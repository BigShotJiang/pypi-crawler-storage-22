---
description: Save current work state for later resume (non-interactive)
---

# Stash Work

You are being asked to save the current work state. This is a "save game" operation - automatically capture context from the recent conversation and create a handoff document for seamless continuation.

**Key Principle**: Extract context from your most recent response and preceding messages. Do NOT ask the user questions - infer everything automatically.

---

## Step 1: Extract Context from Recent Conversation

**Source of Truth**: Your most recent response to the user (before `/stash-work` was invoked)

**What to Extract**:
1. **What was just completed**: Look for summary statements, completion confirmations, "here's what we did"
2. **Current state**: In-progress work, next steps mentioned
3. **Key accomplishments**: Specific deliverables, commits, decisions
4. **What's next**: Next immediate step or task mentioned

**Pattern to Look For**: Often your last response contains:
- "Perfect! Here's what we accomplished..."
- "Migration complete. Next steps..."
- "All changes committed. You can now..."
- Summary sections with bullet points

**Extract ALL relevant context** from that response - it likely already contains the complete picture.

---

## Step 2: Gather Git Context (Automatic)

Run these commands to understand recent work:

```bash
# Recent commits (last 10)
git log --oneline -10

# Current branch
git branch --show-current

# Any uncommitted changes
git status --short

# Files modified recently
git diff --name-only HEAD~5..HEAD
```

**Parse commit messages** for work patterns:
- What was being worked on?
- What got completed?
- Any strategic decisions documented?

---

## Step 3: Gather Project Context (Automatic)

**Read** (do NOT just reference):
- `docs/project_management/PROJECT_TRACKING.md` - Current milestone/epic/task status
- Recent work log entries in `wiki/Work-Log-2025-10.md` (last 3-5 entries)

**Extract**:
- Current milestone status
- What's in progress
- What was recently completed
- Immediate next work

---

## Step 4: Identify Session Type (Automatic)

**Infer from context** why we're pausing:

**Token exhaustion** (high likelihood if invoked near end of long session):
- Check for signs: conversation summary, compact context, 3-5% tokens remaining
- Handoff focus: Preserve context for continuation

**Natural stopping point** (completed major work):
- Check for: "Complete", "Done", "All changes committed"
- Handoff focus: Document accomplishments, clear next step

**Context switch** (interrupted work):
- Check for: Incomplete work, mid-task pause
- Handoff focus: Resume instructions, current state

**Slash command activation** (need restart):
- Check for: New slash commands created, "restart to activate"
- Handoff focus: Testing instructions

---

## Step 4.5: Check for Existing SESSION_HANDOFF.md (Automatic)

**IMPORTANT**: The Write tool requires reading existing files before overwriting them.

**Check if SESSION_HANDOFF.md exists**:

```bash
# Check if file exists
ls -la SESSION_HANDOFF.md 2>&1
```

**If file exists**:
- Read the file first (tool requirement): `Read SESSION_HANDOFF.md` (limit 10 lines is sufficient)
- This satisfies the Write tool's requirement
- Then proceed to overwrite with new content

**If file doesn't exist**:
- Proceed directly to Write (no read required for new files)

**Why This Matters**: Prevents "Error writing file" on every `/stash-work` invocation. The Write tool enforces a "read before write" policy for existing files to prevent accidental data loss.

---

## Step 5: Generate Handoff Document (Automatic)

Create `SESSION_HANDOFF.md` in repository root with this structure:

### Core Sections (Required)

```markdown
# Session Handoff: [Infer Brief Title from Work]

**Date**: [Today's date from env]
**Session Type**: [Token exhaustion / Natural stopping point / etc.]
**Token Status**: [If applicable, mention token % at handoff]
**Status**: ✅ COMPLETE / ⏳ IN PROGRESS / 🔄 PAUSED

---

## What Was Just Completed

[Extract from your last response - what was accomplished]

**Phase/Task/Work**: [What was being done]
- [Accomplishment 1 with evidence]
- [Accomplishment 2 with evidence]
- [Commits: hash, hash]

---

## Strategic Decisions Made (if any)

### 1. [Decision Title]
**Decision**: [What was decided]

**Rationale**: [Why this decision]

**Impact**: [What this affects]

[Repeat for each major decision]

---

## All Changes Committed and Pushed

### [Work Category 1]
- [Change 1]
- [Change 2]
- Commits: [hash, hash]

### [Work Category 2]
- [Change 1]
- [Change 2]

[Include: Files modified, commits, pushes]

---

## [Current Milestone/Epic/Task] Status

**Progress**: [X% or X/Y tasks]
**Status**: [Current state]

**Recent Work**:
- ✅ [Completed item]
- ⏳ [In progress item]
- 📋 [Planned item]

**Next Task**: [Immediate next work item]

---

## What's Next

### Immediate Next Step
**[Action to Take]**: [Specific task]

**Objective**: [What this accomplishes]

**Key Deliverables**: [What will be created]

**Reference Documents**: [Where to find guidance]

### How to Begin
1. [Concrete step 1]
2. [Concrete step 2]
3. [Concrete step 3]

---

## Context for Resumption

### Why We Paused
- [Reason: token exhaustion, natural stopping point, etc.]
- [Context: completed major phase, mid-work, etc.]

### Session Characteristics
- **Duration**: [Estimated time]
- **Work Type**: [Infrastructure / Feature / Bug Fix / etc.]
- **Key Pattern**: [Notable patterns in how work progressed]
- **Quality**: [Assessment of work quality]

### Important Files Modified
- [Count] files updated/created
- [Key file 1] - [Purpose]
- [Key file 2] - [Purpose]

---

## Key Learnings This Session (if any)

1. **[Learning 1]**: [What was discovered/validated]
2. **[Learning 2]**: [Pattern or principle established]
3. **[Learning 3]**: [Process improvement identified]

---

## Quick Reference

### Primary Source of Truth
- **Project Status**: `docs/project_management/PROJECT_TRACKING.md`
- **Active Work**: [GitHub Milestones / Current Epic / etc.]
- **Strategic Context**: `wiki/`
- **Tactical Guides**: `docs/`

### Commands for Quick Status
```bash
# [Relevant command 1]
# [Relevant command 2]
```

---

## Session Metrics (if applicable)

**Estimated Agent Time**: [Active work time]
**Actual Time**: [Wall-clock time]
**Token Usage**: [% consumed]
**Efficiency Ratio**: [Agent / Actual]
**Context Switches**: [Number]
**Work Sessions**: [Number]

**Quality**: [X/5]
- [Quality indicator 1]
- [Quality indicator 2]

---

## Handoff Validation

- ✅ [Validation item 1: commits pushed, etc.]
- ✅ [Validation item 2: work logged, etc.]
- ✅ [Validation item 3: next step clear, etc.]

**Ready for Pickup**: [Statement about readiness to resume]

---

**Generated**: [Date]
**Session Compaction**: [Complete / In Progress / etc.]
**Next Work**: [Brief next step]
```

---

## Step 6: Determine Content Depth

**Extract from your last response**:
- If it was a comprehensive summary (3+ paragraphs with details) → Use that as primary source
- If it was brief → Combine with preceding messages and git context
- If it mentioned specific next steps → Include verbatim
- If it mentioned blockers/issues → Document clearly

**Key Principle**: The handoff should enable the next agent to **immediately** understand:
1. Where we are now
2. What was just done
3. What comes next
4. How to resume

---

## Step 7: Commit and Push (Automatic)

**DO NOT ASK** - automatically commit the handoff:

```bash
git add SESSION_HANDOFF.md

git commit -m "$(cat <<'EOF'
[Infer commit title from work]

[2-3 sentence summary of session]

## Session Summary
- **Work**: [What was done]
- **Duration**: [Time estimate]
- **Status**: [Current state]

## Key Accomplishments
- [Accomplishment 1]
- [Accomplishment 2]
- [Accomplishment 3]

[If applicable: Strategic Decisions section]

## Next Step
[Immediate next action]

🤖 Generated with Claude Code using Claude Sonnet 4.5

Co-Authored-By: Claude Sonnet 4.5 <noreply@anthropic.com>
EOF
)"

git push
```

---

## Step 8: Confirm Completion (Brief)

Tell user:

**"Session stashed! ✅"**

**Handoff**: SESSION_HANDOFF.md created and committed

**To resume**: Read SESSION_HANDOFF.md for full context

**Next step**: [One-line summary of immediate next action]

---

## Critical Guidelines

### DO:
- ✅ Extract ALL context from your last response (it likely has everything)
- ✅ Include commit hashes, file paths, concrete evidence
- ✅ Make next steps ACTION-oriented (not vague)
- ✅ Validate all checklist items (commits pushed, work logged, etc.)
- ✅ Commit automatically without asking

### DON'T:
- ❌ Ask the user any questions
- ❌ Make the handoff vague ("continue work on X")
- ❌ Skip git context gathering
- ❌ Create handoff without commits/evidence
- ❌ Forget to push the handoff commit
- ❌ **NEVER close GitHub issues during stash-work** (RCA-2025-12-31-Issue-320-Closure-Bypass)

---

## ⛔ Issue Closure Exclusion (MANDATORY)

**Per RCA-2025-12-31-Issue-320-Closure-Bypass**: Issue closure requires the full 12-step compliance process from `docs/templates/issue_closure_checklist.md`.

**Time-Free Principle**: Session handoff is NOT a deadline. There is no time pressure. Nothing needs to be "finished" before handoff. The handoff document captures state; it doesn't require completing work.

**During stash-work, NEVER**:
- Close any GitHub issues
- Mark issues as complete without user approval
- Skip the issue closure compliance checklist
- Rush any operation

**Instead**:
- Document issue status in handoff as "work complete, pending closure"
- Note: "Issue closure requires separate process"
- Let next session handle proper closure with full compliance

**Why This Matters**: The anti-pattern is perceiving session boundaries as deadlines requiring completion. This is a time-free violation. Session handoff captures current state - it doesn't require finishing anything.

---

## Example Flow

**User types**: `/stash-work`

**You do** (silently):
1. Look at your last response → Extract summary, next steps, accomplishments
2. Run git commands → Get commits, files, branch
3. Read PROJECT_TRACKING.md → Get current milestone/task status
4. Infer session type → Token exhaustion? Natural stop? Context switch?
5. Generate SESSION_HANDOFF.md → Comprehensive document with all context
6. Commit and push → Automatic, no asking
7. Brief confirmation → "Session stashed! Next: [action]"

**Total interaction**: One confirmation message. No questions asked.

---

## Why This Approach Works

**Your last response** (before `/stash-work`) typically contains:
- Summary of what was just completed
- Next steps or suggestions
- Key accomplishments or decisions
- Current state assessment

**This is exactly what the handoff needs!**

By extracting that content programmatically and combining it with git context + project status, you have everything needed to create a comprehensive handoff.

---

## Special Cases

### If Last Response Was Error/Failure
- Document what was attempted
- Document what failed
- Document blocker/issue
- Next step: Resolve the issue

### If Last Response Was Question to User
- Document the question context
- Document what decision is pending
- Next step: Get user's answer, then continue

### If Last Response Was Brief Acknowledgment
- Look at preceding messages for actual work
- Extract from earlier comprehensive updates
- Combine context from last 3-5 messages

---

**Instruction Source**: User feedback (2025-10-31) - "/stash-work should be non-interactive 'save game' operation"
