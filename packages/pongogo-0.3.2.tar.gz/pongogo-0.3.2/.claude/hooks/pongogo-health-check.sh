#!/bin/bash
# Pongogo MCP Health Check - SessionStart Hook
# Bug #380: Proactive detection of stale MCP connections
#
# This hook runs at session start to detect:
# 1. Docker container not running
# 2. Routing/event logging failures (via verification routing)
#
# Exit codes:
# 0 = Success (stdout added to session context)
# 2 = Blocking error (stderr shown, session continues)

set -euo pipefail

# Configuration
CONTAINER_NAME="knowledge-hub"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERIFY_SCRIPT="$SCRIPT_DIR/verify_routing.py"

# Collect status
issues=()

# Check 1: Docker container running
if ! docker ps --format '{{.Names}}' 2>/dev/null | grep -q "^${CONTAINER_NAME}$"; then
    issues+=("Container '$CONTAINER_NAME' is NOT running")
    issues+=("Run: docker-compose up -d knowledge-hub")
else
    # Check 2: Verification routing (eliminates false positives)
    # Tests actual routing + event logging end-to-end
    if [ -f "$VERIFY_SCRIPT" ]; then
        verify_output=$(python3 "$VERIFY_SCRIPT" 2>&1) || {
            issues+=("Routing verification FAILED")
            issues+=("  $verify_output")
            issues+=("  Run /mcp to reconnect, then verify with /pongogo-status")
        }
    fi
fi

# Output results
if [ ${#issues[@]} -gt 0 ]; then
    # Critical issues found - show warning banner
    echo ""
    echo "=============================================="
    echo "PONGOGO HEALTH CHECK WARNING"
    echo "=============================================="
    for issue in "${issues[@]}"; do
        echo "  - $issue"
    done
    echo "=============================================="
    echo ""
    exit 0  # Still exit 0 so session starts, but context is added
fi

# All healthy - minimal output
exit 0
