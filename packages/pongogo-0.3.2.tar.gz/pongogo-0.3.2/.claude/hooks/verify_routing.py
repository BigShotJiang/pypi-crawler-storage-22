#!/usr/bin/env python3
"""
Verification routing helper for SessionStart health check.
Bug #380: Eliminates false positives by testing actual routing.

This script:
1. Runs a test routing call (direct import, same as UserPromptSubmit hook)
2. Writes a canary event to SQLite
3. Verifies the event appears
4. Cleans up the canary event

Exit codes:
0 = Verification passed (routing + event logging work)
1 = Verification failed (something broken)
"""

import hashlib
import sqlite3
import sys
from datetime import datetime
from pathlib import Path

# Get project directory from environment or infer
PROJECT_DIR = Path(__file__).parent.parent.parent

# Database path (unified schema v3.0.0, matches claude_code_adapter.py)
DB_PATH = PROJECT_DIR / ".pongogo" / "pongogo.db"

# Knowledge base path (matches claude_code_adapter.py)
KNOWLEDGE_BASE_PATH = PROJECT_DIR / ".pongogo" / "instructions"

# Add src directory to path (for package imports)
SRC_PATH = PROJECT_DIR / "src"
if str(SRC_PATH) not in sys.path:
    sys.path.insert(0, str(SRC_PATH))


def verify_routing() -> tuple[bool, str]:
    """
    Verify routing and event logging work end-to-end.

    Returns:
        Tuple of (success, message)
    """
    canary_id = f"health-check-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    canary_message = f"__PONGOGO_HEALTH_CHECK__{canary_id}__"
    canary_hash = hashlib.sha256(canary_message.encode()).hexdigest()

    try:
        # Step 1: Test routing (package import from src/mcp_server)
        from mcp_server.instruction_handler import InstructionHandler
        from mcp_server.pongogo_router import InstructionRouter

        if not KNOWLEDGE_BASE_PATH.exists():
            return False, f"Knowledge base not found: {KNOWLEDGE_BASE_PATH}"

        instruction_handler = InstructionHandler(KNOWLEDGE_BASE_PATH)
        instruction_count = instruction_handler.load_instructions()

        if instruction_count == 0:
            return False, "No instructions loaded"

        router = InstructionRouter(instruction_handler)
        result = router.route("health check test", limit=1)

        if result.get("count", 0) == 0:
            return False, "Routing returned 0 results"

        # Step 2: Write canary event to database
        if not DB_PATH.exists():
            return False, f"Database not found: {DB_PATH}"

        conn = sqlite3.connect(str(DB_PATH))
        cursor = conn.cursor()

        # Unified schema v3.0.0 columns (mode required by production schema)
        cursor.execute(
            """
            INSERT INTO routing_events (
                timestamp, session_id, mode, user_message, message_hash,
                instruction_count, routing_latency_ms,
                exclude_from_eval, exclude_reason
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
            (
                datetime.now().isoformat(),
                "health-check",
                "enabled",  # mode (required NOT NULL)
                canary_message,  # user_message (required)
                canary_hash,
                1,  # instruction_count
                0.0,  # routing_latency_ms
                True,  # exclude_from_eval
                "health_check_canary",  # exclude_reason
            ),
        )
        conn.commit()

        # Step 3: Verify canary exists
        cursor.execute(
            "SELECT COUNT(*) FROM routing_events WHERE message_hash = ?", (canary_hash,)
        )
        count = cursor.fetchone()[0]

        if count == 0:
            conn.close()
            return False, "Canary event not found after insert"

        # Step 4: Clean up canary
        cursor.execute(
            "DELETE FROM routing_events WHERE message_hash = ?", (canary_hash,)
        )
        conn.commit()
        conn.close()

        return True, "Routing and event logging verified"

    except ImportError as e:
        return False, f"Import error: {e}"
    except sqlite3.Error as e:
        return False, f"Database error: {e}"
    except Exception as e:
        return False, f"Unexpected error: {e}"


if __name__ == "__main__":
    success, message = verify_routing()
    if success:
        print(f"OK: {message}")
        sys.exit(0)
    else:
        print(f"FAIL: {message}")
        sys.exit(1)
