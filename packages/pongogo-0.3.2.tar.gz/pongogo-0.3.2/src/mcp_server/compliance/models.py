"""
Data models for the compliance enforcement system.

Platform-agnostic: no Claude Code or hook-specific imports.
"""

from dataclasses import dataclass, field
from enum import Enum


class RuleType(str, Enum):
    """Types of compliance requirements that can be extracted from instructions."""

    READ_FILE = "read_file"
    READ_INSTRUCTION = "read_instruction"
    PROCESS_CHECKLIST = "process_checklist"
    APPROVAL_REQUIRED = "approval_required"
    STEP_CITATION = "step_citation"


@dataclass
class ComplianceRule:
    """A single compliance requirement extracted from a procedural instruction."""

    rule_type: RuleType
    description: str
    source_instruction_id: str
    required_tool: str | None = None
    required_args: dict | None = None
    referenced_file: str | None = None

    def matches_tool_call(self, tool_name: str, tool_input: dict) -> bool:
        """Check if a tool call could potentially satisfy this rule.

        This is a fast pre-filter. The evaluator does full matching.
        """
        if self.rule_type == RuleType.READ_FILE:
            return tool_name == "Read" and self.referenced_file is not None
        if self.rule_type == RuleType.READ_INSTRUCTION:
            return tool_name == "Read"
        if self.rule_type == RuleType.PROCESS_CHECKLIST:
            return tool_name == "Read"
        return False


@dataclass
class FulfillmentResult:
    """Result of evaluating a tool call against a compliance requirement."""

    fulfilled: bool
    partial: bool = False
    reason: str = ""


@dataclass
class ComplianceSpec:
    """Collection of compliance rules extracted from an instruction."""

    rules: list[ComplianceRule] = field(default_factory=list)
    source_instruction_id: str = ""
    detection_method: str = ""

    @property
    def has_rules(self) -> bool:
        return len(self.rules) > 0
