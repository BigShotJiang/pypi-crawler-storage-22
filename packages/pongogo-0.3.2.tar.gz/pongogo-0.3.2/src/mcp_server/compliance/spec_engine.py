"""
Compliance specification engine for parsing procedural instructions.

Extracts declarative ComplianceRule objects from COMPLIANCE GATE blocks
found in procedural instruction content.

Platform-agnostic: no Claude Code or hook-specific imports.

Epic #545: Hook-Based Compliance Enforcement
"""

import logging
import re

from .models import ComplianceRule, ComplianceSpec, RuleType

logger = logging.getLogger(__name__)

# Pattern to detect COMPLIANCE GATE section headers
# Matches variations: "## 🛑 COMPLIANCE GATE", "## 🛑 STOP: COMPLIANCE GATE (BLOCKING - NOT ADVISORY)"
COMPLIANCE_GATE_HEADER = re.compile(
    r"^##\s+.*COMPLIANCE\s+GATE.*$", re.MULTILINE | re.IGNORECASE
)

# Pattern to extract Read tool call requirements from compliance gates
# Matches: Read(file_path="/path/to/file.md") or Read(`path/to/file.md`)
READ_TOOL_CALL_PATTERN = re.compile(
    r'Read\s*\(\s*file_path\s*=\s*["\']([^"\']+)["\']',
    re.IGNORECASE,
)

# Pattern to extract referenced documents from compliance gates
# Matches: Read `docs/templates/issue_closure_checklist.md`
# or: read `docs/templates/issue_closure_checklist.md` first
READ_DOC_REFERENCE_PATTERN = re.compile(
    r'[Rr]ead\s+[`"\']([^`"\']+\.md)[`"\']',
)

# Pattern to detect "read this instruction file" requirements
READ_INSTRUCTION_PATTERN = re.compile(
    r"(?:have\s+I\s+READ\s+this\s+instruction\s+file|"
    r"read\s+this\s+file\s+NOW|"
    r"read\s+the\s+instruction\s+file)",
    re.IGNORECASE,
)

# Pattern to detect step citation requirements
STEP_CITATION_PATTERN = re.compile(
    r"(?:cite\s+step\s+numbers|"
    r"step\s+citation\s+requirement|"
    r'format:\s+["\']?step\s+\d)',
    re.IGNORECASE,
)


class ComplianceSpecEngine:
    """Parse procedural instructions into declarative compliance rules.

    This engine extracts ComplianceSpec objects from instruction content by:
    1. Detecting COMPLIANCE GATE sections
    2. Parsing required actions (Read tool calls, file references, approvals)
    3. Building ComplianceRule objects for each requirement

    Usage:
        engine = ComplianceSpecEngine()
        spec = engine.parse(instruction_id, instruction_content)
        if spec.has_rules:
            for rule in spec.rules:
                print(f"Requirement: {rule.description}")
    """

    def parse(self, instruction_id: str, content: str) -> ComplianceSpec:
        """Parse instruction content into a ComplianceSpec.

        Args:
            instruction_id: Identifier for the source instruction
            content: Full text content of the instruction file

        Returns:
            ComplianceSpec with extracted rules (empty if no compliance gates found)
        """
        if not content:
            return ComplianceSpec(source_instruction_id=instruction_id)

        # Find COMPLIANCE GATE sections
        gate_sections = self._extract_gate_sections(content)
        if not gate_sections:
            return ComplianceSpec(source_instruction_id=instruction_id)

        rules = []
        for section in gate_sections:
            rules.extend(self._extract_rules(instruction_id, section))

        return ComplianceSpec(
            rules=rules,
            source_instruction_id=instruction_id,
            detection_method="compliance_gate",
        )

    def parse_from_routing_result(
        self, instruction_id: str, content: str, procedural_info: dict
    ) -> ComplianceSpec:
        """Parse from routing result that already has procedural detection info.

        This optimized path uses the detection already done by
        pongogo_router._is_procedural_instruction().

        Args:
            instruction_id: Identifier for the source instruction
            content: Full text content of the instruction file
            procedural_info: Dict from _is_procedural_instruction() with
                is_procedural, detection_method, referenced_doc

        Returns:
            ComplianceSpec with extracted rules
        """
        if not procedural_info.get("is_procedural", False):
            return ComplianceSpec(source_instruction_id=instruction_id)

        spec = self.parse(instruction_id, content)

        # If routing detected a referenced doc but parsing didn't find it,
        # add a READ_FILE rule from the routing detection
        if procedural_info.get("referenced_doc"):
            ref_doc = procedural_info["referenced_doc"]
            has_ref = any(
                r.referenced_file == ref_doc
                for r in spec.rules
                if r.rule_type == RuleType.READ_FILE
            )
            if not has_ref:
                spec.rules.append(
                    ComplianceRule(
                        rule_type=RuleType.READ_FILE,
                        description=f"Read {ref_doc} before executing",
                        source_instruction_id=instruction_id,
                        required_tool="Read",
                        referenced_file=ref_doc,
                    )
                )

        return spec

    def _extract_gate_sections(self, content: str) -> list[str]:
        """Extract COMPLIANCE GATE sections from instruction content.

        Returns the text of each compliance gate section, from the header
        to the next --- separator or next ## header.
        """
        sections = []
        matches = list(COMPLIANCE_GATE_HEADER.finditer(content))

        for match in matches:
            start = match.start()
            # Find the end: next "---" or next "## " after this section
            rest = content[match.end() :]
            end_match = re.search(r"^---\s*$|^## (?!.*COMPLIANCE)", rest, re.MULTILINE)
            if end_match:
                section_text = content[start : match.end() + end_match.start()]
            else:
                section_text = content[start:]
            sections.append(section_text)

        return sections

    def _extract_rules(
        self, instruction_id: str, gate_section: str
    ) -> list[ComplianceRule]:
        """Extract compliance rules from a single COMPLIANCE GATE section."""
        rules = []

        # Check for explicit Read tool call requirements
        for match in READ_TOOL_CALL_PATTERN.finditer(gate_section):
            file_path = match.group(1)
            rules.append(
                ComplianceRule(
                    rule_type=RuleType.READ_FILE,
                    description=f"Read {file_path} before executing",
                    source_instruction_id=instruction_id,
                    required_tool="Read",
                    referenced_file=file_path,
                )
            )

        # Check for referenced document requirements (Read `path/to/file.md`)
        for match in READ_DOC_REFERENCE_PATTERN.finditer(gate_section):
            ref_doc = match.group(1)
            # Avoid duplicates if same file found by READ_TOOL_CALL_PATTERN
            already_found = any(r.referenced_file == ref_doc for r in rules)
            if not already_found:
                rules.append(
                    ComplianceRule(
                        rule_type=RuleType.READ_FILE,
                        description=f"Read {ref_doc} before executing",
                        source_instruction_id=instruction_id,
                        required_tool="Read",
                        referenced_file=ref_doc,
                    )
                )

        # Check for "read this instruction file" requirement
        if READ_INSTRUCTION_PATTERN.search(gate_section):
            rules.append(
                ComplianceRule(
                    rule_type=RuleType.READ_INSTRUCTION,
                    description="Read this instruction file before executing",
                    source_instruction_id=instruction_id,
                    required_tool="Read",
                )
            )

        # Check for step citation requirement
        if STEP_CITATION_PATTERN.search(gate_section):
            rules.append(
                ComplianceRule(
                    rule_type=RuleType.STEP_CITATION,
                    description="Cite step numbers from the instruction file",
                    source_instruction_id=instruction_id,
                )
            )

        return rules
