#!/usr/bin/env python3
"""
PostToolUse Compliance Verification Hook

Fires after every tool call to check if it satisfies a pending compliance
requirement. Updates fulfillment state in the database.

Architecture:
    Tool Call Complete → PostToolUse Hook → This Script →
        [Check Pending Requirements] → [Evaluate Fulfillment] →
        [Update Database] → Exit (silent)

Usage:
    Configured in .claude/settings.local.json as PostToolUse hook:
    {
      "hooks": {
        "PostToolUse": [{
          "matcher": "Read",
          "hooks": [{"type": "command", "command": "/path/to/posttooluse_compliance_hook.py"}]
        }]
      }
    }

Input:
    Receives JSON via stdin with:
    - session_id: Current session identifier
    - tool_name: Name of the tool that was called
    - tool_input: Parameters passed to the tool
    - tool_response: Result from the tool
    - transcript_path: Path to conversation JSONL file
    - hook_event_name: "PostToolUse"

Output:
    Prints nothing (silent operation - state tracking only)

Exit Codes:
    0: Success (fulfillment checked and updated)
    1: Error (logged, doesn't block)

Epic #545: Hook-Based Compliance Enforcement
Task #547: PostToolUse Verification Hook
"""

import json
import logging
import sqlite3
import sys
import time
from datetime import datetime
from pathlib import Path

# Configure logging to file (not stdout - stdout would inject context)
# Lazy initialization to avoid side effects at import time (CI test environments)
_log_initialized = False
logger = logging.getLogger(__name__)


def _get_log_dir() -> Path:
    """Get the appropriate log directory based on environment.

    Priority:
    1. PONGOGO_PROJECT_ROOT/.pongogo/logs/ (Docker container)
    2. ~/.claude/logs/ (host machine)
    3. /tmp/pongogo-logs/ (fallback)
    """
    import os

    # Docker container: use project-mounted directory
    project_root = os.environ.get("PONGOGO_PROJECT_ROOT")
    if project_root:
        return Path(project_root) / ".pongogo" / "logs"

    # Host machine: use standard Claude logs location
    return Path.home() / ".claude" / "logs"


def _ensure_log_dir():
    """Ensure log directory exists and configure logging. Called lazily on first use."""
    global _log_initialized
    if _log_initialized:
        return

    log_dir = _get_log_dir()
    log_file = log_dir / "posttooluse-compliance.log"

    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        )
        _log_initialized = True
    except (PermissionError, OSError) as e:
        # Fall back to /tmp if primary location fails
        fallback_dir = Path("/tmp/pongogo-logs")
        try:
            fallback_dir.mkdir(parents=True, exist_ok=True)
            logging.basicConfig(
                filename=fallback_dir / "posttooluse-compliance.log",
                level=logging.INFO,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )
            logging.getLogger(__name__).warning(
                f"Using fallback log dir {fallback_dir}: primary {log_dir} failed with {e}"
            )
            _log_initialized = True
        except (PermissionError, OSError):
            # Last resort: log to stderr so we don't lose diagnostics entirely
            logging.basicConfig(
                stream=sys.stderr,
                level=logging.WARNING,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )
            logging.getLogger(__name__).error(
                f"Could not create log directory at {log_dir} or {fallback_dir}"
            )
            _log_initialized = True


def get_db_path() -> Path | None:
    """Find the Pongogo database path.

    Search order:
    1. PONGOGO_PROJECT_ROOT env var (Docker container mount point)
    2. Current working directory
    3. User home directory fallback
    """
    import os

    # Check PONGOGO_PROJECT_ROOT first (Docker container environment)
    project_root = os.environ.get("PONGOGO_PROJECT_ROOT")
    if project_root:
        project_db = Path(project_root) / ".pongogo" / "pongogo.db"
        if project_db.exists():
            return project_db

    # Check project-local (cwd)
    cwd = Path.cwd()
    local_db = cwd / ".pongogo" / "pongogo.db"
    if local_db.exists():
        return local_db

    # Fall back to user-level
    user_db = Path.home() / ".pongogo" / "pongogo.db"
    if user_db.exists():
        return user_db

    return None


def get_pending_requirements(db_path: Path, session_id: str) -> list[dict]:
    """Query guidance_fulfillment for pending requirements in this session."""
    try:
        conn = sqlite3.connect(str(db_path), timeout=5)
        conn.row_factory = sqlite3.Row
        cursor = conn.execute(
            """
            SELECT id, guidance_type, guidance_content, action_type,
                   fulfillment_status, session_id
            FROM guidance_fulfillment
            WHERE session_id = ? AND fulfillment_status IN ('pending', 'in_progress', 'carried_forward')
            ORDER BY created_at ASC
            """,
            (session_id,),
        )
        rows = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return rows
    except sqlite3.Error as e:
        logger.error(f"Database error querying pending requirements: {e}")
        return []


def update_fulfillment_status(
    db_path: Path,
    requirement_id: int,
    new_status: str,
    evidence: str,
    fulfillment_event_id: int | None = None,
) -> None:
    """Update the fulfillment status of a requirement."""
    try:
        conn = sqlite3.connect(str(db_path), timeout=5)
        conn.execute(
            """
            UPDATE guidance_fulfillment
            SET fulfillment_status = ?,
                fulfillment_evidence = ?,
                fulfillment_event_id = ?,
                fulfilled_at = ?
            WHERE id = ?
            """,
            (
                new_status,
                evidence,
                fulfillment_event_id,
                datetime.now().isoformat() if new_status == "fulfilled" else None,
                requirement_id,
            ),
        )
        conn.commit()
        conn.close()
    except sqlite3.Error as e:
        logger.error(f"Database error updating fulfillment: {e}")


def evaluate_tool_call(
    tool_name: str, tool_input: dict, requirement: dict
) -> dict | None:
    """Evaluate if a tool call satisfies a requirement.

    Lightweight evaluation without importing the full compliance module.
    Checks if a Read tool call matches a pending requirement.

    Returns:
        Dict with fulfillment details if matched, None otherwise
    """
    if tool_name != "Read":
        return None

    file_path = tool_input.get("file_path", "")
    if not file_path:
        return None

    action_type = requirement.get("action_type", "")
    guidance_content = requirement.get("guidance_content", "")

    # Check if the Read call matches a "read instruction" requirement
    if action_type in ("read_instruction", "process_checklist"):
        # Check if the file path contains .pongogo/instructions/
        if ".pongogo/instructions/" in file_path and file_path.endswith(
            ".instructions.md"
        ):
            return {
                "fulfilled": True,
                "evidence": f"Read tool call on instruction file: {file_path}",
            }

    # Check if the Read call matches a specific file requirement
    if action_type == "read_file":
        # The guidance_content may contain the required file path
        # Check if the actual read matches
        if guidance_content:
            # Extract file path from guidance content
            required_file = _extract_required_file(guidance_content)
            if required_file and _paths_match(file_path, required_file):
                return {
                    "fulfilled": True,
                    "evidence": f"Read tool call matches required file: {file_path}",
                }

    return None


def _extract_required_file(guidance_content: str) -> str | None:
    """Extract a file path from guidance content text."""
    import re

    # Match patterns like: Read /path/to/file.md or Read(file_path="/path/to/file.md")
    match = re.search(
        r'(?:Read\s+|file_path\s*=\s*["\'])([^\s"\']+\.md)', guidance_content
    )
    if match:
        return match.group(1)
    return None


def _paths_match(actual_path: str, required_path: str) -> bool:
    """Check if two file paths refer to the same file."""
    if actual_path == required_path:
        return True

    # Check suffix match (handles absolute vs relative)
    actual_parts = Path(actual_path).parts
    required_parts = Path(required_path).parts

    if len(required_parts) <= len(actual_parts):
        return actual_parts[-len(required_parts) :] == required_parts

    return False


def main():
    _ensure_log_dir()
    start_time = time.time()

    try:
        input_data = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError):
        logger.error("Failed to read JSON from stdin")
        sys.exit(0)  # Don't block on input errors

    session_id = input_data.get("session_id", "")
    tool_name = input_data.get("tool_name", "")
    tool_input = input_data.get("tool_input", {})

    # Fast path: only process Read tool calls (most compliance requirements involve reading)
    if tool_name != "Read":
        elapsed = (time.time() - start_time) * 1000
        logger.debug(f"Fast-path skip for {tool_name}: {elapsed:.1f}ms")
        sys.exit(0)

    # Find database
    db_path = get_db_path()
    if not db_path:
        logger.debug("No database found, skipping compliance check")
        sys.exit(0)

    # Check for pending requirements
    pending = get_pending_requirements(db_path, session_id)
    if not pending:
        elapsed = (time.time() - start_time) * 1000
        logger.debug(
            f"No pending requirements for session {session_id}: {elapsed:.1f}ms"
        )
        sys.exit(0)

    # Evaluate tool call against each pending requirement
    fulfilled_count = 0
    for req in pending:
        result = evaluate_tool_call(tool_name, tool_input, req)
        if result and result.get("fulfilled"):
            update_fulfillment_status(
                db_path,
                req["id"],
                "fulfilled",
                result["evidence"],
            )
            fulfilled_count += 1
            logger.info(
                f"Compliance requirement fulfilled: id={req['id']}, "
                f"action_type={req['action_type']}, "
                f"evidence={result['evidence'][:80]}"
            )

    elapsed = (time.time() - start_time) * 1000
    logger.info(
        f"PostToolUse compliance check: tool={tool_name}, "
        f"pending={len(pending)}, fulfilled={fulfilled_count}, "
        f"elapsed={elapsed:.1f}ms"
    )

    # Silent exit - no stdout output
    sys.exit(0)


if __name__ == "__main__":
    main()
