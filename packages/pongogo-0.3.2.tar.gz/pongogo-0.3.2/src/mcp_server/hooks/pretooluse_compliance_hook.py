#!/usr/bin/env python3
"""
PreToolUse Compliance Gate - Blocks tool execution until requirements met.

Fires BEFORE tool execution to check if pending compliance requirements
would be violated. This is the enforcement layer that "traps" the LLM
until compliance is demonstrated.

Architecture:
    LLM requests tool → PreToolUse Hook → This Script →
        [Check Pending Requirements] → [Evaluate Blocking Rules] →
        [ALLOW or DENY with message] → Claude receives result

Usage:
    Configured in .claude/settings.local.json as PreToolUse hook:
    {
      "hooks": {
        "PreToolUse": [{
          "matcher": "mcp__github__close_issue",
          "hooks": [{"type": "command", "command": "/path/to/pretooluse_compliance_hook.py"}]
        }]
      }
    }

Input:
    Receives JSON via stdin with:
    - session_id: Current session identifier
    - tool_name: Name of the tool being called
    - tool_input: Parameters being passed to the tool
    - transcript_path: Path to conversation JSONL file
    - hook_event_name: "PreToolUse"

Output:
    - If ALLOWED: Silent exit (no output), exit code 0
    - If BLOCKED: JSON {"permissionDecision": "deny", "message": "..."} to stdout

Exit Codes:
    0: Success (tool allowed or blocked with message)
    1: Error (logged, tool allowed by default for safety)

Epic #545: Hook-Based Compliance Enforcement
Task #549: PreToolUse Enforcement Gate
"""

import json
import logging
import sqlite3
import sys
import time
from pathlib import Path

# Configure logging to file (not stdout - stdout is for denial messages)
# Lazy initialization to avoid side effects at import time (CI test environments)
_log_initialized = False
logger = logging.getLogger(__name__)


def _get_log_dir() -> Path:
    """Get the appropriate log directory based on environment.

    Priority:
    1. PONGOGO_PROJECT_ROOT/.pongogo/logs/ (Docker container)
    2. ~/.claude/logs/ (host machine)
    3. /tmp/pongogo-logs/ (fallback)
    """
    import os

    # Docker container: use project-mounted directory
    project_root = os.environ.get("PONGOGO_PROJECT_ROOT")
    if project_root:
        return Path(project_root) / ".pongogo" / "logs"

    # Host machine: use standard Claude logs location
    return Path.home() / ".claude" / "logs"


def _ensure_log_dir():
    """Ensure log directory exists and configure logging. Called lazily on first use."""
    global _log_initialized
    if _log_initialized:
        return

    log_dir = _get_log_dir()
    log_file = log_dir / "pretooluse-compliance.log"

    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        )
        _log_initialized = True
    except (PermissionError, OSError) as e:
        # Fall back to /tmp if primary location fails
        fallback_dir = Path("/tmp/pongogo-logs")
        try:
            fallback_dir.mkdir(parents=True, exist_ok=True)
            logging.basicConfig(
                filename=fallback_dir / "pretooluse-compliance.log",
                level=logging.INFO,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )
            # Log the fallback so we know it happened
            logging.getLogger(__name__).warning(
                f"Using fallback log dir {fallback_dir}: primary {log_dir} failed with {e}"
            )
            _log_initialized = True
        except (PermissionError, OSError):
            # Last resort: log to stderr so we don't lose diagnostics entirely
            logging.basicConfig(
                stream=sys.stderr,
                level=logging.WARNING,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )
            logging.getLogger(__name__).error(
                f"Could not create log directory at {log_dir} or {fallback_dir}"
            )
            _log_initialized = True


# Mapping of tools to required action types that must be fulfilled before execution
# Key: tool name pattern
# Value: list of action_types that must NOT be pending
#
# Action types from src/mcp_server/compliance/models.py:
#   - read_file: Must read a specific file before proceeding
#   - read_instruction: Must read an instruction document
#   - process_checklist: Must process/complete a checklist
#   - step_citation: Must cite specific steps from instructions
#   - approval_required: Requires explicit approval
TOOL_ENFORCEMENT_RULES: dict[str, list[str]] = {
    # Issue closure requires completing all compliance requirements
    "mcp__github__close_issue": [
        "read_file",
        "read_instruction",
        "process_checklist",
        "step_citation",
    ],
    # Issue update requires reading relevant instructions/files
    "mcp__github__update_issue": [
        "read_file",
        "read_instruction",
    ],
    # PR creation requires completing all compliance requirements
    "mcp__github__create_pull_request": [
        "read_file",
        "read_instruction",
        "process_checklist",
        "step_citation",
    ],
}


def get_db_path() -> Path | None:
    """Find the Pongogo database path.

    Search order:
    1. PONGOGO_PROJECT_ROOT env var (Docker container mount point)
    2. Current working directory
    3. User home directory fallback
    """
    import os

    # Check PONGOGO_PROJECT_ROOT first (Docker container environment)
    project_root = os.environ.get("PONGOGO_PROJECT_ROOT")
    if project_root:
        project_db = Path(project_root) / ".pongogo" / "pongogo.db"
        if project_db.exists():
            return project_db

    # Check project-local (cwd)
    cwd = Path.cwd()
    local_db = cwd / ".pongogo" / "pongogo.db"
    if local_db.exists():
        return local_db

    # Fall back to user-level
    user_db = Path.home() / ".pongogo" / "pongogo.db"
    if user_db.exists():
        return user_db

    return None


def get_pending_requirements(db_path: Path, session_id: str) -> list[dict]:
    """Query guidance_fulfillment for pending requirements in this session.

    Returns requirements with status: pending, in_progress, or carried_forward
    """
    try:
        conn = sqlite3.connect(str(db_path), timeout=5)
        conn.row_factory = sqlite3.Row
        cursor = conn.execute(
            """
            SELECT id, guidance_type, guidance_content, action_type,
                   fulfillment_status, session_id
            FROM guidance_fulfillment
            WHERE session_id = ?
            AND fulfillment_status IN ('pending', 'in_progress', 'carried_forward')
            ORDER BY created_at ASC
            """,
            (session_id,),
        )
        rows = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return rows
    except sqlite3.Error as e:
        logger.error(f"Database error querying pending requirements: {e}")
        return []


def check_compliance(
    session_id: str, tool_name: str, db_path: Path | None = None
) -> dict | None:
    """Check if pending requirements block this tool execution.

    Args:
        session_id: Current session identifier
        tool_name: Name of the tool being called
        db_path: Optional explicit database path (for testing)

    Returns:
        None if tool is allowed (no blocking requirements)
        Dict with permissionDecision and message if blocked
    """
    # Get DB path if not provided
    if db_path is None:
        db_path = get_db_path()

    if db_path is None:
        logger.debug("No database found, allowing tool execution")
        return None  # No database = no enforcement

    # Check if this tool has enforcement rules
    required_action_types = TOOL_ENFORCEMENT_RULES.get(tool_name, [])
    if not required_action_types:
        logger.debug(f"No enforcement rules for tool {tool_name}, allowing")
        return None  # Tool not in enforcement list

    # Get pending requirements for this session
    pending = get_pending_requirements(db_path, session_id)
    if not pending:
        logger.debug(f"No pending requirements for session {session_id}, allowing")
        return None  # No pending requirements

    # Check if any pending requirements match the blocking types for this tool
    blocking_requirements = [
        req for req in pending if req["action_type"] in required_action_types
    ]

    if not blocking_requirements:
        logger.debug(
            f"No blocking requirements for {tool_name} (required: {required_action_types})"
        )
        return None  # No blocking requirements for this specific tool

    # Build the denial message
    requirements_list = "\n".join(
        [
            f"  - [{req['action_type']}] {req['guidance_content'][:100]}"
            for req in blocking_requirements
        ]
    )

    denial_message = f"""COMPLIANCE GATE: Cannot execute {tool_name}

You must complete these requirements first:
{requirements_list}

To proceed:
1. Read the required instruction file(s) using the Read tool
2. Follow the documented procedures
3. Then retry this action

This enforcement ensures procedural compliance with documented standards."""

    logger.info(
        f"BLOCKING {tool_name}: {len(blocking_requirements)} unmet requirements "
        f"for session {session_id}"
    )

    return {"permissionDecision": "deny", "message": denial_message}


def load_state_file() -> dict:
    """Load Pongogo state from .pongogo-mcp-state.json."""
    state_file = Path.cwd() / ".pongogo-mcp-state.json"

    # Search parent directories if not found
    if not state_file.exists():
        for parent in Path.cwd().parents:
            candidate = parent / ".pongogo-mcp-state.json"
            if candidate.exists():
                state_file = candidate
                break

    if not state_file.exists():
        return {}

    try:
        with open(state_file) as f:
            return json.load(f)
    except Exception:
        return {}


def main():
    """Main entry point for PreToolUse hook."""
    _ensure_log_dir()
    start_time = time.time()

    try:
        input_data = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError):
        logger.error("Failed to read JSON from stdin")
        sys.exit(0)  # Allow tool on input error (fail-open for safety)

    session_id = input_data.get("session_id", "")
    tool_name = input_data.get("tool_name", "")

    logger.debug(f"PreToolUse check: tool={tool_name}, session={session_id[:16]}...")

    # Check if Pongogo is disabled
    state = load_state_file()
    mode = state.get("mode", "enabled")
    if mode == "disabled":
        logger.debug("Pongogo disabled, allowing tool execution")
        sys.exit(0)

    # Check compliance
    result = check_compliance(session_id, tool_name)

    elapsed_ms = (time.time() - start_time) * 1000

    if result:
        # BLOCK: Output denial JSON to stdout
        logger.info(
            f"PreToolUse BLOCKED: tool={tool_name}, session={session_id[:16]}, "
            f"latency={elapsed_ms:.1f}ms"
        )
        print(json.dumps(result))
        sys.exit(0)
    else:
        # ALLOW: Silent exit
        logger.debug(
            f"PreToolUse ALLOWED: tool={tool_name}, session={session_id[:16]}, "
            f"latency={elapsed_ms:.1f}ms"
        )
        sys.exit(0)


if __name__ == "__main__":
    main()
