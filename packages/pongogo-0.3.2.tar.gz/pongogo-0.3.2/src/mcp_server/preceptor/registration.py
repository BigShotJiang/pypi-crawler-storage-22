"""
Compliance registrar — writes ComplianceRule objects to guidance_fulfillment.

Platform-agnostic: uses raw SQLite, no Claude Code or hook-specific imports.

Epic #545: Hook-Based Compliance Enforcement
"""

import logging
import sqlite3
from pathlib import Path

from ..compliance.models import ComplianceSpec

logger = logging.getLogger(__name__)


class ComplianceRegistrar:
    """Write ComplianceSpec rules to the guidance_fulfillment table.

    Each ComplianceRule becomes one guidance_fulfillment row with status 'pending'.
    Deduplicates against existing pending rows for the same session to avoid
    re-registering requirements on repeated routing calls.
    """

    def __init__(self, db_path: Path):
        self._db_path = db_path

    def register_requirements(
        self,
        spec: ComplianceSpec,
        session_id: str,
        routing_event_id: int | None = None,
    ) -> list[int]:
        """Insert one guidance_fulfillment row per ComplianceRule.

        Deduplicates against existing pending rows for this session — if a row
        with the same action_type and guidance_content already exists with
        status 'pending', it is skipped.

        Args:
            spec: ComplianceSpec with rules to register.
            session_id: Session identifier for scoping.
            routing_event_id: Optional routing_events.id for FK linkage.

        Returns:
            List of inserted row IDs (excludes deduplicated skips).
        """
        if not spec.has_rules:
            return []

        inserted_ids: list[int] = []

        conn = sqlite3.connect(str(self._db_path), timeout=10.0)
        try:
            for rule in spec.rules:
                action_type = rule.rule_type.value
                guidance_content = rule.description

                # Deduplicate: skip if identical pending row exists for session
                existing = conn.execute(
                    """
                    SELECT id FROM guidance_fulfillment
                    WHERE session_id = ?
                      AND action_type = ?
                      AND guidance_content = ?
                      AND fulfillment_status = 'pending'
                    """,
                    (session_id, action_type, guidance_content),
                ).fetchone()

                if existing:
                    logger.debug(
                        f"COMPLIANCE_DEDUP: skipping duplicate rule "
                        f"'{action_type}' for session {session_id[:16]}"
                    )
                    continue

                cursor = conn.execute(
                    """
                    INSERT INTO guidance_fulfillment (
                        guidance_event_id, guidance_type, guidance_content,
                        action_type, fulfillment_status, session_id
                    ) VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        routing_event_id,
                        "procedural",
                        guidance_content,
                        action_type,
                        "pending",
                        session_id,
                    ),
                )
                row_id = cursor.lastrowid or 0
                inserted_ids.append(row_id)
                logger.debug(
                    f"COMPLIANCE_REGISTERED: id={row_id} "
                    f"action_type={action_type} session={session_id[:16]}"
                )

            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

        return inserted_ids

    def get_pending_count(self, session_id: str) -> int:
        """Return the number of pending compliance requirements for a session."""
        conn = sqlite3.connect(str(self._db_path), timeout=10.0)
        try:
            row = conn.execute(
                """
                SELECT COUNT(*) FROM guidance_fulfillment
                WHERE session_id = ? AND fulfillment_status = 'pending'
                """,
                (session_id,),
            ).fetchone()
            return row[0] if row else 0
        finally:
            conn.close()
