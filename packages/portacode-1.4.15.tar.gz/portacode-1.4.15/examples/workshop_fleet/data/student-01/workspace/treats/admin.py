from django.contrib import admin

# Register your models here once you add them.
