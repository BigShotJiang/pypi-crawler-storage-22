VERSION = "7.8.1"

if __name__ == "__main__":
    print(VERSION, end="")  # noqa: T201
