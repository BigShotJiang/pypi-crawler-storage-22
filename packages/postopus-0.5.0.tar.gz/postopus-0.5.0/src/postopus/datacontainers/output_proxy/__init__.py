# Import the modules which implement proxy classes
# so they get registered at the OutputProxy base class.
from . import casida as casida
from . import field as field
from . import geometry as geometry
from . import profiling as profiling
from . import static as static
from . import sternheimer as sternheimer
from . import tdgeneral as tdgeneral
from . import textoutput as textoutput
from ._base import OutputProxy as OutputProxy
