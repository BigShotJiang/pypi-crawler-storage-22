from __future__ import annotations

import abc
from dataclasses import dataclass
from typing import TYPE_CHECKING

from postopus.datacontainers import calculationmode

if TYPE_CHECKING:
    from typing import Any

    from postopus.datacontainers.system import System
    from postopus.output_collector import OutputField


@dataclass(frozen=True)
class _OutputMappingKey:
    calculation_mode: str | None = None
    output_name: str | None = None


class OutputProxy(abc.ABC):
    """Base class to wrap outputs of Octopus.

    To access the data of an output the output proxy has to be called:

    >>> from pospotus import Run
    >>> run = Run("path/to/octopusdata")
    >>> convergence_data = run.scf.convergence()

    As the data provided by Octopus is very diverse the interface of the
    output proxy depends on the accessed output. E.g. for "density" (or any
    other output in the output_iter/ folder) calling the proxy requires the
    source as an additional parameter (``run.scf.density('.vtk')``)
    returning an instance of `xarray.DataArray`. An additional attribute
    `available_sources` (``run.scf.density.available_sources``) is
    provided in this case. Other outputs like "convergence" is callable
    without any additional parameters and provides a `pandas.Dataframe`.

    It is possible to define the interface for an output by subclassing
    the `OutputProxy`. One way is to define the interface for one specific
    output by defining either one (or both) of the attributes `__output__`
    or `__calc_mode__` (only specifying one of both acts as a wildcard).
    E.g. to define an own interface for the output 'convergence' of the
    'scf' calculation mode:

    >>> class ConvergenceProxy(OutputProxy):
    ...     __output__ = "convergence"
    ...     __calc_mode__ = "scf"
    ...     def __call__(self):
    ...         with open(self._available_files[0]) as f:
    ...             return f.readlines()

    To register a more generalized class, one has to define a ``_match`` method.
    This method should return true if for a given field the class is suitable
    and false if not. E.g. the ``_match`` method of the class which handles scalar
    and vector fields returns True for 'density' but False for 'info' or
    'convergence'.

    >>> class MyOutput(OutputProxy):
    ...     @classmethod
    ...     def _match(cls, output) -> bool:
    ...         return MyOwnIndexVariant() in output.other_index.keys():
    ...     def __call__(self):
    ...         ...

    Finding the correct class for an given output follows the rules:

    1. All classes defining either `__output__` or `__calc_mode__` (or both)
       are searched. Classes which define both have highest priority,
       classes defining only `__calc_mode__` the lowest. If for example
       class A defines `__output__ = 'foo'` and `__calc_mode__ = 'bar'`,
       class B defines only `__output__ = 'foo'` and not `__calc_mode__`
       the output 'foo' of calculation mode 'bar' will use class A instead of B.
       Defining a new class with the same value in `__output__` and `__calc_mode__`
       overwrites the previous class (i.e. overwriting proxies by inheritance works).
    2. If no class with a matching `__output__` / `__calc_mode__` attribute is found
       the classes defining the `_match` method are considered. The first class whose
       `_match` method return True is used as the output proxy.
       Note that classes which were defined first are searched first. This means
       that overwriting an existing `_match` method, e.g. by inheriting from another
       class is **not** possible as the base class will still be found first. This is
       intended to allow defining a class with a `_match` method to cover most basic
       cases of some kind of output and then refine this base class for special cases
       by inheriting from that base class and defining the `__output__` / `__calc_mode__`
       attribute.
    3. If no suitable class is found, `DefaultOutputProxy` will be used.
    """

    _output_class_map: dict[_OutputMappingKey, type[OutputProxy]] = dict()
    """Map of the output name/calculation mode and a class for that specific output
    (defined by the `__output__` and `__calc_mode__` attribute).
    """

    _default_classes: list[type[OutputProxy]] = list()
    """List of proxy classes which are used as a default for a subset
    of outputs (defined by the `_match` method of such a class).
    """

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        # Check if the class is implemented for a specific calculation mode / output.
        calc_mode = None
        if hasattr(cls, "__calc_mode__"):
            calc_mode = cls.__calc_mode__

        output = None
        if hasattr(cls, "__output__"):
            output = cls.__output__

        if output or calc_mode:
            cls._output_class_map[_OutputMappingKey(calc_mode, output)] = cls
        # Check if the class is intended as default proxy for a range of fields.
        # This is decided by the `_match` method which should return True if the
        # class can be used as a proxy for a given OutputField.
        # We only check this for classes which do not provide `__output__` or `__calc_mode__`
        # to avoid weird behavior when inheriting from a default proxy for some specific output.
        elif hasattr(cls, "_match"):
            cls._default_classes.append(cls)

    def __new__(
        cls,
        parent: calculationmode.CalculationMode | System,
        output_field: OutputField,
    ) -> OutputProxy:
        load_cls = DefaultOutputProxy

        # Check if any dedicated class exists for that field based on calc mode and output name.
        # Note that there are outputs which are not associated to any calculation mode, e.g. the geometry (.xzy files).
        calc_mode_name = None
        if isinstance(parent, calculationmode.CalculationMode):
            calc_mode_name = parent._mode
        output_name = output_field.field

        load_cls = (
            cls._output_class_map.get(_OutputMappingKey(calc_mode_name, output_name))
            or cls._output_class_map.get(_OutputMappingKey(None, output_name))
            or cls._output_class_map.get(_OutputMappingKey(calc_mode_name, None))
            or None
        )

        # Check which of the default proxy classes can be used otherwise.
        if load_cls is None:
            for default_cls in cls._default_classes:
                if default_cls._match(output_field):
                    load_cls = default_cls
                    break

        return abc.ABC.__new__(load_cls or DefaultOutputProxy)

    def __init__(
        self,
        parent: calculationmode.CalculationMode | System,
        output_field: OutputField,
    ):
        self._parent = parent
        self._output_field = output_field

        self.__post_init__()

    def __post_init__(self):
        """Gets called at the end of __init__. Prefered place to
        initialize subclass specefic attributes.
        """

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name={self._output_field.field!r})"

    @abc.abstractmethod
    def __call__(self) -> Any:
        """Return the data provided by the files of the output."""


class DefaultOutputProxy(OutputProxy):
    """Default output proxy if we have no further information about the given files"""

    def __repr__(self) -> str:
        files = self._output_field.get_any_field_files()
        anyfile = next(iter(files))
        return (
            f"Proxy to files like {anyfile}. This kind of file seems unknown "
            "to postopus and no further specialised reading can be provided."
        )

    def __call__(self) -> None:
        raise NotImplementedError("Unknown file type.")
