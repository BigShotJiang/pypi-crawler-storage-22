from __future__ import annotations

import typing

import pandas as pd

from postopus.datacontainers.util.convenience_access import ConvenienceAccess
from postopus.files import PandasTextFile

from ._base import OutputProxy

if typing.TYPE_CHECKING:
    from collections.abc import Iterator


class _SpectrumBySuffix:
    def __init__(self, file: PandasTextFile):
        self._file = file

    def __repr__(self) -> str:
        return f"Spectrum({self._file.filepath})"

    def __call__(self) -> pd.DataFrame:
        df = self._file.values
        df.attrs = self._file.attrs
        return df


class CasidaSpectrum(OutputProxy, ConvenienceAccess):
    """Proxy for files 'casida/spectrum.casida', 'casida/spectrum.eps_diff' and 'casida/spectrum.petersilka'.

    Calling the proxy will return the data from all sources combined as a dataframe.
    The proxy also provides the different sources as attributes (via `ConvenienceAccess`),
    e.g. `run.casida.spectrum.petersilka()` will return the content of the file 'casida/spectrum.petersilka'.
    """

    __calc_mode__ = "casida"
    __output__ = "spectrum"

    __dict_name__ = "_files_by_suffix"

    def __post_init__(self):
        self._files_by_suffix = {}

        for filepath in self._output_field.files:
            file = PandasTextFile(filepath)
            self._files_by_suffix[filepath.suffix.lstrip(".")] = _SpectrumBySuffix(file)

    def __repr__(self) -> str:
        return "\n".join(self._repr_gen())

    def _repr_gen(self) -> Iterator[str]:
        yield f"{self.__class__.__name__}():"

        yield "Available files:"
        for name in sorted(filepath.name for filepath in self._output_field.files):
            yield f"    {name!r}"

    def __call__(self) -> pd.DataFrame:
        dfs = {
            proxy._file.filepath.name: proxy()
            for proxy in self._files_by_suffix.values()
        }
        df = pd.concat(dfs, names=["file"])
        return df
