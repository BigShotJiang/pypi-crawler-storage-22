from __future__ import annotations

import typing

import pandas as pd

from postopus.datacontainers.util.convenience_access import ConvenienceAccess
from postopus.files import XYZFile

from ._base import OutputProxy

if typing.TYPE_CHECKING:
    from collections.abc import Iterator


class _XYZFileWrapper:
    def __init__(self, file: XYZFile):
        self._file = file

    def __call__(self) -> pd.DataFrame:
        return self._file.as_pandas()

    def __repr__(self) -> str:
        return f"XYZFile({self._file._filepath})"


class GeometryFiles(OutputProxy, ConvenienceAccess):
    __output__ = "geometry"

    __dict_name__ = "_xyz_file_wrappers"

    def __post_init__(self):
        self._xyz_files = {}
        self._xyz_file_wrappers = {}

        for file in self._output_field.files:
            xyz_file = XYZFile(file)
            self._xyz_files[file.name] = xyz_file
            self._xyz_file_wrappers[file.stem] = _XYZFileWrapper(xyz_file)

    def __call__(self) -> pd.DataFrame:
        dfs = {name: file.as_pandas() for name, file in self._xyz_files.items()}
        df = pd.concat(dfs, names=["file"])
        return df

    def __repr__(self) -> str:
        return "\n".join(self._repr_gen())

    def _repr_gen(self) -> Iterator[str]:
        yield f"{self.__class__.__name__}():"

        yield "Available xyz files:"
        for name in sorted(self._xyz_files.keys()):
            yield f"    {name!r}"
