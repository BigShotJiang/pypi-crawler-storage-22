from __future__ import annotations

import re
import warnings
from typing import TYPE_CHECKING

from postopus.files import PandasTextFile
from postopus.utils import NUMERICAL_CONST_PATTERN

from ._base import OutputProxy

if TYPE_CHECKING:
    import pandas as pd

    from postopus.output_collector import OutputField


class StaticOutput(OutputProxy):
    """Proxy for outputs in run/static like `info`, `convergence`, etc."""

    @classmethod
    def _match(self, output: OutputField) -> bool:
        return output.is_static()

    def __post_init__(self):
        self._available_files = list(self._output_field.files)
        self._file = PandasTextFile(self._available_files[0])

    def __call__(self) -> pd.DataFrame:
        """Load table-structured data from the output and provide it as
        data frame. The meta data in the header of the output file is also
        provided in `.attrs` of the returned data frame.
        """

        if len(self._available_files) > 1:
            warnings.warn(
                "There is more than one file found for the output which is unexpected."
                f" All files other than {self._available_files[0]} will be ignored"
            )

        # Rely on (lazy loaded) file reader implementation.
        df = self._file.values
        # Update attributes
        df.attrs = self._file.attrs

        return df


class Info(StaticOutput):
    """Proxy class specific for the info file"""

    __output__ = "info"

    def __call__(self) -> list:
        """Return the content of the info file as list of its lines."""
        return self._file.values

    def as_text(self) -> str:
        return "".join(self._file.values)

    def as_lines(self) -> list[str]:
        return self._file.values

    def find_one_or_none(self, patterns: str | list[str]) -> str | None:
        if not isinstance(patterns, list):
            patterns = [patterns]
        matches = set()
        for pattern in patterns:
            for match in re.findall(pattern, self.as_text(), re.M):
                matches.add(match)
        if len(matches) > 1:
            raise ValueError(f"Multiple results found in the info file (`{matches}`).")

        if len(matches) == 0:
            return None
        (result,) = matches
        return result

    def get_total_energy(self) -> float | None:
        patterns = [
            rf"Energy.*\n.*Total.*=\s+({NUMERICAL_CONST_PATTERN})",
            rf"Total Energy \[H\]:\s+({NUMERICAL_CONST_PATTERN})",
        ]
        total_energy = self.find_one_or_none(patterns)
        if total_energy is None:
            return None
        return float(total_energy)

    def get_scf_iteration_count(self) -> int | None:
        expr = r"SCF +converged +in +(\d+) +iterations"
        iterations = self.find_one_or_none(expr)
        if iterations is None:
            return None
        return int(iterations)

    def scf_is_converged(self) -> bool:
        return self.get_scf_iteration_count() is not None

    def get_eigenvalues(self) -> pd.DataFrame:
        # Recycle the reading routine for the file eigenvalues
        file = PandasTextFile(self._available_files[0])
        file._read_eigenvalues_file()
        return file._values
