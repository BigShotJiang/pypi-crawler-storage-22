from __future__ import annotations

import re
import warnings

import pandas as pd

from postopus.files import PandasTextFile
from postopus.utils import NUMERICAL_CONST_PATTERN

from ._base import OutputProxy


class SternheimerCrossSection(OutputProxy):
    """Provide access to files 'em_resp/freq_1.2345/cross_section' over all frequencies."""

    __calc_mode__ = "em_resp"
    __output__ = "cross_section"

    def __post_init__(self):
        self._dfs_per_freq = None

    def __call__(self) -> pd.DataFrame:
        if self._dfs_per_freq is None:
            df_per_freq = {}
            for freq, output in self._output_field.iterations.items():
                if len(output.files) != 1:
                    warnings.warn(
                        "There is more than one file found for the output which is unexpected."
                        f" All files other than {self._available_files[0]} for the frequency {freq} "
                        "will be ignored."
                    )

                file = next(iter(output.files))
                pd_file = PandasTextFile(file)
                df_per_freq[freq] = pd_file.values

        return pd.concat(df_per_freq, names=["freq"])


class SternheimerAlpha(OutputProxy):
    """Extract the Isotropic average from files 'em_resp/freq_1.2345/alpha' over all frequencies."""

    __calc_mode__ = "em_resp"
    __output__ = "alpha"

    def __post_init__(self):
        self._isotropic_avg_df = None

    def __call__(self) -> pd.DataFrame:
        if self._isotropic_avg_df is None:
            # The file contains a polarizability tensor (3x3 matrix)
            # and an additional line "Isotropic average    1.23456".
            # For now only provide the isotropic avg
            # (this is the value of interest in the tutorials).
            isotropic_avg_per_freq = {}
            for freq, output in self._output_field.iterations.items():
                if len(output.files) != 1:
                    warnings.warn(
                        "There is more than one file found for the output which is unexpected."
                        f" All files other than {self._available_files[0]} for the frequency {freq} "
                        "will be ignored."
                    )
                file = next(iter(output.files))
                text = file.read_text()
                result = re.search(
                    rf"Isotropic average\s+({NUMERICAL_CONST_PATTERN})", text
                )
                if not result:
                    warnings.warn(
                        f"Failed to extract the isotropic average from file {file}."
                    )
                    result = "NaN"
                isotropic_avg_per_freq[freq] = float(result.group(1))

            self._isotropic_avg_df = pd.DataFrame.from_dict(
                isotropic_avg_per_freq, orient="index", columns=["Isotropic average"]
            )
            self._isotropic_avg_df.index.name = "freq"
        return self._isotropic_avg_df
