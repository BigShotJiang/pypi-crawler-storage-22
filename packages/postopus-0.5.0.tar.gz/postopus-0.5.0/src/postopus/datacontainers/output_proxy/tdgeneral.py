from __future__ import annotations

import warnings
from collections import namedtuple
from typing import TYPE_CHECKING

import pandas as pd

from postopus.files import PandasTextFile
from postopus.output_collector import VectorDimension

from ._base import OutputProxy

if TYPE_CHECKING:
    from postopus.output_collector import OutputField


class TDGeneralVectorField(OutputProxy):
    """Proxy for files in `run/td.general` that provide data for multiple dimensions.

    Some information in td.general are splitted into multiple files, one per dimension
    e.g. the files `total_e_field_x`, `total_e_field_y` and `total_e_field_z`.
    This output proxy provides those files as single output, e.g. as `total_e_field`.
    """

    @classmethod
    def _match(cls, output_field: OutputField) -> bool:
        """The output field is consider a td.general vectorfield
        if the output provides only vector dimensions in the other_index
        and after that static files (no nested other_index, no iterations).
        """
        if not output_field.has_other_index():
            return False
        if not output_field.other_index.keys() <= {VectorDimension(d) for d in "xyz"}:
            return False

        return output_field.other_index.get_any().is_static()

    _GeneralVectorField = namedtuple("GeneralVectorField", ["x", "y", "z"])

    def __call__(self) -> _GeneralVectorField:
        """Load the data of each provided vector component as data frame and
        return those as a combined named tuple. The components are accessable
        using `output().x`, `output().y` and `output().z`.
        """

        data = list()
        for dim in "xyz":
            files = list(self._output_field.other_index[VectorDimension(dim)].files)
            if len(files) > 1:
                warnings.warn(
                    "There is more than one file found for the output which is unexpected."
                    f" All files other than {files[0]} will be ignored"
                )

            file = PandasTextFile(files[0])
            values = file.values
            values.attrs = file.attrs
            data.append(values)
        return self._GeneralVectorField(*data)


class Multipoles(OutputProxy):
    __output__ = "multipoles"

    def __post_init__(self):
        self._available_files = [
            PandasTextFile(file) for file in list(self._output_field.files)
        ]

    def __call__(self) -> pd.DataFrame:
        # Following https://octopus-code.org/documentation/16/tutorial/response/optical_spectra_from_time-propagation/
        # we might encounter not only the file 'multipoles' but 'multipoles.1', 'multipoles.2', 'multipoles.3'.
        # If this is the case provide them as combined data frame.
        files = list(self._output_field.files)
        data = {}
        for pd_file in self._available_files:
            df = pd_file.values
            df.attrs = pd_file.attrs
            name = pd_file.filepath.name.split(".")[-1]
            data[name] = df

        if len(files) == 1:
            return list(data.values())[0]

        # Sort dictionary to have a reasonable order in the created data frame.
        data = dict(sorted(data.items()))
        return pd.concat(data, names=["Direction"])


class CrossSectionVector(Multipoles):
    __output__ = "cross_section_vector"
