from __future__ import annotations

import abc
import re
import typing

if typing.TYPE_CHECKING:
    from pathlib import Path


class TextOutput(abc.ABC):
    """Wrapper for files containing plain text such as log output, providing
    some utilities to search that output.
    """

    _file: list[Path]
    _data: str | None

    def __init__(self, file: Path):
        self._file = file
        self._data = None

    def __call__(self) -> str:
        return self.as_text()

    def as_text(self) -> str:
        if self._data is None:
            # `errors=replace` as Octopus output sometimes has weird characters in it.
            self._data = self._file.read_text(errors="replace")

        return self._data

    def as_lines(self) -> list[str]:
        return self.as_text().split("\n")

    def find_one_or_none(self, expr: str) -> str | None:
        lines = re.findall(expr, self.as_text(), re.M)
        if len(lines) > 1:
            raise ValueError(
                f"Multiple lines in the output match the expression `{expr}`."
            )

        if len(lines) == 0:
            return None
        return lines[0]

    def find_all(self, expr: str) -> list[str]:
        return re.findall(expr, self.as_text(), re.M)

    def grepfield(self, pattern: str, column: int | None = None) -> str | None:
        matches = [line for line in self.as_lines() if pattern in line]
        if len(matches) > 1:
            raise ValueError(f"Multiple lines matches the pattern `{pattern}`")
        if len(matches) == 0:
            return None
        match = matches[0]
        columns = match.split()
        if column is None:
            return columns
        if column > len(columns):
            raise IndexError(
                f"Column {column} out of range (only {len(columns)} columns found)"
            )
        return columns[column]


def open_textfile(file: Path) -> TextOutput:
    return TextOutput(file)
