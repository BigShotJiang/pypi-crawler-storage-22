from __future__ import annotations

from typing import TYPE_CHECKING

from postopus.datacontainers.calculationmode import CalculationMode
from postopus.datacontainers.output_proxy import OutputProxy
from postopus.datacontainers.util.convenience_access import ConvenienceAccess
from postopus.output_collector.collector import DUMMY_CALC_MODE_NAME

if TYPE_CHECKING:
    from collections.abc import Iterator
    from pathlib import Path

    from postopus import Run
    from postopus.datacontainers.util.output_collector import (
        System as OutputCollectorSystem,
    )


class System(ConvenienceAccess):
    """
    The `System` class provides a dict with all found calculation modes written for the
    system.

    Parameters
    ----------
    systemname
        Name of this system
    rootpath
        Path to the Octopus output (not system folder)
    mode_field_info
        Calculation modes including the outputs of each calculation mode.
    """

    # Set name of dict in ConvenienceAccess
    __dict_name__ = ["_calculation_modes", "_outputs"]

    def __init__(
        self,
        system_name: str,
        rootpath: Path,
        mode_field_info: OutputCollectorSystem,
        parent: Run,
    ) -> None:
        self.system_name = system_name
        self._rootpath = rootpath
        self._mode_field_info = mode_field_info
        self._parent = parent

        self._outputs = {}
        self._calculation_modes = {}

        dummy_calc_mode = mode_field_info.pop(DUMMY_CALC_MODE_NAME, None)
        if dummy_calc_mode:
            for output_name, output in dummy_calc_mode.items():
                output = OutputProxy(self, output)
                self._outputs[output_name] = output

        for m in mode_field_info.keys():
            # self.modes is available through ConvenienceAccess
            self._calculation_modes[m] = CalculationMode(
                m,
                mode_field_info[m],
                self,
                self._rootpath,
                self.system_name,
            )

    def __repr__(self) -> str:
        return "\n".join(self._repr_gen())

    def _repr_gen(self) -> Iterator[str]:
        yield f"{self.__class__.__name__}(name={self.system_name!r}, rootpath='{self._rootpath!s}'):"

        modes = sorted(self._calculation_modes.keys())
        if len(modes) == 0:
            yield "No data related to any calculation modes found!"
        else:
            yield "Found calculation modes:"
            for mode in sorted(modes):
                yield f"    {mode!r}"

        if len(self._outputs):
            yield "Outputs:"
            for output in sorted(self._outputs.keys()):
                yield f"    {output!r}"


class MultiSystem(ConvenienceAccess):
    __dict_name__ = "_sub_systems"

    def __init__(self, system_name, sub_systems: dict[str, System | MultiSystem]):
        self.system_name = system_name
        self._sub_systems = sub_systems

    def __repr__(self) -> str:
        return "\n".join(self._repr_gen())

    def _repr_gen(self) -> Iterator[str]:
        yield f"{self.__class__.__name__}(name={self.system_name!r}):"

        yield "Sub-Systems:"
        for sub_system in sorted(self._sub_systems.keys()):
            yield f"    {sub_system!r}"
