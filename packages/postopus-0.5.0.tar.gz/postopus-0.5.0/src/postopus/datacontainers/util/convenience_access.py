from collections.abc import Mapping


class ConvenienceAccess:
    """
    Base class with convenience access to a dictionary

    Inheriting from this class allows access to all entries of the specified dictionaries
    as properties (i.e. by dot-notation).
    The name of this special dictionaries must be set by providing the attribute '__dict_name__'.

    Example:

    >>> class Example(ConvenienceAccess):
    >>>     __dict_name__ = 'foo'
    >>>     def __init__(self):
    >>>         self.foo = {'a': 1, 'b': 2}
    >>> print(e.a, e.b)
    1 2
    >>> e.foo['x'] = 4
    >>> print(e.x)
    4

    Using multiple dictionaries works as follows:
    >>> class Example(ConvenienceAccess):
    >>>     __dict_name__ = ['foo', 'bar']
    >>>     def __init__(self):
    >>>         self.foo = {'a': 1, 'b': 2}
    >>>         self.bar = {'b': 'asdf', 'c': 'haei'}
    >>> e = Example()
    >>> print(e.a, e.b, e.c)
    1 2 haei
    """

    __dict_name__: list[str] | str

    def __init_subclass__(cls):
        if not hasattr(cls, "__dict_name__"):
            raise AttributeError("Attribute '__dict_name__' not set.")
        if not isinstance(cls.__dict_name__, (str, list)):
            raise TypeError(
                "Attribute '__dict_name__' must either be a string or a list of strings."
            )

    @staticmethod
    def _assure_is_dict(name, maybe_dict):
        if not isinstance(maybe_dict, Mapping):
            raise RuntimeError(
                f"Expected '{name}' to be a dict, got {type(maybe_dict)} instead."
            )

    def _get_convenient_dict(self):
        name_or_names = self.__class__.__dict_name__
        if isinstance(name_or_names, str):
            data = self.__getattribute__(name_or_names)
            self._assure_is_dict(name_or_names, data)
            return data

        data_combined = {}
        for name in reversed(name_or_names):
            data = self.__getattribute__(name)
            self._assure_is_dict(name, data)
            data_combined |= data
        return data_combined

    def __getattr__(self, name):
        if name in (data := self._get_convenient_dict()):
            return data[name]

        return super().__getattribute__(name)

    def __dir__(self):
        return super().__dir__() + list(self._get_convenient_dict().keys())
