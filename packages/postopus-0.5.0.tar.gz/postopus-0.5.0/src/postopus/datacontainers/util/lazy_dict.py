from collections.abc import Callable, Mapping
from typing import TypeVar

K = TypeVar("K")
V = TypeVar("V")


class LazyDict(Mapping[K, V]):
    def __init__(self, items: dict[K, Callable[[], V]]):
        self._items = items
        self._loaded_items: dict[K, V] = {}

    def __getitem__(self, key: K) -> V:
        if key not in self._loaded_items:
            item_getter = self._items[key]
            item = item_getter()
            self._loaded_items[key] = item

        return self._loaded_items[key]

    def __iter__(self):
        return iter(self._items)

    def __len__(self):
        return len(self._items)
