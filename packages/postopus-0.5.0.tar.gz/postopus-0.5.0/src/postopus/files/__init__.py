"""
Implementation of several file readers for the different output formats.
"""

# Import all submodules so the file readers register themselves at the base class
from .cube import CubeFile as CubeFile
from .file import File as File
from .netcdf import NetCDFFile as NetCDFFile
from .pandas_text import PandasTextFile as PandasTextFile
from .text import TextFile as TextFile
from .vtk import VTKFile as VTKFile
from .xcrysden import XCrySDenFile as XCrySDenFile
from .xyz import XYZFile as XYZFile
