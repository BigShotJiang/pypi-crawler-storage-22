from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from pathlib import Path

    import numpy as np


logger = logging.getLogger(__name__)


# Sentinel for lazy loading
class _UNINITIALIZED_SENTINEL:
    pass


_UNINITIALIZED = _UNINITIALIZED_SENTINEL()


def _is_uninitialized(v) -> bool:
    # we have to use `isinstance` here instead of a simple `v is _UNINITIALIZED`
    # because the file objects are copied via the copy module
    # which creates new instances of the sentinel...
    return isinstance(v, _UNINITIALIZED_SENTINEL)


class File(ABC):
    """Load the content of a file as a multidimensional array."""

    extension_loader_map: dict[str, type[File]] = dict()
    """Mapping of an extension to a subclass of `File` which is able to load that file.
    E.g. `File.extension_loader_map[".vtk"]` will yield `VTKFile` which is capable of reading a `.vtk` file.

    Note that this mapping is created automatically by the `__init_subclass__` magic when a subclass is defined.
    Therefore the subclass must set the attribute `EXTENSIONS`, such as

    .. code-block:: python

        class VTKFile(File):
            EXTENSIONS = {".vtk"}
            ...
    """

    EXTENSIONS: set[str] = set()
    """Describe, what extensions the defined class can load (see also `extension_loader_map`).
    Must be set while defining the class (`VTKFile.EXTENSIONS.add('.foo')` won't have any effect).
    Note that, when subclassing a reader and not overwriting that attribute one will overwrite
    the base class. E.g. with `class NewVTKFile(VTKFile): ...` one can overwrite the reading routine
    for a `.vtk` file (i.e. `File.extension_loader_map[".vtk"]` will yield `NewVTKFile` instead of `VTKFile`).
    Setting `EXTENSIONS` to an empty set is allowed (e.g. to define a base class).
    """

    def __new__(cls, filepath: Path | None = None, *args, **kwargs):
        """
        If a file object is constructed using the base class (`File("myfile.ext")`)
        return an instance of a subclass which is capable of loading
        the corresponding extension (e.g. `File("current.vtk")` will return an
        instance of `VTKFile`). If on the other hand one of the subclasses
        is used explicitly do not overwrite this class (e.g. `VTKFile("myfile.ext")`
        should return an instance of `VTKFile` in any case).
        """
        # Note that the parameter `filepath` is optional as otherwise `copy.copy` breaks
        # (We need to support `copy` as objects of this class are stored in xarray metadata
        # which is copied across arrays via the copy module).
        if filepath is None:
            return super().__new__(cls)

        # Only overwrite `cls` if the base class `File` is used for initialization.
        if cls is File:
            extension = filepath.suffix
            if extension not in cls.extension_loader_map:
                raise NotImplementedError(f"Unknown file extension {extension}")
            cls = cls.extension_loader_map[extension]
        return super().__new__(cls)

    def __init_subclass__(cls, /, **kwargs):
        super().__init_subclass__(**kwargs)
        for extension in cls.EXTENSIONS:
            if extension in cls.extension_loader_map:
                logger.warning(
                    f"Overwriting the loader {cls.extension_loader_map[extension]} "
                    f"for extension {extension!r} with the loader {cls}."
                )
            cls.extension_loader_map[extension] = cls

    def __init__(self, filepath: Path):
        self.filepath = filepath
        self._coords = _UNINITIALIZED
        self._values = _UNINITIALIZED
        self._units = _UNINITIALIZED
        self._dims = _UNINITIALIZED

    @property
    def values(self) -> np.array:
        """
        Values of the file as numpy array
        of shape `(len(self.coords[dim]) for dim in self.dims)`
        """
        if _is_uninitialized(self._values):
            self._load()
        return self._values

    @property
    def dims(self) -> list[str]:
        """
        Dimensions of the data, analogous to xarray.Dataset.dims.
        """
        if _is_uninitialized(self._dims):
            self._load()
        return self._dims

    @property
    def coords(self) -> dict[str, list[Any]]:
        """
        Coordinates of the data, analogous to xarray.Dataset.coords

        Returns
        -------
        dict
            existing coordinate points per dimension

        """
        if _is_uninitialized(self._coords):
            self._load()
        return self._coords

    @property
    def units(self) -> Literal["au" | "eV_Ångstrom"] | None:
        """
        Units of the data, e.g. "au" (atomic units).
        """
        if _is_uninitialized(self._units):
            self._load()
        return self._units

    def _load(self):
        self._readfile()

        # Assure the implementation loaded all attributes properly.
        if _is_uninitialized(self._values):
            raise RuntimeError(
                f"Implementation of `{type(self).__qualname__}._readfile` did not provide `._values`"
            )
        if _is_uninitialized(self._dims):
            raise RuntimeError(
                f"Implementation of `{type(self).__qualname__}._readfile` did not provide `._dims`"
            )
        if _is_uninitialized(self._coords):
            raise RuntimeError(
                f"Implementation of `{type(self).__qualname__}._readfile` did not provide `._coords`"
            )

        # Providing units is optional.
        if _is_uninitialized(self._units):
            self._units = None

    @abstractmethod
    def _readfile(self):
        """
        Method to be implemented in derived classes which is specific to the file
        type we read.
        When called, the method must populate the attributes
        - self._values
        - self._dims
        - self._coords
        and optionally provide:
        - self._units
        """
