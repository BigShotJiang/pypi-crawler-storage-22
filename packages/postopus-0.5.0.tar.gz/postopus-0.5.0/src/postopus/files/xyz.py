from io import StringIO
from pathlib import Path

import pandas as pd

_UNINITIALIZED = object()


class XYZFile:
    """
    Enable Postopus to read XYZ data, as written by Octopus.
    https://openbabel.org/wiki/XYZ_%28format%29
    To write XYZ output, set `OutputFormat = xyz` in the inp file.
    (Trusting the Octopus documentation this only affects the geometry output
    so adding `geometry` to the `Output` block is also required.)
    """

    EXTENSIONS = [".xyz"]

    def __init__(self, filepath: Path):
        self._filepath = filepath
        self._pandasdata = _UNINITIALIZED
        self._numpydata = _UNINITIALIZED

    def as_numpy(self):
        if self._numpydata is _UNINITIALIZED:
            self._numpydata = self.as_pandas().to_numpy()

        return self._numpydata

    def as_pandas(self) -> pd.DataFrame:
        if self._pandasdata is _UNINITIALIZED:
            self._read_data()

        return self._pandasdata

    def _read_data(self) -> None:
        # Officially the file format is
        """
        <number of atoms>
        comment line
        <element> <X> <Y> <Z>
        ...
        """
        # but it often occurs that some extra empty lines
        # appear at the beginning, e.g. when using the %%writefile magic.
        with open(self._filepath) as f:
            lines = f.readlines()
            for i, line in enumerate(lines):
                if line.strip():
                    break
            lines = lines[i:]

        data = StringIO("".join(lines))
        self._pandasdata = pd.read_table(
            data,
            skiprows=2,
            names=("Atom", "x", "y", "z"),
            sep=r"\s+",
        )
