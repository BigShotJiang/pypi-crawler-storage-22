"""
Top level module acting as the only class the user interfaces with directly.

Classes:
    Run: Initialization point for Postopus which triggers all data collection and allows
    to access the found data in a unified way.

Examples can be found in the "examples" directory.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from postopus.datacontainers.system import MultiSystem, System
from postopus.datacontainers.util.convenience_access import ConvenienceAccess
from postopus.output_collector import LEGACY_SYSTEM_NAME, OutputCollector

if TYPE_CHECKING:
    from collections.abc import Iterator

    from postopus.datacontainers.calculation_mode import CalculationMode
    from postopus.datacontainers.output_proxy import OutputProxy


class Run(ConvenienceAccess):
    """
    Starting point for users of Postopus.

    Root object for Postopus, initializing the module and providing access to all
    data and functions.
    """

    # Set lookup for ConvenienceAccess
    __dict_name__ = ["_systems", "_calculation_modes", "_outputs"]

    def __init__(self, basedir: Path | str = Path(".")) -> None:
        """
        Entrypoint for the user to initialize the Postopus module.

        Given a path, the collection of all Octopus data below this directory is
        triggered and a dedicated datastructure is build.
        By using the given data structure, data to access can be selected by the user.

        Parameters
        ----------
        basedir
            directory where the results can be found (directory has to contain inp file)

        """
        # Convert basedir to an absolute path and do some basic validations (path is directory, inp file exists)
        self.rootpath = self._check_provided_path(basedir)

        # Collect output from filesystem
        output_from_fs = OutputCollector(self.rootpath)

        # Provide discovered systems
        self._systems: dict[str, System] = {}
        system_names = output_from_fs.output.keys()
        # Nested multisystems are separated via dots, e.g. as self._systems["SolarSystem.Earth"]
        # but we want to provide them as nested structure, such as self._systems["SolarSystem"]["Earth"]
        # (which then translates to 'run.SolarSystem.Earth' via the ConvenienceAccess).
        # For this to work properly we first need to nest the leafs (thinking in a tree-structure).
        # E.g. assume we have systems 'root', 'root.child' and 'root.child.grandchild', then we want to
        # encounter 'root.child.grandchild' first (that way we know that 'root.child' is a nested system
        # and not a system by its own).
        system_names = sorted(
            system_names, key=lambda name: name.count("."), reverse=True
        )

        for system_name in system_names:
            if system_name in self._systems:
                continue

            target = self._systems
            parents = system_name.split(".")
            child_name = parents.pop(-1)
            for parent in parents:
                target = target.setdefault(parent, {})
            target[child_name] = System(
                system_name,
                self.rootpath,
                output_from_fs.output[system_name],
                parent=self,
            )

        # For multisystems we just created a dict but we want an instances of `MultiSystem`
        _convert_nested_dicts_to_multisystem(self._systems)

        # The output collector will assign outputs which do not belong to a system to a special system.
        # These outputs should be directly available via the run object.

        # For multisystems we provide the data as run.sys_name[.nested_sysname].cal_mode.output_name,
        # E.g. run.SolarSystem.Earth.td.energy (https://octopus-code.org/documentation/main/tutorial/multisystem/solar_system/).
        # In a single-system run there is nothing like a system name. The data should be accessible as 'run.td.energy'.
        self._calculation_modes: dict[str, CalculationMode] = {}
        self._outputs: dict[str, OutputProxy] = {}
        self._legacy_system = None
        if LEGACY_SYSTEM_NAME in self._systems:
            self._legacy_system = self._systems.pop(LEGACY_SYSTEM_NAME)
            self._calculation_modes = self._legacy_system._calculation_modes
            self._outputs = self._legacy_system._outputs

    @property
    def default(self):
        # In earlier Postopus versions a system called 'default' was provided if no multisystems are used, e.g. `run.default.td.energy()`.
        # Providing `.default` is redundant, the data access was reduced to `run.td.energy()`.
        # We keep this property for backwards compatibility. See also https://gitlab.com/octopus-code/postopus/-/issues/130
        return self._legacy_system

    def __dir__(self) -> list[str]:
        # Hide deprecated default system
        props = super().__dir__()
        props.remove("default")
        return props

    def __repr__(self) -> str:
        return "\n".join(self._repr_gen())

    def _repr_gen(self) -> Iterator[str]:
        yield f"{self.__class__.__name__}('{self.rootpath!s}'):"

        if len(self._systems) > 0:
            yield "Found systems:"
            for system_name in sorted(self._systems.keys()):
                yield f"    {system_name!r}"

        modes = (
            set(_fetch_calculation_modes(self._systems.values()))
            | self._calculation_modes.keys()
        )
        if len(modes) == 0:
            yield "No data related to any calculation modes found!"
        else:
            yield "Found calculation modes:"
            for mode in sorted(modes):
                yield f"    {mode!r}"

        if len(self._outputs):
            yield "Outputs:"
            for output in sorted(self._outputs.keys()):
                yield f"    {output!r}"

    def __truediv__(self, subdir: str) -> Path:
        return self.rootpath / subdir

    def _check_provided_path(self, path: Path | str) -> Path:
        """
        Check if the provided path is valid

        Parameters
        ----------
        path : Path
            path/to/Octopus/output/with/inp

        """
        path = Path(path)
        if path.is_file():
            # Path to an 'inp' file was provided. Open it and read config
            raise NotADirectoryError(
                "Please provide the path to the directory containing the 'inp' file!"
            )
        elif not (path / "inp").is_file():
            # Abort, no 'inp' file found
            raise FileNotFoundError("'inp' file missing - aborting!")
        return path.absolute()


def _convert_nested_dicts_to_multisystem(systems: dict):
    for system_name, system in systems.items():
        if isinstance(system, dict):
            # Convert nested multisystems as well
            _convert_nested_dicts_to_multisystem(system)

            # Convert the system itself
            systems[system_name] = MultiSystem(system_name, system)


def _fetch_calculation_modes(systems: list[System | MultiSystem]):
    for system_or_multisystem in systems:
        if isinstance(system_or_multisystem, System):
            yield from system_or_multisystem._calculation_modes.keys()
        elif isinstance(system_or_multisystem, MultiSystem):
            yield from _fetch_calculation_modes(
                system_or_multisystem._sub_systems.values()
            )
        else:
            assert False
