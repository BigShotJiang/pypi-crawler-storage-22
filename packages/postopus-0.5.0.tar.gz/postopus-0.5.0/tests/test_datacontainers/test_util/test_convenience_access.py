import pytest
from tests.utils import dir_no_special

from postopus.datacontainers.util.convenience_access import ConvenienceAccess


def test_convenience_dict_access():
    class Example1(ConvenienceAccess):
        __dict_name__ = "foo"

        def __init__(self):
            self.foo = {"a": 1, "b": 2}

    example1 = Example1()

    class Example2(ConvenienceAccess):
        __dict_name__ = ["foo", "bar"]

        def __init__(self):
            self.foo = {"a": 1, "b": 2}
            self.bar = {"b": "asdf", "c": "haei"}

    example2 = Example2()

    # Test attribute access
    assert example1.a == 1
    assert example1.b == 2

    assert example2.a == 1
    assert example2.b == 2
    assert example2.c == "haei"

    # Non-existent attribute
    with pytest.raises(AttributeError):
        example1.d

    with pytest.raises(AttributeError):
        example2.d

    # Test completion via dir method
    assert dir_no_special(example1) == {"a", "b", "foo"}
    assert dir_no_special(example2) == {"a", "b", "c", "foo", "bar"}

    # Test access after update
    example1.foo["d"] = 17
    assert example1.d == 17

    example2.bar = {"d": 19}
    assert example2.d == 19

    # Check for meaningful error messages when the developer does nonsense
    example1.foo = 3.14
    with pytest.raises(RuntimeError, match="Expected 'foo' to be a dict"):
        example1.abc

    example2.bar = [1, 2, 3]
    with pytest.raises(RuntimeError, match="Expected 'bar' to be a dict"):
        example2.a

    # 'Real' object attributes should be preferred over the convenience access.
    class Example3(ConvenienceAccess):
        __dict_name__ = "foo"

        def __init__(self):
            self.a = 1
            self.foo = {"a": 2}

    example3 = Example3()
    assert example3.a == 1
