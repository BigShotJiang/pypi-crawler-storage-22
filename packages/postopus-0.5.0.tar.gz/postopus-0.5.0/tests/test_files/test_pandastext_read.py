import logging
from pathlib import Path

import numpy as np
import numpy.testing as npt

from postopus.files.pandas_text import PandasTextFile


def test_dataframe_dimensionality(methane_run: Path):
    ptf_forces = PandasTextFile(methane_run / "static" / "forces")
    assert ptf_forces.values.shape == (5, 31)

    path = methane_run / "static" / "convergence"
    ptf_convergence = PandasTextFile(path)
    # Count number of lines "per hand". The problem is, that the number of steps required for convergence
    # changes often between octopus versions, so putting some constant here is not reliable.
    data = path.read_text()
    lines = [
        line
        for line in data.split("\n")
        if not line.startswith("#") and line.strip() != ""
    ]
    assert ptf_convergence.values.shape == (len(lines), 6)


def test_dataframe_values(testdata_dir: Path):
    ptf_convergence = PandasTextFile(testdata_dir / "precomputed" / "convergence")
    assert ptf_convergence.values.columns.values.tolist() == [
        "energy",
        "energy_diff",
        "abs_dens",
        "rel_dens",
        "abs_ev",
        "rel_ev",
    ]
    assert ptf_convergence.values.shape == (18, 6)

    assert ptf_convergence.values["energy"][1] == -7.95361970e00
    assert ptf_convergence.values["energy_diff"][1] == 7.95362e00
    assert ptf_convergence.values["abs_dens"][1] == 5.23291e-01
    assert ptf_convergence.values["rel_dens"][1] == 6.54114e-02
    assert ptf_convergence.values["abs_ev"][1] == 7.01022e-02
    assert ptf_convergence.values["rel_ev"][1] == 1.58352e-02

    assert ptf_convergence.values["energy"][10] == -7.83899455e00
    assert ptf_convergence.values["energy_diff"][10] == 1.30738e-03
    assert ptf_convergence.values["abs_dens"][10] == 2.13131e-03
    assert ptf_convergence.values["rel_dens"][10] == 2.66414e-04
    assert ptf_convergence.values["abs_ev"][10] == 1.31255e-03
    assert ptf_convergence.values["rel_ev"][10] == 3.87818e-04

    assert ptf_convergence.values["energy"][18] == -7.83206998e00
    assert ptf_convergence.values["energy_diff"][18] == 2.89571e-06
    assert ptf_convergence.values["abs_dens"][18] == 2.84061e-06
    assert ptf_convergence.values["rel_dens"][18] == 3.55077e-07
    assert ptf_convergence.values["abs_ev"][18] == 7.36993e-07
    assert ptf_convergence.values["rel_ev"][18] == 2.17981e-07

    forces_headers = [
        "species",
        "total_x",
        "total_y",
        "total_z",
        "ion-ion_x",
        "ion-ion_y",
        "ion-ion_z",
        "vdw_x",
        "vdw_y",
        "vdw_z",
        "local_x",
        "local_y",
        "local_z",
        "nl_x",
        "nl_y",
        "nl_z",
        "fields_x",
        "fields_y",
        "fields_z",
        "hubbard_x",
        "hubbard_y",
        "hubbard_z",
        "scf_x",
        "scf_y",
        "scf_z",
        "nlcc_x",
        "nlcc_y",
        "nlcc_z",
        "phot_x",
        "phot_y",
        "phot_z",
    ]

    ptf_forces = PandasTextFile(testdata_dir / "precomputed" / "forces")
    assert ptf_forces.values.columns.values.tolist() == forces_headers
    assert ptf_forces.values.shape == (5, 31)
    assert ptf_forces.values["species"].values.tolist() == ["C", "H", "H", "H", "H"]
    assert ptf_forces.values["total_x"][1] == 2.87910660e-14
    assert ptf_forces.values["local_y"][4] == 6.44560694e-01
    assert ptf_forces.values["scf_x"][4] == 5.51426998e-08
    assert ptf_forces.values["scf_y"][5] == 5.51426996e-08
    assert ptf_forces.values["scf_z"][3] == 5.51426998e-08


def test_read_other_data(tmp_path: Path):
    test_file = tmp_path / "pandas_readable_other_file.txt"

    testdata = "title1 title2 title3# 10 11 12\n1 2 3\n4 5 6\n7 8 9"

    test_file.write_text(testdata)

    pdf = PandasTextFile(test_file)
    npt.assert_array_equal(
        pdf.values.values, np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    )
    assert all(pdf.values.columns.values == ["title1", "title2", "title3"])


def test_read_other_data_unreadable(tmp_path: Path, caplog):
    caplog.set_level(logging.WARNING)

    test_file = tmp_path / "pandas_readable_other_file.txt"

    testdata = (
        "this is a\n"
        "// file containing some random words\n"
        "hoping\n"
        "pandas is unable to read it or make any sense out of it\n"
        "so we can have an error\n"
    )

    test_file.write_text(testdata)

    pdf = PandasTextFile(test_file)
    pdf.values
    assert "Could not read file" in caplog.text
    assert "pandas_readable_other_file.txt" in caplog.text
    # split("\n")[:-1] because list comprehension generates one newline extra at the end
    assert pdf.values == [s + "\n" for s in testdata.split("\n")[:-1]]


def test_attrs_attribute(methane_run: Path):
    ptf = PandasTextFile(methane_run / "td.general" / "laser")
    assert ptf.attrs is not None
