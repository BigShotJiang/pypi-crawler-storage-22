import pandas as pd

from postopus.files import XYZFile

benzene_xyz = """12
Geometry of benzene (in Angstrom)
   C  0.000  1.396  0.000
   C  1.209  0.698  0.000
   C  1.209 -0.698  0.000
   C  0.000 -1.396  0.000
   C -1.209 -0.698  0.000
   C -1.209  0.698  0.000
   H  0.000  2.479  0.000
   H  2.147  1.240  0.000
   H  2.147 -1.240  0.000
   H  0.000 -2.479  0.000
   H -2.147 -1.240  0.000
   H -2.147  1.240  0.000
"""


def test_read_xyz_file(tmp_path):
    f1 = tmp_path / "benzene.xyz"
    with f1.open("w") as f:
        f.write(benzene_xyz)

    # Add some empty lines at beginning of file
    f2 = tmp_path / "benzene_leading_empty_lines.xyz"
    with f2.open("w") as f:
        f.write("\n\n\n")
        f.write(benzene_xyz)

    records = [
        ("C", 0.0, 1.396, 0.0),
        ("C", 1.209, 0.698, 0.0),
        ("C", 1.209, -0.698, 0.0),
        ("C", 0.0, -1.396, 0.0),
        ("C", -1.209, -0.698, 0.0),
        ("C", -1.209, 0.698, 0.0),
        ("H", 0.0, 2.479, 0.0),
        ("H", 2.147, 1.24, 0.0),
        ("H", 2.147, -1.24, 0.0),
        ("H", 0.0, -2.479, 0.0),
        ("H", -2.147, -1.24, 0.0),
        ("H", -2.147, 1.24, 0.0),
    ]
    expected = pd.DataFrame.from_records(records, columns=["Atom", "x", "y", "z"])

    df1 = XYZFile(f1).as_pandas()
    pd.testing.assert_frame_equal(expected, df1)

    df2 = XYZFile(f2).as_pandas()
    pd.testing.assert_frame_equal(expected, df2)
