import pandas as pd
from tests.utils import dir_no_special

from postopus import Run


def test_provided_outputs(casida_run):
    run = Run(casida_run)
    assert dir_no_special(run) == {"scf", "casida", "rootpath"}
    assert dir_no_special(run.casida) == {
        "casida",
        "petersilka",
        "eps_diff",
        "spectrum",
    }


def test_casida_output(casida_run):
    run = Run(casida_run)

    df = run.casida.casida()
    assert list(df.columns) == ["E", "<x>", "<y>", "<z>", "<f>"]
    assert df.shape == (8, 5)
    assert (df.dtypes == "float").all()
    assert not df.isnull().any(axis=None)
    assert (df != 0).all(axis=None)
    assert df.attrs["units"] == {
        "E": "eV",
        "<x>": "A",
        "<y>": "A",
        "<z>": "A",
        "<f>": "",
    }


def test_petersilka_output(casida_run):
    run = Run(casida_run)

    df = run.casida.petersilka()
    assert list(df.columns) == ["E", "<x>", "<y>", "<z>", "<f>"]
    assert df.shape == (8, 5)
    assert (df.dtypes == "float").all()
    assert not df.isnull().any(axis=None)
    assert (df != 0).all(axis=None)
    assert df.attrs["units"] == {
        "E": "eV",
        "<x>": "A",
        "<y>": "A",
        "<z>": "A",
        "<f>": "",
    }


def test_eps_diff_output(casida_run):
    run = Run(casida_run)

    df = run.casida.eps_diff()
    expected_column_names = ["From", "To", "E", "<x>", "<y>", "<z>", "<f>"]
    assert list(df.columns) == expected_column_names
    assert df.shape == (8, 7)
    int_columns = ["From", "To"]
    assert (df[int_columns].dtypes == "int").all()
    float_columns = list(set(expected_column_names) - set(int_columns))
    assert (df[float_columns].dtypes == "float").all()
    assert not df.isnull().any(axis=None)
    assert (df != 0).all(axis=None)
    assert df.attrs["units"] == {
        "From": "",
        "To": "",
        "E": "eV",
        "<x>": "A",
        "<y>": "A",
        "<z>": "A",
        "<f>": "",
    }


def test_spectrum_output(casida_run):
    run = Run(casida_run)

    assert dir_no_special(run.casida.spectrum) == {"casida", "eps_diff", "petersilka"}
    r = repr(run.casida.spectrum)
    assert "spectrum.casida" in r
    assert "spectrum.petersilka" in r

    # Test default data access
    df = run.casida.spectrum()
    assert list(df.columns) == ["E", "<xx>", "<yy>", "<zz>", "<f>"]
    assert (df.dtypes == "float").all()
    assert not df.isnull().any(axis=None)

    # Test access of one specific file (e.g. spectrum.casida)
    df_casida = run.casida.spectrum.casida()
    pd.testing.assert_frame_equal(df.loc["spectrum.casida"], df_casida)
