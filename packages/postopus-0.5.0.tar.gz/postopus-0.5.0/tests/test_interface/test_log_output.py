from postopus import Run, open_textfile


def test_open_textfile(methane_run):
    run = Run(methane_run)

    logfile = open_textfile(run / "gs_stdout.txt")

    assert logfile.grepfield("Number of states") == ["Number", "of", "states", "=", "4"]
    assert logfile.grepfield("Number of states", 4) == "4"
    assert logfile.find_one_or_none(r"Number of states\s+=\s+(\d+)") == "4"
