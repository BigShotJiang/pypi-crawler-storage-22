from pathlib import Path

import pandas as pd
import pytest
import xarray as xr

from postopus import Run, nestedRuns


def test_nested_runs(nested_runs: Path):
    n = nestedRuns(nested_runs)
    nruns = n.get_path(nested_runs)

    # Import each run via the single run interface to compare results.
    run_Δx_4 = Run(nested_runs / "deltax_0.4")
    run_Δx_5 = Run(nested_runs / "deltax_0.5")
    run_Δx_6 = Run(nested_runs / "deltax_0.6")

    # convergence
    convergence = pd.concat(nruns.apply(lambda run: run.scf.convergence()))
    level_values = convergence.index.get_level_values(None)  # get values of deltas
    expected_deltas = ["deltax_0.6", "deltax_0.5", "deltax_0.4"]
    assert all(element in level_values for element in expected_deltas) is True
    expected_len = (
        len(run_Δx_4.scf.convergence())
        + len(run_Δx_5.scf.convergence())
        + len(run_Δx_6.scf.convergence())
    )
    assert len(convergence) == expected_len
    assert set(run_Δx_4.scf.convergence()["energy"].values) <= set(
        convergence["energy"].values
    )
    assert set(run_Δx_5.scf.convergence()["energy"].values) <= set(
        convergence["energy"].values
    )
    assert set(run_Δx_6.scf.convergence()["energy"].values) <= set(
        convergence["energy"].values
    )

    # density fields
    fields = nruns.apply(lambda run: run.scf.density())
    assert isinstance(fields["deltax_0.6"], xr.DataArray)
    assert fields["deltax_0.6"].max() == pytest.approx(2.4, rel=0.5)
