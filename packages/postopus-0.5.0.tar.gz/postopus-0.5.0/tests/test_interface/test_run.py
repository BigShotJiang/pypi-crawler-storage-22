import os
from pathlib import Path

import pytest
from tests.utils import dir_no_special

from postopus import Run


@pytest.fixture
def restore_working_directory(
    request: pytest.FixtureRequest,
) -> None:
    """Reset the working directory to the original path after a test is finished.
    (pytest doesnt change back to the default directory after a test is run.)
    """
    orig_path = request.config.invocation_params.dir
    yield
    os.chdir(orig_path)


def test_bad_path(testdata_dir: Path, methane_run: Path):
    with pytest.raises(NotADirectoryError):
        Run(methane_run / "inp")

    with pytest.raises(FileNotFoundError):
        Run(testdata_dir)


def test_run_instantiation(restore_working_directory: None, methane_run: Path):
    """
    Test checks if the default value for the path of a run object
    is the current working directory.
    """
    os.chdir(methane_run.parent)
    run1 = Run(methane_run.name)
    run1_path = Path(os.path.join(os.getcwd(), run1.rootpath))

    os.chdir(methane_run.name)
    run2 = Run()
    run2_path = Path(os.path.join(os.getcwd(), run2.rootpath))

    assert run1_path == run2_path


def test_expected_outputs(
    methane_run: Path, benzene_run: Path, celestial_bodies_run: Path
):
    run = Run(methane_run)
    assert dir_no_special(run) == {"profiling", "scf", "td", "rootpath"}
    assert (
        dir_no_special(run.default.scf)
        == dir_no_special(run.scf)
        == {
            "density",
            "convergence",
            "forces",
            "info",
            "wf",
        }
    )
    assert (
        dir_no_special(run.default.td)
        == dir_no_special(run.td)
        == {
            "current",
            "density",
            "energy",
            "laser",
            "multipoles",
            "wf",
        }
    )
    assert (
        dir_no_special(run.default.profiling)
        == dir_no_special(run.profiling)
        == {"time"}
    )

    run = Run(benzene_run)
    assert dir_no_special(run) == {"scf", "rootpath", "geometry"}
    assert (
        dir_no_special(run.scf)
        == dir_no_special(run.default.scf)
        == {
            "density",
            "convergence",
            "forces",
            "info",
            "geometry",
        }
    )

    run = Run(celestial_bodies_run)
    assert dir_no_special(run) == {"SolarSystem", "profiling", "rootpath"}
    assert dir_no_special(run.SolarSystem) == {"Earth", "Sun", "Moon", "system_name"}
    assert (
        dir_no_special(run.SolarSystem.Earth)
        == dir_no_special(run.SolarSystem.Sun)
        == dir_no_special(run.SolarSystem.Moon)
        == {"td", "system_name"}
    )

    assert (
        dir_no_special(run.SolarSystem.Earth.td)
        == dir_no_special(run.SolarSystem.Sun.td)
        == dir_no_special(run.SolarSystem.Moon.td)
        == {"coordinates", "energy"}
    )


def test_repr(
    methane_run: Path, celestial_bodies_run: Path, geometric_optimization_run: Path
):
    """Make sure the __repr__ methods are at least not
    throwing any exceptions.
    """
    run = Run(methane_run)

    # Test run object
    r = repr(run)
    assert "Found systems" not in r  # Methane is a run without multi systems
    assert "Found calculation modes" in r
    assert "No data related to any calculation modes found!" not in r
    assert "td" in r
    assert "scf" in r

    # Test calculation modes
    r = repr(run.scf)
    assert "Ground state calculation" in r
    assert "convergence" in r
    assert "density" in r
    r = repr(run.td)
    assert "Time dependent simulation" in r
    assert "current" in r

    # Test output
    r = repr(run.scf.convergence)
    r = repr(run.scf.density)
    assert "Available sources" in r
    assert ".vtk" in r
    assert ".ncdf" in r
    r = repr(run.td.current)
    assert "Available sources" in r
    assert ".vtk" in r
    assert ".ncdf" in r

    # Test multi system
    run = Run(celestial_bodies_run)
    r = repr(run)
    assert "Found systems" in r
    assert "SolarSystem" in r
    assert "Found calculation modes" in r
    assert "td" in r
    assert "profiling" in r

    r = repr(run.SolarSystem)
    assert "name='SolarSystem" in r
    assert "Earth" in r
    assert "Moon" in r
    assert "Sun" in r

    # If only utilities are invoked there might not be any calculation mode related data.
    run = Run(geometric_optimization_run)
    r = repr(run)
    assert "Found calculation modes" not in r
    assert "No data related to any calculation modes found!" in r
    assert "Outputs:" in r
    assert "geometry" in r
    # The same should happen for systems in a multisystem framework.
    # We use the default system for testing here as it uses the same backend
    # as a multisystem.
    r = repr(run.default)
    assert "Found calculation modes" not in r
    assert "No data related to any calculation modes found!" in r
    assert "Outputs:" in r
    assert "geometry" in r
