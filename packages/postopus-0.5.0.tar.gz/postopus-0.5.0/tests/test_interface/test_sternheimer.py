from postopus import Run
from postopus.files import PandasTextFile


def test_pandas_read_cross_section(sternheimer_run):
    path = sternheimer_run / "em_resp" / "freq_0.0000" / "cross_section"
    file = PandasTextFile(path)
    data = file.values
    expected_columns_and_units = {
        "Energy": "[eV]",
        "(1/3)*Tr[sigma]": "[A^2]",
        "Anisotropy[sigma]": "[A^2]",
        "sigma(1,1)": "[A^2]",
        "sigma(1,2)": "[A^2]",
        "sigma(1,3)": "[A^2]",
        "sigma(2,1)": "[A^2]",
        "sigma(2,2)": "[A^2]",
        "sigma(2,3)": "[A^2]",
        "sigma(3,1)": "[A^2]",
        "sigma(3,2)": "[A^2]",
        "sigma(3,3)": "[A^2]",
    }
    assert data.shape == (1, 12)
    assert list(data.columns) == list(expected_columns_and_units.keys())
    assert file.attrs["units"] == expected_columns_and_units
    assert not data.isnull().any(axis=None)


def test_sternheimer_files(sternheimer_run):
    run = Run(sternheimer_run)
    # read cross section and alpha value.
    σ = run.em_resp.cross_section()
    α = run.em_resp.alpha()
    # As both files are present per frequency they should have a matching 'freq' column
    (σ.index.get_level_values("freq") == α.index).all()
    # This should also make joining the two frame a simple task
    combined = σ.join(α)
    assert (combined.index == σ.index).all()
    assert list(σ.columns) + list(α.columns) == list(combined.columns)
