"""Collection of tests to test access on files in the `td.general` folder."""

import re
from pathlib import Path

import pandas as pd
from tests.utils.octopus_runner import OctopusRunner

from postopus import Run
from postopus.files import PandasTextFile
from postopus.utils import NUMERICAL_CONST_PATTERN


def test_read_tdgeneralvectorfield(interference_run: Path):
    """Test reading vector fields occuring in td.general/.
    Similar to vector fields in output_iter the output consists
    of three files with a `_x`/`_y`/`_z` suffix (as in `total_e_field_y`).
    The files are structured the same as any other files in
    static/ and td.general/ and thus returned as a dataframe.
    """
    run = Run(interference_run)

    total_e_field = run.Maxwell.td.total_e_field()
    assert total_e_field.z.shape == (167, 2)
    assert isinstance(total_e_field.z, pd.DataFrame)
    assert total_e_field.z.attrs.keys() == {"units", "metadata"}
    assert total_e_field.z.attrs["units"] == {
        "Iter": "[Iter n.]",
        "t": "[hbar/H]",
        "E(1)": "[H/b]",
    }

    # Extract `0.210656423428E-02 [hbar/H]` from the line `# dt =   0.210656423428E-02 [hbar/H]`
    # which should occure in the metadata as via the key "dt".
    with open(interference_run / "Maxwell" / "td.general" / "total_e_field_z") as f:
        content = f.read()
        m = re.findall(r"# dt =\s+(\d+.\d+E[+0-]\d+\s+\[hbar/H\])", content)
        assert len(m) == 1
        dt = m[0]

    assert total_e_field.z.attrs["metadata"] == {
        "filename": "total_e_field_z",
        "dt": [dt],
    }


def test_loading_static_data(methane_run: Path):
    run = Run(methane_run)
    assert isinstance(run.td.energy(), pd.DataFrame)
    assert isinstance(run.td.laser(), pd.DataFrame)
    assert isinstance(run.td.multipoles(), pd.DataFrame)
    assert isinstance(run.td.multipoles().attrs, dict)


def test_coordinates_attrs_reading(
    octopus_runner: OctopusRunner, celestial_bodies_run: Path
):
    run = Run(celestial_bodies_run)
    print(f"Octopus version is {octopus_runner.octopus_version}")
    if octopus_runner.octopus_version[0] <= 14:
        exp_unit_dict = {
            "Iter": "[Iter n.]",
            "t": "[hbar/H]",
            "x(  1)": "[b]",
            "x(  2)": "[b]",
            "x(  3)": "[b]",
            "v(  1)": "[bH(2pi/h)]",
            "v(  2)": "[bH(2pi/h)]",
            "v(  3)": "[bH(2pi/h)]",
            "f(  1)": "[H/b]",
            "f(  2)": "[H/b]",
            "f(  3)": "[H/b]",
        }
    else:
        exp_unit_dict = {
            "Iter": "[Iter n.]",
            "t": "[hbar/H]",
            "x(  1,  1)": "[b]",
            "x(  1,  2)": "[b]",
            "x(  1,  3)": "[b]",
            "v(  1,  1)": "[bH(2pi/h)]",
            "v(  1,  2)": "[bH(2pi/h)]",
            "v(  1,  3)": "[bH(2pi/h)]",
            "f(  1,  1)": "[H/b]",
            "f(  1,  2)": "[H/b]",
            "f(  1,  3)": "[H/b]",
        }
    act_unit_dict = run.SolarSystem.Sun.td.coordinates().attrs["units"]

    assert exp_unit_dict == act_unit_dict


def test_standard_attrs_reading(methane_run: Path):
    """
    Test expected standard reading routine for attrs in tdgeneral files

    """
    run = Run(methane_run)
    exp_unit_dict = {
        "Iter": "[Iter n.]",
        "t": "[hbar/H]",
        "E(1)": "[H/b]",
        "E(2)": "[H/b]",
        "E(3)": "[H/b]",
    }
    exp_metadata_dict = {"dt": ["0.500000000000E-01 [hbar/H]"], "filename": "laser"}

    act_unit_dict = run.td.laser().attrs["units"]
    act_metadata_dict = run.td.laser().attrs["metadata"]

    assert exp_unit_dict == act_unit_dict
    assert exp_metadata_dict == act_metadata_dict


def test_total_curr_attrs_reading(bulk_si_run: Path):
    run = Run(bulk_si_run)
    assert run.td.total_current().attrs["units"]["t"] == "Units not specified"


def test_multisystems_reading(celestial_bodies_run: Path):
    run = Run(celestial_bodies_run)
    assert run.SolarSystem.Earth.td.coordinates().shape == (73, 10)
    assert run.SolarSystem.Sun.td.coordinates().shape == (73, 10)
    assert run.SolarSystem.Moon.td.coordinates().shape == (73, 10)


def _assert_all_entries_fullmatch(pattern, entries):
    for entry in entries:
        assert re.fullmatch(pattern, entry)


def test_cross_section_vector(optical_spectra_single_polarization_run):
    run = Run(optical_spectra_single_polarization_run)
    data = run.td.cross_section_vector()

    exp_unit_dict = {
        "Energy": "[eV]",
        "sigma(1, nspin=1)": "[A^2]",
        "sigma(2, nspin=1)": "[A^2]",
        "sigma(3, nspin=1)": "[A^2]",
        "StrengthFunction(1)": "[1/eV]",
    }
    assert list(data.columns) == list(exp_unit_dict.keys())
    assert data.attrs["units"] == exp_unit_dict

    # Check at least a subset of all the metadata provided in the file.
    # Only check if we find a number as the values change between octopus versions...
    metadata = data.attrs["metadata"]
    _assert_all_entries_fullmatch(NUMERICAL_CONST_PATTERN, metadata["nspin"])
    _assert_all_entries_fullmatch(
        NUMERICAL_CONST_PATTERN, metadata["Electronic sum rule"]
    )
    # value is something like "0.649500 A"
    _assert_all_entries_fullmatch(
        f"{NUMERICAL_CONST_PATTERN} A",
        metadata["Static polarizability (from sum rule)"],
    )


def test_cross_section_tensor(optical_spectra_multi_polarization_run):
    run = Run(optical_spectra_multi_polarization_run)
    data = run.td.cross_section_tensor()

    exp_unit_dict = {
        "Energy": "[eV]",
        "(1/3)*Tr[sigma]": "[A^2]",
        "Anisotropy[sigma]": "[A^2]",
        "sigma(1,1,1)": "[A^2]",
        "sigma(1,2,1)": "[A^2]",
        "sigma(1,3,1)": "[A^2]",
        "sigma(2,1,1)": "[A^2]",
        "sigma(2,2,1)": "[A^2]",
        "sigma(2,3,1)": "[A^2]",
        "sigma(3,1,1)": "[A^2]",
        "sigma(3,2,1)": "[A^2]",
        "sigma(3,3,1)": "[A^2]",
    }
    assert list(data.columns) == list(exp_unit_dict.keys())
    assert data.attrs["units"] == exp_unit_dict

    # Check at least a subset of all the metadata provided in the file
    expected_metadata_subset = {
        "nspin": ["1"],
        "Equiv. axes": ["0"],
    }
    assert expected_metadata_subset.items() <= data.attrs["metadata"].items()


def test_multiple_cross_section_vectors(optical_spectra_multi_polarization_run):
    """To create the `cross_section_tensor` file the user has to create
    `td.general/multipoles.1`, `td.general/multipoles.2`, `td.general/multipoles.3`
    which also produces
    `cross_section_vector.1`, `cross_section_vector.2`, `cross_section_vector.3`.

    These files should still be readable.
    """
    run = Run(optical_spectra_multi_polarization_run)
    multipoles = run.td.multipoles()

    # compare via merging by hand
    dfs = {
        "1": PandasTextFile(run / "td.general" / "multipoles.1").values,
        "2": PandasTextFile(run / "td.general" / "multipoles.2").values,
        "3": PandasTextFile(run / "td.general" / "multipoles.3").values,
    }
    df = pd.concat(dfs, names=["Direction"])
    pd.testing.assert_frame_equal(df, multipoles)
    # Check also column names (in case each multipoles.i is not read properly)
    assert list(multipoles.columns) == [
        "t",
        "Electronic charge(1)",
        "<x>(1)",
        "<y>(1)",
        "<z>(1)",
    ]

    # same with cross_section_vector
    cross_section_vector = run.td.cross_section_vector()

    dfs = {
        "1": PandasTextFile(run / "cross_section_vector.1").values,
        "2": PandasTextFile(run / "cross_section_vector.2").values,
        "3": PandasTextFile(run / "cross_section_vector.3").values,
    }
    df = pd.concat(dfs, names=["Direction"])
    pd.testing.assert_frame_equal(df, cross_section_vector)
    assert list(cross_section_vector.columns) == [
        "Energy",
        "sigma(1, nspin=1)",
        "sigma(2, nspin=1)",
        "sigma(3, nspin=1)",
        "StrengthFunction(1)",
    ]
