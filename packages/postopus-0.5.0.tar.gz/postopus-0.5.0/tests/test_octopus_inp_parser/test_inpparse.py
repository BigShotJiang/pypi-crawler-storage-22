from pathlib import Path

from postopus.octopus_inp_parser.inpparse import Parser


def test_input_parsing_multiple_systems(celestial_bodies_run: Path):
    # Comparison data for testing
    check_keys = [
        "CalculationMode",
        "ExperimentalFeatures",
        "FromScratch",
        "ProfilingMode",
        "stdout",
        "stderr",
        "Dimensions",
        "Systems",
        "SolarSystem.Systems",
        "Interactions",
        "Earth.ParticleMass",
        "Earth.ParticleInitialPosition",
        "Earth.ParticleInitialVelocity",
        "Moon.ParticleMass",
        "Moon.ParticleInitialPosition",
        "Moon.ParticleInitialVelocity",
        "Sun.ParticleMass",
        "Sun.ParticleInitialPosition",
        "Sun.ParticleInitialVelocity",
        "TDSystemPropagator",
        "sampling",
        "days",
        "seconds_per_day",
        "TDTimeStep",
        "TDPropagationTime",
    ]
    check_systems = [
        "SolarSystem",
        "SolarSystem.Sun",
        "SolarSystem.Earth",
        "SolarSystem.Moon",
        "default",
    ]
    particlemass_sun = "1.98855e30"

    inp = Parser(celestial_bodies_run / "inp")
    assert list(inp.fields_raw) == check_keys
    assert list(inp.systems) == check_systems
    # test multisystem parsing
    assert inp.systems["default"]["Sun.ParticleMass"] == particlemass_sun


def test_input_parsing_default_system(methane_run: Path):
    inp = Parser(methane_run / "inp")
    assert inp.systems["default"]["_systemtype"] == "electronic"


def test_input_parsing_with_extra_whitespace(tmp_path):
    test_path = tmp_path / "test_inp_file_with_intendation"
    test_path.mkdir()
    inp_file = test_path / "inp"
    with open(inp_file, "w") as f:
        f.write("    \n")
        f.write("   foo    =    bar\n")
        # Put an non-empty line  at end of file (without line break at the end!).
        f.write("    ")

    # Now invoke the parser
    parsed_inp = Parser(inp_file)
    assert parsed_inp.fields_raw == {"foo": "bar"}
