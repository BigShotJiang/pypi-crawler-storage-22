"""Collection of common octopus runs, e.g. the methane molecule.

These runs are used across multiple tests (explicit by requesting those as a fixture
or implicit by requesting a fixture which is based on a common run, e.g. from
duplicate_with_missing).
Changing the parameters of the runs will affect these tests!
"""

from __future__ import annotations

import shutil
import typing

import pytest

if typing.TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from .octopus_runner import OctopusRunner


def make_common_run(
    name: str,
    path: str,
    input_files: list[str],
    additional_files: list[str] | None = None,
) -> Callable[[Path, OctopusRunner], Path]:
    """Create a fixture for a common run.

    Parameters
    ----------
    name
        Name of the fixture.
    path
        Path to the input files in the test data directory (tests/data/<path>).
    input_files
        List of the input files, e.g. `["inp_gs", "inp_td"].
    additional_files
        Additional files which should be provided in the octopus run directory,
        e.g. `["benzene.xyz"]`.
    """

    @pytest.fixture(name=name, scope="session")
    def run(testdata_dir: Path, octopus_runner: OctopusRunner) -> Path:
        basepath = testdata_dir / path
        return octopus_runner.run_simple(
            basepath, input_files=input_files, additional_files=additional_files
        )

    return run


methane_run = make_common_run(
    "methane_run",
    "methane",
    ["inp_gs", "inp_td"],
)
benzene_run = make_common_run("benzene_run", "benzene", "inp_gs", "benzene.xyz")
celestial_bodies_run = make_common_run(
    "celestial_bodies_run", "celestial_bodies", "inp_td"
)
kpoints_run = make_common_run("kpoints_run", "kpoints", ["inp_gs", "inp_td"])
bn_monolayer_run = make_common_run(
    "bn_monolayer_run", "2-h-BN_monolayer", ["inp_gs", "inp_unocc"]
)
harmonic_oscillator_run = make_common_run(
    "harmonic_oscillator_run", "1d-harmonic-oscillator", ["inp_gs", "inp_unocc"]
)
bulk_si_run = make_common_run("bulk_si_run", "3-bulk_Si", ["inp_gs", "inp_td"])
sternheimer_run = make_common_run(
    "sternheimer_run", "sternheimer", ["inp_gs", "inp_em"]
)


@pytest.fixture
def born_opp_dynamics_run(testdata_dir: Path, octopus_runner: OctopusRunner) -> Path:
    base_path = testdata_dir / "born-opp-dynamics"
    inp_gs = base_path / "inp_gs"
    inp_td = base_path / "inp_td"
    run_path = base_path / "run"

    # Check if running octopus is required. This is done by `octopus_runner.run` automatically,
    # but as we run some Octopus utility separately we need to do this check ourselves.
    if octopus_runner.is_rerun_required([inp_gs, inp_td], run_path):
        # Run octopus with inp_gs and inp_td
        octopus_runner.run(run_path=run_path, inputfiles=[inp_gs, inp_td])
        # Now run the utility
        octopus_runner.run_utility("oct-vibrational_spectrum", run_path=run_path)

    return run_path


@pytest.fixture
def _optical_spectra_run(testdata_dir: Path, octopus_runner: OctopusRunner) -> Path:
    base_path = testdata_dir / "optical_spectra"
    inp_gs = base_path / "inp_gs"
    inp_td = base_path / "inp_td_template"

    run_path = base_path / "run" / "multi_polarization_direction"
    run_path_single_polarization = base_path / "run" / "single_polarization_direction"

    if not octopus_runner.is_rerun_required([inp_gs, inp_td], run_path):
        return run_path, run_path_single_polarization

    # As this fixture splits the octopus runs in single calls of the octopus runner
    # and even splits the runs into two at some point the octopus_runner will not
    # purge existing files correctly in some situations. Take care of this:
    for p in [run_path, run_path_single_polarization]:
        if p.exists():
            shutil.rmtree(p)

    # Run ground state.
    octopus_runner.run_part(run_path=run_path, inputfiles=inp_gs)

    # Run td for first polarization direction
    octopus_runner.run_part(
        run_path=run_path,
        inputfiles=inp_td,
        parameters={"polarization_direction": "1"},
    )

    # Copy this state for the single polarization version
    shutil.copytree(run_path, run_path_single_polarization)
    # Run the utility for the single polarization version
    octopus_runner.run_utility("oct-propagation_spectrum", run_path_single_polarization)

    # From here, work on the multi polarization version,
    # i.e. rename `multipoles` to `multipoles.i` for each direction
    # and invoke the utility.
    # For direction 1 we did the td run already.
    shutil.move(
        run_path / "td.general" / "multipoles", run_path / "td.general" / "multipoles.1"
    )
    for direction in ["2", "3"]:
        octopus_runner.run_part(
            run_path=run_path,
            inputfiles=inp_td,
            parameters={"polarization_direction": direction},
        )
        shutil.move(
            run_path / "td.general" / "multipoles",
            run_path / "td.general" / f"multipoles.{direction}",
        )
    octopus_runner.run_utility("oct-propagation_spectrum", run_path)

    return run_path, run_path_single_polarization


@pytest.fixture
def optical_spectra_single_polarization_run(_optical_spectra_run) -> Path:
    run_path_multi_polarization, run_path_single_polarization = _optical_spectra_run
    return run_path_single_polarization


@pytest.fixture
def optical_spectra_multi_polarization_run(_optical_spectra_run) -> Path:
    run_path_multi_polarization, run_path_single_polarization = _optical_spectra_run
    return run_path_multi_polarization


@pytest.fixture
def interference_run(testdata_dir: Path, octopus_runner: OctopusRunner) -> Path:
    basepath = testdata_dir / "interference"
    # Beginning with Octopus 14, the input option MaxwellIncidentWaves requires an
    # additional parameter.
    if octopus_runner.octopus_version[0] <= 13:
        inp = "inp_td_13.0"
    else:
        inp = "inp_td"

    return octopus_runner.run_simple(basepath, input_files=[inp])


@pytest.fixture
def geometric_optimization_run(testdata_dir) -> Path:
    # Could execute utility 'oct-center-geom' but as the only relevant output
    # is 'adjusted.xyz' we can just keep that file in the repo as well.
    return testdata_dir / "geometric_optimization"


@pytest.fixture
def casida_run(testdata_dir: Path, octopus_runner: OctopusRunner) -> Path:
    base_path = testdata_dir / "casida"
    inp_gs = base_path / "inp_gs"
    inp_unocc = base_path / "inp_unocc"
    inp_casida = base_path / "inp_casida"
    inp_casida_spectrum = base_path / "inp_casida_spectrum"
    run_path = base_path / "run"

    if octopus_runner.is_rerun_required(
        [inp_gs, inp_unocc, inp_casida, inp_casida_spectrum], run_path
    ):
        octopus_runner.run(
            run_path=run_path, inputfiles=[inp_gs, inp_unocc, inp_casida]
        )
        octopus_runner.run_utility(
            "oct-casida_spectrum", run_path=run_path, inp_file=inp_casida_spectrum
        )

    return run_path
