def dir_no_special(obj):
    """Like `dir` but ignore private and special attributes (e.g. '__doc__')"""
    return {attr for attr in dir(obj) if not attr.startswith("_")}
