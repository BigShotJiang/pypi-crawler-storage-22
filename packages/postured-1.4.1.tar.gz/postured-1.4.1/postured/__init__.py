"""Postured - A Linux app that lets you know when you slouch."""

__version__ = "1.4.1"
