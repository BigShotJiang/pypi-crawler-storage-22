"""Domain model tests."""

