"""POTX theme editing toolkit."""

from .template import PotxTemplate

__all__ = ["PotxTemplate"]
__version__ = "0.1.0"
