"""Bundled package data for potxkit."""
