# Pounce Agent Data SDK

Python SDK for the [Pounce Agent Data API](https://pounce.ch/developers) - Connect your AI agents to 500k+ B2B company signals.

## Installation

```bash
pip install pounce-agent-data
```

## Quick Start

```python
from pounce_agent_data import PounceClient

client = PounceClient(api_key="pounce_live_xxx")

# Recent signals
data, rate_limit = client.recent_signals(limit=10, category="saas")
for item in data["items"]:
    print(f"{item['domain']}: {item['signal_score']}")

# Semantic search
data, rate_limit = client.search("AI startups in healthcare", limit=20)
for item in data["items"]:
    print(f"{item['domain']}: similarity={item['similarity']:.2f}")

# Stream new signals (real-time)
for signal in client.stream(min_score=70):
    print(f"New: {signal.domain} (score={signal.signal_score})")
```

## API Key

Get your API key:
1. Sign up at [pounce.ch](https://pounce.ch)
2. Subscribe to Pro ($49/month) or Business ($149/month)
3. Generate API key in **Settings → API Access**

## Rate Limits

| Tier | Requests/month |
|------|----------------|
| Pro | 1,000 |
| Business | 10,000 |

## Documentation

- [API Documentation](https://pounce.ch/developers)
- [Skill File](https://pounce.ch/skill.md)
- [API Reference](https://api.pounce.ch/docs#/agent-data)

## Support

- Email: hello@pounce.ch

## License

MIT
