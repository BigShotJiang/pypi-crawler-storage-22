from .client import PounceAgentDataClient

# Alias for convenience (used in docs)
PounceClient = PounceAgentDataClient

__all__ = ["PounceAgentDataClient", "PounceClient"]

