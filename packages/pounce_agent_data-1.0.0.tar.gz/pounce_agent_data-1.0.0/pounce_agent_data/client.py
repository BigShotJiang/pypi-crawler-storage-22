"""
Pounce Agent Data SDK - Python Client

Minimal dependency-free client for the Pounce Agent Data API.
Supports recent signals, semantic search, signal details, and SSE streaming.

Usage:
    from pounce_agent_data import PounceAgentDataClient
    
    client = PounceAgentDataClient(api_key="pounce_live_xxx")
    
    # Recent signals
    data, rl = client.recent_signals(limit=10, category="saas")
    
    # Semantic search
    data, rl = client.search("AI companies in healthcare", limit=20)
    
    # Signal detail
    data, rl = client.signal_detail("abc123")
    
    # Stream new signals (generator)
    for signal in client.stream(min_score=70):
        print(signal)
"""
from __future__ import annotations

import json
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Dict, Generator, Iterator, Optional, Tuple


@dataclass(frozen=True)
class RateLimitInfo:
    """Rate limit information from API response headers."""
    limit: Optional[int]
    remaining: Optional[int]
    reset_unix: Optional[int]


@dataclass(frozen=True)
class Signal:
    """A B2B signal from the Pounce platform."""
    signal_id: str
    domain: str
    company_name: Optional[str]
    category: Optional[str]
    signal_score: int
    intent_tags: list[str]
    country: Optional[str]
    detected_at: Optional[str]
    ui_url: Optional[str]
    
    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Signal":
        return cls(
            signal_id=str(d.get("signal_id", d.get("id", ""))),
            domain=d.get("domain", ""),
            company_name=d.get("company_name") or d.get("title"),
            category=d.get("category"),
            signal_score=int(d.get("signal_score", 0)),
            intent_tags=d.get("intent_tags") or [],
            country=d.get("country"),
            detected_at=d.get("detected_at") or d.get("discovered_at"),
            ui_url=d.get("ui_url"),
        )


class PounceAgentDataClient:
    """
    Minimal dependency-free client for the Agent Data API.
    
    Args:
        api_key: Your Pounce API key (must start with pounce_live_)
        base_url: API base URL (default: https://api.pounce.ch)
    
    Raises:
        ValueError: If API key format is invalid
    """

    def __init__(self, *, api_key: str, base_url: str = "https://api.pounce.ch") -> None:
        self.api_key = str(api_key or "").strip()
        self.base_url = str(base_url or "").rstrip("/")
        if not self.api_key.startswith("pounce_live_"):
            raise ValueError("Invalid API key format (expected pounce_live_...)")

    def _extract_rate_limit(self, headers: Any) -> RateLimitInfo:
        """Extract rate limit info from response headers."""
        def _int(h: str) -> Optional[int]:
            v = headers.get(h)
            try:
                return int(v) if v is not None else None
            except Exception:
                return None
        
        return RateLimitInfo(
            limit=_int("X-RateLimit-Limit"),
            remaining=_int("X-RateLimit-Remaining"),
            reset_unix=_int("X-RateLimit-Reset"),
        )

    def _request_get(
        self, path: str, params: Optional[dict[str, Any]] = None
    ) -> Tuple[dict[str, Any], RateLimitInfo]:
        """Make a GET request to the API."""
        q = urllib.parse.urlencode(params or {}, doseq=True)
        url = f"{self.base_url}{path}"
        if q:
            url = url + "?" + q

        req = urllib.request.Request(url, method="GET")
        req.add_header("Authorization", f"Bearer {self.api_key}")
        req.add_header("Accept", "application/json")

        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            data = json.loads(raw) if raw else {}
            rl = self._extract_rate_limit(resp.headers)
            return data, rl

    def _request_post(
        self, path: str, body: dict[str, Any]
    ) -> Tuple[dict[str, Any], RateLimitInfo]:
        """Make a POST request to the API."""
        url = f"{self.base_url}{path}"
        body_bytes = json.dumps(body).encode("utf-8")

        req = urllib.request.Request(url, data=body_bytes, method="POST")
        req.add_header("Authorization", f"Bearer {self.api_key}")
        req.add_header("Accept", "application/json")
        req.add_header("Content-Type", "application/json")

        with urllib.request.urlopen(req, timeout=60) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            data = json.loads(raw) if raw else {}
            rl = self._extract_rate_limit(resp.headers)
            return data, rl

    # -------------------------------------------------------------------------
    # Public API Methods
    # -------------------------------------------------------------------------

    def recent_signals(
        self,
        *,
        hours: int = 24,
        limit: int = 100,
        min_score: int = 50,
        category: Optional[str] = None,
        country: Optional[str] = None,
        tlds: Optional[list[str]] = None,
    ) -> Tuple[dict[str, Any], RateLimitInfo]:
        """
        Get recent B2B signals.
        
        Args:
            hours: Look back period in hours (default: 24)
            limit: Max results (1-100, default: 100)
            min_score: Minimum signal score (0-100, default: 50)
            category: Filter by category (e.g., "saas", "ecommerce")
            country: Filter by ISO country code (e.g., "US", "DE")
            tlds: Filter by TLDs (e.g., ["com", "io"])
        
        Returns:
            Tuple of (response_data, rate_limit_info)
        """
        params: dict[str, Any] = {
            "hours": hours,
            "limit": limit,
            "min_score": min_score,
        }
        if category:
            params["category"] = category
        if country:
            params["country"] = country
        if tlds:
            params["tlds"] = ",".join(tlds)
        
        return self._request_get("/api/v1/agent-data/recent", params)

    def search(
        self,
        query: str,
        *,
        limit: int = 20,
        min_score: int = 50,
        category: Optional[str] = None,
        country: Optional[str] = None,
        tlds: Optional[list[str]] = None,
    ) -> Tuple[dict[str, Any], RateLimitInfo]:
        """
        Semantic search for signals.
        
        Args:
            query: Natural language search query
            limit: Max results (1-100, default: 20)
            min_score: Minimum signal score (0-100, default: 50)
            category: Filter by category
            country: Filter by ISO country code
            tlds: Filter by TLDs
        
        Returns:
            Tuple of (response_data, rate_limit_info)
        
        Example:
            data, rl = client.search("AI startups in healthcare", limit=10)
            for item in data["items"]:
                print(f"{item['domain']}: {item['similarity']:.2f}")
        """
        body: dict[str, Any] = {
            "query": query,
            "limit": limit,
            "min_score": min_score,
        }
        filters: dict[str, Any] = {}
        if category:
            filters["category"] = category
        if country:
            filters["country"] = country
        if tlds:
            filters["tlds"] = tlds
        if filters:
            body["filters"] = filters
        
        return self._request_post("/api/v1/agent-data/search/semantic", body)

    def signal_detail(self, signal_id: str) -> Tuple[dict[str, Any], RateLimitInfo]:
        """
        Get full details for a specific signal.
        
        Args:
            signal_id: The signal ID
        
        Returns:
            Tuple of (signal_data, rate_limit_info)
        """
        return self._request_get(f"/api/v1/agent-data/signals/{signal_id}")

    def usage(self) -> Tuple[dict[str, Any], RateLimitInfo]:
        """
        Get API usage information for your account.
        
        Returns:
            Tuple of (usage_data, rate_limit_info)
        """
        return self._request_get("/api/v1/agent-data/usage")

    def stream(
        self,
        *,
        min_score: int = 50,
        category: Optional[str] = None,
        since: Optional[str] = None,
        timeout: int = 300,
    ) -> Generator[Signal, None, None]:
        """
        Stream new signals in real-time via SSE.
        
        Args:
            min_score: Minimum signal score (0-100, default: 50)
            category: Filter by category
            since: Resume from cursor (for reconnects)
            timeout: Connection timeout in seconds (default: 300)
        
        Yields:
            Signal objects as they're detected
        
        Example:
            for signal in client.stream(min_score=70):
                print(f"New: {signal.domain} (score={signal.signal_score})")
        
        Note:
            This is a blocking generator. Use in a separate thread if needed.
        """
        params: dict[str, Any] = {"min_score": min_score}
        if category:
            params["category"] = category
        if since:
            params["since"] = since
        
        q = urllib.parse.urlencode(params)
        url = f"{self.base_url}/api/v1/agent-data/streams/signals?{q}"
        
        req = urllib.request.Request(url, method="GET")
        req.add_header("Authorization", f"Bearer {self.api_key}")
        req.add_header("Accept", "text/event-stream")
        
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            event_type = None
            data_buffer = []
            
            for line_bytes in resp:
                line = line_bytes.decode("utf-8", errors="replace").rstrip("\r\n")
                
                # Skip empty lines and comments
                if not line:
                    # End of event - process buffered data
                    if event_type == "signal" and data_buffer:
                        try:
                            raw_data = "\n".join(data_buffer)
                            parsed = json.loads(raw_data)
                            yield Signal.from_dict(parsed)
                        except json.JSONDecodeError:
                            pass
                    event_type = None
                    data_buffer = []
                    continue
                
                if line.startswith(":"):
                    # Comment (heartbeat)
                    continue
                
                if line.startswith("event:"):
                    event_type = line[6:].strip()
                elif line.startswith("data:"):
                    data_buffer.append(line[5:].strip())

