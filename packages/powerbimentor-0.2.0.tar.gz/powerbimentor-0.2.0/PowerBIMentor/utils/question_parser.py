from typing import Dict, Optional

def parse_lesson_questions(lesson_text: str) -> Dict[str, Optional[str]]:
    import re

    result: Dict[str, Optional[str]] = {
        'text': None,
        'dax': None,
        'visual': None
    }

    lines = lesson_text.strip().split('\n')
    current_code = None
    questions = {
        'TEXT001': [],
        'DAX002': [],
        'VISUAL003': []
    }

    code_pattern = re.compile(r'"(TEXT001|DAX002|VISUAL003)"')

    for line in lines:
        line = line.strip()

        if not line or line.startswith('#') or line.startswith('**') or line.startswith('```'):
            continue

        code_match = code_pattern.search(line)
        if code_match:
            current_code = code_match.group(1)
            continue

        if current_code and line and line[0].isdigit():
            if '. ' in line:
                questions[current_code].append(line)

    if questions['TEXT001']:
        result['text'] = '\n'.join(questions['TEXT001'])
    if questions['DAX002']:
        result['dax'] = '\n'.join(questions['DAX002'])
    if questions['VISUAL003']:
        result['visual'] = '\n'.join(questions['VISUAL003'])

    return result