from pprint import pprint
from PowerBIMentor import PowerBIMentor

questions = """
    ## Lesson 7  
    **Topic:** Project 1 - Basic Sales Dashboard  
    **Prerequisites:** Download Retail_sales_data.xlsx file  
    
    "TEXT001"
    1. What is the purpose of the "Data/Model" view in Power BI?  
    2. Troubleshoot: Slicers not affecting all visuals—how to fix? 
    
    "DAX002"
    3. Import Retail_Sales_Data.xlsx into Power BI.  
    
    "VISUAL003"
    4. Create a table visual showing Region and Sales.  
    5. Add a slicer for Product.  
    6. Format the dashboard theme to "Dark Mode."  
    7. Build a dashboard with:  
       - A bar chart of Sales by Region.  
       - A line chart of Sales over Date.  
       - A card showing total Profit.  
    8. Add a drill-through filter from Region to a detailed sales page.  
    9. Use conditional formatting to highlight high-profit regions.  
    
    "DAX002"
    10. Publish the dashboard to Power BI Service.  
    11. Share the report with a colleague (simulate steps).  
    12. Add a custom "Sales Growth %" measure without DAX (use Quick Measures).  
    13. Optimize the dataset for faster refresh (e.g., remove unused columns).  
    14. Embed the dashboard into a PowerPoint presentation.  
    15. Set up a scheduled refresh for the dataset in Power BI Service.  
    
    ```Retail_Sales_Data```
    | OrderID | Date       | Product  | Region | Sales | Profit |
    |---------|------------|----------|--------|-------|--------|
    | 2001    | 1/1/2023   | Laptop   | North  | 1200  | 300    |
    | 2002    | 1/5/2023   | Mouse    | South  | 125   | 25     |
    | 2003    | 1/10/2023  | Keyboard | East   | 80    | 15     |
"""

prompts = {
        "dax": """You are evaluating a Power BI DAX assignment submission. Assess the following:
    
    CORRECTNESS (70 points):
    - Does the DAX formula produce accurate results?
    - Are calculations logically sound?
    - Does it handle edge cases (blanks, errors)?
    
    BEST PRACTICES (10 points):
    - Proper use of measure vs calculated column
    - Efficient use of functions (CALCULATE, FILTER, iterators)
    - Appropriate use of time intelligence functions
    - Code readability and formatting
    
    PERFORMANCE (10 points):
    - Avoidance of inefficient patterns (nested iterations, row context in measures)
    - Proper filter context management
    - Use of variables where appropriate
    
    REQUIREMENTS ALIGNMENT (10 points):
    - Does it fully address the question requirements?
    - Are all requested metrics/calculations included?
    
    Provide a score out of 100 and concise feedback (50-75 words) highlighting what was done well and what needs improvement.""",

        "visual": """You are evaluating a Power BI dashboard/visual submission. Assess the following:
    
    CHART SELECTION (25 points):
    - Are chart types appropriate for the data being displayed?
    - Does the visualization effectively communicate insights?
    - Proper use of visuals for comparison, trends, composition, or distribution
    
    DESIGN & LAYOUT (25 points):
    - Clean, professional appearance
    - Logical flow and visual hierarchy
    - Effective use of white space
    - Consistent styling and colors
    
    FUNCTIONALITY (25 points):
    - Proper use of slicers, filters, and drill-through
    - Interactivity enhances user experience
    - Cross-filtering works correctly
    - Titles and labels are clear
    
    DATA STORYTELLING (15 points):
    - Dashboard tells a coherent story
    - Key insights are immediately visible
    - Appropriate level of detail
    
    REQUIREMENTS ALIGNMENT (10 points):
    - Does it meet all specified requirements?
    - Are all requested visuals included?
    
    Provide a score out of 100 and concise feedback (50-75 words) highlighting strengths and areas for improvement.""",

        "text": """You are evaluating a written response about Power BI concepts. Assess the following:
    
    ACCURACY (70 points):
    - Is the information technically correct?
    - Are concepts explained accurately?
    - No significant misconceptions or errors
    
    COMPLETENESS (15 points):
    - Does the answer fully address the question?
    - Are key points covered?
    - Appropriate level of detail
    
    CLARITY ( 15 points):
    - Is the explanation clear and well-organized?
    - Easy to understand for the target audience
    - Good use of examples where appropriate
    
    REQUIREMENTS ALIGNMENT (10 points):
    - Directly answers what was asked
    - Stays on topic
    
    Provide a score out of 100 and concise feedback (50-75 words) on accuracy, completeness, and clarity.""",
}

mentor = PowerBIMentor(api_key="AIzaSyBvxUcdEROsyOCYOzY1L9exx9RjEmk7iGI", model_name="gemini-2.5-flash-lite")

results = mentor.evaluate_all(
    answer_path="files/lesson-9",
    questions=questions,
    prompts=prompts
)

pprint(results)