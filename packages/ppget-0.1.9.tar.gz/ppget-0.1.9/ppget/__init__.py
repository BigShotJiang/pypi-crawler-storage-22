"""
ppget - A simple CLI tool to download PubMed articles
"""

__version__ = "0.1.9"
