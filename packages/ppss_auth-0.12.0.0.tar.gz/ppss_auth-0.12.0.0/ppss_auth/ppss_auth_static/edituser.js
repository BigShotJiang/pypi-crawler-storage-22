function sendForm(event) {
  const form = event.target;
  const url = new URL(form.action || window.location.href);
  const formData = new FormData(form, event.submitter);
  const searchParameters = new URLSearchParams(formData);

  const options = {
    method: form.method,
    headers: new Headers({
      Accept: "application/json",
      "X-CSRF-Token": document.querySelector('input[name="X-CSRF-Token"]')
        .value,
    }),
  };

  if (options.method === "post") {
    // Modify request body to include form data
    options.body =
      form.enctype === "multipart/form-data" ? formData : searchParameters;
  } else {
    // Modify URL to include form data
    url.search = searchParameters;
  }

  const alert = form.querySelector(".auth-alert");
  const submit = form.querySelector('[type="submit"]');
  alert.hidden = true;
  submit.disabled = true;
  submit.dataset.originalInnerHTML = submit.innerHTML;
  submit.innerHTML = 'Please wait... <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';

  fetch(url, options)
    .then((response) => response.json())
    .then((json) => {
      console.log(json);
      if (json.res) {
        alert.classList.remove("auth-alert-danger");
        alert.classList.add("auth-alert-success");
      } else {
        alert.classList.remove("auth-alert-success");
        alert.classList.add("auth-alert-danger");
        form.reset();
      }
      alert.textContent = json.msg;
      alert.hidden = false;
    })
    .catch( (error) => {
      console.warn(error);
      alert.classList.remove("auth-alert-success");
      alert.classList.add("auth-alert-danger");
      alert.textContent = "An error occurred. Please try again later.";
      alert.hidden = false;
    })
    .finally( () => {
      submit.disabled = false;
      submit.innerHTML = submit.dataset.originalInnerHTML;
    });
  event.preventDefault();
}

document.addEventListener("submit", (event) => {
  if (event.target.matches("form[data-ajax-form]")) {
    sendForm(event);
  }
});
