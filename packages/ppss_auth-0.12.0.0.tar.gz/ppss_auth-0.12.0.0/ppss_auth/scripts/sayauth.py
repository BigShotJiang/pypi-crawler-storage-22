def sayitnow():
  print("auth")