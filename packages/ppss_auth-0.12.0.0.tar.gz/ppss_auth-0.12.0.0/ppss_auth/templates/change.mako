<%inherit file="${context['logintpl']}" />
<div class="auth-container">
  <div class="auth-row auth-text-center">
      <div class="auth-col-12 auth-col-md-4 auth-offset-md-4">
        <form action="${request.route_url('ppss:user:changepassword')}" method="POST" class="ppssauthform">
            <input type="hidden" value="${get_csrf_token()}" name="csrf_token">
            <h2>${_("Change password for user {username}", domain='ppss_auth').format(username=request.loggeduser.username) }</h2>
            <input class="auth-form-control" type="password" name="oldpassword" autocomplete="off" placeholder="${_('current password', domain='ppss_auth')}">
            <br/>
            <input class="auth-form-control" type="password" name="newpassword" autocomplete="off" placeholder="${_('new password', domain='ppss_auth')}">
            <br/>
            <input class="auth-form-control" type="password" name="confirmnewpassword" autocomplete="off" placeholder="${_('confirm new password', domain='ppss_auth')}">
            <br/>
            <div class="auth-text-center">
              <input class="auth-btn auth-btn-primary" type="submit" name="submit" value="${_('update', domain='ppss_auth')}"/>
            </div>
            %if msg:
            <div class="auth-alert auth-mt-3 ${'auth-alert-success' if res else 'auth-alert-danger'}" role="alert">
            <p>${msg}</p>
            </div>
            %endif
        </form>
      </div>
  </div>
</div>
