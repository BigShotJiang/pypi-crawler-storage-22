<%inherit file="${context['midtpl']}" />
<div class="auth-row">
    <div class="auth-col-12">
        <div class="auth-alert auth-alert-${msg_type}" role="alert">
            ${msg}
            % if redirect_url:
                <a href="${redirect_url}">Redirecting...</a>
            % endif
            % if login_url:
                <a href="${login_url}">Login</a>
            % endif
        </div>
    </div>
</div>
% if redirect_url:
    <script>
        setTimeout(function() {
            window.location.href = "${redirect_url}";
        }, 3000);
    </script>
% endif

