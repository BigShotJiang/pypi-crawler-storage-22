<%inherit file="${context['midtpl']}" />

<div class="auth-container">
    <div class="auth-row auth-text-center">
        <div class="auth-col-12 auth-col-md-8 offset-md-2">
            %if errmsg:
            <div class="auth-alert auth-alert-danger auth-my-2">
                ${errmsg}
            </div>
            %endif
            <h3 class="auth-mt-3 auth-mb-0">Enable 2FA authentication</h3>
            <p class="auth-mb-3">It seems you don't have 2fa enabled, please follow these steps:</p>
            <p>1. Download an authenticator app on your phone, below are listed some for your convenience </p>
            <%include  file='partials/auth-apps.html' />
            <p>2. Add new account and scan the QR code below or manually add the uri</p>
            <img class="auth-img-fluid" width="200" height="200" src="${img_str}" alt="">
            <p class="auth-small auth-mb-3"> SECRET KEY: ${otp_hash}</p>
            <p>3. Enter the 6 digit code provided by your authenticator</p>
            <form method="post">
                <input type="hidden" value="${get_csrf_token()}" name="csrf_token">
                <input type="hidden" name="otp_hash" value="${otp_hash}">
                <%include file='partials/otp.html' />
                <button class="auth-btn auth-btn-success auth-my-3" type="submit">Confirm</button>
            </form>
        </div>
    </div>
</div>