<%inherit file="${context['logintpl']}" />
<div class="auth-container">
    <div class="auth-row auth-text-center">
        <div class="auth-col-12 auth-col-md-4 auth-offset-md-4">
            <form class="auth-my-5" action="${request.route_url('ppsslogin')}" method="POST" class="loginform">
                <input type="hidden" value="${get_csrf_token()}" name="csrf_token">
                <h1 class="auth-h3 auth-mb-3 auth-font-weight-normal">${_("Please sign in", domain='ppss_auth')}</h1>
                
                % if request.usersession.invalidusersession: 
                    <p>
                        ${_("Your session has expired, please login again with the same user to restore your session.", domain='ppss_auth')}
                    </p>
                % elif request.loggeduser:
                    <p>             
                            ${_('You are already logged in as', domain='ppss_auth')} <a href="${request.route_url('ppss:user:editself')}">${request.loggeduser.username}</a>. <a href="${request.route_url('ppsslogout')}">Logout</a>?<br/>
                            ${signinreason |n}<br/>
                            ${_("You can proceed to your main page following this ") }<a href="${request.route_url(request.ppssauthconf.postloginroute)}">${_("link")}</a>.<br/>                
                    </p>
                % endif
                <input class="auth-form-control" type="text" name="username" placeholder="${_('username', domain='ppss_auth')}" class="auth-form-control">
                <br/>
                <input class="auth-form-control" type="password" name="password" autocomplete="off" placeholder="${_('password', domain='ppss_auth')}" class="auth-form-control">
                <br/>
                % if isCaptchaEnabled:
                <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
                <div class="cf-turnstile" data-sitekey="${ppsauthconf.turnstile_sitekey}"></div>
                % endif
                % if email_is_required:
                <p>${_('Forgot password ?',domain='ppss_auth')}   
                <a href="${request.route_url('ppss:user:recoverpassword')}">${_('recover',domain='ppss_auth')}</a></p>
                % endif
                <div class="auth-text-center">
                    <input class="auth-btn auth-btn-success" type="submit" name="submit" value="${_('Login', domain='ppss_auth')}"/>
                    % if ppsauthconf.usercanregister:
                    <br>
                    <small>${_('Not registered yet?', domain='ppss_auth')} <a href="${request.route_url('ppss:user:register')}">${_('Register now', domain='ppss_auth')}</a></small>
                    % endif
                </div>
                <br/>
                <p class="auth-text-danger">${msg}</p>
            </form>
        </div>
    </div>
</div>