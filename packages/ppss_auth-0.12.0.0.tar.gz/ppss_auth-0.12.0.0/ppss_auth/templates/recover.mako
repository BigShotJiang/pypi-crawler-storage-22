<%inherit file="${context['logintpl']}" />
<div class="auth-row">
    <div class="auth-col-12">
        <div class="auth-d-flex auth-mt-1">
            <div class="auth-m-auto">
                <h1 class="auth-h3 auth-mb-3 auth-font-weight-normal">${_("Recover password",domain='ppss_auth')}</h1>
                <p>${_("Please fill with your email to recover password",domain='ppss_auth')}</p>
                <br>
                <form method="POST" class="loginform ppssauthform">
                    <input type="hidden" value="${get_csrf_token()}" name="csrf_token">

                    <label for="reset-email">Email</label>
                    <input id="reset-email" class="auth-form-control" type="email" name="email"
                        placeholder="${_('email', domain='ppss_auth')}" required>
                    </br>

                    <div class="auth-text-center">
                        <input class="auth-btn auth-btn-success" type="submit" name="submit"
                            value="${_('Recover', domain='ppss_auth')}" />
                    </div>

                    </br>
                    <p class="auth-text-danger">
                        ${msg}

                    </p>
                </form>
            </div>
        </div>
    </div>
</div>