<%inherit file="${context['logintpl']}" />
<div class="auth-row">
    <div class="auth-col-12">
        <form action="${request.route_url('ppss:user:register')}" method="POST" class="loginform ppssauthform">
            <input type="hidden" value="${get_csrf_token()}" name="csrf_token">
            <input class="auth-form-control" type="text" name="username" placeholder="${_('username', domain='ppss_auth')}" class="auth-form-control" required="">
            <br/>
            <input class="auth-form-control" type="email" name="email" placeholder="${_('email', domain='ppss_auth')}" ${ 'required' if email_is_required else '' } >
            </br>
            <input class="auth-form-control" type="password" name="password" placeholder="${_('password', domain='ppss_auth')}" class="auth-form-control" required="">
            <br/>
            <input class="auth-form-control" type="password" name="confirmnewpassword" placeholder="${_('confirm new password', domain='ppss_auth')}" required="">
            <br/>
            <div class="auth-text-center">
                <input class="auth-btn auth-btn-success" type="submit" name="submit" value="${_('Register', domain='ppss_auth')}"/>
            </div>


            </br>
            <p class="auth-text-danger">
                ${msg}
                % if link[0]:
                    <a href="${link[1]}">${link[0]}</a>
                % endif
            </p>
        </form>
    </div>
</div>
