<%inherit file="${context['logintpl']}" />
<div class="auth-row">
    <div class="auth-col-12">
        <div class="auth-d-flex auth-mt-1">
            <div class="auth-m-auto auth-text-center auth-w-50">
                <h1 class="auth-h3 auth-mb-3 auth-font-weight-normal">${_("Reset password",domain='ppss_auth')}</h1>

                <form method="POST" class="loginform ppssauthform">
                    <input type="hidden" value="${get_csrf_token()}" name="csrf_token">
                    <input type="hidden" name="reset-token" value="${token}">
                    <input class="auth-form-control" type="password" name="newpassword" autocomplete="off"
                        placeholder="${_('new password', domain='ppss_auth')}" required>
                    <br />
                    <input class="auth-form-control" type="password" name="confirmnewpassword" autocomplete="off"
                        placeholder="${_('confirm new password', domain='ppss_auth')}" required>
                    <br />

                    <div class="auth-alert auth-alert-info">
                        ${password_requirements}
                    </div>

                    <div class="auth-text-center">
                        <input class="auth-btn auth-btn-success" type="submit" name="submit"
                            value="${_('Reset', domain='ppss_auth')}" />
                    </div>

                    </br>

                </form>
                <p class="auth-text-danger">
                    ${msg}
                    % if login_url:
                    <a href="${login_url}">Login</a>
                    % endif
                </p>
            </div>
        </div>
    </div>
</div>