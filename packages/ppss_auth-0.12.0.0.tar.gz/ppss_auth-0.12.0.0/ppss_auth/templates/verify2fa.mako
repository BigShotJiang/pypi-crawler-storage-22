<%inherit file="${context['logintpl']}" />

<div class="auth-container">
    <div class="auth-row auth-text-center">
        <div class="auth-col-12 auth-col-md-4 auth-offset-md-4">
            <form class="auth-my-5" method="POST" class="loginform">
                <input type="hidden" value="${get_csrf_token()}" name="csrf_token">
                <h1 class="auth-h3 auth-mb-3 auth-font-weight-normal">${_("Verify OTP",domain='ppss_auth')}</h1>
                <%include file='partials/otp.html' />
                <div class="auth-text-center">
                    <input class="auth-btn auth-btn-success" type="submit" name="submit" value='${_("Verify",domain='ppss_auth')}'/>
                </div>
                </br>
                <p class="auth-text-danger">${msg}</p>
            </form>
        </div>
    </div>
</div>

