"""Deck archetype definitions — structured templates for common deck types."""

from __future__ import annotations

from dataclasses import dataclass, field

from pptx_mcp.models.slides import SlideType


@dataclass(frozen=True)
class SlideSlot:
    """A slot in a deck archetype's structure."""
    slide_type: SlideType
    title_template: str
    required: bool = True


@dataclass(frozen=True)
class DeckArchetype:
    """Template for a specific kind of presentation."""
    name: str
    display_name: str
    description: str
    slots: tuple[SlideSlot, ...]
    min_slides: int = 5
    max_slides: int = 20


ARCHETYPES: dict[str, DeckArchetype] = {
    "pitch_deck": DeckArchetype(
        name="pitch_deck",
        display_name="Pitch Deck",
        description="Investor/stakeholder pitch with problem, solution, traction, team, and ask.",
        min_slides=8,
        max_slides=15,
        slots=(
            SlideSlot(SlideType.TITLE, "Company Pitch"),
            SlideSlot(SlideType.CONTENT, "The Problem"),
            SlideSlot(SlideType.CONTENT, "Our Solution"),
            SlideSlot(SlideType.BIG_NUMBER, "Traction"),
            SlideSlot(SlideType.IMAGE_TEXT, "Product Overview"),
            SlideSlot(SlideType.DASHBOARD, "Key Metrics"),
            SlideSlot(SlideType.ICON_GRID, "Why Us"),
            SlideSlot(SlideType.CHART, "Market Opportunity"),
            SlideSlot(SlideType.TEAM, "The Team"),
            SlideSlot(SlideType.CLOSING, "The Ask", required=False),
        ),
    ),
    "board_deck": DeckArchetype(
        name="board_deck",
        display_name="Board Update",
        description="Quarterly board update with financials, strategy, and operational review.",
        min_slides=8,
        max_slides=20,
        slots=(
            SlideSlot(SlideType.TITLE, "Board Update"),
            SlideSlot(SlideType.AGENDA, "Agenda"),
            SlideSlot(SlideType.DASHBOARD, "Financial Overview"),
            SlideSlot(SlideType.CHART, "Revenue & Growth"),
            SlideSlot(SlideType.PROCESS, "Strategic Initiatives"),
            SlideSlot(SlideType.SWOT, "Strategic Assessment"),
            SlideSlot(SlideType.CONTENT, "Operational Highlights"),
            SlideSlot(SlideType.CONTENT, "Risks & Mitigations"),
            SlideSlot(SlideType.CLOSING, "Next Steps"),
        ),
    ),
    "sales_deck": DeckArchetype(
        name="sales_deck",
        display_name="Sales Deck",
        description="Customer-facing sales presentation with value proposition and social proof.",
        min_slides=7,
        max_slides=15,
        slots=(
            SlideSlot(SlideType.TITLE, "Sales Presentation"),
            SlideSlot(SlideType.CONTENT, "The Challenge"),
            SlideSlot(SlideType.STEP_CARDS, "Our Approach"),
            SlideSlot(SlideType.COMPARISON, "Why Choose Us"),
            SlideSlot(SlideType.DASHBOARD, "Results"),
            SlideSlot(SlideType.QUOTE, "What Customers Say"),
            SlideSlot(SlideType.TABLE, "Pricing"),
            SlideSlot(SlideType.CLOSING, "Get Started"),
        ),
    ),
    "all_hands": DeckArchetype(
        name="all_hands",
        display_name="All-Hands Meeting",
        description="Company-wide update with achievements, metrics, and team recognition.",
        min_slides=7,
        max_slides=20,
        slots=(
            SlideSlot(SlideType.TITLE, "All-Hands Meeting"),
            SlideSlot(SlideType.AGENDA, "Agenda"),
            SlideSlot(SlideType.ICON_GRID, "Highlights"),
            SlideSlot(SlideType.DASHBOARD, "Key Metrics"),
            SlideSlot(SlideType.TIMELINE, "Roadmap"),
            SlideSlot(SlideType.TEAM, "New Joiners", required=False),
            SlideSlot(SlideType.CLOSING, "Thank You"),
        ),
    ),
    "project_update": DeckArchetype(
        name="project_update",
        display_name="Project Update",
        description="Status update with progress, timeline, and risk assessment.",
        min_slides=6,
        max_slides=15,
        slots=(
            SlideSlot(SlideType.TITLE, "Project Update"),
            SlideSlot(SlideType.AGENDA, "Agenda"),
            SlideSlot(SlideType.CONTENT, "Executive Summary"),
            SlideSlot(SlideType.PROCESS, "Current Status"),
            SlideSlot(SlideType.TIMELINE, "Project Timeline"),
            SlideSlot(SlideType.PROS_CONS, "Risks & Mitigations"),
            SlideSlot(SlideType.CLOSING, "Next Steps"),
        ),
    ),
    "training": DeckArchetype(
        name="training",
        display_name="Training Deck",
        description="Educational presentation with structured lessons and exercises.",
        min_slides=6,
        max_slides=25,
        slots=(
            SlideSlot(SlideType.TITLE, "Training Session"),
            SlideSlot(SlideType.AGENDA, "Learning Objectives"),
            SlideSlot(SlideType.CONTENT, "Introduction"),
            SlideSlot(SlideType.STEP_CARDS, "Key Concepts"),
            SlideSlot(SlideType.SECTION, "Practice"),
            SlideSlot(SlideType.CONTENT, "Summary"),
            SlideSlot(SlideType.CLOSING, "Next Steps"),
        ),
    ),
    "strategy_deck": DeckArchetype(
        name="strategy_deck",
        display_name="Strategy Deck",
        description="Strategic analysis and recommendations with current state, gap analysis, and roadmap.",
        min_slides=8,
        max_slides=25,
        slots=(
            SlideSlot(SlideType.TITLE, "Strategic Recommendation"),
            SlideSlot(SlideType.AGENDA, "Agenda"),
            SlideSlot(SlideType.CONTENT, "Executive Summary"),
            SlideSlot(SlideType.DASHBOARD, "Current State Assessment"),
            SlideSlot(SlideType.SWOT, "Strategic Assessment"),
            SlideSlot(SlideType.CONTENT, "Gap Analysis"),
            SlideSlot(SlideType.COMPARISON, "Strategic Options"),
            SlideSlot(SlideType.CONTENT, "Recommendation"),
            SlideSlot(SlideType.PROCESS, "Implementation Approach"),
            SlideSlot(SlideType.TIMELINE, "Execution Roadmap"),
            SlideSlot(SlideType.PROS_CONS, "Risk Assessment"),
            SlideSlot(SlideType.CLOSING, "Next Steps"),
        ),
    ),
    "due_diligence": DeckArchetype(
        name="due_diligence",
        display_name="Due Diligence Report",
        description="Investment due diligence with financial analysis, market assessment, and risk evaluation.",
        min_slides=10,
        max_slides=30,
        slots=(
            SlideSlot(SlideType.TITLE, "Due Diligence Report"),
            SlideSlot(SlideType.AGENDA, "Scope & Methodology"),
            SlideSlot(SlideType.CONTENT, "Executive Summary"),
            SlideSlot(SlideType.DASHBOARD, "Financial Overview"),
            SlideSlot(SlideType.CHART, "Revenue & Profitability"),
            SlideSlot(SlideType.CONTENT, "Market Position"),
            SlideSlot(SlideType.FUNNEL, "Customer Pipeline"),
            SlideSlot(SlideType.SWOT, "Risk Assessment"),
            SlideSlot(SlideType.COMPARISON, "Peer Comparison"),
            SlideSlot(SlideType.TABLE, "Key Findings Summary"),
            SlideSlot(SlideType.PROS_CONS, "Investment Considerations"),
            SlideSlot(SlideType.CLOSING, "Recommendation"),
        ),
    ),
    "market_analysis": DeckArchetype(
        name="market_analysis",
        display_name="Market Analysis",
        description="Market sizing, competitive landscape, and opportunity assessment.",
        min_slides=8,
        max_slides=20,
        slots=(
            SlideSlot(SlideType.TITLE, "Market Analysis"),
            SlideSlot(SlideType.AGENDA, "Agenda"),
            SlideSlot(SlideType.BIG_NUMBER, "Market Size"),
            SlideSlot(SlideType.CHART, "Market Growth Trends"),
            SlideSlot(SlideType.FUNNEL, "Market Segments"),
            SlideSlot(SlideType.COMPARISON, "Competitive Landscape"),
            SlideSlot(SlideType.DASHBOARD, "Competitor Metrics"),
            SlideSlot(SlideType.CONTENT, "Key Findings"),
            SlideSlot(SlideType.ICON_GRID, "Market Opportunities"),
            SlideSlot(SlideType.TIMELINE, "Market Evolution"),
            SlideSlot(SlideType.CLOSING, "Strategic Implications"),
        ),
    ),
    "org_design": DeckArchetype(
        name="org_design",
        display_name="Org Design Review",
        description="Organizational structure analysis, capability assessment, and transformation plan.",
        min_slides=8,
        max_slides=20,
        slots=(
            SlideSlot(SlideType.TITLE, "Organizational Review"),
            SlideSlot(SlideType.AGENDA, "Agenda"),
            SlideSlot(SlideType.CONTENT, "Current Organization"),
            SlideSlot(SlideType.DASHBOARD, "Capability Assessment"),
            SlideSlot(SlideType.COMPARISON, "Operating Model Options"),
            SlideSlot(SlideType.PROCESS, "Transition Plan"),
            SlideSlot(SlideType.TEAM, "Leadership Structure"),
            SlideSlot(SlideType.ICON_GRID, "Key Capabilities"),
            SlideSlot(SlideType.TIMELINE, "Transformation Roadmap"),
            SlideSlot(SlideType.PROS_CONS, "Change Impact"),
            SlideSlot(SlideType.CLOSING, "Recommendations"),
        ),
    ),
    "competitive_assessment": DeckArchetype(
        name="competitive_assessment",
        display_name="Competitive Assessment",
        description="Competitive intelligence with positioning analysis and strategic response.",
        min_slides=8,
        max_slides=18,
        slots=(
            SlideSlot(SlideType.TITLE, "Competitive Assessment"),
            SlideSlot(SlideType.AGENDA, "Agenda"),
            SlideSlot(SlideType.DASHBOARD, "Market Overview"),
            SlideSlot(SlideType.COMPARISON, "Competitor Comparison"),
            SlideSlot(SlideType.TABLE, "Feature Matrix"),
            SlideSlot(SlideType.CHART, "Market Share Analysis"),
            SlideSlot(SlideType.SWOT, "Competitive Position"),
            SlideSlot(SlideType.CONTENT, "Key Differentiators"),
            SlideSlot(SlideType.ICON_GRID, "Strategic Response"),
            SlideSlot(SlideType.CLOSING, "Action Plan"),
        ),
    ),
    "transformation_roadmap": DeckArchetype(
        name="transformation_roadmap",
        display_name="Transformation Roadmap",
        description="Business transformation plan with vision, current state, and phased implementation.",
        min_slides=8,
        max_slides=25,
        slots=(
            SlideSlot(SlideType.TITLE, "Transformation Roadmap"),
            SlideSlot(SlideType.AGENDA, "Agenda"),
            SlideSlot(SlideType.CONTENT, "Vision & Objectives"),
            SlideSlot(SlideType.DASHBOARD, "Current State Baseline"),
            SlideSlot(SlideType.CONTENT, "Target State"),
            SlideSlot(SlideType.PROCESS, "Transformation Pillars"),
            SlideSlot(SlideType.STEP_CARDS, "Key Initiatives"),
            SlideSlot(SlideType.TIMELINE, "Phased Roadmap"),
            SlideSlot(SlideType.DASHBOARD, "Expected Outcomes"),
            SlideSlot(SlideType.PROS_CONS, "Risks & Mitigations"),
            SlideSlot(SlideType.CLOSING, "Call to Action"),
        ),
    ),
}
