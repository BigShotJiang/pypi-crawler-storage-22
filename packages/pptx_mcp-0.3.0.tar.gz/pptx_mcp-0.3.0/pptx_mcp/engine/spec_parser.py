"""Markdown spec parser — converts structured markdown presentation specs into PresentationDefinitions.

Two-layer architecture:
  1. Structural extraction: Parse markdown into NormalizedSpec IR (slides, tokens, global config)
  2. Semantic mapping: Convert NormalizedSpec into PresentationDefinition + BrandConfig

This enables agnostic intake of markdown specs regardless of which AI generated them.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

from pptx_mcp.models.brand import BrandConfig, ColorPalette, FontConfig, SpacingConfig
from pptx_mcp.models.slides import (
    CalloutBox,
    CardDefinition,
    ChartData,
    ChartDataSeries,
    ChartElement,
    ChartType,
    ColumnContent,
    KpiCard,
    PresentationDefinition,
    PresentationMetadata,
    ProcessStep,
    SlideDefinition,
    SlideType,
    TableCell,
    TableElement,
)
from pptx_mcp.utils.logging import get_logger

logger = get_logger("engine.spec_parser")


# ---------------------------------------------------------------------------
# Intermediate representation (IR) — the NormalizedSpec
# ---------------------------------------------------------------------------


@dataclass
class ColorToken:
    """A named color from the spec's design system."""
    name: str
    value: str
    usage: str = ""


@dataclass
class TypographyToken:
    """A named typography style from the spec's design system."""
    name: str
    font: str = ""
    size: int = 0
    weight: str = ""
    color_ref: str = ""


@dataclass
class ContentBlock:
    """A content block within a spec slide (text, bullet list, card, table, etc.)."""
    block_type: str  # "text", "bullets", "cards", "table", "kpi", "callout", "chart"
    content: dict = field(default_factory=dict)


@dataclass
class SpecSlide:
    """A slide definition from the parsed markdown spec."""
    number: int
    title: str
    layout_hint: str = ""  # e.g. "two-column-asymmetric", "card-grid", "full-width"
    content_blocks: list[ContentBlock] = field(default_factory=list)
    notes: str = ""
    background: str = ""


@dataclass
class GlobalConfig:
    """Global design system extracted from the spec."""
    colors: list[ColorToken] = field(default_factory=list)
    typography: list[TypographyToken] = field(default_factory=list)
    slide_dimensions: tuple[float, float] = (13.333, 7.5)


@dataclass
class NormalizedSpec:
    """The intermediate representation between raw markdown and PresentationDefinition."""
    title: str = ""
    subtitle: str = ""
    author: str = ""
    company: str = ""
    global_config: GlobalConfig = field(default_factory=GlobalConfig)
    slides: list[SpecSlide] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Layer 1: Structural extraction (markdown → NormalizedSpec)
# ---------------------------------------------------------------------------


_SLIDE_HEADER = re.compile(r"^##\s+Slide\s+(\d+)\s*[:\-–]\s*(.+)", re.IGNORECASE)
_COLOR_TOKEN = re.compile(r"[`*]*(\w[\w\s]*?)[`*]*\s*[:\-–]\s*[`#]*(#[0-9A-Fa-f]{6})[`]*")
_HEX_COLOR = re.compile(r"#[0-9A-Fa-f]{6}")


def _extract_global_config(lines: list[str]) -> GlobalConfig:
    """Extract color tokens, typography, and dimensions from the spec header."""
    config = GlobalConfig()
    in_colors = False
    in_typography = False

    for line in lines:
        stripped = line.strip()
        lower = stripped.lower()

        # Section detection
        if "color" in lower and ("palette" in lower or "token" in lower or "system" in lower):
            in_colors = True
            in_typography = False
            continue
        if "typograph" in lower or "font" in lower:
            in_colors = False
            in_typography = True
            continue
        if stripped.startswith("##"):
            in_colors = False
            in_typography = False
            continue

        if in_colors:
            m = _COLOR_TOKEN.search(stripped)
            if m:
                name = m.group(1).strip().lower().replace(" ", "_")
                value = m.group(2)
                usage = stripped
                config.colors.append(ColorToken(name=name, value=value, usage=usage))

        if in_typography:
            # Simple heuristic: look for size mentions
            size_match = re.search(r"(\d+)\s*pt", stripped, re.IGNORECASE)
            if size_match and ":" in stripped:
                parts = stripped.split(":", 1)
                name = parts[0].strip().strip("*`- ").lower().replace(" ", "_")
                config.typography.append(TypographyToken(
                    name=name,
                    size=int(size_match.group(1)),
                ))

    return config


def _parse_content_blocks(lines: list[str]) -> list[ContentBlock]:
    """Parse content blocks from slide body lines."""
    blocks: list[ContentBlock] = []
    current_bullets: list[str] = []
    current_card_title: str | None = None
    current_card_bullets: list[str] = []

    def _flush_bullets() -> None:
        nonlocal current_bullets
        if current_bullets:
            blocks.append(ContentBlock(block_type="bullets", content={"items": current_bullets}))
            current_bullets = []

    def _flush_card() -> None:
        nonlocal current_card_title, current_card_bullets
        if current_card_title:
            blocks.append(ContentBlock(
                block_type="card",
                content={"title": current_card_title, "bullets": current_card_bullets},
            ))
            current_card_title = None
            current_card_bullets = []

    for line in lines:
        stripped = line.strip()

        # Card block detection: ### heading starts a new card
        if stripped.startswith("### "):
            _flush_bullets()
            _flush_card()
            current_card_title = stripped.lstrip("# ").strip()
            continue

        # Callout detection: > **Note:** / > **Warning:** / > **Info:** / > **Success:**
        if stripped.startswith("> "):
            callout_text = stripped[2:].strip()
            callout_match = re.match(
                r"\*\*(Note|Warning|Info|Success|Tip)\s*[:\-–]*\s*\*\*\s*(.*)",
                callout_text, re.IGNORECASE,
            )
            if callout_match:
                _flush_bullets()
                _flush_card()
                variant_map = {"note": "info", "info": "info", "tip": "info", "warning": "warning", "success": "success"}
                variant = variant_map.get(callout_match.group(1).lower(), "info")
                blocks.append(ContentBlock(
                    block_type="callout",
                    content={"variant": variant, "body": callout_match.group(2).strip()},
                ))
                continue

        # Bullet items — route to card or top-level
        if stripped.startswith(("- ", "* ", "• ")):
            bullet_text = stripped.lstrip("-*• ").strip()
            if current_card_title is not None:
                current_card_bullets.append(bullet_text)
            else:
                current_bullets.append(bullet_text)
            continue

        # Flush accumulated bullets on non-bullet line
        if current_card_title is None and current_bullets and not stripped.startswith(("- ", "* ", "• ")):
            _flush_bullets()

        # Table detection (markdown pipes)
        if stripped.startswith("|") and stripped.endswith("|"):
            _flush_card()
            cells = [c.strip() for c in stripped.strip("|").split("|")]
            if cells and not all(set(c) <= {"-", ":", " "} for c in cells):
                if blocks and blocks[-1].block_type == "table":
                    blocks[-1].content["rows"].append(cells)
                else:
                    blocks.append(ContentBlock(block_type="table", content={"rows": [cells]}))
            continue

        # KPI / metric detection (number-heavy lines)
        if re.search(r"\d+[%$MKBkmb]", stripped) and len(stripped) < 80:
            _flush_card()
            blocks.append(ContentBlock(block_type="kpi", content={"text": stripped}))
            continue

        # Plain text
        if stripped and not stripped.startswith("#"):
            _flush_card()
            blocks.append(ContentBlock(block_type="text", content={"text": stripped}))

    # Flush remaining
    _flush_bullets()
    _flush_card()

    return blocks


def extract_spec(markdown: str) -> NormalizedSpec:
    """Parse a markdown presentation spec into a NormalizedSpec IR.

    Handles common markdown spec formats:
    - `## Slide N: Title` headers for slide boundaries
    - Color palettes in the global design section
    - Bullet lists, tables, and KPI blocks within slides
    """
    lines = markdown.split("\n")
    spec = NormalizedSpec()

    # Extract title from first H1
    for line in lines:
        if line.strip().startswith("# ") and not line.strip().startswith("##"):
            spec.title = line.strip().lstrip("# ").strip()
            break

    # Find the first slide header to split preamble from slides
    first_slide_idx = None
    for i, line in enumerate(lines):
        if _SLIDE_HEADER.match(line.strip()):
            first_slide_idx = i
            break

    # Extract global config from preamble
    preamble = lines[:first_slide_idx] if first_slide_idx else lines
    spec.global_config = _extract_global_config(preamble)

    # Extract slides
    if first_slide_idx is not None:
        slide_starts: list[tuple[int, int, str]] = []
        for i, line in enumerate(lines):
            m = _SLIDE_HEADER.match(line.strip())
            if m:
                slide_starts.append((i, int(m.group(1)), m.group(2).strip()))

        for idx, (start, num, title) in enumerate(slide_starts):
            end = slide_starts[idx + 1][0] if idx + 1 < len(slide_starts) else len(lines)
            body_lines = lines[start + 1:end]
            content_blocks = _parse_content_blocks(body_lines)

            spec.slides.append(SpecSlide(
                number=num,
                title=title,
                content_blocks=content_blocks,
            ))

    logger.info(
        "Extracted spec: %d slides, %d color tokens, %d typography tokens",
        len(spec.slides),
        len(spec.global_config.colors),
        len(spec.global_config.typography),
    )
    return spec


# ---------------------------------------------------------------------------
# Layer 2: Semantic mapping (NormalizedSpec → PresentationDefinition)
# ---------------------------------------------------------------------------


_TYPE_KEYWORDS: dict[str, list[str]] = {
    "title": ["title slide", "cover"],
    "section": ["section", "divider"],
    "dashboard": ["dashboard", "kpi", "metrics", "scorecard"],
    "chart": ["chart", "graph", "trend"],
    "table": ["table", "matrix", "comparison table"],
    "process": ["process", "workflow", "steps"],
    "timeline": ["timeline", "roadmap", "milestones"],
    "quote": ["quote", "testimonial"],
    "big_number": ["big number", "hero metric", "key stat"],
    "team": ["team", "leadership", "people"],
    "closing": ["closing", "thank you", "next steps", "contact"],
    "swot": ["swot"],
    "funnel": ["funnel", "pipeline"],
    "agenda": ["agenda"],
    "two_column": ["two column", "split", "side by side"],
    "pros_cons": ["pros", "cons", "advantages", "disadvantages"],
    "comparison": ["comparison", "versus", "vs"],
    "icon_grid": ["values", "pillars", "principles", "features"],
    "card_grid": ["card grid", "cards", "capabilities", "services", "offerings"],
}


def _infer_slide_type(title: str, blocks: list[ContentBlock]) -> SlideType:
    """Infer the best SlideType from a spec slide's title and content blocks."""
    title_lower = title.lower()

    # Check keywords
    for type_name, keywords in _TYPE_KEYWORDS.items():
        for kw in keywords:
            if kw in title_lower:
                return SlideType(type_name)

    # Content-based inference
    has_table = any(b.block_type == "table" for b in blocks)
    has_kpi = any(b.block_type == "kpi" for b in blocks)
    has_bullets = any(b.block_type == "bullets" for b in blocks)
    has_cards = any(b.block_type == "card" for b in blocks)
    card_count = sum(1 for b in blocks if b.block_type == "card")
    bullet_count = sum(
        len(b.content.get("items", [])) for b in blocks if b.block_type == "bullets"
    )

    if has_cards and card_count >= 2:
        return SlideType.CARD_GRID
    if has_table:
        return SlideType.TABLE
    if has_kpi:
        return SlideType.DASHBOARD
    if bullet_count > 6:
        return SlideType.TWO_COLUMN
    if has_bullets:
        return SlideType.CONTENT

    return SlideType.CONTENT


def _map_slide(spec_slide: SpecSlide) -> SlideDefinition:
    """Convert a SpecSlide into a SlideDefinition."""
    slide_type = _infer_slide_type(spec_slide.title, spec_slide.content_blocks)

    # Collect all bullet items and text
    all_bullets: list[str] = []
    all_text: list[str] = []
    tables: list[TableElement] = []
    kpis: list[KpiCard] = []
    cards: list[CardDefinition] = []
    callout: CalloutBox | None = None

    for block in spec_slide.content_blocks:
        if block.block_type == "bullets":
            all_bullets.extend(block.content.get("items", []))
        elif block.block_type == "text":
            all_text.append(block.content.get("text", ""))
        elif block.block_type == "table":
            rows_raw = block.content.get("rows", [])
            if rows_raw:
                table_rows = [[TableCell(text=c) for c in row] for row in rows_raw]
                tables.append(TableElement(rows=table_rows, alternate_row_shading=True))
        elif block.block_type == "kpi":
            text = block.content.get("text", "")
            # Try to extract number and label
            m = re.match(r"([\d.,]+[%$MKBkmb]*)\s*[:\-–]?\s*(.*)", text)
            if m:
                kpis.append(KpiCard(value=m.group(1), label=m.group(2) or spec_slide.title))
        elif block.block_type == "card":
            cards.append(CardDefinition(
                title=block.content.get("title", ""),
                bullets=block.content.get("bullets", []),
            ))
        elif block.block_type == "callout" and callout is None:
            callout = CalloutBox(
                variant=block.content.get("variant", "info"),
                body=block.content.get("body", ""),
            )

    # Build SlideDefinition based on type
    kwargs: dict = {
        "slide_type": slide_type,
        "title": spec_slide.title,
    }

    if slide_type == SlideType.CARD_GRID:
        kwargs["cards"] = cards[:12]

    elif slide_type == SlideType.CONTENT:
        kwargs["body"] = "\n".join(all_text) if all_text else None
        kwargs["bullets"] = all_bullets[:10]

    elif slide_type == SlideType.TWO_COLUMN:
        mid = len(all_bullets) // 2
        kwargs["columns"] = [
            ColumnContent(bullets=all_bullets[:mid]),
            ColumnContent(bullets=all_bullets[mid:]),
        ]

    elif slide_type == SlideType.TABLE:
        if tables:
            kwargs["elements"] = tables

    elif slide_type == SlideType.DASHBOARD:
        if kpis:
            kwargs["kpis"] = kpis
        elif all_bullets:
            kwargs["bullets"] = all_bullets[:6]

    elif slide_type in (SlideType.PROCESS, SlideType.TIMELINE):
        kwargs["steps"] = [
            ProcessStep(title=b, description=None) for b in all_bullets[:5]
        ]

    elif slide_type in (SlideType.TITLE, SlideType.SECTION, SlideType.CLOSING):
        kwargs["subtitle"] = all_text[0] if all_text else None

    else:
        kwargs["bullets"] = all_bullets[:10]

    # Attach callout if detected
    if callout:
        kwargs["callout"] = callout

    return SlideDefinition(**kwargs)


def _map_brand(global_config: GlobalConfig) -> Optional[BrandConfig]:
    """Convert spec global config to a BrandConfig if enough tokens are present."""
    colors = {t.name: t.value for t in global_config.colors}
    if len(colors) < 2:
        return None

    # Map common token names to ColorPalette fields
    palette_kwargs: dict = {}
    custom: dict[str, str] = {}

    _field_map = {
        "primary": ["primary", "primary_color", "brand_primary"],
        "secondary": ["secondary", "secondary_color"],
        "accent": ["accent", "accent_color", "highlight"],
        "background": ["background", "bg", "surface_white", "white"],
        "text_primary": ["text_primary", "text_dark", "dark", "charcoal"],
        "text_secondary": ["text_secondary", "text_light", "text_muted", "medium_gray"],
        "success": ["success", "green", "positive"],
        "danger": ["danger", "red", "negative", "error"],
    }

    for field_name, aliases in _field_map.items():
        for alias in aliases:
            if alias in colors:
                palette_kwargs[field_name] = colors[alias]
                break

    # Anything not mapped goes to custom_tokens
    mapped_values = set(palette_kwargs.values())
    for name, value in colors.items():
        if value not in mapped_values:
            custom[name] = value

    if "primary" not in palette_kwargs:
        # Use first color as primary
        first = next(iter(colors.values()))
        palette_kwargs["primary"] = first
    if "secondary" not in palette_kwargs:
        palette_kwargs["secondary"] = palette_kwargs["primary"]
    if "accent" not in palette_kwargs:
        palette_kwargs["accent"] = palette_kwargs.get("secondary", palette_kwargs["primary"])

    palette_kwargs["custom_tokens"] = custom

    return BrandConfig(
        name="Spec Brand",
        colors=ColorPalette(**palette_kwargs),
    )


def spec_to_presentation(
    spec: NormalizedSpec,
) -> tuple[PresentationDefinition, Optional[BrandConfig]]:
    """Convert a NormalizedSpec into a PresentationDefinition and optional BrandConfig.

    Returns:
        Tuple of (PresentationDefinition, BrandConfig or None).
    """
    slides = [_map_slide(s) for s in spec.slides]
    brand = _map_brand(spec.global_config)

    definition = PresentationDefinition(
        metadata=PresentationMetadata(
            title=spec.title or "Untitled",
            author=spec.author or None,
            company=spec.company or None,
        ),
        slides=slides,
    )

    return definition, brand


# ---------------------------------------------------------------------------
# Public API — single-call convenience
# ---------------------------------------------------------------------------


def parse_spec(markdown: str) -> tuple[PresentationDefinition, Optional[BrandConfig]]:
    """Parse a markdown presentation spec end-to-end.

    Args:
        markdown: Raw markdown text of the presentation spec.

    Returns:
        Tuple of (PresentationDefinition, BrandConfig or None).
    """
    spec = extract_spec(markdown)
    return spec_to_presentation(spec)
