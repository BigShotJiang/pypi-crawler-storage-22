"""Tests for deck archetype definitions."""

from __future__ import annotations

import pytest

from pptx_mcp.agents.archetypes import ARCHETYPES, DeckArchetype
from pptx_mcp.models.slides import SlideType


class TestArchetypeDefinitions:
    def test_all_archetypes_load(self) -> None:
        assert len(ARCHETYPES) == 12
        for name, arch in ARCHETYPES.items():
            assert isinstance(arch, DeckArchetype)
            assert arch.name == name

    def test_archetypes_have_valid_slide_types(self) -> None:
        for name, arch in ARCHETYPES.items():
            for slot in arch.slots:
                assert isinstance(slot.slide_type, SlideType), (
                    f"Archetype '{name}' has invalid slide_type in slot: {slot}"
                )

    def test_each_archetype_starts_with_title(self) -> None:
        for name, arch in ARCHETYPES.items():
            assert arch.slots[0].slide_type == SlideType.TITLE, (
                f"Archetype '{name}' should start with TITLE"
            )

    def test_archetype_slot_counts(self) -> None:
        for name, arch in ARCHETYPES.items():
            assert len(arch.slots) >= 3, f"Archetype '{name}' has too few slots"
            assert arch.min_slides >= 3
            assert arch.max_slides >= arch.min_slides
