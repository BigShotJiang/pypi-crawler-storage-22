"""Default brand configurations for common use cases."""

from __future__ import annotations

from pptx_mcp.models.brand import (
    BrandConfig,
    ColorPalette,
    FontConfig,
    HeaderFooterConfig,
    LayoutRules,
    LogoConfig,
    ShapeStyleConfig,
    SpacingConfig,
    ToneStyle,
)


def executive_default() -> BrandConfig:
    """Clean executive style suitable for C-suite presentations."""
    return BrandConfig(
        name="Executive Default",
        colors=ColorPalette(
            primary="#1B2A4A",
            secondary="#2D5F8A",
            accent="#E8913A",
            background="#FFFFFF",
            text_primary="#1A1A2E",
            text_secondary="#5A5A6E",
            success="#2E7D32",
            danger="#C62828",
            chart_colors=["#1B2A4A", "#2D5F8A", "#E8913A", "#6B8E23", "#8B4513", "#4682B4"],
        ),
        fonts=FontConfig(
            heading_font="Aptos",
            body_font="Aptos",
            title_size=36,
            heading_size=28,
            subheading_size=20,
            body_size=16,
            caption_size=11,
            line_spacing=1.15,
        ),
        spacing=SpacingConfig(
            margin_left=0.75,
            margin_right=0.75,
            margin_top=0.75,
            margin_bottom=0.5,
            title_top=0.4,
            content_top=1.6,
            element_gap=0.3,
            column_gap=0.5,
            padding=0.2,
        ),
        layout_rules=LayoutRules(
            max_bullets_per_slide=5,
            max_words_per_bullet=12,
            max_words_per_slide=60,
            min_font_size=14,
            prefer_visual_balance=True,
            use_accent_sparingly=True,
            title_every_slide=True,
        ),
        tone=ToneStyle.EXECUTIVE,
    )


def technical_default() -> BrandConfig:
    """Technical style for engineering and product presentations."""
    return BrandConfig(
        name="Technical Default",
        colors=ColorPalette(
            primary="#263238",
            secondary="#37474F",
            accent="#00BCD4",
            background="#FAFAFA",
            text_primary="#212121",
            text_secondary="#616161",
            success="#4CAF50",
            danger="#F44336",
            chart_colors=["#00BCD4", "#FF9800", "#4CAF50", "#E91E63", "#9C27B0", "#3F51B5"],
        ),
        fonts=FontConfig(
            heading_font="Segoe UI",
            body_font="Segoe UI",
            mono_font="Cascadia Code",
            title_size=32,
            heading_size=24,
            subheading_size=18,
            body_size=14,
            caption_size=10,
            line_spacing=1.3,
        ),
        layout_rules=LayoutRules(
            max_bullets_per_slide=7,
            max_words_per_bullet=18,
            max_words_per_slide=100,
            min_font_size=12,
        ),
        tone=ToneStyle.TECHNICAL,
    )


def minimal_default() -> BrandConfig:
    """Minimal, high-contrast style with generous whitespace."""
    return BrandConfig(
        name="Minimal Default",
        colors=ColorPalette(
            primary="#111111",
            secondary="#333333",
            accent="#FF4444",
            background="#FFFFFF",
            text_primary="#111111",
            text_secondary="#666666",
            chart_colors=["#111111", "#FF4444", "#888888", "#CCCCCC"],
        ),
        fonts=FontConfig(
            heading_font="Arial",
            body_font="Arial",
            title_size=40,
            heading_size=32,
            subheading_size=22,
            body_size=18,
            caption_size=12,
            line_spacing=1.4,
        ),
        spacing=SpacingConfig(
            margin_left=1.0,
            margin_right=1.0,
            margin_top=1.0,
            margin_bottom=0.75,
            content_top=2.0,
            element_gap=0.4,
            column_gap=0.6,
        ),
        shape_style=ShapeStyleConfig(
            divider_style="thin_line",
            text_auto_fit=True,
        ),
        layout_rules=LayoutRules(
            max_bullets_per_slide=4,
            max_words_per_bullet=10,
            max_words_per_slide=40,
            min_font_size=16,
        ),
        tone=ToneStyle.MINIMAL,
    )


def creative_default() -> BrandConfig:
    """Bold, colorful style for creative and marketing presentations."""
    return BrandConfig(
        name="Creative Default",
        colors=ColorPalette(
            primary="#6B21A8",
            secondary="#2563EB",
            accent="#F59E0B",
            background="#FFFFFF",
            text_primary="#1E1B4B",
            text_secondary="#6B7280",
            success="#059669",
            danger="#DC2626",
            chart_colors=["#6B21A8", "#2563EB", "#F59E0B", "#059669", "#EC4899", "#14B8A6"],
        ),
        fonts=FontConfig(
            heading_font="Georgia",
            body_font="Aptos",
            title_size=38,
            heading_size=30,
            subheading_size=22,
            body_size=16,
            caption_size=11,
            line_spacing=1.25,
        ),
        spacing=SpacingConfig(
            margin_left=0.9,
            margin_right=0.9,
            margin_top=0.9,
            margin_bottom=0.6,
            title_top=0.45,
            content_top=1.7,
            element_gap=0.35,
            column_gap=0.5,
            padding=0.25,
        ),
        layout_rules=LayoutRules(
            max_bullets_per_slide=5,
            max_words_per_bullet=14,
            max_words_per_slide=65,
            min_font_size=14,
        ),
        tone=ToneStyle.CREATIVE,
    )


def corporate_default() -> BrandConfig:
    """Conservative corporate style for formal business presentations."""
    return BrandConfig(
        name="Corporate Default",
        colors=ColorPalette(
            primary="#1E3A5F",
            secondary="#4A6FA5",
            accent="#C9A84C",
            background="#FFFFFF",
            text_primary="#1A1A1A",
            text_secondary="#555555",
            success="#2E7D32",
            danger="#B71C1C",
            chart_colors=["#1E3A5F", "#4A6FA5", "#C9A84C", "#2E7D32", "#8D6E63", "#546E7A"],
        ),
        fonts=FontConfig(
            heading_font="Garamond",
            body_font="Aptos",
            title_size=34,
            heading_size=26,
            subheading_size=19,
            body_size=15,
            caption_size=10,
            line_spacing=1.2,
        ),
        spacing=SpacingConfig(
            margin_left=0.8,
            margin_right=0.8,
            margin_top=0.8,
            margin_bottom=0.5,
            title_top=0.4,
            content_top=1.6,
            element_gap=0.3,
            column_gap=0.45,
            padding=0.2,
        ),
        layout_rules=LayoutRules(
            max_bullets_per_slide=6,
            max_words_per_bullet=15,
            max_words_per_slide=80,
            min_font_size=12,
        ),
        tone=ToneStyle.CORPORATE,
    )


def consulting_default() -> BrandConfig:
    """Consulting-grade style with shadows, slide numbers, and sharp professional cards."""
    return BrandConfig(
        name="Consulting Default",
        colors=ColorPalette(
            primary="#1A3C6E",
            secondary="#3B6FA0",
            accent="#D4A843",
            background="#FFFFFF",
            text_primary="#1A1A1A",
            text_secondary="#4A4A5A",
            success="#2E7D32",
            danger="#C62828",
            chart_colors=["#1A3C6E", "#3B6FA0", "#D4A843", "#2E7D32", "#8B4513", "#546E7A"],
        ),
        fonts=FontConfig(
            heading_font="Aptos",
            body_font="Aptos",
            title_size=36,
            heading_size=26,
            subheading_size=19,
            body_size=15,
            caption_size=9,
            line_spacing=1.15,
        ),
        spacing=SpacingConfig(
            margin_left=0.7,
            margin_right=0.7,
            margin_top=0.75,
            margin_bottom=0.5,
            title_top=0.35,
            content_top=1.5,
            element_gap=0.25,
            column_gap=0.4,
            padding=0.18,
        ),
        layout_rules=LayoutRules(
            max_bullets_per_slide=5,
            max_words_per_bullet=12,
            max_words_per_slide=60,
            min_font_size=12,
        ),
        header_footer=HeaderFooterConfig(
            show_slide_numbers=True,
            show_date=True,
            confidential_marking="CONFIDENTIAL",
            skip_title_slide=True,
        ),
        shape_style=ShapeStyleConfig(
            card_corner_radius=0.03,
            card_shadow=True,
            shadow_preset="medium",
            card_border_width_pt=0.5,
        ),
        tone=ToneStyle.CORPORATE,
    )


def healthcare_default() -> BrandConfig:
    """Clean, trustworthy style for healthcare and medical presentations."""
    return BrandConfig(
        name="Healthcare Default",
        colors=ColorPalette(
            primary="#0D6EAE",
            secondary="#4A9BD9",
            accent="#27AE60",
            background="#FFFFFF",
            text_primary="#2C3E50",
            text_secondary="#7F8C8D",
            chart_colors=["#0D6EAE", "#4A9BD9", "#27AE60", "#E74C3C", "#F39C12", "#8E44AD"],
        ),
        fonts=FontConfig(
            heading_font="Aptos",
            body_font="Aptos",
            title_size=34,
            heading_size=26,
            subheading_size=20,
            body_size=16,
            caption_size=11,
            line_spacing=1.25,
        ),
        spacing=SpacingConfig(
            margin_left=0.85,
            margin_right=0.85,
            margin_top=0.85,
            margin_bottom=0.6,
            title_top=0.4,
            content_top=1.7,
            element_gap=0.35,
            column_gap=0.5,
            padding=0.22,
        ),
        layout_rules=LayoutRules(
            max_bullets_per_slide=5,
            max_words_per_bullet=12,
            max_words_per_slide=55,
            min_font_size=14,
        ),
        header_footer=HeaderFooterConfig(
            show_slide_numbers=True,
            skip_title_slide=True,
        ),
        shape_style=ShapeStyleConfig(
            card_corner_radius=0.06,
            card_shadow=False,
            card_border_width_pt=0.75,
            show_accent_bar=True,
        ),
        tone=ToneStyle.HEALTHCARE,
    )


def startup_default() -> BrandConfig:
    """Bold, modern style for startup and product presentations."""
    return BrandConfig(
        name="Startup Default",
        colors=ColorPalette(
            primary="#6C5CE7",
            secondary="#A29BFE",
            accent="#00D2D3",
            background="#FFFFFF",
            text_primary="#2D3436",
            text_secondary="#636E72",
            chart_colors=["#6C5CE7", "#00D2D3", "#A29BFE", "#FDCB6E", "#FF7675", "#00B894"],
        ),
        fonts=FontConfig(
            heading_font="Aptos Display",
            body_font="Aptos",
            title_size=38,
            heading_size=30,
            subheading_size=22,
            body_size=16,
            caption_size=11,
            line_spacing=1.3,
        ),
        spacing=SpacingConfig(
            margin_left=0.9,
            margin_right=0.9,
            margin_top=0.9,
            margin_bottom=0.6,
            title_top=0.45,
            content_top=1.8,
            element_gap=0.35,
            column_gap=0.5,
            padding=0.25,
        ),
        layout_rules=LayoutRules(
            max_bullets_per_slide=4,
            max_words_per_bullet=10,
            max_words_per_slide=45,
            min_font_size=16,
        ),
        shape_style=ShapeStyleConfig(
            card_corner_radius=0.1,
            card_shadow=True,
            shadow_preset="subtle",
            edge_bar="left",
        ),
        tone=ToneStyle.STARTUP,
    )


def academic_default() -> BrandConfig:
    """Scholarly, structured style for academic and research presentations."""
    return BrandConfig(
        name="Academic Default",
        colors=ColorPalette(
            primary="#800020",
            secondary="#A0522D",
            accent="#DAA520",
            background="#FAFAF8",
            text_primary="#1A1A1A",
            text_secondary="#555555",
            chart_colors=["#800020", "#DAA520", "#A0522D", "#2E8B57", "#4682B4", "#8B008B"],
        ),
        fonts=FontConfig(
            heading_font="Garamond",
            body_font="Aptos",
            title_size=32,
            heading_size=24,
            subheading_size=18,
            body_size=15,
            caption_size=10,
            line_spacing=1.3,
        ),
        spacing=SpacingConfig(
            margin_left=0.8,
            margin_right=0.8,
            margin_top=0.8,
            margin_bottom=0.5,
            title_top=0.4,
            content_top=1.6,
            element_gap=0.3,
            column_gap=0.45,
            padding=0.2,
        ),
        layout_rules=LayoutRules(
            max_bullets_per_slide=6,
            max_words_per_bullet=18,
            max_words_per_slide=90,
            min_font_size=12,
        ),
        tone=ToneStyle.ACADEMIC,
    )


def government_default() -> BrandConfig:
    """Formal, accessible style for government and public sector presentations."""
    return BrandConfig(
        name="Government Default",
        colors=ColorPalette(
            primary="#003366",
            secondary="#336699",
            accent="#CC0000",
            background="#FFFFFF",
            text_primary="#1A1A1A",
            text_secondary="#4A4A4A",
            chart_colors=["#003366", "#336699", "#CC0000", "#006633", "#CC6600", "#663399"],
        ),
        fonts=FontConfig(
            heading_font="Aptos",
            body_font="Aptos",
            title_size=34,
            heading_size=26,
            subheading_size=20,
            body_size=16,
            caption_size=11,
            line_spacing=1.2,
        ),
        spacing=SpacingConfig(
            margin_left=0.8,
            margin_right=0.8,
            margin_top=0.8,
            margin_bottom=0.5,
            title_top=0.4,
            content_top=1.6,
            element_gap=0.3,
            column_gap=0.45,
            padding=0.2,
        ),
        layout_rules=LayoutRules(
            max_bullets_per_slide=6,
            max_words_per_bullet=15,
            max_words_per_slide=75,
            min_font_size=14,
        ),
        header_footer=HeaderFooterConfig(
            show_slide_numbers=True,
            show_date=True,
            skip_title_slide=True,
        ),
        shape_style=ShapeStyleConfig(
            card_corner_radius=0.0,
            card_shadow=False,
            card_border_width_pt=1.0,
        ),
        tone=ToneStyle.GOVERNMENT,
    )


def finance_default() -> BrandConfig:
    """Sophisticated, data-dense style for financial presentations."""
    return BrandConfig(
        name="Finance Default",
        colors=ColorPalette(
            primary="#1A3C34",
            secondary="#2D6A4F",
            accent="#B8860B",
            background="#FFFFFF",
            text_primary="#1A1A1A",
            text_secondary="#4A4A5A",
            chart_colors=["#1A3C34", "#2D6A4F", "#B8860B", "#8B0000", "#4682B4", "#556B2F"],
        ),
        fonts=FontConfig(
            heading_font="Aptos Display",
            body_font="Aptos",
            mono_font="Cascadia Code",
            title_size=34,
            heading_size=26,
            subheading_size=19,
            body_size=15,
            caption_size=10,
            line_spacing=1.15,
        ),
        spacing=SpacingConfig(
            margin_left=0.7,
            margin_right=0.7,
            margin_top=0.75,
            margin_bottom=0.5,
            title_top=0.35,
            content_top=1.5,
            element_gap=0.25,
            column_gap=0.4,
            padding=0.18,
        ),
        layout_rules=LayoutRules(
            max_bullets_per_slide=6,
            max_words_per_bullet=15,
            max_words_per_slide=80,
            min_font_size=12,
        ),
        header_footer=HeaderFooterConfig(
            show_slide_numbers=True,
            show_date=True,
            confidential_marking="CONFIDENTIAL",
            skip_title_slide=True,
        ),
        shape_style=ShapeStyleConfig(
            card_corner_radius=0.02,
            card_shadow=True,
            shadow_blur_pt=2.0,
            shadow_offset_pt=1.5,
            shadow_opacity_pct=15,
        ),
        tone=ToneStyle.FINANCE,
    )


def nonprofit_default() -> BrandConfig:
    """Warm, approachable style for nonprofit and mission-driven presentations."""
    return BrandConfig(
        name="Nonprofit Default",
        colors=ColorPalette(
            primary="#E07C3E",
            secondary="#D4A574",
            accent="#2E86AB",
            background="#FFFFFF",
            text_primary="#2C2C2C",
            text_secondary="#5A5A5A",
            chart_colors=["#E07C3E", "#2E86AB", "#D4A574", "#6B8E23", "#CD5C5C", "#708090"],
        ),
        fonts=FontConfig(
            heading_font="Aptos Display",
            body_font="Aptos",
            title_size=36,
            heading_size=28,
            subheading_size=20,
            body_size=16,
            caption_size=11,
            line_spacing=1.3,
        ),
        spacing=SpacingConfig(
            margin_left=0.9,
            margin_right=0.9,
            margin_top=0.9,
            margin_bottom=0.6,
            title_top=0.45,
            content_top=1.7,
            element_gap=0.35,
            column_gap=0.5,
            padding=0.25,
        ),
        layout_rules=LayoutRules(
            max_bullets_per_slide=5,
            max_words_per_bullet=12,
            max_words_per_slide=55,
            min_font_size=14,
        ),
        shape_style=ShapeStyleConfig(
            card_corner_radius=0.08,
            card_shadow=False,
            card_border_width_pt=0.75,
        ),
        tone=ToneStyle.NONPROFIT,
    )


PRESETS: dict[str, BrandConfig] = {
    "executive": executive_default(),
    "technical": technical_default(),
    "minimal": minimal_default(),
    "creative": creative_default(),
    "corporate": corporate_default(),
    "consulting": consulting_default(),
    "healthcare": healthcare_default(),
    "startup": startup_default(),
    "academic": academic_default(),
    "government": government_default(),
    "finance": finance_default(),
    "nonprofit": nonprofit_default(),
}


def get_preset(name: str) -> BrandConfig:
    """Get a preset brand configuration by name.

    Args:
        name: Preset name ("executive", "technical", "minimal").

    Returns:
        BrandConfig for the requested preset.

    Raises:
        KeyError: If preset name is not found.
    """
    if name not in PRESETS:
        available = ", ".join(PRESETS.keys())
        raise KeyError(f"Unknown preset '{name}'. Available: {available}")
    return PRESETS[name].model_copy(deep=True)
