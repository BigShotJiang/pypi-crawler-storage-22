"""MCP server — exposes PPTX generation and review tools via Model Context Protocol."""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Annotated, Literal, Optional

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError
from pydantic import Field

from pptx_mcp.agents.designer import DesignAgent, DesignerInput
from pptx_mcp.agents.iterator import IterationAgent, IterationInput
from pptx_mcp.agents.planner import PlannerInput, SlidePlannerAgent
from pptx_mcp.agents.reviewer import ReviewAgent, ReviewerInput
from pptx_mcp.agents.archetypes import ARCHETYPES
from pptx_mcp.brand.config import resolve_brand_config
from pptx_mcp.brand.defaults import PRESETS
from pptx_mcp.engine.generator import (
    DeckGenerator,
    _delete_slide,
    _duplicate_slide,
    _move_slide,
)
from pptx_mcp.engine.brand_extractor import extract_brand as _extract_brand_impl
from pptx_mcp.engine.parser import ingest_presentation, parse_presentation
from pptx_mcp.engine.spec_parser import parse_brand_guide as _parse_brand_guide_impl
from pptx_mcp.engine.spec_parser import parse_spec as _parse_spec_impl
from pptx_mcp.models.slides import (
    PresentationDefinition,
    SlideDefinition,
    SlideType,
)
from pptx_mcp.review.engine import ReviewEngine
from pptx_mcp.models.editor import AlignmentType, ElementLocator, ElementModification
from pptx_mcp.utils.errors import PptxMcpError
from pptx_mcp.utils.logging import get_logger
from pptx_mcp.utils.paths import validate_config_path, validate_output_path, validate_pptx_input

# Type aliases for constrained tool parameters
BrandPreset = Optional[Literal[
    "executive", "technical", "minimal", "creative", "corporate", "consulting",
    "healthcare", "startup", "academic", "government", "finance", "nonprofit",
]]
AudienceType = Literal["executive", "technical", "general"]

logger = get_logger("server")

# ---------------------------------------------------------------------------
# Plan cache — stores planned PresentationDefinitions server-side so
# plan_presentation can return a compact summary instead of 13-16KB JSON.
# ---------------------------------------------------------------------------

@dataclass
class CachedPlan:
    plan_id: str
    definition: PresentationDefinition
    created_at: datetime
    topic: str

_plan_cache: dict[str, CachedPlan] = {}
_PLAN_CACHE_MAX = 50
_PLAN_CACHE_TTL = timedelta(hours=1)


def _cache_plan(definition: PresentationDefinition, topic: str) -> CachedPlan:
    """Cache a plan and return the CachedPlan entry.

    Evicts expired entries first, then oldest if at capacity.
    """
    now = datetime.now()
    # Evict expired
    expired = [k for k, v in _plan_cache.items() if now - v.created_at > _PLAN_CACHE_TTL]
    for k in expired:
        del _plan_cache[k]
    # Evict oldest if at capacity
    while len(_plan_cache) >= _PLAN_CACHE_MAX:
        oldest_key = min(_plan_cache, key=lambda k: _plan_cache[k].created_at)
        del _plan_cache[oldest_key]

    plan_id = uuid.uuid4().hex[:12]
    entry = CachedPlan(
        plan_id=plan_id,
        definition=definition,
        created_at=now,
        topic=topic,
    )
    _plan_cache[plan_id] = entry
    return entry


def _get_cached_plan(plan_id: str) -> CachedPlan:
    """Retrieve a cached plan by ID. Raises ValueError if not found or expired."""
    entry = _plan_cache.get(plan_id)
    if entry is None:
        raise ValueError(f"Plan '{plan_id}' not found. It may have expired or been evicted.")
    if datetime.now() - entry.created_at > _PLAN_CACHE_TTL:
        del _plan_cache[plan_id]
        raise ValueError(f"Plan '{plan_id}' has expired (TTL is 1 hour).")
    return entry

mcp = FastMCP(
    "pptx-mcp",
    instructions="Model Context Protocol server for creating, editing, and reviewing PowerPoint presentations.",
)


def _raise_tool_error(tool_name: str, e: Exception) -> None:
    """Log the error and raise a ToolError with a safe message.

    Raises ToolError so the MCP response includes isError=True,
    letting the LLM client know the call failed.
    """
    logger.error("%s failed: %s", tool_name, e)
    if isinstance(e, PptxMcpError):
        raise ToolError(str(e)) from e
    error_type = type(e).__name__
    # Include message for common safe exception types so LLMs can recover
    if isinstance(e, (ValueError, TypeError, KeyError, IndexError)):
        raise ToolError(f"{error_type}: {e}") from e
    raise ToolError(f"Operation failed ({error_type}). Check server logs for details.") from e


def _resolve_brand(
    brand_config_path: Optional[str] = None,
    brand_preset: Optional[str] = None,
):
    """Resolve brand config with path validation."""
    if brand_config_path:
        validated = validate_config_path(brand_config_path)
        return resolve_brand_config(path=validated)
    return resolve_brand_config(preset=brand_preset)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


@mcp.tool()
def create_presentation(
    definition: PresentationDefinition,
    output_path: str,
    brand_config_path: Optional[str] = None,
    brand_preset: BrandPreset = None,
) -> str:
    """Create a PPTX presentation from a structured slide definition.

    Typical workflow: Call plan_presentation first to get a skeleton,
    fill in real content (replace all bracket placeholders), then pass
    the populated definition here. Call get_slide_templates if unsure
    about the schema for any slide type.

    Args:
        definition: Presentation definition with metadata and slides.
        output_path: File path where the .pptx will be saved (must end in .pptx).
        brand_config_path: Optional path to a brand config YAML/JSON file.
        brand_preset: Optional preset name (executive, technical, minimal, creative, corporate).

    Returns:
        JSON with status and output path.
    """
    try:
        validate_output_path(output_path)
        brand = _resolve_brand(brand_config_path, brand_preset)
        generator = DeckGenerator(brand=brand)
        result_path = generator.generate(definition, output_path)
        return json.dumps({
            "status": "success",
            "output_path": str(result_path),
            "slide_count": len(definition.slides),
        })
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("create_presentation", e)
        return ""  # unreachable, satisfies type checker


@mcp.tool()
def add_slide(
    file_path: str,
    slide: SlideDefinition,
    position: Optional[Annotated[int, Field(ge=0)]] = None,
    brand_config_path: Optional[str] = None,
    brand_preset: BrandPreset = None,
) -> str:
    """Add a slide to an existing PPTX presentation.

    Args:
        file_path: Path to the existing .pptx file.
        slide: Slide definition with slide_type, title, content, etc.
        position: 0-based position to insert. Appends if omitted.
        brand_config_path: Optional brand config path.
        brand_preset: Optional brand preset name.

    Returns:
        JSON with status.
    """
    try:
        validate_pptx_input(file_path)
        brand = _resolve_brand(brand_config_path, brand_preset)
        generator = DeckGenerator(brand=brand)
        generator.add_slide(file_path, slide, position=position)
        return json.dumps({"status": "success", "file_path": file_path})
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("add_slide", e)
        return ""


@mcp.tool()
def update_slide(
    file_path: str,
    slide_index: Annotated[int, Field(ge=0)],
    slide: SlideDefinition,
    brand_config_path: Optional[str] = None,
    brand_preset: BrandPreset = None,
) -> str:
    """Replace a specific slide in an existing presentation.

    Args:
        file_path: Path to the existing .pptx file.
        slide_index: 0-based index of the slide to replace.
        slide: New slide definition to replace the existing slide.
        brand_config_path: Optional brand config path.
        brand_preset: Optional brand preset name.

    Returns:
        JSON with status.
    """
    try:
        validate_pptx_input(file_path)
        brand = _resolve_brand(brand_config_path, brand_preset)
        generator = DeckGenerator(brand=brand)
        generator.update_slide(file_path, slide_index, slide)
        return json.dumps({"status": "success", "file_path": file_path, "slide_index": slide_index})
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("update_slide", e)
        return ""


@mcp.tool()
def delete_slide(file_path: str, slide_index: Annotated[int, Field(ge=0)]) -> str:
    """Delete a slide from a presentation.

    Args:
        file_path: Path to the .pptx file.
        slide_index: 0-based index of the slide to delete.

    Returns:
        JSON with status.
    """
    try:
        validate_pptx_input(file_path)
        from pptx import Presentation

        prs = Presentation(file_path)
        _delete_slide(prs, slide_index)
        prs.save(file_path)

        return json.dumps({"status": "success", "file_path": file_path})
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("delete_slide", e)
        return ""


@mcp.tool()
def move_slide(
    file_path: str,
    from_index: Annotated[int, Field(ge=0)],
    to_index: Annotated[int, Field(ge=0)],
) -> str:
    """Move a slide from one position to another within a presentation.

    Args:
        file_path: Path to the .pptx file.
        from_index: Current 0-based index of the slide to move.
        to_index: Target 0-based index where the slide should end up.

    Returns:
        JSON with status.
    """
    try:
        validate_pptx_input(file_path)
        from pptx import Presentation

        prs = Presentation(file_path)
        _move_slide(prs, from_index, to_index)
        prs.save(file_path)

        return json.dumps({
            "status": "success",
            "file_path": file_path,
            "moved": {"from": from_index, "to": to_index},
        })
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("move_slide", e)
        return ""


@mcp.tool()
def duplicate_slide(
    file_path: str,
    slide_index: Annotated[int, Field(ge=0)],
) -> str:
    """Duplicate a slide, placing the copy immediately after the original.

    Args:
        file_path: Path to the .pptx file.
        slide_index: 0-based index of the slide to duplicate.

    Returns:
        JSON with status and the index of the new slide.
    """
    try:
        validate_pptx_input(file_path)
        from pptx import Presentation

        prs = Presentation(file_path)
        new_index = _duplicate_slide(prs, slide_index)
        prs.save(file_path)

        return json.dumps({
            "status": "success",
            "file_path": file_path,
            "new_slide_index": new_index,
        })
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("duplicate_slide", e)
        return ""


@mcp.tool()
def add_speaker_notes(
    file_path: str,
    slide_index: Annotated[int, Field(ge=0)],
    notes: str,
) -> str:
    """Add or update speaker notes for a specific slide.

    Args:
        file_path: Path to existing .pptx file.
        slide_index: Zero-based slide index.
        notes: Speaker notes text to set.

    Returns:
        JSON with status.
    """
    try:
        validate_pptx_input(file_path)
        from pptx import Presentation

        prs = Presentation(file_path)
        if slide_index < 0 or slide_index >= len(prs.slides):
            raise ValueError(
                f"slide_index {slide_index} out of range (0-{len(prs.slides) - 1})"
            )
        slide = prs.slides[slide_index]
        notes_slide = slide.notes_slide
        notes_slide.notes_text_frame.text = notes
        prs.save(file_path)

        return json.dumps({
            "status": "success",
            "file_path": file_path,
            "slide_index": slide_index,
        })
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("add_speaker_notes", e)
        return ""


@mcp.tool()
def read_presentation(file_path: str, summary: bool = True) -> str:
    """Read and parse an existing PPTX file into structured JSON.

    Args:
        file_path: Path to the .pptx file.
        summary: If True (default), returns a compact outline. Set to False for full detail.

    Returns:
        JSON representation — compact summary or full PresentationDefinition.
    """
    try:
        validate_pptx_input(file_path)
        definition = parse_presentation(file_path)
        if summary:
            slides_summary = []
            for i, s in enumerate(definition.slides):
                entry: dict = {
                    "index": i,
                    "type": s.slide_type.value if s.slide_type else "unknown",
                    "title": s.title or "(untitled)",
                }
                if s.bullets:
                    entry["bullet_count"] = len(s.bullets)
                if s.columns:
                    entry["column_count"] = len(s.columns)
                if s.elements:
                    entry["element_count"] = len(s.elements)
                if s.speaker_notes:
                    entry["has_notes"] = True
                slides_summary.append(entry)
            return json.dumps({
                "title": definition.metadata.title,
                "author": definition.metadata.author,
                "slide_count": len(definition.slides),
                "slides": slides_summary,
            }, indent=2)
        return definition.model_dump_json(indent=2)
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("read_presentation", e)
        return ""


@mcp.tool()
def analyze_presentation(
    file_path: str,
    brand_preset: BrandPreset = None,
) -> str:
    """Analyze a presentation and return natural-language descriptions, content inventory, and recommendations.

    Combines structural parsing, slide descriptions, content analysis, and
    design review into a single comprehensive analysis. Use this to understand
    what's in a deck before editing or restyling.

    Args:
        file_path: Path to the .pptx file.
        brand_preset: Optional brand preset for review scoring.

    Returns:
        JSON with title, slide_count, overall_score, slide_descriptions,
        content_inventory, type_distribution, narrative_assessment, and recommendations.
    """
    try:
        validate_pptx_input(file_path)
        definition = parse_presentation(file_path)

        # Natural-language analysis
        from pptx_mcp.engine.describer import describe_presentation
        analysis = describe_presentation(definition.slides)

        # Review scoring
        brand = _resolve_brand(brand_preset=brand_preset)
        engine = ReviewEngine(brand=brand)
        review = engine.review_definition(definition)

        return json.dumps({
            "title": definition.metadata.title,
            "slide_count": len(definition.slides),
            "overall_score": review.overall_score,
            **analysis,
        }, indent=2)
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("analyze_presentation", e)
        return ""


@mcp.tool()
def review_presentation(
    file_path: str,
    brand_config_path: Optional[str] = None,
    brand_preset: BrandPreset = None,
) -> str:
    """Review a presentation and provide structured design feedback.

    Args:
        file_path: Path to the .pptx file.
        brand_config_path: Optional brand config path.
        brand_preset: Optional brand preset name.

    Returns:
        JSON review result with scores, issues, and suggestions.
    """
    try:
        validate_pptx_input(file_path)
        brand = _resolve_brand(brand_config_path, brand_preset)
        engine = ReviewEngine(brand=brand)
        result = engine.review_file(file_path)
        return result.model_dump_json(indent=2)
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("review_presentation", e)
        return ""


@mcp.tool()
def apply_brand_guidelines(
    file_path: str,
    output_path: Optional[str] = None,
    brand_config_path: Optional[str] = None,
    brand_preset: BrandPreset = None,
) -> str:
    """Re-render a presentation with brand guidelines applied.

    Parses the existing deck, then re-generates it with the specified brand config.

    Args:
        file_path: Path to the existing .pptx file.
        output_path: Where to save the branded version. Overwrites original if omitted.
        brand_config_path: Brand config file path.
        brand_preset: Brand preset name.

    Returns:
        JSON with status and output path.
    """
    try:
        validate_pptx_input(file_path)
        definition = parse_presentation(file_path)
        brand = _resolve_brand(brand_config_path, brand_preset)
        generator = DeckGenerator(brand=brand)
        out = output_path or file_path
        result_path = generator.generate(definition, out)
        return json.dumps({"status": "success", "output_path": str(result_path)})
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("apply_brand_guidelines", e)
        return ""


@mcp.tool()
def restyle_presentation(
    input_path: str,
    output_path: str,
    brand_config_path: Optional[str] = None,
    brand_preset: BrandPreset = None,
) -> str:
    """Restyle an existing presentation by ingesting it and re-generating with a new brand.

    Deep-reads the source deck, detects slide types via heuristics (title,
    section, content, two-column, big-number, quote, chart, table, etc.),
    extracts all content (titles, bullets, body, table data, chart data,
    speaker notes), then re-renders every slide through the layout engine
    with the requested brand config.

    This is the primary tool for consulting-style "feed a deck and restyle
    it better" workflows.

    Args:
        input_path: Path to the existing .pptx file to restyle.
        output_path: Where to save the restyled .pptx (must end in .pptx).
        brand_config_path: Optional path to a brand config YAML/JSON file.
        brand_preset: Optional brand preset name (executive, technical, minimal, creative, corporate, consulting).

    Returns:
        JSON with status, slide count, detected slide types, and output path.
    """
    try:
        validate_pptx_input(input_path)
        validate_output_path(output_path)

        definition = ingest_presentation(input_path)
        brand = _resolve_brand(brand_config_path, brand_preset)
        generator = DeckGenerator(brand=brand)
        result_path = generator.generate(definition, output_path)

        detected_types = [s.slide_type.value for s in definition.slides]

        return json.dumps({
            "status": "success",
            "output_path": str(result_path),
            "slide_count": len(definition.slides),
            "detected_types": detected_types,
        })
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("restyle_presentation", e)
        return ""


@mcp.tool()
def plan_presentation(
    topic: str,
    audience: AudienceType = "executive",
    num_slides: Annotated[int, Field(ge=3, le=50)] = 10,
    key_points: Optional[list[str]] = None,
    context: str = "",
    author: Optional[str] = None,
    company: Optional[str] = None,
    deck_type: Optional[str] = None,
    return_full_json: bool = False,
) -> str:
    """Generate a structured slide plan for a topic.

    Uses the SlidePlanner agent to create a presentation definition
    with appropriate slide types, narrative flow, and content derived
    from your topic, key_points, company, and audience inputs.

    By default returns a compact summary (~1-2KB) with a plan_id.
    The full definition is cached server-side. Use create_from_plan
    with the plan_id to render, or get_plan_slide to inspect individual
    slides before rendering.

    Recommended workflows by deck size:
    - Small (3-6 slides): generate_presentation (single step)
    - Medium (7-15 slides): plan_presentation -> create_from_plan
    - Large (15+ slides): plan_presentation -> create_from_plan, then
      update_slide / add_slide for targeted edits

    Args:
        topic: Main topic or title.
        audience: Target audience.
        num_slides: Target number of slides (3-50).
        key_points: List of key points to cover.
        context: Additional context or instructions.
        author: Author name.
        company: Company name.
        deck_type: Deck archetype name (e.g. 'pitch_deck', 'board_deck'). Call get_deck_types for options.
        return_full_json: If True, return the full PresentationDefinition JSON
            instead of a compact summary (backward compatibility).

    Returns:
        JSON — compact summary with plan_id (default) or full PresentationDefinition.
    """
    try:
        planner = SlidePlannerAgent()
        plan_input = PlannerInput(
            topic=topic,
            audience=audience,
            num_slides=num_slides,
            key_points=key_points or [],
            context=context,
            author=author,
            company=company,
            deck_type=deck_type,
        )
        result = planner.run(plan_input)

        if return_full_json:
            return result.model_dump_json(indent=2)

        # Cache and return compact summary
        entry = _cache_plan(result, topic)
        slides_summary = []
        for i, s in enumerate(result.slides):
            item: dict = {
                "index": i,
                "slide_type": s.slide_type.value if s.slide_type else "unknown",
                "title": s.title or "(untitled)",
            }
            if s.kpis:
                item["kpi_count"] = len(s.kpis)
            if s.bullets:
                item["bullet_count"] = len(s.bullets)
            if s.columns:
                item["column_count"] = len(s.columns)
            if s.cards:
                item["card_count"] = len(s.cards)
            if s.steps:
                item["step_count"] = len(s.steps)
            if s.icons:
                item["icon_count"] = len(s.icons)
            if s.team_members:
                item["member_count"] = len(s.team_members)
            if s.funnel_stages:
                item["stage_count"] = len(s.funnel_stages)
            if s.agenda_items:
                item["agenda_count"] = len(s.agenda_items)
            slides_summary.append(item)

        return json.dumps({
            "plan_id": entry.plan_id,
            "topic": topic,
            "slide_count": len(result.slides),
            "slides": slides_summary,
            "instructions": "Call create_from_plan with this plan_id to render. Use get_plan_slide to inspect individual slides.",
        }, indent=2)
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("plan_presentation", e)
        return ""


@mcp.tool()
def generate_presentation(
    topic: str,
    output_path: str,
    audience: AudienceType = "executive",
    num_slides: Annotated[int, Field(ge=3, le=50)] = 10,
    key_points: Optional[list[str]] = None,
    context: str = "",
    author: Optional[str] = None,
    company: Optional[str] = None,
    brand_config_path: Optional[str] = None,
    brand_preset: BrandPreset = None,
    deck_type: Optional[str] = None,
) -> str:
    """Plan and create a presentation in a single step.

    Combines plan_presentation + optimize_design + create_presentation into one call.
    Best for decks with 10 or fewer slides. For larger decks, use the two-step
    workflow: plan_presentation -> create_from_plan.

    The planner generates content derived from the topic, key_points, company,
    and audience you provide. For best results, supply detailed key_points.
    For maximum control, use the two-step workflow:
    1. Call plan_presentation to get a compact summary with plan_id
    2. Optionally inspect slides with get_plan_slide
    3. Call create_from_plan with the plan_id to render

    Args:
        topic: Main topic or title.
        output_path: File path where the .pptx will be saved (must end in .pptx).
        audience: Target audience.
        num_slides: Target number of slides (3-50).
        key_points: List of key points to cover.
        context: Additional context or instructions.
        author: Author name.
        company: Company name.
        brand_config_path: Optional path to a brand config YAML/JSON file.
        brand_preset: Optional preset name (executive, technical, minimal, creative, corporate).
        deck_type: Deck archetype name (e.g. 'pitch_deck', 'board_deck'). Call get_deck_types for options.

    Returns:
        JSON with status, output path, and slide count.
    """
    try:
        validate_output_path(output_path)
        # Step 1: Plan
        planner = SlidePlannerAgent()
        plan_input = PlannerInput(
            topic=topic,
            audience=audience,
            num_slides=num_slides,
            key_points=key_points or [],
            context=context,
            author=author,
            company=company,
            deck_type=deck_type,
        )
        definition = planner.run(plan_input)

        # Step 2: Design optimize
        designer = DesignAgent()
        design_result = designer.run(DesignerInput(
            definition=definition,
            brand_config_path=brand_config_path,
            brand_preset=brand_preset,
        ))

        # Step 3: Generate PPTX
        brand = _resolve_brand(brand_config_path, brand_preset)
        generator = DeckGenerator(brand=brand)
        result_path = generator.generate(design_result.definition, output_path)

        return json.dumps({
            "status": "success",
            "output_path": str(result_path),
            "slide_count": len(design_result.definition.slides),
            "design_changes": design_result.changes_made,
        })
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("generate_presentation", e)
        return ""


@mcp.tool()
def optimize_design(
    definition: PresentationDefinition,
    brand_config_path: Optional[str] = None,
    brand_preset: BrandPreset = None,
) -> str:
    """Optimize the design/layout of a presentation definition.

    Uses the DesignAgent to apply composition rules, balance columns,
    split overloaded slides, and improve visual hierarchy.

    Args:
        definition: Presentation definition to optimize.
        brand_config_path: Optional brand config path.
        brand_preset: Optional brand preset name.

    Returns:
        JSON with optimized definition and list of changes made.
    """
    try:
        designer = DesignAgent()
        result = designer.run(DesignerInput(
            definition=definition,
            brand_config_path=brand_config_path,
            brand_preset=brand_preset,
        ))
        return json.dumps({
            "definition": json.loads(result.definition.model_dump_json()),
            "changes_made": result.changes_made,
        }, indent=2)
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("optimize_design", e)
        return ""


@mcp.tool()
def improve_presentation(
    file_path: str,
    output_path: Optional[str] = None,
    brand_config_path: Optional[str] = None,
    brand_preset: BrandPreset = None,
) -> str:
    """Review and automatically improve a presentation.

    Runs the full pipeline: parse -> review -> iterate -> re-generate.

    Args:
        file_path: Path to the existing .pptx file.
        output_path: Where to save the improved version.
        brand_config_path: Optional brand config path.
        brand_preset: Optional brand preset name.

    Returns:
        JSON with review results and improvement details.
    """
    try:
        validate_pptx_input(file_path)
        brand = _resolve_brand(brand_config_path, brand_preset)

        # Parse
        definition = parse_presentation(file_path)

        # Review
        review_engine = ReviewEngine(brand=brand)
        review = review_engine.review_definition(definition)

        # Iterate
        iterator = IterationAgent()
        iteration_result = iterator.run(IterationInput(
            definition=definition,
            review=review,
        ))

        # Design optimize
        designer = DesignAgent()
        design_result = designer.run(DesignerInput(
            definition=iteration_result.definition,
            brand_config_path=brand_config_path,
            brand_preset=brand_preset,
        ))

        # Re-generate
        out = output_path or file_path
        generator = DeckGenerator(brand=brand)
        result_path = generator.generate(design_result.definition, out)

        # Re-review to get improved score
        improved_review = review_engine.review_definition(design_result.definition)

        return json.dumps({
            "status": "success",
            "output_path": str(result_path),
            "original_score": review.overall_score,
            "improved_score": improved_review.overall_score,
            "fixes_applied": iteration_result.fixes_applied + design_result.changes_made,
            "remaining_issues": len(iteration_result.remaining_issues),
        }, indent=2)
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("improve_presentation", e)
        return ""


@mcp.tool()
def parse_spec(
    markdown: str,
    output_path: Optional[str] = None,
    brand_preset: BrandPreset = None,
) -> str:
    """Parse a markdown presentation spec into slides and optionally generate a PPTX.

    Accepts structured markdown specs (from any AI or human author) that describe
    slide content, layout hints, and design tokens. Extracts slides, infers slide
    types, and maps design tokens to brand config.

    If output_path is provided, generates the PPTX directly.
    Otherwise, returns the parsed PresentationDefinition JSON for review/editing.

    Args:
        markdown: Raw markdown text of the presentation spec.
        output_path: Optional .pptx path — if provided, generates the file.
        brand_preset: Optional brand preset to override spec-extracted brand.

    Returns:
        JSON with parsed definition, detected brand, and optionally the output path.
    """
    try:
        definition, spec_brand = _parse_spec_impl(markdown)

        result: dict = {
            "slide_count": len(definition.slides),
            "detected_types": [s.slide_type.value for s in definition.slides],
            "spec_brand_detected": spec_brand is not None,
        }

        if output_path:
            validate_output_path(output_path)
            # Use spec brand unless overridden by preset
            if brand_preset:
                brand = _resolve_brand(brand_preset=brand_preset)
            elif spec_brand:
                brand = spec_brand
            else:
                brand = _resolve_brand()
            generator = DeckGenerator(brand=brand)
            path = generator.generate(definition, output_path)
            result["status"] = "success"
            result["output_path"] = str(path)
        else:
            result["definition"] = json.loads(definition.model_dump_json())
            if spec_brand:
                result["spec_brand"] = json.loads(spec_brand.model_dump_json())

        return json.dumps(result, indent=2)
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("parse_spec", e)
        return ""


@mcp.tool()
def create_from_plan(
    plan_id: str,
    output_path: str,
    brand_config_path: Optional[str] = None,
    brand_preset: BrandPreset = None,
    optimize: bool = True,
) -> str:
    """Render a cached plan to a PPTX file.

    Takes a plan_id returned by plan_presentation and generates the
    PowerPoint file. Optionally runs the DesignAgent optimizer first.

    Args:
        plan_id: The plan_id from a previous plan_presentation call.
        output_path: File path where the .pptx will be saved (must end in .pptx).
        brand_config_path: Optional path to a brand config YAML/JSON file.
        brand_preset: Optional preset name (executive, technical, minimal, creative, corporate, consulting).
        optimize: Run DesignAgent layout optimization before rendering (default True).

    Returns:
        JSON with status, output_path, and slide_count.
    """
    try:
        validate_output_path(output_path)
        entry = _get_cached_plan(plan_id)
        definition = entry.definition

        if optimize:
            designer = DesignAgent()
            design_result = designer.run(DesignerInput(
                definition=definition,
                brand_config_path=brand_config_path,
                brand_preset=brand_preset,
            ))
            definition = design_result.definition

        brand = _resolve_brand(brand_config_path, brand_preset)
        generator = DeckGenerator(brand=brand)
        result_path = generator.generate(definition, output_path)

        return json.dumps({
            "status": "success",
            "output_path": str(result_path),
            "slide_count": len(definition.slides),
        })
    except ValueError as e:
        raise ToolError(str(e)) from e
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("create_from_plan", e)
        return ""


@mcp.tool()
def get_plan_slide(
    plan_id: str,
    slide_index: Annotated[int, Field(ge=0)],
) -> str:
    """Get the full definition of a single slide from a cached plan.

    Returns the complete SlideDefinition JSON for one slide (~0.5-1.5KB),
    letting you inspect individual slides without pulling the entire plan.

    Args:
        plan_id: The plan_id from a previous plan_presentation call.
        slide_index: 0-based index of the slide to retrieve.

    Returns:
        JSON with the full SlideDefinition for the requested slide.
    """
    try:
        entry = _get_cached_plan(plan_id)
        slides = entry.definition.slides
        if slide_index < 0 or slide_index >= len(slides):
            raise ValueError(
                f"slide_index {slide_index} out of range (0-{len(slides) - 1})"
            )
        slide = slides[slide_index]
        return json.dumps({
            "plan_id": plan_id,
            "slide_index": slide_index,
            "slide": json.loads(slide.model_dump_json()),
        }, indent=2)
    except ValueError as e:
        raise ToolError(str(e)) from e
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("get_plan_slide", e)
        return ""


@mcp.tool()
def get_slide_templates() -> str:
    """List all available slide types with their schemas and descriptions.

    Returns:
        JSON with slide types, required fields, and example structures.
    """
    templates = {
        "title": {
            "description": "Title slide with centered title and optional subtitle",
            "fields": ["title", "subtitle"],
            "example": {"slide_type": "title", "title": "Quarterly Review", "subtitle": "Q4 2025"},
        },
        "section": {
            "description": "Section divider with accent bar",
            "fields": ["title", "subtitle"],
            "example": {"slide_type": "section", "title": "Market Analysis"},
        },
        "content": {
            "description": "Standard content with title, body text, and/or bullets",
            "fields": ["title", "body", "bullets"],
            "example": {
                "slide_type": "content",
                "title": "Key Findings",
                "bullets": ["Revenue grew 15%", "Customer retention at 92%", "NPS improved to 67"],
            },
        },
        "two_column": {
            "description": "Two-column layout with independent content",
            "fields": ["title", "columns"],
            "example": {
                "slide_type": "two_column",
                "title": "Before vs After",
                "columns": [
                    {"title": "Before", "bullets": ["Manual process", "5-day turnaround"]},
                    {"title": "After", "bullets": ["Automated", "Same-day delivery"]},
                ],
            },
        },
        "pros_cons": {
            "description": "Pros and cons comparison with color-coded lists",
            "fields": ["title", "pros", "cons"],
            "example": {
                "slide_type": "pros_cons",
                "title": "Migration Assessment",
                "pros": ["Improved performance", "Lower cost"],
                "cons": ["Migration risk", "Learning curve"],
            },
        },
        "chart": {
            "description": "Chart slide (bar, line, pie, column, area)",
            "fields": ["title", "elements (ChartElement)"],
            "example": {
                "slide_type": "chart",
                "title": "Revenue by Quarter",
                "elements": [{
                    "type": "chart",
                    "chart_type": "bar",
                    "data": {
                        "categories": ["Q1", "Q2", "Q3", "Q4"],
                        "series": [{"name": "Revenue", "values": [100, 120, 115, 140]}],
                    },
                }],
            },
        },
        "comparison": {
            "description": "Multi-column comparison with header bars",
            "fields": ["title", "columns"],
            "example": {
                "slide_type": "comparison",
                "title": "Platform Comparison",
                "columns": [
                    {"title": "AWS", "bullets": ["Mature", "Broadest services"]},
                    {"title": "Azure", "bullets": ["Enterprise focus", "AD integration"]},
                    {"title": "GCP", "bullets": ["ML/AI strength", "Competitive pricing"]},
                ],
            },
        },
        "diagram": {
            "description": "Shapes and connectors for visual diagrams",
            "fields": ["title", "elements (ShapeElement, ConnectorElement)"],
        },
        "table": {
            "description": "Table with header row and data rows",
            "fields": ["title", "elements (TableElement)"],
        },
        "blank": {
            "description": "Empty slide for freeform element placement",
            "fields": ["elements"],
        },
        "quote": {
            "description": "Quote slide with large quote text, attribution, and decorative elements",
            "fields": ["body (the quote)", "quote_attribution", "quote_attribution_role"],
            "example": {
                "slide_type": "quote",
                "body": "The best way to predict the future is to create it.",
                "quote_attribution": "Peter Drucker",
                "quote_attribution_role": "Management Consultant",
            },
        },
        "big_number": {
            "description": "Hero metric slide with a large number, label, and optional context",
            "fields": ["body (the number)", "title (label)", "subtitle (context)", "bullets (comparison)"],
            "example": {
                "slide_type": "big_number",
                "body": "47%",
                "title": "Customer Satisfaction Score",
                "subtitle": "Q4 2025 Results",
                "bullets": ["Up from 32% last quarter"],
            },
        },
        "process": {
            "description": "Horizontal chevron process flow (2-5 steps)",
            "fields": ["title", "steps", "active_step"],
            "example": {
                "slide_type": "process",
                "title": "Implementation Plan",
                "active_step": 1,
                "steps": [
                    {"title": "Discovery", "description": "Gather requirements", "status": "completed"},
                    {"title": "Design", "description": "Create architecture", "status": "active"},
                    {"title": "Build", "description": "Implement solution", "status": "future"},
                ],
            },
        },
        "timeline": {
            "description": "Vertical timeline with milestone dots and content",
            "fields": ["title", "steps (with date field)", "active_step"],
            "example": {
                "slide_type": "timeline",
                "title": "Project Milestones",
                "steps": [
                    {"title": "Kickoff", "date": "Jan 2025", "status": "completed"},
                    {"title": "Beta Launch", "date": "Mar 2025", "status": "active"},
                    {"title": "GA Release", "date": "Jun 2025", "status": "future"},
                ],
            },
        },
        "step_cards": {
            "description": "Numbered step cards in a horizontal row (2-5 cards)",
            "fields": ["title", "steps"],
            "example": {
                "slide_type": "step_cards",
                "title": "How It Works",
                "steps": [
                    {"title": "Sign Up", "description": "Create your account in minutes"},
                    {"title": "Configure", "description": "Set your preferences"},
                    {"title": "Launch", "description": "Go live with one click"},
                ],
            },
        },
        "dashboard": {
            "description": "KPI dashboard with metric cards in an auto-grid (2-12 cards)",
            "fields": ["title", "kpis"],
            "example": {
                "slide_type": "dashboard",
                "title": "Key Metrics — Q4 2025",
                "kpis": [
                    {"value": "$1.2M", "label": "Revenue", "change": "+15%", "trend": "up"},
                    {"value": "92%", "label": "Retention", "change": "+3%", "trend": "up"},
                    {"value": "67", "label": "NPS Score", "change": "-2", "trend": "down"},
                    {"value": "4.2s", "label": "Avg Response", "trend": "neutral"},
                ],
            },
        },
        "image_text": {
            "description": "Split layout with image on one side and text/bullets on the other",
            "fields": ["title", "image_path", "image_position", "body", "bullets"],
            "example": {
                "slide_type": "image_text",
                "title": "Our Product",
                "image_path": "/path/to/product.png",
                "image_position": "left",
                "body": "Next-generation platform for enterprise teams.",
                "bullets": ["Fast deployment", "Built-in analytics", "24/7 support"],
            },
        },
        "icon_grid": {
            "description": "Grid of icon + title + description cards (2-12 items)",
            "fields": ["title", "icons"],
            "example": {
                "slide_type": "icon_grid",
                "title": "Our Values",
                "icons": [
                    {"icon": "\U0001F680", "title": "Speed", "description": "Ship fast, iterate often"},
                    {"icon": "\U0001F91D", "title": "Trust", "description": "Transparent by default"},
                    {"icon": "\U0001F4A1", "title": "Innovation", "description": "Question everything"},
                    {"icon": "\U0001F4AA", "title": "Resilience", "description": "Embrace failure"},
                ],
            },
        },
        "team": {
            "description": "Team bio cards with avatar circles, names, roles, and optional bios",
            "fields": ["title", "team_members"],
            "example": {
                "slide_type": "team",
                "title": "Leadership Team",
                "team_members": [
                    {"name": "Jane Smith", "role": "CEO", "bio": "20 years in enterprise SaaS"},
                    {"name": "John Doe", "role": "CTO", "bio": "Former VP Engineering at Acme"},
                    {"name": "Alice Chen", "role": "CFO", "bio": "IPO experience across 3 companies"},
                ],
            },
        },
        "closing": {
            "description": "Closing / thank-you slide with optional CTA button and contact info",
            "fields": ["title", "subtitle", "cta_text", "contact_info"],
            "example": {
                "slide_type": "closing",
                "title": "Thank You",
                "subtitle": "Questions? Let's connect.",
                "cta_text": "Schedule a Demo",
                "contact_info": ["hello@company.com", "+1 (555) 123-4567"],
            },
        },
        "swot": {
            "description": "SWOT analysis 2x2 quadrant matrix with color-coded sections",
            "fields": ["title", "swot"],
            "example": {
                "slide_type": "swot",
                "title": "SWOT Analysis",
                "swot": {
                    "strengths": ["Strong brand", "Loyal customers"],
                    "weaknesses": ["High costs", "Limited reach"],
                    "opportunities": ["New markets", "Partnerships"],
                    "threats": ["Competition", "Regulation"],
                },
            },
        },
        "funnel": {
            "description": "Vertical funnel with 3-6 stages of decreasing width",
            "fields": ["title", "funnel_stages"],
            "example": {
                "slide_type": "funnel",
                "title": "Sales Pipeline",
                "funnel_stages": [
                    {"label": "Prospects", "value": "10,000", "description": "Website visitors"},
                    {"label": "Leads", "value": "2,500", "description": "Form submissions"},
                    {"label": "Qualified", "value": "800", "description": "Sales-qualified leads"},
                    {"label": "Closed", "value": "120", "description": "Won deals"},
                ],
            },
        },
        "card_grid": {
            "description": "Rich card grid with icon, title, body, bullets, and optional badge (2-12 cards)",
            "fields": ["title", "cards"],
            "example": {
                "slide_type": "card_grid",
                "title": "Our Services",
                "cards": [
                    {
                        "title": "Strategy",
                        "icon": "\U0001F3AF",
                        "body": "End-to-end strategic advisory",
                        "bullets": ["Market analysis", "Growth planning"],
                        "badge": {"text": "NEW"},
                    },
                    {
                        "title": "Implementation",
                        "icon": "\U0001F527",
                        "body": "Hands-on delivery and execution",
                        "bullets": ["Agile delivery", "Change management"],
                    },
                    {
                        "title": "Analytics",
                        "icon": "\U0001F4CA",
                        "body": "Data-driven insights and reporting",
                        "bullets": ["Dashboards", "Predictive models"],
                    },
                ],
            },
        },
        "agenda": {
            "description": "Visual agenda with numbered circles and status indicators",
            "fields": ["title", "agenda_items", "active_agenda_item"],
            "example": {
                "slide_type": "agenda",
                "title": "Today's Agenda",
                "active_agenda_item": 1,
                "agenda_items": [
                    {"title": "Opening Remarks", "status": "completed"},
                    {"title": "Q4 Financial Review", "description": "Revenue, margins, and forecast", "status": "active"},
                    {"title": "2026 Strategic Priorities", "description": "Growth plan and investments", "status": "upcoming"},
                    {"title": "Q&A", "status": "upcoming"},
                ],
            },
        },
    }
    return json.dumps(templates, indent=2)


@mcp.tool()
def get_brand_presets() -> str:
    """List available brand configuration presets.

    Returns:
        JSON with preset names and their key properties.
    """
    result = {}
    for name, config in PRESETS.items():
        result[name] = {
            "name": config.name,
            "tone": config.tone.value,
            "primary_color": config.colors.primary,
            "secondary_color": config.colors.secondary,
            "accent_color": config.colors.accent,
            "heading_font": config.fonts.heading_font,
            "body_font": config.fonts.body_font,
        }
    return json.dumps(result, indent=2)


@mcp.tool()
def get_deck_types() -> str:
    """List all available deck archetypes with descriptions and slot sequences.

    Each archetype defines a recommended slide structure for a specific
    presentation type (pitch deck, board update, sales deck, etc.).
    Pass the archetype name as the deck_type parameter to plan_presentation
    or generate_presentation for intelligent slide selection.

    Returns:
        JSON with archetype names, descriptions, slide sequences, and limits.
    """
    result = {}
    for name, arch in ARCHETYPES.items():
        result[name] = {
            "display_name": arch.display_name,
            "description": arch.description,
            "min_slides": arch.min_slides,
            "max_slides": arch.max_slides,
            "slot_sequence": [
                {"slide_type": slot.slide_type.value, "title_template": slot.title_template, "required": slot.required}
                for slot in arch.slots
            ],
        }
    return json.dumps(result, indent=2)


# ---------------------------------------------------------------------------
# Element editing tools
# ---------------------------------------------------------------------------


@mcp.tool()
def list_slide_elements(
    file_path: str,
    slide_index: Annotated[int, Field(ge=0)],
) -> str:
    """List all shapes on a slide with their positions, sizes, text, and styling.

    Use this to discover what elements exist on a slide before modifying them.
    Each element includes an index that can be used with modify_element,
    align_elements, and group_elements.

    Args:
        file_path: Path to the .pptx file.
        slide_index: 0-based slide index.

    Returns:
        JSON array of element info objects.
    """
    try:
        validate_pptx_input(file_path)
        from pptx import Presentation

        from pptx_mcp.engine.editor import list_elements

        prs = Presentation(file_path)
        if slide_index < 0 or slide_index >= len(prs.slides):
            raise ValueError(
                f"slide_index {slide_index} out of range (0-{len(prs.slides) - 1})"
            )
        slide = prs.slides[slide_index]
        elements = list_elements(slide)
        return json.dumps(
            [e.model_dump(exclude_none=True) for e in elements],
            indent=2,
        )
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("list_slide_elements", e)
        return ""


@mcp.tool()
def modify_element(
    file_path: str,
    slide_index: Annotated[int, Field(ge=0)],
    locator: ElementLocator,
    modification: ElementModification,
) -> str:
    """Modify a single shape on a slide — change position, size, text, font, fill, or border.

    Locate the target shape by index (from list_slide_elements), name, or text content.
    Only fields you provide in the modification are changed; everything else stays the same.

    Args:
        file_path: Path to the .pptx file.
        slide_index: 0-based slide index.
        locator: How to find the target shape (index, name, or text_match).
        modification: Properties to change (only non-null fields are applied).

    Returns:
        JSON with the updated element info.
    """
    try:
        validate_pptx_input(file_path)
        from pptx import Presentation

        from pptx_mcp.engine.editor import modify_element as _modify

        prs = Presentation(file_path)
        if slide_index < 0 or slide_index >= len(prs.slides):
            raise ValueError(
                f"slide_index {slide_index} out of range (0-{len(prs.slides) - 1})"
            )
        slide = prs.slides[slide_index]
        result = _modify(slide, locator, modification)
        prs.save(file_path)
        return json.dumps(result.model_dump(exclude_none=True), indent=2)
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("modify_element", e)
        return ""


@mcp.tool()
def add_element(
    file_path: str,
    slide_index: Annotated[int, Field(ge=0)],
    element_type: Literal["textbox", "shape", "image"],
    left: float,
    top: float,
    width: Optional[float] = None,
    height: Optional[float] = None,
    text: Optional[str] = None,
    shape_type: Optional[str] = None,
    image_path: Optional[str] = None,
    font_name: Optional[str] = None,
    font_size: Optional[float] = None,
    font_bold: Optional[bool] = None,
    font_color: Optional[str] = None,
    fill_color: Optional[str] = None,
    border_color: Optional[str] = None,
    border_width: Optional[float] = None,
    text_alignment: Optional[str] = None,
) -> str:
    """Add a new element (textbox, shape, or image) to a slide.

    For textbox: provide text and optional font/fill styling.
    For shape: provide shape_type (rectangle, circle, etc.) and optional text/fill/border.
    For image: provide image_path. Width/height are optional (auto-sized if omitted).

    Args:
        file_path: Path to the .pptx file.
        slide_index: 0-based slide index.
        element_type: Type of element to add — "textbox", "shape", or "image".
        left: Left edge position in inches.
        top: Top edge position in inches.
        width: Width in inches (required for textbox/shape, optional for image).
        height: Height in inches (required for textbox/shape, optional for image).
        text: Text content (textbox/shape).
        shape_type: Shape type for "shape" elements (e.g. "rectangle", "circle").
        image_path: File path for "image" elements.
        font_name: Font family name.
        font_size: Font size in points.
        font_bold: Bold flag.
        font_color: Font hex color.
        fill_color: Shape fill hex color.
        border_color: Border hex color.
        border_width: Border width in points.
        text_alignment: Text alignment (left, center, right, justify).

    Returns:
        JSON with the new element info.
    """
    try:
        validate_pptx_input(file_path)
        from pptx import Presentation

        from pptx_mcp.engine.editor import add_image as _add_image
        from pptx_mcp.engine.editor import add_shape as _add_shape
        from pptx_mcp.engine.editor import add_textbox as _add_textbox

        prs = Presentation(file_path)
        if slide_index < 0 or slide_index >= len(prs.slides):
            raise ValueError(
                f"slide_index {slide_index} out of range (0-{len(prs.slides) - 1})"
            )
        slide = prs.slides[slide_index]

        if element_type == "textbox":
            if width is None or height is None:
                raise ValueError("textbox requires width and height")
            result = _add_textbox(
                slide, left, top, width, height,
                text=text or "",
                font_name=font_name,
                font_size=font_size,
                font_bold=font_bold,
                font_color=font_color,
                fill_color=fill_color,
                text_alignment=text_alignment,
            )
        elif element_type == "shape":
            if width is None or height is None:
                raise ValueError("shape requires width and height")
            if not shape_type:
                raise ValueError("shape requires shape_type")
            result = _add_shape(
                slide, shape_type, left, top, width, height,
                text=text,
                fill_color=fill_color,
                border_color=border_color,
                border_width=border_width,
            )
        elif element_type == "image":
            if not image_path:
                raise ValueError("image requires image_path")
            result = _add_image(slide, image_path, left, top, width, height)
        else:
            raise ValueError(f"Invalid element_type '{element_type}'. Use: textbox, shape, image")

        prs.save(file_path)
        return json.dumps(result.model_dump(exclude_none=True), indent=2)
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("add_element", e)
        return ""


@mcp.tool()
def align_elements(
    file_path: str,
    slide_index: Annotated[int, Field(ge=0)],
    locators: Annotated[list[ElementLocator], Field(max_length=100)],
    alignment: AlignmentType,
) -> str:
    """Align or evenly distribute multiple elements on a slide.

    Provide 2+ element locators and an alignment type. Elements can be
    aligned to edges (left, right, top, bottom), centers (center, middle),
    or evenly distributed (distribute_h, distribute_v).

    Args:
        file_path: Path to the .pptx file.
        slide_index: 0-based slide index.
        locators: List of element locators (at least 2).
        alignment: Alignment type (left, center, right, top, middle, bottom, distribute_h, distribute_v).

    Returns:
        JSON array of updated element info objects.
    """
    try:
        validate_pptx_input(file_path)
        from pptx import Presentation

        from pptx_mcp.engine.editor import align_elements as _align

        prs = Presentation(file_path)
        if slide_index < 0 or slide_index >= len(prs.slides):
            raise ValueError(
                f"slide_index {slide_index} out of range (0-{len(prs.slides) - 1})"
            )
        slide = prs.slides[slide_index]
        results = _align(slide, locators, alignment)
        prs.save(file_path)
        return json.dumps(
            [e.model_dump(exclude_none=True) for e in results],
            indent=2,
        )
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("align_elements", e)
        return ""


@mcp.tool()
def group_elements(
    file_path: str,
    slide_index: Annotated[int, Field(ge=0)],
    locators: Annotated[list[ElementLocator], Field(max_length=100)],
) -> str:
    """Group multiple shapes into a single group shape.

    After grouping, shape indices change. Call list_slide_elements again
    to see the updated layout.

    Args:
        file_path: Path to the .pptx file.
        slide_index: 0-based slide index.
        locators: List of element locators (at least 2).

    Returns:
        JSON with the group element info.
    """
    try:
        validate_pptx_input(file_path)
        from pptx import Presentation

        from pptx_mcp.engine.editor import group_elements as _group

        prs = Presentation(file_path)
        if slide_index < 0 or slide_index >= len(prs.slides):
            raise ValueError(
                f"slide_index {slide_index} out of range (0-{len(prs.slides) - 1})"
            )
        slide = prs.slides[slide_index]
        result = _group(slide, locators)
        prs.save(file_path)
        return json.dumps(result.model_dump(exclude_none=True), indent=2)
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("group_elements", e)
        return ""


@mcp.tool()
def validate_slide_layout(
    file_path: str,
    slide_index: Annotated[int, Field(ge=0)],
    brand_preset: BrandPreset = None,
) -> str:
    """Run spatial validation on a single slide to check for layout issues.

    Checks for: element overlaps, out-of-bounds elements, tight spacing,
    and text overflow. Use after adding or modifying elements to verify
    the layout is clean.

    Args:
        file_path: Path to the .pptx file.
        slide_index: 0-based slide index.
        brand_preset: Optional brand preset for context.

    Returns:
        JSON with list of spatial issues (empty array = clean layout).
    """
    try:
        validate_pptx_input(file_path)
        from pptx import Presentation

        from pptx_mcp.review.spatial import SPATIAL_RULES

        prs = Presentation(file_path)
        if slide_index < 0 or slide_index >= len(prs.slides):
            raise ValueError(
                f"slide_index {slide_index} out of range (0-{len(prs.slides) - 1})"
            )
        slide = prs.slides[slide_index]
        brand = _resolve_brand(brand_preset=brand_preset)

        slide_w = round(prs.slide_width / 914400, 3) if prs.slide_width else 13.333
        slide_h = round(prs.slide_height / 914400, 3) if prs.slide_height else 7.5

        all_issues = []
        for rule in SPATIAL_RULES:
            kwargs = {}
            if rule.__name__ == "check_element_bounds":
                kwargs = {"slide_width": slide_w, "slide_height": slide_h}
            all_issues.extend(rule(slide, slide_index, brand, **kwargs))

        return json.dumps({
            "slide_index": slide_index,
            "issue_count": len(all_issues),
            "issues": [issue.model_dump(exclude_none=True) for issue in all_issues],
        }, indent=2)
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("validate_slide_layout", e)
        return ""


@mcp.tool()
def generate_brand_guide(
    output_path: str,
    brand_preset: BrandPreset = None,
    brand_config_path: Optional[str] = None,
) -> str:
    """Generate a brand guide PPTX showcasing colors, fonts, and layout rules.

    Creates a 10-slide deck that demonstrates the brand's visual identity:
    color palette, typography hierarchy, spacing rules, and sample slides
    (dashboard, cards, chart, table, process) rendered with the brand styling.

    Args:
        output_path: File path where the .pptx will be saved (must end in .pptx).
        brand_preset: Optional brand preset name.
        brand_config_path: Optional path to a brand config YAML/JSON file.

    Returns:
        JSON with status, output path, and slide count.
    """
    try:
        validate_output_path(output_path)
        brand = _resolve_brand(brand_config_path, brand_preset)

        from pathlib import Path

        from pptx_mcp.engine.brand_guide import generate_brand_guide as _generate

        result_path = _generate(brand, Path(output_path))
        return json.dumps({
            "status": "success",
            "output_path": str(result_path),
            "slide_count": 10,
            "brand_name": brand.name,
        })
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("generate_brand_guide", e)
        return ""


@mcp.tool()
def parse_brand_guide(
    markdown: str,
    save_path: Optional[str] = None,
) -> str:
    """Parse a markdown or YAML brand guide into a BrandConfig.

    Accepts structured markdown with sections like ``## Colors``,
    ``## Typography``, ``## Shape Style``, ``## Spacing``,
    ``## Header/Footer``, and ``## Logo``. Also auto-detects YAML input
    when the text does not start with ``#``.

    Missing sections use sensible defaults. Use this to convert a
    human-authored brand guide into a machine-readable config that can
    be passed to other tools.

    Args:
        markdown: Raw markdown or YAML text describing the brand.
        save_path: Optional file path (.yaml or .json) to save the
            parsed config for reuse.

    Returns:
        JSON representation of the parsed BrandConfig.
    """
    try:
        brand = _parse_brand_guide_impl(markdown)

        if save_path:
            from pathlib import Path

            p = Path(save_path)
            if p.suffix not in (".yaml", ".yml", ".json"):
                raise ValueError(
                    f"save_path must end in .yaml, .yml, or .json, got '{p.suffix}'"
                )
            p.parent.mkdir(parents=True, exist_ok=True)
            data = json.loads(brand.model_dump_json())
            if p.suffix in (".yaml", ".yml"):
                import yaml

                p.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False), encoding="utf-8")
            else:
                p.write_text(json.dumps(data, indent=2), encoding="utf-8")

            return json.dumps({
                "status": "success",
                "save_path": str(p),
                "brand": data,
            }, indent=2)

        return brand.model_dump_json(indent=2)
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("parse_brand_guide", e)
        return ""


@mcp.tool()
def extract_brand(
    file_path: str,
    save_path: Optional[str] = None,
) -> str:
    """Extract a BrandConfig from an existing PPTX by analyzing its visual properties.

    Scans all slides and shapes to collect font families, sizes, fill colors,
    text colors, and border colors. Aggregates by frequency to determine the
    brand's primary/secondary/accent colors and heading/body fonts.

    Use this to reverse-engineer a brand configuration from any deck, then
    apply it to new presentations via brand_config_path or brand_preset.

    Args:
        file_path: Path to the .pptx file to analyze.
        save_path: Optional file path (.yaml or .json) to save the extracted config.

    Returns:
        JSON representation of the extracted BrandConfig.
    """
    try:
        validate_pptx_input(file_path)
        brand = _extract_brand_impl(file_path)

        if save_path:
            from pathlib import Path

            p = Path(save_path)
            if p.suffix not in (".yaml", ".yml", ".json"):
                raise ValueError(
                    f"save_path must end in .yaml, .yml, or .json, got '{p.suffix}'"
                )
            p.parent.mkdir(parents=True, exist_ok=True)
            data = json.loads(brand.model_dump_json())
            if p.suffix in (".yaml", ".yml"):
                import yaml

                p.write_text(
                    yaml.dump(data, default_flow_style=False, sort_keys=False),
                    encoding="utf-8",
                )
            else:
                p.write_text(json.dumps(data, indent=2), encoding="utf-8")

            return json.dumps({
                "status": "success",
                "save_path": str(p),
                "brand": data,
            }, indent=2)

        return brand.model_dump_json(indent=2)
    except ToolError:
        raise
    except Exception as e:
        _raise_tool_error("extract_brand", e)
        return ""


# ---------------------------------------------------------------------------
# Prompts — pre-built templates for common workflows
# ---------------------------------------------------------------------------


@mcp.prompt()
def choose_workflow(num_slides: int = 10) -> str:
    """Recommend the best workflow based on deck size.

    Returns natural-language guidance on which tools to use for the
    given number of slides to avoid token-limit issues.
    """
    if num_slides <= 6:
        return (
            f"For a {num_slides}-slide deck, use generate_presentation.\n"
            "This single-step workflow plans, optimizes, and renders in one call.\n"
            "The output is small enough to fit comfortably within token limits."
        )
    elif num_slides <= 15:
        return (
            f"For a {num_slides}-slide deck, use the two-step workflow:\n"
            "1. Call plan_presentation to get a compact summary with a plan_id\n"
            "2. Optionally call get_plan_slide to inspect individual slides\n"
            "3. Call create_from_plan with the plan_id to render the .pptx\n\n"
            "This avoids returning the full definition JSON, which can be large."
        )
    else:
        return (
            f"For a {num_slides}-slide deck, use the two-step workflow with targeted edits:\n"
            "1. Call plan_presentation to get a compact summary with a plan_id\n"
            "2. Call create_from_plan with the plan_id to render the .pptx\n"
            "3. Use update_slide / add_slide / delete_slide for targeted edits\n\n"
            "Large decks should avoid transferring the full definition JSON.\n"
            "The plan cache keeps the full definition server-side."
        )


@mcp.prompt()
def create_pitch_deck(topic: str, company: str = "", audience: str = "executive") -> str:
    """Generate a complete pitch deck for a topic.

    Creates a polished pitch presentation with problem, solution, traction,
    team, and ask slides using the pitch_deck archetype.
    """
    return (
        f"Create a professional pitch deck about: {topic}\n"
        f"Company: {company or '(not specified)'}\n"
        f"Target audience: {audience}\n\n"
        "Steps:\n"
        f'1. Call generate_presentation with topic="{topic}", '
        f'audience="{audience}", num_slides=10, deck_type="pitch_deck"'
        f'{f", company={company!r}" if company else ""}\n'
        "2. Review the output path and confirm success\n\n"
        "The deck uses the pitch_deck archetype: title, problem, solution, "
        "traction, product, metrics, differentiators, market, team, and closing."
    )


@mcp.prompt()
def review_and_improve(file_path: str) -> str:
    """Review an existing presentation and apply automatic improvements.

    Runs the full review-iterate-optimize pipeline on a deck.
    """
    return (
        f"Review and improve the presentation at: {file_path}\n\n"
        "Steps:\n"
        f'1. Call read_presentation with file_path="{file_path}" to see the current structure\n'
        f'2. Call review_presentation with file_path="{file_path}" to get design feedback\n'
        f'3. Call improve_presentation with file_path="{file_path}" to apply fixes\n'
        "4. Report the before/after scores and changes made"
    )


@mcp.prompt()
def add_process_flow(file_path: str, num_steps: int = 4) -> str:
    """Add a process flow slide to an existing presentation.

    Creates a chevron process flow or step cards slide.
    """
    return (
        f"Add a process flow slide to: {file_path}\n\n"
        f"Create a slide with {num_steps} steps using the 'process' or 'step_cards' slide type.\n"
        "Each step needs a title and brief description.\n\n"
        "Use add_slide with a slide definition containing:\n"
        '- slide_type: "process" (for chevron flow) or "step_cards" (for numbered cards)\n'
        "- title: descriptive title for the slide\n"
        f'- steps: array of {num_steps} objects with title, description, and status fields\n'
        '- active_step: 0-based index of the current step (optional)\n'
    )


@mcp.prompt()
def create_board_update(topic: str, company: str = "", quarter: str = "") -> str:
    """Generate a board update deck with financials, strategy, and operational review."""
    return (
        f"Create a board update presentation about: {topic}\n"
        f"Company: {company or '(not specified)'}\n"
        f"Quarter: {quarter or '(current)'}\n\n"
        "Steps:\n"
        f'1. Call generate_presentation with topic="{topic}", '
        f'audience="executive", num_slides=12, deck_type="board_deck"'
        f'{f", company={company!r}" if company else ""}\n'
        "2. Review the output path and confirm success\n\n"
        "The deck uses the board_deck archetype: title, agenda, financial dashboard, "
        "revenue charts, strategic initiatives, SWOT analysis, operational highlights, "
        "risks, and next steps."
    )


@mcp.prompt()
def create_sales_deck(topic: str, company: str = "") -> str:
    """Generate a customer-facing sales presentation with value proposition and social proof."""
    return (
        f"Create a sales presentation about: {topic}\n"
        f"Company: {company or '(not specified)'}\n\n"
        "Steps:\n"
        f'1. Call generate_presentation with topic="{topic}", '
        f'audience="general", num_slides=10, deck_type="sales_deck"'
        f'{f", company={company!r}" if company else ""}\n'
        "2. Review the output path and confirm success\n\n"
        "The deck uses the sales_deck archetype: title, challenge, approach, "
        "comparison, results dashboard, customer quote, pricing, and CTA."
    )


@mcp.prompt()
def design_guidance() -> str:
    """Professional slide design principles for creating polished presentations.

    Covers layout, typography, color, content density, whitespace, and the
    recommended verify-and-adjust workflow using element editing tools.
    """
    return (
        "# Slide Design Principles\n\n"
        "## Layout\n"
        "- Maintain 0.5\" margins on all sides\n"
        "- Use a grid system — align elements to consistent vertical and horizontal lines\n"
        "- Apply the rule of thirds: place key content at intersection points\n"
        "- Minimum 0.15\" spacing between adjacent elements\n"
        "- Group related elements with proximity; separate unrelated groups with whitespace\n\n"
        "## Typography\n"
        "- Title: 28-36pt, bold, brand primary color\n"
        "- Body: 14-18pt, regular weight, dark gray or black\n"
        "- Caption/footnote: 10-12pt, lighter color\n"
        "- Use at most 2 font families (one for headings, one for body)\n"
        "- Avoid all-caps for body text; reserve for short labels only\n\n"
        "## Color\n"
        "- Use brand primary color for titles and key accents\n"
        "- Limit to 1-2 accent colors beyond the primary palette\n"
        "- Ensure sufficient contrast (dark text on light backgrounds, or vice versa)\n"
        "- Use color consistently — same meaning across all slides\n\n"
        "## Content Density\n"
        "- One key message per slide\n"
        "- 6×6 rule: max 6 bullets, max 6 words per bullet\n"
        "- Target 75 words or fewer per slide\n"
        "- If a slide feels crowded, split it into two\n\n"
        "## Whitespace\n"
        "- Whitespace is a design element, not wasted space\n"
        "- More whitespace around important elements draws attention\n"
        "- Don't fill every inch of the slide — let content breathe\n\n"
        "## Verify-and-Adjust Workflow\n"
        "After generating or editing slides:\n"
        "1. `list_slide_elements` — see all shapes with positions and sizes\n"
        "2. `validate_slide_layout` — check for overlaps, bounds, and spacing issues\n"
        "3. `modify_element` — fix any flagged issues (reposition, resize)\n"
        "4. `align_elements` — align related elements for visual consistency\n"
        "5. `validate_slide_layout` — confirm the layout is clean\n"
    )


@mcp.prompt()
def create_all_hands(topic: str, company: str = "") -> str:
    """Generate an all-hands meeting deck with achievements, metrics, and team recognition."""
    return (
        f"Create an all-hands meeting presentation about: {topic}\n"
        f"Company: {company or '(not specified)'}\n\n"
        "Steps:\n"
        f'1. Call generate_presentation with topic="{topic}", '
        f'audience="general", num_slides=10, deck_type="all_hands"'
        f'{f", company={company!r}" if company else ""}\n'
        "2. Review the output path and confirm success\n\n"
        "The deck uses the all_hands archetype: title, agenda, highlights, "
        "key metrics, roadmap, new team members, and closing."
    )


@mcp.prompt()
def create_consulting_deck(
    deck_type: str,
    topic: str,
    company: str = "",
    audience: str = "executive",
) -> str:
    """Generate a consulting-grade deck from an archetype.

    Lists available consulting archetypes and generates a professional
    presentation using the consulting brand preset with slide numbers
    and confidential marking.
    """
    consulting_types = [
        "assessment", "opportunity_assessment", "strategy_training",
        "template_guide", "executive_overview", "analysis_deck",
        "cost_breakdown", "architecture_review", "analytics_dashboard",
        "strategy_deck", "due_diligence", "market_analysis",
        "org_design", "competitive_assessment", "transformation_roadmap",
    ]
    type_list = ", ".join(consulting_types)
    return (
        f"Create a consulting-grade presentation about: {topic}\n"
        f"Deck type: {deck_type}\n"
        f"Company: {company or '(not specified)'}\n"
        f"Target audience: {audience}\n\n"
        f"Available consulting archetypes: {type_list}\n\n"
        "Steps:\n"
        f'1. Call generate_presentation with topic="{topic}", '
        f'audience="{audience}", num_slides=12, deck_type="{deck_type}", '
        f'brand_preset="consulting"'
        f'{f", company={company!r}" if company else ""}\n'
        "2. Review the output path and confirm success\n\n"
        "The consulting preset includes slide numbers, date footers, "
        "confidential marking, and professional card styling with subtle shadows."
    )


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------


@mcp.resource("pptx://schema/slide-definition")
def slide_definition_schema() -> str:
    """JSON schema for SlideDefinition."""
    return json.dumps(SlideDefinition.model_json_schema(), indent=2)


@mcp.resource("pptx://schema/presentation-definition")
def presentation_definition_schema() -> str:
    """JSON schema for PresentationDefinition."""
    return json.dumps(PresentationDefinition.model_json_schema(), indent=2)


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------


def run_server() -> None:
    """Start the MCP server."""
    logger.info("Starting PPTX MCP server")
    mcp.run()


if __name__ == "__main__":
    run_server()
