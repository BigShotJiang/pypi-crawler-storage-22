# System Overview

## Module Map

```
pptx_mcp/
├── server.py              ← MCP tool entry points (20 tools, 7 prompts, 2 resources)
├── cli.py                 ← CLI interface (serve, generate, read, review, plan, improve)
├── models/
│   ├── slides.py          ← Core models: SlideType(24), SlideDefinition, PresentationDefinition
│   ├── brand.py           ← BrandConfig, HeaderFooterConfig, ShapeStyleConfig
│   └── review.py          ← ReviewResult, ReviewIssue, Severity
├── engine/
│   ├── generator.py       ← DeckGenerator: definition → .pptx file
│   ├── parser.py          ← parse_presentation() + ingest_presentation()
│   ├── describer.py       ← describe_slide() + describe_presentation()
│   ├── layouts.py         ← Per-type renderers (render_*_slide functions)
│   ├── charts.py          ← Chart rendering (bar, line, pie, column, area)
│   ├── shapes.py          ← Shape/connector rendering, color parsing
│   ├── composition.py     ← LayoutGrid, auto_layout() for grid positioning
│   └── spec_parser.py     ← Markdown spec → PresentationDefinition
├── brand/
│   ├── config.py          ← resolve_brand_config()
│   └── defaults.py        ← 6 preset BrandConfigs
├── agents/
│   ├── planner.py         ← SlidePlannerAgent: topic → slide plan
│   ├── content_mapper.py  ← suggest_slide_type(): keyword → SlideType
│   ├── designer.py        ← DesignAgent: optimize layout/composition
│   ├── reviewer.py        ← ReviewAgent: structured review
│   ├── iterator.py        ← IterationAgent: auto-fix issues
│   ├── archetypes.py      ← 12 deck archetypes
│   └── base.py            ← BaseAgent ABC
├── review/
│   ├── engine.py          ← ReviewEngine: runs rules, computes scores
│   └── rules.py           ← SLIDE_RULES + DECK_RULES
└── utils/
    ├── errors.py          ← PptxMcpError hierarchy
    ├── logging.py         ← Structured logging
    └── paths.py           ← Path validation
```

## Data Flow

```
Topic/KeyPoints → SlidePlannerAgent → PresentationDefinition
                                        ↓
                                    DesignAgent (optimize)
                                        ↓
                                    DeckGenerator → .pptx file
                                        ↓
                                    ReviewEngine → ReviewResult

Existing .pptx → parse_presentation() → PresentationDefinition
             → ingest_presentation() → PresentationDefinition (for restyle)
             → describe_presentation() → Natural-language analysis
```
