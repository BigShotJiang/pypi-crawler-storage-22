# Current Sprint — Phase 4 (Fidelity Fixes)

**Goal:** Fix all 12 issues from spec-vs-output analysis, improve round-trip fidelity

**Source:** `/Users/swak/Documents/Sandbox/pptx-mcp-phase2-analysis.md`

| Task | Severity | Status | Notes |
|------|----------|--------|-------|
| Content slide multi-column | P0 | ✅ Done | 3-6 column rendering + subtitle |
| Title slide parser classification | P0 | ✅ Done | Centered layout heuristic (not just index 0) |
| Configurable accent bar | P1 | ✅ Done | `show_accent_bar` on ShapeStyleConfig |
| Shape border-only rendering | P1 | ✅ Done | Default 1pt when color set without width |
| Title/subtitle style overrides | P2 | ✅ Done | `title_style` / `subtitle_style` on SlideDefinition |
| Bullet list style priority | P2 | ✅ Done | elem.style overrides brand defaults |
| Parser: textbox fill colors | P3 | ✅ Done | `_extract_fill_color()` helper |
| Parser: shape type detection | P3 | ✅ Done | 12-entry `_REVERSE_SHAPE_MAP` |
| Parser: shape fill/border | P3 | ✅ Done | fill_color, border_color, border_width |
| Parser: table cell styling | P3 | ✅ Done | fill_color + text style extraction |
| Parser: empty-text auto shapes | — | ✅ Done | Gap fix for shapes with text_frame but no text |
| Tests | — | ✅ Done | 27 new tests (453 total) |

**Result:** All 12 analysis issues resolved. Weighted fidelity target: ~66% → ~95%+

## Previous: Phase 3 (completed)

| Task | Status | Notes |
|------|--------|-------|
| CARD_GRID in planner | ✅ Done | Handler between ICON_GRID and IMAGE_TEXT |
| CARD_GRID in content mapper | ✅ Done | services/offerings/products keywords |
| CARD_GRID in parser | ✅ Done | Title keywords + _keyword_classify() |
| GroupElement rendering | ✅ Done | Recursive, depth-capped at 5 |
| _gather_text() fix | ✅ Done | All slide type fields included |
| check_card_count rule | ✅ Done | >6 cards / >8 KPIs warning |
| Slide describer module | ✅ Done | Pure functions, no LLM |
| analyze_presentation tool | ✅ Done | Parser + describer + review |
| .dev-team infrastructure | ✅ Done | ADRs, architecture, research, status |
| Tests | ✅ Done | ~35 new tests |
