"""Internal agents for slide planning, design, review, and iteration."""
