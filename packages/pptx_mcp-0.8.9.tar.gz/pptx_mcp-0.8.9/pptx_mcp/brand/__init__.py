"""Brand configuration and style management."""
