"""PPTX generation and parsing engine."""
