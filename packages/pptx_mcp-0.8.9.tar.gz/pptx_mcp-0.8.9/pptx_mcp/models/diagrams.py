"""Pydantic models for diagram slide types (v0.6.0)."""

from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field


class OrgNode(BaseModel):
    """A node in an org chart hierarchy."""

    id: str = Field(max_length=50)
    name: str = Field(max_length=200)
    role: Optional[str] = Field(default=None, max_length=200)
    children: list[OrgNode] = Field(default_factory=list, max_length=20)
    color: Optional[str] = None


# Recursive model — rebuild after definition
OrgNode.model_rebuild()


class MatrixQuadrant(BaseModel):
    """A single quadrant in a 2x2 matrix."""

    label: str = Field(max_length=200)
    items: list[str] = Field(default_factory=list, max_length=8)
    color: Optional[str] = None


class MatrixData(BaseModel):
    """Data for a 2x2 matrix diagram."""

    x_axis_label: Optional[str] = Field(default=None, max_length=100)
    y_axis_label: Optional[str] = Field(default=None, max_length=100)
    top_left: MatrixQuadrant
    top_right: MatrixQuadrant
    bottom_left: MatrixQuadrant
    bottom_right: MatrixQuadrant


class PyramidLayer(BaseModel):
    """A single layer in a pyramid diagram."""

    label: str = Field(max_length=200)
    description: Optional[str] = Field(default=None, max_length=500)
    color: Optional[str] = None


class VennCircle(BaseModel):
    """A single circle in a Venn diagram."""

    label: str = Field(max_length=200)
    items: list[str] = Field(default_factory=list, max_length=6)
    color: Optional[str] = None


class VennData(BaseModel):
    """Data for a Venn diagram with 2-3 circles."""

    circles: list[VennCircle] = Field(min_length=2, max_length=3)
    intersection_label: Optional[str] = Field(default=None, max_length=200)


class WaterfallBar(BaseModel):
    """A single bar in a waterfall (bridge) chart."""

    label: str = Field(max_length=100)
    value: float
    bar_type: Literal["increase", "decrease", "total"] = "increase"
    color: Optional[str] = None


class SpokeItem(BaseModel):
    """A spoke node in a hub-and-spoke diagram."""

    label: str = Field(max_length=200)
    description: Optional[str] = Field(default=None, max_length=500)
    color: Optional[str] = None


class CycleStep(BaseModel):
    """A step in a circular cycle diagram."""

    label: str = Field(max_length=200)
    description: Optional[str] = Field(default=None, max_length=500)
    color: Optional[str] = None


class GanttTask(BaseModel):
    """A task bar in a Gantt chart."""

    label: str = Field(max_length=200)
    start: float = Field(ge=0.0, description="Start as fraction 0.0-1.0")
    duration: float = Field(gt=0.0, le=1.0, description="Duration as fraction")
    progress: float = Field(default=0.0, ge=0.0, le=1.0)
    group: Optional[str] = Field(default=None, max_length=100)
    color: Optional[str] = None
