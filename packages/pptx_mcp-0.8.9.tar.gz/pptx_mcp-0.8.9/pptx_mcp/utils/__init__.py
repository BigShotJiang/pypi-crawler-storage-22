"""Shared utilities for logging, errors, and helpers."""
