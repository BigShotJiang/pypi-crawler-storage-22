"""Custom exceptions for PPTX MCP."""


class PptxMcpError(Exception):
    """Base exception for all PPTX MCP errors."""


class SlideDefinitionError(PptxMcpError):
    """Raised when a slide definition is invalid or malformed."""


class BrandConfigError(PptxMcpError):
    """Raised when brand configuration is invalid or missing required fields."""


class GenerationError(PptxMcpError):
    """Raised when PPTX generation fails."""


class ParseError(PptxMcpError):
    """Raised when parsing an existing PPTX fails."""


class ReviewError(PptxMcpError):
    """Raised when deck review encounters an error."""


class AgentError(PptxMcpError):
    """Raised when an internal agent encounters an error."""


class PathValidationError(PptxMcpError):
    """Raised when a file path fails validation."""
