"""Logging configuration for PPTX MCP."""

from __future__ import annotations

import logging
import sys


_LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
_configured = False


def configure_logging(level: int = logging.INFO) -> None:
    """Configure root logger for pptx_mcp namespace."""
    global _configured
    if _configured:
        return

    root = logging.getLogger("pptx_mcp")
    root.setLevel(level)

    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter(_LOG_FORMAT))
    root.addHandler(handler)
    _configured = True


def get_logger(name: str) -> logging.Logger:
    """Get a namespaced logger for a module.

    Args:
        name: Module name (e.g., "engine.generator"). Will be prefixed with "pptx_mcp.".

    Returns:
        Configured logger instance.
    """
    configure_logging()
    return logging.getLogger(f"pptx_mcp.{name}")
