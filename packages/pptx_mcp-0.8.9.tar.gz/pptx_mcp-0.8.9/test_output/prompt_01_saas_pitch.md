# Prompt 1: SaaS Startup Pitch Deck

## Instructions for AI

Create a 10-slide pitch deck for **Vaultkey**, a B2B SaaS startup that provides passwordless authentication for enterprise applications. Use `plan_presentation` → `create_from_plan` workflow with brand_preset="startup" and deck_type="pitch_deck".

**Topic**: Vaultkey — Passwordless Authentication for the Enterprise

**Company**: Vaultkey, Inc.

**Audience**: Series A investors (executive)

**Key Points**:
- Passwords cause 81% of data breaches (Verizon DBIR) and cost enterprises $5.2M per incident on average
- Vaultkey replaces passwords with biometric + device-bound passkeys across any enterprise app
- 3 deployment options: SDK (2 lines of code), reverse proxy, or SAML/OIDC federation
- Current traction: 42 enterprise customers, 380K monthly active users, $2.1M ARR, 18% MoM growth
- Team: CEO ex-Okta VP Engineering, CTO ex-Google Identity Platform, CISO ex-CrowdStrike
- $87B TAM in identity & access management by 2028 (Gartner)
- Asking $12M Series A at $60M pre-money valuation
- Competitors (Okta, Auth0, Microsoft Entra) still rely on password-first architecture

**Context**: This is for a partner meeting at Andreessen Horowitz. The deck should be bold, data-forward, and tell a clear problem→solution→traction→ask narrative arc. Emphasize the speed of deployment (minutes, not months) versus legacy IAM solutions.

---

## Expected Slide Structure

| # | Type | Title | Key Content |
|---|------|-------|-------------|
| 1 | TITLE | Vaultkey | Passwordless Authentication for the Enterprise |
| 2 | CONTENT | The Password Problem | 81% of breaches, $5.2M avg cost, 40% of helpdesk tickets |
| 3 | TWO_COLUMN | Our Solution | Left: How passkeys work (biometric + device). Right: 3 deployment modes |
| 4 | BIG_NUMBER | $2.1M ARR | 18% month-over-month growth, 42 enterprise customers |
| 5 | CHART | Growth Trajectory | Line chart: ARR from $0 to $2.1M over 14 months |
| 6 | COMPARISON | Vaultkey vs Legacy IAM | Deploy in minutes vs months, zero passwords vs password-first |
| 7 | DASHBOARD | Unit Economics | CAC $8.2K, LTV $142K, LTV:CAC 17.3x, NRR 138%, Gross Margin 89% |
| 8 | TEAM | Leadership | CEO, CTO, CISO with backgrounds |
| 9 | CONTENT | $87B Market Opportunity | TAM/SAM/SOM breakdown with Gartner citation |
| 10 | CLOSING | The Ask | $12M Series A, $60M pre-money, 18-month runway to Series B |
