# Prompt 3: Engineering Team Onboarding

## Instructions for AI

Create a 12-slide onboarding deck for new engineers joining **Meridian Health's** platform engineering team. Use `plan_presentation` → `create_from_plan` workflow with brand_preset="technical" and deck_type="onboarding".

**Topic**: Platform Engineering Onboarding — Meridian Health

**Company**: Meridian Health

**Audience**: New engineering hires (technical)

**Key Points**:
- Meridian Health processes 2.3M patient encounters/day across 340 hospitals and 1,200 clinics
- Platform team owns the core infrastructure: Kubernetes (EKS), event mesh (Kafka), API gateway, observability stack
- Architecture: 380 microservices, 12 domain-bounded contexts, event-driven with CQRS pattern
- Tech stack: Go (API services), Python (ML pipelines), TypeScript (BFF layer), Terraform (IaC), ArgoCD (GitOps)
- Deployment: 450+ deploys/week to production, blue-green with canary analysis, <5min rollback SLA
- HIPAA compliance is non-negotiable — all data encrypted at rest (AES-256) and in transit (mTLS), audit logging on every API call
- On-call rotation: 4 teams, 1-week cycles, PagerDuty escalation, 15-minute P1 response SLA
- First 90 days: Week 1-2 environment setup + shadow on-call, Week 3-6 first PRs + code review, Week 7-12 own a service
- Key systems to learn: Heimdall (auth service), Pulse (patient data pipeline), Atlas (service mesh config), Beacon (alerting)

**Context**: This deck is presented by the VP of Engineering on Day 1. It should be information-dense but scannable — new hires will reference it repeatedly during their first month. Use diagrams and icon grids where possible. The tone should be welcoming but technically precise.

---

## Expected Slide Structure

| # | Type | Title | Key Content |
|---|------|-------|-------------|
| 1 | TITLE | Welcome to Platform Engineering | Meridian Health — Your First 90 Days |
| 2 | CONTENT | Meridian Health at Scale | 2.3M encounters/day, 340 hospitals, 1,200 clinics |
| 3 | BIG_NUMBER | 380 | Microservices in production — and you'll own some of them |
| 4 | HUB_SPOKE | Platform Architecture | Core: API Gateway. Spokes: Auth, Patient Data, Analytics, Billing, Scheduling, Pharmacy |
| 5 | ICON_GRID | Tech Stack | Go, Python, TypeScript, Terraform, ArgoCD, Kafka, EKS, Datadog |
| 6 | PROCESS | Deployment Pipeline | Code → PR Review → Staging → Canary → Production (blue-green) |
| 7 | TABLE | Key Systems Reference | System name, Owner team, Purpose, Repo link for each core system |
| 8 | CARD_GRID | HIPAA Compliance Essentials | Cards: Encryption at Rest, mTLS in Transit, Audit Logging, Access Controls, PHI Handling, Incident Response |
| 9 | TIMELINE | Your First 90 Days | Week 1-2: Setup + Shadow, Week 3-6: First PRs, Week 7-12: Own a Service |
| 10 | DASHBOARD | Team Health Metrics | Deploys/week: 450, MTTR: 4.2min, P1 SLA: 15min, Uptime: 99.97% |
| 11 | STEP_CARDS | Week 1 Checklist | 4 steps: Dev environment, VPN + access, Shadow on-call, First codebase tour |
| 12 | CLOSING | Let's Build | Slack: #platform-eng, Wiki: meridian.wiki/platform, On-call: PagerDuty |
