# MCP Sandbox Test Prompts

Ready-to-paste prompts for testing pptx-mcp v0.5.0 features in an MCP sandbox (Claude Desktop or similar). Each prompt exercises a distinct combination of tools, brand presets, and deck archetypes.

## Coverage Matrix

| # | Prompt | Tool(s) | Preset | Archetype | Validates |
|---|--------|---------|--------|-----------|-----------|
| 1 | Healthcare Assessment | `generate_presentation` | healthcare | assessment | New preset + new archetype |
| 2 | Startup Pitch | `generate_presentation` | startup | pitch_deck | New preset + existing archetype |
| 3 | Finance Quarterly Earnings | `plan_presentation` → `create_from_plan` | finance | quarterly_earnings | Two-step workflow |
| 4 | Government Architecture Review | `generate_presentation` | government | architecture_review | Formal tone, complex archetype |
| 5 | Nonprofit Annual Report | `generate_presentation` | nonprofit | annual_report | Warm brand, TEAM + TIMELINE |
| 6 | Academic Conference Talk | `generate_presentation` | academic | conference_talk | Scholarly brand, dense text |
| 7 | Brand Guide Showcase | `generate_brand_guide` (x3) | healthcare, finance, startup | n/a | Brand guide tool |
| 8 | Consulting Cost Breakdown | `generate_presentation` | consulting | cost_breakdown | Existing preset + new archetype |
| 9 | Markdown Spec Parser | `parse_spec` | (spec-defined) | n/a | Full markdown spec format |
| 10 | Multi-Preset Comparison | `generate_presentation` (x6) | all 6 new | executive_overview | Same content, all new presets |

---

## Prompt 1: Healthcare Assessment

```
Create a healthcare compliance assessment presentation for "Regional Medical Center" evaluating their HIPAA readiness.

Use the generate_presentation tool with:
- topic: "HIPAA Compliance Assessment: Regional Medical Center"
- output_path: "/tmp/healthcare_assessment.pptx"
- brand_preset: "healthcare"
- deck_type: "assessment"
- num_slides: 10
- audience: "executive"
- company: "Regional Medical Center"
- key_points: ["94% policy compliance rate", "3 critical gaps identified", "12-month remediation timeline", "$2.1M investment required"]
```

---

## Prompt 2: Startup Pitch Deck

```
Build a pitch deck for a fintech startup called "PayFlow" that's raising their Series A.

Use the generate_presentation tool with:
- topic: "PayFlow: Instant Cross-Border Payments for SMBs"
- output_path: "/tmp/startup_pitch.pptx"
- brand_preset: "startup"
- deck_type: "pitch_deck"
- num_slides: 10
- audience: "executive"
- company: "PayFlow"
- key_points: ["$4.2M ARR growing 340% YoY", "12,000 active merchants", "47 countries supported", "$850B total addressable market", "Raising $25M Series A"]
```

---

## Prompt 3: Finance Quarterly Earnings (Two-Step)

```
Create a quarterly earnings presentation for "Meridian Capital Group" for Q4 2025 using the two-step workflow.

Step 1: Call plan_presentation with:
- topic: "Q4 2025 Quarterly Earnings Report"
- deck_type: "quarterly_earnings"
- num_slides: 10
- audience: "executive"
- company: "Meridian Capital Group"
- key_points: ["$847M revenue, up 18% YoY", "EPS $3.42 vs $2.89 consensus", "AUM grew to $42.3B", "Operating margin expanded to 34%", "2026 guidance raised to $3.8B"]

Step 2: After reviewing the plan summary, call create_from_plan with:
- plan_id: (use the plan_id from step 1)
- output_path: "/tmp/finance_earnings.pptx"
- brand_preset: "finance"
- optimize: true
```

---

## Prompt 4: Government Architecture Review

```
Create an IT architecture review presentation for a federal agency modernization project.

Use the generate_presentation tool with:
- topic: "Enterprise Architecture Modernization: FedCloud Migration"
- output_path: "/tmp/gov_architecture.pptx"
- brand_preset: "government"
- deck_type: "architecture_review"
- num_slides: 12
- audience: "executive"
- company: "Department of Digital Services"
- key_points: ["187 legacy applications assessed", "62% eligible for cloud migration", "FedRAMP High compliance required", "$34M 3-year investment", "Zero-trust architecture baseline"]
```

---

## Prompt 5: Nonprofit Annual Report

```
Create an annual report for a climate nonprofit called "GreenPath Foundation".

Use the generate_presentation tool with:
- topic: "GreenPath Foundation 2025 Annual Report: Our Impact"
- output_path: "/tmp/nonprofit_annual.pptx"
- brand_preset: "nonprofit"
- deck_type: "annual_report"
- num_slides: 10
- audience: "general"
- company: "GreenPath Foundation"
- key_points: ["2.4M trees planted this year", "45 community programs launched", "92% donor satisfaction", "$18.7M raised from 34,000 donors", "Carbon offset: 127,000 metric tons"]
```

---

## Prompt 6: Academic Conference Talk

```
Create a conference presentation for an AI research paper being presented at a machine learning conference.

Use the generate_presentation tool with:
- topic: "Sparse Mixture-of-Experts for Efficient Multi-Modal Reasoning"
- output_path: "/tmp/academic_talk.pptx"
- brand_preset: "academic"
- deck_type: "conference_talk"
- num_slides: 8
- audience: "technical"
- company: "Stanford AI Lab"
- key_points: ["37% reduction in compute cost vs dense models", "State-of-the-art on 4 benchmarks", "Novel routing mechanism with O(log n) complexity", "Open-source release with 12B and 70B variants"]
```

---

## Prompt 7: Brand Guide Showcase (3 guides)

```
Generate brand guide PPTX files for three of the new brand presets so I can compare their visual identities side by side.

Call the generate_brand_guide tool three times:

1. Healthcare brand guide:
   - output_path: "/tmp/brand_guide_healthcare.pptx"
   - brand_preset: "healthcare"

2. Finance brand guide:
   - output_path: "/tmp/brand_guide_finance.pptx"
   - brand_preset: "finance"

3. Startup brand guide:
   - output_path: "/tmp/brand_guide_startup.pptx"
   - brand_preset: "startup"

After generating all three, tell me the slide count and key visual differences between each guide.
```

---

## Prompt 8: Consulting Cost Breakdown

```
Create a cost optimization analysis for a cloud infrastructure migration project.

Use the generate_presentation tool with:
- topic: "Cloud Infrastructure Cost Optimization Analysis"
- output_path: "/tmp/consulting_cost.pptx"
- brand_preset: "consulting"
- deck_type: "cost_breakdown"
- num_slides: 10
- audience: "executive"
- company: "Apex Technologies"
- key_points: ["$12.4M current annual spend", "38% potential savings identified", "Top 3 cost drivers: compute (45%), storage (28%), networking (15%)", "ROI breakeven in 8 months", "Migration to reserved instances saves $4.7M/yr"]
```

---

## Prompt 9: Markdown Spec (Full Format)

```
Parse this markdown presentation spec and generate a PPTX file.

Use the parse_spec tool with output_path "/tmp/spec_parsed.pptx" and brand_preset "startup" and this markdown:

# Product Launch: NexaSync Platform

## Global Design System

### Color Palette
- `primary`: #6C5CE7
- `secondary`: #A29BFE
- `accent`: #00D2D3
- `background`: #FFFFFF
- `text_primary`: #2D3436

### Typography
- Heading: 38pt
- Subheading: 22pt
- Body: 16pt
- Caption: 11pt

## Slide 1: Title Slide
NexaSync: Real-Time Data Synchronization for the Enterprise

## Slide 2: The Problem
- Data silos cost enterprises $12.9M annually in lost productivity
- 73% of teams report inconsistent data across systems
- Average sync latency: 47 minutes with current solutions
- Compliance risk from stale data in regulated industries

## Slide 3: Key Metrics Dashboard
- $12.9M: Average Annual Data Silo Cost
- 73%: Teams With Inconsistent Data
- 47min: Average Sync Latency
- 4.2x: Productivity Gain With NexaSync

## Slide 4: Solution Architecture
| Component | Technology | Benefit |
|-----------|-----------|---------|
| Sync Engine | Event-driven CRDT | Sub-second consistency |
| API Gateway | GraphQL Federation | Single unified endpoint |
| Storage | Multi-model polyglot | Right tool for each data type |
| Security | Zero-trust mesh | End-to-end encryption |

## Slide 5: Implementation Roadmap
- Phase 1: Core platform deployment (Week 1-4)
- Phase 2: Integration connectors (Week 5-8)
- Phase 3: Advanced analytics (Week 9-12)
- Phase 4: Enterprise rollout (Week 13-16)

> **Note:** All phases include dedicated security review gates

## Slide 6: Competitive Comparison
- NexaSync delivers 10x faster sync than legacy ETL tools
- Only solution with built-in CRDT conflict resolution
- 99.99% uptime SLA vs industry average of 99.5%

## Slide 7: Next Steps
- Schedule a technical deep-dive demo
- Begin pilot program with 3 departments
- Define success metrics and KPIs
- Target production deployment in Q3 2026
```

---

## Prompt 10: Multi-Preset Comparison

```
I want to see how the same content looks across all 6 new brand presets. Generate 6 executive overview decks with identical content but different presets.

For each of the following presets, call generate_presentation with:
- topic: "Digital Transformation Executive Briefing"
- deck_type: "executive_overview"
- num_slides: 8
- audience: "executive"
- company: "Atlas Global"
- key_points: ["$340M digital investment portfolio", "78% of initiatives on track", "23% improvement in customer NPS", "4 strategic pillars defined"]

Presets and output paths:
1. brand_preset: "healthcare" → output_path: "/tmp/compare_healthcare.pptx"
2. brand_preset: "startup" → output_path: "/tmp/compare_startup.pptx"
3. brand_preset: "academic" → output_path: "/tmp/compare_academic.pptx"
4. brand_preset: "government" → output_path: "/tmp/compare_government.pptx"
5. brand_preset: "finance" → output_path: "/tmp/compare_finance.pptx"
6. brand_preset: "nonprofit" → output_path: "/tmp/compare_nonprofit.pptx"

After generating all 6, summarize the visual differences.
```
