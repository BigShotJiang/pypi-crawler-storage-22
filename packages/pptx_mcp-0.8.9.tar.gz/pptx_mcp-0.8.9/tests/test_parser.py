"""Tests for the PPTX parser."""

from __future__ import annotations

from pathlib import Path

import pytest

from pptx_mcp.brand.defaults import executive_default
from pptx_mcp.engine.generator import DeckGenerator
from pptx_mcp.engine.parser import parse_presentation
from pptx_mcp.models.slides import (
    ColumnContent,
    PresentationDefinition,
    PresentationMetadata,
    SlideDefinition,
    SlideType,
)


@pytest.fixture
def output_dir(tmp_path: Path) -> Path:
    return tmp_path


@pytest.fixture
def generator() -> DeckGenerator:
    return DeckGenerator(brand=executive_default())


def _generate_and_parse(
    generator: DeckGenerator,
    output_dir: Path,
    slides: list[SlideDefinition],
    filename: str = "test.pptx",
) -> PresentationDefinition:
    """Helper: generate a deck then parse it back."""
    definition = PresentationDefinition(
        metadata=PresentationMetadata(title="Parse Test"),
        slides=slides,
    )
    path = generator.generate(definition, output_dir / filename)
    return parse_presentation(path)


class TestRoundTrip:
    def test_title_slide_roundtrip(self, generator: DeckGenerator, output_dir: Path) -> None:
        parsed = _generate_and_parse(generator, output_dir, [
            SlideDefinition(
                slide_type=SlideType.TITLE,
                title="Round Trip Title",
                subtitle="Subtitle Text",
            ),
        ])
        assert len(parsed.slides) == 1
        assert parsed.slides[0].title is not None
        assert "Round Trip Title" in parsed.slides[0].title

    def test_content_slide_roundtrip(self, generator: DeckGenerator, output_dir: Path) -> None:
        parsed = _generate_and_parse(generator, output_dir, [
            SlideDefinition(
                slide_type=SlideType.CONTENT,
                title="Content Slide",
                bullets=["Alpha", "Beta", "Gamma"],
            ),
        ])
        assert len(parsed.slides) == 1
        slide = parsed.slides[0]
        assert slide.title is not None

    def test_multi_slide_roundtrip(self, generator: DeckGenerator, output_dir: Path) -> None:
        parsed = _generate_and_parse(generator, output_dir, [
            SlideDefinition(slide_type=SlideType.TITLE, title="Deck Title"),
            SlideDefinition(
                slide_type=SlideType.CONTENT,
                title="Slide 2",
                bullets=["Point A"],
            ),
            SlideDefinition(slide_type=SlideType.SECTION, title="Break"),
            SlideDefinition(
                slide_type=SlideType.TWO_COLUMN,
                title="Columns",
                columns=[
                    ColumnContent(title="Left", bullets=["L1"]),
                    ColumnContent(title="Right", bullets=["R1"]),
                ],
            ),
        ])
        assert len(parsed.slides) == 4

    def test_metadata_preserved(self, generator: DeckGenerator, output_dir: Path) -> None:
        definition = PresentationDefinition(
            metadata=PresentationMetadata(
                title="Metadata Check",
                author="Tester",
                subject="Unit Tests",
            ),
            slides=[SlideDefinition(slide_type=SlideType.TITLE, title="Meta")],
        )
        path = generator.generate(definition, output_dir / "meta.pptx")
        parsed = parse_presentation(path)
        assert parsed.metadata.title == "Metadata Check"
        assert parsed.metadata.author == "Tester"


class TestParserErrors:
    def test_nonexistent_file(self) -> None:
        from pptx_mcp.utils.errors import ParseError

        with pytest.raises(ParseError, match="not found"):
            parse_presentation("/nonexistent/path.pptx")
