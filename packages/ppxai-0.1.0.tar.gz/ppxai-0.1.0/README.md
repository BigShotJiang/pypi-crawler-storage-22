# ppx

Perplexity AI search from your terminal. Zero dependencies.

## Install

```bash
pip install ppxai
```

## Setup

Get an API key from [perplexity.ai/settings/api](https://www.perplexity.ai/settings/api), then:

```bash
export PERPLEXITY_API_KEY=pplx-...
```

Or save it permanently:

```bash
mkdir -p ~/.config/ppx
echo "PERPLEXITY_API_KEY=pplx-..." > ~/.config/ppx/config
chmod 600 ~/.config/ppx/config
```

## Usage

```bash
# Default: research mode (sonar-pro)
ppx "best practices for Python async"

# Quick question
ppx --ask "latest Python version"

# Direct web results (no AI synthesis)
ppx --search "FastAPI middleware" --max-results 5

# Chain-of-thought reasoning
ppx --reason "Redis vs PostgreSQL for sessions"

# Deep research (requires cost confirmation)
ppx --deep --yes-expensive "comprehensive guide to OpenTelemetry"

# JSON output (pipe to jq, scripts, etc.)
ppx --json "test query" | python -m json.tool
```

## Modes & Cost

| Flag | Model | Cost/query | Use for |
|------|-------|------------|---------|
| *(default)* | sonar-pro | ~$0.05 | General research |
| `--ask` | sonar | ~$0.01 | Quick factual questions |
| `--search` | *(direct)* | ~$0.01 | Raw web results |
| `--reason` | sonar-reasoning-pro | ~$0.10 | Complex decisions |
| `--deep` | sonar-deep-research | ~$3.00 | Exhaustive research |

`--deep` requires `--yes-expensive` to prevent accidental spend.

## Options

| Flag | Description |
|------|-------------|
| `--json` | Output raw JSON |
| `--max-results N` | Max results for `--search` (default: 10) |
| `--recency PERIOD` | Filter: day, week, month, year |
| `--domains DOMAIN` | Limit to specific domains |
| `--model MODEL` | Override model selection |
| `--yes-expensive` | Confirm `--deep` queries |

## License

MIT
