"""Allow running as `python -m ppx`."""
from ppx.cli import main

main()
