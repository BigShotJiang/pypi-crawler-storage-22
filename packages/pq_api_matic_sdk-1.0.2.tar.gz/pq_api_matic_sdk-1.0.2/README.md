
# Getting Started with PQ API v2

## Introduction

PayQuicker offers a secure and instant payout platform that delivers payment to a payee-owned and insured bank account linked to a debit card, similar to a standard checking account.

As soon as the payment is made, funds are available in the insured account and available to spend instantly online through a virtual card, at retail with a plastic prepaid debit card, or by loading the card to a mobile wallet.

PayQuicker provides a RESTful API that allows authorized clients to send and receive payments, debit user's accounts for spendback, retrieve user account balance, retrieve user reports, and retrieve transaction reports.

## Install the Package

The package is compatible with Python versions `3.7+`.
Install the package from PyPi using the following pip command:

```bash
pip install pq-api-matic-sdk==1.0.2
```

You can also view the package at:
https://pypi.python.org/pypi/pq-api-matic-sdk/1.0.2

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| x_my_pay_quicker_version | `str` | Date-based API Version specified in the header *required* on all calls.<br>*Default*: `"2026.02.01"` |
| sandbox_instance | `SandboxInstance` | Sandbox Environments<br>*Default*: `"sandbox"` |
| uat_instance | `UatInstance` | UAT Environments<br>*Default*: `"uat1"` |
| environment | [`Environment`](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/README.md#environments) | The API environment. <br> **Default: `Environment.SANDBOX`** |
| http_client_instance | `Union[Session, HttpClientProvider]` | The Http Client passed from the sdk user for making requests |
| override_http_client_configuration | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| http_call_back | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| timeout | `float` | The value to use for connection timeout. <br> **Default: 60** |
| max_retries | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| backoff_factor | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| retry_statuses | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array of string` | The http methods on which retry is to be done. <br> **Default: ["GET", "PUT"]** |
| proxy_settings | [`ProxySettings`](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |
| logging_configuration | [`LoggingConfiguration`](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/logging-configuration.md) | The SDK logging configuration for API calls |
| server_credentials | [`ServerCredentials`](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/auth/oauth-2-client-credentials-grant.md) | The credential object for OAuth 2 Client Credentials Grant |
| clientside_credentials | [`ClientsideCredentials`](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/auth/oauth-2-bearer-token.md) | The credential object for OAuth 2 Bearer token |

The API client can be initialized as follows:

### Code-Based Client Initialization

```python
import logging

from payquickersdk.configuration import Environment
from payquickersdk.http.auth.clientside import ClientsideCredentials
from payquickersdk.http.auth.server import ServerCredentials
from payquickersdk.logging.configuration.api_logging_configuration import LoggingConfiguration
from payquickersdk.logging.configuration.api_logging_configuration import RequestLoggingConfiguration
from payquickersdk.logging.configuration.api_logging_configuration import ResponseLoggingConfiguration
from payquickersdk.models.o_auth_scope_server import OAuthScopeServer
from payquickersdk.models.sandbox_instance import SandboxInstance
from payquickersdk.models.uat_instance import UatInstance
from payquickersdk.pay_quicker_sdk_client import PayQuickerSdkClient

client = PayQuickerSdkClient(
    x_my_pay_quicker_version='2026.02.01',
    server_credentials=ServerCredentials(
        o_auth_client_id='OAuthClientId',
        o_auth_client_secret='OAuthClientSecret',
        o_auth_scopes=[
            OAuthScopeServer.READONLY,
            OAuthScopeServer.MODIFY
        ]
    ),
    clientside_credentials=ClientsideCredentials(
        access_token='AccessToken'
    ),
    environment=Environment.SANDBOX,
    sandbox_instance=SandboxInstance.SANDBOX,
    uat_instance=UatInstance.UAT1,
    logging_configuration=LoggingConfiguration(
        log_level=logging.INFO,
        request_logging_config=RequestLoggingConfiguration(
            log_body=True
        ),
        response_logging_config=ResponseLoggingConfiguration(
            log_headers=True
        )
    )
)
```

### Environment-Based Client Initialization

```python
from payquickersdk.pay_quicker_sdk_client import PayQuickerSdkClient

# Specify the path to your .env file if it’s located outside the project’s root directory.
client = PayQuickerSdkClient.from_environment(dotenv_path='/path/to/.env')
```

See the [Environment-Based Client Initialization](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/environment-based-client-initialization.md) section for details.

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| PRODUCTION | Production |
| SANDBOX | **Default** Sandbox is used for both sandbox testing and customer UAT. |
| UAT | UAT is used for both sandbox testing and customer UAT. |
| DEVELOPMENT | Development is used for local development testing. |

## Authorization

This API uses the following authentication schemes.

* [`server (OAuth 2 Client Credentials Grant)`](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/auth/oauth-2-client-credentials-grant.md)
* [`clientside (OAuth 2 Bearer token)`](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/auth/oauth-2-bearer-token.md)

## List of APIs

* [Agreements](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/agreements.md)
* [Balances](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/balances.md)
* [Bank Accounts](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/bank-accounts.md)
* [Client Side](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/client-side.md)
* [Compliance](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/compliance.md)
* [Documents](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/documents.md)
* [Electronic Wallets](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/electronic-wallets.md)
* [Events](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/events.md)
* [Invitations](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/invitations.md)
* [Jobs](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/jobs.md)
* [Payments](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/payments.md)
* [Prepaid Cards](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/prepaid-cards.md)
* [Program](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/program.md)
* [Receipts](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/receipts.md)
* [Spendback](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/spendback.md)
* [Spendback Refunds](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/spendback-refunds.md)
* [Statements](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/statements.md)
* [Transfers](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/transfers.md)
* [Users](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/users.md)
* [Webhooks](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/controllers/webhooks.md)

## SDK Infrastructure

### Configuration

* [ProxySettings](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/proxy-settings.md)
* [Environment-Based Client Initialization](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/environment-based-client-initialization.md)
* [AbstractLogger](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/abstract-logger.md)
* [LoggingConfiguration](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/logging-configuration.md)
* [RequestLoggingConfiguration](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/request-logging-configuration.md)
* [ResponseLoggingConfiguration](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/response-logging-configuration.md)

### HTTP

* [HttpResponse](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/http-response.md)
* [HttpRequest](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/http-request.md)

### Utilities

* [ApiHelper](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/api-helper.md)
* [HttpDateTime](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/http-date-time.md)
* [RFC3339DateTime](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/rfc3339-date-time.md)
* [UnixDateTime](https://www.github.com/sdks-io/pq-api-matic-python-sdk/tree/1.0.2/doc/unix-date-time.md)

