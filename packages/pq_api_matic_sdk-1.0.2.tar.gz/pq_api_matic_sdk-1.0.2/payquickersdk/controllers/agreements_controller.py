"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.authentication.multiple.single_auth import (
    Single,
)
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.api_error_result_exception import (
    ApiErrorResultException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.agreement_list_result_json import (
    AgreementListResultJson,
)
from payquickersdk.models.agreement_result import (
    AgreementResult,
)


class AgreementsController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize AgreementsController object."""
        super(AgreementsController, self).__init__(config)

    def list_agreements(self,
                        program_token,
                        page,
                        page_size,
                        filter=None,
                        sort=None,
                        language=None):
        """Perform a GET request to /programs/{program-token}/agreements.

        Retrieve a list of program [agreements](page:resources/agreements) that
        supports filtering, sorting, and pagination through existing mechanisms.

        Args:
            program_token (str): Auto-generated unique identifier representing a
                program, prefixed with `prog-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            AgreementListResultJson: Response from the API. Sample Program Agreements
                List Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/programs/{program-token}/agreements")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("program-token")
                .value(program_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(AgreementListResultJson.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_program_agreement(self,
                                   program_token,
                                   agreement_token):
        """Perform a GET request to
        /programs/{program-token}/agreements/{agreement-token}.

        Retrieve a single program [agreement](page:resources/agreements).

        Args:
            program_token (str): Auto-generated unique identifier representing a
                program, prefixed with `prog-`.
            agreement_token (str): Auto-generated unique identifier representing a
                program agreement, prefixed with `agmt-`.

        Returns:
            AgreementResult: Response from the API. Sample Program Agreement Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/programs/{program-token}/agreements/{agreement-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("program-token")
                .value(program_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("agreement-token")
                .value(agreement_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(AgreementResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def accept_agreement(self,
                         user_token,
                         agreement_token):
        """Perform a POST request to
        /users/{user-token}/agreements/{agreement-token}.

        Accept a single program [agreement](page:resources/agreements).

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            agreement_token (str): Auto-generated unique identifier representing a
                program agreement, prefixed with `agmt-`.

        Returns:
            void: Response from the API. OK

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/agreements/{agreement-token}")
            .http_method(HttpMethodEnum.POST)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("agreement-token")
                .value(agreement_token)
                .is_required(True)
                .should_encode(True))
            .auth(Single("server")),
        ).execute()
