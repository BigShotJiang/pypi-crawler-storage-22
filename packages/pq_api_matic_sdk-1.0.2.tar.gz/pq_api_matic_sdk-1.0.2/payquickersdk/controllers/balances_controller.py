"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.authentication.multiple.single_auth import (
    Single,
)
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.api_error_result_exception import (
    ApiErrorResultException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.balance_list_result import (
    BalanceListResult,
)
from payquickersdk.models.balance_result import (
    BalanceResult,
)


class BalancesController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize BalancesController object."""
        super(BalancesController, self).__init__(config)

    def list_account_balances(self,
                              account_token,
                              page,
                              page_size,
                              filter=None,
                              sort=None,
                              language=None):
        """Perform a GET request to /accounts/{account-token}/balances.

        Retrieve a list of bank account [balances](page:resources/balances) that
        supports filtering, sorting, and pagination through existing mechanisms.

        Args:
            account_token (str): Auto-generated unique identifier representing a
                company account, prefixed with `acct-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            BalanceListResult: Response from the API. Sample List Account Balances
                Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/accounts/{account-token}/balances")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("account-token")
                .value(account_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(BalanceListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def list_user_balances(self,
                           user_token,
                           page,
                           page_size,
                           filter=None,
                           sort=None,
                           language=None):
        """Perform a GET request to /users/{user-token}/balances.

        Retrieve a list of user [balances](page:resources/balances) that supports
        filtering, sorting, and pagination through existing mechanisms.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            BalanceListResult: Response from the API. Sample List Account Balances
                Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/balances")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(BalanceListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_card_balance(self,
                              user_token,
                              destination_token,
                              language=None):
        """Perform a GET request to
        /users/{user-token}/prepaid-cards/{destination-token}/balances.

        Retrieve a [prepaid card](page:resources/prepaid-cards)
        [balances](page:resources/balances) by destination token that supports
        filtering, sorting, and pagination through existing mechanisms.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            language (Languages, optional): Filter results by language type.

        Returns:
            BalanceResult: Response from the API. Sample Prepaid Card Balance

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards/{destination-token}/balances")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(BalanceResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()
