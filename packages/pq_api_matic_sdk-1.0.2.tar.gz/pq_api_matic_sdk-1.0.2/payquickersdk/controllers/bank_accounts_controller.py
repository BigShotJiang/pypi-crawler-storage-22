"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.authentication.multiple.single_auth import (
    Single,
)
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.api_error_result_exception import (
    ApiErrorResultException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.bank_account_list_result import (
    BankAccountListResult,
)
from payquickersdk.models.bank_account_requirement_list_result import (
    BankAccountRequirementListResult,
)
from payquickersdk.models.bank_account_result import (
    BankAccountResult,
)
from payquickersdk.models.operation_result import (
    OperationResult,
)


class BankAccountsController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize BankAccountsController object."""
        super(BankAccountsController, self).__init__(config)

    def list_bank_accounts(self,
                           user_token,
                           page,
                           page_size,
                           filter=None,
                           sort=None,
                           language=None):
        """Perform a GET request to /users/{user-token}/bank-accounts.

        Retrieve a list of [bank accounts](page:resources/bank-accounts) that
        supports filtering, sorting, and pagination through existing mechanisms.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            BankAccountListResult: Response from the API. Sample Bank Account List
                Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/bank-accounts")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(BankAccountListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def create_bank_account(self,
                            user_token,
                            body=None):
        """Perform a POST request to /users/{user-token}/bank-accounts.

        Create a [bank account](page:resources/bank-accounts) using a user token.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            body (CreateOrUpdateBankAccount, optional): The request body parameter.

        Returns:
            BankAccountResult: Response from the API. Sample Bank Account Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/bank-accounts")
            .http_method(HttpMethodEnum.POST)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(BankAccountResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_bank_account(self,
                              user_token,
                              destination_token,
                              page,
                              page_size,
                              filter=None,
                              sort=None,
                              language=None):
        """Perform a GET request to
        /users/{user-token}/bank-accounts/{destination-token}.

        Retrieve a single [bank account](page:resources/bank-accounts) using a
        destination token.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            BankAccountResult: Response from the API. Sample Bank Account Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/bank-accounts/{destination-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(BankAccountResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def update_bank_account(self,
                            user_token,
                            destination_token,
                            body=None):
        """Perform a PUT request to
        /users/{user-token}/bank-accounts/{destination-token}.

        Update a [bank account](page:resources/bank-accounts).

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            body (CreateOrUpdateBankAccount, optional): The request body parameter.

        Returns:
            BankAccountResult: Response from the API. Sample Bank Account Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/bank-accounts/{destination-token}")
            .http_method(HttpMethodEnum.PUT)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(BankAccountResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def delete_bank_account(self,
                            user_token,
                            destination_token):
        """Perform a DELETE request to
        /users/{user-token}/bank-accounts/{destination-token}.

        Delete a user [bank account](page:resources/bank-accounts).

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.

        Returns:
            OperationResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/bank-accounts/{destination-token}")
            .http_method(HttpMethodEnum.DELETE)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(OperationResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_creation_requirements(self,
                                       user_token,
                                       country=None,
                                       currency=None):
        """Perform a GET request to
        /users/{user-token}/bank-accounts/requirements.

        Retrieve requirements for adding a [bank
        account](page:resources/bank-accounts) using the parameters provided.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            country (Countries, optional): Filter results by country.
            currency (Currencies, optional): Filter results by currency.

        Returns:
            BankAccountRequirementListResult: Response from the API. Sample Bank
                Account Requirements List Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/bank-accounts/requirements")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("country")
                .value(country))
            .query_param(Parameter()
                .key("currency")
                .value(currency))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(BankAccountRequirementListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def list_company_bank_accounts(self,
                                   account_token,
                                   page,
                                   page_size,
                                   filter=None,
                                   sort=None,
                                   language=None):
        """Perform a GET request to /accounts/{account-token}/bank-accounts.

        Retrieve a list of company [bank accounts](page:resources/bank-accounts) that
        supports filtering, sorting, and pagination through existing mechanisms.

        Args:
            account_token (str): Auto-generated unique identifier representing a
                company account, prefixed with `acct-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            BankAccountListResult: Response from the API. Sample Bank Account List
                Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/accounts/{account-token}/bank-accounts")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("account-token")
                .value(account_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(BankAccountListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def create_company_bank_account(self,
                                    account_token,
                                    body=None):
        """Perform a POST request to /accounts/{account-token}/bank-accounts.

        Create a company [bank account](page:resources/bank-accounts) using an
        account token.

        Args:
            account_token (str): Auto-generated unique identifier representing a
                company account, prefixed with `acct-`.
            body (CreateOrUpdateBankAccount, optional): The request body parameter.

        Returns:
            BankAccountResult: Response from the API. Sample Bank Account Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/accounts/{account-token}/bank-accounts")
            .http_method(HttpMethodEnum.POST)
            .template_param(Parameter()
                .key("account-token")
                .value(account_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(BankAccountResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_company_bank_account(self,
                                      account_token,
                                      destination_token,
                                      page,
                                      page_size,
                                      filter=None,
                                      sort=None,
                                      language=None):
        """Perform a GET request to
        /accounts/{account-token}/bank-accounts/{destination-token}.

        Retrieve a single company [bank account](page:resources/bank-accounts) using
        a destination token.

        Args:
            account_token (str): Auto-generated unique identifier representing a
                company account, prefixed with `acct-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            BankAccountResult: Response from the API. Sample Bank Account Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/accounts/{account-token}/bank-accounts/{destination-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("account-token")
                .value(account_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(BankAccountResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def update_company_bank_account(self,
                                    account_token,
                                    destination_token,
                                    body=None):
        """Perform a PUT request to
        /accounts/{account-token}/bank-accounts/{destination-token}.

        Update a company [bank account](page:resources/bank-accounts).

        Args:
            account_token (str): Auto-generated unique identifier representing a
                company account, prefixed with `acct-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            body (CreateOrUpdateBankAccount, optional): The request body parameter.

        Returns:
            BankAccountResult: Response from the API. Sample Bank Account Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/accounts/{account-token}/bank-accounts/{destination-token}")
            .http_method(HttpMethodEnum.PUT)
            .template_param(Parameter()
                .key("account-token")
                .value(account_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(BankAccountResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def delete_company_bank_account(self,
                                    account_token,
                                    destination_token):
        """Perform a DELETE request to
        /accounts/{account-token}/bank-accounts/{destination-token}.

        Delete a company [bank account](page:resources/bank-accounts).

        Args:
            account_token (str): Auto-generated unique identifier representing a
                company account, prefixed with `acct-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.

        Returns:
            OperationResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/accounts/{account-token}/bank-accounts/{destination-token}")
            .http_method(HttpMethodEnum.DELETE)
            .template_param(Parameter()
                .key("account-token")
                .value(account_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(OperationResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_company_bank_account_creation_requirements(self,
                                                            account_token,
                                                            country=None,
                                                            currency=None):
        """Perform a GET request to
        /accounts/{account-token}/bank-accounts/requirements.

        Retrieve requirements for adding a [bank
        account](page:resources/bank-accounts) using the parameters provided.

        Args:
            account_token (str): Auto-generated unique identifier representing a
                company account, prefixed with `acct-`.
            country (Countries, optional): Filter results by country.
            currency (Currencies, optional): Filter results by currency.

        Returns:
            BankAccountRequirementListResult: Response from the API. Sample Bank
                Account Requirements List Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/accounts/{account-token}/bank-accounts/requirements")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("account-token")
                .value(account_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("country")
                .value(country))
            .query_param(Parameter()
                .key("currency")
                .value(currency))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(BankAccountRequirementListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_bank_account_creation_requirements_for_a_prepaid_card(self,
                                                                       user_token,
                                                                       destination_token,
                                                                       country=None,
                                                                       currency=None):
        """Perform a GET request to
        /users/{user-token}/prepaid-cards/{destination-token}/bank-accounts/requirement
        s.

        Retrieve requirements for adding a [bank
        account](page:resources/bank-accounts) using the pre-paid card as the
        destination.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            country (Countries, optional): Filter results by country.
            currency (Currencies, optional): Filter results by currency.

        Returns:
            BankAccountRequirementListResult: Response from the API. Sample Bank
                Account Requirements List Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards/{destination-token}/bank-accounts/requirements")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("country")
                .value(country))
            .query_param(Parameter()
                .key("currency")
                .value(currency))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(BankAccountRequirementListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()
