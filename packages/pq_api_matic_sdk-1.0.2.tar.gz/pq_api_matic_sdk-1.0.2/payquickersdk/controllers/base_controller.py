"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

from apimatic_core.api_call import ApiCall
from apimatic_core.types.error_case import ErrorCase

from payquickersdk.exceptions.api_exception import (
    APIException,
)


class BaseController(object):
    """All controllers inherit from this base class.

    Attributes:
        config (Configuration): The HttpClient which a specific controller
            instance will use. By default all the controller objects share
            the same HttpClient. A user can use his own custom HttpClient
            as well.
        http_call_back (HttpCallBack): An object which holds call back
            methods to be called before and after the execution of an HttpRequest.
        new_api_call_builder (APICall): Returns the API Call builder instance.

    """

    @staticmethod
    def user_agent():
        """Return UserAgent value."""
        return "PayQuicker SDK 2026.02.01"

    @staticmethod
    def user_agent_parameters():
        """Return UserAgentParameters value."""
        return {
        }

    @staticmethod
    def global_errors():
        """Return GlobalErrors value."""
        return {
            "default": ErrorCase()
                .error_message("HTTP response not OK.")
                .exception_type(APIException),
        }

    def __init__(self, config):
        """Initialize BaseController object."""
        self._config = config.get_http_client_configuration()
        self._http_call_back = self.config.http_callback
        self.api_call = ApiCall(config)

    @property
    def config(self):
        """Return Configuration object."""
        return self._config

    @property
    def http_call_back(self):
        """Return HttpCallBack object."""
        return self._http_call_back

    @property
    def new_api_call_builder(self):
        """Return New ApiCallBuilder object."""
        return self.api_call.new_builder
