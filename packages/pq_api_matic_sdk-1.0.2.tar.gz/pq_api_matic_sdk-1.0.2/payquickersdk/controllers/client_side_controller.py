"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.authentication.multiple.single_auth import (
    Single,
)
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.api_error_result_exception import (
    ApiErrorResultException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.operation_result import (
    OperationResult,
)
from payquickersdk.models.prepaid_card_data_result import (
    PrepaidCardDataResult,
)
from payquickersdk.models.prepaid_card_data_token_result import (
    PrepaidCardDataTokenResult,
)
from payquickersdk.models.prepaid_card_pin_result import (
    PrepaidCardPinResult,
)
from payquickersdk.models.prepaid_card_pin_token_result import (
    PrepaidCardPinTokenResult,
)


class ClientSideController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize ClientSideController object."""
        super(ClientSideController, self).__init__(config)

    def create_card_data_token(self,
                               user_token,
                               destination_token,
                               format,
                               side=None):
        """Perform a GET request to
        /users/{user-token}/prepaid-cards/{destination-token}/pci.

        Generate a token used to reveal [prepaid card](page:resources/prepaid-cards)
        information in the form of image data (base64) or JSON.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            format (PrepaidCardDataType): Desired format for the prepaid card data.
            side (PrepaidCardImageSide, optional): Side to specify when retrieving a
                prepaid card's image data. *Required if IMAGE format specified.

        Returns:
            PrepaidCardDataTokenResult: Response from the API. Sample Generate
                Prepaid Card Data Token Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards/{destination-token}/pci")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("format")
                .value(format)
                .is_required(True))
            .query_param(Parameter()
                .key("side")
                .value(side))
            .header_param(Parameter()
                .key("accept")
                .value("application/json")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(PrepaidCardDataTokenResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_card_data(self,
                           user_token,
                           destination_token,
                           format,
                           side=None,
                           body=None):
        """Perform a POST request to
        /users/{user-token}/prepaid-cards/{destination-token}/pci.

        Return [prepaid card](page:resources/prepaid-cards) data in the form of image
        data, text, or both.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            format (PrepaidCardDataType): Desired format for the prepaid card data.
            side (PrepaidCardImageSide, optional): Side to specify when retrieving a
                prepaid card's image data. *Required if IMAGE format specified.
            body (RetrieveCardData, optional): The request body parameter.

        Returns:
            PrepaidCardDataResult: Response from the API. Sample Prepaid Card Data
                Token Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards/{destination-token}/pci")
            .http_method(HttpMethodEnum.POST)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("format")
                .value(format)
                .is_required(True))
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .query_param(Parameter()
                .key("side")
                .value(side))
            .body_param(Parameter()
                .value(body))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("clientside")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(PrepaidCardDataResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def create_card_pin_token(self,
                              user_token,
                              destination_token):
        """Perform a GET request to
        /users/{user-token}/prepaid-cards/{destination-token}/pin.

        Retrieve one part of a two-part token required to reveal or set a client side
        [prepaid card](page:resources/prepaid-cards) PIN.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.

        Returns:
            PrepaidCardPinTokenResult: Response from the API. Sample Generate Pin
                Operation Token Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards/{destination-token}/pin")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(PrepaidCardPinTokenResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def update_card_pin(self,
                        user_token,
                        destination_token,
                        body=None):
        """Perform a PUT request to
        /users/{user-token}/prepaid-cards/{destination-token}/pin.

        Set a [PIN](#/rest/models/structures/prepaid-card-pin) for a [prepaid
        card](page:resources/prepaid-cards), if supported by program.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            body (UpdateCardPin, optional): The request body parameter.

        Returns:
            OperationResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards/{destination-token}/pin")
            .http_method(HttpMethodEnum.PUT)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("clientside")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(OperationResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_card_pin(self,
                          user_token,
                          destination_token,
                          body=None):
        """Perform a POST request to
        /users/{user-token}/prepaid-cards/{destination-token}/pin.

        Reveal a [PIN](#/rest/models/structures/prepaid-card-pin) for a [prepaid
        card](page:resources/prepaid-cards).

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            body (RetrieveCardPin, optional): The request body parameter.

        Returns:
            PrepaidCardPinResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards/{destination-token}/pin")
            .http_method(HttpMethodEnum.POST)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("clientside")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(PrepaidCardPinResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()
