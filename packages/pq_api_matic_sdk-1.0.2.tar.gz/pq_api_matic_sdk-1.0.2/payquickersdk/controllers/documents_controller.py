"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.authentication.multiple.single_auth import (
    Single,
)
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.api_error_result_exception import (
    ApiErrorResultException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.document_list_result import (
    DocumentListResult,
)
from payquickersdk.models.document_requirements_list_result import (
    DocumentRequirementsListResult,
)
from payquickersdk.models.document_result import (
    DocumentResult,
)


class DocumentsController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize DocumentsController object."""
        super(DocumentsController, self).__init__(config)

    def list_documents(self,
                       user_token,
                       page,
                       page_size,
                       filter=None,
                       sort=None,
                       language=None):
        """Perform a GET request to /users/{user-token}/documents.

        Retrieve a list of user [documents](page:resources/documents) that supports
        filtering, sorting, and pagination through existing mechanisms.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            DocumentListResult: Response from the API. Sample Document List Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/documents")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(DocumentListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def upload_document(self,
                        user_token,
                        fields=None,
                        upload=None):
        """Perform a POST request to /users/{user-token}/documents.

        Upload a user [document](page:resources/documents).

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            fields (CreateOrUpdateDocumentFields, optional): The request form
                parameter.
            upload (typing.BinaryIO, optional): Document to be uploaded

        Returns:
            DocumentResult: Response from the API. Sample Document Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/documents")
            .http_method(HttpMethodEnum.POST)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .multipart_param(Parameter()
                .key("fields")
                .value(APIHelper.json_serialize(fields))
                .default_content_type("application/json"))
            .multipart_param(Parameter()
                .key("upload")
                .value(upload)
                .default_content_type("image/png"))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(DocumentResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_document(self,
                          user_token,
                          document_token):
        """Perform a GET request to
        /users/{user-token}/documents/{document-token}.

        Retrieve a single user [document](page:resources/documents) by its document
        token.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            document_token (str): Auto-generated unique identifier representing an
                uploaded document, prefixed with `docu-`.

        Returns:
            DocumentResult: Response from the API. Sample Document Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/documents/{document-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("document-token")
                .value(document_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(DocumentResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def replace_document(self,
                         user_token,
                         document_token,
                         fields=None,
                         upload=None):
        """Perform a PUT request to
        /users/{user-token}/documents/{document-token}.

        Replace the user [documents](page:resources/documents) at the given document
        token.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            document_token (str): Auto-generated unique identifier representing an
                uploaded document, prefixed with `docu-`.
            fields (CreateOrUpdateDocumentFields, optional): The request form
                parameter.
            upload (typing.BinaryIO, optional): Document to be uploaded

        Returns:
            DocumentResult: Response from the API. Sample Document Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/documents/{document-token}")
            .http_method(HttpMethodEnum.PUT)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("document-token")
                .value(document_token)
                .is_required(True)
                .should_encode(True))
            .multipart_param(Parameter()
                .key("fields")
                .value(APIHelper.json_serialize(fields))
                .default_content_type("application/json"))
            .multipart_param(Parameter()
                .key("upload")
                .value(upload)
                .default_content_type("image/png"))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(DocumentResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def list_user_document_requirements(self,
                                        user_token,
                                        page,
                                        page_size,
                                        filter=None,
                                        sort=None,
                                        language=None):
        """Perform a GET request to /users/{user-token}/documents/requirements.

        Returns a list of user documents that the user can provide

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            DocumentRequirementsListResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/documents/requirements")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(DocumentRequirementsListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()
