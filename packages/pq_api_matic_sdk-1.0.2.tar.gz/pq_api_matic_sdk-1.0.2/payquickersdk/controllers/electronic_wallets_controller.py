"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.authentication.multiple.single_auth import (
    Single,
)
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.api_error_result_exception import (
    ApiErrorResultException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.electronic_wallet_list_result import (
    ElectronicWalletListResult,
)
from payquickersdk.models.electronic_wallet_requirement_list_result import (
    ElectronicWalletRequirementListResult,
)
from payquickersdk.models.electronic_wallet_result import (
    ElectronicWalletResult,
)
from payquickersdk.models.operation_result import (
    OperationResult,
)


class ElectronicWalletsController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize ElectronicWalletsController object."""
        super(ElectronicWalletsController, self).__init__(config)

    def list_electronic_wallets(self,
                                user_token,
                                page,
                                page_size,
                                filter=None,
                                sort=None,
                                language=None):
        """Perform a GET request to /users/{user-token}/electronic-wallets.

        Retrieve a list of [electronic wallets](page:resources/electronic-wallets)
        that supports filtering, sorting, and pagination through existing mechanisms.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            ElectronicWalletListResult: Response from the API. Sample Electronic
                Wallet List Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/electronic-wallets")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(ElectronicWalletListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def create_electronic_wallet(self,
                                 user_token,
                                 body=None):
        """Perform a POST request to /users/{user-token}/electronic-wallets.

        Create a new [electronic wallet](page:resources/electronic-wallets) using a
        user token.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            body (CreateOrUpdateElectronicWallet, optional): The request body
                parameter.

        Returns:
            ElectronicWalletResult: Response from the API. Sample Electronic Wallet
                Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/electronic-wallets")
            .http_method(HttpMethodEnum.POST)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(ElectronicWalletResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_creation_requirements(self,
                                       user_token,
                                       electronic_wallet_type=None,
                                       country=None,
                                       currency=None):
        """Perform a GET request to
        /users/{user-token}/electronic-wallets/requirements.

        Retrieve requirements for adding a [electronic
        wallet](page:resources/electronic-wallets) using the parameters provided.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            electronic_wallet_type (ElectronicWalletTypes, optional): Filter results
                by electronic wallet type.
            country (Countries, optional): Filter results by country.
            currency (Currencies, optional): Filter results by currency.

        Returns:
            ElectronicWalletRequirementListResult: Response from the API. Sample
                Electronic Wallet Requirements List Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/electronic-wallets/requirements")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("electronicWalletType")
                .value(electronic_wallet_type))
            .query_param(Parameter()
                .key("country")
                .value(country))
            .query_param(Parameter()
                .key("currency")
                .value(currency))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(ElectronicWalletRequirementListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_electronic_wallet(self,
                                   user_token,
                                   destination_token,
                                   page,
                                   page_size,
                                   filter=None,
                                   sort=None,
                                   language=None):
        """Perform a GET request to
        /users/{user-token}/electronic-wallets/{destination-token}.

        Retrieve a single [electronic wallet](page:resources/electronic-wallets)
        using a destination token.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            ElectronicWalletResult: Response from the API. Sample Electronic Wallet
                Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/electronic-wallets/{destination-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(ElectronicWalletResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def update_electronic_wallet(self,
                                 user_token,
                                 destination_token,
                                 body=None):
        """Perform a PUT request to
        /users/{user-token}/electronic-wallets/{destination-token}.

        Update a [electronic wallet](page:resources/electronic-wallets).

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            body (CreateOrUpdateElectronicWallet, optional): The request body
                parameter.

        Returns:
            ElectronicWalletResult: Response from the API. Sample Electronic Wallet
                Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/electronic-wallets/{destination-token}")
            .http_method(HttpMethodEnum.PUT)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(ElectronicWalletResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def delete_electronic_wallet(self,
                                 user_token,
                                 destination_token):
        """Perform a DELETE request to
        /users/{user-token}/electronic-wallets/{destination-token}.

        Delete a user [electronic wallet](page:resources/electronic-wallets).

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.

        Returns:
            OperationResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/electronic-wallets/{destination-token}")
            .http_method(HttpMethodEnum.DELETE)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(OperationResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()
