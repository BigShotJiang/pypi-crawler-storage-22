"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.authentication.multiple.single_auth import (
    Single,
)
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.api_error_result_exception import (
    ApiErrorResultException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.event_list_result import (
    EventListResult,
)
from payquickersdk.models.user_event_result import (
    UserEventResult,
)


class EventsController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize EventsController object."""
        super(EventsController, self).__init__(config)

    def list_events(self,
                    user_token):
        """Perform a GET request to /users/{user-token}/events.

        Retrieve a list of [user events](page:resources/user#list-user-events) that
        supports filtering, sorting, and pagination through existing mechanisms.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.

        Returns:
            EventListResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/events")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(EventListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_event(self,
                       user_token,
                       event_token):
        """Perform a GET request to /users/{user-token}/events/{event-token}.

        Retrieve a single [user event](page:resources/user#get-user-event).

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            event_token (str): Auto-generated unique identifier representing an
                event, prefixed with `evnt-`.

        Returns:
            UserEventResult: Response from the API. OK

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/events/{event-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("event-token")
                .value(event_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(UserEventResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()
