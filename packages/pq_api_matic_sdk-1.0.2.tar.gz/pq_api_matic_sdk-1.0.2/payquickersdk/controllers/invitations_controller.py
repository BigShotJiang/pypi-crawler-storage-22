"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.authentication.multiple.single_auth import (
    Single,
)
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.api_error_result_exception import (
    ApiErrorResultException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.invitation_list_result import (
    InvitationListResult,
)
from payquickersdk.models.invitation_result import (
    InvitationResult,
)


class InvitationsController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize InvitationsController object."""
        super(InvitationsController, self).__init__(config)

    def list_invitations(self,
                         page,
                         page_size,
                         filter=None,
                         sort=None,
                         language=None):
        """Perform a GET request to /invitations.

        Retrieve a list of [invitations](page:resources/invitations) that supports
        filtering, sorting, and pagination through existing mechanisms.

        Args:
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            InvitationListResult: Response from the API. Sample invitation list
                response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/invitations")
            .http_method(HttpMethodEnum.GET)
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(InvitationListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def create_invitation(self,
                          body=None):
        """Perform a POST request to /invitations.

        Create a [invitation](page:resources/invitations) quote.

        Args:
            body (CreateInvitation, optional): The request body parameter.

        Returns:
            InvitationResult: Response from the API. Sample invitation response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/invitations")
            .http_method(HttpMethodEnum.POST)
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(InvitationResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_invitation(self,
                            invitation_token,
                            filter=None,
                            language=None):
        """Perform a GET request to /invitations/{invitation-token}.

        Retrieve a single [invitation](page:resources/invitations).

        Args:
            invitation_token (str): Auto-generated unique identifier representing an
                invite, prefixed with `invt-`.
            filter (str, optional): Filter request results by specific criteria.
            language (Languages, optional): Filter results by language type.

        Returns:
            InvitationResult: Response from the API. Sample invitation response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/invitations/{invitation-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("invitation-token")
                .value(invitation_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(InvitationResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def update_invitation(self,
                          invitation_token):
        """Perform a PUT request to /invitations/{invitation-token}.

        Accept an open [invitation](page:resources/invitations) quote.

        Args:
            invitation_token (str): Auto-generated unique identifier representing an
                invite, prefixed with `invt-`.

        Returns:
            InvitationResult: Response from the API. Sample invitation response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/invitations/{invitation-token}")
            .http_method(HttpMethodEnum.PUT)
            .template_param(Parameter()
                .key("invitation-token")
                .value(invitation_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(InvitationResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def cancel_invitation(self,
                          invitation_token):
        """Perform a DELETE request to /invitations/{invitation-token}.

        Cancel an open [invitation](page:resources/invitations) quote.

        Args:
            invitation_token (str): Auto-generated unique identifier representing an
                invite, prefixed with `invt-`.

        Returns:
            InvitationResult: Response from the API. Sample invitation response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/invitations/{invitation-token}")
            .http_method(HttpMethodEnum.DELETE)
            .template_param(Parameter()
                .key("invitation-token")
                .value(invitation_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(InvitationResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()
