"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.authentication.multiple.single_auth import (
    Single,
)
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.api_error_result_exception import (
    ApiErrorResultException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.payment_job_list_result import (
    PaymentJobListResult,
)
from payquickersdk.models.payment_job_result import (
    PaymentJobResult,
)
from payquickersdk.utilities.union_type_lookup import (
    UnionTypeLookUp,
)


class JobsController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize JobsController object."""
        super(JobsController, self).__init__(config)

    def list_payment_jobs(self,
                          page,
                          page_size,
                          filter=None,
                          sort=None,
                          language=None):
        """Perform a GET request to /payments/jobs.

        Retrieve a list of [jobs](page:resources/jobs) that supports filtering,
        sorting, and pagination through existing mechanisms.

        Args:
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            PaymentJobListResult: Response from the API. Sample payment job list
                response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/payments/jobs")
            .http_method(HttpMethodEnum.GET)
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(PaymentJobListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def create_payment_job(self,
                           body=None):
        """Perform a POST request to /payments/jobs.

        Create a [payment](page:resources/jobs).

        Args:
            body (GatewayPaymentJob | PortalPaymentJob | None, optional): The request
                body parameter.

        Returns:
            PaymentJobResult: Response from the API. Sample payment job response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/payments/jobs")
            .http_method(HttpMethodEnum.POST)
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body)
                .validator(lambda value: UnionTypeLookUp
                    .get("_PaymentJob").validate(value)))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(PaymentJobResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_payment_job(self,
                             job_token,
                             filter=None,
                             language=None):
        """Perform a GET request to /payments/jobs/{job-token}.

        Retrieve a single payment [job](page:resources/jobs).

        Args:
            job_token (str): Auto-generated unique identifier representing a job,
                prefixed with `jobs-`.
            filter (str, optional): Filter request results by specific criteria.
            language (Languages, optional): Filter results by language type.

        Returns:
            PaymentJobResult: Response from the API. Sample payment job response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/payments/jobs/{job-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("job-token")
                .value(job_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(PaymentJobResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def cancel_payment_job(self,
                           job_token):
        """Perform a DELETE request to /payments/jobs/{job-token}.

        Cancel an submitted payment [job](page:resources/jobs).

        Args:
            job_token (str): Auto-generated unique identifier representing a job,
                prefixed with `jobs-`.

        Returns:
            PaymentJobResult: Response from the API. Sample payment job response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/payments/jobs/{job-token}")
            .http_method(HttpMethodEnum.DELETE)
            .template_param(Parameter()
                .key("job-token")
                .value(job_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(PaymentJobResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()
