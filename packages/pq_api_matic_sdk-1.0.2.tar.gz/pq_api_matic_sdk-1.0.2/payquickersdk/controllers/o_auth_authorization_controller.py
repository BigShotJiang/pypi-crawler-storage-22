"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.o_auth_provider_exception import (
    OAuthProviderException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.o_auth_token import (
    OAuthToken,
)


class OAuthAuthorizationController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize OAuthAuthorizationController object."""
        super(OAuthAuthorizationController, self).__init__(config)

    def request_token_server(self,
                             authorization,
                             scope=None,
                             _optional_form_parameters=None):
        """Perform a POST request to /auth/connect/token.

        Create a new OAuth 2 token.

        Args:
            authorization (str): Authorization header in Basic auth format
            scope (str, optional): Requested scopes as a space-delimited list.
            _optional_form_parameters (Array, optional): Additional optional form
                parameters are supported by this endpoint

        Returns:
            OAuthToken: Response from the API.

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/auth/connect/token")
            .http_method(HttpMethodEnum.POST)
            .form_param(Parameter()
                .key("grant_type")
                .value("client_credentials"))
            .header_param(Parameter()
                .key("Authorization")
                .value(authorization)
                .is_required(True))
            .form_param(Parameter()
                .key("scope")
                .value(scope))
            .header_param(Parameter()
                            .key("content-type")
                            .value("application/x-www-form-urlencoded"))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .additional_form_params(_optional_form_parameters),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(OAuthToken.from_dictionary)
            .local_error("400",
                "OAuth 2 provider returned an error.",
                OAuthProviderException)
            .local_error("401",
                "OAuth 2 provider says client authentication failed.",
                OAuthProviderException),
        ).execute()
