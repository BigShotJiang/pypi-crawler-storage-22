"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.authentication.multiple.single_auth import (
    Single,
)
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.api_error_result_exception import (
    ApiErrorResultException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.authorization_list_result import (
    AuthorizationListResult,
)
from payquickersdk.models.prepaid_card_list_result import (
    PrepaidCardListResult,
)
from payquickersdk.models.prepaid_card_result import (
    PrepaidCardResult,
)


class PrepaidCardsController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize PrepaidCardsController object."""
        super(PrepaidCardsController, self).__init__(config)

    def list_prepaid_cards(self,
                           user_token,
                           page,
                           page_size,
                           filter=None,
                           sort=None,
                           language=None):
        """Perform a GET request to /users/{user-token}/prepaid-cards.

        Retrieve a list of [prepaid cards](page:resources/prepaid-cards) by user
        token that supports filtering, sorting, and pagination through existing
        mechanisms.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            PrepaidCardListResult: Response from the API. Sample Prepaid Card List
                Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(PrepaidCardListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def order_prepaid_card(self,
                           user_token,
                           body=None):
        """Perform a POST request to /users/{user-token}/prepaid-cards.

        Order a [prepaid card](page:resources/prepaid-cards) for the user by
        specifying a cardPackage.
        Assign a prepaid card to a user when a program token and card reference
        number are supplied.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            body (OrderPrepaidCard, optional): The request body parameter.

        Returns:
            PrepaidCardResult: Response from the API. Sample Prepaid Card Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards")
            .http_method(HttpMethodEnum.POST)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(PrepaidCardResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def replace_prepaid_card(self,
                             user_token,
                             destination_token,
                             body=None):
        """Perform a POST request to
        /users/{user-token}/prepaid-cards/{destination-token}.

        Replace a [prepaid card](page:resources/prepaid-cards) by destination token.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            body (ReplacePrepaidCard, optional): The request body parameter.

        Returns:
            PrepaidCardResult: Response from the API. Sample Prepaid Card Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards/{destination-token}")
            .http_method(HttpMethodEnum.POST)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(PrepaidCardResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_prepaid_card(self,
                              user_token,
                              destination_token):
        """Perform a GET request to
        /users/{user-token}/prepaid-cards/{destination-token}.

        Retrieve [prepaid card](page:resources/prepaid-cards) details by destination
        token.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.

        Returns:
            PrepaidCardResult: Response from the API. Sample Prepaid Card Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards/{destination-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(PrepaidCardResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def update_prepaid_card(self,
                            user_token,
                            destination_token,
                            body=None):
        """Perform a PATCH request to
        /users/{user-token}/prepaid-cards/{destination-token}.

        Partial [prepaid card](page:resources/prepaid-cards) update.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            body (UpdatePrepaidCard, optional): The request body parameter.

        Returns:
            PrepaidCardResult: Response from the API. Sample Prepaid Card Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards/{destination-token}")
            .http_method(HttpMethodEnum.PATCH)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(PrepaidCardResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def list_card_authorizations(self,
                                 user_token,
                                 destination_token):
        """Perform a GET request to
        /users/{user-token}/prepaid-cards/{destination-token}/authorizations.

        TODO

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.

        Returns:
            AuthorizationListResult: Response from the API. Sample Prepaid Card
                Authorizations List Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards/{destination-token}/authorizations")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(AuthorizationListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()
