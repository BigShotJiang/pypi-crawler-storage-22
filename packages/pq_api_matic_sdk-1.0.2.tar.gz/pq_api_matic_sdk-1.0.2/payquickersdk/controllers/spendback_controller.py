"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.authentication.multiple.single_auth import (
    Single,
)
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.api_error_result_exception import (
    ApiErrorResultException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.spendback_list_result import (
    SpendbackListResult,
)
from payquickersdk.models.spendback_result import (
    SpendbackResult,
)
from payquickersdk.utilities.union_type_lookup import (
    UnionTypeLookUp,
)


class SpendbackController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize SpendbackController object."""
        super(SpendbackController, self).__init__(config)

    def list_spendbacks(self,
                        page,
                        page_size,
                        filter=None,
                        sort=None,
                        language=None):
        """Perform a GET request to /spend-back.

        Retrieve a list of [spendbacks](page:resources/spendbacks) that supports
        filtering, sorting, and pagination through existing mechanisms.

        Args:
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            SpendbackListResult: Response from the API. Sample SpendBack List Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/spend-back")
            .http_method(HttpMethodEnum.GET)
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(SpendbackListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def create_spendback_quote(self,
                               body=None):
        """Perform a POST request to /spend-back.

        Create a [spendback](page:resources/spendbacks) quote.

        Args:
            body (GatewaySpendbackQuote | PortalSpendbackQuote | None, optional): The
                request body parameter.

        Returns:
            SpendbackResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/spend-back")
            .http_method(HttpMethodEnum.POST)
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body)
                .validator(lambda value: UnionTypeLookUp
                    .get("_SpendbackQuote").validate(value)))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(SpendbackResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_spendback(self,
                           spendback_token,
                           page,
                           page_size,
                           filter=None,
                           sort=None,
                           language=None):
        """Perform a GET request to /spend-back/{spendback-token}.

        Retrieve a single [spendbacks](page:resources/spendbacks) quote using the
        spendback token.

        Args:
            spendback_token (str): Auto-generated unique identifier representing an
                individual spend back transaction and quote, prefixed with `spnd-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            SpendbackResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/spend-back/{spendback-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("spendback-token")
                .value(spendback_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(SpendbackResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def accept_spendback_quote(self,
                               spendback_token):
        """Perform a POST request to /spend-back/{spendback-token}.

        Accept an open [spendback](page:resources/spendbacks) quote.

        Args:
            spendback_token (str): Auto-generated unique identifier representing an
                individual spend back transaction and quote, prefixed with `spnd-`.

        Returns:
            SpendbackResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/spend-back/{spendback-token}")
            .http_method(HttpMethodEnum.POST)
            .template_param(Parameter()
                .key("spendback-token")
                .value(spendback_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(SpendbackResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def cancel_spendback_quote(self,
                               spendback_token):
        """Perform a DELETE request to /spend-back/{spendback-token}.

        Cancel an open [spendback](page:resources/spendbacks) quote.

        Args:
            spendback_token (str): Auto-generated unique identifier representing an
                individual spend back transaction and quote, prefixed with `spnd-`.

        Returns:
            SpendbackResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/spend-back/{spendback-token}")
            .http_method(HttpMethodEnum.DELETE)
            .template_param(Parameter()
                .key("spendback-token")
                .value(spendback_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(SpendbackResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()
