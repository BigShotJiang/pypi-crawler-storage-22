"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.authentication.multiple.single_auth import (
    Single,
)
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.api_error_result_exception import (
    ApiErrorResultException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.spendback_refund_list_result import (
    SpendbackRefundListResult,
)
from payquickersdk.models.spendback_refund_result import (
    SpendbackRefundResult,
)


class SpendbackRefundsController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize SpendbackRefundsController object."""
        super(SpendbackRefundsController, self).__init__(config)

    def list_spendback_refunds(self,
                               spendback_token,
                               page,
                               page_size,
                               filter=None,
                               sort=None,
                               language=None):
        """Perform a GET request to /spend-back/{spendback-token}/refund.

        Retrieve a list of [spendbacks](page:resources/spendbacks) refunds that
        supports filtering, sorting, and pagination through existing mechanisms.

        Args:
            spendback_token (str): Auto-generated unique identifier representing an
                individual spend back transaction and quote, prefixed with `spnd-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            SpendbackRefundListResult: Response from the API. Sample SpendBack Refund
                List Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/spend-back/{spendback-token}/refund")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("spendback-token")
                .value(spendback_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(SpendbackRefundListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def create_spendback_refund_quote(self,
                                      spendback_token,
                                      body=None):
        """Perform a POST request to /spend-back/{spendback-token}/refund.

        Perform a [spendback](page:resources/spendbacks) refund for a partial amount.

        Args:
            spendback_token (str): Auto-generated unique identifier representing an
                individual spend back transaction and quote, prefixed with `spnd-`.
            body (CreateSpendbackRefundQuote, optional): The request body parameter.

        Returns:
            SpendbackRefundResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/spend-back/{spendback-token}/refund")
            .http_method(HttpMethodEnum.POST)
            .template_param(Parameter()
                .key("spendback-token")
                .value(spendback_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(SpendbackRefundResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def cancel_spendback_refund_quote(self,
                                      spendback_token,
                                      refund_token):
        """Perform a DELETE request to
        /spend-back/{spendback-token}/refund/{refund-token}.

        Cancel an spendback refund quote.

        Args:
            spendback_token (str): Auto-generated unique identifier representing an
                individual spend back transaction and quote, prefixed with `spnd-`.
            refund_token (str): Auto-generated unique identifier representing an
                individual spend back refund transaction and quote, prefixed with
                `rfnd-`.

        Returns:
            SpendbackRefundResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/spend-back/{spendback-token}/refund/{refund-token}")
            .http_method(HttpMethodEnum.DELETE)
            .template_param(Parameter()
                .key("spendback-token")
                .value(spendback_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("refund-token")
                .value(refund_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(SpendbackRefundResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_spendback_refund(self,
                                  spendback_token,
                                  refund_token,
                                  page,
                                  page_size,
                                  filter=None,
                                  sort=None,
                                  language=None):
        """Perform a GET request to
        /spend-back/{spendback-token}/refund/{refund-token}.

        Retrieve a single spendback refund using the rfnd token

        Args:
            spendback_token (str): Auto-generated unique identifier representing an
                individual spend back transaction and quote, prefixed with `spnd-`.
            refund_token (str): Auto-generated unique identifier representing an
                individual spend back refund transaction and quote, prefixed with
                `rfnd-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            SpendbackRefundResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/spend-back/{spendback-token}/refund/{refund-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("spendback-token")
                .value(spendback_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("refund-token")
                .value(refund_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(SpendbackRefundResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def accept_spendback_refund_quote(self,
                                      spendback_token,
                                      refund_token):
        """Perform a POST request to
        /spend-back/{spendback-token}/refund/{refund-token}.

        Accept a spendback return quote.

        Args:
            spendback_token (str): Auto-generated unique identifier representing an
                individual spend back transaction and quote, prefixed with `spnd-`.
            refund_token (str): Auto-generated unique identifier representing an
                individual spend back refund transaction and quote, prefixed with
                `rfnd-`.

        Returns:
            SpendbackRefundResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/spend-back/{spendback-token}/refund/{refund-token}")
            .http_method(HttpMethodEnum.POST)
            .template_param(Parameter()
                .key("spendback-token")
                .value(spendback_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("refund-token")
                .value(refund_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(SpendbackRefundResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()
