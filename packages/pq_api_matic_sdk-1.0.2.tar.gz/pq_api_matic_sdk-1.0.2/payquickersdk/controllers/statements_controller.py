"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.authentication.multiple.single_auth import (
    Single,
)
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.api_error_result_exception import (
    ApiErrorResultException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.statement_list_result import (
    StatementListResult,
)
from payquickersdk.models.statement_result import (
    StatementResult,
)


class StatementsController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize StatementsController object."""
        super(StatementsController, self).__init__(config)

    def list_prepaid_card_statements(self,
                                     user_token,
                                     destination_token,
                                     page,
                                     page_size,
                                     filter=None,
                                     sort=None,
                                     language=None):
        """Perform a GET request to
        /users/{user-token}/prepaid-cards/{destination-token}/statements.

        List Prepaid Card Statements for specific user

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            StatementListResult: Response from the API. Sample Prepaid Card Statement
                List Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards/{destination-token}/statements")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(StatementListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_prepaid_card_statement(self,
                                        user_token,
                                        destination_token,
                                        document_token):
        """Perform a GET request to
        /users/{user-token}/prepaid-cards/{destination-token}/statements/{document-toke
        n}.

        Retrieve a single prepaid card agreement.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            destination_token (str): Auto-generated unique identifier representing a
                transfer destination, including prepaid cards, bank accounts, paper
                checks, and other users, prefixed with `dest-`.
            document_token (str): Auto-generated unique identifier representing an
                uploaded document, prefixed with `docu-`.

        Returns:
            StatementResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/prepaid-cards/{destination-token}/statements/{document-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("destination-token")
                .value(destination_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("document-token")
                .value(document_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(StatementResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def list_statements(self,
                        user_token,
                        page,
                        page_size,
                        filter=None,
                        sort=None,
                        language=None):
        """Perform a GET request to /users/{user-token}/statements.

        Returns all statements for the specified user

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            StatementListResult: Response from the API. Sample Prepaid Card Statement
                List Response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/statements")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(StatementListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_statement(self,
                           user_token,
                           document_token):
        """Perform a GET request to
        /users/{user-token}/statements/{document-token}.

        Return a specific statement

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            document_token (str): Auto-generated unique identifier representing an
                uploaded document, prefixed with `docu-`.

        Returns:
            StatementResult: Response from the API. Example response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/statements/{document-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("document-token")
                .value(document_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(StatementResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()
