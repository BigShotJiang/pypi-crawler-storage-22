"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: D410, E501, E101, D206
from apimatic_core.authentication.multiple.single_auth import (
    Single,
)
from apimatic_core.request_builder import RequestBuilder
from apimatic_core.response_handler import ResponseHandler
from apimatic_core.types.parameter import Parameter

from payquickersdk.api_helper import APIHelper
from payquickersdk.configuration import Server
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.exceptions.api_error_result_exception import (
    ApiErrorResultException,
)
from payquickersdk.http.http_method_enum import (
    HttpMethodEnum,
)
from payquickersdk.models.transfer_list_result import (
    TransferListResult,
)
from payquickersdk.models.transfer_result import (
    TransferResult,
)
from payquickersdk.utilities.union_type_lookup import (
    UnionTypeLookUp,
)


class TransfersController(BaseController):
    """A Controller to access Endpoints in the payquickersdk API."""

    def __init__(self, config):
        """Initialize TransfersController object."""
        super(TransfersController, self).__init__(config)

    def list_transfers(self,
                       page,
                       page_size,
                       filter=None,
                       sort=None,
                       language=None):
        """Perform a GET request to /transfers.

        Retrieve a list of [transfers](page:resources/transfers) that supports
        filtering, sorting, and pagination through existing mechanisms.

        Args:
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            TransferListResult: Response from the API. Sample transfer list response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/transfers")
            .http_method(HttpMethodEnum.GET)
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(TransferListResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def create_transfer_quote(self,
                              body=None):
        """Perform a POST request to /transfers.

        Create a new [transfer](page:resources/transfers) quote.

        Args:
            body (GatewayTransferQuote | PortalTransferQuote | None, optional): The
                request body parameter.

        Returns:
            TransferResult: Response from the API. Sample transfer response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/transfers")
            .http_method(HttpMethodEnum.POST)
            .header_param(Parameter()
                .key("Content-Type")
                .value("application/json"))
            .body_param(Parameter()
                .value(body)
                .validator(lambda value: UnionTypeLookUp
                    .get("_TransferQuote").validate(value)))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .body_serializer(APIHelper.json_serialize)
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(TransferResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def retrieve_transfer(self,
                          transfer_token):
        """Perform a GET request to /transfers/{transfer-token}.

        Retrieve details of a specific [transfer](page:resources/transfers)
        represented by a transfer token.

        Args:
            transfer_token (str): Auto-generated unique identifier representing an
                individual transfer transaction, prefixed with `xfer-`.

        Returns:
            TransferResult: Response from the API. Sample transfer response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/transfers/{transfer-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("transfer-token")
                .value(transfer_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(TransferResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def accept_transfer_quote(self,
                              transfer_token):
        """Perform a POST request to /transfers/{transfer-token}.

        Accept a [transfer](page:resources/transfers) quote.

        Args:
            transfer_token (str): Auto-generated unique identifier representing an
                individual transfer transaction, prefixed with `xfer-`.

        Returns:
            TransferResult: Response from the API. Sample transfer response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/transfers/{transfer-token}")
            .http_method(HttpMethodEnum.POST)
            .template_param(Parameter()
                .key("transfer-token")
                .value(transfer_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(TransferResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def cancel_transfer_quote(self,
                              transfer_token):
        """Perform a DELETE request to /transfers/{transfer-token}.

        Optional [transfer](page:resources/transfers) quote cancellation that
        auto-cancels after a period organically expires or when account activity
        invalidates the quote.

        Args:
            transfer_token (str): Auto-generated unique identifier representing an
                individual transfer transaction, prefixed with `xfer-`.

        Returns:
            TransferResult: Response from the API. Sample transfer response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/transfers/{transfer-token}")
            .http_method(HttpMethodEnum.DELETE)
            .template_param(Parameter()
                .key("transfer-token")
                .value(transfer_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(TransferResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()

    def list_user_transfers(self,
                            user_token,
                            page,
                            page_size,
                            filter=None,
                            sort=None,
                            language=None):
        """Perform a GET request to /users/{user-token}/transfers.

        Retrieve a list of user [transfers](page:resources/transfers) that supports
        filtering, sorting, and pagination through existing mechanisms.

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            page (int): Page number of specific page to return
            page_size (int): Number of items to be displayed per page
            filter (str, optional): Filter request results by specific criteria.
            sort (str, optional): Sort request results by specific attribute.
            language (Languages, optional): Filter results by language type.

        Returns:
            TransferListResult: Response from the API. Sample transfer list response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/transfers")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .query_param(Parameter()
                .key("page")
                .value(page)
                .is_required(True))
            .query_param(Parameter()
                .key("pageSize")
                .value(page_size)
                .is_required(True))
            .query_param(Parameter()
                .key("filter")
                .value(filter))
            .query_param(Parameter()
                .key("sort")
                .value(sort))
            .query_param(Parameter()
                .key("language")
                .value(language))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(TransferListResult.from_dictionary),
        ).execute()

    def retrieve_user_transfer(self,
                               user_token,
                               transfer_token):
        """Perform a GET request to
        /users/{user-token}/transfers/{transfer-token}.

        Retrieve a specific user bank [transfer](page:resources/transfers).

        Args:
            user_token (str): Auto-generated unique identifier representing a user,
                prefixed with `user-`.
            transfer_token (str): Auto-generated unique identifier representing a
                transfer, prefixed with `xfer-`.

        Returns:
            TransferResult: Response from the API. Sample transfer response

        Raises:
            APIException: When an error occurs while fetching the data from the
                remote API. This exception includes the HTTP Response code, an error
                message, and the HTTP body that was received in the request.

        """
        return super().new_api_call_builder.request(
            RequestBuilder().server(Server.API)
            .path("/users/{user-token}/transfers/{transfer-token}")
            .http_method(HttpMethodEnum.GET)
            .template_param(Parameter()
                .key("user-token")
                .value(user_token)
                .is_required(True)
                .should_encode(True))
            .template_param(Parameter()
                .key("transfer-token")
                .value(transfer_token)
                .is_required(True)
                .should_encode(True))
            .header_param(Parameter()
                .key("accept")
                .value("application/json"))
            .auth(Single("server")),
        ).response(
            ResponseHandler()
            .deserializer(APIHelper.json_deserialize)
            .deserialize_into(TransferResult.from_dictionary)
            .local_error("400", "", ApiErrorResultException)
            .local_error("500", "", ApiErrorResultException)
            .local_error("default", "", ApiErrorResultException),
        ).execute()
