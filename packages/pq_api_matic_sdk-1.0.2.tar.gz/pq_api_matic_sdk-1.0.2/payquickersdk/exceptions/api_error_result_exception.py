"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.exceptions.api_exception import (
    APIException,
)


class ApiErrorResultException(APIException):
    def __init__(self, reason, response):
        """Initialize ApiErrorResultException object.

        Args:
            reason (string): The reason (or error message) for the Exception
                to be raised.
            response (HttpResponse): The HttpResponse of the API call.

        """
        super(ApiErrorResultException, self).__init__(reason, response)
        dictionary = APIHelper.json_deserialize(self.response.text)
        if isinstance(dictionary, dict):
            self.unbox(dictionary)

    def unbox(self, dictionary):
        """Populate the properties of this object by extracting them from a dictionary.

        Args:
            dictionary (dictionary): A dictionary representation of the object as
            obtained from the deserialization of the server's response. The keys
            MUST match property names in the API description.

        """
        self.severity =\
            dictionary.get("severity")\
            if dictionary.get("severity")\
                else None
        self.error =\
            dictionary.get("error")\
            if dictionary.get("error")\
                else None
        self.code =\
            dictionary.get("code")\
            if dictionary.get("code")\
                else None
        self.message =\
            dictionary.get("message")\
            if dictionary.get("message")\
                else None
        self.reference_id =\
            dictionary.get("referenceId")\
            if dictionary.get("referenceId")\
                else None
        self.timestamp =\
            dictionary.get("timestamp")\
            if dictionary.get("timestamp")\
                else None
        self.request_ref =\
            dictionary.get("requestRef")\
            if dictionary.get("requestRef")\
                else None


    def __str__(self):
        """Return a human-readable string representation."""
        _severity=self.severity
        _error=self.error
        _code=self.code
        _message=self.message
        _reference_id=self.reference_id
        _timestamp=self.timestamp
        _request_ref=(
            self.request_ref
            if hasattr(self, "request_ref")
            else None
        )
        _base_str = super().__str__()
        _base_str = _base_str[_base_str.find("(") + 1:-1]
        return (
            f"{self.__class__.__name__}("
            f"base_str={_base_str!s}, "
            f"severity={_severity!s}, "
            f"error={_error!s}, "
            f"code={_code!s}, "
            f"message={_message!s}, "
            f"reference_id={_reference_id!s}, "
            f"timestamp={_timestamp!s}, "
            f"request_ref={_request_ref!s}, "
            f")"
        )
