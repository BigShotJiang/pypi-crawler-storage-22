"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.exceptions.api_exception import (
    APIException,
)


class OAuthProviderException(APIException):
    def __init__(self, reason, response):
        """Initialize OAuthProviderException object.

        Args:
            reason (string): The reason (or error message) for the Exception
                to be raised.
            response (HttpResponse): The HttpResponse of the API call.

        """
        super(OAuthProviderException, self).__init__(reason, response)
        dictionary = APIHelper.json_deserialize(self.response.text)
        if isinstance(dictionary, dict):
            self.unbox(dictionary)

    def unbox(self, dictionary):
        """Populate the properties of this object by extracting them from a dictionary.

        Args:
            dictionary (dictionary): A dictionary representation of the object as
            obtained from the deserialization of the server's response. The keys
            MUST match property names in the API description.

        """
        self.error =\
            dictionary.get("error")\
            if dictionary.get("error")\
                else None
        self.error_description =\
            dictionary.get("error_description")\
            if dictionary.get("error_description")\
                else None
        self.error_uri =\
            dictionary.get("error_uri")\
            if dictionary.get("error_uri")\
                else None


    def __str__(self):
        """Return a human-readable string representation."""
        _error=self.error
        _error_description=(
            self.error_description
            if hasattr(self, "error_description")
            else None
        )
        _error_uri=(
            self.error_uri
            if hasattr(self, "error_uri")
            else None
        )
        _base_str = super().__str__()
        _base_str = _base_str[_base_str.find("(") + 1:-1]
        return (
            f"{self.__class__.__name__}("
            f"base_str={_base_str!s}, "
            f"error={_error!s}, "
            f"error_description={_error_description!s}, "
            f"error_uri={_error_uri!s}, "
            f")"
        )
