
"""
pay_quicker_sdk

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

import os

from apimatic_core.authentication.header_auth import (
    HeaderAuth,
)


class Clientside(HeaderAuth):
    """
    An authentication handler that applies `BearerAuth` to
    outgoing requests. It constructs the required credential values and integrates
    with the core authentication framework.
    """

    @property
    def error_message(self):
        """Return reason about the authentication failure."""
        return "Clientside: access_token is undefined."

    def __init__(self, auth_credentials_model):
        """
        Initialize the authentication handler with credential data.

        Args:
            auth_credentials_model: The credentials object used to generate
                the authorization header.

        """
        self._access_token = auth_credentials_model.access_token \
            if auth_credentials_model is not None else None
        auth_params = {}
        if self._access_token:
            auth_params = {"Authorization": f"Bearer {self._access_token}"}
        super().__init__(auth_params=auth_params)


class ClientsideCredentials:
    """
    A model for authentication credentials. Provides simple validation,
    cloning support, and optional construction from environment variables.
    Suitable as a pattern for other auth models.
    """

    @property
    def access_token(self):
        """
        The OAuth 2.0 Access Token to use for API requests.
        """
        return self._access_token

    def __init__(self, access_token):
        """
        Initialize the credentials.

        Args:
            access_token: The access_token property value to set.

        Raises:
            ValueError: If any required value is missing.

        """
        if access_token is None:
            raise ValueError("access_token cannot be None")
        self._access_token = access_token

    def clone_with(self, access_token=None):
        """
        Return a new instance with optional value overrides.

        Args:
            access_token: The access_token property value to set.

        """
        return ClientsideCredentials(access_token or self.access_token)

    @classmethod
    def from_environment(cls):
        """
        Create credentials from environment variables, if available.

        Returns:
            A credentials instance or ``None`` if values are missing.

        """
        access_token = os.getenv(
            "CLIENTSIDE_ACCESS_TOKEN",
            None,
        )

        if (access_token is None):
            return None

        return cls(
            access_token=access_token,
        )
