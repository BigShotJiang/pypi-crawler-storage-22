
"""
pay_quicker_sdk

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

from apimatic_core.http.http_callback import HttpCallBack as CoreHttpCallback


class HttpCallBack(CoreHttpCallback):
    """
    An interface for the callback to be called before and after the
    HTTP call for an endpoint is made.

    This class should not be instantiated but should be used as a base class
    for HttpCallBack classes.

    """
