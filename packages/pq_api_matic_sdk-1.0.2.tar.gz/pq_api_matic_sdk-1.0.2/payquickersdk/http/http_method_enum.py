
"""
pay_quicker_sdk

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

from apimatic_core_interfaces.types.http_method_enum import (
    HttpMethodEnum as CoreHttpMethodEnum,
)


class HttpMethodEnum(CoreHttpMethodEnum):
    """
    Enumeration of an HTTP Method

    Attributes:
        GET: A GET Request
        POST: A POST Request
        PUT: A PUT Request
        PATCH: A PATCH Request
        DELETE: A DELETE Request

    """
