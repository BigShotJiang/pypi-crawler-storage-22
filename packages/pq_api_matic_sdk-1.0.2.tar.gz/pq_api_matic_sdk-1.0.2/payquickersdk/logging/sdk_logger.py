
"""
pay_quicker_sdk

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

from abc import abstractmethod

from apimatic_core_interfaces.logger.logger import Logger


class AbstractLogger(Logger):
    """An abstract class for custom logger implementation."""

    @abstractmethod
    def log(self, level, message, params):
        """
        Log a message with a specified log level and additional parameters.

        Args:
            level (int): The log level of the message.
            message (str): The message to log.
            params (dict): Additional parameters to include in the log message.

        """
        ...
