"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)
from payquickersdk.models.metadata_items import (
    MetadataItems,
)


class AgreementResult(object):
    """Implementation of the '_AgreementResult' model.

    Attributes:
        token (str): [Token](#/rest/models/structures/token) representing the resource
        content_base_64 (str): Program agreement content
        url (str): Full path of the URI to the content for the program agreement
        mtype (AgreementTypes): The model property of type AgreementTypes.
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        meta (MetadataItems): The model property of type MetadataItems.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "token": "token",
        "content_base_64": "contentBase64",
        "url": "url",
        "mtype": "type",
        "links": "links",
        "meta": "meta",
    }

    _optionals = [
        "token",
        "content_base_64",
        "url",
        "mtype",
        "links",
        "meta",
    ]

    def __init__(
        self,
        token=APIHelper.SKIP,
        content_base_64=APIHelper.SKIP,
        url=APIHelper.SKIP,
        mtype=APIHelper.SKIP,
        links=APIHelper.SKIP,
        meta=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a AgreementResult instance."""
        # Initialize members of the class
        if token is not APIHelper.SKIP:
            self.token = token
        if content_base_64 is not APIHelper.SKIP:
            self.content_base_64 = content_base_64
        if url is not APIHelper.SKIP:
            self.url = url
        if mtype is not APIHelper.SKIP:
            self.mtype = mtype
        if links is not APIHelper.SKIP:
            self.links = links
        if meta is not APIHelper.SKIP:
            self.meta = meta

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else APIHelper.SKIP
        content_base_64 =\
            dictionary.get("contentBase64")\
            if dictionary.get("contentBase64")\
                else APIHelper.SKIP
        url =\
            dictionary.get("url")\
            if dictionary.get("url")\
                else APIHelper.SKIP
        mtype =\
            dictionary.get("type")\
            if dictionary.get("type")\
                else APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP
        meta =\
            MetadataItems.from_dictionary(
                dictionary.get("meta"))\
                if "meta" in dictionary.keys()\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(token,
                   content_base_64,
                   url,
                   mtype,
                   links,
                   meta,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _content_base_64=(
            self.content_base_64
            if hasattr(self, "content_base_64")
            else None
        )
        _url=(
            self.url
            if hasattr(self, "url")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!r}, "
            f"content_base_64={_content_base_64!r}, "
            f"url={_url!r}, "
            f"mtype={_mtype!r}, "
            f"links={_links!r}, "
            f"meta={_meta!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _content_base_64=(
            self.content_base_64
            if hasattr(self, "content_base_64")
            else None
        )
        _url=(
            self.url
            if hasattr(self, "url")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!s}, "
            f"content_base_64={_content_base_64!s}, "
            f"url={_url!s}, "
            f"mtype={_mtype!s}, "
            f"links={_links!s}, "
            f"meta={_meta!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
