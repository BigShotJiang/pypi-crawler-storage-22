"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class AgreementTypes(object):
    """Implementation of the '__AgreementTypes' enum.

    Attributes:
        CARD_HOLDER_AGREEMENT: The enum member of type str.
        CARD_HOLDER_AGREEMENT_CONSENT: The enum member of type str.
        CARD_LIMITS: The enum member of type str.
        E_SIGN_AND_CONSENT: The enum member of type str.
        FEE_AGREEMENT: The enum member of type str.
        PRIVACY_POLICY: The enum member of type str.
        PRIVACY_POLICY_ADDENDUM: The enum member of type str.
        TERMS_OF_USE: The enum member of type str.
        UNDEFINED: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    CARD_HOLDER_AGREEMENT = "CARD_HOLDER_AGREEMENT"

    CARD_HOLDER_AGREEMENT_CONSENT = "CARD_HOLDER_AGREEMENT_CONSENT"

    CARD_LIMITS = "CARD_LIMITS"

    E_SIGN_AND_CONSENT = "E_SIGN_AND_CONSENT"

    FEE_AGREEMENT = "FEE_AGREEMENT"

    PRIVACY_POLICY = "PRIVACY_POLICY"

    PRIVACY_POLICY_ADDENDUM = "PRIVACY_POLICY_ADDENDUM"

    TERMS_OF_USE = "TERMS_OF_USE"

    UNDEFINED = "UNDEFINED"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
