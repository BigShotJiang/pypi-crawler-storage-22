"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.translation import (
    Translation,
)


class AuthorizationObject(object):
    """Implementation of the 'AuthorizationObject' model.

    Attributes:
        mtype (PrepaidCardAuthorizations): Financial types for the [prepaid
            card](page:resources/prepaid-cards) authorization.
        created_on (datetime): Time object was
            [created](#/rest/models/structures/created-on)
        sign (Signs): Receipt sign types
        source_token (str): Unique identifier representing the [source of
            funds](#/rest/models/structures/source-token)
        amount (float): Allocated money to be sent in the transaction.
        currency (Currencies): [Currency code type](#/rest/models/structures/country)
            for the object
        status (ReceiptStatuses): Receipt status types
        descriptions (List[Translation]): The model property of type
            List[Translation].
        auth_date (datetime): Date that the auth was created
        reference (str): [Provider
            reference](#/rest/models/structures/identity-verification-provider-referen
            ce) used for performing identity checks for the provider
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "mtype": "type",
        "created_on": "createdOn",
        "sign": "sign",
        "source_token": "sourceToken",
        "amount": "amount",
        "currency": "currency",
        "status": "status",
        "descriptions": "descriptions",
        "auth_date": "authDate",
        "reference": "reference",
    }

    _optionals = [
        "mtype",
        "created_on",
        "sign",
        "source_token",
        "amount",
        "currency",
        "status",
        "descriptions",
        "auth_date",
        "reference",
    ]

    def __init__(
        self,
        mtype=APIHelper.SKIP,
        created_on=APIHelper.SKIP,
        sign=APIHelper.SKIP,
        source_token="acct-3908ab5a-6ce1-474d-8b80-a63a7b147860",
        amount=1.02,
        currency="USD",
        status=APIHelper.SKIP,
        descriptions=APIHelper.SKIP,
        auth_date=APIHelper.SKIP,
        reference=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a AuthorizationObject instance."""
        # Initialize members of the class
        if mtype is not APIHelper.SKIP:
            self.mtype = mtype
        if created_on is not APIHelper.SKIP:
            self.created_on =\
                 APIHelper.apply_datetime_converter(
                created_on, APIHelper.RFC3339DateTime)\
                 if created_on else None
        if sign is not APIHelper.SKIP:
            self.sign = sign
        self.source_token = source_token
        self.amount = amount
        self.currency = currency
        if status is not APIHelper.SKIP:
            self.status = status
        if descriptions is not APIHelper.SKIP:
            self.descriptions = descriptions
        if auth_date is not APIHelper.SKIP:
            self.auth_date =\
                 APIHelper.apply_datetime_converter(
                auth_date, APIHelper.RFC3339DateTime)\
                 if auth_date else None
        if reference is not APIHelper.SKIP:
            self.reference = reference

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        mtype =\
            dictionary.get("type")\
            if dictionary.get("type")\
                else APIHelper.SKIP
        created_on = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("createdOn")).datetime\
            if dictionary.get("createdOn") else APIHelper.SKIP
        sign =\
            dictionary.get("sign")\
            if dictionary.get("sign")\
                else APIHelper.SKIP
        source_token =\
            dictionary.get("sourceToken")\
            if dictionary.get("sourceToken")\
                else "acct-3908ab5a-6ce1-474d-8b80-a63a7b147860"
        amount =\
            dictionary.get("amount")\
            if dictionary.get("amount")\
                else 1.02
        currency =\
            dictionary.get("currency")\
            if dictionary.get("currency")\
                else "USD"
        status =\
            dictionary.get("status")\
            if dictionary.get("status")\
                else APIHelper.SKIP
        descriptions = None
        if dictionary.get("descriptions") is not None:
            descriptions = [
                Translation.from_dictionary(x)
                    for x in dictionary.get("descriptions")
            ]
        else:
            descriptions = APIHelper.SKIP
        auth_date = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("authDate")).datetime\
            if dictionary.get("authDate") else APIHelper.SKIP
        reference =\
            dictionary.get("reference")\
            if dictionary.get("reference")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(mtype,
                   created_on,
                   sign,
                   source_token,
                   amount,
                   currency,
                   status,
                   descriptions,
                   auth_date,
                   reference,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _created_on=(
            self.created_on
            if hasattr(self, "created_on")
            else None
        )
        _sign=(
            self.sign
            if hasattr(self, "sign")
            else None
        )
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _amount=(
            self.amount
            if hasattr(self, "amount")
            else None
        )
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _descriptions=(
            self.descriptions
            if hasattr(self, "descriptions")
            else None
        )
        _auth_date=(
            self.auth_date
            if hasattr(self, "auth_date")
            else None
        )
        _reference=(
            self.reference
            if hasattr(self, "reference")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"mtype={_mtype!r}, "
            f"created_on={_created_on!r}, "
            f"sign={_sign!r}, "
            f"source_token={_source_token!r}, "
            f"amount={_amount!r}, "
            f"currency={_currency!r}, "
            f"status={_status!r}, "
            f"descriptions={_descriptions!r}, "
            f"auth_date={_auth_date!r}, "
            f"reference={_reference!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _created_on=(
            self.created_on
            if hasattr(self, "created_on")
            else None
        )
        _sign=(
            self.sign
            if hasattr(self, "sign")
            else None
        )
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _amount=(
            self.amount
            if hasattr(self, "amount")
            else None
        )
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _descriptions=(
            self.descriptions
            if hasattr(self, "descriptions")
            else None
        )
        _auth_date=(
            self.auth_date
            if hasattr(self, "auth_date")
            else None
        )
        _reference=(
            self.reference
            if hasattr(self, "reference")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"mtype={_mtype!s}, "
            f"created_on={_created_on!s}, "
            f"sign={_sign!s}, "
            f"source_token={_source_token!s}, "
            f"amount={_amount!s}, "
            f"currency={_currency!s}, "
            f"status={_status!s}, "
            f"descriptions={_descriptions!s}, "
            f"auth_date={_auth_date!s}, "
            f"reference={_reference!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
