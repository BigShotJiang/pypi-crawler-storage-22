"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)


class BalanceObject(object):
    """Implementation of the 'BalanceObject' model.

    Attributes:
        amount (float): Amount of money in the account
        currency (Currencies): [Currency code type](#/rest/models/structures/country)
            for the object
        formatted_amount (str): Combination of the amount and currency type
        token (str): [Token](#/rest/models/structures/token) representing the resource
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "amount": "amount",
        "currency": "currency",
        "formatted_amount": "formattedAmount",
        "token": "token",
        "links": "links",
    }

    _optionals = [
        "links",
    ]

    def __init__(
        self,
        amount=0,
        currency="USD",
        formatted_amount="$0.05 USD",
        token=None,
        links=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a BalanceObject instance."""
        # Initialize members of the class
        self.amount = amount
        self.currency = currency
        self.formatted_amount = formatted_amount
        self.token = token
        if links is not APIHelper.SKIP:
            self.links = links

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        amount =\
            dictionary.get("amount")\
            if dictionary.get("amount")\
                else 0
        currency =\
            dictionary.get("currency")\
            if dictionary.get("currency")\
                else "USD"
        formatted_amount =\
            dictionary.get("formattedAmount")\
            if dictionary.get("formattedAmount")\
                else "$0.05 USD"
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else None
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(amount,
                   currency,
                   formatted_amount,
                   token,
                   links,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _amount=self.amount
        _currency=self.currency
        _formatted_amount=self.formatted_amount
        _token=self.token
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"amount={_amount!r}, "
            f"currency={_currency!r}, "
            f"formatted_amount={_formatted_amount!r}, "
            f"token={_token!r}, "
            f"links={_links!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _amount=self.amount
        _currency=self.currency
        _formatted_amount=self.formatted_amount
        _token=self.token
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"amount={_amount!s}, "
            f"currency={_currency!s}, "
            f"formatted_amount={_formatted_amount!s}, "
            f"token={_token!s}, "
            f"links={_links!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
