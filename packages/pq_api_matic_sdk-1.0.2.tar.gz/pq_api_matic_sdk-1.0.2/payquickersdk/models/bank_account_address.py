"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class BankAccountAddress(object):
    """Implementation of the '_BankAccountAddress' model.

    Attributes:
        address_1 (str): Address Line 1
        address_2 (str): The model property of type str.
        address_3 (str): The model property of type str.
        city (str): The model property of type str.
        region (str): The model property of type str.
        postal_code (str): The model property of type str.
        country (Countries): Throughout the PayQuicker API, the usage of the 2-letter
            alpha code is used in place of the country name, e.g., for bank country
            or residential country.  The 2-letter codes adhere to the ISO 3166-1 spec
            and are listed here for convenience.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "address_1": "address1",
        "city": "city",
        "postal_code": "postalCode",
        "country": "country",
        "address_2": "address2",
        "address_3": "address3",
        "region": "region",
    }

    _optionals = [
        "address_2",
        "address_3",
        "region",
    ]

    def __init__(
        self,
        address_1=None,
        city=None,
        postal_code=None,
        country=None,
        address_2=APIHelper.SKIP,
        address_3=APIHelper.SKIP,
        region=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a BankAccountAddress instance."""
        # Initialize members of the class
        self.address_1 = address_1
        if address_2 is not APIHelper.SKIP:
            self.address_2 = address_2
        if address_3 is not APIHelper.SKIP:
            self.address_3 = address_3
        self.city = city
        if region is not APIHelper.SKIP:
            self.region = region
        self.postal_code = postal_code
        self.country = country

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        address_1 =\
            dictionary.get("address1")\
            if dictionary.get("address1")\
                else None
        city =\
            dictionary.get("city")\
            if dictionary.get("city")\
                else None
        postal_code =\
            dictionary.get("postalCode")\
            if dictionary.get("postalCode")\
                else None
        country =\
            dictionary.get("country")\
            if dictionary.get("country")\
                else None
        address_2 =\
            dictionary.get("address2")\
            if dictionary.get("address2")\
                else APIHelper.SKIP
        address_3 =\
            dictionary.get("address3")\
            if dictionary.get("address3")\
                else APIHelper.SKIP
        region =\
            dictionary.get("region")\
            if dictionary.get("region")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(address_1,
                   city,
                   postal_code,
                   country,
                   address_2,
                   address_3,
                   region,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _address_1=self.address_1
        _address_2=(
            self.address_2
            if hasattr(self, "address_2")
            else None
        )
        _address_3=(
            self.address_3
            if hasattr(self, "address_3")
            else None
        )
        _city=self.city
        _region=(
            self.region
            if hasattr(self, "region")
            else None
        )
        _postal_code=self.postal_code
        _country=self.country
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"address_1={_address_1!r}, "
            f"address_2={_address_2!r}, "
            f"address_3={_address_3!r}, "
            f"city={_city!r}, "
            f"region={_region!r}, "
            f"postal_code={_postal_code!r}, "
            f"country={_country!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _address_1=self.address_1
        _address_2=(
            self.address_2
            if hasattr(self, "address_2")
            else None
        )
        _address_3=(
            self.address_3
            if hasattr(self, "address_3")
            else None
        )
        _city=self.city
        _region=(
            self.region
            if hasattr(self, "region")
            else None
        )
        _postal_code=self.postal_code
        _country=self.country
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"address_1={_address_1!s}, "
            f"address_2={_address_2!s}, "
            f"address_3={_address_3!s}, "
            f"city={_city!s}, "
            f"region={_region!s}, "
            f"postal_code={_postal_code!s}, "
            f"country={_country!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
