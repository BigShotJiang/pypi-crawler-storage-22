"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
class BankAccountField(object):
    """Implementation of the '_BankAccountField' model.

    1...N required
    [fields](#/rest/models/structures/key-value-pair-bank-field-types-string) as
    determined by call to get requirements

    Attributes:
        key (BankAccountFields): Classifies bank account [field
            types](#/rest/models/structures/bank-account-fields)
        value (str): The model property of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "key": "key",
        "value": "value",
    }

    def __init__(
        self,
        key=None,
        value=None,
        additional_properties=None):
        """Initialize a BankAccountField instance."""
        # Initialize members of the class
        self.key = key
        self.value = value

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        key =\
            dictionary.get("key")\
            if dictionary.get("key")\
                else None
        value =\
            dictionary.get("value")\
            if dictionary.get("value")\
                else None

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(key,
                   value,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _key=self.key
        _value=self.value
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"key={_key!r}, "
            f"value={_value!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _key=self.key
        _value=self.value
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"key={_key!s}, "
            f"value={_value!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
