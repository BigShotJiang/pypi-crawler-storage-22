"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.bank_account_requirement_format import (
    BankAccountRequirementFormat,
)
from payquickersdk.models.bank_account_requirement_validator import (
    BankAccountRequirementValidator,
)
from payquickersdk.models.translation import (
    Translation,
)


class BankAccountRequiredFields(object):
    """Implementation of the '_BankAccountRequiredFields' model.

    Classifies the required [bank account
    field](#/rest/models/structures/bank-account-required-fields) objects

    Attributes:
        format (BankAccountRequirementFormat): Classifies the
            [format](#/rest/models/structures/bank-account-requirement-format) of the
            required information for a bank account
        requirement (BankAccountFields): Classifies bank account [field
            types](#/rest/models/structures/bank-account-fields)
        description (List[Translation]): Localized requirement description for
            display purposes
        validators (List[BankAccountRequirementValidator]): The model property of
            type List[BankAccountRequirementValidator].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "format": "format",
        "requirement": "requirement",
        "description": "description",
        "validators": "validators",
    }

    _optionals = [
        "format",
        "requirement",
        "description",
        "validators",
    ]

    def __init__(
        self,
        format=APIHelper.SKIP,
        requirement=APIHelper.SKIP,
        description=APIHelper.SKIP,
        validators=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a BankAccountRequiredFields instance."""
        # Initialize members of the class
        if format is not APIHelper.SKIP:
            self.format = format
        if requirement is not APIHelper.SKIP:
            self.requirement = requirement
        if description is not APIHelper.SKIP:
            self.description = description
        if validators is not APIHelper.SKIP:
            self.validators = validators

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        format =\
            BankAccountRequirementFormat.from_dictionary(
                dictionary.get("format"))\
                if "format" in dictionary.keys()\
                else APIHelper.SKIP
        requirement =\
            dictionary.get("requirement")\
            if dictionary.get("requirement")\
                else APIHelper.SKIP
        description = None
        if dictionary.get("description") is not None:
            description = [
                Translation.from_dictionary(x)
                    for x in dictionary.get("description")
            ]
        else:
            description = APIHelper.SKIP
        validators = None
        if dictionary.get("validators") is not None:
            validators = [
                BankAccountRequirementValidator.from_dictionary(x)
                    for x in dictionary.get("validators")
            ]
        else:
            validators = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(format,
                   requirement,
                   description,
                   validators,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _format=(
            self.format
            if hasattr(self, "format")
            else None
        )
        _requirement=(
            self.requirement
            if hasattr(self, "requirement")
            else None
        )
        _description=(
            self.description
            if hasattr(self, "description")
            else None
        )
        _validators=(
            self.validators
            if hasattr(self, "validators")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"format={_format!r}, "
            f"requirement={_requirement!r}, "
            f"description={_description!r}, "
            f"validators={_validators!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _format=(
            self.format
            if hasattr(self, "format")
            else None
        )
        _requirement=(
            self.requirement
            if hasattr(self, "requirement")
            else None
        )
        _description=(
            self.description
            if hasattr(self, "description")
            else None
        )
        _validators=(
            self.validators
            if hasattr(self, "validators")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"format={_format!s}, "
            f"requirement={_requirement!s}, "
            f"description={_description!s}, "
            f"validators={_validators!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
