"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.translation import (
    Translation,
)


class BankAccountRequirementFormatLegend(object):
    """Implementation of the '_BankAccountRequirementFormatLegend' model.

    Classifies the [legend
    format](#/rest/models/structures/bank-account-requirement-format-legend) of the
    required information for a bank account

    Attributes:
        key (str): The model property of type str.
        descriptions (List[Translation]): Localized requirement description for
            display purposes
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "key": "key",
        "descriptions": "descriptions",
    }

    _optionals = [
        "key",
        "descriptions",
    ]

    def __init__(
        self,
        key=APIHelper.SKIP,
        descriptions=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a BankAccountRequirementFormatLegend instance."""
        # Initialize members of the class
        if key is not APIHelper.SKIP:
            self.key = key
        if descriptions is not APIHelper.SKIP:
            self.descriptions = descriptions

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        key =\
            dictionary.get("key")\
            if dictionary.get("key")\
                else APIHelper.SKIP
        descriptions = None
        if dictionary.get("descriptions") is not None:
            descriptions = [
                Translation.from_dictionary(x)
                    for x in dictionary.get("descriptions")
            ]
        else:
            descriptions = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(key,
                   descriptions,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _key=(
            self.key
            if hasattr(self, "key")
            else None
        )
        _descriptions=(
            self.descriptions
            if hasattr(self, "descriptions")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"key={_key!r}, "
            f"descriptions={_descriptions!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _key=(
            self.key
            if hasattr(self, "key")
            else None
        )
        _descriptions=(
            self.descriptions
            if hasattr(self, "descriptions")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"key={_key!s}, "
            f"descriptions={_descriptions!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
