"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.bank_account_requirement import (
    BankAccountRequirement,
)
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)
from payquickersdk.models.list_metadata import (
    ListMetadata,
)


class BankAccountRequirementListResult(object):
    """Implementation of the '_BankAccountRequirementListResult' model.

    Attributes:
        payload (List[BankAccountRequirement]): The model property of type
            List[BankAccountRequirement].
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        meta (ListMetadata): The model property of type ListMetadata.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "payload": "payload",
        "links": "links",
        "meta": "meta",
    }

    _optionals = [
        "payload",
        "links",
        "meta",
    ]

    def __init__(
        self,
        payload=APIHelper.SKIP,
        links=APIHelper.SKIP,
        meta=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a BankAccountRequirementListResult instance."""
        # Initialize members of the class
        if payload is not APIHelper.SKIP:
            self.payload = payload
        if links is not APIHelper.SKIP:
            self.links = links
        if meta is not APIHelper.SKIP:
            self.meta = meta

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        payload = None
        if dictionary.get("payload") is not None:
            payload = [
                BankAccountRequirement.from_dictionary(x)
                    for x in dictionary.get("payload")
            ]
        else:
            payload = APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP
        meta =\
            ListMetadata.from_dictionary(
                dictionary.get("meta"))\
                if "meta" in dictionary.keys()\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(payload,
                   links,
                   meta,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _payload=(
            self.payload
            if hasattr(self, "payload")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"payload={_payload!r}, "
            f"links={_links!r}, "
            f"meta={_meta!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _payload=(
            self.payload
            if hasattr(self, "payload")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"payload={_payload!s}, "
            f"links={_links!s}, "
            f"meta={_meta!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
