"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.bank_account_address import (
    BankAccountAddress,
)
from payquickersdk.models.bank_account_field import (
    BankAccountField,
)
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)
from payquickersdk.models.metadata_items import (
    MetadataItems,
)


class BankAccountResult(object):
    """Implementation of the '_BankAccountResult' model.

    Attributes:
        token (str): Unique identifier representing the [destination of
            funds](#/rest/models/structures/destination-token)
        bank_account_ownership_type (BankAccountOwnership): Account [ownership
            types](#/rest/models/structures/bank-account-ownership)
        bank_country (Countries): Throughout the PayQuicker API, the usage of the
            2-letter alpha code is used in place of the country name, e.g., for bank
            country or residential country.  The 2-letter codes adhere to the ISO
            3166-1 spec and are listed here for convenience.
        bank_currency (Currencies): [Currency code
            type](#/rest/models/structures/country) for the object
        address (BankAccountAddress): The model property of type BankAccountAddress.
        created_on (datetime): Time object was
            [created](#/rest/models/structures/created-on)
        description (str): User-supplied description of the bank account for reference
        fields (List[BankAccountField]): The model property of type
            List[BankAccountField].
        status (BankAccountStatuses): Current verification status type of the [bank
            account](#/rest/models/structures/bank-account-status)
        mtype (BankAccountTypes): Financial purpose of the [bank
            account](#/rest/models/structures/bank-account-type)
        transfer_method_type (TransferMethodTypes): Optional transfer methods
            applicable only to bank and e-wallet transfers.
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        meta (MetadataItems): The model property of type MetadataItems.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "token": "token",
        "bank_account_ownership_type": "bankAccountOwnershipType",
        "bank_country": "bankCountry",
        "bank_currency": "bankCurrency",
        "address": "address",
        "created_on": "createdOn",
        "description": "description",
        "fields": "fields",
        "status": "status",
        "mtype": "type",
        "transfer_method_type": "transferMethodType",
        "links": "links",
        "meta": "meta",
    }

    _optionals = [
        "token",
        "bank_account_ownership_type",
        "bank_country",
        "bank_currency",
        "address",
        "created_on",
        "description",
        "fields",
        "status",
        "mtype",
        "transfer_method_type",
        "links",
        "meta",
    ]

    def __init__(
        self,
        token="dest-631b200f-665d-4dbe-bd01-3063c9dec97d",
        bank_account_ownership_type=APIHelper.SKIP,
        bank_country=APIHelper.SKIP,
        bank_currency="USD",
        address=APIHelper.SKIP,
        created_on=APIHelper.SKIP,
        description=APIHelper.SKIP,
        fields=APIHelper.SKIP,
        status=APIHelper.SKIP,
        mtype=APIHelper.SKIP,
        transfer_method_type=APIHelper.SKIP,
        links=APIHelper.SKIP,
        meta=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a BankAccountResult instance."""
        # Initialize members of the class
        self.token = token
        if bank_account_ownership_type is not APIHelper.SKIP:
            self.bank_account_ownership_type = bank_account_ownership_type
        if bank_country is not APIHelper.SKIP:
            self.bank_country = bank_country
        self.bank_currency = bank_currency
        if address is not APIHelper.SKIP:
            self.address = address
        if created_on is not APIHelper.SKIP:
            self.created_on =\
                 APIHelper.apply_datetime_converter(
                created_on, APIHelper.RFC3339DateTime)\
                 if created_on else None
        if description is not APIHelper.SKIP:
            self.description = description
        if fields is not APIHelper.SKIP:
            self.fields = fields
        if status is not APIHelper.SKIP:
            self.status = status
        if mtype is not APIHelper.SKIP:
            self.mtype = mtype
        if transfer_method_type is not APIHelper.SKIP:
            self.transfer_method_type = transfer_method_type
        if links is not APIHelper.SKIP:
            self.links = links
        if meta is not APIHelper.SKIP:
            self.meta = meta

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else "dest-631b200f-665d-4dbe-bd01-3063c9dec97d"
        bank_account_ownership_type =\
            dictionary.get("bankAccountOwnershipType")\
            if dictionary.get("bankAccountOwnershipType")\
                else APIHelper.SKIP
        bank_country =\
            dictionary.get("bankCountry")\
            if dictionary.get("bankCountry")\
                else APIHelper.SKIP
        bank_currency =\
            dictionary.get("bankCurrency")\
            if dictionary.get("bankCurrency")\
                else "USD"
        address =\
            BankAccountAddress.from_dictionary(
                dictionary.get("address"))\
                if "address" in dictionary.keys()\
                else APIHelper.SKIP
        created_on = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("createdOn")).datetime\
            if dictionary.get("createdOn") else APIHelper.SKIP
        description =\
            dictionary.get("description")\
            if dictionary.get("description")\
                else APIHelper.SKIP
        fields = None
        if dictionary.get("fields") is not None:
            fields = [
                BankAccountField.from_dictionary(x)
                    for x in dictionary.get("fields")
            ]
        else:
            fields = APIHelper.SKIP
        status =\
            dictionary.get("status")\
            if dictionary.get("status")\
                else APIHelper.SKIP
        mtype =\
            dictionary.get("type")\
            if dictionary.get("type")\
                else APIHelper.SKIP
        transfer_method_type =\
            dictionary.get("transferMethodType")\
            if dictionary.get("transferMethodType")\
                else APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP
        meta =\
            MetadataItems.from_dictionary(
                dictionary.get("meta"))\
                if "meta" in dictionary.keys()\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(token,
                   bank_account_ownership_type,
                   bank_country,
                   bank_currency,
                   address,
                   created_on,
                   description,
                   fields,
                   status,
                   mtype,
                   transfer_method_type,
                   links,
                   meta,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _bank_account_ownership_type=(
            self.bank_account_ownership_type
            if hasattr(self, "bank_account_ownership_type")
            else None
        )
        _bank_country=(
            self.bank_country
            if hasattr(self, "bank_country")
            else None
        )
        _bank_currency=(
            self.bank_currency
            if hasattr(self, "bank_currency")
            else None
        )
        _address=(
            self.address
            if hasattr(self, "address")
            else None
        )
        _created_on=(
            self.created_on
            if hasattr(self, "created_on")
            else None
        )
        _description=(
            self.description
            if hasattr(self, "description")
            else None
        )
        _fields=(
            self.fields
            if hasattr(self, "fields")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _transfer_method_type=(
            self.transfer_method_type
            if hasattr(self, "transfer_method_type")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!r}, "
            f"bank_account_ownership_type={_bank_account_ownership_type!r}, "
            f"bank_country={_bank_country!r}, "
            f"bank_currency={_bank_currency!r}, "
            f"address={_address!r}, "
            f"created_on={_created_on!r}, "
            f"description={_description!r}, "
            f"fields={_fields!r}, "
            f"status={_status!r}, "
            f"mtype={_mtype!r}, "
            f"transfer_method_type={_transfer_method_type!r}, "
            f"links={_links!r}, "
            f"meta={_meta!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _bank_account_ownership_type=(
            self.bank_account_ownership_type
            if hasattr(self, "bank_account_ownership_type")
            else None
        )
        _bank_country=(
            self.bank_country
            if hasattr(self, "bank_country")
            else None
        )
        _bank_currency=(
            self.bank_currency
            if hasattr(self, "bank_currency")
            else None
        )
        _address=(
            self.address
            if hasattr(self, "address")
            else None
        )
        _created_on=(
            self.created_on
            if hasattr(self, "created_on")
            else None
        )
        _description=(
            self.description
            if hasattr(self, "description")
            else None
        )
        _fields=(
            self.fields
            if hasattr(self, "fields")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _transfer_method_type=(
            self.transfer_method_type
            if hasattr(self, "transfer_method_type")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!s}, "
            f"bank_account_ownership_type={_bank_account_ownership_type!s}, "
            f"bank_country={_bank_country!s}, "
            f"bank_currency={_bank_currency!s}, "
            f"address={_address!s}, "
            f"created_on={_created_on!s}, "
            f"description={_description!s}, "
            f"fields={_fields!s}, "
            f"status={_status!s}, "
            f"mtype={_mtype!s}, "
            f"transfer_method_type={_transfer_method_type!s}, "
            f"links={_links!s}, "
            f"meta={_meta!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
