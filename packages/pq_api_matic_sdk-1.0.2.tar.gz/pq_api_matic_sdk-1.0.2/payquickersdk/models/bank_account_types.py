"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class BankAccountTypes(object):
    """Implementation of the '__BankAccountTypes' enum.

    Financial purpose of the [bank
    account](#/rest/models/structures/bank-account-type)

    Attributes:
        CHECKING: An account at a financial institution against which checks can be
            drawn by the account depositor.
        MONEY_MARKET: An interest-bearing account at a bank or credit union.
        SAVINGS: An account at a financial institution that pays interest but cannot
            be used directly as money in the narrow sense of a medium of exchange.
        UNDEFINED: Unknown or unrecognized.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    CHECKING = "CHECKING"

    MONEY_MARKET = "MONEY_MARKET"

    SAVINGS = "SAVINGS"

    UNDEFINED = "UNDEFINED"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
