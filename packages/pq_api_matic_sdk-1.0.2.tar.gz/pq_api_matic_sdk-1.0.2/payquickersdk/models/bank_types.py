"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class BankTypes(object):
    """Implementation of the '__BankTypes' enum.

    Name of the bank

    Attributes:
        MCB: The enum member of type str.
        PEOPLES: The enum member of type str.
        PPS: The enum member of type str.
        TOKA: The enum member of type str.
        UNDEFINED: The enum member of type str.
        CHOICELTD: The enum member of type str.
        FLEX: The enum member of type str.
        REWARDS: The enum member of type str.
        PATHWARD: The enum member of type str.
        SUTTON: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    MCB = "MCB"

    PEOPLES = "PEOPLES"

    PPS = "PPS"

    TOKA = "TOKA"

    UNDEFINED = "UNDEFINED"

    CHOICELTD = "CHOICELTD"

    FLEX = "FLEX"

    REWARDS = "REWARDS"

    PATHWARD = "PATHWARD"

    SUTTON = "SUTTON"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
