"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class CardProcessors(object):
    """Implementation of the '__CardProcessors' enum.

    The processor type for the prepaid card

    Attributes:
        FIS: The enum member of type str.
        FLEX: The enum member of type str.
        EPS: The enum member of type str.
        TOKA: The enum member of type str.
        QOLO: The enum member of type str.
        UNDEFINED: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    FIS = "FIS"

    FLEX = "FLEX"

    EPS = "EPS"

    TOKA = "TOKA"

    QOLO = "QOLO"

    UNDEFINED = "UNDEFINED"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
