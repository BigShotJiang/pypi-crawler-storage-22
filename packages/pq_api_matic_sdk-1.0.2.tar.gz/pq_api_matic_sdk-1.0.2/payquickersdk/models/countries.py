"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class Countries(object):
    """Implementation of the '__Countries' enum.

    Throughout the PayQuicker API, the usage of the 2-letter alpha code is used in
    place of the country name, e.g., for bank country or residential country.
    The 2-letter codes adhere to the ISO 3166-1 spec and are listed here for
    convenience.

    Attributes:
        AD: Andorra
        AE: United Arab Emirates
        AF: Afghanistan
        AG: Antigua and Barbuda
        AI: Anguilla
        AL: Albania
        AM: Armenia
        AN: Netherlands Antilles
        AO: Angola
        AQ: Antarctica
        AR: Argentina
        AS: American Samoa
        AT: Austria
        AU: Australia
        AW: Aruba
        AX: Aland Islands
        AZ: Azerbaijan
        BA: Bosnia and Herzegovina
        BB: Barbados
        BD: Bangladesh
        BE: Belgium
        BF: Burkina Faso
        BG: Bulgaria
        BH: Bahrain
        BI: Burundi
        BJ: Benin
        BL: Saint Barthelemy
        BM: Bermuda
        BN: Brunei Darussalam
        BO: Bolivia
        BQ: Bonaire, Saint Eustatius and Saba
        BR: Brazil
        BS: Bahamas
        BT: Bhutan
        BV: Bouvet Island
        BW: Botswana
        BY: Belarus
        BZ: Belize
        CA: Canada
        CC: Cocos Islands
        CD: Congo, Democratic Republic of the
        CF: Central African Republic
        CG: Republic of the Congo
        CH: Switzerland
        CI: Ivory Coast
        CK: Cook Islands
        CL: Chile
        CM: Cameroon
        CN: China
        CO: Colombia
        CR: Costa Rica
        CU: Cuba
        CV: Cape Verde
        CW: Curacao
        CX: Christmas Island
        CY: Cyprus
        CZ: Czech Republic
        DE: Germany
        DJ: Djibouti
        DK: Denmark
        DM: Dominica
        DO: Dominican Republic
        DZ: Algeria
        EC: Ecuador
        EE: Estonia
        EG: Egypt
        EH: Western Sahara
        ER: Eritrea
        ES: Spain
        ET: Ethiopia
        FI: Finland
        FJ: Fiji
        FK: Falkland Islands (Malvinas)
        FM: Micronesia
        FO: Faroe Islands
        FR: France
        GA: Gabon
        GB: United Kingdom
        GD: Grenada
        GE: Georgia
        GF: French Guiana
        GG: Guernsey
        GH: Ghana
        GI: Gibraltar
        GL: Greenland
        GM: Gambia
        GN: Guinea
        GP: Guadeloupe
        GQ: Equatorial Guinea
        GR: Greece
        GS: South Georgia and the South Sandwich Islands
        GT: Guatemala
        GU: Guam
        GW: Guinea-Bissau
        GY: Guyana
        HK: Hong Kong
        HM: Heard Island and Mcdonald Islands
        HN: Honduras
        HR: Croatia
        HT: Haiti
        HU: Hungary
        ID: Indonesia
        IE: Ireland
        IL: Israel
        IM: Isle of Man
        IN: India
        IO: British Indian Ocean Territory
        IQ: Iraq
        IR: Iran
        IS: Iceland
        IT: Italy
        JE: Jersey
        JM: Jamaica
        JO: Jordan
        JP: Japan
        KE: Kenya
        KG: Kyrgyzstan
        KH: Cambodia
        KI: Kiribati
        KM: Comoros
        KN: Saint Kitts and Nevis
        KP: North Korea
        KR: South Korea
        KW: Kuwait
        KY: Cayman Islands
        KZ: Kazakhstan
        LA: Lao PDR
        LB: Lebanon
        LC: Saint Lucia
        LI: Liechtenstein
        LK: Sri Lanka
        LR: Liberia
        LS: Lesotho
        LT: Lithuania
        LU: Luxembourg
        LV: Latvia
        LY: Libya
        MA: Morocco
        MC: Monaco
        MD: Moldova
        ME: Montenegro
        MF: Saint Martin
        MG: Madagascar
        MH: Marshall Islands
        MK: Macedonia
        ML: Mali
        MM: Myanmar
        MN: Mongolia
        MO: Macao
        MP: Northern Mariana Islands
        MQ: Martinique
        MR: Mauritania
        MS: Montserrat
        MT: Malta
        MU: Mauritius
        MV: Maldives
        MW: Malawi
        MX: Mexico
        MY: Malaysia
        MZ: Mozambique
        NA: Namibia
        NC: New Caledonia
        NE: Niger
        NF: Norfolk Island
        NG: Nigeria
        NI: Nicaragua
        NL: Netherlands
        NO: Norway
        NP: Nepal
        NR: Nauru
        NU: Niue
        NZ: New Zealand
        OM: Oman
        PA: Panama
        PE: Peru
        PF: French Polynesia
        PG: Papua New Guinea
        PH: Philippines
        PK: Pakistan
        PL: Poland
        PM: Saint Pierre and Miquelon
        PN: Pitcairn
        PR: Puerto Rico
        PS: Palestinian Territory
        PT: Portugal
        PW: Palau
        PY: Paraguay
        QA: Qatar
        RE: Reunion
        RO: Romania
        RS: Serbia
        RU: Russian Federation
        RW: Rwanda
        SA: Saudi Arabia
        SB: Solomon Islands
        SC: Seychelles
        SD: Sudan
        SE: Sweden
        SG: Singapore
        SH: Saint Helena
        SI: Slovenia
        SJ: Svalbard and Jan Mayen Islands
        SK: Slovakia
        SL: Sierra Leone
        SM: San Marino
        SN: Senegal
        SO: Somalia
        SR: Suriname
        SS: South Sudan
        ST: Sao Tome and Principe
        SV: El Salvador
        SX: Sint Maarten
        SY: Syria
        SZ: Swaziland
        TC: Turks and Caicos Islands
        TD: Chad
        TF: French Southern Territories
        TG: Togo
        TH: Thailand
        TJ: Tajikistan
        TK: Tokelau
        TL: East Timor
        TM: Turkmenistan
        TN: Tunisia
        TO: Tonga
        TR: Turkey
        TT: Trinidad and Tobago
        TV: Tuvalu
        TW: Taiwan
        TZ: Tanzania
        UA: Ukraine
        UG: Uganda
        UM: United States Minor Outlying Islands
        US: United States of America
        UY: Uruguay
        UZ: Uzbekistan
        VA: Vatican
        VC: Saint Vincent and Grenadines
        VE: Venezuela
        VG: British Virgin Islands
        VI: U.S. Virgin Islands
        VN: Vietnam
        VU: Vanuatu
        WF: Wallis and Futuna Islands
        WS: Samoa
        YE: Yemen
        YT: Mayotte
        ZA: South Africa
        ZM: Zambia
        ZW: Zimbabwe
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    AD = "AD"

    AE = "AE"

    AF = "AF"

    AG = "AG"

    AI = "AI"

    AL = "AL"

    AM = "AM"

    AN = "AN"

    AO = "AO"

    AQ = "AQ"

    AR = "AR"

    AS = "AS"

    AT = "AT"

    AU = "AU"

    AW = "AW"

    AX = "AX"

    AZ = "AZ"

    BA = "BA"

    BB = "BB"

    BD = "BD"

    BE = "BE"

    BF = "BF"

    BG = "BG"

    BH = "BH"

    BI = "BI"

    BJ = "BJ"

    BL = "BL"

    BM = "BM"

    BN = "BN"

    BO = "BO"

    BQ = "BQ"

    BR = "BR"

    BS = "BS"

    BT = "BT"

    BV = "BV"

    BW = "BW"

    BY = "BY"

    BZ = "BZ"

    CA = "CA"

    CC = "CC"

    CD = "CD"

    CF = "CF"

    CG = "CG"

    CH = "CH"

    CI = "CI"

    CK = "CK"

    CL = "CL"

    CM = "CM"

    CN = "CN"

    CO = "CO"

    CR = "CR"

    CU = "CU"

    CV = "CV"

    CW = "CW"

    CX = "CX"

    CY = "CY"

    CZ = "CZ"

    DE = "DE"

    DJ = "DJ"

    DK = "DK"

    DM = "DM"

    DO = "DO"

    DZ = "DZ"

    EC = "EC"

    EE = "EE"

    EG = "EG"

    EH = "EH"

    ER = "ER"

    ES = "ES"

    ET = "ET"

    FI = "FI"

    FJ = "FJ"

    FK = "FK"

    FM = "FM"

    FO = "FO"

    FR = "FR"

    GA = "GA"

    GB = "GB"

    GD = "GD"

    GE = "GE"

    GF = "GF"

    GG = "GG"

    GH = "GH"

    GI = "GI"

    GL = "GL"

    GM = "GM"

    GN = "GN"

    GP = "GP"

    GQ = "GQ"

    GR = "GR"

    GS = "GS"

    GT = "GT"

    GU = "GU"

    GW = "GW"

    GY = "GY"

    HK = "HK"

    HM = "HM"

    HN = "HN"

    HR = "HR"

    HT = "HT"

    HU = "HU"

    ID = "ID"

    IE = "IE"

    IL = "IL"

    IM = "IM"

    IN = "IN"

    IO = "IO"

    IQ = "IQ"

    IR = "IR"

    IS = "IS"

    IT = "IT"

    JE = "JE"

    JM = "JM"

    JO = "JO"

    JP = "JP"

    KE = "KE"

    KG = "KG"

    KH = "KH"

    KI = "KI"

    KM = "KM"

    KN = "KN"

    KP = "KP"

    KR = "KR"

    KW = "KW"

    KY = "KY"

    KZ = "KZ"

    LA = "LA"

    LB = "LB"

    LC = "LC"

    LI = "LI"

    LK = "LK"

    LR = "LR"

    LS = "LS"

    LT = "LT"

    LU = "LU"

    LV = "LV"

    LY = "LY"

    MA = "MA"

    MC = "MC"

    MD = "MD"

    ME = "ME"

    MF = "MF"

    MG = "MG"

    MH = "MH"

    MK = "MK"

    ML = "ML"

    MM = "MM"

    MN = "MN"

    MO = "MO"

    MP = "MP"

    MQ = "MQ"

    MR = "MR"

    MS = "MS"

    MT = "MT"

    MU = "MU"

    MV = "MV"

    MW = "MW"

    MX = "MX"

    MY = "MY"

    MZ = "MZ"

    NA = "NA"

    NC = "NC"

    NE = "NE"

    NF = "NF"

    NG = "NG"

    NI = "NI"

    NL = "NL"

    NO = "NO"

    NP = "NP"

    NR = "NR"

    NU = "NU"

    NZ = "NZ"

    OM = "OM"

    PA = "PA"

    PE = "PE"

    PF = "PF"

    PG = "PG"

    PH = "PH"

    PK = "PK"

    PL = "PL"

    PM = "PM"

    PN = "PN"

    PR = "PR"

    PS = "PS"

    PT = "PT"

    PW = "PW"

    PY = "PY"

    QA = "QA"

    RE = "RE"

    RO = "RO"

    RS = "RS"

    RU = "RU"

    RW = "RW"

    SA = "SA"

    SB = "SB"

    SC = "SC"

    SD = "SD"

    SE = "SE"

    SG = "SG"

    SH = "SH"

    SI = "SI"

    SJ = "SJ"

    SK = "SK"

    SL = "SL"

    SM = "SM"

    SN = "SN"

    SO = "SO"

    SR = "SR"

    SS = "SS"

    ST = "ST"

    SV = "SV"

    SX = "SX"

    SY = "SY"

    SZ = "SZ"

    TC = "TC"

    TD = "TD"

    TF = "TF"

    TG = "TG"

    TH = "TH"

    TJ = "TJ"

    TK = "TK"

    TL = "TL"

    TM = "TM"

    TN = "TN"

    TO = "TO"

    TR = "TR"

    TT = "TT"

    TV = "TV"

    TW = "TW"

    TZ = "TZ"

    UA = "UA"

    UG = "UG"

    UM = "UM"

    US = "US"

    UY = "UY"

    UZ = "UZ"

    VA = "VA"

    VC = "VC"

    VE = "VE"

    VG = "VG"

    VI = "VI"

    VN = "VN"

    VU = "VU"

    WF = "WF"

    WS = "WS"

    YE = "YE"

    YT = "YT"

    ZA = "ZA"

    ZM = "ZM"

    ZW = "ZW"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
