"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class CountriesAlphaCode3(object):
    """Implementation of the '__Countries_AlphaCode3' enum.

    3 Character symbol for country

    Attributes:
        AFG: The enum member of type str.
        ALB: The enum member of type str.
        ATA: The enum member of type str.
        DZA: The enum member of type str.
        ASM: The enum member of type str.
        AND: The enum member of type str.
        AGO: The enum member of type str.
        ATG: The enum member of type str.
        AZE: The enum member of type str.
        ARG: The enum member of type str.
        AUS: The enum member of type str.
        AUT: The enum member of type str.
        BHS: The enum member of type str.
        BHR: The enum member of type str.
        BGD: The enum member of type str.
        ARM: The enum member of type str.
        BRB: The enum member of type str.
        BEL: The enum member of type str.
        BMU: The enum member of type str.
        BTN: The enum member of type str.
        BOL: The enum member of type str.
        BIH: The enum member of type str.
        BWA: The enum member of type str.
        BVT: The enum member of type str.
        BRA: The enum member of type str.
        BLZ: The enum member of type str.
        IOT: The enum member of type str.
        SLB: The enum member of type str.
        VGB: The enum member of type str.
        BRN: The enum member of type str.
        BGR: The enum member of type str.
        MMR: The enum member of type str.
        BDI: The enum member of type str.
        BLR: The enum member of type str.
        KHM: The enum member of type str.
        CMR: The enum member of type str.
        CAN: The enum member of type str.
        CPV: The enum member of type str.
        CYM: The enum member of type str.
        CAF: The enum member of type str.
        LKA: The enum member of type str.
        TCD: The enum member of type str.
        CHL: The enum member of type str.
        CHN: The enum member of type str.
        TWN: The enum member of type str.
        CXR: The enum member of type str.
        CCK: The enum member of type str.
        COL: The enum member of type str.
        COM: The enum member of type str.
        MYT: The enum member of type str.
        COG: The enum member of type str.
        COD: The enum member of type str.
        COK: The enum member of type str.
        CRI: The enum member of type str.
        HRV: The enum member of type str.
        CUB: The enum member of type str.
        CYP: The enum member of type str.
        CZE: The enum member of type str.
        BEN: The enum member of type str.
        DNK: The enum member of type str.
        DMA: The enum member of type str.
        DOM: The enum member of type str.
        ECU: The enum member of type str.
        SLV: The enum member of type str.
        CIV: The enum member of type str.
        GNQ: The enum member of type str.
        ETH: The enum member of type str.
        ERI: The enum member of type str.
        EST: The enum member of type str.
        FRO: The enum member of type str.
        FLK: The enum member of type str.
        SGS: The enum member of type str.
        FJI: The enum member of type str.
        FIN: The enum member of type str.
        ALA: The enum member of type str.
        FRA: The enum member of type str.
        GUF: The enum member of type str.
        PYF: The enum member of type str.
        ATF: The enum member of type str.
        DJI: The enum member of type str.
        GAB: The enum member of type str.
        GEO: The enum member of type str.
        GMB: The enum member of type str.
        PSE: The enum member of type str.
        DEU: The enum member of type str.
        GHA: The enum member of type str.
        GIB: The enum member of type str.
        KIR: The enum member of type str.
        GRC: The enum member of type str.
        GRL: The enum member of type str.
        GRD: The enum member of type str.
        GLP: The enum member of type str.
        GUM: The enum member of type str.
        GTM: The enum member of type str.
        GIN: The enum member of type str.
        GUY: The enum member of type str.
        HTI: The enum member of type str.
        HMD: The enum member of type str.
        VAT: The enum member of type str.
        HND: The enum member of type str.
        HKG: The enum member of type str.
        HUN: The enum member of type str.
        ISL: The enum member of type str.
        IND: The enum member of type str.
        IDN: The enum member of type str.
        IRN: The enum member of type str.
        IRQ: The enum member of type str.
        IRL: The enum member of type str.
        ISR: The enum member of type str.
        ITA: The enum member of type str.
        JAM: The enum member of type str.
        JPN: The enum member of type str.
        KAZ: The enum member of type str.
        JOR: The enum member of type str.
        KEN: The enum member of type str.
        PRK: The enum member of type str.
        KOR: The enum member of type str.
        KWT: The enum member of type str.
        KGZ: The enum member of type str.
        LAO: The enum member of type str.
        LBN: The enum member of type str.
        LSO: The enum member of type str.
        LVA: The enum member of type str.
        LBR: The enum member of type str.
        LBY: The enum member of type str.
        LIE: The enum member of type str.
        LTU: The enum member of type str.
        LUX: The enum member of type str.
        MAC: The enum member of type str.
        MDG: The enum member of type str.
        MWI: The enum member of type str.
        MYS: The enum member of type str.
        MDV: The enum member of type str.
        MLI: The enum member of type str.
        MLT: The enum member of type str.
        MTQ: The enum member of type str.
        MRT: The enum member of type str.
        MUS: The enum member of type str.
        MEX: The enum member of type str.
        MCO: The enum member of type str.
        MNG: The enum member of type str.
        MDA: The enum member of type str.
        MNE: The enum member of type str.
        MSR: The enum member of type str.
        MAR: The enum member of type str.
        MOZ: The enum member of type str.
        OMN: The enum member of type str.
        NAM: The enum member of type str.
        NRU: The enum member of type str.
        NPL: The enum member of type str.
        NLD: The enum member of type str.
        ANT: The enum member of type str.
        CUW: The enum member of type str.
        ABW: The enum member of type str.
        SXM: The enum member of type str.
        BES: The enum member of type str.
        NCL: The enum member of type str.
        VUT: The enum member of type str.
        NZL: The enum member of type str.
        NIC: The enum member of type str.
        NER: The enum member of type str.
        NGA: The enum member of type str.
        NIU: The enum member of type str.
        NFK: The enum member of type str.
        NOR: The enum member of type str.
        MNP: The enum member of type str.
        UMI: The enum member of type str.
        FSM: The enum member of type str.
        MHL: The enum member of type str.
        PLW: The enum member of type str.
        PAK: The enum member of type str.
        PAN: The enum member of type str.
        PNG: The enum member of type str.
        PRY: The enum member of type str.
        PER: The enum member of type str.
        PHL: The enum member of type str.
        PCN: The enum member of type str.
        POL: The enum member of type str.
        PRT: The enum member of type str.
        GNB: The enum member of type str.
        TLS: The enum member of type str.
        PRI: The enum member of type str.
        QAT: The enum member of type str.
        REU: The enum member of type str.
        ROU: The enum member of type str.
        RUS: The enum member of type str.
        RWA: The enum member of type str.
        BLM: The enum member of type str.
        SHN: The enum member of type str.
        KNA: The enum member of type str.
        AIA: The enum member of type str.
        LCA: The enum member of type str.
        MAF: The enum member of type str.
        SPM: The enum member of type str.
        VCT: The enum member of type str.
        SMR: The enum member of type str.
        STP: The enum member of type str.
        SAU: The enum member of type str.
        SEN: The enum member of type str.
        SRB: The enum member of type str.
        SYC: The enum member of type str.
        SLE: The enum member of type str.
        SGP: The enum member of type str.
        SVK: The enum member of type str.
        VNM: The enum member of type str.
        SVN: The enum member of type str.
        SOM: The enum member of type str.
        ZAF: The enum member of type str.
        ZWE: The enum member of type str.
        ESP: The enum member of type str.
        SSD: The enum member of type str.
        ESH: The enum member of type str.
        SDN: The enum member of type str.
        SUR: The enum member of type str.
        SJM: The enum member of type str.
        SWZ: The enum member of type str.
        SWE: The enum member of type str.
        CHE: The enum member of type str.
        SYR: The enum member of type str.
        TJK: The enum member of type str.
        THA: The enum member of type str.
        TGO: The enum member of type str.
        TKL: The enum member of type str.
        TON: The enum member of type str.
        TTO: The enum member of type str.
        ARE: The enum member of type str.
        TUN: The enum member of type str.
        TUR: The enum member of type str.
        TKM: The enum member of type str.
        TCA: The enum member of type str.
        TUV: The enum member of type str.
        UGA: The enum member of type str.
        UKR: The enum member of type str.
        MKD: The enum member of type str.
        EGY: The enum member of type str.
        GBR: The enum member of type str.
        GGY: The enum member of type str.
        JEY: The enum member of type str.
        IMN: The enum member of type str.
        TZA: The enum member of type str.
        USA: The enum member of type str.
        VIR: The enum member of type str.
        BFA: The enum member of type str.
        URY: The enum member of type str.
        UZB: The enum member of type str.
        VEN: The enum member of type str.
        WLF: The enum member of type str.
        WSM: The enum member of type str.
        YEM: The enum member of type str.
        ZMB: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    AFG = "AFG"

    ALB = "ALB"

    ATA = "ATA"

    DZA = "DZA"

    ASM = "ASM"

    AND = "AND"

    AGO = "AGO"

    ATG = "ATG"

    AZE = "AZE"

    ARG = "ARG"

    AUS = "AUS"

    AUT = "AUT"

    BHS = "BHS"

    BHR = "BHR"

    BGD = "BGD"

    ARM = "ARM"

    BRB = "BRB"

    BEL = "BEL"

    BMU = "BMU"

    BTN = "BTN"

    BOL = "BOL"

    BIH = "BIH"

    BWA = "BWA"

    BVT = "BVT"

    BRA = "BRA"

    BLZ = "BLZ"

    IOT = "IOT"

    SLB = "SLB"

    VGB = "VGB"

    BRN = "BRN"

    BGR = "BGR"

    MMR = "MMR"

    BDI = "BDI"

    BLR = "BLR"

    KHM = "KHM"

    CMR = "CMR"

    CAN = "CAN"

    CPV = "CPV"

    CYM = "CYM"

    CAF = "CAF"

    LKA = "LKA"

    TCD = "TCD"

    CHL = "CHL"

    CHN = "CHN"

    TWN = "TWN"

    CXR = "CXR"

    CCK = "CCK"

    COL = "COL"

    COM = "COM"

    MYT = "MYT"

    COG = "COG"

    COD = "COD"

    COK = "COK"

    CRI = "CRI"

    HRV = "HRV"

    CUB = "CUB"

    CYP = "CYP"

    CZE = "CZE"

    BEN = "BEN"

    DNK = "DNK"

    DMA = "DMA"

    DOM = "DOM"

    ECU = "ECU"

    SLV = "SLV"

    CIV = "CIV"

    GNQ = "GNQ"

    ETH = "ETH"

    ERI = "ERI"

    EST = "EST"

    FRO = "FRO"

    FLK = "FLK"

    SGS = "SGS"

    FJI = "FJI"

    FIN = "FIN"

    ALA = "ALA"

    FRA = "FRA"

    GUF = "GUF"

    PYF = "PYF"

    ATF = "ATF"

    DJI = "DJI"

    GAB = "GAB"

    GEO = "GEO"

    GMB = "GMB"

    PSE = "PSE"

    DEU = "DEU"

    GHA = "GHA"

    GIB = "GIB"

    KIR = "KIR"

    GRC = "GRC"

    GRL = "GRL"

    GRD = "GRD"

    GLP = "GLP"

    GUM = "GUM"

    GTM = "GTM"

    GIN = "GIN"

    GUY = "GUY"

    HTI = "HTI"

    HMD = "HMD"

    VAT = "VAT"

    HND = "HND"

    HKG = "HKG"

    HUN = "HUN"

    ISL = "ISL"

    IND = "IND"

    IDN = "IDN"

    IRN = "IRN"

    IRQ = "IRQ"

    IRL = "IRL"

    ISR = "ISR"

    ITA = "ITA"

    JAM = "JAM"

    JPN = "JPN"

    KAZ = "KAZ"

    JOR = "JOR"

    KEN = "KEN"

    PRK = "PRK"

    KOR = "KOR"

    KWT = "KWT"

    KGZ = "KGZ"

    LAO = "LAO"

    LBN = "LBN"

    LSO = "LSO"

    LVA = "LVA"

    LBR = "LBR"

    LBY = "LBY"

    LIE = "LIE"

    LTU = "LTU"

    LUX = "LUX"

    MAC = "MAC"

    MDG = "MDG"

    MWI = "MWI"

    MYS = "MYS"

    MDV = "MDV"

    MLI = "MLI"

    MLT = "MLT"

    MTQ = "MTQ"

    MRT = "MRT"

    MUS = "MUS"

    MEX = "MEX"

    MCO = "MCO"

    MNG = "MNG"

    MDA = "MDA"

    MNE = "MNE"

    MSR = "MSR"

    MAR = "MAR"

    MOZ = "MOZ"

    OMN = "OMN"

    NAM = "NAM"

    NRU = "NRU"

    NPL = "NPL"

    NLD = "NLD"

    ANT = "ANT"

    CUW = "CUW"

    ABW = "ABW"

    SXM = "SXM"

    BES = "BES"

    NCL = "NCL"

    VUT = "VUT"

    NZL = "NZL"

    NIC = "NIC"

    NER = "NER"

    NGA = "NGA"

    NIU = "NIU"

    NFK = "NFK"

    NOR = "NOR"

    MNP = "MNP"

    UMI = "UMI"

    FSM = "FSM"

    MHL = "MHL"

    PLW = "PLW"

    PAK = "PAK"

    PAN = "PAN"

    PNG = "PNG"

    PRY = "PRY"

    PER = "PER"

    PHL = "PHL"

    PCN = "PCN"

    POL = "POL"

    PRT = "PRT"

    GNB = "GNB"

    TLS = "TLS"

    PRI = "PRI"

    QAT = "QAT"

    REU = "REU"

    ROU = "ROU"

    RUS = "RUS"

    RWA = "RWA"

    BLM = "BLM"

    SHN = "SHN"

    KNA = "KNA"

    AIA = "AIA"

    LCA = "LCA"

    MAF = "MAF"

    SPM = "SPM"

    VCT = "VCT"

    SMR = "SMR"

    STP = "STP"

    SAU = "SAU"

    SEN = "SEN"

    SRB = "SRB"

    SYC = "SYC"

    SLE = "SLE"

    SGP = "SGP"

    SVK = "SVK"

    VNM = "VNM"

    SVN = "SVN"

    SOM = "SOM"

    ZAF = "ZAF"

    ZWE = "ZWE"

    ESP = "ESP"

    SSD = "SSD"

    ESH = "ESH"

    SDN = "SDN"

    SUR = "SUR"

    SJM = "SJM"

    SWZ = "SWZ"

    SWE = "SWE"

    CHE = "CHE"

    SYR = "SYR"

    TJK = "TJK"

    THA = "THA"

    TGO = "TGO"

    TKL = "TKL"

    TON = "TON"

    TTO = "TTO"

    ARE = "ARE"

    TUN = "TUN"

    TUR = "TUR"

    TKM = "TKM"

    TCA = "TCA"

    TUV = "TUV"

    UGA = "UGA"

    UKR = "UKR"

    MKD = "MKD"

    EGY = "EGY"

    GBR = "GBR"

    GGY = "GGY"

    JEY = "JEY"

    IMN = "IMN"

    TZA = "TZA"

    USA = "USA"

    VIR = "VIR"

    BFA = "BFA"

    URY = "URY"

    UZB = "UZB"

    VEN = "VEN"

    WLF = "WLF"

    WSM = "WSM"

    YEM = "YEM"

    ZMB = "ZMB"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
