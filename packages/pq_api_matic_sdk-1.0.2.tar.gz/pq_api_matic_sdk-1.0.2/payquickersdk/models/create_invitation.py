"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class CreateInvitation(object):
    """Implementation of the '_CreateInvitation' model.

    Attributes:
        currency (Currencies): [Currency code type](#/rest/models/structures/country)
            for the object
        program_user_id (str): [Program
            identifier](#/rest/models/structures/program-user-id) for the user
        email (str): Contact [email address](#/rest/models/structures/email-address)
            for the user account for the user account
        first_name (str): First name
        last_name (str): Last name
        date_of_birth (datetime): The model property of type datetime.
        tax_resident_status (TaxResidentStatuses): Tax [resident status
            type](#/rest/models/structures/tax-resident-status)
        phone_number (str): The model property of type str.
        mobile_number (str): The model property of type str.
        phone_number_country (Countries): Throughout the PayQuicker API, the usage of
            the 2-letter alpha code is used in place of the country name, e.g., for
            bank country or residential country.  The 2-letter codes adhere to the
            ISO 3166-1 spec and are listed here for convenience.
        mobile_number_country (Countries): Throughout the PayQuicker API, the usage
            of the 2-letter alpha code is used in place of the country name, e.g.,
            for bank country or residential country.  The 2-letter codes adhere to
            the ISO 3166-1 spec and are listed here for convenience.
        address_line_1 (str): Address Line 1
        address_line_2 (str): The model property of type str.
        address_line_3 (str): The model property of type str.
        city (str): The model property of type str.
        region (str): The model property of type str.
        country (Countries): Throughout the PayQuicker API, the usage of the 2-letter
            alpha code is used in place of the country name, e.g., for bank country
            or residential country.  The 2-letter codes adhere to the ISO 3166-1 spec
            and are listed here for convenience.
        postal_code (str): The model property of type str.
        gender (Genders): [Gender](#/rest/models/structures/gender) as a user
            identifies
        user_type (UserTypes): Account holder's profile
            [type](#/rest/models/structures/user-type)
        language (Languages): The [Language](#/rest/models/structures/language) type
            in IETF's BCP 47 format
        country_of_birth (Countries): Throughout the PayQuicker API, the usage of the
            2-letter alpha code is used in place of the country name, e.g., for bank
            country or residential country.  The 2-letter codes adhere to the ISO
            3166-1 spec and are listed here for convenience.
        country_of_nationality (Countries): Throughout the PayQuicker API, the usage
            of the 2-letter alpha code is used in place of the country name, e.g.,
            for bank country or residential country.  The 2-letter codes adhere to
            the ISO 3166-1 spec and are listed here for convenience.
        business_contact_role (BusinessContactRoles): Business contact role
        government_id_type (GovernmentIds): Indicates the type of ID submitted for
            user verification purposes.
        government_id (str): The model property of type str.
        occupation_title (str): The model property of type str.
        occupation_type (Occupations): [Type of
            occupation](#/rest/models/structures/occupation) for the user
        mailing_address_line_1 (str): The model property of type str.
        mailing_address_line_2 (str): The model property of type str.
        mailing_address_line_3 (str): The model property of type str.
        mailing_country (Countries): Throughout the PayQuicker API, the usage of the
            2-letter alpha code is used in place of the country name, e.g., for bank
            country or residential country.  The 2-letter codes adhere to the ISO
            3166-1 spec and are listed here for convenience.
        mailing_city (str): The model property of type str.
        mailing_region (str): The model property of type str.
        mailing_postal_code (str): The model property of type str.
        business_address_line_1 (str): Business address line 1
        business_address_line_2 (str): Business address line 2
        business_address_line_3 (str): Business address line 3
        business_country (Countries): Throughout the PayQuicker API, the usage of the
            2-letter alpha code is used in place of the country name, e.g., for bank
            country or residential country.  The 2-letter codes adhere to the ISO
            3166-1 spec and are listed here for convenience.
        business_city (str): Business city
        business_region (str): Region that the business is based out of
        business_postal_code (str): The model property of type str.
        premise_number (str): The model property of type str.
        program_token (str): Auto-generated unique identifier representing a program,
            prefixed with prog-
        primary_user_token (str): Auto-generated unique identifier representing a
            user, prefixed with `user-`.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "currency": "currency",
        "program_user_id": "programUserId",
        "email": "email",
        "first_name": "firstName",
        "last_name": "lastName",
        "date_of_birth": "dateOfBirth",
        "tax_resident_status": "taxResidentStatus",
        "phone_number": "phoneNumber",
        "mobile_number": "mobileNumber",
        "phone_number_country": "phoneNumberCountry",
        "mobile_number_country": "mobileNumberCountry",
        "address_line_1": "addressLine1",
        "address_line_2": "addressLine2",
        "address_line_3": "addressLine3",
        "city": "city",
        "region": "region",
        "country": "country",
        "postal_code": "postalCode",
        "gender": "gender",
        "user_type": "userType",
        "language": "language",
        "country_of_birth": "countryOfBirth",
        "country_of_nationality": "countryOfNationality",
        "business_contact_role": "businessContactRole",
        "government_id_type": "governmentIdType",
        "government_id": "governmentId",
        "occupation_title": "occupationTitle",
        "occupation_type": "occupationType",
        "mailing_address_line_1": "mailingAddressLine1",
        "mailing_address_line_2": "mailingAddressLine2",
        "mailing_address_line_3": "mailingAddressLine3",
        "mailing_country": "mailingCountry",
        "mailing_city": "mailingCity",
        "mailing_region": "mailingRegion",
        "mailing_postal_code": "mailingPostalCode",
        "business_address_line_1": "businessAddressLine1",
        "business_address_line_2": "businessAddressLine2",
        "business_address_line_3": "businessAddressLine3",
        "business_country": "businessCountry",
        "business_city": "businessCity",
        "business_region": "businessRegion",
        "business_postal_code": "businessPostalCode",
        "premise_number": "premiseNumber",
        "program_token": "programToken",
        "primary_user_token": "primaryUserToken",
    }

    _optionals = [
        "currency",
        "program_user_id",
        "email",
        "first_name",
        "last_name",
        "date_of_birth",
        "tax_resident_status",
        "phone_number",
        "mobile_number",
        "phone_number_country",
        "mobile_number_country",
        "address_line_1",
        "address_line_2",
        "address_line_3",
        "city",
        "region",
        "country",
        "postal_code",
        "gender",
        "user_type",
        "language",
        "country_of_birth",
        "country_of_nationality",
        "business_contact_role",
        "government_id_type",
        "government_id",
        "occupation_title",
        "occupation_type",
        "mailing_address_line_1",
        "mailing_address_line_2",
        "mailing_address_line_3",
        "mailing_country",
        "mailing_city",
        "mailing_region",
        "mailing_postal_code",
        "business_address_line_1",
        "business_address_line_2",
        "business_address_line_3",
        "business_country",
        "business_city",
        "business_region",
        "business_postal_code",
        "premise_number",
        "program_token",
        "primary_user_token",
    ]

    def __init__(
        self,
        currency="USD",
        program_user_id=APIHelper.SKIP,
        email=APIHelper.SKIP,
        first_name=APIHelper.SKIP,
        last_name=APIHelper.SKIP,
        date_of_birth=APIHelper.SKIP,
        tax_resident_status=APIHelper.SKIP,
        phone_number=APIHelper.SKIP,
        mobile_number=APIHelper.SKIP,
        phone_number_country=APIHelper.SKIP,
        mobile_number_country=APIHelper.SKIP,
        address_line_1=APIHelper.SKIP,
        address_line_2=APIHelper.SKIP,
        address_line_3=APIHelper.SKIP,
        city=APIHelper.SKIP,
        region=APIHelper.SKIP,
        country=APIHelper.SKIP,
        postal_code=APIHelper.SKIP,
        gender=APIHelper.SKIP,
        user_type=APIHelper.SKIP,
        language=APIHelper.SKIP,
        country_of_birth=APIHelper.SKIP,
        country_of_nationality=APIHelper.SKIP,
        business_contact_role=APIHelper.SKIP,
        government_id_type=APIHelper.SKIP,
        government_id=APIHelper.SKIP,
        occupation_title=APIHelper.SKIP,
        occupation_type=APIHelper.SKIP,
        mailing_address_line_1=APIHelper.SKIP,
        mailing_address_line_2=APIHelper.SKIP,
        mailing_address_line_3=APIHelper.SKIP,
        mailing_country=APIHelper.SKIP,
        mailing_city=APIHelper.SKIP,
        mailing_region=APIHelper.SKIP,
        mailing_postal_code=APIHelper.SKIP,
        business_address_line_1=APIHelper.SKIP,
        business_address_line_2=APIHelper.SKIP,
        business_address_line_3=APIHelper.SKIP,
        business_country=APIHelper.SKIP,
        business_city=APIHelper.SKIP,
        business_region=APIHelper.SKIP,
        business_postal_code=APIHelper.SKIP,
        premise_number=APIHelper.SKIP,
        program_token=APIHelper.SKIP,
        primary_user_token=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a CreateInvitation instance."""
        # Initialize members of the class
        self.currency = currency
        if program_user_id is not APIHelper.SKIP:
            self.program_user_id = program_user_id
        if email is not APIHelper.SKIP:
            self.email = email
        if first_name is not APIHelper.SKIP:
            self.first_name = first_name
        if last_name is not APIHelper.SKIP:
            self.last_name = last_name
        if date_of_birth is not APIHelper.SKIP:
            self.date_of_birth =\
                 APIHelper.apply_datetime_converter(
                date_of_birth, APIHelper.RFC3339DateTime)\
                 if date_of_birth else None
        if tax_resident_status is not APIHelper.SKIP:
            self.tax_resident_status = tax_resident_status
        if phone_number is not APIHelper.SKIP:
            self.phone_number = phone_number
        if mobile_number is not APIHelper.SKIP:
            self.mobile_number = mobile_number
        if phone_number_country is not APIHelper.SKIP:
            self.phone_number_country = phone_number_country
        if mobile_number_country is not APIHelper.SKIP:
            self.mobile_number_country = mobile_number_country
        if address_line_1 is not APIHelper.SKIP:
            self.address_line_1 = address_line_1
        if address_line_2 is not APIHelper.SKIP:
            self.address_line_2 = address_line_2
        if address_line_3 is not APIHelper.SKIP:
            self.address_line_3 = address_line_3
        if city is not APIHelper.SKIP:
            self.city = city
        if region is not APIHelper.SKIP:
            self.region = region
        if country is not APIHelper.SKIP:
            self.country = country
        if postal_code is not APIHelper.SKIP:
            self.postal_code = postal_code
        if gender is not APIHelper.SKIP:
            self.gender = gender
        if user_type is not APIHelper.SKIP:
            self.user_type = user_type
        if language is not APIHelper.SKIP:
            self.language = language
        if country_of_birth is not APIHelper.SKIP:
            self.country_of_birth = country_of_birth
        if country_of_nationality is not APIHelper.SKIP:
            self.country_of_nationality = country_of_nationality
        if business_contact_role is not APIHelper.SKIP:
            self.business_contact_role = business_contact_role
        if government_id_type is not APIHelper.SKIP:
            self.government_id_type = government_id_type
        if government_id is not APIHelper.SKIP:
            self.government_id = government_id
        if occupation_title is not APIHelper.SKIP:
            self.occupation_title = occupation_title
        if occupation_type is not APIHelper.SKIP:
            self.occupation_type = occupation_type
        if mailing_address_line_1 is not APIHelper.SKIP:
            self.mailing_address_line_1 = mailing_address_line_1
        if mailing_address_line_2 is not APIHelper.SKIP:
            self.mailing_address_line_2 = mailing_address_line_2
        if mailing_address_line_3 is not APIHelper.SKIP:
            self.mailing_address_line_3 = mailing_address_line_3
        if mailing_country is not APIHelper.SKIP:
            self.mailing_country = mailing_country
        if mailing_city is not APIHelper.SKIP:
            self.mailing_city = mailing_city
        if mailing_region is not APIHelper.SKIP:
            self.mailing_region = mailing_region
        if mailing_postal_code is not APIHelper.SKIP:
            self.mailing_postal_code = mailing_postal_code
        if business_address_line_1 is not APIHelper.SKIP:
            self.business_address_line_1 = business_address_line_1
        if business_address_line_2 is not APIHelper.SKIP:
            self.business_address_line_2 = business_address_line_2
        if business_address_line_3 is not APIHelper.SKIP:
            self.business_address_line_3 = business_address_line_3
        if business_country is not APIHelper.SKIP:
            self.business_country = business_country
        if business_city is not APIHelper.SKIP:
            self.business_city = business_city
        if business_region is not APIHelper.SKIP:
            self.business_region = business_region
        if business_postal_code is not APIHelper.SKIP:
            self.business_postal_code = business_postal_code
        if premise_number is not APIHelper.SKIP:
            self.premise_number = premise_number
        if program_token is not APIHelper.SKIP:
            self.program_token = program_token
        if primary_user_token is not APIHelper.SKIP:
            self.primary_user_token = primary_user_token

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        currency =\
            dictionary.get("currency")\
            if dictionary.get("currency")\
                else "USD"
        program_user_id =\
            dictionary.get("programUserId")\
            if dictionary.get("programUserId")\
                else APIHelper.SKIP
        email =\
            dictionary.get("email")\
            if dictionary.get("email")\
                else APIHelper.SKIP
        first_name =\
            dictionary.get("firstName")\
            if dictionary.get("firstName")\
                else APIHelper.SKIP
        last_name =\
            dictionary.get("lastName")\
            if dictionary.get("lastName")\
                else APIHelper.SKIP
        date_of_birth = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("dateOfBirth")).datetime\
            if dictionary.get("dateOfBirth") else APIHelper.SKIP
        tax_resident_status =\
            dictionary.get("taxResidentStatus")\
            if dictionary.get("taxResidentStatus")\
                else APIHelper.SKIP
        phone_number =\
            dictionary.get("phoneNumber")\
            if dictionary.get("phoneNumber")\
                else APIHelper.SKIP
        mobile_number =\
            dictionary.get("mobileNumber")\
            if dictionary.get("mobileNumber")\
                else APIHelper.SKIP
        phone_number_country =\
            dictionary.get("phoneNumberCountry")\
            if dictionary.get("phoneNumberCountry")\
                else APIHelper.SKIP
        mobile_number_country =\
            dictionary.get("mobileNumberCountry")\
            if dictionary.get("mobileNumberCountry")\
                else APIHelper.SKIP
        address_line_1 =\
            dictionary.get("addressLine1")\
            if dictionary.get("addressLine1")\
                else APIHelper.SKIP
        address_line_2 =\
            dictionary.get("addressLine2")\
            if dictionary.get("addressLine2")\
                else APIHelper.SKIP
        address_line_3 =\
            dictionary.get("addressLine3")\
            if dictionary.get("addressLine3")\
                else APIHelper.SKIP
        city =\
            dictionary.get("city")\
            if dictionary.get("city")\
                else APIHelper.SKIP
        region =\
            dictionary.get("region")\
            if dictionary.get("region")\
                else APIHelper.SKIP
        country =\
            dictionary.get("country")\
            if dictionary.get("country")\
                else APIHelper.SKIP
        postal_code =\
            dictionary.get("postalCode")\
            if dictionary.get("postalCode")\
                else APIHelper.SKIP
        gender =\
            dictionary.get("gender")\
            if dictionary.get("gender")\
                else APIHelper.SKIP
        user_type =\
            dictionary.get("userType")\
            if dictionary.get("userType")\
                else APIHelper.SKIP
        language =\
            dictionary.get("language")\
            if dictionary.get("language")\
                else APIHelper.SKIP
        country_of_birth =\
            dictionary.get("countryOfBirth")\
            if dictionary.get("countryOfBirth")\
                else APIHelper.SKIP
        country_of_nationality =\
            dictionary.get("countryOfNationality")\
            if dictionary.get("countryOfNationality")\
                else APIHelper.SKIP
        business_contact_role =\
            dictionary.get("businessContactRole")\
            if dictionary.get("businessContactRole")\
                else APIHelper.SKIP
        government_id_type =\
            dictionary.get("governmentIdType")\
            if dictionary.get("governmentIdType")\
                else APIHelper.SKIP
        government_id =\
            dictionary.get("governmentId")\
            if dictionary.get("governmentId")\
                else APIHelper.SKIP
        occupation_title =\
            dictionary.get("occupationTitle")\
            if dictionary.get("occupationTitle")\
                else APIHelper.SKIP
        occupation_type =\
            dictionary.get("occupationType")\
            if dictionary.get("occupationType")\
                else APIHelper.SKIP
        mailing_address_line_1 =\
            dictionary.get("mailingAddressLine1")\
            if dictionary.get("mailingAddressLine1")\
                else APIHelper.SKIP
        mailing_address_line_2 =\
            dictionary.get("mailingAddressLine2")\
            if dictionary.get("mailingAddressLine2")\
                else APIHelper.SKIP
        mailing_address_line_3 =\
            dictionary.get("mailingAddressLine3")\
            if dictionary.get("mailingAddressLine3")\
                else APIHelper.SKIP
        mailing_country =\
            dictionary.get("mailingCountry")\
            if dictionary.get("mailingCountry")\
                else APIHelper.SKIP
        mailing_city =\
            dictionary.get("mailingCity")\
            if dictionary.get("mailingCity")\
                else APIHelper.SKIP
        mailing_region =\
            dictionary.get("mailingRegion")\
            if dictionary.get("mailingRegion")\
                else APIHelper.SKIP
        mailing_postal_code =\
            dictionary.get("mailingPostalCode")\
            if dictionary.get("mailingPostalCode")\
                else APIHelper.SKIP
        business_address_line_1 =\
            dictionary.get("businessAddressLine1")\
            if dictionary.get("businessAddressLine1")\
                else APIHelper.SKIP
        business_address_line_2 =\
            dictionary.get("businessAddressLine2")\
            if dictionary.get("businessAddressLine2")\
                else APIHelper.SKIP
        business_address_line_3 =\
            dictionary.get("businessAddressLine3")\
            if dictionary.get("businessAddressLine3")\
                else APIHelper.SKIP
        business_country =\
            dictionary.get("businessCountry")\
            if dictionary.get("businessCountry")\
                else APIHelper.SKIP
        business_city =\
            dictionary.get("businessCity")\
            if dictionary.get("businessCity")\
                else APIHelper.SKIP
        business_region =\
            dictionary.get("businessRegion")\
            if dictionary.get("businessRegion")\
                else APIHelper.SKIP
        business_postal_code =\
            dictionary.get("businessPostalCode")\
            if dictionary.get("businessPostalCode")\
                else APIHelper.SKIP
        premise_number =\
            dictionary.get("premiseNumber")\
            if dictionary.get("premiseNumber")\
                else APIHelper.SKIP
        program_token =\
            dictionary.get("programToken")\
            if dictionary.get("programToken")\
                else APIHelper.SKIP
        primary_user_token =\
            dictionary.get("primaryUserToken")\
            if dictionary.get("primaryUserToken")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(currency,
                   program_user_id,
                   email,
                   first_name,
                   last_name,
                   date_of_birth,
                   tax_resident_status,
                   phone_number,
                   mobile_number,
                   phone_number_country,
                   mobile_number_country,
                   address_line_1,
                   address_line_2,
                   address_line_3,
                   city,
                   region,
                   country,
                   postal_code,
                   gender,
                   user_type,
                   language,
                   country_of_birth,
                   country_of_nationality,
                   business_contact_role,
                   government_id_type,
                   government_id,
                   occupation_title,
                   occupation_type,
                   mailing_address_line_1,
                   mailing_address_line_2,
                   mailing_address_line_3,
                   mailing_country,
                   mailing_city,
                   mailing_region,
                   mailing_postal_code,
                   business_address_line_1,
                   business_address_line_2,
                   business_address_line_3,
                   business_country,
                   business_city,
                   business_region,
                   business_postal_code,
                   premise_number,
                   program_token,
                   primary_user_token,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _program_user_id=(
            self.program_user_id
            if hasattr(self, "program_user_id")
            else None
        )
        _email=(
            self.email
            if hasattr(self, "email")
            else None
        )
        _first_name=(
            self.first_name
            if hasattr(self, "first_name")
            else None
        )
        _last_name=(
            self.last_name
            if hasattr(self, "last_name")
            else None
        )
        _date_of_birth=(
            self.date_of_birth
            if hasattr(self, "date_of_birth")
            else None
        )
        _tax_resident_status=(
            self.tax_resident_status
            if hasattr(self, "tax_resident_status")
            else None
        )
        _phone_number=(
            self.phone_number
            if hasattr(self, "phone_number")
            else None
        )
        _mobile_number=(
            self.mobile_number
            if hasattr(self, "mobile_number")
            else None
        )
        _phone_number_country=(
            self.phone_number_country
            if hasattr(self, "phone_number_country")
            else None
        )
        _mobile_number_country=(
            self.mobile_number_country
            if hasattr(self, "mobile_number_country")
            else None
        )
        _address_line_1=(
            self.address_line_1
            if hasattr(self, "address_line_1")
            else None
        )
        _address_line_2=(
            self.address_line_2
            if hasattr(self, "address_line_2")
            else None
        )
        _address_line_3=(
            self.address_line_3
            if hasattr(self, "address_line_3")
            else None
        )
        _city=(
            self.city
            if hasattr(self, "city")
            else None
        )
        _region=(
            self.region
            if hasattr(self, "region")
            else None
        )
        _country=(
            self.country
            if hasattr(self, "country")
            else None
        )
        _postal_code=(
            self.postal_code
            if hasattr(self, "postal_code")
            else None
        )
        _gender=(
            self.gender
            if hasattr(self, "gender")
            else None
        )
        _user_type=(
            self.user_type
            if hasattr(self, "user_type")
            else None
        )
        _language=(
            self.language
            if hasattr(self, "language")
            else None
        )
        _country_of_birth=(
            self.country_of_birth
            if hasattr(self, "country_of_birth")
            else None
        )
        _country_of_nationality=(
            self.country_of_nationality
            if hasattr(self, "country_of_nationality")
            else None
        )
        _business_contact_role=(
            self.business_contact_role
            if hasattr(self, "business_contact_role")
            else None
        )
        _government_id_type=(
            self.government_id_type
            if hasattr(self, "government_id_type")
            else None
        )
        _government_id=(
            self.government_id
            if hasattr(self, "government_id")
            else None
        )
        _occupation_title=(
            self.occupation_title
            if hasattr(self, "occupation_title")
            else None
        )
        _occupation_type=(
            self.occupation_type
            if hasattr(self, "occupation_type")
            else None
        )
        _mailing_address_line_1=(
            self.mailing_address_line_1
            if hasattr(self, "mailing_address_line_1")
            else None
        )
        _mailing_address_line_2=(
            self.mailing_address_line_2
            if hasattr(self, "mailing_address_line_2")
            else None
        )
        _mailing_address_line_3=(
            self.mailing_address_line_3
            if hasattr(self, "mailing_address_line_3")
            else None
        )
        _mailing_country=(
            self.mailing_country
            if hasattr(self, "mailing_country")
            else None
        )
        _mailing_city=(
            self.mailing_city
            if hasattr(self, "mailing_city")
            else None
        )
        _mailing_region=(
            self.mailing_region
            if hasattr(self, "mailing_region")
            else None
        )
        _mailing_postal_code=(
            self.mailing_postal_code
            if hasattr(self, "mailing_postal_code")
            else None
        )
        _business_address_line_1=(
            self.business_address_line_1
            if hasattr(self, "business_address_line_1")
            else None
        )
        _business_address_line_2=(
            self.business_address_line_2
            if hasattr(self, "business_address_line_2")
            else None
        )
        _business_address_line_3=(
            self.business_address_line_3
            if hasattr(self, "business_address_line_3")
            else None
        )
        _business_country=(
            self.business_country
            if hasattr(self, "business_country")
            else None
        )
        _business_city=(
            self.business_city
            if hasattr(self, "business_city")
            else None
        )
        _business_region=(
            self.business_region
            if hasattr(self, "business_region")
            else None
        )
        _business_postal_code=(
            self.business_postal_code
            if hasattr(self, "business_postal_code")
            else None
        )
        _premise_number=(
            self.premise_number
            if hasattr(self, "premise_number")
            else None
        )
        _program_token=(
            self.program_token
            if hasattr(self, "program_token")
            else None
        )
        _primary_user_token=(
            self.primary_user_token
            if hasattr(self, "primary_user_token")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"currency={_currency!r}, "
            f"program_user_id={_program_user_id!r}, "
            f"email={_email!r}, "
            f"first_name={_first_name!r}, "
            f"last_name={_last_name!r}, "
            f"date_of_birth={_date_of_birth!r}, "
            f"tax_resident_status={_tax_resident_status!r}, "
            f"phone_number={_phone_number!r}, "
            f"mobile_number={_mobile_number!r}, "
            f"phone_number_country={_phone_number_country!r}, "
            f"mobile_number_country={_mobile_number_country!r}, "
            f"address_line_1={_address_line_1!r}, "
            f"address_line_2={_address_line_2!r}, "
            f"address_line_3={_address_line_3!r}, "
            f"city={_city!r}, "
            f"region={_region!r}, "
            f"country={_country!r}, "
            f"postal_code={_postal_code!r}, "
            f"gender={_gender!r}, "
            f"user_type={_user_type!r}, "
            f"language={_language!r}, "
            f"country_of_birth={_country_of_birth!r}, "
            f"country_of_nationality={_country_of_nationality!r}, "
            f"business_contact_role={_business_contact_role!r}, "
            f"government_id_type={_government_id_type!r}, "
            f"government_id={_government_id!r}, "
            f"occupation_title={_occupation_title!r}, "
            f"occupation_type={_occupation_type!r}, "
            f"mailing_address_line_1={_mailing_address_line_1!r}, "
            f"mailing_address_line_2={_mailing_address_line_2!r}, "
            f"mailing_address_line_3={_mailing_address_line_3!r}, "
            f"mailing_country={_mailing_country!r}, "
            f"mailing_city={_mailing_city!r}, "
            f"mailing_region={_mailing_region!r}, "
            f"mailing_postal_code={_mailing_postal_code!r}, "
            f"business_address_line_1={_business_address_line_1!r}, "
            f"business_address_line_2={_business_address_line_2!r}, "
            f"business_address_line_3={_business_address_line_3!r}, "
            f"business_country={_business_country!r}, "
            f"business_city={_business_city!r}, "
            f"business_region={_business_region!r}, "
            f"business_postal_code={_business_postal_code!r}, "
            f"premise_number={_premise_number!r}, "
            f"program_token={_program_token!r}, "
            f"primary_user_token={_primary_user_token!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _program_user_id=(
            self.program_user_id
            if hasattr(self, "program_user_id")
            else None
        )
        _email=(
            self.email
            if hasattr(self, "email")
            else None
        )
        _first_name=(
            self.first_name
            if hasattr(self, "first_name")
            else None
        )
        _last_name=(
            self.last_name
            if hasattr(self, "last_name")
            else None
        )
        _date_of_birth=(
            self.date_of_birth
            if hasattr(self, "date_of_birth")
            else None
        )
        _tax_resident_status=(
            self.tax_resident_status
            if hasattr(self, "tax_resident_status")
            else None
        )
        _phone_number=(
            self.phone_number
            if hasattr(self, "phone_number")
            else None
        )
        _mobile_number=(
            self.mobile_number
            if hasattr(self, "mobile_number")
            else None
        )
        _phone_number_country=(
            self.phone_number_country
            if hasattr(self, "phone_number_country")
            else None
        )
        _mobile_number_country=(
            self.mobile_number_country
            if hasattr(self, "mobile_number_country")
            else None
        )
        _address_line_1=(
            self.address_line_1
            if hasattr(self, "address_line_1")
            else None
        )
        _address_line_2=(
            self.address_line_2
            if hasattr(self, "address_line_2")
            else None
        )
        _address_line_3=(
            self.address_line_3
            if hasattr(self, "address_line_3")
            else None
        )
        _city=(
            self.city
            if hasattr(self, "city")
            else None
        )
        _region=(
            self.region
            if hasattr(self, "region")
            else None
        )
        _country=(
            self.country
            if hasattr(self, "country")
            else None
        )
        _postal_code=(
            self.postal_code
            if hasattr(self, "postal_code")
            else None
        )
        _gender=(
            self.gender
            if hasattr(self, "gender")
            else None
        )
        _user_type=(
            self.user_type
            if hasattr(self, "user_type")
            else None
        )
        _language=(
            self.language
            if hasattr(self, "language")
            else None
        )
        _country_of_birth=(
            self.country_of_birth
            if hasattr(self, "country_of_birth")
            else None
        )
        _country_of_nationality=(
            self.country_of_nationality
            if hasattr(self, "country_of_nationality")
            else None
        )
        _business_contact_role=(
            self.business_contact_role
            if hasattr(self, "business_contact_role")
            else None
        )
        _government_id_type=(
            self.government_id_type
            if hasattr(self, "government_id_type")
            else None
        )
        _government_id=(
            self.government_id
            if hasattr(self, "government_id")
            else None
        )
        _occupation_title=(
            self.occupation_title
            if hasattr(self, "occupation_title")
            else None
        )
        _occupation_type=(
            self.occupation_type
            if hasattr(self, "occupation_type")
            else None
        )
        _mailing_address_line_1=(
            self.mailing_address_line_1
            if hasattr(self, "mailing_address_line_1")
            else None
        )
        _mailing_address_line_2=(
            self.mailing_address_line_2
            if hasattr(self, "mailing_address_line_2")
            else None
        )
        _mailing_address_line_3=(
            self.mailing_address_line_3
            if hasattr(self, "mailing_address_line_3")
            else None
        )
        _mailing_country=(
            self.mailing_country
            if hasattr(self, "mailing_country")
            else None
        )
        _mailing_city=(
            self.mailing_city
            if hasattr(self, "mailing_city")
            else None
        )
        _mailing_region=(
            self.mailing_region
            if hasattr(self, "mailing_region")
            else None
        )
        _mailing_postal_code=(
            self.mailing_postal_code
            if hasattr(self, "mailing_postal_code")
            else None
        )
        _business_address_line_1=(
            self.business_address_line_1
            if hasattr(self, "business_address_line_1")
            else None
        )
        _business_address_line_2=(
            self.business_address_line_2
            if hasattr(self, "business_address_line_2")
            else None
        )
        _business_address_line_3=(
            self.business_address_line_3
            if hasattr(self, "business_address_line_3")
            else None
        )
        _business_country=(
            self.business_country
            if hasattr(self, "business_country")
            else None
        )
        _business_city=(
            self.business_city
            if hasattr(self, "business_city")
            else None
        )
        _business_region=(
            self.business_region
            if hasattr(self, "business_region")
            else None
        )
        _business_postal_code=(
            self.business_postal_code
            if hasattr(self, "business_postal_code")
            else None
        )
        _premise_number=(
            self.premise_number
            if hasattr(self, "premise_number")
            else None
        )
        _program_token=(
            self.program_token
            if hasattr(self, "program_token")
            else None
        )
        _primary_user_token=(
            self.primary_user_token
            if hasattr(self, "primary_user_token")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"currency={_currency!s}, "
            f"program_user_id={_program_user_id!s}, "
            f"email={_email!s}, "
            f"first_name={_first_name!s}, "
            f"last_name={_last_name!s}, "
            f"date_of_birth={_date_of_birth!s}, "
            f"tax_resident_status={_tax_resident_status!s}, "
            f"phone_number={_phone_number!s}, "
            f"mobile_number={_mobile_number!s}, "
            f"phone_number_country={_phone_number_country!s}, "
            f"mobile_number_country={_mobile_number_country!s}, "
            f"address_line_1={_address_line_1!s}, "
            f"address_line_2={_address_line_2!s}, "
            f"address_line_3={_address_line_3!s}, "
            f"city={_city!s}, "
            f"region={_region!s}, "
            f"country={_country!s}, "
            f"postal_code={_postal_code!s}, "
            f"gender={_gender!s}, "
            f"user_type={_user_type!s}, "
            f"language={_language!s}, "
            f"country_of_birth={_country_of_birth!s}, "
            f"country_of_nationality={_country_of_nationality!s}, "
            f"business_contact_role={_business_contact_role!s}, "
            f"government_id_type={_government_id_type!s}, "
            f"government_id={_government_id!s}, "
            f"occupation_title={_occupation_title!s}, "
            f"occupation_type={_occupation_type!s}, "
            f"mailing_address_line_1={_mailing_address_line_1!s}, "
            f"mailing_address_line_2={_mailing_address_line_2!s}, "
            f"mailing_address_line_3={_mailing_address_line_3!s}, "
            f"mailing_country={_mailing_country!s}, "
            f"mailing_city={_mailing_city!s}, "
            f"mailing_region={_mailing_region!s}, "
            f"mailing_postal_code={_mailing_postal_code!s}, "
            f"business_address_line_1={_business_address_line_1!s}, "
            f"business_address_line_2={_business_address_line_2!s}, "
            f"business_address_line_3={_business_address_line_3!s}, "
            f"business_country={_business_country!s}, "
            f"business_city={_business_city!s}, "
            f"business_region={_business_region!s}, "
            f"business_postal_code={_business_postal_code!s}, "
            f"premise_number={_premise_number!s}, "
            f"program_token={_program_token!s}, "
            f"primary_user_token={_primary_user_token!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
