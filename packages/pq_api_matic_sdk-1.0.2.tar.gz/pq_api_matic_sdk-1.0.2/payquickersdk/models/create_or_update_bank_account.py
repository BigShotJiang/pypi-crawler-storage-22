"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.bank_account_address import (
    BankAccountAddress,
)
from payquickersdk.models.bank_account_field import (
    BankAccountField,
)


class CreateOrUpdateBankAccount(object):
    """Implementation of the '_CreateOrUpdateBankAccount' model.

    Attributes:
        bank_account_ownership_type (BankAccountOwnership): Account [ownership
            types](#/rest/models/structures/bank-account-ownership)
        bank_country (Countries): Throughout the PayQuicker API, the usage of the
            2-letter alpha code is used in place of the country name, e.g., for bank
            country or residential country.  The 2-letter codes adhere to the ISO
            3166-1 spec and are listed here for convenience.
        bank_currency (Currencies): [Currency code
            type](#/rest/models/structures/country) for the object
        description (str): User-supplied description of the bank account for reference
        fields (List[BankAccountField]): The model property of type
            List[BankAccountField].
        mtype (BankAccountTypes): Financial purpose of the [bank
            account](#/rest/models/structures/bank-account-type)
        transfer_method_type (TransferMethodTypes): Optional transfer methods
            applicable only to bank and e-wallet transfers.
        address (BankAccountAddress): The model property of type BankAccountAddress.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "bank_account_ownership_type": "bankAccountOwnershipType",
        "bank_country": "bankCountry",
        "bank_currency": "bankCurrency",
        "description": "description",
        "fields": "fields",
        "mtype": "type",
        "transfer_method_type": "transferMethodType",
        "address": "address",
    }

    _optionals = [
        "bank_account_ownership_type",
        "bank_country",
        "bank_currency",
        "description",
        "fields",
        "mtype",
        "transfer_method_type",
        "address",
    ]

    def __init__(
        self,
        bank_account_ownership_type=APIHelper.SKIP,
        bank_country=APIHelper.SKIP,
        bank_currency="USD",
        description=APIHelper.SKIP,
        fields=APIHelper.SKIP,
        mtype=APIHelper.SKIP,
        transfer_method_type=APIHelper.SKIP,
        address=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a CreateOrUpdateBankAccount instance."""
        # Initialize members of the class
        if bank_account_ownership_type is not APIHelper.SKIP:
            self.bank_account_ownership_type = bank_account_ownership_type
        if bank_country is not APIHelper.SKIP:
            self.bank_country = bank_country
        self.bank_currency = bank_currency
        if description is not APIHelper.SKIP:
            self.description = description
        if fields is not APIHelper.SKIP:
            self.fields = fields
        if mtype is not APIHelper.SKIP:
            self.mtype = mtype
        if transfer_method_type is not APIHelper.SKIP:
            self.transfer_method_type = transfer_method_type
        if address is not APIHelper.SKIP:
            self.address = address

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        bank_account_ownership_type =\
            dictionary.get("bankAccountOwnershipType")\
            if dictionary.get("bankAccountOwnershipType")\
                else APIHelper.SKIP
        bank_country =\
            dictionary.get("bankCountry")\
            if dictionary.get("bankCountry")\
                else APIHelper.SKIP
        bank_currency =\
            dictionary.get("bankCurrency")\
            if dictionary.get("bankCurrency")\
                else "USD"
        description =\
            dictionary.get("description")\
            if dictionary.get("description")\
                else APIHelper.SKIP
        fields = None
        if dictionary.get("fields") is not None:
            fields = [
                BankAccountField.from_dictionary(x)
                    for x in dictionary.get("fields")
            ]
        else:
            fields = APIHelper.SKIP
        mtype =\
            dictionary.get("type")\
            if dictionary.get("type")\
                else APIHelper.SKIP
        transfer_method_type =\
            dictionary.get("transferMethodType")\
            if dictionary.get("transferMethodType")\
                else APIHelper.SKIP
        address =\
            BankAccountAddress.from_dictionary(
                dictionary.get("address"))\
                if "address" in dictionary.keys()\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(bank_account_ownership_type,
                   bank_country,
                   bank_currency,
                   description,
                   fields,
                   mtype,
                   transfer_method_type,
                   address,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _bank_account_ownership_type=(
            self.bank_account_ownership_type
            if hasattr(self, "bank_account_ownership_type")
            else None
        )
        _bank_country=(
            self.bank_country
            if hasattr(self, "bank_country")
            else None
        )
        _bank_currency=(
            self.bank_currency
            if hasattr(self, "bank_currency")
            else None
        )
        _description=(
            self.description
            if hasattr(self, "description")
            else None
        )
        _fields=(
            self.fields
            if hasattr(self, "fields")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _transfer_method_type=(
            self.transfer_method_type
            if hasattr(self, "transfer_method_type")
            else None
        )
        _address=(
            self.address
            if hasattr(self, "address")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"bank_account_ownership_type={_bank_account_ownership_type!r}, "
            f"bank_country={_bank_country!r}, "
            f"bank_currency={_bank_currency!r}, "
            f"description={_description!r}, "
            f"fields={_fields!r}, "
            f"mtype={_mtype!r}, "
            f"transfer_method_type={_transfer_method_type!r}, "
            f"address={_address!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _bank_account_ownership_type=(
            self.bank_account_ownership_type
            if hasattr(self, "bank_account_ownership_type")
            else None
        )
        _bank_country=(
            self.bank_country
            if hasattr(self, "bank_country")
            else None
        )
        _bank_currency=(
            self.bank_currency
            if hasattr(self, "bank_currency")
            else None
        )
        _description=(
            self.description
            if hasattr(self, "description")
            else None
        )
        _fields=(
            self.fields
            if hasattr(self, "fields")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _transfer_method_type=(
            self.transfer_method_type
            if hasattr(self, "transfer_method_type")
            else None
        )
        _address=(
            self.address
            if hasattr(self, "address")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"bank_account_ownership_type={_bank_account_ownership_type!s}, "
            f"bank_country={_bank_country!s}, "
            f"bank_currency={_bank_currency!s}, "
            f"description={_description!s}, "
            f"fields={_fields!s}, "
            f"mtype={_mtype!s}, "
            f"transfer_method_type={_transfer_method_type!s}, "
            f"address={_address!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
