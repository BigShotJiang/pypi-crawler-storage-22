"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.create_or_update_document_fields import (
    CreateOrUpdateDocumentFields,
)


class CreateOrUpdateDocument(object):
    """Implementation of the '_CreateOrUpdateDocument' model.

    Attributes:
        fields (CreateOrUpdateDocumentFields): The model property of type
            CreateOrUpdateDocumentFields.
        upload (Any): Document to be uploaded
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "fields": "fields",
        "upload": "upload",
    }

    _optionals = [
        "fields",
        "upload",
    ]

    def __init__(
        self,
        fields=APIHelper.SKIP,
        upload=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a CreateOrUpdateDocument instance."""
        # Initialize members of the class
        if fields is not APIHelper.SKIP:
            self.fields = fields
        if upload is not APIHelper.SKIP:
            self.upload = upload

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        fields =\
            CreateOrUpdateDocumentFields.from_dictionary(
                dictionary.get("fields"))\
                if "fields" in dictionary.keys()\
                else APIHelper.SKIP
        upload =\
            dictionary.get("upload")\
            if dictionary.get("upload")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(fields,
                   upload,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _fields=(
            self.fields
            if hasattr(self, "fields")
            else None
        )
        _upload=(
            self.upload
            if hasattr(self, "upload")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"fields={_fields!r}, "
            f"upload={_upload!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _fields=(
            self.fields
            if hasattr(self, "fields")
            else None
        )
        _upload=(
            self.upload
            if hasattr(self, "upload")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"fields={_fields!s}, "
            f"upload={_upload!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
