"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.document_details import (
    DocumentDetails,
)


class CreateOrUpdateDocumentFields(object):
    """Implementation of the 'CreateOrUpdateDocumentFields' model.

    Attributes:
        fields (List[DocumentDetails]): The model property of type
            List[DocumentDetails].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "fields": "fields",
    }

    _optionals = [
        "fields",
    ]

    def __init__(
        self,
        fields=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a CreateOrUpdateDocumentFields instance."""
        # Initialize members of the class
        if fields is not APIHelper.SKIP:
            self.fields = fields

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        fields = None
        if dictionary.get("fields") is not None:
            fields = [
                DocumentDetails.from_dictionary(x)
                    for x in dictionary.get("fields")
            ]
        else:
            fields = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(fields,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _fields=(
            self.fields
            if hasattr(self, "fields")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"fields={_fields!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _fields=(
            self.fields
            if hasattr(self, "fields")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"fields={_fields!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
