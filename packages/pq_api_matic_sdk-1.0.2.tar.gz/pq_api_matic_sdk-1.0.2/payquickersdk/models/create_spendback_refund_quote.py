"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class CreateSpendbackRefundQuote(object):
    """Implementation of the '_CreateSpendbackRefundQuote' model.

    Attributes:
        amount (float): Money to be refunded from original payment
        source_token (str): Unique identifier representing the [source of
            funds](#/rest/models/structures/source-token)
        program_user_id (str): [Program
            identifier](#/rest/models/structures/program-user-id) for the user
        email (str): Contact [email address](#/rest/models/structures/email-address)
            for the user account for the user account
        destination_token (str): Unique identifier representing the [destination of
            funds](#/rest/models/structures/destination-token)
        memo (str): Optional internal [memo](#/rest/models/structures/memo) not
            visible to the user
        note (str): [Optional comments](#/rest/models/structures/notes) visible to
            the user
        client_spendback_refund_id (str): [Unique
            value](#/rest/models/structures/client-transfer-id) provided by the
            client for the transfer, utilized for reference and deduplication.
        auto_accept_quote (bool): Determines whether the quote is [automatically
            accepted](#/rest/models/structures/auto-accept-quote) or if a `POST`
            utilizing the token for the quote is required.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "amount": "amount",
        "source_token": "sourceToken",
        "program_user_id": "programUserId",
        "email": "email",
        "destination_token": "destinationToken",
        "memo": "memo",
        "note": "note",
        "client_spendback_refund_id": "clientSpendbackRefundId",
        "auto_accept_quote": "autoAcceptQuote",
    }

    _optionals = [
        "amount",
        "source_token",
        "program_user_id",
        "email",
        "destination_token",
        "memo",
        "note",
        "client_spendback_refund_id",
        "auto_accept_quote",
    ]

    def __init__(
        self,
        amount=APIHelper.SKIP,
        source_token="acct-3908ab5a-6ce1-474d-8b80-a63a7b147860",
        program_user_id=APIHelper.SKIP,
        email=APIHelper.SKIP,
        destination_token="dest-631b200f-665d-4dbe-bd01-3063c9dec97d",
        memo=APIHelper.SKIP,
        note=APIHelper.SKIP,
        client_spendback_refund_id=APIHelper.SKIP,
        auto_accept_quote=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a CreateSpendbackRefundQuote instance."""
        # Initialize members of the class
        if amount is not APIHelper.SKIP:
            self.amount = amount
        self.source_token = source_token
        if program_user_id is not APIHelper.SKIP:
            self.program_user_id = program_user_id
        if email is not APIHelper.SKIP:
            self.email = email
        self.destination_token = destination_token
        if memo is not APIHelper.SKIP:
            self.memo = memo
        if note is not APIHelper.SKIP:
            self.note = note
        if client_spendback_refund_id is not APIHelper.SKIP:
            self.client_spendback_refund_id = client_spendback_refund_id
        if auto_accept_quote is not APIHelper.SKIP:
            self.auto_accept_quote = auto_accept_quote

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        amount =\
            dictionary.get("amount")\
            if dictionary.get("amount")\
                else APIHelper.SKIP
        source_token =\
            dictionary.get("sourceToken")\
            if dictionary.get("sourceToken")\
                else "acct-3908ab5a-6ce1-474d-8b80-a63a7b147860"
        program_user_id =\
            dictionary.get("programUserId")\
            if dictionary.get("programUserId")\
                else APIHelper.SKIP
        email =\
            dictionary.get("email")\
            if dictionary.get("email")\
                else APIHelper.SKIP
        destination_token =\
            dictionary.get("destinationToken")\
            if dictionary.get("destinationToken")\
                else "dest-631b200f-665d-4dbe-bd01-3063c9dec97d"
        memo =\
            dictionary.get("memo")\
            if dictionary.get("memo")\
                else APIHelper.SKIP
        note =\
            dictionary.get("note")\
            if dictionary.get("note")\
                else APIHelper.SKIP
        client_spendback_refund_id =\
            dictionary.get("clientSpendbackRefundId")\
            if dictionary.get("clientSpendbackRefundId")\
                else APIHelper.SKIP
        auto_accept_quote =\
            dictionary.get("autoAcceptQuote")\
            if "autoAcceptQuote" in dictionary.keys()\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(amount,
                   source_token,
                   program_user_id,
                   email,
                   destination_token,
                   memo,
                   note,
                   client_spendback_refund_id,
                   auto_accept_quote,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _amount=(
            self.amount
            if hasattr(self, "amount")
            else None
        )
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _program_user_id=(
            self.program_user_id
            if hasattr(self, "program_user_id")
            else None
        )
        _email=(
            self.email
            if hasattr(self, "email")
            else None
        )
        _destination_token=(
            self.destination_token
            if hasattr(self, "destination_token")
            else None
        )
        _memo=(
            self.memo
            if hasattr(self, "memo")
            else None
        )
        _note=(
            self.note
            if hasattr(self, "note")
            else None
        )
        _client_spendback_refund_id=(
            self.client_spendback_refund_id
            if hasattr(self, "client_spendback_refund_id")
            else None
        )
        _auto_accept_quote=(
            self.auto_accept_quote
            if hasattr(self, "auto_accept_quote")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"amount={_amount!r}, "
            f"source_token={_source_token!r}, "
            f"program_user_id={_program_user_id!r}, "
            f"email={_email!r}, "
            f"destination_token={_destination_token!r}, "
            f"memo={_memo!r}, "
            f"note={_note!r}, "
            f"client_spendback_refund_id={_client_spendback_refund_id!r}, "
            f"auto_accept_quote={_auto_accept_quote!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _amount=(
            self.amount
            if hasattr(self, "amount")
            else None
        )
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _program_user_id=(
            self.program_user_id
            if hasattr(self, "program_user_id")
            else None
        )
        _email=(
            self.email
            if hasattr(self, "email")
            else None
        )
        _destination_token=(
            self.destination_token
            if hasattr(self, "destination_token")
            else None
        )
        _memo=(
            self.memo
            if hasattr(self, "memo")
            else None
        )
        _note=(
            self.note
            if hasattr(self, "note")
            else None
        )
        _client_spendback_refund_id=(
            self.client_spendback_refund_id
            if hasattr(self, "client_spendback_refund_id")
            else None
        )
        _auto_accept_quote=(
            self.auto_accept_quote
            if hasattr(self, "auto_accept_quote")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"amount={_amount!s}, "
            f"source_token={_source_token!s}, "
            f"program_user_id={_program_user_id!s}, "
            f"email={_email!s}, "
            f"destination_token={_destination_token!s}, "
            f"memo={_memo!s}, "
            f"note={_note!s}, "
            f"client_spendback_refund_id={_client_spendback_refund_id!s}, "
            f"auto_accept_quote={_auto_accept_quote!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
