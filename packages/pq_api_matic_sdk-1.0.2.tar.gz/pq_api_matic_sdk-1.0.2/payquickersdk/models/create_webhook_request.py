"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class CreateWebhookRequest(object):
    """Implementation of the '_CreateWebhookRequest' model.

    Attributes:
        namespace (WebhookNamespaces): Namespace used to identify and refer to the
            object
        url (str): Full path of the URI used for this object
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "namespace": "namespace",
        "url": "url",
    }

    _optionals = [
        "namespace",
        "url",
    ]

    def __init__(
        self,
        namespace=APIHelper.SKIP,
        url=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a CreateWebhookRequest instance."""
        # Initialize members of the class
        if namespace is not APIHelper.SKIP:
            self.namespace = namespace
        if url is not APIHelper.SKIP:
            self.url = url

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        namespace =\
            dictionary.get("namespace")\
            if dictionary.get("namespace")\
                else APIHelper.SKIP
        url =\
            dictionary.get("url")\
            if dictionary.get("url")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(namespace,
                   url,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _namespace=(
            self.namespace
            if hasattr(self, "namespace")
            else None
        )
        _url=(
            self.url
            if hasattr(self, "url")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"namespace={_namespace!r}, "
            f"url={_url!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _namespace=(
            self.namespace
            if hasattr(self, "namespace")
            else None
        )
        _url=(
            self.url
            if hasattr(self, "url")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"namespace={_namespace!s}, "
            f"url={_url!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
