"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class Currencies(object):
    """Implementation of the '__Currencies' enum.

    [Currency code type](#/rest/models/structures/country) for the object

    Attributes:
        UNDEFINED: The enum member of type str.
        AED: The enum member of type str.
        AFN: The enum member of type str.
        ALL: The enum member of type str.
        AMD: The enum member of type str.
        ANG: The enum member of type str.
        AOA: The enum member of type str.
        ARS: The enum member of type str.
        AUD: The enum member of type str.
        AWG: The enum member of type str.
        AZN: The enum member of type str.
        BAM: The enum member of type str.
        BBD: The enum member of type str.
        BDT: The enum member of type str.
        BGN: The enum member of type str.
        BHD: The enum member of type str.
        BIF: The enum member of type str.
        BMD: The enum member of type str.
        BND: The enum member of type str.
        BOB: The enum member of type str.
        BRL: The enum member of type str.
        BSD: The enum member of type str.
        BTN: The enum member of type str.
        BWP: The enum member of type str.
        BYR: The enum member of type str.
        BZD: The enum member of type str.
        CAD: The enum member of type str.
        CDF: The enum member of type str.
        CHF: The enum member of type str.
        CLP: The enum member of type str.
        CNY: The enum member of type str.
        COP: The enum member of type str.
        CRC: The enum member of type str.
        CUC: The enum member of type str.
        CUP: The enum member of type str.
        CVE: The enum member of type str.
        CZK: The enum member of type str.
        DJF: The enum member of type str.
        DKK: The enum member of type str.
        DOP: The enum member of type str.
        DZD: The enum member of type str.
        EGP: The enum member of type str.
        ERN: The enum member of type str.
        ETB: The enum member of type str.
        EUR: The enum member of type str.
        FJD: The enum member of type str.
        FKP: The enum member of type str.
        GBP: The enum member of type str.
        GEL: The enum member of type str.
        GGP: The enum member of type str.
        GHS: The enum member of type str.
        GIP: The enum member of type str.
        GMD: The enum member of type str.
        GNF: The enum member of type str.
        GTQ: The enum member of type str.
        GYD: The enum member of type str.
        HKD: The enum member of type str.
        HNL: The enum member of type str.
        HRK: The enum member of type str.
        HTG: The enum member of type str.
        HUF: The enum member of type str.
        IDR: The enum member of type str.
        ILS: The enum member of type str.
        IMP: The enum member of type str.
        INR: The enum member of type str.
        IQD: The enum member of type str.
        IRR: The enum member of type str.
        ISK: The enum member of type str.
        JEP: The enum member of type str.
        JMD: The enum member of type str.
        JOD: The enum member of type str.
        JPY: The enum member of type str.
        KES: The enum member of type str.
        KGS: The enum member of type str.
        KHR: The enum member of type str.
        KMF: The enum member of type str.
        KPW: The enum member of type str.
        KRW: The enum member of type str.
        KWD: The enum member of type str.
        KYD: The enum member of type str.
        KZT: The enum member of type str.
        LAK: The enum member of type str.
        LBP: The enum member of type str.
        LKR: The enum member of type str.
        LRD: The enum member of type str.
        LSL: The enum member of type str.
        LYD: The enum member of type str.
        MAD: The enum member of type str.
        MDL: The enum member of type str.
        MGA: The enum member of type str.
        MKD: The enum member of type str.
        MMK: The enum member of type str.
        MNT: The enum member of type str.
        MOP: The enum member of type str.
        MRO: The enum member of type str.
        MUR: The enum member of type str.
        MVR: The enum member of type str.
        MWK: The enum member of type str.
        MXN: The enum member of type str.
        MYR: The enum member of type str.
        MZN: The enum member of type str.
        NAD: The enum member of type str.
        NGN: The enum member of type str.
        NIO: The enum member of type str.
        NOK: The enum member of type str.
        NPR: The enum member of type str.
        NZD: The enum member of type str.
        OMR: The enum member of type str.
        PAB: The enum member of type str.
        PEN: The enum member of type str.
        PGK: The enum member of type str.
        PHP: The enum member of type str.
        PKR: The enum member of type str.
        PLN: The enum member of type str.
        PYG: The enum member of type str.
        QAR: The enum member of type str.
        RON: The enum member of type str.
        RSD: The enum member of type str.
        RUB: The enum member of type str.
        RWF: The enum member of type str.
        SAR: The enum member of type str.
        SBD: The enum member of type str.
        SCR: The enum member of type str.
        SDG: The enum member of type str.
        SEK: The enum member of type str.
        SGD: The enum member of type str.
        SHP: The enum member of type str.
        SLL: The enum member of type str.
        SOS: The enum member of type str.
        SPL: The enum member of type str.
        SRD: The enum member of type str.
        STD: The enum member of type str.
        SVC: The enum member of type str.
        SYP: The enum member of type str.
        SZL: The enum member of type str.
        THB: The enum member of type str.
        TJS: The enum member of type str.
        TMT: The enum member of type str.
        TND: The enum member of type str.
        TOP: The enum member of type str.
        TRY: The enum member of type str.
        TTD: The enum member of type str.
        TVD: The enum member of type str.
        TWD: The enum member of type str.
        TZS: The enum member of type str.
        UAH: The enum member of type str.
        UGX: The enum member of type str.
        USD: The enum member of type str.
        UYU: The enum member of type str.
        UZS: The enum member of type str.
        VEF: The enum member of type str.
        VND: The enum member of type str.
        VUV: The enum member of type str.
        WST: The enum member of type str.
        XAF: The enum member of type str.
        XCD: The enum member of type str.
        XDR: The enum member of type str.
        XOF: The enum member of type str.
        XPF: The enum member of type str.
        YER: The enum member of type str.
        ZAR: The enum member of type str.
        ZMW: The enum member of type str.
        ZWD: The enum member of type str.
        CNH: The enum member of type str.
        CXX: The enum member of type str.
        MRU: The enum member of type str.
        SLE: The enum member of type str.
        SSP: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    _all_values = ["UNDEFINED", "AED", "AFN", "ALL", "AMD", "ANG", "AOA",
        "ARS", "AUD", "AWG", "AZN", "BAM", "BBD", "BDT", "BGN", "BHD", "BIF", "BMD",
        "BND", "BOB", "BRL", "BSD", "BTN", "BWP", "BYR", "BZD", "CAD", "CDF", "CHF",
        "CLP", "CNY", "COP", "CRC", "CUC", "CUP", "CVE", "CZK", "DJF", "DKK", "DOP",
        "DZD", "EGP", "ERN", "ETB", "EUR", "FJD", "FKP", "GBP", "GEL", "GGP", "GHS",
        "GIP", "GMD", "GNF", "GTQ", "GYD", "HKD", "HNL", "HRK", "HTG", "HUF", "IDR",
        "ILS", "IMP", "INR", "IQD", "IRR", "ISK", "JEP", "JMD", "JOD", "JPY", "KES",
        "KGS", "KHR", "KMF", "KPW", "KRW", "KWD", "KYD", "KZT", "LAK", "LBP", "LKR",
        "LRD", "LSL", "LYD", "MAD", "MDL", "MGA", "MKD", "MMK", "MNT", "MOP", "MRO",
        "MUR", "MVR", "MWK", "MXN", "MYR", "MZN", "NAD", "NGN", "NIO", "NOK", "NPR",
        "NZD", "OMR", "PAB", "PEN", "PGK", "PHP", "PKR", "PLN", "PYG", "QAR", "RON",
        "RSD", "RUB", "RWF", "SAR", "SBD", "SCR", "SDG", "SEK", "SGD", "SHP", "SLL",
        "SOS", "SPL", "SRD", "STD", "SVC", "SYP", "SZL", "THB", "TJS", "TMT", "TND",
        "TOP", "TRY", "TTD", "TVD", "TWD", "TZS", "UAH", "UGX", "USD", "UYU", "UZS",
        "VEF", "VND", "VUV", "WST", "XAF", "XCD", "XDR", "XOF", "XPF", "YER", "ZAR",
        "ZMW", "ZWD", "CNH", "CXX", "MRU", "SLE", "SSP"]
    UNDEFINED = "UNDEFINED"

    AED = "AED"

    AFN = "AFN"

    ALL = "ALL"

    AMD = "AMD"

    ANG = "ANG"

    AOA = "AOA"

    ARS = "ARS"

    AUD = "AUD"

    AWG = "AWG"

    AZN = "AZN"

    BAM = "BAM"

    BBD = "BBD"

    BDT = "BDT"

    BGN = "BGN"

    BHD = "BHD"

    BIF = "BIF"

    BMD = "BMD"

    BND = "BND"

    BOB = "BOB"

    BRL = "BRL"

    BSD = "BSD"

    BTN = "BTN"

    BWP = "BWP"

    BYR = "BYR"

    BZD = "BZD"

    CAD = "CAD"

    CDF = "CDF"

    CHF = "CHF"

    CLP = "CLP"

    CNY = "CNY"

    COP = "COP"

    CRC = "CRC"

    CUC = "CUC"

    CUP = "CUP"

    CVE = "CVE"

    CZK = "CZK"

    DJF = "DJF"

    DKK = "DKK"

    DOP = "DOP"

    DZD = "DZD"

    EGP = "EGP"

    ERN = "ERN"

    ETB = "ETB"

    EUR = "EUR"

    FJD = "FJD"

    FKP = "FKP"

    GBP = "GBP"

    GEL = "GEL"

    GGP = "GGP"

    GHS = "GHS"

    GIP = "GIP"

    GMD = "GMD"

    GNF = "GNF"

    GTQ = "GTQ"

    GYD = "GYD"

    HKD = "HKD"

    HNL = "HNL"

    HRK = "HRK"

    HTG = "HTG"

    HUF = "HUF"

    IDR = "IDR"

    ILS = "ILS"

    IMP = "IMP"

    INR = "INR"

    IQD = "IQD"

    IRR = "IRR"

    ISK = "ISK"

    JEP = "JEP"

    JMD = "JMD"

    JOD = "JOD"

    JPY = "JPY"

    KES = "KES"

    KGS = "KGS"

    KHR = "KHR"

    KMF = "KMF"

    KPW = "KPW"

    KRW = "KRW"

    KWD = "KWD"

    KYD = "KYD"

    KZT = "KZT"

    LAK = "LAK"

    LBP = "LBP"

    LKR = "LKR"

    LRD = "LRD"

    LSL = "LSL"

    LYD = "LYD"

    MAD = "MAD"

    MDL = "MDL"

    MGA = "MGA"

    MKD = "MKD"

    MMK = "MMK"

    MNT = "MNT"

    MOP = "MOP"

    MRO = "MRO"

    MUR = "MUR"

    MVR = "MVR"

    MWK = "MWK"

    MXN = "MXN"

    MYR = "MYR"

    MZN = "MZN"

    NAD = "NAD"

    NGN = "NGN"

    NIO = "NIO"

    NOK = "NOK"

    NPR = "NPR"

    NZD = "NZD"

    OMR = "OMR"

    PAB = "PAB"

    PEN = "PEN"

    PGK = "PGK"

    PHP = "PHP"

    PKR = "PKR"

    PLN = "PLN"

    PYG = "PYG"

    QAR = "QAR"

    RON = "RON"

    RSD = "RSD"

    RUB = "RUB"

    RWF = "RWF"

    SAR = "SAR"

    SBD = "SBD"

    SCR = "SCR"

    SDG = "SDG"

    SEK = "SEK"

    SGD = "SGD"

    SHP = "SHP"

    SLL = "SLL"

    SOS = "SOS"

    SPL = "SPL"

    SRD = "SRD"

    STD = "STD"

    SVC = "SVC"

    SYP = "SYP"

    SZL = "SZL"

    THB = "THB"

    TJS = "TJS"

    TMT = "TMT"

    TND = "TND"

    TOP = "TOP"

    TRY = "TRY"

    TTD = "TTD"

    TVD = "TVD"

    TWD = "TWD"

    TZS = "TZS"

    UAH = "UAH"

    UGX = "UGX"

    USD = "USD"

    UYU = "UYU"

    UZS = "UZS"

    VEF = "VEF"

    VND = "VND"

    VUV = "VUV"

    WST = "WST"

    XAF = "XAF"

    XCD = "XCD"

    XDR = "XDR"

    XOF = "XOF"

    XPF = "XPF"

    YER = "YER"

    ZAR = "ZAR"

    ZMW = "ZMW"

    ZWD = "ZWD"

    CNH = "CNH"

    CXX = "CXX"

    MRU = "MRU"

    SLE = "SLE"

    SSP = "SSP"

    @classmethod
    def validate(cls, value):
        """Validate value contains in enum

        Args:
            value: the value to be validated

        Returns:
            boolean : if value is valid enum values.

        """
        return value in cls._all_values

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
