"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class DeliveryDetails(object):
    """Implementation of the '_DeliveryDetails' model.

    The delivery details of a Bank transfer with the minimum and maximum delivery in
    minutes or the expected delivery time.

    Attributes:
        minimum_delivery_minutes (int): The model property of type int.
        maximum_delivery_minutes (int): The model property of type int.
        expected_delivery (ExpectedDeliveryTypes): Transfer expected delivery types
        expected_delivery_time (datetime): The time of the expected delivery. Does
            not include the date.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "minimum_delivery_minutes": "minimumDeliveryMinutes",
        "maximum_delivery_minutes": "maximumDeliveryMinutes",
        "expected_delivery": "expectedDelivery",
        "expected_delivery_time": "expectedDeliveryTime",
    }

    _optionals = [
        "minimum_delivery_minutes",
        "maximum_delivery_minutes",
        "expected_delivery",
        "expected_delivery_time",
    ]

    def __init__(
        self,
        minimum_delivery_minutes=APIHelper.SKIP,
        maximum_delivery_minutes=APIHelper.SKIP,
        expected_delivery=APIHelper.SKIP,
        expected_delivery_time=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a DeliveryDetails instance."""
        # Initialize members of the class
        if minimum_delivery_minutes is not APIHelper.SKIP:
            self.minimum_delivery_minutes = minimum_delivery_minutes
        if maximum_delivery_minutes is not APIHelper.SKIP:
            self.maximum_delivery_minutes = maximum_delivery_minutes
        if expected_delivery is not APIHelper.SKIP:
            self.expected_delivery = expected_delivery
        if expected_delivery_time is not APIHelper.SKIP:
            self.expected_delivery_time =\
                 APIHelper.apply_datetime_converter(
                expected_delivery_time, APIHelper.RFC3339DateTime)\
                 if expected_delivery_time else None

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        minimum_delivery_minutes =\
            dictionary.get("minimumDeliveryMinutes")\
            if dictionary.get("minimumDeliveryMinutes")\
                else APIHelper.SKIP
        maximum_delivery_minutes =\
            dictionary.get("maximumDeliveryMinutes")\
            if dictionary.get("maximumDeliveryMinutes")\
                else APIHelper.SKIP
        expected_delivery =\
            dictionary.get("expectedDelivery")\
            if dictionary.get("expectedDelivery")\
                else APIHelper.SKIP
        expected_delivery_time = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("expectedDeliveryTime")).datetime\
            if dictionary.get("expectedDeliveryTime") else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(minimum_delivery_minutes,
                   maximum_delivery_minutes,
                   expected_delivery,
                   expected_delivery_time,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _minimum_delivery_minutes=(
            self.minimum_delivery_minutes
            if hasattr(self, "minimum_delivery_minutes")
            else None
        )
        _maximum_delivery_minutes=(
            self.maximum_delivery_minutes
            if hasattr(self, "maximum_delivery_minutes")
            else None
        )
        _expected_delivery=(
            self.expected_delivery
            if hasattr(self, "expected_delivery")
            else None
        )
        _expected_delivery_time=(
            self.expected_delivery_time
            if hasattr(self, "expected_delivery_time")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"minimum_delivery_minutes={_minimum_delivery_minutes!r}, "
            f"maximum_delivery_minutes={_maximum_delivery_minutes!r}, "
            f"expected_delivery={_expected_delivery!r}, "
            f"expected_delivery_time={_expected_delivery_time!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _minimum_delivery_minutes=(
            self.minimum_delivery_minutes
            if hasattr(self, "minimum_delivery_minutes")
            else None
        )
        _maximum_delivery_minutes=(
            self.maximum_delivery_minutes
            if hasattr(self, "maximum_delivery_minutes")
            else None
        )
        _expected_delivery=(
            self.expected_delivery
            if hasattr(self, "expected_delivery")
            else None
        )
        _expected_delivery_time=(
            self.expected_delivery_time
            if hasattr(self, "expected_delivery_time")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"minimum_delivery_minutes={_minimum_delivery_minutes!s}, "
            f"maximum_delivery_minutes={_maximum_delivery_minutes!s}, "
            f"expected_delivery={_expected_delivery!s}, "
            f"expected_delivery_time={_expected_delivery_time!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
