"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.list_metadata import (
    ListMetadata,
)
from payquickersdk.models.user_document_requirement_item import (
    UserDocumentRequirementItem,
)


class DocumentRequirementsListResult(object):
    """Implementation of the '_DocumentRequirementsListResult' model.

    Attributes:
        id (List[UserDocumentRequirementItem]): The model property of type
            List[UserDocumentRequirementItem].
        meta (ListMetadata): The model property of type ListMetadata.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "id": "id",
        "meta": "meta",
    }

    _optionals = [
        "id",
        "meta",
    ]

    def __init__(
        self,
        id=APIHelper.SKIP,
        meta=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a DocumentRequirementsListResult instance."""
        # Initialize members of the class
        if id is not APIHelper.SKIP:
            self.id = id
        if meta is not APIHelper.SKIP:
            self.meta = meta

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        id = None
        if dictionary.get("id") is not None:
            id = [
                UserDocumentRequirementItem.from_dictionary(x)
                    for x in dictionary.get("id")
            ]
        else:
            id = APIHelper.SKIP
        meta =\
            ListMetadata.from_dictionary(
                dictionary.get("meta"))\
                if "meta" in dictionary.keys()\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(id,
                   meta,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _id=(
            self.id
            if hasattr(self, "id")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"id={_id!r}, "
            f"meta={_meta!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _id=(
            self.id
            if hasattr(self, "id")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"id={_id!s}, "
            f"meta={_meta!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
