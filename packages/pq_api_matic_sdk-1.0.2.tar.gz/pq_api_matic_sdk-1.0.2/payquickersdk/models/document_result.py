"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.document_details import (
    DocumentDetails,
)
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)
from payquickersdk.models.metadata_items import (
    MetadataItems,
)


class DocumentResult(object):
    """Implementation of the '_DocumentResult' model.

    Attributes:
        create_date (datetime): Time object was
            [created](#/rest/models/structures/created-on)
        fields (List[DocumentDetails]): The model property of type
            List[DocumentDetails].
        filename (str): The name given to a computer file in order to distinguish it
            from other files
        mime_type (str): A label used to identify a type of data.  Acts like a file
            extension on the internet.
        token (str): [Token](#/rest/models/structures/token) representing the document
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        meta (MetadataItems): The model property of type MetadataItems.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "create_date": "createDate",
        "token": "token",
        "links": "links",
        "fields": "fields",
        "filename": "filename",
        "mime_type": "mimeType",
        "meta": "meta",
    }

    _optionals = [
        "fields",
        "filename",
        "mime_type",
        "meta",
    ]

    def __init__(
        self,
        create_date=None,
        token="docu-2053aaad-c1a5-45e2-a2da-f71287f32800",
        links=None,
        fields=APIHelper.SKIP,
        filename=APIHelper.SKIP,
        mime_type=APIHelper.SKIP,
        meta=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a DocumentResult instance."""
        # Initialize members of the class
        self.create_date =\
             APIHelper.apply_datetime_converter(
            create_date, APIHelper.RFC3339DateTime)\
             if create_date else None
        if fields is not APIHelper.SKIP:
            self.fields = fields
        if filename is not APIHelper.SKIP:
            self.filename = filename
        if mime_type is not APIHelper.SKIP:
            self.mime_type = mime_type
        self.token = token
        self.links = links
        if meta is not APIHelper.SKIP:
            self.meta = meta

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        create_date = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("createDate")).datetime\
            if dictionary.get("createDate") else None
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else "docu-2053aaad-c1a5-45e2-a2da-f71287f32800"
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        fields = None
        if dictionary.get("fields") is not None:
            fields = [
                DocumentDetails.from_dictionary(x)
                    for x in dictionary.get("fields")
            ]
        else:
            fields = APIHelper.SKIP
        filename =\
            dictionary.get("filename")\
            if dictionary.get("filename")\
                else APIHelper.SKIP
        mime_type =\
            dictionary.get("mimeType")\
            if dictionary.get("mimeType")\
                else APIHelper.SKIP
        meta =\
            MetadataItems.from_dictionary(
                dictionary.get("meta"))\
                if "meta" in dictionary.keys()\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(create_date,
                   token,
                   links,
                   fields,
                   filename,
                   mime_type,
                   meta,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _create_date=self.create_date
        _fields=(
            self.fields
            if hasattr(self, "fields")
            else None
        )
        _filename=(
            self.filename
            if hasattr(self, "filename")
            else None
        )
        _mime_type=(
            self.mime_type
            if hasattr(self, "mime_type")
            else None
        )
        _token=self.token
        _links=self.links
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"create_date={_create_date!r}, "
            f"fields={_fields!r}, "
            f"filename={_filename!r}, "
            f"mime_type={_mime_type!r}, "
            f"token={_token!r}, "
            f"links={_links!r}, "
            f"meta={_meta!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _create_date=self.create_date
        _fields=(
            self.fields
            if hasattr(self, "fields")
            else None
        )
        _filename=(
            self.filename
            if hasattr(self, "filename")
            else None
        )
        _mime_type=(
            self.mime_type
            if hasattr(self, "mime_type")
            else None
        )
        _token=self.token
        _links=self.links
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"create_date={_create_date!s}, "
            f"fields={_fields!s}, "
            f"filename={_filename!s}, "
            f"mime_type={_mime_type!s}, "
            f"token={_token!s}, "
            f"links={_links!s}, "
            f"meta={_meta!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
