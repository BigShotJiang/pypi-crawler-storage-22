"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class DocumentTypes(object):
    """Implementation of the '__DocumentTypes' enum.

    Indicates the enums for KYC.

    Attributes:
        UNDEFINED: The enum member of type str.
        ARMED_FORCES_ID_CARD: The enum member of type str.
        BANK_OR_CREDIT_CARD_STATEMENT: The enum member of type str.
        BANK_REFERENCE_LETTER: The enum member of type str.
        BIRTH_CERTIFICATE: The enum member of type str.
        DEED_POLL: The enum member of type str.
        DEED_POLL_NAME_CHANGE: The enum member of type str.
        DRIVERS_LICENSE: The enum member of type str.
        DRIVERS_LICENSE_BACK: The enum member of type str.
        DRIVERS_LICENSE_NAME_CHANGE: The enum member of type str.
        FIREARMS_LICENSE: The enum member of type str.
        HEALTH_ID_CARD: The enum member of type str.
        HIGH_QUALITY_HEADSHOT: The enum member of type str.
        MARRIAGE_LICENSE: The enum member of type str.
        MARRIAGE_LICENSE_NAME_CHANGE: The enum member of type str.
        MATRICULA_CONSULAR_ID_CARD: The enum member of type str.
        NATIONAL_IDENTITY_CARD: The enum member of type str.
        NATIONAL_IDENTITY_CARD_FRONT: The enum member of type str.
        NATIONAL_IDENTITY_CARD_BACK: The enum member of type str.
        NATIONAL_INSURANCE_CARD: The enum member of type str.
        OFFICIAL_NAME_CHANGE_DOCUMENT: The enum member of type str.
        OTHER_GOVERNMENT_ISSUED_ID: The enum member of type str.
        PASSPORT: The enum member of type str.
        PAY_STUB: The enum member of type str.
        PROOF_OF_AGE_CARD: The enum member of type str.
        PROVISIONAL_DRIVERS_LICENSE: The enum member of type str.
        PUBLIC_SERVICE_CARD_FRONT: The enum member of type str.
        PUBLIC_SERVICE_CARD_BACK: The enum member of type str.
        RESIDENT_CARD: The enum member of type str.
        RESIDENT_IMMIGRATION_CARD: The enum member of type str.
        SOCIAL_SECURITY_CARD: The enum member of type str.
        TAX_IDENTIFICATION_CARD_OR_LETTER: The enum member of type str.
        TAX_STATEMENT: The enum member of type str.
        UTILITY_BILL: The enum member of type str.
        VOTERS_CARD: The enum member of type str.
        ARMED_FORCES_ID_CARD_BACK: The enum member of type str.
        TAX_DOCUMENT: The enum member of type str.
        HEALTH_ID_CARD_BACK: The enum member of type str.
        PROOF_OF_AGE_CARD_BACK: The enum member of type str.
        INDEPENDENT_PERSONAL_REFERENCE_DOCUMENT: The enum member of type str.
        VIDEO_CALL_FILE: The enum member of type str.
        HOME_OR_AUTO_INSURANCE_CERTIFICATE_OR_SCHEDULE: The enum member of type str.
        DIVORCE_DECREE_NAME_CHANGE: The enum member of type str.
        CIVIL_PARTNERSHIP_REGISTRATION_NAME_CHANGE: The enum member of type str.
        RENT_AGREEMENT: The enum member of type str.
        VEHICLE_REGISTRATION: The enum member of type str.
        BENEFITS_CONFIRMATION_LETTER: The enum member of type str.
        RESIDENT_CARD_BACK: The enum member of type str.
        LOAN_ACCOUNT_STATEMENT: The enum member of type str.
        PROCESSED_CHECK: The enum member of type str.
        RESIDENTIAL_DIRECTORY_LISTING: The enum member of type str.
        GENERIC_DOCUMENT: The enum member of type str.
        GOVERNMENT_ISSUED_PHOTOID: The enum member of type str.
        GOVERNMENT_ISSUED_PHOTO_ID_BACK: The enum member of type str.
        SOCIAL_INSURANCE_NUMBER_CARD: The enum member of type str.
        SOCIAL_INSURANCE_NUMBER_LETTER: The enum member of type str.
        OTHER_SOCIAL_INSURANCE_NUMBER_DOCUMENT: The enum member of type str.
        PLASTIC_CARD_CUSTOM_IMAGE: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    UNDEFINED = "UNDEFINED"

    ARMED_FORCES_ID_CARD = "ARMED_FORCES_ID_CARD"

    BANK_OR_CREDIT_CARD_STATEMENT = "BANK_OR_CREDIT_CARD_STATEMENT"

    BANK_REFERENCE_LETTER = "BANK_REFERENCE_LETTER"

    BIRTH_CERTIFICATE = "BIRTH_CERTIFICATE"

    DEED_POLL = "DEED_POLL"

    DEED_POLL_NAME_CHANGE = "DEED_POLL_NAME_CHANGE"

    DRIVERS_LICENSE = "DRIVERS_LICENSE"

    DRIVERS_LICENSE_BACK = "DRIVERS_LICENSE_BACK"

    DRIVERS_LICENSE_NAME_CHANGE = "DRIVERS_LICENSE_NAME_CHANGE"

    FIREARMS_LICENSE = "FIREARMS_LICENSE"

    HEALTH_ID_CARD = "HEALTH_ID_CARD"

    HIGH_QUALITY_HEADSHOT = "HIGH_QUALITY_HEADSHOT"

    MARRIAGE_LICENSE = "MARRIAGE_LICENSE"

    MARRIAGE_LICENSE_NAME_CHANGE = "MARRIAGE_LICENSE_NAME_CHANGE"

    MATRICULA_CONSULAR_ID_CARD = "MATRICULA_CONSULAR_ID_CARD"

    NATIONAL_IDENTITY_CARD = "NATIONAL_IDENTITY_CARD"

    NATIONAL_IDENTITY_CARD_FRONT = "NATIONAL_IDENTITY_CARD_FRONT"

    NATIONAL_IDENTITY_CARD_BACK = "NATIONAL_IDENTITY_CARD_BACK"

    NATIONAL_INSURANCE_CARD = "NATIONAL_INSURANCE_CARD"

    OFFICIAL_NAME_CHANGE_DOCUMENT = "OFFICIAL_NAME_CHANGE_DOCUMENT"

    OTHER_GOVERNMENT_ISSUED_ID = "OTHER_GOVERNMENT_ISSUED_ID"

    PASSPORT = "PASSPORT"

    PAY_STUB = "PAY_STUB"

    PROOF_OF_AGE_CARD = "PROOF_OF_AGE_CARD"

    PROVISIONAL_DRIVERS_LICENSE = "PROVISIONAL_DRIVERS_LICENSE"

    PUBLIC_SERVICE_CARD_FRONT = "PUBLIC_SERVICE_CARD_FRONT"

    PUBLIC_SERVICE_CARD_BACK = "PUBLIC_SERVICE_CARD_BACK"

    RESIDENT_CARD = "RESIDENT_CARD"

    RESIDENT_IMMIGRATION_CARD = "RESIDENT_IMMIGRATION_CARD"

    SOCIAL_SECURITY_CARD = "SOCIAL_SECURITY_CARD"

    TAX_IDENTIFICATION_CARD_OR_LETTER = "TAX_IDENTIFICATION_CARD_OR_LETTER"

    TAX_STATEMENT = "TAX_STATEMENT"

    UTILITY_BILL = "UTILITY_BILL"

    VOTERS_CARD = "VOTERS_CARD"

    ARMED_FORCES_ID_CARD_BACK = "ARMED_FORCES_ID_CARD_BACK"

    TAX_DOCUMENT = "TAX_DOCUMENT"

    HEALTH_ID_CARD_BACK = "HEALTH_ID_CARD_BACK"

    PROOF_OF_AGE_CARD_BACK = "PROOF_OF_AGE_CARD_BACK"

    INDEPENDENT_PERSONAL_REFERENCE_DOCUMENT = "INDEPENDENT_PERSONAL_REFERENCE_DOCUMENT"

    VIDEO_CALL_FILE = "VIDEO_CALL_FILE"

    HOME_OR_AUTO_INSURANCE_CERTIFICATE_OR_SCHEDULE = "HOME_OR_AUTO_INSURANCE_CERTIFICATE_OR_SCHEDULE" # noqa: E501

    DIVORCE_DECREE_NAME_CHANGE = "DIVORCE_DECREE_NAME_CHANGE"

    CIVIL_PARTNERSHIP_REGISTRATION_NAME_CHANGE = "CIVIL_PARTNERSHIP_REGISTRATION_NAME_CHANGE" # noqa: E501

    RENT_AGREEMENT = "RENT_AGREEMENT"

    VEHICLE_REGISTRATION = "VEHICLE_REGISTRATION"

    BENEFITS_CONFIRMATION_LETTER = "BENEFITS_CONFIRMATION_LETTER"

    RESIDENT_CARD_BACK = "RESIDENT_CARD_BACK"

    LOAN_ACCOUNT_STATEMENT = "LOAN_ACCOUNT_STATEMENT"

    PROCESSED_CHECK = "PROCESSED_CHECK"

    RESIDENTIAL_DIRECTORY_LISTING = "RESIDENTIAL_DIRECTORY_LISTING"

    GENERIC_DOCUMENT = "GENERIC_DOCUMENT"

    GOVERNMENT_ISSUED_PHOTOID = "GOVERNMENT_ISSUED_PHOTOID"

    GOVERNMENT_ISSUED_PHOTO_ID_BACK = "GOVERNMENT_ISSUED_PHOTO_ID_BACK"

    SOCIAL_INSURANCE_NUMBER_CARD = "SOCIAL_INSURANCE_NUMBER_CARD"

    SOCIAL_INSURANCE_NUMBER_LETTER = "SOCIAL_INSURANCE_NUMBER_LETTER"

    OTHER_SOCIAL_INSURANCE_NUMBER_DOCUMENT = "OTHER_SOCIAL_INSURANCE_NUMBER_DOCUMENT"

    PLASTIC_CARD_CUSTOM_IMAGE = "PLASTIC_CARD_CUSTOM_IMAGE"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
