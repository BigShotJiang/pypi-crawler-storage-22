"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class ElectronicTransferFailureTypes(object):
    """Implementation of the '__ElectronicTransferFailureTypes' enum.

    The type of failure for a bank transfer

    Attributes:
        INCORRECT_ACCOUNT_NUMBER: The account number is invalid or incorrect.
        INVALID_SORT_CODE: The sort code or account number are invalid.
        ACCOUNT_NOT_FOUND: No account was found with the details provided.
        DESTINATION_ACCOUNT_NUMBER_INVALID: The destination account number is invalid.
        BENEFICIARY_ACCOUNT_NUMBER_INVALID: The destination account number is invalid.
        ACCOUNT_CLOSED: The bank account is closed.
        GENERAL_COMPLIANCE: GENERAL_COMPLIANCE
        INCORRECT_ROUTING_CODE: INCORRECT_ROUTING_CODE
        BELOW_MIN_ABOVE_MAX_ALLOWED_AMOUNT: BELOW_MIN_ABOVE_MAX_ALLOWED_AMOUNT
        INVALID_INSUFFICIENT_PAYMENT_DETAILS: INVALID_INSUFFICIENT_PAYMENT_DETAILS
        INVALID_BENEFICIARY_NAME: INVALID_BENEFICIARY_NAME
        INVALID_BENEFICIARY_TAX_ID: INVALID_BENEFICIARY_TAX_ID
        INVALID_BENEFICIARY_BANK_BRANCH_ADDRESS:
            INVALID_BENEFICIARY_BANK_BRANCH_ADDRESS
        INVALID_BENEFICIARY_ADDRESS: INVALID_BENEFICIARY_ADDRESS
        BANK_UNABLE_TO_APPLY: BANK_UNABLE_TO_APPLY
        BANK_CODE_WRONG: BANK_CODE_WRONG
        OTHER: The transfer failed and the reason will be in the EFTFAILURECOMMENT
            field
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    INCORRECT_ACCOUNT_NUMBER = "INCORRECT_ACCOUNT_NUMBER"

    INVALID_SORT_CODE = "INVALID_SORT_CODE"

    ACCOUNT_NOT_FOUND = "ACCOUNT_NOT_FOUND"

    DESTINATION_ACCOUNT_NUMBER_INVALID = "DESTINATION_ACCOUNT_NUMBER_INVALID"

    BENEFICIARY_ACCOUNT_NUMBER_INVALID = "BENEFICIARY_ACCOUNT_NUMBER_INVALID"

    ACCOUNT_CLOSED = "ACCOUNT_CLOSED"

    GENERAL_COMPLIANCE = "GENERAL_COMPLIANCE"

    INCORRECT_ROUTING_CODE = "INCORRECT_ROUTING_CODE"

    BELOW_MIN_ABOVE_MAX_ALLOWED_AMOUNT = "BELOW_MIN_ABOVE_MAX_ALLOWED_AMOUNT"

    INVALID_INSUFFICIENT_PAYMENT_DETAILS = "INVALID_INSUFFICIENT_PAYMENT_DETAILS"

    INVALID_BENEFICIARY_NAME = "INVALID_BENEFICIARY_NAME"

    INVALID_BENEFICIARY_TAX_ID = "INVALID_BENEFICIARY_TAX_ID"

    INVALID_BENEFICIARY_BANK_BRANCH_ADDRESS = "INVALID_BENEFICIARY_BANK_BRANCH_ADDRESS"

    INVALID_BENEFICIARY_ADDRESS = "INVALID_BENEFICIARY_ADDRESS"

    BANK_UNABLE_TO_APPLY = "BANK_UNABLE_TO_APPLY"

    BANK_CODE_WRONG = "BANK_CODE_WRONG"

    OTHER = "OTHER"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
