"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class ElectronicWalletFields(object):
    """Implementation of the '__ElectronicWalletFields' enum.

    Classifies electronic wallet [field
    types](#/rest/models/structures/electronic-wallet-fields)

    Attributes:
        UNDEFINED: Unknown or unrecognized.
        ACCOUNT_NUMBER: Used for credit party identifier. For example,`012345678`.
        GOVERNMENT_ID: Used for credit party identifier. For example,`012345678`.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    UNDEFINED = "UNDEFINED"

    ACCOUNT_NUMBER = "ACCOUNT_NUMBER"

    GOVERNMENT_ID = "GOVERNMENT_ID"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
