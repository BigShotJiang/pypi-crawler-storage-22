"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.electronic_wallet_field import (
    ElectronicWalletField,
)
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)


class ElectronicWalletObject(object):
    """Implementation of the 'ElectronicWalletObject' model.

    Unique identifier for the [electronic
    wallet](#/rest/models/enumerations/electronic-wallet-types)

    Attributes:
        token (str): Unique identifier representing the [destination of
            funds](#/rest/models/structures/destination-token)
        mtype (ElectronicWalletTypes): Name of the electronic wallet
        electronic_wallet_country (Countries): Throughout the PayQuicker API, the
            usage of the 2-letter alpha code is used in place of the country name,
            e.g., for bank country or residential country.  The 2-letter codes adhere
            to the ISO 3166-1 spec and are listed here for convenience.
        electronic_wallet_currency (Currencies): [Currency code
            type](#/rest/models/structures/country) for the object
        created_on (datetime): Time object was
            [created](#/rest/models/structures/created-on)
        fields (List[ElectronicWalletField]): The model property of type
            List[ElectronicWalletField].
        status (ElectronicWalletStatuses): Current verification status type of the
            electronic wallet
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "token": "token",
        "mtype": "type",
        "electronic_wallet_country": "electronicWalletCountry",
        "electronic_wallet_currency": "electronicWalletCurrency",
        "created_on": "createdOn",
        "fields": "fields",
        "status": "status",
        "links": "links",
    }

    _optionals = [
        "token",
        "mtype",
        "electronic_wallet_country",
        "electronic_wallet_currency",
        "created_on",
        "fields",
        "status",
        "links",
    ]

    def __init__(
        self,
        token="dest-631b200f-665d-4dbe-bd01-3063c9dec97d",
        mtype=APIHelper.SKIP,
        electronic_wallet_country=APIHelper.SKIP,
        electronic_wallet_currency="USD",
        created_on=APIHelper.SKIP,
        fields=APIHelper.SKIP,
        status=APIHelper.SKIP,
        links=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a ElectronicWalletObject instance."""
        # Initialize members of the class
        self.token = token
        if mtype is not APIHelper.SKIP:
            self.mtype = mtype
        if electronic_wallet_country is not APIHelper.SKIP:
            self.electronic_wallet_country = electronic_wallet_country
        self.electronic_wallet_currency = electronic_wallet_currency
        if created_on is not APIHelper.SKIP:
            self.created_on =\
                 APIHelper.apply_datetime_converter(
                created_on, APIHelper.RFC3339DateTime)\
                 if created_on else None
        if fields is not APIHelper.SKIP:
            self.fields = fields
        if status is not APIHelper.SKIP:
            self.status = status
        if links is not APIHelper.SKIP:
            self.links = links

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else "dest-631b200f-665d-4dbe-bd01-3063c9dec97d"
        mtype =\
            dictionary.get("type")\
            if dictionary.get("type")\
                else APIHelper.SKIP
        electronic_wallet_country =\
            dictionary.get("electronicWalletCountry")\
            if dictionary.get("electronicWalletCountry")\
                else APIHelper.SKIP
        electronic_wallet_currency =\
            dictionary.get("electronicWalletCurrency")\
            if dictionary.get("electronicWalletCurrency")\
                else "USD"
        created_on = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("createdOn")).datetime\
            if dictionary.get("createdOn") else APIHelper.SKIP
        fields = None
        if dictionary.get("fields") is not None:
            fields = [
                ElectronicWalletField.from_dictionary(x)
                    for x in dictionary.get("fields")
            ]
        else:
            fields = APIHelper.SKIP
        status =\
            dictionary.get("status")\
            if dictionary.get("status")\
                else APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(token,
                   mtype,
                   electronic_wallet_country,
                   electronic_wallet_currency,
                   created_on,
                   fields,
                   status,
                   links,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _electronic_wallet_country=(
            self.electronic_wallet_country
            if hasattr(self, "electronic_wallet_country")
            else None
        )
        _electronic_wallet_currency=(
            self.electronic_wallet_currency
            if hasattr(self, "electronic_wallet_currency")
            else None
        )
        _created_on=(
            self.created_on
            if hasattr(self, "created_on")
            else None
        )
        _fields=(
            self.fields
            if hasattr(self, "fields")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!r}, "
            f"mtype={_mtype!r}, "
            f"electronic_wallet_country={_electronic_wallet_country!r}, "
            f"electronic_wallet_currency={_electronic_wallet_currency!r}, "
            f"created_on={_created_on!r}, "
            f"fields={_fields!r}, "
            f"status={_status!r}, "
            f"links={_links!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _electronic_wallet_country=(
            self.electronic_wallet_country
            if hasattr(self, "electronic_wallet_country")
            else None
        )
        _electronic_wallet_currency=(
            self.electronic_wallet_currency
            if hasattr(self, "electronic_wallet_currency")
            else None
        )
        _created_on=(
            self.created_on
            if hasattr(self, "created_on")
            else None
        )
        _fields=(
            self.fields
            if hasattr(self, "fields")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!s}, "
            f"mtype={_mtype!s}, "
            f"electronic_wallet_country={_electronic_wallet_country!s}, "
            f"electronic_wallet_currency={_electronic_wallet_currency!s}, "
            f"created_on={_created_on!s}, "
            f"fields={_fields!s}, "
            f"status={_status!s}, "
            f"links={_links!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
