"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.electronic_wallet_required_fields import (
    ElectronicWalletRequiredFields,
)
from payquickersdk.models.fee_configuration import (
    FeeConfiguration,
)


class ElectronicWalletRequirement(object):
    """Implementation of the '_ElectronicWalletRequirement' model.

    Classifies the electronic wallet
    [required](#/rest/models/structures/electronic-wallet-requirement) information

    Attributes:
        electronic_wallet_type (ElectronicWalletTypes): Name of the electronic wallet
        electronic_wallet_country (Countries): Throughout the PayQuicker API, the
            usage of the 2-letter alpha code is used in place of the country name,
            e.g., for bank country or residential country.  The 2-letter codes adhere
            to the ISO 3166-1 spec and are listed here for convenience.
        electronic_wallet_currency (Currencies): [Currency code
            type](#/rest/models/structures/country) for the object
        fee (FeeConfiguration): The model property of type FeeConfiguration.
        source_country (Countries): Throughout the PayQuicker API, the usage of the
            2-letter alpha code is used in place of the country name, e.g., for bank
            country or residential country.  The 2-letter codes adhere to the ISO
            3166-1 spec and are listed here for convenience.
        source_currency (Currencies): [Currency code
            type](#/rest/models/structures/country) for the object
        requirements (List[ElectronicWalletRequiredFields]): The model property of
            type List[ElectronicWalletRequiredFields].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "electronic_wallet_type": "electronicWalletType",
        "electronic_wallet_country": "electronicWalletCountry",
        "electronic_wallet_currency": "electronicWalletCurrency",
        "fee": "fee",
        "source_country": "sourceCountry",
        "source_currency": "sourceCurrency",
        "requirements": "requirements",
    }

    _optionals = [
        "electronic_wallet_type",
        "electronic_wallet_country",
        "electronic_wallet_currency",
        "fee",
        "source_country",
        "source_currency",
        "requirements",
    ]

    def __init__(
        self,
        electronic_wallet_type=APIHelper.SKIP,
        electronic_wallet_country=APIHelper.SKIP,
        electronic_wallet_currency="USD",
        fee=APIHelper.SKIP,
        source_country=APIHelper.SKIP,
        source_currency="USD",
        requirements=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a ElectronicWalletRequirement instance."""
        # Initialize members of the class
        if electronic_wallet_type is not APIHelper.SKIP:
            self.electronic_wallet_type = electronic_wallet_type
        if electronic_wallet_country is not APIHelper.SKIP:
            self.electronic_wallet_country = electronic_wallet_country
        self.electronic_wallet_currency = electronic_wallet_currency
        if fee is not APIHelper.SKIP:
            self.fee = fee
        if source_country is not APIHelper.SKIP:
            self.source_country = source_country
        self.source_currency = source_currency
        if requirements is not APIHelper.SKIP:
            self.requirements = requirements

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        electronic_wallet_type =\
            dictionary.get("electronicWalletType")\
            if dictionary.get("electronicWalletType")\
                else APIHelper.SKIP
        electronic_wallet_country =\
            dictionary.get("electronicWalletCountry")\
            if dictionary.get("electronicWalletCountry")\
                else APIHelper.SKIP
        electronic_wallet_currency =\
            dictionary.get("electronicWalletCurrency")\
            if dictionary.get("electronicWalletCurrency")\
                else "USD"
        fee =\
            FeeConfiguration.from_dictionary(
                dictionary.get("fee"))\
                if "fee" in dictionary.keys()\
                else APIHelper.SKIP
        source_country =\
            dictionary.get("sourceCountry")\
            if dictionary.get("sourceCountry")\
                else APIHelper.SKIP
        source_currency =\
            dictionary.get("sourceCurrency")\
            if dictionary.get("sourceCurrency")\
                else "USD"
        requirements = None
        if dictionary.get("requirements") is not None:
            requirements = [
                ElectronicWalletRequiredFields.from_dictionary(x)
                    for x in dictionary.get("requirements")
            ]
        else:
            requirements = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(electronic_wallet_type,
                   electronic_wallet_country,
                   electronic_wallet_currency,
                   fee,
                   source_country,
                   source_currency,
                   requirements,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _electronic_wallet_type=(
            self.electronic_wallet_type
            if hasattr(self, "electronic_wallet_type")
            else None
        )
        _electronic_wallet_country=(
            self.electronic_wallet_country
            if hasattr(self, "electronic_wallet_country")
            else None
        )
        _electronic_wallet_currency=(
            self.electronic_wallet_currency
            if hasattr(self, "electronic_wallet_currency")
            else None
        )
        _fee=(
            self.fee
            if hasattr(self, "fee")
            else None
        )
        _source_country=(
            self.source_country
            if hasattr(self, "source_country")
            else None
        )
        _source_currency=(
            self.source_currency
            if hasattr(self, "source_currency")
            else None
        )
        _requirements=(
            self.requirements
            if hasattr(self, "requirements")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"electronic_wallet_type={_electronic_wallet_type!r}, "
            f"electronic_wallet_country={_electronic_wallet_country!r}, "
            f"electronic_wallet_currency={_electronic_wallet_currency!r}, "
            f"fee={_fee!r}, "
            f"source_country={_source_country!r}, "
            f"source_currency={_source_currency!r}, "
            f"requirements={_requirements!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _electronic_wallet_type=(
            self.electronic_wallet_type
            if hasattr(self, "electronic_wallet_type")
            else None
        )
        _electronic_wallet_country=(
            self.electronic_wallet_country
            if hasattr(self, "electronic_wallet_country")
            else None
        )
        _electronic_wallet_currency=(
            self.electronic_wallet_currency
            if hasattr(self, "electronic_wallet_currency")
            else None
        )
        _fee=(
            self.fee
            if hasattr(self, "fee")
            else None
        )
        _source_country=(
            self.source_country
            if hasattr(self, "source_country")
            else None
        )
        _source_currency=(
            self.source_currency
            if hasattr(self, "source_currency")
            else None
        )
        _requirements=(
            self.requirements
            if hasattr(self, "requirements")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"electronic_wallet_type={_electronic_wallet_type!s}, "
            f"electronic_wallet_country={_electronic_wallet_country!s}, "
            f"electronic_wallet_currency={_electronic_wallet_currency!s}, "
            f"fee={_fee!s}, "
            f"source_country={_source_country!s}, "
            f"source_currency={_source_currency!s}, "
            f"requirements={_requirements!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
