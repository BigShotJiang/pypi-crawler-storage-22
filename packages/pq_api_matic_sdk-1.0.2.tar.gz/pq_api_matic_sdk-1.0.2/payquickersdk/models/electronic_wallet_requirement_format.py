"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.electronic_wallet_requirement_format_legend import (
    ElectronicWalletRequirementFormatLegend,
)


class ElectronicWalletRequirementFormat(object):
    """Implementation of the '_ElectronicWalletRequirementFormat' model.

    Classifies the
    [format](#/rest/models/structures/electronic-wallet-requirement-format) of the
    required information for an electronic wallet

    Attributes:
        example (str): Example of a requirement generated from the validator(s)
        legend (List[ElectronicWalletRequirementFormatLegend]): The model property of
            type List[ElectronicWalletRequirementFormatLegend].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "example": "example",
        "legend": "legend",
    }

    _optionals = [
        "example",
        "legend",
    ]

    def __init__(
        self,
        example=APIHelper.SKIP,
        legend=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a ElectronicWalletRequirementFormat instance."""
        # Initialize members of the class
        if example is not APIHelper.SKIP:
            self.example = example
        if legend is not APIHelper.SKIP:
            self.legend = legend

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        example =\
            dictionary.get("example")\
            if dictionary.get("example")\
                else APIHelper.SKIP
        legend = None
        if dictionary.get("legend") is not None:
            legend = [
                ElectronicWalletRequirementFormatLegend.from_dictionary(x)
                    for x in dictionary.get("legend")
            ]
        else:
            legend = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(example,
                   legend,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _example=(
            self.example
            if hasattr(self, "example")
            else None
        )
        _legend=(
            self.legend
            if hasattr(self, "legend")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"example={_example!r}, "
            f"legend={_legend!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _example=(
            self.example
            if hasattr(self, "example")
            else None
        )
        _legend=(
            self.legend
            if hasattr(self, "legend")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"example={_example!s}, "
            f"legend={_legend!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
