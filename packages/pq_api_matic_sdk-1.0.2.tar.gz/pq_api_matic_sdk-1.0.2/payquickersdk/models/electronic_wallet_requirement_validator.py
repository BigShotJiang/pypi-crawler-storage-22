"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class ElectronicWalletRequirementValidator(object):
    """Implementation of the '_ElectronicWalletRequirementValidator' model.

    [Validator
    type](#/rest/models/structures/electronic-wallet-requirement-validator) that for
    the required electronic wallet information.

    Attributes:
        validator_type (ValidatorTypes): [Validator
            types](#/rest/models/structures/bank-account-requirement-validator) for
            the required bank account information.
        expression (str): Validation regular expression
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "expression": "expression",
        "validator_type": "validatorType",
    }

    _optionals = [
        "validator_type",
    ]

    def __init__(
        self,
        expression=None,
        validator_type=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a ElectronicWalletRequirementValidator instance."""
        # Initialize members of the class
        if validator_type is not APIHelper.SKIP:
            self.validator_type = validator_type
        self.expression = expression

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        expression =\
            dictionary.get("expression")\
            if dictionary.get("expression")\
                else None
        validator_type =\
            dictionary.get("validatorType")\
            if dictionary.get("validatorType")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(expression,
                   validator_type,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _validator_type=(
            self.validator_type
            if hasattr(self, "validator_type")
            else None
        )
        _expression=self.expression
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"validator_type={_validator_type!r}, "
            f"expression={_expression!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _validator_type=(
            self.validator_type
            if hasattr(self, "validator_type")
            else None
        )
        _expression=self.expression
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"validator_type={_validator_type!s}, "
            f"expression={_expression!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
