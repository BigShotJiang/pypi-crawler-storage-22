"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
class ElectronicWalletType(object):
    """Implementation of the '_ElectronicWalletType' model.

    Classifies the electronic wallet
    [required](#/rest/models/structures/electronic-wallet-type) configuration

    Attributes:
        mtype (ElectronicWalletTypes): Name of the electronic wallet
        electronic_wallet_country (Countries): Throughout the PayQuicker API, the
            usage of the 2-letter alpha code is used in place of the country name,
            e.g., for bank country or residential country.  The 2-letter codes adhere
            to the ISO 3166-1 spec and are listed here for convenience.
        electronic_wallet_currency (Currencies): [Currency code
            type](#/rest/models/structures/country) for the object
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "mtype": "type",
        "electronic_wallet_country": "electronicWalletCountry",
        "electronic_wallet_currency": "electronicWalletCurrency",
    }

    def __init__(
        self,
        mtype=None,
        electronic_wallet_country=None,
        electronic_wallet_currency="USD",
        additional_properties=None):
        """Initialize a ElectronicWalletType instance."""
        # Initialize members of the class
        self.mtype = mtype
        self.electronic_wallet_country = electronic_wallet_country
        self.electronic_wallet_currency = electronic_wallet_currency

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        mtype =\
            dictionary.get("type")\
            if dictionary.get("type")\
                else None
        electronic_wallet_country =\
            dictionary.get("electronicWalletCountry")\
            if dictionary.get("electronicWalletCountry")\
                else None
        electronic_wallet_currency =\
            dictionary.get("electronicWalletCurrency")\
            if dictionary.get("electronicWalletCurrency")\
                else "USD"

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(mtype,
                   electronic_wallet_country,
                   electronic_wallet_currency,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _mtype=self.mtype
        _electronic_wallet_country=self.electronic_wallet_country
        _electronic_wallet_currency=self.electronic_wallet_currency
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"mtype={_mtype!r}, "
            f"electronic_wallet_country={_electronic_wallet_country!r}, "
            f"electronic_wallet_currency={_electronic_wallet_currency!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _mtype=self.mtype
        _electronic_wallet_country=self.electronic_wallet_country
        _electronic_wallet_currency=self.electronic_wallet_currency
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"mtype={_mtype!s}, "
            f"electronic_wallet_country={_electronic_wallet_country!s}, "
            f"electronic_wallet_currency={_electronic_wallet_currency!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
