"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class ElectronicWalletTypes(object):
    """Implementation of the '__ElectronicWalletTypes' enum.

    Name of the electronic wallet

    Attributes:
        AIRTEL_MONEY: The enum member of type str.
        AIRTEL_TIGO_MONEY: The enum member of type str.
        ALIPAY: The enum member of type str.
        AMOLE: The enum member of type str.
        ASTRAPAY: The enum member of type str.
        AWASH_BIRR: The enum member of type str.
        AYA_PAY_WALLET: The enum member of type str.
        BANKILY: The enum member of type str.
        BIGPAY: The enum member of type str.
        BILLET_BHD_WALLET: The enum member of type str.
        BILLETERA_MOVIL_BANPRO: The enum member of type str.
        BKASH: The enum member of type str.
        CBE_BIRR: The enum member of type str.
        CELLPAY: The enum member of type str.
        COINS: The enum member of type str.
        DANA: The enum member of type str.
        DAVIPLATA: The enum member of type str.
        DIGICEL_MYCASH: The enum member of type str.
        DINARAK: The enum member of type str.
        EASY_PAISA_WALLET: The enum member of type str.
        ECOCASH: The enum member of type str.
        EQUITEL_MONEY: The enum member of type str.
        ESEWA: The enum member of type str.
        EXPRESS_UNION: The enum member of type str.
        EZ_CASH: The enum member of type str.
        FDH_BANK_WALLETS: The enum member of type str.
        FINJA_WALLET: The enum member of type str.
        GADHA: The enum member of type str.
        GCASH: The enum member of type str.
        GOPAY: The enum member of type str.
        GRABPAY: The enum member of type str.
        HELLOCASH: The enum member of type str.
        HORMUUD_EVC: The enum member of type str.
        ICASH: The enum member of type str.
        ILLICOCASH: The enum member of type str.
        IME_PAY: The enum member of type str.
        IMKAS: The enum member of type str.
        JAZZ_CASH_WALLET: The enum member of type str.
        KHALTI_WALLET: The enum member of type str.
        LENDMN: The enum member of type str.
        LINKAJA: The enum member of type str.
        M_PAISA: The enum member of type str.
        M_PESA: The enum member of type str.
        MCASH: The enum member of type str.
        MGURUSH_MOBILE_MONEY: The enum member of type str.
        MOMO: The enum member of type str.
        MONCASH: The enum member of type str.
        MOOV_MONEY: The enum member of type str.
        MORU: The enum member of type str.
        MOVII: The enum member of type str.
        MTN_GUINEA_CONAKRY: The enum member of type str.
        MTN_MOBILE_MONEY: The enum member of type str.
        NAMASTEPAY: The enum member of type str.
        NAYAPAY: The enum member of type str.
        NEQUI: The enum member of type str.
        ORANGE_MONEY: The enum member of type str.
        OVO: The enum member of type str.
        PAYMAYA: The enum member of type str.
        PAYTREN: The enum member of type str.
        PRABHU_PAY: The enum member of type str.
        PREMIER_WALLET: The enum member of type str.
        QIWI: The enum member of type str.
        QPAY: The enum member of type str.
        SADAPAY: The enum member of type str.
        SAJILOPAY: The enum member of type str.
        SHOPEEPAY: The enum member of type str.
        SMARTCASH_AIRTEL: The enum member of type str.
        TELEBIRR: The enum member of type str.
        TIGO_MONEY: The enum member of type str.
        TIGO_PESA: The enum member of type str.
        TNG_DIGITAL: The enum member of type str.
        TNM_WALLETS: The enum member of type str.
        TRUEMONEY_WALLET: The enum member of type str.
        UNIPAGO: The enum member of type str.
        UWALLET: The enum member of type str.
        VNPAY: The enum member of type str.
        VNPT_PAY: The enum member of type str.
        VODAFONE_MONEY: The enum member of type str.
        WECHATPAY: The enum member of type str.
        WING_MONEY: The enum member of type str.
        YOAPP: The enum member of type str.
        ZAIN_CASH: The enum member of type str.
        ZALOPAY: The enum member of type str.
        ZAMTEL_MOBILE_MONEY: The enum member of type str.
        UNDEFINED: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    AIRTEL_MONEY = "AIRTEL_MONEY"

    AIRTEL_TIGO_MONEY = "AIRTEL_TIGO_MONEY"

    ALIPAY = "ALIPAY"

    AMOLE = "AMOLE"

    ASTRAPAY = "ASTRAPAY"

    AWASH_BIRR = "AWASH_BIRR"

    AYA_PAY_WALLET = "AYA_PAY_WALLET"

    BANKILY = "BANKILY"

    BIGPAY = "BIGPAY"

    BILLET_BHD_WALLET = "BILLET_BHD_WALLET"

    BILLETERA_MOVIL_BANPRO = "BILLETERA_MOVIL_BANPRO"

    BKASH = "BKASH"

    CBE_BIRR = "CBE_BIRR"

    CELLPAY = "CELLPAY"

    COINS = "COINS"

    DANA = "DANA"

    DAVIPLATA = "DAVIPLATA"

    DIGICEL_MYCASH = "DIGICEL_MYCASH"

    DINARAK = "DINARAK"

    EASY_PAISA_WALLET = "EASY_PAISA_WALLET"

    ECOCASH = "ECOCASH"

    EQUITEL_MONEY = "EQUITEL_MONEY"

    ESEWA = "ESEWA"

    EXPRESS_UNION = "EXPRESS_UNION"

    EZ_CASH = "EZ_CASH"

    FDH_BANK_WALLETS = "FDH_BANK_WALLETS"

    FINJA_WALLET = "FINJA_WALLET"

    GADHA = "GADHA"

    GCASH = "GCASH"

    GOPAY = "GOPAY"

    GRABPAY = "GRABPAY"

    HELLOCASH = "HELLOCASH"

    HORMUUD_EVC = "HORMUUD_EVC"

    ICASH = "ICASH"

    ILLICOCASH = "ILLICOCASH"

    IME_PAY = "IME_PAY"

    IMKAS = "IMKAS"

    JAZZ_CASH_WALLET = "JAZZ_CASH_WALLET"

    KHALTI_WALLET = "KHALTI_WALLET"

    LENDMN = "LENDMN"

    LINKAJA = "LINKAJA"

    M_PAISA = "M_PAISA"

    M_PESA = "M_PESA"

    MCASH = "MCASH"

    MGURUSH_MOBILE_MONEY = "MGURUSH_MOBILE_MONEY"

    MOMO = "MOMO"

    MONCASH = "MONCASH"

    MOOV_MONEY = "MOOV_MONEY"

    MORU = "MORU"

    MOVII = "MOVII"

    MTN_GUINEA_CONAKRY = "MTN_GUINEA_CONAKRY"

    MTN_MOBILE_MONEY = "MTN_MOBILE_MONEY"

    NAMASTEPAY = "NAMASTEPAY"

    NAYAPAY = "NAYAPAY"

    NEQUI = "NEQUI"

    ORANGE_MONEY = "ORANGE_MONEY"

    OVO = "OVO"

    PAYMAYA = "PAYMAYA"

    PAYTREN = "PAYTREN"

    PRABHU_PAY = "PRABHU_PAY"

    PREMIER_WALLET = "PREMIER_WALLET"

    QIWI = "QIWI"

    QPAY = "QPAY"

    SADAPAY = "SADAPAY"

    SAJILOPAY = "SAJILOPAY"

    SHOPEEPAY = "SHOPEEPAY"

    SMARTCASH_AIRTEL = "SMARTCASH_AIRTEL"

    TELEBIRR = "TELEBIRR"

    TIGO_MONEY = "TIGO_MONEY"

    TIGO_PESA = "TIGO_PESA"

    TNG_DIGITAL = "TNG_DIGITAL"

    TNM_WALLETS = "TNM_WALLETS"

    TRUEMONEY_WALLET = "TRUEMONEY_WALLET"

    UNIPAGO = "UNIPAGO"

    UWALLET = "UWALLET"

    VNPAY = "VNPAY"

    VNPT_PAY = "VNPT_PAY"

    VODAFONE_MONEY = "VODAFONE_MONEY"

    WECHATPAY = "WECHATPAY"

    WING_MONEY = "WING_MONEY"

    YOAPP = "YOAPP"

    ZAIN_CASH = "ZAIN_CASH"

    ZALOPAY = "ZALOPAY"

    ZAMTEL_MOBILE_MONEY = "ZAMTEL_MOBILE_MONEY"

    UNDEFINED = "UNDEFINED"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
