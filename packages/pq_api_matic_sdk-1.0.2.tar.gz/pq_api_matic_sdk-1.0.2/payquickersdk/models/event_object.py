"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)


class EventObject(object):
    """Implementation of the 'EventObject' model.

    Attributes:
        token (str): [Token](#/rest/models/structures/token) representing the resource
        can_be_cancelled (bool): The model property of type bool.
        event_requirement_category_type (EventRequirementCategories): The model
            property of type EventRequirementCategories.
        event_requirement_type (EventRequirements): The model property of type
            EventRequirements.
        event_status (EventStatuses): Indicates the current verification status type
            of an event.
        event_type (EventTypes): The model property of type EventTypes.
        is_complete (bool): The model property of type bool.
        user_action (UserAction): The model property of type UserAction.
        user_impact (UserImpact): The model property of type UserImpact.
        event (EventCategoryTypes): The type of Registration tied to a particular
            event
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "event": "event",
        "token": "token",
        "can_be_cancelled": "canBeCancelled",
        "event_requirement_category_type": "eventRequirementCategoryType",
        "event_requirement_type": "eventRequirementType",
        "event_status": "eventStatus",
        "event_type": "eventType",
        "is_complete": "isComplete",
        "user_action": "userAction",
        "user_impact": "userImpact",
        "links": "links",
    }

    _optionals = [
        "token",
        "can_be_cancelled",
        "event_requirement_category_type",
        "event_requirement_type",
        "event_status",
        "event_type",
        "is_complete",
        "user_action",
        "user_impact",
        "links",
    ]

    def __init__(
        self,
        event=None,
        token=APIHelper.SKIP,
        can_be_cancelled=APIHelper.SKIP,
        event_requirement_category_type=APIHelper.SKIP,
        event_requirement_type=APIHelper.SKIP,
        event_status=APIHelper.SKIP,
        event_type=APIHelper.SKIP,
        is_complete=APIHelper.SKIP,
        user_action=APIHelper.SKIP,
        user_impact=APIHelper.SKIP,
        links=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a EventObject instance."""
        # Initialize members of the class
        if token is not APIHelper.SKIP:
            self.token = token
        if can_be_cancelled is not APIHelper.SKIP:
            self.can_be_cancelled = can_be_cancelled
        if event_requirement_category_type is not APIHelper.SKIP:
            self.event_requirement_category_type = event_requirement_category_type
        if event_requirement_type is not APIHelper.SKIP:
            self.event_requirement_type = event_requirement_type
        if event_status is not APIHelper.SKIP:
            self.event_status = event_status
        if event_type is not APIHelper.SKIP:
            self.event_type = event_type
        if is_complete is not APIHelper.SKIP:
            self.is_complete = is_complete
        if user_action is not APIHelper.SKIP:
            self.user_action = user_action
        if user_impact is not APIHelper.SKIP:
            self.user_impact = user_impact
        self.event = event
        if links is not APIHelper.SKIP:
            self.links = links

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        event =\
            dictionary.get("event")\
            if dictionary.get("event")\
                else None
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else APIHelper.SKIP
        can_be_cancelled =\
            dictionary.get("canBeCancelled")\
            if "canBeCancelled" in dictionary.keys()\
                else APIHelper.SKIP
        event_requirement_category_type =\
            dictionary.get("eventRequirementCategoryType")\
            if dictionary.get("eventRequirementCategoryType")\
                else APIHelper.SKIP
        event_requirement_type =\
            dictionary.get("eventRequirementType")\
            if dictionary.get("eventRequirementType")\
                else APIHelper.SKIP
        event_status =\
            dictionary.get("eventStatus")\
            if dictionary.get("eventStatus")\
                else APIHelper.SKIP
        event_type =\
            dictionary.get("eventType")\
            if dictionary.get("eventType")\
                else APIHelper.SKIP
        is_complete =\
            dictionary.get("isComplete")\
            if "isComplete" in dictionary.keys()\
                else APIHelper.SKIP
        user_action =\
            dictionary.get("userAction")\
            if dictionary.get("userAction")\
                else APIHelper.SKIP
        user_impact =\
            dictionary.get("userImpact")\
            if dictionary.get("userImpact")\
                else APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(event,
                   token,
                   can_be_cancelled,
                   event_requirement_category_type,
                   event_requirement_type,
                   event_status,
                   event_type,
                   is_complete,
                   user_action,
                   user_impact,
                   links,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _can_be_cancelled=(
            self.can_be_cancelled
            if hasattr(self, "can_be_cancelled")
            else None
        )
        _event_requirement_category_type=(
            self.event_requirement_category_type
            if hasattr(self, "event_requirement_category_type")
            else None
        )
        _event_requirement_type=(
            self.event_requirement_type
            if hasattr(self, "event_requirement_type")
            else None
        )
        _event_status=(
            self.event_status
            if hasattr(self, "event_status")
            else None
        )
        _event_type=(
            self.event_type
            if hasattr(self, "event_type")
            else None
        )
        _is_complete=(
            self.is_complete
            if hasattr(self, "is_complete")
            else None
        )
        _user_action=(
            self.user_action
            if hasattr(self, "user_action")
            else None
        )
        _user_impact=(
            self.user_impact
            if hasattr(self, "user_impact")
            else None
        )
        _event=self.event
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!r}, "
            f"can_be_cancelled={_can_be_cancelled!r}, "
            f"event_requirement_category_type={_event_requirement_category_type!r}, "
            f"event_requirement_type={_event_requirement_type!r}, "
            f"event_status={_event_status!r}, "
            f"event_type={_event_type!r}, "
            f"is_complete={_is_complete!r}, "
            f"user_action={_user_action!r}, "
            f"user_impact={_user_impact!r}, "
            f"event={_event!r}, "
            f"links={_links!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _can_be_cancelled=(
            self.can_be_cancelled
            if hasattr(self, "can_be_cancelled")
            else None
        )
        _event_requirement_category_type=(
            self.event_requirement_category_type
            if hasattr(self, "event_requirement_category_type")
            else None
        )
        _event_requirement_type=(
            self.event_requirement_type
            if hasattr(self, "event_requirement_type")
            else None
        )
        _event_status=(
            self.event_status
            if hasattr(self, "event_status")
            else None
        )
        _event_type=(
            self.event_type
            if hasattr(self, "event_type")
            else None
        )
        _is_complete=(
            self.is_complete
            if hasattr(self, "is_complete")
            else None
        )
        _user_action=(
            self.user_action
            if hasattr(self, "user_action")
            else None
        )
        _user_impact=(
            self.user_impact
            if hasattr(self, "user_impact")
            else None
        )
        _event=self.event
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!s}, "
            f"can_be_cancelled={_can_be_cancelled!s}, "
            f"event_requirement_category_type={_event_requirement_category_type!s}, "
            f"event_requirement_type={_event_requirement_type!s}, "
            f"event_status={_event_status!s}, "
            f"event_type={_event_type!s}, "
            f"is_complete={_is_complete!s}, "
            f"user_action={_user_action!s}, "
            f"user_impact={_user_impact!s}, "
            f"event={_event!s}, "
            f"links={_links!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
