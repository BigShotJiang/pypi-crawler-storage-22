"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class EventRequirements(object):
    """Implementation of the '__EventRequirements' enum.

    Attributes:
        ACH_UPGRADE_PII_DETAILS_VALIDATED: The enum member of type str.
        AGREEMENTS_ACCEPTED: The enum member of type str.
        DOCUMENTS_REQUIRED: The enum member of type str.
        EMAIL_ADDRESS_VERIFIED: The enum member of type str.
        FINANCIAL_PROCESSOR_ACCOUNT_CREATED: The enum member of type str.
        IDENTITY_VERIFIED: The enum member of type str.
        MFA_REGISTRATION_CANCELLED: The enum member of type str.
        MFA_REGISTRATION_CHALLENGE_SENT: The enum member of type str.
        MFA_REGISTRATION_COMPLETED: The enum member of type str.
        MFA_REGISTRATION_PII_COLLECTED: The enum member of type str.
        MFA_REGISTRATION_PROCESSOR_REGISTRATION: The enum member of type str.
        MFA_REGISTRATION_TYPE_CHANGED: The enum member of type str.
        MFA_REGISTRATION_VALIDATION: The enum member of type str.
        ORDER_PLASTIC_CARD: The enum member of type str.
        PEP_SANCTIONS_SCREENING_VERIFIED: The enum member of type str.
        PERSONAL_DETAILS_COLLECTED: The enum member of type str.
        PROCESS_EXECUTED: The enum member of type str.
        TYPE_UNDEFINED: The enum member of type str.
        USER_CREATED: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    ACH_UPGRADE_PII_DETAILS_VALIDATED = "ACH_UPGRADE_PII_DETAILS_VALIDATED"

    AGREEMENTS_ACCEPTED = "AGREEMENTS_ACCEPTED"

    DOCUMENTS_REQUIRED = "DOCUMENTS_REQUIRED"

    EMAIL_ADDRESS_VERIFIED = "EMAIL_ADDRESS_VERIFIED"

    FINANCIAL_PROCESSOR_ACCOUNT_CREATED = "FINANCIAL_PROCESSOR_ACCOUNT_CREATED"

    IDENTITY_VERIFIED = "IDENTITY_VERIFIED"

    MFA_REGISTRATION_CANCELLED = "MFA_REGISTRATION_CANCELLED"

    MFA_REGISTRATION_CHALLENGE_SENT = "MFA_REGISTRATION_CHALLENGE_SENT"

    MFA_REGISTRATION_COMPLETED = "MFA_REGISTRATION_COMPLETED"

    MFA_REGISTRATION_PII_COLLECTED = "MFA_REGISTRATION_PII_COLLECTED"

    MFA_REGISTRATION_PROCESSOR_REGISTRATION = "MFA_REGISTRATION_PROCESSOR_REGISTRATION"

    MFA_REGISTRATION_TYPE_CHANGED = "MFA_REGISTRATION_TYPE_CHANGED"

    MFA_REGISTRATION_VALIDATION = "MFA_REGISTRATION_VALIDATION"

    ORDER_PLASTIC_CARD = "ORDER_PLASTIC_CARD"

    PEP_SANCTIONS_SCREENING_VERIFIED = "PEP_SANCTIONS_SCREENING_VERIFIED"

    PERSONAL_DETAILS_COLLECTED = "PERSONAL_DETAILS_COLLECTED"

    PROCESS_EXECUTED = "PROCESS_EXECUTED"

    TYPE_UNDEFINED = "TYPE_UNDEFINED"

    USER_CREATED = "USER_CREATED"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
