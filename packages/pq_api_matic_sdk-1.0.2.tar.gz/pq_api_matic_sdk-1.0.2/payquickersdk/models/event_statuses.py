"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class EventStatuses(object):
    """Implementation of the '__EventStatuses' enum.

    Indicates the current verification status type of an event.

    Attributes:
        UNDEFINED: TO BE DONE
        CANCELLED: Processing of the event has been canceled.
        COMPLETED: Processing of the event has been completed.
        IN_PROGRESS: The event is currently being processed.
        PENDING: The event is waiting to be processed.
        SUSPENDED: The event processing has been suspended.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    UNDEFINED = "UNDEFINED"

    CANCELLED = "CANCELLED"

    COMPLETED = "COMPLETED"

    IN_PROGRESS = "IN_PROGRESS"

    PENDING = "PENDING"

    SUSPENDED = "SUSPENDED"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
