"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.fee_distribution import (
    FeeDistribution,
)


class FeeConfiguration(object):
    """Implementation of the '_FeeConfiguration' model.

    Attributes:
        category (CategoryTypes): Category types
        distribution (List[FeeDistribution]): The model property of type
            List[FeeDistribution].
        source (FeeSources): Fee source types
        total_amount (float): Total amount of money for all transactions
        transaction_amount (float): Total amount of money for the transaction
        mtype (Fees): Fee types
        value_amount (str): Value of the target resource
        value_type (FeeValues): Fee value types
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "category": "category",
        "distribution": "distribution",
        "source": "source",
        "total_amount": "totalAmount",
        "transaction_amount": "transactionAmount",
        "mtype": "type",
        "value_amount": "valueAmount",
        "value_type": "valueType",
    }

    _optionals = [
        "category",
        "distribution",
        "source",
        "total_amount",
        "transaction_amount",
        "mtype",
        "value_amount",
        "value_type",
    ]

    def __init__(
        self,
        category=APIHelper.SKIP,
        distribution=APIHelper.SKIP,
        source=APIHelper.SKIP,
        total_amount=APIHelper.SKIP,
        transaction_amount=APIHelper.SKIP,
        mtype=APIHelper.SKIP,
        value_amount=APIHelper.SKIP,
        value_type=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a FeeConfiguration instance."""
        # Initialize members of the class
        if category is not APIHelper.SKIP:
            self.category = category
        if distribution is not APIHelper.SKIP:
            self.distribution = distribution
        if source is not APIHelper.SKIP:
            self.source = source
        if total_amount is not APIHelper.SKIP:
            self.total_amount = total_amount
        if transaction_amount is not APIHelper.SKIP:
            self.transaction_amount = transaction_amount
        if mtype is not APIHelper.SKIP:
            self.mtype = mtype
        if value_amount is not APIHelper.SKIP:
            self.value_amount = value_amount
        if value_type is not APIHelper.SKIP:
            self.value_type = value_type

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        category =\
            dictionary.get("category")\
            if dictionary.get("category")\
                else APIHelper.SKIP
        distribution = None
        if dictionary.get("distribution") is not None:
            distribution = [
                FeeDistribution.from_dictionary(x)
                    for x in dictionary.get("distribution")
            ]
        else:
            distribution = APIHelper.SKIP
        source =\
            dictionary.get("source")\
            if dictionary.get("source")\
                else APIHelper.SKIP
        total_amount =\
            dictionary.get("totalAmount")\
            if dictionary.get("totalAmount")\
                else APIHelper.SKIP
        transaction_amount =\
            dictionary.get("transactionAmount")\
            if dictionary.get("transactionAmount")\
                else APIHelper.SKIP
        mtype =\
            dictionary.get("type")\
            if dictionary.get("type")\
                else APIHelper.SKIP
        value_amount =\
            dictionary.get("valueAmount")\
            if dictionary.get("valueAmount")\
                else APIHelper.SKIP
        value_type =\
            dictionary.get("valueType")\
            if dictionary.get("valueType")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(category,
                   distribution,
                   source,
                   total_amount,
                   transaction_amount,
                   mtype,
                   value_amount,
                   value_type,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _category=(
            self.category
            if hasattr(self, "category")
            else None
        )
        _distribution=(
            self.distribution
            if hasattr(self, "distribution")
            else None
        )
        _source=(
            self.source
            if hasattr(self, "source")
            else None
        )
        _total_amount=(
            self.total_amount
            if hasattr(self, "total_amount")
            else None
        )
        _transaction_amount=(
            self.transaction_amount
            if hasattr(self, "transaction_amount")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _value_amount=(
            self.value_amount
            if hasattr(self, "value_amount")
            else None
        )
        _value_type=(
            self.value_type
            if hasattr(self, "value_type")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"category={_category!r}, "
            f"distribution={_distribution!r}, "
            f"source={_source!r}, "
            f"total_amount={_total_amount!r}, "
            f"transaction_amount={_transaction_amount!r}, "
            f"mtype={_mtype!r}, "
            f"value_amount={_value_amount!r}, "
            f"value_type={_value_type!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _category=(
            self.category
            if hasattr(self, "category")
            else None
        )
        _distribution=(
            self.distribution
            if hasattr(self, "distribution")
            else None
        )
        _source=(
            self.source
            if hasattr(self, "source")
            else None
        )
        _total_amount=(
            self.total_amount
            if hasattr(self, "total_amount")
            else None
        )
        _transaction_amount=(
            self.transaction_amount
            if hasattr(self, "transaction_amount")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _value_amount=(
            self.value_amount
            if hasattr(self, "value_amount")
            else None
        )
        _value_type=(
            self.value_type
            if hasattr(self, "value_type")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"category={_category!s}, "
            f"distribution={_distribution!s}, "
            f"source={_source!s}, "
            f"total_amount={_total_amount!s}, "
            f"transaction_amount={_transaction_amount!s}, "
            f"mtype={_mtype!s}, "
            f"value_amount={_value_amount!s}, "
            f"value_type={_value_type!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
