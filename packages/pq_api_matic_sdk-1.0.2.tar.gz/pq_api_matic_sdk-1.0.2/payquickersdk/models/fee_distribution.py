"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.receipt_descriptions import (
    ReceiptDescriptions,
)


class FeeDistribution(object):
    """Implementation of the '_FeeDistribution' model.

    Attributes:
        amount (float): Allocated money to be sent in the transaction.
        currency (Currencies): [Currency code type](#/rest/models/structures/country)
            for the object
        description (List[ReceiptDescriptions]): The model property of type
            List[ReceiptDescriptions].
        formatted_amount (str): Combination of the amount and currency type
        percentage (float): Fee percentage that the responsible account pays
        responsibility (FeeResponsibilityParties): Fee responsibility types
        responsibility_source (FeeResponsibilitySources): Fee responsibility source
            types
        source_token (str): Unique identifier representing the [source of
            funds](#/rest/models/structures/source-token)
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "amount": "amount",
        "currency": "currency",
        "description": "description",
        "formatted_amount": "formattedAmount",
        "percentage": "percentage",
        "responsibility": "responsibility",
        "responsibility_source": "responsibilitySource",
        "source_token": "sourceToken",
    }

    _optionals = [
        "amount",
        "currency",
        "description",
        "formatted_amount",
        "percentage",
        "responsibility",
        "responsibility_source",
        "source_token",
    ]

    def __init__(
        self,
        amount=1.02,
        currency="USD",
        description=APIHelper.SKIP,
        formatted_amount="$0.05 USD",
        percentage=APIHelper.SKIP,
        responsibility=APIHelper.SKIP,
        responsibility_source=APIHelper.SKIP,
        source_token="acct-3908ab5a-6ce1-474d-8b80-a63a7b147860",
        additional_properties=None):
        """Initialize a FeeDistribution instance."""
        # Initialize members of the class
        self.amount = amount
        self.currency = currency
        if description is not APIHelper.SKIP:
            self.description = description
        self.formatted_amount = formatted_amount
        if percentage is not APIHelper.SKIP:
            self.percentage = percentage
        if responsibility is not APIHelper.SKIP:
            self.responsibility = responsibility
        if responsibility_source is not APIHelper.SKIP:
            self.responsibility_source = responsibility_source
        self.source_token = source_token

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        amount =\
            dictionary.get("amount")\
            if dictionary.get("amount")\
                else 1.02
        currency =\
            dictionary.get("currency")\
            if dictionary.get("currency")\
                else "USD"
        description = None
        if dictionary.get("description") is not None:
            description = [
                ReceiptDescriptions.from_dictionary(x)
                    for x in dictionary.get("description")
            ]
        else:
            description = APIHelper.SKIP
        formatted_amount =\
            dictionary.get("formattedAmount")\
            if dictionary.get("formattedAmount")\
                else "$0.05 USD"
        percentage =\
            dictionary.get("percentage")\
            if dictionary.get("percentage")\
                else APIHelper.SKIP
        responsibility =\
            dictionary.get("responsibility")\
            if dictionary.get("responsibility")\
                else APIHelper.SKIP
        responsibility_source =\
            dictionary.get("responsibilitySource")\
            if dictionary.get("responsibilitySource")\
                else APIHelper.SKIP
        source_token =\
            dictionary.get("sourceToken")\
            if dictionary.get("sourceToken")\
                else "acct-3908ab5a-6ce1-474d-8b80-a63a7b147860"

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(amount,
                   currency,
                   description,
                   formatted_amount,
                   percentage,
                   responsibility,
                   responsibility_source,
                   source_token,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _amount=(
            self.amount
            if hasattr(self, "amount")
            else None
        )
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _description=(
            self.description
            if hasattr(self, "description")
            else None
        )
        _formatted_amount=(
            self.formatted_amount
            if hasattr(self, "formatted_amount")
            else None
        )
        _percentage=(
            self.percentage
            if hasattr(self, "percentage")
            else None
        )
        _responsibility=(
            self.responsibility
            if hasattr(self, "responsibility")
            else None
        )
        _responsibility_source=(
            self.responsibility_source
            if hasattr(self, "responsibility_source")
            else None
        )
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"amount={_amount!r}, "
            f"currency={_currency!r}, "
            f"description={_description!r}, "
            f"formatted_amount={_formatted_amount!r}, "
            f"percentage={_percentage!r}, "
            f"responsibility={_responsibility!r}, "
            f"responsibility_source={_responsibility_source!r}, "
            f"source_token={_source_token!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _amount=(
            self.amount
            if hasattr(self, "amount")
            else None
        )
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _description=(
            self.description
            if hasattr(self, "description")
            else None
        )
        _formatted_amount=(
            self.formatted_amount
            if hasattr(self, "formatted_amount")
            else None
        )
        _percentage=(
            self.percentage
            if hasattr(self, "percentage")
            else None
        )
        _responsibility=(
            self.responsibility
            if hasattr(self, "responsibility")
            else None
        )
        _responsibility_source=(
            self.responsibility_source
            if hasattr(self, "responsibility_source")
            else None
        )
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"amount={_amount!s}, "
            f"currency={_currency!s}, "
            f"description={_description!s}, "
            f"formatted_amount={_formatted_amount!s}, "
            f"percentage={_percentage!s}, "
            f"responsibility={_responsibility!s}, "
            f"responsibility_source={_responsibility_source!s}, "
            f"source_token={_source_token!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
