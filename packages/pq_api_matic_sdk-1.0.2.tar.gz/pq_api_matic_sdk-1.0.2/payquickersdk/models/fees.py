"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class Fees(object):
    """Implementation of the '__Fees' enum.

    Fee types

    Attributes:
        BANK_TRANSFER_REVERSAL_STOP_NOC: The enum member of type str.
        PAPER_CHECK_STOP: The enum member of type str.
        INSTANT_PAYMENT: The enum member of type str.
        ACCOUNT_DIRECT_DEPOSIT: The enum member of type str.
        INBOUND_WIRE: The enum member of type str.
        PLASTIC_CARD_PURCHASE_DECLINED: The enum member of type str.
        ATM_DECLINED: The enum member of type str.
        CLEAR_NEGATIVE_BALANCE: The enum member of type str.
        PLASTIC_CARD_ISSUANCE: The enum member of type str.
        PLASTIC_CARD_REPLACEMENT_FRAUD: The enum member of type str.
        PLASTIC_CARD_REPLACEMENT_LOST_OR_STOLEN: The enum member of type str.
        PLASTIC_CARD_REPLACEMENT_EXPIRED: The enum member of type str.
        BANK_TRANSFER_CURRENCY_CONVERSION: The enum member of type str.
        PAPER_CHECK_ISSUANCE_CURRENCY_CONVERSION: The enum member of type str.
        PLASTIC_CARD_PIN_PURCHASE: The enum member of type str.
        FOREIGN_EXCHANGE_CONVERSION: The enum member of type str.
        ATM_CASH_WITHDRAWAL_REMOTE_CURRENCY_FOREIGN_EXCHANGE: The enum member of type
            str.
        PAPER_STATEMENT: The enum member of type str.
        BANK_TRANSFER: The enum member of type str.
        PAPER_CHECK_ISSUANCE: The enum member of type str.
        ACCOUNT_ENROLLMENT: The enum member of type str.
        MONTHLY_MAINTENANCE_INACTIVE_ACCOUNT: The enum member of type str.
        MONTHLY_MAINTENANCE_ACTIVE_ACCOUNT: The enum member of type str.
        ACCOUNT_CLOSURE: The enum member of type str.
        PLASTIC_CARD_PURCHASE_OUTSIDE_USA: The enum member of type str.
        EXTERNAL_INITIATED_BANK_TRANSFER: The enum member of type str.
        CO_BRANDED_ACCOUNT_PROCESSING_ORDER_FEE: The enum member of type str.
        ATM_CASH_WITHDRAWAL_FEE_LOCAL_CURRENCY: The enum member of type str.
        ATM_CASH_WITHDRAWAL_FEE_OUTSIDE_CURRENCY: The enum member of type str.
        ATM_BALANCE_INQUIRY_FEE: The enum member of type str.
        BANK_TELLER_CASH_WITHDRAWAL_FEE: The enum member of type str.
        BANK_TELLER_CASH_WITHDRAWAL_DECLINE_FEE: The enum member of type str.
        COMPANY_BULK_MONTHLY_FEE: The enum member of type str.
        PAYMENT_ESCHEATMENT_FEE: The enum member of type str.
        SPENDBACK_PROCESSING_FEE: The enum member of type str.
        VIRTUAL_PLASTIC_CARD_REPLACEMENT_FRAUD: The enum member of type str.
        VIRTUAL_PLASTIC_CARD_REPLACEMENT_LOST_OR_STOLEN: The enum member of type str.
        VIRTUAL_PLASTIC_CARD_REPLACEMENT_EXPIRED: The enum member of type str.
        REVERSE_FEE: The enum member of type str.
        LOAD_SERVICE_FEE: The enum member of type str.
        PAYMENT_SUBSCRIPTION_FEE: The enum member of type str.
        AUTO_ACH_FEE: The enum member of type str.
        UNDEFINED: The enum member of type str.
        BULK_MONTHLY_FEE: The enum member of type str.
        VIRTUAL_PLASTIC_CARD_ISSUANCE: The enum member of type str.
        ELECTRONIC_WALLET_TRANSFER: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    BANK_TRANSFER_REVERSAL_STOP_NOC = "BANK_TRANSFER_REVERSAL_STOP_NOC"

    PAPER_CHECK_STOP = "PAPER_CHECK_STOP"

    INSTANT_PAYMENT = "INSTANT_PAYMENT"

    ACCOUNT_DIRECT_DEPOSIT = "ACCOUNT_DIRECT_DEPOSIT"

    INBOUND_WIRE = "INBOUND_WIRE"

    PLASTIC_CARD_PURCHASE_DECLINED = "PLASTIC_CARD_PURCHASE_DECLINED"

    ATM_DECLINED = "ATM_DECLINED"

    CLEAR_NEGATIVE_BALANCE = "CLEAR_NEGATIVE_BALANCE"

    PLASTIC_CARD_ISSUANCE = "PLASTIC_CARD_ISSUANCE"

    PLASTIC_CARD_REPLACEMENT_FRAUD = "PLASTIC_CARD_REPLACEMENT_FRAUD"

    PLASTIC_CARD_REPLACEMENT_LOST_OR_STOLEN = "PLASTIC_CARD_REPLACEMENT_LOST_OR_STOLEN"

    PLASTIC_CARD_REPLACEMENT_EXPIRED = "PLASTIC_CARD_REPLACEMENT_EXPIRED"

    BANK_TRANSFER_CURRENCY_CONVERSION = "BANK_TRANSFER_CURRENCY_CONVERSION"

    PAPER_CHECK_ISSUANCE_CURRENCY_CONVERSION = "PAPER_CHECK_ISSUANCE_CURRENCY_CONVERSION" # noqa: E501

    PLASTIC_CARD_PIN_PURCHASE = "PLASTIC_CARD_PIN_PURCHASE"

    FOREIGN_EXCHANGE_CONVERSION = "FOREIGN_EXCHANGE_CONVERSION"

    ATM_CASH_WITHDRAWAL_REMOTE_CURRENCY_FOREIGN_EXCHANGE = "ATM_CASH_WITHDRAWAL_REMOTE_CURRENCY_FOREIGN_EXCHANGE" # noqa: E501

    PAPER_STATEMENT = "PAPER_STATEMENT"

    BANK_TRANSFER = "BANK_TRANSFER"

    PAPER_CHECK_ISSUANCE = "PAPER_CHECK_ISSUANCE"

    ACCOUNT_ENROLLMENT = "ACCOUNT_ENROLLMENT"

    MONTHLY_MAINTENANCE_INACTIVE_ACCOUNT = "MONTHLY_MAINTENANCE_INACTIVE_ACCOUNT"

    MONTHLY_MAINTENANCE_ACTIVE_ACCOUNT = "MONTHLY_MAINTENANCE_ACTIVE_ACCOUNT"

    ACCOUNT_CLOSURE = "ACCOUNT_CLOSURE"

    PLASTIC_CARD_PURCHASE_OUTSIDE_USA = "PLASTIC_CARD_PURCHASE_OUTSIDE_USA"

    EXTERNAL_INITIATED_BANK_TRANSFER = "EXTERNAL_INITIATED_BANK_TRANSFER"

    CO_BRANDED_ACCOUNT_PROCESSING_ORDER_FEE = "CO_BRANDED_ACCOUNT_PROCESSING_ORDER_FEE"

    ATM_CASH_WITHDRAWAL_FEE_LOCAL_CURRENCY = "ATM_CASH_WITHDRAWAL_FEE_LOCAL_CURRENCY"

    ATM_CASH_WITHDRAWAL_FEE_OUTSIDE_CURRENCY = "ATM_CASH_WITHDRAWAL_FEE_OUTSIDE_CURRENCY" # noqa: E501

    ATM_BALANCE_INQUIRY_FEE = "ATM_BALANCE_INQUIRY_FEE"

    BANK_TELLER_CASH_WITHDRAWAL_FEE = "BANK_TELLER_CASH_WITHDRAWAL_FEE"

    BANK_TELLER_CASH_WITHDRAWAL_DECLINE_FEE = "BANK_TELLER_CASH_WITHDRAWAL_DECLINE_FEE"

    COMPANY_BULK_MONTHLY_FEE = "COMPANY_BULK_MONTHLY_FEE"

    PAYMENT_ESCHEATMENT_FEE = "PAYMENT_ESCHEATMENT_FEE"

    SPENDBACK_PROCESSING_FEE = "SPENDBACK_PROCESSING_FEE"

    VIRTUAL_PLASTIC_CARD_REPLACEMENT_FRAUD = "VIRTUAL_PLASTIC_CARD_REPLACEMENT_FRAUD"

    VIRTUAL_PLASTIC_CARD_REPLACEMENT_LOST_OR_STOLEN = "VIRTUAL_PLASTIC_CARD_REPLACEMENT_LOST_OR_STOLEN" # noqa: E501

    VIRTUAL_PLASTIC_CARD_REPLACEMENT_EXPIRED = "VIRTUAL_PLASTIC_CARD_REPLACEMENT_EXPIRED" # noqa: E501

    REVERSE_FEE = "REVERSE_FEE"

    LOAD_SERVICE_FEE = "LOAD_SERVICE_FEE"

    PAYMENT_SUBSCRIPTION_FEE = "PAYMENT_SUBSCRIPTION_FEE"

    AUTO_ACH_FEE = "AUTO_ACH_FEE"

    UNDEFINED = "UNDEFINED"

    BULK_MONTHLY_FEE = "BULK_MONTHLY_FEE"

    VIRTUAL_PLASTIC_CARD_ISSUANCE = "VIRTUAL_PLASTIC_CARD_ISSUANCE"

    ELECTRONIC_WALLET_TRANSFER = "ELECTRONIC_WALLET_TRANSFER"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
