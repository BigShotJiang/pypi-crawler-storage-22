"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class FxRate(object):
    """Implementation of the '_FxRate' model.

    Exchange rate

    Attributes:
        destination_amount (float): Allocated money to be sent in the transaction.
        destination_currency (Currencies): [Currency code
            type](#/rest/models/structures/country) for the object
        destination_formatted_amount (str): Combination of the amount and currency
            type
        rate (float): Exchange [rate](#/rest/models/structures/rate)
        source_amount (float): Allocated money to be sent in the transaction.
        source_currency (Currencies): [Currency code
            type](#/rest/models/structures/country) for the object
        source_formatted_amount (str): Combination of the amount and currency type
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "destination_amount": "destinationAmount",
        "destination_currency": "destinationCurrency",
        "destination_formatted_amount": "destinationFormattedAmount",
        "rate": "rate",
        "source_amount": "sourceAmount",
        "source_currency": "sourceCurrency",
        "source_formatted_amount": "sourceFormattedAmount",
    }

    _optionals = [
        "destination_amount",
        "destination_currency",
        "destination_formatted_amount",
        "rate",
        "source_amount",
        "source_currency",
        "source_formatted_amount",
    ]

    def __init__(
        self,
        destination_amount=APIHelper.SKIP,
        destination_currency="USD",
        destination_formatted_amount="$0.05 USD",
        rate=APIHelper.SKIP,
        source_amount=1.02,
        source_currency="USD",
        source_formatted_amount="$0.05 USD",
        additional_properties=None):
        """Initialize a FxRate instance."""
        # Initialize members of the class
        if destination_amount is not APIHelper.SKIP:
            self.destination_amount = destination_amount
        self.destination_currency = destination_currency
        self.destination_formatted_amount = destination_formatted_amount
        if rate is not APIHelper.SKIP:
            self.rate = rate
        self.source_amount = source_amount
        self.source_currency = source_currency
        self.source_formatted_amount = source_formatted_amount

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        destination_amount =\
            dictionary.get("destinationAmount")\
            if dictionary.get("destinationAmount")\
                else APIHelper.SKIP
        destination_currency =\
            dictionary.get("destinationCurrency")\
            if dictionary.get("destinationCurrency")\
                else "USD"
        destination_formatted_amount =\
            dictionary.get("destinationFormattedAmount")\
            if dictionary.get("destinationFormattedAmount")\
                else "$0.05 USD"
        rate =\
            dictionary.get("rate")\
            if dictionary.get("rate")\
                else APIHelper.SKIP
        source_amount =\
            dictionary.get("sourceAmount")\
            if dictionary.get("sourceAmount")\
                else 1.02
        source_currency =\
            dictionary.get("sourceCurrency")\
            if dictionary.get("sourceCurrency")\
                else "USD"
        source_formatted_amount =\
            dictionary.get("sourceFormattedAmount")\
            if dictionary.get("sourceFormattedAmount")\
                else "$0.05 USD"

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(destination_amount,
                   destination_currency,
                   destination_formatted_amount,
                   rate,
                   source_amount,
                   source_currency,
                   source_formatted_amount,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _destination_amount=(
            self.destination_amount
            if hasattr(self, "destination_amount")
            else None
        )
        _destination_currency=(
            self.destination_currency
            if hasattr(self, "destination_currency")
            else None
        )
        _destination_formatted_amount=(
            self.destination_formatted_amount
            if hasattr(self, "destination_formatted_amount")
            else None
        )
        _rate=(
            self.rate
            if hasattr(self, "rate")
            else None
        )
        _source_amount=(
            self.source_amount
            if hasattr(self, "source_amount")
            else None
        )
        _source_currency=(
            self.source_currency
            if hasattr(self, "source_currency")
            else None
        )
        _source_formatted_amount=(
            self.source_formatted_amount
            if hasattr(self, "source_formatted_amount")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"destination_amount={_destination_amount!r}, "
            f"destination_currency={_destination_currency!r}, "
            f"destination_formatted_amount={_destination_formatted_amount!r}, "
            f"rate={_rate!r}, "
            f"source_amount={_source_amount!r}, "
            f"source_currency={_source_currency!r}, "
            f"source_formatted_amount={_source_formatted_amount!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _destination_amount=(
            self.destination_amount
            if hasattr(self, "destination_amount")
            else None
        )
        _destination_currency=(
            self.destination_currency
            if hasattr(self, "destination_currency")
            else None
        )
        _destination_formatted_amount=(
            self.destination_formatted_amount
            if hasattr(self, "destination_formatted_amount")
            else None
        )
        _rate=(
            self.rate
            if hasattr(self, "rate")
            else None
        )
        _source_amount=(
            self.source_amount
            if hasattr(self, "source_amount")
            else None
        )
        _source_currency=(
            self.source_currency
            if hasattr(self, "source_currency")
            else None
        )
        _source_formatted_amount=(
            self.source_formatted_amount
            if hasattr(self, "source_formatted_amount")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"destination_amount={_destination_amount!s}, "
            f"destination_currency={_destination_currency!s}, "
            f"destination_formatted_amount={_destination_formatted_amount!s}, "
            f"rate={_rate!s}, "
            f"source_amount={_source_amount!s}, "
            f"source_currency={_source_currency!s}, "
            f"source_formatted_amount={_source_formatted_amount!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
