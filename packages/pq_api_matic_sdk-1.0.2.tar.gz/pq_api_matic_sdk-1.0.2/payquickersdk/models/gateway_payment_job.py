"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.gateway_payment_job_quote import (
    GatewayPaymentJobQuote,
)


class GatewayPaymentJob(object):
    """Implementation of the 'Gateway Payment Job' model.

    TODO1

    Attributes:
        not_before (datetime):
            [Transfer](#/rest/models/structures/not-before-or-after) is scheduled and
            will not process before this time.
        not_after (datetime):
            [Transfer](#/rest/models/structures/not-before-or-after) expires if not
            completed prior to this time.
        items (List[GatewayPaymentJobQuote]): The model property of type
            List[GatewayPaymentJobQuote].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "not_before": "notBefore",
        "not_after": "notAfter",
        "items": "items",
    }

    _optionals = [
        "not_before",
        "not_after",
        "items",
    ]

    def __init__(
        self,
        not_before=APIHelper.SKIP,
        not_after=APIHelper.SKIP,
        items=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a GatewayPaymentJob instance."""
        # Initialize members of the class
        if not_before is not APIHelper.SKIP:
            self.not_before =\
                 APIHelper.apply_datetime_converter(
                not_before, APIHelper.RFC3339DateTime)\
                 if not_before else None
        if not_after is not APIHelper.SKIP:
            self.not_after =\
                 APIHelper.apply_datetime_converter(
                not_after, APIHelper.RFC3339DateTime)\
                 if not_after else None
        if items is not APIHelper.SKIP:
            self.items = items

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        not_before = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("notBefore")).datetime\
            if dictionary.get("notBefore") else APIHelper.SKIP
        not_after = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("notAfter")).datetime\
            if dictionary.get("notAfter") else APIHelper.SKIP
        items = None
        if dictionary.get("items") is not None:
            items = [
                GatewayPaymentJobQuote.from_dictionary(x)
                    for x in dictionary.get("items")
            ]
        else:
            items = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(not_before,
                   not_after,
                   items,
                   additional_properties)

    @classmethod
    def validate(cls, dictionary):
        """Validate dictionary against class required properties

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            boolean : if dictionary is valid contains required properties.

        """
        if isinstance(dictionary, cls):
            return True

        if not isinstance(dictionary, dict):
            return False

        return True

    def __repr__(self):
        """Return a unambiguous string representation."""
        _not_before=(
            self.not_before
            if hasattr(self, "not_before")
            else None
        )
        _not_after=(
            self.not_after
            if hasattr(self, "not_after")
            else None
        )
        _items=(
            self.items
            if hasattr(self, "items")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"not_before={_not_before!r}, "
            f"not_after={_not_after!r}, "
            f"items={_items!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _not_before=(
            self.not_before
            if hasattr(self, "not_before")
            else None
        )
        _not_after=(
            self.not_after
            if hasattr(self, "not_after")
            else None
        )
        _items=(
            self.items
            if hasattr(self, "items")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"not_before={_not_before!s}, "
            f"not_after={_not_after!s}, "
            f"items={_items!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
