"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class GatewayPaymentJobQuote(object):
    """Implementation of the 'Gateway Payment Job Quote' model.

    TODO 2

    Attributes:
        amount (float): Allocated money to be sent in the transaction.
        currency (Currencies): [Currency code type](#/rest/models/structures/country)
            for the object
        source_token (str): Unique identifier representing the [source of
            funds](#/rest/models/structures/source-token)
        destination_token (str): Unique identifier representing the [destination of
            funds](#/rest/models/structures/destination-token)
        note (str): [Optional comments](#/rest/models/structures/notes) visible to
            the user
        memo (str): Optional internal [memo](#/rest/models/structures/memo) not
            visible to the user
        purpose (PaymentPurposes): Used to identify the [purpose of a
            payment](#/models/structures/payment-object) and impacts reporting and
            calculated taxable earnings (if utilizing tax services)
        client_payment_id (str): Unique value provided by the client for the
            [payment](page:resources/payments), utilized for reference and
            deduplication.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "amount": "amount",
        "currency": "currency",
        "source_token": "sourceToken",
        "destination_token": "destinationToken",
        "note": "note",
        "memo": "memo",
        "purpose": "purpose",
        "client_payment_id": "clientPaymentId",
    }

    _optionals = [
        "amount",
        "currency",
        "source_token",
        "destination_token",
        "note",
        "memo",
        "purpose",
        "client_payment_id",
    ]

    def __init__(
        self,
        amount=1.02,
        currency="USD",
        source_token="acct-3908ab5a-6ce1-474d-8b80-a63a7b147860",
        destination_token="dest-631b200f-665d-4dbe-bd01-3063c9dec97d",
        note=APIHelper.SKIP,
        memo=APIHelper.SKIP,
        purpose=APIHelper.SKIP,
        client_payment_id="d4b6f130-1d1c-4ce2-903a-0c1ad128f55e",
        additional_properties=None):
        """Initialize a GatewayPaymentJobQuote instance."""
        # Initialize members of the class
        self.amount = amount
        self.currency = currency
        self.source_token = source_token
        self.destination_token = destination_token
        if note is not APIHelper.SKIP:
            self.note = note
        if memo is not APIHelper.SKIP:
            self.memo = memo
        if purpose is not APIHelper.SKIP:
            self.purpose = purpose
        self.client_payment_id = client_payment_id

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        amount =\
            dictionary.get("amount")\
            if dictionary.get("amount")\
                else 1.02
        currency =\
            dictionary.get("currency")\
            if dictionary.get("currency")\
                else "USD"
        source_token =\
            dictionary.get("sourceToken")\
            if dictionary.get("sourceToken")\
                else "acct-3908ab5a-6ce1-474d-8b80-a63a7b147860"
        destination_token =\
            dictionary.get("destinationToken")\
            if dictionary.get("destinationToken")\
                else "dest-631b200f-665d-4dbe-bd01-3063c9dec97d"
        note =\
            dictionary.get("note")\
            if dictionary.get("note")\
                else APIHelper.SKIP
        memo =\
            dictionary.get("memo")\
            if dictionary.get("memo")\
                else APIHelper.SKIP
        purpose =\
            dictionary.get("purpose")\
            if dictionary.get("purpose")\
                else APIHelper.SKIP
        client_payment_id =\
            dictionary.get("clientPaymentId")\
            if dictionary.get("clientPaymentId")\
                else "d4b6f130-1d1c-4ce2-903a-0c1ad128f55e"

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(amount,
                   currency,
                   source_token,
                   destination_token,
                   note,
                   memo,
                   purpose,
                   client_payment_id,
                   additional_properties)

    @classmethod
    def validate(cls, dictionary):
        """Validate dictionary against class required properties

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            boolean : if dictionary is valid contains required properties.

        """
        if isinstance(dictionary, cls):
            return True

        if not isinstance(dictionary, dict):
            return False

        return True

    def __repr__(self):
        """Return a unambiguous string representation."""
        _amount=(
            self.amount
            if hasattr(self, "amount")
            else None
        )
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _destination_token=(
            self.destination_token
            if hasattr(self, "destination_token")
            else None
        )
        _note=(
            self.note
            if hasattr(self, "note")
            else None
        )
        _memo=(
            self.memo
            if hasattr(self, "memo")
            else None
        )
        _purpose=(
            self.purpose
            if hasattr(self, "purpose")
            else None
        )
        _client_payment_id=(
            self.client_payment_id
            if hasattr(self, "client_payment_id")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"amount={_amount!r}, "
            f"currency={_currency!r}, "
            f"source_token={_source_token!r}, "
            f"destination_token={_destination_token!r}, "
            f"note={_note!r}, "
            f"memo={_memo!r}, "
            f"purpose={_purpose!r}, "
            f"client_payment_id={_client_payment_id!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _amount=(
            self.amount
            if hasattr(self, "amount")
            else None
        )
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _destination_token=(
            self.destination_token
            if hasattr(self, "destination_token")
            else None
        )
        _note=(
            self.note
            if hasattr(self, "note")
            else None
        )
        _memo=(
            self.memo
            if hasattr(self, "memo")
            else None
        )
        _purpose=(
            self.purpose
            if hasattr(self, "purpose")
            else None
        )
        _client_payment_id=(
            self.client_payment_id
            if hasattr(self, "client_payment_id")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"amount={_amount!s}, "
            f"currency={_currency!s}, "
            f"source_token={_source_token!s}, "
            f"destination_token={_destination_token!s}, "
            f"note={_note!s}, "
            f"memo={_memo!s}, "
            f"purpose={_purpose!s}, "
            f"client_payment_id={_client_payment_id!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
