"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class GovernmentIds(object):
    """Implementation of the '__GovernmentIds' enum.

    Indicates the type of ID submitted for user verification purposes.

    Attributes:
        CURP: Identity code for both citizens and residents of Mexico.
        NATIONAL_ID_CARD: Identity card with a photo issued by an official authority.
        PASSPORT: Travel document that certifies the identity and nationality of its
            holder.
        SSN: Social Security number for citizens of the United States.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    CURP = "CURP"

    NATIONAL_ID_CARD = "NATIONAL_ID_CARD"

    PASSPORT = "PASSPORT"

    SSN = "SSN"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
