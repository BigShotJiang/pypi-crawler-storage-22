"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
class HateoasRelationship(object):
    """Implementation of the '_HateoasRelationship' model.

    Indicates the HATEOS relationship between the target and current resources.

    Attributes:
        rel (str): Indicates the relationship between the target and current
            resources.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "rel": "rel",
    }

    def __init__(
        self,
        rel="self",
        additional_properties=None):
        """Initialize a HateoasRelationship instance."""
        # Initialize members of the class
        self.rel = rel

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        rel =\
            dictionary.get("rel")\
            if dictionary.get("rel")\
                else "self"

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(rel,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _rel=self.rel
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"rel={_rel!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _rel=self.rel
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"rel={_rel!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
