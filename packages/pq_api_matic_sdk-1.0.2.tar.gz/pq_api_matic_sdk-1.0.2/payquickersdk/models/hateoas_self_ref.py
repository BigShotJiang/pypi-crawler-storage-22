"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.hateoas_relationship import (
    HateoasRelationship,
)


class HateoasSelfRef(object):
    """Implementation of the '_HateoasSelfRef' model.

    Indicates the external link with the full URL of the same page on which the link
    appears.

    Attributes:
        href (str): The model property of type str.
        params (HateoasRelationship): Indicates the HATEOS relationship between the
            target and current resources.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "href": "href",
        "params": "params",
    }

    _optionals = [
        "href",
        "params",
    ]

    def __init__(
        self,
        href=APIHelper.SKIP,
        params=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a HateoasSelfRef instance."""
        # Initialize members of the class
        if href is not APIHelper.SKIP:
            self.href = href
        if params is not APIHelper.SKIP:
            self.params = params

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        href =\
            dictionary.get("href")\
            if dictionary.get("href")\
                else APIHelper.SKIP
        params =\
            HateoasRelationship.from_dictionary(
                dictionary.get("params"))\
                if "params" in dictionary.keys()\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(href,
                   params,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _href=(
            self.href
            if hasattr(self, "href")
            else None
        )
        _params=(
            self.params
            if hasattr(self, "params")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"href={_href!r}, "
            f"params={_params!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _href=(
            self.href
            if hasattr(self, "href")
            else None
        )
        _params=(
            self.params
            if hasattr(self, "params")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"href={_href!s}, "
            f"params={_params!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
