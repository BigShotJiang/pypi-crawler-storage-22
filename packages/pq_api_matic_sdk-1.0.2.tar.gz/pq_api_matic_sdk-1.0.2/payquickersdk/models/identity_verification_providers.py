"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class IdentityVerificationProviders(object):
    """Implementation of the '__IdentityVerificationProviders' enum.

    Provider types of
    [verification](#/rest/models/structures/identity-verification-provider-type) that
    can be used for performing identity checks

    Attributes:
        EQUIFAX: The enum member of type str.
        W2: The enum member of type str.
        FISIDOLOGY: The enum member of type str.
        OFACANALYZER: The enum member of type str.
        UNDEFINED: The enum member of type str.
        HOOYU: The enum member of type str.
        LEXISNEXISIVI: The enum member of type str.
        QOLO: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    EQUIFAX = "EQUIFAX"

    W2 = "W2"

    FISIDOLOGY = "FISIDOLOGY"

    OFACANALYZER = "OFACANALYZER"

    UNDEFINED = "UNDEFINED"

    HOOYU = "HOOYU"

    LEXISNEXISIVI = "LEXISNEXISIVI"

    QOLO = "QOLO"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
