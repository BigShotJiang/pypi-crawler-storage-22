"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)
from payquickersdk.models.metadata_items import (
    MetadataItems,
)


class IdvCheckResult(object):
    """Implementation of the '_IdvCheckResult' model.

    Attributes:
        token (str): [Token](#/rest/models/structures/token) representing the resource
        user_token (str): [Token](#/rest/models/structures/token) representing the
            resource
        idv_provider_reference (str): [Provider
            reference](#/rest/models/structures/identity-verification-provider-referen
            ce) used for performing identity checks for the provider
        idv_result (IdentityVerificationResultTypes): Result type of
            [verification](#/rest/models/structures/identity-verification-result-type)
        idv_sub_result (IdentityVerificationResultSubTypes): Sub result type of
            [verification](#/rest/models/structures/identity-verification-sub-result-t
            ype)
        idv_provider (IdentityVerificationProviders): Provider types of
            [verification](#/rest/models/structures/identity-verification-provider-typ
            e) that can be used for performing identity checks
        created_on (datetime): Time object was
            [created](#/rest/models/structures/created-on)
        raw (str): Contains the raw (unprocessed)
            [output](/#/rest/models/structures/identity-verification-provider-raw-outp
            ut) from the IDV provider
        idv_check_type (str):
            [Type](#/rest/models/structures/identity-verification-check-type) of
            verification used for performing an identity check
        idv_disposition (str): Disposition type of
            [verification](#/rest/models/structures/identity-verification-disposition-
            type)
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        meta (MetadataItems): The model property of type MetadataItems.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "token": "token",
        "user_token": "userToken",
        "idv_provider_reference": "idvProviderReference",
        "idv_result": "idvResult",
        "idv_sub_result": "idvSubResult",
        "idv_provider": "idvProvider",
        "created_on": "createdOn",
        "raw": "raw",
        "idv_check_type": "idvCheckType",
        "idv_disposition": "idvDisposition",
        "links": "links",
        "meta": "meta",
    }

    _optionals = [
        "token",
        "user_token",
        "idv_provider_reference",
        "idv_result",
        "idv_sub_result",
        "idv_provider",
        "created_on",
        "raw",
        "idv_check_type",
        "idv_disposition",
        "links",
        "meta",
    ]

    def __init__(
        self,
        token=APIHelper.SKIP,
        user_token=APIHelper.SKIP,
        idv_provider_reference=APIHelper.SKIP,
        idv_result=APIHelper.SKIP,
        idv_sub_result=APIHelper.SKIP,
        idv_provider=APIHelper.SKIP,
        created_on=APIHelper.SKIP,
        raw=APIHelper.SKIP,
        idv_check_type=APIHelper.SKIP,
        idv_disposition=APIHelper.SKIP,
        links=APIHelper.SKIP,
        meta=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a IdvCheckResult instance."""
        # Initialize members of the class
        if token is not APIHelper.SKIP:
            self.token = token
        if user_token is not APIHelper.SKIP:
            self.user_token = user_token
        if idv_provider_reference is not APIHelper.SKIP:
            self.idv_provider_reference = idv_provider_reference
        if idv_result is not APIHelper.SKIP:
            self.idv_result = idv_result
        if idv_sub_result is not APIHelper.SKIP:
            self.idv_sub_result = idv_sub_result
        if idv_provider is not APIHelper.SKIP:
            self.idv_provider = idv_provider
        if created_on is not APIHelper.SKIP:
            self.created_on =\
                 APIHelper.apply_datetime_converter(
                created_on, APIHelper.RFC3339DateTime)\
                 if created_on else None
        if raw is not APIHelper.SKIP:
            self.raw = raw
        if idv_check_type is not APIHelper.SKIP:
            self.idv_check_type = idv_check_type
        if idv_disposition is not APIHelper.SKIP:
            self.idv_disposition = idv_disposition
        if links is not APIHelper.SKIP:
            self.links = links
        if meta is not APIHelper.SKIP:
            self.meta = meta

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else APIHelper.SKIP
        user_token =\
            dictionary.get("userToken")\
            if dictionary.get("userToken")\
                else APIHelper.SKIP
        idv_provider_reference =\
            dictionary.get("idvProviderReference")\
            if dictionary.get("idvProviderReference")\
                else APIHelper.SKIP
        idv_result =\
            dictionary.get("idvResult")\
            if dictionary.get("idvResult")\
                else APIHelper.SKIP
        idv_sub_result =\
            dictionary.get("idvSubResult")\
            if dictionary.get("idvSubResult")\
                else APIHelper.SKIP
        idv_provider =\
            dictionary.get("idvProvider")\
            if dictionary.get("idvProvider")\
                else APIHelper.SKIP
        created_on = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("createdOn")).datetime\
            if dictionary.get("createdOn") else APIHelper.SKIP
        raw =\
            dictionary.get("raw")\
            if dictionary.get("raw")\
                else APIHelper.SKIP
        idv_check_type =\
            dictionary.get("idvCheckType")\
            if dictionary.get("idvCheckType")\
                else APIHelper.SKIP
        idv_disposition =\
            dictionary.get("idvDisposition")\
            if dictionary.get("idvDisposition")\
                else APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP
        meta =\
            MetadataItems.from_dictionary(
                dictionary.get("meta"))\
                if "meta" in dictionary.keys()\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(token,
                   user_token,
                   idv_provider_reference,
                   idv_result,
                   idv_sub_result,
                   idv_provider,
                   created_on,
                   raw,
                   idv_check_type,
                   idv_disposition,
                   links,
                   meta,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _user_token=(
            self.user_token
            if hasattr(self, "user_token")
            else None
        )
        _idv_provider_reference=(
            self.idv_provider_reference
            if hasattr(self, "idv_provider_reference")
            else None
        )
        _idv_result=(
            self.idv_result
            if hasattr(self, "idv_result")
            else None
        )
        _idv_sub_result=(
            self.idv_sub_result
            if hasattr(self, "idv_sub_result")
            else None
        )
        _idv_provider=(
            self.idv_provider
            if hasattr(self, "idv_provider")
            else None
        )
        _created_on=(
            self.created_on
            if hasattr(self, "created_on")
            else None
        )
        _raw=(
            self.raw
            if hasattr(self, "raw")
            else None
        )
        _idv_check_type=(
            self.idv_check_type
            if hasattr(self, "idv_check_type")
            else None
        )
        _idv_disposition=(
            self.idv_disposition
            if hasattr(self, "idv_disposition")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!r}, "
            f"user_token={_user_token!r}, "
            f"idv_provider_reference={_idv_provider_reference!r}, "
            f"idv_result={_idv_result!r}, "
            f"idv_sub_result={_idv_sub_result!r}, "
            f"idv_provider={_idv_provider!r}, "
            f"created_on={_created_on!r}, "
            f"raw={_raw!r}, "
            f"idv_check_type={_idv_check_type!r}, "
            f"idv_disposition={_idv_disposition!r}, "
            f"links={_links!r}, "
            f"meta={_meta!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _user_token=(
            self.user_token
            if hasattr(self, "user_token")
            else None
        )
        _idv_provider_reference=(
            self.idv_provider_reference
            if hasattr(self, "idv_provider_reference")
            else None
        )
        _idv_result=(
            self.idv_result
            if hasattr(self, "idv_result")
            else None
        )
        _idv_sub_result=(
            self.idv_sub_result
            if hasattr(self, "idv_sub_result")
            else None
        )
        _idv_provider=(
            self.idv_provider
            if hasattr(self, "idv_provider")
            else None
        )
        _created_on=(
            self.created_on
            if hasattr(self, "created_on")
            else None
        )
        _raw=(
            self.raw
            if hasattr(self, "raw")
            else None
        )
        _idv_check_type=(
            self.idv_check_type
            if hasattr(self, "idv_check_type")
            else None
        )
        _idv_disposition=(
            self.idv_disposition
            if hasattr(self, "idv_disposition")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!s}, "
            f"user_token={_user_token!s}, "
            f"idv_provider_reference={_idv_provider_reference!s}, "
            f"idv_result={_idv_result!s}, "
            f"idv_sub_result={_idv_sub_result!s}, "
            f"idv_provider={_idv_provider!s}, "
            f"created_on={_created_on!s}, "
            f"raw={_raw!s}, "
            f"idv_check_type={_idv_check_type!s}, "
            f"idv_disposition={_idv_disposition!s}, "
            f"links={_links!s}, "
            f"meta={_meta!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
