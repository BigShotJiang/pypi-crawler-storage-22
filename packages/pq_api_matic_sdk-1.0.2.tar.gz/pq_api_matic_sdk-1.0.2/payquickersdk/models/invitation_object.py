"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)


class InvitationObject(object):
    """Implementation of the 'InvitationObject' model.

    Response from a invitation request

    Attributes:
        token (str): [Token](#/rest/models/structures/token) representing the resource
        portal_id (str): Reference ID in the PayQuicker Hosted Portal, if applicable.
        amount (float): Allocated money to be sent in the transaction.
        client_payment_id (str): Unique value provided by the client for the
            [payment](page:resources/payments), utilized for reference and
            deduplication.
        created (datetime): Time object was
            [created](#/rest/models/structures/created-on)
        currency (Currencies): [Currency code type](#/rest/models/structures/country)
            for the object
        destination_token (str): Unique identifier representing the [destination of
            funds](#/rest/models/structures/destination-token)
        program_user_id (str): [Program
            identifier](#/rest/models/structures/program-user-id) for the user
        email (str): Contact [email address](#/rest/models/structures/email-address)
            for the user account for the user account
        memo (str): Optional internal [memo](#/rest/models/structures/memo) not
            visible to the user
        note (str): [Optional comments](#/rest/models/structures/notes) visible to
            the user
        purpose (PaymentPurposes): Used to identify the [purpose of a
            payment](#/models/structures/payment-object) and impacts reporting and
            calculated taxable earnings (if utilizing tax services)
        source_token (str): Unique identifier representing the [source of
            funds](#/rest/models/structures/source-token)
        status (TransferStatuses): Current status of a
            [transfer](#/rest/models/structures/transfer)
        receipt_token (str): Auto-generated unique identifier representing a receipt,
            prefixed with `rcpt-`.
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "token": "token",
        "portal_id": "portalId",
        "amount": "amount",
        "client_payment_id": "clientPaymentId",
        "created": "created",
        "currency": "currency",
        "destination_token": "destinationToken",
        "program_user_id": "programUserId",
        "email": "email",
        "memo": "memo",
        "note": "note",
        "purpose": "purpose",
        "source_token": "sourceToken",
        "status": "status",
        "receipt_token": "receiptToken",
        "links": "links",
    }

    _optionals = [
        "token",
        "portal_id",
        "amount",
        "client_payment_id",
        "created",
        "currency",
        "destination_token",
        "program_user_id",
        "email",
        "memo",
        "note",
        "purpose",
        "source_token",
        "status",
        "receipt_token",
        "links",
    ]

    def __init__(
        self,
        token=APIHelper.SKIP,
        portal_id=APIHelper.SKIP,
        amount=1.02,
        client_payment_id="d4b6f130-1d1c-4ce2-903a-0c1ad128f55e",
        created=APIHelper.SKIP,
        currency="USD",
        destination_token="dest-631b200f-665d-4dbe-bd01-3063c9dec97d",
        program_user_id=APIHelper.SKIP,
        email=APIHelper.SKIP,
        memo=APIHelper.SKIP,
        note=APIHelper.SKIP,
        purpose=APIHelper.SKIP,
        source_token="acct-3908ab5a-6ce1-474d-8b80-a63a7b147860",
        status=APIHelper.SKIP,
        receipt_token="rcpt-b7fda294-8d3a-48e8-9a11-ef7be07a732c",
        links=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a InvitationObject instance."""
        # Initialize members of the class
        if token is not APIHelper.SKIP:
            self.token = token
        if portal_id is not APIHelper.SKIP:
            self.portal_id = portal_id
        self.amount = amount
        self.client_payment_id = client_payment_id
        if created is not APIHelper.SKIP:
            self.created =\
                 APIHelper.apply_datetime_converter(
                created, APIHelper.RFC3339DateTime)\
                 if created else None
        self.currency = currency
        self.destination_token = destination_token
        if program_user_id is not APIHelper.SKIP:
            self.program_user_id = program_user_id
        if email is not APIHelper.SKIP:
            self.email = email
        if memo is not APIHelper.SKIP:
            self.memo = memo
        if note is not APIHelper.SKIP:
            self.note = note
        if purpose is not APIHelper.SKIP:
            self.purpose = purpose
        self.source_token = source_token
        if status is not APIHelper.SKIP:
            self.status = status
        self.receipt_token = receipt_token
        if links is not APIHelper.SKIP:
            self.links = links

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else APIHelper.SKIP
        portal_id =\
            dictionary.get("portalId")\
            if dictionary.get("portalId")\
                else APIHelper.SKIP
        amount =\
            dictionary.get("amount")\
            if dictionary.get("amount")\
                else 1.02
        client_payment_id =\
            dictionary.get("clientPaymentId")\
            if dictionary.get("clientPaymentId")\
                else "d4b6f130-1d1c-4ce2-903a-0c1ad128f55e"
        created = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("created")).datetime\
            if dictionary.get("created") else APIHelper.SKIP
        currency =\
            dictionary.get("currency")\
            if dictionary.get("currency")\
                else "USD"
        destination_token =\
            dictionary.get("destinationToken")\
            if dictionary.get("destinationToken")\
                else "dest-631b200f-665d-4dbe-bd01-3063c9dec97d"
        program_user_id =\
            dictionary.get("programUserId")\
            if dictionary.get("programUserId")\
                else APIHelper.SKIP
        email =\
            dictionary.get("email")\
            if dictionary.get("email")\
                else APIHelper.SKIP
        memo =\
            dictionary.get("memo")\
            if dictionary.get("memo")\
                else APIHelper.SKIP
        note =\
            dictionary.get("note")\
            if dictionary.get("note")\
                else APIHelper.SKIP
        purpose =\
            dictionary.get("purpose")\
            if dictionary.get("purpose")\
                else APIHelper.SKIP
        source_token =\
            dictionary.get("sourceToken")\
            if dictionary.get("sourceToken")\
                else "acct-3908ab5a-6ce1-474d-8b80-a63a7b147860"
        status =\
            dictionary.get("status")\
            if dictionary.get("status")\
                else APIHelper.SKIP
        receipt_token =\
            dictionary.get("receiptToken")\
            if dictionary.get("receiptToken")\
                else "rcpt-b7fda294-8d3a-48e8-9a11-ef7be07a732c"
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(token,
                   portal_id,
                   amount,
                   client_payment_id,
                   created,
                   currency,
                   destination_token,
                   program_user_id,
                   email,
                   memo,
                   note,
                   purpose,
                   source_token,
                   status,
                   receipt_token,
                   links,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _portal_id=(
            self.portal_id
            if hasattr(self, "portal_id")
            else None
        )
        _amount=(
            self.amount
            if hasattr(self, "amount")
            else None
        )
        _client_payment_id=(
            self.client_payment_id
            if hasattr(self, "client_payment_id")
            else None
        )
        _created=(
            self.created
            if hasattr(self, "created")
            else None
        )
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _destination_token=(
            self.destination_token
            if hasattr(self, "destination_token")
            else None
        )
        _program_user_id=(
            self.program_user_id
            if hasattr(self, "program_user_id")
            else None
        )
        _email=(
            self.email
            if hasattr(self, "email")
            else None
        )
        _memo=(
            self.memo
            if hasattr(self, "memo")
            else None
        )
        _note=(
            self.note
            if hasattr(self, "note")
            else None
        )
        _purpose=(
            self.purpose
            if hasattr(self, "purpose")
            else None
        )
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _receipt_token=(
            self.receipt_token
            if hasattr(self, "receipt_token")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!r}, "
            f"portal_id={_portal_id!r}, "
            f"amount={_amount!r}, "
            f"client_payment_id={_client_payment_id!r}, "
            f"created={_created!r}, "
            f"currency={_currency!r}, "
            f"destination_token={_destination_token!r}, "
            f"program_user_id={_program_user_id!r}, "
            f"email={_email!r}, "
            f"memo={_memo!r}, "
            f"note={_note!r}, "
            f"purpose={_purpose!r}, "
            f"source_token={_source_token!r}, "
            f"status={_status!r}, "
            f"receipt_token={_receipt_token!r}, "
            f"links={_links!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _portal_id=(
            self.portal_id
            if hasattr(self, "portal_id")
            else None
        )
        _amount=(
            self.amount
            if hasattr(self, "amount")
            else None
        )
        _client_payment_id=(
            self.client_payment_id
            if hasattr(self, "client_payment_id")
            else None
        )
        _created=(
            self.created
            if hasattr(self, "created")
            else None
        )
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _destination_token=(
            self.destination_token
            if hasattr(self, "destination_token")
            else None
        )
        _program_user_id=(
            self.program_user_id
            if hasattr(self, "program_user_id")
            else None
        )
        _email=(
            self.email
            if hasattr(self, "email")
            else None
        )
        _memo=(
            self.memo
            if hasattr(self, "memo")
            else None
        )
        _note=(
            self.note
            if hasattr(self, "note")
            else None
        )
        _purpose=(
            self.purpose
            if hasattr(self, "purpose")
            else None
        )
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _receipt_token=(
            self.receipt_token
            if hasattr(self, "receipt_token")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!s}, "
            f"portal_id={_portal_id!s}, "
            f"amount={_amount!s}, "
            f"client_payment_id={_client_payment_id!s}, "
            f"created={_created!s}, "
            f"currency={_currency!s}, "
            f"destination_token={_destination_token!s}, "
            f"program_user_id={_program_user_id!s}, "
            f"email={_email!s}, "
            f"memo={_memo!s}, "
            f"note={_note!s}, "
            f"purpose={_purpose!s}, "
            f"source_token={_source_token!s}, "
            f"status={_status!s}, "
            f"receipt_token={_receipt_token!s}, "
            f"links={_links!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
