"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class Languages(object):
    """Implementation of the '__Languages' enum.

    The [Language](#/rest/models/structures/language) type in IETF's BCP 47 format

    Attributes:
        CSCZ: Czech
        DEDE: German
        ENGB: English (UK)
        ENUS: English (US)
        ESES: Spanish (Spain)
        ESMX: Spanish (Mexico)
        FRCA: French (Canadian)
        FRFR: French (France)
        ITIT: Italian
        JAJP: I bet you already know
        KOKR: Korea
        NLNL: Dutch
        PLPL: Polish
        PTBR: Portuguese (Brazil)
        PTPT: Portuguese (Portugal)
        RURU: Russian
        ZHHANS: Chinese (Simplified)
        ZHHANT: Chinese (Traditional)
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    CSCZ = "cs-CZ"

    DEDE = "de-DE"

    ENGB = "en-GB"

    ENUS = "en-US"

    ESES = "es-ES"

    ESMX = "es-MX"

    FRCA = "fr-CA"

    FRFR = "fr-FR"

    ITIT = "it-IT"

    JAJP = "ja-JP"

    KOKR = "ko-KR"

    NLNL = "nl-NL"

    PLPL = "pl-PL"

    PTBR = "pt-BR"

    PTPT = "pt-PT"

    RURU = "ru-RU"

    ZHHANS = "zh-Hans"

    ZHHANT = "zh-Hant"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
