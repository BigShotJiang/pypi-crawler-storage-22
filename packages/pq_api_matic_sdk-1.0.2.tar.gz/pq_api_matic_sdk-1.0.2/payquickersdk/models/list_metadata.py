"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
class ListMetadata(object):
    """Implementation of the 'ListMetadata' model.

    Attributes:
        page_no (str): The model property of type str.
        page_size (str): The model property of type str.
        page_count (str): The model property of type str.
        record_count (str): The model property of type str.
        timezone (str): Timezone of the datetime objects in the response
        request_ref (str): The model property of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "page_no": "pageNo",
        "page_size": "pageSize",
        "page_count": "pageCount",
        "record_count": "recordCount",
        "timezone": "timezone",
        "request_ref": "requestRef",
    }

    def __init__(
        self,
        page_no="1",
        page_size="10",
        page_count="1",
        record_count=None,
        timezone=None,
        request_ref=None,
        additional_properties=None):
        """Initialize a ListMetadata instance."""
        # Initialize members of the class
        self.page_no = page_no
        self.page_size = page_size
        self.page_count = page_count
        self.record_count = record_count
        self.timezone = timezone
        self.request_ref = request_ref

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        page_no =\
            dictionary.get("pageNo")\
            if dictionary.get("pageNo")\
                else "1"
        page_size =\
            dictionary.get("pageSize")\
            if dictionary.get("pageSize")\
                else "10"
        page_count =\
            dictionary.get("pageCount")\
            if dictionary.get("pageCount")\
                else "1"
        record_count =\
            dictionary.get("recordCount")\
            if dictionary.get("recordCount")\
                else None
        timezone =\
            dictionary.get("timezone")\
            if dictionary.get("timezone")\
                else None
        request_ref =\
            dictionary.get("requestRef")\
            if dictionary.get("requestRef")\
                else None

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(page_no,
                   page_size,
                   page_count,
                   record_count,
                   timezone,
                   request_ref,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _page_no=self.page_no
        _page_size=self.page_size
        _page_count=self.page_count
        _record_count=self.record_count
        _timezone=self.timezone
        _request_ref=self.request_ref
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"page_no={_page_no!r}, "
            f"page_size={_page_size!r}, "
            f"page_count={_page_count!r}, "
            f"record_count={_record_count!r}, "
            f"timezone={_timezone!r}, "
            f"request_ref={_request_ref!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _page_no=self.page_no
        _page_size=self.page_size
        _page_count=self.page_count
        _record_count=self.record_count
        _timezone=self.timezone
        _request_ref=self.request_ref
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"page_no={_page_no!s}, "
            f"page_size={_page_size!s}, "
            f"page_count={_page_count!s}, "
            f"record_count={_record_count!s}, "
            f"timezone={_timezone!s}, "
            f"request_ref={_request_ref!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
