"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
class MetadataItems(object):
    """Implementation of the '_MetadataItems' model.

    Attributes:
        timezone (str): Timezone of the datetime objects in the response
        request_ref (str): The model property of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "timezone": "timezone",
        "request_ref": "requestRef",
    }

    def __init__(
        self,
        timezone=None,
        request_ref=None,
        additional_properties=None):
        """Initialize a MetadataItems instance."""
        # Initialize members of the class
        self.timezone = timezone
        self.request_ref = request_ref

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        timezone =\
            dictionary.get("timezone")\
            if dictionary.get("timezone")\
                else None
        request_ref =\
            dictionary.get("requestRef")\
            if dictionary.get("requestRef")\
                else None

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(timezone,
                   request_ref,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _timezone=self.timezone
        _request_ref=self.request_ref
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"timezone={_timezone!r}, "
            f"request_ref={_request_ref!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _timezone=self.timezone
        _request_ref=self.request_ref
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"timezone={_timezone!s}, "
            f"request_ref={_request_ref!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
