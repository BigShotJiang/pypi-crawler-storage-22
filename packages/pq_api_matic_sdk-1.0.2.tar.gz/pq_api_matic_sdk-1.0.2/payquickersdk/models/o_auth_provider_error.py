"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class OAuthProviderError(object):
    """Implementation of the 'OAuthProviderError' enum.

    OAuth 2 Authorization error codes

    Attributes:
        INVALID_REQUEST: The request is missing a required parameter, includes an
            unsupported parameter value (other than grant type), repeats a parameter,
            includes multiple credentials, utilizes more than one mechanism for
            authenticating the client, or is otherwise malformed.
        INVALID_CLIENT: Client authentication failed (e.g., unknown client, no client
            authentication included, or unsupported authentication method).
        INVALID_GRANT: The provided authorization grant (e.g., authorization code,
            resource owner credentials) or refresh token is invalid, expired,
            revoked, does not match the redirection URI used in the authorization
            request, or was issued to another client.
        UNAUTHORIZED_CLIENT: The authenticated client is not authorized to use this
            authorization grant type.
        UNSUPPORTED_GRANT_TYPE: The authorization grant type is not supported by the
            authorization server.
        INVALID_SCOPE: The requested scope is invalid, unknown, malformed, or exceeds
            the scope granted by the resource owner.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    INVALID_REQUEST = "invalid_request"

    INVALID_CLIENT = "invalid_client"

    INVALID_GRANT = "invalid_grant"

    UNAUTHORIZED_CLIENT = "unauthorized_client"

    UNSUPPORTED_GRANT_TYPE = "unsupported_grant_type"

    INVALID_SCOPE = "invalid_scope"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
