"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class Occupations(object):
    """Implementation of the '__Occupations' enum.

    [Type of occupation](#/rest/models/structures/occupation) for the user

    Attributes:
        ARTS: The enum member of type str.
        DESIGN: The enum member of type str.
        EDUCATION: The enum member of type str.
        ENGINEERING: The enum member of type str.
        FINANCE: The enum member of type str.
        GOVERNMENT: The enum member of type str.
        HEALTHCARE: The enum member of type str.
        HOSPITALITY_AND_TOURISM: The enum member of type str.
        INDEPENDENT_BUSINESS_OWNER: The enum member of type str.
        LAW: The enum member of type str.
        MANUFACTURING: The enum member of type str.
        MATH: The enum member of type str.
        MEDIA: The enum member of type str.
        OFFICE_AND_ADMIN_SUPPORT: The enum member of type str.
        SCIENCE: The enum member of type str.
        SOCIAL_SERVICES: The enum member of type str.
        TECHNOLOGY: The enum member of type str.
        SALES: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    ARTS = "ARTS"

    DESIGN = "DESIGN"

    EDUCATION = "EDUCATION"

    ENGINEERING = "ENGINEERING"

    FINANCE = "FINANCE"

    GOVERNMENT = "GOVERNMENT"

    HEALTHCARE = "HEALTHCARE"

    HOSPITALITY_AND_TOURISM = "HOSPITALITY_AND_TOURISM"

    INDEPENDENT_BUSINESS_OWNER = "INDEPENDENT_BUSINESS_OWNER"

    LAW = "LAW"

    MANUFACTURING = "MANUFACTURING"

    MATH = "MATH"

    MEDIA = "MEDIA"

    OFFICE_AND_ADMIN_SUPPORT = "OFFICE_AND_ADMIN_SUPPORT"

    SCIENCE = "SCIENCE"

    SOCIAL_SERVICES = "SOCIAL_SERVICES"

    TECHNOLOGY = "TECHNOLOGY"

    SALES = "SALES"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
