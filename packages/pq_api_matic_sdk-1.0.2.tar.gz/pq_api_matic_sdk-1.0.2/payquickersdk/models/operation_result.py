"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class OperationResult(object):
    """Implementation of the '_OperationResult' model.

    Attributes:
        result (bool): The result of the api operation
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "result": "result",
    }

    _optionals = [
        "result",
    ]

    def __init__(
        self,
        result=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a OperationResult instance."""
        # Initialize members of the class
        if result is not APIHelper.SKIP:
            self.result = result

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        result =\
            dictionary.get("result")\
            if "result" in dictionary.keys()\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(result,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _result=(
            self.result
            if hasattr(self, "result")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"result={_result!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _result=(
            self.result
            if hasattr(self, "result")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"result={_result!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
