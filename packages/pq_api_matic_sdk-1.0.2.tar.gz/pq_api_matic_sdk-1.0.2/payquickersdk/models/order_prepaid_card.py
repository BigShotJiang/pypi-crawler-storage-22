"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class OrderPrepaidCard(object):
    """Implementation of the '_OrderPrepaidCard' model.

    Attributes:
        card_package (str): [Package](#/rest/models/structures/prepaid-card-package)
            for the card being displayed, including artwork, packaging, and delivery
            method
        program_token (str): Auto-generated unique identifier representing a program,
            prefixed with prog-
        card_reference_number (str): Number that is printed on the back of a plastic
            card.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "card_package": "cardPackage",
        "program_token": "programToken",
        "card_reference_number": "cardReferenceNumber",
    }

    _optionals = [
        "card_package",
        "program_token",
        "card_reference_number",
    ]

    def __init__(
        self,
        card_package=APIHelper.SKIP,
        program_token=APIHelper.SKIP,
        card_reference_number=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a OrderPrepaidCard instance."""
        # Initialize members of the class
        if card_package is not APIHelper.SKIP:
            self.card_package = card_package
        if program_token is not APIHelper.SKIP:
            self.program_token = program_token
        if card_reference_number is not APIHelper.SKIP:
            self.card_reference_number = card_reference_number

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        card_package =\
            dictionary.get("cardPackage")\
            if dictionary.get("cardPackage")\
                else APIHelper.SKIP
        program_token =\
            dictionary.get("programToken")\
            if dictionary.get("programToken")\
                else APIHelper.SKIP
        card_reference_number =\
            dictionary.get("cardReferenceNumber")\
            if dictionary.get("cardReferenceNumber")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(card_package,
                   program_token,
                   card_reference_number,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _card_package=(
            self.card_package
            if hasattr(self, "card_package")
            else None
        )
        _program_token=(
            self.program_token
            if hasattr(self, "program_token")
            else None
        )
        _card_reference_number=(
            self.card_reference_number
            if hasattr(self, "card_reference_number")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_package={_card_package!r}, "
            f"program_token={_program_token!r}, "
            f"card_reference_number={_card_reference_number!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _card_package=(
            self.card_package
            if hasattr(self, "card_package")
            else None
        )
        _program_token=(
            self.program_token
            if hasattr(self, "program_token")
            else None
        )
        _card_reference_number=(
            self.card_reference_number
            if hasattr(self, "card_reference_number")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_package={_card_package!s}, "
            f"program_token={_program_token!s}, "
            f"card_reference_number={_card_reference_number!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
