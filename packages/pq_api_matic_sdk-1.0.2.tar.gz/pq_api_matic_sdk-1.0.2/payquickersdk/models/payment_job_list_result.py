"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)
from payquickersdk.models.list_metadata import (
    ListMetadata,
)
from payquickersdk.models.payment_job_object import (
    PaymentJobObject,
)


class PaymentJobListResult(object):
    """Implementation of the '_PaymentJobListResult' model.

    Attributes:
        payload (List[PaymentJobObject]): The model property of type
            List[PaymentJobObject].
        meta (ListMetadata): The model property of type ListMetadata.
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "payload": "payload",
        "meta": "meta",
        "links": "links",
    }

    def __init__(
        self,
        payload=None,
        meta=None,
        links=None,
        additional_properties=None):
        """Initialize a PaymentJobListResult instance."""
        # Initialize members of the class
        self.payload = payload
        self.meta = meta
        self.links = links

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        payload = None
        if dictionary.get("payload") is not None:
            payload = [
                PaymentJobObject.from_dictionary(x)
                    for x in dictionary.get("payload")
            ]
        meta =\
            ListMetadata.from_dictionary(
                dictionary.get("meta"))\
                if dictionary.get("meta") else None
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(payload,
                   meta,
                   links,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _payload=self.payload
        _meta=self.meta
        _links=self.links
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"payload={_payload!r}, "
            f"meta={_meta!r}, "
            f"links={_links!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _payload=self.payload
        _meta=self.meta
        _links=self.links
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"payload={_payload!s}, "
            f"meta={_meta!s}, "
            f"links={_links!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
