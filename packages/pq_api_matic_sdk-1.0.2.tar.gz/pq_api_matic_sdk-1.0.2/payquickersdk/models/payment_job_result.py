"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)
from payquickersdk.models.metadata_items import (
    MetadataItems,
)
from payquickersdk.models.payment_object import (
    PaymentObject,
)


class PaymentJobResult(object):
    """Implementation of the '_PaymentJobResult' model.

    Attributes:
        token (str): [Token](#/rest/models/structures/token) representing the resource
        portal_id (str): Reference ID in the PayQuicker Hosted Portal, if applicable.
        filename (str): The name given to a computer file in order to distinguish it
            from other files
        file_token (str): [Token](#/rest/models/structures/token) representing the
            document
        created (datetime): Time object was
            [created](#/rest/models/structures/created-on)
        not_before (datetime):
            [Transfer](#/rest/models/structures/not-before-or-after) is scheduled and
            will not process before this time.
        count (int): The model property of type int.
        mtype (JobTypes): Job Types
        status (JobStatusTypes): Job Status Types
        items (List[PaymentObject]): The model property of type List[PaymentObject].
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        meta (MetadataItems): The model property of type MetadataItems.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "token": "token",
        "portal_id": "portalId",
        "filename": "filename",
        "file_token": "fileToken",
        "created": "created",
        "not_before": "notBefore",
        "count": "count",
        "mtype": "type",
        "status": "status",
        "items": "items",
        "links": "links",
        "meta": "meta",
    }

    _optionals = [
        "token",
        "portal_id",
        "filename",
        "file_token",
        "created",
        "not_before",
        "count",
        "mtype",
        "status",
        "items",
        "links",
        "meta",
    ]

    def __init__(
        self,
        token=APIHelper.SKIP,
        portal_id=APIHelper.SKIP,
        filename=APIHelper.SKIP,
        file_token="docu-2053aaad-c1a5-45e2-a2da-f71287f32800",
        created=APIHelper.SKIP,
        not_before=APIHelper.SKIP,
        count=APIHelper.SKIP,
        mtype=APIHelper.SKIP,
        status=APIHelper.SKIP,
        items=APIHelper.SKIP,
        links=APIHelper.SKIP,
        meta=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a PaymentJobResult instance."""
        # Initialize members of the class
        if token is not APIHelper.SKIP:
            self.token = token
        if portal_id is not APIHelper.SKIP:
            self.portal_id = portal_id
        if filename is not APIHelper.SKIP:
            self.filename = filename
        self.file_token = file_token
        if created is not APIHelper.SKIP:
            self.created =\
                 APIHelper.apply_datetime_converter(
                created, APIHelper.RFC3339DateTime)\
                 if created else None
        if not_before is not APIHelper.SKIP:
            self.not_before =\
                 APIHelper.apply_datetime_converter(
                not_before, APIHelper.RFC3339DateTime)\
                 if not_before else None
        if count is not APIHelper.SKIP:
            self.count = count
        if mtype is not APIHelper.SKIP:
            self.mtype = mtype
        if status is not APIHelper.SKIP:
            self.status = status
        if items is not APIHelper.SKIP:
            self.items = items
        if links is not APIHelper.SKIP:
            self.links = links
        if meta is not APIHelper.SKIP:
            self.meta = meta

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else APIHelper.SKIP
        portal_id =\
            dictionary.get("portalId")\
            if dictionary.get("portalId")\
                else APIHelper.SKIP
        filename =\
            dictionary.get("filename")\
            if dictionary.get("filename")\
                else APIHelper.SKIP
        file_token =\
            dictionary.get("fileToken")\
            if dictionary.get("fileToken")\
                else "docu-2053aaad-c1a5-45e2-a2da-f71287f32800"
        created = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("created")).datetime\
            if dictionary.get("created") else APIHelper.SKIP
        not_before = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("notBefore")).datetime\
            if dictionary.get("notBefore") else APIHelper.SKIP
        count =\
            dictionary.get("count")\
            if dictionary.get("count")\
                else APIHelper.SKIP
        mtype =\
            dictionary.get("type")\
            if dictionary.get("type")\
                else APIHelper.SKIP
        status =\
            dictionary.get("status")\
            if dictionary.get("status")\
                else APIHelper.SKIP
        items = None
        if dictionary.get("items") is not None:
            items = [
                PaymentObject.from_dictionary(x)
                    for x in dictionary.get("items")
            ]
        else:
            items = APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP
        meta =\
            MetadataItems.from_dictionary(
                dictionary.get("meta"))\
                if "meta" in dictionary.keys()\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(token,
                   portal_id,
                   filename,
                   file_token,
                   created,
                   not_before,
                   count,
                   mtype,
                   status,
                   items,
                   links,
                   meta,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _portal_id=(
            self.portal_id
            if hasattr(self, "portal_id")
            else None
        )
        _filename=(
            self.filename
            if hasattr(self, "filename")
            else None
        )
        _file_token=(
            self.file_token
            if hasattr(self, "file_token")
            else None
        )
        _created=(
            self.created
            if hasattr(self, "created")
            else None
        )
        _not_before=(
            self.not_before
            if hasattr(self, "not_before")
            else None
        )
        _count=(
            self.count
            if hasattr(self, "count")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _items=(
            self.items
            if hasattr(self, "items")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!r}, "
            f"portal_id={_portal_id!r}, "
            f"filename={_filename!r}, "
            f"file_token={_file_token!r}, "
            f"created={_created!r}, "
            f"not_before={_not_before!r}, "
            f"count={_count!r}, "
            f"mtype={_mtype!r}, "
            f"status={_status!r}, "
            f"items={_items!r}, "
            f"links={_links!r}, "
            f"meta={_meta!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _portal_id=(
            self.portal_id
            if hasattr(self, "portal_id")
            else None
        )
        _filename=(
            self.filename
            if hasattr(self, "filename")
            else None
        )
        _file_token=(
            self.file_token
            if hasattr(self, "file_token")
            else None
        )
        _created=(
            self.created
            if hasattr(self, "created")
            else None
        )
        _not_before=(
            self.not_before
            if hasattr(self, "not_before")
            else None
        )
        _count=(
            self.count
            if hasattr(self, "count")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _items=(
            self.items
            if hasattr(self, "items")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!s}, "
            f"portal_id={_portal_id!s}, "
            f"filename={_filename!s}, "
            f"file_token={_file_token!s}, "
            f"created={_created!s}, "
            f"not_before={_not_before!s}, "
            f"count={_count!s}, "
            f"mtype={_mtype!s}, "
            f"status={_status!s}, "
            f"items={_items!s}, "
            f"links={_links!s}, "
            f"meta={_meta!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
