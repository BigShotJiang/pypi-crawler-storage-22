"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class PaymentPurposes(object):
    """Implementation of the '__PaymentPurposes' enum.

    Used to identify the [purpose of a payment](#/models/structures/payment-object)
    and impacts reporting and calculated taxable earnings (if utilizing tax services)

    Attributes:
        BONUS: The enum member of type str.
        EXPENSE: The enum member of type str.
        INCOME: The enum member of type str.
        NON_TAXABLE: The enum member of type str.
        OTHER: The enum member of type str.
        TAXABLE: The enum member of type str.
        UNDEFINED: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    _all_values = ["BONUS", "EXPENSE", "INCOME", "NON_TAXABLE", "OTHER",
        "TAXABLE", "UNDEFINED"]
    BONUS = "BONUS"

    EXPENSE = "EXPENSE"

    INCOME = "INCOME"

    NON_TAXABLE = "NON_TAXABLE"

    OTHER = "OTHER"

    TAXABLE = "TAXABLE"

    UNDEFINED = "UNDEFINED"

    @classmethod
    def validate(cls, value):
        """Validate value contains in enum

        Args:
            value: the value to be validated

        Returns:
            boolean : if value is valid enum values.

        """
        return value in cls._all_values

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
