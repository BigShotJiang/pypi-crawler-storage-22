"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class PortalPaymentQuote(object):
    """Implementation of the 'PortalPaymentQuote' model.

    Response from a invitation request

    Attributes:
        amount (float): Allocated money to be sent in the transaction.
        currency (Currencies): [Currency code type](#/rest/models/structures/country)
            for the object
        source_token (str): Unique identifier representing the [source of
            funds](#/rest/models/structures/source-token)
        program_user_id (str): [Program
            identifier](#/rest/models/structures/program-user-id) for the user
        email (str): Contact [email address](#/rest/models/structures/email-address)
            for the user account for the user account
        note (str): [Optional comments](#/rest/models/structures/notes) visible to
            the user
        memo (str): Optional internal [memo](#/rest/models/structures/memo) not
            visible to the user
        purpose (PaymentPurposes): Used to identify the [purpose of a
            payment](#/models/structures/payment-object) and impacts reporting and
            calculated taxable earnings (if utilizing tax services)
        client_payment_id (str): Unique value provided by the client for the
            [payment](page:resources/payments), utilized for reference and
            deduplication.
        auto_accept_quote (bool): Determines whether the quote is [automatically
            accepted](#/rest/models/structures/auto-accept-quote) or if a `POST`
            utilizing the token for the quote is required.
        not_before (datetime):
            [Transfer](#/rest/models/structures/not-before-or-after) is scheduled and
            will not process before this time.
        not_after (datetime):
            [Transfer](#/rest/models/structures/not-before-or-after) expires if not
            completed prior to this time.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "amount": "amount",
        "currency": "currency",
        "source_token": "sourceToken",
        "program_user_id": "programUserId",
        "email": "email",
        "note": "note",
        "memo": "memo",
        "purpose": "purpose",
        "client_payment_id": "clientPaymentId",
        "auto_accept_quote": "autoAcceptQuote",
        "not_before": "notBefore",
        "not_after": "notAfter",
    }

    _optionals = [
        "amount",
        "currency",
        "source_token",
        "program_user_id",
        "email",
        "note",
        "memo",
        "purpose",
        "client_payment_id",
        "auto_accept_quote",
        "not_before",
        "not_after",
    ]

    def __init__(
        self,
        amount=1.02,
        currency="USD",
        source_token="acct-3908ab5a-6ce1-474d-8b80-a63a7b147860",
        program_user_id=APIHelper.SKIP,
        email=APIHelper.SKIP,
        note=APIHelper.SKIP,
        memo=APIHelper.SKIP,
        purpose=APIHelper.SKIP,
        client_payment_id="d4b6f130-1d1c-4ce2-903a-0c1ad128f55e",
        auto_accept_quote=APIHelper.SKIP,
        not_before=APIHelper.SKIP,
        not_after=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a PortalPaymentQuote instance."""
        # Initialize members of the class
        self.amount = amount
        self.currency = currency
        self.source_token = source_token
        if program_user_id is not APIHelper.SKIP:
            self.program_user_id = program_user_id
        if email is not APIHelper.SKIP:
            self.email = email
        if note is not APIHelper.SKIP:
            self.note = note
        if memo is not APIHelper.SKIP:
            self.memo = memo
        if purpose is not APIHelper.SKIP:
            self.purpose = purpose
        self.client_payment_id = client_payment_id
        if auto_accept_quote is not APIHelper.SKIP:
            self.auto_accept_quote = auto_accept_quote
        if not_before is not APIHelper.SKIP:
            self.not_before =\
                 APIHelper.apply_datetime_converter(
                not_before, APIHelper.RFC3339DateTime)\
                 if not_before else None
        if not_after is not APIHelper.SKIP:
            self.not_after =\
                 APIHelper.apply_datetime_converter(
                not_after, APIHelper.RFC3339DateTime)\
                 if not_after else None

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        amount =\
            dictionary.get("amount")\
            if dictionary.get("amount")\
                else 1.02
        currency =\
            dictionary.get("currency")\
            if dictionary.get("currency")\
                else "USD"
        source_token =\
            dictionary.get("sourceToken")\
            if dictionary.get("sourceToken")\
                else "acct-3908ab5a-6ce1-474d-8b80-a63a7b147860"
        program_user_id =\
            dictionary.get("programUserId")\
            if dictionary.get("programUserId")\
                else APIHelper.SKIP
        email =\
            dictionary.get("email")\
            if dictionary.get("email")\
                else APIHelper.SKIP
        note =\
            dictionary.get("note")\
            if dictionary.get("note")\
                else APIHelper.SKIP
        memo =\
            dictionary.get("memo")\
            if dictionary.get("memo")\
                else APIHelper.SKIP
        purpose =\
            dictionary.get("purpose")\
            if dictionary.get("purpose")\
                else APIHelper.SKIP
        client_payment_id =\
            dictionary.get("clientPaymentId")\
            if dictionary.get("clientPaymentId")\
                else "d4b6f130-1d1c-4ce2-903a-0c1ad128f55e"
        auto_accept_quote =\
            dictionary.get("autoAcceptQuote")\
            if "autoAcceptQuote" in dictionary.keys()\
                else APIHelper.SKIP
        not_before = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("notBefore")).datetime\
            if dictionary.get("notBefore") else APIHelper.SKIP
        not_after = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("notAfter")).datetime\
            if dictionary.get("notAfter") else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(amount,
                   currency,
                   source_token,
                   program_user_id,
                   email,
                   note,
                   memo,
                   purpose,
                   client_payment_id,
                   auto_accept_quote,
                   not_before,
                   not_after,
                   additional_properties)

    @classmethod
    def validate(cls, dictionary):
        """Validate dictionary against class required properties

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            boolean : if dictionary is valid contains required properties.

        """
        if isinstance(dictionary, cls):
            return True

        if not isinstance(dictionary, dict):
            return False

        return True

    def __repr__(self):
        """Return a unambiguous string representation."""
        _amount=(
            self.amount
            if hasattr(self, "amount")
            else None
        )
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _program_user_id=(
            self.program_user_id
            if hasattr(self, "program_user_id")
            else None
        )
        _email=(
            self.email
            if hasattr(self, "email")
            else None
        )
        _note=(
            self.note
            if hasattr(self, "note")
            else None
        )
        _memo=(
            self.memo
            if hasattr(self, "memo")
            else None
        )
        _purpose=(
            self.purpose
            if hasattr(self, "purpose")
            else None
        )
        _client_payment_id=(
            self.client_payment_id
            if hasattr(self, "client_payment_id")
            else None
        )
        _auto_accept_quote=(
            self.auto_accept_quote
            if hasattr(self, "auto_accept_quote")
            else None
        )
        _not_before=(
            self.not_before
            if hasattr(self, "not_before")
            else None
        )
        _not_after=(
            self.not_after
            if hasattr(self, "not_after")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"amount={_amount!r}, "
            f"currency={_currency!r}, "
            f"source_token={_source_token!r}, "
            f"program_user_id={_program_user_id!r}, "
            f"email={_email!r}, "
            f"note={_note!r}, "
            f"memo={_memo!r}, "
            f"purpose={_purpose!r}, "
            f"client_payment_id={_client_payment_id!r}, "
            f"auto_accept_quote={_auto_accept_quote!r}, "
            f"not_before={_not_before!r}, "
            f"not_after={_not_after!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _amount=(
            self.amount
            if hasattr(self, "amount")
            else None
        )
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _program_user_id=(
            self.program_user_id
            if hasattr(self, "program_user_id")
            else None
        )
        _email=(
            self.email
            if hasattr(self, "email")
            else None
        )
        _note=(
            self.note
            if hasattr(self, "note")
            else None
        )
        _memo=(
            self.memo
            if hasattr(self, "memo")
            else None
        )
        _purpose=(
            self.purpose
            if hasattr(self, "purpose")
            else None
        )
        _client_payment_id=(
            self.client_payment_id
            if hasattr(self, "client_payment_id")
            else None
        )
        _auto_accept_quote=(
            self.auto_accept_quote
            if hasattr(self, "auto_accept_quote")
            else None
        )
        _not_before=(
            self.not_before
            if hasattr(self, "not_before")
            else None
        )
        _not_after=(
            self.not_after
            if hasattr(self, "not_after")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"amount={_amount!s}, "
            f"currency={_currency!s}, "
            f"source_token={_source_token!s}, "
            f"program_user_id={_program_user_id!s}, "
            f"email={_email!s}, "
            f"note={_note!s}, "
            f"memo={_memo!s}, "
            f"purpose={_purpose!s}, "
            f"client_payment_id={_client_payment_id!s}, "
            f"auto_accept_quote={_auto_accept_quote!s}, "
            f"not_before={_not_before!s}, "
            f"not_after={_not_after!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
