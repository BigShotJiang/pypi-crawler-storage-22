"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class PortalTransferQuote(object):
    """Implementation of the 'PortalTransferQuote' model.

    Response from a invitation request

    Attributes:
        source_token (str): Unique identifier representing the [source of
            funds](#/rest/models/structures/source-token)
        program_user_id (str): [Program
            identifier](#/rest/models/structures/program-user-id) for the user
        email (str): Contact [email address](#/rest/models/structures/email-address)
            for the user account for the user account
        note (str): [Optional comments](#/rest/models/structures/notes) visible to
            the user
        memo (str): Optional internal [memo](#/rest/models/structures/memo) not
            visible to the user
        auto_accept_quote (bool): Determines whether the quote is [automatically
            accepted](#/rest/models/structures/auto-accept-quote) or if a `POST`
            utilizing the token for the quote is required.
        client_transfer_id (str): [Unique
            value](#/rest/models/structures/client-transfer-id) provided by the
            client for the transfer, utilized for reference and deduplication.
        destination_amount (float): Allocated money to be sent in the transaction.
        destination_currency (Currencies): [Currency code
            type](#/rest/models/structures/country) for the object
        transfer_lock_side (LockSideTypes): Type of
            [lockside](page:additional-api-information/transfer-lockside-types) for
            transfers.
        transfer_method_type (TransferMethodTypes): Optional transfer methods
            applicable only to bank and e-wallet transfers.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "source_token": "sourceToken",
        "program_user_id": "programUserId",
        "email": "email",
        "note": "note",
        "memo": "memo",
        "auto_accept_quote": "autoAcceptQuote",
        "client_transfer_id": "clientTransferId",
        "destination_amount": "destinationAmount",
        "destination_currency": "destinationCurrency",
        "transfer_lock_side": "transferLockSide",
        "transfer_method_type": "transferMethodType",
    }

    _optionals = [
        "source_token",
        "program_user_id",
        "email",
        "note",
        "memo",
        "auto_accept_quote",
        "client_transfer_id",
        "destination_amount",
        "destination_currency",
        "transfer_lock_side",
        "transfer_method_type",
    ]

    def __init__(
        self,
        source_token="acct-3908ab5a-6ce1-474d-8b80-a63a7b147860",
        program_user_id=APIHelper.SKIP,
        email=APIHelper.SKIP,
        note=APIHelper.SKIP,
        memo=APIHelper.SKIP,
        auto_accept_quote=APIHelper.SKIP,
        client_transfer_id=APIHelper.SKIP,
        destination_amount=APIHelper.SKIP,
        destination_currency="USD",
        transfer_lock_side=APIHelper.SKIP,
        transfer_method_type=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a PortalTransferQuote instance."""
        # Initialize members of the class
        self.source_token = source_token
        if program_user_id is not APIHelper.SKIP:
            self.program_user_id = program_user_id
        if email is not APIHelper.SKIP:
            self.email = email
        if note is not APIHelper.SKIP:
            self.note = note
        if memo is not APIHelper.SKIP:
            self.memo = memo
        if auto_accept_quote is not APIHelper.SKIP:
            self.auto_accept_quote = auto_accept_quote
        if client_transfer_id is not APIHelper.SKIP:
            self.client_transfer_id = client_transfer_id
        if destination_amount is not APIHelper.SKIP:
            self.destination_amount = destination_amount
        self.destination_currency = destination_currency
        if transfer_lock_side is not APIHelper.SKIP:
            self.transfer_lock_side = transfer_lock_side
        if transfer_method_type is not APIHelper.SKIP:
            self.transfer_method_type = transfer_method_type

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        source_token =\
            dictionary.get("sourceToken")\
            if dictionary.get("sourceToken")\
                else "acct-3908ab5a-6ce1-474d-8b80-a63a7b147860"
        program_user_id =\
            dictionary.get("programUserId")\
            if dictionary.get("programUserId")\
                else APIHelper.SKIP
        email =\
            dictionary.get("email")\
            if dictionary.get("email")\
                else APIHelper.SKIP
        note =\
            dictionary.get("note")\
            if dictionary.get("note")\
                else APIHelper.SKIP
        memo =\
            dictionary.get("memo")\
            if dictionary.get("memo")\
                else APIHelper.SKIP
        auto_accept_quote =\
            dictionary.get("autoAcceptQuote")\
            if "autoAcceptQuote" in dictionary.keys()\
                else APIHelper.SKIP
        client_transfer_id =\
            dictionary.get("clientTransferId")\
            if dictionary.get("clientTransferId")\
                else APIHelper.SKIP
        destination_amount =\
            dictionary.get("destinationAmount")\
            if dictionary.get("destinationAmount")\
                else APIHelper.SKIP
        destination_currency =\
            dictionary.get("destinationCurrency")\
            if dictionary.get("destinationCurrency")\
                else "USD"
        transfer_lock_side =\
            dictionary.get("transferLockSide")\
            if dictionary.get("transferLockSide")\
                else APIHelper.SKIP
        transfer_method_type =\
            dictionary.get("transferMethodType")\
            if dictionary.get("transferMethodType")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(source_token,
                   program_user_id,
                   email,
                   note,
                   memo,
                   auto_accept_quote,
                   client_transfer_id,
                   destination_amount,
                   destination_currency,
                   transfer_lock_side,
                   transfer_method_type,
                   additional_properties)

    @classmethod
    def validate(cls, dictionary):
        """Validate dictionary against class required properties

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            boolean : if dictionary is valid contains required properties.

        """
        if isinstance(dictionary, cls):
            return True

        if not isinstance(dictionary, dict):
            return False

        return True

    def __repr__(self):
        """Return a unambiguous string representation."""
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _program_user_id=(
            self.program_user_id
            if hasattr(self, "program_user_id")
            else None
        )
        _email=(
            self.email
            if hasattr(self, "email")
            else None
        )
        _note=(
            self.note
            if hasattr(self, "note")
            else None
        )
        _memo=(
            self.memo
            if hasattr(self, "memo")
            else None
        )
        _auto_accept_quote=(
            self.auto_accept_quote
            if hasattr(self, "auto_accept_quote")
            else None
        )
        _client_transfer_id=(
            self.client_transfer_id
            if hasattr(self, "client_transfer_id")
            else None
        )
        _destination_amount=(
            self.destination_amount
            if hasattr(self, "destination_amount")
            else None
        )
        _destination_currency=(
            self.destination_currency
            if hasattr(self, "destination_currency")
            else None
        )
        _transfer_lock_side=(
            self.transfer_lock_side
            if hasattr(self, "transfer_lock_side")
            else None
        )
        _transfer_method_type=(
            self.transfer_method_type
            if hasattr(self, "transfer_method_type")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"source_token={_source_token!r}, "
            f"program_user_id={_program_user_id!r}, "
            f"email={_email!r}, "
            f"note={_note!r}, "
            f"memo={_memo!r}, "
            f"auto_accept_quote={_auto_accept_quote!r}, "
            f"client_transfer_id={_client_transfer_id!r}, "
            f"destination_amount={_destination_amount!r}, "
            f"destination_currency={_destination_currency!r}, "
            f"transfer_lock_side={_transfer_lock_side!r}, "
            f"transfer_method_type={_transfer_method_type!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _program_user_id=(
            self.program_user_id
            if hasattr(self, "program_user_id")
            else None
        )
        _email=(
            self.email
            if hasattr(self, "email")
            else None
        )
        _note=(
            self.note
            if hasattr(self, "note")
            else None
        )
        _memo=(
            self.memo
            if hasattr(self, "memo")
            else None
        )
        _auto_accept_quote=(
            self.auto_accept_quote
            if hasattr(self, "auto_accept_quote")
            else None
        )
        _client_transfer_id=(
            self.client_transfer_id
            if hasattr(self, "client_transfer_id")
            else None
        )
        _destination_amount=(
            self.destination_amount
            if hasattr(self, "destination_amount")
            else None
        )
        _destination_currency=(
            self.destination_currency
            if hasattr(self, "destination_currency")
            else None
        )
        _transfer_lock_side=(
            self.transfer_lock_side
            if hasattr(self, "transfer_lock_side")
            else None
        )
        _transfer_method_type=(
            self.transfer_method_type
            if hasattr(self, "transfer_method_type")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"source_token={_source_token!s}, "
            f"program_user_id={_program_user_id!s}, "
            f"email={_email!s}, "
            f"note={_note!s}, "
            f"memo={_memo!s}, "
            f"auto_accept_quote={_auto_accept_quote!s}, "
            f"client_transfer_id={_client_transfer_id!s}, "
            f"destination_amount={_destination_amount!s}, "
            f"destination_currency={_destination_currency!s}, "
            f"transfer_lock_side={_transfer_lock_side!s}, "
            f"transfer_method_type={_transfer_method_type!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
