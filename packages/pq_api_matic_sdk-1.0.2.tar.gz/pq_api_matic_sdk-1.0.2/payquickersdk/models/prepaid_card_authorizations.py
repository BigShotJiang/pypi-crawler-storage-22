"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class PrepaidCardAuthorizations(object):
    """Implementation of the '__PrepaidCardAuthorizations' enum.

    Financial types for the [prepaid card](page:resources/prepaid-cards)
    authorization.

    Attributes:
        UNDEFINED: The enum member of type str.
        BANK_TRANSFER: The enum member of type str.
        PAPER_CHECK: The enum member of type str.
        DEPOSIT: The enum member of type str.
        CARD_PURCHASE: The enum member of type str.
        CARD_PURCHASE_REFUND: The enum member of type str.
        FEE: The enum member of type str.
        FEE_REFUND: The enum member of type str.
        PAYMENT: The enum member of type str.
        CANCELLED_PAYMENT: The enum member of type str.
        CASH_WITHDRAWAL: The enum member of type str.
        SPENDBACK: The enum member of type str.
        BANK_TRANSFER_REVERSAL: The enum member of type str.
        SPENDBACK_RETURN: The enum member of type str.
        BANK_TRANSFER_RETURN: The enum member of type str.
        PREPAID_CARD_LOAD: The enum member of type str.
        PREPAID_CARD_UNLOAD: The enum member of type str.
        PROVISIONAL_REFUND: The enum member of type str.
        PAYMENT_RETRACTION: The enum member of type str.
        ACCOUNT_TO_ACCOUNT_TRANSFER: The enum member of type str.
        ESCHEATED_FUNDS_RETURN: The enum member of type str.
        UNSETTLED_AUTHORIZATION: The enum member of type str.
        FEE_REBATE: The enum member of type str.
        EFT_FX_MARGIN: The enum member of type str.
        ELECTRONIC_WALLET_TRANSFER: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    UNDEFINED = "UNDEFINED"

    BANK_TRANSFER = "BANK_TRANSFER"

    PAPER_CHECK = "PAPER_CHECK"

    DEPOSIT = "DEPOSIT"

    CARD_PURCHASE = "CARD_PURCHASE"

    CARD_PURCHASE_REFUND = "CARD_PURCHASE_REFUND"

    FEE = "FEE"

    FEE_REFUND = "FEE_REFUND"

    PAYMENT = "PAYMENT"

    CANCELLED_PAYMENT = "CANCELLED_PAYMENT"

    CASH_WITHDRAWAL = "CASH_WITHDRAWAL"

    SPENDBACK = "SPENDBACK"

    BANK_TRANSFER_REVERSAL = "BANK_TRANSFER_REVERSAL"

    SPENDBACK_RETURN = "SPENDBACK_RETURN"

    BANK_TRANSFER_RETURN = "BANK_TRANSFER_RETURN"

    PREPAID_CARD_LOAD = "PREPAID_CARD_LOAD"

    PREPAID_CARD_UNLOAD = "PREPAID_CARD_UNLOAD"

    PROVISIONAL_REFUND = "PROVISIONAL_REFUND"

    PAYMENT_RETRACTION = "PAYMENT_RETRACTION"

    ACCOUNT_TO_ACCOUNT_TRANSFER = "ACCOUNT_TO_ACCOUNT_TRANSFER"

    ESCHEATED_FUNDS_RETURN = "ESCHEATED_FUNDS_RETURN"

    UNSETTLED_AUTHORIZATION = "UNSETTLED_AUTHORIZATION"

    FEE_REBATE = "FEE_REBATE"

    EFT_FX_MARGIN = "EFT_FX_MARGIN"

    ELECTRONIC_WALLET_TRANSFER = "ELECTRONIC_WALLET_TRANSFER"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
