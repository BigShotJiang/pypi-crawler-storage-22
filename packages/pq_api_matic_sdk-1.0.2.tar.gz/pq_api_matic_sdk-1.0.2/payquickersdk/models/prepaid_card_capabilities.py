"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class PrepaidCardCapabilities(object):
    """Implementation of the '__PrepaidCardCapabilities' enum.

    Capabilities of a [prepaid card](page:resources/prepaid-cards).

    Attributes:
        APPLEPAY: The prepaid card supports ApplePay and can be added to an iOS
            device.
        BANK_IN: The prepaid card supports banking details that allow for loads
            (i.e., direct deposit).
        BANK_OUT: The prepaid card supports transfers to external bank accounts.
        GOOGLEPAY: The prepaid card supports Google Pay and can be added to a
            supported Android device.
        REVEAL_CARD: The prepaid card supports revealing the card details or rendered
            card image via the API.
        REVEAL_PIN: TO BE DONE
        SAMSUNGPAY: The prepaid card supports Samsung Pay and can be added to a
            supported Samsung device.
        SET_PIN: The prepaid card supports setting the PIN via the API.
        CONTACTLESS: The prepaid card supports contactless transactions at supported
            terminals.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    APPLEPAY = "APPLEPAY"

    BANK_IN = "BANK_IN"

    BANK_OUT = "BANK_OUT"

    GOOGLEPAY = "GOOGLEPAY"

    REVEAL_CARD = "REVEAL_CARD"

    REVEAL_PIN = "REVEAL_PIN"

    SAMSUNGPAY = "SAMSUNGPAY"

    SET_PIN = "SET_PIN"

    CONTACTLESS = "CONTACTLESS"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
