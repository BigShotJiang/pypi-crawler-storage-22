"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)


class PrepaidCardDataObject(object):
    """Implementation of the 'PrepaidCardDataObject' model.

    Attributes:
        card_number (float): Unique number on the prepaid card
        cvv_number (str): Three- or four-digit [Card Verification Value
            (CVV)](#/rest/models/structures/cvv) number displayed on the back of a
            credit or debit card
        expiration (str): Date that the card will expire
        name_on_card (str): Name of the card's owner
        token (str): A token used to reveal prepaid card information in the form of
            image data (base64) or JSON.
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "card_number": "cardNumber",
        "cvv_number": "cvvNumber",
        "expiration": "expiration",
        "name_on_card": "nameOnCard",
        "token": "token",
        "links": "links",
    }

    _optionals = [
        "card_number",
        "cvv_number",
        "expiration",
        "name_on_card",
        "token",
        "links",
    ]

    def __init__(
        self,
        card_number=APIHelper.SKIP,
        cvv_number=APIHelper.SKIP,
        expiration=APIHelper.SKIP,
        name_on_card=APIHelper.SKIP,
        token=APIHelper.SKIP,
        links=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a PrepaidCardDataObject instance."""
        # Initialize members of the class
        if card_number is not APIHelper.SKIP:
            self.card_number = card_number
        if cvv_number is not APIHelper.SKIP:
            self.cvv_number = cvv_number
        if expiration is not APIHelper.SKIP:
            self.expiration = expiration
        if name_on_card is not APIHelper.SKIP:
            self.name_on_card = name_on_card
        if token is not APIHelper.SKIP:
            self.token = token
        if links is not APIHelper.SKIP:
            self.links = links

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        card_number =\
            dictionary.get("cardNumber")\
            if dictionary.get("cardNumber")\
                else APIHelper.SKIP
        cvv_number =\
            dictionary.get("cvvNumber")\
            if dictionary.get("cvvNumber")\
                else APIHelper.SKIP
        expiration =\
            dictionary.get("expiration")\
            if dictionary.get("expiration")\
                else APIHelper.SKIP
        name_on_card =\
            dictionary.get("nameOnCard")\
            if dictionary.get("nameOnCard")\
                else APIHelper.SKIP
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(card_number,
                   cvv_number,
                   expiration,
                   name_on_card,
                   token,
                   links,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _card_number=(
            self.card_number
            if hasattr(self, "card_number")
            else None
        )
        _cvv_number=(
            self.cvv_number
            if hasattr(self, "cvv_number")
            else None
        )
        _expiration=(
            self.expiration
            if hasattr(self, "expiration")
            else None
        )
        _name_on_card=(
            self.name_on_card
            if hasattr(self, "name_on_card")
            else None
        )
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_number={_card_number!r}, "
            f"cvv_number={_cvv_number!r}, "
            f"expiration={_expiration!r}, "
            f"name_on_card={_name_on_card!r}, "
            f"token={_token!r}, "
            f"links={_links!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _card_number=(
            self.card_number
            if hasattr(self, "card_number")
            else None
        )
        _cvv_number=(
            self.cvv_number
            if hasattr(self, "cvv_number")
            else None
        )
        _expiration=(
            self.expiration
            if hasattr(self, "expiration")
            else None
        )
        _name_on_card=(
            self.name_on_card
            if hasattr(self, "name_on_card")
            else None
        )
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_number={_card_number!s}, "
            f"cvv_number={_cvv_number!s}, "
            f"expiration={_expiration!s}, "
            f"name_on_card={_name_on_card!s}, "
            f"token={_token!s}, "
            f"links={_links!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
