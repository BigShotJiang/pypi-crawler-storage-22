"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)


class PrepaidCardDataTokenObject(object):
    """Implementation of the 'PrepaidCardDataTokenObject' model.

    Attributes:
        card_processor_type (CardProcessors): The processor type for the prepaid card
        resource_value (str): Value of the target resource
        token (str): [Token](#/rest/models/structures/token) representing the resource
        token_purpose_type (TokenPurposes): Purpose of the token
        url (str): Full path of the URI to perform the request action against a
            prepaid card that replaces the need to build the URL with query params.
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "card_processor_type": "cardProcessorType",
        "token_purpose_type": "tokenPurposeType",
        "resource_value": "resourceValue",
        "token": "token",
        "url": "url",
        "links": "links",
    }

    _optionals = [
        "resource_value",
        "token",
        "url",
        "links",
    ]

    def __init__(
        self,
        card_processor_type=None,
        token_purpose_type=None,
        resource_value=APIHelper.SKIP,
        token=APIHelper.SKIP,
        url=APIHelper.SKIP,
        links=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a PrepaidCardDataTokenObject instance."""
        # Initialize members of the class
        self.card_processor_type = card_processor_type
        if resource_value is not APIHelper.SKIP:
            self.resource_value = resource_value
        if token is not APIHelper.SKIP:
            self.token = token
        self.token_purpose_type = token_purpose_type
        if url is not APIHelper.SKIP:
            self.url = url
        if links is not APIHelper.SKIP:
            self.links = links

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        card_processor_type =\
            dictionary.get("cardProcessorType")\
            if dictionary.get("cardProcessorType")\
                else None
        token_purpose_type =\
            dictionary.get("tokenPurposeType")\
            if dictionary.get("tokenPurposeType")\
                else None
        resource_value =\
            dictionary.get("resourceValue")\
            if dictionary.get("resourceValue")\
                else APIHelper.SKIP
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else APIHelper.SKIP
        url =\
            dictionary.get("url")\
            if dictionary.get("url")\
                else APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(card_processor_type,
                   token_purpose_type,
                   resource_value,
                   token,
                   url,
                   links,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _card_processor_type=self.card_processor_type
        _resource_value=(
            self.resource_value
            if hasattr(self, "resource_value")
            else None
        )
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _token_purpose_type=self.token_purpose_type
        _url=(
            self.url
            if hasattr(self, "url")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_processor_type={_card_processor_type!r}, "
            f"resource_value={_resource_value!r}, "
            f"token={_token!r}, "
            f"token_purpose_type={_token_purpose_type!r}, "
            f"url={_url!r}, "
            f"links={_links!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _card_processor_type=self.card_processor_type
        _resource_value=(
            self.resource_value
            if hasattr(self, "resource_value")
            else None
        )
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _token_purpose_type=self.token_purpose_type
        _url=(
            self.url
            if hasattr(self, "url")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_processor_type={_card_processor_type!s}, "
            f"resource_value={_resource_value!s}, "
            f"token={_token!s}, "
            f"token_purpose_type={_token_purpose_type!s}, "
            f"url={_url!s}, "
            f"links={_links!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
