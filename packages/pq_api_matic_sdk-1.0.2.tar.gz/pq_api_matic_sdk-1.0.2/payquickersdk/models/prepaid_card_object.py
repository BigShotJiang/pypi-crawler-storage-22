"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.bank_account_field import (
    BankAccountField,
)
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)


class PrepaidCardObject(object):
    """Implementation of the 'PrepaidCardObject' model.

    Attributes:
        token (str): [Token](#/rest/models/structures/token) representing the resource
        card_network (CardNetworks): Major [credit card
            network](#/rest/models/structures/card-network) types
        card_number (str): Unique number on the prepaid card
        card_package (str): [Package](#/rest/models/structures/prepaid-card-package)
            for the card being displayed, including artwork, packaging, and delivery
            method
        country (Countries): Throughout the PayQuicker API, the usage of the 2-letter
            alpha code is used in place of the country name, e.g., for bank country
            or residential country.  The 2-letter codes adhere to the ISO 3166-1 spec
            and are listed here for convenience.
        created_on (datetime): Time object was
            [created](#/rest/models/structures/created-on)
        currency (Currencies): [Currency code type](#/rest/models/structures/country)
            for the object
        cvv (str): Three- or four-digit [Card Verification Value
            (CVV)](#/rest/models/structures/cvv) number displayed on the back of a
            credit or debit card
        expires (str): Date and time the object will
            [expire](#/rest/models/structures/expiration)
        status (PrepaidCardStatuses): Current
            [status](#/rest/models/structures/prepaid-card-status) of the prepaid card
        bank_in_details (List[BankAccountField]): The model property of type
            List[BankAccountField].
        capabilities (List[PrepaidCardCapabilities]): The model property of type
            List[PrepaidCardCapabilities].
        user_token (str): Auto-generated unique identifier representing a user,
            prefixed with `user-`.
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "token": "token",
        "card_network": "cardNetwork",
        "card_number": "cardNumber",
        "card_package": "cardPackage",
        "country": "country",
        "created_on": "createdOn",
        "currency": "currency",
        "cvv": "cvv",
        "expires": "expires",
        "status": "status",
        "bank_in_details": "bankInDetails",
        "capabilities": "capabilities",
        "user_token": "userToken",
        "links": "links",
    }

    _optionals = [
        "token",
        "card_network",
        "card_number",
        "card_package",
        "country",
        "created_on",
        "currency",
        "cvv",
        "expires",
        "status",
        "bank_in_details",
        "capabilities",
        "user_token",
        "links",
    ]

    def __init__(
        self,
        token=APIHelper.SKIP,
        card_network=APIHelper.SKIP,
        card_number=APIHelper.SKIP,
        card_package=APIHelper.SKIP,
        country=APIHelper.SKIP,
        created_on=APIHelper.SKIP,
        currency="USD",
        cvv=APIHelper.SKIP,
        expires=APIHelper.SKIP,
        status=APIHelper.SKIP,
        bank_in_details=APIHelper.SKIP,
        capabilities=APIHelper.SKIP,
        user_token=APIHelper.SKIP,
        links=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a PrepaidCardObject instance."""
        # Initialize members of the class
        if token is not APIHelper.SKIP:
            self.token = token
        if card_network is not APIHelper.SKIP:
            self.card_network = card_network
        if card_number is not APIHelper.SKIP:
            self.card_number = card_number
        if card_package is not APIHelper.SKIP:
            self.card_package = card_package
        if country is not APIHelper.SKIP:
            self.country = country
        if created_on is not APIHelper.SKIP:
            self.created_on =\
                 APIHelper.apply_datetime_converter(
                created_on, APIHelper.RFC3339DateTime)\
                 if created_on else None
        self.currency = currency
        if cvv is not APIHelper.SKIP:
            self.cvv = cvv
        if expires is not APIHelper.SKIP:
            self.expires = expires
        if status is not APIHelper.SKIP:
            self.status = status
        if bank_in_details is not APIHelper.SKIP:
            self.bank_in_details = bank_in_details
        if capabilities is not APIHelper.SKIP:
            self.capabilities = capabilities
        if user_token is not APIHelper.SKIP:
            self.user_token = user_token
        if links is not APIHelper.SKIP:
            self.links = links

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else APIHelper.SKIP
        card_network =\
            dictionary.get("cardNetwork")\
            if dictionary.get("cardNetwork")\
                else APIHelper.SKIP
        card_number =\
            dictionary.get("cardNumber")\
            if dictionary.get("cardNumber")\
                else APIHelper.SKIP
        card_package =\
            dictionary.get("cardPackage")\
            if dictionary.get("cardPackage")\
                else APIHelper.SKIP
        country =\
            dictionary.get("country")\
            if dictionary.get("country")\
                else APIHelper.SKIP
        created_on = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("createdOn")).datetime\
            if dictionary.get("createdOn") else APIHelper.SKIP
        currency =\
            dictionary.get("currency")\
            if dictionary.get("currency")\
                else "USD"
        cvv =\
            dictionary.get("cvv")\
            if dictionary.get("cvv")\
                else APIHelper.SKIP
        expires =\
            dictionary.get("expires")\
            if dictionary.get("expires")\
                else APIHelper.SKIP
        status =\
            dictionary.get("status")\
            if dictionary.get("status")\
                else APIHelper.SKIP
        bank_in_details = None
        if dictionary.get("bankInDetails") is not None:
            bank_in_details = [
                BankAccountField.from_dictionary(x)
                    for x in dictionary.get("bankInDetails")
            ]
        else:
            bank_in_details = APIHelper.SKIP
        capabilities =\
            dictionary.get("capabilities")\
            if dictionary.get("capabilities")\
                else APIHelper.SKIP
        user_token =\
            dictionary.get("userToken")\
            if dictionary.get("userToken")\
                else APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(token,
                   card_network,
                   card_number,
                   card_package,
                   country,
                   created_on,
                   currency,
                   cvv,
                   expires,
                   status,
                   bank_in_details,
                   capabilities,
                   user_token,
                   links,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _card_network=(
            self.card_network
            if hasattr(self, "card_network")
            else None
        )
        _card_number=(
            self.card_number
            if hasattr(self, "card_number")
            else None
        )
        _card_package=(
            self.card_package
            if hasattr(self, "card_package")
            else None
        )
        _country=(
            self.country
            if hasattr(self, "country")
            else None
        )
        _created_on=(
            self.created_on
            if hasattr(self, "created_on")
            else None
        )
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _cvv=(
            self.cvv
            if hasattr(self, "cvv")
            else None
        )
        _expires=(
            self.expires
            if hasattr(self, "expires")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _bank_in_details=(
            self.bank_in_details
            if hasattr(self, "bank_in_details")
            else None
        )
        _capabilities=(
            self.capabilities
            if hasattr(self, "capabilities")
            else None
        )
        _user_token=(
            self.user_token
            if hasattr(self, "user_token")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!r}, "
            f"card_network={_card_network!r}, "
            f"card_number={_card_number!r}, "
            f"card_package={_card_package!r}, "
            f"country={_country!r}, "
            f"created_on={_created_on!r}, "
            f"currency={_currency!r}, "
            f"cvv={_cvv!r}, "
            f"expires={_expires!r}, "
            f"status={_status!r}, "
            f"bank_in_details={_bank_in_details!r}, "
            f"capabilities={_capabilities!r}, "
            f"user_token={_user_token!r}, "
            f"links={_links!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _card_network=(
            self.card_network
            if hasattr(self, "card_network")
            else None
        )
        _card_number=(
            self.card_number
            if hasattr(self, "card_number")
            else None
        )
        _card_package=(
            self.card_package
            if hasattr(self, "card_package")
            else None
        )
        _country=(
            self.country
            if hasattr(self, "country")
            else None
        )
        _created_on=(
            self.created_on
            if hasattr(self, "created_on")
            else None
        )
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _cvv=(
            self.cvv
            if hasattr(self, "cvv")
            else None
        )
        _expires=(
            self.expires
            if hasattr(self, "expires")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _bank_in_details=(
            self.bank_in_details
            if hasattr(self, "bank_in_details")
            else None
        )
        _capabilities=(
            self.capabilities
            if hasattr(self, "capabilities")
            else None
        )
        _user_token=(
            self.user_token
            if hasattr(self, "user_token")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!s}, "
            f"card_network={_card_network!s}, "
            f"card_number={_card_number!s}, "
            f"card_package={_card_package!s}, "
            f"country={_country!s}, "
            f"created_on={_created_on!s}, "
            f"currency={_currency!s}, "
            f"cvv={_cvv!s}, "
            f"expires={_expires!s}, "
            f"status={_status!s}, "
            f"bank_in_details={_bank_in_details!s}, "
            f"capabilities={_capabilities!s}, "
            f"user_token={_user_token!s}, "
            f"links={_links!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
