"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)
from payquickersdk.models.metadata_items import (
    MetadataItems,
)


class PrepaidCardPinResult(object):
    """Implementation of the '_PrepaidCardPinResult' model.

    Attributes:
        card_pin (str): [Card PIN](#/rest/models/structures/prepaid-card-pin) for ATM
            and Debit usage
        token (str): [Token](#/rest/models/structures/prepaid-card-pin-token) used as
            part of a two-leg card PIN reveal request sent directly from the client
            that generally involves a second piece of data, such as the CVV code on
            the back of the card.
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        meta (MetadataItems): The model property of type MetadataItems.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "card_pin": "cardPin",
        "token": "token",
        "links": "links",
        "meta": "meta",
    }

    _optionals = [
        "card_pin",
        "token",
        "links",
        "meta",
    ]

    def __init__(
        self,
        card_pin=APIHelper.SKIP,
        token=APIHelper.SKIP,
        links=APIHelper.SKIP,
        meta=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a PrepaidCardPinResult instance."""
        # Initialize members of the class
        if card_pin is not APIHelper.SKIP:
            self.card_pin = card_pin
        if token is not APIHelper.SKIP:
            self.token = token
        if links is not APIHelper.SKIP:
            self.links = links
        if meta is not APIHelper.SKIP:
            self.meta = meta

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        card_pin =\
            dictionary.get("cardPin")\
            if dictionary.get("cardPin")\
                else APIHelper.SKIP
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP
        meta =\
            MetadataItems.from_dictionary(
                dictionary.get("meta"))\
                if "meta" in dictionary.keys()\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(card_pin,
                   token,
                   links,
                   meta,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _card_pin=(
            self.card_pin
            if hasattr(self, "card_pin")
            else None
        )
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_pin={_card_pin!r}, "
            f"token={_token!r}, "
            f"links={_links!r}, "
            f"meta={_meta!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _card_pin=(
            self.card_pin
            if hasattr(self, "card_pin")
            else None
        )
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_pin={_card_pin!s}, "
            f"token={_token!s}, "
            f"links={_links!s}, "
            f"meta={_meta!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
