"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)


class PrepaidCardPinTokenObject(object):
    """Implementation of the 'PrepaidCardPinTokenObject' model.

    Attributes:
        card_processor_type (CardProcessors): The processor type for the prepaid card
        card_pin_token (str):
            [Token](#/rest/models/structures/prepaid-card-pin-token) used as part of
            a two-leg card PIN reveal request sent directly from the client that
            generally involves a second piece of data, such as the CVV code on the
            back of the card.
        token (str): [Token](#/rest/models/structures/token) representing the resource
        url (str): Full path of the URI to perform the request action against a
            prepaid card that replaces the need to build the URL with query params.
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "card_processor_type": "cardProcessorType",
        "card_pin_token": "cardPinToken",
        "token": "token",
        "url": "url",
        "links": "links",
    }

    _optionals = [
        "card_processor_type",
        "card_pin_token",
        "token",
        "url",
        "links",
    ]

    def __init__(
        self,
        card_processor_type=APIHelper.SKIP,
        card_pin_token=APIHelper.SKIP,
        token=APIHelper.SKIP,
        url=APIHelper.SKIP,
        links=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a PrepaidCardPinTokenObject instance."""
        # Initialize members of the class
        if card_processor_type is not APIHelper.SKIP:
            self.card_processor_type = card_processor_type
        if card_pin_token is not APIHelper.SKIP:
            self.card_pin_token = card_pin_token
        if token is not APIHelper.SKIP:
            self.token = token
        if url is not APIHelper.SKIP:
            self.url = url
        if links is not APIHelper.SKIP:
            self.links = links

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        card_processor_type =\
            dictionary.get("cardProcessorType")\
            if dictionary.get("cardProcessorType")\
                else APIHelper.SKIP
        card_pin_token =\
            dictionary.get("cardPinToken")\
            if dictionary.get("cardPinToken")\
                else APIHelper.SKIP
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else APIHelper.SKIP
        url =\
            dictionary.get("url")\
            if dictionary.get("url")\
                else APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(card_processor_type,
                   card_pin_token,
                   token,
                   url,
                   links,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _card_processor_type=(
            self.card_processor_type
            if hasattr(self, "card_processor_type")
            else None
        )
        _card_pin_token=(
            self.card_pin_token
            if hasattr(self, "card_pin_token")
            else None
        )
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _url=(
            self.url
            if hasattr(self, "url")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_processor_type={_card_processor_type!r}, "
            f"card_pin_token={_card_pin_token!r}, "
            f"token={_token!r}, "
            f"url={_url!r}, "
            f"links={_links!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _card_processor_type=(
            self.card_processor_type
            if hasattr(self, "card_processor_type")
            else None
        )
        _card_pin_token=(
            self.card_pin_token
            if hasattr(self, "card_pin_token")
            else None
        )
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _url=(
            self.url
            if hasattr(self, "url")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_processor_type={_card_processor_type!s}, "
            f"card_pin_token={_card_pin_token!s}, "
            f"token={_token!s}, "
            f"url={_url!s}, "
            f"links={_links!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
