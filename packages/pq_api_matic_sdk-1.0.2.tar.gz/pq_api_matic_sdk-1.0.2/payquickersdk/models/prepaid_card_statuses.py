"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class PrepaidCardStatuses(object):
    """Implementation of the '__PrepaidCardStatuses' enum.

    Current [status](#/rest/models/structures/prepaid-card-status) of the prepaid card

    Attributes:
        ACTIVATED: The prepaid card is active and ready to use.
        CLOSED: The prepaid card is damaged and is no longer usable.
        CLOSED_LOST_STOLEN_DAMAGED: The prepaid card is expired and is no longer
            usable.
        COMPLIANCE_HOLD: The prepaid card has been suspended for compliance reasons.
        EXPIRED: The expiration date set for the prepaid card has elapsed. The
            prepaid card will no longer be accepted.
        PENDING_ACTIVATION: The prepaid card has been created but has not yet been
            activated. Instantly issued cards are activated automatically.Plastic
            cards are activated upon delivery and require the CVV on the back of the
            prepaid card to complete.
        QUEUED: The prepaid card is awaiting order placement and will transition to
            PENDING_ACTIVATION once ordered.
        STAGED: TO BE DONE
        SUSPENDED: The prepaid card has been suspended and may neither send nor
            receive funds.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    ACTIVATED = "ACTIVATED"

    CLOSED = "CLOSED"

    CLOSED_LOST_STOLEN_DAMAGED = "CLOSED_LOST_STOLEN_DAMAGED"

    COMPLIANCE_HOLD = "COMPLIANCE_HOLD"

    EXPIRED = "EXPIRED"

    PENDING_ACTIVATION = "PENDING_ACTIVATION"

    QUEUED = "QUEUED"

    STAGED = "STAGED"

    SUSPENDED = "SUSPENDED"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
