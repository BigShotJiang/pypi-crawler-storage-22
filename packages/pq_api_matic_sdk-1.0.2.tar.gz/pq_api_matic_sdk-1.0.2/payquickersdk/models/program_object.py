"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.electronic_wallet_type import (
    ElectronicWalletType,
)
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)


class ProgramObject(object):
    """Implementation of the 'ProgramObject' model.

    Attributes:
        token (str): Auto-generated unique identifier representing a program,
            prefixed with prog-
        currency (Currencies): [Currency code type](#/rest/models/structures/country)
            for the object
        bank (BankTypes): Name of the bank
        electronic_wallets (List[ElectronicWalletType]): The model property of type
            List[ElectronicWalletType].
        mtype (ProgramTypes): Indicates the type of program associated with a prepaid
            card
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "token": "token",
        "currency": "currency",
        "bank": "bank",
        "mtype": "type",
        "electronic_wallets": "electronicWallets",
        "links": "links",
    }

    _optionals = [
        "electronic_wallets",
        "links",
    ]

    def __init__(
        self,
        token=None,
        currency="USD",
        bank=None,
        mtype=None,
        electronic_wallets=APIHelper.SKIP,
        links=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a ProgramObject instance."""
        # Initialize members of the class
        self.token = token
        self.currency = currency
        self.bank = bank
        if electronic_wallets is not APIHelper.SKIP:
            self.electronic_wallets = electronic_wallets
        self.mtype = mtype
        if links is not APIHelper.SKIP:
            self.links = links

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else None
        currency =\
            dictionary.get("currency")\
            if dictionary.get("currency")\
                else "USD"
        bank =\
            dictionary.get("bank")\
            if dictionary.get("bank")\
                else None
        mtype =\
            dictionary.get("type")\
            if dictionary.get("type")\
                else None
        electronic_wallets = None
        if dictionary.get("electronicWallets") is not None:
            electronic_wallets = [
                ElectronicWalletType.from_dictionary(x)
                    for x in dictionary.get("electronicWallets")
            ]
        else:
            electronic_wallets = APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(token,
                   currency,
                   bank,
                   mtype,
                   electronic_wallets,
                   links,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _token=self.token
        _currency=self.currency
        _bank=self.bank
        _electronic_wallets=(
            self.electronic_wallets
            if hasattr(self, "electronic_wallets")
            else None
        )
        _mtype=self.mtype
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!r}, "
            f"currency={_currency!r}, "
            f"bank={_bank!r}, "
            f"electronic_wallets={_electronic_wallets!r}, "
            f"mtype={_mtype!r}, "
            f"links={_links!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _token=self.token
        _currency=self.currency
        _bank=self.bank
        _electronic_wallets=(
            self.electronic_wallets
            if hasattr(self, "electronic_wallets")
            else None
        )
        _mtype=self.mtype
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!s}, "
            f"currency={_currency!s}, "
            f"bank={_bank!s}, "
            f"electronic_wallets={_electronic_wallets!s}, "
            f"mtype={_mtype!s}, "
            f"links={_links!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
