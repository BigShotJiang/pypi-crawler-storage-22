"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class ReceiptDetails(object):
    """Implementation of the '_ReceiptDetails' model.

    Attributes:
        bank_account_id (str): Bank account ID for the bank account
        bank_account_id_type (BankAccountFields): Classifies bank account [field
            types](#/rest/models/structures/bank-account-fields)
        bank_name (str): Name of the bank the account is registered to
        bank_id (str): The bank id
        bank_id_type (BankAccountFields): Classifies bank account [field
            types](#/rest/models/structures/bank-account-fields)
        branch_address (str): The bank branch address
        branch_city (str): The bank branch city
        branch_id (str): The bank branch id
        branch_name (str): The bank branch name
        branch_postal_code (str): The bank branch postal code
        branch_phone_number (str): The bank branch phone number
        branch_region (str): The bank branch region
        beneficary_tax_id (str): The beneficiary's tax id
        beneficary_tax_id_type (BankAccountFields): Classifies bank account [field
            types](#/rest/models/structures/bank-account-fields)
        beneficary_name (str): The name of the person chosen to inherit your account
        memo (str): Optional internal [memo](#/rest/models/structures/memo) not
            visible to the user
        note (str): [Optional comments](#/rest/models/structures/notes) visible to
            the user
        correlation_token (str): [Token](#/rest/models/structures/token) representing
            the resource
        card_expiry_date (str): Date that the card will expire
        card_holder_name (str): Name of the card's owner
        card_number (str): Unique number on the prepaid card
        electronic_wallet_account_number (str): Account number for the electronic
            wallet
        electronic_wallet_account_number_type (ElectronicWalletFields): Classifies
            electronic wallet [field
            types](#/rest/models/structures/electronic-wallet-fields)
        electronic_wallet_government_id (str): Government ID for the electronic wallet
        electronic_wallet_government_id_type (ElectronicWalletFields): Classifies
            electronic wallet [field
            types](#/rest/models/structures/electronic-wallet-fields)
        electronic_wallet_type (ElectronicWalletTypes): Name of the electronic wallet
        mobile_phone_number (str): The model property of type str.
        electronic_funds_transfer_type (ElectronicFundsTransferTypes): The type of
            transfer performed
        electronic_funds_transfer_failure_type (ElectronicTransferFailureTypes): The
            type of failure for a bank transfer
        electronic_transfer_status_type (ElectronicTransferStatusTypes): The status
            of a bank transfer
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "bank_account_id": "bankAccountId",
        "bank_account_id_type": "bankAccountIdType",
        "bank_name": "bankName",
        "bank_id": "bankId",
        "bank_id_type": "bankIdType",
        "branch_address": "branchAddress",
        "branch_city": "branchCity",
        "branch_id": "branchId",
        "branch_name": "branchName",
        "branch_postal_code": "branchPostalCode",
        "branch_phone_number": "branchPhoneNumber",
        "branch_region": "branchRegion",
        "beneficary_tax_id": "beneficaryTaxId",
        "beneficary_tax_id_type": "beneficaryTaxIdType",
        "beneficary_name": "beneficaryName",
        "memo": "memo",
        "note": "note",
        "correlation_token": "correlationToken",
        "card_expiry_date": "cardExpiryDate",
        "card_holder_name": "cardHolderName",
        "card_number": "cardNumber",
        "electronic_wallet_account_number": "electronicWalletAccountNumber",
        "electronic_wallet_account_number_type": "electronicWalletAccountNumberType",
        "electronic_wallet_government_id": "electronicWalletGovernmentId",
        "electronic_wallet_government_id_type": "electronicWalletGovernmentIdType",
        "electronic_wallet_type": "electronicWalletType",
        "mobile_phone_number": "mobilePhoneNumber",
        "electronic_funds_transfer_type": "electronicFundsTransferType",
        "electronic_funds_transfer_failure_type": "electronicFundsTransferFailureType",
        "electronic_transfer_status_type": "electronicTransferStatusType",
    }

    _optionals = [
        "bank_account_id",
        "bank_account_id_type",
        "bank_name",
        "bank_id",
        "bank_id_type",
        "branch_address",
        "branch_city",
        "branch_id",
        "branch_name",
        "branch_postal_code",
        "branch_phone_number",
        "branch_region",
        "beneficary_tax_id",
        "beneficary_tax_id_type",
        "beneficary_name",
        "memo",
        "note",
        "correlation_token",
        "card_expiry_date",
        "card_holder_name",
        "card_number",
        "electronic_wallet_account_number",
        "electronic_wallet_account_number_type",
        "electronic_wallet_government_id",
        "electronic_wallet_government_id_type",
        "electronic_wallet_type",
        "mobile_phone_number",
        "electronic_funds_transfer_type",
        "electronic_funds_transfer_failure_type",
        "electronic_transfer_status_type",
    ]

    def __init__(
        self,
        bank_account_id=APIHelper.SKIP,
        bank_account_id_type=APIHelper.SKIP,
        bank_name=APIHelper.SKIP,
        bank_id=APIHelper.SKIP,
        bank_id_type=APIHelper.SKIP,
        branch_address=APIHelper.SKIP,
        branch_city=APIHelper.SKIP,
        branch_id=APIHelper.SKIP,
        branch_name=APIHelper.SKIP,
        branch_postal_code=APIHelper.SKIP,
        branch_phone_number=APIHelper.SKIP,
        branch_region=APIHelper.SKIP,
        beneficary_tax_id=APIHelper.SKIP,
        beneficary_tax_id_type=APIHelper.SKIP,
        beneficary_name=APIHelper.SKIP,
        memo=APIHelper.SKIP,
        note=APIHelper.SKIP,
        correlation_token=APIHelper.SKIP,
        card_expiry_date=APIHelper.SKIP,
        card_holder_name=APIHelper.SKIP,
        card_number=APIHelper.SKIP,
        electronic_wallet_account_number=APIHelper.SKIP,
        electronic_wallet_account_number_type=APIHelper.SKIP,
        electronic_wallet_government_id=APIHelper.SKIP,
        electronic_wallet_government_id_type=APIHelper.SKIP,
        electronic_wallet_type=APIHelper.SKIP,
        mobile_phone_number=APIHelper.SKIP,
        electronic_funds_transfer_type=APIHelper.SKIP,
        electronic_funds_transfer_failure_type=APIHelper.SKIP,
        electronic_transfer_status_type=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a ReceiptDetails instance."""
        # Initialize members of the class
        if bank_account_id is not APIHelper.SKIP:
            self.bank_account_id = bank_account_id
        if bank_account_id_type is not APIHelper.SKIP:
            self.bank_account_id_type = bank_account_id_type
        if bank_name is not APIHelper.SKIP:
            self.bank_name = bank_name
        if bank_id is not APIHelper.SKIP:
            self.bank_id = bank_id
        if bank_id_type is not APIHelper.SKIP:
            self.bank_id_type = bank_id_type
        if branch_address is not APIHelper.SKIP:
            self.branch_address = branch_address
        if branch_city is not APIHelper.SKIP:
            self.branch_city = branch_city
        if branch_id is not APIHelper.SKIP:
            self.branch_id = branch_id
        if branch_name is not APIHelper.SKIP:
            self.branch_name = branch_name
        if branch_postal_code is not APIHelper.SKIP:
            self.branch_postal_code = branch_postal_code
        if branch_phone_number is not APIHelper.SKIP:
            self.branch_phone_number = branch_phone_number
        if branch_region is not APIHelper.SKIP:
            self.branch_region = branch_region
        if beneficary_tax_id is not APIHelper.SKIP:
            self.beneficary_tax_id = beneficary_tax_id
        if beneficary_tax_id_type is not APIHelper.SKIP:
            self.beneficary_tax_id_type = beneficary_tax_id_type
        if beneficary_name is not APIHelper.SKIP:
            self.beneficary_name = beneficary_name
        if memo is not APIHelper.SKIP:
            self.memo = memo
        if note is not APIHelper.SKIP:
            self.note = note
        if correlation_token is not APIHelper.SKIP:
            self.correlation_token = correlation_token
        if card_expiry_date is not APIHelper.SKIP:
            self.card_expiry_date = card_expiry_date
        if card_holder_name is not APIHelper.SKIP:
            self.card_holder_name = card_holder_name
        if card_number is not APIHelper.SKIP:
            self.card_number = card_number
        if electronic_wallet_account_number is not APIHelper.SKIP:
            self.electronic_wallet_account_number = electronic_wallet_account_number
        if electronic_wallet_account_number_type is not APIHelper.SKIP:
            self.electronic_wallet_account_number_type =\
                 electronic_wallet_account_number_type
        if electronic_wallet_government_id is not APIHelper.SKIP:
            self.electronic_wallet_government_id = electronic_wallet_government_id
        if electronic_wallet_government_id_type is not APIHelper.SKIP:
            self.electronic_wallet_government_id_type =\
                 electronic_wallet_government_id_type
        if electronic_wallet_type is not APIHelper.SKIP:
            self.electronic_wallet_type = electronic_wallet_type
        if mobile_phone_number is not APIHelper.SKIP:
            self.mobile_phone_number = mobile_phone_number
        if electronic_funds_transfer_type is not APIHelper.SKIP:
            self.electronic_funds_transfer_type = electronic_funds_transfer_type
        if electronic_funds_transfer_failure_type is not APIHelper.SKIP:
            self.electronic_funds_transfer_failure_type =\
                 electronic_funds_transfer_failure_type
        if electronic_transfer_status_type is not APIHelper.SKIP:
            self.electronic_transfer_status_type = electronic_transfer_status_type

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        bank_account_id =\
            dictionary.get("bankAccountId")\
            if dictionary.get("bankAccountId")\
                else APIHelper.SKIP
        bank_account_id_type =\
            dictionary.get("bankAccountIdType")\
            if dictionary.get("bankAccountIdType")\
                else APIHelper.SKIP
        bank_name =\
            dictionary.get("bankName")\
            if dictionary.get("bankName")\
                else APIHelper.SKIP
        bank_id =\
            dictionary.get("bankId")\
            if dictionary.get("bankId")\
                else APIHelper.SKIP
        bank_id_type =\
            dictionary.get("bankIdType")\
            if dictionary.get("bankIdType")\
                else APIHelper.SKIP
        branch_address =\
            dictionary.get("branchAddress")\
            if dictionary.get("branchAddress")\
                else APIHelper.SKIP
        branch_city =\
            dictionary.get("branchCity")\
            if dictionary.get("branchCity")\
                else APIHelper.SKIP
        branch_id =\
            dictionary.get("branchId")\
            if dictionary.get("branchId")\
                else APIHelper.SKIP
        branch_name =\
            dictionary.get("branchName")\
            if dictionary.get("branchName")\
                else APIHelper.SKIP
        branch_postal_code =\
            dictionary.get("branchPostalCode")\
            if dictionary.get("branchPostalCode")\
                else APIHelper.SKIP
        branch_phone_number =\
            dictionary.get("branchPhoneNumber")\
            if dictionary.get("branchPhoneNumber")\
                else APIHelper.SKIP
        branch_region =\
            dictionary.get("branchRegion")\
            if dictionary.get("branchRegion")\
                else APIHelper.SKIP
        beneficary_tax_id =\
            dictionary.get("beneficaryTaxId")\
            if dictionary.get("beneficaryTaxId")\
                else APIHelper.SKIP
        beneficary_tax_id_type =\
            dictionary.get("beneficaryTaxIdType")\
            if dictionary.get("beneficaryTaxIdType")\
                else APIHelper.SKIP
        beneficary_name =\
            dictionary.get("beneficaryName")\
            if dictionary.get("beneficaryName")\
                else APIHelper.SKIP
        memo =\
            dictionary.get("memo")\
            if dictionary.get("memo")\
                else APIHelper.SKIP
        note =\
            dictionary.get("note")\
            if dictionary.get("note")\
                else APIHelper.SKIP
        correlation_token =\
            dictionary.get("correlationToken")\
            if dictionary.get("correlationToken")\
                else APIHelper.SKIP
        card_expiry_date =\
            dictionary.get("cardExpiryDate")\
            if dictionary.get("cardExpiryDate")\
                else APIHelper.SKIP
        card_holder_name =\
            dictionary.get("cardHolderName")\
            if dictionary.get("cardHolderName")\
                else APIHelper.SKIP
        card_number =\
            dictionary.get("cardNumber")\
            if dictionary.get("cardNumber")\
                else APIHelper.SKIP
        electronic_wallet_account_number =\
            dictionary.get("electronicWalletAccountNumber")\
            if dictionary.get("electronicWalletAccountNumber")\
                else APIHelper.SKIP
        electronic_wallet_account_number_type =\
            dictionary.get("electronicWalletAccountNumberType")\
            if dictionary.get("electronicWalletAccountNumberType")\
                else APIHelper.SKIP
        electronic_wallet_government_id =\
            dictionary.get("electronicWalletGovernmentId")\
            if dictionary.get("electronicWalletGovernmentId")\
                else APIHelper.SKIP
        electronic_wallet_government_id_type =\
            dictionary.get("electronicWalletGovernmentIdType")\
            if dictionary.get("electronicWalletGovernmentIdType")\
                else APIHelper.SKIP
        electronic_wallet_type =\
            dictionary.get("electronicWalletType")\
            if dictionary.get("electronicWalletType")\
                else APIHelper.SKIP
        mobile_phone_number =\
            dictionary.get("mobilePhoneNumber")\
            if dictionary.get("mobilePhoneNumber")\
                else APIHelper.SKIP
        electronic_funds_transfer_type =\
            dictionary.get("electronicFundsTransferType")\
            if dictionary.get("electronicFundsTransferType")\
                else APIHelper.SKIP
        electronic_funds_transfer_failure_type =\
            dictionary.get("electronicFundsTransferFailureType")\
            if dictionary.get("electronicFundsTransferFailureType")\
                else APIHelper.SKIP
        electronic_transfer_status_type =\
            dictionary.get("electronicTransferStatusType")\
            if dictionary.get("electronicTransferStatusType")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(bank_account_id,
                   bank_account_id_type,
                   bank_name,
                   bank_id,
                   bank_id_type,
                   branch_address,
                   branch_city,
                   branch_id,
                   branch_name,
                   branch_postal_code,
                   branch_phone_number,
                   branch_region,
                   beneficary_tax_id,
                   beneficary_tax_id_type,
                   beneficary_name,
                   memo,
                   note,
                   correlation_token,
                   card_expiry_date,
                   card_holder_name,
                   card_number,
                   electronic_wallet_account_number,
                   electronic_wallet_account_number_type,
                   electronic_wallet_government_id,
                   electronic_wallet_government_id_type,
                   electronic_wallet_type,
                   mobile_phone_number,
                   electronic_funds_transfer_type,
                   electronic_funds_transfer_failure_type,
                   electronic_transfer_status_type,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _bank_account_id=(
            self.bank_account_id
            if hasattr(self, "bank_account_id")
            else None
        )
        _bank_account_id_type=(
            self.bank_account_id_type
            if hasattr(self, "bank_account_id_type")
            else None
        )
        _bank_name=(
            self.bank_name
            if hasattr(self, "bank_name")
            else None
        )
        _bank_id=(
            self.bank_id
            if hasattr(self, "bank_id")
            else None
        )
        _bank_id_type=(
            self.bank_id_type
            if hasattr(self, "bank_id_type")
            else None
        )
        _branch_address=(
            self.branch_address
            if hasattr(self, "branch_address")
            else None
        )
        _branch_city=(
            self.branch_city
            if hasattr(self, "branch_city")
            else None
        )
        _branch_id=(
            self.branch_id
            if hasattr(self, "branch_id")
            else None
        )
        _branch_name=(
            self.branch_name
            if hasattr(self, "branch_name")
            else None
        )
        _branch_postal_code=(
            self.branch_postal_code
            if hasattr(self, "branch_postal_code")
            else None
        )
        _branch_phone_number=(
            self.branch_phone_number
            if hasattr(self, "branch_phone_number")
            else None
        )
        _branch_region=(
            self.branch_region
            if hasattr(self, "branch_region")
            else None
        )
        _beneficary_tax_id=(
            self.beneficary_tax_id
            if hasattr(self, "beneficary_tax_id")
            else None
        )
        _beneficary_tax_id_type=(
            self.beneficary_tax_id_type
            if hasattr(self, "beneficary_tax_id_type")
            else None
        )
        _beneficary_name=(
            self.beneficary_name
            if hasattr(self, "beneficary_name")
            else None
        )
        _memo=(
            self.memo
            if hasattr(self, "memo")
            else None
        )
        _note=(
            self.note
            if hasattr(self, "note")
            else None
        )
        _correlation_token=(
            self.correlation_token
            if hasattr(self, "correlation_token")
            else None
        )
        _card_expiry_date=(
            self.card_expiry_date
            if hasattr(self, "card_expiry_date")
            else None
        )
        _card_holder_name=(
            self.card_holder_name
            if hasattr(self, "card_holder_name")
            else None
        )
        _card_number=(
            self.card_number
            if hasattr(self, "card_number")
            else None
        )
        _electronic_wallet_account_number=(
            self.electronic_wallet_account_number
            if hasattr(self, "electronic_wallet_account_number")
            else None
        )
        _electronic_wallet_account_number_type=(
            self.electronic_wallet_account_number_type
            if hasattr(self, "electronic_wallet_account_number_type")
            else None
        )
        _electronic_wallet_government_id=(
            self.electronic_wallet_government_id
            if hasattr(self, "electronic_wallet_government_id")
            else None
        )
        _electronic_wallet_government_id_type=(
            self.electronic_wallet_government_id_type
            if hasattr(self, "electronic_wallet_government_id_type")
            else None
        )
        _electronic_wallet_type=(
            self.electronic_wallet_type
            if hasattr(self, "electronic_wallet_type")
            else None
        )
        _mobile_phone_number=(
            self.mobile_phone_number
            if hasattr(self, "mobile_phone_number")
            else None
        )
        _electronic_funds_transfer_type=(
            self.electronic_funds_transfer_type
            if hasattr(self, "electronic_funds_transfer_type")
            else None
        )
        _electronic_funds_transfer_failure_type=(
            self.electronic_funds_transfer_failure_type
            if hasattr(self, "electronic_funds_transfer_failure_type")
            else None
        )
        _electronic_transfer_status_type=(
            self.electronic_transfer_status_type
            if hasattr(self, "electronic_transfer_status_type")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"bank_account_id={_bank_account_id!r}, "
            f"bank_account_id_type={_bank_account_id_type!r}, "
            f"bank_name={_bank_name!r}, "
            f"bank_id={_bank_id!r}, "
            f"bank_id_type={_bank_id_type!r}, "
            f"branch_address={_branch_address!r}, "
            f"branch_city={_branch_city!r}, "
            f"branch_id={_branch_id!r}, "
            f"branch_name={_branch_name!r}, "
            f"branch_postal_code={_branch_postal_code!r}, "
            f"branch_phone_number={_branch_phone_number!r}, "
            f"branch_region={_branch_region!r}, "
            f"beneficary_tax_id={_beneficary_tax_id!r}, "
            f"beneficary_tax_id_type={_beneficary_tax_id_type!r}, "
            f"beneficary_name={_beneficary_name!r}, "
            f"memo={_memo!r}, "
            f"note={_note!r}, "
            f"correlation_token={_correlation_token!r}, "
            f"card_expiry_date={_card_expiry_date!r}, "
            f"card_holder_name={_card_holder_name!r}, "
            f"card_number={_card_number!r}, "
            f"electronic_wallet_account_number={_electronic_wallet_account_number!r}, "
            f"electronic_wallet_account_number_type={_electronic_wallet_account_number_type!r}, "
            f"electronic_wallet_government_id={_electronic_wallet_government_id!r}, "
            f"electronic_wallet_government_id_type={_electronic_wallet_government_id_type!r}, "
            f"electronic_wallet_type={_electronic_wallet_type!r}, "
            f"mobile_phone_number={_mobile_phone_number!r}, "
            f"electronic_funds_transfer_type={_electronic_funds_transfer_type!r}, "
            f"electronic_funds_transfer_failure_type={_electronic_funds_transfer_failure_type!r}, "
            f"electronic_transfer_status_type={_electronic_transfer_status_type!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _bank_account_id=(
            self.bank_account_id
            if hasattr(self, "bank_account_id")
            else None
        )
        _bank_account_id_type=(
            self.bank_account_id_type
            if hasattr(self, "bank_account_id_type")
            else None
        )
        _bank_name=(
            self.bank_name
            if hasattr(self, "bank_name")
            else None
        )
        _bank_id=(
            self.bank_id
            if hasattr(self, "bank_id")
            else None
        )
        _bank_id_type=(
            self.bank_id_type
            if hasattr(self, "bank_id_type")
            else None
        )
        _branch_address=(
            self.branch_address
            if hasattr(self, "branch_address")
            else None
        )
        _branch_city=(
            self.branch_city
            if hasattr(self, "branch_city")
            else None
        )
        _branch_id=(
            self.branch_id
            if hasattr(self, "branch_id")
            else None
        )
        _branch_name=(
            self.branch_name
            if hasattr(self, "branch_name")
            else None
        )
        _branch_postal_code=(
            self.branch_postal_code
            if hasattr(self, "branch_postal_code")
            else None
        )
        _branch_phone_number=(
            self.branch_phone_number
            if hasattr(self, "branch_phone_number")
            else None
        )
        _branch_region=(
            self.branch_region
            if hasattr(self, "branch_region")
            else None
        )
        _beneficary_tax_id=(
            self.beneficary_tax_id
            if hasattr(self, "beneficary_tax_id")
            else None
        )
        _beneficary_tax_id_type=(
            self.beneficary_tax_id_type
            if hasattr(self, "beneficary_tax_id_type")
            else None
        )
        _beneficary_name=(
            self.beneficary_name
            if hasattr(self, "beneficary_name")
            else None
        )
        _memo=(
            self.memo
            if hasattr(self, "memo")
            else None
        )
        _note=(
            self.note
            if hasattr(self, "note")
            else None
        )
        _correlation_token=(
            self.correlation_token
            if hasattr(self, "correlation_token")
            else None
        )
        _card_expiry_date=(
            self.card_expiry_date
            if hasattr(self, "card_expiry_date")
            else None
        )
        _card_holder_name=(
            self.card_holder_name
            if hasattr(self, "card_holder_name")
            else None
        )
        _card_number=(
            self.card_number
            if hasattr(self, "card_number")
            else None
        )
        _electronic_wallet_account_number=(
            self.electronic_wallet_account_number
            if hasattr(self, "electronic_wallet_account_number")
            else None
        )
        _electronic_wallet_account_number_type=(
            self.electronic_wallet_account_number_type
            if hasattr(self, "electronic_wallet_account_number_type")
            else None
        )
        _electronic_wallet_government_id=(
            self.electronic_wallet_government_id
            if hasattr(self, "electronic_wallet_government_id")
            else None
        )
        _electronic_wallet_government_id_type=(
            self.electronic_wallet_government_id_type
            if hasattr(self, "electronic_wallet_government_id_type")
            else None
        )
        _electronic_wallet_type=(
            self.electronic_wallet_type
            if hasattr(self, "electronic_wallet_type")
            else None
        )
        _mobile_phone_number=(
            self.mobile_phone_number
            if hasattr(self, "mobile_phone_number")
            else None
        )
        _electronic_funds_transfer_type=(
            self.electronic_funds_transfer_type
            if hasattr(self, "electronic_funds_transfer_type")
            else None
        )
        _electronic_funds_transfer_failure_type=(
            self.electronic_funds_transfer_failure_type
            if hasattr(self, "electronic_funds_transfer_failure_type")
            else None
        )
        _electronic_transfer_status_type=(
            self.electronic_transfer_status_type
            if hasattr(self, "electronic_transfer_status_type")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"bank_account_id={_bank_account_id!s}, "
            f"bank_account_id_type={_bank_account_id_type!s}, "
            f"bank_name={_bank_name!s}, "
            f"bank_id={_bank_id!s}, "
            f"bank_id_type={_bank_id_type!s}, "
            f"branch_address={_branch_address!s}, "
            f"branch_city={_branch_city!s}, "
            f"branch_id={_branch_id!s}, "
            f"branch_name={_branch_name!s}, "
            f"branch_postal_code={_branch_postal_code!s}, "
            f"branch_phone_number={_branch_phone_number!s}, "
            f"branch_region={_branch_region!s}, "
            f"beneficary_tax_id={_beneficary_tax_id!s}, "
            f"beneficary_tax_id_type={_beneficary_tax_id_type!s}, "
            f"beneficary_name={_beneficary_name!s}, "
            f"memo={_memo!s}, "
            f"note={_note!s}, "
            f"correlation_token={_correlation_token!s}, "
            f"card_expiry_date={_card_expiry_date!s}, "
            f"card_holder_name={_card_holder_name!s}, "
            f"card_number={_card_number!s}, "
            f"electronic_wallet_account_number={_electronic_wallet_account_number!s}, "
            f"electronic_wallet_account_number_type={_electronic_wallet_account_number_type!s}, "
            f"electronic_wallet_government_id={_electronic_wallet_government_id!s}, "
            f"electronic_wallet_government_id_type={_electronic_wallet_government_id_type!s}, "
            f"electronic_wallet_type={_electronic_wallet_type!s}, "
            f"mobile_phone_number={_mobile_phone_number!s}, "
            f"electronic_funds_transfer_type={_electronic_funds_transfer_type!s}, "
            f"electronic_funds_transfer_failure_type={_electronic_funds_transfer_failure_type!s}, "
            f"electronic_transfer_status_type={_electronic_transfer_status_type!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
