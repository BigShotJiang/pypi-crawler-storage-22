"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.delivery_details import (
    DeliveryDetails,
)
from payquickersdk.models.fx_rate import FxRate
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)
from payquickersdk.models.receipt_descriptions import (
    ReceiptDescriptions,
)
from payquickersdk.models.receipt_details import (
    ReceiptDetails,
)


class ReceiptObject(object):
    """Implementation of the 'ReceiptObject' model.

    Attributes:
        token (str): Auto-generated unique identifier representing a receipt,
            prefixed with `rcpt-`.
        mtype (TransferTypes): [Transfer type](#/rest/models/structures/transfer-type)
        created_on (datetime): Time object was
            [created](#/rest/models/structures/created-on)
        sign (Signs): Receipt sign types
        source_token (str): Unique identifier representing the [source of
            funds](#/rest/models/structures/source-token)
        destination_token (str): Unique identifier representing the [destination of
            funds](#/rest/models/structures/destination-token)
        amount (float): Allocated money to be sent in the transaction.
        currency (Currencies): [Currency code type](#/rest/models/structures/country)
            for the object
        status (ReceiptStatuses): Receipt status types
        descriptions (List[ReceiptDescriptions]): The model property of type
            List[ReceiptDescriptions].
        delivery_details (DeliveryDetails): The delivery details of a Bank transfer
            with the minimum and maximum delivery in minutes or the expected delivery
            time.
        details (ReceiptDetails): The model property of type ReceiptDetails.
        fx_rate (FxRate): Exchange rate
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "token": "token",
        "mtype": "type",
        "created_on": "createdOn",
        "sign": "sign",
        "source_token": "sourceToken",
        "destination_token": "destinationToken",
        "amount": "amount",
        "currency": "currency",
        "status": "status",
        "descriptions": "descriptions",
        "delivery_details": "deliveryDetails",
        "details": "details",
        "fx_rate": "fxRate",
        "links": "links",
    }

    _optionals = [
        "token",
        "mtype",
        "created_on",
        "sign",
        "source_token",
        "destination_token",
        "amount",
        "currency",
        "status",
        "descriptions",
        "delivery_details",
        "details",
        "fx_rate",
        "links",
    ]

    def __init__(
        self,
        token="rcpt-b7fda294-8d3a-48e8-9a11-ef7be07a732c",
        mtype=APIHelper.SKIP,
        created_on=APIHelper.SKIP,
        sign=APIHelper.SKIP,
        source_token="acct-3908ab5a-6ce1-474d-8b80-a63a7b147860",
        destination_token="dest-631b200f-665d-4dbe-bd01-3063c9dec97d",
        amount=1.02,
        currency="USD",
        status=APIHelper.SKIP,
        descriptions=APIHelper.SKIP,
        delivery_details=APIHelper.SKIP,
        details=APIHelper.SKIP,
        fx_rate=APIHelper.SKIP,
        links=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a ReceiptObject instance."""
        # Initialize members of the class
        self.token = token
        if mtype is not APIHelper.SKIP:
            self.mtype = mtype
        if created_on is not APIHelper.SKIP:
            self.created_on =\
                 APIHelper.apply_datetime_converter(
                created_on, APIHelper.RFC3339DateTime)\
                 if created_on else None
        if sign is not APIHelper.SKIP:
            self.sign = sign
        self.source_token = source_token
        self.destination_token = destination_token
        self.amount = amount
        self.currency = currency
        if status is not APIHelper.SKIP:
            self.status = status
        if descriptions is not APIHelper.SKIP:
            self.descriptions = descriptions
        if delivery_details is not APIHelper.SKIP:
            self.delivery_details = delivery_details
        if details is not APIHelper.SKIP:
            self.details = details
        if fx_rate is not APIHelper.SKIP:
            self.fx_rate = fx_rate
        if links is not APIHelper.SKIP:
            self.links = links

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else "rcpt-b7fda294-8d3a-48e8-9a11-ef7be07a732c"
        mtype =\
            dictionary.get("type")\
            if dictionary.get("type")\
                else APIHelper.SKIP
        created_on = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("createdOn")).datetime\
            if dictionary.get("createdOn") else APIHelper.SKIP
        sign =\
            dictionary.get("sign")\
            if dictionary.get("sign")\
                else APIHelper.SKIP
        source_token =\
            dictionary.get("sourceToken")\
            if dictionary.get("sourceToken")\
                else "acct-3908ab5a-6ce1-474d-8b80-a63a7b147860"
        destination_token =\
            dictionary.get("destinationToken")\
            if dictionary.get("destinationToken")\
                else "dest-631b200f-665d-4dbe-bd01-3063c9dec97d"
        amount =\
            dictionary.get("amount")\
            if dictionary.get("amount")\
                else 1.02
        currency =\
            dictionary.get("currency")\
            if dictionary.get("currency")\
                else "USD"
        status =\
            dictionary.get("status")\
            if dictionary.get("status")\
                else APIHelper.SKIP
        descriptions = None
        if dictionary.get("descriptions") is not None:
            descriptions = [
                ReceiptDescriptions.from_dictionary(x)
                    for x in dictionary.get("descriptions")
            ]
        else:
            descriptions = APIHelper.SKIP
        delivery_details =\
            DeliveryDetails.from_dictionary(
                dictionary.get("deliveryDetails"))\
                if "deliveryDetails" in dictionary.keys()\
                else APIHelper.SKIP
        details =\
            ReceiptDetails.from_dictionary(
                dictionary.get("details"))\
                if "details" in dictionary.keys()\
                else APIHelper.SKIP
        fx_rate =\
            FxRate.from_dictionary(
                dictionary.get("fxRate"))\
                if "fxRate" in dictionary.keys()\
                else APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(token,
                   mtype,
                   created_on,
                   sign,
                   source_token,
                   destination_token,
                   amount,
                   currency,
                   status,
                   descriptions,
                   delivery_details,
                   details,
                   fx_rate,
                   links,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _created_on=(
            self.created_on
            if hasattr(self, "created_on")
            else None
        )
        _sign=(
            self.sign
            if hasattr(self, "sign")
            else None
        )
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _destination_token=(
            self.destination_token
            if hasattr(self, "destination_token")
            else None
        )
        _amount=(
            self.amount
            if hasattr(self, "amount")
            else None
        )
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _descriptions=(
            self.descriptions
            if hasattr(self, "descriptions")
            else None
        )
        _delivery_details=(
            self.delivery_details
            if hasattr(self, "delivery_details")
            else None
        )
        _details=(
            self.details
            if hasattr(self, "details")
            else None
        )
        _fx_rate=(
            self.fx_rate
            if hasattr(self, "fx_rate")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!r}, "
            f"mtype={_mtype!r}, "
            f"created_on={_created_on!r}, "
            f"sign={_sign!r}, "
            f"source_token={_source_token!r}, "
            f"destination_token={_destination_token!r}, "
            f"amount={_amount!r}, "
            f"currency={_currency!r}, "
            f"status={_status!r}, "
            f"descriptions={_descriptions!r}, "
            f"delivery_details={_delivery_details!r}, "
            f"details={_details!r}, "
            f"fx_rate={_fx_rate!r}, "
            f"links={_links!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _created_on=(
            self.created_on
            if hasattr(self, "created_on")
            else None
        )
        _sign=(
            self.sign
            if hasattr(self, "sign")
            else None
        )
        _source_token=(
            self.source_token
            if hasattr(self, "source_token")
            else None
        )
        _destination_token=(
            self.destination_token
            if hasattr(self, "destination_token")
            else None
        )
        _amount=(
            self.amount
            if hasattr(self, "amount")
            else None
        )
        _currency=(
            self.currency
            if hasattr(self, "currency")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _descriptions=(
            self.descriptions
            if hasattr(self, "descriptions")
            else None
        )
        _delivery_details=(
            self.delivery_details
            if hasattr(self, "delivery_details")
            else None
        )
        _details=(
            self.details
            if hasattr(self, "details")
            else None
        )
        _fx_rate=(
            self.fx_rate
            if hasattr(self, "fx_rate")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!s}, "
            f"mtype={_mtype!s}, "
            f"created_on={_created_on!s}, "
            f"sign={_sign!s}, "
            f"source_token={_source_token!s}, "
            f"destination_token={_destination_token!s}, "
            f"amount={_amount!s}, "
            f"currency={_currency!s}, "
            f"status={_status!s}, "
            f"descriptions={_descriptions!s}, "
            f"delivery_details={_delivery_details!s}, "
            f"details={_details!s}, "
            f"fx_rate={_fx_rate!s}, "
            f"links={_links!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
