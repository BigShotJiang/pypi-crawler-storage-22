"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class ReceiptStatuses(object):
    """Implementation of the '__ReceiptStatuses' enum.

    Receipt status types

    Attributes:
        UNDEFINED: The enum member of type str.
        PENDING: The enum member of type str.
        COMPLETE: The enum member of type str.
        FAILED: The enum member of type str.
        CANCELED: The enum member of type str.
        SCHEDULED: The enum member of type str.
        REVIEW_REQUIRED: The enum member of type str.
        EXPIRED: The enum member of type str.
        REFUNDED: The enum member of type str.
        PROCESSING: The enum member of type str.
        REVERSED: The enum member of type str.
        UNSETTLED: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    UNDEFINED = "UNDEFINED"

    PENDING = "PENDING"

    COMPLETE = "COMPLETE"

    FAILED = "FAILED"

    CANCELED = "CANCELED"

    SCHEDULED = "SCHEDULED"

    REVIEW_REQUIRED = "REVIEW_REQUIRED"

    EXPIRED = "EXPIRED"

    REFUNDED = "REFUNDED"

    PROCESSING = "PROCESSING"

    REVERSED = "REVERSED"

    UNSETTLED = "UNSETTLED"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
