"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class ReplacePrepaidCard(object):
    """Implementation of the '_ReplacePrepaidCard' model.

    Attributes:
        card_package (str): [Package](#/rest/models/structures/prepaid-card-package)
            for the card being displayed, including artwork, packaging, and delivery
            method
        card_replacement_reason (PrepaidCardReplacementReasons): Reason for [prepaid
            card](page:resources/prepaid-cards) replacement.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "card_package": "cardPackage",
        "card_replacement_reason": "cardReplacementReason",
    }

    _optionals = [
        "card_package",
        "card_replacement_reason",
    ]

    def __init__(
        self,
        card_package=APIHelper.SKIP,
        card_replacement_reason=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a ReplacePrepaidCard instance."""
        # Initialize members of the class
        if card_package is not APIHelper.SKIP:
            self.card_package = card_package
        if card_replacement_reason is not APIHelper.SKIP:
            self.card_replacement_reason = card_replacement_reason

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        card_package =\
            dictionary.get("cardPackage")\
            if dictionary.get("cardPackage")\
                else APIHelper.SKIP
        card_replacement_reason =\
            dictionary.get("cardReplacementReason")\
            if dictionary.get("cardReplacementReason")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(card_package,
                   card_replacement_reason,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _card_package=(
            self.card_package
            if hasattr(self, "card_package")
            else None
        )
        _card_replacement_reason=(
            self.card_replacement_reason
            if hasattr(self, "card_replacement_reason")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_package={_card_package!r}, "
            f"card_replacement_reason={_card_replacement_reason!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _card_package=(
            self.card_package
            if hasattr(self, "card_package")
            else None
        )
        _card_replacement_reason=(
            self.card_replacement_reason
            if hasattr(self, "card_replacement_reason")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_package={_card_package!s}, "
            f"card_replacement_reason={_card_replacement_reason!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
