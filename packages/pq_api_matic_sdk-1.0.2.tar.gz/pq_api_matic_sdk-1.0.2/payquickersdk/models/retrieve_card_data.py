"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class RetrieveCardData(object):
    """Implementation of the '_RetrieveCardData' model.

    Attributes:
        token (str): A token used to reveal prepaid card information in the form of
            image data (base64) or JSON.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "token": "Token",
    }

    _optionals = [
        "token",
    ]

    def __init__(
        self,
        token=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a RetrieveCardData instance."""
        # Initialize members of the class
        if token is not APIHelper.SKIP:
            self.token = token

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        token =\
            dictionary.get("Token")\
            if dictionary.get("Token")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(token,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
