"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class SandboxInstance(object):
    """Implementation of the 'sandbox_instance' enum.

    Attributes:
        SANDBOX: The enum member of type str.
        SBX1: The enum member of type str.
        SBX2: The enum member of type str.
        SBX3: The enum member of type str.
        SBX4: The enum member of type str.
        SBX5: The enum member of type str.
        SBX6: The enum member of type str.
        SBX7: The enum member of type str.
        SBX8: The enum member of type str.
        SBX9: The enum member of type str.
        SBX10: The enum member of type str.
        SBX11: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    SANDBOX = "sandbox"

    SBX1 = "sbx1"

    SBX2 = "sbx2"

    SBX3 = "sbx3"

    SBX4 = "sbx4"

    SBX5 = "sbx5"

    SBX6 = "sbx6"

    SBX7 = "sbx7"

    SBX8 = "sbx8"

    SBX9 = "sbx9"

    SBX10 = "sbx10"

    SBX11 = "sbx11"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
