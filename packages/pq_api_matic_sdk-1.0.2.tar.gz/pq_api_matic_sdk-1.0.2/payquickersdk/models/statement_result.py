"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)
from payquickersdk.models.metadata_items import (
    MetadataItems,
)


class StatementResult(object):
    """Implementation of the '_StatementResult' model.

    Attributes:
        file_contents (str): The string representation of the file content.
        filename (str): The name given to a computer file in order to distinguish it
            from other files
        mime_type (str): A label used to identify a type of data.  Acts like a file
            extension on the internet.
        token (str): [Token](#/rest/models/structures/token) representing the resource
        user_token (str): Auto-generated unique identifier representing a user,
            prefixed with `user-`.
        prepaid_card_token (str): Auto-generated unique identifier representing a
            dest, prefixed with dest-.
        mfrom (datetime): Beginning date and time of a prepaid card statement
        to (datetime): Ending date and time of a prepaid card statement
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        meta (MetadataItems): The model property of type MetadataItems.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "file_contents": "fileContents",
        "filename": "filename",
        "mime_type": "mimeType",
        "token": "token",
        "user_token": "userToken",
        "prepaid_card_token": "prepaidCardToken",
        "mfrom": "from",
        "to": "to",
        "links": "links",
        "meta": "meta",
    }

    _optionals = [
        "file_contents",
        "filename",
        "mime_type",
        "token",
        "user_token",
        "prepaid_card_token",
        "mfrom",
        "to",
        "links",
        "meta",
    ]

    def __init__(
        self,
        file_contents=APIHelper.SKIP,
        filename=APIHelper.SKIP,
        mime_type=APIHelper.SKIP,
        token=APIHelper.SKIP,
        user_token=APIHelper.SKIP,
        prepaid_card_token=APIHelper.SKIP,
        mfrom=APIHelper.SKIP,
        to=APIHelper.SKIP,
        links=APIHelper.SKIP,
        meta=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a StatementResult instance."""
        # Initialize members of the class
        if file_contents is not APIHelper.SKIP:
            self.file_contents = file_contents
        if filename is not APIHelper.SKIP:
            self.filename = filename
        if mime_type is not APIHelper.SKIP:
            self.mime_type = mime_type
        if token is not APIHelper.SKIP:
            self.token = token
        if user_token is not APIHelper.SKIP:
            self.user_token = user_token
        if prepaid_card_token is not APIHelper.SKIP:
            self.prepaid_card_token = prepaid_card_token
        if mfrom is not APIHelper.SKIP:
            self.mfrom =\
                 APIHelper.apply_datetime_converter(
                mfrom, APIHelper.RFC3339DateTime)\
                 if mfrom else None
        if to is not APIHelper.SKIP:
            self.to =\
                 APIHelper.apply_datetime_converter(
                to, APIHelper.RFC3339DateTime)\
                 if to else None
        if links is not APIHelper.SKIP:
            self.links = links
        if meta is not APIHelper.SKIP:
            self.meta = meta

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        file_contents =\
            dictionary.get("fileContents")\
            if dictionary.get("fileContents")\
                else APIHelper.SKIP
        filename =\
            dictionary.get("filename")\
            if dictionary.get("filename")\
                else APIHelper.SKIP
        mime_type =\
            dictionary.get("mimeType")\
            if dictionary.get("mimeType")\
                else APIHelper.SKIP
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else APIHelper.SKIP
        user_token =\
            dictionary.get("userToken")\
            if dictionary.get("userToken")\
                else APIHelper.SKIP
        prepaid_card_token =\
            dictionary.get("prepaidCardToken")\
            if dictionary.get("prepaidCardToken")\
                else APIHelper.SKIP
        mfrom = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("from")).datetime\
            if dictionary.get("from") else APIHelper.SKIP
        to = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("to")).datetime\
            if dictionary.get("to") else APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP
        meta =\
            MetadataItems.from_dictionary(
                dictionary.get("meta"))\
                if "meta" in dictionary.keys()\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(file_contents,
                   filename,
                   mime_type,
                   token,
                   user_token,
                   prepaid_card_token,
                   mfrom,
                   to,
                   links,
                   meta,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _file_contents=(
            self.file_contents
            if hasattr(self, "file_contents")
            else None
        )
        _filename=(
            self.filename
            if hasattr(self, "filename")
            else None
        )
        _mime_type=(
            self.mime_type
            if hasattr(self, "mime_type")
            else None
        )
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _user_token=(
            self.user_token
            if hasattr(self, "user_token")
            else None
        )
        _prepaid_card_token=(
            self.prepaid_card_token
            if hasattr(self, "prepaid_card_token")
            else None
        )
        _mfrom=(
            self.mfrom
            if hasattr(self, "mfrom")
            else None
        )
        _to=(
            self.to
            if hasattr(self, "to")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"file_contents={_file_contents!r}, "
            f"filename={_filename!r}, "
            f"mime_type={_mime_type!r}, "
            f"token={_token!r}, "
            f"user_token={_user_token!r}, "
            f"prepaid_card_token={_prepaid_card_token!r}, "
            f"mfrom={_mfrom!r}, "
            f"to={_to!r}, "
            f"links={_links!r}, "
            f"meta={_meta!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _file_contents=(
            self.file_contents
            if hasattr(self, "file_contents")
            else None
        )
        _filename=(
            self.filename
            if hasattr(self, "filename")
            else None
        )
        _mime_type=(
            self.mime_type
            if hasattr(self, "mime_type")
            else None
        )
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _user_token=(
            self.user_token
            if hasattr(self, "user_token")
            else None
        )
        _prepaid_card_token=(
            self.prepaid_card_token
            if hasattr(self, "prepaid_card_token")
            else None
        )
        _mfrom=(
            self.mfrom
            if hasattr(self, "mfrom")
            else None
        )
        _to=(
            self.to
            if hasattr(self, "to")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"file_contents={_file_contents!s}, "
            f"filename={_filename!s}, "
            f"mime_type={_mime_type!s}, "
            f"token={_token!s}, "
            f"user_token={_user_token!s}, "
            f"prepaid_card_token={_prepaid_card_token!s}, "
            f"mfrom={_mfrom!s}, "
            f"to={_to!s}, "
            f"links={_links!s}, "
            f"meta={_meta!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
