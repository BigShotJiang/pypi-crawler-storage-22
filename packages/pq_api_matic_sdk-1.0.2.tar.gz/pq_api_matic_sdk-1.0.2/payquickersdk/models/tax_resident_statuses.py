"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class TaxResidentStatuses(object):
    """Implementation of the '__TaxResidentStatuses' enum.

    Tax [resident status type](#/rest/models/structures/tax-resident-status)

    Attributes:
        NO: The enum member of type str.
        YES: The enum member of type str.
        UNDEFINED: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    NO = "NO"

    YES = "YES"

    UNDEFINED = "UNDEFINED"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
