"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class TransferMethodTypes(object):
    """Implementation of the '__TransferMethodTypes' enum.

    Optional transfer methods applicable only to bank and e-wallet transfers.

    Attributes:
        IACH: The enum member of type str.
        WIRE: The enum member of type str.
        US_SAMEDAY_IACH: The enum member of type str.
        STANDARD_EWALLET: The enum member of type str.
        STANDARD_POST: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    _all_values = ["IACH", "WIRE", "US_SAMEDAY_IACH", "STANDARD_EWALLET",
        "STANDARD_POST"]
    IACH = "IACH"

    WIRE = "WIRE"

    US_SAMEDAY_IACH = "US_SAMEDAY_IACH"

    STANDARD_EWALLET = "STANDARD_EWALLET"

    STANDARD_POST = "STANDARD_POST"

    @classmethod
    def validate(cls, value):
        """Validate value contains in enum

        Args:
            value: the value to be validated

        Returns:
            boolean : if value is valid enum values.

        """
        return value in cls._all_values

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
