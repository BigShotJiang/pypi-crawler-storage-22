"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class TransferStatuses(object):
    """Implementation of the '__TransferStatuses' enum.

    Current status of a [transfer](#/rest/models/structures/transfer)

    Attributes:
        ACCEPTED: The enum member of type str.
        CANCELLED: The enum member of type str.
        COMPLETED: The enum member of type str.
        EXPIRED: The enum member of type str.
        FAILED: The enum member of type str.
        PENDING: The enum member of type str.
        PENDING_ACCEPTANCE: The enum member of type str.
        QUOTED: The enum member of type str.
        RETURNED: The enum member of type str.
        SCHEDULED: The enum member of type str.
        VERIFICATION_HOLD: The enum member of type str.
        VOIDED: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    ACCEPTED = "ACCEPTED"

    CANCELLED = "CANCELLED"

    COMPLETED = "COMPLETED"

    EXPIRED = "EXPIRED"

    FAILED = "FAILED"

    PENDING = "PENDING"

    PENDING_ACCEPTANCE = "PENDING_ACCEPTANCE"

    QUOTED = "QUOTED"

    RETURNED = "RETURNED"

    SCHEDULED = "SCHEDULED"

    VERIFICATION_HOLD = "VERIFICATION_HOLD"

    VOIDED = "VOIDED"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
