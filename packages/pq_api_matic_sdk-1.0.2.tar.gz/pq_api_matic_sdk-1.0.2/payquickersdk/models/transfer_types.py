"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class TransferTypes(object):
    """Implementation of the '__TransferTypes' enum.

    [Transfer type](#/rest/models/structures/transfer-type)

    Attributes:
        ACCOUNT_TO_ACCOUNT_TRANSFER: The enum member of type str.
        BANK_TRANSFER: The enum member of type str.
        BANK_TRANSFER_RETURN: The enum member of type str.
        BANK_TRANSFER_REVERSAL: The enum member of type str.
        CANCELLED_PAYMENT: The enum member of type str.
        CARD_PURCHASE: The enum member of type str.
        CARD_PURCHASE_REFUND: The enum member of type str.
        CASH_WITHDRAWAL: The enum member of type str.
        DEPOSIT: The enum member of type str.
        ESCHEATED_FUNDS_RETURN: The enum member of type str.
        FEE: The enum member of type str.
        FEE_REFUND: The enum member of type str.
        PAPER_CHECK: The enum member of type str.
        PAYMENT: The enum member of type str.
        PAYMENT_RETRACTION: The enum member of type str.
        PREPAID_CARD_LOAD: The enum member of type str.
        PREPAID_CARD_UNLOAD: The enum member of type str.
        PROVISIONAL_REFUND: The enum member of type str.
        SPENDBACK: The enum member of type str.
        SPENDBACK_RETURN: The enum member of type str.
        ELECTRONIC_WALLET_TRANSFER: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    ACCOUNT_TO_ACCOUNT_TRANSFER = "ACCOUNT_TO_ACCOUNT_TRANSFER"

    BANK_TRANSFER = "BANK_TRANSFER"

    BANK_TRANSFER_RETURN = "BANK_TRANSFER_RETURN"

    BANK_TRANSFER_REVERSAL = "BANK_TRANSFER_REVERSAL"

    CANCELLED_PAYMENT = "CANCELLED_PAYMENT"

    CARD_PURCHASE = "CARD_PURCHASE"

    CARD_PURCHASE_REFUND = "CARD_PURCHASE_REFUND"

    CASH_WITHDRAWAL = "CASH_WITHDRAWAL"

    DEPOSIT = "DEPOSIT"

    ESCHEATED_FUNDS_RETURN = "ESCHEATED_FUNDS_RETURN"

    FEE = "FEE"

    FEE_REFUND = "FEE_REFUND"

    PAPER_CHECK = "PAPER_CHECK"

    PAYMENT = "PAYMENT"

    PAYMENT_RETRACTION = "PAYMENT_RETRACTION"

    PREPAID_CARD_LOAD = "PREPAID_CARD_LOAD"

    PREPAID_CARD_UNLOAD = "PREPAID_CARD_UNLOAD"

    PROVISIONAL_REFUND = "PROVISIONAL_REFUND"

    SPENDBACK = "SPENDBACK"

    SPENDBACK_RETURN = "SPENDBACK_RETURN"

    ELECTRONIC_WALLET_TRANSFER = "ELECTRONIC_WALLET_TRANSFER"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
