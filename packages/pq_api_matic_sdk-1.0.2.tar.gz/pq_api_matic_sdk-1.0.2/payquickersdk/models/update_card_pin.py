"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class UpdateCardPin(object):
    """Implementation of the '_UpdateCardPin' model.

    Attributes:
        card_pin_token (str):
            [Token](#/rest/models/structures/prepaid-card-pin-token) used as part of
            a two-leg card PIN reveal request sent directly from the client that
            generally involves a second piece of data, such as the CVV code on the
            back of the card.
        card_pin (str): [Card PIN](#/rest/models/structures/prepaid-card-pin) for ATM
            and Debit usage
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "card_pin_token": "cardPinToken",
        "card_pin": "cardPin",
    }

    _optionals = [
        "card_pin_token",
        "card_pin",
    ]

    def __init__(
        self,
        card_pin_token=APIHelper.SKIP,
        card_pin=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a UpdateCardPin instance."""
        # Initialize members of the class
        if card_pin_token is not APIHelper.SKIP:
            self.card_pin_token = card_pin_token
        if card_pin is not APIHelper.SKIP:
            self.card_pin = card_pin

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        card_pin_token =\
            dictionary.get("cardPinToken")\
            if dictionary.get("cardPinToken")\
                else APIHelper.SKIP
        card_pin =\
            dictionary.get("cardPin")\
            if dictionary.get("cardPin")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(card_pin_token,
                   card_pin,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _card_pin_token=(
            self.card_pin_token
            if hasattr(self, "card_pin_token")
            else None
        )
        _card_pin=(
            self.card_pin
            if hasattr(self, "card_pin")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_pin_token={_card_pin_token!r}, "
            f"card_pin={_card_pin!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _card_pin_token=(
            self.card_pin_token
            if hasattr(self, "card_pin_token")
            else None
        )
        _card_pin=(
            self.card_pin
            if hasattr(self, "card_pin")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_pin_token={_card_pin_token!s}, "
            f"card_pin={_card_pin!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
