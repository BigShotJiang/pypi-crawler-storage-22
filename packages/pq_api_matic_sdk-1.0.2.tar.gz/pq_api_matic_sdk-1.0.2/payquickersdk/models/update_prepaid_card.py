"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class UpdatePrepaidCard(object):
    """Implementation of the '_UpdatePrepaidCard' model.

    Attributes:
        card_package (str): [Package](#/rest/models/structures/prepaid-card-package)
            for the card being displayed, including artwork, packaging, and delivery
            method
        status (PrepaidCardStatuses): Current
            [status](#/rest/models/structures/prepaid-card-status) of the prepaid card
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "card_package": "cardPackage",
        "status": "status",
    }

    _optionals = [
        "card_package",
        "status",
    ]

    def __init__(
        self,
        card_package=APIHelper.SKIP,
        status=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a UpdatePrepaidCard instance."""
        # Initialize members of the class
        if card_package is not APIHelper.SKIP:
            self.card_package = card_package
        if status is not APIHelper.SKIP:
            self.status = status

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        card_package =\
            dictionary.get("cardPackage")\
            if dictionary.get("cardPackage")\
                else APIHelper.SKIP
        status =\
            dictionary.get("status")\
            if dictionary.get("status")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(card_package,
                   status,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _card_package=(
            self.card_package
            if hasattr(self, "card_package")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_package={_card_package!r}, "
            f"status={_status!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _card_package=(
            self.card_package
            if hasattr(self, "card_package")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"card_package={_card_package!s}, "
            f"status={_status!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
