"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.user_doc_req_item_docs_items_metadata_items_name_items import (  # noqa: E501
    UserDocReqItemDocsItemsMetadataItemsNameItems,
)


class UserDocReqItemDocsItemsMetadataItems(object):
    """Implementation of the 'UserDocReqItemDocsItemsMetadataItems' model.

    Attributes:
        data_type (str): The model property of type str.
        field_type (str): The model property of type str.
        name (List[UserDocReqItemDocsItemsMetadataItemsNameItems]): The model
            property of type List[UserDocReqItemDocsItemsMetadataItemsNameItems].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "data_type": "dataType",
        "field_type": "fieldType",
        "name": "name",
    }

    _optionals = [
        "data_type",
        "field_type",
        "name",
    ]

    def __init__(
        self,
        data_type=APIHelper.SKIP,
        field_type=APIHelper.SKIP,
        name=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a UserDocReqItemDocsItemsMetadataItems instance."""
        # Initialize members of the class
        if data_type is not APIHelper.SKIP:
            self.data_type = data_type
        if field_type is not APIHelper.SKIP:
            self.field_type = field_type
        if name is not APIHelper.SKIP:
            self.name = name

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        data_type =\
            dictionary.get("dataType")\
            if dictionary.get("dataType")\
                else APIHelper.SKIP
        field_type =\
            dictionary.get("fieldType")\
            if dictionary.get("fieldType")\
                else APIHelper.SKIP
        name = None
        if dictionary.get("name") is not None:
            name = [
                UserDocReqItemDocsItemsMetadataItemsNameItems.from_dictionary(x)
                    for x in dictionary.get("name")
            ]
        else:
            name = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(data_type,
                   field_type,
                   name,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _data_type=(
            self.data_type
            if hasattr(self, "data_type")
            else None
        )
        _field_type=(
            self.field_type
            if hasattr(self, "field_type")
            else None
        )
        _name=(
            self.name
            if hasattr(self, "name")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"data_type={_data_type!r}, "
            f"field_type={_field_type!r}, "
            f"name={_name!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _data_type=(
            self.data_type
            if hasattr(self, "data_type")
            else None
        )
        _field_type=(
            self.field_type
            if hasattr(self, "field_type")
            else None
        )
        _name=(
            self.name
            if hasattr(self, "name")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"data_type={_data_type!s}, "
            f"field_type={_field_type!s}, "
            f"name={_name!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
