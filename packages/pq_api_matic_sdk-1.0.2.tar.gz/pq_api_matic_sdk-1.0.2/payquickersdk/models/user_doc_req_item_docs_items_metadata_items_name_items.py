"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class UserDocReqItemDocsItemsMetadataItemsNameItems(object):
    """Implementation of the 'UserDocReqItemDocsItemsMetadataItemsNameItems' model.

    Attributes:
        language (str): The model property of type str.
        translation (str): The model property of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "language": "language",
        "translation": "translation",
    }

    _optionals = [
        "language",
        "translation",
    ]

    def __init__(
        self,
        language=APIHelper.SKIP,
        translation=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a UserDocReqItemDocsItemsMetadataItemsNameItems instance."""
        # Initialize members of the class
        if language is not APIHelper.SKIP:
            self.language = language
        if translation is not APIHelper.SKIP:
            self.translation = translation

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        language =\
            dictionary.get("language")\
            if dictionary.get("language")\
                else APIHelper.SKIP
        translation =\
            dictionary.get("translation")\
            if dictionary.get("translation")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(language,
                   translation,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _language=(
            self.language
            if hasattr(self, "language")
            else None
        )
        _translation=(
            self.translation
            if hasattr(self, "translation")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"language={_language!r}, "
            f"translation={_translation!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _language=(
            self.language
            if hasattr(self, "language")
            else None
        )
        _translation=(
            self.translation
            if hasattr(self, "translation")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"language={_language!s}, "
            f"translation={_translation!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
