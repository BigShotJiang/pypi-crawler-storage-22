"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper


class UserDocReqItemDocsItemsSupplementalDocsItems(object):
    """Implementation of the 'UserDocReqItemDocsItemsSupplementalDocsItems' model.

    Attributes:
        example_image (str): Full path of the URI used for this object
        status (DocumentStatusTypes): Status Type of a document
        mtype (DocumentTypes): Indicates the enums for KYC.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "example_image": "exampleImage",
        "status": "status",
        "mtype": "type",
    }

    _optionals = [
        "example_image",
        "status",
        "mtype",
    ]

    def __init__(
        self,
        example_image=APIHelper.SKIP,
        status=APIHelper.SKIP,
        mtype=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a UserDocReqItemDocsItemsSupplementalDocsItems instance."""
        # Initialize members of the class
        if example_image is not APIHelper.SKIP:
            self.example_image = example_image
        if status is not APIHelper.SKIP:
            self.status = status
        if mtype is not APIHelper.SKIP:
            self.mtype = mtype

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        example_image =\
            dictionary.get("exampleImage")\
            if dictionary.get("exampleImage")\
                else APIHelper.SKIP
        status =\
            dictionary.get("status")\
            if dictionary.get("status")\
                else APIHelper.SKIP
        mtype =\
            dictionary.get("type")\
            if dictionary.get("type")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(example_image,
                   status,
                   mtype,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _example_image=(
            self.example_image
            if hasattr(self, "example_image")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"example_image={_example_image!r}, "
            f"status={_status!r}, "
            f"mtype={_mtype!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _example_image=(
            self.example_image
            if hasattr(self, "example_image")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"example_image={_example_image!s}, "
            f"status={_status!s}, "
            f"mtype={_mtype!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
