"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.user_document_requirement_item_documents_items import (
    UserDocumentRequirementItemDocumentsItems,
)


class UserDocumentRequirementItem(object):
    """Implementation of the 'UserDocumentRequirementItem' model.

    Attributes:
        country_of_birth (str): The model property of type str.
        country_of_nationality (str): The model property of type str.
        documents (List[UserDocumentRequirementItemDocumentsItems]): The model
            property of type List[UserDocumentRequirementItemDocumentsItems].
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "country_of_birth": "countryOfBirth",
        "country_of_nationality": "countryOfNationality",
        "documents": "documents",
    }

    _optionals = [
        "country_of_birth",
        "country_of_nationality",
        "documents",
    ]

    def __init__(
        self,
        country_of_birth=APIHelper.SKIP,
        country_of_nationality=APIHelper.SKIP,
        documents=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a UserDocumentRequirementItem instance."""
        # Initialize members of the class
        if country_of_birth is not APIHelper.SKIP:
            self.country_of_birth = country_of_birth
        if country_of_nationality is not APIHelper.SKIP:
            self.country_of_nationality = country_of_nationality
        if documents is not APIHelper.SKIP:
            self.documents = documents

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        country_of_birth =\
            dictionary.get("countryOfBirth")\
            if dictionary.get("countryOfBirth")\
                else APIHelper.SKIP
        country_of_nationality =\
            dictionary.get("countryOfNationality")\
            if dictionary.get("countryOfNationality")\
                else APIHelper.SKIP
        documents = None
        if dictionary.get("documents") is not None:
            documents = [
                UserDocumentRequirementItemDocumentsItems.from_dictionary(x)
                    for x in dictionary.get("documents")
            ]
        else:
            documents = APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(country_of_birth,
                   country_of_nationality,
                   documents,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _country_of_birth=(
            self.country_of_birth
            if hasattr(self, "country_of_birth")
            else None
        )
        _country_of_nationality=(
            self.country_of_nationality
            if hasattr(self, "country_of_nationality")
            else None
        )
        _documents=(
            self.documents
            if hasattr(self, "documents")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"country_of_birth={_country_of_birth!r}, "
            f"country_of_nationality={_country_of_nationality!r}, "
            f"documents={_documents!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _country_of_birth=(
            self.country_of_birth
            if hasattr(self, "country_of_birth")
            else None
        )
        _country_of_nationality=(
            self.country_of_nationality
            if hasattr(self, "country_of_nationality")
            else None
        )
        _documents=(
            self.documents
            if hasattr(self, "documents")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"country_of_birth={_country_of_birth!s}, "
            f"country_of_nationality={_country_of_nationality!s}, "
            f"documents={_documents!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
