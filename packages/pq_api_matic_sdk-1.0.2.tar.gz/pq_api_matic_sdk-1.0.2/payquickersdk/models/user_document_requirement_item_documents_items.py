"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.user_doc_req_item_docs_items_metadata_items import (
    UserDocReqItemDocsItemsMetadataItems,
)
from payquickersdk.models.user_doc_req_item_docs_items_supplemental_docs_items import (
    UserDocReqItemDocsItemsSupplementalDocsItems,
)


class UserDocumentRequirementItemDocumentsItems(object):
    """Implementation of the 'UserDocumentRequirementItemDocumentsItems' model.

    Attributes:
        example_image (str): Full path of the URI used for this object
        supplemental_documents (List[UserDocReqItemDocsItemsSupplementalDocsItems]):
            The model property of type
            List[UserDocReqItemDocsItemsSupplementalDocsItems].
        metadata (List[UserDocReqItemDocsItemsMetadataItems]): The model property of
            type List[UserDocReqItemDocsItemsMetadataItems].
        status (DocumentStatusTypes): Status Type of a document
        mtype (DocumentTypes): Indicates the enums for KYC.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "example_image": "exampleImage",
        "supplemental_documents": "supplementalDocuments",
        "metadata": "metadata",
        "status": "status",
        "mtype": "type",
    }

    _optionals = [
        "example_image",
        "supplemental_documents",
        "metadata",
        "status",
        "mtype",
    ]

    def __init__(
        self,
        example_image=APIHelper.SKIP,
        supplemental_documents=APIHelper.SKIP,
        metadata=APIHelper.SKIP,
        status=APIHelper.SKIP,
        mtype=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a UserDocumentRequirementItemDocumentsItems instance."""
        # Initialize members of the class
        if example_image is not APIHelper.SKIP:
            self.example_image = example_image
        if supplemental_documents is not APIHelper.SKIP:
            self.supplemental_documents = supplemental_documents
        if metadata is not APIHelper.SKIP:
            self.metadata = metadata
        if status is not APIHelper.SKIP:
            self.status = status
        if mtype is not APIHelper.SKIP:
            self.mtype = mtype

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        example_image =\
            dictionary.get("exampleImage")\
            if dictionary.get("exampleImage")\
                else APIHelper.SKIP
        supplemental_documents = None
        if dictionary.get("supplementalDocuments") is not None:
            supplemental_documents = [
                UserDocReqItemDocsItemsSupplementalDocsItems.from_dictionary(x)
                    for x in dictionary.get("supplementalDocuments")
            ]
        else:
            supplemental_documents = APIHelper.SKIP
        metadata = None
        if dictionary.get("metadata") is not None:
            metadata = [
                UserDocReqItemDocsItemsMetadataItems.from_dictionary(x)
                    for x in dictionary.get("metadata")
            ]
        else:
            metadata = APIHelper.SKIP
        status =\
            dictionary.get("status")\
            if dictionary.get("status")\
                else APIHelper.SKIP
        mtype =\
            dictionary.get("type")\
            if dictionary.get("type")\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(example_image,
                   supplemental_documents,
                   metadata,
                   status,
                   mtype,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _example_image=(
            self.example_image
            if hasattr(self, "example_image")
            else None
        )
        _supplemental_documents=(
            self.supplemental_documents
            if hasattr(self, "supplemental_documents")
            else None
        )
        _metadata=(
            self.metadata
            if hasattr(self, "metadata")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"example_image={_example_image!r}, "
            f"supplemental_documents={_supplemental_documents!r}, "
            f"metadata={_metadata!r}, "
            f"status={_status!r}, "
            f"mtype={_mtype!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _example_image=(
            self.example_image
            if hasattr(self, "example_image")
            else None
        )
        _supplemental_documents=(
            self.supplemental_documents
            if hasattr(self, "supplemental_documents")
            else None
        )
        _metadata=(
            self.metadata
            if hasattr(self, "metadata")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _mtype=(
            self.mtype
            if hasattr(self, "mtype")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"example_image={_example_image!s}, "
            f"supplemental_documents={_supplemental_documents!s}, "
            f"metadata={_metadata!s}, "
            f"status={_status!s}, "
            f"mtype={_mtype!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
