"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501

class UserImpact(object):
    """Implementation of the '_UserImpact' enum.

    Attributes:
        NO_IMPACT: The enum member of type str.
        USER_RESTRICTIONS: The enum member of type str.
        USER_SUSPENDED: The enum member of type str.
        USER_PENDING_REGISTRATION: The enum member of type str.
        USER_CLOSED: The enum member of type str.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    NO_IMPACT = "NO_IMPACT"

    USER_RESTRICTIONS = "USER_RESTRICTIONS"

    USER_SUSPENDED = "USER_SUSPENDED"

    USER_PENDING_REGISTRATION = "USER_PENDING_REGISTRATION"

    USER_CLOSED = "USER_CLOSED"

    @classmethod
    def from_value(cls, value, default=None):
        """Return the matching enum value for the given input."""
        if value is None:
            return default

        # If numeric and matches directly
        if isinstance(value, int):
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and val == value:
                    return val

        # If string, perform case-insensitive match
        if isinstance(value, str):
            value_lower = value.lower()
            for name, val in cls.__dict__.items():
                if not name.startswith("_") and (
                    name.lower() == value_lower or str(val).lower() == value_lower
                ):
                    return val

        # Fallback to default
        return default
