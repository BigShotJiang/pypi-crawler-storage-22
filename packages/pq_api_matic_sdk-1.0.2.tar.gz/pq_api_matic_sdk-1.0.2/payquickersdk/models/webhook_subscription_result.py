"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from payquickersdk.api_helper import APIHelper
from payquickersdk.models.hateoas_self_ref import (
    HateoasSelfRef,
)
from payquickersdk.models.metadata_items import (
    MetadataItems,
)


class WebhookSubscriptionResult(object):
    """Implementation of the '_WebhookSubscriptionResult' model.

    Attributes:
        token (str): [Token](#/rest/models/structures/token) representing the resource
        created (datetime): Time object was
            [created](#/rest/models/structures/created-on)
        last_updated (datetime): Date and time that the object was last updated
        url (str): Full path of the URI used for this object
        namespace (WebhookNamespaces): Namespace used to identify and refer to the
            object
        status (WebhookSubscriptionStatuses): The model property of type
            WebhookSubscriptionStatuses.
        links (List[HateoasSelfRef]): The model property of type List[HateoasSelfRef].
        meta (MetadataItems): The model property of type MetadataItems.
        additional_properties (Dict[str, object]): The additional properties for the
            model.

    """

    # Create a mapping from Model property names to API property names
    _names = {
        "token": "token",
        "created": "created",
        "last_updated": "lastUpdated",
        "url": "url",
        "namespace": "namespace",
        "status": "status",
        "links": "links",
        "meta": "meta",
    }

    _optionals = [
        "token",
        "created",
        "last_updated",
        "url",
        "namespace",
        "status",
        "links",
        "meta",
    ]

    def __init__(
        self,
        token=APIHelper.SKIP,
        created=APIHelper.SKIP,
        last_updated=APIHelper.SKIP,
        url=APIHelper.SKIP,
        namespace=APIHelper.SKIP,
        status=APIHelper.SKIP,
        links=APIHelper.SKIP,
        meta=APIHelper.SKIP,
        additional_properties=None):
        """Initialize a WebhookSubscriptionResult instance."""
        # Initialize members of the class
        if token is not APIHelper.SKIP:
            self.token = token
        if created is not APIHelper.SKIP:
            self.created =\
                 APIHelper.apply_datetime_converter(
                created, APIHelper.RFC3339DateTime)\
                 if created else None
        if last_updated is not APIHelper.SKIP:
            self.last_updated =\
                 APIHelper.apply_datetime_converter(
                last_updated, APIHelper.RFC3339DateTime)\
                 if last_updated else None
        if url is not APIHelper.SKIP:
            self.url = url
        if namespace is not APIHelper.SKIP:
            self.namespace = namespace
        if status is not APIHelper.SKIP:
            self.status = status
        if links is not APIHelper.SKIP:
            self.links = links
        if meta is not APIHelper.SKIP:
            self.meta = meta

        # Add additional model properties to the instance
        if additional_properties is None:
            additional_properties = {}
        self.additional_properties = additional_properties

    @classmethod
    def from_dictionary(cls,
                        dictionary):
        """Create an instance of this model from a dictionary

        Args:
            dictionary (dictionary): A dictionary representation of the object
            as obtained from the deserialization of the server's response. The
            keys MUST match property names in the API description.

        Returns:
            object: An instance of this structure class.

        """
        if not isinstance(dictionary, dict) or dictionary is None:
            return None

        # Extract variables from the dictionary
        token =\
            dictionary.get("token")\
            if dictionary.get("token")\
                else APIHelper.SKIP
        created = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("created")).datetime\
            if dictionary.get("created") else APIHelper.SKIP
        last_updated = APIHelper.RFC3339DateTime.from_value(
            dictionary.get("lastUpdated")).datetime\
            if dictionary.get("lastUpdated") else APIHelper.SKIP
        url =\
            dictionary.get("url")\
            if dictionary.get("url")\
                else APIHelper.SKIP
        namespace =\
            dictionary.get("namespace")\
            if dictionary.get("namespace")\
                else APIHelper.SKIP
        status =\
            dictionary.get("status")\
            if dictionary.get("status")\
                else APIHelper.SKIP
        links = None
        if dictionary.get("links") is not None:
            links = [
                HateoasSelfRef.from_dictionary(x)
                    for x in dictionary.get("links")
            ]
        else:
            links = APIHelper.SKIP
        meta =\
            MetadataItems.from_dictionary(
                dictionary.get("meta"))\
                if "meta" in dictionary.keys()\
                else APIHelper.SKIP

        # Clean out expected properties from dictionary
        additional_properties =\
            {k: v for k, v in dictionary.items() if k not in cls._names.values()}

        # Return an object of this model
        return cls(token,
                   created,
                   last_updated,
                   url,
                   namespace,
                   status,
                   links,
                   meta,
                   additional_properties)

    def __repr__(self):
        """Return a unambiguous string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _created=(
            self.created
            if hasattr(self, "created")
            else None
        )
        _last_updated=(
            self.last_updated
            if hasattr(self, "last_updated")
            else None
        )
        _url=(
            self.url
            if hasattr(self, "url")
            else None
        )
        _namespace=(
            self.namespace
            if hasattr(self, "namespace")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!r}, "
            f"created={_created!r}, "
            f"last_updated={_last_updated!r}, "
            f"url={_url!r}, "
            f"namespace={_namespace!r}, "
            f"status={_status!r}, "
            f"links={_links!r}, "
            f"meta={_meta!r}, "
            f"additional_properties={_additional_properties!r}, "
            f")"
        )

    def __str__(self):
        """Return a human-readable string representation."""
        _token=(
            self.token
            if hasattr(self, "token")
            else None
        )
        _created=(
            self.created
            if hasattr(self, "created")
            else None
        )
        _last_updated=(
            self.last_updated
            if hasattr(self, "last_updated")
            else None
        )
        _url=(
            self.url
            if hasattr(self, "url")
            else None
        )
        _namespace=(
            self.namespace
            if hasattr(self, "namespace")
            else None
        )
        _status=(
            self.status
            if hasattr(self, "status")
            else None
        )
        _links=(
            self.links
            if hasattr(self, "links")
            else None
        )
        _meta=(
            self.meta
            if hasattr(self, "meta")
            else None
        )
        _additional_properties=self.additional_properties
        return (
            f"{self.__class__.__name__}("
            f"token={_token!s}, "
            f"created={_created!s}, "
            f"last_updated={_last_updated!s}, "
            f"url={_url!s}, "
            f"namespace={_namespace!s}, "
            f"status={_status!s}, "
            f"links={_links!s}, "
            f"meta={_meta!s}, "
            f"additional_properties={_additional_properties!s}, "
            f")"
        )
