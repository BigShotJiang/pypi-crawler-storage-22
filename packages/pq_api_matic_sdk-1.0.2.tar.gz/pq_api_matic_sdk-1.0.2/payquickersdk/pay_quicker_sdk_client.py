"""pay_quicker_sdk.

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from apimatic_core.configurations.global_configuration import (
    GlobalConfiguration,
)
from apimatic_core.decorators.lazy_property import (
    LazyProperty,
)

from payquickersdk.configuration import (
    Configuration,
    Environment,
)
from payquickersdk.controllers.agreements_controller import (
    AgreementsController,
)
from payquickersdk.controllers.balances_controller import (
    BalancesController,
)
from payquickersdk.controllers.bank_accounts_controller import (
    BankAccountsController,
)
from payquickersdk.controllers.base_controller import (
    BaseController,
)
from payquickersdk.controllers.client_side_controller import (
    ClientSideController,
)
from payquickersdk.controllers.compliance_controller import (
    ComplianceController,
)
from payquickersdk.controllers.documents_controller import (
    DocumentsController,
)
from payquickersdk.controllers.electronic_wallets_controller import (
    ElectronicWalletsController,
)
from payquickersdk.controllers.events_controller import (
    EventsController,
)
from payquickersdk.controllers.invitations_controller import (
    InvitationsController,
)
from payquickersdk.controllers.jobs_controller import (
    JobsController,
)
from payquickersdk.controllers.o_auth_authorization_controller import (
    OAuthAuthorizationController,
)
from payquickersdk.controllers.payments_controller import (
    PaymentsController,
)
from payquickersdk.controllers.prepaid_cards_controller import (
    PrepaidCardsController,
)
from payquickersdk.controllers.program_controller import (
    ProgramController,
)
from payquickersdk.controllers.receipts_controller import (
    ReceiptsController,
)
from payquickersdk.controllers.spendback_controller import (
    SpendbackController,
)
from payquickersdk.controllers.spendback_refunds_controller import (
    SpendbackRefundsController,
)
from payquickersdk.controllers.statements_controller import (
    StatementsController,
)
from payquickersdk.controllers.transfers_controller import (
    TransfersController,
)
from payquickersdk.controllers.users_controller import (
    UsersController,
)
from payquickersdk.controllers.webhooks_controller import (
    WebhooksController,
)
from payquickersdk.http.auth.clientside import (
    Clientside,
)
from payquickersdk.http.auth.server import Server


class PayQuickerSdkClient(object):
    """Client that provide access to the PayQuickerSdkClient APIs."""

    @LazyProperty
    def agreements(self):
        """Provide access to the AgreementsController endpoints."""
        return AgreementsController(self.global_configuration)

    @LazyProperty
    def balances(self):
        """Provide access to the BalancesController endpoints."""
        return BalancesController(self.global_configuration)

    @LazyProperty
    def bank_accounts(self):
        """Provide access to the BankAccountsController endpoints."""
        return BankAccountsController(self.global_configuration)

    @LazyProperty
    def client_side(self):
        """Provide access to the ClientSideController endpoints."""
        return ClientSideController(self.global_configuration)

    @LazyProperty
    def compliance(self):
        """Provide access to the ComplianceController endpoints."""
        return ComplianceController(self.global_configuration)

    @LazyProperty
    def documents(self):
        """Provide access to the DocumentsController endpoints."""
        return DocumentsController(self.global_configuration)

    @LazyProperty
    def electronic_wallets(self):
        """Provide access to the ElectronicWalletsController endpoints."""
        return ElectronicWalletsController(self.global_configuration)

    @LazyProperty
    def events(self):
        """Provide access to the EventsController endpoints."""
        return EventsController(self.global_configuration)

    @LazyProperty
    def payments(self):
        """Provide access to the PaymentsController endpoints."""
        return PaymentsController(self.global_configuration)

    @LazyProperty
    def prepaid_cards(self):
        """Provide access to the PrepaidCardsController endpoints."""
        return PrepaidCardsController(self.global_configuration)

    @LazyProperty
    def program(self):
        """Provide access to the ProgramController endpoints."""
        return ProgramController(self.global_configuration)

    @LazyProperty
    def receipts(self):
        """Provide access to the ReceiptsController endpoints."""
        return ReceiptsController(self.global_configuration)

    @LazyProperty
    def spendback(self):
        """Provide access to the SpendbackController endpoints."""
        return SpendbackController(self.global_configuration)

    @LazyProperty
    def spendback_refunds(self):
        """Provide access to the SpendbackRefundsController endpoints."""
        return SpendbackRefundsController(self.global_configuration)

    @LazyProperty
    def statements(self):
        """Provide access to the StatementsController endpoints."""
        return StatementsController(self.global_configuration)

    @LazyProperty
    def transfers(self):
        """Provide access to the TransfersController endpoints."""
        return TransfersController(self.global_configuration)

    @LazyProperty
    def users(self):
        """Provide access to the UsersController endpoints."""
        return UsersController(self.global_configuration)

    @LazyProperty
    def webhooks(self):
        """Provide access to the WebhooksController endpoints."""
        return WebhooksController(self.global_configuration)

    @LazyProperty
    def jobs(self):
        """Provide access to the JobsController endpoints."""
        return JobsController(self.global_configuration)

    @LazyProperty
    def invitations(self):
        """Provide access to the InvitationsController endpoints."""
        return InvitationsController(self.global_configuration)

    @LazyProperty
    def o_auth_authorization(self):
        """Provide access to the OAuthAuthorizationController endpoints."""
        return OAuthAuthorizationController(self.global_configuration)

    @property
    def server(self):
        """Provide access to the Server auth manager."""
        return self.auth_managers["server"]

    def __init__(self, http_client_instance=None,
                 override_http_client_configuration=False, http_call_back=None,
                 timeout=60, max_retries=0, backoff_factor=2,
                 retry_statuses=None, retry_methods=None, proxy_settings=None,
                 logging_configuration=None, environment=Environment.SANDBOX,
                 sandbox_instance="sandbox", uat_instance="uat1",
                 server_credentials=None, clientside_credentials=None,
                 x_my_pay_quicker_version="2026.02.01", config=None):
        """Initialize a new instance of PayQuickerSdkClient."""
        self.config = config or Configuration(
            http_client_instance=http_client_instance,
            override_http_client_configuration=override_http_client_configuration,
            http_call_back=http_call_back, timeout=timeout,
            max_retries=max_retries, backoff_factor=backoff_factor,
            retry_statuses=retry_statuses, retry_methods=retry_methods,
            proxy_settings=proxy_settings,
            logging_configuration=logging_configuration,
            environment=environment, sandbox_instance=sandbox_instance,
            uat_instance=uat_instance, server_credentials=server_credentials,
            clientside_credentials=clientside_credentials,
            x_my_pay_quicker_version=x_my_pay_quicker_version)

        self.global_configuration = GlobalConfiguration(self.config)\
            .global_errors(BaseController.global_errors())\
            .base_uri_executor(self.config.get_base_uri)\
            .user_agent(BaseController.user_agent(),
                BaseController.user_agent_parameters())\
            .global_header("X-MyPayQuicker-Version",
                self.config.x_my_pay_quicker_version)

        self.auth_managers = {
            "server": Server(self.config.server_credentials,
                             self.global_configuration),
            "clientside": Clientside(self.config.clientside_credentials),
        }
        self.global_configuration =\
            self.global_configuration.auth_managers(self.auth_managers)

    @classmethod
    def from_environment(cls, dotenv_path=None, **overrides):
        """Create a client instance using environment variables.

        Returns:
            PayQuickerSdkClient instance.

        """
        return cls(config=Configuration
            .from_environment(dotenv_path=dotenv_path, **overrides))
