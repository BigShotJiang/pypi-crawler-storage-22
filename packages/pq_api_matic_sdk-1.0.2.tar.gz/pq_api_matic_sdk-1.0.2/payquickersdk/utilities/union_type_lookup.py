
"""
pay_quicker_sdk

This file was automatically generated for PayQuicker by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

# ruff: noqa: E501
from __future__ import annotations

from typing import (
    Callable,
    ClassVar,
)

from apimatic_core.types.union_types.leaf_type import (
    LeafType,
)
from apimatic_core.types.union_types.one_of import (
    OneOf,
)
from apimatic_core.types.union_types.union_type_context import (
    UnionTypeContext as Context,
)

from payquickersdk.models.gateway_payment_job import (
    GatewayPaymentJob,
)
from payquickersdk.models.gateway_payment_quote import (
    GatewayPaymentQuote,
)
from payquickersdk.models.gateway_spendback_quote import (
    GatewaySpendbackQuote,
)
from payquickersdk.models.gateway_transfer_quote import (
    GatewayTransferQuote,
)
from payquickersdk.models.portal_payment_job import (
    PortalPaymentJob,
)
from payquickersdk.models.portal_payment_quote import (
    PortalPaymentQuote,
)
from payquickersdk.models.portal_spendback_quote import (
    PortalSpendbackQuote,
)
from payquickersdk.models.portal_transfer_quote import (
    PortalTransferQuote,
)


class UnionTypeLookUp:
    """
    Provides lookup and factory methods for predefined union type templates.
    This class stores a mapping of template names to callables that construct
    union type instances. These templates are used to describe compatible
    data shapes by combining primitive or model-based types into a single
    resolved representation at runtime.

    Attributes:
        _templates (dict): A mapping of template names to factory callables
        that create configured union types.

    """

    _templates: ClassVar[dict[str, Callable]] = {
        "_PaymentQuote": lambda: OneOf(
            [
                LeafType(GatewayPaymentQuote),
                LeafType(PortalPaymentQuote),
            ],
            Context.create(
               is_optional=True,
            ),
        ),
        "_SpendbackQuote": lambda: OneOf(
            [
                LeafType(GatewaySpendbackQuote),
                LeafType(PortalSpendbackQuote),
            ],
            Context.create(
               is_optional=True,
            ),
        ),
        "_TransferQuote": lambda: OneOf(
            [
                LeafType(GatewayTransferQuote),
                LeafType(PortalTransferQuote),
            ],
            Context.create(
               is_optional=True,
            ),
        ),
        "_PaymentJob": lambda: OneOf(
            [
                LeafType(GatewayPaymentJob),
                LeafType(PortalPaymentJob),
            ],
            Context.create(
               is_optional=True,
            ),
        ),
    }

    @staticmethod
    def get(name):
        """
        Retrieve and construct a union type template by name.

        Args:
            name (str): The key identifying the template to resolve.

        Returns:
            Any: A new instance of the union type defined for the given name.

        Raises:
            KeyError: If no template exists for the specified name.

        """
        return UnionTypeLookUp._templates[name]()
