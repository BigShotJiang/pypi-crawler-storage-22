# Installation Guide - PQC Analyzer MCP Server

## Prerequisites

### Required
- **Python 3.10 or higher** (Python 3.9 and below are NOT supported)
- **Git** (for analyzing commits)
- **pip** (Python package manager)

### System Requirements
- macOS, Linux, or Windows
- Command-line access
- Git repository access

## Step 1: Install Python 3.10+

### Check Current Python Version

```bash
python3 --version
```

If you see Python 3.10 or higher, skip to Step 2.

### Install Python 3.10+ (macOS)

#### Option A: Using Homebrew (Recommended)

```bash
# Install Homebrew if not already installed
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Python 3.12
brew install python@3.12

# Verify installation
python3.12 --version
```

#### Option B: Download from python.org

1. Visit https://www.python.org/downloads/
2. Download Python 3.12 (or latest 3.10+)
3. Run the installer
4. Verify: `python3.12 --version`

### Install Python 3.10+ (Linux)

#### Ubuntu/Debian

```bash
sudo apt update
sudo apt install python3.12 python3.12-pip
```

#### Fedora/RHEL

```bash
sudo dnf install python3.12 python3.12-pip
```

### Install Python 3.10+ (Windows)

1. Visit https://www.python.org/downloads/
2. Download Python 3.12 installer
3. Run installer and check "Add Python to PATH"
4. Verify in Command Prompt: `python --version`

## Step 2: Run Setup Script

### Automated Setup (Recommended)

```bash
cd /Users/sucharitapaul/Documents/Cline/MCP/pqc-analyzer
./setup.sh
```

The setup script will:
- ✅ Detect Python 3.10+ installation
- ✅ Install MCP SDK
- ✅ Make server executable
- ✅ Provide configuration instructions

### Manual Setup (Alternative)

If the setup script fails, install manually:

```bash
# Navigate to server directory
cd /Users/sucharitapaul/Documents/Cline/MCP/pqc-analyzer

# Install MCP SDK (use python3.12, python3.11, or python3.10)
python3.12 -m pip install --user mcp

# Make server executable
chmod +x server.py

# Verify installation
python3.12 -c "import mcp; print('MCP SDK installed successfully')"
```

## Step 3: Configure MCP Settings

### Locate MCP Settings File

**IBM Bob:**
```
/Users/sucharitapaul/Library/Application Support/IBM Bob/User/globalStorage/ibm.bob-code/settings/mcp_settings.json
```

**Claude Desktop (if applicable):**
```
~/Library/Application Support/Claude/claude_desktop_config.json
```

### Add Server Configuration

Open the settings file and add the PQC analyzer server:

```json
{
  "mcpServers": {
    "pqc-analyzer": {
      "command": "python3.12",
      "args": ["/Users/sucharitapaul/Documents/Cline/MCP/pqc-analyzer/server.py"],
      "disabled": false,
      "alwaysAllow": [],
      "disabledTools": []
    }
  }
}
```

**Important:** Replace `python3.12` with your actual Python command:
- `python3.12` (if you installed Python 3.12)
- `python3.11` (if you installed Python 3.11)
- `python3.10` (if you installed Python 3.10)

### Verify Python Command

```bash
# Test which Python version you have
which python3.12 || which python3.11 || which python3.10
```

Use the command that returns a path.

## Step 4: Restart IBM Bob

After adding the configuration:

1. **Quit IBM Bob completely** (Cmd+Q on macOS)
2. **Restart IBM Bob**
3. The PQC analyzer server will start automatically

## Step 5: Verify Installation

### Check Server Status

In IBM Bob, you should see the PQC analyzer server listed under "Connected MCP Servers".

### Test the Server

Try these commands in IBM Bob:

```
Get information about DILITHIUM algorithm
```

```
Analyze commit <commit-id> for PQC readiness
```

Replace `<commit-id>` with an actual commit SHA from your repository.

## Troubleshooting

### Issue: "Python 3.10+ not found"

**Solution:** Install Python 3.10 or higher using the instructions in Step 1.

### Issue: "mcp module not found"

**Solution:** Install MCP SDK manually:

```bash
python3.12 -m pip install --user mcp
```

### Issue: "Permission denied" when running setup.sh

**Solution:** Make the script executable:

```bash
chmod +x /Users/sucharitapaul/Documents/Cline/MCP/pqc-analyzer/setup.sh
```

### Issue: "Git command not found"

**Solution:** Install Git:

**macOS:**
```bash
brew install git
```

**Linux:**
```bash
sudo apt install git  # Ubuntu/Debian
sudo dnf install git  # Fedora/RHEL
```

### Issue: Server not appearing in IBM Bob

**Solutions:**
1. Check the MCP settings file syntax (valid JSON)
2. Verify the Python command path is correct
3. Restart IBM Bob completely
4. Check IBM Bob logs for errors

### Issue: "Invalid commit ID"

**Solution:** Verify the commit exists:

```bash
cd /path/to/your/repo
git log --oneline -10
```

Use a commit SHA from the output.

## Verification Checklist

- [ ] Python 3.10+ installed and verified
- [ ] MCP SDK installed (`python3.12 -c "import mcp"` works)
- [ ] server.py is executable (`ls -l server.py` shows `x` permission)
- [ ] MCP settings file updated with correct configuration
- [ ] IBM Bob restarted
- [ ] Server appears in "Connected MCP Servers"
- [ ] Test command works successfully

## Getting Help

If you encounter issues:

1. Check the error message carefully
2. Verify all prerequisites are met
3. Review the troubleshooting section
4. Check the main README.md for additional information

## Next Steps

Once installed, refer to:
- **README.md** - Usage examples and features
- **Example commands** - Try analyzing your first commit
- **Integration guide** - Connect with your crypto-agility framework

---

**Installation complete!** You can now use the PQC Analyzer to assess quantum readiness of your codebase.