# PQC Readiness Analyzer MCP Server

A Model Context Protocol (MCP) server that analyzes Git commits for Post-Quantum Cryptography (PQC) readiness. This server integrates with your crypto-agility framework to provide automated analysis of cryptographic algorithm usage and quantum risk assessment.

## Features

- **Git Commit Analysis**: Analyzes code changes in Git commits to detect cryptographic algorithms
- **PQC Algorithm Detection**: Identifies classical, PQC, and hybrid cryptographic algorithms
- **Readiness Scoring**: Calculates deterministic PQC readiness percentages
- **Risk Classification**: Categorizes quantum risk levels (LOW, MEDIUM, HIGH, CRITICAL)
- **Detailed Reporting**: Provides comprehensive analysis with recommendations

## Supported Algorithms

### Post-Quantum (PQC-Safe)
- **Dilithium** (Dilithium2, Dilithium3, Dilithium5) - NIST FIPS 204
- **Falcon** (Falcon-512, Falcon-1024) - NIST FIPS 206
- **SPHINCS+** - NIST FIPS 205
- **Hybrid** (RSA+Dilithium) - Experimental

### Classical (Quantum-Vulnerable)
- **RSA** (RSA-2048, RSA-3072, RSA-4096)
- **ECDSA** (P-256, secp256r1)

### Hash Functions (Quantum-Resistant)
- **SHA-256**, **SHA-3** (quantum-resistant for hashing)

## Installation

### Prerequisites
- Python 3.10 or higher
- Git installed and accessible from command line
- Access to your Git repository

### Setup

1. Install dependencies:
```bash
cd /Users/sucharitapaul/Documents/Cline/MCP/pqc-analyzer
pip install -r requirements.txt
```

2. Make the server executable:
```bash
chmod +x server.py
```

## Configuration

Add the server to your MCP settings file at:
`/Users/sucharitapaul/Library/Application Support/IBM Bob/User/globalStorage/ibm.bob-code/settings/mcp_settings.json`

```json
{
  "mcpServers": {
    "pqc-analyzer": {
      "command": "python3",
      "args": ["/Users/sucharitapaul/Documents/Cline/MCP/pqc-analyzer/server.py"],
      "disabled": false,
      "alwaysAllow": [],
      "disabledTools": []
    }
  }
}
```

## Available Tools

### 1. analyze_commit_pqc_readiness

Analyzes a Git commit for PQC readiness and provides a comprehensive report.

**Parameters:**
- `commit_id` (required): Git commit SHA to analyze
- `repo_path` (optional): Path to Git repository (defaults to current directory)

**Returns:**
- Total algorithms detected
- PQC-safe vs unsafe counts
- Classical, PQC, and hybrid algorithm counts
- PQC readiness percentage (0-100%)
- Quantum risk level (LOW/MEDIUM/HIGH/CRITICAL)
- Detailed list of detected algorithms with file locations
- Actionable recommendations

**Example Usage:**
```
Analyze commit abc123 for PQC readiness in the current repository
```

### 2. get_pqc_algorithm_info

Provides detailed information about cryptographic algorithms.

**Parameters:**
- `algorithm` (optional): Specific algorithm name (DILITHIUM, FALCON, SPHINCS, RSA, ECDSA, HYBRID)

**Returns:**
- Algorithm specifications
- NIST standardization status
- Security levels
- Key sizes and signature sizes
- Quantum safety status
- Recommended use cases

**Example Usage:**
```
Get information about DILITHIUM algorithm
```

## How It Works

### Algorithm Detection

The server uses pattern matching to detect cryptographic algorithms in code:

1. **Pattern Recognition**: Scans code for algorithm-specific patterns (e.g., `RSA_3072`, `DilithiumKeyPairGenerator`, `AlgorithmType.FALCON`)
2. **File Analysis**: Analyzes Java, Python, JavaScript, TypeScript, Go, C/C++ files
3. **Context Extraction**: Captures the code context where algorithms are used

### PQC Readiness Calculation

```
PQC Readiness % = (PQC-Safe Algorithms / Total Algorithms) × 100
```

**Risk Level Classification:**
- **LOW** (90-100%): Excellent PQC readiness
- **MEDIUM** (70-89%): Good progress, some work needed
- **HIGH** (40-69%): Significant quantum risk exposure
- **CRITICAL** (0-39%): Immediate action required

### Recommendations Engine

The server provides context-aware recommendations:
- Migration strategies for classical algorithms
- Hybrid approach suggestions for gradual transitions
- NIST standard compliance guidance
- Priority levels based on risk assessment

## Integration with Crypto-Agility Framework

This MCP server is designed to work seamlessly with your existing crypto-agility framework:

- Recognizes `AlgorithmType` enum values (RSA_3072, ECDSA_P256, DILITHIUM3, FALCON512, HYBRID_RSA_DILITHIUM)
- Detects key pair generators (RSAKeyPairGenerator, DilithiumKeyPairGenerator, etc.)
- Identifies certificate builders (ClassicalCertificateBuilder, PQCCertificateBuilder, HybridCertificateBuilder)
- Analyzes policy-driven configurations

## Example Analysis Report

```markdown
# PQC Readiness Analysis Report

## Commit Information
- Commit ID: abc123def456
- Repository: /path/to/repo

## Summary Statistics
- Total Algorithms Detected: 5
- PQC-Safe Algorithms: 3
- PQC-Unsafe Algorithms: 2
- Classical Algorithms: 2
- Hybrid Algorithms: 1

## PQC Readiness Score
- Score: 60.0%
- Quantum Risk Level: HIGH

## Detected Algorithms

### 1. RSA (CLASSICAL)
- File: `src/main/java/com/example/KeyGen.java`
- Line: 45
- PQC Safe: ❌ No
- Context: `KeyPairGenerator.getInstance("RSA")`

### 2. DILITHIUM (PQC)
- File: `src/main/java/com/example/PQCKeyGen.java`
- Line: 23
- PQC Safe: ✅ Yes
- Context: `new DilithiumKeyPairGenerator()`

## Recommendations

⚠️ CRITICAL: Found 2 classical algorithm(s). Consider hybrid approach (RSA+Dilithium) for gradual migration.

🟡 MEDIUM PRIORITY: PQC readiness is moderate. Plan migration strategy for remaining classical algorithms.

✅ Good: 1 hybrid algorithm(s) detected. This provides a balanced transition path to full PQC.
```

## Troubleshooting

### Common Issues

1. **Git command not found**
   - Ensure Git is installed and in your PATH
   - Test with: `git --version`

2. **Permission denied**
   - Make server.py executable: `chmod +x server.py`

3. **MCP SDK not found**
   - Install dependencies: `pip install -r requirements.txt`

4. **Invalid commit ID**
   - Verify commit exists: `git log --oneline`
   - Use full or short SHA (minimum 7 characters)

## Development

### Testing the Server

```bash
# Test locally
python3 server.py

# Test with a specific commit
# (Use through MCP client or IBM Bob)
```

### Extending Algorithm Detection

To add new algorithm patterns, edit the `ALGORITHM_PATTERNS` dictionary in `server.py`:

```python
'NEW_ALGORITHM': {
    'patterns': [
        r'pattern1',
        r'pattern2',
    ],
    'family': 'PQC',  # or 'CLASSICAL', 'HYBRID'
    'pqc_safe': True  # or False
}
```

## License

Part of the crypto-agility framework Bob-athon initiative.

## Support

For issues or questions, refer to the main crypto-agility framework documentation.