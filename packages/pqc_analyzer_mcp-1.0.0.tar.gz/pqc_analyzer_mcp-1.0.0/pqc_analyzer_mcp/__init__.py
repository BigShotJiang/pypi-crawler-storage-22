"""
PQC Analyzer MCP Server

A Model Context Protocol server for analyzing Git commits for 
Post-Quantum Cryptography (PQC) readiness.
"""

__version__ = "1.0.0"
__author__ = "Sucharita Paul"

from .server import main

__all__ = ["main"]