# Leave this file empty or add the version
__version__ = "0.1.1"