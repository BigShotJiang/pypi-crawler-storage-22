from .pqc_wrapper_shim import ml_kem_generate

# This allows the CLI and the refactored code to see the shim