def get_badge_markdown(score):
    color = "brightgreen" if score > 90 else "yellow" if score > 50 else "red"
    badge_url = f"https://img.shields.io/badge/Quantum--Readiness-{score}%25-{color}"
    return f"![PQC-Hero Status]({badge_url})"