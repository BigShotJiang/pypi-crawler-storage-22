import libcst as cst
import libcst.matchers as m

class ImportUpdater(cst.CSTTransformer):
    """
    Ensures PQC libraries are imported by adding:
    from pqc_hero.engine import pqc_wrapper_shim as pqc_wrapper
    """
    def leave_Module(self, original_node: cst.Module, updated_node: cst.Module) -> cst.Module:
        # Check if our specific shim is already imported
        has_pqc_import = any(
            m.matches(body_stmt, m.SimpleStatementLine(body=[m.ImportFrom(module=m.Attribute(attr=m.Name("engine")))]))
            for body_stmt in updated_node.body
        )

        if not has_pqc_import:
            # Construct: from pqc_hero.engine import pqc_wrapper_shim as pqc_wrapper
            new_import = cst.SimpleStatementLine(
                body=[
                    cst.ImportFrom(
                        module=cst.Attribute(
                            value=cst.Name("pqc_hero"),
                            attr=cst.Name("engine")
                        ),
                        names=[
                            cst.ImportAlias(
                                name=cst.Name("pqc_wrapper_shim"),
                                asname=cst.AsName(name=cst.Name("pqc_wrapper"))
                            )
                        ]
                    )
                ]
            )
            
            # Insert at the top
            return updated_node.with_changes(body=[new_import] + list(updated_node.body))
        
        return updated_node