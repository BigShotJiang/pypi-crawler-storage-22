"""
AI-Powered PR Analysis
Supports multiple AI providers: AWS Bedrock (with SSO), Google Gemini, and OpenAI
"""

import os
import json
import requests
from typing import Dict, Any, List, Optional
from enum import Enum


class AIProvider(Enum):
    """Supported AI providers"""
    BEDROCK = "bedrock"
    GEMINI = "gemini"
    OPENAI = "openai"


class AIAnalyzer:
    """Analyzes PRs using AI - supports multiple providers"""
    
    # Available Gemini models
    GEMINI_MODELS = [
        "gemini-2.5-flash",
        "gemini-2.5-pro", 
        "gemini-2.0-flash",
        "gemini-2.0-flash-001",
        "gemini-2.0-flash-lite-001",
        "gemini-2.0-flash-lite",
        "gemini-2.5-flash-lite"
    ]
    
    # Available OpenAI models
    OPENAI_MODELS = [
        "gpt-4o",
        "gpt-4o-mini",
        "gpt-4-turbo",
        "gpt-4",
        "gpt-3.5-turbo"
    ]
    
    def __init__(self, provider: str = None, api_key: str = None, 
                 region: str = 'us-east-1', model: str = None, config: Dict = None):
        """
        Initialize AI analyzer
        
        Args:
            provider: 'bedrock', 'gemini', or 'openai' (auto-detect if None)
            api_key: API key for the provider
            region: AWS region for Bedrock (default: us-east-1)
            model: Specific model to use (provider-specific)
            config: Configuration dictionary
        """
        self.config = config or {}
        
        # Auto-detect provider if not specified
        if provider is None:
            provider = self._auto_detect_provider()
        
        self.provider = AIProvider(provider.lower())
        self.api_key = api_key or self._get_api_key()
        self.region = region
        
        # Set model based on provider
        if self.provider == AIProvider.GEMINI:
            self.model = model or self.config.get('ai', {}).get('gemini', {}).get('model', "gemini-2.0-flash-lite")
            self._init_gemini()
        elif self.provider == AIProvider.OPENAI:
            self.model = model or self.config.get('ai', {}).get('openai', {}).get('model', "gpt-4o-mini")
            self._init_openai()
        else:  # BEDROCK
            self.model = model or self.config.get('ai', {}).get('bedrock', {}).get('model_id', "us.anthropic.claude-3-5-haiku-20241022-v1:0")
            self._init_bedrock()
    
    def _auto_detect_provider(self) -> str:
        """Auto-detect available AI provider"""
        if os.getenv('GEMINI_API_KEY'):
            return 'gemini'
        elif os.getenv('OPENAI_API_KEY'):
            return 'openai'
        elif os.getenv('BEDROCK_API_KEY') or os.getenv('AWS_PROFILE'):
            return 'bedrock'
        else:
            raise ValueError("No AI provider configured. Set GEMINI_API_KEY, OPENAI_API_KEY, or configure AWS Bedrock")
    
    def _get_api_key(self) -> Optional[str]:
        """Get API key from environment"""
        if self.provider == AIProvider.GEMINI:
            key = os.getenv('GEMINI_API_KEY')
            if not key:
                raise ValueError("GEMINI_API_KEY not set")
            return key
        elif self.provider == AIProvider.OPENAI:
            key = os.getenv('OPENAI_API_KEY')
            if not key:
                raise ValueError("OPENAI_API_KEY not set")
            return key
        else:  # BEDROCK
            # For Bedrock, API key is optional (can use SSO/IAM)
            return os.getenv('BEDROCK_API_KEY')
    
    def _init_gemini(self):
        """Initialize Gemini client"""
        self.base_url = "https://generativelanguage.googleapis.com/v1"
        print(f"✓ Initialized Gemini AI ({self.model})")
    
    def _init_openai(self):
        """Initialize OpenAI client"""
        self.openai_base_url = "https://api.openai.com/v1"
        print(f"✓ Initialized OpenAI ({self.model})")
    
    def _init_bedrock(self):
        """Initialize Bedrock client with SSO support"""
        try:
            import boto3
            from botocore.exceptions import NoCredentialsError, ProfileNotFound
            
            bedrock_config = self.config.get('ai', {}).get('bedrock', {})
            auth_method = bedrock_config.get('auth_method', 'api_key')
            
            session_kwargs = {'region_name': bedrock_config.get('region', self.region)}
            
            if auth_method == 'sso':
                # Use SSO profile
                sso_profile = bedrock_config.get('sso_profile') or os.getenv('AWS_PROFILE')
                if sso_profile:
                    session_kwargs['profile_name'] = sso_profile
                    print(f"✓ Using AWS SSO profile: {sso_profile}")
                else:
                    raise ValueError("SSO profile not configured. Set AWS_PROFILE or configure in config.yaml")
            
            elif auth_method == 'iam_role':
                # Use default IAM role credentials
                print("✓ Using IAM role credentials")
            
            elif auth_method == 'api_key' and self.api_key:
                # Use API key (bearer token)
                os.environ['AWS_BEARER_TOKEN_BEDROCK'] = self.api_key
                os.environ['AWS_ACCESS_KEY_ID'] = 'not-used'
                os.environ['AWS_SECRET_ACCESS_KEY'] = 'not-used'
                print("✓ Using Bedrock API key")
            
            # Create session and client
            session = boto3.Session(**session_kwargs)
            self.bedrock_runtime = session.client('bedrock-runtime')
            
            print(f"✓ Initialized AWS Bedrock ({self.model})")
        except ImportError:
            raise ImportError("boto3 required for Bedrock. Install: pip install boto3")
        except (NoCredentialsError, ProfileNotFound) as e:
            raise ValueError(f"Bedrock authentication failed: {str(e)}")
    
    def _invoke_gemini(self, prompt: str, max_tokens: int = 2000, 
                      temperature: float = 0.3) -> str:
        """Invoke Gemini API"""
        url = f"{self.base_url}/models/{self.model}:generateContent?key={self.api_key}"
        
        payload = {
            "contents": [{
                "parts": [{"text": prompt}]
            }],
            "generationConfig": {
                "maxOutputTokens": max_tokens,
                "temperature": temperature
            }
        }
        
        headers = {"Content-Type": "application/json"}
        
        try:
            response = requests.post(url, json=payload, headers=headers, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                text = result['candidates'][0]['content']['parts'][0]['text']
                return text
            else:
                raise Exception(f"Gemini API error: {response.status_code} - {response.text}")
        except Exception as e:
            raise Exception(f"Gemini request failed: {str(e)}")
    
    def _invoke_openai(self, prompt: str, max_tokens: int = 2000,
                      temperature: float = 0.3) -> str:
        """Invoke OpenAI API"""
        url = f"{self.openai_base_url}/chat/completions"
        
        payload = {
            "model": self.model,
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "max_tokens": max_tokens,
            "temperature": temperature
        }
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        try:
            response = requests.post(url, json=payload, headers=headers, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                text = result['choices'][0]['message']['content']
                return text
            else:
                raise Exception(f"OpenAI API error: {response.status_code} - {response.text}")
        except Exception as e:
            raise Exception(f"OpenAI request failed: {str(e)}")
    
    def _invoke_bedrock(self, prompt: str, max_tokens: int = 2000,
                       temperature: float = 0.3) -> str:
        """Invoke Bedrock API"""
        from botocore.exceptions import ClientError
        
        request_body = {
            "messages": [
                {
                    "role": "user",
                    "content": [{"text": prompt}]
                }
            ],
            "inferenceConfig": {
                "maxTokens": max_tokens,
                "temperature": temperature
            }
        }
        
        try:
            response = self.bedrock_runtime.converse(
                modelId=self.model,
                messages=request_body["messages"],
                inferenceConfig=request_body["inferenceConfig"]
            )
            
            return response['output']['message']['content'][0]['text']
        except ClientError as e:
            raise Exception(f"Bedrock error: {e.response['Error']['Message']}")
    
    def _invoke_model(self, prompt: str, max_tokens: int = 2000,
                     temperature: float = 0.3) -> str:
        """Invoke AI model (provider-agnostic)"""
        if self.provider == AIProvider.GEMINI:
            return self._invoke_gemini(prompt, max_tokens, temperature)
        elif self.provider == AIProvider.OPENAI:
            return self._invoke_openai(prompt, max_tokens, temperature)
        else:  # BEDROCK
            return self._invoke_bedrock(prompt, max_tokens, temperature)
    
    def _parse_json_response(self, response: str, analysis_type: str) -> Dict[str, Any]:
        """Parse JSON from AI response"""
        try:
            # Try to find JSON in response
            start = response.find('{')
            end = response.rfind('}') + 1
            
            if start >= 0 and end > start:
                json_str = response[start:end]
                return json.loads(json_str)
            else:
                # No JSON found
                return {
                    'error': 'No JSON in response',
                    'raw_response': response[:500]
                }
        except json.JSONDecodeError as e:
            return {
                'error': f'JSON parse error: {str(e)}',
                'raw_response': response[:500]
            }
    
    def _prepare_files_summary(self, files: List[Any], max_files: int = 20, include_patches: bool = True) -> str:
        """Prepare file changes summary with actual code changes"""
        summary_lines = []
        total_chars = 0
        max_chars = 15000  # Limit total context to avoid token limits
        
        for i, file in enumerate(files[:max_files]):
            # Handle both dict and object formats
            if isinstance(file, dict):
                filename = file.get('filename', 'unknown')
                additions = file.get('additions', 0)
                deletions = file.get('deletions', 0)
                status = file.get('status', 'modified')
                patch = file.get('patch', '')
            else:
                filename = getattr(file, 'filename', 'unknown')
                additions = getattr(file, 'additions', 0)
                deletions = getattr(file, 'deletions', 0)
                status = getattr(file, 'status', 'modified')
                patch = getattr(file, 'patch', '')
            
            # Add file header
            file_summary = f"\n### File {i+1}: {filename} ({status}): +{additions}/-{deletions}\n"
            
            # Add patch if available and requested
            if include_patches and patch and total_chars < max_chars:
                # Truncate patch if too long
                max_patch_length = min(2000, max_chars - total_chars)
                if len(patch) > max_patch_length:
                    file_summary += f"```diff\n{patch[:max_patch_length]}\n... (truncated)\n```\n"
                else:
                    file_summary += f"```diff\n{patch}\n```\n"
                
                total_chars += len(file_summary)
            else:
                file_summary += "(No changes or patch too large)\n"
            
            summary_lines.append(file_summary)
            
            # Stop if we've reached character limit
            if total_chars >= max_chars:
                remaining = len(files) - i - 1
                if remaining > 0:
                    summary_lines.append(f"\n... and {remaining} more files (truncated to fit context limit)")
                break
        
        if len(files) > max_files:
            summary_lines.append(f"\n... and {len(files) - max_files} more files")
        
        return ''.join(summary_lines)
    
    def analyze_pr_complexity(self, pr_data: Any, max_tokens: int = 2000,
                             temperature: float = 0.3) -> Dict[str, Any]:
        """
        Analyze PR complexity using AI with actual code changes
        
        Args:
            pr_data: PRData object
            max_tokens: Maximum tokens for response
            temperature: Model temperature
            
        Returns:
            Dictionary with complexity analysis
        """
        files_summary = self._prepare_files_summary(pr_data.files, max_files=10, include_patches=True)
        description = pr_data.description or 'No description provided'
        
        prompt = f"""Analyze this Pull Request for complexity based on the actual code changes below.

PR Title: {pr_data.title}
PR Description: {description[:500]}

Changes Summary:
- Files changed: {pr_data.changed_files}
- Lines added: {pr_data.additions}
- Lines deleted: {pr_data.deletions}
- Commits: {pr_data.commits}

Code Changes:
{files_summary}

Based on the actual code changes above, analyze complexity considering:
1. Types of changes (features, refactoring, bug fixes, config)
2. Technical complexity and logic changes
3. Number of systems/modules affected
4. Potential for bugs or breaking changes

Provide a JSON response with the following structure:
{{
    "complexity_level": "low|medium|high|very_high",
    "score": <number 0-100, where 100 is least complex>,
    "key_factors": [
        "specific factor from code analysis",
        "another factor from code review"
    ],
    "risk_areas": [
        "specific risk from code changes",
        "another risk identified"
    ],
    "assessment": "<detailed summary based on code review>",
    "recommendations": [
        "specific recommendation based on changes",
        "another actionable recommendation"
    ]
}}

Focus on:
1. Scope of changes (how many different areas/modules affected)
2. Type of changes (refactoring, new features, bug fixes)
3. Potential impact on existing functionality
4. Code coupling and dependencies"""

        try:
            response = self._invoke_model(prompt, max_tokens, temperature)
            return self._parse_json_response(response, 'complexity')
        except Exception as e:
            print(f"Error in complexity analysis: {str(e)}")
            return {
                'complexity_level': 'unknown',
                'score': 70,
                'assessment': f'AI analysis failed: {str(e)}',
                'key_factors': [],
                'risk_areas': [],
                'recommendations': []
            }
    
    def analyze_pr_impact(self, pr_data: Any, max_tokens: int = 2000,
                         temperature: float = 0.3) -> Dict[str, Any]:
        """
        Analyze PR impact on codebase
        
        Args:
            pr_data: PRData object
            max_tokens: Maximum tokens for response
            temperature: Model temperature
            
        Returns:
            Dictionary with impact analysis
        """
        files_summary = self._prepare_files_summary(pr_data.files, max_files=10, include_patches=True)
        description = pr_data.description or 'No description provided'
        
        prompt = f"""Analyze the impact of this Pull Request based on actual code changes.

PR Title: {pr_data.title}
PR Description: {description[:500]}

Changes Summary:
- Files changed: {pr_data.changed_files}
- Lines added: {pr_data.additions}
- Lines deleted: {pr_data.deletions}

Code Changes:
{files_summary}

Based on the actual code changes above, analyze:
1. What systems/modules are affected?
2. What are the potential risks?
3. What testing should be done?
4. Any deployment considerations?

Provide a JSON response:
{{
    "impact_level": "minimal|moderate|significant|critical",
    "affected_areas": [
        "specific area from code review",
        "another affected system"
    ],
    "breaking_changes": true|false,
    "migration_needed": true|false,
    "testing_recommendations": [
        "test area 1",
        "test area 2"
    ],
    "deployment_considerations": [
        "consideration 1"
    ]
}}"""

        try:
            response = self._invoke_model(prompt, max_tokens, temperature)
            return self._parse_json_response(response, 'impact')
        except Exception as e:
            print(f"Error in impact analysis: {str(e)}")
            return {
                'impact_level': 'unknown',
                'affected_areas': [],
                'breaking_changes': False,
                'migration_needed': False,
                'testing_recommendations': [],
                'deployment_considerations': []
            }
    
    def get_quality_recommendations(self, pr_data: Any, health_score: int,
                                   max_tokens: int = 1500,
                                   temperature: float = 0.3) -> List[str]:
        """
        Get AI-powered quality improvement recommendations
        
        Args:
            pr_data: PRData object
            health_score: Current PR health score
            max_tokens: Maximum tokens
            temperature: Model temperature
            
        Returns:
            List of recommendations
        """
        files_summary = self._prepare_files_summary(pr_data.files, max_files=10, include_patches=True)
        description = pr_data.description or 'No description provided'
        
        prompt = f"""Review this Pull Request based on actual code changes and provide quality improvement recommendations.

PR Title: {pr_data.title}

Description:
{description[:500]}

Current Health Score: {health_score}/100

Stats:
- Files: {pr_data.changed_files}
- Lines: +{pr_data.additions}/-{pr_data.deletions}
- Commits: {pr_data.commits}
- Reviewers: {pr_data.reviewers}
- Approvals: {pr_data.approvals}

Code Changes:
{files_summary}

Based on the actual code changes above, provide 3-5 specific, actionable recommendations to improve:
1. Code quality
2. Testing coverage
3. Documentation
4. Security
5. Performance

Return as JSON array: ["specific recommendation 1", "specific recommendation 2", ...]"""

        try:
            response = self._invoke_model(prompt, max_tokens, temperature)
            
            # Try to parse as JSON array
            start = response.find('[')
            end = response.rfind(']') + 1
            
            if start >= 0 and end > start:
                json_str = response[start:end]
                recommendations = json.loads(json_str)
                return recommendations if isinstance(recommendations, list) else []
            
            # Fallback: split by newlines
            lines = [line.strip() for line in response.split('\n') if line.strip()]
            return [line.lstrip('- ').lstrip('* ') for line in lines[:5]]
            
        except Exception as e:
            print(f"Error getting recommendations: {str(e)}")
            return ["Unable to generate AI recommendations at this time"]
    
    # Alias methods for backward compatibility
    def analyze_complexity(self, pr_data: Any, **kwargs) -> Dict[str, Any]:
        """Alias for analyze_pr_complexity"""
        return self.analyze_pr_complexity(pr_data, **kwargs)
    
    def analyze_impact(self, pr_data: Any, **kwargs) -> Dict[str, Any]:
        """Alias for analyze_pr_impact"""
        return self.analyze_pr_impact(pr_data, **kwargs)
    
    def generate_review_comments(self, pr_data: Any, **kwargs) -> List[str]:
        """Generate AI-powered review comments"""
        # Get recommendations based on health score
        recommendations = self.get_quality_recommendations(pr_data, health_score=70, **kwargs)
        return recommendations
