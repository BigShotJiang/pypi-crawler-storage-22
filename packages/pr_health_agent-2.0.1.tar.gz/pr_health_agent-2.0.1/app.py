#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PR Review Agent - Unified Application Entry Point
Main menu for setup, PR analysis, and command reference
"""

import os
import sys
import yaml
from pathlib import Path
from dotenv import load_dotenv

# Fix Unicode encoding for Windows console
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')


def clear_screen():
    """Clear the console screen"""
    os.system('cls' if os.name == 'nt' else 'clear')


def print_header():
    """Print application header"""
    print("=" * 70)
    print("🔍 PR Review Agent - AI-Powered Pull Request Analysis")
    print("=" * 70)
    print()


def print_menu():
    """Display main menu"""
    print("📋 Main Menu")
    print("=" * 70)
    print()
    print("1. 🔧 Setup & Configuration")
    print("   └─ Configure GitHub PAT & AI Providers (Gemini/Bedrock/OpenAI)")
    print()
    print("2. 🔍 Analyze Pull Request")
    print("   └─ Health Score, AI Analysis, Security Scan, Coverage Check")
    print()
    print("3. 📖 Commands Reference")
    print("   └─ CLI Usage Examples & Configuration Guide")
    print()
    print("4. ❌ Exit")
    print()
    print("=" * 70)


def setup_wizard():
    """Run setup and validation wizard"""
    clear_screen()
    print_header()
    print("🔧 Setup & Configuration Wizard")
    print("=" * 70)
    print()
    
    # Import setup functions
    from interactive import (
        check_dependencies,
        setup_github_token,
        setup_ai_provider,
        test_all_connections,
        save_env_file
    )
    
    print("Step 1: Checking dependencies...")
    if not check_dependencies():
        print("\n❌ Please install missing dependencies first.")
        input("\nPress Enter to return to main menu...")
        return
    
    print("\n✅ Dependencies OK\n")
    
    print("Step 2: GitHub Configuration")
    print("-" * 70)
    github_token = setup_github_token()
    
    print("\nStep 3: AI Provider Configuration")
    print("-" * 70)
    ai_configs = setup_ai_provider()
    
    print("\nStep 4: Testing Connections")
    print("-" * 70)
    test_all_connections(github_token, ai_configs)
    
    print("\nStep 5: Saving Configuration")
    print("-" * 70)
    save_env_file(github_token, ai_configs)
    
    print("\n✅ Setup Complete!")
    print("\nYour configuration has been saved to .env file")
    print("You can now proceed to analyze Pull Requests.")
    
    input("\nPress Enter to return to main menu...")


def analyze_pr():
    """Analyze pull request with all available checks"""
    clear_screen()
    print_header()
    print("🔍 Pull Request Analysis")
    print("=" * 70)
    print()
    
    # Check if setup is complete
    load_dotenv()
    if not os.getenv('GITHUB_TOKEN'):
        print("❌ GitHub token not configured!")
        print("Please run Setup & Configuration first (Option 1)")
        input("\nPress Enter to return to main menu...")
        return
    
    # Get PR details
    print("Enter Pull Request Details:")
    print("-" * 70)
    repo_name = input("Repository (owner/repo): ").strip()
    if not repo_name or '/' not in repo_name:
        print("❌ Invalid repository format. Use: owner/repo")
        input("\nPress Enter to return to main menu...")
        return
    
    try:
        pr_number = int(input("PR Number: ").strip())
    except ValueError:
        print("❌ Invalid PR number")
        input("\nPress Enter to return to main menu...")
        return
    
    # Import analysis modules
    from pr_collector import PRCollector
    from score_calculator import HealthScoreCalculator
    from ai_analyzer import AIAnalyzer
    from security_scanner import SecurityScanner
    from coverage_analyzer import CoverageAnalyzer
    from commit_analyzer import CommitAnalyzer
    from code_quality_analyzer import CodeQualityAnalyzer
    from comment_generator import CommentGenerator
    from merge_controller import MergeController
    
    print()
    print("🔄 Starting Analysis...")
    print("=" * 70)
    
    # Load configuration
    try:
        with open('config.yaml', 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
    except FileNotFoundError:
        print("❌ config.yaml not found")
        input("\nPress Enter to return to main menu...")
        return
    
    # Step 1: Collect PR data
    print("\n[1/8] 📥 Collecting PR data...")
    try:
        collector = PRCollector(os.getenv('GITHUB_TOKEN'))
        pr_data = collector.get_pr_data(repo_name, pr_number)
        print(f"✅ Fetched PR #{pr_number}: {pr_data.title}")
    except Exception as e:
        print(f"❌ Failed to fetch PR: {str(e)}")
        input("\nPress Enter to return to main menu...")
        return
    
    # Step 2: Security scan
    print("\n[2/8] 🔒 Running security scan...")
    try:
        security_scanner = SecurityScanner(config)
        security_report = security_scanner.scan_pr(pr_data)
        print(f"✅ Security Score: {security_report['score']}/100")
        if security_report['issues']:
            print(f"⚠️  Found {len(security_report['issues'])} security issues")
    except Exception as e:
        print(f"⚠️  Security scan failed: {str(e)}")
        security_report = None
    
    # Step 3: Coverage analysis
    print("\n[3/8] 📊 Analyzing code coverage...")
    try:
        coverage_analyzer = CoverageAnalyzer(config)
        coverage_report = coverage_analyzer.analyze(pr_data)
        print(f"✅ Coverage Score: {coverage_report['score']}/100")
    except Exception as e:
        print(f"⚠️  Coverage analysis failed: {str(e)}")
        coverage_report = None
    
    # Step 4: Commit analysis
    print("\n[4/8] 📝 Analyzing commits...")
    try:
        commit_analyzer = CommitAnalyzer(config)
        commit_report = commit_analyzer.analyze(pr_data)
        print(f"✅ Commit Quality Score: {commit_report['score']}/100")
    except Exception as e:
        print(f"⚠️  Commit analysis failed: {str(e)}")
        commit_report = None
    
    # Step 5: Code quality analysis
    print("\n[5/8] 🎯 Analyzing code quality...")
    try:
        quality_analyzer = CodeQualityAnalyzer(config)
        quality_report = quality_analyzer.analyze(pr_data)
        print(f"✅ Code Quality Score: {quality_report['score']}/100")
    except Exception as e:
        print(f"⚠️  Code quality analysis failed: {str(e)}")
        quality_report = None
    
    # Step 6: AI analysis (if configured)
    ai_analysis = None
    has_ai = (
        os.getenv('GEMINI_API_KEY') or 
        os.getenv('BEDROCK_API_KEY') or 
        os.getenv('AWS_PROFILE') or 
        os.getenv('OPENAI_API_KEY')
    )
    
    if has_ai:
        print("\n[6/8] 🤖 Running AI analysis...")
        try:
            ai_analyzer = AIAnalyzer()
            complexity_analysis = ai_analyzer.analyze_complexity(pr_data)
            impact_analysis = ai_analyzer.analyze_impact(pr_data)
            ai_comments = ai_analyzer.generate_review_comments(pr_data)
            
            ai_analysis = {
                'complexity': complexity_analysis,
                'impact': impact_analysis,
                'comments': ai_comments
            }
            print("✅ AI analysis complete")
        except Exception as e:
            print(f"⚠️  AI analysis failed: {str(e)}")
    else:
        print("\n[6/8] ⚠️  AI analysis skipped (no AI provider configured)")
    
    # Step 7: Calculate health score
    print("\n[7/8] 🧮 Calculating health score...")
    try:
        calculator = HealthScoreCalculator(config)
        score_breakdown = calculator.calculate_score(
            pr_data,
            security_report=security_report,
            coverage_report=coverage_report,
            commit_report=commit_report,
            quality_report=quality_report,
            complexity_analysis=ai_analysis['complexity'] if ai_analysis else None
        )
        print(f"✅ Total Health Score: {score_breakdown.total_score}/100 ({score_breakdown.category})")
    except Exception as e:
        print(f"❌ Score calculation failed: {str(e)}")
        input("\nPress Enter to return to main menu...")
        return
    
    # Step 8: Generate report
    print("\n[8/8] 📄 Generating report...")
    try:
        comment_gen = CommentGenerator(config)
        report = comment_gen.generate_health_report(
            pr_data,
            score_breakdown,
            security_report=security_report,
            coverage_report=coverage_report,
            commit_report=commit_report,
            quality_report=quality_report,
            complexity_analysis=ai_analysis['complexity'] if ai_analysis else None,
            impact_analysis=ai_analysis['impact'] if ai_analysis else None,
            ai_comments=ai_analysis['comments'] if ai_analysis else None
        )
        print("✅ Report generated")
    except Exception as e:
        print(f"❌ Report generation failed: {str(e)}")
        input("\nPress Enter to return to main menu...")
        return
    
    # Display results
    print("\n" + "=" * 70)
    print("📊 ANALYSIS COMPLETE")
    print("=" * 70)
    print(report)
    print("=" * 70)
    
    # Ask if user wants to post comment
    from menu_helper import get_yes_no
    
    if get_yes_no("\nWould you like to post this report as a PR comment?", default='n'):
        try:
            posted = collector.post_comment(repo_name, pr_number, report)
            if posted:
                print("✅ Comment posted to PR successfully!")
                
                # Update merge status
                merge_controller = MergeController(os.getenv('GITHUB_TOKEN'), config)
                can_merge, reason = merge_controller.check_merge_eligibility(score_breakdown.total_score)
                merge_controller.update_pr_status(repo_name, pr_number, score_breakdown.total_score, can_merge)
        except Exception as e:
            print(f"❌ Failed to post comment: {str(e)}")
    
    input("\nPress Enter to return to main menu...")


def show_commands_reference():
    """Display command reference guide"""
    clear_screen()
    print_header()
    print("📖 Commands Reference")
    print("=" * 70)
    print()
    
    print("ANALYSIS COMMANDS")
    print("-" * 70)
    print("Interactive menu (recommended):")
    print("  python app.py")
    print()
    print("Direct PR analysis:")
    print("  python pr_agent.py owner/repo PR_NUMBER")
    print()
    print("PR analysis with AI insights:")
    print("  python pr_agent.py owner/repo PR_NUMBER --ai-analysis")
    print()
    print("Analyze and post comment to PR:")
    print("  python pr_agent.py owner/repo PR_NUMBER --post-comment")
    print()
    print("Analyze and block merge if below threshold:")
    print("  python pr_agent.py owner/repo PR_NUMBER --block-merge")
    print()
    
    print("\nSETUP COMMANDS")
    print("-" * 70)
    print("Guided setup wizard:")
    print("  python interactive.py")
    print()
    print("Validate configuration:")
    print("  python setup_check.py")
    print()
    print("Test Google Gemini connection:")
    print("  python test_gemini.py")
    print()
    print("Test AWS Bedrock connection:")
    print("  python test_bedrock.py")
    print()
    
    print("\nCONFIGURATION")
    print("-" * 70)
    print("Edit scoring weights and thresholds:")
    print("  config.yaml")
    print()
    print("Set environment variables (.env file):")
    print("  GITHUB_TOKEN=ghp_your_token")
    print("  GEMINI_API_KEY=your_gemini_key")
    print("  BEDROCK_API_KEY=your_bedrock_key")
    print("  OPENAI_API_KEY=your_openai_key")
    print("  AI_PROVIDER=gemini  # or bedrock, openai")
    print()
    
    print("\nSCORING CATEGORIES")
    print("-" * 70)
    print("Size (10%): Lines changed, files impacted, commits count")
    print("Commit Quality (10%): Message quality, atomic commits")
    print("Test Quality (20%): Coverage %, test files ratio")
    print("Review Quality (20%): Reviewers, approvals, comments")
    print("Complexity (15%): AI-powered complexity assessment")
    print("Security (15%): Secret scanning, vulnerability checks")
    print("Code Quality (5%): Linting, duplication, complexity")
    print("Documentation (5%): PR description, inline comments")
    print()
    
    print("\nPR SIZE CATEGORIES")
    print("-" * 70)
    print("Small:        <5 lines, 1-2 files, 1-2 commits")
    print("Medium:       <10 lines, 4-5 files, ≤5 commits")
    print("Complex:      15-50 lines, <10 files, ≤10 commits")
    print("Very Complex: >50 lines, >10 files, >10 commits")
    print()
    
    print("\nAI PROVIDERS SUPPORTED")
    print("-" * 70)
    print("Google Gemini:")
    print("  - Get API key: https://aistudio.google.com/app/apikey")
    print("  - Models: gemini-2.0-flash-lite (default), gemini-2.5-flash, gemini-2.5-pro")
    print()
    print("AWS Bedrock:")
    print("  - Supports SSO/IAM Role authentication")
    print("  - Models: Claude 3.5 Haiku, Claude 3.5 Sonnet")
    print()
    print("OpenAI:")
    print("  - Get API key: https://platform.openai.com/api-keys")
    print("  - Models: gpt-4o, gpt-4o-mini, gpt-4-turbo")
    print()
    
    input("\nPress Enter to return to main menu...")


def main():
    """Main application loop"""
    from menu_helper import get_single_choice
    
    # Load environment variables
    load_dotenv()
    
    while True:
        clear_screen()
        print_header()
        
        # Use menu_helper for better UX
        choice = get_single_choice(
            "📋 Main Menu - Select an option:",
            [
                (1, "🔧 Setup & Configuration - Configure GitHub PAT & AI Providers"),
                (2, "🔍 Analyze Pull Request - Health Score, AI Analysis, Security Scan"),
                (3, "📖 Commands Reference - CLI Usage Examples & Configuration Guide"),
                (4, "❌ Exit")
            ]
        )
        
        if choice == 1:
            setup_wizard()
        elif choice == 2:
            analyze_pr()
        elif choice == 3:
            show_commands_reference()
        elif choice == 4:
            clear_screen()
            print("👋 Thank you for using PR Review Agent!")
            print("=" * 70)
            sys.exit(0)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Goodbye!")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Unexpected error: {str(e)}")
        sys.exit(1)
