"""
Breaking Changes Analyzer Module
Detects and validates documentation of breaking changes
"""

from typing import Dict, Any, List
import re


class BreakingChangesAnalyzer:
    """Analyzes breaking changes in PR"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
    
    def analyze(self, pr_data) -> Dict[str, Any]:
        """
        Analyze breaking changes
        
        Returns:
            Dict with score, detected changes, and documentation status
        """
        result = {
            'score': 0,
            'max_score': 5,
            'has_breaking_changes': False,
            'detected_breaking_changes': [],
            'documented_in_pr': False,
            'documented_in_changelog': False,
            'has_migration_guide': False,
            'severity': 'none',
            'recommendation': '',
            'data_available': True
        }
        
        try:
            # Detect breaking changes
            breaking_changes = self._detect_breaking_changes(pr_data)
            
            if breaking_changes:
                result['has_breaking_changes'] = True
                result['detected_breaking_changes'] = breaking_changes
                result['severity'] = self._calculate_severity(breaking_changes)
            
            # Check documentation
            pr_description = (pr_data.description or '').lower()
            pr_title = pr_data.title.lower()
            
            # Check if documented in PR
            breaking_keywords = ['breaking', 'breaking change', 'bc:', 'major version', 'incompatible']
            result['documented_in_pr'] = any(keyword in pr_description or keyword in pr_title 
                                             for keyword in breaking_keywords)
            
            # Check for migration guide in description
            migration_keywords = ['migration', 'upgrade', 'how to migrate', 'breaking changes']
            result['has_migration_guide'] = any(keyword in pr_description 
                                                for keyword in migration_keywords)
            
            # Check CHANGELOG
            for file in pr_data.files:
                if 'CHANGELOG' in file.get('filename', '').upper():
                    patch = file.get('patch', '').lower()
                    if any(keyword in patch for keyword in breaking_keywords):
                        result['documented_in_changelog'] = True
                    break
            
            # Calculate score
            if not result['has_breaking_changes']:
                # No breaking changes detected - perfect score
                result['score'] = 5
                result['recommendation'] = 'No breaking changes detected'
            else:
                # Breaking changes exist - score based on documentation
                score = 0
                
                if result['documented_in_pr']:
                    score += 2
                
                if result['documented_in_changelog']:
                    score += 2
                
                if result['has_migration_guide']:
                    score += 1
                
                result['score'] = score
                
                # Generate recommendation
                if result['score'] >= 4:
                    result['recommendation'] = 'Breaking changes well documented'
                elif result['score'] >= 3:
                    missing = []
                    if not result['has_migration_guide']:
                        missing.append('migration guide')
                    result['recommendation'] = f"Add {', '.join(missing)} for breaking changes"
                else:
                    result['recommendation'] = 'Breaking changes detected but poorly documented. Add documentation to PR and CHANGELOG with migration guide'
        
        except Exception as e:
            result['data_available'] = False
            result['score'] = 5  # Default to passing if can't analyze
            result['recommendation'] = f'Unable to analyze breaking changes: {str(e)}'
        
        return result
    
    def _detect_breaking_changes(self, pr_data) -> List[Dict[str, str]]:
        """Detect potential breaking changes from PR content"""
        breaking_changes = []
        
        for file in pr_data.files:
            filename = file.get('filename', '')
            patch = file.get('patch', '')
            
            if not patch:
                continue
            
            # API signature changes
            if self._detect_api_signature_change(patch, filename):
                breaking_changes.append({
                    'type': 'API Signature Change',
                    'file': filename,
                    'description': 'Method/function signature modified'
                })
            
            # Database migrations
            if self._detect_db_migration(filename, patch):
                breaking_changes.append({
                    'type': 'Database Migration',
                    'file': filename,
                    'description': 'Schema changes detected'
                })
            
            # Config format changes
            if self._detect_config_change(filename, patch):
                breaking_changes.append({
                    'type': 'Configuration Change',
                    'file': filename,
                    'description': 'Config format or keys modified'
                })
            
            # Removed public methods/classes
            if self._detect_removal(patch, filename):
                breaking_changes.append({
                    'type': 'API Removal',
                    'file': filename,
                    'description': 'Public method/class removed'
                })
            
            # Environment variable changes
            if self._detect_env_var_change(patch, filename):
                breaking_changes.append({
                    'type': 'Environment Variable Change',
                    'file': filename,
                    'description': 'Environment variables modified'
                })
        
        # Check for major dependency version bumps
        for file in pr_data.files:
            if file.get('filename', '') in ['package.json', 'requirements.txt', 'Gemfile', 'go.mod', 'pom.xml']:
                if self._detect_major_version_bump(file.get('patch', '')):
                    breaking_changes.append({
                        'type': 'Major Dependency Upgrade',
                        'file': file.get('filename'),
                        'description': 'Major version dependency update'
                    })
        
        return breaking_changes
    
    def _detect_api_signature_change(self, patch: str, filename: str) -> bool:
        """Detect API signature changes"""
        # Look for function/method definition changes
        patterns = [
            r'-\s*def\s+\w+\([^)]*\):',  # Python
            r'-\s*function\s+\w+\([^)]*\)',  # JavaScript
            r'-\s*public\s+\w+\s+\w+\([^)]*\)',  # Java/C#
        ]
        
        for pattern in patterns:
            if re.search(pattern, patch):
                return True
        
        return False
    
    def _detect_db_migration(self, filename: str, patch: str) -> bool:
        """Detect database migrations"""
        migration_indicators = [
            'migration' in filename.lower(),
            'schema' in filename.lower(),
            re.search(r'CREATE TABLE|ALTER TABLE|DROP TABLE|ADD COLUMN|DROP COLUMN', patch, re.IGNORECASE)
        ]
        
        return any(migration_indicators)
    
    def _detect_config_change(self, filename: str, patch: str) -> bool:
        """Detect configuration changes"""
        config_files = ['config', 'settings', '.env', 'application.properties', 'appsettings.json']
        
        if any(cf in filename.lower() for cf in config_files):
            # Look for removed or renamed keys
            removed_keys = re.findall(r'-\s*["\']?(\w+)["\']?\s*:', patch)
            return len(removed_keys) > 0
        
        return False
    
    def _detect_removal(self, patch: str, filename: str) -> bool:
        """Detect removed public APIs"""
        # Look for removed public functions/classes
        removal_patterns = [
            r'-\s*export\s+(function|class)\s+\w+',  # JavaScript
            r'-\s*public\s+(class|interface)\s+\w+',  # Java/C#
            r'-\s*def\s+\w+\(',  # Python (heuristic)
        ]
        
        for pattern in removal_patterns:
            if re.search(pattern, patch):
                return True
        
        return False
    
    def _detect_env_var_change(self, patch: str, filename: str) -> bool:
        """Detect environment variable changes"""
        if '.env' in filename or 'environment' in filename.lower():
            removed_vars = re.findall(r'-\s*(\w+)=', patch)
            return len(removed_vars) > 0
        
        # Look for env var usage changes in code
        env_patterns = [
            r'-\s*process\.env\.\w+',  # Node.js
            r'-\s*os\.getenv\([\'"](\w+)[\'"]\)',  # Python
            r'-\s*Environment\.GetEnvironmentVariable\(',  # C#
        ]
        
        for pattern in env_patterns:
            if re.search(pattern, patch):
                return True
        
        return False
    
    def _detect_major_version_bump(self, patch: str) -> bool:
        """Detect major version bumps in dependencies"""
        # Look for version changes like 1.x.x -> 2.x.x
        version_changes = re.findall(r'-.*?["\']\^?(\d+)\.\d+\.\d+["\'].*?\n\+.*?["\']\^?(\d+)\.\d+\.\d+["\']', patch)
        
        for old_major, new_major in version_changes:
            if int(new_major) > int(old_major):
                return True
        
        return False
    
    def _calculate_severity(self, breaking_changes: List[Dict[str, str]]) -> str:
        """Calculate severity based on types of breaking changes"""
        if not breaking_changes:
            return 'none'
        
        critical_types = ['Database Migration', 'API Removal']
        high_types = ['API Signature Change', 'Major Dependency Upgrade']
        
        for change in breaking_changes:
            if change['type'] in critical_types:
                return 'critical'
        
        for change in breaking_changes:
            if change['type'] in high_types:
                return 'high'
        
        return 'moderate'
