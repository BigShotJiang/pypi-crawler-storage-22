"""
CHANGELOG Analyzer Module
Checks if CHANGELOG.md is updated and properly formatted
"""

from typing import Dict, Any, Optional
import re
from datetime import datetime


class ChangelogAnalyzer:
    """Analyzes CHANGELOG.md updates in PR"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
    
    def analyze(self, pr_data) -> Dict[str, Any]:
        """
        Analyze CHANGELOG.md updates
        
        Returns:
            Dict with score, details, and recommendations
        """
        result = {
            'score': 0,
            'max_score': 5,
            'has_changelog': False,
            'is_updated': False,
            'has_version': False,
            'has_date': False,
            'has_breaking_changes': False,
            'has_migration_guide': False,
            'format_valid': False,
            'recommendation': '',
            'data_available': True
        }
        
        try:
            # Check if CHANGELOG.md exists in changed files
            changelog_file = None
            changelog_content = ''
            
            for file in pr_data.files:
                filename = file.get('filename', '')
                if filename.lower() in ['changelog.md', 'changelog', 'changes.md', 'history.md']:
                    changelog_file = file
                    result['has_changelog'] = True
                    result['is_updated'] = True
                    
                    # Get patch content to analyze
                    patch = file.get('patch', '')
                    if patch:
                        changelog_content = patch
                    break
            
            if not result['has_changelog']:
                result['score'] = 0
                result['recommendation'] = 'Add CHANGELOG.md file to track changes'
                return result
            
            if not result['is_updated']:
                result['score'] = 1
                result['recommendation'] = 'Update CHANGELOG.md with PR changes'
                return result
            
            # Analyze changelog content
            score = 1  # Base score for having changelog updated
            
            # Check for version number (e.g., [2.1.0], ## 2.1.0, v2.1.0)
            version_patterns = [
                r'\[?\d+\.\d+\.\d+\]?',
                r'[vV]\d+\.\d+\.\d+',
                r'##\s*\d+\.\d+\.\d+'
            ]
            for pattern in version_patterns:
                if re.search(pattern, changelog_content):
                    result['has_version'] = True
                    score += 1
                    break
            
            # Check for date (ISO format or common formats)
            date_patterns = [
                r'\d{4}-\d{2}-\d{2}',
                r'\d{2}/\d{2}/\d{4}',
                r'\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s+\d{4}\b'
            ]
            for pattern in date_patterns:
                if re.search(pattern, changelog_content):
                    result['has_date'] = True
                    score += 0.5
                    break
            
            # Check for breaking changes section
            breaking_patterns = [
                r'###?\s*Breaking\s*Changes?',
                r'###?\s*BREAKING\s*CHANGES?',
                r'\*\*BREAKING\*\*',
                r'⚠️.*breaking'
            ]
            for pattern in breaking_patterns:
                if re.search(pattern, changelog_content, re.IGNORECASE):
                    result['has_breaking_changes'] = True
                    score += 1
                    break
            
            # Check for migration guide
            migration_patterns = [
                r'###?\s*Migration',
                r'###?\s*Upgrade\s*Guide',
                r'How\s*to\s*upgrade',
                r'Migration\s*steps'
            ]
            for pattern in migration_patterns:
                if re.search(pattern, changelog_content, re.IGNORECASE):
                    result['has_migration_guide'] = True
                    score += 1
                    break
            
            # Check for Keep a Changelog format
            keep_a_changelog_sections = ['Added', 'Changed', 'Deprecated', 'Removed', 'Fixed', 'Security']
            sections_found = sum(1 for section in keep_a_changelog_sections 
                               if re.search(rf'###?\s*{section}', changelog_content))
            
            if sections_found >= 2:
                result['format_valid'] = True
                score += 0.5
            
            result['score'] = min(score, 5)
            
            # Generate recommendation
            if result['score'] >= 4.5:
                result['recommendation'] = 'Excellent CHANGELOG documentation'
            elif result['score'] >= 3:
                missing = []
                if not result['has_version']:
                    missing.append('version number')
                if not result['has_date']:
                    missing.append('release date')
                if not result['has_breaking_changes'] and self._likely_has_breaking_changes(pr_data):
                    missing.append('breaking changes section')
                if not result['has_migration_guide'] and result['has_breaking_changes']:
                    missing.append('migration guide')
                
                if missing:
                    result['recommendation'] = f"CHANGELOG updated but missing: {', '.join(missing)}"
                else:
                    result['recommendation'] = 'CHANGELOG documentation is good'
            else:
                result['recommendation'] = 'CHANGELOG needs significant improvements: add version, date, categorized changes'
        
        except Exception as e:
            result['data_available'] = False
            result['score'] = 0
            result['recommendation'] = f'Unable to analyze CHANGELOG: {str(e)}'
        
        return result
    
    def _likely_has_breaking_changes(self, pr_data) -> bool:
        """Heuristic to detect if PR likely has breaking changes"""
        title = pr_data.title.lower()
        description = (pr_data.description or '').lower()
        
        breaking_keywords = ['breaking', 'breaking change', 'bc:', 'major version', 'incompatible']
        
        for keyword in breaking_keywords:
            if keyword in title or keyword in description:
                return True
        
        return False
