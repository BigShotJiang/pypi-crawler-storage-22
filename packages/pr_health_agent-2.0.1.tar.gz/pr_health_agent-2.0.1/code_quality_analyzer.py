"""
Code Quality Analyzer Module
Analyzes code quality including linting issues, complexity, and code duplication
"""

import re
import os
import subprocess
from typing import Dict, Any, List, Optional
from collections import defaultdict


class CodeQualityAnalyzer:
    """Analyzes code quality metrics for pull requests"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize code quality analyzer
        
        Args:
            config: Configuration dictionary
        """
        self.config = config
        self.quality_config = config.get('code_quality', {})
        self.max_complexity = self.quality_config.get('max_complexity', 10)
        self.max_function_length = self.quality_config.get('max_function_length', 50)
    
    def analyze(self, pr_data: Any) -> Dict[str, Any]:
        """
        Analyze code quality for PR
        
        Args:
            pr_data: PRData object
            
        Returns:
            Code quality analysis report
        """
        # Analyze complexity from patches
        complexity_issues = self._analyze_complexity(pr_data)
        
        # Analyze function/method length
        length_issues = self._analyze_function_length(pr_data)
        
        # Analyze code duplication
        duplication_score = self._analyze_duplication(pr_data)
        
        # Try to run linters if available
        linting_results = self._run_linters(pr_data)
        
        # Calculate overall score
        score = self._calculate_quality_score(
            complexity_issues,
            length_issues,
            duplication_score,
            linting_results
        )
        
        return {
            'score': score,
            'complexity_issues': complexity_issues,
            'length_issues': length_issues,
            'duplication_score': duplication_score,
            'linting_results': linting_results,
            'recommendation': self._get_recommendation(complexity_issues, length_issues)
        }
    
    def _analyze_complexity(self, pr_data: Any) -> List[Dict[str, Any]]:
        """
        Analyze cyclomatic complexity from code patches
        
        Args:
            pr_data: PRData object
            
        Returns:
            List of complexity issues
        """
        issues = []
        
        for file_data in pr_data.files:
            if not file_data['patch']:
                continue
            
            filename = file_data['filename']
            
            # Only analyze code files
            if not self._is_code_file(filename):
                continue
            
            patch = file_data['patch']
            
            # Count complexity indicators in added lines
            complexity = self._calculate_patch_complexity(patch)
            
            if complexity > self.max_complexity:
                issues.append({
                    'file': filename,
                    'complexity': complexity,
                    'threshold': self.max_complexity,
                    'description': f'High complexity detected ({complexity} decision points)'
                })
        
        return issues
    
    def _calculate_patch_complexity(self, patch: str) -> int:
        """
        Calculate approximate cyclomatic complexity from patch
        
        Args:
            patch: Git diff patch
            
        Returns:
            Complexity score
        """
        # Complexity indicators (decision points)
        indicators = [
            r'\bif\b',
            r'\belse\b',
            r'\belif\b',
            r'\bfor\b',
            r'\bwhile\b',
            r'\bcatch\b',
            r'\bcase\b',
            r'\b\?\s*.*\s*:',  # Ternary operator
            r'\b&&\b',
            r'\b\|\|\b',
        ]
        
        complexity = 1  # Base complexity
        
        # Only count added lines
        for line in patch.split('\n'):
            if line.startswith('+') and not line.startswith('+++'):
                line_content = line[1:]
                for indicator in indicators:
                    complexity += len(re.findall(indicator, line_content))
        
        return complexity
    
    def _analyze_function_length(self, pr_data: Any) -> List[Dict[str, Any]]:
        """
        Analyze function/method length
        
        Args:
            pr_data: PRData object
            
        Returns:
            List of long function issues
        """
        issues = []
        
        for file_data in pr_data.files:
            if not file_data['patch']:
                continue
            
            filename = file_data['filename']
            
            if not self._is_code_file(filename):
                continue
            
            # Detect long functions in added code
            long_functions = self._find_long_functions(file_data['patch'], filename)
            issues.extend(long_functions)
        
        return issues
    
    def _find_long_functions(self, patch: str, filename: str) -> List[Dict[str, Any]]:
        """Find functions/methods that are too long"""
        issues = []
        in_function = False
        function_name = None
        function_lines = 0
        
        # Language-specific function patterns
        if filename.endswith('.py'):
            func_pattern = r'^\+\s*def\s+(\w+)'
        elif filename.endswith(('.js', '.ts', '.jsx', '.tsx')):
            func_pattern = r'^\+\s*(?:function\s+(\w+)|(\w+)\s*[=:]\s*(?:function|\([^)]*\)\s*=>))'
        elif filename.endswith(('.java', '.c', '.cpp', '.cs')):
            func_pattern = r'^\+\s*(?:public|private|protected)?\s*\w+\s+(\w+)\s*\('
        else:
            return issues
        
        for line in patch.split('\n'):
            if line.startswith('+') and not line.startswith('+++'):
                # Check for function start
                match = re.search(func_pattern, line)
                if match:
                    # Save previous function if too long
                    if in_function and function_lines > self.max_function_length:
                        issues.append({
                            'file': filename,
                            'function': function_name,
                            'lines': function_lines,
                            'threshold': self.max_function_length,
                            'description': f'Function "{function_name}" is too long ({function_lines} lines)'
                        })
                    
                    # Start new function
                    in_function = True
                    function_name = match.group(1) or match.group(2) or 'anonymous'
                    function_lines = 1
                elif in_function:
                    function_lines += 1
                    
                    # Check for function end (simplified heuristic)
                    if line.strip() in ['', '+}', '+    pass']:
                        if function_lines > self.max_function_length:
                            issues.append({
                                'file': filename,
                                'function': function_name,
                                'lines': function_lines,
                                'threshold': self.max_function_length,
                                'description': f'Function "{function_name}" is too long ({function_lines} lines)'
                            })
                        in_function = False
        
        return issues
    
    def _analyze_duplication(self, pr_data: Any) -> float:
        """
        Analyze code duplication (simplified detection)
        
        Args:
            pr_data: PRData object
            
        Returns:
            Duplication score (0-100, higher is better)
        """
        # Collect all added code blocks (simplified)
        code_blocks = defaultdict(int)
        
        for file_data in pr_data.files:
            if not file_data['patch']:
                continue
            
            if not self._is_code_file(file_data['filename']):
                continue
            
            # Extract added lines
            added_lines = []
            for line in file_data['patch'].split('\n'):
                if line.startswith('+') and not line.startswith('+++'):
                    cleaned = line[1:].strip()
                    if len(cleaned) > 10:  # Ignore short lines
                        added_lines.append(cleaned)
            
            # Look for duplicate blocks (3+ consecutive lines)
            for i in range(len(added_lines) - 2):
                block = '\n'.join(added_lines[i:i+3])
                code_blocks[block] += 1
        
        # Calculate duplication percentage
        total_blocks = len(code_blocks)
        duplicated_blocks = sum(1 for count in code_blocks.values() if count > 1)
        
        if total_blocks == 0:
            return 100.0
        
        duplication_pct = (duplicated_blocks / total_blocks) * 100
        
        # Convert to score (inverse)
        score = max(0, 100 - duplication_pct * 2)
        
        return round(score, 1)
    
    def _run_linters(self, pr_data: Any) -> Dict[str, Any]:
        """
        Try to run linters on changed files
        
        Args:
            pr_data: PRData object
            
        Returns:
            Linting results
        """
        results = {
            'ran': False,
            'issues': [],
            'total_issues': 0
        }
        
        # Check if linting tools are available
        linters = self._get_available_linters()
        
        if not linters:
            return results
        
        # Run linters on changed files
        for file_data in pr_data.files:
            filename = file_data['filename']
            
            # Skip deleted files
            if file_data['status'] == 'removed':
                continue
            
            # Run appropriate linter
            linter_issues = self._run_linter_for_file(filename, linters)
            if linter_issues:
                results['issues'].extend(linter_issues)
        
        results['ran'] = True
        results['total_issues'] = len(results['issues'])
        
        return results
    
    def _get_available_linters(self) -> Dict[str, str]:
        """Check which linters are available"""
        linters = {}
        
        # Python linters
        if self._command_exists('pylint'):
            linters['python'] = 'pylint'
        elif self._command_exists('flake8'):
            linters['python'] = 'flake8'
        
        # JavaScript linters
        if self._command_exists('eslint'):
            linters['javascript'] = 'eslint'
        
        return linters
    
    def _command_exists(self, command: str) -> bool:
        """Check if a command exists"""
        try:
            subprocess.run([command, '--version'], 
                         capture_output=True, 
                         timeout=2,
                         check=False)
            return True
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            return False
    
    def _run_linter_for_file(self, filename: str, linters: Dict[str, str]) -> List[Dict[str, Any]]:
        """Run linter for specific file"""
        # Simplified - would need actual implementation
        # This is a placeholder that returns empty list
        return []
    
    def _is_code_file(self, filename: str) -> bool:
        """Check if file is a code file"""
        code_extensions = [
            '.py', '.js', '.ts', '.jsx', '.tsx',
            '.java', '.c', '.cpp', '.cs', '.go',
            '.rb', '.php', '.swift', '.kt', '.rs'
        ]
        return any(filename.endswith(ext) for ext in code_extensions)
    
    def _calculate_quality_score(self, complexity_issues: List, length_issues: List, 
                                 duplication_score: float, linting_results: Dict) -> float:
        """
        Calculate overall code quality score
        
        Args:
            complexity_issues: List of complexity issues
            length_issues: List of length issues
            duplication_score: Duplication score
            linting_results: Linting results
            
        Returns:
            Score from 0-100
        """
        score = 100.0
        
        # Deduct for complexity issues
        score -= len(complexity_issues) * 10
        
        # Deduct for length issues
        score -= len(length_issues) * 8
        
        # Factor in duplication (30% weight)
        score = (score * 0.7) + (duplication_score * 0.3)
        
        # Deduct for linting issues
        if linting_results['ran']:
            lint_deduction = min(linting_results['total_issues'] * 2, 20)
            score -= lint_deduction
        
        return max(0, round(score, 1))
    
    def _get_recommendation(self, complexity_issues: List, length_issues: List) -> str:
        """Generate recommendation based on analysis"""
        recommendations = []
        
        if complexity_issues:
            recommendations.append(f"Reduce complexity in {len(complexity_issues)} file(s)")
        
        if length_issues:
            recommendations.append(f"Refactor {len(length_issues)} long function(s)")
        
        if not recommendations:
            return "Code quality looks good!"
        
        return " | ".join(recommendations)
