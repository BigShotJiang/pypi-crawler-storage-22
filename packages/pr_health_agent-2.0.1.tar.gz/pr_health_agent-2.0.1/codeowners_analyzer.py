"""
CODEOWNERS Analyzer Module
Checks if changed files are covered by CODEOWNERS
"""

from typing import Dict, Any, List
import re


class CodeownersAnalyzer:
    """Analyzes CODEOWNERS coverage for PR"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.codeowners_patterns = []
    
    def analyze(self, pr_data, repo_codeowners_content: str = None) -> Dict[str, Any]:
        """
        Analyze CODEOWNERS coverage
        
        Args:
            pr_data: PR data object
            repo_codeowners_content: Content of CODEOWNERS file from repo
        
        Returns:
            Dict with score, coverage details, and recommendations
        """
        result = {
            'score': 0,
            'max_score': 3,
            'has_codeowners': False,
            'total_files': 0,
            'covered_files': 0,
            'coverage_percent': 0,
            'uncovered_files': [],
            'critical_uncovered': [],
            'owners_assigned': False,
            'recommendation': '',
            'data_available': True
        }
        
        try:
            # Check if CODEOWNERS exists
            if repo_codeowners_content:
                result['has_codeowners'] = True
                self._parse_codeowners(repo_codeowners_content)
            else:
                # Try to find CODEOWNERS in PR files
                for file in pr_data.files:
                    filename = file.get('filename', '')
                    if 'CODEOWNERS' in filename.upper():
                        result['has_codeowners'] = True
                        # In a real implementation, fetch content
                        break
            
            if not result['has_codeowners']:
                result['score'] = 0
                result['recommendation'] = 'Add CODEOWNERS file to define code ownership'
                result['data_available'] = False
                return result
            
            # Analyze file coverage
            changed_files = [f.get('filename', '') for f in pr_data.files]
            result['total_files'] = len(changed_files)
            
            covered = []
            uncovered = []
            critical_uncovered = []
            
            for filepath in changed_files:
                if self._is_covered(filepath):
                    covered.append(filepath)
                else:
                    uncovered.append(filepath)
                    if self._is_critical_file(filepath):
                        critical_uncovered.append(filepath)
            
            result['covered_files'] = len(covered)
            result['uncovered_files'] = uncovered
            result['critical_uncovered'] = critical_uncovered
            
            if result['total_files'] > 0:
                result['coverage_percent'] = (len(covered) / result['total_files']) * 100
            
            # Calculate score
            coverage = result['coverage_percent']
            
            if coverage == 100 and self._check_owners_assigned(pr_data):
                result['score'] = 3
                result['owners_assigned'] = True
            elif coverage >= 90:
                result['score'] = 2
            elif coverage >= 70:
                result['score'] = 1
            else:
                result['score'] = 0
            
            # Generate recommendation
            if result['score'] == 3:
                result['recommendation'] = 'All files covered by CODEOWNERS and owners assigned'
            elif critical_uncovered:
                result['recommendation'] = f"Critical files lack ownership: {', '.join(critical_uncovered[:3])}"
            elif uncovered:
                count = len(uncovered)
                result['recommendation'] = f"{count} file(s) not covered by CODEOWNERS ({coverage:.0f}% coverage)"
            else:
                result['recommendation'] = 'Add code owners as reviewers'
        
        except Exception as e:
            result['data_available'] = False
            result['score'] = 0
            result['recommendation'] = f'Unable to analyze CODEOWNERS: {str(e)}'
        
        return result
    
    def _parse_codeowners(self, content: str):
        """Parse CODEOWNERS file into patterns"""
        self.codeowners_patterns = []
        
        for line in content.split('\n'):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            parts = line.split()
            if len(parts) >= 2:
                pattern = parts[0]
                owners = parts[1:]
                self.codeowners_patterns.append({
                    'pattern': pattern,
                    'owners': owners
                })
    
    def _is_covered(self, filepath: str) -> bool:
        """Check if file is covered by any CODEOWNERS pattern"""
        if not self.codeowners_patterns:
            # If no patterns loaded, assume basic coverage
            return True
        
        for entry in self.codeowners_patterns:
            pattern = entry['pattern']
            
            # Handle glob patterns
            if '*' in pattern:
                import fnmatch
                if fnmatch.fnmatch(filepath, pattern):
                    return True
            # Handle directory patterns
            elif pattern.endswith('/'):
                if filepath.startswith(pattern):
                    return True
            # Exact match
            elif filepath == pattern:
                return True
        
        return False
    
    def _is_critical_file(self, filepath: str) -> bool:
        """Determine if file is critical (auth, payment, security, config)"""
        critical_patterns = [
            r'auth',
            r'authentication',
            r'authorization',
            r'payment',
            r'billing',
            r'security',
            r'crypto',
            r'config',
            r'settings',
            r'permissions',
            r'roles'
        ]
        
        filepath_lower = filepath.lower()
        
        for pattern in critical_patterns:
            if re.search(pattern, filepath_lower):
                return True
        
        return False
    
    def _check_owners_assigned(self, pr_data) -> bool:
        """Check if code owners are assigned as reviewers"""
        # Simple heuristic: check if there are reviewers assigned
        return len(pr_data.reviewers) > 0
