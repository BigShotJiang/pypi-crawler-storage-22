"""
PR Comment Generator
Generates formatted comments for PRs using templates and analysis data
"""

from typing import Dict, Any, List
import yaml


class CommentGenerator:
    """Generates formatted PR comments"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize comment generator
        
        Args:
            config: Configuration dictionary from config.yaml
        """
        self.config = config
        self.templates = config['comment_templates']
        self.thresholds = config['thresholds']
    
    def generate_health_report(self, pr_data: Any, score_breakdown: Any,
                              security_report: Dict[str, Any] = None,
                              coverage_report: Dict[str, Any] = None,
                              commit_report: Dict[str, Any] = None,
                              quality_report: Dict[str, Any] = None,
                              complexity_analysis: Dict[str, Any] = None,
                              impact_analysis: Dict[str, Any] = None,
                              ai_comments: List[str] = None) -> str:
        """
        Generate complete health report comment
        
        Args:
            pr_data: PRData object
            score_breakdown: ScoreBreakdown object
            security_report: Optional security scan report
            coverage_report: Optional coverage analysis report
            commit_report: Optional commit quality report
            quality_report: Optional code quality report
            complexity_analysis: Optional complexity analysis from AI
            impact_analysis: Optional impact analysis from AI
            ai_comments: Optional AI-generated review comments
            
        Returns:
            Formatted comment string
        """
        sections = []
        
        # Header
        sections.append(self._generate_header(score_breakdown))
        
        # Size section
        sections.append(self._generate_size_section(score_breakdown))
        
        # Security section (if available)
        if security_report:
            sections.append(self._generate_security_section(score_breakdown, security_report))
        
        # Test coverage section
        sections.append(self._generate_test_coverage_section(score_breakdown, coverage_report))
        
        # Commit quality section (if available)
        if commit_report:
            sections.append(self._generate_commit_quality_section(score_breakdown, commit_report))
        
        # Code quality section (if available)
        if quality_report:
            sections.append(self._generate_code_quality_section(score_breakdown, quality_report))
        
        # Review quality section
        sections.append(self._generate_review_quality_section(score_breakdown, pr_data))
        
        # Complexity section
        sections.append(self._generate_complexity_section(score_breakdown, complexity_analysis))
        
        # Impact analysis (if available)
        if impact_analysis:
            sections.append(self._generate_impact_section(impact_analysis))
        
        # AI-generated comments (if available)
        if ai_comments:
            sections.append(self._generate_ai_comments_section(ai_comments))
        
        # Recommendations
        sections.append(self._generate_recommendations_section(score_breakdown, security_report, coverage_report, commit_report, quality_report))
        
        # Footer with merge status
        sections.append(self._generate_footer(score_breakdown))
        
        return '\n'.join(sections)
    
    def _generate_header(self, score_breakdown: Any) -> str:
        """Generate header section"""
        score = score_breakdown.total_score
        
        # Determine emoji
        if score >= 90:
            emoji = '🌟'
        elif score >= self.thresholds['min_passing_score']:
            emoji = '✅'
        elif score >= 50:
            emoji = '⚠️'
        else:
            emoji = '❌'
        
        return self.templates['header'].format(
            score=score,
            status_emoji=emoji
        )
    
    def _generate_size_section(self, score_breakdown: Any) -> str:
        """Generate size analysis section"""
        details = score_breakdown.size_details
        
        return self.templates['size_section'].format(
            category=details['category'].replace('_', ' ').title(),
            additions=details['additions'],
            deletions=details['deletions'],
            files_count=details['files_count'],
            commits=details.get('commits', 'N/A'),
            score=int(score_breakdown.size_score)
        )
    
    def _generate_test_coverage_section(self, score_breakdown: Any, coverage_report: Dict[str, Any] = None) -> str:
        """Generate test coverage section"""
        if coverage_report:
            coverage_pct = coverage_report.get('coverage_percent', 0)
            delta = coverage_report.get('coverage_delta', 0)
            
            section = f"\n### 🧪 Test Coverage ({int(score_breakdown.test_quality_score)}/100)\n\n"
            section += f"**Coverage**: {coverage_pct:.1f}%\n"
            if delta != 0:
                delta_sign = '+' if delta > 0 else ''
                section += f"**Delta**: {delta_sign}{delta:.1f}%\n"
            
            return section
        else:
            # Fallback to original format
            details = score_breakdown.test_quality_details
            
            return self.templates['test_coverage_section'].format(
                test_files=details['test_files'],
                total_files=details['total_files'],
                coverage_ratio=details['ratio'],
                score=int(score_breakdown.test_quality_score)
            )
    
    def _generate_review_quality_section(self, score_breakdown: Any, pr_data: Any) -> str:
        """Generate review quality section"""
        details = score_breakdown.review_quality_details
        
        return self.templates['review_quality_section'].format(
            reviewers=details['reviewers'],
            approvals=details['approvals'],
            comments=details['total_comments'],
            score=int(score_breakdown.review_quality_score)
        )
    
    def _generate_complexity_section(self, score_breakdown: Any, 
                                    complexity_analysis: Dict[str, Any] = None) -> str:
        """Generate complexity section"""
        if complexity_analysis and 'assessment' in complexity_analysis:
            assessment = f"{complexity_analysis.get('complexity_level', 'N/A').title()} - {complexity_analysis['assessment']}"
        else:
            assessment = score_breakdown.complexity_details.get('assessment', 'No detailed analysis available')
        
        return self.templates['complexity_section'].format(
            assessment=assessment,
            score=int(score_breakdown.complexity_score)
        )
    
    def _generate_security_section(self, score_breakdown: Any, security_report: Dict[str, Any]) -> str:
        """Generate security section"""
        issues = security_report.get('issues', [])
        issue_summary = f"Found {len(issues)} security issue(s)" if issues else "No security issues detected"
        
        section = f"\n### 🔒 Security Analysis ({int(score_breakdown.security_score)}/100)\n\n"
        section += f"**Status**: {issue_summary}\n\n"
        
        if issues:
            section += "**Issues Detected**:\n"
            for issue in issues[:5]:  # Show top 5 issues
                section += f"- **{issue['type']}**: {issue['description']} (Line {issue.get('line', 'N/A')})\n"
            if len(issues) > 5:
                section += f"- _{len(issues) - 5} more issue(s)..._\n"
        
        return section
    
    def _generate_commit_quality_section(self, score_breakdown: Any, commit_report: Dict[str, Any]) -> str:
        """Generate commit quality section"""
        section = f"\n### 📝 Commit Quality ({int(score_breakdown.commit_quality_score)}/100)\n\n"
        
        total_commits = commit_report.get('commit_count', 0)
        has_conventional = commit_report.get('has_conventional_commits', False)
        has_issues = commit_report.get('has_issue_references', False)
        poor_messages = commit_report.get('poor_messages', [])
        
        section += f"**Total Commits**: {total_commits}\n"
        section += f"**Conventional Commits**: {'Yes' if has_conventional else 'No'}\n"
        section += f"**Issue References**: {'Yes' if has_issues else 'No'}\n"
        
        if poor_messages:
            section += f"\n**Quality Issues**: {len(poor_messages)} commit(s) with poor messages\n"
        
        if commit_report.get('recommendation'):
            section += f"\n**Recommendation**: {commit_report['recommendation']}\n"
        
        return section
    
    def _generate_code_quality_section(self, score_breakdown: Any, quality_report: Dict[str, Any]) -> str:
        """Generate code quality section"""
        section = f"\n### 🎯 Code Quality ({int(score_breakdown.code_quality_score)}/100)\n\n"
        
        complexity_issues = quality_report.get('complexity_issues', [])
        duplication_issues = quality_report.get('duplication_issues', [])
        long_functions = quality_report.get('long_functions', [])
        
        section += f"**Complexity Issues**: {len(complexity_issues)}\n"
        section += f"**Code Duplication**: {len(duplication_issues)} instance(s)\n"
        section += f"**Long Functions**: {len(long_functions)}\n"
        
        if complexity_issues or duplication_issues or long_functions:
            section += "\n**Issues**:\n"
            for issue in complexity_issues[:3]:
                section += f"- High complexity in `{issue.get('function', 'unknown')}` (complexity: {issue.get('score', 'N/A')})\n"
            for issue in duplication_issues[:3]:
                section += f"- Code duplication detected ({issue.get('lines', 'N/A')} lines)\n"
            for func in long_functions[:3]:
                section += f"- Long function `{func.get('name', 'unknown')}` ({func.get('lines', 'N/A')} lines)\n"
        
        return section
    
    def _generate_impact_section(self, impact_analysis: Dict[str, Any]) -> str:
        """Generate impact analysis section"""
        impact_text = []
        
        impact_text.append(f"**Impact Level**: {impact_analysis.get('impact_level', 'Unknown').title()}")
        
        if impact_analysis.get('affected_areas'):
            impact_text.append("\n**Affected Areas**:")
            for area in impact_analysis['affected_areas']:
                impact_text.append(f"- {area}")
        
        if impact_analysis.get('summary'):
            impact_text.append(f"\n{impact_analysis['summary']}")
        
        # Add specific change flags
        flags = []
        if impact_analysis.get('user_facing_changes'):
            flags.append('👥 User-facing changes')
        if impact_analysis.get('breaking_changes'):
            flags.append('⚠️ Breaking changes')
        if impact_analysis.get('database_changes'):
            flags.append('🗄️ Database changes')
        if impact_analysis.get('api_changes'):
            flags.append('🔌 API changes')
        
        if flags:
            impact_text.append("\n**Change Flags**: " + ' | '.join(flags))
        
        if impact_analysis.get('considerations'):
            impact_text.append("\n**Key Considerations**:")
            for consideration in impact_analysis['considerations']:
                impact_text.append(f"- {consideration}")
        
        return self.templates['impact_section'].format(
            impact_analysis='\n'.join(impact_text)
        )
    
    def _generate_ai_comments_section(self, ai_comments: List[str]) -> str:
        """Generate AI comments section"""
        section = "### 🤖 AI-Powered Review Insights\n\n"
        section += '\n\n'.join(ai_comments)
        return section
    
    def _generate_recommendations_section(self, score_breakdown: Any, 
                                         security_report: Dict[str, Any] = None,
                                         coverage_report: Dict[str, Any] = None,
                                         commit_report: Dict[str, Any] = None,
                                         quality_report: Dict[str, Any] = None) -> str:
        """Generate recommendations section"""
        recommendations = []
        
        # Collect recommendations from each category
        if score_breakdown.size_details.get('recommendation'):
            recommendations.append(f"**Size**: {score_breakdown.size_details['recommendation']}")
        
        if security_report and security_report.get('issues'):
            recommendations.append(f"**Security**: Address {len(security_report['issues'])} security issue(s) detected")
        
        if coverage_report and coverage_report.get('recommendation'):
            recommendations.append(f"**Testing**: {coverage_report['recommendation']}")
        elif score_breakdown.test_quality_details.get('recommendation'):
            recommendations.append(f"**Testing**: {score_breakdown.test_quality_details['recommendation']}")
        
        if commit_report and commit_report.get('recommendation'):
            recommendations.append(f"**Commits**: {commit_report['recommendation']}")
        
        if quality_report and (quality_report.get('complexity_issues') or quality_report.get('duplication_issues')):
            recommendations.append(f"**Code Quality**: Reduce complexity and code duplication")
        
        if score_breakdown.review_quality_details.get('recommendation'):
            recommendations.append(f"**Review**: {score_breakdown.review_quality_details['recommendation']}")
        
        if score_breakdown.documentation_details.get('recommendation'):
            recommendations.append(f"**Documentation**: {score_breakdown.documentation_details['recommendation']}")
        
        if score_breakdown.complexity_details.get('recommendation'):
            recommendations.append(f"**Complexity**: {score_breakdown.complexity_details['recommendation']}")
        
        recommendations_text = '\n'.join(f"- {rec}" for rec in recommendations) if recommendations else "- Great work! No major recommendations."
        
        return self.templates['recommendations_section'].format(
            recommendations=recommendations_text
        )
    
    def _generate_footer(self, score_breakdown: Any) -> str:
        """Generate footer with merge status"""
        score = score_breakdown.total_score
        min_score = self.thresholds['min_passing_score']
        
        if score >= min_score:
            merge_status = self.templates['merge_allowed'].format(min_score=min_score)
        else:
            merge_status = self.templates['merge_blocked'].format(min_score=min_score)
        
        return self.templates['footer'].format(merge_status=merge_status)
    
    def generate_quick_summary(self, score_breakdown: Any) -> str:
        """
        Generate a quick summary for console output
        
        Args:
            score_breakdown: ScoreBreakdown object
            
        Returns:
            Summary string
        """
        score = score_breakdown.total_score
        category = score_breakdown.category
        
        summary = f"""
╔══════════════════════════════════════════════════════════╗
║           PR HEALTH SCORE REPORT                         ║
╚══════════════════════════════════════════════════════════╝

Overall Score: {score}/100 ({category.upper()})

Breakdown:
  📏 Size:           {score_breakdown.size_score}/20
  🧪 Test Coverage:  {score_breakdown.test_quality_score}/25
  👀 Review Quality: {score_breakdown.review_quality_score}/25
  🔍 Complexity:     {score_breakdown.complexity_score}/20
  📝 Description:    {score_breakdown.documentation_score}/10

Status: {'✅ PASS' if score >= self.thresholds['min_passing_score'] else '❌ BLOCKED'}
Threshold: {self.thresholds['min_passing_score']}
"""
        return summary
