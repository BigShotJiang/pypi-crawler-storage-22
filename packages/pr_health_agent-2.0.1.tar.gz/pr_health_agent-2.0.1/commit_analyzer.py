"""
Commit Analyzer Module
Analyzes commit quality including count, message quality, and atomic commits
"""

import re
from typing import Dict, Any, List, Optional
from datetime import datetime


class CommitAnalyzer:
    """Analyzes commit quality for pull requests"""
    
    # Conventional commit types
    CONVENTIONAL_TYPES = [
        'feat', 'fix', 'docs', 'style', 'refactor', 
        'perf', 'test', 'build', 'ci', 'chore', 'revert'
    ]
    
    # Poor commit message patterns
    POOR_MESSAGE_PATTERNS = [
        r'^(wip|WIP)$',
        r'^(fix|fixed|fixes)$',
        r'^(update|updated|updates)$',
        r'^(change|changed|changes)$',
        r'^(test|tests)$',
        r'^(stuff|things)$',
        r'^(misc|miscellaneous)$',
        r'^\.+$',  # Just dots
        r'^[0-9]+$',  # Just numbers
    ]
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize commit analyzer
        
        Args:
            config: Configuration dictionary
        """
        self.config = config
        self.commit_config = config.get('commit_quality', {})
        self.max_commits_small = self.commit_config.get('max_commits_small', 2)
        self.max_commits_medium = self.commit_config.get('max_commits_medium', 5)
        self.max_commits_complex = self.commit_config.get('max_commits_complex', 10)
    
    def analyze(self, pr_data: Any) -> Dict[str, Any]:
        """
        Analyze commit quality for PR
        
        Args:
            pr_data: PRData object with commits
            
        Returns:
            Commit analysis report
        """
        commits = pr_data.commits_data if hasattr(pr_data, 'commits_data') else []
        commit_count = len(commits) if commits else pr_data.commits
        
        # Analyze commit messages if available
        if commits:
            message_quality = self._analyze_commit_messages(commits)
            has_conventional = message_quality['conventional_count'] > 0
            has_issue_refs = message_quality['issue_ref_count'] > 0
            poor_messages = message_quality['poor_messages']
        else:
            message_quality = None
            has_conventional = False
            has_issue_refs = False
            poor_messages = []
        
        # Calculate commit count score
        count_score = self._score_commit_count(commit_count, pr_data)
        
        # Calculate message quality score
        msg_score = self._score_message_quality(message_quality) if message_quality else 50
        
        # Overall score (60% count, 40% message quality)
        overall_score = (count_score * 0.6) + (msg_score * 0.4)
        
        return {
            'score': round(overall_score, 1),
            'commit_count': commit_count,
            'count_score': count_score,
            'message_score': msg_score,
            'has_conventional_commits': has_conventional,
            'has_issue_references': has_issue_refs,
            'poor_messages': poor_messages,
            'recommendation': self._get_recommendation(commit_count, message_quality)
        }
    
    def _analyze_commit_messages(self, commits: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze quality of commit messages
        
        Args:
            commits: List of commit dictionaries
            
        Returns:
            Message quality metrics
        """
        total = len(commits)
        conventional_count = 0
        issue_ref_count = 0
        poor_messages = []
        descriptive_count = 0
        
        for commit in commits:
            message = commit.get('message', '')
            
            # Check for conventional commits
            if self._is_conventional_commit(message):
                conventional_count += 1
            
            # Check for issue references (#123, JIRA-123, etc.)
            if self._has_issue_reference(message):
                issue_ref_count += 1
            
            # Check for poor messages
            if self._is_poor_message(message):
                poor_messages.append({
                    'sha': commit.get('sha', '')[:7],
                    'message': message.split('\n')[0][:50]  # First line, max 50 chars
                })
            
            # Check if descriptive (more than 10 characters)
            if len(message.strip()) > 10:
                descriptive_count += 1
        
        return {
            'total': total,
            'conventional_count': conventional_count,
            'issue_ref_count': issue_ref_count,
            'descriptive_count': descriptive_count,
            'poor_messages': poor_messages
        }
    
    def _is_conventional_commit(self, message: str) -> bool:
        """Check if commit follows conventional commit format"""
        # Pattern: type(scope): description
        pattern = r'^(' + '|'.join(self.CONVENTIONAL_TYPES) + r')(\(.+\))?: .+'
        return bool(re.match(pattern, message.strip()))
    
    def _has_issue_reference(self, message: str) -> bool:
        """Check if commit message references an issue"""
        # Patterns: #123, JIRA-123, GH-123, fixes #123, closes #123
        patterns = [
            r'#\d+',
            r'[A-Z]+-\d+',
            r'GH-\d+',
            r'(fixes|closes|resolves|refs?)\s+#?\d+',
        ]
        return any(re.search(pattern, message, re.IGNORECASE) for pattern in patterns)
    
    def _is_poor_message(self, message: str) -> bool:
        """Check if commit message is poor quality"""
        first_line = message.split('\n')[0].strip()
        
        # Check against poor patterns
        for pattern in self.POOR_MESSAGE_PATTERNS:
            if re.match(pattern, first_line, re.IGNORECASE):
                return True
        
        # Too short (less than 5 characters)
        if len(first_line) < 5:
            return True
        
        return False
    
    def _score_commit_count(self, count: int, pr_data: Any) -> float:
        """
        Score based on commit count relative to PR size
        
        Args:
            count: Number of commits
            pr_data: PRData object
            
        Returns:
            Score from 0-100
        """
        total_changes = pr_data.additions + pr_data.deletions
        files_changed = pr_data.changed_files
        
        # Determine expected commit range based on PR size
        if total_changes < 5 and files_changed <= 2:
            # Small PR: 1-2 commits ideal
            if count <= 2:
                return 100
            elif count <= 5:
                return 80
            else:
                return 60
        elif total_changes < 10 and files_changed <= 5:
            # Medium PR: up to 5 commits
            if count <= 5:
                return 100
            elif count <= 8:
                return 85
            else:
                return 70
        elif total_changes <= 50 and files_changed <= 10:
            # Complex PR: up to 10 commits
            if count <= 10:
                return 100
            elif count <= 15:
                return 85
            else:
                return 70
        else:
            # Very complex PR: more commits acceptable
            if count <= 15:
                return 100
            elif count <= 25:
                return 90
            else:
                return 75
    
    def _score_message_quality(self, message_quality: Dict[str, Any]) -> float:
        """
        Score commit message quality
        
        Args:
            message_quality: Message quality metrics
            
        Returns:
            Score from 0-100
        """
        total = message_quality['total']
        if total == 0:
            return 50
        
        # Calculate percentages
        conventional_pct = message_quality['conventional_count'] / total
        issue_ref_pct = message_quality['issue_ref_count'] / total
        descriptive_pct = message_quality['descriptive_count'] / total
        poor_pct = len(message_quality['poor_messages']) / total
        
        # Scoring weights
        score = 50  # Base score
        
        # Bonus for conventional commits
        score += conventional_pct * 20
        
        # Bonus for issue references
        score += issue_ref_pct * 15
        
        # Bonus for descriptive messages
        score += descriptive_pct * 15
        
        # Penalty for poor messages
        score -= poor_pct * 30
        
        return max(0, min(100, score))
    
    def _get_recommendation(self, count: int, message_quality: Optional[Dict[str, Any]]) -> str:
        """Generate recommendation based on analysis"""
        recommendations = []
        
        if count > 20:
            recommendations.append("Consider squashing some commits for cleaner history")
        elif count == 1 and message_quality and message_quality['total'] == 1:
            recommendations.append("Single commit is good for small changes")
        
        if message_quality:
            if message_quality['conventional_count'] == 0:
                recommendations.append("Use conventional commit format (feat:, fix:, etc.)")
            
            if message_quality['issue_ref_count'] == 0:
                recommendations.append("Reference issues/tickets in commit messages")
            
            if message_quality['poor_messages']:
                recommendations.append("Improve commit message quality - avoid generic messages")
        
        if not recommendations:
            return "Commit quality looks good!"
        
        return " | ".join(recommendations)
