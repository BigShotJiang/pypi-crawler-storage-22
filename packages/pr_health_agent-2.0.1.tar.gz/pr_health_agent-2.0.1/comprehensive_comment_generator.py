"""
Comprehensive Comment Generator
Generates formatted PR comments with all 13 scoring categories
"""

from typing import Dict, Any, List


class ComprehensiveCommentGenerator:
    """Generates comprehensive PR review comments with 13 categories"""
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize comment generator"""
        self.config = config
        self.thresholds = config.get('thresholds', {'min_passing_score': 70, 'excellent_score': 90})
    
    def generate_comprehensive_report(
        self,
        pr_data: Any,
        score_breakdown: Any,
        complexity_analysis: Dict = None,
        impact_analysis: Dict = None,
        ai_comments: List[str] = None,
        dependency_changes: Dict = None
    ) -> str:
        """
        Generate complete comprehensive health report with all 13 categories
        
        Returns:
            Formatted markdown comment
        """
        sections = []
        
        # Header
        sections.append(self._generate_header(score_breakdown))
        
        # Part A: PR Review Criteria (70 points)
        sections.append("\n## 📋 Part A: PR Review Criteria ({:.1f}/70)\n".format(score_breakdown.pr_review_score))
        
        # 1. PR Structure & Quality (25 points)
        sections.append("### 1️⃣ PR Structure & Quality ({:.1f}/25)\n".format(
            score_breakdown.size_score + score_breakdown.test_quality_score + 
            score_breakdown.commit_quality_score + score_breakdown.review_quality_score
        ))
        
        sections.append(self._generate_size_section(score_breakdown))
        sections.append(self._generate_test_quality_section(score_breakdown))
        sections.append(self._generate_commit_quality_section(score_breakdown))
        sections.append(self._generate_review_quality_section(score_breakdown, pr_data))
        
        # 2. Code Standards (25 points)
        sections.append("\n### 2️⃣ Code Standards & Quality ({:.1f}/25)\n".format(
            score_breakdown.security_score + score_breakdown.code_quality_score + 
            score_breakdown.code_style_score + score_breakdown.dependency_score
        ))
        
        sections.append(self._generate_security_section(score_breakdown))
        sections.append(self._generate_code_quality_section(score_breakdown))
        sections.append(self._generate_code_style_section(score_breakdown))
        sections.append(self._generate_dependency_section(score_breakdown, dependency_changes))
        
        # 3. Documentation (20 points)
        sections.append("\n### 3️⃣ Documentation & Standards ({:.1f}/20)\n".format(
            score_breakdown.changelog_score + score_breakdown.codeowners_score + 
            score_breakdown.breaking_changes_score + score_breakdown.documentation_score
        ))
        
        sections.append(self._generate_changelog_section(score_breakdown))
        sections.append(self._generate_codeowners_section(score_breakdown))
        sections.append(self._generate_breaking_changes_section(score_breakdown))
        sections.append(self._generate_documentation_section(score_breakdown))
        
        # Part B: Impact Analysis (30 points)
        sections.append("\n## 🎯 Part B: Impact Analysis ({:.1f}/30)\n".format(score_breakdown.impact_analysis_score))
        
        sections.append(self._generate_complexity_section(score_breakdown, complexity_analysis))
        sections.append(self._generate_impact_scope_section(score_breakdown, impact_analysis))
        sections.append(self._generate_performance_section(score_breakdown))
        
        # AI Comments
        if ai_comments:
            sections.append(self._generate_ai_comments_section(ai_comments))
        
        # Recommendations
        sections.append(self._generate_recommendations_section(score_breakdown, dependency_changes))
        
        # Summary
        sections.append(self._generate_summary_section(score_breakdown))
        
        # Footer
        sections.append(self._generate_footer(score_breakdown))
        
        return '\n'.join(sections)
    
    def _generate_header(self, score_breakdown: Any) -> str:
        """Generate header with overall score"""
        score = score_breakdown.total_score
        
        if score >= 90:
            emoji = '🌟'
            status = 'excellent'
        elif score >= 70:
            emoji = '✅'
            status = 'good'
        elif score >= 50:
            emoji = '⚠️'
            status = 'needs improvement'
        else:
            emoji = '❌'
            status = 'poor'
        
        header = f"""## 🤖 PR Health Score Analysis

**Overall Score: {score:.1f}/100** {emoji}

📊 **Breakdown:**
- **PR Review Criteria**: {score_breakdown.pr_review_score:.1f}/70
- **Impact Analysis**: {score_breakdown.impact_analysis_score:.1f}/30

**Category**: {status.upper()}
"""
        
        if score_breakdown.missing_data:
            header += f"\n⚠️  **Missing Data**: {', '.join(score_breakdown.missing_data)}\n"
        
        return header
    
    def _generate_size_section(self, sb: Any) -> str:
        """Size analysis (5 points)"""
        details = sb.size_details
        return f"""
**📏 Size ({sb.size_score:.1f}/5)**
- Category: {details.get('category', 'N/A')}
- Lines: +{details.get('additions', 0)} / -{details.get('deletions', 0)}
- Files: {details.get('files_count', 0)}
- Commits: {details.get('commits', 0)}
{f"- ℹ️  {details.get('recommendation', '')}" if details.get('recommendation') else ''}
"""
    
    def _generate_test_quality_section(self, sb: Any) -> str:
        """Test quality (10 points)"""
        details = sb.test_quality_details
        coverage = details.get('coverage_percent', 0)
        return f"""
**🧪 Test Quality ({sb.test_quality_score:.1f}/10)**
- Coverage: {coverage:.1f}%
- Test Files: {details.get('test_files', 0)}/{details.get('total_files', 0)}
- Delta: {details.get('coverage_delta', 'N/A')}
{f"- ⚠️  {details.get('recommendation', '')}" if details.get('recommendation') else ''}
"""
    
    def _generate_commit_quality_section(self, sb: Any) -> str:
        """Commit quality (5 points)"""
        details = sb.commit_quality_details
        return f"""
**📝 Commit Quality ({sb.commit_quality_score:.1f}/5)**
- Total Commits: {details.get('total_commits', 0)}
- Conventional: {'Yes' if details.get('has_conventional') else 'No'}
- Issue Refs: {'Yes' if details.get('has_issue_refs') else 'No'}
{f"- ℹ️  {details.get('recommendation', '')}" if details.get('recommendation') else ''}
"""
    
    def _generate_review_quality_section(self, sb: Any, pr_data: Any) -> str:
        """Review quality (5 points)"""
        return f"""
**👀 Review Quality ({sb.review_quality_score:.1f}/5)**
- Reviewers: {pr_data.reviewers.__len__() if hasattr(pr_data.reviewers, '__len__') else len(pr_data.reviewers) if pr_data.reviewers else 0}
- Approvals: {pr_data.approvals}
- Comments: {len(pr_data.review_comments) if pr_data.review_comments else 0}
"""
    
    def _generate_security_section(self, sb: Any) -> str:
        """Security (10 points)"""
        details = sb.security_details
        
        section = f"""
**🔒 Security ({sb.security_score:.1f}/10)**
"""
        
        if 'secret_scanning' in details:
            secret_info = details['secret_scanning']['details']
            critical = secret_info.get('critical_count', 0)
            high = secret_info.get('high_count', 0)
            
            if critical > 0:
                section += f"- 🚨 Secrets: {critical} critical detected\n"
            elif high > 0:
                section += f"- ⚠️  Secrets: {high} high-risk patterns\n"
            else:
                section += "- ✅ Secrets: No hardcoded secrets\n"
        
        if 'dependency_scanning' in details:
            dep_info = details['dependency_scanning']['details']
            critical_vulns = dep_info.get('critical_vulns', 0)
            high_vulns = dep_info.get('high_vulns', 0)
            
            if critical_vulns > 0:
                section += f"- 🚨 Dependencies: {critical_vulns} critical vulnerabilities\n"
            elif high_vulns > 0:
                section += f"- ⚠️  Dependencies: {high_vulns} high-severity vulnerabilities\n"
            else:
                section += "- ✅ Dependencies: No known vulnerabilities\n"
        
        if details.get('recommendation'):
            section += f"\n{details['recommendation']}\n"
        
        return section
    
    def _generate_code_quality_section(self, sb: Any) -> str:
        """Code quality (8 points)"""
        details = sb.code_quality_details
        return f"""
**🎯 Code Quality ({sb.code_quality_score:.1f}/8)**
- Complexity Issues: {details.get('complexity_issues', 0)}
- Duplications: {details.get('duplications', 0)}
- Long Functions: {details.get('long_functions', 0)}
"""
    
    def _generate_code_style_section(self, sb: Any) -> str:
        """Code style (3 points)"""
        details = sb.code_style_details
        return f"""
**✨ Code Style ({sb.code_style_score:.1f}/3)**
- Status: {details.get('status', 'Not analyzed')}
{f"- Linting Errors: {details.get('linting_errors', 0)}" if 'linting_errors' in details else ''}
"""
    
    def _generate_dependency_section(self, sb: Any, dep_changes: Dict = None) -> str:
        """Dependencies (4 points)"""
        details = sb.dependency_details
        
        section = f"""
**📦 Dependencies ({sb.dependency_score:.1f}/4)**
"""
        
        if dep_changes and dep_changes.get('has_dependency_changes'):
            section += f"- Modified Files: {len(dep_changes['modified_files'])}\n"
            section += f"- Ecosystems: {', '.join(dep_changes.get('ecosystems_affected', []))}\n"
            section += f"- {dep_changes.get('recommendation', '')}\n"
        else:
            section += f"- Status: {details.get('message', 'No dependency changes')}\n"
        
        return section
    
    def _generate_changelog_section(self, sb: Any) -> str:
        """CHANGELOG (5 points)"""
        details = sb.changelog_details
        return f"""
**📄 CHANGELOG ({sb.changelog_score:.1f}/5)**
- Status: {details.get('status', 'Not found')}
{f"- Updated: {'Yes' if details.get('updated') else 'No'}" if 'updated' in details else ''}
{f"- ⚠️  {details.get('recommendation', '')}" if details.get('recommendation') else ''}
"""
    
    def _generate_codeowners_section(self, sb: Any) -> str:
        """CODEOWNERS (3 points)"""
        details = sb.codeowners_details
        return f"""
**👥 CODEOWNERS ({sb.codeowners_score:.1f}/3)**
- Coverage: {details.get('coverage_percent', 0):.0f}%
{f"- Uncovered Files: {details.get('uncovered_files', 0)}" if 'uncovered_files' in details else ''}
"""
    
    def _generate_breaking_changes_section(self, sb: Any) -> str:
        """Breaking Changes (5 points)"""
        details = sb.breaking_changes_details
        return f"""
**⚠️  Breaking Changes ({sb.breaking_changes_score:.1f}/5)**
- Detected: {details.get('breaking_changes_count', 0)}
- Documented: {'Yes' if details.get('documented') else 'No'}
{f"- Migration Guide: {'Yes' if details.get('has_migration_guide') else 'No'}" if 'has_migration_guide' in details else ''}
"""
    
    def _generate_documentation_section(self, sb: Any) -> str:
        """Documentation (7 points)"""
        details = sb.documentation_details
        return f"""
**📚 Documentation ({sb.documentation_score:.1f}/7)**
- Title: {details.get('title_length', 0)} chars
- Description: {details.get('description_length', 0)} chars
- Has Context: {'✅' if details.get('has_context') else '❌'}
- Has Changes: {'✅' if details.get('has_changes') else '❌'}
- Has Testing: {'✅' if details.get('has_testing') else '❌'}
"""
    
    def _generate_complexity_section(self, sb: Any, ai_analysis: Dict = None) -> str:
        """Complexity (10 points)"""
        section = f"""
**🔍 Complexity ({sb.complexity_score:.1f}/10)**
"""
        
        if ai_analysis:
            section += f"- Level: {ai_analysis.get('complexity_level', 'N/A').title()}\n"
            section += f"- Assessment: {ai_analysis.get('assessment', 'No analysis')}\n"
        else:
            details = sb.complexity_details
            section += f"- Assessment: {details.get('assessment', 'Not analyzed')}\n"
        
        return section
    
    def _generate_impact_scope_section(self, sb: Any, ai_analysis: Dict = None) -> str:
        """Impact Scope (10 points)"""
        section = f"""
**🎯 Impact Scope ({sb.impact_score:.1f}/10)**
"""
        
        if ai_analysis:
            section += f"- Level: {ai_analysis.get('impact_level', 'N/A').title()}\n"
            affected = ai_analysis.get('affected_areas', [])
            if affected:
                section += f"- Affected Areas: {', '.join(affected[:3])}\n"
        else:
            details = sb.impact_details
            section += f"- Status: {details.get('message', 'Not analyzed')}\n"
        
        return section
    
    def _generate_performance_section(self, sb: Any) -> str:
        """Performance (10 points)"""
        details = sb.performance_details
        return f"""
**⚡ Performance ({sb.performance_score:.1f}/10)**
- Status: {details.get('message', 'Not analyzed')}
{f"- Impact: {details.get('impact', '')}" if 'impact' in details else ''}
"""
    
    def _generate_ai_comments_section(self, ai_comments: List[str]) -> str:
        """AI recommendations"""
        section = "\n## 🤖 AI-Powered Recommendations\n\n"
        for i, comment in enumerate(ai_comments, 1):
            section += f"{i}. {comment}\n"
        return section
    def _generate_recommendations_section(self, sb: Any, dependency_changes: Dict = None) -> str:
        """Generate actionable recommendations with score improvement potential"""
        recommendations = []
        
        # Calculate potential gains for each category (max - current)
        # Prioritize by impact (points that can be gained)
        
        # Size (5 points max)
        size_gain = 5 - sb.size_score
        if size_gain > 1:
            size_details = sb.size_details or {}
            lines = size_details.get('total_lines_changed', 0)
            if lines > 1000:
                recommendations.append(("Size", f"This PR is very large ({lines} lines). Strongly recommend splitting into multiple smaller PRs.", size_gain))
            elif lines > 500:
                recommendations.append(("Size", f"Consider splitting this PR ({lines} lines) into smaller, focused changes.", size_gain))
        
        # Test Quality (10 points max)
        test_gain = 10 - sb.test_quality_score
        if test_gain > 2:
            test_details = sb.test_quality_details or {}
            coverage = test_details.get('coverage_percentage', 0)
            test_files = test_details.get('test_files_count', 0)
            total_files = test_details.get('total_files', 1)
            if test_files == 0:
                recommendations.append(("Testing", f"Add test coverage. Currently {test_files}/{total_files} files are tests.", test_gain))
            elif coverage < 80:
                recommendations.append(("Testing", f"Improve test coverage from {coverage}% to at least 80%.", test_gain))
        
        # Commit Quality (5 points max)
        commit_gain = 5 - sb.commit_quality_score
        if commit_gain > 1:
            commit_details = sb.commit_quality_details or {}
            suggestions = []
            if not commit_details.get('uses_conventional', False):
                suggestions.append("Use conventional commit format (feat:, fix:, etc.)")
            if not commit_details.get('has_issue_references', False):
                suggestions.append("Reference issues/tickets in commit messages")
            if suggestions:
                recommendations.append(("Commits", " | ".join(suggestions), commit_gain))
        
        # Review Quality (5 points max)
        review_gain = 5 - sb.review_quality_score
        if review_gain > 1:
            review_details = sb.review_quality_details or {}
            reviewers = review_details.get('reviewers_count', 0)
            approvals = review_details.get('approvals_count', 0)
            comments = review_details.get('review_comments_count', 0)
            suggestions = []
            if reviewers < 2:
                suggestions.append("This PR needs more reviewers")
            if approvals == 0:
                suggestions.append("Needs approval")
            if comments < 3:
                suggestions.append("Could benefit from more review feedback")
            if suggestions:
                recommendations.append(("Review", ", ".join(suggestions) + ".", review_gain))
        
        # Security (10 points max)
        security_gain = 10 - sb.security_score
        if security_gain > 2:
            security_details = sb.security_details or {}
            if security_details.get('secrets_count', 0) > 0:
                recommendations.append(("Security", "Remove hardcoded secrets/credentials from code.", security_gain))
            elif security_details.get('vulnerable_dependencies', 0) > 0:
                recommendations.append(("Security", f"Fix {security_details.get('vulnerable_dependencies', 0)} vulnerable dependencies.", security_gain))
        
        # Code Quality (8 points max)
        quality_gain = 8 - sb.code_quality_score
        if quality_gain > 2:
            quality_details = sb.code_quality_details or {}
            suggestions = []
            if quality_details.get('complex_files', 0) > 0:
                suggestions.append(f"Reduce complexity in {quality_details.get('complex_files', 0)} files")
            if quality_details.get('long_functions', 0) > 0:
                suggestions.append(f"Refactor {quality_details.get('long_functions', 0)} long functions")
            if suggestions:
                recommendations.append(("Code Quality", " | ".join(suggestions), quality_gain))
        
        # Code Style (3 points max)
        style_gain = 3 - sb.code_style_score
        if style_gain > 0.5:
            recommendations.append(("Code Style", "Run linter and fix style violations.", style_gain))
        
        # Dependencies (4 points max)
        dep_gain = 4 - sb.dependency_score
        if dep_gain > 1 and dependency_changes:
            vuln_count = dependency_changes.get('vulnerability_summary', {}).get('total', 0)
            if vuln_count > 0:
                recommendations.append(("Dependencies", f"Update {vuln_count} vulnerable dependencies to secure versions.", dep_gain))
        
        # CHANGELOG (5 points max)
        changelog_gain = 5 - sb.changelog_score
        if changelog_gain > 2:
            changelog_details = sb.changelog_details or {}
            if not changelog_details.get('changelog_exists', False):
                recommendations.append(("CHANGELOG", "Create CHANGELOG.md to track changes.", changelog_gain))
            elif not changelog_details.get('changelog_updated', False):
                recommendations.append(("CHANGELOG", "Update CHANGELOG.md with this PR's changes.", changelog_gain))
        
        # CODEOWNERS (3 points max)
        codeowners_gain = 3 - sb.codeowners_score
        if codeowners_gain > 0.5:
            codeowners_details = sb.codeowners_details or {}
            coverage = codeowners_details.get('coverage_percentage', 0)
            if coverage == 0:
                recommendations.append(("CODEOWNERS", "Create CODEOWNERS file to define code ownership.", codeowners_gain))
            elif coverage < 80:
                recommendations.append(("CODEOWNERS", f"Improve CODEOWNERS coverage from {coverage}% to at least 80%.", codeowners_gain))
        
        # Breaking Changes (5 points max)
        breaking_gain = 5 - sb.breaking_changes_score
        if breaking_gain > 2:
            breaking_details = sb.breaking_changes_details or {}
            breaking_count = breaking_details.get('breaking_changes_count', 0)
            if breaking_count > 0:
                suggestions = []
                if not breaking_details.get('documented', False):
                    suggestions.append("Document all breaking changes")
                if not breaking_details.get('has_migration_guide', False):
                    suggestions.append("Add migration guide for affected users")
                if suggestions:
                    recommendations.append(("Breaking Changes", " | ".join(suggestions), breaking_gain))
        
        # Documentation (7 points max)
        doc_gain = 7 - sb.documentation_score
        if doc_gain > 2:
            doc_details = sb.documentation_details or {}
            suggestions = []
            if doc_details.get('title_length', 0) < 10:
                suggestions.append("Improve PR title clarity")
            if doc_details.get('description_length', 0) < 50:
                suggestions.append("Missing context/reason")
            if doc_details.get('description_length', 0) < 100:
                suggestions.append("Missing change description")
            if not doc_details.get('has_testing_info', False):
                suggestions.append("Add testing instructions")
            if suggestions:
                recommendations.append(("Documentation", "Improve PR description: " + ", ".join(suggestions), doc_gain))
        
        # Impact Analysis categories (AI-powered - harder to improve)
        # Complexity (10 points max)
        complexity_gain = 10 - sb.complexity_score
        if complexity_gain > 3:
            recommendations.append(("Complexity", "Simplify code changes to reduce cognitive load.", complexity_gain))
        
        # Sort by potential gain (highest first)
        recommendations.sort(key=lambda x: x[2], reverse=True)
        
        if not recommendations:
            return "\n## 💡 Recommendations\n\nExcellent work! No significant improvements needed.\n"
        
        output = "\n## 💡 Recommendations - Score Improvement Opportunities\n\n"
        for category, suggestion, gain in recommendations:
            output += f"- **{category}**: {suggestion} **(+{gain:.1f} points)**\n"
        
        return output + "\n"
    
    def _generate_summary_section(self, sb: Any) -> str:
        """Generate summary with top issues"""
        issues = []
        
        if sb.security_score < 70:
            issues.append("🚨 **Security**: Critical security issues detected")
        if sb.test_quality_score < 60:
            issues.append("⚠️  **Testing**: Insufficient test coverage")
        if sb.breaking_changes_score < 30 and sb.breaking_changes_details.get('breaking_changes_count', 0) > 0:
            issues.append("⚠️  **Breaking Changes**: Not properly documented")
        if sb.dependency_score < 50:
            issues.append("⚠️  **Dependencies**: Vulnerable dependencies detected")
        
        if not issues:
            return "\n## ✅ Summary\n\nNo critical issues detected. Good job!\n"
        
        return "\n## ⚠️  Summary - Action Required\n\n" + '\n'.join(issues) + "\n"
    
    def _generate_footer(self, sb: Any) -> str:
        """Generate footer with merge decision"""
        score = sb.total_score
        
        if score >= 70:
            return "\n---\n✅ **Merge Recommended** - Score meets minimum threshold\n"
        else:
            return f"\n---\n🚫 **Merge Blocked** - Score below minimum threshold (70)\n"
    
    def generate_quick_summary(self, score_breakdown: Any) -> str:
        """Generate quick text summary for console output"""
        sb = score_breakdown
        
        summary = f"""
📊 COMPREHENSIVE ANALYSIS COMPLETE
======================================================================
Overall Score: {sb.total_score:.1f}/100

PR Review Criteria: {sb.pr_review_score:.1f}/70
  - PR Structure: {sb.size_score + sb.test_quality_score + sb.commit_quality_score + sb.review_quality_score:.1f}/25
  - Code Standards: {sb.security_score + sb.code_quality_score + sb.code_style_score + sb.dependency_score:.1f}/25
  - Documentation: {sb.changelog_score + sb.codeowners_score + sb.breaking_changes_score + sb.documentation_score:.1f}/20

Impact Analysis: {sb.impact_analysis_score:.1f}/30
  - Complexity: {sb.complexity_score:.1f}/10
  - Impact Scope: {sb.impact_score:.1f}/10
  - Performance: {sb.performance_score:.1f}/10

Category: {sb.category.upper()}
{"Missing Data: " + ", ".join(sb.missing_data) if sb.missing_data else "All data collected"}
======================================================================
"""
        return summary
