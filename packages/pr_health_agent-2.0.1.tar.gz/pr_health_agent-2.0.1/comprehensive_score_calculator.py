"""
Comprehensive PR Score Calculator (v2.0)
Includes enhanced scoring with 13 categories across PR Review and Impact Analysis
"""

from typing import Dict, Any, Optional
from dataclasses import dataclass, field


@dataclass
class ComprehensiveScoreBreakdown:
    """Complete score breakdown with all categories"""
    
    # PR REVIEW CRITERIA (70 points)
    # 1. PR Structure & Quality (25 points)
    size_score: float = 0
    size_details: Dict[str, Any] = field(default_factory=dict)
    
    test_quality_score: float = 0
    test_quality_details: Dict[str, Any] = field(default_factory=dict)
    
    commit_quality_score: float = 0
    commit_quality_details: Dict[str, Any] = field(default_factory=dict)
    
    review_quality_score: float = 0
    review_quality_details: Dict[str, Any] = field(default_factory=dict)
    
    # 2. Code Quality & Standards (25 points)
    security_score: float = 0
    security_details: Dict[str, Any] = field(default_factory=dict)
    
    code_quality_score: float = 0
    code_quality_details: Dict[str, Any] = field(default_factory=dict)
    
    code_style_score: float = 0
    code_style_details: Dict[str, Any] = field(default_factory=dict)
    
    dependency_score: float = 0
    dependency_details: Dict[str, Any] = field(default_factory=dict)
    
    # 3. Documentation & Standards (20 points)
    changelog_score: float = 0
    changelog_details: Dict[str, Any] = field(default_factory=dict)
    
    codeowners_score: float = 0
    codeowners_details: Dict[str, Any] = field(default_factory=dict)
    
    breaking_changes_score: float = 0
    breaking_changes_details: Dict[str, Any] = field(default_factory=dict)
    
    documentation_score: float = 0
    documentation_details: Dict[str, Any] = field(default_factory=dict)
    
    # IMPACT ANALYSIS (30 points)
    complexity_score: float = 0
    complexity_details: Dict[str, Any] = field(default_factory=dict)
    
    impact_score: float = 0
    impact_details: Dict[str, Any] = field(default_factory=dict)
    
    performance_score: float = 0
    performance_details: Dict[str, Any] = field(default_factory=dict)
    
    # Totals
    pr_review_score: float = 0  # Out of 70
    impact_analysis_score: float = 0  # Out of 30
    total_score: float = 0  # Out of 100
    category: str = ''
    
    # Data availability tracking
    missing_data: list = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'total_score': self.total_score,
            'pr_review_score': self.pr_review_score,
            'impact_analysis_score': self.impact_analysis_score,
            'category': self.category,
            'missing_data': self.missing_data,
            'breakdown': {
                'pr_structure': {
                    'size': {'score': self.size_score, 'max': 5, 'details': self.size_details},
                    'test_quality': {'score': self.test_quality_score, 'max': 10, 'details': self.test_quality_details},
                    'commit_quality': {'score': self.commit_quality_score, 'max': 5, 'details': self.commit_quality_details},
                    'review_quality': {'score': self.review_quality_score, 'max': 5, 'details': self.review_quality_details},
                },
                'code_standards': {
                    'security': {'score': self.security_score, 'max': 10, 'details': self.security_details},
                    'code_quality': {'score': self.code_quality_score, 'max': 8, 'details': self.code_quality_details},
                    'code_style': {'score': self.code_style_score, 'max': 3, 'details': self.code_style_details},
                    'dependencies': {'score': self.dependency_score, 'max': 4, 'details': self.dependency_details},
                },
                'documentation': {
                    'changelog': {'score': self.changelog_score, 'max': 5, 'details': self.changelog_details},
                    'codeowners': {'score': self.codeowners_score, 'max': 3, 'details': self.codeowners_details},
                    'breaking_changes': {'score': self.breaking_changes_score, 'max': 5, 'details': self.breaking_changes_details},
                    'docs_quality': {'score': self.documentation_score, 'max': 7, 'details': self.documentation_details},
                },
                'impact_analysis': {
                    'complexity': {'score': self.complexity_score, 'max': 10, 'details': self.complexity_details},
                    'impact_scope': {'score': self.impact_score, 'max': 10, 'details': self.impact_details},
                    'performance': {'score': self.performance_score, 'max': 10, 'details': self.performance_details},
                }
            }
        }


class ComprehensiveScoreCalculator:
    """
    Comprehensive PR Score Calculator
    
    Scoring Structure (100 points total):
    
    Part A: PR Review Criteria (70 points)
    ├── PR Structure & Quality (25 points)
    │   ├── Size (5): Multi-factor size analysis
    │   ├── Test Quality (10): Coverage + delta
    │   ├── Commit Quality (5): Conventional commits + practices
    │   └── Review Quality (5): Reviewers + approvals
    ├── Code Quality & Standards (25 points)
    │   ├── Security (10): Vulnerabilities + best practices
    │   ├── Code Quality (8): Complexity + duplication + length
    │   ├── Code Style (3): Linting + formatting
    │   └── Dependencies (4): License + health
    └── Documentation & Standards (20 points)
        ├── CHANGELOG (5): Updates + format
        ├── CODEOWNERS (3): Coverage
        ├── Breaking Changes (5): Detection + documentation
        └── Documentation (7): README + inline + API docs
    
    Part B: Impact Analysis (30 points)
    ├── Complexity (10): AI-analyzed architectural complexity
    ├── Impact Scope (10): Business + technical reach
    └── Performance (10): Execution + resources + database
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        
        # Import analyzers
        from enhanced_size_analyzer import EnhancedSizeAnalyzer
        from changelog_analyzer import ChangelogAnalyzer
        from codeowners_analyzer import CodeownersAnalyzer
        from breaking_changes_analyzer import BreakingChangesAnalyzer
        
        self.size_analyzer = EnhancedSizeAnalyzer(config)
        self.changelog_analyzer = ChangelogAnalyzer(config)
        self.codeowners_analyzer = CodeownersAnalyzer(config)
        self.breaking_analyzer = BreakingChangesAnalyzer(config)
    
    def calculate_comprehensive_score(
        self,
        pr_data: Any,
        # PR Review inputs
        security_report: Optional[Dict[str, Any]] = None,
        coverage_report: Optional[Dict[str, Any]] = None,
        commit_report: Optional[Dict[str, Any]] = None,
        quality_report: Optional[Dict[str, Any]] = None,
        style_report: Optional[Dict[str, Any]] = None,
        # Impact Analysis inputs
        complexity_analysis: Optional[Dict[str, Any]] = None,
        impact_analysis: Optional[Dict[str, Any]] = None,
        performance_analysis: Optional[Dict[str, Any]] = None,
        # Additional data
        codeowners_content: Optional[str] = None
    ) -> ComprehensiveScoreBreakdown:
        """
        Calculate comprehensive health score with all 13 categories
        
        Returns:
            ComprehensiveScoreBreakdown with detailed scoring
        """
        breakdown = ComprehensiveScoreBreakdown()
        missing_data = []
        
        # ============================================
        # PART A: PR REVIEW CRITERIA (70 points)
        # ============================================
        
        # 1. PR STRUCTURE & QUALITY (25 points)
        
        # Size Score (5 points) - Enhanced multi-factor
        size_result = self.size_analyzer.analyze(pr_data)
        breakdown.size_score = self._normalize_score(size_result['score'], 5, 100)
        breakdown.size_details = size_result
        if not size_result.get('data_available', True):
            missing_data.append('size_analysis')
        
        # Test Quality Score (10 points)
        test_result = self._calculate_test_quality(coverage_report, pr_data)
        breakdown.test_quality_score = self._normalize_score(test_result['score'], 10, 100)
        breakdown.test_quality_details = test_result
        if not test_result.get('data_available', True):
            missing_data.append('test_coverage')
        
        # Commit Quality Score (5 points)
        commit_result = self._calculate_commit_quality(commit_report, pr_data)
        breakdown.commit_quality_score = self._normalize_score(commit_result['score'], 5, 100)
        breakdown.commit_quality_details = commit_result
        if not commit_result.get('data_available', True):
            missing_data.append('commit_analysis')
        
        # Review Quality Score (5 points)
        review_result = self._calculate_review_quality(pr_data)
        breakdown.review_quality_score = self._normalize_score(review_result['score'], 5, 100)
        breakdown.review_quality_details = review_result
        
        # 2. CODE QUALITY & STANDARDS (25 points)
        
        # Security Score (10 points)
        security_result = self._calculate_security_score(security_report)
        breakdown.security_score = self._normalize_score(security_result['score'], 10, 100)
        breakdown.security_details = security_result
        if not security_result.get('data_available', True):
            missing_data.append('security_scan')
        
        # Code Quality Score (8 points)
        code_quality_result = self._calculate_code_quality(quality_report)
        breakdown.code_quality_score = self._normalize_score(code_quality_result['score'], 8, 100)
        breakdown.code_quality_details = code_quality_result
        if not code_quality_result.get('data_available', True):
            missing_data.append('code_quality_analysis')
        
        # Code Style Score (3 points)
        style_result = self._calculate_code_style(style_report)
        breakdown.code_style_score = self._normalize_score(style_result['score'], 3, 100)
        breakdown.code_style_details = style_result
        if not style_result.get('data_available', True):
            missing_data.append('style_check')
        
        # Dependency Score (4 points)
        dependency_result = self._calculate_dependency_score(pr_data)
        breakdown.dependency_score = self._normalize_score(dependency_result['score'], 4, 100)
        breakdown.dependency_details = dependency_result
        if not dependency_result.get('data_available', True):
            missing_data.append('dependency_check')
        
        # 3. DOCUMENTATION & STANDARDS (20 points)
        
        # CHANGELOG Score (5 points)
        changelog_result = self.changelog_analyzer.analyze(pr_data)
        breakdown.changelog_score = changelog_result['score']
        breakdown.changelog_details = changelog_result
        if not changelog_result.get('data_available', True):
            missing_data.append('changelog')
        
        # CODEOWNERS Score (3 points)
        codeowners_result = self.codeowners_analyzer.analyze(pr_data, codeowners_content)
        breakdown.codeowners_score = codeowners_result['score']
        breakdown.codeowners_details = codeowners_result
        if not codeowners_result.get('data_available', True):
            missing_data.append('codeowners')
        
        # Breaking Changes Score (5 points)
        breaking_result = self.breaking_analyzer.analyze(pr_data)
        breakdown.breaking_changes_score = breaking_result['score']
        breakdown.breaking_changes_details = breaking_result
        if not breaking_result.get('data_available', True):
            missing_data.append('breaking_changes')
        
        # Documentation Score (7 points)
        docs_result = self._calculate_documentation_score(pr_data)
        breakdown.documentation_score = self._normalize_score(docs_result['score'], 7, 100)
        breakdown.documentation_details = docs_result
        if not docs_result.get('data_available', True):
            missing_data.append('documentation')
        
        # ============================================
        # PART B: IMPACT ANALYSIS (30 points)
        # ============================================
        
        # Complexity Score (10 points) - AI-powered
        complexity_result = self._calculate_complexity_impact(complexity_analysis, pr_data)
        breakdown.complexity_score = complexity_result['score']
        breakdown.complexity_details = complexity_result
        if not complexity_result.get('data_available', True):
            missing_data.append('complexity_analysis')
        
        # Impact Scope Score (10 points) - AI-powered
        impact_result = self._calculate_impact_scope(impact_analysis, pr_data)
        breakdown.impact_score = impact_result['score']
        breakdown.impact_details = impact_result
        if not impact_result.get('data_available', True):
            missing_data.append('impact_analysis')
        
        # Performance Score (10 points) - AI-powered
        perf_result = self._calculate_performance_impact(performance_analysis, pr_data)
        breakdown.performance_score = perf_result['score']
        breakdown.performance_details = perf_result
        if not perf_result.get('data_available', True):
            missing_data.append('performance_analysis')
        
        # ============================================
        # CALCULATE TOTALS
        # ============================================
        
        # PR Review total (70 points)
        pr_review_total = (
            breakdown.size_score +
            breakdown.test_quality_score +
            breakdown.commit_quality_score +
            breakdown.review_quality_score +
            breakdown.security_score +
            breakdown.code_quality_score +
            breakdown.code_style_score +
            breakdown.dependency_score +
            breakdown.changelog_score +
            breakdown.codeowners_score +
            breakdown.breaking_changes_score +
            breakdown.documentation_score
        )
        
        # Impact Analysis total (30 points)
        impact_total = (
            breakdown.complexity_score +
            breakdown.impact_score +
            breakdown.performance_score
        )
        
        breakdown.pr_review_score = round(pr_review_total, 1)
        breakdown.impact_analysis_score = round(impact_total, 1)
        breakdown.total_score = round(pr_review_total + impact_total, 1)
        breakdown.category = self._get_category(breakdown.total_score)
        breakdown.missing_data = missing_data
        
        return breakdown
    
    def _normalize_score(self, score: float, max_points: float, original_max: float = 100) -> float:
        """Normalize score from original scale to target max points"""
        if original_max == 0:
            return 0
        normalized = (score / original_max) * max_points
        return round(min(normalized, max_points), 2)
    
    def _get_category(self, total_score: float) -> str:
        """Determine category based on total score"""
        if total_score >= 90:
            return 'excellent'
        elif total_score >= 80:
            return 'good'
        elif total_score >= 70:
            return 'needs_improvement'
        elif total_score >= 60:
            return 'poor'
        else:
            return 'blocked'
    
    # Individual scoring methods to be implemented
    # These are placeholder implementations - extend as needed
    
    def _calculate_test_quality(self, coverage_report, pr_data) -> Dict[str, Any]:
        """Calculate test quality score (10 points: 6 for coverage, 4 for delta)"""
        result = {
            'score': 50,  # Default neutral score
            'coverage_percent': 0,
            'coverage_delta': 0,
            'data_available': coverage_report is not None
        }
        
        if coverage_report:
            result['coverage_percent'] = coverage_report.get('coverage_percent', 0)
            result['coverage_delta'] = coverage_report.get('coverage_delta', 0)
            result['score'] = coverage_report.get('score', 50)
        
        return result
    
    def _calculate_commit_quality(self, commit_report, pr_data) -> Dict[str, Any]:
        """Calculate commit quality score (5 points)"""
        result = {
            'score': 50,
            'conventional_percent': 0,
            'data_available': commit_report is not None
        }
        
        if commit_report:
            result['score'] = commit_report.get('score', 50)
            result.update(commit_report)
        
        return result
    
    def _calculate_review_quality(self, pr_data) -> Dict[str, Any]:
        """Calculate review quality score (5 points)"""
        reviewers = len(pr_data.reviewers)
        approvals = pr_data.approvals
        comments = len(pr_data.review_comments)
        
        # Score based on engagement
        if reviewers >= 2 and approvals >= 2 and comments >= 5:
            score = 100
        elif reviewers >= 2 and approvals >= 1:
            score = 80
        elif reviewers >= 1 and approvals >= 1:
            score = 60
        elif reviewers >= 1:
            score = 40
        else:
            score = 0
        
        return {
            'score': score,
            'reviewers': reviewers,
            'approvals': approvals,
            'comments': comments,
            'data_available': True
        }
    
    def _calculate_security_score(self, security_report) -> Dict[str, Any]:
        """Calculate security score (10 points)"""
        result = {
            'score': 100,  # Default to passing
            'data_available': security_report is not None
        }
        
        if security_report:
            result['score'] = security_report.get('score', 100)
            result.update(security_report)
        
        return result
    
    def _calculate_code_quality(self, quality_report) -> Dict[str, Any]:
        """Calculate code quality score (8 points)"""
        result = {
            'score': 100,
            'data_available': quality_report is not None
        }
        
        if quality_report:
            result['score'] = quality_report.get('score', 100)
            result.update(quality_report)
        
        return result
    
    def _calculate_code_style(self, style_report) -> Dict[str, Any]:
        """Calculate code style score (3 points)"""
        result = {
            'score': 100,
            'data_available': style_report is not None
        }
        
        if style_report:
            result['score'] = style_report.get('score', 100)
            result.update(style_report)
        
        return result
    
    def _calculate_dependency_score(self, pr_data) -> Dict[str, Any]:
        """Calculate dependency score (4 points)"""
        # Placeholder - would check lock files, licenses, etc.
        return {
            'score': 100,
            'license_compliant': True,
            'dependencies_healthy': True,
            'data_available': False  # Not yet implemented
        }
    
    def _calculate_documentation_score(self, pr_data) -> Dict[str, Any]:
        """Calculate documentation score (7 points)"""
        # Check README, inline docs, API docs
        has_readme_update = any('README' in f.get('filename', '').upper() for f in pr_data.files)
        
        score = 50  # Baseline
        if has_readme_update:
            score += 25
        
        return {
            'score': score,
            'readme_updated': has_readme_update,
            'data_available': True
        }
    
    def _calculate_complexity_impact(self, complexity_analysis, pr_data) -> Dict[str, Any]:
        """Calculate complexity score (10 points) - AI-powered"""
        result = {
            'score': 5,  # Neutral default
            'complexity_level': 'moderate',
            'data_available': complexity_analysis is not None
        }
        
        if complexity_analysis:
            level = complexity_analysis.get('complexity_level', 'moderate').lower()
            
            if level in ['low', 'simple', 'straightforward']:
                result['score'] = 10
            elif level in ['moderate', 'medium']:
                result['score'] = 8
            elif level in ['high', 'complex']:
                result['score'] = 6
            elif level in ['very high', 'very complex']:
                result['score'] = 3
            else:
                result['score'] = 0
            
            result['complexity_level'] = level
            result.update(complexity_analysis)
        
        return result
    
    def _calculate_impact_scope(self, impact_analysis, pr_data) -> Dict[str, Any]:
        """Calculate impact scope score (10 points) - AI-powered"""
        result = {
            'score': 5,
            'impact_level': 'moderate',
            'data_available': impact_analysis is not None
        }
        
        if impact_analysis:
            level = impact_analysis.get('impact_level', 'moderate').lower()
            
            if level in ['low', 'minimal', 'isolated']:
                result['score'] = 10
            elif level in ['minor', 'contained']:
                result['score'] = 8
            elif level in ['moderate', 'medium']:
                result['score'] = 6
            elif level in ['high', 'broad']:
                result['score'] = 4
            else:
                result['score'] = 2
            
            result['impact_level'] = level
            result.update(impact_analysis)
        
        return result
    
    def _calculate_performance_impact(self, performance_analysis, pr_data) -> Dict[str, Any]:
        """Calculate performance impact score (10 points) - AI-powered"""
        result = {
            'score': 6,  # Neutral default
            'performance_impact': 'neutral',
            'data_available': performance_analysis is not None
        }
        
        if performance_analysis:
            impact = performance_analysis.get('performance_impact', 'neutral').lower()
            
            if impact in ['improved', 'optimized', 'better']:
                result['score'] = 10
            elif impact in ['neutral', 'no change', 'minimal']:
                result['score'] = 6
            elif impact in ['minor degradation', 'slight']:
                result['score'] = 4
            elif impact in ['moderate degradation']:
                result['score'] = 2
            else:
                result['score'] = 0
            
            result['performance_impact'] = impact
            result.update(performance_analysis)
        
        return result
