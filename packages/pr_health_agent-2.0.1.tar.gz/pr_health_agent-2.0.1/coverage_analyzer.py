"""
Coverage Analyzer Module
Analyzes code coverage for PRs by parsing coverage reports and calculating coverage delta
"""

import re
import os
from typing import Dict, Any, List, Optional
import xml.etree.ElementTree as ET


class CoverageAnalyzer:
    """Analyzes code coverage for pull requests"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize coverage analyzer
        
        Args:
            config: Configuration dictionary
        """
        self.config = config
        self.coverage_config = config.get('coverage', {})
        self.target_coverage = self.coverage_config.get('target_coverage', 80)
        self.min_coverage = self.coverage_config.get('min_coverage', 60)
    
    def analyze(self, pr_data: Any) -> Dict[str, Any]:
        """
        Analyze coverage for PR
        
        Args:
            pr_data: PRData object
            
        Returns:
            Coverage analysis report
        """
        # Try to find coverage reports
        coverage_data = self._find_coverage_report()
        
        if not coverage_data:
            # Fallback to test file ratio analysis
            return self._analyze_test_file_ratio(pr_data)
        
        # Calculate coverage metrics
        total_coverage = coverage_data.get('total_coverage', 0)
        changed_files_coverage = self._calculate_changed_files_coverage(pr_data, coverage_data)
        
        score = self._calculate_coverage_score(total_coverage, changed_files_coverage)
        
        return {
            'score': score,
            'total_coverage': total_coverage,
            'changed_files_coverage': changed_files_coverage,
            'target_coverage': self.target_coverage,
            'has_coverage_report': True,
            'uncovered_files': self._get_uncovered_files(pr_data, coverage_data),
            'recommendation': self._get_recommendation(total_coverage)
        }
    
    def _find_coverage_report(self) -> Optional[Dict[str, Any]]:
        """
        Find and parse coverage reports (coverage.xml, .coverage, etc.)
        
        Returns:
            Coverage data or None if not found
        """
        # Look for common coverage report files
        coverage_files = [
            'coverage.xml',
            '.coverage',
            'htmlcov/index.html',
            'coverage/coverage.xml',
            'test-results/coverage.xml'
        ]
        
        for coverage_file in coverage_files:
            if os.path.exists(coverage_file):
                if coverage_file.endswith('.xml'):
                    return self._parse_coverage_xml(coverage_file)
        
        return None
    
    def _parse_coverage_xml(self, filepath: str) -> Dict[str, Any]:
        """
        Parse coverage.xml file (Cobertura format)
        
        Args:
            filepath: Path to coverage.xml
            
        Returns:
            Coverage data dictionary
        """
        try:
            tree = ET.parse(filepath)
            root = tree.getroot()
            
            # Get overall coverage
            line_rate = float(root.attrib.get('line-rate', 0))
            total_coverage = line_rate * 100
            
            # Get per-file coverage
            files_coverage = {}
            for package in root.findall('.//package'):
                for class_elem in package.findall('.//class'):
                    filename = class_elem.attrib.get('filename', '')
                    file_line_rate = float(class_elem.attrib.get('line-rate', 0))
                    files_coverage[filename] = file_line_rate * 100
            
            return {
                'total_coverage': total_coverage,
                'files': files_coverage
            }
        except Exception as e:
            print(f"Warning: Failed to parse coverage file: {str(e)}")
            return None
    
    def _calculate_changed_files_coverage(self, pr_data: Any, coverage_data: Dict[str, Any]) -> float:
        """
        Calculate average coverage for files changed in PR
        
        Args:
            pr_data: PRData object
            coverage_data: Coverage data from report
            
        Returns:
            Average coverage percentage for changed files
        """
        files_coverage = coverage_data.get('files', {})
        changed_files = [f['filename'] for f in pr_data.files]
        
        covered_files = []
        for changed_file in changed_files:
            # Try exact match first
            if changed_file in files_coverage:
                covered_files.append(files_coverage[changed_file])
            else:
                # Try partial match (different path formats)
                for cov_file, cov_pct in files_coverage.items():
                    if changed_file.endswith(cov_file) or cov_file.endswith(changed_file):
                        covered_files.append(cov_pct)
                        break
        
        if not covered_files:
            return 0.0
        
        return sum(covered_files) / len(covered_files)
    
    def _analyze_test_file_ratio(self, pr_data: Any) -> Dict[str, Any]:
        """
        Fallback: Analyze test file ratio when no coverage report available
        
        Args:
            pr_data: PRData object
            
        Returns:
            Test ratio analysis
        """
        test_patterns = self.coverage_config.get('test_file_patterns', [
            '*test*.py', '*_test.py', 'test_*.py', 'tests/*.py',
            '*test*.js', '*.test.js', '*.spec.js', 'tests/*.js'
        ])
        
        total_files = len(pr_data.files)
        test_files = 0
        
        for file_data in pr_data.files:
            filename = file_data['filename'].lower()
            if any(self._matches_pattern(filename, pattern) for pattern in test_patterns):
                test_files += 1
        
        test_ratio = (test_files / total_files * 100) if total_files > 0 else 0
        
        # Score based on test ratio
        if test_ratio >= 30:
            score = 100
        elif test_ratio >= 20:
            score = 80
        elif test_ratio >= 10:
            score = 60
        else:
            score = 40
        
        return {
            'score': score,
            'total_files': total_files,
            'test_files': test_files,
            'test_ratio': round(test_ratio, 1),
            'has_coverage_report': False,
            'recommendation': f'Add coverage reporting. Currently {test_files}/{total_files} files are tests.'
        }
    
    def _matches_pattern(self, filename: str, pattern: str) -> bool:
        """Check if filename matches pattern"""
        import fnmatch
        return fnmatch.fnmatch(filename, pattern)
    
    def _calculate_coverage_score(self, total_coverage: float, changed_files_coverage: float) -> float:
        """
        Calculate coverage score (0-100)
        
        Args:
            total_coverage: Overall coverage percentage
            changed_files_coverage: Coverage for changed files
            
        Returns:
            Score from 0-100
        """
        # Weight changed files coverage more heavily (70%) than total (30%)
        weighted_coverage = (changed_files_coverage * 0.7) + (total_coverage * 0.3)
        
        # Score based on target
        if weighted_coverage >= self.target_coverage:
            score = 100
        elif weighted_coverage >= (self.target_coverage * 0.9):
            score = 90
        elif weighted_coverage >= (self.target_coverage * 0.8):
            score = 80
        elif weighted_coverage >= self.min_coverage:
            score = 70
        elif weighted_coverage >= (self.min_coverage * 0.8):
            score = 60
        else:
            score = max(40, weighted_coverage / self.target_coverage * 100)
        
        return round(score, 1)
    
    def _get_uncovered_files(self, pr_data: Any, coverage_data: Dict[str, Any]) -> List[str]:
        """
        Get list of changed files with low/no coverage
        
        Args:
            pr_data: PRData object
            coverage_data: Coverage data
            
        Returns:
            List of filenames with coverage below threshold
        """
        files_coverage = coverage_data.get('files', {})
        uncovered = []
        
        for file_data in pr_data.files:
            filename = file_data['filename']
            
            # Skip test files
            if 'test' in filename.lower():
                continue
            
            # Check coverage
            coverage = files_coverage.get(filename, 0)
            if coverage < self.min_coverage:
                uncovered.append(f"{filename} ({coverage:.1f}%)")
        
        return uncovered
    
    def _get_recommendation(self, coverage: float) -> str:
        """Generate recommendation based on coverage"""
        if coverage >= self.target_coverage:
            return f"Excellent coverage! Meets target of {self.target_coverage}%"
        elif coverage >= self.min_coverage:
            return f"Coverage acceptable but below target. Aim for {self.target_coverage}%"
        else:
            return f"Coverage below minimum threshold of {self.min_coverage}%. Add more tests!"
