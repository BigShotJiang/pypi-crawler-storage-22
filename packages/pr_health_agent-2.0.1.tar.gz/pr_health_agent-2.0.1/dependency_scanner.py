"""
Dependency Scanner Module (No GHAS License Required)
Uses GitHub's free Dependabot API to scan for vulnerable dependencies
"""

import requests
from typing import Dict, List, Any, Optional
from dataclasses import dataclass


@dataclass
class DependencyAlert:
    """Represents a Dependabot vulnerability alert"""
    severity: str  # critical, high, moderate, low
    package: str
    ecosystem: str  # npm, pip, maven, etc.
    vulnerable_version: str
    patched_version: Optional[str]
    cve_id: Optional[str]
    ghsa_id: str
    description: str
    state: str  # open, dismissed, fixed
    manifest_path: str


class DependencyScanner:
    """
    Scans for dependency vulnerabilities using Dependabot API
    
    FREE Feature - No GHAS license required
    Requires: 'security_events' scope on PAT
    """
    
    def __init__(self, github_token: str):
        """
        Initialize dependency scanner
        
        Args:
            github_token: GitHub Personal Access Token with 'security_events' scope
        """
        self.github_token = github_token
        self.base_url = "https://api.github.com"
        self.headers = {
            "Authorization": f"Bearer {github_token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28"
        }
    
    def scan_repository(self, repo_name: str) -> Dict[str, Any]:
        """
        Scan repository for dependency vulnerabilities
        
        Args:
            repo_name: Repository name in format 'owner/repo'
            
        Returns:
            Dictionary with vulnerability report and score
        """
        alerts = self._get_dependabot_alerts(repo_name)
        
        if 'error' in alerts:
            return {
                'enabled': False,
                'error': alerts['error'],
                'score': 100,  # Don't penalize if API fails
                'alerts': []
            }
        
        # Categorize alerts by severity
        critical = [a for a in alerts if a.severity == 'critical' and a.state == 'open']
        high = [a for a in alerts if a.severity == 'high' and a.state == 'open']
        moderate = [a for a in alerts if a.severity == 'moderate' and a.state == 'open']
        low = [a for a in alerts if a.severity == 'low' and a.state == 'open']
        
        # Calculate score
        score = self._calculate_dependency_score(critical, high, moderate, low)
        
        return {
            'enabled': True,
            'score': score,
            'total_alerts': len(alerts),
            'open_alerts': len([a for a in alerts if a.state == 'open']),
            'critical_count': len(critical),
            'high_count': len(high),
            'moderate_count': len(moderate),
            'low_count': len(low),
            'alerts': [self._alert_to_dict(a) for a in alerts if a.state == 'open'],
            'passed': score >= 70
        }
    
    def check_pr_dependencies(self, repo_name: str, pr_files: List[Dict]) -> Dict[str, Any]:
        """
        Check if PR modifies dependency files and get vulnerability status
        
        Args:
            repo_name: Repository name in format 'owner/repo'
            pr_files: List of files changed in PR
            
        Returns:
            Dictionary with dependency change analysis
        """
        # Dependency manifest files by ecosystem
        dependency_files = {
            'npm': ['package.json', 'package-lock.json', 'yarn.lock'],
            'pip': ['requirements.txt', 'Pipfile', 'Pipfile.lock', 'setup.py', 'pyproject.toml'],
            'maven': ['pom.xml'],
            'gradle': ['build.gradle', 'build.gradle.kts'],
            'composer': ['composer.json', 'composer.lock'],
            'bundler': ['Gemfile', 'Gemfile.lock'],
            'cargo': ['Cargo.toml', 'Cargo.lock'],
            'go': ['go.mod', 'go.sum'],
            'nuget': ['*.csproj', 'packages.config']
        }
        
        # Check which dependency files changed
        changed_dep_files = []
        ecosystem_changes = set()
        
        for file in pr_files:
            filename = file.get('filename', '')
            for ecosystem, patterns in dependency_files.items():
                for pattern in patterns:
                    if filename.endswith(pattern) or filename.split('/')[-1] == pattern:
                        changed_dep_files.append({
                            'file': filename,
                            'ecosystem': ecosystem,
                            'additions': file.get('additions', 0),
                            'deletions': file.get('deletions', 0)
                        })
                        ecosystem_changes.add(ecosystem)
                        break
        
        if not changed_dep_files:
            return {
                'has_dependency_changes': False,
                'recommendation': '✅ No dependency files modified'
            }
        
        # Get current vulnerability alerts
        repo_scan = self.scan_repository(repo_name)
        
        return {
            'has_dependency_changes': True,
            'modified_files': changed_dep_files,
            'ecosystems_affected': list(ecosystem_changes),
            'active_vulnerabilities': repo_scan.get('open_alerts', 0),
            'critical_vulns': repo_scan.get('critical_count', 0),
            'high_vulns': repo_scan.get('high_count', 0),
            'recommendation': self._get_dependency_recommendation(repo_scan, changed_dep_files)
        }
    
    def check_dependabot_enabled(self, repo_name: str) -> Dict[str, Any]:
        """
        Check if Dependabot alerts are enabled for repository
        
        Args:
            repo_name: Repository name in format 'owner/repo'
            
        Returns:
            Dictionary with Dependabot status
        """
        url = f"{self.base_url}/repos/{repo_name}/vulnerability-alerts"
        
        try:
            response = requests.get(url, headers=self.headers)
            
            if response.status_code == 204:
                return {
                    'enabled': True,
                    'message': '✅ Dependabot alerts are enabled'
                }
            elif response.status_code == 404:
                return {
                    'enabled': False,
                    'message': '⚠️  Dependabot alerts are not enabled',
                    'recommendation': 'Enable Dependabot in Settings → Security → Dependabot alerts'
                }
            else:
                return {
                    'enabled': False,
                    'error': f'HTTP {response.status_code}: {response.text}'
                }
        
        except Exception as e:
            return {
                'enabled': False,
                'error': f'Failed to check Dependabot status: {str(e)}'
            }
    
    def _get_dependabot_alerts(self, repo_name: str) -> List[DependencyAlert]:
        """
        Get Dependabot alerts from GitHub API
        
        Args:
            repo_name: Repository name in format 'owner/repo'
            
        Returns:
            List of DependencyAlert objects or error dict
        """
        url = f"{self.base_url}/repos/{repo_name}/dependabot/alerts"
        
        try:
            response = requests.get(url, headers=self.headers, params={'per_page': 100})
            
            if response.status_code == 404:
                # Check if Dependabot is enabled
                check = self.check_dependabot_enabled(repo_name)
                return {'error': check.get('message', 'Dependabot not enabled')}
            
            if response.status_code == 403:
                return {'error': 'Insufficient permissions. Ensure PAT has "security_events" scope'}
            
            if response.status_code != 200:
                return {'error': f'HTTP {response.status_code}: {response.text}'}
            
            alerts = []
            for alert in response.json():
                advisory = alert.get('security_advisory', {})
                dependency = alert.get('security_vulnerability', {}).get('package', {})
                
                alerts.append(DependencyAlert(
                    severity=advisory.get('severity', 'unknown'),
                    package=dependency.get('name', 'unknown'),
                    ecosystem=dependency.get('ecosystem', 'unknown'),
                    vulnerable_version=alert.get('security_vulnerability', {}).get('vulnerable_version_range', 'unknown'),
                    patched_version=alert.get('security_vulnerability', {}).get('first_patched_version', {}).get('identifier'),
                    cve_id=advisory.get('cve_id'),
                    ghsa_id=advisory.get('ghsa_id', 'N/A'),
                    description=advisory.get('description', 'No description'),
                    state=alert.get('state', 'open'),
                    manifest_path=alert.get('dependency', {}).get('manifest_path', 'unknown')
                ))
            
            return alerts
        
        except requests.exceptions.RequestException as e:
            return {'error': f'Network error: {str(e)}'}
        except Exception as e:
            return {'error': f'Unexpected error: {str(e)}'}
    
    def _calculate_dependency_score(
        self,
        critical: List,
        high: List,
        moderate: List,
        low: List
    ) -> float:
        """
        Calculate dependency security score
        
        Args:
            critical: List of critical severity alerts
            high: List of high severity alerts
            moderate: List of moderate severity alerts
            low: List of low severity alerts
            
        Returns:
            Score from 0-100
        """
        if not any([critical, high, moderate, low]):
            return 100.0
        
        # Deduct points based on severity
        deductions = {
            'critical': 40,  # Each critical = -40 points
            'high': 20,      # Each high = -20 points
            'moderate': 8,   # Each moderate = -8 points
            'low': 3         # Each low = -3 points
        }
        
        total_deduction = (
            len(critical) * deductions['critical'] +
            len(high) * deductions['high'] +
            len(moderate) * deductions['moderate'] +
            len(low) * deductions['low']
        )
        
        # Critical vulnerabilities should block
        if critical:
            return 0.0  # Auto-fail
        
        # Cap deduction at 100
        total_deduction = min(total_deduction, 100)
        
        return max(0, 100 - total_deduction)
    
    def _get_dependency_recommendation(
        self,
        repo_scan: Dict,
        changed_files: List
    ) -> str:
        """Generate recommendation based on dependency changes"""
        
        if repo_scan.get('critical_count', 0) > 0:
            return f"🚨 CRITICAL: {repo_scan['critical_count']} critical vulnerabilities found. Fix before merging!"
        
        if repo_scan.get('high_count', 0) > 0:
            return f"⚠️  HIGH RISK: {repo_scan['high_count']} high-severity vulnerabilities. Review and fix."
        
        if repo_scan.get('moderate_count', 0) > 0:
            return f"⚠️  {repo_scan['moderate_count']} moderate vulnerabilities. Consider updating dependencies."
        
        if repo_scan.get('low_count', 0) > 0:
            return f"ℹ️  {repo_scan['low_count']} low-severity vulnerabilities. Monitor and update when possible."
        
        if changed_files:
            return "✅ Dependency changes detected. No known vulnerabilities found."
        
        return "✅ No dependency vulnerabilities detected"
    
    def _alert_to_dict(self, alert: DependencyAlert) -> Dict[str, Any]:
        """Convert DependencyAlert to dictionary"""
        return {
            'severity': alert.severity,
            'package': alert.package,
            'ecosystem': alert.ecosystem,
            'vulnerable_version': alert.vulnerable_version,
            'patched_version': alert.patched_version,
            'cve_id': alert.cve_id,
            'ghsa_id': alert.ghsa_id,
            'description': alert.description[:200] + '...' if len(alert.description) > 200 else alert.description,
            'state': alert.state,
            'manifest_path': alert.manifest_path
        }
