"""
Enhanced Size Analyzer Module
Multi-factor size analysis: lines, files, commits, commit size distribution
"""

from typing import Dict, Any, List


class EnhancedSizeAnalyzer:
    """Analyzes PR size with multiple factors"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
    
    def analyze(self, pr_data) -> Dict[str, Any]:
        """
        Calculate comprehensive size score
        
        Components:
        - Lines changed (40% - 2.0 points)
        - Files impacted (30% - 1.5 points)
        - Number of commits (15% - 0.75 points)
        - Commit size distribution (15% - 0.75 points)
        
        Returns:
            Dict with score breakdown and details
        """
        result = {
            'score': 0,
            'max_score': 5,
            'lines_score': 0,
            'files_score': 0,
            'commits_score': 0,
            'commit_size_score': 0,
            'total_lines': 0,
            'additions': 0,
            'deletions': 0,
            'changed_files': 0,
            'weighted_files': 0,
            'commits': 0,
            'avg_commit_size': 0,
            'max_commit_size': 0,
            'category': '',
            'recommendation': '',
            'data_available': True
        }
        
        try:
            # Extract data
            additions = pr_data.additions
            deletions = pr_data.deletions
            total_lines = additions + deletions
            changed_files = pr_data.changed_files
            commits = pr_data.commits
            
            result['total_lines'] = total_lines
            result['additions'] = additions
            result['deletions'] = deletions
            result['changed_files'] = changed_files
            result['commits'] = commits
            
            # 1. Lines Changed Score (2.0 points max)
            if total_lines <= 50:
                lines_score = 2.0
            elif total_lines <= 200:
                lines_score = 1.6
            elif total_lines <= 500:
                lines_score = 1.2
            elif total_lines <= 1000:
                lines_score = 0.8
            elif total_lines <= 2000:
                lines_score = 0.4
            else:
                lines_score = 0.0
            
            result['lines_score'] = lines_score
            
            # 2. Files Impacted Score (1.5 points max)
            # Calculate weighted file count
            weighted_files = self._calculate_weighted_files(pr_data.files)
            result['weighted_files'] = weighted_files
            
            if weighted_files <= 5:
                files_score = 1.5
            elif weighted_files <= 10:
                files_score = 1.2
            elif weighted_files <= 20:
                files_score = 0.9
            elif weighted_files <= 40:
                files_score = 0.6
            elif weighted_files <= 75:
                files_score = 0.3
            else:
                files_score = 0.0
            
            result['files_score'] = files_score
            
            # 3. Number of Commits Score (0.75 points max)
            if commits <= 3:
                commits_score = 0.75
            elif commits <= 7:
                commits_score = 0.60
            elif commits <= 15:
                commits_score = 0.45
            elif commits <= 30:
                commits_score = 0.30
            elif commits <= 50:
                commits_score = 0.15
            else:
                commits_score = 0.0
            
            result['commits_score'] = commits_score
            
            # 4. Commit Size Distribution Score (0.75 points max)
            avg_commit_size = total_lines / max(commits, 1)
            max_commit_size = self._get_max_commit_size(pr_data)
            
            result['avg_commit_size'] = round(avg_commit_size, 1)
            result['max_commit_size'] = max_commit_size
            
            if avg_commit_size <= 100 and max_commit_size <= 300:
                commit_size_score = 0.75
            elif avg_commit_size <= 200 and max_commit_size <= 500:
                commit_size_score = 0.60
            elif avg_commit_size <= 400 and max_commit_size <= 800:
                commit_size_score = 0.45
            elif avg_commit_size <= 600 and max_commit_size <= 1200:
                commit_size_score = 0.30
            else:
                commit_size_score = 0.15
            
            result['commit_size_score'] = commit_size_score
            
            # Total Score (5.0 points max)
            total_score = lines_score + files_score + commits_score + commit_size_score
            result['score'] = round(total_score, 2)
            
            # Determine category
            if total_score >= 4.5:
                result['category'] = 'Ideal'
            elif total_score >= 3.5:
                result['category'] = 'Good'
            elif total_score >= 2.5:
                result['category'] = 'Complex'
            elif total_score >= 1.5:
                result['category'] = 'Very Complex'
            else:
                result['category'] = 'Should Split'
            
            # Generate recommendation
            result['recommendation'] = self._generate_recommendation(result)
        
        except Exception as e:
            result['data_available'] = False
            result['score'] = 0
            result['recommendation'] = f'Unable to calculate size score: {str(e)}'
        
        return result
    
    def _calculate_weighted_files(self, files: List[Dict]) -> float:
        """
        Calculate weighted file count
        
        Weights:
        - Config/docs: 0.5x
        - Tests: 0.7x
        - Source code: 1.0x
        - Critical files (auth, payment): 1.5x
        """
        weighted_count = 0
        
        for file in files:
            filename = file.get('filename', '').lower()
            weight = 1.0
            
            # Config and documentation
            if any(ext in filename for ext in ['.md', '.yml', '.yaml', '.json', '.xml', '.properties', '.ini']):
                weight = 0.5
            # Test files
            elif any(marker in filename for marker in ['test', 'spec', '__test__', '.test.', '.spec.']):
                weight = 0.7
            # Critical files
            elif any(critical in filename for critical in ['auth', 'payment', 'billing', 'security', 'crypto']):
                weight = 1.5
            
            weighted_count += weight
        
        return round(weighted_count, 1)
    
    def _get_max_commit_size(self, pr_data) -> int:
        """Get size of largest commit in PR"""
        # If commits_data is available, calculate actual max
        if hasattr(pr_data, 'commits_data') and pr_data.commits_data:
            max_size = 0
            for commit in pr_data.commits_data:
                commit_size = commit.get('stats', {}).get('total', 0)
                if commit_size > max_size:
                    max_size = commit_size
            return max_size
        
        # Otherwise estimate: assume largest commit is avg + 50%
        avg = pr_data.additions + pr_data.deletions / max(pr_data.commits, 1)
        return int(avg * 1.5)
    
    def _generate_recommendation(self, result: Dict[str, Any]) -> str:
        """Generate detailed recommendation based on size analysis"""
        category = result['category']
        total_lines = result['total_lines']
        files = result['weighted_files']
        commits = result['commits']
        
        if category == 'Ideal':
            return f"Perfect size - easy to review ({total_lines} lines, {files} files, {commits} commits)"
        
        elif category == 'Good':
            suggestions = []
            if commits > 7:
                suggestions.append("consider squashing commits")
            if files > 10:
                suggestions.append("many files affected")
            
            if suggestions:
                return f"Acceptable size - {', '.join(suggestions)} ({total_lines} lines)"
            return f"Good size - manageable complexity ({total_lines} lines)"
        
        elif category == 'Complex':
            suggestions = []
            if total_lines > 400:
                suggestions.append("split into 2-3 smaller PRs")
            if files > 15:
                suggestions.append("group changes by module")
            if commits > 15:
                suggestions.append("too many commits, squash related changes")
            
            return f"Large PR - {', '.join(suggestions)} ({total_lines} lines, {files} files)"
        
        elif category == 'Very Complex':
            return f"Too large - must split into smaller PRs. Target: <500 lines per PR ({total_lines} lines, {files} files)"
        
        else:  # Should Split
            num_splits = max(3, total_lines // 500)
            return f"Unacceptable size - BLOCKED. Split into {num_splits}+ smaller PRs (<500 lines each). Current: {total_lines} lines across {files} files"
