#!/usr/bin/env python3
"""
Interactive PR Review Tool
Prompts user for PR details and performs analysis with AI-powered review
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv
import subprocess


def get_input(prompt, default=None):
    """Get user input with optional default"""
    if default:
        user_input = input(f"{prompt} [{default}]: ").strip()
        return user_input if user_input else default
    else:
        user_input = input(f"{prompt}: ").strip()
        while not user_input:
            print("This field is required!")
            user_input = input(f"{prompt}: ").strip()
        return user_input


def check_dependencies():
    """Check if required Python packages are installed"""
    print("Checking dependencies...")
    missing = []
    
    try:
        import github
    except ImportError:
        missing.append("PyGithub")
    
    try:
        import requests
    except ImportError:
        missing.append("requests")
    
    try:
        import yaml
    except ImportError:
        missing.append("PyYAML")
    
    try:
        from dotenv import load_dotenv
    except ImportError:
        missing.append("python-dotenv")
    
    # boto3 is optional (only for Bedrock)
    try:
        import boto3
    except ImportError:
        print("  ⚠️  boto3 not installed (required only for AWS Bedrock)")
    
    if missing:
        print(f"  ✗ Missing packages: {', '.join(missing)}")
        print("\n  Fix: pip install -r requirements.txt")
        return False
    else:
        print("  ✓ All dependencies installed")
        return True


def set_environment_variable(key, value):
    """Set environment variable for current session and provide command for permanent storage"""
    # Set for current session
    os.environ[key] = value
    
    print(f"\n  ✓ {key} set for current session")
    print(f"\n  To make this permanent, run this command:")
    
    if sys.platform == 'win32':
        # Windows PowerShell command
        print(f"\n  PowerShell:")
        print(f"  [System.Environment]::SetEnvironmentVariable('{key}', '{value}', 'User')")
        print(f"\n  Or add to your PowerShell profile for auto-load:")
        print(f"  $env:{key} = '{value}'")
    else:
        # Linux/macOS bash/zsh command
        print(f"\n  Bash/Zsh:")
        print(f"  echo 'export {key}=\"{value}\"' >> ~/.bashrc")
        print(f"  source ~/.bashrc")


def validate_github_token(token):
    """Validate GitHub token by making a test API call"""
    try:
        from github import Github, Auth
        import urllib3
        
        # Disable SSL warnings for corporate environments
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        # Use new auth method
        auth = Auth.Token(token)
        g = Github(auth=auth, verify=False)
        user = g.get_user()
        username = user.login
        print(f"  ✓ Token valid for user: {username}")
        return True
    except Exception as e:
        print(f"  ✗ Token validation failed: {str(e)}")
        return False


def validate_gemini_key(api_key):
    """Validate Gemini API key by listing available models"""
    try:
        import requests
        
        if not api_key or len(api_key) < 20:
            print(f"  ✗ Invalid Gemini API key format")
            return False
        
        # Test by listing available models
        url = f"https://generativelanguage.googleapis.com/v1/models?key={api_key}"
        response = requests.get(url, timeout=10)
        
        if response.status_code == 200:
            models = response.json()
            model_count = len(models.get('models', []))
            print(f"  ✓ Gemini API key validated ({model_count} models available)")
            return True
        elif response.status_code == 403 or response.status_code == 401:
            print(f"  ✗ Invalid or unauthorized Gemini API key")
            return False
        else:
            print(f"  ✗ Gemini validation failed: HTTP {response.status_code}")
            return False
            
    except Exception as e:
        print(f"  ✗ Gemini validation failed: {str(e)}")
        return False


def validate_bedrock_key(api_key, region='us-east-1'):
    """Validate Bedrock API key by making a test API call"""
    try:
        import boto3
        import os
        
        if not api_key or len(api_key) < 10:
            print(f"  ✗ Invalid Bedrock API key format")
            return False
        
        # Set environment variables for authentication
        os.environ['AWS_BEARER_TOKEN_BEDROCK'] = api_key
        os.environ['AWS_ACCESS_KEY_ID'] = 'not-used'
        os.environ['AWS_SECRET_ACCESS_KEY'] = 'not-used'
        
        # Create Bedrock client
        client = boto3.client(
            service_name='bedrock-runtime',
            region_name=region
        )
        
        # Make a simple test request
        model_id = "us.anthropic.claude-3-5-haiku-20241022-v1:0"
        messages = [{"role": "user", "content": [{"text": "Hello"}]}]
        
        response = client.converse(
            modelId=model_id,
            messages=messages,
            inferenceConfig={
                "maxTokens": 10,
                "temperature": 0.1
            }
        )
        
        # If we get here, the key is valid
        print(f"  ✓ Bedrock API key validated successfully (region: {region})")
        return True
        
    except Exception as e:
        error_msg = str(e)
        if "UnrecognizedClientException" in error_msg or "security token" in error_msg:
            print(f"  ✗ Invalid Bedrock API key")
        elif "AccessDeniedException" in error_msg:
            print(f"  ✗ API key valid but lacks permissions for model")
        else:
            print(f"  ✗ Bedrock validation failed: {error_msg}")
        return False


def setup_wizard():
    """Interactive wizard to collect and validate API keys"""
    from menu_helper import get_single_choice, get_yes_no
    
    print("\n" + "="*70)
    print("🔧 Setup Wizard - Configure API Keys")
    print("="*70)
    
    # GitHub Token
    print("\n1️⃣  GitHub Personal Access Token")
    print("   Generate at: https://github.com/settings/tokens")
    print("   Required permissions: repo (full control)")
    
    github_valid = False
    while not github_valid:
        github_token = input("\n   Enter GitHub Token: ").strip()
        
        if not github_token:
            print("\n   ❌ GitHub token is required to continue!")
            if not get_yes_no("   Try again?", default='y'):
                print("\n   ❌ Setup cancelled. GitHub token is required.")
                return False
            continue
        
        print("\n   Validating GitHub token...")
        if validate_github_token(github_token):
            set_environment_variable('GITHUB_TOKEN', github_token)
            github_valid = True
        else:
            print("\n   ❌ Token validation failed!")
            if not get_yes_no("   Try again?", default='y'):
                print("\n   ❌ Setup cancelled. Valid GitHub token is required.")
                return False
    
    # AI Provider Selection (optional)
    print("\n\n2️⃣  AI Provider Configuration (Optional - for AI analysis)")
    
    ai_choice = get_single_choice(
        "Choose your AI provider for PR analysis:",
        [
            (1, "Google Gemini (Recommended - Fast & Free tier available)"),
            (2, "AWS Bedrock (Anthropic Claude)"),
            (3, "Skip AI configuration")
        ],
        default=1
    )
    
    if ai_choice == 1:
        # Configure Gemini
        print("\n   📱 Google Gemini Setup")
        print("   Get API key: https://aistudio.google.com/app/apikey")
        print("   Available models: gemini-2.5-flash, gemini-2.0-flash-lite, etc.")
        
        gemini_valid = False
        max_attempts = 3
        attempts = 0
        
        while not gemini_valid and attempts < max_attempts:
            attempts += 1
            gemini_key = input(f"\n   Enter Gemini API Key (attempt {attempts}/{max_attempts}): ").strip()
            
            if not gemini_key:
                print("\n   ⚠️  Skipping AI configuration")
                break
            
            print("\n   Validating Gemini API key...")
            if validate_gemini_key(gemini_key):
                set_environment_variable('GEMINI_API_KEY', gemini_key)
                set_environment_variable('AI_PROVIDER', 'gemini')
                
                # Optional: Let user choose model
                model_choice = get_single_choice(
                    "Choose Gemini model:",
                    [
                        ('gemini-2.0-flash-lite', "gemini-2.0-flash-lite (fastest, recommended)"),
                        ('gemini-2.0-flash', "gemini-2.0-flash (balanced)"),
                        ('gemini-2.5-pro', "gemini-2.5-pro (most capable)")
                    ],
                    default=1
                )
                set_environment_variable('GEMINI_MODEL', model_choice)
                
                gemini_valid = True
                print(f"\n   ✅ Gemini configured with {model_choice}")
            else:
                print(f"\n   ❌ Gemini validation failed!")
                if attempts < max_attempts:
                    if not get_yes_no("   Try again?", default='y'):
                        print("\n   ⚠️  Skipping AI configuration")
                        break
                else:
                    print(f"\n   ⚠️  Max attempts reached. Skipping AI configuration.")
    
    elif ai_choice == 2:
        # Configure Bedrock
        print("\n   ☁️  AWS Bedrock Setup")
        print("   Required for: Anthropic Claude models")
        
        bedrock_valid = False
        max_attempts = 3
        attempts = 0
        
        while not bedrock_valid and attempts < max_attempts:
            attempts += 1
            bedrock_key = input(f"\n   Enter Bedrock API Key (attempt {attempts}/{max_attempts}): ").strip()
            region = input("   Enter AWS Region [us-east-1]: ").strip() or 'us-east-1'
            
            if not bedrock_key:
                print("\n   ⚠️  Skipping AI configuration")
                break
            
            print("\n   Validating Bedrock API key (this may take a few seconds)...")
            if validate_bedrock_key(bedrock_key, region):
                set_environment_variable('BEDROCK_API_KEY', bedrock_key)
                set_environment_variable('AWS_REGION', region)
                set_environment_variable('AI_PROVIDER', 'bedrock')
                bedrock_valid = True
                print("\n   ✅ Bedrock configured")
            else:
                print(f"\n   ❌ Bedrock validation failed!")
                if attempts < max_attempts:
                    if not get_yes_no("   Try again?", default='y'):
                        print("\n   ⚠️  Skipping AI configuration")
                        break
                else:
                    print(f"\n   ⚠️  Max attempts reached. Skipping AI configuration.")
    else:
        print("\n   ⚠️  Skipping AI configuration (AI features will be disabled)")
    
    print("\n" + "="*70)
    print("✅ Setup Complete!")
    print("="*70)
    print("\n⚠️  Remember: Environment variables are set for this session only.")
    print("Use the commands shown above to make them permanent.\n")
    return True


def validate_setup():
    """Validate the setup and return status"""
    print("\n" + "="*70)
    print("🔍 Validating Setup")
    print("="*70)
    
    all_ok = True
    
    # Check dependencies
    deps_ok = check_dependencies()
    if not deps_ok:
        all_ok = False
    
    # Check for required files
    print("\nChecking required files...")
    required_files = [
        'pr_agent.py',
        'pr_collector.py',
        'score_calculator.py',
        'comment_generator.py',
        'merge_controller.py',
        'config.yaml'
    ]
    
    for filename in required_files:
        if Path(filename).exists():
            print(f"  ✓ {filename}")
        else:
            print(f"  ✗ {filename} - MISSING")
            all_ok = False
    
    # Check environment variables
    print("\nChecking environment variables...")
    github_token = os.getenv('GITHUB_TOKEN')
    gemini_key = os.getenv('GEMINI_API_KEY')
    bedrock_key = os.getenv('BEDROCK_API_KEY')
    aws_profile = os.getenv('AWS_PROFILE')
    openai_key = os.getenv('OPENAI_API_KEY')
    
    github_ok = False
    if github_token:
        print(f"  ✓ GITHUB_TOKEN set")
        github_ok = True
    else:
        print(f"  ✗ GITHUB_TOKEN not set")
        all_ok = False
    
    ai_available = False
    if gemini_key:
        print(f"  ✓ GEMINI_API_KEY set (AI features available)")
        ai_available = True
    elif bedrock_key:
        print(f"  ✓ BEDROCK_API_KEY set (AI features available)")
        ai_available = True
    elif aws_profile:
        print(f"  ✓ AWS_PROFILE set (Bedrock SSO - AI features available)")
        ai_available = True
    elif openai_key:
        print(f"  ✓ OPENAI_API_KEY set (AI features available)")
        ai_available = True
    else:
        print(f"  ⚠  No AI provider configured (AI features disabled)")
    
    print()
    if all_ok:
        print("✅ Setup validation passed!")
    else:
        print("❌ Setup validation failed - please fix issues above")
    
    return all_ok, github_ok, ai_available


def show_main_menu(ai_available):
    """Display main menu and get user choice"""
    from menu_helper import get_single_choice
    
    ai_warning = "" if ai_available else " (⚠️  AI not configured)"
    
    return get_single_choice(
        "📋 Main Menu - Select an option:",
        [
            (1, "📊 Analyze PR Health Score"),
            (2, f"🤖 Analyze PR Impact (AI){ai_warning}"),
            (3, "📚 Show Commands Reference"),
            (4, "🔧 Run Setup Wizard"),
            (5, "🔍 Validate Setup"),
            (6, "❌ Exit")
        ]
    )


def show_commands_reference():
    """Show reference for command-line usage"""
    print("\n" + "="*70)
    print("📚 Command Reference")
    print("="*70)
    
    print("\n🔹 Basic PR Analysis:")
    print("   python pr_agent.py owner/repo 123")
    
    print("\n🔹 With AI Analysis:")
    print("   python pr_agent.py owner/repo 123 --ai-analysis")
    
    print("\n🔹 Post Comment to PR:")
    print("   python pr_agent.py owner/repo 123 --ai-analysis --post-comment")
    
    print("\n🔹 Add Labels:")
    print("   python pr_agent.py owner/repo 123 --add-labels")
    
    print("\n🔹 Custom Threshold:")
    print("   python pr_agent.py owner/repo 123 --threshold 80")
    
    print("\n🔹 Disable Merge Blocking:")
    print("   python pr_agent.py owner/repo 123 --no-block")
    
    print("\n🔹 All Options:")
    print("   python pr_agent.py owner/repo 123 \\")
    print("       --ai-analysis \\")
    print("       --post-comment \\")
    print("       --add-labels \\")
    print("       --threshold 75 \\")
    print("       --verbose")
    
    print("\n" + "="*70)


def run_pr_health_analysis():
    """Guided PR health analysis"""
    from menu_helper import get_yes_no
    
    print("\n" + "="*70)
    print("📊 PR Health Score Analysis")
    print("="*70)
    
    # Get PR details
    print("\nEnter PR details:")
    repository = get_input("  Repository (owner/repo)", "octocat/Hello-World")
    pr_number = get_input("  PR Number", "1")
    
    # Get options
    print("\nAnalysis options:")
    post_comment = get_yes_no("  Post comment to PR?", default='n')
    add_labels = get_yes_no("  Add health labels?", default='n')
    use_ai = get_yes_no("  Use AI analysis?", default='y')
    
    threshold = input("  Minimum passing score [70]: ").strip()
    threshold = threshold if threshold else "70"
    
    print("\n" + "="*70)
    print("Running analysis...")
    print("="*70)
    print()
    
    # Build command
    cmd_parts = [
        "python", "pr_agent.py",
        repository, pr_number
    ]
    
    # Check if any AI provider is available
    has_ai = os.getenv('GEMINI_API_KEY') or os.getenv('BEDROCK_API_KEY') or os.getenv('AWS_PROFILE') or os.getenv('OPENAI_API_KEY')
    
    if use_ai and has_ai:
        cmd_parts.append("--ai-analysis")
    elif use_ai:
        print("⚠️  AI analysis requested but no AI provider configured. Skipping AI features.")
        print("    Set GEMINI_API_KEY, BEDROCK_API_KEY, AWS_PROFILE (for SSO), or OPENAI_API_KEY to enable AI.")
    
    if post_comment:
        cmd_parts.append("--post-comment")
    
    if add_labels:
        cmd_parts.append("--add-labels")
    
    cmd_parts.extend(["--threshold", threshold])
    cmd_parts.extend(["--verbose", "--no-block"])
    
    print(f"Command: {' '.join(cmd_parts)}")
    print()
    
    # Run command
    result = subprocess.run(cmd_parts, cwd=Path(__file__).parent)
    
    print()
    print("="*70)
    print("✅ Analysis completed!")
    print("="*70)
    
    return True

def run_impact_analysis():
    """Guided AI-powered impact analysis"""
    from menu_helper import get_yes_no
    
    print("\n" + "="*70)
    print("🤖 AI-Powered Impact Analysis")
    print("="*70)
    
    # Check if Bedrock is configured
    bedrock_configured = os.getenv('BEDROCK_API_KEY') or os.getenv('AWS_PROFILE')
    if not bedrock_configured:
        print("\n⚠️  Bedrock not configured (need BEDROCK_API_KEY or AWS_PROFILE for SSO)!")
        
        if get_yes_no("\nWould you like to set it up now? Run setup wizard?", default='y'):
            setup_wizard()
            
            # Check again
            bedrock_configured = os.getenv('BEDROCK_API_KEY') or os.getenv('AWS_PROFILE')
            if not bedrock_configured:
                print("\n❌ Bedrock still not configured. Cannot proceed with impact analysis.")
                return False
        else:
            print("\n❌ Cannot proceed without Bedrock configuration.")
            return False
    
    # Get PR details
    print("\nEnter PR details:")
    repository = get_input("  Repository (owner/repo)", "octocat/Hello-World")
    pr_number = get_input("  PR Number", "1")
    
    # Get options
    print("\nAnalysis options:")
    post_comment = get_yes_no("  Post AI comments to PR?", default='n')
    post_comment = input("  Post AI comments to PR? (yes/no) [no]: ").strip().lower() in ['yes', 'y']
    
    print("\n" + "="*70)
    print("Running AI impact analysis...")
    print("="*70)
    print()
    
    # Build command with AI analysis enabled
    cmd_parts = [
        "python", "pr_agent.py",
        repository, pr_number,
        "--ai-analysis"
    ]
    
    if post_comment:
        cmd_parts.append("--post-comment")
    
    cmd_parts.extend(["--verbose", "--no-block"])
    
    print(f"Command: {' '.join(cmd_parts)}")
    print()
    
    result = subprocess.run(cmd_parts, cwd=Path(__file__).parent)
    
    print()
    print("="*70)
    print("✅ Impact analysis completed!")
    print("="*70)
    
    return True


def main():
    print("="*70)
    print("🤖 PR Health Score Agent - Interactive Mode")
    print("="*70)
    
    # Load .env file if it exists (for backward compatibility)
    env_path = Path('.env')
    if env_path.exists():
        load_dotenv(env_path)
    
    # Check if setup exists
    github_token = os.getenv('GITHUB_TOKEN')
    
    if not github_token:
        print("\n⚠️  No GITHUB_TOKEN found. Let's set up your API keys.")
        input("\nPress Enter to start setup wizard...")
        setup_wizard()
    
    # Validate setup
    setup_ok, github_ok, ai_available = validate_setup()
    
    if not setup_ok:
        print("\n❌ Setup validation failed!")
        print("\nWould you like to run the setup wizard?")
        run_wizard = input("Run setup wizard? (yes/no) [yes]: ").strip().lower()
        
        if run_wizard in ['', 'yes', 'y']:
            setup_wizard()
            # Revalidate
            setup_ok, github_ok, ai_available = validate_setup()
            
            if not setup_ok:
                print("\n❌ Setup still incomplete. Please check the issues above.")
                print("\nNote: Environment variables are set for this session only.")
                print("Use the commands shown above to make them permanent.")
                sys.exit(1)
        else:
            print("\nExiting. Please set environment variables manually.")
            print("See ENV_SETUP.md for instructions.")
            sys.exit(1)
    
    # Main interactive loop
    while True:
        choice = show_main_menu(ai_available)
        
        if choice == '1':
            # Analyze PR Health
            run_pr_health_analysis()
            print("\n")
            input("Press Enter to return to main menu...")
        
        elif choice == 2:
            # AI Impact Analysis
            run_impact_analysis()
            # Recheck ai_available in case user set up Bedrock
            ai_available = bool(os.getenv('BEDROCK_API_KEY') or os.getenv('AWS_PROFILE') or os.getenv('GEMINI_API_KEY') or os.getenv('OPENAI_API_KEY'))
            print("\n")
            input("Press Enter to return to main menu...")
        
        elif choice == '3':
            # Show commands reference
            show_commands_reference()
            input("\nPress Enter to return to main menu...")
        
        elif choice == '4':
            # Run setup wizard
            setup_wizard()
            # Revalidate
            setup_ok, github_ok, ai_available = validate_setup()
            input("\nPress Enter to return to main menu...")
        
        elif choice == '5':
            # Re-run setup validation
            setup_ok, github_ok, ai_available = validate_setup()
            input("\nPress Enter to return to main menu...")
        
        elif choice == '6':
            # Exit
            print("\n✅ Thank you for using PR Health Score Agent!")
            sys.exit(0)
        
        else:
            print("\n❌ Invalid choice. Please enter a number between 1-6.")
            input("Press Enter to continue...")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Cancelled by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        sys.exit(1)


# Additional helper functions for app.py integration
def setup_github_token():
    """Setup and validate GitHub token"""
    print("   Generate at: https://github.com/settings/tokens")
    print("   Required permissions: repo (full control)")
    
    github_token = get_input("Enter GitHub Personal Access Token")
    
    if validate_github_token(github_token):
        return github_token
    else:
        print("❌ Invalid GitHub token. Please try again.")
        return setup_github_token()


def setup_ai_provider():
    """Setup AI providers and return configurations"""
    from menu_helper import get_multiple_choice, get_single_choice
    
    ai_configs = {}
    
    # Let user select which providers to configure
    selected_providers = get_multiple_choice(
        "Choose AI providers to configure (you can select multiple):",
        [
            ('gemini', "Google Gemini (Recommended - Free tier available)"),
            ('bedrock', "AWS Bedrock (Supports SSO)"),
            ('openai', "OpenAI (GPT-4o models)")
        ],
        allow_skip=True
    )
    
    # Configure each selected provider
    for provider in selected_providers:
        if provider == 'gemini':
            print("\n📱 Configuring Google Gemini")
            print("-" * 70)
            print("Get API key: https://aistudio.google.com/app/apikey")
            gemini_key = get_input("Enter Gemini API Key")
            if validate_gemini_key(gemini_key):
                ai_configs['gemini'] = gemini_key
                print("✅ Gemini configured successfully")
        
        elif provider == 'bedrock':
            print("\n☁️  Configuring AWS Bedrock")
            print("-" * 70)
            auth_method = get_single_choice(
                "Select authentication method:",
                [
                    ('api_key', "API Key (Bearer token)"),
                    ('sso', "AWS SSO (Recommended for corporate)"),
                    ('iam_role', "IAM Role (For EC2/Lambda)")
                ]
            )
            
            if auth_method == 'sso':
                sso_profile = get_input("AWS SSO Profile name", "default")
                ai_configs['bedrock'] = {'auth': 'sso', 'profile': sso_profile}
                print("✅ Bedrock configured with SSO")
            elif auth_method == 'api_key':
                bedrock_key = get_input("Enter Bedrock API Key")
                region = get_input("AWS Region", "us-east-1")
                if validate_bedrock_key(bedrock_key, region):
                    ai_configs['bedrock'] = {'auth': 'api_key', 'key': bedrock_key, 'region': region}
                    print("✅ Bedrock configured with API key")
            else:
                ai_configs['bedrock'] = {'auth': 'iam_role'}
                print("✅ Bedrock configured with IAM role")
        
        elif provider == 'openai':
            print("\n🤖 Configuring OpenAI")
            print("-" * 70)
            print("Get API key: https://platform.openai.com/api-keys")
            openai_key = get_input("Enter OpenAI API Key")
            ai_configs['openai'] = openai_key
            print("✅ OpenAI configured successfully")
    
    if not selected_providers:
        print("\n⚠️  No AI providers configured. AI analysis will be disabled.")
    
    return ai_configs


def test_all_connections(github_token, ai_configs):
    """Test all configured connections"""
    print("Testing GitHub connection...")
    validate_github_token(github_token)
    
    for provider, config in ai_configs.items():
        print(f"\nTesting {provider.title()} connection...")
        if provider == 'gemini':
            validate_gemini_key(config)
        elif provider == 'openai':
            print("  ⚠️  OpenAI validation not implemented yet")


def save_env_file(github_token, ai_configs):
    """Save configuration to .env file"""
    env_lines = [
        f"GITHUB_TOKEN={github_token}\n"
    ]
    
    if 'gemini' in ai_configs:
        env_lines.append(f"GEMINI_API_KEY={ai_configs['gemini']}\n")
        env_lines.append("AI_PROVIDER=gemini\n")
    
    if 'bedrock' in ai_configs:
        bedrock_config = ai_configs['bedrock']
        if bedrock_config.get('auth') == 'api_key':
            env_lines.append(f"BEDROCK_API_KEY={bedrock_config['key']}\n")
            env_lines.append(f"AWS_REGION={bedrock_config.get('region', 'us-east-1')}\n")
        elif bedrock_config.get('auth') == 'sso':
            env_lines.append(f"AWS_PROFILE={bedrock_config['profile']}\n")
        if not 'gemini' in ai_configs:
            env_lines.append("AI_PROVIDER=bedrock\n")
    
    if 'openai' in ai_configs:
        env_lines.append(f"OPENAI_API_KEY={ai_configs['openai']}\n")
        if not 'gemini' in ai_configs and not 'bedrock' in ai_configs:
            env_lines.append("AI_PROVIDER=openai\n")
    
    with open('.env', 'w') as f:
        f.writelines(env_lines)
    
    print("✅ Configuration saved to .env file")
