"""
PR Merge Controller
Manages merge blocking logic based on health score thresholds
"""

from typing import Dict, Any, Optional, Tuple
from github import Github, GithubException
import sys


class MergeController:
    """Controls PR merge permissions based on health scores"""
    
    def __init__(self, github_token: str, config: Dict[str, Any]):
        """
        Initialize merge controller
        
        Args:
            github_token: GitHub personal access token
            config: Configuration dictionary
        """
        from github import Auth
        import urllib3
        
        # Disable SSL warnings for corporate environments
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        # Use new auth method and disable SSL verification
        auth = Auth.Token(github_token)
        self.github = Github(auth=auth, verify=False)
        self.config = config
        self.min_score = config['thresholds']['min_passing_score']
    
    def check_merge_eligibility(self, score: float) -> Tuple[bool, str]:
        """
        Check if PR meets merge criteria
        
        Args:
            score: Health score
            
        Returns:
            Tuple of (can_merge: bool, reason: str)
        """
        if score >= self.min_score:
            return True, f"Score {score} meets minimum threshold of {self.min_score}"
        else:
            return False, f"Score {score} is below minimum threshold of {self.min_score}"
    
    def update_pr_status(self, repo_name: str, pr_number: int, 
                        score: float, can_merge: bool) -> bool:
        """
        Update PR with status label
        
        Args:
            repo_name: Repository name in format 'owner/repo'
            pr_number: Pull request number
            score: Health score
            can_merge: Whether PR can be merged
            
        Returns:
            True if successful, False otherwise
        """
        try:
            repo = self.github.get_repo(repo_name)
            pr = repo.get_pull(pr_number)
            
            # Define labels
            pass_label = "health-check:pass"
            fail_label = "health-check:fail"
            
            # Get current labels
            current_labels = [label.name for label in pr.labels]
            
            # Remove old health check labels
            labels_to_keep = [l for l in current_labels if not l.startswith('health-check:')]
            
            # Add new label
            if can_merge:
                labels_to_keep.append(pass_label)
            else:
                labels_to_keep.append(fail_label)
            
            # Update labels
            pr.set_labels(*labels_to_keep)
            
            print(f"✓ Updated PR labels: {', '.join(labels_to_keep)}")
            return True
            
        except GithubException as e:
            print(f"✗ Failed to update PR labels: {str(e)}")
            return False
    
    def block_merge_if_needed(self, score: float) -> int:
        """
        Return appropriate exit code based on score
        
        Args:
            score: Health score
            
        Returns:
            Exit code (0 for pass, 1 for fail)
        """
        can_merge, reason = self.check_merge_eligibility(score)
        
        if can_merge:
            print(f"\n✅ MERGE ALLOWED: {reason}")
            return 0
        else:
            print(f"\n🚫 MERGE BLOCKED: {reason}")
            return 1
    
    def create_status_check(self, repo_name: str, commit_sha: str, 
                          score: float, can_merge: bool, 
                          details_url: Optional[str] = None) -> bool:
        """
        Create a GitHub commit status check
        Note: Requires appropriate permissions
        
        Args:
            repo_name: Repository name
            commit_sha: Commit SHA
            score: Health score
            can_merge: Whether score passes
            details_url: Optional URL for details
            
        Returns:
            True if successful
        """
        try:
            repo = self.github.get_repo(repo_name)
            commit = repo.get_commit(commit_sha)
            
            state = "success" if can_merge else "failure"
            description = f"Health Score: {score}/100 (min: {self.min_score})"
            context = "pr-health-check"
            
            commit.create_status(
                state=state,
                description=description,
                context=context,
                target_url=details_url
            )
            
            print(f"✓ Created commit status: {state}")
            return True
            
        except GithubException as e:
            print(f"✗ Failed to create commit status: {str(e)}")
            print("  Note: This requires repo status permissions")
            return False
    
    def add_review_if_needed(self, repo_name: str, pr_number: int, 
                           score: float, can_merge: bool, 
                           comment: str) -> bool:
        """
        Add an automated review to the PR
        
        Args:
            repo_name: Repository name
            pr_number: PR number
            score: Health score
            can_merge: Whether score passes
            comment: Review comment body
            
        Returns:
            True if successful
        """
        try:
            repo = self.github.get_repo(repo_name)
            pr = repo.get_pull(pr_number)
            
            # Determine review event
            if can_merge:
                event = "COMMENT"  # or "APPROVE" if you want to auto-approve
            else:
                event = "REQUEST_CHANGES"
            
            # Create review
            pr.create_review(
                body=comment,
                event=event
            )
            
            print(f"✓ Added review: {event}")
            return True
            
        except GithubException as e:
            print(f"✗ Failed to add review: {str(e)}")
            return False


def handle_merge_decision(controller: MergeController, repo_name: str, 
                         pr_number: int, score: float, 
                         pr_data: Any = None, 
                         add_labels: bool = True,
                         add_status: bool = False) -> int:
    """
    Handle all merge-related decisions and updates
    
    Args:
        controller: MergeController instance
        repo_name: Repository name
        pr_number: PR number
        score: Health score
        pr_data: Optional PRData object
        add_labels: Whether to add labels
        add_status: Whether to add commit status
        
    Returns:
        Exit code
    """
    can_merge, reason = controller.check_merge_eligibility(score)
    
    # Update labels
    if add_labels:
        controller.update_pr_status(repo_name, pr_number, score, can_merge)
    
    # Add commit status if requested and PR data available
    if add_status and pr_data:
        try:
            # Get latest commit SHA from PR
            from github import Github, Auth
            import urllib3
            
            # Disable SSL warnings
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            
            # Reuse the auth from controller
            auth = Auth.Token(controller.github._Github__requester._Requester__auth.token)
            github = Github(auth=auth, verify=False)
            repo = github.get_repo(repo_name)
            pr = repo.get_pull(pr_number)
            commit_sha = pr.head.sha
            
            controller.create_status_check(
                repo_name, 
                commit_sha, 
                score, 
                can_merge,
                pr.html_url
            )
        except Exception as e:
            print(f"Warning: Could not create status check: {e}")
    
    # Return exit code
    return controller.block_merge_if_needed(score)
