#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PR Health Score Agent
A CLI tool to calculate health scores for GitHub Pull Requests
and provide AI-powered analysis using AWS Bedrock or Google Gemini
"""

import os
import sys
import argparse
import yaml
from pathlib import Path
from dotenv import load_dotenv
from typing import Optional

# Fix Unicode encoding for Windows console
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

from pr_collector import PRCollector
from score_calculator import HealthScoreCalculator
from comprehensive_score_calculator import ComprehensiveScoreCalculator
from ai_analyzer import AIAnalyzer
from comment_generator import CommentGenerator
from comprehensive_comment_generator import ComprehensiveCommentGenerator
from merge_controller import MergeController, handle_merge_decision
from dependency_scanner import DependencyScanner


def load_config(config_path: str = 'config.yaml') -> dict:
    """Load configuration from YAML file"""
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    except FileNotFoundError:
        print(f"Error: Configuration file '{config_path}' not found")
        sys.exit(1)
    except yaml.YAMLError as e:
        print(f"Error parsing config file: {e}")
        sys.exit(1)


def setup_environment():
    """Load environment variables from .env file"""
    # Look for .env in current directory
    env_path = Path('.env')
    if env_path.exists():
        load_dotenv(env_path)
    else:
        print("Warning: .env file not found. Make sure environment variables are set.")


def validate_environment(require_ai: bool = False):
    """
    Validate required environment variables
    
    Args:
        require_ai: Whether to require AI provider configuration
    """
    required_vars = ['GITHUB_TOKEN']
    
    missing_vars = [var for var in required_vars if not os.getenv(var)]
    
    if missing_vars:
        print("Error: Missing required environment variables:")
        for var in missing_vars:
            print(f"  - {var}")
        print("\nPlease set these in your environment.")
        sys.exit(1)
    
    # Check AI provider if required
    if require_ai:
        has_gemini = os.getenv('GEMINI_API_KEY')
        has_bedrock = os.getenv('BEDROCK_API_KEY')
        
        if not has_gemini and not has_bedrock:
            print("\nError: AI analysis requires an AI provider.")
            print("Set one of the following:")
            print("  - GEMINI_API_KEY (Google Gemini - Recommended)")
            print("  - BEDROCK_API_KEY (AWS Bedrock)")
            print("\nRun 'python interactive.py' for guided setup.")
            sys.exit(1)


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description='PR Health Score Agent - Analyze GitHub Pull Requests',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Analyze a PR (basic)
  python pr_agent.py owner/repo 123

  # Analyze with AI-powered insights
  python pr_agent.py owner/repo 123 --ai-analysis

  # Analyze and post comment to PR
  python pr_agent.py owner/repo 123 --post-comment

  # Use custom config and threshold
  python pr_agent.py owner/repo 123 --config custom.yaml --threshold 80

  # Full analysis with all features
  python pr_agent.py owner/repo 123 --ai-analysis --post-comment --add-labels
        """
    )
    
    # Positional arguments
    parser.add_argument(
        'repository',
        help='Repository in format owner/repo (e.g., microsoft/vscode)'
    )
    parser.add_argument(
        'pr_number',
        type=int,
        help='Pull request number'
    )
    
    # Optional arguments
    parser.add_argument(
        '--config',
        default='config.yaml',
        help='Path to configuration file (default: config.yaml)'
    )
    parser.add_argument(
        '--threshold',
        type=int,
        help='Override minimum passing score threshold'
    )
    parser.add_argument(
        '--ai-analysis',
        action='store_true',
        help='Enable AI-powered analysis using Amazon Bedrock'
    )
    parser.add_argument(
        '--post-comment',
        action='store_true',
        help='Post health report as PR comment'
    )
    parser.add_argument(
        '--add-labels',
        action='store_true',
        help='Add health-check labels to PR'
    )
    parser.add_argument(
        '--add-status',
        action='store_true',
        help='Add commit status check (requires repo status permissions)'
    )
    parser.add_argument(
        '--no-block',
        action='store_true',
        help='Don\'t exit with error code if score is below threshold'
    )
    parser.add_argument(
        '--output',
        choices=['console', 'json', 'both'],
        default='console',
        help='Output format (default: console)'
    )
    parser.add_argument(
        '--verbose',
        '-v',
        action='store_true',
        help='Enable verbose output'
    )
    
    args = parser.parse_args()
    
    # Setup
    setup_environment()
    
    # Validate based on whether AI is requested
    validate_environment(require_ai=args.ai_analysis)
    
    # Load configuration
    config = load_config(args.config)
    
    # Override threshold if specified
    if args.threshold:
        config['thresholds']['min_passing_score'] = args.threshold
        if args.verbose:
            print(f"Using custom threshold: {args.threshold}")
    
    try:
        # Initialize components
        print("🔍 Initializing PR Health Score Agent...")
        
        github_token = os.getenv('GITHUB_TOKEN')
        pr_collector = PRCollector(github_token)
        
        # Use comprehensive scoring system (13 categories)
        score_calculator = ComprehensiveScoreCalculator(config)
        
        # Use comprehensive comment generator
        comment_generator = ComprehensiveCommentGenerator(config)
        
        # Initialize dependency scanner
        dependency_scanner = DependencyScanner(github_token)
        
        merge_controller = MergeController(github_token, config)
        
        # Fetch PR data
        print(f"📥 Fetching PR #{args.pr_number} from {args.repository}...")
        pr_data = pr_collector.get_pr_data(args.repository, args.pr_number)
        
        if args.verbose:
            print(f"  ✓ Title: {pr_data.title}")
            print(f"  ✓ Author: {pr_data.author}")
            print(f"  ✓ Files changed: {pr_data.changed_files}")
            print(f"  ✓ Lines: +{pr_data.additions} / -{pr_data.deletions}")
        
        # Run dependency scan
        print("🔒 Scanning dependencies for vulnerabilities...")
        try:
            dependency_report = dependency_scanner.scan_repository(args.repository)
            dependency_changes = dependency_scanner.check_pr_dependencies(
                args.repository,
                pr_data.files
            )
            
            if args.verbose:
                if dependency_report.get('enabled'):
                    print(f"  ✓ Dependabot: Enabled")
                    print(f"  ✓ Open vulnerabilities: {dependency_report.get('open_alerts', 0)}")
                    if dependency_report.get('critical_count', 0) > 0:
                        print(f"  🚨 CRITICAL: {dependency_report['critical_count']} critical vulnerabilities!")
                else:
                    print(f"  ⚠️  Dependabot: Not enabled or no access")
        except Exception as e:
            if args.verbose:
                print(f"  ⚠️  Dependency scan failed: {str(e)}")
            dependency_report = None
            dependency_changes = None
        
        # AI Analysis (optional)
        complexity_analysis = None
        impact_analysis = None
        ai_analyzer = None
        
        if args.ai_analysis:
            # Check if any AI provider is available
            has_gemini = os.getenv('GEMINI_API_KEY')
            has_bedrock = os.getenv('BEDROCK_API_KEY')
            
            if not has_gemini and not has_bedrock:
                print("⚠️  AI analysis requested but no AI provider configured.")
                print("    Set GEMINI_API_KEY or BEDROCK_API_KEY. Skipping AI features.")
            else:
                print("🤖 Running AI-powered analysis...")
                
                try:
                    # Auto-detect provider or use configured one
                    provider = os.getenv('AI_PROVIDER', 'gemini' if has_gemini else 'bedrock')
                    
                    ai_analyzer = AIAnalyzer(
                        provider=provider,
                        region=os.getenv('AWS_REGION', 'us-east-1'),
                        model=os.getenv('GEMINI_MODEL') if provider == 'gemini' else None
                    )
                    
                    print("  - Analyzing complexity...")
                    complexity_analysis = ai_analyzer.analyze_pr_complexity(pr_data)
                    
                    print("  - Analyzing impact...")
                    impact_analysis = ai_analyzer.analyze_pr_impact(pr_data)
                    
                    if args.verbose:
                        print(f"  ✓ Complexity: {complexity_analysis.get('complexity_level', 'N/A')}")
                        print(f"  ✓ Impact: {impact_analysis.get('impact_level', 'N/A')}")
                
                except Exception as e:
                    print(f"  ⚠️  AI analysis failed: {str(e)}")
                    print("  Continuing with basic analysis...")
                    ai_analyzer = None
        
        # Calculate comprehensive health score (13 categories)
        print("📊 Calculating comprehensive health score (13 categories)...")
        score_breakdown = score_calculator.calculate_comprehensive_score(
            pr_data
        )
        
        if args.verbose:
            print(f"  ✓ Total Score: {score_breakdown.total_score:.1f}/100")
            print(f"  ✓ PR Review: {score_breakdown.pr_review_score:.1f}/70")
            print(f"  ✓ Impact Analysis: {score_breakdown.impact_analysis_score:.1f}/30")
            if score_breakdown.missing_data:
                print(f"  ⚠️  Missing data: {', '.join(score_breakdown.missing_data)}")
        
        # Generate AI review comments if analysis was done
        ai_comments = []
        if args.ai_analysis and ai_analyzer and complexity_analysis:
            print("💬 Generating AI recommendations...")
            try:
                ai_comments = ai_analyzer.get_quality_recommendations(
                    pr_data,
                    score_breakdown.total_score
                )
            except Exception as e:
                print(f"  ⚠️  Failed to generate AI recommendations: {str(e)}")
        
        # Generate report
        health_report = comment_generator.generate_comprehensive_report(
            pr_data,
            score_breakdown,
            complexity_analysis,
            impact_analysis,
            ai_comments,
            dependency_changes
        )
        
        # Output results
        if args.output in ['console', 'both']:
            print("\n" + "="*60)
            print(comment_generator.generate_quick_summary(score_breakdown))
            print("="*60)
        
        if args.output in ['json', 'both']:
            import json
            result = {
                'pr': {
                    'repository': args.repository,
                    'number': args.pr_number,
                    'title': pr_data.title,
                    'author': pr_data.author,
                    'url': pr_data.url
                },
                'score': score_breakdown.to_dict(),
                'complexity': complexity_analysis,
                'impact': impact_analysis
            }
            print("\n" + json.dumps(result, indent=2))
        
        # Post comment if requested
        if args.post_comment:
            print("\n💬 Posting health report to PR...")
            success = pr_collector.post_comment(args.repository, args.pr_number, health_report)
            if success:
                print("  ✓ Comment posted successfully")
            else:
                print("  ✗ Failed to post comment")
        
        # Handle merge decision
        exit_code = handle_merge_decision(
            merge_controller,
            args.repository,
            args.pr_number,
            score_breakdown.total_score,
            pr_data,
            add_labels=args.add_labels,
            add_status=args.add_status
        )
        
        # Exit with appropriate code
        if args.no_block:
            print("\n✓ Analysis complete (--no-block mode)")
            sys.exit(0)
        else:
            sys.exit(exit_code)
        
    except KeyboardInterrupt:
        print("\n\n⚠️  Interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n❌ Error: {str(e)}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
