"""
PR Data Collector Module
Fetches PR details from GitHub API including files, reviews, comments, and metadata.
"""

from typing import Dict, List, Any, Optional
from github import Github, GithubException
from dataclasses import dataclass, asdict
import re


@dataclass
class PRData:
    """Data class to hold PR information"""
    number: int
    title: str
    description: str
    state: str
    author: str
    base_branch: str
    head_branch: str
    additions: int
    deletions: int
    changed_files: int
    commits: int
    files: List[Dict[str, Any]]
    reviews: List[Dict[str, Any]]
    comments: List[Dict[str, Any]]
    review_comments: List[Dict[str, Any]]
    reviewers: List[str]
    approvals: int
    url: str
    created_at: str
    updated_at: str
    commits_data: List[Dict[str, Any]] = None  # NEW: Detailed commit data
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return asdict(self)


class PRCollector:
    """Collects PR data from GitHub"""
    
    def __init__(self, github_token: str):
        """
        Initialize PR Collector
        
        Args:
            github_token: GitHub personal access token
        """
        from github import Auth
        import urllib3
        
        # Disable SSL warnings for corporate environments
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        # Use new auth method and disable SSL verification
        auth = Auth.Token(github_token)
        self.github = Github(auth=auth, verify=False)
    
    def get_pr_data(self, repo_name: str, pr_number: int) -> PRData:
        """
        Fetch comprehensive PR data
        
        Args:
            repo_name: Repository name in format 'owner/repo'
            pr_number: Pull request number
            
        Returns:
            PRData object with all PR information
            
        Raises:
            GithubException: If PR or repository not found
        """
        try:
            repo = self.github.get_repo(repo_name)
            pr = repo.get_pull(pr_number)
            
            # Get basic PR info
            basic_info = {
                'number': pr.number,
                'title': pr.title,
                'description': pr.body or '',
                'state': pr.state,
                'author': pr.user.login,
                'base_branch': pr.base.ref,
                'head_branch': pr.head.ref,
                'additions': pr.additions,
                'deletions': pr.deletions,
                'changed_files': pr.changed_files,
                'commits': pr.commits,
                'url': pr.html_url,
                'created_at': pr.created_at.isoformat(),
                'updated_at': pr.updated_at.isoformat(),
            }
            
            # Get files
            files = self._get_files(pr)
            
            # Get reviews
            reviews = self._get_reviews(pr)
            
            # Get comments
            comments = self._get_comments(pr)
            
            # Get review comments (inline code comments)
            review_comments = self._get_review_comments(pr)
            
            # Get reviewers and approvals
            reviewers, approvals = self._get_reviewers_and_approvals(reviews)
            
            # Get commit details
            commits_data = self._get_commits(pr)
            
            return PRData(
                **basic_info,
                files=files,
                reviews=reviews,
                comments=comments,
                review_comments=review_comments,
                reviewers=reviewers,
                approvals=approvals,
                commits_data=commits_data
            )
            
        except GithubException as e:
            raise Exception(f"Failed to fetch PR data: {str(e)}")
    
    def _get_files(self, pr) -> List[Dict[str, Any]]:
        """Get list of changed files with details"""
        files = []
        for file in pr.get_files():
            files.append({
                'filename': file.filename,
                'status': file.status,  # added, modified, removed, renamed
                'additions': file.additions,
                'deletions': file.deletions,
                'changes': file.changes,
                'patch': file.patch if hasattr(file, 'patch') else None,
            })
        return files
    
    def _get_reviews(self, pr) -> List[Dict[str, Any]]:
        """Get PR reviews"""
        reviews = []
        for review in pr.get_reviews():
            reviews.append({
                'id': review.id,
                'user': review.user.login,
                'state': review.state,  # APPROVED, CHANGES_REQUESTED, COMMENTED, DISMISSED
                'body': review.body or '',
                'submitted_at': review.submitted_at.isoformat() if review.submitted_at else None,
            })
        return reviews
    
    def _get_comments(self, pr) -> List[Dict[str, Any]]:
        """Get PR issue comments"""
        comments = []
        for comment in pr.get_issue_comments():
            comments.append({
                'id': comment.id,
                'user': comment.user.login,
                'body': comment.body,
                'created_at': comment.created_at.isoformat(),
            })
        return comments
    
    def _get_review_comments(self, pr) -> List[Dict[str, Any]]:
        """Get PR review comments (inline code comments)"""
        review_comments = []
        for comment in pr.get_review_comments():
            review_comments.append({
                'id': comment.id,
                'user': comment.user.login,
                'body': comment.body,
                'path': comment.path,
                'position': comment.position,
                'created_at': comment.created_at.isoformat(),
            })
        return review_comments
    
    def _get_reviewers_and_approvals(self, reviews: List[Dict[str, Any]]) -> tuple:
        """
        Extract unique reviewers and count approvals
        
        Returns:
            Tuple of (reviewers list, approval count)
        """
        reviewers = set()
        approvals = 0
        
        for review in reviews:
            reviewers.add(review['user'])
            if review['state'] == 'APPROVED':
                approvals += 1
        
        return list(reviewers), approvals
    
    def _get_commits(self, pr) -> List[Dict[str, Any]]:
        """
        Get detailed commit information
        
        Returns:
            List of commit dictionaries
        """
        commits_data = []
        try:
            for commit in pr.get_commits():
                commits_data.append({
                    'sha': commit.sha,
                    'message': commit.commit.message,
                    'author': commit.commit.author.name if commit.commit.author else 'Unknown',
                    'date': commit.commit.author.date.isoformat() if commit.commit.author and commit.commit.author.date else None,
                    'additions': commit.stats.additions if commit.stats else 0,
                    'deletions': commit.stats.deletions if commit.stats else 0,
                })
        except Exception as e:
            print(f"Warning: Could not fetch commit details: {str(e)}")
        
        return commits_data
    
    def post_comment(self, repo_name: str, pr_number: int, comment: str) -> bool:
        """
        Post a comment to the PR
        
        Args:
            repo_name: Repository name in format 'owner/repo'
            pr_number: Pull request number
            comment: Comment text to post
            
        Returns:
            True if successful, False otherwise
        """
        try:
            repo = self.github.get_repo(repo_name)
            pr = repo.get_pull(pr_number)
            pr.create_issue_comment(comment)
            return True
        except GithubException as e:
            print(f"Failed to post comment: {str(e)}")
            return False
    
    def can_merge(self, repo_name: str, pr_number: int) -> bool:
        """
        Check if PR is mergeable
        
        Args:
            repo_name: Repository name in format 'owner/repo'
            pr_number: Pull request number
            
        Returns:
            True if mergeable, False otherwise
        """
        try:
            repo = self.github.get_repo(repo_name)
            pr = repo.get_pull(pr_number)
            return pr.mergeable if pr.mergeable is not None else False
        except GithubException:
            return False
