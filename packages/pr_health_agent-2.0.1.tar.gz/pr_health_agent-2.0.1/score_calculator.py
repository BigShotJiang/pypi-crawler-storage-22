"""
PR Health Score Calculator
Calculates health scores based on multiple factors:
- Size (lines changed, files impacted)
- Test coverage (test files ratio)
- Review quality (reviewers, approvals, comments)
- Complexity (will be enhanced with AI analysis)
- Description quality
"""

from typing import Dict, Any, List
from dataclasses import dataclass
import re
import fnmatch


@dataclass
class ScoreBreakdown:
    """Detailed score breakdown"""
    size_score: float
    size_details: Dict[str, Any]
    
    commit_quality_score: float
    commit_quality_details: Dict[str, Any]
    
    test_quality_score: float
    test_quality_details: Dict[str, Any]
    
    review_quality_score: float
    review_quality_details: Dict[str, Any]
    
    complexity_score: float
    complexity_details: Dict[str, Any]
    
    security_score: float
    security_details: Dict[str, Any]
    
    code_quality_score: float
    code_quality_details: Dict[str, Any]
    
    documentation_score: float
    documentation_details: Dict[str, Any]
    
    total_score: float
    category: str  # excellent, good, needs_improvement, poor
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'total_score': self.total_score,
            'category': self.category,
            'breakdown': {
                'size': {
                    'score': self.size_score,
                    'details': self.size_details
                },
                'commit_quality': {
                    'score': self.commit_quality_score,
                    'details': self.commit_quality_details
                },
                'test_quality': {
                    'score': self.test_quality_score,
                    'details': self.test_quality_details
                },
                'review_quality': {
                    'score': self.review_quality_score,
                    'details': self.review_quality_details
                },
                'complexity': {
                    'score': self.complexity_score,
                    'details': self.complexity_details
                },
                'security': {
                    'score': self.security_score,
                    'details': self.security_details
                },
                'code_quality': {
                    'score': self.code_quality_score,
                    'details': self.code_quality_details
                },
                'documentation': {
                    'score': self.documentation_score,
                    'details': self.documentation_details
                }
            }
        }


class HealthScoreCalculator:
    """Calculates PR health scores"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize calculator with configuration
        
        Args:
            config: Configuration dictionary from config.yaml
        """
        self.config = config
        self.weights = config['weights']
        self.size_limits = config['size_limits']
        self.test_config = config.get('test_quality', config.get('test_coverage', {}))
        self.review_config = config['review_quality']
    
    def calculate_score(self, pr_data: Any, 
                       security_report: Dict[str, Any] = None,
                       coverage_report: Dict[str, Any] = None,
                       commit_report: Dict[str, Any] = None,
                       quality_report: Dict[str, Any] = None,
                       complexity_analysis: Dict[str, Any] = None) -> ScoreBreakdown:
        """
        Calculate overall health score
        
        Args:
            pr_data: PRData object
            security_report: Security scan report
            coverage_report: Coverage analysis report
            commit_report: Commit quality report
            quality_report: Code quality report
            complexity_analysis: Optional AI-generated complexity analysis
            
        Returns:
            ScoreBreakdown with detailed scoring
        """
        # Calculate individual scores
        size_score, size_details = self._calculate_size_score(pr_data)
        commit_score, commit_details = self._get_commit_score(commit_report)
        test_score, test_details = self._get_test_quality_score(coverage_report, pr_data)
        review_score, review_details = self._calculate_review_quality_score(pr_data)
        complexity_score, complexity_details = self._calculate_complexity_score(pr_data, complexity_analysis)
        security_score, security_details = self._get_security_score(security_report)
        quality_score, quality_details = self._get_code_quality_score(quality_report)
        doc_score, doc_details = self._calculate_description_score(pr_data)
        
        # Calculate weighted total
        total_score = (
            (size_score * self.weights['size'] / 100) +
            (commit_score * self.weights['commit_quality'] / 100) +
            (test_score * self.weights['test_quality'] / 100) +
            (review_score * self.weights['review_quality'] / 100) +
            (complexity_score * self.weights['complexity'] / 100) +
            (security_score * self.weights['security'] / 100) +
            (quality_score * self.weights['code_quality'] / 100) +
            (doc_score * self.weights['documentation'] / 100)
        )
        
        # Determine category
        category = self._get_category(total_score)
        
        return ScoreBreakdown(
            size_score=size_score,
            size_details=size_details,
            commit_quality_score=commit_score,
            commit_quality_details=commit_details,
            test_quality_score=test_score,
            test_quality_details=test_details,
            review_quality_score=review_score,
            review_quality_details=review_details,
            complexity_score=complexity_score,
            complexity_details=complexity_details,
            security_score=security_score,
            security_details=security_details,
            code_quality_score=quality_score,
            code_quality_details=quality_details,
            documentation_score=doc_score,
            documentation_details=doc_details,
            total_score=round(total_score, 1),
            category=category
        )
    
    def _calculate_size_score(self, pr_data) -> tuple:
        """
        Calculate size score (0-100) based on multi-factor analysis
        Considers: lines changed, files impacted, commits count
        """
        total_changes = pr_data.additions + pr_data.deletions
        files_count = pr_data.changed_files
        commits_count = pr_data.commits
        
        # Multi-factor size determination
        small_limits = self.size_limits['small']
        medium_limits = self.size_limits['medium']
        complex_limits = self.size_limits['complex']
        very_complex_limits = self.size_limits['very_complex']
        
        # Determine category based on all factors
        if (total_changes < small_limits['lines'] and 
            files_count <= small_limits['files'] and 
            commits_count <= small_limits['commits']):
            category = 'small'
            base_score = 100
        elif (total_changes < medium_limits['lines'] and 
              files_count <= medium_limits['files'] and 
              commits_count <= medium_limits['commits']):
            category = 'medium'
            base_score = 85
        elif (complex_limits['lines_min'] <= total_changes <= complex_limits['lines_max'] and 
              files_count < complex_limits['files'] and 
              commits_count <= complex_limits['commits']):
            category = 'complex'
            base_score = 70
        else:
            category = 'very_complex'
            base_score = 50
        
        score = max(0, min(100, base_score))
        
        details = {
            'category': category,
            'total_changes': total_changes,
            'additions': pr_data.additions,
            'deletions': pr_data.deletions,
            'files_count': files_count,
            'commits': commits_count,
            'recommendation': self._get_size_recommendation(category)
        }
        
        return score, details
    
    def _calculate_test_coverage_score(self, pr_data) -> tuple:
        """
        Calculate test coverage score based on test file ratio
        """
        if not pr_data.files:
            return 0, {'test_files': 0, 'total_files': 0, 'ratio': 0}
        
        test_patterns = self.test_config['test_file_patterns']
        test_files = []
        non_test_files = []
        
        for file in pr_data.files:
            filename = file['filename']
            is_test = any(fnmatch.fnmatch(filename, pattern) for pattern in test_patterns)
            
            if is_test:
                test_files.append(filename)
            else:
                non_test_files.append(filename)
        
        total_files = len(pr_data.files)
        test_count = len(test_files)
        ratio = test_count / total_files if total_files > 0 else 0
        
        # Calculate score
        min_ratio = self.test_config['min_test_files_ratio']
        
        if ratio >= min_ratio:
            score = 100
        elif ratio > 0:
            # Partial credit
            score = (ratio / min_ratio) * 100
        else:
            # Check if only test files were changed (maintenance)
            if test_count == total_files and test_count > 0:
                score = 100
            else:
                score = 0
        
        details = {
            'test_files': test_count,
            'total_files': total_files,
            'ratio': round(ratio * 100, 1),
            'test_file_list': test_files,
            'expected_ratio': min_ratio * 100,
            'recommendation': self._get_test_recommendation(ratio, min_ratio)
        }
        
        return min(100, score), details
    
    def _calculate_review_quality_score(self, pr_data) -> tuple:
        """
        Calculate review quality score
        """
        reviewers_count = len(pr_data.reviewers)
        approvals = pr_data.approvals
        total_comments = len(pr_data.review_comments) + len(pr_data.comments)
        
        # Calculate expected comments based on PR size
        total_changes = pr_data.additions + pr_data.deletions
        expected_comments = max(1, (total_changes / 100) * self.review_config['min_comments_per_100_lines'])
        
        score = 0
        
        # Reviewers score (40 points)
        if reviewers_count >= self.review_config['min_reviewers']:
            score += 40
        else:
            score += (reviewers_count / self.review_config['min_reviewers']) * 40
        
        # Approvals score (40 points)
        if approvals >= self.review_config['min_approvals']:
            score += 40
        else:
            score += (approvals / self.review_config['min_approvals']) * 40
        
        # Comments score (20 points)
        if total_comments >= expected_comments:
            score += 20
        else:
            score += (total_comments / expected_comments) * 20
        
        details = {
            'reviewers': reviewers_count,
            'approvals': approvals,
            'total_comments': total_comments,
            'expected_comments': round(expected_comments, 1),
            'reviewer_list': pr_data.reviewers,
            'recommendation': self._get_review_recommendation(reviewers_count, approvals, total_comments, expected_comments)
        }
        
        return min(100, score), details
    
    def _calculate_complexity_score(self, pr_data, complexity_analysis: Dict[str, Any] = None) -> tuple:
        """
        Calculate complexity score
        Uses AI analysis if available, otherwise uses heuristics
        """
        if complexity_analysis and 'score' in complexity_analysis:
            # Use AI-generated score
            score = complexity_analysis['score']
            details = complexity_analysis
        else:
            # Use heuristics
            score = 70  # Default moderate complexity
            
            # Analyze file types
            code_extensions = {'.py', '.js', '.ts', '.java', '.cpp', '.c', '.go', '.rs', '.rb'}
            config_extensions = {'.json', '.yaml', '.yml', '.toml', '.xml', '.ini'}
            
            code_files = 0
            config_files = 0
            
            for file in pr_data.files:
                ext = '.' + file['filename'].split('.')[-1] if '.' in file['filename'] else ''
                if ext in code_extensions:
                    code_files += 1
                elif ext in config_extensions:
                    config_files += 1
            
            # More code files = potentially more complex
            if code_files > 10:
                score -= 20
            elif code_files > 5:
                score -= 10
            
            # Config-only changes are usually simpler
            if config_files > 0 and code_files == 0:
                score += 20
            
            details = {
                'assessment': 'Heuristic-based analysis',
                'code_files': code_files,
                'config_files': config_files,
                'recommendation': 'Consider AI-powered analysis for detailed complexity assessment'
            }
        
        return max(0, min(100, score)), details
    
    def _calculate_description_score(self, pr_data) -> tuple:
        """
        Calculate description quality score
        """
        description = pr_data.description or ''
        title = pr_data.title or ''
        
        score = 0
        issues = []
        
        # Title checks (30 points)
        if len(title) >= 10:
            score += 20
        else:
            issues.append("Title is too short")
        
        if not title.isupper():  # Not all caps
            score += 10
        else:
            issues.append("Title is all caps")
        
        # Description checks (70 points)
        if len(description) >= 50:
            score += 30
        elif len(description) >= 20:
            score += 15
        else:
            issues.append("Description is too short")
        
        # Check for common sections
        has_context = any(keyword in description.lower() for keyword in ['why', 'because', 'reason', 'context'])
        has_changes = any(keyword in description.lower() for keyword in ['changes', 'what', 'modified', 'added', 'updated'])
        has_testing = any(keyword in description.lower() for keyword in ['test', 'tested', 'testing', 'qa'])
        
        if has_context:
            score += 15
        else:
            issues.append("Missing context/reason")
        
        if has_changes:
            score += 15
        else:
            issues.append("Missing change description")
        
        if has_testing:
            score += 10
        else:
            issues.append("Missing testing information")
        
        details = {
            'title_length': len(title),
            'description_length': len(description),
            'has_context': has_context,
            'has_changes': has_changes,
            'has_testing': has_testing,
            'issues': issues,
            'recommendation': self._get_description_recommendation(issues)
        }
        
        return min(100, score), details
    
    def _get_category(self, score: float) -> str:
        """Determine score category"""
        if score >= self.config['thresholds']['excellent_score']:
            return 'excellent'
        elif score >= self.config['thresholds']['min_passing_score']:
            return 'good'
        elif score >= 50:
            return 'needs_improvement'
        else:
            return 'poor'
    
    def _get_size_recommendation(self, category: str) -> str:
        """Get size-based recommendation"""
        recommendations = {
            'small': 'Excellent! Small PRs are easier to review.',
            'medium': 'Good size. Consider splitting if possible.',
            'complex': 'This PR is complex. Consider breaking into smaller PRs.',
            'very_complex': 'This PR is very complex. Strongly recommend splitting into multiple smaller PRs.'
        }
        return recommendations.get(category, '')
    
    def _get_commit_score(self, commit_report: Dict[str, Any] = None) -> tuple:
        """Get commit quality score from report"""
        if not commit_report:
            return 50.0, {'message': 'Commit analysis not available'}
        
        return commit_report['score'], commit_report
    
    def _get_test_quality_score(self, coverage_report: Dict[str, Any] = None, pr_data: Any = None) -> tuple:
        """Get test quality score from coverage report"""
        if not coverage_report:
            # Fallback to old test file ratio method
            if pr_data:
                return self._calculate_test_coverage_score(pr_data)
            return 50.0, {'message': 'Coverage analysis not available'}
        
        return coverage_report['score'], coverage_report
    
    def _get_security_score(self, security_report: Dict[str, Any] = None) -> tuple:
        """Get security score from report"""
        if not security_report:
            return 100.0, {'message': 'Security scan not performed'}
        
        return security_report['score'], security_report
    
    def _get_code_quality_score(self, quality_report: Dict[str, Any] = None) -> tuple:
        """Get code quality score from report"""
        if not quality_report:
            return 75.0, {'message': 'Code quality analysis not available'}
        
        return quality_report['score'], quality_report
    
    def _get_test_recommendation(self, ratio: float, min_ratio: float) -> str:
        """Get test coverage recommendation"""
        if ratio >= min_ratio:
            return 'Good test coverage!'
        elif ratio > 0:
            return f'Add more tests. Current ratio: {ratio*100:.1f}%, expected: {min_ratio*100:.1f}%'
        else:
            return 'No test files detected. Please add tests for your changes.'
    
    def _get_review_recommendation(self, reviewers: int, approvals: int, comments: int, expected: float) -> str:
        """Get review quality recommendation"""
        issues = []
        if reviewers < self.review_config['min_reviewers']:
            issues.append('needs more reviewers')
        if approvals < self.review_config['min_approvals']:
            issues.append('needs approval')
        if comments < expected:
            issues.append('could benefit from more review feedback')
        
        if not issues:
            return 'Good review coverage!'
        return 'This PR ' + ', '.join(issues) + '.'
    
    def _get_description_recommendation(self, issues: List[str]) -> str:
        """Get description quality recommendation"""
        if not issues:
            return 'Well-documented PR!'
        return 'Improve PR description: ' + ', '.join(issues)
