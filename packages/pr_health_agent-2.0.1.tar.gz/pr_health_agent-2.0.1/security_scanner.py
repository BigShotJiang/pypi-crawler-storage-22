"""
Security Scanner Module
Scans PR for security issues including secrets, credentials, and vulnerabilities
"""

import re
import os
from typing import Dict, Any, List
from dataclasses import dataclass


@dataclass
class SecurityIssue:
    """Represents a security issue found in the PR"""
    severity: str  # critical, high, medium, low
    type: str  # secret, hardcoded_credential, sql_injection, xss, etc.
    file: str
    line: int
    description: str
    recommendation: str


class SecurityScanner:
    """Scans PRs for security vulnerabilities"""
    
    # Common secret patterns
    SECRET_PATTERNS = {
        'github_token': {
            'pattern': r'ghp_[a-zA-Z0-9]{36}',
            'description': 'GitHub Personal Access Token',
            'severity': 'critical'
        },
        'aws_access_key': {
            'pattern': r'AKIA[0-9A-Z]{16}',
            'description': 'AWS Access Key ID',
            'severity': 'critical'
        },
        'aws_secret_key': {
            'pattern': r'aws_secret_access_key\s*=\s*["\']?([a-zA-Z0-9/+=]{40})["\']?',
            'description': 'AWS Secret Access Key',
            'severity': 'critical'
        },
        'generic_api_key': {
            'pattern': r'(?i)(api[_-]?key|apikey|api[_-]?secret)\s*[:=]\s*["\']([a-zA-Z0-9_\-]{20,})["\']',
            'description': 'Generic API Key',
            'severity': 'high'
        },
        'password': {
            'pattern': r'(?i)(password|passwd|pwd)\s*[:=]\s*["\']([^"\']{8,})["\']',
            'description': 'Hardcoded Password',
            'severity': 'high'
        },
        'private_key': {
            'pattern': r'-----BEGIN (RSA |DSA )?PRIVATE KEY-----',
            'description': 'Private Key',
            'severity': 'critical'
        },
        'slack_token': {
            'pattern': r'xox[baprs]-[0-9a-zA-Z]{10,48}',
            'description': 'Slack Token',
            'severity': 'high'
        },
        'stripe_key': {
            'pattern': r'sk_live_[0-9a-zA-Z]{24,}',
            'description': 'Stripe Live Secret Key',
            'severity': 'critical'
        },
        'google_api_key': {
            'pattern': r'AIza[0-9A-Za-z_-]{35}',
            'description': 'Google API Key',
            'severity': 'high'
        },
        'jwt_token': {
            'pattern': r'eyJ[a-zA-Z0-9_-]*\.eyJ[a-zA-Z0-9_-]*\.[a-zA-Z0-9_-]*',
            'description': 'JWT Token',
            'severity': 'medium'
        }
    }
    
    # SQL Injection patterns
    SQL_INJECTION_PATTERNS = [
        r'execute\s*\(\s*["\'].*%s.*["\']',
        r'cursor\.execute\s*\(\s*.*\+.*\)',
        r'query\s*=\s*["\'].*["\'].*\+',
        r'SELECT.*FROM.*WHERE.*=.*\+',
    ]
    
    # XSS patterns
    XSS_PATTERNS = [
        r'innerHTML\s*=',
        r'document\.write\s*\(',
        r'eval\s*\(',
        r'dangerouslySetInnerHTML',
    ]
    
    # Insecure functions
    INSECURE_FUNCTIONS = {
        'pickle.loads': 'Use JSON instead of pickle for untrusted data',
        'eval(': 'Avoid using eval() - use ast.literal_eval() or json.loads()',
        'exec(': 'Avoid using exec() - security risk',
        'os.system(': 'Use subprocess.run() instead of os.system()',
        'shell=True': 'Avoid shell=True in subprocess calls',
        'yaml.load(': 'Use yaml.safe_load() instead of yaml.load()',
        'md5(': 'MD5 is cryptographically broken - use SHA256 or better',
        'sha1(': 'SHA1 is weak - use SHA256 or better',
    }
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize security scanner
        
        Args:
            config: Configuration dictionary
        """
        self.config = config
        self.issues = []
    
    def scan_pr(self, pr_data: Any) -> Dict[str, Any]:
        """
        Scan PR for security issues
        
        Args:
            pr_data: PRData object
            
        Returns:
            Dictionary with security report and score
        """
        self.issues = []
        
        # Scan each file
        for file_data in pr_data.files:
            if file_data['patch']:
                self._scan_file(file_data)
        
        # Calculate score
        score = self._calculate_security_score()
        
        return {
            'score': score,
            'issues': [self._issue_to_dict(issue) for issue in self.issues],
            'critical_count': len([i for i in self.issues if i.severity == 'critical']),
            'high_count': len([i for i in self.issues if i.severity == 'high']),
            'medium_count': len([i for i in self.issues if i.severity == 'medium']),
            'low_count': len([i for i in self.issues if i.severity == 'low']),
            'passed': score >= 70
        }
    
    def _scan_file(self, file_data: Dict[str, Any]):
        """Scan individual file for security issues"""
        filename = file_data['filename']
        patch = file_data['patch']
        
        # Skip certain file types
        skip_extensions = ['.md', '.txt', '.json', '.yaml', '.yml', '.lock', '.min.js']
        if any(filename.endswith(ext) for ext in skip_extensions):
            return
        
        # Parse patch to get line numbers and content
        lines = patch.split('\n')
        current_line = 0
        
        for line in lines:
            # Track line numbers from diff
            if line.startswith('@@'):
                match = re.search(r'\+(\d+)', line)
                if match:
                    current_line = int(match.group(1))
                continue
            
            if line.startswith('+') and not line.startswith('+++'):
                current_line += 1
                line_content = line[1:]  # Remove the + prefix
                
                # Scan for secrets
                self._scan_for_secrets(filename, current_line, line_content)
                
                # Scan for SQL injection
                self._scan_for_sql_injection(filename, current_line, line_content)
                
                # Scan for XSS
                self._scan_for_xss(filename, current_line, line_content)
                
                # Scan for insecure functions
                self._scan_for_insecure_functions(filename, current_line, line_content)
    
    def _scan_for_secrets(self, filename: str, line_num: int, content: str):
        """Scan for hardcoded secrets"""
        for secret_type, secret_info in self.SECRET_PATTERNS.items():
            if re.search(secret_info['pattern'], content):
                # Avoid false positives for example/placeholder values
                if self._is_likely_example(content):
                    continue
                
                self.issues.append(SecurityIssue(
                    severity=secret_info['severity'],
                    type=f'secret_{secret_type}',
                    file=filename,
                    line=line_num,
                    description=f'Potential {secret_info["description"]} detected',
                    recommendation='Remove hardcoded secrets. Use environment variables or secret management systems.'
                ))
    
    def _scan_for_sql_injection(self, filename: str, line_num: int, content: str):
        """Scan for SQL injection vulnerabilities"""
        if not (filename.endswith('.py') or filename.endswith('.js')):
            return
        
        for pattern in self.SQL_INJECTION_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE):
                self.issues.append(SecurityIssue(
                    severity='high',
                    type='sql_injection',
                    file=filename,
                    line=line_num,
                    description='Potential SQL injection vulnerability',
                    recommendation='Use parameterized queries or ORM instead of string concatenation.'
                ))
    
    def _scan_for_xss(self, filename: str, line_num: int, content: str):
        """Scan for XSS vulnerabilities"""
        if not (filename.endswith('.js') or filename.endswith('.jsx') or 
                filename.endswith('.ts') or filename.endswith('.tsx')):
            return
        
        for pattern in self.XSS_PATTERNS:
            if re.search(pattern, content):
                self.issues.append(SecurityIssue(
                    severity='medium',
                    type='xss',
                    file=filename,
                    line=line_num,
                    description='Potential XSS vulnerability',
                    recommendation='Sanitize user input and use safe DOM manipulation methods.'
                ))
    
    def _scan_for_insecure_functions(self, filename: str, line_num: int, content: str):
        """Scan for usage of insecure functions"""
        for func, recommendation in self.INSECURE_FUNCTIONS.items():
            if func in content:
                self.issues.append(SecurityIssue(
                    severity='medium',
                    type='insecure_function',
                    file=filename,
                    line=line_num,
                    description=f'Usage of insecure function: {func}',
                    recommendation=recommendation
                ))
    
    def _is_likely_example(self, content: str) -> bool:
        """Check if the content is likely an example/placeholder"""
        example_indicators = [
            'example', 'placeholder', 'your_', 'xxx', 'test', 'dummy',
            'sample', 'demo', 'TODO', 'FIXME', '<your', 'replace_me'
        ]
        content_lower = content.lower()
        return any(indicator in content_lower for indicator in example_indicators)
    
    def _calculate_security_score(self) -> float:
        """
        Calculate security score based on issues found
        
        Returns:
            Score from 0-100
        """
        if not self.issues:
            return 100.0
        
        # Deduct points based on severity
        deductions = {
            'critical': 30,
            'high': 15,
            'medium': 8,
            'low': 3
        }
        
        total_deduction = 0
        for issue in self.issues:
            total_deduction += deductions.get(issue.severity, 5)
        
        # Cap deduction at 100
        total_deduction = min(total_deduction, 100)
        
        return max(0, 100 - total_deduction)
    
    def _issue_to_dict(self, issue: SecurityIssue) -> Dict[str, Any]:
        """Convert SecurityIssue to dictionary"""
        return {
            'severity': issue.severity,
            'type': issue.type,
            'file': issue.file,
            'line': issue.line,
            'description': issue.description,
            'recommendation': issue.recommendation
        }
