"""
PR Health Score Agent - Setup Configuration
Enables installation via pip for end users
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README for long description
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

setup(
    name="pr-health-agent",
    version="2.0.1",
    author="LTIM Digital Engineering",
    author_email="your-email@ltimindtree.com",
    description="Comprehensive GitHub PR health scoring with AI-powered analysis",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/LTIM-Digital-Engineering/PR-Review-Agent",
    packages=find_packages(),
    py_modules=[
        'pr_agent',
        'pr_collector',
        'score_calculator',
        'comprehensive_score_calculator',
        'ai_analyzer',
        'bedrock_analyzer',
        'comment_generator',
        'comprehensive_comment_generator',
        'merge_controller',
        'dependency_scanner',
        'interactive',
        'app',
        'setup_check',
        'enhanced_size_analyzer',
        'changelog_analyzer',
        'codeowners_analyzer',
        'breaking_changes_analyzer',
        'commit_analyzer',
        'coverage_analyzer',
        'code_quality_analyzer',
        'security_scanner'
    ],
    include_package_data=True,
    package_data={
        '': ['config.yaml', '.env.example', 'README.md'],
    },
    install_requires=[
        'PyGithub>=2.1.1',
        'pyyaml>=6.0.1',
        'requests>=2.31.0',
        'python-dotenv>=1.0.0',
        'click>=8.1.7',
        'rich>=13.7.0',
        'urllib3>=1.26.0,<2.0.0',
    ],
    extras_require={
        'bedrock': ['boto3>=1.34.0'],
        'all': ['boto3>=1.34.0'],
    },
    entry_points={
        'console_scripts': [
            'pr-health=pr_agent:main',
            'pr-health-interactive=interactive:main',
            'pr-health-app=app:main',
        ],
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Quality Assurance',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
    ],
    python_requires='>=3.8',
    keywords='github pull-request code-review quality-analysis ai automation',
    project_urls={
        'Bug Reports': 'https://github.com/LTIM-Digital-Engineering/PR-Review-Agent/issues',
        'Source': 'https://github.com/LTIM-Digital-Engineering/PR-Review-Agent',
        'Documentation': 'https://github.com/LTIM-Digital-Engineering/PR-Review-Agent#readme',
    },
)
