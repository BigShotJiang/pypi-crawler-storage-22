"""
Setup and Validation Script
Run this to verify your environment is configured correctly
"""

import os
import sys
from pathlib import Path


def check_file_exists(filepath, description):
    """Check if a file exists"""
    if Path(filepath).exists():
        print(f"✓ {description}: {filepath}")
        return True
    else:
        print(f"✗ {description} not found: {filepath}")
        return False


def check_env_var(var_name, required=True):
    """Check if environment variable is set"""
    value = os.getenv(var_name)
    if value:
        # Mask sensitive values
        if 'KEY' in var_name or 'TOKEN' in var_name or 'SECRET' in var_name:
            display_value = value[:8] + "..." if len(value) > 8 else "***"
        else:
            display_value = value
        print(f"✓ {var_name}: {display_value}")
        return True
    else:
        status = "✗" if required else "⚠"
        print(f"{status} {var_name}: Not set" + (" (required)" if required else " (optional)"))
        return not required


def main():
    print("="*70)
    print("PR Health Score Agent - Setup Validation")
    print("="*70)
    print()
    
    # Check Python version
    print("1. Python Version Check")
    print(f"   Python {sys.version}")
    if sys.version_info >= (3, 8):
        print("   ✓ Python version is compatible (3.8+)")
    else:
        print("   ✗ Python 3.8+ is required")
        sys.exit(1)
    print()
    
    # Check required files
    print("2. Required Files Check")
    files_ok = True
    files_ok &= check_file_exists("config.yaml", "Configuration file")
    files_ok &= check_file_exists("pr_agent.py", "Main script")
    files_ok &= check_file_exists("requirements.txt", "Requirements file")
    
    if not check_file_exists(".env", "Environment file"):
        print("   ℹ  Create .env from .env.example:")
        print("      Copy-Item .env.example .env")
        files_ok = False
    print()
    
    # Check dependencies
    print("3. Python Dependencies Check")
    try:
        import github
        print("   ✓ PyGithub installed")
    except ImportError:
        print("   ✗ PyGithub not installed")
        print("      Run: pip install -r requirements.txt")
        files_ok = False
    
    try:
        import boto3
        print("   ✓ boto3 installed")
    except ImportError:
        print("   ✗ boto3 not installed")
        print("      Run: pip install -r requirements.txt")
        files_ok = False
    
    try:
        import yaml
        print("   ✓ PyYAML installed")
    except ImportError:
        print("   ✗ PyYAML not installed")
        print("      Run: pip install -r requirements.txt")
        files_ok = False
    
    try:
        from dotenv import load_dotenv
        print("   ✓ python-dotenv installed")
    except ImportError:
        print("   ✗ python-dotenv not installed")
        print("      Run: pip install -r requirements.txt")
        files_ok = False
    print()
    
    # Check environment variables
    print("4. Environment Variables Check")
    
    # Load .env if it exists
    env_path = Path('.env')
    if env_path.exists():
        from dotenv import load_dotenv
        load_dotenv(env_path)
        print("   ✓ Loaded .env file")
    
    env_ok = True
    env_ok &= check_env_var("GITHUB_TOKEN", required=True)
    env_ok &= check_env_var("BEDROCK_API_KEY", required=False)
    env_ok &= check_env_var("AWS_REGION", required=False)
    
    if not env_ok:
        print()
        print("   ⚠  BEDROCK_API_KEY is optional but required for AI features")
    print()
    
    # Final summary
    print("="*70)
    print("Setup Summary")
    print("="*70)
    
    if files_ok and env_ok:
        print("✅ All checks passed! You're ready to use the PR Health Score Agent.")
        print()
        print("Quick test command:")
        print("  python pr_agent.py owner/repo PR_NUMBER")
        print()
        print("With AI analysis (requires AWS credentials):")
        print("  python pr_agent.py owner/repo PR_NUMBER --ai-analysis")
        return 0
    else:
        print("⚠️  Some checks failed. Please review the issues above.")
        print()
        print("Common fixes:")
        print("1. Install dependencies: pip install -r requirements.txt")
        print("2. Create .env file: Copy-Item .env.example .env")
        print("3. Edit .env and add your GITHUB_TOKEN")
        return 1


if __name__ == '__main__':
    sys.exit(main())
