from .praatfan_rust import *

__doc__ = praatfan_rust.__doc__
if hasattr(praatfan_rust, "__all__"):
    __all__ = praatfan_rust.__all__