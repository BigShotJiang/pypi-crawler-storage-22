# Sample Markdown

This is a sample markdown file.

## Section 1

Some content here.

## Section 2

More content here.
