# Tests for generate-reference-docs.py
