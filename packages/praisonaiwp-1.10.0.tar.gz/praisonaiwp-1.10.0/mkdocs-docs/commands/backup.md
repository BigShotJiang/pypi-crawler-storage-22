# backup Command

Documentation coming soon.

```bash
praisonaiwp backup --help
```
