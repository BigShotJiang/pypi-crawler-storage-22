# category Command

Documentation coming soon.

```bash
praisonaiwp category --help
```
