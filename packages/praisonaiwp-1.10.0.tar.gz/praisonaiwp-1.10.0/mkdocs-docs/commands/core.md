# core Command

Documentation coming soon.

```bash
praisonaiwp core --help
```
