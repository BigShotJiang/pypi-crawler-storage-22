# export Command

Documentation coming soon.

```bash
praisonaiwp export --help
```
