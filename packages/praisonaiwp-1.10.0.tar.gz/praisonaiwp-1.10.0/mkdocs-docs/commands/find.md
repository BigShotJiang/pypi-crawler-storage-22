# find Command

Documentation coming soon.

```bash
praisonaiwp find --help
```
