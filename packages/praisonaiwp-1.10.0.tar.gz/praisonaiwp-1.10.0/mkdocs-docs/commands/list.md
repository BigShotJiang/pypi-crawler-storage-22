# list Command

Documentation coming soon.

```bash
praisonaiwp list --help
```
