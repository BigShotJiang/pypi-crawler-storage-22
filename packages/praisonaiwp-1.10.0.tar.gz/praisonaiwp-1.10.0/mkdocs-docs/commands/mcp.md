# mcp Command

Documentation coming soon.

```bash
praisonaiwp mcp --help
```
