# media Command

Documentation coming soon.

```bash
praisonaiwp media --help
```
