# plugin Command

Documentation coming soon.

```bash
praisonaiwp plugin --help
```
