# term Command

Documentation coming soon.

```bash
praisonaiwp term --help
```
