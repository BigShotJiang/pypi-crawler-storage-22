# theme Command

Documentation coming soon.

```bash
praisonaiwp theme --help
```
