# update Command

Documentation coming soon.

```bash
praisonaiwp update --help
```
