"""CLI interface for PraisonAIWP"""

from praisonaiwp.cli.main import cli

__all__ = ["cli"]
