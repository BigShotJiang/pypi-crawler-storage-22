"""Parallel execution module for PraisonAIWP"""

from praisonaiwp.parallel.executor import ParallelExecutor

__all__ = ["ParallelExecutor"]
