"""CLI module for PreApply."""

