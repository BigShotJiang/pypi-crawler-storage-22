class PreclinicalError(Exception):
    """Error from the Preclinical API."""

    def __init__(self, message: str, status: int, code: str | None = None):
        super().__init__(message)
        self.status = status
        self.code = code

    def __repr__(self) -> str:
        return f"PreclinicalError(message={self.args[0]!r}, status={self.status}, code={self.code!r})"
