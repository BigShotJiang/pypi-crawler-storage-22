# predictpy

A simple Python logging utility.

## Install
```bash
pip install predictpy

```

## Usage
from predictpy import log

log("Hello world")
log("Something failed", level="ERROR")
