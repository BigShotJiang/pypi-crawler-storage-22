from .logger import log

__all__ = ["log"]
__version__ = "0.1.0"