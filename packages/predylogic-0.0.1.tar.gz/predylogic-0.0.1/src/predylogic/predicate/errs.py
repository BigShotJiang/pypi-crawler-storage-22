class PredicateError(Exception):
    """Base Predicate exception."""

    ...
