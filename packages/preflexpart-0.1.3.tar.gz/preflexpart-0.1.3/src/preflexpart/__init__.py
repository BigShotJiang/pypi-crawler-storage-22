import warnings

warnings.warn(
    "preflexpart has moved to flexprep. "
    "Install 'flexprep' and update imports: `preflexpart` -> `flexprep`.",
    DeprecationWarning,
    stacklevel=2,
)
