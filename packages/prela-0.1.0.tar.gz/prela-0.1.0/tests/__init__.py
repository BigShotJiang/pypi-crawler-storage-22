"""Tests for Prela SDK."""
