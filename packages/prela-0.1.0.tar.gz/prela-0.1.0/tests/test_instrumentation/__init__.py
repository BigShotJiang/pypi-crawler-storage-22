"""Tests for instrumentation modules."""
