"""
Tests package initialization
"""
