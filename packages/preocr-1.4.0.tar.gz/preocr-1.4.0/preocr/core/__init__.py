"""Core functionality for PreOCR."""
