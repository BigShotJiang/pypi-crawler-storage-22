"""Utility modules for PreOCR."""
