"""Cloudy runtime — Claude + MCP connector for Presentations.AI.

Requires: pip install presentations-ai[cloudy]
"""

from presentations_ai.cloudy._system_prompt import CLOUDY_SYSTEM_PROMPT
from presentations_ai.cloudy.async_runtime import AsyncCloudyRuntime
from presentations_ai.cloudy.runtime import CloudyRuntime
from presentations_ai.cloudy.types import (
    CloudyConfig,
    CloudyMessage,
    CloudyResponse,
    CloudyToolCall,
    CloudyUsage,
)

__all__ = [
    "CloudyRuntime",
    "AsyncCloudyRuntime",
    "CLOUDY_SYSTEM_PROMPT",
    "CloudyConfig",
    "CloudyMessage",
    "CloudyResponse",
    "CloudyToolCall",
    "CloudyUsage",
]
