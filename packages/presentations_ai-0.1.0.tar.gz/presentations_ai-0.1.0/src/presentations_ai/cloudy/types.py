"""Type definitions for the Cloudy runtime."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class CloudyConfig:
    """Configuration for the Cloudy runtime."""

    anthropic_api_key: str
    mcp_server_url: str = "https://developers.presentations.ai/mcp"
    model: str = "claude-sonnet-4-5-20250929"
    max_tokens: int = 4096
    max_continuations: int = 5
    system_prompt: str | None = None


@dataclass
class CloudyToolCall:
    """A single MCP tool call made during a Cloudy conversation turn."""

    tool_name: str
    server_name: str
    input: dict[str, Any]
    result: str = ""
    is_error: bool = False


@dataclass
class CloudyResponse:
    """Response from a Cloudy chat() call."""

    text: str
    tool_calls: list[CloudyToolCall]
    stop_reason: str
    usage: CloudyUsage
    presentation_url: str | None = None
    document_id: int | None = None
    animated_url: str | None = None
    job_id: str | None = None


@dataclass
class CloudyUsage:
    """Token usage for a Cloudy conversation turn."""

    input_tokens: int = 0
    output_tokens: int = 0


@dataclass
class CloudyMessage:
    """A message in a Cloudy conversation history."""

    role: str  # "user" or "assistant"
    content: str
