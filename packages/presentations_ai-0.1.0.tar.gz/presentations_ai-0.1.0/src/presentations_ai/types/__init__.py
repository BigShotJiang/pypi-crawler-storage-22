"""Presentations.AI SDK type definitions."""

from presentations_ai.types.common import (
    CreateFromContentParams,
    CreateFromFileParams,
    CreateFromRawContentParams,
    CreateFromTopicParams,
    CreateSingleSlideParams,
    ExportType,
    PreservationMode,
    SlideContent,
    SlideUpdate,
    UpdateSlidesParams,
)
from presentations_ai.types.jobs import (
    ApiErrorResponse,
    AsyncJobResponse,
    JobStatusResponse,
)
from presentations_ai.types.presentations import (
    ContentDocumentResponse,
    PresentationResponse,
    SlideUpdateResponse,
)

__all__ = [
    # Literal types
    "ExportType",
    "PreservationMode",
    # Slide types
    "SlideContent",
    "SlideUpdate",
    # Request params
    "CreateFromTopicParams",
    "CreateFromFileParams",
    "CreateSingleSlideParams",
    "CreateFromContentParams",
    "CreateFromRawContentParams",
    "UpdateSlidesParams",
    # Response models
    "PresentationResponse",
    "ContentDocumentResponse",
    "SlideUpdateResponse",
    "AsyncJobResponse",
    "JobStatusResponse",
    "ApiErrorResponse",
]
