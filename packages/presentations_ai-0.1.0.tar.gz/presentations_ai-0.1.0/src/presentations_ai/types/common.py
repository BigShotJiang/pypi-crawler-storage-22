"""Common types shared across the Presentations.AI SDK."""

from __future__ import annotations

from typing import Literal, TypedDict

from typing_extensions import Required

# ─── Enum-like Literal Types ─────────────────────────────────

ExportType = Literal["ppt", "pptx", "pdf", "image", "render", "share"]

PreservationMode = Literal["enhance", "preserve", "summarize", "instruction"]

# ─── Structured Slide Types (used in request bodies) ─────────


class SlideContent(TypedDict):
    """A slide with a title and content body."""

    title: str
    content: str


class SlideUpdate(TypedDict):
    """An update action for an existing slide."""

    action: Required[Literal["update"]]
    slide_content: Required[str]
    index: Required[int]


# ─── Request Parameter Types (TypedDict) ─────────────────────


class CreateFromTopicParams(TypedDict, total=False):
    topic: Required[str]
    export_type: Required[ExportType]
    slide_count: int
    language: str
    domain: str
    target_audience: str
    tone: str
    callback_url: str


class CreateFromFileParams(TypedDict, total=False):
    file: Required[bytes]
    file_name: Required[str]
    export_type: Required[ExportType]
    topic: str
    slide_count: int
    language: str
    domain: str
    preservation_mode: PreservationMode
    target_audience: str
    tone: str
    callback_url: str


class CreateSingleSlideParams(TypedDict, total=False):
    topic: Required[str]
    export_type: Required[ExportType]
    language: str
    domain: str
    target_audience: str
    tone: str
    callback_url: str


class CreateFromContentParams(TypedDict, total=False):
    name: Required[str]
    slides: Required[list[SlideContent]]
    type: str
    domain: str


class CreateFromRawContentParams(TypedDict, total=False):
    content: Required[str]
    export_type: Required[ExportType]
    topic: str
    slide_count: int
    language: str
    domain: str
    preservation_mode: PreservationMode
    target_audience: str
    tone: str
    callback_url: str


class UpdateSlidesParams(TypedDict):
    doc_id: int
    slides: list[SlideUpdate]
