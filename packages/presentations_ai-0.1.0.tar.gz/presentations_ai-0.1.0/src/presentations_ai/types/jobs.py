"""Pydantic models for async job-related API responses."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict


class AsyncJobResponse(BaseModel):
    """Response when a presentation creation is queued as an async job."""

    model_config = ConfigDict(extra="ignore")

    job_id: str
    status: Literal["queued"]


class JobStatusResponse(BaseModel):
    """Response from polling an async job's status."""

    model_config = ConfigDict(extra="ignore")

    status: int
    message: str | None = None
    poll_url: str | None = None
    docid: int | None = None
    docurl: str | None = None
    animated_url: str | None = None


class ApiErrorResponse(BaseModel):
    """Error response from the API."""

    model_config = ConfigDict(extra="ignore")

    status: Literal[1]
    error: str
