"""Pydantic models for presentation-related API responses."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class PresentationResponse(BaseModel):
    """Response from creating a presentation (topic, file, single slide, raw content)."""

    model_config = ConfigDict(extra="ignore")

    status: int
    docid: int
    docurl: str
    animated_url: str | None = None


class ContentDocumentResponse(BaseModel):
    """Response from creating a presentation from structured content."""

    model_config = ConfigDict(extra="ignore")

    status: int
    message: str
    docurl: str
    insertid: int


class SlideUpdateResponse(BaseModel):
    """Response from updating slides in an existing presentation."""

    model_config = ConfigDict(extra="ignore")

    status: int
    message: str
