"""Shared test fixtures for the Presentations.AI SDK tests."""

from __future__ import annotations

from typing import Any

import pytest
import respx

TEST_API_KEY = "pai_test_key_12345"
TEST_BASE_URL = "https://developers.presentations.ai"


@pytest.fixture
def api_key() -> str:
    return TEST_API_KEY


@pytest.fixture
def mock_api() -> respx.MockRouter:
    """Create a respx mock router for API tests."""
    with respx.mock(base_url=TEST_BASE_URL, assert_all_called=False) as router:
        yield router


@pytest.fixture
def presentation_response_data() -> dict[str, Any]:
    """Standard presentation response data."""
    return {
        "status": 0,
        "docid": 12345,
        "docurl": "https://app.presentations.ai/view/abc123",
        "animated_url": "https://app.presentations.ai/animated/abc123",
    }


@pytest.fixture
def content_document_response_data() -> dict[str, Any]:
    """Standard content document response data."""
    return {
        "status": 0,
        "message": "Document created successfully",
        "docurl": "https://app.presentations.ai/view/def456",
        "insertid": 67890,
    }


@pytest.fixture
def async_job_response_data() -> dict[str, Any]:
    """Standard async job response data."""
    return {
        "job_id": "job_abc123",
        "status": "queued",
    }


@pytest.fixture
def job_status_complete_data() -> dict[str, Any]:
    """Job status response indicating completion."""
    return {
        "status": 0,
        "message": "Document is ready",
        "docid": 12345,
        "docurl": "https://app.presentations.ai/view/abc123",
        "animated_url": "https://app.presentations.ai/animated/abc123",
    }


@pytest.fixture
def job_status_processing_data() -> dict[str, Any]:
    """Job status response indicating still processing."""
    return {
        "status": 1,
        "message": "Document is being processed",
    }


@pytest.fixture
def job_status_failed_data() -> dict[str, Any]:
    """Job status response indicating failure."""
    return {
        "status": 1,
        "message": "Generation failed: invalid content",
    }
