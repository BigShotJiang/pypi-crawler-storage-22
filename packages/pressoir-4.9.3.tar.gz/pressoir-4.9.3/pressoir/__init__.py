from pathlib import Path

VERSION = "4.9.3"
ROOT_DIR = Path(__file__).parent
