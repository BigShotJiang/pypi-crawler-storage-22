## EnvironnementVirtuel

---
title: >-
   Installer un environnement virtuel
credits:
keywords: venv,environnement,virtuel,python
lang: fr
type: article
link:
link-archive:
embed:
zotero:
date: 2024-09-20
date-publication: 2024-09-20
source: auteur
priority: lowpriority
position: main
---

Au besoin, installer et activer un environnement virtuel&nbsp;:

```
$ python3 -m venv venv
$ source venv/bin/activate
```
