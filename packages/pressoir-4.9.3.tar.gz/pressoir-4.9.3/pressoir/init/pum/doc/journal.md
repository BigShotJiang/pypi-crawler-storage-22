# Journal

<!--le journal de bord est destiné aux éditeur.rice.s et permet de faire un suivi de l'avancée du projet-->
