# Pretix Sales Map Plugin

A powerful geographic analytics and visualization plugin for [pretix](https://github.com/pretix/pretix). This plugin allows you to visualize where your attendees are coming from, track sales growth over time, and analyze regional market penetration.

## ✨ Features

- **📍 Automatic Geocoding:** Automatically converts attendee addresses to map coordinates upon payment.
- **🗺️ Interactive Map:** Switch between **Pin View** (with clustering), **Heatmap**, and **Density Grid**.
- **📈 Sales Analytics:** Track total revenue, average travel distance, and top regions (cities/items).
- **⏱️ Timeline Animation:** Play back the history of your sales to see geographic growth over time.
- **★ Marketing Milestones:** Define important dates (e.g., newsletters) in the UI to see their impact on the timeline.
- **🔄 Event Comparison:** Overlay data from previous events to compare reach and performance.
- **⚠️ Quality Control:** Dedicated view for orders with failed geocoding to manage data issues.
- **🌙 Nightly Sync:** Automated background task to retry failed geocoding attempts.
- **🔘 Manual Trigger:** Admin button to re-run geocoding for all orders of an event.

## 🚀 Installation & Setup

To use this plugin with your local pretix instance (`C:\Users\SCJA03\Desktop\Programmieren\pretix`):

### 1. Register the Plugin
Open your terminal, navigate to this directory, and ensure your pretix virtual environment is active.
```bash
python setup.py develop
```

### 2. Run Migrations
Apply the database changes for geodata and milestones:
```bash
# From your pretix/src directory
python manage.py migrate
```

### 3. Configuration
Add a User-Agent for the geocoding service in your `pretix.cfg`:
```ini
[pretix_mapplugin]
nominatim_user_agent = YourProjectName/1.0 (contact@yourdomain.com)
```

### 4. Enable the Plugin
1. Log in to your Pretix Control Panel.
2. Go to **Organizer Settings > Plugins** and enable **Map-Plugin**.
3. In your specific **Event > Settings > Plugins**, also enable **Map-Plugin**.

## 🛠️ Usage

- **Map View:** Navigate to **Sales Map > Map View** in the event sidebar.
- **Milestones:** Go to **Sales Map > Milestones** to add marketing dates.
- **Revenue Weighting:** Use the toggle button on the map to see "where the money comes from" instead of just "where the people are".

## 🚀 Starting the Application (Development)

1. **Pretix Server:**
   ```bash
   cd C:\Users\SCJA03\Desktop\Programmieren\pretix\src
   python manage.py runserver
   ```
2. **Celery Worker:**
   ```bash
   cd C:\Users\SCJA03\Desktop\Programmieren\pretix\src
   celery -A pretix.celery_app worker -l info
   ```
   *Note: If you don't have a broker like Redis or RabbitMQ running, the plugin will automatically fall back to synchronous geocoding (eager mode) if configured in `pretix.cfg`.*

## 🛡️ Requirements

- pretix >= 2.7
- geopy
- A running Celery worker (essential for background geocoding)

---
Developed by MarkenJaden. Released under the Apache License 2.0.
