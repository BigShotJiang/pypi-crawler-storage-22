import logging
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut, GeocoderServiceError
from geopy.distance import distance as geopy_distance
from time import sleep

# DO NOT import settings here, as it won't work reliably in Celery

logger = logging.getLogger(__name__)

# Define a default/fallback User-Agent. Users *should* override this in pretix.cfg.
DEFAULT_NOMINATIM_USER_AGENT = "pretix-map-plugin/unknown (Please configure nominatim_user_agent in pretix.cfg)"


# --- Geocoding Function (Accepts user_agent) ---
def geocode_address(address_string: str, nominatim_user_agent: str | None = None) -> tuple[float, float] | None:
    """
    Tries to geocode a given address string using Nominatim, using the
    provided User-Agent string.

    Args:
        address_string: A single string representing the address.
        nominatim_user_agent: The User-Agent string to use for Nominatim.

    Returns:
        A tuple (latitude, longitude) if successful, otherwise None.
    """
    # Use the provided User-Agent or the default
    user_agent = nominatim_user_agent or DEFAULT_NOMINATIM_USER_AGENT

    if user_agent == DEFAULT_NOMINATIM_USER_AGENT:
        # Log warning if default is used - admins should configure this
        logger.warning(
            "Using default Nominatim User-Agent. Please set a specific "
            "'nominatim_user_agent' under [pretix_mapplugin] in your "
            "pretix.cfg according to Nominatim's usage policy."
        )

    # Initialize the geolocator with the determined user_agent
    geolocator = Nominatim(user_agent=user_agent)

    try:
        # Add a 1-second delay to respect Nominatim's usage policy (1 req/sec)
        sleep(1)

        # Perform geocoding
        location = geolocator.geocode(address_string, timeout=10)  # 10-second timeout

        if location:
            logger.debug(
                f"Geocoded '{address_string}' to ({location.latitude}, {location.longitude}) using User-Agent: {user_agent}"
            )
            return (location.latitude, location.longitude)
        else:
            logger.warning(f"Could not geocode address: {address_string} (Address not found by Nominatim)")
            return None

    except GeocoderTimedOut:
        logger.error(f"Geocoding timed out for address: {address_string}")
        return None
    except GeocoderServiceError as e:
        # Log specific service errors (e.g., API limits, server issues)
        logger.error(f"Geocoding service error for address '{address_string}': {e}")
        return None
    except Exception as e:
        # Catch any other unexpected exceptions during geocoding
        logger.exception(f"An unexpected error occurred during geocoding for address '{address_string}': {e}")
        return None


# --- Helper to Format Address Candidates from Pretix Order ---
def get_address_candidates_from_order(order) -> list[str]:
    """
    Creates a list of formatted address strings from a Pretix order's invoice address,
    ordered from most specific to least specific (fallback).

    Args:
        order: A Pretix `Order` object.

    Returns:
        A list of address strings (e.g., ["Street, City, Zip, Country", "Zip City, Country"]).
    """
    # Ensure order and invoice_address exist
    if not order or not order.invoice_address:
        return []

    candidates = []
    addr = order.invoice_address  # Shortcut
    country_name = str(addr.country.name) if addr.country else ""

    # Strategy 1: Full Address (Street, Zip City, State, Country)
    parts_full = []
    if addr.street: parts_full.append(addr.street)
    if addr.zipcode and addr.city:
        parts_full.append(f"{addr.zipcode} {addr.city}")
    elif addr.city:
        parts_full.append(addr.city)
    elif addr.zipcode:
        parts_full.append(addr.zipcode)
    
    if addr.state: parts_full.append(addr.state)
    if country_name: parts_full.append(country_name)
    
    full_address = ", ".join(filter(None, parts_full))
    if full_address:
        candidates.append(full_address)

    # Strategy 2: Zip + City + Country (No Street) - Good for privacy or if street is weird
    parts_zip_city = []
    if addr.zipcode and addr.city:
        parts_zip_city.append(f"{addr.zipcode} {addr.city}")
    elif addr.city: # Fallback if only city
        parts_zip_city.append(addr.city)
    
    if country_name: parts_zip_city.append(country_name)

    zip_city_address = ", ".join(filter(None, parts_zip_city))
    if zip_city_address and zip_city_address not in candidates:
        candidates.append(zip_city_address)

    # Strategy 3: Just Zip + Country (Coarse location)
    parts_zip = []
    if addr.zipcode: parts_zip.append(addr.zipcode)
    if country_name: parts_zip.append(country_name)
    
    zip_address = ", ".join(filter(None, parts_zip))
    if zip_address and zip_address not in candidates:
        candidates.append(zip_address)

    return candidates


def get_best_address_string(order) -> str | None:
    """Returns the most specific address string for an order."""
    candidates = get_address_candidates_from_order(order)
    return candidates[0] if candidates else None


def geocode_event_location(event, nominatim_user_agent: str | None = None) -> tuple[float, float] | None:
    """
    Tries to geocode the event's location field.
    """
    if not event or not event.location:
        return None
    
    location_str = str(event.location)
    logger.info(f"Geocoding event location: {location_str}")
    return geocode_address(location_str, nominatim_user_agent=nominatim_user_agent)


def calculate_distance(coord1: tuple[float, float], coord2: tuple[float, float]) -> float | None:
    """
    Calculates the distance in kilometers between two coordinates (lat, lon).
    Returns None if coordinates are invalid.
    """
    try:
        if not coord1 or not coord2:
            return None
        return geopy_distance(coord1, coord2).km
    except Exception as e:
        logger.warning(f"Error calculating distance: {e}")
        return None
