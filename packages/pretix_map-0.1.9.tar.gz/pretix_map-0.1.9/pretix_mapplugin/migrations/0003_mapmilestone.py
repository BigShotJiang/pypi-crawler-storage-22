from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('pretixbase', '0001_initial'),
        ('pretix_mapplugin', '0002_remove_ordergeocodedata_geocoded_timestamp_and_more'),
    ]

    operations = [
        migrations.CreateModel(
            name='MapMilestone',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False)),
                ('date', models.DateField(verbose_name='Date')),
                ('label', models.CharField(max_length=200, verbose_name='Milestone Label')),
                ('event', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='map_milestones', to='pretixbase.Event')),
            ],
            options={
                'verbose_name': 'Map Milestone',
                'verbose_name_plural': 'Map Milestones',
                'ordering': ['date'],
            },
        ),
    ]
