from django.db import migrations, models

class Migration(migrations.Migration):

    dependencies = [
        ('pretix_mapplugin', '0003_mapmilestone'),
    ]

    operations = [
        migrations.AddField(
            model_name='ordergeocodedata',
            name='success_level',
            field=models.CharField(blank=True, help_text='Precision of geocoding (e.g., street, city, zip, failed)', max_length=50, null=True),
        ),
    ]
