from django.db import models
from pretix.base.models import LoggedModel, Order


class OrderGeocodeData(LoggedModel):  # Keep LoggedModel if you want audit logs
    """
    Stores the geocoded coordinates for a Pretix Order's invoice address.
    Allows null coordinates for failed geocoding attempts.
    """
    order = models.OneToOneField(
        Order,
        on_delete=models.CASCADE,
        related_name='geocode_data',
        primary_key=True  # Keep this if you want order PK as primary key
    )
    latitude = models.FloatField(
        null=True,  # Allow NULL in the database if geocoding fails
        blank=True  # Allow blank in forms/admin (good practice with null=True)
    )
    longitude = models.FloatField(
        null=True,  # Allow NULL in the database if geocoding fails
        blank=True  # Allow blank in forms/admin
    )
    success_level = models.CharField(
        max_length=50,
        null=True,
        blank=True,
        help_text="Precision of geocoding (e.g., street, city, zip, failed)"
    )

    # Change to auto_now to update timestamp on every save (successful or null)
    last_geocoded_at = models.DateTimeField(
        auto_now=True,  # Set/Update timestamp every time the record is saved
        help_text="Timestamp when geocoding was last attempted/updated."
    )

    class Meta:
        verbose_name = "Order Geocode Data"
        verbose_name_plural = "Order Geocode Data"
        # Optional: Indexing coordinates can speed up map data queries if you have many entries
        # indexes = [
        #     models.Index(fields=['latitude', 'longitude']),
        # ]

    def __str__(self):
        # Provide more informative string representation
        if self.latitude is not None and self.longitude is not None:
            return f"Geocode for Order {self.order.code}: ({self.latitude:.4f}, {self.longitude:.4f})"
        else:
            return f"Geocode data for Order {self.order.code} (Coordinates: None)"


class MapMilestone(models.Model):
    """
    Stores marketing milestones (e.g., newsletters, ad starts) for an event.
    Used for visualization in the Sales Map timeline.
    """
    event = models.ForeignKey(
        'pretixbase.Event',
        on_delete=models.CASCADE,
        related_name='map_milestones'
    )
    date = models.DateField(
        verbose_name="Date"
    )
    label = models.CharField(
        max_length=200,
        verbose_name="Milestone Label"
    )

    class Meta:
        ordering = ['date']
        verbose_name = "Map Milestone"
        verbose_name_plural = "Map Milestones"

    def __str__(self):
        return f"{self.date}: {self.label} ({self.event.slug})"
