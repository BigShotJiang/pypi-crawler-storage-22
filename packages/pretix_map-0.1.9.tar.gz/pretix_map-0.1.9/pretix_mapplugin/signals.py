import logging
from django.dispatch import receiver
from django.urls import reverse, NoReverseMatch
from django.utils.translation import gettext_lazy as _
from django.http import HttpRequest
from django.conf import settings
from django.utils.timezone import now
from django.db import transaction

# --- Pretix Signals ---
from pretix.base.signals import order_placed, periodic_task
from pretix.control.signals import nav_event

# --- Tasks ---
from .tasks import geocode_order_task, nightly_reprocess_geocoding
# --- Geocoding Default ---
from .geocoding import DEFAULT_NOMINATIM_USER_AGENT

logger = logging.getLogger(__name__)

# --- Constants ---
MAP_VIEW_URL_NAME = 'plugins:pretix_mapplugin:event.settings.salesmap.show'
REQUIRED_MAP_PERMISSION = 'can_view_orders'
PLUGIN_NAME = 'pretix_mapplugin'


@receiver(periodic_task, dispatch_uid="sales_mapper_periodic_reprocess")
def trigger_nightly_geocoding(sender, **kwargs):
    if now().hour == 3 and now().minute < 10:
        nightly_reprocess_geocoding.apply_async()


@receiver(order_placed, dispatch_uid="sales_mapper_order_placed_geocode")
def trigger_geocoding_on_placement(sender, order, **kwargs):
    """
    Queues geocoding after the current transaction is committed to avoid SQLite locks.
    """
    user_agent = DEFAULT_NOMINATIM_USER_AGENT
    if hasattr(settings, 'CONFIG_FILE') and settings.CONFIG_FILE.has_section('pretix_mapplugin'):
        user_agent = settings.CONFIG_FILE.get('pretix_mapplugin', 'nominatim_user_agent', fallback=DEFAULT_NOMINATIM_USER_AGENT)

    def run_task():
        geocode_order_task.apply_async(
            args=[order.pk],
            kwargs={
                'nominatim_user_agent': user_agent,
                'organizer_pk': order.event.organizer.pk
            }
        )
    
    # Crucial: Only run AFTER the order has been saved to DB
    transaction.on_commit(run_task)


@receiver(nav_event, dispatch_uid="sales_mapper_nav_event_add_map")
def add_map_nav_item(sender, request: HttpRequest, **kwargs):
    has_permission = request.user.has_event_permission(request.organizer, request.event, REQUIRED_MAP_PERMISSION, request=request)
    if not has_permission: return []
    try:
        map_url = reverse(MAP_VIEW_URL_NAME, kwargs={'organizer': request.organizer.slug, 'event': request.event.slug})
        milestone_url = reverse('plugins:pretix_mapplugin:event.settings.salesmap.milestones', kwargs={'organizer': request.organizer.slug, 'event': request.event.slug})
    except NoReverseMatch:
        return []
    
    is_active = request.resolver_match.view_name == MAP_VIEW_URL_NAME if request.resolver_match else False
    is_milestone_active = request.resolver_match.view_name == 'plugins:pretix_mapplugin:event.settings.salesmap.milestones' if request.resolver_match else False

    return [{
        'label': _('Sales Map'),
        'url': map_url,
        'active': is_active or is_milestone_active,
        'icon': 'map-o',
        'children': [
            {'label': _('Map View'), 'url': map_url, 'active': is_active},
            {'label': _('Milestones'), 'url': milestone_url, 'active': is_milestone_active},
        ]
    }]
