import logging
from django.db import transaction
from django.core.exceptions import ObjectDoesNotExist

from django_scopes import scope, scopes_disabled
from django.conf import settings

# --- Use Pretix Celery app instance ---
from pretix.celery_app import app
# --- Import necessary Pretix models ---
from pretix.base.models import Order, Organizer, Event  # Import Organizer

# --- Import your Geocode model and geocoding functions ---
from .models import OrderGeocodeData
from .geocoding import (
    get_address_candidates_from_order,
    geocode_address,
    DEFAULT_NOMINATIM_USER_AGENT
)

logger = logging.getLogger(__name__)


@app.task
def nightly_reprocess_geocoding():
    """
    Nightly task to find paid orders that haven't been geocoded yet or failed previously.
    """
    user_agent = DEFAULT_NOMINATIM_USER_AGENT
    if hasattr(settings, 'CONFIG_FILE') and settings.CONFIG_FILE.has_section('pretix_mapplugin'):
        user_agent = settings.CONFIG_FILE.get('pretix_mapplugin', 'nominatim_user_agent', fallback=DEFAULT_NOMINATIM_USER_AGENT)

    with scopes_disabled():
        # Find paid orders without successful geocode data
        # This includes those without an OrderGeocodeData record AND those with null lat/lon
        orders_to_retry = Order.objects.filter(
            status=Order.STATUS_PAID
        ).exclude(
            geocode_data__latitude__isnull=False
        ).select_related('event', 'event__organizer')

        count = orders_to_retry.count()
        logger.info(f"Nightly Geocode Reprocess: Found {count} orders to process.")

        for order in orders_to_retry:
            geocode_order_task.apply_async(
                args=[order.pk],
                kwargs={
                    'nominatim_user_agent': user_agent,
                    'organizer_pk': order.event.organizer.pk
                }
            )


@app.task(bind=True, max_retries=3, default_retry_delay=60, ignore_result=True)
# --- Accept organizer_pk as kwarg ---
def geocode_order_task(self, order_pk: int, organizer_pk: int | None = None, nominatim_user_agent: str | None = None):
    """
    Celery task to geocode the address for a given order PK.
    Accepts organizer_pk and Nominatim User-Agent as arguments.
    Fetches Organizer first, then activates scope.
    """
    organizer = None
    order = None
    try:
        # --- Step 1: Fetch Organizer (unscoped) ---
        if organizer_pk is None:
            # This should ideally not happen if called correctly, but handle defensively
            logger.error(f"organizer_pk not provided for Order PK {order_pk}. Cannot activate scope.")
            return

        try:
            organizer = Organizer.objects.get(pk=organizer_pk)
        except ObjectDoesNotExist:
            logger.error(f"Organizer with PK {organizer_pk} not found (for Order PK {order_pk}).")
            return

        # --- Step 2: Activate Scope ---
        with scope(organizer=organizer):
            # --- Step 3: Fetch Order (now within scope) ---
            try:
                order = Order.objects.select_related(
                    'invoice_address'  # Only need this direct relation now
                ).get(pk=order_pk)
            except ObjectDoesNotExist:
                logger.error(f"Order with PK {order_pk} not found within scope of Org {organizer_pk}.")
                return

            logger.info(
                f"Starting geocoding task for Order {order.code} (PK: {order_pk}) within scope of Organizer '{organizer.slug}'")

            # --- Rest of the logic runs within scope ---
            if OrderGeocodeData.objects.filter(order_id=order_pk).exists():
                logger.info(f"Geocode data already exists for Order {order.code}. Skipping.")
                return

            candidates = get_address_candidates_from_order(order)
            if not candidates:
                logger.info(f"Order {order.code} has no address suitable for geocoding. Storing null coordinates.")
                with transaction.atomic():
                    OrderGeocodeData.objects.update_or_create(
                        order=order, defaults={'latitude': None, 'longitude': None}
                    )
                return

            # Try candidates in order
            coordinates = None
            successful_candidate = None
            success_level = "failed"

            for i, candidate in enumerate(candidates):
                logger.debug(f"Attempting to geocode candidate for Order {order.code}: '{candidate}'")
                coordinates = geocode_address(candidate, nominatim_user_agent=nominatim_user_agent)
                if coordinates:
                    successful_candidate = candidate
                    # Map candidate index to level (0: full, 1: zip+city, 2: zip)
                    if i == 0: success_level = "street"
                    elif i == 1: success_level = "city"
                    else: success_level = "zip"
                    break  # Success!

            with transaction.atomic():
                if coordinates:
                    latitude, longitude = coordinates
                    obj, created = OrderGeocodeData.objects.update_or_create(
                        order=order, defaults={
                            'latitude': latitude, 
                            'longitude': longitude,
                            'success_level': success_level
                        }
                    )
                    log_level = logging.INFO if created else logging.DEBUG
                    logger.log(log_level,
                               f"Saved{' new' if created else ' updated'} geocode data for Order {order.code} using '{successful_candidate}' (Level: {success_level}): ({latitude}, {longitude})")
                else:
                    logger.warning(f"Geocoding failed for Order {order.code} (tried {len(candidates)} candidates). Storing null coordinates.")
                    obj, created = OrderGeocodeData.objects.update_or_create(
                        order=order, defaults={
                            'latitude': None, 
                            'longitude': None,
                            'success_level': 'failed'
                        }
                    )
        # --- Scope deactivated automatically ---

    # --- Outer exception handling ---
    except ObjectDoesNotExist:
        # Should be caught earlier now, but keep for safety
        obj_type = "Organizer" if organizer is None else "Order"
        obj_pk = organizer_pk if organizer is None else order_pk
        logger.error(f"{obj_type} with PK {obj_pk} not found.")
    except Exception as e:
        org_info = f" (Org PK: {organizer_pk})" if organizer_pk else ""
        order_info = f" (Order PK: {order_pk})" if order_pk else ""
        logger.exception(f"Unexpected error in geocode_order_task{org_info}{order_info}: {e}")
        # Retry on potentially temporary errors
        raise self.retry(exc=e)
