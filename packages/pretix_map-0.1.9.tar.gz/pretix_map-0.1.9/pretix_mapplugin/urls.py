from django.urls import re_path

from .views import SalesMapDataView, SalesMapView, MilestoneSettingsView, TriggerGeocodingView, SingleGeocodeView

# Define the URL patterns for the event settings area
# These URLs will be prefixed with /control/event/<organizer>/<event>/
urlpatterns = [
    # URL for the API endpoint providing coordinate data
    re_path(
        r'^control/event/(?P<organizer>[^/]+)/(?P<event>[^/]+)/sales-map/data/',
        SalesMapDataView.as_view(),
        name="event.settings.salesmap.data",
    ),
    # URL for triggering geocoding for all
    re_path(
        r'^control/event/(?P<organizer>[^/]+)/(?P<event>[^/]+)/sales-map/trigger/',
        TriggerGeocodingView.as_view(),
        name="event.settings.salesmap.trigger",
    ),
    # URL for single order geocoding
    re_path(
        r'^control/event/(?P<organizer>[^/]+)/(?P<event>[^/]+)/sales-map/retry/(?P<order>[^/]+)/',
        SingleGeocodeView.as_view(),
        name="event.settings.salesmap.retry",
    ),
    # URL for milestone management
    re_path(
        r'^control/event/(?P<organizer>[^/]+)/(?P<event>[^/]+)/sales-map/milestones/',
        MilestoneSettingsView.as_view(),
        name="event.settings.salesmap.milestones",
    ),
    # URL for the HTML page displaying the map
    re_path(
        r'^control/event/(?P<organizer>[^/]+)/(?P<event>[^/]+)/sales-map/',
        SalesMapView.as_view(),
        name="event.settings.salesmap.show",
    ),
]
