import logging
from collections import Counter
from django.conf import settings
from django.contrib import messages
from django.db.models import Prefetch
from django.forms import inlineformset_factory
from django.http import HttpResponse, JsonResponse
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.formats import date_format
from django.utils.translation import gettext_lazy as _
from django.views.generic import TemplateView, View

from pretix.base.models import Order, Event
from pretix.control.views.event import EventSettingsViewMixin

from .models import OrderGeocodeData, MapMilestone
from .tasks import geocode_order_task
from .geocoding import (
    DEFAULT_NOMINATIM_USER_AGENT,
    geocode_event_location,
    get_best_address_string,
    calculate_distance
)

# --- CSP Helpers ---
try:
    from pretix.base.csp import _merge_csp, _parse_csp, _render_csp
except ImportError:
    from pretix.base.middleware import _merge_csp, _parse_csp, _render_csp

logger = logging.getLogger(__name__)


from django import forms
try:
    from pretix.control.forms.widgets import DatePickerWidget
except ImportError:
    class DatePickerWidget(forms.DateInput):
        def __init__(self, *args, **kwargs):
            attrs = kwargs.get('attrs', {})
            attrs['class'] = attrs.get('class', '') + ' datepickerfield'
            kwargs['attrs'] = attrs
            super().__init__(*args, **kwargs)

# --- Milestone Management ---
MilestoneFormSet = inlineformset_factory(
    Event,
    MapMilestone,
    fields=('date', 'label'),
    widgets={
        'date': DatePickerWidget(),
    },
    extra=1,
    can_delete=True
)


class MilestoneSettingsView(EventSettingsViewMixin, TemplateView):
    permission = 'can_change_event_settings'
    template_name = 'pretix_mapplugin/milestones.html'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        if 'formset' not in ctx:
            ctx['formset'] = MilestoneFormSet(
                instance=self.request.event,
                queryset=MapMilestone.objects.filter(event=self.request.event)
            )
        return ctx

    def post(self, request, *args, **kwargs):
        formset = MilestoneFormSet(
            request.POST,
            instance=self.request.event,
            queryset=MapMilestone.objects.filter(event=self.request.event)
        )
        if formset.is_valid():
            formset.save()
            return redirect(reverse('plugins:pretix_mapplugin:event.settings.salesmap.milestones', kwargs={
                'organizer': self.request.organizer.slug,
                'event': self.request.event.slug,
            }))
        return self.render_to_response(self.get_context_data(formset=formset))


class SingleGeocodeView(EventSettingsViewMixin, View):
    permission = 'can_change_event_settings'

    def post(self, request, *args, **kwargs):
        order_pk = self.kwargs.get('order')
        try:
            order = Order.objects.get(pk=order_pk, event=self.request.event)
        except Order.DoesNotExist:
            return JsonResponse({'error': 'Order not found'}, status=404)

        user_agent = DEFAULT_NOMINATIM_USER_AGENT
        if hasattr(settings, 'CONFIG_FILE') and settings.CONFIG_FILE.has_section('pretix_mapplugin'):
            user_agent = settings.CONFIG_FILE.get('pretix_mapplugin', 'nominatim_user_agent', fallback=DEFAULT_NOMINATIM_USER_AGENT)

        geocode_order_task.apply_async(
            args=[order.pk],
            kwargs={
                'nominatim_user_agent': user_agent,
                'organizer_pk': self.request.organizer.pk
            }
        )
        return JsonResponse({'success': True})


class TriggerGeocodingView(EventSettingsViewMixin, View):
    permission = 'can_change_event_settings'

    def post(self, request, *args, **kwargs):
        user_agent = DEFAULT_NOMINATIM_USER_AGENT
        if hasattr(settings, 'CONFIG_FILE') and settings.CONFIG_FILE.has_section('pretix_mapplugin'):
            user_agent = settings.CONFIG_FILE.get('pretix_mapplugin', 'nominatim_user_agent', fallback=DEFAULT_NOMINATIM_USER_AGENT)

        orders_to_geocode = Order.objects.filter(
            event=self.request.event,
            status__in=[Order.STATUS_PAID, Order.STATUS_PENDING]
        ).exclude(
            geocode_data__latitude__isnull=False
        )
        
        count = 0
        for order in orders_to_geocode:
            geocode_order_task.apply_async(
                args=[order.pk],
                kwargs={
                    'nominatim_user_agent': user_agent,
                    'organizer_pk': self.request.organizer.pk
                }
            )
            count += 1
        
        messages.success(request, _("Queued {} orders for geocoding.").format(count))
        return redirect(reverse('plugins:pretix_mapplugin:event.settings.salesmap.show', kwargs={
            'organizer': self.request.organizer.slug,
            'event': self.request.event.slug,
        }))


class SalesMapDataView(EventSettingsViewMixin, View):
    permission = 'can_view_orders'

    def get(self, request, *args, **kwargs):
        event = self.request.event
        organizer = request.organizer

        user_agent = DEFAULT_NOMINATIM_USER_AGENT
        if hasattr(settings, 'CONFIG_FILE') and settings.CONFIG_FILE.has_section('pretix_mapplugin'):
            user_agent = settings.CONFIG_FILE.get('pretix_mapplugin', 'nominatim_user_agent', fallback=DEFAULT_NOMINATIM_USER_AGENT)
            
        milestones = [
            {'date': m.date.isoformat(), 'label': m.label}
            for m in MapMilestone.objects.filter(event=event)
        ]

        item_availability = {}
        for item in event.items.all():
            item_availability[str(item.name)] = {
                'available_from': item.available_from.isoformat() if item.available_from else None,
                'available_until': item.available_until.isoformat() if item.available_until else None,
                'first_sale': None,
                'last_sale': None,
            }

        locations_data = []
        failed_orders_data = []
        city_counter = Counter()
        item_counter = Counter()
        distances = []
        total_revenue = 0

        try:
            event_marker = None
            event_coords = None
            if event.location:
                event_coords = geocode_event_location(event, user_agent)
                if event_coords:
                    event_marker = {'lat': event_coords[0], 'lon': event_coords[1], 'name': str(event.name), 'location': str(event.location)}

            geocode_entries = OrderGeocodeData.objects.filter(
                order__event=event, latitude__isnull=False, longitude__isnull=False
            ).select_related('order', 'order__invoice_address').prefetch_related('order__positions__item')

            for entry in geocode_entries:
                order = entry.order
                iso_date = order.datetime.isoformat() if order.datetime else ""
                revenue = float(order.total)
                
                status = 'pending'
                if order.status == Order.STATUS_PAID: status = 'paid'
                elif order.status == Order.STATUS_CANCELED: status = 'canceled'

                if status != 'canceled':
                    total_revenue += revenue
                    if order.invoice_address and order.invoice_address.city:
                        city_counter[order.invoice_address.city] += 1
                    dist_km = calculate_distance(event_coords, (entry.latitude, entry.longitude)) if event_coords else None
                    if dist_km is not None: distances.append(dist_km)
                else:
                    dist_km = calculate_distance(event_coords, (entry.latitude, entry.longitude)) if event_coords else None

                item_names = [str(p.item.name) for p in order.positions.all() if p.item]
                if status != 'canceled':
                    for name in item_names:
                        item_counter[name] += 1
                        # Track sales period
                        if name in item_availability:
                            if not item_availability[name]['first_sale'] or iso_date < item_availability[name]['first_sale']:
                                item_availability[name]['first_sale'] = iso_date
                            if not item_availability[name]['last_sale'] or iso_date > item_availability[name]['last_sale']:
                                item_availability[name]['last_sale'] = iso_date

                tooltip_parts = [f"<strong>Order:</strong> {order.code} ({status.upper()})"]
                if order.datetime:
                    tooltip_parts.append(f"<strong>Date:</strong> {date_format(order.datetime, format='SHORT_DATETIME_FORMAT', use_l10n=True)}")
                tooltip_parts.append(f"<strong>Items:</strong> {order.positions.count()}")
                tooltip_parts.append(f"<strong>Total:</strong> {order.total} {event.currency}")
                if dist_km: tooltip_parts.append(f"<strong>Dist:</strong> {dist_km:.1f} km")
                if entry.success_level:
                    level_map = {'street': _('Street'), 'city': _('City'), 'zip': _('Zip code')}
                    tooltip_parts.append(f"<strong>Precision:</strong> {level_map.get(entry.success_level, entry.success_level)}")

                locations_data.append({
                    "lat": entry.latitude, "lon": entry.longitude, "tooltip": "<br>".join(tooltip_parts),
                    "order_url": reverse('control:event.order', kwargs={'organizer': organizer.slug, 'event': event.slug, 'code': order.code}),
                    "items": item_names, "date": iso_date, "dist": dist_km, "revenue": revenue, "status": status,
                    "precision": entry.success_level
                })

            failed_entries = OrderGeocodeData.objects.filter(order__event=event, latitude__isnull=True).select_related('order', 'order__invoice_address')
            for entry in failed_entries:
                failed_orders_data.append({
                    'pk': entry.order.pk, 'code': entry.order.code,
                    'address': get_best_address_string(entry.order) or _("No address"),
                    'url': reverse('control:event.order', kwargs={'organizer': organizer.slug, 'event': event.slug, 'code': entry.order.code}),
                    'retry_url': reverse('plugins:pretix_mapplugin:event.settings.salesmap.retry', kwargs={'organizer': organizer.slug, 'event': event.slug, 'order': entry.order.pk}),
                    'success_level': entry.success_level or 'failed'
                })
            
            avg_dist_val = round(sum(distances) / len(distances), 1) if distances else 0

            return JsonResponse({
                'locations': locations_data, 'failed_orders': failed_orders_data,
                'event_marker': event_marker, 'milestones': milestones,
                'item_availability': item_availability,
                'stats': {
                    'top_cities': city_counter.most_common(10), 'top_items': item_counter.most_common(10),
                    'total_orders': len(locations_data) + len(failed_orders_data),
                    'geocoded_count': len(locations_data), 'avg_distance_km': avg_dist_val,
                    'total_revenue': total_revenue, 'currency': event.currency
                }
            })
        except Exception as e:
            logger.exception(f"Error: {e}")
            return JsonResponse({'error': _('Error')}, status=500)


class SalesMapView(EventSettingsViewMixin, TemplateView):
    permission = 'can_view_orders'
    template_name = 'pretix_mapplugin/map_page.html'
    
    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['other_events'] = self.request.organizer.events.exclude(pk=self.request.event.pk).order_by('-date_from')
        return ctx

    def get(self, request, *args, **kwargs):
        try:
            response = super().get(request, *args, **kwargs)
        except Exception as e:
            logger.exception(f"Error: {e}")
            return HttpResponse(_("Error"), status=500)

        current_csp = {}
        header_key = 'Content-Security-Policy'
        if header_key in response:
            header_value = response[header_key]
            if isinstance(header_value, bytes): header_value = header_value.decode('utf-8')
            try:
                from pretix.base.middleware import _parse_csp
                current_csp = _parse_csp(header_value)
            except Exception: current_csp = {}

        # Allow external images for markers and Chart.js from CDN
        map_csp_additions = {
            'img-src': [
                'https://*.tile.openstreetmap.org',
                'https://raw.githubusercontent.com',
                'https://cdnjs.cloudflare.com'
            ],
            'script-src': [
                'https://cdn.jsdelivr.net',
                "'unsafe-eval'" # Needed for some charting libs
            ],
            'connect-src': [
                'https://cdn.jsdelivr.net',
                'https://*.tile.openstreetmap.org'
            ],
            'style-src': ["'unsafe-inline'"]
        }

        try:
            from pretix.base.middleware import _merge_csp, _render_csp
            _merge_csp(current_csp, map_csp_additions)
            response[header_key] = _render_csp(current_csp)
        except Exception: pass

        return response