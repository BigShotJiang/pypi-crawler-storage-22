# Configuration API

::: pretok.config.schema.PretokConfig

::: pretok.config.schema.PipelineConfig

::: pretok.config.schema.DetectionConfig

::: pretok.config.schema.TranslationConfig

::: pretok.config.schema.CacheConfig

::: pretok.config.schema.SegmentConfig

::: pretok.config.loader.load_config

::: pretok.config.loader.ConfigurationError
