# Detection API

::: pretok.detection.LanguageDetector
    options:
      show_source: true

::: pretok.detection.DetectionResult

::: pretok.detection.fasttext_backend.FastTextDetector

::: pretok.detection.langdetect_backend.LangDetectDetector

::: pretok.detection.composite.CompositeDetector
