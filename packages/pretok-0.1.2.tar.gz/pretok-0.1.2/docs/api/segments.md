# Segments API

::: pretok.segment.Segment

::: pretok.segment.SegmentType

::: pretok.segment.PromptLexer

::: pretok.segment.lex_prompt
