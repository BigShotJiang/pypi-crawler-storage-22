# PrideFetch User Guide

PrideFetch is a Python API package for discovering and downloading PRIDE Archive dataset files. It is designed for programmatic workflows and does not ship a CLI.

## Installation

```bash
pip install pridefetch
```

## Quick Start

```python
from pridefetch import list_raw_files, download_files

accession = "PXD032067"
files = list_raw_files(accession)

results = download_files(
    accession,
    files,
    output_dir="./downloads/PXD032067",
    overwrite=False,
    resume=True,
    workers=4,
    show_progress=True,
    verify_checksums=True,
)

print(results)
```

## Authentication

PrideFetch supports API key authentication using a configurable header.

### Explicit configuration

```python
from pridefetch import AuthConfig, PrideFetchClient

auth = AuthConfig(api_key="your-token", header_name="X-API-Key")

with PrideFetchClient(auth=auth) as client:
    files = client.list_raw_files("PXD032067")
    results = client.download_files("PXD032067", files)
```

### Environment variables

```bash
export PRIDEFETCH_API_KEY="your-token"
export PRIDEFETCH_API_KEY_HEADER="X-API-Key"
```

```python
from pridefetch import PrideFetchClient, load_auth_from_env

with PrideFetchClient(auth=load_auth_from_env()) as client:
    project = client.fetch_project("PXD032067")
    print(project["title"])
```

## Common Workflows

### Fetch project metadata

```python
from pridefetch import fetch_project

project = fetch_project("PXD032067")
print(project["title"])
```

### List files and filter by extension

```python
from pridefetch import list_files, filter_files

files = list_files("PXD032067")
raw_only = filter_files(files, extensions=["raw"])
print(len(raw_only))
```

### Filter by size and name

```python
from pridefetch import list_files, filter_files

files = list_files("PXD032067")
filtered = filter_files(
    files,
    extensions=["raw", "mzml"],
    min_size=500 * 1024 * 1024,
    max_size=2 * 1024 * 1024 * 1024,
    name_contains="replicate",
)
```

### Download a subset by exact names

```python
from pridefetch import list_files, filter_files_by_name, download_files

files = list_files("PXD032067")
selected = filter_files_by_name(files, ["file1.raw", "file2.raw"])
results = download_files("PXD032067", selected, output_dir="./downloads/PXD032067")
```

### Build tasks without downloading

```python
from pridefetch import list_files, build_download_tasks

files = list_files("PXD032067")
tasks = build_download_tasks("PXD032067", files, output_dir="./downloads/PXD032067")
print(tasks[0])
```

## Download Behavior

- Parallel downloads use a thread pool.
- Resume uses HTTP Range requests when a partial file exists.
- Use `verify_checksums=True` to validate checksums if PRIDE metadata provides them.

Return payload format from `download_files`:

```python
{
  "file.raw": {
    "status": "downloaded|resumed|exists|skipped|checksum_mismatch|error",
    "path": "/path/to/file.raw",
    "checksum_expected": "...",
    "checksum_actual": "...",
    "error": "..."
  }
}
```

## Error Handling

- Missing datasets return `None` from `fetch_project`.
- Empty file lists return empty arrays and download results.
- Download exceptions are captured per file and surfaced as `status="error"`.

## Performance Tips

- Reuse a `PrideFetchClient` when making multiple API calls.
- Limit `workers` to avoid overwhelming your network or filesystem.
- Disable progress bars (`show_progress=False`) for batch automation logs.

## API Summary

- `fetch_project(accession, session=None, auth=None)`
- `list_files(accession, session=None, auth=None)`
- `list_raw_files(accession, session=None, auth=None)`
- `filter_files(files, extensions=None, min_size=None, max_size=None, name_contains=None)`
- `filter_files_by_name(files, names)`
- `build_download_tasks(accession, files, output_dir=None, overwrite=False, resume=True)`
- `download_files(accession, files, output_dir=None, overwrite=False, resume=True, workers=4, show_progress=True, verify_checksums=False)`
- `PrideFetchClient(auth=None, session=None)`
- `AuthConfig(api_key, header_name="X-API-Key")`
- `load_auth_from_env()`
