# PrideFetch

PrideFetch is a Python API package for discovering and downloading PRIDE Archive dataset files. It wraps the PRIDE REST API, resolves file download URLs, and provides parallel downloads with resume support.

## Installation

```bash
pip install pridefetch
```

## Quick Start

```python
from pridefetch import list_raw_files, download_files

accession = "PXD032067"
files = list_raw_files(accession)

results = download_files(
    accession,
    files,
    output_dir="./downloads/PXD032067",
    overwrite=False,
    resume=True,
    workers=4,
    show_progress=False,
    verify_checksums=True,
)

print(results)
```

## Authenticated Access

PrideFetch supports API key authentication using a configurable header.

```python
from pridefetch import AuthConfig, PrideFetchClient

auth = AuthConfig(api_key="your-token", header_name="X-API-Key")

with PrideFetchClient(auth=auth) as client:
    files = client.list_raw_files("PXD032067")
    results = client.download_files("PXD032067", files)
```

You can also load credentials from environment variables:

```bash
export PRIDEFETCH_API_KEY="your-token"
export PRIDEFETCH_API_KEY_HEADER="X-API-Key"
```

```python
from pridefetch import PrideFetchClient, load_auth_from_env

with PrideFetchClient(auth=load_auth_from_env()) as client:
    project = client.fetch_project("PXD032067")
    print(project["title"])
```

## API Overview

- `fetch_project(accession)`
- `list_files(accession)`
- `list_raw_files(accession)`
- `filter_files(files, ...)`
- `build_download_tasks(accession, files, ...)`
- `download_files(accession, files, ...)`
- `PrideFetchClient` for session reuse and auth

## User Guide

See the full user guide in [DEV.md](https://github.com/ImMortaLGuruji/PrideFetch/blob/main/DEV.md).

## License

MIT License
