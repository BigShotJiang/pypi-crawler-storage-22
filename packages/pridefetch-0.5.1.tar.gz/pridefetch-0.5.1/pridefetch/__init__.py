"""PrideFetch package."""

from .auth import AuthConfig, load_auth_from_env
from .client import PrideFetchClient

from .core import (
    build_download_tasks,
    download_files,
    fetch_project,
    filter_files,
    filter_files_by_name,
    list_files,
    list_raw_files,
)

__all__ = [
    "__version__",
    "AuthConfig",
    "PrideFetchClient",
    "load_auth_from_env",
    "build_download_tasks",
    "download_files",
    "fetch_project",
    "filter_files",
    "filter_files_by_name",
    "list_files",
    "list_raw_files",
]

__version__ = "0.5.1"
