"""PRIDE REST API helpers for project and file metadata."""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Tuple

import requests

BASE_URL = "https://www.ebi.ac.uk/pride/ws/archive/v2"
DEFAULT_TIMEOUT = 30


def _request_json(
    url: str,
    params: Optional[Dict[str, int]] = None,
    session: Optional[requests.Session] = None,
) -> Dict:
    client = session or requests
    response = client.get(url, params=params, timeout=DEFAULT_TIMEOUT)
    if response.status_code == 404:
        return {}
    response.raise_for_status()
    return response.json()


def get_project(
    accession: str, session: Optional[requests.Session] = None
) -> Optional[Dict]:
    url = f"{BASE_URL}/projects/{accession}"
    payload = _request_json(url, session=session)
    return payload or None


def _extract_files(payload: Dict) -> Tuple[List[Dict], Optional[Dict], Optional[str]]:
    """Return a tuple of (files, page_info, next_link)."""
    if isinstance(payload, list):
        return payload, None, None

    if "list" in payload and isinstance(payload["list"], list):
        return payload["list"], payload.get("page"), None

    embedded = payload.get("_embedded")
    if embedded and isinstance(embedded, dict):
        for key in ("files", "projectFiles"):
            if key in embedded and isinstance(embedded[key], list):
                next_link = None
                links = payload.get("_links", {})
                if isinstance(links, dict) and "next" in links:
                    next_link = links["next"].get("href")
                return embedded[key], payload.get("page"), next_link

    if "content" in payload and isinstance(payload["content"], list):
        return payload["content"], payload.get("page"), None

    if "files" in payload and isinstance(payload["files"], list):
        return payload["files"], payload.get("page"), None

    return [], payload.get("page"), None


def iter_project_files(
    accession: str,
    page_size: int = 200,
    session: Optional[requests.Session] = None,
) -> Iterable[Dict]:
    url = f"{BASE_URL}/projects/{accession}/files"
    params: Optional[Dict[str, int]] = {"page": 0, "size": page_size}

    while url:
        payload = _request_json(url, params=params, session=session)
        if not payload:
            break

        files, page_info, next_link = _extract_files(payload)
        for entry in files:
            yield entry

        if next_link:
            url = next_link
            params = None
            continue

        if page_info and "totalPages" in page_info and "number" in page_info:
            if page_info["number"] + 1 >= page_info["totalPages"]:
                break
            params = {"page": page_info["number"] + 1, "size": page_size}
            continue

        if not files:
            break

        if params and "page" in params:
            params = {"page": params["page"] + 1, "size": page_size}
        else:
            break
