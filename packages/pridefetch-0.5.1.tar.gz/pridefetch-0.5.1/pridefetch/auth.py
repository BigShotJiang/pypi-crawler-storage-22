"""Auth helpers for PrideFetch."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional


@dataclass(frozen=True)
class AuthConfig:
    """API key header configuration."""

    api_key: str
    header_name: str = "X-API-Key"

    def apply(self, headers: Dict[str, str]) -> None:
        if self.api_key:
            headers[self.header_name] = self.api_key


def load_auth_from_env(
    api_key_env: str = "PRIDEFETCH_API_KEY",
    header_env: str = "PRIDEFETCH_API_KEY_HEADER",
) -> Optional[AuthConfig]:
    """Load API key auth from environment variables if set."""
    import os

    api_key = os.getenv(api_key_env)
    if not api_key:
        return None
    header_name = os.getenv(header_env, "X-API-Key")
    return AuthConfig(api_key=api_key, header_name=header_name)
