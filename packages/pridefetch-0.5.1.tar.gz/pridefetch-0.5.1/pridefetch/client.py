"""High-level client for PrideFetch API usage."""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Union

import requests

from .auth import AuthConfig
from .core import (
    build_download_tasks,
    download_files,
    fetch_project,
    filter_files,
    filter_files_by_name,
    list_files,
    list_raw_files,
)
from .http import create_session


class PrideFetchClient:
    """Client wrapper that manages an authenticated session."""

    def __init__(
        self,
        auth: Optional[AuthConfig] = None,
        session: Optional[requests.Session] = None,
    ) -> None:
        self._owns_session = session is None
        self.session = session or create_session(auth=auth)

    def close(self) -> None:
        if self._owns_session:
            self.session.close()

    def __enter__(self) -> "PrideFetchClient":
        return self

    def __exit__(self, exc_type, exc, traceback) -> None:
        self.close()

    def fetch_project(self, accession: str) -> Optional[Dict]:
        return fetch_project(accession, session=self.session)

    def list_files(self, accession: str) -> List[Dict]:
        return list_files(accession, session=self.session)

    def list_raw_files(self, accession: str) -> List[Dict]:
        return list_raw_files(accession, session=self.session)

    def filter_files(
        self,
        files: Sequence[Dict],
        extensions: Optional[Sequence[str]] = None,
        min_size: Optional[int] = None,
        max_size: Optional[int] = None,
        name_contains: Optional[str] = None,
    ) -> List[Dict]:
        return filter_files(
            files,
            extensions=extensions,
            min_size=min_size,
            max_size=max_size,
            name_contains=name_contains,
        )

    def filter_files_by_name(
        self, files: Sequence[Dict], names: Sequence[str]
    ) -> List[Dict]:
        return filter_files_by_name(files, names)

    def build_download_tasks(
        self,
        accession: str,
        files: Sequence[Dict],
        output_dir: Optional[str] = None,
        overwrite: Union[Dict[str, bool], bool] = False,
        resume: Union[Dict[str, bool], bool] = True,
    ) -> List[Dict]:
        return build_download_tasks(
            accession,
            files,
            output_dir=output_dir,
            overwrite=overwrite,
            resume=resume,
        )

    def download_files(
        self,
        accession: str,
        files: Sequence[Dict],
        output_dir: Optional[str] = None,
        overwrite: Union[Dict[str, bool], bool] = False,
        resume: Union[Dict[str, bool], bool] = True,
        workers: int = 4,
        show_progress: bool = True,
        verify_checksums: bool = False,
    ) -> Dict[str, Dict[str, Optional[str]]]:
        return download_files(
            accession,
            files,
            output_dir=output_dir,
            overwrite=overwrite,
            resume=resume,
            workers=workers,
            show_progress=show_progress,
            verify_checksums=verify_checksums,
            session=self.session,
        )
