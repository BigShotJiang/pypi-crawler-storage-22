"""Programmatic API for PrideFetch."""

from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Optional, Sequence, Tuple, Union

import requests

from .api import get_project, iter_project_files
from .downloader import download_file
from .auth import AuthConfig
from .http import create_session
from .utils import (
    compute_checksum,
    ensure_dir,
    extract_checksum_info,
    extract_file_size,
    get_file_name,
    is_raw_file,
    normalize_accession,
    normalize_extensions,
    resolve_download_url,
)


def _get_session(
    session: Optional[requests.Session],
    auth: Optional[AuthConfig],
) -> Tuple[requests.Session, bool]:
    if session is not None:
        return session, False
    return create_session(auth=auth), True


def fetch_project(
    accession: str,
    session: Optional[requests.Session] = None,
    auth: Optional[AuthConfig] = None,
) -> Optional[Dict]:
    """Fetch project metadata for a PRIDE accession."""
    client, owns_client = _get_session(session, auth)
    try:
        return get_project(normalize_accession(accession), session=client)
    finally:
        if owns_client:
            client.close()


def list_files(
    accession: str,
    session: Optional[requests.Session] = None,
    auth: Optional[AuthConfig] = None,
) -> List[Dict]:
    """Return all files for a PRIDE accession."""
    client, owns_client = _get_session(session, auth)
    try:
        return list(iter_project_files(normalize_accession(accession), session=client))
    finally:
        if owns_client:
            client.close()


def list_raw_files(
    accession: str,
    session: Optional[requests.Session] = None,
    auth: Optional[AuthConfig] = None,
) -> List[Dict]:
    """Return only .raw files for a PRIDE accession."""
    client, owns_client = _get_session(session, auth)
    try:
        return [
            entry
            for entry in iter_project_files(
                normalize_accession(accession), session=client
            )
            if is_raw_file(entry)
        ]
    finally:
        if owns_client:
            client.close()


def filter_files_by_name(files: Sequence[Dict], names: Sequence[str]) -> List[Dict]:
    """Filter file metadata entries by file name."""
    name_set = {name.strip() for name in names}
    return [entry for entry in files if get_file_name(entry) in name_set]


def filter_files(
    files: Sequence[Dict],
    extensions: Optional[Sequence[str]] = None,
    min_size: Optional[int] = None,
    max_size: Optional[int] = None,
    name_contains: Optional[str] = None,
) -> List[Dict]:
    """Filter file metadata by extension, size, or name match."""
    normalized_exts = normalize_extensions(extensions or [])
    name_query = name_contains.lower() if name_contains else None

    filtered: List[Dict] = []
    for entry in files:
        name = get_file_name(entry)
        if not name:
            continue

        if normalized_exts and not any(
            name.lower().endswith(ext) for ext in normalized_exts
        ):
            continue

        if name_query and name_query not in name.lower():
            continue

        size = extract_file_size(entry)
        if min_size is not None and (size is None or size < min_size):
            continue
        if max_size is not None and (size is None or size > max_size):
            continue

        filtered.append(entry)

    return filtered


def _resolve_flag(
    value: Optional[Union[Dict[str, bool], bool]],
    name: str,
    default: bool,
) -> bool:
    if isinstance(value, dict):
        return value.get(name, default)
    if isinstance(value, bool):
        return value
    return default


def build_download_tasks(
    accession: str,
    files: Sequence[Dict],
    output_dir: Optional[str] = None,
    overwrite: Union[Dict[str, bool], bool] = False,
    resume: Union[Dict[str, bool], bool] = True,
) -> List[Dict]:
    """Prepare download tasks without executing them."""
    accession = normalize_accession(accession)
    download_dir = output_dir or os.path.join(os.getcwd(), "downloads", accession)
    ensure_dir(download_dir)

    tasks: List[Dict] = []
    for file_meta in files:
        name = get_file_name(file_meta)
        if not name:
            continue

        url = resolve_download_url(file_meta, accession)
        if not url:
            continue

        dest_path = os.path.join(download_dir, name)
        file_overwrite = _resolve_flag(overwrite, name, False)
        file_resume = _resolve_flag(resume, name, True)
        checksum_type, checksum_value = extract_checksum_info(file_meta)
        tasks.append(
            {
                "name": name,
                "url": url,
                "dest_path": dest_path,
                "overwrite": file_overwrite,
                "resume": file_resume,
                "checksum_type": checksum_type,
                "checksum": checksum_value,
            }
        )
    return tasks


def download_files(
    accession: str,
    files: Sequence[Dict],
    output_dir: Optional[str] = None,
    overwrite: Union[Dict[str, bool], bool] = False,
    resume: Union[Dict[str, bool], bool] = True,
    workers: int = 4,
    show_progress: bool = True,
    verify_checksums: bool = False,
    session: Optional[requests.Session] = None,
    auth: Optional[AuthConfig] = None,
) -> Dict[str, Dict[str, Optional[str]]]:
    """Download files and return per-file status and checksum info."""
    tasks = build_download_tasks(
        accession,
        files,
        output_dir=output_dir,
        overwrite=overwrite,
        resume=resume,
    )
    if not tasks:
        return {}

    max_workers = max(1, min(workers, len(tasks)))
    results: Dict[str, Dict[str, Optional[str]]] = {}
    client, owns_client = _get_session(session, auth)

    task_by_name = {task["name"]: task for task in tasks}

    try:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {}
            for idx, task in enumerate(tasks):
                future = executor.submit(
                    download_file,
                    task["url"],
                    task["dest_path"],
                    overwrite=task["overwrite"],
                    resume=task["resume"],
                    position=idx,
                    show_progress=show_progress,
                    session=client,
                )
                futures[future] = task["name"]

            for future in as_completed(futures):
                name = futures[future]
                try:
                    status = future.result()
                except Exception as exc:  # pylint: disable=broad-except
                    results[name] = {
                        "status": "error",
                        "path": None,
                        "checksum_expected": None,
                        "checksum_actual": None,
                        "error": str(exc),
                    }
                    continue

                task = task_by_name[name]
                checksum_expected = task.get("checksum")
                checksum_type = task.get("checksum_type")
                checksum_actual = None

                if (
                    verify_checksums
                    and checksum_expected
                    and checksum_type in {"md5", "sha1", "sha256"}
                ):
                    checksum_actual = compute_checksum(task["dest_path"], checksum_type)
                    if checksum_actual != checksum_expected:
                        status = "checksum_mismatch"

                results[name] = {
                    "status": status,
                    "path": task["dest_path"],
                    "checksum_expected": checksum_expected,
                    "checksum_actual": checksum_actual,
                    "error": None,
                }
    finally:
        if owns_client:
            client.close()

    return results
