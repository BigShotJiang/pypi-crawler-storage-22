"""Download helpers with progress reporting."""

from __future__ import annotations

import os
from typing import Optional, Tuple

import requests
from tqdm import tqdm

DEFAULT_TIMEOUT = 60
CHUNK_SIZE = 1024 * 256


def _progress_bar(
    dest_path: str,
    total: int,
    initial: int = 0,
    position: int = 0,
    show_progress: bool = True,
) -> tqdm:
    return tqdm(
        total=total,
        initial=initial,
        unit="B",
        unit_scale=True,
        unit_divisor=1024,
        desc=os.path.basename(dest_path),
        position=position,
        leave=True,
        disable=not show_progress,
    )


def _extract_total(response: requests.Response, existing_size: int) -> int:
    content_range = response.headers.get("Content-Range")
    if content_range and "/" in content_range:
        try:
            return int(content_range.split("/")[-1])
        except ValueError:
            return 0
    length = response.headers.get("Content-Length")
    if length and length.isdigit():
        return int(length) + existing_size
    return 0


def download_file(
    url: str,
    dest_path: str,
    overwrite: bool = False,
    resume: bool = True,
    position: int = 0,
    show_progress: bool = True,
    session: Optional[requests.Session] = None,
) -> str:
    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
    client = session or requests

    if os.path.exists(dest_path) and not overwrite:
        existing_size = os.path.getsize(dest_path)
        if not resume:
            return "skipped"

        headers = {"Range": f"bytes={existing_size}-"}
        response = client.get(
            url,
            stream=True,
            headers=headers,
            timeout=DEFAULT_TIMEOUT,
        )
        if response.status_code == 416:
            return "exists"
        if response.status_code != 206:
            if response.status_code == 200:
                return "skipped"
            response.raise_for_status()

        total = _extract_total(response, existing_size)
        with open(dest_path, "ab") as handle, _progress_bar(
            dest_path,
            total=total,
            initial=existing_size,
            position=position,
            show_progress=show_progress,
        ) as progress:
            for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
                if not chunk:
                    continue
                handle.write(chunk)
                progress.update(len(chunk))

        return "resumed"

    response = client.get(url, stream=True, timeout=DEFAULT_TIMEOUT)
    response.raise_for_status()

    total = int(response.headers.get("Content-Length", 0))
    with open(dest_path, "wb") as handle, _progress_bar(
        dest_path,
        total=total,
        position=position,
        show_progress=show_progress,
    ) as progress:
        for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
            if not chunk:
                continue
            handle.write(chunk)
            progress.update(len(chunk))

    return "downloaded"
