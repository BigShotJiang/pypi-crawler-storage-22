"""HTTP client helpers with retries."""

from __future__ import annotations

from typing import Dict, Iterable, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .auth import AuthConfig


def create_session(
    retries: int = 4,
    backoff: float = 0.5,
    status_forcelist: Iterable[int] = (429, 500, 502, 503, 504),
    headers: Optional[Dict[str, str]] = None,
    auth: Optional[AuthConfig] = None,
) -> requests.Session:
    session = requests.Session()
    if headers:
        session.headers.update(headers)
    if auth:
        auth.apply(session.headers)
    retry = Retry(
        total=retries,
        backoff_factor=backoff,
        status_forcelist=status_forcelist,
        allowed_methods=("GET", "HEAD"),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session
