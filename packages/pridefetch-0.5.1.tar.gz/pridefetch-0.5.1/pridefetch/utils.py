"""Utility helpers for PrideFetch."""

from __future__ import annotations

import hashlib
import os
import re
from typing import Dict, List, Optional, Sequence, Tuple


def get_file_name(file_meta: Dict) -> Optional[str]:
    for key in ("fileName", "filename", "name"):
        value = file_meta.get(key)
        if isinstance(value, str) and value.strip():
            return value
    return None


def is_raw_file(file_meta: Dict) -> bool:
    name = get_file_name(file_meta)
    return bool(name) and name.lower().endswith(".raw")


def normalize_accession(accession: str) -> str:
    return accession.strip().upper()


def normalize_extensions(extensions: Sequence[str]) -> List[str]:
    normalized = []
    for ext in extensions:
        value = ext.strip().lower()
        if not value:
            continue
        if not value.startswith("."):
            value = f".{value}"
        normalized.append(value)
    return normalized


def parse_size(value: str) -> int:
    match = re.match(r"^(\d+)([kKmMgGtT]?[bB]?)?$", value.strip())
    if not match:
        raise ValueError("Invalid size format")
    number = int(match.group(1))
    suffix = (match.group(2) or "").lower().replace("b", "")
    multipliers = {"": 1, "k": 1024, "m": 1024**2, "g": 1024**3, "t": 1024**4}
    return number * multipliers.get(suffix, 1)


def extract_file_size(file_meta: Dict) -> Optional[int]:
    for key in ("fileSizeBytes", "fileSize", "size", "fileSizeInBytes"):
        value = file_meta.get(key)
        if isinstance(value, int):
            return value
        if isinstance(value, str) and value.isdigit():
            return int(value)
    return None


def extract_checksum_info(file_meta: Dict) -> Tuple[Optional[str], Optional[str]]:
    checksum = file_meta.get("checksum")
    checksum_type = file_meta.get("checksumType") or file_meta.get("checksum_type")

    if isinstance(checksum_type, dict):
        checksum_type = checksum_type.get("name") or checksum_type.get("value")

    if isinstance(checksum_type, str):
        checksum_type = checksum_type.strip().lower()

    if isinstance(checksum, str):
        checksum = checksum.strip().lower()

    if not checksum:
        return None, None

    if not checksum_type:
        checksum_type = "sha1"

    checksum_type = checksum_type.replace("-", "")
    if checksum_type in {"sha1", "md5", "sha256"}:
        return checksum_type, checksum

    if "sha1" in checksum_type:
        return "sha1", checksum
    if "sha256" in checksum_type:
        return "sha256", checksum
    if "md5" in checksum_type:
        return "md5", checksum

    return None, checksum


def extract_project_organisms(project: Dict) -> List[str]:
    organisms: List[str] = []
    for key in ("organismName", "organism", "species"):
        value = project.get(key)
        if isinstance(value, str) and value.strip():
            organisms.append(value.strip())

    for key in ("organisms", "projectOrganisms"):
        values = project.get(key)
        if isinstance(values, list):
            for item in values:
                if isinstance(item, str) and item.strip():
                    organisms.append(item.strip())
                if isinstance(item, dict):
                    name = item.get("name") or item.get("organismName")
                    if isinstance(name, str) and name.strip():
                        organisms.append(name.strip())

    return organisms


def parse_indices(raw: str, max_index: int) -> List[int]:
    selected: List[int] = []
    tokens = [
        token.strip() for token in raw.replace(" ", "").split(",") if token.strip()
    ]
    for token in tokens:
        if token.lower() in {"a", "all"}:
            return list(range(1, max_index + 1))
        if "-" in token:
            start_str, end_str = token.split("-", 1)
            if not start_str.isdigit() or not end_str.isdigit():
                raise ValueError("Invalid range")
            start, end = int(start_str), int(end_str)
            if start < 1 or end > max_index or start > end:
                raise ValueError("Range out of bounds")
            selected.extend(range(start, end + 1))
        else:
            if not token.isdigit():
                raise ValueError("Invalid selection")
            index = int(token)
            if index < 1 or index > max_index:
                raise ValueError("Selection out of bounds")
            selected.append(index)
    return sorted(set(selected))


def resolve_download_url(
    file_meta: Dict,
    accession: str,
) -> Optional[str]:
    public_locations = file_meta.get("publicFileLocations")
    if isinstance(public_locations, list):
        for entry in public_locations:
            if not isinstance(entry, dict):
                continue
            value = entry.get("value")
            if isinstance(value, str) and value.strip():
                if value.startswith("http://") or value.startswith("https://"):
                    return value
                if value.startswith("ftp://"):
                    return value.replace("ftp://", "https://", 1)
                if value.startswith("/"):
                    return f"https://ftp.pride.ebi.ac.uk{value}"

    for key in ("publicFileLocation", "downloadLink", "fileLocation", "publicLocation"):
        value = file_meta.get(key)
        if isinstance(value, str) and value.strip():
            if value.startswith("http://") or value.startswith("https://"):
                return value
            if value.startswith("ftp://"):
                return value.replace("ftp://", "https://", 1)
            if value.startswith("/"):
                return f"https://ftp.pride.ebi.ac.uk{value}"

    name = get_file_name(file_meta)
    archive_year = file_meta.get("archiveYear")
    archive_month = file_meta.get("archiveMonth")
    if name and archive_year and archive_month:
        month = str(archive_month).zfill(2)
        return (
            "https://ftp.pride.ebi.ac.uk/pride/data/archive/"
            f"{archive_year}/{month}/{accession}/{name}"
        )

    return None


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def compute_checksum(
    path: str,
    algorithm: str,
    chunk_size: int = 1024 * 1024,
) -> str:
    hasher = hashlib.new(algorithm)
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            hasher.update(chunk)
    return hasher.hexdigest()
