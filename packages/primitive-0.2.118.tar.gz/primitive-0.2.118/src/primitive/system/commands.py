import click

from ..utils import power


@click.group()
def cli():
    """cross-platform system commands"""
    pass


@cli.command("reboot")
def reboot():
    """Restarts or reboots the system."""

    power.reboot()


@cli.command("halt")
def halt():
    """Instructs hardware to stop CPU functions."""

    power.halt()


@cli.command("poweroff")
def poweroff():
    """Instruct the system to power down."""

    power.poweroff()
