import subprocess
import platform
from typing import Literal


def halt():
    os_family = platform.system()

    match os_family:
        case "Linux":
            linux_halt()
        case "Darwin":
            darwin_halt()
        case "Windows":
            windows_halt()
        case _:
            raise Exception(f"OS '{os_family}' not supported")


def reboot():
    os_family = platform.system()

    match os_family:
        case "Linux":
            linux_reboot()
        case "Darwin":
            darwin_reboot()
        case "Windows":
            windows_reboot()
        case _:
            raise Exception(f"OS '{os_family}' not supported")


def poweroff():
    os_family = platform.system()

    match os_family:
        case "Linux":
            linux_poweroff()
        case "Darwin":
            darwin_poweroff()
        case "Windows":
            windows_poweroff()
        case _:
            raise Exception(f"OS '{os_family}' not supported")


def linux_halt(
    mode: Literal["Force", "Shutdown", "Regular"] = "Shutdown", power_off: bool = False
):
    power_off_arg = ["--poweroff"] if power_off else []

    match mode:
        case "Shutdown":
            subprocess.run(
                ["sudo", "shutdown", "-h"] + power_off_arg + ["now"], check=True
            )
        case "Regular":
            subprocess.run(["sudo", "halt"] + power_off_arg, check=True)
        case "Force":
            subprocess.run(["sudo", "halt", "--force"] + power_off_arg, check=True)


def linux_reboot(mode: Literal["Force", "Shutdown", "Regular"] = "Shutdown"):
    match mode:
        case "Shutdown":
            subprocess.run(["sudo", "shutdown", "-r", "now"], check=True)
        case "Regular":
            subprocess.run(["sudo", "reboot"], check=True)
        case "Force":
            subprocess.run(["sudo", "reboot", "--force"], check=True)


def linux_poweroff(mode: Literal["Force", "Shutdown", "Regular"] = "Shutdown"):
    match mode:
        case "Shutdown":
            subprocess.run(["sudo", "shutdown", "-P", "now"], check=True)
        case "Regular":
            subprocess.run(["sudo", "poweroff"], check=True)
        case "Force":
            subprocess.run(["sudo", "poweroff", "--force"], check=True)


# NOTE: no halt on windows
def windows_halt(mode: Literal["Force", "Shutdown", "Regular"] = "Shutdown"):
    windows_poweroff(mode)


def windows_reboot(mode: Literal["Force", "Shutdown"] = "Shutdown"):
    args = ["/r"]  # /r = reboot
    if mode == "Force":
        args.append("/f")
    subprocess.run(["shutdown"] + args + ["/t", "0"], check=True)


def windows_poweroff(mode: Literal["Force", "Shutdown", "Regular"] = "Shutdown"):
    args = ["/p"]  # /p = power off

    match mode:
        case "Shutdown":
            args.append("/s")
        case "Force":
            args.append("/f")

    subprocess.run(["shutdown"] + args + ["/t", "0"], check=True)


def darwin_halt(mode: Literal["Shutdown", "Regular"] = "Shutdown"):
    match mode:
        case "Shutdown":
            subprocess.run(["sudo", "shutdown", "-h", "now"], check=True)
        case "Regular":
            subprocess.run(["sudo", "halt"], check=True)


def darwin_reboot(mode: Literal["Shutdown", "Regular"] = "Shutdown"):
    match mode:
        case "Shutdown":
            subprocess.run(["sudo", "shutdown", "-r", "now"], check=True)
        case "Regular":
            subprocess.run(["sudo", "reboot"], check=True)


# NOTE: no poweroff on macos
def darwin_poweroff(mode: Literal["Shutdown", "Regular"] = "Shutdown"):
    darwin_halt(mode)
