# printa

Pastel-friendly pretty printer for Python.

## Install

```bash
pip install printa
```

## Usage

```python
import printa

printa("hi", 123, True, None, {"a": 1, "b": [2, 3]})
printa.set_theme("mono")
printa("after mono")
```

## Themes

- `pastel` (default)
- `solarized`
- `dracula`
- `gruvbox`
- `mono`

```python
import printa

printa.available_themes()
printa.set_theme("pastel")
```
