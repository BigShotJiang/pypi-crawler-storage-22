"""Printa: pastel-friendly pretty printer."""
from __future__ import annotations

import sys
from dataclasses import dataclass
from typing import Any, Iterable


__version__ = "0.1.0"

RESET = "\x1b[0m"


@dataclass(frozen=True)
class Theme:
    name: str
    text: str
    number: str
    boolean: str
    none: str
    string: str
    collection: str
    key: str


THEMES = {
    "pastel": Theme(
        name="pastel",
        text="\x1b[38;5;232m",      # near-black
        number="\x1b[38;5;141m",    # pastel purple
        boolean="\x1b[38;5;110m",   # pastel cyan
        none="\x1b[38;5;244m",      # soft gray
        string="\x1b[38;5;232m",    # near-black
        collection="\x1b[38;5;108m",# pastel green
        key="\x1b[38;5;217m",       # pastel pink
    ),
    "solarized": Theme(
        name="solarized",
        text="\x1b[38;5;234m",      # base02
        number="\x1b[38;5;136m",    # yellow
        boolean="\x1b[38;5;37m",    # cyan
        none="\x1b[38;5;244m",      # base0
        string="\x1b[38;5;33m",     # blue
        collection="\x1b[38;5;64m", # green
        key="\x1b[38;5;166m",       # orange
    ),
    "dracula": Theme(
        name="dracula",
        text="\x1b[38;5;255m",      # foreground
        number="\x1b[38;5;213m",    # pink
        boolean="\x1b[38;5;81m",    # cyan
        none="\x1b[38;5;241m",      # comment
        string="\x1b[38;5;84m",     # green
        collection="\x1b[38;5;141m",# purple
        key="\x1b[38;5;215m",       # orange
    ),
    "gruvbox": Theme(
        name="gruvbox",
        text="\x1b[38;5;223m",      # fg
        number="\x1b[38;5;214m",    # orange
        boolean="\x1b[38;5;108m",   # aqua
        none="\x1b[38;5;244m",      # gray
        string="\x1b[38;5;142m",    # green
        collection="\x1b[38;5;175m",# purple
        key="\x1b[38;5;109m",       # blue
    ),
    "mono": Theme(
        name="mono",
        text="\x1b[38;5;250m",
        number="\x1b[38;5;250m",
        boolean="\x1b[38;5;250m",
        none="\x1b[38;5;250m",
        string="\x1b[38;5;250m",
        collection="\x1b[38;5;250m",
        key="\x1b[38;5;250m",
    ),
}


def _is_tty(stream: Any) -> bool:
    return bool(getattr(stream, "isatty", lambda: False)())


def _color(text: str, color: str, enable: bool) -> str:
    if not enable:
        return text
    return f"{color}{text}{RESET}"


def _render(obj: Any, theme: Theme, enable: bool) -> str:
    if obj is None:
        return _color("None", theme.none, enable)
    if isinstance(obj, bool):
        return _color("True" if obj else "False", theme.boolean, enable)
    if isinstance(obj, (int, float, complex)):
        return _color(repr(obj), theme.number, enable)
    if isinstance(obj, str):
        return _color(repr(obj), theme.string, enable)

    if isinstance(obj, dict):
        items = []
        for k, v in obj.items():
            k_plain = _render(k, theme, False)
            k_str = _color(k_plain, theme.key, enable)
            v_str = _render(v, theme, enable)
            items.append(f"{k_str}: {v_str}")
        inside = ", ".join(items)
        return _color("{" + inside + "}", theme.collection, enable)

    if isinstance(obj, list):
        inside = ", ".join(_render(v, theme, enable) for v in obj)
        return _color("[" + inside + "]", theme.collection, enable)

    if isinstance(obj, tuple):
        inside = ", ".join(_render(v, theme, enable) for v in obj)
        if len(obj) == 1:
            inside = inside + ","
        return _color("(" + inside + ")", theme.collection, enable)

    if isinstance(obj, set):
        if not obj:
            return _color("set()", theme.collection, enable)
        inside = ", ".join(_render(v, theme, enable) for v in obj)
        return _color("{" + inside + "}", theme.collection, enable)

    if isinstance(obj, Iterable) and not isinstance(obj, (bytes, bytearray)):
        inside = ", ".join(_render(v, theme, enable) for v in obj)
        return _color("[" + inside + "]", theme.collection, enable)

    return _color(repr(obj), theme.text, enable)


class _Printa:
    def __init__(self) -> None:
        self._theme = THEMES["pastel"]

    def set_theme(self, name: str) -> None:
        key = name.strip().lower()
        if key not in THEMES:
            raise ValueError(f"Unknown theme '{name}'. Available: {', '.join(sorted(THEMES))}")
        self._theme = THEMES[key]

    def available_themes(self) -> tuple[str, ...]:
        return tuple(sorted(THEMES))

    def __call__(self, *values: Any, sep: str = " ", end: str = "\n", file: Any = None) -> None:
        if file is None:
            file = sys.stdout
        enable = _is_tty(file)
        rendered = sep.join(_render(v, self._theme, enable) for v in values)
        print(rendered, sep="", end=end, file=file)


_instance = _Printa()
_instance.__all__ = ["set_theme", "available_themes", "__version__"]
_instance.__version__ = __version__
_instance.__doc__ = __doc__
_instance.__name__ = __name__

sys.modules[__name__] = _instance
