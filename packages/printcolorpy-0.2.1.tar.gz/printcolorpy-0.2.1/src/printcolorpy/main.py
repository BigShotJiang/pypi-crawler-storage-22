from colorama import Fore, Back, Style, init

init(autoreset=True) #! `autoreset=True` is crucial. It ensures that after each print, the color is reset and not LEAK.


#% "Style.BRIGHT" makes the text BOLDER, not brighter lol.

class PrintColorPy:
    def header1(self, text: str):
        #* Bold Yellow background
        print(Back.YELLOW  + Style.BRIGHT + text )

    def header2(self, text: str):
        #* Bold Yellow text
        print(Fore.YELLOW + Style.BRIGHT + text )

    def bold_text(self, text: str):
        #* Bold white text
        print(Style.BRIGHT + text)

    def success(self, text: str):
        #* Black text on Green background
        print(Back.GREEN  + text )

    def error(self, text: str):
        #* White text on red background
        print(Back.RED + text )

    def red(self, text: str):
        #* Bold red text
        print(Fore.RED + Style.BRIGHT + text )

    def blue(self, text: str):
        #* Bold blue text
        print(Fore.BLUE + Style.BRIGHT + text )

    def space(self, number: int = 1):
        print("\n" * number)

printcolorpy = PrintColorPy()