from printcolorpy import printcolorpy

def print_color_test():
    print("Header 1:")
    printcolorpy.header1("Hello, World!")
    print("\n")

    print("Header 2:")
    printcolorpy.header2("Hello, World!")
    print("\n")

    print("Bold Text:")
    printcolorpy.bold_text("Hello, World!")
    print("\n")

    print("Success:")
    printcolorpy.success("Hello, World!")
    print("\n")

    print("Error:")
    printcolorpy.error("Hello, World!")
    print("\n")

    print("Red:")
    printcolorpy.red("Hello, World!")
    print("\n")

    print("Blue:")
    printcolorpy.blue("Hello, World!")
    print("\n")