Once printcolorpy is installed, to see what each method of printcolorpy does run this binary:

`
    printcolorpy
`