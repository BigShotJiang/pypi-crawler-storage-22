from printcolorpy.main import printcolorpy
from printcolorpy.print_color_test import print_color_test


__all__ = ["printcolorpy", "print_color_test"]


