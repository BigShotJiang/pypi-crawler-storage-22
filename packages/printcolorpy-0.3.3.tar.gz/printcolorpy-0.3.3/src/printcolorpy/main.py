from colorama import Fore, Back, Style, init

init(autoreset=True) #! `autoreset=True` is crucial. It ensures that after each print, the color is reset and not LEAK.

    #! Still, I've noticed that in some cases resetting doesn't work, but in some cases it actually does work.
    #! That is why either way, I used "Fore.RESET" on every method.
        #! Example: Colorama can work with input statements but it's a bit FUNKY lol 

#% "Style.BRIGHT" makes the text BOLDER, not brighter lol.

class PrintColorPy:
    def header1(self, text: str):
        #* Bold Yellow background
        return Back.YELLOW  + Style.BRIGHT + text + Fore.RESET

    def header2(self, text: str):
        #* Bold Yellow text
        return Fore.YELLOW + Style.BRIGHT + text + Fore.RESET

    def bold_text(self, text: str):
        #* Bold white text
        return Style.BRIGHT + text + Fore.RESET

    def success(self, text: str):
        #* Black text on Green background
        return Back.GREEN  + text + Fore.RESET

    def error(self, text: str):
        #* White text on red background
        return Back.RED + text + Fore.RESET

    def red(self, text: str):
        #* Bold red text
        return Fore.RED + Style.BRIGHT + text + Fore.RESET

    def blue(self, text: str):
        #* Bold blue text
        return Fore.BLUE + Style.BRIGHT + text + Fore.RESET

    def space(self, number: int = 1):
        return "\n" * number

printcolorpy = PrintColorPy()