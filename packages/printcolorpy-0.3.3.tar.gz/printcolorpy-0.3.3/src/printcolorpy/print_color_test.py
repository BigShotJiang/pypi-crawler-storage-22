from printcolorpy import printcolorpy as color

def print_color_test():
    print("Header 1:")
    print(color.header1("Hello, World!"))
    print("\n")

    print("Header 2:")
    print(color.header2("Hello, World!"))
    print("\n")

    print("Bold Text:")
    print(color.bold_text("Hello, World!"))
    print("\n")

    print("Success:")
    print(color.success("Hello, World!"))
    print("\n")

    print("Error:")
    print(color.error("Hello, World!"))
    print("\n")

    print("Red:")
    print(color.red("Hello, World!"))
    print("\n")

    print("Blue:")
    print(color.blue("Hello, World!"))
    print("\n")