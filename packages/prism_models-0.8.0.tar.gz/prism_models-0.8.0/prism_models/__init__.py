"""Data models for the Prism RAG system."""

__version__ = "0.1.0"


from prism_models.agent_profile import (
    Agent,
    AgentCollectionAccess,
    AgentProfile,
    AgentProfileStatus,
    ContactProfile,
    Profile,
    ProfileCollectionAccess,
)
from prism_models.base import POSTGRES_NAMING_CONVENTION, Base, BaseModel, TimestampMixin
from prism_models.chat import Contact, Conversation, ConversationMessage, ConversationMessageMetadata, UserPreferences
from prism_models.content import (
    Chunk,
    ChunkConfig,
    Collection,
    CollectionDocument,
    Document,
    IntegrationConfig,
    RFP,
    RFPQNA,
    Source,
    Vector,
)
from prism_models.feedback import Augmentation, Feedback, FeedbackAnalysis, FeedbackStatus, FeedbackType
from prism_models.qdrant import QdrantVectorPayload, DestinationVectorPayload, PydanticType
from prism_models.notification import NotificationTarget, NotificationOutbox

__all__ = [
    "POSTGRES_NAMING_CONVENTION",
    "Agent",
    "AgentCollectionAccess",
    "AgentProfile",
    "AgentProfileStatus",
    "Augmentation",
    "Base",
    "BaseModel",
    "Chunk",
    "ChunkConfig",
    "Collection",
    "CollectionDocument",
    "Contact",
    "ContactProfile",
    "Conversation",
    "ConversationMessage",
    "ConversationMessageMetadata",
    "UserPreferences",
    "DestinationVectorPayload",
    "Document",
    "Feedback",
    "FeedbackAnalysis",
    "FeedbackStatus",
    "FeedbackType",
    "IntegrationConfig",
    "RFP",
    "RFPQNA",
    "Profile",
    "ProfileCollectionAccess",
    "PydanticType",
    "QdrantVectorPayload",
    "Source",
    "TimestampMixin",
    "Vector",
    "NotificationTarget",
    "NotificationOutbox",
]
