"""
03: State Geometry Entry Point
==============================

Pure orchestration - calls eigendecomp engine from engines/state/eigendecomp.py.
Computes the SHAPE of the signal distribution around each state.

Stages: signal_vector.parquet + state_vector.parquet → state_geometry.parquet

Key insight (Avery Rudder): effective_dim shows 63% importance in predicting RUL.
"""

import numpy as np
import polars as pl
from pathlib import Path
from typing import List, Dict, Optional, Any

# Import the actual computation from engine
from prism.engines.state.eigendecomp import compute as compute_eigenvalues_engine


# Feature groups
try:
    from prism.engines.geometry.config import DEFAULT_FEATURE_GROUPS
except ImportError:
    DEFAULT_FEATURE_GROUPS = {
        'shape': ['kurtosis', 'skewness', 'crest_factor'],
        'complexity': ['permutation_entropy', 'hurst', 'acf_lag1'],
        'spectral': ['spectral_entropy', 'spectral_centroid', 'band_low_rel', 'band_mid_rel', 'band_high_rel'],
    }


def compute_eigenvalues(
    signal_matrix: np.ndarray,
    centroid: np.ndarray,
    min_signals: int = 3,
    normalize: bool = True
) -> Dict[str, Any]:
    """
    Wrapper around eigendecomp engine - centers around centroid first.

    Args:
        signal_matrix: N_signals × D_features
        centroid: D_features centroid from state_vector
        min_signals: Minimum signals for reliable eigenvalues
        normalize: If True, Z-score normalize before SVD

    Returns:
        Eigenvalue metrics including effective_dim
    """
    N, D = signal_matrix.shape

    if N < min_signals:
        return _empty_eigenvalues(D)

    # Remove NaN/Inf
    valid_mask = np.isfinite(signal_matrix).all(axis=1)
    if valid_mask.sum() < min_signals:
        return _empty_eigenvalues(D)

    signal_matrix = signal_matrix[valid_mask]
    N = len(signal_matrix)

    # Center around centroid
    centered = signal_matrix - centroid

    # Z-score normalize if requested
    if normalize:
        std = np.std(centered, axis=0, keepdims=True)
        std = np.where(std < 1e-10, 1.0, std)
        normalized = centered / std
    else:
        normalized = centered

    # Call engine
    engine_result = compute_eigenvalues_engine(normalized)

    # Add PC1 alignment metrics (orchestration-level)
    eigenvalues = engine_result['eigenvalues']
    total = engine_result['total_variance']

    # Eigenvalue ratios
    if len(eigenvalues) >= 2 and eigenvalues[0] > 1e-10:
        ratio_2_1 = eigenvalues[1] / eigenvalues[0]
    else:
        ratio_2_1 = 0

    if len(eigenvalues) >= 3 and eigenvalues[0] > 1e-10:
        ratio_3_1 = eigenvalues[2] / eigenvalues[0]
    else:
        ratio_3_1 = 0

    # Eigenvalue entropy
    if total > 1e-10:
        nonzero = eigenvalues[eigenvalues > 1e-10]
        if len(nonzero) > 1:
            p = nonzero / nonzero.sum()
            eigenvalue_entropy = -np.sum(p * np.log(p))
            max_entropy = np.log(len(nonzero))
            eigenvalue_entropy_norm = eigenvalue_entropy / max_entropy if max_entropy > 0 else 0
        else:
            eigenvalue_entropy = 0
            eigenvalue_entropy_norm = 0
    else:
        eigenvalue_entropy = 0
        eigenvalue_entropy_norm = 0

    return {
        'eigenvalues': eigenvalues,
        'explained_ratios': engine_result['explained_ratio'],
        'total_variance': total,
        'effective_dim': engine_result['effective_dim'],
        'condition_number': engine_result['condition_number'],
        'eigenvalue_entropy': eigenvalue_entropy,
        'eigenvalue_entropy_normalized': eigenvalue_entropy_norm,
        'ratio_2_1': ratio_2_1,
        'ratio_3_1': ratio_3_1,
        'n_signals': N,
        'n_features': D,
    }


def _empty_eigenvalues(D: int) -> Dict[str, Any]:
    """Return empty eigenvalue result."""
    return {
        'eigenvalues': np.zeros(D),
        'explained_ratios': np.zeros(D),
        'total_variance': 0.0,
        'effective_dim': 0.0,
        'condition_number': 1.0,
        'eigenvalue_entropy': 0.0,
        'eigenvalue_entropy_normalized': 0.0,
        'ratio_2_1': 0.0,
        'ratio_3_1': 0.0,
        'n_signals': 0,
        'n_features': D,
    }


def compute_state_geometry(
    signal_vector_path: str,
    state_vector_path: str,
    output_path: str = "state_geometry.parquet",
    feature_groups: Optional[Dict[str, List[str]]] = None,
    max_eigenvalues: int = 5,
    verbose: bool = True
) -> pl.DataFrame:
    """
    Compute state geometry (eigenvalues per engine per index).

    Args:
        signal_vector_path: Path to signal_vector.parquet
        state_vector_path: Path to state_vector.parquet
        output_path: Output path
        feature_groups: Dict mapping engine names to feature lists
        max_eigenvalues: Maximum eigenvalues to store
        verbose: Print progress

    Returns:
        State geometry DataFrame
    """
    if verbose:
        print("=" * 70)
        print("03: STATE GEOMETRY - Eigenvalues and shape metrics")
        print("=" * 70)

    # Load data
    signal_vector = pl.read_parquet(signal_vector_path)
    state_vector = pl.read_parquet(state_vector_path)

    # Identify features
    meta_cols = ['unit_id', 'I', 'signal_id', 'cohort']
    all_features = [c for c in signal_vector.columns if c not in meta_cols]

    # Determine feature groups
    if feature_groups is None:
        feature_groups = {}
        for name, features in DEFAULT_FEATURE_GROUPS.items():
            available = [f for f in features if f in all_features]
            if len(available) >= 2:
                feature_groups[name] = available

        if not feature_groups and len(all_features) >= 2:
            feature_groups['full'] = all_features[:3]

    if verbose:
        print(f"Feature groups: {list(feature_groups.keys())}")
        print()

    # Determine grouping columns
    has_cohort = 'cohort' in signal_vector.columns
    group_cols = ['cohort', 'I'] if has_cohort else ['I']

    # Process each group
    results = []
    groups = signal_vector.group_by(group_cols, maintain_order=True)
    n_groups = signal_vector.select(group_cols).unique().height

    # Track previous PC1 for alignment
    prev_eigenvalues_by_key: Dict[Any, np.ndarray] = {}

    if verbose:
        print(f"Processing {n_groups} groups...")

    for i, (group_key, group) in enumerate(groups):
        if has_cohort:
            cohort, I = group_key if isinstance(group_key, tuple) else (group_key, None)
        else:
            cohort = None
            I = group_key[0] if isinstance(group_key, tuple) else group_key

        # Get state vector for this group
        if has_cohort and 'cohort' in state_vector.columns:
            state_row = state_vector.filter(
                (pl.col('I') == I) & (pl.col('cohort') == cohort)
            )
        else:
            state_row = state_vector.filter(pl.col('I') == I)

        if len(state_row) == 0:
            continue

        # Compute eigenvalues for each engine
        for engine_name, features in feature_groups.items():
            available = [f for f in features if f in group.columns]
            if len(available) < 2:
                continue

            # Get centroid from state_vector
            centroid_cols = [f'state_{engine_name}_{f}' for f in available]
            centroid_available = [c for c in centroid_cols if c in state_row.columns]

            if len(centroid_available) != len(available):
                # Compute centroid from data
                matrix = group.select(available).to_numpy()
                valid_mask = np.isfinite(matrix).all(axis=1)
                if valid_mask.sum() > 0:
                    centroid = np.mean(matrix[valid_mask], axis=0)
                else:
                    continue
            else:
                centroid = state_row.select(centroid_available).to_numpy().flatten()

            # Get signal matrix
            matrix = group.select(available).to_numpy()

            # Compute eigenvalues
            eigen_result = compute_eigenvalues(matrix, centroid)

            # Build result row
            unit_id = group['unit_id'][0] if 'unit_id' in group.columns else ''
            row = {
                'I': I,
                'engine': engine_name,
                'n_signals': eigen_result['n_signals'],
                'n_features': eigen_result['n_features'],
            }
            if cohort:
                row['cohort'] = cohort
            if unit_id:
                row['unit_id'] = unit_id

            # Eigenvalues
            for j in range(min(max_eigenvalues, len(eigen_result['eigenvalues']))):
                row[f'eigenvalue_{j+1}'] = float(eigen_result['eigenvalues'][j])

            # Explained ratios
            for j in range(min(max_eigenvalues, len(eigen_result['explained_ratios']))):
                row[f'explained_{j+1}'] = float(eigen_result['explained_ratios'][j])

            # Derived metrics
            row['effective_dim'] = eigen_result['effective_dim']
            row['total_variance'] = eigen_result['total_variance']
            row['eigenvalue_entropy'] = eigen_result['eigenvalue_entropy']
            row['eigenvalue_entropy_norm'] = eigen_result['eigenvalue_entropy_normalized']
            row['condition_number'] = eigen_result['condition_number']
            row['ratio_2_1'] = eigen_result['ratio_2_1']
            row['ratio_3_1'] = eigen_result['ratio_3_1']

            results.append(row)

        if verbose and (i + 1) % 1000 == 0:
            print(f"  Processed {i + 1}/{n_groups}...")

    # Build DataFrame
    result = pl.DataFrame(results)
    result.write_parquet(output_path)

    if verbose:
        print(f"\nSaved: {output_path}")
        print(f"Shape: {result.shape}")

        # Summary per engine
        for engine_name in feature_groups.keys():
            engine_data = result.filter(pl.col('engine') == engine_name)
            if len(engine_data) > 0:
                print(f"\n{engine_name} engine:")
                print(f"  effective_dim: mean={engine_data['effective_dim'].mean():.2f}, "
                      f"std={engine_data['effective_dim'].std():.2f}")

    return result


def main():
    import sys

    if len(sys.argv) < 3:
        print("Usage: python 03_state_geometry.py <signal_vector.parquet> <state_vector.parquet> [output.parquet]")
        sys.exit(1)

    signal_path = sys.argv[1]
    state_path = sys.argv[2]
    output_path = sys.argv[3] if len(sys.argv) > 3 else "state_geometry.parquet"

    compute_state_geometry(signal_path, state_path, output_path)


if __name__ == "__main__":
    main()
