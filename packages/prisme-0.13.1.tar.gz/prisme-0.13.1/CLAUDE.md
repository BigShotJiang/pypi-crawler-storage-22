# CLAUDE.md

> Project context for Claude Code sessions. See also: [AGENT.md](AGENT.md) | [CONTRIBUTING.md](CONTRIBUTING.md)

## Project

Prism (`prisme` on PyPI) is a code generation framework that produces full-stack CRUD applications from Pydantic model specifications. Python 3.13+, MIT licensed, v0.12.1.

## Quick Reference

Always use `uv run` to execute Python, pytest, and prism commands (e.g., `uv run python`, `uv run pytest`, `uv run prism`).

```bash
uv sync --all-extras                    # Install dependencies
uv run pytest                           # Run tests (870+ tests)
uv run pytest -x                        # Stop on first failure
uv run pytest --cov                     # With coverage
uv run ruff check . --fix               # Lint + auto-fix
uv run ruff format .                    # Format
uv run mypy src                         # Type check
uv run mkdocs build --strict            # Build docs
```

## Architecture

- `src/prism/cli.py` - CLI entry point (58+ commands, 11 groups)
- `src/prism/spec/` - Pydantic specification models
- `src/prism/generators/` - 30 generator classes (backend, frontend, testing, infrastructure)
- `src/prism/templates/jinja2/` - 100+ Jinja2 templates
- `src/prism/docker/` - Docker/Traefik proxy management
- `src/prism/deploy/` - Hetzner/Terraform deployment
- `src/prism/devcontainer/` - Dev container lifecycle
- `tests/` - Test suite (58 files)

## Code Style

- Ruff: line-length 100, target py313, rules E/W/F/I/UP/B/SIM/TCH/RUF
- Conventional commits: `type(scope): description`
- Types: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`, `ci`, `perf`, `build`
- Pre-commit hooks enforce formatting; pre-push runs full CI checks

## Development Documentation

Internal development docs live in `dev/`. See **[dev/dev-docs.md](dev/dev-docs.md)** for structure and conventions.

- **[dev/roadmap.md](dev/roadmap.md)** - Priorities, status tracking, release history
- **[dev/plans/](dev/plans/)** - 8 feature implementation plans
- **[dev/issues/](dev/issues/)** - 15 tracked issue documents
- **[dev/tasks/](dev/tasks/)** - Active task tracking

Always check `dev/roadmap.md` before starting work on a new feature to understand priorities and dependencies.

## Testing

Markers: `slow`, `e2e`, `docker` (all excluded from default runs). Async mode: auto. Timeout: 120s.

## CI/CD

GitHub Actions: lint -> test -> docs -> e2e -> e2e-docker. Semantic release on main merge publishes to PyPI.
