"""Infrastructure code generators for Prism.

This module contains generators for:
- Docker Compose stacks for authentication providers
- Traefik reverse proxy configuration
- Environment configuration templates
"""

from prism.generators.infrastructure.authentik_compose import AuthentikComposeGenerator

__all__ = [
    "AuthentikComposeGenerator",
]
