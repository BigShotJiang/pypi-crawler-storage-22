"""Authentik Docker Compose generator for Prism.

This generator creates Docker Compose infrastructure for Authentik:
- docker-compose.authentik.yml with all required services
- traefik.yml static configuration
- .env.authentik.example template
"""

from __future__ import annotations

from pathlib import Path

from prism.generators.base import GeneratedFile, GeneratorBase
from prism.spec.stack import FileStrategy
from prism.utils.template_engine import TemplateRenderer


class AuthentikComposeGenerator(GeneratorBase):
    """Generates Docker Compose stack for Authentik authentication."""

    REQUIRED_TEMPLATES = [
        "docker/authentik/docker-compose.authentik.yml.jinja2",
        "docker/authentik/traefik.yml.jinja2",
        "docker/authentik/.env.authentik.example.jinja2",
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Skip generation if auth is not enabled or preset is not authentik
        if not self.spec.auth.enabled or self.spec.auth.preset != "authentik":
            self.skip_generation = True
            return

        # Initialize template renderer
        self.renderer = TemplateRenderer()
        self.renderer.validate_templates_exist(self.REQUIRED_TEMPLATES)

        # Infrastructure files go to the project root (output_dir)
        self.infra_path = self.output_dir

    def generate_files(self) -> list[GeneratedFile]:
        """Generate all Authentik Docker infrastructure files.

        Returns:
            List of generated files with content and strategies
        """
        if getattr(self, "skip_generation", False):
            return []

        files = []

        # Docker Compose stack
        files.append(self._generate_docker_compose())

        # Traefik configuration (only if Traefik is enabled)
        if self.spec.traefik.enabled:
            files.append(self._generate_traefik_config())

        # Environment template
        files.append(self._generate_env_template())

        return files

    def _get_common_context(self) -> dict:
        """Get common template context variables.

        Returns:
            Dictionary with common context variables
        """
        project_name = self.get_package_name()
        authentik_config = self.spec.auth.authentik
        traefik_config = self.spec.traefik

        return {
            "project_name": project_name,
            "project_title": self.spec.effective_title,
            # Authentik configuration
            "authentik_version": authentik_config.version,
            "authentik_subdomain": authentik_config.subdomain,
            "mfa_enabled": authentik_config.mfa.enabled,
            "mfa_methods": authentik_config.mfa.methods,
            "self_signup": authentik_config.self_signup,
            "email_verification": authentik_config.email_verification,
            "email_enabled": authentik_config.email_verification,
            # Traefik configuration
            "traefik_enabled": traefik_config.enabled,
            "ssl_provider": traefik_config.ssl_provider,
            "ssl_email": traefik_config.ssl_email,
            "domain": traefik_config.domain,
            "traefik_dashboard": traefik_config.dashboard_enabled,
            "traefik_subdomain": traefik_config.dashboard_subdomain,
        }

    def _generate_docker_compose(self) -> GeneratedFile:
        """Generate Docker Compose file for Authentik stack.

        Returns:
            GeneratedFile for docker-compose.authentik.yml
        """
        context = self._get_common_context()

        content = self.renderer.render_file(
            "docker/authentik/docker-compose.authentik.yml.jinja2",
            context=context,
        )

        return GeneratedFile(
            path=Path("docker-compose.authentik.yml"),
            content=content,
            strategy=FileStrategy.GENERATE_ONCE,  # Allow customization
            description="Authentik Docker Compose stack",
        )

    def _generate_traefik_config(self) -> GeneratedFile:
        """Generate Traefik static configuration.

        Returns:
            GeneratedFile for traefik.yml
        """
        context = self._get_common_context()

        content = self.renderer.render_file(
            "docker/authentik/traefik.yml.jinja2",
            context=context,
        )

        return GeneratedFile(
            path=Path("traefik.yml"),
            content=content,
            strategy=FileStrategy.GENERATE_ONCE,  # Allow customization
            description="Traefik static configuration",
        )

    def _generate_env_template(self) -> GeneratedFile:
        """Generate environment variables template.

        Returns:
            GeneratedFile for .env.authentik.example
        """
        context = self._get_common_context()

        content = self.renderer.render_file(
            "docker/authentik/.env.authentik.example.jinja2",
            context=context,
        )

        return GeneratedFile(
            path=Path(".env.authentik.example"),
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,  # Template should always be up-to-date
            description="Authentik environment template",
        )
