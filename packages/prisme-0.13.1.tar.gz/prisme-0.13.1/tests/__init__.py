"""Prism test suite."""
