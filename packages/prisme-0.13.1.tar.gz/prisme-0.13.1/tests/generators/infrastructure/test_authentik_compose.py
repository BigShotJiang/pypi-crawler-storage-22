"""Tests for Authentik Docker Compose infrastructure generator."""

from pathlib import Path

import pytest

from prism.generators.base import GeneratorContext
from prism.generators.infrastructure.authentik_compose import AuthentikComposeGenerator
from prism.spec import AuthConfig, FieldSpec, FieldType, ModelSpec, StackSpec
from prism.spec.auth import AuthentikConfig
from prism.spec.infrastructure import TraefikConfig
from prism.spec.stack import FileStrategy


@pytest.fixture
def authentik_with_traefik_spec() -> StackSpec:
    """Stack spec with Authentik and Traefik enabled."""
    return StackSpec(
        name="enterprise-app",
        auth=AuthConfig(
            enabled=True,
            preset="authentik",
            user_model="User",
            authentik=AuthentikConfig(
                version="2024.2",
                subdomain="auth",
            ),
        ),
        traefik=TraefikConfig(
            enabled=True,
            ssl_provider="letsencrypt",
            ssl_email="admin@example.com",
            domain="example.com",
            dashboard_enabled=True,
        ),
        models=[
            ModelSpec(
                name="User",
                fields=[
                    FieldSpec(name="email", type=FieldType.STRING, required=True, unique=True),
                    FieldSpec(name="authentik_id", type=FieldType.STRING, unique=True),
                    FieldSpec(name="is_active", type=FieldType.BOOLEAN, default=True),
                    FieldSpec(name="roles", type=FieldType.JSON, default=["user"]),
                ],
            )
        ],
    )


@pytest.fixture
def authentik_without_traefik_spec() -> StackSpec:
    """Stack spec with Authentik enabled but Traefik disabled."""
    return StackSpec(
        name="simple-auth-app",
        auth=AuthConfig(
            enabled=True,
            preset="authentik",
            user_model="User",
            authentik=AuthentikConfig(
                version="2024.4",
                subdomain="sso",
            ),
        ),
        traefik=TraefikConfig(enabled=False),
        models=[
            ModelSpec(
                name="User",
                fields=[
                    FieldSpec(name="email", type=FieldType.STRING, required=True, unique=True),
                    FieldSpec(name="authentik_id", type=FieldType.STRING, unique=True),
                    FieldSpec(name="is_active", type=FieldType.BOOLEAN, default=True),
                    FieldSpec(name="roles", type=FieldType.JSON, default=["user"]),
                ],
            )
        ],
    )


@pytest.fixture
def jwt_auth_spec() -> StackSpec:
    """Stack spec with JWT authentication (not Authentik)."""
    return StackSpec(
        name="jwt-app",
        auth=AuthConfig(
            enabled=True,
            preset="jwt",
            secret_key="${JWT_SECRET}",
            user_model="User",
        ),
        models=[
            ModelSpec(
                name="User",
                fields=[
                    FieldSpec(name="email", type=FieldType.STRING, required=True, unique=True),
                    FieldSpec(name="password_hash", type=FieldType.STRING, hidden=True),
                    FieldSpec(name="is_active", type=FieldType.BOOLEAN, default=True),
                    FieldSpec(name="roles", type=FieldType.JSON, default=["user"]),
                ],
            )
        ],
    )


@pytest.fixture
def auth_disabled_spec() -> StackSpec:
    """Stack spec with authentication disabled."""
    return StackSpec(
        name="simple-app",
        models=[
            ModelSpec(
                name="Post",
                fields=[
                    FieldSpec(name="title", type=FieldType.STRING, required=True),
                ],
            )
        ],
    )


@pytest.fixture
def generator_context_authentik_traefik(
    authentik_with_traefik_spec: StackSpec, tmp_path: Path
) -> GeneratorContext:
    """Generator context with Authentik and Traefik."""
    return GeneratorContext(
        spec=authentik_with_traefik_spec,
        output_dir=tmp_path,
        dry_run=True,
    )


@pytest.fixture
def generator_context_authentik_only(
    authentik_without_traefik_spec: StackSpec, tmp_path: Path
) -> GeneratorContext:
    """Generator context with Authentik but no Traefik."""
    return GeneratorContext(
        spec=authentik_without_traefik_spec,
        output_dir=tmp_path,
        dry_run=True,
    )


@pytest.fixture
def generator_context_jwt(jwt_auth_spec: StackSpec, tmp_path: Path) -> GeneratorContext:
    """Generator context with JWT auth."""
    return GeneratorContext(
        spec=jwt_auth_spec,
        output_dir=tmp_path,
        dry_run=True,
    )


@pytest.fixture
def generator_context_disabled(auth_disabled_spec: StackSpec, tmp_path: Path) -> GeneratorContext:
    """Generator context with auth disabled."""
    return GeneratorContext(
        spec=auth_disabled_spec,
        output_dir=tmp_path,
        dry_run=True,
    )


class TestAuthentikComposeGenerator:
    """Tests for AuthentikComposeGenerator."""

    def test_generator_skips_when_auth_disabled(self, generator_context_disabled: GeneratorContext):
        """Generator returns empty list when auth is disabled."""
        generator = AuthentikComposeGenerator(generator_context_disabled)
        files = generator.generate_files()
        assert files == []
        assert generator.skip_generation is True

    def test_generator_skips_when_preset_not_authentik(
        self, generator_context_jwt: GeneratorContext
    ):
        """Generator returns empty list when preset is not authentik."""
        generator = AuthentikComposeGenerator(generator_context_jwt)
        files = generator.generate_files()
        assert files == []
        assert generator.skip_generation is True

    def test_generator_creates_files_with_traefik(
        self, generator_context_authentik_traefik: GeneratorContext
    ):
        """Generator creates all files when Traefik is enabled."""
        generator = AuthentikComposeGenerator(generator_context_authentik_traefik)
        files = generator.generate_files()

        # Should generate 3 files: docker-compose, traefik.yml, .env.example
        assert len(files) == 3
        assert not hasattr(generator, "skip_generation") or not generator.skip_generation

    def test_generator_creates_files_without_traefik(
        self, generator_context_authentik_only: GeneratorContext
    ):
        """Generator creates fewer files when Traefik is disabled."""
        generator = AuthentikComposeGenerator(generator_context_authentik_only)
        files = generator.generate_files()

        # Should generate 2 files: docker-compose, .env.example (no traefik.yml)
        assert len(files) == 2

        file_paths = [str(f.path) for f in files]
        assert not any("traefik.yml" in p for p in file_paths)

    def test_generator_creates_docker_compose(
        self, generator_context_authentik_traefik: GeneratorContext
    ):
        """Generator creates Docker Compose file."""
        generator = AuthentikComposeGenerator(generator_context_authentik_traefik)
        files = generator.generate_files()

        file_paths = [str(f.path) for f in files]
        assert any("docker-compose.authentik.yml" in p for p in file_paths)

        compose_file = next(f for f in files if "docker-compose.authentik.yml" in str(f.path))
        content = compose_file.content

        # Check services
        assert "authentik-server:" in content
        assert "authentik-worker:" in content
        assert "authentik-db:" in content
        assert "authentik-redis:" in content
        assert "traefik:" in content

        # Check images
        assert "ghcr.io/goauthentik/server" in content
        assert "postgres:16-alpine" in content
        assert "redis:7-alpine" in content
        assert "traefik:v3.0" in content

    def test_docker_compose_has_traefik_labels(
        self, generator_context_authentik_traefik: GeneratorContext
    ):
        """Docker Compose includes Traefik routing labels."""
        generator = AuthentikComposeGenerator(generator_context_authentik_traefik)
        files = generator.generate_files()

        compose_file = next(f for f in files if "docker-compose.authentik.yml" in str(f.path))
        content = compose_file.content

        # Check Traefik labels
        assert "traefik.enable=true" in content
        assert "traefik.http.routers" in content
        assert "certresolver=letsencrypt" in content

    def test_docker_compose_without_traefik(
        self, generator_context_authentik_only: GeneratorContext
    ):
        """Docker Compose works without Traefik."""
        generator = AuthentikComposeGenerator(generator_context_authentik_only)
        files = generator.generate_files()

        compose_file = next(f for f in files if "docker-compose.authentik.yml" in str(f.path))
        content = compose_file.content

        # Should NOT have traefik service definition (as a YAML service block)
        # The "traefik:" in comments is OK, we're checking it's not a service
        assert "  traefik:\n    image:" not in content

        # Should expose ports directly for authentik-server
        assert "9000:9000" in content

    def test_generator_creates_traefik_config(
        self, generator_context_authentik_traefik: GeneratorContext
    ):
        """Generator creates Traefik config when enabled."""
        generator = AuthentikComposeGenerator(generator_context_authentik_traefik)
        files = generator.generate_files()

        file_paths = [str(f.path) for f in files]
        assert any("traefik.yml" in p for p in file_paths)

        traefik_file = next(f for f in files if "traefik.yml" in str(f.path))
        content = traefik_file.content

        # Check Traefik config
        assert "entryPoints:" in content
        assert "web:" in content
        assert "websecure:" in content
        assert "certificatesResolvers:" in content or "certresolver" in content.lower()

    def test_generator_creates_env_template(
        self, generator_context_authentik_traefik: GeneratorContext
    ):
        """Generator creates environment template file."""
        generator = AuthentikComposeGenerator(generator_context_authentik_traefik)
        files = generator.generate_files()

        file_paths = [str(f.path) for f in files]
        assert any(".env.authentik.example" in p for p in file_paths)

        env_file = next(f for f in files if ".env.authentik.example" in str(f.path))
        content = env_file.content

        # Check environment variables
        assert "DOMAIN=" in content
        assert "SSL_EMAIL=" in content
        assert "AUTHENTIK_SECRET_KEY=" in content
        assert "AUTHENTIK_DB_PASSWORD=" in content
        assert "AUTHENTIK_CLIENT_ID=" in content
        assert "AUTHENTIK_CLIENT_SECRET=" in content
        assert "AUTHENTIK_WEBHOOK_SECRET=" in content

    def test_env_template_has_setup_instructions(
        self, generator_context_authentik_traefik: GeneratorContext
    ):
        """Environment template includes setup instructions."""
        generator = AuthentikComposeGenerator(generator_context_authentik_traefik)
        files = generator.generate_files()

        env_file = next(f for f in files if ".env.authentik.example" in str(f.path))
        content = env_file.content

        # Check for setup notes
        assert "INITIAL SETUP" in content or "setup" in content.lower()
        assert "OAuth2" in content or "OIDC" in content
        assert "Provider" in content

    def test_generator_uses_project_name(
        self, generator_context_authentik_traefik: GeneratorContext
    ):
        """Generator uses project name in generated files."""
        generator = AuthentikComposeGenerator(generator_context_authentik_traefik)
        files = generator.generate_files()

        compose_file = next(f for f in files if "docker-compose.authentik.yml" in str(f.path))
        content = compose_file.content

        # Check project name is used
        assert "enterprise_app" in content or "enterprise-app" in content

    def test_generator_uses_authentik_version(
        self, generator_context_authentik_only: GeneratorContext
    ):
        """Generator uses configured Authentik version."""
        generator = AuthentikComposeGenerator(generator_context_authentik_only)
        files = generator.generate_files()

        compose_file = next(f for f in files if "docker-compose.authentik.yml" in str(f.path))
        content = compose_file.content

        # Check version is used (spec has 2024.4)
        assert "2024.4" in content

    def test_generator_file_strategies(self, generator_context_authentik_traefik: GeneratorContext):
        """Generator uses appropriate file strategies."""
        generator = AuthentikComposeGenerator(generator_context_authentik_traefik)
        files = generator.generate_files()

        # Docker Compose and Traefik should be GENERATE_ONCE (allow customization)
        compose_file = next(f for f in files if "docker-compose.authentik.yml" in str(f.path))
        assert compose_file.strategy == FileStrategy.GENERATE_ONCE

        traefik_file = next(f for f in files if "traefik.yml" in str(f.path))
        assert traefik_file.strategy == FileStrategy.GENERATE_ONCE

        # Env template should be ALWAYS_OVERWRITE (keep in sync)
        env_file = next(f for f in files if ".env.authentik.example" in str(f.path))
        assert env_file.strategy == FileStrategy.ALWAYS_OVERWRITE
