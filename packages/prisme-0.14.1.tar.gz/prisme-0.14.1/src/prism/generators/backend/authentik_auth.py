"""Authentik authentication generator for Prism.

This generator creates OIDC-based authentication infrastructure with Authentik:
- OIDC configuration settings
- OIDC client for token handling
- Webhook handlers for user sync
- FastAPI authentication dependencies
- Authentication routes (login, callback, logout)
"""

from __future__ import annotations

from pathlib import Path

from prism.generators.base import GeneratedFile, GeneratorBase
from prism.spec.stack import FileStrategy
from prism.utils.case_conversion import to_snake_case
from prism.utils.template_engine import TemplateRenderer


class AuthentikAuthGenerator(GeneratorBase):
    """Generates Authentik OIDC authentication system for backend."""

    REQUIRED_TEMPLATES = [
        "backend/auth/authentik/config.py.jinja2",
        "backend/auth/authentik/oidc.py.jinja2",
        "backend/auth/authentik/webhooks.py.jinja2",
        "backend/auth/authentik/dependencies.py.jinja2",
        "backend/auth/authentik/routes_auth.py.jinja2",
        "backend/auth/authentik/auth_init.py.jinja2",
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Skip generation if auth is not enabled or preset is not authentik
        if not self.spec.auth.enabled or self.spec.auth.preset != "authentik":
            self.skip_generation = True
            return

        # Initialize template renderer
        self.renderer = TemplateRenderer()
        self.renderer.validate_templates_exist(self.REQUIRED_TEMPLATES)

        # Setup paths for generated auth files
        backend_base = Path(self.spec.generator.backend_output)
        package_name = self.get_package_name()
        package_base = backend_base / package_name

        self.auth_base = package_base / "auth"
        self.middleware_path = package_base / "middleware"
        self.schemas_path = package_base / "schemas"
        self.routes_base = package_base / "api" / "rest"
        self.webhooks_path = package_base / "api" / "webhooks"

    def generate_files(self) -> list[GeneratedFile]:
        """Generate all Authentik authentication-related files.

        Returns:
            List of generated files with content and strategies
        """
        if getattr(self, "skip_generation", False):
            return []

        files = []

        # Core OIDC components
        files.append(self._generate_config())
        files.append(self._generate_oidc_client())
        files.append(self._generate_webhooks())
        files.append(self._generate_dependencies())

        # Routes
        files.append(self._generate_auth_routes())

        # Init file
        files.append(self._generate_auth_init())

        return files

    def _get_common_context(self) -> dict:
        """Get common template context variables.

        Returns:
            Dictionary with common context variables
        """
        return {
            "project_name": self.get_package_name(),
            "user_model": self.spec.auth.user_model,
            "user_model_snake": to_snake_case(self.spec.auth.user_model),
            "default_role": self.spec.auth.default_role,
            "authentik_config": self.spec.auth.authentik,
        }

    def _generate_config(self) -> GeneratedFile:
        """Generate Authentik configuration settings.

        Returns:
            GeneratedFile for auth/config.py
        """
        context = self._get_common_context()

        content = self.renderer.render_file(
            "backend/auth/authentik/config.py.jinja2",
            context=context,
        )

        return GeneratedFile(
            path=self.auth_base / "config.py",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="Authentik OIDC configuration",
        )

    def _generate_oidc_client(self) -> GeneratedFile:
        """Generate OIDC client for Authentik.

        Returns:
            GeneratedFile for auth/oidc.py
        """
        context = self._get_common_context()

        content = self.renderer.render_file(
            "backend/auth/authentik/oidc.py.jinja2",
            context=context,
        )

        return GeneratedFile(
            path=self.auth_base / "oidc.py",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="OIDC client for Authentik",
        )

    def _generate_webhooks(self) -> GeneratedFile:
        """Generate webhook handlers for user sync.

        Returns:
            GeneratedFile for auth/webhooks.py
        """
        context = self._get_common_context()

        content = self.renderer.render_file(
            "backend/auth/authentik/webhooks.py.jinja2",
            context=context,
        )

        return GeneratedFile(
            path=self.auth_base / "webhooks.py",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="Authentik webhook handlers",
        )

    def _generate_dependencies(self) -> GeneratedFile:
        """Generate FastAPI authentication dependencies.

        Returns:
            GeneratedFile for auth/dependencies.py
        """
        context = self._get_common_context()

        content = self.renderer.render_file(
            "backend/auth/authentik/dependencies.py.jinja2",
            context=context,
        )

        return GeneratedFile(
            path=self.auth_base / "dependencies.py",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="Authentik auth dependencies",
        )

    def _generate_auth_routes(self) -> GeneratedFile:
        """Generate FastAPI authentication routes.

        Returns:
            GeneratedFile for api/rest/auth.py
        """
        context = self._get_common_context()

        content = self.renderer.render_file(
            "backend/auth/authentik/routes_auth.py.jinja2",
            context=context,
        )

        return GeneratedFile(
            path=self.routes_base / "auth.py",
            content=content,
            strategy=FileStrategy.GENERATE_ONCE,  # Allow customization
            description="Authentik auth routes",
        )

    def _generate_auth_init(self) -> GeneratedFile:
        """Generate __init__.py for auth module.

        Returns:
            GeneratedFile for auth/__init__.py
        """
        context = self._get_common_context()

        content = self.renderer.render_file(
            "backend/auth/authentik/auth_init.py.jinja2",
            context=context,
        )

        return GeneratedFile(
            path=self.auth_base / "__init__.py",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="Auth module init",
        )
