"""Frontend Authentik authentication generator for Prism.

This generator creates React authentication components for OIDC with Authentik:
- AuthContext with useAuth() hook
- AuthCallback for handling OIDC redirects
- ProtectedRoute wrapper for secure routes
- Index file for exports
"""

from __future__ import annotations

from pathlib import Path

from prism.generators.base import GeneratedFile, GeneratorBase
from prism.spec.stack import FileStrategy
from prism.utils.template_engine import TemplateRenderer


class AuthentikFrontendAuthGenerator(GeneratorBase):
    """Generates React authentication components for Authentik OIDC."""

    REQUIRED_TEMPLATES = [
        "frontend/auth/authentik/AuthContext.tsx.jinja2",
        "frontend/auth/authentik/AuthCallback.tsx.jinja2",
        "frontend/auth/authentik/ProtectedRoute.tsx.jinja2",
        "frontend/auth/authentik/index.ts.jinja2",
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Skip generation if auth is not enabled or preset is not authentik
        if not self.spec.auth.enabled or self.spec.auth.preset != "authentik":
            self.skip_generation = True
            return

        # Initialize template renderer
        self.renderer = TemplateRenderer()
        self.renderer.validate_templates_exist(self.REQUIRED_TEMPLATES)

        # Setup paths for generated auth files
        frontend_base = Path(self.spec.generator.frontend_output)
        self.contexts_path = frontend_base / "contexts"
        self.components_path = frontend_base / "components" / "auth"
        self.pages_path = frontend_base / "pages"

    def generate_files(self) -> list[GeneratedFile]:
        """Generate all frontend Authentik authentication files.

        Returns:
            List of generated files with content and strategies
        """
        if getattr(self, "skip_generation", False):
            return []

        files = []

        # Auth context with useAuth hook
        files.append(self._generate_auth_context())

        # Auth components
        files.append(self._generate_auth_callback())
        files.append(self._generate_protected_route())

        # Index file
        files.append(self._generate_components_index())

        return files

    def _get_common_context(self) -> dict:
        """Get common template context variables.

        Returns:
            Dictionary with common context variables
        """
        return {
            "user_model": self.spec.auth.user_model,
            "username_field": self.spec.auth.username_field,
            "authentik_config": self.spec.auth.authentik,
        }

    def _generate_auth_context(self) -> GeneratedFile:
        """Generate AuthContext with useAuth() hook.

        Returns:
            GeneratedFile for AuthContext.tsx
        """
        context = self._get_common_context()

        content = self.renderer.render_file(
            "frontend/auth/authentik/AuthContext.tsx.jinja2",
            context=context,
        )

        return GeneratedFile(
            path=self.contexts_path / "AuthContext.tsx",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="Authentik auth context with useAuth hook",
        )

    def _generate_auth_callback(self) -> GeneratedFile:
        """Generate AuthCallback component for OIDC redirect handling.

        Returns:
            GeneratedFile for AuthCallback.tsx
        """
        context = self._get_common_context()

        content = self.renderer.render_file(
            "frontend/auth/authentik/AuthCallback.tsx.jinja2",
            context=context,
        )

        return GeneratedFile(
            path=self.components_path / "AuthCallback.tsx",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="OIDC callback handler",
        )

    def _generate_protected_route(self) -> GeneratedFile:
        """Generate ProtectedRoute wrapper component.

        Returns:
            GeneratedFile for ProtectedRoute.tsx
        """
        context = self._get_common_context()

        content = self.renderer.render_file(
            "frontend/auth/authentik/ProtectedRoute.tsx.jinja2",
            context=context,
        )

        return GeneratedFile(
            path=self.components_path / "ProtectedRoute.tsx",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="Protected route wrapper",
        )

    def _generate_components_index(self) -> GeneratedFile:
        """Generate index file for auth components.

        Returns:
            GeneratedFile for components/auth/index.ts
        """
        context = self._get_common_context()

        content = self.renderer.render_file(
            "frontend/auth/authentik/index.ts.jinja2",
            context=context,
        )

        return GeneratedFile(
            path=self.components_path / "index.ts",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="Authentik auth components index",
        )
