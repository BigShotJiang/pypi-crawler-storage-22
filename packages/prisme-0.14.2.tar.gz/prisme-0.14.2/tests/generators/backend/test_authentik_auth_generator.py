"""Tests for Authentik authentication code generator."""

from pathlib import Path

import pytest

from prism.generators.backend.authentik_auth import AuthentikAuthGenerator
from prism.generators.base import GeneratorContext
from prism.spec import AuthConfig, FieldSpec, FieldType, ModelSpec, StackSpec
from prism.spec.auth import AuthentikConfig
from prism.spec.stack import FileStrategy


@pytest.fixture
def authentik_enabled_spec() -> StackSpec:
    """Stack spec with Authentik authentication enabled."""
    return StackSpec(
        name="enterprise-app",
        auth=AuthConfig(
            enabled=True,
            preset="authentik",
            user_model="User",
            username_field="email",
            authentik=AuthentikConfig(
                version="2024.2",
                subdomain="auth",
                client_id="${AUTHENTIK_CLIENT_ID}",
                issuer_url="${AUTHENTIK_ISSUER_URL}",
            ),
        ),
        models=[
            ModelSpec(
                name="User",
                fields=[
                    FieldSpec(name="email", type=FieldType.STRING, required=True, unique=True),
                    FieldSpec(name="authentik_id", type=FieldType.STRING, unique=True),
                    FieldSpec(name="username", type=FieldType.STRING),
                    FieldSpec(name="is_active", type=FieldType.BOOLEAN, default=True),
                    FieldSpec(name="roles", type=FieldType.JSON, default=["user"]),
                ],
            )
        ],
    )


@pytest.fixture
def jwt_auth_spec() -> StackSpec:
    """Stack spec with JWT authentication (not Authentik)."""
    return StackSpec(
        name="jwt-app",
        auth=AuthConfig(
            enabled=True,
            preset="jwt",
            secret_key="${JWT_SECRET}",
            user_model="User",
        ),
        models=[
            ModelSpec(
                name="User",
                fields=[
                    FieldSpec(name="email", type=FieldType.STRING, required=True, unique=True),
                    FieldSpec(name="password_hash", type=FieldType.STRING, hidden=True),
                    FieldSpec(name="is_active", type=FieldType.BOOLEAN, default=True),
                    FieldSpec(name="roles", type=FieldType.JSON, default=["user"]),
                ],
            )
        ],
    )


@pytest.fixture
def auth_disabled_spec() -> StackSpec:
    """Stack spec with authentication disabled."""
    return StackSpec(
        name="simple-app",
        models=[
            ModelSpec(
                name="Post",
                fields=[
                    FieldSpec(name="title", type=FieldType.STRING, required=True),
                ],
            )
        ],
    )


@pytest.fixture
def generator_context_authentik(
    authentik_enabled_spec: StackSpec, tmp_path: Path
) -> GeneratorContext:
    """Generator context with Authentik auth enabled."""
    return GeneratorContext(
        spec=authentik_enabled_spec,
        output_dir=tmp_path,
        dry_run=True,
    )


@pytest.fixture
def generator_context_jwt(jwt_auth_spec: StackSpec, tmp_path: Path) -> GeneratorContext:
    """Generator context with JWT auth (not Authentik)."""
    return GeneratorContext(
        spec=jwt_auth_spec,
        output_dir=tmp_path,
        dry_run=True,
    )


@pytest.fixture
def generator_context_disabled(auth_disabled_spec: StackSpec, tmp_path: Path) -> GeneratorContext:
    """Generator context with auth disabled."""
    return GeneratorContext(
        spec=auth_disabled_spec,
        output_dir=tmp_path,
        dry_run=True,
    )


class TestAuthentikAuthGenerator:
    """Tests for AuthentikAuthGenerator."""

    def test_generator_skips_when_auth_disabled(self, generator_context_disabled: GeneratorContext):
        """Generator returns empty list when auth is disabled."""
        generator = AuthentikAuthGenerator(generator_context_disabled)
        files = generator.generate_files()
        assert files == []
        assert generator.skip_generation is True

    def test_generator_skips_when_preset_not_authentik(
        self, generator_context_jwt: GeneratorContext
    ):
        """Generator returns empty list when preset is not authentik."""
        generator = AuthentikAuthGenerator(generator_context_jwt)
        files = generator.generate_files()
        assert files == []
        assert generator.skip_generation is True

    def test_generator_creates_files_when_authentik_enabled(
        self, generator_context_authentik: GeneratorContext
    ):
        """Generator creates auth files when Authentik is enabled."""
        generator = AuthentikAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        # Should generate 6 files: config, oidc, webhooks, dependencies, routes, init
        assert len(files) == 6
        assert not hasattr(generator, "skip_generation") or not generator.skip_generation

    def test_generator_creates_config_file(self, generator_context_authentik: GeneratorContext):
        """Generator creates Authentik config file."""
        generator = AuthentikAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        file_paths = [str(f.path) for f in files]
        assert any("config.py" in p for p in file_paths)

        config_file = next(f for f in files if "config.py" in str(f.path))
        assert "AuthentikSettings" in config_file.content
        assert "client_id" in config_file.content
        assert "issuer_url" in config_file.content
        assert 'env_prefix="AUTHENTIK_"' in config_file.content
        assert "os.getenv" not in config_file.content

    def test_generator_creates_oidc_client(self, generator_context_authentik: GeneratorContext):
        """Generator creates OIDC client file."""
        generator = AuthentikAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        file_paths = [str(f.path) for f in files]
        assert any("oidc.py" in p for p in file_paths)

        oidc_file = next(f for f in files if "oidc.py" in str(f.path))
        assert "OIDCClient" in oidc_file.content
        assert "get_authorization_url" in oidc_file.content
        assert "exchange_code" in oidc_file.content
        assert "validate_id_token" in oidc_file.content
        assert "authlib" in oidc_file.content

    def test_generator_creates_webhooks_handler(
        self, generator_context_authentik: GeneratorContext
    ):
        """Generator creates webhook handlers file."""
        generator = AuthentikAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        file_paths = [str(f.path) for f in files]
        assert any("webhooks.py" in p for p in file_paths)

        webhooks_file = next(f for f in files if "webhooks.py" in str(f.path))
        assert "verify_webhook_signature" in webhooks_file.content
        assert "handle_user_created" in webhooks_file.content
        assert "handle_user_updated" in webhooks_file.content
        assert "handle_user_deleted" in webhooks_file.content
        assert "HMAC" in webhooks_file.content or "hmac" in webhooks_file.content

    def test_generator_creates_dependencies(self, generator_context_authentik: GeneratorContext):
        """Generator creates FastAPI dependencies file."""
        generator = AuthentikAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        file_paths = [str(f.path) for f in files]
        assert any("dependencies.py" in p for p in file_paths)

        deps_file = next(f for f in files if "dependencies.py" in str(f.path))
        assert "get_current_user" in deps_file.content
        assert "get_current_active_user" in deps_file.content
        assert "require_roles" in deps_file.content
        assert "CurrentUser" in deps_file.content
        assert "CurrentActiveUser" in deps_file.content

    def test_generator_creates_auth_routes(self, generator_context_authentik: GeneratorContext):
        """Generator creates auth routes file."""
        generator = AuthentikAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        route_files = [f for f in files if "rest" in str(f.path) and "auth.py" in str(f.path)]
        assert len(route_files) == 1

        route_file = route_files[0]
        content = route_file.content

        # Check router prefix
        assert 'prefix="/auth"' in content

        # Check all route decorators exist
        assert '"/login"' in content
        assert '"/callback"' in content
        assert '"/logout"' in content
        assert '"/me"' in content

        # Check route functions
        assert "async def login" in content
        assert "async def callback" in content
        assert "async def logout" in content

    def test_generator_uses_project_name_in_imports(
        self, generator_context_authentik: GeneratorContext
    ):
        """Generator uses correct project name in imports."""
        generator = AuthentikAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        project_name = "enterprise_app"  # snake_case of "enterprise-app"

        for file in files:
            if "oidc.py" in str(file.path):
                assert f"from {project_name}.auth.config" in file.content
            elif "dependencies.py" in str(file.path):
                assert f"from {project_name}.auth.config" in file.content
                assert f"from {project_name}.auth.oidc" in file.content

    def test_generator_file_strategies(self, generator_context_authentik: GeneratorContext):
        """Generator uses appropriate file strategies."""
        generator = AuthentikAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        # Config and OIDC should be ALWAYS_OVERWRITE (pure generated)
        config_file = next(f for f in files if "config.py" in str(f.path))
        assert config_file.strategy == FileStrategy.ALWAYS_OVERWRITE

        oidc_file = next(f for f in files if "oidc.py" in str(f.path))
        assert oidc_file.strategy == FileStrategy.ALWAYS_OVERWRITE

        # Routes should be GENERATE_ONCE (allow customization)
        auth_routes = next(f for f in files if "rest" in str(f.path) and "auth.py" in str(f.path))
        assert auth_routes.strategy == FileStrategy.GENERATE_ONCE

    def test_generator_uses_user_model_name(self, generator_context_authentik: GeneratorContext):
        """Generator uses configured user model name."""
        generator = AuthentikAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        # Check dependencies file references User model
        deps_file = next(f for f in files if "dependencies.py" in str(f.path))
        assert "User" in deps_file.content

        # Check webhooks file references User model
        webhooks_file = next(f for f in files if "webhooks.py" in str(f.path))
        assert "User" in webhooks_file.content
