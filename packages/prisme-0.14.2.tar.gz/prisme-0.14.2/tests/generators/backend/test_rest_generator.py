"""Tests for REST API generator."""

from pathlib import Path

import pytest

from prism.generators.backend.rest import RESTGenerator
from prism.generators.base import GeneratorContext
from prism.spec import AuthConfig, FieldSpec, FieldType, ModelSpec, StackSpec
from prism.spec.auth import AuthentikConfig


@pytest.fixture
def basic_spec() -> StackSpec:
    """Stack spec without auth."""
    return StackSpec(
        name="test-app",
        models=[
            ModelSpec(
                name="Post",
                fields=[
                    FieldSpec(name="title", type=FieldType.STRING, required=True),
                ],
            )
        ],
    )


@pytest.fixture
def authentik_spec() -> StackSpec:
    """Stack spec with Authentik auth enabled."""
    return StackSpec(
        name="test-app",
        auth=AuthConfig(
            enabled=True,
            preset="authentik",
            user_model="User",
            username_field="email",
            authentik=AuthentikConfig(
                version="2024.2",
                subdomain="auth",
                client_id="${AUTHENTIK_CLIENT_ID}",
                issuer_url="${AUTHENTIK_ISSUER_URL}",
            ),
        ),
        models=[
            ModelSpec(
                name="User",
                fields=[
                    FieldSpec(name="email", type=FieldType.STRING, required=True, unique=True),
                    FieldSpec(name="authentik_id", type=FieldType.STRING, unique=True),
                ],
            ),
            ModelSpec(
                name="Post",
                fields=[
                    FieldSpec(name="title", type=FieldType.STRING, required=True),
                ],
            ),
        ],
    )


class TestRESTGeneratorAuthRouter:
    """Tests for auth router inclusion in main router."""

    def test_main_router_excludes_auth_when_disabled(self, basic_spec: StackSpec, tmp_path: Path):
        """Main router should not include auth router when auth is disabled."""
        ctx = GeneratorContext(spec=basic_spec, output_dir=tmp_path, dry_run=True)
        generator = RESTGenerator(ctx)
        files = generator.generate_index_files()

        router_file = next(f for f in files if f.path.name == "router.py")
        assert "auth_router" not in router_file.content

    def test_main_router_includes_auth_when_authentik_enabled(
        self, authentik_spec: StackSpec, tmp_path: Path
    ):
        """Main router should include auth router when Authentik auth is enabled."""
        ctx = GeneratorContext(spec=authentik_spec, output_dir=tmp_path, dry_run=True)
        generator = RESTGenerator(ctx)
        files = generator.generate_index_files()

        router_file = next(f for f in files if f.path.name == "router.py")
        assert "from .auth import router as auth_router" in router_file.content
        assert "router.include_router(auth_router)" in router_file.content
