"""Tests for Authentik frontend authentication code generator."""

from pathlib import Path

import pytest

from prism.generators.base import GeneratorContext
from prism.generators.frontend.authentik_auth import AuthentikFrontendAuthGenerator
from prism.spec import AuthConfig, FieldSpec, FieldType, ModelSpec, StackSpec
from prism.spec.auth import AuthentikConfig
from prism.spec.stack import FileStrategy


@pytest.fixture
def authentik_enabled_spec() -> StackSpec:
    """Stack spec with Authentik authentication enabled."""
    return StackSpec(
        name="enterprise-app",
        auth=AuthConfig(
            enabled=True,
            preset="authentik",
            user_model="User",
            username_field="email",
            authentik=AuthentikConfig(
                version="2024.2",
                subdomain="auth",
            ),
        ),
        models=[
            ModelSpec(
                name="User",
                fields=[
                    FieldSpec(name="email", type=FieldType.STRING, required=True, unique=True),
                    FieldSpec(name="authentik_id", type=FieldType.STRING, unique=True),
                    FieldSpec(name="is_active", type=FieldType.BOOLEAN, default=True),
                    FieldSpec(name="roles", type=FieldType.JSON, default=["user"]),
                ],
            )
        ],
    )


@pytest.fixture
def jwt_auth_spec() -> StackSpec:
    """Stack spec with JWT authentication (not Authentik)."""
    return StackSpec(
        name="jwt-app",
        auth=AuthConfig(
            enabled=True,
            preset="jwt",
            secret_key="${JWT_SECRET}",
            user_model="User",
        ),
        models=[
            ModelSpec(
                name="User",
                fields=[
                    FieldSpec(name="email", type=FieldType.STRING, required=True, unique=True),
                    FieldSpec(name="password_hash", type=FieldType.STRING, hidden=True),
                    FieldSpec(name="is_active", type=FieldType.BOOLEAN, default=True),
                    FieldSpec(name="roles", type=FieldType.JSON, default=["user"]),
                ],
            )
        ],
    )


@pytest.fixture
def auth_disabled_spec() -> StackSpec:
    """Stack spec with authentication disabled."""
    return StackSpec(
        name="simple-app",
        models=[
            ModelSpec(
                name="Post",
                fields=[
                    FieldSpec(name="title", type=FieldType.STRING, required=True),
                ],
            )
        ],
    )


@pytest.fixture
def generator_context_authentik(
    authentik_enabled_spec: StackSpec, tmp_path: Path
) -> GeneratorContext:
    """Generator context with Authentik auth enabled."""
    return GeneratorContext(
        spec=authentik_enabled_spec,
        output_dir=tmp_path,
        dry_run=True,
    )


@pytest.fixture
def generator_context_jwt(jwt_auth_spec: StackSpec, tmp_path: Path) -> GeneratorContext:
    """Generator context with JWT auth."""
    return GeneratorContext(
        spec=jwt_auth_spec,
        output_dir=tmp_path,
        dry_run=True,
    )


@pytest.fixture
def generator_context_disabled(auth_disabled_spec: StackSpec, tmp_path: Path) -> GeneratorContext:
    """Generator context with auth disabled."""
    return GeneratorContext(
        spec=auth_disabled_spec,
        output_dir=tmp_path,
        dry_run=True,
    )


class TestAuthentikFrontendAuthGenerator:
    """Tests for AuthentikFrontendAuthGenerator."""

    def test_generator_skips_when_auth_disabled(self, generator_context_disabled: GeneratorContext):
        """Generator returns empty list when auth is disabled."""
        generator = AuthentikFrontendAuthGenerator(generator_context_disabled)
        files = generator.generate_files()
        assert files == []
        assert generator.skip_generation is True

    def test_generator_skips_when_preset_not_authentik(
        self, generator_context_jwt: GeneratorContext
    ):
        """Generator returns empty list when preset is not authentik."""
        generator = AuthentikFrontendAuthGenerator(generator_context_jwt)
        files = generator.generate_files()
        assert files == []
        assert generator.skip_generation is True

    def test_generator_creates_files_when_authentik_enabled(
        self, generator_context_authentik: GeneratorContext
    ):
        """Generator creates auth files when Authentik is enabled."""
        generator = AuthentikFrontendAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        # Should generate 4 files: AuthContext, AuthCallback, ProtectedRoute, index
        assert len(files) == 4
        assert not hasattr(generator, "skip_generation") or not generator.skip_generation

    def test_generator_creates_auth_context(self, generator_context_authentik: GeneratorContext):
        """Generator creates AuthContext file."""
        generator = AuthentikFrontendAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        file_paths = [str(f.path) for f in files]
        assert any("AuthContext.tsx" in p for p in file_paths)

        context_file = next(f for f in files if "AuthContext.tsx" in str(f.path))
        content = context_file.content

        # Check interface and hook
        assert "interface User" in content
        assert "interface AuthContextType" in content
        assert "function AuthProvider" in content or "AuthProvider" in content
        assert "function useAuth" in content or "useAuth" in content

        # Check auth methods
        assert "login" in content
        assert "logout" in content
        assert "isAuthenticated" in content
        assert "hasRole" in content

        # Check OIDC-specific behavior
        assert "/api/auth/login" in content or "auth/login" in content

    def test_generator_creates_auth_callback(self, generator_context_authentik: GeneratorContext):
        """Generator creates AuthCallback file."""
        generator = AuthentikFrontendAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        file_paths = [str(f.path) for f in files]
        assert any("AuthCallback.tsx" in p for p in file_paths)

        callback_file = next(f for f in files if "AuthCallback.tsx" in str(f.path))
        content = callback_file.content

        # Check callback component
        assert "AuthCallback" in content
        assert "useNavigate" in content or "navigate" in content
        assert "error" in content.lower()

    def test_generator_creates_protected_route(self, generator_context_authentik: GeneratorContext):
        """Generator creates ProtectedRoute file."""
        generator = AuthentikFrontendAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        file_paths = [str(f.path) for f in files]
        assert any("ProtectedRoute.tsx" in p for p in file_paths)

        protected_file = next(f for f in files if "ProtectedRoute.tsx" in str(f.path))
        content = protected_file.content

        # Check ProtectedRoute component
        assert "ProtectedRoute" in content
        assert "isAuthenticated" in content
        assert "roles" in content
        assert "Navigate" in content or "redirect" in content.lower()

    def test_generator_creates_index_file(self, generator_context_authentik: GeneratorContext):
        """Generator creates index file with exports."""
        generator = AuthentikFrontendAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        file_paths = [str(f.path) for f in files]
        assert any("index.ts" in p for p in file_paths)

        index_file = next(f for f in files if "index.ts" in str(f.path))
        content = index_file.content

        # Check exports
        assert "AuthProvider" in content
        assert "useAuth" in content
        assert "ProtectedRoute" in content
        assert "AuthCallback" in content

    def test_generator_file_strategies(self, generator_context_authentik: GeneratorContext):
        """Generator uses appropriate file strategies."""
        generator = AuthentikFrontendAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        # All frontend auth files should be ALWAYS_OVERWRITE for consistency
        for file in files:
            assert file.strategy == FileStrategy.ALWAYS_OVERWRITE

    def test_auth_context_has_user_interface(self, generator_context_authentik: GeneratorContext):
        """AuthContext includes User interface with Authentik fields."""
        generator = AuthentikFrontendAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        context_file = next(f for f in files if "AuthContext.tsx" in str(f.path))
        content = context_file.content

        # Check User interface has relevant fields
        assert "authentik_id" in content
        assert "roles" in content
        assert "email" in content

    def test_protected_route_supports_role_checking(
        self, generator_context_authentik: GeneratorContext
    ):
        """ProtectedRoute supports role-based access control."""
        generator = AuthentikFrontendAuthGenerator(generator_context_authentik)
        files = generator.generate_files()

        protected_file = next(f for f in files if "ProtectedRoute.tsx" in str(f.path))
        content = protected_file.content

        # Check role checking
        assert "roles" in content
        assert "hasRole" in content or "hasAnyRole" in content
        assert "Access Denied" in content or "unauthorized" in content.lower()
