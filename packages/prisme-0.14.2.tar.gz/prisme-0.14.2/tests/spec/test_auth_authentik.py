"""Tests for Authentik authentication specification models."""

import pytest

from prism.spec.auth import AuthConfig, AuthentikConfig, AuthentikMFAConfig
from prism.spec.infrastructure import TraefikConfig
from prism.spec.stack import StackSpec


class TestAuthentikMFAConfig:
    """Tests for AuthentikMFAConfig model."""

    def test_default_mfa_enabled(self):
        """MFA is enabled by default."""
        mfa = AuthentikMFAConfig()
        assert mfa.enabled is True

    def test_default_mfa_methods(self):
        """Default MFA methods are TOTP and email."""
        mfa = AuthentikMFAConfig()
        assert mfa.methods == ["totp", "email"]

    def test_custom_mfa_methods(self):
        """Can configure custom MFA methods."""
        mfa = AuthentikMFAConfig(
            enabled=True,
            methods=["totp", "webauthn"],
        )
        assert mfa.methods == ["totp", "webauthn"]

    def test_mfa_disabled(self):
        """Can disable MFA."""
        mfa = AuthentikMFAConfig(enabled=False)
        assert mfa.enabled is False


class TestAuthentikConfig:
    """Tests for AuthentikConfig model."""

    def test_default_values(self):
        """AuthentikConfig has sensible defaults."""
        config = AuthentikConfig()
        assert config.version == "2024.2"
        assert config.subdomain == "auth"
        assert config.self_signup is True
        assert config.email_verification is True
        assert config.mfa.enabled is True

    def test_custom_configuration(self):
        """Can create custom Authentik configuration."""
        config = AuthentikConfig(
            version="2024.4",
            subdomain="sso",
            self_signup=False,
            email_verification=False,
            client_id="my-client-id",
            issuer_url="https://auth.example.com/application/o/myapp/",
        )
        assert config.version == "2024.4"
        assert config.subdomain == "sso"
        assert config.self_signup is False
        assert config.client_id == "my-client-id"

    def test_environment_variable_placeholders(self):
        """Config fields use environment variable placeholders by default."""
        config = AuthentikConfig()
        assert config.client_id == "${AUTHENTIK_CLIENT_ID}"
        assert config.client_secret == "${AUTHENTIK_CLIENT_SECRET}"
        assert config.issuer_url == "${AUTHENTIK_ISSUER_URL}"
        assert config.webhook_secret == "${AUTHENTIK_WEBHOOK_SECRET}"


class TestAuthConfigAuthentikPreset:
    """Tests for AuthConfig with authentik preset."""

    def test_preset_authentik_valid(self):
        """Can create auth config with authentik preset."""
        auth = AuthConfig(
            enabled=True,
            preset="authentik",
            authentik=AuthentikConfig(
                client_id="${AUTHENTIK_CLIENT_ID}",
                issuer_url="${AUTHENTIK_ISSUER_URL}",
            ),
        )
        assert auth.preset == "authentik"
        assert auth.authentik.version == "2024.2"

    def test_preset_authentik_with_custom_mfa(self):
        """Can configure MFA with authentik preset."""
        auth = AuthConfig(
            enabled=True,
            preset="authentik",
            authentik=AuthentikConfig(
                mfa=AuthentikMFAConfig(
                    enabled=True,
                    methods=["totp", "email", "webauthn"],
                ),
            ),
        )
        assert auth.authentik.mfa.methods == ["totp", "email", "webauthn"]

    def test_preset_authentik_validation_client_id(self):
        """Validation fails if client_id is empty for authentik preset."""
        with pytest.raises(ValueError, match="client_id is required"):
            AuthConfig(
                enabled=True,
                preset="authentik",
                authentik=AuthentikConfig(
                    client_id="",
                    issuer_url="${AUTHENTIK_ISSUER_URL}",
                ),
            )

    def test_preset_authentik_validation_issuer_url(self):
        """Validation fails if issuer_url is empty for authentik preset."""
        with pytest.raises(ValueError, match="issuer_url is required"):
            AuthConfig(
                enabled=True,
                preset="authentik",
                authentik=AuthentikConfig(
                    client_id="${AUTHENTIK_CLIENT_ID}",
                    issuer_url="",
                ),
            )

    def test_preset_authentik_with_defaults_passes_validation(self):
        """Authentik preset with default env var placeholders passes validation."""
        # Should not raise - env var placeholders are valid
        auth = AuthConfig(
            enabled=True,
            preset="authentik",
        )
        assert auth.authentik.client_id == "${AUTHENTIK_CLIENT_ID}"
        assert auth.authentik.issuer_url == "${AUTHENTIK_ISSUER_URL}"


class TestTraefikConfig:
    """Tests for TraefikConfig model."""

    def test_default_values(self):
        """TraefikConfig is disabled by default."""
        config = TraefikConfig()
        assert config.enabled is False
        assert config.ssl_provider == "letsencrypt"
        assert config.dashboard_enabled is False

    def test_custom_configuration(self):
        """Can create custom Traefik configuration."""
        config = TraefikConfig(
            enabled=True,
            ssl_provider="manual",
            ssl_email="admin@example.com",
            domain="example.com",
            dashboard_enabled=True,
            dashboard_subdomain="traefik",
        )
        assert config.enabled is True
        assert config.ssl_provider == "manual"
        assert config.ssl_email == "admin@example.com"
        assert config.domain == "example.com"
        assert config.dashboard_enabled is True

    def test_ssl_provider_options(self):
        """Can use different SSL providers."""
        for provider in ["letsencrypt", "manual", "none"]:
            config = TraefikConfig(ssl_provider=provider)
            assert config.ssl_provider == provider


class TestStackSpecWithAuthentik:
    """Tests for StackSpec with Authentik configuration."""

    def test_stack_with_authentik_auth(self):
        """Can create stack spec with Authentik authentication."""
        from prism.spec import FieldSpec, FieldType, ModelSpec

        stack = StackSpec(
            name="enterprise-app",
            auth=AuthConfig(
                enabled=True,
                preset="authentik",
                user_model="User",
            ),
            traefik=TraefikConfig(
                enabled=True,
                domain="example.com",
            ),
            models=[
                ModelSpec(
                    name="User",
                    fields=[
                        FieldSpec(name="email", type=FieldType.STRING, required=True, unique=True),
                        FieldSpec(name="authentik_id", type=FieldType.STRING, unique=True),
                        FieldSpec(name="username", type=FieldType.STRING),
                        FieldSpec(name="is_active", type=FieldType.BOOLEAN, default=True),
                        FieldSpec(name="roles", type=FieldType.JSON, default=["user"]),
                    ],
                )
            ],
        )
        assert stack.auth.preset == "authentik"
        assert stack.traefik.enabled is True
        assert stack.auth.authentik.version == "2024.2"

    def test_stack_with_default_traefik(self):
        """Stack has default Traefik config (disabled)."""
        from prism.spec import FieldSpec, FieldType, ModelSpec

        stack = StackSpec(
            name="simple-app",
            models=[
                ModelSpec(
                    name="Post",
                    fields=[
                        FieldSpec(name="title", type=FieldType.STRING, required=True),
                    ],
                )
            ],
        )
        assert stack.traefik.enabled is False
