"""Tests for code generators."""
