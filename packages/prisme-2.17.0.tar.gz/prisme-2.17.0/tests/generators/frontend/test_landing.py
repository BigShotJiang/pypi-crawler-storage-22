"""Tests for the landing page generator."""

from __future__ import annotations

from pathlib import Path

import pytest

from prisme.generators.base import GeneratorContext
from prisme.generators.frontend.landing import LandingPageGenerator
from prisme.spec.auth import AuthConfig
from prisme.spec.fields import FieldSpec, FieldType
from prisme.spec.model import ModelSpec
from prisme.spec.project import ProjectSpec
from prisme.spec.stack import FileStrategy, StackSpec


@pytest.fixture
def basic_stack() -> StackSpec:
    return StackSpec(
        name="test-project",
        version="1.0.0",
        description="A test project",
        models=[
            ModelSpec(
                name="Item",
                fields=[FieldSpec(name="name", type=FieldType.STRING, required=True)],
            )
        ],
    )


class TestLandingPageGenerator:
    """Tests for LandingPageGenerator."""

    def test_generates_landing_when_auth_enabled(
        self, basic_stack: StackSpec, tmp_path: Path
    ) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(
                name="test-project",
                auth=AuthConfig(enabled=True),
            ),
        )
        gen = LandingPageGenerator(ctx)
        files = gen.generate_files()
        assert len(files) == 1
        assert "LandingPage.tsx" in str(files[0].path)

    def test_no_landing_when_auth_disabled(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(
                name="test-project",
                auth=AuthConfig(enabled=False),
            ),
        )
        gen = LandingPageGenerator(ctx)
        files = gen.generate_files()
        assert files == []

    def test_landing_uses_generate_once_strategy(
        self, basic_stack: StackSpec, tmp_path: Path
    ) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(
                name="test-project",
                auth=AuthConfig(enabled=True),
            ),
        )
        gen = LandingPageGenerator(ctx)
        files = gen.generate_files()
        assert files[0].strategy == FileStrategy.GENERATE_ONCE

    def test_landing_content_has_project_info(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(
                name="test-project",
                auth=AuthConfig(enabled=True),
            ),
        )
        gen = LandingPageGenerator(ctx)
        files = gen.generate_files()
        assert len(files[0].content) > 0
