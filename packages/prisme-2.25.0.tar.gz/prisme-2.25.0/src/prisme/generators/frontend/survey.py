"""Survey page generator for Prism.

Generates a multi-page survey with question groups (multiple choice, text,
yes/no), a final contact-details page, and submission handling.
"""

from __future__ import annotations

from pathlib import Path

from prisme.generators.base import GeneratedFile, GeneratorBase
from prisme.spec.stack import FileStrategy
from prisme.utils.template_engine import TemplateRenderer


class SurveyGenerator(GeneratorBase):
    """Generator for the multi-page survey component."""

    REQUIRED_TEMPLATES = [
        "frontend/pages/survey.tsx.jinja2",
    ]

    def __init__(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__(*args, **kwargs)
        frontend_base = Path(self.generator_config.frontend_output)
        self.pages_path = frontend_base / self.generator_config.pages_path
        self.renderer = TemplateRenderer()
        self.renderer.validate_templates_exist(self.REQUIRED_TEMPLATES)

    def generate_files(self) -> list[GeneratedFile]:
        """Generate the survey page."""
        project_title = self.spec.effective_title
        dark_mode = self.design_config.dark_mode

        content = self.renderer.render_file(
            "frontend/pages/survey.tsx.jinja2",
            context={
                "project_title": project_title,
                "dark_mode": dark_mode,
            },
        )

        return [
            GeneratedFile(
                path=self.pages_path / "SurveyPage.tsx",
                content=content,
                strategy=FileStrategy.GENERATE_ONCE,
                description="Multi-page survey with contact details and submission",
            ),
        ]


__all__ = ["SurveyGenerator"]
