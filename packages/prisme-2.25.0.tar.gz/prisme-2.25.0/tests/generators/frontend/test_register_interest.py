"""Tests for the register interest page generator."""

from __future__ import annotations

from pathlib import Path

import pytest

from prisme.generators.base import GeneratorContext
from prisme.generators.frontend.register_interest import RegisterInterestGenerator
from prisme.spec.fields import FieldSpec, FieldType
from prisme.spec.model import ModelSpec
from prisme.spec.project import ProjectSpec
from prisme.spec.stack import FileStrategy, StackSpec


@pytest.fixture
def basic_stack() -> StackSpec:
    return StackSpec(
        name="test-project",
        version="1.0.0",
        description="A test project",
        models=[
            ModelSpec(
                name="Item",
                fields=[FieldSpec(name="name", type=FieldType.STRING, required=True)],
            )
        ],
    )


class TestRegisterInterestGenerator:
    """Tests for RegisterInterestGenerator."""

    def test_generates_register_interest_page(self, basic_stack: StackSpec, tmp_path: Path) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = RegisterInterestGenerator(ctx)
        files = gen.generate_files()
        assert len(files) == 1
        assert "RegisterInterestPage.tsx" in str(files[0].path)

    def test_register_interest_uses_generate_once_strategy(
        self, basic_stack: StackSpec, tmp_path: Path
    ) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = RegisterInterestGenerator(ctx)
        files = gen.generate_files()
        assert files[0].strategy == FileStrategy.GENERATE_ONCE

    def test_register_interest_content_has_waitlist_elements(
        self, basic_stack: StackSpec, tmp_path: Path
    ) -> None:
        ctx = GeneratorContext(
            domain_spec=basic_stack,
            output_dir=tmp_path,
            dry_run=True,
            project_spec=ProjectSpec(name="test-project"),
        )
        gen = RegisterInterestGenerator(ctx)
        files = gen.generate_files()
        content = files[0].content
        assert "email" in content
        assert "Waitlist" in content or "Register" in content
