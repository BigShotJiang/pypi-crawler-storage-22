"""CI generator — reads ProjectSpec.ci to generate CI/CD workflows."""

from __future__ import annotations

from pathlib import Path

from prisme.generators.base import GeneratedFile, GeneratorBase, GeneratorResult


class CIGenerator(GeneratorBase):
    """Generate CI/CD workflows from ProjectSpec.ci."""

    def generate_files(self) -> list[GeneratedFile]:
        return []

    def generate(self) -> GeneratorResult:
        project_spec = self.context.project_spec
        if project_spec is None or project_spec.ci is None:
            return GeneratorResult()

        ci = project_spec.ci

        if ci.provider != "github":
            return GeneratorResult(errors=[f"Unsupported CI provider: {ci.provider}"])

        from prisme.ci import CIConfig as CICLIConfig
        from prisme.ci import GitHubCIGenerator

        gen_config = project_spec.generator
        backend_output = Path(gen_config.backend_output)
        frontend_output = Path(gen_config.frontend_output)
        project_dir = Path.cwd()

        backend_path_relative = str(backend_output.parent)
        frontend_path_relative = str(
            frontend_output.parent
            if (project_dir / frontend_output.parent / "package.json").exists()
            else frontend_output
        )
        backend_module = project_spec.backend.module_name or backend_output.name

        config = CICLIConfig(
            project_name=project_spec.name,
            include_frontend=ci.include_frontend,
            use_redis=ci.use_redis,
            enable_codecov=ci.enable_codecov,
            enable_dependabot=ci.enable_dependabot,
            enable_semantic_release=ci.enable_semantic_release,
            enable_commitlint=ci.enable_commitlint,
            backend_path=backend_path_relative,
            frontend_path=frontend_path_relative,
            backend_module=backend_module,
        )

        project_dir = Path.cwd()
        generator = GitHubCIGenerator(project_dir)
        generator.generate(config)

        return GeneratorResult(written=1)
