# Archive

Historical and completed documents preserved for reference. These are no longer actively maintained.

## Removed Features

| Document | Reason | Date |
|----------|--------|------|
| [authentik-integration-plan.md](removed-features/authentik-integration-plan.md) | Replaced by built-in JWT auth system in v0.15.0 | 2026-01-29 |

## Completed Plans

| Document | PR | Date |
|----------|-----|------|
| [admin-panel-plan.md](completed-plans/admin-panel-plan.md) | PR #63 | 2026-01-30 |

## Historical Discussions

Background conversations that informed major design decisions.

| Document | Context |
|----------|---------|
| [v1-feedback.md](historical/v1-feedback.md) | Analysis of v1 spec/config boundary confusion — prompted the v2 refactor |
| [v1-review-new-perspective.md](historical/v1-review-new-perspective.md) | Clarification of v1 three-layer architecture |
| [generate-ignores-config-paths.md](historical/generate-ignores-config-paths.md) | Issue #5 (closed) — generate ignoring config paths |
