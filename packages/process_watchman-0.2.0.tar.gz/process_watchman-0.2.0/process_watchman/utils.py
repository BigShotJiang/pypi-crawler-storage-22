"""Safe psutil wrappers and helper utilities."""

from __future__ import annotations

import psutil

from .model import ProcessInfo, WatcherConfig


def safe_process(pid: int) -> psutil.Process | None:
    """Create a psutil.Process, returning None if the PID does not exist."""
    try:
        return psutil.Process(pid)
    except psutil.NoSuchProcess:
        return None


def safe_create_time(proc: psutil.Process) -> float | None:
    """Return create_time for *proc*, or None on access errors."""
    try:
        return proc.create_time()
    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
        return None


def truncate_cmdline(parts: list[str], max_chars: int) -> str:
    """Join cmdline parts and truncate to *max_chars*."""
    joined = " ".join(parts)
    if len(joined) > max_chars:
        return joined[:max_chars]
    return joined


def collect_process_info(
    proc: psutil.Process,
    config: WatcherConfig,
    *,
    tolerate: bool = True,
) -> ProcessInfo | None:
    """Best-effort collection of ProcessInfo from a psutil.Process.

    Returns None only when the process no longer exists.
    When *tolerate* is True (default), AccessDenied / ZombieProcess errors
    result in partial info (fields set to None) rather than an exception.
    """
    try:
        pid = proc.pid
        ppid = proc.ppid()
    except psutil.NoSuchProcess:
        return None
    except (psutil.AccessDenied, psutil.ZombieProcess):
        if not tolerate:
            raise
        return ProcessInfo(pid=proc.pid, ppid=0)

    create_time = safe_create_time(proc)

    name: str | None = None
    if config.capture_name:
        try:
            name = proc.name()
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            if not tolerate:
                raise

    cmdline: str | None = None
    if config.capture_cmdline:
        try:
            parts = proc.cmdline()
            cmdline = truncate_cmdline(parts, config.cmdline_max_chars)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            if not tolerate:
                raise

    status: str | None = None
    if config.capture_status:
        try:
            status = proc.status()
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            if not tolerate:
                raise

    return ProcessInfo(
        pid=pid,
        ppid=ppid,
        create_time=create_time,
        name=name,
        cmdline=cmdline,
        status=status,
    )
