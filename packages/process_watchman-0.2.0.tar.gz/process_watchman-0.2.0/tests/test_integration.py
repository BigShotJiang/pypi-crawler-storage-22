"""Integration tests: spawn real process trees and verify watcher behaviour."""

from __future__ import annotations

import os
import signal
import subprocess
import sys
import time

import pytest

from process_watchman import ProcessTreeWatcher, WatcherConfig

# Helper script that spawns N sleep children, then waits.
_SPAWN_SCRIPT = """\
import subprocess, sys, time, signal
signal.signal(signal.SIGTERM, lambda *a: sys.exit(0))
n = int(sys.argv[1])
children = [subprocess.Popen(["sleep", "300"]) for _ in range(n)]
# Signal readiness by printing pids
for c in children:
    print(c.pid, flush=True)
time.sleep(300)
"""

# Helper script that spawns a child which itself spawns a grandchild.
_GRANDCHILD_SCRIPT = """\
import subprocess, sys, time, signal
signal.signal(signal.SIGTERM, lambda *a: sys.exit(0))
child = subprocess.Popen([
    sys.executable, "-c",
    "import subprocess, sys, time, signal;"
    "signal.signal(signal.SIGTERM, lambda *a: sys.exit(0));"
    "gc = subprocess.Popen(['sleep', '300']);"
    "print(gc.pid, flush=True);"
    "time.sleep(300)"
], stdout=subprocess.PIPE, text=True)
# Print child pid, then grandchild pid
print(child.pid, flush=True)
gc_pid = child.stdout.readline().strip()
print(gc_pid, flush=True)
time.sleep(300)
"""


@pytest.fixture()
def spawn_tree():
    """Fixture that spawns a root process with N sleep children.

    Yields (root_proc, child_pids).  Cleans up on teardown.
    """
    procs: list[subprocess.Popen] = []
    all_pids: list[int] = []

    def _spawn(n: int = 3) -> tuple[subprocess.Popen, list[int]]:
        root = subprocess.Popen(
            [sys.executable, "-c", _SPAWN_SCRIPT, str(n)],
            stdout=subprocess.PIPE,
            text=True,
            start_new_session=True,
        )
        procs.append(root)
        child_pids = []
        for _ in range(n):
            line = root.stdout.readline().strip()  # type: ignore[union-attr]
            child_pids.append(int(line))
        all_pids.extend(child_pids)
        all_pids.append(root.pid)
        return root, child_pids

    yield _spawn

    # Teardown: kill everything
    for pid in all_pids:
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    for p in procs:
        try:
            p.wait(timeout=2)
        except subprocess.TimeoutExpired:
            p.kill()
            p.wait()


@pytest.fixture()
def spawn_grandchild_tree():
    """Fixture that spawns root -> child -> grandchild.

    Yields (root_proc, child_pid, grandchild_pid).
    """
    all_pids: list[int] = []
    procs: list[subprocess.Popen] = []

    def _spawn() -> tuple[subprocess.Popen, int, int]:
        root = subprocess.Popen(
            [sys.executable, "-c", _GRANDCHILD_SCRIPT],
            stdout=subprocess.PIPE,
            text=True,
            start_new_session=True,
        )
        procs.append(root)
        child_pid = int(root.stdout.readline().strip())  # type: ignore[union-attr]
        gc_pid = int(root.stdout.readline().strip())  # type: ignore[union-attr]
        all_pids.extend([root.pid, child_pid, gc_pid])
        return root, child_pid, gc_pid

    yield _spawn

    for pid in all_pids:
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    for p in procs:
        try:
            p.wait(timeout=2)
        except subprocess.TimeoutExpired:
            p.kill()
            p.wait()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestChildrenRecursiveIntegration:
    def test_discovers_all_children(self, spawn_tree):
        root, child_pids = spawn_tree(3)
        watcher = ProcessTreeWatcher.attach(root.pid)
        snap = watcher.poll()

        assert snap.root_alive is True
        assert snap.root_matches_identity is True
        assert set(child_pids).issubset(set(snap.processes.keys()))

    def test_child_exit_removes_from_live_set(self, spawn_tree):
        root, child_pids = spawn_tree(3)
        watcher = ProcessTreeWatcher.attach(root.pid)
        watcher.poll()

        # Kill first child
        os.kill(child_pids[0], signal.SIGKILL)
        time.sleep(0.3)

        snap2 = watcher.poll()
        assert child_pids[0] not in snap2.processes
        assert child_pids[0] in snap2.delta.removed_pids

    def test_delta_added_on_first_poll(self, spawn_tree):
        root, child_pids = spawn_tree(2)
        watcher = ProcessTreeWatcher.attach(root.pid)
        snap = watcher.poll()

        assert len(snap.delta.added_pids) >= 2
        assert set(child_pids).issubset(set(snap.delta.added_pids))
        assert snap.delta.removed_pids == []


class TestScanPpidIntegration:
    def test_discovers_all_children(self, spawn_tree):
        root, child_pids = spawn_tree(3)
        cfg = WatcherConfig(strategy="scan_ppid")
        watcher = ProcessTreeWatcher.attach(root.pid, config=cfg)
        snap = watcher.poll()

        assert snap.root_alive is True
        assert set(child_pids).issubset(set(snap.processes.keys()))

    def test_discovers_grandchildren(self, spawn_grandchild_tree):
        root, child_pid, gc_pid = spawn_grandchild_tree()
        cfg = WatcherConfig(strategy="scan_ppid")
        watcher = ProcessTreeWatcher.attach(root.pid, config=cfg)
        snap = watcher.poll()

        assert child_pid in snap.processes
        assert gc_pid in snap.processes


class TestGrandchildDiscovery:
    def test_children_recursive_finds_grandchild(self, spawn_grandchild_tree):
        root, child_pid, gc_pid = spawn_grandchild_tree()
        watcher = ProcessTreeWatcher.attach(root.pid)
        snap = watcher.poll()

        assert child_pid in snap.processes
        assert gc_pid in snap.processes


class TestAttachIntegration:
    def test_attach_live_process(self, spawn_tree):
        root, _ = spawn_tree(1)
        watcher = ProcessTreeWatcher.attach(root.pid)
        assert watcher._root.pid == root.pid
        assert watcher._root.create_time > 0

    def test_attach_dead_process(self):
        p = subprocess.Popen(["sleep", "0"])
        p.wait()
        time.sleep(0.1)
        with pytest.raises(Exception):
            ProcessTreeWatcher.attach(p.pid)


class TestRootExitIntegration:
    def test_root_alive_false_after_exit(self, spawn_tree):
        root, child_pids = spawn_tree(2)
        watcher = ProcessTreeWatcher.attach(root.pid)
        watcher.poll()

        # Kill root
        os.kill(root.pid, signal.SIGKILL)
        root.wait()
        time.sleep(0.3)

        snap = watcher.poll()
        assert snap.root_alive is False
        assert snap.root_matches_identity is False
        assert len(snap.processes) == 0
        # All previous children should appear in removed
        for pid in child_pids:
            assert pid in snap.delta.removed_pids


class TestDeltaAcrossPolls:
    def test_multiple_polls_track_changes(self, spawn_tree):
        root, child_pids = spawn_tree(3)
        watcher = ProcessTreeWatcher.attach(root.pid)

        snap1 = watcher.poll()
        assert len(snap1.delta.added_pids) >= 3

        # Steady state — no changes
        snap2 = watcher.poll()
        assert snap2.delta.added_pids == []
        assert snap2.delta.removed_pids == []

        # Kill two children
        os.kill(child_pids[0], signal.SIGKILL)
        os.kill(child_pids[1], signal.SIGKILL)
        time.sleep(0.3)

        snap3 = watcher.poll()
        assert set(snap3.delta.removed_pids) >= {child_pids[0], child_pids[1]}
        assert snap3.delta.added_pids == []

        # Remaining child still live
        assert child_pids[2] in snap3.processes
