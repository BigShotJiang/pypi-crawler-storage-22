"""Tests for ProcessTreeWatcher."""

from unittest.mock import MagicMock, patch

import psutil
import pytest

from process_watchman.model import ProcessIdentity, ProcessInfo, WatcherConfig
from process_watchman.watcher import ProcessTreeWatcher


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_proc(pid, ppid=1, ct=100.0, name="sleep", status="running"):
    """Create a mock psutil.Process."""
    proc = MagicMock()
    proc.pid = pid
    proc.ppid.return_value = ppid
    proc.create_time.return_value = ct
    proc.name.return_value = name
    proc.cmdline.return_value = [name]
    proc.status.return_value = status
    proc.info = {"pid": pid, "ppid": ppid}
    return proc


ROOT_ID = ProcessIdentity(pid=1000, create_time=500.0)


# ---------------------------------------------------------------------------
# attach()
# ---------------------------------------------------------------------------

class TestAttach:
    @patch("process_watchman.watcher.safe_create_time", return_value=500.0)
    @patch("process_watchman.watcher.safe_process")
    def test_attach_success(self, mock_sp, mock_ct):
        mock_sp.return_value = MagicMock()
        watcher = ProcessTreeWatcher.attach(1000)
        assert watcher._root.pid == 1000
        assert watcher._root.create_time == 500.0

    @patch("process_watchman.watcher.safe_process", return_value=None)
    def test_attach_no_such_process(self, mock_sp):
        with pytest.raises(psutil.NoSuchProcess):
            ProcessTreeWatcher.attach(9999)

    @patch("process_watchman.watcher.safe_create_time", return_value=None)
    @patch("process_watchman.watcher.safe_process")
    def test_attach_access_denied(self, mock_sp, mock_ct):
        mock_sp.return_value = MagicMock()
        with pytest.raises(psutil.AccessDenied):
            ProcessTreeWatcher.attach(1000)


# ---------------------------------------------------------------------------
# PID reuse detection
# ---------------------------------------------------------------------------

class TestPidReuse:
    @patch("process_watchman.watcher.safe_create_time", return_value=999.0)
    @patch("process_watchman.watcher.safe_process")
    def test_pid_reuse_detected(self, mock_sp, mock_ct):
        mock_sp.return_value = MagicMock()
        watcher = ProcessTreeWatcher(root=ROOT_ID)
        snap = watcher.poll()
        assert snap.root_alive is True
        assert snap.root_matches_identity is False
        assert len(snap.processes) == 0
        assert any("PID reuse" in w for w in snap.warnings)

    @patch("process_watchman.watcher.safe_process", return_value=None)
    def test_root_dead(self, mock_sp):
        watcher = ProcessTreeWatcher(root=ROOT_ID)
        snap = watcher.poll()
        assert snap.root_alive is False
        assert snap.root_matches_identity is False
        assert len(snap.processes) == 0

    @patch("process_watchman.watcher.safe_create_time", return_value=None)
    @patch("process_watchman.watcher.safe_process")
    def test_create_time_unreadable(self, mock_sp, mock_ct):
        mock_sp.return_value = MagicMock()
        watcher = ProcessTreeWatcher(root=ROOT_ID)
        snap = watcher.poll()
        assert snap.root_alive is True
        assert snap.root_matches_identity is False
        assert any("Cannot read create_time" in w for w in snap.warnings)


# ---------------------------------------------------------------------------
# Delta computation
# ---------------------------------------------------------------------------

class TestDelta:
    def _setup_watcher_with_children(self, child_pids):
        """Return a watcher whose _discover returns mocked children."""
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        children = {
            pid: ProcessInfo(pid=pid, ppid=ROOT_ID.pid)
            for pid in child_pids
        }
        watcher = ProcessTreeWatcher(root=ROOT_ID)
        return watcher, root_proc, children

    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_first_poll_all_added(self, mock_sp, mock_ct):
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time

        child_procs = [_mock_proc(pid, ppid=ROOT_ID.pid) for pid in [10, 20, 30]]
        root_proc.children.return_value = child_procs

        watcher = ProcessTreeWatcher(root=ROOT_ID)
        snap = watcher.poll()

        assert snap.delta.added_pids == [10, 20, 30]
        assert snap.delta.removed_pids == []
        assert set(snap.processes.keys()) == {10, 20, 30}

    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_second_poll_removed(self, mock_sp, mock_ct):
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time

        # First poll: 3 children
        child_procs = [_mock_proc(pid, ppid=ROOT_ID.pid) for pid in [10, 20, 30]]
        root_proc.children.return_value = child_procs
        watcher = ProcessTreeWatcher(root=ROOT_ID)
        watcher.poll()

        # Second poll: child 20 gone
        root_proc.children.return_value = [_mock_proc(10, ppid=ROOT_ID.pid),
                                           _mock_proc(30, ppid=ROOT_ID.pid)]
        snap2 = watcher.poll()
        assert snap2.delta.added_pids == []
        assert snap2.delta.removed_pids == [20]

    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_added_and_removed(self, mock_sp, mock_ct):
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time

        # Poll 1: [10, 20]
        root_proc.children.return_value = [_mock_proc(10, ppid=ROOT_ID.pid),
                                           _mock_proc(20, ppid=ROOT_ID.pid)]
        watcher = ProcessTreeWatcher(root=ROOT_ID)
        watcher.poll()

        # Poll 2: [20, 30] — 10 removed, 30 added
        root_proc.children.return_value = [_mock_proc(20, ppid=ROOT_ID.pid),
                                           _mock_proc(30, ppid=ROOT_ID.pid)]
        snap2 = watcher.poll()
        assert snap2.delta.added_pids == [30]
        assert snap2.delta.removed_pids == [10]


# ---------------------------------------------------------------------------
# children_recursive strategy
# ---------------------------------------------------------------------------

class TestChildrenRecursive:
    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_discovers_children(self, mock_sp, mock_ct):
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time

        child = _mock_proc(10, ppid=ROOT_ID.pid)
        grandchild = _mock_proc(20, ppid=10)
        root_proc.children.return_value = [child, grandchild]

        watcher = ProcessTreeWatcher(root=ROOT_ID)
        snap = watcher.poll()
        assert set(snap.processes.keys()) == {10, 20}

    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_children_call_fails(self, mock_sp, mock_ct):
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time
        root_proc.children.side_effect = psutil.AccessDenied(ROOT_ID.pid)

        watcher = ProcessTreeWatcher(root=ROOT_ID)
        snap = watcher.poll()
        assert len(snap.processes) == 0
        assert any("children(recursive=True) failed" in w for w in snap.warnings)


# ---------------------------------------------------------------------------
# scan_ppid strategy
# ---------------------------------------------------------------------------

class TestScanPpid:
    @patch("process_watchman.watcher.psutil.process_iter")
    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_discovers_via_bfs(self, mock_sp, mock_ct, mock_iter):
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time

        # Simulate process table: root -> child(10) -> grandchild(20)
        procs = [
            _mock_proc(ROOT_ID.pid, ppid=1, ct=ROOT_ID.create_time),
            _mock_proc(10, ppid=ROOT_ID.pid),
            _mock_proc(20, ppid=10),
            _mock_proc(999, ppid=1),  # unrelated
        ]
        mock_iter.return_value = procs

        cfg = WatcherConfig(strategy="scan_ppid")
        watcher = ProcessTreeWatcher(root=ROOT_ID, config=cfg)
        snap = watcher.poll()
        assert set(snap.processes.keys()) == {10, 20}

    @patch("process_watchman.watcher.psutil.process_iter")
    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_max_depth(self, mock_sp, mock_ct, mock_iter):
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time

        # Chain: root -> 10 -> 20 -> 30, max_depth=2 should exclude 30
        procs = [
            _mock_proc(ROOT_ID.pid, ppid=1, ct=ROOT_ID.create_time),
            _mock_proc(10, ppid=ROOT_ID.pid),
            _mock_proc(20, ppid=10),
            _mock_proc(30, ppid=20),
        ]
        mock_iter.return_value = procs

        cfg = WatcherConfig(strategy="scan_ppid", max_depth=2)
        watcher = ProcessTreeWatcher(root=ROOT_ID, config=cfg)
        snap = watcher.poll()
        assert set(snap.processes.keys()) == {10, 20}
        assert 30 not in snap.processes


# ---------------------------------------------------------------------------
# Config options: max_descendants, include_root, keep_tombstones, drop_exited
# ---------------------------------------------------------------------------

class TestConfigOptions:
    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_max_descendants(self, mock_sp, mock_ct):
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time
        root_proc.children.return_value = [_mock_proc(pid, ppid=ROOT_ID.pid) for pid in range(100)]

        cfg = WatcherConfig(max_descendants=5)
        watcher = ProcessTreeWatcher(root=ROOT_ID, config=cfg)
        snap = watcher.poll()
        assert len(snap.processes) == 5
        assert any("max_descendants" in w for w in snap.warnings)

    @patch("process_watchman.watcher.collect_process_info")
    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_include_root(self, mock_sp, mock_ct, mock_collect):
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time
        root_proc.children.return_value = []

        root_info = ProcessInfo(pid=ROOT_ID.pid, ppid=1)
        mock_collect.return_value = root_info

        cfg = WatcherConfig(include_root=True)
        watcher = ProcessTreeWatcher(root=ROOT_ID, config=cfg)
        snap = watcher.poll()
        assert ROOT_ID.pid in snap.processes

    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_keep_tombstones(self, mock_sp, mock_ct):
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time

        # Poll 1: child 10
        root_proc.children.return_value = [_mock_proc(10, ppid=ROOT_ID.pid)]
        cfg = WatcherConfig(keep_tombstones=True)
        watcher = ProcessTreeWatcher(root=ROOT_ID, config=cfg)
        watcher.poll()

        # Poll 2: child 10 gone
        root_proc.children.return_value = []
        watcher.poll()

        assert 10 in watcher._tombstones
        assert watcher._tombstones[10].pid == 10

    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_drop_exited_filters_zombies(self, mock_sp, mock_ct):
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time

        alive = _mock_proc(10, ppid=ROOT_ID.pid, status="running")
        zombie = _mock_proc(20, ppid=ROOT_ID.pid, status=psutil.STATUS_ZOMBIE)
        root_proc.children.return_value = [alive, zombie]

        cfg = WatcherConfig(drop_exited=True)
        watcher = ProcessTreeWatcher(root=ROOT_ID, config=cfg)
        snap = watcher.poll()
        assert 10 in snap.processes
        assert 20 not in snap.processes

    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_drop_exited_false_keeps_zombies(self, mock_sp, mock_ct):
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time

        alive = _mock_proc(10, ppid=ROOT_ID.pid, status="running")
        zombie = _mock_proc(20, ppid=ROOT_ID.pid, status=psutil.STATUS_ZOMBIE)
        root_proc.children.return_value = [alive, zombie]

        cfg = WatcherConfig(drop_exited=False)
        watcher = ProcessTreeWatcher(root=ROOT_ID, config=cfg)
        snap = watcher.poll()
        assert 10 in snap.processes
        assert 20 in snap.processes


# ---------------------------------------------------------------------------
# live_pids
# ---------------------------------------------------------------------------

class TestLivePids:
    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_live_pids_after_poll(self, mock_sp, mock_ct):
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time
        root_proc.children.return_value = [_mock_proc(10, ppid=ROOT_ID.pid),
                                           _mock_proc(20, ppid=ROOT_ID.pid)]

        watcher = ProcessTreeWatcher(root=ROOT_ID)
        assert watcher.live_pids() == set()  # before first poll
        watcher.poll()
        assert watcher.live_pids() == {10, 20}

    def test_live_pids_returns_copy(self):
        watcher = ProcessTreeWatcher(root=ROOT_ID)
        watcher._prev_pids = {1, 2, 3}
        live = watcher.live_pids()
        live.add(999)
        assert 999 not in watcher._prev_pids


# ---------------------------------------------------------------------------
# Error tolerance
# ---------------------------------------------------------------------------

class TestErrorTolerance:
    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_poll_never_raises(self, mock_sp, mock_ct):
        """poll() should never raise, even with unexpected errors in discovery."""
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time
        root_proc.children.side_effect = psutil.NoSuchProcess(ROOT_ID.pid)

        watcher = ProcessTreeWatcher(root=ROOT_ID)
        snap = watcher.poll()  # should not raise
        assert snap.root_alive is True
        assert len(snap.processes) == 0

    @patch("process_watchman.watcher.safe_create_time")
    @patch("process_watchman.watcher.safe_process")
    def test_unknown_strategy_warning(self, mock_sp, mock_ct):
        root_proc = _mock_proc(ROOT_ID.pid, ct=ROOT_ID.create_time)
        mock_sp.return_value = root_proc
        mock_ct.return_value = ROOT_ID.create_time
        root_proc.children.return_value = []

        cfg = WatcherConfig(strategy="bogus")
        watcher = ProcessTreeWatcher(root=ROOT_ID, config=cfg)
        snap = watcher.poll()
        assert any("Unknown strategy" in w for w in snap.warnings)
