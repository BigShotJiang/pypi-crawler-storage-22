import concurrent.futures
import grpc
import re
import time
from grpc_interceptor import ClientCallDetails, ClientInterceptor
from profiles_rudderstack.tunnel.tunnel_pb2_grpc import WhtServiceStub

GoRpc = None
MAX_RETRIES = 5


def init_go_rpc(goRpcAddress: str, token: str):
    # Determine the port from the input address (which might be a template like 127.0.0.1:port)
    # The goRpcAddress passed here was constructed in Go as "127.0.0.1:port" or "localhost:port"
    # We need to extract the port to build our candidate list.

    port_match = re.search(r":(\d+)$", goRpcAddress)
    if not port_match:
        # If we can't parse the port, fallback to original behavior (single attempt)
        candidates = [goRpcAddress]
    else:
        port = port_match.group(1)
        candidates = [f"localhost:{port}", f"127.0.0.1:{port}", f"[::1]:{port}"]

    interceptors = [ClientTokenAuthInterceptor(token)]
    size_in_kb = 64  # Default is 8
    options = [("grpc.max_metadata_size", size_in_kb * 1024)]

    last_error = None

    def probe(address):
        """Attempts to connect to the given address. Returns (channel, intercept_channel) on success, raises Exception on failure."""
        try:
            channel = grpc.insecure_channel(address, options=options)
            intercept_channel = grpc.intercept_channel(channel, *interceptors)
            # Probing phase
            grpc.channel_ready_future(channel).result(timeout=1.0)
            return channel, intercept_channel
        except Exception:
            # We don't explicitly close here because the channel might not even be open,
            # and explicit close logic in Python gRPC can be tricky if not ready.
            # But good practice to let GC handle it or close if we kept a reference.
            raise

    last_error = None

    for i in range(MAX_RETRIES):
        # Manual executor management to avoid blocking on __exit__
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=len(candidates))
        future_to_addr = {executor.submit(probe, addr): addr for addr in candidates}

        success_result = None
        try:
            for future in concurrent.futures.as_completed(future_to_addr):
                try:
                    channel, intercept_channel = future.result()
                    if not success_result:
                        success_result = (channel, intercept_channel)
                        # We don't 'break' yet, we need to collect/close losers
                    else:
                        # This is a 'late' winner, close it immediately
                        channel.close()
                except Exception as e:
                    last_error = e
        finally:
            # helper to shutdown without waiting
            executor.shutdown(wait=False)

        if success_result:
            channel, intercept_channel = success_result
            global GoRpc
            GoRpc = WhtServiceStub(intercept_channel)
            return GoRpc, channel

        # If we are here, essentially all attempts in this iteration failed
        # Outer backoff
        if i < MAX_RETRIES - 1:
            time.sleep(0.1 * (2**i))

    raise Exception(
        f"Failed to connect to Go RPC server after trying candidates {candidates}. Last error: {last_error}"
    )


def get_gorpc() -> WhtServiceStub:
    if GoRpc is None:
        raise Exception("Go RPC Client not initialized")
    return GoRpc


class ClientTokenAuthInterceptor(ClientInterceptor):
    def __init__(self, token: str):
        self.token = token

    def intercept(
        self, method, request_or_iterator, call_details: grpc.ClientCallDetails
    ):
        new_details = ClientCallDetails(
            call_details.method,
            call_details.timeout,
            [("authorization", self.token)],
            call_details.credentials,
            call_details.wait_for_ready,
            call_details.compression,
        )

        return method(request_or_iterator, new_details)
