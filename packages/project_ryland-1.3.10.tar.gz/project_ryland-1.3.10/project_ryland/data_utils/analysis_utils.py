"""
------------------------------------------------------------------------------
Author:         Justin Vinh
Collaborators:  John Rhee, MD
Parent Package: Project Ryland
Creation Date:  2025.10.16
Last Modified:  2025.10.16

Purpose:
This module contains functions designed to aid in statistical analyses of
data processed by LLMs
------------------------------------------------------------------------------
"""

