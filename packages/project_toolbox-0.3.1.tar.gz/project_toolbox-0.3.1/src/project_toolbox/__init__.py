"""project-toolbox -- A set of tools for managing codebases, workflows, and development tasks.

  A guide to navigate through the toolbox.

Available tools:
  release-tag           Add and push git tag for project release.
  bump                  Bump project version.
"""


def main():
    print(__doc__)
