# /// script
# requires-python = ">=3.12"
# dependencies = [
#     "click>=8.3.1",
# ]
# ///


import subprocess
import itertools
import click


CORE = ("major", "minor", "patch")
STABLE = ("stable", )
PRERELEASE = ("alpha", "beta", "rc", "post", "dev")
BUMP = CORE + STABLE + PRERELEASE


def run(cmd, **kwds):
    click.echo("---")
    click.echo(f"$ {' '.join(cmd)}")
    result = subprocess.run(cmd, **kwds)
    click.echo("---")
    return result


@click.command(context_settings={"help_option_names": ['-h', '--help']})
@click.argument("values", nargs=-1, type=click.Choice(BUMP))
@click.option("--no-retry", "-y", is_flag=True, help="No dry-run, don't ask before doing.")
def main(values, no_retry) -> None:
    """ Update the project version using the given semantics.
    """
    edit_values = click.Choice([*BUMP, ""])
    values = list(values)
    while True:
        print("bumps:", *values)
        options = list(itertools.chain.from_iterable(
            itertools.zip_longest((), values, fillvalue='--bump')
        ))
        if no_retry:
            run(["uv", "version", *options])
            exit()
        res = run(["uv", "version", "--dry-run", *options])
        if res.returncode == 0:
            if click.confirm(f"Do it ?"):
                run(["uv", "version", *options])
                exit()
        print("bumps:", *values)
        bump = click.prompt("name value to add/remove it:", default="", type=edit_values)
        if not bump:
            exit()
        core = [e for e in values if e in CORE]
        prerelease = [e for e in values if e in PRERELEASE]
        if bump in STABLE:
            values = [bump]
        elif bump in CORE:
            values = [bump, *prerelease]
        elif bump in PRERELEASE:
            values = [*core, bump]


if __name__ == "__main__":
    main()
