import os
import importlib.metadata
import subprocess
import click

from . import cmd_manual
from . import cmd_self
from . import toolboxes


@click.group(
    add_help_option=False,
)
def main():
    """ project-toolbox - the toolbox for managing your project
    """
    pass


main.add_command(cmd_manual.main)
main.add_command(cmd_self.main)

for cmd, config in toolboxes.iter_commands():
    main.command(**config)(cmd)
