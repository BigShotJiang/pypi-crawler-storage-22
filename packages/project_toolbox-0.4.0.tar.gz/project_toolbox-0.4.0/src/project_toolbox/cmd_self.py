import subprocess
import click


@click.group("self")
def main():
    """ A set of commands for managing the toolbox itself.
    """
    pass


@main.command()
@click.argument("name", default="default")
def add(name):
    """ add or upgrade a toolbox to the project
    """
    name = f"project-toolbox-{name}"
    out = subprocess.run(["uv", "add", "--quiet", "--dev", name])
    if out.returncode != 0:
        exit(out.returncode)
    subprocess.run(["uv", "remove", "--quiet", "--dev", name])
    subprocess.run(["uv", "add", "--dev", name])


@main.command()
def env():
    """ show project's environment
    """
    ...


@main.command()
def completion():
    """ add completion to shell
    """
    ...
