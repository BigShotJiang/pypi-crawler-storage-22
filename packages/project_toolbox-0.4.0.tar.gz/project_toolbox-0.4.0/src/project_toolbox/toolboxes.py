import os
import importlib.metadata
import subprocess
import click


def rename(name):
    def wrap(func):
        func.__name__ = name
        return func
    return wrap


def complete_args(ctx, param, incomplete):
    shell_complete_mode = os.environ.get("_T_COMPLETE")
    cmd = ["uv", "run", ctx.command.name]
    env = {
        **os.environ,
        f"_{ctx.command.name}_COMPLETE".upper().replace('-', '_') : shell_complete_mode,
    }
    subprocess.run(cmd, env=env)
    # return empty but command above already emitted data to system
    return []


def build_command(command):
    result = subprocess.run(
        ["uv", "run", command, "--help"], capture_output=True, text=True,
    )
    help = '\n'.join(result.stdout.splitlines()[1:]).strip()

    group_config = dict(
        context_settings=dict(ignore_unknown_options=True),
        help=help,
        add_help_option=False,
    )

    @click.argument("args", nargs=-1, type=click.UNPROCESSED, shell_complete=complete_args)
    @rename(command)
    def _subcommand(args):
        cmd = ["uv", "run", command, *args]
        click.echo(f"$ {' '.join(cmd)}")
        subprocess.run(cmd)

    return _subcommand, group_config


def get_commands_from_module(module):
    return subprocess.run(
        ["uv", "run", "python", "-c", (
            "import importlib.metadata as im;"
            "print(*("
            "  ep.name"
            "  for ep in im.entry_points(group='console_scripts')"
            f"  if '{module}' in ep.module.split('.')[:1]"
            "))"
        )],
        capture_output=True,
        text=True,
    ).stdout.split()


def get_toolbox_modules():
    return subprocess.run(
        ["uv", "run", "python", "-c", (
            "import importlib.metadata as im;"
            "print(*("
            "  ep.value"
            "  for ep in im.entry_points(group='project_toolbox')"
            f"  if ep.name == 'module'"
            "))"
        )],
        capture_output=True,
        text=True,
    ).stdout.split()


def iter_commands():
    for module in get_toolbox_modules():
        for command in get_commands_from_module(module):
            yield build_command(command)
