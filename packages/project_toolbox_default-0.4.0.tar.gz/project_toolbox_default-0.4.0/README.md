# project-toolbox

A set of tools for managing codebases, workflows, and development tasks.
```shell
uv tool install project-toolbox-launcher
cd my/project/
t install
t
```

## Overview

I want a toolbox to support my Python development workflow.
This toolbox does not cover all workflows.

For now, I'm working with git and uv.

## Getting started
Add `project-toolbox` to the project
```shell
uv add --dev project-toolbox
```
Now you can call the tools with `uv run <command>`.

Get the  of the tools with
```shell
uv run project-toolbox
```
Or call a specific tool
```shell
uv run release  # add a new version tag to git repo based on pyproject.toml
```

## The launcher

[project-toolbox-launcher](https://pypi.org/project/project-toolbox-launcher/) is a companion package providing a handy launcher for the tools.

## Philosophy

- tools should make each step of the workflow simple and easy
- tools should make the workflow easy to follow and remember
- tools should automate repetitive tasks
- tools should reduce the number of command to remember
- tools should avoid mistakes by checking project sanity
- tools should tell what they are doing
