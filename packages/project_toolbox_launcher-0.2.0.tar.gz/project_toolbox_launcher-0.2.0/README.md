# project-toolbox-launcher
A launcher command for project-toolbox.

## Getting started

Install the launcher globally:
```shell
uv tool install project-toolbox-launcher
```

Enable completion (bash) by adding the following to the end of your `~/.bashrc`:
```shell
eval "$(_T_COMPLETE=bash_source t)"
```
Instructions for completion with other shells [can be found here](https://click.palletsprojects.com/en/stable/shell-completion/#enabling-completion).


## Why ?
[project-toolbox](https://gitlab.com/fsmai/project-toolbox) is designed to be installed in your project dev environment and to be run like:
```shell
uv run <command>
```
This works well but it has 2 problems
- a lot of repetitive typing
- no completion available throught `uv run`

The launcher fixes that by providing a single command, `t`, at global level:
```shell
t <command>
```
Completion works for `<command>` and also for the parameters of the commands.


