import os
import importlib.metadata
import subprocess
import click


@click.group(
    add_help_option=False,
)
def main():
    """ Launcher for project-toolbox
    """
    pass


@main.command()
def install():
    """ Install/upgrade project-toolbox into project
    """
    out = subprocess.run(["uv", "add", "--quiet", "--dev", "project-toolbox"])
    if out.returncode != 0:
        exit(out.returncode)
    subprocess.run(["uv", "remove", "--quiet", "--dev", "project-toolbox"])
    subprocess.run(["uv", "add", "--dev", "project-toolbox"])


def rename(name):
    def wrap(func):
        func.__name__ = name
        return func
    return wrap


def complete_args(ctx, param, incomplete):
    shell_complete_mode = os.environ.get("_T_COMPLETE")
    cmd = ["uv", "run", ctx.command.name]
    env = {
        **os.environ,
        f"_{ctx.command.name}_COMPLETE".upper().replace('-', '_') : shell_complete_mode,
    }
    subprocess.run(cmd, env=env)
    # return empty but command above already emitted data to system
    return []


def add_subcommand(main, command):
    result = subprocess.run(
        ["uv", "run", command, "--help"], capture_output=True, text=True,
    )
    help = '\n'.join(result.stdout.splitlines()[1:]).strip()

    @main.command(
        context_settings=dict(ignore_unknown_options=True),
        help=help,
        add_help_option=False,
    )
    @click.argument("args", nargs=-1, type=click.UNPROCESSED, shell_complete=complete_args)
    @rename(command)
    def _subcommand(args):
        cmd = ["uv", "run", command, *args]
        click.echo(f"$ {' '.join(cmd)}")
        subprocess.run(cmd)

    return _subcommand


def add_all_subcommands(group, module):
    command_names = subprocess.run(
        ["uv", "run", "python", "-c", (
            "import importlib.metadata as im;"
            "print(*("
            "  ep.name"
            "  for ep in im.entry_points(group='console_scripts')"
            f"  if (ep.module != '{module}.launcher')"
            f"     and ('{module}' in ep.module.split('.')[:1])"
            "))"
        )],
        capture_output=True,
        text=True,
    ).stdout.split()

    for command in command_names:
        add_subcommand(group, command)


add_all_subcommands(main, "project_toolbox")
