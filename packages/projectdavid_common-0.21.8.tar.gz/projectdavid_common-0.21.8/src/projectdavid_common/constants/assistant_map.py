PLATFORM_ASSISTANT_ID_MAP = {
    "default_assistant": "plt_ast_9fnJT01VGrK4a9fcNr8z2O",
    "synthian": "plt_ast_mFySSaT11K0qM6RmFoOpW6",
}
