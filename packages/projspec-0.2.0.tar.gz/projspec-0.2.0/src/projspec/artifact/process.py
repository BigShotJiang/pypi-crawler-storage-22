import subprocess

from projspec.artifact import BaseArtifact


class Process(BaseArtifact):
    """A simple process where we know nothing about what it does, only if it's running.

    Can include batch jobs and long-running services.
    """

    def _make(self, **kwargs):
        if self.proc is None:
            self.proc = subprocess.Popen(self.cmd, **kwargs)

    def _is_done(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def clean(
        self,
    ):
        if self.proc is not None:
            self.proc.terminate()
            self.proc.wait()
            self.proc = None


class Server(Process):
    """A process that is designed to stay running and serve requests, usually over HTTP"""

    pass
