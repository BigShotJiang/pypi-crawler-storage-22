import os
import subprocess

from projspec.proj import ProjectSpec, ParseFailed


class Django(ProjectSpec):
    """A python web app using the django framework"""

    # this is the metadata settings reference
    spec_doc = "https://docs.djangoproject.com/en/6.0/ref/settings/"

    def match(self):
        return "manage.py" in self.proj.basenames

    def parse(self) -> None:
        from projspec.artifact.process import Server

        # global settings are in ./*/settings.py in a directory also containing urls.py
        # the top-level; manage.py may have the line to locate it:
        # os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings")
        # and "mysite" is the suggestion in the tutorials;
        # can also be given as --settings to manage.py
        allpy = self.proj.fs.glob(f"{self.proj.url}/*/*.py")

        # We could also choose to parse the settings or URLs - but they are required
        s_dirs = {_.rsplit("/", 1)[0] for _ in allpy if _.endswith("settings.py")}
        u_dirs = {_.rsplit("/", 1)[0] for _ in allpy if _.endswith("urls.py")}
        maindir = s_dirs.intersection(u_dirs)
        if not maindir:
            raise ParseFailed

        # each site is a subdirectory with admin.py and other stuff, typically
        # each mapped to a different sub-URL.
        appdirs = [_.rsplit("/", 2)[-2] for _ in allpy if _.endswith("admin.py")]
        if appdirs:
            self.contents["apps"] = appdirs

        self.artifacts["server"] = Server(
            proj=self.proj, cmd=["python", "manage.py", "runserver"]
        )

    @staticmethod
    def _create(path, sitename="mysite", appname="myapp"):
        os.makedirs(path, exist_ok=True)
        cmd = ["python", "-m", "django", "startproject", sitename, path]
        subprocess.check_call(cmd, cwd=path)
        cmd = ["python", f"{path}/manage.py", "startapp", appname]
        subprocess.check_call(cmd, cwd=path)


class Streamlit(ProjectSpec):
    """Interactive graphical app served in the browser, with streamlit components"""

    spec_doc = "https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/file-organization"
    # see also "https://docs.streamlit.io/develop/api-reference/configuration/config.toml", which is
    # mainly theme and server config.

    def match(self) -> bool:
        # more possible layouts
        return bool(
            {".streamlit", "streamlit_app.py"}.intersection(self.proj.basenames)
        )

    @staticmethod
    def _create(path):
        # `streamlit init` does this, without the toml file.
        os.makedirs(f"{path}/.streamlit", exist_ok=True)
        with open(f"{path}/.streamlit/config.toml", "wt") as f:
            f.write(
                """
                [global]

                [logger]
                level = "info"

                [server]
                headless = true
                """
            )
        with open(f"{path}/streamlit_app.py", "wt") as f:
            f.write(
                """
                import streamlit as st
                st.title("Streamlit minimal app")
                st.write("Hello world!")
                """
            )
        if not os.path.exists(f"{path}/requirements.txt"):
            with open(f"{path}/requirements.txt", "wt") as f:
                f.write("streamlit")
        elif "streamlit" not in open(f"{path}/requirements.txt").read():
            with open(f"{path}/requirements.txt", "at") as f:
                f.write("\nstreamlit")

    def parse(self) -> None:
        from projspec.content.environment import PythonRequirements, CondaEnv
        from projspec.artifact.process import Server

        # https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/app-dependencies

        # a requirements.txt file is the most common and suggested way, but uv, pipenv and poetry are
        # also supported - but they will get picked up as separate project types.
        # Furthermore, the spec can live alongside the code in subdirectories, the apps in this
        # project do not share an environment.
        if "environment" not in self.proj.contents:
            # just because of ordering
            for cls in (PythonRequirements, CondaEnv):
                if cls.match(self):
                    p = cls(self.proj)
                    p.parse()
                    self._contents["environment"] = p.contents["environment"]
                    break
        if "environment" in self.proj.contents:
            self._contents["environment"] = self.proj.contents["environment"]
        # TODO: packages.txt lists packages to apt-get

        # the common case is a single .py file
        pyfiles = [v for v in self.proj.basenames if v.endswith(".py")]
        if len(pyfiles) == 1:
            self.artifacts["server"] = Server(
                proj=self.proj, cmd=["streamlit", "run", pyfiles[0]]
            )
        else:
            # TODO: use walk (top-down) here to avoid known directories like .venv/
            pyfiles = self.proj.fs.glob(f"{self.proj.url}/**/*.py")
            pycontent = self.proj.fs.cat(pyfiles)
            self.artifacts["server"] = {}
            for path, content in pycontent.items():
                if "import streamlit as st" and "\nst." in content.decode():
                    name = path.rsplit("/", 1)[-1].replace(".py", "")
                    self.artifacts["server"][name] = Server(
                        proj=self.proj,
                        cmd=["streamlit", "run", path.replace(self.proj.url, "")],
                    )


# TODO: the following are similar to streamlit, but with perhaps even less metadata
# - flask (from flask import Flask; app = Flask( )
# - fastapi (from fastapi import FastAPI; app = FastAPI( )
# - plotly/dash (from dash import Dash; app = Dash(); app.run())
# - voila (this is just a way to display a notebook)
# - panel (import panel as pn; .servable())
# Each of these takes extra parameters for listen address and port at least.
