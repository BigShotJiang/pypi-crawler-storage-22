"""
ProleTRact - Tandem Repeat Visualization Tool
"""

__version__ = "1.1.0"
__author__ = "Lion Ward Al Raei"

