"""
CLI module for ProleTRact
"""


