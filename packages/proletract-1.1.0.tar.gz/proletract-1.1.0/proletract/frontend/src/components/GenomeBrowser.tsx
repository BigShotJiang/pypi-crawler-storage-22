import React, { useState, useEffect, useRef, useCallback } from 'react';
import axios from 'axios';
import './GenomeBrowser.css';

const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8502';

interface GenomeRegion {
  chr: string;
  start: number;
  end: number;
  region: string;
  density?: number;
}

interface GenomeBrowserProps {
  vcfPath: string;
  selectedRegion?: string;
  onRegionSelect?: (region: string) => void;
  publicVcfFolder?: string;
}

type ZoomLevel = 'chromosome' | '1mb' | '100kb' | '10kb' | 'region';

const CHROMOSOME_ORDER = [
  'chr1', 'chr2', 'chr3', 'chr4', 'chr5', 'chr6', 'chr7', 'chr8', 'chr9', 'chr10',
  'chr11', 'chr12', 'chr13', 'chr14', 'chr15', 'chr16', 'chr17', 'chr18', 'chr19', 'chr20',
  'chr21', 'chr22', 'chrX', 'chrY', 'chrM'
];

const CHROMOSOME_SIZES: Record<string, number> = {
  'chr1': 248956422, 'chr2': 242193529, 'chr3': 198295559, 'chr4': 190214555,
  'chr5': 181538259, 'chr6': 170805979, 'chr7': 159345973, 'chr8': 145138636,
  'chr9': 138394717, 'chr10': 133797422, 'chr11': 135086622, 'chr12': 133275309,
  'chr13': 114364328, 'chr14': 107043718, 'chr15': 101991189, 'chr16': 90338345,
  'chr17': 83257441, 'chr18': 80373285, 'chr19': 58617616, 'chr20': 64444167,
  'chr21': 46709983, 'chr22': 50818468, 'chrX': 156040895, 'chrY': 57227415,
  'chrM': 16569
};

const GenomeBrowser: React.FC<GenomeBrowserProps> = ({
  vcfPath,
  selectedRegion,
  onRegionSelect,
  publicVcfFolder
}) => {
  const [regions, setRegions] = useState<GenomeRegion[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentChromosome, setCurrentChromosome] = useState<string>('chr1');
  const [zoomLevel, setZoomLevel] = useState<ZoomLevel>('chromosome');
  const [viewStart, setViewStart] = useState<number>(0);
  const [viewEnd, setViewEnd] = useState<number>(0);
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);
  const [availableChromosomes, setAvailableChromosomes] = useState<string[]>([]);
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<number>(0);
  const [bookmarkedRegions, setBookmarkedRegions] = useState<Set<string>>(new Set());
  const [pathogenicRegions, setPathogenicRegions] = useState<Set<string>>(new Set());

  // Load bookmarks
  useEffect(() => {
    try {
      const stored = localStorage.getItem('proletract_bookmarks');
      if (stored) {
        const bookmarks = JSON.parse(stored) as { region: string }[];
        const regionSet = new Set<string>(bookmarks.map((b) => b.region));
        setBookmarkedRegions(regionSet);
      }
    } catch (err) {
      console.error('Error loading bookmarks:', err);
    }
  }, []);

  // Fetch regions for current view
  useEffect(() => {
    if (!vcfPath || !currentChromosome) return;

    const fetchRegions = async () => {
      setLoading(true);
      try {
        const params: any = {
          vcf_path: vcfPath,
          chr: currentChromosome
        };

        if (zoomLevel !== 'chromosome') {
          params.start = viewStart;
          params.end = viewEnd;
        }

        const response = await axios.get(`${API_BASE}/api/vcf/genome-view`, { params });
        setRegions(response.data.regions || []);
        setAvailableChromosomes(response.data.available_chromosomes || []);
      } catch (error: any) {
        console.error('Error fetching genome view:', error);
        setRegions([]);
      } finally {
        setLoading(false);
      }
    };

    fetchRegions();
  }, [vcfPath, currentChromosome, zoomLevel, viewStart, viewEnd]);

  // Initialize view based on selected region
  useEffect(() => {
    if (selectedRegion) {
      const match = selectedRegion.match(/^([^:]+):(\d+)-(\d+)$/);
      if (match) {
        const [, chr, startStr, endStr] = match;
        const start = parseInt(startStr, 10);
        const end = parseInt(endStr, 10);
        setCurrentChromosome(chr);
        const size = CHROMOSOME_SIZES[chr] || end;
        const center = (start + end) / 2;
        
        if (zoomLevel === 'chromosome') {
          setViewStart(Math.max(0, center - size / 2));
          setViewEnd(Math.min(size, center + size / 2));
          setZoomLevel('1mb');
        } else {
          setViewStart(Math.max(0, center - (viewEnd - viewStart) / 2));
          setViewEnd(Math.min(size, center + (viewEnd - viewStart) / 2));
        }
      }
    }
  }, [selectedRegion]);

  // Calculate view range based on zoom level
  useEffect(() => {
    const chrSize = CHROMOSOME_SIZES[currentChromosome] || 100000000;
    
    switch (zoomLevel) {
      case 'chromosome':
        setViewStart(0);
        setViewEnd(chrSize);
        break;
      case '1mb':
        setViewStart(Math.max(0, (viewStart + viewEnd) / 2 - 500000));
        setViewEnd(Math.min(chrSize, (viewStart + viewEnd) / 2 + 500000));
        break;
      case '100kb':
        setViewStart(Math.max(0, (viewStart + viewEnd) / 2 - 50000));
        setViewEnd(Math.min(chrSize, (viewStart + viewEnd) / 2 + 50000));
        break;
      case '10kb':
        setViewStart(Math.max(0, (viewStart + viewEnd) / 2 - 5000));
        setViewEnd(Math.min(chrSize, (viewStart + viewEnd) / 2 + 5000));
        break;
      case 'region':
        // Keep current view, but constrain to chromosome
        setViewStart(Math.max(0, Math.min(viewStart, chrSize)));
        setViewEnd(Math.min(chrSize, Math.max(viewEnd, viewStart + 1000)));
        break;
    }
  }, [zoomLevel, currentChromosome]);

  const handleZoom = (level: ZoomLevel) => {
    setZoomLevel(level);
  };

  const handlePan = (direction: 'left' | 'right') => {
    const chrSize = CHROMOSOME_SIZES[currentChromosome] || 100000000;
    const range = viewEnd - viewStart;
    const panAmount = range * 0.2;

    if (direction === 'left') {
      setViewStart(Math.max(0, viewStart - panAmount));
      setViewEnd(Math.min(chrSize, viewEnd - panAmount));
    } else {
      setViewStart(Math.max(0, viewStart + panAmount));
      setViewEnd(Math.min(chrSize, viewEnd + panAmount));
    }
  };

  const handleRegionClick = (region: string) => {
    if (onRegionSelect) {
      onRegionSelect(region);
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 0) { // Left mouse button
      setIsDragging(true);
      setDragStart(e.clientX);
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging && containerRef.current) {
      const delta = dragStart - e.clientX;
      const chrSize = CHROMOSOME_SIZES[currentChromosome] || 100000000;
      const range = viewEnd - viewStart;
      const pixelsPerBase = containerRef.current.clientWidth / range;
      const panAmount = delta / pixelsPerBase;
      
      setViewStart(Math.max(0, viewStart + panAmount));
      setViewEnd(Math.min(chrSize, viewEnd + panAmount));
      setDragStart(e.clientX);
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const chrSize = CHROMOSOME_SIZES[currentChromosome] || 100000000;
    const range = viewEnd - viewStart;
    const center = (viewStart + viewEnd) / 2;
    const zoomFactor = e.deltaY > 0 ? 1.1 : 0.9;
    const newRange = range * zoomFactor;
    const minRange = 1000;
    const maxRange = chrSize;

    if (newRange >= minRange && newRange <= maxRange) {
      const newStart = Math.max(0, center - newRange / 2);
      const newEnd = Math.min(chrSize, center + newRange / 2);
      setViewStart(newStart);
      setViewEnd(newEnd);
      
      // Update zoom level based on range
      if (newRange >= chrSize * 0.8) {
        setZoomLevel('chromosome');
      } else if (newRange >= 1000000) {
        setZoomLevel('1mb');
      } else if (newRange >= 100000) {
        setZoomLevel('100kb');
      } else if (newRange >= 10000) {
        setZoomLevel('10kb');
      } else {
        setZoomLevel('region');
      }
    }
  };

  const renderChromosomeOverview = () => {
    const chrSize = CHROMOSOME_SIZES[currentChromosome] || 100000000;
    const width = 800;
    const height = 100;
    const scale = width / chrSize;
    const viewStartPx = viewStart * scale;
    const viewEndPx = viewEnd * scale;

    return (
      <div className="chromosome-overview">
        <h4>{currentChromosome}</h4>
        <svg width={width} height={height} className="overview-svg">
          {/* Chromosome background */}
          <rect x={0} y={20} width={width} height={60} fill="#e0e0e0" rx={5} />
          
          {/* Region density */}
          {regions.map((region, idx) => {
            const x = region.start * scale;
            const w = Math.max(1, (region.end - region.start) * scale);
            return (
              <rect
                key={idx}
                x={x}
                y={20}
                width={w}
                height={60}
                fill="#4a90e2"
                opacity={0.5}
                className="density-bar"
              />
            );
          })}
          
          {/* Viewport indicator */}
          <rect
            x={viewStartPx}
            y={15}
            width={Math.max(2, viewEndPx - viewStartPx)}
            height={70}
            fill="none"
            stroke="#ff6b6b"
            strokeWidth={2}
            className="viewport-indicator"
          />
        </svg>
        <div className="overview-scale">
          <span>0</span>
          <span>{Math.floor(chrSize / 1000000)}Mb</span>
        </div>
      </div>
    );
  };

  const renderMainView = () => {
    const width = containerRef.current?.clientWidth || 1200;
    const height = 400;
    const range = viewEnd - viewStart;
    const scale = width / range;
    const tickSpacing = calculateTickSpacing(range);

    return (
      <div
        ref={containerRef}
        className="genome-browser-main"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
        style={{ cursor: isDragging ? 'grabbing' : 'grab' }}
      >
        <svg ref={svgRef} width={width} height={height} className="main-svg">
          {/* Ruler */}
          <g className="ruler">
            {generateTicks(viewStart, viewEnd, tickSpacing).map((tick, idx) => {
              const x = (tick - viewStart) * scale;
              return (
                <g key={idx}>
                  <line x1={x} y1={0} x2={x} y2={height} stroke="#ccc" strokeWidth={1} opacity={0.3} />
                  <text x={x} y={15} textAnchor="middle" fontSize="10" fill="#666">
                    {formatPosition(tick)}
                  </text>
                </g>
              );
            })}
          </g>

          {/* Regions */}
          <g className="regions">
            {regions.map((region, idx) => {
              if (region.end < viewStart || region.start > viewEnd) return null;
              
              const x = (region.start - viewStart) * scale;
              const w = Math.max(1, (region.end - region.start) * scale);
              const isSelected = selectedRegion === region.region;
              const isBookmarked = bookmarkedRegions.has(region.region);
              const isPathogenic = pathogenicRegions.has(region.region);
              const isHovered = hoveredRegion === region.region;
              
              let fill = '#4a90e2';
              if (isSelected) fill = '#ff6b6b';
              else if (isPathogenic) fill = '#ff0000';
              else if (isBookmarked) fill = '#ffd700';
              
              return (
                <rect
                  key={idx}
                  x={x}
                  y={50}
                  width={w}
                  height={300}
                  fill={fill}
                  opacity={isHovered ? 1 : 0.7}
                  stroke={isSelected ? '#000' : 'none'}
                  strokeWidth={isSelected ? 2 : 0}
                  className="region-bar"
                  onMouseEnter={() => setHoveredRegion(region.region)}
                  onMouseLeave={() => setHoveredRegion(null)}
                  onClick={() => handleRegionClick(region.region)}
                  style={{ cursor: 'pointer' }}
                />
              );
            })}
          </g>

          {/* Hover tooltip */}
          {hoveredRegion && (
            <g className="tooltip">
              <rect
                x={10}
                y={10}
                width={200}
                height={60}
                fill="rgba(0, 0, 0, 0.8)"
                rx={5}
              />
              <text x={15} y={30} fill="white" fontSize="12">
                {hoveredRegion}
              </text>
            </g>
          )}
        </svg>
      </div>
    );
  };

  const calculateTickSpacing = (range: number): number => {
    if (range >= 100000000) return 10000000; // 10Mb
    if (range >= 10000000) return 1000000; // 1Mb
    if (range >= 1000000) return 100000; // 100kb
    if (range >= 100000) return 10000; // 10kb
    if (range >= 10000) return 1000; // 1kb
    return 100;
  };

  const generateTicks = (start: number, end: number, spacing: number): number[] => {
    const ticks: number[] = [];
    const firstTick = Math.ceil(start / spacing) * spacing;
    for (let tick = firstTick; tick <= end; tick += spacing) {
      ticks.push(tick);
    }
    return ticks;
  };

  const formatPosition = (pos: number): string => {
    if (pos >= 1000000) return `${(pos / 1000000).toFixed(2)}Mb`;
    if (pos >= 1000) return `${(pos / 1000).toFixed(0)}kb`;
    return `${pos}`;
  };

  if (!vcfPath) {
    return (
      <div className="genome-browser-empty">
        <p>Load a VCF file to view the genome browser</p>
      </div>
    );
  }

  return (
    <div className="genome-browser">
      <div className="browser-controls">
        <div className="control-group">
          <label>Chromosome:</label>
          <select
            value={currentChromosome}
            onChange={(e) => {
              setCurrentChromosome(e.target.value);
              setViewStart(0);
              setViewEnd(CHROMOSOME_SIZES[e.target.value] || 100000000);
            }}
          >
            {CHROMOSOME_ORDER.filter(chr => 
              availableChromosomes.length === 0 || availableChromosomes.includes(chr)
            ).map(chr => (
              <option key={chr} value={chr}>{chr}</option>
            ))}
          </select>
        </div>

        <div className="control-group">
          <label>Zoom:</label>
          <div className="zoom-buttons">
            <button
              className={zoomLevel === 'chromosome' ? 'active' : ''}
              onClick={() => handleZoom('chromosome')}
            >
              Chromosome
            </button>
            <button
              className={zoomLevel === '1mb' ? 'active' : ''}
              onClick={() => handleZoom('1mb')}
            >
              1Mb
            </button>
            <button
              className={zoomLevel === '100kb' ? 'active' : ''}
              onClick={() => handleZoom('100kb')}
            >
              100kb
            </button>
            <button
              className={zoomLevel === '10kb' ? 'active' : ''}
              onClick={() => handleZoom('10kb')}
            >
              10kb
            </button>
            <button
              className={zoomLevel === 'region' ? 'active' : ''}
              onClick={() => handleZoom('region')}
            >
              Region
            </button>
          </div>
        </div>

        <div className="control-group">
          <button onClick={() => handlePan('left')}>← Pan Left</button>
          <button onClick={() => handlePan('right')}>Pan Right →</button>
        </div>

        <div className="control-group">
          <span className="view-range">
            {formatPosition(viewStart)} - {formatPosition(viewEnd)} 
            ({formatPosition(viewEnd - viewStart)} view)
          </span>
        </div>
      </div>

      {loading && (
        <div className="browser-loading">
          <div className="spinner"></div>
          <p>Loading regions...</p>
        </div>
      )}

      <div className="browser-content">
        {renderChromosomeOverview()}
        {renderMainView()}
      </div>

      <div className="browser-legend">
        <div className="legend-item">
          <div className="legend-color" style={{ background: '#4a90e2' }}></div>
          <span>Region</span>
        </div>
        <div className="legend-item">
          <div className="legend-color" style={{ background: '#ff6b6b' }}></div>
          <span>Selected</span>
        </div>
        <div className="legend-item">
          <div className="legend-color" style={{ background: '#ffd700' }}></div>
          <span>Bookmarked</span>
        </div>
        <div className="legend-item">
          <div className="legend-color" style={{ background: '#ff0000' }}></div>
          <span>Pathogenic</span>
        </div>
      </div>
    </div>
  );
};

export default GenomeBrowser;
