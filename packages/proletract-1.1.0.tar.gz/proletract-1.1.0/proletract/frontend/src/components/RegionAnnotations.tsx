import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import './RegionAnnotations.css';

const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8502';

interface Annotation {
  id: string;
  region: string;
  tags: string[];
  note: string;
  createdAt: number;
  updatedAt: number;
}

interface RegionAnnotationsProps {
  region: string;
  vcfPath?: string;
  onAnnotationChange?: (hasAnnotations: boolean) => void;
}

const PREDEFINED_TAGS = [
  'Interesting',
  'Follow-up',
  'Pathogenic',
  'Benign',
  'Uncertain',
  'Reviewed',
  'High Priority',
  'Low Priority'
];

const RegionAnnotations: React.FC<RegionAnnotationsProps> = ({
  region,
  vcfPath,
  onAnnotationChange
}) => {
  const [annotation, setAnnotation] = useState<Annotation | null>(null);
  const [tags, setTags] = useState<string[]>([]);
  const [note, setNote] = useState<string>('');
  const [customTag, setCustomTag] = useState<string>('');
  const [isEditing, setIsEditing] = useState(false);
  const [showTagInput, setShowTagInput] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const noteTextareaRef = useRef<HTMLTextAreaElement>(null);

  // Load annotation on mount or when region changes
  useEffect(() => {
    if (!region) {
      setAnnotation(null);
      setTags([]);
      setNote('');
      return;
    }

    const loadAnnotation = async () => {
      setLoading(true);
      setError(null);

      try {
        // Try to load from backend first
        try {
          const response = await axios.get(`${API_BASE}/api/annotations/region/${encodeURIComponent(region)}`);
          if (response.data.success && response.data.annotation) {
            const ann = response.data.annotation;
            setAnnotation(ann);
            setTags(ann.tags || []);
            setNote(ann.note || '');
            if (onAnnotationChange) {
              onAnnotationChange(true);
            }
            return;
          }
        } catch (err: any) {
          // Backend not available or no annotation, try localStorage
          if (err.response?.status !== 404) {
            console.debug('Backend annotation endpoint not available, using localStorage');
          }
        }

        // Fallback to localStorage
        const stored = localStorage.getItem(`annotation_${region}`);
        if (stored) {
          const ann = JSON.parse(stored) as Annotation;
          setAnnotation(ann);
          setTags(ann.tags || []);
          setNote(ann.note || '');
          if (onAnnotationChange) {
            onAnnotationChange(true);
          }
        } else {
          setAnnotation(null);
          setTags([]);
          setNote('');
          if (onAnnotationChange) {
            onAnnotationChange(false);
          }
        }
      } catch (err: any) {
        setError('Failed to load annotation');
        console.error('Error loading annotation:', err);
      } finally {
        setLoading(false);
      }
    };

    loadAnnotation();
  }, [region, onAnnotationChange]);

  // Save annotation
  const saveAnnotation = async () => {
    if (!region) return;

    setLoading(true);
    setError(null);

    const now = Date.now();
    const newAnnotation: Annotation = {
      id: annotation?.id || `${region}_${now}`,
      region,
      tags: tags.filter(t => t.trim().length > 0),
      note: note.trim(),
      createdAt: annotation?.createdAt || now,
      updatedAt: now
    };

    try {
      // Try to save to backend first
      try {
        await axios.post(`${API_BASE}/api/annotations`, {
          annotation: newAnnotation
        });
      } catch (err: any) {
        // Backend not available, save to localStorage
        if (err.response?.status !== 404) {
          console.debug('Backend annotation endpoint not available, saving to localStorage');
        }
        localStorage.setItem(`annotation_${region}`, JSON.stringify(newAnnotation));
      }

      setAnnotation(newAnnotation);
      setIsEditing(false);
      if (onAnnotationChange) {
        onAnnotationChange(newAnnotation.note.length > 0 || newAnnotation.tags.length > 0);
      }
    } catch (err: any) {
      setError('Failed to save annotation');
      console.error('Error saving annotation:', err);
    } finally {
      setLoading(false);
    }
  };

  // Delete annotation
  const deleteAnnotation = async () => {
    if (!region || !annotation) return;

    if (!window.confirm('Are you sure you want to delete this annotation?')) {
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Try to delete from backend
      try {
        await axios.delete(`${API_BASE}/api/annotations/region/${encodeURIComponent(region)}`);
      } catch (err: any) {
        // Backend not available, delete from localStorage
        if (err.response?.status !== 404) {
          console.debug('Backend annotation endpoint not available, deleting from localStorage');
        }
        localStorage.removeItem(`annotation_${region}`);
      }

      setAnnotation(null);
      setTags([]);
      setNote('');
      setIsEditing(false);
      if (onAnnotationChange) {
        onAnnotationChange(false);
      }
    } catch (err: any) {
      setError('Failed to delete annotation');
      console.error('Error deleting annotation:', err);
    } finally {
      setLoading(false);
    }
  };

  // Toggle tag
  const toggleTag = (tag: string) => {
    if (tags.includes(tag)) {
      setTags(tags.filter(t => t !== tag));
    } else {
      setTags([...tags, tag]);
    }
  };

  // Add custom tag
  const addCustomTag = () => {
    const trimmed = customTag.trim();
    if (trimmed && !tags.includes(trimmed)) {
      setTags([...tags, trimmed]);
      setCustomTag('');
      setShowTagInput(false);
    }
  };

  // Remove tag
  const removeTag = (tag: string) => {
    setTags(tags.filter(t => t !== tag));
  };

  // Start editing
  const startEditing = () => {
    setIsEditing(true);
    setTimeout(() => {
      noteTextareaRef.current?.focus();
    }, 100);
  };

  // Cancel editing
  const cancelEditing = () => {
    if (annotation) {
      setTags(annotation.tags || []);
      setNote(annotation.note || '');
    } else {
      setTags([]);
      setNote('');
    }
    setIsEditing(false);
    setShowTagInput(false);
    setCustomTag('');
  };

  if (loading && !annotation) {
    return <div className="region-annotations-loading">Loading annotations...</div>;
  }

  const hasAnnotation = annotation && (annotation.note.length > 0 || annotation.tags.length > 0);

  return (
    <div className="region-annotations">
      <div className="region-annotations-header">
        <h3 className="region-annotations-title">
          <span className="annotation-icon">📝</span>
          Annotations
        </h3>
        {!isEditing && (
          <div className="region-annotations-actions">
            {hasAnnotation && (
              <button
                className="annotation-btn annotation-btn-danger"
                onClick={deleteAnnotation}
                title="Delete annotation"
              >
                🗑️ Delete
              </button>
            )}
            <button
              className="annotation-btn annotation-btn-primary"
              onClick={startEditing}
              title={hasAnnotation ? 'Edit annotation' : 'Add annotation'}
            >
              {hasAnnotation ? '✏️ Edit' : '+ Add Note'}
            </button>
          </div>
        )}
      </div>

      {error && (
        <div className="region-annotations-error">
          {error}
        </div>
      )}

      {isEditing ? (
        <div className="region-annotations-editor">
          {/* Tags Section */}
          <div className="annotation-tags-section">
            <label className="annotation-label">Tags</label>
            <div className="annotation-tags-container">
              {tags.map(tag => (
                <span key={tag} className="annotation-tag annotation-tag-selected">
                  {tag}
                  <button
                    className="annotation-tag-remove"
                    onClick={() => removeTag(tag)}
                    title="Remove tag"
                  >
                    ×
                  </button>
                </span>
              ))}
              {showTagInput ? (
                <div className="annotation-tag-input-wrapper">
                  <input
                    type="text"
                    className="annotation-tag-input"
                    value={customTag}
                    onChange={(e) => setCustomTag(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addCustomTag();
                      } else if (e.key === 'Escape') {
                        setShowTagInput(false);
                        setCustomTag('');
                      }
                    }}
                    onBlur={() => {
                      if (customTag.trim()) {
                        addCustomTag();
                      } else {
                        setShowTagInput(false);
                      }
                    }}
                    placeholder="Custom tag"
                    autoFocus
                  />
                </div>
              ) : (
                <button
                  className="annotation-tag-add"
                  onClick={() => setShowTagInput(true)}
                  title="Add custom tag"
                >
                  + Custom
                </button>
              )}
            </div>

            {/* Predefined Tags */}
            <div className="annotation-predefined-tags">
              {PREDEFINED_TAGS.map(tag => (
                <button
                  key={tag}
                  className={`annotation-tag-btn ${tags.includes(tag) ? 'selected' : ''}`}
                  onClick={() => toggleTag(tag)}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          {/* Note Section */}
          <div className="annotation-note-section">
            <label className="annotation-label" htmlFor="annotation-note">
              Notes
            </label>
            <textarea
              id="annotation-note"
              ref={noteTextareaRef}
              className="annotation-note-textarea"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Add your notes about this region (supports markdown)..."
              rows={6}
            />
            <div className="annotation-note-hint">
              Markdown supported: **bold**, *italic*, `code`, [links](url)
            </div>
          </div>

          {/* Editor Actions */}
          <div className="annotation-editor-actions">
            <button
              className="annotation-btn annotation-btn-secondary"
              onClick={cancelEditing}
              disabled={loading}
            >
              Cancel
            </button>
            <button
              className="annotation-btn annotation-btn-primary"
              onClick={saveAnnotation}
              disabled={loading}
            >
              {loading ? 'Saving...' : 'Save'}
            </button>
          </div>
        </div>
      ) : (
        <div className="region-annotations-display">
          {hasAnnotation ? (
            <>
              {annotation.tags && annotation.tags.length > 0 && (
                <div className="annotation-tags-display">
                  {annotation.tags.map(tag => (
                    <span key={tag} className="annotation-tag">
                      {tag}
                    </span>
                  ))}
                </div>
              )}
              {annotation.note && (
                <div className="annotation-note-display">
                  <div className="annotation-note-content">
                    {annotation.note.split('\n').map((line, idx) => (
                      <div key={idx}>{line || '\u00A0'}</div>
                    ))}
                  </div>
                  <div className="annotation-note-meta">
                    Last updated: {new Date(annotation.updatedAt).toLocaleString()}
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="region-annotations-empty">
              No annotations yet. Click "Add Note" to add tags and notes about this region.
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default RegionAnnotations;
