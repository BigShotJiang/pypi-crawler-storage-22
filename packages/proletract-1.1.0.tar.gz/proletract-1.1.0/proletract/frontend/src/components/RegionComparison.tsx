import React, { useState, useEffect, useRef, useMemo } from 'react';
import axios from 'axios';
import './RegionComparison.css';
import RegionVisualization from './RegionVisualization';

const REGION_PATTERN = /^[^:]+:\d+-\d+$/;
const DEBOUNCE_MS = 500;

function isValidRegion(s: string): boolean {
  return Boolean(s && REGION_PATTERN.test(s.trim()));
}

const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8502';

interface Record {
  chr: string;
  pos: number;
  stop: number;
  motifs: string[];
  motif_ids_h1: string[];
  motif_ids_h2: string[];
  motif_ids_ref: string[];
  ref_CN: number | null;
  CN_H1: string | null;
  CN_H2: string | null;
  spans: string[];
  ref_allele: string;
  alt_allele1: string;
  alt_allele2: string;
  gt: string;
  supported_reads_h1: number;
  supported_reads_h2: number;
  id: string;
}

interface RegionComparisonProps {
  regions: string[];
  vcfPath: string;
  publicVcfFolder?: string;
  onRegionSelect?: (region: string) => void;
}

interface RegionData {
  region: string;
  record: Record | null;
  loading: boolean;
  error: string | null;
}

const RegionComparison: React.FC<RegionComparisonProps> = ({
  regions,
  vcfPath,
  publicVcfFolder,
  onRegionSelect,
}) => {
  const [regionData, setRegionData] = useState<Map<string, RegionData>>(new Map());
  const [synchronized, setSynchronized] = useState(true);
  const [comparisonLayout, setComparisonLayout] = useState<2 | 3 | 4>(2);
  const [selectedRegions, setSelectedRegions] = useState<string[]>(() => {
    const base = regions.slice(0, comparisonLayout);
    const arr = base.slice();
    while (arr.length < comparisonLayout) arr.push('');
    return arr;
  });
  const [debouncedRegions, setDebouncedRegions] = useState<string[]>(() => {
    const base = regions.slice(0, comparisonLayout);
    const arr = base.slice();
    while (arr.length < comparisonLayout) arr.push('');
    return arr;
  });
  const [availableRegions, setAvailableRegions] = useState<string[]>([]);
  const scrollPositionsRef = useRef<Map<string, number>>(new Map());

  // Fetch available regions for autocomplete
  useEffect(() => {
    if (!vcfPath) {
      setAvailableRegions([]);
      return;
    }

    const fetchRegions = async () => {
      try {
        const response = await axios.get(`${API_BASE}/api/vcf/regions`, {
          params: { vcf_path: vcfPath, page: 0, page_size: 300 }
        });
        setAvailableRegions(response.data.regions || []);
      } catch (err) {
        console.error('Failed to fetch regions for autocomplete:', err);
      }
    };

    fetchRegions();
  }, [vcfPath]);

  // Update selected regions when layout changes
  useEffect(() => {
    const current = selectedRegions.filter(r => r).slice(0, comparisonLayout);
    while (current.length < comparisonLayout) {
      current.push('');
    }
    const next = current.slice(0, comparisonLayout);
    setSelectedRegions(next);
    setDebouncedRegions(next);
  }, [comparisonLayout]);

  // Debounce selected regions so we only fetch after user stops typing
  useEffect(() => {
    const t = setTimeout(() => setDebouncedRegions(selectedRegions.slice()), DEBOUNCE_MS);
    return () => clearTimeout(t);
  }, [selectedRegions]);

  // Fetch data only for valid, debounced regions (avoids fetch storm on every keystroke)
  useEffect(() => {
    if (!vcfPath) return;

    debouncedRegions.forEach(region => {
      const trimmed = region?.trim() || '';
      if (!trimmed || !isValidRegion(trimmed)) return;

      const fetchRegion = async () => {
        setRegionData(prev => {
          const newMap = new Map(prev);
          newMap.set(trimmed, { region: trimmed, record: null, loading: true, error: null });
          return newMap;
        });

        try {
          const response = await axios.get(`${API_BASE}/api/vcf/region/${encodeURIComponent(trimmed)}`, {
            params: { vcf_path: vcfPath }
          });

          setRegionData(prev => {
            const newMap = new Map(prev);
            newMap.set(trimmed, {
              region: trimmed,
              record: response.data.record,
              loading: false,
              error: null
            });
            return newMap;
          });
        } catch (error: any) {
          setRegionData(prev => {
            const newMap = new Map(prev);
            newMap.set(trimmed, {
              region: trimmed,
              record: null,
              loading: false,
              error: error.response?.data?.detail || error.message
            });
            return newMap;
          });
        }
      };

      fetchRegion();
    });
  }, [debouncedRegions, vcfPath]);

  // Synchronized scrolling
  useEffect(() => {
    if (!synchronized) return;

    const handleScroll = (sourceRegion: string, scrollTop: number) => {
      scrollPositionsRef.current.set(sourceRegion, scrollTop);
      
      selectedRegions.forEach(region => {
        if (region !== sourceRegion && region) {
          const element = document.getElementById(`comparison-view-${region}`);
          if (element) {
            element.scrollTop = scrollTop;
          }
        }
      });
    };

    // This will be called by child components via scroll sync
    return () => {
      // Cleanup if needed
    };
  }, [synchronized, selectedRegions]);

  const handleRegionChange = (index: number, newRegion: string) => {
    const updated = [...selectedRegions];
    updated[index] = newRegion;
    setSelectedRegions(updated);
  };

  const calculateDifferences = () => {
    const records = debouncedRegions
      .map(r => regionData.get((r || '').trim())?.record)
      .filter((r): r is Record => r !== null && r !== undefined);

    if (records.length < 2) return null;

    const differences: {
      type: 'motif_count' | 'cn' | 'genotype' | 'length';
      field: string;
      values: { region: string; value: any }[];
    }[] = [];

    // Compare motif counts
    const motifCounts = records.map(r => ({
      region: `${r.chr}:${r.pos}-${r.stop}`,
      h1: r.motif_ids_h1?.filter(id => id && id !== '.' && id !== '').length || 0,
      h2: r.motif_ids_h2?.filter(id => id && id !== '.' && id !== '').length || 0,
      ref: r.motif_ids_ref?.filter(id => id && id !== '.' && id !== '').length || 0
    }));

    const uniqueMotifCounts = new Set(motifCounts.flatMap(m => [m.h1, m.h2, m.ref]));
    if (uniqueMotifCounts.size > 1) {
      differences.push({
        type: 'motif_count',
        field: 'Motif Count',
        values: motifCounts.map((m, i) => ({
          region: records[i].id,
          value: `H1: ${m.h1}, H2: ${m.h2}, Ref: ${m.ref}`
        }))
      });
    }

    // Compare copy numbers
    const cnValues = records.map(r => ({
      region: `${r.chr}:${r.pos}-${r.stop}`,
      cn_h1: r.CN_H1,
      cn_h2: r.CN_H2,
      cn_ref: r.ref_CN
    }));

    const uniqueCN = new Set(cnValues.flatMap(c => [c.cn_h1, c.cn_h2, c.cn_ref].filter(v => v !== null)));
    if (uniqueCN.size > 1) {
      differences.push({
        type: 'cn',
        field: 'Copy Number',
        values: cnValues.map((c, i) => ({
          region: records[i].id,
          value: `H1: ${c.cn_h1 || 'N/A'}, H2: ${c.cn_h2 || 'N/A'}, Ref: ${c.cn_ref || 'N/A'}`
        }))
      });
    }

    // Compare genotypes
    const genotypes = records.map(r => ({ region: r.id, value: r.gt }));
    const uniqueGT = new Set(genotypes.map(g => g.value));
    if (uniqueGT.size > 1) {
      differences.push({
        type: 'genotype',
        field: 'Genotype',
        values: genotypes
      });
    }

    // Compare sequence lengths
    const lengths = records.map(r => ({
      region: r.id,
      ref_length: r.ref_allele?.length || 0,
      alt1_length: r.alt_allele1?.length || 0,
      alt2_length: r.alt_allele2?.length || 0
    }));

    const uniqueLengths = new Set(lengths.flatMap(l => [l.ref_length, l.alt1_length, l.alt2_length]));
    if (uniqueLengths.size > 1) {
      differences.push({
        type: 'length',
        field: 'Sequence Length',
        values: lengths.map((l, i) => ({
          region: records[i].id,
          value: `Ref: ${l.ref_length}, Alt1: ${l.alt1_length}, Alt2: ${l.alt2_length}`
        }))
      });
    }

    return differences;
  };

  const differences = useMemo(() => calculateDifferences(), [regionData, debouncedRegions]);
  const gridColumns = comparisonLayout === 2 ? '1fr 1fr' : comparisonLayout === 3 ? '1fr 1fr 1fr' : '1fr 1fr';

  return (
    <div className="region-comparison">
      <div className="comparison-controls">
        <div className="control-group">
          <label>Layout:</label>
          <div className="layout-buttons">
            <button
              className={comparisonLayout === 2 ? 'active' : ''}
              onClick={() => setComparisonLayout(2)}
            >
              2 Regions
            </button>
            <button
              className={comparisonLayout === 3 ? 'active' : ''}
              onClick={() => setComparisonLayout(3)}
            >
              3 Regions
            </button>
            <button
              className={comparisonLayout === 4 ? 'active' : ''}
              onClick={() => setComparisonLayout(4)}
            >
              4 Regions
            </button>
          </div>
        </div>
        <div className="control-group">
          <label>
            <input
              type="checkbox"
              checked={synchronized}
              onChange={(e) => setSynchronized(e.target.checked)}
            />
            Synchronized Navigation
          </label>
        </div>
        {differences && differences.length > 0 && (
          <div className="control-group">
            <button
              className="export-button"
              onClick={() => {
                const data = {
                  regions: selectedRegions.filter(r => r),
                  differences,
                  timestamp: new Date().toISOString()
                };
                const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `region-comparison-${Date.now()}.json`;
                a.click();
                URL.revokeObjectURL(url);
              }}
            >
              📥 Export Comparison
            </button>
          </div>
        )}
      </div>

      {differences && differences.length > 0 && (
        <div className="differences-panel">
          <h3>🔍 Detected Differences</h3>
          {differences.map((diff, idx) => (
            <div key={idx} className="difference-item">
              <span className="difference-type">{diff.field}:</span>
              <div className="difference-values">
                {diff.values.map((v, vIdx) => (
                  <div key={vIdx} className="difference-value">
                    <strong>{v.region}:</strong> {v.value}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <div
        className="comparison-grid"
        style={{
          gridTemplateColumns: comparisonLayout === 4 ? '1fr 1fr' : comparisonLayout === 3 ? '1fr 1fr 1fr' : '1fr 1fr',
          gridTemplateRows: comparisonLayout === 4 ? '1fr 1fr' : '1fr'
        }}
      >
        {Array.from({ length: comparisonLayout }).map((_, index) => {
          const region = selectedRegions[index] || '';
          const dataKey = region.trim();
          const data = dataKey ? regionData.get(dataKey) : null;

          return (
            <div key={index} className="comparison-cell">
              <div className="comparison-cell-header">
                <input
                  type="text"
                  className="region-selector"
                  placeholder={`Region ${index + 1} (e.g., chr1:1000-2000)`}
                  value={region}
                  onChange={(e) => handleRegionChange(index, e.target.value)}
                  list={`regions-list-${index}`}
                />
                <datalist id={`regions-list-${index}`}>
                  {availableRegions.map((r) => (
                    <option key={r} value={r} />
                  ))}
                </datalist>
                {data?.loading && <span className="loading-indicator">⏳</span>}
                {data?.error && <span className="error-indicator" title={data.error}>⚠️</span>}
              </div>
              <div
                id={`comparison-view-${dataKey || region}`}
                className={`comparison-view ${synchronized ? 'synchronized' : ''}`}
              >
                {region ? (
                  data?.record ? (
                    <RegionVisualization
                      region={dataKey}
                      vcfPath={vcfPath}
                      publicVcfFolder={publicVcfFolder}
                      onRegionSelect={onRegionSelect}
                    />
                  ) : data?.loading ? (
                    <div className="comparison-loading">
                      <div className="spinner"></div>
                      <p>Loading region...</p>
                    </div>
                  ) : (
                    <div className="comparison-error">
                      <p>Error loading region</p>
                      {data?.error && <p className="error-detail">{data.error}</p>}
                    </div>
                  )
                ) : (
                  <div className="comparison-empty">
                    <p>Select a region to compare</p>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RegionComparison;
