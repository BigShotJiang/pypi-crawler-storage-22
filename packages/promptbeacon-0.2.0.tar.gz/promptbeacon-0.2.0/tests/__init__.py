"""Tests for PromptBeacon."""
