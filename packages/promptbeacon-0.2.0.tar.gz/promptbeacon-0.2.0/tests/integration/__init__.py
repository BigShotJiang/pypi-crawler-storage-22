"""Integration tests for PromptBeacon."""
