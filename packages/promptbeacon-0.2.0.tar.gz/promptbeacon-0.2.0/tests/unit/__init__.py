"""Unit tests for PromptBeacon."""
