# PromptBridge

AI CLI 도구를 위한 프롬프트 최적화 SaaS 서비스

---

## 서비스 구조

```
┌──────────────────────────────────────────────────────────────┐
│                        고객 환경                              │
│  ┌────────────────────────────────────────────────────────┐  │
│  │  pip install promptbridge                              │  │
│  │                                                        │  │
│  │  $ pb claude                                           │  │
│  │  [PromptBridge]> !login                                │  │
│  │  [PromptBridge]> !opt 게시판 만들어줘                    │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────┬───────────────────────────────┘
                               │
                               ▼
┌──────────────────────────────────────────────────────────────┐
│              promptbridge.store-art.com (서버)                │
│  ┌────────────────────────────────────────────────────────┐  │
│  │  웹사이트                                               │  │
│  │  • 회원가입 / 로그인                                     │  │
│  │  • 크레딧 충전                                          │  │
│  │  • 사용량 확인                                          │  │
│  └────────────────────────────────────────────────────────┘  │
│  ┌────────────────────────────────────────────────────────┐  │
│  │  API 서버                                               │  │
│  │  • 인증 처리                                            │  │
│  │  • 프롬프트 최적화 (OpenAI API 호출)                     │  │
│  │  • 크레딧 차감                                          │  │
│  └────────────────────────────────────────────────────────┘  │
│                               │                              │
│                               ▼                              │
│  ┌────────────────────────────────────────────────────────┐  │
│  │  MariaDB + OpenAI API                                   │  │
│  │  (사용자 데이터 + AI 최적화)                              │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

---

## 운영자 가이드 (당신이 해야 할 것)

### 1. 서버 배포

**필요 파일:**
```
server/           # 전체 업로드
scripts/          # 전체 업로드
requirements.txt
.env              # 아래 설정으로 생성
```

**서버 환경 설정 (.env):**
```bash
# 서버
PB_HOST=0.0.0.0
PB_PORT=8000

# 데이터베이스
PB_DB_HOST=your-db-host
PB_DB_PORT=3306
PB_DB_USER=promptbridge
PB_DB_PASSWORD=강력한비밀번호

# JWT (필수! 아래 명령으로 생성)
# openssl rand -hex 32
PB_JWT_SECRET=생성된64자문자열

# CORS
PB_CORS_ORIGINS=https://promptbridge.store-art.com

# OpenAI API (당신의 키)
OPENAI_API_KEY=sk-your-api-key
```

**서버 실행:**
```bash
# 의존성 설치
pip install -r requirements.txt

# 서버 시작 (개발)
python scripts/run_server.py

# 서버 시작 (프로덕션)
gunicorn server.app:app -w 4 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:8000

# 어드민 계정 생성
python scripts/create_admin.py
```

### 2. 웹사이트 접속

- **메인**: https://promptbridge.store-art.com
- **어드민**: https://promptbridge.store-art.com/admin

어드민에서 할 수 있는 것:
- 사용자 목록 조회
- 크레딧 충전
- 가격 설정 변경
- 사용량 모니터링

### 3. CLI 패키지 배포

```bash
# 빌드
pip install build
python -m build

# PyPI 업로드
pip install twine
twine upload dist/*
```

---

## 고객 가이드 (고객이 해야 할 것)

### 1. 회원가입

https://promptbridge.store-art.com 에서 회원가입

### 2. CLI 설치

```bash
pip install promptbridge
```

### 3. 환경 설정

```bash
# ~/.zshrc 또는 ~/.bashrc에 추가
export PB_SERVER_URL=https://promptbridge.store-art.com
```

### 4. 사용

```bash
# CLI 실행
pb claude    # 또는 pb gemini, pb opencode

# 로그인
[PromptBridge]> !login

# 프롬프트 최적화
[PromptBridge]> !opt 노드js로 게시판 만들어줘

# 잔액 확인
[PromptBridge]> !status
```

---

## 명령어 목록

| 명령어 | 설명 |
|--------|------|
| `!login` | 로그인 |
| `!logout` | 로그아웃 |
| `!status` | 크레딧 잔액 확인 |
| `!opt <프롬프트>` | 프롬프트 최적화 후 전송 |
| `!clear` | 화면 클리어 |
| `!help` | 도움말 |
| `!quit` | 종료 |

---

## 가격 정책 (어드민에서 수정 가능)

| 토큰 타입 | 기본 가격 (1M 토큰당) |
|----------|---------------------|
| Input | 0.05 크레딧 |
| Cached Input | 0.005 크레딧 |
| Output | 0.40 크레딧 |

---

## 보안 체크리스트

- [x] OpenAI API 키 서버에서만 사용 (고객에게 노출 안됨)
- [x] SSL 인증서 검증
- [x] CORS 도메인 제한
- [x] JWT 시크릿 필수
- [x] 비밀번호 bcrypt 해싱
- [ ] HTTPS (Nginx/Caddy로 설정 필요)
- [ ] Rate Limiting (Nginx에서 설정 권장)
