# PromptBridge

Use AI CLI tools more smartly.

PromptBridge is a prompt optimization wrapper for AI coding assistants like Claude Code, Gemini CLI, and OpenCode. It automatically transforms simple requests into detailed prompts that AI can understand better.

## Features

- **Prompt Optimization**: Expand short requests into specific instructions
- **Multi-CLI Support**: Works with Claude Code, Gemini CLI, OpenCode
- **Seamless Integration**: Naturally integrates into your existing CLI workflow
- **Credit-Based**: Pay only for what you use

## Installation

```bash
pip install promptbridge
```

## Quick Start

```bash
# 1. Launch CLI
pb claude

# 2. Login
[PromptBridge]> !login

# 3. Use prompt optimization
[PromptBridge]> !opt create a login page
```

**Before (Original):**
```
create a login page
```

**After (Optimized):**
```
Please implement a login page using React and TypeScript.

Requirements:
- Email and password input fields
- Form validation (email format, password min 8 characters)
- Loading state display
- Error message handling
- Responsive design
...
```

## Supported CLIs

| CLI | Command |
|-----|---------|
| Claude Code | `pb claude` |
| Gemini CLI | `pb gemini` |
| OpenCode | `pb opencode` |

## Commands

| Command | Description |
|---------|-------------|
| `!login` | Login to your account |
| `!logout` | Logout |
| `!status` | Check credit balance |
| `!opt <prompt>` | Optimize prompt and send to CLI |
| `!help` | Show help |
| `!quit` | Exit |

## Requirements

- Python 3.9+
- At least one supported CLI installed

## Sign Up

Visit https://promptbridge.store-art.com to create an account.

## License

MIT License
