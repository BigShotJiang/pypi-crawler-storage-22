"""PromptBridge - CLI Wrapper with Prompt Optimization"""
__version__ = "1.0.0"
