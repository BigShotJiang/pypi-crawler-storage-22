"""
PromptEval SDK - Semantic Testing for LLMs

A Python SDK for testing LLM outputs using semantic similarity validation.

Quick Start:
    from prompteval import PromptEval
    
    client = PromptEval(api_key="pe_xxxxx")
    result = client.run_from_files("adapter.yml", "tests.yml")
    
    print(f"Success rate: {result.success_rate}%")

CLI Usage:
    prompteval run adapter.yml --tests tests.yml --api-key KEY
    prompteval validate tests.yml
    prompteval report results.json
"""

__version__ = "0.1.0"
__author__ = "PromptEval Team"

from .client import (
    PromptEval,
    EvalResult,
    TestResult,
    License,
    User,
    run_tests,
)

from .exceptions import (
    PromptEvalError,
    AuthenticationError,
    QuotaExceededError,
    RateLimitError,
    ValidationError,
    APIError,
    ConnectionError,
    TimeoutError,
)

__all__ = [
    # Main client
    "PromptEval",
    
    # Data classes
    "EvalResult",
    "TestResult",
    "License",
    "User",
    
    # Convenience functions
    "run_tests",
    
    # Exceptions
    "PromptEvalError",
    "AuthenticationError",
    "QuotaExceededError",
    "RateLimitError",
    "ValidationError",
    "APIError",
    "ConnectionError",
    "TimeoutError",
    
    # Version
    "__version__",
]
