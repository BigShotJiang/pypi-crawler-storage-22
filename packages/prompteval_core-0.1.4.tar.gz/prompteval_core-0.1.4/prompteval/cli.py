#!/usr/bin/env python3
"""
PromptEval CLI

Command line interface for PromptEval - Semantic Testing for LLMs.

Usage:
    prompteval run adapter.yml --tests tests.yml --api-key KEY
    prompteval validate tests.yml
    prompteval report results.json
"""

import sys
import os
import argparse
import json
from pathlib import Path
from datetime import datetime

try:
    import yaml
except ImportError:
    print("Error: PyYAML is required. Install with: pip install pyyaml")
    sys.exit(1)

from .client import PromptEval, EvalResult
from .exceptions import PromptEvalError


# =============================================================================
# COMMANDS
# =============================================================================

def run_command(args) -> int:
    """Execute evaluation tests"""
    
    api_key = args.api_key or os.environ.get("PROMPTEVAL_API_KEY")
    if not api_key:
        print("❌ API key required. Use --api-key or set PROMPTEVAL_API_KEY")
        return 1
    
    adapter_path = Path(args.adapter_file)
    if not adapter_path.exists():
        print(f"❌ Adapter file not found: {adapter_path}")
        return 1
    
    # Read adapter for name
    with open(adapter_path, "r", encoding="utf-8") as f:
        adapter_data = yaml.safe_load(f)
    
    print("🚀 Running evaluation...")
    print(f"   Adapter: {adapter_path}")
    if args.tests:
        print(f"   Tests: {args.tests}")
    
    try:
        client = PromptEval(
            api_key=api_key,
            base_url=args.api_url,
            timeout=args.timeout or 300
        )
        
        result = client.run_from_files(
            adapter_path=str(adapter_path),
            tests_path=args.tests,
            model=args.model or "gpt-4o"
        )
        
    except PromptEvalError as e:
        print(f"❌ Error: {e}")
        return 1
    
    # Display results
    _print_results(result)
    
    # Save results
    output_file = Path(args.output or "results.json")
    _save_results(result, output_file, adapter_data.get("name", "prompteval"))
    print(f"\n💾 Results saved: {output_file}")
    
    return 0 if result.success else 1


def validate_command(args) -> int:
    """Validate YAML file"""
    
    print(f"🔍 Validating: {args.file}")
    
    try:
        with open(args.file, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        
        if isinstance(data, list):
            tests = data
        elif isinstance(data, dict) and "tests" in data:
            tests = data["tests"]
        else:
            print("❌ Invalid format: must be list or {tests: []}")
            return 1
        
        # Validate each test
        errors = []
        for i, test in enumerate(tests):
            if not test.get("id") and not test.get("name"):
                errors.append(f"  Test {i+1}: missing 'id' or 'name'")
            if not test.get("expected"):
                errors.append(f"  Test {i+1}: missing 'expected'")
        
        if errors:
            print(f"❌ Validation errors:")
            for err in errors:
                print(err)
            return 1
        
        print(f"✅ Valid YAML - {len(tests)} test cases found")
        return 0
        
    except yaml.YAMLError as e:
        print(f"❌ Invalid YAML syntax: {e}")
        return 1
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1


def report_command(args) -> int:
    """Generate HTML report from results"""
    
    input_file = Path(args.input)
    if not input_file.exists():
        print(f"❌ File not found: {input_file}")
        return 1
    
    output_file = args.output or "test-report.html"
    
    print("📄 Generating HTML report...")
    
    try:
        with open(input_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        html = _generate_html_report(data)
        
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(html)
        
        print(f"✅ Report generated: {output_file}")
        return 0
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1


def licenses_command(args) -> int:
    """Show license information"""
    
    api_key = args.api_key or os.environ.get("PROMPTEVAL_API_KEY")
    if not api_key:
        print("❌ API key required")
        return 1
    
    try:
        client = PromptEval(api_key=api_key, base_url=args.api_url)
        licenses = client.get_licenses()
        
        print("\n📋 Your Licenses:")
        print("=" * 50)
        
        for lic in licenses:
            status = "✅ Active" if lic.is_active else "❌ Inactive"
            print(f"\n   ID: {lic.id}")
            print(f"   Plan: {lic.plan}")
            print(f"   Status: {status}")
            print(f"   Quota: {lic.tests_used_this_month}/{lic.max_tests_per_month} tests used")
            print(f"   Remaining: {lic.tests_remaining} tests")
        
        print("=" * 50)
        return 0
        
    except PromptEvalError as e:
        print(f"❌ Error: {e}")
        return 1


def status_command(args) -> int:
    """Show account status: quota, usage, API keys"""
    
    api_key = args.api_key or os.environ.get("PROMPTEVAL_API_KEY")
    if not api_key:
        print("❌ API key required")
        return 1
    
    try:
        client = PromptEval(api_key=api_key, base_url=args.api_url)
        licenses = client.get_licenses()
        
        print("\n" + "=" * 60)
        print("📊 PROMPTEVAL ACCOUNT STATUS")
        print("=" * 60)
        
        for lic in licenses:
            status_icon = "✅" if lic.is_active else "❌"
            
            # Progress bar for quota
            if lic.max_tests_per_month > 0:
                used_pct = min(100, (lic.tests_used_this_month / lic.max_tests_per_month) * 100)
                bar_filled = int(used_pct / 5)  # 20 chars total
                bar_empty = 20 - bar_filled
                progress_bar = "█" * bar_filled + "░" * bar_empty
            else:
                progress_bar = "░" * 20
                used_pct = 0
            
            print(f"\n   📦 License: {lic.id[:16]}...")
            print(f"   📋 Plan: {lic.plan.upper()}")
            print(f"   {status_icon} Status: {'Active' if lic.is_active else 'Inactive'}")
            print(f"\n   📈 Usage This Month:")
            print(f"      [{progress_bar}] {used_pct:.1f}%")
            print(f"      Tests used:      {lic.tests_used_this_month}")
            print(f"      Tests remaining: {lic.tests_remaining}")
            print(f"      Monthly limit:   {lic.max_tests_per_month}")
            
            # Get API keys count
            try:
                api_keys = client.get_api_keys(lic.id)
                active_keys = len([k for k in api_keys if k.get("is_active")])
                print(f"\n   🔑 API Keys: {active_keys} active")
            except Exception:
                pass
            
            # Get detailed usage
            try:
                usage = client.get_usage(lic.id)
                if usage.get("last_used"):
                    print(f"   🕐 Last used: {usage['last_used']}")
                if usage.get("api_keys_used"):
                    print(f"   🖥️  Machines used: {usage['api_keys_used']}")
            except Exception:
                pass
            
            if lic.expires_at:
                print(f"   ⏰ Expires: {lic.expires_at}")
        
        print("\n" + "=" * 60)
        
        # Summary
        total_remaining = sum(lic.tests_remaining for lic in licenses if lic.is_active)
        active_licenses = sum(1 for lic in licenses if lic.is_active)
        
        print(f"   💡 Total tests remaining: {total_remaining}")
        print(f"   📦 Active licenses: {active_licenses}")
        print("=" * 60 + "\n")
        
        return 0
        
    except PromptEvalError as e:
        print(f"❌ Error: {e}")
        return 1


# =============================================================================
# HELPERS
# =============================================================================

def _print_results(result: EvalResult) -> None:
    """Print evaluation results to console"""
    
    print("\n" + "=" * 50)
    print("📊 EVALUATION RESULTS")
    print("=" * 50)
    print(f"   Total tests:  {result.total_tests}")
    print(f"   ✅ Passed:    {result.total_passed}")
    print(f"   ❌ Failed:    {result.total_failed}")
    print(f"   ⚠️  Errors:    {result.total_errors}")
    print(f"   Success rate: {result.success_rate}%")
    print(f"   Duration:     {result.duration_ms:.2f}ms")
    print("=" * 50)
    
    # Show failed tests
    if result.failed_tests:
        print("\n❌ FAILED TESTS:")
        for t in result.failed_tests:
            print(f"\n   [{t.id_test}] {t.description}")
            if t.expected:
                print(f"   Expected: {t.expected[:80]}...")
            if t.actual:
                print(f"   Actual:   {t.actual[:80]}...")
            if t.similarity is not None:
                threshold = t.threshold or 0.75
                print(f"   Similarity: {t.similarity*100:.1f}% (threshold: {threshold*100:.0f}%)")
            if t.error:
                print(f"   Error: {t.error}")


def _save_results(result: EvalResult, output_file: Path, adapter_name: str) -> None:
    """Save results to JSON file in report-compatible format"""
    
    report_data = {
        "timestamp": datetime.utcnow().isoformat(),
        "adapter": adapter_name,
        "total_tests": result.total_tests,
        "total_passed": result.total_passed,
        "total_failed": result.total_failed,
        "total_errors": result.total_errors,
        "success_rate": result.success_rate,
        "total_duration_ms": result.duration_ms,
        "test_results": [
            {
                "test_case": {
                    "id_test": t.id_test,
                    "description": t.description,
                },
                "validation": {
                    "expected_result": t.expected or "",
                    "actual_result": t.actual or "",
                    "validation_method": t.validation_method,
                    "ml_validation": {
                        "similarity": t.similarity,
                        "threshold": t.threshold,
                    } if t.similarity is not None else None,
                },
                "duration_ms": t.duration_ms,
                "passed": t.passed,
                "failed": t.failed,
                "error": bool(t.error),
                "custom_fields": t.custom_fields,
            }
            for t in result.test_results
        ],
    }
    
    output_file.write_text(
        json.dumps(report_data, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )


def _generate_html_report(data: dict) -> str:
    """Generate HTML report from results data"""
    
    json_string = json.dumps(data, ensure_ascii=False, indent=2)
    json_string = (json_string
                   .replace('<', '\\u003c')
                   .replace('>', '\\u003e')
                   .replace('&', '\\u0026'))
    
    return f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PromptEval - Test Report</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f5f5;
            color: #333;
            line-height: 1.6;
            padding: 2rem;
        }}
        .container {{ max-width: 1000px; margin: 0 auto; }}
        .header {{
            background: white;
            padding: 2rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        h1 {{ font-size: 1.8rem; margin-bottom: 0.5rem; }}
        .subtitle {{ color: #666; }}
        .stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }}
        .stat {{
            background: white;
            padding: 1.5rem;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .stat-value {{ font-size: 2rem; font-weight: bold; }}
        .stat-value.success {{ color: #10b981; }}
        .stat-value.error {{ color: #ef4444; }}
        .stat-label {{ color: #666; font-size: 0.875rem; }}
        .tests {{
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .test {{
            padding: 1rem 1.5rem;
            border-bottom: 1px solid #eee;
            cursor: pointer;
        }}
        .test:hover {{ background: #f9f9f9; }}
        .test-header {{ display: flex; justify-content: space-between; align-items: center; }}
        .test-id {{ font-family: monospace; font-weight: 600; }}
        .badge {{
            padding: 0.25rem 0.75rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 600;
        }}
        .badge-pass {{ background: #d1fae5; color: #065f46; }}
        .badge-fail {{ background: #fee2e2; color: #991b1b; }}
        .test-desc {{ color: #666; margin-top: 0.25rem; }}
        .test-details {{
            display: none;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #eee;
            font-size: 0.875rem;
        }}
        .test.expanded .test-details {{ display: block; }}
        .detail {{ margin-bottom: 0.5rem; }}
        .detail-label {{ color: #666; }}
        .detail-value {{
            font-family: monospace;
            background: #f5f5f5;
            padding: 0.5rem;
            border-radius: 4px;
            margin-top: 0.25rem;
            word-break: break-word;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🧪 PromptEval Test Report</h1>
            <div class="subtitle" id="info"></div>
        </div>
        <div class="stats" id="stats"></div>
        <div class="tests" id="tests"></div>
    </div>
    <script>
        const data = {json_string};
        
        document.getElementById('info').innerHTML = 
            `Adapter: ${{data.adapter}} | Generated: ${{new Date(data.timestamp).toLocaleString()}}`;
        
        document.getElementById('stats').innerHTML = `
            <div class="stat">
                <div class="stat-value">${{data.total_tests}}</div>
                <div class="stat-label">Total Tests</div>
            </div>
            <div class="stat">
                <div class="stat-value success">${{data.total_passed}}</div>
                <div class="stat-label">Passed</div>
            </div>
            <div class="stat">
                <div class="stat-value error">${{data.total_failed}}</div>
                <div class="stat-label">Failed</div>
            </div>
            <div class="stat">
                <div class="stat-value">${{data.success_rate}}%</div>
                <div class="stat-label">Success Rate</div>
            </div>
            <div class="stat">
                <div class="stat-value">${{(data.total_duration_ms/1000).toFixed(2)}}s</div>
                <div class="stat-label">Duration</div>
            </div>
        `;
        
        const testsHtml = data.test_results.map(t => `
            <div class="test" onclick="this.classList.toggle('expanded')">
                <div class="test-header">
                    <span class="test-id">${{t.test_case.id_test}}</span>
                    <span class="badge ${{t.passed ? 'badge-pass' : 'badge-fail'}}">
                        ${{t.passed ? 'PASS' : 'FAIL'}}
                    </span>
                </div>
                <div class="test-desc">${{t.test_case.description}}</div>
                <div class="test-details">
                    <div class="detail">
                        <div class="detail-label">Expected:</div>
                        <div class="detail-value">${{t.validation.expected_result || 'N/A'}}</div>
                    </div>
                    <div class="detail">
                        <div class="detail-label">Actual:</div>
                        <div class="detail-value">${{t.validation.actual_result || 'N/A'}}</div>
                    </div>
                    ${{t.validation.ml_validation ? `
                        <div class="detail">
                            <div class="detail-label">Similarity: ${{(t.validation.ml_validation.similarity * 100).toFixed(1)}}%</div>
                        </div>
                    ` : ''}}
                    <div class="detail">
                        <div class="detail-label">Duration: ${{t.duration_ms.toFixed(0)}}ms</div>
                    </div>
                </div>
            </div>
        `).join('');
        
        document.getElementById('tests').innerHTML = testsHtml;
    </script>
</body>
</html>'''


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        prog="prompteval",
        description="PromptEval - Semantic Testing for LLMs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  prompteval run adapter.yml --tests tests.yml -k $API_KEY
  prompteval run adapter.yml -t tests.yml -k $API_KEY -u http://localhost:8000
  prompteval validate tests.yml
  prompteval report results.json -o report.html
  prompteval status -k $API_KEY
  prompteval licenses -k $API_KEY
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run evaluation tests")
    run_parser.add_argument("adapter_file", help="Adapter YAML file")
    run_parser.add_argument("--tests", "-t", help="Test cases YAML file")
    run_parser.add_argument("--api-key", "-k", help="API key (or set PROMPTEVAL_API_KEY)")
    run_parser.add_argument("--api-url", "-u", help="API URL")
    run_parser.add_argument("--model", "-m", default="gpt-4o", help="Model to use")
    run_parser.add_argument("--output", "-o", help="Output file (default: results.json)")
    run_parser.add_argument("--timeout", type=int, help="Request timeout in seconds")
    
    # Validate command
    validate_parser = subparsers.add_parser("validate", help="Validate YAML file")
    validate_parser.add_argument("file", help="YAML file to validate")
    
    # Report command
    report_parser = subparsers.add_parser("report", help="Generate HTML report")
    report_parser.add_argument("input", help="Results JSON file")
    report_parser.add_argument("--output", "-o", help="Output HTML file")
    
    # Licenses command
    licenses_parser = subparsers.add_parser("licenses", help="Show license info")
    licenses_parser.add_argument("--api-key", "-k", help="API key")
    licenses_parser.add_argument("--api-url", "-u", help="API URL")
    
    # Status command
    status_parser = subparsers.add_parser("status", help="Show account status (quota, usage, machines)")
    status_parser.add_argument("--api-key", "-k", help="API key")
    status_parser.add_argument("--api-url", "-u", help="API URL")
    
    args = parser.parse_args()
    
    if args.command == "run":
        return run_command(args)
    elif args.command == "validate":
        return validate_command(args)
    elif args.command == "report":
        return report_command(args)
    elif args.command == "licenses":
        return licenses_command(args)
    elif args.command == "status":
        return status_command(args)
    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
