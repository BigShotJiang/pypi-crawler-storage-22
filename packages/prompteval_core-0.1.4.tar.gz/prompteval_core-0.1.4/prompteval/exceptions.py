"""
PromptEval SDK Exceptions
"""


class PromptEvalError(Exception):
    """Base exception for PromptEval SDK"""
    pass


class AuthenticationError(PromptEvalError):
    """Invalid or missing API key"""
    pass


class QuotaExceededError(PromptEvalError):
    """Monthly quota exceeded"""
    pass


class RateLimitError(PromptEvalError):
    """Rate limit exceeded"""
    pass


class ValidationError(PromptEvalError):
    """Invalid input data"""
    pass


class APIError(PromptEvalError):
    """Generic API error"""
    
    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class ConnectionError(PromptEvalError):
    """Cannot connect to API"""
    pass


class TimeoutError(PromptEvalError):
    """Request timed out"""
    pass
