"""
PromptEval SDK Setup
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_path = Path(__file__).parent / "README.md"
long_description = readme_path.read_text(encoding="utf-8") if readme_path.exists() else ""

setup(
    name="prompteval",
    version="0.1.0",
    author="PromptEval Team",
    author_email="hello@getprompteval.com",
    description="Semantic Testing for LLMs - Test your AI outputs with semantic similarity validation",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/prompteval/prompteval-sdk",
    project_urls={
        "Documentation": "https://docs.getprompteval.com",
        "Homepage": "https://getprompteval.com",
        "Bug Tracker": "https://github.com/prompteval/prompteval-sdk/issues",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Testing",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.25.0",
        "pyyaml>=5.4.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "prompteval=prompteval.cli:main",
        ],
    },
    keywords=[
        "llm",
        "testing",
        "semantic",
        "ai",
        "nlp",
        "validation",
        "prompt",
        "gpt",
        "openai",
        "anthropic",
    ],
)
