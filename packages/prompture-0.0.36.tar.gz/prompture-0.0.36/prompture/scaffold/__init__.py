"""Project scaffolding for Prompture-based FastAPI apps."""
