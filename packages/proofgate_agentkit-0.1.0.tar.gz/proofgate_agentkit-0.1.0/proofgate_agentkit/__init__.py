"""ProofGate Action Provider for Coinbase AgentKit.

Blockchain guardrails for AI agents - validate transactions before execution.
"""

from .action_provider import (
    ProofGateActionProvider,
    proofgate_action_provider,
)
from .config import ProofGateConfig
from .exceptions import ProofGateValidationError
from .wrapper import (
    ProofGateWrapper,
    wrap_with_proofgate,
)

__version__ = "0.1.0"

__all__ = [
    # Action Provider
    "ProofGateActionProvider",
    "proofgate_action_provider",
    # Config
    "ProofGateConfig",
    # Wrapper
    "ProofGateWrapper",
    "wrap_with_proofgate",
    # Exceptions
    "ProofGateValidationError",
]
