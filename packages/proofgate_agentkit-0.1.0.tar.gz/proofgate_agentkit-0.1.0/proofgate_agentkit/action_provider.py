"""ProofGate Action Provider for Coinbase AgentKit.

This module provides the ProofGateActionProvider class that validates
transactions through ProofGate before they are executed.
"""

import logging
from typing import Any, Optional

from coinbase_agentkit.action_providers import ActionProvider, create_action
from coinbase_agentkit.network import Network
from coinbase_agentkit.wallet_providers import EvmWalletProvider
from proofgate import ProofGate, ProofGateError
from pydantic import BaseModel, Field

from .config import ProofGateConfig
from .exceptions import ProofGateValidationError

logger = logging.getLogger(__name__)


class ValidateTransactionSchema(BaseModel):
    """Schema for validating a transaction through ProofGate."""

    to: str = Field(..., description="The destination address of the transaction")
    data: str = Field(default="0x", description="The transaction calldata (hex)")
    value: str = Field(default="0", description="The value to send in wei")
    guardrail_id: Optional[str] = Field(None, description="Override guardrail ID")


class CheckAgentSchema(BaseModel):
    """Schema for checking an agent's trust score."""

    wallet_address: str = Field(..., description="The wallet address to check")


class ProofGateActionProvider(ActionProvider[EvmWalletProvider]):
    """Action provider that validates transactions through ProofGate.

    ProofGate acts as a security layer that validates blockchain transactions
    before execution, protecting AI agents from:
    - Wallet drains from prompt injection attacks
    - Infinite token approvals to malicious contracts
    - Excessive spending beyond limits
    - High slippage swaps

    Example:
        ```python
        from proofgate_agentkit import ProofGateActionProvider, ProofGateConfig

        config = ProofGateConfig(
            api_key="pg_your_api_key",
            guardrail_id="your_guardrail_id",
        )
        provider = ProofGateActionProvider(config)
        ```
    """

    def __init__(
        self,
        config: ProofGateConfig,
        action_providers: Optional[list[ActionProvider]] = None,
    ) -> None:
        """Initialize the ProofGate action provider.

        Args:
            config: ProofGate configuration with API credentials.
            action_providers: Optional list of sub-providers.
        """
        super().__init__("proofgate", action_providers or [])
        self.config = config

        # Initialize ProofGate client
        self._client = ProofGate(
            api_key=config.api_key,
            chain_id=config.chain_id,
            guardrail_id=config.guardrail_id,
            base_url=config.base_url,
            timeout=config.timeout,
        )

    @property
    def client(self) -> ProofGate:
        """Get the ProofGate client."""
        return self._client

    def validate_transaction(
        self,
        from_address: str,
        to: str,
        data: str = "0x",
        value: str = "0",
        chain_id: Optional[int] = None,
        guardrail_id: Optional[str] = None,
    ) -> str:
        """Validate a transaction through ProofGate.

        Args:
            from_address: The sender address.
            to: The destination address.
            data: Transaction calldata (hex).
            value: Value in wei.
            chain_id: Override chain ID.
            guardrail_id: Override guardrail ID.

        Returns:
            The validation/proof ID if transaction is safe.

        Raises:
            ProofGateValidationError: If transaction is blocked.
        """
        try:
            result = self._client.validate(
                from_address=from_address,
                to=to,
                data=data,
                value=value,
                chain_id=chain_id,
                guardrail_id=guardrail_id,
            )

            if self.config.log_validations:
                logger.info(
                    f"ProofGate validation: {result.result} | "
                    f"ID: {result.validation_id} | "
                    f"To: {to}"
                )

            if not result.safe:
                raise ProofGateValidationError(
                    message=f"Transaction blocked by ProofGate: {result.reason}",
                    validation_id=result.validation_id,
                    reason=result.reason,
                    checks=[check.model_dump() for check in result.checks] if result.checks else [],
                    evidence_uri=result.evidence_uri,
                )

            return result.validation_id

        except ProofGateError as e:
            if self.config.fail_open:
                logger.warning(f"ProofGate API error (fail_open=True): {e}")
                return "fail_open_bypass"
            raise ProofGateValidationError(
                message=f"ProofGate API error: {e}",
                reason=str(e),
            ) from e

    @create_action(
        name="validate_transaction",
        description="""
        Validate a blockchain transaction through ProofGate before execution.

        This tool checks if a transaction is safe to execute by validating it
        against ProofGate's security guardrails. Use this before any transaction
        that sends funds or interacts with contracts.

        Inputs:
        - to: The destination address of the transaction
        - data: The transaction calldata in hex format (default: "0x")
        - value: The value to send in wei (default: "0")
        - guardrail_id: Optional override for the guardrail ID

        Returns the validation result with proof ID if safe, or blocks with reason.
        """,
        schema=ValidateTransactionSchema,
    )
    def validate_transaction_action(
        self, wallet_provider: EvmWalletProvider, args: dict[str, Any]
    ) -> str:
        """Validate a transaction through ProofGate.

        Args:
            wallet_provider: The wallet provider instance.
            args: Input arguments for the action.

        Returns:
            A message with validation result.
        """
        try:
            validated_args = ValidateTransactionSchema(**args)
            from_address = wallet_provider.get_address()
            network = wallet_provider.get_network()
            chain_id = int(network.chain_id) if network.chain_id else self.config.chain_id

            proof_id = self.validate_transaction(
                from_address=from_address,
                to=validated_args.to,
                data=validated_args.data,
                value=validated_args.value,
                chain_id=chain_id,
                guardrail_id=validated_args.guardrail_id,
            )

            return (
                f"✅ Transaction validated by ProofGate\n"
                f"Proof ID: {proof_id}\n"
                f"From: {from_address}\n"
                f"To: {validated_args.to}\n"
                f"Value: {validated_args.value} wei\n"
                f"The transaction is safe to execute."
            )

        except ProofGateValidationError as e:
            return (
                f"🚫 Transaction BLOCKED by ProofGate\n"
                f"Reason: {e.reason}\n"
                f"Validation ID: {e.validation_id}\n"
                f"Evidence: {e.evidence_uri or 'N/A'}\n"
                f"DO NOT execute this transaction."
            )

        except Exception as e:
            return f"Error validating transaction: {e}"

    @create_action(
        name="check_agent_trust",
        description="""
        Check an agent wallet's trust score on ProofGate.

        This tool retrieves the trust score and verification status of an
        agent wallet address. Higher trust scores may have higher spending limits.

        Inputs:
        - wallet_address: The wallet address to check

        Returns the agent's trust score, tier, and verification status.
        """,
        schema=CheckAgentSchema,
    )
    def check_agent_trust(
        self, wallet_provider: EvmWalletProvider, args: dict[str, Any]
    ) -> str:
        """Check an agent's trust score.

        Args:
            wallet_provider: The wallet provider instance.
            args: Input arguments for the action.

        Returns:
            A message with the agent's trust information.
        """
        try:
            validated_args = CheckAgentSchema(**args)
            agent = self._client.check_agent(validated_args.wallet_address)

            return (
                f"Agent Trust Score for {validated_args.wallet_address}:\n"
                f"- Trust Score: {agent.trust_score}\n"
                f"- Tier: {agent.tier}\n"
                f"- Verification Status: {agent.verification_status}"
            )

        except ProofGateError as e:
            return f"Error checking agent trust: {e}"

        except Exception as e:
            return f"Error: {e}"

    def supports_network(self, network: Network) -> bool:
        """Check if the network is supported.

        ProofGate supports EVM networks.

        Args:
            network: The network to check.

        Returns:
            True if the network is EVM-based.
        """
        return network.protocol_family == "evm"


def proofgate_action_provider(
    api_key: str,
    guardrail_id: Optional[str] = None,
    chain_id: Optional[int] = None,
    fail_open: bool = False,
    **kwargs: Any,
) -> ProofGateActionProvider:
    """Create a new ProofGateActionProvider instance.

    This is a convenience factory function for creating the provider.

    Args:
        api_key: ProofGate API key.
        guardrail_id: Default guardrail ID.
        chain_id: Default chain ID.
        fail_open: Whether to allow transactions on API failure.
        **kwargs: Additional config options.

    Returns:
        A configured ProofGateActionProvider.

    Example:
        ```python
        provider = proofgate_action_provider(
            api_key="pg_your_api_key",
            guardrail_id="your_guardrail_id",
            chain_id=8453,  # Base
        )
        ```
    """
    config = ProofGateConfig(
        api_key=api_key,
        guardrail_id=guardrail_id,
        chain_id=chain_id,
        fail_open=fail_open,
        **kwargs,
    )
    return ProofGateActionProvider(config)
