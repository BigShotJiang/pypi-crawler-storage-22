"""Configuration for ProofGate Action Provider."""

from typing import Optional

from pydantic import BaseModel, Field


class ProofGateConfig(BaseModel):
    """Configuration for ProofGate validation.

    Attributes:
        api_key: ProofGate API key (required). Get from proofgate.xyz/dashboard.
        guardrail_id: Default guardrail ID to use for validation.
        chain_id: Default chain ID (e.g., 1 for Ethereum, 8453 for Base).
        base_url: Custom API base URL. Defaults to ProofGate's production API.
        timeout: Request timeout in seconds.
        fail_open: If True, allow transactions when ProofGate API is unreachable.
                   Default False (fail closed for security).
        log_validations: If True, log validation results. Default True.
    """

    api_key: str = Field(..., description="ProofGate API key")
    guardrail_id: Optional[str] = Field(None, description="Default guardrail ID")
    chain_id: Optional[int] = Field(None, description="Default chain ID")
    base_url: Optional[str] = Field(None, description="Custom API base URL")
    timeout: float = Field(30.0, description="Request timeout in seconds")
    fail_open: bool = Field(False, description="Allow tx on API failure")
    log_validations: bool = Field(True, description="Log validation results")

    class Config:
        """Pydantic config."""

        extra = "forbid"
