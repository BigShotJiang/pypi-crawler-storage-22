"""Exceptions for ProofGate Action Provider."""

from typing import Any, Optional


class ProofGateValidationError(Exception):
    """Raised when ProofGate blocks a transaction.

    Attributes:
        validation_id: The ProofGate validation ID.
        reason: The reason the transaction was blocked.
        checks: List of validation checks that were performed.
        evidence_uri: URI to the evidence for this validation.
    """

    def __init__(
        self,
        message: str,
        validation_id: Optional[str] = None,
        reason: Optional[str] = None,
        checks: Optional[list[dict[str, Any]]] = None,
        evidence_uri: Optional[str] = None,
    ) -> None:
        """Initialize the exception.

        Args:
            message: Human-readable error message.
            validation_id: The ProofGate validation ID.
            reason: The reason the transaction was blocked.
            checks: List of validation checks performed.
            evidence_uri: URI to validation evidence.
        """
        super().__init__(message)
        self.validation_id = validation_id
        self.reason = reason
        self.checks = checks or []
        self.evidence_uri = evidence_uri

    def __str__(self) -> str:
        """Return string representation."""
        parts = [str(self.args[0])]
        if self.reason:
            parts.append(f"Reason: {self.reason}")
        if self.validation_id:
            parts.append(f"Validation ID: {self.validation_id}")
        if self.evidence_uri:
            parts.append(f"Evidence: {self.evidence_uri}")
        return " | ".join(parts)
