"""Transaction wrapper that adds ProofGate validation to any action provider.

This module provides utilities to wrap existing action providers with
ProofGate validation, intercepting transactions before execution.
"""

import functools
import logging
from typing import Any, Callable, Optional, TypeVar

from coinbase_agentkit.action_providers import Action, ActionProvider
from coinbase_agentkit.wallet_providers import EvmWalletProvider

from .action_provider import ProofGateActionProvider
from .config import ProofGateConfig
from .exceptions import ProofGateValidationError

logger = logging.getLogger(__name__)

T = TypeVar("T")


class ProofGateWrapper:
    """Wraps wallet provider methods to add ProofGate validation.

    This class intercepts transaction methods (send_transaction, native_transfer)
    and validates them through ProofGate before execution.

    Example:
        ```python
        from proofgate_agentkit import ProofGateWrapper, ProofGateConfig

        config = ProofGateConfig(api_key="pg_xxx", guardrail_id="xxx")
        wrapper = ProofGateWrapper(config)

        # Wrap the wallet provider
        wrapped_wallet = wrapper.wrap(wallet_provider)

        # Now all transactions will be validated
        wrapped_wallet.send_transaction({...})  # Validated first!
        ```
    """

    def __init__(self, config: ProofGateConfig) -> None:
        """Initialize the wrapper.

        Args:
            config: ProofGate configuration.
        """
        self.config = config
        self._provider = ProofGateActionProvider(config)

    def wrap(self, wallet_provider: EvmWalletProvider) -> EvmWalletProvider:
        """Wrap a wallet provider with ProofGate validation.

        This patches the wallet provider's send_transaction method to
        validate transactions before execution.

        Args:
            wallet_provider: The wallet provider to wrap.

        Returns:
            The same wallet provider with patched methods.
        """
        original_send = wallet_provider.send_transaction

        @functools.wraps(original_send)
        def validated_send(tx: dict[str, Any]) -> str:
            """Send transaction after ProofGate validation."""
            from_address = wallet_provider.get_address()
            network = wallet_provider.get_network()
            chain_id = int(network.chain_id) if network.chain_id else self.config.chain_id

            to = tx.get("to", "")
            data = tx.get("data", "0x")
            value = str(tx.get("value", 0))

            # Validate through ProofGate
            proof_id = self._provider.validate_transaction(
                from_address=from_address,
                to=to,
                data=data,
                value=value,
                chain_id=chain_id,
            )

            logger.info(f"ProofGate approved transaction | Proof ID: {proof_id}")

            # Execute the original transaction
            return original_send(tx)

        # Patch the method
        wallet_provider.send_transaction = validated_send  # type: ignore

        return wallet_provider


def wrap_with_proofgate(
    action_provider: ActionProvider[EvmWalletProvider],
    config: ProofGateConfig,
) -> ActionProvider[EvmWalletProvider]:
    """Wrap an action provider's transaction actions with ProofGate validation.

    This creates a wrapper that intercepts actions that result in transactions
    and validates them through ProofGate first.

    Args:
        action_provider: The action provider to wrap.
        config: ProofGate configuration.

    Returns:
        A wrapped action provider.

    Example:
        ```python
        from coinbase_agentkit.action_providers import erc20_action_provider
        from proofgate_agentkit import wrap_with_proofgate, ProofGateConfig

        config = ProofGateConfig(api_key="pg_xxx")
        erc20 = erc20_action_provider()
        safe_erc20 = wrap_with_proofgate(erc20, config)
        ```
    """
    pg_provider = ProofGateActionProvider(config)

    class WrappedActionProvider(ActionProvider[EvmWalletProvider]):
        """Wrapper that validates transactions through ProofGate."""

        def __init__(self) -> None:
            super().__init__(
                f"proofgate_wrapped_{action_provider.name}",
                [action_provider],
            )
            self._inner = action_provider
            self._pg = pg_provider

        def get_actions(self, wallet_provider: EvmWalletProvider) -> list[Action]:
            """Get wrapped actions that validate through ProofGate."""
            original_actions = self._inner.get_actions(wallet_provider)
            wrapped_actions = []

            # Actions that modify state (need validation)
            tx_action_names = {
                "transfer",
                "approve",
                "native_transfer",
                "swap",
                "supply",
                "withdraw",
                "borrow",
                "repay",
                "wrap",
                "unwrap",
                "mint",
                "burn",
            }

            for action in original_actions:
                # Check if this is a transaction action
                action_name_lower = action.name.lower()
                needs_validation = any(
                    tx_name in action_name_lower for tx_name in tx_action_names
                )

                if needs_validation:
                    wrapped_actions.append(
                        self._wrap_action(action, wallet_provider)
                    )
                else:
                    wrapped_actions.append(action)

            return wrapped_actions

        def _wrap_action(
            self, action: Action, wallet_provider: EvmWalletProvider
        ) -> Action:
            """Wrap an action with ProofGate validation."""
            original_invoke = action.invoke

            def wrapped_invoke(args: dict[str, Any]) -> str:
                """Invoke with ProofGate validation."""
                # Extract transaction details from args
                to = args.get("to") or args.get("contract_address") or args.get("destination_address", "")
                value = str(args.get("value", 0))

                if to:
                    try:
                        from_address = wallet_provider.get_address()
                        network = wallet_provider.get_network()
                        chain_id = int(network.chain_id) if network.chain_id else config.chain_id

                        proof_id = self._pg.validate_transaction(
                            from_address=from_address,
                            to=to,
                            data="0x",  # Simplified - could extract real data
                            value=value,
                            chain_id=chain_id,
                        )

                        logger.info(
                            f"ProofGate approved {action.name} | "
                            f"Proof ID: {proof_id}"
                        )

                    except ProofGateValidationError as e:
                        return (
                            f"🚫 Action BLOCKED by ProofGate\n"
                            f"Action: {action.name}\n"
                            f"Reason: {e.reason}\n"
                            f"Validation ID: {e.validation_id}\n"
                            f"This action was not executed."
                        )

                return original_invoke(args)

            return Action(
                name=action.name,
                description=f"[ProofGate Protected] {action.description}",
                args_schema=action.args_schema,
                invoke=wrapped_invoke,
            )

        def supports_network(self, network: Any) -> bool:
            """Check network support."""
            return self._inner.supports_network(network)

    return WrappedActionProvider()


def create_validated_action(
    config: ProofGateConfig,
    extract_tx_params: Optional[Callable[[dict[str, Any]], dict[str, Any]]] = None,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator to add ProofGate validation to an action function.

    Args:
        config: ProofGate configuration.
        extract_tx_params: Function to extract tx params (to, data, value) from args.

    Returns:
        A decorator that adds validation.

    Example:
        ```python
        @create_validated_action(config)
        def my_transfer_action(wallet_provider, args):
            # This will be validated first
            ...
        ```
    """
    pg_provider = ProofGateActionProvider(config)

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(
            self: Any,
            wallet_provider: EvmWalletProvider,
            args: dict[str, Any],
        ) -> T:
            # Extract transaction parameters
            if extract_tx_params:
                tx_params = extract_tx_params(args)
            else:
                tx_params = {
                    "to": args.get("to") or args.get("contract_address", ""),
                    "data": args.get("data", "0x"),
                    "value": str(args.get("value", 0)),
                }

            if tx_params.get("to"):
                from_address = wallet_provider.get_address()
                network = wallet_provider.get_network()
                chain_id = int(network.chain_id) if network.chain_id else config.chain_id

                # This will raise ProofGateValidationError if blocked
                proof_id = pg_provider.validate_transaction(
                    from_address=from_address,
                    to=tx_params["to"],
                    data=tx_params.get("data", "0x"),
                    value=tx_params.get("value", "0"),
                    chain_id=chain_id,
                )

                logger.info(f"ProofGate validated | Proof ID: {proof_id}")

            return func(self, wallet_provider, args)

        return wrapper

    return decorator
