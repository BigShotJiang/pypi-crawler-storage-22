"""Async resource classes for the Proofpudding API."""

from pudding._async.resources.documents import AsyncDocumentsResource
from pudding._async.resources.health import AsyncHealthResource
from pudding._async.resources.jobs import AsyncJobsResource

__all__ = [
    "AsyncHealthResource",
    "AsyncDocumentsResource",
    "AsyncJobsResource",
]
