"""Async documents resource for the Proofpudding API."""

from __future__ import annotations

from pathlib import Path

from pudding._async.resources.base import AsyncBaseResource
from pudding.exceptions import ValidationError
from pudding.models.documents import DocumentList, DocumentResponse

# Maximum file size: 100MB
MAX_FILE_SIZE = 100 * 1024 * 1024

# Allowed file extensions and their MIME types
ALLOWED_EXTENSIONS: dict[str, str] = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
}


class AsyncDocumentsResource(AsyncBaseResource):
    """
    Asynchronous resource for document endpoints.

    Provides methods for uploading, listing, and deleting documents.
    """

    async def upload(
        self,
        *,
        file_path: str | Path | None = None,
        file: bytes | None = None,
        filename: str | None = None,
    ) -> DocumentResponse:
        """
        Upload a document.

        You must provide either `file_path` OR both `file` and `filename`.

        Args:
            file_path: Path to the file to upload (.pdf or .docx).
            file: Raw bytes of the file.
            filename: Filename to use when uploading bytes (required with `file`).

        Returns:
            DocumentResponse with the uploaded document details.

        Raises:
            ValidationError: If the file is not a PDF, empty, or too large.
            ValueError: If arguments are invalid.

        Example:
            >>> # Upload from file path
            >>> doc = await client.documents.upload(file_path="./contract.pdf")
            >>> print(doc.id)

            >>> # Upload a .docx file
            >>> doc = await client.documents.upload(file_path="./report.docx")

            >>> # Upload from bytes
            >>> with open("contract.pdf", "rb") as f:
            ...     doc = await client.documents.upload(file=f.read(), filename="contract.pdf")
        """
        # Validate arguments
        if file_path is not None and file is not None:
            raise ValueError("Cannot specify both file_path and file")

        if file_path is None and file is None:
            raise ValueError("Must specify either file_path or file")

        if file is not None and filename is None:
            raise ValueError("filename is required when uploading bytes")

        # Handle file path upload
        if file_path is not None:
            path = Path(file_path)

            if not path.exists():
                raise ValueError(f"File not found: {file_path}")

            filename = path.name
            file_bytes = path.read_bytes()
        else:
            file_bytes = file
            # filename is already set

        # Validate filename and extension
        if filename is None:
            raise ValidationError("Filename is required")

        ext = Path(filename).suffix.lower()
        if ext not in ALLOWED_EXTENSIONS:
            raise ValidationError("Only .pdf, .docx files are allowed")

        # Validate file size
        if file_bytes is None or len(file_bytes) == 0:
            raise ValidationError("File is empty")

        if len(file_bytes) > MAX_FILE_SIZE:
            raise ValidationError("File too large. Maximum size is 100MB")

        # Upload the file
        content_type = ALLOWED_EXTENSIONS[ext]
        files = {"file": (filename, file_bytes, content_type)}
        data = await self._post("/api/v1/documents", files=files)

        return DocumentResponse.model_validate(data)

    async def list(self, *, skip: int = 0, limit: int = 20) -> DocumentList:
        """
        List documents with pagination.

        Args:
            skip: Number of documents to skip (default: 0).
            limit: Maximum number of documents to return (default: 20).

        Returns:
            DocumentList with items and pagination info.

        Example:
            >>> docs = await client.documents.list(skip=0, limit=10)
            >>> print(f"Total: {docs.total}")
            >>> for doc in docs.items:
            ...     print(f"  {doc.filename}")
        """
        params = {"skip": skip, "limit": limit}
        data = await self._get("/api/v1/documents", params=params)
        return DocumentList.model_validate(data)

    async def delete(self, document_id: str) -> DocumentResponse:
        """
        Delete a document and all associated jobs.

        Args:
            document_id: The UUID of the document to delete.

        Returns:
            DocumentResponse with the deleted document details.

        Raises:
            NotFoundError: If the document is not found or belongs to another team.

        Example:
            >>> deleted = await client.documents.delete(document_id="uuid-string")
            >>> print(f"Deleted: {deleted.filename}")
        """
        data = await self._delete(f"/api/v1/documents/{document_id}")
        return DocumentResponse.model_validate(data)


__all__ = ["AsyncDocumentsResource"]
