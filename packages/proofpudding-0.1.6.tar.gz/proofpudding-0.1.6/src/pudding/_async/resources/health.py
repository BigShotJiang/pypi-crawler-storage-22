"""Async health check resource for the Proofpudding API."""

from __future__ import annotations

from pudding._async.resources.base import AsyncBaseResource
from pudding.models.health import HealthResponse, ReadinessResponse


class AsyncHealthResource(AsyncBaseResource):
    """
    Asynchronous resource for health check endpoints.

    These endpoints do not require authentication.
    """

    async def check(self) -> HealthResponse:
        """
        Check the API health status.

        Returns:
            HealthResponse with status, version, and environment.

        Example:
            >>> health = await client.health.check()
            >>> print(health.status)
            "healthy"
        """
        data = await self._get("/health", include_auth=False)
        return HealthResponse.model_validate(data)

    async def ready(self) -> ReadinessResponse:
        """
        Check the API readiness status, including database connectivity.

        Returns:
            ReadinessResponse with status and database connection info.

        Example:
            >>> ready = await client.health.ready()
            >>> print(ready.status)
            "ready"
            >>> print(ready.database)
            "connected"
        """
        data = await self._get("/health/ready", include_auth=False)
        return ReadinessResponse.model_validate(data)


__all__ = ["AsyncHealthResource"]
