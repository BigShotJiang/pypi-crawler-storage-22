"""Async jobs resource for the Proofpudding API."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

from pudding._async.resources.base import AsyncBaseResource
from pudding.models.jobs import (
    CompleteEvent,
    DownloadingEvent,
    ErrorEvent,
    JobConfig,
    JobList,
    JobResponse,
    ProcessingEvent,
    StepEvent,
    StreamEvent,
    ThinkingEvent,
    VerifyingEvent,
)

# Default timeout for job creation (30 minutes)
DEFAULT_JOB_TIMEOUT = 1800.0

# SSE event type to model class mapping
_SSE_EVENT_MAP: dict[str, type[StreamEvent]] = {
    "downloading": DownloadingEvent,
    "processing": ProcessingEvent,
    "thinking": ThinkingEvent,
    "tool_exec": StepEvent,
    "step": StepEvent,
    "verifying": VerifyingEvent,
    "complete": CompleteEvent,
    "error": ErrorEvent,
}


class AsyncJobsResource(AsyncBaseResource):
    """
    Asynchronous resource for job endpoints.

    Jobs represent document processing tasks with questions.
    """

    async def create(
        self,
        *,
        document_id: str,
        question: str,
        config: JobConfig | None = None,
        timeout: float | None = None,
    ) -> JobResponse:
        """
        Create a job to process a document with a question.

        This is a BLOCKING call that waits for document processing to complete.
        The default timeout is 1800 seconds (30 minutes).

        Args:
            document_id: The UUID of the document to process.
            question: The question to ask about the document.
            config: Optional processing configuration (verify_citations, output_schema, etc.).
            timeout: Optional timeout in seconds (default: 1800).

        Returns:
            JobResponse with the processing result.

        Raises:
            NotFoundError: If the document is not found.
            GatewayError: If document processing fails.
            TimeoutError: If processing times out.

        Example:
            >>> job = await client.jobs.create(
            ...     document_id="uuid-string",
            ...     question="What is the effective date?"
            ... )
            >>> if job.success:
            ...     print(job.result.answer)
            ...     print(job.result.confidence)

            >>> # With structured output
            >>> from pudding.models import JobConfig, OutputSchemaConfig
            >>> config = JobConfig(
            ...     output_schema=OutputSchemaConfig(
            ...         schema={"type": "object", "properties": {"date": {"type": "string"}}},
            ...         strict=True,
            ...     )
            ... )
            >>> job = await client.jobs.create(
            ...     document_id="uuid-string",
            ...     question="Extract the effective date",
            ...     config=config,
            ... )
        """
        json_data: dict[str, Any] = {
            "document_id": document_id,
            "question": question,
        }

        if config is not None:
            json_data["config"] = config.model_dump(by_alias=True, exclude_none=True)

        # Use the provided timeout or fall back to client timeout or default
        request_timeout = timeout or self._client.timeout or DEFAULT_JOB_TIMEOUT

        data = await self._request(
            "POST",
            "/api/v1/jobs",
            json=json_data,
            timeout=request_timeout,
        )

        return JobResponse.model_validate(data)

    async def create_stream(
        self,
        *,
        document_id: str,
        question: str,
        config: JobConfig | None = None,
        timeout: float | None = None,
    ) -> AsyncIterator[StreamEvent]:
        """
        Create a job with streaming progress updates via Server-Sent Events.

        This returns an async iterator that yields typed event objects as the
        document is being processed.

        Args:
            document_id: The UUID of the document to process.
            question: The question to ask about the document.
            config: Optional processing configuration (verify_citations, output_schema, etc.).
            timeout: Optional timeout in seconds (default: 1800).

        Yields:
            StreamEvent objects (ProcessingEvent, ThinkingEvent, StepEvent,
            CompleteEvent, or ErrorEvent).

        Raises:
            NotFoundError: If the document is not found.
            AuthenticationError: If the API key is invalid.
            PuddingError: If an SSE error event is received.

        Example:
            >>> async for event in client.jobs.create_stream(
            ...     document_id="uuid-string",
            ...     question="What is the effective date?"
            ... ):
            ...     if isinstance(event, ProcessingEvent):
            ...         print(f"Processing: {event.pages_done}/{event.total_pages}")
            ...     elif isinstance(event, CompleteEvent):
            ...         print(f"Done: {event.result}")
        """
        json_data: dict[str, Any] = {
            "document_id": document_id,
            "question": question,
        }

        if config is not None:
            json_data["config"] = config.model_dump(by_alias=True, exclude_none=True)

        request_timeout = timeout or self._client.timeout or DEFAULT_JOB_TIMEOUT

        async for raw_event in self._stream_sse(
            "/api/v1/jobs/stream",
            json=json_data,
            timeout=request_timeout,
        ):
            event_type = raw_event.get("event")
            model_class = _SSE_EVENT_MAP.get(event_type) if event_type else None
            if model_class is not None:
                yield model_class.model_validate(raw_event)

    async def list(
        self,
        *,
        document_id: str | None = None,
        skip: int = 0,
        limit: int = 20,
    ) -> JobList:
        """
        List jobs with optional filtering and pagination.

        Args:
            document_id: Optional document UUID to filter by.
            skip: Number of jobs to skip (default: 0).
            limit: Maximum number of jobs to return (default: 20).

        Returns:
            JobList with items and pagination info.

        Example:
            >>> # List all jobs
            >>> jobs = await client.jobs.list(skip=0, limit=10)

            >>> # List jobs for a specific document
            >>> jobs = await client.jobs.list(document_id="uuid-string")
        """
        params: dict[str, str | int] = {"skip": skip, "limit": limit}

        if document_id is not None:
            params["document_id"] = document_id

        data = await self._get("/api/v1/jobs", params=params)
        return JobList.model_validate(data)


__all__ = ["AsyncJobsResource"]
