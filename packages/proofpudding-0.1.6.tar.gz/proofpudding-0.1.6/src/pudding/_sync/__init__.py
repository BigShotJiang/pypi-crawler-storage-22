"""This file is AUTO-GENERATED. Do not edit manually. Edit the _async version instead. And run generate_sync.py to regenerate the sync version."""

from pudding._sync.client import PuddingClient
from pudding._sync.resources import (
    DocumentsResource,
    HealthResource,
    JobsResource,
)

__all__ = [
    "PuddingClient",
    "HealthResource",
    "DocumentsResource",
    "JobsResource",
]
