"""This file is AUTO-GENERATED. Do not edit manually. Edit the _async version instead. And run generate_sync.py to regenerate the sync version."""

from __future__ import annotations

import logging
from types import TracebackType
from typing import Self

import httpx

from pudding._sync.resources.documents import DocumentsResource
from pudding._sync.resources.health import HealthResource
from pudding._sync.resources.jobs import JobsResource

logger = logging.getLogger("pudding")

# Default API base URL
DEFAULT_BASE_URL = "https://api.proofpudding.ai"

# Default timeout for jobs (30 minutes)
DEFAULT_TIMEOUT = 1800.0

# Default number of retries for transient errors
DEFAULT_MAX_RETRIES = 3


class PuddingClient:
    """
    Asynchronous client for the Proofpudding API.

    This client provides access to all Proofpudding API endpoints through
    resource-based interfaces using async/await.

    Attributes:
        access_token: The API key for authentication.
        timeout: The default timeout for requests in seconds.
        max_retries: Maximum number of retries for transient errors.
        health: Resource for health check endpoints.
        documents: Resource for document endpoints.
        jobs: Resource for job endpoints.

    Example:
        >>> client = PuddingClient(access_token="pk_your_api_key")
        >>> health = client.health.check()
        >>> print(health.status)

        >>> # Using async context manager
        >>> with PuddingClient(access_token="pk_your_api_key") as client:
        ...     docs = client.documents.list()
    """

    def __init__(
        self,
        access_token: str,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        """
        Initialize the async Proofpudding client.

        Args:
            access_token: The API key for authentication.
            timeout: Default timeout for requests in seconds (default: 1800).
            max_retries: Maximum number of retries for transient errors (default: 3).

        Raises:
            ValueError: If access_token is empty.
        """
        if not access_token:
            raise ValueError("access_token is required")

        self.base_url = DEFAULT_BASE_URL

        self.access_token = access_token
        self.timeout = timeout
        self.max_retries = max_retries

        # Initialize HTTP client
        self._http_client = httpx.Client()

        # Initialize resources
        self.health = HealthResource(self)
        self.documents = DocumentsResource(self)
        self.jobs = JobsResource(self)

        logger.debug(
            "Initialized PuddingClient with base_url=%s, timeout=%s, max_retries=%s",
            self.base_url,
            self.timeout,
            self.max_retries,
        )

    def __enter__(self) -> Self:
        """Enter the async context manager."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit the async context manager and close the HTTP client."""
        self.close()

    def close(self) -> None:
        """Close the HTTP client and release resources."""
        self._http_client.close()
        logger.debug("Closed PuddingClient")


__all__ = ["PuddingClient"]
