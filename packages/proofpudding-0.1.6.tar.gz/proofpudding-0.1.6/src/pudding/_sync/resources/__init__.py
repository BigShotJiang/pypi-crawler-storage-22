"""This file is AUTO-GENERATED. Do not edit manually. Edit the _async version instead. And run generate_sync.py to regenerate the sync version."""

from pudding._sync.resources.documents import DocumentsResource
from pudding._sync.resources.health import HealthResource
from pudding._sync.resources.jobs import JobsResource

__all__ = [
    "HealthResource",
    "DocumentsResource",
    "JobsResource",
]
