"""This file is AUTO-GENERATED. Do not edit manually. Edit the _async version instead. And run generate_sync.py to regenerate the sync version."""

from __future__ import annotations

import json as json_module
import logging
from collections.abc import Iterator
from typing import TYPE_CHECKING, Any

import httpx

from pudding.exceptions import PuddingError, TimeoutError, raise_for_status

if TYPE_CHECKING:
    from pudding._sync.client import PuddingClient

logger = logging.getLogger("pudding")


class BaseResource:
    """
    Base class for asynchronous API resources.

    Provides common HTTP methods with error handling and retry logic.
    """

    def __init__(self, client: PuddingClient) -> None:
        """
        Initialize the resource.

        Args:
            client: The PuddingClient instance.
        """
        self._client = client

    def _get_headers(self, include_auth: bool = True) -> dict[str, str]:
        """
        Get the headers for a request.

        Args:
            include_auth: Whether to include the Authorization header.

        Returns:
            A dictionary of headers.
        """
        headers: dict[str, str] = {}
        if include_auth:
            headers["Authorization"] = f"Bearer {self._client.access_token}"
        return headers

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """
        Handle the HTTP response and raise exceptions for errors.

        Args:
            response: The HTTP response.

        Returns:
            The parsed JSON response.

        Raises:
            PuddingError: If the response indicates an error.
        """
        if response.status_code >= 400:
            try:
                error_data = response.json()
                message = error_data.get("detail", "Unknown error")
            except Exception:
                message = response.text or "Unknown error"

            logger.error(
                "API error: status=%d, message=%s",
                response.status_code,
                message,
            )
            raise_for_status(response.status_code, message)

        if response.status_code == 204:
            return {}

        return response.json()

    def _request(
        self,
        method: str,
        path: str,
        *,
        include_auth: bool = True,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Make an async HTTP request with retry logic.

        Args:
            method: The HTTP method (GET, POST, DELETE, etc.).
            path: The API path (will be appended to base URL).
            include_auth: Whether to include authentication headers.
            timeout: Optional timeout override.
            **kwargs: Additional arguments to pass to httpx.

        Returns:
            The parsed JSON response.

        Raises:
            PuddingError: If the request fails after all retries.
        """
        url = f"{self._client.base_url}{path}"
        headers = self._get_headers(include_auth)

        if "headers" in kwargs:
            headers.update(kwargs.pop("headers"))

        request_timeout = timeout or self._client.timeout

        last_exception: Exception | None = None

        for attempt in range(self._client.max_retries + 1):
            try:
                logger.debug(
                    "Making %s request to %s (attempt %d/%d)",
                    method,
                    url,
                    attempt + 1,
                    self._client.max_retries + 1,
                )

                response = self._client._http_client.request(
                    method,
                    url,
                    headers=headers,
                    timeout=request_timeout,
                    **kwargs,
                )

                return self._handle_response(response)

            except httpx.TimeoutException as e:
                logger.warning("Request timed out (attempt %d): %s", attempt + 1, e)
                last_exception = e
                if attempt == self._client.max_retries:
                    raise TimeoutError("Request timed out") from e

            except httpx.NetworkError as e:
                logger.warning("Network error (attempt %d): %s", attempt + 1, e)
                last_exception = e
                if attempt == self._client.max_retries:
                    raise PuddingError(f"Network error: {e}") from e

            except PuddingError as e:
                # Only retry on 5xx errors
                if e.status_code and 500 <= e.status_code < 600:
                    logger.warning(
                        "Server error %d (attempt %d): %s",
                        e.status_code,
                        attempt + 1,
                        e.message,
                    )
                    last_exception = e
                    if attempt == self._client.max_retries:
                        raise
                else:
                    # Don't retry client errors
                    raise

        # This should never be reached, but just in case
        if last_exception:
            raise PuddingError(
                f"Request failed after {self._client.max_retries + 1} attempts"
            ) from last_exception
        raise PuddingError(f"Request failed after {self._client.max_retries + 1} attempts")

    def _get(
        self,
        path: str,
        *,
        include_auth: bool = True,
        params: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Make an async GET request."""
        return self._request("GET", path, include_auth=include_auth, params=params, **kwargs)

    def _post(
        self,
        path: str,
        *,
        include_auth: bool = True,
        json: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        files: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Make an async POST request."""
        return self._request(
            "POST",
            path,
            include_auth=include_auth,
            json=json,
            data=data,
            files=files,
            **kwargs,
        )

    def _delete(
        self,
        path: str,
        *,
        include_auth: bool = True,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Make an async DELETE request."""
        return self._request("DELETE", path, include_auth=include_auth, **kwargs)

    def _stream_sse(
        self,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        include_auth: bool = True,
        timeout: float | None = None,
    ) -> Iterator[dict[str, Any]]:
        """
        Make an async POST request and stream Server-Sent Events (SSE).

        Args:
            path: The API path (will be appended to base URL).
            json: JSON body to send with the request.
            include_auth: Whether to include authentication headers.
            timeout: Optional timeout override.

        Yields:
            Parsed JSON dictionaries for each SSE data event.

        Raises:
            PuddingError: If the request fails or an SSE error event is received.
        """
        url = f"{self._client.base_url}{path}"
        headers = self._get_headers(include_auth)
        headers["Accept"] = "text/event-stream"
        headers["Cache-Control"] = "no-cache"

        request_timeout = timeout or self._client.timeout

        try:
            with self._client._http_client.stream(
                "POST",
                url,
                headers=headers,
                json=json,
                timeout=request_timeout,
            ) as response:
                if response.status_code >= 400:
                    response.read()
                    try:
                        error_data = response.json()
                        message = error_data.get("detail", "Unknown error")
                    except Exception:
                        message = response.text or "Unknown error"

                    logger.error(
                        "API error: status=%d, message=%s",
                        response.status_code,
                        message,
                    )
                    raise_for_status(response.status_code, message)

                buffer = ""
                for chunk in response.iter_text():
                    buffer += chunk
                    while "\n\n" in buffer:
                        event_str, buffer = buffer.split("\n\n", 1)
                        for line in event_str.strip().split("\n"):
                            if line.startswith("data: "):
                                data_str = line[6:]
                                try:
                                    yield json_module.loads(data_str)
                                except (json_module.JSONDecodeError, TypeError):
                                    logger.warning("Failed to parse SSE data: %s", data_str)

        except httpx.TimeoutException as e:
            raise TimeoutError("Request timed out") from e
        except httpx.NetworkError as e:
            raise PuddingError(f"Network error: {e}") from e


__all__ = ["BaseResource"]
