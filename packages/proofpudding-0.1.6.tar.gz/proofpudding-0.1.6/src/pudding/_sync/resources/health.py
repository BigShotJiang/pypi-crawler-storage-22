"""This file is AUTO-GENERATED. Do not edit manually. Edit the _async version instead. And run generate_sync.py to regenerate the sync version."""

from __future__ import annotations

from pudding._sync.resources.base import BaseResource
from pudding.models.health import HealthResponse, ReadinessResponse


class HealthResource(BaseResource):
    """
    Asynchronous resource for health check endpoints.

    These endpoints do not require authentication.
    """

    def check(self) -> HealthResponse:
        """
        Check the API health status.

        Returns:
            HealthResponse with status, version, and environment.

        Example:
            >>> health = client.health.check()
            >>> print(health.status)
            "healthy"
        """
        data = self._get("/health", include_auth=False)
        return HealthResponse.model_validate(data)

    def ready(self) -> ReadinessResponse:
        """
        Check the API readiness status, including database connectivity.

        Returns:
            ReadinessResponse with status and database connection info.

        Example:
            >>> ready = client.health.ready()
            >>> print(ready.status)
            "ready"
            >>> print(ready.database)
            "connected"
        """
        data = self._get("/health/ready", include_auth=False)
        return ReadinessResponse.model_validate(data)


__all__ = ["HealthResource"]
