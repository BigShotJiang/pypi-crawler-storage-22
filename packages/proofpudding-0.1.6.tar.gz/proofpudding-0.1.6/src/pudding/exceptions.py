"""
Proofpudding SDK Exceptions.

This module defines the exception hierarchy for the Proofpudding SDK.
All exceptions inherit from PuddingError, which is the base exception
for all SDK errors.
"""

from __future__ import annotations


class PuddingError(Exception):
    """
    Base exception for all Proofpudding SDK errors.

    All SDK exceptions inherit from this class, making it easy to catch
    any SDK-related error with a single except clause.

    Attributes:
        status_code: The HTTP status code associated with the error.
        message: The error message from the API.
    """

    def __init__(self, message: str, status_code: int | None = None) -> None:
        """
        Initialize a PuddingError.

        Args:
            message: The error message.
            status_code: The HTTP status code, if applicable.
        """
        self.message = message
        self.status_code = status_code
        super().__init__(message)

    def __str__(self) -> str:
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(message={self.message!r}, status_code={self.status_code!r})"
        )


class AuthenticationError(PuddingError):
    """
    Raised when authentication fails.

    This error occurs when:
    - The API key is missing
    - The API key is invalid
    - The API key has been revoked

    HTTP Status Code: 401
    """

    def __init__(self, message: str = "Authentication failed") -> None:
        super().__init__(message, status_code=401)


class NotFoundError(PuddingError):
    """
    Raised when a requested resource is not found.

    This error occurs when:
    - The requested document does not exist
    - The requested job does not exist
    - The resource belongs to a different team

    HTTP Status Code: 404
    """

    def __init__(self, message: str = "Resource not found") -> None:
        super().__init__(message, status_code=404)


class ValidationError(PuddingError):
    """
    Raised when request validation fails.

    This error occurs when:
    - The file type is not allowed (only PDF supported)
    - The file is empty
    - The file exceeds the maximum size limit
    - Required fields are missing
    - Field values are invalid

    HTTP Status Code: 400
    """

    def __init__(self, message: str = "Validation error") -> None:
        super().__init__(message, status_code=400)


class RateLimitError(PuddingError):
    """
    Raised when the API rate limit is exceeded.

    This error occurs when too many requests have been made
    in a short period of time.

    HTTP Status Code: 429
    """

    def __init__(self, message: str = "Rate limit exceeded") -> None:
        super().__init__(message, status_code=429)


class ServerError(PuddingError):
    """
    Raised when an internal server error occurs.

    This error indicates a problem on the server side that
    prevented the request from being processed.

    HTTP Status Code: 500
    """

    def __init__(self, message: str = "Internal server error") -> None:
        super().__init__(message, status_code=500)


class GatewayError(PuddingError):
    """
    Raised when an upstream service error occurs.

    This error occurs when:
    - The document processing service is unavailable
    - Failed to connect to the processing service
    - Upstream service returned an error

    HTTP Status Code: 502
    """

    def __init__(self, message: str = "Gateway error") -> None:
        super().__init__(message, status_code=502)


class TimeoutError(PuddingError):
    """
    Raised when a request times out.

    This error occurs when:
    - Document processing takes longer than the timeout limit
    - The server doesn't respond within the timeout period

    HTTP Status Code: 504
    """

    def __init__(self, message: str = "Request timed out") -> None:
        super().__init__(message, status_code=504)


# Mapping of HTTP status codes to exception classes
STATUS_CODE_EXCEPTIONS: dict[int, type[PuddingError]] = {
    400: ValidationError,
    401: AuthenticationError,
    404: NotFoundError,
    429: RateLimitError,
    500: ServerError,
    502: GatewayError,
    504: TimeoutError,
}


def raise_for_status(status_code: int, message: str) -> None:
    """
    Raise an appropriate exception based on the HTTP status code.

    Args:
        status_code: The HTTP status code from the response.
        message: The error message from the API.

    Raises:
        PuddingError: An appropriate subclass based on the status code.
    """
    exception_class = STATUS_CODE_EXCEPTIONS.get(status_code, PuddingError)
    raise exception_class(message)


__all__ = [
    "PuddingError",
    "AuthenticationError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    "GatewayError",
    "TimeoutError",
    "STATUS_CODE_EXCEPTIONS",
    "raise_for_status",
]
