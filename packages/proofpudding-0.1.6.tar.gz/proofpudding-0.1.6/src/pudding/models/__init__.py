"""Pydantic models for the Proofpudding API."""

from __future__ import annotations

from pudding.models.documents import DocumentList, DocumentResponse
from pudding.models.health import HealthResponse, ReadinessResponse
from pudding.models.jobs import (
    Citation,
    CompleteEvent,
    DownloadingEvent,
    ErrorEvent,
    JobConfig,
    JobCreate,
    JobList,
    JobResponse,
    JobResult,
    OutputSchemaConfig,
    ProcessingEvent,
    StepEvent,
    StreamEvent,
    ThinkingEvent,
    UsageInfo,
    VerifyingEvent,
)

__all__ = [
    # Health models
    "HealthResponse",
    "ReadinessResponse",
    # Document models
    "DocumentResponse",
    "DocumentList",
    # Job models
    "OutputSchemaConfig",
    "JobConfig",
    "Citation",
    "UsageInfo",
    "JobResult",
    "JobCreate",
    "JobResponse",
    "JobList",
    # SSE event models
    "DownloadingEvent",
    "ProcessingEvent",
    "ThinkingEvent",
    "StepEvent",
    "VerifyingEvent",
    "CompleteEvent",
    "ErrorEvent",
    "StreamEvent",
]
