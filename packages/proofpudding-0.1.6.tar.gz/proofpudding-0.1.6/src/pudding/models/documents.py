"""Document models for the Proofpudding API."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field


class DocumentResponse(BaseModel):
    """
    Response model for a document.

    Attributes:
        id: The unique identifier (UUID) of the document.
        team_id: The unique identifier (UUID) of the team that owns the document.
        filename: The original filename of the uploaded document.
        size_bytes: The size of the document in bytes.
        created_at: The timestamp when the document was created.
    """

    id: str = Field(..., description="Document UUID")
    team_id: str = Field(..., description="Team UUID")
    filename: str = Field(..., description="Original filename")
    size_bytes: int = Field(..., description="File size in bytes")
    created_at: datetime = Field(..., description="Creation timestamp")


class DocumentList(BaseModel):
    """
    Response model for a paginated list of documents.

    Attributes:
        items: List of documents in the current page.
        total: Total number of documents across all pages.
        skip: Number of documents skipped (offset).
        limit: Maximum number of documents per page.
    """

    items: list[DocumentResponse] = Field(default_factory=list, description="List of documents")
    total: int = Field(..., description="Total document count")
    skip: int = Field(..., description="Offset")
    limit: int = Field(..., description="Page size")


__all__ = ["DocumentResponse", "DocumentList"]
