"""Health check models for the Proofpudding API."""

from __future__ import annotations

from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    """
    Response model for the health check endpoint.

    Attributes:
        status: The health status of the API (e.g., "healthy").
        version: The API version string.
        environment: The environment name (e.g., "production", "staging").
    """

    status: str = Field(..., description="Health status of the API")
    version: str = Field(..., description="API version")
    environment: str = Field(..., description="Environment name")


class ReadinessResponse(BaseModel):
    """
    Response model for the readiness check endpoint.

    Attributes:
        status: The readiness status ("ready" or "not_ready").
        database: The database connection status ("connected" or error message).
    """

    status: str = Field(..., description="Readiness status")
    database: str = Field(..., description="Database connection status")


__all__ = ["HealthResponse", "ReadinessResponse"]
