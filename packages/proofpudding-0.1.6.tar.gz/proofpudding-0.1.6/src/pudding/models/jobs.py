"""Job models for the Proofpudding API."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class Citation(BaseModel):
    """
    A citation from the document supporting an answer.

    Attributes:
        page: The page number where the citation was found.
        quote: The quoted text from the document.
        type: The type of citation (default: "text").
    """

    page: int = Field(..., description="Page number")
    quote: str = Field(..., description="Quoted text from document")
    type: str = Field(default="text", description="Citation type")


class UsageInfo(BaseModel):
    """
    Cost information for a processed job.

    Attributes:
        total_cost_cents: Total cost charged in cents.
        llm_cost_cents: LLM token cost in cents.
        fixed_fee_cents: Per-call fixed fee in cents.
    """

    total_cost_cents: float = Field(..., description="Total cost in cents")
    llm_cost_cents: float = Field(..., description="LLM token cost in cents")
    fixed_fee_cents: float = Field(..., description="Per-call fixed fee in cents")


class OutputSchemaConfig(BaseModel):
    """
    Configuration for structured output in job processing.

    Attributes:
        schema_: JSON Schema (draft-07) defining the desired output structure.
            Uses alias "schema" for serialization since "schema" is a reserved name in Pydantic.
        strict: If true, processing fails when the schema cannot be satisfied;
            if false, partial data is returned (default: true).
        include_citations: Whether to include citations in the response (default: true).
        include_raw_answer: Whether to include the raw text answer for debugging (default: false).
    """

    schema_: dict[str, Any] = Field(..., alias="schema", description="JSON Schema (draft-07)")
    strict: bool = Field(default=True, description="Whether to enforce strict schema validation")
    include_citations: bool = Field(default=True, description="Include citations in response")
    include_raw_answer: bool = Field(
        default=False, description="Include raw text answer for debugging"
    )

    model_config = {"populate_by_name": True}


class JobConfig(BaseModel):
    """
    Configuration for job processing.

    Attributes:
        verify_citations: Whether to verify citations against the source document (default: true).
        reasoning_effort: Controls analysis depth. One of "auto", "low", "high" (default: "auto").
        output_schema: Optional structured output configuration.
    """

    verify_citations: bool = Field(
        default=True, description="Whether to verify citations against source"
    )
    reasoning_effort: str = Field(
        default="auto", description="Analysis depth: 'auto', 'low', or 'high'"
    )
    output_schema: OutputSchemaConfig | None = Field(
        None, description="Structured output configuration"
    )


class JobResult(BaseModel):
    """
    The result of a successfully processed job.

    Attributes:
        answer: The answer to the question.
        confidence: Confidence level ("high", "medium", "low", or "not_found").
        citations: List of citations supporting the answer.
        structured_output: Structured data conforming to the provided schema, or None.
    """

    answer: str = Field(..., description="The answer text")
    confidence: str = Field(..., description="Confidence level")
    citations: list[Citation] = Field(default_factory=list, description="Supporting citations")
    structured_output: dict[str, Any] | None = Field(
        None, description="Structured output data when output_schema was provided"
    )


class JobCreate(BaseModel):
    """
    Request model for creating a new job.

    Attributes:
        document_id: The UUID of the document to process.
        question: The question to ask about the document.
        config: Optional processing configuration.
    """

    document_id: str = Field(..., description="Document UUID to process")
    question: str = Field(..., description="Question to ask about the document")
    config: JobConfig | None = Field(None, description="Optional processing configuration")


class JobResponse(BaseModel):
    """
    Response model for a job.

    Attributes:
        id: The unique identifier (UUID) of the job.
        document_id: The UUID of the processed document.
        question: The question that was asked.
        success: Whether the processing succeeded.
        result: The job result if successful, None otherwise.
        error: Error message if processing failed, None otherwise.
        processing_time_ms: Processing duration in milliseconds.
        usage: Cost information, or None.
        created_at: The timestamp when the job was created.
    """

    id: str = Field(..., description="Job UUID")
    document_id: str = Field(..., description="Document UUID")
    question: str = Field(..., description="Question asked")
    success: bool = Field(..., description="Whether processing succeeded")
    result: JobResult | None = Field(None, description="Job result if successful")
    error: str | None = Field(None, description="Error message if failed")
    processing_time_ms: int = Field(..., description="Processing duration in ms")
    usage: UsageInfo | None = Field(None, description="Cost information")
    created_at: datetime = Field(..., description="Creation timestamp")


class JobList(BaseModel):
    """
    Response model for a paginated list of jobs.

    Attributes:
        items: List of jobs in the current page.
        total: Total number of jobs across all pages.
        skip: Number of jobs skipped (offset).
        limit: Maximum number of jobs per page.
    """

    items: list[JobResponse] = Field(default_factory=list, description="List of jobs")
    total: int = Field(..., description="Total job count")
    skip: int = Field(..., description="Offset")
    limit: int = Field(..., description="Page size")


# --- SSE Event Models ---


class StreamEvent(BaseModel):
    """Base model for Server-Sent Events from the streaming endpoint."""

    event: str = Field(..., description="Event type")
    message: str = Field(default="", description="Event message")


class DownloadingEvent(StreamEvent):
    """
    Progress event during document download.

    Attributes:
        event: Always "downloading".
        message: Description of the download step.
        progress: Download progress percentage (0-100).
    """

    event: str = Field(default="downloading", description="Event type")
    progress: int | None = Field(None, description="Download progress percentage")


class ProcessingEvent(StreamEvent):
    """
    Progress event during document ingestion.

    Attributes:
        event: Always "processing".
        message: Description of the processing step.
        progress: Processing progress percentage (0-100).
        pages_done: Number of pages processed so far (if available).
        total_pages: Total number of pages in the document (if available).
    """

    event: str = Field(default="processing", description="Event type")
    progress: int | None = Field(None, description="Processing progress percentage")
    pages_done: int | None = Field(None, description="Pages processed so far")
    total_pages: int | None = Field(None, description="Total pages in document")


class ThinkingEvent(StreamEvent):
    """
    Agent reasoning iteration event.

    Attributes:
        event: Always "thinking".
        message: Description of the thinking step.
        iteration: Thinking iteration number (if available).
    """

    event: str = Field(default="thinking", description="Event type")
    iteration: int | None = Field(None, description="Thinking iteration number")


class StepEvent(StreamEvent):
    """
    Tool execution update event.

    Attributes:
        event: Always "step".
        message: Description of what tool is being executed.
    """

    event: str = Field(default="step", description="Event type")


class VerifyingEvent(StreamEvent):
    """
    Citation verification progress event.

    Attributes:
        event: Always "verifying".
        message: Description of the verification step.
    """

    event: str = Field(default="verifying", description="Event type")


class CompleteEvent(StreamEvent):
    """
    Final result event when processing finishes.

    Attributes:
        event: Always "complete".
        message: Completion message.
        result: The full processing result.
    """

    event: str = Field(default="complete", description="Event type")
    result: dict[str, Any] = Field(..., description="Full processing result")


class ErrorEvent(StreamEvent):
    """
    Error event when processing fails.

    Attributes:
        event: Always "error".
        message: Error description.
        error_code: Machine-readable error code.
        result: Error result details (if available).
    """

    event: str = Field(default="error", description="Event type")
    error_code: str | None = Field(None, description="Machine-readable error code")
    result: dict[str, Any] | None = Field(None, description="Error result details")


__all__ = [
    "Citation",
    "UsageInfo",
    "OutputSchemaConfig",
    "JobConfig",
    "JobResult",
    "JobCreate",
    "JobResponse",
    "JobList",
    "StreamEvent",
    "DownloadingEvent",
    "ProcessingEvent",
    "ThinkingEvent",
    "StepEvent",
    "VerifyingEvent",
    "CompleteEvent",
    "ErrorEvent",
]
