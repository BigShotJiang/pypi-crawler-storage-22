import json
import base64
import numpy as np
from io import BytesIO
from PIL import Image
from typing import Dict, Any, List
import matplotlib.pyplot as plt



# --------------------------------------------------
# Utils
# --------------------------------------------------

def _decode_base64_image(data: str, mode: str) -> np.ndarray:
    """
    Décode une image base64 en numpy array.
    mode = "RGB" ou "L"
    """
    decoded = base64.b64decode(data.strip())
    img = Image.open(BytesIO(decoded)).convert(mode)
    return np.array(img)


# --------------------------------------------------
# Main loader
# --------------------------------------------------

def load_frame(json_path: str) -> Dict[str, Any]:
    """
    Charge un frame JSON PROPIX et retourne un dict Python
    100 % exploitable (numpy-ready).
    """

    with open(json_path, "r", encoding="utf-8") as f:
        raw = json.load(f)

    # --- RGB ---
    rgb = None
    if raw.get("rgb_img") is not None:
        rgb = _decode_base64_image(raw["rgb_img"], mode="RGB")

    # --- Masks ---
    masks = []
    if raw.get("masks") is not None:
        for mask_b64 in raw["masks"]:
            mask = _decode_base64_image(mask_b64, mode="L")
            mask = mask.astype(np.float32) / 255.0  # normalisé [0,1]
            masks.append(mask)

    # --- Colors ---
    mask_colors = raw.get("mask_colors", [])
    mask_colors = [
        [c / 255 if max(color) > 1 else c for c in color]
        for color in mask_colors
    ]

    frame = {
        # Metadata
        "frame_id": raw.get("frame"),
        "task_finished": raw.get("taskFinished"),

        # Spectral
        "wavelengths": np.array(raw.get("wavelengths")) if raw.get("wavelengths") else None,
        "spectra": {
            "values": np.array(raw.get("spectra")) if raw.get("spectra") else None,
            "labels": raw.get("labels"),
        },

        # Image
        "rgb": rgb,                     # np.ndarray [H,W,3]
        "masks": masks,                 # List[np.ndarray [H,W]]
        "mask_colors": mask_colors,     # List[RGBA] normalisés
    }

    return frame

from typing import Dict, Any
import numpy as np

def frame_summary(frame: Dict[str, Any]) -> None:
    print("\n" + "=" * 48)
    print("        PROPIX FRAME — SUMMARY")
    print("=" * 48)

    # --- Image ---
    rgb = frame.get("rgb")
    if rgb is not None:
        h, w = rgb.shape[:2]
        total_pixels = h * w
        print("\n🖼️  Image")
        print(f"  • Resolution       : {w} x {h} px")
        print(f"  • Total pixels     : {total_pixels:,}")
    else:
        print("\n🖼️  Image            : ❌ missing")
        total_pixels = None

    # --- Masks ---
    masks = frame.get("masks", [])
    print("\n🎭 Masks")
    print(f"  • Count            : {len(masks)}")

    if masks and total_pixels is not None:
        percentages = []

        for m in masks:
            nonzero_pixels = int(np.count_nonzero(m))
            pct = 100.0 * nonzero_pixels / total_pixels
            percentages.append(pct)

        print(
            f"  • Masked area      : "
            f"min={min(percentages):.2f}% | "
            f"max={max(percentages):.2f}%"
        )

    # --- Spectral ---
    wavelengths = frame.get("wavelengths")
    print("\n🌈 Spectral")
    if wavelengths is not None and len(wavelengths) > 1:
        wl_min = float(wavelengths.min())
        wl_max = float(wavelengths.max())
        bands = len(wavelengths)

        # mean spectral resolution (Δλ)
        spectral_resolution = float(np.mean(np.diff(wavelengths)))

        print(f"  • Wavelength range   : {wl_min:.1f} – {wl_max:.1f} nm")
        print(f"  • Bands              : {bands}")
        print(f"  • Spectral resolution: {spectral_resolution:.2f} nm")
    else:
        print("  • Spectral data      : ❌ missing")

    print("\n" + "=" * 48 + "\n")



def plot_rgb_with_masks(frame, alpha=0.3):
    import numpy as np
    import matplotlib.pyplot as plt

    rgb = frame["rgb"]
    masks = frame["masks"]
    colors = frame["mask_colors"]

    plt.figure(figsize=(6, 6))
    plt.imshow(rgb)
    plt.title(f"RGB + masks – Frame {frame['frame_id']}")
    plt.axis("off")

    for i, mask in enumerate(masks):
        color = colors[i]

        overlay = np.zeros((*mask.shape, 4), dtype=np.float32)
        overlay[..., :3] = color[:3]      # couleur
        overlay[..., 3] = mask * alpha    # alpha maîtrisé

        plt.imshow(overlay)

    plt.tight_layout()
    plt.show()


def plot_rgb(frame: Dict[str, Any]) -> None:
    """
    Affiche uniquement l'image RGB d'un frame.
    """

    rgb = frame.get("rgb")

    if rgb is None:
        print("❌ Pas d'image RGB dans ce frame")
        return

    plt.figure(figsize=(6, 6))
    plt.imshow(rgb)
    plt.axis("off")
    plt.tight_layout()
    plt.show()



import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any


def plot_masks_only(
    frame: Dict[str, Any],
    alpha: float = 0.5,
    superpose: bool = True
) -> None:
    """
    Affiche uniquement les masques (sans image RGB).

    - superpose=True  : masques colorés superposés
    - superpose=False : un masque par subplot en noir/blanc
                        (1 = blanc, 0 = noir)
    """

    masks = frame.get("masks", [])
    colors = frame.get("mask_colors", [])

    if not masks:
        print("❌ Aucun masque à afficher")
        return

    # ============================
    # CAS 1 : superposition colorée
    # ============================
    if superpose:
        plt.figure(figsize=(6, 6))
        plt.axis("off")

        for i, mask in enumerate(masks):
            if mask is None:
                continue

            color = colors[i] if i < len(colors) else [1.0, 0.0, 0.0, 1.0]

            overlay = np.zeros((*mask.shape, 4), dtype=np.float32)
            overlay[..., :3] = color[:3]
            overlay[..., 3] = mask * alpha

            plt.imshow(overlay)

        plt.title("Masques superposés")
        plt.tight_layout()
        plt.show()

    # ============================
    # CAS 2 : un masque par subplot
    # ============================
    else:
        valid_masks = [(i, m) for i, m in enumerate(masks) if m is not None]
        n = len(valid_masks)

        cols = int(np.ceil(np.sqrt(n)))
        rows = int(np.ceil(n / cols))

        fig, axes = plt.subplots(rows, cols, figsize=(4 * cols, 4 * rows))
        axes = np.array(axes).reshape(-1)

        for ax, (i, mask) in zip(axes, valid_masks):
            ax.imshow(mask, cmap="gray", vmin=0, vmax=1)
            ax.set_title(f"Masque {i}", fontsize=14)
            ax.axis("off")

        # Désactiver les axes inutilisés
        for ax in axes[len(valid_masks):]:
            ax.axis("off")

        plt.suptitle("Masques individuels (binaire)", fontsize=16)
        plt.tight_layout()
        plt.show()



def plot_frame_rgb_and_spectra(frame: Dict[str, Any], alpha: float = 0.3):
    """
    Affiche :
    - à gauche : RGB + masques en transparence
    - à droite : spectres (intensité vs wavelengths)
    """

    rgb = frame["rgb"]
    masks = frame["masks"]
    colors = frame["mask_colors"]

    wavelengths = frame["wavelengths"]
    spectra = frame["spectra"]["values"]
    labels = frame["spectra"]["labels"]

    fig, (ax_img, ax_spec) = plt.subplots(
        1, 2, figsize=(12, 5), gridspec_kw={"width_ratios": [1, 1]}
    )

    # -------------------------------------------------
    # 🖼️ RGB + masks
    # -------------------------------------------------
    ax_img.imshow(rgb)
    ax_img.axis("off")

    for i, mask in enumerate(masks):
        color = colors[i]

        overlay = np.zeros((*mask.shape, 4), dtype=np.float32)
        overlay[..., :3] = color[:3]
        overlay[..., 3] = mask * alpha

        ax_img.imshow(overlay)

    # -------------------------------------------------
    # 📈 Spectres
    # -------------------------------------------------
    for i, spectrum in enumerate(spectra):
        label = f"Spectrum {i}"
        if labels:
            label += f" ({labels[i]})"

        ax_spec.plot(wavelengths, spectrum, label=label)

    ax_spec.set_xlabel("Wavelength")
    ax_spec.set_ylabel("Intensity")
    ax_spec.set_title("Spectra")
    ax_spec.grid(True)
    ax_spec.legend()

    plt.tight_layout()
    plt.show()

def plot_spectra(frame: Dict[str, Any]) -> None:
    """
    Affiche les spectres (intensité vs longueur d'onde).
    """
    

    wavelengths = frame.get("wavelengths")
    spectra = frame.get("spectra", {}).get("values")
    labels = frame.get("spectra", {}).get("labels")

    if wavelengths is None or spectra is None:
        print("❌ Données spectrales manquantes")
        return

    plt.figure(figsize=(7, 4))

    for i, spectrum in enumerate(spectra):
        label = f"Spectrum {i}"
        if labels and i < len(labels):
            label += f" ({labels[i]})"

        plt.plot(wavelengths, spectrum, label=label)

    plt.xlabel("Wavelength")
    plt.ylabel("Intensity")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()