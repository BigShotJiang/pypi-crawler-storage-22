# Propp_fr

Pattern Recognition and Ontologies for Prose Processing

Natural Language Processing Pipeline for French Literary Works

[DOCUMENTATION](https://lattice-8094.github.io/propp/)
