"""
Data access abstractions for the inference engine.
"""
