# Legacy setup.py - kept for editable installs compatibility
# All configuration is in pyproject.toml
from setuptools import setup
setup()
