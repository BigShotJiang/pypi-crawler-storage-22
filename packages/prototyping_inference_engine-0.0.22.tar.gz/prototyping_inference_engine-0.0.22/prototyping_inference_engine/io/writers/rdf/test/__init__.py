"""RDF writer tests."""
