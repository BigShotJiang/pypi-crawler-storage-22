"""Tests for session module."""
