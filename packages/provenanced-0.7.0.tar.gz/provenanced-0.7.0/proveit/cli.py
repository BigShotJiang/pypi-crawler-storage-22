"""
ProveIt CLI: unified command-line interface for provenance, fairness, and docs.

Usage:
    proveit fairness analyze --model m.pkl --data d.csv --protected race,sex --industry lending
    proveit docs generate --template sr11-7 --model metadata.json
    proveit docs templates
    proveit compliance check --db provenance.db --fingerprint 0xABC123
    proveit compliance score --db provenance.db
    proveit health --db provenance.db
    proveit dashboard
"""

import argparse
import json
import sys

from proveit import __version__


def main():
    parser = argparse.ArgumentParser(
        prog="proveit",
        description="ProveIt: Cryptographically Provable AI Compliance for Banks",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"proveit {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command")

    # --- fairness (from fairlens) ---
    fairness_parser = subparsers.add_parser(
        "fairness",
        help="Algorithmic fairness analysis",
    )
    fairness_sub = fairness_parser.add_subparsers(dest="fairness_command")
    from .fairness.cli import register_subcommands as reg_fairness
    reg_fairness(fairness_sub)

    # --- docs (from autodoc) ---
    docs_parser = subparsers.add_parser(
        "docs",
        help="Compliance documentation generation",
    )
    docs_sub = docs_parser.add_subparsers(dest="docs_command")
    from .docs.cli import register_subcommands as reg_docs
    reg_docs(docs_sub)

    # --- compliance ---
    compliance_parser = subparsers.add_parser(
        "compliance",
        help="Run compliance checks on a provenance DAG",
    )
    compliance_sub = compliance_parser.add_subparsers(dest="compliance_command")

    check_parser = compliance_sub.add_parser(
        "check",
        help="Run compliance engines against a specific DAG root fingerprint",
    )
    check_parser.add_argument(
        "--db", required=True,
        help="Path to the SQLite provenance database",
    )
    check_parser.add_argument(
        "--fingerprint", required=True,
        help="Root node fingerprint (hex, e.g. 0xABC123)",
    )
    check_parser.add_argument(
        "--format", choices=["json", "text"], default="text",
        help="Output format (default: text)",
    )

    score_parser = compliance_sub.add_parser(
        "score",
        help="Calculate board-reportable compliance score",
    )
    score_parser.add_argument(
        "--db", required=True,
        help="Path to the SQLite provenance database",
    )
    score_parser.add_argument(
        "--fingerprint", required=True,
        help="Root node fingerprint (hex, e.g. 0xABC123)",
    )

    # --- health ---
    health_parser = subparsers.add_parser(
        "health",
        help="Run platform health check",
    )
    health_parser.add_argument(
        "--db",
        help="Optional SQLite DB path to check connectivity",
    )

    # --- dashboard ---
    subparsers.add_parser(
        "dashboard",
        help="Launch the provenance dashboard",
    )

    args = parser.parse_args()

    if args.command == "fairness":
        _dispatch_fairness(args, fairness_parser)
    elif args.command == "docs":
        _dispatch_docs(args, docs_parser)
    elif args.command == "compliance":
        _dispatch_compliance(args, compliance_parser)
    elif args.command == "health":
        _dispatch_health(args)
    elif args.command == "dashboard":
        from .dashboard.server import main as dashboard_main
        dashboard_main()
    else:
        parser.print_help()


def _dispatch_fairness(args, parent_parser):
    from .fairness.cli import cmd_analyze, _validate_regulation
    if getattr(args, "fairness_command", None) == "analyze":
        _validate_regulation(args.regulation)
        cmd_analyze(args)
    else:
        parent_parser.print_help()


def _dispatch_docs(args, parent_parser):
    from .docs.cli import cmd_generate, cmd_templates
    if getattr(args, "docs_command", None) == "generate":
        cmd_generate(args)
    elif getattr(args, "docs_command", None) == "templates":
        cmd_templates(args)
    else:
        parent_parser.print_help()


def _dispatch_compliance(args, parent_parser):
    cmd = getattr(args, "compliance_command", None)
    if cmd == "check":
        _cmd_compliance_check(args)
    elif cmd == "score":
        _cmd_compliance_score(args)
    else:
        parent_parser.print_help()


def _cmd_compliance_check(args):
    """Run compliance engines against a DAG and print results."""
    from .persistence.sqlite_storage import SQLiteStorage
    from .compliance import EUAIActEngine, ECOAEngine, ComplianceReport
    from .dashboard.server import _load_dag_graph, _build_computation_dag

    storage = SQLiteStorage(args.db)
    storage.connect()

    try:
        fp = int(args.fingerprint, 0)
    except ValueError:
        print(f"Error: invalid fingerprint '{args.fingerprint}'", file=sys.stderr)
        sys.exit(1)

    root_data = storage.get_node_by_fingerprint(fp)
    if not root_data:
        print(f"Error: fingerprint {args.fingerprint} not found in database", file=sys.stderr)
        sys.exit(1)

    nodes_map, edges_list = _load_dag_graph(storage, root_data["node_id"])
    dag = _build_computation_dag(nodes_map, edges_list, root_data["node_id"])

    report = ComplianceReport()
    for engine in [EUAIActEngine(), ECOAEngine()]:
        try:
            report.add(engine.check(dag, {"domain": "general"}))
        except Exception as e:
            print(f"Warning: {engine.regulation_name} engine failed: {e}", file=sys.stderr)

    if args.format == "json":
        print(json.dumps(report.to_dict(), indent=2, default=str))
    else:
        summary = report.summary()
        status = "PASS" if summary["overall_passed"] else "FAIL"
        print(f"Overall: {status}")
        print(f"Engines run: {summary['engines_run']}")
        print(f"Findings: {summary['total_findings']} "
              f"({summary['total_critical']} critical, {summary['total_warnings']} warnings)")
        for reg, info in summary["per_regulation"].items():
            s = "PASS" if info["passed"] else "FAIL"
            print(f"  {reg}: {s} ({info['critical']}C / {info['warning']}W)")

    storage.disconnect()


def _cmd_compliance_score(args):
    """Calculate and print a board-reportable compliance score."""
    from .persistence.sqlite_storage import SQLiteStorage
    from .compliance import EUAIActEngine, ECOAEngine, ComplianceReport
    from .compliance.score import ComplianceScorer
    from .dashboard.server import _load_dag_graph, _build_computation_dag

    storage = SQLiteStorage(args.db)
    storage.connect()

    try:
        fp = int(args.fingerprint, 0)
    except ValueError:
        print(f"Error: invalid fingerprint '{args.fingerprint}'", file=sys.stderr)
        sys.exit(1)

    root_data = storage.get_node_by_fingerprint(fp)
    if not root_data:
        print(f"Error: fingerprint {args.fingerprint} not found in database", file=sys.stderr)
        sys.exit(1)

    nodes_map, edges_list = _load_dag_graph(storage, root_data["node_id"])
    dag = _build_computation_dag(nodes_map, edges_list, root_data["node_id"])

    report = ComplianceReport()
    for engine in [EUAIActEngine(), ECOAEngine()]:
        try:
            report.add(engine.check(dag, {"domain": "general"}))
        except Exception as e:
            print(f"Warning: {engine.regulation_name} engine failed: {e}", file=sys.stderr)

    scorer = ComplianceScorer()
    result = scorer.score(report)
    print(result.board_summary())

    storage.disconnect()


def _dispatch_health(args):
    """Run platform health checks."""
    from .vendor.health_check import PlatformHealthCheck

    check = PlatformHealthCheck()

    if args.db:
        from .persistence.sqlite_storage import SQLiteStorage
        storage = SQLiteStorage(args.db)
        try:
            storage.connect()
            stats = storage.get_stats()
            print(f"Database: OK ({stats.get('nodes', 0)} nodes, "
                  f"{stats.get('edges', 0)} edges)")
            storage.disconnect()
        except Exception as e:
            print(f"Database: FAIL ({e})", file=sys.stderr)
            sys.exit(1)

    result = check.run_checks()
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
