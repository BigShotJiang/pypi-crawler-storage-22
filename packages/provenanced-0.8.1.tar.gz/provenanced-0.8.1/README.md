# ProveIt

Cryptographically provable AI compliance for banks: tamper-proof provenance tracking, fair lending analysis, and automated compliance documentation.

## Install

```bash
pip install -e .
pip install -e ".[all]"  # with sklearn, flask, postgres, shap, opentelemetry
```

## Quick Start

### Provenance Tracking

```python
import proveit

proveit.configure(dag=True)
apps = proveit.wrap(apps_df, "applications.csv")
credit = proveit.wrap(credit_df, "credit_bureau.csv")

df = apps.merge(credit, on="applicant_id")
risk_score = df["balance"] / df["limit"]

dag = proveit.get_dag_simple(risk_score)
print(dag.source_nodes)
```

### Fairness Analysis

```python
from proveit.fairness import FairLensEngine, FairLensConfig

config = FairLensConfig(
    protected_columns=["race", "gender", "age"],
    industry="lending",
)
engine = FairLensEngine(config=config)
results = engine.analyze(
    model=model, X_train=X_train, y_train=y_train,
    X_test=X_test, y_test=y_test, protected_data=prot_test,
)
print(results.disparate_impact_results)
```

### Compliance Documentation

```python
from proveit.docs import AutoDocEngine, TemplateType, ModelMetadata

engine = AutoDocEngine()
report = engine.generate(
    template=TemplateType.SR_11_7,
    model_metadata=ModelMetadata(
        name="Risk Model v2",
        version="2.1.0",
        model_type="XGBoost",
    ),
)
report.save("sr117_report.md")
```

## CLI

```bash
proveit fairness analyze --model m.pkl --data d.csv --protected race,sex --industry lending
proveit docs generate --template sr11-7 --model metadata.json
proveit docs templates
proveit dashboard
```

## Modules

| Module | Description |
|--------|-------------|
| `proveit` | Core provenance DAG engine with Merkle tree anchoring |
| `proveit.fairness` | Disparate impact, proxy detection, LDA search, adverse action codes |
| `proveit.docs` | SR 11-7, EU AI Act, Model Cards, ECOA, GDPR, NIST AI RMF, dbt |
| `proveit.compliance` | EU AI Act and ECOA compliance engines |
| `proveit.persistence` | SQLite, PostgreSQL, DuckDB, S3 storage backends |
| `proveit.integrations` | Airflow, Kubeflow, Prefect, Dagster, dbt, Vertex AI, SageMaker, Azure ML |
| `proveit.dashboard` | Flask-based provenance dashboard |

## Test

```bash
pytest tests/ -v
```

## Requirements

- Python >= 3.9
- numpy >= 1.24
- pandas >= 2.0
- scikit-learn >= 1.3

## License

Proprietary. Copyright (c) 2024-2026 Provenance, Inc. All rights reserved.
