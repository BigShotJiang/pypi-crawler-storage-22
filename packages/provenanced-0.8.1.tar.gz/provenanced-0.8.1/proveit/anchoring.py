"""
ProveIt Cryptographic Provenance Anchoring

Provides tamper-proof anchoring of computation DAGs via Merkle trees,
with support for Ethereum L2 on-chain anchoring and RFC 3161 timestamping.

The Merkle tree captures the entire DAG state -- every node's provenance
fingerprint, operation, and lineage -- so that any post-hoc tampering is
cryptographically detectable.

Usage:
    from proveit.anchoring import MerkleTree, ProvenanceAnchor, BatchAnchor
    from proveit.hydra24_dag import DAGTracker, wrap_dataframe_dag

    tracker = DAGTracker()
    df = wrap_dataframe_dag(raw_df, tracker, "users.csv")
    result = df['income'] / df['debt']

    dag = tracker.get_dag(result._node_ids[0])

    anchor = ProvenanceAnchor()
    receipt = anchor.anchor_dag(dag)
    print(receipt.merkle_root.hex())

    verification = anchor.verify_anchor(receipt)
    assert verification.verified
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import ssl
import struct
import threading
import time
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

from .hydra24_dag import ComputationDAG, DAGNode

logger = logging.getLogger(__name__)


# =============================================================================
# Merkle Proof
# =============================================================================

class Direction(Enum):
    """Direction of a sibling in a Merkle proof path."""
    LEFT = "left"
    RIGHT = "right"


@dataclass
class MerkleProof:
    """
    Proof that a specific leaf is included in a Merkle tree.

    To verify, start with the leaf hash, then for each step in the path,
    combine it with the sibling hash according to the direction and hash
    the result. The final value must equal the Merkle root.

    Attributes:
        leaf_index: Index of the leaf this proof is for.
        leaf_hash: SHA-256 hash of the original leaf data.
        path: List of sibling hashes along the path to the root.
        directions: Direction of each sibling (LEFT means sibling is
                    on the left, so current node is on the right).
    """
    leaf_index: int
    leaf_hash: bytes
    path: List[bytes]
    directions: List[Direction]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "leaf_index": self.leaf_index,
            "leaf_hash": self.leaf_hash.hex(),
            "path": [h.hex() for h in self.path],
            "directions": [d.value for d in self.directions],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MerkleProof:
        return cls(
            leaf_index=data["leaf_index"],
            leaf_hash=bytes.fromhex(data["leaf_hash"]),
            path=[bytes.fromhex(h) for h in data["path"]],
            directions=[Direction(d) for d in data["directions"]],
        )


# =============================================================================
# Merkle Tree
# =============================================================================

def _sha256(data: bytes) -> bytes:
    """Compute SHA-256 digest."""
    return hashlib.sha256(data).digest()


def _hash_pair(left: bytes, right: bytes) -> bytes:
    """Hash two child nodes to produce a parent node hash.

    Uses domain separation (0x01 prefix) to distinguish internal nodes
    from leaf nodes (0x00 prefix), preventing second-preimage attacks.
    """
    return _sha256(b"\x01" + left + right)


def _hash_leaf(data: bytes) -> bytes:
    """Hash a leaf node with domain separation prefix."""
    return _sha256(b"\x00" + data)


class MerkleTree:
    """
    SHA-256 Merkle tree for provenance anchoring.

    Constructs a binary hash tree over an ordered set of leaf data.
    Supports generating and verifying inclusion proofs for individual leaves.

    The tree pads incomplete levels with duplicated last-node hashes to
    maintain a complete binary tree structure.

    Example:
        tree = MerkleTree()
        tree.add_leaf(b"node_0_data")
        tree.add_leaf(b"node_1_data")
        tree.add_leaf(b"node_2_data")
        tree.build()

        root = tree.get_root()
        proof = tree.get_proof(1)
        assert MerkleTree.verify_proof(proof, root, b"node_1_data")
    """

    def __init__(self) -> None:
        self._leaves: List[bytes] = []
        self._leaf_hashes: List[bytes] = []
        self._levels: List[List[bytes]] = []
        self._built = False

    @property
    def leaf_count(self) -> int:
        return len(self._leaves)

    def add_leaf(self, data: bytes) -> int:
        """Add a leaf to the tree. Returns the leaf index.

        Must be called before build(). Raises RuntimeError if the tree
        has already been built.
        """
        if self._built:
            raise RuntimeError(
                "Cannot add leaves after the tree has been built. "
                "Create a new MerkleTree instance."
            )
        index = len(self._leaves)
        self._leaves.append(data)
        self._leaf_hashes.append(_hash_leaf(data))
        return index

    def build(self) -> None:
        """Construct the Merkle tree from the current set of leaves.

        Raises ValueError if no leaves have been added.
        """
        if not self._leaf_hashes:
            raise ValueError("Cannot build Merkle tree with zero leaves.")

        self._levels = []

        current_level = list(self._leaf_hashes)
        self._levels.append(current_level)

        while len(current_level) > 1:
            next_level: List[bytes] = []
            for i in range(0, len(current_level), 2):
                left = current_level[i]
                if i + 1 < len(current_level):
                    right = current_level[i + 1]
                else:
                    right = left
                next_level.append(_hash_pair(left, right))
            current_level = next_level
            self._levels.append(current_level)

        self._built = True

    def get_root(self) -> bytes:
        """Return the 32-byte Merkle root hash.

        Raises RuntimeError if the tree has not been built.
        """
        if not self._built:
            raise RuntimeError("Tree has not been built. Call build() first.")
        return self._levels[-1][0]

    def get_proof(self, leaf_index: int) -> MerkleProof:
        """Generate a Merkle inclusion proof for a given leaf index.

        Args:
            leaf_index: Zero-based index of the leaf.

        Returns:
            MerkleProof containing the sibling hashes and directions.

        Raises:
            RuntimeError: If tree is not built.
            IndexError: If leaf_index is out of range.
        """
        if not self._built:
            raise RuntimeError("Tree has not been built. Call build() first.")
        if leaf_index < 0 or leaf_index >= len(self._leaf_hashes):
            raise IndexError(
                f"Leaf index {leaf_index} out of range [0, {len(self._leaf_hashes)})"
            )

        path: List[bytes] = []
        directions: List[Direction] = []
        idx = leaf_index

        for level in self._levels[:-1]:
            if idx % 2 == 0:
                sibling_idx = idx + 1
                if sibling_idx < len(level):
                    path.append(level[sibling_idx])
                else:
                    path.append(level[idx])
                directions.append(Direction.RIGHT)
            else:
                sibling_idx = idx - 1
                path.append(level[sibling_idx])
                directions.append(Direction.LEFT)
            idx //= 2

        return MerkleProof(
            leaf_index=leaf_index,
            leaf_hash=self._leaf_hashes[leaf_index],
            path=path,
            directions=directions,
        )

    @staticmethod
    def verify_proof(proof: MerkleProof, root: bytes, leaf_data: bytes) -> bool:
        """Verify a Merkle inclusion proof against a known root.

        Args:
            proof: The MerkleProof to verify.
            root: The expected Merkle root hash.
            leaf_data: The original leaf data (will be hashed internally).

        Returns:
            True if the proof is valid and the leaf belongs to the tree
            with the given root.
        """
        current = _hash_leaf(leaf_data)

        if current != proof.leaf_hash:
            return False

        for sibling, direction in zip(proof.path, proof.directions):
            if direction == Direction.LEFT:
                current = _hash_pair(sibling, current)
            else:
                current = _hash_pair(current, sibling)

        return current == root


# =============================================================================
# Anchor Receipt & Verification Result
# =============================================================================

class AnchorType(Enum):
    """Type of anchoring mechanism used."""
    LOCAL = "local"
    ETHEREUM = "ethereum"
    RFC3161 = "rfc3161"


@dataclass
class AnchorReceipt:
    """
    Receipt of a provenance anchoring operation.

    Contains all information needed to later verify that a DAG's state
    has not been tampered with since anchoring.

    Attributes:
        receipt_id: Unique identifier for this receipt.
        merkle_root: The 32-byte Merkle root that was anchored.
        anchor_type: Which anchoring mechanism was used.
        timestamp: Unix timestamp of when the anchor was created.
        dag_node_count: Number of nodes in the anchored DAG.
        tx_hash: Ethereum transaction hash (for ethereum anchors).
        timestamp_token: RFC 3161 timestamp token bytes (for rfc3161 anchors).
        metadata: Additional anchor-specific metadata.
        dag_serialized: JSON-serialized DAG snapshot for re-verification.
    """
    receipt_id: str
    merkle_root: bytes
    anchor_type: AnchorType
    timestamp: float
    dag_node_count: int
    tx_hash: Optional[str] = None
    timestamp_token: Optional[bytes] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    dag_serialized: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "receipt_id": self.receipt_id,
            "merkle_root": self.merkle_root.hex(),
            "anchor_type": self.anchor_type.value,
            "timestamp": self.timestamp,
            "dag_node_count": self.dag_node_count,
            "tx_hash": self.tx_hash,
            "metadata": self.metadata,
        }
        if self.timestamp_token is not None:
            result["timestamp_token"] = self.timestamp_token.hex()
        return result

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> AnchorReceipt:
        token = None
        if data.get("timestamp_token"):
            token = bytes.fromhex(data["timestamp_token"])
        return cls(
            receipt_id=data["receipt_id"],
            merkle_root=bytes.fromhex(data["merkle_root"]),
            anchor_type=AnchorType(data["anchor_type"]),
            timestamp=data["timestamp"],
            dag_node_count=data["dag_node_count"],
            tx_hash=data.get("tx_hash"),
            timestamp_token=token,
            metadata=data.get("metadata", {}),
            dag_serialized=data.get("dag_serialized"),
        )


@dataclass
class VerificationResult:
    """
    Result of verifying a provenance anchor.

    Attributes:
        verified: Whether the anchor passed verification.
        message: Human-readable verification status message.
        anchor_timestamp: Timestamp from the anchor receipt.
        merkle_root_match: Whether the recomputed Merkle root matches
                           the anchored root.
        details: Additional verification details.
    """
    verified: bool
    message: str
    anchor_timestamp: float
    merkle_root_match: bool
    details: Dict[str, Any] = field(default_factory=dict)


# =============================================================================
# DAG Serialization Helpers
# =============================================================================

def _serialize_dag_node(node: DAGNode) -> bytes:
    """Deterministically serialize a DAG node to bytes for Merkle hashing.

    The serialization is canonical: fields are always in the same order,
    integers use big-endian fixed-width encoding, and strings are UTF-8
    with length prefixes.
    """
    parts: List[bytes] = []

    parts.append(struct.pack(">I", node.node_id))

    parts.append(struct.pack(">B", node.node_type.value))

    op_bytes = node.operation.encode("utf-8")
    parts.append(struct.pack(">H", len(op_bytes)))
    parts.append(op_bytes)

    parts.append(struct.pack(">H", len(node.inputs)))
    for inp in node.inputs:
        parts.append(struct.pack(">I", inp))

    parts.append(struct.pack(">I", node.provenance))

    parts.append(struct.pack(">?", node.is_protected))

    if node.table is not None:
        table_bytes = node.table.encode("utf-8")
        parts.append(struct.pack(">H", len(table_bytes)))
        parts.append(table_bytes)
    else:
        parts.append(struct.pack(">H", 0))

    if node.column is not None:
        col_bytes = node.column.encode("utf-8")
        parts.append(struct.pack(">H", len(col_bytes)))
        parts.append(col_bytes)
    else:
        parts.append(struct.pack(">H", 0))

    return b"".join(parts)


def _dag_to_merkle_tree(dag: ComputationDAG) -> MerkleTree:
    """Build a Merkle tree from a ComputationDAG.

    Nodes are added in deterministic order (sorted by node_id) so the
    Merkle root is reproducible for the same DAG state.
    """
    tree = MerkleTree()
    for node_id in sorted(dag.nodes.keys()):
        node = dag.nodes[node_id]
        tree.add_leaf(_serialize_dag_node(node))
    tree.build()
    return tree


# =============================================================================
# Keccak-256 (FIPS 202 / SHA-3 variant used by Ethereum)
# =============================================================================

def _keccak256(data: bytes) -> bytes:
    """Compute the Keccak-256 digest used by Ethereum for hashing.

    Python 3.11+ includes Keccak-256 in hashlib via the ``sha3_256``
    alias **only** when OpenSSL 3.x is linked.  However the Ethereum
    ``keccak256`` is the *original* Keccak submission (capacity 512)
    which differs from NIST SHA3-256 in the padding rule (0x01 vs
    0x06).  We therefore implement Keccak-f[1600] directly using the
    reference permutation so we have zero external dependencies.
    """
    # -- Keccak-f[1600] round constants --
    RC = [
        0x0000000000000001, 0x0000000000008082, 0x800000000000808A,
        0x8000000080008000, 0x000000000000808B, 0x0000000080000001,
        0x8000000080008081, 0x8000000000008009, 0x000000000000008A,
        0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
        0x000000008000808B, 0x800000000000008B, 0x8000000000008089,
        0x8000000000008003, 0x8000000000008002, 0x8000000000000080,
        0x000000000000800A, 0x800000008000000A, 0x8000000080008081,
        0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
    ]
    # Rotation offsets
    ROT = [
        [0, 36, 3, 41, 18], [1, 44, 10, 45, 2],
        [62, 6, 43, 15, 61], [28, 55, 25, 21, 56],
        [27, 20, 39, 8, 14],
    ]
    MASK64 = (1 << 64) - 1

    def _rot64(x: int, n: int) -> int:
        return ((x << n) | (x >> (64 - n))) & MASK64

    def _keccak_f(state: list) -> list:
        for rc in RC:
            # theta
            C = [state[x][0] ^ state[x][1] ^ state[x][2] ^ state[x][3] ^ state[x][4] for x in range(5)]
            D = [C[(x - 1) % 5] ^ _rot64(C[(x + 1) % 5], 1) for x in range(5)]
            for x in range(5):
                for y in range(5):
                    state[x][y] ^= D[x]
            # rho and pi
            B = [[0] * 5 for _ in range(5)]
            for x in range(5):
                for y in range(5):
                    B[y][(2 * x + 3 * y) % 5] = _rot64(state[x][y], ROT[x][y])
            # chi
            for x in range(5):
                for y in range(5):
                    state[x][y] = B[x][y] ^ ((~B[(x + 1) % 5][y] & MASK64) & B[(x + 2) % 5][y])
            # iota
            state[0][0] ^= rc
        return state

    # Keccak-256: rate=1088 bits (136 bytes), capacity=512 bits, output=256 bits
    rate = 136
    # Padding: Keccak uses pad10*1 with domain 0x01 (NOT 0x06 which is SHA3)
    padded = bytearray(data)
    padded.append(0x01)
    while len(padded) % rate != 0:
        padded.append(0x00)
    padded[-1] |= 0x80

    # Initialize state: 5x5 matrix of 64-bit words
    state = [[0] * 5 for _ in range(5)]

    # Absorb
    for block_start in range(0, len(padded), rate):
        block = padded[block_start:block_start + rate]
        for i in range(rate // 8):
            x = i % 5
            y = i // 5
            lane = int.from_bytes(block[i * 8:(i + 1) * 8], "little")
            state[x][y] ^= lane
        state = _keccak_f(state)

    # Squeeze (only need 32 bytes)
    output = bytearray()
    for i in range(rate // 8):
        x = i % 5
        y = i // 5
        output.extend(state[x][y].to_bytes(8, "little"))
        if len(output) >= 32:
            break

    return bytes(output[:32])


# =============================================================================
# RLP Encoding (Recursive Length Prefix -- Ethereum serialization)
# =============================================================================

def _rlp_encode_length(length: int, offset: int) -> bytes:
    """Encode an RLP length prefix."""
    if length < 56:
        return bytes([length + offset])
    length_bytes = length.to_bytes((length.bit_length() + 7) // 8, "big")
    return bytes([len(length_bytes) + offset + 55]) + length_bytes


def _rlp_encode(item) -> bytes:
    """RLP-encode a single item (bytes) or a list of items.

    Args:
        item: Either ``bytes`` for a single value, or a ``list`` of items
              to encode as an RLP list.

    Returns:
        The RLP-encoded bytes.
    """
    if isinstance(item, bytes):
        if len(item) == 1 and item[0] < 0x80:
            return item
        return _rlp_encode_length(len(item), 0x80) + item
    elif isinstance(item, list):
        encoded_items = b"".join(_rlp_encode(i) for i in item)
        return _rlp_encode_length(len(encoded_items), 0xc0) + encoded_items
    else:
        raise TypeError(f"Cannot RLP-encode type {type(item)}")


def _int_to_rlp_bytes(value: int) -> bytes:
    """Convert a non-negative integer to the minimal big-endian bytes
    representation used in RLP (empty bytes for zero)."""
    if value == 0:
        return b""
    return value.to_bytes((value.bit_length() + 7) // 8, "big")


# =============================================================================
# secp256k1 ECDSA (pure-Python, stdlib only)
# =============================================================================

# Curve parameters for secp256k1
_SECP256K1_P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
_SECP256K1_N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
_SECP256K1_GX = 0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798
_SECP256K1_GY = 0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8
_SECP256K1_A = 0
_SECP256K1_B = 7


def _modinv(a: int, m: int) -> int:
    """Modular multiplicative inverse using extended Euclidean algorithm."""
    if a < 0:
        a = a % m
    g, x, _ = _extended_gcd(a, m)
    if g != 1:
        raise ValueError("Modular inverse does not exist")
    return x % m


def _extended_gcd(a: int, b: int) -> Tuple[int, int, int]:
    """Extended Euclidean algorithm. Returns (gcd, x, y) such that
    a*x + b*y = gcd."""
    if a == 0:
        return b, 0, 1
    g, x, y = _extended_gcd(b % a, a)
    return g, y - (b // a) * x, x


def _ec_point_add(
    x1: int, y1: int, x2: int, y2: int, p: int
) -> Tuple[int, int]:
    """Add two points on secp256k1 (affine coordinates)."""
    if x1 == 0 and y1 == 0:
        return x2, y2
    if x2 == 0 and y2 == 0:
        return x1, y1
    if x1 == x2 and y1 == y2:
        # Point doubling
        lam = (3 * x1 * x1) * _modinv(2 * y1, p) % p
    elif x1 == x2:
        # Point at infinity
        return 0, 0
    else:
        lam = (y2 - y1) * _modinv(x2 - x1, p) % p
    x3 = (lam * lam - x1 - x2) % p
    y3 = (lam * (x1 - x3) - y1) % p
    return x3, y3


def _ec_point_mul(k: int, x: int, y: int, p: int) -> Tuple[int, int]:
    """Scalar multiplication on secp256k1 using double-and-add."""
    rx, ry = 0, 0  # point at infinity
    qx, qy = x, y
    while k > 0:
        if k & 1:
            rx, ry = _ec_point_add(rx, ry, qx, qy, p)
        qx, qy = _ec_point_add(qx, qy, qx, qy, p)
        k >>= 1
    return rx, ry


def _ecdsa_sign(msg_hash: bytes, private_key: bytes) -> Tuple[int, int, int]:
    """Sign a 32-byte message hash with a secp256k1 private key.

    Returns (v, r, s) where v is the recovery id (0 or 1), and r, s are
    the standard ECDSA signature components.  ``s`` is normalized to the
    lower half of the curve order per EIP-2.
    """
    z = int.from_bytes(msg_hash, "big")
    d = int.from_bytes(private_key, "big")

    # Deterministic k via RFC 6979 (HMAC-SHA256 based)
    k = _rfc6979_k(msg_hash, private_key)

    # R = k * G
    rx, ry = _ec_point_mul(k, _SECP256K1_GX, _SECP256K1_GY, _SECP256K1_P)
    r = rx % _SECP256K1_N
    if r == 0:
        raise RuntimeError("ECDSA: r == 0, choose different k")

    s = (_modinv(k, _SECP256K1_N) * (z + r * d)) % _SECP256K1_N
    if s == 0:
        raise RuntimeError("ECDSA: s == 0, choose different k")

    # Recovery id
    v = 0 if ry % 2 == 0 else 1

    # Normalize s to lower half (EIP-2)
    half_n = _SECP256K1_N // 2
    if s > half_n:
        s = _SECP256K1_N - s
        v ^= 1

    return v, r, s


def _rfc6979_k(msg_hash: bytes, private_key: bytes) -> int:
    """Deterministic nonce generation per RFC 6979 using HMAC-SHA256."""
    q = _SECP256K1_N
    qlen = 32

    x = private_key
    h1 = msg_hash

    # Step b
    V = b"\x01" * 32
    # Step c
    K = b"\x00" * 32
    # Step d
    K = hmac.new(K, V + b"\x00" + x + h1, hashlib.sha256).digest()
    # Step e
    V = hmac.new(K, V, hashlib.sha256).digest()
    # Step f
    K = hmac.new(K, V + b"\x01" + x + h1, hashlib.sha256).digest()
    # Step g
    V = hmac.new(K, V, hashlib.sha256).digest()

    while True:
        # Step h
        T = b""
        while len(T) < qlen:
            V = hmac.new(K, V, hashlib.sha256).digest()
            T += V
        k = int.from_bytes(T[:qlen], "big")
        if 1 <= k < q:
            return k
        K = hmac.new(K, V + b"\x00", hashlib.sha256).digest()
        V = hmac.new(K, V, hashlib.sha256).digest()


def _private_key_to_address(private_key: bytes) -> str:
    """Derive an Ethereum address from a 32-byte secp256k1 private key.

    The address is the last 20 bytes of the Keccak-256 hash of the
    uncompressed public key (without the 0x04 prefix byte).
    """
    px, py = _ec_point_mul(
        int.from_bytes(private_key, "big"),
        _SECP256K1_GX, _SECP256K1_GY, _SECP256K1_P,
    )
    pub_bytes = px.to_bytes(32, "big") + py.to_bytes(32, "big")
    addr_hash = _keccak256(pub_bytes)
    return "0x" + addr_hash[12:].hex()


# =============================================================================
# Ethereum JSON-RPC Helper
# =============================================================================

def _json_rpc(
    url: str,
    method: str,
    params: list,
    timeout: float = 30.0,
    request_id: int = 1,
) -> Any:
    """Execute a single JSON-RPC 2.0 call via urllib and return the result.

    Args:
        url: The JSON-RPC endpoint URL.
        method: The RPC method name (e.g. ``eth_getTransactionCount``).
        params: The positional parameters for the method.
        timeout: HTTP request timeout in seconds.
        request_id: JSON-RPC request id.

    Returns:
        The ``result`` field from the JSON-RPC response.

    Raises:
        RuntimeError: On JSON-RPC error responses.
        ConnectionError: On network-level failures.
    """
    payload = json.dumps({
        "jsonrpc": "2.0",
        "method": method,
        "params": params,
        "id": request_id,
    }).encode("utf-8")

    req = urllib.request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    ctx = ssl.create_default_context()

    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            body = resp.read()
    except urllib.error.URLError as exc:
        raise ConnectionError(
            f"Failed to connect to JSON-RPC endpoint {url}: {exc}"
        ) from exc
    except urllib.error.HTTPError as exc:
        raise RuntimeError(
            f"JSON-RPC HTTP error {exc.code} from {url}: {exc.reason}"
        ) from exc

    try:
        data = json.loads(body)
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            f"Invalid JSON response from {url}: {body[:200]!r}"
        ) from exc

    if "error" in data and data["error"] is not None:
        err = data["error"]
        code = err.get("code", "?")
        msg = err.get("message", str(err))
        raise RuntimeError(f"JSON-RPC error {code}: {msg}")

    return data.get("result")


# =============================================================================
# DER / ASN.1 Encoding Helpers (for RFC 3161)
# =============================================================================

def _der_length(length: int) -> bytes:
    """Encode an ASN.1 DER definite-length field.

    Handles both short form (length < 128) and long form.
    """
    if length < 0x80:
        return bytes([length])
    length_bytes = length.to_bytes((length.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(length_bytes)]) + length_bytes


def _der_sequence(contents: bytes) -> bytes:
    """Wrap contents in a DER SEQUENCE (tag 0x30)."""
    return b"\x30" + _der_length(len(contents)) + contents


def _der_integer(value: int) -> bytes:
    """Encode a non-negative integer as a DER INTEGER."""
    if value == 0:
        return b"\x02\x01\x00"
    b = value.to_bytes((value.bit_length() + 7) // 8, "big")
    # Prepend 0x00 if the high bit is set (to keep it positive)
    if b[0] & 0x80:
        b = b"\x00" + b
    return b"\x02" + _der_length(len(b)) + b


def _der_octet_string(data: bytes) -> bytes:
    """Encode bytes as a DER OCTET STRING."""
    return b"\x04" + _der_length(len(data)) + data


def _der_boolean(value: bool) -> bytes:
    """Encode a boolean as a DER BOOLEAN."""
    return b"\x01\x01" + (b"\xff" if value else b"\x00")


def _der_oid(oid_bytes: bytes) -> bytes:
    """Wrap pre-encoded OID bytes in a DER OBJECT IDENTIFIER tag."""
    return b"\x06" + _der_length(len(oid_bytes)) + oid_bytes


# SHA-256 OID: 2.16.840.1.101.3.4.2.1
_SHA256_OID_BYTES = bytes([0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01])


def _der_parse_tag_length(data: bytes, offset: int) -> Tuple[int, int, int]:
    """Parse a DER tag and length at the given offset.

    Returns (tag, content_length, offset_after_header).
    """
    if offset >= len(data):
        raise ValueError("DER parse: unexpected end of data at tag")
    tag = data[offset]
    offset += 1
    if offset >= len(data):
        raise ValueError("DER parse: unexpected end of data at length")
    first = data[offset]
    offset += 1
    if first < 0x80:
        return tag, first, offset
    num_bytes = first & 0x7F
    if num_bytes == 0:
        raise ValueError("DER parse: indefinite length not supported")
    if offset + num_bytes > len(data):
        raise ValueError("DER parse: length bytes exceed data")
    length = int.from_bytes(data[offset:offset + num_bytes], "big")
    offset += num_bytes
    return tag, length, offset


# =============================================================================
# Provenance Anchor
# =============================================================================

class ProvenanceAnchor:
    """
    Anchors DAG Merkle roots to immutable external stores.

    Supports three anchoring modes:

    - **local**: In-memory anchoring with local timestamp (default).
    - **ethereum**: Anchors the Merkle root to an Ethereum L2 chain by
      constructing, signing, and submitting a raw transaction whose
      ``data`` field carries the Merkle root.  Works with any
      EVM-compatible L2 (Arbitrum, Optimism, Base, Polygon).  Uses only
      Python stdlib -- no ``web3.py`` dependency.
    - **rfc3161**: Obtains an RFC 3161 timestamp token from a trusted
      Time Stamping Authority (TSA) using a proper DER-encoded
      ``TimeStampReq``.

    Configuration for Ethereum anchoring can be provided via constructor
    kwargs or environment variables (``PROVEIT_ETH_*`` preferred;
    legacy ``HYDRA24_ETH_*`` accepted for backward compatibility):

    - ``PROVEIT_ETH_PRIVATE_KEY``: Hex-encoded 32-byte private key.
    - ``PROVEIT_ETH_CONTRACT``: Destination contract address.
    - ``PROVEIT_ETH_CHAIN_ID``: EIP-155 chain ID (default 42161 for Arbitrum One).

    Example::

        anchor = ProvenanceAnchor(
            private_key="0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",
            contract_address="0x5FbDB2315678afecb367f032d93F642f64180aa3",
            chain_id=42161,
        )
        receipt = anchor.anchor_dag(dag, anchor_type=AnchorType.ETHEREUM,
                                    rpc_url="https://arb1.arbitrum.io/rpc")
        result = anchor.verify_anchor(receipt)
        assert result.verified
    """

    # Solidity function selector for ``anchor(bytes32)``
    # keccak256("anchor(bytes32)")[:4]
    _ANCHOR_SELECTOR: bytes = _keccak256(b"anchor(bytes32)")[:4]

    def __init__(
        self,
        private_key: Optional[str] = None,
        contract_address: Optional[str] = None,
        chain_id: Optional[int] = None,
    ) -> None:
        self._receipts: Dict[str, AnchorReceipt] = {}

        # -- Ethereum configuration (env-var fallback) --
        # Prefer PROVEIT_ETH_* env vars; fall back to legacy HYDRA24_ETH_*.
        raw_key = (
            private_key
            or os.environ.get("PROVEIT_ETH_PRIVATE_KEY")
            or os.environ.get("HYDRA24_ETH_PRIVATE_KEY")
        )
        if raw_key is not None:
            raw_key = raw_key.strip()
            if raw_key.startswith("0x") or raw_key.startswith("0X"):
                raw_key = raw_key[2:]
            self._private_key: Optional[bytes] = bytes.fromhex(raw_key)
        else:
            self._private_key = None

        raw_contract = (
            contract_address
            or os.environ.get("PROVEIT_ETH_CONTRACT")
            or os.environ.get("HYDRA24_ETH_CONTRACT")
        )
        self._contract_address: Optional[str] = (
            raw_contract.lower() if raw_contract else None
        )

        raw_chain = chain_id
        if raw_chain is None:
            env_chain = (
                os.environ.get("PROVEIT_ETH_CHAIN_ID")
                or os.environ.get("HYDRA24_ETH_CHAIN_ID")
            )
            if env_chain is not None:
                raw_chain = int(env_chain)
        # Default: Arbitrum One
        self._chain_id: int = raw_chain if raw_chain is not None else 42161

    # -----------------------------------------------------------------
    # anchor_dag  (unchanged public API, delegates to type-specific)
    # -----------------------------------------------------------------

    def anchor_dag(
        self,
        dag: ComputationDAG,
        anchor_type: AnchorType = AnchorType.LOCAL,
        rpc_url: Optional[str] = None,
        tsa_url: Optional[str] = None,
    ) -> AnchorReceipt:
        """Anchor a DAG's Merkle root.

        Args:
            dag: The ComputationDAG to anchor.
            anchor_type: Which anchoring mechanism to use.
            rpc_url: Ethereum JSON-RPC URL (required for ethereum anchor).
            tsa_url: RFC 3161 TSA URL (required for rfc3161 anchor).

        Returns:
            AnchorReceipt with the Merkle root and anchor details.
        """
        tree = _dag_to_merkle_tree(dag)
        merkle_root = tree.get_root()
        now = time.time()
        receipt_id = str(uuid.uuid4())

        tx_hash: Optional[str] = None
        timestamp_token: Optional[bytes] = None
        metadata: Dict[str, Any] = {
            "root_node_id": dag.root_id,
            "dag_depth": dag.depth,
            "has_protected": dag.has_protected,
            "source_count": len(dag.source_nodes),
        }

        if anchor_type == AnchorType.ETHEREUM:
            if rpc_url is None:
                raise ValueError(
                    "rpc_url is required for Ethereum anchoring. "
                    "Provide an L2 JSON-RPC endpoint."
                )
            tx_hash = self.anchor_to_ethereum(merkle_root, rpc_url)
            metadata["rpc_url"] = rpc_url
            metadata["chain_id"] = self._chain_id
            if self._contract_address:
                metadata["contract"] = self._contract_address

        elif anchor_type == AnchorType.RFC3161:
            if tsa_url is None:
                raise ValueError(
                    "tsa_url is required for RFC 3161 timestamping. "
                    "Provide a TSA endpoint URL."
                )
            timestamp_token = self.anchor_to_rfc3161(merkle_root, tsa_url)
            metadata["tsa_url"] = tsa_url

        dag_serialized = dag.to_json()

        receipt = AnchorReceipt(
            receipt_id=receipt_id,
            merkle_root=merkle_root,
            anchor_type=anchor_type,
            timestamp=now,
            dag_node_count=len(dag.nodes),
            tx_hash=tx_hash,
            timestamp_token=timestamp_token,
            metadata=metadata,
            dag_serialized=dag_serialized,
        )

        self._receipts[receipt_id] = receipt
        return receipt

    # -----------------------------------------------------------------
    # Ethereum L2 anchoring
    # -----------------------------------------------------------------

    def anchor_to_ethereum(self, merkle_root: bytes, rpc_url: str) -> str:
        """Anchor a Merkle root to an EVM-compatible L2 chain.

        Constructs and sends an ``eth_sendRawTransaction`` containing the
        Merkle root in the transaction ``data`` field, prefixed with the
        4-byte Keccak-256 selector of ``anchor(bytes32)``.  The
        transaction is signed locally with the configured private key so
        no unlocked accounts on the RPC node are required.

        The implementation handles:

        - Nonce management via ``eth_getTransactionCount``.
        - Gas estimation via ``eth_estimateGas`` with a configurable
          multiplier and hard-cap sanity check.
        - Gas price via ``eth_gasPrice``.
        - EIP-155 replay-protection using the configured chain ID.
        - Proper RLP encoding and Keccak-256 transaction hashing.
        - ECDSA signing on secp256k1 (pure Python, no C extension).

        Works with any EVM-compatible L2: Arbitrum, Optimism, Base,
        Polygon, zkSync Era, Scroll, Linea, etc.

        Args:
            merkle_root: 32-byte Merkle root hash to anchor.
            rpc_url: JSON-RPC endpoint URL for the L2 chain.

        Returns:
            Transaction hash as a ``0x``-prefixed hex string.

        Raises:
            ValueError: If no private key is configured.
            RuntimeError: On RPC errors, insufficient funds, gas
                estimation failures, or transaction rejection.
            ConnectionError: If the RPC endpoint is unreachable.
        """
        if self._private_key is None:
            raise ValueError(
                "Ethereum anchoring requires a private key. "
                "Pass private_key= to ProvenanceAnchor() or set the "
                "PROVEIT_ETH_PRIVATE_KEY environment variable."
            )

        if len(merkle_root) != 32:
            raise ValueError(
                f"Expected 32-byte Merkle root, got {len(merkle_root)} bytes."
            )

        # -- Derive sender address --
        sender = _private_key_to_address(self._private_key)
        logger.debug("Ethereum anchor sender address: %s", sender)

        # -- Calldata: anchor(bytes32) --
        # ABI: 4-byte selector + 32-byte argument (already aligned)
        calldata = self._ANCHOR_SELECTOR + merkle_root

        # -- Destination --
        to_addr = self._contract_address or sender  # self-send if no contract

        # -- Fetch nonce --
        nonce_hex = _json_rpc(rpc_url, "eth_getTransactionCount", [sender, "pending"])
        nonce = int(nonce_hex, 16)
        logger.debug("Nonce for %s: %d", sender, nonce)

        # -- Gas price --
        gas_price_hex = _json_rpc(rpc_url, "eth_gasPrice", [])
        gas_price = int(gas_price_hex, 16)
        # Apply a 10% buffer to avoid under-priced rejections
        gas_price = gas_price + gas_price // 10
        logger.debug("Gas price (with buffer): %d wei", gas_price)

        # -- Estimate gas --
        estimate_tx = {
            "from": sender,
            "to": to_addr,
            "data": "0x" + calldata.hex(),
            "value": "0x0",
        }
        try:
            gas_estimate_hex = _json_rpc(rpc_url, "eth_estimateGas", [estimate_tx])
            gas_limit = int(gas_estimate_hex, 16)
            # Add 20% safety margin
            gas_limit = gas_limit + gas_limit // 5
        except RuntimeError as exc:
            # If estimation fails (e.g. no contract deployed), use a
            # reasonable default for a simple data-carrying transaction.
            logger.warning("Gas estimation failed (%s), using default 100000", exc)
            gas_limit = 100_000

        # Sanity cap at 500k gas (anchoring should never need more)
        if gas_limit > 500_000:
            gas_limit = 500_000

        logger.debug("Gas limit: %d", gas_limit)

        # -- Check balance --
        balance_hex = _json_rpc(rpc_url, "eth_getBalance", [sender, "latest"])
        balance = int(balance_hex, 16)
        required = gas_limit * gas_price
        if balance < required:
            raise RuntimeError(
                f"Insufficient funds for gas: balance={balance} wei, "
                f"required={required} wei (gas_limit={gas_limit}, "
                f"gas_price={gas_price}). Fund address {sender}."
            )

        # -- Build unsigned transaction fields (legacy EIP-155) --
        # [nonce, gasPrice, gasLimit, to, value, data, chainId, 0, 0]
        to_bytes_raw = bytes.fromhex(to_addr[2:] if to_addr.startswith("0x") else to_addr)
        unsigned_fields = [
            _int_to_rlp_bytes(nonce),
            _int_to_rlp_bytes(gas_price),
            _int_to_rlp_bytes(gas_limit),
            to_bytes_raw,
            b"",  # value = 0
            calldata,
            _int_to_rlp_bytes(self._chain_id),
            b"",  # EIP-155 r placeholder
            b"",  # EIP-155 s placeholder
        ]
        unsigned_rlp = _rlp_encode(unsigned_fields)

        # -- Hash and sign --
        tx_hash_bytes = _keccak256(unsigned_rlp)
        v_raw, r, s = _ecdsa_sign(tx_hash_bytes, self._private_key)

        # EIP-155 v = recovery_id + chain_id * 2 + 35
        v = v_raw + self._chain_id * 2 + 35

        # -- Build signed transaction --
        signed_fields = [
            _int_to_rlp_bytes(nonce),
            _int_to_rlp_bytes(gas_price),
            _int_to_rlp_bytes(gas_limit),
            to_bytes_raw,
            b"",  # value = 0
            calldata,
            _int_to_rlp_bytes(v),
            _int_to_rlp_bytes(r),
            _int_to_rlp_bytes(s),
        ]
        signed_rlp = _rlp_encode(signed_fields)
        raw_tx_hex = "0x" + signed_rlp.hex()

        # -- Submit --
        result = _json_rpc(rpc_url, "eth_sendRawTransaction", [raw_tx_hex])

        if not result or not isinstance(result, str):
            raise RuntimeError(
                f"eth_sendRawTransaction returned unexpected result: {result!r}"
            )

        logger.info(
            "Merkle root anchored to chain %d in tx %s",
            self._chain_id, result,
        )
        return result

    # -----------------------------------------------------------------
    # RFC 3161 timestamping
    # -----------------------------------------------------------------

    def anchor_to_rfc3161(self, merkle_root: bytes, tsa_url: str) -> bytes:
        """Obtain an RFC 3161 timestamp token for a Merkle root.

        Builds a DER-encoded ``TimeStampReq`` (RFC 3161 section 2.4.1)
        containing the SHA-256 digest of the Merkle root as the message
        imprint, a random nonce, and ``certReq=TRUE``.  Sends the
        request to the TSA via HTTP POST and parses the
        ``TimeStampResp``.

        The response is validated:
        - The outer ``PKIStatusInfo.status`` must be ``granted`` (0) or
          ``grantedWithMods`` (1).
        - The embedded ``TimeStampToken`` (CMS ``ContentInfo``) is
          extracted and returned as raw DER bytes.

        Uses only ``urllib.request`` -- no ``requests`` dependency.

        Args:
            merkle_root: 32-byte Merkle root hash.
            tsa_url: URL of the RFC 3161 Time Stamping Authority.

        Returns:
            DER-encoded ``TimeStampToken`` bytes (a CMS ContentInfo).

        Raises:
            RuntimeError: If the TSA returns an error status.
            ConnectionError: If the TSA is unreachable.
        """
        ts_request = self._build_rfc3161_request(merkle_root)

        req = urllib.request.Request(
            tsa_url,
            data=ts_request,
            headers={
                "Content-Type": "application/timestamp-query",
                "Accept": "application/timestamp-reply",
            },
            method="POST",
        )

        ctx = ssl.create_default_context()

        try:
            with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
                response_bytes = resp.read()
        except urllib.error.URLError as exc:
            raise ConnectionError(
                f"Failed to connect to TSA at {tsa_url}: {exc}"
            ) from exc
        except urllib.error.HTTPError as exc:
            raise RuntimeError(
                f"TSA HTTP error {exc.code}: {exc.reason}"
            ) from exc

        # Parse TimeStampResp and extract token
        token = self._parse_rfc3161_response(response_bytes)
        logger.info(
            "RFC 3161 timestamp token obtained (%d bytes) from %s",
            len(token), tsa_url,
        )
        return token

    @staticmethod
    def _build_rfc3161_request(merkle_root: bytes) -> bytes:
        """Build a DER-encoded RFC 3161 TimeStampReq.

        Structure (ASN.1)::

            TimeStampReq ::= SEQUENCE {
                version         INTEGER  { v1(1) },
                messageImprint  MessageImprint,
                nonce           INTEGER,
                certReq         BOOLEAN DEFAULT FALSE
            }
            MessageImprint ::= SEQUENCE {
                hashAlgorithm   AlgorithmIdentifier,
                hashedMessage   OCTET STRING
            }

        The hash algorithm is SHA-256.  A 128-bit random nonce is
        included to prevent replay attacks.  ``certReq`` is set to
        ``TRUE`` so the TSA includes its signing certificate in the
        response for offline verification.
        """
        # SHA-256 AlgorithmIdentifier: SEQUENCE { OID, NULL }
        algo_id = _der_sequence(
            _der_oid(_SHA256_OID_BYTES) + b"\x05\x00"
        )

        # MessageImprint
        digest = hashlib.sha256(merkle_root).digest()
        message_imprint = _der_sequence(algo_id + _der_octet_string(digest))

        # version INTEGER 1
        version = _der_integer(1)

        # Random nonce (128 bits)
        nonce_int = int.from_bytes(os.urandom(16), "big")
        nonce = _der_integer(nonce_int)

        # certReq BOOLEAN TRUE
        cert_req = _der_boolean(True)

        return _der_sequence(version + message_imprint + nonce + cert_req)

    @staticmethod
    def _parse_rfc3161_response(data: bytes) -> bytes:
        """Parse a DER-encoded TimeStampResp and extract the token.

        TimeStampResp ::= SEQUENCE {
            status          PKIStatusInfo,
            timeStampToken  TimeStampToken OPTIONAL
        }

        PKIStatusInfo ::= SEQUENCE {
            status        PKIStatus,
            ...
        }

        PKIStatus ::= INTEGER {
            granted                (0),
            grantedWithMods        (1),
            rejection              (2),
            waiting                (3),
            revocationWarning      (4),
            revocationNotification (5)
        }

        Returns the raw TimeStampToken bytes (the second element of the
        outer SEQUENCE).

        Raises:
            RuntimeError: If the status is not granted or the response
                is malformed.
        """
        # Outer SEQUENCE
        tag, total_len, offset = _der_parse_tag_length(data, 0)
        if tag != 0x30:
            raise RuntimeError(
                f"Expected SEQUENCE (0x30) at start of TimeStampResp, got 0x{tag:02x}"
            )

        # First element: PKIStatusInfo SEQUENCE
        tag2, status_len, status_offset = _der_parse_tag_length(data, offset)
        if tag2 != 0x30:
            raise RuntimeError(
                f"Expected SEQUENCE for PKIStatusInfo, got 0x{tag2:02x}"
            )
        status_info_end = status_offset + status_len

        # PKIStatus INTEGER inside PKIStatusInfo
        tag3, int_len, int_offset = _der_parse_tag_length(data, status_offset)
        if tag3 != 0x02:
            raise RuntimeError(
                f"Expected INTEGER for PKIStatus, got 0x{tag3:02x}"
            )
        status_value = int.from_bytes(data[int_offset:int_offset + int_len], "big")

        if status_value > 1:
            status_names = {
                2: "rejection", 3: "waiting",
                4: "revocationWarning", 5: "revocationNotification",
            }
            name = status_names.get(status_value, f"unknown({status_value})")
            raise RuntimeError(
                f"TSA returned non-granted status: {name} ({status_value})"
            )

        # TimeStampToken is everything after PKIStatusInfo
        token_start = status_info_end
        if token_start >= len(data):
            raise RuntimeError(
                "TimeStampResp has granted status but no TimeStampToken"
            )

        return data[token_start:]

    @staticmethod
    def _build_local_timestamp_token(merkle_root: bytes) -> bytes:
        """Build a locally-signed timestamp token when TSA is unreachable.

        This is NOT a true RFC 3161 token but preserves the Merkle root
        binding with a keyed HMAC so verification can still detect
        tampering of the root.  The token format is:

        ``merkle_root (32) || timestamp (8) || nonce (16) || hmac (32)``
        """
        timestamp_bytes = struct.pack(">d", time.time())
        nonce = os.urandom(16)
        payload = merkle_root + timestamp_bytes + nonce
        signature = hmac.new(
            b"hydra24_local_tsa_key", payload, hashlib.sha256
        ).digest()
        return payload + signature

    # -----------------------------------------------------------------
    # Verification
    # -----------------------------------------------------------------

    def verify_anchor(
        self,
        receipt: AnchorReceipt,
        rpc_url: Optional[str] = None,
    ) -> VerificationResult:
        """Verify that an anchored DAG has not been tampered with.

        Performs a multi-layer verification:

        1. **Merkle root recomputation**: Rebuilds the Merkle tree from
           the stored DAG snapshot and checks that the root matches the
           receipt.
        2. **Ethereum on-chain verification** (if ``anchor_type`` is
           ``ETHEREUM`` and ``rpc_url`` is provided): Queries
           ``eth_getTransactionByHash`` to confirm the transaction
           exists on-chain and that its ``input`` (calldata) contains
           the expected Merkle root.
        3. **RFC 3161 token verification** (if ``anchor_type`` is
           ``RFC3161``): Parses the timestamp token to extract the
           embedded message imprint and checks that it matches the
           SHA-256 digest of the Merkle root.
        4. **Local HMAC verification** (if the token is a local
           fallback): Verifies the HMAC binding.

        Args:
            receipt: The AnchorReceipt to verify.
            rpc_url: Optional Ethereum RPC URL for on-chain verification.
                Falls back to ``receipt.metadata["rpc_url"]`` if available.

        Returns:
            VerificationResult indicating whether verification passed.
        """
        details: Dict[str, Any] = {
            "receipt_id": receipt.receipt_id,
            "anchor_type": receipt.anchor_type.value,
            "node_count": receipt.dag_node_count,
        }

        # -- Step 1: Recompute Merkle root from DAG snapshot --

        if receipt.dag_serialized is None:
            return VerificationResult(
                verified=False,
                message="Cannot verify: DAG snapshot not available in receipt.",
                anchor_timestamp=receipt.timestamp,
                merkle_root_match=False,
                details=details,
            )

        try:
            dag_dict = json.loads(receipt.dag_serialized)
        except (json.JSONDecodeError, TypeError) as exc:
            return VerificationResult(
                verified=False,
                message=f"Cannot verify: DAG snapshot is corrupted ({exc}).",
                anchor_timestamp=receipt.timestamp,
                merkle_root_match=False,
                details=details,
            )

        dag = _reconstruct_dag_from_dict(dag_dict)
        tree = _dag_to_merkle_tree(dag)
        recomputed_root = tree.get_root()
        root_match = recomputed_root == receipt.merkle_root

        details["recomputed_root"] = recomputed_root.hex()
        details["stored_root"] = receipt.merkle_root.hex()

        if not root_match:
            return VerificationResult(
                verified=False,
                message=(
                    "VERIFICATION FAILED: Merkle root mismatch. "
                    "The DAG has been tampered with since anchoring."
                ),
                anchor_timestamp=receipt.timestamp,
                merkle_root_match=False,
                details=details,
            )

        # -- Step 2: Anchor-type-specific verification --

        if receipt.anchor_type == AnchorType.ETHEREUM and receipt.tx_hash:
            eth_result = self._verify_ethereum_anchor(
                receipt, rpc_url
            )
            details.update(eth_result)

        elif receipt.anchor_type == AnchorType.RFC3161 and receipt.timestamp_token:
            rfc_result = self._verify_rfc3161_anchor(receipt)
            details.update(rfc_result)

        return VerificationResult(
            verified=True,
            message=(
                f"Anchor verified. Merkle root matches across "
                f"{receipt.dag_node_count} DAG nodes. "
                f"Anchored at {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime(receipt.timestamp))}."
            ),
            anchor_timestamp=receipt.timestamp,
            merkle_root_match=True,
            details=details,
        )

    def _verify_ethereum_anchor(
        self,
        receipt: AnchorReceipt,
        rpc_url: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Verify an Ethereum anchor by querying the transaction on-chain.

        Calls ``eth_getTransactionByHash`` and checks:
        - The transaction exists (not null).
        - The transaction ``input`` field contains the expected
          ``anchor(bytes32)`` calldata with the correct Merkle root.
        - The transaction has been included in a block (``blockNumber``
          is not null).

        Returns a dict of verification details to merge into the
        result's ``details``.
        """
        result: Dict[str, Any] = {
            "tx_hash": receipt.tx_hash,
        }

        effective_rpc = rpc_url or receipt.metadata.get("rpc_url")
        if not effective_rpc:
            result["ethereum_verified"] = "skipped_no_rpc_url"
            return result

        try:
            tx_data = _json_rpc(
                effective_rpc,
                "eth_getTransactionByHash",
                [receipt.tx_hash],
            )
        except (ConnectionError, RuntimeError) as exc:
            result["ethereum_verified"] = f"rpc_error: {exc}"
            return result

        if tx_data is None:
            result["ethereum_verified"] = "tx_not_found"
            return result

        # Check that the calldata matches
        tx_input = tx_data.get("input", "")
        expected_calldata = "0x" + self._ANCHOR_SELECTOR.hex() + receipt.merkle_root.hex()

        if tx_input.lower() == expected_calldata.lower():
            result["ethereum_calldata_match"] = True
        else:
            result["ethereum_calldata_match"] = False
            result["ethereum_expected_calldata"] = expected_calldata
            result["ethereum_actual_calldata"] = tx_input

        # Check block inclusion
        block_number = tx_data.get("blockNumber")
        if block_number is not None:
            result["ethereum_block_number"] = int(block_number, 16)
            result["ethereum_verified"] = "confirmed_on_chain"
        else:
            result["ethereum_verified"] = "pending_not_mined"

        # Include sender and recipient
        result["ethereum_from"] = tx_data.get("from", "")
        result["ethereum_to"] = tx_data.get("to", "")

        return result

    def _verify_rfc3161_anchor(
        self,
        receipt: AnchorReceipt,
    ) -> Dict[str, Any]:
        """Verify an RFC 3161 timestamp token.

        Parses the CMS ContentInfo structure of the TimeStampToken to
        locate the ``MessageImprint`` inside the ``TSTInfo`` and checks
        that its digest matches ``SHA-256(merkle_root)``.

        Full PKI signature chain verification is not performed (that
        would require the TSA's certificate chain and a trust store).
        This method verifies the *binding* between the token and the
        Merkle root -- i.e., that the token is about this specific root.

        Also handles locally-generated fallback tokens by checking the
        HMAC binding.

        Returns a dict of verification details.
        """
        result: Dict[str, Any] = {
            "rfc3161_token_size": len(receipt.timestamp_token),
        }

        token = receipt.timestamp_token

        # Detect local fallback token (fixed size: 32 + 8 + 16 + 32 = 88 bytes)
        if len(token) == 88:
            embedded_root = token[:32]
            payload = token[:56]  # root + timestamp + nonce
            token_hmac = token[56:]
            expected_hmac = hmac.new(
                b"hydra24_local_tsa_key", payload, hashlib.sha256
            ).digest()
            if hmac.compare_digest(token_hmac, expected_hmac):
                if embedded_root == receipt.merkle_root:
                    result["rfc3161_verified"] = "local_token_valid"
                    result["rfc3161_local_token"] = True
                    ts_float = struct.unpack(">d", token[32:40])[0]
                    result["rfc3161_token_timestamp"] = ts_float
                else:
                    result["rfc3161_verified"] = "local_token_root_mismatch"
                    result["rfc3161_local_token"] = True
            else:
                result["rfc3161_verified"] = "local_token_hmac_invalid"
                result["rfc3161_local_token"] = True
            return result

        # Attempt to parse as a real CMS/PKCS#7 TimeStampToken
        expected_digest = hashlib.sha256(receipt.merkle_root).digest()
        try:
            digest_match = self._extract_tst_digest_match(token, expected_digest)
            if digest_match:
                result["rfc3161_verified"] = "token_digest_verified"
                result["rfc3161_digest_match"] = True
            else:
                result["rfc3161_verified"] = "token_digest_mismatch"
                result["rfc3161_digest_match"] = False
        except (ValueError, IndexError, KeyError) as exc:
            # If parsing fails, fall back to a byte-scan for the digest
            logger.warning("RFC 3161 token parsing failed: %s", exc)
            if expected_digest in token:
                result["rfc3161_verified"] = "token_contains_digest"
                result["rfc3161_digest_match"] = True
            else:
                result["rfc3161_verified"] = f"parse_error: {exc}"
                result["rfc3161_digest_match"] = False

        return result

    @staticmethod
    def _extract_tst_digest_match(token: bytes, expected_digest: bytes) -> bool:
        """Walk a CMS TimeStampToken to find the TSTInfo messageImprint
        and compare its digest against the expected value.

        The CMS structure is::

            ContentInfo ::= SEQUENCE {
                contentType   OID (signedData),
                content       [0] EXPLICIT SignedData
            }
            SignedData ::= SEQUENCE {
                version,
                digestAlgorithms,
                encapContentInfo  EncapsulatedContentInfo,
                ...
            }
            EncapsulatedContentInfo ::= SEQUENCE {
                eContentType  OID (id-smime-ct-TSTInfo),
                eContent      [0] EXPLICIT OCTET STRING containing TSTInfo
            }
            TSTInfo ::= SEQUENCE {
                version         INTEGER,
                policy          OID,
                messageImprint  MessageImprint,
                ...
            }
            MessageImprint ::= SEQUENCE {
                hashAlgorithm  AlgorithmIdentifier,
                hashedMessage  OCTET STRING
            }

        Rather than fully parsing every field, we navigate through the
        structure level by level, skipping over elements by their
        encoded lengths, until we reach the ``hashedMessage`` OCTET
        STRING inside the ``MessageImprint``.
        """
        pos = 0

        # ContentInfo SEQUENCE
        tag, length, pos = _der_parse_tag_length(token, pos)
        if tag != 0x30:
            raise ValueError("Expected ContentInfo SEQUENCE")

        # contentType OID -- skip it
        tag, length, pos = _der_parse_tag_length(token, pos)
        pos += length

        # content [0] EXPLICIT
        tag, length, pos = _der_parse_tag_length(token, pos)
        # tag should be 0xa0 (context-specific constructed 0)

        # SignedData SEQUENCE
        tag, length, pos = _der_parse_tag_length(token, pos)
        if tag != 0x30:
            raise ValueError("Expected SignedData SEQUENCE")
        signed_data_end = pos + length

        # version INTEGER -- skip
        tag, length, pos = _der_parse_tag_length(token, pos)
        pos += length

        # digestAlgorithms SET -- skip
        tag, length, pos = _der_parse_tag_length(token, pos)
        pos += length

        # encapContentInfo SEQUENCE
        tag, length, pos = _der_parse_tag_length(token, pos)
        if tag != 0x30:
            raise ValueError("Expected EncapsulatedContentInfo SEQUENCE")
        encap_end = pos + length

        # eContentType OID -- skip
        tag, length, pos = _der_parse_tag_length(token, pos)
        pos += length

        # eContent [0] EXPLICIT
        tag, length, pos = _der_parse_tag_length(token, pos)

        # OCTET STRING containing TSTInfo
        tag, length, pos = _der_parse_tag_length(token, pos)
        if tag != 0x04:
            raise ValueError("Expected OCTET STRING for TSTInfo")
        tst_info_bytes = token[pos:pos + length]

        # Parse TSTInfo SEQUENCE
        tst_pos = 0
        tag, length, tst_pos = _der_parse_tag_length(tst_info_bytes, tst_pos)
        if tag != 0x30:
            raise ValueError("Expected TSTInfo SEQUENCE")

        # version INTEGER -- skip
        tag, length, tst_pos = _der_parse_tag_length(tst_info_bytes, tst_pos)
        tst_pos += length

        # policy OID -- skip
        tag, length, tst_pos = _der_parse_tag_length(tst_info_bytes, tst_pos)
        tst_pos += length

        # messageImprint SEQUENCE
        tag, length, tst_pos = _der_parse_tag_length(tst_info_bytes, tst_pos)
        if tag != 0x30:
            raise ValueError("Expected MessageImprint SEQUENCE")
        mi_bytes = tst_info_bytes[tst_pos:tst_pos + length]

        # hashAlgorithm AlgorithmIdentifier -- skip
        mi_pos = 0
        tag, length, mi_pos = _der_parse_tag_length(mi_bytes, mi_pos)
        mi_pos += length

        # hashedMessage OCTET STRING
        tag, length, mi_pos = _der_parse_tag_length(mi_bytes, mi_pos)
        if tag != 0x04:
            raise ValueError("Expected OCTET STRING for hashedMessage")
        actual_digest = mi_bytes[mi_pos:mi_pos + length]

        return actual_digest == expected_digest

    # -----------------------------------------------------------------
    # Receipt management
    # -----------------------------------------------------------------

    def get_receipt(self, receipt_id: str) -> Optional[AnchorReceipt]:
        """Look up a receipt by ID."""
        return self._receipts.get(receipt_id)

    def list_receipts(self) -> List[AnchorReceipt]:
        """List all stored receipts."""
        return list(self._receipts.values())


# =============================================================================
# DAG Reconstruction from Serialized Dict
# =============================================================================

def _reconstruct_dag_from_dict(data: Dict[str, Any]) -> ComputationDAG:
    """Reconstruct a ComputationDAG from its to_dict() output.

    Used during verification to rebuild the DAG and recompute the
    Merkle root.
    """
    from .hydra24_dag import DAGNode, DAGEdge, NodeType, ComputationDAG

    nodes: Dict[int, DAGNode] = {}
    for nid_str, ndata in data.get("nodes", {}).items():
        nid = int(nid_str)
        nodes[nid] = DAGNode(
            node_id=ndata["id"],
            node_type=NodeType[ndata["type"]],
            operation=ndata["operation"],
            inputs=ndata["inputs"],
            provenance=int(ndata["provenance"], 16) if isinstance(ndata["provenance"], str) else ndata["provenance"],
            table=ndata.get("table"),
            column=ndata.get("column"),
            pair_id=ndata.get("pair_id"),
            is_protected=ndata.get("is_protected", False),
            metadata=ndata.get("metadata", {}),
        )

    edges: List[DAGEdge] = []
    for edata in data.get("edges", []):
        edges.append(DAGEdge(
            source_id=edata["source"],
            target_id=edata["target"],
            input_index=edata["input_index"],
        ))

    return ComputationDAG(
        root_id=data["root_id"],
        nodes=nodes,
        edges=edges,
    )


# =============================================================================
# Batch Anchor
# =============================================================================

@dataclass
class BatchProof:
    """Proof that an individual DAG's Merkle root is included in a batch.

    Combines the individual DAG's local anchor receipt with a Merkle
    inclusion proof into the batch tree, plus the batch receipt itself.
    This enables any third party to verify that a specific DAG was part
    of a particular on-chain or timestamped batch anchor without
    needing the full set of DAGs.

    Attributes:
        individual_receipt: The per-DAG AnchorReceipt (local anchor).
        batch_receipt: The AnchorReceipt for the overall batch.
        inclusion_proof: MerkleProof showing the DAG root is a leaf
            in the batch Merkle tree.
    """
    individual_receipt: AnchorReceipt
    batch_receipt: AnchorReceipt
    inclusion_proof: MerkleProof

    def verify(self) -> bool:
        """Verify this batch proof end-to-end.

        Checks that the individual DAG's Merkle root, when used as leaf
        data, is validated by the inclusion proof against the batch
        receipt's Merkle root.
        """
        return MerkleTree.verify_proof(
            self.inclusion_proof,
            self.batch_receipt.merkle_root,
            self.individual_receipt.merkle_root,
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "individual_receipt_id": self.individual_receipt.receipt_id,
            "individual_merkle_root": self.individual_receipt.merkle_root.hex(),
            "batch_receipt_id": self.batch_receipt.receipt_id,
            "batch_merkle_root": self.batch_receipt.merkle_root.hex(),
            "inclusion_proof": self.inclusion_proof.to_dict(),
        }


class BatchAnchor:
    """
    Batches multiple DAG anchors into periodic bulk anchoring operations.

    Instead of anchoring each DAG individually (which may be costly for
    on-chain operations), BatchAnchor accumulates DAGs and periodically
    builds a single Merkle tree over all their individual roots, anchoring
    the combined root.

    This amortizes anchoring cost across many DAGs while maintaining
    the ability to produce Merkle inclusion proofs for any individual
    DAG via :meth:`get_proof_for_dag`.

    Cost model: A single Ethereum L2 transaction costs roughly 21,000
    base gas + calldata gas.  Anchoring N DAGs individually costs
    N * tx_cost.  Batching amortizes to tx_cost / N per DAG, plus a
    tiny constant for the local Merkle tree construction.

    Args:
        anchor: ProvenanceAnchor instance for performing anchors.
        anchor_type: Default anchor type for batch anchors.
        batch_interval_seconds: Seconds between automatic batch flushes.
            Set to 0 to disable automatic flushing (manual only).
        rpc_url: Ethereum RPC URL (if using ethereum anchoring).
        tsa_url: TSA URL (if using rfc3161 anchoring).

    Example::

        anchor = ProvenanceAnchor(private_key="0x...")
        batch = BatchAnchor(
            anchor,
            anchor_type=AnchorType.ETHEREUM,
            rpc_url="https://arb1.arbitrum.io/rpc",
            batch_interval_seconds=300,
        )
        batch.start()

        r1 = batch.add_dag(dag1)
        r2 = batch.add_dag(dag2)
        r3 = batch.add_dag(dag3)

        batch_receipt = batch.stop()

        # Get a proof that dag2 was in the batch
        proof = batch.get_proof_for_dag(r2.receipt_id)
        assert proof.verify()
    """

    def __init__(
        self,
        anchor: ProvenanceAnchor,
        anchor_type: AnchorType = AnchorType.LOCAL,
        batch_interval_seconds: float = 300.0,
        rpc_url: Optional[str] = None,
        tsa_url: Optional[str] = None,
    ) -> None:
        self._anchor = anchor
        self._anchor_type = anchor_type
        self._interval = batch_interval_seconds
        self._rpc_url = rpc_url
        self._tsa_url = tsa_url

        self._pending_dags: List[ComputationDAG] = []
        self._pending_roots: List[bytes] = []
        self._individual_receipts: List[AnchorReceipt] = []
        self._batch_receipts: List[AnchorReceipt] = []
        self._dag_to_batch_index: Dict[str, int] = {}

        # Proof storage: maps individual receipt_id -> BatchProof
        self._batch_proofs: Dict[str, BatchProof] = {}
        # Stores the last batch tree for proof generation
        self._last_batch_tree: Optional[MerkleTree] = None
        self._last_batch_individual_ids: List[str] = []
        self._last_batch_individual_receipts: Dict[str, AnchorReceipt] = {}

        self._lock = threading.Lock()
        self._timer: Optional[threading.Timer] = None
        self._running = False

    def add_dag(self, dag: ComputationDAG) -> AnchorReceipt:
        """Add a DAG to the current batch.

        The DAG is immediately anchored locally (to capture its
        individual Merkle root) and queued for the next batch anchor.

        Args:
            dag: ComputationDAG to add.

        Returns:
            Individual AnchorReceipt for the DAG (local anchor).
        """
        individual_receipt = self._anchor.anchor_dag(
            dag, anchor_type=AnchorType.LOCAL
        )

        with self._lock:
            batch_idx = len(self._pending_roots)
            self._pending_dags.append(dag)
            self._pending_roots.append(individual_receipt.merkle_root)
            self._individual_receipts.append(individual_receipt)
            self._dag_to_batch_index[individual_receipt.receipt_id] = batch_idx

        return individual_receipt

    def flush(self) -> Optional[AnchorReceipt]:
        """Flush the current batch immediately.

        Builds a Merkle tree over all pending DAG roots, anchors the
        combined root, and generates inclusion proofs for each
        individual DAG.

        Returns:
            AnchorReceipt for the batch, or None if batch is empty.
        """
        with self._lock:
            if not self._pending_roots:
                return None

            roots = list(self._pending_roots)
            dag_count = len(self._pending_dags)
            individual_ids = [r.receipt_id for r in self._individual_receipts]
            individual_receipts_snapshot = {
                r.receipt_id: r for r in self._individual_receipts
            }

            self._pending_dags.clear()
            self._pending_roots.clear()
            self._individual_receipts.clear()
            self._dag_to_batch_index.clear()

        batch_tree = MerkleTree()
        for root in roots:
            batch_tree.add_leaf(root)
        batch_tree.build()

        batch_root = batch_tree.get_root()
        now = time.time()
        receipt_id = str(uuid.uuid4())

        tx_hash: Optional[str] = None
        timestamp_token: Optional[bytes] = None

        if self._anchor_type == AnchorType.ETHEREUM and self._rpc_url:
            tx_hash = self._anchor.anchor_to_ethereum(batch_root, self._rpc_url)
        elif self._anchor_type == AnchorType.RFC3161 and self._tsa_url:
            timestamp_token = self._anchor.anchor_to_rfc3161(batch_root, self._tsa_url)

        batch_receipt = AnchorReceipt(
            receipt_id=receipt_id,
            merkle_root=batch_root,
            anchor_type=self._anchor_type,
            timestamp=now,
            dag_node_count=dag_count,
            tx_hash=tx_hash,
            timestamp_token=timestamp_token,
            metadata={
                "batch": True,
                "individual_receipt_ids": individual_ids,
                "individual_roots": [r.hex() for r in roots],
                "amortized_cost_factor": dag_count,
            },
        )

        self._batch_receipts.append(batch_receipt)
        self._anchor._receipts[receipt_id] = batch_receipt

        # Generate and store inclusion proofs for each individual DAG
        self._last_batch_tree = batch_tree
        self._last_batch_individual_ids = individual_ids
        self._last_batch_individual_receipts.update(individual_receipts_snapshot)

        for leaf_idx, ind_id in enumerate(individual_ids):
            ind_receipt = individual_receipts_snapshot[ind_id]
            proof = batch_tree.get_proof(leaf_idx)
            batch_proof = BatchProof(
                individual_receipt=ind_receipt,
                batch_receipt=batch_receipt,
                inclusion_proof=proof,
            )
            self._batch_proofs[ind_id] = batch_proof

        logger.info(
            "Batch flush: %d DAGs anchored in batch %s (type=%s)",
            dag_count, receipt_id, self._anchor_type.value,
        )

        return batch_receipt

    def get_proof_for_dag(self, individual_receipt_id: str) -> Optional[BatchProof]:
        """Get the batch inclusion proof for an individual DAG.

        After a batch has been flushed, this returns a ``BatchProof``
        that cryptographically links the individual DAG's Merkle root
        to the batch's anchored Merkle root via a Merkle inclusion
        proof.

        Args:
            individual_receipt_id: The receipt ID returned by
                :meth:`add_dag`.

        Returns:
            A ``BatchProof`` if the DAG was part of a flushed batch,
            or ``None`` if not found.
        """
        return self._batch_proofs.get(individual_receipt_id)

    def get_all_proofs(self) -> Dict[str, BatchProof]:
        """Return all batch proofs generated so far.

        Returns:
            Dict mapping individual receipt IDs to their BatchProof.
        """
        return dict(self._batch_proofs)

    def start(self) -> None:
        """Start the automatic batch anchoring timer."""
        if self._running:
            return
        self._running = True
        if self._interval > 0:
            self._schedule_next()

    def stop(self) -> Optional[AnchorReceipt]:
        """Stop automatic anchoring and flush any remaining DAGs.

        Returns:
            AnchorReceipt for the final batch, or None if empty.
        """
        self._running = False
        if self._timer is not None:
            self._timer.cancel()
            self._timer = None
        return self.flush()

    def _schedule_next(self) -> None:
        """Schedule the next automatic flush."""
        if not self._running:
            return
        self._timer = threading.Timer(self._interval, self._auto_flush)
        self._timer.daemon = True
        self._timer.start()

    def _auto_flush(self) -> None:
        """Callback for automatic flush."""
        if not self._running:
            return
        self.flush()
        self._schedule_next()

    def get_batch_receipts(self) -> List[AnchorReceipt]:
        """Return all batch receipts produced so far."""
        return list(self._batch_receipts)

    @property
    def pending_count(self) -> int:
        """Number of DAGs waiting in the current batch."""
        with self._lock:
            return len(self._pending_roots)

    @property
    def total_batched(self) -> int:
        """Total number of DAGs that have been batched across all flushes."""
        return len(self._batch_proofs)
