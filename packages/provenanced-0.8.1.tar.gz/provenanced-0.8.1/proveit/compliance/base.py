"""
Base Compliance Engine for ProveIt Provenance DAGs.

Provides abstract base classes and result types for regulation-specific
compliance checks against computation DAGs produced by the ProveIt system.

Each compliance engine inspects a ComputationDAG (and optional metadata)
and returns structured findings with regulatory citations and remediation
recommendations.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Set

from ..hydra24_dag import ComputationDAG


ENGINE_VERSION = "1.0.0"


# ---------------------------------------------------------------------------
# Severity levels
# ---------------------------------------------------------------------------

class Severity(Enum):
    """Severity of a compliance finding."""
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


# ---------------------------------------------------------------------------
# Finding
# ---------------------------------------------------------------------------

@dataclass
class ComplianceFinding:
    """A single finding produced by a compliance check.

    Attributes:
        severity: How severe the issue is (INFO / WARNING / CRITICAL).
        description: Human-readable explanation of the finding.
        regulation_citation: Specific regulation reference (e.g. "Article 12(1)").
        affected_nodes: List of DAG node IDs implicated in the finding.
        remediation: Recommended corrective action.
    """
    severity: Severity
    description: str
    regulation_citation: str
    affected_nodes: List[int] = field(default_factory=list)
    remediation: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "severity": self.severity.value,
            "description": self.description,
            "regulation_citation": self.regulation_citation,
            "affected_nodes": self.affected_nodes,
            "remediation": self.remediation,
        }


# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------

@dataclass
class ComplianceResult:
    """Aggregate result of running a single compliance engine.

    Attributes:
        passed: Whether the DAG passed all checks for this regulation.
        regulation_name: Short canonical name (e.g. "EU AI Act", "ECOA / Reg B").
        findings: Individual findings (may be empty if fully compliant).
        citations: All regulation citations referenced by the engine.
        remediation_recommendations: Top-level remediation suggestions.
        timestamp: When the check was executed (UTC).
        metadata: Arbitrary extra data produced by the engine.
    """
    passed: bool
    regulation_name: str
    findings: List[ComplianceFinding] = field(default_factory=list)
    citations: List[str] = field(default_factory=list)
    remediation_recommendations: List[str] = field(default_factory=list)
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.CRITICAL)

    @property
    def warning_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.WARNING)

    @property
    def info_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.INFO)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "regulation": self.regulation_name,
            "regulation_name": self.regulation_name,
            "findings": [f.to_dict() for f in self.findings],
            "citations": self.citations,
            "remediation_recommendations": self.remediation_recommendations,
            "timestamp": self.timestamp.isoformat(),
            "engine_version": ENGINE_VERSION,
            "metadata": self.metadata,
            "summary": {
                "critical": self.critical_count,
                "warning": self.warning_count,
                "info": self.info_count,
                "total": len(self.findings),
            },
        }


# ---------------------------------------------------------------------------
# Base engine
# ---------------------------------------------------------------------------

class BaseComplianceEngine(ABC):
    """Abstract base class for regulation-specific compliance engines.

    Subclasses must implement ``check`` which inspects a ``ComputationDAG``
    (and optional metadata dictionary) and returns a ``ComplianceResult``.
    """

    @property
    @abstractmethod
    def regulation_name(self) -> str:
        """Short canonical name for the regulation this engine covers."""
        ...

    @abstractmethod
    def check(
        self,
        dag: ComputationDAG,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ComplianceResult:
        """Run all compliance checks against *dag*.

        Args:
            dag: The computation DAG to audit.
            metadata: Optional context such as model type, deployment info,
                      organizational policies, etc.

        Returns:
            A ``ComplianceResult`` with pass/fail, findings, and citations.
        """
        ...

    def run_all_checks(
        self,
        dag: ComputationDAG,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ComplianceResult:
        """Alias for ``check`` -- runs all compliance checks against *dag*.

        Provided for consistency across engines.  Delegates to ``check``.
        """
        return self.check(dag, metadata)


# ---------------------------------------------------------------------------
# Report (aggregates multiple engines)
# ---------------------------------------------------------------------------

class ComplianceReport:
    """Aggregates results from multiple compliance engines into one report.

    Usage::

        report = ComplianceReport()
        report.add(eu_engine.check(dag, meta))
        report.add(ecoa_engine.check(dag, meta))
        print(report.summary())
    """

    def __init__(self) -> None:
        self.results: List[ComplianceResult] = []
        self.generated_at: datetime = datetime.now(timezone.utc)

    # -- mutators -----------------------------------------------------------

    def add(self, result: ComplianceResult) -> None:
        """Append a ``ComplianceResult`` to the report."""
        self.results.append(result)

    def run_engines(
        self,
        engines: List[BaseComplianceEngine],
        dag: ComputationDAG,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ComplianceReport":
        """Convenience: run every engine against *dag* and collect results.

        Returns *self* for chaining.
        """
        for engine in engines:
            self.add(engine.check(dag, metadata))
        return self

    # -- queries ------------------------------------------------------------

    @property
    def overall_passed(self) -> bool:
        """True only if every engine's result passed."""
        if not self.results:
            return True
        return all(r.passed for r in self.results)

    @property
    def total_findings(self) -> int:
        return sum(len(r.findings) for r in self.results)

    @property
    def total_critical(self) -> int:
        return sum(r.critical_count for r in self.results)

    @property
    def total_warnings(self) -> int:
        return sum(r.warning_count for r in self.results)

    @staticmethod
    def _dedup_flat(nested: List[List[str]]) -> List[str]:
        """Order-preserving deduplication of items across nested lists."""
        seen: Set[str] = set()
        out: List[str] = []
        for sublist in nested:
            for item in sublist:
                if item not in seen:
                    seen.add(item)
                    out.append(item)
        return out

    @property
    def all_citations(self) -> List[str]:
        """De-duplicated list of all citations across engines."""
        return self._dedup_flat([r.citations for r in self.results])

    @property
    def all_remediation_recommendations(self) -> List[str]:
        return self._dedup_flat([r.remediation_recommendations for r in self.results])

    # -- serialization ------------------------------------------------------

    def summary(self) -> Dict[str, Any]:
        """Produce a human-readable summary dictionary."""
        return {
            "overall_passed": self.overall_passed,
            "generated_at": self.generated_at.isoformat(),
            "engines_run": len(self.results),
            "total_findings": self.total_findings,
            "total_critical": self.total_critical,
            "total_warnings": self.total_warnings,
            "per_regulation": {
                r.regulation_name: {
                    "passed": r.passed,
                    "critical": r.critical_count,
                    "warning": r.warning_count,
                    "info": r.info_count,
                }
                for r in self.results
            },
            "all_citations": self.all_citations,
            "all_remediation_recommendations": self.all_remediation_recommendations,
        }

    def examiner_summary(self) -> Dict[str, Any]:
        """Produce a structured summary formatted for regulatory examiners.

        Returns a dictionary organized by the categories OCC / Fed
        examiners review during fair lending and model risk examinations:

        1. **model_risk** -- SR 11-7 compliance indicators
        2. **fair_lending** -- ECOA / Reg B compliance status
        3. **data_governance** -- data lineage and provenance findings
        4. **action_items** -- prioritised list of remediation steps

        This format maps directly to the OCC's Model Risk Management
        Handbook and the Fed's Consumer Compliance Examination Manual.
        """
        model_risk: List[Dict[str, Any]] = []
        fair_lending: List[Dict[str, Any]] = []
        data_governance: List[Dict[str, Any]] = []

        for r in self.results:
            for f in r.findings:
                entry = {
                    "severity": f.severity.value,
                    "regulation": r.regulation_name,
                    "citation": f.regulation_citation,
                    "description": f.description,
                    "remediation": f.remediation,
                }
                cit = f.regulation_citation.lower()
                reg = r.regulation_name.lower()
                if "sr 11-7" in cit or "occ 2011" in cit or "sr 11-7" in reg:
                    model_risk.append(entry)
                elif "1002" in cit or "1691" in cit or "ecoa" in cit:
                    fair_lending.append(entry)
                else:
                    data_governance.append(entry)

        # Build prioritised action items (CRITICAL first, then WARNING)
        action_items: List[Dict[str, str]] = []
        for r in self.results:
            for f in r.findings:
                if f.severity == Severity.CRITICAL and f.remediation:
                    action_items.append({
                        "priority": "immediate",
                        "regulation": f.regulation_citation,
                        "action": f.remediation,
                    })
        for r in self.results:
            for f in r.findings:
                if f.severity == Severity.WARNING and f.remediation:
                    action_items.append({
                        "priority": "scheduled",
                        "regulation": f.regulation_citation,
                        "action": f.remediation,
                    })

        # Build model inventory from engine metadata
        model_inventory: Dict[str, Any] = {}
        for r in self.results:
            if r.metadata:
                for key in ("model_id", "model_version", "model_hash",
                            "has_validation", "has_monitoring"):
                    if key in r.metadata and r.metadata[key]:
                        model_inventory[key] = r.metadata[key]

        return {
            "report_date": self.generated_at.isoformat(),
            "overall_status": "PASS" if self.overall_passed else "FAIL",
            "critical_findings": self.total_critical,
            "warning_findings": self.total_warnings,
            "model_risk": model_risk,
            "fair_lending": fair_lending,
            "data_governance": data_governance,
            "model_inventory": model_inventory,
            "action_items": action_items,
            "regulations_checked": [r.regulation_name for r in self.results],
        }

    def to_dict(self) -> Dict[str, Any]:
        """Full serialization of the report."""
        return {
            "overall_passed": self.overall_passed,
            "generated_at": self.generated_at.isoformat(),
            "results": [r.to_dict() for r in self.results],
            "summary": self.summary(),
        }
