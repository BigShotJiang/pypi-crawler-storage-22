"""
Admin / Founder Dashboard: Platform-Wide Monitoring.

Shows all tenants, system health, pipeline stats, error rates,
global compliance posture, and alert overview.

Protected by a simple bearer token (ADMIN_TOKEN env var).

Usage:
    ADMIN_TOKEN=secret DASH_WRITER_DSN=postgresql://... python -m proveit.dashboard.admin_app
    # Then open: http://localhost:5004

For local development without Aurora, set DASH_MODE=demo for synthetic data.
"""

import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import time
from collections import defaultdict
from datetime import datetime, timezone
from functools import wraps

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from flask import Flask, jsonify, render_template, render_template_string, request, Response, redirect, make_response

logger = logging.getLogger(__name__)

app = Flask(__name__)


class _ReverseProxied:
    """WSGI middleware that adjusts SCRIPT_NAME from X-Script-Name header."""
    def __init__(self, wsgi_app):
        self.app = wsgi_app

    def __call__(self, environ, start_response):
        script_name = environ.get("HTTP_X_SCRIPT_NAME", "")
        if script_name:
            environ["SCRIPT_NAME"] = script_name
            path_info = environ.get("PATH_INFO", "")
            if path_info.startswith(script_name):
                environ["PATH_INFO"] = path_info[len(script_name):]
        return self.app(environ, start_response)


app.wsgi_app = _ReverseProxied(app.wsgi_app)

ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN")
DASH_MODE = os.environ.get("DASH_MODE", "demo")
DASH_DB_PATH = os.environ.get("DASH_DB_PATH", "")

TIER_PRICING = {
    "enterprise": int(os.environ.get("PROVEIT_PRICE_ENTERPRISE", "5000")),
    "professional": int(os.environ.get("PROVEIT_PRICE_PROFESSIONAL", "2000")),
    "starter": int(os.environ.get("PROVEIT_PRICE_STARTER", "500")),
}

# In demo mode only, allow a default token for local development.
# In all other modes, ADMIN_TOKEN must be explicitly set.
if not ADMIN_TOKEN:
    if DASH_MODE == "demo" and not DASH_DB_PATH:
        ADMIN_TOKEN = "dev-token"
    else:
        raise RuntimeError(
            "ADMIN_TOKEN environment variable is required. "
            "Set ADMIN_TOKEN to a secure random value (e.g. python -c "
            "\"import secrets; print(secrets.token_urlsafe(32))\"), or set "
            "DASH_MODE=demo for local development without a database."
        )

_store = None

# Session cookie secret — used to sign the admin session cookie.
# Generated at startup; sessions invalidate on restart (acceptable for admin console).
_SESSION_SECRET = secrets.token_hex(32)


@app.after_request
def add_security_headers(response):
    """Add security headers to all responses."""
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; "
        "img-src 'self' data:; "
        "connect-src 'self'"
    )
    return response


def _get_store():
    global _store
    if _store is not None:
        return _store
    if DASH_MODE == "demo" and not DASH_DB_PATH:
        return None
    if DASH_MODE == "sqlite" or DASH_DB_PATH:
        from .sqlite_dashdb import SQLiteDashboardStore
        db_path = DASH_DB_PATH or "./proveit_dashboard.db"
        store = SQLiteDashboardStore(db_path)
        store.connect()
        store.ensure_schema()
        _store = store
        return _store
    from .dashdb import DashboardStore
    store = DashboardStore(
        writer_dsn=os.environ["DASH_WRITER_DSN"],
        reader_dsn=os.environ.get("DASH_READER_DSN"),
    )
    store.connect()
    _store = store
    return _store


# Simple in-memory rate limiter for failed auth attempts.
# Tracks per-IP failure counts and blocks after threshold.
_AUTH_FAILURES: defaultdict = defaultdict(list)  # IP -> list of failure timestamps
_MAX_FAILURES = 5          # Max failures in the window before lockout
_FAILURE_WINDOW = 300      # Window in seconds (5 minutes)
_LOCKOUT_DURATION = 600    # Lockout duration in seconds (10 minutes)


def _is_rate_limited(ip: str) -> bool:
    """Check if an IP is currently locked out due to repeated auth failures."""
    now = time.monotonic()
    # Prune old entries outside the window
    _AUTH_FAILURES[ip] = [t for t in _AUTH_FAILURES[ip] if now - t < _FAILURE_WINDOW]
    if len(_AUTH_FAILURES[ip]) >= _MAX_FAILURES:
        # Still within lockout period from last failure?
        if now - _AUTH_FAILURES[ip][-1] < _LOCKOUT_DURATION:
            return True
        # Lockout expired — clear slate
        _AUTH_FAILURES[ip].clear()
    return False


def _record_auth_failure(ip: str) -> None:
    """Record a failed authentication attempt for rate limiting."""
    _AUTH_FAILURES[ip].append(time.monotonic())
    logger.warning("Failed admin auth attempt from %s (attempt %d)", ip, len(_AUTH_FAILURES[ip]))


def _make_session_token() -> str:
    """Create an HMAC session token proving the user authenticated."""
    return hmac.new(
        _SESSION_SECRET.encode(), ADMIN_TOKEN.encode(), hashlib.sha256
    ).hexdigest()


def _valid_session_cookie() -> bool:
    """Check if the request has a valid admin session cookie."""
    cookie = request.cookies.get("proveit_admin_session")
    if not cookie:
        return False
    expected = _make_session_token()
    return hmac.compare_digest(cookie, expected)


def require_auth(f):
    """Bearer-token auth for admin endpoints (timing-safe, rate-limited).

    Accepts auth via:
    1. Authorization: Bearer <token> header (API clients)
    2. proveit_admin_session cookie (browser sessions via /login)
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        # Allow unauthenticated in demo mode
        if DASH_MODE == "demo":
            return f(*args, **kwargs)

        # Check session cookie first (browser access)
        if _valid_session_cookie():
            return f(*args, **kwargs)

        # Check Bearer token (API clients) — checked before rate limit
        # so valid tokens always pass, even if the IP was rate-limited
        # by prior unauthenticated requests.
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            provided = auth[7:]
            if hmac.compare_digest(provided, ADMIN_TOKEN):
                return f(*args, **kwargs)

        # No valid credentials provided.
        # Distinguish between the dashboard's own AJAX (expired session)
        # and actual brute-force attempts with wrong tokens.
        client_ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown")
        if "," in client_ip:
            client_ip = client_ip.split(",")[0].strip()

        # Only count as a brute-force attempt if a Bearer token was
        # actually provided but was wrong.  Dashboard AJAX requests
        # with an expired cookie don't send a Bearer header, so they
        # should not trigger the rate limiter.
        if auth.startswith("Bearer "):
            if _is_rate_limited(client_ip):
                logger.warning("Rate-limited admin auth from %s", client_ip)
                return jsonify({"error": "Too many failed attempts. Try again later."}), 429
            _record_auth_failure(client_ip)

        # For direct browser navigation, redirect to login page.
        # AJAX/fetch requests get JSON 401 so the frontend can handle it.
        accept = request.headers.get("Accept", "")
        is_ajax = request.headers.get("X-Requested-With") == "XMLHttpRequest"
        is_fetch = "application/json" in accept and "text/html" not in accept
        if not is_ajax and not is_fetch and "text/html" in accept:
            return redirect("/login")

        return jsonify({"error": "Unauthorized"}), 401
    return decorated


# ---------------------------------------------------------------------------
# Demo / synthetic data
# ---------------------------------------------------------------------------

def _demo_tenants():
    return [
        {"tenant_id": "first_national", "name": "First National Bank",
         "tier": "enterprise", "latest_score": 82.5, "latest_grade": "B",
         "critical_findings": 1, "warning_findings": 4, "trend": "improving",
         "model_count": 4, "open_alerts": 3, "pipelines_24h": 12},
        {"tenant_id": "midwest_credit", "name": "Midwest Credit Union",
         "tier": "professional", "latest_score": 91.0, "latest_grade": "A",
         "critical_findings": 0, "warning_findings": 1, "trend": "stable",
         "model_count": 2, "open_alerts": 0, "pipelines_24h": 5},
        {"tenant_id": "coastal_bank", "name": "Coastal Community Bank",
         "tier": "professional", "latest_score": 67.0, "latest_grade": "C",
         "critical_findings": 3, "warning_findings": 5, "trend": "declining",
         "model_count": 6, "open_alerts": 7, "pipelines_24h": 18},
        {"tenant_id": "summit_fin", "name": "Summit Financial Group",
         "tier": "enterprise", "latest_score": 88.0, "latest_grade": "B",
         "critical_findings": 0, "warning_findings": 3, "trend": "improving",
         "model_count": 5, "open_alerts": 1, "pipelines_24h": 9},
        {"tenant_id": "valley_savings", "name": "Valley Savings & Loan",
         "tier": "starter", "latest_score": None, "latest_grade": None,
         "critical_findings": 0, "warning_findings": 0, "trend": None,
         "model_count": 0, "open_alerts": 0, "pipelines_24h": 0},
    ]


def _demo_system_health():
    return {
        "tenant_count": 5,
        "total_models": 17,
        "open_alerts": 11,
        "pipelines_24h": 44,
        "avg_compliance_score": 82.1,
    }


def _demo_pipeline_stats():
    return [
        {"tenant_id": "coastal_bank", "pipeline_name": "credit_scoring_pipeline",
         "status": "completed", "node_count": 142, "edge_count": 287,
         "duration_ms": 3420, "started_at": "2026-02-10T08:30:00Z"},
        {"tenant_id": "first_national", "pipeline_name": "fraud_detection_v2",
         "status": "completed", "node_count": 89, "edge_count": 156,
         "duration_ms": 1850, "started_at": "2026-02-10T08:15:00Z"},
        {"tenant_id": "summit_fin", "pipeline_name": "pricing_model_retrain",
         "status": "failed", "node_count": 0, "edge_count": 0,
         "duration_ms": 450, "started_at": "2026-02-10T07:45:00Z"},
        {"tenant_id": "midwest_credit", "pipeline_name": "monthly_fairness_audit",
         "status": "completed", "node_count": 45, "edge_count": 78,
         "duration_ms": 920, "started_at": "2026-02-10T06:00:00Z"},
        {"tenant_id": "coastal_bank", "pipeline_name": "adverse_action_batch",
         "status": "completed", "node_count": 312, "edge_count": 624,
         "duration_ms": 8100, "started_at": "2026-02-10T05:30:00Z"},
        {"tenant_id": "first_national", "pipeline_name": "model_monitoring_daily",
         "status": "completed", "node_count": 67, "edge_count": 134,
         "duration_ms": 1200, "started_at": "2026-02-10T04:00:00Z"},
    ]


def _demo_metrics():
    return [
        {"metric_name": "api_requests_1h", "metric_value": 2340,
         "labels": {}, "recorded_at": "2026-02-10T09:00:00Z"},
        {"metric_name": "avg_response_ms", "metric_value": 45.2,
         "labels": {}, "recorded_at": "2026-02-10T09:00:00Z"},
        {"metric_name": "error_rate_1h", "metric_value": 0.3,
         "labels": {}, "recorded_at": "2026-02-10T09:00:00Z"},
        {"metric_name": "db_connections_active", "metric_value": 12,
         "labels": {}, "recorded_at": "2026-02-10T09:00:00Z"},
        {"metric_name": "storage_gb", "metric_value": 42.7,
         "labels": {}, "recorded_at": "2026-02-10T09:00:00Z"},
        {"metric_name": "dag_nodes_total", "metric_value": 1_420_000,
         "labels": {}, "recorded_at": "2026-02-10T09:00:00Z"},
    ]


def _demo_alerts_all():
    return [
        {"id": 1, "tenant_id": "first_national", "severity": "critical",
         "source": "FairLens", "title": "DI detected: credit_score_v2",
         "model_id": "credit_score_v2", "created_at": "2026-02-09T14:30:00Z"},
        {"id": 2, "tenant_id": "coastal_bank", "severity": "critical",
         "source": "FairLens", "title": "DI detected: auto_loan_v1",
         "model_id": "auto_loan_v1", "created_at": "2026-02-09T11:00:00Z"},
        {"id": 3, "tenant_id": "coastal_bank", "severity": "critical",
         "source": "ComplianceScorer", "title": "Score dropped below D",
         "model_id": None, "created_at": "2026-02-08T16:00:00Z"},
        {"id": 4, "tenant_id": "first_national", "severity": "warning",
         "source": "ModelRegistry", "title": "Pricing model validation overdue",
         "model_id": "pricing_v3", "created_at": "2026-02-08T09:00:00Z"},
        {"id": 5, "tenant_id": "coastal_bank", "severity": "warning",
         "source": "RegulatoryCalendar", "title": "Colorado AI Act < 30 days",
         "model_id": None, "created_at": "2026-01-15T10:00:00Z"},
    ]


# ---------------------------------------------------------------------------
# Login page
# ---------------------------------------------------------------------------

_LOGIN_HTML = """<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ProveIt — Admin Login</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--bg:#f1f5f9;--surface:#ffffff;--border:#e2e8f0;--text-1:#0f172a;--text-2:#64748b;--text-3:#94a3b8;--blue:#3b82f6;--red:#ef4444;--radius:8px}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);color:var(--text-1);display:flex;align-items:center;justify-content:center;min-height:100vh;-webkit-font-smoothing:antialiased}
.login-card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:40px;width:360px;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,0.06)}
.logo{font-size:20px;font-weight:700;letter-spacing:-0.5px;margin-bottom:4px}
.logo-sub{font-size:12px;color:var(--text-3);margin-bottom:32px}
label{display:block;text-align:left;font-size:12px;font-weight:500;color:var(--text-2);margin-bottom:6px}
input{width:100%;height:40px;padding:0 12px;font-size:13px;font-family:inherit;background:var(--bg);border:1px solid var(--border);border-radius:var(--radius);color:var(--text-1);outline:none;transition:border-color 0.15s}
input:focus{border-color:var(--blue)}
button{width:100%;height:40px;margin-top:16px;font-size:13px;font-weight:600;font-family:inherit;background:var(--blue);color:#fff;border:none;border-radius:var(--radius);cursor:pointer;transition:opacity 0.15s}
button:hover{opacity:0.9}
.error{color:var(--red);font-size:12px;margin-top:12px;display:none}
</style>
</head><body>
<div class="login-card">
<div class="logo">ProveIt</div>
<div class="logo-sub">Admin Console</div>
<form method="POST" action="/login">
<label for="token">Admin Token</label>
<input type="password" id="token" name="token" placeholder="Enter admin token" autofocus>
<button type="submit">Sign In</button>
</form>
<div class="error" id="err">Invalid token. Please try again.</div>
</div>
<script>
if (location.search.includes('error=1')) document.getElementById('err').style.display='block';
</script>
</body></html>"""


@app.route("/login", methods=["GET", "POST"])
def login():
    """Login page for browser-based admin access."""
    if request.method == "GET":
        # If already authenticated, redirect to dashboard
        if _valid_session_cookie():
            return redirect("/")
        return _LOGIN_HTML

    # POST: validate token
    token = request.form.get("token", "")
    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown")
    if "," in client_ip:
        client_ip = client_ip.split(",")[0].strip()

    if _is_rate_limited(client_ip):
        return redirect("/login?error=1")

    if hmac.compare_digest(token, ADMIN_TOKEN):
        resp = make_response(redirect("/"))
        resp.set_cookie(
            "proveit_admin_session",
            _make_session_token(),
            httponly=True,
            samesite="Lax",
            secure=request.scheme == "https",
            max_age=86400,
        )
        return resp

    _record_auth_failure(client_ip)
    return redirect("/login?error=1")


@app.route("/logout")
def logout():
    """Clear the admin session cookie."""
    resp = make_response(redirect("/login"))
    resp.delete_cookie("proveit_admin_session")
    return resp


# ---------------------------------------------------------------------------
# Error Handlers
# ---------------------------------------------------------------------------

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Not found"}), 404


@app.errorhandler(500)
def server_error(e):
    logger.exception("Internal server error")
    return jsonify({"error": "Internal server error"}), 500


@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"error": "Method not allowed"}), 405


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
@require_auth
def index():
    return render_template("admin_dashboard.html")


@app.route("/health")
def health():
    return jsonify({"status": "healthy", "role": "admin"})


@app.route("/api/tenants")
@require_auth
def api_tenants():
    store = _get_store()
    if store is None:
        return jsonify(_demo_tenants())
    return jsonify(store.admin_tenant_summary())


@app.route("/api/system-health")
@require_auth
def api_system_health():
    store = _get_store()
    if store is None:
        logger.warning("system-health: no store, returning demo data")
        return jsonify(_demo_system_health())
    result = store.admin_system_health()
    return jsonify(result)


@app.route("/api/pipelines")
@require_auth
def api_pipelines():
    store = _get_store()
    if store is None:
        return jsonify(_demo_pipeline_stats())
    limit = min(request.args.get("limit", 50, type=int), 200)
    return jsonify(store.get_pipeline_stats(limit=limit))


@app.route("/api/metrics")
@require_auth
def api_metrics():
    store = _get_store()
    if store is None:
        return jsonify(_demo_metrics())
    return jsonify(store.get_latest_metrics())


@app.route("/api/alerts")
@require_auth
def api_alerts():
    store = _get_store()
    if store is None:
        return jsonify(_demo_alerts_all())
    return jsonify(store.get_all_alerts_platform(limit=50))


@app.route("/api/alerts/<int:alert_id>/resolve", methods=["POST"])
@require_auth
def api_resolve_alert(alert_id):
    store = _get_store()
    if store is None:
        return jsonify({"ok": True})
    store.resolve_alert(alert_id)
    return jsonify({"ok": True})


_TENANT_ID_RE = re.compile(r'^[a-zA-Z0-9_-]{1,128}$')


@app.route("/api/tenants/<tenant_id>")
@require_auth
def api_tenant_detail(tenant_id):
    if not _TENANT_ID_RE.match(tenant_id):
        return jsonify({"error": "Invalid tenant ID"}), 400
    store = _get_store()
    if store is None:
        return jsonify({"error": "No store configured"}), 500
    t = store.get_tenant(tenant_id)
    if not t:
        return jsonify({"error": "Tenant not found"}), 404
    comp = store.get_latest_compliance(tenant_id)
    comp_history = store.get_compliance_history(tenant_id, limit=12)
    models = store.get_models(tenant_id)
    alerts = store.get_alerts(tenant_id, unresolved_only=True)
    pipelines = store.get_pipeline_stats(tenant_id=tenant_id, limit=20)
    fairness = store.get_all_fairness(tenant_id)
    certs = store.get_certifications(tenant_id)
    return jsonify({
        "tenant_id": t["tenant_id"],
        "name": t["name"],
        "tier": t["tier"],
        "created_at": t.get("created_at"),
        "compliance": comp,
        "compliance_history": comp_history,
        "models": models,
        "alerts": alerts,
        "pipelines": pipelines,
        "fairness": fairness,
        "certifications": certs,
    })


@app.route("/api/models/all")
@require_auth
def api_models_all():
    store = _get_store()
    if store is None:
        return jsonify([])
    return jsonify(store.get_all_models_platform())


@app.route("/api/fairness/all")
@require_auth
def api_fairness_all():
    store = _get_store()
    if store is None:
        return jsonify([])
    return jsonify(store.get_all_fairness_platform())


@app.route("/api/compliance/platform")
@require_auth
def api_compliance_platform():
    store = _get_store()
    if store is None:
        return jsonify({"tenants": [], "avg_score": None})
    return jsonify(store.get_compliance_platform())


@app.route("/api/pipelines/summary")
@require_auth
def api_pipeline_summary():
    store = _get_store()
    if store is None:
        return jsonify({"total_runs": 0, "completed": 0, "failed": 0})
    return jsonify(store.get_pipeline_summary())


@app.route("/api/revenue")
@require_auth
def api_revenue():
    store = _get_store()
    if store is None:
        return jsonify({})
    tenants = store.get_all_tenants()
    tier_counts = {}
    for t in tenants:
        tier = t.get("tier", "starter")
        tier_counts[tier] = tier_counts.get(tier, 0) + 1
    mrr = sum(TIER_PRICING.get(tier, 0) * count for tier, count in tier_counts.items())
    arr = mrr * 12
    models = store.get_all_models_platform()
    health = store.admin_system_health()
    pipelines_24h = health.get("pipelines_24h", 0)
    return jsonify({
        "mrr": mrr,
        "arr": arr,
        "tier_breakdown": [
            {"tier": tier, "count": count, "mrr": TIER_PRICING.get(tier, 0) * count,
             "price_per_unit": TIER_PRICING.get(tier, 0)}
            for tier, count in sorted(tier_counts.items(), key=lambda x: -TIER_PRICING.get(x[0], 0))
        ],
        "total_clients": len(tenants),
        "total_models": len(models),
        "models_per_client": round(len(models) / max(len(tenants), 1), 1),
        "pipelines_24h": pipelines_24h,
        "avg_revenue_per_client": round(mrr / max(len(tenants), 1)),
    })


@app.route("/api/calendar")
@require_auth
def api_calendar():
    from proveit.governance.regulatory_calendar import RegulatoryCalendar
    cal = RegulatoryCalendar()
    return jsonify(cal.generate_report())


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    import argparse
    parser = argparse.ArgumentParser(description="ProveIt Admin Dashboard")
    parser.add_argument("--port", default=5004, type=int)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    from proveit import __version__

    mode_label = {
        "demo": "Demo (synthetic data, no database)",
        "sqlite": f"SQLite ({DASH_DB_PATH or './proveit_dashboard.db'})",
    }.get(DASH_MODE, f"Aurora PostgreSQL")
    if DASH_MODE not in ("demo", "sqlite") and DASH_DB_PATH:
        mode_label = f"SQLite ({DASH_DB_PATH})"

    auth_label = "open (demo mode)" if DASH_MODE == "demo" else "bearer token required"
    url = f"http://{args.host}:{args.port}"

    print()
    print("  ProveIt Admin Dashboard v" + __version__)
    print("  " + "=" * 44)
    print(f"  Mode:       {mode_label}")
    print(f"  Auth:       {auth_label}")
    print(f"  Dashboard:  {url}")
    print()

    app.run(debug=args.debug, port=args.port, host=args.host)


if __name__ == "__main__":
    main()
