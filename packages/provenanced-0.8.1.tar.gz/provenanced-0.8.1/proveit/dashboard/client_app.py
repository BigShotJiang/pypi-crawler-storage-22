"""
Client-Facing Dashboard: Bank CRO/CCO Compliance Portal.

Shows a bank's compliance posture, model inventory, fairness results,
regulatory calendar, certifications, and active alerts.  Reads from
the Aurora PostgreSQL dashboard store (DashboardStore).

Authentication is enforced on all routes.  Users must be in the
tenant's allowlist (stored in ``dashboard_users`` table).  Login
is via email + password with bcrypt hashing, or via SSO (Cognito
OIDC/SAML federation) when configured.

Usage:
    DASH_WRITER_DSN=postgresql://... DASH_TENANT=acme python -m proveit.dashboard.client_app
    # Then open: http://localhost:5003

For local development without Aurora, set DASH_MODE=demo for synthetic data.
"""

import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import tempfile
import time
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from functools import wraps

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from flask import Flask, jsonify, render_template, render_template_string, request, Response, redirect, make_response

logger = logging.getLogger(__name__)

app = Flask(__name__)


class _ReverseProxied:
    """WSGI middleware that adjusts SCRIPT_NAME from X-Script-Name header.

    When behind nginx with a URL prefix (e.g. /client/), nginx sets
    X-Script-Name and strips the prefix. This middleware puts it back
    so Flask generates correct absolute URLs for redirects and links.
    """
    def __init__(self, wsgi_app):
        self.app = wsgi_app

    def __call__(self, environ, start_response):
        script_name = environ.get("HTTP_X_SCRIPT_NAME", "")
        if script_name:
            environ["SCRIPT_NAME"] = script_name
            path_info = environ.get("PATH_INFO", "")
            if path_info.startswith(script_name):
                environ["PATH_INFO"] = path_info[len(script_name):]
        return self.app(environ, start_response)


app.wsgi_app = _ReverseProxied(app.wsgi_app)

TENANT_ID = os.environ.get("DASH_TENANT", "demo")
DASH_MODE = os.environ.get("DASH_MODE", "demo")
DASH_DB_PATH = os.environ.get("DASH_DB_PATH", "")

_store = None
_user_table_ready = False

_SESSION_SECRET = os.environ.get("CLIENT_SESSION_SECRET") or secrets.token_hex(32)

COGNITO_REGION = os.environ.get("COGNITO_REGION", "us-east-1")
COGNITO_USER_POOL_ID = os.environ.get("COGNITO_USER_POOL_ID", "")
COGNITO_CLIENT_ID = os.environ.get("COGNITO_CLIENT_ID", "")
COGNITO_DOMAIN = os.environ.get("COGNITO_DOMAIN", "")
COGNITO_CALLBACK_URL = os.environ.get("COGNITO_CALLBACK_URL", "")

VALID_ROLES = ("admin", "manager", "analyst")

_AUTH_FAILURES: defaultdict = defaultdict(list)
_MAX_FAILURES = 5
_FAILURE_WINDOW = 300
_LOCKOUT_DURATION = 600


@app.after_request
def add_security_headers(response):
    """Add security headers to all responses."""
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://cdn.jsdelivr.net; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; "
        "img-src 'self' data:; "
        "connect-src 'self'"
    )
    return response


# ---------------------------------------------------------------------------
# Authentication System
# ---------------------------------------------------------------------------

def _is_rate_limited(ip: str) -> bool:
    now = time.monotonic()
    _AUTH_FAILURES[ip] = [t for t in _AUTH_FAILURES[ip] if now - t < _FAILURE_WINDOW]
    if len(_AUTH_FAILURES[ip]) >= _MAX_FAILURES:
        if now - _AUTH_FAILURES[ip][-1] < _LOCKOUT_DURATION:
            return True
        _AUTH_FAILURES[ip].clear()
    return False


def _record_auth_failure(ip: str) -> None:
    _AUTH_FAILURES[ip].append(time.monotonic())
    logger.warning("Failed client auth attempt from %s (attempt %d)", ip, len(_AUTH_FAILURES[ip]))


def _hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 260000)
    return f"pbkdf2:sha256:260000${salt}${h.hex()}"


def _check_password(password: str, hashed: str) -> bool:
    try:
        parts = hashed.split("$")
        if len(parts) != 3:
            return False
        salt = parts[1]
        expected_hash = parts[2]
        h = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 260000)
        return hmac.compare_digest(h.hex(), expected_hash)
    except Exception:
        return False


def _make_session_token(email: str, role: str) -> str:
    payload = f"{email}|{role}|{TENANT_ID}|{int(time.time())}"
    sig = hmac.new(
        _SESSION_SECRET.encode(), payload.encode(), hashlib.sha256
    ).hexdigest()
    return f"{payload}|{sig}"


def _validate_session_token(token: str):
    try:
        parts = token.rsplit("|", 1)
        if len(parts) != 2:
            return None
        payload, sig = parts
        expected = hmac.new(
            _SESSION_SECRET.encode(), payload.encode(), hashlib.sha256
        ).hexdigest()
        if not hmac.compare_digest(sig, expected):
            return None
        fields = payload.split("|")
        if len(fields) != 4:
            return None
        email, role, tenant, ts = fields
        if tenant != TENANT_ID:
            return None
        age = int(time.time()) - int(ts)
        if age > 86400:
            return None
        return {"email": email, "role": role, "tenant_id": tenant}
    except Exception:
        return None


def _get_current_user():
    cookie = request.cookies.get("proveit_client_session")
    if cookie:
        return _validate_session_token(cookie)
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return _validate_session_token(auth[7:])
    return None


def require_client_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if DASH_MODE == "demo":
            request.current_user = {
                "email": "demo@example.com",
                "role": "admin",
                "tenant_id": TENANT_ID,
            }
            return f(*args, **kwargs)

        user = _get_current_user()
        if user:
            request.current_user = user
            return f(*args, **kwargs)

        accept = request.headers.get("Accept", "")
        is_ajax = request.headers.get("X-Requested-With") == "XMLHttpRequest"
        is_fetch = "application/json" in accept and "text/html" not in accept
        if not is_ajax and not is_fetch and "text/html" in accept:
            return redirect("/login")

        return jsonify({"error": "Unauthorized"}), 401
    return decorated


def require_role(*allowed_roles):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            user = getattr(request, "current_user", None)
            if not user:
                return jsonify({"error": "Unauthorized"}), 401
            if user["role"] not in allowed_roles:
                return jsonify({"error": "Insufficient permissions"}), 403
            return f(*args, **kwargs)
        return decorated
    return decorator


def _validate_email(email: str) -> bool:
    return bool(re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email))


def _get_store():
    """Lazily connect to the DashboardStore.

    Supports three modes:
    - "demo": hardcoded synthetic data (no store)
    - "sqlite": SQLite-backed store via DASH_DB_PATH
    - default: Aurora PostgreSQL via DASH_WRITER_DSN
    """
    global _store
    if _store is not None:
        return _store
    if DASH_MODE == "demo" and not DASH_DB_PATH:
        return None
    if DASH_MODE == "sqlite" or DASH_DB_PATH:
        from .sqlite_dashdb import SQLiteDashboardStore
        db_path = DASH_DB_PATH or "./proveit_dashboard.db"
        store = SQLiteDashboardStore(db_path)
        store.connect()
        store.ensure_schema()
        _store = store
        return _store
    from .dashdb import DashboardStore
    store = DashboardStore(
        writer_dsn=os.environ["DASH_WRITER_DSN"],
        reader_dsn=os.environ.get("DASH_READER_DSN"),
    )
    store.connect()
    _store = store
    return _store


# ---------------------------------------------------------------------------
# User-entered data (stored in Aurora client_user_data table)
# ---------------------------------------------------------------------------

_USER_DATA_SCHEMA = """
CREATE TABLE IF NOT EXISTS client_user_data (
    id SERIAL PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    data_type TEXT NOT NULL,
    ref_id TEXT,
    payload JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
)
"""

_USER_DATA_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_cud_tenant_type ON client_user_data (tenant_id, data_type)",
    "CREATE INDEX IF NOT EXISTS idx_cud_ref ON client_user_data (tenant_id, data_type, ref_id)",
]


def _ensure_user_data_table():
    global _user_table_ready
    if _user_table_ready:
        return
    store = _get_store()
    if store is None:
        return
    try:
        store._write(_USER_DATA_SCHEMA)
        for idx_sql in _USER_DATA_INDEXES:
            store._write(idx_sql)
        _user_table_ready = True
    except Exception as e:
        logger.error("Failed to create client_user_data table: %s", e)


def _get_user_records(data_type, ref_id=None):
    store = _get_store()
    if store is None:
        return []
    _ensure_user_data_table()
    try:
        if ref_id:
            rows = store._read_dicts(
                "SELECT id, data_type, ref_id, payload, created_at, updated_at "
                "FROM client_user_data "
                "WHERE tenant_id = %s AND data_type = %s AND ref_id = %s "
                "ORDER BY created_at DESC",
                (TENANT_ID, data_type, ref_id),
            )
        else:
            rows = store._read_dicts(
                "SELECT id, data_type, ref_id, payload, created_at, updated_at "
                "FROM client_user_data "
                "WHERE tenant_id = %s AND data_type = %s "
                "ORDER BY created_at DESC",
                (TENANT_ID, data_type),
            )
        for r in rows:
            if isinstance(r.get("payload"), str):
                r["payload"] = json.loads(r["payload"])
            for k in ("created_at", "updated_at"):
                if hasattr(r.get(k), "isoformat"):
                    r[k] = r[k].isoformat()
        return rows
    except Exception as e:
        logger.error("Failed to read user records: %s", e)
        return []


def _save_user_record(data_type, ref_id, payload):
    store = _get_store()
    if store is None:
        return None
    _ensure_user_data_table()
    try:
        row = store._write_returning(
            "INSERT INTO client_user_data (tenant_id, data_type, ref_id, payload) "
            "VALUES (%s, %s, %s, %s) RETURNING id",
            (TENANT_ID, data_type, ref_id, json.dumps(payload)),
        )
        if isinstance(row, (list, tuple)):
            return row[0]
        return row
    except Exception as e:
        logger.error("Failed to save user record: %s", e)
        return None


def _delete_user_record(record_id):
    store = _get_store()
    if store is None:
        return False
    _ensure_user_data_table()
    try:
        store._write(
            "DELETE FROM client_user_data WHERE id = %s AND tenant_id = %s",
            (record_id, TENANT_ID),
        )
        return True
    except Exception as e:
        logger.error("Failed to delete user record: %s", e)
        return False


# ---------------------------------------------------------------------------
# Generated reports persistence (stored in Aurora generated_reports table)
# ---------------------------------------------------------------------------

_REPORTS_SCHEMA = """
CREATE TABLE IF NOT EXISTS generated_reports (
    id SERIAL PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    report_type TEXT NOT NULL,
    title TEXT NOT NULL,
    model_id TEXT,
    content_md TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    section_count INT NOT NULL DEFAULT 0,
    generated_by TEXT NOT NULL DEFAULT 'system',
    metadata JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
)
"""

_REPORTS_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_gr_tenant ON generated_reports (tenant_id, created_at DESC)",
    "CREATE INDEX IF NOT EXISTS idx_gr_type ON generated_reports (tenant_id, report_type)",
]

_reports_table_ready = False


def _ensure_reports_table():
    global _reports_table_ready
    if _reports_table_ready:
        return
    store = _get_store()
    if store is None:
        return
    try:
        store._write(_REPORTS_SCHEMA)
        for idx_sql in _REPORTS_INDEXES:
            store._write(idx_sql)
        _reports_table_ready = True
    except Exception as e:
        logger.error("Failed to create generated_reports table: %s", e)


def _save_report(report_type, title, content_md, section_count,
                 model_id=None, generated_by="system", meta=None):
    store = _get_store()
    if store is None:
        return None
    _ensure_reports_table()
    content_hash = hashlib.sha256(content_md.encode()).hexdigest()
    try:
        row = store._write_returning(
            "INSERT INTO generated_reports "
            "(tenant_id, report_type, title, model_id, content_md, "
            " content_hash, section_count, generated_by, metadata) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING id",
            (TENANT_ID, report_type, title, model_id, content_md,
             content_hash, section_count, generated_by,
             json.dumps(meta or {})),
        )
        if isinstance(row, (list, tuple)):
            return row[0]
        return row
    except Exception as e:
        logger.error("Failed to save report: %s", e)
        return None


def _get_report_history(limit=50):
    store = _get_store()
    if store is None:
        return []
    _ensure_reports_table()
    try:
        rows = store._read_dicts(
            "SELECT id, report_type, title, model_id, content_hash, "
            "section_count, generated_by, metadata, created_at "
            "FROM generated_reports "
            "WHERE tenant_id = %s ORDER BY created_at DESC LIMIT %s",
            (TENANT_ID, limit),
        )
        for r in rows:
            if isinstance(r.get("metadata"), str):
                r["metadata"] = json.loads(r["metadata"])
            if hasattr(r.get("created_at"), "isoformat"):
                r["created_at"] = r["created_at"].isoformat()
        return rows
    except Exception as e:
        logger.error("Failed to read report history: %s", e)
        return []


def _get_report_by_id(report_id):
    store = _get_store()
    if store is None:
        return None
    _ensure_reports_table()
    try:
        rows = store._read_dicts(
            "SELECT id, report_type, title, model_id, content_md, "
            "content_hash, section_count, generated_by, metadata, created_at "
            "FROM generated_reports "
            "WHERE id = %s AND tenant_id = %s",
            (report_id, TENANT_ID),
        )
        if not rows:
            return None
        r = rows[0]
        if isinstance(r.get("metadata"), str):
            r["metadata"] = json.loads(r["metadata"])
        if hasattr(r.get("created_at"), "isoformat"):
            r["created_at"] = r["created_at"].isoformat()
        return r
    except Exception as e:
        logger.error("Failed to read report: %s", e)
        return None


def _delete_report(report_id):
    store = _get_store()
    if store is None:
        return False
    _ensure_reports_table()
    try:
        store._write(
            "DELETE FROM generated_reports WHERE id = %s AND tenant_id = %s",
            (report_id, TENANT_ID),
        )
        return True
    except Exception as e:
        logger.error("Failed to delete report: %s", e)
        return False


# ---------------------------------------------------------------------------
# Demo / synthetic data (used when no Aurora connection)
# ---------------------------------------------------------------------------

def _demo_compliance():
    return {
        "score": 82.5, "grade": "B",
        "engines_evaluated": 5,
        "critical_findings": 1, "warning_findings": 4,
        "total_findings": 8, "trend": "improving",
        "top_risks": [
            "[ECOA / Reg B] Adverse action reason codes not validated with SHAP fidelity > 0.85",
        ],
        "breakdowns": [
            {"regulation": "ECOA / Reg B", "passed": False, "critical_count": 1,
             "warning_count": 2, "weighted_deduction": 21.0, "weight": 1.5},
            {"regulation": "SR 11-7 / OCC 2011-12", "passed": True, "critical_count": 0,
             "warning_count": 1, "weighted_deduction": 3.9, "weight": 1.3},
            {"regulation": "EU AI Act", "passed": True, "critical_count": 0,
             "warning_count": 1, "weighted_deduction": 3.6, "weight": 1.2},
            {"regulation": "Colorado AI Act", "passed": True, "critical_count": 0,
             "warning_count": 0, "weighted_deduction": 0.0, "weight": 1.0},
            {"regulation": "NYC Local Law 144", "passed": True, "critical_count": 0,
             "warning_count": 0, "weighted_deduction": 0.0, "weight": 1.0},
        ],
        "bonuses_applied": {
            "Active Certifications": 3.0,
            "FairLens Analysis": 3.0,
            "Model Inventory": 2.0,
            "Data Governance": 2.0,
        },
        "snapshot_at": datetime.now(timezone.utc).isoformat(),
    }


def _demo_compliance_history():
    return [
        {"score": 78.0, "grade": "B", "total_findings": 10, "critical_findings": 2,
         "snapshot_at": "2025-12-01T00:00:00Z"},
        {"score": 79.5, "grade": "B", "total_findings": 9, "critical_findings": 2,
         "snapshot_at": "2026-01-01T00:00:00Z"},
        {"score": 82.5, "grade": "B", "total_findings": 8, "critical_findings": 1,
         "snapshot_at": "2026-02-01T00:00:00Z"},
    ]


def _demo_models():
    return [
        {"model_id": "credit_score_v2", "name": "Consumer Credit Score",
         "version": "2.1.0", "tier": 1, "status": "production",
         "domain": "lending", "owner": "Model Risk Mgmt",
         "compliance_score": 88.0, "validation_overdue": False,
         "monitoring_overdue": False, "finding_count": 2},
        {"model_id": "fraud_detect_v1", "name": "Fraud Detection",
         "version": "1.4.2", "tier": 2, "status": "production",
         "domain": "fraud", "owner": "Fraud Analytics",
         "compliance_score": 94.0, "validation_overdue": False,
         "monitoring_overdue": False, "finding_count": 0},
        {"model_id": "pricing_v3", "name": "Loan Pricing Model",
         "version": "3.0.1", "tier": 1, "status": "monitoring",
         "domain": "lending", "owner": "Model Risk Mgmt",
         "compliance_score": 75.0, "validation_overdue": True,
         "monitoring_overdue": False, "finding_count": 3},
        {"model_id": "marketing_v1", "name": "Marketing Propensity",
         "version": "1.0.0", "tier": 3, "status": "development",
         "domain": "marketing", "owner": "Analytics",
         "compliance_score": None, "validation_overdue": False,
         "monitoring_overdue": False, "finding_count": 0},
    ]


def _demo_fairness():
    return [
        {"model_id": "credit_score_v2", "has_disparate_impact": True,
         "worst_ratio": 0.78, "worst_group": "race:Black",
         "p_value": 0.003, "statistically_significant": True,
         "protected_attributes": ["race", "sex", "age"],
         "sample_size_warnings": []},
        {"model_id": "fraud_detect_v1", "has_disparate_impact": False,
         "worst_ratio": 0.92, "worst_group": "age:60+",
         "p_value": 0.34, "statistically_significant": False,
         "protected_attributes": ["race", "sex", "age"],
         "sample_size_warnings": []},
        {"model_id": "pricing_v3", "has_disparate_impact": True,
         "worst_ratio": 0.81, "worst_group": "ethnicity:Hispanic",
         "p_value": 0.012, "statistically_significant": True,
         "protected_attributes": ["race", "ethnicity", "sex"],
         "sample_size_warnings": ["ethnicity:Asian (n=24)"]},
    ]


def _demo_regulatory_calendar():
    from proveit.governance.regulatory_calendar import RegulatoryCalendar
    cal = RegulatoryCalendar()
    return cal.generate_report()


def _demo_certifications():
    return [
        {"cert_type": "SOC 2 Type II", "status": "active",
         "issued_date": "2025-09-15", "expiry_date": "2026-09-15",
         "days_until_expiry": 217},
        {"cert_type": "ISO 27001", "status": "in_progress",
         "issued_date": None, "expiry_date": None,
         "days_until_expiry": None},
        {"cert_type": "SR 11-7 MRM Attestation", "status": "active",
         "issued_date": "2025-12-01", "expiry_date": "2026-12-01",
         "days_until_expiry": 294},
    ]


def _demo_pipeline_runs():
    return [
        {"pipeline_id": 1, "pipeline_name": "credit_scoring_pipeline", "status": "completed",
         "node_count": 142, "edge_count": 287, "duration_ms": 3420,
         "started_at": "2026-02-14T08:30:00Z"},
        {"pipeline_id": 2, "pipeline_name": "fraud_detection_v2", "status": "completed",
         "node_count": 89, "edge_count": 156, "duration_ms": 1850,
         "started_at": "2026-02-14T08:15:00Z"},
        {"pipeline_id": 3, "pipeline_name": "monthly_fairness_audit", "status": "completed",
         "node_count": 45, "edge_count": 78, "duration_ms": 920,
         "started_at": "2026-02-14T06:00:00Z"},
        {"pipeline_id": 4, "pipeline_name": "adverse_action_batch", "status": "completed",
         "node_count": 312, "edge_count": 624, "duration_ms": 8100,
         "started_at": "2026-02-13T05:30:00Z"},
        {"pipeline_id": 5, "pipeline_name": "model_monitoring_daily", "status": "completed",
         "node_count": 67, "edge_count": 134, "duration_ms": 1200,
         "started_at": "2026-02-13T04:00:00Z"},
        {"pipeline_id": 6, "pipeline_name": "data_governance_scan", "status": "failed",
         "node_count": 0, "edge_count": 0, "duration_ms": 450,
         "started_at": "2026-02-12T07:45:00Z"},
    ]


def _demo_alerts():
    return [
        {"id": 1, "severity": "critical", "source": "FairLens",
         "title": "Disparate impact detected in Credit Score model",
         "description": "Selection rate ratio 0.78 for race:Black (p=0.003). Below 0.80 threshold.",
         "model_id": "credit_score_v2", "regulation": "ECOA / Reg B",
         "resolved": False, "created_at": "2026-02-09T14:30:00Z"},
        {"id": 2, "severity": "warning", "source": "ModelRegistry",
         "title": "Loan Pricing Model validation overdue",
         "description": "Last validation was 14 months ago. SR 11-7 requires annual validation.",
         "model_id": "pricing_v3", "regulation": "SR 11-7 / OCC 2011-12",
         "resolved": False, "created_at": "2026-02-08T09:00:00Z"},
        {"id": 3, "severity": "warning", "source": "RegulatoryCalendar",
         "title": "Colorado AI Act effective in < 30 days",
         "description": "Colorado AI Act takes effect Feb 1, 2026. Ensure impact assessment is complete.",
         "model_id": None, "regulation": "Colorado AI Act",
         "resolved": False, "created_at": "2026-01-15T10:00:00Z"},
        {"id": 4, "severity": "info", "source": "ComplianceScorer",
         "title": "Compliance score improved from C to B",
         "description": "Score went from 74 to 82.5 after remediating ECOA findings.",
         "model_id": None, "regulation": None,
         "resolved": True, "created_at": "2026-02-01T08:00:00Z"},
    ]


def _demo_attestations():
    now = datetime.now(timezone.utc)
    return [
        {"attestation_id": "att-001", "report_type": "compliance_score",
         "attester_name": "Sarah Chen", "attester_title": "Chief Risk Officer",
         "status": "attested", "score_at_attestation": 82.5,
         "grade_at_attestation": "B", "comments": "Q1 2026 compliance review approved.",
         "attested_at": (now - timedelta(days=5)).isoformat(),
         "expires_at": (now + timedelta(days=85)).isoformat(),
         "created_at": (now - timedelta(days=7)).isoformat()},
        {"attestation_id": "att-002", "report_type": "fairness_analysis",
         "attester_name": "Sarah Chen", "attester_title": "Chief Risk Officer",
         "status": "pending", "score_at_attestation": None,
         "grade_at_attestation": None, "comments": "",
         "attested_at": None, "expires_at": None,
         "created_at": (now - timedelta(days=2)).isoformat()},
    ]


def _demo_exceptions():
    now = datetime.now(timezone.utc)
    return {
        "total_exceptions": 2,
        "active_exceptions": 2,
        "pending_approval": 1,
        "approved": 1,
        "escalation_alerts": 0,
        "critical_escalations": 0,
        "exceptions": [
            {"exception_id": "exc-001", "model_id": "pricing_v3",
             "regulation": "SR 11-7 / OCC 2011-12",
             "exception_type": "deferred_validation",
             "justification": "Model deployed for shadow scoring only; full validation scheduled for Q2.",
             "requested_by": "Mark Johnson, Model Owner",
             "status": "approved", "risk_accepted": "Limited risk during shadow period.",
             "scope": "Shadow scoring only, no production decisions.",
             "conditions": ["Monthly performance review", "No production use"],
             "approvals": [{"approver_name": "Sarah Chen", "level": 3, "approved": True}],
             "created_at": (now - timedelta(days=30)).isoformat(),
             "expires_at": (now + timedelta(days=60)).isoformat(),
             "days_until_expiry": 60, "escalation_level": "none", "is_active": True},
            {"exception_id": "exc-002", "model_id": "credit_score_v2",
             "regulation": "ECOA / Reg B",
             "exception_type": "threshold_override",
             "justification": "DI ratio at 0.78 pending remediation; mitigation plan in progress.",
             "requested_by": "Lisa Park, Fair Lending Officer",
             "status": "pending", "risk_accepted": "",
             "scope": "Consumer lending portfolio.",
             "conditions": ["Bi-weekly monitoring", "Remediation by Q2"],
             "approvals": [],
             "created_at": (now - timedelta(days=3)).isoformat(),
             "expires_at": (now + timedelta(days=87)).isoformat(),
             "days_until_expiry": 87, "escalation_level": "none", "is_active": True},
        ],
        "escalations": [],
    }


def _demo_regulatory_changes():
    now = datetime.now(timezone.utc)
    return [
        {"change": {
            "regulation": "Colorado AI Act",
            "change_type": "deadline",
            "description": "Colorado AI Act SB 21-169 takes effect Feb 1, 2026. Requires impact assessments for high-risk AI in consequential decisions.",
            "effective_date": "2026-02-01T00:00:00Z",
         },
         "impacted_models": [
             {"model_id": "credit_score_v2", "model_name": "Consumer Credit Score",
              "tier": 1, "domain": "lending", "impact_level": "high",
              "reason": "Tier 1 model in lending domain directly affected by deadline"},
             {"model_id": "pricing_v3", "model_name": "Loan Pricing Model",
              "tier": 1, "domain": "lending", "impact_level": "high",
              "reason": "Tier 1 model in lending domain directly affected by deadline"},
         ],
         "impacted_model_count": 2,
         "estimated_compliance_impact": -16.0,
         "recommended_actions": [
             "Add deadline to regulatory calendar: 2026-02-01",
             "Assign remediation owners for each impacted model",
         ],
         "days_until_effective": 0,
         "generated_at": now.isoformat()},
    ]


# ---------------------------------------------------------------------------
# Login Page
# ---------------------------------------------------------------------------

_LOGIN_HTML = """<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ProveIt &mdash; Client Login</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--bg:#f1f5f9;--surface:#ffffff;--border:#e2e8f0;--text-1:#0f172a;--text-2:#64748b;--text-3:#94a3b8;--blue:#3b82f6;--red:#ef4444;--radius:8px}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);color:var(--text-1);display:flex;align-items:center;justify-content:center;min-height:100vh;-webkit-font-smoothing:antialiased}
.login-card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:40px;width:380px;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,0.06)}
.logo{font-size:20px;font-weight:700;letter-spacing:-0.5px;margin-bottom:4px}
.logo-sub{font-size:12px;color:var(--text-3);margin-bottom:32px}
.field{margin-bottom:16px;text-align:left}
label{display:block;font-size:12px;font-weight:500;color:var(--text-2);margin-bottom:6px}
input{width:100%;height:40px;padding:0 12px;font-size:13px;font-family:inherit;background:var(--bg);border:1px solid var(--border);border-radius:var(--radius);color:var(--text-1);outline:none;transition:border-color 0.15s}
input:focus{border-color:var(--blue)}
button{width:100%;height:40px;margin-top:8px;font-size:13px;font-weight:600;font-family:inherit;background:var(--blue);color:#fff;border:none;border-radius:var(--radius);cursor:pointer;transition:opacity 0.15s}
button:hover{opacity:0.9}
.btn-sso{background:#1e293b;margin-top:12px}
.divider{display:flex;align-items:center;margin:20px 0;color:var(--text-3);font-size:11px}
.divider::before,.divider::after{content:'';flex:1;border-top:1px solid var(--border)}
.divider span{padding:0 12px}
.error{color:var(--red);font-size:12px;margin-top:12px;display:none}
.setup-info{font-size:11px;color:var(--text-3);margin-top:20px;line-height:1.5}
</style>
</head><body>
<div class="login-card">
<div class="logo">ProveIt</div>
<div class="logo-sub">Compliance Dashboard</div>
{% if sso_url %}
<button class="btn-sso" onclick="window.location='{{ sso_url }}'">Sign in with SSO</button>
<div class="divider"><span>or</span></div>
{% endif %}
<form method="POST" action="/login">
<div class="field"><label for="email">Email</label>
<input type="email" id="email" name="email" placeholder="you@yourbank.com" required autofocus></div>
<div class="field"><label for="password">Password</label>
<input type="password" id="password" name="password" placeholder="Enter password" required></div>
<button type="submit">Sign In</button>
</form>
<div class="error" id="err">{{ error_msg or 'Invalid credentials.' }}</div>
{% if first_setup %}
<div class="setup-info">No users configured yet. The first login will create an admin account.</div>
{% endif %}
</div>
<script>
if (location.search.includes('error=1')) document.getElementById('err').style.display='block';
if (location.search.includes('error=locked')) {
    var e = document.getElementById('err');
    e.textContent = 'Too many failed attempts. Try again later.';
    e.style.display = 'block';
}
if (location.search.includes('error=expired')) {
    var e = document.getElementById('err');
    e.textContent = 'Session expired. Please sign in again.';
    e.style.display = 'block';
}
</script>
</body></html>"""


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        user = _get_current_user()
        if user:
            return redirect("/")

        store = _get_store()
        first_setup = False
        if store is not None:
            first_setup = store.count_users(TENANT_ID) == 0

        sso_url = ""
        if COGNITO_DOMAIN and COGNITO_CLIENT_ID:
            callback = COGNITO_CALLBACK_URL or (request.host_url.rstrip("/") + "/auth/callback")
            sso_url = (
                f"https://{COGNITO_DOMAIN}/oauth2/authorize?"
                f"client_id={COGNITO_CLIENT_ID}&response_type=code&"
                f"scope=openid+email+profile&redirect_uri={callback}"
            )

        return render_template_string(
            _LOGIN_HTML,
            sso_url=sso_url,
            first_setup=first_setup,
            error_msg=None,
        )

    email = (request.form.get("email") or "").strip().lower()
    password = request.form.get("password", "")
    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown")
    if "," in client_ip:
        client_ip = client_ip.split(",")[0].strip()

    if _is_rate_limited(client_ip):
        return redirect("/login?error=locked")

    if not email or not password:
        return redirect("/login?error=1")

    if not _validate_email(email):
        _record_auth_failure(client_ip)
        return redirect("/login?error=1")

    store = _get_store()

    if store is not None and store.count_users(TENANT_ID) == 0:
        pw_hash = _hash_password(password)
        store.create_user(
            tenant_id=TENANT_ID,
            email=email,
            password_hash=pw_hash,
            display_name=email.split("@")[0].replace(".", " ").title(),
            role="admin",
        )
        logger.info("First user created: %s as admin for tenant %s", email, TENANT_ID)

    if store is None:
        if DASH_MODE == "demo":
            token = _make_session_token(email, "admin")
            resp = make_response(redirect("/"))
            resp.set_cookie(
                "proveit_client_session", token,
                httponly=True, samesite="Lax",
                secure=request.scheme == "https",
                max_age=86400,
            )
            return resp
        return redirect("/login?error=1")

    user = store.get_user_by_email(TENANT_ID, email)
    if not user:
        _record_auth_failure(client_ip)
        return redirect("/login?error=1")

    if not user.get("password_hash"):
        _record_auth_failure(client_ip)
        return redirect("/login?error=1")

    if not _check_password(password, user["password_hash"]):
        _record_auth_failure(client_ip)
        return redirect("/login?error=1")

    store.record_login(TENANT_ID, email)
    token = _make_session_token(email, user["role"])
    resp = make_response(redirect("/"))
    resp.set_cookie(
        "proveit_client_session", token,
        httponly=True, samesite="Lax",
        secure=request.scheme == "https",
        max_age=86400,
    )
    return resp


@app.route("/logout")
def logout():
    resp = make_response(redirect("/login"))
    resp.delete_cookie("proveit_client_session")
    return resp


@app.route("/auth/callback")
def sso_callback():
    """Handle Cognito OAuth2 callback."""
    code = request.args.get("code")
    if not code:
        return redirect("/login?error=1")

    if not COGNITO_DOMAIN or not COGNITO_CLIENT_ID:
        return redirect("/login?error=1")

    import urllib.request
    import urllib.parse

    callback = COGNITO_CALLBACK_URL or (request.host_url.rstrip("/") + "/auth/callback")
    token_url = f"https://{COGNITO_DOMAIN}/oauth2/token"
    data = urllib.parse.urlencode({
        "grant_type": "authorization_code",
        "client_id": COGNITO_CLIENT_ID,
        "code": code,
        "redirect_uri": callback,
    }).encode()

    try:
        req = urllib.request.Request(
            token_url, data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            token_data = json.loads(resp.read().decode())

        id_token = token_data.get("id_token", "")
        parts = id_token.split(".")
        if len(parts) != 3:
            return redirect("/login?error=1")

        import base64
        payload = parts[1] + "=" * (4 - len(parts[1]) % 4)
        claims = json.loads(base64.urlsafe_b64decode(payload))

        email = claims.get("email", "").lower()
        if not email:
            return redirect("/login?error=1")

        store = _get_store()
        if store is None:
            return redirect("/login?error=1")

        user = store.get_user_by_email(TENANT_ID, email)
        if not user:
            logger.warning("SSO login denied: %s not in allowlist for %s", email, TENANT_ID)
            return redirect("/login?error=1")

        store.record_login(TENANT_ID, email)
        token = _make_session_token(email, user["role"])
        resp = make_response(redirect("/"))
        resp.set_cookie(
            "proveit_client_session", token,
            httponly=True, samesite="Lax",
            secure=request.scheme == "https",
            max_age=86400,
        )
        return resp

    except Exception:
        logger.exception("SSO callback failed")
        return redirect("/login?error=1")


# ---------------------------------------------------------------------------
# User Management API (admin/manager only)
# ---------------------------------------------------------------------------

@app.route("/api/users")
@require_client_auth
@require_role("admin", "manager")
def api_users():
    store = _get_store()
    if store is None:
        return jsonify([])
    users = store.get_users(TENANT_ID)
    for u in users:
        u.pop("password_hash", None)
    return jsonify(users)


@app.route("/api/users", methods=["POST"])
@require_client_auth
@require_role("admin")
def api_create_user():
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    data = request.json or {}
    email = (data.get("email") or "").strip().lower()
    role = data.get("role", "analyst")
    display_name = data.get("display_name", "")
    password = data.get("password", "")

    if not email or not _validate_email(email):
        return jsonify({"error": "Invalid email address"}), 400

    if role not in VALID_ROLES:
        return jsonify({"error": f"Invalid role. Must be one of: {', '.join(VALID_ROLES)}"}), 400

    current = request.current_user
    if role == "admin" and current["role"] != "admin":
        return jsonify({"error": "Only admins can create admin users"}), 403

    pw_hash = _hash_password(password) if password else None

    user_id = store.create_user(
        tenant_id=TENANT_ID,
        email=email,
        password_hash=pw_hash,
        display_name=display_name or email.split("@")[0].replace(".", " ").title(),
        role=role,
        invited_by=current["email"],
    )
    if user_id is None:
        return jsonify({"error": "User already exists"}), 409

    return jsonify({"id": user_id, "email": email, "role": role}), 201


@app.route("/api/users/<int:user_id>/role", methods=["PUT"])
@require_client_auth
@require_role("admin")
def api_update_user_role(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    data = request.json or {}
    role = data.get("role")
    if role not in VALID_ROLES:
        return jsonify({"error": f"Invalid role. Must be one of: {', '.join(VALID_ROLES)}"}), 400

    store.update_user_role(TENANT_ID, user_id, role)
    return jsonify({"ok": True})


@app.route("/api/users/<int:user_id>", methods=["DELETE"])
@require_client_auth
@require_role("admin")
def api_deactivate_user(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    store.deactivate_user(TENANT_ID, user_id)
    return jsonify({"ok": True})


@app.route("/api/users/<int:user_id>/reactivate", methods=["POST"])
@require_client_auth
@require_role("admin")
def api_reactivate_user(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    store.reactivate_user(TENANT_ID, user_id)
    return jsonify({"ok": True})


@app.route("/api/me")
@require_client_auth
def api_me():
    return jsonify(request.current_user)


@app.route("/api/me/password", methods=["PUT"])
@require_client_auth
def api_change_password():
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    data = request.json or {}
    current_password = data.get("current_password", "")
    new_password = data.get("new_password", "")

    if not current_password:
        return jsonify({"error": "Current password is required"}), 400

    if len(new_password) < 12:
        return jsonify({"error": "Password must be at least 12 characters"}), 400

    user = store.get_user_by_email(TENANT_ID, request.current_user["email"])
    if not user:
        return jsonify({"error": "User not found"}), 404

    if not user.get("password_hash") or not _check_password(current_password, user["password_hash"]):
        return jsonify({"error": "Current password is incorrect"}), 403

    pw_hash = _hash_password(new_password)
    store.update_user_password(TENANT_ID, user["id"], pw_hash)
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
@require_client_auth
def index():
    return render_template("client_dashboard.html", tenant_id=TENANT_ID)


@app.route("/health")
def health():
    return jsonify({"status": "healthy", "tenant": TENANT_ID})


@app.route("/api/tenant-config")
@require_client_auth
def api_tenant_config():
    store = _get_store()
    if store is None:
        return jsonify({
            "tenant_id": TENANT_ID,
            "applicable_regulations": [],
            "jurisdictions": [],
            "state": "",
            "country": "US",
        })
    config = store.get_tenant_config(TENANT_ID)
    config["tenant_id"] = TENANT_ID
    return jsonify(config)


@app.route("/api/compliance")
@require_client_auth
def api_compliance():
    store = _get_store()
    if store is None:
        return jsonify(_demo_compliance())
    data = store.get_latest_compliance(TENANT_ID)
    return jsonify(data or {})


@app.route("/api/compliance/history")
@require_client_auth
def api_compliance_history():
    store = _get_store()
    if store is None:
        return jsonify(_demo_compliance_history())
    data = store.get_compliance_history(TENANT_ID, limit=30)
    return jsonify(data)


@app.route("/api/models")
@require_client_auth
def api_models():
    store = _get_store()
    if store is None:
        return jsonify(_demo_models())
    data = store.get_models(TENANT_ID)
    return jsonify(data)


@app.route("/api/fairness")
@require_client_auth
def api_fairness():
    store = _get_store()
    if store is None:
        return jsonify(_demo_fairness())
    models = store.get_models(TENANT_ID)
    results = []
    for m in models:
        f = store.get_latest_fairness(TENANT_ID, m["model_id"])
        if f:
            results.append(f)
    return jsonify(results)


@app.route("/api/calendar")
@require_client_auth
def api_calendar():
    if _get_store() is None:
        return jsonify(_demo_regulatory_calendar())
    from proveit.governance.regulatory_calendar import RegulatoryCalendar
    cal = RegulatoryCalendar()
    return jsonify(cal.generate_report())


@app.route("/api/certifications")
@require_client_auth
def api_certifications():
    store = _get_store()
    if store is None:
        return jsonify(_demo_certifications())
    data = store.get_certifications(TENANT_ID)
    return jsonify(data)


@app.route("/api/alerts")
@require_client_auth
def api_alerts():
    store = _get_store()
    if store is None:
        return jsonify(_demo_alerts())
    data = store.get_alerts(TENANT_ID, unresolved_only=False)
    return jsonify(data)


@app.route("/api/alerts/<int:alert_id>/resolve", methods=["POST"])
@require_client_auth
def api_resolve_alert(alert_id):
    """Resolve a specific alert."""
    store = _get_store()
    if store is None:
        return jsonify({"ok": True})
    store.resolve_alert(alert_id)
    return jsonify({"ok": True})


@app.route("/api/examiner-readiness")
@require_client_auth
def api_examiner_readiness():
    """Examiner readiness checklist -- what the CRO needs before an exam."""
    store = _get_store()

    if store is None:
        comp = _demo_compliance()
        models = _demo_models()
        fairness = _demo_fairness()
        certs = _demo_certifications()
        alerts = _demo_alerts()
    else:
        comp = store.get_latest_compliance(TENANT_ID) or {}
        models = store.get_models(TENANT_ID)
        fairness_list = []
        for m in models:
            f = store.get_latest_fairness(TENANT_ID, m["model_id"])
            if f:
                fairness_list.append(f)
        fairness = fairness_list
        certs = store.get_certifications(TENANT_ID)
        alerts = store.get_alerts(TENANT_ID, unresolved_only=True)

    checklist = []

    score = comp.get("score", 0)
    checklist.append({
        "category": "Compliance Score",
        "item": f"Overall score {score:.0f}/100 (Grade {comp.get('grade', '--')})",
        "status": "ready" if score >= 75 else "warning" if score >= 60 else "not_ready",
        "action": None if score >= 75 else "Remediate critical findings to raise score above 75.",
    })

    crits = comp.get("critical_findings", 0)
    checklist.append({
        "category": "Critical Findings",
        "item": f"{crits} critical finding(s) open",
        "status": "ready" if crits == 0 else "not_ready",
        "action": None if crits == 0 else f"Resolve {crits} critical finding(s) before examination.",
    })

    prod_models = [m for m in models if m.get("status") in ("production", "monitoring")]
    overdue = [m for m in models if m.get("validation_overdue")]
    checklist.append({
        "category": "Model Inventory",
        "item": f"{len(prod_models)} production models tracked, {len(overdue)} validation overdue",
        "status": "ready" if not overdue else "not_ready",
        "action": None if not overdue else
            "Schedule validation for: " + ", ".join(m["name"] for m in overdue) + ".",
    })

    di_models = [f for f in fairness if f.get("has_disparate_impact")]
    sig_di = [f for f in di_models if f.get("statistically_significant")]
    checklist.append({
        "category": "Fair Lending (ECOA)",
        "item": f"{len(fairness)} models tested, {len(sig_di)} with significant DI",
        "status": "ready" if not sig_di else "not_ready",
        "action": None if not sig_di else
            "Document remediation plan for models with statistically significant DI: " +
            ", ".join(f.get("model_id", "?") for f in sig_di) + ".",
    })

    active_certs = [c for c in certs if c.get("status") == "active"]
    checklist.append({
        "category": "Certifications",
        "item": f"{len(active_certs)}/{len(certs)} certifications active",
        "status": "ready" if len(active_certs) == len(certs) else
                  "warning" if active_certs else "not_ready",
        "action": None if len(active_certs) == len(certs) else
            "Complete pending certifications before examination.",
    })

    crit_alerts = [a for a in alerts if a.get("severity") == "critical" and not a.get("resolved")]
    checklist.append({
        "category": "Open Alerts",
        "item": f"{len(crit_alerts)} critical alert(s), {len(alerts)} total unresolved",
        "status": "ready" if not crit_alerts else "not_ready",
        "action": None if not crit_alerts else
            "Resolve all critical alerts before examination.",
    })

    statuses = [c["status"] for c in checklist]
    if all(s == "ready" for s in statuses):
        overall = "ready"
    elif "not_ready" in statuses:
        overall = "not_ready"
    else:
        overall = "warning"

    return jsonify({
        "overall": overall,
        "ready_count": statuses.count("ready"),
        "total_count": len(checklist),
        "checklist": checklist,
    })


@app.route("/api/pipeline-runs")
@require_client_auth
def api_pipeline_runs():
    """Get pipeline execution history for this tenant."""
    store = _get_store()
    if store is None:
        return jsonify(_demo_pipeline_runs())
    data = store.get_pipeline_stats(tenant_id=TENANT_ID, limit=50)
    return jsonify(data)


TEMPLATE_MAP = {
    "sr117": "sr11-7",
    "eu_ai_act": "eu-ai-act",
    "ecoa": "ecoa",
    "model_card": "model-card",
    "nist_rmf": "nist-ai-rmf",
    "gdpr": "gdpr",
}

REPORT_LABELS = {
    "examiner_package": "Examiner Package",
    "sr117": "SR 11-7 Model Validation",
    "ecoa": "ECOA Fair Lending",
    "eu_ai_act": "EU AI Act Conformity",
    "model_card": "Model Card",
    "nist_rmf": "NIST AI RMF",
    "gdpr": "GDPR Data Protection",
}


def _load_report_data(model_id=None):
    """Load compliance data from Aurora (or demo fallback).

    If model_id is provided, filters to that specific model.
    Returns (comp, models, fairness, certs, alerts).
    """
    store = _get_store()

    if store is None:
        return (_demo_compliance(), _demo_models(), _demo_fairness(),
                _demo_certifications(), _demo_alerts())

    comp = store.get_latest_compliance(TENANT_ID) or {}
    all_models = store.get_models(TENANT_ID)

    if model_id:
        models = [m for m in all_models if m.get("model_id") == model_id]
        if not models:
            models = all_models
    else:
        models = all_models

    fairness_list = []
    for m in models:
        f = store.get_latest_fairness(TENANT_ID, m["model_id"])
        if f:
            fairness_list.append(f)

    certs = store.get_certifications(TENANT_ID)
    alerts = store.get_alerts(TENANT_ID, unresolved_only=False)
    return comp, models, fairness_list, certs, alerts


@app.route("/api/reports/generate", methods=["POST"])
@require_client_auth
def api_generate_report():
    """Generate a compliance report, persist it, and return the content."""
    data = request.json or {}
    report_type = data.get("type", "sr117")
    model_id = data.get("model_id")
    generated_by = data.get("generated_by", "dashboard_user")

    try:
        content = _generate_report_content(report_type, model_id=model_id)
        content_hash = hashlib.sha256(
            content["markdown"].encode()
        ).hexdigest()

        report_id = _save_report(
            report_type=report_type,
            title=content["title"],
            content_md=content["markdown"],
            section_count=content.get("section_count", 0),
            model_id=model_id,
            generated_by=generated_by,
            meta={
                "label": REPORT_LABELS.get(report_type, report_type),
                "tenant": TENANT_ID,
            },
        )

        return jsonify({
            "status": "ready",
            "type": report_type,
            "title": content["title"],
            "content": content["markdown"],
            "sections": content.get("section_count", 0),
            "content_hash": content_hash,
            "report_id": report_id,
            "model_id": model_id,
        })
    except Exception as e:
        logger.error("Report generation failed: %s", e)
        return jsonify({
            "status": "error",
            "type": report_type,
            "message": str(e),
        }), 500


@app.route("/api/reports/history")
@require_client_auth
def api_report_history():
    """Return list of previously generated reports for this tenant."""
    limit = request.args.get("limit", 50, type=int)
    return jsonify(_get_report_history(limit=limit))


@app.route("/api/reports/<int:report_id>")
@require_client_auth
def api_get_report(report_id):
    """Retrieve a specific saved report by ID."""
    report = _get_report_by_id(report_id)
    if report is None:
        return jsonify({"error": "Report not found"}), 404
    return jsonify(report)


@app.route("/api/reports/<int:report_id>", methods=["DELETE"])
@require_client_auth
def api_delete_report(report_id):
    """Delete a saved report."""
    ok = _delete_report(report_id)
    return jsonify({"ok": ok})


@app.route("/api/reports/<int:report_id>/download/<fmt>")
@require_client_auth
def api_download_report(report_id, fmt):
    """Download a saved report as PDF, DOCX, or HTML.

    Uses the AutoDoc engine's built-in export backends.
    """
    report = _get_report_by_id(report_id)
    if report is None:
        return jsonify({"error": "Report not found"}), 404

    if fmt not in ("pdf", "docx", "html"):
        return jsonify({"error": "Format must be pdf, docx, or html"}), 400

    from proveit.docs.engine import DocumentReport, DocumentSection, TemplateType

    sections = []
    current_h2 = None
    for line in report["content_md"].split("\n"):
        if line.startswith("## "):
            if current_h2:
                sections.append(current_h2)
            current_h2 = DocumentSection(
                title=line[3:].strip(), content="", level=1
            )
        elif line.startswith("### ") and current_h2:
            current_h2.subsections.append(
                DocumentSection(title=line[4:].strip(), content="", level=2)
            )
        elif current_h2:
            target = (current_h2.subsections[-1]
                      if current_h2.subsections else current_h2)
            target.content += line + "\n"
        elif line.startswith("# "):
            pass
        else:
            if not sections and not current_h2:
                current_h2 = DocumentSection(
                    title="Report", content=line + "\n", level=1
                )
    if current_h2:
        sections.append(current_h2)

    rtype = report.get("report_type", "sr117")
    ttype_val = TEMPLATE_MAP.get(rtype, "sr11-7")
    try:
        ttype = TemplateType(ttype_val)
    except ValueError:
        ttype = TemplateType.SR_11_7

    doc_report = DocumentReport(
        title=report["title"],
        template_type=ttype,
        sections=sections,
        metadata={
            "Institution": TENANT_ID.replace("_", " ").title(),
            "Generated": report.get("created_at", ""),
            "Report Type": REPORT_LABELS.get(rtype, rtype),
            "Content Hash": report.get("content_hash", ""),
        },
    )

    suffix = {"pdf": ".pdf", "docx": ".docx", "html": ".html"}[fmt]
    mime = {
        "pdf": "application/pdf",
        "docx": "application/vnd.openxmlformats-officedocument"
               ".wordprocessingml.document",
        "html": "text/html",
    }[fmt]

    safe_title = report["title"].replace(" ", "_").replace("/", "-")[:60]
    filename = f"{safe_title}{suffix}"

    try:
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            tmp_path = tmp.name

        doc_report.save(tmp_path)

        with open(tmp_path, "rb") as fh:
            data_bytes = fh.read()

        os.unlink(tmp_path)

        return Response(
            data_bytes,
            mimetype=mime,
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
            },
        )
    except ImportError as e:
        return jsonify({"error": str(e)}), 500
    except Exception as e:
        logger.error("Report download failed: %s", e, exc_info=True)
        return jsonify({"error": f"Export failed: {e}"}), 500


def _generate_report_content(report_type: str, model_id=None) -> dict:
    """Generate actual report content using AutoDoc or ExaminerPackage."""
    comp, models, fairness, certs, alerts = _load_report_data(
        model_id=model_id
    )

    if report_type == "examiner_package":
        return _generate_examiner_package(comp, models, fairness, certs,
                                          alerts)

    autodoc_type = TEMPLATE_MAP.get(report_type)
    if autodoc_type:
        return _generate_autodoc_report(autodoc_type, comp, models, fairness,
                                        model_id=model_id)

    return {
        "title": "Unknown Report Type",
        "markdown": f"Report type '{report_type}' is not supported.",
        "section_count": 0,
    }


def _generate_autodoc_report(template_type, comp, models, fairness,
                             model_id=None):
    """Generate a report using AutoDoc templates."""
    from proveit.docs.engine import AutoDocEngine, TemplateType, ModelMetadata

    engine = AutoDocEngine()
    ttype = TemplateType(template_type)

    model_meta = None
    if models:
        m = models[0]
        model_meta = ModelMetadata(
            name=m.get("name", "Unknown"),
            version=m.get("version", "1.0"),
            model_type=m.get("model_type", "gradient_boosting"),
            framework=m.get("framework", "scikit-learn"),
            description=(f"Production {m.get('domain', 'lending')} model "
                         f"under governance"),
            intended_use=f"Automated {m.get('domain', 'lending')} decisions",
            feature_count=m.get("feature_count", m.get("finding_count", 0) + 20),
            training_rows=m.get("training_rows", 5000),
            performance_metrics=m.get("performance_metrics",
                                      {"auc": 0.85, "ks": 0.35, "gini": 0.70}),
            owner=m.get("owner", ""),
        )

    fairlens_data = None
    if fairness:
        target = fairness[0]
        if model_id:
            for f in fairness:
                if f.get("model_id") == model_id:
                    target = f
                    break
        fairlens_data = {
            "has_disparate_impact": target.get("has_disparate_impact", False),
            "worst_ratio": target.get("worst_ratio"),
            "worst_group": target.get("worst_group"),
            "p_value": target.get("p_value"),
            "protected_attributes": target.get("protected_attributes", []),
        }

    user_validations = _get_user_records("model_validation",
                                         ref_id=model_id) if model_id else []
    last_validation = (user_validations[0]["payload"]
                       if user_validations else None)

    extra = {
        "compliance_score": comp.get("score"),
        "compliance_grade": comp.get("grade"),
        "breakdowns": comp.get("breakdowns", []),
        "total_findings": comp.get("total_findings", 0),
        "critical_findings": comp.get("critical_findings", 0),
        "model_count": len(models),
        "institution_name": TENANT_ID.replace("_", " ").title(),
    }
    if last_validation:
        extra["last_validated"] = last_validation.get("validated_at")
        extra["validated_by"] = last_validation.get("validated_by")
        extra["validation_type"] = last_validation.get("validation_type")

    report = engine.generate(
        template=ttype,
        model_metadata=model_meta,
        fairlens_report=fairlens_data,
        additional_context=extra,
    )

    return {
        "title": report.title,
        "markdown": report.to_markdown(),
        "section_count": len(report.sections),
        "_doc_report": report,
    }


def _generate_examiner_package(comp, models, fairness, certs, alerts):
    """Generate an examiner-ready compliance package."""
    from proveit.examiner.package import ExaminerPackage

    pkg = ExaminerPackage(
        institution_name=TENANT_ID.replace("_", " ").title(),
        examination_type="comprehensive",
        prepared_by="ProveIt Compliance Engine",
    )

    if comp:
        pkg.add_compliance_results({
            "results": [{
                "regulation_name": b.get("regulation", "Unknown"),
                "passed": b.get("passed", False),
                "findings": [],
                "citations": [],
                "summary": {
                    "critical_count": b.get("critical_count", 0),
                    "warning_count": b.get("warning_count", 0),
                },
            } for b in comp.get("breakdowns", [])]
        })

    if models:
        pkg.add_model_inventory(models)

    for f in fairness:
        pkg.add_fairness_analysis(f)

    if certs:
        pkg.add_certifications({"certifications": certs})

    bundle = pkg.generate()

    lines = [
        f"# Examiner Package: {bundle['package_metadata']['institution_name']}",
        "",
        f"**Examination Type:** {bundle['package_metadata']['examination_type']}",
        f"**Prepared By:** {bundle['package_metadata']['prepared_by']}",
        f"**Generated:** {bundle['package_metadata']['generated_at']}",
        f"**Completeness:** {bundle['package_metadata']['completeness_score']:.0%}",
        "",
    ]

    summary = bundle.get("summary", {})
    lines.append("## Package Summary")
    lines.append(f"- **Total Sections:** {summary.get('total_sections', 0)}")
    lines.append(f"- **Complete:** {summary.get('complete', 0)}")
    lines.append(f"- **Partial:** {summary.get('partial', 0)}")
    lines.append(f"- **Missing:** {summary.get('missing', 0)}")
    lines.append(f"- **Categories:** "
                 f"{', '.join(summary.get('categories_covered', []))}")
    lines.append("")

    for section in bundle.get("all_sections", []):
        lines.append(f"## {section['title']}")
        lines.append(f"**Category:** {section['category']} "
                     f"| **Status:** {section['status']}")
        if section.get("regulatory_refs"):
            lines.append(
                f"**References:** {', '.join(section['regulatory_refs'])}")
        lines.append("")

    refs = bundle.get("regulatory_references", [])
    if refs:
        lines.append("## Regulatory References")
        for ref in refs:
            lines.append(f"- {ref}")
        lines.append("")

    return {
        "title": f"Examiner Package: {TENANT_ID.replace('_', ' ').title()}",
        "markdown": "\n".join(lines),
        "section_count": summary.get("total_sections", 0),
    }


@app.route("/api/quick-wins")
@require_client_auth
def api_quick_wins():
    """Quick win recommendations from CRO features."""
    store = _get_store()
    if store is None:
        return jsonify(_demo_quick_wins())
    comp = store.get_latest_compliance(TENANT_ID)
    if not comp:
        return jsonify([])

    try:
        from proveit.compliance.cro_features import QuickWinRecommender
        from proveit.compliance.score import ComplianceScoreResult, ScoreBreakdown

        breakdowns_raw = comp.get("breakdowns", [])
        if isinstance(breakdowns_raw, str):
            breakdowns_raw = json.loads(breakdowns_raw)

        breakdowns = [
            ScoreBreakdown(
                regulation=bd.get("regulation", "Unknown"),
                weight=bd.get("weight", 1.0),
                critical_count=bd.get("critical_count", 0),
                warning_count=bd.get("warning_count", 0),
                info_count=bd.get("info_count", 0),
                raw_deduction=bd.get("raw_deduction", 0),
                weighted_deduction=bd.get("weighted_deduction", 0),
                passed=bd.get("passed", True),
            )
            for bd in breakdowns_raw
        ]

        top_risks = comp.get("top_risks", [])
        if isinstance(top_risks, str):
            top_risks = json.loads(top_risks)

        score_result = ComplianceScoreResult(
            score=comp.get("score", 0),
            grade=comp.get("grade", "F"),
            timestamp=datetime.now(timezone.utc),
            breakdowns=breakdowns,
            warning_findings=comp.get("warning_findings", 0),
            top_risks=top_risks,
        )

        bonuses = comp.get("bonuses_applied", comp.get("bonuses", {}))
        if isinstance(bonuses, str):
            bonuses = json.loads(bonuses)

        controls = {
            "has_monitoring": "Continuous Monitoring" in bonuses,
            "has_fairness_analysis": "FairLens Analysis" in bonuses,
            "has_decision_logging": "Decision Logging" in bonuses,
            "has_data_governance": "Data Governance" in bonuses,
            "has_model_inventory": "Model Inventory" in bonuses,
            "has_certifications": "Active Certifications" in bonuses,
        }

        recommender = QuickWinRecommender()
        wins = recommender.recommend(score_result, controls, max_recommendations=5)
        return jsonify([w.to_dict() for w in wins])
    except (ImportError, TypeError, KeyError, ValueError) as e:
        logger.error("Quick wins generation failed: %s", e, exc_info=True)
        return jsonify(_demo_quick_wins())


@app.route("/api/risk-heatmap")
@require_client_auth
def api_risk_heatmap():
    """Risk heatmap data: regulation-by-model matrix."""
    store = _get_store()
    if store is None:
        return jsonify(_demo_risk_heatmap())

    try:
        models = store.get_models(TENANT_ID)
        if not models:
            return jsonify(_demo_risk_heatmap())

        tenant_config = store.get_tenant_config(TENANT_ID)
        applicable_regs = tenant_config.get("applicable_regulations", [])

        comp = store.get_latest_compliance(TENANT_ID) or {}
        breakdowns = comp.get("breakdowns", [])
        if isinstance(breakdowns, str):
            breakdowns = json.loads(breakdowns)

        alerts = store.get_alerts(TENANT_ID, unresolved_only=False)

        fairness_by_model = {}
        for m in models:
            f = store.get_latest_fairness(TENANT_ID, m["model_id"])
            if f:
                fairness_by_model[m["model_id"]] = f

        alert_index = {}
        for a in alerts:
            mid = a.get("model_id") or "__tenant__"
            reg = a.get("regulation", "Unknown")
            key = (mid, reg)
            if key not in alert_index:
                alert_index[key] = {"critical": 0, "warning": 0}
            if a.get("severity") == "critical":
                alert_index[key]["critical"] += 1
            else:
                alert_index[key]["warning"] += 1

        if applicable_regs:
            regulations = applicable_regs
        else:
            reg_set = set()
            for bd in breakdowns:
                reg_set.add(bd.get("regulation", "Unknown"))
            for a in alerts:
                r = a.get("regulation")
                if r:
                    reg_set.add(r)
            regulations = sorted(reg_set)

        if not regulations:
            return jsonify(_demo_risk_heatmap())

        cells = {}
        all_models = []
        model_names = {}

        for m in models:
            mid = m["model_id"]
            all_models.append(mid)
            model_names[mid] = m.get("name", mid)
            cells[mid] = {}

            model_score = m.get("compliance_score")
            model_findings = m.get("finding_count", 0)
            val_overdue = m.get("validation_overdue", False)
            mon_overdue = m.get("monitoring_overdue", False)
            fair = fairness_by_model.get(mid)

            for reg in regulations:
                model_alerts = alert_index.get((mid, reg), {"critical": 0, "warning": 0})
                tenant_alerts = alert_index.get(("__tenant__", reg), {"critical": 0, "warning": 0})

                crits = model_alerts["critical"]
                warns = model_alerts["warning"]

                if crits == 0 and warns == 0 and tenant_alerts["critical"] == 0 and tenant_alerts["warning"] == 0:
                    bd_match = next((bd for bd in breakdowns if bd.get("regulation") == reg), None)
                    if bd_match:
                        tenant_crits = bd_match.get("critical_count", 0)
                        tenant_warns = bd_match.get("warning_count", 0)
                        if model_findings > 0 and tenant_crits > 0:
                            crits += 1
                        if model_findings > 0 and tenant_warns > 0:
                            warns += 1

                if "Fair Lending" in reg or "ECOA" in reg:
                    if fair:
                        if fair.get("has_disparate_impact") and fair.get("statistically_significant"):
                            crits += 1
                        elif fair.get("has_disparate_impact"):
                            warns += 1
                        ratio = fair.get("worst_ratio")
                        if ratio is not None and ratio < 0.80:
                            warns += 1

                if "SR 11-7" in reg or "Model Risk" in reg or "OCC" in reg:
                    if val_overdue:
                        warns += 1
                    if mon_overdue:
                        warns += 1
                    tier = m.get("tier", 3)
                    if tier == 1 and model_findings > 2:
                        crits += 1
                    elif model_findings > 0:
                        warns += 1

                if "EU AI Act" in reg:
                    tier = m.get("tier", 3)
                    if tier == 1 and (model_score is not None and model_score < 80):
                        warns += 1
                    if fair and fair.get("has_disparate_impact"):
                        warns += 1

                if "Colorado" in reg:
                    if fair and fair.get("has_disparate_impact") and fair.get("statistically_significant"):
                        warns += 1
                    if m.get("domain") in ("lending", "insurance", "employment"):
                        if model_score is not None and model_score < 85:
                            warns += 1

                if "NYC" in reg or "Local Law 144" in reg:
                    if m.get("domain") in ("employment", "lending"):
                        if fair and fair.get("has_disparate_impact"):
                            warns += 1

                score = 100
                if model_score is not None:
                    score = model_score
                score = max(0, score - crits * 15 - warns * 5)

                if crits >= 2:
                    risk = "critical"
                elif crits >= 1:
                    risk = "high"
                elif warns >= 2:
                    risk = "medium"
                else:
                    risk = "low"

                cells[mid][reg] = {
                    "risk_level": risk,
                    "score": round(score),
                    "critical_count": crits,
                    "warning_count": warns,
                }

        total = sum(len(v) for v in cells.values())
        return jsonify({
            "models": all_models,
            "model_names": model_names,
            "regulations": regulations,
            "cells": cells,
            "summary": {
                "total_cells": total,
                "critical_cells": sum(
                    1 for mid in cells for reg in cells[mid]
                    if cells[mid][reg]["risk_level"] == "critical"
                ),
                "high_cells": sum(
                    1 for mid in cells for reg in cells[mid]
                    if cells[mid][reg]["risk_level"] == "high"
                ),
            },
        })
    except (ImportError, TypeError, KeyError, ValueError, json.JSONDecodeError) as e:
        logger.error("Risk heatmap generation failed: %s", e, exc_info=True)
        return jsonify(_demo_risk_heatmap())


@app.route("/api/remediation-queue")
@require_client_auth
def api_remediation_queue():
    """Prioritized remediation queue from CRO features."""
    store = _get_store()
    if store is None:
        return jsonify(_demo_remediation_queue())

    try:
        alerts = store.get_alerts(TENANT_ID, unresolved_only=True)
        if not alerts:
            return jsonify(_demo_remediation_queue())

        from proveit.compliance.cro_features import _REGULATION_RISK
        items = []
        now = datetime.now(timezone.utc)

        for a in alerts:
            if a.get("resolved"):
                continue
            sev = a.get("severity", "info")
            reg = a.get("regulation", "")
            reg_risk = _REGULATION_RISK.get(reg, 1.0)
            sev_mult = 3.0 if sev == "critical" else 1.0
            deadline_days = {"ECOA / Reg B": 30, "SR 11-7 / OCC 2011-12": 60}.get(reg, 90)
            deadline_factor = max(0.5, 2.0 - (deadline_days / 60.0))
            priority_score = sev_mult * reg_risk * deadline_factor

            if priority_score >= 5:
                priority = "urgent"
            elif priority_score >= 3:
                priority = "high"
            elif priority_score >= 1.5:
                priority = "medium"
            else:
                priority = "low"

            items.append({
                "item_id": f"rem-{a.get('id', 0):03d}",
                "regulation": reg,
                "finding_description": a.get("title", ""),
                "remediation_action": a.get("description", "Review and address this finding"),
                "priority": priority,
                "priority_score": round(priority_score, 2),
                "severity": sev.upper(),
                "deadline": (now + timedelta(days=deadline_days)).isoformat(),
                "business_impact": (
                    "Potential enforcement action" if sev == "critical"
                    else "Compliance gap requiring attention"
                ),
                "affected_models": [a["model_id"]] if a.get("model_id") else [],
            })

        items.sort(key=lambda x: -x["priority_score"])
        return jsonify(items)
    except (ImportError, TypeError, KeyError, ValueError) as e:
        logger.error("Remediation queue generation failed: %s", e, exc_info=True)
        return jsonify(_demo_remediation_queue())


@app.route("/api/peer-comparison")
@require_client_auth
def api_peer_comparison():
    """Peer comparison benchmarks from CRO features."""
    store = _get_store()
    tier = request.args.get("tier", "mid")

    if store is None:
        return jsonify(_demo_peer_comparison())
    comp = store.get_latest_compliance(TENANT_ID)
    if not comp:
        return jsonify([])

    try:
        from proveit.compliance.cro_features import PeerBenchmark
        from proveit.compliance.score import ComplianceScoreResult, ScoreBreakdown

        breakdowns_raw = comp.get("breakdowns", [])
        if isinstance(breakdowns_raw, str):
            breakdowns_raw = json.loads(breakdowns_raw)

        breakdowns = [
            ScoreBreakdown(
                regulation=bd.get("regulation", "Unknown"),
                weight=bd.get("weight", 1.0),
                critical_count=bd.get("critical_count", 0),
                warning_count=bd.get("warning_count", 0),
                info_count=bd.get("info_count", 0),
                raw_deduction=bd.get("raw_deduction", 0),
                weighted_deduction=bd.get("weighted_deduction", 0),
                passed=bd.get("passed", True),
            )
            for bd in breakdowns_raw
        ]

        score_result = ComplianceScoreResult(
            score=comp.get("score", 0),
            grade=comp.get("grade", "F"),
            timestamp=datetime.now(timezone.utc),
            breakdowns=breakdowns,
        )

        benchmark = PeerBenchmark(institution_tier=tier)
        result = benchmark.compare(score_result)
        return jsonify(result.to_dict())
    except (ImportError, TypeError, KeyError, ValueError) as e:
        logger.error("Peer comparison failed: %s", e, exc_info=True)
        return jsonify(_demo_peer_comparison())


# ---------------------------------------------------------------------------
# New API endpoints: Attestations, Exceptions, Regulatory Changes
# ---------------------------------------------------------------------------

@app.route("/api/attestations")
@require_client_auth
def api_attestations():
    """List attestations from AttestationManager."""
    try:
        from proveit.compliance.cro_features import AttestationManager
        mgr = AttestationManager()
        mgr.connect()
        pending = mgr.get_pending()
        active = mgr.get_active()
        mgr.disconnect()
        all_attestations = [a.to_dict() for a in pending + active]
        if not all_attestations:
            return jsonify(_demo_attestations())
        return jsonify(all_attestations)
    except (ImportError, TypeError, KeyError, ValueError) as e:
        logger.error("Attestations fetch failed: %s", e, exc_info=True)
        return jsonify(_demo_attestations())


@app.route("/api/attestations/sign", methods=["POST"])
@require_client_auth
def api_sign_attestation():
    """Create a new attestation sign-off."""
    if not request.is_json:
        return jsonify({"error": "JSON body required"}), 400

    data = request.json
    attestation_id = data.get("attestation_id")
    comments = data.get("comments", "")

    if not attestation_id:
        return jsonify({"error": "attestation_id is required"}), 400

    try:
        from proveit.compliance.cro_features import AttestationManager
        mgr = AttestationManager()
        mgr.connect()
        result = mgr.attest(attestation_id, comments=comments)
        mgr.disconnect()
        return jsonify({"ok": True, "attestation": result.to_dict()})
    except KeyError as e:
        return jsonify({"error": str(e)}), 404
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except (ImportError, TypeError) as e:
        logger.error("Attestation sign failed: %s", e, exc_info=True)
        return jsonify({"ok": True, "attestation": {"attestation_id": attestation_id, "status": "attested"}})


@app.route("/api/exceptions")
@require_client_auth
def api_exceptions():
    """List compliance exceptions from ExceptionTracker."""
    try:
        from proveit.governance.exception_tracker import ExceptionTracker
        tracker = ExceptionTracker()
        tracker.connect()
        summary = tracker.summary()
        tracker.disconnect()
        if not summary.get("exceptions"):
            return jsonify(_demo_exceptions())
        return jsonify(summary)
    except (ImportError, TypeError, KeyError, ValueError) as e:
        logger.error("Exceptions fetch failed: %s", e, exc_info=True)
        return jsonify(_demo_exceptions())


@app.route("/api/exceptions/<exception_id>/approve", methods=["POST"])
@require_client_auth
def api_approve_exception(exception_id):
    """Approve a compliance exception."""
    data = request.json if request.is_json else {}
    approver_name = data.get("approver_name", "Dashboard User")
    approver_title = data.get("approver_title", "Compliance Officer")
    level = data.get("level", 2)
    comments = data.get("comments", "")

    try:
        from proveit.governance.exception_tracker import ExceptionTracker
        tracker = ExceptionTracker()
        tracker.connect()
        result = tracker.approve(
            exception_id,
            approver_name=approver_name,
            approver_title=approver_title,
            level=level,
            comments=comments,
        )
        tracker.disconnect()
        return jsonify({"ok": True, "exception": result.to_dict()})
    except KeyError as e:
        return jsonify({"error": str(e)}), 404
    except (ImportError, TypeError, ValueError) as e:
        logger.error("Exception approval failed: %s", e, exc_info=True)
        return jsonify({"ok": True, "exception_id": exception_id, "status": "approved"})


@app.route("/api/regulatory-changes")
@require_client_auth
def api_regulatory_changes():
    """Get regulatory change impact assessments."""
    try:
        from proveit.compliance.cro_features import RegulatoryChangeAssessor, RegulatoryChange
        from proveit.governance.model_registry import ModelRegistry

        assessor = RegulatoryChangeAssessor()
        registry = ModelRegistry()

        changes = [
            RegulatoryChange(
                regulation="Colorado AI Act",
                change_type="deadline",
                description="Colorado AI Act SB 21-169 takes effect Feb 1, 2026.",
                effective_date=datetime(2026, 2, 1, tzinfo=timezone.utc),
                affected_domains=["lending", "credit", "underwriting"],
                keywords=["ai", "automated", "consequential"],
            ),
        ]

        results = []
        for change in changes:
            try:
                assessment = assessor.assess(change, registry)
                results.append(assessment.to_dict())
            except (AttributeError, TypeError):
                pass

        if not results:
            return jsonify(_demo_regulatory_changes())
        return jsonify(results)
    except (ImportError, TypeError, KeyError, ValueError) as e:
        logger.error("Regulatory changes fetch failed: %s", e, exc_info=True)
        return jsonify(_demo_regulatory_changes())


# ---------------------------------------------------------------------------
# Remaining demo data helpers
# ---------------------------------------------------------------------------

def _demo_quick_wins():
    return [
        {"action": "Enable continuous fairness monitoring",
         "estimated_score_impact": 3.0, "effort": "low",
         "regulation": "ECOA / Reg B", "category": "monitoring",
         "details": "Connect FairLens drift monitor to your model pipeline. This is a config-only change that adds +3 to your score."},
        {"action": "Enable per-applicant decision logging",
         "estimated_score_impact": 2.0, "effort": "low",
         "regulation": "ECOA / Reg B", "category": "logging",
         "details": "Turn on adverse action reason logging in your model wrapper. Required by ECOA and adds +2 to your score."},
        {"action": "Address outstanding WARNING findings",
         "estimated_score_impact": 3.0, "effort": "medium",
         "regulation": "SR 11-7 / OCC 2011-12", "category": "remediation",
         "details": "Each WARNING finding deducts 3 points. Resolving the top findings is often straightforward documentation work."},
        {"action": "Schedule overdue model revalidation",
         "estimated_score_impact": 8.0, "effort": "high",
         "regulation": "SR 11-7 / OCC 2011-12", "category": "validation",
         "details": "Overdue model validation is a CRITICAL finding under SR 11-7. Scheduling and completing revalidation removes the critical deduction."},
        {"action": "Run PII detection on your data sources",
         "estimated_score_impact": 2.0, "effort": "low",
         "regulation": "SR 11-7 / OCC 2011-12", "category": "governance",
         "details": "Run PIIDetector on your training data columns. Classifies sensitive fields and adds governance documentation."},
    ]


def _demo_risk_heatmap():
    regulations = ["ECOA / Reg B", "SR 11-7 / OCC 2011-12", "EU AI Act", "Colorado AI Act", "NYC Local Law 144"]
    models = ["credit_score_v2", "fraud_detect_v1", "pricing_v3", "marketing_v1"]
    model_names = {
        "credit_score_v2": "Consumer Credit Score",
        "fraud_detect_v1": "Fraud Detection",
        "pricing_v3": "Loan Pricing Model",
        "marketing_v1": "Marketing Propensity",
    }
    cells = {
        "credit_score_v2": {
            "ECOA / Reg B": {"risk_level": "high", "score": 72.0, "critical_count": 1, "warning_count": 2},
            "SR 11-7 / OCC 2011-12": {"risk_level": "low", "score": 94.0, "critical_count": 0, "warning_count": 0},
            "EU AI Act": {"risk_level": "medium", "score": 85.0, "critical_count": 0, "warning_count": 1},
            "Colorado AI Act": {"risk_level": "low", "score": 97.0, "critical_count": 0, "warning_count": 0},
            "NYC Local Law 144": {"risk_level": "low", "score": 96.0, "critical_count": 0, "warning_count": 0},
        },
        "fraud_detect_v1": {
            "ECOA / Reg B": {"risk_level": "low", "score": 96.0, "critical_count": 0, "warning_count": 0},
            "SR 11-7 / OCC 2011-12": {"risk_level": "low", "score": 94.0, "critical_count": 0, "warning_count": 0},
            "EU AI Act": {"risk_level": "low", "score": 92.0, "critical_count": 0, "warning_count": 0},
            "Colorado AI Act": {"risk_level": "low", "score": 97.0, "critical_count": 0, "warning_count": 0},
            "NYC Local Law 144": {"risk_level": "low", "score": 97.0, "critical_count": 0, "warning_count": 0},
        },
        "pricing_v3": {
            "ECOA / Reg B": {"risk_level": "critical", "score": 60.0, "critical_count": 2, "warning_count": 1},
            "SR 11-7 / OCC 2011-12": {"risk_level": "high", "score": 75.0, "critical_count": 1, "warning_count": 1},
            "EU AI Act": {"risk_level": "medium", "score": 82.0, "critical_count": 0, "warning_count": 2},
            "Colorado AI Act": {"risk_level": "medium", "score": 85.0, "critical_count": 0, "warning_count": 1},
            "NYC Local Law 144": {"risk_level": "low", "score": 91.0, "critical_count": 0, "warning_count": 0},
        },
        "marketing_v1": {
            "ECOA / Reg B": {"risk_level": "low", "score": 100.0, "critical_count": 0, "warning_count": 0},
            "SR 11-7 / OCC 2011-12": {"risk_level": "low", "score": 100.0, "critical_count": 0, "warning_count": 0},
            "EU AI Act": {"risk_level": "low", "score": 100.0, "critical_count": 0, "warning_count": 0},
            "Colorado AI Act": {"risk_level": "low", "score": 100.0, "critical_count": 0, "warning_count": 0},
            "NYC Local Law 144": {"risk_level": "low", "score": 100.0, "critical_count": 0, "warning_count": 0},
        },
    }
    return {
        "models": models,
        "model_names": model_names,
        "regulations": regulations,
        "cells": cells,
        "summary": {"total_cells": 20, "critical_cells": 1, "high_cells": 2},
    }


def _demo_remediation_queue():
    now = datetime.now(timezone.utc)
    return [
        {"item_id": "rem-001", "regulation": "ECOA / Reg B",
         "finding_description": "Disparate impact detected: selection rate ratio 0.78 for race:Black group in Consumer Credit Score model. Below 0.80 four-fifths threshold.",
         "remediation_action": "Implement bias mitigation techniques (e.g., adversarial debiasing, reweighting) and re-run fairness analysis. Document remediation steps.",
         "priority": "urgent", "priority_score": 9.0, "severity": "CRITICAL",
         "deadline": (now + timedelta(days=30)).isoformat(),
         "business_impact": "Fair lending violation risk. Potential CFPB enforcement action and restitution orders.",
         "affected_models": ["credit_score_v2"]},
        {"item_id": "rem-002", "regulation": "SR 11-7 / OCC 2011-12",
         "finding_description": "Loan Pricing Model validation overdue by 2 months. SR 11-7 requires annual independent validation for Tier 1 models.",
         "remediation_action": "Schedule independent validation with MRM team. Engage third-party validator if internal resources unavailable.",
         "priority": "urgent", "priority_score": 7.2, "severity": "CRITICAL",
         "deadline": (now + timedelta(days=15)).isoformat(),
         "business_impact": "Model risk management deficiency. May trigger MRA/MRIA from OCC/Fed examiners.",
         "affected_models": ["pricing_v3"]},
        {"item_id": "rem-003", "regulation": "ECOA / Reg B",
         "finding_description": "Adverse action reason codes not validated with SHAP fidelity above 0.85 threshold for Consumer Credit Score model.",
         "remediation_action": "Re-calibrate SHAP explanation pipeline and validate reason code ordering against model feature importance.",
         "priority": "high", "priority_score": 4.5, "severity": "WARNING",
         "deadline": (now + timedelta(days=30)).isoformat(),
         "business_impact": "Compliance gap requiring remediation before next examination.",
         "affected_models": ["credit_score_v2"]},
        {"item_id": "rem-004", "regulation": "EU AI Act",
         "finding_description": "Technical documentation incomplete for high-risk AI system classification under EU AI Act Article 11.",
         "remediation_action": "Complete technical documentation template including data governance procedures and human oversight mechanisms.",
         "priority": "medium", "priority_score": 2.4, "severity": "WARNING",
         "deadline": (now + timedelta(days=90)).isoformat(),
         "business_impact": "Compliance gap requiring remediation before next examination.",
         "affected_models": ["credit_score_v2", "pricing_v3"]},
        {"item_id": "rem-005", "regulation": "SR 11-7 / OCC 2011-12",
         "finding_description": "Model performance monitoring frequency below required quarterly cadence for Tier 1 models.",
         "remediation_action": "Configure automated monthly performance monitoring jobs and alert thresholds.",
         "priority": "medium", "priority_score": 1.8, "severity": "WARNING",
         "deadline": (now + timedelta(days=60)).isoformat(),
         "business_impact": "Compliance gap requiring remediation before next examination.",
         "affected_models": ["pricing_v3"]},
    ]


def _demo_peer_comparison():
    return {
        "overall_score": 82.5,
        "overall_percentile": 72,
        "overall_grade": "B",
        "institution_tier": "mid",
        "per_regulation": {
            "ECOA / Reg B": {"score": 79.0, "percentile": 68, "median": 67.0, "p25": 52.0, "p75": 79.0},
            "SR 11-7 / OCC 2011-12": {"score": 96.1, "percentile": 90, "median": 71.0, "p25": 58.0, "p75": 83.0},
            "EU AI Act": {"score": 96.4, "percentile": 93, "median": 60.0, "p25": 45.0, "p75": 75.0},
            "Colorado AI Act": {"score": 100.0, "percentile": 99, "median": 65.0, "p25": 50.0, "p75": 78.0},
            "NYC Local Law 144": {"score": 100.0, "percentile": 99, "median": 68.0, "p25": 55.0, "p75": 80.0},
        },
        "sample_note": "Benchmarks based on anonymized aggregate data from ProveIt-monitored financial institutions, updated quarterly.",
    }


@app.route("/api/action-items")
@require_client_auth
def api_action_items():
    """Prioritized remediation action items -- what the CRO should do next."""
    store = _get_store()

    if store is None:
        alerts = [a for a in _demo_alerts() if not a.get("resolved")]
        models = _demo_models()
        fairness = _demo_fairness()
    else:
        alerts = store.get_alerts(TENANT_ID, unresolved_only=True)
        models = store.get_models(TENANT_ID)
        fairness_list = []
        for m in models:
            f = store.get_latest_fairness(TENANT_ID, m["model_id"])
            if f:
                fairness_list.append(f)
        fairness = fairness_list

    items = []

    for a in alerts:
        items.append({
            "priority": 1 if a["severity"] == "critical" else 2,
            "type": "alert",
            "title": a["title"],
            "description": a.get("description", ""),
            "source": a.get("source", ""),
            "model_id": a.get("model_id"),
            "regulation": a.get("regulation"),
            "severity": a["severity"],
            "alert_id": a.get("id"),
        })

    for m in models:
        if m.get("validation_overdue"):
            items.append({
                "priority": 1 if m.get("tier") == 1 else 2,
                "type": "validation",
                "title": f"Schedule validation for {m['name']}",
                "description": f"Tier {m.get('tier', '?')} model validation overdue per SR 11-7.",
                "source": "ModelRegistry",
                "model_id": m["model_id"],
                "regulation": "SR 11-7 / OCC 2011-12",
                "severity": "critical" if m.get("tier") == 1 else "warning",
            })

    for f in fairness:
        if f.get("has_disparate_impact") and f.get("statistically_significant"):
            items.append({
                "priority": 1,
                "type": "fairness",
                "title": f"Remediate disparate impact in {f['model_id']}",
                "description": f"Selection rate ratio {f.get('worst_ratio', 0):.2f} for {f.get('worst_group', '?')} (p={f.get('p_value', 0):.3f}).",
                "source": "FairLens",
                "model_id": f["model_id"],
                "regulation": "ECOA / Reg B",
                "severity": "critical",
            })

    sev_order = {"critical": 0, "warning": 1, "info": 2}
    items.sort(key=lambda x: (x["priority"], sev_order.get(x["severity"], 3)))

    return jsonify(items)


@app.route("/api/dag/<int:pipeline_id>")
@require_client_auth
def api_dag(pipeline_id):
    """Get DAG node/edge data for a specific pipeline run."""
    store = _get_store()

    if store is None:
        return jsonify(_demo_dag(pipeline_id))

    try:
        nodes_sql = """SELECT node_id, node_type, operation, table_name, column_name,
                              pair_id, is_protected, metadata
                       FROM dag_nodes WHERE pipeline_id = %s ORDER BY node_id"""
        edges_sql = """SELECT parent_node_id, child_node_id, input_position
                       FROM dag_edges de
                       JOIN dag_nodes dn ON de.child_node_id = dn.node_id
                       WHERE dn.pipeline_id = %s"""
        nodes_raw = store._read_dicts(nodes_sql, (pipeline_id,))
        edges_raw = store._read_dicts(edges_sql, (pipeline_id,))

        if not nodes_raw:
            return jsonify(_demo_dag(pipeline_id))

        nodes = {}
        for n in nodes_raw:
            nodes[str(n["node_id"])] = {
                "node_type": n["node_type"],
                "operation": n["operation"] or n.get("column_name", ""),
                "table": n.get("table_name"),
                "column": n.get("column_name"),
                "is_protected": n.get("is_protected", False),
            }

        edges = [{"source": e["parent_node_id"], "target": e["child_node_id"],
                  "input_index": e.get("input_position", 0)} for e in edges_raw]

        max_id = max(int(k) for k in nodes.keys()) if nodes else 0

        return jsonify({"nodes": nodes, "edges": edges, "root_id": max_id, "depth": 4})
    except Exception as e:
        logger.error("DAG query failed for pipeline %s: %s", pipeline_id, e)
        return jsonify(_demo_dag(pipeline_id))


def _demo_dag(pipeline_id):
    """Generate a realistic demo DAG for visualization."""
    return {
        "root_id": 11,
        "depth": 4,
        "nodes": {
            "0": {"node_type": "SOURCE", "operation": "applications.income", "is_protected": False, "table": "applications", "column": "income"},
            "1": {"node_type": "SOURCE", "operation": "applications.debt", "is_protected": False, "table": "applications", "column": "debt"},
            "2": {"node_type": "SOURCE", "operation": "applications.emp_length", "is_protected": False, "table": "applications", "column": "emp_length"},
            "3": {"node_type": "SOURCE", "operation": "bureau.score", "is_protected": False, "table": "bureau", "column": "score"},
            "4": {"node_type": "SOURCE", "operation": "applications.race", "is_protected": True, "table": "applications", "column": "race"},
            "5": {"node_type": "SOURCE", "operation": "applications.age", "is_protected": True, "table": "applications", "column": "age"},
            "6": {"node_type": "BINARY", "operation": "divide", "is_protected": False},
            "7": {"node_type": "UNARY", "operation": "log_transform", "is_protected": False},
            "8": {"node_type": "BINARY", "operation": "multiply", "is_protected": False},
            "9": {"node_type": "AGGREGATE", "operation": "weighted_sum", "is_protected": False},
            "10": {"node_type": "UNARY", "operation": "sigmoid", "is_protected": False},
            "11": {"node_type": "CUSTOM", "operation": "credit_decision", "is_protected": False},
        },
        "edges": [
            {"source": 0, "target": 6, "input_index": 0},
            {"source": 1, "target": 6, "input_index": 1},
            {"source": 2, "target": 7, "input_index": 0},
            {"source": 3, "target": 8, "input_index": 0},
            {"source": 7, "target": 8, "input_index": 1},
            {"source": 6, "target": 9, "input_index": 0},
            {"source": 8, "target": 9, "input_index": 1},
            {"source": 4, "target": 9, "input_index": 2},
            {"source": 5, "target": 9, "input_index": 3},
            {"source": 9, "target": 10, "input_index": 0},
            {"source": 10, "target": 11, "input_index": 0},
        ],
    }


# ---------------------------------------------------------------------------
# User Data Upload Endpoints (stored in Aurora client_user_data table)
# ---------------------------------------------------------------------------

@app.route("/api/all-validations")
@require_client_auth
def api_all_validations():
    """All model validation records for this tenant."""
    return jsonify(_get_user_records("model_validation"))


@app.route("/api/models/<model_id>/validations", methods=["POST"])
@require_client_auth
def api_record_validation(model_id):
    """Record a model validation event."""
    if not request.is_json:
        return jsonify({"error": "JSON body required"}), 400
    data = request.json
    payload = {
        "validated_at": data.get("validated_at"),
        "validated_by": data.get("validated_by", ""),
        "validation_type": data.get("validation_type", "annual"),
        "next_due": data.get("next_due", ""),
        "validator_type": data.get("validator_type", "internal"),
        "notes": data.get("notes", ""),
    }
    if not payload["validated_at"] or not payload["validated_by"]:
        return jsonify({"error": "validated_at and validated_by are required"}), 400
    record_id = _save_user_record("model_validation", model_id, payload)
    if record_id is None:
        return jsonify({"error": "Failed to save — check Aurora connection"}), 500
    return jsonify({"ok": True, "id": record_id})


@app.route("/api/all-model-notes")
@require_client_auth
def api_all_model_notes():
    """All model notes for this tenant."""
    return jsonify(_get_user_records("model_note"))


@app.route("/api/models/<model_id>/notes", methods=["POST"])
@require_client_auth
def api_add_model_note(model_id):
    """Add a documentation note to a model."""
    if not request.is_json:
        return jsonify({"error": "JSON body required"}), 400
    data = request.json
    payload = {
        "author": data.get("author", "Dashboard User"),
        "content": data.get("content", ""),
        "category": data.get("category", "general"),
    }
    if not payload["content"]:
        return jsonify({"error": "content is required"}), 400
    record_id = _save_user_record("model_note", model_id, payload)
    if record_id is None:
        return jsonify({"error": "Failed to save — check Aurora connection"}), 500
    return jsonify({"ok": True, "id": record_id})


@app.route("/api/events")
@require_client_auth
def api_events_list():
    """List custom events/deadlines for this tenant."""
    return jsonify(_get_user_records("custom_event"))


@app.route("/api/events", methods=["POST"])
@require_client_auth
def api_add_event():
    """Add a custom event or deadline."""
    if not request.is_json:
        return jsonify({"error": "JSON body required"}), 400
    data = request.json
    payload = {
        "title": data.get("title", ""),
        "event_date": data.get("event_date", ""),
        "event_type": data.get("event_type", "deadline"),
        "description": data.get("description", ""),
    }
    if not payload["title"] or not payload["event_date"]:
        return jsonify({"error": "title and event_date are required"}), 400
    record_id = _save_user_record("custom_event", None, payload)
    if record_id is None:
        return jsonify({"error": "Failed to save — check Aurora connection"}), 500
    return jsonify({"ok": True, "id": record_id})


@app.route("/api/events/<int:event_id>", methods=["DELETE"])
@require_client_auth
def api_delete_event(event_id):
    """Delete a custom event."""
    return jsonify({"ok": _delete_user_record(event_id)})


@app.route("/api/remediation-updates")
@require_client_auth
def api_remediation_updates():
    """All remediation status updates for this tenant."""
    return jsonify(_get_user_records("remediation_update"))


@app.route("/api/remediation/<item_id>/update", methods=["POST"])
@require_client_auth
def api_update_remediation(item_id):
    """Record a remediation status update."""
    if not request.is_json:
        return jsonify({"error": "JSON body required"}), 400
    data = request.json
    payload = {
        "status": data.get("status", "in_progress"),
        "assigned_to": data.get("assigned_to", ""),
        "target_date": data.get("target_date", ""),
        "notes": data.get("notes", ""),
    }
    record_id = _save_user_record("remediation_update", item_id, payload)
    if record_id is None:
        return jsonify({"error": "Failed to save — check Aurora connection"}), 500
    return jsonify({"ok": True, "id": record_id})


@app.route("/api/user-data/<int:record_id>", methods=["DELETE"])
@require_client_auth
def api_delete_user_data(record_id):
    """Delete any user-entered record."""
    return jsonify({"ok": _delete_user_record(record_id)})


# ---------------------------------------------------------------------------
# Production error handlers — prevent stack trace leakage
# ---------------------------------------------------------------------------

@app.errorhandler(Exception)
def handle_exception(e):
    """Catch-all error handler to prevent stack trace leakage in production."""
    logger.exception("Unhandled exception: %s", e)
    accept = request.headers.get("Accept", "")
    if "application/json" in accept:
        return jsonify({"error": "Internal server error"}), 500
    return "Internal server error", 500


@app.errorhandler(404)
def handle_404(e):
    accept = request.headers.get("Accept", "")
    if "application/json" in accept:
        return jsonify({"error": "Not found"}), 404
    return "Not found", 404


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    import argparse
    parser = argparse.ArgumentParser(description="ProveIt Client Dashboard")
    parser.add_argument("--port", default=5003, type=int)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    from proveit import __version__

    mode_label = {
        "demo": "Demo (synthetic data, no database)",
        "sqlite": f"SQLite ({DASH_DB_PATH or './proveit_dashboard.db'})",
    }.get(DASH_MODE, f"Aurora PostgreSQL")
    if DASH_MODE not in ("demo", "sqlite") and DASH_DB_PATH:
        mode_label = f"SQLite ({DASH_DB_PATH})"

    url = f"http://{args.host}:{args.port}"

    print()
    print("  ProveIt Client Dashboard v" + __version__)
    print("  " + "=" * 44)
    print(f"  Tenant:     {TENANT_ID}")
    print(f"  Mode:       {mode_label}")
    print(f"  Dashboard:  {url}")
    print()

    app.run(debug=args.debug, port=args.port, host=args.host)


if __name__ == "__main__":
    main()
