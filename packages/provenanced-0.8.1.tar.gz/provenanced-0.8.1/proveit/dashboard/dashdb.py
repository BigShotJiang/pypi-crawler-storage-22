"""
Aurora PostgreSQL read-optimized data store for ProveIt dashboards.

Designed for heavy dashboard reads with:
- Separate reader/writer connection pools (Aurora read replicas)
- Denormalized snapshot tables refreshed periodically
- Tenant isolation for multi-client deployments
- Connection pooling via psycopg2 ThreadedConnectionPool

Schema is optimized for the two dashboard use cases:
1. Client dashboard: bank CRO sees their own compliance posture
2. Admin dashboard: founder monitors all tenants

Usage::

    store = DashboardStore(
        writer_dsn="postgresql://writer.cluster.rds.amazonaws.com/proveit",
        reader_dsn="postgresql://reader.cluster-ro.rds.amazonaws.com/proveit",
    )
    store.connect()
    store.ensure_schema()

    # Write path (goes to Aurora primary)
    store.upsert_tenant_snapshot(tenant_id, snapshot_data)

    # Read path (goes to Aurora read replica)
    data = store.get_tenant_overview(tenant_id)
"""

import json
import logging
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional

import numpy as np

logger = logging.getLogger(__name__)


class _NumpyEncoder(json.JSONEncoder):
    """JSON encoder that handles numpy types."""

    def default(self, obj):
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, (np.bool_,)):
            return bool(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        return super().default(obj)


def _json_dumps(obj) -> str:
    """Serialize to JSON with numpy support."""
    return json.dumps(obj, cls=_NumpyEncoder)

# ---------------------------------------------------------------------------
# Schema DDL — executed once via ensure_schema()
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
-- Tenants (bank clients)
CREATE TABLE IF NOT EXISTS tenants (
    tenant_id       TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    tier            TEXT NOT NULL DEFAULT 'professional',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    active          BOOLEAN NOT NULL DEFAULT TRUE,
    config          JSONB DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_tenants_active ON tenants (active);

-- Compliance score snapshots (denormalized for fast reads)
CREATE TABLE IF NOT EXISTS compliance_snapshots (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    score           REAL NOT NULL,
    grade           TEXT NOT NULL,
    engines_evaluated INTEGER NOT NULL DEFAULT 0,
    critical_findings INTEGER NOT NULL DEFAULT 0,
    warning_findings  INTEGER NOT NULL DEFAULT 0,
    total_findings  INTEGER NOT NULL DEFAULT 0,
    top_risks       JSONB DEFAULT '[]',
    breakdowns      JSONB DEFAULT '[]',
    bonuses         JSONB DEFAULT '{}',
    trend           TEXT,
    snapshot_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_comp_snap_tenant
    ON compliance_snapshots (tenant_id, snapshot_at DESC);

-- Model inventory snapshots (denormalized)
CREATE TABLE IF NOT EXISTS model_snapshots (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    model_id        TEXT NOT NULL,
    name            TEXT NOT NULL,
    version         TEXT,
    tier            INTEGER NOT NULL DEFAULT 3,
    status          TEXT NOT NULL DEFAULT 'development',
    domain          TEXT,
    owner           TEXT,
    compliance_score REAL,
    last_validated  TIMESTAMPTZ,
    last_monitored  TIMESTAMPTZ,
    validation_overdue BOOLEAN DEFAULT FALSE,
    monitoring_overdue BOOLEAN DEFAULT FALSE,
    finding_count   INTEGER DEFAULT 0,
    snapshot_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_model_snap_tenant
    ON model_snapshots (tenant_id, snapshot_at DESC);
CREATE INDEX IF NOT EXISTS idx_model_snap_status
    ON model_snapshots (tenant_id, status);

-- Fairness analysis results (per model, per run)
CREATE TABLE IF NOT EXISTS fairness_snapshots (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    model_id        TEXT NOT NULL,
    has_disparate_impact BOOLEAN DEFAULT FALSE,
    worst_ratio     REAL,
    worst_group     TEXT,
    p_value         REAL,
    statistically_significant BOOLEAN DEFAULT FALSE,
    protected_attributes JSONB DEFAULT '[]',
    sample_size_warnings JSONB DEFAULT '[]',
    details         JSONB DEFAULT '{}',
    snapshot_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_fair_snap_tenant
    ON fairness_snapshots (tenant_id, snapshot_at DESC);

-- Certification status
CREATE TABLE IF NOT EXISTS certification_snapshots (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    cert_type       TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'not_started',
    issued_date     DATE,
    expiry_date     DATE,
    days_until_expiry INTEGER,
    snapshot_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_cert_snap_tenant
    ON certification_snapshots (tenant_id, snapshot_at DESC);

-- Alert / finding log
CREATE TABLE IF NOT EXISTS alert_log (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    severity        TEXT NOT NULL,
    source          TEXT NOT NULL,
    title           TEXT NOT NULL,
    description     TEXT,
    model_id        TEXT,
    regulation      TEXT,
    resolved        BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at     TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_alert_tenant
    ON alert_log (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_alert_unresolved
    ON alert_log (tenant_id, resolved, severity);

-- Pipeline execution stats (for admin dashboard)
CREATE TABLE IF NOT EXISTS pipeline_stats (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    pipeline_name   TEXT,
    status          TEXT NOT NULL,
    node_count      INTEGER DEFAULT 0,
    edge_count      INTEGER DEFAULT 0,
    duration_ms     INTEGER,
    started_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at    TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_pipeline_tenant
    ON pipeline_stats (tenant_id, started_at DESC);

-- System metrics (for admin dashboard)
CREATE TABLE IF NOT EXISTS system_metrics (
    id              BIGSERIAL PRIMARY KEY,
    metric_name     TEXT NOT NULL,
    metric_value    REAL NOT NULL,
    labels          JSONB DEFAULT '{}',
    recorded_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sys_metrics
    ON system_metrics (metric_name, recorded_at DESC);

CREATE TABLE IF NOT EXISTS dashboard_users (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL,
    email           TEXT NOT NULL,
    password_hash   TEXT,
    display_name    TEXT NOT NULL DEFAULT '',
    role            TEXT NOT NULL DEFAULT 'analyst',
    active          BOOLEAN NOT NULL DEFAULT TRUE,
    invited_by      TEXT,
    last_login_at   TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, email)
);

CREATE INDEX IF NOT EXISTS idx_users_tenant
    ON dashboard_users (tenant_id, active);
CREATE INDEX IF NOT EXISTS idx_users_email
    ON dashboard_users (email);
"""


class DashboardStore:
    """Aurora PostgreSQL read-optimized store for dashboards.

    Supports separate writer and reader connection strings for
    Aurora read replicas.  Falls back to writer DSN for reads
    if no reader DSN is provided (single-instance mode).
    """

    def __init__(
        self,
        writer_dsn: str,
        reader_dsn: Optional[str] = None,
        min_conn: int = 2,
        max_conn: int = 10,
    ):
        self.writer_dsn = writer_dsn
        self.reader_dsn = reader_dsn or writer_dsn
        self.min_conn = min_conn
        self.max_conn = max_conn
        self._writer_pool = None
        self._reader_pool = None

    def connect(self) -> None:
        """Create connection pools for writer and reader endpoints."""
        from psycopg2 import pool as pg_pool
        from psycopg2.extras import register_default_jsonb

        register_default_jsonb()

        self._writer_pool = pg_pool.ThreadedConnectionPool(
            self.min_conn, self.max_conn, self.writer_dsn,
        )
        if self.reader_dsn != self.writer_dsn:
            self._reader_pool = pg_pool.ThreadedConnectionPool(
                self.min_conn, self.max_conn, self.reader_dsn,
            )
        else:
            self._reader_pool = self._writer_pool

        logger.info("DashboardStore connected (writer + reader pools)")

    def disconnect(self) -> None:
        """Close all connection pools."""
        if self._writer_pool is not None:
            self._writer_pool.closeall()
        if self._reader_pool is not None and self._reader_pool is not self._writer_pool:
            self._reader_pool.closeall()
        self._writer_pool = None
        self._reader_pool = None

    def ensure_schema(self) -> None:
        """Create tables if they don't exist (idempotent)."""
        conn = self._writer_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(_SCHEMA_SQL)
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_pool.putconn(conn)

    # -- Writer methods (Aurora primary) ------------------------------------

    @staticmethod
    def _adapt_params(params: tuple) -> tuple:
        """Convert numpy types and dicts to native Python for psycopg2."""
        adapted = []
        for p in params:
            if isinstance(p, (np.integer,)):
                adapted.append(int(p))
            elif isinstance(p, (np.floating,)):
                adapted.append(float(p))
            elif isinstance(p, (np.bool_,)):
                adapted.append(bool(p))
            elif isinstance(p, (dict, list)):
                adapted.append(_json_dumps(p))
            elif isinstance(p, np.ndarray):
                adapted.append(_json_dumps(p.tolist()))
            else:
                adapted.append(p)
        return tuple(adapted)

    def _write(self, sql: str, params: tuple = ()) -> None:
        params = self._adapt_params(params)
        conn = self._writer_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_pool.putconn(conn)

    def _write_returning(self, sql: str, params: tuple = ()) -> Any:
        conn = self._writer_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                result = cur.fetchone()
            conn.commit()
            return result
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_pool.putconn(conn)

    # -- Reader methods (Aurora read replica) --------------------------------

    def _read_one(self, sql: str, params: tuple = ()) -> Optional[tuple]:
        conn = self._reader_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return cur.fetchone()
        finally:
            self._reader_pool.putconn(conn)

    def _read_all(self, sql: str, params: tuple = ()) -> List[tuple]:
        conn = self._reader_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return cur.fetchall()
        finally:
            self._reader_pool.putconn(conn)

    def _read_dicts(self, sql: str, params: tuple = ()) -> List[Dict[str, Any]]:
        conn = self._reader_pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                cols = [desc[0] for desc in cur.description]
                return [dict(zip(cols, row)) for row in cur.fetchall()]
        finally:
            self._reader_pool.putconn(conn)

    # -- Tenant management ---------------------------------------------------

    def upsert_tenant(self, tenant_id: str, name: str, tier: str = "professional",
                      config: Optional[Dict[str, Any]] = None) -> None:
        cfg = _json_dumps(config or {})
        self._write(
            """INSERT INTO tenants (tenant_id, name, tier, config)
               VALUES (%s, %s, %s, %s)
               ON CONFLICT (tenant_id) DO UPDATE
               SET name = EXCLUDED.name, tier = EXCLUDED.tier,
                   config = EXCLUDED.config""",
            (tenant_id, name, tier, cfg),
        )

    def get_tenant(self, tenant_id: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            "SELECT * FROM tenants WHERE tenant_id = %s AND active = TRUE",
            (tenant_id,),
        )
        return rows[0] if rows else None

    def get_tenant_config(self, tenant_id: str) -> Dict[str, Any]:
        rows = self._read_dicts(
            "SELECT config FROM tenants WHERE tenant_id = %s AND active = TRUE",
            (tenant_id,),
        )
        if not rows:
            return {}
        raw = rows[0].get("config", {})
        if isinstance(raw, str):
            return json.loads(raw)
        return raw or {}

    def get_all_tenants(self) -> List[Dict[str, Any]]:
        return self._read_dicts(
            "SELECT * FROM tenants WHERE active = TRUE ORDER BY name"
        )

    # -- Compliance snapshots ------------------------------------------------

    def insert_compliance_snapshot(self, tenant_id: str, data: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO compliance_snapshots
               (tenant_id, score, grade, engines_evaluated, critical_findings,
                warning_findings, total_findings, top_risks, breakdowns, bonuses, trend)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (
                tenant_id,
                data["score"], data["grade"], data.get("engines_evaluated", 0),
                data.get("critical_findings", 0), data.get("warning_findings", 0),
                data.get("total_findings", 0),
                _json_dumps(data.get("top_risks", [])),
                _json_dumps(data.get("breakdowns", [])),
                _json_dumps(data.get("bonuses_applied", {})),
                data.get("trend"),
            ),
        )

    def get_latest_compliance(self, tenant_id: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            """SELECT * FROM compliance_snapshots
               WHERE tenant_id = %s ORDER BY snapshot_at DESC LIMIT 1""",
            (tenant_id,),
        )
        return rows[0] if rows else None

    def get_compliance_history(self, tenant_id: str, limit: int = 30) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT score, grade, total_findings, critical_findings,
                      snapshot_at
               FROM compliance_snapshots
               WHERE tenant_id = %s ORDER BY snapshot_at DESC LIMIT %s""",
            (tenant_id, limit),
        )

    # -- Model snapshots -----------------------------------------------------

    def upsert_model_snapshot(self, tenant_id: str, model: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO model_snapshots
               (tenant_id, model_id, name, version, tier, status, domain, owner,
                compliance_score, last_validated, last_monitored,
                validation_overdue, monitoring_overdue, finding_count)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (
                tenant_id, model["model_id"], model["name"],
                model.get("version"), model.get("tier", 3),
                model.get("status", "development"), model.get("domain"),
                model.get("owner"), model.get("compliance_score"),
                model.get("last_validated"), model.get("last_monitored"),
                model.get("validation_overdue", False),
                model.get("monitoring_overdue", False),
                model.get("finding_count", 0),
            ),
        )

    def get_models(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT DISTINCT ON (model_id)
                      model_id, name, version, tier, status, domain, owner,
                      compliance_score, last_validated, last_monitored,
                      validation_overdue, monitoring_overdue, finding_count,
                      snapshot_at
               FROM model_snapshots
               WHERE tenant_id = %s
               ORDER BY model_id, snapshot_at DESC""",
            (tenant_id,),
        )

    # -- Fairness snapshots --------------------------------------------------

    def insert_fairness_snapshot(self, tenant_id: str, data: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO fairness_snapshots
               (tenant_id, model_id, has_disparate_impact, worst_ratio,
                worst_group, p_value, statistically_significant,
                protected_attributes, sample_size_warnings, details)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (
                tenant_id, data["model_id"],
                data.get("has_disparate_impact", False),
                data.get("worst_ratio"), data.get("worst_group"),
                data.get("p_value"), data.get("statistically_significant", False),
                _json_dumps(data.get("protected_attributes", [])),
                _json_dumps(data.get("sample_size_warnings", [])),
                _json_dumps(data.get("details", {})),
            ),
        )

    def get_latest_fairness(self, tenant_id: str, model_id: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            """SELECT * FROM fairness_snapshots
               WHERE tenant_id = %s AND model_id = %s
               ORDER BY snapshot_at DESC LIMIT 1""",
            (tenant_id, model_id),
        )
        return rows[0] if rows else None

    def get_all_fairness(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT DISTINCT ON (model_id) *
               FROM fairness_snapshots
               WHERE tenant_id = %s
               ORDER BY model_id, snapshot_at DESC""",
            (tenant_id,),
        )

    # -- Certifications ------------------------------------------------------

    def upsert_certification(self, tenant_id: str, cert: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO certification_snapshots
               (tenant_id, cert_type, status, issued_date, expiry_date, days_until_expiry)
               VALUES (%s,%s,%s,%s,%s,%s)""",
            (
                tenant_id, cert["cert_type"], cert.get("status", "not_started"),
                cert.get("issued_date"), cert.get("expiry_date"),
                cert.get("days_until_expiry"),
            ),
        )

    def get_certifications(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT DISTINCT ON (cert_type)
                      cert_type, status, issued_date, expiry_date,
                      days_until_expiry, snapshot_at
               FROM certification_snapshots
               WHERE tenant_id = %s
               ORDER BY cert_type, snapshot_at DESC""",
            (tenant_id,),
        )

    # -- Alert log -----------------------------------------------------------

    def insert_alert(self, tenant_id: str, alert: Dict[str, Any]) -> int:
        row = self._write_returning(
            """INSERT INTO alert_log
               (tenant_id, severity, source, title, description, model_id, regulation)
               VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING id""",
            (
                tenant_id, alert["severity"], alert["source"],
                alert["title"], alert.get("description"),
                alert.get("model_id"), alert.get("regulation"),
            ),
        )
        return row[0] if row else 0

    def get_alerts(self, tenant_id: str, unresolved_only: bool = True,
                   limit: int = 50) -> List[Dict[str, Any]]:
        if unresolved_only:
            return self._read_dicts(
                """SELECT * FROM alert_log
                   WHERE tenant_id = %s AND resolved = FALSE
                   ORDER BY CASE severity
                       WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2
                   END, created_at DESC LIMIT %s""",
                (tenant_id, limit),
            )
        return self._read_dicts(
            """SELECT * FROM alert_log WHERE tenant_id = %s
               ORDER BY created_at DESC LIMIT %s""",
            (tenant_id, limit),
        )

    def resolve_alert(self, alert_id: int) -> None:
        self._write(
            "UPDATE alert_log SET resolved = TRUE, resolved_at = NOW() WHERE id = %s",
            (alert_id,),
        )

    # -- Pipeline stats (admin) ----------------------------------------------

    def insert_pipeline_stat(self, tenant_id: str, stat: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO pipeline_stats
               (tenant_id, pipeline_name, status, node_count, edge_count,
                duration_ms, completed_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s)""",
            (
                tenant_id, stat.get("pipeline_name"), stat["status"],
                stat.get("node_count", 0), stat.get("edge_count", 0),
                stat.get("duration_ms"), stat.get("completed_at"),
            ),
        )

    def get_pipeline_stats(self, tenant_id: Optional[str] = None,
                           limit: int = 100) -> List[Dict[str, Any]]:
        if tenant_id:
            return self._read_dicts(
                """SELECT id AS pipeline_id, tenant_id, pipeline_name, status,
                          node_count, edge_count, duration_ms, started_at, completed_at
                   FROM pipeline_stats WHERE tenant_id = %s
                   ORDER BY started_at DESC LIMIT %s""",
                (tenant_id, limit),
            )
        return self._read_dicts(
            """SELECT id AS pipeline_id, tenant_id, pipeline_name, status,
                      node_count, edge_count, duration_ms, started_at, completed_at
               FROM pipeline_stats ORDER BY started_at DESC LIMIT %s""",
            (limit,),
        )

    # -- System metrics (admin) ----------------------------------------------

    def record_metric(self, name: str, value: float,
                      labels: Optional[Dict[str, str]] = None) -> None:
        self._write(
            """INSERT INTO system_metrics (metric_name, metric_value, labels)
               VALUES (%s, %s, %s)""",
            (name, value, _json_dumps(labels or {})),
        )

    def get_latest_metrics(self) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT DISTINCT ON (metric_name)
                      metric_name, metric_value, labels, recorded_at
               FROM system_metrics ORDER BY metric_name, recorded_at DESC"""
        )

    # -- Admin aggregates (read-heavy, hits read replica) --------------------

    def admin_tenant_summary(self) -> List[Dict[str, Any]]:
        """Aggregate summary for admin dashboard — one row per tenant."""
        return self._read_dicts("""
            SELECT
                t.tenant_id, t.name, t.tier, t.created_at,
                cs.score AS latest_score, cs.grade AS latest_grade,
                cs.critical_findings, cs.warning_findings,
                cs.trend,
                (SELECT COUNT(*) FROM model_snapshots ms
                 WHERE ms.tenant_id = t.tenant_id
                   AND ms.snapshot_at = (SELECT MAX(snapshot_at) FROM model_snapshots
                                         WHERE tenant_id = t.tenant_id)
                ) AS model_count,
                (SELECT COUNT(*) FROM alert_log a
                 WHERE a.tenant_id = t.tenant_id AND a.resolved = FALSE
                ) AS open_alerts,
                (SELECT COUNT(*) FROM pipeline_stats ps
                 WHERE ps.tenant_id = t.tenant_id
                   AND ps.started_at > NOW() - INTERVAL '24 hours'
                ) AS pipelines_24h
            FROM tenants t
            LEFT JOIN LATERAL (
                SELECT score, grade, critical_findings, warning_findings, trend
                FROM compliance_snapshots
                WHERE tenant_id = t.tenant_id
                ORDER BY snapshot_at DESC LIMIT 1
            ) cs ON TRUE
            WHERE t.active = TRUE
            ORDER BY cs.score ASC NULLS LAST
        """)

    def admin_system_health(self) -> Dict[str, Any]:
        """System-wide health metrics for admin dashboard."""
        totals = self._read_one("""
            SELECT
                (SELECT COUNT(*) FROM tenants WHERE active = TRUE),
                (SELECT COUNT(DISTINCT model_id) FROM model_snapshots),
                (SELECT COUNT(*) FROM alert_log WHERE resolved = FALSE),
                (SELECT COUNT(*) FROM pipeline_stats
                 WHERE started_at > NOW() - INTERVAL '24 hours'),
                (SELECT AVG(score) FROM (
                    SELECT DISTINCT ON (tenant_id) score
                    FROM compliance_snapshots
                    ORDER BY tenant_id, snapshot_at DESC
                ) recent),
                (SELECT COUNT(*) FROM alert_log WHERE resolved = FALSE AND severity = 'critical'),
                (SELECT COUNT(*) FROM pipeline_stats),
                (SELECT COUNT(*) FROM pipeline_stats WHERE status = 'completed'),
                (SELECT COUNT(*) FROM pipeline_stats WHERE status = 'failed'),
                (SELECT AVG(duration_ms) FROM pipeline_stats WHERE status = 'completed' AND duration_ms IS NOT NULL),
                (SELECT COUNT(*) FROM alert_log),
                (SELECT COUNT(*) FROM alert_log WHERE resolved = TRUE),
                (SELECT started_at FROM pipeline_stats ORDER BY started_at DESC LIMIT 1),
                (SELECT snapshot_at FROM compliance_snapshots ORDER BY snapshot_at DESC LIMIT 1),
                (SELECT COUNT(DISTINCT model_id) FROM model_snapshots WHERE status = 'production'),
                (SELECT COUNT(DISTINCT model_id) FROM model_snapshots WHERE finding_count > 0),
                (SELECT COUNT(*) FROM fairness_snapshots WHERE has_disparate_impact = TRUE AND statistically_significant = TRUE),
                (SELECT COUNT(*) FROM (
                    SELECT DISTINCT ON (tenant_id) score
                    FROM compliance_snapshots
                    ORDER BY tenant_id, snapshot_at DESC
                ) sub WHERE score < 60)
        """)
        if not totals:
            return {}

        tenant_count = totals[0] or 0
        total_models = totals[1] or 0
        open_alerts = totals[2] or 0
        pipelines_24h = totals[3] or 0
        avg_score = totals[4]
        critical_alerts = totals[5] or 0
        p_total = totals[6] or 0
        p_completed = totals[7] or 0
        p_failed = totals[8] or 0
        avg_dur = totals[9]
        t_alerts = totals[10] or 0
        r_alerts = totals[11] or 0

        table_names = [
            "tenants", "compliance_snapshots", "model_snapshots",
            "fairness_snapshots", "certification_snapshots", "alert_log",
            "pipeline_stats", "system_metrics",
        ]
        table_row_counts = {}
        total_rows = 0
        for tbl in table_names:
            row = self._read_one(f"SELECT COUNT(*) FROM {tbl}")
            cnt = row[0] if row else 0
            table_row_counts[tbl] = cnt
            total_rows += cnt

        return {
            "tenant_count": tenant_count,
            "total_models": total_models,
            "open_alerts": open_alerts,
            "pipelines_24h": pipelines_24h,
            "avg_compliance_score": round(avg_score, 1) if avg_score else None,
            "critical_alerts": critical_alerts,
            "pipelines_total": p_total,
            "pipeline_success_rate": round(p_completed / max(p_total, 1) * 100, 1),
            "pipeline_failure_rate": round(p_failed / max(p_total, 1) * 100, 1),
            "avg_pipeline_duration_ms": round(avg_dur, 1) if avg_dur else None,
            "total_alerts": t_alerts,
            "resolved_alerts": r_alerts,
            "alert_resolution_rate": round(r_alerts / max(t_alerts, 1) * 100, 1),
            "table_row_counts": table_row_counts,
            "total_rows": total_rows,
            "latest_pipeline_at": str(totals[12]) if totals[12] else None,
            "latest_compliance_at": str(totals[13]) if totals[13] else None,
            "models_in_production": totals[14] or 0,
            "models_with_findings": totals[15] or 0,
            "di_confirmed_count": totals[16] or 0,
            "tenants_below_c": totals[17] or 0,
        }

    # -- Platform-wide queries (admin) ---------------------------------------

    def get_all_models_platform(self) -> List[Dict[str, Any]]:
        return self._read_dicts("""
            SELECT DISTINCT ON (ms.tenant_id, ms.model_id)
                   ms.model_id, ms.tenant_id, ms.name, ms.version, ms.tier,
                   ms.status, ms.domain, ms.owner, ms.compliance_score,
                   ms.last_validated, ms.last_monitored,
                   ms.validation_overdue, ms.monitoring_overdue,
                   ms.finding_count, ms.snapshot_at,
                   t.name as tenant_name
            FROM model_snapshots ms
            JOIN tenants t ON ms.tenant_id = t.tenant_id
            WHERE t.active = TRUE
            ORDER BY ms.tenant_id, ms.model_id, ms.snapshot_at DESC
        """)

    def get_all_fairness_platform(self) -> List[Dict[str, Any]]:
        return self._read_dicts("""
            SELECT DISTINCT ON (fs.tenant_id, fs.model_id)
                   fs.*, t.name as tenant_name
            FROM fairness_snapshots fs
            JOIN tenants t ON fs.tenant_id = t.tenant_id
            WHERE t.active = TRUE
            ORDER BY fs.tenant_id, fs.model_id, fs.snapshot_at DESC
        """)

    def get_compliance_platform(self) -> Dict[str, Any]:
        tenant_scores = self._read_dicts("""
            SELECT DISTINCT ON (cs.tenant_id)
                   cs.tenant_id, t.name as tenant_name, t.tier,
                   cs.score, cs.grade, cs.critical_findings, cs.warning_findings,
                   cs.trend, cs.breakdowns, cs.top_risks, cs.snapshot_at
            FROM compliance_snapshots cs
            JOIN tenants t ON cs.tenant_id = t.tenant_id
            WHERE t.active = TRUE
            ORDER BY cs.tenant_id, cs.snapshot_at DESC
        """)
        scores = [t["score"] for t in tenant_scores if t["score"] is not None]
        return {
            "tenants": tenant_scores,
            "avg_score": round(sum(scores) / len(scores), 1) if scores else None,
            "min_score": min(scores) if scores else None,
            "max_score": max(scores) if scores else None,
            "grade_distribution": {
                "A": len([s for s in scores if s >= 90]),
                "B": len([s for s in scores if 75 <= s < 90]),
                "C": len([s for s in scores if 60 <= s < 75]),
                "D": len([s for s in scores if s < 60]),
            },
        }

    def get_pipeline_summary(self) -> Dict[str, Any]:
        totals = self._read_one("""
            SELECT
                (SELECT COUNT(*) FROM pipeline_stats),
                (SELECT COUNT(*) FROM pipeline_stats WHERE status = 'completed'),
                (SELECT COUNT(*) FROM pipeline_stats WHERE status = 'failed'),
                (SELECT AVG(duration_ms) FROM pipeline_stats
                 WHERE status = 'completed' AND duration_ms IS NOT NULL)
        """)
        total = totals[0] if totals else 0
        completed = totals[1] if totals else 0
        failed = totals[2] if totals else 0
        avg_dur = totals[3] if totals else None

        by_tenant = self._read_dicts("""
            SELECT ps.tenant_id, t.name as tenant_name,
                   COUNT(*) as total_runs,
                   SUM(CASE WHEN ps.status = 'completed' THEN 1 ELSE 0 END) as completed,
                   SUM(CASE WHEN ps.status = 'failed' THEN 1 ELSE 0 END) as failed,
                   ROUND(AVG(CASE WHEN ps.status = 'completed'
                             THEN ps.duration_ms END)::numeric, 0) as avg_duration_ms,
                   SUM(ps.node_count) as total_nodes,
                   SUM(ps.edge_count) as total_edges
            FROM pipeline_stats ps
            JOIN tenants t ON ps.tenant_id = t.tenant_id
            GROUP BY ps.tenant_id, t.name
            ORDER BY total_runs DESC
        """)
        by_pipeline = self._read_dicts("""
            SELECT pipeline_name,
                   COUNT(*) as run_count,
                   SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                   SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                   ROUND(AVG(CASE WHEN status = 'completed'
                             THEN duration_ms END)::numeric, 0) as avg_duration_ms
            FROM pipeline_stats
            GROUP BY pipeline_name
            ORDER BY run_count DESC
        """)
        return {
            "total_runs": total,
            "completed": completed,
            "failed": failed,
            "success_rate": round(completed / max(total, 1) * 100, 1),
            "avg_duration_ms": round(avg_dur, 1) if avg_dur else None,
            "by_tenant": by_tenant,
            "by_pipeline": by_pipeline,
        }

    def get_all_alerts_platform(self, limit: int = 50) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT id, tenant_id, severity, source, title, model_id, created_at
               FROM alert_log WHERE resolved = FALSE
               ORDER BY CASE severity
                   WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2
               END, created_at DESC LIMIT %s""",
            (limit,),
        )

    # -- User management (authentication) ------------------------------------

    def get_user_by_email(self, tenant_id: str, email: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            """SELECT id, tenant_id, email, password_hash, display_name, role,
                      active, invited_by, last_login_at, created_at
               FROM dashboard_users
               WHERE tenant_id = %s AND email = %s AND active = TRUE""",
            (tenant_id, email),
        )
        return rows[0] if rows else None

    def get_users(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT id, tenant_id, email, display_name, role,
                      active, invited_by, last_login_at, created_at
               FROM dashboard_users
               WHERE tenant_id = %s
               ORDER BY role, email""",
            (tenant_id,),
        )

    def create_user(self, tenant_id: str, email: str, password_hash: str,
                    display_name: str, role: str = "analyst",
                    invited_by: str = None) -> Optional[int]:
        row = self._write_returning(
            """INSERT INTO dashboard_users
               (tenant_id, email, password_hash, display_name, role, invited_by)
               VALUES (%s, %s, %s, %s, %s, %s) RETURNING id""",
            (tenant_id, email, password_hash, display_name, role, invited_by),
        )
        return row[0] if row else None

    def update_user_role(self, tenant_id: str, user_id: int, role: str) -> bool:
        self._write(
            """UPDATE dashboard_users SET role = %s, updated_at = NOW()
               WHERE id = %s AND tenant_id = %s""",
            (role, user_id, tenant_id),
        )
        return True

    def deactivate_user(self, tenant_id: str, user_id: int) -> bool:
        self._write(
            """UPDATE dashboard_users SET active = FALSE, updated_at = NOW()
               WHERE id = %s AND tenant_id = %s""",
            (user_id, tenant_id),
        )
        return True

    def reactivate_user(self, tenant_id: str, user_id: int) -> bool:
        self._write(
            """UPDATE dashboard_users SET active = TRUE, updated_at = NOW()
               WHERE id = %s AND tenant_id = %s""",
            (user_id, tenant_id),
        )
        return True

    def record_login(self, tenant_id: str, email: str) -> None:
        self._write(
            """UPDATE dashboard_users SET last_login_at = NOW()
               WHERE tenant_id = %s AND email = %s""",
            (tenant_id, email),
        )

    def update_user_password(self, tenant_id: str, user_id: int,
                             password_hash: str) -> bool:
        self._write(
            """UPDATE dashboard_users SET password_hash = %s, updated_at = NOW()
               WHERE id = %s AND tenant_id = %s""",
            (password_hash, user_id, tenant_id),
        )
        return True

    def count_users(self, tenant_id: str) -> int:
        row = self._read_one(
            "SELECT COUNT(*) FROM dashboard_users WHERE tenant_id = %s AND active = TRUE",
            (tenant_id,),
        )
        return row[0] if row else 0
