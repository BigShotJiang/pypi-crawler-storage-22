"""
HYDRA-24 Dashboard Server

Flask server for visualizing provenance data, DAG graphs, and compliance status.

Usage:
    python -m proveit.dashboard.server

Then open: http://localhost:5001
"""

from flask import Flask, render_template, jsonify, request, Response
import os
import csv
import io
import logging

from proveit.persistence.sqlite_storage import SQLiteStorage

app = Flask(__name__)
logger = logging.getLogger(__name__)

storage = None
DB_PATH = os.environ.get("PROVEIT_DB") or os.environ.get("HYDRA24_DB", "./proveit_dev.db")


ALLOWED_ORIGINS = [
    o.strip() for o in (
        os.environ.get("PROVEIT_CORS_ORIGINS")
        or os.environ.get("HYDRA24_CORS_ORIGINS", "http://localhost:5001,http://127.0.0.1:5001")
    ).split(",") if o.strip()
]


@app.after_request
def add_security_headers(response):
    # CORS — only set headers when origin is explicitly allowed
    origin = request.headers.get("Origin", "")
    if origin in ALLOWED_ORIGINS:
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Methods"] = "GET, OPTIONS"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    # Security headers
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; "
        "connect-src 'self'"
    )
    return response


def get_storage():
    global storage
    if storage is None:
        storage = SQLiteStorage(DB_PATH)
    if storage.conn is None:
        storage.connect()
    return storage


def _fp_to_int(value):
    """Convert a fingerprint value (possibly bytes/memoryview) to int."""
    if isinstance(value, (bytes, memoryview)):
        return int.from_bytes(bytes(value), "big")
    return value


def _serialize_node_row(row):
    """Convert a (node_id, fingerprint, node_type, operation,
    table_name, column_name, is_protected) SQL row to a JSON-safe dict."""
    return {
        "node_id": row[0],
        "fingerprint": _fp_to_int(row[1]),
        "node_type": str(row[2]) if row[2] else None,
        "operation": str(row[3]) if row[3] else None,
        "table_name": str(row[4]) if row[4] else None,
        "column_name": str(row[5]) if row[5] else None,
        "is_protected": bool(row[6]),
    }


def _load_dag_graph(store, root_node_id, max_nodes=500):
    """Walk the DAG from *root_node_id* and return (nodes_map, edges_list).

    Uses a single recursive CTE query instead of per-node queries (N+1 -> 1).
    Each entry in *nodes_map* is keyed by ``node_id`` and contains the
    standard dict representation.  *edges_list* is a flat list of
    ``{source, target}`` dicts.
    """
    cursor = store.conn.cursor()

    # Single recursive CTE: fetch all reachable ancestor nodes in one query
    cursor.execute("""
        WITH RECURSIVE ancestors(node_id, depth) AS (
            SELECT ?, 0
            UNION
            SELECT e.parent_node_id, a.depth + 1
            FROM dag_edges e
            JOIN ancestors a ON e.child_node_id = a.node_id
            WHERE a.depth < 50
        )
        SELECT DISTINCT n.node_id, n.fingerprint, n.node_type, n.operation,
               n.table_name, n.column_name, n.is_protected, n.pair_id,
               MIN(a.depth) AS depth
        FROM ancestors a
        JOIN dag_nodes n ON a.node_id = n.node_id
        GROUP BY n.node_id
        LIMIT ?
    """, (root_node_id, max_nodes))

    nodes_map = {}
    for row in cursor.fetchall():
        nodes_map[row[0]] = {
            "id": row[0],
            "fingerprint": _fp_to_int(row[1]),
            "type": str(row[2]) if row[2] else "UNKNOWN",
            "operation": str(row[3]) if row[3] else "unknown",
            "table": str(row[4]) if row[4] else None,
            "column": str(row[5]) if row[5] else None,
            "is_protected": bool(row[6]),
            "pair_id": row[7],
            "depth": row[8],
        }

    if not nodes_map:
        return {}, []

    # Bulk-fetch all edges between discovered nodes in a single query
    node_ids = list(nodes_map.keys())
    placeholders = ",".join("?" for _ in node_ids)
    cursor.execute(f"""
        SELECT parent_node_id, child_node_id
        FROM dag_edges
        WHERE child_node_id IN ({placeholders})
          AND parent_node_id IN ({placeholders})
    """, node_ids + node_ids)

    edges_list = [
        {"source": row[0], "target": row[1]}
        for row in cursor.fetchall()
    ]

    return nodes_map, edges_list


def _build_computation_dag(nodes_map, edges_list, root_id):
    """Reconstruct a ``ComputationDAG`` from the walk results."""
    from proveit.hydra24_dag import ComputationDAG, DAGNode, DAGEdge, NodeType

    dag_nodes = {}
    for nid, nd in nodes_map.items():
        try:
            nt = NodeType[nd["type"]]
        except KeyError:
            nt = NodeType.CUSTOM

        dag_nodes[nid] = DAGNode(
            node_id=nid,
            node_type=nt,
            operation=nd["operation"],
            inputs=[e["source"] for e in edges_list if e["target"] == nid],
            provenance=nd["fingerprint"] if isinstance(nd["fingerprint"], int) else 0,
            table=nd.get("table"),
            column=nd.get("column"),
            pair_id=nd.get("pair_id"),
            is_protected=nd.get("is_protected", False),
        )

    dag_edges = [
        DAGEdge(source_id=e["source"], target_id=e["target"], input_index=i)
        for i, e in enumerate(edges_list)
    ]

    return ComputationDAG(root_id=root_id, nodes=dag_nodes, edges=dag_edges)


@app.route('/health')
def health():
    try:
        store = get_storage()
        cursor = store.conn.cursor()
        cursor.execute("SELECT 1")
        return jsonify({"status": "healthy", "database": "connected"})
    except Exception as e:
        logger.exception("Health check failed")
        return jsonify({"status": "unhealthy", "error": "Database connection failed"}), 503


@app.route('/favicon.ico')
def favicon():
    return Response(status=204)


@app.route('/')
def index():
    return render_template('dashboard.html')


@app.route('/api/stats')
def api_stats():
    try:
        store = get_storage()
        stats = store.get_stats()

        # Single query for both type count and breakdown
        cursor = store.conn.cursor()
        cursor.execute("""
            SELECT node_type, COUNT(*) FROM dag_nodes GROUP BY node_type
        """)
        breakdown = {str(row[0]): row[1] for row in cursor.fetchall()}
        stats['node_types'] = len(breakdown)
        stats['type_breakdown'] = breakdown

        return jsonify(stats)
    except Exception as e:
        logger.exception("Error fetching stats")
        return jsonify({"error": "Failed to load stats"}), 500


@app.route('/api/pipelines')
def api_pipelines():
    try:
        store = get_storage()
        limit = min(request.args.get('limit', 100, type=int), 500)
        pipelines = store.get_all_pipelines(limit=limit)
        return jsonify(pipelines)
    except Exception as e:
        logger.exception("Error fetching pipelines")
        return jsonify({"error": "Failed to load pipelines"}), 500


@app.route('/api/nodes')
def api_nodes():
    try:
        store = get_storage()
        limit = min(request.args.get('limit', 200, type=int), 500)
        nodes = store.get_recent_nodes(limit=limit)

        cleaned_nodes = []
        for node in nodes:
            cleaned_node = {}
            for key, value in node.items():
                if isinstance(value, bytes):
                    cleaned_node[key] = value.hex()
                elif isinstance(value, memoryview):
                    cleaned_node[key] = bytes(value).hex()
                elif value is None:
                    cleaned_node[key] = None
                elif isinstance(value, (int, float, bool)):
                    cleaned_node[key] = value
                else:
                    cleaned_node[key] = str(value)
            cleaned_nodes.append(cleaned_node)

        return jsonify(cleaned_nodes)
    except Exception as e:
        logger.exception("Error fetching nodes")
        return jsonify({"error": "Failed to load nodes"}), 500


@app.route('/api/node/<int:fingerprint>')
def api_node(fingerprint):
    try:
        store = get_storage()
        node = store.get_node_by_fingerprint(fingerprint)
        if node:
            for key in list(node):
                if isinstance(node[key], (bytes, memoryview)):
                    node[key] = bytes(node[key]).hex()
            return jsonify(node)
        return jsonify({'error': 'Node not found'}), 404
    except Exception as e:
        logger.exception("Error fetching node %s", fingerprint)
        return jsonify({"error": "Failed to load node"}), 500


@app.route('/api/dag/<int:fingerprint>')
def api_dag(fingerprint):
    try:
        store = get_storage()

        root_data = store.get_node_by_fingerprint(fingerprint)
        if not root_data:
            return jsonify({'error': 'Fingerprint not found'}), 404

        MAX_NODES = 500
        nodes_map, edges_list = _load_dag_graph(
            store, root_data['node_id'], max_nodes=MAX_NODES,
        )

        # Add input_position to edges for this endpoint
        for i, edge in enumerate(edges_list):
            edge['input_position'] = i

        max_depth = max(
            (n.get('depth', 0) for n in nodes_map.values()), default=0,
        )
        protected_sources = [n for n in nodes_map.values() if n.get('is_protected')]
        source_nodes = [n for n in nodes_map.values() if n.get('type') == 'SOURCE']

        return jsonify({
            'root_id': root_data['node_id'],
            'depth': max_depth,
            'node_count': len(nodes_map),
            'edge_count': len(edges_list),
            'has_protected': len(protected_sources) > 0,
            'protected_count': len(protected_sources),
            'source_count': len(source_nodes),
            'nodes': list(nodes_map.values()),
            'edges': edges_list,
            'truncated': len(nodes_map) >= MAX_NODES,
        })
    except Exception as e:
        logger.exception("Error fetching DAG for %s", fingerprint)
        return jsonify({"error": "Failed to load DAG"}), 500


def _escape_like(value: str) -> str:
    """Escape SQL LIKE metacharacters (%, _) so user input is treated literally."""
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


@app.route('/api/search')
def api_search():
    try:
        store = get_storage()
        query = request.args.get('q', '').strip()

        if not query or len(query) > 200:
            return jsonify([])

        cursor = store.conn.cursor()

        if query.startswith('0x') or query.startswith('0X'):
            try:
                fp = int(query, 16)
                cursor.execute("""
                    SELECT node_id, fingerprint, node_type, operation,
                           table_name, column_name, is_protected
                    FROM dag_nodes WHERE fingerprint = ?
                """, (fp,))
            except ValueError:
                return jsonify([])
        else:
            # Escape LIKE metacharacters so user input is treated literally
            safe_query = f'%{_escape_like(query)}%'
            cursor.execute("""
                SELECT node_id, fingerprint, node_type, operation,
                       table_name, column_name, is_protected
                FROM dag_nodes
                WHERE table_name LIKE ? ESCAPE '\\'
                   OR column_name LIKE ? ESCAPE '\\'
                   OR operation LIKE ? ESCAPE '\\'
                LIMIT 50
            """, (safe_query, safe_query, safe_query))

        results = [_serialize_node_row(row) for row in cursor.fetchall()]

        return jsonify(results)
    except Exception as e:
        logger.exception("Error in search")
        return jsonify({"error": "Search failed"}), 500


@app.route('/api/protected-data-flow')
def api_protected_data_flow():
    try:
        store = get_storage()
        cursor = store.conn.cursor()

        cursor.execute("""
            SELECT DISTINCT n.node_id, n.fingerprint, n.node_type, n.operation,
                   n.table_name, n.column_name
            FROM dag_nodes n
            WHERE n.is_protected = 1
            ORDER BY n.created_at DESC
            LIMIT 100
        """)

        protected_nodes = [_serialize_node_row(row) for row in cursor.fetchall()]

        return jsonify(protected_nodes)
    except Exception as e:
        logger.exception("Error fetching protected data flow")
        return jsonify({"error": "Failed to load protected data flow"}), 500


@app.route('/api/sources')
def api_sources():
    try:
        store = get_storage()
        cursor = store.conn.cursor()

        cursor.execute("""
            SELECT pair_id, table_name, column_name, is_protected, registered_at
            FROM source_registry
            ORDER BY registered_at DESC
        """)

        sources = []
        for row in cursor.fetchall():
            sources.append({
                'pair_id': row[0],
                'table_name': str(row[1]) if row[1] else None,
                'column_name': str(row[2]) if row[2] else None,
                'is_protected': bool(row[3]),
                'registered_at': str(row[4]) if row[4] else None,
            })

        return jsonify(sources)
    except Exception as e:
        logger.exception("Error fetching sources")
        return jsonify({"error": "Failed to load sources"}), 500


@app.route('/api/compliance/check/<int:fingerprint>')
def api_compliance_check(fingerprint):
    try:
        store = get_storage()

        root_data = store.get_node_by_fingerprint(fingerprint)
        if not root_data:
            return jsonify({'error': 'Fingerprint not found'}), 404

        nodes_map, edges_list = _load_dag_graph(store, root_data['node_id'])
        dag = _build_computation_dag(nodes_map, edges_list, root_data['node_id'])

        from proveit.compliance import (
            EUAIActEngine, ECOAEngine,
            ComplianceReport,
        )

        report = ComplianceReport()
        engines = [EUAIActEngine(), ECOAEngine()]

        metadata = {
            'domain': 'loan_approval',
            'model_type': 'gradient_boosting',
        }

        for engine in engines:
            try:
                report.add(engine.check(dag, metadata))
            except Exception as eng_err:
                logger.warning(
                    "Engine %s failed: %s",
                    engine.regulation_name, eng_err,
                )

        return jsonify(report.to_dict())

    except Exception as e:
        logger.exception("Compliance check failed for %s", fingerprint)
        return jsonify({
            'error': 'Compliance check failed',
        }), 500


@app.route('/api/export/csv')
def api_export_csv():
    try:
        store = get_storage()
        limit = min(request.args.get('limit', 50000, type=int), 100000)

        def generate_csv():
            cursor = store.conn.cursor()
            cursor.execute("""
                SELECT node_id, fingerprint, node_type, operation,
                       table_name, column_name, is_protected, pair_id, created_at
                FROM dag_nodes
                ORDER BY created_at DESC
                LIMIT ?
            """, (limit,))

            buf = io.StringIO()
            writer = csv.writer(buf)
            writer.writerow([
                'node_id', 'fingerprint', 'node_type', 'operation',
                'table_name', 'column_name', 'is_protected', 'pair_id', 'created_at'
            ])
            yield buf.getvalue()
            buf.seek(0)
            buf.truncate(0)

            for row in cursor:
                fp_val = _fp_to_int(row[1])
                writer.writerow([
                    row[0],
                    f'0x{fp_val:06X}' if isinstance(fp_val, int) else fp_val,
                    str(row[2]) if row[2] else '',
                    str(row[3]) if row[3] else '',
                    str(row[4]) if row[4] else '',
                    str(row[5]) if row[5] else '',
                    'Yes' if row[6] else 'No',
                    row[7] if row[7] is not None else '',
                    str(row[8]) if row[8] else '',
                ])
                yield buf.getvalue()
                buf.seek(0)
                buf.truncate(0)

        return Response(
            generate_csv(),
            mimetype='text/csv',
            headers={'Content-Disposition': 'attachment; filename=proveit_nodes.csv'}
        )
    except Exception as e:
        logger.exception("Error exporting CSV")
        return jsonify({"error": "CSV export failed"}), 500


@app.route('/api/dag/<int:fingerprint>/report')
def api_dag_report(fingerprint):
    try:
        store = get_storage()

        root_data = store.get_node_by_fingerprint(fingerprint)
        if not root_data:
            return '<h1>Fingerprint not found</h1>', 404

        nodes_map, edges_list = _load_dag_graph(store, root_data['node_id'])
        dag = _build_computation_dag(nodes_map, edges_list, root_data['node_id'])

        from proveit.compliance import EUAIActEngine, ECOAEngine
        from proveit.reports.compliance import ComplianceReportGenerator, ReportConfig

        fp_hex = f'0x{fingerprint:06X}'
        metadata = {
            'domain': 'loan_approval',
            'model_type': 'gradient_boosting',
        }

        compliance_results = []
        engines = [EUAIActEngine(), ECOAEngine()]
        for engine in engines:
            try:
                result = engine.check(dag, metadata)
                compliance_results.append(result.to_dict())
            except Exception as eng_err:
                logger.warning(
                    "Report engine %s failed: %s",
                    engine.regulation_name, eng_err,
                )

        config = ReportConfig(
            title=f'ProveIt Compliance Report - {fp_hex}',
            organization='ProveIt Dashboard',
        )
        generator = ComplianceReportGenerator(config)
        report_html = generator.generate(
            dag=dag,
            compliance_results=compliance_results,
        )

        return report_html

    except Exception as e:
        logger.exception("Report generation failed for %s", fingerprint)
        return '<h1>Report generation failed</h1><p>An internal error occurred. Check server logs for details.</p>', 500


def main():
    """Entry point for the proveit-dashboard console script."""
    global DB_PATH

    import argparse
    parser = argparse.ArgumentParser(description='ProveIt Dashboard')
    parser.add_argument('--db', default=DB_PATH, help='SQLite database path')
    parser.add_argument('--port', default=5001, type=int, help='Server port')
    parser.add_argument('--host', default='127.0.0.1', help='Server host')
    parser.add_argument('--debug', action='store_true', default=False, help='Enable debug mode')
    args = parser.parse_args()

    DB_PATH = args.db

    from proveit import __version__
    print()
    print("  ProveIt Provenance Dashboard v" + __version__)
    print("  " + "=" * 44)
    print(f"  Database:   {DB_PATH}")
    print(f"  Dashboard:  http://{args.host}:{args.port}")
    print()

    app.run(debug=args.debug, port=args.port, host=args.host)


if __name__ == '__main__':
    main()
