"""
SQLite-backed dashboard store for local development and integration testing.

Drop-in replacement for the Aurora PostgreSQL DashboardStore that uses SQLite.
Implements the same public interface so DashboardSync, client_app, and admin_app
work identically in both modes.

Usage::

    from proveit.dashboard.sqlite_dashdb import SQLiteDashboardStore

    store = SQLiteDashboardStore("./dashboard.db")
    store.connect()
    store.ensure_schema()

    # Same API as DashboardStore:
    store.insert_compliance_snapshot("tenant_1", {...})
    data = store.get_latest_compliance("tenant_1")
"""

import json
import logging
import sqlite3
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional

import numpy as np

logger = logging.getLogger(__name__)


class _NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, (np.bool_,)):
            return bool(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        return super().default(obj)


def _json_dumps(obj) -> str:
    return json.dumps(obj, cls=_NumpyEncoder)


def _adapt(val):
    """Convert numpy types and dicts/lists to native Python for sqlite3."""
    if isinstance(val, (np.integer,)):
        return int(val)
    if isinstance(val, (np.floating,)):
        return float(val)
    if isinstance(val, (np.bool_,)):
        return bool(val)
    if isinstance(val, np.ndarray):
        return _json_dumps(val.tolist())
    if isinstance(val, (dict, list)):
        return _json_dumps(val)
    return val


_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS tenants (
    tenant_id       TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    tier            TEXT NOT NULL DEFAULT 'professional',
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    active          INTEGER NOT NULL DEFAULT 1,
    config          TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS compliance_snapshots (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    score           REAL NOT NULL,
    grade           TEXT NOT NULL,
    engines_evaluated INTEGER NOT NULL DEFAULT 0,
    critical_findings INTEGER NOT NULL DEFAULT 0,
    warning_findings  INTEGER NOT NULL DEFAULT 0,
    total_findings  INTEGER NOT NULL DEFAULT 0,
    top_risks       TEXT DEFAULT '[]',
    breakdowns      TEXT DEFAULT '[]',
    bonuses         TEXT DEFAULT '{}',
    trend           TEXT,
    snapshot_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_comp_snap_tenant
    ON compliance_snapshots (tenant_id, snapshot_at DESC);

CREATE TABLE IF NOT EXISTS model_snapshots (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    model_id        TEXT NOT NULL,
    name            TEXT NOT NULL,
    version         TEXT,
    tier            INTEGER NOT NULL DEFAULT 3,
    status          TEXT NOT NULL DEFAULT 'development',
    domain          TEXT,
    owner           TEXT,
    compliance_score REAL,
    last_validated  TEXT,
    last_monitored  TEXT,
    validation_overdue INTEGER DEFAULT 0,
    monitoring_overdue INTEGER DEFAULT 0,
    finding_count   INTEGER DEFAULT 0,
    snapshot_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_model_snap_tenant
    ON model_snapshots (tenant_id, snapshot_at DESC);

CREATE TABLE IF NOT EXISTS fairness_snapshots (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    model_id        TEXT NOT NULL,
    has_disparate_impact INTEGER DEFAULT 0,
    worst_ratio     REAL,
    worst_group     TEXT,
    p_value         REAL,
    statistically_significant INTEGER DEFAULT 0,
    protected_attributes TEXT DEFAULT '[]',
    sample_size_warnings TEXT DEFAULT '[]',
    details         TEXT DEFAULT '{}',
    snapshot_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_fair_snap_tenant
    ON fairness_snapshots (tenant_id, snapshot_at DESC);

CREATE TABLE IF NOT EXISTS certification_snapshots (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    cert_type       TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'not_started',
    issued_date     TEXT,
    expiry_date     TEXT,
    days_until_expiry INTEGER,
    snapshot_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_cert_snap_tenant
    ON certification_snapshots (tenant_id, snapshot_at DESC);

CREATE TABLE IF NOT EXISTS alert_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    severity        TEXT NOT NULL,
    source          TEXT NOT NULL,
    title           TEXT NOT NULL,
    description     TEXT,
    model_id        TEXT,
    regulation      TEXT,
    resolved        INTEGER DEFAULT 0,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    resolved_at     TEXT
);

CREATE INDEX IF NOT EXISTS idx_alert_tenant
    ON alert_log (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_alert_unresolved
    ON alert_log (tenant_id, resolved, severity);

CREATE TABLE IF NOT EXISTS pipeline_stats (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    pipeline_name   TEXT,
    status          TEXT NOT NULL,
    node_count      INTEGER DEFAULT 0,
    edge_count      INTEGER DEFAULT 0,
    duration_ms     INTEGER,
    started_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    completed_at    TEXT
);

CREATE INDEX IF NOT EXISTS idx_pipeline_tenant
    ON pipeline_stats (tenant_id, started_at DESC);

CREATE TABLE IF NOT EXISTS system_metrics (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    metric_name     TEXT NOT NULL,
    metric_value    REAL NOT NULL,
    labels          TEXT DEFAULT '{}',
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_sys_metrics
    ON system_metrics (metric_name, recorded_at DESC);

CREATE TABLE IF NOT EXISTS dashboard_users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id       TEXT NOT NULL,
    email           TEXT NOT NULL,
    password_hash   TEXT,
    display_name    TEXT NOT NULL DEFAULT '',
    role            TEXT NOT NULL DEFAULT 'analyst',
    active          INTEGER NOT NULL DEFAULT 1,
    invited_by      TEXT,
    last_login_at   TEXT,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    updated_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    UNIQUE(tenant_id, email)
);

CREATE INDEX IF NOT EXISTS idx_users_tenant
    ON dashboard_users (tenant_id, active);
CREATE INDEX IF NOT EXISTS idx_users_email
    ON dashboard_users (email);
"""


class SQLiteDashboardStore:
    """SQLite-backed dashboard store -- same interface as DashboardStore.

    Uses a single SQLite file for both reads and writes. Perfect for
    local development, integration testing, and single-tenant demos.
    """

    def __init__(self, db_path: str = ":memory:"):
        self.db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None

    def connect(self) -> None:
        self._conn = sqlite3.connect(
            self.db_path, check_same_thread=False, timeout=10.0,
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.execute("PRAGMA foreign_keys=ON")

    def disconnect(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def __enter__(self):
        if self._conn is None:
            self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()
        return False

    def ensure_schema(self) -> None:
        self._conn.executescript(_SCHEMA_SQL)
        self._conn.commit()

    def _write(self, sql: str, params: tuple = ()) -> None:
        params = tuple(_adapt(p) for p in params)
        self._conn.execute(sql, params)
        self._conn.commit()

    def _write_returning(self, sql: str, params: tuple = ()) -> Optional[tuple]:
        params = tuple(_adapt(p) for p in params)
        cur = self._conn.execute(sql, params)
        self._conn.commit()
        return (cur.lastrowid,)

    def _read_one(self, sql: str, params: tuple = ()) -> Optional[tuple]:
        cur = self._conn.execute(sql, params)
        return cur.fetchone()

    def _read_all(self, sql: str, params: tuple = ()) -> List[tuple]:
        cur = self._conn.execute(sql, params)
        return cur.fetchall()

    def _read_dicts(self, sql: str, params: tuple = ()) -> List[Dict[str, Any]]:
        cur = self._conn.execute(sql, params)
        cols = [desc[0] for desc in cur.description]
        rows = cur.fetchall()
        result = []
        for row in rows:
            d = dict(zip(cols, row))
            for key in ("top_risks", "breakdowns", "bonuses", "protected_attributes",
                        "sample_size_warnings", "details", "labels", "config"):
                if key in d and isinstance(d[key], str):
                    try:
                        d[key] = json.loads(d[key])
                    except (json.JSONDecodeError, TypeError):
                        pass
            if "has_disparate_impact" in d:
                d["has_disparate_impact"] = bool(d["has_disparate_impact"])
            if "statistically_significant" in d:
                d["statistically_significant"] = bool(d["statistically_significant"])
            if "resolved" in d:
                d["resolved"] = bool(d["resolved"])
            if "active" in d:
                d["active"] = bool(d["active"])
            if "validation_overdue" in d:
                d["validation_overdue"] = bool(d["validation_overdue"])
            if "monitoring_overdue" in d:
                d["monitoring_overdue"] = bool(d["monitoring_overdue"])
            result.append(d)
        return result

    # -- Tenant management ---------------------------------------------------

    def upsert_tenant(self, tenant_id: str, name: str, tier: str = "professional",
                      config: Optional[Dict[str, Any]] = None) -> None:
        cfg = _json_dumps(config or {})
        self._write(
            """INSERT INTO tenants (tenant_id, name, tier, config)
               VALUES (?, ?, ?, ?)
               ON CONFLICT (tenant_id) DO UPDATE
               SET name = excluded.name, tier = excluded.tier,
                   config = excluded.config""",
            (tenant_id, name, tier, cfg),
        )

    def get_tenant_config(self, tenant_id: str) -> Dict[str, Any]:
        rows = self._read_dicts(
            "SELECT config FROM tenants WHERE tenant_id = ? AND active = 1",
            (tenant_id,),
        )
        if not rows:
            return {}
        raw = rows[0].get("config", "{}")
        if isinstance(raw, str):
            return json.loads(raw)
        return raw or {}

    def get_tenant(self, tenant_id: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            "SELECT * FROM tenants WHERE tenant_id = ? AND active = 1",
            (tenant_id,),
        )
        return rows[0] if rows else None

    def get_all_tenants(self) -> List[Dict[str, Any]]:
        return self._read_dicts(
            "SELECT * FROM tenants WHERE active = 1 ORDER BY name"
        )

    # -- Compliance snapshots ------------------------------------------------

    def insert_compliance_snapshot(self, tenant_id: str, data: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO compliance_snapshots
               (tenant_id, score, grade, engines_evaluated, critical_findings,
                warning_findings, total_findings, top_risks, breakdowns, bonuses, trend)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                tenant_id,
                data["score"], data["grade"], data.get("engines_evaluated", 0),
                data.get("critical_findings", 0), data.get("warning_findings", 0),
                data.get("total_findings", 0),
                data.get("top_risks", []),
                data.get("breakdowns", []),
                data.get("bonuses_applied", {}),
                data.get("trend"),
            ),
        )

    def get_latest_compliance(self, tenant_id: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            """SELECT * FROM compliance_snapshots
               WHERE tenant_id = ? ORDER BY snapshot_at DESC LIMIT 1""",
            (tenant_id,),
        )
        return rows[0] if rows else None

    def get_compliance_history(self, tenant_id: str, limit: int = 30) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT score, grade, total_findings, critical_findings, snapshot_at
               FROM compliance_snapshots
               WHERE tenant_id = ? ORDER BY snapshot_at DESC LIMIT ?""",
            (tenant_id, limit),
        )

    # -- Model snapshots -----------------------------------------------------

    def upsert_model_snapshot(self, tenant_id: str, model: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO model_snapshots
               (tenant_id, model_id, name, version, tier, status, domain, owner,
                compliance_score, last_validated, last_monitored,
                validation_overdue, monitoring_overdue, finding_count)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                tenant_id, model["model_id"], model["name"],
                model.get("version"), model.get("tier", 3),
                model.get("status", "development"), model.get("domain"),
                model.get("owner"), model.get("compliance_score"),
                model.get("last_validated"), model.get("last_monitored"),
                model.get("validation_overdue", False),
                model.get("monitoring_overdue", False),
                model.get("finding_count", 0),
            ),
        )

    def get_models(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT model_id, name, version, tier, status, domain, owner,
                      compliance_score, last_validated, last_monitored,
                      validation_overdue, monitoring_overdue, finding_count,
                      snapshot_at
               FROM model_snapshots
               WHERE tenant_id = ?
               GROUP BY model_id
               HAVING snapshot_at = MAX(snapshot_at)
               ORDER BY model_id""",
            (tenant_id,),
        )

    # -- Fairness snapshots --------------------------------------------------

    def insert_fairness_snapshot(self, tenant_id: str, data: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO fairness_snapshots
               (tenant_id, model_id, has_disparate_impact, worst_ratio,
                worst_group, p_value, statistically_significant,
                protected_attributes, sample_size_warnings, details)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (
                tenant_id, data["model_id"],
                1 if data.get("has_disparate_impact", False) else 0,
                data.get("worst_ratio"), data.get("worst_group"),
                data.get("p_value"),
                1 if data.get("statistically_significant", False) else 0,
                data.get("protected_attributes", []),
                data.get("sample_size_warnings", []),
                data.get("details", {}),
            ),
        )

    def get_latest_fairness(self, tenant_id: str, model_id: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            """SELECT * FROM fairness_snapshots
               WHERE tenant_id = ? AND model_id = ?
               ORDER BY snapshot_at DESC LIMIT 1""",
            (tenant_id, model_id),
        )
        return rows[0] if rows else None

    def get_all_fairness(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT *
               FROM fairness_snapshots
               WHERE tenant_id = ?
               GROUP BY model_id
               HAVING snapshot_at = MAX(snapshot_at)
               ORDER BY model_id""",
            (tenant_id,),
        )

    # -- Certifications ------------------------------------------------------

    def upsert_certification(self, tenant_id: str, cert: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO certification_snapshots
               (tenant_id, cert_type, status, issued_date, expiry_date, days_until_expiry)
               VALUES (?,?,?,?,?,?)""",
            (
                tenant_id, cert["cert_type"], cert.get("status", "not_started"),
                cert.get("issued_date"), cert.get("expiry_date"),
                cert.get("days_until_expiry"),
            ),
        )

    def get_certifications(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT cert_type, status, issued_date, expiry_date,
                      days_until_expiry, snapshot_at
               FROM certification_snapshots
               WHERE tenant_id = ?
               GROUP BY cert_type
               HAVING snapshot_at = MAX(snapshot_at)
               ORDER BY cert_type""",
            (tenant_id,),
        )

    # -- Alert log -----------------------------------------------------------

    def insert_alert(self, tenant_id: str, alert: Dict[str, Any]) -> int:
        sql = """INSERT INTO alert_log
                 (tenant_id, severity, source, title, description, model_id, regulation)
                 VALUES (?,?,?,?,?,?,?)"""
        params = (
            tenant_id, alert["severity"], alert["source"],
            alert["title"], alert.get("description"),
            alert.get("model_id"), alert.get("regulation"),
        )
        params = tuple(_adapt(p) for p in params)
        cur = self._conn.execute(sql, params)
        self._conn.commit()
        return cur.lastrowid

    def get_alerts(self, tenant_id: str, unresolved_only: bool = True,
                   limit: int = 50) -> List[Dict[str, Any]]:
        if unresolved_only:
            return self._read_dicts(
                """SELECT * FROM alert_log
                   WHERE tenant_id = ? AND resolved = 0
                   ORDER BY CASE severity
                       WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2
                   END, created_at DESC LIMIT ?""",
                (tenant_id, limit),
            )
        return self._read_dicts(
            """SELECT * FROM alert_log WHERE tenant_id = ?
               ORDER BY created_at DESC LIMIT ?""",
            (tenant_id, limit),
        )

    def resolve_alert(self, alert_id: int) -> None:
        self._write(
            """UPDATE alert_log SET resolved = 1,
               resolved_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
               WHERE id = ?""",
            (alert_id,),
        )

    def get_all_alerts_platform(self, limit: int = 50) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT id, tenant_id, severity, source, title, model_id, created_at
               FROM alert_log WHERE resolved = 0
               ORDER BY CASE severity
                   WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2
               END, created_at DESC LIMIT ?""",
            (limit,),
        )

    # -- Pipeline stats (admin) ----------------------------------------------

    def insert_pipeline_stat(self, tenant_id: str, stat: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO pipeline_stats
               (tenant_id, pipeline_name, status, node_count, edge_count,
                duration_ms, completed_at)
               VALUES (?,?,?,?,?,?,?)""",
            (
                tenant_id, stat.get("pipeline_name"), stat["status"],
                stat.get("node_count", 0), stat.get("edge_count", 0),
                stat.get("duration_ms"), stat.get("completed_at"),
            ),
        )

    def get_pipeline_stats(self, tenant_id: Optional[str] = None,
                           limit: int = 100) -> List[Dict[str, Any]]:
        if tenant_id:
            return self._read_dicts(
                """SELECT id AS pipeline_id, tenant_id, pipeline_name, status,
                          node_count, edge_count, duration_ms, started_at, completed_at
                   FROM pipeline_stats WHERE tenant_id = ?
                   ORDER BY started_at DESC LIMIT ?""",
                (tenant_id, limit),
            )
        return self._read_dicts(
            """SELECT id AS pipeline_id, tenant_id, pipeline_name, status,
                      node_count, edge_count, duration_ms, started_at, completed_at
               FROM pipeline_stats ORDER BY started_at DESC LIMIT ?""",
            (limit,),
        )

    # -- System metrics (admin) ----------------------------------------------

    def record_metric(self, name: str, value: float,
                      labels: Optional[Dict[str, str]] = None) -> None:
        self._write(
            """INSERT INTO system_metrics (metric_name, metric_value, labels)
               VALUES (?, ?, ?)""",
            (name, value, labels or {}),
        )

    def get_latest_metrics(self) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT metric_name, metric_value, labels, recorded_at
               FROM system_metrics
               GROUP BY metric_name
               HAVING recorded_at = MAX(recorded_at)
               ORDER BY metric_name"""
        )

    # -- Admin aggregates ----------------------------------------------------

    def admin_tenant_summary(self) -> List[Dict[str, Any]]:
        tenants = self._read_dicts(
            "SELECT * FROM tenants WHERE active = 1 ORDER BY name"
        )
        result = []
        for t in tenants:
            tid = t["tenant_id"]
            comp = self.get_latest_compliance(tid)
            models = self.get_models(tid)
            alerts = self.get_alerts(tid, unresolved_only=True)
            pipelines = self._read_dicts(
                """SELECT COUNT(*) as cnt FROM pipeline_stats
                   WHERE tenant_id = ?
                   AND started_at > datetime('now', '-24 hours')""",
                (tid,),
            )
            result.append({
                "tenant_id": tid,
                "name": t["name"],
                "tier": t["tier"],
                "created_at": t["created_at"],
                "latest_score": comp["score"] if comp else None,
                "latest_grade": comp["grade"] if comp else None,
                "critical_findings": comp.get("critical_findings", 0) if comp else 0,
                "warning_findings": comp.get("warning_findings", 0) if comp else 0,
                "trend": comp.get("trend") if comp else None,
                "model_count": len(models),
                "open_alerts": len(alerts),
                "pipelines_24h": pipelines[0]["cnt"] if pipelines else 0,
            })
        return result

    def admin_system_health(self) -> Dict[str, Any]:
        tenants = self._read_dicts(
            "SELECT COUNT(*) as cnt FROM tenants WHERE active = 1"
        )
        models = self._read_dicts(
            "SELECT COUNT(DISTINCT model_id) as cnt FROM model_snapshots"
        )
        alerts = self._read_dicts(
            "SELECT COUNT(*) as cnt FROM alert_log WHERE resolved = 0"
        )
        pipelines = self._read_dicts(
            """SELECT COUNT(*) as cnt FROM pipeline_stats
               WHERE started_at > datetime('now', '-24 hours')"""
        )
        scores = self._read_dicts(
            """SELECT AVG(score) as avg_score FROM (
                SELECT score FROM compliance_snapshots
                GROUP BY tenant_id
                HAVING snapshot_at = MAX(snapshot_at)
            )"""
        )
        avg_score = scores[0]["avg_score"] if scores and scores[0]["avg_score"] else None

        critical_alerts = self._read_dicts(
            "SELECT COUNT(*) as cnt FROM alert_log WHERE resolved = 0 AND severity = 'critical'"
        )
        pipelines_total = self._read_dicts(
            "SELECT COUNT(*) as cnt FROM pipeline_stats"
        )
        pipelines_completed = self._read_dicts(
            "SELECT COUNT(*) as cnt FROM pipeline_stats WHERE status = 'completed'"
        )
        pipelines_failed = self._read_dicts(
            "SELECT COUNT(*) as cnt FROM pipeline_stats WHERE status = 'failed'"
        )
        avg_pipeline_dur = self._read_dicts(
            "SELECT AVG(duration_ms) as avg_ms FROM pipeline_stats WHERE status = 'completed' AND duration_ms IS NOT NULL"
        )
        total_alerts = self._read_dicts(
            "SELECT COUNT(*) as cnt FROM alert_log"
        )
        resolved_alerts = self._read_dicts(
            "SELECT COUNT(*) as cnt FROM alert_log WHERE resolved = 1"
        )
        latest_pipeline = self._read_dicts(
            "SELECT started_at FROM pipeline_stats ORDER BY started_at DESC LIMIT 1"
        )
        latest_compliance = self._read_dicts(
            "SELECT snapshot_at FROM compliance_snapshots ORDER BY snapshot_at DESC LIMIT 1"
        )
        models_in_production = self._read_dicts(
            """SELECT COUNT(DISTINCT model_id) as cnt FROM model_snapshots WHERE status = 'production'"""
        )
        models_with_findings = self._read_dicts(
            """SELECT COUNT(DISTINCT model_id) as cnt FROM model_snapshots WHERE finding_count > 0"""
        )
        di_confirmed = self._read_dicts(
            "SELECT COUNT(*) as cnt FROM fairness_snapshots WHERE has_disparate_impact = 1 AND statistically_significant = 1"
        )
        tenants_below_c = self._read_dicts(
            """SELECT COUNT(*) as cnt FROM (
                SELECT score FROM compliance_snapshots
                GROUP BY tenant_id
                HAVING snapshot_at = MAX(snapshot_at) AND score < 60
            )"""
        )

        table_names = [
            "tenants", "compliance_snapshots", "model_snapshots",
            "fairness_snapshots", "certification_snapshots", "alert_log",
            "pipeline_stats", "system_metrics",
        ]
        table_row_counts = {}
        total_rows = 0
        for tbl in table_names:
            row = self._read_dicts(f"SELECT COUNT(*) as cnt FROM {tbl}")
            cnt = row[0]["cnt"] if row else 0
            table_row_counts[tbl] = cnt
            total_rows += cnt

        p_total = pipelines_total[0]["cnt"] if pipelines_total else 0
        p_completed = pipelines_completed[0]["cnt"] if pipelines_completed else 0
        p_failed = pipelines_failed[0]["cnt"] if pipelines_failed else 0
        t_alerts = total_alerts[0]["cnt"] if total_alerts else 0
        r_alerts = resolved_alerts[0]["cnt"] if resolved_alerts else 0
        avg_dur = avg_pipeline_dur[0]["avg_ms"] if avg_pipeline_dur and avg_pipeline_dur[0]["avg_ms"] else None

        return {
            "tenant_count": tenants[0]["cnt"] if tenants else 0,
            "total_models": models[0]["cnt"] if models else 0,
            "open_alerts": alerts[0]["cnt"] if alerts else 0,
            "pipelines_24h": pipelines[0]["cnt"] if pipelines else 0,
            "avg_compliance_score": round(avg_score, 1) if avg_score else None,
            "critical_alerts": critical_alerts[0]["cnt"] if critical_alerts else 0,
            "pipelines_total": p_total,
            "pipeline_success_rate": round(p_completed / max(p_total, 1) * 100, 1),
            "pipeline_failure_rate": round(p_failed / max(p_total, 1) * 100, 1),
            "avg_pipeline_duration_ms": round(avg_dur, 1) if avg_dur else None,
            "total_alerts": t_alerts,
            "resolved_alerts": r_alerts,
            "alert_resolution_rate": round(r_alerts / max(t_alerts, 1) * 100, 1),
            "table_row_counts": table_row_counts,
            "total_rows": total_rows,
            "latest_pipeline_at": latest_pipeline[0]["started_at"] if latest_pipeline else None,
            "latest_compliance_at": latest_compliance[0]["snapshot_at"] if latest_compliance else None,
            "models_in_production": models_in_production[0]["cnt"] if models_in_production else 0,
            "models_with_findings": models_with_findings[0]["cnt"] if models_with_findings else 0,
            "di_confirmed_count": di_confirmed[0]["cnt"] if di_confirmed else 0,
            "tenants_below_c": tenants_below_c[0]["cnt"] if tenants_below_c else 0,
        }

    def get_all_models_platform(self) -> List[Dict[str, Any]]:
        return self._read_dicts("""
            SELECT ms.model_id, ms.tenant_id, ms.name, ms.version, ms.tier,
                   ms.status, ms.domain, ms.owner, ms.compliance_score,
                   ms.last_validated, ms.last_monitored,
                   ms.validation_overdue, ms.monitoring_overdue,
                   ms.finding_count, ms.snapshot_at,
                   t.name as tenant_name
            FROM model_snapshots ms
            JOIN tenants t ON ms.tenant_id = t.tenant_id
            WHERE t.active = 1
            GROUP BY ms.tenant_id, ms.model_id
            HAVING ms.snapshot_at = MAX(ms.snapshot_at)
            ORDER BY ms.tenant_id, ms.model_id
        """)

    def get_all_fairness_platform(self) -> List[Dict[str, Any]]:
        return self._read_dicts("""
            SELECT fs.*, t.name as tenant_name
            FROM fairness_snapshots fs
            JOIN tenants t ON fs.tenant_id = t.tenant_id
            WHERE t.active = 1
            GROUP BY fs.tenant_id, fs.model_id
            HAVING fs.snapshot_at = MAX(fs.snapshot_at)
            ORDER BY fs.has_disparate_impact DESC, fs.worst_ratio ASC
        """)

    def get_compliance_platform(self) -> Dict[str, Any]:
        tenant_scores = self._read_dicts("""
            SELECT cs.tenant_id, t.name as tenant_name, t.tier,
                   cs.score, cs.grade, cs.critical_findings, cs.warning_findings,
                   cs.trend, cs.breakdowns, cs.top_risks, cs.snapshot_at
            FROM compliance_snapshots cs
            JOIN tenants t ON cs.tenant_id = t.tenant_id
            WHERE t.active = 1
            GROUP BY cs.tenant_id
            HAVING cs.snapshot_at = MAX(cs.snapshot_at)
            ORDER BY cs.score ASC
        """)
        scores = [t["score"] for t in tenant_scores if t["score"] is not None]
        return {
            "tenants": tenant_scores,
            "avg_score": round(sum(scores) / len(scores), 1) if scores else None,
            "min_score": min(scores) if scores else None,
            "max_score": max(scores) if scores else None,
            "grade_distribution": {
                "A": len([s for s in scores if s >= 90]),
                "B": len([s for s in scores if 75 <= s < 90]),
                "C": len([s for s in scores if 60 <= s < 75]),
                "D": len([s for s in scores if s < 60]),
            },
        }

    def get_pipeline_summary(self) -> Dict[str, Any]:
        total = self._read_dicts("SELECT COUNT(*) as cnt FROM pipeline_stats")[0]["cnt"]
        completed = self._read_dicts("SELECT COUNT(*) as cnt FROM pipeline_stats WHERE status = 'completed'")[0]["cnt"]
        failed = self._read_dicts("SELECT COUNT(*) as cnt FROM pipeline_stats WHERE status = 'failed'")[0]["cnt"]
        avg_duration = self._read_dicts(
            "SELECT AVG(duration_ms) as avg_ms FROM pipeline_stats WHERE status = 'completed' AND duration_ms IS NOT NULL"
        )
        by_tenant = self._read_dicts("""
            SELECT ps.tenant_id, t.name as tenant_name,
                   COUNT(*) as total_runs,
                   SUM(CASE WHEN ps.status = 'completed' THEN 1 ELSE 0 END) as completed,
                   SUM(CASE WHEN ps.status = 'failed' THEN 1 ELSE 0 END) as failed,
                   ROUND(AVG(CASE WHEN ps.status = 'completed' THEN ps.duration_ms END), 0) as avg_duration_ms,
                   SUM(ps.node_count) as total_nodes,
                   SUM(ps.edge_count) as total_edges
            FROM pipeline_stats ps
            JOIN tenants t ON ps.tenant_id = t.tenant_id
            GROUP BY ps.tenant_id
            ORDER BY total_runs DESC
        """)
        by_pipeline = self._read_dicts("""
            SELECT pipeline_name,
                   COUNT(*) as run_count,
                   SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                   SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                   ROUND(AVG(CASE WHEN status = 'completed' THEN duration_ms END), 0) as avg_duration_ms
            FROM pipeline_stats
            GROUP BY pipeline_name
            ORDER BY run_count DESC
        """)
        return {
            "total_runs": total,
            "completed": completed,
            "failed": failed,
            "success_rate": round(completed / max(total, 1) * 100, 1),
            "avg_duration_ms": round(avg_duration[0]["avg_ms"], 1) if avg_duration and avg_duration[0]["avg_ms"] else None,
            "by_tenant": by_tenant,
            "by_pipeline": by_pipeline,
        }

    # -- User management (authentication) ------------------------------------

    def get_user_by_email(self, tenant_id: str, email: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            """SELECT id, tenant_id, email, password_hash, display_name, role,
                      active, invited_by, last_login_at, created_at
               FROM dashboard_users
               WHERE tenant_id = ? AND email = ? AND active = 1""",
            (tenant_id, email),
        )
        return rows[0] if rows else None

    def get_users(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT id, tenant_id, email, display_name, role,
                      active, invited_by, last_login_at, created_at
               FROM dashboard_users
               WHERE tenant_id = ?
               ORDER BY role, email""",
            (tenant_id,),
        )

    def create_user(self, tenant_id: str, email: str, password_hash: str,
                    display_name: str, role: str = "analyst",
                    invited_by: str = None) -> Optional[int]:
        try:
            params = tuple(_adapt(p) for p in (
                tenant_id, email, password_hash, display_name, role, invited_by,
            ))
            cur = self._conn.execute(
                """INSERT INTO dashboard_users
                   (tenant_id, email, password_hash, display_name, role, invited_by)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                params,
            )
            self._conn.commit()
            return cur.lastrowid
        except sqlite3.IntegrityError:
            logger.warning("User %s already exists for tenant %s", email, tenant_id)
            return None

    def update_user_role(self, tenant_id: str, user_id: int, role: str) -> bool:
        self._write(
            """UPDATE dashboard_users SET role = ?,
               updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
               WHERE id = ? AND tenant_id = ?""",
            (role, user_id, tenant_id),
        )
        return True

    def deactivate_user(self, tenant_id: str, user_id: int) -> bool:
        self._write(
            """UPDATE dashboard_users SET active = 0,
               updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
               WHERE id = ? AND tenant_id = ?""",
            (user_id, tenant_id),
        )
        return True

    def reactivate_user(self, tenant_id: str, user_id: int) -> bool:
        self._write(
            """UPDATE dashboard_users SET active = 1,
               updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
               WHERE id = ? AND tenant_id = ?""",
            (user_id, tenant_id),
        )
        return True

    def record_login(self, tenant_id: str, email: str) -> None:
        self._write(
            """UPDATE dashboard_users
               SET last_login_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
               WHERE tenant_id = ? AND email = ?""",
            (tenant_id, email),
        )

    def update_user_password(self, tenant_id: str, user_id: int,
                             password_hash: str) -> bool:
        self._write(
            """UPDATE dashboard_users SET password_hash = ?,
               updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
               WHERE id = ? AND tenant_id = ?""",
            (password_hash, user_id, tenant_id),
        )
        return True

    def count_users(self, tenant_id: str) -> int:
        rows = self._read_dicts(
            "SELECT COUNT(*) as cnt FROM dashboard_users WHERE tenant_id = ? AND active = 1",
            (tenant_id,),
        )
        return rows[0]["cnt"] if rows else 0
