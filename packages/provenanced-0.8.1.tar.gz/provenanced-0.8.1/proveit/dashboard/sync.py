"""
DashboardSync: One-line integration between ProveIt modules and the dashboard store.

This is the glue that makes backend integration trivial. After running your
normal ProveIt compliance pipeline, call `sync.push()` and everything appears
in the dashboards automatically.

Usage::

    from proveit.dashboard.sync import DashboardSync

    # Option 1: Full pipeline sync (most common)
    sync = DashboardSync(store, tenant_id="first_national")
    sync.push(
        compliance_result=scorer_result,     # ComplianceScoreResult
        model_registry=registry,             # ModelRegistry
        fairness_results=fairness_reports,   # List[DisparateImpactResult]
        certifications=cert_tracker,         # CertificationTracker
    )

    # Option 2: Sync individual components
    sync.push_compliance(scorer_result)
    sync.push_models(registry)
    sync.push_fairness("model_id", di_result)
    sync.push_alert(severity="critical", source="FairLens", title="DI detected")

    # Option 3: Auto-sync with context manager
    with DashboardSync.auto(store, "first_national") as sync:
        # ... run your pipeline ...
        sync.push_compliance(result)
        # On exit, pipeline stats are automatically recorded
"""

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class DashboardSync:
    """Sync ProveIt pipeline results to the dashboard data store.

    Designed for minimal integration effort: pass your existing ProveIt
    objects and DashboardSync handles the data transformation and writes.

    Works with both Aurora PostgreSQL (production) and the demo store.
    """

    def __init__(self, store, tenant_id: str):
        """
        Args:
            store: A DashboardStore instance (connected).
            tenant_id: Tenant identifier for this sync session.
        """
        self.store = store
        self.tenant_id = tenant_id
        self._pipeline_start = None
        self._pipeline_name = None
        self._node_count = 0
        self._edge_count = 0

    # -------------------------------------------------------------------
    # Full pipeline push
    # -------------------------------------------------------------------

    def push(
        self,
        compliance_result=None,
        model_registry=None,
        fairness_results: Optional[List] = None,
        certifications=None,
        exception_tracker=None,
    ) -> Dict[str, int]:
        """Push all available data to the dashboard store in one call.

        Pass any combination of ProveIt objects -- only non-None items
        are synced. Returns a dict of counts for each synced category.

        Args:
            compliance_result: A ComplianceScoreResult from ComplianceScorer.
            model_registry: A ModelRegistry instance.
            fairness_results: List of (model_id, DisparateImpactResult) tuples
                              or DisparateImpactResult objects with model_id attr.
            certifications: A CertificationTracker instance.
            exception_tracker: An ExceptionTracker instance (optional).

        Returns:
            Dict with keys like {"compliance": 1, "models": 4, "fairness": 2, ...}
        """
        counts = {}

        if compliance_result is not None:
            self.push_compliance(compliance_result)
            counts["compliance"] = 1

        if model_registry is not None:
            n = self.push_models(model_registry)
            counts["models"] = n
            reval_count = self.push_revalidation_alerts(model_registry)
            if reval_count:
                counts["revalidation_alerts"] = reval_count

        if fairness_results is not None:
            for item in fairness_results:
                if isinstance(item, tuple):
                    model_id, result = item
                    self.push_fairness(model_id, result)
                elif hasattr(item, "model_id"):
                    self.push_fairness(item.model_id, item)
            counts["fairness"] = len(fairness_results)

        if certifications is not None:
            n = self.push_certifications(certifications)
            counts["certifications"] = n

        if exception_tracker is not None:
            n = self.push_exception_alerts(exception_tracker)
            if n:
                counts["exception_alerts"] = n

        logger.info(
            "DashboardSync.push complete for tenant=%s: %s",
            self.tenant_id, counts,
        )
        return counts

    # -------------------------------------------------------------------
    # Individual component pushes
    # -------------------------------------------------------------------

    def push_compliance(self, result) -> None:
        """Push a ComplianceScoreResult to the dashboard store."""
        data = result.to_dict() if hasattr(result, "to_dict") else result
        self.store.insert_compliance_snapshot(self.tenant_id, data)

    def push_models(self, registry) -> int:
        """Push all models from a ModelRegistry to the dashboard store.

        Returns the number of models synced.
        """
        count = 0
        for record in registry._models.values():
            model_data = {
                "model_id": record.model_id,
                "name": record.name,
                "version": record.version,
                "tier": record.tier if isinstance(record.tier, int) else record.tier.value,
                "status": record.status.value if hasattr(record.status, "value") else record.status,
                "domain": record.domain,
                "owner": record.owner,
                "compliance_score": getattr(record, "compliance_score", None),
                "last_validated": getattr(record, "last_validated", None),
                "last_monitored": getattr(record, "last_monitored", None),
                "validation_overdue": getattr(record, "validation_overdue", False),
                "monitoring_overdue": getattr(record, "monitoring_overdue", False),
                "finding_count": getattr(record, "finding_count", 0),
            }
            self.store.upsert_model_snapshot(self.tenant_id, model_data)
            count += 1
        return count

    def push_fairness(self, model_id: str, result) -> None:
        """Push a DisparateImpactResult to the dashboard store."""
        if hasattr(result, "to_dict"):
            d = result.to_dict()
        else:
            d = result if isinstance(result, dict) else {}

        worst_ratio = d.get("worst_ratio")
        if worst_ratio is not None:
            worst_ratio = float(worst_ratio)

        data = {
            "model_id": model_id,
            "has_disparate_impact": bool(d.get("has_disparate_impact", False)),
            "worst_ratio": worst_ratio,
            "worst_group": d.get("worst_group"),
            "p_value": None,
            "statistically_significant": False,
            "protected_attributes": d.get("protected_attributes", []),
            "sample_size_warnings": d.get("sample_size_warnings", []),
            "details": d,
        }

        # Extract p-value from per-attribute results
        if "p_values" in d and d["p_values"]:
            p_vals = list(d["p_values"].values()) if isinstance(d["p_values"], dict) else d["p_values"]
            if p_vals:
                data["p_value"] = min(p_vals)
        if "statistically_significant" in d:
            sig = d["statistically_significant"]
            if isinstance(sig, dict):
                data["statistically_significant"] = any(sig.values())
            else:
                data["statistically_significant"] = bool(sig)

        self.store.insert_fairness_snapshot(self.tenant_id, data)

    def push_certifications(self, tracker) -> int:
        """Push certifications from a CertificationTracker."""
        count = 0
        for cert in tracker._certifications:
            cert_data = {
                "cert_type": cert.name,
                "status": cert.status.value,
                "issued_date": cert.issue_date.isoformat() if cert.issue_date else None,
                "expiry_date": cert.expiration_date.isoformat() if cert.expiration_date else None,
                "days_until_expiry": cert.days_until_expiration,
            }
            self.store.upsert_certification(self.tenant_id, cert_data)
            count += 1
        return count

    def push_alert(
        self,
        severity: str,
        source: str,
        title: str,
        description: str = "",
        model_id: Optional[str] = None,
        regulation: Optional[str] = None,
    ) -> int:
        """Push a single alert to the dashboard store.

        Returns the alert ID.
        """
        return self.store.insert_alert(self.tenant_id, {
            "severity": severity,
            "source": source,
            "title": title,
            "description": description,
            "model_id": model_id,
            "regulation": regulation,
        })

    # -------------------------------------------------------------------
    # CRO Feature Pushes
    # -------------------------------------------------------------------

    def push_revalidation_alerts(self, registry) -> int:
        """Push revalidation-needed alerts from a ModelRegistry.

        Checks which models need revalidation and creates alerts in the
        dashboard store for each one.

        Returns the number of alerts pushed.
        """
        flagged = registry.revalidation_needed()
        count = 0
        for item in flagged:
            reasons = "; ".join(item.get("reasons", []))
            self.push_alert(
                severity="critical" if item.get("priority") == "urgent" else "warning",
                source="ModelRegistry",
                title=f"Revalidation needed: {item.get('name', item['model_id'])}",
                description=reasons,
                model_id=item["model_id"],
                regulation="SR 11-7 / OCC 2011-12",
            )
            count += 1
        return count

    def push_exception_alerts(self, exception_tracker) -> int:
        """Push escalation alerts from an ExceptionTracker.

        Checks for expiring/expired exceptions and creates alerts.

        Returns the number of alerts pushed.
        """
        escalations = exception_tracker.check_escalations()
        count = 0
        for esc in escalations:
            severity = "critical" if esc.level.value in ("expired", "critical") else "warning"
            self.push_alert(
                severity=severity,
                source="ExceptionTracker",
                title=f"Exception escalation: {esc.model_id}",
                description=esc.message,
                model_id=esc.model_id,
                regulation=esc.regulation,
            )
            count += 1
        return count

    # -------------------------------------------------------------------
    # Automated alert generation from results
    # -------------------------------------------------------------------

    def push_compliance_alerts(self, result) -> int:
        """Generate alerts from compliance results.

        Creates critical/warning alerts for failing regulations and
        an info alert when the score changes significantly.

        Returns the number of alerts pushed.
        """
        data = result.to_dict() if hasattr(result, "to_dict") else result
        count = 0

        breakdowns = data.get("breakdowns", [])
        for bd in breakdowns:
            if isinstance(bd, dict):
                reg = bd.get("regulation", "Unknown")
                crits = bd.get("critical_count", 0)
                warns = bd.get("warning_count", 0)
                passed = bd.get("passed", True)
            else:
                reg = getattr(bd, "regulation", "Unknown")
                crits = getattr(bd, "critical_count", 0)
                warns = getattr(bd, "warning_count", 0)
                passed = getattr(bd, "passed", True)

            if not passed and crits > 0:
                self.push_alert(
                    severity="critical",
                    source="ComplianceScorer",
                    title=f"Critical compliance failure: {reg}",
                    description=f"{crits} critical and {warns} warning findings for {reg}.",
                    regulation=reg,
                )
                count += 1
            elif warns > 0:
                self.push_alert(
                    severity="warning",
                    source="ComplianceScorer",
                    title=f"Compliance warnings in {reg}",
                    description=f"{warns} warning finding(s) for {reg}.",
                    regulation=reg,
                )
                count += 1

        return count

    def push_fairness_alerts(self, model_id: str, result) -> int:
        """Generate alerts from fairness analysis results.

        Creates critical alerts for statistically significant DI
        and warning alerts for borderline results.

        Returns the number of alerts pushed.
        """
        if hasattr(result, "to_dict"):
            d = result.to_dict()
        else:
            d = result if isinstance(result, dict) else {}

        count = 0
        has_di = d.get("has_disparate_impact", False)
        worst_ratio = d.get("worst_ratio")
        worst_group = d.get("worst_group", "unknown")

        stat_sig = d.get("statistically_significant", False)
        if isinstance(stat_sig, dict):
            stat_sig = any(stat_sig.values())

        p_value = None
        if "p_values" in d and d["p_values"]:
            p_vals = list(d["p_values"].values()) if isinstance(d["p_values"], dict) else d["p_values"]
            if p_vals:
                p_value = min(p_vals)

        if has_di and stat_sig:
            desc = f"Selection rate ratio {worst_ratio:.2f} for {worst_group}"
            if p_value is not None:
                desc += f" (p={p_value:.3f})"
            desc += ". Below 0.80 four-fifths threshold."
            self.push_alert(
                severity="critical",
                source="FairLens",
                title=f"Disparate impact detected in {model_id}",
                description=desc,
                model_id=model_id,
                regulation="ECOA / Reg B",
            )
            count += 1
        elif has_di:
            self.push_alert(
                severity="warning",
                source="FairLens",
                title=f"Borderline disparate impact in {model_id}",
                description=f"Selection rate ratio {worst_ratio:.2f} for {worst_group}. Not statistically significant but warrants monitoring.",
                model_id=model_id,
                regulation="ECOA / Reg B",
            )
            count += 1

        return count

    # -------------------------------------------------------------------
    # Pipeline tracking (for admin dashboard metrics)
    # -------------------------------------------------------------------

    def start_pipeline(self, name: str) -> None:
        """Mark the start of a pipeline run."""
        self._pipeline_start = time.monotonic()
        self._pipeline_name = name
        self._node_count = 0
        self._edge_count = 0

    def record_dag_stats(self, node_count: int, edge_count: int) -> None:
        """Record DAG node/edge counts for pipeline stats."""
        self._node_count = node_count
        self._edge_count = edge_count

    def end_pipeline(self, status: str = "completed") -> None:
        """Record pipeline completion with stats."""
        duration = None
        if self._pipeline_start is not None:
            duration = int((time.monotonic() - self._pipeline_start) * 1000)

        self.store.insert_pipeline_stat(self.tenant_id, {
            "pipeline_name": self._pipeline_name,
            "status": status,
            "node_count": self._node_count,
            "edge_count": self._edge_count,
            "duration_ms": duration,
            "completed_at": datetime.now(timezone.utc).isoformat(),
        })

    # -------------------------------------------------------------------
    # Context manager for auto pipeline tracking
    # -------------------------------------------------------------------

    class _AutoContext:
        """Context manager that auto-records pipeline stats."""

        def __init__(self, sync: "DashboardSync", pipeline_name: str):
            self._sync = sync
            self._name = pipeline_name

        def __enter__(self):
            self._sync.start_pipeline(self._name)
            return self._sync

        def __exit__(self, exc_type, exc_val, exc_tb):
            status = "completed" if exc_type is None else "failed"
            self._sync.end_pipeline(status)
            return False

    @classmethod
    def auto(cls, store, tenant_id: str, pipeline_name: str = "default"):
        """Create a context manager that auto-tracks pipeline execution.

        Usage::

            with DashboardSync.auto(store, "tenant_id", "credit_scoring") as sync:
                sync.push_compliance(result)
                sync.record_dag_stats(142, 287)
                # Pipeline stats auto-recorded on exit
        """
        instance = cls(store, tenant_id)
        return cls._AutoContext(instance, pipeline_name)
