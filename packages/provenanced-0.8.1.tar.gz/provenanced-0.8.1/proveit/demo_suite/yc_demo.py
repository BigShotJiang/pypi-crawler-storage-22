#!/usr/bin/env python3
"""
ProveIt YC Application Demo
============================

Full end-to-end demonstration of ProveIt's compliance automation platform.
Runs in ~30 seconds. Designed for a 1-minute YC demo video screencast.

What this demo shows:
    1. Synthetic credit scoring model (sklearn) with intentional bias
    2. HYDRA-24 provenance tracking on the data pipeline
    3. FairLens fairness analysis (DI, proxy detection, adverse action)
    4. 5-engine compliance check (ECOA, SR 11-7, EU AI Act, Colorado, NYC)
    5. Board-reportable compliance score (0-100)
    6. One-click examiner package generation
    7. PII detection and data governance
    8. Model card auto-generation

Run:
    python -m proveit.demo_suite.yc_demo

For YC video: run in terminal with a dark theme, 14pt font.
"""

import json
import sys
import time
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split

# ------------------------------------------------------------------
# Pretty printing helpers
# ------------------------------------------------------------------

_BOLD = "\033[1m"
_GREEN = "\033[92m"
_RED = "\033[91m"
_YELLOW = "\033[93m"
_BLUE = "\033[94m"
_CYAN = "\033[96m"
_DIM = "\033[2m"
_RESET = "\033[0m"


def _header(text: str) -> None:
    width = 60
    print()
    print(f"{_BOLD}{_CYAN}{'=' * width}{_RESET}")
    print(f"{_BOLD}{_CYAN}  {text}{_RESET}")
    print(f"{_BOLD}{_CYAN}{'=' * width}{_RESET}")
    print()


def _step(num: int, text: str) -> None:
    print(f"{_BOLD}{_BLUE}[Step {num}]{_RESET} {text}")


def _ok(text: str) -> None:
    print(f"  {_GREEN}✓{_RESET} {text}")


def _warn(text: str) -> None:
    print(f"  {_YELLOW}!{_RESET} {text}")


def _fail(text: str) -> None:
    print(f"  {_RED}✗{_RESET} {text}")


def _info(text: str) -> None:
    print(f"  {_DIM}{text}{_RESET}")


def _metric(label: str, value, good: bool = True) -> None:
    color = _GREEN if good else _RED
    print(f"  {label}: {color}{value}{_RESET}")


# ------------------------------------------------------------------
# 1. Generate synthetic credit data with hidden bias
# ------------------------------------------------------------------

def generate_credit_data(n: int = 2000, seed: int = 42) -> pd.DataFrame:
    """Generate synthetic credit application data with realistic bias.

    The bias is embedded via zip_code → race correlation, mimicking
    real-world redlining patterns that violate ECOA.
    """
    rng = np.random.RandomState(seed)

    data = {
        "applicant_id": [f"APP-{i:05d}" for i in range(n)],
        "income": rng.lognormal(10.8, 0.6, n).astype(int),
        "debt_to_income": rng.uniform(0.05, 0.65, n).round(2),
        "credit_score": rng.normal(680, 80, n).astype(int).clip(300, 850),
        "employment_years": rng.exponential(5, n).round(1).clip(0, 40),
        "loan_amount": rng.lognormal(11.5, 0.5, n).astype(int),
        "zip_code": rng.choice(
            ["10001", "10002", "10003", "10004", "10005",
             "60601", "60602", "60603", "60604", "60605"],
            n,
        ),
    }

    # Race distribution correlated with zip code (redlining proxy)
    race_map = {
        "10001": ["White"] * 7 + ["Black"] * 1 + ["Hispanic"] * 1 + ["Asian"] * 1,
        "10002": ["White"] * 7 + ["Black"] * 1 + ["Hispanic"] * 1 + ["Asian"] * 1,
        "10003": ["Black"] * 6 + ["Hispanic"] * 2 + ["White"] * 1 + ["Asian"] * 1,
        "10004": ["Black"] * 6 + ["Hispanic"] * 2 + ["White"] * 1 + ["Asian"] * 1,
        "10005": ["Hispanic"] * 5 + ["Black"] * 3 + ["White"] * 1 + ["Asian"] * 1,
        "60601": ["White"] * 8 + ["Asian"] * 1 + ["Black"] * 1,
        "60602": ["White"] * 8 + ["Asian"] * 1 + ["Hispanic"] * 1,
        "60603": ["Black"] * 5 + ["Hispanic"] * 3 + ["White"] * 1 + ["Asian"] * 1,
        "60604": ["Hispanic"] * 6 + ["Black"] * 2 + ["White"] * 1 + ["Asian"] * 1,
        "60605": ["White"] * 6 + ["Asian"] * 2 + ["Black"] * 1 + ["Hispanic"] * 1,
    }
    data["race"] = [rng.choice(race_map[z]) for z in data["zip_code"]]
    data["sex"] = rng.choice(["M", "F"], n)
    data["age"] = rng.normal(42, 12, n).astype(int).clip(21, 75)
    data["ssn_last4"] = [f"{rng.randint(1000, 9999)}" for _ in range(n)]
    data["email"] = [f"applicant{i}@example.com" for i in range(n)]

    df = pd.DataFrame(data)

    # Approval decision: biased by zip_code (proxy for race)
    # This is the exact pattern ECOA is designed to catch
    zip_bias = df["zip_code"].map({
        "10001": 0.15, "10002": 0.15, "10003": -0.20, "10004": -0.20,
        "10005": -0.15, "60601": 0.15, "60602": 0.15, "60603": -0.20,
        "60604": -0.15, "60605": 0.10,
    })
    approval_score = (
        0.3 * (df["credit_score"] - 300) / 550
        + 0.25 * (1 - df["debt_to_income"])
        + 0.15 * np.log1p(df["income"]) / 15
        + 0.1 * df["employment_years"] / 40
        + zip_bias
        + rng.normal(0, 0.08, n)
    )
    df["approved"] = (approval_score > 0.45).astype(int)

    return df


# ------------------------------------------------------------------
# 2. Train a model
# ------------------------------------------------------------------

def train_model(df: pd.DataFrame):
    """Train a GradientBoosting credit model (intentionally using zip_code)."""
    feature_cols = [
        "income", "debt_to_income", "credit_score",
        "employment_years", "loan_amount", "zip_code",
    ]
    X = df[feature_cols].copy()
    X["zip_code"] = X["zip_code"].astype("category").cat.codes
    y = df["approved"].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42,
    )
    model = GradientBoostingClassifier(
        n_estimators=100, max_depth=4, random_state=42,
    )
    model.fit(X_train, y_train)

    return model, X_train, X_test, y_train, y_test, feature_cols


# ------------------------------------------------------------------
# Main demo flow
# ------------------------------------------------------------------

def run_demo() -> None:
    """Run the full ProveIt demo."""
    start = time.time()

    _header("ProveIt — AI Compliance Demo for Banks")
    print(f"  {_DIM}Cryptographically provable compliance automation{_RESET}")
    print(f"  {_DIM}7 engines | 80+ regulatory checks | 1,200+ tests{_RESET}")
    print()

    # ---- Step 1: Data ----
    _step(1, "Generating synthetic credit application data...")
    df = generate_credit_data(2000)
    _ok(f"{len(df):,} applications generated")
    _info(f"Features: income, DTI, credit score, employment, zip code")
    _info(f"Protected: race, sex, age")
    approval_rate = df["approved"].mean()
    _metric("Overall approval rate", f"{approval_rate:.1%}", True)

    # ---- Step 2: HYDRA-24 Provenance ----
    _step(2, "Instrumenting pipeline with HYDRA-24 provenance tracking...")
    from proveit import DAGTracker, wrap_dataframe, get_dag
    tracker = DAGTracker()
    tracked_df = wrap_dataframe(df.drop(columns=["applicant_id", "ssn_last4", "email"]), tracker, "applications.csv")
    ratio = tracked_df["income"] / tracked_df["loan_amount"]
    _ok("Every value tagged with 24-bit provenance (3 bytes overhead)")
    dag = get_dag(ratio)
    _ok(f"DAG captured: {len(dag.nodes)} nodes, {len(dag.edges)} edges")

    # ---- Step 3: Train Model ----
    _step(3, "Training credit scoring model (GradientBoosting)...")
    model, X_train, X_test, y_train, y_test, feature_cols = train_model(df)
    accuracy = model.score(X_test, y_test)
    _ok(f"Model trained — accuracy: {accuracy:.1%}")

    # ---- Step 4: FairLens Analysis ----
    _step(4, "Running FairLens algorithmic fairness analysis...")
    from proveit.fairness import FairLensEngine, FairLensConfig

    protected_df = df.loc[X_test.index, ["race", "sex"]].reset_index(drop=True)
    X_test_reset = X_test.reset_index(drop=True)
    X_train_reset = X_train.reset_index(drop=True)

    config = FairLensConfig(
        protected_columns=["race", "sex"],
        run_lda_search=False,  # Skip for speed in demo
    )
    engine = FairLensEngine(config)
    report = engine.analyze(
        model=model,
        X_train=X_train_reset,
        y_train=y_train,
        X_test=X_test_reset,
        y_test=y_test,
        protected_data=protected_df,
        model_name="credit_score_v1",
        model_version="1.0.0",
    )

    di_detected = report.summary.get("disparate_impact_detected", False)
    proxy_count = report.summary.get("proxy_features_detected", 0)
    inter_detected = report.summary.get("intersectional_di_detected", False)

    if di_detected:
        _fail(f"DISPARATE IMPACT DETECTED")
        for di in report.disparate_impact_results:
            if di.has_disparate_impact:
                _fail(
                    f"  {di.protected_attribute}: ratio {di.worst_ratio:.2f} "
                    f"(below 0.80 threshold)"
                )
    else:
        _ok("No disparate impact detected")

    if proxy_count > 0:
        _warn(f"{proxy_count} proxy variable(s) detected")
        for p in report.proxy_results[:3]:
            _warn(f"  {p.feature_name} → {p.protected_attribute} (r={p.correlation:.2f})")

    if inter_detected:
        _fail("Intersectional disparate impact detected (race x sex)")

    _metric("Model hash (SHA-256)", report.model_identity.model_hash[:16] + "...", True)
    _metric("Explanation method", report.summary.get("explanation_method", "none"), True)

    # ---- Step 5: Compliance Engines ----
    _step(5, "Running 5 compliance engines (80+ checks)...")
    from proveit.compliance import (
        ComplianceReport,
        ECOAEngine,
        SR117Engine,
        EUAIActEngine,
        ColoradoAIActEngine,
        NYCLL144Engine,
    )

    metadata = {
        "model_type": "gradient_boosting",
        "domain": "lending",
        "is_adverse_action": True,
        "adverse_action_reasons": [
            "High debt-to-income ratio",
            "Insufficient employment history",
            "Low credit score",
        ],
        "record_retention_months": 60,
        "risk_tier": "high",
        "model_validation_date": "2026-01-15",
        "monitoring_plan": "Quarterly FairLens re-analysis",
        "model_owner": "Model Risk Management",
        "model_id": "credit_score_v1",
        "model_version": "1.0.0",
        "model_tier": "high",
        "model_purpose": "Consumer credit underwriting",
        "has_validation": True,
        "has_monitoring": True,
        "has_documentation": True,
        "independent_validation": True,
        "independent_validator": "Internal Model Validation Group",
        "challenger_model": True,
        "challenger_model_type": "Logistic Regression baseline",
        "use_limitations": "Not for HELOC or commercial lending",
        "concentration_risk_assessed": True,
        "vendor_model": False,
        "governance_framework": True,
        "documentation_completeness": 0.85,
        "disparate_impact_analysis": {
            "race": 0.72 if di_detected else 0.85,
            "sex": 0.88,
        },
        "intersectional_impact_analysis": [
            {
                "attribute_pair": ["race", "sex"],
                "worst_ratio": 0.65 if inter_detected else 0.85,
            },
        ],
        "hmda_reportable": True,
        "collected_demographics": ["race", "ethnicity", "sex"],
        "monitoring_purpose_disclosed": True,
        "explanation_method": "feature_importances",
        "explanation_confidence": 0.82,
        # EU AI Act
        "risk_classification": "high",
        "human_oversight": True,
        "human_oversight_measures": "Senior underwriter reviews all denials above $100K",
        "technical_documentation": True,
        "conformity_assessment": False,
        "data_governance_measures": True,
        # Colorado
        "deployer_type": "deployer",
        "impact_assessment_date": "2026-01-01",
        "impact_assessment_summary": "Annual impact assessment completed.",
        "consumer_notice_provided": True,
        # NYC LL144
        "bias_audit_date": "2025-12-01",
        "bias_audit_independent_auditor": "FairAudit Inc.",
        "bias_audit_summary_published": True,
        "candidate_notice_provided": True,
        "selection_rate_disclosure": {"race": 0.72, "sex": 0.88},
    }

    comp_report = ComplianceReport()
    engines = [
        ECOAEngine(),
        SR117Engine(),
        EUAIActEngine(),
        ColoradoAIActEngine(),
        NYCLL144Engine(),
    ]
    comp_report.run_engines(engines, dag, metadata)

    for result in comp_report.results:
        status = f"{_GREEN}PASS{_RESET}" if result.passed else f"{_RED}FAIL{_RESET}"
        print(
            f"  {result.regulation_name}: {status} "
            f"({result.critical_count}C / {result.warning_count}W / {result.info_count}I)"
        )

    # ---- Step 6: Compliance Score ----
    _step(6, "Calculating board-reportable compliance score...")
    from proveit.compliance.score import ComplianceScorer

    scorer = ComplianceScorer()
    score_result = scorer.score(
        comp_report,
        proactive_controls={
            "has_certifications": False,
            "has_monitoring": True,
            "has_fairness_analysis": True,
            "has_decision_logging": True,
            "has_data_governance": True,
            "has_model_inventory": True,
        },
    )
    grade_color = _GREEN if score_result.grade in ("A", "B") else _YELLOW if score_result.grade == "C" else _RED
    print(f"\n  {_BOLD}COMPLIANCE SCORE: {grade_color}{score_result.score:.0f}/100 (Grade: {score_result.grade}){_RESET}")
    if score_result.top_risks:
        print(f"\n  {_BOLD}Top Risks:{_RESET}")
        for risk in score_result.top_risks[:3]:
            _fail(risk[:80])

    # ---- Step 7: PII Detection ----
    _step(7, "Scanning for PII and data classification...")
    from proveit.governance import PIIDetector

    detector = PIIDetector()
    col_names = list(df.columns)
    pii_results = detector.classify_columns(col_names)
    restricted = detector.restricted_columns(col_names)
    _ok(f"Scanned {len(col_names)} columns")
    pii_cols = [r for r in pii_results if r.pii_categories]
    for r in pii_cols[:5]:
        cats = ", ".join(c.value for c in r.pii_categories)
        _warn(f"  {r.column_name}: {r.classification.name} ({cats})")
    if restricted:
        _fail(f"{len(restricted)} RESTRICTED column(s): {', '.join(restricted)}")
    _ok(f"Data classified per FFIEC guidelines")

    # ---- Step 8: Model Card ----
    _step(8, "Generating model card (Mitchell et al. 2019)...")
    from proveit.examiner import ModelCardGenerator

    generator = ModelCardGenerator()
    card = generator.generate(
        model_metadata={
            "name": "CreditScore v1.0",
            "type": "GradientBoostingClassifier",
            "version": "1.0.0",
            "owner": "Model Risk Management",
            "developer": "ML Engineering",
        },
        fairness_results=report.to_dict(),
        compliance_results=comp_report.to_dict(),
    )
    _ok(f"Model card generated: {len(card.to_markdown())} chars")
    _info("Sections: model details, intended use, metrics, ethical considerations")

    # ---- Step 9: Examiner Package ----
    _step(9, "Assembling examiner-ready package...")
    from proveit.examiner import ExaminerPackage

    package = ExaminerPackage(
        institution_name="Acme Bank",
        examination_type="fair_lending",
        prepared_by="ProveIt Compliance Platform",
    )
    package.add_compliance_results(comp_report.to_dict())
    package.add_fairness_analysis(report.to_dict())
    package.add_model_card(card.to_dict())
    completeness = package.completeness_score
    _ok(f"Examiner package assembled")
    _metric("Completeness", f"{completeness:.0%}", completeness >= 0.5)

    # ---- Summary ----
    elapsed = time.time() - start
    _header("Demo Complete")
    print(f"  {_BOLD}Total time: {elapsed:.1f}s{_RESET}")
    print()
    print(f"  What ProveIt did in {elapsed:.0f} seconds:")
    print(f"  {_GREEN}1.{_RESET} Tracked provenance for {len(df):,} records (24-bit HYDRA-24)")
    print(f"  {_GREEN}2.{_RESET} Detected disparate impact + {proxy_count} proxy variables")
    print(f"  {_GREEN}3.{_RESET} Ran 5 compliance engines (80+ regulatory checks)")
    print(f"  {_GREEN}4.{_RESET} Calculated board score: {score_result.score:.0f}/100")
    print(f"  {_GREEN}5.{_RESET} Generated model card + examiner package")
    print()
    print(f"  {_BOLD}What this replaces:{_RESET}")
    print(f"  {_DIM}  - 200+ hours of manual validation work{_RESET}")
    print(f"  {_DIM}  - $50-200K in Big 4 consultant fees per model{_RESET}")
    print(f"  {_DIM}  - Weeks of back-and-forth with examiners{_RESET}")
    print()
    print(f"  {_BOLD}{_CYAN}proveit.ai{_RESET}")
    print()


def main():
    run_demo()


if __name__ == "__main__":
    main()
