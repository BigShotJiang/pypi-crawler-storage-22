"""Allow running as ``python -m proveit.docs``."""

from proveit.docs.cli import main

main()
