"""Allow running as ``python -m proveit.fairness``."""

from proveit.fairness.cli import main

main()
