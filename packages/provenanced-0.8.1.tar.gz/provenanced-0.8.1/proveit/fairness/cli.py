"""
ProveIt Fairness CLI: algorithmic fairness analysis from the command line.

Usage:
    proveit fairness analyze --model credit_model.pkl --data training_data.csv \
        --protected race,sex,age --industry lending
"""

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Optional

BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
CYAN = "\033[36m"
RESET = "\033[0m"


def _supports_color() -> bool:
    import os
    if not hasattr(sys.stdout, "isatty") or not sys.stdout.isatty():
        return False
    return os.environ.get("NO_COLOR") is None


def _c(text: str, color: str) -> str:
    return f"{color}{text}{RESET}" if _supports_color() else text


def cmd_analyze(args):
    """Run full algorithmic fairness analysis."""
    import logging as _logging
    import numpy as np
    import pandas as pd
    from .engine import FairLensEngine, FairLensConfig

    if getattr(args, "verbose", False):
        _logging.basicConfig(level=_logging.DEBUG)

    if not Path(args.model).exists():
        print(_c(f"Error: model file not found: {args.model}", RED))
        sys.exit(1)
    if not Path(args.data).exists():
        print(_c(f"Error: data file not found: {args.data}", RED))
        sys.exit(1)

    from proveit.loader import load_model as _load_model_universal, load_data as _load_data_universal

    try:
        model = _load_model_universal(args.model)
    except (ImportError, ValueError, FileNotFoundError) as exc:
        print(_c(f"Error: could not load model '{args.model}': {exc}", RED))
        sys.exit(1)

    try:
        data = _load_data_universal(args.data)
    except (ImportError, ValueError, FileNotFoundError) as exc:
        print(_c(f"Error: could not read data '{args.data}': {exc}", RED))
        sys.exit(1)

    user_protected = [c.strip() for c in args.protected.split(",")]
    target_col = args.target or _guess_target(data)

    if target_col not in data.columns:
        print(_c(f"Error: target column '{target_col}' not in data", RED))
        sys.exit(1)

    # Build config + engine first so industry presets can expand protected_columns
    config = FairLensConfig(
        protected_columns=user_protected,
        run_lda_search=not args.no_lda,
        run_adverse_action=not args.no_adverse,
        industry=getattr(args, 'industry', None),
    )
    engine = FairLensEngine(config=config)

    # The engine may have expanded protected_columns via industry preset.
    # Only analyze columns actually present in the data.
    protected_columns = [c for c in config.protected_columns if c in data.columns]
    missing_protected = [c for c in config.protected_columns if c not in data.columns]
    if missing_protected:
        print(_c(f"  Warning: protected columns not in data (skipped): {', '.join(missing_protected)}", YELLOW))
    config.protected_columns = protected_columns

    # Determine feature columns: if the model knows its feature names, use those;
    # otherwise exclude target and protected columns from the data.
    if hasattr(model, 'feature_names_in_'):
        feature_cols = list(model.feature_names_in_)
    else:
        feature_cols = [c for c in data.columns if c != target_col and c not in protected_columns]

    X = data[feature_cols]
    y = data[target_col].values
    protected = data[protected_columns]

    try:
        from sklearn.model_selection import train_test_split
        try:
            X_train, X_test, y_train, y_test, prot_train, prot_test = train_test_split(
                X, y, protected, test_size=0.3, random_state=42, stratify=y,
            )
        except ValueError:
            X_train, X_test, y_train, y_test, prot_train, prot_test = train_test_split(
                X, y, protected, test_size=0.3, random_state=42,
            )
    except ImportError:
        split = int(len(X) * 0.7)
        X_train, X_test = X.iloc[:split], X.iloc[split:]
        y_train, y_test = y[:split], y[split:]
        prot_test = protected.iloc[split:]

    if not getattr(args, "json", False):
        print()
        print(_c("  FairLens Analysis", BOLD))
        print(_c(f"  Model: {args.model}", DIM))
        print(_c(f"  Data: {args.data} ({len(data):,} rows)", DIM))
        print(_c(f"  Protected: {', '.join(protected_columns)}", DIM))
        if config.industry:
            print(_c(f"  Industry: {config.industry}", DIM))
            if engine._framework:
                print(_c(f"  Framework: {engine._framework.name}", DIM))
        print()

    def model_factory():
        return _load_model(args.model)

    report = engine.analyze(
        model=model,
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        protected_data=prot_test,
        model_name=Path(args.model).stem,
        model_factory=model_factory if config.run_lda_search else None,
    )

    if getattr(args, "json", False):
        print(report.to_json())
        return

    print(_c(f"  FairLens Analysis Complete ({report.analysis_time_seconds:.1f}s)", GREEN))
    print()
    print(_c("  FINDINGS:", BOLD))

    for finding in report.findings:
        if finding.severity.value == "critical":
            tag = _c("[CRITICAL]", RED + BOLD)
        elif finding.severity.value == "warning":
            tag = _c("[WARNING]", YELLOW)
        else:
            tag = _c("[INFO]", CYAN)

        print(f"  {tag} {finding.description}")
        if finding.regulation:
            print(f"    {_c(finding.regulation, DIM)}")
        print()

    print(_c(f"  Summary: {report.summary['critical']} critical, "
             f"{report.summary['warnings']} warnings, "
             f"{report.summary['proxy_features_detected']} proxy features", BOLD))

    if args.output:
        output_path = Path(args.output)
        output_path.write_text(report.to_json())
        print(f"\n  {_c('Full report:', DIM)} {output_path}")

    print()


def _load_model(path: str):
    """Load a model from joblib format (preferred for sklearn models)."""
    p = Path(path)
    try:
        import joblib
    except ModuleNotFoundError:
        print(_c("Error: joblib is required to load models. Install joblib: pip install joblib", RED))
        sys.exit(1)
    if p.suffix == ".joblib":
        return joblib.load(p)
    else:
        try:
            return joblib.load(p)
        except Exception:
            raise ValueError(
                f"Could not load model from {path}. "
                f"Save your model using joblib.dump(model, 'model.joblib')"
            )


def _guess_target(data) -> str:
    """Guess the target column name."""
    for name in ["target", "label", "approved", "default", "y", "outcome", "decision"]:
        if name in data.columns:
            return name
    return data.columns[-1]


SUPPORTED_REGULATIONS = {"ecoa", "eu_ai_act", "title_vii", "fha", "aca_1557", "naic"}


def _validate_regulation(regulation: str) -> None:
    """Validate the --regulation flag and warn for unsupported values."""
    reg_lower = regulation.lower().strip()
    if reg_lower not in SUPPORTED_REGULATIONS:
        print(_c(
            f"  Warning: unrecognized regulation '{regulation}'. "
            f"Supported: {', '.join(sorted(SUPPORTED_REGULATIONS))}. "
            f"Defaulting to ECOA.",
            YELLOW,
        ))


def register_subcommands(subparsers):
    """Register fairness subcommands on a parent subparser (for unified CLI)."""
    analyze_parser = subparsers.add_parser("analyze", help="Run algorithmic fairness analysis")
    analyze_parser.add_argument("--model", required=True, help="Path to trained model (.joblib)")
    analyze_parser.add_argument("--data", required=True, help="Path to training data (.csv)")
    analyze_parser.add_argument("--protected", required=True, help="Comma-separated protected attributes")
    analyze_parser.add_argument("--target", help="Target column name (auto-detected if not specified)")
    analyze_parser.add_argument("--regulation", default="ecoa", help="Regulation to check against")
    analyze_parser.add_argument("--output", help="Output file path for JSON report")
    analyze_parser.add_argument("--industry", default=None,
                                choices=["lending", "hiring", "insurance", "housing", "healthcare", "education", "general"],
                                help="Industry preset for regulatory framework")
    analyze_parser.add_argument("--no-lda", action="store_true", help="Skip LDA search")
    analyze_parser.add_argument("--no-adverse", action="store_true", help="Skip adverse action generation")
    analyze_parser.add_argument("--json", action="store_true", help="Output JSON report to stdout")
    analyze_parser.add_argument("--verbose", "-v", action="store_true", help="Enable debug logging")


def main():
    parser = argparse.ArgumentParser(
        prog="proveit fairness",
        description="ProveIt Fairness: Automated Algorithmic Fairness Analysis",
    )
    parser.add_argument("--version", action="version", version="proveit 0.1.0")

    subparsers = parser.add_subparsers(dest="command")
    register_subcommands(subparsers)

    args = parser.parse_args()

    if args.command == "analyze":
        _validate_regulation(args.regulation)
        cmd_analyze(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
