"""
Model and data loading utilities for bank ML workflows.

Handles the common formats used in regulated financial institutions:
- Models: pickle, joblib, ONNX, PyTorch (.pt), TensorFlow SavedModel,
          XGBoost (.json/.ubj), LightGBM (.txt)
- Data: CSV, Parquet, SAS (.sas7bdat/.xpt), Excel, Feather, JSON

Usage:
    from proveit import load_model, load_data

    model = load_model("credit_model.pkl")
    data = load_data("applications.parquet")
"""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import pandas as pd

logger = logging.getLogger(__name__)

# ── Model Loading ────────────────────────────────────────────────────────────

_MODEL_LOADERS = {}


def _register_loader(extensions, loader_fn):
    for ext in extensions:
        _MODEL_LOADERS[ext] = loader_fn


def _load_pickle(path: Path):
    # Try joblib first — most sklearn models are saved with joblib
    # even when using .pkl extension
    try:
        import joblib
        return joblib.load(path)
    except ImportError:
        pass
    except Exception as exc:
        logger.debug("joblib.load failed for %s: %s", path, exc)

    import pickle
    with open(path, "rb") as f:
        return pickle.load(f)


def _load_joblib(path: Path):
    try:
        import joblib
    except ImportError:
        raise ImportError(
            "joblib is required to load .joblib models.\n"
            "    pip install joblib"
        )
    return joblib.load(path)


def _load_onnx(path: Path):
    try:
        import onnxruntime as ort
    except ImportError:
        raise ImportError(
            "onnxruntime is required to load ONNX models.\n"
            "    pip install provenanced[onnx]"
        )
    return _ONNXModelWrapper(ort.InferenceSession(str(path)))


def _load_pytorch(path: Path):
    try:
        import torch
    except ImportError:
        raise ImportError(
            "PyTorch is required to load .pt/.pth models.\n"
            "    pip install provenanced[torch]"
        )
    model = torch.load(str(path), map_location="cpu", weights_only=False)
    if isinstance(model, dict) and "model_state_dict" in model:
        raise ValueError(
            f"{path} contains a state_dict, not a full model. "
            "Load the model architecture first, then call "
            "model.load_state_dict(torch.load(path)['model_state_dict'])"
        )
    return model


def _load_tensorflow(path: Path):
    try:
        import tensorflow as tf
    except ImportError:
        raise ImportError(
            "TensorFlow is required to load SavedModel directories.\n"
            "    pip install provenanced[tensorflow]"
        )
    return tf.keras.models.load_model(str(path))


def _load_h5(path: Path):
    try:
        import tensorflow as tf
    except ImportError:
        raise ImportError(
            "TensorFlow is required to load .h5 Keras models.\n"
            "    pip install provenanced[tensorflow]"
        )
    return tf.keras.models.load_model(str(path))


def _load_xgboost(path: Path):
    try:
        import xgboost as xgb
    except ImportError:
        raise ImportError(
            "XGBoost is required to load .json/.ubj XGBoost models.\n"
            "    pip install provenanced[xgboost]"
        )
    booster = xgb.Booster()
    booster.load_model(str(path))
    return booster


def _load_lightgbm(path: Path):
    try:
        import lightgbm as lgb
    except ImportError:
        raise ImportError(
            "LightGBM is required to load .lgb LightGBM models.\n"
            "    pip install provenanced[lightgbm]"
        )
    return lgb.Booster(model_file=str(path))


_register_loader([".pkl", ".pickle"], _load_pickle)
_register_loader([".joblib"], _load_joblib)
_register_loader([".onnx"], _load_onnx)
_register_loader([".pt", ".pth"], _load_pytorch)
_register_loader([".h5", ".keras"], _load_h5)
_register_loader([".ubj"], _load_xgboost)
_register_loader([".lgb"], _load_lightgbm)


# JSON can be XGBoost — detect by content
def _load_json_model(path: Path):
    """Load a JSON model file — detects XGBoost vs generic."""
    text = path.read_text(encoding="utf-8", errors="replace")[:200]
    if '"learner"' in text or '"version"' in text:
        return _load_xgboost(path)
    raise ValueError(
        f"Could not determine model format for '{path}'. "
        f"If this is an XGBoost model, rename to .ubj or use "
        f"xgb.Booster().load_model() directly."
    )


_register_loader([".json"], _load_json_model)


# TXT can be LightGBM — detect by content
def _load_txt_model(path: Path):
    """Load a TXT model file — detects LightGBM vs generic."""
    text = path.read_text(encoding="utf-8", errors="replace")[:300]
    if "tree" in text and ("num_leaves" in text or "num_class" in text):
        return _load_lightgbm(path)
    raise ValueError(
        f"Could not determine model format for '{path}'. "
        f"If this is a LightGBM model, rename to .lgb or use "
        f"lgb.Booster(model_file=path) directly."
    )


_register_loader([".txt"], _load_txt_model)


class _ONNXModelWrapper:
    """Wraps an ONNX InferenceSession to provide sklearn-compatible API."""

    def __init__(self, session):
        self._session = session
        input_info = session.get_inputs()
        self._input_name = input_info[0].name if input_info else "input"
        self._input_shape = input_info[0].shape if input_info else None

    def predict(self, X):
        import numpy as np
        if isinstance(X, pd.DataFrame):
            X = X.values.astype(np.float32)
        elif not isinstance(X, np.ndarray):
            X = np.asarray(X, dtype=np.float32)
        else:
            X = X.astype(np.float32)
        results = self._session.run(None, {self._input_name: X})
        output = results[0]
        if output.ndim == 2 and output.shape[1] == 1:
            output = output.ravel()
        if output.ndim == 2 and output.shape[1] == 2:
            return (output[:, 1] >= 0.5).astype(int)
        return output

    def predict_proba(self, X):
        import numpy as np
        if isinstance(X, pd.DataFrame):
            X = X.values.astype(np.float32)
        elif not isinstance(X, np.ndarray):
            X = np.asarray(X, dtype=np.float32)
        else:
            X = X.astype(np.float32)
        results = self._session.run(None, {self._input_name: X})
        if len(results) > 1:
            return np.array(results[1])[:, 1]
        output = results[0]
        if output.ndim == 2 and output.shape[1] == 2:
            return output[:, 1]
        return output.ravel()


def load_model(path: str, **kwargs) -> Any:
    """Load a trained ML model from disk.

    Supports pickle, joblib, ONNX, PyTorch, TensorFlow SavedModel,
    Keras HDF5, XGBoost (.json/.ubj), and LightGBM (.txt/.lgb) formats.
    Format is detected from the file extension.

    Args:
        path: Path to the model file or directory (for SavedModel).

    Returns:
        The loaded model object, ready for ``proveit.analyze()``.

    Examples:
        >>> model = load_model("credit_model.pkl")
        >>> model = load_model("fraud_detector.onnx")
        >>> model = load_model("xgb_model.json")
        >>> model = load_model("lgb_model.txt")
        >>> model = load_model("saved_model/")  # TF SavedModel dir
    """
    p = Path(path)

    if p.is_dir():
        saved_model_pb = p / "saved_model.pb"
        keras_metadata = p / "keras_metadata.pb"
        if saved_model_pb.exists() or keras_metadata.exists():
            return _load_tensorflow(p)
        raise ValueError(
            f"{path} is a directory but doesn't appear to be a "
            "TensorFlow SavedModel (no saved_model.pb found)"
        )

    if not p.exists():
        raise FileNotFoundError(f"Model file not found: {path}")

    if p.stat().st_size == 0:
        raise ValueError(f"Model file is empty: {path}")

    ext = p.suffix.lower()
    loader = _MODEL_LOADERS.get(ext)
    if loader is None:
        logger.info(
            "Unknown extension '%s', trying pickle then joblib", ext
        )
        try:
            return _load_pickle(p)
        except Exception:
            pass
        try:
            return _load_joblib(p)
        except Exception:
            pass
        raise ValueError(
            f"Could not load model from '{path}'. "
            f"Supported extensions: {', '.join(sorted(_MODEL_LOADERS.keys()))}, "
            f"or TensorFlow SavedModel directories."
        )

    return loader(p)


# ── Data Loading ─────────────────────────────────────────────────────────────

_DATA_LOADERS = {
    ".csv": lambda p, kw: pd.read_csv(p, **kw),
    ".tsv": lambda p, kw: pd.read_csv(p, sep="\t", **kw),
    ".parquet": lambda p, kw: pd.read_parquet(p, **kw),
    ".pq": lambda p, kw: pd.read_parquet(p, **kw),
    ".xlsx": lambda p, kw: pd.read_excel(p, **kw),
    ".xls": lambda p, kw: pd.read_excel(p, **kw),
    ".feather": lambda p, kw: pd.read_feather(p, **kw),
    ".ftr": lambda p, kw: pd.read_feather(p, **kw),
    ".json": lambda p, kw: pd.read_json(p, **kw),
    ".jsonl": lambda p, kw: pd.read_json(p, lines=True, **kw),
    ".sas7bdat": lambda p, kw: pd.read_sas(p, format="sas7bdat", **kw),
    ".xpt": lambda p, kw: pd.read_sas(p, format="xport", **kw),
    ".dta": lambda p, kw: pd.read_stata(p, **kw),
    ".orc": lambda p, kw: pd.read_orc(p, **kw),
}


def load_data(
    path: str,
    **kwargs,
) -> pd.DataFrame:
    """Load tabular data from disk into a pandas DataFrame.

    Supports CSV, Parquet, SAS (.sas7bdat, .xpt), Excel, Feather,
    JSON/JSONL, Stata, and ORC formats. Format is detected from
    the file extension.

    Args:
        path: Path to the data file.
        **kwargs: Additional keyword arguments passed to the
            underlying pandas reader (e.g., ``sheet_name`` for Excel,
            ``encoding`` for CSV).

    Returns:
        A pandas DataFrame.

    Examples:
        >>> data = load_data("applications.csv")
        >>> data = load_data("training_data.parquet")
        >>> data = load_data("legacy_data.sas7bdat")
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Data file not found: {path}")

    if p.stat().st_size == 0:
        raise ValueError(f"Data file is empty: {path}")

    ext = p.suffix.lower()
    loader = _DATA_LOADERS.get(ext)
    if loader is None:
        raise ValueError(
            f"Unsupported data format '{ext}'. "
            f"Supported: {', '.join(sorted(_DATA_LOADERS.keys()))}"
        )

    df = loader(p, kwargs)

    if len(df) == 0:
        raise ValueError(f"Data file contains no rows: {path}")

    logger.info("Loaded %d rows x %d columns from %s", len(df), len(df.columns), path)
    return df
