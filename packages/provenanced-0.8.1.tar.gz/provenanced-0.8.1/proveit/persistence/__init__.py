"""
Persistence layer for HYDRA-24 DAG provenance.

Provides database storage for long-term audit trails with minimal performance impact.

Basic usage:
    from proveit import DAGTracker
    from proveit.persistence import create_storage

    # SQLite for testing
    storage = create_storage("./local.db")

    # S3 for production
    storage = create_storage("s3://my-bucket/provenance")

    # Run pipeline, then persist
    tracker = DAGTracker(pipeline_name="loan_scoring")
    # ... compute ...
    storage.connect()
    tracker.persist_to_storage(storage)
    storage.disconnect()

Reconstruct from database:
    from proveit.persistence import reconstruct_dag

    dag = reconstruct_dag(
        fingerprint=0x401B01,
        connection="sqlite:///provenance.db"
    )
    print(dag.has_protected)  # Cryptographic proof
"""

from .schema import init_database, get_schema_ddl
from .storage import PostgreSQLStorage, StorageBackend
from .sqlite_storage import SQLiteStorage
from .query import reconstruct_dag, query_by_fingerprint, query_by_source
from .async_writer import AsyncWriter, WriterConfig
from .factory import create_storage


def __getattr__(name):
    if name == "S3Storage":
        from .s3_storage import S3Storage
        return S3Storage
    if name == "DuckDBStorage":
        from .duckdb_storage import DuckDBStorage
        return DuckDBStorage
    if name == "HostedStorage":
        from .hosted_storage import HostedStorage
        return HostedStorage
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    # Setup
    'init_database',
    'get_schema_ddl',

    # Storage backends
    'SQLiteStorage',
    'PostgreSQLStorage',
    'StorageBackend',
    'S3Storage',
    'DuckDBStorage',
    'HostedStorage',

    # Factory
    'create_storage',

    # Query/reconstruction
    'reconstruct_dag',
    'query_by_fingerprint',
    'query_by_source',

    # Async writing
    'AsyncWriter',
    'WriterConfig',
]
