"""
Async writer for non-blocking persistence.

Writes DAG nodes and edges in a background thread to avoid slowing ML pipelines.
Uses a queue with batching for maximum throughput.
"""

import json
import os
import threading
import queue
import time
from dataclasses import dataclass
from typing import Optional, List, Callable
from enum import Enum, auto
import logging

from .storage import StorageBackend, StoredNode, StoredEdge


logger = logging.getLogger(__name__)


class WriteCommand(Enum):
    """Commands for the async writer thread."""
    WRITE_NODES = auto()
    WRITE_EDGES = auto()
    REGISTER_SOURCE = auto()
    FLUSH = auto()
    SHUTDOWN = auto()


@dataclass
class WriterConfig:
    """Configuration for async writer."""
    batch_size: int = 100          # Nodes/edges per batch insert
    flush_interval: float = 1.0    # Max seconds before auto-flush
    queue_size: int = 10000        # Max items in queue before blocking
    retry_attempts: int = 3        # Retry failed writes
    retry_delay: float = 0.5       # Seconds between retries
    wal_path: Optional[str] = None  # Write-ahead log path (None = no WAL)


class _WriteAheadLog:
    """Simple append-only WAL that journals pending writes to disk.

    On crash, unacknowledged writes survive in the WAL file and can be
    replayed on the next start.  After a successful flush the WAL is
    truncated.
    """

    def __init__(self, path: str):
        self.path = path
        self._fd: Optional[int] = None

    def open(self) -> None:
        self._fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)

    def close(self) -> None:
        if self._fd is not None:
            os.close(self._fd)
            self._fd = None

    def append_nodes(self, nodes: List[StoredNode]) -> None:
        """Append a batch of nodes to the WAL."""
        if self._fd is None:
            return
        for n in nodes:
            record = json.dumps({
                "t": "n",
                "fp": n.fingerprint, "nt": n.node_type, "op": n.operation,
                "tn": n.table_name, "cn": n.column_name, "pi": n.pair_id,
                "pr": n.is_protected, "eh": n.entity_hash, "ch": n.chain_hash,
                "md": n.metadata, "pid": n.pipeline_id,
            }) + "\n"
            os.write(self._fd, record.encode())

    def append_edges(self, edges: List[StoredEdge]) -> None:
        """Append a batch of edges to the WAL."""
        if self._fd is None:
            return
        for e in edges:
            record = json.dumps({
                "t": "e",
                "pf": e.parent_fingerprint, "cf": e.child_fingerprint,
                "ip": e.input_position,
            }) + "\n"
            os.write(self._fd, record.encode())

    def truncate(self) -> None:
        """Clear the WAL after a successful flush."""
        if self._fd is not None:
            os.ftruncate(self._fd, 0)
            os.lseek(self._fd, 0, os.SEEK_SET)

    def recover(self) -> tuple:
        """Read uncommitted records from the WAL file.

        Returns ``(nodes, edges)`` lists that need to be replayed.
        """
        nodes: List[StoredNode] = []
        edges: List[StoredEdge] = []
        if not os.path.exists(self.path):
            return nodes, edges
        try:
            with open(self.path, "r") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    rec = json.loads(line)
                    if rec["t"] == "n":
                        nodes.append(StoredNode(
                            fingerprint=rec["fp"], node_type=rec["nt"],
                            operation=rec["op"], table_name=rec.get("tn"),
                            column_name=rec.get("cn"), pair_id=rec.get("pi"),
                            is_protected=rec.get("pr", False),
                            entity_hash=rec.get("eh"), chain_hash=rec.get("ch"),
                            metadata=rec.get("md"), pipeline_id=rec.get("pid"),
                        ))
                    elif rec["t"] == "e":
                        edges.append(StoredEdge(
                            parent_fingerprint=rec["pf"],
                            child_fingerprint=rec["cf"],
                            input_position=rec.get("ip", 0),
                        ))
        except (json.JSONDecodeError, KeyError, OSError) as exc:
            logger.warning("WAL recovery partial — corrupt record skipped: %s", exc)
        return nodes, edges


class AsyncWriter:
    """
    Background writer for HYDRA-24 provenance.

    Batches writes to minimize database round-trips and avoid blocking
    the ML pipeline during computation.

    Thread-safe: Multiple threads can call write_node/write_edge concurrently.

    When ``config.wal_path`` is set, pending writes are journaled to disk
    before acknowledgement so that a crash will not lose audit data.

    Example:
        writer = AsyncWriter(storage, config)
        writer.start()

        # These return immediately without blocking
        writer.write_node(node)
        writer.write_edge(edge)

        # Ensure everything is written before exit
        writer.flush()
        writer.stop()
    """

    def __init__(self, storage: StorageBackend, config: Optional[WriterConfig] = None):
        """
        Initialize async writer.

        Args:
            storage: Storage backend to write to
            config: Writer configuration (uses defaults if None)
        """
        self.storage = storage
        self.config = config or WriterConfig()

        self._queue: queue.Queue = queue.Queue(maxsize=self.config.queue_size)
        self._thread: Optional[threading.Thread] = None
        self._running = False

        # Write-ahead log for crash safety
        self._wal: Optional[_WriteAheadLog] = None
        if self.config.wal_path:
            self._wal = _WriteAheadLog(self.config.wal_path)

        # Statistics
        self._stats = {
            'nodes_written': 0,
            'edges_written': 0,
            'sources_registered': 0,
            'batches_written': 0,
            'errors': 0,
            'retries': 0,
        }
        self._stats_lock = threading.Lock()

    def start(self) -> None:
        """Start the background writer thread.

        If a WAL file exists from a previous crash, replays its contents
        before accepting new writes.
        """
        if self._running:
            return

        # Replay any WAL records from a previous crash
        if self._wal:
            self._wal.open()
            recovered_nodes, recovered_edges = self._wal.recover()
            if recovered_nodes or recovered_edges:
                logger.info(
                    "WAL recovery: replaying %d nodes, %d edges",
                    len(recovered_nodes), len(recovered_edges),
                )
                if recovered_nodes:
                    self._queue.put((WriteCommand.WRITE_NODES, recovered_nodes), block=False)
                if recovered_edges:
                    self._queue.put((WriteCommand.WRITE_EDGES, recovered_edges), block=False)

        self._running = True
        self._thread = threading.Thread(target=self._writer_loop, daemon=True)
        self._thread.start()
        logger.info("AsyncWriter started")

    def stop(self, timeout: float = 10.0) -> bool:
        """
        Stop the background writer thread.

        Sends a shutdown command and waits for the background thread
        to drain remaining items and exit gracefully.

        Args:
            timeout: Max seconds to wait for graceful shutdown

        Returns:
            True if all queued writes completed, False if the writer
            timed out and queued data may have been lost.
        """
        if not self._running:
            return True

        self._running = False
        # Signal shutdown -- the writer loop will flush remaining batches
        self._queue.put((WriteCommand.SHUTDOWN, None))

        completed = True
        # Wait for thread to finish
        if self._thread:
            self._thread.join(timeout=timeout)
            if self._thread.is_alive():
                remaining = self._queue.qsize()
                logger.error(
                    "AsyncWriter thread did not stop within %s seconds. "
                    "Approximately %d queued items may be lost. "
                    "Audit trail may be incomplete.",
                    timeout, remaining,
                )
                completed = False
            self._thread = None

        # Close the WAL file
        if self._wal:
            self._wal.close()

        logger.info("AsyncWriter stopped. Stats: %s", self._stats)
        return completed

    def __enter__(self):
        """Context manager entry -- starts the writer."""
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit -- stops the writer."""
        self.stop()
        return False

    def write_node(self, node: StoredNode) -> None:
        """
        Queue a node for writing (non-blocking).

        If WAL is enabled, the node is journaled to disk before queuing
        so that it survives a crash.

        Args:
            node: Node to write

        Raises:
            queue.Full: If queue is full (only if queue_size is set)
        """
        nodes = [node]
        if self._wal:
            self._wal.append_nodes(nodes)
        self._queue.put((WriteCommand.WRITE_NODES, nodes), block=False)

    def write_nodes(self, nodes: List[StoredNode]) -> None:
        """
        Queue multiple nodes for writing (non-blocking).

        More efficient than calling write_node repeatedly.
        """
        if nodes:
            if self._wal:
                self._wal.append_nodes(nodes)
            self._queue.put((WriteCommand.WRITE_NODES, nodes), block=False)

    def write_edge(self, edge: StoredEdge) -> None:
        """Queue an edge for writing (non-blocking)."""
        edges = [edge]
        if self._wal:
            self._wal.append_edges(edges)
        self._queue.put((WriteCommand.WRITE_EDGES, edges), block=False)

    def write_edges(self, edges: List[StoredEdge]) -> None:
        """Queue multiple edges for writing (non-blocking)."""
        if edges:
            if self._wal:
                self._wal.append_edges(edges)
            self._queue.put((WriteCommand.WRITE_EDGES, edges), block=False)

    def register_source(self, pair_id: int, table: str, column: str,
                       is_protected: bool = False) -> None:
        """Queue a source registration (non-blocking)."""
        self._queue.put(
            (WriteCommand.REGISTER_SOURCE, (pair_id, table, column, is_protected)),
            block=False
        )

    def flush(self, timeout: float = 30.0) -> bool:
        """
        Block until all queued writes complete.

        Args:
            timeout: Max seconds to wait

        Returns:
            True if flush completed, False if timeout
        """
        if not self._running:
            return True

        # Send flush command
        flush_event = threading.Event()
        self._queue.put((WriteCommand.FLUSH, flush_event), block=True)

        # Wait for flush to complete
        return flush_event.wait(timeout=timeout)

    def get_stats(self) -> dict:
        """Get writer statistics."""
        with self._stats_lock:
            return self._stats.copy()

    def _writer_loop(self) -> None:
        """
        Main writer thread loop.

        Batches writes and flushes periodically or when batch is full.
        On shutdown, drains any remaining items from the queue before exiting.
        """
        node_batch: List[StoredNode] = []
        edge_batch: List[StoredEdge] = []
        last_flush = time.time()
        shutting_down = False

        while True:
            try:
                # Get next command with timeout
                try:
                    command, data = self._queue.get(timeout=self.config.flush_interval)
                except queue.Empty:
                    if shutting_down:
                        # Queue is drained, flush and exit
                        self._flush_batches(node_batch, edge_batch)
                        break
                    # Flush timeout reached
                    self._flush_batches(node_batch, edge_batch)
                    node_batch.clear()
                    edge_batch.clear()
                    last_flush = time.time()
                    continue

                # Handle command
                if command == WriteCommand.WRITE_NODES:
                    node_batch.extend(data)

                    # Flush if batch is full
                    if len(node_batch) >= self.config.batch_size:
                        self._flush_nodes(node_batch)
                        node_batch.clear()
                        last_flush = time.time()

                elif command == WriteCommand.WRITE_EDGES:
                    edge_batch.extend(data)

                    # Flush if batch is full
                    if len(edge_batch) >= self.config.batch_size:
                        self._flush_edges(edge_batch)
                        edge_batch.clear()
                        last_flush = time.time()

                elif command == WriteCommand.REGISTER_SOURCE:
                    pair_id, table, column, is_protected = data
                    self._register_source_with_retry(pair_id, table, column, is_protected)

                elif command == WriteCommand.FLUSH:
                    flush_event = data
                    self._flush_batches(node_batch, edge_batch)
                    node_batch.clear()
                    edge_batch.clear()
                    last_flush = time.time()
                    flush_event.set()

                elif command == WriteCommand.SHUTDOWN:
                    # Flush current batches, then drain remaining queue items
                    self._flush_batches(node_batch, edge_batch)
                    node_batch.clear()
                    edge_batch.clear()
                    shutting_down = True
                    continue

                # Auto-flush if interval elapsed
                if not shutting_down and time.time() - last_flush > self.config.flush_interval:
                    self._flush_batches(node_batch, edge_batch)
                    node_batch.clear()
                    edge_batch.clear()
                    last_flush = time.time()

            except Exception as e:
                logger.error("Error in writer loop: %s", e, exc_info=True)
                with self._stats_lock:
                    self._stats['errors'] += 1

    def _flush_batches(self, nodes: List[StoredNode], edges: List[StoredEdge]) -> None:
        """Flush both node and edge batches, then truncate the WAL."""
        if nodes:
            self._flush_nodes(nodes)
        if edges:
            self._flush_edges(edges)
        # All data successfully persisted — safe to clear the WAL
        if self._wal and (nodes or edges):
            self._wal.truncate()

    def _retry(self, action: Callable[[], None], stat_key: str, label: str) -> None:
        """Run *action* with retry logic, updating stats on success or failure."""
        for attempt in range(self.config.retry_attempts):
            try:
                action()
                with self._stats_lock:
                    self._stats[stat_key] += 1
                return
            except Exception as e:
                with self._stats_lock:
                    self._stats['retries'] += 1

                if attempt == self.config.retry_attempts - 1:
                    logger.error("Failed %s after %d attempts: %s", label, self.config.retry_attempts, e)
                    with self._stats_lock:
                        self._stats['errors'] += 1
                else:
                    logger.warning("Retry %d/%d for %s", attempt + 1, self.config.retry_attempts, label)
                    time.sleep(self.config.retry_delay * (attempt + 1))

    def _flush_nodes(self, nodes: List[StoredNode]) -> None:
        """Write nodes with retry logic."""
        def _write():
            self.storage.store_nodes(nodes)
            with self._stats_lock:
                self._stats['nodes_written'] += len(nodes)
        self._retry(_write, 'batches_written', f"writing {len(nodes)} nodes")

    def _flush_edges(self, edges: List[StoredEdge]) -> None:
        """Write edges with retry logic."""
        def _write():
            self.storage.store_edges(edges)
            with self._stats_lock:
                self._stats['edges_written'] += len(edges)
        self._retry(_write, 'batches_written', f"writing {len(edges)} edges")

    def _register_source_with_retry(self, pair_id: int, table: str, column: str,
                                    is_protected: bool) -> None:
        """Register source with retry logic."""
        self._retry(
            lambda: self.storage.register_source(pair_id, table, column, is_protected),
            'sources_registered',
            "registering source",
        )


class SyncWriter:
    """
    Synchronous writer (no background thread).

    Useful for testing or when you want immediate writes.
    """

    def __init__(self, storage: StorageBackend):
        self.storage = storage
        self._stats = {
            'nodes_written': 0,
            'edges_written': 0,
            'sources_registered': 0,
        }

    def start(self) -> None:
        """No-op for sync writer."""
        pass

    def stop(self) -> None:
        """No-op for sync writer."""
        pass

    def write_node(self, node: StoredNode) -> None:
        """Write node immediately."""
        self.storage.store_nodes([node])
        self._stats['nodes_written'] += 1

    def write_nodes(self, nodes: List[StoredNode]) -> None:
        """Write nodes immediately."""
        self.storage.store_nodes(nodes)
        self._stats['nodes_written'] += len(nodes)

    def write_edge(self, edge: StoredEdge) -> None:
        """Write edge immediately."""
        self.storage.store_edges([edge])
        self._stats['edges_written'] += 1

    def write_edges(self, edges: List[StoredEdge]) -> None:
        """Write edges immediately."""
        self.storage.store_edges(edges)
        self._stats['edges_written'] += len(edges)

    def register_source(self, pair_id: int, table: str, column: str,
                       is_protected: bool = False) -> None:
        """Register source immediately."""
        self.storage.register_source(pair_id, table, column, is_protected)
        self._stats['sources_registered'] += 1

    def flush(self, timeout: Optional[float] = None) -> bool:
        """No-op for sync writer (already written)."""
        return True

    def get_stats(self) -> dict:
        """Get writer statistics."""
        return self._stats.copy()
