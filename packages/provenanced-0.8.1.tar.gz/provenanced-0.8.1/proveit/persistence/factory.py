"""
ProveIt storage factory for provenance backends.

Provides a single ``create_storage`` entry point that builds the right
``StorageBackend`` from a URL string (or the ``PROVEIT_STORAGE_URL``
environment variable).

Usage:
    from proveit.persistence import create_storage

    # SQLite (local / testing)
    storage = create_storage("sqlite:///path/to/db.db")
    storage = create_storage("sqlite:///:memory:")
    storage = create_storage("./local.db")

    # AWS S3 (production)
    storage = create_storage("s3://my-bucket/provenance/prefix")

    # Environment variable fallback
    storage = create_storage()  # reads PROVEIT_STORAGE_URL env var
"""

import logging
import os
from typing import Optional
from urllib.parse import urlparse

from .storage import StorageBackend

logger = logging.getLogger(__name__)

# Prefer the new PROVEIT_STORAGE_URL env var; fall back to the legacy
# HYDRA24_STORAGE_URL for backward compatibility with existing deployments.
PROVEIT_STORAGE_URL_ENV = "PROVEIT_STORAGE_URL"
HYDRA24_STORAGE_URL_ENV = "HYDRA24_STORAGE_URL"


def create_storage(url: Optional[str] = None, **kwargs) -> StorageBackend:
    """Create a storage backend from a URL string.

    Inspects the URL scheme and file extension to select the appropriate
    backend class.  boto3 is imported lazily — only when S3 is selected.

    Args:
        url: Storage URL.  If ``None``, reads from the
            ``PROVEIT_STORAGE_URL`` environment variable (falling back
            to ``HYDRA24_STORAGE_URL`` for backward compatibility).
            If neither is set, defaults to an in-memory SQLite database.
        **kwargs: Additional keyword arguments forwarded to the backend
            constructor.  For ``S3Storage`` these can include ``region``
            and ``local_dir``.

    Returns:
        A ``StorageBackend`` instance.  The caller is responsible for
        calling ``.connect()`` (or using the instance as a context
        manager) before issuing reads/writes.

    Raises:
        ValueError: If the URL cannot be parsed or the scheme is not
            recognised.

    Examples:
        >>> storage = create_storage("sqlite:///:memory:")
        >>> storage.connect()

        >>> with create_storage("./local.db") as storage:
        ...     pid = storage.create_pipeline("demo")
    """
    if url is None:
        url = os.environ.get(PROVEIT_STORAGE_URL_ENV) or os.environ.get(HYDRA24_STORAGE_URL_ENV)

    if url is None:
        logger.debug(
            "No storage URL provided and %s not set; "
            "defaulting to in-memory SQLite",
            PROVEIT_STORAGE_URL_ENV,
        )
        return _make_sqlite(":memory:", **kwargs)

    return _dispatch(url, **kwargs)


def _dispatch(url: str, **kwargs) -> StorageBackend:
    """Route *url* to the correct backend constructor."""

    # -- S3 (production) -----------------------------------------------------
    if url.startswith("s3://"):
        return _make_s3(url, **kwargs)

    # -- DuckDB via scheme ---------------------------------------------------
    if url.startswith("duckdb:///"):
        path = url[len("duckdb:///"):]
        if path == ":memory:" or path == "":
            return _make_duckdb(":memory:", **kwargs)
        return _make_duckdb(path, **kwargs)

    # -- Bare file path shortcuts --------------------------------------------
    if _looks_like_bare_path(url):
        if url.endswith(".duckdb"):
            return _make_duckdb(url, **kwargs)
        return _make_sqlite(url, **kwargs)

    # -- SQLite via scheme ---------------------------------------------------
    if url.startswith("sqlite:///"):
        path = url[len("sqlite:///"):]
        if path == ":memory:" or path == "":
            return _make_sqlite(":memory:", **kwargs)
        return _make_sqlite(path, **kwargs)

    if url == "sqlite://":
        return _make_sqlite(":memory:", **kwargs)

    raise ValueError(
        f"Cannot determine storage backend for URL: {url!r}. "
        f"Supported schemes: sqlite:/// , s3:// , duckdb:/// , "
        f"or a bare file path ending in .db / .sqlite / .sqlite3 / .duckdb."
    )


def _looks_like_bare_path(url: str) -> bool:
    """Return True if *url* looks like a bare file path rather than a URL."""
    if "://" in url:
        return False
    return url.endswith((".db", ".sqlite", ".sqlite3", ".duckdb"))


# ---------------------------------------------------------------------------
# Backend constructors (lazy imports)
# ---------------------------------------------------------------------------

def _make_sqlite(db_path: str, **kwargs) -> "StorageBackend":
    from .sqlite_storage import SQLiteStorage
    logger.debug("Creating SQLiteStorage(db_path=%r)", db_path)
    return SQLiteStorage(db_path=db_path)


def _make_duckdb(db_path: str, **kwargs) -> "StorageBackend":
    from .duckdb_storage import DuckDBStorage
    logger.debug("Creating DuckDBStorage(db_path=%r)", db_path)
    return DuckDBStorage(db_path=db_path)


def _make_s3(url: str, **kwargs) -> "StorageBackend":
    from .s3_storage import S3Storage

    parsed = urlparse(url)
    bucket = parsed.netloc
    prefix = parsed.path.lstrip("/")

    if not bucket:
        raise ValueError(
            f"S3 URL must include a bucket name: {url!r}. "
            f"Expected format: s3://bucket-name/optional/prefix"
        )

    logger.debug(
        "Creating S3Storage(bucket=%r, prefix=%r)", bucket, prefix
    )
    return S3Storage(
        bucket=bucket,
        prefix=prefix or "provenance",
        region=kwargs.pop("region", None),
        local_dir=kwargs.pop("local_dir", None),
        storage_class=kwargs.pop("storage_class", "INTELLIGENT_TIERING"),
    )
