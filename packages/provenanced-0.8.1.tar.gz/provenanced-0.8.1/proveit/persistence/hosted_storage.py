"""
ProveIt Hosted Storage: REST API-backed persistence for cloud deployments.

Sends provenance data to a central ProveIt server via HTTP, enabling
multi-tenant, cloud-native deployment without direct database access.

Usage:
    from proveit.persistence.hosted_storage import HostedStorage

    storage = HostedStorage(
        api_url="https://api.proveit.ai",
        api_key="your-api-key",
        tenant_id="org-123",
    )
    storage.connect()
"""

import json
import logging
import time
from typing import List, Dict, Any, Optional, Tuple
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

from .storage import StorageBackend, StoredNode, StoredEdge

logger = logging.getLogger(__name__)

# Maximum retry attempts for transient failures
_MAX_RETRIES = 3
# HTTP status codes that are safe to retry (server-side transient errors)
_RETRYABLE_STATUS = {429, 500, 502, 503, 504}


class HostedStorage(StorageBackend):
    """
    REST API-backed storage backend for cloud-native ProveIt deployments.

    Implements the StorageBackend interface using HTTP REST API calls
    instead of direct database connections. All provenance data is sent
    to a central ProveIt server for multi-tenant storage.

    Features:
    - No database driver dependencies (uses stdlib urllib)
    - Multi-tenant via X-Tenant-ID header
    - Bearer token authentication
    - Graceful error handling (logs warnings, never crashes)
    """

    def __init__(
        self,
        api_url: str,
        api_key: str,
        tenant_id: str = "default",
        timeout: int = 30,
        batch_size: int = 100,
    ):
        self.api_url = api_url.rstrip("/")
        self.api_key = api_key
        self.tenant_id = tenant_id
        self.timeout = timeout
        self.batch_size = batch_size
        self._connected = False

    def _request(
        self,
        method: str,
        path: str,
        data: Optional[Any] = None,
    ) -> Optional[Any]:
        """Send an HTTP request with auth headers, JSON body, and retry logic.

        Retries on transient server errors (429, 5xx) and connection failures
        with exponential backoff. Returns the parsed JSON response on success,
        or None on failure.
        """
        url = f"{self.api_url}{path}"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "X-Tenant-ID": self.tenant_id,
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Connection": "keep-alive",
        }

        body = None
        if data is not None:
            body = json.dumps(data).encode("utf-8")

        last_exc: Optional[Exception] = None
        for attempt in range(_MAX_RETRIES):
            req = Request(url, data=body, headers=headers, method=method)
            try:
                with urlopen(req, timeout=self.timeout) as resp:
                    resp_body = resp.read().decode("utf-8")
                    if resp_body:
                        return json.loads(resp_body)
                    return None
            except HTTPError as exc:
                last_exc = exc
                if exc.code not in _RETRYABLE_STATUS:
                    logger.warning("HTTP %s %s failed: %s %s", method, path, exc.code, exc.reason)
                    return None
                # Retryable server error — back off and retry
            except URLError as exc:
                last_exc = exc
                # Connection failures are retryable
            except Exception as exc:
                last_exc = exc

            if attempt < _MAX_RETRIES - 1:
                backoff = 0.5 * (2 ** attempt)  # 0.5s, 1s, 2s
                logger.debug("Retry %d/%d for %s %s in %.1fs", attempt + 1, _MAX_RETRIES, method, path, backoff)
                time.sleep(backoff)

        logger.warning("Request %s %s failed after %d attempts: %s", method, path, _MAX_RETRIES, last_exc)
        return None

    # -- Connection lifecycle --

    def connect(self) -> None:
        """Validate API key by hitting the health endpoint.

        Sets ``_connected = True`` even if the server is unreachable so
        that offline/queued usage remains possible.
        """
        result = self._request("GET", "/v1/health")
        if result is None:
            logger.warning(
                "Could not reach %s/v1/health -- continuing in offline mode",
                self.api_url,
            )
        self._connected = True

    def disconnect(self) -> None:
        """Mark the connection as closed."""
        self._connected = False

    # -- Pipeline lifecycle --

    def create_pipeline(
        self,
        pipeline_name: str,
        config: Optional[Dict[str, Any]] = None,
        git_commit: Optional[str] = None,
        tenant_id: Optional[str] = None,
    ) -> int:
        payload = {
            "pipeline_name": pipeline_name,
            "config": config,
            "git_commit": git_commit,
            "tenant_id": tenant_id or self.tenant_id,
        }
        result = self._request("POST", "/v1/pipelines", data=payload)
        if result and "pipeline_id" in result:
            return result["pipeline_id"]
        logger.warning("create_pipeline got no pipeline_id; returning 0")
        return 0

    def complete_pipeline(self, pipeline_id: int, status: str = "completed") -> None:
        payload = {"status": status}
        self._request("PATCH", f"/v1/pipelines/{pipeline_id}", data=payload)

    # -- DAG storage --

    def store_nodes(self, nodes: List[StoredNode]) -> None:
        if not nodes:
            return
        for i in range(0, len(nodes), self.batch_size):
            batch = nodes[i : i + self.batch_size]
            payload = [
                {
                    "fingerprint": n.fingerprint,
                    "node_type": n.node_type,
                    "operation": n.operation,
                    "table_name": n.table_name,
                    "column_name": n.column_name,
                    "pair_id": n.pair_id,
                    "is_protected": n.is_protected,
                    "entity_hash": n.entity_hash,
                    "chain_hash": n.chain_hash,
                    "metadata": n.metadata,
                    "pipeline_id": n.pipeline_id,
                }
                for n in batch
            ]
            self._request("POST", "/v1/nodes", data=payload)

    def store_edges(self, edges: List[StoredEdge]) -> None:
        if not edges:
            return
        for i in range(0, len(edges), self.batch_size):
            batch = edges[i : i + self.batch_size]
            payload = [
                {
                    "parent_fingerprint": e.parent_fingerprint,
                    "child_fingerprint": e.child_fingerprint,
                    "input_position": e.input_position,
                }
                for e in batch
            ]
            self._request("POST", "/v1/edges", data=payload)

    def store_edges_resolved(self, edges: List[Tuple[int, int, int]]) -> None:
        if not edges:
            return
        for i in range(0, len(edges), self.batch_size):
            batch = edges[i : i + self.batch_size]
            payload = [
                {
                    "parent_node_id": parent_id,
                    "child_node_id": child_id,
                    "input_position": pos,
                }
                for parent_id, child_id, pos in batch
            ]
            self._request("POST", "/v1/edges", data=payload)

    def register_source(
        self,
        pair_id: int,
        table: str,
        column: str,
        is_protected: bool = False,
    ) -> None:
        payload = {
            "pair_id": pair_id,
            "table_name": table,
            "column_name": column,
            "is_protected": is_protected,
        }
        self._request("POST", "/v1/sources", data=payload)

    # -- Per-row results --

    def store_results(self, pipeline_id: int, results: List[tuple]) -> None:
        if not results:
            return
        for i in range(0, len(results), self.batch_size):
            batch = results[i : i + self.batch_size]
            payload = {
                "pipeline_id": pipeline_id,
                "results": [
                    {
                        "row_key": row[0],
                        "output_name": row[1],
                        "fingerprint": row[2],
                        "output_value": row[3],
                        "input_hash": row[4] if len(row) > 4 else None,
                    }
                    for row in batch
                ],
            }
            self._request("POST", "/v1/results", data=payload)

    # -- Query methods --

    def get_node_by_fingerprint(
        self,
        fingerprint: int,
        pipeline_id: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        params = f"?fingerprint={fingerprint}"
        if pipeline_id is not None:
            params += f"&pipeline_id={pipeline_id}"
        return self._request("GET", f"/v1/nodes{params}")

    def get_edges_for_node(self, node_id: int) -> List[Dict[str, Any]]:
        result = self._request("GET", f"/v1/edges?node_id={node_id}")
        if isinstance(result, list):
            return result
        return []

    def get_fingerprint_node_map(self, pipeline_id: int) -> Dict[int, int]:
        result = self._request("GET", f"/v1/nodes/fingerprint-map?pipeline_id={pipeline_id}")
        if isinstance(result, dict):
            return {int(k): int(v) for k, v in result.items()}
        return {}

    def get_source_info(self, pair_id: int) -> Optional[Tuple[str, str, bool]]:
        result = self._request("GET", f"/v1/sources?pair_id={pair_id}")
        if result and "table_name" in result:
            return (result["table_name"], result["column_name"], result.get("is_protected", False))
        return None

    def get_results_for_row(
        self,
        row_key: str,
        pipeline_id: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        params = f"?row_key={row_key}"
        if pipeline_id is not None:
            params += f"&pipeline_id={pipeline_id}"
        result = self._request("GET", f"/v1/results{params}")
        if isinstance(result, list):
            return result
        return []

    # -- Dashboard / stats --

    def get_stats(self) -> Dict[str, Any]:
        result = self._request("GET", "/v1/stats")
        if isinstance(result, dict):
            return result
        return {}
