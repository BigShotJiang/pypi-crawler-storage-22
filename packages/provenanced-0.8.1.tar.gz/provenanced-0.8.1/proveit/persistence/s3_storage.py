"""
S3-backed storage backend for ProveIt provenance.

Uses SQLite locally during pipeline execution for zero-overhead writes,
then uploads the completed database file to S3 for long-term audit storage.
Downloads from S3 when needed for querying or compliance review.

This is the simplest cloud storage option: no database server to manage,
no connection strings, no schema migrations. Just an S3 bucket.

Usage:
    from proveit.persistence.s3_storage import S3Storage

    # Run a pipeline with S3-backed provenance
    with S3Storage(bucket="my-provenance", prefix="prod") as storage:
        pipeline_id = storage.create_pipeline("loan_scoring_v3")
        storage.store_nodes(nodes)
        storage.store_edges(edges)
        storage.store_results(pipeline_id, results)
        storage.complete_pipeline(pipeline_id)
        # SQLite DB is auto-uploaded to S3 on exit

    # Later: download and query for audit
    querier = S3Storage.download("my-provenance", pipeline_id=1, prefix="prod")
    results = querier.get_results_for_row("applicant_42")
    querier.disconnect()

    # List all stored pipelines
    pipelines = S3Storage.list_pipelines("my-provenance", prefix="prod")

Requires:
    pip install boto3
"""

import json
import logging
import os
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .sqlite_storage import SQLiteStorage
from .storage import StorageBackend, StoredEdge, StoredNode

logger = logging.getLogger(__name__)

_INDEX_FILENAME = "index.json"


def _require_boto3():
    """Lazily import and return the boto3 module.

    Raises ImportError with clear install instructions if boto3 is
    not available.
    """
    try:
        import boto3
        return boto3
    except ImportError:
        raise ImportError(
            "S3Storage requires the boto3 package.\n"
            "Install it with:\n"
            "    pip install boto3\n"
            "Or install proveit with S3 extras:\n"
            "    pip install provenanced[s3]"
        )


class S3Storage(StorageBackend):
    """S3-backed provenance storage using local SQLite + S3 sync.

    Architecture:
        1. Pipeline writes go to a local SQLite file (fast, zero overhead).
        2. When the pipeline completes (or on disconnect), the SQLite file
           is uploaded to S3 at ``s3://{bucket}/{prefix}/pipeline_{id}.db``.
        3. An ``index.json`` file in S3 tracks all pipeline databases with
           metadata (name, timestamps, status).
        4. For audit queries, download a specific pipeline DB from S3 and
           query it locally with full SQLite performance.

    S3 Key Layout::

        s3://{bucket}/{prefix}/
            pipeline_1.db       # Complete SQLite database
            pipeline_2.db       # Complete SQLite database
            index.json          # Pipeline metadata index

    Parameters:
        bucket: S3 bucket name.
        prefix: S3 key prefix (default ``"provenance"``). Acts as a
            namespace so multiple environments can share a bucket.
        region: AWS region name (optional; uses boto3/env defaults).
        local_dir: Directory for temporary SQLite files. If ``None``,
            a new temporary directory is created and cleaned up on
            disconnect.
        storage_class: S3 storage class for uploaded files. Defaults to
            ``INTELLIGENT_TIERING`` which auto-tiers data between
            frequent and infrequent access, saving up to 68% vs
            Standard for compliance data accessed mainly during
            examinations. Options: ``STANDARD``,
            ``INTELLIGENT_TIERING``, ``STANDARD_IA``, ``GLACIER_IR``.
    """

    # S3 storage classes optimized for compliance data retention.
    # INTELLIGENT_TIERING is the best default: auto-tiers between
    # frequent and infrequent access with no retrieval fees, saving
    # up to 68% vs. S3 Standard for audit data accessed rarely.
    STORAGE_CLASS_STANDARD = "STANDARD"
    STORAGE_CLASS_INTELLIGENT_TIERING = "INTELLIGENT_TIERING"
    STORAGE_CLASS_STANDARD_IA = "STANDARD_IA"
    STORAGE_CLASS_GLACIER_IR = "GLACIER_IR"

    def __init__(
        self,
        bucket: str,
        prefix: str = "provenance",
        region: Optional[str] = None,
        local_dir: Optional[str] = None,
        storage_class: str = "INTELLIGENT_TIERING",
    ):
        self.bucket = bucket
        self.prefix = prefix.strip("/")
        self.region = region
        self.storage_class = storage_class

        self._owns_local_dir = local_dir is None
        if local_dir is not None:
            self.local_dir = str(Path(local_dir).resolve())
            os.makedirs(self.local_dir, exist_ok=True)
        else:
            self.local_dir = tempfile.mkdtemp(prefix="proveit_s3_")

        self._sqlite: Optional[SQLiteStorage] = None
        self._s3_client: Any = None
        self._current_pipeline_id: Optional[int] = None
        self._uploaded_pipeline_ids: set = set()
        self._dirty = False

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Create a local SQLite database and initialize the S3 client.

        The boto3 import happens here (lazy), so users without boto3
        installed will get a clear error only when they actually try
        to use S3Storage.
        """
        boto3 = _require_boto3()

        if self.region:
            self._s3_client = boto3.client("s3", region_name=self.region)
        else:
            self._s3_client = boto3.client("s3")

        db_path = os.path.join(self.local_dir, "current.db")
        self._sqlite = SQLiteStorage(db_path)
        self._sqlite.connect()
        self._dirty = False

        logger.info(
            "S3Storage connected: bucket=%s prefix=%s local=%s",
            self.bucket, self.prefix, self.local_dir,
        )

    def disconnect(self) -> None:
        """Close the local database and upload to S3 if dirty.

        If there is an active pipeline that has not been uploaded yet,
        a final sync is performed before closing the connection.

        Raises:
            RuntimeError: If the final S3 sync fails. This prevents
                silent data loss of compliance audit trails, which is
                unacceptable for bank examiner requirements.
        """
        sync_error = None
        if self._sqlite is not None:
            if self._dirty and self._current_pipeline_id is not None:
                try:
                    self.sync_to_s3()
                except Exception as exc:
                    logger.exception(
                        "Failed to sync pipeline %s to S3 on disconnect",
                        self._current_pipeline_id,
                    )
                    sync_error = exc
            self._sqlite.disconnect()
            self._sqlite = None

        if self._owns_local_dir and os.path.isdir(self.local_dir):
            shutil.rmtree(self.local_dir, ignore_errors=True)

        self._s3_client = None
        self._current_pipeline_id = None
        self._dirty = False

        if sync_error is not None:
            raise RuntimeError(
                "Failed to sync provenance data to S3 on disconnect. "
                "Audit trail may be incomplete."
            ) from sync_error

    def __enter__(self):
        """Context manager entry -- connects if needed."""
        if self._sqlite is None:
            self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit -- disconnects (uploads if dirty)."""
        self.disconnect()
        return False

    def __del__(self):
        """Best-effort cleanup on garbage collection.

        Suppresses RuntimeError from sync failures since __del__ cannot
        propagate exceptions, but logs at ERROR level so production
        monitoring (Splunk/ELK/Datadog) can catch it.
        """
        try:
            self.disconnect()
        except RuntimeError:
            logger.error(
                "S3Storage.__del__: failed to sync pipeline %s to S3. "
                "Use disconnect() explicitly or a context manager to "
                "catch sync failures.",
                self._current_pipeline_id,
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    # S3 operations
    # ------------------------------------------------------------------

    def _s3_key(self, filename: str) -> str:
        """Build a full S3 key from the prefix and a filename."""
        return f"{self.prefix}/{filename}"

    def sync_to_s3(self) -> str:
        """Upload the current SQLite database to S3.

        Returns the S3 key of the uploaded file.

        Raises:
            RuntimeError: If not connected or no pipeline has been created.
        """
        if self._sqlite is None or self._s3_client is None:
            raise RuntimeError("S3Storage is not connected")
        if self._current_pipeline_id is None:
            raise RuntimeError(
                "No pipeline to sync. Call create_pipeline() first."
            )

        if self._sqlite.conn:
            self._sqlite.conn.commit()

        db_path = self._sqlite.db_path
        s3_filename = f"pipeline_{self._current_pipeline_id}.db"
        s3_key = self._s3_key(s3_filename)

        logger.info(
            "Uploading %s to s3://%s/%s (StorageClass=%s)",
            db_path, self.bucket, s3_key, self.storage_class,
        )
        extra_args = {}
        if self.storage_class != self.STORAGE_CLASS_STANDARD:
            extra_args["StorageClass"] = self.storage_class
        self._s3_client.upload_file(
            db_path, self.bucket, s3_key, ExtraArgs=extra_args or None,
        )

        self._uploaded_pipeline_ids.add(self._current_pipeline_id)
        self._dirty = False

        self._update_index(
            pipeline_id=self._current_pipeline_id,
            s3_key=s3_key,
        )

        return s3_key

    def _update_index(self, pipeline_id: int, s3_key: str) -> None:
        """Update the index.json file in S3 with pipeline metadata."""
        index_key = self._s3_key(_INDEX_FILENAME)
        index = self._load_index()

        pipeline_name = None
        status = None
        if self._sqlite and self._sqlite.conn:
            cursor = self._sqlite.conn.cursor()
            cursor.execute(
                "SELECT pipeline_name, status FROM pipeline_metadata "
                "WHERE pipeline_id = ?",
                (pipeline_id,),
            )
            row = cursor.fetchone()
            if row:
                pipeline_name = row[0]
                status = row[1]

        now = datetime.now(timezone.utc).isoformat()
        entry = {
            "pipeline_id": pipeline_id,
            "s3_key": s3_key,
            "pipeline_name": pipeline_name,
            "status": status,
            "uploaded_at": now,
        }

        existing_ids = {p["pipeline_id"] for p in index.get("pipelines", [])}
        if pipeline_id in existing_ids:
            index["pipelines"] = [
                entry if p["pipeline_id"] == pipeline_id else p
                for p in index["pipelines"]
            ]
        else:
            index.setdefault("pipelines", []).append(entry)

        index["updated_at"] = now

        self._s3_client.put_object(
            Bucket=self.bucket,
            Key=index_key,
            Body=json.dumps(index, indent=2),
            ContentType="application/json",
        )

    def _load_index(self) -> Dict[str, Any]:
        """Load the index.json from S3, returning empty dict if missing."""
        index_key = self._s3_key(_INDEX_FILENAME)
        try:
            response = self._s3_client.get_object(
                Bucket=self.bucket, Key=index_key,
            )
            return json.loads(response["Body"].read().decode("utf-8"))
        except self._s3_client.exceptions.NoSuchKey:
            return {"pipelines": [], "updated_at": None}
        except Exception:
            logger.debug("Could not load index.json, starting fresh")
            return {"pipelines": [], "updated_at": None}

    @staticmethod
    def download(
        bucket: str,
        pipeline_id: int,
        prefix: str = "provenance",
        region: Optional[str] = None,
        local_dir: Optional[str] = None,
    ) -> SQLiteStorage:
        """Download a pipeline database from S3 and return a connected SQLiteStorage.

        This is the primary way to access historical provenance data for
        audit, compliance review, or litigation support.

        Parameters:
            bucket: S3 bucket name.
            pipeline_id: The pipeline ID to download.
            prefix: S3 key prefix (must match the prefix used during upload).
            region: AWS region (optional).
            local_dir: Where to store the downloaded file. If ``None``,
                uses a temporary directory.

        Returns:
            A connected ``SQLiteStorage`` instance pointing at the
            downloaded database. The caller is responsible for calling
            ``disconnect()`` when done.

        Raises:
            FileNotFoundError: If the pipeline database does not exist in S3.
        """
        boto3 = _require_boto3()

        if region:
            s3 = boto3.client("s3", region_name=region)
        else:
            s3 = boto3.client("s3")

        s3_key = f"{prefix.strip('/')}/pipeline_{pipeline_id}.db"

        if local_dir is None:
            local_dir = tempfile.mkdtemp(prefix="proveit_s3_download_")
        else:
            os.makedirs(local_dir, exist_ok=True)

        local_path = os.path.join(local_dir, f"pipeline_{pipeline_id}.db")

        try:
            s3.download_file(bucket, s3_key, local_path)
        except s3.exceptions.ClientError as exc:
            error_code = exc.response.get("Error", {}).get("Code", "")
            if error_code in ("404", "NoSuchKey"):
                raise FileNotFoundError(
                    f"Pipeline {pipeline_id} not found at "
                    f"s3://{bucket}/{s3_key}"
                ) from exc
            raise

        logger.info(
            "Downloaded s3://%s/%s to %s", bucket, s3_key, local_path,
        )

        storage = SQLiteStorage(local_path)
        storage.connect()
        return storage

    @staticmethod
    def list_pipelines(
        bucket: str,
        prefix: str = "provenance",
        region: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List all pipeline databases stored in S3.

        Reads the ``index.json`` metadata file. If the index is missing
        or unreadable, falls back to listing ``.db`` files by S3 prefix.

        Parameters:
            bucket: S3 bucket name.
            prefix: S3 key prefix.
            region: AWS region (optional).

        Returns:
            List of dicts with pipeline metadata (pipeline_id, s3_key,
            pipeline_name, status, uploaded_at).
        """
        boto3 = _require_boto3()

        if region:
            s3 = boto3.client("s3", region_name=region)
        else:
            s3 = boto3.client("s3")

        clean_prefix = prefix.strip("/")
        index_key = f"{clean_prefix}/{_INDEX_FILENAME}"

        try:
            response = s3.get_object(Bucket=bucket, Key=index_key)
            index = json.loads(response["Body"].read().decode("utf-8"))
            return index.get("pipelines", [])
        except Exception:
            pass

        pipelines = []
        paginator = s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(
            Bucket=bucket, Prefix=f"{clean_prefix}/pipeline_",
        ):
            for obj in page.get("Contents", []):
                key = obj["Key"]
                filename = key.rsplit("/", 1)[-1]
                if filename.startswith("pipeline_") and filename.endswith(".db"):
                    pid_str = filename[len("pipeline_"):-len(".db")]
                    try:
                        pid = int(pid_str)
                    except ValueError:
                        continue
                    pipelines.append({
                        "pipeline_id": pid,
                        "s3_key": key,
                        "pipeline_name": None,
                        "status": None,
                        "uploaded_at": obj.get("LastModified", "").isoformat()
                        if obj.get("LastModified") else None,
                    })

        return sorted(pipelines, key=lambda p: p["pipeline_id"])

    # ------------------------------------------------------------------
    # Pipeline lifecycle (delegates to SQLite, tracks dirty state)
    # ------------------------------------------------------------------

    def create_pipeline(
        self,
        pipeline_name: str,
        config: Optional[Dict[str, Any]] = None,
        git_commit: Optional[str] = None,
        tenant_id: Optional[str] = None,
    ) -> int:
        """Create a pipeline execution record.

        Returns pipeline_id. Also sets this as the current pipeline for
        automatic S3 sync on disconnect or complete.
        """
        self._ensure_connected()
        pipeline_id = self._sqlite.create_pipeline(
            pipeline_name, config, git_commit, tenant_id,
        )
        self._current_pipeline_id = pipeline_id
        self._dirty = True
        return pipeline_id

    def complete_pipeline(
        self, pipeline_id: int, status: str = "completed",
    ) -> None:
        """Mark pipeline as completed and upload the database to S3.

        This is the primary upload trigger: the full SQLite database
        (with all nodes, edges, sources, and results) is uploaded as a
        single file to S3.
        """
        self._ensure_connected()
        self._sqlite.complete_pipeline(pipeline_id, status)
        self._current_pipeline_id = pipeline_id
        self.sync_to_s3()

    # ------------------------------------------------------------------
    # DAG storage (pure delegation + dirty flag)
    # ------------------------------------------------------------------

    def store_nodes(self, nodes: List[StoredNode]) -> None:
        """Store DAG nodes (delegates to SQLite)."""
        self._ensure_connected()
        self._sqlite.store_nodes(nodes)
        if nodes:
            self._dirty = True

    def store_edges(self, edges: List[StoredEdge]) -> None:
        """Store DAG edges by fingerprint (delegates to SQLite)."""
        self._ensure_connected()
        self._sqlite.store_edges(edges)
        if edges:
            self._dirty = True

    def store_edges_resolved(
        self, edges: List[Tuple[int, int, int]],
    ) -> None:
        """Store edges with resolved node IDs (delegates to SQLite)."""
        self._ensure_connected()
        self._sqlite.store_edges_resolved(edges)
        if edges:
            self._dirty = True

    def register_source(
        self, pair_id: int, table: str, column: str,
        is_protected: bool = False,
    ) -> None:
        """Register a source pair (delegates to SQLite)."""
        self._ensure_connected()
        self._sqlite.register_source(pair_id, table, column, is_protected)
        self._dirty = True

    # ------------------------------------------------------------------
    # Query methods (pure delegation)
    # ------------------------------------------------------------------

    def get_node_by_fingerprint(
        self, fingerprint: int, pipeline_id: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        """Retrieve a node by fingerprint (delegates to SQLite)."""
        self._ensure_connected()
        return self._sqlite.get_node_by_fingerprint(fingerprint, pipeline_id)

    def get_edges_for_node(self, node_id: int) -> List[Dict[str, Any]]:
        """Get parent edges for a node (delegates to SQLite)."""
        self._ensure_connected()
        return self._sqlite.get_edges_for_node(node_id)

    def get_fingerprint_node_map(self, pipeline_id: int) -> Dict[int, int]:
        """Return fingerprint-to-node_id mapping (delegates to SQLite)."""
        self._ensure_connected()
        return self._sqlite.get_fingerprint_node_map(pipeline_id)

    # ------------------------------------------------------------------
    # Results (audit trail)
    # ------------------------------------------------------------------

    def store_results(
        self, pipeline_id: int, results: List[tuple],
    ) -> None:
        """Store per-row audit results (delegates to SQLite)."""
        self._ensure_connected()
        self._sqlite.store_results(pipeline_id, results)
        if results:
            self._dirty = True

    def get_results_for_row(
        self, row_key: str, pipeline_id: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Look up provenance for a specific row (delegates to SQLite)."""
        self._ensure_connected()
        return self._sqlite.get_results_for_row(row_key, pipeline_id)

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def get_stats(self) -> Dict[str, Any]:
        """Return node/edge/source/result counts plus S3 metadata."""
        self._ensure_connected()
        stats = self._sqlite.get_stats()
        stats["s3_bucket"] = self.bucket
        stats["s3_prefix"] = self.prefix
        stats["s3_storage_class"] = self.storage_class
        stats["s3_uploaded_pipelines"] = len(self._uploaded_pipeline_ids)
        return stats

    @staticmethod
    def recommended_lifecycle_policy() -> Dict[str, Any]:
        """Return a recommended S3 lifecycle policy for compliance data.

        This policy aligns with regulatory retention requirements:
        - ECOA: 25 months minimum (12 CFR 1002.12)
        - SR 11-7: 5 years recommended
        - EU AI Act: 10 years for technical documentation
        - BSA/AML: 5 years

        The policy uses S3 Intelligent-Tiering for the first 2 years
        (covers ECOA), transitions to Glacier Instant Retrieval at
        year 2 (still accessible in milliseconds for examinations),
        and to Glacier Deep Archive at year 10 for maximum cost
        savings on long-term retention.

        Cost savings vs S3 Standard over 10 years: ~72%.

        Returns a dict that can be passed to
        ``s3.put_bucket_lifecycle_configuration()``.
        """
        return {
            "Rules": [
                {
                    "ID": "proveit-compliance-lifecycle",
                    "Status": "Enabled",
                    "Filter": {"Prefix": "provenance/"},
                    "Transitions": [
                        {
                            "Days": 730,  # 2 years (covers ECOA 25mo)
                            "StorageClass": "GLACIER_IR",
                        },
                        {
                            "Days": 3650,  # 10 years
                            "StorageClass": "DEEP_ARCHIVE",
                        },
                    ],
                },
            ],
        }

    def apply_lifecycle_policy(self) -> None:
        """Apply the recommended lifecycle policy to the S3 bucket.

        Requires the ``s3:PutLifecycleConfiguration`` permission.
        Safe to call multiple times -- overwrites the existing policy.
        """
        if self._s3_client is None:
            raise RuntimeError("S3Storage is not connected")
        policy = self.recommended_lifecycle_policy()
        self._s3_client.put_bucket_lifecycle_configuration(
            Bucket=self.bucket,
            LifecycleConfiguration=policy,
        )
        logger.info(
            "Applied compliance lifecycle policy to s3://%s",
            self.bucket,
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _ensure_connected(self) -> None:
        """Raise RuntimeError if not connected."""
        if self._sqlite is None:
            raise RuntimeError(
                "S3Storage is not connected. Call connect() or use as "
                "a context manager."
            )
