"""Tests for CRO value-add features."""

import pytest
from datetime import datetime, timedelta, timezone

from proveit.compliance.base import (
    ComplianceFinding,
    ComplianceReport,
    ComplianceResult,
    Severity,
)
from proveit.compliance.score import ComplianceScorer, ComplianceScoreResult
from proveit.compliance.cro_features import (
    AttestationManager,
    AttestationStatus,
    HeatmapCell,
    ImpactAssessment,
    PeerBenchmark,
    PeerComparisonResult,
    QuickWin,
    QuickWinRecommender,
    RegulatoryChange,
    RegulatoryChangeAssessor,
    RemediationItem,
    RemediationPriority,
    RemediationQueue,
    RiskHeatmap,
    RiskHeatmapData,
    RiskLevel,
)
from proveit.governance.exception_tracker import (
    ComplianceException,
    EscalationLevel,
    ExceptionStatus,
    ExceptionTracker,
)
from proveit.governance.model_registry import (
    ModelRecord,
    ModelRegistry,
    MonitoringResult,
    ValidationRecord,
)


# ---------------------------------------------------------------------------
# Test fixtures
# ---------------------------------------------------------------------------

def _make_report(
    sr117_criticals=1,
    sr117_warnings=1,
    ecoa_criticals=0,
    ecoa_warnings=1,
):
    """Create a test compliance report with configurable findings."""
    report = ComplianceReport()

    sr_findings = []
    for i in range(sr117_criticals):
        sr_findings.append(ComplianceFinding(
            severity=Severity.CRITICAL,
            description=f"SR 11-7 critical finding {i+1}",
            regulation_citation="SR 11-7 III.B",
            remediation=f"Fix critical issue {i+1}",
        ))
    for i in range(sr117_warnings):
        sr_findings.append(ComplianceFinding(
            severity=Severity.WARNING,
            description=f"SR 11-7 warning {i+1}",
            regulation_citation="SR 11-7 III.A",
            remediation=f"Address warning {i+1}",
        ))
    report.add(ComplianceResult(
        passed=sr117_criticals == 0,
        regulation_name="SR 11-7 / OCC 2011-12",
        findings=sr_findings,
    ))

    ecoa_findings = []
    for i in range(ecoa_criticals):
        ecoa_findings.append(ComplianceFinding(
            severity=Severity.CRITICAL,
            description=f"ECOA critical finding {i+1}",
            regulation_citation="12 CFR 1002.9",
            remediation=f"Fix ECOA issue {i+1}",
        ))
    for i in range(ecoa_warnings):
        ecoa_findings.append(ComplianceFinding(
            severity=Severity.WARNING,
            description=f"ECOA warning {i+1}",
            regulation_citation="12 CFR 1002.4",
            remediation=f"Address ECOA warning {i+1}",
        ))
    report.add(ComplianceResult(
        passed=ecoa_criticals == 0,
        regulation_name="ECOA / Reg B",
        findings=ecoa_findings,
    ))

    return report


def _make_registry():
    """Create a test model registry."""
    registry = ModelRegistry()
    registry.register(ModelRecord(
        model_id="credit_v1",
        name="Consumer Credit Score v1",
        version="1.0.0",
        tier=1,
        owner="Model Risk",
        domain="lending",
        status="production",
        description="Consumer credit scoring",
        data_sources=["credit_bureau"],
        protected_attributes=["race", "gender"],
    ))
    registry.register(ModelRecord(
        model_id="fraud_v2",
        name="Fraud Detection v2",
        version="2.1.0",
        tier=2,
        owner="Fraud Team",
        domain="fraud",
        status="production",
    ))
    registry.register(ModelRecord(
        model_id="marketing_v1",
        name="Marketing Segmentation",
        version="1.0.0",
        tier=3,
        owner="Marketing",
        domain="marketing",
        status="production",
    ))
    return registry


def _make_score_result():
    """Create a test ComplianceScoreResult."""
    scorer = ComplianceScorer()
    report = _make_report()
    return scorer.score(report)


# ===========================================================================
# 1. Risk Heatmap Tests
# ===========================================================================

class TestRiskHeatmap:
    def test_generate_from_reports(self):
        heatmap = RiskHeatmap()
        report = _make_report()
        data = heatmap.generate({"model_a": report, "model_b": report})
        assert len(data.models) == 2
        assert len(data.regulations) == 2
        assert len(data.cells) == 4

    def test_generate_from_scores(self):
        heatmap = RiskHeatmap()
        result = _make_score_result()
        data = heatmap.generate_from_scores({"model_a": result})
        assert len(data.cells) == 2
        assert "SR 11-7 / OCC 2011-12" in data.regulations

    def test_risk_classification(self):
        heatmap = RiskHeatmap()
        assert heatmap._classify_risk(2, 0) == RiskLevel.CRITICAL
        assert heatmap._classify_risk(1, 0) == RiskLevel.HIGH
        assert heatmap._classify_risk(0, 3) == RiskLevel.MEDIUM
        assert heatmap._classify_risk(0, 0) == RiskLevel.LOW

    def test_heatmap_to_dict(self):
        heatmap = RiskHeatmap()
        report = _make_report()
        data = heatmap.generate({"model_a": report})
        d = data.to_dict()
        assert "matrix" in d
        assert "summary" in d
        assert d["summary"]["total_cells"] == 2

    def test_empty_reports(self):
        heatmap = RiskHeatmap()
        data = heatmap.generate({})
        assert len(data.cells) == 0
        assert len(data.models) == 0

    def test_scorer_convenience_method(self):
        scorer = ComplianceScorer()
        report = _make_report()
        data = scorer.risk_heatmap({"model_a": report})
        assert len(data.cells) == 2


# ===========================================================================
# 2. Revalidation Needed Tests
# ===========================================================================

class TestRevalidationNeeded:
    def test_flags_unvalidated_models(self):
        registry = _make_registry()
        flagged = registry.revalidation_needed()
        assert len(flagged) >= 1
        ids = [f["model_id"] for f in flagged]
        assert "credit_v1" in ids

    def test_priority_ordering(self):
        registry = _make_registry()
        flagged = registry.revalidation_needed()
        tiers = [f["tier"] for f in flagged]
        assert tiers == sorted(tiers)

    def test_flags_failed_monitoring(self):
        registry = _make_registry()
        registry.record_monitoring("credit_v1", MonitoringResult(
            date=datetime.now(timezone.utc),
            monitor_type="fairness",
            passed=False,
            alerts=["DI ratio below threshold"],
        ))
        flagged = registry.revalidation_needed()
        credit_flags = [f for f in flagged if f["model_id"] == "credit_v1"]
        assert len(credit_flags) == 1
        reasons = credit_flags[0]["reasons"]
        assert any("FAILED" in r for r in reasons)

    def test_flags_low_compliance_score(self):
        registry = _make_registry()
        registry.update_compliance_score("credit_v1", 45.0)
        flagged = registry.revalidation_needed()
        credit_flags = [f for f in flagged if f["model_id"] == "credit_v1"]
        assert any("below threshold" in r for r in credit_flags[0]["reasons"])

    def test_trigger_revalidation(self):
        registry = _make_registry()
        result = registry.trigger_revalidation("credit_v1", "CRO", "Overdue")
        assert result["new_status"] == "under_review"
        assert result["previous_status"] == "production"
        model = registry.get("credit_v1")
        assert model.status == "under_review"

    def test_trigger_revalidation_not_found(self):
        registry = _make_registry()
        with pytest.raises(KeyError):
            registry.trigger_revalidation("nonexistent")


# ===========================================================================
# 3. Peer Comparison Tests
# ===========================================================================

class TestPeerBenchmark:
    def test_basic_comparison(self):
        benchmark = PeerBenchmark(institution_tier="mid")
        result = _make_score_result()
        peer = benchmark.compare(result)
        assert 1 <= peer.overall_percentile <= 99
        assert peer.institution_tier == "mid"

    def test_tier_adjustments(self):
        result = _make_score_result()
        mid = PeerBenchmark("mid").compare(result)
        large = PeerBenchmark("large").compare(result)
        community = PeerBenchmark("community").compare(result)
        assert community.overall_percentile >= mid.overall_percentile
        assert mid.overall_percentile >= large.overall_percentile

    def test_per_regulation_breakdown(self):
        benchmark = PeerBenchmark()
        result = _make_score_result()
        peer = benchmark.compare(result)
        assert "SR 11-7 / OCC 2011-12" in peer.per_regulation

    def test_summary_output(self):
        benchmark = PeerBenchmark()
        result = _make_score_result()
        peer = benchmark.compare(result)
        summary = peer.summary()
        assert "percentile" in summary.lower()

    def test_to_dict(self):
        benchmark = PeerBenchmark()
        result = _make_score_result()
        peer = benchmark.compare(result)
        d = peer.to_dict()
        assert "overall_percentile" in d
        assert "per_regulation" in d

    def test_high_score_high_percentile(self):
        report = ComplianceReport()
        report.add(ComplianceResult(
            passed=True, regulation_name="SR 11-7 / OCC 2011-12", findings=[],
        ))
        scorer = ComplianceScorer()
        result = scorer.score(report, {"has_monitoring": True, "has_fairness_analysis": True})
        benchmark = PeerBenchmark()
        peer = benchmark.compare(result)
        assert peer.overall_percentile >= 90


# ===========================================================================
# 4. Exception Tracking Tests
# ===========================================================================

class TestExceptionTracker:
    def test_create_exception(self):
        with ExceptionTracker() as tracker:
            exc = tracker.create(
                model_id="credit_v1",
                regulation="SR 11-7",
                exception_type="deferred_validation",
                justification="Shadow scoring",
                requested_by="Jane Smith",
            )
            assert exc.status == ExceptionStatus.PENDING
            assert exc.model_id == "credit_v1"

    def test_approve_exception(self):
        with ExceptionTracker() as tracker:
            exc = tracker.create(
                model_id="credit_v1",
                regulation="SR 11-7",
                exception_type="deferred_validation",
                justification="Shadow scoring",
                requested_by="Jane Smith",
            )
            exc = tracker.approve(
                exc.exception_id, "John Doe", "CRO", level=3,
            )
            assert exc.status == ExceptionStatus.APPROVED
            assert len(exc.approvals) == 1

    def test_reject_exception(self):
        with ExceptionTracker() as tracker:
            exc = tracker.create(
                model_id="credit_v1",
                regulation="SR 11-7",
                exception_type="deferred_validation",
                justification="test",
                requested_by="Jane",
            )
            exc = tracker.reject(
                exc.exception_id, "John", "CRO", reason="Insufficient justification",
            )
            assert exc.status == ExceptionStatus.REJECTED

    def test_close_exception(self):
        with ExceptionTracker() as tracker:
            exc = tracker.create(
                model_id="credit_v1",
                regulation="SR 11-7",
                exception_type="temp",
                justification="test",
                requested_by="Jane",
            )
            tracker.approve(exc.exception_id, "John")
            exc = tracker.close(exc.exception_id)
            assert exc.status == ExceptionStatus.CLOSED

    def test_get_by_model(self):
        with ExceptionTracker() as tracker:
            tracker.create(
                model_id="credit_v1", regulation="SR 11-7",
                exception_type="temp", justification="test",
                requested_by="Jane",
            )
            tracker.create(
                model_id="fraud_v2", regulation="SR 11-7",
                exception_type="temp", justification="test",
                requested_by="Jane",
            )
            credit_excs = tracker.get_by_model("credit_v1")
            assert len(credit_excs) == 1

    def test_escalation_approaching(self):
        with ExceptionTracker() as tracker:
            exc = tracker.create(
                model_id="credit_v1", regulation="SR 11-7",
                exception_type="temp", justification="test",
                requested_by="Jane", expires_in_days=10,
            )
            tracker.approve(exc.exception_id, "John")
            alerts = tracker.check_escalations()
            assert len(alerts) == 1
            assert alerts[0].level == EscalationLevel.APPROACHING

    def test_escalation_imminent(self):
        with ExceptionTracker() as tracker:
            exc = tracker.create(
                model_id="credit_v1", regulation="SR 11-7",
                exception_type="temp", justification="test",
                requested_by="Jane", expires_in_days=5,
            )
            tracker.approve(exc.exception_id, "John")
            alerts = tracker.check_escalations()
            assert len(alerts) == 1
            assert alerts[0].level == EscalationLevel.IMMINENT

    def test_summary(self):
        with ExceptionTracker() as tracker:
            exc = tracker.create(
                model_id="credit_v1", regulation="SR 11-7",
                exception_type="temp", justification="test",
                requested_by="Jane",
            )
            tracker.approve(exc.exception_id, "John")
            summary = tracker.summary()
            assert summary["active_exceptions"] == 1
            assert summary["approved"] == 1

    def test_get_not_found(self):
        with ExceptionTracker() as tracker:
            with pytest.raises(KeyError):
                tracker.get("nonexistent")

    def test_to_dict(self):
        with ExceptionTracker() as tracker:
            exc = tracker.create(
                model_id="credit_v1", regulation="SR 11-7",
                exception_type="temp", justification="test",
                requested_by="Jane",
            )
            d = exc.to_dict()
            assert "exception_id" in d
            assert "escalation_level" in d
            assert d["is_active"] is True


# ===========================================================================
# 5. Remediation Priority Queue Tests
# ===========================================================================

class TestRemediationQueue:
    def test_build_from_report(self):
        queue = RemediationQueue()
        report = _make_report()
        items = queue.build(report)
        assert len(items) >= 2

    def test_priority_ordering(self):
        queue = RemediationQueue()
        report = _make_report(sr117_criticals=2, ecoa_warnings=3)
        items = queue.build(report)
        scores = [i.priority_score for i in items]
        assert scores == sorted(scores, reverse=True)

    def test_critical_findings_urgent(self):
        queue = RemediationQueue()
        report = _make_report(sr117_criticals=1)
        items = queue.build(report)
        critical_items = [
            i for i in items if i.severity == "CRITICAL"
        ]
        assert all(
            i.priority in (RemediationPriority.URGENT, RemediationPriority.HIGH)
            for i in critical_items
        )

    def test_info_findings_excluded(self):
        report = ComplianceReport()
        report.add(ComplianceResult(
            passed=True,
            regulation_name="SR 11-7 / OCC 2011-12",
            findings=[ComplianceFinding(
                severity=Severity.INFO,
                description="Info only",
                regulation_citation="SR 11-7",
            )],
        ))
        queue = RemediationQueue()
        items = queue.build(report)
        assert len(items) == 0

    def test_affected_models(self):
        queue = RemediationQueue()
        report = _make_report()
        items = queue.build(report, affected_models={
            "SR 11-7 / OCC 2011-12": ["credit_v1", "fraud_v2"],
        })
        sr_items = [i for i in items if "SR 11-7" in i.regulation]
        assert all(len(i.affected_models) == 2 for i in sr_items)

    def test_to_dict(self):
        queue = RemediationQueue()
        report = _make_report()
        items = queue.build(report)
        d = items[0].to_dict()
        assert "priority_score" in d
        assert "deadline" in d
        assert "business_impact" in d


# ===========================================================================
# 6. Quick Win Tests
# ===========================================================================

class TestQuickWins:
    def test_recommends_missing_controls(self):
        recommender = QuickWinRecommender()
        result = _make_score_result()
        wins = recommender.recommend(result, {})
        assert len(wins) >= 1
        actions = [w.action for w in wins]
        assert any("monitoring" in a.lower() for a in actions)

    def test_no_recommendations_when_all_controls_active(self):
        recommender = QuickWinRecommender()
        report = ComplianceReport()
        report.add(ComplianceResult(
            passed=True, regulation_name="SR 11-7 / OCC 2011-12", findings=[],
        ))
        scorer = ComplianceScorer()
        result = scorer.score(report, {
            "has_monitoring": True,
            "has_fairness_analysis": True,
            "has_decision_logging": True,
            "has_data_governance": True,
            "has_model_inventory": True,
            "has_certifications": True,
        })
        wins = recommender.recommend(result, {
            "has_monitoring": True,
            "has_fairness_analysis": True,
            "has_decision_logging": True,
            "has_data_governance": True,
            "has_model_inventory": True,
            "has_certifications": True,
        })
        assert len(wins) == 0

    def test_sorted_by_impact(self):
        recommender = QuickWinRecommender()
        result = _make_score_result()
        wins = recommender.recommend(result, {})
        impacts = [w.estimated_score_impact for w in wins]
        assert impacts == sorted(impacts, reverse=True)

    def test_max_recommendations(self):
        recommender = QuickWinRecommender()
        result = _make_score_result()
        wins = recommender.recommend(result, {}, max_recommendations=2)
        assert len(wins) <= 2

    def test_scorer_convenience(self):
        scorer = ComplianceScorer()
        report = _make_report()
        result = scorer.score(report)
        wins = scorer.quick_wins(result)
        assert isinstance(wins, list)
        assert all(isinstance(w, dict) for w in wins)

    def test_to_dict(self):
        recommender = QuickWinRecommender()
        result = _make_score_result()
        wins = recommender.recommend(result)
        d = wins[0].to_dict()
        assert "action" in d
        assert "estimated_score_impact" in d
        assert "effort" in d


# ===========================================================================
# 7. Attestation Workflow Tests
# ===========================================================================

class TestAttestationManager:
    def test_request_attestation(self):
        with AttestationManager() as mgr:
            att = mgr.request_attestation(
                report_type="compliance_score",
                report_data={"score": 85},
                attester_name="John Doe",
                attester_title="CRO",
                score=85.0,
            )
            assert att.status == AttestationStatus.PENDING

    def test_attest(self):
        with AttestationManager() as mgr:
            att = mgr.request_attestation(
                report_type="compliance_score",
                report_data={"score": 85},
                attester_name="John Doe",
                attester_title="CRO",
            )
            att = mgr.attest(att.attestation_id, "Reviewed")
            assert att.status == AttestationStatus.ATTESTED
            assert att.is_valid

    def test_reject(self):
        with AttestationManager() as mgr:
            att = mgr.request_attestation(
                report_type="compliance_score",
                report_data={"score": 85},
                attester_name="John Doe",
                attester_title="CRO",
            )
            att = mgr.reject(att.attestation_id, "Score too low")
            assert att.status == AttestationStatus.REJECTED

    def test_verify_intact(self):
        with AttestationManager() as mgr:
            data = {"score": 85, "grade": "B"}
            att = mgr.request_attestation(
                "compliance_score", data, "John", "CRO",
            )
            mgr.attest(att.attestation_id)
            valid, msg = mgr.verify(att.attestation_id, data)
            assert valid

    def test_verify_tampered(self):
        with AttestationManager() as mgr:
            data = {"score": 85, "grade": "B"}
            att = mgr.request_attestation(
                "compliance_score", data, "John", "CRO",
            )
            mgr.attest(att.attestation_id)
            tampered = {"score": 99, "grade": "A"}
            valid, msg = mgr.verify(att.attestation_id, tampered)
            assert not valid
            assert "modified" in msg.lower()

    def test_get_pending(self):
        with AttestationManager() as mgr:
            mgr.request_attestation(
                "compliance_score", {}, "John", "CRO",
            )
            mgr.request_attestation(
                "fairness_analysis", {}, "Jane", "CRO",
            )
            pending = mgr.get_pending()
            assert len(pending) == 2

    def test_get_active(self):
        with AttestationManager() as mgr:
            att = mgr.request_attestation(
                "compliance_score", {}, "John", "CRO",
            )
            mgr.attest(att.attestation_id)
            active = mgr.get_active()
            assert len(active) == 1

    def test_attest_not_found(self):
        with AttestationManager() as mgr:
            with pytest.raises(KeyError):
                mgr.attest("nonexistent")

    def test_attest_already_attested(self):
        with AttestationManager() as mgr:
            att = mgr.request_attestation(
                "compliance_score", {}, "John", "CRO",
            )
            mgr.attest(att.attestation_id)
            with pytest.raises(ValueError):
                mgr.attest(att.attestation_id)

    def test_to_dict(self):
        with AttestationManager() as mgr:
            att = mgr.request_attestation(
                "compliance_score", {"score": 85}, "John", "CRO",
                score=85.0, grade="B",
            )
            d = att.to_dict()
            assert d["status"] == "pending"
            assert d["score_at_attestation"] == 85.0


# ===========================================================================
# 8. Regulatory Change Impact Tests
# ===========================================================================

class TestRegulatoryChangeAssessor:
    def test_basic_assessment(self):
        assessor = RegulatoryChangeAssessor()
        registry = _make_registry()
        change = RegulatoryChange(
            regulation="ECOA / Reg B",
            change_type="new_requirement",
            description="New adverse action requirements",
            affected_domains=["lending"],
        )
        impact = assessor.assess(change, registry)
        assert len(impact.impacted_models) >= 1

    def test_domain_matching(self):
        assessor = RegulatoryChangeAssessor()
        registry = _make_registry()
        change = RegulatoryChange(
            regulation="SR 11-7 / OCC 2011-12",
            change_type="amendment",
            description="Updated model risk guidance",
            affected_domains=["fraud"],
        )
        impact = assessor.assess(change, registry)
        ids = [m.model_id for m in impact.impacted_models]
        assert "fraud_v2" in ids

    def test_keyword_matching(self):
        assessor = RegulatoryChangeAssessor()
        registry = _make_registry()
        change = RegulatoryChange(
            regulation="EU AI Act",
            change_type="new_requirement",
            description="New transparency requirements",
            keywords=["credit scoring", "credit bureau"],
        )
        impact = assessor.assess(change, registry)
        ids = [m.model_id for m in impact.impacted_models]
        assert "credit_v1" in ids

    def test_tier_based_impact_levels(self):
        assessor = RegulatoryChangeAssessor()
        registry = _make_registry()
        change = RegulatoryChange(
            regulation="ECOA / Reg B",
            change_type="enforcement",
            description="CFPB enforcement action",
            affected_domains=["lending", "fraud", "marketing"],
        )
        impact = assessor.assess(change, registry)
        tier1 = [m for m in impact.impacted_models if m.tier == 1]
        tier3 = [m for m in impact.impacted_models if m.tier == 3]
        if tier1:
            assert tier1[0].impact_level == "high"
        if tier3:
            assert tier3[0].impact_level == "low"

    def test_score_impact_negative(self):
        assessor = RegulatoryChangeAssessor()
        registry = _make_registry()
        change = RegulatoryChange(
            regulation="ECOA / Reg B",
            change_type="new_requirement",
            description="New requirements",
            affected_domains=["lending"],
        )
        impact = assessor.assess(change, registry)
        assert impact.estimated_compliance_impact <= 0

    def test_recommended_actions(self):
        assessor = RegulatoryChangeAssessor()
        registry = _make_registry()
        change = RegulatoryChange(
            regulation="ECOA / Reg B",
            change_type="enforcement",
            description="Enforcement action",
            affected_domains=["lending"],
        )
        impact = assessor.assess(change, registry)
        assert len(impact.recommended_actions) >= 1
        assert any("legal" in a.lower() for a in impact.recommended_actions)

    def test_days_until_effective(self):
        assessor = RegulatoryChangeAssessor()
        registry = _make_registry()
        change = RegulatoryChange(
            regulation="ECOA / Reg B",
            change_type="deadline",
            description="New deadline",
            effective_date=datetime.now(timezone.utc) + timedelta(days=60),
            affected_domains=["lending"],
        )
        impact = assessor.assess(change, registry)
        assert impact.days_until_effective is not None
        assert 59 <= impact.days_until_effective <= 60

    def test_no_impact_when_no_match(self):
        assessor = RegulatoryChangeAssessor()
        registry = _make_registry()
        change = RegulatoryChange(
            regulation="Some Other Regulation",
            change_type="new_requirement",
            description="Unrelated change",
            affected_domains=["insurance"],
        )
        impact = assessor.assess(change, registry)
        assert len(impact.impacted_models) == 0
        assert impact.estimated_compliance_impact == 0.0

    def test_to_dict(self):
        assessor = RegulatoryChangeAssessor()
        registry = _make_registry()
        change = RegulatoryChange(
            regulation="ECOA / Reg B",
            change_type="new_requirement",
            description="Test change",
            affected_domains=["lending"],
        )
        impact = assessor.assess(change, registry)
        d = impact.to_dict()
        assert "impacted_model_count" in d
        assert "recommended_actions" in d

    def test_summary_output(self):
        assessor = RegulatoryChangeAssessor()
        registry = _make_registry()
        change = RegulatoryChange(
            regulation="ECOA / Reg B",
            change_type="new_requirement",
            description="Test change",
            affected_domains=["lending"],
        )
        impact = assessor.assess(change, registry)
        summary = impact.summary()
        assert "REGULATORY CHANGE" in summary
        assert "IMPACTED MODELS" in summary


# ===========================================================================
# Integration: ComplianceScoreResult peer_percentile field
# ===========================================================================

class TestScoreResultPeerPercentile:
    def test_peer_percentile_field_default_none(self):
        result = _make_score_result()
        assert result.peer_percentile is None
        assert result.peer_tier is None

    def test_peer_percentile_in_to_dict_when_set(self):
        result = _make_score_result()
        result.peer_percentile = 72
        result.peer_tier = "mid"
        d = result.to_dict()
        assert d["peer_percentile"] == 72
        assert d["peer_tier"] == "mid"

    def test_peer_percentile_omitted_when_none(self):
        result = _make_score_result()
        d = result.to_dict()
        assert "peer_percentile" not in d
