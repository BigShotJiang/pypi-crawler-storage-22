"""
End-to-End Integration Tests.

Exercises the full ProveIt pipeline the way a bank CRO would use it:
    1. Instrument a data pipeline with HYDRA-24
    2. Run FairLens fairness analysis
    3. Run compliance engines
    4. Calculate compliance score
    5. Generate model card and examiner package
    6. Check model registry lifecycle tracking

These tests ensure all modules integrate correctly.
"""

import pytest
from datetime import datetime, timezone, timedelta

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression

from proveit import (
    DAGTracker,
    wrap_dataframe,
    get_dag,
)
from proveit.compliance import (
    ComplianceReport,
    ECOAEngine,
    SR117Engine,
    EUAIActEngine,
)
from proveit.compliance.score import ComplianceScorer
from proveit.fairness import FairLensEngine, FairLensConfig
from proveit.governance import (
    PIIDetector,
    RetentionPolicyEngine,
    RegulatoryCalendar,
    ModelRegistry,
    ModelRecord,
)
from proveit.governance.model_registry import ValidationRecord, MonitoringResult
from proveit.examiner import ModelCardGenerator, ExaminerPackage
from proveit.vendor import PlatformHealthCheck


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def fair_credit_data():
    """Generate fair credit data with no disparate impact."""
    rng = np.random.RandomState(42)
    n = 500
    df = pd.DataFrame({
        "income": rng.lognormal(10.8, 0.4, n).astype(int),
        "debt_to_income": rng.uniform(0.1, 0.5, n).round(2),
        "credit_score": rng.normal(720, 50, n).astype(int).clip(500, 850),
        "employment_years": rng.exponential(8, n).round(1).clip(1, 30),
        "loan_amount": rng.lognormal(11.0, 0.3, n).astype(int),
        "race": rng.choice(["White", "Black", "Hispanic", "Asian"], n),
        "sex": rng.choice(["M", "F"], n),
        "ssn_last4": [f"{rng.randint(1000, 9999)}" for _ in range(n)],
    })
    # Fair approval based only on creditworthiness, not demographics
    score = (
        0.4 * (df["credit_score"] - 500) / 350
        + 0.3 * (1 - df["debt_to_income"])
        + 0.2 * np.log1p(df["income"]) / 15
        + 0.1 * df["employment_years"] / 30
        + rng.normal(0, 0.05, n)
    )
    df["approved"] = (score > 0.45).astype(int)
    return df


@pytest.fixture
def trained_model(fair_credit_data):
    """Train a logistic regression on the fair data."""
    df = fair_credit_data
    feature_cols = ["income", "debt_to_income", "credit_score",
                    "employment_years", "loan_amount"]
    X = df[feature_cols]
    y = df["approved"]
    model = LogisticRegression(max_iter=500, random_state=42)
    model.fit(X, y)
    return model, X, y, feature_cols


@pytest.fixture
def compliant_metadata():
    """Metadata for a well-documented, compliant model."""
    return {
        "model_type": "logistic_regression",
        "domain": "lending",
        "model_id": "fair_credit_v1",
        "model_version": "1.0.0",
        "model_tier": "high",
        "model_purpose": "Consumer credit underwriting",
        "model_owner": "Model Risk Management",
        "is_adverse_action": True,
        "adverse_action_reasons": [
            "Low credit score",
            "High debt-to-income ratio",
            "Insufficient employment history",
            "Loan amount exceeds capacity",
        ],
        "record_retention_months": 60,
        "risk_tier": "high",
        "model_validation_date": "2026-01-15",
        "monitoring_plan": "Quarterly FairLens re-analysis",
        "has_validation": True,
        "has_monitoring": True,
        "has_documentation": True,
        "independent_validation": True,
        "independent_validator": "Internal Model Validation Group",
        "challenger_model": True,
        "challenger_model_type": "Decision tree baseline",
        "use_limitations": "Consumer unsecured lending only",
        "concentration_risk_assessed": True,
        "vendor_model": False,
        "governance_framework": True,
        "documentation_completeness": 0.90,
        "disparate_impact_analysis": {"race": 0.92, "sex": 0.95},
        "intersectional_impact_analysis": [
            {"attribute_pair": ["race", "sex"], "worst_ratio": 0.88},
        ],
        "hmda_reportable": True,
        "collected_demographics": ["race", "ethnicity", "sex"],
        "monitoring_purpose_disclosed": True,
        "explanation_method": "coefficients",
        "explanation_confidence": 0.95,
        # EU AI Act
        "risk_classification": "high",
        "human_oversight": True,
        "human_oversight_measures": "Senior underwriter reviews all denials",
        "technical_documentation": True,
        "conformity_assessment": True,
        "data_governance_measures": True,
    }


# ---------------------------------------------------------------------------
# Integration Tests
# ---------------------------------------------------------------------------

class TestFullPipeline:
    """Test the complete bank compliance pipeline end-to-end."""

    def test_hydra24_provenance_tracking(self, fair_credit_data):
        """HYDRA-24 should track provenance on wrapped dataframes."""
        tracker = DAGTracker()
        wrapped = wrap_dataframe(
            fair_credit_data[["income", "loan_amount"]],
            tracker, "applications.csv",
        )
        ratio = wrapped["income"] / wrapped["loan_amount"]
        dag = get_dag(ratio)
        assert len(dag.nodes) >= 2
        assert len(dag.edges) >= 1

    def test_fairness_analysis_on_fair_model(
        self, fair_credit_data, trained_model,
    ):
        """FairLens should detect minimal/no DI on a fair model."""
        model, X, y, _ = trained_model
        protected_df = fair_credit_data[["race", "sex"]].reset_index(drop=True)

        config = FairLensConfig(
            protected_columns=["race", "sex"],
            run_lda_search=False,
        )
        engine = FairLensEngine(config)
        report = engine.analyze(
            model=model,
            X_train=X.reset_index(drop=True),
            y_train=y.values,
            X_test=X.reset_index(drop=True),
            y_test=y.values,
            protected_data=protected_df,
            model_name="fair_credit_v1",
        )
        assert report.model_identity is not None
        assert report.model_identity.model_hash != ""

    def test_compliance_engines_with_metadata(
        self, fair_credit_data, compliant_metadata,
    ):
        """Compliance engines should produce results with compliant metadata."""
        tracker = DAGTracker()
        wrapped = wrap_dataframe(
            fair_credit_data[["income", "loan_amount"]],
            tracker, "apps.csv",
        )
        dag = get_dag(wrapped["income"])

        report = ComplianceReport()
        report.run_engines(
            [ECOAEngine(), SR117Engine(), EUAIActEngine()],
            dag, compliant_metadata,
        )

        assert len(report.results) == 3
        # With compliant metadata, ECOA should pass (no DI in metadata)
        ecoa = report.results[0]
        assert ecoa.regulation_name == "ECOA / Reg B"

        # Check summary has expected structure
        summary = report.summary()
        assert "overall_passed" in summary
        assert "per_regulation" in summary

    def test_compliance_score_calculation(
        self, fair_credit_data, compliant_metadata,
    ):
        """ComplianceScorer should produce a valid score."""
        tracker = DAGTracker()
        wrapped = wrap_dataframe(
            fair_credit_data[["income"]], tracker, "apps.csv",
        )
        dag = get_dag(wrapped["income"])

        report = ComplianceReport()
        report.run_engines(
            [ECOAEngine(), SR117Engine(), EUAIActEngine()],
            dag, compliant_metadata,
        )

        scorer = ComplianceScorer()
        result = scorer.score(report, proactive_controls={
            "has_certifications": True,
            "has_monitoring": True,
            "has_fairness_analysis": True,
            "has_decision_logging": True,
            "has_data_governance": True,
            "has_model_inventory": True,
        })

        assert 0 <= result.score <= 100
        assert result.grade in ("A", "B", "C", "D", "F")
        assert result.engines_evaluated == 3
        assert result.to_dict()["score"] == round(result.score, 1)

    def test_pii_detection(self, fair_credit_data):
        """PIIDetector should flag protected attributes and financial data."""
        detector = PIIDetector()
        cols = list(fair_credit_data.columns)
        results = detector.classify_columns(cols)
        assert len(results) == len(cols)

        restricted = detector.restricted_columns(cols)
        assert "race" in restricted
        assert "sex" in restricted

        assert detector.has_pii(cols)

    def test_model_card_generation(self, compliant_metadata):
        """ModelCardGenerator should produce a valid model card."""
        generator = ModelCardGenerator()
        card = generator.generate(
            model_metadata={
                "name": "FairCredit v1.0",
                "type": "LogisticRegression",
                "version": "1.0.0",
                "owner": "MRM Team",
            },
        )
        md = card.to_markdown()
        assert "FairCredit" in md
        d = card.to_dict()
        assert "model_details" in d
        assert d["model_details"]["name"] == "FairCredit v1.0"

    def test_examiner_package_assembly(
        self, fair_credit_data, compliant_metadata,
    ):
        """ExaminerPackage should assemble all components."""
        tracker = DAGTracker()
        wrapped = wrap_dataframe(
            fair_credit_data[["income"]], tracker, "apps.csv",
        )
        dag = get_dag(wrapped["income"])

        # Compliance
        comp_report = ComplianceReport()
        comp_report.run_engines(
            [ECOAEngine(), SR117Engine()], dag, compliant_metadata,
        )

        # Model card
        gen = ModelCardGenerator()
        card = gen.generate(model_metadata={
            "name": "FairCredit v1.0",
            "type": "LogisticRegression",
        })

        # Assemble
        pkg = ExaminerPackage(
            institution_name="Test Bank",
            examination_type="fair_lending",
            prepared_by="ProveIt",
        )
        pkg.add_compliance_results(comp_report.to_dict())
        pkg.add_model_card(card.to_dict())

        assert pkg.completeness_score > 0
        bundle = pkg.generate()
        assert "all_sections" in bundle
        assert bundle["package_metadata"]["completeness_score"] > 0

    def test_model_registry_lifecycle(self):
        """ModelRegistry should track the full model lifecycle."""
        now = datetime.now(timezone.utc)
        registry = ModelRegistry()

        # Register
        model = ModelRecord(
            model_id="fair_credit_v1",
            name="Fair Credit Score",
            version="1.0.0",
            tier=1,
            owner="MRM Team",
            domain="lending",
            status="development",
        )
        registry.register(model)
        assert len(registry.all_models) == 1

        # Validate
        registry.record_validation("fair_credit_v1", ValidationRecord(
            validation_id="val_001",
            date=now,
            validator="Internal Validation Group",
            independent=True,
            result="approved",
            next_validation_date=now + timedelta(days=365),
        ))

        # Deploy
        registry.update_status("fair_credit_v1", "production")

        # Monitor
        registry.record_monitoring("fair_credit_v1", MonitoringResult(
            date=now,
            monitor_type="fairness",
            passed=True,
            metrics={"di_ratio_race": 0.92},
        ))

        # Score
        registry.update_compliance_score("fair_credit_v1", 85.0)

        # Report
        report = registry.inventory_report()
        assert report["total_models"] == 1
        assert report["production_models"] == 1
        assert report["average_compliance_score"] == 85.0

        risk = registry.risk_summary()
        assert risk["tier_1_models"] == 1

    def test_platform_health_check(self):
        """PlatformHealthCheck should score across all dimensions."""
        health = PlatformHealthCheck()
        health.check_compliance_engines(
            engines_configured=["ecoa", "sr117", "eu_ai_act",
                               "colorado_ai_act", "nyc_ll144"],
        )
        health.check_fairness_monitoring(
            enabled=True,
            protected_attributes=["race", "sex"],
            monitoring_frequency="quarterly",
            has_intersectional=True,
        )
        health.check_decision_logging(
            enabled=True, format="jsonl", retention_days=760,
        )
        health.check_data_governance(
            classification_policy=True,
            pii_detection_enabled=True,
            retention_policy=True,
            lineage_tracking=True,
        )

        report = health.generate_report()
        assert "overall_score" in report
        assert report["overall_score"] >= 0

    def test_retention_policy_check(self):
        """RetentionPolicyEngine should enforce retention requirements."""
        engine = RetentionPolicyEngine()
        from datetime import date
        # "credit_applications" is a valid category in default ECOA policy
        violations = engine.check_retention(
            data_category="credit_applications",
            created_date=date(2024, 1, 1),
            deleted_date=date(2024, 6, 1),  # Deleted after 5 months (< 25)
        )
        assert len(violations) > 0
        assert any(v.violation_type == "under_retention" for v in violations)

    def test_regulatory_calendar(self):
        """RegulatoryCalendar should have deadlines."""
        cal = RegulatoryCalendar()
        upcoming = cal.upcoming(days=365 * 3)
        assert len(upcoming) > 0
        report = cal.generate_report()
        # Report has 'all_deadlines' key
        assert "all_deadlines" in report
        assert len(report["all_deadlines"]) > 0
