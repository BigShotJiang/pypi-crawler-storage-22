"""
Comprehensive tests for FairLens: Automated Fair Lending Analysis.

Tests cover:
- Disparate impact analysis
- Proxy variable detection
- LDA search
- Adverse action generation
- End-to-end analysis engine
"""

import json
import numpy as np
import pandas as pd
import pytest

from proveit.fairness.disparate_impact import DisparateImpactAnalyzer, DisparateImpactResult
from proveit.fairness.proxy_detection import ProxyDetector, ProxyResult
from proveit.fairness.lda_search import LDASearcher, LDACandidate
from proveit.fairness.adverse_action import AdverseActionGenerator, ApplicantExplanation
from proveit.fairness.engine import FairLensEngine, FairLensConfig, FairLensReport, Finding
from proveit.hydra24_dag import DAGTracker


def _make_credit_data(n=1000, seed=42):
    """Generate synthetic credit data with known disparate impact."""
    rng = np.random.RandomState(seed)

    race = rng.choice(["white", "black", "hispanic", "asian"], n, p=[0.6, 0.2, 0.15, 0.05])
    sex = rng.choice(["male", "female"], n, p=[0.5, 0.5])
    age = rng.randint(21, 70, n)

    income = rng.normal(60000, 20000, n)
    income[race == "black"] -= 10000
    income[race == "hispanic"] -= 5000
    income = np.clip(income, 15000, 200000)

    credit_score = rng.normal(700, 80, n)
    credit_score[race == "black"] -= 30
    credit_score[race == "hispanic"] -= 15
    credit_score = np.clip(credit_score, 300, 850).astype(int)

    dti = rng.uniform(0.1, 0.6, n)
    zip_code = rng.choice(["10001", "10002", "10003", "10004", "10005"], n)

    zip_race_map = {"10001": "white", "10002": "white", "10003": "black",
                    "10004": "hispanic", "10005": "asian"}
    for i in range(n):
        if rng.random() < 0.7:
            for zc, dominant in zip_race_map.items():
                if race[i] == dominant:
                    zip_code[i] = zc
                    break

    approved = (
        (credit_score > 650).astype(int) +
        (income > 40000).astype(int) +
        (dti < 0.4).astype(int)
    ) >= 2
    approved = approved.astype(int)

    noise = rng.random(n) < 0.05
    approved[noise] = 1 - approved[noise]

    return pd.DataFrame({
        "income": income,
        "credit_score": credit_score,
        "dti": dti,
        "zip_code": zip_code,
        "employment_length": rng.randint(0, 30, n),
        "loan_amount": rng.uniform(5000, 100000, n),
        "race": race,
        "sex": sex,
        "age": age,
        "approved": approved,
    })


@pytest.fixture
def credit_data():
    return _make_credit_data()


@pytest.fixture
def split_data(credit_data):
    n = len(credit_data)
    split = int(n * 0.7)
    feature_cols = ["income", "credit_score", "dti", "zip_code", "employment_length", "loan_amount"]
    protected_cols = ["race", "sex", "age"]

    X = credit_data[feature_cols].copy()
    X["zip_code"] = X["zip_code"].astype("category").cat.codes
    y = credit_data["approved"].values
    protected = credit_data[protected_cols]

    return {
        "X_train": X.iloc[:split],
        "X_test": X.iloc[split:],
        "y_train": y[:split],
        "y_test": y[split:],
        "protected_train": protected.iloc[:split],
        "protected_test": protected.iloc[split:],
    }


@pytest.fixture
def trained_model(split_data):
    from sklearn.ensemble import GradientBoostingClassifier
    model = GradientBoostingClassifier(n_estimators=50, max_depth=3, random_state=42)
    model.fit(split_data["X_train"], split_data["y_train"])
    return model


class TestDisparateImpact:
    def test_basic_disparate_impact(self, split_data, trained_model):
        preds = trained_model.predict(split_data["X_test"])
        analyzer = DisparateImpactAnalyzer()

        results = analyzer.analyze(
            predictions=preds,
            protected_data=split_data["protected_test"],
            protected_columns=["race"],
        )

        assert len(results) == 1
        result = results[0]
        assert result.protected_attribute == "race"
        assert len(result.group_metrics) >= 2
        assert result.reference_rate > 0

    def test_multiple_attributes(self, split_data, trained_model):
        preds = trained_model.predict(split_data["X_test"])
        analyzer = DisparateImpactAnalyzer()

        results = analyzer.analyze(
            predictions=preds,
            protected_data=split_data["protected_test"],
            protected_columns=["race", "sex"],
        )

        assert len(results) == 2
        attrs = {r.protected_attribute for r in results}
        assert attrs == {"race", "sex"}

    def test_no_disparate_impact_equal_rates(self):
        preds = np.ones(100)
        protected = pd.DataFrame({"group": ["A"] * 50 + ["B"] * 50})

        analyzer = DisparateImpactAnalyzer()
        results = analyzer.analyze(preds, protected, ["group"])

        assert len(results) == 1
        assert not results[0].has_disparate_impact

    def test_clear_disparate_impact(self):
        preds = np.array([1]*80 + [0]*20 + [1]*30 + [0]*70)
        protected = pd.DataFrame({"group": ["A"]*100 + ["B"]*100})

        analyzer = DisparateImpactAnalyzer()
        results = analyzer.analyze(preds, protected, ["group"])

        assert len(results) == 1
        assert results[0].has_disparate_impact
        assert results[0].worst_ratio < 0.80

    def test_with_scores(self, split_data, trained_model):
        preds = trained_model.predict(split_data["X_test"])
        scores = trained_model.predict_proba(split_data["X_test"])[:, 1]
        analyzer = DisparateImpactAnalyzer()

        results = analyzer.analyze(
            predictions=preds,
            protected_data=split_data["protected_test"],
            protected_columns=["race"],
            scores=scores,
        )

        for gm in results[0].group_metrics:
            assert gm.average_score is not None

    def test_to_dict(self):
        result = DisparateImpactResult(
            protected_attribute="race",
            reference_group="white",
            reference_rate=0.80,
            group_metrics=[],
            adverse_impact_ratios={"black": 0.65},
            has_disparate_impact=True,
            worst_ratio=0.65,
            worst_group="black",
        )
        d = result.to_dict()
        assert d["has_disparate_impact"] is True
        assert d["worst_ratio"] == 0.65


class TestProxyDetection:
    def test_zip_code_proxy(self, credit_data):
        features = credit_data[["zip_code", "income", "credit_score"]].copy()
        protected = credit_data[["race"]]

        detector = ProxyDetector(correlation_threshold=0.3)
        results = detector.detect(features, protected, ["race"])

        zip_proxies = [r for r in results if r.feature_name == "zip_code"]
        assert len(zip_proxies) >= 1
        assert zip_proxies[0].known_proxy

    def test_income_correlation(self, credit_data):
        features = credit_data[["income", "credit_score"]].copy()
        protected = credit_data[["race"]]

        detector = ProxyDetector(correlation_threshold=0.1)
        results = detector.detect(features, protected, ["race"])

        income_results = [r for r in results if r.feature_name == "income"]
        assert len(income_results) >= 1
        assert income_results[0].correlation > 0

    def test_no_proxy_unrelated(self):
        rng = np.random.RandomState(42)
        features = pd.DataFrame({
            "random_a": rng.uniform(0, 1, 500),
            "random_b": rng.uniform(0, 1, 500),
        })
        protected = pd.DataFrame({
            "group": rng.choice(["A", "B"], 500),
        })

        detector = ProxyDetector(correlation_threshold=0.5)
        results = detector.detect(features, protected, ["group"])
        assert len(results) == 0

    def test_known_proxy_patterns(self):
        detector = ProxyDetector()
        known = detector._check_known_proxies("zip_code")
        assert "race" in known

        known2 = detector._check_known_proxies("census_tract_id")
        assert len(known2) > 0

        known3 = detector._check_known_proxies("credit_score")
        assert len(known3) == 0

    def test_causal_chain_geography(self):
        detector = ProxyDetector()
        chain = detector._build_causal_chain("zip_code", "race", 0.85, True)
        assert len(chain) >= 1
        assert any("geographic" in c.mechanism.lower() or "segregation" in c.mechanism.lower()
                    for c in chain)

    def test_cramers_v(self):
        x = pd.Series(["A", "A", "B", "B"] * 50)
        y = pd.Series(["X", "Y", "X", "Y"] * 50)
        v = ProxyDetector._cramers_v(x, y)
        assert 0 <= v <= 1

    def test_correlation_ratio(self):
        cats = pd.Series(["A"] * 100 + ["B"] * 100)
        vals = pd.Series([10.0] * 100 + [20.0] * 100)
        eta = ProxyDetector._correlation_ratio(cats, vals)
        assert eta > 0.9

    def test_proxy_result_to_dict(self):
        from proveit.fairness.proxy_detection import CausalChainLink
        result = ProxyResult(
            feature_name="zip_code",
            protected_attribute="race",
            correlation=0.83,
            is_high_risk=True,
            causal_chain=[CausalChainLink("zip_code", "race", 0.83, "geographic")],
            known_proxy=True,
            recommendation="Remove zip_code",
        )
        d = result.to_dict()
        assert d["correlation"] == 0.83
        assert d["is_high_risk"] is True


class TestLDASearch:
    def test_basic_lda_search(self, split_data, trained_model):
        from sklearn.ensemble import GradientBoostingClassifier

        searcher = LDASearcher(max_auc_loss=0.05)

        def factory():
            return GradientBoostingClassifier(n_estimators=50, max_depth=3, random_state=42)

        candidates = searcher.search(
            X_train=split_data["X_train"],
            y_train=split_data["y_train"],
            X_test=split_data["X_test"],
            y_test=split_data["y_test"],
            protected_test=split_data["protected_test"],
            protected_column="race",
            proxy_features=["zip_code"],
            model_factory=factory,
        )

        assert len(candidates) >= 1
        for c in candidates:
            assert "zip_code" in c.removed_features
            assert c.original_auc > 0

    def test_lda_with_substitutes(self, split_data):
        from sklearn.ensemble import GradientBoostingClassifier

        searcher = LDASearcher()

        def factory():
            return GradientBoostingClassifier(n_estimators=30, max_depth=2, random_state=42)

        candidates = searcher.search(
            X_train=split_data["X_train"],
            y_train=split_data["y_train"],
            X_test=split_data["X_test"],
            y_test=split_data["y_test"],
            protected_test=split_data["protected_test"],
            protected_column="race",
            proxy_features=["zip_code"],
            model_factory=factory,
            substitute_features=["employment_length"],
        )

        sub_candidates = [c for c in candidates if c.added_features]
        assert len(sub_candidates) >= 1

    def test_lda_candidate_to_dict(self):
        c = LDACandidate(
            removed_features=["zip_code"],
            added_features=[],
            original_auc=0.85,
            candidate_auc=0.84,
            auc_loss=0.01,
            auc_loss_pct=1.2,
            original_disparity=0.74,
            candidate_disparity=0.82,
            disparity_improvement=0.08,
            disparity_improvement_pct=30.8,
            passes_four_fifths=True,
            recommendation="RECOMMENDED",
        )
        d = c.to_dict()
        assert d["passes_four_fifths"] is True
        assert d["auc_loss"] == 0.01


class TestAdverseAction:
    def test_generate_reasons(self, split_data, trained_model):
        preds = trained_model.predict(split_data["X_test"])

        generator = AdverseActionGenerator(max_reasons=4)
        explanations = generator.generate(
            model=trained_model,
            X=split_data["X_test"],
            predictions=preds,
        )

        denied = [e for e in explanations if e.prediction == 0]
        assert len(denied) > 0

        for exp in denied[:5]:
            assert exp.prediction == 0
            assert len(exp.reasons) > 0, (
                f"ECOA violation: denied applicant {exp.applicant_index} has zero adverse action reasons"
            )
            assert len(exp.reasons) <= 4

    def test_all_applicants(self, split_data, trained_model):
        preds = trained_model.predict(split_data["X_test"])

        generator = AdverseActionGenerator()
        explanations = generator.generate(
            model=trained_model,
            X=split_data["X_test"],
            predictions=preds,
            denied_only=False,
        )

        assert len(explanations) == len(split_data["X_test"])

    def test_feature_mapping(self):
        generator = AdverseActionGenerator()

        codes = generator._map_to_reason_codes("credit_utilization_ratio")
        assert len(codes) > 0
        assert all(c.startswith(("A", "B", "C", "D", "E", "F", "G", "H", "I"))
                    for c in codes)

    def test_explanation_to_dict(self):
        from proveit.fairness.adverse_action import AdverseActionReason
        exp = ApplicantExplanation(
            applicant_index=0,
            prediction=0,
            probability=0.3,
            reasons=[AdverseActionReason(
                rank=1, reason_code="F01",
                reason_text="Income insufficient", feature_name="income",
                feature_value=25000, feature_importance=-0.5,
                contribution_direction="negative",
            )],
            top_positive_features=[("credit_score", 0.3)],
            top_negative_features=[("income", -0.5)],
        )
        d = exp.to_dict()
        assert d["prediction"] == 0
        assert len(d["reasons"]) == 1
        assert d["reasons"][0]["code"] == "F01"


class TestFairLensEngine:
    def test_full_analysis(self, split_data, trained_model):
        from sklearn.ensemble import GradientBoostingClassifier

        config = FairLensConfig(
            protected_columns=["race", "sex"],
            run_lda_search=True,
            run_adverse_action=True,
        )
        engine = FairLensEngine(config=config)

        def factory():
            return GradientBoostingClassifier(n_estimators=50, max_depth=3, random_state=42)

        report = engine.analyze(
            model=trained_model,
            X_train=split_data["X_train"],
            y_train=split_data["y_train"],
            X_test=split_data["X_test"],
            y_test=split_data["y_test"],
            protected_data=split_data["protected_test"],
            model_name="test_credit_model",
            model_factory=factory,
        )

        assert isinstance(report, FairLensReport)
        assert report.model_name == "test_credit_model"
        assert len(report.findings) > 0
        assert len(report.disparate_impact_results) >= 2
        assert report.analysis_time_seconds > 0
        assert report.summary["total_findings"] > 0

    def test_analysis_no_lda(self, split_data, trained_model):
        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=False,
        )
        engine = FairLensEngine(config=config)

        report = engine.analyze(
            model=trained_model,
            X_train=split_data["X_train"],
            y_train=split_data["y_train"],
            X_test=split_data["X_test"],
            y_test=split_data["y_test"],
            protected_data=split_data["protected_test"],
        )

        assert len(report.lda_candidates) == 0
        assert len(report.adverse_action_samples) == 0

    def test_report_to_json(self, split_data, trained_model):
        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=False,
        )
        engine = FairLensEngine(config=config)

        report = engine.analyze(
            model=trained_model,
            X_train=split_data["X_train"],
            y_train=split_data["y_train"],
            X_test=split_data["X_test"],
            y_test=split_data["y_test"],
            protected_data=split_data["protected_test"],
        )

        j = report.to_json()
        parsed = json.loads(j)
        assert "findings" in parsed
        assert "disparate_impact" in parsed
        assert "summary" in parsed


class TestEndToEnd:
    def test_biased_model_detection(self):
        """Verify FairLens detects known bias in a synthetic model."""
        rng = np.random.RandomState(123)
        n = 500

        race = rng.choice(["A", "B"], n, p=[0.5, 0.5])
        income = rng.normal(50000, 15000, n)
        score = rng.normal(700, 50, n)

        # Deliberately bias: group B gets lower approval
        approved = np.zeros(n, dtype=int)
        for i in range(n):
            threshold = 0.4 if race[i] == "A" else 0.6
            if rng.random() > threshold:
                approved[i] = 1

        data = pd.DataFrame({
            "income": income, "credit_score": score, "approved": approved, "race": race,
        })

        from sklearn.tree import DecisionTreeClassifier
        X = data[["income", "credit_score"]]
        y = data["approved"]

        split = int(n * 0.7)
        model = DecisionTreeClassifier(max_depth=3, random_state=42)
        model.fit(X.iloc[:split], y.iloc[:split])

        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=True,
        )
        engine = FairLensEngine(config=config)

        report = engine.analyze(
            model=model,
            X_train=X.iloc[:split],
            y_train=y.iloc[:split].values,
            X_test=X.iloc[split:],
            y_test=y.iloc[split:].values,
            protected_data=data[["race"]].iloc[split:],
        )

        assert report.summary["total_findings"] > 0
        di_results = report.disparate_impact_results
        assert len(di_results) == 1


class TestIntegrationNoShap:
    """Integration tests verifying FairLens works WITHOUT SHAP installed.

    These tests create real sklearn models, generate predictions, and verify
    that the critical regulatory requirements are met using only the global
    feature_importances_ fallback path.
    """

    def _build_model_and_data(self):
        """Build a simple credit model with known disparate impact."""
        from sklearn.ensemble import RandomForestClassifier

        rng = np.random.RandomState(99)
        n = 600

        race = rng.choice(["white", "black"], n, p=[0.6, 0.4])
        income = rng.normal(55000, 15000, n)
        income[race == "black"] -= 20000
        income = np.clip(income, 15000, 150000)

        credit_score = rng.normal(700, 60, n)
        credit_score[race == "black"] -= 60
        credit_score = np.clip(credit_score, 300, 850).astype(int)

        dti = rng.uniform(0.15, 0.55, n)
        employment_length = rng.randint(0, 25, n)

        approved = (
            (credit_score > 640).astype(int)
            + (income > 35000).astype(int)
            + (dti < 0.42).astype(int)
        ) >= 2
        approved = approved.astype(int)

        noise = rng.random(n) < 0.03
        approved[noise] = 1 - approved[noise]

        data = pd.DataFrame({
            "income": income,
            "credit_score": credit_score,
            "dti": dti,
            "employment_length": employment_length,
            "race": race,
            "approved": approved,
        })

        feature_cols = ["income", "credit_score", "dti", "employment_length"]
        X = data[feature_cols]
        y = data["approved"].values
        protected = data[["race"]]

        split = int(n * 0.7)
        model = RandomForestClassifier(n_estimators=50, max_depth=4, random_state=42)
        model.fit(X.iloc[:split], y[:split])

        return model, X.iloc[split:], y[split:], protected.iloc[split:]

    def test_adverse_action_generates_reasons_without_shap(self):
        """CRITICAL: Denied applicants MUST receive > 0 adverse action reasons.

        This verifies the fix for the bug where feature_importances_ (all positive)
        caused zero reasons to be generated because the code only looked for
        negative importances.

        Regulatory requirement: ECOA 12 CFR 1002.9(a)(2).
        """
        model, X_test, y_test, protected = self._build_model_and_data()

        assert hasattr(model, 'feature_importances_'), "Model must have feature_importances_"
        assert all(v >= 0 for v in model.feature_importances_), (
            "Test requires all-positive importances (global fallback path)"
        )

        preds = model.predict(X_test)

        from proveit.fairness.adverse_action import AdverseActionGenerator
        generator = AdverseActionGenerator(max_reasons=4)
        explanations = generator.generate(
            model=model,
            X=X_test,
            predictions=preds,
        )

        denied = [e for e in explanations if e.prediction == 0]
        assert len(denied) > 0, "Test data must produce at least some denials"

        for exp in denied:
            assert len(exp.reasons) > 0, (
                f"ECOA violation: denied applicant {exp.applicant_index} "
                f"received zero adverse action reasons"
            )
            assert len(exp.reasons) <= 4

    def test_reason_codes_are_valid_ffiec(self):
        """Verify that generated reason codes map to valid FFIEC codes."""
        model, X_test, y_test, protected = self._build_model_and_data()
        preds = model.predict(X_test)

        from proveit.fairness.adverse_action import AdverseActionGenerator, FFIEC_REASON_CODES
        generator = AdverseActionGenerator(max_reasons=4)
        explanations = generator.generate(model=model, X=X_test, predictions=preds)

        denied = [e for e in explanations if e.prediction == 0]

        valid_prefixes = set("ABCDEFGHIZ")
        for exp in denied[:20]:
            for reason in exp.reasons:
                assert reason.reason_code[0] in valid_prefixes, (
                    f"Invalid reason code prefix: {reason.reason_code}"
                )
                assert len(reason.reason_code) == 3, (
                    f"Reason code must be 3 chars: {reason.reason_code}"
                )
                if not reason.reason_code.startswith("Z"):
                    assert reason.reason_code in FFIEC_REASON_CODES, (
                        f"Reason code {reason.reason_code} not in FFIEC table"
                    )
                assert len(reason.reason_text) > 0
                assert reason.rank >= 1

    def test_disparate_impact_detects_bias(self):
        """Verify disparate impact detection when approval rates differ significantly."""
        model, X_test, y_test, protected = self._build_model_and_data()
        preds = model.predict(X_test)

        from proveit.fairness.disparate_impact import DisparateImpactAnalyzer
        analyzer = DisparateImpactAnalyzer(threshold=0.80)
        results = analyzer.analyze(
            predictions=preds,
            protected_data=protected,
            protected_columns=["race"],
        )

        assert len(results) == 1
        result = results[0]

        assert len(result.group_metrics) == 2
        rates = {m.group_value: m.selection_rate for m in result.group_metrics}
        assert "white" in rates
        assert "black" in rates

        assert result.has_disparate_impact, (
            f"Expected disparate impact but ratio was {result.worst_ratio:.3f}. "
            f"Rates: white={rates.get('white', 0):.3f}, black={rates.get('black', 0):.3f}"
        )
        assert result.worst_ratio < 0.80

    def test_full_pipeline_integration(self):
        """End-to-end: engine produces findings with reasons for all denied applicants."""
        from proveit.fairness.engine import FairLensEngine, FairLensConfig

        model, X_test, y_test, protected = self._build_model_and_data()
        rng = np.random.RandomState(42)
        X_train = X_test.copy()
        y_train = y_test.copy()

        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=True,
        )
        engine = FairLensEngine(config=config)

        report = engine.analyze(
            model=model,
            X_train=X_train,
            y_train=y_train,
            X_test=X_test,
            y_test=y_test,
            protected_data=protected,
        )

        assert report.summary["total_findings"] > 0

        denied_samples = [a for a in report.adverse_action_samples if a.prediction == 0]
        assert len(denied_samples) > 0
        zero_reason_count = sum(1 for a in denied_samples if len(a.reasons) == 0)
        assert zero_reason_count == 0, (
            f"{zero_reason_count} of {len(denied_samples)} denied applicants "
            f"have zero adverse action reasons -- ECOA violation"
        )


# ---------------------------------------------------------------------------
# Regulatory framework tests
# ---------------------------------------------------------------------------

class TestRegulatoryFramework:
    def test_all_presets_load(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        for preset in IndustryPreset:
            fw = get_framework(preset)
            assert fw is not None
            assert fw.framework_id == preset.value

    def test_framework_has_reason_codes(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        for preset in IndustryPreset:
            fw = get_framework(preset)
            assert len(fw.reason_code_library) >= 15, (
                f"{preset.value} has only {len(fw.reason_code_library)} reason codes"
            )

    def test_framework_has_statutes(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        for preset in IndustryPreset:
            fw = get_framework(preset)
            assert len(fw.statute_references) >= 3, (
                f"{preset.value} has only {len(fw.statute_references)} statutes"
            )

    def test_get_statute_citation(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        fw = get_framework(IndustryPreset.LENDING)
        citation = fw.get_statute_citation()
        assert "ECOA" in citation
        assert len(citation) > 20

    def test_list_frameworks(self):
        from proveit.fairness.regulatory import list_frameworks
        frameworks = list_frameworks()
        assert len(frameworks) == 7
        assert "lending" in frameworks
        assert "hiring" in frameworks
        assert "insurance" in frameworks
        assert "housing" in frameworks
        assert "healthcare" in frameworks
        assert "education" in frameworks
        assert "general" in frameworks

    def test_invalid_preset(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        with pytest.raises(KeyError):
            # Create a fake preset by bypassing enum
            class FakePreset:
                value = "nonexistent"
            get_framework(FakePreset())


class TestIndustryPresets:
    def test_lending_framework(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        fw = get_framework(IndustryPreset.LENDING)
        assert fw.name == "Fair Lending (ECOA / Reg B)"
        assert "race" in fw.protected_attributes
        assert fw.four_fifths_threshold == 0.80
        assert "A01" in fw.reason_code_library

    def test_hiring_framework(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        fw = get_framework(IndustryPreset.HIRING)
        assert "Title VII" in fw.name
        assert "disability" in fw.protected_attributes
        assert "HR01" in fw.reason_code_library

    def test_insurance_framework(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        fw = get_framework(IndustryPreset.INSURANCE)
        assert "NAIC" in fw.name
        assert "IN01" in fw.reason_code_library

    def test_housing_framework(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        fw = get_framework(IndustryPreset.HOUSING)
        assert "Fair Housing" in fw.name
        assert "familial_status" in fw.protected_attributes
        assert "HS01" in fw.reason_code_library

    def test_healthcare_framework(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        fw = get_framework(IndustryPreset.HEALTHCARE)
        assert "ACA" in fw.name
        assert "HC01" in fw.reason_code_library

    def test_education_framework(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        fw = get_framework(IndustryPreset.EDUCATION)
        assert "Title VI" in fw.name
        assert "ED01" in fw.reason_code_library

    def test_general_framework(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        fw = get_framework(IndustryPreset.GENERAL)
        assert "EU AI Act" in fw.name
        assert "GN01" in fw.reason_code_library


class TestDecisionExplanationAlias:
    def test_alias_exists(self):
        from proveit.fairness import DecisionExplanationGenerator, AdverseActionGenerator
        assert DecisionExplanationGenerator is AdverseActionGenerator

    def test_alias_with_custom_codes(self):
        from proveit.fairness import DecisionExplanationGenerator
        custom_codes = {"X01": "Custom reason 1", "X02": "Custom reason 2"}
        gen = DecisionExplanationGenerator(max_reasons=2, reason_code_library=custom_codes)
        assert gen.reason_code_library == custom_codes
        assert gen.max_reasons == 2


class TestMultiIndustryEngine:
    def _build_data(self):
        rng = np.random.RandomState(42)
        n = 500
        data = pd.DataFrame({
            "score": rng.normal(0, 1, n),
            "experience": rng.randint(0, 20, n),
            "education": rng.randint(1, 5, n),
        })
        protected = pd.DataFrame({
            "race": rng.choice(["white", "black"], n, p=[0.7, 0.3]),
            "sex": rng.choice(["male", "female"], n, p=[0.5, 0.5]),
        })

        bias = np.where(protected["race"] == "black", -0.8, 0)
        y = ((data["score"] + data["experience"] * 0.1 + bias) > 0).astype(int)

        from sklearn.ensemble import GradientBoostingClassifier
        model = GradientBoostingClassifier(n_estimators=20, max_depth=3, random_state=42)
        model.fit(data, y)

        return model, data, y, protected

    def test_engine_with_hiring_industry(self):
        from proveit.fairness.engine import FairLensEngine, FairLensConfig
        model, X, y, protected = self._build_data()

        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=True,
            industry="hiring",
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=model, X_train=X, y_train=y,
            X_test=X, y_test=y, protected_data=protected,
        )
        assert report.summary["total_findings"] > 0

    def test_engine_with_insurance_industry(self):
        from proveit.fairness.engine import FairLensEngine, FairLensConfig
        model, X, y, protected = self._build_data()

        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=False,
            industry="insurance",
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=model, X_train=X, y_train=y,
            X_test=X, y_test=y, protected_data=protected,
        )
        assert report.summary["total_findings"] > 0


class TestCLIIndustry:
    def test_industry_flag_in_parser(self):
        from proveit.fairness.cli import main
        import argparse
        # Just verify the parser accepts --industry
        from proveit.fairness.cli import main as cli_main
        import sys
        old_argv = sys.argv
        try:
            sys.argv = ["fairlens", "analyze", "--model", "x.pkl", "--data", "x.csv",
                         "--protected", "race", "--industry", "hiring", "--help"]
            # --help exits, so we catch SystemExit
            with pytest.raises(SystemExit):
                cli_main()
        finally:
            sys.argv = old_argv


class TestFairLensValidation:
    """Tests for input validation and error handling."""

    def test_config_negative_threshold(self):
        """Negative proxy_correlation_threshold should raise ValueError."""
        with pytest.raises(ValueError, match="proxy_correlation_threshold"):
            FairLensConfig(proxy_correlation_threshold=-0.1)

    def test_config_threshold_above_one(self):
        """four_fifths_threshold > 1.0 should raise ValueError."""
        with pytest.raises(ValueError, match="four_fifths_threshold"):
            FairLensConfig(four_fifths_threshold=1.5)

    def test_config_protected_columns_string(self):
        """Passing a bare string instead of list should raise ValueError."""
        with pytest.raises(ValueError, match="protected_columns"):
            FairLensConfig(protected_columns="race")

    def test_config_invalid_industry(self):
        """Invalid industry should raise ValueError."""
        with pytest.raises(ValueError, match="industry"):
            FairLensConfig(industry="invalid_industry")

    def test_analyze_empty_dataframe(self, trained_model, split_data):
        """analyze() with empty DataFrame should raise ValueError."""
        config = FairLensConfig(protected_columns=["race"])
        engine = FairLensEngine(config=config)
        with pytest.raises(ValueError, match="empty"):
            engine.analyze(
                model=trained_model,
                X_train=pd.DataFrame(),
                y_train=np.array([]),
                X_test=split_data["X_test"],
                y_test=split_data["y_test"],
                protected_data=split_data["protected_test"],
            )

    def test_analyze_missing_protected_column(self, trained_model, split_data):
        """analyze() with missing protected column should raise ValueError."""
        config = FairLensConfig(protected_columns=["nonexistent_column"])
        engine = FairLensEngine(config=config)
        with pytest.raises(ValueError, match="nonexistent_column"):
            engine.analyze(
                model=trained_model,
                X_train=split_data["X_train"],
                y_train=split_data["y_train"],
                X_test=split_data["X_test"],
                y_test=split_data["y_test"],
                protected_data=split_data["protected_test"],
            )

    def test_analyze_model_without_predict(self, split_data):
        """analyze() with model lacking predict should raise ValueError."""
        config = FairLensConfig(protected_columns=["race"])
        engine = FairLensEngine(config=config)
        with pytest.raises(ValueError, match="predict"):
            engine.analyze(
                model="not_a_model",
                X_train=split_data["X_train"],
                y_train=split_data["y_train"],
                X_test=split_data["X_test"],
                y_test=split_data["y_test"],
                protected_data=split_data["protected_test"],
            )

    def test_proxy_detector_empty_features(self):
        """ProxyDetector with empty features should raise ValueError."""
        from proveit.fairness.proxy_detection import ProxyDetector
        detector = ProxyDetector()
        with pytest.raises(ValueError, match="empty"):
            detector.detect(
                features=pd.DataFrame(),
                protected_data=pd.DataFrame({"race": ["A"]}),
                protected_columns=["race"],
            )

    def test_adverse_action_mismatched_predictions(self, split_data, trained_model):
        """AdverseAction with mismatched prediction lengths should raise ValueError."""
        from proveit.fairness.adverse_action import AdverseActionGenerator
        generator = AdverseActionGenerator()
        with pytest.raises(ValueError, match="length"):
            generator.generate(
                model=trained_model,
                X=split_data["X_test"],
                predictions=np.array([0, 1]),  # wrong length
            )

    def test_lda_search_empty_proxy_features(self, split_data):
        """LDA search with empty proxy_features should return []."""
        from sklearn.ensemble import GradientBoostingClassifier
        searcher = LDASearcher()
        result = searcher.search(
            X_train=split_data["X_train"],
            y_train=split_data["y_train"],
            X_test=split_data["X_test"],
            y_test=split_data["y_test"],
            protected_test=split_data["protected_test"],
            protected_column="race",
            proxy_features=[],
            model_factory=lambda: GradientBoostingClassifier(n_estimators=10, random_state=42),
        )
        assert result == []


class TestIndustryAwareCitations:
    """Tests that regulatory citations match the selected industry."""

    def _build_biased_data(self):
        rng = np.random.RandomState(42)
        n = 500
        data = pd.DataFrame({
            "score": rng.normal(0, 1, n),
            "experience": rng.randint(0, 20, n),
            "education": rng.randint(1, 5, n),
        })
        protected = pd.DataFrame({
            "race": rng.choice(["white", "black"], n, p=[0.7, 0.3]),
        })
        bias = np.where(protected["race"] == "black", -0.8, 0)
        y = ((data["score"] + data["experience"] * 0.1 + bias) > 0).astype(int)

        from sklearn.ensemble import GradientBoostingClassifier
        model = GradientBoostingClassifier(n_estimators=20, max_depth=3, random_state=42)
        model.fit(data, y)
        return model, data, y, protected

    def test_lending_citations_use_ecoa(self):
        model, X, y, protected = self._build_biased_data()
        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=False,
            industry="lending",
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=model, X_train=X, y_train=y,
            X_test=X, y_test=y, protected_data=protected,
        )
        di_findings = [f for f in report.findings if f.category == "disparate_impact"]
        assert len(di_findings) > 0
        assert any("ECOA" in f.regulation or "12 CFR 1002" in f.regulation for f in di_findings)

    def test_hiring_citations_use_title_vii(self):
        model, X, y, protected = self._build_biased_data()
        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=False,
            industry="hiring",
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=model, X_train=X, y_train=y,
            X_test=X, y_test=y, protected_data=protected,
        )
        di_findings = [f for f in report.findings if f.category == "disparate_impact"]
        assert len(di_findings) > 0
        assert any("Title VII" in f.regulation or "42 USC 2000e" in f.regulation for f in di_findings)
        assert not any("ECOA" in f.regulation or "12 CFR 1002" in f.regulation for f in di_findings)

    def test_no_industry_uses_generic_citations(self):
        model, X, y, protected = self._build_biased_data()
        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=False,
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=model, X_train=X, y_train=y,
            X_test=X, y_test=y, protected_data=protected,
        )
        di_findings = [f for f in report.findings if f.category == "disparate_impact"]
        assert len(di_findings) > 0
        assert all("General algorithmic fairness" in f.regulation for f in di_findings)

    def test_housing_citations_use_fha(self):
        model, X, y, protected = self._build_biased_data()
        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=False,
            industry="housing",
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=model, X_train=X, y_train=y,
            X_test=X, y_test=y, protected_data=protected,
        )
        di_findings = [f for f in report.findings if f.category == "disparate_impact"]
        assert len(di_findings) > 0
        assert any("Fair Housing" in f.regulation or "42 USC 3601" in f.regulation for f in di_findings)

    def test_healthcare_citations_use_aca(self):
        model, X, y, protected = self._build_biased_data()
        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=False,
            industry="healthcare",
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=model, X_train=X, y_train=y,
            X_test=X, y_test=y, protected_data=protected,
        )
        di_findings = [f for f in report.findings if f.category == "disparate_impact"]
        assert len(di_findings) > 0
        assert any("ACA" in f.regulation or "42 USC 18116" in f.regulation for f in di_findings)

    def test_framework_metadata_in_report(self):
        model, X, y, protected = self._build_biased_data()
        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=False,
            industry="hiring",
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=model, X_train=X, y_train=y,
            X_test=X, y_test=y, protected_data=protected,
        )
        report_dict = report.to_dict()
        assert "regulatory_framework" in report_dict
        assert "Title VII" in report_dict["regulatory_framework"]["name"]

    def test_no_industry_no_framework_metadata(self):
        model, X, y, protected = self._build_biased_data()
        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=False,
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=model, X_train=X, y_train=y,
            X_test=X, y_test=y, protected_data=protected,
        )
        report_dict = report.to_dict()
        assert "regulatory_framework" not in report_dict


class TestIndustryFeatureMapping:
    """Tests that feature mappings are industry-specific."""

    def test_lending_feature_mapping(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        fw = get_framework(IndustryPreset.LENDING)
        assert fw.feature_mapping is not None
        assert "credit_score" in fw.feature_mapping
        assert "E01" in fw.feature_mapping["credit_score"]

    def test_hiring_feature_mapping(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        fw = get_framework(IndustryPreset.HIRING)
        assert fw.feature_mapping is not None
        assert "years_experience" in fw.feature_mapping
        assert "HR01" in fw.feature_mapping["years_experience"]

    def test_insurance_feature_mapping(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        fw = get_framework(IndustryPreset.INSURANCE)
        assert fw.feature_mapping is not None
        assert "claims_history" in fw.feature_mapping
        assert "IN01" in fw.feature_mapping["claims_history"]

    def test_all_frameworks_have_feature_mapping(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        for preset in IndustryPreset:
            fw = get_framework(preset)
            assert fw.feature_mapping is not None, (
                f"{preset.value} framework has no feature_mapping"
            )
            assert len(fw.feature_mapping) >= 10, (
                f"{preset.value} has only {len(fw.feature_mapping)} feature mappings"
            )

    def test_feature_mapping_codes_match_reason_library(self):
        from proveit.fairness.regulatory import IndustryPreset, get_framework
        for preset in IndustryPreset:
            fw = get_framework(preset)
            for feature, codes in fw.feature_mapping.items():
                for code in codes:
                    assert code in fw.reason_code_library, (
                        f"{preset.value}: feature '{feature}' maps to code '{code}' "
                        f"which is not in reason_code_library"
                    )

    def test_summary_key_negative_outcomes(self):
        """Verify that the summary uses 'negative_outcomes' (not 'denied_applicants')."""
        rng = np.random.RandomState(42)
        n = 200
        X = pd.DataFrame({"a": rng.normal(0, 1, n), "b": rng.normal(0, 1, n)})
        y = (X["a"] > 0).astype(int).values
        protected = pd.DataFrame({"race": rng.choice(["A", "B"], n)})

        from sklearn.tree import DecisionTreeClassifier
        model = DecisionTreeClassifier(max_depth=2, random_state=42)
        model.fit(X, y)

        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=True,
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=model, X_train=X, y_train=y,
            X_test=X, y_test=y, protected_data=protected,
        )
        assert "negative_outcomes" in report.summary
        assert "denied_applicants" not in report.summary


# ============================================================================
# Model Identity Tests (SR 11-7 § 4.1)
# ============================================================================

class TestModelIdentity:
    """Tests for model versioning and cryptographic hashing."""

    def test_model_hash_deterministic(self, trained_model):
        from proveit.fairness.engine import compute_model_hash
        h1 = compute_model_hash(trained_model)
        h2 = compute_model_hash(trained_model)
        assert h1 == h2
        assert len(h1) == 64  # SHA-256 hex digest

    def test_different_models_different_hashes(self, split_data):
        from proveit.fairness.engine import compute_model_hash
        from sklearn.tree import DecisionTreeClassifier
        from sklearn.ensemble import GradientBoostingClassifier

        m1 = DecisionTreeClassifier(max_depth=2, random_state=1)
        m1.fit(split_data["X_train"], split_data["y_train"])

        m2 = GradientBoostingClassifier(n_estimators=10, random_state=2)
        m2.fit(split_data["X_train"], split_data["y_train"])

        assert compute_model_hash(m1) != compute_model_hash(m2)

    def test_report_contains_model_identity(self, split_data, trained_model):
        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=False,
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=trained_model,
            X_train=split_data["X_train"],
            y_train=split_data["y_train"],
            X_test=split_data["X_test"],
            y_test=split_data["y_test"],
            protected_data=split_data["protected_test"],
            model_version="1.0.0",
        )

        assert report.model_identity is not None
        assert len(report.model_identity.model_hash) == 64
        assert report.model_identity.model_version == "1.0.0"
        assert len(report.model_identity.training_data_hash) == 64

    def test_model_identity_in_to_dict(self, split_data, trained_model):
        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=False,
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=trained_model,
            X_train=split_data["X_train"],
            y_train=split_data["y_train"],
            X_test=split_data["X_test"],
            y_test=split_data["y_test"],
            protected_data=split_data["protected_test"],
        )

        d = report.to_dict()
        assert "model_identity" in d
        assert "model_hash" in d["model_identity"]

    def test_model_hash_in_summary(self, split_data, trained_model):
        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=False,
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=trained_model,
            X_train=split_data["X_train"],
            y_train=split_data["y_train"],
            X_test=split_data["X_test"],
            y_test=split_data["y_test"],
            protected_data=split_data["protected_test"],
        )

        assert "model_hash" in report.summary
        assert len(report.summary["model_hash"]) == 64


# ============================================================================
# Intersectional Fairness Tests (CFPB 2025, 12 CFR 1002.4)
# ============================================================================

class TestIntersectionalFairness:
    """Tests for multi-attribute intersectional disparate impact analysis."""

    def test_basic_intersectional_analysis(self, split_data, trained_model):
        preds = trained_model.predict(split_data["X_test"])
        analyzer = DisparateImpactAnalyzer()

        results = analyzer.analyze_intersectional(
            predictions=preds,
            protected_data=split_data["protected_test"],
            protected_columns=["race", "sex"],
        )

        assert len(results) >= 1
        result = results[0]
        assert result.attribute_pair == ("race", "sex")
        assert len(result.groups) >= 2
        assert result.reference_rate > 0

    def test_intersectional_detects_compound_discrimination(self):
        """Construct data where univariate is fair but intersectional is not."""
        n = 400
        rng = np.random.RandomState(99)

        # Group A+X: 80% positive, A+Y: 80%, B+X: 80%, B+Y: 30%
        preds = np.array(
            [1]*64 + [0]*16 +   # A+X: 80% (80 people)
            [1]*64 + [0]*16 +   # A+Y: 80% (80 people)
            [1]*96 + [0]*24 +   # B+X: 80% (120 people)
            [1]*36 + [0]*84     # B+Y: 30% (120 people)
        )
        protected = pd.DataFrame({
            "group1": ["A"]*160 + ["B"]*240,
            "group2": (["X"]*80 + ["Y"]*80) + (["X"]*120 + ["Y"]*120),
        })

        analyzer = DisparateImpactAnalyzer()

        # Univariate: both groups pass
        uni_results = analyzer.analyze(preds, protected, ["group1", "group2"])
        # group1: A=80%, B=55% → might fail; group2: X=80%, Y=50% → might fail
        # But the KEY point: intersectional catches B+Y = 30%

        inter_results = analyzer.analyze_intersectional(
            preds, protected, ["group1", "group2"], min_group_size=5,
        )

        assert len(inter_results) == 1
        ir = inter_results[0]
        assert ir.has_disparate_impact
        # The worst group should be B+Y
        assert ir.worst_group.get("group1") == "B"
        assert ir.worst_group.get("group2") == "Y"
        assert ir.worst_ratio < 0.80

    def test_intersectional_no_impact_equal_rates(self):
        preds = np.ones(200)
        protected = pd.DataFrame({
            "g1": ["A"]*100 + ["B"]*100,
            "g2": (["X"]*50 + ["Y"]*50) * 2,
        })

        analyzer = DisparateImpactAnalyzer()
        results = analyzer.analyze_intersectional(
            preds, protected, ["g1", "g2"], min_group_size=5,
        )

        assert len(results) == 1
        assert not results[0].has_disparate_impact

    def test_intersectional_min_group_size(self):
        """Groups below min_group_size should be excluded."""
        preds = np.array([1]*100 + [0]*3)
        protected = pd.DataFrame({
            "g1": ["A"]*100 + ["B"]*3,
            "g2": ["X"]*100 + ["X"]*3,
        })

        analyzer = DisparateImpactAnalyzer()
        results = analyzer.analyze_intersectional(
            preds, protected, ["g1", "g2"], min_group_size=10,
        )

        # B+X has only 3 observations, should be excluded
        if results:
            for g in results[0].groups:
                assert g.total_count >= 10

    def test_intersectional_to_dict(self, split_data, trained_model):
        preds = trained_model.predict(split_data["X_test"])
        analyzer = DisparateImpactAnalyzer()

        results = analyzer.analyze_intersectional(
            preds, split_data["protected_test"], ["race", "sex"],
        )

        for r in results:
            d = r.to_dict()
            assert "attribute_pair" in d
            assert "groups" in d
            assert "worst_ratio" in d

    def test_engine_runs_intersectional(self, split_data, trained_model):
        """Engine should run intersectional analysis when 2+ protected columns."""
        config = FairLensConfig(
            protected_columns=["race", "sex"],
            run_lda_search=False,
            run_adverse_action=False,
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=trained_model,
            X_train=split_data["X_train"],
            y_train=split_data["y_train"],
            X_test=split_data["X_test"],
            y_test=split_data["y_test"],
            protected_data=split_data["protected_test"],
        )

        assert len(report.intersectional_results) >= 1
        assert "intersectional_analysis" in report.to_dict()
        assert "intersectional_di_detected" in report.summary


# ============================================================================
# Data Quality Validation Tests (SR 11-7 § 3.2)
# ============================================================================

class TestDataQualityValidation:
    """Tests for automatic data quality checks in the engine."""

    def test_high_missing_values_flagged(self):
        rng = np.random.RandomState(42)
        n = 200
        X_train = pd.DataFrame({
            "a": rng.normal(0, 1, n),
            "b": rng.normal(0, 1, n),
        })
        # Introduce 30% missing values in column 'b'
        X_train.loc[X_train.index[:60], "b"] = np.nan
        X_test = pd.DataFrame({
            "a": rng.normal(0, 1, n),
            "b": rng.normal(0, 1, n),
        })
        y_train = (X_train["a"] > 0).astype(int).values

        findings = FairLensEngine._validate_data_quality(X_train, X_test, y_train)
        missing_findings = [f for f in findings if "missing" in f.description.lower()]
        assert len(missing_findings) >= 1
        assert missing_findings[0].category == "data_quality"

    def test_class_imbalance_flagged(self):
        rng = np.random.RandomState(42)
        n = 200
        X_train = pd.DataFrame({"a": rng.normal(0, 1, n)})
        X_test = pd.DataFrame({"a": rng.normal(0, 1, n)})
        y_train = np.zeros(n)
        y_train[:5] = 1  # 2.5% positive rate

        findings = FairLensEngine._validate_data_quality(X_train, X_test, y_train)
        imbalance_findings = [f for f in findings if "imbalance" in f.description.lower()]
        assert len(imbalance_findings) == 1

    def test_distribution_shift_flagged(self):
        rng = np.random.RandomState(42)
        n = 200
        X_train = pd.DataFrame({"income": rng.normal(60000, 10000, n)})
        X_test = pd.DataFrame({"income": rng.normal(90000, 10000, n)})  # 50% shift
        y_train = np.ones(n)

        findings = FairLensEngine._validate_data_quality(X_train, X_test, y_train)
        shift_findings = [f for f in findings if "shift" in f.description.lower()]
        assert len(shift_findings) >= 1

    def test_clean_data_no_findings(self, split_data):
        findings = FairLensEngine._validate_data_quality(
            split_data["X_train"], split_data["X_test"], split_data["y_train"]
        )
        # Clean data may have minor findings but should have no missing/imbalance
        missing = [f for f in findings if "missing" in f.description.lower()]
        imbalance = [f for f in findings if "imbalance" in f.description.lower()]
        assert len(missing) == 0
        assert len(imbalance) == 0

    def test_data_quality_in_report(self, split_data, trained_model):
        config = FairLensConfig(
            protected_columns=["race"],
            run_lda_search=False,
            run_adverse_action=False,
        )
        engine = FairLensEngine(config=config)
        report = engine.analyze(
            model=trained_model,
            X_train=split_data["X_train"],
            y_train=split_data["y_train"],
            X_test=split_data["X_test"],
            y_test=split_data["y_test"],
            protected_data=split_data["protected_test"],
        )

        assert "data_quality_issues" in report.summary
        d = report.to_dict()
        assert "data_quality" in d or report.summary["data_quality_issues"] == 0


# ============================================================================
# SR 11-7 Compliance Engine Tests
# ============================================================================

class TestSR117Engine:
    """Tests for the SR 11-7 / OCC 2011-12 compliance engine."""

    def test_instantiation(self):
        from proveit.compliance.sr117 import SR117Engine
        engine = SR117Engine()
        assert engine.regulation_name == "SR 11-7 / OCC 2011-12"

    def test_empty_metadata_fails(self):
        from proveit.compliance.sr117 import SR117Engine
        engine = SR117Engine()

        tracker = DAGTracker()
        df = pd.DataFrame({"value": [1, 2, 3]})
        from proveit.hydra24_dag import wrap_dataframe_dag, get_dag_for_series
        wrapped = wrap_dataframe_dag(df, tracker, "test_table")
        series = wrapped["value"]
        dag = get_dag_for_series(series, row_index=0)

        result = engine.check(dag)
        assert result.passed is False
        assert result.critical_count >= 1

    def test_complete_metadata_passes(self):
        from proveit.compliance.sr117 import SR117Engine
        engine = SR117Engine()

        tracker = DAGTracker()
        df = pd.DataFrame({"value": [1, 2, 3]})
        from proveit.hydra24_dag import wrap_dataframe_dag, get_dag_for_series
        wrapped = wrap_dataframe_dag(df, tracker, "test_table")
        series = wrapped["value"]
        dag = get_dag_for_series(series, row_index=0)

        metadata = {
            "model_id": "LOAN_SCORING_v2",
            "model_version": "2.1.3",
            "model_hash": "abc123" * 10,
            "model_owner": "Jane Smith, Model Risk",
            "model_purpose": "Consumer credit underwriting",
            "model_validation_date": "2025-09-15",
            "model_validator": "Independent Validation Group",
            "backtesting_results": {"auc": 0.87, "ks": 0.42},
            "stress_testing": True,
            "monitoring_plan": "Monthly DI/AUC checks",
            "monitoring_frequency": "monthly",
            "performance_thresholds": {"min_auc": 0.80, "min_di_ratio": 0.80},
            "change_log": [{"date": "2025-09-01", "change": "Added income feature"}],
            "approved_by": "CRO Derek Flowers",
            "training_data_description": "Consumer loans 2020-2024",
            "training_data_hash": "def456" * 10,
            "escalation_procedures": "Notify CRO within 24h if AUC < 0.80",
            "model_risk_tier": "high",
            "board_approval_date": "2025-08-01",
            "mrm_committee_name": "Model Risk Committee",
            "board_reporting_frequency": "quarterly",
            "model_policies_documentation": "MRM Policy v3.0",
            "model_developer": "Data Science Team",
            "validation_conceptual_soundness": "Sound per review",
            "validation_outcomes_analysis": "Backtested on holdout",
            "model_assumptions": "Stationary distributions",
            "model_limitations": "Thin-file applicants underserved",
            "design_document": "DOC-001",
            "testing_results": "In-sample/OOS validated",
            "training_data_documentation": "Consumer loans 2020-2024",
        }

        result = engine.check(dag, metadata)
        assert result.passed is True
        assert result.critical_count == 0

    def test_missing_model_id_critical(self):
        from proveit.compliance.sr117 import SR117Engine
        engine = SR117Engine()

        tracker = DAGTracker()
        df = pd.DataFrame({"value": [1, 2, 3]})
        from proveit.hydra24_dag import wrap_dataframe_dag, get_dag_for_series
        wrapped = wrap_dataframe_dag(df, tracker, "test_table")
        dag = get_dag_for_series(wrapped["value"], row_index=0)

        result = engine.check(dag, {"model_validation_date": "2025-01-01", "monitoring_plan": "yes"})

        model_id_findings = [
            f for f in result.findings
            if "model_id" in f.description.lower() or "model identifier" in f.description.lower()
        ]
        assert len(model_id_findings) >= 1
        assert any(f.severity.value == "CRITICAL" for f in model_id_findings)

    def test_missing_validation_critical(self):
        from proveit.compliance.sr117 import SR117Engine
        engine = SR117Engine()

        tracker = DAGTracker()
        df = pd.DataFrame({"value": [1, 2, 3]})
        from proveit.hydra24_dag import wrap_dataframe_dag, get_dag_for_series
        wrapped = wrap_dataframe_dag(df, tracker, "test_table")
        dag = get_dag_for_series(wrapped["value"], row_index=0)

        result = engine.check(dag, {"model_id": "TEST_v1", "monitoring_plan": "yes"})

        validation_findings = [
            f for f in result.findings
            if "validation" in f.description.lower() and f.severity.value == "CRITICAL"
        ]
        assert len(validation_findings) >= 1

    def test_missing_monitoring_critical(self):
        from proveit.compliance.sr117 import SR117Engine
        engine = SR117Engine()

        tracker = DAGTracker()
        df = pd.DataFrame({"value": [1, 2, 3]})
        from proveit.hydra24_dag import wrap_dataframe_dag, get_dag_for_series
        wrapped = wrap_dataframe_dag(df, tracker, "test_table")
        dag = get_dag_for_series(wrapped["value"], row_index=0)

        result = engine.check(dag, {"model_id": "TEST_v1", "model_validation_date": "2025-01-01"})

        monitoring_findings = [
            f for f in result.findings
            if "monitoring plan" in f.description.lower() and f.severity.value == "CRITICAL"
        ]
        assert len(monitoring_findings) >= 1

    def test_to_dict_serializable(self):
        import json
        from proveit.compliance.sr117 import SR117Engine
        engine = SR117Engine()

        tracker = DAGTracker()
        df = pd.DataFrame({"value": [1, 2, 3]})
        from proveit.hydra24_dag import wrap_dataframe_dag, get_dag_for_series
        wrapped = wrap_dataframe_dag(df, tracker, "test_table")
        dag = get_dag_for_series(wrapped["value"], row_index=0)

        result = engine.check(dag)
        serialized = json.dumps(result.to_dict())
        assert isinstance(serialized, str)

    def test_integration_with_compliance_report(self):
        from proveit.compliance.sr117 import SR117Engine
        from proveit.compliance.base import ComplianceReport

        tracker = DAGTracker()
        df = pd.DataFrame({"value": [1, 2, 3]})
        from proveit.hydra24_dag import wrap_dataframe_dag, get_dag_for_series
        wrapped = wrap_dataframe_dag(df, tracker, "test_table")
        dag = get_dag_for_series(wrapped["value"], row_index=0)

        report = ComplianceReport()
        report.run_engines(engines=[SR117Engine()], dag=dag)

        assert len(report.results) == 1
        assert report.results[0].regulation_name == "SR 11-7 / OCC 2011-12"
        summary = report.summary()
        assert "SR 11-7 / OCC 2011-12" in summary["per_regulation"]
