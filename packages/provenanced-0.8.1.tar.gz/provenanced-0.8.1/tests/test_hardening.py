"""Tests for hardening improvements: DAG integrity, examiner validation, logging.

These tests verify the production-grade features needed for bank deployments:
- DAG integrity verification (audit trail trust)
- ExaminerPackage required section validation
- Production logging setup
"""

import json
import logging
import unittest

from proveit.persistence.sqlite_storage import SQLiteStorage
from proveit.persistence.storage import StoredNode, StoredEdge
from proveit.examiner.package import ExaminerPackage, ExaminerSection


# ---------------------------------------------------------------------------
# DAG Integrity Verification
# ---------------------------------------------------------------------------

class TestDAGIntegrityVerification(unittest.TestCase):
    """Test verify_dag_integrity() on SQLiteStorage."""

    def setUp(self):
        self.storage = SQLiteStorage(":memory:")
        self.storage.connect()

    def tearDown(self):
        self.storage.disconnect()

    def _create_simple_dag(self):
        """Create a simple DAG: source1 -> compute -> output."""
        pid = self.storage.create_pipeline("test_pipeline")

        self.storage.store_nodes([
            StoredNode(fingerprint=100, node_type="SOURCE", operation="load",
                       table_name="users", column_name="age", pipeline_id=pid),
            StoredNode(fingerprint=200, node_type="SOURCE", operation="load",
                       table_name="users", column_name="income", pipeline_id=pid),
            StoredNode(fingerprint=300, node_type="BINARY", operation="add",
                       pipeline_id=pid),
            StoredNode(fingerprint=400, node_type="UNARY", operation="normalize",
                       pipeline_id=pid),
        ])

        # Get node IDs
        fp_map = self.storage.get_fingerprint_node_map(pid)

        self.storage.store_edges_resolved([
            (fp_map[100], fp_map[300], 0),  # source1 -> compute
            (fp_map[200], fp_map[300], 1),  # source2 -> compute
            (fp_map[300], fp_map[400], 0),  # compute -> output
        ])

        return pid

    def test_valid_dag_passes_all_checks(self):
        pid = self._create_simple_dag()
        result = self.storage.verify_dag_integrity(pid)

        self.assertTrue(result["valid"])
        self.assertTrue(result["checks"]["fingerprint_uniqueness"])
        self.assertTrue(result["checks"]["edge_referential_integrity"])
        self.assertTrue(result["checks"]["acyclicity"])
        self.assertTrue(result["checks"]["has_source_nodes"])
        self.assertTrue(result["checks"]["has_leaf_nodes"])
        self.assertEqual(result["errors"], [])

    def test_stats_reported_correctly(self):
        pid = self._create_simple_dag()
        result = self.storage.verify_dag_integrity(pid)

        self.assertEqual(result["stats"]["node_count"], 4)
        self.assertEqual(result["stats"]["edge_count"], 3)
        self.assertEqual(result["stats"]["source_nodes"], 2)
        self.assertEqual(result["stats"]["leaf_nodes"], 1)

    def test_empty_pipeline_returns_invalid(self):
        pid = self.storage.create_pipeline("empty_pipeline")
        result = self.storage.verify_dag_integrity(pid)

        self.assertFalse(result["valid"])
        self.assertIn("No nodes found", result["errors"][0])

    def test_pipeline_id_in_result(self):
        pid = self._create_simple_dag()
        result = self.storage.verify_dag_integrity(pid)
        self.assertEqual(result["pipeline_id"], pid)

    def test_single_source_node_valid(self):
        """A single source node with no edges is valid."""
        pid = self.storage.create_pipeline("single_node")
        self.storage.store_nodes([
            StoredNode(fingerprint=100, node_type="SOURCE", operation="load",
                       pipeline_id=pid),
        ])
        result = self.storage.verify_dag_integrity(pid)

        self.assertTrue(result["valid"])
        self.assertEqual(result["stats"]["node_count"], 1)
        self.assertEqual(result["stats"]["source_nodes"], 1)
        self.assertEqual(result["stats"]["leaf_nodes"], 1)

    def test_linear_chain_valid(self):
        """A linear chain (A -> B -> C) should be valid."""
        pid = self.storage.create_pipeline("linear")
        self.storage.store_nodes([
            StoredNode(fingerprint=10, node_type="SOURCE", operation="load",
                       pipeline_id=pid),
            StoredNode(fingerprint=20, node_type="UNARY", operation="transform",
                       pipeline_id=pid),
            StoredNode(fingerprint=30, node_type="UNARY", operation="output",
                       pipeline_id=pid),
        ])
        fp_map = self.storage.get_fingerprint_node_map(pid)
        self.storage.store_edges_resolved([
            (fp_map[10], fp_map[20], 0),
            (fp_map[20], fp_map[30], 0),
        ])
        result = self.storage.verify_dag_integrity(pid)

        self.assertTrue(result["valid"])
        self.assertEqual(result["stats"]["source_nodes"], 1)
        self.assertEqual(result["stats"]["leaf_nodes"], 1)

    def test_diamond_dag_valid(self):
        """A diamond DAG (A -> B, A -> C, B -> D, C -> D) is valid."""
        pid = self.storage.create_pipeline("diamond")
        self.storage.store_nodes([
            StoredNode(fingerprint=1, node_type="SOURCE", operation="load",
                       pipeline_id=pid),
            StoredNode(fingerprint=2, node_type="UNARY", operation="branch1",
                       pipeline_id=pid),
            StoredNode(fingerprint=3, node_type="UNARY", operation="branch2",
                       pipeline_id=pid),
            StoredNode(fingerprint=4, node_type="BINARY", operation="merge",
                       pipeline_id=pid),
        ])
        fp_map = self.storage.get_fingerprint_node_map(pid)
        self.storage.store_edges_resolved([
            (fp_map[1], fp_map[2], 0),
            (fp_map[1], fp_map[3], 0),
            (fp_map[2], fp_map[4], 0),
            (fp_map[3], fp_map[4], 1),
        ])
        result = self.storage.verify_dag_integrity(pid)

        self.assertTrue(result["valid"])
        self.assertEqual(result["stats"]["source_nodes"], 1)
        self.assertEqual(result["stats"]["leaf_nodes"], 1)


# ---------------------------------------------------------------------------
# ExaminerPackage Required Section Validation
# ---------------------------------------------------------------------------

class TestExaminerRequiredSections(unittest.TestCase):
    """Test validate_required_sections() on ExaminerPackage."""

    def _make_package(self, exam_type="comprehensive"):
        return ExaminerPackage(
            institution_name="Test Bank",
            examination_type=exam_type,
            prepared_by="Test User",
        )

    def test_comprehensive_all_present(self):
        pkg = self._make_package("comprehensive")
        pkg.add_fairness_analysis({"disparate_impact": {"race": 0.85}})
        pkg.add_compliance_results({
            "results": [
                {"regulation_name": "ECOA (Reg B)", "passed": True,
                 "findings": [], "citations": []},
                {"regulation_name": "SR 11-7", "passed": True,
                 "findings": [], "citations": []},
            ]
        })
        pkg.add_model_card({
            "model_details": {"name": "Test Model"},
        })

        result = pkg.validate_required_sections()
        self.assertTrue(result["complete"])
        self.assertEqual(len(result["missing"]), 0)
        self.assertEqual(result["examination_type"], "comprehensive")

    def test_comprehensive_missing_fairness(self):
        pkg = self._make_package("comprehensive")
        # Only add compliance, no fairness
        pkg.add_compliance_results({
            "results": [
                {"regulation_name": "ECOA (Reg B)", "passed": True,
                 "findings": [], "citations": []},
                {"regulation_name": "SR 11-7", "passed": True,
                 "findings": [], "citations": []},
            ]
        })
        pkg.add_model_card({"model_details": {"name": "M"}})

        result = pkg.validate_required_sections()
        self.assertFalse(result["complete"])
        self.assertIn("Algorithmic Fairness Analysis", result["missing"])

    def test_fair_lending_exam_requires_ecoa(self):
        pkg = self._make_package("fair_lending")
        pkg.add_fairness_analysis({"di": 0.8})
        # No ECOA results

        result = pkg.validate_required_sections()
        self.assertFalse(result["complete"])
        self.assertIn("ECOA Compliance Assessment", result["missing"])

    def test_fair_lending_exam_complete(self):
        pkg = self._make_package("fair_lending")
        pkg.add_fairness_analysis({"di": 0.8})
        pkg.add_compliance_results({
            "results": [
                {"regulation_name": "ECOA (Reg B)", "passed": True,
                 "findings": [], "citations": []},
            ]
        })

        result = pkg.validate_required_sections()
        self.assertTrue(result["complete"])

    def test_model_risk_exam_requires_sr117(self):
        pkg = self._make_package("model_risk")
        # No SR 11-7, no model card, no inventory
        result = pkg.validate_required_sections()
        self.assertFalse(result["complete"])
        self.assertEqual(len(result["missing"]), 3)

    def test_model_risk_exam_complete(self):
        pkg = self._make_package("model_risk")
        pkg.add_compliance_results({
            "results": [
                {"regulation_name": "SR 11-7", "passed": True,
                 "findings": [], "citations": []},
            ]
        })
        pkg.add_model_card({"model_details": {"name": "LoanModel"}})
        pkg.add_model_inventory([{"model_id": "M-001"}])

        result = pkg.validate_required_sections()
        self.assertTrue(result["complete"])

    def test_ai_act_exam(self):
        pkg = self._make_package("ai_act")
        pkg.add_compliance_results({
            "results": [
                {"regulation_name": "EU AI Act", "passed": True,
                 "findings": [], "citations": []},
            ]
        })
        pkg.add_fairness_analysis({"di": 0.9})

        result = pkg.validate_required_sections()
        self.assertTrue(result["complete"])

    def test_state_compliance_exam(self):
        pkg = self._make_package("state_compliance")
        pkg.add_compliance_results({
            "results": [
                {"regulation_name": "Colorado AI Act", "passed": True,
                 "findings": [], "citations": []},
                {"regulation_name": "NYC Local Law 144", "passed": True,
                 "findings": [], "citations": []},
            ]
        })

        result = pkg.validate_required_sections()
        self.assertTrue(result["complete"])

    def test_unknown_exam_type_falls_back_to_comprehensive(self):
        pkg = self._make_package("custom_exam")
        result = pkg.validate_required_sections()
        # Should use comprehensive defaults (4 required sections)
        self.assertFalse(result["complete"])
        self.assertEqual(result["required_count"], 4)

    def test_validation_included_in_generate(self):
        pkg = self._make_package("fair_lending")
        pkg.add_fairness_analysis({"di": 0.8})
        pkg.add_compliance_results({
            "results": [
                {"regulation_name": "ECOA (Reg B)", "passed": True,
                 "findings": [], "citations": []},
            ]
        })

        bundle = pkg.generate()
        self.assertIn("validation", bundle)
        self.assertTrue(bundle["validation"]["complete"])

    def test_warnings_for_incomplete_package(self):
        pkg = self._make_package("comprehensive")
        result = pkg.validate_required_sections()
        self.assertTrue(len(result["warnings"]) > 0)
        self.assertIn("missing", result["warnings"][-1])

    def test_partial_section_flagged(self):
        pkg = self._make_package("fair_lending")
        # Add a partial fairness section manually
        pkg.add_section(ExaminerSection(
            title="Algorithmic Fairness Analysis (FairLens)",
            category="fair_lending",
            content={"partial": True},
            status="partial",
        ))
        pkg.add_compliance_results({
            "results": [
                {"regulation_name": "ECOA (Reg B)", "passed": True,
                 "findings": [], "citations": []},
            ]
        })

        result = pkg.validate_required_sections()
        # Partial counts as present but with warning
        self.assertTrue(result["complete"])
        self.assertTrue(any("partial" in w for w in result["warnings"]))


# ---------------------------------------------------------------------------
# Production Logging Setup
# ---------------------------------------------------------------------------

class TestSetupLogging(unittest.TestCase):
    """Test proveit.setup_logging() function."""

    def tearDown(self):
        # Clean up any handlers we added
        logger = logging.getLogger("proveit")
        logger.handlers.clear()
        logger.setLevel(logging.WARNING)

    def test_setup_json_logging(self):
        import proveit
        proveit.setup_logging(level="DEBUG", fmt="json")

        logger = logging.getLogger("proveit")
        self.assertEqual(logger.level, logging.DEBUG)
        self.assertEqual(len(logger.handlers), 1)

    def test_setup_text_logging(self):
        import proveit
        proveit.setup_logging(level="INFO", fmt="text")

        logger = logging.getLogger("proveit")
        self.assertEqual(logger.level, logging.INFO)

    def test_json_format_is_valid_json(self):
        import proveit
        import io

        proveit.setup_logging(level="DEBUG", fmt="json")

        logger = logging.getLogger("proveit.test")
        # Capture output
        handler = logger.parent.handlers[0]
        stream = io.StringIO()
        handler.stream = stream

        logger.info("test message")
        output = stream.getvalue().strip()
        if output:
            data = json.loads(output)
            self.assertEqual(data["message"], "test message")
            self.assertEqual(data["level"], "INFO")
            self.assertIn("timestamp", data)

    def test_repeated_setup_does_not_duplicate_handlers(self):
        import proveit
        proveit.setup_logging(level="INFO", fmt="json")
        proveit.setup_logging(level="DEBUG", fmt="text")

        logger = logging.getLogger("proveit")
        self.assertEqual(len(logger.handlers), 1)

    def test_child_loggers_inherit(self):
        import proveit
        proveit.setup_logging(level="DEBUG", fmt="json")

        child = logging.getLogger("proveit.compliance.ecoa")
        self.assertEqual(child.getEffectiveLevel(), logging.DEBUG)

    def test_setup_logging_in_all(self):
        import proveit
        self.assertIn("setup_logging", proveit.__all__)


# ---------------------------------------------------------------------------
# Persistence Exports
# ---------------------------------------------------------------------------

class TestPersistenceExports(unittest.TestCase):
    """Verify that verify_dag_integrity is accessible."""

    def test_verify_dag_integrity_is_method(self):
        from proveit.persistence.sqlite_storage import SQLiteStorage
        self.assertTrue(hasattr(SQLiteStorage, "verify_dag_integrity"))

    def test_storage_backend_has_method(self):
        from proveit.persistence.storage import StorageBackend
        self.assertTrue(hasattr(StorageBackend, "verify_dag_integrity"))


if __name__ == "__main__":
    unittest.main()
