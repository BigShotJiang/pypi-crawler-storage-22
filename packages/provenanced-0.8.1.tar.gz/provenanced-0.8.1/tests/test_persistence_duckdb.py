"""Tests for DuckDB factory support and lazy import."""

import pytest


class TestCreateStorageDuckDB:
    """Test factory and lazy import for DuckDB backend."""

    def test_create_duckdb_from_url(self):
        """create_storage with duckdb:/// URL returns DuckDBStorage."""
        from proveit.persistence.factory import create_storage
        from proveit.persistence.duckdb_storage import DuckDBStorage
        storage = create_storage("duckdb:///test.duckdb")
        assert isinstance(storage, DuckDBStorage)
        assert storage.db_path == "test.duckdb"

    def test_create_duckdb_from_bare_path(self):
        """create_storage with bare .duckdb path returns DuckDBStorage."""
        from proveit.persistence.factory import create_storage
        from proveit.persistence.duckdb_storage import DuckDBStorage
        storage = create_storage("my_data.duckdb")
        assert isinstance(storage, DuckDBStorage)
        assert storage.db_path == "my_data.duckdb"

    def test_duckdb_lazy_import(self):
        """DuckDBStorage can be imported from proveit.persistence."""
        from proveit.persistence import DuckDBStorage
        from proveit.persistence.duckdb_storage import DuckDBStorage as Direct
        assert DuckDBStorage is Direct
