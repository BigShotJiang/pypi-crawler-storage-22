"""
Tests for production hardening improvements:

1. Statistical significance testing in disparate impact analysis
2. PostgreSQL transaction rollback handling
3. S3Storage data loss prevention
4. AsyncWriter completion reporting
5. SHAP fidelity enforcement in adverse action
"""

import math
import threading
import time
import unittest
from unittest.mock import MagicMock, patch

import numpy as np
import pandas as pd

from proveit.fairness.disparate_impact import (
    DisparateImpactAnalyzer,
    DisparateImpactResult,
    IntersectionalResult,
    _fisher_exact_p,
    _ratio_confidence_interval,
    MIN_RELIABLE_SAMPLE_SIZE,
)
from proveit.fairness.adverse_action import (
    AdverseActionGenerator,
    ApplicantExplanation,
)
from proveit.persistence.async_writer import AsyncWriter, WriterConfig
from proveit.persistence.storage import StoredNode, StoredEdge


# ── Statistical Significance Testing ──────────────────────────────────


class TestFisherExactP(unittest.TestCase):
    """Test the pure-Python Fisher's exact test implementation."""

    def test_identical_rates_not_significant(self):
        """Two groups with identical rates should have p ≈ 1."""
        p = _fisher_exact_p(50, 50, 50, 50)
        self.assertGreater(p, 0.5)

    def test_very_different_rates_significant(self):
        """Two groups with very different rates should have p < 0.05."""
        # Group 1: 90/100 approved, Group 2: 30/100 approved
        p = _fisher_exact_p(90, 10, 30, 70)
        self.assertLess(p, 0.001)

    def test_small_sample_not_significant(self):
        """Small samples should generally not be significant."""
        # Group 1: 3/5 approved, Group 2: 1/5 approved
        p = _fisher_exact_p(3, 2, 1, 4)
        self.assertGreater(p, 0.05)

    def test_empty_table(self):
        """Empty table should return p=1."""
        p = _fisher_exact_p(0, 0, 0, 0)
        self.assertEqual(p, 1.0)

    def test_p_value_in_range(self):
        """P-value should always be in [0, 1]."""
        for a, b, c, d in [(10, 5, 3, 12), (100, 0, 0, 100), (1, 99, 99, 1)]:
            p = _fisher_exact_p(a, b, c, d)
            self.assertGreaterEqual(p, 0.0)
            self.assertLessEqual(p, 1.0)

    def test_symmetric(self):
        """Swapping rows should give the same p-value (two-sided test)."""
        p1 = _fisher_exact_p(20, 80, 40, 60)
        p2 = _fisher_exact_p(40, 60, 20, 80)
        self.assertAlmostEqual(p1, p2, places=10)


class TestRatioConfidenceInterval(unittest.TestCase):
    """Test confidence interval computation for selection rate ratios."""

    def test_equal_rates_contains_one(self):
        """CI for equal rates should contain 1.0."""
        lo, hi = _ratio_confidence_interval(100, 50, 100, 50)
        self.assertLess(lo, 1.0)
        self.assertGreater(hi, 1.0)

    def test_lower_rate_ci_below_one(self):
        """CI for a much lower rate should have upper bound < 1."""
        lo, hi = _ratio_confidence_interval(100, 20, 100, 80)
        self.assertLess(hi, 1.0)

    def test_zero_positives(self):
        """Zero positives should give CI starting at 0."""
        lo, hi = _ratio_confidence_interval(100, 0, 100, 50)
        self.assertEqual(lo, 0.0)

    def test_empty_group(self):
        """Empty groups should return (0, inf)."""
        lo, hi = _ratio_confidence_interval(0, 0, 100, 50)
        self.assertEqual(lo, 0.0)
        self.assertEqual(hi, float("inf"))


class TestDisparateImpactStatisticalSignificance(unittest.TestCase):
    """Test that DI analysis includes statistical significance."""

    def setUp(self):
        self.analyzer = DisparateImpactAnalyzer()

    def _make_data(self, n_white=200, n_black=200, white_rate=0.70, black_rate=0.50):
        """Create synthetic lending data with known rates."""
        np.random.seed(42)
        predictions = np.concatenate([
            np.random.binomial(1, white_rate, n_white),
            np.random.binomial(1, black_rate, n_black),
        ])
        protected = pd.DataFrame({
            "race": ["White"] * n_white + ["Black"] * n_black,
        })
        return predictions, protected

    def test_result_contains_p_values(self):
        """DI result should include p-values for each group."""
        preds, protected = self._make_data()
        results = self.analyzer.analyze(preds, protected, ["race"])
        self.assertEqual(len(results), 1)
        result = results[0]
        self.assertIn("Black", result.p_values)
        self.assertIsInstance(result.p_values["Black"], float)

    def test_result_contains_confidence_intervals(self):
        """DI result should include confidence intervals."""
        preds, protected = self._make_data()
        results = self.analyzer.analyze(preds, protected, ["race"])
        result = results[0]
        self.assertIn("Black", result.confidence_intervals)
        lo, hi = result.confidence_intervals["Black"]
        self.assertLess(lo, hi)

    def test_statistically_significant_with_large_disparity(self):
        """Large disparity with large samples should be statistically significant."""
        preds, protected = self._make_data(n_white=500, n_black=500,
                                            white_rate=0.80, black_rate=0.40)
        results = self.analyzer.analyze(preds, protected, ["race"])
        result = results[0]
        self.assertTrue(result.statistically_significant.get("Black", False))
        self.assertLess(result.p_values["Black"], 0.05)

    def test_not_significant_with_small_samples(self):
        """Small samples should generally not be statistically significant."""
        preds, protected = self._make_data(n_white=10, n_black=10,
                                            white_rate=0.70, black_rate=0.50)
        results = self.analyzer.analyze(preds, protected, ["race"])
        result = results[0]
        # With only 10 per group, the p-value should be high
        self.assertGreater(result.p_values.get("Black", 1.0), 0.05)

    def test_sample_size_warnings(self):
        """Groups below MIN_RELIABLE_SAMPLE_SIZE should get warnings."""
        preds, protected = self._make_data(n_white=100, n_black=15,
                                            white_rate=0.70, black_rate=0.50)
        results = self.analyzer.analyze(preds, protected, ["race"])
        result = results[0]
        self.assertTrue(len(result.sample_size_warnings) > 0)
        self.assertIn("15", result.sample_size_warnings[0])

    def test_no_warnings_for_large_samples(self):
        """Large samples should have no warnings."""
        preds, protected = self._make_data(n_white=200, n_black=200)
        results = self.analyzer.analyze(preds, protected, ["race"])
        result = results[0]
        self.assertEqual(len(result.sample_size_warnings), 0)

    def test_custom_significance_level(self):
        """Custom significance level should be respected."""
        analyzer = DisparateImpactAnalyzer(significance_level=0.01)
        preds, protected = self._make_data(n_white=100, n_black=100,
                                            white_rate=0.70, black_rate=0.55)
        results = analyzer.analyze(preds, protected, ["race"])
        result = results[0]
        # With marginal disparity, p < 0.05 but maybe not < 0.01
        if result.p_values.get("Black", 1.0) > 0.01:
            self.assertFalse(result.statistically_significant.get("Black", True))

    def test_to_dict_includes_statistical_fields(self):
        """to_dict() should include all new statistical fields."""
        preds, protected = self._make_data()
        results = self.analyzer.analyze(preds, protected, ["race"])
        d = results[0].to_dict()
        self.assertIn("p_values", d)
        self.assertIn("confidence_intervals", d)
        self.assertIn("statistically_significant", d)
        self.assertIn("sample_size_warnings", d)

    def test_intersectional_sample_warnings(self):
        """Intersectional analysis should include sample size warnings."""
        np.random.seed(42)
        n = 200
        preds = np.random.binomial(1, 0.6, n)
        protected = pd.DataFrame({
            "race": np.random.choice(["White", "Black", "Hispanic"], n),
            "sex": np.random.choice(["Male", "Female"], n),
        })
        results = self.analyzer.analyze_intersectional(
            preds, protected, ["race", "sex"], min_group_size=5
        )
        self.assertTrue(len(results) > 0)
        # With 200 records split across 6 groups, some will be < 30
        result = results[0]
        self.assertIsInstance(result.sample_size_warnings, list)

    def test_intersectional_to_dict_includes_warnings(self):
        """IntersectionalResult.to_dict() should include sample_size_warnings."""
        np.random.seed(42)
        n = 100
        preds = np.random.binomial(1, 0.6, n)
        protected = pd.DataFrame({
            "race": np.random.choice(["White", "Black"], n),
            "sex": np.random.choice(["Male", "Female"], n),
        })
        results = self.analyzer.analyze_intersectional(
            preds, protected, ["race", "sex"], min_group_size=5
        )
        if results:
            d = results[0].to_dict()
            self.assertIn("sample_size_warnings", d)


# ── AsyncWriter Completion Reporting ──────────────────────────────────


class TestAsyncWriterStop(unittest.TestCase):
    """Test that AsyncWriter.stop() reports data loss."""

    def test_stop_returns_true_on_clean_shutdown(self):
        """stop() should return True when all writes complete."""
        storage = MagicMock()
        writer = AsyncWriter(storage, WriterConfig(batch_size=10))
        writer.start()
        writer.write_nodes([StoredNode(fingerprint=1, node_type="source", operation="load")])
        completed = writer.stop(timeout=5.0)
        self.assertTrue(completed)

    def test_stop_returns_false_on_timeout(self):
        """stop() should return False when the writer thread hangs."""
        storage = MagicMock()
        # Make store_nodes block forever
        block_event = threading.Event()
        def blocking_store(*args, **kwargs):
            block_event.wait(timeout=30)
        storage.store_nodes.side_effect = blocking_store

        writer = AsyncWriter(storage, WriterConfig(batch_size=1))
        writer.start()
        writer.write_nodes([StoredNode(fingerprint=1, node_type="source", operation="load")])
        time.sleep(0.1)  # Let the writer thread pick up the item

        completed = writer.stop(timeout=0.5)
        self.assertFalse(completed)
        block_event.set()  # Unblock the thread for cleanup

    def test_stop_idempotent(self):
        """Calling stop() when not running should return True."""
        storage = MagicMock()
        writer = AsyncWriter(storage)
        self.assertTrue(writer.stop())


# ── SHAP Fidelity Enforcement ─────────────────────────────────────────


class TestAdverseActionFidelity(unittest.TestCase):
    """Test SHAP fidelity enforcement in AdverseActionGenerator."""

    def _make_model_and_data(self):
        """Create a simple sklearn model for testing."""
        from sklearn.tree import DecisionTreeClassifier
        np.random.seed(42)
        X = pd.DataFrame({
            "income": np.random.normal(60000, 15000, 100),
            "debt_to_income": np.random.uniform(0.1, 0.8, 100),
            "credit_score": np.random.randint(550, 800, 100),
        })
        y = (X["credit_score"] > 650).astype(int)
        model = DecisionTreeClassifier(random_state=42, max_depth=3)
        model.fit(X, y)
        predictions = model.predict(X)
        return model, X, predictions, y

    def test_default_no_fidelity_check(self):
        """Default min_explanation_fidelity=0.0 should not warn."""
        gen = AdverseActionGenerator()
        self.assertEqual(gen.min_explanation_fidelity, 0.0)

    def test_fidelity_threshold_stored(self):
        """Custom fidelity threshold should be stored."""
        gen = AdverseActionGenerator(min_explanation_fidelity=0.85)
        self.assertEqual(gen.min_explanation_fidelity, 0.85)

    def test_low_fidelity_warning_set(self):
        """When using feature_importances_ (fidelity=0.5), threshold=0.85 should flag."""
        model, X, preds, _ = self._make_model_and_data()
        gen = AdverseActionGenerator(min_explanation_fidelity=0.85)

        # Force feature_importances_ path (confidence=0.5) by mocking SHAP away
        with patch.dict("sys.modules", {"shap": None}):
            explanations = gen.generate(model, X, preds)

        # Feature importances gives confidence=0.5, which is < 0.85
        if explanations:
            self.assertTrue(explanations[0].low_fidelity_warning)

    def test_no_warning_when_fidelity_disabled(self):
        """min_explanation_fidelity=0 should never set warning."""
        model, X, preds, _ = self._make_model_and_data()
        gen = AdverseActionGenerator(min_explanation_fidelity=0.0)

        with patch.dict("sys.modules", {"shap": None}):
            explanations = gen.generate(model, X, preds)

        if explanations:
            self.assertFalse(explanations[0].low_fidelity_warning)

    def test_low_fidelity_in_to_dict(self):
        """low_fidelity_warning should appear in to_dict() when True."""
        exp = ApplicantExplanation(
            applicant_index=0, prediction=0, probability=0.3,
            reasons=[], top_positive_features=[], top_negative_features=[],
            explanation_method="feature_importances", explanation_confidence=0.5,
            low_fidelity_warning=True,
        )
        d = exp.to_dict()
        self.assertTrue(d["low_fidelity_warning"])

    def test_no_fidelity_key_when_false(self):
        """low_fidelity_warning should not appear in to_dict() when False."""
        exp = ApplicantExplanation(
            applicant_index=0, prediction=0, probability=0.3,
            reasons=[], top_positive_features=[], top_negative_features=[],
            explanation_method="shap", explanation_confidence=0.98,
            low_fidelity_warning=False,
        )
        d = exp.to_dict()
        self.assertNotIn("low_fidelity_warning", d)


# ── PostgreSQL Transaction Rollback (Structural Tests) ────────────────


class TestPostgreSQLRollbackStructure(unittest.TestCase):
    """Verify PostgreSQL storage methods have proper rollback handling.

    These are structural tests that verify the code paths exist without
    requiring an actual PostgreSQL connection.
    """

    def test_store_nodes_has_rollback(self):
        """store_nodes should call conn.rollback() on exception."""
        import inspect
        from proveit.persistence.storage import PostgreSQLStorage
        source = inspect.getsource(PostgreSQLStorage.store_nodes)
        self.assertIn("conn.rollback()", source)

    def test_store_edges_has_rollback(self):
        """store_edges should call conn.rollback() on exception."""
        import inspect
        from proveit.persistence.storage import PostgreSQLStorage
        source = inspect.getsource(PostgreSQLStorage.store_edges)
        self.assertIn("conn.rollback()", source)

    def test_store_results_has_rollback(self):
        """store_results should call conn.rollback() on exception."""
        import inspect
        from proveit.persistence.storage import PostgreSQLStorage
        source = inspect.getsource(PostgreSQLStorage.store_results)
        self.assertIn("conn.rollback()", source)

    def test_create_pipeline_has_rollback(self):
        """create_pipeline should call conn.rollback() on exception."""
        import inspect
        from proveit.persistence.storage import PostgreSQLStorage
        source = inspect.getsource(PostgreSQLStorage.create_pipeline)
        self.assertIn("conn.rollback()", source)

    def test_complete_pipeline_has_rollback(self):
        """complete_pipeline should call conn.rollback() on exception."""
        import inspect
        from proveit.persistence.storage import PostgreSQLStorage
        source = inspect.getsource(PostgreSQLStorage.complete_pipeline)
        self.assertIn("conn.rollback()", source)

    def test_register_source_has_rollback(self):
        """register_source should call conn.rollback() on exception."""
        import inspect
        from proveit.persistence.storage import PostgreSQLStorage
        source = inspect.getsource(PostgreSQLStorage.register_source)
        self.assertIn("conn.rollback()", source)

    def test_store_edges_resolved_has_rollback(self):
        """store_edges_resolved should call conn.rollback() on exception."""
        import inspect
        from proveit.persistence.storage import PostgreSQLStorage
        source = inspect.getsource(PostgreSQLStorage.store_edges_resolved)
        self.assertIn("conn.rollback()", source)


# ── S3Storage Data Loss Prevention (Structural Tests) ─────────────────


class TestS3DisconnectRaises(unittest.TestCase):
    """Verify S3Storage.disconnect() raises on sync failure."""

    def test_disconnect_raises_on_sync_failure(self):
        """disconnect() should raise RuntimeError when S3 sync fails."""
        import inspect
        from proveit.persistence.s3_storage import S3Storage
        source = inspect.getsource(S3Storage.disconnect)
        self.assertIn("raise RuntimeError", source)
        self.assertIn("sync_error", source)

    def test_del_logs_error_on_sync_failure(self):
        """__del__ should log at ERROR level when sync fails."""
        import inspect
        from proveit.persistence.s3_storage import S3Storage
        source = inspect.getsource(S3Storage.__del__)
        self.assertIn("logger.error", source)


if __name__ == "__main__":
    unittest.main()
