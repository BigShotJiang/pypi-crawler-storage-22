"""SDK configuration and environment variable handling."""

import os
from typing import Optional

DEFAULT_PROXY_URL = "https://api.proxle.dev"

# Environment variable names
ENV_PROXY_KEY = "PROXLE_API_KEY"
ENV_PROXY_URL = "PROXLE_URL"


def get_proxy_url(override: Optional[str] = None) -> str:
    """Resolve proxy URL from override, env var, or default."""
    if override:
        return override.rstrip("/")
    return os.environ.get(ENV_PROXY_URL, DEFAULT_PROXY_URL).rstrip("/")


def get_proxy_key(override: Optional[str] = None) -> str:
    """Resolve proxy key from override or env var."""
    key = override or os.environ.get(ENV_PROXY_KEY)
    if not key:
        raise ValueError(
            f"Proxle API key is required. "
            f"Pass proxy_key= or set {ENV_PROXY_KEY} environment variable."
        )
    return key
