"""Proxle SDK exceptions."""


class ProxleError(Exception):
    """Base exception for Proxle SDK errors."""

    pass


class ProxleConfigError(ProxleError):
    """Raised for configuration issues (missing key, invalid URL, etc.)."""

    pass


class ProxleAuthError(ProxleError):
    """Raised when the Proxle proxy rejects the proxy key."""

    def __init__(self, message: str, status_code: int):
        self.status_code = status_code
        super().__init__(message)
