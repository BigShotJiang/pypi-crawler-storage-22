"""Metadata serialization and validation utilities."""

import json
from typing import Any, Dict, Optional

from ._exceptions import ProxleConfigError

# Maximum metadata JSON size (to prevent oversized headers)
MAX_METADATA_BYTES = 4096


def validate_and_serialize(metadata: Optional[Dict[str, Any]]) -> Optional[str]:
    """Validate metadata dict and serialize to JSON string.

    Args:
        metadata: Optional dict with string keys and JSON-serializable values.

    Returns:
        JSON string for X-Metadata header, or None if metadata is empty/None.

    Raises:
        ProxleConfigError: If metadata is not serializable or exceeds size limit.
    """
    if not metadata:
        return None

    if not isinstance(metadata, dict):
        raise ProxleConfigError(
            f"metadata must be a dict, got {type(metadata).__name__}"
        )

    try:
        serialized = json.dumps(metadata, separators=(",", ":"))
    except (TypeError, ValueError) as e:
        raise ProxleConfigError(
            f"metadata values must be JSON-serializable: {e}"
        ) from e

    if len(serialized.encode("utf-8")) > MAX_METADATA_BYTES:
        raise ProxleConfigError(
            f"Serialized metadata exceeds {MAX_METADATA_BYTES} bytes. "
            f"Reduce metadata size or remove large values."
        )

    return serialized
