"""Shared proxy header logic for SDK provider wrappers."""

import json
from typing import Any, Dict, Optional


def build_proxy_headers(
    proxy_key: str,
    provider_key: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, str]:
    """Build the proxy-specific headers for a request."""
    headers = {
        "X-Api-Key": proxy_key,
        "X-Provider-Key": provider_key,
    }
    if metadata:
        headers["X-Metadata"] = json.dumps(metadata)
    return headers


def build_default_headers(proxy_key: str, provider_key: str) -> Dict[str, str]:
    """Build default headers for SDK client initialization (no metadata)."""
    return {
        "X-Api-Key": proxy_key,
        "X-Provider-Key": provider_key,
    }
