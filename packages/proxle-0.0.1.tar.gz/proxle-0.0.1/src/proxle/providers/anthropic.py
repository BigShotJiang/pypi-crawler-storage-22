"""Anthropic drop-in replacement with Proxle proxy support."""

import json
from typing import Any, Dict, Optional

from .._config import get_proxy_key, get_proxy_url
from ._base import build_default_headers


class _MessagesProxy:
    """Wraps anthropic.resources.Messages to inject metadata."""

    def __init__(self, original: Any):
        self._original = original

    def create(self, *, metadata: Optional[Dict[str, Any]] = None, **kwargs: Any) -> Any:
        """Create message with optional metadata tracking."""
        if metadata:
            extra_headers = kwargs.pop("extra_headers", None) or {}
            extra_headers["X-Metadata"] = json.dumps(metadata)
            kwargs["extra_headers"] = extra_headers
        return self._original.create(**kwargs)

    def stream(self, *, metadata: Optional[Dict[str, Any]] = None, **kwargs: Any) -> Any:
        """Stream message with optional metadata tracking."""
        if metadata:
            extra_headers = kwargs.pop("extra_headers", None) or {}
            extra_headers["X-Metadata"] = json.dumps(metadata)
            kwargs["extra_headers"] = extra_headers
        return self._original.stream(**kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class Anthropic:
    """Drop-in replacement for anthropic.Anthropic with Proxle proxy support.

    Usage:
        from proxle import Anthropic

        client = Anthropic(api_key=ANTHROPIC_KEY, proxy_key=PROXY_KEY)
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
            metadata={"feature": "summarizer", "user_id": "user_456"}
        )
    """

    def __init__(
        self,
        *,
        api_key: str,
        proxy_key: Optional[str] = None,
        proxy_url: Optional[str] = None,
        **kwargs: Any,
    ):
        try:
            import anthropic as _anthropic
        except ImportError:
            raise ImportError(
                "The 'anthropic' package is required for proxle.Anthropic. "
                "Install it with: pip install proxle[anthropic]"
            )

        resolved_proxy_key = get_proxy_key(proxy_key)
        resolved_proxy_url = get_proxy_url(proxy_url)

        self._client = _anthropic.Anthropic(
            api_key=api_key,
            base_url=f"{resolved_proxy_url}/v1/proxy/anthropic",
            default_headers=build_default_headers(resolved_proxy_key, api_key),
            **kwargs,
        )

        self.messages = _MessagesProxy(self._client.messages)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


class AsyncAnthropic:
    """Async drop-in replacement for anthropic.AsyncAnthropic."""

    def __init__(
        self,
        *,
        api_key: str,
        proxy_key: Optional[str] = None,
        proxy_url: Optional[str] = None,
        **kwargs: Any,
    ):
        try:
            import anthropic as _anthropic
        except ImportError:
            raise ImportError(
                "The 'anthropic' package is required for proxle.AsyncAnthropic. "
                "Install it with: pip install proxle[anthropic]"
            )

        resolved_proxy_key = get_proxy_key(proxy_key)
        resolved_proxy_url = get_proxy_url(proxy_url)

        self._client = _anthropic.AsyncAnthropic(
            api_key=api_key,
            base_url=f"{resolved_proxy_url}/v1/proxy/anthropic",
            default_headers=build_default_headers(resolved_proxy_key, api_key),
            **kwargs,
        )

        self.messages = _MessagesProxy(self._client.messages)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)
