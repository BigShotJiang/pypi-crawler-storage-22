"""Azure OpenAI drop-in replacement with Proxle proxy support."""

from typing import Any, Optional

from .._config import get_proxy_key, get_proxy_url
from ._base import build_default_headers
from .openai import _ChatProxy, _EmbeddingsProxy


class AzureOpenAI:
    """Drop-in replacement for openai.AzureOpenAI with Proxle proxy support.

    Usage:
        from proxle import AzureOpenAI

        client = AzureOpenAI(
            api_key=AZURE_KEY,
            azure_endpoint="https://my-resource.openai.azure.com",
            api_version="2024-02-01",
            proxy_key=PROXY_KEY,
        )
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello"}],
            metadata={"feature": "chat"}
        )
    """

    def __init__(
        self,
        *,
        api_key: str,
        azure_endpoint: str,
        api_version: str,
        proxy_key: Optional[str] = None,
        proxy_url: Optional[str] = None,
        **kwargs: Any,
    ):
        try:
            import openai as _openai
        except ImportError:
            raise ImportError(
                "The 'openai' package is required for proxle.AzureOpenAI. "
                "Install it with: pip install proxle[openai]"
            )

        resolved_proxy_key = get_proxy_key(proxy_key)
        resolved_proxy_url = get_proxy_url(proxy_url)

        default_headers = build_default_headers(resolved_proxy_key, api_key)
        default_headers["X-Azure-Endpoint"] = azure_endpoint
        default_headers["X-Azure-Api-Version"] = api_version

        self._client = _openai.AzureOpenAI(
            api_key=api_key,
            azure_endpoint=f"{resolved_proxy_url}/v1/proxy/azure",
            api_version=api_version,
            default_headers=default_headers,
            **kwargs,
        )

        self.chat = _ChatProxy(self._client.chat)
        self.embeddings = _EmbeddingsProxy(self._client.embeddings)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


class AsyncAzureOpenAI:
    """Async drop-in replacement for openai.AsyncAzureOpenAI."""

    def __init__(
        self,
        *,
        api_key: str,
        azure_endpoint: str,
        api_version: str,
        proxy_key: Optional[str] = None,
        proxy_url: Optional[str] = None,
        **kwargs: Any,
    ):
        try:
            import openai as _openai
        except ImportError:
            raise ImportError(
                "The 'openai' package is required for proxle.AsyncAzureOpenAI. "
                "Install it with: pip install proxle[openai]"
            )

        resolved_proxy_key = get_proxy_key(proxy_key)
        resolved_proxy_url = get_proxy_url(proxy_url)

        default_headers = build_default_headers(resolved_proxy_key, api_key)
        default_headers["X-Azure-Endpoint"] = azure_endpoint
        default_headers["X-Azure-Api-Version"] = api_version

        self._client = _openai.AsyncAzureOpenAI(
            api_key=api_key,
            azure_endpoint=f"{resolved_proxy_url}/v1/proxy/azure",
            api_version=api_version,
            default_headers=default_headers,
            **kwargs,
        )

        self.chat = _ChatProxy(self._client.chat)
        self.embeddings = _EmbeddingsProxy(self._client.embeddings)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)
