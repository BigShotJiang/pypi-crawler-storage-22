"""Cohere client with Proxle proxy support."""

import json
from typing import Any, Dict, Iterator, List, Optional

import httpx

from .._config import get_proxy_key, get_proxy_url
from ._base import build_proxy_headers


class Cohere:
    """Lightweight Cohere client routed through Proxle proxy.

    Usage:
        from proxle import Cohere

        client = Cohere(api_key=COHERE_KEY, proxy_key=PROXY_KEY)
        response = client.chat(
            message="Hello!",
            model="command-r-plus",
            metadata={"feature": "chat"}
        )
    """

    def __init__(
        self,
        *,
        api_key: str,
        proxy_key: Optional[str] = None,
        proxy_url: Optional[str] = None,
        timeout: float = 120.0,
    ):
        self._api_key = api_key
        self._proxy_key = get_proxy_key(proxy_key)
        self._base_url = f"{get_proxy_url(proxy_url)}/v1/proxy/cohere"
        self._http = httpx.Client(timeout=timeout)

    def chat(
        self,
        *,
        message: str,
        model: str = "command-r-plus",
        chat_history: Optional[List[Dict[str, str]]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        stream: bool = False,
        **kwargs: Any,
    ) -> Any:
        """Send a chat request to Cohere via the proxy."""
        body: Dict[str, Any] = {"message": message, "model": model, **kwargs}
        if chat_history:
            body["chat_history"] = chat_history
        if stream:
            body["stream"] = True

        headers = build_proxy_headers(self._proxy_key, self._api_key, metadata)
        headers["Content-Type"] = "application/json"

        if stream:
            return self._stream_request("/v2/chat", body, headers)

        response = self._http.post(
            f"{self._base_url}/v2/chat",
            json=body,
            headers=headers,
        )
        response.raise_for_status()
        return response.json()

    def generate(
        self,
        *,
        prompt: str,
        model: str = "command",
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        """Send a text generation request to Cohere via the proxy."""
        body = {"prompt": prompt, "model": model, **kwargs}
        headers = build_proxy_headers(self._proxy_key, self._api_key, metadata)
        headers["Content-Type"] = "application/json"

        response = self._http.post(
            f"{self._base_url}/v1/generate",
            json=body,
            headers=headers,
        )
        response.raise_for_status()
        return response.json()

    def embed(
        self,
        *,
        texts: List[str],
        model: str = "embed-english-v3.0",
        input_type: str = "search_document",
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        """Create embeddings via Cohere through the proxy."""
        body = {"texts": texts, "model": model, "input_type": input_type, **kwargs}
        headers = build_proxy_headers(self._proxy_key, self._api_key, metadata)
        headers["Content-Type"] = "application/json"

        response = self._http.post(
            f"{self._base_url}/v1/embed",
            json=body,
            headers=headers,
        )
        response.raise_for_status()
        return response.json()

    def _stream_request(
        self, path: str, body: dict, headers: dict
    ) -> Iterator[Dict[str, Any]]:
        """Stream SSE events from the proxy."""
        with self._http.stream(
            "POST", f"{self._base_url}{path}", json=body, headers=headers
        ) as response:
            response.raise_for_status()
            for line in response.iter_lines():
                if line.startswith("data: "):
                    data = line[6:]
                    if data.strip() == "[DONE]":
                        break
                    yield json.loads(data)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "Cohere":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
