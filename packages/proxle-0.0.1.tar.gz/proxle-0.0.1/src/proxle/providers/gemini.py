"""Gemini client with Proxle proxy support."""

import json
from typing import Any, Dict, Iterator, List, Optional

import httpx

from .._config import get_proxy_key, get_proxy_url
from ._base import build_proxy_headers


class Gemini:
    """Lightweight Gemini client routed through Proxle proxy.

    Usage:
        from proxle import Gemini

        client = Gemini(api_key=GEMINI_KEY, proxy_key=PROXY_KEY)
        response = client.generate_content(
            model="gemini-1.5-pro",
            contents=[{"role": "user", "parts": [{"text": "Hello!"}]}],
            metadata={"feature": "chat"}
        )
    """

    def __init__(
        self,
        *,
        api_key: str,
        proxy_key: Optional[str] = None,
        proxy_url: Optional[str] = None,
        timeout: float = 120.0,
    ):
        self._api_key = api_key
        self._proxy_key = get_proxy_key(proxy_key)
        self._base_url = f"{get_proxy_url(proxy_url)}/v1/proxy/gemini"
        self._http = httpx.Client(timeout=timeout)

    def generate_content(
        self,
        *,
        model: str,
        contents: List[Dict[str, Any]],
        generation_config: Optional[Dict[str, Any]] = None,
        safety_settings: Optional[List[Dict[str, Any]]] = None,
        system_instruction: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        stream: bool = False,
        **kwargs: Any,
    ) -> Any:
        """Generate content via Gemini through the proxy."""
        body: Dict[str, Any] = {"contents": contents, **kwargs}
        if generation_config:
            body["generationConfig"] = generation_config
        if safety_settings:
            body["safetySettings"] = safety_settings
        if system_instruction:
            body["systemInstruction"] = system_instruction

        action = "streamGenerateContent" if stream else "generateContent"
        path = f"/v1beta/models/{model}:{action}"

        headers = build_proxy_headers(self._proxy_key, self._api_key, metadata)
        headers["Content-Type"] = "application/json"

        if stream:
            return self._stream_request(path, body, headers)

        response = self._http.post(
            f"{self._base_url}{path}",
            json=body,
            headers=headers,
        )
        response.raise_for_status()
        return response.json()

    def embed_content(
        self,
        *,
        model: str,
        content: Dict[str, Any],
        task_type: Optional[str] = None,
        title: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        """Create embeddings via Gemini through the proxy."""
        body: Dict[str, Any] = {"content": content, **kwargs}
        if task_type:
            body["taskType"] = task_type
        if title:
            body["title"] = title

        headers = build_proxy_headers(self._proxy_key, self._api_key, metadata)
        headers["Content-Type"] = "application/json"

        response = self._http.post(
            f"{self._base_url}/v1beta/models/{model}:embedContent",
            json=body,
            headers=headers,
        )
        response.raise_for_status()
        return response.json()

    def count_tokens(
        self,
        *,
        model: str,
        contents: List[Dict[str, Any]],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Count tokens via Gemini through the proxy."""
        body = {"contents": contents}
        headers = build_proxy_headers(self._proxy_key, self._api_key, metadata)
        headers["Content-Type"] = "application/json"

        response = self._http.post(
            f"{self._base_url}/v1beta/models/{model}:countTokens",
            json=body,
            headers=headers,
        )
        response.raise_for_status()
        return response.json()

    def _stream_request(
        self, path: str, body: dict, headers: dict
    ) -> Iterator[Dict[str, Any]]:
        """Stream SSE events from the proxy."""
        with self._http.stream(
            "POST", f"{self._base_url}{path}", json=body, headers=headers
        ) as response:
            response.raise_for_status()
            for line in response.iter_lines():
                if line.startswith("data: "):
                    data = line[6:]
                    if data.strip() == "[DONE]":
                        break
                    yield json.loads(data)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "Gemini":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
