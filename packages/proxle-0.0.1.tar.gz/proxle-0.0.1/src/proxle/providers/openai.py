"""OpenAI drop-in replacement with Proxle proxy support."""

import json
from typing import Any, Dict, Optional

from .._config import get_proxy_key, get_proxy_url
from ._base import build_default_headers


class _ChatCompletionsProxy:
    """Wraps openai.resources.ChatCompletions to inject metadata."""

    def __init__(self, original: Any):
        self._original = original

    def create(self, *, metadata: Optional[Dict[str, Any]] = None, **kwargs: Any) -> Any:
        """Create chat completion with optional metadata tracking.

        Args:
            metadata: Optional dict for cost attribution.
                      e.g. {"feature": "chat", "user_id": "u_123"}
            **kwargs: All arguments supported by openai.ChatCompletion.create()
        """
        if metadata:
            extra_headers = kwargs.pop("extra_headers", None) or {}
            extra_headers["X-Metadata"] = json.dumps(metadata)
            kwargs["extra_headers"] = extra_headers
        return self._original.create(**kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class _ChatProxy:
    """Wraps openai.resources.Chat to expose proxied completions."""

    def __init__(self, original: Any):
        self._original = original
        self.completions = _ChatCompletionsProxy(original.completions)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class _EmbeddingsProxy:
    """Wraps openai.resources.Embeddings to inject metadata."""

    def __init__(self, original: Any):
        self._original = original

    def create(self, *, metadata: Optional[Dict[str, Any]] = None, **kwargs: Any) -> Any:
        """Create embeddings with optional metadata tracking."""
        if metadata:
            extra_headers = kwargs.pop("extra_headers", None) or {}
            extra_headers["X-Metadata"] = json.dumps(metadata)
            kwargs["extra_headers"] = extra_headers
        return self._original.create(**kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class OpenAI:
    """Drop-in replacement for openai.OpenAI with Proxle proxy support.

    Usage:
        from proxle import OpenAI

        client = OpenAI(api_key=OPENAI_KEY, proxy_key=PROXY_KEY)
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello"}],
            metadata={"feature": "chat_assistant", "user_id": "user_123"}
        )
    """

    def __init__(
        self,
        *,
        api_key: str,
        proxy_key: Optional[str] = None,
        proxy_url: Optional[str] = None,
        **kwargs: Any,
    ):
        try:
            import openai as _openai
        except ImportError:
            raise ImportError(
                "The 'openai' package is required for proxle.OpenAI. "
                "Install it with: pip install proxle[openai]"
            )

        resolved_proxy_key = get_proxy_key(proxy_key)
        resolved_proxy_url = get_proxy_url(proxy_url)

        self._client = _openai.OpenAI(
            api_key=api_key,
            base_url=f"{resolved_proxy_url}/v1/proxy/openai",
            default_headers=build_default_headers(resolved_proxy_key, api_key),
            **kwargs,
        )

        self.chat = _ChatProxy(self._client.chat)
        self.embeddings = _EmbeddingsProxy(self._client.embeddings)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


class AsyncOpenAI:
    """Drop-in replacement for openai.AsyncOpenAI with Proxle proxy support.

    Same interface as OpenAI but for async usage.
    """

    def __init__(
        self,
        *,
        api_key: str,
        proxy_key: Optional[str] = None,
        proxy_url: Optional[str] = None,
        **kwargs: Any,
    ):
        try:
            import openai as _openai
        except ImportError:
            raise ImportError(
                "The 'openai' package is required for proxle.AsyncOpenAI. "
                "Install it with: pip install proxle[openai]"
            )

        resolved_proxy_key = get_proxy_key(proxy_key)
        resolved_proxy_url = get_proxy_url(proxy_url)

        self._client = _openai.AsyncOpenAI(
            api_key=api_key,
            base_url=f"{resolved_proxy_url}/v1/proxy/openai",
            default_headers=build_default_headers(resolved_proxy_key, api_key),
            **kwargs,
        )

        # Async proxies use same wrapper classes - openai SDK methods
        # return coroutines for AsyncOpenAI, our wrapper is transparent
        self.chat = _ChatProxy(self._client.chat)
        self.embeddings = _EmbeddingsProxy(self._client.embeddings)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)
