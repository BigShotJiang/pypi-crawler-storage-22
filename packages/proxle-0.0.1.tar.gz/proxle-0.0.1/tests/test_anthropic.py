"""Tests for the Anthropic provider wrapper."""

import json
from unittest.mock import MagicMock, patch

import pytest

from proxle.providers.anthropic import (
    Anthropic,
    AsyncAnthropic,
    _MessagesProxy,
)


@pytest.fixture
def mock_anthropic_module():
    """Create a mock anthropic module."""
    mock_module = MagicMock()

    mock_client = MagicMock()
    mock_client.messages.create.return_value = {
        "id": "msg_123",
        "content": [{"type": "text", "text": "Hello!"}],
    }
    mock_module.Anthropic.return_value = mock_client

    mock_async_client = MagicMock()
    mock_module.AsyncAnthropic.return_value = mock_async_client

    return mock_module


class TestAnthropicConstructor:
    def test_sets_base_url_to_proxy(self, mock_anthropic_module, proxy_key, proxy_url):
        with patch.dict("sys.modules", {"anthropic": mock_anthropic_module}):
            Anthropic(api_key="sk-ant-test", proxy_key=proxy_key, proxy_url=proxy_url)

        call_kwargs = mock_anthropic_module.Anthropic.call_args[1]
        assert call_kwargs["base_url"] == f"{proxy_url}/v1/proxy/anthropic"

    def test_sets_default_headers(self, mock_anthropic_module, proxy_key, proxy_url):
        with patch.dict("sys.modules", {"anthropic": mock_anthropic_module}):
            Anthropic(api_key="sk-ant-test", proxy_key=proxy_key, proxy_url=proxy_url)

        call_kwargs = mock_anthropic_module.Anthropic.call_args[1]
        assert call_kwargs["default_headers"]["X-Api-Key"] == proxy_key
        assert call_kwargs["default_headers"]["X-Provider-Key"] == "sk-ant-test"

    def test_raises_import_error_if_anthropic_not_installed(self, proxy_key, proxy_url):
        with patch.dict("sys.modules", {"anthropic": None}):
            with pytest.raises(ImportError, match="anthropic"):
                Anthropic(
                    api_key="sk-ant-test", proxy_key=proxy_key, proxy_url=proxy_url
                )


class TestMessagesProxy:
    def test_create_without_metadata(self):
        mock_original = MagicMock()
        proxy = _MessagesProxy(mock_original)
        proxy.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hi"}],
        )
        mock_original.create.assert_called_once_with(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hi"}],
        )

    def test_create_with_metadata(self):
        mock_original = MagicMock()
        proxy = _MessagesProxy(mock_original)
        metadata = {"feature": "summarizer", "user_id": "u_456"}
        proxy.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hi"}],
            metadata=metadata,
        )
        call_kwargs = mock_original.create.call_args[1]
        assert "metadata" not in call_kwargs
        assert json.loads(call_kwargs["extra_headers"]["X-Metadata"]) == metadata

    def test_stream_without_metadata(self):
        mock_original = MagicMock()
        proxy = _MessagesProxy(mock_original)
        proxy.stream(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hi"}],
        )
        mock_original.stream.assert_called_once()

    def test_stream_with_metadata(self):
        mock_original = MagicMock()
        proxy = _MessagesProxy(mock_original)
        metadata = {"feature": "chat"}
        proxy.stream(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hi"}],
            metadata=metadata,
        )
        call_kwargs = mock_original.stream.call_args[1]
        assert "metadata" not in call_kwargs
        assert json.loads(call_kwargs["extra_headers"]["X-Metadata"]) == metadata

    def test_create_preserves_existing_extra_headers(self):
        mock_original = MagicMock()
        proxy = _MessagesProxy(mock_original)
        proxy.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            messages=[],
            metadata={"feature": "chat"},
            extra_headers={"X-Custom": "value"},
        )
        call_kwargs = mock_original.create.call_args[1]
        assert call_kwargs["extra_headers"]["X-Custom"] == "value"
        assert "X-Metadata" in call_kwargs["extra_headers"]

    def test_delegates_unknown_attrs(self):
        mock_original = MagicMock()
        mock_original.some_method.return_value = "result"
        proxy = _MessagesProxy(mock_original)
        assert proxy.some_method() == "result"


class TestAsyncAnthropic:
    def test_constructor_sets_base_url(
        self, mock_anthropic_module, proxy_key, proxy_url
    ):
        with patch.dict("sys.modules", {"anthropic": mock_anthropic_module}):
            AsyncAnthropic(
                api_key="sk-ant-test", proxy_key=proxy_key, proxy_url=proxy_url
            )

        call_kwargs = mock_anthropic_module.AsyncAnthropic.call_args[1]
        assert call_kwargs["base_url"] == f"{proxy_url}/v1/proxy/anthropic"

    def test_has_messages_proxy(self, mock_anthropic_module, proxy_key, proxy_url):
        with patch.dict("sys.modules", {"anthropic": mock_anthropic_module}):
            client = AsyncAnthropic(
                api_key="sk-ant-test", proxy_key=proxy_key, proxy_url=proxy_url
            )

        assert isinstance(client.messages, _MessagesProxy)


class TestAnthropicGetattr:
    def test_delegates_to_underlying_client(
        self, mock_anthropic_module, proxy_key, proxy_url
    ):
        with patch.dict("sys.modules", {"anthropic": mock_anthropic_module}):
            client = Anthropic(
                api_key="sk-ant-test", proxy_key=proxy_key, proxy_url=proxy_url
            )

        _ = client.count_tokens
        mock_anthropic_module.Anthropic.return_value.count_tokens
