"""Tests for the Azure OpenAI provider wrapper."""

from unittest.mock import MagicMock, patch

import pytest

from proxle.providers.azure import AsyncAzureOpenAI, AzureOpenAI
from proxle.providers.openai import _ChatProxy, _EmbeddingsProxy


@pytest.fixture
def mock_openai_module():
    """Create a mock openai module with AzureOpenAI class."""
    mock_module = MagicMock()

    mock_client = MagicMock()
    mock_module.AzureOpenAI.return_value = mock_client

    mock_async_client = MagicMock()
    mock_module.AsyncAzureOpenAI.return_value = mock_async_client

    return mock_module


@pytest.fixture
def azure_endpoint():
    return "https://my-resource.openai.azure.com"


@pytest.fixture
def api_version():
    return "2024-02-01"


class TestAzureOpenAIConstructor:
    def test_sets_azure_endpoint_to_proxy(
        self, mock_openai_module, proxy_key, proxy_url, azure_endpoint, api_version
    ):
        with patch.dict("sys.modules", {"openai": mock_openai_module}):
            AzureOpenAI(
                api_key="sk-azure-test",
                azure_endpoint=azure_endpoint,
                api_version=api_version,
                proxy_key=proxy_key,
                proxy_url=proxy_url,
            )

        call_kwargs = mock_openai_module.AzureOpenAI.call_args[1]
        assert call_kwargs["azure_endpoint"] == f"{proxy_url}/v1/proxy/azure"

    def test_sets_azure_headers(
        self, mock_openai_module, proxy_key, proxy_url, azure_endpoint, api_version
    ):
        with patch.dict("sys.modules", {"openai": mock_openai_module}):
            AzureOpenAI(
                api_key="sk-azure-test",
                azure_endpoint=azure_endpoint,
                api_version=api_version,
                proxy_key=proxy_key,
                proxy_url=proxy_url,
            )

        call_kwargs = mock_openai_module.AzureOpenAI.call_args[1]
        headers = call_kwargs["default_headers"]
        assert headers["X-Azure-Endpoint"] == azure_endpoint
        assert headers["X-Azure-Api-Version"] == api_version

    def test_sets_proxy_auth_headers(
        self, mock_openai_module, proxy_key, proxy_url, azure_endpoint, api_version
    ):
        with patch.dict("sys.modules", {"openai": mock_openai_module}):
            AzureOpenAI(
                api_key="sk-azure-test",
                azure_endpoint=azure_endpoint,
                api_version=api_version,
                proxy_key=proxy_key,
                proxy_url=proxy_url,
            )

        call_kwargs = mock_openai_module.AzureOpenAI.call_args[1]
        headers = call_kwargs["default_headers"]
        assert headers["X-Api-Key"] == proxy_key
        assert headers["X-Provider-Key"] == "sk-azure-test"

    def test_has_chat_and_embeddings(
        self, mock_openai_module, proxy_key, proxy_url, azure_endpoint, api_version
    ):
        with patch.dict("sys.modules", {"openai": mock_openai_module}):
            client = AzureOpenAI(
                api_key="sk-azure-test",
                azure_endpoint=azure_endpoint,
                api_version=api_version,
                proxy_key=proxy_key,
                proxy_url=proxy_url,
            )

        assert isinstance(client.chat, _ChatProxy)
        assert isinstance(client.embeddings, _EmbeddingsProxy)

    def test_raises_import_error(self, proxy_key, proxy_url, azure_endpoint, api_version):
        with patch.dict("sys.modules", {"openai": None}):
            with pytest.raises(ImportError, match="openai"):
                AzureOpenAI(
                    api_key="sk-azure-test",
                    azure_endpoint=azure_endpoint,
                    api_version=api_version,
                    proxy_key=proxy_key,
                    proxy_url=proxy_url,
                )


class TestAsyncAzureOpenAI:
    def test_constructor_sets_proxy_endpoint(
        self, mock_openai_module, proxy_key, proxy_url, azure_endpoint, api_version
    ):
        with patch.dict("sys.modules", {"openai": mock_openai_module}):
            AsyncAzureOpenAI(
                api_key="sk-azure-test",
                azure_endpoint=azure_endpoint,
                api_version=api_version,
                proxy_key=proxy_key,
                proxy_url=proxy_url,
            )

        call_kwargs = mock_openai_module.AsyncAzureOpenAI.call_args[1]
        assert call_kwargs["azure_endpoint"] == f"{proxy_url}/v1/proxy/azure"

    def test_has_chat_and_embeddings(
        self, mock_openai_module, proxy_key, proxy_url, azure_endpoint, api_version
    ):
        with patch.dict("sys.modules", {"openai": mock_openai_module}):
            client = AsyncAzureOpenAI(
                api_key="sk-azure-test",
                azure_endpoint=azure_endpoint,
                api_version=api_version,
                proxy_key=proxy_key,
                proxy_url=proxy_url,
            )

        assert isinstance(client.chat, _ChatProxy)
        assert isinstance(client.embeddings, _EmbeddingsProxy)
