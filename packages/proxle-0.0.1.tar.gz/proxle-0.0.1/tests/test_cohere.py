"""Tests for the Cohere provider client."""

import json

import httpx
import pytest
import respx

from proxle.providers.cohere import Cohere


@pytest.fixture
def cohere_client(proxy_key, proxy_url):
    return Cohere(
        api_key="cohere-test-key",
        proxy_key=proxy_key,
        proxy_url=proxy_url,
    )


class TestCohereConstructor:
    def test_sets_base_url(self, cohere_client, proxy_url):
        assert cohere_client._base_url == f"{proxy_url}/v1/proxy/cohere"

    def test_stores_keys(self, cohere_client, proxy_key):
        assert cohere_client._proxy_key == proxy_key
        assert cohere_client._api_key == "cohere-test-key"


class TestCohereChat:
    @respx.mock
    def test_chat_sends_correct_request(self, cohere_client, proxy_url, proxy_key):
        route = respx.post(f"{proxy_url}/v1/proxy/cohere/v2/chat").mock(
            return_value=httpx.Response(200, json={"text": "Hello!"})
        )

        result = cohere_client.chat(message="Hi", model="command-r-plus")

        assert route.called
        request = route.calls[0].request
        body = json.loads(request.content)
        assert body["message"] == "Hi"
        assert body["model"] == "command-r-plus"
        assert result == {"text": "Hello!"}

    @respx.mock
    def test_chat_sends_metadata_header(self, cohere_client, proxy_url):
        route = respx.post(f"{proxy_url}/v1/proxy/cohere/v2/chat").mock(
            return_value=httpx.Response(200, json={"text": "ok"})
        )

        metadata = {"feature": "chat", "user_id": "u_123"}
        cohere_client.chat(message="Hi", metadata=metadata)

        request = route.calls[0].request
        assert json.loads(request.headers["X-Metadata"]) == metadata

    @respx.mock
    def test_chat_sends_proxy_auth_headers(self, cohere_client, proxy_url, proxy_key):
        route = respx.post(f"{proxy_url}/v1/proxy/cohere/v2/chat").mock(
            return_value=httpx.Response(200, json={"text": "ok"})
        )

        cohere_client.chat(message="Hi")

        request = route.calls[0].request
        assert request.headers["X-Api-Key"] == proxy_key
        assert request.headers["X-Provider-Key"] == "cohere-test-key"

    @respx.mock
    def test_chat_with_history(self, cohere_client, proxy_url):
        route = respx.post(f"{proxy_url}/v1/proxy/cohere/v2/chat").mock(
            return_value=httpx.Response(200, json={"text": "ok"})
        )

        history = [{"role": "USER", "message": "Hello"}, {"role": "CHATBOT", "message": "Hi!"}]
        cohere_client.chat(message="How are you?", chat_history=history)

        body = json.loads(route.calls[0].request.content)
        assert body["chat_history"] == history

    @respx.mock
    def test_chat_raises_on_error(self, cohere_client, proxy_url):
        respx.post(f"{proxy_url}/v1/proxy/cohere/v2/chat").mock(
            return_value=httpx.Response(401, text="Unauthorized")
        )

        with pytest.raises(httpx.HTTPStatusError):
            cohere_client.chat(message="Hi")


class TestCohereGenerate:
    @respx.mock
    def test_generate_sends_correct_request(self, cohere_client, proxy_url):
        route = respx.post(f"{proxy_url}/v1/proxy/cohere/v1/generate").mock(
            return_value=httpx.Response(200, json={"generations": [{"text": "output"}]})
        )

        result = cohere_client.generate(prompt="Tell me a joke")

        body = json.loads(route.calls[0].request.content)
        assert body["prompt"] == "Tell me a joke"
        assert body["model"] == "command"
        assert result == {"generations": [{"text": "output"}]}

    @respx.mock
    def test_generate_with_metadata(self, cohere_client, proxy_url):
        route = respx.post(f"{proxy_url}/v1/proxy/cohere/v1/generate").mock(
            return_value=httpx.Response(200, json={"generations": []})
        )

        metadata = {"feature": "generation"}
        cohere_client.generate(prompt="Test", metadata=metadata)

        request = route.calls[0].request
        assert json.loads(request.headers["X-Metadata"]) == metadata


class TestCohereEmbed:
    @respx.mock
    def test_embed_sends_correct_request(self, cohere_client, proxy_url):
        route = respx.post(f"{proxy_url}/v1/proxy/cohere/v1/embed").mock(
            return_value=httpx.Response(200, json={"embeddings": [[0.1, 0.2]]})
        )

        result = cohere_client.embed(texts=["hello"])

        body = json.loads(route.calls[0].request.content)
        assert body["texts"] == ["hello"]
        assert body["model"] == "embed-english-v3.0"
        assert body["input_type"] == "search_document"
        assert result == {"embeddings": [[0.1, 0.2]]}


class TestCohereContextManager:
    def test_context_manager(self, proxy_key, proxy_url):
        with Cohere(
            api_key="cohere-test-key",
            proxy_key=proxy_key,
            proxy_url=proxy_url,
        ) as client:
            assert isinstance(client, Cohere)
