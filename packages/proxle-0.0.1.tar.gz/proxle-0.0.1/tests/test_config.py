"""Tests for SDK configuration module."""

import pytest

from proxle._config import (
    DEFAULT_PROXY_URL,
    ENV_PROXY_KEY,
    ENV_PROXY_URL,
    get_proxy_key,
    get_proxy_url,
)


class TestGetProxyUrl:
    def test_returns_override(self):
        assert get_proxy_url("https://custom.proxy.com") == "https://custom.proxy.com"

    def test_strips_trailing_slash(self):
        assert get_proxy_url("https://custom.proxy.com/") == "https://custom.proxy.com"

    def test_reads_env_var(self, monkeypatch):
        monkeypatch.setenv(ENV_PROXY_URL, "https://env.proxy.com")
        assert get_proxy_url() == "https://env.proxy.com"

    def test_env_var_strips_trailing_slash(self, monkeypatch):
        monkeypatch.setenv(ENV_PROXY_URL, "https://env.proxy.com/")
        assert get_proxy_url() == "https://env.proxy.com"

    def test_override_takes_precedence_over_env(self, monkeypatch):
        monkeypatch.setenv(ENV_PROXY_URL, "https://env.proxy.com")
        assert get_proxy_url("https://override.proxy.com") == "https://override.proxy.com"

    def test_returns_default_when_no_override_or_env(self, monkeypatch):
        monkeypatch.delenv(ENV_PROXY_URL, raising=False)
        assert get_proxy_url() == DEFAULT_PROXY_URL


class TestGetProxyKey:
    def test_returns_override(self):
        assert get_proxy_key("pk_live_abc") == "pk_live_abc"

    def test_reads_env_var(self, monkeypatch):
        monkeypatch.setenv(ENV_PROXY_KEY, "pk_live_env")
        assert get_proxy_key() == "pk_live_env"

    def test_override_takes_precedence_over_env(self, monkeypatch):
        monkeypatch.setenv(ENV_PROXY_KEY, "pk_live_env")
        assert get_proxy_key("pk_live_override") == "pk_live_override"

    def test_raises_when_no_key(self, monkeypatch):
        monkeypatch.delenv(ENV_PROXY_KEY, raising=False)
        with pytest.raises(ValueError, match="Proxle API key is required"):
            get_proxy_key()

    def test_error_message_mentions_env_var(self, monkeypatch):
        monkeypatch.delenv(ENV_PROXY_KEY, raising=False)
        with pytest.raises(ValueError, match=ENV_PROXY_KEY):
            get_proxy_key()
