"""Tests for the Gemini provider client."""

import json

import httpx
import pytest
import respx

from proxle.providers.gemini import Gemini


@pytest.fixture
def gemini_client(proxy_key, proxy_url):
    return Gemini(
        api_key="gemini-test-key",
        proxy_key=proxy_key,
        proxy_url=proxy_url,
    )


class TestGeminiConstructor:
    def test_sets_base_url(self, gemini_client, proxy_url):
        assert gemini_client._base_url == f"{proxy_url}/v1/proxy/gemini"

    def test_stores_keys(self, gemini_client, proxy_key):
        assert gemini_client._proxy_key == proxy_key
        assert gemini_client._api_key == "gemini-test-key"


class TestGeminiGenerateContent:
    @respx.mock
    def test_sends_correct_request(self, gemini_client, proxy_url):
        url = f"{proxy_url}/v1/proxy/gemini/v1beta/models/gemini-1.5-pro:generateContent"
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200,
                json={
                    "candidates": [
                        {"content": {"parts": [{"text": "Hello!"}]}}
                    ]
                },
            )
        )

        contents = [{"role": "user", "parts": [{"text": "Hi"}]}]
        result = gemini_client.generate_content(
            model="gemini-1.5-pro", contents=contents
        )

        assert route.called
        body = json.loads(route.calls[0].request.content)
        assert body["contents"] == contents
        assert "candidates" in result

    @respx.mock
    def test_sends_metadata_header(self, gemini_client, proxy_url):
        url = f"{proxy_url}/v1/proxy/gemini/v1beta/models/gemini-1.5-pro:generateContent"
        route = respx.post(url).mock(
            return_value=httpx.Response(200, json={"candidates": []})
        )

        metadata = {"feature": "chat"}
        gemini_client.generate_content(
            model="gemini-1.5-pro",
            contents=[{"role": "user", "parts": [{"text": "Hi"}]}],
            metadata=metadata,
        )

        request = route.calls[0].request
        assert json.loads(request.headers["X-Metadata"]) == metadata

    @respx.mock
    def test_sends_proxy_auth_headers(self, gemini_client, proxy_url, proxy_key):
        url = f"{proxy_url}/v1/proxy/gemini/v1beta/models/gemini-1.5-pro:generateContent"
        route = respx.post(url).mock(
            return_value=httpx.Response(200, json={"candidates": []})
        )

        gemini_client.generate_content(
            model="gemini-1.5-pro",
            contents=[{"role": "user", "parts": [{"text": "Hi"}]}],
        )

        request = route.calls[0].request
        assert request.headers["X-Api-Key"] == proxy_key
        assert request.headers["X-Provider-Key"] == "gemini-test-key"

    @respx.mock
    def test_with_generation_config(self, gemini_client, proxy_url):
        url = f"{proxy_url}/v1/proxy/gemini/v1beta/models/gemini-1.5-pro:generateContent"
        route = respx.post(url).mock(
            return_value=httpx.Response(200, json={"candidates": []})
        )

        gemini_client.generate_content(
            model="gemini-1.5-pro",
            contents=[{"role": "user", "parts": [{"text": "Hi"}]}],
            generation_config={"temperature": 0.7, "maxOutputTokens": 100},
        )

        body = json.loads(route.calls[0].request.content)
        assert body["generationConfig"]["temperature"] == 0.7

    @respx.mock
    def test_with_safety_settings(self, gemini_client, proxy_url):
        url = f"{proxy_url}/v1/proxy/gemini/v1beta/models/gemini-1.5-pro:generateContent"
        route = respx.post(url).mock(
            return_value=httpx.Response(200, json={"candidates": []})
        )

        safety = [{"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"}]
        gemini_client.generate_content(
            model="gemini-1.5-pro",
            contents=[{"role": "user", "parts": [{"text": "Hi"}]}],
            safety_settings=safety,
        )

        body = json.loads(route.calls[0].request.content)
        assert body["safetySettings"] == safety

    @respx.mock
    def test_raises_on_error(self, gemini_client, proxy_url):
        url = f"{proxy_url}/v1/proxy/gemini/v1beta/models/gemini-1.5-pro:generateContent"
        respx.post(url).mock(
            return_value=httpx.Response(403, text="Forbidden")
        )

        with pytest.raises(httpx.HTTPStatusError):
            gemini_client.generate_content(
                model="gemini-1.5-pro",
                contents=[{"role": "user", "parts": [{"text": "Hi"}]}],
            )


class TestGeminiEmbedContent:
    @respx.mock
    def test_embed_sends_correct_request(self, gemini_client, proxy_url):
        url = f"{proxy_url}/v1/proxy/gemini/v1beta/models/text-embedding-004:embedContent"
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200, json={"embedding": {"values": [0.1, 0.2]}}
            )
        )

        content = {"parts": [{"text": "hello"}]}
        result = gemini_client.embed_content(
            model="text-embedding-004", content=content
        )

        body = json.loads(route.calls[0].request.content)
        assert body["content"] == content
        assert "embedding" in result

    @respx.mock
    def test_embed_with_task_type(self, gemini_client, proxy_url):
        url = f"{proxy_url}/v1/proxy/gemini/v1beta/models/text-embedding-004:embedContent"
        route = respx.post(url).mock(
            return_value=httpx.Response(200, json={"embedding": {"values": []}})
        )

        gemini_client.embed_content(
            model="text-embedding-004",
            content={"parts": [{"text": "hello"}]},
            task_type="RETRIEVAL_DOCUMENT",
            title="My doc",
        )

        body = json.loads(route.calls[0].request.content)
        assert body["taskType"] == "RETRIEVAL_DOCUMENT"
        assert body["title"] == "My doc"


class TestGeminiCountTokens:
    @respx.mock
    def test_count_tokens_sends_correct_request(self, gemini_client, proxy_url):
        url = f"{proxy_url}/v1/proxy/gemini/v1beta/models/gemini-1.5-pro:countTokens"
        route = respx.post(url).mock(
            return_value=httpx.Response(200, json={"totalTokens": 5})
        )

        contents = [{"role": "user", "parts": [{"text": "Hello world"}]}]
        result = gemini_client.count_tokens(model="gemini-1.5-pro", contents=contents)

        body = json.loads(route.calls[0].request.content)
        assert body["contents"] == contents
        assert result["totalTokens"] == 5


class TestGeminiContextManager:
    def test_context_manager(self, proxy_key, proxy_url):
        with Gemini(
            api_key="gemini-test-key",
            proxy_key=proxy_key,
            proxy_url=proxy_url,
        ) as client:
            assert isinstance(client, Gemini)
