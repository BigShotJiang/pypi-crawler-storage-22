"""Tests for metadata validation and serialization."""

import pytest

from proxle._exceptions import ProxleConfigError
from proxle._metadata import MAX_METADATA_BYTES, validate_and_serialize


class TestValidateAndSerialize:
    def test_returns_none_for_none(self):
        assert validate_and_serialize(None) is None

    def test_returns_none_for_empty_dict(self):
        assert validate_and_serialize({}) is None

    def test_serializes_simple_metadata(self):
        result = validate_and_serialize({"feature": "chat"})
        assert result == '{"feature":"chat"}'

    def test_serializes_multiple_fields(self):
        result = validate_and_serialize({"feature": "chat", "user_id": "u_123"})
        assert '"feature":"chat"' in result
        assert '"user_id":"u_123"' in result

    def test_serializes_numeric_values(self):
        result = validate_and_serialize({"count": 42, "rate": 0.95})
        assert '"count":42' in result
        assert '"rate":0.95' in result

    def test_serializes_boolean_values(self):
        result = validate_and_serialize({"active": True})
        assert '"active":true' in result

    def test_raises_for_non_dict(self):
        with pytest.raises(ProxleConfigError, match="metadata must be a dict"):
            validate_and_serialize("not a dict")  # type: ignore

    def test_raises_for_non_serializable(self):
        with pytest.raises(ProxleConfigError, match="JSON-serializable"):
            validate_and_serialize({"obj": object()})

    def test_raises_for_oversized_metadata(self):
        large_metadata = {"key": "x" * (MAX_METADATA_BYTES + 1)}
        with pytest.raises(ProxleConfigError, match="exceeds"):
            validate_and_serialize(large_metadata)

    def test_uses_compact_separators(self):
        result = validate_and_serialize({"a": 1, "b": 2})
        # Compact separators: no spaces after , and :
        assert " " not in result
