"""Tests for the OpenAI provider wrapper."""

import json
from unittest.mock import MagicMock, patch

import pytest

from proxle.providers.openai import (
    AsyncOpenAI,
    OpenAI,
    _ChatCompletionsProxy,
    _ChatProxy,
    _EmbeddingsProxy,
)


@pytest.fixture
def mock_openai_module():
    """Create a mock openai module with the needed classes."""
    mock_module = MagicMock()

    # Mock sync client
    mock_client = MagicMock()
    mock_client.chat.completions.create.return_value = {
        "id": "chatcmpl-123",
        "choices": [{"message": {"content": "Hello!"}}],
    }
    mock_client.embeddings.create.return_value = {
        "data": [{"embedding": [0.1, 0.2]}],
    }
    mock_module.OpenAI.return_value = mock_client

    # Mock async client
    mock_async_client = MagicMock()
    mock_module.AsyncOpenAI.return_value = mock_async_client

    return mock_module


class TestOpenAIConstructor:
    def test_sets_base_url_to_proxy(self, mock_openai_module, proxy_key, proxy_url):
        with patch.dict("sys.modules", {"openai": mock_openai_module}):
            OpenAI(api_key="sk-test", proxy_key=proxy_key, proxy_url=proxy_url)

        call_kwargs = mock_openai_module.OpenAI.call_args[1]
        assert call_kwargs["base_url"] == f"{proxy_url}/v1/proxy/openai"

    def test_sets_default_headers(self, mock_openai_module, proxy_key, proxy_url):
        with patch.dict("sys.modules", {"openai": mock_openai_module}):
            OpenAI(api_key="sk-test", proxy_key=proxy_key, proxy_url=proxy_url)

        call_kwargs = mock_openai_module.OpenAI.call_args[1]
        assert call_kwargs["default_headers"]["X-Api-Key"] == proxy_key
        assert call_kwargs["default_headers"]["X-Provider-Key"] == "sk-test"

    def test_passes_extra_kwargs_to_underlying_client(
        self, mock_openai_module, proxy_key, proxy_url
    ):
        with patch.dict("sys.modules", {"openai": mock_openai_module}):
            OpenAI(
                api_key="sk-test",
                proxy_key=proxy_key,
                proxy_url=proxy_url,
                timeout=30,
            )

        call_kwargs = mock_openai_module.OpenAI.call_args[1]
        assert call_kwargs["timeout"] == 30

    def test_raises_import_error_if_openai_not_installed(self, proxy_key, proxy_url):
        with patch.dict("sys.modules", {"openai": None}):
            with pytest.raises(ImportError, match="openai"):
                OpenAI(api_key="sk-test", proxy_key=proxy_key, proxy_url=proxy_url)


class TestChatCompletionsProxy:
    def test_create_without_metadata(self):
        mock_original = MagicMock()
        proxy = _ChatCompletionsProxy(mock_original)
        proxy.create(model="gpt-4", messages=[{"role": "user", "content": "Hi"}])
        mock_original.create.assert_called_once_with(
            model="gpt-4", messages=[{"role": "user", "content": "Hi"}]
        )

    def test_create_with_metadata(self):
        mock_original = MagicMock()
        proxy = _ChatCompletionsProxy(mock_original)
        metadata = {"feature": "chat", "user_id": "u_123"}
        proxy.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hi"}],
            metadata=metadata,
        )
        call_kwargs = mock_original.create.call_args[1]
        assert "metadata" not in call_kwargs
        assert json.loads(call_kwargs["extra_headers"]["X-Metadata"]) == metadata

    def test_create_preserves_existing_extra_headers(self):
        mock_original = MagicMock()
        proxy = _ChatCompletionsProxy(mock_original)
        proxy.create(
            model="gpt-4",
            messages=[],
            metadata={"feature": "chat"},
            extra_headers={"X-Custom": "value"},
        )
        call_kwargs = mock_original.create.call_args[1]
        assert call_kwargs["extra_headers"]["X-Custom"] == "value"
        assert "X-Metadata" in call_kwargs["extra_headers"]

    def test_delegates_unknown_attrs(self):
        mock_original = MagicMock()
        mock_original.some_method.return_value = "result"
        proxy = _ChatCompletionsProxy(mock_original)
        assert proxy.some_method() == "result"


class TestChatProxy:
    def test_has_completions_proxy(self):
        mock_chat = MagicMock()
        proxy = _ChatProxy(mock_chat)
        assert isinstance(proxy.completions, _ChatCompletionsProxy)


class TestEmbeddingsProxy:
    def test_create_without_metadata(self):
        mock_original = MagicMock()
        proxy = _EmbeddingsProxy(mock_original)
        proxy.create(input=["hello"], model="text-embedding-ada-002")
        mock_original.create.assert_called_once_with(
            input=["hello"], model="text-embedding-ada-002"
        )

    def test_create_with_metadata(self):
        mock_original = MagicMock()
        proxy = _EmbeddingsProxy(mock_original)
        metadata = {"feature": "search"}
        proxy.create(input=["hello"], model="text-embedding-ada-002", metadata=metadata)
        call_kwargs = mock_original.create.call_args[1]
        assert "metadata" not in call_kwargs
        assert json.loads(call_kwargs["extra_headers"]["X-Metadata"]) == metadata


class TestAsyncOpenAI:
    def test_constructor_sets_base_url(self, mock_openai_module, proxy_key, proxy_url):
        with patch.dict("sys.modules", {"openai": mock_openai_module}):
            AsyncOpenAI(api_key="sk-test", proxy_key=proxy_key, proxy_url=proxy_url)

        call_kwargs = mock_openai_module.AsyncOpenAI.call_args[1]
        assert call_kwargs["base_url"] == f"{proxy_url}/v1/proxy/openai"

    def test_has_chat_and_embeddings(self, mock_openai_module, proxy_key, proxy_url):
        with patch.dict("sys.modules", {"openai": mock_openai_module}):
            client = AsyncOpenAI(
                api_key="sk-test", proxy_key=proxy_key, proxy_url=proxy_url
            )

        assert isinstance(client.chat, _ChatProxy)
        assert isinstance(client.embeddings, _EmbeddingsProxy)


class TestOpenAIGetattr:
    def test_delegates_to_underlying_client(
        self, mock_openai_module, proxy_key, proxy_url
    ):
        with patch.dict("sys.modules", {"openai": mock_openai_module}):
            client = OpenAI(
                api_key="sk-test", proxy_key=proxy_key, proxy_url=proxy_url
            )

        # Access an attribute not defined on our wrapper
        _ = client.models
        mock_openai_module.OpenAI.return_value.models  # should be accessed
