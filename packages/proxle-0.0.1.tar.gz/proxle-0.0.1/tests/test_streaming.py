"""Tests for streaming support across providers."""

import json

import httpx
import pytest
import respx

from proxle.providers.cohere import Cohere
from proxle.providers.gemini import Gemini


def make_sse_response(*events, done=True):
    """Build an SSE byte stream for testing."""
    lines = []
    for event in events:
        lines.append(f"data: {json.dumps(event)}")
    if done:
        lines.append("data: [DONE]")
    return "\n".join(lines) + "\n"


class TestCohereStreaming:
    @respx.mock
    def test_chat_stream_yields_events(self, proxy_key, proxy_url):
        client = Cohere(
            api_key="cohere-key", proxy_key=proxy_key, proxy_url=proxy_url
        )

        events = [
            {"event_type": "text-generation", "text": "Hello"},
            {"event_type": "text-generation", "text": " world"},
        ]
        sse_body = make_sse_response(*events)

        route = respx.post(f"{proxy_url}/v1/proxy/cohere/v2/chat").mock(
            return_value=httpx.Response(
                200,
                content=sse_body.encode(),
                headers={"Content-Type": "text/event-stream"},
            )
        )

        result = list(client.chat(message="Hi", stream=True))

        assert len(result) == 2
        assert result[0]["text"] == "Hello"
        assert result[1]["text"] == " world"

    @respx.mock
    def test_chat_stream_sends_metadata(self, proxy_key, proxy_url):
        client = Cohere(
            api_key="cohere-key", proxy_key=proxy_key, proxy_url=proxy_url
        )

        sse_body = make_sse_response({"text": "ok"})
        route = respx.post(f"{proxy_url}/v1/proxy/cohere/v2/chat").mock(
            return_value=httpx.Response(
                200,
                content=sse_body.encode(),
                headers={"Content-Type": "text/event-stream"},
            )
        )

        metadata = {"feature": "stream_test"}
        list(client.chat(message="Hi", stream=True, metadata=metadata))

        request = route.calls[0].request
        assert json.loads(request.headers["X-Metadata"]) == metadata


class TestGeminiStreaming:
    @respx.mock
    def test_generate_content_stream(self, proxy_key, proxy_url):
        client = Gemini(
            api_key="gemini-key", proxy_key=proxy_key, proxy_url=proxy_url
        )

        events = [
            {"candidates": [{"content": {"parts": [{"text": "Hello"}]}}]},
            {"candidates": [{"content": {"parts": [{"text": " world"}]}}]},
        ]
        sse_body = make_sse_response(*events)

        url = f"{proxy_url}/v1/proxy/gemini/v1beta/models/gemini-1.5-pro:streamGenerateContent"
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200,
                content=sse_body.encode(),
                headers={"Content-Type": "text/event-stream"},
            )
        )

        result = list(
            client.generate_content(
                model="gemini-1.5-pro",
                contents=[{"role": "user", "parts": [{"text": "Hi"}]}],
                stream=True,
            )
        )

        assert len(result) == 2
        assert result[0]["candidates"][0]["content"]["parts"][0]["text"] == "Hello"

    @respx.mock
    def test_stream_uses_correct_action(self, proxy_key, proxy_url):
        client = Gemini(
            api_key="gemini-key", proxy_key=proxy_key, proxy_url=proxy_url
        )

        sse_body = make_sse_response({"candidates": []})
        url = f"{proxy_url}/v1/proxy/gemini/v1beta/models/gemini-1.5-pro:streamGenerateContent"
        route = respx.post(url).mock(
            return_value=httpx.Response(
                200,
                content=sse_body.encode(),
                headers={"Content-Type": "text/event-stream"},
            )
        )

        list(
            client.generate_content(
                model="gemini-1.5-pro",
                contents=[{"role": "user", "parts": [{"text": "Hi"}]}],
                stream=True,
            )
        )

        assert route.called
        # The URL should contain streamGenerateContent, not generateContent
        assert "streamGenerateContent" in str(route.calls[0].request.url)
