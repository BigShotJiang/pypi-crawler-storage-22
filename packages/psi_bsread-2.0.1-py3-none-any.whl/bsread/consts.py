import mflow


PULL = mflow.PULL
PUSH = mflow.PUSH
PUB = mflow.PUB
SUB = mflow.SUB

CONNECT = "connect"
BIND = "bind"

BASE_DISPATCHER_URL = "https://dispatcher-api.psi.ch"
DEFAULT_DISPATCHER_URL = BASE_DISPATCHER_URL + "/sf-databuffer"



