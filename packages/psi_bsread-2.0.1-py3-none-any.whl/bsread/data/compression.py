import struct
import numpy as np
from logging import getLogger
_logger = getLogger(__name__)


try:
    import bitshuffle
except:
    _logger.warning("Bitshuffle not installed")

try:
    import lz4.block
except:
    _logger.warning("LZ4 not installed")

class NoCompression:

    @staticmethod
    def unpack_data(raw_string, dtype, shape=None):
        """
        Convert raw bytes into the specified numpy type.
        :param raw_string: Raw bytes to convert.
        :param dtype: dtype to use for the result.
        :param shape: Shape of the result.
        :return: Numpy array of dtype and shape.
        """
        raw_data = np.frombuffer(raw_string, dtype=dtype)

        # Empty data received.
        if raw_data.size == 0:
            return None

        # Do not reshape scalars.
        if shape is not None and shape != [1]:
            # Numpy is slowest dimension first, but bsread is fastest dimension first.
            raw_data = raw_data.reshape(shape[::-1])

        return raw_data

    @staticmethod
    def pack_data(numpy_array, dtype=None):
        """
        Convert numpy array to byte array.
        :param numpy_array: Numpy array to convert.
        :param dtype: Ignored. Here just to have a consistent interface.
        :return: Bytes array of provided numpy array.
        """
        return numpy_array.tobytes()


class LZ4:
    @staticmethod
    def unpack_data(raw_bytes, dtype, shape=None):
        """
        Convert raw bytes into the specified numpy type.
        :param raw_bytes: Raw bytes to convert (lz4-compressed).
        :param dtype: dtype to use for the result.
        :param shape: Shape of the result.
        :return: Numpy array of dtype and shape.
        """

        # Empty data received.
        if not raw_bytes:
            return None

        raw_data = np.frombuffer(raw_bytes, dtype=np.uint8)

        # Read uncompressed size (first 4 bytes). Same endianness as the array.
        endianness = "big" if (type(dtype) == str and dtype.startswith(">")) else "little"
        fmt = "<I" if endianness == "little" else ">I"
        uncompressed_size = struct.unpack(fmt, raw_data[:4])[0]

        # Decompress payload
        decompressed_bytes = lz4.block.decompress(
            raw_data[4:],
            uncompressed_size=uncompressed_size
        )

        # Convert bytes to numpy array
        raw_data = np.frombuffer(decompressed_bytes, dtype=dtype)

        if raw_data.size == 0:
            return None

        # Do not reshape scalars
        if shape is not None and shape != [1]:
            # Numpy is slowest dimension first, but bsread is fastest dimension first
            raw_data = raw_data.reshape(shape[::-1])

        return raw_data

    @staticmethod
    def pack_data(numpy_array, dtype=None):
        """
        Convert numpy array to byte array.
        :param numpy_array: Numpy array to convert.
        :param dtype: Ignored. Here just to have a consistent interface.
        :return: LZ4-compressed bytes of provided numpy array.
        """
        # Convert numpy array to raw bytes
        raw_bytes = numpy_array.tobytes()
        uncompressed_size = len(raw_bytes)

        # Compress using lz4 block
        compressed_payload = lz4.block.compress(raw_bytes, store_size=False)

        # Prepend uncompressed size (4 bytes, little-endian)
        header = struct.pack("<I", uncompressed_size)

        return header + compressed_payload



class BitshuffleLZ4:

    # numpy type definitions can be found at: http://docs.scipy.org/doc/numpy/reference/arrays.dtypes.html
    @staticmethod
    def unpack_data(raw_bytes, dtype, shape=None):
        """
        Convert raw bytes into the specified numpy type.
        :param raw_bytes: Raw bytes to convert.
        :param dtype: dtype to use for the result.
        :param shape: Shape of the result.
        :return: Numpy array of dtype and shape.
        """
        # Interpret the bytes as a numpy array.
        raw_data = np.frombuffer(raw_bytes, dtype=np.uint8)

        # If the numpy array is empty, return it as such.
        if raw_data.size == 0:
            return None

        # Uncompressed block size, big endian, int64 (long long)
        unpacked_length = struct.unpack(">q", raw_data[0:8].tobytes())[0]

        # Empty array was transmitted.
        if unpacked_length == 0:
            return None

        # Type of the output array.
        dtype = np.dtype(dtype)
        n_bytes_per_element = dtype.itemsize

        # Either the unpacked length or the dtype is wrong.
        if unpacked_length % n_bytes_per_element != 0:
            raise ValueError("Invalid unpacked length or dtype for raw bytes.")

        # How many bytes per element we use.
        n_elements = int(unpacked_length / n_bytes_per_element)

        #TODO: do strings really need the following special case?
        # shape == [1] and n_elements > 1 is used for strings.
        if shape is None or (shape == [1] and n_elements > 1):
            shape = (n_elements,)

        # Compression block size, big endian, int32 (int). Divide by number of bytes per element.
        header_compression_block_size = struct.unpack(">i", raw_data[8:12].tobytes())[0]
        n_bytes_per_element = np.dtype(dtype).itemsize
        compression_block_size = header_compression_block_size / n_bytes_per_element

        # If shape is not provided use the original length.
        if shape is None:
            shape = (unpacked_length,)

        # Numpy is slowest dimension first, but bsread is fastest dimension first.
        shape = shape[::-1]

        # Actual data.
        byte_array = bitshuffle.decompress_lz4(raw_data[12:], block_size=compression_block_size,
                                               shape=shape, dtype=dtype)

        return byte_array


    @staticmethod
    def pack_data(numpy_array, dtype):
        """
        Compress the provided numpy array.
        :param numpy_array: Array to compress.
        :param dtype: Data type (Numpy).
        :return: Header (unpacked length, compression block size) + Compressed data
        """
        # Uncompressed block size, big endian, int64 (long long)
        unpacked_length_bytes = struct.pack(">q", numpy_array.nbytes)

        n_bytes_per_element = np.dtype(dtype).itemsize
        compression_block_size = BitshuffleLZ4.get_compression_block_size(n_bytes_per_element)

        # We multiply the compression block size by the n_bytes_per_element, because the HDF5 filter does so.
        # https://github.com/kiyo-masui/bitshuffle/blob/04e58bd553304ec26e222654f1d9b6ff64e97d10/src/bshuf_h5filter.c#L167
        header_compression_block_size = compression_block_size * n_bytes_per_element
        # Compression block size, big endian, int32 (int).
        block_size_bytes = struct.pack(">i", header_compression_block_size)

        compressed_bytes = bitshuffle.compress_lz4(numpy_array, compression_block_size).tobytes()

        return unpacked_length_bytes + block_size_bytes + compressed_bytes

    target_block_size = 8192
    minimum_block_size = 128
    block_size_multiplier = 8


    @staticmethod
    def get_compression_block_size(n_bytes_per_element):

        block_size = BitshuffleLZ4.target_block_size / n_bytes_per_element

        # Make the target block size the closest multiple of block_size_multiplier.
        block_size = (block_size // BitshuffleLZ4.block_size_multiplier) * BitshuffleLZ4.block_size_multiplier

        # Since it is a multiple of block_size_multiplier (which is an int) it is always an int.
        block_size = int(block_size)

        return max(block_size, BitshuffleLZ4.minimum_block_size)



