"""Secure credential storage using OS keyring with chunking support."""

from typing import Optional

import keyring
import keyring.errors


class CredentialManager:
    """
    Manages storage of large secrets in the OS keyring by splitting them into chunks.

    This class addresses limitations in some keyring backends, such as the
    Windows Credential Manager's 512-byte limit for generic credentials,
    by transparently handling the splitting (chunking) and reassembly of
    large secrets.
    """

    def __init__(self, service_name: str, chunk_size: int = 450) -> None:
        """
        Initializes the CredentialManager.

        Args:
            service_name (str): The name of the service under which credentials
                will be stored in the keyring.
            chunk_size (int, optional): The maximum size in bytes for each
                secret chunk. Defaults to 450 to safely stay under standard
                512-byte limits including overhead.
        """
        self.service_name = service_name
        self.chunk_size = chunk_size

    def _get_part_key(self, base_name: str, index: int) -> str:
        """
        Generates the specific key name for a chunk.

        Args:
            base_name (str): The base name of the secret.
            index (int): The chunk index.

        Returns:
            str: The formatted key for the chunk (e.g., 'secret.part0').
        """
        return f"{base_name}.part{index}"

    def delete_secret(self, key_base_name: str) -> None:
        """
        Deletes all chunks associated with a base key name.

        Iterates and removes 'key.part0', 'key.part1', etc., until no more
        parts are found.

        Args:
            key_base_name (str): The base name of the secret to delete.
        """
        i = 0
        while True:
            part_key = self._get_part_key(key_base_name, i)
            try:
                if keyring.get_password(self.service_name, part_key) is not None:
                    keyring.delete_password(self.service_name, part_key)
                    i += 1
                else:
                    break
            except keyring.errors.PasswordDeleteError:
                break

    def save_secret(self, key_base_name: str, secret: str) -> None:
        """
        Splits and saves a secret into the keyring.

        Existing chunks for the same key base name are first deleted to ensure
        data consistency.

        Args:
            key_base_name (str): The base name for the secret.
            secret (str): The actual secret data to store.
        """
        self.delete_secret(key_base_name)

        total_length = len(secret)
        chunks = [
            secret[i : i + self.chunk_size]
            for i in range(0, total_length, self.chunk_size)
        ]

        for i, chunk in enumerate(chunks):
            part_key = self._get_part_key(key_base_name, i)
            keyring.set_password(self.service_name, part_key, chunk)

    def get_secret(self, key_base_name: str) -> Optional[str]:
        """
        Retrieves and reassembles a secret from its chunks.

        Args:
            key_base_name (str): The base name of the secret to retrieve.

        Returns:
            Optional[str]: The reassembled secret, or None if not found.
        """
        secret_parts = []
        i = 0
        while True:
            part_key = self._get_part_key(key_base_name, i)
            part_val = keyring.get_password(self.service_name, part_key)

            if part_val is None:
                break

            secret_parts.append(part_val)
            i += 1

        if not secret_parts:
            return None

        return "".join(secret_parts)

    def clear_all_credentials(self, keys: list[str]) -> None:
        """
        Deletes all credentials for the specified keys.

        Args:
            keys (list[str]): A list of base key names to delete.
                For example: ["access_token", "refresh_token", "id_token"]
        """
        for key in keys:
            self.delete_secret(key)
