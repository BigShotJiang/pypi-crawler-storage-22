__version__ = '0.1.0'

from psychopy_aurora.components.auroraRecorder import AuroraRecorder
from psychopy_aurora.components.auroraTrigger import AuroraTrigger
