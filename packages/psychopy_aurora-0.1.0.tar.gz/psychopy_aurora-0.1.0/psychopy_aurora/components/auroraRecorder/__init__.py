"""Aurora Recorder Builder component."""

from __future__ import annotations
from psychopy.experiment.components import BaseComponent, Param
from pathlib import Path
from psychopy.experiment._experiment import getInitVals


class AuroraRecorder(BaseComponent):
    """Component responsible for controlling Aurora recordings."""

    categories = ["fNIRS"]
    targets = ['PsychoPy', 'PsychoJS']
    iconFile = Path(__file__).parent / 'example.png'
    tooltip = 'Connect to Aurora'
    plugin = "psychopy-aurora"

    def __init__(self, exp, parentName, name='AuroraRecorder'):
        super(AuroraRecorder, self).__init__(
            exp, parentName, name=name,
            startType='time (s)', startVal=0,
            stopType='duration (s)', stopVal=1,
            startEstim='', durationEstim='',
            saveStartStop=False
        )
        # imports used in generated code
        self.exp.requireImport("Aurora", "psychopy_aurora.aurora")
        self.exp.requireImport("aurora_connection", "psychopy_aurora.aurora")
        self.exp.requireImport("AuroraRequestError", "psychopy_aurora.aurora")
        self.exp.requireImport("print_json", "rich")
        self.exp.requireImport("AuroraSettings", "psychopy_aurora.models")
        self.exp.requireImport("AuroraRecorder", "psychopy_aurora.components.auroraRecorder")
        self.exp.requireImport("os")  # used for output path
        self.type = 'AuroraRecorder'

        # --- Builder parameters (simple and explicit) ---
        self.params = {
            'name': Param(
                name,
                valType='code',
                hint="Name of this Aurora recorder component",
                label="Name"
            ),
            'startRecording': Param(
                False,
                valType='bool',
                hint="Start recording when this component runs",
                label="Start recording"
            ),
            'stopRecording': Param(
                False,
                valType='bool',
                hint="Stop recording when this component runs",
                label="Stop recording"
            ),
            'previewMode': Param(
                False,
                valType='bool',
                hint="Enable Aurora preview mode instead of recording",
                label="Preview mode"
            ),
            'disabled': Param(False, valType='bool', updates='constant',
                              hint='Component enabled/disabled in Builder',
                              label='Disabled'),
        }

    # ------------------------------------------------------------------
    # Minimal instance init so PsychoPy doesn't crash (avoids NoneType.tStart)
    # ------------------------------------------------------------------
    def writeInitCode(self, buff):
        inits = getInitVals(self.params, 'PsychoPy')
        name = inits['name']
        subject_expr = "expInfo.get('participant', 'Unknown')"

        buff.writeIndentedLines("# --- Initialize and Control Aurora Recording (Blocking, globals() version) ---")
        buff.writeIndentedLines("print('[Aurora] --- Starting Aurora initialization and control block ---')")
        buff.writeIndentedLines("try:")
        buff.writeIndentedLines("    import time")
        buff.writeIndentedLines("    from psychopy import core, event")
        buff.writeIndentedLines("")
        buff.writeIndentedLines("    # Define Aurora globals safely")
        buff.writeIndentedLines("    globals()['aurora'] = globals().get('aurora', None)")
        buff.writeIndentedLines("    globals()['aurora_connection_ctx'] = globals().get('aurora_connection_ctx', None)")
        buff.writeIndentedLines("")
        buff.writeIndentedLines("    # Initialize Aurora only if not already connected")
        buff.writeIndentedLines("    if globals()['aurora'] is None:")
        buff.writeIndentedLines("        print('[Aurora] Searching for Aurora instance...')")
        buff.writeIndentedLines("        aurora_info = Aurora.discover_instances()")
        buff.writeIndentedLines("        if len(aurora_info) == 0:")
        buff.writeIndentedLines("            raise SystemExit('[Aurora] No Aurora instance found')")
        buff.writeIndentedLines("        aurora_instance_info = aurora_info[0]")
        buff.writeIndentedLines("        if aurora_instance_info is None:")
        buff.writeIndentedLines("            raise SystemExit('[Aurora] Could not find Aurora instance')")
        buff.writeIndentedLines("")
        buff.writeIndentedLines("        # Connect and store globally")
        buff.writeIndentedLines(
            "        globals()['aurora_connection_ctx'] = aurora_connection(aurora_instance_info, debug_requests=True)")
        buff.writeIndentedLines("        globals()['aurora'] = globals()['aurora_connection_ctx'].__enter__()")
        buff.writeIndentedLines("        print('[Aurora] Connected to Aurora API')")
        buff.writeIndentedLines("        print_json(data=globals()['aurora'].info().model_dump_json())")
        buff.writeIndentedLines("")
        buff.writeIndentedLines("        # Retrieve and display settings")
        buff.writeIndentedLines("        settings = globals()['aurora'].settings()")
        buff.writeIndentedLines("        print_json(data=settings.model_dump_json())")
        buff.writeIndentedLines("")
        buff.writeIndentedLines("        # Set output directory")
        buff.writeIndentedLines("        print('[Aurora] Setting output directory...')")
        buff.writeIndentedLines("        output_dir = os.path.expandvars('%USERPROFILE%/Documents/AuroraTest')")
        buff.writeIndentedLines("        new_settings = AuroraSettings(output_root=output_dir)")
        buff.writeIndentedLines("        globals()['aurora'].settings(new_settings)")
        buff.writeIndentedLines("        print_json(data=globals()['aurora'].settings().model_dump_json())")
        buff.writeIndentedLines("")
        buff.writeIndentedLines("        # Detect and select device")
        buff.writeIndentedLines("        devices = globals()['aurora'].list_devices()")
        buff.writeIndentedLines("        print_json(data=devices.model_dump_json())")
        buff.writeIndentedLines("        if not devices:")
        buff.writeIndentedLines("            raise SystemExit('[Aurora] No Aurora devices detected')")
        # buff.writeIndentedLines("        device_name = devices[0].name")
        # buff.writeIndentedLines("        print(f'[Aurora] Selecting device: {device_name}')")
        # buff.writeIndentedLines("        globals()['aurora'].select_device(device_name)")

        buff.writeIndentedLines("        # Build a list of device names for the chooser")
        buff.writeIndentedLines("        device_names = [d.name for d in devices]")
        buff.writeIndentedLines("        print('[Aurora] Available devices: ' + ', '.join(device_names))")

        buff.writeIndentedLines("        # Prompt user to choose a device (dropdown)")
        buff.writeIndentedLines("        from psychopy import gui")
        buff.writeIndentedLines("        dlg = gui.Dlg(title='Select Aurora device')")
        buff.writeIndentedLines("        dlg.addField('Device:', choices=device_names)")
        buff.writeIndentedLines("        ok_data = dlg.show()")

        buff.writeIndentedLines("        if dlg.OK is False or ok_data is None:")
        buff.writeIndentedLines("            raise SystemExit('[Aurora] Device selection cancelled by user')")

        buff.writeIndentedLines("        device_name = ok_data[0]")
        buff.writeIndentedLines("        print(f'[Aurora] Selecting device: {device_name}')")
        buff.writeIndentedLines("        globals()['aurora'].select_device(device_name)")
        buff.writeIndentedLines("")
        buff.writeIndentedLines("        # Get and print device status")
        buff.writeIndentedLines("        print('[Aurora] Device status:')")
        buff.writeIndentedLines("        print_json(data=globals()['aurora'].device_status().model_dump_json())")
        buff.writeIndentedLines("")
        buff.writeIndentedLines("        # List and select configuration")
        # buff.writeIndentedLines("        configurations = globals()['aurora'].list_configurations()")
        # buff.writeIndentedLines("        print_json(data=configurations.model_dump_json())")
        # buff.writeIndentedLines("        config = None")
        # buff.writeIndentedLines("        for c in configurations:")
        # buff.writeIndentedLines("            info = globals()['aurora'].configuration_info(c.name)")
        # buff.writeIndentedLines("            if info.number_devices == 1:")
        # buff.writeIndentedLines("                config = c")
        # buff.writeIndentedLines("                break")
        # buff.writeIndentedLines("            core.wait(0.05); event.clearEvents()")
        # buff.writeIndentedLines("        if config is None:")
        # buff.writeIndentedLines("            raise SystemExit('[Aurora] No suitable configuration found')")
        # buff.writeIndentedLines("        print(f'[Aurora] Selecting configuration: {config.name}')")
        # buff.writeIndentedLines("        globals()['aurora'].select_configuration(config.name)")
        buff.writeIndentedLines("        configurations = globals()['aurora'].list_configurations()")
        buff.writeIndentedLines("        print_json(data=configurations.model_dump_json())")
        buff.writeIndentedLines("        if not configurations:")
        buff.writeIndentedLines("            raise SystemExit('[Aurora] No Aurora configurations found')")

        buff.writeIndentedLines("        # Build list of configuration names")
        buff.writeIndentedLines("        config_names = [c.name for c in configurations]")
        buff.writeIndentedLines("        print('[Aurora] Available configurations: ' + ', '.join(config_names))")

        buff.writeIndentedLines("        # Prompt user to choose a configuration")
        buff.writeIndentedLines("        from psychopy import gui")
        buff.writeIndentedLines("        dlg = gui.Dlg(title='Select Aurora configuration')")
        buff.writeIndentedLines("        dlg.addField('Configuration:', choices=config_names)")
        buff.writeIndentedLines("        ok_data = dlg.show()")

        buff.writeIndentedLines("        if dlg.OK is False or ok_data is None:")
        buff.writeIndentedLines("            raise SystemExit('[Aurora] Configuration selection cancelled by user')")

        buff.writeIndentedLines("        config_name = ok_data[0]")
        buff.writeIndentedLines("        print(f'[Aurora] Selecting configuration: {config_name}')")
        buff.writeIndentedLines("        globals()['aurora'].select_configuration(config_name)")
        buff.writeIndentedLines("        globals()['aurora_selected_config_name'] = config_name")

        buff.writeIndentedLines("")
        buff.writeIndentedLines("        # Run signal optimization synchronously")
        # buff.writeIndentedLines("        print('[Aurora] Starting signal optimization...')")
        # buff.writeIndentedLines("        globals()['aurora'].start_signal_optimization()")
        # buff.writeIndentedLines("        while True:")
        # buff.writeIndentedLines("            status = globals()['aurora'].signal_optimization_status()")
        # buff.writeIndentedLines("            if status.signal_optimization_status == 'COMPLETED':")
        # buff.writeIndentedLines("                break")
        # buff.writeIndentedLines("            if status.progress is not None:")
        # buff.writeIndentedLines("                print(f'[Aurora] Optimization progress: {status.progress:.2f}')")
        # buff.writeIndentedLines("            core.wait(1.0); event.clearEvents()")
        # buff.writeIndentedLines("        print('[Aurora] Signal optimization completed!')")
        buff.writeIndentedLines("        from psychopy import gui")
        buff.writeIndentedLines("        while True:")
        buff.writeIndentedLines("            print('[Aurora] Starting signal optimization...')")
        buff.writeIndentedLines("            globals()['aurora'].start_signal_optimization()")
        buff.writeIndentedLines("            while True:")
        buff.writeIndentedLines("                status = globals()['aurora'].signal_optimization_status()")
        buff.writeIndentedLines("                if status.signal_optimization_status == 'COMPLETED':")
        buff.writeIndentedLines("                    break")
        buff.writeIndentedLines("                if getattr(status, 'progress', None) is not None:")
        buff.writeIndentedLines("                    print(f'[Aurora] Optimization progress: {status.progress:.2f}')")
        buff.writeIndentedLines("                core.wait(1.0); event.clearEvents()")
        buff.writeIndentedLines("            print('[Aurora] Signal optimization completed!')")

        buff.writeIndentedLines("")
        buff.writeIndentedLines("            # Ask user whether signal quality is acceptable")
        buff.writeIndentedLines("            choice_dlg = gui.Dlg(title='Aurora Signal Check')")
        buff.writeIndentedLines(
            "            choice_dlg.addText('Signal optimization finished.\\n\\nAre you happy with the signal quality?')")
        buff.writeIndentedLines(
            "            choice_dlg.addField('Decision:', choices=['Signal Quality is Good', 'Signals need more optimization'])")
        buff.writeIndentedLines("            choice = choice_dlg.show()")
        buff.writeIndentedLines("            if choice_dlg.OK is False or choice is None:")
        buff.writeIndentedLines("                raise SystemExit('[Aurora] Signal check cancelled by user')")

        buff.writeIndentedLines("")
        buff.writeIndentedLines("            if choice[0] == 'Signal Quality is Good':")
        buff.writeIndentedLines(
            "                print('[Aurora] User accepted signal quality. Continuing experiment.')")
        buff.writeIndentedLines("                break")

        buff.writeIndentedLines("")
        buff.writeIndentedLines("            # Otherwise: show instructions, wait for OK, then repeat optimization")
        buff.writeIndentedLines("            fix_dlg = gui.Dlg(title='Fix Optodes')")
        buff.writeIndentedLines("            fix_dlg.addText('Please adjust optodes with low signal quality.\\n\\nWhen ready, press OK to re-run optimization.')")
        buff.writeIndentedLines("            fix_dlg.show()")
        buff.writeIndentedLines("            if fix_dlg.OK is False:")
        buff.writeIndentedLines("                raise SystemExit('[Aurora] Optode adjustment cancelled by user')")
        buff.writeIndentedLines("            print('[Aurora] Re-running signal optimization (user requested).')")
        buff.writeIndentedLines("")
        buff.writeIndentedLines("")
        buff.writeIndentedLines(
            f"        globals()['aurora'].set_subject_information(name={subject_expr}, gender='unspecified', age=0)")
        buff.writeIndentedLines(
            "        globals()['aurora'].set_experiment_information(name=expName, remarks='PsychoPy session')")
        buff.writeIndentedLines("        print('[Aurora] Initialization finished.')")
        buff.writeIndentedLines("except Exception as e:")
        buff.writeIndentedLines("    print(f'[AuroraRecorder] Error: {e}')")

    # ------------------------------------------------------------------
    # Unified init + start/stop logic (stable working path)
    # Runs at routine start; guarded to avoid reconnecting twice
    # ------------------------------------------------------------------
    def writeRoutineStartCode(self, buff):
        """Start Aurora recording at the beginning of a routine if flagged."""
        buff.writeIndentedLines("# --- Start Aurora recording if requested ---")
        buff.writeIndentedLines("try:")
        buff.writeIndentedLines("    if 'aurora' not in globals():")
        buff.writeIndentedLines("        print('[Aurora] Recorder not initialized; skipping start.')")
        buff.writeIndentedLines("    else:")
        buff.writeIndentedLines(f"        if bool({self.params['startRecording']}):")
        buff.writeIndentedLines(
            "            globals()['aurora'].start_recording(preview_mode=bool({}))".format(self.params['previewMode']))
        buff.writeIndentedLines("            print('[Aurora] Recording started at routine start.')")
        buff.writeIndentedLines("except Exception as e:")
        buff.writeIndentedLines("    print(f'[Aurora] Error starting recording: {e}')")
        buff.writeIndentedLines("")

    def writeRoutineEndCode(self, buff):
        """Stop Aurora recording at the end of a routine if flagged."""
        buff.writeIndentedLines("# --- Stop Aurora recording if requested ---")
        buff.writeIndentedLines("try:")
        buff.writeIndentedLines("    if 'aurora' not in globals():")
        buff.writeIndentedLines("        print('[Aurora] Recorder not initialized; skipping stop.')")
        buff.writeIndentedLines("    else:")
        buff.writeIndentedLines(f"        if bool({self.params['stopRecording']}):")
        # buff.writeIndentedLines("            status = globals()['aurora'].recording_status()")
        buff.writeIndentedLines("            globals()['aurora'].stop_recording()")
        # buff.writeIndentedLines("            if hasattr(status, 'is_recording') and status.is_recording:")
        # buff.writeIndentedLines("                globals()['aurora'].stop_recording()")
        # buff.writeIndentedLines("                print('[Aurora] Recording stopped at routine end.')")
        # buff.writeIndentedLines("            else:")
        # buff.writeIndentedLines("                print('[Aurora] Stop requested, but no active recording found.')")
        # 👇 add a dedicated handler for SystemExit
        buff.writeIndentedLines("except SystemExit as e:")
        buff.writeIndentedLines("    print(f'[Aurora] SystemExit raised during stop (ignored): {e}')")
        buff.writeIndentedLines("except Exception as e:")
        buff.writeIndentedLines("    print(f'[Aurora] Error stopping recording: {e}')")
        buff.writeIndentedLines("")

    # ------------------------------------------------------------------
    # (No per-frame logic needed when using start/stop flags at routine start)
    # ------------------------------------------------------------------
    def writeFrameCode(self, buff):
        pass

    # ------------------------------------------------------------------
    # Safe cleanup at experiment end (no 400 if already idle) + disconnect
    # ------------------------------------------------------------------
    # def writeExperimentEndCode(self, buff):
    #     """Stop any active recording and disconnect Aurora safely at experiment end."""
    #     buff.writeIndentedLines("# --- Final Aurora cleanup at experiment end ---")
    #     buff.writeIndentedLines("try:")
    #     buff.writeIndentedLines("    if 'aurora' in globals() and globals()['aurora'] is not None:")
    #     buff.writeIndentedLines("        status = aurora.recording_status()")
    #     buff.writeIndentedLines("        if hasattr(status, 'is_recording') and status.is_recording:")
    #     buff.writeIndentedLines("            aurora.stop_recording()")
    #     buff.writeIndentedLines("            print('[Aurora] Recording stopped at experiment end.')")
    #     buff.writeIndentedLines("        else:")
    #     buff.writeIndentedLines("            print('[Aurora] Already idle; no stop needed.')")
    #     buff.writeIndentedLines("")
    #     buff.writeIndentedLines(
    #         "        if 'aurora_connection_ctx' in globals() and aurora_connection_ctx is not None:")
    #     buff.writeIndentedLines("            aurora_connection_ctx.__exit__(None, None, None)")
    #     buff.writeIndentedLines("            print('[Aurora] Disconnected cleanly.')")
    #     buff.writeIndentedLines("    else:")
    #     buff.writeIndentedLines("        print('[Aurora] No Aurora connection found to clean up.')")
    #     buff.writeIndentedLines("except Exception as e:")
    #     buff.writeIndentedLines("    print(f'[Aurora] Error during final cleanup: {e}')")
