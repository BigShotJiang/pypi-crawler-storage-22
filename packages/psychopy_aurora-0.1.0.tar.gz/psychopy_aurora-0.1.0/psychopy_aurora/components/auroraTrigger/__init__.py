"""Aurora Trigger Builder component."""

from __future__ import annotations
from pathlib import Path
from psychopy.experiment.components import BaseComponent, Param


class AuroraTrigger(BaseComponent):
    """Component that sends trigger values to Aurora through an active global connection."""

    categories = ["fNIRS"]
    targets = ["PsychoPy", "PsychoJS"]
    iconFile = Path(__file__).parent / "example.png"
    tooltip = "Send trigger to Aurora via existing connection"
    plugin = "psychopy-aurora"

    def __init__(
        self,
        exp,
        parentName,
        name="AuroraTrigger",
        triggerId=1,  # allow literals OR variable names
        when: str = "begin",
    ) -> None:
        super().__init__(exp, parentName, name)
        _allow3 = ['constant', 'set every repeat', 'set every frame']

        self.type = "AuroraTrigger"

        # Appearance order in PsychoPy Builder
        self.order = ["name", "triggerId", "when"]

        # --- Parameters ---
        # IMPORTANT: valType="code" so user can type a variable name from the conditions file
        self.params["triggerId"] = Param(
            triggerId,
            valType="code",
            updates="constant",
            allowedUpdates=_allow3[:],
            hint=(
                "Trigger value to send to Aurora. "
                "Either a fixed integer (e.g. 1) or the name of a column in your "
                "conditions file (e.g. trigger) whose value will change each trial."
            ),
            label="Trigger ID",
        )

        self.params["when"] = Param(
            when,
            valType="list",
            updates="constant",
            inputType="choice",
            allowedVals=["begin", "end"],
            hint="When the trigger should be emitted relative to the routine lifecycle.",
            label="When",
        )

    # --------------------------------------------------------------------
    # PsychoPy code generation hooks
    # --------------------------------------------------------------------
    def writeInitCode(self, buff) -> None:
        """Create a placeholder object for PsychoPy runtime tracking (avoids NoneType errors)."""
        name = self.params["name"].val
        buff.writeIndentedLines(f"# --- Initialize {name} (AuroraTrigger component) ---")
        buff.writeIndentedLines(f"{name} = type('AuroraTriggerComponent', (), {{}})()")
        buff.writeIndentedLines(f"{name}.status = NOT_STARTED")
        buff.writeIndentedLines(f"{name}.tStart = None")
        buff.writeIndentedLines(f"{name}.tStop = None")
        buff.writeIndentedLines(f"{name}.tStartRefresh = None")
        buff.writeIndentedLines(f"{name}.tStopRefresh = None")
        buff.writeIndentedLines("")

        # NEW: define a no-op setter to satisfy Builder calls like AuroraTrigger_4.setTriggerId(...)
        buff.writeIndentedLines(f"def _{name}_setTriggerId(value):")
        buff.writeIndentedLines("    # AuroraTrigger uses the expression directly; setter kept for compatibility")
        buff.writeIndentedLines("    pass")
        buff.writeIndentedLines(f"{name}.setTriggerId = _{name}_setTriggerId")
        buff.writeIndentedLines("")

    def writeFrameCode(self, buff):
        """
        All timing handled here:
          - when == 'begin'     -> one trigger at tStart
          - when == 'end'       -> one trigger at tStop
        """
        name = self.params["name"].val
        trigger_expr = self.params["triggerId"].val  # expression or variable name
        when = self.params["when"].val  # 'begin' | 'end'

        # ---------- fire once at tStart ----------
        indented = self.writeStartTestCode(buff)
        if indented:
            if when == "begin":
                buff.writeIndentedLines("# send trigger once at tStart")
                buff.writeIndentedLines("try:")
                buff.writeIndentedLines("    if 'aurora' in globals() and globals()['aurora'] is not None:")
                buff.writeIndentedLines(
                    f"        _aurora_trigger_value = int({trigger_expr})"
                )
                buff.writeIndentedLines(
                    "        globals()['aurora'].trigger(_aurora_trigger_value)"
                )
                buff.writeIndentedLines(
                    f"        print('[AuroraTrigger] {name}: sent trigger', "
                    f"_aurora_trigger_value, 'at tStart.')"
                )
                buff.writeIndentedLines("except SystemExit as e:")
                buff.writeIndentedLines(
                    "    print(f'[AuroraTrigger] SystemExit while sending trigger at start (ignored): {e}')"
                )
                buff.writeIndentedLines("except Exception as e:")
                buff.writeIndentedLines(
                    "    print(f'[AuroraTrigger] Error sending trigger at start: {e}')"
                )
            buff.setIndentLevel(-indented, relative=True)

        # ---------- fire once at tStop ----------
        indented = self.writeStopTestCode(buff)
        if indented:
            if when == "end":
                buff.writeIndentedLines("# send trigger once at tStop")
                buff.writeIndentedLines("try:")
                buff.writeIndentedLines("    if 'aurora' in globals() and globals()['aurora'] is not None:")
                buff.writeIndentedLines(
                    f"        _aurora_trigger_value = int({trigger_expr})"
                )
                buff.writeIndentedLines(
                    "        globals()['aurora'].trigger(_aurora_trigger_value)"
                )
                buff.writeIndentedLines(
                    f"        print('[AuroraTrigger] {name}: sent trigger', "
                    f"_aurora_trigger_value, 'at tStop.')"
                )
                buff.writeIndentedLines("except SystemExit as e:")
                buff.writeIndentedLines(
                    "    print(f'[AuroraTrigger] SystemExit while sending trigger at end (ignored): {e}')"
                )
                buff.writeIndentedLines("except Exception as e:")
                buff.writeIndentedLines(
                    "    print(f'[AuroraTrigger] Error sending trigger at end: {e}')"
                )
            buff.setIndentLevel(-indented, relative=True)
