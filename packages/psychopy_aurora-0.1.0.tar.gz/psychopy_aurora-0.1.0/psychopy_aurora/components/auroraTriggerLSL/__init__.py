"""Aurora Trigger LSL Builder component."""

from __future__ import annotations
from pathlib import Path
from psychopy.experiment.components import BaseComponent, Param


class AuroraTriggerLSL(BaseComponent):
    """Component that sends LSL trigger values to Aurora using its configured trigger stream."""

    categories = ["fNIRS"]
    targets = ["PsychoPy", "PsychoJS"]
    iconFile = Path(__file__).parent / "example.png"
    tooltip = "Send trigger to Aurora via LSL"
    plugin = "psychopy-aurora"

    def __init__(
        self,
        exp,
        parentName,
        name="AuroraTriggerLSL",
        triggerId=1,  # allow literals OR variable names
        when: str = "begin",
    ) -> None:

        super().__init__(exp, parentName, name)
        _allow3 = ['constant', 'set every repeat', 'set every frame']  # list

        self.type = "AuroraTriggerLSL"

        self.order = ["name", "triggerId", "when"]

        # CHANGED: valType="code" and hint updated
        self.params["triggerId"] = Param(
            triggerId,
            valType="code",  # allow raw code / variable names (e.g. trigger)
            updates="constant",
            allowedUpdates=_allow3[:],
            hint=(
                "Trigger value to send to Aurora via LSL. "
                "Either a fixed integer (e.g. 1) or the name of a column in your "
                "conditions file (e.g. trigger) whose value will change each trial."
            ),
            label="Trigger ID",
        )

        self.params["when"] = Param(
            when,
            valType="list",          # small tweak: keep consistent with other component
            inputType="choice",
            updates="constant",
            allowedVals=["begin", "end"],
            hint="When the trigger is emitted.",
            label="When",
        )

    # -------------------------------------------------------
    # INIT BLOCK
    # -------------------------------------------------------
    def writeInitCode(self, buff):
        name = self.params["name"].val

        buff.writeIndentedLines(f"# --- Initialize {name} (AuroraTriggerLSL) ---")
        buff.writeIndentedLines("try:")
        buff.writeIndentedLines("    from pylsl import StreamInfo, StreamOutlet")
        buff.writeIndentedLines("    from psychopy import core, event")
        buff.writeIndentedLines("    if 'aurora' in globals() and globals()['aurora'] is not None:")

        # Use the previously selected configuration (set by AuroraRecorder)
        buff.writeIndentedLines(
            "        if 'aurora_selected_config_name' not in globals() or globals()['aurora_selected_config_name'] is None:")
        buff.writeIndentedLines(
            "            raise SystemExit('[AuroraTriggerLSL] No previously selected Aurora configuration found. Select one in AuroraRecorder first.')")

        buff.writeIndentedLines("        config_name = globals()['aurora_selected_config_name']")
        buff.writeIndentedLines(
            "        print(f'[AuroraTriggerLSL] Using previously selected configuration: {config_name}')")

        # Optional: ensure Aurora is set to that configuration (safe re-select)
        buff.writeIndentedLines("        try:")
        buff.writeIndentedLines("            globals()['aurora'].select_configuration(config_name)")
        buff.writeIndentedLines("        except Exception as e:")
        buff.writeIndentedLines(
            "            print(f'[AuroraTriggerLSL] Warning: could not re-select configuration ({config_name}): {e}')")

        buff.writeIndentedLines("        cfg = globals()['aurora'].configuration_info(config_name)")
        buff.writeIndentedLines("        stream_name = cfg.trigger_in_stream_name")
        buff.writeIndentedLines("        print(f'[AuroraTriggerLSL] Using LSL stream name: {stream_name}')")
        buff.writeIndentedLines(
            "        info = StreamInfo(name=stream_name, type='Markers', channel_count=1, nominal_srate=0, channel_format='int32', source_id='aurora_trigger_outlet')"
        )
        buff.writeIndentedLines("        globals()['lsl_trigger_outlet'] = StreamOutlet(info)")
        buff.writeIndentedLines("    else:")
        buff.writeIndentedLines("        print('[AuroraTriggerLSL] WARNING: No active aurora connection found.')")
        buff.writeIndentedLines("except Exception as e:")
        buff.writeIndentedLines("    print(f'[AuroraTriggerLSL] Failed to initialize LSL outlet: {e}')")

        # Minimal stub object so Builder doesn't crash
        buff.writeIndentedLines(f"{name} = type('AuroraTriggerLSLObject', (), {{}})()")
        buff.writeIndentedLines(f"{name}.status = NOT_STARTED")
        buff.writeIndentedLines(f"{name}.tStart = None")
        buff.writeIndentedLines(f"{name}.tStop = None")
        buff.writeIndentedLines(f"{name}.tStartRefresh = None")
        buff.writeIndentedLines(f"{name}.tStopRefresh = None")
        buff.writeIndentedLines("")

        # Stub setter to satisfy Builder calls (e.g. set every repeat)
        buff.writeIndentedLines(f"def _{name}_setTriggerId(value):")
        buff.writeIndentedLines("    # AuroraTriggerLSL uses the expression directly; setter kept for compatibility")
        buff.writeIndentedLines("    pass")
        buff.writeIndentedLines(f"{name}.setTriggerId = _{name}_setTriggerId")
        buff.writeIndentedLines("")

    # -------------------------------------------------------
    # FRAME BLOCK
    # -------------------------------------------------------
    def writeFrameCode(self, buff):
        name = self.params["name"].val
        trigger_expr = self.params["triggerId"].val  # expression or variable name
        when = self.params["when"].val

        # BEGIN trigger
        indented = self.writeStartTestCode(buff)
        if indented:
            if when == "begin":
                buff.writeIndentedLines("try:")
                buff.writeIndentedLines("    if 'lsl_trigger_outlet' in globals():")
                # Evaluate expression per trial and cast to int
                buff.writeIndentedLines(
                    f"        _aurora_lsl_trigger_value = int({trigger_expr})"
                )
                buff.writeIndentedLines(
                    "        globals()['lsl_trigger_outlet'].push_sample([_aurora_lsl_trigger_value])"
                )
                buff.writeIndentedLines(
                    f"        print('[AuroraTriggerLSL] Sent trigger', "
                    f"_aurora_lsl_trigger_value, 'at tStart.')"
                )
                buff.writeIndentedLines("except Exception as e:")
                buff.writeIndentedLines("    print(f'[AuroraTriggerLSL] Error sending trigger at start: {e}')")
            buff.setIndentLevel(-indented, relative=True)

        # END trigger
        indented = self.writeStopTestCode(buff)
        if indented:
            if when == "end":
                buff.writeIndentedLines("try:")
                buff.writeIndentedLines("    if 'lsl_trigger_outlet' in globals():")
                buff.writeIndentedLines(
                    f"        _aurora_lsl_trigger_value = int({trigger_expr})"
                )
                buff.writeIndentedLines(
                    "        globals()['lsl_trigger_outlet'].push_sample([_aurora_lsl_trigger_value])"
                )
                buff.writeIndentedLines(
                    f"        print('[AuroraTriggerLSL] Sent trigger', "
                    f"_aurora_lsl_trigger_value, 'at tStop.')"
                )
                buff.writeIndentedLines("except Exception as e:")
                buff.writeIndentedLines("    print(f'[AuroraTriggerLSL] Error sending trigger at end: {e}')")
            buff.setIndentLevel(-indented, relative=True)
