from pathlib import Path

PATH = Path(__file__).parents[0]
