# V1RoleRef


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**api_group** | **str** | APIGroup is the group for the resource being referenced | [optional] 
**kind** | **str** | Kind is the type of resource being referenced | [optional] 
**name** | **str** | Name is the name of resource being referenced | [optional] 

## Example

```python
from openapi_client.models.v1_role_ref import V1RoleRef

# TODO update the JSON string below
json = "{}"
# create an instance of V1RoleRef from a JSON string
v1_role_ref_instance = V1RoleRef.from_json(json)
# print the JSON string representation of the object
print(V1RoleRef.to_json())

# convert the object into a dict
v1_role_ref_dict = v1_role_ref_instance.to_dict()
# create an instance of V1RoleRef from a dict
v1_role_ref_from_dict = V1RoleRef.from_dict(v1_role_ref_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


