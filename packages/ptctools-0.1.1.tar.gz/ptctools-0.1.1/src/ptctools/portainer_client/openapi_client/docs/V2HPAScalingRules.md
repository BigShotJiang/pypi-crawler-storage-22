# V2HPAScalingRules


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**policies** | [**List[V2HPAScalingPolicy]**](V2HPAScalingPolicy.md) | policies is a list of potential scaling polices which can be used during scaling. If not set, use the default values: - For scale up: allow doubling the number of pods, or an absolute change of 4 pods in a 15s window. - For scale down: allow all pods to be removed in a 15s window. +listType&#x3D;atomic +optional | [optional] 
**select_policy** | [**V2ScalingPolicySelect**](V2ScalingPolicySelect.md) | selectPolicy is used to specify which policy should be used. If not set, the default value Max is used. +optional | [optional] 
**stabilization_window_seconds** | **int** | stabilizationWindowSeconds is the number of seconds for which past recommendations should be considered while scaling up or scaling down. StabilizationWindowSeconds must be greater than or equal to zero and less than or equal to 3600 (one hour). If not set, use the default values: - For scale up: 0 (i.e. no stabilization is done). - For scale down: 300 (i.e. the stabilization window is 300 seconds long). +optional | [optional] 
**tolerance** | [**ResourceQuantity**](ResourceQuantity.md) | tolerance is the tolerance on the ratio between the current and desired metric value under which no updates are made to the desired number of replicas (e.g. 0.01 for 1%). Must be greater than or equal to zero. If not set, the default cluster-wide tolerance is applied (by default 10%).  For example, if autoscaling is configured with a memory consumption target of 100Mi, and scale-down and scale-up tolerances of 5% and 1% respectively, scaling will be triggered when the actual consumption falls below 95Mi or exceeds 101Mi.  This is an alpha field and requires enabling the HPAConfigurableTolerance feature gate.  +featureGate&#x3D;HPAConfigurableTolerance +optional | [optional] 

## Example

```python
from openapi_client.models.v2_hpa_scaling_rules import V2HPAScalingRules

# TODO update the JSON string below
json = "{}"
# create an instance of V2HPAScalingRules from a JSON string
v2_hpa_scaling_rules_instance = V2HPAScalingRules.from_json(json)
# print the JSON string representation of the object
print(V2HPAScalingRules.to_json())

# convert the object into a dict
v2_hpa_scaling_rules_dict = v2_hpa_scaling_rules_instance.to_dict()
# create an instance of V2HPAScalingRules from a dict
v2_hpa_scaling_rules_from_dict = V2HPAScalingRules.from_dict(v2_hpa_scaling_rules_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


