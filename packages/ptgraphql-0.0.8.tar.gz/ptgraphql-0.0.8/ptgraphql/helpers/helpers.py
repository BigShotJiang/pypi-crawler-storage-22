"""
Helpers module for shared functionality used across test modules.
"""
from http.client import HTTPResponse

from ptlibs import ptprint
from urllib.parse import urlencode
import json


class Helpers:
    def __init__(self, args: object, ptjsonlib: object, http_client: object):
        """Helpers provides utility methods"""
        self.args = args
        self.ptjsonlib = ptjsonlib
        self.http_client = http_client
        self.cycle_detector = self.CycleDetector(self.args)

    def print_header(self, test_label):
        ptprint(f"Testing: {test_label}", "TITLE", not self.args.json, colortext=True)

    def send_request(self, supported_methods: set, payload: object) -> HTTPResponse:
        response = None

        if "POST" in supported_methods:
            response = self.http_client.send_request(url=self.args.url, method="POST", data=json.dumps(payload), allow_redirects=True)
            return response
        elif "GET" in supported_methods:
            headers = self.args.headers.copy()
            if "content-type" in headers.keys():
                headers.pop("content-type")
            elif "Content-Type" in headers.keys():
                headers.pop("Content-Type")

            url = self.args.url + '?' + urlencode(payload)
            response = self.http_client.send_request(url=url, method="GET", allow_redirects=True, headers=headers, merge_headers=False)

        return response

    class CycleDetector:
        def __init__(self, args: object):
            self.args = args

        def _get_base_type_name(self, type_ref):
            """
            Recursively unwraps NON_NULL and LIST wrappers to find
            the actual named type (e.g., turns '[User!]!' into 'User').
            """
            if type_ref.get('kind') in ['NON_NULL', 'LIST']:
                return self._get_base_type_name(type_ref['ofType'])
            return type_ref.get('name')

        def _build_dependency_graph(self, schema_data):
            """
            Parses introspection data to build a directed graph (adjacency list).
            Returns: dict { 'TypeName': set(['Dependency1', 'Dependency2']) }
            """
            types = schema_data['data']['__schema']['types']
            graph = {}

            ignored_types = {'String', 'Int', 'Float', 'Boolean', 'ID'}

            for t in types:
                name = t['name']

                if name.startswith('__') or name in ignored_types:
                    continue

                if t['kind'] not in ['OBJECT', 'INTERFACE', 'INPUT_OBJECT']:
                    continue

                if name not in graph:
                    graph[name] = set()

                if t.get('fields'):
                    for field in t['fields']:
                        target_type = self._get_base_type_name(field['type'])

                        if target_type and target_type not in ignored_types:
                            graph[name].add(target_type)

                if t.get('inputFields'):
                    for field in t['inputFields']:
                        target_type = self._get_base_type_name(field['type'])
                        if target_type and target_type not in ignored_types:
                            graph[name].add(target_type)

            return graph

        def _find_cycles(self, graph):
            """
            Uses DFS to detect cycles in the graph.
            Returns a list of cycles, where each cycle is a list of type names.
            """
            visited = set()
            cycles = []

            def dfs(node, path):
                visited.add(node)
                path.append(node)

                if node in graph:
                    for neighbor in graph[node]:
                        if neighbor not in visited:
                            dfs(neighbor, path)
                        elif neighbor in path:
                            cycle_start_index = path.index(neighbor)
                            cycle_path = path[cycle_start_index:] + [neighbor]
                            cycles.append(cycle_path)

                path.pop()

            for node in graph:
                if node not in visited:
                    dfs(node, [])

            return cycles

        def run_detection(self) -> bool:
            introspection_data = self.args.schema

            if not introspection_data:
                ptprint("No schema available to detect cyclic relationships", "OK", not self.args.json, indent=4)
                return False

            dependency_graph = self._build_dependency_graph(introspection_data)
            found_cycles = self._find_cycles(dependency_graph)

            if found_cycles:
                ptprint(f"Found {len(found_cycles)} circular relationships", "VULN", not self.args.json, indent=4)
                for i, cycle in enumerate(found_cycles, 1):
                    ptprint(f"{i}. {' -> '.join(cycle)}", "VULN", not self.args.json, indent=8)
                return True
            else:
                ptprint("No circular relationships found.", "OK", not self.args.json, indent=4)
                return False
