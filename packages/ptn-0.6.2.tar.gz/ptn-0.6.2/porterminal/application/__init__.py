"""Application layer - use cases and orchestration."""
