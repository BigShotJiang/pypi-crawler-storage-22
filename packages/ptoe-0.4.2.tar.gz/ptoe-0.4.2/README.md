# ptoe (matPlotlib To ECharts)

**ptoe** is an experimental library that converts charts created with ``matplotlib``
👉 into **interactive HTML outputs powered by ECharts.**

 Core Philosophy  
> **“Keep matplotlib syntax as-is, only change the output to ECharts.”**

## Supported Chart Types (v0.4.2)

### Bar Chart
- Single bar
- Multiple series bar
- Stacked bar (`bottom=`)

```python
plt.bar(x, y1)
plt.bar(x, y2, bottom=y1)
ptoe.show()
```

*Automatically detects legend and stack
*Supports category x-axis

### Line Chart

- Standard line
- step line (plt.step, steps-pre/mid/post)

```python
plt.plot(x, y)
plt.step(x, y, where="post")
ptoe.show()
```

*Automatically detects numeric / category x-axis
*Converts step lines to ECharts step option

### Scatter Plot

```python
plt.scatter(x, y)
ptoe.show()
```

*matplotlib scatter → ECharts scatter

### Area Chart

```python
plt.fill_between

plt.fill_between(x, y)
ptoe.show()
```

*Detected via PolyCollection
*Converted to ECharts line + areaStyle

### Histogram

Directly computed using numpy.histogram()

```python
ptoe.show(
    data=data,
    chart_type="hist",
    bins=30,
    density=False,
    cumulative=False,
    hist_range=[-3, 3],
    color="green",
    alpha=0.4,
    edgecolor="black",
)
```

### Boxplot

Directly computed using original data

```python
ptoe.show(
    data=data,
    chart_type="boxplot",
)
```
*Does NOT reuse matplotlib results
*Quartiles and whiskers calculated manually
*Can be used without matplotlib
### Heatmap

```python
ptoe.show(
    data=data,
    chart_type="heatmap",
)
```
*Uses 2D array directly
*Automatically calculates min / max
*Automatically generates `visualMap`
*Can be used without matplotlib


## Common Style Options
- color
- alpha
- edgecolor
- linewidth


## Execution Modes

### Convert matplotlib result
```python
plt.plot(x, y)
ptoe.show()
```

### Requires original data
```python
ptoe.show(
    data=data,
    chart_type="hist",
)
```
*Recommended for hist / boxplot / heatmap


## Running Methods

### Jupyter / Colab
```python
ptoe.show(inline=True)
```

### Local (HTML)
```python
ptoe.show()
```

## Design Overview

- Analyze matplotlib objects (wrap mode)
- Automatic `chart_type` detection
- Statistical charts computed from raw data
- Generate ECharts options
- Render HTML

## Version History
v0.4.2

- Transitioned to chart_type-based structure
- Introduced raw data computation for hist, boxplot, heatmap
- Partial style option support

## One-Line Summary

ptoe is a tool for matplotlib users that delivers **Same syntax, upgraded output.**
