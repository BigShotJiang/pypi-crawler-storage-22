# 商讯 / 舆情 IDL
IDL仓库用于管理 【商讯 / 舆情】 项目的数据模型、枚举、常量等

### 如何发布新的IDL版本？
请仔细阅读指引文档
https://kcn67g8bllja.feishu.cn/wiki/XFNswWUbziJ3E0kAw8TcjkVvnte

### GitLab 群组地址
https://git.xmu.edu.cn/innovation

### 项目技术架构文档
https://kcn67g8bllja.feishu.cn/wiki/Utr8wiXK9igQwfk2H8OcSIJAnNd
