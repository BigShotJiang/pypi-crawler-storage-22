"""
Async Utilities for Efficient API Calls.

Python 3.12+ features used:
- asyncio.TaskGroup for structured concurrency (3.11+)
- Type parameter syntax for generic classes
- Modern async patterns

Provides:
- Parallel API calls with TaskGroup
- Rate limiting with token bucket
- Connection pooling
- Circuit breaker for fault tolerance

Note:
    Retry logic uses tenacity (project dependency).
    See infrastructure/ncbi/strategy.py for examples.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, TypeVar

from typing_extensions import Self

from .exceptions import (
    RateLimitError,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable, Sequence

logger = logging.getLogger(__name__)

T = TypeVar("T")
R = TypeVar("R")


# =============================================================================
# Rate Limiter (Token Bucket Algorithm)
# =============================================================================


@dataclass
class RateLimiter:
    """
    Token bucket rate limiter for API calls.

    NCBI allows:
    - Without API key: 3 requests/second
    - With API key: 10 requests/second

    Example:
        limiter = RateLimiter(rate=10, per=1.0)
        async with limiter:
            await make_api_call()
    """

    rate: float = 3.0  # requests per period
    per: float = 1.0  # period in seconds
    _tokens: float = field(init=False)
    _last_update: float = field(init=False)
    _lock: asyncio.Lock = field(init=False, default_factory=asyncio.Lock)

    def __post_init__(self) -> None:
        self._tokens = self.rate
        self._last_update = time.monotonic()

    async def acquire(self) -> None:
        """Acquire a token, waiting if necessary."""
        async with self._lock:
            now = time.monotonic()
            elapsed = now - self._last_update
            self._tokens = min(self.rate, self._tokens + elapsed * (self.rate / self.per))
            self._last_update = now

            if self._tokens < 1:
                wait_time = (1 - self._tokens) * (self.per / self.rate)
                logger.debug(f"Rate limit: waiting {wait_time:.2f}s")
                await asyncio.sleep(wait_time)
                self._tokens = 0
            else:
                self._tokens -= 1

    async def __aenter__(self) -> Self:
        await self.acquire()
        return self

    async def __aexit__(self, *args: object) -> None:
        pass


# Global rate limiters for different APIs
_rate_limiters: dict[str, RateLimiter] = {}


def get_rate_limiter(api_name: str, rate: float = 3.0) -> RateLimiter:
    """Get or create a rate limiter for an API."""
    if api_name not in _rate_limiters:
        _rate_limiters[api_name] = RateLimiter(rate=rate)
    return _rate_limiters[api_name]


# NOTE: Retry logic is provided by tenacity (already a project dependency).
# Use tenacity's @retry decorator for both sync and async retry needs.
# See infrastructure/ncbi/strategy.py for usage examples.


# =============================================================================
# Parallel Execution with TaskGroup (Python 3.11+)
# =============================================================================


async def gather_with_errors(
    *coros: Awaitable[T],
    return_exceptions: bool = False,
) -> list[T | Exception]:
    """
    Execute coroutines in parallel using TaskGroup.

    Python 3.11+ TaskGroup provides structured concurrency:
    - All tasks are properly cancelled on failure
    - Exceptions are properly propagated
    - Resources are cleaned up

    Args:
        *coros: Coroutines to execute
        return_exceptions: If True, return exceptions instead of raising

    Returns:
        List of results (or exceptions if return_exceptions=True)

    Example:
        results = await gather_with_errors(
            fetch_pmid("123"),
            fetch_pmid("456"),
            return_exceptions=True
        )
    """
    results: list[T | Exception] = []

    if return_exceptions:
        # Collect all results, including exceptions
        async def safe_run(coro: Awaitable[T]) -> None:
            try:
                result = await coro
                results.append(result)
            except Exception as e:  # noqa: BLE001
                results.append(e)

        async with asyncio.TaskGroup() as tg:  # type: ignore[attr-defined]
            for coro in coros:
                tg.create_task(safe_run(coro))
    else:
        # Fail fast on any exception
        async with asyncio.TaskGroup() as tg:  # type: ignore[attr-defined]
            tasks = [tg.create_task(coro) for coro in coros]
        results = [task.result() for task in tasks]

    return results


async def batch_process(
    items: Sequence[T],
    processor: Callable[[T], Awaitable[R]],
    batch_size: int = 10,
    rate_limiter: RateLimiter | None = None,
) -> list[R | Exception]:
    """
    Process items in batches with rate limiting.

    Args:
        items: Items to process
        processor: Async function to process each item
        batch_size: Number of items per batch
        rate_limiter: Optional rate limiter

    Returns:
        List of results (exceptions for failed items)

    Example:
        results = await batch_process(
            pmids,
            fetch_article_details,
            batch_size=10,
            rate_limiter=ncbi_limiter
        )
    """
    all_results: list[R | Exception] = []

    for i in range(0, len(items), batch_size):
        batch = items[i : i + batch_size]

        async def process_with_limit(item: T) -> R:
            if rate_limiter:
                await rate_limiter.acquire()
            return await processor(item)

        batch_results = await gather_with_errors(*[process_with_limit(item) for item in batch], return_exceptions=True)
        all_results.extend(batch_results)

        # Small delay between batches
        if i + batch_size < len(items):
            await asyncio.sleep(0.1)

    return all_results


# =============================================================================
# Circuit Breaker Pattern
# =============================================================================


@dataclass
class CircuitBreaker:
    """
    Circuit breaker for fault tolerance.

    Protects against cascading failures when external APIs are down.
    Used by BaseAPIClient to automatically stop calling failing services.

    States:
    - CLOSED: Normal operation, requests pass through
    - OPEN: Service is failing, reject requests immediately
    - HALF_OPEN: Testing if service recovered

    Example:
        breaker = CircuitBreaker(failure_threshold=5)

        async with breaker:
            result = await risky_api_call()
    """

    failure_threshold: int = 5
    recovery_timeout: float = 30.0
    half_open_max_calls: int = 3

    _failure_count: int = field(init=False, default=0)
    _last_failure_time: float | None = field(init=False, default=None)
    _state: str = field(init=False, default="closed")
    _half_open_calls: int = field(init=False, default=0)
    _lock: asyncio.Lock = field(init=False, default_factory=asyncio.Lock)

    @property
    def state(self) -> str:
        """Current circuit breaker state."""
        return self._state

    @property
    def is_open(self) -> bool:
        """Check if circuit is open (rejecting requests)."""
        if self._state != "open":
            return False
        # Check if recovery timeout passed
        return not (self._last_failure_time and time.monotonic() - self._last_failure_time > self.recovery_timeout)

    async def __aenter__(self) -> Self:
        async with self._lock:
            if self.is_open:
                raise RateLimitError("Circuit breaker is open", retry_after=self.recovery_timeout)

            if self._state == "open":
                self._state = "half_open"
                self._half_open_calls = 0

            if self._state == "half_open":
                if self._half_open_calls >= self.half_open_max_calls:
                    raise RateLimitError(
                        "Circuit breaker is half-open (max calls reached)",
                        retry_after=self.recovery_timeout / 2,
                    )
                self._half_open_calls += 1

        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        async with self._lock:
            if exc_val is not None:
                self._failure_count += 1
                self._last_failure_time = time.monotonic()

                if self._failure_count >= self.failure_threshold:
                    self._state = "open"
                    logger.warning(f"Circuit breaker opened after {self._failure_count} failures")
            # Success
            elif self._state == "half_open":
                self._state = "closed"
                self._failure_count = 0
                logger.info("Circuit breaker closed (recovered)")
            elif self._state == "closed":
                self._failure_count = max(0, self._failure_count - 1)


# =============================================================================
# Shared Async HTTP Client
# =============================================================================

_shared_async_client: Any | None = None


def get_shared_async_client() -> Any:
    """
    Get a shared httpx.AsyncClient singleton for general-purpose HTTP requests.

    Replaces per-call ``httpx.AsyncClient(...)`` creation in tools like
    vision_search, openurl, and pdf download.  A single long-lived client
    reuses TCP connections, saving TLS-handshake and DNS-lookup overhead
    on repeated calls.

    The client is configured with:
    - follow_redirects=True (needed by most callers)
    - 30 s default timeout (override per-request with ``timeout=`` kwarg)
    - Connection pool limits matching BaseAPIClient

    Returns:
        A reusable ``httpx.AsyncClient`` instance.

    Example::

        client = get_shared_async_client()
        response = await client.get(url, timeout=10.0)
    """
    global _shared_async_client

    import httpx  # lazy import to avoid circular deps

    if _shared_async_client is None or _shared_async_client.is_closed:
        _shared_async_client = httpx.AsyncClient(
            timeout=30.0,
            follow_redirects=True,
            limits=httpx.Limits(
                max_connections=20,
                max_keepalive_connections=10,
                keepalive_expiry=30.0,
            ),
        )
    return _shared_async_client


async def close_shared_async_client() -> None:
    """Close the shared async HTTP client (call on shutdown)."""
    global _shared_async_client
    if _shared_async_client is not None and not _shared_async_client.is_closed:
        await _shared_async_client.aclose()
        _shared_async_client = None


# =============================================================================
# Utility Functions
# =============================================================================


async def timeout_with_fallback(
    coro: Awaitable[T],
    timeout: float,
    fallback: T | Callable[[], T],
) -> T:
    """
    Execute coroutine with timeout and fallback.

    Args:
        coro: Coroutine to execute
        timeout: Timeout in seconds
        fallback: Value or callable to return on timeout

    Returns:
        Result or fallback value
    """
    try:
        return await asyncio.wait_for(coro, timeout=timeout)
    except asyncio.TimeoutError:
        if callable(fallback):
            return fallback()
        return fallback
