"""Tests for coordination module."""
