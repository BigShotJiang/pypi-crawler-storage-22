import os
from dataclasses import dataclass, field
from pathlib import Path

from google.auth.transport.requests import Request
from google.oauth2 import service_account

# Bundled service account key path (inside the package)
_CREDENTIALS_PATH = Path(__file__).parent.parent / "credentials" / "service-account.json"

# Default Cloud Run URL
_DEFAULT_PROXY_URL = "https://puli-proxy-gpvaoh5hka-uw.a.run.app"


def _load_credentials(target_audience: str) -> service_account.IDTokenCredentials | None:
    """Load GCP credentials from the bundled service account key."""
    sa_path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS", str(_CREDENTIALS_PATH))

    if not Path(sa_path).exists():
        return None

    return service_account.IDTokenCredentials.from_service_account_file(
        sa_path, target_audience=target_audience
    )


@dataclass
class ProxyConfig:
    """Configuration for the proxy client."""

    base_url: str
    api_key: str
    _credentials: service_account.IDTokenCredentials | None = field(
        default=None, repr=False
    )
    _jwt_token: str | None = field(default=None, repr=False)

    @property
    def identity_token(self) -> str | None:
        """Get a valid identity token, refreshing automatically if expired."""
        if self._credentials is None:
            return None

        if not self._credentials.valid:
            self._credentials.refresh(Request())

        return self._credentials.token

    @property
    def jwt_token(self) -> str | None:
        return self._jwt_token

    @jwt_token.setter
    def jwt_token(self, value: str | None) -> None:
        self._jwt_token = value

    @classmethod
    def from_env(cls) -> "ProxyConfig":
        """Load configuration from environment variables."""
        base_url = os.environ.get("PROXY_BASE_URL", _DEFAULT_PROXY_URL)
        if not base_url:
            raise ValueError("PROXY_BASE_URL environment variable is required")

        api_key = os.environ.get("PROXY_API_KEY", "puli-proxy-api-key")
        if not api_key:
            raise ValueError("PROXY_API_KEY environment variable is required")

        credentials = _load_credentials(target_audience=base_url)

        return cls(
            base_url=base_url.rstrip("/"),
            api_key=api_key,
            _credentials=credentials,
        )
