from typing import List, Optional
from openai import OpenAI
from .config import EmbeddingConfig


class EmbeddingClient:
    """Client for generating text embeddings using OpenAI."""

    def __init__(self, config: Optional[EmbeddingConfig] = None):
        """
        Initialize the embedding client.

        Args:
            config: EmbeddingConfig instance. If None, loads from environment variables.
        """
        self.config = config or EmbeddingConfig.from_env()
        self.client = OpenAI(api_key=self.config.api_key)

    def generate_embedding(self, text: str) -> List[float]:
        """
        Generate an embedding for the given text.

        Args:
            text: The text to embed.

        Returns:
            A list of floats representing the embedding vector.
        """
        # Ensure text isn't empty and replace newlines
        clean_text = text.replace("\n", " ")
        return self.client.embeddings.create(
            input=[clean_text],
            model=self.config.model
        ).data[0].embedding
