import os
from dataclasses import dataclass
from typing import Dict, Any

EMBEDDING_ALGORITHM = "text-embedding-3-large"


@dataclass
class EmbeddingConfig:
    """Configuration for Embedding client, loaded from environment variables."""

    api_key: str
    model: str

    @classmethod
    def from_env(cls) -> "EmbeddingConfig":
        """Load configuration from environment variables."""
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OpenAI API key is required. Set OPENAI_API_KEY environment variable.")

        model = os.environ.get("EMBEDDING_ALGORITHM", EMBEDDING_ALGORITHM)

        return cls(
            api_key=api_key,
            model=model,
        )

    @classmethod
    def from_remote(cls, config: Dict[str, Any]) -> "EmbeddingConfig":
        """Load configuration from remote config dict (fetched from proxy).
        
        Args:
            config: Configuration dictionary from proxy /config/mcp endpoint
        
        Returns:
            EmbeddingConfig instance with settings from remote config
        """
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OpenAI API key is required. Set OPENAI_API_KEY environment variable.")

        model = config.get("EMBEDDING_ALGORITHM", EMBEDDING_ALGORITHM)

        return cls(
            api_key=api_key,
            model=model,
        )

