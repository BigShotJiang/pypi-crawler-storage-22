from dataclasses import dataclass, field
from typing import List


@dataclass
class Incident:
    """Represents an incident record in the Zilliz collection."""

    id: str
    vector: List[float]
    company: str
    year: int
    industries: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    trigger_keywords: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "Incident":
        """Create an Incident from a dictionary, handling Milvus/Zilliz types."""
        return cls(
            id=data.get("id"),
            vector=list(data.get("vector", [])),
            company=data.get("company"),
            year=data.get("year"),
            industries=list(data.get("industries", [])),
            tags=list(data.get("tags", [])),
            trigger_keywords=list(data.get("trigger_keywords", [])),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for insertion."""
        return {
            "id": self.id,
            "vector": self.vector,
            "company": self.company,
            "year": self.year,
            "industries": self.industries,
            "tags": self.tags,
            "trigger_keywords": self.trigger_keywords,
        }


@dataclass
class IncidentQueryResult:
    """Represents a lightweight incident record for search/query results."""

    id: str
    company: str
    year: int
    industries: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "IncidentQueryResult":
        """Create a QueryResult from a dictionary, handling Milvus/Zilliz types."""
        return cls(
            id=data.get("id"),
            company=data.get("company"),
            year=data.get("year"),
            industries=list(data.get("industries", [])),
            tags=list(data.get("tags", [])),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "company": self.company,
            "year": self.year,
            "industries": self.industries,
            "tags": self.tags,
        }

    def to_prompt_str(self) -> str:
        """Returns a string representation of the incident query result."""
        return f"Incident: {self.company} ({self.year}) " + '\n' \
            + f"Tags: {', '.join(self.tags)}" + '\n' \
            + f"Industries: {', '.join(self.industries)}" + '\n'
