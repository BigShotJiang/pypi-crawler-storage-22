"""Pulse module transpilation.

Submodules:
- tags: HTML tag functions -> JSX elements
"""
