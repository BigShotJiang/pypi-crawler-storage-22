# Pulso

An extensible microservice platform for plugin-based applications.

> This package is under active development. Stay tuned.

## Links

- [GitHub](https://github.com/JonesHong/pulso)
