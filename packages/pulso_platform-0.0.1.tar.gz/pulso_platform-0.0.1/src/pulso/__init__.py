"""Pulso — An extensible microservice platform for plugin-based applications."""

__version__ = "0.0.1"
