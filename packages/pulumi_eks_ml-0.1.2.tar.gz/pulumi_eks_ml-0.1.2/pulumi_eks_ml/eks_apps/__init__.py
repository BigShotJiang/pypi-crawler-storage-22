"""EKS applications."""
