﻿// my_math.cpp
#include <pybind11/pybind11.h>

namespace py = pybind11;

// 这是一个纯 C++ 函数，性能极高
int add(int i, int j)
{
    return i + j;
}

// 这里是“魔法”部分：告诉 Python 怎么用这个函数
PYBIND11_MODULE(my_math, m)
{
    m.doc() = "这是我的第一个 C++ 扩展模块！"; // 模块说明
    m.def("add", &add, "一个加法函数");        // 把 C++ 的 add 绑定为 Python 的 add
}