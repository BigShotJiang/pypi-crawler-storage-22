from setuptools import setup, Extension
import pybind11

# 这里的参数改成了 Windows 专用的 /std:c++14
cpp_args = ["/std:c++14"]

ext_modules = [
    Extension(
        "my_math",
        ["my_math.cpp"],
        include_dirs=[pybind11.get_include()],
        language="c++",
        extra_compile_args=cpp_args,
    ),
]

setup(
    name="pumengyu_cpp_math_tool_2026",  # 名字保持和你之前的一样
    version="0.0.1",
    author="Pu Mengyu",
    author_email="jinmengyu193777@gmail.com",
    description="A simple math extension using C++ and pybind11",
    ext_modules=ext_modules,
)
