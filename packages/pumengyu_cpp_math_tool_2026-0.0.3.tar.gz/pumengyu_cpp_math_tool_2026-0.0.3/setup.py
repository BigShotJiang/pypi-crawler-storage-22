import sys
from setuptools import setup, Extension
import pybind11

# 🌟 核心修改：自动判断系统
if sys.platform == "win32":
    # Windows 系统（用斜杠）
    print("Detected Windows system, using MSVC flags.")
    cpp_args = ["/std:c++14", "/utf-8"]
else:
    # Linux/Mac 系统（用减号）
    print(f"Detected {sys.platform} system, using GCC/Clang flags.")
    cpp_args = ["-std=c++14"]

ext_modules = [
    Extension(
        "my_math",
        ["my_math.cpp"],
        include_dirs=[pybind11.get_include()],
        language="c++",
        extra_compile_args=cpp_args,  # 这里引用上面判断好的参数
    ),
]

setup(
    name="pumengyu_cpp_math_tool_2026",
    version="0.0.3",  # 👈 记得改成 0.0.3，不然传不上去
    author="Pu Mengyu",
    author_email="your_email@example.com",
    description="A cross-platform math extension using C++ and pybind11",
    ext_modules=ext_modules,
)
