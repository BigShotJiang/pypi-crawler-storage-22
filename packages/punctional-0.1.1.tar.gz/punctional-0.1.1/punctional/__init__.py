"""
Punctional - A functional programming framework for Python.

Provides composable filters and method chaining for native types and custom dataclasses.
"""

from .core import Filter, Functional, Compose
from .types import FunctionalInt, FunctionalFloat, FunctionalStr, fint, ffloat, fstr
from .arithmetic import Add, Mult, Sub, Div
from .logical import AndFilter, OrFilter, NotFilter
from .comparison import GreaterThan, LessThan, Equals
from .string import ToUpper, ToLower, Contains
from .list_filters import Map, FilterList, Reduce
from .monads import Option, Some, Nothing, Result, Ok, Error, some, try_result

__version__ = "0.1.1"

__all__ = [
    # Core
    "Filter",
    "Functional",
    # Types
    "FunctionalInt",
    "FunctionalFloat",
    "FunctionalStr",
    "fint",
    "ffloat",
    "fstr",
    # Arithmetic
    "Add",
    "Mult",
    "Sub",
    "Div",
    # Logical
    "AndFilter",
    "OrFilter",
    "NotFilter",
    # Comparison
    "GreaterThan",
    "LessThan",
    "Equals",
    # String
    "ToUpper",
    "ToLower",
    "Contains",
    # Composition
    "Compose",
    # List
    "Map",
    "FilterList",
    "Reduce",
    # Monads
    "Option",
    "Some",
    "Nothing",
    "Result",
    "Ok",
    "Error",
    "some",
    "try_result",
]
