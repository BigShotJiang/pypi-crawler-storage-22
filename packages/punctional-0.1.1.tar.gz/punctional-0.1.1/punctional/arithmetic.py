"""
Arithmetic operation filters (Add, Mult, Sub, Div).
"""

from typing import Any
from .core import Filter


class Add(Filter[Any, Any]):
    """Addition filter - adds a value."""
    
    def __init__(self, addend: Any):
        self.addend = addend
    
    def apply(self, value: Any) -> Any:
        return value + self.addend


class Mult(Filter[Any, Any]):
    """Multiplication filter - multiplies by a value."""
    
    def __init__(self, multiplier: Any):
        self.multiplier = multiplier
    
    def apply(self, value: Any) -> Any:
        return value * self.multiplier


class Sub(Filter[Any, Any]):
    """Subtraction filter - subtracts a value."""
    
    def __init__(self, subtrahend: Any):
        self.subtrahend = subtrahend
    
    def apply(self, value: Any) -> Any:
        return value - self.subtrahend


class Div(Filter[Any, Any]):
    """Division filter - divides by a value."""
    
    def __init__(self, divisor: Any):
        self.divisor = divisor
    
    def apply(self, value: Any) -> Any:
        return value / self.divisor
