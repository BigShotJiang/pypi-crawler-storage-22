"""
Comparison filters (GreaterThan, LessThan, Equals).
"""

from typing import Any
from .core import Filter


class GreaterThan(Filter[Any, bool]):
    """Check if value is greater than threshold."""
    
    def __init__(self, threshold: Any):
        self.threshold = threshold
    
    def apply(self, value: Any) -> bool:
        return value > self.threshold


class LessThan(Filter[Any, bool]):
    """Check if value is less than threshold."""
    
    def __init__(self, threshold: Any):
        self.threshold = threshold
    
    def apply(self, value: Any) -> bool:
        return value < self.threshold


class Equals(Filter[Any, bool]):
    """Check if value equals another value."""
    
    def __init__(self, target: Any):
        self.target = target
    
    def apply(self, value: Any) -> bool:
        return value == self.target
