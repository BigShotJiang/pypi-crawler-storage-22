"""
Core abstractions for the Punctional functional programming framework.
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any, TypeVar, Generic

T = TypeVar('T')
U = TypeVar('U')


class Filter(ABC, Generic[T, U]):
    """
    Abstract base class for all functional filters.
    A filter transforms input of type T to output of type U.
    """

    @abstractmethod
    def apply(self, value: T) -> U:
        """Apply the filter to a value."""
        pass

    def __call__(self, value: T) -> U:
        """Allow filters to be called as functions."""
        return self.apply(value)

    def __or__(self, other: Filter) -> Compose:
        """Enable pipe operator for filter composition: filter1 | filter2"""
        # Import here to avoid circular dependency at module level
        # Compose is defined below in this same module
        return Compose(self, other)

    def __and__(self, other: Filter) -> 'AndFilter':
        """Enable & operator for logical AND"""
        return AndFilter(self, other)


class AndFilter(Filter[T, bool]):
    """Logical AND filter - applies multiple filters and returns True if all are True."""

    def __init__(self, *filters: Filter):
        self.filters = filters

    def apply(self, value: T) -> bool:
        return all(f.apply(value) for f in self.filters)


class Compose(Filter[T, Any]):
    """Compose multiple filters into a pipeline."""

    def __init__(self, *filters: Filter):
        self.filters = filters

    def apply(self, value: T) -> Any:
        result = value
        for filter in self.filters:
            result = filter.apply(result)
        return result


class Functional:
    """
    Mixin class that adds functional programming capabilities to any class.
    Inherit from this to enable method chaining and filter application.
    """

    def pipe(self, filter: Filter) -> Any:
        """Apply a filter to this object."""
        result = filter.apply(self)
        return self._wrap_result(result)

    def __or__(self, filter: Filter) -> Any:
        """Enable pipe operator: obj | filter"""
        result = filter.apply(self)
        return self._wrap_result(result)

    @staticmethod
    def _wrap_result(result: Any) -> Any:
        """Wrap basic types in functional wrappers for continued chaining."""
        if isinstance(result, Functional):
            return result
        elif isinstance(result, int) and not isinstance(result, bool):
            from .types import FunctionalInt
            return FunctionalInt(result)
        elif isinstance(result, float):
            from .types import FunctionalFloat
            return FunctionalFloat(result)
        elif isinstance(result, str):
            from .types import FunctionalStr
            return FunctionalStr(result)
        return result
