"""
Filters for List operations (Map, FilterList, Reduce).
"""

from typing import Any, List
from functools import reduce
from .core import Filter


class Map(Filter[List, List]):
    """Map a filter over a List."""

    def __init__(self, filter: Filter):
        self.filter = filter

    def apply(self, values: List) -> List:
        return [self.filter.apply(v) for v in values]


class FilterList(Filter[List, List]):
    """Filter a List based on a predicate."""

    def __init__(self, predicate: Filter[Any, bool]):
        self.predicate = predicate

    def apply(self, values: List) -> List:
        return [v for v in values if self.predicate.apply(v)]


class Reduce(Filter[List, Any]):
    """Reduce a List to a single value using a filter."""

    def __init__(self, filter: Filter, initial: Any = None):
        self.filter = filter
        self.initial = initial

    def apply(self, values: List) -> Any:
        if self.initial is not None:
            return reduce(lambda acc, x: self.filter.apply((acc, x)), values, self.initial)
        return reduce(lambda acc, x: self.filter.apply((acc, x)), values)
