"""
Logical operation filters (And, Or, Not).
"""

from typing import TypeVar
from .core import Filter

T = TypeVar('T')


class AndFilter(Filter[T, bool]):
    """Logical AND filter - applies multiple filters and returns True if all are True."""

    def __init__(self, *filters: Filter):
        self.filters = filters

    def apply(self, value: T) -> bool:
        return all(f.apply(value) for f in self.filters)


class OrFilter(Filter[T, bool]):
    """Logical OR filter - applies multiple filters and returns True if any is True."""

    def __init__(self, *filters: Filter):
        self.filters = filters

    def apply(self, value: T) -> bool:
        return any(f.apply(value) for f in self.filters)


class NotFilter(Filter[T, bool]):
    """Logical NOT filter - negates the result of another filter."""

    def __init__(self, filter: Filter[T, bool]):
        self.filter = filter

    def apply(self, value: T) -> bool:
        return not self.filter.apply(value)
