"""
Monad implementations for functional programming patterns.

Provides Option (Some/Nothing) and Result (Ok/Error) monads with standard
monadic operations like map, bind, and flat_map.
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from typing import TypeVar, Generic, Callable, Any, Union, Optional
from dataclasses import dataclass

T = TypeVar('T')
U = TypeVar('U')
E = TypeVar('E')


class Option(ABC, Generic[T]):
    """
    Option monad representing the presence (Some) or absence (Nothing) of a value.
    
    Useful for handling nullable values without explicit None checks.
    """

    @abstractmethod
    def map(self, f: Callable[[T], U]) -> Option[U]:
        """Transform the contained value if present."""
        pass

    @abstractmethod
    def flat_map(self, f: Callable[[T], Option[U]]) -> Option[U]:
        """Chain operations that return Options (also called bind or >>=)."""
        pass

    @abstractmethod
    def bind(self, f: Callable[[T], Option[U]]) -> Option[U]:
        """Alias for flat_map (monadic bind operation)."""
        pass

    @abstractmethod
    def get_or_else(self, default: T) -> T:
        """Get the value or return a default."""
        pass

    @abstractmethod
    def get_or_none(self) -> Optional[T]:
        """Get the value or return None."""
        pass

    @abstractmethod
    def is_some(self) -> bool:
        """Check if this is Some."""
        pass

    @abstractmethod
    def is_nothing(self) -> bool:
        """Check if this is Nothing."""
        pass

    @abstractmethod
    def filter(self, predicate: Callable[[T], bool]) -> Option[T]:
        """Return Nothing if predicate is False, otherwise return self."""
        pass

    @abstractmethod
    def or_else(self, alternative: Option[T]) -> Option[T]:
        """Return self if Some, otherwise return alternative."""
        pass

    def __bool__(self) -> bool:
        """Enable truthiness checks."""
        return self.is_some()


@dataclass(frozen=True)
class Some(Option[T]):
    """Represents the presence of a value."""
    
    value: T

    def map(self, f: Callable[[T], U]) -> Option[U]:
        """Apply function to the contained value."""
        return Some(f(self.value))

    def flat_map(self, f: Callable[[T], Option[U]]) -> Option[U]:
        """Apply function that returns an Option."""
        return f(self.value)

    def bind(self, f: Callable[[T], Option[U]]) -> Option[U]:
        """Monadic bind (alias for flat_map)."""
        return self.flat_map(f)

    def get_or_else(self, default: T) -> T:
        """Return the contained value."""
        return self.value

    def get_or_none(self) -> Optional[T]:
        """Return the contained value."""
        return self.value

    def is_some(self) -> bool:
        """Always True for Some."""
        return True

    def is_nothing(self) -> bool:
        """Always False for Some."""
        return False

    def filter(self, predicate: Callable[[T], bool]) -> Option[T]:
        """Return self if predicate passes, otherwise Nothing."""
        return self if predicate(self.value) else Nothing()

    def or_else(self, alternative: Option[T]) -> Option[T]:
        """Return self since we have a value."""
        return self

    def __repr__(self) -> str:
        return f"Some({self.value!r})"


class NothingType(Option[T]):
    """Represents the absence of a value (singleton pattern)."""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def map(self, f: Callable[[T], U]) -> Option[U]:
        """Nothing remains Nothing."""
        return self

    def flat_map(self, f: Callable[[T], Option[U]]) -> Option[U]:
        """Nothing remains Nothing."""
        return self

    def bind(self, f: Callable[[T], Option[U]]) -> Option[U]:
        """Nothing remains Nothing."""
        return self

    def get_or_else(self, default: T) -> T:
        """Return the default value."""
        return default

    def get_or_none(self) -> Optional[T]:
        """Return None."""
        return None

    def is_some(self) -> bool:
        """Always False for Nothing."""
        return False

    def is_nothing(self) -> bool:
        """Always True for Nothing."""
        return True

    def filter(self, predicate: Callable[[T], bool]) -> Option[T]:
        """Nothing remains Nothing."""
        return self

    def or_else(self, alternative: Option[T]) -> Option[T]:
        """Return the alternative since we have no value."""
        return alternative

    def __repr__(self) -> str:
        return "Nothing"

    def __bool__(self) -> bool:
        """Nothing is falsy."""
        return False


# Singleton instance
Nothing = NothingType


def some(value: Optional[T], allow_none: bool = False) -> Option[T]:
    """
    Create an Option from a potentially None value.
    
    Args:
        value: The value to wrap
        allow_none: If True, wrap None as Some(None). If False, return Nothing for None.
    
    Returns:
        Some(value) if value is not None or allow_none is True
        Nothing if value is None and allow_none is False
    
    Examples:
        >>> some(5)
        Some(5)
        >>> some(None)
        Nothing
        >>> some(None, allow_none=True)
        Some(None)
    """
    if value is None and not allow_none:
        return Nothing()
    return Some(value)


class Result(ABC, Generic[T, E]):
    """
    Result monad representing either a success (Ok) or failure (Error).
    
    Useful for operations that can fail with an error value.
    """

    @abstractmethod
    def map(self, f: Callable[[T], U]) -> Result[U, E]:
        """Transform the success value if present."""
        pass

    @abstractmethod
    def map_error(self, f: Callable[[E], U]) -> Result[T, U]:
        """Transform the error value if present."""
        pass

    @abstractmethod
    def flat_map(self, f: Callable[[T], Result[U, E]]) -> Result[U, E]:
        """Chain operations that return Results."""
        pass

    @abstractmethod
    def bind(self, f: Callable[[T], Result[U, E]]) -> Result[U, E]:
        """Alias for flat_map (monadic bind)."""
        pass

    @abstractmethod
    def get_or_else(self, default: T) -> T:
        """Get the success value or return a default."""
        pass

    @abstractmethod
    def is_ok(self) -> bool:
        """Check if this is Ok."""
        pass

    @abstractmethod
    def is_error(self) -> bool:
        """Check if this is Error."""
        pass

    @abstractmethod
    def to_option(self) -> Option[T]:
        """Convert to Option, discarding error information."""
        pass

    def __bool__(self) -> bool:
        """Enable truthiness checks (Ok is truthy, Error is falsy)."""
        return self.is_ok()


@dataclass(frozen=True)
class Ok(Result[T, E]):
    """Represents a successful result."""
    
    value: T

    def map(self, f: Callable[[T], U]) -> Result[U, E]:
        """Apply function to the success value."""
        return Ok(f(self.value))

    def map_error(self, f: Callable[[E], U]) -> Result[T, U]:
        """Leave Ok unchanged."""
        return self

    def flat_map(self, f: Callable[[T], Result[U, E]]) -> Result[U, E]:
        """Apply function that returns a Result."""
        return f(self.value)

    def bind(self, f: Callable[[T], Result[U, E]]) -> Result[U, E]:
        """Monadic bind (alias for flat_map)."""
        return self.flat_map(f)

    def get_or_else(self, default: T) -> T:
        """Return the success value."""
        return self.value

    def is_ok(self) -> bool:
        """Always True for Ok."""
        return True

    def is_error(self) -> bool:
        """Always False for Ok."""
        return False

    def to_option(self) -> Option[T]:
        """Convert to Some with the value."""
        return Some(self.value)

    def __repr__(self) -> str:
        return f"Ok({self.value!r})"


@dataclass(frozen=True)
class Error(Result[T, E]):
    """Represents a failed result with an error value."""
    
    error: E

    def map(self, f: Callable[[T], U]) -> Result[U, E]:
        """Error remains Error."""
        return self

    def map_error(self, f: Callable[[E], U]) -> Result[T, U]:
        """Apply function to the error value."""
        return Error(f(self.error))

    def flat_map(self, f: Callable[[T], Result[U, E]]) -> Result[U, E]:
        """Error remains Error."""
        return self

    def bind(self, f: Callable[[T], Result[U, E]]) -> Result[U, E]:
        """Error remains Error."""
        return self

    def get_or_else(self, default: T) -> T:
        """Return the default value."""
        return default

    def is_ok(self) -> bool:
        """Always False for Error."""
        return False

    def is_error(self) -> bool:
        """Always True for Error."""
        return True

    def to_option(self) -> Option[T]:
        """Convert to Nothing."""
        return Nothing()

    def __repr__(self) -> str:
        return f"Error({self.error!r})"


# Utility functions for creating Results
def try_result(f: Callable[[], T], error_handler: Optional[Callable[[Exception], E]] = None) -> Result[T, Union[E, Exception]]:
    """
    Execute a function and wrap the result in Ok or Error.
    
    Args:
        f: Function to execute
        error_handler: Optional function to transform exceptions into error values
    
    Returns:
        Ok(result) if successful, Error(exception) or Error(error_handler(exception)) if failed
    """
    try:
        return Ok(f())
    except Exception as e:
        if error_handler:
            return Error(error_handler(e))
        return Error(e)
