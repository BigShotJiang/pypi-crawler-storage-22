"""
String manipulation filters.
"""

from .core import Filter


class ToUpper(Filter[str, str]):
    """Convert string to uppercase."""
    
    def apply(self, value: str) -> str:
        return value.upper()


class ToLower(Filter[str, str]):
    """Convert string to lowercase."""
    
    def apply(self, value: str) -> str:
        return value.lower()


class Contains(Filter[str, bool]):
    """Check if string contains substring."""
    
    def __init__(self, substring: str):
        self.substring = substring
    
    def apply(self, value: str) -> bool:
        return self.substring in value
