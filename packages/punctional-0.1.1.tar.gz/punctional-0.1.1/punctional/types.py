"""
Functional wrapper types for Python native types (int, float, str).
"""

from .core import Functional, Filter


class FunctionalInt(int, Functional):
    """Int with functional programming capabilities."""
    
    def __or__(self, other):
        """Override to support Filter piping, fall back to bitwise OR for ints."""
        if isinstance(other, Filter):
            result = other.apply(self)
            return self._wrap_result(result)
        return int.__or__(self, other)
    
    def __new__(cls, value):
        return int.__new__(cls, value)


class FunctionalFloat(float, Functional):
    """Float with functional programming capabilities."""
    
    def __or__(self, other):
        """Support Filter piping."""
        if isinstance(other, Filter):
            result = other.apply(self)
            return self._wrap_result(result)
        return NotImplemented
    
    def __new__(cls, value):
        return float.__new__(cls, value)


class FunctionalStr(str, Functional):
    """String with functional programming capabilities."""
    
    def __or__(self, other):
        """Support Filter piping."""
        if isinstance(other, Filter):
            result = other.apply(self)
            return self._wrap_result(result)
        return NotImplemented
    
    def __new__(cls, value):
        return str.__new__(cls, value)


# Convenience constructors
def fint(value: int) -> FunctionalInt:
    """Create a functional integer."""
    return FunctionalInt(value)


def ffloat(value: float) -> FunctionalFloat:
    """Create a functional float."""
    return FunctionalFloat(value)


def fstr(value: str) -> FunctionalStr:
    """Create a functional string."""
    return FunctionalStr(value)
