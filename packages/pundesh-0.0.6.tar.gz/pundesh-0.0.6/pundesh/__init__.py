# =================================================
# Google Maps + EB Review Automation
# (from single combined file)
# =================================================

from .pundesh import (
    # ---- Google Maps ----
    scrape_maps,
    scrape_maps_sync,
    GoogleMapsScraper,
    ScraperConfig,
    Business,
    BusinessList,
    ProxyManager,

    # ---- EB Reviews ----
    submit_reviews,
    submit_reviews_sync,
    EBReviewAutomation,
    ReviewConfig,
    ReviewResult,
    ReviewResultList,

    # ---- Setup & utils ----
    setup_colab,
    install_playwright_deps,
    is_colab,
    is_jupyter,
)

# =================================================
# YouTube Scraper
# (simple, Colab-only)
# =================================================

from .youtube_scraper import YouTubeScraper

# =================================================
# Package metadata
# =================================================

__version__ = "1.1.0"
__author__ = "Sidharth"

# =================================================
# Public API
# =================================================

__all__ = [

    # ---- Google Maps ----
    "scrape_maps",
    "scrape_maps_sync",
    "GoogleMapsScraper",
    "ScraperConfig",
    "Business",
    "BusinessList",
    "ProxyManager",

    # ---- EB Reviews ----
    "submit_reviews",
    "submit_reviews_sync",
    "EBReviewAutomation",
    "ReviewConfig",
    "ReviewResult",
    "ReviewResultList",

    # ---- YouTube ----
    "scrape_youtube",
    "YouTubeScraper",
    "Video",
    "Short",

    # ---- Setup & utils ----
    "setup_colab",
    "install_playwright_deps",
    "is_colab",
    "is_jupyter",
]

