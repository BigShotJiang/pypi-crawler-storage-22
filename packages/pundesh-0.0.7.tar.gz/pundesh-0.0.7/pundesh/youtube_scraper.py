import asyncio
import random
import os
import re
from dataclasses import dataclass, asdict
from typing import List, Optional

import pandas as pd
from playwright.async_api import async_playwright

try:
    from playwright_stealth import stealth_async
    STEALTH_AVAILABLE = True
except ImportError:
    STEALTH_AVAILABLE = False


def parse_views_to_number(views_str: str) -> int:
    """
    Convert view string to integer
    Examples:
        '1.2M views' -> 1200000
        '3.4K views' -> 3400
        '500 views' -> 500
        '2K views' -> 2000
    """
    if not views_str:
        return 0
    
    # Remove common words and clean up
    text = views_str.lower().replace('views', '').replace('view', '').replace(',', '').strip()
    
    # Match number with optional K/M/B suffix
    match = re.search(r'([\d.]+)\s*([kmb])?', text, re.IGNORECASE)
    if not match:
        return 0
    
    try:
        number = float(match.group(1))
        suffix = match.group(2)
        
        if suffix:
            suffix = suffix.lower()
            if suffix == 'k':
                number *= 1000
            elif suffix == 'm':
                number *= 1000000
            elif suffix == 'b':
                number *= 1000000000
        
        return int(number)
    except (ValueError, TypeError):
        return 0


@dataclass
class Video:
    rank: int = 0
    title: str = ""
    views: str = ""
    views_numeric: int = 0
    duration: str = ""
    url: str = ""
    video_id: str = ""
    content_type: str = "video"


@dataclass
class Short:
    rank: int = 0
    title: str = ""
    views: str = ""
    views_numeric: int = 0
    url: str = ""
    video_id: str = ""
    content_type: str = "short"


class YouTubeScraper:
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    ]

    def __init__(self):
        self.browser = None
        self.page = None
        self.channel_name = ""

    async def run(
        self,
        link: str,
        filename: Optional[str] = None,
        folder: str = "data",
        scrape_videos: Optional[bool] = None,
        scrape_shorts: Optional[bool] = None,
        max_videos: Optional[int] = None,
        max_shorts: Optional[int] = None
    ) -> pd.DataFrame:
        """
        Main scraping function
        """
        
        # Determine what to scrape
        if scrape_videos is None and scrape_shorts is None:
            scrape_videos = True
            scrape_shorts = True
        else:
            if scrape_videos is None:
                scrape_videos = False
            if scrape_shorts is None:
                scrape_shorts = False
        
        # Clean base URL
        base_url = link.rstrip('/')
        for suffix in ['/videos', '/shorts', '/streams', '/playlists', '/community', '/channels', '/about', '/featured']:
            if base_url.endswith(suffix):
                base_url = base_url[:-len(suffix)]
        
        # Extract channel name
        self.channel_name = base_url.split('/')[-1].replace('@', '')
        
        # Set filename
        if filename is None:
            filename = self.channel_name
        
        all_content = []
        
        async with async_playwright() as p:
            await self._setup_browser(p)
            
            print("=" * 60)
            print(f"🎬 YouTube Channel Scraper")
            print(f"📺 Channel: {self.channel_name}")
            print(f"📁 Output: {folder}/{filename}.csv")
            print(f"🎯 Scraping: {'Videos' if scrape_videos else ''}{' + ' if scrape_videos and scrape_shorts else ''}{'Shorts' if scrape_shorts else ''}")
            print("=" * 60)
            
            # Scrape Videos
            if scrape_videos:
                print(f"\n{'='*60}")
                print("📹 SCRAPING VIDEOS")
                print("=" * 60)
                videos_url = f"{base_url}/videos"
                videos = await self._scrape_videos(videos_url, max_videos)
                all_content.extend(videos)
                
                if scrape_shorts:
                    await self.page.wait_for_timeout(random.randint(2000, 4000))
            
            # Scrape Shorts
            if scrape_shorts:
                print(f"\n{'='*60}")
                print("📱 SCRAPING SHORTS")
                print("=" * 60)
                shorts_url = f"{base_url}/shorts"
                shorts = await self._scrape_shorts(shorts_url, max_shorts)
                all_content.extend(shorts)
            
            await self.browser.close()
        
        # Convert to DataFrame
        if not all_content:
            print("\n⚠️ No content found.")
            return pd.DataFrame()
        
        df = pd.DataFrame([asdict(item) for item in all_content])
        
        # ============================================================
        # SORTING: First by content_type (videos first), then by views
        # ============================================================
        # Create a sort key: videos = 0, shorts = 1 (so videos come first)
        df['_sort_type'] = df['content_type'].map({'video': 0, 'short': 1})
        df = df.sort_values(
            by=['_sort_type', 'views_numeric'],
            ascending=[True, False]  # Videos first, then by views descending
        ).drop(columns=['_sort_type'])
        
        # Re-assign ranks within each content type
        df = df.reset_index(drop=True)
        
        # Re-rank videos
        video_mask = df['content_type'] == 'video'
        df.loc[video_mask, 'rank'] = range(1, video_mask.sum() + 1)
        
        # Re-rank shorts
        short_mask = df['content_type'] == 'short'
        df.loc[short_mask, 'rank'] = range(1, short_mask.sum() + 1)
        
        # Convert rank to int
        df['rank'] = df['rank'].astype(int)
        
        # Print summary
        print(f"\n{'='*60}")
        print("📊 SCRAPING COMPLETE")
        print("=" * 60)
        
        videos_count = len(df[df['content_type'] == 'video'])
        shorts_count = len(df[df['content_type'] == 'short'])
        
        if scrape_videos:
            print(f"   📹 Videos: {videos_count}")
        if scrape_shorts:
            print(f"   📱 Shorts: {shorts_count}")
        print(f"   📦 Total:  {len(df)}")
        
        # Print preview
        print(f"\n{'='*60}")
        print("📋 PREVIEW (sorted by views)")
        print("=" * 60)
        
        # Show relevant columns
        preview_cols = ['rank', 'title', 'views', 'views_numeric', 'content_type']
        if 'duration' in df.columns:
            preview_cols.insert(4, 'duration')
        
        print(df[preview_cols].head(20).to_string())
        
        # Save to CSV
        os.makedirs(folder, exist_ok=True)
        output_path = f"{folder}/{filename}.csv"
        df.to_csv(output_path, index=False)
        print(f"\n💾 Saved: {output_path} ({len(df)} rows)")
        
        return df

    async def _setup_browser(self, playwright):
        """Setup browser with stealth"""
        self.browser = await playwright.chromium.launch(
            headless=True,
            args=[
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-blink-features=AutomationControlled',
            ]
        )
        
        context = await self.browser.new_context(
            viewport={"width": 1920, "height": 1080},
            user_agent=random.choice(self.USER_AGENTS),
            locale="en-US",
        )
        
        await context.set_extra_http_headers({
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
        })
        
        if STEALTH_AVAILABLE:
            await stealth_async(context)
        
        self.page = await context.new_page()
        
        await self.page.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
        """)

    async def _navigate_to_page(self, url: str) -> bool:
        """Navigate to a page"""
        print(f"🔗 URL: {url}")
        print(f"📄 Loading page...")
        
        try:
            await self.page.goto(url, wait_until="networkidle", timeout=60000)
            await self.page.wait_for_timeout(3000)
            
            await self._handle_consent()
            
            return True
            
        except Exception as e:
            print(f"⚠️ Failed to load page: {e}")
            return False

    async def _handle_consent(self):
        """Handle YouTube cookie consent dialog"""
        try:
            consent_selectors = [
                'button[aria-label*="Accept"]',
                'button:has-text("Accept all")',
                'button:has-text("I agree")',
                '[aria-label="Accept the use of cookies and other data for the purposes described"]',
                'tp-yt-paper-button:has-text("Accept all")',
            ]
            
            for selector in consent_selectors:
                try:
                    btn = self.page.locator(selector).first
                    if await btn.count() > 0 and await btn.is_visible(timeout=2000):
                        await btn.click(timeout=3000)
                        await self.page.wait_for_timeout(1500)
                        print("   ✅ Handled consent dialog")
                        break
                except:
                    continue
        except:
            pass

    async def _click_popular_button(self):
        """Click the Popular button to sort by most viewed"""
        print(f"🔘 Looking for 'Popular' button...")
        
        try:
            await self.page.wait_for_timeout(2000)
            
            # Wait for chips to be visible
            await self.page.wait_for_selector(
                'yt-chip-cloud-chip-renderer, #chips, yt-chip-cloud-renderer',
                timeout=5000
            )
            
            # Method 1: Direct click using page.evaluate with better selectors
            popular_clicked = await self.page.evaluate('''() => {
                // Try multiple approaches to find the Popular button
                
                // Approach 1: Look for chip cloud chips
                const chips = document.querySelectorAll('yt-chip-cloud-chip-renderer');
                for (const chip of chips) {
                    const text = chip.textContent.trim().toLowerCase();
                    if (text === 'popular') {
                        const button = chip.querySelector('button, a') || chip;
                        button.click();
                        return true;
                    }
                }
                
                // Approach 2: Look for formatted strings inside chips
                const formattedStrings = document.querySelectorAll('yt-chip-cloud-chip-renderer yt-formatted-string');
                for (const fs of formattedStrings) {
                    if (fs.textContent.trim().toLowerCase() === 'popular') {
                        const chip = fs.closest('yt-chip-cloud-chip-renderer');
                        if (chip) {
                            const button = chip.querySelector('button, a') || chip;
                            button.click();
                            return true;
                        }
                    }
                }
                
                // Approach 3: Look in iron-selector chips
                const ironChips = document.querySelectorAll('#chips yt-formatted-string, iron-selector yt-formatted-string');
                for (const chip of ironChips) {
                    if (chip.textContent.trim().toLowerCase() === 'popular') {
                        chip.click();
                        return true;
                    }
                }
                
                // Approach 4: Any clickable element with "Popular" text
                const allElements = document.querySelectorAll('*');
                for (const el of allElements) {
                    if (el.childNodes.length === 1 && 
                        el.textContent.trim().toLowerCase() === 'popular' &&
                        (el.tagName === 'BUTTON' || el.tagName === 'A' || 
                         el.getAttribute('role') === 'tab' || 
                         el.closest('yt-chip-cloud-chip-renderer'))) {
                        el.click();
                        return true;
                    }
                }
                
                return false;
            }''')
            
            if not popular_clicked:
                # Method 2: Try using Playwright locator
                try:
                    popular_btn = self.page.locator('yt-chip-cloud-chip-renderer').filter(has_text="Popular").first
                    if await popular_btn.count() > 0:
                        await popular_btn.click(timeout=5000)
                        popular_clicked = True
                except:
                    pass
            
            if not popular_clicked:
                # Method 3: Try text-based selector
                try:
                    popular_btn = self.page.get_by_text("Popular", exact=True).first
                    if await popular_btn.count() > 0 and await popular_btn.is_visible(timeout=2000):
                        await popular_btn.click(timeout=5000)
                        popular_clicked = True
                except:
                    pass
            
            if popular_clicked:
                await self.page.wait_for_timeout(3000)
                print("   ✅ Clicked 'Popular' button - sorting by most viewed")
            else:
                print("   ⚠️ 'Popular' button not found, will sort manually by views")
                
        except Exception as e:
            print(f"   ⚠️ Could not find filter buttons: {e}")
            print("   ℹ️ Content will be sorted by views after scraping")

    async def _scroll_to_load_all(self, content_type: str, max_items: Optional[int] = None):
        """Scroll page to load all content"""
        print(f"📜 Scrolling to load {content_type}...")
        
        prev_count = 0
        no_change_count = 0
        max_no_change = 10
        
        while no_change_count < max_no_change:
            if content_type == "videos":
                current_count = await self.page.evaluate('''() => {
                    const items = document.querySelectorAll('ytd-rich-item-renderer');
                    let count = 0;
                    items.forEach(item => {
                        const link = item.querySelector('a#video-title-link, a[href*="/watch?v="]');
                        if (link && !link.href.includes('/shorts/')) count++;
                    });
                    return count;
                }''')
            else:
                current_count = await self.page.evaluate('''() => {
                    const items = document.querySelectorAll('ytd-rich-item-renderer');
                    let count = 0;
                    items.forEach(item => {
                        const link = item.querySelector('a[href*="/shorts/"]');
                        if (link) count++;
                    });
                    return count;
                }''')
            
            print(f"   Loaded: {current_count} {content_type}", end='\r')
            
            if max_items and current_count >= max_items:
                print(f"\n   ✅ Reached target: {current_count} {content_type}")
                break
            
            if current_count == prev_count:
                no_change_count += 1
            else:
                no_change_count = 0
            
            prev_count = current_count
            
            await self.page.evaluate('window.scrollBy(0, 1500)')
            await self.page.wait_for_timeout(random.randint(1000, 2000))
            
            if no_change_count > 5:
                await self.page.keyboard.press('End')
                await self.page.wait_for_timeout(1500)
        
        print(f"\n   📦 Total loaded: {prev_count} {content_type}")

    async def _scrape_videos(self, url: str, max_items: Optional[int] = None) -> List[Video]:
        """Scrape videos from channel"""
        
        success = await self._navigate_to_page(url)
        if not success:
            return []
        
        await self._click_popular_button()
        await self._scroll_to_load_all("videos", max_items)
        
        print(f"🔍 Extracting video data...")
        
        try:
            data = await self.page.evaluate('''() => {
                const videos = [];
                const seen = new Set();
                
                const items = document.querySelectorAll('ytd-rich-item-renderer');
                
                items.forEach((item) => {
                    try {
                        // Skip if this is a shorts item
                        const shortsLink = item.querySelector('a[href*="/shorts/"]');
                        if (shortsLink) return;
                        
                        // Find the video link - be specific to avoid thumbnail overlays
                        const titleElement = item.querySelector('#video-title-link, a#video-title, h3 a#video-title-link');
                        if (!titleElement) return;
                        
                        const href = titleElement.href || '';
                        if (!href.includes('/watch?v=')) return;
                        
                        const videoIdMatch = href.match(/watch\\?v=([a-zA-Z0-9_-]{11})/);
                        if (!videoIdMatch) return;
                        
                        const videoId = videoIdMatch[1];
                        if (seen.has(videoId)) return;
                        seen.add(videoId);
                        
                        // Get title - use title attribute first (more reliable), then text content
                        let title = titleElement.getAttribute('title') || '';
                        if (!title) {
                            // Get direct text content, avoiding nested elements
                            const titleTextEl = titleElement.querySelector('#video-title') || titleElement;
                            title = titleTextEl.textContent.trim();
                        }
                        
                        // Clean up title - remove any duration or "Now playing" artifacts
                        title = title.replace(/^\\d+:\\d+\\s*/g, '')  // Remove leading timestamps
                                    .replace(/\\s*Now playing\\s*/gi, '')  // Remove "Now playing"
                                    .replace(/\\n/g, ' ')  // Replace newlines
                                    .replace(/\\s+/g, ' ')  // Normalize whitespace
                                    .trim();
                        
                        if (!title) return;
                        
                        // Get views from metadata line
                        let views = '';
                        const metadataLine = item.querySelector('#metadata-line');
                        if (metadataLine) {
                            const spans = metadataLine.querySelectorAll('span.inline-metadata-item');
                            for (const span of spans) {
                                const text = span.textContent.trim();
                                if (text.toLowerCase().includes('view')) {
                                    views = text;
                                    break;
                                }
                            }
                        }
                        
                        // Alternative: try aria-label on the title element
                        if (!views && titleElement.getAttribute('aria-label')) {
                            const ariaLabel = titleElement.getAttribute('aria-label');
                            const viewMatch = ariaLabel.match(/(\\d[\\d,\\.]*[KMB]?\\s*views?)/i);
                            if (viewMatch) {
                                views = viewMatch[1];
                            }
                        }
                        
                        // Get duration from thumbnail overlay
                        let duration = '';
                        const durationEl = item.querySelector(
                            'ytd-thumbnail-overlay-time-status-renderer span#text, ' +
                            'ytd-thumbnail-overlay-time-status-renderer #text, ' +
                            'span.ytd-thumbnail-overlay-time-status-renderer'
                        );
                        if (durationEl) {
                            duration = durationEl.textContent.trim();
                        }
                        
                        videos.push({
                            title,
                            views,
                            duration,
                            videoId,
                            url: 'https://www.youtube.com/watch?v=' + videoId
                        });
                        
                    } catch(e) {
                        console.error('Error extracting video:', e);
                    }
                });
                
                return videos;
            }''')
            
            videos = []
            items_to_process = data[:max_items] if max_items else data
            
            for idx, v in enumerate(items_to_process, 1):
                views_str = v.get('views', '')
                videos.append(Video(
                    rank=idx,
                    title=v.get('title', ''),
                    views=views_str,
                    views_numeric=parse_views_to_number(views_str),
                    duration=v.get('duration', ''),
                    url=v.get('url', ''),
                    video_id=v.get('videoId', ''),
                    content_type='video'
                ))
            
            print(f"✅ Extracted {len(videos)} videos")
            return videos
            
        except Exception as e:
            print(f"⚠️ Extraction error: {e}")
            import traceback
            traceback.print_exc()
            return []

    async def _scrape_shorts(self, url: str, max_items: Optional[int] = None) -> List[Short]:
        """Scrape shorts from channel"""
        
        success = await self._navigate_to_page(url)
        if not success:
            return []
        
        current_url = self.page.url
        if '/shorts' not in current_url:
            print("   ⚠️ Channel has no shorts")
            return []
        
        await self._click_popular_button()
        await self._scroll_to_load_all("shorts", max_items)
        
        print(f"🔍 Extracting shorts data...")
        
        try:
            data = await self.page.evaluate('''() => {
                const shorts = [];
                const seen = new Set();
                
                const items = document.querySelectorAll('ytd-rich-item-renderer');
                
                items.forEach((item) => {
                    try {
                        // Find shorts link
                        const thumbnailLink = item.querySelector('a#thumbnail[href*="/shorts/"], a[href*="/shorts/"]');
                        if (!thumbnailLink) return;
                        
                        const href = thumbnailLink.href || '';
                        const shortIdMatch = href.match(/\\/shorts\\/([a-zA-Z0-9_-]{11})/);
                        if (!shortIdMatch) return;
                        
                        const videoId = shortIdMatch[1];
                        if (seen.has(videoId)) return;
                        seen.add(videoId);
                        
                        // Get title - try multiple approaches
                        let title = '';
                        
                        // Approach 1: Direct title element
                        const titleEl = item.querySelector('#video-title, yt-formatted-string#video-title, a#video-title-link, h3 a');
                        if (titleEl) {
                            title = titleEl.getAttribute('title') || titleEl.textContent.trim();
                        }
                        
                        // Approach 2: Aria label on thumbnail
                        if (!title && thumbnailLink.getAttribute('aria-label')) {
                            const ariaLabel = thumbnailLink.getAttribute('aria-label');
                            // Aria label format: "Title - X views"
                            const parts = ariaLabel.split(' - ');
                            if (parts.length > 0) {
                                title = parts[0].trim();
                            }
                        }
                        
                        // Approach 3: Look in details section
                        if (!title) {
                            const detailsTitle = item.querySelector('#details #video-title, #details h3');
                            if (detailsTitle) {
                                title = detailsTitle.textContent.trim();
                            }
                        }
                        
                        // Get views - try multiple approaches
                        let views = '';
                        
                        // Approach 1: Metadata line
                        const metadataLine = item.querySelector('#metadata-line, ytd-video-meta-block #metadata-line');
                        if (metadataLine) {
                            const spans = metadataLine.querySelectorAll('span');
                            for (const span of spans) {
                                const text = span.textContent.trim();
                                if (text.toLowerCase().includes('view')) {
                                    views = text;
                                    break;
                                }
                            }
                        }
                        
                        // Approach 2: Look for any span with views
                        if (!views) {
                            const allSpans = item.querySelectorAll('span');
                            for (const span of allSpans) {
                                const text = span.textContent.trim();
                                if (text.toLowerCase().includes('view') && /\\d/.test(text)) {
                                    views = text;
                                    break;
                                }
                            }
                        }
                        
                        // Approach 3: Aria label
                        if (!views && thumbnailLink.getAttribute('aria-label')) {
                            const ariaLabel = thumbnailLink.getAttribute('aria-label');
                            const viewMatch = ariaLabel.match(/(\\d[\\d,\\.]*[KMB]?\\s*views?)/i);
                            if (viewMatch) {
                                views = viewMatch[1];
                            }
                        }
                        
                        // Approach 4: Overlay panel
                        if (!views) {
                            const overlay = item.querySelector('ytd-thumbnail-overlay-bottom-panel-renderer span');
                            if (overlay) {
                                const text = overlay.textContent.trim();
                                if (text.toLowerCase().includes('view') || /\\d/.test(text)) {
                                    views = text;
                                }
                            }
                        }
                        
                        shorts.push({
                            title,
                            views,
                            videoId,
                            url: 'https://www.youtube.com/shorts/' + videoId
                        });
                        
                    } catch(e) {
                        console.error('Error extracting short:', e);
                    }
                });
                
                return shorts;
            }''')
            
            shorts = []
            items_to_process = data[:max_items] if max_items else data
            
            for idx, s in enumerate(items_to_process, 1):
                views_str = s.get('views', '')
                shorts.append(Short(
                    rank=idx,
                    title=s.get('title', ''),
                    views=views_str,
                    views_numeric=parse_views_to_number(views_str),
                    url=s.get('url', ''),
                    video_id=s.get('videoId', ''),
                    content_type='short'
                ))
            
            print(f"✅ Extracted {len(shorts)} shorts")
            return shorts
            
        except Exception as e:
            print(f"⚠️ Extraction error: {e}")
            import traceback
            traceback.print_exc()
            return []

