from __future__ import annotations

from pathlib import Path

from purifyllm.main import main


def write(p: Path, s: str) -> Path:
	p.write_text(s, encoding="utf-8")
	return p


def read(p: Path) -> str:
	return p.read_text(encoding="utf-8")


def test_default_replacements_changes_file(tmp_path: Path) -> None:
	# content contains em dash (\u2014), ellipsis (\u2026), nbsp (\u00A0), zero width space (\u200B)
	original = "\u201CHello\u201D \u2014 world\u2026\nNBSP: X\u00A0Y\nZW: A\u200BB\n"
	f = write(tmp_path / "a.txt", original)

	rc = main([str(f)])
	assert rc == 1  # file modified

	out = read(f)
	assert out == '"Hello" - world...\nNBSP: X Y\nZW: AB\n'


def test_no_changes_exit_zero(tmp_path: Path) -> None:
	f = write(tmp_path / "b.txt", 'plain ascii line\n')
	rc = main([str(f)])
	assert rc == 0
	assert read(f) == 'plain ascii line\n'


def test_custom_map_only_no_defaults(tmp_path: Path) -> None:
	# star (\u2605) should be mapped to '*' only when specified
	content = "rating: \u2605\u2605\u2605\n"
	f = write(tmp_path / "c.txt", content)

	rc = main(["--no-defaults", "--map", "\\u2605=*", str(f)])
	assert rc == 1
	assert read(f) == "rating: ***\n"


def test_multiple_files_exit_code(tmp_path: Path) -> None:
	changed = write(tmp_path / "c1.txt", "dash: \u2014\n")
	unchanged = write(tmp_path / "c2.txt", "ok\n")
	rc = main([str(changed), str(unchanged)])
	assert rc == 1
	assert read(changed) == "dash: -\n"
	assert read(unchanged) == "ok\n"


def test_no_files_returns_zero() -> None:
	assert main([]) == 0


def test_ignore_files_by_dirname_glob(tmp_path: Path) -> None:
	# Create a directory named LICENSES and a file inside
	d = tmp_path / "LICENSES"
	d.mkdir()
	f = d / "notice.txt"
	write(f, "dash: \u2014\n")

	# same content in allowed dir
	g = tmp_path / "src" / "file.txt"
	g.parent.mkdir(parents=True)
	write(g, "dash: \u2014\n")

	rc = main(["--ignore-files", "**/LICENSES/**", str(f), str(g)])
	# g should be modified, f skipped
	assert rc == 1
	assert read(f) == "dash: \u2014\n"
	assert read(g) == "dash: -\n"


def test_ignore_files_by_subpath_glob(tmp_path: Path) -> None:
	d = tmp_path / "docs" / "vendor"
	d.mkdir(parents=True)
	f = d / "x.txt"
	write(f, "…\n")

	other = tmp_path / "docs" / "ours" / "y.txt"
	other.parent.mkdir(parents=True)
	write(other, "…\n")

	rc = main(["--ignore-files", "docs/vendor/**", str(f), str(other)])
	assert rc == 1
	assert read(f) == "…\n"  # ignored
	assert read(other) == "...\n"  # processed


def test_additional_quotation_marks(tmp_path: Path) -> None:
	# Test guillemets and other quotation marks
	original = "\u00ABHello\u00BB and \u2039hi\u203A and \u201Equote\u201C and \u201Asingle\u201B and \u201Fother\u201D\n"
	f = write(tmp_path / "quotes.txt", original)

	rc = main([str(f)])
	assert rc == 1
	out = read(f)
	assert out == '"Hello" and \'hi\' and "quote" and \'single\' and "other"\n'


def test_additional_dashes(tmp_path: Path) -> None:
	# Test figure dash, horizontal bar, soft hyphen, hyphen, non-breaking hyphen
	original = "hyphen:\u2010 nb-hyphen:\u2011 figure:\u2012 horiz:\u2015 soft:\u00ADhyphen\n"
	f = write(tmp_path / "dashes.txt", original)

	rc = main([str(f)])
	assert rc == 1
	out = read(f)
	assert out == "hyphen:- nb-hyphen:- figure:- horiz:- soft:hyphen\n"


def test_additional_spaces(tmp_path: Path) -> None:
	# Test em space, en space, ideographic space, and other spaces
	original = "em:\u2003space en:\u2002space ideo:\u3000space three:\u2004four:\u2005six:\u2006punct:\u2008x\n"
	f = write(tmp_path / "spaces.txt", original)

	rc = main([str(f)])
	assert rc == 1
	out = read(f)
	assert out == "em: space en: space ideo: space three: four: six: punct: x\n"


def test_invisible_operators(tmp_path: Path) -> None:
	# Test invisible mathematical operators
	original = "func:\u2061app times:\u2062x sep:\u2063y plus:\u2064z\n"
	f = write(tmp_path / "invisible.txt", original)

	rc = main([str(f)])
	assert rc == 1
	out = read(f)
	assert out == "func:app times:x sep:y plus:z\n"


def test_directional_marks(tmp_path: Path) -> None:
	# Test LTR/RTL marks and embeddings
	original = "text\u200Ewith\u200FLTR\u202ARTL\u202Bpop\u202Coverride\u202D\u202Eisolate\u2066\u2067\u2068pop\u2069\n"
	f = write(tmp_path / "bidi.txt", original)

	rc = main([str(f)])
	assert rc == 1
	out = read(f)
	assert out == "textwithLTRRTLpopoverrideisolatepop\n"


def test_mongolian_vowel_separator(tmp_path: Path) -> None:
	# Test historic mongolian vowel separator (used to be a space)
	original = "word\u180Eseparator\n"
	f = write(tmp_path / "mongolian.txt", original)

	rc = main([str(f)])
	assert rc == 1
	out = read(f)
	assert out == "wordseparator\n"


def test_comprehensive_gpt_symbols(tmp_path: Path) -> None:
	# Test a realistic example with multiple GPT-produced symbols
	original = (
		"\u201CHello,\u201D she said\u2014\u201Chow are you?\u201D\n"
		"Price: $100\u2009\u2013\u2009$200\u00A0(non\u2011breaking)\n"
		"Ellipsis\u2026 and «guillemets» here.\n"
		"Math: a\u2062b\u2009=\u2009c (invisible\u200Btimes)\n"
	)
	f = write(tmp_path / "comprehensive.txt", original)

	rc = main([str(f)])
	assert rc == 1
	out = read(f)
	expected = (
		'"Hello," she said-"how are you?"\n'
		"Price: $100 - $200 (non-breaking)\n"
		'Ellipsis... and "guillemets" here.\n'
		"Math: ab = c (invisibletimes)\n"
	)
	assert out == expected

