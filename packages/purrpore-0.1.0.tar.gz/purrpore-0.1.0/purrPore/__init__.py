# purrPore/__init__.py
"""purrPore: merge ONT nanopore data from POD5 and FASTQ for per-pore QC."""

from purrPore.fastq import load_fastq_metrics
from purrPore.pod5 import load_pod5_metadata
from purrPore.merge import merge_fastq_pod5
from purrPore.qc import compute_qc_tables
from purrPore.types import QCResults
from purrPore.io import write_qc_results
from purrPore.plot import plot_flowcell_heatmap

__all__ = [
    "load_fastq_metrics",
    "load_pod5_metadata",
    "merge_fastq_pod5",
    "compute_qc_tables",
    "QCResults",
    "run_qc",
    "write_qc_results",
    "plot_flowcell_heatmap",
]


def run_qc(fastq_path: str, pod5_dir: str) -> QCResults:
    """Load FASTQ and POD5 data, merge by read_id, and compute per-pore and flowcell QC."""
    fastq_df = load_fastq_metrics(fastq_path)
    pod5_df = load_pod5_metadata(pod5_dir)
    merged = merge_fastq_pod5(fastq_df, pod5_df)
    per_pore, flowcell, dropout_pores = compute_qc_tables(merged)
    return QCResults(
        merged=merged,
        per_pore=per_pore,
        flowcell=flowcell,
        dropout_pores=dropout_pores,
    )

