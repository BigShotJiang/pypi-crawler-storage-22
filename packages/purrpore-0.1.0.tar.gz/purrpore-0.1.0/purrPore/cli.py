# purrPore/cli.py
"""Command-line interface for purrPore."""

import argparse
import sys
from pathlib import Path


def run_cmd(args: argparse.Namespace) -> int:
    """Execute `purrPore run` subcommand."""
    from purrPore import run_qc, write_qc_results
    from purrPore.io import collect_fastq_paths, collect_pod5_paths
    from purrPore.plot import plot_flowcell_heatmap_from_results

    fastq_path = Path(args.fastq)
    pod5_dir = Path(args.pod5_dir)
    out_dir = Path(args.out_dir) if args.out_dir else Path("purrPore_qc")

    # Resolve FASTQ: single file or directory
    fastq_files = collect_fastq_paths(fastq_path)
    if not fastq_files:
        print(f"Error: No FASTQ files found at {fastq_path}", file=sys.stderr)
        return 1

    # For now, use first FASTQ if multiple (could concatenate or process all)
    fastq_file = fastq_files[0]
    if len(fastq_files) > 1:
        print(f"Note: Using first FASTQ: {fastq_file} ({len(fastq_files)} total)", file=sys.stderr)

    pod5_files = collect_pod5_paths(pod5_dir)
    if not pod5_files:
        print(f"Error: No POD5 files found at {pod5_dir}", file=sys.stderr)
        return 1

    print(f"FASTQ: {fastq_file}")
    print(f"POD5:  {pod5_dir} ({len(pod5_files)} files)")
    print(f"Output: {out_dir}")

    results = run_qc(str(fastq_file), str(pod5_dir))
    write_qc_results(results, out_dir)

    # Heatmaps
    if args.heatmap:
        try:
            plot_flowcell_heatmap_from_results(
                results,
                value_col="yield_bp",
                out_path=out_dir / "heatmap_yield.png",
            )
            plot_flowcell_heatmap_from_results(
                results,
                value_col="n50",
                out_path=out_dir / "heatmap_n50.png",
            )
            plot_flowcell_heatmap_from_results(
                results,
                value_col="reads",
                out_path=out_dir / "heatmap_reads.png",
            )
            print(f"Heatmaps saved to {out_dir}/")
        except ImportError as e:
            print(f"Warning: Could not generate heatmaps (matplotlib?): {e}", file=sys.stderr)

    print(f"QC complete. Active pores: {results.flowcell['active_pores'].iloc[0]}, "
          f"Dropout: {results.flowcell['dropout_pores'].iloc[0]}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="purrPore",
        description="Merge ONT nanopore data from POD5 and FASTQ for per-pore QC",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser("run", help="Run QC on FASTQ + POD5 data")
    run_parser.add_argument("fastq", help="FASTQ file or directory")
    run_parser.add_argument("pod5_dir", help="POD5 directory")
    run_parser.add_argument("-o", "--out-dir", default="purrPore_qc", help="Output directory")
    run_parser.add_argument("--heatmap", action="store_true", help="Generate flow cell heatmaps")
    run_parser.set_defaults(func=run_cmd)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
