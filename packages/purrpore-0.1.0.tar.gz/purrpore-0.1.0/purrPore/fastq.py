# purrPore/fastq.py
"""Load per-read metrics from FASTQ (length, mean Q, GC)."""

from typing import Union

import pandas as pd
from Bio import SeqIO


def load_fastq_metrics(fastq_path: Union[str, bytes]) -> pd.DataFrame:
    """Parse FASTQ and return a DataFrame with read_id, read_length, mean_q, gc."""
    rows = []
    for rec in SeqIO.parse(fastq_path, "fastq"):
        seq = str(rec.seq)
        quals = rec.letter_annotations["phred_quality"]
        rows.append({
            "read_id": rec.id.split()[0],
            "read_length": len(seq),
            "mean_q": sum(quals) / len(quals),
            "gc": 100 * (seq.count("G") + seq.count("C")) / len(seq),
        })
    return pd.DataFrame(rows)
