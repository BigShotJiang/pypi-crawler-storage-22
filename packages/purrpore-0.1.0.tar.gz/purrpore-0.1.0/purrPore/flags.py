# purrPore/flags.py
"""Constants and flags for ONT nanopore QC and filtering."""

# Default QC thresholds (commonly used cutoffs)
DEFAULT_MIN_MEAN_Q = 7.0
DEFAULT_MIN_READ_LENGTH = 100
DEFAULT_MAX_READ_LENGTH = 2_000_000
DEFAULT_MIN_GC = 0.0
DEFAULT_MAX_GC = 100.0

# Typical MinION/GridION sample rate (Hz)
DEFAULT_SAMPLE_RATE = 4000

# Pore layout (MinION R9/R10 flow cell)
MINION_CHANNELS = 512
MINION_WELLS_PER_CHANNEL = 4
TOTAL_PORES = MINION_CHANNELS * MINION_WELLS_PER_CHANNEL  # 2048
