# purrPore/io.py
"""I/O helpers for reading FASTQ/POD5 paths and writing QC outputs."""

from pathlib import Path
from typing import List, Optional, Union

import pandas as pd

from purrPore.types import QCResults


def write_qc_results(
    results: QCResults,
    out_dir: Union[str, Path],
    *,
    per_pore_csv: str = "per_pore.csv",
    flowcell_csv: str = "flowcell.csv",
    merged_parquet: Optional[str] = "merged.parquet",
    dropout_txt: str = "dropout_pores.txt",
) -> None:
    """Write QCResults to CSV (and optionally merged table as Parquet) under out_dir."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    results.per_pore.to_csv(out_dir / per_pore_csv, index=False)
    results.flowcell.to_csv(out_dir / flowcell_csv, index=False)
    if merged_parquet:
        results.merged.to_parquet(out_dir / merged_parquet, index=False)
    with open(out_dir / dropout_txt, "w") as f:
        f.write("channel,well\n")
        f.write("\n".join(f"{ch},{w}" for ch, w in results.dropout_pores) + "\n")


def collect_fastq_paths(path: Union[str, Path]) -> List[Path]:
    """Resolve path to a list of FASTQ files (single file or directory of .fastq/.fq)."""
    path = Path(path)
    if path.is_file():
        return [path]
    if path.is_dir():
        return sorted(path.glob("*.fastq")) + sorted(path.glob("*.fq"))
    return []


def collect_pod5_paths(path: Union[str, Path]) -> List[Path]:
    """Resolve path to a list of POD5 files (single file or directory of .pod5)."""
    path = Path(path)
    if path.is_file():
        return [path] if path.suffix.lower() == ".pod5" else []
    if path.is_dir():
        return sorted(path.glob("*.pod5"))
    return []
