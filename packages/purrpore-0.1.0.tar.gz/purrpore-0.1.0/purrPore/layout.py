# purrPore/layout.py
"""MinION flow cell physical layout for heatmap plotting.

Layout based on publicly documented MinION channel mapping:
- Channels 1-64 at top, 449-512, 385-448, 321-384, 257-320, 193-256, 129-192, 65-128 at bottom
- 32 rows × 16 columns for channels; each channel has 4 wells → 128×16 pore grid
- Source: https://bioinformatics.stackexchange.com/a/749
"""

import numpy as np

# Channel order down the chip (8 blocks of 64 channels each, top to bottom)
_CHANNEL_BLOCKS = [
    (33, 64, 1, 4, 1, 8),
    (481, 512, 5, 8, 1, 8),
    (417, 448, 9, 12, 1, 8),
    (353, 384, 13, 16, 1, 8),
    (289, 320, 17, 20, 1, 8),
    (225, 256, 21, 24, 1, 8),
    (161, 192, 25, 28, 1, 8),
    (97, 128, 29, 32, 1, 8),
    (1, 32, 1, 4, 16, 9),
    (449, 480, 5, 8, 16, 9),
    (385, 416, 9, 12, 16, 9),
    (321, 352, 13, 16, 16, 9),
    (257, 288, 17, 20, 16, 9),
    (193, 224, 21, 24, 16, 9),
    (129, 160, 25, 28, 16, 9),
    (65, 96, 29, 32, 16, 9),
]

CHANNEL_ROWS = 32
CHANNEL_COLS = 16
WELLS_PER_CHANNEL = 4
# Per-pore grid: 4 rows per channel row (one per well)
PORE_ROWS = CHANNEL_ROWS * WELLS_PER_CHANNEL  # 128
PORE_COLS = CHANNEL_COLS  # 16

# Backward compat
ROWS = CHANNEL_ROWS
COLS = CHANNEL_COLS


def channel_to_position(channel: int) -> tuple[int, int]:
    """Map channel (1-512) to (row, col) on the channel grid. Row/col are 0-based."""
    for start, end, r0, r1, c_start, c_end in _CHANNEL_BLOCKS:
        if start <= channel <= end:
            idx = channel - start
            n_per_row = 8
            row_offset = idx // n_per_row
            col_offset = idx % n_per_row
            row = r0 + row_offset - 1
            if c_start > c_end:
                col = c_start - 1 - col_offset
            else:
                col = c_start - 1 + col_offset
            return (row, col)
    raise ValueError(f"Channel {channel} out of range 1-512")


def channel_well_to_position(channel: int, well: int) -> tuple[int, int]:
    """Map (channel, well) to (row, col) on the pore grid. Well is 1-4, 0-based output."""
    ch_row, ch_col = channel_to_position(channel)
    # Each channel occupies 4 consecutive rows (wells 1-4)
    pore_row = ch_row * WELLS_PER_CHANNEL + (well - 1)
    pore_col = ch_col
    return (pore_row, pore_col)


def build_channel_grid() -> np.ndarray:
    """Return a 32×16 array where grid[row, col] = channel number (1-512)."""
    grid = np.zeros((CHANNEL_ROWS, CHANNEL_COLS), dtype=int)
    for ch in range(1, 513):
        r, c = channel_to_position(ch)
        grid[r, c] = ch
    return grid


def pore_grid_to_value_grid(
    per_pore: "pd.DataFrame",
    value_col: str,
    channel_col: str = "channel",
    well_col: str = "well",
) -> np.ndarray:
    """Map per-pore DataFrame (channel, well) values onto the physical layout. NaN for missing pores."""
    grid = np.full((PORE_ROWS, PORE_COLS), np.nan, dtype=float)
    lookup = per_pore.set_index([channel_col, well_col])[value_col]
    for ch in range(1, 513):
        for w in range(1, WELLS_PER_CHANNEL + 1):
            try:
                val = lookup.loc[(ch, w)]
            except (KeyError, TypeError):
                continue
            r, c = channel_well_to_position(ch, w)
            grid[r, c] = float(val)
    return grid


def channel_grid_to_value_grid(
    per_pore: "pd.DataFrame",
    value_col: str,
    channel_col: str = "channel",
    well_col: str = "well",
) -> np.ndarray:
    """Map per-pore DataFrame onto pore grid. Aggregates by channel if well_col missing (backward compat)."""
    if well_col in per_pore.columns:
        return pore_grid_to_value_grid(per_pore, value_col, channel_col, well_col)
    # Fallback: aggregate per channel (e.g. sum across wells) for channel-only data
    grid = np.full((PORE_ROWS, PORE_COLS), np.nan, dtype=float)
    agg = per_pore.groupby(channel_col)[value_col].mean()
    for ch in range(1, 513):
        try:
            val = agg.loc[ch]
        except (KeyError, TypeError):
            continue
        for w in range(1, WELLS_PER_CHANNEL + 1):
            r, c = channel_well_to_position(ch, w)
            grid[r, c] = float(val)
    return grid
