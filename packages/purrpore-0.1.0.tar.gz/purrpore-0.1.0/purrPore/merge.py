# purrPore/merge.py
"""Merge FASTQ-derived metrics with POD5 metadata on read_id."""

import pandas as pd


def merge_fastq_pod5(fastq_df: pd.DataFrame, pod5_df: pd.DataFrame) -> pd.DataFrame:
    """Inner join FASTQ and POD5 DataFrames on read_id. Raises if no overlap."""
    merged = pod5_df.merge(fastq_df, on="read_id", how="inner")
    if len(merged) == 0:
        raise ValueError("No overlapping read_ids between FASTQ and POD5")
    return merged
