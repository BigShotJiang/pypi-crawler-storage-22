# purrPore/plot.py
"""Flow cell heatmap and QC visualizations."""

from pathlib import Path
from typing import Optional, Union

import numpy as np

from purrPore.layout import (
    CHANNEL_ROWS,
    CHANNEL_COLS,
    PORE_ROWS,
    PORE_COLS,
    channel_grid_to_value_grid,
    channel_to_position,
)


def plot_flowcell_heatmap(
    per_pore: "pd.DataFrame",
    value_col: str = "yield_bp",
    *,
    per_channel: bool = True,
    agg_func: str = "median",
    title: Optional[str] = None,
    cmap: str = "viridis",
    out_path: Optional[Union[str, Path]] = None,
    figsize: Optional[tuple[float, float]] = None,
    **kwargs,
) -> "matplotlib.figure.Figure":
    """Plot a heatmap of the flow cell.

    Args:
        per_pore: DataFrame with 'channel', 'well', and value_col
        value_col: Column to plot (e.g. 'yield_bp', 'reads', 'n50', 'mean_q')
        per_channel: If True (default), aggregate by channel (median over wells) for 32×16 grid.
            If False, plot per-pore 128×16 grid.
        agg_func: Aggregation when per_channel=True ('median', 'mean', 'sum')
        title: Plot title
        cmap: Matplotlib colormap name
        out_path: Save figure to this path
        figsize: Figure size (default: (5, 10) per-channel, (4, 14) per-pore; long thin layout)
        **kwargs: Passed to imshow

    Returns:
        matplotlib Figure
    """
    import matplotlib.pyplot as plt
    import pandas as pd

    if per_channel and "well" in per_pore.columns:
        # Aggregate by channel (median over wells)
        agg = per_pore.groupby("channel")[value_col].agg(agg_func)
        grid = np.full((CHANNEL_ROWS, CHANNEL_COLS), np.nan, dtype=float)
        for ch in agg.index:
            try:
                val = float(agg.loc[ch])
            except (KeyError, TypeError):
                continue
            r, c = channel_to_position(int(ch))
            grid[r, c] = val
        n_rows, n_cols = CHANNEL_ROWS, CHANNEL_COLS
        # Long and thin: 32×16 → height ~2× width (inches)
        default_figsize = (5, 10)
        aspect = "equal"
    else:
        grid = channel_grid_to_value_grid(per_pore, value_col)
        n_rows, n_cols = PORE_ROWS, PORE_COLS
        # Long and thin: 128×16
        default_figsize = (4, 14)
        aspect = "equal"

    masked = np.ma.masked_invalid(grid)
    figsize = figsize or default_figsize

    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(
        masked,
        aspect=aspect,
        cmap=cmap,
        interpolation="nearest",
        **kwargs,
    )
    plt.colorbar(im, ax=ax, label=value_col, fraction=0.03, shrink=0.5)
    ax.set_xlabel("Column")
    ax.set_ylabel("Row")
    if title is None:
        suffix = " (per channel, median)" if per_channel else " (per pore)"
        title = f"Flow cell: {value_col}{suffix}"
    ax.set_title(title)
    ax.set_xticks(range(n_cols))
    ax.set_yticks(range(n_rows))

    if out_path is not None:
        fig.savefig(out_path, dpi=150, bbox_inches="tight")
    return fig


def plot_flowcell_heatmap_from_results(
    results: "QCResults",
    value_col: str = "yield_bp",
    *,
    per_channel: bool = True,
    agg_func: str = "median",
    out_path: Optional[Union[str, Path]] = None,
    **kwargs,
) -> "matplotlib.figure.Figure":
    """Convenience wrapper: plot heatmap from QCResults.per_pore."""
    return plot_flowcell_heatmap(
        results.per_pore,
        value_col=value_col,
        per_channel=per_channel,
        agg_func=agg_func,
        out_path=out_path,
        **kwargs,
    )
