# purrPore/pod5.py
"""Load per-read metadata from POD5 files (pore channel, well, duration, etc.)."""

from pathlib import Path
from typing import Union

import pandas as pd
import pod5

DEFAULT_SAMPLE_RATE = 4000  # Hz, fallback if run_info missing


def load_pod5_metadata(pod5_dir: Union[str, Path]) -> pd.DataFrame:
    """Load read_id, channel, well, start_sample, duration_s from all POD5 files in a directory."""
    pod5_dir = Path(pod5_dir)
    rows = []

    for pod5_path in sorted(pod5_dir.glob("*.pod5")):
        with pod5.Reader(pod5_path) as reader:
            for r in reader.reads():
                sample_rate = getattr(
                    getattr(r, "run_info", None), "sample_rate", None
                ) or DEFAULT_SAMPLE_RATE
                num_samples = getattr(r, "num_samples", 0) or getattr(
                    r, "sample_count", 0
                )
                duration_s = num_samples / sample_rate if num_samples else 0.0
                start_time_s = r.start_sample / sample_rate if sample_rate else 0.0

                rows.append({
                    "read_id": str(r.read_id),
                    "channel": r.pore.channel,
                    "well": r.pore.well,
                    "acquisition_id": getattr(r.run_info, "acquisition_id", ""),
                    "start_sample": r.start_sample,
                    "start_time_s": start_time_s,
                    "duration_s": duration_s,
                    "num_samples": num_samples,
                    "sample_rate": sample_rate,
                    "pod5_file": str(pod5_path),
                })

    return pd.DataFrame(rows)
