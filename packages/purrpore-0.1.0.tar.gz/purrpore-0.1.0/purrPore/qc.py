# purrPore/qc.py
"""Compute per-pore and flowcell QC tables from merged FASTQ+POD5 data."""

from typing import List, Tuple

import pandas as pd

from purrPore.flags import MINION_CHANNELS, MINION_WELLS_PER_CHANNEL, TOTAL_PORES


def _n50(lengths: pd.Series) -> float:
    """N50: length of shortest read such that 50% of total yield is in reads of that length or longer."""
    if len(lengths) == 0:
        return 0.0
    total = lengths.sum()
    if total == 0:
        return 0.0
    sorted_len = lengths.sort_values(ascending=False)
    cumsum = sorted_len.cumsum()
    half = total / 2
    idx = (cumsum >= half).idxmax()
    return float(sorted_len.loc[idx])


def compute_qc_tables(
    merged: pd.DataFrame,
    total_channels: int = MINION_CHANNELS,
    wells_per_channel: int = MINION_WELLS_PER_CHANNEL,
) -> Tuple[pd.DataFrame, pd.DataFrame, List[Tuple[int, int]]]:
    """Aggregate merged reads by (channel, well) for true per-pore QC.

    Each channel has up to 4 wells (nanopores). Dropout = pores (channel, well) with 0 reads.
    """
    merged = merged.copy()
    merged["bp_per_sec"] = merged["read_length"] / merged["duration_s"]

    per_pore = (
        merged.groupby(["channel", "well"])
        .agg(
            reads=("read_id", "count"),
            yield_bp=("read_length", "sum"),
            mean_len=("read_length", "mean"),
            mean_q=("mean_q", "mean"),
            mean_gc=("gc", "mean"),
            median_speed=("bp_per_sec", "median"),
            active_time_s=("duration_s", "sum"),
        )
        .reset_index()
    )

    # N50 per pore (custom aggregation)
    n50_per_pore = (
        merged.groupby(["channel", "well"])["read_length"]
        .apply(_n50)
        .reset_index()
    )
    n50_per_pore.columns = ["channel", "well", "n50"]
    per_pore = per_pore.merge(n50_per_pore, on=["channel", "well"], how="left")
    per_pore["n50"] = per_pore["n50"].fillna(0)

    active_pores = set(
        zip(per_pore["channel"].astype(int), per_pore["well"].astype(int))
    )
    all_pores = {
        (ch, w)
        for ch in range(1, total_channels + 1)
        for w in range(1, wells_per_channel + 1)
    }
    dropout_pores = sorted(all_pores - active_pores)
    total_pores = total_channels * wells_per_channel

    flowcell = pd.DataFrame([{
        "total_reads": len(merged),
        "total_yield_bp": merged["read_length"].sum(),
        "mean_q": merged["mean_q"].mean(),
        "active_pores": len(active_pores),
        "dropout_pores": len(dropout_pores),
        "total_pores": total_pores,
        "active_channels": merged["channel"].nunique(),
    }])

    return per_pore, flowcell, dropout_pores
