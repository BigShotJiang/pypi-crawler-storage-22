# purrPore/types.py
"""Data types for purrPore QC results."""

from dataclasses import dataclass
from typing import List, Tuple

import pandas as pd


@dataclass
class QCResults:
    """Container for merged read table, per-pore QC, flowcell summary, and dropout pores."""

    merged: pd.DataFrame
    per_pore: pd.DataFrame
    flowcell: pd.DataFrame
    dropout_pores: List[Tuple[int, int]]  # (channel, well) pairs with 0 reads
