from typing import Any, List, Dict
from puzzlekit.core.solver import PuzzleSolver
from puzzlekit.core.grid import Grid
from puzzlekit.core.regionsgrid import RegionsGrid
from puzzlekit.core.position import Position
from puzzlekit.utils.ortools_utils import add_circuit_constraint_from_undirected
from puzzlekit.utils.puzzle_math import get_allowed_direction_chars
from puzzlekit.core.docs_template import GENERAL_REGION_GRID_TEMPLATE_INPUT_DESC, LOOP_TEMPLATE_OUTPUT_DESC
from ortools.sat.python import cp_model as cp
from typeguard import typechecked

class DoubleBackSolver(PuzzleSolver):
    metadata : Dict[str, Any] = {
        "name": "double_back",
        "aliases": [],
        "difficulty": "",
        "tags": ["loop"],
        "rule_url": "https://pzplus.tck.mn/rules.html?doubleback",
        "external_links": [
            {"Play at puzz.link": "https://puzz.link/p?doubleback/10/10/i10o548pcisb7pd9ii1sf3fp1me3te986sg2"},
            {"Janko": "https://www.janko.at/Raetsel/Double-Back/001.a.htm"}
        ],
        "input_desc": GENERAL_REGION_GRID_TEMPLATE_INPUT_DESC,
        "output_desc": LOOP_TEMPLATE_OUTPUT_DESC,
        "input_example": """
        8 8
        1 1 6 6 6 6 6 6
        1 5 5 5 5 11 11 6
        1 5 7 7 7 7 11 6
        2 4 7 8 8 7 11 6
        2 4 7 8 8 9 11 12
        2 4 9 9 9 9 11 12
        3 4 10 10 10 10 10 13
        3 3 3 3 3 13 13 13
        """,
        "output_example": """
        8 8
        se ew ew ew sw se ew sw
        ne sw se ew nw ne sw ns
        se nw ne ew ew sw ns ns
        ne sw se ew sw ne nw ns
        se nw ne sw ne sw se nw
        ns se ew nw se nw ne sw
        ns ns se ew nw se sw ns
        ne nw ne ew ew nw ne nw
        """
    }

    @typechecked
    def __init__(self, num_rows: int, num_cols: int, region_grid: List[List[str]], grid: List[List[str]] = list()):
        self.num_rows: int = num_rows
        self.num_cols: int  = num_cols
        self.region_grid: RegionsGrid[str] = RegionsGrid(region_grid)
        self.grid: Grid[str] = Grid(grid) if grid else Grid([["-" for _ in range(self.num_cols)] for _ in range(self.num_rows)])
        # for pre fill cells, not active for now.
        self.validate_input()
        
    def validate_input(self):
        self._check_grid_dims(self.num_rows, self.num_cols, self.grid.matrix)
        self._check_grid_dims(self.num_rows, self.num_cols, self.region_grid.matrix)
        self._check_allowed_chars(self.grid.matrix, allowed= get_allowed_direction_chars() | {"-", "@", "x"})
        
    def _add_constr(self):
        self.x = dict()
        self.model = cp.CpModel()
        self.solver = cp.CpSolver()
        self._add_vars()
        self._add_region_constr()
        
        
    def _add_vars(self):
        self.arc_vars = dict()
        all_nodes = []
        for i in range(self.num_rows):
            for j in range(self.num_cols):
                all_nodes.append(Position(i, j))
                
        for i in range(self.num_rows):
            for j in range(self.num_cols):
                u = Position(i, j)

                if j < self.num_cols:
                    v = Position(i, j + 1)
                    self.arc_vars[(u, v)] = self.model.NewBoolVar(f"edge_{u}_{v}")

                if i < self.num_rows:
                    v = Position(i + 1, j)
                    self.arc_vars[(u, v)] = self.model.NewBoolVar(f"edge_{u}_{v}")
        
        self.node_active = add_circuit_constraint_from_undirected(
            self.model, 
            all_nodes, 
            self.arc_vars
        )
        
        for i in range(self.num_rows):
            for j in range(self.num_cols):
                if self.region_grid.value(i, j) not in "@#x":
                    self.model.Add(self.node_active[Position(i, j)] == 1)
                else:
                    self.model.Add(self.node_active[Position(i, j)] == 0)
                # All node must be visited, except those marked `not visited` with @#x
    
    def _add_region_constr(self):
        
        for region_id, borders in self.region_grid.region_borders.items():
            if region_id not in "@#x":
                self.model.Add(sum(self.arc_vars[(u, v)] for (u, v) in borders) == 4)
                
    def get_solution(self):
        sol_grid = [["-" for _ in range(self.num_cols)] for _ in range(self.num_rows)]
        
        for i in range(self.num_rows):
            for j in range(self.num_cols):
                curr = Position(i, j)
                # If the node is not activated (self-looped), skip and remain '-'
                if self.solver.Value(self.node_active[curr]) == 0:
                    continue
                neighbors = self.region_grid.get_neighbors(curr, "orthogonal")
                chs = ""
                for neighbor in neighbors:
                    if neighbor == curr.up and self.solver.Value(self.arc_vars[(neighbor, curr)]) == 1:
                        chs += "n"
                    if neighbor == curr.left and self.solver.Value(self.arc_vars[(neighbor, curr)]) == 1:
                        chs += "w"
                    if neighbor == curr.down and self.solver.Value(self.arc_vars[(curr, neighbor)]) == 1:
                        chs += "s"
                    if neighbor == curr.right and self.solver.Value(self.arc_vars[(curr, neighbor)]) == 1:
                        chs += "e"
                if len(chs) > 0:
                    sol_grid[i][j] = "".join(sorted(chs))

        return Grid(sol_grid)