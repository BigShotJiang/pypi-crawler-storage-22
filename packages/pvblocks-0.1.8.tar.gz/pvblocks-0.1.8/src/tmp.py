# The format is <c>000000XX-0000-0000-00YY-000000000000</c>, where XX is the board nr and YY is the usb nr.
# Board nrs start from 101, usb nrs from 0.
# Example Guids are:
# <c>00000065-0000-0000-0000-000000000000</c> (block 0 of board 0, address 101, 0x65; usb 0)
# <c>00000065-0000-0000-0001-000000000000</c> (block 0 of board 0, address 101, 0x65; usb 1)
# <c>00000069-0000-0000-0002-000000000000</c> (block 4 of board 0, address 105, 0x69; usb 2)
# <c>00000084-0000-0000-0002-000000000000</c> (block 7 of board 3, address 133, 0x84; usb 2)


def extract_hex_values(guid_string):
    xx = guid_string[6:8]
    yy = guid_string[21:23]
    return int(xx, 16), int(yy, 16)


# (usb nr, board nr, channel nr), with slotnr = None for a temperature sensor
def GetPosition(guid_string):
    (BlockNr, UsbNr) = extract_hex_values(guid_string)

    if BlockNr > 100:
        return (UsbNr, int((BlockNr -101)/8), (BlockNr -101)%8)

    return (UsbNr, BlockNr-64, None)


# --- Usage Example ---
input_str = "00000040-0000-0000-0002-000000000000"
result = GetPosition(input_str)

print(f"UsbNr: {result[0]}")
print(f"BlockNr: {result[1]}")
print(f"SlotNr: {result[2]}")
print(f"Tuple: {result}")