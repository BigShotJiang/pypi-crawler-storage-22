"""Init PVoutput library"""

from .pvoutput import *  # noqa

__version__ = 0.1
