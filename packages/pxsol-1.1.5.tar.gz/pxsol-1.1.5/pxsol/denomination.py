lamport = 1
sol = 1000000000
