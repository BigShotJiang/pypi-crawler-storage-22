# Hello Solana Program

## Build

```sh
$ git clone https://github.com/solana-developers/program-examples
$ cd program-examples/basics/hello-solana/pinocchio
$ cargo build-sbf --manifest-path=./program/Cargo.toml --sbf-out-dir=./program/target/so
```
