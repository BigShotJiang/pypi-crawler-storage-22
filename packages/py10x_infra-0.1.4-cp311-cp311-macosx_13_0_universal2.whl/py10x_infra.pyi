"""
10x infra
"""
from __future__ import annotations
__all__: list[str] = ['MongoCollectionHelper']
class MongoCollectionHelper:
    @staticmethod
    def prepare_filter_and_pipeline(arg0: dict, arg1: dict, arg2: list) -> None:
        ...
