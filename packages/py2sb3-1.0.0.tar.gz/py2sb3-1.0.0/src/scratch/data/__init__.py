# This file marks the data directory as a Python package for resource loading
