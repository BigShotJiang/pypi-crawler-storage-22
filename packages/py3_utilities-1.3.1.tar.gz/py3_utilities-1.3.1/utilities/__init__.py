"""
project_utils: Shared utilities for configuration and logging.
"""
__all__ = []

# Import Config parser and writer
try:
    from .config import parse_config, write_config
    __all__.append("parse_config")
    __all__.append("write_config")
except (ImportError, ModuleNotFoundError):
    pass

# Import Logger module
try:
    from .logging import Logger, LogDecorator, LogWrapper, init_logging
    __all__.append("Logger")
    __all__.append("LogDecorator")
    __all__.append("LogWrapper")
    __all__.append("init_logging")
except (ImportError, ModuleNotFoundError):
    pass

# Import Gitlab utils
try:
    from .gitlab import GitlabClient, CommitMetadata, MergeRequestMetadata
    __all__.append("GitlabClient")
    __all__.append("CommitMetadata")
    __all__.append("MergeRequestMetadata")
except (ImportError, ModuleNotFoundError):
    pass

# Import Jira utils
try:
    from .jira import JiraClient, JiraWrapper
    __all__.append("JiraClient")
    __all__.append("JiraWrapper")
except (ImportError, ModuleNotFoundError):
    pass

# Import Excel utils
try:
    from .excel import ExcelComparer
    __all__.append("ExcelComparer")
except (ImportError, ModuleNotFoundError):
    pass

# Import OS utils
try:
    from .os import DirectoryWatcher, DirectoryChangeEvent, FileScanner, ContentScanner, TraversalMethod
    __all__.append("DirectoryWatcher")
    __all__.append("DirectoryChangeEvent")
    __all__.append("FileScanner")
    __all__.append("ContentScanner")
    __all__.append("TraversalMethod")
except (ImportError, ModuleNotFoundError):
    pass

# Import Teams module
try:
    from .teams import TeamsClient
    __all__.append("TeamsClient")
except (ImportError, ModuleNotFoundError):
    pass

# Import AI utils
try:
    from .ai import OpenAIChatClient, ChatClientError
    from .ai.providers import BaseChatProvider, CompletionResult, ProviderError, DeepInfraProvider, AzureOpenAIProvider

    # OpenAI API compatible chat client
    __all__.append("OpenAIChatClient")
    __all__.append("ChatClientError")

    # Providers
    __all__.append("BaseChatProvider")
    __all__.append("CompletionResult")
    __all__.append("ProviderError")
    __all__.append("DeepInfraProvider")
    __all__.append("AzureOpenAIProvider")
except (ImportError, ModuleNotFoundError):
    pass
