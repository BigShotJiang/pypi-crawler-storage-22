import json
import logging
import time
import tempfile
import os
import asyncio
import aiohttp
import openai
import inspect
import re
import base64
import mimetypes
import pathlib

from urllib.parse import urlparse
from typing import Any, Callable, Awaitable, Optional, Dict, Mapping, Union, List

from ..utility_base import UtilityBase
from ..logging import Logger, LogWrapper
from .providers import BaseChatProvider, ProviderError


ToolCallable = Union[
    Callable[..., Any],
    Callable[..., Awaitable[Any]],
]


# Define exceptions
class ChatClientError(Exception):
    """Custom exception for OpenAIChatClient errors."""
    pass


class OpenAIChatClient(UtilityBase):
    """
    A wrapper for interacting with an async chat provider (e.g., Azure OpenAI) with:
      - session-based message history
      - optional on-disk persistence
      - tool/function calling loop
      - optional multimodal file attachments (images embedded; non-images converted to text)

    Notes:
        - This class delegates the actual model call to `provider.complete(...)`.
        - `request_completion()` must not be called from inside a running event loop.

    Examples:
        >>> # provider must implement BaseChatProvider.complete(...)
        >>> provider = ...  
        >>> client = OpenAIChatClient(provider)  
        >>> client.request_completion("Hello")  
        '...'
    """
    SESSION_DIR = ".sessions"

    def __init__(
            self,
            provider: BaseChatProvider,
            *,
            default_system_message: str = "You are a helpful assistant.",
            max_tokens: int = 4000,
            temperature: float = 0.0,
            top_p: float = 0.95,
            frequency_penalty: float = 0.0,
            presence_penalty: float = 0.0,
            include_message_history: bool = True,
            save_sessions_to_disk: bool = True,
            verbose: bool = False,
            log_messages: bool = False,
            logger: logging.Logger | Logger | LogWrapper | None = None,
            log_level: Optional[int] = None,
            store_tool_messages: bool = False,
            strip_thinking: bool = False,
            thinking_tag_patterns: Optional[list[str]] = None
        ):
        """
        Initialize the client and (optionally) load persisted sessions from disk.

        Args:
            provider (BaseChatProvider): Provider implementation responsible for model calls.
            default_system_message (str, optional): Default system prompt. Defaults to "You are a helpful assistant.".
            max_tokens (int, optional): Maximum tokens for the response. Defaults to 4000.
            temperature (float, optional): Sampling temperature for randomness. Defaults to 0.0.
            top_p (float, optional): Nucleus sampling parameter. Defaults to 0.95.
            frequency_penalty (float, optional): Penalize repeated tokens. Defaults to 0.0.
            presence_penalty (float, optional): Penalize repeated topics. Defaults to 0.0.
            include_message_history (bool, optional): Include full session history in requests. Defaults to True.
            save_sessions_to_disk (bool, optional): Persist session histories under `SESSION_DIR`. Defaults to True.
            verbose (bool, optional): Enable debug logging (via UtilityBase). Defaults to False.
            log_messages (bool, optional): Log user/system messages. Defaults to False.
            logger (Optional[Union[logging.Logger, Logger, LogWrapper]]): Logger instance. If None, UtilityBase default is used.
            log_level (Optional[int], optional): Log level. If None, UtilityBase default is used.
            store_tool_messages (bool, optional): Persist tool-call traces into session history. Defaults to False.
            strip_thinking (bool, optional): Strip "thinking" tags from inputs/outputs. Defaults to False.
            thinking_tag_patterns (Optional[list[str]], optional): Regex patterns to strip. Defaults to common <think> variants.

        Returns:
            None

        Raises:
            OSError: If session directory creation or session loading fails (when `save_sessions_to_disk=True`).
            json.JSONDecodeError: If a persisted session JSON file is malformed.
            Exception: Any unexpected errors raised by UtilityBase initialization or filesystem operations.

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=False)  
            >>> client.get_message_count()  
            1
        """
        # Init base class
        super().__init__(verbose, logger, log_level)
        self.log_messages = log_messages

        # Model configuration
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.top_p = top_p
        self.frequency_penalty = frequency_penalty
        self.presence_penalty = presence_penalty

        # Client configuration
        self.max_tool_rounds = 8
        self.tools: Dict[str, ToolCallable] = {}
        self.tool_schemas: List[dict] = []
        self.include_message_history = include_message_history
        self.default_system_message = {"role": "system", "content": default_system_message}
        self.store_tool_messages = store_tool_messages

        self.strip_thinking = strip_thinking
        self.thinking_tag_patterns = thinking_tag_patterns or [
            r"<think>.*?</think>",          # common
            r"<thinking>.*?</thinking>",    # some models
        ]
        self._thinking_re = re.compile("|".join(self.thinking_tag_patterns), re.DOTALL | re.IGNORECASE)

        # Provider Client
        self.async_client = provider

        # Session locks (guards session mutation + disk writes)
        self._session_locks: Dict[str, asyncio.Lock] = {}

        # Initialize storage
        self.save_sessions_to_disk = save_sessions_to_disk
        if save_sessions_to_disk:
            os.makedirs(self.SESSION_DIR, exist_ok=True)
            self._load_all_sessions_from_disk()
        else:
            self.sessions = {}

        # Ensure locks exist for loaded sessions
        for sid in self.sessions.keys():
            self._session_locks.setdefault(sid, asyncio.Lock())

        self._log(f"ChatClient initialized successfully. Conversation history {'enabled' if include_message_history else 'disabled'}.")

    def register_tool(
        self,
        *,
        schema: Mapping[str, Any],
        func: ToolCallable,
        name: Optional[str] = None,
        max_tool_rounds: Optional[int] = None,
        overwrite: bool = True,
        insert_front: bool = False,
    ) -> str:
        """
        Register a tool/function for model tool-calling.

        This stores:
          - the OpenAI-compatible tool schema (used in request payloads)
          - the callable implementation (sync or async)

        Args:
            schema (Mapping[str, Any]): OpenAI-compatible tool schema dict:
                {
                  "type": "function",
                  "function": {
                    "name": "...",
                    "description": "...",
                    "parameters": {...json schema...}
                  }
                }
            func (ToolCallable): Callable to execute (sync or async). Accepts **kwargs matching schema parameters.
            name (Optional[str], optional): Override tool name. If None, uses schema["function"]["name"].
            max_tool_rounds (Optional[int], optional): If provided, updates `self.max_tool_rounds`.
            overwrite (bool, optional): If False, raises if a tool with same name already exists. Defaults to True.
            insert_front (bool, optional): If True, inserts schema at front of tool list. Defaults to False.

        Returns:
            str: The registered tool name.

        Raises:
            ValueError: If `schema` is not a mapping; `func` is not callable; schema shape is invalid; tool name invalid;
                        overwrite is False and tool already exists; or `max_tool_rounds` is not a positive integer.

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider)  
            >>> schema = {  
            ...     "type": "function",
            ...     "function": {
            ...         "name": "add",
            ...         "description": "Add two integers",
            ...         "parameters": {
            ...             "type": "object",
            ...             "properties": {"a": {"type": "integer"}, "b": {"type": "integer"}},
            ...             "required": ["a", "b"],
            ...         },
            ...     },
            ... }
            >>> def add(a: int, b: int) -> int:  
            ...     return a + b
            >>> client.register_tool(schema=schema, func=add)  
        """
        if not isinstance(schema, Mapping):
            raise ValueError("schema must be a mapping/dict.")
        if not callable(func):
            raise ValueError("func must be callable.")

        # Validate schema shape
        schema_type = schema.get("type")
        fn_block = schema.get("function")
        if schema_type != "function" or not isinstance(fn_block, Mapping):
            raise ValueError("schema must be OpenAI-compatible with type='function' and a 'function' object.")

        schema_name = fn_block.get("name")
        tool_name = (name or schema_name)
        if not tool_name or not isinstance(tool_name, str):
            raise ValueError("Tool name must be a non-empty string (either pass name= or set schema['function']['name']).")

        # Update tool rounds cap if requested
        if max_tool_rounds is not None:
            if not isinstance(max_tool_rounds, int) or max_tool_rounds <= 0:
                raise ValueError("max_tool_rounds must be a positive integer.")
            self.max_tool_rounds = max_tool_rounds

        # Register callable
        if (not overwrite) and (tool_name in self.tools):
            raise ValueError(f"Tool '{tool_name}' is already registered (overwrite=False).")
        self.tools[tool_name] = func

        # Ensure schema name matches tool_name
        schema_copy = dict(schema)
        fn_copy = dict(fn_block)
        fn_copy["name"] = tool_name
        schema_copy["function"] = fn_copy

        # Upsert schema: replace existing schema with same function.name, else add
        replaced = False
        for i, existing in enumerate(self.tool_schemas):
            try:
                ex_fn = existing.get("function", {})
                ex_name = ex_fn.get("name")
            except Exception:
                ex_name = None

            if ex_name == tool_name:
                self.tool_schemas[i] = schema_copy
                replaced = True
                break

        if not replaced:
            if insert_front:
                self.tool_schemas.insert(0, schema_copy)
            else:
                self.tool_schemas.append(schema_copy)

        return tool_name

    def request_completion(
            self,
            message_content: str,
            session_id: Optional[str] = None,
            timeout: int = 30,
            retries: int = 3,
            retry_delay: float = 2.0,
            files: Optional[list[str]] = None,
            drop_files_from_history: bool = False,
        ) -> str:
        """
        Send a message and return the model response (synchronous helper).

        Important:
            Do not call this method from inside a running event loop.
            Use `request_completion_async()` instead.

        Args:
            message_content (str): User message to send.
            session_id (Optional[str], optional): Session ID. Defaults to None ("default").
            timeout (int, optional): Request timeout seconds (also used for URL file fetch). Defaults to 30.
            retries (int, optional): Number of retry attempts for transient failures. Defaults to 3.
            retry_delay (float, optional): Base delay between retries (exponential backoff). Defaults to 2.0.
            files (Optional[list[str]], optional): Optional list of local file paths and/or http(s) URLs to attach.
                Images are embedded as data URLs; non-images are converted to text by `_extract_text_from_bytes(...)`.
            drop_files_from_history (bool, optional): If True, removes file blocks from stored history. Defaults to False.

        Returns:
            str: The assistant's final response text for this turn.

        Raises:
            ValueError: If `message_content` is empty.
            ChatClientError: If called from a running event loop; or if all retries fail.
            ProviderError: If the underlying provider raises a provider-specific error (may be wrapped depending on path).
            aiohttp.ClientResponseError: For HTTP status errors while fetching URL attachments (may be wrapped depending on path).
            aiohttp.ClientConnectionError: For network/connectivity errors while fetching URL attachments (may be wrapped).
            Exception: Any unexpected error from the request path (may be wrapped in ChatClientError on final retry).

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=False)  
            >>> client.request_completion("Hello", session_id="demo")  
            '...'
        """
        if not message_content.strip():
            raise ValueError("Message content cannot be empty.")

        try:
            asyncio.get_running_loop()
            raise ChatClientError("request_completion() cannot be used inside a running event loop; use request_completion_async().")
        except RuntimeError:
            pass

        # Request a completion, try it again "retries" times, if it fails
        for attempt in range(retries):
            try:
                response = asyncio.run(self._request_completion(message_content, session_id, timeout, files, drop_files_from_history))
                return response
            except Exception as e:
                self._log_exception(e)
                self._log_warning(f"Attempt {attempt + 1} failed. Retrying in {retry_delay * (2 ** attempt):.2f} seconds...")
                time.sleep(retry_delay * (2 ** attempt))

                if (attempt + 1) == retries:
                    raise ChatClientError("Failed to complete the request after multiple retries.") from e

    async def request_completion_async(
            self,
            message_content: str,
            session_id: Optional[str] = None,
            timeout: int = 30,
            retries: int = 3,
            retry_delay: float = 2.0,
            files: Optional[list[str]] = None,
            drop_files_from_history: bool = False,
        ) -> str:
        """
        Send a message and return the model response (async).

        Args:
            message_content (str): User message to send.
            session_id (Optional[str], optional): Session ID. Defaults to None ("default").
            timeout (int, optional): Request timeout seconds (also used for URL file fetch). Defaults to 30.
            retries (int, optional): Number of retry attempts for transient failures. Defaults to 3.
            retry_delay (float, optional): Base delay between retries (exponential backoff). Defaults to 2.0.
            files (Optional[list[str]], optional): Optional list of local file paths and/or http(s) URLs to attach.
                Images are embedded as data URLs; non-images are converted to text by `_extract_text_from_bytes(...)`.
            drop_files_from_history (bool, optional): If True, removes file blocks from stored history. Defaults to False.

        Returns:
            str: The assistant's final response text for this turn.

        Raises:
            ValueError: If `message_content` is empty.
            ChatClientError: If the request fails after all retries.
            ProviderError: If the underlying provider raises a provider-specific error.
            aiohttp.ClientResponseError: For HTTP status errors while fetching URL attachments (may be wrapped).
            aiohttp.ClientConnectionError: For network/connectivity errors while fetching URL attachments (may be wrapped).
            asyncio.TimeoutError: If the request or URL attachment fetch exceeds `timeout` (may be wrapped depending on path).
            Exception: Any unexpected error from the request path (may be wrapped in ChatClientError on final retry).

        Examples:
            >>> import asyncio  
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=False)  
            >>> async def demo():  
            ...     return await client.request_completion_async("Hello", session_id="demo")
            >>> asyncio.run(demo())  
            '...'
        """
        if not message_content.strip():
            raise ValueError("Message content cannot be empty.")

        for attempt in range(retries):
            try:
                response = await self._request_completion(message_content, session_id, timeout, files, drop_files_from_history)
                return response
            except Exception as e:
                self._log_warning(f"Attempt {attempt + 1} failed. Retrying in {retry_delay * (2 ** attempt):.2f} seconds...")
                await asyncio.sleep(retry_delay * (2 ** attempt))

                if (attempt + 1) == retries:
                    raise ChatClientError("Failed to complete the request after multiple retries.") from e

    def trim_conversation_history(self, session_id: Optional[str] = None, max_length: int = 50) -> None:
        """
        Trim stored conversation history to the last `max_length` conversational messages.

        This keeps:
          - the system message at index 0
          - the most recent `max_length` of user + final assistant messages

        It drops tool traces and assistant(tool_calls) messages, regardless of `store_tool_messages`.

        Args:
            session_id (Optional[str], optional): Session ID. Defaults to None ("default").
            max_length (int, optional): Maximum number of conversational messages to retain. Defaults to 50.

        Returns:
            None

        Raises:
            ValueError: If `max_length` is not a positive integer.
            OSError: If persisting the trimmed session to disk fails.
            json.JSONEncodeError: If session cannot be serialized (rare; would indicate invalid message objects).
            Exception: Any unexpected error from validation or persistence.

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=False)  
            >>> client.trim_conversation_history("default", max_length=10)  
        """
        if max_length <= 0:
            raise ValueError("`max_length` must be a positive integer.")

        session_id = self._validate_session(session_id)
        sys_msg = self.sessions[session_id][:1]
        rest = self.sessions[session_id][1:]
        self._log(f"Trimming conversation history for session `{session_id}`")

        # Keep only conversational messages (user + final assistant), drop tool + assistant(tool_calls)
        convo = [
            m for m in rest
            if m.get("role") in ("user", "assistant") and "tool_calls" not in m
        ]

        self.sessions[session_id] = sys_msg + convo[-max_length:]
        self._save_session_to_disk(session_id)

    def get_message_count(self, session_id: Optional[str] = None) -> int:
        """
        Return the number of stored messages in a session (including the system message).

        Args:
            session_id (Optional[str], optional): Session ID. Defaults to None ("default").

        Returns:
            int: Total number of messages stored for the session.

        Raises:
            OSError: If session initialization tries to persist and fails (when disk persistence is enabled).
            Exception: Any unexpected error during session validation/creation.

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=False)  
            >>> client.get_message_count()  
            1
        """
        session_id = self._validate_session(session_id)

        return len(self.sessions[session_id])

    def change_system_message(self, system_message: str, session_id: Optional[str] = None) -> None:
        """
        Replace the session's system message (message 0) and persist it.

        Args:
            system_message (str): New system message content.
            session_id (Optional[str], optional): Session ID. Defaults to None ("default").

        Returns:
            None

        Raises:
            ValueError: If `system_message` is empty/whitespace.
            OSError: If persisting the updated session fails.
            Exception: Any unexpected error from session validation or persistence.

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=False)  
            >>> client.change_system_message("Be concise.", session_id="default")  
        """
        if not system_message.strip():
            raise ValueError("System message cannot be empty.")

        session_id = self._validate_session(session_id)

        if self.log_messages:
            self._log(f"Changing system message for session `{session_id}`. New system message: `{system_message}`")

        new_system_message: Dict[str, str] = {"role": "system", "content": system_message}
        self.sessions[session_id][0] = new_system_message

        # Persist the updated system message to disk (atomic in _save_session_to_disk)
        self._save_session_to_disk(session_id)

    def get_conversation_history_as_text(self, session_id: Optional[str] = None) -> str:
        """
        Return the session history as a plain-text transcript.

        The transcript joins messages as:
            "<Role>: <content>\\n"

        For multimodal user messages (where `content` is a list of blocks), only text blocks are included.
        Image blocks are replaced with a placeholder.

        Args:
            session_id (Optional[str], optional): Session ID. Defaults to None ("default").

        Returns:
            str: Plain-text transcript. Returns "" if the session has no messages.

        Raises:
            Exception: Any unexpected error during session validation.

        Examples:
            >>> provider = ...
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=False)
            >>> client.get_conversation_history_as_text("default")
            'System: ...'
        """
        session_id = self._validate_session(session_id)

        if not self.sessions[session_id]:
            return ""

        def _content_to_text(content: Any) -> str:
            # Plain string content
            if isinstance(content, str):
                return content

            # Multimodal blocks: keep only text blocks; mask others (e.g., images)
            if isinstance(content, list):
                parts: list[str] = []
                for b in content:
                    if isinstance(b, dict) and b.get("type") == "text":
                        t = b.get("text", "")
                        parts.append(t if isinstance(t, str) else str(t))
                    else:
                        parts.append("[FILE]")
                return "\n".join(p for p in parts if p)

            # Fallback
            return str(content)

        history = "\n".join(
            f"{msg.get('role', '').capitalize()}: {_content_to_text(msg.get('content'))}"
            for msg in self.sessions[session_id]
        )

        return history

    def get_conversation_history(self, session_id: Optional[str] = None) -> List[dict]:
        """
        Return the raw stored message list for a session.

        Args:
            session_id (Optional[str], optional): Session ID. Defaults to None ("default").

        Returns:
            List[dict]: The raw message objects (each message is a dict). Returns [] if the session is empty.

        Raises:
            Exception: Any unexpected error during session validation.

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=False)  
            >>> hist = client.get_conversation_history("default")  
            >>> isinstance(hist, list)  
            True
        """
        session_id = self._validate_session(session_id)

        if not self.sessions[session_id]:
            return []
        else:
            return self.sessions[session_id]

    def reset_conversation(self, session_id: Optional[str] = None) -> None:
        """
        Reset a session to only its system message (preserving the current system prompt).

        Args:
            session_id (Optional[str], optional): Session ID. Defaults to None ("default").

        Returns:
            None

        Raises:
            OSError: If persisting the reset session fails.
            Exception: Any unexpected error during session validation or persistence.

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=False)  
            >>> client.reset_conversation("default")  
        """
        session_id = self._validate_session(session_id)
        self._log(f"Resetting conversation for session `{session_id}`.")

        if len(self.sessions[session_id]) <= 1:  # Only system message exists
            self._log_warning(f"Session '{session_id}' is already at its default state.")

        self.sessions[session_id] = [self.sessions[session_id][0]]  # Preserve system message
        self._save_session_to_disk(session_id)

    def save_conversation(self, file_path: str, session_id: Optional[str] = None) -> None:
        """
        Save the session history to a JSON file at `file_path`.

        This uses an atomic write pattern (temp file + fsync + replace).

        Args:
            file_path (str): Destination path for the JSON file.
            session_id (Optional[str], optional): Session ID. Defaults to None ("default").

        Returns:
            None

        Raises:
            ValueError: If session validation fails and yields an empty session id (unlikely with current logic).
            OSError: If writing, flushing, fsync, or replacing the file fails.
            TypeError: If the session contains non-JSON-serializable objects.
            Exception: Any unexpected error during session validation or I/O.

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=False)  
            >>> client.save_conversation("chat.json", session_id="default")  
        """
        session_id = self._validate_session(session_id)
        self._log(f"Saving conversation for session `{session_id}`.")

        with tempfile.NamedTemporaryFile("w", delete=False) as tmp_file:
            json.dump(self.sessions[session_id], tmp_file)
            tmp_file.flush()
            os.fsync(tmp_file.fileno())
        os.replace(tmp_file.name, file_path)

    def load_conversation(self, file_path: str, session_id: Optional[str] = None) -> None:
        """
        Load session history from a JSON file and replace the current session state.

        If the file is missing, the session is reset to default. If JSON is invalid, a ValueError is raised.

        Args:
            file_path (str): Path to JSON file containing a list of message dicts.
            session_id (Optional[str], optional): Session ID to load into. Defaults to None ("default").

        Returns:
            None

        Raises:
            ValueError: If the loaded JSON is not a list of messages; or if the JSON format is invalid.
            FileNotFoundError: Not raised (handled internally) — missing file triggers reset.
            json.JSONDecodeError: Converted to ValueError("Invalid JSON format ...").
            OSError: If reading the file or persisting the loaded session fails.
            Exception: Any unexpected error.

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=False)  
            >>> client.load_conversation("chat.json", session_id="default")  
        """
        session_id = self._validate_session(session_id)
        self._log(f"Loading conversation for session `{session_id}`.")

        try:
            with open(file_path, 'r') as f:
                loaded_session = json.load(f)
                if not isinstance(loaded_session, list):
                    raise ValueError("Invalid conversation format. Expected a list of messages.")

            self.sessions[session_id] = loaded_session
            self._session_locks.setdefault(session_id, asyncio.Lock())
            self._save_session_to_disk(session_id)
        except FileNotFoundError:
            self._log_warning(f"File '{file_path}' not found. Starting a fresh session for '{session_id}'.")
            self.reset_conversation(session_id)
        except json.JSONDecodeError:
            raise ValueError("Invalid JSON format in the conversation file.")
        except Exception as e:
            raise e

    async def _request_completion(
        self,
        message_content: str,
        session_id: str,
        timeout: int,
        files: Optional[list[str]] = None,
        drop_files_from_history: bool = False,
    ) -> str:
        """
        Internal async request handler.

        Responsibilities:
          - validate/init session
          - optionally strip thinking tags from input
          - build multimodal content blocks when `files` are provided
          - run the provider completion call
          - handle tool calling loop (append assistant tool_calls + tool results, then re-call)
          - strip thinking tags from final output (optional)
          - persist session history (depending on config)

        Args:
            message_content (str): User message (may be str or turned into multimodal blocks).
            session_id (str): Session identifier (validated/created via `_validate_session`).
            timeout (int): Timeout for provider call and URL attachment fetching.
            files (Optional[list[str]], optional): Local paths and/or http(s) URLs.
                - images => embedded as data URLs
                - non-images => converted to text via `_extract_text_from_bytes(...)`
            drop_files_from_history (bool, optional): If True, removes file blocks from stored history.

        Returns:
            str: Final assistant response text for this turn (no tool calls pending).

        Raises:
            ChatClientError: If tool call rounds exceed `max_tool_rounds`.
            ProviderError: If the provider raises a provider-specific error.
            asyncio.TimeoutError: If the provider call or URL fetching times out.
            aiohttp.ClientResponseError: For non-2xx responses when fetching URL attachments.
            aiohttp.ClientConnectionError: For network/connectivity errors when fetching URL attachments.
            ValueError: For invalid input encountered in validation paths (e.g., invalid session id in persistence).
            Exception: Any other unexpected error.

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=False)  
            >>> # Direct call is internal; use request_completion_async in practice.  
            >>> await client._request_completion("Hi", "default", timeout=30)  
            '...'
        """
        session_id = self._validate_session(session_id)
        lock = self._session_locks.setdefault(session_id, asyncio.Lock())

        async with lock:
            if self.log_messages:
                self._log(f"Requesting completion for session `{session_id}`. Message `{message_content}`")

            if self.sessions[session_id][0].get("role") != "system":
                self.sessions[session_id].insert(0, self.default_system_message)

            message_content = self._strip_thinking_tags(message_content)

            # --- Build multimodal message content if files are provided ---
            content: object = message_content
            if files:
                blocks: list[dict[str, Any]] = [{"type": "text", "text": message_content}]

                for ref in files:
                    is_url = urlparse(ref).scheme in ("http", "https")

                    if is_url:
                        async with aiohttp.ClientSession() as s:
                            async with s.get(ref, timeout=timeout) as r:
                                r.raise_for_status()

                                data = await r.read()
                                mime = (r.headers.get("Content-Type") or "").split(";")[0].strip()
                                
                                if not mime:
                                    mime = "application/octet-stream"
                    else:
                        p = pathlib.Path(ref)
                        data = p.read_bytes()
                        mime, _ = mimetypes.guess_type(str(p))
                        mime = mime or "application/octet-stream"

                    if mime.startswith("image/"):
                        b64 = base64.b64encode(data).decode("ascii")
                        blocks.append(
                            {
                                "type": "image_url",
                                "image_url": {"url": f"data:{mime};base64,{b64}"},
                            }
                        )
                    else:
                        # Convert to text (PDF/docx/xlsx/etc.) and send as text.
                        text = self._extract_text_from_bytes(data, mime=mime)  # you implement this
                        blocks.append({"type": "text", "text": f"[{mime}]\n{text}"})

                content = blocks

            new_message = {"role": "user", "content": content}

            # Slim message for history (no embedded file blocks)
            history_user_message = (
                {"role": "user", "content": message_content}
                if (files and drop_files_from_history)
                else new_message
            )

            turn_events = [new_message]

            # Build a safe tuple of OpenAI timeout exception types (SDK versions differ)
            openai_timeout_exc = getattr(getattr(openai, "error", object()), "Timeout", None)
            timeout_excs = (asyncio.TimeoutError,) + ((openai_timeout_exc,) if isinstance(openai_timeout_exc, type) else ())

            try:
                # Construct initial outbound messages
                if self.include_message_history:
                    messages = list(self.sessions[session_id]) + list(turn_events)
                else:
                    # Still include the current session's system message for consistent behavior.
                    sys_msg = self.sessions[session_id][:1] if self.sessions.get(session_id) else [self.default_system_message]
                    messages = list(sys_msg) + [new_message]

                for _ in range(self.max_tool_rounds):
                    # Hand over available tools
                    if self.tools and self.tool_schemas:
                        extras = {"tools": self.tool_schemas, "tool_choice": "auto"} if self.tool_schemas else {}
                    else:
                        extras = {}

                    completion = await self.async_client.complete(
                        messages=messages,
                        temperature=self.temperature,
                        max_tokens=self.max_tokens,
                        top_p=self.top_p,
                        frequency_penalty=self.frequency_penalty,
                        presence_penalty=self.presence_penalty,
                        timeout=timeout,
                        extras=extras
                    )

                    # Tool calls requested?
                    if completion.tool_calls:
                        # 1) append assistant tool-call message to the *outbound* messages and to our turn buffer
                        assistant_tool_msg = {
                            "role": "assistant",
                            "content": completion.text or "",
                            "tool_calls": completion.tool_calls,
                        }
                        messages.append(assistant_tool_msg)
                        turn_events.append(assistant_tool_msg)

                        # 2) run tools and append tool outputs (both outbound + turn buffer)
                        for tc in completion.tool_calls:
                            name = tc.get("function", {}).get("name")
                            args_json = tc.get("function", {}).get("arguments", "{}")

                            try:
                                args = json.loads(args_json) if args_json else {}
                            except Exception:
                                self._log_warning(
                                    f"Tool '{name}' received invalid JSON arguments; falling back to empty args."
                                )
                                args = {}

                            fn = self.tools.get(name) if self.tools else None
                            if not fn:
                                tool_output = json.dumps({"error": f"Unknown tool: {name}"})
                            else:
                                try:
                                    res = fn(**args)
                                    if inspect.isawaitable(res):
                                        res = await res
                                    tool_output = res if isinstance(res, str) else json.dumps(res)
                                except Exception as e:
                                    tool_output = json.dumps({"error": str(e)})

                            tool_msg = {
                                "role": "tool",
                                "tool_call_id": tc.get("id"),
                                "content": tool_output,
                            }
                            messages.append(tool_msg)
                            turn_events.append(tool_msg)

                        # Continue: ask the model again now that tool results are appended
                        continue

                    # No tool calls -> final response for this turn
                    response = completion.text or ""
                    response = self._strip_thinking_tags(response)

                    final_assistant_msg = {"role": "assistant", "content": response}
                    turn_events.append(final_assistant_msg)

                    # Persist in correct order
                    if self.include_message_history:
                        if self.store_tool_messages:
                            to_store = list(turn_events)
                        else:
                            to_store = []
                            for m in turn_events:
                                if m.get("role") == "user":
                                    to_store.append(m)
                                elif m.get("role") == "assistant" and "tool_calls" not in m:
                                    to_store.append(m)

                         # Replace the user message we store (drop file blocks if requested)
                        if files and drop_files_from_history:
                            for i, m in enumerate(to_store):
                                if m.get("role") == "user":
                                    to_store[i] = history_user_message
                                    break
                        
                        self.sessions[session_id].extend(to_store)
                        self._save_session_to_disk(session_id)

                    return response

                # If we get here, we exceeded tool rounds without a final response.
                raise ChatClientError(
                    f"Exceeded max_tool_rounds ({self.max_tool_rounds}) without producing a final answer."
                )

            # --- Timeout from asyncio or OpenAI directly ---
            except timeout_excs as e:
                self._log_error(f"The request timed out (timeout={timeout}).")
                self._log_exception(f"Original error: {e}")
                raise

            # --- Provider-specific error types ---
            except ProviderError as e:
                self._log_exception(f"Client provider error: {e.__str__}")
                raise

            # --- aiohttp-specific HTTP/connection errors ---
            except aiohttp.ClientResponseError as e:
                self._log_exception(f"HTTP Error {e.status}: {e.message}")
                raise ChatClientError() from e
            except aiohttp.ClientConnectionError as e:
                self._log_exception(f"Connection error while accessing OpenAI API: {e}")
                raise ChatClientError() from e

            # --- General issues ---
            except ValueError as e:
                self._log_exception(f"Invalid input: {e}")
                raise
            except Exception as e:
                self._log_exception(f"An unexpected error occurred: {e}")
                raise

    def _strip_thinking_tags(self, text: str) -> str:
        """
        Strip configured "thinking" tags from a text string.

        Behavior:
            - If `self.strip_thinking` is False or text is empty, returns input unchanged.
            - Otherwise removes any matches of `self.thinking_tag_patterns` (compiled as OR-regex),
              then normalizes excessive blank lines.

        Args:
            text (str): Input text.

        Returns:
            str: Cleaned text.

        Raises:
            re.error: If the configured regex patterns are invalid (would occur at initialization/compile time).
            Exception: Any unexpected error from regex substitution (rare).

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, strip_thinking=True, save_sessions_to_disk=False)  
            >>> client._strip_thinking_tags("<think>hidden</think> visible")  
            'visible'
        """
        if not text or not self.strip_thinking:
            return text
        
        cleaned = self._thinking_re.sub("", text)

        # tidy up leftover blank lines/spaces
        cleaned = re.sub(r"\n{3,}", "\n\n", cleaned).strip()

        return cleaned

    def _load_all_sessions_from_disk(self) -> None:
        """
        Load all JSON session files from `SESSION_DIR` into memory.

        Session files are expected to be named `<session_id>.json` and contain a JSON list of message dicts.

        Returns:
            None

        Raises:
            OSError: If listing or reading session files fails.
            json.JSONDecodeError: If any session file contains invalid JSON.
            Exception: Any unexpected error during loading.

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=True)  
            >>> client._load_all_sessions_from_disk()  
        """
        self.sessions = {}

        for filename in os.listdir(self.SESSION_DIR):
            if filename.endswith(".json"):
                session_id = filename[:-5]  # Remove '.json'

                with open(os.path.join(self.SESSION_DIR, filename), "r") as file:
                    self.sessions[session_id] = json.load(file)

    def _save_session_to_disk(self, session_id: str) -> None:
        """
        Persist a session to disk as JSON using an atomic write.

        No-op when:
            - `self.save_sessions_to_disk` is False, or
            - `self.include_message_history` is False.

        Args:
            session_id (str): Session identifier.

        Returns:
            None

        Raises:
            ValueError: If `session_id` is empty/whitespace.
            OSError: If writing/flushing/fsync/replacing the file fails.
            TypeError: If session content is not JSON-serializable.
            Exception: Any unexpected error.

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=True)  
            >>> client._save_session_to_disk("default")  
        """
        if not self.save_sessions_to_disk or not self.include_message_history:
            return

        if not session_id.strip():
            raise ValueError("Session ID cannot be empty.")

        filepath = os.path.join(self.SESSION_DIR, f"{session_id}.json")

        # Atomic write (temp file + fsync + replace) to avoid corrupted JSON on crash.
        with tempfile.NamedTemporaryFile("w", delete=False, dir=self.SESSION_DIR) as tmp_file:
            json.dump(self.sessions[session_id], tmp_file)
            tmp_file.flush()
            os.fsync(tmp_file.fileno())
            tmp_name = tmp_file.name

        os.replace(tmp_name, filepath)

    def _validate_session(self, session_id: Optional[str] = None) -> str:
        """
        Validate a session ID and ensure the session exists.

        If `session_id` is None, uses "default". If the session does not exist yet, initializes it
        with the current `default_system_message` and persists it (if configured).

        Also ensures an asyncio.Lock exists for the session.

        Args:
            session_id (Optional[str], optional): Session ID or None. Defaults to None.

        Returns:
            str: A valid session ID (never None).

        Raises:
            OSError: If a new session must be persisted and disk operations fail.
            ValueError: If persistence is enabled and the derived session id is empty (unlikely with current defaulting).
            Exception: Any unexpected error.

        Examples:
            >>> provider = ...  
            >>> client = OpenAIChatClient(provider, save_sessions_to_disk=False)  
            >>> client._validate_session("default")  
        """
        session_id = session_id or "default"

        # Ensure lock exists even before creating the session.
        self._session_locks.setdefault(session_id, asyncio.Lock())

        if session_id not in self.sessions:
            self.sessions[session_id] = [self.default_system_message]
            self._save_session_to_disk(session_id)

        return session_id
