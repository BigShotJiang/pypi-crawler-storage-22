from __future__ import annotations

from typing import Any, Mapping, Optional
from openai import AsyncAzureOpenAI

from .base_chat_provider import (
    BaseChatProvider, 
    Messages, 
    CompletionResult,
    ProviderError
)


class AzureOpenAIProvider(BaseChatProvider):
    """
    Azure OpenAI chat-completions provider using the OpenAI Python SDK (AsyncAzureOpenAI).

    Notes:
      - In Azure, `model` is typically your *deployment name*.
      - This provider assumes OpenAI-style message format:
        ``[{"role": "...", "content": "..."}]``

    Examples:
        >>> provider = AzureOpenAIProvider(
        ...     azure_endpoint="https://example-resource.openai.azure.com/",
        ...     api_key="***",
        ...     api_version="2024-02-15-preview",
        ...     model="my-deployment",
        ... )
        >>> # Use inside an async context / event loop:
        >>> # text = (await provider.complete([{"role": "user", "content": "Hello"}])).text

    """

    PROVIDER_NAME = "azure_openai"

    def __init__(
        self,
        *,
        azure_endpoint: str,
        api_key: str,
        api_version: str,
        model: str,
        default_max_tokens: int = 4000,
        default_temperature: float = 0.0,
        default_top_p: float = 0.95,
        default_frequency_penalty: float = 0.0,
        default_presence_penalty: float = 0.0,
    ) -> None:
        """
        Initialize the Azure OpenAI provider.

        Args:
            azure_endpoint: Azure OpenAI resource endpoint (e.g. ``https://<resource>.openai.azure.com/``).
            api_key: Azure OpenAI API key.
            api_version: Azure OpenAI API version string.
            model: Azure OpenAI deployment name (used as ``model`` in requests).
            default_max_tokens: Default ``max_tokens`` used when not overridden per-call.
            default_temperature: Default ``temperature`` used when not overridden per-call.
            default_top_p: Default ``top_p`` used when not overridden per-call.
            default_frequency_penalty: Default ``frequency_penalty`` used when not overridden per-call.
            default_presence_penalty: Default ``presence_penalty`` used when not overridden per-call.

        Raises:
            ValueError: If any of ``azure_endpoint``, ``api_key``, ``api_version``, or ``model`` is empty.

        Examples:
            >>> provider = AzureOpenAIProvider(
            ...     azure_endpoint="https://example-resource.openai.azure.com/",
            ...     api_key="***",
            ...     api_version="2024-02-15-preview",
            ...     model="my-deployment",
            ... )
        """
        if not azure_endpoint or not api_key or not api_version or not model:
            raise ValueError("azure_endpoint, api_key, api_version, and model are required.")

        self.model = model

        self._defaults = {
            "max_tokens": default_max_tokens,
            "temperature": default_temperature,
            "top_p": default_top_p,
            "frequency_penalty": default_frequency_penalty,
            "presence_penalty": default_presence_penalty,
        }

        self._client = AsyncAzureOpenAI(
            azure_endpoint=azure_endpoint,
            api_key=api_key,
            api_version=api_version,
        )

    async def complete(
        self,
        messages: Messages,
        *,
        timeout: Optional[float] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        extras: Optional[Mapping[str, Any]] = None,
    ) -> CompletionResult:
        """
        Create a chat completion using the configured Azure OpenAI deployment.

        This method merges provider defaults with per-call overrides and forwards the
        request to ``AsyncAzureOpenAI.chat.completions.create``.

        Args:
            messages: Sequence of OpenAI-style message dicts (e.g. ``{"role": "user", "content": "..."}``).
            timeout: Optional request timeout forwarded to the SDK.
            max_tokens: Override for ``max_tokens``.
            temperature: Override for ``temperature``.
            top_p: Override for ``top_p``.
            frequency_penalty: Override for ``frequency_penalty``.
            presence_penalty: Override for ``presence_penalty``.
            extras: Optional extra request parameters merged into the outgoing request.

        Returns:
            CompletionResult: An object containing:
                - ``text``: The assistant message content (trimmed; empty string if missing).
                - ``raw``: The SDK completion object.
                - ``model``: Model identifier from the SDK response (if present).
                - ``finish_reason``: Finish reason from the first choice (if present).
                - ``usage``: Best-effort usage dict (or ``None`` if unavailable).
                - ``tool_calls``: Best-effort normalized tool call list (or ``None``).

        Raises:
            ProviderError: If ``messages`` is empty, or if the underlying SDK call fails.
                The raised error includes best-effort retryability hints and (when available)
                an HTTP status code.

        Examples:
            >>> provider = AzureOpenAIProvider(
            ...     azure_endpoint="https://example-resource.openai.azure.com/",
            ...     api_key="***",
            ...     api_version="2024-02-15-preview",
            ...     model="my-deployment",
            ... )
            >>> # Inside an async function / event loop:
            >>> # result = await provider.complete([{"role": "user", "content": "Say hi"}])
            >>> # result.text
        """
        if not messages:
            raise ProviderError(
                "messages cannot be empty",
                retryable=False,
                provider=self.PROVIDER_NAME,
            )

        # Merge defaults with per-call overrides
        req = {
            "model": self.model,
            "messages": list(messages),
            "max_tokens": self._defaults["max_tokens"] if max_tokens is None else max_tokens,
            "temperature": self._defaults["temperature"] if temperature is None else temperature,
            "top_p": self._defaults["top_p"] if top_p is None else top_p,
            "frequency_penalty": self._defaults["frequency_penalty"] if frequency_penalty is None else frequency_penalty,
            "presence_penalty": self._defaults["presence_penalty"] if presence_penalty is None else presence_penalty,
        }

        if timeout is not None:
            req["timeout"] = timeout

        if extras:
            req |= dict(extras)

        try:
            completion = await self._client.chat.completions.create(**req)

            # OpenAI SDK shape: choices[0].message.content
            choice0 = completion.choices[0]
            msg = choice0.message
            text = (choice0.message.content or "").strip()

            usage = None
            # usage field varies across SDK versions; try best-effort
            if getattr(completion, "usage", None) is not None:
                # could be pydantic-like object; convert carefully
                try:
                    usage = dict(completion.usage)  # type: ignore[arg-type]
                except Exception:
                    try:
                        usage = completion.usage.model_dump()  # type: ignore[attr-defined]
                    except Exception:
                        usage = None

            tool_calls_out = None
            tc_list = getattr(msg, "tool_calls", None)

            if tc_list:
                tool_calls_out = []
                for tc in tc_list:
                    fn = getattr(tc, "function", None)
                    
                    tool_calls_out.append({
                        "id": getattr(tc, "id", ""),
                        "type": getattr(tc, "type", "function"),
                        "function": {
                            "name": getattr(fn, "name", "") if fn else "",
                            "arguments": getattr(fn, "arguments", "{}") if fn else "{}",
                        },
                    })

            return CompletionResult(
                text=text,
                raw=completion,
                model=getattr(completion, "model", None),
                finish_reason=getattr(choice0, "finish_reason", None),
                usage=usage,
                tool_calls=tool_calls_out,
            )

        except Exception as e:
            raise self._to_provider_error(e) from e

    def _to_provider_error(self, e: Exception) -> ProviderError:
        """
        Convert an SDK exception into a ProviderError.

        The OpenAI Python SDK exception surface varies by version; this method uses
        defensive heuristics (class-name and optional status codes) to populate
        retryability hints.

        Args:
            e: The exception raised by the underlying SDK.

        Returns:
            ProviderError: Normalized provider error containing:
                - message text
                - ``retryable`` hint
                - optional HTTP ``status_code``
                - provider name
                - original exception in ``cause``

        Examples:
            >>> provider = AzureOpenAIProvider(
            ...     azure_endpoint="https://example-resource.openai.azure.com/",
            ...     api_key="***",
            ...     api_version="2024-02-15-preview",
            ...     model="my-deployment",
            ... )
            >>> try:
            ...     raise RuntimeError("boom")
            ... except Exception as e:
            ...     err = provider._to_provider_error(e)
            ...     isinstance(err, ProviderError)
            True
        """
        cls = e.__class__.__name__

        # Try to extract a status code if present
        status_code = getattr(e, "status_code", None)
        if status_code is None:
            status_code = getattr(e, "status", None)

        # Heuristic retryability
        retryable = False

        # Common transient categories across SDK versions
        transient_names = {
            "APITimeoutError",
            "Timeout",
            "TimeoutError",
            "APIConnectionError",
            "ConnectionError",
            "RateLimitError",
            "InternalServerError",
            "ServiceUnavailableError",
        }
        if cls in transient_names:
            retryable = True

        # If we got a status code, use it
        if isinstance(status_code, int):
            if status_code in (408, 409, 425, 429, 500, 502, 503, 504):
                retryable = True

        # Non-retryable (auth/permission/bad request) hints
        non_retryable_names = {
            "AuthenticationError",
            "PermissionDeniedError",
            "BadRequestError",
            "InvalidRequestError",
            "NotFoundError",
            "UnprocessableEntityError",
        }
        if cls in non_retryable_names:
            retryable = False

        msg = str(e) or f"{cls} from Azure OpenAI provider"
        return ProviderError(
            msg,
            retryable=retryable,
            status_code=status_code if isinstance(status_code, int) else None,
            provider=self.PROVIDER_NAME,
            cause=e,
        )

    async def aclose(self) -> None:
        """
        Close the underlying SDK client.

        Different OpenAI SDK versions expose different close methods; this calls the
        first available of ``aclose`` or ``close`` and suppresses any exceptions.

        Returns:
            None

        Examples:
            >>> provider = AzureOpenAIProvider(
            ...     azure_endpoint="https://example-resource.openai.azure.com/",
            ...     api_key="***",
            ...     api_version="2024-02-15-preview",
            ...     model="my-deployment",
            ... )
            >>> # Inside an async function / event loop:
            >>> # await provider.aclose()
        """
        # Different SDK versions expose different close methods; best-effort.
        client = self._client
        for method_name in ("aclose", "close"):
            m = getattr(client, method_name, None)
            if callable(m):
                try:
                    res = m()
                    if hasattr(res, "__await__"):
                        await res  # type: ignore[misc]
                except Exception:
                    pass
                break
