from __future__ import annotations

from typing import Any, Mapping, Optional
from openai import AsyncOpenAI

from .base_chat_provider import (
    BaseChatProvider,
    Messages,
    CompletionResult,
    ProviderError
)


class DeepInfraProvider(BaseChatProvider):
    """
    Chat-completions provider for DeepInfra via its OpenAI-compatible API.

    This provider uses the OpenAI Python SDK with a custom ``base_url`` pointing to DeepInfra.

    Args:
        api_key: DeepInfra API key. Required.
        model: Model identifier on DeepInfra. Defaults to ``"moonshotai/Kimi-K2-Instruct"``.
        base_url: DeepInfra OpenAI-compatible base URL. Defaults to
            ``"https://api.deepinfra.com/v1/openai"``.
        default_max_tokens: Default ``max_tokens`` applied when not provided per-request.
        default_temperature: Default ``temperature`` applied when not provided per-request.
        default_top_p: Default ``top_p`` applied when not provided per-request.
        default_frequency_penalty: Default ``frequency_penalty`` applied when not provided per-request.
        default_presence_penalty: Default ``presence_penalty`` applied when not provided per-request.

    Raises:
        ValueError: If ``api_key``, ``model``, or ``base_url`` is empty.

    Examples:
        >>> provider = DeepInfraProvider(api_key="DI_KEY")
        >>> provider.model
        'moonshotai/Kimi-K2-Instruct'

        >>> provider = DeepInfraProvider(
        ...     api_key="DI_KEY",
        ...     model="moonshotai/Kimi-K2-Instruct-0905",
        ... )
        >>> provider.base_url
        'https://api.deepinfra.com/v1/openai'
    """

    PROVIDER_NAME = "deepinfra"

    def __init__(
        self,
        *,
        api_key: str,
        model: str = "moonshotai/Kimi-K2-Instruct",
        base_url: str = "https://api.deepinfra.com/v1/openai",
        default_max_tokens: int = 4000,
        default_temperature: float = 0.0,
        default_top_p: float = 0.95,
        default_frequency_penalty: float = 0.0,
        default_presence_penalty: float = 0.0,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required for DeepInfraProvider.")
        if not model:
            raise ValueError("model is required for DeepInfraProvider.")
        if not base_url:
            raise ValueError("base_url is required for DeepInfraProvider.")

        self.model = model
        self.base_url = base_url

        self._defaults = {
            "max_tokens": default_max_tokens,
            "temperature": default_temperature,
            "top_p": default_top_p,
            "frequency_penalty": default_frequency_penalty,
            "presence_penalty": default_presence_penalty,
        }

        # DeepInfra exposes an OpenAI-compatible API; the OpenAI SDK works by setting base_url.
        self._client = AsyncOpenAI(
            api_key=api_key,
            base_url=base_url,
        )

    async def complete(
        self,
        messages: Messages,
        *,
        timeout: Optional[float] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        extras: Optional[Mapping[str, Any]] = None,
    ) -> CompletionResult:
        """
        Create a chat completion using DeepInfra's OpenAI-compatible API.

        Args:
            messages: Chat messages (OpenAI-style dicts/objects) to send to the model.
                Must be non-empty.
            timeout: Optional request timeout (seconds). Passed through to the OpenAI SDK.
            max_tokens: Maximum tokens to generate. If omitted, uses the provider default.
            temperature: Sampling temperature. If omitted, uses the provider default.
            top_p: Nucleus sampling probability mass. If omitted, uses the provider default.
            frequency_penalty: Frequency penalty. If omitted, uses the provider default.
            presence_penalty: Presence penalty. If omitted, uses the provider default.
            extras: Extra request parameters merged into the request dict (e.g. ``tools``,
                ``tool_choice``, vendor-specific flags). If a key overlaps a built-in field,
                the value in ``extras`` wins.

        Returns:
            A :class:`CompletionResult` containing:
            - ``text``: The trimmed assistant message content from the first choice.
            - ``raw``: The raw SDK response object.
            - ``model``: Model name reported by the response (if present).
            - ``finish_reason``: Finish reason for the first choice (if present).
            - ``usage``: Token usage dict if available; otherwise ``None``.
            - ``tool_calls``: Normalized tool-call list (if present); otherwise ``None``.

        Raises:
            ProviderError: If ``messages`` is empty, or if the underlying SDK call fails.
                Network/timeouts/rate limits and many 5xx responses are marked retryable in
                the raised ``ProviderError``.
                The original exception is available as ``ProviderError.cause``.
            Exception: Any unexpected exception types encountered while parsing usage/tool calls
                are handled internally; they are not re-raised.

        Examples:
            >>> import asyncio
            >>> provider = DeepInfraProvider(api_key="DI_KEY")
            >>> async def main():
            ...     res = await provider.complete([{"role": "user", "content": "Say hi"}])
            ...     isinstance(res.text, str)
            ...     return bool(res.text)
            >>> asyncio.run(main())
            True

            >>> async def with_extras():
            ...     return await provider.complete(
            ...         [{"role": "user", "content": "Use tools"}],
            ...         extras={"tools": [{"type": "function", "function": {"name": "noop", "parameters": {}}}]},
            ...     )
            >>> asyncio.run(with_extras())
            CompletionResult(...)
        """
        if not messages:
            raise ProviderError(
                "messages cannot be empty",
                retryable=False,
                provider=self.PROVIDER_NAME,
            )

        req: dict[str, Any] = {
            "model": self.model,
            "messages": list(messages),
            "max_tokens": self._defaults["max_tokens"] if max_tokens is None else max_tokens,
            "temperature": self._defaults["temperature"] if temperature is None else temperature,
            "top_p": self._defaults["top_p"] if top_p is None else top_p,
            "frequency_penalty": self._defaults["frequency_penalty"]
            if frequency_penalty is None
            else frequency_penalty,
            "presence_penalty": self._defaults["presence_penalty"]
            if presence_penalty is None
            else presence_penalty,
        }

        # OpenAI SDK (v1+) accepts `timeout` on requests; if your pinned version differs,
        # you can alternatively configure client-level timeouts.
        if timeout is not None:
            req["timeout"] = timeout

        if extras:
            req |= dict(extras)

        try:
            completion = await self._client.chat.completions.create(**req)

            choice0 = completion.choices[0]
            msg = choice0.message
            text = (choice0.message.content or "").strip()

            usage = None
            if getattr(completion, "usage", None) is not None:
                try:
                    usage = dict(completion.usage)  # type: ignore[arg-type]
                except Exception:
                    try:
                        usage = completion.usage.model_dump()  # type: ignore[attr-defined]
                    except Exception:
                        usage = None

            tool_calls_out = None
            tc_list = getattr(msg, "tool_calls", None)

            if tc_list:
                tool_calls_out = []
                for tc in tc_list:
                    fn = getattr(tc, "function", None)
                    
                    tool_calls_out.append({
                        "id": getattr(tc, "id", ""),
                        "type": getattr(tc, "type", "function"),
                        "function": {
                            "name": getattr(fn, "name", "") if fn else "",
                            "arguments": getattr(fn, "arguments", "{}") if fn else "{}",
                        },
                    })

            return CompletionResult(
                text=text,
                raw=completion,
                model=getattr(completion, "model", None),
                finish_reason=getattr(choice0, "finish_reason", None),
                usage=usage,
                tool_calls=tool_calls_out,
            )

        except Exception as e:
            raise self._to_provider_error(e) from e

    def _to_provider_error(self, e: Exception) -> ProviderError:
        """
        Convert an exception raised by the OpenAI SDK into a :class:`ProviderError`.

        The returned ``ProviderError`` includes a best-effort ``retryable`` flag based on
        exception class names and/or HTTP status codes commonly used for transient failures.

        Args:
            e: The caught exception to convert.

        Returns:
            A :class:`ProviderError` instance with:
            - ``retryable``: ``True`` for timeouts, connection errors, rate limits, and many 5xx codes.
            - ``status_code``: Parsed HTTP status code when available; otherwise ``None``.
            - ``provider``: Always ``"deepinfra"``.
            - ``cause``: The original exception object.

        Raises:
            ProviderError: Always returns (and callers raise) a ``ProviderError``; this method itself
                does not raise under normal use.

        Examples:
            >>> p = DeepInfraProvider(api_key="DI_KEY")
            >>> err = p._to_provider_error(Exception("boom"))
            >>> isinstance(err, ProviderError)
            True
        """
        cls = e.__class__.__name__

        status_code = getattr(e, "status_code", None)
        if status_code is None:
            status_code = getattr(e, "status", None)

        retryable = False

        transient_names = {
            "APITimeoutError",
            "Timeout",
            "TimeoutError",
            "APIConnectionError",
            "ConnectionError",
            "RateLimitError",
            "InternalServerError",
            "ServiceUnavailableError",
        }
        if cls in transient_names:
            retryable = True

        if isinstance(status_code, int) and status_code in (408, 409, 425, 429, 500, 502, 503, 504):
            retryable = True

        non_retryable_names = {
            "AuthenticationError",
            "PermissionDeniedError",
            "BadRequestError",
            "InvalidRequestError",
            "NotFoundError",
            "UnprocessableEntityError",
        }
        if cls in non_retryable_names:
            retryable = False

        msg = str(e) or f"{cls} from DeepInfra provider"
        return ProviderError(
            msg,
            retryable=retryable,
            status_code=status_code if isinstance(status_code, int) else None,
            provider=self.PROVIDER_NAME,
            cause=e,
        )

    async def aclose(self) -> None:
        """
        Close the underlying OpenAI SDK client, if it exposes a close method.

        This method attempts ``aclose()`` first (async close), then falls back to ``close()``.
        Any exceptions raised during closing are suppressed.

        Returns:
            None

        Raises:
            None: Exceptions during shutdown are swallowed by design.

        Examples:
            >>> import asyncio
            >>> provider = DeepInfraProvider(api_key="DI_KEY")
            >>> asyncio.run(provider.aclose())
        """
        client = self._client
        for method_name in ("aclose", "close"):
            m = getattr(client, method_name, None)
            if callable(m):
                try:
                    res = m()
                    if hasattr(res, "__await__"):
                        await res  # type: ignore[misc]
                except Exception:
                    pass
                break
