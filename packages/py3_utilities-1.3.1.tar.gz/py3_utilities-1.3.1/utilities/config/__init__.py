import os
import sys
import warnings

from .config_parser import Config
from .config_writer import write_config
from types import SimpleNamespace
from typing import Optional, List
from pathlib import Path

__all__ = ["parse_config", "write_config"]

# Original execution path
_original_cwd: Optional[Path] = None


def _orange_warning(message, category, filename, lineno, file=None, line=None):
    """Custom warning formatter (no source line, orange text)."""
    _ORANGE = "\033[33m"
    _RESET = "\033[0m"

    stream = file if file is not None else sys.stderr
    stream.write(f"{_ORANGE}{category.__name__}: {message}{_RESET}\n")


def parse_config(
    config_paths: Optional[List[str]] = None,
    whitelist: Optional[List[str]] = None,
    switch_cwd: bool = False,
    restore_cwd: bool = False,
) -> SimpleNamespace:
    """
    Retrieve the application configuration, including YAML/JSON/TOML/INI/XML and `.env` content.

    Optionally switches the current working directory (CWD) to the main entry directory before
    loading config and optionally restores it afterwards. The original CWD is stored on the
    returned config as ``original_cwd``.

    If ``whitelist`` is provided, only config files whose name or (POSIX) path matches at least one
    whitelist pattern are included. Patterns use shell-style wildcards (fnmatch), e.g.
    ``["app.yaml", "secrets*.toml", "config/*.json"]``.

    Args:
        config_paths: Optional list of paths to project-specific config directories.
        whitelist: Optional list of filename/path patterns to include when merging config files.
        switch_cwd: If True, change the working directory to the main entry directory before loading.
        restore_cwd: If True, restore the working directory back to the original directory after loading.

    Returns:
        A namespace object with config and env values accessible via dot notation.

    Raises:
        OSError: If changing/restoring the working directory fails.

    Example:
        >>> # Basic load (default search dirs)
        >>> cfg = parse_config()
        >>> print(cfg.os.env.PATH)
        >>> ...
        >>> # Add extra config directories
        >>> cfg = parse_config(config_paths=["/etc/myapp", "./overrides"])
        >>> ...
        >>> # Only merge selected config files
        >>> cfg = parse_config(allowlist=["app.yaml", "secrets*.toml", "config/*.json"])
        >>> ...
        >>> # Switch CWD to entry directory for config discovery, then restore it
        >>> cfg = parse_config(switch_cwd=True, restore_cwd=True)
    """
    def main_dir() -> Path:
        # Frozen (Nuitka, PyInstaller, cx_Freeze)
        if getattr(sys, "frozen", False):
            # Prefer argv[0] so Nuitka onefile resolves to the real exe location
            return Path(sys.argv[0]).resolve().parent

        # Source run (script or `python -m pkg`)
        main_mod = sys.modules.get("__main__")
        if main_mod and getattr(main_mod, "__file__", None):
            return Path(main_mod.__file__).resolve().parent

        # Fallback (REPL, unusual launchers)
        return Path.cwd()

    global _original_cwd

    # Install custom warning formatting only for the duration of this call
    prev_showwarning = warnings.showwarning
    warnings.showwarning = _orange_warning
    
    try:
        # Remember original cwd
        if _original_cwd is None:
            _original_cwd = Path.cwd().resolve()

        # Switch cwd if requested
        if switch_cwd:
            target_dir = main_dir()
            if target_dir != _original_cwd:
                os.chdir(target_dir)
                new_cwd = Path.cwd().resolve()
                if new_cwd != _original_cwd:
                    warnings.warn(
                        f"Working directory changed: '{_original_cwd}' -> '{new_cwd}'.",
                        RuntimeWarning,
                        stacklevel=2,
                    )

        # Load config (single instance)
        cfg_loader = Config()
        cfg_loader.reload(config_paths, whitelist)
        cfg = cfg_loader.get()

        # Set original_cwd once (don't overwrite if already present)
        if not hasattr(cfg, "original_cwd"):
            setattr(cfg, "original_cwd", str(_original_cwd))

        # Restore cwd if requested and it actually changed
        current_cwd = Path.cwd().resolve()
        if restore_cwd and current_cwd != _original_cwd:
            os.chdir(_original_cwd)
            warnings.warn(
                f"Working directory restored: '{current_cwd}' -> '{_original_cwd}'.",
                RuntimeWarning,
                stacklevel=2,
            )

        return cfg

    finally:
        warnings.showwarning = prev_showwarning
