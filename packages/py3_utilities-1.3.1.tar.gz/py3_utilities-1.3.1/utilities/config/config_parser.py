import os
import yaml
import tomllib
import fnmatch
import json
import configparser
import warnings
import xml.etree.ElementTree as ET

from dotenv import load_dotenv
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Union, Dict, List, Optional


class Config:
    """
    Singleton configuration loader that merges environment variables and file-based settings.

    Loads environment variables from `.env` files found in common configuration directories and
    merges configuration from supported formats (`.yaml`/`.yml`, `.toml`, `.json`, `.ini`, `.xml`)
    across those directories.

    By default, it searches the following directories (in this order), plus any optional paths
    provided to :meth:`reload`:

    - current directory: `.`
    - `config`, `configuration`, `conf`, `cfg`, `env`, `environment`

    The resulting configuration is exposed as a nested :class:`types.SimpleNamespace` and includes
    an additional `os.env` namespace containing environment variables.

    Example:
        >>> cfg = Config().get()
        >>> print(cfg.database.host)
        >>> print(cfg.os.env.PATH)
        ...
        >>> # Reload after modifying config files:
        >>> Config().reload(["/opt/myapp/config"], [*.toml])
    """
    _instance = None
    _config: SimpleNamespace

    def __new__(cls) -> "Config":
        """
        Create (or return) the singleton instance and load configuration on first use.

        Returns:
            Config: The singleton :class:`Config` instance.

        Raises:
            OSError: If a configuration file cannot be opened due to an OS-level error.
            ValueError: If a configuration file has invalid syntax (e.g., malformed YAML/TOML/JSON/XML).
        """
        if cls._instance is None:
            cls._instance = super(Config, cls).__new__(cls)
            cls._instance._load()

        return cls._instance

    def _load(self, 
              config_paths: Optional[List[str]] = None, 
              whitelist: Optional[List[str]] = None
        ) -> None:
        """
        Load environment variables from `.env` files and merge configuration files.

        Environment variables are collected from :data:`os.environ` (filtered to identifier-like keys)
        and stored under `os.env` in the returned namespace from :meth:`get`.

        Configuration files are discovered by searching common directories and merging all matching
        files across supported formats. For INI files, each section becomes a top-level key.

        If ``whitelist`` is provided, only config files whose name or (POSIX) path matches at least one
        whitelist pattern are included. Patterns use shell-style wildcards (fnmatch), e.g.
        ``["app.yaml", "secrets*.toml", "config/*.json"]``.

        Args:
            config_paths: Optional list of additional directories to search for `.env` and config files.
            allwhitelistwlist: Optional list of filename/path patterns to include when merging config files.

        Raises:
            FileNotFoundError: If any provided path in ``config_paths`` does not exist (when accessed).
            PermissionError: If a configuration file cannot be read due to permissions.
            OSError: If a configuration file cannot be opened due to an OS-level error.
            ValueError: If a configuration file contains invalid syntax or cannot be parsed.
        """
        # Directories to search
        search_dirs = [Path("."), Path("config"), Path("configuration"), Path("conf"), Path("cfg"), Path("env"), Path("environment")]
        additional_search_dirs = [Path(path) for path in config_paths] if config_paths else []
        search_dirs.extend(additional_search_dirs)

        # Load .env files from all search directories (first found takes precedence)
        for search_dir in search_dirs:
            env_path = search_dir / ".env"
            if env_path.exists():
                load_dotenv(dotenv_path=env_path, override=False)

        # Map environment variables
        env_vars = {
            key: value for key, value in os.environ.items()
            if key.isidentifier()
        }
        self._env = self._dict_to_namespace(env_vars)        

        # Collect config files from all locations
        patterns = ["*.toml", "*.yaml", "*.yml", "*.json", "*.ini", "*.xml"]
        config_files = []

        for search_dir in search_dirs:
            for pattern in patterns:
                config_files.extend(sorted(search_dir.glob(pattern)))

        # Filter config files
        if whitelist:
            allowlist = [str(p) for p in whitelist]

            config_files = [
                p for p in config_files
                if any((fnmatch.fnmatch(p.as_posix(), pat) if ("/" in pat or "\\" in pat) else fnmatch.fnmatch(p.name, pat)) for pat in allowlist)
            ]

        merged_config: Dict[str, Any] = {}

        for file_path in config_files:
            try:
                if file_path.suffix == ".ini":
                    parser = configparser.ConfigParser()
                    parser.read(file_path)
                    data = {section: dict(parser[section]) for section in parser.sections()}
                else:
                    with open(file_path, "rb") as f:
                        if file_path.suffix in [".yaml", ".yml"]:
                            data = yaml.safe_load(f)
                        elif file_path.suffix == ".toml":
                            data = tomllib.load(f)
                        elif file_path.suffix == ".json":
                            data = json.load(f)
                        elif file_path.suffix == ".xml":
                            tree = ET.parse(f)
                            root = tree.getroot()
                            data = self._xml_to_dict(root)
                        else:
                            continue

                if data:
                    merged_config = self._deep_merge_dicts(merged_config, data)

            except Exception as e:
                warnings.warn(f"Skipping invalid config file '{file_path}': {e.__class__.__name__}: {e}", RuntimeWarning, stacklevel=2)
                continue

        self._config = self._dict_to_namespace(merged_config)

    def _xml_to_dict(self, elem: ET.Element) -> Dict[str, Any]:
        """
        Convert an XML element tree into a nested dictionary.

        Child elements become nested keys. Attributes are merged into the element dictionary as
        lowercase keys. If an element has text content and no children, it is stored under `"value"`.

        Args:
            elem: The XML element to convert.

        Returns:
            A dictionary representation of the XML tree rooted at ``elem``.

        Raises:
            RecursionError: If the XML structure is deeply nested beyond the recursion limit.
        """
        d = {}

        # Process children
        children = list(elem)
        if children:
            child_dict = {}
            for child in children:
                child_data = self._xml_to_dict(child)
                for k, v in child_data.items():
                    if k in child_dict:
                        if not isinstance(child_dict[k], list):
                            child_dict[k] = [child_dict[k]]
                        child_dict[k].append(v)
                    else:
                        child_dict[k] = v
            d.update(child_dict)

        # Add attributes directly
        if elem.attrib:
            d.update({k.lower(): v for k, v in elem.attrib.items()})

        # Add text content if no children
        text = elem.text.strip() if elem.text else ""
        if text and not children:
            d["value"] = text

        return {elem.tag.lower(): d or text}

    def _deep_merge_dicts(self, base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
        """
        Deep-merge two dictionaries.

        For keys present in both dictionaries:
        - if both values are dicts, merge recursively
        - otherwise, the value from ``override`` replaces the one in ``base``

        Args:
            base: Base dictionary to merge into.
            override: Dictionary containing overriding values.

        Returns:
            A new dictionary containing the merged result.
        """
        result = base.copy()

        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._deep_merge_dicts(result[key], value)
            else:
                result[key] = value

        return result

    def _dict_to_namespace(self, d: Any) -> Union[SimpleNamespace, list, Any]:
        """
        Convert dict/list structures into nested :class:`types.SimpleNamespace` objects.

        Dictionary keys are lowercased and converted to strings before being used as attributes.

        Args:
            d: Input value to convert (dict, list, or scalar).

        Returns:
            A nested structure where dictionaries become :class:`SimpleNamespace`, lists are
            converted element-wise, and non-collection values are returned unchanged.
        """
        if isinstance(d, dict):
            return SimpleNamespace(**{str(k).lower(): self._dict_to_namespace(v) for k, v in d.items()})
        elif isinstance(d, list):
            return [self._dict_to_namespace(i) for i in d]
        else:
            return d

    def get(self) -> SimpleNamespace:
        """
        Return the loaded configuration, augmented with an `os.env` namespace.

        Returns:
            A configuration namespace. The returned object contains configuration keys from merged
            config files and an additional `os.env` namespace for environment variables.

        Example:
            >>> cfg = Config().get()
            >>> print(cfg.os.env.HOME)
        """
        cfg = self._config
        setattr(cfg, "os", SimpleNamespace())
        setattr(cfg.os, "env", self._env)

        return cfg

    def reload(self, 
               config_paths: Optional[List[str]] = None, 
               whitelist: Optional[List[str]] = None
    ) -> None:
        """
        Reload configuration from `.env` and supported config files.

        Useful if configuration files change while the application is running.

        If ``whitelist`` is provided, only config files whose name or (POSIX) path matches at least one
        whitelist pattern are included. Patterns use shell-style wildcards (fnmatch), e.g.
        ``["app.yaml", "secrets*.toml", "config/*.json"]``.

        Args:
            config_paths: Optional list of additional directories to search for `.env` and config files.
            whitelist: Optional list of filename/path patterns to include when merging config files.

        Raises:
            FileNotFoundError: If any provided path in ``config_paths`` does not exist (when accessed).
            PermissionError: If a configuration file cannot be read due to permissions.
            OSError: If a configuration file cannot be opened due to an OS-level error.
            ValueError: If a configuration file contains invalid syntax or cannot be parsed.

        Example:
            >>> Config().reload(["./path/to/config"], ["*.json", "*.toml"])
            >>> cfg = Config().get()
            >>> print(cfg.os.env.HOME)
        """
        self._load(config_paths, whitelist)
