import json
import yaml
import tomli_w
import configparser
import xml.etree.ElementTree as ET

from types import SimpleNamespace
from typing import Any, Union, List
from pathlib import Path
from enum import Enum


class ConfigFormat(Enum):
    """
    Supported configuration output formats.

    Attributes:
        JSON: JSON format.
        YAML: YAML format.
        TOML: TOML format.
        INI: INI format.
        XML: XML format.
    """
    JSON = "json"
    YAML = "yaml"
    TOML = "toml"
    INI = "ini"
    XML = "xml"


def _namespace_to_dict(obj: Any) -> Any:
    """
    Recursively convert a :class:`types.SimpleNamespace` (or nested collections) into built-in types.

    Args:
        obj: The object to convert. Supports :class:`types.SimpleNamespace`, dict, list, and scalars.

    Returns:
        The converted object as a dictionary, list, or primitive value.

    Example:
        >>> ns = SimpleNamespace(a=1, b=SimpleNamespace(c=2))
        >>> data = _namespace_to_dict(ns)
        >>> # {"a": 1, "b": {"c": 2}}
    """
    if isinstance(obj, SimpleNamespace):
        return {k: _namespace_to_dict(v) for k, v in vars(obj).items()}
    elif isinstance(obj, dict):
        return {k: _namespace_to_dict(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_namespace_to_dict(item) for item in obj]
    else:
        return obj


def _filter_dict(data: Any, exclude: List[str]) -> Any:
    """
    Recursively remove specified keys from a dictionary (and nested dictionaries inside lists).

    Args:
        data: The data structure to filter (dict, list, or scalar).
        exclude: Keys to exclude at any dictionary level.

    Returns:
        The filtered structure with excluded keys removed.

    Example:
        >>> data = {"a": 1, "b": {"secret": 2, "c": 3}}
        >>> filtered = _filter_dict(data, exclude=["secret"])
        >>> # {"a": 1, "b": {"c": 3}}
    """
    if isinstance(data, dict):
        return {k: _filter_dict(v, exclude) for k, v in data.items() if k not in exclude}
    elif isinstance(data, list):
        return [_filter_dict(item, exclude) for item in data]
    else:
        return data


def _dict_to_xml_element(name: str, data: Any) -> ET.Element:
    """
    Convert a dictionary/list/scalar into an XML element tree.

    - dict: keys become child element names
    - list: each item becomes an ``<item>`` child
    - scalar: becomes element text

    Args:
        name: Name of the root XML element.
        data: Data to convert (dict, list, or primitive).

    Returns:
        An :class:`xml.etree.ElementTree.Element` representing the input data.

    Raises:
        TypeError: If an XML element name is not a valid string (e.g., non-string dict keys).
        RecursionError: If the structure is nested beyond the recursion limit.

    Example:
        >>> elem = _dict_to_xml_element("config", {"a": 1, "b": ["x", "y"]})
    """
    element = ET.Element(name)

    if isinstance(data, dict):
        for key, val in data.items():
            child = _dict_to_xml_element(key, val)
            element.append(child)
    elif isinstance(data, list):
        for item in data:
            child = _dict_to_xml_element("item", item)
            element.append(child)
    else:
        element.text = str(data)

    return element


def write_config(
    config: Union[dict, SimpleNamespace],
    filename: str,
    format: ConfigFormat,
    exclude_keys: List[str] = None
) -> None:
    """
    Write configuration data to a file in the specified format.

    The input config may be a dict or :class:`types.SimpleNamespace`. It is converted to built-in
    types, filtered via ``exclude_keys`` (applied recursively), then serialized.

    Args:
        config: Configuration data as a dict or :class:`types.SimpleNamespace`.
        filename: Path to the target output file.
        format: Output format to write.
        exclude_keys: Optional list of keys to exclude (applied recursively).

    Raises:
        ValueError: If the provided format is unsupported.
        OSError: If the output file cannot be created or written (e.g., permissions, invalid path).
        TypeError: If the configuration contains values that cannot be serialized for the chosen format.

    Example:
        >>> cfg = SimpleNamespace(app=SimpleNamespace(name="demo"), secrets={"token": "x"})
        >>> write_config(cfg, "config.yaml", ConfigFormat.YAML, exclude_keys=["secrets"])
    """
    exclude_keys = exclude_keys or []
    data = _namespace_to_dict(config)
    filtered = _filter_dict(data, exclude_keys)

    path = Path(filename)
    if format == ConfigFormat.JSON:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(filtered, f, indent=2)

    elif format == ConfigFormat.YAML:
        with open(path, "w", encoding="utf-8") as f:
            yaml.safe_dump(filtered, f, sort_keys=False)

    elif format == ConfigFormat.TOML:
        with open(path, "wb") as f:
            f.write(tomli_w.dumps(filtered).encode("utf-8"))

    elif format == ConfigFormat.INI:
        config_parser = configparser.ConfigParser()

        for section, values in filtered.items():
            if isinstance(values, dict):
                config_parser[section] = {str(k): str(v) for k, v in values.items()}
            else:
                config_parser["DEFAULT"][section] = str(values)

        with open(path, "w", encoding="utf-8") as f:
            config_parser.write(f)
            
    elif format == ConfigFormat.XML:
        root = _dict_to_xml_element("config", filtered)
        tree = ET.ElementTree(root)
        tree.write(path, encoding="utf-8", xml_declaration=True)
    else:
        raise ValueError(f"Unsupported format: {format}")
