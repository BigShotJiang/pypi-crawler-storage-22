import gitlab
import os
import zipfile

from dataclasses import dataclass
from typing import TypeVar, Any, Optional, Union, List
from gitlab.v4.objects import Project
from git import Repo
from datetime import datetime, date

from ..utility_base import UtilityBase
from ..logging import Logger, LogWrapper

T = TypeVar("T")


@dataclass
class MergeRequestActivity:
    """A single merge request note/activity item.

    Attributes:
        id: Note/activity ID.
        body: Text body.
        type: Optional note type (depends on GitLab server/version).
        author: Author display name.
        created_at: Creation timestamp as returned by GitLab (ISO-like string).
    """
    id: int
    body: str
    type: Optional[str]
    author: str
    created_at: str


@dataclass
class MergeRequestMetadata:
    """Metadata about a merge request plus optional expanded info.

    Attributes:
        parent_branch_name: Target branch name.
        source_branch_name: Source branch name.
        merge_request_id: MR IID (per-project number).
        merge_request_title: MR title.
        merge_request_description: MR description/body.
        merge_request_state: MR state (opened/closed/merged).
        merge_request_url: Web URL to the MR.
        branch_changed_files: Optional list of changed file paths (if requested).
        merge_request_activity: Optional list of notes/activity items (if requested).
    """
    parent_branch_name: str
    source_branch_name: str
    merge_request_id: int
    merge_request_title: str
    merge_request_description: str
    merge_request_state: str
    merge_request_url: str
    branch_changed_files: Optional[List[str]] = None
    merge_request_activity: Optional[List[MergeRequestActivity]] = None


@dataclass
class CommitMetadata:
    """Metadata about a commit plus optional change magnitude stats.

    Attributes:
        commit_short_id: Short SHA.
        commit_title: Commit title/subject.
        commit_author_name: Author name as returned by GitLab.
        commit_id: Full SHA.
        commit_date: Commit timestamp string as returned by GitLab.
        lines_added: Optional additions count (if computed).
        lines_deleted: Optional deletions count (if computed).
        total_lines_changed: Optional total changed lines (if computed).
        files_changed: Optional number of changed files (if computed).
        changed_files: Optional list of changed files (if computed).
        directories_touched: Optional top-level directories touched (if computed).
        entropy: Optional normalized entropy of change distribution per file (if computed).
    """
    commit_short_id: str
    commit_title: str
    commit_author_name: str
    commit_id: str
    commit_date: str

    lines_added: Optional[int] = None
    lines_deleted: Optional[int] = None
    total_lines_changed: Optional[int] = None
    files_changed: Optional[int] = None
    changed_files: Optional[List[str]] = None
    directories_touched: Optional[List[str]] = None
    entropy: Optional[float] = None


class GitlabClient(UtilityBase):
    """Thin convenience wrapper around `python-gitlab` + a few GitPython helpers.

    This class centralizes the common operations you use for automation scripts:
    listing branches/tags/commits, fetching MR metadata, cloning/checking out repos,
    and downloading pipeline artifacts.

    Args:
        url: GitLab instance base URL, e.g. ``"https://gitlab.example.com"``.
        private_token: Personal access token with sufficient permissions.
        verbose: Enable verbose logging in the base utility class.
        ssl_verify: Verify SSL certificates during API calls.
        logger: Optional logger instance used by the base utility class.
        log_level: Optional log level used by the base utility class.
        timeout: API call timeout in seconds.
        retries: Number of retry attempts for transient API failures.
        large_repo_threshold: Warn threshold for large projects (branches/tags/commits).

    Raises:
        gitlab.exceptions.GitlabAuthenticationError: If authentication fails.
        gitlab.exceptions.GitlabConnectionError: If the server is unreachable.
        gitlab.exceptions.GitlabHttpError: For other HTTP/API errors during auth.

    Examples:
        Basic usage:

        >>> client = GitlabClient(
        ...     url="https://gitlab.example.com",
        ...     private_token=os.environ["GITLAB_TOKEN"],
        ... )
        >>> client.list_branches("group/project", max_branches=20)
    """

    def __init__(
        self,
        url: str,
        private_token: str,
        verbose: bool = False,
        ssl_verify: bool = True,
        logger: Optional[Union[Logger, LogWrapper]] = None,
        log_level: Optional[int] = None,
        timeout: float = 50,
        retries: int = 3,
        large_repo_threshold: int = 500,
    ):
        super().__init__(verbose, logger, log_level)

        self.url = url
        self.retries = retries
        self.large_repo_threshold = large_repo_threshold

        self.gl = gitlab.Gitlab(
            url,
            private_token=private_token,
            timeout=timeout,
            retry_transient_errors=True,
            ssl_verify=ssl_verify,
        )
        self.gl.auth()

    def _warn_large(self, resource: Any, project_path: str, label: str) -> None:
        """Warn if resource count exceeds the configured large repo threshold.

        Note:
            This triggers an additional API call to estimate size.

        Args:
            resource: A `python-gitlab` listable resource (e.g. `project.branches`).
            project_path: Project path or ID used only for logging.
            label: Human label used only for logging.
        """
        count = len(resource.list(per_page=100))
        if count > self.large_repo_threshold:
            self._log_warning(
                f"Project '{project_path}' has {count}+ {label}. all=True may be slow."
            )

    def _to_iso8601(self, dt: Union[str, datetime, date]) -> str:
        """Convert a date/datetime to an ISO-8601-ish string accepted by GitLab.

        Args:
            dt: Either an ISO-8601 string (returned unchanged), a `date`, or a `datetime`.
                Naive datetimes are treated as UTC (trailing ``Z``).

        Returns:
            ISO-8601 string suitable for GitLab query params.
        """
        if isinstance(dt, str):
            return dt
        if isinstance(dt, date) and not isinstance(dt, datetime):
            dt = datetime.combine(dt, datetime.min.time())
        if dt.tzinfo is None:
            return dt.strftime("%Y-%m-%dT%H:%M:%SZ")
        return dt.astimezone().strftime("%Y-%m-%dT%H:%M:%SZ")

    @staticmethod
    def _parse_committed_date(commit_info: dict) -> datetime:
        """Parse committed date from a commit info dict.

        Args:
            commit_info: Dict containing a ``"committed_date"`` key.

        Returns:
            Parsed `datetime` (naive, without timezone) or `datetime.min` if unknown.
        """
        date_str = commit_info.get("committed_date")
        if date_str:
            try:
                return datetime.strptime(date_str[:19], "%Y-%m-%dT%H:%M:%S")
            except Exception:
                pass
        return datetime.min

    def get_project(self, project_path: str) -> Optional[Project]:
        """Fetch a GitLab project by path or numeric ID.

        Args:
            project_path: Project path (e.g. ``"group/project"``) or project ID as a string.

        Returns:
            A `Project` object.

        Raises:
            gitlab.exceptions.GitlabGetError: If the project does not exist or is not accessible.
            gitlab.exceptions.GitlabAuthenticationError: If the token is invalid/expired.
            gitlab.exceptions.GitlabConnectionError: For connectivity issues.

        Examples:
            >>> project = client.get_project("group/project")
            >>> project.name
        """
        return self.gl.projects.get(project_path)

    def list_branches(self, project_path: str, max_branches: Optional[int] = None) -> list[str]:
        """List branch names for a project.

        Args:
            project_path: Project path or ID.
            max_branches: If set, limit the number of branches fetched from the API.
                If `None`, fetch all branches (may be slow for large repos).

        Returns:
            List of branch names. Returns an empty list if `get_project()` returned falsy.

        Raises:
            gitlab.exceptions.GitlabListError: If listing branches fails.

        Examples:
            >>> client.list_branches("group/project", max_branches=10)
        """
        if not (project := self.get_project(project_path)):
            return []

        if max_branches is not None:
            branches = project.branches.list(per_page=max_branches)
        else:
            self._warn_large(project.branches, project_path, "branches")
            branches = project.branches.list(all=True)

        return [branch.name for branch in branches]

    def list_recent_branches(self, project_path: str, num_branches: int = 10) -> list[str]:
        """Return the N most recently updated branch names.

        This uses each branch's latest commit committed_date to sort.

        Args:
            project_path: Project path or ID.
            num_branches: Number of branches to return.

        Returns:
            List of branch names, sorted by most recently committed first. Empty list if
            `get_project()` returned falsy.

        Raises:
            gitlab.exceptions.GitlabListError: If listing branches fails.
            gitlab.exceptions.GitlabGetError: If fetching an individual branch fails.

        Examples:
            >>> client.list_recent_branches("group/project", num_branches=5)
        """
        if not (project := self.get_project(project_path)):
            return []

        branches = project.branches.list(all=True)
        branches_with_dates = [
            (
                branch.name,
                self._parse_committed_date(
                    getattr(project.branches.get(branch.name), "commit", {}) or {}
                ),
            )
            for branch in branches
        ]
        branches_with_dates.sort(key=lambda x: x[1], reverse=True)

        return [name for name, _ in branches_with_dates[:num_branches]]

    def get_mr(
        self,
        project_path: str,
        merge_request_id: int,
        get_changed_files: bool = False,
        get_activity: bool = False,
    ) -> Optional[MergeRequestMetadata]:
        """Fetch merge request details by MR IID.

        Args:
            project_path: Project path or ID.
            merge_request_id: MR IID (the per-project number shown in GitLab UI).
            get_changed_files: If True, also retrieve changed file paths.
            get_activity: If True, also retrieve MR notes/activity.

        Returns:
            `MergeRequestMetadata` or `None` if `get_project()` returned falsy.

        Raises:
            gitlab.exceptions.GitlabGetError: If the MR cannot be fetched.
            gitlab.exceptions.GitlabListError: If notes listing fails (when `get_activity=True`).

        Examples:
            >>> mr = client.get_mr("group/project", 42, get_changed_files=True)
            >>> mr.merge_request_title
            >>> mr.branch_changed_files[:3]
        """
        if not (project := self.get_project(project_path)):
            return None

        mr_full = project.mergerequests.get(merge_request_id, lazy=False)

        branch_changed_files = []
        if get_changed_files:
            try:
                changes = mr_full.changes()
                branch_changed_files = [c["new_path"] for c in changes.get("changes", [])]
            except Exception:
                branch_changed_files = []

        merge_request_activity = None
        if get_activity:
            try:
                notes = mr_full.notes.list(all=True)
                merge_request_activity = [
                    MergeRequestActivity(
                        id=note.id,
                        body=note.body,
                        type=getattr(note, "type", None),
                        author=note.author["name"],
                        created_at=note.created_at,
                    )
                    for note in notes
                ]
            except Exception:
                merge_request_activity = []

        return MergeRequestMetadata(
            parent_branch_name=mr_full.target_branch,
            source_branch_name=mr_full.source_branch,
            merge_request_id=mr_full.iid,
            merge_request_title=mr_full.title,
            merge_request_description=mr_full.description,
            merge_request_state=mr_full.state,
            merge_request_url=mr_full.web_url,
            branch_changed_files=branch_changed_files,
            merge_request_activity=merge_request_activity,
        )

    def get_branch_mr(
        self,
        project_path: str,
        branch_name: str,
        state: str = "all",
        get_changed_files: bool = False,
        get_activity: bool = False,
    ) -> Optional[List[MergeRequestMetadata]]:
        """Get merge requests for a given source branch.

        Args:
            project_path: Project path or ID.
            branch_name: Source branch name to filter MRs.
            state: MR state filter: ``"opened"``, ``"closed"``, ``"merged"``, or ``"all"``.
            get_changed_files: If True, retrieve list of changed files per MR.
            get_activity: If True, retrieve MR notes/activity per MR.

        Returns:
            List of `MergeRequestMetadata` if MRs exist, otherwise `None`. Returns `None`
            if `get_project()` returned falsy.

        Raises:
            gitlab.exceptions.GitlabListError: If MR listing fails.
            gitlab.exceptions.GitlabGetError: If fetching an MR fails (when expanding).
            gitlab.exceptions.GitlabListError: If notes listing fails (when `get_activity=True`).

        Examples:
            >>> mrs = client.get_branch_mr("group/project", "feature/x", state="opened")
            >>> [mr.merge_request_id for mr in (mrs or [])]
        """
        if not (project := self.get_project(project_path)):
            return None

        mrs = project.mergerequests.list(
            source_branch=branch_name,
            state=state,
            order_by="updated_at",
            sort="desc",
        )

        if not mrs:
            return None

        result: list[MergeRequestMetadata] = []
        for mr in mrs:
            branch_changed_files: list[str] = []

            # Always fetch full MR object if we need changes/notes, or to keep fields consistent.
            mr_full = project.mergerequests.get(mr.iid, lazy=False)

            if get_changed_files:
                try:
                    changes = mr_full.changes()
                    branch_changed_files = [change["new_path"] for change in changes["changes"]]
                except Exception:
                    branch_changed_files = []

            merge_request_activity = None
            if get_activity:
                try:
                    notes = mr_full.notes.list(all=True)
                    merge_request_activity = [
                        MergeRequestActivity(
                            id=note.id,
                            body=note.body,
                            type=getattr(note, "type", None),
                            author=note.author["name"],
                            created_at=note.created_at,
                        )
                        for note in notes
                    ]
                except Exception:
                    merge_request_activity = []

            result.append(
                MergeRequestMetadata(
                    parent_branch_name=mr_full.target_branch,
                    source_branch_name=branch_name,
                    merge_request_id=mr_full.iid,
                    merge_request_title=mr_full.title,
                    merge_request_description=mr_full.description,
                    merge_request_state=mr_full.state,
                    merge_request_url=mr_full.web_url,
                    branch_changed_files=branch_changed_files,
                    merge_request_activity=merge_request_activity,
                )
            )

        return result

    def list_tags(self, project_path: str, max_tags: Optional[int] = None) -> list[str]:
        """List tag names in a project.

        Args:
            project_path: Project path or ID.
            max_tags: If set, limit number of tags returned. If `None`, fetch all tags.

        Returns:
            List of tag names. Empty list if `get_project()` returned falsy.

        Raises:
            gitlab.exceptions.GitlabListError: If listing tags fails.

        Examples:
            >>> client.list_tags("group/project", max_tags=20)
        """
        if not (project := self.get_project(project_path)):
            return []

        if max_tags is not None:
            tags = project.tags.list(per_page=max_tags)
        else:
            self._warn_large(project.tags, project_path, "tags")
            tags = project.tags.list(all=True)

        return [tag.name for tag in tags]

    def list_changed_files_between_tags(self, project_path: str, from_tag: str, to_tag: str) -> list[str]:
        """List files changed between two tags.

        Args:
            project_path: Project path or ID.
            from_tag: Base tag name.
            to_tag: Target tag name.

        Returns:
            List of unique changed file paths (order not guaranteed). Empty list if
            `get_project()` returned falsy.

        Raises:
            gitlab.exceptions.GitlabGetError: If repository compare fails (bad refs / no access).

        Examples:
            >>> client.list_changed_files_between_tags("group/project", "v1.0.0", "v1.1.0")
        """
        if not (project := self.get_project(project_path)):
            return []

        comparison = project.repository_compare(from_=from_tag, to=to_tag)
        diffs = comparison.get("diffs", [])
        changed_files = {diff["new_path"] for diff in diffs}
        return list(changed_files)

    def list_changed_files_for_commit(self, project_path: str, commit_id: str) -> list[str]:
        """List changed files for a given commit SHA.

        Args:
            project_path: Project path or ID.
            commit_id: Commit SHA (full or short) accepted by GitLab.

        Returns:
            Sorted list of changed file paths. Empty list if `get_project()` returned falsy.

        Raises:
            gitlab.exceptions.GitlabGetError: If the commit cannot be fetched.
            gitlab.exceptions.GitlabHttpError: If diff retrieval fails.

        Examples:
            >>> client.list_changed_files_for_commit("group/project", "a1b2c3d4")
        """
        if not (project := self.get_project(project_path)):
            return []

        commit = project.commits.get(commit_id)
        diffs = commit.diff(get_all=True)
        changed_files = [d["new_path"] for d in diffs]
        return sorted(changed_files)

    def get_commit_metadata(
        self,
        project_path: str,
        commit_hash: str,
        include_change_stats: bool = False,
    ) -> Optional[CommitMetadata]:
        """Get metadata for a single commit (optionally with change stats).

        Args:
            project_path: Project path or ID.
            commit_hash: Commit hash (full or short) accepted by GitLab.
            include_change_stats: If True, compute diff-derived stats such as files changed
                and a simple "entropy" heuristic.

        Returns:
            `CommitMetadata` on success, otherwise `None` (e.g. if commit fetch fails or
            `get_project()` returned falsy).

        Raises:
            gitlab.exceptions.GitlabGetError: If `get_project()` succeeds but the commit
                retrieval raises and is not caught elsewhere. (This method catches generic
                exceptions during commit fetch and returns `None`.)

        Examples:
            >>> meta = client.get_commit_metadata("group/project", "a1b2c3d4", include_change_stats=True)
            >>> meta.files_changed, meta.entropy
        """
        if not (project := self.get_project(project_path)):
            return None

        try:
            commit = project.commits.get(commit_hash)
        except Exception:
            self._log_exception(
                f"Error occurred while requesting commit metadata for `{commit_hash}`"
            )
            return None

        meta = CommitMetadata(
            commit_short_id=commit.short_id,
            commit_title=commit.title,
            commit_author_name=commit.author_name,
            commit_id=commit.id,
            commit_date=commit.committed_date,
        )

        if include_change_stats:
            try:
                diffs = commit.diff(get_all=True)
                files = [d["new_path"] for d in diffs]
                stats = getattr(commit, "stats", {}) or {}
                additions = stats.get("additions")
                deletions = stats.get("deletions")
                total = stats.get("total")

                dirs = sorted({f.split("/")[0] for f in files if "/" in f})

                per_file_changes = []
                for d in diffs:
                    patch = d.get("diff", "") or ""
                    added = patch.count("\n+")
                    removed = patch.count("\n-")
                    per_file_changes.append(max(1, added + removed))

                entropy = None
                if per_file_changes:
                    import math

                    total_lines = sum(per_file_changes)
                    probs = [c / total_lines for c in per_file_changes]
                    raw_entropy = -sum(p * math.log2(p) for p in probs if p > 0)
                    entropy = (
                        raw_entropy / math.log2(len(per_file_changes))
                        if len(per_file_changes) > 1
                        else 0.0
                    )

                meta.lines_added = additions
                meta.lines_deleted = deletions
                meta.total_lines_changed = total
                meta.files_changed = len(files)
                meta.changed_files = files
                meta.directories_touched = dirs
                meta.entropy = entropy
            except Exception as e:
                self._log_warning(f"Could not compute change stats for `{commit_hash}`: {e}")

        return meta

    def list_commits(
        self,
        project_path: str,
        branch: str,
        max_commits: Optional[int] = None,
        since: Optional[Union[str, datetime, date]] = None,
        until: Optional[Union[str, datetime, date]] = None,
    ) -> list[CommitMetadata]:
        """List commits on a branch, optionally filtered by a date/time range.

        Args:
            project_path: Project path or ID.
            branch: Branch name (GitLab ref name).
            max_commits: If set, limit results to this many commits. If `None`, fetch all.
            since: Include commits at/after this timestamp/date. Accepts ISO string,
                `datetime`, or `date`.
            until: Include commits up to this timestamp/date (GitLab semantics).

        Returns:
            List of `CommitMetadata`. Empty list if `get_project()` returned falsy.

        Raises:
            gitlab.exceptions.GitlabListError: If listing commits fails.

        Examples:
            >>> client.list_commits("group/project", "main", max_commits=50)
            >>> client.list_commits("group/project", "main", since=date(2025, 1, 1))
        """
        if not (project := self.get_project(project_path)):
            return []

        params: dict[str, Any] = {"ref_name": branch}
        if since:
            params["since"] = self._to_iso8601(since)
        if until:
            params["until"] = self._to_iso8601(until)

        if max_commits is not None:
            commits = project.commits.list(per_page=max_commits, **params)
        else:
            self._warn_large(project.commits, project_path, "commits")
            commits = project.commits.list(all=True, **params)

        result = [
            CommitMetadata(
                commit_short_id=c.short_id,
                commit_title=c.title,
                commit_author_name=c.author_name,
                commit_id=c.id,
                commit_date=c.committed_date,
            )
            for c in commits
        ]

        if max_commits is not None:
            result = result[:max_commits]

        return result

    def list_unique_commits_on_branch(
        self, project_path: str, base_branch: str, compare_branch: str
    ) -> list[CommitMetadata]:
        """List commits unique to `compare_branch` relative to `base_branch`.

        This uses GitLab's repository compare endpoint.

        Args:
            project_path: Project path or ID.
            base_branch: Base ref (branch/tag/SHA) for comparison.
            compare_branch: Compare ref (branch/tag/SHA).

        Returns:
            List of `CommitMetadata`. Empty list if `get_project()` returned falsy.

        Raises:
            gitlab.exceptions.GitlabGetError: If repository compare fails (bad refs / no access).

        Examples:
            >>> client.list_unique_commits_on_branch("group/project", "main", "feature/x")
        """
        if not (project := self.get_project(project_path)):
            return []

        comparison = project.repository_compare(from_=base_branch, to=compare_branch)
        commits = comparison["commits"]

        return [
            CommitMetadata(
                commit_short_id=commit["short_id"],
                commit_title=commit["title"],
                commit_author_name=commit["author_name"],
                commit_id=commit["id"],
                commit_date=commit.get("committed_date", ""),
            )
            for commit in commits
        ]

    def get_commit_changed_files(self, project_path: str, commit_id: str) -> list[str]:
        """Get list of files changed in a commit.

        Args:
            project_path: Project path or ID.
            commit_id: Commit SHA or ID.

        Returns:
            List of changed file paths. Empty list if `get_project()` returned falsy.

        Raises:
            gitlab.exceptions.GitlabGetError: If the commit cannot be fetched.
            gitlab.exceptions.GitlabHttpError: If diff retrieval fails.

        Examples:
            >>> client.get_commit_changed_files("group/project", "a1b2c3d4")
        """
        if not (project := self.get_project(project_path)):
            return []

        changes = project.commits.get(commit_id).diff()
        return [file["new_path"] for file in changes]

    def clone_repository(
        self, project_url: str, local_path: str, branch: Optional[str] = None
    ) -> Optional[Repo]:
        """Clone a GitLab repo to a local path (or open it if already cloned).

        Args:
            project_url: Repository path *after* the GitLab base URL (no protocol),
                e.g. ``"group/project"``.
            local_path: Local directory to clone into / open.
            branch: Optional branch to check out after clone/open.

        Returns:
            `git.Repo` instance.

        Raises:
            RuntimeError: If `local_path` exists but is not a git repository.
            git.exc.GitCommandError: If clone/fetch/checkout fails.

        Examples:
            >>> repo = client.clone_repository("group/project", "/tmp/project", branch="main")
            >>> repo.active_branch.name
        """
        if not os.path.exists(local_path):
            repo = Repo.clone_from(f"{self.url}/{project_url}.git", local_path)
        elif os.path.isdir(os.path.join(local_path, ".git")):
            repo = Repo(local_path)
        else:
            raise RuntimeError(
                f"Directory '{local_path}' exists but is not a git repository."
            )

        if branch:
            repo.git.checkout(branch)

        return repo

    def checkout_branch(self, local_path: str, branch: str) -> None:
        """Check out a branch in an existing local repository.

        This fetches all remotes and attempts a fast-forward pull when the branch exists,
        otherwise creates a local branch from ``origin/<branch>``.

        Args:
            local_path: Local repository path.
            branch: Branch name to check out.

        Raises:
            git.exc.GitCommandError: If fetch/checkout/pull operations fail unexpectedly.

        Examples:
            >>> client.checkout_branch("/tmp/project", "feature/x")
        """
        repo = Repo(local_path)

        repo.git.fetch("--all")
        try:
            repo.git.checkout(branch)
            repo.git.pull("--ff-only")
        except Exception:
            repo.git.checkout("-b", branch, f"origin/{branch}")

    def checkout_tag(self, local_path: str, tag: str, new_branch: str = None) -> None:
        """Check out a tag in a local repository, optionally creating a new branch.

        Args:
            local_path: Local repository path.
            tag: Tag name to check out.
            new_branch: If provided, create this branch at `tag` and check it out.

        Raises:
            git.exc.GitCommandError: If fetch/checkout fails.

        Examples:
            Detached HEAD at tag:

            >>> client.checkout_tag("/tmp/project", "v1.2.3")

            Create a branch from tag:

            >>> client.checkout_tag("/tmp/project", "v1.2.3", new_branch="hotfix/v1.2.3")
        """
        repo = Repo(local_path)

        repo.git.fetch("--tags")
        if new_branch:
            repo.git.checkout("-b", new_branch, tag)
        else:
            repo.git.checkout(tag)

    def download_pipeline_artifacts(
        self,
        project_path: str,
        pipeline_id: int,
        jobs_of_interest: list[str],
        output_folder: str,
    ) -> None:
        """Download and extract artifacts from specified jobs in a pipeline.

        This method is *best-effort*: it logs errors per job and continues.

        Args:
            project_path: Project path or ID.
            pipeline_id: Pipeline ID.
            jobs_of_interest: Job names to download artifacts from.
            output_folder: Directory to store extracted artifacts. Existing folder is removed.

        Returns:
            None.

        Raises:
            None explicitly. Errors are caught and logged.

        Examples:
            >>> client.download_pipeline_artifacts(
            ...     "group/project",
            ...     pipeline_id=12345,
            ...     jobs_of_interest=["build", "test"],
            ...     output_folder="./artifacts",
            ... )
        """
        import shutil

        project = self.get_project(project_path)
        if not project:
            self._log_error(f"Project '{project_path}' not found.")
            return

        if os.path.exists(output_folder):
            shutil.rmtree(output_folder, ignore_errors=True)
        os.makedirs(output_folder, exist_ok=True)

        jobs = project.pipelines.get(pipeline_id).jobs.list(all=True)
        found_any = False

        for job in jobs:
            if job.name in jobs_of_interest:
                found_any = True
                job_dir = os.path.join(output_folder, job.name)
                os.makedirs(job_dir, exist_ok=True)
                zip_path = os.path.join(job_dir, "artifacts.zip")
                
                try:
                    full_job = project.jobs.get(job.id)

                    with open(zip_path, "wb") as f:
                        f.write(full_job.artifacts())

                    with zipfile.ZipFile(zip_path, "r") as z:
                        z.extractall(path=job_dir)
                    os.remove(zip_path)

                    self._log_info(
                        f"Downloaded and extracted artifacts for job: {job.name}"
                    )
                except Exception as e:
                    self._log_error(f"Failed to process artifacts for job {job.name}: {e}")
            else:
                self._log_info(f"Skipped job: {job.name}")

        if not found_any:
            self._log_warning("No matching jobs with artifacts found in the pipeline.")
