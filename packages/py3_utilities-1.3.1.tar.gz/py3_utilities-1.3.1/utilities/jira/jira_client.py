import aiohttp
import asyncio
import logging
import ssl

from typing import Optional, Dict, Any, List, Union
from collections import defaultdict

from ..utility_base import UtilityBase
from ..logging import Logger, LogWrapper


async def _noop():
    """
    Do-nothing async helper.

    Used internally to keep :func:`asyncio.gather` call sites uniform.
    """
    return None


class JiraClient(UtilityBase):
    """
    Asynchronous client for Jira's REST API (v2 + Agile).

    The client manages an internal ``aiohttp.ClientSession`` which must be created via
    :meth:`start_session` before making requests.

    Args:
        api_key: Jira API token used as a Bearer token.
        jira_url: Base URL of the Jira instance, e.g. ``"https://jira.example.com"``.
        retry_cnt: Number of attempts for simple GET JSON fetches in :meth:`_fetch_json`.
            (Only used by :meth:`_fetch_json`, not by :meth:`send_request`.)
        verbose: If ``True``, emits debug logs via the inherited logger helpers.
        ssl_verify: If ``False``, disables SSL certificate verification for the session.
        log_urls: If ``True``, logs every requested URL in :meth:`_fetch_json`.
        logger: Optional logger instance. If not provided, a default logger is used by
            :class:`~..utility_base.UtilityBase`.
        log_level: Optional log level to set on the default logger (if created).

    Attributes:
        session: The underlying ``aiohttp.ClientSession`` (created by :meth:`start_session`).
        headers: Default request headers including Bearer authorization.

    Examples:
        >>> import asyncio
        >>> async def example():
        ...     jc = JiraClient("TOKEN", "https://jira.example.com")
        ...     await jc.start_session()
        ...     try:
        ...         issue = await jc.read_issue("ABC-123")
        ...         _ = (issue is None) or ("fields" in issue)
        ...     finally:
        ...         await jc.close_session()
        >>> # asyncio.run(example())
    """

    def __init__(
            self,
            api_key: str,
            jira_url: str,
            retry_cnt: int = 1,
            verbose: bool = False,
            ssl_verify: bool = True,
            log_urls: bool = False,
            logger: Optional[Union[logging.Logger, Logger, LogWrapper]] = None,
            log_level: Optional[int] = None
        ):
        """
        Initialize the Jira client.

        Notes:
            - This does *not* create the network session; call :meth:`start_session`.
            - Authentication uses Bearer token header: ``Authorization: Bearer <api_key>``.

        Args:
            api_key: Jira API token used as a Bearer token.
            jira_url: Base URL of the Jira instance.
            retry_cnt: Number of retries in case of a failed request (for :meth:`_fetch_json`).
            verbose: If True, debug messages are logged during operations.
            ssl_verify: If False, SSL certificate verification is disabled.
            log_urls: If True, all requested URLs are logged (for :meth:`_fetch_json`).
            logger: Logger instance. If not provided, a default logger is used.
            log_level: Log level. If not provided, INFO level will be used.

        Raises:
            Any exception raised by the base class initialization, if applicable.
        """
        # Init base class
        super().__init__(verbose, logger, log_level)
        self.log_urls = log_urls

        self.api_key = api_key
        self.headers = {
            'Authorization': f'Bearer {api_key}',
            'Accept': 'application/json'
        }
        self.session: Optional[aiohttp.ClientSession] = None  # Session is not created yet

        self.jira_url = jira_url
        self.base_project_url = f"{jira_url}/rest/api/2/project"
        self.base_issue_url = f"{jira_url}/rest/api/2/issue"
        self.base_search_url = f"{jira_url}/rest/api/2/search"
        self.base_board_url = f"{jira_url}/rest/agile/1.0/board"

        self.retry_cnt = retry_cnt
        self.ssl_verify = ssl_verify

    async def _fetch_json(self, url: str) -> Optional[Dict[str, Any]]:
        """
        Fetch a JSON object from Jira via HTTP GET.

        Requires the session to be started first using :meth:`start_session`.

        Args:
            url: Fully qualified URL that returns a JSON object.

        Returns:
            The decoded JSON response as a dictionary, or ``None`` if:
            - The response is not HTTP 200 after exhausting retries, or
            - An error occurs and the function returns ``None`` after logging.

        Raises:
            RuntimeError: If the client session is not initialized.
            aiohttp.ClientConnectionError: For connection-level errors.
            aiohttp.ClientResponseError: For invalid HTTP responses (when raised by aiohttp).
            aiohttp.ClientPayloadError: For invalid payload / decoding issues.
            aiohttp.ClientError: For other aiohttp client errors.
            Exception: Re-raises unexpected exceptions after logging.

        Examples:
            >>> # Requires network + valid Jira; shown as doctest-style usage.
            >>> import asyncio
            >>> async def example(jc):
            ...     await jc.start_session()
            ...     try:
            ...         data = await jc._fetch_json("https://jira.example.com/rest/api/2/myself")
            ...         _ = (data is None) or isinstance(data, dict)
            ...     finally:
            ...         await jc.close_session()
            >>> asyncio.run(example(jc))
        """
        if self.session is None:
            raise RuntimeError("JiraClient session is not initialized. Call `await start_session()` first.")

        if self.log_urls:
            self._log(f"Requested URL: `{url}`")

        try:
            counter = 0
            while counter < self.retry_cnt:
                async with self.session.get(url, headers=self.headers) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        self._log_warning(f"Failed to fetch `{url}`. Response status: {response.status} ({counter+1}. attempt).")
                counter += 1

            self._log_error(f"Failed to fetch `{url}` after {self.retry_cnt} retries.")
        except aiohttp.ClientConnectionError as e:
            self._log_exception(f"Connection error while requesting `{url}`: {e}")
            raise
        except aiohttp.ClientResponseError as e:
            self._log_exception(f"Response error {e.status} while requesting `{url}`: {e}")
            raise
        except aiohttp.ClientPayloadError as e:
            self._log_exception(f"Payload error while requesting `{url}`: {e}")
            raise
        except aiohttp.ClientError as e:
            self._log_exception(f"General client error while requesting `{url}`: {e}")
            raise
        except Exception as e:
            self._log_exception(f"Unexpected error while requesting `{url}`: {e}")
            raise

        return None

    async def _read_issue_worklog(self, issue_id: str) -> Optional[Dict[str, Any]]:
        """
        Fetch worklog details for a Jira issue.

        Args:
            issue_id: Jira issue key or ID (depending on Jira configuration), e.g. ``"ABC-123"``.

        Returns:
            Worklog JSON data as a dictionary, or ``None`` if retrieval fails.

        Raises:
            RuntimeError: If the client session is not initialized.
            aiohttp.ClientConnectionError: For connection-level errors.
            aiohttp.ClientResponseError: For invalid HTTP responses (when raised by aiohttp).
            aiohttp.ClientPayloadError: For invalid payload / decoding issues.
            aiohttp.ClientError: For other aiohttp client errors.
            Exception: Re-raises unexpected exceptions after logging.

        Examples:
            >>> asyncio.run(jc._read_issue_worklog("ABC-123"))
        """
        url = f"{self.base_issue_url}/{issue_id}/worklog"
        return await self._fetch_json(url)

    async def _read_issue_comments(self, issue_id: str) -> Optional[Dict[str, Any]]:
        """
        Fetch comments for a Jira issue.

        Args:
            issue_id: Jira issue key or ID, e.g. ``"ABC-123"``.

        Returns:
            Comments JSON data as a dictionary, or ``None`` if retrieval fails.

        Raises:
            RuntimeError: If the client session is not initialized.
            aiohttp.ClientConnectionError: For connection-level errors.
            aiohttp.ClientResponseError: For invalid HTTP responses (when raised by aiohttp).
            aiohttp.ClientPayloadError: For invalid payload / decoding issues.
            aiohttp.ClientError: For other aiohttp client errors.
            Exception: Re-raises unexpected exceptions after logging.

        Examples:
            >>> asyncio.run(jc._read_issue_comments("ABC-123"))
        """
        url = f"{self.base_issue_url}/{issue_id}/comment"
        return await self._fetch_json(url)

    async def start_session(self):
        """
        Initialize the underlying ``aiohttp.ClientSession``.

        Call exactly once before using any method that performs HTTP requests.

        Behavior:
            - If ``ssl_verify`` is ``False``, SSL certificate verification is disabled.
            - If a session already exists, logs and does nothing.

        Raises:
            ssl.SSLError: If SSL context creation fails (rare).
            aiohttp.ClientError: If ``aiohttp`` fails to create a session/connector.

        Examples:
            >>> await jc.start_session()
            >>> await jc.close_session()
        """
        if self.session is None:
            if not self.ssl_verify:
                ssl_context = ssl.create_default_context()
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE
                self.session = aiohttp.ClientSession(connector=aiohttp.TCPConnector(ssl=ssl_context))
            else:
                self.session = aiohttp.ClientSession()
        else:
            self._log("Session already initialized. Skipping.")

    async def close_session(self):
        """
        Close the underlying ``aiohttp.ClientSession``.

        Safe to call multiple times.

        Returns:
            None

        Examples:
            >>> await jc.close_session()
        """
        if self.session:
            await self.session.close()
            self.session = None

    async def read_custom_jql_keys(self, custom_jql: str) -> list[str]:
        """
        Retrieve all issue keys for a custom JQL query.

        This paginates through Jira search results and collects the ``key`` field only.

        Args:
            custom_jql: JQL query string (will be appended to the URL query).

        Returns:
            A list of issue keys (e.g., ``["ABC-1", "ABC-2"]``). Returns an empty list if
            nothing is found or the request fails.

        Raises:
            RuntimeError: If the client session is not initialized.
            aiohttp.ClientConnectionError: For connection-level errors.
            aiohttp.ClientResponseError: For invalid HTTP responses (when raised by aiohttp).
            aiohttp.ClientPayloadError: For invalid payload / decoding issues.
            aiohttp.ClientError: For other aiohttp client errors.
            Exception: Re-raises unexpected exceptions after logging.

        Examples:
            >>> keys = await jc.read_custom_jql_keys('project = ABC AND status = "Done"')
            >>> isinstance(keys, list) 
        """
        issue_keys = []
        start_at = 0
        batch_size = 1000  # Jira API limit per request

        while True:
            url = f"{self.base_search_url}?jql={custom_jql}&fields=key&startAt={start_at}&maxResults={batch_size}"

            response_data = await self._fetch_json(url)
            if not response_data or "issues" not in response_data:
                self._log_error(f"Failed to retrieve result keys for query '{custom_jql}'")
                break

            # Extract issue keys
            batch_keys = [issue["key"] for issue in response_data["issues"]]
            issue_keys.extend(batch_keys)

            # Pagination check: Stop if fewer results than batch size
            if len(batch_keys) < batch_size:
                break  # No more issues left to fetch

            # Move to the next batch
            start_at += batch_size

        self._log(f"Read {len(issue_keys)} keys for JQL query:\n\t`{custom_jql}`")
        return issue_keys

    async def read_linked_issue_keys(self, issue_key: str) -> dict[str, list[str]]:
        """
        Retrieve linked issue keys for a given Jira issue, grouped by link type.

        This inspects ``fields.issuelinks`` on the issue JSON and collects keys from both
        directions (``inwardIssue`` and ``outwardIssue``).

        Args:
            issue_key: Jira issue key, e.g. ``"ABC-123"``.

        Returns:
            Dictionary mapping link type name to list of related issue keys.
            Returns an empty dict if the issue cannot be fetched.

        Raises:
            RuntimeError: If the client session is not initialized.
            aiohttp.ClientConnectionError: For connection-level errors.
            aiohttp.ClientResponseError: For invalid HTTP responses (when raised by aiohttp).
            aiohttp.ClientPayloadError: For invalid payload / decoding issues.
            aiohttp.ClientError: For other aiohttp client errors.
            Exception: Re-raises unexpected exceptions after logging.

        Examples:
            >>> links = await jc.read_linked_issue_keys("ABC-123")
            >>> isinstance(links, dict)
        """
        url = f"{self.base_issue_url}/{issue_key}"
        issue_data = await self._fetch_json(url)
        if not issue_data:
            self._log_error(f"Failed to fetch issue data for {issue_key}")
            return {}

        issuelinks = issue_data.get("fields", {}).get("issuelinks", [])
        result = defaultdict(list)

        for link in issuelinks:
            link_type = link.get("type", {}).get("name", "Unknown")
            # Can be 'inwardIssue' or 'outwardIssue'
            if "outwardIssue" in link:
                result[link_type].append(link["outwardIssue"]["key"])
            if "inwardIssue" in link:
                result[link_type].append(link["inwardIssue"]["key"])

        return dict(result)

    async def read_linked_epic_keys(self, epic_key: str) -> list[str]:
        """
        Retrieve issue keys linked to an epic via JQL.

        Uses the Jira field name ``"Epic Link"``:
        ``"Epic Link"=<epic_key>``.

        Args:
            epic_key: Epic issue key, e.g. ``"ABC-1000"``.

        Returns:
            List of issue keys linked to the epic.

        Raises:
            RuntimeError: If the client session is not initialized.
            aiohttp.ClientConnectionError: For connection-level errors.
            aiohttp.ClientResponseError: For invalid HTTP responses (when raised by aiohttp).
            aiohttp.ClientPayloadError: For invalid payload / decoding issues.
            aiohttp.ClientError: For other aiohttp client errors.
            Exception: Re-raises unexpected exceptions after logging.

        Examples:
            >>> children = await jc.read_linked_epic_keys("ABC-1000")
        """
        return await self.read_custom_jql_keys(custom_jql=f'"Epic Link"={epic_key}')

    async def read_issue(
            self,
            issue_id: str,
            read_changelog: Optional[bool] = False,
            read_comments: Optional[bool] = False,
            read_worklog: Optional[bool] = False,
            changelog_filter: Optional[List[str]] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Fetch a Jira issue and optionally merge changelog, comments, and worklog.

        When ``read_comments`` / ``read_worklog`` are enabled, this method fetches those
        resources concurrently and inserts them into:

        - ``issue_data["fields"]["comment"]``
        - ``issue_data["fields"]["worklog"]``

        When ``read_changelog`` is enabled, the issue is requested with
        ``expand=changelog``. If ``changelog_filter`` is provided, the changelog histories
        are filtered to keep only items whose ``field`` matches one of the provided names
        (case-insensitive).

        Args:
            issue_id: Jira issue key or ID, e.g. ``"ABC-123"``.
            read_changelog: If True, includes changelog expansion in the issue request.
            read_comments: If True, fetches comments and merges them into ``fields.comment``.
            read_worklog: If True, fetches worklog and merges it into ``fields.worklog``.
            changelog_filter: Optional list of field names to keep in the changelog.
                Ignored unless ``read_changelog`` is True.

        Returns:
            The issue JSON as a dictionary (with merged fields as described), or ``None``
            if the issue cannot be fetched.

        Raises:
            RuntimeError: If the client session is not initialized.
            aiohttp.ClientConnectionError: For connection-level errors.
            aiohttp.ClientResponseError: For invalid HTTP responses (when raised by aiohttp).
            aiohttp.ClientPayloadError: For invalid payload / decoding issues.
            aiohttp.ClientError: For other aiohttp client errors.
            Exception: Re-raises unexpected exceptions after logging.

        Examples:
            >>> # Basic issue fetch
            >>> issue = await jc.read_issue("ABC-123")
            >>> # Changelog + filter
            >>> issue = await jc.read_issue("ABC-123", read_changelog=True, changelog_filter=["status"])
            >>> # With comments and worklog
            >>> issue = await jc.read_issue("ABC-123", read_comments=True, read_worklog=True)
        """
        url = f"{self.base_issue_url}/{issue_id}"
        if read_changelog:
            url = f"{url}?expand=changelog"

        issue_data, worklog, comments = await asyncio.gather(
            self._fetch_json(url),
            self._read_issue_worklog(issue_id) if read_worklog else _noop(),
            self._read_issue_comments(issue_id) if read_comments else _noop(),
            return_exceptions=True)

        if issue_data and "fields" in issue_data:
            issue_data["fields"]["worklog"] = worklog if worklog else {}
            issue_data["fields"]["comment"] = comments if comments else {}

            if read_changelog and changelog_filter and len(changelog_filter) > 0:
                changelog_filter_lower = [item.lower() for item in changelog_filter]

                filtered_changelog = []
                for log in issue_data["changelog"]["histories"]:
                    matching_items = [
                        item for item in log["items"]
                        if item["field"].lower() in changelog_filter_lower
                    ]
                    if matching_items:
                        filtered_log = dict(log)  # shallow copy to avoid mutating original
                        filtered_log["items"] = matching_items
                        filtered_changelog.append(filtered_log)

                issue_data["changelog"]["histories"] = filtered_changelog

            return issue_data
        else:
            self._log_error(f"Could not fetch issue {issue_id}")

        return None

    async def read_board_id(self, board_name: str) -> int | None:
        """
        Retrieve the ID of a Jira board by its exact name.

        Args:
            board_name: Board name to search for (exact match against returned values).

        Returns:
            The board ID if found, otherwise ``None``.

        Raises:
            RuntimeError: If the client session is not initialized.
            aiohttp.ClientConnectionError: For connection-level errors.
            aiohttp.ClientResponseError: For invalid HTTP responses (when raised by aiohttp).
            aiohttp.ClientPayloadError: For invalid payload / decoding issues.
            aiohttp.ClientError: For other aiohttp client errors.
            Exception: Re-raises unexpected exceptions after logging.

        Examples:
            >>> board_id = await jc.read_board_id("My Scrum Board")
            >>> isinstance(board_id, int) or (board_id is None)
        """
        url = f"{self.base_board_url}?name={board_name}"
        response = await self._fetch_json(url)

        if response and len(response) > 0:
            for board in response["values"]:
                if board["name"] == board_name:
                    self._log(f"Read board ID ({int(board['id'])}) for board `{board_name}`")
                    return int(board["id"])
        else:
            self._log_error(f"Could not retrieve ID for board `{board_name}`")

        return None

    async def read_sprint_list(self,
                               board_id: int,
                               origin_board: Optional[bool] = False,
                               name_filter: Optional[str] = None
        ) -> List[Dict[str, Any]]:
        """
        Retrieve active and closed sprints for a board (with optional filtering).

        This paginates over the Agile endpoint and collects sprints with state
        ``active`` or ``closed``.

        Args:
            board_id: Jira board ID.
            origin_board: If True, only include sprints whose ``originBoardId`` equals ``board_id``.
            name_filter: If provided, only include sprints whose ``name`` contains this substring.

        Returns:
            List of sprint dictionaries as returned by Jira.
            Note: On failure this implementation returns ``None`` (despite the type annotation).

        Raises:
            RuntimeError: If the client session is not initialized.
            aiohttp.ClientConnectionError: For connection-level errors.
            aiohttp.ClientResponseError: For invalid HTTP responses (when raised by aiohttp).
            aiohttp.ClientPayloadError: For invalid payload / decoding issues.
            aiohttp.ClientError: For other aiohttp client errors.
            Exception: Re-raises unexpected exceptions after logging.

        Examples:
            >>> sprints = await jc.read_sprint_list(123)
            >>> sprints = await jc.read_sprint_list(123, origin_board=True, name_filter="2026")
        """
        sprint_list = []
        start_at = 0
        batch_size = 50  # Jira API limit per request

        while True:
            url = f"{self.base_board_url}/{board_id}/sprint?state=active,closed&startAt={start_at}&maxResults={batch_size}"

            response_data = await self._fetch_json(url)
            if not response_data or "values" not in response_data:
                self._log_error(f"Failed to retrieve sprints for board {board_id}")
                return None

            # Extract sprints
            if origin_board:
                batch_sprints = [sprint for sprint in response_data["values"] if int(sprint["originBoardId"]) == board_id]
            else:
                batch_sprints = [sprint for sprint in response_data["values"]]

            if name_filter:
                batch_sprints = [sprint for sprint in batch_sprints if name_filter in sprint["name"]]

            sprint_list.extend(batch_sprints)

            # Pagination check: Stop if fewer results than batch size
            if len(response_data["values"]) < batch_size:
                break  # No more sprints left to fetch

            # Move to the next batch
            start_at += batch_size

        self._log(f"Read {len(sprint_list)} sprints for board `{board_id}`")
        return sprint_list

    async def read_project_release_list(self, project_id: str) -> List[Dict[str, Any]] | None:
        """
        Retrieve the release list (fix versions) for a Jira project.

        Uses the endpoint:
        ``/rest/api/2/project/{project_id}/versions``.

        Args:
            project_id: Jira project key or ID (as accepted by the endpoint), e.g. ``"ABC"``.

        Returns:
            A list of version objects (dictionaries) on success, otherwise ``None``.

        Raises:
            RuntimeError: If the client session is not initialized.
            aiohttp.ClientConnectionError: For connection-level errors.
            aiohttp.ClientResponseError: For invalid HTTP responses (when raised by aiohttp).
            aiohttp.ClientPayloadError: For invalid payload / decoding issues.
            aiohttp.ClientError: For other aiohttp client errors.
            Exception: Re-raises unexpected exceptions after logging.

        Examples:
            >>> versions = await jc.read_project_release_list("ABC")
            >>> isinstance(versions, list) or (versions is None)
        """
        url = f"{self.base_project_url}/{project_id}/versions"
        response = await self._fetch_json(url)

        if response and len(response) > 0:
            return response
        else:
            self._log_error(f"Could not retrieve version list for project `{project_id}`")

        return None

    async def send_request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, str]] = None,
        headers: Optional[Dict[str, str]] = None,
        allow_redirects: bool = True,
    ) -> Optional[Dict[str, Any]]:
        """
        Send a raw HTTP request to Jira and (optionally) decode JSON.

        This is a more general helper than :meth:`_fetch_json`:
        - Supports any HTTP method (GET/POST/PUT/DELETE/etc.).
        - Allows adding query params, extra headers, and JSON body.
        - Treats HTTP 200/201/204 as success.
        - For 204 or empty body, returns ``None``.

        Args:
            method: HTTP method (e.g. ``"GET"``, ``"POST"``).
            path: Full URL or relative path. If not starting with ``http``, it will be
                joined with ``jira_url``.
                Example: ``"/rest/api/2/issue"``.
            json: JSON body for POST/PUT/PATCH requests (passed to ``aiohttp``).
            params: URL query parameters.
            headers: Additional headers merged on top of default auth headers.
            allow_redirects: Whether to follow redirects.

        Returns:
            Decoded JSON response as a dict when present, otherwise ``None``.
            On non-success HTTP status, logs the response text and returns ``None``.

        Raises:
            RuntimeError: If session is not started.
            Exception: Re-raises any unexpected exception after logging (including ``aiohttp`` errors).

        Examples:
            >>> # Create an issue (example payload shape will depend on your Jira)
            >>> payload = {"fields": {"project": {"key": "ABC"}, "summary": "Test", "issuetype": {"name": "Task"}}}
            >>> resp = await jc.send_request("POST", "/rest/api/2/issue", json=payload)
            >>> # Transition an issue (example)
            >>> resp = await jc.send_request("POST", "/rest/api/2/issue/ABC-123/transitions", json={"transition": {"id": "31"}})
        """
        if self.session is None:
            raise RuntimeError("Session not started. Call `await start_session()`.")

        url = path if path.startswith("http") else f"{self.jira_url.rstrip('/')}/{path.lstrip('/')}"
        merged_headers = {**self.headers, **(headers or {})}

        try:
            async with self.session.request(
                method=method,
                url=url,
                headers=merged_headers,
                json=json,
                params=params,
                allow_redirects=allow_redirects,
            ) as resp:

                if resp.status in (200, 201, 204):
                    if resp.content_length == 0 or resp.status == 204:
                        return None

                    return await resp.json()
                else:
                    text = await resp.text()
                    self._log_error(f"{method} {url} failed: {resp.status} - {text}")
        except Exception as e:
            self._log_exception(f"Error with {method} {url}: {e}")
            raise

        return None
