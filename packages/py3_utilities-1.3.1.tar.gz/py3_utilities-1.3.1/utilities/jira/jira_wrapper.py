import asyncio as aio

from typing import Optional, Dict, Any, List

from .jira_client import JiraClient
from ..utility_base import UtilityBase


class JiraWrapper(UtilityBase):
    """
    Manage concurrent Jira issue fetching, JQL queries, and session handling.

    Args:
        api_token: Jira API token for authentication.
        jira_url: Base URL of the Jira instance.
        max_concurrent_requests: Maximum number of concurrent API requests.
        max_retry_count: Number of retries for failed requests.
        max_issues_per_file: Reserved for callers that chunk results externally (not used in this class).
        verbose: Enable verbose logging.
        ssl_verify: Enable SSL verification.
        logger: Custom logger instance.
        log_level: Custom log level.

    Raises:
        Exception: Any exception raised by UtilityBase/JiraClient initialization.

    Examples:
        >>> wrapper = JiraWrapper("TOKEN", "https://my-jira.net")
    """

    def __init__(
        self,
        api_token: str,
        jira_url: str,
        max_concurrent_requests: int = 50,
        max_retry_count: int = 3,
        max_issues_per_file: int = 10000,
        verbose: Optional[bool] = None,
        ssl_verify: Optional[bool] = True,
        logger: Optional[Any] = None,
        log_level: Optional[int] = None
    ) -> None:
        super().__init__(verbose, logger, log_level)

        self.max_concurrent_requests = max_concurrent_requests
        self.max_retry_count = max_retry_count
        self.max_issues_per_file = max_issues_per_file

        self.jira_client = JiraClient(
            api_key=api_token,
            jira_url=jira_url,
            ssl_verify=ssl_verify,
            retry_cnt=max_retry_count,
            logger=logger,
            log_level=log_level,
            log_urls=False,
            verbose=verbose
        )

    async def _fetch_issue(
        self,
        issue_key: str,
        semaphore: aio.Semaphore,
        read_changelog: Optional[bool] = False,
        read_comments: Optional[bool] = False,
        read_worklog: Optional[bool] = False,
        changelog_filter: Optional[List[str]] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Fetch a single Jira issue with concurrency limiting and retry.

        Args:
            issue_key: Jira issue key (e.g. "ABC-123").
            semaphore: Semaphore used to limit concurrent requests.
            read_changelog: If True, include changelog in the response.
            read_comments: If True, include comments in the response.
            read_worklog: If True, include worklog in the response.
            changelog_filter: Optional list of changelog field names to include.

        Returns:
            The issue payload as a dict if found; otherwise None.

        Raises:
            asyncio.CancelledError: If the task is cancelled.
            Exception: Propagates exceptions raised by JiraClient.read_issue.

        Examples:
            >>> sem = aio.Semaphore(10)
            >>> issue = await wrapper._fetch_issue("ABC-123", sem, read_comments=True)
            >>> issue["key"]
            'ABC-123'
        """

        fetched_issue = None
        retry_cnt = 0

        async with semaphore:
            while not fetched_issue and retry_cnt < self.max_retry_count:
                retry_cnt += 1
                fetched_issue = await self.jira_client.read_issue(
                    issue_id=issue_key,
                    read_changelog=read_changelog,
                    read_comments=read_comments,
                    read_worklog=read_worklog,
                    changelog_filter=changelog_filter,
                )

        return fetched_issue

    async def _fetch_issues_in_batches(
        self,
        issue_keys: List[str],
        read_changelog: Optional[bool] = False,
        read_comments: Optional[bool] = False,
        read_worklog: Optional[bool] = False,
        changelog_filter: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Fetch multiple Jira issues concurrently, filtering out failed/invalid results.

        Args:
            issue_keys: List of Jira issue keys to fetch.
            read_changelog: If True, include changelog in each issue.
            read_comments: If True, include comments in each issue.
            read_worklog: If True, include worklog in each issue.
            changelog_filter: Optional list of changelog field names to include.

        Returns:
            A list of issue dicts. Only results that are dicts and contain "fields"
            are included.

        Raises:
            asyncio.CancelledError: If the task is cancelled.
            Exception: Propagates exceptions raised by JiraClient.read_issue
                (exceptions returned by gather are filtered out).

        Examples:
            >>> issues = await wrapper._fetch_issues_in_batches(["ABC-1", "ABC-2"])
            >>> [i["key"] for i in issues]
            ['ABC-1', 'ABC-2']
        """
        semaphore = aio.Semaphore(self.max_concurrent_requests)
        tasks = [
            self._fetch_issue(
                issue_key=key,
                semaphore=semaphore,
                read_changelog=read_changelog,
                read_comments=read_comments,
                read_worklog=read_worklog,
                changelog_filter=changelog_filter,
            ) for key in issue_keys
        ]

        issues = []
        for batch_start in range(0, len(tasks), self.max_concurrent_requests):
            batch = tasks[batch_start: batch_start + self.max_concurrent_requests]
            results = await aio.gather(*batch, return_exceptions=True)

            issues.extend(issue for issue in results if isinstance(issue, dict) and "fields" in issue)

        return issues

    async def read_issues_jql(
        self,
        custom_jql: str,
        read_changelog: Optional[bool] = False,
        read_comments: Optional[bool] = False,
        read_worklog: Optional[bool] = False,
        changelog_filter: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Fetch all issues matching a JQL query.

        This method manages the Jira session lifecycle internally.

        Args:
            custom_jql: JQL query string.
            read_changelog: If True, include changelog in each issue.
            read_comments: If True, include comments in each issue.
            read_worklog: If True, include worklog in each issue.
            changelog_filter: Optional list of changelog field names to include.

        Returns:
            A list of issue dicts. Returns an empty list if the JQL matches no issues.

        Raises:
            asyncio.CancelledError: If the task is cancelled.
            Exception: Propagates exceptions raised by JiraClient session methods or
                JiraClient.read_custom_jql_keys / JiraClient.read_issue.

        Examples:
            >>> issues = await wrapper.read_issues_jql("project = ABC AND status = Done")
            >>> len(issues) >= 0
            True
        """

        await self.jira_client.start_session()
        issue_keys = await self.jira_client.read_custom_jql_keys(custom_jql)

        if not issue_keys:
            await self.jira_client.close_session()
            return []

        issues = await self._fetch_issues_in_batches(
            issue_keys=issue_keys,
            read_changelog=read_changelog,
            read_comments=read_comments,
            read_worklog=read_worklog,
            changelog_filter=changelog_filter,
        )

        await self.jira_client.close_session()

        return issues

    async def read_issue(
        self,
        issue_key: str,
        read_changelog: Optional[bool] = False,
        read_comments: Optional[bool] = False,
        read_worklog: Optional[bool] = False,
        changelog_filter: Optional[List[str]] = None,
    ) -> None:
        """
        Fetch a single Jira issue by key.

        This method manages the Jira session lifecycle internally.

        Args:
            issue_key: Jira issue key (e.g. "ABC-123").
            read_changelog: If True, include changelog in the response.
            read_comments: If True, include comments in the response.
            read_worklog: If True, include worklog in the response.
            changelog_filter: Optional list of changelog field names to include.

        Returns:
            The issue dict if found; otherwise None.

        Raises:
            asyncio.CancelledError: If the task is cancelled.
            Exception: Propagates exceptions raised by JiraClient session methods or
                JiraClient.read_issue.

        Examples:
            >>> issue = await wrapper.read_issue("ABC-123", read_comments=True)
            >>> issue["key"]
            'ABC-123'
        """

        await self.jira_client.start_session()

        issues = await self._fetch_issues_in_batches(
            issue_keys=[issue_key],
            read_changelog=read_changelog,
            read_comments=read_comments,
            read_worklog=read_worklog,
            changelog_filter=changelog_filter,
        )

        await self.jira_client.close_session()

        return issues[0] if issues else None

    async def read_issues(
        self,
        issue_keys: List[str],
        read_changelog: Optional[bool] = False,
        read_comments: Optional[bool] = False,
        read_worklog: Optional[bool] = False,
        changelog_filter: Optional[List[str]] = None,
    ) -> None:
        """
        Fetch multiple Jira issues by key.

        This method manages the Jira session lifecycle internally.

        Args:
            issue_keys: List of Jira issue keys to fetch.
            read_changelog: If True, include changelog in each issue.
            read_comments: If True, include comments in each issue.
            read_worklog: If True, include worklog in each issue.
            changelog_filter: Optional list of changelog field names to include.

        Returns:
            A list of issue dicts. Returns an empty list if `issue_keys` is empty.

        Raises:
            asyncio.CancelledError: If the task is cancelled.
            Exception: Propagates exceptions raised by JiraClient session methods or
                JiraClient.read_issue.

        Examples:
            >>> issues = await wrapper.read_issues(["ABC-1", "ABC-2"])
            >>> [i["key"] for i in issues]
            ['ABC-1', 'ABC-2']
        """
        if not issue_keys:
            return []

        await self.jira_client.start_session()

        issues = await self._fetch_issues_in_batches(
            issue_keys=issue_keys,
            read_changelog=read_changelog,
            read_comments=read_comments,
            read_worklog=read_worklog,
            changelog_filter=changelog_filter,
        )

        await self.jira_client.close_session()
        return issues

    async def read_keys_jql(self, custom_jql: str) -> List[str]:
        """
        Get all issue keys matching a JQL query.

        This method manages the Jira session lifecycle internally.

        Args:
            custom_jql: JQL query string.

        Returns:
            List of Jira issue keys. Returns an empty list if nothing matches.

        Raises:
            asyncio.CancelledError: If the task is cancelled.
            Exception: Propagates exceptions raised by JiraClient session methods or
                JiraClient.read_custom_jql_keys.

        Examples:
            >>> keys = await wrapper.read_keys_jql("project = ABC AND status != Done")
            >>> isinstance(keys, list)
            True
        """
        await self.jira_client.start_session()

        issue_keys = await self.jira_client.read_custom_jql_keys(custom_jql)

        await self.jira_client.close_session()
        return issue_keys

    async def read_issue_children_keys(self, issue_id: str) -> Dict[str, List[str]]:
        """
        Get linked/child issue keys for a given issue.

        This method manages the Jira session lifecycle internally.

        Args:
            issue_id: Parent issue key/id (e.g. "ABC-123").

        Returns:
            Mapping of link type -> list of issue keys.

        Raises:
            asyncio.CancelledError: If the task is cancelled.
            Exception: Propagates exceptions raised by JiraClient session methods or
                JiraClient.read_linked_issue_keys.

        Examples:
            >>> children = await wrapper.read_issue_children_keys("ABC-123")
            >>> isinstance(children, dict)
            True
        """
        await self.jira_client.start_session()

        issue_keys = await self.jira_client.read_linked_issue_keys(issue_id)

        await self.jira_client.close_session()
        return issue_keys

    async def read_epic_children_keys(self, epic_id: str) -> List[str]:
        """
        Get issue keys linked to a Jira epic.

        This method manages the Jira session lifecycle internally.

        Args:
            epic_id: Epic issue key/id (e.g. "ABC-EPIC-1" or "ABC-123").

        Returns:
            List of Jira issue keys linked to the epic. May be empty.

        Raises:
            asyncio.CancelledError: If the task is cancelled.
            Exception: Propagates exceptions raised by JiraClient session methods or
                JiraClient.read_linked_epic_keys.

        Examples:
            >>> keys = await wrapper.read_epic_children_keys("ABC-1000")
            >>> isinstance(keys, list)
            True
        """
        await self.jira_client.start_session()

        epic_keys = await self.jira_client.read_linked_epic_keys(epic_id)

        await self.jira_client.close_session()
        return epic_keys

    async def read_sprint_list(
        self,
        board_name: str,
        origin_board: Optional[bool] = False,
        name_filter: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Retrieve the sprint list for a Jira board.

        This method manages the Jira session lifecycle internally.

        Args:
            board_name: Exact Jira board name.
            origin_board: If True, request sprints only from the origin board (if supported by client).
            name_filter: If provided, filter sprints by name substring.

        Returns:
            List of sprint dicts (may be empty).

        Raises:
            asyncio.CancelledError: If the task is cancelled.
            Exception: Propagates exceptions raised by JiraClient session methods or
                JiraClient.read_board_id / JiraClient.read_sprint_list.

        Examples:
            >>> sprints = await wrapper.read_sprint_list("MY BOARD", name_filter="2026")
            >>> isinstance(sprints, list)
            True
        """
        await self.jira_client.start_session()

        board_id = await self.jira_client.read_board_id(board_name)
        sprint_list = await self.jira_client.read_sprint_list(board_id, origin_board, name_filter)

        await self.jira_client.close_session()
        return sprint_list

    async def read_project_release_list(self, project_id: str) -> List[Dict[str, Any]] | None:
        """
        Retrieve the release list (fix versions) for a Jira project.

        This method manages the Jira session lifecycle internally.

        Args:
            project_id: Jira project key or numeric project id.

        Returns:
            List of version dicts on success; otherwise None.

        Raises:
            asyncio.CancelledError: If the task is cancelled.
            Exception: Propagates exceptions raised by JiraClient session methods or
                JiraClient.read_project_release_list.

        Examples:
            >>> versions = await wrapper.read_project_release_list("ABC")
            >>> versions is None or isinstance(versions, list)
            True
        """
        await self.jira_client.start_session()
        versions = await self.jira_client.read_project_release_list(project_id)
        await self.jira_client.close_session()
        return versions

    async def read_board_id(self, board_name: str) -> int | None:
        """
        Retrieve the board id for an exact Jira board name.

        This method manages the Jira session lifecycle internally.

        Args:
            board_name: Exact Jira board name.

        Returns:
            Board id if found; otherwise None.

        Raises:
            asyncio.CancelledError: If the task is cancelled.
            Exception: Propagates exceptions raised by JiraClient session methods or
                JiraClient.read_board_id.

        Examples:
            >>> board_id = await wrapper.read_board_id("MY BOARD")
            >>> board_id is None or isinstance(board_id, int)
            True
        """
        await self.jira_client.start_session()
        board_id = await self.jira_client.read_board_id(board_name)
        await self.jira_client.close_session()
        return board_id

    async def send_request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, str]] = None,
        headers: Optional[Dict[str, str]] = None,
        allow_redirects: bool = True,
    ) -> Optional[Dict[str, Any]]:
        """
        Send a raw HTTP request to Jira and (optionally) decode JSON.

        This is a thin wrapper over JiraClient.send_request that manages session lifecycle.

        Args:
            method: HTTP method (e.g. "GET", "POST").
            path: Jira API path (relative to Jira base URL), as expected by JiraClient.
            json: Optional JSON body to send.
            params: Optional query parameters.
            headers: Optional request headers.
            allow_redirects: Whether to allow redirects.

        Returns:
            Decoded JSON response as a dict when available; otherwise whatever JiraClient returns
            (commonly None on failure / non-JSON).

        Raises:
            asyncio.CancelledError: If the task is cancelled.
            Exception: Propagates exceptions raised by JiraClient session methods or
                JiraClient.send_request.

        Examples:
            >>> resp = await wrapper.send_request("GET", "/rest/api/3/myself")
            >>> resp is None or isinstance(resp, dict)
            True
        """
        await self.jira_client.start_session()
        resp = await self.jira_client.send_request(
            method=method,
            path=path,
            json=json,
            params=params,
            headers=headers,
            allow_redirects=allow_redirects,
        )
        await self.jira_client.close_session()
        return resp
