import logging
import warnings
import sys

from types import SimpleNamespace
from typing import Optional, Any, List

from .logger import Logger
from .log_decorator import LogDecorator
from .log_wrapper import LogWrapper

"""
Logging package initializer.

This module exposes:

- :class:`~.logger.Logger`
- :class:`~.log_decorator.LogDecorator`
- :class:`~.log_wrapper.LogWrapper`
- ``log``: an (initially empty) registry object intended to hold configured loggers
  as nested attributes (e.g. ``log.app``, ``log.jobs.daily``).

No loggers are created at import time.

Use :func:`init_logging` to load configuration (via ``..config.parse_config``) and
populate a logger registry. If configuration cannot be loaded or no ``logging`` section
exists, the returned registry will be empty and a :class:`RuntimeWarning` is emitted.

Examples:
    >>> from yourpkg.logging import init_logging
    >>> log = init_logging()
    >>> # if config defines `app`:
    >>> log.app.info("hello")
    >>> @log.app
    ... def work(x):
    ...     return x + 1
    >>> work(1)
    2
"""

__all__ = [
    "Logger",
    "LogDecorator",
    "LogWrapper",
    "init_logging",
]


def _orange_warning(message, category, filename, lineno, file=None, line=None):
    """Custom warning formatter (no source line, orange text)."""
    _ORANGE = "\033[33m"
    _RESET = "\033[0m"

    stream = file if file is not None else sys.stderr
    stream.write(f"{_ORANGE}{category.__name__}: {message}{_RESET}\n")


def _flatten_loggers(config_section: SimpleNamespace, prefix: Optional[str] = None):
    """
    Flatten a nested logger configuration tree into a flat ``dict``.

    The input is expected to be a nested :class:`types.SimpleNamespace` structure where
    intermediate nodes represent groups and leaf nodes represent a logger configuration.
    Returned keys are dot-separated paths (e.g. ``"app"``, ``"jobs.daily"``).

    Args:
        config_section:
            The logger configuration namespace to flatten (usually ``config.logging.loggers``).
        prefix:
            Optional prefix to prepend while recursing. Used internally.

    Returns:
        A mapping ``{full_logger_name: config_namespace}`` where ``full_logger_name`` is
        the dot-separated logger name and ``config_namespace`` is the leaf configuration
        :class:`types.SimpleNamespace`.

    Raises:
        AttributeError:
            If ``config_section`` does not provide a ``__dict__`` (i.e. not namespace-like).

    Examples:
        >>> from types import SimpleNamespace
        >>> cfg = SimpleNamespace(app=SimpleNamespace(enabled=True), jobs=SimpleNamespace(daily=SimpleNamespace(enabled=False)))
        >>> flat = flatten_loggers(cfg)
        >>> sorted(flat.keys())
        ['app', 'jobs.daily']
    """
    flat = {}
    for key, val in config_section.__dict__.items():
        full_key = f"{prefix}.{key}" if prefix else key

        if hasattr(val, "__dict__"):
            flat.update(_flatten_loggers(val, full_key))
        else:
            flat[prefix] = config_section
            break

    return flat


def _set_nested_attr(obj: SimpleNamespace, path: str, value: Any):
    """
    Set a value on a dotted attribute path, creating intermediate namespaces as needed.

    This is used to populate the public ``log`` registry so that names like
    ``"jobs.daily"`` become accessible as ``log.jobs.daily``.

    Args:
        obj:
            Root object to assign attributes on (typically a registry object returned by
            :func:`init_logging`).
        path:
            Dot-separated path specifying the nested attribute (e.g. ``"jobs.daily"``).
        value:
            Value assigned at the final attribute.

    Returns:
        None.

    Raises:
        AttributeError:
            If an intermediate attribute exists but cannot be traversed/assigned.
        TypeError:
            If ``path`` is not a string or cannot be split as expected.

    Examples:
        >>> from types import SimpleNamespace
        >>> root = SimpleNamespace()
        >>> set_nested_attr(root, "a.b.c", 123)
        >>> root.a.b.c
        123
    """
    parts = path.split(".")
    current = obj

    for part in parts[:-1]:
        if not hasattr(current, part):
            setattr(current, part, SimpleNamespace())
        current = getattr(current, part)

    setattr(current, parts[-1], value)


def init_logging(
        config_paths: Optional[List[str]] = None,
        whitelist: Optional[List[str]] = None,
        switch_cwd: bool = False,
        restore_cwd: bool = False,
    ):
    """
    Initialize loggers from framework configuration and return a logger registry.

    This function attempts to import and call ``..config.parse_config`` and looks for a
    ``logging`` section. If configured loggers exist, it creates:

    - a :class:`~.logger.Logger` instance per configured logger,
    - a :class:`~.log_decorator.LogDecorator` attached to that logger,
    - a :class:`~.log_wrapper.LogWrapper` exposing both decorator behavior and direct logging.

    The resulting registry supports both:
    - direct logging: ``log.app.info("...")``
    - decoration: ``@log.app``

    If configuration cannot be imported/loaded, or no logging section exists, this returns
    an empty registry and emits a :class:`RuntimeWarning`.

    Args:
        config_paths:
            Passed through to ``parse_config``. If provided, these paths are used to
            locate configuration files/modules.
        whitelist:
            Passed through to ``parse_config``. If provided, only these config sections
            are loaded.
        switch_cwd:
            Passed through to ``parse_config``. If your config loader needs to change working
            directory to locate the config, set this to ``True``.
        restore_cwd:
            Passed through to ``parse_config``. If ``switch_cwd`` is ``True``, this controls
            whether the original working directory is restored afterwards.

    Returns:
        A registry object (same shape as the module-level ``log``), populated with configured
        loggers as nested attributes.

    Raises:
        RuntimeError:
            Not raised intentionally, but may propagate if logger initialization fails in
            :class:`~.logger.Logger` or :class:`~.log_decorator.LogDecorator` due to invalid
            configuration values.

    Warnings:
        RuntimeWarning:
            Emitted when config cannot be imported/loaded or when no ``logging`` section is found.

    Examples:
        >>> from yourpkg.logging import init_logging
        >>> log = init_logging()
        >>> # if config defines `app`:
        >>> log.app.info("started")

        >>> @log.app
        ... def add(a, b):
        ...     return a + b
        >>> add(1, 2)
        3
    """
    registry = type("LoggerRegistry", (), {})()

    # Install custom warning formatting only for the duration of this call
    prev_showwarning = warnings.showwarning
    warnings.showwarning = _orange_warning

    try:
        from ..config import parse_config
        _config = parse_config(
            config_paths=config_paths,
            whitelist=whitelist,
            switch_cwd=switch_cwd, 
            restore_cwd=restore_cwd
        )
        if not hasattr(_config, "logging"):
            warnings.warn("No 'logging' section found in config; logging registry will be empty.", RuntimeWarning, stacklevel=2)
            return registry
    except (ImportError, ModuleNotFoundError) as e:
        warnings.warn(f"Could not import config parser; logging registry will be empty: {e.__class__.__name__}: {e}", RuntimeWarning, stacklevel=2)
        return registry
    except Exception as e:
        warnings.warn(f"Could not load config; logging registry will be empty: {e.__class__.__name__}: {e}", RuntimeWarning, stacklevel=2)
        return registry
    
    finally:
        warnings.showwarning = prev_showwarning

    logging_config = _config.logging

    # --- Global ---
    root_folder = getattr(logging_config, "root_folder", "logs")
    cleanup_old_logs = getattr(logging_config, "cleanup_old_logs", False)
    cleanup_days = getattr(logging_config, "cleanup_days", 7)

    if cleanup_old_logs:
        Logger.cleanup_old_logs(
            base_log_dir=root_folder,
            name="*",
            days=cleanup_days,
            verbose=False
        )

    if not hasattr(logging_config, "loggers"):
        warnings.showwarning = _orange_warning
        warnings.warn("Config has 'logging' section but no 'logging.loggers' section; logging registry will be empty.", RuntimeWarning, stacklevel=2)
        warnings.showwarning = prev_showwarning

        return registry

    loggers_list = _flatten_loggers(logging_config.loggers)

    for logger_name, cfg in loggers_list.items():
        enabled = getattr(cfg, "enabled", False)

        clear_handlers = getattr(cfg, "clear_handlers", False)

        # --- Console ---
        console_output = getattr(cfg, "console_output", True)
        console_log_level_str = getattr(cfg, "console_log_level", "DEBUG").upper()
        console_log_level = getattr(logging, console_log_level_str, logging.INFO)
        console_timestamp_format = getattr(cfg, "console_timestamp_format", None)

        # --- File ---
        file_output = getattr(cfg, "file_output", False)
        file_log_level_str = getattr(cfg, "file_log_level", "INFO").upper()
        file_log_level = getattr(logging, file_log_level_str, logging.INFO)
        file_rotation_time_based = getattr(cfg, "file_rotation_time", True)
        file_rotation_when = getattr(cfg, "file_rotation_when", "midnight")
        file_rotation_interval = getattr(cfg, "file_rotation_interval", 1)
        file_rotation_backup_count = getattr(cfg, "file_rotation_backup_count", 7)
        file_timestamp_format = getattr(cfg, "file_timestamp_format", None)

        # --- JSON ---
        json_output = getattr(cfg, "json_output", False)
        json_log_level_str = getattr(cfg, "json_log_level", "INFO").upper()
        json_log_level = getattr(logging, json_log_level_str, logging.INFO)
        json_rotation_time_based = getattr(cfg, "json_rotation_time", True)
        json_rotation_when = getattr(cfg, "json_rotation_when", "midnight")
        json_rotation_interval = getattr(cfg, "json_rotation_interval", 1)
        json_rotation_backup_count = getattr(cfg, "json_rotation_backup_count", 7)
        json_timestamp_format = getattr(cfg, "json_timestamp_format", None)

        # --- Decorator ---
        decorator_sensitive_params = getattr(cfg, "decorator_sensitive_params", [])
        decorator_raise_exception = getattr(cfg, "decorator_raise_exception", False)
        decorator_log_level_str = getattr(cfg, "decorator_log_level", "DEBUG").upper()
        decorator_log_level = getattr(logging, decorator_log_level_str, logging.INFO)
        decorator_max_log_length = getattr(cfg, "decorator_max_log_length", 500)
        decorator_log_arguments = getattr(cfg, "decorator_log_arguments", False)
        decorator_tag = getattr(cfg, "decorator_tag", "decorator")
        decorator_warn_duration = getattr(cfg, "decorator_warn_duration", None)
        decorator_log_stack = getattr(cfg, "decorator_log_stack", False)
        decorator_log_return_value = getattr(cfg, "decorator_log_return_value", False)
        decorator_log_execution_time = getattr(cfg, "decorator_log_execution_time", False)

        if not enabled:
            file_output = False
            json_output = False
            console_output = False
            clear_handlers = False

        logger = Logger(
            name=logger_name,
            base_log_dir=root_folder,
            clear_handlers=clear_handlers,

            # Console
            console_output=console_output,
            console_log_level=console_log_level,
            console_timestamp_format=console_timestamp_format,

            # File
            file_output=file_output,
            file_log_level=file_log_level,
            file_rotation_time_based=file_rotation_time_based,
            file_rotation_when=file_rotation_when,
            file_rotation_interval=file_rotation_interval,
            file_rotation_backup_count=file_rotation_backup_count,
            file_timestamp_format=file_timestamp_format,

            # JSON
            json_output=json_output,
            json_log_level=json_log_level,
            json_rotation_time_based=json_rotation_time_based,
            json_rotation_when=json_rotation_when,
            json_rotation_interval=json_rotation_interval,
            json_rotation_backup_count=json_rotation_backup_count,
            json_timestamp_format=json_timestamp_format,
        )

        decorator = LogDecorator(
            logger=logger.get_logger(),
            raise_exception=decorator_raise_exception,
            log_level=decorator_log_level,
            max_log_length=decorator_max_log_length,
            sensitive_params=decorator_sensitive_params,
            default_return=None,
            log_arguments=decorator_log_arguments,
            tag=decorator_tag,
            warn_duration=decorator_warn_duration,
            log_stack=decorator_log_stack,
            log_return=decorator_log_return_value,
            log_execution_time=decorator_log_execution_time
        )

        wrapper = LogWrapper(decorator=decorator, logger=logger)
        _set_nested_attr(registry, logger_name, wrapper)

    return registry
