import logging
import functools
import time
import inspect
import traceback

from typing import Callable, Any, Union, Optional, List, TypeVar, ParamSpec

from .logger import Logger

P = ParamSpec("P")
R = TypeVar("R")


class LogDecorator:
    def __init__(
        self,
        logger: Union[logging.Logger, Logger],
        raise_exception: bool = True,
        log_level: int = logging.INFO,
        max_log_length: int = 500,
        sensitive_params: Optional[List[str]] = None,
        default_return: Any = None,
        log_arguments: bool = False,
        tag: Optional[str] = None,
        warn_duration: Optional[float] = None,
        log_stack: bool = False,
        log_return: bool = False,
        log_execution_time: bool = False
    ) -> None:
        """
        Configure a decorator that logs function calls, optional arguments/returns,
        execution time, and exceptions.

        The resulting instance is callable and can be used as a decorator for both
        synchronous and asynchronous functions. Behavior is controlled via the
        initialization parameters (e.g., whether to log arguments, whether to
        re-raise exceptions, etc.).

        Args:
            logger:
                A standard :class:`logging.Logger` or the framework's :class:`~.logger.Logger`.
                If a framework ``Logger`` is provided, its underlying stdlib logger is used.
            raise_exception:
                If ``True`` (default), re-raise any exception after logging it.
                If ``False``, swallow the exception and return ``default_return``.
            log_level:
                Logging level used for routine call/return messages (default: ``logging.INFO``).
            max_log_length:
                Maximum number of characters to include for any argument/return value string
                representation before truncation.
            sensitive_params:
                Names of parameters whose values should be masked as ``[FILTERED]`` in logs.
                Matching is done against the bound parameter names from the target function
                signature.
            default_return:
                Value returned when an exception occurs and ``raise_exception`` is ``False``.
            log_arguments:
                If ``True``, log formatted positional and keyword arguments at call time.
            tag:
                Optional tag prefix. If provided, logs are prefixed with ``"[{tag}] "``.
            warn_duration:
                If provided, emit a warning when execution time exceeds this threshold
                (in seconds).
            log_stack:
                If ``True``, log a trimmed call stack at DEBUG level on entry (and at exception).
            log_return:
                If ``True``, log the return value (truncated if needed).
            log_execution_time:
                If ``True``, log execution duration for each call.

        Raises:
            ValueError:
                If ``logger`` is ``None`` or otherwise falsy.

        Examples:
            Basic usage with stdlib logger:

            >>> import logging
            >>> log = logging.getLogger("demo")
            >>> deco = LogDecorator(log, log_arguments=True, log_return=True)
            >>> @deco
            ... def add(a, b):
            ...     return a + b
            >>> add(1, 2)
            3

            Masking sensitive parameters:

            >>> deco = LogDecorator(log, log_arguments=True, sensitive_params=["password"])
            >>> @deco
            ... def login(user, password):
            ...     return True
            >>> login("alice", "secret")
            True

            Swallowing exceptions:

            >>> deco = LogDecorator(log, raise_exception=False, default_return="fallback")
            >>> @deco
            ... def boom():
            ...     raise RuntimeError("x")
            >>> boom()
            'fallback'
        """
        if isinstance(logger, Logger):
            self.logger = logger.get_logger()
        elif logger:
            self.logger = logger
        else:
            raise ValueError("Logger cannot be None")

        self.raise_exception = raise_exception
        self.log_level = log_level
        self.max_log_length = max_log_length
        self.sensitive_params = set(sensitive_params or [])
        self.default_return = default_return
        self.tag = f"[{tag}] " if tag else ""
        self.warn_duration = warn_duration
        self.log_arguments = log_arguments
        self.log_stack = log_stack
        self.log_return = log_return
        self.log_execution_time = log_execution_time

    def _truncate(self, value: Any) -> str:
        """
        Convert ``value`` to a string and truncate it to ``max_log_length``.

        This is used to keep log lines bounded when argument/return values are large.

        Args:
            value:
                Any object whose string representation is required for logging.

        Returns:
            A string representation of ``value``. If the representation exceeds
            ``max_log_length``, it is truncated and suffixed with ``" ... [TRUNCATED]"``.

        Raises:
            This method does not intentionally raise. It guards against exceptions thrown by
            ``str(value)`` by falling back to ``repr(value)``. If both ``str`` and ``repr``
            were to raise (very unusual), that exception would propagate.
        """
        try:
            text = str(value)
        except Exception:
            text = repr(value)
        return text if len(text) <= self.max_log_length else text[:self.max_log_length] + " ... [TRUNCATED]"

    def _get_call_stack(self) -> str:
        """
        Build a trimmed, human-readable call stack for diagnostics.

        The stack is obtained from :func:`traceback.format_stack` and then trimmed to
        remove the decorator's own frames. Each remaining frame is formatted as a
        numbered bullet with code line and call location.

        Returns:
            A formatted multi-line string representing the call stack.

        Raises:
            This method does not intentionally raise. Any unexpected exception from
            Python's traceback machinery would propagate.
        """
        stack = traceback.format_stack()
        trimmed = stack[:-3]  # remove decorator's own frames

        formatted = []
        for index, element in enumerate(trimmed):
            parts = element.split("\n")
            formatted.append(f"\t{index+1}. - `{parts[1].lstrip()}` (Call location: `{parts[0].lstrip()}`)")

        return "\n".join(formatted)

    def _format_args(self, func: Callable[P, R], args: tuple, kwargs: dict) -> tuple[str, str]:
        """
        Format bound arguments of ``func`` for logging.

        This method uses :func:`inspect.signature` + ``bind`` to pair passed arguments with
        parameter names. Values for parameters listed in ``sensitive_params`` are replaced
        with ``[FILTERED]``. Other values are stringified and truncated via :meth:`_truncate`.

        Args:
            func:
                Function whose signature is used for binding.
            args:
                Positional arguments originally passed to ``func``.
            kwargs:
                Keyword arguments originally passed to ``func``.

        Returns:
            A tuple ``(args_str, kwargs_str)``. Each element is either an empty string
            or a multi-line string prefixed with ``"\\n"`` containing formatted entries.

            If binding fails, returns ``("<unable to parse args>", "<unable to parse kwargs>")``.

        Raises:
            This method does not intentionally raise. It catches exceptions from signature
            binding and returns the "unable to parse" strings instead.
        """
        try:
            bound = inspect.signature(func).bind(*args, **kwargs)
            bound.apply_defaults()
        except Exception:
            return "<unable to parse args>", "<unable to parse kwargs>"

        args_strs = []
        kwargs_strs = []

        for name, value in bound.arguments.items():
            val = '[FILTERED]' if name in self.sensitive_params else self._truncate(value)
            entry = f"{name}: `{val}`"
            if name in kwargs:
                kwargs_strs.append(entry)
            else:
                args_strs.append(entry)

        args_str = "\n" + "\n".join(f"Positional parameter {line}" for line in args_strs) if args_strs else ""
        kwargs_str = "\n" + "\n".join(f"Keyword parameter {line}" for line in kwargs_strs) if kwargs_strs else ""
        return args_str, kwargs_str

    def _log_sync(self, func: Callable[P, R], *args: P.args, **kwargs: P.kwargs) -> R:
        """
        Execute and log a *synchronous* function call.

        Depending on configuration, this logs:
        - entry (and optionally arguments),
        - optional call stack at DEBUG level,
        - optional execution duration,
        - optional return value,
        - exceptions (with ``exc_info=True``) and a stack trace snapshot.

        Args:
            func:
                The synchronous callable to execute.
            *args:
                Positional arguments passed through to ``func``.
            **kwargs:
                Keyword arguments passed through to ``func``.

        Returns:
            The return value of ``func(*args, **kwargs)`` on success.

            If an exception occurs and ``raise_exception`` is ``False``, returns
            ``default_return``.

        Raises:
            Any exception raised by ``func`` will be re-raised if ``raise_exception`` is ``True``.
            This method does not otherwise intentionally raise.
        """
        func_name = f"{func.__module__}.{func.__name__}"

        if self.logger.isEnabledFor(self.log_level):
            if self.log_arguments:
                args_str, kwargs_str = self._format_args(func, args, kwargs)
                self.logger.log(self.log_level, f"{self.tag}Function `{func_name}` called.{args_str}{kwargs_str}")
            else:
                self.logger.log(self.log_level, f"{self.tag}Function `{func_name}` called.")

            if self.log_stack:
                self.logger.debug(f"{self.tag}Call stack for `{func_name}`:\n{self._get_call_stack()}")

        start_time = time.time()
        try:
            result = func(*args, **kwargs)
            elapsed = time.time() - start_time

            if self.log_execution_time:
                self.logger.log(self.log_level, f"{self.tag}Function `{func_name}` returned after {elapsed:.2f} seconds.")

            if self.warn_duration and elapsed > self.warn_duration:
                self.logger.warning(f"{self.tag}Function `{func_name}` exceeded {self.warn_duration} seconds.")

            if self.log_return:
                self.logger.log(self.log_level, f"{self.tag}Return value: `{self._truncate(result)}`")

            return result
        except Exception as e:
            self.logger.critical(f"{self.tag}Exception in `{func_name}`: {type(e).__name__}: {str(e)}", exc_info=True)
            self.logger.debug(f"{self.tag}Call stack at exception in `{func_name}`:\n{self._get_call_stack()}")

            if self.raise_exception:
                raise

            return self.default_return

    async def _log_async(self, func: Callable[P, R], *args: P.args, **kwargs: P.kwargs) -> R:
        """
        Execute and log an *asynchronous* function call.

        This behaves like :meth:`_log_sync` but awaits the target coroutine function.

        Args:
            func:
                The asynchronous callable (coroutine function) to execute.
            *args:
                Positional arguments passed through to ``func``.
            **kwargs:
                Keyword arguments passed through to ``func``.

        Returns:
            The awaited result of ``func(*args, **kwargs)`` on success.

            If an exception occurs and ``raise_exception`` is ``False``, returns
            ``default_return``.

        Raises:
            Any exception raised by ``func`` will be re-raised if ``raise_exception`` is ``True``.
            This method does not otherwise intentionally raise.
        """
        func_name = f"{func.__module__}.{func.__name__}"

        if self.logger.isEnabledFor(self.log_level):
            if self.log_arguments:
                args_str, kwargs_str = self._format_args(func, args, kwargs)
                self.logger.log(self.log_level, f"{self.tag}<Async> Function `{func_name}` called.{args_str}{kwargs_str}")
            else:
                self.logger.log(self.log_level, f"{self.tag}<Async> Function `{func_name}` called.")

            if self.log_stack:
                self.logger.debug(f"{self.tag}Call stack for `{func_name}`:\n{self._get_call_stack()}")

        start_time = time.time()
        try:
            result = await func(*args, **kwargs)
            elapsed = time.time() - start_time

            if self.log_execution_time:
                self.logger.log(self.log_level, f"{self.tag}Function `{func_name}` returned after {elapsed:.2f} seconds.")

            if self.warn_duration and elapsed > self.warn_duration:
                self.logger.warning(f"{self.tag}Function `{func_name}` exceeded {self.warn_duration} seconds.")

            if self.log_return:
                self.logger.log(self.log_level, f"{self.tag}Return value: `{self._truncate(result)}`")

            return result
        except Exception as e:
            self.logger.critical(f"{self.tag}Exception in `{func_name}`: {type(e).__name__}: {str(e)}", exc_info=True)
            self.logger.debug(f"{self.tag}Call stack at exception in `{func_name}`:\n{self._get_call_stack()}")
            
            if self.raise_exception:
                raise

            return self.default_return

    def __call__(self, func: Callable[P, R]) -> Callable[P, R]:
        """
        Make the instance usable as a decorator.

        This returns a wrapper that routes calls to either :meth:`_log_sync` or
        :meth:`_log_async` depending on whether ``func`` is a coroutine function.

        Args:
            func:
                The function to decorate (sync or async).

        Returns:
            A callable wrapper with the same signature metadata as ``func`` (via
            :func:`functools.wraps`).

        Raises:
            This method does not intentionally raise. Any exception raised during
            execution of the wrapped function will follow the behavior of
            :meth:`_log_sync` / :meth:`_log_async` (re-raised or swallowed depending
            on ``raise_exception``).
        """
        @functools.wraps(func)
        async def async_wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            return await self._log_async(func, *args, **kwargs)

        @functools.wraps(func)
        def sync_wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            return self._log_sync(func, *args, **kwargs)

        return async_wrapper if inspect.iscoroutinefunction(func) else sync_wrapper
