from typing import Callable
from .log_decorator import LogDecorator
from .logger import Logger


class LogWrapper:
    def __init__(self, decorator: LogDecorator, logger: Logger):
        """
        Combine a :class:`~.log_decorator.LogDecorator` and a framework :class:`~.logger.Logger`
        into a single object.

        The wrapper serves two roles:
        1) It is callable and can be used as a decorator (delegates to ``decorator``).
        2) It transparently exposes logging methods/attributes, delegating either to the
           framework ``Logger`` or its underlying stdlib ``logging.Logger`` depending on
           the attribute name.

        Args:
            decorator:
                A configured :class:`~.log_decorator.LogDecorator` instance used to wrap functions.
            logger:
                The framework :class:`~.logger.Logger` instance used for direct logging calls.

        Raises:
            This initializer does not intentionally raise. Any exception would come from
            storing the provided objects (e.g., if they are incompatible types).

        Examples:
            Using the wrapper as a decorator:

            >>> # assume `decorator` is a LogDecorator and `logger` is a framework Logger
            >>> log = LogWrapper(decorator, logger)
            >>> @log
            ... def add(a, b):
            ...     return a + b
            >>> add(1, 2)
            3

            Using the wrapper for direct logging:

            >>> # delegates to the underlying stdlib logger for .info/.warning/etc.
            >>> log.info("hello")
        """
        self._decorator = decorator
        self._logger = logger

    def __call__(self, func: Callable):
        """
        Decorate ``func`` using the stored :class:`~.log_decorator.LogDecorator`.

        Args:
            func:
                The function (sync or async) to wrap.

        Returns:
            A decorated callable produced by the underlying :class:`~.log_decorator.LogDecorator`.

        Raises:
            Any exception raised by the underlying decorator during wrapping would propagate.
            During execution of the wrapped function, exception behavior is controlled by the
            underlying :class:`~.log_decorator.LogDecorator` configuration.

        Examples:
            >>> # assume `log` is a LogWrapper
            >>> @log
            ... def hello(name):
            ...     return f"hi {name}"
            >>> hello("Bob")
            'hi Bob'
        """
        return self._decorator(func)

    def __getattr__(self, name: str):
        """
        Delegate attribute access to the framework ``Logger`` or its stdlib logger.

        Rule:
        - If ``name`` contains any of ``("context", "async", "get_logger")``, delegate to the
          framework :class:`~.logger.Logger` instance.
        - Otherwise delegate to the underlying stdlib ``logging.Logger`` returned by
          ``self._logger.get_logger()``.

        This enables convenient usage like:

        - ``log.info(...)`` (stdlib logger)
        - ``log.warning(...)`` (stdlib logger)
        - ``log.get_logger()`` (framework logger method)
        - ``log.context(...)`` / ``log.async...`` (framework logger features)

        Args:
            name:
                Attribute or method name being requested.

        Returns:
            The resolved attribute from the appropriate delegated object.

        Raises:
            AttributeError:
                If neither the framework ``Logger`` nor the underlying stdlib logger has
                an attribute named ``name``.

        Examples:
            >>> # stdlib logging methods
            >>> log.info("message")
            >>> log.warning("message")

            >>> # framework methods (examples; depend on your Logger implementation)
            >>> log.get_logger()
            >>> # log.context("job-123")  # if your Logger provides it
        """
        if any(keyword in name for keyword in ("context", "async", "get_logger")):
            return getattr(self._logger, name)
        else:
            return getattr(self._logger.get_logger(), name)
