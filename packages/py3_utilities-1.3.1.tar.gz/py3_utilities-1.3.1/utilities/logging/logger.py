import logging
import os
import threading
import shutil
import tempfile
import contextvars
import queue

from datetime import datetime, timedelta
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler, QueueHandler, QueueListener
from colorlog import ColoredFormatter
from pythonjsonlogger import jsonlogger
from typing import Optional, List, Callable
from contextlib import contextmanager


class ContextAwareJsonFormatter(jsonlogger.JsonFormatter):
    """JSON formatter that injects context variables into each log record.

    If a `contextvars.ContextVar` holding a dict is provided, its keys/values are
    added to every emitted JSON log record (unless the key already exists in the record).

    Args:
        *args: Passed through to `pythonjsonlogger.jsonlogger.JsonFormatter`.
        context_var: Optional `contextvars.ContextVar` that returns a dict of context
            fields to attach to each log record.
        **kwargs: Passed through to `pythonjsonlogger.jsonlogger.JsonFormatter`.

    Examples:
        >>> import contextvars
        >>> cv = contextvars.ContextVar("ctx", default={"request_id": "abc"})
        >>> fmt = ContextAwareJsonFormatter(context_var=cv)
        >>> isinstance(fmt, jsonlogger.JsonFormatter)
        True
    """

    def __init__(self, *args, context_var: Optional[contextvars.ContextVar[dict]] = None, **kwargs) -> None:
        """Initialize the formatter.

        Args:
            *args: Passed through to the base JSON formatter.
            context_var: Optional `ContextVar` returning a dict of extra fields.
            **kwargs: Passed through to the base JSON formatter.
        """
        super().__init__(*args, **kwargs)
        self._context_var = context_var

    def add_fields(self, log_record: dict, record: logging.LogRecord, message_dict: dict) -> None:
        """Add base JSON fields and merge in context fields.

        Args:
            log_record: Target dict that will be serialized to JSON.
            record: The original `logging.LogRecord`.
            message_dict: Extra fields attached by the logger call.

        Returns:
            None
        """
        super().add_fields(log_record, record, message_dict)

        if self._context_var:
            context = self._context_var.get()

            for key, value in context.items():
                if key not in log_record:
                    log_record[key] = value


class Logger:
    """Configurable logger wrapper with optional file/console/JSON outputs and utilities.

    This class wraps Python's `logging` module to provide a single, convenient setup
    point for common patterns used in automation/reporting scripts:

    - Plain text file logging (optional)
    - JSON file logging (optional)
    - Colorized console logging (optional)
    - Size-based or time-based rotation (mutually exclusive per output)
    - Daily log directories (when file/json output enabled)
    - Optional asynchronous logging via `QueueHandler` + `QueueListener`
    - Context-aware JSON logging via `contextvars`
    - Helper utilities to clean up or compress old log folders

    Notes:
        - The underlying logger is created via `logging.getLogger(name)` and is set
          to DEBUG; handler levels control effective output filtering.
        - Handler creation and addition is guarded by a class-level lock.
        - Daily folder naming: YYYY-MM-DD.

    Args:
        name: Logger name used for `logging.getLogger(name)` and file naming.
        base_log_dir: Base directory for storing daily log folders.
        clear_handlers: If True, clears existing handlers on the underlying logger
            before adding new ones.
        file_output: Enable plain text file logging.
        file_extension: Extension for the text log file (default "log").
        file_formatter: Optional custom formatter for file logs. If None, a default
            formatter is used.
        file_log_level: Handler level for file output.
        file_timestamp_format: Optional `datefmt` for file formatter timestamps.
        file_rotation_size_based: Enable size-based rotation for file logs.
        file_rotation_max_bytes: Rotation max size (bytes) for file logs.
        file_rotation_time_based: Enable time-based rotation for file logs.
        file_rotation_when: Rotation interval type for file logs (e.g. "midnight", "H").
        file_rotation_interval: Rotation interval for file logs.
        file_rotation_backup_count: Number of rotated file logs to keep.
        console_output: Enable console logging to stdout.
        console_formatter: Optional custom formatter for console logs. If None, a default
            color formatter is used.
        console_log_level: Handler level for console output.
        console_timestamp_format: Optional `datefmt` for console formatter timestamps.
        json_output: Enable JSON file logging.
        json_formatter: Optional custom formatter for JSON logs. If None, a default
            context-aware JSON formatter is used.
        json_log_level: Handler level for JSON output.
        json_timestamp_format: Optional `datefmt` for JSON formatter timestamps.
        json_rotation_size_based: Enable size-based rotation for JSON logs.
        json_rotation_max_bytes: Rotation max size (bytes) for JSON logs.
        json_rotation_time_based: Enable time-based rotation for JSON logs.
        json_rotation_when: Rotation interval type for JSON logs (e.g. "midnight", "H").
        json_rotation_interval: Rotation interval for JSON logs.
        json_rotation_backup_count: Number of rotated JSON logs to keep.
        async_queue_size: Queue size for async logging. Uses `queue.Queue(async_queue_size)`
            during initialization; `enable_async_logging()` replaces it with an unbounded queue.
        now_func: Optional callable returning `datetime` (used to compute today's folder).
            Intended for testability.

    Raises:
        ValueError: If both size-based and time-based rotation are enabled for file logs.
        ValueError: If both size-based and time-based rotation are enabled for JSON logs.

    Examples:
        Basic console logger:
        >>> lg = Logger("demo", console_output=True).get_logger()
        >>> lg.info("hello")  # doctest: +ELLIPSIS
        ...

        File + JSON outputs under logs/<YYYY-MM-DD>/:
        >>> _ = Logger("demo2", file_output=True, json_output=True, base_log_dir="logs")

        Context-aware JSON fields:
        >>> L = Logger("demo3", json_output=True)
        >>> with L.context_scope(job_id="42", user="alice"):
        ...     L.get_logger().info("run")  # JSON record will include job_id and user

        Asynchronous logging:
        >>> L2 = Logger("demo4", console_output=True)
        >>> L2.enable_async_logging()
        >>> L2.get_logger().warning("async")  # doctest: +ELLIPSIS
        ...
        >>> L2.shutdown_async_logging()
    """

    _lock = threading.Lock()

    _internal_logger = logging.getLogger("LoggerInternal")
    _internal_logger.setLevel(logging.WARNING)
    _internal_console_handler = logging.StreamHandler()
    _internal_console_handler.setFormatter(logging.Formatter(
        fmt="%(asctime)s - %(levelname)s - %(message)s", datefmt="%Y-%m-%dT%H:%M:%S"
    ))
    _internal_logger.addHandler(_internal_console_handler)

    def __init__(
        self,
        name: str,
        base_log_dir: str = "logs",
        clear_handlers: bool = False,
        file_output: bool = False,
        file_extension: str = "log",
        file_formatter: Optional[logging.Formatter] = None,
        file_log_level: int = logging.INFO,
        file_timestamp_format: Optional[str] = None,
        file_rotation_size_based: bool = False,
        file_rotation_max_bytes: int = 10 * 1024 * 1024,
        file_rotation_time_based: bool = False,
        file_rotation_when: str = "midnight",
        file_rotation_interval: int = 1,
        file_rotation_backup_count: int = 7,
        console_output: bool = False,
        console_formatter: Optional[logging.Formatter] = None,
        console_log_level: int = logging.INFO,
        console_timestamp_format: Optional[str] = None,
        json_output: bool = False,
        json_formatter: Optional[logging.Formatter] = None,
        json_log_level: int = logging.INFO,
        json_timestamp_format: Optional[str] = None,
        json_rotation_size_based: bool = False,
        json_rotation_max_bytes: int = 10 * 1024 * 1024,
        json_rotation_time_based: bool = False,
        json_rotation_when: str = "midnight",
        json_rotation_interval: int = 1,
        json_rotation_backup_count: int = 7,
        async_queue_size: int = -1,
        now_func: Optional[Callable[[], datetime]] = None # For testability
    ) -> None:
        """Create and configure the underlying `logging.Logger`.

        This sets up handlers according to the selected outputs (file/json/console).
        If file and/or JSON outputs are enabled, a daily folder is created under:
        `base_log_dir/<YYYY-MM-DD>/`.

        Rotation configuration:
            - For each output type (file/json), rotation is either size-based, time-based,
              or disabled.
            - Size-based and time-based rotation cannot both be enabled for the same output.

        Args:
            name: Logger name used in records and for file naming.
            base_log_dir: Base directory for logs.
            clear_handlers: If True, clears existing handlers on the logger.
            file_output: Enable plain text file logging.
            file_extension: Extension for the file log (default "log").
            file_formatter: Optional formatter for file logs.
            file_log_level: Handler level for file logs.
            file_timestamp_format: Optional `datefmt` for file timestamps.
            file_rotation_size_based: Enable `RotatingFileHandler` for file logs.
            file_rotation_max_bytes: Max bytes before rotating file logs.
            file_rotation_time_based: Enable `TimedRotatingFileHandler` for file logs.
            file_rotation_when: "when" value for timed rotation.
            file_rotation_interval: Interval for timed rotation.
            file_rotation_backup_count: Number of rotated file logs to keep.
            console_output: Enable console logging.
            console_formatter: Optional formatter for console.
            console_log_level: Handler level for console.
            console_timestamp_format: Optional `datefmt` for console timestamps.
            json_output: Enable JSON file logging.
            json_formatter: Optional formatter for JSON logs.
            json_log_level: Handler level for JSON logs.
            json_timestamp_format: Optional `datefmt` for JSON timestamps.
            json_rotation_size_based: Enable `RotatingFileHandler` for JSON logs.
            json_rotation_max_bytes: Max bytes before rotating JSON logs.
            json_rotation_time_based: Enable `TimedRotatingFileHandler` for JSON logs.
            json_rotation_when: "when" value for timed JSON rotation.
            json_rotation_interval: Interval for timed JSON rotation.
            json_rotation_backup_count: Number of rotated JSON logs to keep.
            async_queue_size: Initial queue size used for async queue creation.
            now_func: Optional callable returning current datetime (test seam).

        Returns:
            None

        Raises:
            ValueError: If both size-based and time-based rotation are enabled for file logs.
            ValueError: If both size-based and time-based rotation are enabled for JSON logs.

        Examples:
            >>> L = Logger("ex", console_output=True)
            >>> L.get_logger().info("hi")  # doctest: +ELLIPSIS
            ...
        """
        if file_rotation_size_based and file_rotation_time_based:
            raise ValueError("Cannot enable both size-based and time-based rotation for file logs.")

        if json_rotation_size_based and json_rotation_time_based:
            raise ValueError("Cannot enable both size-based and time-based rotation for JSON logs.")

        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)

        # Async logging
        self._log_queue = queue.Queue(async_queue_size)
        self._original_handlers = []
        self._listener = None

        # Create context variables
        self._context_var = contextvars.ContextVar(f"{name}_log_context", default={})

        self._file_formatter = file_formatter or self._get_file_formatter(file_timestamp_format)
        self._json_formatter = json_formatter or self._get_json_formatter(json_timestamp_format)
        self._console_formatter = console_formatter or self._get_console_formatter(console_timestamp_format) 

        self._now = now_func or datetime.now

        with Logger._lock:
            if self.logger.hasHandlers() and clear_handlers:
                self.logger.handlers.clear()

            now = self._now()

            if file_output or json_output:
                day_folder = now.strftime("%Y-%m-%d")
                log_root = os.path.join(base_log_dir, day_folder)
                os.makedirs(log_root, exist_ok=True)

            if file_output:
                log_path = os.path.join(log_root, f"{name}.{file_extension}")
                if file_rotation_time_based:
                    file_handler = TimedRotatingFileHandler(
                        log_path,
                        when=file_rotation_when,
                        interval=file_rotation_interval,
                        backupCount=file_rotation_backup_count
                    )
                elif file_rotation_size_based:
                    file_handler = RotatingFileHandler(
                        log_path,
                        maxBytes=file_rotation_max_bytes,
                        backupCount=file_rotation_backup_count
                    )
                else:
                    file_handler = logging.FileHandler(log_path)

                file_handler.setLevel(file_log_level)
                file_handler.setFormatter(self._file_formatter)
                self._add_handler_once(file_handler)

            if json_output:
                json_path = os.path.join(log_root, f"{name}.json")
                if json_rotation_time_based:
                    json_handler = TimedRotatingFileHandler(
                        json_path,
                        when=json_rotation_when,
                        interval=json_rotation_interval,
                        backupCount=json_rotation_backup_count
                    )
                elif json_rotation_size_based:
                    json_handler = RotatingFileHandler(
                        json_path,
                        maxBytes=json_rotation_max_bytes,
                        backupCount=json_rotation_backup_count
                    )
                else:
                    json_handler = logging.FileHandler(json_path)

                json_handler.setLevel(json_log_level)
                json_handler.setFormatter(self._json_formatter)
                self._add_handler_once(json_handler)

            if console_output:
                console_handler = logging.StreamHandler()
                console_handler.setLevel(console_log_level)
                console_handler.setFormatter(self._console_formatter)
                self._add_handler_once(console_handler)

    def _add_handler_once(self, handler: logging.Handler) -> None:
        """Add a handler only if an equivalent destination isn't already attached.

        This prevents common duplicates when multiple `Logger(...)` instances are
        created with the same `name` (and therefore share the same underlying
        `logging.Logger`).

        Equivalence rules:
            - For stream handlers: same handler type and same `.stream`
            - For file handlers: same handler type and same `.baseFilename`

        Args:
            handler: Handler instance to add.

        Returns:
            None

        Examples:
            >>> L = Logger("dup_demo", console_output=True)
            >>> before = len(L.get_logger().handlers)
            >>> L.add_handler(logging.StreamHandler())  # different stream by default; may add
            >>> after = len(L.get_logger().handlers)
            >>> after >= before
            True
        """
        for existing in self.logger.handlers:
            # Compare stream handlers
            if isinstance(handler, logging.StreamHandler) and isinstance(existing, logging.StreamHandler):
                if getattr(existing, 'stream', None) == getattr(handler, 'stream', None):
                    return

            # Compare all file-based handlers using filename
            if isinstance(handler, logging.FileHandler) and isinstance(existing, logging.FileHandler):
                if getattr(existing, 'baseFilename', None) == getattr(handler, 'baseFilename', None):
                    return

        self.logger.addHandler(handler)

    def get_logger(self) -> logging.Logger:
        """Return the configured `logging.Logger` instance.

        Returns:
            logging.Logger: The underlying Python logger.

        Examples:
            >>> L = Logger("get_demo", console_output=True)
            >>> isinstance(L.get_logger(), logging.Logger)
            True
        """
        return self.logger

    def add_handler(self, handler: logging.Handler) -> None:
        """Attach a custom handler, avoiding duplicates where possible.

        This method is thread-safe and uses the same duplicate detection logic as
        `_add_handler_once()`.

        Args:
            handler: Handler instance to attach.

        Returns:
            None

        Examples:
            >>> L = Logger("custom_handler_demo")
            >>> h = logging.StreamHandler()
            >>> L.add_handler(h)
            >>> h in L.get_logger().handlers
            True
        """
        with Logger._lock:
            self._add_handler_once(handler)

    def get_handler_summary(self) -> List[dict]:
        """Return a summary of handlers currently attached to the logger.

        The summary is intentionally minimal and JSON-serializable.

        Returns:
            List[dict]: One dict per handler with:
                - "type": handler class name
                - "level": level name (e.g. "INFO")
                - "formatter": formatter class name or None

        Examples:
            >>> L = Logger("summary_demo", console_output=True)
            >>> s = L.get_handler_summary()
            >>> isinstance(s, list) and isinstance(s[0], dict)
            True
        """
        return [
            {
                "type": type(h).__name__,
                "level": logging.getLevelName(h.level),
                "formatter": type(h.formatter).__name__ if h.formatter else None,
            }
            for h in self.logger.handlers
        ]

    def enable_async_logging(self):
        """Enable asynchronous logging using a queue.

        This replaces the logger's handlers with a single `QueueHandler` and starts
        a `QueueListener` that forwards records to the original handlers.

        Behavior:
            - If async logging is already enabled, does nothing.
            - Preserves the current handlers so they can be restored by
              `shutdown_async_logging()`.

        Returns:
            None

        Examples:
            >>> L = Logger("async_demo", console_output=True)
            >>> L.enable_async_logging()
            >>> L.async_enabled
            True
        """
        if self._listener:
            Logger._internal_logger.warning("Async logging already enabled.")
            return

        self._original_handlers = self.logger.handlers[:]
        self.logger.handlers.clear()

        self._log_queue = queue.Queue(-1)
        queue_handler = QueueHandler(self._log_queue)
        self.logger.addHandler(queue_handler)

        self._listener = QueueListener(self._log_queue, *self._original_handlers, respect_handler_level=True)
        self._listener.start()

    def shutdown_async_logging(self):
        """Stop the async listener and restore the original handlers.

        If async logging is not enabled, this method has no effect.

        Returns:
            None

        Examples:
            >>> L = Logger("async_stop_demo", console_output=True)
            >>> L.enable_async_logging()
            >>> L.shutdown_async_logging()
            >>> L.async_enabled
            False
        """
        if self._listener:
            self._listener.stop()
            self._listener = None
            self.logger.handlers.clear()

            for handler in self._original_handlers:
                self.logger.addHandler(handler)

            self._original_handlers = []
            self._log_queue = None

    @property
    def async_enabled(self):
        """Whether asynchronous logging is currently enabled.

        Returns:
            bool: True if `enable_async_logging()` has been called and not shut down.

        Examples:
            >>> L = Logger("async_prop_demo")
            >>> L.async_enabled
            False
        """
        return self._listener is not None

    @contextmanager
    def context_scope(self, **kwargs):
        """Temporarily set context fields for JSON logging within a `with` block.

        Context fields are stored in an internal `ContextVar`. When using the default
        JSON formatter, these fields will be injected into each JSON record emitted
        within the scope.

        Args:
            **kwargs: Key/value pairs to set for the duration of the context manager.

        Yields:
            None

        Returns:
            Context manager that sets then resets the context.

        Examples:
            >>> L = Logger("ctx_demo", json_output=True)
            >>> with L.context_scope(run_id="r1"):
            ...     L.get_logger().info("inside")
            >>> L.clear_context()
        """
        token = self._context_var.set(kwargs)
        try:
            yield
        finally:
            self._context_var.reset(token)

    def set_context(self, **kwargs):
        """Set (replace) the current JSON logging context fields.

        This overwrites the entire context dict with the provided key/value pairs.
        Use `context_scope()` for a temporary scope.

        Args:
            **kwargs: Key/value pairs to set as the current context.

        Returns:
            None

        Examples:
            >>> L = Logger("set_ctx_demo", json_output=True)
            >>> L.set_context(task="daily_job", attempt=1)
        """
        self._context_var.set(kwargs)

    def clear_context(self):
        """Clear all context fields used for JSON logging.

        Returns:
            None

        Examples:
            >>> L = Logger("clear_ctx_demo", json_output=True)
            >>> L.set_context(x=1)
            >>> L.clear_context()
        """
        self._context_var.set({})

    def _get_file_formatter(self, timestamp_format: Optional[str] = None) -> logging.Formatter:
        """Create the default formatter for plain text file output.

        Args:
            timestamp_format: Optional `datefmt`. Defaults to "%Y-%m-%dT%H:%M:%S".

        Returns:
            logging.Formatter: Configured formatter instance.

        Examples:
            >>> L = Logger("fmt_demo")
            >>> f = L._get_file_formatter()
            >>> isinstance(f, logging.Formatter)
            True
        """
        return logging.Formatter(
            fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            datefmt=timestamp_format or "%Y-%m-%dT%H:%M:%S"
        )

    def _get_json_formatter(self, timestamp_format: Optional[str] = None) -> ContextAwareJsonFormatter:
        """Create the default context-aware JSON formatter.

        The formatter includes timestamp, name, level, message plus any context
        fields set via `set_context()` / `context_scope()`.

        Args:
            timestamp_format: Optional `datefmt`. Defaults to "%Y-%m-%dT%H:%M:%S".

        Returns:
            ContextAwareJsonFormatter: Configured formatter instance.

        Examples:
            >>> L = Logger("json_fmt_demo")
            >>> jf = L._get_json_formatter()
            >>> isinstance(jf, ContextAwareJsonFormatter)
            True
        """
        return ContextAwareJsonFormatter(
            fmt='{"timestamp": "%(asctime)s", "name": "%(name)s", "level": "%(levelname)s", "message": "%(message)s"}',
            datefmt=timestamp_format or "%Y-%m-%dT%H:%M:%S",
            context_var=self._context_var
        )

    def _get_console_formatter(self, timestamp_format: Optional[str] = None) -> ColoredFormatter:
        """Create the default colorized formatter for console output.

        Args:
            timestamp_format: Optional `datefmt`. Defaults to "%Y-%m-%d %H:%M:%S".

        Returns:
            colorlog.ColoredFormatter: Configured color formatter instance.

        Examples:
            >>> L = Logger("console_fmt_demo")
            >>> cf = L._get_console_formatter()
            >>> isinstance(cf, ColoredFormatter)
            True
        """
        default_fmt = (
            "\033[1m[%(name)s]\033[0m "     # Bracketed name
            "\033[2m%(asctime)s\033[0m "    # Dim timestamp
            "%(log_color)s[%(levelname).3s]%(reset)s → "
            "%(message)s"
        )

        return ColoredFormatter(
            fmt=default_fmt,
            datefmt=timestamp_format or "%Y-%m-%d %H:%M:%S",
            log_colors={
                'DEBUG':    'bold_cyan',
                'INFO':     'bold_green',
                'WARNING':  'bold_yellow',
                'ERROR':    'bold_red',
                'CRITICAL': 'bold_white,bg_red',
            },
            style='%'
        )

    @staticmethod
    def cleanup_old_logs(base_log_dir: str, name: str, days: int = 7, verbose: bool = False) -> bool:
        """Delete old daily log folders.

        This removes folders whose date (parsed from folder name "YYYY-MM-DD") is older
        than `datetime.now() - timedelta(days=days)`.

        Folder selection:
            - If `name == "*"`, considers immediate subdirectories under `base_log_dir`
              as logger directories and scans their daily folders.
            - Otherwise, only scans `os.path.join(base_log_dir, name)` if it exists.

        Args:
            base_log_dir: Root logs directory.
            name: Logger directory name to clean up, or "*" for all.
            days: Delete folders older than this age (in days).
            verbose: If True, logs warnings about deletions/errors to the internal logger.

        Returns:
            bool: True if at least one folder was deleted, otherwise False.

        Examples:
            >>> # Typically used in housekeeping jobs:
            >>> Logger.cleanup_old_logs("logs", "*", days=30) in (True, False)
            True
        """
        deleted_any = False
        folders = Logger._get_old_log_folders(base_log_dir, name, days)

        for folder in folders:
            try:
                shutil.rmtree(folder)
                deleted_any = True
                if verbose:
                    Logger._internal_logger.warning(f"{name} - Deleted folder: {folder}")
            except Exception as e:
                Logger._internal_logger.warning(f"{name} - Failed to delete {folder}: {e}")

        return deleted_any

    @staticmethod
    def compress_old_logs(base_log_dir: str, name: str, days: int = 7, archive_name: Optional[str] = None, verbose: bool = False) -> Optional[str]:
        """Create a gzip tar archive of old daily log folders.

        This copies selected folders into a temporary directory, then creates a `.tar.gz`
        archive via `shutil.make_archive(..., 'gztar', ...)`. The original folders are
        not removed.

        Folder selection rules match `cleanup_old_logs()`.

        Args:
            base_log_dir: Root logs directory.
            name: Logger directory name to archive, or "*" for all.
            days: Archive folders older than this age (in days).
            archive_name: Output base name for the archive (no extension). If None, an
                automatic name `archived_logs_<YYYYMMDD_HHMMSS>` is used.
            verbose: If True, logs progress/errors to the internal logger.

        Returns:
            Optional[str]: Path to the created archive file, or None if no folders matched
            the criteria.

        Examples:
            >>> p = Logger.compress_old_logs("logs", "*", days=30)
            >>> (p is None) or isinstance(p, str)
            True
        """
        folders = Logger._get_old_log_folders(base_log_dir, name, days)
        if not folders:
            return None

        archive_name = archive_name or f"archived_logs_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        tmp_dir = tempfile.mkdtemp()

        try:
            for folder in folders:
                rel_path = os.path.relpath(folder, base_log_dir)
                dest_path = os.path.join(tmp_dir, rel_path)
                os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                shutil.copytree(folder, dest_path)

            archive_path = shutil.make_archive(archive_name, 'gztar', tmp_dir)
            if verbose:
                Logger._internal_logger.warning(f"{name} - Created archive: {archive_path}")
            return archive_path
        except Exception as e:
            Logger._internal_logger.error(f"{name} - Compression failed: {e}")
            return None
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

    @staticmethod
    def _get_old_log_folders(base_log_dir: str, name: str, days: int) -> List[str]:
        """Return daily log folders older than the cutoff date.

        A "daily log folder" is expected to be named "YYYY-MM-DD". Any subfolder name
        that cannot be parsed as a date is skipped (with a warning).

        Args:
            base_log_dir: Root logs directory.
            name: Logger directory name to scan, or "*" to scan all immediate subdirectories.
            days: Age threshold in days; folders strictly older than `now - days` are included.

        Returns:
            List[str]: Absolute paths to old daily folders.

        Examples:
            >>> folders = Logger._get_old_log_folders("logs", "*", days=3650)
            >>> isinstance(folders, list)
            True
        """
        cutoff_date = datetime.now() - timedelta(days=days)
        result = []
        logger_dirs = []

        if name == "*":
            logger_dirs = [
                os.path.join(base_log_dir, d) for d in os.listdir(base_log_dir)
                if os.path.isdir(os.path.join(base_log_dir, d))
            ]
        else:
            specific_dir = os.path.join(base_log_dir, name)
            if os.path.isdir(specific_dir):
                logger_dirs = [specific_dir]

        for logger_dir in logger_dirs:
            for day_dir in os.listdir(logger_dir):
                full_path = os.path.join(logger_dir, day_dir)
                try:
                    day_date = datetime.strptime(day_dir, "%Y-%m-%d")
                    if day_date < cutoff_date:
                        result.append(full_path)
                except ValueError:
                    Logger._internal_logger.warning(f"{name} - Skipping invalid date folder: {full_path}")
                    continue

        return result
