# py4096

Play **4096** in your terminal.

## Install (local)

```bash
pip install -e .
```
