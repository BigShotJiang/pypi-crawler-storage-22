import random

SIZE = 4
TARGET = 4096

def init_board():
    return [[0] * SIZE for _ in range(SIZE)]

def add_random_tile(board):
    empty = [(i, j) for i in range(SIZE) for j in range(SIZE) if board[i][j] == 0]
    if not empty:
        return
    i, j = random.choice(empty)
    board[i][j] = 4 if random.random() < 0.1 else 2

def compress(row):
    new_row = [x for x in row if x != 0]
    return new_row + [0] * (SIZE - len(new_row))

def merge(row):
    for i in range(SIZE - 1):
        if row[i] != 0 and row[i] == row[i + 1]:
            row[i] *= 2
            row[i + 1] = 0
    return row

def move_left(board):
    moved = False
    new_board = []

    for row in board:
        final = compress(merge(compress(row)))
        if final != row:
            moved = True
        new_board.append(final)

    return new_board, moved

def rotate(board):
    return [list(row) for row in zip(*board[::-1])]

def has_won(board):
    return any(TARGET in row for row in board)

def can_move(board):
    for i in range(SIZE):
        for j in range(SIZE):
            if board[i][j] == 0:
                return True
            if j < SIZE - 1 and board[i][j] == board[i][j + 1]:
                return True
            if i < SIZE - 1 and board[i][j] == board[i + 1][j]:
                return True
    return False
