from py4096.game import run

def main():
    run()
