from py4096.board import (
    init_board, add_random_tile,
    move_left, rotate,
    has_won, can_move, TARGET
)
from py4096.render import print_board

def run():
    board = init_board()
    score = 0

    add_random_tile(board)
    add_random_tile(board)

    while True:
        print_board(board, score, TARGET)
        move = input("> ").lower()

        if move == "q":
            break

        rotations = {"a": 0, "w": 3, "d": 2, "s": 1}
        if move not in rotations:
            continue

        for _ in range(rotations[move]):
            board = rotate(board)

        new_board, moved = move_left(board)

        for _ in range((4 - rotations[move]) % 4):
            new_board = rotate(new_board)

        if moved:
            board = new_board
            add_random_tile(board)

            if has_won(board):
                print_board(board, score, TARGET)
                print(f"\n🎉 You reached {TARGET}! You win!")
                input("Press Enter to exit...")
                break

            if not can_move(board):
                print_board(board, score, TARGET)
                print("\n💀 No more moves. Game over.")
                input("Press Enter to exit...")
                break
