import os

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def print_board(board, score, target):
    clear()
    print(f"==== {target} ====\n")
    print(f"Score: {score}\n")

    for row in board:
        print(" | ".join(str(x).rjust(4) if x else "   ." for x in row))

    print("\nControls: W/A/S/D  |  Q = Quit")
