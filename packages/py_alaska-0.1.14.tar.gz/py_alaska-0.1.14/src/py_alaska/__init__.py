"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  ALASKA v2.0 - py_alaska                                                     ║
║  Multiprocess Task Management Framework                                      ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Version : 2.0.1                                                             ║
║  Date    : 2026-02-08                                                        ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Summary:                                                                    ║
║    Python 멀티프로세스 Task 관리 프레임워크                                  ║
║    - RMI (Remote Method Invocation) 기반 프로세스 간 통신                    ║
║    - Signal 기반 이벤트 브로드캐스트                                         ║
║    - SmBlock 공유 메모리 관리                                                ║
║    - HTTP 기반 모니터링 대시보드                                             ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from .task_decoration import rmi_task, rmi_run, rmi_signal, has_run_flag, get_signal_handlers, TaskValidator
from .task_manager import TaskManager, TaskInfo, TaskRuntime, RmiClient
from .task_monitor import TaskMonitor
from .task_log import LogRecord, RmiLogger, LogTask
from .task_signal import Signal, SignalBroker, SignalClient
from .sm_block import SmBlock, SmBlockHandler
from .task_monitor_sysinfo import HwInfoCollector
from .task_monitor_ext_link import (
    ExternalLinkManager,
    SlackSender,
    EmailSender,
    WebhookSender,
    HealthReporter,
    ReportScheduler,
)
from .task_performance import (
    MethodPerformance,
    TaskPerformance,
    SystemPerformance,
    TimingRecorder,
    PerformanceCollector,
)
from .task_banner import banner
from .task_log_handler import (
    SafeRotatingFileHandler,
    QueueFileHandler,
    QueueFileListener,
    create_safe_file_handler,
    setup_safe_logging,
)
from .gconfig import (
    gconfig,
    GConfig,
    ConfigError,
    ConfigFileNotFoundError,
    ConfigPathNotFoundError,
    ConfigLockTimeoutError,
    ConfigValidationError,
    ConfigParseError,
    ConfigIntegrityError,
    ConfigSecurityError,
    ConfigStaleLockError,
    ConfigMandatoryFieldError,
    ConfigRecoveryError,
)

__version__ = "2.1.0"
__all__ = [
    # Task Decorators & Validation
    "rmi_task", "rmi_run", "rmi_signal", "has_run_flag", "get_signal_handlers", "TaskValidator",
    # Task Manager
    "TaskManager", "TaskInfo", "TaskRuntime", "RmiClient", "TaskMonitor",
    # Log
    "LogRecord", "RmiLogger", "LogTask",
    # Signal
    "Signal", "SignalBroker", "SignalClient",
    # SmBlock
    "SmBlock", "SmBlockHandler",
    # SysInfo
    "HwInfoCollector",
    # External Link
    "ExternalLinkManager", "SlackSender", "EmailSender",
    "WebhookSender", "HealthReporter", "ReportScheduler",
    # Performance
    "MethodPerformance", "TaskPerformance", "SystemPerformance",
    "TimingRecorder", "PerformanceCollector",
    # Banner
    "banner",
    # Safe Logging
    "SafeRotatingFileHandler", "QueueFileHandler", "QueueFileListener",
    "create_safe_file_handler", "setup_safe_logging",
    # Config
    "gconfig", "GConfig",
    "ConfigError", "ConfigFileNotFoundError", "ConfigPathNotFoundError",
    "ConfigLockTimeoutError", "ConfigValidationError", "ConfigParseError",
    "ConfigIntegrityError", "ConfigSecurityError", "ConfigStaleLockError",
    "ConfigMandatoryFieldError", "ConfigRecoveryError",
]
