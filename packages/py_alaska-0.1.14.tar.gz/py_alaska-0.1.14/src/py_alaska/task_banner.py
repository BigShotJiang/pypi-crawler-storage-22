import unicodedata


def banner(msg: str) -> None:
    """Draw a box around the message with margin (supports wide characters like Korean, Chinese)"""
    def display_width(text: str) -> int:
        width = 0
        for char in text:
            if unicodedata.east_asian_width(char) in ('F', 'W'):
                width += 2
            else:
                width += 1
        return width

    margin = 4
    min_width = 80  # 최소 박스 폭
    lines = msg.split('\n')
    max_width = max(display_width(line) for line in lines) if lines else 0
    box_width = max(max_width + margin * 2, min_width)

    top_left = '┌'
    top_right = '┐'
    bottom_left = '└'
    bottom_right = '┘'
    horizontal = '─'
    vertical = '│'

    result = []
    result.append(top_left + horizontal * box_width + top_right)

    for line in lines:
        line_width = display_width(line)
        padding_left = ' ' * margin
        padding_right = ' ' * (box_width - margin - line_width)
        result.append(f'{vertical}{padding_left}{line}{padding_right}{vertical}')

    result.append(bottom_left + horizontal * box_width + bottom_right)

    output = '\n'.join(result)
    print(output.encode('utf-8').decode('utf-8'))