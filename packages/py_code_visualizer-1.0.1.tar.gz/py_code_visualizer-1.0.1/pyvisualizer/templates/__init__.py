"""HTML templates for PyVisualizer."""
