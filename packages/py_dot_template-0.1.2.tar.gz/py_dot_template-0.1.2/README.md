# py-dot-template

A Python project template using modern tooling with `uv` and `hatchling`.

## Requirements

- Python 3.12+
- [uv](https://docs.astral.sh/uv/) package manager

## Quickstart

**Installation**
```shell
# Pip
pip install py-dot-template 
# UV
uv add py-dot-template
```
**Usage**
```python
from dot_template import hello

hello()
```

## Development

See [docs/DEVELOPMENT.md](docs/DEVELOPMENT.md) for development setup, testing, and contribution guidelines.
See [docs/PUBLISHING.md](docs/PUBLISHING.md) for instructions on how to publish releases to PyPI.

## License

See [LICENSE](LICENSE) for details.
