# Development Guide

## Requirements

- Python 3.12+

## Installation

### Clone the repository

```shell
git clone git@gitlab.com:deepika6190303/deepika-open-toolbox/py-dot-template.git
cd py-dot-template
```

### Python environment

1. Install dependencies. From the root directory of the project:

```shell
# Switch to Python 3.12 (or 3.13)
uv venv --python python3.12

# Install virtual environment
uv sync
```

## Testing

To run tests with coverage, use the following command:

```shell
uv run pytest tests/
```

## Example

To run the example script, use the following command:

```shell
uv run example/hello.py
```

## Usage

To use the released package, follow the instructions in the [README](../README.md).

In development mode, you can install the package directly from the Gitlab repository using `uv`.

1. Create a Python 3.12 environment
```shell
mkdir -p /tmp/test-py-dot && cd /tmp/test-py-dot

uv venv --python 3.12
source .venv/bin/activate
python --version
```

2. Install the package
```shell
uv pip install "git+ssh://git@gitlab.com/deepika6190303/deepika-open-toolbox/py-dot-template.git@main"

> 💡 Replace `main` with a **tag** (e.g., `v0.1.0`) once you tag your release — this is the best practice for reproducible installs.