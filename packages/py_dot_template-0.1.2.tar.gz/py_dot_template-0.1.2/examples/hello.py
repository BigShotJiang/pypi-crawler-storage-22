from dot_template import hello

if __name__ == "__main__":
    print("Running example...")
    msg = hello()
    print(f"Received: {msg}")
