def hello() -> str:
    """
    Returns a greeting message.
    
    Returns:
        str: The greeting message "Hello Deepika"
    """
    message = "Hello Deepika"
    print(message)
    return message
