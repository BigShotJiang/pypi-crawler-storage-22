from dot_template import hello

def test_hello(capsys):
    """Test that hello() returns the correct string and prints to stdout."""
    result = hello()
    
    # Check return value
    assert result == "Hello Deepika"
    
    # Check stdout
    captured = capsys.readouterr()
    assert "Hello Deepika" in captured.out
