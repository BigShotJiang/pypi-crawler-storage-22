# py-dot-template

![Python Version](https://img.shields.io/badge/python-3.12%2B-blue)
![Coverage](https://img.shields.io/badge/coverage-100%25-brightgreen)


**dot-py-template** is a blueprint package designed to standardize Python development at **deepika**. It serves as a reference implementation for Clean Architecture, rigorous testing, and modern packaging.

## 🚀 Features

- **Minimalist Core:** A simple `hello()` function to demonstrate the pipeline.
- **Modern Stack:** Built with `uv`, `ruff`, and `ty`.
- **Quality First:** strict type checking and comprehensive testing setup.
- **Ready-to-use:** Includes CI/CD configuration and pre-commit hooks.


## 🛠️ Getting Started

### Installation

You can install the library using pip (or uv):

```bash
pip install dot-py-template
```

### Usage

```python
from dot_template import hello

# Returns and prints "Hello deepika"
message = hello()
```

## 🤝 Contributing
See [docs/CONTRIBUTING.md](docs/CONTRIBUTING.md) for contribution guidelines.

## 👩‍💻 Development
See [docs/DEVELOPMENT.md](docs/DEVELOPMENT.md) for development setup, testing, and contribution guidelines.

## 📦 Publishing
See [docs/PUBLISHING.md](docs/PUBLISHING.md) for instructions on how to publish releases to PyPI.

## 📄 License
See [LICENSE](LICENSE) for details.

## 📞 Contact
deepika Team - contact@deepika.ai
Project Link: [https://gitlab.com/deepika6190303/deepika-open-toolbox/py-dot-template](https://gitlab.com/deepika6190303/deepika-open-toolbox/py-dot-template)
