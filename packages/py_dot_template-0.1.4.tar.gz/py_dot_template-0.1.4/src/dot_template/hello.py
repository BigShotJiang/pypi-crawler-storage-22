def hello() -> str:
    """
    Returns a greeting message.
    
    Returns:
        str: The greeting message "Hello deepika"
    """
    message = "Hello deepika"
    print(message)
    return message
