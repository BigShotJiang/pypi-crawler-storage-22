#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
HttpxRequest 模块

该模块提供了基于 httpx 库的 HTTP 请求封装，支持同步和异步请求方式。
通过统一的接口，可以方便地发送 HTTP 请求并处理响应。
"""
from typing import Optional

import httpx


class HttpxRequest:
    """
    HTTP 请求封装类

    提供同步和异步 HTTP 请求功能，支持自定义客户端配置。
    可以重复使用同一个客户端实例，也可以每次请求创建新的客户端。

    Attributes:
        client_kwargs: 传递给 httpx.Client 和 httpx.AsyncClient 的默认参数
    """
    def __init__(self, client_kwargs=None):
        """
        初始化 HttpxRequest 实例

        Args:
            client_kwargs: 客户端配置参数，将传递给 httpx.Client 和 httpx.AsyncClient
                          例如：{'timeout': 30.0, 'headers': {'User-Agent': 'Custom'}})
        """
        self.client_kwargs = client_kwargs or {}

    def client(self, **kwargs) -> httpx.Client:
        """
        创建同步 httpx.Client 实例

        Args:
            **kwargs: 传递给 httpx.Client 的额外参数，会覆盖默认参数

        Returns:
            httpx.Client - 配置好的同步客户端实例
        """
        return httpx.Client(**{**self.client_kwargs, **kwargs})

    def async_client(self, **kwargs) -> httpx.AsyncClient:
        """
        创建异步 httpx.AsyncClient 实例

        Args:
            **kwargs: 传递给 httpx.AsyncClient 的额外参数，会覆盖默认参数

        Returns:
            httpx.AsyncClient - 配置好的异步客户端实例
        """
        return httpx.AsyncClient(**{**self.client_kwargs, **kwargs})

    def request(self, client: Optional[httpx.Client] = None, **kwargs) -> httpx.Response:
        """
        同步请求方法

        如果提供了客户端实例，则使用该实例发送请求；
        否则，创建新的客户端实例并在请求完成后自动关闭。

        Args:
            client: 可选的同步客户端实例
            **kwargs: 传递给 client.request 的额外参数，如 method, url, data, json 等

        Returns:
            httpx.Response - HTTP 响应对象

        Examples:
            # 基本用法
            request = HttpxRequest()
            response = request.request(method='GET', url='https://example.com')
            
            # 使用自定义客户端
            client = request.client(timeout=60.0)
            response = request.request(client=client, method='POST', url='https://example.com', json={'key': 'value'})
        """
        if not isinstance(client, httpx.Client):
            # 如果没有提供客户端实例，创建新实例并使用上下文管理器自动关闭
            with self.client() as client:
                return client.request(**kwargs)
        return client.request(**kwargs)

    async def async_request(self, client: Optional[httpx.AsyncClient] = None, **kwargs) -> httpx.Response:
        """
        异步请求方法

        如果提供了异步客户端实例，则使用该实例发送请求；
        否则，创建新的异步客户端实例并在请求完成后自动关闭。

        Args:
            client: 可选的异步客户端实例
            **kwargs: 传递给 client.request 的额外参数，如 method, url, data, json 等

        Returns:
            httpx.Response - HTTP 响应对象

        Examples:
            # 基本用法
            request = HttpxRequest()
            response = await request.async_request(method='GET', url='https://example.com')
            
            # 使用自定义异步客户端
            client = request.async_client(timeout=60.0)
            response = await request.async_request(client=client, method='POST', url='https://example.com', json={'key': 'value'})
        """
        if not isinstance(client, httpx.AsyncClient):
            # 如果没有提供异步客户端实例，创建新实例并使用异步上下文管理器自动关闭
            async with self.async_client() as client:
                return await client.request(**kwargs)
        return await client.request(**kwargs)