#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
response 模块

该模块提供了 HTTP 响应处理功能，包括 JSON 数据验证和提取。
主要通过装饰器形式，对 httpx.Response 对象进行 JSON 解析、Schema 验证和 JSONPath 提取。
"""
from typing import Optional, Any, Union

import httpx
from decorator import decorator
from jsonpath_ng import parse
from jsonschema.validators import Draft202012Validator


def json_paser(
        validator: Optional[dict] = None,
        path_expr: Optional[str] = None,
):
    """
    JSON 响应解析装饰器（同步）

    用于装饰返回 httpx.Response 对象的同步函数，自动处理 JSON 解析、Schema 验证和 JSONPath 提取。

    Args:
        validator: JSON Schema 验证规则，用于验证响应数据的结构
        path_expr: JSONPath 表达式，用于从验证通过的 JSON 数据中提取特定路径的值

    Returns:
        装饰器函数，装饰后的函数会返回：
        - 如果 Schema 验证失败：None
        - 如果 Schema 验证通过且未指定 path_expr：True
        - 如果 Schema 验证通过且指定了 path_expr：提取的第一个匹配值

    Examples:
        # 基本用法：验证响应结构
        @json_paser(validator={"type": "object", "properties": {"name": {"type": "string"}}})
        def get_user():
            response = httpx.get("https://api.example.com/user")
            return response

        # 提取特定字段
        @json_paser(
            validator={"type": "object", "properties": {"data": {"type": "object", "properties": {"id": {"type": "integer"}}}},
            path_expr="$.data.id"
        )
        def get_user_id():
            response = httpx.get("https://api.example.com/user")
            return response
    """
    # 默认值处理：如果未提供 validator 或 path_expr，则使用空值
    validator = validator or {}
    path_expr = path_expr or ""

    @decorator
    def decorator_func(func, *args, **kwargs):
        """
        装饰器内部函数，处理同步函数的响应

        Args:
            func: 被装饰的同步函数
            *args: 被装饰函数的位置参数
            **kwargs: 被装饰函数的关键字参数

        Returns:
            处理后的结果，根据验证和提取情况返回不同值
        """
        # 执行被装饰的函数，获取结果（预期为 httpx.Response 对象）
        func_result: httpx.Response = func(*args, **kwargs)
        json_data = func_result
        
        # 如果结果是 httpx.Response 对象，则尝试解析为 JSON
        if isinstance(func_result, httpx.Response):
            try:
                json_data = func_result.json()
            except:
                # 如果解析失败，保持原始结果
                pass
        
        # 使用 JSON Schema 验证数据结构
        if Draft202012Validator(validator).is_valid(json_data):
            # 如果未指定 JSONPath 表达式，直接返回 True 表示验证通过
            if not isinstance(path_expr, str) or not len(path_expr) > 0:
                return True
            # 使用 JSONPath 提取指定路径的值
            matches = [i.value for i in parse(path_expr).find(json_data)]
            # 如果找到匹配值，返回第一个匹配项
            if isinstance(matches, list) and len(matches) > 0:
                return matches[0]
        # 验证失败或未找到匹配值，返回 None
        return None

    return decorator_func


def async_json_paser(
        validator: Optional[dict] = None,
        path_expr: Optional[str] = None,
):
    """
    JSON 响应解析装饰器（异步）

    用于装饰返回 httpx.Response 对象的异步函数，自动处理 JSON 解析、Schema 验证和 JSONPath 提取。

    Args:
        validator: JSON Schema 验证规则，用于验证响应数据的结构
        path_expr: JSONPath 表达式，用于从验证通过的 JSON 数据中提取特定路径的值

    Returns:
        异步装饰器函数，装饰后的函数会返回：
        - 如果 Schema 验证失败：None
        - 如果 Schema 验证通过且未指定 path_expr：True
        - 如果 Schema 验证通过且指定了 path_expr：提取的第一个匹配值

    Examples:
        # 基本用法：验证响应结构
        @async_json_paser(validator={"type": "object", "properties": {"name": {"type": "string"}}})
        async def get_user():
            async with httpx.AsyncClient() as client:
                response = await client.get("https://api.example.com/user")
                return response

        # 提取特定字段
        @async_json_paser(
            validator={"type": "object", "properties": {"data": {"type": "object", "properties": {"id": {"type": "integer"}}}},
            path_expr="$.data.id"
        )
        async def get_user_id():
            async with httpx.AsyncClient() as client:
                response = await client.get("https://api.example.com/user")
                return response
    """
    # 默认值处理：如果未提供 validator 或 path_expr，则使用空值
    validator = validator or {}
    path_expr = path_expr or ""

    @decorator
    async def decorator_func(func, *args, **kwargs):
        """
        装饰器内部函数，处理异步函数的响应

        Args:
            func: 被装饰的异步函数
            *args: 被装饰函数的位置参数
            **kwargs: 被装饰函数的关键字参数

        Returns:
            处理后的结果，根据验证和提取情况返回不同值
        """
        # 执行被装饰的异步函数，获取结果（预期为 httpx.Response 对象）
        func_result: httpx.Response = await func(*args, **kwargs)
        json_data = func_result
        
        # 如果结果是 httpx.Response 对象，则尝试解析为 JSON
        if isinstance(func_result, httpx.Response):
            try:
                json_data = func_result.json()
            except:
                # 如果解析失败，保持原始结果
                pass
        
        # 使用 JSON Schema 验证数据结构
        if Draft202012Validator(validator).is_valid(json_data):
            # 如果未指定 JSONPath 表达式，直接返回 True 表示验证通过
            if not isinstance(path_expr, str) or not len(path_expr) > 0:
                return True
            # 使用 JSONPath 提取指定路径的值
            matches = [i.value for i in parse(path_expr).find(json_data)]
            # 如果找到匹配值，返回第一个匹配项
            if isinstance(matches, list) and len(matches) > 0:
                return matches[0]
        # 验证失败或未找到匹配值，返回 None
        return None

    return decorator_func