"""API modules for Euroleague API versions."""

from euroleague.api.base import BaseAPI

__all__ = ["BaseAPI"]
