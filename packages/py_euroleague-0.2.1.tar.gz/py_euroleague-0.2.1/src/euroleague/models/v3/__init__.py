"""V3 response models."""
