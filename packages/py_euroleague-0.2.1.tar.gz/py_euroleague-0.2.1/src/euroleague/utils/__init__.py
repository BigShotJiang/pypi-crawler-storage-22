"""Utility modules for py-euroleague."""

from euroleague.utils.constants import BASE_URL, CompetitionCode

__all__ = ["BASE_URL", "CompetitionCode"]
