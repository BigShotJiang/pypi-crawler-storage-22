from setuptools import setup, find_packages

setup(
    name='py_me',
    version='3.5.1',
    packages=find_packages(),
    description='Library with music, graphics, and project creation modules.',
    author='isaias da silva nobrega',
    author_email='isaiasdasilvanobrega@gmail.com',
)