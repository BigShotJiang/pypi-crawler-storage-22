* website: [Website](https://arrizza.com/py-runner-base.html)
* installation: [Common Setup](https://arrizza.com/setup-common.html)

## Summary

This project is a base class for running various commands in python from the command line.

see ```sample/toolbox_app.py``` for an example use.

see ```doc/api.md``` for the API available.

## how to run

Don't specify a command gives you help.
Note that you can use check() in toolbox_runner.py or run() in toolbox_app.py to
specify a default command.

```bash
./doit 
WARN no command chosen, nothing to do
     py-runner-base: v0.1.0
     Choose one of these:
        task1               : run task1
        task2a              : run task2 step-a
        task2b              : run task2 step-b
        task3               : run task3
        task4               : run task4
```

Note: that there are several sorting orders available, see property ```sort_order``` in base_runner.py or
cmd_map.py.

* Add an argument ```arg1```:

```text
$ ./doit task1 arg1
==== doit: starting...
     running Task1 args:['arg1']
     doit: run_it rc=0
```

* Run a command "task1" that has no prerequisites:

```bash
./doit task1
==== doit: starting...
     running Task1 args:[]
     doit: run_it rc=0
```

* Run a command "task2b" that has a prerequisite:

```bash
./doit task2b
==== doit: starting...
     running Task2 step-a
     running Task2 step-b
     doit: run_it rc=0
```

## how to add commands

See the ```sample/taskxx.py``` files for example tasks.
Note ```register()``` functions that allow you to specify command names for any tasks
you want to add.

```text
    # --------------------
    def register(self, runner):
        self._runner = runner
        self._runner.add_cmd('task2a', self._run_step_a, 'run task2 step-a')
        self._runner.add_cmd('task2b', self._run_step_b, 'run task2 step-b', prereqs=['task2a'])
```
