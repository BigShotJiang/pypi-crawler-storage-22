from .svc import svc


# --------------------
## holds info about the current known cmds
class CmdMap:
    # --------------------
    ## constructor
    def __init__(self):
        ## list of all commands
        self._cmd_map = {}

        ## sorting index
        self._created_idx = 1

        ## how to sort
        self._sort_order = 'created'

        ## sorted list of cmd names
        self._sorted_cmds = []

    # --------------------
    ## add a command
    # @param cmd        the command name
    # @param cmd_fn     the function to invoke when this command is named
    # @param desc       help for this command
    # @param prereqs    any pre-requisite commands for this cmd
    # @param sort_idx   the sorting value/index for this cmd
    # @return None
    def add_cmd(self, cmd, cmd_fn, desc, prereqs=None, sort_idx=0):
        if self.is_registered(cmd):
            svc.log.warn(f'command already registered: {cmd}, skipping')
            return

        self._cmd_map[cmd] = {
            'fn': cmd_fn,
            'prereqs': prereqs,
            'created_idx': self._created_idx,
            'sort_idx': sort_idx,
            'help': desc,
        }
        self._created_idx += 1

    # --------------------
    ## returns the chosen sort order (see the setter)
    # @return the chosen sort order
    @property
    def sort_order(self):
        return self._sort_order

    # --------------------
    ## set the sort order:
    #   * 'created' - (default) run as created via register()
    #   * 'entered' - run as entered
    #   * 'alpha'   - sort alphabetically
    #   * 'index'   - sort by index
    #
    # @param choice  the requested sort_order
    # @return None
    @sort_order.setter
    def sort_order(self, choice):
        valid = ['created', 'entered', 'alpha', 'index']
        if choice not in valid:
            raise ValueError(f'invalid choice: {choice}, must be one of: {valid}')
        self._sort_order = choice

    # --------------------
    ## returns list of sorted commands.
    # see sort_order.setter for valid sorting.
    #
    # @param entered_cmds   the list of commands entered by the caller
    # @return the list of commands to perform based on the current sort order
    def sorted_cmds(self, entered_cmds=None):
        cmds_to_do = None
        if entered_cmds is None:
            if self._sort_order == 'alpha':
                cmds_to_do = sorted(self._cmd_map.keys())
            if self._sort_order == 'index':
                cmds_to_do = sorted(self._cmd_map.keys(), key=lambda cmdx: self._cmd_map[cmdx]['sort_idx'])
            if self._sort_order in ['created', 'entered']:
                cmds_to_do = list(self._cmd_map.keys())
        else:
            if self._sort_order == 'alpha':
                cmds_to_do = sorted(entered_cmds)
            if self._sort_order == 'index':
                cmds_to_do = sorted(entered_cmds, key=lambda cmdx: self._cmd_map[cmdx]['sort_idx'])
            if self._sort_order == 'entered':
                cmds_to_do = entered_cmds
            if self._sort_order == 'created':
                cmds_to_do = []
                for cmd in list(self._cmd_map.keys()):
                    if cmd in entered_cmds:
                        cmds_to_do.append(cmd)
        if cmds_to_do is None:
            raise RuntimeError(f'invalid sort order: {self._sort_order}')
        return cmds_to_do

    # --------------------
    ## returns True if the cmd is registered in the cmd_map
    # @param cmd  the command name
    # @return True if the cmd is registered in the cmd_map
    def is_registered(self, cmd):
        return cmd in self._cmd_map

    # --------------------
    ## check if the given command is registered. If not, the help is printed using the given prefix
    #
    # @param pfx    the logging prefix to use
    # @param cmd    the command to check
    # @return True if registered, False otherwise
    def check_valid_cmd(self, pfx, cmd):
        if self.is_registered(cmd):
            return True

        svc.rc += 1
        svc.log.raw(f'{pfx}: unknown command:', cmd)
        self.print_help('   ')
        return False

    # --------------------
    ## returns the function pointer for the given cmd
    # @param cmd    the command name
    # @return the function pointer for the given cmd
    def get_fn(self, cmd):
        if not self.is_registered(cmd):
            svc.rc += 1
            svc.log.err(f'get_fn: unknown command: {cmd}')
            return None

        return self._cmd_map[cmd]['fn']

    # --------------------
    ## get the list of prereqs (if any) for the given command
    # @param cmd  the cmd name
    # @return None if the the command is not registered, a list of prereqs (possibly empty)
    def get_prereqs(self, cmd):
        if not self.is_registered(cmd):
            svc.rc += 1
            svc.log.err(f'get_prereqs: unknown command: {cmd}')
            return None

        return self._cmd_map[cmd]['prereqs']

    # --------------------
    ## print the help for the current set of commands
    # @param prefix  the logging prefix to use
    # @return None
    def print_help(self, prefix=''):
        for cmd in self.sorted_cmds():
            help_str = self._cmd_map[cmd]['help']
            line = f'{cmd: <20}: {help_str}'
            svc.log.raw(f'{prefix}{line}')
