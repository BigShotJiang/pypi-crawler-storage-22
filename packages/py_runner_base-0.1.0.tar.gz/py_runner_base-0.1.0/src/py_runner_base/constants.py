from dataclasses import dataclass

from .constants_version import ConstantsVersion


# -------------------
## Holds various constants
@dataclass
class Constants(ConstantsVersion):  # pylint: disable=too-few-public-methods
    pass
