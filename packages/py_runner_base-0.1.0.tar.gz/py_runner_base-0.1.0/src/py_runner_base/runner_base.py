import inspect
import sys

from falcon_logger import FalconLogger

from .cmd_map import CmdMap
from .constants import Constants
from .svc import svc


# -------------------
## parent class, holds all commands and common data
class RunnerBase:
    # -------------------
    ## constructor
    def __init__(self):
        super().__init__()
        ## reference to CmdMap
        self._cmd_map = CmdMap()
        ## current list of known commands
        self._cmds = []
        ## any args entered from the CLI
        self._args = []
        ## whether this is a dry-run or not (set "-n" on CLI)
        self._dry_run = False
        ## prefix for various log lines
        self._pfx = 'py-runner-base'

    # -------------------
    ## returns the current return code
    # @return the current rc
    @property
    def rc(self):
        return svc.rc

    # -------------------
    ## initialize the base content
    # @param logger  (optional) defaults to FalconLogger
    # @param prefix  (optional) the prefix to use for various log lines; defaults to "py-runner-base"
    def init_runner_base(self, logger=None, prefix=None):
        if logger is None:  # pragma: no cover  UTs set the logger
            svc.log = FalconLogger(mode='immediate')
            svc.log.set_format('prefix')
        else:
            svc.log = logger
        # uncomment to test log setup
        # print(f'runner: svc.whoami: {svc.whoami} {svc.log}')

        if prefix is not None:  # pragma: no cover  UTs set the prefix
            self._pfx = prefix

    # -------------------
    ## register a command
    # @param cmd        the command name
    # @param cmd_fn     the function to invoke when this command is named
    # @param desc       help for this command
    # @param prereqs    any pre-requisite commands for this cmd
    # @param sort_idx   the sorting value/index for this cmd
    # @return None
    def add_cmd(self, cmd, cmd_fn, desc, prereqs=None, sort_idx=0):
        self._cmd_map.add_cmd(cmd, cmd_fn, desc, prereqs, sort_idx)

    # -------------------
    ## register a task class.
    # Assumes:
    #  * it is a class name, i.e. the class has not been instantiated
    #  * the class has a register() function which does the registration using add_cmd()
    #
    # @param new_clazz   a list, tuple, or string of the class(es) to register
    # @return None
    def register(self, new_clazz):
        if isinstance(new_clazz, (tuple, list)):
            for clazz in new_clazz:
                self._register_task(clazz)
        elif inspect.isclass(new_clazz):
            self._register_task(new_clazz)
        else:
            svc.rc += 1
            raise TypeError(f'register expects a tuple or list or a single class, actual: {type(new_clazz)}')

    # -------------------
    ## instantiates a class and calls register(self) on it
    #
    # @param clazz  the clazz to instantiate
    # @return None
    def _register_task(self, clazz):
        try:
            inst = clazz()
        except TypeError as excp:
            svc.log.err(f'failed to instantiate class: {clazz.__name__}')
            svc.log.exception(excp, max_lines=1)
            svc.rc += 1
            return

        if not hasattr(inst, 'register'):
            svc.log.err(f'task class is missing function register(): {inst.__class__.__name__}')
            svc.rc += 1
            return

        # It exists, but is it a function?
        if not callable(inst.register):
            svc.log.err(f'task class register() is not callable: {inst.__class__.__name__}')
            svc.rc += 1
            return

        inst.register(self)

    # -------------------
    ## run all of the commands requested by the CLI.
    # The commands are sorted according to the sort_order()
    # @return None
    def run_all(self):
        if svc.rc > 0:
            svc.log.err(f'{self._pfx}: rc={svc.rc}, cannot run')
            return

        for cmd in self._cmd_map.sorted_cmds(self._cmds):
            # svc.log.dbg(f'curr_cmd: {cmd}')
            # TODO add a mode to end if run_cmd returns non-zero
            self.run_cmd(cmd)

    # -------------------
    ## adds any prerequisite cmds specified by the registered command.
    # The cmds property will return the new set of commands
    # @return None.
    def _add_prereqs(self):
        errs = 0
        new_cmds = []
        for cmd in self._cmds:
            if cmd not in new_cmds:
                new_cmds.append(cmd)
            errs += self._add_prereqs_for(cmd, new_cmds)

        if errs != 0:
            raise ValueError('missing prereq(s). Add those commands')

        # svc.log.dbg(f'add_prereqs: new_cmds: {new_cmds}')
        self._cmds = new_cmds

    # -------------------
    ## add any prereqs for the given command
    #
    # @param cmd      the cmd name to check
    # @param new_cmds the new set of commands formed with any additional prereqs
    # @return 0 if no errors, others a non-zero to indicate a problem occurred
    def _add_prereqs_for(self, cmd, new_cmds):
        errs = 0
        prereqs = self._cmd_map.get_prereqs(cmd)
        if prereqs is None:
            return errs

        # svc.log.dbg(f'add_prereqs: prereqs: {prereqs}')

        if isinstance(prereqs, str):
            prereqs = [prereqs]
        for prereq in prereqs:
            # svc.log.dbg(f'add_prereqs: prereq: {prereq}')
            if not self._cmd_map.is_registered(prereq):
                errs += 1
                # TODO check if there is a case where the user wants the ability to specify a future cmd
                svc.log.err(f'prereq is not registered: {prereq}')
                svc.rc += 1
                continue

            # it's missing, so add it
            if prereq not in new_cmds:
                new_cmds.insert(0, prereq)
                self._add_prereqs_for(prereq, new_cmds)

        return errs

    # -------------------
    ## run the given command
    #
    # @param cmd_name   the cmd name
    # @return errs
    def run_cmd(self, cmd_name):
        # don't use svc.rc in this function
        # the caller's functions will run to completion
        errs = 0
        if not self._cmd_map.check_valid_cmd(self._pfx, cmd_name):
            errs += 1
            return errs

        # TODO call get_cli_info to ensure args are okay for this command
        #    pass the current command into get_cli_info()

        if self._dry_run:
            svc.log.line(f'dry_run cmd: {cmd_name}')
        else:
            fn = self._cmd_map.get_fn(cmd_name)
            errs += fn()
        return errs

    # --------------------
    ## returns the chosen sort order (see the setter)
    # @return the chosen sort order
    @property
    def sort_order(self):
        return self._cmd_map.sort_order

    # --------------------
    ## set the sort order:
    #   * 'created' - (default) run as created via register()
    #   * 'entered' - run as entered
    #   * 'alpha'   - sort alphabetically
    #   * 'index'   - sort by index
    #
    # @param new_sort_order  the new sort_order to set
    # @return None
    @sort_order.setter
    def sort_order(self, new_sort_order):
        self._cmd_map.sort_order = new_sort_order

    # --------------------
    ## returns the current set of commands that will be run
    # @return the current set of commands
    @property
    def cmds(self):
        return self._cmds

    # --------------------
    ## returns the current set of CLI args
    # @return the current set of CLI args
    @property
    def args(self):
        return self._args

    # --------------------
    ## returns if this a dry run. see "-n" CLI arg.
    # @return if this is a dry run
    @property
    def dry_run(self):
        return self._dry_run

    # -------------------
    ## delete the given command from the list of commands to run
    # @param cmd_name  the cmd to remove
    # @return None
    def delete_cmd(self, cmd_name):
        self._cmds.remove(cmd_name)

    # -------------------
    ## get commands and args from the command line
    # @return None
    def get_cli_info(self):
        show_err_msg = False

        self._args = []
        for idx, arg in enumerate(sys.argv):
            if idx == 0:
                continue

            if arg == '-n':
                self._dry_run = True
                continue

            if self._cmd_map.is_registered(arg):
                self._cmds.append(arg)
                continue

            ok = self.handle_unknown_arg(arg)
            if not ok:
                show_err_msg = True
                svc.rc += 1
                break

        # uncomment to debug
        # show_err_msg = True
        # svc.log.dbg(f'sys.argv: {sys.argv}')
        # svc.log.dbg(f'cmds    : {self._cmds}')
        # svc.log.dbg(f'args    : {self._args}')

        if show_err_msg:
            self.report_err_msg()
        else:
            # at this point: the cmds to run are set
            # add any prereqs based on the current chosen commands
            self._add_prereqs()

    # -------------------
    ## callback when an unknown CLI arg is found.
    # Normally this is overridden when using this base class
    #
    # @param _arg  the CLI argument found
    # @return True if no error occurred, False when an errror occurred
    def handle_unknown_arg(self, _arg):
        # default, just ignore it
        return True  # pragma: no cover

    # -------------------
    ## reports the list of registered commands
    # @return None
    def report_err_msg(self):
        svc.log.line(f'{self._pfx}: v{Constants.version}')
        svc.log.line('Choose one of these:')
        self._cmd_map.print_help(prefix='        ')

    # -------------------
    ## returns True if the cmd list from the CLI is empty, False otherwise
    # @return if there are any commands to execute
    def nothing_chosen(self):
        return not self.cmds
