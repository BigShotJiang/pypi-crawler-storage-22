# -------------------
## holds various singletons needed for RunnerBase and other classes
class SingletonServices:  # pylint: disable=too-few-public-methods
    ## return code
    rc = 0

    ## holds reference to logger
    log = None


svc = SingletonServices()
