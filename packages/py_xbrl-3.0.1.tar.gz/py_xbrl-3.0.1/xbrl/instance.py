"""
This module contains all classes and functions necessary for parsing a Instance file.

This module will also access other Modules i.e TaxonomySchema.py to parse the Instance file
as well as the taxonomies and linkbases used by the instance files
"""

import abc
import json
import logging
import re
import xml.etree.ElementTree as ET
from datetime import date, datetime
from io import StringIO
from pathlib import Path
from typing import Any

from xbrl import InstanceParseException
from xbrl.cache import HttpCache
from xbrl.helper.uri_helper import is_url, resolve_uri
from xbrl.helper.xml_parser import get_ns_map, parse_file
from xbrl.taxonomy import Concept, TaxonomyParser, TaxonomySchema
from xbrl.transformations import (
    TransformationException,
    TransformationNotImplemented,
    normalize,
)

logger = logging.getLogger(__name__)
LINK_NS: str = "{http://www.xbrl.org/2003/linkbase}"
XLINK_NS: str = "{http://www.w3.org/1999/xlink}"
XDS_NS: str = "{http://www.w3.org/2001/XMLSchema}"
XBRLI_NS: str = "{http://www.xbrl.org/2003/instance}"

NAME_SPACES: dict = {
    "xsd": "http://www.w3.org/2001/XMLSchema",
    "link": "http://www.xbrl.org/2003/linkbase",
    "xlink": "http://www.w3.org/1999/xlink",
    "xbrldt": "http://xbrl.org/2005/xbrldt",
    "xbrli": "http://www.xbrl.org/2003/instance",
    "xbrldi": "http://xbrl.org/2006/xbrldi",
}


class AbstractMember(abc.ABC):
    def __init__(self, dimension: Concept) -> None:
        self.dimension = dimension

    def __str__(self) -> str:
        return f"Dimension {self.dimension.name}"

    def to_dict(self):
        return {
            "dimension": self.dimension.to_dict(),
        }

    def to_json(self):
        return json.dumps(self.to_dict())


class TypedMember(AbstractMember):
    """
    Representation of a typed member in xbrl.

    XML Example:
    <xbrldi:typedMember dimension="us-gaap:RevenueRemainingPerformanceObligationExpectedTimingOfSatisfactionStartDateAxis">
        <us-gaap:RevenueRemainingPerformanceObligationExpectedTimingOfSatisfactionStartDateAxis.domain>2024-06-30</us-gaap:RevenueRemainingPerformanceObligationExpectedTimingOfSatisfactionStartDateAxis.domain>
    </xbrldi:typedMember>
    """

    def __init__(self, dimension: Concept, domain: list[str]) -> None:
        super().__init__(dimension)
        self.domain = domain

    def __str__(self) -> str:
        return f"{self.domain} on dimension {self.dimension.name}"

    def to_dict(self):
        return {"dimension": self.dimension.to_dict(), "domain": self.domain}

    def to_json(self):
        return json.dumps(self.to_dict())


class ExplicitMember(AbstractMember):
    """
    Representation of an explicit member in xbrl.

    XML Example:
    <xbrldi:explicitMember dimension="us-gaap:StatementBusinessSegmentsAxis">aapl:EuropeSegmentMember</xbrldi:explicitMember>
    """

    def __init__(self, dimension: Concept, member: Concept) -> None:
        super().__init__(dimension)
        self.member = member

    def __str__(self) -> str:
        return f"{self.member.name} on dimension {self.dimension.name}"

    def to_dict(self):
        return {"dimension": self.dimension.to_dict(), "member": self.member.to_dict()}

    def to_json(self):
        return json.dumps(self.to_dict())


class AbstractContext(abc.ABC):
    """
    Abstract class used for a context

    The segment array stores the dimensional information about the context. According to the XBRL Dimensions 1.0
    specification, the segment array can either have explicit members or typed members. This parser will only
    parse explicit members.
    """

    def __init__(self, xml_id: str, entity: str) -> None:
        self.xml_id: str = xml_id
        self.entity: str = entity
        self.segments: list[AbstractMember] = []


class InstantContext(AbstractContext):
    """
    Class representing an instant context:
    XML Example:
    <xbrli:context id="I2016Q3Sep9">
        <xbrli:entity><xbrli:identifier scheme="http://www.sec.gov/CIK">0001495320</xbrli:identifier></xbrli:entity>
        <xbrli:period><xbrli:instant>2015-09-09</xbrli:instant></xbrli:period>
    </xbrli:context>
    """

    def __init__(self, xml_id: str, entity: str, instant_date: date) -> None:
        super().__init__(xml_id, entity)
        self.instant_date: date = instant_date

    def __str__(self) -> str:
        return f"{self.instant_date} {len(self.segments)} dimension"


class TimeFrameContext(AbstractContext):
    """
    Class representing a time frame context
    XML Example:
    <xbrli:context id="FD2016Q2YTD">
    <xbrli:entity><xbrli:identifier scheme="http://www.sec.gov/CIK">0001495320</xbrli:identifier></xbrli:entity>
        <xbrli:period>
            <xbrli:startDate>2015-02-01</xbrli:startDate><xbrli:endDate>2015-08-01</xbrli:endDate>
        </xbrli:period>
    </xbrli:context>
    """

    def __init__(
        self, xml_id: str, entity: str, start_date: date, end_date: date
    ) -> None:
        super().__init__(xml_id, entity)
        self.start_date: date = start_date
        self.end_date: date = end_date

    def __str__(self) -> str:
        return f"{self.start_date} to {self.end_date} {len(self.segments)} dimension"


class ForeverContext(AbstractContext):
    """
    Class representing a forever context
    XML Example:
    <xbrli:context id="Forever">
        <xbrli:entity><xbrli:identifier scheme="http://www.sec.gov/CIK">0000880285</xbrli:identifier></xbrli:entity>
        <xbrli:period><xbrli:forever/></xbrli:period>
    </xbrli:context>
    """

    def __init__(self, xml_id: str, entity: str) -> None:
        super().__init__(xml_id, entity)


class AbstractUnit(abc.ABC):
    """
    Class representing a Unit, defined in the instance file
    """

    def __init__(self, unit_id: str) -> None:
        self.unit_id: str = unit_id


class SimpleUnit(AbstractUnit):
    """
    Class representing a Simple Unit.
    XML example:
    <xbrli:unit id="shares">
        <xbrli:measure>xbrli:shares</xbrli:measure>
    </xbrli:unit>
    """

    def __init__(self, unit_id: str, unit: str) -> None:
        super().__init__(unit_id)
        self.unit: str = unit

    def __str__(self):
        return self.unit


class DivideUnit(AbstractUnit):
    """
    Class representing a divided unit (i.e usd/share)
    XML example:
    <xbrli:unit id="usdPerShare">
        <xbrli:divide>
            <xbrli:unitNumerator><xbrli:measure>iso4217:USD</xbrli:measure></xbrli:unitNumerator>
            <xbrli:unitDenominator><xbrli:measure>xbrli:shares</xbrli:measure></xbrli:unitDenominator>
        </xbrli:divide>
    </xbrli:unit>
    """

    def __init__(self, unit_id: str, numerator: str, denominator: str) -> None:
        super().__init__(unit_id)
        self.numerator: str = numerator
        self.denominator: str = denominator

    def __str__(self):
        return self.numerator + "/" + self.denominator


class AbstractFact(abc.ABC):
    """
    Class representing a XBRL Fact.
    A Fact combines a Value with a Concept and a Context
    """

    def __init__(
        self, concept: Concept, context: AbstractContext, value: Any, xml_id: str | None
    ) -> None:
        """
        :param concept: concept from the taxonomy, that the fact is referencing
        :param context: context of the fact
        :param value: value of the fact (can be number or text)
        :param xml_id: id value of the fact
        """
        self.concept: Concept = concept
        self.context: AbstractContext = context
        self.value: Any = value
        self.xml_id = xml_id
        self.footnote: Footnote | None = None

    def __str__(self) -> str:
        return f"{self.concept.name}: {self.value}"

    def json(self, **kwargs) -> dict:
        period: str
        if isinstance(self.context, TimeFrameContext):
            start_date = self.context.start_date.strftime("%Y-%m-%dT%H:%M:%S")
            end_date = self.context.end_date.strftime("%Y-%m-%dT%H:%M:%S")
            period = f"{start_date}/{end_date}"
        elif isinstance(self.context, InstantContext):
            instant_date = self.context.instant_date.strftime("%Y-%m-%dT%H:%M:%S")
            period = str(instant_date)
        else:
            period = ""  # Forever context not specified in REC-2021-10-13

        kwargs["value"] = self.value
        if "dimensions" not in kwargs:
            kwargs["dimensions"] = {}
        kwargs["dimensions"]["concept"] = self.concept.name
        kwargs["dimensions"]["entity"] = self.context.entity
        kwargs["dimensions"]["contextId"] = self.context.xml_id
        kwargs["dimensions"]["period"] = period
        for segment in self.context.segments:
            if isinstance(segment, ExplicitMember):
                kwargs["dimensions"][segment.dimension.name] = segment.member.name
        return kwargs


class NumericFact(AbstractFact):
    """
    Class representing a numeric XBRL Fact
    XML Example:
    <us-gaap:Assets contextRef="FI2015Q4" decimals="-3" id="Fact-7214827CB0865D3EDB8BC10FF27FAF5E"
        unitRef="usd">377284000</us-gaap:Assets>
    """

    def __init__(
        self,
        concept: Concept,
        context: AbstractContext,
        value: float | None,
        unit: AbstractUnit,
        decimals: int | None,
        xml_id: str | None,
    ) -> None:
        """
        :param concept: see Abstract Fact
        :param context: see Abstract Fact
        :param value: see Abstract Fact
        :param unit: unit of the Numeric fact (i.e usd or usd/share)
        :param decimals: how accurate the number is. If decimals is none, the value of the fact is considered as
        accurate, without rounding errors
        """
        super().__init__(concept, context, value, xml_id)
        self.unit: AbstractUnit = unit
        self.decimals: int | None = decimals

    def json(self, **kwargs) -> dict:
        return super().json(
            dimensions={"unit": str(self.unit)}, decimals=self.decimals, **kwargs
        )


class TextFact(AbstractFact):
    """
    Class representing a text XBRL Fact
    XML Example:
    <dei:DocumentFiscalPeriodFocus contextRef="c-123" id="f-123">Q2</dei:DocumentFiscalPeriodFocus>
    @warning The content of a Text fact can be huge. Especially for Text Blocks, those can also contain HTML code
    """

    def __init__(
        self, concept: Concept, context: AbstractContext, value: str, xml_id: str | None
    ) -> None:
        super().__init__(concept, context, value, xml_id)


class Footnote:
    """
    Class representing a footnote
    https://www.xbrl.org/Specification/XBRL-2.1/REC-2003-12-31/XBRL-2.1-REC-2003-12-31+corrected-errata-2013-02-20.html#_4.11

    XML Example:
     <link:footnote id=".." xlink:label=".." xlink:role="http://www.xbrl.org/2003/role/footnote" xlink:type="resource"
     xml:lang="en-US">The domestic loss in 2020 versus domestic income in 2019 was mainly related to the ... </link:footnote>

    """

    def __init__(self, content: str, lang: str) -> None:
        """
        :param content: content of the footnote
        :param lang: language of the footnote
        """
        self.content = content
        self.lang = lang


class XbrlInstance(abc.ABC):
    """
    Class representing a xbrl instance file
    """

    def __init__(
        self,
        url: str,
        taxonomy: TaxonomySchema,
        facts: list[AbstractFact],
        context_map: dict,
        unit_map: dict,
    ) -> None:
        """
        :param taxonomy: taxonomy file that the instance file references (via link:schemaRef)
        :param facts: array of all facts that the instance contains
        """
        self.taxonomy: TaxonomySchema = taxonomy
        self.facts: list[AbstractFact] = facts
        self.instance_url: str = url
        self.context_map: dict = context_map
        self.unit_map: dict = unit_map

    def __str__(self) -> str:
        file_name: str = self.instance_url.split("/")[-1]
        return f"{file_name} with {len(self.facts)} facts"

    def json(
        self, file_path: str | None = None, override_fact_ids: bool = True, **kwargs
    ) -> str | None:
        """
        Converts the instance document into json format
        :param file_path: if a path is given the function will store the json there
        :param override_fact_ids:
        :param kwargs: additional arguments for the json parser
        :return: string (serialized json) or None (if file_path was given)

        https://www.xbrl.org/Specification/xbrl-json/REC-2021-10-13/xbrl-json-REC-2021-10-13.html
        """
        json_dict: dict = {
            "facts": {},
            "documentInfo": {
                "documentType": "https://xbrl.org/2021/xbrl-json",
                "taxonomy": self.taxonomy.get_schema_urls(),
                "baseUrl": self.instance_url,
            },
        }
        for i, fact in enumerate(self.facts):
            fact_id = fact.xml_id if fact.xml_id and not override_fact_ids else f"f{i}"
            json_dict["facts"][fact_id] = fact.json()

        if file_path:
            with open(file_path, "w", encoding="utf8") as f:
                json.dump(json_dict, f, **kwargs)
                return None
        else:
            return json.dumps(json_dict, **kwargs)


def parse_xbrl_url(
    instance_url: str, cache: HttpCache, taxParser: TaxonomyParser | None = None
) -> XbrlInstance:
    """
    Parses a instance file with it's taxonomy. This function will check, if the instance file is already
    in the cache and load it from there based on the instance_url.
    For EDGAR submissions: Before calling this method; extract the enclosure and copy the files to the cache.
    i.e. Use HttpCache.cache_edgar_enclosure()

    :param instance_url: url to the instance file (on the internet)
    :param cache: HttpCache instance
    :return: parsed XbrlInstance object containing all facts with additional information
    """
    instance_path: str = cache.cache_file(instance_url)
    return parse_xbrl(instance_path, cache, taxParser, instance_url)


def parse_xbrl(
    instance_path: str,
    cache: HttpCache,
    taxParser: TaxonomyParser | None = None,
    instance_url: str | None = None,
) -> XbrlInstance:
    """
    Parses a instance file with it's taxonomy

    :param instance_path: url to the instance file (on the internet)
    :param cache: HttpCache instance
    :param instance_url: optional url to the instance file. Is sometimes necessary if the xbrl filings have their own
        extension taxonomy. If i.e. a submission from the sec is parsed, the instance file might reference the taxonomy schema
        with a relative path (since it is in the same directory as the instance file) schemaRef="./aapl-20211231.xsd"
    :param use_local_ns_map: if enabled the parser will use a local namespace map as fallback to try resolving taxonomies
    :param use_edgar_taxonomies: if enabled, the parser will upfront load the EDGAR Common Taxonomies from
        https://www.sec.gov/files/edgartaxonomies.xml and use them as fallback
    :return: parsed XbrlInstance object containing all facts with additional information
    """
    if taxParser is None:
        taxParser = TaxonomyParser(cache)

    root: ET.Element | None = parse_file(instance_path).getroot()
    if root is None:
        raise InstanceParseException("Could not parse instance file!")
    # get the link to the taxonomy schema and parse it
    schema_ref: ET.Element | None = root.find(LINK_NS + "schemaRef")
    if schema_ref is None:
        raise InstanceParseException("Document does not import any taxonomy schema")
    schema_uri: str = schema_ref.attrib[XLINK_NS + "href"]
    # check if the schema uri is relative or absolute
    # submissions from SEC normally have their own schema files, whereas submissions from the uk have absolute schemas

    taxonomy: TaxonomySchema

    if is_url(schema_uri):
        # fetch the taxonomy extension schema from remote
        taxonomy = taxParser.parse_taxonomy(schema_uri)
    elif instance_url:
        # fetch the taxonomy extension schema from remote by reconstructing the url
        schema_url = resolve_uri(instance_url, schema_uri)
        taxonomy = taxParser.parse_taxonomy(schema_url)
    else:
        # try to find the taxonomy extension schema file locally because no full url can be constructed
        schema_path = resolve_uri(instance_path, schema_uri)
        taxonomy = taxParser.parse_taxonomy(schema_path)

    # parse contexts and units
    context_dir = _parse_context_elements(
        root.findall("xbrli:context", NAME_SPACES),
        get_ns_map(root),
        taxonomy,
        taxParser,
    )
    unit_dir = _parse_unit_elements(root.findall("xbrli:unit", NAME_SPACES))

    # parse facts
    facts: list[AbstractFact] = []
    for fact_elem in root:
        # skip contexts and units
        taxonomy_ns, concept_name = fact_elem.tag.split("}")
        if (
            concept_name.lower() == "context"
            or concept_name.lower() == "unit"
            or concept_name.lower() == "schemaref"
        ):
            continue
        # check if the element has the required attributes
        if "contextRef" not in fact_elem.attrib:
            continue

        # check if the fact has a value (some facts are like <us-gaap:Assets ... \>
        if fact_elem.text is None or len(str(fact_elem.text).strip()) == 0:
            continue

        xml_id: str | None = (
            fact_elem.attrib["id"] if "id" in fact_elem.attrib else None
        )

        # find the taxonomy where the tag is coming from
        taxonomy_ns = taxonomy_ns.replace("{", "")
        # get the concept object from the taxonomy
        tax = taxonomy.get_taxonomy(taxonomy_ns)
        if tax is None:
            tax = taxParser.try_taxonomy_from_namespace(taxonomy_ns)
            taxonomy.imports.append(tax)
        try:
            concept: Concept = tax.concepts[tax.name_id_map[concept_name]]
        except KeyError:
            logger.warning(
                f"Instance file uses invalid concept {concept_name}, thus fact {fact_elem.attrib['id']} won't be parsed!"
            )
            continue
        context: AbstractContext = context_dir[fact_elem.attrib["contextRef"].strip()]

        fact: AbstractFact
        if "unitRef" in fact_elem.attrib:
            # the fact is a numerical fact
            # get the unit
            unit: AbstractUnit = unit_dir[fact_elem.attrib["unitRef"].strip()]
            decimals_text: str = str(fact_elem.attrib["decimals"]).strip()
            decimals: int = 0 if decimals_text.lower() == "inf" else int(decimals_text)
            fact = NumericFact(
                concept, context, float(fact_elem.text), unit, decimals, xml_id
            )
        else:
            # the fact is probably a text fact
            fact = TextFact(concept, context, fact_elem.text.strip(), xml_id)
        facts.append(fact)

    return XbrlInstance(
        instance_url if instance_url else instance_path,
        taxonomy,
        facts,
        context_dir,
        unit_dir,
    )


def parse_ixbrl_url(
    instance_url: str,
    cache: HttpCache,
    taxParser: TaxonomyParser | None = None,
    encoding: str | None = None,
) -> XbrlInstance:
    """
    Parses a inline XBRL (iXBRL) instance file.

    :param cache: HttpCache instance
    :param instance_url: url to the instance file(on the internet)
    :param encoding: specifies the encoding of the file
    :return: parsed XbrlInstance object containing all facts with additional information
    """
    instance_path: str = cache.cache_file(instance_url)
    return parse_ixbrl(instance_path, cache, taxParser, instance_url, encoding)


def parse_ixbrl(
    instance_path: str,
    cache: HttpCache,
    taxParser: TaxonomyParser | None = None,
    instance_url: str | None = None,
    encoding=None,
    schema_root=None,
) -> XbrlInstance:
    """
    Parses a inline XBRL (iXBRL) instance file.

    :param instance_path: path to the submission you want to parse
    :param cache: HttpCache instance
    :param instance_url: url to the instance file(on the internet)
    :param encoding: optionally specify a file encoding
    :param schema_root: path to the directory where the taxonomy schema is stored (Only works for relative imports)
    :return: parsed XbrlInstance object containing all facts with additional information
    """
    """
    In contrary to the XBRL-parse method we use here the actual root instead of the root element!!!
    to the .getRoot() is missing. This has the benefit, that we can search the document with absolute xpath expressions
    => in the XBRL-parse function root is ET.Element, here just an instance of ElementTree class!
    """
    if taxParser is None:
        taxParser = TaxonomyParser(cache)
    instance_file = open(instance_path, "r", encoding=encoding)
    contents = instance_file.read()
    pattern = r"<[ ]*script.*?\/[ ]*script[ ]*>"
    contents = re.sub(
        pattern, "", contents, flags=(re.IGNORECASE | re.MULTILINE | re.DOTALL)
    )

    root: ET.ElementTree = parse_file(StringIO(contents))
    root_elem = root.getroot()
    if root_elem is None:
        raise InstanceParseException("Could not parse instance file!")
    ns_map: dict = get_ns_map(root_elem)
    # get the link to the taxonomy schema and parse it
    schema_ref: ET.Element | None = root.find(f".//{LINK_NS}schemaRef")
    if schema_ref is None:
        raise InstanceParseException("Document does not import any taxonomy schema")
    schema_uri: str = schema_ref.attrib[XLINK_NS + "href"]
    # check if the schema uri is relative or absolute
    # submissions from SEC normally have their own schema files, whereas submissions from the uk have absolute schemas

    taxonomy: TaxonomySchema
    if is_url(schema_uri):
        # fetch the taxonomy extension schema from remote
        taxonomy = taxParser.parse_taxonomy(schema_uri)
    elif schema_root:
        # take the given schema_root path as directory for searching for the taxonomy schema
        schema_path = str(next(Path(schema_root).glob(f"**/{schema_uri}")))
        taxonomy = taxParser.parse_taxonomy(schema_path)
    elif instance_url:
        # fetch the taxonomy extension schema from remote by reconstructing the url
        schema_url = resolve_uri(instance_url, schema_uri)
        taxonomy = taxParser.parse_taxonomy(schema_url)
    else:
        # try to find the taxonomy extension schema file locally because no full url can be constructed
        schema_path = resolve_uri(instance_path, schema_uri)
        taxonomy = taxParser.parse_taxonomy(schema_path)

    # get all contexts and units
    xbrl_resources: ET.Element | None = root.find(".//ix:resources", ns_map)
    if xbrl_resources is None:
        raise InstanceParseException("Could not find xbrl resources in file")
    # parse contexts and units
    context_dir = _parse_context_elements(
        xbrl_resources.findall("xbrli:context", NAME_SPACES),
        ns_map,
        taxonomy,
        taxParser,
    )
    unit_dir = _parse_unit_elements(xbrl_resources.findall("xbrli:unit", NAME_SPACES))

    # parse facts
    facts: list[AbstractFact] = []
    fact_elements: list[ET.Element] = root.findall(
        ".//ix:nonFraction", ns_map
    ) + root.findall(".//ix:nonNumeric", ns_map)
    for fact_elem in fact_elements:
        # update the prefix map (sometimes the xmlns is defined at XML-Element level and not at the root element)
        _update_ns_map(ns_map, get_ns_map(fact_elem))
        taxonomy_prefix, concept_name = fact_elem.attrib["name"].split(":")

        tax = taxonomy.get_taxonomy(ns_map[taxonomy_prefix])
        if tax is None:
            tax = taxParser.try_taxonomy_from_namespace(ns_map[taxonomy_prefix])
            taxonomy.imports.append(tax)

        xml_id: str | None = (
            fact_elem.attrib["id"] if "id" in fact_elem.attrib else None
        )

        concept: Concept = tax.concepts[tax.name_id_map[concept_name]]
        context: AbstractContext = context_dir[fact_elem.attrib["contextRef"].strip()]
        # ixbrl values are not normalized! They are formatted (i.e. 123,000,000)
        fact_value: float | str | None
        if fact_elem.tag == "{" + ns_map["ix"] + "}nonFraction":
            fact_value = _extract_non_fraction_value(fact_elem)

            unit: AbstractUnit = unit_dir[fact_elem.attrib["unitRef"].strip()]
            decimals_text: str = (
                str(fact_elem.attrib["decimals"]).strip()
                if "decimals" in fact_elem.attrib
                else "0"
            )
            decimals: int = 0 if decimals_text.lower() == "inf" else int(decimals_text)
            if fact_value is not None:
                facts.append(
                    NumericFact(
                        concept, context, float(fact_value), unit, decimals, xml_id
                    )
                )
        elif fact_elem.tag == "{" + ns_map["ix"] + "}nonNumeric":
            fact_value = _extract_non_numeric_value(fact_elem)
            facts.append(TextFact(concept, context, str(fact_value), xml_id))

    return XbrlInstance(
        instance_url if instance_url else instance_path,
        taxonomy,
        facts,
        context_dir,
        unit_dir,
    )


def _extract_non_numeric_value(fact_elem: ET.Element) -> str:
    """
    This function parses a ix:nonNumeric fact as defined in:
    https://www.xbrl.org/Specification/inlineXBRL-part1/PWD-2013-02-13/inlineXBRL-part1-PWD-2013-02-13.html#d1e6391
    :param fact_elem:
    :return:
    """
    fact_value = "" if fact_elem.text is None else fact_elem.text

    # recursively iterate over all children (<ix:nonNumeric><b>data</b></ix:nonNumeric>)
    for children in fact_elem:
        fact_value += _extract_text_value(children)

    fact_format = fact_elem.attrib["format"] if "format" in fact_elem.attrib else None
    if fact_format:
        # extract transformation registry namespace and transformation rule code
        registryPrefix, formatCode = fact_format.split(":")
        registryNS: str = get_ns_map(fact_elem)[registryPrefix]
        try:
            fact_value = normalize(registryNS, formatCode, fact_value)
        except TransformationNotImplemented:
            logging.info(
                f"Transformation rule {formatCode} of registry {registryPrefix} is not supported. "
                f"The parser will just parse the value as it is and not transform it according to the rule."
            )
            return fact_value
        except TransformationException:
            logging.warning(
                f'Could not transform value "{fact_value}" with format {fact_format}'
            )
            return fact_value
    return fact_value


def _extract_non_fraction_value(fact_elem: ET.Element) -> float | str | None:
    """
    https://www.xbrl.org/Specification/inlineXBRL-part1/PWD-2013-02-13/inlineXBRL-part1-PWD-2013-02-13.html#d1e5045
    :param fact_elem:
    :return:
    """
    # First look if the fact is nilled (look for xsi:nil="true" or xs:nil="true")
    elem_ns_map = get_ns_map(fact_elem)
    for prefix in ("xsi", "xs"):
        if prefix in elem_ns_map:
            nil_attrib = f"{{{elem_ns_map[prefix]}}}nil"
            if fact_elem.attrib.get(nil_attrib) == "true":
                return None
    # Also, if the fact just has no value, we also return null (instead of just failing)
    if fact_elem.text is None or len(fact_elem.text.strip()) == 0:
        return None

    fact_value = "" if fact_elem.text is None else fact_elem.text
    # recursively iterate over all children (<ix:nonNumeric><b>data</b></ix:nonNumeric>)
    for children in fact_elem:
        fact_value += _extract_text_value(children)

    fact_format = fact_elem.attrib["format"] if "format" in fact_elem.attrib else None
    value_scale: int = (
        int(fact_elem.attrib["scale"]) if "scale" in fact_elem.attrib else 0
    )
    value_sign: str | None = (
        fact_elem.attrib["sign"] if "sign" in fact_elem.attrib else None
    )

    if fact_format:
        # extract transformation registry namespace and transformation rule code
        registryPrefix, formatCode = fact_format.split(":")
        registryNS: str = get_ns_map(fact_elem)[registryPrefix]
        try:
            fact_value = normalize(registryNS, formatCode, fact_value)
        except TransformationNotImplemented:
            logging.info(
                f"Transformation rule {formatCode} of registry {registryPrefix} is not supported. "
                f"The parser will just parse the value as it is and not transform it according to the rule."
            )
            return fact_value
        except TransformationException:
            logging.warning(
                f'Could not transform value "{fact_value}" with format {fact_format}'
            )
            return fact_value

    scaled_value: float = float(fact_value) * pow(10, value_scale)
    # Floating-point error mitigation
    if abs(scaled_value) > 1e6:
        scaled_value = float(round(scaled_value))
    if value_sign == "-":
        scaled_value = -scaled_value

    return scaled_value


def _extract_text_value(element: ET.Element) -> str:
    text = "" if element.text is None else element.text
    if element.tail:
        text += element.tail
    for children in element:
        text += _extract_text_value(children)
    return text


def _parse_context_elements(
    context_elements: list[ET.Element],
    ns_map: dict,
    taxonomy: TaxonomySchema,
    taxParser: TaxonomyParser,
) -> dict:
    """
    Parses all context elements from the instance file and stores them into a dictionary with the
    context id as key
    :param context_elements: array of context elements from the xml of html
    :param ns_map: the prefix - namespace map of the document
    :param taxonomy: The taxonomy of the instance file (needed for parsing dimensional information)
    :return:
    """
    context_dict = {}
    for context_elem in context_elements:
        context_id: str = context_elem.attrib["id"]
        entity_elem = context_elem.find("xbrli:entity/xbrli:identifier", NAME_SPACES)
        entity: str = str(entity_elem.text).strip() if entity_elem is not None else ""

        instant_date: ET.Element | None = context_elem.find(
            "xbrli:period/xbrli:instant", NAME_SPACES
        )
        start_date: ET.Element | None = context_elem.find(
            "xbrli:period/xbrli:startDate", NAME_SPACES
        )
        end_date: ET.Element | None = context_elem.find(
            "xbrli:period/xbrli:endDate", NAME_SPACES
        )
        forever: ET.Element | None = context_elem.find(
            "xbrli:period/xbrli:forever", NAME_SPACES
        )

        context: AbstractContext
        if instant_date is not None and instant_date.text is not None:
            # the context is a instant context
            context = InstantContext(
                context_id,
                entity,
                datetime.strptime(instant_date.text.strip()[:10], "%Y-%m-%d").date(),
            )
        elif forever is not None:
            context = ForeverContext(context_id, entity)
        elif (
            start_date is not None
            and end_date is not None
            and start_date.text is not None
            and end_date.text is not None
        ):
            # the context is a time frame context
            context = TimeFrameContext(
                context_id,
                entity,
                datetime.strptime(start_date.text.strip()[:10], "%Y-%m-%d").date(),
                datetime.strptime(end_date.text.strip()[:10], "%Y-%m-%d").date(),
            )
        else:
            logger.warning(
                f"Context {context_id} has an unknown period type and will be skipped! This can lead to crashes when parsing facts!"
            )

        # check if dimensional information exists on this context and parse it
        segment: ET.Element | None = context_elem.find(
            "xbrli:entity/xbrli:segment", NAME_SPACES
        )
        if segment is not None:
            dimension_concept: Concept
            for explicit_member_elem in segment.findall(
                "xbrldi:explicitMember", NAME_SPACES
            ):
                if explicit_member_elem.text is None:
                    continue
                _update_ns_map(ns_map, get_ns_map(explicit_member_elem))
                dimension_prefix, dimension_concept_name = (
                    explicit_member_elem.attrib["dimension"].strip().split(":")
                )
                member_prefix, member_concept_name = (
                    explicit_member_elem.text.strip().split(":")
                )
                # get the taxonomy where the dimension attribute is defined
                dimension_tax = taxonomy.get_taxonomy(ns_map[dimension_prefix])
                # check if the taxonomy was found
                if dimension_tax is None:
                    # try to subsequently load the taxonomy
                    dimension_tax = taxParser.try_taxonomy_from_namespace(
                        ns_map[dimension_prefix]
                    )
                    taxonomy.imports.append(dimension_tax)

                # get the taxonomy where the member attribute is defined
                member_tax = (
                    dimension_tax
                    if member_prefix == dimension_prefix
                    else taxonomy.get_taxonomy(ns_map[member_prefix])
                )
                # check if the taxonomy was found
                if member_tax is None:
                    # try to subsequently load the taxonomy
                    member_tax = taxParser.try_taxonomy_from_namespace(
                        ns_map[member_prefix]
                    )
                    taxonomy.imports.append(member_tax)
                dimension_concept = dimension_tax.concepts[
                    dimension_tax.name_id_map[dimension_concept_name]
                ]
                member_concept: Concept = member_tax.concepts[
                    member_tax.name_id_map[member_concept_name]
                ]

                # add the explicit member to the context
                context.segments.append(
                    ExplicitMember(dimension_concept, member_concept)
                )

            for typed_member_element in segment.findall(
                "xbrldi:typedMember", NAME_SPACES
            ):
                _update_ns_map(ns_map, get_ns_map(typed_member_element))
                dimension_prefix, dimension_concept_name = (
                    typed_member_element.attrib["dimension"].strip().split(":")
                )
                # get the taxonomy where the dimension attribute is defined
                dimension_tax = taxonomy.get_taxonomy(ns_map[dimension_prefix])
                # check if the taxonomy was found
                if dimension_tax is None:
                    # try to subsequently load the taxonomy
                    dimension_tax = taxParser.try_taxonomy_from_namespace(
                        ns_map[dimension_prefix]
                    )
                    taxonomy.imports.append(dimension_tax)
                dimension_concept = dimension_tax.concepts[
                    dimension_tax.name_id_map[dimension_concept_name]
                ]
                domain: list[str] = []
                for child in typed_member_element:
                    if child.text is not None:
                        domain.append(child.text.strip())

                context.segments.append(TypedMember(dimension_concept, domain))

        context_dict[context_id] = context
    return context_dict


def _update_ns_map(ns_map: dict, new_ns_map: dict) -> None:
    """
    Compares the new_ns_map with the ns_map and adds prefix/namespace mappings that are not present in ns_map
    :param ns_map:
    :param new_ns_map:
    :return:
    """
    for prefix in new_ns_map:
        if prefix not in ns_map:
            ns_map[prefix] = new_ns_map[prefix]


def _parse_unit_elements(unit_elements: list[ET.Element]) -> dict:
    """
    Parses all unit elements from the instance file and stores them into a dictionary with the
    unit id as key
    :param unit_elements:
    :return:
    """
    unit_dict: dict[str, AbstractUnit] = {}
    for unit_elem in unit_elements:
        unit_id: str = unit_elem.attrib["id"]

        simple_unit: ET.Element | None = unit_elem.find("xbrli:measure", NAME_SPACES)
        divide: ET.Element | None = unit_elem.find("xbrli:divide", NAME_SPACES)

        if simple_unit is not None:
            unit_dict[unit_id] = SimpleUnit(unit_id, (simple_unit.text or "").strip())
        elif divide is not None:
            numerator = divide.find("xbrli:unitNumerator/xbrli:measure", NAME_SPACES)
            denominator = divide.find(
                "xbrli:unitDenominator/xbrli:measure", NAME_SPACES
            )
            if numerator is not None and denominator is not None:
                unit_dict[unit_id] = DivideUnit(
                    unit_id,
                    (numerator.text or "").strip(),
                    (denominator.text or "").strip(),
                )
    return unit_dict


class XbrlParser:
    """
    XbrlParser to make interaction easier.
    """

    def __init__(
        self, cache: HttpCache, taxParser: TaxonomyParser | None = None
    ) -> None:
        self.cache = cache
        self.taxParser = taxParser if taxParser is not None else TaxonomyParser(cache)

    def parse_instance(
        self,
        uri: str,
        instance_url: str | None = None,
        encoding: str | None = None,
    ) -> XbrlInstance:
        """
        Parses a xbrl instance (either xbrl or ixbrl)

        .. warning::

            If the instance document or extension taxonomy have relative imports the parser will also search for those
            files locally!

        :param uri: url to the instance file.
            i.e: https://www.sec.gov/Archives/edgar/data/320193/000032019320000096/aapl-20200926.
        :param instance_url: this parameter overrides the above described behaviour. If you also provide the url where the
            instance document was downloaded, the parser can fetch relative imports using this base url
        :param encoding: specifies the encoding of the file
        :return:
        """
        if uri.split(".")[-1] == "xml" or uri.split(".")[-1] == "xbrl":
            return (
                parse_xbrl_url(uri, self.cache, self.taxParser)
                if is_url(uri)
                else parse_xbrl(uri, self.cache, self.taxParser, instance_url)
            )
        return (
            parse_ixbrl_url(uri, self.cache, self.taxParser)
            if is_url(uri)
            else parse_ixbrl(uri, self.cache, self.taxParser, instance_url, encoding)
        )

    def __str__(self) -> str:
        return f"XbrlParser with cache dir at {self.cache.cache_dir}"
