"""
LLM provider module containing implementations for various language model providers.

This module provides a unified interface for different LLM providers including OpenAI,
Anthropic, and mock providers for testing purposes.
"""

from enum import Enum

from pyagentic.llm._openai import OpenAIProvider
from pyagentic.llm._openaiv1 import OpenAIV1Provider
from pyagentic.llm._anthropic import AnthropicProvider
from pyagentic.llm._gemini import GeminiProvider
from pyagentic.llm._mock import _MockProvider


__all__ = ["OpenAIProvider", "AnthropicProvider", "GeminiProvider"]


class LLMProviders(Enum):
    """
    Enumeration of available LLM provider implementations.

    Provides easy access to different language model providers that can be used
    with agents for text generation and tool calling.
    """

    OPENAI = OpenAIProvider
    OPENAIV1 = OpenAIV1Provider
    ANTHROPIC = AnthropicProvider
    GEMINI = GeminiProvider
    _MOCK = _MockProvider
