# Code of Conduct

This project follows the Contributor Covenant Code of Conduct.

## Our Pledge

We as members, contributors, and maintainers pledge to make participation in our community a harassment-free
experience for everyone, regardless of age, body size, visible or invisible disability, ethnicity, sex
characteristics, gender identity and expression, level of experience, education, socio-economic status,
nationality, personal appearance, race, religion, or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive, and healthy
community.

## Our Standards

Examples of behavior that contributes to a positive environment for our community include:

- Demonstrating empathy and kindness toward other people
- Being respectful of differing opinions, viewpoints, and experiences
- Giving and gracefully accepting constructive feedback
- Accepting responsibility and apologizing to those affected by our mistakes
- Focusing on what is best not just for us as individuals, but for the overall community

Examples of unacceptable behavior include:

- The use of sexualized language or imagery, and sexual attention or advances
- Trolling, insulting or derogatory comments, and personal or political attacks
- Public or private harassment
- Publishing others' private information, such as a physical or email address, without their explicit permission
- Other conduct which could reasonably be considered inappropriate in a professional setting

## Enforcement Responsibilities

Project maintainers are responsible for clarifying and enforcing standards of acceptable behavior and will take
appropriate and fair corrective action in response to any behavior they deem inappropriate, threatening,
offensive, or harmful.

## Scope

This Code of Conduct applies within all project spaces and also applies when an individual is officially
representing the project in public spaces.

## Enforcement

To report unacceptable behavior, contact the repository owner via their GitHub profile. If you feel unsafe
reporting publicly, do not open a public issue.

## Attribution

This Code of Conduct is adapted from the Contributor Covenant, version 2.1:
https://www.contributor-covenant.org/version/2/1/code_of_conduct.html

