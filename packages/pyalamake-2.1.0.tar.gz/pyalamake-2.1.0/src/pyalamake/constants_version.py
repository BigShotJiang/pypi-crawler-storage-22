from dataclasses import dataclass


# --------------------
## holds constants
@dataclass
class ConstantsVersion:
    ## current App version
    version = '2.1.0'
