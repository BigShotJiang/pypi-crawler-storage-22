from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
SRC_DIR = BASE_DIR / "src"
PYCAMI_DIR = SRC_DIR / "pyami"
TESTS_DIR = BASE_DIR / "tests"
