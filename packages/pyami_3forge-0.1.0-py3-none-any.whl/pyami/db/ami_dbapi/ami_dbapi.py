"""
3forge AMI DB-API 2.0 compatible module.
This module implements a tiny engine that supports basic queries.

Usage:
    from pyami.db import ami_dbapi as db
    conn = db.connect("localhost", 3280, "demo", "demo123")
    cur = conn.cursor()
    cur.execute("SELECT id, name FROM users WHERE id = %(uid)s", {"uid": 1})
    rows = cur.fetchall()

"""


from typing import Any, Dict, Iterable, Optional, Sequence, Mapping, Final
import re
import time

from pyami.db import pycami

# Module level DB-API attributes
apilevel = "2.0"
threadsafety = 1  # Threads may share the module, but not connections
paramstyle = "named"  # use DB-API 'named' format, e.g. ...WHERE name=:name

# Exceptions required by DB-API
class Error(Exception):
    pass

class Warning(Exception):
    pass

class InterfaceError(Error):
    pass

class DatabaseError(Error):
    pass

class OperationError(DatabaseError):
    pass

class IntegrityError(DatabaseError):
    pass

class InternalError(DatabaseError):
    pass

class ProgrammingError(DatabaseError):
    pass

class NotSupportedError(DatabaseError):
    pass

# Public connect factory
def connect(
        host="localhost",
        port=3280,
        username="demo",
        password="demo123",
        timeout_ms=60000,
        limit=10000) -> 'Connection':
    return Connection(host, port, username, password, timeout_ms, limit)


# --- Simple in-memory engine ---

class Connection:
    def __init__(self, host="localhost", port=3280, username="demo", password="demo123", timeout_ms=60000, limit=10000):
        # shallow-copy table data so tests can mutate original without breaking
        self._ami_conn = pycami.AmiConnection(host, port, username, password, timeout_ms, limit)
        self._closed = False

    def close(self):
        if not self._closed:
            self._ami_conn.disconnect()
            self._closed = True

    def cursor(self):
        self._ensure_open()
        return Cursor(self._ami_conn)

    def commit(self):
        self._ensure_open()
        # no-op

    def rollback(self):
        self._ensure_open()
        # no-op

    def _ensure_open(self):
        if self._closed:
            raise InterfaceError("connection is closed")


class Cursor:
    def __init__(self, ami_conn: pycami.AmiConnection):
        self._ami_conn = ami_conn
        self._closed = False
        self._result_pos = 0
        self._current_operation = None
        self._parsed = None
        self.description = None  # per PEP 249: sequence of 7-item sequences
        self.rowcount = -1
        self.arraysize = 1  # default fetchmany size
        self.lastrowid = -1

    def close(self):
        self._closed = True

    def _reset(self):
        self._result_pos = 0
        self.description = None
        self.rowcount = -1

    def callproc(self, procname: str, parameters: Optional[Sequence[Any]] = None):
        self._ensure_open()
        query_str = f"CALL {procname}"
        if parameters:
            query_str += '('
            for p in parameters:
                if isinstance(p, str):
                    query_str += '"' + p + '", '
                else:
                    query_str += str(p) + ', '
            query_str = query_str[:-2]  # remove last comma
            query_str += ')'
        self._reset()
        self._get_result(query_str)
        return parameters

    def _get_result(self, sql_stmt: str):
        self._ami_conn.execute(sql_stmt)
        if self._ami_conn.has_last_error():
            raise DatabaseError(self._ami_conn.get_last_error_message())
        self.rowcount = self._ami_conn.get_last_row_count()
        column_desc = self._ami_conn.get_last_result_column_descriptions()
        self.description = [(_type_code_from_ami(item[0]), item[1], None, None, None, None, item[2]) for item in column_desc]

    def execute(self, operation: str, parameters: Optional[Any] = None):
        self._ensure_open()
        self._reset()
        if self._current_operation is None or self._current_operation != operation:
            self._current_operation = operation
            self._parsed = _parse(operation)
        if self._parsed is None:
            raise DatabaseError("failed to parse SQL operation")
        sql_stmt = _to_sql_stmt(self._current_operation, self._parsed, parameters)
        self._get_result(sql_stmt)
        return self

    def executemany(self, operation: str, seq_of_parameters: Iterable[Any]):
        self._ensure_open()
        self._reset()
        self._current_operation = operation
        self._parsed = _parse(operation)
        if self._parsed is None:
            raise DatabaseError("failed to parse SQL operation")
        sql_stmt = _to_sql_stmt_many(self._current_operation, self._parsed, seq_of_parameters)
        self._get_result(sql_stmt)
        return self

    def fetchone(self):
        self._ensure_open()
        if self._result_pos >= self.rowcount:
            return None
        row = self._ami_conn.get_rows(self._result_pos, self._result_pos + 1)
        self._result_pos += 1
        return row

    def fetchmany(self, size: Optional[int] = None):
        self._ensure_open()
        if size is None:
            size = self.arraysize
        start = self._result_pos
        end = min(start + size, self.rowcount)
        if start >= end:
            return []
        rows = self._ami_conn.get_rows(start, end)
        self._result_pos = end
        return rows

    def fetchall(self):
        self._ensure_open()
        return self._ami_conn.get_rows(self._result_pos, self.rowcount)

    def setinputsizes(self, sizes):
        # no-op
        pass

    def setoutputsize(self, size, column=None):
        # no-op
        pass

    def _ensure_open(self):
        if self._closed:
            raise InterfaceError("cursor is closed")

# --- Simple SQL parsing helpers ---

#_SELECT_RE = re.compile(r"^\s*SELECT\s+(?P<cols>.+?)\s+FROM\s+(?P<table>\w+)(?:\s+WHERE\s+(?P<where>.+))?$", re.I)
#_WHERE_CLAUSE_RE = re.compile(r"(?P<col>\w+)\s*=\s*(?P<ph>%(?P<name>\(\w+\)s)|\?|%s)", re.I)
_NAMED_PARAM_RE = re.compile(r":(?P<key>\w+)")

# split operation into pre-VALUES and VALUES parts
_MULTI_PARAM_SPLIT_STMT_RE = re.compile(r"(?i)^\s*(.+)\s*\bvalues\s*([^)]*\))")

_MULTI_PARAM_UPDATE_RE = re.compile(r"(?i)^\s*(update\s+\w+\s+set\s+)(.+?)(\s+where\s+.+)?$")

# construct a SQL statement from operation, parsed info, and parameters
# substitute parameters into pyformat placeholders
def _to_sql_stmt(operation: str, parsed: Dict[str, Any], parameters: Optional[Any]) -> str:
    sql = operation
    if not parsed:
        return sql
    # resolve parameters
    params_seq, params_map = _normalize_params(parameters)
    # If only a positional sequence is provided, map it to parameter names in appearance order
    param_names = list(parsed.keys())
    if params_map is None and params_seq is not None:
        if len(params_seq) != len(param_names):
            raise DatabaseError("number of parameters does not match")
        params_map = dict(zip(param_names, params_seq))
    # require a mapping for named-style substitution
    if params_map is None:
        raise DatabaseError("named parameters required but mapping or sequence not provided")
    # substitute parameters into named placeholders
    def _substitute_param(m):
        pname = m.group("key")
        # missing names become NULL
        val = params_map.get(pname)
        if val is None:
            return "NULL"
        if isinstance(val, str):
            return '"' + val + '"'
        return str(val)
    sql_filled = _NAMED_PARAM_RE.sub(_substitute_param, sql)
    return sql_filled

def _to_sql_stmt_update_many(operation: str, parsed: Dict[str, Any], seq_of_parameters: Iterable[Any]) -> str:
    sql = operation
    if not parsed or not seq_of_parameters:
        return sql

    # split into pre-SET and SET parts
    pre_set, set_part = "", ""
    m = _MULTI_PARAM_UPDATE_RE.match(sql)
    if m:
        pre_set = m.group(1)
        set_part = m.group(2)
        where_part = m.group(3) if m.group(3) else ""
    else:
        raise DatabaseError("executemany UPDATE requires SET clause for multiple parameter sets")

    result_sql = ""
    for param_values in seq_of_parameters:
        # if each element is a mapping, use it directly
        if isinstance(param_values, dict):
            params_map = param_values
        else:
            # positional sequence: map by param_names order
            param_names = list(parsed.keys())
            if isinstance(param_values, (list, tuple)):
                if len(param_values) != len(param_names):
                    raise DatabaseError("number of parameters does not match")
                params_map = dict(zip(param_names, param_values))
            else:
                # single scalar for single-param statements
                if len(param_names) != 1:
                    raise DatabaseError("number of parameters does not match")
                params_map = {param_names[0]: param_values}
        # substitute using the params_map
        def _substitute_param(m):
            pname = m.group("key")
            val = params_map.get(pname)
            if val is None:
                return "NULL"
            if isinstance(val, str):
                return '"' + val + '"'
            return str(val)
        set_filled = _NAMED_PARAM_RE.sub(_substitute_param, set_part)
        where_filled = _NAMED_PARAM_RE.sub(_substitute_param, where_part)
        result_sql += pre_set + set_filled + where_filled + "; "
    result_sql = result_sql[:-2]  # remove last semicolon
    return result_sql

def _to_sql_stmt_many(operation: str, parsed: Dict[str, Any], seq_of_parameters: Iterable[Any]) -> str:
    # if this is 'UPDATE' call another method
    update_str = "update"
    if update_str.casefold() in operation.casefold():
        return _to_sql_stmt_update_many(operation, parsed, seq_of_parameters)

    sql = operation
    if not parsed or not seq_of_parameters:
        return sql

    # split into pre-VALUES and VALUES parts
    pre_value, values_part = "", ""
    m = _MULTI_PARAM_SPLIT_STMT_RE.match(sql)
    if m:
        pre_value = m.group(1)
        values_part = m.group(2)
    else:
        raise DatabaseError("executemany requires VALUES clause for multiple parameter sets")

    result_sql = pre_value + " VALUES "
    for param_values in seq_of_parameters:
        # if each element is a mapping, use it directly
        if isinstance(param_values, dict):
            params_map = param_values
        else:
            # positional sequence: map by param_names order
            param_names = list(parsed.keys())
            if isinstance(param_values, (list, tuple)):
                if len(param_values) != len(param_names):
                    raise DatabaseError("number of parameters does not match")
                params_map = dict(zip(param_names, param_values))
            else:
                # single scalar for single-param statements
                if len(param_names) != 1:
                    raise DatabaseError("number of parameters does not match")
                params_map = {param_names[0]: param_values}
        # substitute using the params_map
        def _substitute_param(m):
            pname = m.group("key")
            val = params_map.get(pname)
            if val is None:
                return "NULL"
            if isinstance(val, str):
                return '"' + val + '"'
            return str(val)
        values_filled = _NAMED_PARAM_RE.sub(_substitute_param, values_part)
        result_sql += values_filled + ", "
    result_sql = result_sql[:-2]  # remove last comma
    return result_sql

# return dict with keys: param_name, value = None to be filled in later
def _parse(sql: str):
    # get all parameter names in pyformat style
    param_names = {}
    for m in _NAMED_PARAM_RE.finditer(sql):
        param_names[m.group("key")] = None
    return param_names


def _normalize_params(parameters: Optional[Any]):
    """Return (seq, map) where one may be None depending on parameters.

    For mapping, seq is None and map is the dict. For sequence, seq is list and map None.
    None parameters => both None.
    """
    if parameters is None:
        return None, None
    if isinstance(parameters, dict):
        return None, parameters
    if isinstance(parameters, (list, tuple)):
        return list(parameters), None
    # single scalar
    return [parameters], None

class Date:
    def __init__(self, year: int, month: int, day: int):
        self.year = year
        self.month = month
        self.day = day

class Time:
    def __init__(self, hour: int, minute: int, second: int):
        self.hour = hour
        self.minute = minute
        self.second = second

class Timestamp:
    def __init__(self, year: int, month: int, day: int, hour: int, minute: int, second: int):
        self.year = year
        self.month = month
        self.day = day
        self.hour = hour
        self.minute = minute
        self.second = second

def DateFromTicks(ticks):
    return Date(*time.localtime(ticks)[:3])

def TimeFromTicks(ticks):
    return Time(*time.localtime(ticks)[3:6])

def TimestampFromTicks(ticks):
    return Timestamp(*time.localtime(ticks)[:6])

class DATETIME:
    def __init__(self, year: int, month: int, day: int, hour: int, minute: int, second: int):
        self.year = year
        self.month = month
        self.day = day
        self.hour = hour
        self.minute = minute
        self.second = second

class Binary:
    def __init__(self, data: bytes):
        self.data = data

class STRING:
    def __init__(self, s: str):
        self.s = s

class BINARY:
    def __init__(self, data: bytes):
        self.data = data

class NUMBER:
    def __init__(self, n: int):
        self.n = n

class ROWID:
    def __init__(self, row: int):
        self.row = row

class AmiTypesMap:
    AMI_TO_TYPE_CODE: Final[Mapping[int, object]] = {
        0: NUMBER, # PrimitiveBoolean
        1: NUMBER, # PrimitiveByte
        2: NUMBER, # PrimitiveShort
        3: STRING, # PrimitiveChar
        4: NUMBER, # PrimitiveInt
        5: NUMBER, # PrimitiveFloat
        6: NUMBER, # Primitive Long
        7: NUMBER, # PrimitiveDouble
        8: Binary, # PrimitiveObject
        9: Binary, # PrimitiveVoid
        10: NUMBER, # Boolean
        11: NUMBER, # Byte
        12: NUMBER, # Short
        13: STRING, # Character
        14: NUMBER, # Integer
        15: NUMBER, # Float
        16: NUMBER, # Long
        17: NUMBER, # Double
        18: Binary, # Object
        19: Binary, # Void
        20: STRING, # String
        21: Binary, # List
        22: Binary, # Set
        23: Binary, # Map
        24: STRING, # Password
        30: Date, # Date
        31: Date, # Day
        32: Date, # DateTime
        33: STRING, # TimeZone
        34: NUMBER, # DateNanos
        35: NUMBER, # DateMillis
        36: BINARY, # Bytes
        37: Binary, # Complex
        38: Binary, # UUID
        39: Binary, # TableColumnar
        40: Binary, # Ideable
        41: Binary, # Message
        42: Binary, # MapMessage
        43: Binary, # Table
        44: Binary, # FixPoint
        45: Binary, # BigDecimal
        46: Binary, # BigInteger
        47: Binary, # ValuedEnum
        48: Binary, # PersistableMap
        49: Binary, # PersistableList
        50: Binary, # PersistableSet
        51: Binary, # Class
        52: Binary, # Null
        53: Binary, # Throwable
        54: Binary, # Enum
        55: Binary, # Tuple
        56: Binary, # Array
        57: Binary, # StringArray
        58: Binary, # ByteArrayArray
        59: Binary, # StringBuilder
        60: Binary, # Undefined
        61: Binary, # Custom
        62: Binary, # ColorGradient
        63: Date, # DatePart
        70: Binary, # LongKeyMap
        101: Binary, # PrimitiveByteArray
        104: Binary, # PrimitiveIntArray
        106: Binary, # PrimitiveLongArray
        107: STRING, # PrimitiveCharArray
        108: Binary, # PrimitiveDoubleArray
        109: Binary, # PrimitiveFloatArray
    }

def _type_code_from_ami(ami_type_code: int):
    return AmiTypesMap.AMI_TO_TYPE_CODE[ami_type_code]
