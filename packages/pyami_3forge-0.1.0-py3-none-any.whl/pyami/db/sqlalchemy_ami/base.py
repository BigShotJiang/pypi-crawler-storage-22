from sqlalchemy import Connection, PrimaryKeyConstraint, event, Index, Table, types, pool
from sqlalchemy.engine.default import DefaultDialect
from sqlalchemy.engine.interfaces import ReflectedForeignKeyConstraint
from sqlalchemy.sql import compiler, operators, selectable
from sqlalchemy.sql import sqltypes
from sqlalchemy.engine.url import make_url
from sqlalchemy.types import TypeEngine

import pyami.db.ami_dbapi
from typing import Any, Dict, Tuple, Optional, List, Callable


def _create_pk_index_for_table(table: Table, connection, pk_cols, **kw) -> None:
    index_name = f"idx_{table.name}_pk"
    info = {}
    if getattr(*pk_cols, "info"):
        info = pk_cols[0].info
    info["use_constraint"] = "PRIMARY"
    idx = Index(index_name, *pk_cols, info=info)
    idx.create(bind=connection, checkfirst=True)


def _create_fk_index_for_table(table: Table, connection, fk_cols, **kw) -> None:
    index_name = f"idx_{table.name}_fk"
    idx = Index(index_name, *fk_cols, info={"use_constraint": "NONE"})
    idx.create(bind=connection, checkfirst=True)


def _trigger_index_for_pk_fk_table(table: Table, connection, **kw) -> None:
    """
    Event listener for Table.after_create.
    When a table is created, check its primary key and create a unique index
    on the primary key columns.
    The similar for foreign keys
    """
    try:
        pk_cols = [c for c in table.primary_key.columns]
        if pk_cols:
            _create_pk_index_for_table(table, connection, pk_cols, **kw)

        fk_constrs = [fk for fk in table.foreign_key_constraints]
        if fk_constrs:
            fk_cols = None
            for fk in fk_constrs:
                fk_cols = [c for c in fk.columns]
            if fk_cols:
                _create_fk_index_for_table(table, connection, fk_cols, **kw)

    except Exception:
        pass
    return


@event.listens_for(Table, "after_create")
def on_table_after_create(table: Table, connection, **kw) -> None:
    if event.contains(Table, "after_create", _trigger_index_for_pk_fk_table):
        return
    _trigger_index_for_pk_fk_table(table, connection, **kw)

#event.listen(Table, "after_create", _trigger_index_for_pk_fk_table)

class AmiIdentifierPreparer(compiler.IdentifierPreparer):
    def __init__(self, dialect):
        super().__init__(dialect, initial_quote='"', final_quote='"')

    def format_literal(self, value, **kw):
        """Format a string literal for AMI SQL."""
        return f'"{str(value).replace(self.final_quote, self.final_quote + self.final_quote)}"'


class AmiTypeCompiler(compiler.TypeCompiler):
    """Type compiler for AMI SQL."""

    def visit_big_integer(self, type_, **kw):
        return "LONG"

    def visit_integer(self, type_, **kw):
        return "INT"

    def visit_CHAR(self, type_, **kw):
        return "CHAR"

    def visit_small_integer(self, type_, **kw):
        return "SHORT"

    def visit_float(self, type_, **kw):
        return "DOUBLE"

    def visit_REAL(self, type_, **kw):
        return "FLOAT"

    def visit_datetime(self, type_, **kw):
        return "UTC"

    def visit_boolean(self, type_, **kw):
        return "BOOLEAN"

    def visit_string(self, type_, **kw):
        return "STRING"

    def visit_unicode(self, type_, **kw):
        return "STRING"

    def visit_BINARY(self, type_, **kw):
        return "Binary"

    def visit_large_binary(self, type_, **kw):
        return "BYTE"

    def visit_text(self, type_, **kw):
        return "STRING"


class AmiDDLCompiler(compiler.DDLCompiler):
    """DDL compiler for AMI SQL."""

    """
    NOT NULL - is not supported in AMI SQL DDL
    PRIMARY KEY - is not supported in AMI SQL DDL
    UNIQUE - is not supported in AMI SQL DDL
    FOREIGN KEY - is not supported in AMI SQL DDL
    """
    def get_column_specification(self, column, **kwargs):
        """Generate column specification for AMI SQL."""
        # so far no constraints are supported in AMI SQL DDL
        return self.preparer.format_column(column) + " " + self.type_compiler.process(column.type)

    def visit_primary_key_constraint(
        self, constraint: PrimaryKeyConstraint, **kw: Any
    ) -> str:
        """Primary keys are not supported in AMI SQL DDL."""
        return ""

    #def visit_foreign_key_constraint(self, constraint, **kw):
    #    """Foreign keys are not supported in AMI SQL DDL."""
    #    return ""

    def visit_create_index(self, create, **kw):
        """
        Render AMI dialect CREATE INDEX:

        CREATE INDEX [IF NOT EXISTS] idx_name
            ON tbl_name(col_name [HASH|SORT|SERIES] [, ...])
            [USE  CONSTRAINT="[NONE|UNIQUE|PRIMARY]"]

        Per-column modifiers can be supplied via:
          - index.info['ami_columns'] = {'col_name': 'HASH', ...}
          - column.info['ami_index'] = 'SORT'
        Global use-constraint can be supplied via:
          - index.info['use_constraint'] = 'UNIQUE'
          - index.dialect_options.get('ami', {}).get('use_constraint')
        """
        index = getattr(create, "element", create)
        # If index was already created in the after_create listener and marked
        # to skip DDL, don't emit a CREATE INDEX statement again.
        if getattr(index, "info", {}).get("skip_ddl"):
            return ""
        table = index.table

        # prefer index.info mapping for per-column modifiers
        info_cols = {}
        if getattr(index, "info", None):
            info_cols = index.info.get("ami_columns", {}) or {}
        # also check dialect-specific options
        dialect_opts = {}
        if getattr(index, "dialect_options", None):
            dialect_opts = index.dialect_options.get("ami", {}) or {}

        use_constraint = None
        if getattr(index, "info", None):
            use_constraint = index.info.get("use_constraint")
        if use_constraint is None:
            use_constraint = dialect_opts.get("use_constraint")
        if use_constraint is None:
            if getattr(index, "unique", False):
                use_constraint = "UNIQUE"

        # AUTOGEN handling: can be supplied via index.info['autogen'] or
        # index.dialect_options['ami']['autogen']. Accept values RAND or INC.
        autogen = None
        if getattr(index, "info", None):
            autogen = index.info.get("autogen")
        if autogen is None:
            autogen = dialect_opts.get("autogen")
        if autogen is not None:
            try:
                autogen = str(autogen).upper()
            except Exception:
                autogen = None
            if autogen not in ("RAND", "INC"):
                autogen = None

        # collect column fragments
        exprs = getattr(index, "expressions", None)
        if not exprs:
            # fallback to index.columns (SQLAlchemy Index has .columns collection)
            exprs = list(getattr(index, "columns", []))

        col_fragments = []
        for expr in exprs:
            # try to format as a column name first
            try:
                col_name = self.preparer.format_column(expr)
            except Exception:
                # expression fallback
                col_name = self.process(expr, **kw)

            # determine modifier: index.info mapping keyed by column name, or column.info
            modifier = None
            col_plain_name = getattr(expr, "name", None)
            if col_plain_name and col_plain_name in info_cols:
                modifier = str(info_cols[col_plain_name]).upper()
            elif getattr(expr, "info", None):
                modifier = expr.info.get("ami_index")
                if modifier:
                    modifier = str(modifier).upper()

            if modifier and modifier not in ("HASH", "SORT", "SERIES"):
                modifier = None

            if modifier:
                col_fragments.append(f"{col_name} {modifier}")
            else:
                col_fragments.append(col_name)

        idx_name = index.name or ""
        table_name = self.preparer.format_table(table)

        sql = "CREATE INDEX IF NOT EXISTS "
        sql += f"{idx_name} ON {table_name}(" + ", ".join(col_fragments) + ")"

        if use_constraint:
            uc = str(use_constraint).upper()
            if uc in ("NONE", "UNIQUE", "PRIMARY"):
                sql += f' USE CONSTRAINT="{uc}"'

        if autogen:
            sql += f' AUTOGEN="{autogen}"'

        return sql

    def visit_create_table(self, create, **kw):
        # include_foreign_key_constraints can be None in some SQLAlchemy versions
        if getattr(create, 'include_foreign_key_constraints', None) is None:
            create.include_foreign_key_constraints = []
        elif len(create.include_foreign_key_constraints) > 0:
            create.include_foreign_key_constraints = []

        # if in 'info' there is no 'prefixes' set prefixes=["PUBLIC"] by default
        table = create.element
        if table._prefixes is None or "PUBLIC" not in table._prefixes:
            if table._prefixes is None:
                table._prefixes = []
            table._prefixes.append("PUBLIC")

        return super().visit_create_table(create, **kw)


class AmiStatementCompiler(compiler.SQLCompiler):
    """SQL compiler for AMI SQL."""

    def visit_binary(self, binary, override_operator=None, **kw):
        """Translate standard SQL operators to AMI SQL operators."""
        # Handle JSON getitem operators (postfix JSON indexing) as: <left>[<right>]
        try:
            if binary.operator == getattr(operators, 'json_getitem_op'):
                left_expr = binary.left
                right_expr = binary.right
                left_sql = self.process(left_expr, **kw)
                right_sql = self.process(right_expr, **kw)
                # if left side has JSON type, wrap with parseJson(...)
                try:
                    from sqlalchemy import types as _satypes
                    left_type = getattr(left_expr, 'type', None)
                    is_json_left = False
                    if left_type is not None:
                        if isinstance(left_type, type):
                            try:
                                if issubclass(left_type, _satypes.JSON):
                                    is_json_left = True
                            except Exception:
                                pass
                        else:
                            if isinstance(left_type, _satypes.JSON):
                                is_json_left = True
                    if is_json_left:
                        left_sql = f"parseJson({left_sql})"
                except Exception:
                    pass
                return left_sql + '[' + right_sql + ']'
        except Exception:
            pass
        try:
            if binary.operator == getattr(operators, 'json_getitem_path_op'):
                left_expr = binary.left
                right_expr = binary.right
                left_sql = self.process(left_expr, **kw)
                right_sql = self.process(right_expr, **kw)
                try:
                    from sqlalchemy import types as _satypes
                    left_type = getattr(left_expr, 'type', None)
                    is_json_left = False
                    if left_type is not None:
                        if isinstance(left_type, type):
                            try:
                                if issubclass(left_type, _satypes.JSON):
                                    is_json_left = True
                            except Exception:
                                pass
                        else:
                            if isinstance(left_type, _satypes.JSON):
                                is_json_left = True
                    if is_json_left:
                        left_sql = f"parseJson({left_sql})"
                except Exception:
                    pass
                return left_sql + '[' + right_sql + ']'
        except Exception:
            pass
        try:
            if binary.operator == getattr(operators, 'json_getitem_op_text'):
                left_expr = binary.left
                right_expr = binary.right
                left_sql = self.process(left_expr, **kw)
                right_sql = self.process(right_expr, **kw)
                try:
                    from sqlalchemy import types as _satypes
                    left_type = getattr(left_expr, 'type', None)
                    is_json_left = False
                    if left_type is not None:
                        if isinstance(left_type, type):
                            try:
                                if issubclass(left_type, _satypes.JSON):
                                    is_json_left = True
                            except Exception:
                                pass
                        else:
                            if isinstance(left_type, _satypes.JSON):
                                is_json_left = True
                    if is_json_left:
                        left_sql = f"parseJson({left_sql})"
                except Exception:
                    pass
                return left_sql + '[' + right_sql + ']'
        except Exception:
            pass

        if binary.operator == operators.eq:
            override_operator = operators.custom_op("==")
        elif binary.operator == operators.is_:
            override_operator = operators.custom_op("==")
        elif binary.operator == operators.isnot:
            override_operator = operators.custom_op("!=")
        elif binary.operator == operators.like_op:
            override_operator = operators.custom_op("~~")
        elif binary.operator == operators.not_like_op:
            override_operator = operators.custom_op("!~")
        elif binary.operator == operators.concat_op:
            override_operator = operators.custom_op("+")
        return super().visit_binary(binary, override_operator=override_operator, **kw)

    def visit_join(self, join, asfrom=False, **kwargs):
        """Translate SQLAlchemy joins to AMI SQL JOIN syntax."""

        # join: sqlalchemy.sql.selectable.Join: full, isouter, right, left, onclause

        # SQLAlchemy 'join' doesn't support:
        # OUTER ONLY JOIN
        # LEFT ONLY JOIN
        # RIGHT ONLY JOIN
        # So we check for custom attributes or hints to handle these. - TODO

        if join.full:
            join_type = " OUTER JOIN "
        elif join.isouter:
            if getattr(join, "_is_right_join", False):
                join_type = " RIGHT JOIN "
            elif getattr(join, "_is_right_only_join", False):
                join_type = " RIGHT ONLY JOIN "
            elif getattr(join, "_is_left_only_join", False):
                join_type = " LEFT ONLY JOIN "
            elif getattr(join, "_is_outer_only_join", False):
                join_type = " OUTER ONLY JOIN "
            else:
                join_type = " LEFT JOIN "
        else:
            join_type = " JOIN "

        return (
            self.process(join.left, asfrom=True, **kwargs)
            + join_type
            + self.process(join.right, asfrom=True, **kwargs)
            + " ON "
            + self.process(join.onclause, **kwargs)
        )

    def visit_select(self, select_stmt: selectable.Select, **kwargs):
        """Translate SELECT DISTINCT to GROUP BY for AMI SQL."""
        if select_stmt._distinct and not select_stmt._group_by_clause.clauses:
            select_stmt._distinct = False
            stmt = select_stmt.group_by(*select_stmt.selected_columns.values())
            return super().visit_select(stmt, **kwargs)

        return super().visit_select(select_stmt, **kwargs)

    def limit_clause(self, select, **kw):
        """Render LIMIT clause as: LIMIT [offset,] <n>"""
        if select._limit_clause is None:
            if select._offset_clause is not None:
                raise ValueError("AMI SQL requires LIMIT when OFFSET is specified.")
            return ""

        limit_expression = "\n LIMIT "
        if select._offset_clause is not None:
            limit_expression += self.process(select._offset_clause, **kw) + ", "
        limit_expression += self.process(select._limit_clause, **kw)
        return limit_expression

    def offset_clause(self, select, **kw):
        """Handled by limit_clause for AMI SQL."""
        return ""

    def visit_function(self, func, **kw):
        """Translate SQL functions to AMI SQL functions if needed."""
        # Example: translate CURRENT_TIMESTAMP to UTCNOW
        if func.name.upper() == "NOW" or func.name.upper() == "CURRENT_TIMESTAMP":
            return "timestamp()"
        return super().visit_function(func, **kw)

    def visit_cast(self, cast, **kw):
        """Translate CAST expressions to AMI SQL syntax.

        Render as (TargetType)(Value). Prefer using the dialect's TypeCompiler
        when the target is a SQLAlchemy TypeEngine so that DB-specific type
        names are generated (e.g. INT, STRING, UTC). Fall back to generic
        expression processing when needed.
        """

        # Render the value being cast using the normal machinery
        try:
            value = self.process(cast.clause, **kw)
        except Exception:
            # fallback to lower-level dispatch
            value = cast.clause._compiler_dispatch(self, **kw)

        # Determine the target type. If the cast carries a SQLAlchemy TypeEngine
        # instance (accessible as .type or via .type_clause.type) use the
        # dialect's TypeCompiler to produce the correct type name.
        target = None
        try:
            # preferred: cast.type (TypeEngine) if present
            if getattr(cast, "type", None) is not None:
                target_type_obj = cast.type
            elif getattr(cast, "type_clause", None) is not None and getattr(cast.type_clause, "type", None) is not None:
                target_type_obj = cast.type_clause.type
            else:
                target_type_obj = None

            # Detect JSON target early: if the target type is a SQLAlchemy JSON
            # type, AMI expects usage of parseJson(string) rather than CAST(... AS JSON).
            is_json_target = False
            try:
                from sqlalchemy import types as _satypes
                if target_type_obj is not None:
                    # If class, try issubclass; if instance, isinstance
                    if isinstance(target_type_obj, type):
                        try:
                            if issubclass(target_type_obj, _satypes.JSON):
                                is_json_target = True
                        except Exception:
                            # not a class that can be issubclass-checked
                            pass
                    else:
                        if isinstance(target_type_obj, _satypes.JSON):
                            is_json_target = True
            except Exception:
                is_json_target = False

            # If target is JSON, render as parseJson(<value>) and return early.
            if is_json_target:
                return f"parseJson({value})"

            # If a class is passed (e.g. Integer), try to instantiate it to a TypeEngine
            if target_type_obj is not None and isinstance(target_type_obj, type):
                try:
                    if issubclass(target_type_obj, TypeEngine):
                        # instantiate the TypeEngine (e.g. Integer -> Integer())
                        try:
                            target_type_obj = target_type_obj()
                        except Exception:
                            # instantiation may fail for unusual types; leave as-is
                            pass
                except Exception:
                    # issubclass can raise if target_type_obj is not a class; ignore
                    pass

            if target_type_obj is not None:
                # use the dialect's TypeCompiler to render the type name
                try:
                    # instantiate the dialect's TypeCompiler if available
                    tc_cls = getattr(self.dialect, 'type_compiler', None)
                    if tc_cls is not None:
                        try:
                            tc = tc_cls(self.dialect)
                            target = tc.process(target_type_obj, **kw)
                        except Exception:
                            # if instantiation or processing fails, fallback
                            target = None
                    else:
                        target = None
                except Exception:
                    target = None

                if not target:
                    # fallback: if we have the original target_type_obj, try a simple
                    # mapping by class name (covers common SQLAlchemy types).
                    try:
                        cls_name = None
                        if target_type_obj is not None:
                            if isinstance(target_type_obj, type):
                                cls_name = target_type_obj.__name__
                            else:
                                cls_name = target_type_obj.__class__.__name__
                        if cls_name:
                            simple_map = {
                                'Integer': 'INT',
                                'BigInteger': 'LONG',
                                'SmallInteger': 'SHORT',
                                'Float': 'DOUBLE',
                                'REAL': 'FLOAT',
                                'DateTime': 'UTC',
                                'Date': 'UTC',
                                'Boolean': 'BOOLEAN',
                                'String': 'STRING',
                                'Unicode': 'STRING',
                                'BINARY': 'Binary',
                                'LargeBinary': 'BYTE',
                                'CHAR': 'CHAR',
                            }
                            mapped = simple_map.get(cls_name)
                            if mapped:
                                target = mapped
                    except Exception:
                        pass

            if not target:
                # fallback to processing the type_clause/expression
                try:
                    target = self.process(cast.type_clause, **kw)
                except Exception:
                    try:
                        target = cast.type_clause._compiler_dispatch(self, **kw)
                    except Exception:
                        target = ""
        except Exception:
            target = ""

        return f"({target})({value})"





class AmiComplexType(types.TypeDecorator):
    """Custom type for AMI Complex type."""
    impl = sqltypes.String

    def process_bind_param(self, value, dialect):
        """Convert Python complex to AMI string representation."""
        if value is None:
            return None
        if isinstance(value, complex):
            return f"{value.real}+{value.imag}i"
        raise ValueError("Value must be a complex number.")

    def process_result_value(self, value, dialect):
        """Convert AMI string representation back to Python complex."""
        if value is None:
            return None
        try:
            value = value.replace('i', 'j')
            return complex(value)
        except Exception:
            raise ValueError("Invalid complex number format from database.")

class AmiUUIDType(types.TypeDecorator):
    """Custom type for AMI UUID type."""
    impl = sqltypes.String

    def process_bind_param(self, value, dialect):
        """Convert Python UUID to string for AMI."""
        if value is None:
            return None
        return str(value)

    def process_result_value(self, value, dialect):
        """Convert string from AMI back to Python UUID."""
        if value is None:
            return None
        import uuid
        try:
            return uuid.UUID(value)
        except Exception:
            raise ValueError("Invalid UUID format from database.")

class AmiDialect(DefaultDialect):
    name = "ami"
    driver = "ami_dbapi"
    supports_native_boolean = True
    supports_schemas = True
    supports_multivalues_insert = True
    statement_compiler = AmiStatementCompiler
    ddl_compiler = AmiDDLCompiler
    type_compiler = AmiTypeCompiler
    preparer = AmiIdentifierPreparer
    paramstyle = 'named'
    supports_statement_cache = True
    skip_autocommit_rollback = True

    # mapping of SQL types to SQLAlchemy types
    ischema_names: Dict[str, Any] = {
        'BigDecimal': sqltypes.BigInteger,
        'BigInteger': sqltypes.BigInteger,
        'Binary': sqltypes.BINARY,
        'Boolean': sqltypes.Boolean,
        'Byte': sqltypes.INTEGER,
        'Character': sqltypes.CHAR,
        'Complex': AmiComplexType,
        'Date': sqltypes.Date,
        'Double': sqltypes.Float,
        'Float': sqltypes.Float,
        'Integer': sqltypes.Integer,
        'Long': sqltypes.BigInteger,
        'Number': sqltypes.Integer,
        'Short': sqltypes.SmallInteger,
        'String': sqltypes.String,
        'UTC': sqltypes.DateTime,
        'UTCN': sqltypes.DateTime,
        'UUID': AmiUUIDType,
    }

    #def do_rollback(self, dbapi_connection):
    #    raise Exception("Not implemented")
    #    pass

    @classmethod
    def dbapi(cls):
        import pyami.db.ami_dbapi.ami_dbapi
        return pyami.db.ami_dbapi.ami_dbapi

    @classmethod
    def import_dbapi(cls):
        import pyami.db.ami_dbapi.ami_dbapi as module
        return module

    @staticmethod
    def create_url(url_str: str):
        return make_url(url_str)

    def create_connect_args(self, url) -> Tuple[list, Dict[str, Any]]:
        """Create (args, kwargs) for DBAPI's connect() from a SQLAlchemy URL."""
        opts: Dict[str, Any] = dict(url.query) if getattr(url, "query", None) else {}

        if getattr(url, "username", None):
            opts.setdefault("username", url.username)
        if getattr(url, "password", None):
            opts.setdefault("password", url.password)
        if getattr(url, "host", None):
            opts.setdefault("host", url.host)
        if getattr(url, "port", None):
            opts.setdefault("port", url.port)
        if getattr(url, "timeout", None):
            opts.setdefault("timeout", url.timeout)
        if getattr(url, "limit", None):
            opts.setdefault("limit", url.limit)

        return [], opts

    def initialize(self, connection):
        """Dialect initialization hook."""
        super().initialize(connection)

    def has_table(self, connection, table_name: str, schema: str = None, **kw) -> bool:
        """Return True if table exists using parameterized driver SQL."""
        try:
            result = connection.exec_driver_sql(
                'select count(*) from __TABLE where TableName == :name',
                {"name": table_name},
            )
            row = result.fetchone()
            return len(row) > 0 and row[0][0] > 0
        except Exception:
            return False

    def get_table_names(self, connection, schema: str = None, **kw):
        """Return a list of table names from AMI catalog."""
        try:
            result = connection.exec_driver_sql("select TableName from __TABLE")
            rows = result.fetchall()
            return [row[0] for row in rows]
        except Exception:
            return []

    def get_view_names(self, connection: Connection, schema: Optional[str] = None, **kw: Any):
        """No views in AMI dialect."""
        return []

    def get_columns(self, connection, table_name, schema=None, **kw):
        """Return column information for a table."""
        sql = "SELECT ColumnName, DataType, NoNull FROM __COLUMN WHERE TableName == :table_name"
        try:
            result = connection.exec_driver_sql(sql, {"table_name": table_name})
            rows = result.fetchall()
            columns = []
            for row in rows:
                col_name = row[0]
                col_type_str = row[1]
                nullable = not row[2]
                col_type = self.ischema_names.get(col_type_str, sqltypes.NULLTYPE)

                columns.append({
                    "name": col_name,
                    "type": col_type,
                    "nullable": nullable,
                    "default": None, # Not available in assumed schema
                    "autoincrement": False, # Not available in assumed schema
                })
            return columns
        except Exception:
            return []

    def get_pk_constraint(self, connection, table_name, schema=None, **kw):
        """Return the primary key constraint for a table."""
        # This implementation assumes a system catalog table named `__COLUMN`
        # with a boolean `IsPrimaryKey` column.
        sql = 'SELECT ColumnName FROM __INDEX WHERE TableName == :table_name AND Constraint == "PRIMARY"'
        try:
            result = connection.exec_driver_sql(sql, {"table_name": table_name})
            rows = result.fetchall()
            pk_cols = [row.ColumnName for row in rows]
            return {"constrained_columns": pk_cols, "name": None}
        except Exception:
            return {"constrained_columns": [], "name": None}

    def get_indexes(self, connection, table_name, schema=None, **kw):
        """Return index information for a table."""
        # This implementation assumes a system catalog table named `__INDEX`.
        # You may need to adjust the table and column names.
        sql = "SELECT IndexName, ColumnName, Constraint FROM __INDEX WHERE TableName == :table_name"
        try:
            result = connection.exec_driver_sql(sql, {"table_name": table_name})
            rows = result.fetchall()
            indexes = {}
            for row in rows:
                index_name = row[0]
                column_name = row[1]
                is_unique = row[2] != "NONE"
                if index_name not in indexes:
                    indexes[index_name] = {
                        "name": index_name,
                        "column_names": [column_name],
                        "unique": is_unique
                    }
                else:
                    indexes[index_name]["column_names"].append(column_name)
                    indexes[index_name]["unique"] = is_unique
            return list(indexes.values())
        except Exception:
            return []

    def get_foreign_keys(
        self,
        connection: Connection,
        table_name: str,
        schema: Optional[str] = None,
        **kw: Any,
    ) -> List[ReflectedForeignKeyConstraint]:
        """ Foreign keys are not supported in this dialect. """
        return []
