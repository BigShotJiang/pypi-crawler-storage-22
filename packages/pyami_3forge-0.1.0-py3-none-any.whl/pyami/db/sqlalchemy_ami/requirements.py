from sqlalchemy.testing.requirements import SuiteRequirements
from sqlalchemy.testing import exclusions


class Requirements(SuiteRequirements):
    @property
    def uuid_data_type(self):
        return exclusions.open()

    @property
    def self_referential_foreign_keys(self):
        return exclusions.closed()

    @property
    def foreign_key_ddl(self):
        return exclusions.closed()

    @property
    def foreign_keys(self):
        return exclusions.closed()

    @property
    def views(self):
        return exclusions.open()

