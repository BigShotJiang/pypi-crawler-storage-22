from setuptools import setup

setup(
    name="pyami-sqlalchemy-ami",
    version="0.1.0",
    description="SQLAlchemy dialect for AMI JDBC connections",
    author="sss",
    entry_points = {
        "sqlalchemy.dialects": [
            "ami.jdbc = pyami.db.sqlalchemy_ami.base:AmiDialect",
        ],
    },
)

# entrypoint ami.jdbc allows URLs to be used such as:
# create_engine("ami+jdbc://user:password@host:port?timeout=60000&limit=10000")
