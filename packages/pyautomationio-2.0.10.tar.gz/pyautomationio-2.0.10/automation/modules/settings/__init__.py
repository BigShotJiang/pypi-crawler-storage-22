# -*- coding: utf-8 -*-
"""automation/modules/settings/__init__.py

This module implements settings resources.
"""
from .resources.settings import ns

