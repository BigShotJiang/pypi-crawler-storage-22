# pyav_scenechage

Python binding for [av-scenechange](https://github.com/rust-av/av-scenechange)

- [Installation](#installtion)
- [Usage](#usage)


## Installtion

1. Build wheel

   ```bash
   git clone https://codeberg.org/Khaoklong51/py_avscenechange.git
   cd py_avscenechange
   # for windows self build check build/windows folder
   # normal build
   python -m venv .venv # or uv venv if you have uv
   pip install maturin # or uv pip install maturin if you have uv
   maturin build --release
   ```

2. Wheel files

   **Windows** Wheel file can be download at [release](https://codeberg.org/Khaoklong51/py_avscenechange/releases) section\
   \
   then install with pip or your prefered package manager

## Usage
```python
import pyav_scenechange
input_path = "test.mp4" # change this to your actual video path

print(pyav_scenechange.scene_detect(input_path).to_list())
# this will print list of scene chanage
# example: [0, 240, 366, 606, 671, 762, 829, 982, 1143, 
# 1219, 1303, 1380, 1423, 1468, 1492, 1561, 1623, 1671, 
# 1736, 1760, 1827, 1877, 2022, 2066, 2147, 2183]
```
