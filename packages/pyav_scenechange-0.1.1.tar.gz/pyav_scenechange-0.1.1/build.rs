fn main() {
    println!("cargo:rerun-if-changed=build.rs");
    #[cfg(feature = "ffms2_static")]
    {
        let ffms2_lib = pkg_config::Config::new()
            .statik(true)
            .probe("ffms2")
            .expect("failed to find ffms2 via pkg-config");

        for path in ffms2_lib.link_paths {
            println!("cargo:rustc-link-search=native={}", path.display());
        }

        for lib in ffms2_lib.libs {
            println!("cargo:rustc-link-lib=static={}", lib);
        }

        #[cfg(feature = "dev")]
        // personal feature for pyo3-stub-gen
        println!(
            "cargo:rustc-link-search=native={}",
            r"C:\Program Files (x86)\Windows Kits\10\Lib\10.0.26100.0\um\x64"
        );

        println!("cargo:rustc-link-lib=static=ffms2");
        #[cfg(all(target_os = "windows", target_abi = "llvm"))]
        {
            println!("cargo:rustc-link-lib=static=c++");
            println!("cargo:rustc-link-lib=static=c++abi");
        }
    }
}
