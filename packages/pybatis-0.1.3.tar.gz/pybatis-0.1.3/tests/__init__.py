# Tests package for pyBatis
