"""
finite volume method
"""

from __future__ import annotations

import typing

import pybFoam.pybFoam_core

__all__: list[str] = ["Sp", "Su", "SuSp", "ddt", "div", "laplacian"]

@typing.overload
def Sp(
    arg0: pybFoam.pybFoam_core.dimensionedScalar, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def Sp(
    arg0: pybFoam.pybFoam_core.tmp_volScalarField, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def Sp(
    arg0: pybFoam.pybFoam_core.dimensionedScalar, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def Sp(
    arg0: pybFoam.pybFoam_core.tmp_volScalarField, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def Sp(
    arg0: pybFoam.pybFoam_core.dimensionedScalar, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def Sp(
    arg0: pybFoam.pybFoam_core.tmp_volScalarField, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def Su(
    arg0: pybFoam.pybFoam_core.dimensionedScalar, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def Su(
    arg0: pybFoam.pybFoam_core.tmp_volScalarField, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def Su(
    arg0: pybFoam.pybFoam_core.dimensionedVector, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def Su(
    arg0: pybFoam.pybFoam_core.tmp_volVectorField, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def Su(
    arg0: pybFoam.pybFoam_core.dimensionedTensor, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def Su(
    arg0: pybFoam.pybFoam_core.tmp_volTensorField, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def SuSp(
    arg0: pybFoam.pybFoam_core.dimensionedScalar, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def SuSp(
    arg0: pybFoam.pybFoam_core.tmp_volScalarField, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def SuSp(
    arg0: pybFoam.pybFoam_core.dimensionedScalar, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def SuSp(
    arg0: pybFoam.pybFoam_core.tmp_volScalarField, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def SuSp(
    arg0: pybFoam.pybFoam_core.dimensionedScalar, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def SuSp(
    arg0: pybFoam.pybFoam_core.tmp_volScalarField, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def ddt(arg0: pybFoam.pybFoam_core.volScalarField) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def ddt(
    arg0: pybFoam.pybFoam_core.dimensionedScalar, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def ddt(
    arg0: pybFoam.pybFoam_core.volScalarField, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def ddt(
    arg0: pybFoam.pybFoam_core.volScalarField,
    arg1: pybFoam.pybFoam_core.volScalarField,
    arg2: pybFoam.pybFoam_core.volScalarField,
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def ddt(arg0: pybFoam.pybFoam_core.volVectorField) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def ddt(
    arg0: pybFoam.pybFoam_core.dimensionedScalar, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def ddt(
    arg0: pybFoam.pybFoam_core.volScalarField, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def ddt(
    arg0: pybFoam.pybFoam_core.volScalarField,
    arg1: pybFoam.pybFoam_core.volScalarField,
    arg2: pybFoam.pybFoam_core.volVectorField,
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def ddt(arg0: pybFoam.pybFoam_core.volTensorField) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def ddt(
    arg0: pybFoam.pybFoam_core.dimensionedScalar, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def ddt(
    arg0: pybFoam.pybFoam_core.volScalarField, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def ddt(
    arg0: pybFoam.pybFoam_core.volScalarField,
    arg1: pybFoam.pybFoam_core.volScalarField,
    arg2: pybFoam.pybFoam_core.volTensorField,
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def div(
    arg0: pybFoam.pybFoam_core.surfaceScalarField, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def div(
    arg0: pybFoam.pybFoam_core.tmp_surfaceScalarField, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def div(
    arg0: pybFoam.pybFoam_core.surfaceScalarField, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def div(
    arg0: pybFoam.pybFoam_core.tmp_surfaceScalarField, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def div(
    arg0: pybFoam.pybFoam_core.surfaceScalarField, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def div(
    arg0: pybFoam.pybFoam_core.tmp_surfaceScalarField, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def div(
    arg0: pybFoam.pybFoam_core.surfaceScalarField, arg1: pybFoam.pybFoam_core.volSymmTensorField
) -> pybFoam.pybFoam_core.tmp_fvSymmTensorMatrix: ...
@typing.overload
def div(
    arg0: pybFoam.pybFoam_core.tmp_surfaceScalarField, arg1: pybFoam.pybFoam_core.volSymmTensorField
) -> pybFoam.pybFoam_core.tmp_fvSymmTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.volScalarField,
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.dimensionedScalar, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.volScalarField, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.tmp_volScalarField, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.volTensorField, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.tmp_volTensorField, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.surfaceScalarField, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.tmp_surfaceScalarField, arg1: pybFoam.pybFoam_core.volScalarField
) -> pybFoam.pybFoam_core.tmp_fvScalarMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.volVectorField,
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.dimensionedScalar, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.volScalarField, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.tmp_volScalarField, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.volTensorField, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.tmp_volTensorField, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.surfaceScalarField, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.tmp_surfaceScalarField, arg1: pybFoam.pybFoam_core.volVectorField
) -> pybFoam.pybFoam_core.tmp_fvVectorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.volTensorField,
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.dimensionedScalar, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.volScalarField, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.tmp_volScalarField, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.volTensorField, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.tmp_volTensorField, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.surfaceScalarField, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.tmp_surfaceScalarField, arg1: pybFoam.pybFoam_core.volTensorField
) -> pybFoam.pybFoam_core.tmp_fvTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.volSymmTensorField,
) -> pybFoam.pybFoam_core.tmp_fvSymmTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.dimensionedScalar, arg1: pybFoam.pybFoam_core.volSymmTensorField
) -> pybFoam.pybFoam_core.tmp_fvSymmTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.volScalarField, arg1: pybFoam.pybFoam_core.volSymmTensorField
) -> pybFoam.pybFoam_core.tmp_fvSymmTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.tmp_volScalarField, arg1: pybFoam.pybFoam_core.volSymmTensorField
) -> pybFoam.pybFoam_core.tmp_fvSymmTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.volTensorField, arg1: pybFoam.pybFoam_core.volSymmTensorField
) -> pybFoam.pybFoam_core.tmp_fvSymmTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.tmp_volTensorField, arg1: pybFoam.pybFoam_core.volSymmTensorField
) -> pybFoam.pybFoam_core.tmp_fvSymmTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.surfaceScalarField, arg1: pybFoam.pybFoam_core.volSymmTensorField
) -> pybFoam.pybFoam_core.tmp_fvSymmTensorMatrix: ...
@typing.overload
def laplacian(
    arg0: pybFoam.pybFoam_core.tmp_surfaceScalarField, arg1: pybFoam.pybFoam_core.volSymmTensorField
) -> pybFoam.pybFoam_core.tmp_fvSymmTensorMatrix: ...
