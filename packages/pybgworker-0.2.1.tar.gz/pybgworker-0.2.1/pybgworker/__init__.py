from .task import task
from .result import AsyncResult

__all__ = ["task", "AsyncResult"]
__version__ = "0.2.1"

