# Code

GitHub: [geobuf-cpp](hptts://github.com/cubao/geobuf-cpp)

## test_geobuf.py

```python
{%
   include-markdown "../tests/test_geobuf.py"
   comments=false
%}
```
