# pybind11-geobuf

{%
   include-markdown "../README.md"
   start="<!--intro-start-->"
   end="<!--intro-end-->"
%}

<div class="text-center">
<a href="https://github.com/cubao/geobuf-cpp" class="btn btn-primary" role="button">Code on GitHub</a>
<a href="https://pypi.org/project/pybind11-geobuf" class="btn btn-primary" role="button">Package on PyPi</a>
</div>
