from pynq import DefaultHierarchy, DefaultIP, allocate
import numpy as np
import struct
import time
import requests
import json
import os
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
import math
import struct

class AxiStreamHandler():

    def __init__(self, overlay, model_specs):
        self.firmware_name = overlay
        self.supported_boards = {
            'zynq': ['zedboard', 'ebaz4205'],
            'alveo': ['u50']
        }
        self.model_specs = model_specs
        self.batch_size = self.model_specs["batch_size"]
        self.overlay = overlay
        self.fill = False
        self.batches = []
        self.last_batch_size = 0
        self.n_input = self.model_specs['n_input']
        self.n_output = self.model_specs['n_output']
        self.benchcore = self.model_specs['benchcore']
        if self.benchcore == True:
            self.n_output = self.n_output + 1
        self.input_shape  = (self.batch_size, self.n_input)
        self.output_shape = (self.batch_size, self.n_output)
        self.datatype = None
        self.scale = None
        self.__initialize_datatype()
        if self.model_specs['board'] in self.supported_boards['zynq']:
            self.__init_channels()
        if self.model_specs["data_type"][:3] == "fps" or self.model_specs["data_type"][:3] == "fpx":
            self.__initialize_fixedpoint()

        self._use_local_flp = self.model_specs["data_type"].startswith("flp")
        if self._use_local_flp:
            self._flp_pool = ThreadPoolExecutor(max_workers=256)
        
    def __bin_to_float16(self, binary_str):
        binary_bytes = int(binary_str, 2).to_bytes(2, byteorder='big')
        float_val = struct.unpack('>e', binary_bytes)[0]
        return float_val

    def __bin_to_float32(self, binary_str):
        byte_str = int(binary_str, 2).to_bytes(4, byteorder='big')
        float_value = struct.unpack('>f', byte_str)[0]
        return float_value

    def __float_to_flopoco_binary(self, num, exponent_bits, mantissa_bits):
        """
        Convert a Python float to FloPoCo binary format (as unsigned int).
        
        FloPoCo format: exn (2 bits) | s (1 bit) | E (exponent_bits) | F (mantissa_bits)
        Total bits: exponent_bits + mantissa_bits + 3
        
        Args:
            num: float value to convert
            exponent_bits: number of exponent bits (wE)
            mantissa_bits: number of mantissa bits (wF)
        
        Returns:
            unsigned integer representation of the FloPoCo number
        """
        # Handle special cases first
        if math.isnan(num):
            # exn = 11 (NaN)
            exn = 0b11
            sign = 0
            exp = 0
            frac = 0
        elif math.isinf(num):
            # exn = 10 (infinity)
            exn = 0b10
            sign = 1 if num < 0 else 0
            exp = 0
            frac = 0
        elif num == 0.0:
            # exn = 00 (zero)
            exn = 0b00
            sign = 1 if math.copysign(1.0, num) < 0 else 0
            exp = 0
            frac = 0
        else:
            # exn = 01 (normal number)
            exn = 0b01
            
            # Extract sign
            sign = 1 if num < 0 else 0
            abs_num = abs(num)
            
            # Get exponent bias
            E0 = (1 << (exponent_bits - 1)) - 1  # 2^(wE-1) - 1
            
            # Get mantissa and exponent using frexp
            # frexp returns (mantissa, exponent) where num = mantissa * 2^exponent
            # and 0.5 <= abs(mantissa) < 1.0
            mant, exp_raw = math.frexp(abs_num)
            
            # Adjust to FloPoCo convention: (1 + F) * 2^(E - E0)
            # frexp gives us: mant * 2^exp_raw where 0.5 <= mant < 1.0
            # We need: (1 + F) * 2^(E - E0) where 0 <= F < 1.0
            
            # mant * 2^exp_raw = (2*mant) * 2^(exp_raw-1) = (1 + (2*mant - 1)) * 2^(exp_raw-1)
            # So F = 2*mant - 1 and E - E0 = exp_raw - 1
            
            frac_value = 2.0 * mant - 1.0  # This is F, should be in [0, 1)
            exp_biased = exp_raw - 1 + E0  # This is E
            
            # Clamp exponent to valid range
            max_exp = (1 << exponent_bits) - 1
            if exp_biased < 0:
                # Underflow to zero
                exn = 0b00
                exp = 0
                frac = 0
            elif exp_biased > max_exp:
                # Overflow to infinity
                exn = 0b10
                exp = 0
                frac = 0
            else:
                exp = int(exp_biased)
                # Convert fractional part to integer
                frac = int(frac_value * (1 << mantissa_bits))
                # Clamp to mantissa_bits
                frac = frac & ((1 << mantissa_bits) - 1)
        
        # Pack everything together: exn | s | E | F
        total_bits = exponent_bits + mantissa_bits + 3
        result = (exn << (total_bits - 2))
        result |= (sign << (total_bits - 3))
        result |= (exp << mantissa_bits)
        result |= frac
        
        return result

    def __flopoco_binary_to_float(self, binary_str, exponent_bits, mantissa_bits):
        """
        Convert FloPoCo binary format to Python float.
        
        Args:
            binary_str: binary string representation (e.g., "0101010...")
            exponent_bits: number of exponent bits (wE)
            mantissa_bits: number of mantissa bits (wF)
        
        Returns:
            float value
        """
        total_bits = exponent_bits + mantissa_bits + 3
        
        # Ensure binary string is the right length
        binary_str = binary_str.lstrip('0b')
        if len(binary_str) < total_bits:
            binary_str = '0' * (total_bits - len(binary_str)) + binary_str
        
        # Extract fields
        exn = int(binary_str[0:2], 2)
        sign = int(binary_str[2], 2)
        exp = int(binary_str[3:3+exponent_bits], 2)
        frac = int(binary_str[3+exponent_bits:], 2)
        
        # Get exponent bias
        E0 = (1 << (exponent_bits - 1)) - 1
        
        # Decode based on exn field
        if exn == 0b00:  # Zero
            return -0.0 if sign else 0.0
        elif exn == 0b10:  # Infinity
            return float('-inf') if sign else float('inf')
        elif exn == 0b11:  # NaN
            return float('nan')
        else:  # exn == 0b01, normal number
            # Value = (-1)^s × (1 + F) × 2^(E - E0)
            frac_value = frac / (1 << mantissa_bits)  # F in [0, 1)
            mantissa = 1.0 + frac_value
            exponent = exp - E0
            
            result = mantissa * (2.0 ** exponent)
            return -result if sign else result

    def __unsigned_to_flopoco_binary_str(self, num, exponent_bits, mantissa_bits):
        """
        Convert unsigned integer to FloPoCo binary string.
        
        Args:
            num: unsigned integer
            exponent_bits: number of exponent bits (wE)
            mantissa_bits: number of mantissa bits (wF)
        
        Returns:
            binary string with proper length
        """
        total_bits = exponent_bits + mantissa_bits + 3
        binary_str = bin(num)[2:]  # Remove '0b' prefix
        
        # Pad to correct length
        if len(binary_str) < total_bits:
            binary_str = '0' * (total_bits - len(binary_str)) + binary_str
        
        # Take only the last total_bits (in case of overflow)
        binary_str = binary_str[-total_bits:]
        
        return binary_str

    def __random_pad(self, vec, pad_width, *_, **__):
        vec[:pad_width[0]] = np.random.uniform(0, 1, size=pad_width[0])
        vec[vec.size-pad_width[1]:] = np.random.uniform(0,1, size=pad_width[1])

    def __cast_float_to_binary_to_unsigned(self, num, remote=False):
        
        """Updated to use local implementation instead of external tools."""
        exponent_bits = int(self.model_specs["data_type"][4:5])
        mantissa_bits = int(self.model_specs["data_type"][6:len(self.model_specs["data_type"])])
        
        # Use the new pure Python implementation
        return self.__float_to_flopoco_binary(num, exponent_bits, mantissa_bits)

    def __cast_unsigned_to_bin(self, num, remote=False):
        """Updated to use local implementation."""
        exponent_bits = int(self.model_specs["data_type"][4:5])
        mantissa_bits = int(self.model_specs["data_type"][6:len(self.model_specs["data_type"])])
        
        # Use the new pure Python implementation
        return self.__unsigned_to_flopoco_binary_str(num, exponent_bits, mantissa_bits)

    def __convert_binary_to_float(self, binary_str, remote=False):
        """Updated to use local implementation."""
        exponent_bits = int(self.model_specs["data_type"][4:5])
        mantissa_bits = int(self.model_specs["data_type"][6:len(self.model_specs["data_type"])])
        
        # Use the new pure Python implementation
        return self.__flopoco_binary_to_float(binary_str, exponent_bits, mantissa_bits)


    def prepare_data(self):
        self.samples_len = len(self.X_test)
        self.fill = False
        self.batches = []

        _, hw_dtype = self.__get_dtype()

        def cast_batch(batch):
            flat = batch.ravel()

            is_signed_fixed = self.model_specs["data_type"].startswith("fps")
            is_unsigned_fixed = self.model_specs["data_type"].startswith("fpx")
            
            if is_signed_fixed or is_unsigned_fixed:
                conv = [self.__float_to_fixed(x) for x in flat]
            elif self._use_local_flp:
                futures = [self._flp_pool.submit(self.__cast_float_to_binary_to_unsigned, x)
                        for x in flat]
                conv = [f.result() for f in futures]
            else:
                return batch.astype(self.__get_dtype()[0])
            
            arr = np.array(conv, dtype=self.__get_dtype()[1]).reshape(batch.shape)
            return arr

        if self.samples_len <= self.batch_size:
            pad_n = self.batch_size - self.samples_len
            noise = np.random.rand(pad_n, self.X_test.shape[1])
            full = np.vstack([self.X_test, noise])
            self.batches.append(cast_batch(full))

        else:
            n_full = self.samples_len // self.batch_size
            rem    = self.samples_len % self.batch_size

            # full batches
            for i in range(n_full):
                batch = self.X_test[i*self.batch_size:(i+1)*self.batch_size]
                self.batches.append(cast_batch(batch))

            # leftover
            if rem:
                self.fill = True
                self.last_batch_size = rem
                last = self.X_test[n_full*self.batch_size:]
                pad_n = self.batch_size - rem
                noise = np.random.rand(pad_n, self.X_test.shape[1])
                last_padded = np.vstack([last, noise])
                self.batches.append(cast_batch(last_padded))

        print(f"Prepared {len(self.batches)} batches "
            f"(fill={self.fill}, last_batch_size={self.last_batch_size})")


    def __init_channels(self):
        self.sendchannel = self.overlay.axi_dma_0.sendchannel
        self.recvchannel = self.overlay.axi_dma_0.recvchannel

    def __initialize_fixedpoint(self):
        self.total_bits = self.model_specs['register_size']  # Total number of bits
        fractional_bits = int(self.model_specs['data_type'][6:len(self.model_specs['data_type'])])  # Number of fractional bits
        self.scale = 2 ** fractional_bits

    def __float_to_fixed(self, number):
        """Convert float to signed fixed-point with saturation."""
        scaled = int(round(number * self.scale))
        
        # Compute bounds for signed representation
        max_val = (1 << (self.total_bits - 1)) - 1
        min_val = -(1 << (self.total_bits - 1))
        
        # Optional: warn on overflow
        if scaled > max_val or scaled < min_val:
            print(f"Warning: Fixed-point overflow! Value {number} scaled to {scaled} "
                f"exceeds range [{min_val}, {max_val}]")
        
        # Saturate to valid range
        return max(min_val, min(max_val, scaled))
    
    def __float_to_fixed_unsigned(self, number):
        """Convert float to UNSIGNED fixed-point (for fpx types if needed)."""
        scaled = int(round(number * self.scale))
        
        # Compute bounds for unsigned representation
        max_val = (1 << self.total_bits) - 1
        min_val = 0
        
        if scaled > max_val or scaled < min_val:
            print(f"Warning: Unsigned fixed-point overflow! Value {number} scaled to {scaled} "
                f"exceeds range [{min_val}, {max_val}]")
        
        return max(min_val, min(max_val, scaled))

    def __fixed_to_float_unsigned(self, fixed_number):
        """Convert UNSIGNED fixed-point to float."""
        # For unsigned, ensure we interpret as unsigned
        # (though if buffer is already uint, this is automatic)
        if fixed_number < 0:
            # This shouldn't happen if buffer is correctly typed
            print(f"Warning: Received negative value {fixed_number} in unsigned context!")
            fixed_number = fixed_number & ((1 << self.total_bits) - 1)
        
        return float(fixed_number) / self.scale

    def __fixed_to_float(self, fixed_number):
        """
        Convert fixed-point to float.
        
        Note: Since buffers are allocated with signed dtypes (np.int16/np.int32),
        the values are already in signed representation. No two's complement
        conversion is needed.
        """
        # Direct conversion - no manual two's complement needed
        # because NumPy already gives us signed values
        return float(fixed_number) / self.scale

    def __initialize_datatype_flopoco(self, flopoco_datatype):

        exponent_bits = int(flopoco_datatype[4:5])
        mantissa_bits = int(flopoco_datatype[6:len(flopoco_datatype)])

        total_bits = exponent_bits + mantissa_bits + 3

        if total_bits <= 8:
            self.total_bits = 8
        elif total_bits > 8 and total_bits <= 16:
            self.total_bits = 16
        elif total_bits > 16 and total_bits < 32:
            self.total_bits = 32
        elif total_bits >= 32:
            self.total_bits = 32

        if self.total_bits == 32:
            return "np.uint32"
        elif self.total_bits == 16:
            return "np.uint16"
        elif self.total_bits == 8:
            return "np.uint8"

        
    def __initialize_datatype(self):
        if (self.model_specs["data_type"] == "float16"):
            self.datatype = "np.float16"
        elif (self.model_specs["data_type"] == "float32"):
            self.datatype = "np.float32"
        elif (self.model_specs["data_type"] == "fps16f10"):
            self.datatype = "np.fps16f10"
        elif (self.model_specs["data_type"] == "fps16f8"):
            self.datatype = "np.fps16f8"
        elif (self.model_specs["data_type"] == "fps16f6"):
            self.datatype = "np.fps16f6"
        elif (self.model_specs["data_type"] == "fps32f16"):
            self.datatype = "np.fps32f16"
        elif (self.model_specs["data_type"] == "fpx16f10"):
            self.datatype = "np.fpx16f10"
        elif (self.model_specs["data_type"] == "fpx16f8"):
            self.datatype = "np.fpx16f8"
        elif (self.model_specs["data_type"] == "fpx16f6"):
            self.datatype = "np.fpx16f6"
        elif (self.model_specs["data_type"] == "fpx32f16"):
            self.datatype = "np.fpx32f16"
        elif (self.model_specs["data_type"] == "fpx32f3"):
            self.datatype = "np.fpx32f3"
        elif (self.model_specs["data_type"].startswith("flpe")):
            print("Data type is flopoco since it starts with flpe")
            self.datatype = self.__initialize_datatype_flopoco(self.model_specs["data_type"])
        else:
            raise Exception("Data type not supported yet")

    def __get_dtype(self):
        if (self.model_specs["data_type"] == "float16"):
            return np.float16, np.uint16
        elif (self.model_specs["data_type"] == "float32"):
            return np.float32, np.uint32
        elif (self.model_specs["data_type"] == "fps16f10"):
            return np.int16, np.int16
        elif (self.model_specs["data_type"] == "fps16f8"):
            return np.int16, np.int16
        elif (self.model_specs["data_type"] == "fps16f6"):
            return np.int16, np.int16
        elif (self.model_specs["data_type"] == "fps32f16"):
            return np.int32, np.int32
        elif (self.model_specs["data_type"] == "fpx16f10"):
            return np.uint16, np.uint16  # Changed to unsigned!
        elif (self.model_specs["data_type"] == "fpx16f8"):
            return np.uint16, np.uint16
        elif (self.model_specs["data_type"] == "fpx16f6"):
            return np.uint16, np.uint16
        elif (self.model_specs["data_type"] == "fpx32f16"):
            return np.uint32, np.uint32
        elif (self.model_specs["data_type"] == "fpx32f3"):
            return np.uint32, np.uint32
        elif (self.model_specs["data_type"].startswith("flpe")):
            if self.datatype == "np.uint8" or self.datatype == "np.uint16":
                return np.uint16, np.uint16
            #elif self.datatype == "np.uint16":
            #    return np.uint16, np.uint16
            elif self.datatype == "np.uint32":
                return np.uint32, np.uint32
        else:
            raise Exception("Data type not supported yet")

    def __parse_prediction(self, outputs, debug):
        # Stack all batches into one big (N, n_output) array
        stacked = np.vstack(outputs).astype(int)
        total_samples, n_out = stacked.shape

        # If benchcore, last column is clock cycles
        if self.benchcore:
            clock_cycles = stacked[:, -1].tolist()
            data = stacked[:, :-1]
        else:
            clock_cycles = []
            data = stacked

        all_probs = []
        # FPS branch: fixed‑point → float by scaling
        if self.model_specs["data_type"].startswith("fps") or self.model_specs["data_type"].startswith("fpx"):
            # data is int array of shape (N, n_output)
            # fixed_to_float is just dividing by scale
            #probs = data.astype(np.float64) / self.scale
            #preds = np.argmax(probs, axis=1).astype(int).tolist()
            hw_classifications = []
            for outcome in outputs:
                for out in outcome:
                    probs = []
                    if self.model_specs["data_type"][:3] == "fps" or self.model_specs["data_type"][:3] == "fpx":
                        for i in range(0, self.n_output):
                            if self.benchcore == True and i == self.n_output - 1:
                                clock_cycles.append(out[i])
                            else:
                                prob = self.__fixed_to_float(out[i])
                                probs.append(prob)

                    print("probs: ", probs)
                    classification = np.argmax(probs)
                    hw_classifications.append(int(classification))
            
            preds = hw_classifications

        # FLP branch: floating‑point with custom exponent/mantissa
        elif self.model_specs["data_type"].startswith("flp"):
            # convert one row of unsigned ints → float probs + argmax
            def parse_row(row):
                # row is 1‑D array of ints
                # for each element, cast to binary then to float
                floats = [
                    self.__convert_binary_to_float(
                        self.__cast_unsigned_to_bin(int(val)),
                        remote=False
                    )
                    for val in row
                ]
                return int(np.argmax(floats))

            # parallelize across rows with threads
            with ThreadPoolExecutor(max_workers=256) as pool:
                preds = list(pool.map(parse_row, data))

        # IEEE float16 / float32 branch: reinterpret bits as real floats
        else:
            hw_classifications = []
            clock_cycles = []
            for outcome in outputs:
                for out in outcome:
                    probs = []
                    if self.model_specs['register_size'] == 16:
                        for i in range(0, self.n_output):
                            if self.benchcore == True and i == self.n_output - 1:
                                clock_cycles.append(out[i])
                            else:
                                binary_str = bin(out[i])[2:]
                                prob_float = self.__bin_to_float16(binary_str)
                                probs.append(prob_float)

                    elif self.model_specs['register_size'] == 32:
                        for i in range(0, self.n_output):
                            if self.benchcore == True and i == self.n_output - 1:
                                clock_cycles.append(out[i])
                            else:
                                binary_str = bin(out[i])[2:].zfill(32)
                                prob_float = self.__bin_to_float32(binary_str)

                                probs.append(prob_float)

                    
                    all_probs.append(probs)
                    classification = np.argmax(probs)
                    hw_classifications.append(int(classification))
            
            
            preds = hw_classifications

        

        return {'predictions': preds, 'clock_cycles': clock_cycles, 'all_probs': all_probs}
    def release(self):
        self.overlay.free()
        if getattr(self, "_flp_pool", None):
            self._flp_pool.shutdown()

    def predict(self, debug=False):

        latencies = []

        if self.model_specs['board'] in self.supported_boards['zynq']:
            outputs = []
            data_type_input, data_type_output = self.__get_dtype()

            input_buffer = allocate(shape=self.input_shape, dtype=data_type_input)

            for i in range(0, len(self.batches)):
                input_buffer[:]=self.batches[i]
                #print("input buffer: ", input_buffer)
                output_buffer = allocate(shape=self.output_shape, dtype=data_type_output)
                if debug:
                    start_time = time.time()
                #print("Before transfer")
                self.sendchannel.transfer(input_buffer)
                self.recvchannel.transfer(output_buffer)
                self.sendchannel.wait()
                self.recvchannel.wait()
                #print("After transfer")
                #print("output buffer: ", output_buffer)
                if debug:
                    end_time = time.time()
                    time_diff = (end_time - start_time) * 1000
                    latencies.append(time_diff)
                if len(self.batches) == 1:
                    outputs.append(output_buffer)
                else:
                    if self.fill == True and i == len(self.batches) - 1:
                        outputs.append(output_buffer[0:self.last_batch_size])
                    else:
                        outputs.append(output_buffer)

            if debug:
                print("Time taken to predict a batch of size ", self.batch_size, " is ", np.mean(latencies), " ms")
                print("Time taken to predict a single sample is ", np.mean(latencies)/self.batch_size, " ms")
        else:
            outputs = []
            data_type_input, data_type_output = self.__get_dtype()

            bm_krnl = self.overlay.krnl_bondmachine_rtl_1

            input_buffer = allocate(shape=self.input_shape, dtype=data_type_input)

            for i in range(0, len(self.batches)):
                input_buffer[:]=self.batches[i]
                output_buffer = allocate(shape=self.output_shape, dtype=data_type_output)
                input_buffer.sync_to_device()
                if debug:
                    start_time = time.time()
                bm_krnl.call(input_buffer, output_buffer)
                output_buffer.sync_from_device()
                if debug:
                    end_time = time.time()
                    time_diff = (end_time - start_time) * 1000
                    latencies.append(time_diff)

                if len(self.batches) == 1:
                    outputs.append(output_buffer)
                else:
                    if self.fill == True and i == len(self.batches) - 1:
                        outputs.append(output_buffer[0:self.last_batch_size])
                    else:
                        outputs.append(output_buffer)

            #print(outputs)
            if debug:
                print("Time taken to predict a batch of size ", self.batch_size, " is ", np.mean(latencies), " ms")
                print("Time taken to predict a single sample is ", np.mean(latencies)/self.batch_size, " ms")
                print("Standard deviation of the time taken to predict a batch of size ", self.batch_size, " is ", np.std(latencies), " ms")
                print("Standard deviation of the time taken to predict a single sample is ", np.std(latencies)/self.batch_size, " ms")
                
        result = self.__parse_prediction(outputs, debug)

        del input_buffer
        del output_buffer

        return result
            




