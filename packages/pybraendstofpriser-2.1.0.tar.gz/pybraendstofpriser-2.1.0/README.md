![Buy Me A Coffee](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)

## pybraendstofpriser

This is a PyPI module for fetching fuel prices from Fuelprices.dk API, primarily developed for use with [Home Assistant](https://home-assistant.io), but I try to keep it as widely usable as possible.

The API requires an API key to be used - see [https://fuelprices.dk](https://fuelprices.dk) for more information.