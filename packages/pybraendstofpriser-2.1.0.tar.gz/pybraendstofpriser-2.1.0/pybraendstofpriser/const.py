"""Constants for pybraendstofpriser."""

BIO_DIESEL = "bio_diesel"
DIESEL = "diesel"
DIESEL_PLUS = "diesel_plus"
OCTANE_92 = "octane_92"
OCTANE_95 = "octane_95"
OCTANE_100 = "octane_100"

API_TIMEOUT = 10  # seconds
API_ENDPOINT = "https://api.fuelprices.dk/v1"
