"""Tests for pybumpchart."""
