"""Shared constants used across pycen."""

# Census API geography specifications (for tabular data)
CENSUS_GEO_ALIASES = {
    'cbsa': 'metropolitan statistical area/micropolitan statistical area',
    'core based statistical area': 'metropolitan statistical area/micropolitan statistical area',
    'csa': 'combined statistical area',
    'zcta': 'zip code tabulation area',
    'puma': 'public use microdata area',
    'cbg': 'block group',
}

# GEOID component widths for standardization
GEOID_WIDTHS = {
    'state': 2,
    'county': 3,
    'tract': 6,
    'block group': 1,
    'block': 4,
}

HIERARCHICAL_GEOS = {'state', 'county', 'tract', 'block group', 'block'}

STATE_REQUIRED_GEOS = {
    'county', 'tract', 'block group', 'block', 'place', 'county subdivision',
    'puma', 'public use microdata area', 'congressional district',
}
COUNTY_REQUIRED_GEOS = {'tract', 'block group', 'block'}

PYGRIS_FUNCTIONS = {
    'nation',
    'divisions',
    'regions',
    'states',
    'counties',
    'tracts',
    'block_groups',
    'blocks',
    'places',
    'pumas',
    'school_districts',
    'zctas',
    'congressional_districts',
    'state_legislative_districts',
    'voting_districts',
    'area_water',
    'linear_water',
    'coastline',
    'core_based_statistical_areas',
    'combined_statistical_areas',
    'metro_divisions',
    'new_england',
    'county_subdivisions',
    'urban_areas',
    'primary_roads',
    'primary_secondary_roads',
    'roads',
    'rails',
    'native_areas',
    'alaska_native_regional_corporations',
    'tribal_block_groups',
    'tribal_census_tracts',
    'tribal_subdivisions_national',
    'landmarks',
    'military',
}

CONUS_STATES = {
    '01', '04', '05', '06', '08', '09', '10', '11', '12', '13',
    '16', '17', '18', '19', '20', '21', '22', '23', '24', '25',
    '26', '27', '28', '29', '30', '31', '32', '33', '34', '35',
    '36', '37', '38', '39', '40', '41', '42', '44', '45', '46',
    '47', '48', '49', '50', '51', '53', '54', '55', '56',
}

NONCONUS_STATES = {'02', '15', '60', '66', '69', '72', '78'}

BOUNDARY_GEO_ALIASES = {
    'us': 'nation',
    'region': 'regions',
    'division': 'divisions',
    'state': 'states',
    'county': 'counties',
    'tract': 'tracts',
    'block group': 'block_groups',
    'block': 'blocks',
    'place': 'places',
    'puma': 'pumas',
    'public use microdata area': 'pumas',
    'zcta': 'zctas',
    'zip code tabulation area': 'zctas',
    'cbsa': 'core_based_statistical_areas',
    'metropolitan statistical area/micropolitan statistical area': 'core_based_statistical_areas',
    'csa': 'combined_statistical_areas',
    'combined statistical area': 'combined_statistical_areas',
    'urban area': 'urban_areas',
    'congressional district': 'congressional_districts',
    'county subdivision': 'county_subdivisions',
    'school district (elementary)': 'school_districts',
    'school district (secondary)': 'school_districts',
    'school district (unified)': 'school_districts',
    'state legislative district': 'state_legislative_districts',
    'state legislative districts': 'state_legislative_districts',
    'voting district': 'voting_districts',
    'voting districts': 'voting_districts',
}
