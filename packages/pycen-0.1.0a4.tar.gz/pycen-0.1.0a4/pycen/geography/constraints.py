"""Geography constraints helper."""

import re

from pycen.constants import CENSUS_GEO_ALIASES, STATE_REQUIRED_GEOS, COUNTY_REQUIRED_GEOS
from pycen.geography.catalog import load_geography_catalog

def _normalize_geo_name(value):
    text = value.strip().lower()
    text = text.replace('›', '>')
    parts = [part.strip() for part in text.split('>')]
    if len(parts) > 1:
        return ' > '.join(parts)
    return re.sub(r'\s+', ' ', text)


def _build_catalog_index(geos):
    key_map = {}
    base_map = {}
    for geo in geos:
        key = _normalize_geo_name(geo)
        parts = key.split(' > ')
        base = parts[-1]
        required_in = parts[:-1]
        entry = {
            'key': key,
            'base': base,
            'required_in': required_in,
            'for_token': f"{base}:*",
        }
        key_map[key] = entry
        base_map.setdefault(base, []).append(entry)
    return key_map, base_map


def constraints(dataset, year, cache_dir='./pycen_cache', use_live=True, geography=None):
    '''Return geography constraints for a dataset/year.'''
    geos, source = load_geography_catalog(dataset, year, cache_dir=cache_dir, use_live=use_live)
    key_map, base_map = _build_catalog_index(geos)
    entries = []
    for entry in key_map.values():
        base = entry['base']
        required_in = entry['required_in']
        normalized = CENSUS_GEO_ALIASES.get(entry['key'], entry['key'])
        entries.append({
            'key': entry['key'],
            'normalized': normalized,
            'base': base,
            'required_in': required_in,
            'for_token': entry['for_token'],
            'state_required': 'state' in required_in or base in STATE_REQUIRED_GEOS,
            'county_required': 'county' in required_in or base in COUNTY_REQUIRED_GEOS,
        })
    order = {
        'block': 0,
        'block group': 1,
        'tract': 2,
        'county': 3,
        'state': 4,
        'region': 5,
        'division': 6,
        'us': 7,
    }
    entries = sorted(entries, key=lambda e: (order.get(e['base'], 100), e['key']))

    if geography:
        geo_norm = _normalize_geo_name(geography)
        geo_norm = CENSUS_GEO_ALIASES.get(geo_norm, geo_norm)
        entries = [
            e for e in entries
            if e['base'] == geo_norm or e['key'] == geo_norm or e['normalized'] == geo_norm
        ]
    return {
        'dataset': dataset,
        'year': year,
        'source': source,
        'geographies': entries,
    }
