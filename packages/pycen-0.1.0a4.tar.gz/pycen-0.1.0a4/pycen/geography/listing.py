"""Geography listing helpers."""

from pycen.geography.lookup import state as lookup_state

def _filter_names(gdf, query, name_cols):
    if not query:
        return gdf
    mask = False
    for col in name_cols:
        if col in gdf.columns:
            mask = mask | gdf[col].str.contains(query, case=False, na=False)
    return gdf[mask]

def _apply_limit_offset(gdf, limit, offset):
    if offset:
        gdf = gdf.iloc[int(offset):]
    if limit is not None:
        gdf = gdf.iloc[:int(limit)]
    return gdf

def _resolve_state_fips(state):
    if state is None:
        return None
    info = lookup_state(state)
    return info['fips']

def _list_geo(fetch_func, query, year, limit, offset, name_cols, cols, **kwargs):
    gdf = fetch_func(year=year, cb=True, **kwargs)
    gdf = _filter_names(gdf, query, name_cols)
    cols = [c for c in cols if c in gdf.columns]
    gdf = gdf[cols].sort_values(cols[0]) if cols else gdf
    return _apply_limit_offset(gdf, limit, offset)

def list_places(state, query=None, year=2020, limit=50, offset=0):
    '''List places for a state, optionally filtered by name.'''
    import pygris
    state_fips = _resolve_state_fips(state)
    return _list_geo(
        pygris.places,
        query,
        year,
        limit,
        offset,
        ['NAME', 'NAMELSAD'],
        ['NAME', 'NAMELSAD', 'GEOID', 'PLACEFP', 'STATEFP'],
        state=state_fips,
    )

def list_county_boundaries(state, query=None, year=2020, limit=50, offset=0):
    '''List county boundaries for a state, optionally filtered by name.'''
    import pygris
    state_fips = _resolve_state_fips(state)
    return _list_geo(
        pygris.counties,
        query,
        year,
        limit,
        offset,
        ['NAME'],
        ['NAME', 'GEOID', 'COUNTYFP', 'STATEFP'],
        state=state_fips,
    )

def list_counties(state, query=None, year=2020, limit=50, offset=0):
    '''Backward-compatible alias for list_county_boundaries.'''
    return list_county_boundaries(state, query=query, year=year, limit=limit, offset=offset)

def list_cbsa(query=None, year=2020, limit=50, offset=0):
    '''List CBSAs, optionally filtered by name.'''
    import pygris
    return _list_geo(
        pygris.core_based_statistical_areas,
        query,
        year,
        limit,
        offset,
        ['NAME'],
        ['NAME', 'GEOID', 'CBSAFP'],
    )

def list_csa(query=None, year=2020, limit=50, offset=0):
    '''List CSAs, optionally filtered by name.'''
    import pygris
    return _list_geo(
        pygris.combined_statistical_areas,
        query,
        year,
        limit,
        offset,
        ['NAME'],
        ['NAME', 'GEOID', 'CSAFP'],
    )

def list_zcta(query=None, year=2020, limit=50, offset=0):
    '''List ZCTAs, optionally filtered by name.'''
    import pygris
    return _list_geo(
        pygris.zctas,
        query,
        year,
        limit,
        offset,
        ['NAME'],
        ['NAME', 'GEOID', 'ZCTA5CE'],
    )
