'''Geography search by city name.'''

import csv
import io
import json
import gzip
import re
from pathlib import Path
from pprint import pprint
import requests

_SNAPSHOT = {}

def _fetch_live_snapshot(vintage):
    base = f'https://www2.census.gov/geo/docs/reference/codes{vintage}'
    place_url = f'{base}/national_place{vintage}.txt'
    pbc_url = f'{base}/national_place_by_county{vintage}.txt'

    def _get_text(url):
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        return resp.text

    place_text = _get_text(place_url)
    pbc_text = _get_text(pbc_url)

    places_by_state = {}
    reader = csv.DictReader(io.StringIO(place_text), delimiter='|')
    for row in reader:
        statefp = row.get('STATEFP')
        placefp = row.get('PLACEFP')
        name = row.get('PLACENAME')
        if not statefp or not placefp or not name:
            continue
        normalized = _normalize(name)
        places_by_state.setdefault(statefp, {}).setdefault(normalized, []).append([placefp, name])

    counties_by_place = {}
    reader = csv.DictReader(io.StringIO(pbc_text), delimiter='|')
    for row in reader:
        statefp = row.get('STATEFP')
        placefp = row.get('PLACEFP')
        countyfp = row.get('COUNTYFP')
        if not statefp or not placefp or not countyfp:
            continue
        counties_by_place.setdefault(statefp, {}).setdefault(placefp, []).append(countyfp)

    return {
        'vintage': vintage,
        'places_by_state': places_by_state,
        'counties_by_place': counties_by_place,
    }

def _load_snapshot(vintage=2020):
    '''Lazy load geography search snapshot.'''
    global _SNAPSHOT
    if vintage in _SNAPSHOT:
        return _SNAPSHOT[vintage]

    data_file = Path(__file__).parent.parent / 'data' / f'geo_search_{vintage}.json.gz'
    if data_file.exists():
        with gzip.open(data_file, 'rt', encoding='utf-8') as f:
            _SNAPSHOT[vintage] = json.load(f)
        return _SNAPSHOT[vintage]

    if vintage != 2020:
        try:
            _SNAPSHOT[vintage] = _fetch_live_snapshot(vintage)
            return _SNAPSHOT[vintage]
        except requests.RequestException:
            pass

    fallback = Path(__file__).parent.parent / 'data' / 'geo_search_2020.json.gz'
    if fallback.exists():
        with gzip.open(fallback, 'rt', encoding='utf-8') as f:
            _SNAPSHOT[vintage] = json.load(f)
        return _SNAPSHOT[vintage]

    raise FileNotFoundError(
        f'Geography search snapshot not found: {data_file}. '
        'Reinstall package with data files.'
    )

def _normalize(name):
    '''Normalize name for matching.'''
    name = name.lower().strip()
    name = re.sub(r'\s+(city|town|village|borough|cdp)$', '', name)
    name = re.sub(r'[^\w\s]', '', name)
    name = re.sub(r'\s+', ' ', name)
    return name

def search(city, state=None, vintage=2020, print_result=False):
    '''
    Search geography by city name.

    Parameters
    ----------
    city : str
    state : str, optional
    vintage : int, default 2020

    print_result : bool, default False
        If True, pretty-print the result.

    Returns
    -------
    dict
        {state, places, counties}
    '''
    data = _load_snapshot(vintage)

    state_info = None
    state_fips = None
    if state:
        from pycen.geography.lookup import state as lookup_state
        state_info = lookup_state(state)
        state_fips = state_info['fips']

    city_norm = _normalize(city)
    if state_fips == '11' and city_norm in {'dc', 'd c', 'district of columbia', 'washington dc', 'washington d c'}:
        city_norm = 'washington'
    places = []
    places_by_state = data['places_by_state']

    if state_fips:
        state_places = places_by_state.get(state_fips, {})
        if city_norm in state_places:
            for placefp, name in state_places[city_norm]:
                places.append({'fips': placefp, 'name': name, 'state_fips': state_fips})
    else:
        for sf, sp in places_by_state.items():
            if city_norm in sp:
                for placefp, name in sp[city_norm]:
                    places.append({'fips': placefp, 'name': name, 'state_fips': sf})

    if not places:
        msg = f'No place found: {city}'
        if state_info:
            msg += f' in {state_info["abbr"]}'
        print(msg)
        return {'state': state_info, 'places': [], 'counties': []}

    counties = []
    counties_by_place = data.get('counties_by_place', {})
    for place in places:
        sf, pf = place['state_fips'], place['fips']
        if sf in counties_by_place and pf in counties_by_place[sf]:
            for cf in counties_by_place[sf][pf]:
                try:
                    from pycen.geography.lookup import county as lookup_county
                    c_info = lookup_county(cf, state=sf)
                    counties.append({'fips': c_info['fips'], 'name': c_info['name'], 'state_fips': sf})
                except ValueError:
                    counties.append({'fips': cf, 'name': None, 'state_fips': sf})

    counties = list({(c['state_fips'], c['fips']): c for c in counties}.values())

    result = {
        'state': state_info,
        'places': places,
        'counties': counties
    }

    if print_result:
        pprint(result, sort_dicts=False)

    return result
