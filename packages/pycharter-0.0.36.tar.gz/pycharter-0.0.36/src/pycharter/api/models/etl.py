"""
Request/Response models for ETL run endpoint.
"""

from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class EtlRunRequest(BaseModel):
    """Request model for running an ETL pipeline from YAML configs."""

    extract_yaml: str = Field(..., description="Extract config as YAML string")
    load_yaml: str = Field(..., description="Load config as YAML string")
    transform_yaml: Optional[str] = Field(
        default=None,
        description="Optional transform config as YAML string",
    )
    variables: Optional[Dict[str, str]] = Field(
        default=None,
        description="Optional variables for ${VAR} substitution in configs",
    )
    dry_run: bool = Field(
        default=False,
        description="If True, extract and transform but do not load",
    )


class EtlRunResponse(BaseModel):
    """Response model for ETL pipeline run result (mirrors PipelineResult.to_dict())."""

    success: bool = Field(..., description="Whether the pipeline run succeeded")
    rows_extracted: int = Field(0, description="Number of rows extracted")
    rows_transformed: int = Field(0, description="Number of rows transformed")
    rows_loaded: int = Field(0, description="Number of rows loaded")
    rows_failed: int = Field(0, description="Number of rows that failed to load")
    # Validation tracking
    rows_quarantined_extract: int = Field(
        0,
        description="Number of rows quarantined at extract stage due to validation",
    )
    rows_quarantined_load: int = Field(
        0,
        description="Number of rows quarantined at load stage due to validation",
    )
    total_quarantined: int = Field(
        0,
        description="Total rows quarantined at both stages",
    )
    validation_errors_extract: List[str] = Field(
        default_factory=list,
        description="Validation error messages from extract stage",
    )
    validation_errors_load: List[str] = Field(
        default_factory=list,
        description="Validation error messages from load stage",
    )
    # Timing and metadata
    duration_seconds: Optional[float] = Field(
        None,
        description="Total run duration in seconds",
    )
    batches_processed: int = Field(0, description="Number of batches processed")
    errors: List[str] = Field(default_factory=list, description="Error messages if any")
    pipeline_name: Optional[str] = Field(None, description="Pipeline name if set")
    run_id: Optional[str] = Field(None, description="Run identifier")
