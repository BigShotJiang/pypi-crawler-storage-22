"""
Route handlers for ETL pipeline execution.

Allows running an ETL pipeline from YAML config strings (extract, transform, load).
"""

import logging
from typing import Any, Dict, List, Union

import yaml
from fastapi import APIRouter, HTTPException, status

from pycharter import Pipeline
from pycharter.api.models.etl import EtlRunRequest, EtlRunResponse

logger = logging.getLogger(__name__)

router = APIRouter()


def _parse_yaml_config(
    yaml_str: str, field_name: str
) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
    """
    Parse a YAML string into a dict or list of dicts.
    Empty or whitespace-only string returns {}.
    Raises HTTPException 400 on parse error or invalid type.
    """
    if not yaml_str or not yaml_str.strip():
        return {}
    try:
        parsed = yaml.safe_load(yaml_str)
    except yaml.YAMLError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid YAML in {field_name}: {str(e)}",
        )
    if parsed is None:
        return {}
    if isinstance(parsed, dict):
        return parsed
    if isinstance(parsed, list):
        if all(isinstance(item, dict) for item in parsed):
            return parsed
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"{field_name} must be a YAML object or list of objects",
        )
    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail=f"{field_name} must be a YAML object or list of objects, got {type(parsed).__name__}",
    )


@router.post(
    "/etl/run",
    response_model=EtlRunResponse,
    status_code=status.HTTP_200_OK,
    summary="Run ETL pipeline",
    description="Run an ETL pipeline from extract, transform, and load YAML config strings. Optional variables are applied for ${VAR} substitution. Use dry_run=True to extract and transform without loading.",
    response_description="Pipeline run result with row counts and any errors",
    tags=["ETL"],
)
async def run_etl_pipeline(request: EtlRunRequest) -> EtlRunResponse:
    """
    Run an ETL pipeline from the provided YAML configs.

    Parses extract_yaml, load_yaml, and optional transform_yaml; builds a pipeline
    via Pipeline.from_dict() (so variable substitution is applied), runs it, and
    returns the result (row counts, success, errors).
    """
    # Parse YAML configs
    extract_dict = _parse_yaml_config(request.extract_yaml, "extract")
    load_dict = _parse_yaml_config(request.load_yaml, "load")
    transform_raw = _parse_yaml_config(request.transform_yaml or "", "transform")

    if not isinstance(extract_dict, dict) or not extract_dict:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Extract config is required and must be a non-empty YAML object",
        )
    if not isinstance(load_dict, dict) or not load_dict:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Load config is required and must be a non-empty YAML object",
        )

    # Build config for Pipeline.from_dict
    # The transform YAML can contain: transform (simple ops), jsonata, custom_function
    # We pass the full parsed dict to from_dict which will extract these
    config: Dict[str, Any] = {
        "extract": extract_dict,
        "load": load_dict,
    }

    # If transform_raw is a dict, include its keys in config (transform, jsonata, custom_function)
    if isinstance(transform_raw, dict):
        if "transform" in transform_raw:
            config["transform"] = transform_raw["transform"]
        if "jsonata" in transform_raw:
            config["jsonata"] = transform_raw["jsonata"]
        if "custom_function" in transform_raw:
            config["custom_function"] = transform_raw["custom_function"]
    elif isinstance(transform_raw, list):
        # If it's a list, treat it as transform steps
        config["transform"] = transform_raw

    variables = request.variables or {}

    try:
        pipeline = Pipeline.from_dict(config, variables=variables)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        logger.exception("Pipeline build failed")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Pipeline config invalid: {str(e)}",
        )

    try:
        result = await pipeline.run(dry_run=request.dry_run)
    except Exception as e:
        logger.exception("Pipeline run failed")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
        )

    return EtlRunResponse(**result.to_dict())
