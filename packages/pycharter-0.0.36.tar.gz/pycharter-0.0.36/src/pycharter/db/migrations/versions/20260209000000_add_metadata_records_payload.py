"""Add payload column to metadata_records for flexible metadata document storage

Revision ID: add_metadata_payload
Revises: change_artifact_uniq_constraints
Create Date: 2026-02-09 00:00:00.000000

Stores the full metadata document (new template shape: ownership, lineage,
lifecycle, serve, etc.) as JSON. Enables metadata to evolve without schema
migrations; indexed columns (title, version, status, etc.) remain for querying.
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "add_metadata_payload"
down_revision: Union[str, None] = "change_artifact_uniq_constraints"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    bind = op.get_bind()
    schema_name = None if bind.dialect.name == "sqlite" else "pycharter"
    table = "metadata_records"
    col = sa.Column("payload", sa.JSON(), nullable=True)
    op.add_column(table, col, schema=schema_name)


def downgrade() -> None:
    bind = op.get_bind()
    schema_name = None if bind.dialect.name == "sqlite" else "pycharter"
    op.drop_column("metadata_records", "payload", schema=schema_name)
