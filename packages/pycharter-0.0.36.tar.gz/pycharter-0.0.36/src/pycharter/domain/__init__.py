"""
Domain entity lifecycle binding (engine-agnostic).

Domain entity contracts may declare an optional lifecycle in metadata.lifecycle
(root) or metadata.governance_rules.lifecycle, specifying which state machine
governs the entity (e.g. order_management, intraday_signal_lifecycle). PyCharter
does not depend on any FSM engine; consumers (e.g. trading apps using PyStator)
read this convention and call their engine with the given machine name, version,
and entity/state field mapping.
"""

from __future__ import annotations

from typing import Any

DEFAULT_STATE_FIELD = "status"


def _get_lifecycle_dict(metadata: dict[str, Any]) -> dict[str, Any] | None:
    """Resolve lifecycle from root metadata.lifecycle or governance_rules.lifecycle."""
    if not metadata or not isinstance(metadata, dict):
        return None
    lifecycle = metadata.get("lifecycle")
    if (
        lifecycle
        and isinstance(lifecycle, dict)
        and lifecycle.get("state_machine_name")
    ):
        return dict(lifecycle)
    gov = metadata.get("governance_rules")
    if not gov or not isinstance(gov, dict):
        return None
    lifecycle = gov.get("lifecycle")
    if not lifecycle or not isinstance(lifecycle, dict):
        return None
    if not lifecycle.get("state_machine_name"):
        return None
    return dict(lifecycle)


def get_lifecycle_binding(metadata: dict[str, Any]) -> dict[str, Any] | None:
    """Read lifecycle binding from metadata (root lifecycle or governance_rules.lifecycle).

    Returns the full lifecycle dict if it exists and contains at least state_machine_name;
    otherwise returns None. Keys may include state_machine_name, machine_version,
    state_field, entity_id_field (for precise integration with FSM engines like PyStator).

    Args:
        metadata: Metadata dict (e.g. from a contract or metadata record),
            with optional "lifecycle" at root or under "governance_rules".

    Returns:
        Lifecycle binding dict (e.g. state_machine_name, machine_version, state_field,
        entity_id_field), or None if not present or invalid.

    Example:
        >>> meta = {"governance_rules": {"lifecycle": {"state_machine_name": "order_management"}}}
        >>> get_lifecycle_binding(meta)
        {'state_machine_name': 'order_management'}
    """
    return _get_lifecycle_dict(metadata)


def get_domain_entity_info(contract_dict: dict[str, Any]) -> dict[str, Any] | None:
    """Extract domain entity info (schema + lifecycle) from a full contract dict.

    Given a contract structure with optional "metadata" and "schema" (or raw schema
    at top level), returns a dict with state_machine_name, state_field, and
    optionally machine_version and entity_id_field for entities that have a
    lifecycle binding. Use this when calling an FSM engine (e.g. PyStator):
    entity_id = record[info["entity_id_field"]], machine_version for API pinning.

    Args:
        contract_dict: Full contract dict (e.g. from store or build_contract),
            possibly with keys like metadata, schema, coercion_rules, validation_rules.

    Returns:
        Dict with state_machine_name, state_field (default "status"), and when
        present in metadata: machine_version, entity_id_field. None if no binding.

    Example:
        >>> c = {"metadata": {"governance_rules": {"lifecycle": {"state_machine_name": "order_management"}}}}
        >>> get_domain_entity_info(c)
        {'state_machine_name': 'order_management', 'state_field': 'status'}
    """
    if not contract_dict or not isinstance(contract_dict, dict):
        return None
    metadata = contract_dict.get("metadata")
    if not metadata and "governance_rules" in contract_dict:
        metadata = contract_dict
    binding = get_lifecycle_binding(metadata) if metadata else None
    if not binding:
        return None
    out: dict[str, Any] = {
        "state_machine_name": binding["state_machine_name"],
        "state_field": binding.get("state_field") or DEFAULT_STATE_FIELD,
    }
    if binding.get("machine_version") is not None:
        out["machine_version"] = binding["machine_version"]
    if binding.get("entity_id_field"):
        out["entity_id_field"] = binding["entity_id_field"]
    return out


__all__ = [
    "DEFAULT_STATE_FIELD",
    "get_lifecycle_binding",
    "get_domain_entity_info",
]
