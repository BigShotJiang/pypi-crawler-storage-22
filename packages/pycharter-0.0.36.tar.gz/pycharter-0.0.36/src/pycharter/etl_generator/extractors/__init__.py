"""
Extractors module for ETL orchestrator.

This module provides a modular architecture for data extraction from various sources:
- HTTP/API extraction
- File-based extraction (CSV, JSON, Parquet, Excel, TSV, XML)
- Database extraction (PostgreSQL, MySQL, SQLite, MSSQL, Oracle)
- MongoDB extraction (queries and aggregation pipelines)
- Cloud storage extraction (S3, GCS, Azure Blob)

Entry point for orchestration: extract_with_pagination_streaming().
"""

from pycharter.etl_generator.extractors.base import BaseExtractor
from pycharter.etl_generator.extractors.cloud_storage import CloudStorageExtractor
from pycharter.etl_generator.extractors.database import DatabaseExtractor
from pycharter.etl_generator.extractors.factory import ExtractorFactory
from pycharter.etl_generator.extractors.file import FileExtractor
from pycharter.etl_generator.extractors.http import HTTPExtractor, get_path_param_names
from pycharter.etl_generator.extractors.streaming import (
    extract_with_pagination_streaming,
)

__all__ = [
    "BaseExtractor",
    "ExtractorFactory",
    "HTTPExtractor",
    "FileExtractor",
    "DatabaseExtractor",
    "MongoDBExtractor",
    "CloudStorageExtractor",
    "extract_with_pagination_streaming",
    "get_path_param_names",
]


def __getattr__(name: str):
    """Lazy-load MongoDBExtractor (requires pymongo) on first access."""
    if name == "MongoDBExtractor":
        from pycharter.etl_generator.extractors.mongodb import MongoDBExtractor

        return MongoDBExtractor
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
