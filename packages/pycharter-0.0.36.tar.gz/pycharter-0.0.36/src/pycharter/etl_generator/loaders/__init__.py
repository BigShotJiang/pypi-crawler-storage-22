"""
Load (destination) backends for ETL pipelines.

Two APIs:
1. Class-based: PostgresLoader(...).load(data) - for programmatic use
2. Function-based: load_to_file(data, config) - for config-driven use

Supports:
- Database (PostgreSQL, MySQL, SQLite, MSSQL)
- MongoDB (insert, upsert, replace, update, delete)
- File (local JSON, CSV, Parquet, JSONL)
- Cloud storage (AWS S3, Google Cloud Storage, Azure Blob)
"""

# Base class
from pycharter.etl_generator.loaders.base import BaseLoader

# Cloud storage loaders (class and function APIs)
from pycharter.etl_generator.loaders.cloud_storage import (
    CloudStorageLoader,
    load_to_cloud_storage,
)

# Database loaders
from pycharter.etl_generator.loaders.database import DatabaseLoader, PostgresLoader

# Factory
from pycharter.etl_generator.loaders.factory import LoaderFactory

# File loaders (class and function APIs)
from pycharter.etl_generator.loaders.file import FileLoader, load_to_file

__all__ = [
    # Base class
    "BaseLoader",
    # Factory
    "LoaderFactory",
    # Class-based loaders
    "PostgresLoader",
    "DatabaseLoader",
    "MongoDBLoader",
    "FileLoader",
    "CloudStorageLoader",
    # Function-based loaders
    "load_to_file",
    "load_to_cloud_storage",
]


def __getattr__(name: str):
    """Lazy-load MongoDBLoader (requires pymongo) on first access."""
    if name == "MongoDBLoader":
        from pycharter.etl_generator.loaders.mongodb import MongoDBLoader

        return MongoDBLoader
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
