"""
Pipeline class with | operator for chaining.

Supports both config-driven and programmatic pipeline construction.
Includes optional validation at extract (source) and load (target) stages.
"""

import logging
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import yaml

from pycharter.etl_generator.context import VARIABLE_PATTERN, PipelineContext
from pycharter.etl_generator.protocols import Extractor, Loader, Transformer
from pycharter.etl_generator.result import BatchResult, PipelineResult
from pycharter.shared.errors import ErrorContext, ErrorMode, get_error_context

logger = logging.getLogger(__name__)


class Pipeline:
    """
    ETL Pipeline with | operator for chaining transformers.

    Programmatic usage:
        >>> pipeline = (
        ...     Pipeline(HTTPExtractor(url="..."))
        ...     | Rename({"old": "new"})
        ...     | PostgresLoader(...)
        ... )
        >>> result = await pipeline.run()

    Config-driven usage:
        >>> # From explicit files (most flexible)
        >>> pipeline = Pipeline.from_config_files(
        ...     extract="configs/extract.yaml",
        ...     load="configs/load.yaml",
        ...     variables={"API_KEY": "secret"}
        ... )
        >>>
        >>> # From directory (expects extract.yaml, transform.yaml, load.yaml)
        >>> pipeline = Pipeline.from_config_dir("pipelines/users/")
        >>>
        >>> # From single file (pipeline.yaml with all sections)
        >>> pipeline = Pipeline.from_config_file("pipelines/users/pipeline.yaml")
        >>>
        >>> result = await pipeline.run()

    Async execution:
        run() is async. From a script use asyncio.run():
            asyncio.run(pipeline.run())
        From an async context (FastAPI, Jupyter) await directly:
            result = await pipeline.run()
        See pycharter/etl_generator/ASYNC_AND_EXECUTION.md for details.
    """

    def __init__(
        self,
        extractor: Optional[Extractor] = None,
        transformers: Optional[List[Transformer]] = None,
        loader: Optional[Loader] = None,
        context: Optional[PipelineContext] = None,
        name: Optional[str] = None,
        transform_config: Optional[Union[Dict[str, Any], List[Dict[str, Any]]]] = None,
        # Validation configs
        extract_validation_config: Optional[Dict[str, Any]] = None,
        load_validation_config: Optional[Dict[str, Any]] = None,
        # Shared settings
        settings: Optional[Dict[str, Any]] = None,
        # Base directory for resolving relative paths
        base_dir: Optional[Path] = None,
    ):
        self.extractor = extractor
        self._transformers: List[Transformer] = (
            list(transformers) if transformers else []
        )
        self.loader = loader
        self.context = context or PipelineContext()
        self.name = name
        # For config-driven runs, store raw transform config and use apply_transforms
        self._transform_config = transform_config
        # Validation configs
        self._extract_validation_config = extract_validation_config
        self._load_validation_config = load_validation_config
        # Shared settings from settings.yaml
        self._settings = settings or {}
        # Base directory for resolving file paths
        self._base_dir = base_dir
        # Run ID (set during run())
        self._run_id: Optional[str] = None

    def __or__(self, other: Union[Transformer, Loader]) -> "Pipeline":
        """Chain transformer or set loader using | operator."""
        if isinstance(other, Loader):
            return Pipeline(
                extractor=self.extractor,
                transformers=self._transformers.copy(),
                loader=other,
                context=self.context,
                name=self.name,
                extract_validation_config=self._extract_validation_config,
                load_validation_config=self._load_validation_config,
                settings=self._settings,
                base_dir=self._base_dir,
            )
        else:
            new_transformers = self._transformers.copy()
            new_transformers.append(other)
            return Pipeline(
                extractor=self.extractor,
                transformers=new_transformers,
                loader=self.loader,
                context=self.context,
                name=self.name,
                extract_validation_config=self._extract_validation_config,
                load_validation_config=self._load_validation_config,
                settings=self._settings,
                base_dir=self._base_dir,
            )

    async def run(
        self,
        dry_run: bool = False,
        error_context: Optional[ErrorContext] = None,
        **params,
    ) -> PipelineResult:
        """
        Run the ETL pipeline.

        Args:
            dry_run: If True, extract and transform but do not load.
            error_context: Optional error context for handling failures.
                If not set, uses the default from get_error_context().
                In STRICT mode, extraction or load failures raise.
                In LENIENT/COLLECT mode, errors are logged and appended to result.errors.
            **params: Passed to extractor.extract() and loader.load().

        Returns:
            PipelineResult with counts and any errors.
        """
        run_id = str(uuid.uuid4())[:8]
        self._run_id = run_id
        start_time = datetime.now(timezone.utc)
        ctx = error_context or get_error_context()

        result = PipelineResult(
            pipeline_name=self.name,
            run_id=run_id,
            start_time=start_time,
        )

        if not self.extractor:
            result.success = False
            result.errors.append("No extractor configured")
            return result

        logger.info(f"[{run_id}] Starting pipeline: {self.name or 'unnamed'}")

        # Create validators if configured
        extract_validator = self._create_extract_validator()
        load_validator = self._create_load_validator()

        try:
            batch_index = 0
            async for batch in self.extractor.extract(**params):
                batch_result = BatchResult(batch_index=batch_index, rows_in=len(batch))
                result.rows_extracted += len(batch)

                # Source validation (after extract)
                if extract_validator:
                    try:
                        batch, quarantined, error_count = (
                            await extract_validator.validate(batch, run_id=run_id)
                        )
                        result.rows_quarantined_extract += len(quarantined)
                        if error_count > 0:
                            batch_result.errors.append(
                                f"Extract validation: {error_count} record(s) invalid"
                            )
                    except Exception as e:
                        # Validation error with on_error=fail
                        ctx.handle_error(str(e), e, category="extract_validation")
                        batch_result.errors.append(f"Extract validation failed: {e}")
                        result.success = False
                        result.errors.append(str(e))
                        break

                # Transform
                transformed = self._apply_transforms(batch)
                batch_result.rows_out = len(transformed)
                result.rows_transformed += len(transformed)

                # Target validation (before load)
                if load_validator and transformed:
                    try:
                        transformed, quarantined, error_count = (
                            await load_validator.validate(transformed, run_id=run_id)
                        )
                        result.rows_quarantined_load += len(quarantined)
                        if error_count > 0:
                            batch_result.errors.append(
                                f"Load validation: {error_count} record(s) invalid"
                            )
                    except Exception as e:
                        # Validation error with on_error=fail
                        ctx.handle_error(str(e), e, category="load_validation")
                        batch_result.errors.append(f"Load validation failed: {e}")
                        result.success = False
                        result.errors.append(str(e))
                        break

                # Load
                if not dry_run and self.loader and transformed:
                    try:
                        load_result = await self.loader.load(transformed, **params)
                        if load_result.success:
                            result.rows_loaded += load_result.rows_loaded
                        else:
                            msg = load_result.error or "Load failed"
                            ctx.handle_error(msg, category="load")
                            batch_result.errors.append(msg)
                            batch_result.rows_failed += len(transformed)
                    except Exception as e:
                        ctx.handle_error(str(e), e, category="load")
                        batch_result.errors.append(str(e))
                        batch_result.rows_failed += len(transformed)
                elif dry_run:
                    result.rows_loaded += len(transformed)

                result.batches_processed += 1
                result.batch_results.append(batch_result)
                batch_index += 1

        except Exception as e:
            result.success = False
            result.errors.append(str(e))
            ctx.handle_error(str(e), e, category="pipeline")
            logger.error(f"[{run_id}] Pipeline error: {e}")

        result.end_time = datetime.now(timezone.utc)
        result.duration_seconds = (result.end_time - start_time).total_seconds()
        result.rows_failed = sum(br.rows_failed for br in result.batch_results)

        if result.errors:
            result.success = False

        logger.info(
            f"[{run_id}] Complete: extracted={result.rows_extracted}, "
            f"loaded={result.rows_loaded}, "
            f"quarantined_extract={result.rows_quarantined_extract}, "
            f"quarantined_load={result.rows_quarantined_load}"
        )
        return result

    def _create_extract_validator(self):
        """Create extract validator if configured."""
        if not self._extract_validation_config:
            return None

        from pycharter.etl_generator.config_models import DLQConfig
        from pycharter.etl_generator.validation import create_etl_validator

        # Get default DLQ config from settings
        default_dlq = None
        if self._settings.get("dlq"):
            default_dlq = DLQConfig(**self._settings["dlq"])

        return create_etl_validator(
            validation_config=self._extract_validation_config,
            pipeline_name=self.name or "unnamed",
            stage="extract",
            metadata_store=None,  # Extract uses local schema, not store
            default_contract=None,
            default_dlq_config=default_dlq,
            base_dir=self._base_dir,
        )

    def _create_load_validator(self):
        """Create load validator if configured."""
        if not self._load_validation_config:
            return None

        from pycharter.etl_generator.config_models import DLQConfig
        from pycharter.etl_generator.validation import create_etl_validator
        from pycharter.metadata_store import MetadataStoreClient

        # Get default DLQ config from settings
        default_dlq = None
        if self._settings.get("dlq"):
            default_dlq = DLQConfig(**self._settings["dlq"])

        # Get default contract from settings
        default_contract = self._settings.get("contract")

        # Create metadata store if configured
        metadata_store = None
        if self._settings.get("metadata_store"):
            metadata_store = self._create_metadata_store()

        return create_etl_validator(
            validation_config=self._load_validation_config,
            pipeline_name=self.name or "unnamed",
            stage="load",
            metadata_store=metadata_store,
            default_contract=default_contract,
            default_dlq_config=default_dlq,
            base_dir=self._base_dir,
        )

    def _create_metadata_store(self) -> Optional["MetadataStoreClient"]:
        """Create metadata store from settings."""
        store_config = self._settings.get("metadata_store")
        if not store_config:
            return None

        store_type = store_config.get("type", "").lower()
        connection_string = store_config.get("connection_string")

        if not connection_string:
            logger.warning("metadata_store missing connection_string")
            return None

        if store_type == "postgres":
            from pycharter.metadata_store import PostgresMetadataStore

            return PostgresMetadataStore(connection_string)
        elif store_type == "sqlite":
            from pycharter.metadata_store import SQLiteMetadataStore

            return SQLiteMetadataStore(connection_string)
        elif store_type == "mongodb":
            from pycharter.metadata_store import MongoDBMetadataStore

            return MongoDBMetadataStore(connection_string)
        elif store_type == "redis":
            from pycharter.metadata_store import RedisMetadataStore

            return RedisMetadataStore(connection_string)
        elif store_type == "memory":
            from pycharter.metadata_store import InMemoryMetadataStore

            return InMemoryMetadataStore()
        else:
            logger.warning(f"Unknown metadata_store type: {store_type}")
            return None

    def _apply_transforms(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Apply all transformers to data.

        For config-driven pipelines (when _transform_config is set), uses the unified
        apply_transforms() which supports simple_ops, jsonata, and custom_function.
        For programmatic pipelines (when _transformers is set), loops through the
        transformer chain.
        """
        # Config-driven path: use unified apply_transforms (supports jsonata, etc.)
        if self._transform_config:
            from pycharter.etl_generator.transformers import apply_transforms

            return apply_transforms(data, self._transform_config)

        # Programmatic path: loop through transformer instances
        result = data
        for transformer in self._transformers:
            result = transformer.transform(result)
        return result

    # =========================================================================
    # CONFIG-DRIVEN FACTORY METHODS
    # =========================================================================

    @classmethod
    def from_config_files(
        cls,
        extract: Union[str, Path, Dict[str, Any]],
        load: Union[str, Path, Dict[str, Any]],
        transform: Optional[
            Union[str, Path, Dict[str, Any], List[Dict[str, Any]]]
        ] = None,
        variables: Optional[Dict[str, str]] = None,
        validate: bool = True,
        name: Optional[str] = None,
    ) -> "Pipeline":
        """
        Create pipeline from explicit file paths or dictionaries.

        This is the most flexible method - use any file paths without any
        assumptions about directory structure or file naming.

        Args:
            extract: Path to extract config file OR config as dict
            load: Path to load config file OR config as dict
            transform: Optional path to transform config OR config as dict/list
            variables: Variables for ${VAR} substitution in config values
            validate: If True, validate configs against schemas
            name: Optional pipeline name

        Returns:
            Configured Pipeline instance

        Example:
            pipeline = Pipeline.from_config_files(
                extract="configs/my_http_source.yaml",
                transform="configs/my_transforms.yaml",
                load="configs/my_postgres_sink.yaml",
                variables={"API_KEY": "secret", "DB_URL": "postgresql://..."}
            )
        """
        variables = variables or {}

        # Load configs
        extract_config = _load_config_input(extract, variables)
        load_config = _load_config_input(load, variables)

        if transform is not None:
            transform_config = _load_config_input(transform, variables)
        else:
            transform_config = {}

        return cls._build_from_configs(
            extract_config=extract_config,
            transform_config=transform_config,
            load_config=load_config,
            variables=variables,
            validate=validate,
            name=name,
        )

    @classmethod
    def from_config_dir(
        cls,
        directory: Union[str, Path],
        variables: Optional[Dict[str, str]] = None,
        validate: bool = True,
        name: Optional[str] = None,
    ) -> "Pipeline":
        """
        Create pipeline from a directory containing config files.

        Expects files with standard names:
        - extract.yaml (required)
        - transform.yaml (optional)
        - load.yaml (required)
        - settings.yaml (optional, for shared config like DLQ, metadata store)

        Args:
            directory: Path to directory containing config files
            variables: Variables for ${VAR} substitution
            validate: If True, validate configs against schemas
            name: Optional pipeline name (defaults to directory name)

        Returns:
            Configured Pipeline instance

        Example:
            pipeline = Pipeline.from_config_dir(
                "pipelines/users/",
                variables={"DATA_DIR": "./data", "OUTPUT_DIR": "./output"}
            )
        """
        directory = Path(directory)
        if not directory.is_dir():
            raise NotADirectoryError(f"Not a directory: {directory}")

        variables = variables or {}

        # Check for required files
        extract_file = directory / "extract.yaml"
        load_file = directory / "load.yaml"
        transform_file = directory / "transform.yaml"
        settings_file = directory / "settings.yaml"

        if not extract_file.exists():
            raise FileNotFoundError(f"Required file not found: {extract_file}")
        if not load_file.exists():
            raise FileNotFoundError(f"Required file not found: {load_file}")

        # Load configs
        extract_config = _load_config_input(extract_file, variables)
        load_config = _load_config_input(load_file, variables)
        transform_config = (
            _load_config_input(transform_file, variables)
            if transform_file.exists()
            else {}
        )
        settings_config = (
            _load_config_input(settings_file, variables)
            if settings_file.exists()
            else {}
        )

        # Extract validation configs from extract/load
        extract_validation_config = (
            extract_config.pop("validation", None)
            if isinstance(extract_config, dict)
            else None
        )
        load_validation_config = (
            load_config.pop("validation", None)
            if isinstance(load_config, dict)
            else None
        )

        return cls._build_from_configs(
            extract_config=extract_config,
            transform_config=transform_config,
            load_config=load_config,
            variables=variables,
            validate=validate,
            name=name or directory.name,
            extract_validation_config=extract_validation_config,
            load_validation_config=load_validation_config,
            settings=settings_config if isinstance(settings_config, dict) else {},
            base_dir=directory.resolve(),
        )

    @classmethod
    def from_config_file(
        cls,
        path: Union[str, Path],
        variables: Optional[Dict[str, str]] = None,
        validate: bool = True,
    ) -> "Pipeline":
        """
        Create pipeline from a single config file containing all sections.

        The file should have extract, transform (optional), and load sections:

            name: my_pipeline
            extract:
              type: http
              url: https://api.example.com
              validation:  # optional
                schema: ./source_schema.yaml
                on_error: quarantine
            transform:
              - rename: {old: new}
            load:
              type: file
              path: output.json
              validation:  # optional
                contract: ./contracts/orders
                on_error: fail
            # Optional shared settings
            metadata_store:
              type: postgres
              connection_string: ...
            dlq:
              enabled: true
              backend: file
              path: ./dlq

        Args:
            path: Path to pipeline config file (YAML)
            variables: Variables for ${VAR} substitution
            validate: If True, validate config against schema

        Returns:
            Configured Pipeline instance

        Example:
            pipeline = Pipeline.from_config_file(
                "pipelines/users/pipeline.yaml",
                variables={"API_KEY": "secret"}
            )
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")
        if not path.is_file():
            raise ValueError(
                f"Not a file: {path}. Use from_config_dir() for directories."
            )

        variables = variables or {}

        # Load the full config
        config = _load_config_input(path, variables)

        if "extract" not in config:
            raise ValueError(f"Config file missing 'extract' section: {path}")
        if "load" not in config:
            raise ValueError(f"Config file missing 'load' section: {path}")

        # Extract validation configs
        extract_config = config["extract"]
        load_config = config["load"]
        extract_validation_config = (
            extract_config.pop("validation", None)
            if isinstance(extract_config, dict)
            else None
        )
        load_validation_config = (
            load_config.pop("validation", None)
            if isinstance(load_config, dict)
            else None
        )

        # Build inline settings from top-level keys
        settings: Dict[str, Any] = {}
        if config.get("metadata_store"):
            settings["metadata_store"] = config["metadata_store"]
        if config.get("dlq"):
            settings["dlq"] = config["dlq"]
        if config.get("contract"):
            settings["contract"] = config["contract"]

        return cls._build_from_configs(
            extract_config=extract_config,
            transform_config=config.get("transform", {}),
            load_config=load_config,
            variables=variables,
            validate=validate,
            name=config.get("name"),
            extract_validation_config=extract_validation_config,
            load_validation_config=load_validation_config,
            settings=settings,
            base_dir=path.parent.resolve(),
        )

    @classmethod
    def from_dict(
        cls,
        config: Dict[str, Any],
        variables: Optional[Dict[str, str]] = None,
        validate: bool = True,
        base_dir: Optional[Path] = None,
    ) -> "Pipeline":
        """
        Create pipeline from a configuration dictionary.

        Args:
            config: Dict with 'extract', 'transform' (optional), 'load' sections
            variables: Variables for ${VAR} substitution
            validate: If True, validate config against schema
            base_dir: Base directory for resolving relative file paths

        Returns:
            Configured Pipeline instance

        Example:
            pipeline = Pipeline.from_dict({
                "name": "my_pipeline",
                "extract": {"type": "http", "url": "https://api.example.com"},
                "transform": [{"rename": {"userId": "user_id"}}],
                "load": {"type": "file", "path": "${OUTPUT_DIR}/result.json"}
            }, variables={"OUTPUT_DIR": "./output"})
        """
        if "extract" not in config:
            raise ValueError("Config dict missing 'extract' section")
        if "load" not in config:
            raise ValueError("Config dict missing 'load' section")

        variables = variables or {}
        context = PipelineContext(variables=variables)

        # Resolve variables in config
        extract_config = context.resolve_dict(config["extract"])
        load_config = context.resolve_dict(config["load"])

        # Extract validation configs
        extract_validation_config = (
            extract_config.pop("validation", None)
            if isinstance(extract_config, dict)
            else None
        )
        load_validation_config = (
            load_config.pop("validation", None)
            if isinstance(load_config, dict)
            else None
        )

        # Build transform config - include transform, jsonata, and custom_function
        # This allows top-level jsonata/custom_function in config (common in yaml files)
        transform_config: Dict[str, Any] = {}
        raw_transform = config.get("transform", {})
        if isinstance(raw_transform, list):
            transform_config["transform"] = [
                context.resolve_dict(item) if isinstance(item, dict) else item
                for item in raw_transform
            ]
        elif raw_transform:
            transform_config["transform"] = context.resolve_dict(raw_transform)

        # Include top-level jsonata if present
        if config.get("jsonata"):
            transform_config["jsonata"] = context.resolve_dict(config["jsonata"])

        # Include top-level custom_function if present
        if config.get("custom_function"):
            transform_config["custom_function"] = context.resolve_dict(
                config["custom_function"]
            )

        # Build inline settings from top-level keys
        settings: Dict[str, Any] = {}
        if config.get("metadata_store"):
            settings["metadata_store"] = context.resolve_dict(config["metadata_store"])
        if config.get("dlq"):
            settings["dlq"] = context.resolve_dict(config["dlq"])
        if config.get("contract"):
            settings["contract"] = config["contract"]

        return cls._build_from_configs(
            extract_config=extract_config,
            transform_config=transform_config,
            load_config=load_config,
            variables=variables,
            validate=validate,
            name=config.get("name"),
            extract_validation_config=extract_validation_config,
            load_validation_config=load_validation_config,
            settings=settings,
            base_dir=base_dir,
        )

    @classmethod
    def _build_from_configs(
        cls,
        extract_config: Dict[str, Any],
        transform_config: Union[Dict[str, Any], List[Dict[str, Any]]],
        load_config: Dict[str, Any],
        variables: Dict[str, str],
        validate: bool,
        name: Optional[str],
        extract_validation_config: Optional[Dict[str, Any]] = None,
        load_validation_config: Optional[Dict[str, Any]] = None,
        settings: Optional[Dict[str, Any]] = None,
        base_dir: Optional[Path] = None,
    ) -> "Pipeline":
        """Internal method to build pipeline from resolved configs.

        Uses the unified apply_transforms path for transformations, which supports:
        - Simple ops: rename, convert, defaults, add, select, drop, filter
        - JSONata expressions
        - Custom functions

        Also supports validation at extract and load stages via extract_validation_config
        and load_validation_config parameters.
        """
        from pycharter.etl_generator.config_validator import ConfigValidator
        from pycharter.etl_generator.extractors.factory import ExtractorFactory
        from pycharter.etl_generator.loaders.factory import LoaderFactory

        # Validate if enabled
        if validate:
            validator = ConfigValidator(strict=True)
            validator.validate_extract(extract_config)
            if transform_config:
                # Wrap list in dict for validation
                if isinstance(transform_config, list):
                    validator.validate_transform({"transform": transform_config})
                else:
                    validator.validate_transform(transform_config)
            validator.validate_load(load_config)

        # Create context
        context = PipelineContext(variables=variables)

        # Create components
        extractor = _create_extractor(extract_config)
        loader_instance = _create_loader(load_config)

        # Pass raw transform config - will be used by apply_transforms in _apply_transforms
        return cls(
            extractor=extractor,
            transformers=None,  # No transformer objects for config-driven runs
            loader=loader_instance,
            context=context,
            name=name,
            transform_config=transform_config if transform_config else None,
            extract_validation_config=extract_validation_config,
            load_validation_config=load_validation_config,
            settings=settings or {},
            base_dir=base_dir,
        )


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================


def _load_config_input(
    config_input: Union[str, Path, Dict[str, Any], List[Dict[str, Any]]],
    variables: Dict[str, str],
) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
    """Load config from file path or return dict/list directly."""
    if isinstance(config_input, (dict, list)):
        return config_input

    path = Path(config_input)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(path) as f:
        content = f.read()

    # Resolve variables in content before parsing
    content = _resolve_variables(content, variables)

    return yaml.safe_load(content) or {}


def _resolve_variables(content: str, variables: Dict[str, str]) -> str:
    """Resolve ${VAR} placeholders in content string."""

    def replace_var(match):
        var_name = match.group(1)
        modifier = match.group(2)
        modifier_value = match.group(3)

        # Use value if variable is present (even when empty), so e.g. SSH_PASSWORD="" substitutes correctly
        if var_name in variables:
            return str(variables[var_name])
        if var_name in os.environ:
            return str(os.environ[var_name])

        # Handle modifiers when variable is not set
        if modifier == "-":
            return modifier_value if modifier_value is not None else ""
        elif modifier == "?":
            error_msg = modifier_value or f"Required variable {var_name} is not set"
            raise ValueError(error_msg)

        return match.group(0)

    return VARIABLE_PATTERN.sub(replace_var, content)


def _create_extractor(config: Dict[str, Any]) -> Optional[Extractor]:
    """Create extractor from config. Requires explicit 'type' in config."""
    if not config:
        return None

    from pycharter.etl_generator.extractors import (
        CloudStorageExtractor,
        DatabaseExtractor,
        FileExtractor,
        HTTPExtractor,
    )
    from pycharter.etl_generator.extractors.factory import ExtractorFactory

    EXTRACTOR_REGISTRY = {
        "http": HTTPExtractor,
        "file": FileExtractor,
        "database": DatabaseExtractor,
        "cloud_storage": CloudStorageExtractor,
    }

    extract_type = config.get("type")
    if not extract_type:
        raise ValueError(
            "Extract config missing required 'type' field. "
            f"Supported types: {list(EXTRACTOR_REGISTRY.keys())}"
        )

    extract_type = extract_type.lower()
    extractor_class = EXTRACTOR_REGISTRY.get(extract_type)

    if not extractor_class:
        raise ValueError(
            f"Unknown extractor type: '{extract_type}'. "
            f"Supported types: {list(EXTRACTOR_REGISTRY.keys())}"
        )

    return extractor_class.from_config(config)


def _create_loader(config: Dict[str, Any]) -> Optional[Loader]:
    """Create loader from config using explicit type field."""
    if not config:
        return None

    from pycharter.etl_generator.loaders import (
        CloudStorageLoader,
        FileLoader,
        PostgresLoader,
    )

    LOADER_REGISTRY = {
        "postgres": PostgresLoader,
        "postgresql": PostgresLoader,
        "database": PostgresLoader,
        "sqlite": PostgresLoader,
        "file": FileLoader,
        "cloud_storage": CloudStorageLoader,
    }

    # Get type field
    load_type = config.get("type")

    if not load_type:
        raise ValueError(
            "Load config missing required 'type' field. "
            f"Supported types: postgres, sqlite, file, cloud_storage"
        )

    load_type = load_type.lower()
    loader_class = LOADER_REGISTRY.get(load_type)

    if not loader_class:
        raise ValueError(
            f"Unknown loader type: '{load_type}'. "
            f"Supported types: postgres, sqlite, file, cloud_storage"
        )

    return loader_class.from_config(config)
