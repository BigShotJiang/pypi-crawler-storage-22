"""
ETL Pipeline Configuration Schemas.

This module previously provided JSON Schema validation.
Now validation is handled by Pydantic models in config_models.py.

For backward compatibility, this module re-exports the config model classes.
"""

from pycharter.etl_generator.config_models import (  # Config parsers; Extract configs; Load configs; Transform configs; Settings; Validation; Pipeline
    CloudStorageExtractConfig,
    CloudStorageLoadConfig,
    ContractRef,
    CustomFunctionConfig,
    DatabaseExtractConfig,
    DLQConfig,
    ExtractConfig,
    ExtractValidationConfig,
    FileExtractConfig,
    FileLoadConfig,
    HTTPExtractConfig,
    JSONataConfig,
    LoadConfig,
    LoadValidationConfig,
    MetadataStoreConfig,
    PipelineConfig,
    PostgresLoadConfig,
    SettingsConfig,
    SimpleOpsConfig,
    SQLiteLoadConfig,
    TransformConfig,
    parse_extract_config,
    parse_load_config,
    parse_settings_config,
    parse_transform_config,
)

__all__ = [
    # Parsers
    "parse_extract_config",
    "parse_load_config",
    "parse_transform_config",
    "parse_settings_config",
    # Extract
    "ExtractConfig",
    "HTTPExtractConfig",
    "FileExtractConfig",
    "DatabaseExtractConfig",
    "CloudStorageExtractConfig",
    # Load
    "LoadConfig",
    "PostgresLoadConfig",
    "SQLiteLoadConfig",
    "FileLoadConfig",
    "CloudStorageLoadConfig",
    # Transform
    "TransformConfig",
    "SimpleOpsConfig",
    "JSONataConfig",
    "CustomFunctionConfig",
    # Settings
    "SettingsConfig",
    # Validation
    "ExtractValidationConfig",
    "LoadValidationConfig",
    "DLQConfig",
    "ContractRef",
    "MetadataStoreConfig",
    # Pipeline
    "PipelineConfig",
]
