"""
PostgreSQL Metadata Store Implementation

Stores metadata in PostgreSQL tables within a dedicated schema.
"""

import json
from typing import TYPE_CHECKING, Any, Dict, List, Optional

import psycopg2  # type: ignore[import-untyped]
from alembic.runtime.migration import MigrationContext
from psycopg2.extras import RealDictCursor  # type: ignore[import-untyped]
from sqlalchemy import create_engine

from pycharter.metadata_store.client import MetadataStoreClient

if TYPE_CHECKING:
    from psycopg2.extensions import (
        connection as Psycopg2Connection,  # type: ignore[import-untyped]
    )
else:
    Psycopg2Connection = Any

try:
    from pycharter.config import get_database_url
except ImportError:

    def get_database_url() -> Optional[str]:  # type: ignore[misc]
        return None


class PostgresMetadataStore(MetadataStoreClient):
    """
    PostgreSQL metadata store implementation.

    Stores metadata in PostgreSQL tables within the specified schema (default: "pycharter"):
    - schemas: JSON Schema definitions
    - governance_rules: Governance rules
    - ownership: Ownership information
    - metadata: Additional metadata
    - coercion_rules: Coercion rules for data transformation
    - validation_rules: Validation rules for data validation

    Connection string format: postgresql://[user[:password]@][host][:port][/database]

    The schema namespace is automatically created if it doesn't exist when connecting.
    However, tables must be initialized separately using 'pycharter db init' (similar to
    'airflow db init'). All tables are created in the specified schema (not in the public schema).

    Example:
        >>> # First, initialize the database schema
        >>> # Run: pycharter db init postgresql://user:pass@localhost/pycharter
        >>>
        >>> # Then connect
        >>> store = PostgresMetadataStore("postgresql://user:pass@localhost/pycharter")
        >>> store.connect()  # Only connects and validates schema
        >>> store.store_schema("user", "1.0", {"type": "object"})
        >>> store.store_coercion_rules("user", "1.0", {"age": "coerce_to_integer"})
        >>> store.store_validation_rules("user", "1.0", {"age": {"is_positive": {}}})

    To use a different schema name:
        >>> store = PostgresMetadataStore(
        ...     "postgresql://user:pass@localhost/pycharter",
        ...     schema_name="my_custom_schema"
        ... )
    """

    def __init__(
        self, connection_string: Optional[str] = None, schema_name: str = "pycharter"
    ):
        """
        Initialize PostgreSQL metadata store.

        Args:
            connection_string: Optional PostgreSQL connection string.
                              If not provided, will use configuration from:
                              - PYCHARTER__DATABASE__SQL_ALCHEMY_CONN env var
                              - PYCHARTER_DATABASE_URL env var
                              - pycharter.cfg config file
                              - alembic.ini config file
            schema_name: PostgreSQL schema name to use (default: "pycharter")
        """
        # Try to get connection string from config if not provided
        if not connection_string:
            connection_string = get_database_url()

        if not connection_string:
            raise ValueError(
                "connection_string is required. Provide it directly, or configure it via:\n"
                "  - Environment variable: PYCHARTER__DATABASE__SQL_ALCHEMY_CONN or PYCHARTER_DATABASE_URL\n"
                "  - Config file: pycharter.cfg [database] sql_alchemy_conn\n"
                "  - Config file: alembic.ini sqlalchemy.url"
            )

        super().__init__(connection_string)
        self.schema_name = schema_name
        self._connection: Optional["Psycopg2Connection"] = None

    def connect(self, validate_schema_on_connect: bool = True) -> None:
        """
        Connect to PostgreSQL and validate schema.

        Args:
            validate_schema_on_connect: If True, validate that tables exist after connection

        Raises:
            ValueError: If connection_string is missing
            RuntimeError: If schema validation fails (tables don't exist)

        Note:
            This method only connects and validates. To initialize the database schema,
            run 'pycharter db init' first (similar to 'airflow db init').
        """
        if not self.connection_string:
            raise ValueError("connection_string is required for PostgreSQL")

        self._connection = psycopg2.connect(self.connection_string)
        self._ensure_schema_exists()
        self._set_search_path()

        if validate_schema_on_connect and not self._is_schema_initialized():
            raise RuntimeError(
                "Database schema is not initialized. "
                "Please run 'pycharter db init' to initialize the schema first.\n"
                f"Example: pycharter db init {self.connection_string}"
            )

    def disconnect(self) -> None:
        """Close PostgreSQL connection."""
        if self._connection is not None:
            self._connection.close()
            self._connection = None

    # ============================================================================
    # Connection Management Helpers
    # ============================================================================

    def _ensure_schema_exists(self) -> None:
        """Create the PostgreSQL schema namespace if it doesn't exist."""
        if self._connection is None:
            return

        conn = self._get_connection()
        with conn.cursor() as cur:
            cur.execute(f'CREATE SCHEMA IF NOT EXISTS "{self.schema_name}"')
            conn.commit()

    def _set_search_path(self) -> None:
        """Set search_path to use the schema."""
        if self._connection is None:
            return

        conn = self._get_connection()
        with conn.cursor() as cur:
            cur.execute(f'SET search_path TO "{self.schema_name}", public')
            conn.commit()

    def _is_schema_initialized(self) -> bool:
        """Check if the database schema is initialized."""
        if self._connection is None:
            return False

        try:
            with self._connection.cursor() as cur:
                cur.execute(
                    """
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_schema = %s AND table_name = 'schemas'
                    )
                """,
                    (self.schema_name,),
                )
                return cur.fetchone()[0]
        except Exception:
            return False

    def _require_connection(self) -> None:
        """Raise error if not connected."""
        if self._connection is None:
            raise RuntimeError("Not connected. Call connect() first.")

    def _get_connection(self) -> "Psycopg2Connection":
        """Get connection, raising error if not connected."""
        if self._connection is None:
            raise RuntimeError("Not connected. Call connect() first.")
        return self._connection

    def _parse_jsonb(self, value: Any) -> Dict[str, Any]:
        """Parse JSONB value (psycopg2 may return dict or str)."""
        if isinstance(value, str):
            return json.loads(value)
        return value if value is not None else {}

    def _table_name(self, table: str) -> str:
        """Get fully qualified table name."""
        return f'"{self.schema_name}".{table}'

    # ============================================================================
    # Schema Info
    # ============================================================================

    def get_schema_info(self) -> Dict[str, Any]:
        """
        Get information about the current database schema.

        Returns:
            Dictionary with schema information:
            {
                "revision": str or None,
                "initialized": bool,
                "message": str
            }
        """
        self._require_connection()

        initialized = self._is_schema_initialized()
        revision = None

        if initialized:
            try:
                if self.connection_string is None:
                    raise ValueError("connection_string is required")
                engine = create_engine(self.connection_string)
                with engine.connect() as conn:
                    context = MigrationContext.configure(conn)
                    revision = context.get_current_revision()
            except Exception:
                pass

        message = f"Schema initialized: {initialized}"
        if revision:
            message += f" (revision: {revision})"

        return {
            "revision": revision,
            "initialized": initialized,
            "message": message,
        }

    # ============================================================================
    # Schema Operations
    # ============================================================================

    def _get_or_create_data_contract(
        self,
        contract_name: str,
        version: str,
        status: str = "active",
        description: Optional[str] = None,
    ) -> Any:
        """
        Get or create a data_contract record. Contract name is validated.

        Returns:
            Data contract ID (UUID).
        """
        from pycharter.shared.name_validator import validate_name

        contract_name = validate_name(contract_name, field_name="contract_name")
        self._require_connection()
        conn = self._get_connection()

        with conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT id FROM {self._table_name("data_contracts")}
                WHERE name = %s AND version = %s
                """,
                (contract_name, version),
            )
            row = cur.fetchone()
            if row:
                return row[0]

            cur.execute(
                f"""
                INSERT INTO {self._table_name("data_contracts")} 
                    (id, name, version, status, description)
                VALUES (gen_random_uuid(), %s, %s, %s, %s)
                RETURNING id
                """,
                (contract_name, version, status, description),
            )
            data_contract_id = cur.fetchone()[0]
            conn.commit()
            return data_contract_id

    def _resolve_data_contract(
        self, contract_name: str, contract_version: str
    ) -> Optional[Dict[str, Any]]:
        """
        Resolve (contract_name, contract_version) to data_contract row.
        Returns dict with id, schema_id, coercion_rules_id, validation_rules_id, metadata_record_id, or None.
        """
        self._require_connection()
        conn = self._get_connection()
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                f"""
                SELECT id, schema_id, coercion_rules_id, validation_rules_id, metadata_record_id
                FROM {self._table_name("data_contracts")}
                WHERE name = %s AND version = %s
                """,
                (contract_name, contract_version),
            )
            row = cur.fetchone()
            return dict(row) if row else None

    def _get_schema_by_id(self, schema_id: Any) -> Optional[Dict[str, Any]]:
        """Load schema by schemas.id (internal use)."""
        self._require_connection()
        conn = self._get_connection()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(
                    f"""
                    SELECT schema_data, version FROM {self._table_name("schemas")}
                    WHERE id = %s
                    """,
                    (schema_id,),
                )
                row = cur.fetchone()
                if not row:
                    return None
                schema_data = self._parse_jsonb(row["schema_data"])
                if "version" not in schema_data:
                    schema_data = dict(schema_data)
                    schema_data["version"] = row.get("version") or "1.0.0"
                return schema_data
        except Exception:
            conn.rollback()
            raise

    def store_schema(
        self,
        contract_name: str,
        contract_version: str,
        schema: Dict[str, Any],
    ) -> str:
        """
        Store a schema for the given data contract. Creates the data contract if needed.

        Returns:
            Contract ID (data_contract id) as string.
        """
        self._require_connection()
        conn = self._get_connection()

        schema_artifact_version = schema.get("version")
        if not schema_artifact_version:
            schema = dict(schema)
            schema["version"] = contract_version
            schema_artifact_version = contract_version
        elif "version" not in schema:
            schema = dict(schema)
            schema["version"] = schema_artifact_version

        data_contract_id = self._get_or_create_data_contract(
            contract_name=contract_name,
            version=contract_version,
            description=schema.get("description"),
        )

        from pycharter.shared.name_validator import validate_name

        _name = validate_name(contract_name, field_name="contract_name")
        title = schema.get("title") or _name
        if title:
            title = validate_name(str(title), field_name="schema.title")

        with conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT id FROM {self._table_name("schemas")}
                WHERE title = %s AND version = %s
                """,
                (title, schema_artifact_version),
            )
            if cur.fetchone():
                raise ValueError(
                    f"Schema with title '{title}' and version '{schema_artifact_version}' already exists."
                )
            cur.execute(
                f"""
                INSERT INTO {self._table_name("schemas")} 
                    (id, title, data_contract_id, version, schema_data)
                VALUES (gen_random_uuid(), %s, %s, %s, %s)
                RETURNING id
                """,
                (title, data_contract_id, schema_artifact_version, json.dumps(schema)),
            )
            schema_id = cur.fetchone()[0]
            cur.execute(
                f"""
                UPDATE {self._table_name("data_contracts")} SET schema_id = %s WHERE id = %s
                """,
                (schema_id, data_contract_id),
            )
            conn.commit()
        return str(data_contract_id)

    def get_schema(
        self, contract_name: str, contract_version: str
    ) -> Optional[Dict[str, Any]]:
        """Retrieve the schema for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("schema_id"):
            return None
        return self._get_schema_by_id(row["schema_id"])

    def list_contracts(self) -> List[Dict[str, Any]]:
        """List all data contracts with name, version, and optional id/schema_id."""
        self._require_connection()
        conn = self._get_connection()
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(f"""
                SELECT id, name, version, schema_id
                FROM {self._table_name("data_contracts")}
                ORDER BY name, version
                """)
            return [
                {
                    "id": str(r["id"]),
                    "name": r["name"],
                    "version": r["version"],
                    "schema_id": str(r["schema_id"]) if r.get("schema_id") else None,
                }
                for r in cur.fetchall()
            ]

    # ============================================================================
    # Metadata Operations - Helper Methods
    # ============================================================================

    def _get_or_create_owner(self, cur: Any, owner_id: str) -> str:
        """
        Get or create an owner by ID (string).

        Args:
            cur: Database cursor
            owner_id: Owner identifier

        Returns:
            Owner ID
        """
        cur.execute(
            f"SELECT id FROM {self._table_name('owners')} WHERE id = %s",
            (owner_id,),
        )
        existing = cur.fetchone()
        if not existing:
            # Create owner with just the ID (name defaults to id)
            cur.execute(
                f"""
                INSERT INTO {self._table_name('owners')} (id, name)
                VALUES (%s, %s)
                ON CONFLICT (id) DO NOTHING
                """,
                (owner_id, owner_id),
            )
        return owner_id

    def _get_or_create_system(self, cur: Any, system_name: str) -> str:
        """
        Get or create a system by name, return system UUID.

        Args:
            cur: Database cursor
            system_name: System name

        Returns:
            System UUID as string
        """
        cur.execute(
            f"SELECT id FROM {self._table_name('systems')} WHERE name = %s",
            (system_name,),
        )
        existing = cur.fetchone()
        if existing:
            return str(existing[0])
        # Create new system
        cur.execute(
            f"""
            INSERT INTO {self._table_name('systems')} (id, name)
            VALUES (gen_random_uuid(), %s)
            RETURNING id
            """,
            (system_name,),
        )
        return str(cur.fetchone()[0])

    def _get_or_create_domain(self, cur: Any, domain_name: str) -> str:
        """
        Get or create a domain by name, return domain UUID.

        Args:
            cur: Database cursor
            domain_name: Domain name

        Returns:
            Domain UUID as string
        """
        cur.execute(
            f"SELECT id FROM {self._table_name('domains')} WHERE name = %s",
            (domain_name,),
        )
        existing = cur.fetchone()
        if existing:
            return str(existing[0])
        # Create new domain
        cur.execute(
            f"""
            INSERT INTO {self._table_name('domains')} (id, name)
            VALUES (gen_random_uuid(), %s)
            RETURNING id
            """,
            (domain_name,),
        )
        return str(cur.fetchone()[0])

    def _clear_metadata_relationships(self, cur: Any, metadata_id: str) -> None:
        """
        Clear all existing relationships for a metadata record.

        Args:
            cur: Database cursor
            metadata_id: Metadata record ID
        """
        join_tables = [
            "metadata_record_business_owners",
            "metadata_record_bu_sme",
            "metadata_record_it_application_owners",
            "metadata_record_it_sme",
            "metadata_record_support_lead",
            "metadata_record_system_pulls",
            "metadata_record_system_pushes",
            "metadata_record_system_sources",
            "metadata_record_domains",
        ]
        for table in join_tables:
            cur.execute(
                f"DELETE FROM {self._table_name(table)} WHERE metadata_record_id = %s",
                (metadata_id,),
            )

    def _store_ownership_relationship(
        self, cur: Any, metadata_id: str, owner_id: str, relationship_type: str
    ) -> None:
        """
        Store an ownership relationship in the appropriate join table.

        Args:
            cur: Database cursor
            metadata_id: Metadata record ID
            owner_id: Owner ID
            relationship_type: Type of relationship (business_owners, bu_sme, etc.)
        """
        table_map = {
            "business_owners": "metadata_record_business_owners",
            "bu_sme": "metadata_record_bu_sme",
            "it_application_owners": "metadata_record_it_application_owners",
            "it_sme": "metadata_record_it_sme",
            "support_lead": "metadata_record_support_lead",
        }

        table = table_map.get(relationship_type)
        if not table:
            raise ValueError(
                f"Unknown ownership relationship type: {relationship_type}"
            )

        self._get_or_create_owner(cur, owner_id)
        cur.execute(
            f"""
            INSERT INTO {self._table_name(table)}
            (id, metadata_record_id, owner_id)
            VALUES (gen_random_uuid(), %s, %s)
            ON CONFLICT (metadata_record_id, owner_id) DO NOTHING
            """,
            (metadata_id, owner_id),
        )

    def _store_system_relationship(
        self, cur: Any, metadata_id: str, system_name: str, relationship_type: str
    ) -> None:
        """
        Store a system relationship in the appropriate join table.

        Args:
            cur: Database cursor
            metadata_id: Metadata record ID
            system_name: System name
            relationship_type: Type of relationship (pulls_from, pushes_to, system_sources)
        """
        table_map = {
            "pulls_from": "metadata_record_system_pulls",
            "pushes_to": "metadata_record_system_pushes",
            "system_sources": "metadata_record_system_sources",
        }

        table = table_map.get(relationship_type)
        if not table:
            raise ValueError(f"Unknown system relationship type: {relationship_type}")

        system_id = self._get_or_create_system(cur, system_name)
        cur.execute(
            f"""
            INSERT INTO {self._table_name(table)}
            (id, metadata_record_id, system_id)
            VALUES (gen_random_uuid(), %s, %s::uuid)
            ON CONFLICT (metadata_record_id, system_id) DO NOTHING
            """,
            (metadata_id, system_id),
        )

    def _get_metadata_relationships(
        self, cur: Any, metadata_record_id: str
    ) -> Dict[str, Any]:
        """
        Retrieve all relationships for a metadata record.

        Args:
            cur: Database cursor
            metadata_record_id: Metadata record ID

        Returns:
            Dictionary containing all relationship data
        """
        relationships: Dict[str, Any] = {}

        # Get system relationships
        system_queries = {
            "pulls_from": (
                "metadata_record_system_pulls",
                "SELECT s.name FROM {table} mrsp JOIN {systems} s ON mrsp.system_id = s.id WHERE mrsp.metadata_record_id = %s ORDER BY s.name",
            ),
            "pushes_to": (
                "metadata_record_system_pushes",
                "SELECT s.name FROM {table} mrsp JOIN {systems} s ON mrsp.system_id = s.id WHERE mrsp.metadata_record_id = %s ORDER BY s.name",
            ),
            "system_sources": (
                "metadata_record_system_sources",
                "SELECT s.name FROM {table} mrss JOIN {systems} s ON mrss.system_id = s.id WHERE mrss.metadata_record_id = %s ORDER BY s.name",
            ),
        }

        for key, (table, query_template) in system_queries.items():
            cur.execute(
                query_template.format(
                    table=self._table_name(table), systems=self._table_name("systems")
                ),
                (metadata_record_id,),
            )
            results = [r["name"] for r in cur.fetchall()]
            if results:
                relationships[key] = results

        # Get ownership relationships
        ownership_queries = {
            "business_owners": "metadata_record_business_owners",
            "bu_sme": "metadata_record_bu_sme",
            "it_application_owners": "metadata_record_it_application_owners",
            "it_sme": "metadata_record_it_sme",
            "support_lead": "metadata_record_support_lead",
        }

        for key, table in ownership_queries.items():
            cur.execute(
                f"""
                SELECT o.id
                FROM {self._table_name(table)} mrt
                JOIN {self._table_name('owners')} o ON mrt.owner_id = o.id
                WHERE mrt.metadata_record_id = %s
                ORDER BY o.id
                """,
                (metadata_record_id,),
            )
            results = [r["id"] for r in cur.fetchall()]
            if results:
                relationships[key] = results

        # Get domain (only one domain per metadata_record)
        cur.execute(
            f"""
            SELECT d.name
            FROM {self._table_name("metadata_record_domains")} mrd
            JOIN {self._table_name("domains")} d ON mrd.domain_id = d.id
            WHERE mrd.metadata_record_id = %s
            LIMIT 1
            """,
            (metadata_record_id,),
        )
        domain_row = cur.fetchone()
        if domain_row:
            relationships["domain"] = domain_row["name"]

        return relationships

    def _build_metadata_response(
        self, row: Dict[str, Any], rels: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Build canonical metadata dict from DB row and relationship data."""
        payload = row.get("payload")
        if payload is not None:
            try:
                payload = (
                    self._parse_jsonb(payload) if isinstance(payload, str) else payload
                )
            except Exception:
                payload = None
        if isinstance(payload, dict) and payload:
            out = dict(payload)
            out.setdefault("ownership", {})
            out.setdefault("lineage", {})
            for k in (
                "business_owners",
                "bu_sme",
                "it_application_owners",
                "it_sme",
                "support_lead",
            ):
                if k in rels:
                    out["ownership"][k] = rels[k]
            for k in ("pulls_from", "pushes_to", "system_sources"):
                if k in rels:
                    out["lineage"][k] = rels[k]
            if "domain" in rels:
                out["domain"] = rels["domain"]
            return out
        out = {
            "title": row.get("title"),
            "version": row.get("version"),
            "status": row.get("status"),
            "type": row.get("type"),
            "description": row.get("description"),
            "created_at": (
                row.get("created_at").isoformat() if row.get("created_at") else None
            ),
            "updated_at": (
                row.get("updated_at").isoformat() if row.get("updated_at") else None
            ),
            "created_by": row.get("created_by"),
            "updated_by": row.get("updated_by"),
            "ownership": {
                k: rels[k]
                for k in (
                    "business_owners",
                    "bu_sme",
                    "it_application_owners",
                    "it_sme",
                    "support_lead",
                )
                if k in rels
            },
            "lineage": {
                k: rels[k]
                for k in ("pulls_from", "pushes_to", "system_sources")
                if k in rels
            },
        }
        if row.get("governance_rules"):
            out["governance_rules"] = self._parse_jsonb(row["governance_rules"])
        if "domain" in rels:
            out["domain"] = rels["domain"]
        return out

    def _store_metadata_relationships(
        self, cur: Any, metadata_id: str, view: Dict[str, Any]
    ) -> None:
        """Store relationship rows from flat view (ownership lists, lineage lists, domain)."""
        for rel_type in (
            "business_owners",
            "bu_sme",
            "it_application_owners",
            "it_sme",
            "support_lead",
        ):
            for owner_id in view.get(rel_type) or []:
                if isinstance(owner_id, str):
                    self._store_ownership_relationship(
                        cur, metadata_id, owner_id, rel_type
                    )

        for rel_type in ("pulls_from", "pushes_to", "system_sources"):
            for name in view.get(rel_type) or []:
                if isinstance(name, str):
                    self._store_system_relationship(cur, metadata_id, name, rel_type)

        domain = view.get("domain")
        if isinstance(domain, str):
            domain_id = self._get_or_create_domain(cur, domain)
            # Delete existing domain relationship first
            cur.execute(
                f"DELETE FROM {self._table_name('metadata_record_domains')} WHERE metadata_record_id = %s",
                (metadata_id,),
            )
            cur.execute(
                f"""
                INSERT INTO {self._table_name('metadata_record_domains')}
                (id, metadata_record_id, domain_id)
                VALUES (gen_random_uuid(), %s, %s::uuid)
                """,
                (metadata_id, domain_id),
            )

    # ============================================================================
    # Metadata Operations
    # ============================================================================

    def store_metadata(
        self,
        contract_name: str,
        contract_version: str,
        metadata: Dict[str, Any],
    ) -> str:
        """Store metadata for the given data contract. Contract must exist (store_schema first)."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row:
            raise ValueError(
                f"Data contract not found: {contract_name!r} @ {contract_version!r}. "
                "Store the schema first."
            )
        data_contract_id = row["id"]

        from pycharter.db.metadata_normalizer import ensure_canonical, relationship_view
        from pycharter.shared.name_validator import normalize_name, validate_name

        canonical = ensure_canonical(metadata)
        rel_view = relationship_view(canonical)

        title = canonical.get("title")
        if not title:
            title = (
                normalize_name(f"metadata_for_{contract_name}_{contract_version}")
                or "metadata"
            )
        normalized_title = normalize_name(str(title))
        if not normalized_title:
            raise ValueError(
                f"metadata.title '{title}' cannot be normalized to a valid name."
            )
        title = validate_name(normalized_title, field_name="metadata.title")
        version = contract_version
        status = canonical.get("status", "active")
        type_val = canonical.get("type")
        description = canonical.get("description")
        governance_rules = canonical.get("governance_rules")
        payload_json = json.dumps(canonical) if canonical else None

        self._require_connection()
        conn = self._get_connection()
        with conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT id FROM {self._table_name("metadata_records")}
                WHERE title = %s AND version = %s
                """,
                (title, version),
            )
            if cur.fetchone():
                raise ValueError(
                    f"Metadata with title '{title}' and version '{version}' already exists."
                )
            cur.execute(
                f"""
                INSERT INTO {self._table_name("metadata_records")} (
                    id, title, data_contract_id, version, status, type, description,
                    governance_rules, payload
                )
                VALUES (gen_random_uuid(), %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id
                """,
                (
                    title,
                    data_contract_id,
                    version,
                    status,
                    type_val,
                    description,
                    json.dumps(governance_rules) if governance_rules else None,
                    payload_json,
                ),
            )
            metadata_id = cur.fetchone()[0]
            cur.execute(
                f"""
                UPDATE {self._table_name("data_contracts")}
                SET metadata_record_id = %s WHERE id = %s
                """,
                (metadata_id, data_contract_id),
            )
            self._clear_metadata_relationships(cur, metadata_id)
            self._store_metadata_relationships(cur, metadata_id, rel_view)
            conn.commit()
        return str(metadata_id)

    def get_metadata(
        self, contract_name: str, contract_version: str
    ) -> Optional[Dict[str, Any]]:
        """Retrieve metadata for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("metadata_record_id"):
            return None
        return self._get_metadata_by_id(row["metadata_record_id"])

    def _get_metadata_by_id(self, metadata_id: Any) -> Optional[Dict[str, Any]]:
        """Load metadata by metadata_records.id (internal use)."""
        self._require_connection()
        conn = self._get_connection()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(
                    f"SELECT * FROM {self._table_name('metadata_records')} WHERE id = %s",
                    (metadata_id,),
                )
                row = cur.fetchone()
                if not row:
                    return None
                rels = self._get_metadata_relationships(cur, row["id"])
                return self._build_metadata_response(row, rels)
        except Exception:
            conn.rollback()
            raise

    # ============================================================================
    # Coercion Rules Operations
    # ============================================================================

    def store_coercion_rules(
        self,
        contract_name: str,
        contract_version: str,
        coercion_rules: Dict[str, Any],
    ) -> str:
        """Store coercion rules for the given data contract. Contract must have a schema."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row:
            raise ValueError(
                f"Data contract not found: {contract_name!r} @ {contract_version!r}. Store the schema first."
            )
        data_contract_id = row["id"]
        schema_id = row.get("schema_id")
        if not schema_id:
            raise ValueError(
                f"Data contract {contract_name!r} @ {contract_version!r} has no schema. Store the schema first."
            )

        from pycharter.shared.name_validator import normalize_name, validate_name

        schema_title = contract_name  # use contract name for title
        title = (
            normalize_name(f"{schema_title}_coercion_rules")
            or normalize_name(f"{schema_title}_coercion")
            or "coercion_rules"
        )
        title = validate_name(title, field_name="coercion_rules.title")
        version = contract_version

        self._require_connection()
        conn = self._get_connection()
        with conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT id FROM {self._table_name("coercion_rules")}
                WHERE title = %s AND version = %s
                """,
                (title, version),
            )
            if cur.fetchone():
                raise ValueError(
                    f"Coercion rules with title '{title}' and version '{version}' already exist."
                )
            cur.execute(
                f"""
                INSERT INTO {self._table_name("coercion_rules")} (
                    id, title, data_contract_id, version, rules, schema_id
                )
                VALUES (gen_random_uuid(), %s, %s, %s, %s, %s)
                RETURNING id
                """,
                (
                    title,
                    data_contract_id,
                    version,
                    json.dumps(coercion_rules),
                    schema_id,
                ),
            )
            rule_id = cur.fetchone()[0]
            cur.execute(
                f"""
                UPDATE {self._table_name("data_contracts")}
                SET coercion_rules_id = %s WHERE id = %s
                """,
                (rule_id, data_contract_id),
            )
            conn.commit()
        return str(rule_id)

    def get_coercion_rules(
        self, contract_name: str, contract_version: str
    ) -> Optional[Dict[str, Any]]:
        """Retrieve coercion rules for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("coercion_rules_id"):
            return None
        return self._get_coercion_rules_by_id(row["coercion_rules_id"])

    def _get_coercion_rules_by_id(
        self, coercion_rules_id: Any
    ) -> Optional[Dict[str, Any]]:
        """Load coercion rules by id (internal use)."""
        self._require_connection()
        conn = self._get_connection()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(
                    f"SELECT rules FROM {self._table_name('coercion_rules')} WHERE id = %s",
                    (coercion_rules_id,),
                )
                row = cur.fetchone()
                return self._parse_jsonb(row["rules"]) if row else None
        except Exception:
            conn.rollback()
            raise

    # ============================================================================
    # Validation Rules Operations
    # ============================================================================

    def store_validation_rules(
        self,
        contract_name: str,
        contract_version: str,
        validation_rules: Dict[str, Any],
    ) -> str:
        """Store validation rules for the given data contract. Contract must have a schema."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row:
            raise ValueError(
                f"Data contract not found: {contract_name!r} @ {contract_version!r}. Store the schema first."
            )
        data_contract_id = row["id"]
        schema_id = row.get("schema_id")
        if not schema_id:
            raise ValueError(
                f"Data contract {contract_name!r} @ {contract_version!r} has no schema. Store the schema first."
            )

        from pycharter.shared.name_validator import normalize_name, validate_name

        schema_title = contract_name
        title = (
            normalize_name(f"{schema_title}_validation_rules")
            or normalize_name(f"{schema_title}_validation")
            or "validation_rules"
        )
        title = validate_name(title, field_name="validation_rules.title")
        version = contract_version

        self._require_connection()
        conn = self._get_connection()
        with conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT id FROM {self._table_name("validation_rules")}
                WHERE title = %s AND version = %s
                """,
                (title, version),
            )
            if cur.fetchone():
                raise ValueError(
                    f"Validation rules with title '{title}' and version '{version}' already exist."
                )
            cur.execute(
                f"""
                INSERT INTO {self._table_name("validation_rules")} (
                    id, title, data_contract_id, version, rules, schema_id
                )
                VALUES (gen_random_uuid(), %s, %s, %s, %s, %s)
                RETURNING id
                """,
                (
                    title,
                    data_contract_id,
                    version,
                    json.dumps(validation_rules),
                    schema_id,
                ),
            )
            rule_id = cur.fetchone()[0]
            cur.execute(
                f"""
                UPDATE {self._table_name("data_contracts")}
                SET validation_rules_id = %s WHERE id = %s
                """,
                (rule_id, data_contract_id),
            )
            conn.commit()
        return str(rule_id)

    def get_validation_rules(
        self, contract_name: str, contract_version: str
    ) -> Optional[Dict[str, Any]]:
        """Retrieve validation rules for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("validation_rules_id"):
            return None
        return self._get_validation_rules_by_id(row["validation_rules_id"])

    def _get_validation_rules_by_id(
        self, validation_rules_id: Any
    ) -> Optional[Dict[str, Any]]:
        """Load validation rules by id (internal use)."""
        self._require_connection()
        conn = self._get_connection()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(
                    f"SELECT rules FROM {self._table_name('validation_rules')} WHERE id = %s",
                    (validation_rules_id,),
                )
                row = cur.fetchone()
                return self._parse_jsonb(row["rules"]) if row else None
        except Exception:
            conn.rollback()
            raise
