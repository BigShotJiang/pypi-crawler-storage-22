"""
SQLite Metadata Store Implementation

Stores metadata in SQLite database file.
"""

import json
import sqlite3
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from sqlalchemy import create_engine, inspect, text

from pycharter.metadata_store.client import MetadataStoreClient

if TYPE_CHECKING:
    from sqlite3 import Connection as SQLiteConnection
else:
    SQLiteConnection = Any

try:
    from pycharter.config import get_database_url
except ImportError:

    def get_database_url() -> Optional[str]:  # type: ignore[misc]
        return None


class SQLiteMetadataStore(MetadataStoreClient):
    """
    SQLite metadata store implementation.

    Stores metadata in SQLite database file:
    - schemas: JSON Schema definitions
    - metadata_records: Metadata including governance rules
    - coercion_rules: Coercion rules for data transformation
    - validation_rules: Validation rules for data validation
    - data_contracts: Central table linking all components

    Connection string format: sqlite:///path/to/database.db
    Or: sqlite:///:memory: (for in-memory database)

    The database file is created automatically if it doesn't exist.
    Tables are initialized using SQLAlchemy models (same as PostgreSQL).

    Example:
        >>> # First, initialize the database schema
        >>> # Run: pycharter db init sqlite:///pycharter.db
        >>>
        >>> # Then connect
        >>> store = SQLiteMetadataStore("sqlite:///pycharter.db")
        >>> store.connect()  # Only connects and validates schema
        >>> store.store_schema("user", "1.0", {"type": "object"})
        >>> store.store_coercion_rules("user", "1.0", {"age": "coerce_to_integer"})
        >>> store.store_validation_rules("user", "1.0", {"age": {"is_positive": {}}})
    """

    def __init__(self, connection_string: Optional[str] = None):
        """
        Initialize SQLite metadata store.

        Args:
            connection_string: Optional SQLite connection string.
                            If not provided, will use configuration from:
                            - PYCHARTER__DATABASE__SQL_ALCHEMY_CONN env var
                            - PYCHARTER_DATABASE_URL env var
                            - pycharter.cfg config file
                            - alembic.ini config file

        Connection string formats:
            - sqlite:///path/to/database.db (absolute or relative path)
            - sqlite:///:memory: (in-memory database)
        """
        # Try to get connection string from config if not provided
        if not connection_string:
            connection_string = get_database_url()

        if not connection_string:
            raise ValueError(
                "connection_string is required. Provide it directly, or configure it via:\n"
                "  - Environment variable: PYCHARTER__DATABASE__SQL_ALCHEMY_CONN or PYCHARTER_DATABASE_URL\n"
                "  - Config file: pycharter.cfg [database] sql_alchemy_conn\n"
                "  - Config file: alembic.ini sqlalchemy.url"
            )

        # Normalize SQLite connection string
        # sqlite:///path/to/db -> sqlite:///path/to/db
        # sqlite:///:memory: -> sqlite:///:memory:
        if connection_string.startswith("sqlite:///"):
            # Extract the path part
            db_path = connection_string[10:]  # Remove "sqlite:///"
            if db_path != ":memory:":
                # Ensure parent directory exists
                db_file = Path(db_path)
                if db_file.parent and not db_file.parent.exists():
                    db_file.parent.mkdir(parents=True, exist_ok=True)
        elif not connection_string.startswith("sqlite://"):
            # If it's just a path, convert to sqlite:/// format
            db_path = Path(connection_string)
            if db_path.parent and not db_path.parent.exists():
                db_path.parent.mkdir(parents=True, exist_ok=True)
            connection_string = f"sqlite:///{db_path.absolute()}"

        super().__init__(connection_string)
        self._connection: Optional[SQLiteConnection] = None

    def connect(
        self, validate_schema_on_connect: bool = True, auto_initialize: bool = False
    ) -> None:
        """
        Connect to SQLite and validate schema.

        Args:
            validate_schema_on_connect: If True, validate that tables exist after connection
            auto_initialize: If True, automatically create tables if they don't exist (default: False)

        Raises:
            ValueError: If connection_string is missing
            RuntimeError: If schema validation fails (tables don't exist) and auto_initialize is False

        Note:
            This method only connects and validates. To initialize the database schema,
            run 'pycharter db init' first, or set auto_initialize=True.
        """
        if not self.connection_string:
            raise ValueError("connection_string is required for SQLite")

        # Extract database path from connection string
        if self.connection_string.startswith("sqlite:///"):
            db_path = self.connection_string[10:]  # Remove "sqlite:///"
        else:
            db_path = self.connection_string

        # Connect to SQLite
        self._connection = sqlite3.connect(
            db_path,
            check_same_thread=False,  # Allow use from multiple threads
            isolation_level=None,  # Autocommit mode
        )
        # Enable foreign keys
        self._connection.execute("PRAGMA foreign_keys = ON")

        if validate_schema_on_connect:
            if not self._is_schema_initialized():
                if auto_initialize:
                    self._initialize_schema()
                else:
                    raise RuntimeError(
                        "Database schema is not initialized. "
                        "Please run 'pycharter db init' to initialize the schema first.\n"
                        f"Example: pycharter db init {self.connection_string}"
                    )

    def disconnect(self) -> None:
        """Close SQLite connection."""
        if self._connection is not None:
            self._connection.close()
            self._connection = None

    # ============================================================================
    # Connection Management Helpers
    # ============================================================================

    def _is_schema_initialized(self) -> bool:
        """Check if the database schema is initialized."""
        if self._connection is None:
            return False

        try:
            cursor = self._connection.cursor()
            cursor.execute("""
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name='schemas'
                """)
            return cursor.fetchone() is not None
        except Exception:
            return False

    def _initialize_schema(self) -> None:
        """Initialize database schema using SQLAlchemy models."""
        try:
            from pycharter.db.models.base import Base

            # Create all tables
            engine = create_engine(self.connection_string)
            Base.metadata.create_all(engine)
        except Exception as e:
            raise RuntimeError(f"Failed to initialize schema: {e}")

    def _require_connection(self) -> None:
        """Raise error if not connected."""
        if self._connection is None:
            raise RuntimeError("Not connected. Call connect() first.")

    def _get_connection(self) -> SQLiteConnection:
        """Get connection, raising error if not connected."""
        if self._connection is None:
            raise RuntimeError("Not connected. Call connect() first.")
        return self._connection

    def _table_name(self, table: str) -> str:
        """Get table name (SQLite doesn't use schemas)."""
        return table

    # ============================================================================
    # Schema Info
    # ============================================================================

    def get_schema_info(self) -> Dict[str, Any]:
        """
        Get information about the current database schema.

        Returns:
            Dictionary with schema information:
            {
                "revision": str or None,
                "initialized": bool,
                "message": str
            }
        """
        self._require_connection()

        initialized = self._is_schema_initialized()
        revision = None

        if initialized:
            try:
                # Check if alembic_version table exists
                cursor = self._connection.cursor()
                cursor.execute("""
                    SELECT name FROM sqlite_master 
                    WHERE type='table' AND name='alembic_version'
                    """)
                if cursor.fetchone():
                    cursor.execute("SELECT version_num FROM alembic_version LIMIT 1")
                    row = cursor.fetchone()
                    if row:
                        revision = row[0]
            except Exception:
                pass

        message = f"Schema initialized: {initialized}"
        if revision:
            message += f" (revision: {revision})"

        return {
            "revision": revision,
            "initialized": initialized,
            "message": message,
        }

    # ============================================================================
    # Schema Operations
    # ============================================================================

    def _get_or_create_data_contract(
        self,
        contract_name: str,
        version: str,
        status: str = "active",
        description: Optional[str] = None,
    ) -> str:
        """Get or create a data_contract record. Returns data contract ID (UUID string)."""
        from pycharter.shared.name_validator import validate_name

        contract_name = validate_name(contract_name, field_name="contract_name")
        self._require_connection()
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id FROM data_contracts WHERE name = ? AND version = ?",
            (contract_name, version),
        )
        row = cursor.fetchone()
        if row:
            return row[0]
        import uuid

        data_contract_id = str(uuid.uuid4())
        cursor.execute(
            """
            INSERT INTO data_contracts (id, name, version, status, description)
            VALUES (?, ?, ?, ?, ?)
            """,
            (data_contract_id, contract_name, version, status, description),
        )
        return data_contract_id

    def _resolve_data_contract(
        self, contract_name: str, contract_version: str
    ) -> Optional[Dict[str, Any]]:
        """Resolve (contract_name, contract_version) to data_contract row. Returns dict or None."""
        self._require_connection()
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT id, schema_id, coercion_rules_id, validation_rules_id, metadata_record_id
            FROM data_contracts WHERE name = ? AND version = ?
            """,
            (contract_name, contract_version),
        )
        row = cursor.fetchone()
        if not row:
            return None
        return {
            "id": row[0],
            "schema_id": row[1],
            "coercion_rules_id": row[2],
            "validation_rules_id": row[3],
            "metadata_record_id": row[4],
        }

    def _get_schema_by_id(self, schema_id: str) -> Optional[Dict[str, Any]]:
        """Load schema by schemas.id (internal use)."""
        self._require_connection()
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT schema_data, version FROM schemas WHERE id = ?",
            (schema_id,),
        )
        row = cursor.fetchone()
        if not row:
            return None
        schema_data = json.loads(row[0]) if isinstance(row[0], str) else row[0]
        if "version" not in schema_data:
            schema_data = dict(schema_data)
            schema_data["version"] = row[1] or "1.0.0"
        return schema_data

    def store_schema(
        self,
        contract_name: str,
        contract_version: str,
        schema: Dict[str, Any],
    ) -> str:
        """Store a schema for the given data contract. Returns contract ID (string)."""
        self._require_connection()
        conn = self._get_connection()

        schema_artifact_version = schema.get("version")
        if not schema_artifact_version:
            schema = dict(schema)
            schema["version"] = contract_version
            schema_artifact_version = contract_version
        elif "version" not in schema:
            schema = dict(schema)
            schema["version"] = schema_artifact_version

        data_contract_id = self._get_or_create_data_contract(
            contract_name=contract_name,
            version=contract_version,
            description=schema.get("description"),
        )

        from pycharter.shared.name_validator import validate_name

        _name = validate_name(contract_name, field_name="contract_name")
        title = schema.get("title") or _name
        if title:
            title = validate_name(str(title), field_name="schema.title")

        cursor = conn.cursor()
        cursor.execute(
            "SELECT id FROM schemas WHERE title = ? AND version = ?",
            (title, schema_artifact_version),
        )
        if cursor.fetchone():
            raise ValueError(
                f"Schema with title '{title}' and version '{schema_artifact_version}' already exists."
            )
        import uuid

        schema_id = str(uuid.uuid4())
        cursor.execute(
            """
            INSERT INTO schemas (id, title, data_contract_id, version, schema_data)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                schema_id,
                title,
                data_contract_id,
                schema_artifact_version,
                json.dumps(schema),
            ),
        )
        cursor.execute(
            "UPDATE data_contracts SET schema_id = ? WHERE id = ?",
            (schema_id, data_contract_id),
        )
        return data_contract_id

    def get_schema(
        self, contract_name: str, contract_version: str
    ) -> Optional[Dict[str, Any]]:
        """Retrieve the schema for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("schema_id"):
            return None
        return self._get_schema_by_id(row["schema_id"])

    def list_contracts(self) -> List[Dict[str, Any]]:
        """List all data contracts with name, version, and optional id/schema_id."""
        self._require_connection()
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, name, version, schema_id FROM data_contracts ORDER BY name, version"
        )
        return [
            {
                "id": str(r[0]),
                "name": r[1],
                "version": r[2],
                "schema_id": str(r[3]) if r[3] else None,
            }
            for r in cursor.fetchall()
        ]

    # ============================================================================
    # Metadata Operations
    # ============================================================================

    def store_metadata(
        self,
        contract_name: str,
        contract_version: str,
        metadata: Dict[str, Any],
    ) -> str:
        """Store metadata for the given data contract. Contract must exist (store_schema first)."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row:
            raise ValueError(
                f"Data contract not found: {contract_name!r} @ {contract_version!r}. Store the schema first."
            )
        data_contract_id = row["id"]

        from pycharter.db.metadata_normalizer import ensure_canonical
        from pycharter.shared.name_validator import normalize_name, validate_name

        canonical = ensure_canonical(metadata)
        title = canonical.get("title")
        if not title:
            title = (
                normalize_name(f"metadata_for_{contract_name}_{contract_version}")
                or "metadata"
            )
        normalized_title = normalize_name(str(title))
        if not normalized_title:
            raise ValueError(
                f"metadata.title '{title}' cannot be normalized to a valid name."
            )
        title = validate_name(normalized_title, field_name="metadata.title")
        version = contract_version
        status = canonical.get("status", "active")
        type_val = canonical.get("type")
        description = canonical.get("description")
        governance_rules = canonical.get("governance_rules")
        payload_json = json.dumps(canonical) if canonical else None

        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id FROM metadata_records WHERE title = ? AND version = ?",
            (title, version),
        )
        if cursor.fetchone():
            raise ValueError(
                f"Metadata with title '{title}' and version '{version}' already exists."
            )
        import uuid

        metadata_id = str(uuid.uuid4())
        cursor.execute(
            """
            INSERT INTO metadata_records 
                (id, title, data_contract_id, version, status, type, description, governance_rules, payload)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                metadata_id,
                title,
                data_contract_id,
                version,
                status,
                type_val,
                description,
                json.dumps(governance_rules) if governance_rules else None,
                payload_json,
            ),
        )
        cursor.execute(
            "UPDATE data_contracts SET metadata_record_id = ? WHERE id = ?",
            (metadata_id, data_contract_id),
        )
        return metadata_id

    def get_metadata(
        self, contract_name: str, contract_version: str
    ) -> Optional[Dict[str, Any]]:
        """Retrieve metadata for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("metadata_record_id"):
            return None
        return self._get_metadata_by_id(row["metadata_record_id"])

    def _get_metadata_by_id(self, metadata_id: str) -> Optional[Dict[str, Any]]:
        """Load metadata by metadata_records.id (internal use)."""
        self._require_connection()
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT id, title, data_contract_id, version, status, type, description,
                   created_at, updated_at, created_by, updated_by, governance_rules, payload
            FROM metadata_records WHERE id = ?
            """,
            (metadata_id,),
        )
        row = cursor.fetchone()
        if not row:
            return None
        payload = row[12] if len(row) > 12 else None
        if payload is not None:
            try:
                data = json.loads(payload) if isinstance(payload, str) else payload
                if isinstance(data, dict) and data:
                    return data
            except (json.JSONDecodeError, TypeError):
                pass
        out = {
            "title": row[1],
            "version": row[3],
            "status": row[4],
            "type": row[5] if len(row) > 5 else None,
            "description": row[6] if len(row) > 6 else None,
            "ownership": {},
            "lineage": {},
        }
        if len(row) > 11 and row[11]:
            try:
                out["governance_rules"] = (
                    json.loads(row[11]) if isinstance(row[11], str) else row[11]
                )
            except (json.JSONDecodeError, TypeError):
                pass
        return out

    # ============================================================================
    # Coercion Rules Operations
    # ============================================================================

    def store_coercion_rules(
        self,
        contract_name: str,
        contract_version: str,
        coercion_rules: Dict[str, Any],
    ) -> str:
        """Store coercion rules for the given data contract. Contract must have a schema."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row:
            raise ValueError(
                f"Data contract not found: {contract_name!r} @ {contract_version!r}. Store the schema first."
            )
        data_contract_id = row["id"]
        schema_id = row.get("schema_id")
        if not schema_id:
            raise ValueError(
                f"Data contract {contract_name!r} @ {contract_version!r} has no schema. Store the schema first."
            )

        from pycharter.shared.name_validator import normalize_name, validate_name

        schema_title = contract_name
        title = (
            normalize_name(f"{schema_title}_coercion_rules")
            or normalize_name(f"{schema_title}_coercion")
            or "coercion_rules"
        )
        title = validate_name(title, field_name="coercion_rules.title")
        version = contract_version

        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id FROM coercion_rules WHERE title = ? AND version = ?",
            (title, version),
        )
        if cursor.fetchone():
            raise ValueError(
                f"Coercion rules with title '{title}' and version '{version}' already exist."
            )
        import uuid

        rule_id = str(uuid.uuid4())
        cursor.execute(
            """
            INSERT INTO coercion_rules (id, title, data_contract_id, version, rules, schema_id)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                rule_id,
                title,
                data_contract_id,
                version,
                json.dumps(coercion_rules),
                schema_id,
            ),
        )
        cursor.execute(
            "UPDATE data_contracts SET coercion_rules_id = ? WHERE id = ?",
            (rule_id, data_contract_id),
        )
        return rule_id

    def get_coercion_rules(
        self, contract_name: str, contract_version: str
    ) -> Optional[Dict[str, Any]]:
        """Retrieve coercion rules for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("coercion_rules_id"):
            return None
        return self._get_coercion_rules_by_id(row["coercion_rules_id"])

    def _get_coercion_rules_by_id(
        self, coercion_rules_id: str
    ) -> Optional[Dict[str, Any]]:
        """Load coercion rules by id (internal use)."""
        self._require_connection()
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT rules FROM coercion_rules WHERE id = ?", (coercion_rules_id,)
        )
        row = cursor.fetchone()
        return json.loads(row[0]) if row and row[0] else None

    def _get_validation_rules_by_id(
        self, validation_rules_id: str
    ) -> Optional[Dict[str, Any]]:
        """Load validation rules by id (internal use)."""
        self._require_connection()
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT rules FROM validation_rules WHERE id = ?", (validation_rules_id,)
        )
        row = cursor.fetchone()
        return json.loads(row[0]) if row and row[0] else None

    # ============================================================================
    # Validation Rules Operations
    # ============================================================================

    def store_validation_rules(
        self,
        contract_name: str,
        contract_version: str,
        validation_rules: Dict[str, Any],
    ) -> str:
        """Store validation rules for the given data contract. Contract must have a schema."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row:
            raise ValueError(
                f"Data contract not found: {contract_name!r} @ {contract_version!r}. Store the schema first."
            )
        data_contract_id = row["id"]
        schema_id = row.get("schema_id")
        if not schema_id:
            raise ValueError(
                f"Data contract {contract_name!r} @ {contract_version!r} has no schema. Store the schema first."
            )

        from pycharter.shared.name_validator import normalize_name, validate_name

        schema_title = contract_name
        title = (
            normalize_name(f"{schema_title}_validation_rules")
            or normalize_name(f"{schema_title}_validation")
            or "validation_rules"
        )
        title = validate_name(title, field_name="validation_rules.title")
        version = contract_version

        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id FROM validation_rules WHERE title = ? AND version = ?",
            (title, version),
        )
        if cursor.fetchone():
            raise ValueError(
                f"Validation rules with title '{title}' and version '{version}' already exist."
            )
        import uuid

        rule_id = str(uuid.uuid4())
        cursor.execute(
            """
            INSERT INTO validation_rules (id, title, data_contract_id, version, rules, schema_id)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                rule_id,
                title,
                data_contract_id,
                version,
                json.dumps(validation_rules),
                schema_id,
            ),
        )
        cursor.execute(
            "UPDATE data_contracts SET validation_rules_id = ? WHERE id = ?",
            (rule_id, data_contract_id),
        )
        return rule_id

    def get_validation_rules(
        self, contract_name: str, contract_version: str
    ) -> Optional[Dict[str, Any]]:
        """Retrieve validation rules for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("validation_rules_id"):
            return None
        return self._get_validation_rules_by_id(row["validation_rules_id"])
