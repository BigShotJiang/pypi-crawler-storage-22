"""
Data Quality Assurance Module

Provides quality checking, metrics calculation, violation tracking, and reporting
for data contracts.

Submodules:
    - tracking: Time-series metrics collection and analysis
"""

# Tracking submodule exports
from pycharter.quality import tracking
from pycharter.quality.check import QualityCheck
from pycharter.quality.metrics import QualityMetrics, QualityScore
from pycharter.quality.models import (
    FieldQualityMetrics,
    QualityCheckOptions,
    QualityReport,
    QualityThresholds,
)
from pycharter.quality.profiling import DataProfiler
from pycharter.quality.tracking import (
    InMemoryMetricsStore,
    MetricsCollector,
    MetricsFilter,
    MetricsStore,
    MetricsSummary,
    SQLiteMetricsStore,
    ValidationMetric,
)
from pycharter.quality.violations import ViolationRecord, ViolationTracker

__all__ = [
    # Quality checking
    "QualityCheck",
    "QualityMetrics",
    "QualityScore",
    "QualityReport",
    "QualityThresholds",
    "QualityCheckOptions",
    "FieldQualityMetrics",
    "ViolationTracker",
    "ViolationRecord",
    "DataProfiler",
    # Tracking submodule
    "tracking",
    "MetricsCollector",
    "ValidationMetric",
    "MetricsSummary",
    "MetricsFilter",
    "MetricsStore",
    "InMemoryMetricsStore",
    "SQLiteMetricsStore",
]
