(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,33558,e=>{"use strict";var t=e.i(43476),a=e.i(71645),r=e.i(19455),i=e.i(9165);e.i(55824);var o=e.i(73465),n=e.i(31343),s=e.i(75254);let c=(0,s.default)("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]),d=(0,s.default)("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);var l=e.i(78583),m=e.i(58041);let p=(0,s.default)("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]]),u=(0,s.default)("ShieldCheck",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);var _=e.i(42009);let h=(0,s.default)("Layers",[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]]),f=(0,s.default)("BookOpen",[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]]),y=(0,s.default)("Activity",[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]]),g=(0,s.default)("GitCompare",[["circle",{cx:"18",cy:"18",r:"3",key:"1xkwt0"}],["circle",{cx:"6",cy:"6",r:"3",key:"1lh9wr"}],["path",{d:"M13 6h3a2 2 0 0 1 2 2v7",key:"1yeb86"}],["path",{d:"M11 18H8a2 2 0 0 1-2-2V9",key:"19pyzm"}]]);e.i(80428);var v=e.i(50398);let x=[{id:"parse_contract",title:"Contract Parser",description:"Read and decompose data contract files",method:"parse_contract(contract_dict, validate=True)",apiEndpoint:"/api/v1/contracts/parse",apiMethod:"POST",exampleRequest:{contract:{schema:{type:"object",properties:{name:{type:"string"},age:{type:"integer"}}},metadata:{title:"User Contract",version:"1.0.0"}}},exampleCode:`from pycharter import parse_contract, parse_contract_file

parse_contract(contract_dict)
parse_contract_file(file_path)`,arguments:[{name:"contract_data",type:"Dict[str, Any]",description:"Contract data as dictionary containing schema, metadata, ownership, governance_rules, coercion_rules, and validation_rules",required:!0},{name:"validate",type:"bool",description:"If True (default), validate contract against schema before parsing",required:!1,default:"True"}],returns:{type:"ContractMetadata",description:"ContractMetadata object with decomposed components (schema, metadata, ownership, governance_rules, coercion_rules, validation_rules) and version tracking"}},{id:"parse_contract_file",title:"Contract Parser - From File",description:"Parse a data contract from an uploaded file (YAML or JSON)",method:"parse_contract_file(file_path, validate=True)",apiEndpoint:"/api/v1/contracts/parse/upload",apiMethod:"POST",exampleRequest:null,exampleCode:`from pycharter import parse_contract_file

# Parse contract from file
contract_metadata = parse_contract_file("contract.yaml")
# or
contract_metadata = parse_contract_file("contract.json", validate=True)`,arguments:[{name:"file_path",type:"str",description:"Path to contract file (YAML or JSON)",required:!0},{name:"validate",type:"bool",description:"If True (default), validate contract against schema before parsing",required:!1,default:"True"}],returns:{type:"ContractMetadata",description:"ContractMetadata object with decomposed components (schema, metadata, ownership, governance_rules, coercion_rules, validation_rules)"}},{id:"build_contract",title:"Contract Builder",description:"Construct consolidated contracts from separate artifacts. Returns raw schema plus coercion_rules and validation_rules as separate keys; Validator merges rules internally for validation.",method:"build_contract(artifacts: ContractArtifacts, include_metadata=True, include_ownership=True, include_governance=True)",apiEndpoint:"/api/v1/contracts/build",apiMethod:"POST",exampleRequest:{artifacts:{schema:{type:"object",version:"1.0.0",properties:{name:{type:"string"},age:{type:"integer"}}},coercion_rules:{version:"1.0.0",age:"coerce_to_integer"},validation_rules:{version:"1.0.0",age:{greater_than_or_equal_to:{threshold:0}}},metadata:{version:"1.0.0",description:"User contract"}},include_metadata:!0,include_ownership:!0,include_governance:!0},exampleCode:`from pycharter import build_contract, ContractArtifacts

artifacts = ContractArtifacts(
    schema={"type": "object", "version": "1.0.0", "properties": {...}},
    coercion_rules={"version": "1.0.0", "age": "coerce_to_integer"},
    validation_rules={"version": "1.0.0", "age": {...}},
    metadata={"version": "1.0.0", "description": "User contract"}
)
contract = build_contract(artifacts)`,arguments:[{name:"artifacts",type:"ContractArtifacts",description:"ContractArtifacts dataclass containing schema (required), coercion_rules (optional), validation_rules (optional), and metadata (optional)",required:!0},{name:"include_metadata",type:"bool",description:"Whether to include metadata in the contract",required:!1,default:"True"},{name:"include_ownership",type:"bool",description:"Whether to include ownership information",required:!1,default:"True"},{name:"include_governance",type:"bool",description:"Whether to include governance rules",required:!1,default:"True"}],returns:{type:"Dict[str, Any]",description:"Consolidated contract dictionary with raw schema (rules not merged into schema), coercion_rules and validation_rules as separate keys, metadata (if included), and versions. Use Validator for validation—it merges rules internally."}},{id:"build_contract_from_store",title:"Contract Builder - From Store",description:"Build a consolidated contract from artifacts stored in metadata store (raw schema + separate rules; Validator merges internally for validation).",method:"build_contract_from_store(store, schema_title, schema_version=None, coercion_rules_title=None, coercion_rules_version=None, validation_rules_title=None, validation_rules_version=None, metadata_title=None, metadata_version=None)",apiEndpoint:"/api/v1/contracts/build",apiMethod:"POST",exampleRequest:{schema_title:"user_schema",schema_version:"1.0.0",coercion_rules_title:"user_schema",coercion_rules_version:"1.0.0",validation_rules_title:"user_schema",validation_rules_version:"1.0.0",metadata_title:"user_schema",metadata_version:"1.0.0"},exampleCode:`from pycharter import build_contract_from_store

store = PostgresMetadataStore(connection_string)
store.connect()
contract = build_contract_from_store(
    store=store,
    schema_title="user_schema",
    schema_version="1.0.0",
    coercion_rules_title="user_schema",
    coercion_rules_version="1.0.0",
    validation_rules_title="user_schema",
    validation_rules_version="1.0.0",
    metadata_title="user_schema",
    metadata_version="1.0.0"
)`,arguments:[{name:"store",type:"MetadataStoreClient",description:"MetadataStoreClient instance connected to the metadata store",required:!0},{name:"schema_title",type:"str",description:"Schema title/identifier",required:!0},{name:"schema_version",type:"Optional[str]",description:"Optional schema version (if None, uses latest version)",required:!1,default:"None"},{name:"coercion_rules_title",type:"Optional[str]",description:"Optional coercion rules title/identifier (if None, uses schema_title)",required:!1,default:"None"},{name:"coercion_rules_version",type:"Optional[str]",description:"Optional coercion rules version (if None, uses latest version or schema_version)",required:!1,default:"None"},{name:"validation_rules_title",type:"Optional[str]",description:"Optional validation rules title/identifier (if None, uses schema_title)",required:!1,default:"None"},{name:"validation_rules_version",type:"Optional[str]",description:"Optional validation rules version (if None, uses latest version or schema_version)",required:!1,default:"None"},{name:"metadata_title",type:"Optional[str]",description:"Optional metadata title/identifier (if None, uses schema_title)",required:!1,default:"None"},{name:"metadata_version",type:"Optional[str]",description:"Optional metadata version (if None, uses latest version or schema_version)",required:!1,default:"None"}],returns:{type:"Dict[str, Any]",description:"Consolidated contract dictionary with raw schema (rules not merged into schema), coercion_rules and validation_rules as separate keys, metadata (if included), and versions. Use Validator for validation—it merges rules internally."}},{id:"build_contract_from_id",title:"Build Contract from ID",description:"Reconstruct a complete data contract from a contract ID by fetching its linked artifacts (schema, coercion rules, validation rules, metadata) from the database.",method:"POST /api/v1/contracts/{contract_id}/build",apiEndpoint:"/api/v1/contracts/{contract_id}/build",apiMethod:"POST",exampleRequest:{contract_id:"123e4567-e89b-12d3-a456-426614174000",include_metadata:!0,include_ownership:!0,include_governance:!0},exampleCode:`# API: POST /api/v1/contracts/{contract_id}/build
# Query params: include_metadata, include_ownership, include_governance (default true)
# Returns the complete contract dictionary built from stored artifacts`,arguments:[{name:"contract_id",type:"str",description:"Contract ID (UUID) from the database",required:!0},{name:"include_metadata",type:"bool",description:"Include metadata in the built contract",required:!1,default:"True"},{name:"include_ownership",type:"bool",description:"Include ownership information",required:!1,default:"True"},{name:"include_governance",type:"bool",description:"Include governance rules",required:!1,default:"True"}],returns:{type:"Dict[str, Any]",description:"Complete contract dictionary with raw schema, coercion_rules and validation_rules (separate), metadata (if included). Validator merges rules internally for validation."}},{id:"create_from_artifacts",title:"Create Contract from Artifacts",description:"Create a new data contract by linking to existing artifacts (schemas, coercion rules, validation rules, metadata) identified by title and version in the store.",method:"POST /api/v1/contracts/create-from-artifacts",apiEndpoint:"/api/v1/contracts/create-from-artifacts",apiMethod:"POST",exampleRequest:{name:"user_contract",version:"2.0.0",schema_title:"user_schema",schema_version:"1.0.0",coercion_rules_title:"user_schema_coercion_rules",coercion_rules_version:"1.0.0",validation_rules_title:"user_schema_validation_rules",validation_rules_version:"1.0.0",metadata_title:"user_metadata",metadata_version:"1.0.0",status:"active",description:"User data contract"},exampleCode:`# API: POST /api/v1/contracts/create-from-artifacts
# Body: name, version, schema_title, schema_version, and optional *_title/*_version for coercion_rules, validation_rules, metadata
# Returns the created contract (ContractListItem) with id, name, version, status, etc.`,arguments:[{name:"name",type:"str",description:"Contract name",required:!0},{name:"version",type:"str",description:"Contract version",required:!0},{name:"schema_title",type:"str",description:"Schema artifact title",required:!0},{name:"schema_version",type:"str",description:"Schema artifact version",required:!0},{name:"coercion_rules_title",type:"Optional[str]",description:"Coercion rules artifact title",required:!1},{name:"coercion_rules_version",type:"Optional[str]",description:"Coercion rules artifact version",required:!1},{name:"validation_rules_title",type:"Optional[str]",description:"Validation rules artifact title",required:!1},{name:"validation_rules_version",type:"Optional[str]",description:"Validation rules artifact version",required:!1},{name:"metadata_title",type:"Optional[str]",description:"Metadata artifact title",required:!1},{name:"metadata_version",type:"Optional[str]",description:"Metadata artifact version",required:!1},{name:"status",type:"Optional[str]",description:"Contract status (e.g. active)",required:!1,default:"active"},{name:"description",type:"Optional[str]",description:"Contract description",required:!1}],returns:{type:"ContractListItem",description:"Created contract with id, name, version, status, description, schema_id, created_at, updated_at"}},{id:"create_mixed",title:"Create Contract (Mixed Artifacts)",description:"Create a new data contract by mixing new artifacts (provided as data) and existing artifacts (identified by title and version). Each artifact type can be either new or existing independently.",method:"POST /api/v1/contracts/create-mixed",apiEndpoint:"/api/v1/contracts/create-mixed",apiMethod:"POST",exampleRequest:{name:"user_contract",version:"1.0.0",schema:{type:"object",properties:{name:{type:"string"},age:{type:"integer"}}},coercion_rules_title:"existing_coercion_rules",coercion_rules_version:"1.0.0",validation_rules:{version:"1.0.0",rules:{}},metadata_title:"existing_metadata",metadata_version:"1.0.0",status:"active",description:"User data contract"},exampleCode:`# API: POST /api/v1/contracts/create-mixed
# For each artifact type: provide either new data (e.g. schema) OR existing (schema_title + schema_version), not both
# Returns the created contract (ContractListItem)`,arguments:[{name:"name",type:"str",description:"Contract name",required:!0},{name:"version",type:"str",description:"Contract version",required:!0},{name:"schema",type:"Optional[Dict]",description:"New schema (if not using existing)",required:!1},{name:"schema_title",type:"Optional[str]",description:"Existing schema title (if not providing schema)",required:!1},{name:"schema_version",type:"Optional[str]",description:"Existing schema version",required:!1},{name:"coercion_rules",type:"Optional[Dict]",description:"New coercion rules (if not using existing)",required:!1},{name:"coercion_rules_title",type:"Optional[str]",description:"Existing coercion rules title",required:!1},{name:"coercion_rules_version",type:"Optional[str]",description:"Existing coercion rules version",required:!1},{name:"validation_rules",type:"Optional[Dict]",description:"New validation rules (if not using existing)",required:!1},{name:"validation_rules_title",type:"Optional[str]",description:"Existing validation rules title",required:!1},{name:"validation_rules_version",type:"Optional[str]",description:"Existing validation rules version",required:!1},{name:"metadata",type:"Optional[Dict]",description:"New metadata (if not using existing)",required:!1},{name:"metadata_title",type:"Optional[str]",description:"Existing metadata title",required:!1},{name:"metadata_version",type:"Optional[str]",description:"Existing metadata version",required:!1},{name:"status",type:"Optional[str]",description:"Contract status",required:!1,default:"active"},{name:"description",type:"Optional[str]",description:"Contract description",required:!1}],returns:{type:"ContractListItem",description:"Created contract with id, name, version, status, description, schema_id, created_at, updated_at"}},{id:"list_contracts",title:"List Contracts",description:"Get a list of all data contracts stored in the database, ordered by created_at descending.",method:"GET /api/v1/contracts",apiEndpoint:"/api/v1/contracts",apiMethod:"GET",exampleRequest:null,exampleCode:`# API: GET /api/v1/contracts
# Returns: { contracts: ContractListItem[], total: number }`,arguments:[],returns:{type:"ContractListResponse",description:"Object with contracts array and total count"}},{id:"get_contract",title:"Get Contract by ID",description:"Retrieve a specific data contract from the database by its ID (UUID).",method:"GET /api/v1/contracts/{contract_id}",apiEndpoint:"/api/v1/contracts/{contract_id}",apiMethod:"GET",exampleRequest:{contract_id:"123e4567-e89b-12d3-a456-426614174000"},exampleCode:`# API: GET /api/v1/contracts/{contract_id}
# Path: contract_id (UUID)
# Returns: ContractListItem with id, name, version, status, description, schema_id, created_at, updated_at`,arguments:[{name:"contract_id",type:"str",description:"Contract ID (UUID)",required:!0}],returns:{type:"ContractListItem",description:"Contract details or 404 if not found"}},{id:"update_contract",title:"Update Contract",description:"Update a data contract's metadata (name, version, status, description). All fields are optional; only provided fields are updated.",method:"PUT /api/v1/contracts/{contract_id}",apiEndpoint:"/api/v1/contracts/{contract_id}",apiMethod:"PUT",exampleRequest:{contract_id:"123e4567-e89b-12d3-a456-426614174000",name:"updated_contract_name",version:"1.1.0",status:"active",description:"Updated contract description"},exampleCode:`# API: PUT /api/v1/contracts/{contract_id}
# Body: { name?, version?, status?, description? }
# Returns: updated ContractListItem`,arguments:[{name:"contract_id",type:"str",description:"Contract ID (UUID)",required:!0},{name:"name",type:"Optional[str]",description:"New contract name",required:!1},{name:"version",type:"Optional[str]",description:"New contract version",required:!1},{name:"status",type:"Optional[str]",description:"Status (e.g. active, deprecated, draft)",required:!1},{name:"description",type:"Optional[str]",description:"New description",required:!1}],returns:{type:"ContractListItem",description:"Updated contract details"}},{id:"store_schema",title:"Metadata Store - Store Schema",description:"Store a JSON Schema in the metadata store",method:"store.store_schema(schema_name, schema, version)",apiEndpoint:"/api/v1/metadata/schemas",apiMethod:"POST",exampleRequest:{schema_name:"user_schema",schema:{type:"object",properties:{name:{type:"string"},age:{type:"integer"}}},version:"1.0.0"},exampleCode:`from pycharter import MetadataStoreClient

store = MetadataStoreClient(database_url)
store.store_schema(schema_id, schema, version)
store.get_schema(schema_id, version)
store.store_metadata(schema_id, metadata, version)`,arguments:[{name:"schema_name",type:"str",description:"Name/identifier for the schema (used as data_contract name)",required:!0},{name:"schema",type:"Dict[str, Any]",description:'JSON Schema dictionary (must contain "version" field or it will be added)',required:!0},{name:"version",type:"str",description:'Required version string (must match schema["version"] if present)',required:!0}],returns:{type:"str",description:"Schema ID or identifier"}},{id:"get_schema",title:"Metadata Store - Get Schema",description:"Retrieve a schema from the metadata store",method:"store.get_schema(schema_id, version=None)",apiEndpoint:"/api/v1/metadata/schemas/{schema_id}",apiMethod:"GET",exampleRequest:null,exampleCode:`from pycharter import MetadataStoreClient

store = MetadataStoreClient(database_url)
store.get_schema(schema_id, version)`,arguments:[{name:"schema_id",type:"str",description:"Schema identifier",required:!0},{name:"version",type:"Optional[str]",description:"Optional version string (if None, returns latest version)",required:!1,default:"None"}],returns:{type:"Optional[Dict[str, Any]]",description:"Schema dictionary with version included, or None if not found"}},{id:"list_schemas",title:"Metadata Store - List Schemas",description:"Retrieve a list of all schemas stored in the metadata store",method:"store.list_schemas()",apiEndpoint:"/api/v1/metadata/schemas",apiMethod:"GET",exampleRequest:null,exampleCode:`from pycharter import PostgresMetadataStore

store = PostgresMetadataStore(connection_string)
store.connect()

# List all schemas
schemas = store.list_schemas()
for schema in schemas:
    print(f"Schema: {schema.get('name')}, Version: {schema.get('version')}")`,arguments:[],returns:{type:"List[Dict[str, Any]]",description:"List of schema metadata dictionaries, each containing id, name, title, and version"}},{id:"store_metadata",title:"Metadata Store - Store Metadata",description:"Store metadata (ownership, governance rules, etc.) for a schema",method:"store.store_metadata(schema_id, metadata, version=None)",apiEndpoint:"/api/v1/metadata/metadata",apiMethod:"POST",exampleRequest:{schema_id:"user_schema",metadata:{title:"user_schema_metadata",description:"Metadata for user schema",business_owners:["owner@example.com"],team:"data-engineering",governance_rules:{data_retention:{days:2555},access_control:{level:"public"}}},version:"1.0.0"},exampleCode:`from pycharter import PostgresMetadataStore

store = PostgresMetadataStore(connection_string)
store.connect()

# Store metadata for a schema
metadata_id = store.store_metadata(
    schema_id='user_schema',
    metadata={
        'title': 'user_schema_metadata',
        'description': 'Metadata for user schema',
        'business_owners': ['owner@example.com'],
        'team': 'data-engineering',
        'governance_rules': {
            'data_retention': {'days': 2555},
            'access_control': {'level': 'public'}
        }
    },
    version='1.0.0'
)`,arguments:[{name:"schema_id",type:"str",description:"Schema identifier",required:!0},{name:"metadata",type:"Dict[str, Any]",description:"Metadata dictionary containing ownership, governance_rules, and other metadata",required:!0},{name:"version",type:"Optional[str]",description:"Optional version string (if None, uses schema version)",required:!1,default:"None"}],returns:{type:"str",description:"Metadata record ID"}},{id:"get_metadata",title:"Metadata Store - Get Metadata",description:"Retrieve metadata for a schema from the metadata store",method:"store.get_metadata(schema_id, version=None)",apiEndpoint:"/api/v1/metadata/metadata/{schema_id}",apiMethod:"GET",exampleRequest:null,exampleCode:`from pycharter import PostgresMetadataStore

store = PostgresMetadataStore(connection_string)
store.connect()

# Get metadata for a schema
metadata = store.get_metadata(
    schema_id='user_schema',
    version='1.0.0'  # Optional, defaults to latest
)`,arguments:[{name:"schema_id",type:"str",description:"Schema identifier",required:!0},{name:"version",type:"Optional[str]",description:"Optional version string (if None, uses latest version)",required:!1,default:"None"}],returns:{type:"Optional[Dict[str, Any]]",description:"Metadata dictionary or None if not found"}},{id:"get_complete_schema",title:"Metadata Store - Get Complete Schema",description:"Retrieve a complete schema with coercion and validation rules merged",method:"store.get_complete_schema(schema_id, version=None)",apiEndpoint:"/api/v1/metadata/schemas/{schema_id}/complete",apiMethod:"GET",exampleRequest:null,exampleCode:`from pycharter import PostgresMetadataStore

store = PostgresMetadataStore(connection_string)
store.connect()

# Get complete schema with rules merged
complete_schema = store.get_complete_schema(
    schema_id='user_schema',
    version='1.0.0'  # Optional, defaults to latest
)
# The schema now includes coercion and validation rules
# merged into the properties`,arguments:[{name:"schema_id",type:"str",description:"Schema identifier",required:!0},{name:"version",type:"Optional[str]",description:"Optional version string (if None, defaults to latest)",required:!1,default:"None"}],returns:{type:"Optional[Dict[str, Any]]",description:"Complete schema dictionary with coercion and validation rules merged into the properties, or None if not found"}},{id:"store_coercion_rules",title:"Metadata Store - Store Coercion Rules",description:"Store coercion rules that define how data should be transformed before validation",method:"store.store_coercion_rules(schema_id, coercion_rules, version=None)",apiEndpoint:"/api/v1/metadata/coercion-rules",apiMethod:"POST",exampleRequest:{schema_id:"user_schema",coercion_rules:{age:"coerce_to_integer",email:"coerce_to_lowercase",price:"coerce_to_float",name:"coerce_to_stripped_string"},version:"1.0.0"},exampleCode:`from pycharter import PostgresMetadataStore

store = PostgresMetadataStore(connection_string)
store.connect()

# Store coercion rules for a schema
rule_id = store.store_coercion_rules(
    schema_id='user_schema',
    coercion_rules={
        'age': 'coerce_to_integer',
        'email': 'coerce_to_lowercase',
        'name': 'coerce_to_stripped_string'
    },
    version='1.0.0'
)`,arguments:[{name:"schema_id",type:"str",description:"Schema identifier",required:!0},{name:"coercion_rules",type:"Dict[str, Any]",description:'Dictionary mapping field names to coercion rule types (e.g., "coerce_to_integer", "coerce_to_lowercase")',required:!0},{name:"version",type:"Optional[str]",description:"Optional version string (if None, uses schema version)",required:!1,default:"None"}],returns:{type:"str",description:"Coercion rule record ID"}},{id:"get_coercion_rules",title:"Metadata Store - Get Coercion Rules",description:"Retrieve coercion rules for a schema from the metadata store",method:"store.get_coercion_rules(schema_id, version=None)",apiEndpoint:"/api/v1/metadata/coercion-rules/{schema_id}",apiMethod:"GET",exampleRequest:null,exampleCode:`from pycharter import PostgresMetadataStore

store = PostgresMetadataStore(connection_string)
store.connect()

# Get coercion rules for a schema
coercion_rules = store.get_coercion_rules(
    schema_id='user_schema',
    version='1.0.0'  # Optional, defaults to latest
)`,arguments:[{name:"schema_id",type:"str",description:"Schema identifier",required:!0},{name:"version",type:"Optional[str]",description:"Optional version string (if None, defaults to latest)",required:!1,default:"None"}],returns:{type:"Optional[Dict[str, Any]]",description:"Coercion rules dictionary mapping field names to coercion types, or None if not found"}},{id:"store_validation_rules",title:"Metadata Store - Store Validation Rules",description:"Store validation rules that define custom validation logic beyond JSON Schema",method:"store.store_validation_rules(schema_id, validation_rules, version=None)",apiEndpoint:"/api/v1/metadata/validation-rules",apiMethod:"POST",exampleRequest:{schema_id:"user_schema",validation_rules:{age:{greater_than_or_equal_to:{threshold:0},less_than_or_equal_to:{threshold:150}},email:{min_length:{threshold:5},matches_pattern:{pattern:"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"}}},version:"1.0.0"},exampleCode:`from pycharter import PostgresMetadataStore

store = PostgresMetadataStore(connection_string)
store.connect()

# Store validation rules for a schema
rule_id = store.store_validation_rules(
    schema_id='user_schema',
    validation_rules={
        'age': {
            'greater_than_or_equal_to': {'threshold': 0},
            'less_than_or_equal_to': {'threshold': 150}
        },
        'email': {
            'min_length': {'threshold': 5},
            'matches_pattern': {'pattern': '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$'}
        }
    },
    version='1.0.0'
)`,arguments:[{name:"schema_id",type:"str",description:"Schema identifier",required:!0},{name:"validation_rules",type:"Dict[str, Any]",description:'Dictionary mapping field names to validation rule dictionaries (e.g., {"age": {"greater_than_or_equal_to": {"threshold": 0}}})',required:!0},{name:"version",type:"Optional[str]",description:"Optional version string (if None, uses schema version)",required:!1,default:"None"}],returns:{type:"str",description:"Validation rule record ID"}},{id:"get_validation_rules",title:"Metadata Store - Get Validation Rules",description:"Retrieve validation rules for a schema from the metadata store",method:"store.get_validation_rules(schema_id, version=None)",apiEndpoint:"/api/v1/metadata/validation-rules/{schema_id}",apiMethod:"GET",exampleRequest:null,exampleCode:`from pycharter import PostgresMetadataStore

store = PostgresMetadataStore(connection_string)
store.connect()

# Get validation rules for a schema
validation_rules = store.get_validation_rules(
    schema_id='user_schema',
    version='1.0.0'  # Optional, defaults to latest
)`,arguments:[{name:"schema_id",type:"str",description:"Schema identifier",required:!0},{name:"version",type:"Optional[str]",description:"Optional version string (if None, defaults to latest)",required:!1,default:"None"}],returns:{type:"Optional[Dict[str, Any]]",description:"Validation rules dictionary mapping field names to validation rule dictionaries, or None if not found"}},{id:"generate_model",title:"Pydantic Generator",description:"Generate Pydantic models from JSON Schema",method:'generate_model(schema, model_name="DynamicModel")',apiEndpoint:"/api/v1/schemas/generate",apiMethod:"POST",exampleRequest:{schema:{type:"object",properties:{name:{type:"string"},age:{type:"integer"}}},model_name:"User"},exampleCode:`from pycharter import generate_model, generate_model_file, from_dict, from_file, from_json, from_url

# Advanced: More control
UserModel = generate_model(schema_dict, model_name="User")

# Quick helpers: Generate and return model
UserModel = from_dict(schema_dict)  # From dictionary
UserModel = from_file("schema.json")  # From file
UserModel = from_json(json_string)  # From JSON string
UserModel = from_url("https://example.com/schema.json")  # From URL

# Generate model and save to file
generate_model_file(schema_dict, "models.py", model_name="User")`,arguments:[{name:"schema",type:"Dict[str, Any]",description:"JSON Schema dictionary",required:!0},{name:"model_name",type:"str",description:"Name for the generated Pydantic model class",required:!1,default:'"DynamicModel"'}],returns:{type:"Type[BaseModel]",description:"A Pydantic model class generated from the schema"}},{id:"from_dict",title:"Generate Model from Dict",description:"Quick helper: Generate Pydantic model from JSON Schema dictionary",method:"from_dict(schema_dict)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import from_dict

schema = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "age": {"type": "integer"}
    }
}

UserModel = from_dict(schema)
user = UserModel(name="Alice", age=30)`,arguments:[{name:"schema_dict",type:"Dict[str, Any]",description:"JSON Schema dictionary",required:!0}],returns:{type:"Type[BaseModel]",description:"Pydantic model class generated from the schema"}},{id:"from_file",title:"Generate Model from File",description:"Quick helper: Generate Pydantic model from JSON Schema file",method:"from_file(file_path)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import from_file

UserModel = from_file("schema.json")
# or
UserModel = from_file("schema.yaml")`,arguments:[{name:"file_path",type:"str",description:"Path to JSON Schema file (JSON or YAML)",required:!0}],returns:{type:"Type[BaseModel]",description:"Pydantic model class generated from the schema file"}},{id:"from_json",title:"Generate Model from JSON String",description:"Quick helper: Generate Pydantic model from JSON Schema JSON string",method:"from_json(json_string)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import from_json

json_schema = '{"type": "object", "properties": {"name": {"type": "string"}}}'
UserModel = from_json(json_schema)`,arguments:[{name:"json_string",type:"str",description:"JSON Schema as JSON string",required:!0}],returns:{type:"Type[BaseModel]",description:"Pydantic model class generated from the JSON string"}},{id:"from_url",title:"Generate Model from URL",description:"Quick helper: Generate Pydantic model from JSON Schema URL",method:"from_url(url)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import from_url

UserModel = from_url("https://example.com/schema.json")`,arguments:[{name:"url",type:"str",description:"URL to JSON Schema file",required:!0}],returns:{type:"Type[BaseModel]",description:"Pydantic model class generated from the URL"}},{id:"generate_model_file",title:"Generate Model File",description:"Generate Pydantic model and save to Python file",method:'generate_model_file(schema, output_file, model_name="DynamicModel")',apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import generate_model_file

schema = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "age": {"type": "integer"}
    }
}

generate_model_file(
    schema=schema,
    output_file="models.py",
    model_name="User"
)`,arguments:[{name:"schema",type:"Dict[str, Any]",description:"JSON Schema dictionary",required:!0},{name:"output_file",type:"str",description:"Path to output Python file",required:!0},{name:"model_name",type:"str",description:"Name for the generated Pydantic model class",required:!1,default:'"DynamicModel"'}],returns:{type:"None",description:"Saves the generated model to the specified file"}},{id:"model_to_schema",title:"JSON Schema Converter (Advanced)",description:"Convert Pydantic models to JSON Schema - core conversion function",method:"model_to_schema(model_class)",apiEndpoint:"/api/v1/schemas/convert",apiMethod:"POST",exampleRequest:{model_class:"pydantic.BaseModel"},exampleCode:`from pycharter import model_to_schema
from pydantic import BaseModel

class UserModel(BaseModel):
    name: str
    age: int

schema = model_to_schema(UserModel)
print(schema)`,arguments:[{name:"model_class",type:"Type[BaseModel] | str",description:'Pydantic model class or fully qualified class name (e.g., "mymodule.UserModel")',required:!0}],returns:{type:"Dict[str, Any]",description:"JSON Schema dictionary with optional title and version fields"}},{id:"to_dict",title:"Convert Model to Dict",description:"Quick helper: Convert Pydantic model to JSON Schema dictionary",method:"to_dict(model_class)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import to_dict
from pydantic import BaseModel

class UserModel(BaseModel):
    name: str
    age: int

schema = to_dict(UserModel)`,arguments:[{name:"model_class",type:"Type[BaseModel] | str",description:"Pydantic model class or fully qualified class name",required:!0}],returns:{type:"Dict[str, Any]",description:"JSON Schema dictionary"}},{id:"to_json",title:"Convert Model to JSON String",description:"Quick helper: Convert Pydantic model to JSON Schema JSON string",method:"to_json(model_class)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import to_json
from pydantic import BaseModel

class UserModel(BaseModel):
    name: str
    age: int

json_schema = to_json(UserModel)
print(json_schema)`,arguments:[{name:"model_class",type:"Type[BaseModel] | str",description:"Pydantic model class or fully qualified class name",required:!0}],returns:{type:"str",description:"JSON Schema as JSON string"}},{id:"to_file",title:"Convert Model to File",description:"Quick helper: Convert Pydantic model to JSON Schema file",method:"to_file(model_class, file_path)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import to_file
from pydantic import BaseModel

class UserModel(BaseModel):
    name: str
    age: int

to_file(UserModel, "schema.json")
# or
to_file(UserModel, "schema.yaml")`,arguments:[{name:"model_class",type:"Type[BaseModel] | str",description:"Pydantic model class or fully qualified class name",required:!0},{name:"file_path",type:"str",description:"Path to output file (JSON or YAML)",required:!0}],returns:{type:"None",description:"Saves the JSON Schema to the specified file"}},{id:"validator_class",title:"Validator Class (PRIMARY INTERFACE)",description:"⭐ PRIMARY: Use Validator class for all validation - best performance and flexibility",method:"Validator(contract_dir=None, contract_file=None, contract_dict=None, contract_metadata=None, store=None, schema_id=None, schema_version=None)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import Validator, ValidatorBuilder, create_validator
from pycharter.metadata_store import SQLiteMetadataStore

# From contract directory
validator = Validator(contract_dir="data/contracts/user")
result = validator.validate({"name": "Alice", "age": 30})

# From metadata store
store = SQLiteMetadataStore("metadata.db")
store.connect()
validator = Validator(store=store, schema_id="user_schema")
result = validator.validate({"name": "Alice", "age": 30})

# Using ValidatorBuilder (fluent API)
validator = (
    ValidatorBuilder()
    .from_directory("data/contracts/user")
    .strict()
    .with_quality_checks({"completeness": 0.95})
    .build()
)
result = validator.validate({"name": "Alice", "age": 30})
print(result.quality.completeness)  # Quality metrics included

# Batch validation
results = validator.validate_batch([
    {"name": "Alice", "age": 30},
    {"name": "Bob", "age": 25}
])

# Factory function
validator = create_validator(contract_file="contract.yaml")`,arguments:[{name:"contract_dir",type:"Optional[str]",description:"Directory containing contract files (schema.yaml, coercion_rules.yaml, validation_rules.yaml)",required:!1},{name:"contract_file",type:"Optional[str]",description:"Path to complete contract file (YAML/JSON)",required:!1},{name:"contract_dict",type:"Optional[Dict[str, Any]]",description:"Contract as dictionary with schema, coercion_rules, validation_rules keys",required:!1},{name:"contract_metadata",type:"Optional[ContractMetadata]",description:"ContractMetadata object (from parse_contract)",required:!1},{name:"store",type:"Optional[MetadataStoreClient]",description:"MetadataStoreClient instance (for loading from metadata store)",required:!1},{name:"schema_id",type:"Optional[str]",description:"Schema identifier (required when using store)",required:!1},{name:"schema_version",type:"Optional[str]",description:"Optional schema version (defaults to latest when using store)",required:!1}],returns:{type:"Validator",description:"Validator instance with validate() and validate_batch() methods"}},{id:"validator_builder",title:"ValidatorBuilder (Fluent API)",description:"Fluent builder pattern for constructing validators with configuration options like strict mode and quality checks",method:"ValidatorBuilder().from_directory(path).strict().with_quality_checks(thresholds).build()",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import ValidatorBuilder

# Basic usage
validator = (
    ValidatorBuilder()
    .from_directory("data/contracts/user")
    .build()
)

# With strict mode (raises exceptions on errors)
validator = (
    ValidatorBuilder()
    .from_file("contracts/user.yaml")
    .strict()
    .build()
)

# With quality checks
validator = (
    ValidatorBuilder()
    .from_dict(contract_dict)
    .with_quality_checks({"completeness": 0.95, "validity_rate": 0.99})
    .build()
)

# From metadata store
validator = (
    ValidatorBuilder()
    .from_store(store, "user_schema", version="1.0.0")
    .lenient()
    .with_quality_checks()
    .build()
)

# Validate with quality metrics
result = validator.validate(data, include_quality=True)
if result.quality:
    print(f"Completeness: {result.quality.completeness}")
    print(f"Validity rate: {result.quality.validity_rate}")`,arguments:[{name:"from_directory(path)",type:"method",description:"Load contract from directory containing schema.yaml, coercion_rules.yaml, validation_rules.yaml",required:!1},{name:"from_file(path)",type:"method",description:"Load contract from a single file (YAML/JSON)",required:!1},{name:"from_dict(contract_dict)",type:"method",description:"Load contract from dictionary",required:!1},{name:"from_store(store, schema_id, version)",type:"method",description:"Load contract from metadata store",required:!1},{name:"strict()",type:"method",description:"Enable strict mode - raises exceptions on validation errors",required:!1},{name:"lenient()",type:"method",description:"Enable lenient mode (default) - returns errors in ValidationResult",required:!1},{name:"with_quality_checks(thresholds)",type:"method",description:"Enable quality metrics calculation during validation. Optional thresholds dict for pass/fail criteria.",required:!1},{name:"build()",type:"method",description:"Build and return the configured Validator instance",required:!0}],returns:{type:"Validator",description:"Configured Validator instance with the specified options"}},{id:"validation_quality_metrics",title:"ValidationResult Quality Metrics",description:"Quality metrics included in ValidationResult when quality checks are enabled",method:"result.quality (QualityMetrics)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import Validator, ValidatorBuilder

# Enable quality checks via builder
validator = (
    ValidatorBuilder()
    .from_directory("data/contracts/user")
    .with_quality_checks()
    .build()
)

# Single validation with quality
result = validator.validate(data, include_quality=True)
if result.is_valid:
    print(f"Valid! Quality score: {result.quality.completeness:.2%}")
else:
    print(f"Invalid. Errors: {result.errors}")

# Batch validation with quality
results = validator.validate_batch(data_list, include_quality=True)
last_result = results[-1]  # Quality metrics on last result
print(f"Valid: {last_result.quality.valid_count}/{last_result.quality.record_count}")
print(f"Validity rate: {last_result.quality.validity_rate:.2%}")

# Check against thresholds
thresholds = {"completeness": 0.95, "validity_rate": 0.99}
if last_result.quality.passes_thresholds(thresholds):
    print("Quality thresholds passed!")`,arguments:[{name:"completeness",type:"float",description:"Ratio of non-null fields (0.0 to 1.0)",required:!1},{name:"field_completeness",type:"Dict[str, float]",description:"Per-field completeness ratios",required:!1},{name:"record_count",type:"int",description:"Total number of records validated",required:!1},{name:"valid_count",type:"int",description:"Number of valid records",required:!1},{name:"error_count",type:"int",description:"Number of records with errors",required:!1},{name:"validity_rate",type:"float (property)",description:"Ratio of valid records (valid_count / record_count)",required:!1}],returns:{type:"QualityMetrics",description:"Quality metrics object with completeness, validity rate, and per-field metrics"}},{id:"error_handling",title:"Error Handling Modes",description:"Standardized error handling with STRICT, LENIENT, and COLLECT modes for consistent behavior across pycharter",method:"ErrorMode, StrictMode, LenientMode, set_error_mode()",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import ErrorMode, StrictMode, LenientMode, set_error_mode

# Set global error mode
set_error_mode(ErrorMode.STRICT)   # Raise exceptions
set_error_mode(ErrorMode.LENIENT)  # Log warnings (default)
set_error_mode(ErrorMode.COLLECT)  # Collect errors

# Context manager for temporary strict mode
from pycharter import Validator

validator = Validator(contract_dir="data/contracts/user")

with StrictMode():
    # Errors will raise exceptions in this block
    result = validator.validate(data)  # Raises on error

# Back to default lenient mode
result = validator.validate(data)  # Returns ValidationResult with errors

# Context manager for lenient mode
with LenientMode():
    # Errors are logged as warnings
    result = validator.validate(data)

# Using ErrorContext for collecting errors
from pycharter.shared import ErrorContext, ErrorMode

ctx = ErrorContext(mode=ErrorMode.COLLECT)
ctx.handle_error("Field 'name' is missing", category="validation")
ctx.handle_error("Field 'age' must be positive", category="validation")

print(f"Has errors: {ctx.has_errors}")
print(f"Errors: {ctx.errors}")
ctx.raise_if_errors()  # Raises ValueError with all errors`,arguments:[{name:"ErrorMode.STRICT",type:"enum",description:"Raise exceptions immediately on any error",required:!1},{name:"ErrorMode.LENIENT",type:"enum",description:"Log warnings and continue with best effort (default)",required:!1},{name:"ErrorMode.COLLECT",type:"enum",description:"Collect errors and return them with results",required:!1},{name:"StrictMode",type:"context manager",description:"Context manager for temporarily enabling strict mode",required:!1},{name:"LenientMode",type:"context manager",description:"Context manager for temporarily enabling lenient mode",required:!1},{name:"set_error_mode(mode)",type:"function",description:"Set the default error handling mode globally",required:!1}],returns:{type:"None / ErrorContext",description:"Context managers return None; ErrorContext for collecting errors"}},{id:"validate_with_store",title:"Validate with Store (Convenience)",description:"Quick validation using schema from metadata store",method:"validate_with_store(store, schema_id, data, version=None, strict=False)",apiEndpoint:"/api/v1/validation/validate",apiMethod:"POST",exampleRequest:{schema_id:"user_schema",data:{name:"Alice",age:30},version:"1.0.0",strict:!1},exampleCode:`from pycharter import validate_with_store
from pycharter.metadata_store import SQLiteMetadataStore

store = SQLiteMetadataStore("metadata.db")
store.connect()

result = validate_with_store(
    store=store,
    schema_id="user_schema",
    data={"name": "Alice", "age": 30},
    version="1.0.0"
)

if result.is_valid:
    print("Valid data:", result.data)
else:
    print("Errors:", result.errors)`,arguments:[{name:"store",type:"MetadataStoreClient",description:"MetadataStoreClient instance",required:!0},{name:"schema_id",type:"str",description:"Schema identifier",required:!0},{name:"data",type:"Dict[str, Any]",description:"Data dictionary to validate",required:!0},{name:"version",type:"Optional[str]",description:"Optional schema version (if None, uses latest)",required:!1,default:"None"},{name:"strict",type:"bool",description:"If True, raise exceptions on validation errors",required:!1,default:"False"}],returns:{type:"ValidationResult",description:"ValidationResult object with is_valid flag, validated data (if valid), and list of errors (if invalid)"}},{id:"validate_with_contract",title:"Validate with Contract (Convenience)",description:"Quick validation using contract dictionary or file",method:"validate_with_contract(contract, data, strict=False)",apiEndpoint:"/api/v1/validation/validate",apiMethod:"POST",exampleRequest:{contract:{schema:{type:"object",properties:{name:{type:"string"},age:{type:"integer"}}}},data:{name:"Alice",age:30},strict:!1},exampleCode:`from pycharter import validate_with_contract

contract = {
    "schema": {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"}
        }
    }
}

result = validate_with_contract(
    contract=contract,
    data={"name": "Alice", "age": 30}
)

# Or from file
result = validate_with_contract(
    contract="contracts/user.yaml",
    data={"name": "Alice", "age": 30}
)`,arguments:[{name:"contract",type:"Dict[str, Any] | ContractMetadata | str",description:"Contract dictionary, ContractMetadata object, or file path",required:!0},{name:"data",type:"Dict[str, Any]",description:"Data dictionary to validate",required:!0},{name:"strict",type:"bool",description:"If True, raise exceptions on validation errors",required:!1,default:"False"}],returns:{type:"ValidationResult",description:"ValidationResult object with is_valid flag, validated data (if valid), and list of errors (if invalid)"}},{id:"validate_batch_with_store",title:"Batch Validate with Store",description:"Validate multiple records using schema from metadata store",method:"validate_batch_with_store(store, schema_id, data_list, version=None, strict=False)",apiEndpoint:"/api/v1/validation/validate-batch",apiMethod:"POST",exampleRequest:{schema_id:"user_schema",data_list:[{name:"Alice",age:30},{name:"Bob",age:25}],version:"1.0.0",strict:!1},exampleCode:`from pycharter import validate_batch_with_store
from pycharter.metadata_store import SQLiteMetadataStore

store = SQLiteMetadataStore("metadata.db")
store.connect()

results = validate_batch_with_store(
    store=store,
    schema_id="user_schema",
    data_list=[
        {"name": "Alice", "age": 30},
        {"name": "Bob", "age": 25}
    ],
    version="1.0.0"
)

print(f"Valid: {results.total_count - len(results.errors)}/{results.total_count}")`,arguments:[{name:"store",type:"MetadataStoreClient",description:"MetadataStoreClient instance",required:!0},{name:"schema_id",type:"str",description:"Schema identifier",required:!0},{name:"data_list",type:"List[Dict[str, Any]]",description:"List of data dictionaries to validate",required:!0},{name:"version",type:"Optional[str]",description:"Optional schema version (if None, uses latest)",required:!1,default:"None"},{name:"strict",type:"bool",description:"If True, raise exceptions on validation errors",required:!1,default:"False"}],returns:{type:"ValidationBatchResponse",description:"Batch validation results with total_count, valid_count, error_count, and results list"}},{id:"validate_batch_with_contract",title:"Batch Validate with Contract",description:"Validate multiple records using contract dictionary or file",method:"validate_batch_with_contract(contract, data_list, strict=False)",apiEndpoint:"/api/v1/validation/validate-batch",apiMethod:"POST",exampleRequest:{contract:{schema:{type:"object",properties:{name:{type:"string"},age:{type:"integer"}}}},data_list:[{name:"Alice",age:30},{name:"Bob",age:25}],strict:!1},exampleCode:`from pycharter import validate_batch_with_contract

contract = {
    "schema": {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"}
        }
    }
}

results = validate_batch_with_contract(
    contract=contract,
    data_list=[
        {"name": "Alice", "age": 30},
        {"name": "Bob", "age": 25}
    ]
)`,arguments:[{name:"contract",type:"Dict[str, Any] | ContractMetadata | str",description:"Contract dictionary, ContractMetadata object, or file path",required:!0},{name:"data_list",type:"List[Dict[str, Any]]",description:"List of data dictionaries to validate",required:!0},{name:"strict",type:"bool",description:"If True, raise exceptions on validation errors",required:!1,default:"False"}],returns:{type:"ValidationBatchResponse",description:"Batch validation results with total_count, valid_count, error_count, and results list"}},{id:"get_model_from_store",title:"Get Model from Store",description:"Get Pydantic model class from schema stored in metadata store",method:"get_model_from_store(store, schema_id, version=None)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import get_model_from_store
from pycharter.metadata_store import SQLiteMetadataStore

store = SQLiteMetadataStore("metadata.db")
store.connect()

# Get Pydantic model class
UserModel = get_model_from_store(
    store=store,
    schema_id="user_schema",
    version="1.0.0"
)

# Use the model directly
user = UserModel(name="Alice", age=30)
print(user.model_dump())`,arguments:[{name:"store",type:"MetadataStoreClient",description:"MetadataStoreClient instance",required:!0},{name:"schema_id",type:"str",description:"Schema identifier",required:!0},{name:"version",type:"Optional[str]",description:"Optional schema version (if None, uses latest)",required:!1,default:"None"}],returns:{type:"Type[BaseModel]",description:"Pydantic model class generated from the schema"}},{id:"get_model_from_contract",title:"Get Model from Contract",description:"Get Pydantic model class from contract dictionary or file",method:"get_model_from_contract(contract)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import get_model_from_contract

contract = {
    "schema": {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"}
        }
    }
}

# Get Pydantic model class
UserModel = get_model_from_contract(contract)

# Use the model directly
user = UserModel(name="Alice", age=30)
print(user.model_dump())

# Or from file
UserModel = get_model_from_contract("contracts/user.yaml")`,arguments:[{name:"contract",type:"Dict[str, Any] | ContractMetadata | str",description:"Contract dictionary, ContractMetadata object, or file path",required:!0}],returns:{type:"Type[BaseModel]",description:"Pydantic model class generated from the contract schema"}},{id:"validate",title:"Validate (Low-level)",description:"Low-level validation with existing Pydantic model",method:"validate(data, model, coercion_rules=None, validation_rules=None, strict=False)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import validate
from pydantic import BaseModel

# Define model manually or get from contract
class UserModel(BaseModel):
    name: str
    age: int

# Validate with model
result = validate(
    data={"name": "Alice", "age": 30},
    model=UserModel,
    coercion_rules=None,
    validation_rules=None
)

if result.is_valid:
    print("Valid:", result.data)
else:
    print("Errors:", result.errors)`,arguments:[{name:"data",type:"Dict[str, Any]",description:"Data dictionary to validate",required:!0},{name:"model",type:"Type[BaseModel]",description:"Pydantic model class",required:!0},{name:"coercion_rules",type:"Optional[Dict[str, Any]]",description:"Optional coercion rules dictionary",required:!1,default:"None"},{name:"validation_rules",type:"Optional[Dict[str, Any]]",description:"Optional validation rules dictionary",required:!1,default:"None"},{name:"strict",type:"bool",description:"If True, raise exceptions on validation errors",required:!1,default:"False"}],returns:{type:"ValidationResult",description:"ValidationResult object with is_valid flag, validated data (if valid), and list of errors (if invalid)"}},{id:"validate_batch",title:"Batch Validate (Low-level)",description:"Low-level batch validation with existing Pydantic model",method:"validate_batch(data_list, model, coercion_rules=None, validation_rules=None, strict=False)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import validate_batch
from pydantic import BaseModel

# Define model manually or get from contract
class UserModel(BaseModel):
    name: str
    age: int

# Batch validate with model
results = validate_batch(
    data_list=[
        {"name": "Alice", "age": 30},
        {"name": "Bob", "age": 25}
    ],
    model=UserModel
)

print(f"Valid: {results.valid_count}/{results.total_count}")`,arguments:[{name:"data_list",type:"List[Dict[str, Any]]",description:"List of data dictionaries to validate",required:!0},{name:"model",type:"Type[BaseModel]",description:"Pydantic model class",required:!0},{name:"coercion_rules",type:"Optional[Dict[str, Any]]",description:"Optional coercion rules dictionary",required:!1,default:"None"},{name:"validation_rules",type:"Optional[Dict[str, Any]]",description:"Optional validation rules dictionary",required:!1,default:"None"},{name:"strict",type:"bool",description:"If True, raise exceptions on validation errors",required:!1,default:"False"}],returns:{type:"ValidationBatchResponse",description:"Batch validation results with total_count, valid_count, error_count, and results list"}},{id:"quality_check",title:"QualityCheck Class (PRIMARY INTERFACE)",description:"⭐ PRIMARY: Use QualityCheck class for quality assurance - monitor data quality, calculate metrics, and track violations",method:"QualityCheck(store=None, db_session=None).run(schema_id=None, contract=None, data=None, options=None)",apiEndpoint:"/api/v1/quality/check",apiMethod:"POST",exampleRequest:{schema_id:"user_schema",data:[{name:"Alice",age:30},{name:"Bob",age:25}],calculate_metrics:!0,record_violations:!0},exampleCode:`from pycharter import QualityCheck, QualityCheckOptions, QualityReport, QualityThresholds
from pycharter.metadata_store import SQLiteMetadataStore
from sqlalchemy.orm import Session

# Create quality check instance
store = SQLiteMetadataStore("metadata.db")
store.connect()
db_session = Session()  # Your database session

check = QualityCheck(store=store, db_session=db_session)

# Configure options
options = QualityCheckOptions(
    record_violations=True,
    calculate_metrics=True,
    check_thresholds=True,
    include_field_metrics=True,
    sample_size=None  # Process all data
)

# Set thresholds (optional)
thresholds = QualityThresholds(
    overall_score_min=80.0,
    accuracy_min=95.0,
    completeness_min=90.0
)

# Run quality check
report = check.run(
    schema_id='user_schema',
    data="data/users.json",  # File path, list, or callable
    options=options
)

# Access results
print(f"Quality Score: {report.quality_score.overall_score:.2f}/100")
print(f"Passed: {report.passed}")
print(f"Metrics: {report.metrics}")
print(f"Violations: {len(report.violations)}")`,arguments:[{name:"store",type:"Optional[MetadataStoreClient]",description:"Optional metadata store for retrieving contracts and storing violations",required:!1,default:"None"},{name:"db_session",type:"Optional[Session]",description:"Optional SQLAlchemy database session for persisting metrics and violations",required:!1,default:"None"},{name:"schema_id",type:"Optional[str]",description:"Schema ID (if using store-based validation)",required:!1},{name:"contract",type:"Optional[Dict[str, Any] | str]",description:"Contract dictionary or file path (if using contract-based validation)",required:!1},{name:"data",type:"List[Dict[str, Any]] | str | Callable",description:"Data to validate. Can be a list of dictionaries, file path (JSON/CSV), or callable that returns data",required:!0},{name:"options",type:"Optional[QualityCheckOptions]",description:"Quality check options including record_violations, calculate_metrics, check_thresholds, include_field_metrics, sample_size, data_source, data_version, etc.",required:!1,default:"None"}],returns:{type:"QualityReport",description:"QualityReport object containing validation results, quality score (QualityScore), field metrics (FieldQualityMetrics), violations (List[ViolationRecord]), and threshold breaches"}},{id:"quality_check_options",title:"QualityCheckOptions",description:"Configuration options for quality checks",method:"QualityCheckOptions(record_violations=True, calculate_metrics=True, check_thresholds=False, include_field_metrics=True, sample_size=None, data_source=None, data_version=None, skip_if_unchanged=False)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import QualityCheckOptions

options = QualityCheckOptions(
    record_violations=True,      # Record violations to database
    calculate_metrics=True,      # Calculate quality metrics
    check_thresholds=False,      # Check against quality thresholds
    include_field_metrics=True,  # Include field-level metrics
    sample_size=1000,            # Sample size for large datasets
    data_source="users.csv",     # Data source identifier
    data_version="v1.0",         # Data version identifier
    skip_if_unchanged=True       # Skip if data hasn't changed
)`,arguments:[{name:"record_violations",type:"bool",description:"Whether to record violations to database",required:!1,default:"True"},{name:"calculate_metrics",type:"bool",description:"Whether to calculate quality metrics",required:!1,default:"True"},{name:"check_thresholds",type:"bool",description:"Whether to check against quality thresholds",required:!1,default:"False"},{name:"include_field_metrics",type:"bool",description:"Whether to include field-level quality metrics",required:!1,default:"True"},{name:"sample_size",type:"Optional[int]",description:"Sample size for large datasets (None = process all)",required:!1,default:"None"},{name:"data_source",type:"Optional[str]",description:"Data source identifier (e.g., file name)",required:!1,default:"None"},{name:"data_version",type:"Optional[str]",description:"Data version identifier",required:!1,default:"None"},{name:"skip_if_unchanged",type:"bool",description:"Skip quality check if data fingerprint hasn't changed",required:!1,default:"False"}],returns:{type:"QualityCheckOptions",description:"QualityCheckOptions instance for configuring quality checks"}},{id:"quality_thresholds",title:"QualityThresholds",description:"Define quality thresholds for monitoring and alerting",method:"QualityThresholds(overall_score_min=None, accuracy_min=None, completeness_min=None, violation_rate_max=None, field_thresholds=None)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import QualityThresholds

thresholds = QualityThresholds(
    overall_score_min=80.0,        # Minimum overall quality score
    accuracy_min=95.0,              # Minimum accuracy percentage
    completeness_min=90.0,           # Minimum completeness percentage
    violation_rate_max=0.05,        # Maximum violation rate (5%)
    field_thresholds={              # Field-specific thresholds
        "email": {"completeness_min": 98.0},
        "age": {"accuracy_min": 99.0}
    }
)`,arguments:[{name:"overall_score_min",type:"Optional[float]",description:"Minimum overall quality score (0-100)",required:!1,default:"None"},{name:"accuracy_min",type:"Optional[float]",description:"Minimum accuracy percentage (0-100)",required:!1,default:"None"},{name:"completeness_min",type:"Optional[float]",description:"Minimum completeness percentage (0-100)",required:!1,default:"None"},{name:"violation_rate_max",type:"Optional[float]",description:"Maximum violation rate (0-1)",required:!1,default:"None"},{name:"field_thresholds",type:"Optional[Dict[str, Dict[str, float]]]",description:'Field-specific thresholds (e.g., {"email": {"completeness_min": 98.0}})',required:!1,default:"None"}],returns:{type:"QualityThresholds",description:"QualityThresholds instance for defining quality requirements"}},{id:"pipeline_class",title:"Pipeline Class (NEW - PRIMARY)",description:"⭐ NEW: Build ETL pipelines with | operator for fluent, composable pipelines. Supports both programmatic and config-driven approaches.",method:"Pipeline(extractor) | transformer | loader",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import (
    Pipeline, PipelineBuilder, PipelineContext,
    HTTPExtractor, PostgresLoader,
    Rename, AddField, Filter, Convert, Drop
)

# Programmatic pipeline with | operator
pipeline = (
    Pipeline(HTTPExtractor(url="https://api.example.com/users"))
    | Rename({"userName": "name", "userAge": "age"})
    | AddField("processed_at", lambda r: datetime.now().isoformat())
    | Filter(lambda r: r["age"] >= 18)
    | Convert({"age": int, "salary": float})
    | PostgresLoader(connection_string="...", table="users")
)

# Run the pipeline
result = await pipeline.run()
print(f"Loaded {result.total_loaded} records")

# Config-driven pipeline (from YAML files)
pipeline = Pipeline.from_config("data/pipelines/users")
result = await pipeline.run()

# With context for variable substitution
context = PipelineContext(extra={"API_KEY": "secret123"})
pipeline = Pipeline.from_config("configs/api_pipeline", context=context)
result = await pipeline.run()`,arguments:[{name:"extractor",type:"Extractor",description:"Extractor instance (HTTPExtractor, FileExtractor, DatabaseExtractor, CloudStorageExtractor)",required:!0},{name:"| transformer",type:"Transformer",description:"Chain transformers using | operator (Rename, AddField, Filter, Convert, Drop, Select, Map, FlatMap)",required:!1},{name:"| loader",type:"Loader",description:"Chain loader at the end (PostgresLoader, FileLoader, CloudStorageLoader)",required:!0}],returns:{type:"PipelineResult",description:"Result with total_extracted, total_transformed, total_loaded, batches, errors, duration_seconds"}},{id:"pipeline_builder",title:"PipelineBuilder (Fluent API)",description:"Alternative fluent API for building pipelines with method chaining",method:"PipelineBuilder().extract(extractor).transform(transformer).load(loader).build()",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import PipelineBuilder, HTTPExtractor, PostgresLoader, Rename, Filter

pipeline = (
    PipelineBuilder()
    .extract(HTTPExtractor(url="https://api.example.com/data"))
    .transform(Rename({"old_name": "new_name"}))
    .transform(Filter(lambda r: r["active"]))
    .load(PostgresLoader(connection_string="...", table="users"))
    .build()
)

result = await pipeline.run()`,arguments:[{name:"extract(extractor)",type:"method",description:"Set the extractor for the pipeline",required:!0},{name:"transform(transformer)",type:"method",description:"Add a transformer (can be called multiple times)",required:!1},{name:"load(loader)",type:"method",description:"Set the loader for the pipeline",required:!0},{name:"build()",type:"method",description:"Build and return the Pipeline instance",required:!0}],returns:{type:"Pipeline",description:"Configured Pipeline instance ready to run"}},{id:"etl_transformers",title:"ETL Transformers",description:"Built-in transformers for data manipulation, chainable with | operator",method:"Rename, AddField, Drop, Select, Filter, Convert, Default, Map, FlatMap, CustomFunction",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import (
    Rename, AddField, Drop, Select, Filter,
    Convert, Default, Map, FlatMap, CustomFunction
)

# Rename fields
rename = Rename({"old_name": "new_name", "userName": "user_name"})

# Add computed fields
add = AddField("full_name", lambda r: f"{r['first']} {r['last']}")

# Drop fields
drop = Drop(["temp_field", "internal_id"])

# Select specific fields only
select = Select(["id", "name", "email"])

# Filter records
filter_active = Filter(lambda r: r.get("active", False))

# Convert types
convert = Convert({"age": int, "price": float, "active": bool})

# Set defaults for missing/null values
defaults = Default({"status": "pending", "count": 0})

# Map - transform each record
map_transform = Map(lambda r: {**r, "name": r["name"].upper()})

# FlatMap - expand records (one-to-many)
flatmap = FlatMap(lambda r: [{"item": i} for i in r.get("items", [])])

# Custom function
def my_transform(records, **kwargs):
    return [r for r in records if r.get("valid")]
custom = CustomFunction(my_transform)

# Chain transformers
chain = Rename({"a": "b"}) | Filter(lambda r: r["x"] > 0) | Convert({"x": int})`,arguments:[{name:"Rename(mapping)",type:"Transformer",description:"Rename fields according to mapping dict",required:!1},{name:"AddField(name, value_or_func)",type:"Transformer",description:"Add a new field with static value or computed from record",required:!1},{name:"Drop(fields)",type:"Transformer",description:"Remove specified fields from records",required:!1},{name:"Select(fields)",type:"Transformer",description:"Keep only specified fields",required:!1},{name:"Filter(predicate)",type:"Transformer",description:"Keep only records matching predicate function",required:!1},{name:"Convert(type_mapping)",type:"Transformer",description:"Convert field types (int, float, str, bool)",required:!1},{name:"Default(defaults)",type:"Transformer",description:"Set default values for missing/null fields",required:!1},{name:"Map(func)",type:"Transformer",description:"Transform each record with function",required:!1},{name:"FlatMap(func)",type:"Transformer",description:"Expand records (one-to-many transformation)",required:!1}],returns:{type:"Transformer / TransformerChain",description:"Transformer instance, chainable with | operator"}},{id:"etl_extractors",title:"ETL Extractors",description:"Built-in extractors for different data sources",method:"HTTPExtractor, FileExtractor, DatabaseExtractor, CloudStorageExtractor",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import (
    HTTPExtractor, FileExtractor,
    DatabaseExtractor, CloudStorageExtractor
)

# HTTP API extraction
http = HTTPExtractor(
    url="https://api.example.com/data",
    method="GET",
    headers={"Authorization": "Bearer token"},
    params={"limit": 100}
)

# File extraction (JSON, CSV, Parquet)
file = FileExtractor(
    file_path="data/input.json",
    file_format="json"
)

# Database extraction
db = DatabaseExtractor(
    connection_string="postgresql://user:pass@host/db",
    query="SELECT * FROM users WHERE active = true"
)

# Cloud storage extraction (S3, GCS, Azure)
cloud = CloudStorageExtractor(
    provider="s3",
    bucket="my-bucket",
    key="data/users.json",
    credentials={"aws_access_key_id": "...", "aws_secret_access_key": "..."}
)

# Config-driven extraction
http_from_config = HTTPExtractor.from_config({
    "base_url": "https://api.example.com",
    "api_endpoint": "/v1/users",
    "method": "GET"
})`,arguments:[{name:"HTTPExtractor",type:"class",description:"Extract from HTTP APIs with pagination support",required:!1},{name:"FileExtractor",type:"class",description:"Extract from local files (JSON, CSV, Parquet, JSONL)",required:!1},{name:"DatabaseExtractor",type:"class",description:"Extract from databases via SQL query",required:!1},{name:"CloudStorageExtractor",type:"class",description:"Extract from cloud storage (S3, GCS, Azure Blob)",required:!1}],returns:{type:"Extractor",description:"Extractor instance implementing the Extractor protocol"}},{id:"etl_loaders",title:"ETL Loaders",description:"Built-in loaders for different destinations",method:"PostgresLoader, DatabaseLoader, FileLoader, CloudStorageLoader",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import PostgresLoader, FileLoader, CloudStorageLoader

# PostgreSQL/Database loading
postgres = PostgresLoader(
    connection_string="postgresql://user:pass@host/db",
    table="users",
    schema="public",
    if_exists="append",  # 'append', 'replace', 'fail'
)

# File loading
file = FileLoader(
    file_path="output/users.json",
    file_format="json",
    mode="w"
)

# Cloud storage loading
cloud = CloudStorageLoader(
    provider="s3",
    bucket="my-bucket",
    key="output/users.parquet",
    file_format="parquet"
)

# Use in pipeline
pipeline = (
    Pipeline(HTTPExtractor(url="..."))
    | Rename({"old": "new"})
    | PostgresLoader(connection_string="...", table="users")
)`,arguments:[{name:"PostgresLoader",type:"class",description:"Load to PostgreSQL database",required:!1},{name:"DatabaseLoader",type:"class",description:"Generic database loader (supports various databases)",required:!1},{name:"FileLoader",type:"class",description:"Load to local files (JSON, CSV, Parquet)",required:!1},{name:"CloudStorageLoader",type:"class",description:"Load to cloud storage (S3, GCS, Azure Blob)",required:!1}],returns:{type:"Loader",description:"Loader instance implementing the Loader protocol"}},{id:"etl_orchestrator",title:"ETL Orchestrator (Legacy)",description:"Config-driven ETL orchestration from contract directories. Use Pipeline class for new projects.",method:"ETLOrchestrator(contract_dir=None, contract_file=None, extract_config=None, transform_config=None, load_config=None, config_context=None, ...)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter.etl_generator import ETLOrchestrator

orchestrator = ETLOrchestrator(contract_dir="path/to/contract_dir")
result = await orchestrator.run()

# With config overrides
orchestrator = ETLOrchestrator(
    contract_dir="contracts/user",
    extract_config={"base_url": "https://api.example.com", "api_endpoint": "/v1/data"},
    transform_config={"rename": {"oldName": "new_name"}},
    load_config={"target_table": "users", "schema_name": "public"}
)
result = await orchestrator.run(dry_run=False)`,arguments:[{name:"contract_dir",type:"Optional[str]",description:"Directory containing schema and extract/transform/load configs",required:!1},{name:"contract_file",type:"Optional[str]",description:"Path to a complete contract file (YAML or JSON)",required:!1},{name:"extract_config",type:"Optional[Dict[str, Any]]",description:"Extract configuration dictionary (overrides extract.yaml when provided)",required:!1},{name:"transform_config",type:"Optional[Dict[str, Any]]",description:"Transform configuration dictionary (overrides transform.yaml when provided)",required:!1},{name:"load_config",type:"Optional[Dict[str, Any]]",description:"Load configuration dictionary (overrides load.yaml when provided)",required:!1},{name:"config_context",type:"Optional[Dict[str, Any]]",description:"Context for resolving ${VAR} placeholders in config files",required:!1}],returns:{type:"ETLOrchestrator",description:"Orchestrator instance; call .run(**kwargs) to execute the pipeline"}},{id:"create_orchestrator",title:"Create Orchestrator",description:"Factory helper that creates an ETLOrchestrator instance from a contract directory.",method:"create_orchestrator(contract_dir=None, **kwargs) -> ETLOrchestrator",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter.etl_generator import create_orchestrator

orchestrator = create_orchestrator(contract_dir="configs/user_pipeline")
result = await orchestrator.run()`,arguments:[{name:"contract_dir",type:"Optional[str]",description:"Directory containing ETL configs (extract.yaml, transform.yaml, load.yaml)",required:!1},{name:"**kwargs",type:"Any",description:"Additional arguments passed through to ETLOrchestrator",required:!1}],returns:{type:"ETLOrchestrator",description:"Orchestrator instance configured for the given contract directory"}},{id:"pipeline_factory",title:"Pipeline Factory",description:"Discover pipelines by scanning a config root for subdirectories that contain extract.yaml, transform.yaml, and load.yaml, and create orchestrators by pipeline name.",method:'PipelineFactory(config_root="configs", excluded_dirs=None, required_files=None)',apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter.etl_generator import PipelineFactory

factory = PipelineFactory(config_root="configs")
names = factory.get_pipeline_names()
orchestrator = factory.create_orchestrator(
    pipeline_name="fmp_key_metrics",
    config_context={"FMP_API_KEY": "your_key"}
)
result = await orchestrator.run(symbol="AAPL")`,arguments:[{name:"config_root",type:"Union[str, Path]",description:"Root directory to scan for pipeline config directories",required:!1,default:'"configs"'},{name:"excluded_dirs",type:"Optional[List[str]]",description:"Directory names to skip during discovery (e.g. old, templates)",required:!1},{name:"required_files",type:"Optional[List[str]]",description:"Files each pipeline directory must contain (default: extract.yaml, transform.yaml, load.yaml)",required:!1}],returns:{type:"PipelineFactory",description:"Factory with get_pipeline_names(), get_contract_dir(name), and create_orchestrator(name, ...)"}},{id:"extract_with_pagination_streaming",title:"Extract with Pagination Streaming",description:"Async generator that yields batches of records. Dispatches to the appropriate extractor by type (http, file, database, cloud_storage) via ExtractorFactory.",method:"extract_with_pagination_streaming(extract_config, params, headers, contract_dir=None, batch_size=1000, max_records=None, config_context=None)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter.etl_generator.extractors import extract_with_pagination_streaming

async for batch in extract_with_pagination_streaming(
    extract_config={"type": "file", "file_path": "data.json"},
    params={},
    headers={},
    batch_size=500
):
    print(len(batch))`,arguments:[{name:"extract_config",type:"Dict[str, Any]",description:"Extract configuration (type is auto-detected if omitted)",required:!0},{name:"params",type:"Dict[str, Any]",description:"Request or query parameters (e.g. for HTTP extractions)",required:!0},{name:"headers",type:"Dict[str, Any]",description:"Request headers (e.g. for HTTP extractions)",required:!0},{name:"contract_dir",type:"Optional[Any]",description:"Contract directory used for variable resolution in configs",required:!1},{name:"batch_size",type:"int",description:"Number of records to yield per batch",required:!1,default:"1000"},{name:"max_records",type:"Optional[int]",description:"Maximum total records to extract (None for no limit)",required:!1},{name:"config_context",type:"Optional[Dict[str, Any]]",description:"Context for resolving ${VAR} placeholders in configs",required:!1}],returns:{type:"AsyncIterator[List[Dict[str, Any]]]",description:"Async iterator yielding batches of record dictionaries"}},{id:"apply_transforms",title:"Apply Transforms",description:"Run the transform pipeline on a list of records. Order: simple operations (rename, convert, defaults, add, select, drop) → JSONata → custom function.",method:"apply_transforms(data, transform_config, **kwargs) -> List[Dict[str, Any]]",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter.etl_generator.transformers import apply_transforms

config = {
    "transform": {"rename": {"oldName": "new_name"}, "convert": {"price": "float"}},
    "jsonata": {"expression": "$.{\\"x\\": x * 2}", "mode": "record"}
}
out = apply_transforms(records, config)`,arguments:[{name:"data",type:"List[Dict[str, Any]]",description:"Input list of record dictionaries to transform",required:!0},{name:"transform_config",type:"Dict[str, Any]",description:"Transform configuration (transform, jsonata, and/or custom_function)",required:!0},{name:"**kwargs",type:"Any",description:"Additional keyword arguments passed to the custom_function step when configured",required:!1}],returns:{type:"List[Dict[str, Any]]",description:"Transformed list of record dictionaries"}},{id:"extractor_factory",title:"Extractor Factory",description:"Resolve type from extract config and return the appropriate extractor (HTTPExtractor, FileExtractor, DatabaseExtractor, or CloudStorageExtractor).",method:"ExtractorFactory.create(extract_config) -> BaseExtractor",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter.etl_generator.extractors import ExtractorFactory

# Create extractor from config
extractor = ExtractorFactory.create({"type": "http", "url": "https://api.example.com/data"})

# Auto-detection from config keys
extractor = ExtractorFactory.create({"file_path": "data.csv"})  # -> FileExtractor

# Register a custom extractor
ExtractorFactory.register("kafka", KafkaExtractor)`,arguments:[{name:"extract_config",type:"Dict[str, Any]",description:"Extract configuration; type is auto-detected from config keys if not specified",required:!0}],returns:{type:"BaseExtractor",description:"Extractor instance (HTTPExtractor, FileExtractor, DatabaseExtractor, or CloudStorageExtractor)"}},{id:"load_to_file",title:"Load to File and Cloud Storage",description:"Write transformed data to a local file (JSON, CSV, Parquet, JSONL) or to cloud storage (S3, GCS, Azure). Used when load_config has destination_type file or cloud_storage.",method:"load_to_file(data, load_config, contract_dir=None, config_context=None)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter.etl_generator.loaders import load_to_file, load_to_cloud_storage

# Local file
result = load_to_file(
    data=transformed_records,
    load_config={"destination_type": "file", "file_path": "out.json", "format": "json"}
)
# Cloud (S3 / GCS / Azure)
result = load_to_cloud_storage(data, load_config, contract_dir=contract_dir)`,arguments:[{name:"data",type:"List[Dict[str, Any]]",description:"List of record dictionaries to write",required:!0},{name:"load_config",type:"Dict[str, Any]",description:"Load configuration (destination_type, file_path or storage, format, etc.)",required:!0},{name:"contract_dir",type:"Optional[Any]",description:"Contract directory used for variable resolution in load_config",required:!1},{name:"config_context",type:"Optional[Dict[str, Any]]",description:"Context for resolving ${VAR} placeholders in load_config",required:!1}],returns:{type:"Dict[str, Any]",description:"Result dictionary with keys such as written and total"}},{id:"generate_etl_config",title:"Generate ETL Config",description:"Generate ETL config dictionaries (extract, transform, load) from contract artifacts or from the metadata store. Use generate_etl_config_from_contract or generate_etl_config_from_store.",method:"generate_etl_config_from_contract(contract_dict, extraction_config=None, ...)",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter.etl_generator import generate_etl_config_from_contract, generate_etl_config_from_store

# From contract dictionary
config = generate_etl_config_from_contract(
    contract_dict,
    extraction_config={"provider_name": "fmp", "api_endpoint": "/api/v3/profile/AAPL"}
)
# From metadata store
config = generate_etl_config_from_store(store, schema_title="user_schema", ...)`,arguments:[{name:"contract_dict",type:"Dict[str, Any]",description:"Contract dictionary (used by generate_etl_config_from_contract)",required:!1},{name:"store",type:"MetadataStoreClient",description:"Metadata store client (used by generate_etl_config_from_store)",required:!1},{name:"schema_title",type:"str",description:"Schema or title identifier in the store",required:!1},{name:"extraction_config",type:"Optional[Dict[str, Any]]",description:"Extraction hints such as provider name and API endpoint",required:!1}],returns:{type:"Dict[str, Any]",description:"Dictionary containing extract, transform, and load configuration sections"}},{id:"etl_run_api",title:"Run ETL Pipeline (API)",description:"Run an ETL pipeline from YAML config strings (extract, transform, load). Optional variables are applied for ${VAR} substitution. Use dry_run=True to extract and transform without loading.",method:"POST /api/v1/etl/run",apiEndpoint:"/api/v1/etl/run",apiMethod:"POST",exampleRequest:{extract_yaml:"type: http\nurl: https://api.example.com/data\nmethod: GET",load_yaml:"type: file\npath: /tmp/out.jsonl\nformat: jsonl",transform_yaml:null,variables:{API_KEY:"your_key"},dry_run:!1},exampleCode:`# API: POST /api/v1/etl/run
# Body: extract_yaml (required), load_yaml (required), transform_yaml (optional), variables (optional), dry_run (default false)
# Returns: { success, rows_extracted, rows_transformed, rows_loaded, rows_failed, validation_errors_*, duration_seconds, errors, ... }

from pycharter import Pipeline
# Python equivalent: build pipeline from config dicts and run
pipeline = Pipeline.from_dict({"extract": {...}, "transform": {...}, "load": {...}})
result = pipeline.run()`,arguments:[{name:"extract_yaml",type:"str",description:"Extract config as YAML string (required)",required:!0},{name:"load_yaml",type:"str",description:"Load config as YAML string (required)",required:!0},{name:"transform_yaml",type:"Optional[str]",description:"Optional transform config as YAML string",required:!1},{name:"variables",type:"Optional[Dict[str, str]]",description:"Optional variables for ${VAR} substitution in configs",required:!1},{name:"dry_run",type:"bool",description:"If True, extract and transform but do not load",required:!1,default:"False"}],returns:{type:"EtlRunResponse",description:"Pipeline result: success, rows_extracted, rows_transformed, rows_loaded, rows_failed, rows_quarantined_*, validation_errors_*, duration_seconds, batches_processed, errors"}},{id:"docs_generator",title:"DocsGenerator Class",description:"Generate human-readable documentation from data contracts. Supports Markdown and HTML output formats.",method:"DocsGenerator(renderer=MarkdownRenderer())",apiEndpoint:"/api/v1/docs/generate",apiMethod:"POST",exampleRequest:{contract:{schema:{type:"object",title:"UserProfile",version:"1.0.0",properties:{name:{type:"string",description:"User name"},email:{type:"string",format:"email"}},required:["name"]}},format:"markdown"},exampleCode:`from pycharter import DocsGenerator, generate_docs, MarkdownRenderer, HTMLRenderer

# Quick generation
contract = parse_contract_file("contract.yaml")
markdown = generate_docs(contract)
html = generate_docs(contract, format="html")

# Custom generator
generator = DocsGenerator(renderer=MarkdownRenderer())
docs = generator.generate(contract)
schema_section = generator.generate_schema_section(contract.schema)`,arguments:[{name:"renderer",type:"DocsRenderer",description:"Renderer for output format (MarkdownRenderer or HTMLRenderer)",required:!1,default:"MarkdownRenderer()"}],returns:{type:"DocsGenerator",description:"DocsGenerator instance for generating documentation"}},{id:"generate_docs",title:"generate_docs() Function",description:"Convenience function to generate documentation from a contract in one call",method:'generate_docs(contract, format="markdown", **kwargs)',apiEndpoint:"/api/v1/docs/generate",apiMethod:"POST",exampleRequest:{contract:{schema:{type:"object",title:"Product",version:"1.0.0",properties:{id:{type:"string"},price:{type:"number",minimum:0}}},coercion_rules:{price:"to_float"}},format:"html",include_schema:!0,include_coercions:!0},exampleCode:`from pycharter import generate_docs, parse_contract_file

contract = parse_contract_file("contract.yaml")

# Generate Markdown
markdown = generate_docs(contract)

# Generate HTML
html = generate_docs(contract, format="html")

# Control sections included
docs = generate_docs(
    contract,
    format="markdown",
    include_schema=True,
    include_coercions=True,
    include_validations=False,
    include_metadata=True
)`,arguments:[{name:"contract",type:"ContractMetadata | Dict",description:"ContractMetadata object or contract dictionary",required:!0},{name:"format",type:"str",description:'Output format: "markdown" or "html"',required:!1,default:'"markdown"'},{name:"include_schema",type:"bool",description:"Include schema fields section",required:!1,default:"True"},{name:"include_coercions",type:"bool",description:"Include coercion rules section",required:!1,default:"True"},{name:"include_validations",type:"bool",description:"Include validation rules section",required:!1,default:"True"},{name:"include_metadata",type:"bool",description:"Include metadata/ownership section",required:!1,default:"True"}],returns:{type:"str",description:"Generated documentation as string"}},{id:"metrics_collector",title:"MetricsCollector Class",description:"Collect and query validation metrics over time. Track quality trends and aggregate statistics.",method:"MetricsCollector(store=InMemoryMetricsStore())",apiEndpoint:"/api/v1/quality/tracking",apiMethod:"GET",exampleRequest:null,exampleCode:`from pycharter import MetricsCollector, InMemoryMetricsStore, SQLiteMetricsStore

# Create collector with in-memory store (development)
store = InMemoryMetricsStore()
collector = MetricsCollector(store)

# Or use SQLite for persistence
store = SQLiteMetricsStore("metrics.db")
collector = MetricsCollector(store)

# Record validation results
result = validator.validate(data)
collector.record(result, schema_name="users", version="1.0.0", duration_ms=50.0)

# Query metrics
metrics = collector.query(schema_name="users", limit=100)

# Get aggregated summary
summary = collector.get_summary("users", window_hours=24)
print(f"Avg validity rate: {summary.avg_validity_rate}")`,arguments:[{name:"store",type:"MetricsStore",description:"Storage backend (InMemoryMetricsStore or SQLiteMetricsStore)",required:!1,default:"InMemoryMetricsStore()"}],returns:{type:"MetricsCollector",description:"MetricsCollector instance for tracking validation metrics"}},{id:"validation_metric",title:"ValidationMetric Model",description:"Data model for a single validation run metric. Contains all metrics captured from validation.",method:"ValidationMetric(schema_name, version, ...)",apiEndpoint:"/api/v1/quality/tracking",apiMethod:"POST",exampleRequest:{schema_name:"users",version:"1.0.0",record_count:100,valid_count:95,error_count:5,completeness:.98,duration_ms:150.5},exampleCode:`from pycharter import ValidationMetric
from datetime import datetime

# Metrics are typically created automatically by MetricsCollector
# but can be created manually:
metric = ValidationMetric(
    schema_name="users",
    version="1.0.0",
    timestamp=datetime.utcnow(),
    record_count=100,
    valid_count=95,
    error_count=5,
    validity_rate=0.95,
    completeness=0.98,
    field_completeness={"email": 1.0, "phone": 0.85},
    duration_ms=150.5,
    errors_by_type={"missing_required": 3, "type_error": 2}
)

# Convert to dict for API/storage
data = metric.to_dict()`,arguments:[{name:"schema_name",type:"str",description:"Name of the schema validated against",required:!0},{name:"version",type:"str",description:"Version of the schema",required:!0},{name:"record_count",type:"int",description:"Number of records validated",required:!1,default:"0"},{name:"valid_count",type:"int",description:"Number of valid records",required:!1,default:"0"},{name:"validity_rate",type:"float",description:"Ratio of valid records (0.0 to 1.0)",required:!1,default:"1.0"},{name:"completeness",type:"float",description:"Overall data completeness (0.0 to 1.0)",required:!1,default:"1.0"},{name:"duration_ms",type:"float",description:"Validation duration in milliseconds",required:!1,default:"0.0"}],returns:{type:"ValidationMetric",description:"ValidationMetric dataclass instance"}},{id:"metrics_summary",title:"MetricsSummary Model",description:"Aggregated metrics summary for a schema over a time period. Used for trend analysis.",method:"collector.get_summary(schema_name, window_hours=24)",apiEndpoint:"/api/v1/quality/tracking/{schema_name}/summary",apiMethod:"GET",exampleRequest:null,exampleCode:`from pycharter import MetricsCollector, InMemoryMetricsStore

collector = MetricsCollector(InMemoryMetricsStore())

# Get summary for last 24 hours
summary = collector.get_summary("users", window_hours=24)

print(f"Total validations: {summary.total_validations}")
print(f"Average validity rate: {summary.avg_validity_rate:.2%}")
print(f"Min validity rate: {summary.min_validity_rate:.2%}")
print(f"Max validity rate: {summary.max_validity_rate:.2%}")
print(f"Total records: {summary.total_records}")
print(f"Top errors: {summary.top_error_types}")`,arguments:[{name:"schema_name",type:"str",description:"Name of the schema to summarize",required:!0},{name:"window_hours",type:"int",description:"Number of hours to look back",required:!1,default:"24"}],returns:{type:"MetricsSummary",description:"MetricsSummary with aggregated statistics"}},{id:"metrics_export",title:"Export Metrics",description:"Export validation metrics in various formats: JSON, Prometheus, or CSV.",method:"export_json(metrics) | export_prometheus(metrics) | export_csv(metrics)",apiEndpoint:"/api/v1/quality/tracking/export",apiMethod:"GET",exampleRequest:null,exampleCode:`from pycharter.quality.tracking import (
    export_json, export_prometheus, export_csv, MetricsCollector
)

collector = MetricsCollector()
metrics = collector.query(schema_name="users")

# Export as JSON
json_data = export_json(metrics, pretty=True)

# Export as Prometheus text format (for scraping)
prom_data = export_prometheus(metrics, prefix="pycharter")

# Export as CSV
csv_data = export_csv(metrics, include_header=True)

# Via API
# GET /api/v1/quality/tracking/export?format=prometheus&schema_name=users`,arguments:[{name:"metrics",type:"List[ValidationMetric]",description:"List of metrics to export",required:!0},{name:"format",type:"str",description:'Export format: "json", "prometheus", or "csv"',required:!1,default:'"json"'}],returns:{type:"str",description:"Exported metrics as string in specified format"}},{id:"validator_with_tracking",title:"Validator with Tracking",description:"Integrate metrics tracking into validators using ValidatorBuilder.with_tracking()",method:"ValidatorBuilder().with_tracking(collector).build()",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import ValidatorBuilder
from pycharter.quality.tracking import MetricsCollector, InMemoryMetricsStore

# Create metrics collector
store = InMemoryMetricsStore()
collector = MetricsCollector(store)

# Build validator with automatic tracking
validator = (
    ValidatorBuilder()
    .from_directory("contracts/users")
    .with_tracking(collector)  # Enable tracking
    .with_quality_checks()
    .build()
)

# Each validation automatically records metrics
result = validator.validate({"name": "Alice", "email": "alice@example.com"})

# Batch validation also tracks
results = validator.validate_batch([...])

# Query the recorded metrics
metrics = collector.query(schema_name="users")
summary = collector.get_summary("users")`,arguments:[{name:"collector",type:"MetricsCollector",description:"MetricsCollector instance for recording metrics",required:!0}],returns:{type:"ValidatorBuilder",description:"Self for method chaining"}},{id:"check_compatibility",title:"check_compatibility() Function",description:"Check if two schemas are compatible according to the specified mode (backward, forward, or full).",method:'check_compatibility(old_schema, new_schema, mode="backward")',apiEndpoint:"/api/v1/evolution/check",apiMethod:"POST",exampleRequest:{old_schema:{type:"object",properties:{name:{type:"string"}},required:["name"]},new_schema:{type:"object",properties:{name:{type:"string"},email:{type:"string"}},required:["name"]},mode:"backward"},exampleCode:`from pycharter import check_compatibility, CompatibilityMode

old_schema = {
    "type": "object",
    "properties": {"name": {"type": "string"}},
    "required": ["name"]
}
new_schema = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "email": {"type": "string"}  # New optional field
    },
    "required": ["name"]
}

# Check backward compatibility (new consumer, old data)
result = check_compatibility(old_schema, new_schema, mode="backward")
print(f"Compatible: {result.compatible}")

if not result.compatible:
    print(f"Issues: {result.issues}")

# Check forward compatibility (old consumer, new data)
result = check_compatibility(old_schema, new_schema, mode="forward")

# Check full compatibility (both directions)
result = check_compatibility(old_schema, new_schema, mode="full")`,arguments:[{name:"old_schema",type:"Dict[str, Any]",description:"The existing/original schema",required:!0},{name:"new_schema",type:"Dict[str, Any]",description:"The new schema to check",required:!0},{name:"mode",type:"str | CompatibilityMode",description:'Compatibility mode: "backward", "forward", or "full"',required:!1,default:'"backward"'}],returns:{type:"CompatibilityResult",description:"CompatibilityResult with compatible status, diff, issues, and warnings"}},{id:"compute_diff",title:"compute_diff() Function",description:"Compute detailed diff between two JSON Schema versions. Returns all changes categorized by type.",method:"compute_diff(old_schema, new_schema)",apiEndpoint:"/api/v1/evolution/diff",apiMethod:"POST",exampleRequest:{old_schema:{type:"object",properties:{name:{type:"string"},age:{type:"integer",minimum:0}}},new_schema:{type:"object",properties:{name:{type:"string"},age:{type:"integer",minimum:18},email:{type:"string"}}}},exampleCode:`from pycharter import compute_diff, ChangeType

old_schema = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "age": {"type": "integer", "minimum": 0}
    }
}
new_schema = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "age": {"type": "integer", "minimum": 18},  # Changed
        "email": {"type": "string"}  # Added
    }
}

diff = compute_diff(old_schema, new_schema)

print(f"Total changes: {len(diff.changes)}")
print(f"Breaking changes: {len(diff.breaking_changes)}")

for change in diff.changes:
    status = "BREAKING" if change.breaking else "OK"
    print(f"[{status}] {change.change_type.value}: {change.path}")
    print(f"  {change.message}")

# Access specific change types
for addition in diff.additions:
    print(f"Added: {addition.path}")`,arguments:[{name:"old_schema",type:"Dict[str, Any]",description:"Original schema",required:!0},{name:"new_schema",type:"Dict[str, Any]",description:"New schema",required:!0}],returns:{type:"SchemaDiff",description:"SchemaDiff with changes, breaking_changes, additions, removals, modifications"}},{id:"compatibility_modes",title:"Compatibility Modes",description:"Understanding the three compatibility modes: backward, forward, and full.",method:"CompatibilityMode.BACKWARD | FORWARD | FULL",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import CompatibilityMode, check_compatibility

# BACKWARD: New schema can read old data
# Use when: Upgrading consumers before producers
# Safe: Add optional fields, remove fields, widen types
# Breaking: Add required fields, narrow types, remove enum values
result = check_compatibility(old, new, mode=CompatibilityMode.BACKWARD)

# FORWARD: Old schema can read new data
# Use when: Upgrading producers before consumers
# Safe: Remove optional fields, add fields
# Breaking: Remove required fields, add enum values, widen types
result = check_compatibility(old, new, mode=CompatibilityMode.FORWARD)

# FULL: Both backward and forward compatible
# Use when: No control over upgrade order
# Safe: Only metadata changes, add fields with defaults
# Breaking: Most schema changes
result = check_compatibility(old, new, mode=CompatibilityMode.FULL)`,arguments:[{name:"BACKWARD",type:"CompatibilityMode",description:"New consumers can read data from old producers",required:!1},{name:"FORWARD",type:"CompatibilityMode",description:"Old consumers can read data from new producers",required:!1},{name:"FULL",type:"CompatibilityMode",description:"Both backward and forward compatible",required:!1}],returns:{type:"CompatibilityMode",description:"Enum for specifying compatibility checking mode"}},{id:"change_types",title:"Change Types",description:"All schema change types detected by compute_diff()",method:"ChangeType enum values",apiEndpoint:null,apiMethod:"N/A",exampleRequest:null,exampleCode:`from pycharter import ChangeType, compute_diff

diff = compute_diff(old_schema, new_schema)

# Field changes
# ChangeType.FIELD_ADDED - New field added
# ChangeType.FIELD_REMOVED - Field removed

# Type changes
# ChangeType.TYPE_CHANGED - Type completely changed
# ChangeType.TYPE_WIDENED - Type widened (int -> number) - safe for backward
# ChangeType.TYPE_NARROWED - Type narrowed (number -> int) - breaking

# Constraint changes
# ChangeType.CONSTRAINT_ADDED - New constraint (min, max, pattern, etc.)
# ChangeType.CONSTRAINT_REMOVED - Constraint removed
# ChangeType.CONSTRAINT_MODIFIED - Constraint value changed

# Required/optional changes
# ChangeType.REQUIRED_ADDED - Field became required - breaking
# ChangeType.REQUIRED_REMOVED - Field became optional - safe

# Enum changes
# ChangeType.ENUM_VALUE_ADDED - New enum value
# ChangeType.ENUM_VALUE_REMOVED - Enum value removed - breaking

# Filter by type
type_changes = [c for c in diff.changes if c.change_type == ChangeType.TYPE_CHANGED]`,arguments:[],returns:{type:"ChangeType",description:"Enum with all possible schema change types"}}];function b({method:s}){let[l,m]=(0,a.useState)(s.exampleRequest?JSON.stringify(s.exampleRequest,null,2):""),[p,u]=(0,a.useState)(null),[_,h]=(0,a.useState)(null),[f,y]=(0,a.useState)(!1),[g,v]=(0,a.useState)(!1);if(!s.apiEndpoint)return null;let x=s.apiEndpoint?.includes("/upload")??!1,b=async()=>{y(!0),h(null);try{let t,a,{getApiBaseUrl:r}=await e.A(36909),i=r(),o=s.apiEndpoint;if(!o){h({success:!1,error:"This method does not have an API endpoint (Python-only)"}),y(!1);return}o.includes("{schema_id}")&&(o=o.replace("{schema_id}","user_schema"));let n=`${i}${o}`;if("GET"===s.apiMethod)t=await fetch(n);else if(x){if(!p){h({success:!1,error:"Please select a file to upload"}),y(!1);return}let e=new FormData;e.append("file",p),o.includes("/contracts/parse/upload")&&e.append("validate","true"),t=await fetch(n,{method:s.apiMethod,body:e})}else{let e=l?JSON.parse(l):{};t=await fetch(n,{method:s.apiMethod,headers:{"Content-Type":"application/json"},body:JSON.stringify(e)})}let c=t.headers.get("content-type");a=c&&c.includes("application/json")?await t.json():{message:await t.text()},t.ok?h({success:!0,data:a}):h({success:!1,error:a.detail||a.message||`HTTP ${t.status}: ${t.statusText}`})}catch(t){let e=(0,i.getApiErrorMessage)(t,"Failed to test API");t instanceof Error&&t.message.includes("JSON")&&(e="Invalid JSON in request body. Please check your input."),h({success:!1,error:e})}finally{y(!1)}};return(0,t.jsxs)("div",{className:"border rounded-lg p-4 bg-muted/30",children:[(0,t.jsxs)("div",{className:"flex items-center justify-between mb-3",children:[(0,t.jsx)("h5",{className:"text-sm font-semibold",children:"Test API"}),s.apiEndpoint&&(0,t.jsxs)("div",{className:"flex gap-2",children:[(0,t.jsx)(r.Button,{size:"sm",variant:"outline",onClick:()=>{var e;return s.apiEndpoint&&(e=s.apiEndpoint,void(navigator.clipboard.writeText(e),v(!0),setTimeout(()=>v(!1),2e3)))},className:"h-7",disabled:!s.apiEndpoint,children:g?(0,t.jsx)(d,{className:"h-3 w-3"}):(0,t.jsx)(c,{className:"h-3 w-3"})}),(0,t.jsx)(r.Button,{size:"sm",onClick:b,disabled:f||"GET"!==s.apiMethod&&!x&&!l||x&&!p,className:"h-7",children:f?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:"mr-1",children:(0,t.jsx)(o.LoadingSpinner,{size:"sm"})}),"Testing..."]}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(n.Play,{className:"h-3 w-3 mr-1"}),"Test"]})})]})]}),s.apiEndpoint&&"GET"!==s.apiMethod&&(0,t.jsx)("div",{className:"mb-3",children:x?(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-xs font-medium mb-1",children:"Upload File"}),(0,t.jsx)("input",{type:"file",accept:".yaml,.yml,.json",onChange:e=>u(e.target.files?.[0]||null),className:"w-full px-2 py-1 border rounded text-xs bg-background"}),p&&(0,t.jsxs)("div",{className:"mt-1 text-xs text-muted-foreground",children:["Selected: ",p.name," (",(p.size/1024).toFixed(2)," KB)"]})]}):(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-xs font-medium mb-1",children:"Request Body (JSON)"}),(0,t.jsx)("textarea",{value:l,onChange:e=>m(e.target.value),rows:6,className:"w-full px-2 py-1 border rounded text-xs font-mono bg-background",placeholder:"Enter JSON request body..."})]})}),s.apiEndpoint&&(0,t.jsxs)("div",{className:"text-xs text-muted-foreground mb-2",children:[(0,t.jsx)("span",{className:"font-mono font-semibold",children:s.apiMethod})," ",s.apiEndpoint]}),_&&(0,t.jsx)("div",{className:"mt-3",children:_.success?(0,t.jsxs)("div",{className:"bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded p-2",children:[(0,t.jsx)("div",{className:"text-xs font-semibold text-green-800 dark:text-green-200 mb-1",children:"Success"}),(0,t.jsx)("pre",{className:"text-xs overflow-x-auto text-green-700 dark:text-green-300",children:JSON.stringify(_.data,null,2)})]}):(0,t.jsxs)("div",{className:"bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded p-2",children:[(0,t.jsx)("div",{className:"text-xs font-semibold text-red-800 dark:text-red-200 mb-1",children:"Error"}),(0,t.jsx)("div",{className:"text-xs text-red-700 dark:text-red-300",children:_.error})]})})]})}function C(){let[e,r]=(0,a.useState)("contract-management"),i={"contract-management":["parse_contract","parse_contract_file","build_contract","build_contract_from_store","build_contract_from_id","create_from_artifacts","create_mixed","list_contracts","get_contract","update_contract"],"metadata-store":["store_schema","get_schema","list_schemas","store_metadata","get_metadata","store_coercion_rules","get_coercion_rules","store_validation_rules","get_validation_rules","get_complete_schema"],"model-generator":["generate_model","generate_model_file","from_dict","from_file","from_json","from_url","model_to_schema","to_dict","to_json","to_file"],validation:["validator_class","validator_builder","validation_quality_metrics","error_handling","validate_with_store","validate_with_contract","validate_batch_with_store","validate_batch_with_contract","get_model_from_store","get_model_from_contract","validate","validate_batch"],"quality-assurance":["quality_check","quality_check_options","quality_thresholds"],"quality-tracking":["metrics_collector","validation_metric","metrics_summary","metrics_export","validator_with_tracking"],"docs-generation":["docs_generator","generate_docs"],"schema-evolution":["check_compatibility","compute_diff","compatibility_modes","change_types"],"etl-generator":["pipeline_class","pipeline_builder","etl_transformers","etl_extractors","etl_loaders","etl_orchestrator","create_orchestrator","pipeline_factory","extract_with_pagination_streaming","apply_transforms","extractor_factory","load_to_file","generate_etl_config","etl_run_api"]},o=e=>{let t=Object.keys(i).find(t=>i[t].includes(e));if(t)r(t),setTimeout(()=>{let t=document.getElementById(`method-${e}`);t&&t.scrollIntoView({behavior:"smooth",block:"start"})},150);else{let t=document.getElementById(`method-${e}`);t&&t.scrollIntoView({behavior:"smooth",block:"start"})}},n=[{id:"contract-management",title:"Contract Management",icon:l.FileText,items:[{id:"parse_contract",label:"Parse Contract",onClick:()=>o("parse_contract")},{id:"build_contract",label:"Build Contract",onClick:()=>o("build_contract")},{id:"build_contract_from_id",label:"Build from ID",onClick:()=>o("build_contract_from_id")},{id:"create_from_artifacts",label:"Create from Artifacts",onClick:()=>o("create_from_artifacts")},{id:"create_mixed",label:"Create (Mixed)",onClick:()=>o("create_mixed")},{id:"list_contracts",label:"List Contracts",onClick:()=>o("list_contracts")},{id:"get_contract",label:"Get Contract",onClick:()=>o("get_contract")},{id:"update_contract",label:"Update Contract",onClick:()=>o("update_contract")}]},{id:"metadata-store",title:"Metadata Store Client",icon:m.Database,items:[{id:"store_schema",label:"Store Schema",onClick:()=>o("store_schema")},{id:"get_schema",label:"Get Schema",onClick:()=>o("get_schema")},{id:"list_schemas",label:"List Schemas",onClick:()=>o("list_schemas")},{id:"store_metadata",label:"Store Metadata",onClick:()=>o("store_metadata")},{id:"get_metadata",label:"Get Metadata",onClick:()=>o("get_metadata")},{id:"store_coercion_rules",label:"Store Coercion Rules",onClick:()=>o("store_coercion_rules")},{id:"get_coercion_rules",label:"Get Coercion Rules",onClick:()=>o("get_coercion_rules")},{id:"store_validation_rules",label:"Store Validation Rules",onClick:()=>o("store_validation_rules")},{id:"get_validation_rules",label:"Get Validation Rules",onClick:()=>o("get_validation_rules")},{id:"get_complete_schema",label:"Get Complete Schema",onClick:()=>o("get_complete_schema")}]},{id:"model-generator",title:"Model Generator",icon:p,items:[{id:"generate_model",label:"Generate Model",onClick:()=>o("generate_model")},{id:"generate_model_file",label:"Generate Model File",onClick:()=>o("generate_model_file")},{id:"from_dict",label:"From Dict",onClick:()=>o("from_dict")},{id:"from_file",label:"From File",onClick:()=>o("from_file")},{id:"from_json",label:"From JSON",onClick:()=>o("from_json")},{id:"from_url",label:"From URL",onClick:()=>o("from_url")},{id:"model_to_schema",label:"Model to Schema",onClick:()=>o("model_to_schema")},{id:"to_dict",label:"To Dict",onClick:()=>o("to_dict")},{id:"to_json",label:"To JSON",onClick:()=>o("to_json")},{id:"to_file",label:"To File",onClick:()=>o("to_file")}]},{id:"validation",title:"Validation",icon:u,items:[{id:"validator_class",label:"⭐ Validator Class",onClick:()=>o("validator_class")},{id:"validator_builder",label:"ValidatorBuilder",onClick:()=>o("validator_builder")},{id:"validation_quality_metrics",label:"Quality Metrics",onClick:()=>o("validation_quality_metrics")},{id:"error_handling",label:"Error Handling",onClick:()=>o("error_handling")},{id:"validate_with_store",label:"Validate with Store",onClick:()=>o("validate_with_store")},{id:"validate_with_contract",label:"Validate with Contract",onClick:()=>o("validate_with_contract")},{id:"validate_batch_with_store",label:"Batch Validate (Store)",onClick:()=>o("validate_batch_with_store")},{id:"validate_batch_with_contract",label:"Batch Validate (Contract)",onClick:()=>o("validate_batch_with_contract")},{id:"get_model_from_store",label:"Get Model (Store)",onClick:()=>o("get_model_from_store")},{id:"get_model_from_contract",label:"Get Model (Contract)",onClick:()=>o("get_model_from_contract")},{id:"validate",label:"Validate (Low-level)",onClick:()=>o("validate")},{id:"validate_batch",label:"Batch Validate (Low-level)",onClick:()=>o("validate_batch")}]},{id:"quality-assurance",title:"Quality Assurance",icon:_.Award,items:[{id:"quality_check",label:"⭐ QualityCheck Class",onClick:()=>o("quality_check")},{id:"quality_check_options",label:"QualityCheckOptions",onClick:()=>o("quality_check_options")},{id:"quality_thresholds",label:"QualityThresholds",onClick:()=>o("quality_thresholds")}]},{id:"quality-tracking",title:"Quality Tracking",icon:y,items:[{id:"metrics_collector",label:"⭐ MetricsCollector",onClick:()=>o("metrics_collector")},{id:"validation_metric",label:"ValidationMetric",onClick:()=>o("validation_metric")},{id:"metrics_summary",label:"MetricsSummary",onClick:()=>o("metrics_summary")},{id:"metrics_export",label:"Export Metrics",onClick:()=>o("metrics_export")},{id:"validator_with_tracking",label:"Validator + Tracking",onClick:()=>o("validator_with_tracking")}]},{id:"docs-generation",title:"Doc Generation",icon:f,items:[{id:"docs_generator",label:"⭐ DocsGenerator",onClick:()=>o("docs_generator")},{id:"generate_docs",label:"generate_docs()",onClick:()=>o("generate_docs")}]},{id:"schema-evolution",title:"Schema Evolution",icon:g,items:[{id:"check_compatibility",label:"⭐ check_compatibility()",onClick:()=>o("check_compatibility")},{id:"compute_diff",label:"compute_diff()",onClick:()=>o("compute_diff")},{id:"compatibility_modes",label:"Compatibility Modes",onClick:()=>o("compatibility_modes")},{id:"change_types",label:"Change Types",onClick:()=>o("change_types")}]},{id:"etl-generator",title:"ETL Generator",icon:h,items:[{id:"pipeline_class",label:"⭐ Pipeline (NEW)",onClick:()=>o("pipeline_class")},{id:"pipeline_builder",label:"PipelineBuilder",onClick:()=>o("pipeline_builder")},{id:"etl_transformers",label:"Transformers",onClick:()=>o("etl_transformers")},{id:"etl_extractors",label:"Extractors",onClick:()=>o("etl_extractors")},{id:"etl_loaders",label:"Loaders",onClick:()=>o("etl_loaders")},{id:"etl_orchestrator",label:"ETL Orchestrator (Legacy)",onClick:()=>o("etl_orchestrator")},{id:"create_orchestrator",label:"Create Orchestrator",onClick:()=>o("create_orchestrator")},{id:"pipeline_factory",label:"Pipeline Factory",onClick:()=>o("pipeline_factory")},{id:"extract_with_pagination_streaming",label:"Extract Streaming",onClick:()=>o("extract_with_pagination_streaming")},{id:"apply_transforms",label:"Apply Transforms",onClick:()=>o("apply_transforms")},{id:"extractor_factory",label:"Extractor Factory",onClick:()=>o("extractor_factory")},{id:"load_to_file",label:"Load to File / Cloud",onClick:()=>o("load_to_file")},{id:"generate_etl_config",label:"Generate ETL Config",onClick:()=>o("generate_etl_config")},{id:"etl_run_api",label:"⭐ Run ETL (API)",onClick:()=>o("etl_run_api")}]}],s=i[e]?x.filter(t=>i[e].includes(t.id)):x;return(0,t.jsxs)("div",{className:"flex h-full bg-background",style:{height:"calc(100vh - 4rem)",overflow:"hidden"},children:[(0,t.jsx)("div",{className:"flex-shrink-0",style:{height:"100%",overflow:"hidden"},children:(0,t.jsx)(v.CollapsibleSidebar,{sections:n,defaultCollapsed:!1,headerTitle:"Documentation",selectedSection:e,onSectionClick:e=>{r(e),setTimeout(()=>{let t=document.getElementById(`section-${e}`);t&&t.scrollIntoView({behavior:"smooth",block:"start"})},100)}})}),(0,t.jsx)("div",{className:"flex-1 min-w-0",style:{height:"100%",overflowY:"auto",overflowX:"hidden"},"data-content-area":!0,children:(0,t.jsx)("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:(0,t.jsxs)("div",{className:"space-y-8",children:[(0,t.jsxs)("div",{id:`section-${e}`,className:"scroll-mt-4 mb-4",children:[(0,t.jsx)("h2",{className:"text-2xl font-bold text-foreground mb-1",children:n.find(t=>t.id===e)?.title||"Documentation"}),(0,t.jsxs)("p",{className:"text-sm text-muted-foreground",children:["contract-management"===e&&"Manage and work with data contracts","metadata-store"===e&&"Store and retrieve schemas, metadata, coercion rules, and validation rules","model-generator"===e&&"Generate Pydantic models from schemas","validation"===e&&"Validate data against schemas and contracts","quality-assurance"===e&&"Monitor data quality and track violations","quality-tracking"===e&&"Track validation metrics over time with trend analysis and export capabilities","docs-generation"===e&&"Generate human-readable documentation from data contracts in Markdown or HTML","schema-evolution"===e&&"Check schema compatibility and compute detailed diffs between versions","etl-generator"===e&&"Execute ETL pipelines from contract configs: extract, transform, and load"]})]}),(0,t.jsx)("div",{className:"space-y-6",children:s.map(e=>(0,t.jsx)("div",{id:`method-${e.id}`,className:"border rounded-lg overflow-hidden scroll-mt-4",children:(0,t.jsxs)("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-4 p-4",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("h4",{className:"font-semibold mb-2",children:e.title}),(0,t.jsx)("p",{className:"text-sm text-muted-foreground mb-3",children:e.description}),e.arguments&&e.arguments.length>0&&(0,t.jsxs)("div",{className:"mb-4",children:[(0,t.jsx)("h5",{className:"text-sm font-semibold mb-2",children:"Arguments"}),(0,t.jsx)("div",{className:"space-y-2",children:e.arguments.map((e,a)=>(0,t.jsxs)("div",{className:"text-xs border-l-2 border-primary/20 pl-2",children:[(0,t.jsxs)("div",{className:"font-mono font-semibold text-foreground",children:[e.name,!e.required&&(0,t.jsx)("span",{className:"text-muted-foreground ml-1",children:"(optional)"})]}),(0,t.jsxs)("div",{className:"text-muted-foreground mt-0.5",children:[(0,t.jsx)("span",{className:"font-mono",children:e.type}),e.default&&(0,t.jsxs)("span",{className:"ml-1",children:["default: ",e.default]})]}),(0,t.jsx)("div",{className:"text-muted-foreground mt-1",children:e.description})]},a))})]}),e.returns&&(0,t.jsxs)("div",{className:"mb-4",children:[(0,t.jsx)("h5",{className:"text-sm font-semibold mb-2",children:"Returns"}),(0,t.jsxs)("div",{className:"text-xs border-l-2 border-green-500/20 pl-2",children:[(0,t.jsx)("div",{className:"font-mono font-semibold text-foreground mb-0.5",children:e.returns.type}),(0,t.jsx)("div",{className:"text-muted-foreground",children:e.returns.description})]})]}),(0,t.jsx)("div",{className:"bg-muted p-3 rounded font-mono text-xs overflow-x-auto mb-3",children:(0,t.jsx)("pre",{className:"whitespace-pre-wrap",children:e.exampleCode})}),(0,t.jsxs)("div",{className:"text-xs text-muted-foreground",children:[(0,t.jsx)("span",{className:"font-semibold",children:"Method:"})," ",e.method]})]}),(0,t.jsx)("div",{children:(0,t.jsx)(b,{method:e})})]})},e.id))}),(0,t.jsxs)("div",{className:"border rounded-lg p-4 bg-primary/5",children:[(0,t.jsx)("h4",{className:"font-semibold mb-2",children:"Additional Resources"}),(0,t.jsxs)("ul",{className:"text-sm space-y-1 text-muted-foreground",children:[(0,t.jsx)("li",{children:"• Full documentation: See README.md and docs/reference.md"}),(0,t.jsx)("li",{children:"• ETL Generator interfaces: pycharter/etl_generator/INTERFACES.md"}),(0,t.jsx)("li",{children:"• Examples: See docs/notebooks/ for Jupyter notebooks (ETL, contracts, validation, quality, metadata store, schema conversion)"}),(0,t.jsx)("li",{children:"• API Documentation: Available at /docs when running the API server"})]})]})]})})})]})}e.s(["default",()=>C],33558)}]);