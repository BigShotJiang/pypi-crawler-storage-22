# Changelog

All notable changes to PyCivil will be documented in this file.

## Version 0.2.19

### Bug Fixes

1. Added `Concrete_NTC2018_RFI_Enum` for NTC2018 RFI concrete support
2. Fixed `Check_SLE_F` crack value to be `bool` instead of `float`
3. Added NTC2018:RFI in known codes

## Version 0.2.18

### Bug Fixes

1. `RCRectCalculator.addForce()` now returns the `loadId` for better tracking and reference of added load cases

## Version 0.2.17

### Bug Fixes

1. Fixed markdown/HTML reports not including SLE-F (crack check), SLE-NM, and SLU-T verification results

### New Features

1. Added `pydmodelhelper.py` module in EXAUtils with helper functions to find Pydantic models in nested JSON structures:
   - `find_all_submodels()` - finds all matching model instances
   - `find_submodel()` - finds the first matching model instance

## Version 0.2.16

### Refactoring

1. Moved `SectionPlotViewEnum` and `SectionPlot` from `EXAStructural/plot.py` to `EXAStructural/rcgensolver/plot.py`

## Version 0.2.15

### Documentation

1. Added source code link to GitLab repository in README

## Version 0.2.14

### Bug Fixes

1. Logo can now be changed in reports
2. Reports now display an alternative phrase when material is not set by code
3. Steel with id -1 is no longer printed in output
4. Improved assertion handling in fe.py
5. Fixed area properties calculation in RCTemplRectEC2
6. Fixed cracked parameters computation in RCTemplRectEC2

### Improvements

1. Added copyright notice to all Python files
2. File extensions are now handled as uppercase for consistency
3. Reorganized test_obj into separate shapes and geometry test files
4. Moved version history from README to dedicated CHANGELOG.md

### Documentation

1. Added comprehensive tutorials with Quick Start examples and Marimo notebook examples
2. Expanded Docs section in README with MkDocs build instructions

## Version 0.2.13

1. Type checking improvements with mypy
2. Updated pandas-stubs and dependencies

## Version 0.2.6

1. New features in FEAModel: support for frames and load combinations

## Version 0.2.0

1. Available on PyPI via `pip install pycivil`
2. Module xstrumodeler for generic shape RC section is a requirement
3. Separated sws-mind backend to separate module
4. Added Strand7 post-processor tool
