### Elemento strutturale e classe di calcestruzzo

| Descrizione | Valore |
|-------------|--------|
| Elemento strutturale | **{{ elementDescr }}** |
| Norma utilizzata | **{{ keyCode }}** |
| Classe del calcestruzzo | **{{ concreteClass }}** |

### Valori medi e caratteristici $[N/mm^2]$

| Caratteristica | Valore | Rif. |
|----------------|--------|------|
| Resistenza cubica a 28gg | $R_{ck}={{ value_Rck }}$ | Tab. 4.1.1 |
| Resistenza cilindrica a 28gg | $f_{ck}={{ value_fck }}$ | Tab. 4.1.1 |
| Resistenza media a compressione | $f_{cm}=f_{ck}+8={{ value_fcm }}$ | [11.2.2] |
| Resistenza media a trazione | $f_{ctm}={{ value_fctm }}$ | [11.2.3] |
| Modulo elastico medio | $E_{cm}=22000 \left(\frac{f_{cm}}{10}\right)^{0.3}={{ value_Ecm }}$ | [11.2.5] |

### Valori di progetto $[N/mm^2]$

| Caratteristica | Valore | Rif. |
|----------------|--------|------|
| Riduzione a lungo termine | $\alpha_{cc}={{ value_alphacc }}$ | [4.1.2.1.1.1] |
| Coefficiente di sicurezza | $\gamma_{c}={{ value_gammac }}$ | [4.1.2.1.1.1] |
| Resistenza cilindrica di progetto | $f_{cd}=\alpha_{cc}\cdot\frac{f_{ck}}{\gamma_{c}}={{ value_fcd }}$ | [4.1.3] |
| Max compr. in combinazione rara | $\sigma_{c,max}^{car}=0.60 \cdot f_{ck} = {{ value_sigmaCar }}$ | [4.1.15] |
| Max compr. in combinazione q.p. | $\sigma_{c,max}^{qp}=0.45 \cdot f_{ck} = {{ value_sigmaQp }}$ | [4.1.16] |
