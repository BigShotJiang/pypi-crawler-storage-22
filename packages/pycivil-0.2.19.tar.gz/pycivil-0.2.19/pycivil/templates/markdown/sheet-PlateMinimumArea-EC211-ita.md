### Dati generali

| Descrizione | Valore |
|-------------|--------|
| Elemento strutturale | **{{ elementDescr }}** |
| Norma utilizzata per il materiale | **{{ keyCode }}** |

### Caratteristiche dei materiali

| Descrizione | Valore | u.d.m. |
|-------------|--------|--------|
| Classe del calcestruzzo | **{{ concreteClass }}** | ... |
| Resistenza cilindrica a compressione | $f_{ck}={{ cls_fck }}$ | $N/mm^2$ |
| Resistenza media a trazione | $f_{ctm}={{ cls_fctm }}$ | $N/mm^2$ |
| Classe di acciaio | **{{ steelClass }}** | ... |
| Resistenza caratteristica a snervamento | $f_{yk}={{ steel_fyk }}$ | $N/mm^2$ |

### Dati geometrici della sezione

| Descrizione | Valore | u.d.m. |
|-------------|--------|--------|
| Altezza dell'elemento | $H={{ hEl }}$ | $mm$ |
| Diametro delle barre principali | $\phi_{lt} = {{ rebarD }}$ | $mm$ |
| Diametro delle barre secondarie | $\phi_{lt}^{*} = {{ rebarDSec }}$ | $mm$ |
| Copriferro delle barre principali | $c = {{ cover }}$ | $mm$ |
| Copriferro delle barre secondarie | $c^*={{ coverSec }}$ | $mm$ |
| Diametro barre trasversali | $\phi_{st}={{ stirrupD }}$ | $mm$ |
| Numero di bracci trasversali | $n_{b,t}={{ nbLegDirX }}$ | ... |

### Armatura a flessione minima in direzione principale

| Descrizione | Valore | u.d.m. | Rif. |
|-------------|--------|--------|------|
| Altezza utile | $d=H-c-\frac{\phi_{lt}}{2}={{ heightUtil }}$ | $mm$ | |
| Area utile | $A_u=b_{t,med} \cdot d=1000 \cdot d = {{ areaUtil }}$ | $mm^2$ | |
| Area minima criterio (1) | $A_{min}^{(1)}=0.26 \cdot \frac {f_{ctm}} {f_{yk}}\cdot A_u = {{ minimumRebarAreaCrit1 }}$ | $mm^2$ | 9.3.1.1 (1) |
| Area minima criterio (2) | $A_{min}^{(2)}=0.0013 \cdot A_u= {{ minimumRebarAreaCrit2 }}$ | $mm^2$ | 9.3.1.1 (1) |
| Area minima | $A_{min}=max(A_{min}^{(1)},A_{min}^{(2)})={{ minimumRebarArea }}$ | $mm^2$ | |
| Distanza massima in zona corrente | $s_{max,slabs}=min(3H, 400)={{ distMaxRebar }}$ | $mm$ | 9.3.1.1 (3) |
| Distanza massima con momento massimo | $s_{max,slabs}^m=min(2H, 250)={{ distMaxRebarMaxLoad }}$ | $mm$ | 9.3.1.1 (3) |
| Area di acciaio in zona corrente | $A_{disp}={{ disposedRebarArea }}$ | $mm^2$ | |
| Numero di barre in zona corrente | $n_{disp}={{ disposedRebarNumber }}$ | ... | |
| Area di acciaio con momento massimo | $A_{disp}^m={{ disposedRebarAreaMaxLoad }}$ | $mm^2$ | |
| Numero di barre con momento massimo | $n_{disp}^m={{ disposedRebarNumberMaxLoad }}$ | ... | |

### Armatura a flessione minima in direzione secondaria

| Descrizione | Valore | u.d.m. | Rif. |
|-------------|--------|--------|------|
| Altezza utile | $d^*=H^*-c^*-\frac{\phi_{lt}^*}{2}={{ heightUtilSec }}$ | $mm$ | |
| Area utile | $A_u^*=b_{t,med}^* \cdot d^*=1000 \cdot d^* = {{ areaUtilSec }}$ | $mm^2$ | |
| Area minima criterio (1) | $A_{min}^{*(1)}=0.26 \cdot \frac {f_{ctm}} {f_{yk}}\cdot A_u^* = {{ minimumRebarAreaCrit1Sec }}$ | $mm^2$ | 9.3.1.1 (1) |
| Area minima criterio (2) | $A_{min}^{*(2)}=0.0013 \cdot A_u^*= {{ minimumRebarAreaCrit2Sec }}$ | $mm^2$ | 9.3.1.1 (1) |
| Area minima | $A_{min}^*=max(A_{min}^{*(1)},A_{min}^{*(2)})={{ minimumRebarAreaSec }}$ | $mm^2$ | |
| Distanza massima in zona corrente | $s_{max,slabs}^*=min(3.5 H^*, 450)={{ distMaxRebarSec }}$ | $mm$ | 9.3.1.1 (3) |
| Distanza massima con momento massimo | $s_{max,slabs}^{*m}=min(3 H^*, 400)={{ distMaxRebarMaxLoadSec }}$ | $mm$ | 9.3.1.1 (3) |
| Area di acciaio in zona corrente | $A_{disp}^*={{ disposedRebarAreaSec }}$ | $mm^2$ | |
| Numero di barre in zona corrente | $n_{disp}^{*}={{ disposedRebarNumberSec }}$ | ... | |
| Area di acciaio con momento massimo | $A_{disp}^{*m}={{ disposedRebarAreaMaxLoadSec }}$ | $mm^2$ | |
| Numero di barre con momento massimo | $n_{disp}^{*m}={{ disposedRebarNumberMaxLoadSec }}$ | ... | |

### Armatura a taglio minima (spilli)

| Descrizione | Valore | u.d.m. | Rif. |
|-------------|--------|--------|------|
| Area minima per metro di elemento | $\frac{A_{sw,min}}{s} = 0.08 \cdot \frac{\sqrt{f_{ck}}}{f_{yk}}={{ minimumRebarAreaForElementLenght }}$ | $mm^2$ | 9.3.2 (2) |
| Passo massimo trasversale dei bracci | $s_{t,max}=1.5 \cdot d={{ maxStepTrasv }}$ | $mm$ | 9.3.2 (5) |
| Numero di bracci complessivo per garantire area minima | $n_{b}={{ legsNumber }}$ | ... | |
| Numero di bracci trasversali calcolato | $n_{b,c}={{ legsNumberTrasv }}$ | ... | |
| Passo massimo per disporre area minima (1) | $s_{max}^{(1)}=\frac{n_{b,t}}{n_{b}}\cdot 1000={{ maxStepLongCrit1 }}$ | $mm$ | |
| Passo massimo con altezza utile (2) | $s_{max}^{(2)}=0.75 \cdot d \cdot (1+ \cot \alpha)={{ maxStepLongCrit2 }}$ | $mm$ | 9.3.2 (4) |
| Passo massimo in generale | $s_{max}=min(s_{max}^{(1)},s_{max}^{(2)})={{ maxStep }}$ | $mm$ | |
| Area staffe disposta per metro di elemento | $\frac{A_{sw}}{s} = {{ rebarAreaForElementLenght }}$ | $mm^2$ | |
