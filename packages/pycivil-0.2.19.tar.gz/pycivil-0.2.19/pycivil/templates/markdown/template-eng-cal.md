---
title: "{{ project_brief }}"
module: "{{ module_name }}"
version: "{{ module_version }}"
date: "{{ report_date }}"
time: "{{ report_time }}"
designer: "{{ report_designer }}"
token: "{{ report_token }}"
---

<!-- Engineering Calculation Document -->
<!-- Markdown Template converted from LaTeX -->
<!-- Original: http://www.LaTeXTemplates.com -->
<!-- License: CC BY-NC-SA 3.0 -->

# {{ project_brief }}

| | | | |
|------------|-------------------------|----------|------------------------|
| **Project** | {{ project_brief }}    | **Page** | {{ page }}             |
| **Module**  | {{ module_name }}      | **Date** | {{ report_date }}      |
| **Version** | {{ module_version }}   | **Time** | {{ report_time }}      |
| **Designer**| {{ report_designer }}  | **Token**| {{ report_token }}     |

---

{{ place_holder }}

---

{% if glossary %}
## Symbol Index

{% include 'template-ita-gloss.md' %}
{% endif %}
