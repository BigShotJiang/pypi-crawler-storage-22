<!-- Load Combinations and Forces Table - NTC2018 -->

Nella seguente tabella sono elencate le caratteristiche di sollecitazione nelle
varie combinazioni di carico.

### Combinazioni di carico e sollecitazioni

| **id** | $F_x$ | $F_y$ | $F_z$ | **Descrizione** | **S.L.** | **FR.** |
|--------|-------|-------|-------|-----------------|----------|---------|
|        | *[KN]* | *[KN]* | *[KN]* |                |          |         |
|        | $M_x$ | $M_y$ | $M_z$ |                 |          |         |
|        | *[KNm]* | *[KNm]* | *[KNm]* |              |          |         |
{% for force in forces %}
| {{ force.id }} | {{ force.Fx }} | {{ force.Fy }} | {{ force.Fz }} | {{ force.descr }} | {{ force.limitState }} | {{ force.frequency }} |
|                | {{ force.Mx }} | {{ force.My }} | {{ force.Mz }} |                   |                        |                       |
{% endfor %}

Ogni combinazione ha un identificativo unico (**id**).

La colonna **S.L.** contiene il tipo di stato limite rappresentato dalle
seguenti possibilita:

- **SLU** - Stati limite ultimi
- **SLE** - Stati limite di esercizio

La colonna **FR.** contiene la combinazione di carico che rappresenta la frequenza:

- **RAR** - Combinazione di carico rara
- **FRE** - Combinazione di carico frequente
- **QP** - Combinazione di carico quasi permanente
