<!-- Rebar Material Properties - NTC2018 -->

{% if byCode %}
Avendo scelto la seguente classe di acciaio e la sensibilita dell'armatura:

| Classe | Norma | Sensibilita |
|--------|-------|-------------|
| **{{ classe }}** | {{ norma }} | {{ sensitivity }} |

si assumono i seguenti valori caratteristici per il materiale
{% else %}
Per il materiale si scelgono i seguenti valori caratteristici:
{% endif %}

### Parametri dell'acciaio

| Parametro | Valore | Parametro | Valore |
|-----------|--------|-----------|--------|
| $f_{sy}$ | {{ fsy }} | $E_{s}$ | {{ Es }} |
| $\gamma_s$ | {{ gammas }} | $\sigma^{car}_{sd}$ | {{ sigmas_max_c }} |
| $e_{su}$ | {{ esu }} | $e_{sy} = \frac{f_{sy}}{E_{s}}$ | {{ esy }} |

{% if not byCode %}
Ai fini del calcolo a fessurazione si assume che l'armatura sia di tipo **{{ sensitivity }}**
{% endif %}
