<!-- SLU Verification Table for Generic RC Sections (Biaxial Bending) -->

### Verifiche SLU per pressoflessione retta

| **id** | $N_{ed}$ | $M_{xed}$ | $M_{yed}$ | $N_{rd}$ | $M_{xrd}$ | $M_{yrd}$ | **FS** | **check** |
|--------|----------|-----------|-----------|----------|-----------|-----------|--------|-----------|
|        | *[KN]*   | *[KNm]*   | *[KNm]*   | *[KN]*   | *[KNm]*   | *[KNm]*   | *[...]*| *[...]*   |
{% for c in check_SLU_MN %}
| {{ c.id }} | {{ c.Ned }} | {{ c.Mxed }} | {{ c.Myed }} | {{ c.Nrd }} | {{ c.Mxrd }} | {{ c.Myrd }} | {{ c.FS }} | {{ c.check }} |
{% endfor %}

{% for f in figures %}
### Check agli SLU - Parte {{ f.figIndex }} di {{ nbFigs }}

{% for url in f.domainUrls %}
![Check con id = {{ url.idLoad }}]({{ url.domainUrl }}){width={{ figuresWidth }}}
{% endfor %}
{% endfor %}
