# import math
from pathlib import Path

# import pytest
from pycivil.EXAStructural.codes import Code
from pycivil.EXAStructural.materials import Concrete, ConcreteSteel
from pycivil.EXAStructural.templateRCRect import RCTemplRectEC2, SectionPlot

from matplotlib import (
    pyplot as plt,
)

from matplotlib.pyplot import Figure, Axes

def section_1():
    code = Code("NTC2008")
    concrete = Concrete(descr="My concrete")
    concrete.setByCode(code, "C32/40")
    steel = ConcreteSteel(descr="My steel")
    steel.setByCode(code, "B450C")
    rcSection = RCTemplRectEC2(1, "Template RC Section - Manuscript #5")
    rcSection.setDimH(500)
    rcSection.setDimW(1000)
    rcSection.addSteelArea("LINE-MT", dist=74, d=24, nb=5, sd=200)
    rcSection.addSteelArea("LINE-MB", dist=71, d=18, nb=5, sd=200)
    return rcSection

def test_section_1(tmp_path: Path):
    section_plotter = SectionPlot(section_1())
    section_plotter.plot()
    section_plotter.save(tmp_path / Path("test.png"), dpi=300)
