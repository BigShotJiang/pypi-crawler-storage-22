# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

import json
from pathlib import Path

from pycivil.EXAStructural.rcrecsolver.srvRcSecCheck import ModelInputRcSecCheck
from pycivil.EXAUtils.markdownReportMakers import ConcreteSectionMdFB
from pycivil.EXAUtils.report import (
    MarkdownReporter,
    ReportTemplateEnum,
    getMarkdownTemplatesPath,
)


def test_report_markdown_section_01(tmp_path: Path):
    """Test RC section markdown fragment generation with first test data."""
    with open(Path(__file__).parent / "test_report_latex_sections_01.json") as jsonFile:
        jsonObject = json.load(jsonFile)
        jsonFile.close()

    iData = ModelInputRcSecCheck(**jsonObject)

    print(json.dumps(iData.model_dump(), indent=3))

    section = iData.buildRcsRectangular()
    if section is not None:
        markdownTemplatePath = getMarkdownTemplatesPath()
        f = ConcreteSectionMdFB(markdownTemplatePath, rcs=section).buildFragment()
        print(f.frags())
        reporter = MarkdownReporter(markdownTemplatePath)
        reporter.linkFragments(
            template=ReportTemplateEnum.MD_ENG_CAL, fragments=[f]
        )
        reporter.compileDocument(path=str(tmp_path), output_format="md")
        print(f"Temporary path for test is {tmp_path}")
        assert tmp_path.joinpath("report.md").exists()

        # Verify content has section data
        content = tmp_path.joinpath("report.md").read_text(encoding="utf-8")
        assert "400" in content  # width or height


def test_report_markdown_section_02(tmp_path: Path):
    """Test RC section markdown fragment generation with second test data."""
    with open(Path(__file__).parent / "test_report_latex_sections_02.json") as jsonFile:
        jsonObject = json.load(jsonFile)
        jsonFile.close()

    iData = ModelInputRcSecCheck(**jsonObject)

    print(json.dumps(iData.model_dump(), indent=3))

    section = iData.buildRcsRectangular()
    if section is not None:
        markdownTemplatePath = getMarkdownTemplatesPath()
        f = ConcreteSectionMdFB(markdownTemplatePath, rcs=section).buildFragment()
        print(f.frags())
        reporter = MarkdownReporter(markdownTemplatePath)
        reporter.linkFragments(
            template=ReportTemplateEnum.MD_ENG_CAL, fragments=[f]
        )
        reporter.compileDocument(path=str(tmp_path), output_format="md")
        print(f"Temporary path for test is {tmp_path}")
        assert tmp_path.joinpath("report.md").exists()


def test_report_markdown_section_with_html(tmp_path: Path):
    """Test RC section with HTML output."""
    with open(Path(__file__).parent / "test_report_latex_sections_01.json") as jsonFile:
        jsonObject = json.load(jsonFile)
        jsonFile.close()

    iData = ModelInputRcSecCheck(**jsonObject)

    section = iData.buildRcsRectangular()
    if section is not None:
        markdownTemplatePath = getMarkdownTemplatesPath()
        f = ConcreteSectionMdFB(markdownTemplatePath, rcs=section).buildFragment()
        reporter = MarkdownReporter(markdownTemplatePath)
        reporter.linkFragments(
            template=ReportTemplateEnum.MD_ENG_CAL, fragments=[f]
        )
        reporter.compileDocument(path=str(tmp_path), output_format="html")
        print(f"Temporary path for test is {tmp_path}")
        assert tmp_path.joinpath("report.md").exists()
        assert tmp_path.joinpath("report.html").exists()
