import pycogat
from pycogat.cogat import cogat_split

def test_cogat_split_exists():
    assert cogat_split is not None