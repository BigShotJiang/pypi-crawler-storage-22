"""Contrail modeling support."""
