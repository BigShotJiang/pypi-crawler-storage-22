# Authors

Contributors to pyconverters_mistralocr include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
