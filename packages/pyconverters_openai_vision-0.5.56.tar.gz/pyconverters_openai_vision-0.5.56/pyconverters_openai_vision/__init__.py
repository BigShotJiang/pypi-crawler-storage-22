"""OpenAIVision converter"""
__version__ = "0.5.56"
