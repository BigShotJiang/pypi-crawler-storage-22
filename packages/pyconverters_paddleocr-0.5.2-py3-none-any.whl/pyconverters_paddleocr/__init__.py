"""Convert PDF to structured text using PaddleOCR"""
__version__ = "0.5.2"
