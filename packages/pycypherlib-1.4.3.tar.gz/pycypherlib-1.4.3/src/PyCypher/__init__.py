from .Cy import Cy, __version__

__all__ = ["Cy", "__version__"]


def main() -> None:
    """CLI entry point: print version and short usage."""
    print(f"PyCypher {__version__}")
    print("Usage: from PyCypher import Cy")
    print("  Cy().enc('file.txt').P('password')")
    print("  Cy().dec('file.txt.cy').P('password')")