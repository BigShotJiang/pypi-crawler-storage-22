"""Pydantic Evals framework for evaluating toolsets."""

