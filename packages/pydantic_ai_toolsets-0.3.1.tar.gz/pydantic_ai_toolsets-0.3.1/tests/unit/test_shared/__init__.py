"""Unit tests for shared utilities."""
