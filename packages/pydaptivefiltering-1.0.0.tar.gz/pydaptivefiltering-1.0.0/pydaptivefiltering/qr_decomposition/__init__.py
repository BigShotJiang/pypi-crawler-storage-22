# qr_decomposition.__init__.py

from .rls import QRRLS

__all__ = ["QRRLS"]