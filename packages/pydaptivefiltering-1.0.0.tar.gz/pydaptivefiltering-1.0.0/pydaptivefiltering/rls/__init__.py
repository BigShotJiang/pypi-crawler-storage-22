# rls.__init__.py

from .rls import RLS
from .rls_alt import RLSAlt

__all__ = ['RLS', 'RLSAlt']