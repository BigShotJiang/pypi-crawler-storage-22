# pydataframer-databricks

Databricks connector package for Dataframer, providing seamless integration with Databricks SQL and data operations.

## Installation

```bash
pip install pydataframer-databricks
```

## Building

Requires [uv](https://docs.astral.sh/uv/) installed in your environment.

```bash
uv build
```

## Development

```bash
# Install with dev dependencies
uv pip install -e ".[dev]"

# Run tests
pytest
```

