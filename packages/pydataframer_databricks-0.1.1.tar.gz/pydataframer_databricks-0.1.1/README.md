# pydataframer-databricks

Databricks connector for Dataframer

## Installation

```bash
pip install pydataframer-databricks
```

## Usage

```python
from pydataframer_databricks import DatabricksConnector, DatasetType, FileType

databricks_connector = DatabricksConnector(dbutils, scope="dataframer")

# Fetch sample data
df = databricks_connector.fetch_sample_data(
    num_items_to_select=100,
    table_name="catalog.schema.table"
)

# Load generated data
databricks_connector.load_generated_data(
    table_name="catalog.schema.table",
    downloaded_zip=downloaded_zip,
    dataset_type=DatasetType.SINGLE_FILE,
    file_type=FileType.CSV
)
```