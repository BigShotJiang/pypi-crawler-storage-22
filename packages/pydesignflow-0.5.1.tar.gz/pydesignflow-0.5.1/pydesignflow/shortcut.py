# SPDX-FileCopyrightText: 2024 Tobias Kaiser <mail@tb-kaiser.de>
# SPDX-License-Identifier: Apache-2.0

# PYTHON_ARGCOMPLETE_OK

import importlib.util
from pathlib import Path
import sys
import os
import warnings

def import_flow_addpath():
    flow_package = Path.cwd() / "flow" / "__init__.py"
    flow_module = Path.cwd() / "flow.py"

    if not (flow_package.exists() or flow_module.exists()):
        raise FileNotFoundError()
    sys.path.insert(0, str(Path.cwd()))
    import flow
    return flow

def import_flow_importlib():
    flow_package = Path.cwd() / "flow" / "__init__.py"
    flow_module = Path.cwd() / "flow.py"

    if flow_package.exists():
        flow_path = flow_package
    elif flow_module.exists():
        flow_path = flow_module
    else:
        raise FileNotFoundError()

    spec=importlib.util.spec_from_file_location("flow", flow_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules["flow"] = module
    spec.loader.exec_module(module)
    return module

import_flow = import_flow_importlib
"""
import_flow can be set to import_flow_importlib or import_flow_addpath.
They should both do roughly the same.
"""


def main():
    warnings.simplefilter('always', DeprecationWarning)

    try:
        flow = import_flow()
    except FileNotFoundError:
        print("Error: Could not import flow module.")
        print("Ensure that your working directory has either flow.py or flow/__init__.py.")
        sys.exit(1)

    prog = os.path.basename(sys.argv[0])
    args = sys.argv[1:]
    flow.flow.cli_main(args)


if __name__=="__main__":
    main()
