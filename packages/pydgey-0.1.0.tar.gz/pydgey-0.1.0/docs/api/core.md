# Core API

::: pydgey.core
