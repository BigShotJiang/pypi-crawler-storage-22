# Perf / Microbench

Self-contained benchmarks for core hot paths. Does not import `pydivkit`
(the generated `pydivkit.div` package may be absent).

## Running

```bash
make bench                                      # via Makefile
python3 perf/bench_cast_value_type.py           # direct
python3 perf/bench_cast_value_type.py --check   # CI mode: fail on regression
```

## What is benchmarked

### _cast_value_type

- Exact type match (fast path)
- Optional[int] with None
- Sequence[int] casting
- Mapping[str, int] casting
- Union dict dispatch (via injected types)
- Union exact instance match

### dict() / make_div()

- `dict()` serialization only (pre-built tree)
- `make_div()` wrapper (templates + card)
- Full build + dict (construction + serialization)
- Full build + make_div

### dump()

- Flat entity serialization
- Nested entities (3+ levels deep)
- Sequence of 10 entities
- Mapping with mixed values (Expr, enum, entity)
- Enum value serialization

## Regression check

Pass `--check` to enable CI mode. Each benchmark is compared against a
generous upper bound. If any benchmark exceeds its threshold, the script
exits with code 1.
