"""
Build helpers for cffi bindings from the stepfunc/dnp3 C headers.

Preprocesses dnp3.h to extract what cffi can parse (enums, structs,
function declarations, numeric #define constants).
"""

import os
import re
from pathlib import Path


def _project_root():
    """Return the project root (two levels above src/dnp3/)."""
    return Path(__file__).resolve().parent.parents[1]


def find_header():
    """Locate the dnp3.h header file from the stepfunc/dnp3 build."""
    root = _project_root()
    pkg_dir = Path(__file__).resolve().parent
    candidates = [
        # Bundled inside installed package (wheel distribution)
        pkg_dir / "vendor" / "dnp3.h",
        # Sibling directory (common development layout)
        root.parent / "stepfunc-dnp3" / "ffi" / "bindings" / "c" / "generated" / "include" / "dnp3.h",
        # Vendored inside project
        root / "vendor" / "dnp3" / "include" / "dnp3.h",
        # Environment override
        Path(os.environ.get("DNP3_HEADER_PATH", "/nonexistent")),
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise FileNotFoundError(
        "Cannot find dnp3.h. Build stepfunc/dnp3 first or set DNP3_HEADER_PATH.\n"
        f"Searched: {[str(c) for c in candidates]}"
    )


def find_shared_lib():
    """Locate the compiled libdnp3_ffi shared library."""
    root = _project_root()
    pkg_dir = Path(__file__).resolve().parent
    candidates = [
        # Bundled inside installed package (wheel distribution)
        pkg_dir / "vendor" / "libdnp3_ffi.so",
        # Sibling directory — pre-built artifacts
        root.parent / "stepfunc-dnp3" / "ffi" / "bindings" / "c" / "generated" / "lib" / "x86_64-unknown-linux-gnu" / "libdnp3_ffi.so",
        # Sibling directory — cargo build output
        root.parent / "stepfunc-dnp3" / "target" / "release" / "libdnp3_ffi.so",
        # Vendored inside project
        root / "vendor" / "dnp3" / "lib" / "libdnp3_ffi.so",
        # Environment override
        Path(os.environ.get("DNP3_LIB_PATH", "/nonexistent")),
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise FileNotFoundError(
        "Cannot find libdnp3_ffi.so. Build stepfunc/dnp3 first or set DNP3_LIB_PATH.\n"
        f"Searched: {[str(c) for c in candidates]}"
    )


def preprocess_header(header_path: Path) -> str:
    """
    Preprocess dnp3.h for cffi cdef consumption.

    Strips:
    - Static inline functions (with their full bodies)
    - #include, #pragma, #ifdef/#endif, extern "C"
    - C comments (// and /* */)

    Keeps:
    - typedef enum { ... } name;
    - typedef struct name { ... } name;
    - typedef struct name name; (opaque forward declarations)
    - Non-static function declarations
    - #define DNP3_* constants
    """
    text = header_path.read_text()

    # Remove multi-line comments
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)

    # Remove single-line comments
    text = re.sub(r"//[^\n]*", "", text)

    # Remove static functions with their bodies using brace-depth tracking
    result = []
    i = 0
    while i < len(text):
        if text[i:i+7] == "static ":
            j = i + 7
            while j < len(text) and text[j] != "{" and text[j] != ";":
                j += 1
            if j < len(text) and text[j] == "{":
                depth = 1
                j += 1
                while j < len(text) and depth > 0:
                    if text[j] == "{":
                        depth += 1
                    elif text[j] == "}":
                        depth -= 1
                    j += 1
                i = j
                continue
            elif j < len(text) and text[j] == ";":
                i = j + 1
                continue
        result.append(text[i])
        i += 1

    text = "".join(result)

    # Filter preprocessor directives
    lines = text.split("\n")
    output_lines = []
    for line in lines:
        stripped = line.strip()

        if stripped.startswith("#pragma"):
            continue
        if stripped.startswith(("#ifdef", "#ifndef", "#endif")):
            continue
        if stripped.startswith("#include"):
            continue
        if 'extern "C"' in stripped:
            continue

        # Keep numeric DNP3_* constants only (cffi can't parse string defines)
        if stripped.startswith("#define DNP3_"):
            if '"' in stripped:
                continue
            output_lines.append(stripped)
            continue

        if stripped.startswith("#define"):
            continue

        output_lines.append(line)

    text = "\n".join(output_lines)

    # Remove lone closing braces left over from extern "C" block
    lines2 = text.split("\n")
    final_lines = [line for line in lines2 if line.strip() != "}"]
    text = "\n".join(final_lines)

    # Clean up excessive blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[ \t]+\n", "\n", text)

    return text.strip() + "\n"


def get_cdef():
    """Get the preprocessed cdef string for cffi."""
    header_path = find_header()
    return preprocess_header(header_path)


if __name__ == "__main__":
    cdef = get_cdef()
    print(cdef)
