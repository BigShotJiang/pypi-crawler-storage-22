"""
Raw cffi bindings for the stepfunc/dnp3 C FFI library.

This module provides the low-level FFI object and loaded library.
Higher-level modules should import `ffi` and `lib` from here.
"""

import cffi

from ._build_ffi import get_cdef, find_shared_lib

# Create the FFI instance
ffi = cffi.FFI()

# Parse the C header definitions
_cdef = get_cdef()
ffi.cdef(_cdef)

# Load the shared library
_lib_path = str(find_shared_lib())
lib = ffi.dlopen(_lib_path)

# Error code names (the to_string functions are static inline in the header,
# not exported from the .so, so we replicate them here)
_PARAM_ERROR_NAMES = {
    0: "ok",
    1: "invalid_timeout",
    2: "null_parameter",
    3: "string_not_utf8",
    4: "no_support",
    5: "association_does_not_exist",
    6: "association_duplicate_address",
    7: "invalid_socket_address",
    8: "invalid_dnp3_address",
    9: "invalid_buffer_size",
    10: "address_filter_conflict",
    11: "server_already_started",
    12: "server_bind_error",
    13: "master_already_shutdown",
    14: "runtime_creation_failure",
    15: "runtime_destroyed",
    16: "runtime_cannot_block_within_async",
    17: "logging_already_configured",
    18: "point_does_not_exist",
    19: "invalid_peer_certificate",
    20: "invalid_local_certificate",
    21: "invalid_private_key",
    22: "invalid_dns_name",
    23: "other_tls_error",
    24: "wrong_channel_type",
    25: "consumed",
}


class DNP3Error(Exception):
    """Base exception for DNP3 library errors."""
    pass


def check_error(err):
    """Check a dnp3_param_error_t return value and raise on failure."""
    if err != lib.DNP3_PARAM_ERROR_OK:
        name = _PARAM_ERROR_NAMES.get(err, f"unknown({err})")
        raise DNP3Error(f"DNP3 error: {name}")
