"""
TCP/TLS/Serial/UDP channel creation for DNP3 master stations.

Includes both standard channel creation and v2 variants that accept
ConnectOptions for local endpoint binding and connection timeout.
"""

from typing import Optional, List

from ._ffi import ffi, lib, check_error
from .types import (
    LinkErrorMode,
    DecodeLevel,
    ConnectStrategy,
)
from .handler import ClientStateListener, PortStateListener


class MasterChannelConfig:
    """Configuration for a master channel."""

    def __init__(
        self,
        address: int = 1,
        decode_level: Optional[DecodeLevel] = None,
        tx_buffer_size: int = 2048,
        rx_buffer_size: int = 2048,
    ):
        self.address = address
        self.decode_level = decode_level or DecodeLevel()
        self.tx_buffer_size = tx_buffer_size
        self.rx_buffer_size = rx_buffer_size

    def to_ffi(self):
        """Create the C config struct."""
        config = ffi.new("dnp3_master_channel_config_t*")
        config.address = self.address
        config.decode_level = ffi.new("dnp3_decode_level_t*", self.decode_level.to_ffi())[0]
        config.tx_buffer_size = self.tx_buffer_size
        config.rx_buffer_size = self.rx_buffer_size
        return config[0]


class ConnectOptions:
    """Options for controlling TCP connection behavior.

    Wraps dnp3_connect_options_t and supports setting a local endpoint
    (source IP/port) and connection timeout.

    Example::

        opts = ConnectOptions()
        opts.set_local_endpoint("192.168.1.10:0")
        opts.set_timeout(5000)

        channel = create_tcp_channel_2(
            runtime, endpoints=["127.0.0.1:20000"],
            connect_options=opts,
        )
    """

    def __init__(self):
        self._ptr = lib.dnp3_connect_options_create()

    def set_local_endpoint(self, endpoint: str):
        """Set the local source endpoint (e.g. "192.168.1.10:0").

        Args:
            endpoint: Local "host:port" address to bind to.
        """
        check_error(lib.dnp3_connect_options_set_local_endpoint(self._ptr, endpoint.encode()))

    def set_timeout(self, timeout_ms: int):
        """Set the connection timeout in milliseconds.

        Args:
            timeout_ms: Timeout value in milliseconds.
        """
        lib.dnp3_connect_options_set_timeout(self._ptr, timeout_ms)

    def destroy(self):
        """Destroy the options and free resources."""
        if self._ptr is not None:
            lib.dnp3_connect_options_destroy(self._ptr)
            self._ptr = None

    def __del__(self):
        self.destroy()


def create_tcp_channel(
    runtime,
    endpoints: List[str],
    config: Optional[MasterChannelConfig] = None,
    link_error_mode: LinkErrorMode = LinkErrorMode.CLOSE,
    connect_strategy: Optional[ConnectStrategy] = None,
    listener: Optional[ClientStateListener] = None,
):
    """
    Create a TCP master channel.

    Args:
        runtime: Runtime instance (from Runtime class)
        endpoints: List of "host:port" strings. First is primary.
        config: Master channel configuration
        link_error_mode: How to handle link errors
        connect_strategy: Reconnection strategy
        listener: Connection state listener

    Returns:
        A MasterChannel wrapping the C pointer
    """
    from .master import MasterChannel

    config = config or MasterChannelConfig()
    connect_strategy = connect_strategy or ConnectStrategy()
    listener = listener or ClientStateListener()

    # Create endpoint list
    ep_list = lib.dnp3_endpoint_list_create(endpoints[0].encode())
    for ep in endpoints[1:]:
        lib.dnp3_endpoint_list_add(ep_list, ep.encode())

    # Create channel
    channel_ptr = ffi.new("dnp3_master_channel_t**")
    strategy_ffi = ffi.new("dnp3_connect_strategy_t*", connect_strategy.to_ffi())[0]

    err = lib.dnp3_master_channel_create_tcp(
        runtime._ptr,
        link_error_mode.value,
        config.to_ffi(),
        ep_list,
        strategy_ffi,
        listener.as_ffi(),
        channel_ptr,
    )
    lib.dnp3_endpoint_list_destroy(ep_list)
    check_error(err)

    return MasterChannel(channel_ptr[0], listener)


def create_tcp_channel_2(
    runtime,
    endpoints: List[str],
    config: Optional[MasterChannelConfig] = None,
    link_error_mode: LinkErrorMode = LinkErrorMode.CLOSE,
    connect_strategy: Optional[ConnectStrategy] = None,
    connect_options: Optional[ConnectOptions] = None,
    listener: Optional[ClientStateListener] = None,
):
    """Create a TCP master channel with ConnectOptions support.

    Like create_tcp_channel but accepts a ConnectOptions instance for
    specifying local endpoint binding and connection timeout.

    Args:
        runtime: Runtime instance.
        endpoints: List of "host:port" strings.
        config: Master channel configuration.
        link_error_mode: How to handle link errors.
        connect_strategy: Reconnection strategy.
        connect_options: TCP connection options (local endpoint, timeout).
        listener: Connection state listener.

    Returns:
        A MasterChannel wrapping the C pointer.
    """
    from .master import MasterChannel

    config = config or MasterChannelConfig()
    connect_strategy = connect_strategy or ConnectStrategy()
    listener = listener or ClientStateListener()

    ep_list = lib.dnp3_endpoint_list_create(endpoints[0].encode())
    for ep in endpoints[1:]:
        lib.dnp3_endpoint_list_add(ep_list, ep.encode())

    strategy_ffi = ffi.new("dnp3_connect_strategy_t*", connect_strategy.to_ffi())[0]
    co_ptr = connect_options._ptr if connect_options is not None else ffi.NULL

    channel_ptr = ffi.new("dnp3_master_channel_t**")
    err = lib.dnp3_master_channel_create_tcp_2(
        runtime._ptr,
        link_error_mode.value,
        config.to_ffi(),
        ep_list,
        strategy_ffi,
        co_ptr,
        listener.as_ffi(),
        channel_ptr,
    )
    lib.dnp3_endpoint_list_destroy(ep_list)
    check_error(err)

    return MasterChannel(channel_ptr[0], listener)


def create_tls_channel(
    runtime,
    endpoints: List[str],
    tls_config: dict,
    config: Optional[MasterChannelConfig] = None,
    link_error_mode: LinkErrorMode = LinkErrorMode.CLOSE,
    connect_strategy: Optional[ConnectStrategy] = None,
    listener: Optional[ClientStateListener] = None,
):
    """
    Create a TLS master channel.

    Args:
        runtime: Runtime instance
        endpoints: List of "host:port" strings
        tls_config: dict with keys: dns_name, peer_cert_path, local_cert_path,
                    private_key_path, password (optional), certificate_mode (optional)
        config: Master channel configuration
        link_error_mode: How to handle link errors
        connect_strategy: Reconnection strategy
        listener: Connection state listener

    Returns:
        A MasterChannel wrapping the C pointer
    """
    from .master import MasterChannel

    config = config or MasterChannelConfig()
    connect_strategy = connect_strategy or ConnectStrategy()
    listener = listener or ClientStateListener()

    ep_list = lib.dnp3_endpoint_list_create(endpoints[0].encode())
    for ep in endpoints[1:]:
        lib.dnp3_endpoint_list_add(ep_list, ep.encode())

    # Build TLS config -- keep references to char[] buffers so they are not
    # garbage-collected before the C library copies them.
    _dns_buf = ffi.new("char[]", tls_config["dns_name"].encode())
    _peer_buf = ffi.new("char[]", tls_config["peer_cert_path"].encode())
    _cert_buf = ffi.new("char[]", tls_config["local_cert_path"].encode())
    _key_buf = ffi.new("char[]", tls_config["private_key_path"].encode())
    _pass_buf = ffi.new("char[]", tls_config.get("password", "").encode())

    tls_c = ffi.new("dnp3_tls_client_config_t*")
    tls_c.dns_name = _dns_buf
    tls_c.peer_cert_path = _peer_buf
    tls_c.local_cert_path = _cert_buf
    tls_c.private_key_path = _key_buf
    tls_c.password = _pass_buf
    if "certificate_mode" in tls_config:
        tls_c.certificate_mode = tls_config["certificate_mode"]

    channel_ptr = ffi.new("dnp3_master_channel_t**")
    strategy_ffi = ffi.new("dnp3_connect_strategy_t*", connect_strategy.to_ffi())[0]

    err = lib.dnp3_master_channel_create_tls(
        runtime._ptr,
        link_error_mode.value,
        config.to_ffi(),
        ep_list,
        strategy_ffi,
        listener.as_ffi(),
        tls_c[0],
        channel_ptr,
    )
    lib.dnp3_endpoint_list_destroy(ep_list)
    check_error(err)

    # prevent GC of buffers until after check_error
    del _dns_buf, _peer_buf, _cert_buf, _key_buf, _pass_buf

    return MasterChannel(channel_ptr[0], listener)


def create_tls_channel_2(
    runtime,
    endpoints: List[str],
    tls_config: dict,
    config: Optional[MasterChannelConfig] = None,
    link_error_mode: LinkErrorMode = LinkErrorMode.CLOSE,
    connect_strategy: Optional[ConnectStrategy] = None,
    connect_options: Optional[ConnectOptions] = None,
    listener: Optional[ClientStateListener] = None,
):
    """Create a TLS master channel with ConnectOptions support.

    Like create_tls_channel but accepts a ConnectOptions instance.

    Args:
        runtime: Runtime instance.
        endpoints: List of "host:port" strings.
        tls_config: TLS configuration dict.
        config: Master channel configuration.
        link_error_mode: How to handle link errors.
        connect_strategy: Reconnection strategy.
        connect_options: TCP connection options.
        listener: Connection state listener.

    Returns:
        A MasterChannel wrapping the C pointer.
    """
    from .master import MasterChannel

    config = config or MasterChannelConfig()
    connect_strategy = connect_strategy or ConnectStrategy()
    listener = listener or ClientStateListener()

    ep_list = lib.dnp3_endpoint_list_create(endpoints[0].encode())
    for ep in endpoints[1:]:
        lib.dnp3_endpoint_list_add(ep_list, ep.encode())

    # Keep references to char[] buffers to prevent GC before C call
    _dns_buf = ffi.new("char[]", tls_config["dns_name"].encode())
    _peer_buf = ffi.new("char[]", tls_config["peer_cert_path"].encode())
    _cert_buf = ffi.new("char[]", tls_config["local_cert_path"].encode())
    _key_buf = ffi.new("char[]", tls_config["private_key_path"].encode())
    _pass_buf = ffi.new("char[]", tls_config.get("password", "").encode())

    tls_c = ffi.new("dnp3_tls_client_config_t*")
    tls_c.dns_name = _dns_buf
    tls_c.peer_cert_path = _peer_buf
    tls_c.local_cert_path = _cert_buf
    tls_c.private_key_path = _key_buf
    tls_c.password = _pass_buf
    if "certificate_mode" in tls_config:
        tls_c.certificate_mode = tls_config["certificate_mode"]

    strategy_ffi = ffi.new("dnp3_connect_strategy_t*", connect_strategy.to_ffi())[0]
    co_ptr = connect_options._ptr if connect_options is not None else ffi.NULL

    channel_ptr = ffi.new("dnp3_master_channel_t**")
    err = lib.dnp3_master_channel_create_tls_2(
        runtime._ptr,
        link_error_mode.value,
        config.to_ffi(),
        ep_list,
        strategy_ffi,
        co_ptr,
        listener.as_ffi(),
        tls_c[0],
        channel_ptr,
    )
    lib.dnp3_endpoint_list_destroy(ep_list)
    check_error(err)

    # prevent GC of buffers until after check_error
    del _dns_buf, _peer_buf, _cert_buf, _key_buf, _pass_buf

    return MasterChannel(channel_ptr[0], listener)


def create_serial_channel(
    runtime,
    path: str,
    config: Optional[MasterChannelConfig] = None,
    open_retry_delay: int = 5000,
    listener: Optional[PortStateListener] = None,
):
    """
    Create a serial master channel.

    Args:
        runtime: Runtime instance
        path: Serial port path (e.g., "/dev/ttyS0")
        config: Master channel configuration
        open_retry_delay: Retry delay in ms when port open fails
        listener: Port state listener

    Returns:
        A MasterChannel wrapping the C pointer
    """
    from .master import MasterChannel

    config = config or MasterChannelConfig()
    listener = listener or PortStateListener()

    serial_settings = ffi.new("dnp3_serial_settings_t*")
    # Use defaults (9600 baud, 8N1)
    serial_settings.baud_rate = 9600
    serial_settings.data_bits = lib.DNP3_DATA_BITS_EIGHT
    serial_settings.flow_control = lib.DNP3_FLOW_CONTROL_NONE
    serial_settings.parity = lib.DNP3_PARITY_NONE
    serial_settings.stop_bits = lib.DNP3_STOP_BITS_ONE

    channel_ptr = ffi.new("dnp3_master_channel_t**")

    err = lib.dnp3_master_channel_create_serial(
        runtime._ptr,
        config.to_ffi(),
        path.encode(),
        serial_settings[0],
        open_retry_delay,
        listener.as_ffi(),
        channel_ptr,
    )
    check_error(err)

    return MasterChannel(channel_ptr[0], None)


def create_udp_channel(
    runtime,
    local_endpoint: str,
    config: Optional[MasterChannelConfig] = None,
    retry_delay: int = 5000,
):
    """
    Create a UDP master channel.

    Args:
        runtime: Runtime instance
        local_endpoint: Local bind address "host:port"
        config: Master channel configuration
        retry_delay: Retry delay in ms

    Returns:
        A MasterChannel wrapping the C pointer
    """
    from .master import MasterChannel

    config = config or MasterChannelConfig()

    channel_ptr = ffi.new("dnp3_master_channel_t**")

    err = lib.dnp3_master_channel_create_udp(
        runtime._ptr,
        config.to_ffi(),
        local_endpoint.encode(),
        0,  # link_read_mode
        retry_delay,
        channel_ptr,
    )
    check_error(err)

    return MasterChannel(channel_ptr[0], None)
