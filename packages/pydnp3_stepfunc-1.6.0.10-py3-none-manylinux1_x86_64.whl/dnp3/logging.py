"""
DNP3 protocol logging configuration.

Wraps the stepfunc/dnp3 tracing/logging subsystem.
"""

from enum import IntEnum
from typing import Optional, Callable

from ._ffi import ffi, lib, check_error

_logging_configured = False


class LogLevel(IntEnum):
    ERROR = 0
    WARN = 1
    INFO = 2
    DEBUG = 3
    TRACE = 4


class LogOutputFormat(IntEnum):
    TEXT = 0
    JSON = 1


class TimeFormat(IntEnum):
    NONE = 0
    RFC_3339 = 1
    SYSTEM = 2


def configure_logging(
    level: LogLevel = LogLevel.WARN,
    output_format: LogOutputFormat = LogOutputFormat.TEXT,
    print_level: bool = True,
    print_module_info: bool = False,
    time_format: TimeFormat = TimeFormat.SYSTEM,
    callback: Optional[Callable[[LogLevel, str], None]] = None,
):
    """
    Configure the DNP3 library logging.

    Can only be called once. Subsequent calls will be ignored.

    Args:
        level: Minimum log level
        output_format: Text or JSON
        print_level: Include log level in output
        print_module_info: Include module info
        time_format: Timestamp format
        callback: Optional callback for log messages. If None, logs to stdout.
    """
    global _logging_configured
    if _logging_configured:
        return
    _logging_configured = True

    config = ffi.new("dnp3_logging_config_t*")
    config.level = level.value
    config.output_format = output_format.value
    config.print_level = print_level
    config.print_module_info = print_module_info
    config.time_format = time_format.value

    if callback is not None:
        @ffi.callback("void(dnp3_log_level_t, const char*, void*)")
        def _on_message(lvl, msg, ctx):
            callback(LogLevel(lvl), ffi.string(msg).decode())

        # Must keep reference alive
        configure_logging._callback_ref = _on_message

        logger = ffi.new("dnp3_logger_t*", {
            "on_message": _on_message,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]
    else:
        @ffi.callback("void(dnp3_log_level_t, const char*, void*)")
        def _on_message(lvl, msg, ctx):
            print(ffi.string(msg).decode(), end="")

        configure_logging._callback_ref = _on_message

        logger = ffi.new("dnp3_logger_t*", {
            "on_message": _on_message,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]

    lib.dnp3_configure_logging(config[0], logger)
