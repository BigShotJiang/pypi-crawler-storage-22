"""
Master station implementation wrapping the stepfunc/dnp3 C FFI.

Provides a high-level API for DNP3 master operations including:
- Polling (integrity, event, class-based)
- Read operations (specific group/variation)
- Control operations (SBO, direct operate)
- Time synchronization
- Restart commands
- Device attribute reading
- File transfer operations (get_file_info, open, close, read, write, directory)
- Dead band writing
- Advanced read operations with custom handlers
"""

import threading
from enum import IntEnum
from typing import Optional, List, Dict, Any, Callable

from ._ffi import ffi, lib, check_error, DNP3Error
from .types import (
    Variation,
    CommandMode,
    TimeSyncMode,
    FunctionCode,
    AutoTimeSync,
    DecodeLevel,
    Group12Var1,
    ControlCode,
    OpType,
    TripCloseCode,
    Flags,
    Timestamp,
    TimeQuality,
    ReadResult,
    FileResult,
)
from .handler import (
    ReadHandler,
    ReadTaskCallback,
    CommandTaskCallback,
    TimeSyncTaskCallback,
    RestartTaskCallback,
    EmptyResponseCallback,
    LinkStatusCallback,
    AssociationHandler,
    AssociationInformation,
    ClientStateListener,
    TaskCallback,
)


# --- Enums ---


class FileError(IntEnum):
    """File operation error codes."""
    OK = 0
    BAD_STATUS = 1
    NO_PERMISSION = 2
    BAD_BLOCK_NUM = 3
    ABORT_BY_USER = 4
    MAX_LENGTH_EXCEEDED = 5
    WRONG_HANDLE = 6
    # Expanded FileStatus variants (previously collapsed into BAD_STATUS)
    STATUS_PERMISSION_DENIED = 7
    STATUS_INVALID_MODE = 8
    STATUS_FILE_NOT_FOUND = 9
    STATUS_FILE_LOCKED = 10
    STATUS_TOO_MANY_OPEN = 11
    STATUS_INVALID_HANDLE = 12
    STATUS_WRITE_BLOCK_SIZE = 13
    STATUS_COMM_LOST = 14
    STATUS_CANNOT_ABORT = 15
    STATUS_NOT_OPENED = 16
    STATUS_HANDLE_EXPIRED = 17
    STATUS_BUFFER_OVERRUN = 18
    STATUS_FATAL = 19
    STATUS_BLOCK_SEQ = 20
    STATUS_UNDEFINED = 21
    # Task errors
    TOO_MANY_REQUESTS = 22
    IIN_ERROR = 23
    BAD_RESPONSE = 24
    RESPONSE_TIMEOUT = 25
    WRITE_ERROR = 26
    NO_CONNECTION = 27
    SHUTDOWN = 28
    ASSOCIATION_REMOVED = 29
    BAD_ENCODING = 30


class FileMode(IntEnum):
    """File open modes."""
    READ = 0
    WRITE = 1
    APPEND = 2


class FileType(IntEnum):
    """File types returned by get_file_info."""
    DIRECTORY = 0
    SIMPLE = 1
    OTHER = 2


# --- Callback classes for file operations ---


class FileInfoCallback(TaskCallback):
    """Callback for get_file_info operations."""

    def __init__(self):
        super().__init__()

        @ffi.callback("void(dnp3_file_info_t, void*)")
        def _on_complete(info, ctx):
            file_name = ffi.string(info.file_name).decode() if info.file_name != ffi.NULL else ""
            self._signal_success({
                "file_name": file_name,
                "file_type": int(info.file_type),
                "size": info.size,
                "time_created": info.time_created,
                "permissions": {
                    "world": {
                        "execute": bool(info.permissions.world.execute),
                        "write": bool(info.permissions.world.write),
                        "read": bool(info.permissions.world.read),
                    },
                    "group": {
                        "execute": bool(info.permissions.group.execute),
                        "write": bool(info.permissions.group.write),
                        "read": bool(info.permissions.group.read),
                    },
                    "owner": {
                        "execute": bool(info.permissions.owner.execute),
                        "write": bool(info.permissions.owner.write),
                        "read": bool(info.permissions.owner.read),
                    },
                },
            })

        @ffi.callback("void(dnp3_file_error_t, void*)")
        def _on_failure(error, ctx):
            self._signal_failure(int(error))

        self._on_complete = _on_complete
        self._on_failure = _on_failure

    def as_ffi(self):
        return ffi.new("dnp3_file_info_callback_t*", {
            "on_complete": self._on_complete,
            "on_failure": self._on_failure,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class FileOpenCallback(TaskCallback):
    """Callback for open_file operations."""

    def __init__(self):
        super().__init__()

        @ffi.callback("void(dnp3_open_file_t, void*)")
        def _on_complete(open_file, ctx):
            self._signal_success({
                "file_handle": open_file.file_handle,
                "file_size": open_file.file_size,
                "max_block_size": open_file.max_block_size,
            })

        @ffi.callback("void(dnp3_file_error_t, void*)")
        def _on_failure(error, ctx):
            self._signal_failure(int(error))

        self._on_complete = _on_complete
        self._on_failure = _on_failure

    def as_ffi(self):
        return ffi.new("dnp3_file_open_callback_t*", {
            "on_complete": self._on_complete,
            "on_failure": self._on_failure,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class FileOperationCallback(TaskCallback):
    """Callback for close_file and write_file_block operations."""

    def __init__(self):
        super().__init__()

        @ffi.callback("void(dnp3_nothing_t, void*)")
        def _on_complete(nothing, ctx):
            self._signal_success()

        @ffi.callback("void(dnp3_file_error_t, void*)")
        def _on_failure(error, ctx):
            self._signal_failure(int(error))

        self._on_complete = _on_complete
        self._on_failure = _on_failure

    def as_ffi(self):
        return ffi.new("dnp3_file_operation_callback_t*", {
            "on_complete": self._on_complete,
            "on_failure": self._on_failure,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class FileAuthCallback(TaskCallback):
    """Callback for get_file_auth_key operations."""

    def __init__(self):
        super().__init__()

        @ffi.callback("void(uint32_t, void*)")
        def _on_complete(auth_key, ctx):
            self._signal_success(auth_key)

        @ffi.callback("void(dnp3_file_error_t, void*)")
        def _on_failure(error, ctx):
            self._signal_failure(int(error))

        self._on_complete = _on_complete
        self._on_failure = _on_failure

    def as_ffi(self):
        return ffi.new("dnp3_file_auth_callback_t*", {
            "on_complete": self._on_complete,
            "on_failure": self._on_failure,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class FileReader:
    """Callback handler for streaming file read operations.

    Override methods to process file data as it arrives::

        class MyReader(FileReader):
            def on_opened(self, file_size):
                self.data = bytearray()
                return True  # Continue reading

            def on_block_received(self, block_num, data):
                self.data.extend(data)
                return True  # Continue reading

            def on_completed(self):
                print(f"Read {len(self.data)} bytes")
    """

    def __init__(self):
        self._data = bytearray()
        self._error = None
        self._completed = False
        self._event = threading.Event()

        @ffi.callback("_Bool(uint32_t, void*)")
        def _opened(file_size, ctx):
            return self.on_opened(file_size)

        @ffi.callback("_Bool(uint32_t, dnp3_byte_iterator_t*, void*)")
        def _block_received(block_num, it, ctx):
            data = bytearray()
            while True:
                byte_ptr = lib.dnp3_byte_iterator_next(it)
                if byte_ptr == ffi.NULL:
                    break
                data.append(byte_ptr[0])
            return self.on_block_received(block_num, bytes(data))

        @ffi.callback("void(dnp3_file_error_t, void*)")
        def _aborted(error, ctx):
            self._error = int(error)
            self.on_aborted(int(error))
            self._event.set()

        @ffi.callback("void(void*)")
        def _completed(ctx):
            self._completed = True
            self.on_completed()
            self._event.set()

        self._opened_cb = _opened
        self._block_received_cb = _block_received
        self._aborted_cb = _aborted
        self._completed_cb = _completed

    def on_opened(self, file_size: int) -> bool:
        """Called when file is opened. Return True to continue reading."""
        return True

    def on_block_received(self, block_num: int, data: bytes) -> bool:
        """Called for each data block. Return True to continue reading."""
        self._data.extend(data)
        return True

    def on_aborted(self, error: int):
        """Called when the read is aborted due to error."""
        pass

    def on_completed(self):
        """Called when file read is complete."""
        pass

    def wait(self, timeout: float = 30.0) -> bool:
        """Wait for the read to complete or abort."""
        return self._event.wait(timeout)

    @property
    def data(self) -> bytes:
        """Return all collected data."""
        return bytes(self._data)

    def as_ffi(self):
        return ffi.new("dnp3_file_reader_t*", {
            "opened": self._opened_cb,
            "block_received": self._block_received_cb,
            "aborted": self._aborted_cb,
            "completed": self._completed_cb,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class ReadDirectoryCallback(TaskCallback):
    """Callback for read_directory operations."""

    def __init__(self):
        super().__init__()

        @ffi.callback("void(dnp3_file_info_iterator_t*, void*)")
        def _on_complete(it, ctx):
            entries = []
            while True:
                entry = lib.dnp3_file_info_iterator_next(it)
                if entry == ffi.NULL:
                    break
                file_name = ffi.string(entry.file_name).decode() if entry.file_name != ffi.NULL else ""
                entries.append({
                    "file_name": file_name,
                    "file_type": int(entry.file_type),
                    "size": entry.size,
                    "time_created": entry.time_created,
                    "permissions": {
                        "world": {
                            "execute": bool(entry.permissions.world.execute),
                            "write": bool(entry.permissions.world.write),
                            "read": bool(entry.permissions.world.read),
                        },
                        "group": {
                            "execute": bool(entry.permissions.group.execute),
                            "write": bool(entry.permissions.group.write),
                            "read": bool(entry.permissions.group.read),
                        },
                        "owner": {
                            "execute": bool(entry.permissions.owner.execute),
                            "write": bool(entry.permissions.owner.write),
                            "read": bool(entry.permissions.owner.read),
                        },
                    },
                })
            self._signal_success(entries)

        @ffi.callback("void(dnp3_file_error_t, void*)")
        def _on_failure(error, ctx):
            self._signal_failure(int(error))

        self._on_complete = _on_complete
        self._on_failure = _on_failure

    def as_ffi(self):
        return ffi.new("dnp3_read_directory_callback_t*", {
            "on_complete": self._on_complete,
            "on_failure": self._on_failure,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


# --- File read/dir config ---


class FileReadConfig:
    """Configuration for file read operations.

    Args:
        max_block_size: Maximum block size in bytes (default: 1024).
        max_file_size: Maximum total file size in bytes (default: 1048576 = 1MB).
    """

    def __init__(self, max_block_size: int = 1024, max_file_size: int = 1048576):
        self.max_block_size = max_block_size
        self.max_file_size = max_file_size

    def to_ffi(self):
        return ffi.new("dnp3_file_read_config_t*", {
            "max_block_size": self.max_block_size,
            "max_file_size": self.max_file_size,
        })[0]


class DirReadConfig:
    """Configuration for directory read operations.

    Args:
        max_block_size: Maximum block size in bytes (default: 1024).
        max_file_size: Maximum total directory listing size (default: 1048576).
    """

    def __init__(self, max_block_size: int = 1024, max_file_size: int = 1048576):
        self.max_block_size = max_block_size
        self.max_file_size = max_file_size

    def to_ffi(self):
        return ffi.new("dnp3_dir_read_config_t*", {
            "max_block_size": self.max_block_size,
            "max_file_size": self.max_file_size,
        })[0]


# --- Dead band request ---


class DeadBandRequest:
    """Builder for dead band write requests.

    Dead bands control the threshold before a point value change generates
    an event. Group 34 Var 1 = uint16, Var 2 = uint32, Var 3 = float.

    Example::

        req = DeadBandRequest()
        req.add_g34v1_u16(index=0, deadband=100)
        req.add_g34v3_u16(index=1, deadband=1.5)
        req.finish_header()
        channel.write_dead_bands(assoc, req)
    """

    def __init__(self):
        self._ptr = lib.dnp3_write_dead_band_request_create()

    def add_g34v1_u8(self, index: int, deadband: int):
        """Add a uint16 dead band with 8-bit index."""
        lib.dnp3_write_dead_band_request_add_g34v1_u8(self._ptr, index, deadband)

    def add_g34v1_u16(self, index: int, deadband: int):
        """Add a uint16 dead band with 16-bit index."""
        lib.dnp3_write_dead_band_request_add_g34v1_u16(self._ptr, index, deadband)

    def add_g34v2_u8(self, index: int, deadband: int):
        """Add a uint32 dead band with 8-bit index."""
        lib.dnp3_write_dead_band_request_add_g34v2_u8(self._ptr, index, deadband)

    def add_g34v2_u16(self, index: int, deadband: int):
        """Add a uint32 dead band with 16-bit index."""
        lib.dnp3_write_dead_band_request_add_g34v2_u16(self._ptr, index, deadband)

    def add_g34v3_u8(self, index: int, deadband: float):
        """Add a float dead band with 8-bit index."""
        lib.dnp3_write_dead_band_request_add_g34v3_u8(self._ptr, index, deadband)

    def add_g34v3_u16(self, index: int, deadband: float):
        """Add a float dead band with 16-bit index."""
        lib.dnp3_write_dead_band_request_add_g34v3_u16(self._ptr, index, deadband)

    def finish_header(self):
        """Finish the current header (start a new object header group)."""
        lib.dnp3_write_dead_band_request_finish_header(self._ptr)

    def destroy(self):
        """Destroy the request. Called automatically after use."""
        if self._ptr is not None:
            lib.dnp3_write_dead_band_request_destroy(self._ptr)
            self._ptr = None

    def __del__(self):
        self.destroy()


# --- Association config/id/poll ---


class AssociationConfig:
    """Configuration for a master-outstation association."""

    def __init__(
        self,
        disable_unsol_classes: tuple = (True, True, True),  # class 1,2,3
        enable_unsol_classes: tuple = (True, True, True),
        startup_integrity_classes: tuple = (True, True, True, True),  # class 0,1,2,3
        event_scan_on_events_available: tuple = (False, False, False),
        auto_time_sync: AutoTimeSync = AutoTimeSync.LAN,
        keep_alive_timeout: int = 60,  # seconds
        auto_tasks_retry_strategy_min_delay: int = 1000,  # ms
        auto_tasks_retry_strategy_max_delay: int = 30000,  # ms
        response_timeout: int = 5000,  # ms
        auto_integrity_scan_on_buffer_overflow: bool = True,
        max_queued_user_requests: int = 16,
    ):
        self.disable_unsol_classes = disable_unsol_classes
        self.enable_unsol_classes = enable_unsol_classes
        self.startup_integrity_classes = startup_integrity_classes
        self.event_scan_on_events_available = event_scan_on_events_available
        self.auto_time_sync = auto_time_sync
        self.keep_alive_timeout = keep_alive_timeout
        self.auto_tasks_retry_strategy_min_delay = auto_tasks_retry_strategy_min_delay
        self.auto_tasks_retry_strategy_max_delay = auto_tasks_retry_strategy_max_delay
        self.response_timeout = response_timeout
        self.auto_integrity_scan_on_buffer_overflow = auto_integrity_scan_on_buffer_overflow
        self.max_queued_user_requests = max_queued_user_requests

    def to_ffi(self):
        config = ffi.new("dnp3_association_config_t*")

        # Response timeout (ms)
        config.response_timeout = self.response_timeout

        # Disable unsolicited classes
        config.disable_unsol_classes.class1 = self.disable_unsol_classes[0]
        config.disable_unsol_classes.class2 = self.disable_unsol_classes[1]
        config.disable_unsol_classes.class3 = self.disable_unsol_classes[2]

        # Enable unsolicited classes
        config.enable_unsol_classes.class1 = self.enable_unsol_classes[0]
        config.enable_unsol_classes.class2 = self.enable_unsol_classes[1]
        config.enable_unsol_classes.class3 = self.enable_unsol_classes[2]

        # Startup integrity poll classes
        config.startup_integrity_classes.class0 = self.startup_integrity_classes[0]
        config.startup_integrity_classes.class1 = self.startup_integrity_classes[1]
        config.startup_integrity_classes.class2 = self.startup_integrity_classes[2]
        config.startup_integrity_classes.class3 = self.startup_integrity_classes[3]

        config.auto_time_sync = self.auto_time_sync.value
        config.auto_tasks_retry_strategy.min_delay = self.auto_tasks_retry_strategy_min_delay
        config.auto_tasks_retry_strategy.max_delay = self.auto_tasks_retry_strategy_max_delay
        config.keep_alive_timeout = self.keep_alive_timeout
        config.auto_integrity_scan_on_buffer_overflow = self.auto_integrity_scan_on_buffer_overflow

        # Event scan on events available
        config.event_scan_on_events_available.class1 = self.event_scan_on_events_available[0]
        config.event_scan_on_events_available.class2 = self.event_scan_on_events_available[1]
        config.event_scan_on_events_available.class3 = self.event_scan_on_events_available[2]

        config.max_queued_user_requests = self.max_queued_user_requests

        return config[0]


class AssociationId:
    """Wraps the C association_id struct."""

    def __init__(self, c_id):
        self._id = c_id

    @property
    def address(self):
        return self._id.address

    @property
    def raw(self):
        return self._id


class PollId:
    """Wraps the C poll_id struct."""

    def __init__(self, c_id):
        self._id = c_id

    @property
    def raw(self):
        return self._id


# --- Master channel ---


class MasterChannel:
    """
    High-level wrapper around a DNP3 master channel.

    Manages associations and provides methods for read, control,
    time sync, restart, file transfer, and dead band operations.
    """

    def __init__(self, ptr, listener=None):
        self._ptr = ptr
        self._listener = listener
        self._destroyed = False

    def destroy(self):
        """Destroy the channel and free resources."""
        if not self._destroyed and self._ptr is not None:
            lib.dnp3_master_channel_destroy(self._ptr)
            self._destroyed = True

    def __del__(self):
        self.destroy()

    def enable(self):
        """Enable communications on the channel."""
        check_error(lib.dnp3_master_channel_enable(self._ptr))

    def disable(self):
        """Disable communications on the channel."""
        check_error(lib.dnp3_master_channel_disable(self._ptr))

    def set_decode_level(self, level: DecodeLevel):
        """Set the decode/logging level."""
        c_level = ffi.new("dnp3_decode_level_t*", level.to_ffi())[0]
        check_error(lib.dnp3_master_channel_set_decode_level(self._ptr, c_level))

    def get_decode_level(self) -> DecodeLevel:
        """Get the current decode/logging level."""
        from .types import AppDecodeLevel, TransportDecodeLevel, LinkDecodeLevel, PhysDecodeLevel
        out = ffi.new("dnp3_decode_level_t*")
        check_error(lib.dnp3_master_channel_get_decode_level(self._ptr, out))
        return DecodeLevel(
            application=AppDecodeLevel(out.application),
            transport=TransportDecodeLevel(out.transport),
            link=LinkDecodeLevel(out.link),
            physical=PhysDecodeLevel(out.physical),
        )

    def get_last_iin(self, assoc_id: "AssociationId") -> Optional["IIN"]:
        """Get the last IIN received from the specified outstation.

        Args:
            assoc_id: Association to query.

        Returns:
            IIN object with decoded bit fields, or None if no response
            has been received yet.
        """
        from .types import IIN
        out = ffi.new("dnp3_raw_iin_t*")
        check_error(lib.dnp3_master_channel_get_last_iin(self._ptr, assoc_id.raw, out))
        if not out.is_valid:
            return None
        return IIN.from_raw_bytes(out.iin1, out.iin2)

    def add_association(
        self,
        address: int,
        read_handler: Optional[ReadHandler] = None,
        config: Optional[AssociationConfig] = None,
        assoc_handler: Optional[AssociationHandler] = None,
        assoc_info: Optional[AssociationInformation] = None,
    ) -> AssociationId:
        """
        Add a master-outstation association.

        Args:
            address: Outstation DNP3 address
            read_handler: Handler for received data
            config: Association configuration
            assoc_handler: Time provider
            assoc_info: Task status receiver

        Returns:
            AssociationId for use in subsequent operations
        """
        read_handler = read_handler or ReadHandler()
        config = config or AssociationConfig()
        assoc_handler = assoc_handler or AssociationHandler()
        assoc_info = assoc_info or AssociationInformation()

        # Keep references to handlers to prevent GC
        self._read_handler = read_handler
        self._assoc_handler = assoc_handler
        self._assoc_info = assoc_info

        assoc_id = ffi.new("dnp3_association_id_t*")
        err = lib.dnp3_master_channel_add_association(
            self._ptr,
            address,
            config.to_ffi(),
            read_handler.as_ffi(),
            assoc_handler.as_ffi(),
            assoc_info.as_ffi(),
            assoc_id,
        )
        check_error(err)
        return AssociationId(assoc_id[0])

    def add_udp_association(
        self,
        address: int,
        remote_endpoint: str,
        read_handler: Optional[ReadHandler] = None,
        config: Optional[AssociationConfig] = None,
        assoc_handler: Optional[AssociationHandler] = None,
        assoc_info: Optional[AssociationInformation] = None,
    ) -> AssociationId:
        """Add an association for a UDP channel with a specific remote endpoint.

        Args:
            address: Outstation DNP3 address.
            remote_endpoint: Remote "host:port" for the outstation.
            read_handler: Handler for received data.
            config: Association configuration.
            assoc_handler: Time provider.
            assoc_info: Task status receiver.

        Returns:
            AssociationId for use in subsequent operations.
        """
        read_handler = read_handler or ReadHandler()
        config = config or AssociationConfig()
        assoc_handler = assoc_handler or AssociationHandler()
        assoc_info = assoc_info or AssociationInformation()

        # Keep references
        self._read_handler = read_handler
        self._assoc_handler = assoc_handler
        self._assoc_info = assoc_info

        assoc_id = ffi.new("dnp3_association_id_t*")
        err = lib.dnp3_master_channel_add_udp_association(
            self._ptr,
            address,
            remote_endpoint.encode(),
            config.to_ffi(),
            read_handler.as_ffi(),
            assoc_handler.as_ffi(),
            assoc_info.as_ffi(),
            assoc_id,
        )
        check_error(err)
        return AssociationId(assoc_id[0])

    def remove_association(self, assoc_id: AssociationId):
        """Remove an association."""
        check_error(lib.dnp3_master_channel_remove_association(self._ptr, assoc_id.raw))

    def add_poll(
        self,
        assoc_id: AssociationId,
        class0: bool = False,
        class1: bool = True,
        class2: bool = True,
        class3: bool = True,
        period_ms: int = 5000,
    ) -> PollId:
        """
        Add a periodic poll to the association.

        Args:
            assoc_id: Association to poll on
            class0: Include Class 0 (static data)
            class1: Include Class 1 events
            class2: Include Class 2 events
            class3: Include Class 3 events
            period_ms: Poll period in milliseconds

        Returns:
            PollId for managing the poll
        """
        request = lib.dnp3_request_new_class(class0, class1, class2, class3)
        poll_id = ffi.new("dnp3_poll_id_t*")
        err = lib.dnp3_master_channel_add_poll(
            self._ptr, assoc_id.raw, request, period_ms, poll_id
        )
        lib.dnp3_request_destroy(request)
        check_error(err)
        return PollId(poll_id[0])

    def demand_poll(self, poll_id: PollId):
        """Trigger an immediate execution of a poll."""
        check_error(lib.dnp3_master_channel_demand_poll(self._ptr, poll_id.raw))

    def remove_poll(self, poll_id: PollId):
        """Remove a poll."""
        check_error(lib.dnp3_master_channel_remove_poll(self._ptr, poll_id.raw))

    def read(
        self,
        assoc_id: AssociationId,
        variation: Optional[Variation] = None,
        class0: bool = True,
        class1: bool = True,
        class2: bool = True,
        class3: bool = True,
        start: Optional[int] = None,
        stop: Optional[int] = None,
        timeout: float = 30.0,
    ) -> "ReadResult":
        """
        Perform a one-shot read operation.

        If variation is specified, reads that specific group/variation.
        Otherwise reads by class.

        Args:
            assoc_id: Association to read from
            variation: Specific variation to read (e.g., Variation.GROUP30_VAR0)
            class0-3: Classes to include when variation is None
            start: Start index for range reads
            stop: Stop index for range reads
            timeout: Timeout in seconds

        Returns:
            ReadResult that is truthy on success, with error details on failure.
            Backward compatible: ``if channel.read(assoc):`` still works.
        """
        if variation is not None:
            if start is not None and stop is not None:
                request = lib.dnp3_request_new_two_byte_range(variation.value, start, stop)
            else:
                request = lib.dnp3_request_new_all_objects(variation.value)
        else:
            request = lib.dnp3_request_new_class(class0, class1, class2, class3)

        cb = ReadTaskCallback()
        err = lib.dnp3_master_channel_read(
            self._ptr, assoc_id.raw, request, cb.as_ffi()
        )
        lib.dnp3_request_destroy(request)
        check_error(err)

        cb.wait(timeout)
        return ReadResult(success=cb.success, error_code=cb.error)

    def read_with_handler(
        self,
        assoc_id: AssociationId,
        request,
        handler: ReadHandler,
        timeout: float = 30.0,
    ) -> "ReadResult":
        """Perform a read with a specific handler (instead of the association default).

        Args:
            assoc_id: Association to read from.
            request: A raw dnp3_request_t* pointer (from request builder methods).
            handler: ReadHandler for this specific read.
            timeout: Timeout in seconds.

        Returns:
            ReadResult that is truthy on success, with error details on failure.
        """
        cb = ReadTaskCallback()
        err = lib.dnp3_master_channel_read_with_handler(
            self._ptr, assoc_id.raw, request, handler.as_ffi(), cb.as_ffi()
        )
        check_error(err)
        cb.wait(timeout)
        return ReadResult(success=cb.success, error_code=cb.error)

    def read_attributes(
        self,
        assoc_id: AssociationId,
        variation: int = 0xFE,  # ALL_ATTRIBUTES_REQUEST
        set_id: int = 0,
        timeout: float = 30.0,
    ) -> "ReadResult":
        """
        Read device attributes (Group 0).

        Args:
            assoc_id: Association
            variation: Attribute variation (0xFE = all attributes request)
            set_id: Attribute set (default 0)
            timeout: Timeout in seconds

        Returns:
            ReadResult that is truthy on success, with error details on failure.
        """
        request = lib.dnp3_request_create()
        lib.dnp3_request_add_specific_attribute(request, variation, set_id)

        cb = ReadTaskCallback()
        err = lib.dnp3_master_channel_read(
            self._ptr, assoc_id.raw, request, cb.as_ffi()
        )
        lib.dnp3_request_destroy(request)
        check_error(err)

        cb.wait(timeout)
        return ReadResult(success=cb.success, error_code=cb.error)

    def operate(
        self,
        assoc_id: AssociationId,
        mode: CommandMode = CommandMode.SELECT_BEFORE_OPERATE,
        crob_commands: Optional[List[tuple]] = None,
        analog_int32_commands: Optional[List[tuple]] = None,
        analog_int16_commands: Optional[List[tuple]] = None,
        analog_float_commands: Optional[List[tuple]] = None,
        analog_double_commands: Optional[List[tuple]] = None,
        timeout: float = 30.0,
    ) -> bool:
        """
        Perform a control operation.

        Args:
            assoc_id: Association
            mode: SELECT_BEFORE_OPERATE or DIRECT_OPERATE
            crob_commands: List of (index, Group12Var1) tuples for binary output control
            analog_int32_commands: List of (index, value) for G41V1
            analog_int16_commands: List of (index, value) for G41V2
            analog_float_commands: List of (index, value) for G41V3
            analog_double_commands: List of (index, value) for G41V4
            timeout: Timeout in seconds

        Returns:
            True if operation succeeded
        """
        commands = lib.dnp3_command_set_create()

        if crob_commands:
            for idx, g12v1 in crob_commands:
                c_g12v1 = ffi.new("dnp3_group12_var1_t*", g12v1.to_ffi())[0]
                if idx <= 0xFF:
                    lib.dnp3_command_set_add_g12_v1_u8(commands, idx, c_g12v1)
                else:
                    lib.dnp3_command_set_add_g12_v1_u16(commands, idx, c_g12v1)

        if analog_int32_commands:
            for idx, value in analog_int32_commands:
                if idx <= 0xFF:
                    lib.dnp3_command_set_add_g41_v1_u8(commands, idx, value)
                else:
                    lib.dnp3_command_set_add_g41_v1_u16(commands, idx, value)

        if analog_int16_commands:
            for idx, value in analog_int16_commands:
                if idx <= 0xFF:
                    lib.dnp3_command_set_add_g41_v2_u8(commands, idx, value)
                else:
                    lib.dnp3_command_set_add_g41_v2_u16(commands, idx, value)

        if analog_float_commands:
            for idx, value in analog_float_commands:
                if idx <= 0xFF:
                    lib.dnp3_command_set_add_g41_v3_u8(commands, idx, value)
                else:
                    lib.dnp3_command_set_add_g41_v3_u16(commands, idx, value)

        if analog_double_commands:
            for idx, value in analog_double_commands:
                if idx <= 0xFF:
                    lib.dnp3_command_set_add_g41_v4_u8(commands, idx, value)
                else:
                    lib.dnp3_command_set_add_g41_v4_u16(commands, idx, value)

        lib.dnp3_command_set_finish_header(commands)

        cb = CommandTaskCallback()
        err = lib.dnp3_master_channel_operate(
            self._ptr, assoc_id.raw, mode.value, commands, cb.as_ffi()
        )
        lib.dnp3_command_set_destroy(commands)
        check_error(err)

        cb.wait(timeout)
        return cb.success

    def select_before_operate(
        self,
        assoc_id: AssociationId,
        index: int,
        op_type: OpType = OpType.LATCH_ON,
        tcc: TripCloseCode = TripCloseCode.NUL,
        timeout: float = 30.0,
    ) -> bool:
        """
        Convenience: Perform a Select-Before-Operate binary output control.

        Args:
            assoc_id: Association
            index: Binary output index
            op_type: Operation type (LATCH_ON, LATCH_OFF, PULSE_ON, etc.)
            tcc: Trip-Close code
            timeout: Timeout

        Returns:
            True if successful
        """
        g12v1 = Group12Var1(
            code=ControlCode(tcc=tcc, op_type=op_type),
        )
        return self.operate(
            assoc_id,
            mode=CommandMode.SELECT_BEFORE_OPERATE,
            crob_commands=[(index, g12v1)],
            timeout=timeout,
        )

    def direct_operate(
        self,
        assoc_id: AssociationId,
        index: int,
        op_type: OpType = OpType.LATCH_ON,
        tcc: TripCloseCode = TripCloseCode.NUL,
        timeout: float = 30.0,
    ) -> bool:
        """Convenience: Perform a Direct Operate binary output control."""
        g12v1 = Group12Var1(
            code=ControlCode(tcc=tcc, op_type=op_type),
        )
        return self.operate(
            assoc_id,
            mode=CommandMode.DIRECT_OPERATE,
            crob_commands=[(index, g12v1)],
            timeout=timeout,
        )

    def synchronize_time(
        self,
        assoc_id: AssociationId,
        mode: TimeSyncMode = TimeSyncMode.LAN,
        timeout: float = 30.0,
    ) -> bool:
        """Synchronize time with the outstation."""
        cb = TimeSyncTaskCallback()
        err = lib.dnp3_master_channel_synchronize_time(
            self._ptr, assoc_id.raw, mode.value, cb.as_ffi()
        )
        check_error(err)
        cb.wait(timeout)
        return cb.success

    def cold_restart(
        self,
        assoc_id: AssociationId,
        timeout: float = 30.0,
    ) -> Optional[int]:
        """
        Send a cold restart command.

        Returns:
            Delay in ms before restart, or None on failure
        """
        cb = RestartTaskCallback()
        err = lib.dnp3_master_channel_cold_restart(
            self._ptr, assoc_id.raw, cb.as_ffi()
        )
        check_error(err)
        cb.wait(timeout)
        return cb.result if cb.success else None

    def warm_restart(
        self,
        assoc_id: AssociationId,
        timeout: float = 30.0,
    ) -> Optional[int]:
        """
        Send a warm restart command.

        Returns:
            Delay in ms before restart, or None on failure
        """
        cb = RestartTaskCallback()
        err = lib.dnp3_master_channel_warm_restart(
            self._ptr, assoc_id.raw, cb.as_ffi()
        )
        check_error(err)
        cb.wait(timeout)
        return cb.result if cb.success else None

    def check_link_status(
        self,
        assoc_id: AssociationId,
        timeout: float = 10.0,
    ) -> bool:
        """Check link status with the outstation."""
        cb = LinkStatusCallback()
        err = lib.dnp3_master_channel_check_link_status(
            self._ptr, assoc_id.raw, cb.as_ffi()
        )
        check_error(err)
        cb.wait(timeout)
        return cb.success

    def send_and_expect_empty_response(
        self,
        assoc_id: AssociationId,
        function_code: FunctionCode,
        variation: Optional[Variation] = None,
        timeout: float = 30.0,
    ) -> bool:
        """
        Send a request and expect an empty response (e.g., enable/disable unsolicited).

        Args:
            assoc_id: Association
            function_code: DNP3 function code
            variation: Optional variation to include in request
            timeout: Timeout

        Returns:
            True if successful
        """
        request = lib.dnp3_request_create()
        if variation is not None:
            lib.dnp3_request_add_all_objects_header(request, variation.value)

        cb = EmptyResponseCallback()
        err = lib.dnp3_master_channel_send_and_expect_empty_response(
            self._ptr, assoc_id.raw, function_code.value, request, cb.as_ffi()
        )
        lib.dnp3_request_destroy(request)
        check_error(err)

        cb.wait(timeout)
        return cb.success

    # --- File transfer operations ---

    def get_file_info(
        self,
        assoc_id: AssociationId,
        filename: str,
        timeout: float = 30.0,
    ) -> "FileResult":
        """Get information about a file on the outstation.

        Args:
            assoc_id: Association.
            filename: Path to the file on the outstation.
            timeout: Timeout in seconds.

        Returns:
            FileResult that is truthy on success (with ``result.value`` containing
            file_name, file_type, size, time_created, permissions dict);
            falsy on failure with error details.
        """
        cb = FileInfoCallback()
        err = lib.dnp3_master_channel_get_file_info(
            self._ptr, assoc_id.raw, filename.encode(), cb.as_ffi()
        )
        check_error(err)
        cb.wait(timeout)
        if cb.success:
            return FileResult(success=True, value=cb.result)
        return FileResult(success=False, error_code=cb.error)

    def open_file(
        self,
        assoc_id: AssociationId,
        filename: str,
        mode: FileMode = FileMode.READ,
        max_block_size: int = 1024,
        file_size: int = 0,
        permissions_world: int = 0,
        permissions_group: int = 0,
        permissions_owner: int = 0,
        timeout: float = 30.0,
    ) -> "FileResult":
        """Open a file on the outstation.

        Args:
            assoc_id: Association.
            filename: Path to the file.
            mode: File open mode (READ, WRITE, APPEND).
            max_block_size: Maximum block size for transfers.
            file_size: Expected file size (for write mode).
            permissions_world: World permission bits.
            permissions_group: Group permission bits.
            permissions_owner: Owner permission bits.
            timeout: Timeout in seconds.

        Returns:
            FileResult truthy on success (with file_handle, file_size,
            max_block_size in ``result.value``); falsy with error details.
        """
        perms = ffi.new("dnp3_permissions_t*")
        perms.world.read = bool(permissions_world & 4)
        perms.world.write = bool(permissions_world & 2)
        perms.world.execute = bool(permissions_world & 1)
        perms.group.read = bool(permissions_group & 4)
        perms.group.write = bool(permissions_group & 2)
        perms.group.execute = bool(permissions_group & 1)
        perms.owner.read = bool(permissions_owner & 4)
        perms.owner.write = bool(permissions_owner & 2)
        perms.owner.execute = bool(permissions_owner & 1)

        cb = FileOpenCallback()
        err = lib.dnp3_master_channel_open_file(
            self._ptr, assoc_id.raw,
            filename.encode(),
            file_size,
            perms[0],
            max_block_size,
            mode.value,
            max_block_size,
            cb.as_ffi(),
        )
        check_error(err)
        cb.wait(timeout)
        if cb.success:
            return FileResult(success=True, value=cb.result)
        return FileResult(success=False, error_code=cb.error)

    def close_file(
        self,
        assoc_id: AssociationId,
        file_handle: int,
        timeout: float = 30.0,
    ) -> bool:
        """Close an open file on the outstation.

        Args:
            assoc_id: Association.
            file_handle: Handle returned by open_file().
            timeout: Timeout in seconds.

        Returns:
            True if successful.
        """
        cb = FileOperationCallback()
        err = lib.dnp3_master_channel_close_file(
            self._ptr, assoc_id.raw, file_handle, cb.as_ffi()
        )
        check_error(err)
        cb.wait(timeout)
        return cb.success

    def read_file(
        self,
        assoc_id: AssociationId,
        filename: str,
        reader: Optional[FileReader] = None,
        config: Optional[FileReadConfig] = None,
        timeout: float = 60.0,
    ) -> "FileResult":
        """Read a file from the outstation.

        Args:
            assoc_id: Association.
            filename: Path to the file on the outstation.
            reader: Optional custom FileReader. If None, a default is created.
            config: File read configuration.
            timeout: Timeout in seconds.

        Returns:
            FileResult truthy on success (with file bytes in ``result.value``);
            falsy with error details on failure.
        """
        reader = reader or FileReader()
        config = config or FileReadConfig()

        err = lib.dnp3_master_channel_read_file(
            self._ptr, assoc_id.raw, filename.encode(),
            config.to_ffi(), reader.as_ffi(),
        )
        check_error(err)
        reader.wait(timeout)
        if reader._completed:
            return FileResult(success=True, value=reader.data)
        return FileResult(success=False, error_code=reader._error)

    def read_file_with_auth(
        self,
        assoc_id: AssociationId,
        filename: str,
        username: str,
        password: str,
        reader: Optional[FileReader] = None,
        config: Optional[FileReadConfig] = None,
        timeout: float = 60.0,
    ) -> "FileResult":
        """Read a file with authentication.

        Args:
            assoc_id: Association.
            filename: Path to the file.
            username: Authentication username.
            password: Authentication password.
            reader: Optional custom FileReader.
            config: File read configuration.
            timeout: Timeout in seconds.

        Returns:
            FileResult truthy on success (with file bytes in ``result.value``);
            falsy with error details on failure.
        """
        reader = reader or FileReader()
        config = config or FileReadConfig()

        err = lib.dnp3_master_channel_read_file_with_auth(
            self._ptr, assoc_id.raw, filename.encode(),
            config.to_ffi(), reader.as_ffi(),
            username.encode(), password.encode(),
        )
        check_error(err)
        reader.wait(timeout)
        if reader._completed:
            return FileResult(success=True, value=reader.data)
        return FileResult(success=False, error_code=reader._error)

    def read_directory(
        self,
        assoc_id: AssociationId,
        path: str,
        config: Optional[DirReadConfig] = None,
        timeout: float = 30.0,
    ) -> "FileResult":
        """Read a directory listing from the outstation.

        Args:
            assoc_id: Association.
            path: Directory path on the outstation.
            config: Directory read configuration.
            timeout: Timeout in seconds.

        Returns:
            FileResult truthy on success (with list of file info dicts in
            ``result.value``); falsy with error details on failure.
        """
        config = config or DirReadConfig()
        cb = ReadDirectoryCallback()
        err = lib.dnp3_master_channel_read_directory(
            self._ptr, assoc_id.raw, path.encode(),
            config.to_ffi(), cb.as_ffi(),
        )
        check_error(err)
        cb.wait(timeout)
        if cb.success:
            return FileResult(success=True, value=cb.result)
        return FileResult(success=False, error_code=cb.error)

    def read_directory_with_auth(
        self,
        assoc_id: AssociationId,
        path: str,
        username: str,
        password: str,
        config: Optional[DirReadConfig] = None,
        timeout: float = 30.0,
    ) -> "FileResult":
        """Read a directory listing with authentication.

        Args:
            assoc_id: Association.
            path: Directory path.
            username: Authentication username.
            password: Authentication password.
            config: Directory read configuration.
            timeout: Timeout in seconds.

        Returns:
            FileResult truthy on success (with list of file info dicts in
            ``result.value``); falsy with error details on failure.
        """
        config = config or DirReadConfig()
        cb = ReadDirectoryCallback()
        err = lib.dnp3_master_channel_read_directory_with_auth(
            self._ptr, assoc_id.raw, path.encode(),
            config.to_ffi(),
            username.encode(), password.encode(),
            cb.as_ffi(),
        )
        check_error(err)
        cb.wait(timeout)
        if cb.success:
            return FileResult(success=True, value=cb.result)
        return FileResult(success=False, error_code=cb.error)

    def write_file_block(
        self,
        assoc_id: AssociationId,
        file_handle: int,
        block_num: int,
        last: bool,
        data: bytes,
        timeout: float = 30.0,
    ) -> bool:
        """Write a data block to an open file.

        Args:
            assoc_id: Association.
            file_handle: Handle from open_file().
            block_num: Block sequence number.
            last: True if this is the last block.
            data: Data bytes to write.
            timeout: Timeout in seconds.

        Returns:
            True if successful.
        """
        from .types import ByteCollection
        bc = ByteCollection(data)

        cb = FileOperationCallback()
        err = lib.dnp3_master_channel_write_file_block(
            self._ptr, assoc_id.raw, file_handle, block_num, last,
            bc._ptr, cb.as_ffi(),
        )
        check_error(err)
        cb.wait(timeout)
        return cb.success

    def get_file_auth_key(
        self,
        assoc_id: AssociationId,
        username: str,
        password: str,
        timeout: float = 30.0,
    ) -> "FileResult":
        """Get a file authentication key.

        Args:
            assoc_id: Association.
            username: Username for authentication.
            password: Password for authentication.
            timeout: Timeout in seconds.

        Returns:
            FileResult truthy on success (with auth key int in ``result.value``);
            falsy with error details on failure.
        """
        cb = FileAuthCallback()
        err = lib.dnp3_master_channel_get_file_auth_key(
            self._ptr, assoc_id.raw,
            username.encode(), password.encode(),
            cb.as_ffi(),
        )
        check_error(err)
        cb.wait(timeout)
        if cb.success:
            return FileResult(success=True, value=cb.result)
        return FileResult(success=False, error_code=cb.error)

    # --- Dead band operations ---

    def write_dead_bands(
        self,
        assoc_id: AssociationId,
        request: DeadBandRequest,
        timeout: float = 30.0,
    ) -> bool:
        """Write dead band values to the outstation.

        Args:
            assoc_id: Association.
            request: DeadBandRequest containing the dead band values.
            timeout: Timeout in seconds.

        Returns:
            True if successful.
        """
        cb = EmptyResponseCallback()
        err = lib.dnp3_master_channel_write_dead_bands(
            self._ptr, assoc_id.raw, request._ptr, cb.as_ffi()
        )
        check_error(err)
        cb.wait(timeout)
        return cb.success


# --- Request builder helpers ---


def create_request():
    """Create an empty request for custom read operations.

    Returns:
        A raw dnp3_request_t* pointer. Must be destroyed with destroy_request().
    """
    return lib.dnp3_request_create()


def destroy_request(request):
    """Destroy a request created by create_request()."""
    lib.dnp3_request_destroy(request)


def request_add_one_byte_range_header(request, variation, start: int, stop: int):
    """Add a one-byte range header to a request."""
    lib.dnp3_request_add_one_byte_range_header(request, variation.value if hasattr(variation, 'value') else variation, start, stop)


def request_add_two_byte_range_header(request, variation, start: int, stop: int):
    """Add a two-byte range header to a request."""
    lib.dnp3_request_add_two_byte_range_header(request, variation.value if hasattr(variation, 'value') else variation, start, stop)


def request_add_one_byte_limited_count_header(request, variation, count: int):
    """Add a one-byte limited count header to a request."""
    lib.dnp3_request_add_one_byte_limited_count_header(request, variation.value if hasattr(variation, 'value') else variation, count)


def request_add_two_byte_limited_count_header(request, variation, count: int):
    """Add a two-byte limited count header to a request."""
    lib.dnp3_request_add_two_byte_limited_count_header(request, variation.value if hasattr(variation, 'value') else variation, count)


def request_add_string_attribute(request, set_id: int, variation: int, value: str):
    """Add a string attribute write to a request."""
    lib.dnp3_request_add_string_attribute(request, set_id, variation, value.encode())


def request_add_uint_attribute(request, set_id: int, variation: int, value: int):
    """Add an unsigned integer attribute write to a request."""
    lib.dnp3_request_add_uint_attribute(request, set_id, variation, value)


def request_add_time_and_interval(request, time_ms: int, interval_ms: int):
    """Add a time and interval header to a request."""
    lib.dnp3_request_add_time_and_interval(request, time_ms, interval_ms)


def request_new_one_byte_range(variation, start: int, stop: int):
    """Create a new request with a one-byte range header."""
    return lib.dnp3_request_new_one_byte_range(variation.value if hasattr(variation, 'value') else variation, start, stop)


def request_new_one_byte_limited_count(variation, count: int):
    """Create a new request with a one-byte limited count header."""
    return lib.dnp3_request_new_one_byte_limited_count(variation.value if hasattr(variation, 'value') else variation, count)


def request_new_two_byte_limited_count(variation, count: int):
    """Create a new request with a two-byte limited count header."""
    return lib.dnp3_request_new_two_byte_limited_count(variation.value if hasattr(variation, 'value') else variation, count)
