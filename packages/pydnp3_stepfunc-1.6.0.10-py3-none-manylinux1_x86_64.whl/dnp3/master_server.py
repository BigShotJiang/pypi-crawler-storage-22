"""
Master TCP server (reverse connection) for DNP3.

A master TCP server listens for incoming outstation connections
(reverse from the normal master-connects-to-outstation model).
This is useful when outstations are behind NAT or firewalls and
must initiate the TCP connection to the master.

Usage::

    from dnp3 import Runtime
    from dnp3.master_server import MasterTcpServer, ConnectionHandler

    with Runtime() as runtime:
        handler = ConnectionHandler()
        server = MasterTcpServer(
            runtime,
            address="0.0.0.0:20000",
            connection_handler=handler,
        )
        # Server is now listening; handler callbacks fire on connections.
"""

from ._ffi import ffi, lib, check_error
from .types import DecodeLevel, PhysDecodeLevel, LinkErrorMode


class ConnectionInfo:
    """Configuration for where a master TCP server should connect next.

    Used inside ConnectionHandler.on_next() to direct the server to
    connect to a specific outstation endpoint.
    """

    def __init__(self):
        self._ptr = lib.dnp3_connection_info_create()

    def set_endpoint(self, endpoint: str):
        """Set the remote endpoint to connect to.

        Args:
            endpoint: Remote "host:port" address.
        """
        check_error(lib.dnp3_connection_info_set_endpoint(self._ptr, endpoint.encode()))

    def set_local_endpoint(self, endpoint: str):
        """Set the local source endpoint.

        Args:
            endpoint: Local "host:port" address.
        """
        check_error(lib.dnp3_connection_info_set_local_endpoint(self._ptr, endpoint.encode()))

    def clear_local_endpoint(self):
        """Clear the local endpoint setting (use OS default)."""
        lib.dnp3_connection_info_clear_local_endpoint(self._ptr)

    def set_master_address(self, address: int):
        """Set the master DNP3 link address.

        Args:
            address: Master link-layer address (0-65534).
        """
        check_error(lib.dnp3_connection_info_set_master_address(self._ptr, address))

    def set_timeout(self, timeout_ms: int):
        """Set the connection timeout.

        Args:
            timeout_ms: Timeout in milliseconds.
        """
        lib.dnp3_connection_info_set_timeout(self._ptr, timeout_ms)

    def clear_timeout(self):
        """Clear the timeout (use default)."""
        lib.dnp3_connection_info_clear_timeout(self._ptr)

    def destroy(self):
        """Destroy the connection info."""
        if self._ptr is not None:
            lib.dnp3_connection_info_destroy(self._ptr)
            self._ptr = None

    def __del__(self):
        self.destroy()


class ConnectionHandler:
    """Callback handler for master TCP server connection events.

    Override the on_* methods to handle connection lifecycle events.
    The default implementations accept all connections with default settings.

    Example::

        class MyHandler(ConnectionHandler):
            def on_accept(self, endpoint, accept_handler):
                # Accept with default config
                accept_handler.accept(LinkErrorMode.CLOSE)
                return True

            def on_start(self, endpoint, channel):
                print(f"Connected to {endpoint}")
    """

    def __init__(self):
        @ffi.callback("void(char*, dnp3_accept_handler_t*, void*)")
        def _accept(endpoint, accept_handler, ctx):
            ep = ffi.string(endpoint).decode() if endpoint != ffi.NULL else ""
            self.on_accept(ep, _AcceptHandlerWrapper(accept_handler))

        @ffi.callback("void(char*, dnp3_master_channel_t*, void*)")
        def _start(endpoint, channel, ctx):
            from .master import MasterChannel
            ep = ffi.string(endpoint).decode() if endpoint != ffi.NULL else ""
            self.on_start(ep, MasterChannel(channel))

        @ffi.callback("void(char*, uint16_t, uint16_t, dnp3_identified_link_handler_t*, void*)")
        def _accept_with_link_id(endpoint, source, destination, handler, ctx):
            ep = ffi.string(endpoint).decode() if endpoint != ffi.NULL else ""
            self.on_accept_with_link_id(
                ep, source, destination, _IdentifiedLinkHandlerWrapper(handler)
            )

        @ffi.callback("void(char*, uint16_t, uint16_t, dnp3_master_channel_t*, void*)")
        def _start_with_link_id(endpoint, source, destination, channel, ctx):
            from .master import MasterChannel
            ep = ffi.string(endpoint).decode() if endpoint != ffi.NULL else ""
            self.on_start_with_link_id(ep, source, destination, MasterChannel(channel))

        self._accept = _accept
        self._start = _start
        self._accept_with_link_id = _accept_with_link_id
        self._start_with_link_id = _start_with_link_id

    def on_accept(self, endpoint: str, accept_handler):
        """Called when a new TCP connection is received.

        Override to control acceptance. The default accepts with CLOSE link error mode
        and default channel config.

        Args:
            endpoint: Remote endpoint string.
            accept_handler: Call accept_handler.accept() to accept the connection.
        """
        from .channel import MasterChannelConfig
        accept_handler.accept(LinkErrorMode.CLOSE, MasterChannelConfig())

    def on_start(self, endpoint: str, channel):
        """Called when a connection is fully established.

        Args:
            endpoint: Remote endpoint string.
            channel: MasterChannel instance for the connection.
        """
        pass

    def on_accept_with_link_id(self, endpoint: str, source: int, destination: int, handler):
        """Called when a connection with identified link addresses is received.

        Args:
            endpoint: Remote endpoint string.
            source: Source link address.
            destination: Destination link address.
            handler: IdentifiedLinkHandler to accept/reject.
        """
        from .channel import MasterChannelConfig
        handler.accept(LinkErrorMode.CLOSE, MasterChannelConfig())

    def on_start_with_link_id(self, endpoint: str, source: int, destination: int, channel):
        """Called when a link-identified connection is established.

        Args:
            endpoint: Remote endpoint string.
            source: Source link address.
            destination: Destination link address.
            channel: MasterChannel instance.
        """
        pass

    def as_ffi(self):
        return ffi.new("dnp3_connection_handler_t*", {
            "accept": self._accept,
            "start": self._start,
            "accept_with_link_id": self._accept_with_link_id,
            "start_with_link_id": self._start_with_link_id,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class _AcceptHandlerWrapper:
    """Wraps the opaque dnp3_accept_handler_t* for use in Python callbacks."""

    def __init__(self, ptr):
        self._ptr = ptr

    def accept(self, link_error_mode=LinkErrorMode.CLOSE, config=None):
        """Accept the incoming connection.

        Args:
            link_error_mode: How to handle link errors.
            config: MasterChannelConfig for the new channel.
        """
        from .channel import MasterChannelConfig
        config = config or MasterChannelConfig()
        check_error(lib.dnp3_accept_handler_accept(
            self._ptr, link_error_mode.value, config.to_ffi(),
        ))

    def get_link_identity(self):
        """Request link identity information before accepting."""
        check_error(lib.dnp3_accept_handler_get_link_identity(self._ptr))


class _IdentifiedLinkHandlerWrapper:
    """Wraps the opaque dnp3_identified_link_handler_t* for use in Python callbacks."""

    def __init__(self, ptr):
        self._ptr = ptr

    def accept(self, link_error_mode=LinkErrorMode.CLOSE, config=None):
        """Accept the identified link connection.

        Args:
            link_error_mode: How to handle link errors.
            config: MasterChannelConfig for the new channel.
        """
        from .channel import MasterChannelConfig
        config = config or MasterChannelConfig()
        check_error(lib.dnp3_identified_link_handler_accept(
            self._ptr, link_error_mode.value, config.to_ffi(),
        ))


class NextEndpointAction:
    """Wraps a dnp3_next_endpoint_action_t* for directing reconnection behavior."""

    def __init__(self, ptr):
        self._ptr = ptr

    def connect_to(self, info: ConnectionInfo):
        """Direct the client to connect to the specified endpoint.

        Args:
            info: ConnectionInfo with target endpoint details.
        """
        check_error(lib.dnp3_next_endpoint_action_connect_to(self._ptr, info._ptr))

    def sleep_for(self, duration_ms: int):
        """Pause before the next connection attempt.

        Args:
            duration_ms: Sleep duration in milliseconds.
        """
        check_error(lib.dnp3_next_endpoint_action_sleep_for(self._ptr, duration_ms))


class MasterTcpServer:
    """DNP3 master TCP server that listens for outstation connections.

    This implements the "reverse connection" model where the master listens
    and outstations connect to it, rather than the master connecting to
    outstations.

    Args:
        runtime: Runtime instance.
        address: Bind address as "host:port".
        connection_handler: Handler for connection events.
        max_tasks: Maximum concurrent identification tasks.
        timeout_ms: Identification timeout in milliseconds.
        decode_level: Physical layer decode level.
    """

    def __init__(
        self,
        runtime,
        address: str = "0.0.0.0:20000",
        connection_handler: ConnectionHandler = None,
        max_tasks: int = 16,
        timeout_ms: int = 5000,
        decode_level: PhysDecodeLevel = PhysDecodeLevel.NOTHING,
    ):
        connection_handler = connection_handler or ConnectionHandler()
        self._handler = connection_handler

        link_id_config = ffi.new("dnp3_link_id_config_t*", {
            "max_tasks": max_tasks,
            "timeout": timeout_ms,
            "decode_level": decode_level.value,
        })[0]

        server_ptr = ffi.new("dnp3_master_server_t**")
        err = lib.dnp3_create_master_tcp_server(
            runtime._ptr,
            address.encode(),
            link_id_config,
            connection_handler.as_ffi(),
            server_ptr,
        )
        check_error(err)
        self._ptr = server_ptr[0]
        self._destroyed = False

    def destroy(self):
        """Destroy the server and free resources."""
        if not self._destroyed and self._ptr is not None:
            lib.dnp3_master_server_destroy(self._ptr)
            self._destroyed = True

    def __del__(self):
        try:
            self.destroy()
        except Exception:
            pass
