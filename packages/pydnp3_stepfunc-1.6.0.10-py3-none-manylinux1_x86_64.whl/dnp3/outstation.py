"""
Outstation (server) implementation for testing purposes.

This allows creating a DNP3 outstation that can be used as a test target.
Supports both TCP and TLS transport, as well as standalone outstation modes
(TCP client, TLS client, serial, UDP).
"""

from enum import IntEnum
from typing import Optional, List, Callable

from ._ffi import ffi, lib, check_error
from .types import (
    LinkErrorMode,
    DecodeLevel,
    MinTlsVersion,
    CertificateMode,
    ConnectStrategy,
    Flags,
    Timestamp,
    TimeQuality,
)
from .handler import ConnectionStateListener, ClientStateListener, PortStateListener


# --- Enums ---


class EventClass(IntEnum):
    """Event class assignment for database points."""
    NONE = 0
    CLASS1 = 1
    CLASS2 = 2
    CLASS3 = 3


class EventMode(IntEnum):
    """Controls how point updates generate events."""
    DETECT = 0
    FORCE = 1
    SUPPRESS = 2


class UpdateFlagsType(IntEnum):
    """Point type for flag-based updates."""
    BINARY_INPUT = 0
    DOUBLE_BIT_BINARY_INPUT = 1
    BINARY_OUTPUT_STATUS = 2
    COUNTER = 3
    FROZEN_COUNTER = 4
    ANALOG_INPUT = 5
    ANALOG_OUTPUT_STATUS = 6


# --- Event buffer config ---


class EventBufferConfig:
    """Configuration for event buffer sizes."""

    def __init__(
        self,
        binary: int = 10,
        double_bit_binary: int = 10,
        binary_output_status: int = 10,
        counter: int = 5,
        frozen_counter: int = 5,
        analog: int = 5,
        analog_output_status: int = 5,
        octet_string: int = 3,
    ):
        self.binary = binary
        self.double_bit_binary = double_bit_binary
        self.binary_output_status = binary_output_status
        self.counter = counter
        self.frozen_counter = frozen_counter
        self.analog = analog
        self.analog_output_status = analog_output_status
        self.octet_string = octet_string

    def to_ffi(self):
        return ffi.new("dnp3_event_buffer_config_t*", {
            "max_binary": self.binary,
            "max_double_bit_binary": self.double_bit_binary,
            "max_binary_output_status": self.binary_output_status,
            "max_counter": self.counter,
            "max_frozen_counter": self.frozen_counter,
            "max_analog": self.analog,
            "max_analog_output_status": self.analog_output_status,
            "max_octet_string": self.octet_string,
        })[0]


# --- Outstation config ---


class OutstationConfig:
    """Configuration for an outstation."""

    def __init__(
        self,
        outstation_address: int = 1024,
        master_address: int = 1,
        event_buffer: Optional[EventBufferConfig] = None,
        decode_level: Optional[DecodeLevel] = None,
    ):
        self.outstation_address = outstation_address
        self.master_address = master_address
        self.event_buffer = event_buffer or EventBufferConfig()
        self.decode_level = decode_level or DecodeLevel()

    def to_ffi(self):
        config = ffi.new("dnp3_outstation_config_t*")
        config.outstation_address = self.outstation_address
        config.master_address = self.master_address
        config.event_buffer_config = self.event_buffer.to_ffi()
        config.solicited_buffer_size = 2048
        config.unsolicited_buffer_size = 2048
        config.rx_buffer_size = 2048
        config.decode_level = ffi.new("dnp3_decode_level_t*", self.decode_level.to_ffi())[0]
        config.confirm_timeout = 5000
        config.select_timeout = 5000
        # Features -- matches dnp3_outstation_features_init() defaults
        config.features.self_address = False
        config.features.broadcast = True
        config.features.unsolicited = True
        config.features.respond_to_any_master = False
        config.max_unsolicited_retries = 4294967295  # max uint32
        config.unsolicited_retry_delay = 5000
        config.keep_alive_timeout = 60000  # ms
        config.max_read_request_headers = 64
        config.max_controls_per_request = 65535
        # Class zero config -- matches dnp3_class_zero_config_init() defaults
        config.class_zero.binary = True
        config.class_zero.double_bit_binary = True
        config.class_zero.binary_output_status = True
        config.class_zero.counter = True
        config.class_zero.frozen_counter = True
        config.class_zero.analog = True
        config.class_zero.analog_output_status = True
        config.class_zero.octet_string = False
        return config[0]


# --- Outstation application callbacks ---


class OutstationApplication:
    """Default outstation application callbacks."""

    def __init__(self):
        @ffi.callback("uint16_t(void*)")
        def _get_processing_delay_ms(ctx):
            return 0

        @ffi.callback("dnp3_write_time_result_t(uint64_t, void*)")
        def _write_absolute_time(time, ctx):
            return lib.DNP3_WRITE_TIME_RESULT_OK

        @ffi.callback("dnp3_application_iin_t(void*)")
        def _get_application_iin(ctx):
            return ffi.new("dnp3_application_iin_t*", {
                "need_time": False,
                "local_control": False,
                "device_trouble": False,
                "config_corrupt": False,
            })[0]

        @ffi.callback("dnp3_restart_delay_t(void*)")
        def _cold_restart(ctx):
            return ffi.new("dnp3_restart_delay_t*", {
                "restart_type": lib.DNP3_RESTART_DELAY_TYPE_SECONDS,
                "value": 60,
            })[0]

        @ffi.callback("dnp3_restart_delay_t(void*)")
        def _warm_restart(ctx):
            return ffi.new("dnp3_restart_delay_t*", {
                "restart_type": lib.DNP3_RESTART_DELAY_TYPE_NOT_SUPPORTED,
                "value": 0,
            })[0]

        @ffi.callback("dnp3_freeze_result_t(dnp3_freeze_type_t, dnp3_database_handle_t*, void*)")
        def _freeze_counters_all(freeze_type, db, ctx):
            return lib.DNP3_FREEZE_RESULT_NOT_SUPPORTED

        @ffi.callback("dnp3_freeze_result_t(uint16_t, uint16_t, dnp3_freeze_type_t, dnp3_database_handle_t*, void*)")
        def _freeze_counters_range(start, stop, freeze_type, db, ctx):
            return lib.DNP3_FREEZE_RESULT_NOT_SUPPORTED

        @ffi.callback("bool(uint8_t, uint8_t, dnp3_string_attr_t, const char*, void*)")
        def _write_string_attr(set_id, var, attr, value, ctx):
            return True

        self._get_processing_delay_ms = _get_processing_delay_ms
        self._write_absolute_time = _write_absolute_time
        self._get_application_iin = _get_application_iin
        self._cold_restart = _cold_restart
        self._warm_restart = _warm_restart
        self._freeze_counters_all = _freeze_counters_all
        self._freeze_counters_range = _freeze_counters_range
        self._write_string_attr = _write_string_attr

    def as_ffi(self):
        return ffi.new("dnp3_outstation_application_t*", {
            "get_processing_delay_ms": self._get_processing_delay_ms,
            "write_absolute_time": self._write_absolute_time,
            "get_application_iin": self._get_application_iin,
            "cold_restart": self._cold_restart,
            "warm_restart": self._warm_restart,
            "freeze_counters_all": self._freeze_counters_all,
            "freeze_counters_range": self._freeze_counters_range,
            "write_string_attr": self._write_string_attr,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


# --- Outstation information callbacks ---


class OutstationInformation:
    """Default outstation information callbacks (no-op)."""

    def __init__(self):
        @ffi.callback("void(dnp3_request_header_t, void*)")
        def _noop_header(h, ctx):
            pass

        @ffi.callback("void(dnp3_function_code_t, dnp3_broadcast_action_t, void*)")
        def _broadcast_received(fc, action, ctx):
            pass

        @ffi.callback("void(uint8_t, void*)")
        def _noop_u8(v, ctx):
            pass

        @ffi.callback("void(uint8_t, uint8_t, void*)")
        def _noop_u8_u8(a, b, ctx):
            pass

        @ffi.callback("void(bool, uint8_t, void*)")
        def _noop_bool_u8(a, b, ctx):
            pass

        @ffi.callback("void(uint8_t, bool, void*)")
        def _noop_u8_bool(a, b, ctx):
            pass

        @ffi.callback("void(void*)")
        def _noop(ctx):
            pass

        self._noop_header = _noop_header
        self._broadcast_received = _broadcast_received
        self._noop_u8 = _noop_u8
        self._noop_u8_u8 = _noop_u8_u8
        self._noop_bool_u8 = _noop_bool_u8
        self._noop_u8_bool = _noop_u8_bool
        self._noop = _noop

    def as_ffi(self):
        return ffi.new("dnp3_outstation_information_t*", {
            "process_request_from_idle": self._noop_header,
            "broadcast_received": self._broadcast_received,
            "enter_solicited_confirm_wait": self._noop_u8,
            "solicited_confirm_timeout": self._noop_u8,
            "solicited_confirm_received": self._noop_u8,
            "solicited_confirm_wait_new_request": self._noop,
            "wrong_solicited_confirm_seq": self._noop_u8_u8,
            "unexpected_confirm": self._noop_bool_u8,
            "enter_unsolicited_confirm_wait": self._noop_u8,
            "unsolicited_confirm_timeout": self._noop_u8_bool,
            "unsolicited_confirmed": self._noop_u8,
            "clear_restart_iin": self._noop,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


# --- Control handler ---


class ControlHandler:
    """Default control handler (accepts all controls)."""

    def __init__(self):
        @ffi.callback("void(void*)")
        def _begin_fragment(ctx):
            pass

        @ffi.callback("void(dnp3_database_handle_t*, void*)")
        def _end_fragment(db, ctx):
            pass

        @ffi.callback("dnp3_command_status_t(dnp3_group12_var1_t, uint16_t, dnp3_database_handle_t*, void*)")
        def _select_g12v1(control, index, db, ctx):
            return lib.DNP3_COMMAND_STATUS_SUCCESS

        @ffi.callback("dnp3_command_status_t(dnp3_group12_var1_t, uint16_t, dnp3_operate_type_t, dnp3_database_handle_t*, void*)")
        def _operate_g12v1(control, index, op_type, db, ctx):
            return lib.DNP3_COMMAND_STATUS_SUCCESS

        @ffi.callback("dnp3_command_status_t(int32_t, uint16_t, dnp3_database_handle_t*, void*)")
        def _select_g41v1(value, index, db, ctx):
            return lib.DNP3_COMMAND_STATUS_SUCCESS

        @ffi.callback("dnp3_command_status_t(int32_t, uint16_t, dnp3_operate_type_t, dnp3_database_handle_t*, void*)")
        def _operate_g41v1(value, index, op_type, db, ctx):
            return lib.DNP3_COMMAND_STATUS_SUCCESS

        @ffi.callback("dnp3_command_status_t(int16_t, uint16_t, dnp3_database_handle_t*, void*)")
        def _select_g41v2(value, index, db, ctx):
            return lib.DNP3_COMMAND_STATUS_SUCCESS

        @ffi.callback("dnp3_command_status_t(int16_t, uint16_t, dnp3_operate_type_t, dnp3_database_handle_t*, void*)")
        def _operate_g41v2(value, index, op_type, db, ctx):
            return lib.DNP3_COMMAND_STATUS_SUCCESS

        @ffi.callback("dnp3_command_status_t(float, uint16_t, dnp3_database_handle_t*, void*)")
        def _select_g41v3(value, index, db, ctx):
            return lib.DNP3_COMMAND_STATUS_SUCCESS

        @ffi.callback("dnp3_command_status_t(float, uint16_t, dnp3_operate_type_t, dnp3_database_handle_t*, void*)")
        def _operate_g41v3(value, index, op_type, db, ctx):
            return lib.DNP3_COMMAND_STATUS_SUCCESS

        @ffi.callback("dnp3_command_status_t(double, uint16_t, dnp3_database_handle_t*, void*)")
        def _select_g41v4(value, index, db, ctx):
            return lib.DNP3_COMMAND_STATUS_SUCCESS

        @ffi.callback("dnp3_command_status_t(double, uint16_t, dnp3_operate_type_t, dnp3_database_handle_t*, void*)")
        def _operate_g41v4(value, index, op_type, db, ctx):
            return lib.DNP3_COMMAND_STATUS_SUCCESS

        self._begin_fragment = _begin_fragment
        self._end_fragment = _end_fragment
        self._select_g12v1 = _select_g12v1
        self._operate_g12v1 = _operate_g12v1
        self._select_g41v1 = _select_g41v1
        self._operate_g41v1 = _operate_g41v1
        self._select_g41v2 = _select_g41v2
        self._operate_g41v2 = _operate_g41v2
        self._select_g41v3 = _select_g41v3
        self._operate_g41v3 = _operate_g41v3
        self._select_g41v4 = _select_g41v4
        self._operate_g41v4 = _operate_g41v4

    def as_ffi(self):
        return ffi.new("dnp3_control_handler_t*", {
            "begin_fragment": self._begin_fragment,
            "end_fragment": self._end_fragment,
            "select_g12v1": self._select_g12v1,
            "operate_g12v1": self._operate_g12v1,
            "select_g41v1": self._select_g41v1,
            "operate_g41v1": self._operate_g41v1,
            "select_g41v2": self._select_g41v2,
            "operate_g41v2": self._operate_g41v2,
            "select_g41v3": self._select_g41v3,
            "operate_g41v3": self._operate_g41v3,
            "select_g41v4": self._select_g41v4,
            "operate_g41v4": self._operate_g41v4,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


# --- TLS server config ---


class TlsServerConfig:
    """TLS configuration for an outstation server.

    Args:
        dns_name: Expected DNS name for the server certificate.
        peer_cert_path: Path to CA certificate used to verify client certificates.
        local_cert_path: Path to the server's own certificate (PEM).
        private_key_path: Path to the server's private key (PEM).
        password: Password for the private key (default: empty).
        min_tls_version: Minimum TLS version to accept (default: V12).
        certificate_mode: Certificate verification mode (default: SELF_SIGNED).
        allow_client_name_wildcard: Allow wildcard matching on client cert names (default: True).
    """

    def __init__(
        self,
        dns_name: str = "localhost",
        peer_cert_path: str = "",
        local_cert_path: str = "",
        private_key_path: str = "",
        password: str = "",
        min_tls_version: MinTlsVersion = MinTlsVersion.V12,
        certificate_mode: CertificateMode = CertificateMode.SELF_SIGNED,
        allow_client_name_wildcard: bool = True,
    ):
        self.dns_name = dns_name
        self.peer_cert_path = peer_cert_path
        self.local_cert_path = local_cert_path
        self.private_key_path = private_key_path
        self.password = password
        self.min_tls_version = min_tls_version
        self.certificate_mode = certificate_mode
        self.allow_client_name_wildcard = allow_client_name_wildcard

    @classmethod
    def from_dict(cls, d: dict) -> "TlsServerConfig":
        """Create a TlsServerConfig from a dict.

        Accepted keys: dns_name, peer_cert_path, local_cert_path,
        private_key_path, password, min_tls_version, certificate_mode,
        allow_client_name_wildcard.
        """
        return cls(
            dns_name=d.get("dns_name", "localhost"),
            peer_cert_path=d.get("peer_cert_path", ""),
            local_cert_path=d.get("local_cert_path", ""),
            private_key_path=d.get("private_key_path", ""),
            password=d.get("password", ""),
            min_tls_version=MinTlsVersion(d.get("min_tls_version", MinTlsVersion.V12)),
            certificate_mode=CertificateMode(d.get("certificate_mode", CertificateMode.SELF_SIGNED)),
            allow_client_name_wildcard=d.get("allow_client_name_wildcard", True),
        )

    def to_ffi(self):
        """Build the C struct for dnp3_tls_server_config_t."""
        # Keep references to char[] buffers so they are not garbage-collected
        # before the C library copies them.
        self._dns_name_buf = ffi.new("char[]", self.dns_name.encode())
        self._peer_cert_buf = ffi.new("char[]", self.peer_cert_path.encode())
        self._local_cert_buf = ffi.new("char[]", self.local_cert_path.encode())
        self._key_buf = ffi.new("char[]", self.private_key_path.encode())
        self._password_buf = ffi.new("char[]", self.password.encode())

        tls_c = ffi.new("dnp3_tls_server_config_t*")
        tls_c.dns_name = self._dns_name_buf
        tls_c.peer_cert_path = self._peer_cert_buf
        tls_c.local_cert_path = self._local_cert_buf
        tls_c.private_key_path = self._key_buf
        tls_c.password = self._password_buf
        tls_c.min_tls_version = self.min_tls_version.value
        tls_c.certificate_mode = self.certificate_mode.value
        tls_c.allow_client_name_wildcard = self.allow_client_name_wildcard
        return tls_c[0]


# --- Update options ---


class UpdateOptions:
    """Options for updating database points.

    Args:
        update_static: Whether to update the static value.
        event_mode: Controls event generation (DETECT, FORCE, SUPPRESS).
    """

    def __init__(self, update_static: bool = True, event_mode: EventMode = EventMode.DETECT):
        self.update_static = update_static
        self.event_mode = event_mode

    def to_ffi(self):
        """Build the C struct."""
        return ffi.new("dnp3_update_options_t*", {
            "update_static": self.update_static,
            "event_mode": self.event_mode.value,
        })[0]


# --- Database wrapper ---


class Database:
    """Pythonic wrapper around the outstation database C API.

    This class wraps both ``dnp3_database_t*`` (initial setup via transaction)
    and ``dnp3_database_handle_t*`` (runtime transactions) -- the underlying
    add/get/remove/update functions accept the same pointer type in the C FFI.

    Typically used inside a transaction callback::

        def setup(db: Database):
            db.add_binary_input(0, EventClass.CLASS1)
            db.add_analog_input(0, EventClass.CLASS1, deadband=1.0)
            db.update_binary_input(0, True, online=True)

        outstation.transaction(setup)
    """

    def __init__(self, db_ptr):
        """Wrap a raw database pointer (dnp3_database_t* or dnp3_database_handle_t*)."""
        self._ptr = db_ptr

    # --- Add points ---

    def add_binary_input(
        self,
        index: int,
        event_class: EventClass = EventClass.CLASS1,
        static_variation: Optional[int] = None,
        event_variation: Optional[int] = None,
    ) -> bool:
        """Add a binary input point to the database."""
        config = ffi.new("dnp3_binary_input_config_t*")
        config.static_variation = (
            static_variation if static_variation is not None
            else lib.DNP3_STATIC_BINARY_INPUT_VARIATION_GROUP1_VAR1
        )
        config.event_variation = (
            event_variation if event_variation is not None
            else lib.DNP3_EVENT_BINARY_INPUT_VARIATION_GROUP2_VAR2
        )
        return bool(lib.dnp3_database_add_binary_input(self._ptr, index, event_class.value, config[0]))

    def add_double_bit_binary_input(
        self,
        index: int,
        event_class: EventClass = EventClass.CLASS1,
        static_variation: Optional[int] = None,
        event_variation: Optional[int] = None,
    ) -> bool:
        """Add a double-bit binary input point."""
        config = ffi.new("dnp3_double_bit_binary_input_config_t*")
        config.static_variation = (
            static_variation if static_variation is not None
            else lib.DNP3_STATIC_DOUBLE_BIT_BINARY_INPUT_VARIATION_GROUP3_VAR1
        )
        config.event_variation = (
            event_variation if event_variation is not None
            else lib.DNP3_EVENT_DOUBLE_BIT_BINARY_INPUT_VARIATION_GROUP4_VAR1
        )
        return bool(lib.dnp3_database_add_double_bit_binary_input(self._ptr, index, event_class.value, config[0]))

    def add_binary_output_status(
        self,
        index: int,
        event_class: EventClass = EventClass.CLASS1,
        static_variation: Optional[int] = None,
        event_variation: Optional[int] = None,
    ) -> bool:
        """Add a binary output status point."""
        config = ffi.new("dnp3_binary_output_status_config_t*")
        config.static_variation = (
            static_variation if static_variation is not None
            else lib.DNP3_STATIC_BINARY_OUTPUT_STATUS_VARIATION_GROUP10_VAR2
        )
        config.event_variation = (
            event_variation if event_variation is not None
            else lib.DNP3_EVENT_BINARY_OUTPUT_STATUS_VARIATION_GROUP11_VAR2
        )
        return bool(lib.dnp3_database_add_binary_output_status(self._ptr, index, event_class.value, config[0]))

    def add_counter(
        self,
        index: int,
        event_class: EventClass = EventClass.CLASS1,
        static_variation: Optional[int] = None,
        event_variation: Optional[int] = None,
        deadband: int = 0,
    ) -> bool:
        """Add a counter point."""
        config = ffi.new("dnp3_counter_config_t*")
        config.static_variation = (
            static_variation if static_variation is not None
            else lib.DNP3_STATIC_COUNTER_VARIATION_GROUP20_VAR1
        )
        config.event_variation = (
            event_variation if event_variation is not None
            else lib.DNP3_EVENT_COUNTER_VARIATION_GROUP22_VAR1
        )
        config.deadband = deadband
        return bool(lib.dnp3_database_add_counter(self._ptr, index, event_class.value, config[0]))

    def add_frozen_counter(
        self,
        index: int,
        event_class: EventClass = EventClass.CLASS1,
        static_variation: Optional[int] = None,
        event_variation: Optional[int] = None,
        deadband: int = 0,
    ) -> bool:
        """Add a frozen counter point."""
        config = ffi.new("dnp3_frozen_counter_config_t*")
        config.static_variation = (
            static_variation if static_variation is not None
            else lib.DNP3_STATIC_FROZEN_COUNTER_VARIATION_GROUP21_VAR1
        )
        config.event_variation = (
            event_variation if event_variation is not None
            else lib.DNP3_EVENT_FROZEN_COUNTER_VARIATION_GROUP23_VAR1
        )
        config.deadband = deadband
        return bool(lib.dnp3_database_add_frozen_counter(self._ptr, index, event_class.value, config[0]))

    def add_analog_input(
        self,
        index: int,
        event_class: EventClass = EventClass.CLASS1,
        static_variation: Optional[int] = None,
        event_variation: Optional[int] = None,
        deadband: float = 0.0,
    ) -> bool:
        """Add an analog input point."""
        config = ffi.new("dnp3_analog_input_config_t*")
        config.static_variation = (
            static_variation if static_variation is not None
            else lib.DNP3_STATIC_ANALOG_INPUT_VARIATION_GROUP30_VAR1
        )
        config.event_variation = (
            event_variation if event_variation is not None
            else lib.DNP3_EVENT_ANALOG_INPUT_VARIATION_GROUP32_VAR1
        )
        config.deadband = deadband
        return bool(lib.dnp3_database_add_analog_input(self._ptr, index, event_class.value, config[0]))

    def add_analog_output_status(
        self,
        index: int,
        event_class: EventClass = EventClass.CLASS1,
        static_variation: Optional[int] = None,
        event_variation: Optional[int] = None,
        deadband: float = 0.0,
    ) -> bool:
        """Add an analog output status point."""
        config = ffi.new("dnp3_analog_output_status_config_t*")
        config.static_variation = (
            static_variation if static_variation is not None
            else lib.DNP3_STATIC_ANALOG_OUTPUT_STATUS_VARIATION_GROUP40_VAR1
        )
        config.event_variation = (
            event_variation if event_variation is not None
            else lib.DNP3_EVENT_ANALOG_OUTPUT_STATUS_VARIATION_GROUP42_VAR1
        )
        config.deadband = deadband
        return bool(lib.dnp3_database_add_analog_output_status(self._ptr, index, event_class.value, config[0]))

    def add_octet_string(self, index: int, event_class: EventClass = EventClass.CLASS1) -> bool:
        """Add an octet string point."""
        return bool(lib.dnp3_database_add_octet_string(self._ptr, index, event_class.value))

    # --- Remove points ---

    def remove_binary_input(self, index: int) -> bool:
        """Remove a binary input point."""
        return bool(lib.dnp3_database_remove_binary_input(self._ptr, index))

    def remove_double_bit_binary_input(self, index: int) -> bool:
        """Remove a double-bit binary input point."""
        return bool(lib.dnp3_database_remove_double_bit_binary_input(self._ptr, index))

    def remove_binary_output_status(self, index: int) -> bool:
        """Remove a binary output status point."""
        return bool(lib.dnp3_database_remove_binary_output_status(self._ptr, index))

    def remove_counter(self, index: int) -> bool:
        """Remove a counter point."""
        return bool(lib.dnp3_database_remove_counter(self._ptr, index))

    def remove_frozen_counter(self, index: int) -> bool:
        """Remove a frozen counter point."""
        return bool(lib.dnp3_database_remove_frozen_counter(self._ptr, index))

    def remove_analog_input(self, index: int) -> bool:
        """Remove an analog input point."""
        return bool(lib.dnp3_database_remove_analog_input(self._ptr, index))

    def remove_analog_output_status(self, index: int) -> bool:
        """Remove an analog output status point."""
        return bool(lib.dnp3_database_remove_analog_output_status(self._ptr, index))

    def remove_octet_string(self, index: int) -> bool:
        """Remove an octet string point."""
        return bool(lib.dnp3_database_remove_octet_string(self._ptr, index))

    # --- Get points ---

    def get_binary_input(self, index: int):
        """Get a binary input value. Returns (value, flags) or raises DNP3Error."""
        out = ffi.new("dnp3_binary_input_t*")
        check_error(lib.dnp3_database_get_binary_input(self._ptr, index, out))
        return {"index": out.index, "value": bool(out.value), "flags": out.flags.value}

    def get_double_bit_binary_input(self, index: int):
        """Get a double-bit binary input value."""
        out = ffi.new("dnp3_double_bit_binary_input_t*")
        check_error(lib.dnp3_database_get_double_bit_binary_input(self._ptr, index, out))
        return {"index": out.index, "value": int(out.value), "flags": out.flags.value}

    def get_binary_output_status(self, index: int):
        """Get a binary output status value."""
        out = ffi.new("dnp3_binary_output_status_t*")
        check_error(lib.dnp3_database_get_binary_output_status(self._ptr, index, out))
        return {"index": out.index, "value": bool(out.value), "flags": out.flags.value}

    def get_counter(self, index: int):
        """Get a counter value."""
        out = ffi.new("dnp3_counter_t*")
        check_error(lib.dnp3_database_get_counter(self._ptr, index, out))
        return {"index": out.index, "value": out.value, "flags": out.flags.value}

    def get_frozen_counter(self, index: int):
        """Get a frozen counter value."""
        out = ffi.new("dnp3_frozen_counter_t*")
        check_error(lib.dnp3_database_get_frozen_counter(self._ptr, index, out))
        return {"index": out.index, "value": out.value, "flags": out.flags.value}

    def get_analog_input(self, index: int):
        """Get an analog input value."""
        out = ffi.new("dnp3_analog_input_t*")
        check_error(lib.dnp3_database_get_analog_input(self._ptr, index, out))
        return {"index": out.index, "value": out.value, "flags": out.flags.value}

    def get_analog_output_status(self, index: int):
        """Get an analog output status value."""
        out = ffi.new("dnp3_analog_output_status_t*")
        check_error(lib.dnp3_database_get_analog_output_status(self._ptr, index, out))
        return {"index": out.index, "value": out.value, "flags": out.flags.value}

    # --- Update points ---

    def update_binary_input(
        self,
        index: int,
        value: bool,
        online: bool = True,
        timestamp: Optional[Timestamp] = None,
        options: Optional[UpdateOptions] = None,
    ) -> bool:
        """Update a binary input point value."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        point = ffi.new("dnp3_binary_input_t*", {
            "index": index,
            "value": value,
            "flags": ffi.new("dnp3_flags_t*", {"value": 0x01 if online else 0x00})[0],
            "time": ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
        })[0]
        return bool(lib.dnp3_database_update_binary_input(self._ptr, point, opts.to_ffi()))

    def update_double_bit_binary_input(
        self,
        index: int,
        value: int,
        online: bool = True,
        timestamp: Optional[Timestamp] = None,
        options: Optional[UpdateOptions] = None,
    ) -> bool:
        """Update a double-bit binary input point value."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        point = ffi.new("dnp3_double_bit_binary_input_t*", {
            "index": index,
            "value": value,
            "flags": ffi.new("dnp3_flags_t*", {"value": 0x01 if online else 0x00})[0],
            "time": ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
        })[0]
        return bool(lib.dnp3_database_update_double_bit_binary_input(self._ptr, point, opts.to_ffi()))

    def update_binary_output_status(
        self,
        index: int,
        value: bool,
        online: bool = True,
        timestamp: Optional[Timestamp] = None,
        options: Optional[UpdateOptions] = None,
    ) -> bool:
        """Update a binary output status point value."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        point = ffi.new("dnp3_binary_output_status_t*", {
            "index": index,
            "value": value,
            "flags": ffi.new("dnp3_flags_t*", {"value": 0x01 if online else 0x00})[0],
            "time": ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
        })[0]
        return bool(lib.dnp3_database_update_binary_output_status(self._ptr, point, opts.to_ffi()))

    def update_counter(
        self,
        index: int,
        value: int,
        online: bool = True,
        timestamp: Optional[Timestamp] = None,
        options: Optional[UpdateOptions] = None,
    ) -> bool:
        """Update a counter point value."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        point = ffi.new("dnp3_counter_t*", {
            "index": index,
            "value": value,
            "flags": ffi.new("dnp3_flags_t*", {"value": 0x01 if online else 0x00})[0],
            "time": ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
        })[0]
        return bool(lib.dnp3_database_update_counter(self._ptr, point, opts.to_ffi()))

    def update_frozen_counter(
        self,
        index: int,
        value: int,
        online: bool = True,
        timestamp: Optional[Timestamp] = None,
        options: Optional[UpdateOptions] = None,
    ) -> bool:
        """Update a frozen counter point value."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        point = ffi.new("dnp3_frozen_counter_t*", {
            "index": index,
            "value": value,
            "flags": ffi.new("dnp3_flags_t*", {"value": 0x01 if online else 0x00})[0],
            "time": ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
        })[0]
        return bool(lib.dnp3_database_update_frozen_counter(self._ptr, point, opts.to_ffi()))

    def update_analog_input(
        self,
        index: int,
        value: float,
        online: bool = True,
        timestamp: Optional[Timestamp] = None,
        options: Optional[UpdateOptions] = None,
    ) -> bool:
        """Update an analog input point value."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        point = ffi.new("dnp3_analog_input_t*", {
            "index": index,
            "value": value,
            "flags": ffi.new("dnp3_flags_t*", {"value": 0x01 if online else 0x00})[0],
            "time": ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
        })[0]
        return bool(lib.dnp3_database_update_analog_input(self._ptr, point, opts.to_ffi()))

    def update_analog_output_status(
        self,
        index: int,
        value: float,
        online: bool = True,
        timestamp: Optional[Timestamp] = None,
        options: Optional[UpdateOptions] = None,
    ) -> bool:
        """Update an analog output status point value."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        point = ffi.new("dnp3_analog_output_status_t*", {
            "index": index,
            "value": value,
            "flags": ffi.new("dnp3_flags_t*", {"value": 0x01 if online else 0x00})[0],
            "time": ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
        })[0]
        return bool(lib.dnp3_database_update_analog_output_status(self._ptr, point, opts.to_ffi()))

    def update_octet_string(
        self,
        index: int,
        data: bytes,
        options: Optional[UpdateOptions] = None,
    ) -> bool:
        """Update an octet string point value."""
        from .types import OctetStringValue
        opts = options or UpdateOptions()
        osv = OctetStringValue(data)
        result = bool(lib.dnp3_database_update_octet_string(self._ptr, index, osv._ptr, opts.to_ffi()))
        return result

    # --- Update points (_2 variants returning UpdateInfo) ---

    def update_binary_input_2(self, index, value, online=True, timestamp=None, options=None):
        """Update a binary input and return detailed update info."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        point = ffi.new("dnp3_binary_input_t*", {
            "index": index, "value": value,
            "flags": ffi.new("dnp3_flags_t*", {"value": 0x01 if online else 0x00})[0],
            "time": ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
        })[0]
        info = lib.dnp3_database_update_binary_input_2(self._ptr, point, opts.to_ffi())
        return {"result": int(info.result), "created": info.created, "discarded": info.discarded}

    def update_double_bit_binary_input_2(self, index, value, online=True, timestamp=None, options=None):
        """Update a double-bit binary input and return detailed update info."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        point = ffi.new("dnp3_double_bit_binary_input_t*", {
            "index": index, "value": value,
            "flags": ffi.new("dnp3_flags_t*", {"value": 0x01 if online else 0x00})[0],
            "time": ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
        })[0]
        info = lib.dnp3_database_update_double_bit_binary_input_2(self._ptr, point, opts.to_ffi())
        return {"result": int(info.result), "created": info.created, "discarded": info.discarded}

    def update_binary_output_status_2(self, index, value, online=True, timestamp=None, options=None):
        """Update a binary output status and return detailed update info."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        point = ffi.new("dnp3_binary_output_status_t*", {
            "index": index, "value": value,
            "flags": ffi.new("dnp3_flags_t*", {"value": 0x01 if online else 0x00})[0],
            "time": ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
        })[0]
        info = lib.dnp3_database_update_binary_output_status_2(self._ptr, point, opts.to_ffi())
        return {"result": int(info.result), "created": info.created, "discarded": info.discarded}

    def update_counter_2(self, index, value, online=True, timestamp=None, options=None):
        """Update a counter and return detailed update info."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        point = ffi.new("dnp3_counter_t*", {
            "index": index, "value": value,
            "flags": ffi.new("dnp3_flags_t*", {"value": 0x01 if online else 0x00})[0],
            "time": ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
        })[0]
        info = lib.dnp3_database_update_counter_2(self._ptr, point, opts.to_ffi())
        return {"result": int(info.result), "created": info.created, "discarded": info.discarded}

    def update_frozen_counter_2(self, index, value, online=True, timestamp=None, options=None):
        """Update a frozen counter and return detailed update info."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        point = ffi.new("dnp3_frozen_counter_t*", {
            "index": index, "value": value,
            "flags": ffi.new("dnp3_flags_t*", {"value": 0x01 if online else 0x00})[0],
            "time": ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
        })[0]
        info = lib.dnp3_database_update_frozen_counter_2(self._ptr, point, opts.to_ffi())
        return {"result": int(info.result), "created": info.created, "discarded": info.discarded}

    def update_analog_input_2(self, index, value, online=True, timestamp=None, options=None):
        """Update an analog input and return detailed update info."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        point = ffi.new("dnp3_analog_input_t*", {
            "index": index, "value": float(value),
            "flags": ffi.new("dnp3_flags_t*", {"value": 0x01 if online else 0x00})[0],
            "time": ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
        })[0]
        info = lib.dnp3_database_update_analog_input_2(self._ptr, point, opts.to_ffi())
        return {"result": int(info.result), "created": info.created, "discarded": info.discarded}

    def update_analog_output_status_2(self, index, value, online=True, timestamp=None, options=None):
        """Update an analog output status and return detailed update info."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        point = ffi.new("dnp3_analog_output_status_t*", {
            "index": index, "value": float(value),
            "flags": ffi.new("dnp3_flags_t*", {"value": 0x01 if online else 0x00})[0],
            "time": ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
        })[0]
        info = lib.dnp3_database_update_analog_output_status_2(self._ptr, point, opts.to_ffi())
        return {"result": int(info.result), "created": info.created, "discarded": info.discarded}

    def update_octet_string_2(self, index, data, options=None):
        """Update an octet string and return detailed update info."""
        from .types import OctetStringValue
        opts = options or UpdateOptions()
        osv = OctetStringValue(data)
        info = lib.dnp3_database_update_octet_string_2(self._ptr, index, osv._ptr, opts.to_ffi())
        return {"result": int(info.result), "created": info.created, "discarded": info.discarded}

    @staticmethod
    def handle_transaction(db_handle_ptr, func):
        """Execute a transaction on a database handle (dnp3_database_handle_t*).

        This wraps dnp3_database_handle_transaction for use inside control
        handler callbacks where you receive a database handle pointer.

        Args:
            db_handle_ptr: Raw dnp3_database_handle_t* pointer.
            func: Callable receiving a Database instance.
        """
        @ffi.callback("void(dnp3_database_t*, void*)")
        def _execute(db_ptr, ctx):
            db = Database(db_ptr)
            func(db)

        # Must keep callback alive
        Database._last_handle_transaction_cb = _execute

        transaction_s = ffi.new("dnp3_database_transaction_t*", {
            "execute": _execute,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]
        lib.dnp3_database_handle_transaction(db_handle_ptr, transaction_s)

    def update_flags(
        self,
        index: int,
        flags_type: UpdateFlagsType,
        flags: Flags,
        timestamp: Optional[Timestamp] = None,
        options: Optional[UpdateOptions] = None,
    ):
        """Update flags for any point type. Returns an UpdateInfo dict."""
        ts = timestamp or Timestamp.now()
        opts = options or UpdateOptions()
        info = lib.dnp3_database_update_flags(
            self._ptr,
            index,
            flags_type.value,
            ffi.new("dnp3_flags_t*", flags.to_ffi())[0],
            ffi.new("dnp3_timestamp_t*", ts.to_ffi())[0],
            opts.to_ffi(),
        )
        return {"result": int(info.result), "created": info.created, "discarded": info.discarded}

    # --- Define device attributes ---

    def define_string_attr(self, set_id: int, writable: bool, variation: int, value: str):
        """Define a string device attribute."""
        return int(lib.dnp3_database_define_string_attr(
            self._ptr, set_id, writable, variation, value.encode(),
        ))

    def define_int_attr(self, set_id: int, writable: bool, variation: int, value: int):
        """Define an integer device attribute."""
        return int(lib.dnp3_database_define_int_attr(
            self._ptr, set_id, writable, variation, value,
        ))

    def define_uint_attr(self, set_id: int, writable: bool, variation: int, value: int):
        """Define an unsigned integer device attribute."""
        return int(lib.dnp3_database_define_uint_attr(
            self._ptr, set_id, writable, variation, value,
        ))

    def define_float_attr(self, set_id: int, writable: bool, variation: int, value: float):
        """Define a float device attribute."""
        return int(lib.dnp3_database_define_float_attr(
            self._ptr, set_id, writable, variation, value,
        ))

    def define_double_attr(self, set_id: int, writable: bool, variation: int, value: float):
        """Define a double-precision device attribute."""
        return int(lib.dnp3_database_define_double_attr(
            self._ptr, set_id, writable, variation, value,
        ))

    def define_bool_attr(self, set_id: int, writable: bool, variation: int, value: bool):
        """Define a boolean device attribute."""
        return int(lib.dnp3_database_define_bool_attr(
            self._ptr, set_id, writable, variation, value,
        ))

    def define_time_attr(self, set_id: int, writable: bool, variation: int, value: int):
        """Define a time device attribute (value in ms since epoch)."""
        return int(lib.dnp3_database_define_time_attr(
            self._ptr, set_id, writable, variation, value,
        ))


# --- Address filter ---


class AddressFilter:
    """Wraps a dnp3_address_filter_t for controlling which master addresses can connect.

    Use ``AddressFilter.any()`` to accept connections from any address, or
    ``AddressFilter("192.168.1.0/24")`` for a specific subnet.
    """

    def __init__(self, address: Optional[str] = None):
        """Create an address filter.

        Args:
            address: An address or wildcard string (e.g. "192.168.1.0/24").
                     If None, accepts any address.
        """
        if address is None:
            self._ptr = lib.dnp3_address_filter_any()
        else:
            filter_ptr = ffi.new("dnp3_address_filter_t**")
            check_error(lib.dnp3_address_filter_create(address.encode(), filter_ptr))
            self._ptr = filter_ptr[0]

    @classmethod
    def any(cls) -> "AddressFilter":
        """Create a filter that accepts any address."""
        return cls(None)

    def add(self, address: str):
        """Add an address to the filter."""
        check_error(lib.dnp3_address_filter_add(self._ptr, address.encode()))

    def destroy(self):
        """Destroy the filter."""
        if self._ptr is not None:
            lib.dnp3_address_filter_destroy(self._ptr)
            self._ptr = None

    def __del__(self):
        pass  # Typically destroyed by the caller after use


# --- Outstation wrapper ---


class Outstation:
    """Wraps a dnp3_outstation_t* pointer with enable/disable/transaction/decode_level.

    Instances are returned by OutstationServer.add_outstation() and the
    standalone creation functions.
    """

    def __init__(self, ptr, _refs=None):
        """Wrap a raw outstation pointer.

        Args:
            ptr: dnp3_outstation_t* pointer.
            _refs: Optional list of Python objects to prevent garbage collection.
        """
        self._ptr = ptr
        self._refs = _refs or []
        self._destroyed = False

    @property
    def raw(self):
        """Return the underlying C pointer for advanced use."""
        return self._ptr

    def enable(self):
        """Enable the outstation."""
        check_error(lib.dnp3_outstation_enable(self._ptr))

    def disable(self):
        """Disable the outstation."""
        check_error(lib.dnp3_outstation_disable(self._ptr))

    def set_decode_level(self, level: DecodeLevel):
        """Set the decode/logging level."""
        c_level = ffi.new("dnp3_decode_level_t*", level.to_ffi())[0]
        check_error(lib.dnp3_outstation_set_decode_level(self._ptr, c_level))

    def transaction(self, func: Callable):
        """Execute a database transaction.

        The callable receives a Database instance wrapping the transaction
        handle. All modifications within the callable are applied atomically.

        Example::

            def update(db: Database):
                db.update_binary_input(0, True)
                db.update_analog_input(0, 42.5)

            outstation.transaction(update)
        """
        @ffi.callback("void(dnp3_database_t*, void*)")
        def _execute(db_ptr, ctx):
            db = Database(db_ptr)
            func(db)

        # Must keep callback alive for the duration of the call
        self._last_transaction_cb = _execute

        transaction_s = ffi.new("dnp3_database_transaction_t*", {
            "execute": _execute,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]
        lib.dnp3_outstation_transaction(self._ptr, transaction_s)

    def destroy(self):
        """Destroy the outstation and free resources."""
        if not self._destroyed and self._ptr is not None:
            lib.dnp3_outstation_destroy(self._ptr)
            self._destroyed = True

    def __del__(self):
        try:
            self.destroy()
        except Exception:
            pass


# --- Outstation server ---


class OutstationServer:
    """
    DNP3 outstation server (TCP or TLS).

    Creates a server that accepts master connections over TCP or TLS.

    Args:
        runtime: Runtime instance.
        address: Bind address as "host:port" (default: "127.0.0.1:20000").
        link_error_mode: How to handle link errors (default: CLOSE).
        tls_config: If provided, creates a TLS server instead of TCP.
            Can be a TlsServerConfig instance or a dict with the same keys.
    """

    def __init__(
        self,
        runtime,
        address: str = "127.0.0.1:20000",
        link_error_mode: LinkErrorMode = LinkErrorMode.CLOSE,
        tls_config=None,
    ):
        self._runtime = runtime
        self._outstations = []
        self._destroyed = False
        self._tls_config = None

        if tls_config is not None:
            self._create_tls_server(runtime, address, link_error_mode, tls_config)
        else:
            self._create_tcp_server(runtime, address, link_error_mode)

    def _create_tcp_server(self, runtime, address, link_error_mode):
        """Create a plain TCP outstation server."""
        server_ptr = ffi.new("dnp3_outstation_server_t**")
        err = lib.dnp3_outstation_server_create_tcp_server(
            runtime._ptr,
            link_error_mode.value,
            address.encode(),
            server_ptr,
        )
        check_error(err)
        self._ptr = server_ptr[0]

    def _create_tls_server(self, runtime, address, link_error_mode, tls_config):
        """Create a TLS outstation server."""
        if isinstance(tls_config, dict):
            tls_config = TlsServerConfig.from_dict(tls_config)
        # Keep a reference so buffers are not garbage-collected
        self._tls_config = tls_config

        server_ptr = ffi.new("dnp3_outstation_server_t**")
        err = lib.dnp3_outstation_server_create_tls_server(
            runtime._ptr,
            link_error_mode.value,
            address.encode(),
            tls_config.to_ffi(),
            server_ptr,
        )
        check_error(err)
        self._ptr = server_ptr[0]

    def add_outstation(
        self,
        config: Optional[OutstationConfig] = None,
        application: Optional[OutstationApplication] = None,
        information: Optional[OutstationInformation] = None,
        control_handler: Optional[ControlHandler] = None,
        listener: Optional[ConnectionStateListener] = None,
        address_filter: Optional[AddressFilter] = None,
    ) -> Outstation:
        """Add an outstation to the server.

        Returns an Outstation wrapper with enable/disable/transaction methods.
        """
        config = config or OutstationConfig()
        application = application or OutstationApplication()
        information = information or OutstationInformation()
        control_handler = control_handler or ControlHandler()
        listener = listener or ConnectionStateListener()

        # Keep references
        self._app = application
        self._info = information
        self._ctrl = control_handler
        self._listener = listener

        if address_filter is not None:
            af = address_filter._ptr
        else:
            af = lib.dnp3_address_filter_any()

        outstation_ptr = ffi.new("dnp3_outstation_t**")

        err = lib.dnp3_outstation_server_add_outstation(
            self._ptr,
            config.to_ffi(),
            application.as_ffi(),
            information.as_ffi(),
            control_handler.as_ffi(),
            listener.as_ffi(),
            af,
            outstation_ptr,
        )
        if address_filter is None:
            lib.dnp3_address_filter_destroy(af)
        check_error(err)

        os_obj = Outstation(
            outstation_ptr[0],
            _refs=[application, information, control_handler, listener],
        )
        self._outstations.append(os_obj)
        return os_obj

    def bind(self):
        """Start accepting connections."""
        check_error(lib.dnp3_outstation_server_bind(self._ptr))

    def destroy(self):
        """Clean up all outstations and the server."""
        if self._destroyed:
            return
        self._destroyed = True
        for os_obj in self._outstations:
            os_obj.destroy()
        self._outstations.clear()
        lib.dnp3_outstation_server_destroy(self._ptr)

    def __del__(self):
        try:
            self.destroy()
        except Exception:
            pass


# --- Standalone outstation creation functions ---


def create_tcp_client_outstation(
    runtime,
    endpoints: List[str],
    config: Optional[OutstationConfig] = None,
    application: Optional[OutstationApplication] = None,
    information: Optional[OutstationInformation] = None,
    control_handler: Optional[ControlHandler] = None,
    listener: Optional[ClientStateListener] = None,
    link_error_mode: LinkErrorMode = LinkErrorMode.CLOSE,
    connect_strategy: Optional[ConnectStrategy] = None,
    connect_options=None,
) -> Outstation:
    """Create an outstation that connects to a remote master as a TCP client.

    Args:
        runtime: Runtime instance.
        endpoints: List of "host:port" strings for the master.
        config: Outstation configuration.
        application: Outstation application callbacks.
        information: Outstation information callbacks.
        control_handler: Control handler callbacks.
        listener: Client state change listener.
        link_error_mode: How to handle link errors.
        connect_strategy: Reconnection strategy.
        connect_options: Optional ConnectOptions instance.

    Returns:
        An Outstation wrapper.
    """
    config = config or OutstationConfig()
    application = application or OutstationApplication()
    information = information or OutstationInformation()
    control_handler = control_handler or ControlHandler()
    listener = listener or ClientStateListener()
    connect_strategy = connect_strategy or ConnectStrategy()

    ep_list = lib.dnp3_endpoint_list_create(endpoints[0].encode())
    for ep in endpoints[1:]:
        lib.dnp3_endpoint_list_add(ep_list, ep.encode())

    strategy_ffi = ffi.new("dnp3_connect_strategy_t*", connect_strategy.to_ffi())[0]

    co_ptr = ffi.NULL
    if connect_options is not None:
        co_ptr = connect_options._ptr

    outstation_ptr = ffi.new("dnp3_outstation_t**")
    err = lib.dnp3_outstation_create_tcp_client(
        runtime._ptr,
        link_error_mode.value,
        ep_list,
        strategy_ffi,
        co_ptr,
        config.to_ffi(),
        application.as_ffi(),
        information.as_ffi(),
        control_handler.as_ffi(),
        listener.as_ffi(),
        outstation_ptr,
    )
    lib.dnp3_endpoint_list_destroy(ep_list)
    check_error(err)

    return Outstation(
        outstation_ptr[0],
        _refs=[application, information, control_handler, listener],
    )


def create_tls_client_outstation(
    runtime,
    endpoints: List[str],
    tls_config: dict,
    config: Optional[OutstationConfig] = None,
    application: Optional[OutstationApplication] = None,
    information: Optional[OutstationInformation] = None,
    control_handler: Optional[ControlHandler] = None,
    listener: Optional[ClientStateListener] = None,
    link_error_mode: LinkErrorMode = LinkErrorMode.CLOSE,
    connect_strategy: Optional[ConnectStrategy] = None,
    connect_options=None,
) -> Outstation:
    """Create an outstation that connects to a remote master as a TLS client.

    Args:
        runtime: Runtime instance.
        endpoints: List of "host:port" strings for the master.
        tls_config: Dict with TLS client settings (dns_name, peer_cert_path, etc.).
        config: Outstation configuration.
        application: Outstation application callbacks.
        information: Outstation information callbacks.
        control_handler: Control handler callbacks.
        listener: Client state change listener.
        link_error_mode: How to handle link errors.
        connect_strategy: Reconnection strategy.
        connect_options: Optional ConnectOptions instance.

    Returns:
        An Outstation wrapper.
    """
    config = config or OutstationConfig()
    application = application or OutstationApplication()
    information = information or OutstationInformation()
    control_handler = control_handler or ControlHandler()
    listener = listener or ClientStateListener()
    connect_strategy = connect_strategy or ConnectStrategy()

    ep_list = lib.dnp3_endpoint_list_create(endpoints[0].encode())
    for ep in endpoints[1:]:
        lib.dnp3_endpoint_list_add(ep_list, ep.encode())

    strategy_ffi = ffi.new("dnp3_connect_strategy_t*", connect_strategy.to_ffi())[0]

    co_ptr = ffi.NULL
    if connect_options is not None:
        co_ptr = connect_options._ptr

    # Build TLS client config
    tls_c = ffi.new("dnp3_tls_client_config_t*")
    tls_c.dns_name = ffi.new("char[]", tls_config["dns_name"].encode())
    tls_c.peer_cert_path = ffi.new("char[]", tls_config["peer_cert_path"].encode())
    tls_c.local_cert_path = ffi.new("char[]", tls_config["local_cert_path"].encode())
    tls_c.private_key_path = ffi.new("char[]", tls_config["private_key_path"].encode())
    tls_c.password = ffi.new("char[]", tls_config.get("password", "").encode())
    if "certificate_mode" in tls_config:
        tls_c.certificate_mode = tls_config["certificate_mode"]

    outstation_ptr = ffi.new("dnp3_outstation_t**")
    err = lib.dnp3_outstation_create_tls_client(
        runtime._ptr,
        link_error_mode.value,
        ep_list,
        strategy_ffi,
        co_ptr,
        config.to_ffi(),
        application.as_ffi(),
        information.as_ffi(),
        control_handler.as_ffi(),
        listener.as_ffi(),
        tls_c[0],
        outstation_ptr,
    )
    lib.dnp3_endpoint_list_destroy(ep_list)
    check_error(err)

    return Outstation(
        outstation_ptr[0],
        _refs=[application, information, control_handler, listener],
    )


class ClientConnectionHandler:
    """Callback handler for outstation TCP/TLS client connection events.

    Used with create_tcp_client_outstation_with_handler and
    create_tls_client_outstation_with_handler for custom connection management.
    """

    def __init__(self):
        @ffi.callback("uint64_t(char*, char*, void*)")
        def _disconnected(remote, local, ctx):
            return self.on_disconnected(
                ffi.string(remote).decode() if remote != ffi.NULL else "",
                ffi.string(local).decode() if local != ffi.NULL else "",
            )

        @ffi.callback("void(char*, char*, void*)")
        def _connecting(remote, local, ctx):
            self.on_connecting(
                ffi.string(remote).decode() if remote != ffi.NULL else "",
                ffi.string(local).decode() if local != ffi.NULL else "",
            )

        @ffi.callback("void(char*, char*, void*)")
        def _connect_failed(remote, local, ctx):
            self.on_connect_failed(
                ffi.string(remote).decode() if remote != ffi.NULL else "",
                ffi.string(local).decode() if local != ffi.NULL else "",
            )

        @ffi.callback("void(char*, char*, void*)")
        def _connected(remote, local, ctx):
            self.on_connected(
                ffi.string(remote).decode() if remote != ffi.NULL else "",
                ffi.string(local).decode() if local != ffi.NULL else "",
            )

        @ffi.callback("void(char*, void*)")
        def _resolution_failed(endpoint, ctx):
            self.on_resolution_failed(
                ffi.string(endpoint).decode() if endpoint != ffi.NULL else "",
            )

        @ffi.callback("void(dnp3_next_endpoint_action_t*, void*)")
        def _next(action, ctx):
            from .master_server import NextEndpointAction
            self.on_next(NextEndpointAction(action))

        self._disconnected = _disconnected
        self._connecting = _connecting
        self._connect_failed = _connect_failed
        self._connected = _connected
        self._resolution_failed = _resolution_failed
        self._next = _next

    def on_disconnected(self, remote: str, local: str) -> int:
        """Called on disconnect. Return reconnect delay in ms."""
        return 5000

    def on_connecting(self, remote: str, local: str):
        """Called when connecting."""
        pass

    def on_connect_failed(self, remote: str, local: str):
        """Called when connection fails."""
        pass

    def on_connected(self, remote: str, local: str):
        """Called when connected."""
        pass

    def on_resolution_failed(self, endpoint: str):
        """Called when DNS resolution fails."""
        pass

    def on_next(self, action):
        """Called to determine next endpoint action."""
        pass

    def as_ffi(self):
        return ffi.new("dnp3_client_connection_handler_t*", {
            "disconnected": self._disconnected,
            "connecting": self._connecting,
            "connect_failed": self._connect_failed,
            "connected": self._connected,
            "resolution_failed": self._resolution_failed,
            "next": self._next,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


def create_tcp_client_outstation_with_handler(
    runtime,
    address: str,
    config: Optional[OutstationConfig] = None,
    application: Optional[OutstationApplication] = None,
    information: Optional[OutstationInformation] = None,
    control_handler: Optional[ControlHandler] = None,
    listener: Optional[ClientStateListener] = None,
    connection_handler: Optional[ClientConnectionHandler] = None,
    link_error_mode: LinkErrorMode = LinkErrorMode.CLOSE,
) -> Outstation:
    """Create a TCP client outstation with a custom connection handler.

    Args:
        runtime: Runtime instance.
        address: Initial remote "host:port" address.
        config: Outstation configuration.
        application: Outstation application callbacks.
        information: Outstation information callbacks.
        control_handler: Control handler callbacks.
        listener: Client state change listener.
        connection_handler: Custom connection lifecycle handler.
        link_error_mode: How to handle link errors.

    Returns:
        An Outstation wrapper.
    """
    config = config or OutstationConfig()
    application = application or OutstationApplication()
    information = information or OutstationInformation()
    control_handler = control_handler or ControlHandler()
    listener = listener or ClientStateListener()
    connection_handler = connection_handler or ClientConnectionHandler()

    outstation_ptr = ffi.new("dnp3_outstation_t**")
    err = lib.dnp3_outstation_create_tcp_client_with_handler(
        runtime._ptr,
        link_error_mode.value,
        address.encode(),
        config.to_ffi(),
        application.as_ffi(),
        information.as_ffi(),
        control_handler.as_ffi(),
        listener.as_ffi(),
        connection_handler.as_ffi(),
        outstation_ptr,
    )
    check_error(err)

    return Outstation(
        outstation_ptr[0],
        _refs=[application, information, control_handler, listener, connection_handler],
    )


def create_tls_client_outstation_with_handler(
    runtime,
    address: str,
    tls_config: dict,
    config: Optional[OutstationConfig] = None,
    application: Optional[OutstationApplication] = None,
    information: Optional[OutstationInformation] = None,
    control_handler: Optional[ControlHandler] = None,
    listener: Optional[ClientStateListener] = None,
    connection_handler: Optional[ClientConnectionHandler] = None,
    link_error_mode: LinkErrorMode = LinkErrorMode.CLOSE,
) -> Outstation:
    """Create a TLS client outstation with a custom connection handler.

    Args:
        runtime: Runtime instance.
        address: Initial remote "host:port" address.
        tls_config: Dict with TLS client settings.
        config: Outstation configuration.
        application: Outstation application callbacks.
        information: Outstation information callbacks.
        control_handler: Control handler callbacks.
        listener: Client state change listener.
        connection_handler: Custom connection lifecycle handler.
        link_error_mode: How to handle link errors.

    Returns:
        An Outstation wrapper.
    """
    config = config or OutstationConfig()
    application = application or OutstationApplication()
    information = information or OutstationInformation()
    control_handler = control_handler or ControlHandler()
    listener = listener or ClientStateListener()
    connection_handler = connection_handler or ClientConnectionHandler()

    tls_c = ffi.new("dnp3_tls_client_config_t*")
    tls_c.dns_name = ffi.new("char[]", tls_config["dns_name"].encode())
    tls_c.peer_cert_path = ffi.new("char[]", tls_config["peer_cert_path"].encode())
    tls_c.local_cert_path = ffi.new("char[]", tls_config["local_cert_path"].encode())
    tls_c.private_key_path = ffi.new("char[]", tls_config["private_key_path"].encode())
    tls_c.password = ffi.new("char[]", tls_config.get("password", "").encode())
    if "certificate_mode" in tls_config:
        tls_c.certificate_mode = tls_config["certificate_mode"]

    outstation_ptr = ffi.new("dnp3_outstation_t**")
    err = lib.dnp3_outstation_create_tls_client_with_handler(
        runtime._ptr,
        link_error_mode.value,
        address.encode(),
        config.to_ffi(),
        application.as_ffi(),
        information.as_ffi(),
        control_handler.as_ffi(),
        listener.as_ffi(),
        connection_handler.as_ffi(),
        tls_c[0],
        outstation_ptr,
    )
    check_error(err)

    return Outstation(
        outstation_ptr[0],
        _refs=[application, information, control_handler, listener, connection_handler],
    )


def create_serial_outstation(
    runtime,
    path: str,
    config: Optional[OutstationConfig] = None,
    application: Optional[OutstationApplication] = None,
    information: Optional[OutstationInformation] = None,
    control_handler: Optional[ControlHandler] = None,
    baud_rate: int = 9600,
) -> Outstation:
    """Create an outstation on a serial port.

    Args:
        runtime: Runtime instance.
        path: Serial port path (e.g. "/dev/ttyS0").
        config: Outstation configuration.
        application: Outstation application callbacks.
        information: Outstation information callbacks.
        control_handler: Control handler callbacks.
        baud_rate: Serial baud rate (default: 9600).

    Returns:
        An Outstation wrapper.
    """
    config = config or OutstationConfig()
    application = application or OutstationApplication()
    information = information or OutstationInformation()
    control_handler = control_handler or ControlHandler()

    serial_settings = ffi.new("dnp3_serial_settings_t*")
    serial_settings.baud_rate = baud_rate
    serial_settings.data_bits = lib.DNP3_DATA_BITS_EIGHT
    serial_settings.flow_control = lib.DNP3_FLOW_CONTROL_NONE
    serial_settings.parity = lib.DNP3_PARITY_NONE
    serial_settings.stop_bits = lib.DNP3_STOP_BITS_ONE

    outstation_ptr = ffi.new("dnp3_outstation_t**")
    err = lib.dnp3_outstation_create_serial_session(
        runtime._ptr,
        path.encode(),
        serial_settings[0],
        config.to_ffi(),
        application.as_ffi(),
        information.as_ffi(),
        control_handler.as_ffi(),
        outstation_ptr,
    )
    check_error(err)

    return Outstation(
        outstation_ptr[0],
        _refs=[application, information, control_handler],
    )


def create_serial_outstation_2(
    runtime,
    path: str,
    config: Optional[OutstationConfig] = None,
    application: Optional[OutstationApplication] = None,
    information: Optional[OutstationInformation] = None,
    control_handler: Optional[ControlHandler] = None,
    listener: Optional[PortStateListener] = None,
    baud_rate: int = 9600,
    open_retry_delay: int = 5000,
) -> Outstation:
    """Create an outstation on a serial port with port state listener.

    Like create_serial_outstation but adds a PortStateListener and
    configurable retry delay.

    Args:
        runtime: Runtime instance.
        path: Serial port path.
        config: Outstation configuration.
        application: Outstation application callbacks.
        information: Outstation information callbacks.
        control_handler: Control handler callbacks.
        listener: Port state change listener.
        baud_rate: Serial baud rate.
        open_retry_delay: Retry delay in ms when port open fails.

    Returns:
        An Outstation wrapper.
    """
    config = config or OutstationConfig()
    application = application or OutstationApplication()
    information = information or OutstationInformation()
    control_handler = control_handler or ControlHandler()
    listener = listener or PortStateListener()

    serial_settings = ffi.new("dnp3_serial_settings_t*")
    serial_settings.baud_rate = baud_rate
    serial_settings.data_bits = lib.DNP3_DATA_BITS_EIGHT
    serial_settings.flow_control = lib.DNP3_FLOW_CONTROL_NONE
    serial_settings.parity = lib.DNP3_PARITY_NONE
    serial_settings.stop_bits = lib.DNP3_STOP_BITS_ONE

    outstation_ptr = ffi.new("dnp3_outstation_t**")
    err = lib.dnp3_outstation_create_serial_session_2(
        runtime._ptr,
        path.encode(),
        serial_settings[0],
        open_retry_delay,
        config.to_ffi(),
        application.as_ffi(),
        information.as_ffi(),
        control_handler.as_ffi(),
        listener.as_ffi(),
        outstation_ptr,
    )
    check_error(err)

    return Outstation(
        outstation_ptr[0],
        _refs=[application, information, control_handler, listener],
    )


def create_serial_outstation_fault_tolerant(
    runtime,
    path: str,
    config: Optional[OutstationConfig] = None,
    application: Optional[OutstationApplication] = None,
    information: Optional[OutstationInformation] = None,
    control_handler: Optional[ControlHandler] = None,
    baud_rate: int = 9600,
    open_retry_delay: int = 5000,
) -> Outstation:
    """Create a fault-tolerant serial outstation that automatically reopens the port.

    Args:
        runtime: Runtime instance.
        path: Serial port path.
        config: Outstation configuration.
        application: Outstation application callbacks.
        information: Outstation information callbacks.
        control_handler: Control handler callbacks.
        baud_rate: Serial baud rate.
        open_retry_delay: Retry delay in ms.

    Returns:
        An Outstation wrapper.
    """
    config = config or OutstationConfig()
    application = application or OutstationApplication()
    information = information or OutstationInformation()
    control_handler = control_handler or ControlHandler()

    serial_settings = ffi.new("dnp3_serial_settings_t*")
    serial_settings.baud_rate = baud_rate
    serial_settings.data_bits = lib.DNP3_DATA_BITS_EIGHT
    serial_settings.flow_control = lib.DNP3_FLOW_CONTROL_NONE
    serial_settings.parity = lib.DNP3_PARITY_NONE
    serial_settings.stop_bits = lib.DNP3_STOP_BITS_ONE

    outstation_ptr = ffi.new("dnp3_outstation_t**")
    err = lib.dnp3_outstation_create_serial_session_fault_tolerant(
        runtime._ptr,
        path.encode(),
        serial_settings[0],
        open_retry_delay,
        config.to_ffi(),
        application.as_ffi(),
        information.as_ffi(),
        control_handler.as_ffi(),
        outstation_ptr,
    )
    check_error(err)

    return Outstation(
        outstation_ptr[0],
        _refs=[application, information, control_handler],
    )


def create_udp_outstation(
    runtime,
    local_endpoint: str,
    remote_endpoint: str,
    config: Optional[OutstationConfig] = None,
    application: Optional[OutstationApplication] = None,
    information: Optional[OutstationInformation] = None,
    control_handler: Optional[ControlHandler] = None,
    retry_delay: int = 5000,
) -> Outstation:
    """Create a UDP outstation.

    Args:
        runtime: Runtime instance.
        local_endpoint: Local bind address "host:port".
        remote_endpoint: Remote master address "host:port".
        config: Outstation configuration.
        application: Outstation application callbacks.
        information: Outstation information callbacks.
        control_handler: Control handler callbacks.
        retry_delay: Retry delay in ms.

    Returns:
        An Outstation wrapper.
    """
    config = config or OutstationConfig()
    application = application or OutstationApplication()
    information = information or OutstationInformation()
    control_handler = control_handler or ControlHandler()

    udp_config = ffi.new("dnp3_outstation_udp_config_t*")
    udp_config.local_endpoint = ffi.new("char[]", local_endpoint.encode())
    udp_config.remote_endpoint = ffi.new("char[]", remote_endpoint.encode())
    udp_config.socket_mode = lib.DNP3_UDP_SOCKET_MODE_ONE_TO_ONE
    udp_config.link_read_mode = lib.DNP3_LINK_READ_MODE_DATAGRAM
    udp_config.retry_delay = retry_delay

    outstation_ptr = ffi.new("dnp3_outstation_t**")
    err = lib.dnp3_outstation_create_udp(
        runtime._ptr,
        udp_config[0],
        config.to_ffi(),
        application.as_ffi(),
        information.as_ffi(),
        control_handler.as_ffi(),
        outstation_ptr,
    )
    check_error(err)

    return Outstation(
        outstation_ptr[0],
        _refs=[application, information, control_handler],
    )
