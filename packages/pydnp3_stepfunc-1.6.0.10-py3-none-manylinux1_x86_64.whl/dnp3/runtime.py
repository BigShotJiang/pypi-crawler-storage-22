"""
DNP3 runtime management.

The runtime manages the Tokio async runtime used by the Rust library.
It must be created before any channels and destroyed after all channels.
"""

from ._ffi import ffi, lib, check_error


class Runtime:
    """
    Manages the underlying Tokio async runtime.

    Usage:
        runtime = Runtime(num_threads=4)
        # ... create channels ...
        runtime.destroy()

    Or as a context manager:
        with Runtime() as runtime:
            channel = create_tcp_channel(runtime, ...)
    """

    def __init__(self, num_threads: int = 0):
        """
        Create a new runtime.

        Args:
            num_threads: Number of worker threads. 0 = auto-detect from CPU count.
        """
        rt_ptr = ffi.new("dnp3_runtime_t**")
        config = ffi.new("dnp3_runtime_config_t*", {"num_core_threads": num_threads})
        err = lib.dnp3_runtime_create(config[0], rt_ptr)
        check_error(err)
        self._ptr = rt_ptr[0]
        self._destroyed = False

    def set_shutdown_timeout(self, timeout_secs: int):
        """Set maximum time to wait during shutdown."""
        lib.dnp3_runtime_set_shutdown_timeout(self._ptr, timeout_secs)

    def destroy(self):
        """Destroy the runtime. Blocks until all tasks complete."""
        if not self._destroyed and self._ptr is not None:
            lib.dnp3_runtime_destroy(self._ptr)
            self._destroyed = True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.destroy()
        return False

    def __del__(self):
        self.destroy()
