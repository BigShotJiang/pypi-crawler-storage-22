"""
pydnp3-stepfunc: Python bindings for the stepfunc/dnp3 Rust library.

Provides a Pythonic API for DNP3 master and outstation operations,
built on the production-quality stepfunc/dnp3 implementation with
full Secure Authentication support.

License: stepfunc/dnp3 uses a non-commercial license
(evaluation/research/training only).

Basic usage::

    from dnp3 import Runtime, MasterChannelConfig, ReadHandler
    from dnp3.channel import create_tcp_channel
    from dnp3.logging import configure_logging, LogLevel

    configure_logging(LogLevel.INFO)

    with Runtime() as runtime:
        handler = ReadHandler()
        channel = create_tcp_channel(
            runtime,
            endpoints=["127.0.0.1:20000"],
            config=MasterChannelConfig(address=1),
        )
        assoc = channel.add_association(address=1024, read_handler=handler)
        channel.enable()

        # Read all data
        channel.read(assoc)

        # Access collected data
        for bi in handler.binary_inputs:
            print(f"BI {bi.index}: {bi.value}")
        for ai in handler.analog_inputs:
            print(f"AI {ai.index}: {ai.value}")

        channel.destroy()
"""

__version__ = "1.6.0.6"

from ._ffi import DNP3Error

from .runtime import Runtime

from .types import (
    # Enums
    ParamError,
    CommandStatus,
    TripCloseCode,
    OpType,
    DoubleBit,
    TimeQuality,
    CommandMode,
    TimeSyncMode,
    LinkErrorMode,
    AppDecodeLevel,
    TransportDecodeLevel,
    LinkDecodeLevel,
    PhysDecodeLevel,
    FunctionCode,
    ClientState,
    ReadType,
    TaskType,
    AutoTimeSync,
    MinTlsVersion,
    CertificateMode,
    Variation,
    # Convenience group/variation aliases
    BINARY_INPUT,
    BINARY_OUTPUT,
    ANALOG_INPUT,
    ANALOG_OUTPUT,
    COUNTER,
    FROZEN_COUNTER,
    # Data classes
    Flags,
    Timestamp,
    BinaryInput,
    DoubleBitBinaryInput,
    BinaryOutputStatus,
    Counter,
    FrozenCounter,
    AnalogInput,
    AnalogOutputStatus,
    FrozenAnalogInput,
    AnalogOutputCommandEvent,
    BinaryOutputCommandEvent,
    AttributeItem,
    UnsignedInteger,
    ControlCode,
    Group12Var1,
    DecodeLevel,
    ConnectStrategy,
    IIN,
    IIN1,
    IIN2,
    # Error enums and result types
    ReadError,
    TaskErrorCode,
    ReadResult,
    FileResult,
    # Utility data types
    OctetStringValue,
    ByteCollection,
    # Library-level utility functions
    version,
    parse_zero_length_strings,
    disable_client_tcp_no_delay,
    disable_server_tcp_no_delay,
)

from .handler import (
    ReadHandler,
    ClientStateListener,
    PortStateListener,
    ConnectionStateListener,
    AssociationHandler,
    AssociationInformation,
    ReadTaskCallback,
    CommandTaskCallback,
    TimeSyncTaskCallback,
    RestartTaskCallback,
    EmptyResponseCallback,
    LinkStatusCallback,
)

from .channel import (
    MasterChannelConfig,
    ConnectOptions,
    create_tcp_channel,
    create_tcp_channel_2,
    create_tls_channel,
    create_tls_channel_2,
    create_serial_channel,
    create_udp_channel,
)

from .master import (
    MasterChannel,
    AssociationConfig,
    AssociationId,
    PollId,
    # File transfer
    FileReadConfig,
    DirReadConfig,
    FileReader,
    FileInfoCallback,
    FileOpenCallback,
    FileOperationCallback,
    FileAuthCallback,
    ReadDirectoryCallback,
    FileError,
    FileMode,
    FileType,
    # Dead bands
    DeadBandRequest,
    # Request builder helpers
    create_request,
    destroy_request,
    request_add_one_byte_range_header,
    request_add_two_byte_range_header,
    request_add_one_byte_limited_count_header,
    request_add_two_byte_limited_count_header,
    request_add_string_attribute,
    request_add_uint_attribute,
    request_add_time_and_interval,
    request_new_one_byte_range,
    request_new_one_byte_limited_count,
    request_new_two_byte_limited_count,
)

from .outstation import (
    OutstationServer,
    OutstationConfig,
    EventBufferConfig,
    OutstationApplication,
    OutstationInformation,
    ControlHandler,
    TlsServerConfig,
    # New classes
    Outstation,
    Database,
    AddressFilter,
    UpdateOptions,
    EventClass,
    EventMode,
    UpdateFlagsType,
    # Connection handler for client outstations
    ClientConnectionHandler,
    # Standalone outstation creation functions
    create_tcp_client_outstation,
    create_tls_client_outstation,
    create_tcp_client_outstation_with_handler,
    create_tls_client_outstation_with_handler,
    create_serial_outstation,
    create_serial_outstation_2,
    create_serial_outstation_fault_tolerant,
    create_udp_outstation,
)

from .master_server import (
    MasterTcpServer,
    ConnectionHandler,
    ConnectionInfo,
    NextEndpointAction,
)

from .logging import (
    configure_logging,
    LogLevel,
    LogOutputFormat,
    TimeFormat,
)
