"""
Callback handler wrappers for DNP3 read/command/event callbacks.

The C FFI uses function pointers in structs for async callbacks.
This module wraps them with cffi @ffi.callback decorators and
collects data into Python objects.
"""

import threading
from typing import List, Optional, Dict, Any

from ._ffi import ffi, lib
from .types import (
    BinaryInput,
    DoubleBitBinaryInput,
    BinaryOutputStatus,
    Counter,
    FrozenCounter,
    AnalogInput,
    AnalogOutputStatus,
    FrozenAnalogInput,
    AnalogOutputCommandEvent,
    BinaryOutputCommandEvent,
    AttributeItem,
    UnsignedInteger,
    IIN,
    ReadType,
    ReadError,
    TaskErrorCode,
)


class ReadHandler:
    """
    Collects data received from DNP3 read operations.

    Usage:
        handler = ReadHandler()
        # Pass handler.as_ffi() to master_channel_read or add_association
        # After read completes, access handler.binary_inputs, handler.analog_inputs, etc.
    """

    def __init__(self):
        self.binary_inputs: List[BinaryInput] = []
        self.double_bit_binary_inputs: List[DoubleBitBinaryInput] = []
        self.binary_output_statuses: List[BinaryOutputStatus] = []
        self.counters: List[Counter] = []
        self.frozen_counters: List[FrozenCounter] = []
        self.analog_inputs: List[AnalogInput] = []
        self.analog_output_statuses: List[AnalogOutputStatus] = []
        self.frozen_analog_inputs: List[FrozenAnalogInput] = []
        self.analog_output_command_events: List[AnalogOutputCommandEvent] = []
        self.binary_output_command_events: List[BinaryOutputCommandEvent] = []
        self.attribute_items: List[AttributeItem] = []
        self.unsigned_integers: List[UnsignedInteger] = []
        self.octet_strings: List[Dict[str, Any]] = []
        self.string_attrs: List[Dict[str, Any]] = []
        self.response_headers: List[Dict[str, Any]] = []
        self.iin: Optional[IIN] = None
        self._lock = threading.Lock()

        # Create persistent C callbacks - these must be kept alive
        # as long as the handler is in use

        @ffi.callback("void(dnp3_read_type_t, dnp3_response_header_t, void*)")
        def _begin_fragment(read_type, header, ctx):
            with self._lock:
                self.iin = IIN.from_ffi(header.iin)

        @ffi.callback("void(dnp3_read_type_t, dnp3_response_header_t, void*)")
        def _end_fragment(read_type, header, ctx):
            pass

        @ffi.callback("void(dnp3_header_info_t, dnp3_binary_input_iterator_t*, void*)")
        def _handle_binary_input(info, it, ctx):
            with self._lock:
                count = 0
                while True:
                    val = lib.dnp3_binary_input_iterator_next(it)
                    if val == ffi.NULL:
                        break
                    self.binary_inputs.append(BinaryInput.from_ffi(val))
                    count += 1
                self.response_headers.append({"variation": int(info.variation), "count": count})

        @ffi.callback("void(dnp3_header_info_t, dnp3_double_bit_binary_input_iterator_t*, void*)")
        def _handle_double_bit(info, it, ctx):
            with self._lock:
                count = 0
                while True:
                    val = lib.dnp3_double_bit_binary_input_iterator_next(it)
                    if val == ffi.NULL:
                        break
                    self.double_bit_binary_inputs.append(DoubleBitBinaryInput.from_ffi(val))
                    count += 1
                self.response_headers.append({"variation": int(info.variation), "count": count})

        @ffi.callback("void(dnp3_header_info_t, dnp3_binary_output_status_iterator_t*, void*)")
        def _handle_bos(info, it, ctx):
            with self._lock:
                count = 0
                while True:
                    val = lib.dnp3_binary_output_status_iterator_next(it)
                    if val == ffi.NULL:
                        break
                    self.binary_output_statuses.append(BinaryOutputStatus.from_ffi(val))
                    count += 1
                self.response_headers.append({"variation": int(info.variation), "count": count})

        @ffi.callback("void(dnp3_header_info_t, dnp3_counter_iterator_t*, void*)")
        def _handle_counter(info, it, ctx):
            with self._lock:
                count = 0
                while True:
                    val = lib.dnp3_counter_iterator_next(it)
                    if val == ffi.NULL:
                        break
                    self.counters.append(Counter.from_ffi(val))
                    count += 1
                self.response_headers.append({"variation": int(info.variation), "count": count})

        @ffi.callback("void(dnp3_header_info_t, dnp3_frozen_counter_iterator_t*, void*)")
        def _handle_frozen_counter(info, it, ctx):
            with self._lock:
                count = 0
                while True:
                    val = lib.dnp3_frozen_counter_iterator_next(it)
                    if val == ffi.NULL:
                        break
                    self.frozen_counters.append(FrozenCounter.from_ffi(val))
                    count += 1
                self.response_headers.append({"variation": int(info.variation), "count": count})

        @ffi.callback("void(dnp3_header_info_t, dnp3_analog_input_iterator_t*, void*)")
        def _handle_analog_input(info, it, ctx):
            with self._lock:
                count = 0
                while True:
                    val = lib.dnp3_analog_input_iterator_next(it)
                    if val == ffi.NULL:
                        break
                    self.analog_inputs.append(AnalogInput.from_ffi(val))
                    count += 1
                self.response_headers.append({"variation": int(info.variation), "count": count})

        @ffi.callback("void(dnp3_header_info_t, dnp3_analog_output_status_iterator_t*, void*)")
        def _handle_aos(info, it, ctx):
            with self._lock:
                count = 0
                while True:
                    val = lib.dnp3_analog_output_status_iterator_next(it)
                    if val == ffi.NULL:
                        break
                    self.analog_output_statuses.append(AnalogOutputStatus.from_ffi(val))
                    count += 1
                self.response_headers.append({"variation": int(info.variation), "count": count})

        @ffi.callback("void(dnp3_header_info_t, dnp3_octet_string_iterator_t*, void*)")
        def _handle_octet_string(info, it, ctx):
            with self._lock:
                count = 0
                while True:
                    val = lib.dnp3_octet_string_iterator_next(it)
                    if val == ffi.NULL:
                        break
                    data = []
                    while True:
                        byte_ptr = lib.dnp3_byte_iterator_next(val.value)
                        if byte_ptr == ffi.NULL:
                            break
                        data.append(byte_ptr[0])
                    self.octet_strings.append({"index": val.index, "value": bytes(data)})
                    count += 1
                self.response_headers.append({"variation": int(info.variation), "count": count})

        @ffi.callback("void(dnp3_header_info_t, dnp3_string_attr_t, uint8_t, uint8_t, const char*, void*)")
        def _handle_string_attr(info, attr, set_id, variation, value, ctx):
            with self._lock:
                self.string_attrs.append({
                    "attr": int(attr),
                    "set": set_id,
                    "variation": variation,
                    "value": ffi.string(value).decode() if value != ffi.NULL else "",
                })

        @ffi.callback("void(dnp3_header_info_t, dnp3_frozen_analog_input_iterator_t*, void*)")
        def _handle_frozen_analog_input(info, it, ctx):
            with self._lock:
                count = 0
                while True:
                    val = lib.dnp3_frozen_analog_input_iterator_next(it)
                    if val == ffi.NULL:
                        break
                    self.frozen_analog_inputs.append(FrozenAnalogInput.from_ffi(val))
                    count += 1
                self.response_headers.append({"variation": int(info.variation), "count": count})

        @ffi.callback("void(dnp3_header_info_t, dnp3_analog_output_command_event_iterator_t*, void*)")
        def _handle_analog_output_command_event(info, it, ctx):
            with self._lock:
                count = 0
                while True:
                    val = lib.dnp3_analog_output_command_event_iterator_next(it)
                    if val == ffi.NULL:
                        break
                    self.analog_output_command_events.append(AnalogOutputCommandEvent.from_ffi(val))
                    count += 1
                self.response_headers.append({"variation": int(info.variation), "count": count})

        @ffi.callback("void(dnp3_header_info_t, dnp3_binary_output_command_event_iterator_t*, void*)")
        def _handle_binary_output_command_event(info, it, ctx):
            with self._lock:
                count = 0
                while True:
                    val = lib.dnp3_binary_output_command_event_iterator_next(it)
                    if val == ffi.NULL:
                        break
                    self.binary_output_command_events.append(BinaryOutputCommandEvent.from_ffi(val))
                    count += 1
                self.response_headers.append({"variation": int(info.variation), "count": count})

        @ffi.callback("void(dnp3_header_info_t, dnp3_unsigned_integer_iterator_t*, void*)")
        def _handle_unsigned_integer(info, it, ctx):
            with self._lock:
                count = 0
                while True:
                    val = lib.dnp3_unsigned_integer_iterator_next(it)
                    if val == ffi.NULL:
                        break
                    self.unsigned_integers.append(UnsignedInteger.from_ffi(val))
                    count += 1
                self.response_headers.append({"variation": int(info.variation), "count": count})

        @ffi.callback("void(dnp3_header_info_t, dnp3_timestamp_t, void*)")
        def _handle_abs_time(info, ts, ctx):
            pass  # Absolute time -- no-op by default

        @ffi.callback("void(dnp3_header_info_t, dnp3_variation_list_attr_t, uint8_t, uint8_t, dnp3_attr_item_iter_t*, void*)")
        def _handle_variation_list_attr(info, attr, set_id, variation, it, ctx):
            with self._lock:
                while True:
                    val = lib.dnp3_attr_item_iter_next(it)
                    if val == ffi.NULL:
                        break
                    self.attribute_items.append(AttributeItem.from_ffi(val))

        @ffi.callback("void(dnp3_header_info_t, dnp3_uint_attr_t, uint8_t, uint8_t, uint32_t, void*)")
        def _handle_uint_attr(info, attr, set_id, variation, value, ctx):
            with self._lock:
                self.string_attrs.append({
                    "attr": int(attr), "set": set_id, "variation": variation,
                    "value": str(value), "type": "uint",
                })

        @ffi.callback("void(dnp3_header_info_t, dnp3_bool_attr_t, uint8_t, uint8_t, _Bool, void*)")
        def _handle_bool_attr(info, attr, set_id, variation, value, ctx):
            with self._lock:
                self.string_attrs.append({
                    "attr": int(attr), "set": set_id, "variation": variation,
                    "value": str(value), "type": "bool",
                })

        @ffi.callback("void(dnp3_header_info_t, dnp3_int_attr_t, uint8_t, uint8_t, int32_t, void*)")
        def _handle_int_attr(info, attr, set_id, variation, value, ctx):
            with self._lock:
                self.string_attrs.append({
                    "attr": int(attr), "set": set_id, "variation": variation,
                    "value": str(value), "type": "int",
                })

        @ffi.callback("void(dnp3_header_info_t, dnp3_time_attr_t, uint8_t, uint8_t, uint64_t, void*)")
        def _handle_time_attr(info, attr, set_id, variation, value, ctx):
            with self._lock:
                self.string_attrs.append({
                    "attr": int(attr), "set": set_id, "variation": variation,
                    "value": str(value), "type": "time",
                })

        @ffi.callback("void(dnp3_header_info_t, dnp3_float_attr_t, uint8_t, uint8_t, double, void*)")
        def _handle_float_attr(info, attr, set_id, variation, value, ctx):
            with self._lock:
                self.string_attrs.append({
                    "attr": int(attr), "set": set_id, "variation": variation,
                    "value": str(value), "type": "float",
                })

        @ffi.callback("void(dnp3_header_info_t, dnp3_octet_string_attr_t, uint8_t, uint8_t, dnp3_byte_iterator_t*, void*)")
        def _handle_octet_string_attr(info, attr, set_id, variation, it, ctx):
            with self._lock:
                data = []
                while True:
                    byte_ptr = lib.dnp3_byte_iterator_next(it)
                    if byte_ptr == ffi.NULL:
                        break
                    data.append(byte_ptr[0])
                self.string_attrs.append({
                    "attr": int(attr), "set": set_id, "variation": variation,
                    "value": bytes(data), "type": "octet_string",
                })

        @ffi.callback("void(dnp3_header_info_t, dnp3_bit_string_attr_t, uint8_t, uint8_t, dnp3_byte_iterator_t*, void*)")
        def _handle_bit_string_attr(info, attr, set_id, variation, it, ctx):
            with self._lock:
                data = []
                while True:
                    byte_ptr = lib.dnp3_byte_iterator_next(it)
                    if byte_ptr == ffi.NULL:
                        break
                    data.append(byte_ptr[0])
                self.string_attrs.append({
                    "attr": int(attr), "set": set_id, "variation": variation,
                    "value": bytes(data), "type": "bit_string",
                })

        # Store references to prevent GC
        self._begin_fragment = _begin_fragment
        self._end_fragment = _end_fragment
        self._handle_binary_input = _handle_binary_input
        self._handle_double_bit = _handle_double_bit
        self._handle_bos = _handle_bos
        self._handle_counter = _handle_counter
        self._handle_frozen_counter = _handle_frozen_counter
        self._handle_analog_input = _handle_analog_input
        self._handle_aos = _handle_aos
        self._handle_octet_string = _handle_octet_string
        self._handle_string_attr = _handle_string_attr
        self._handle_frozen_analog_input = _handle_frozen_analog_input
        self._handle_analog_output_command_event = _handle_analog_output_command_event
        self._handle_binary_output_command_event = _handle_binary_output_command_event
        self._handle_unsigned_integer = _handle_unsigned_integer
        self._handle_abs_time = _handle_abs_time
        self._handle_variation_list_attr = _handle_variation_list_attr
        self._handle_uint_attr = _handle_uint_attr
        self._handle_bool_attr = _handle_bool_attr
        self._handle_int_attr = _handle_int_attr
        self._handle_time_attr = _handle_time_attr
        self._handle_float_attr = _handle_float_attr
        self._handle_octet_string_attr = _handle_octet_string_attr
        self._handle_bit_string_attr = _handle_bit_string_attr

    def clear(self):
        """Reset all collected data."""
        with self._lock:
            self.binary_inputs.clear()
            self.double_bit_binary_inputs.clear()
            self.binary_output_statuses.clear()
            self.counters.clear()
            self.frozen_counters.clear()
            self.analog_inputs.clear()
            self.analog_output_statuses.clear()
            self.frozen_analog_inputs.clear()
            self.analog_output_command_events.clear()
            self.binary_output_command_events.clear()
            self.attribute_items.clear()
            self.unsigned_integers.clear()
            self.octet_strings.clear()
            self.string_attrs.clear()
            self.response_headers.clear()
            self.iin = None

    def as_ffi(self):
        """Return a dnp3_read_handler_t struct for use with the C FFI."""
        return ffi.new("dnp3_read_handler_t*", {
            "begin_fragment": self._begin_fragment,
            "end_fragment": self._end_fragment,
            "handle_binary_input": self._handle_binary_input,
            "handle_double_bit_binary_input": self._handle_double_bit,
            "handle_binary_output_status": self._handle_bos,
            "handle_counter": self._handle_counter,
            "handle_frozen_counter": self._handle_frozen_counter,
            "handle_analog_input": self._handle_analog_input,
            "handle_frozen_analog_input": self._handle_frozen_analog_input,
            "handle_analog_output_status": self._handle_aos,
            "handle_binary_output_command_event": self._handle_binary_output_command_event,
            "handle_analog_output_command_event": self._handle_analog_output_command_event,
            "handle_unsigned_integer": self._handle_unsigned_integer,
            "handle_octet_string": self._handle_octet_string,
            "handle_abs_time": self._handle_abs_time,
            "handle_string_attr": self._handle_string_attr,
            "handle_variation_list_attr": self._handle_variation_list_attr,
            "handle_uint_attr": self._handle_uint_attr,
            "handle_bool_attr": self._handle_bool_attr,
            "handle_int_attr": self._handle_int_attr,
            "handle_time_attr": self._handle_time_attr,
            "handle_float_attr": self._handle_float_attr,
            "handle_octet_string_attr": self._handle_octet_string_attr,
            "handle_bit_string_attr": self._handle_bit_string_attr,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class ClientStateListener:
    """Tracks master channel connection state changes."""

    def __init__(self):
        self.state = None
        self._event = threading.Event()
        self._lock = threading.Lock()

        @ffi.callback("void(dnp3_client_state_t, void*)")
        def _on_change(state, ctx):
            with self._lock:
                self.state = int(state)
            self._event.set()

        self._on_change = _on_change

    def wait_for_state(self, expected_state, timeout=10.0) -> bool:
        """Wait for a specific state, returns True if reached."""
        deadline = threading.Event()
        while True:
            with self._lock:
                if self.state == expected_state:
                    return True
            if not self._event.wait(timeout):
                return False
            self._event.clear()

    def as_ffi(self):
        return ffi.new("dnp3_client_state_listener_t*", {
            "on_change": self._on_change,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class PortStateListener:
    """Tracks serial port state changes."""

    def __init__(self):
        self.state = None

        @ffi.callback("void(dnp3_port_state_t, void*)")
        def _on_change(state, ctx):
            self.state = int(state)

        self._on_change = _on_change

    def as_ffi(self):
        return ffi.new("dnp3_port_state_listener_t*", {
            "on_change": self._on_change,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class ConnectionStateListener:
    """Tracks outstation server connection state changes."""

    def __init__(self):
        self.state = None

        @ffi.callback("void(dnp3_connection_state_t, void*)")
        def _on_change(state, ctx):
            self.state = int(state)

        self._on_change = _on_change

    def as_ffi(self):
        return ffi.new("dnp3_connection_state_listener_t*", {
            "on_change": self._on_change,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class AssociationHandler:
    """Provides time synchronization for master-outstation association."""

    def __init__(self):
        @ffi.callback("dnp3_utc_timestamp_t(void*)")
        def _get_current_time(ctx):
            import time
            return ffi.new("dnp3_utc_timestamp_t*", {
                "value": int(time.time() * 1000),
                "is_valid": True,
            })[0]

        self._get_current_time = _get_current_time

    def as_ffi(self):
        return ffi.new("dnp3_association_handler_t*", {
            "get_current_time": self._get_current_time,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class AssociationInformation:
    """Receives task status notifications.

    Tracks the last task error with typed error codes. When a task fails
    with ``task_error == TaskErrorCode.IIN_ERROR``, this means the outstation
    rejected the request via IIN2 error bits.

    Attributes:
        last_task_type: Last task type that completed or failed (int from TaskType enum).
        last_error: Raw error code from the last failure (int).
        last_task_error: Typed TaskErrorCode from the last failure (or None).
        last_success_task_type: Last task type that succeeded.
        failure_count: Running count of task failures.
        iin_error_count: Running count of IIN2-related failures.
    """

    def __init__(self):
        self.last_task_type = None
        self.last_error = None
        self.last_task_error = None  # type: Optional[TaskErrorCode]
        self.last_success_task_type = None
        self.failure_count = 0
        self.iin_error_count = 0
        self._lock = threading.Lock()

        @ffi.callback("void(dnp3_task_type_t, dnp3_function_code_t, uint8_t, void*)")
        def _task_start(task_type, fc, seq, ctx):
            pass

        @ffi.callback("void(dnp3_task_type_t, dnp3_function_code_t, uint8_t, void*)")
        def _task_success(task_type, fc, seq, ctx):
            with self._lock:
                self.last_task_type = int(task_type)
                self.last_success_task_type = int(task_type)

        @ffi.callback("void(dnp3_task_type_t, dnp3_task_error_t, void*)")
        def _task_fail(task_type, error, ctx):
            with self._lock:
                self.last_task_type = int(task_type)
                error_code = int(error)
                self.last_error = error_code
                try:
                    self.last_task_error = TaskErrorCode(error_code)
                except ValueError:
                    self.last_task_error = None
                self.failure_count += 1
                if error_code == TaskErrorCode.IIN_ERROR:
                    self.iin_error_count += 1

        @ffi.callback("void(bool, uint8_t, void*)")
        def _unsolicited_response(is_duplicate, seq, ctx):
            pass

        self._task_start = _task_start
        self._task_success = _task_success
        self._task_fail = _task_fail
        self._unsolicited_response = _unsolicited_response

    @property
    def last_error_was_iin(self) -> bool:
        """True if the last task failure was caused by IIN2 error bits."""
        return self.last_task_error == TaskErrorCode.IIN_ERROR

    def as_ffi(self):
        return ffi.new("dnp3_association_information_t*", {
            "task_start": self._task_start,
            "task_success": self._task_success,
            "task_fail": self._task_fail,
            "unsolicited_response": self._unsolicited_response,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class TaskCallback:
    """Generic callback for async operations (read, command, restart, etc.)."""

    def __init__(self):
        self.success = False
        self.result = None
        self.error = None
        self._event = threading.Event()

    def wait(self, timeout=30.0) -> bool:
        """Wait for the callback to fire. Returns True if it completed."""
        return self._event.wait(timeout)

    def _signal_success(self, result=None):
        self.success = True
        self.result = result
        self._event.set()

    def _signal_failure(self, error):
        self.success = False
        self.error = error
        self._event.set()


class ReadTaskCallback(TaskCallback):
    """Callback for read operations.

    On failure, ``self.error`` contains the raw error code and
    ``self.read_error`` contains a ``ReadError`` enum for named access.
    ``self.is_iin_error`` is True when the outstation rejected via IIN2.
    """

    def __init__(self):
        super().__init__()
        self.read_error = None  # type: Optional[ReadError]

        @ffi.callback("void(dnp3_nothing_t, void*)")
        def _on_complete(nothing, ctx):
            self._signal_success()

        @ffi.callback("void(dnp3_read_error_t, void*)")
        def _on_failure(error, ctx):
            error_code = int(error)
            try:
                self.read_error = ReadError(error_code)
            except ValueError:
                self.read_error = None
            self._signal_failure(error_code)

        self._on_complete = _on_complete
        self._on_failure = _on_failure

    @property
    def is_iin_error(self) -> bool:
        """True if the read was rejected by IIN2 error bits."""
        return self.read_error == ReadError.IIN_ERROR

    def as_ffi(self):
        return ffi.new("dnp3_read_task_callback_t*", {
            "on_complete": self._on_complete,
            "on_failure": self._on_failure,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class CommandTaskCallback(TaskCallback):
    """Callback for command (operate/select) operations."""

    def __init__(self):
        super().__init__()

        @ffi.callback("void(dnp3_nothing_t, void*)")
        def _on_complete(nothing, ctx):
            self._signal_success()

        @ffi.callback("void(dnp3_command_error_t, void*)")
        def _on_failure(error, ctx):
            self._signal_failure(int(error))

        self._on_complete = _on_complete
        self._on_failure = _on_failure

    def as_ffi(self):
        return ffi.new("dnp3_command_task_callback_t*", {
            "on_complete": self._on_complete,
            "on_failure": self._on_failure,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class TimeSyncTaskCallback(TaskCallback):
    """Callback for time sync operations."""

    def __init__(self):
        super().__init__()

        @ffi.callback("void(dnp3_nothing_t, void*)")
        def _on_complete(nothing, ctx):
            self._signal_success()

        @ffi.callback("void(dnp3_time_sync_error_t, void*)")
        def _on_failure(error, ctx):
            self._signal_failure(int(error))

        self._on_complete = _on_complete
        self._on_failure = _on_failure

    def as_ffi(self):
        return ffi.new("dnp3_time_sync_task_callback_t*", {
            "on_complete": self._on_complete,
            "on_failure": self._on_failure,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class RestartTaskCallback(TaskCallback):
    """Callback for restart operations — returns delay in ms."""

    def __init__(self):
        super().__init__()

        @ffi.callback("void(uint64_t, void*)")
        def _on_complete(delay, ctx):
            self._signal_success(delay)

        @ffi.callback("void(dnp3_restart_error_t, void*)")
        def _on_failure(error, ctx):
            self._signal_failure(int(error))

        self._on_complete = _on_complete
        self._on_failure = _on_failure

    def as_ffi(self):
        return ffi.new("dnp3_restart_task_callback_t*", {
            "on_complete": self._on_complete,
            "on_failure": self._on_failure,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class EmptyResponseCallback(TaskCallback):
    """Callback for operations that expect empty responses."""

    def __init__(self):
        super().__init__()

        @ffi.callback("void(dnp3_nothing_t, void*)")
        def _on_complete(nothing, ctx):
            self._signal_success()

        @ffi.callback("void(dnp3_empty_response_error_t, void*)")
        def _on_failure(error, ctx):
            self._signal_failure(int(error))

        self._on_complete = _on_complete
        self._on_failure = _on_failure

    def as_ffi(self):
        return ffi.new("dnp3_empty_response_callback_t*", {
            "on_complete": self._on_complete,
            "on_failure": self._on_failure,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]


class LinkStatusCallback(TaskCallback):
    """Callback for link status check."""

    def __init__(self):
        super().__init__()

        @ffi.callback("void(dnp3_nothing_t, void*)")
        def _on_complete(nothing, ctx):
            self._signal_success()

        @ffi.callback("void(dnp3_link_status_error_t, void*)")
        def _on_failure(error, ctx):
            self._signal_failure(int(error))

        self._on_complete = _on_complete
        self._on_failure = _on_failure

    def as_ffi(self):
        return ffi.new("dnp3_link_status_callback_t*", {
            "on_complete": self._on_complete,
            "on_failure": self._on_failure,
            "on_destroy": ffi.NULL,
            "ctx": ffi.NULL,
        })[0]
