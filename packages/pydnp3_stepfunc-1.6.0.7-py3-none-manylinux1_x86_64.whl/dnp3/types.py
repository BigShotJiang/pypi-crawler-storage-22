"""
DNP3 data types, enums, and flags.

Provides Pythonic wrappers around the C FFI enum and struct types.
"""

from enum import IntEnum
from dataclasses import dataclass
from typing import Optional
import time as _time

from ._ffi import ffi, lib


# --- Enums ---

class ParamError(IntEnum):
    OK = 0
    INVALID_TIMEOUT = 1
    NULL_PARAMETER = 2
    STRING_NOT_UTF8 = 3
    NO_SUPPORT = 4
    ASSOCIATION_DOES_NOT_EXIST = 5
    ASSOCIATION_DUPLICATE_ADDRESS = 6
    INVALID_SOCKET_ADDRESS = 7
    INVALID_DNP3_ADDRESS = 8
    INVALID_BUFFER_SIZE = 9
    ADDRESS_FILTER_CONFLICT = 10
    SERVER_ALREADY_STARTED = 11
    SERVER_BIND_ERROR = 12
    MASTER_ALREADY_SHUTDOWN = 13
    RUNTIME_CREATION_FAILURE = 14
    RUNTIME_DESTROYED = 15
    RUNTIME_CANNOT_BLOCK_WITHIN_ASYNC = 16
    LOGGING_ALREADY_CONFIGURED = 17
    POINT_DOES_NOT_EXIST = 18
    INVALID_PEER_CERTIFICATE = 19
    INVALID_LOCAL_CERTIFICATE = 20
    INVALID_PRIVATE_KEY = 21
    INVALID_DNS_NAME = 22
    OTHER_TLS_ERROR = 23
    WRONG_CHANNEL_TYPE = 24
    CONSUMED = 25


class CommandStatus(IntEnum):
    SUCCESS = 0
    TIMEOUT = 1
    NO_SELECT = 2
    FORMAT_ERROR = 3
    NOT_SUPPORTED = 4
    ALREADY_ACTIVE = 5
    HARDWARE_ERROR = 6
    LOCAL = 7
    TOO_MANY_OPS = 8
    NOT_AUTHORIZED = 9
    AUTOMATION_INHIBIT = 10
    PROCESSING_LIMITED = 11
    OUT_OF_RANGE = 12
    DOWNSTREAM_LOCAL = 13
    ALREADY_COMPLETE = 14
    BLOCKED = 15
    CANCELED = 16
    BLOCKED_OTHER_MASTER = 17
    DOWNSTREAM_FAIL = 18
    NON_PARTICIPATING = 19
    UNKNOWN = 20


class TripCloseCode(IntEnum):
    NUL = 0
    CLOSE = 1
    TRIP = 2
    RESERVED = 3


class OpType(IntEnum):
    NUL = 0
    PULSE_ON = 1
    PULSE_OFF = 2
    LATCH_ON = 3
    LATCH_OFF = 4


class DoubleBit(IntEnum):
    INTERMEDIATE = 0
    DETERMINED_OFF = 1
    DETERMINED_ON = 2
    INDETERMINATE = 3


class TimeQuality(IntEnum):
    SYNCHRONIZED = 0
    UNSYNCHRONIZED = 1
    INVALID = 2


class CommandMode(IntEnum):
    DIRECT_OPERATE = 0
    SELECT_BEFORE_OPERATE = 1


class TimeSyncMode(IntEnum):
    LAN = 0
    NON_LAN = 1


class LinkErrorMode(IntEnum):
    DISCARD = 0
    CLOSE = 1


class AppDecodeLevel(IntEnum):
    NOTHING = 0
    HEADER = 1
    OBJECT_HEADERS = 2
    OBJECT_VALUES = 3


class TransportDecodeLevel(IntEnum):
    NOTHING = 0
    HEADER = 1
    PAYLOAD = 2


class LinkDecodeLevel(IntEnum):
    NOTHING = 0
    HEADER = 1
    PAYLOAD = 2


class PhysDecodeLevel(IntEnum):
    NOTHING = 0
    LENGTH = 1
    DATA = 2


class FunctionCode(IntEnum):
    CONFIRM = 0
    READ = 1
    WRITE = 2
    SELECT = 3
    OPERATE = 4
    DIRECT_OPERATE = 5
    DIRECT_OPERATE_NO_ACK = 6
    IMMEDIATE_FREEZE = 7
    IMMEDIATE_FREEZE_NO_ACK = 8
    FREEZE_AND_CLEAR = 9
    FREEZE_AND_CLEAR_NO_ACK = 10
    FREEZE_AT_TIME = 11
    FREEZE_AT_TIME_NO_ACK = 12
    COLD_RESTART = 13
    WARM_RESTART = 14
    INITIALIZE_DATA = 15
    INITIALIZE_APPLICATION = 16
    START_APPLICATION = 17
    STOP_APPLICATION = 18
    SAVE_CONFIGURATION = 19
    ENABLE_UNSOLICITED = 20
    DISABLE_UNSOLICITED = 21
    ASSIGN_CLASS = 22
    DELAY_MEASURE = 23
    RECORD_CURRENT_TIME = 24
    OPEN_FILE = 25
    CLOSE_FILE = 26
    DELETE_FILE = 27
    GET_FILE_INFO = 28
    AUTHENTICATE_FILE = 29
    ABORT_FILE = 30
    RESPONSE = 129
    UNSOLICITED_RESPONSE = 130


class ClientState(IntEnum):
    DISABLED = 0
    CONNECTING = 1
    CONNECTED = 2
    WAIT_AFTER_FAILED_CONNECT = 3
    WAIT_AFTER_DISCONNECT = 4
    SHUTDOWN = 5


class ReadType(IntEnum):
    STARTUP_INTEGRITY = 0
    UNSOLICITED = 1
    SINGLE_POLL = 2
    PERIODIC_POLL = 3


class TaskType(IntEnum):
    USER_READ = 0
    PERIODIC_POLL = 1
    STARTUP_INTEGRITY = 2
    AUTO_EVENT_SCAN = 3
    COMMAND = 4
    CLEAR_RESTART_BIT = 5
    ENABLE_UNSOLICITED = 6
    DISABLE_UNSOLICITED = 7
    TIME_SYNC = 8
    RESTART = 9
    FILE_READ = 10
    GET_FILE_INFO = 11
    READ_DIRECTORY = 12
    FILE_AUTH = 13
    FILE_OPEN = 14
    FILE_WRITE = 15
    FILE_CLOSE = 16
    GENERIC_EMPTY_RESPONSE = 17
    WRITE_DEAD_BANDS = 18
    LINK_STATUS = 19


class ReadError(IntEnum):
    """Error codes from DNP3 read operations.

    Maps to dnp3_read_error_t in the C FFI. IIN_ERROR indicates
    the outstation set IIN2 error bits (object_unknown, no_func_code_support, etc.).
    """
    OK = 0
    TOO_MANY_REQUESTS = 1
    IIN_ERROR = 2
    BAD_RESPONSE = 3
    RESPONSE_TIMEOUT = 4
    WRITE_ERROR = 5
    NO_CONNECTION = 6
    SHUTDOWN = 7
    ASSOCIATION_REMOVED = 8
    BAD_ENCODING = 9

    @property
    def description(self) -> str:
        _descriptions = {
            0: "success",
            1: "too many user requests queued",
            2: "outstation IIN2 error (object_unknown, no_func_code_support, parameter_error, etc.)",
            3: "malformed response",
            4: "response timeout",
            5: "write/serialization error",
            6: "no connection",
            7: "master shutdown",
            8: "association removed",
            9: "bad encoding",
        }
        return _descriptions.get(self.value, f"unknown({self.value})")


class TaskErrorCode(IntEnum):
    """Error codes from DNP3 task failures reported via AssociationInformation.

    Maps to dnp3_task_error_t in the C FFI.
    """
    TOO_MANY_REQUESTS = 0
    IIN_ERROR = 1
    BAD_RESPONSE = 2
    RESPONSE_TIMEOUT = 3
    WRITE_ERROR = 4
    NO_CONNECTION = 5
    SHUTDOWN = 6
    ASSOCIATION_REMOVED = 7
    BAD_ENCODING = 8

    @property
    def description(self) -> str:
        _descriptions = {
            0: "too many user requests queued",
            1: "outstation IIN2 error (object_unknown, no_func_code_support, parameter_error, etc.)",
            2: "malformed response",
            3: "response timeout",
            4: "write/serialization error",
            5: "no connection",
            6: "master shutdown",
            7: "association removed",
            8: "bad encoding",
        }
        return _descriptions.get(self.value, f"unknown({self.value})")


class AutoTimeSync(IntEnum):
    NONE = 0
    LAN = 1
    NON_LAN = 2


class MinTlsVersion(IntEnum):
    V12 = 0
    V13 = 1


class CertificateMode(IntEnum):
    AUTHORITY_BASED = 0
    SELF_SIGNED = 1


def _build_variation_enum():
    """Build Variation enum dynamically from C library constants."""
    members = {}
    for attr_name in dir(lib):
        if attr_name.startswith("DNP3_VARIATION_GROUP"):
            name = attr_name.replace("DNP3_VARIATION_", "")
            members[name] = getattr(lib, attr_name)
    return IntEnum("Variation", members)


Variation = _build_variation_enum()


# Convenience group/variation mappings
BINARY_INPUT = Variation["GROUP1_VAR0"]
BINARY_OUTPUT = Variation["GROUP10_VAR0"]
ANALOG_INPUT = Variation["GROUP30_VAR0"]
ANALOG_OUTPUT = Variation["GROUP40_VAR0"]
COUNTER = Variation["GROUP20_VAR0"]
FROZEN_COUNTER = Variation["GROUP21_VAR0"]


# --- Data classes ---

@dataclass
class Flags:
    value: int

    @property
    def online(self) -> bool:
        return bool(self.value & 0x01)

    @property
    def restart(self) -> bool:
        return bool(self.value & 0x02)

    @property
    def comm_lost(self) -> bool:
        return bool(self.value & 0x04)

    @property
    def remote_forced(self) -> bool:
        return bool(self.value & 0x08)

    @property
    def local_forced(self) -> bool:
        return bool(self.value & 0x10)

    def to_ffi(self):
        return {"value": self.value}


@dataclass
class Timestamp:
    value: int  # milliseconds since UNIX epoch
    quality: TimeQuality

    @classmethod
    def now(cls) -> "Timestamp":
        return cls(int(_time.time() * 1000), TimeQuality.SYNCHRONIZED)

    @classmethod
    def invalid(cls) -> "Timestamp":
        return cls(0, TimeQuality.INVALID)

    def to_ffi(self):
        return {"value": self.value, "quality": self.quality.value}


@dataclass
class BinaryInput:
    index: int
    value: bool
    flags: Flags
    time: Timestamp

    @classmethod
    def from_ffi(cls, c_obj) -> "BinaryInput":
        return cls(
            index=c_obj.index,
            value=bool(c_obj.value),
            flags=Flags(c_obj.flags.value),
            time=Timestamp(c_obj.time.value, TimeQuality(c_obj.time.quality)),
        )


@dataclass
class DoubleBitBinaryInput:
    index: int
    value: DoubleBit
    flags: Flags
    time: Timestamp

    @classmethod
    def from_ffi(cls, c_obj) -> "DoubleBitBinaryInput":
        return cls(
            index=c_obj.index,
            value=DoubleBit(c_obj.value),
            flags=Flags(c_obj.flags.value),
            time=Timestamp(c_obj.time.value, TimeQuality(c_obj.time.quality)),
        )


@dataclass
class BinaryOutputStatus:
    index: int
    value: bool
    flags: Flags
    time: Timestamp

    @classmethod
    def from_ffi(cls, c_obj) -> "BinaryOutputStatus":
        return cls(
            index=c_obj.index,
            value=bool(c_obj.value),
            flags=Flags(c_obj.flags.value),
            time=Timestamp(c_obj.time.value, TimeQuality(c_obj.time.quality)),
        )


@dataclass
class Counter:
    index: int
    value: int
    flags: Flags
    time: Timestamp

    @classmethod
    def from_ffi(cls, c_obj) -> "Counter":
        return cls(
            index=c_obj.index,
            value=c_obj.value,
            flags=Flags(c_obj.flags.value),
            time=Timestamp(c_obj.time.value, TimeQuality(c_obj.time.quality)),
        )


@dataclass
class FrozenCounter:
    index: int
    value: int
    flags: Flags
    time: Timestamp

    @classmethod
    def from_ffi(cls, c_obj) -> "FrozenCounter":
        return cls(
            index=c_obj.index,
            value=c_obj.value,
            flags=Flags(c_obj.flags.value),
            time=Timestamp(c_obj.time.value, TimeQuality(c_obj.time.quality)),
        )


@dataclass
class AnalogInput:
    index: int
    value: float
    flags: Flags
    time: Timestamp

    @classmethod
    def from_ffi(cls, c_obj) -> "AnalogInput":
        return cls(
            index=c_obj.index,
            value=c_obj.value,
            flags=Flags(c_obj.flags.value),
            time=Timestamp(c_obj.time.value, TimeQuality(c_obj.time.quality)),
        )


@dataclass
class AnalogOutputStatus:
    index: int
    value: float
    flags: Flags
    time: Timestamp

    @classmethod
    def from_ffi(cls, c_obj) -> "AnalogOutputStatus":
        return cls(
            index=c_obj.index,
            value=c_obj.value,
            flags=Flags(c_obj.flags.value),
            time=Timestamp(c_obj.time.value, TimeQuality(c_obj.time.quality)),
        )


@dataclass
class ControlCode:
    tcc: TripCloseCode = TripCloseCode.NUL
    clear: bool = False
    op_type: OpType = OpType.LATCH_ON

    def to_ffi(self):
        return {
            "tcc": self.tcc.value,
            "clear": self.clear,
            "queue": False,
            "op_type": self.op_type.value,
        }


@dataclass
class Group12Var1:
    """Control Relay Output Block (CROB)."""
    code: ControlCode
    count: int = 1
    on_time: int = 1000
    off_time: int = 1000

    def to_ffi(self):
        return {
            "code": self.code.to_ffi(),
            "count": self.count,
            "on_time": self.on_time,
            "off_time": self.off_time,
        }


@dataclass
class DecodeLevel:
    application: AppDecodeLevel = AppDecodeLevel.NOTHING
    transport: TransportDecodeLevel = TransportDecodeLevel.NOTHING
    link: LinkDecodeLevel = LinkDecodeLevel.NOTHING
    physical: PhysDecodeLevel = PhysDecodeLevel.NOTHING

    def to_ffi(self):
        return {
            "application": self.application.value,
            "transport": self.transport.value,
            "link": self.link.value,
            "physical": self.physical.value,
        }


@dataclass
class ConnectStrategy:
    min_connect_delay: int = 1000  # ms
    max_connect_delay: int = 10000  # ms
    reconnect_delay: int = 1000  # ms

    def to_ffi(self):
        return {
            "min_connect_delay": self.min_connect_delay,
            "max_connect_delay": self.max_connect_delay,
            "reconnect_delay": self.reconnect_delay,
        }


@dataclass
class IIN1:
    broadcast: bool = False
    class_1_events: bool = False
    class_2_events: bool = False
    class_3_events: bool = False
    need_time: bool = False
    local_control: bool = False
    device_trouble: bool = False
    device_restart: bool = False


@dataclass
class IIN2:
    no_func_code_support: bool = False
    object_unknown: bool = False
    parameter_error: bool = False
    event_buffer_overflow: bool = False
    already_executing: bool = False
    config_corrupt: bool = False


@dataclass
class IIN:
    iin1: IIN1
    iin2: IIN2

    @classmethod
    def from_ffi(cls, c_iin):
        return cls(
            iin1=IIN1(
                broadcast=bool(c_iin.iin1.broadcast),
                class_1_events=bool(c_iin.iin1.class_1_events),
                class_2_events=bool(c_iin.iin1.class_2_events),
                class_3_events=bool(c_iin.iin1.class_3_events),
                need_time=bool(c_iin.iin1.need_time),
                local_control=bool(c_iin.iin1.local_control),
                device_trouble=bool(c_iin.iin1.device_trouble),
                device_restart=bool(c_iin.iin1.device_restart),
            ),
            iin2=IIN2(
                no_func_code_support=bool(c_iin.iin2.no_func_code_support),
                object_unknown=bool(c_iin.iin2.object_unknown),
                parameter_error=bool(c_iin.iin2.parameter_error),
                event_buffer_overflow=bool(c_iin.iin2.event_buffer_overflow),
                already_executing=bool(c_iin.iin2.already_executing),
                config_corrupt=bool(c_iin.iin2.config_corrupt),
            ),
        )


# --- Result types for operations that can fail with error details ---


class ReadResult:
    """Result of a DNP3 read operation with full error detail.

    Boolean-truthy for backward compatibility: ``if result:`` works.
    On failure, provides the error code, name, and description.

    Attributes:
        success: True if the read completed without error.
        error: ReadError enum value on failure, None on success.
        error_name: Human-readable error name (e.g., "iin_error").
        error_description: Longer description of the error.

    Example::

        result = channel.read(assoc, variation=Variation.GROUP50_VAR1)
        if not result:
            print(f"Read failed: {result.error_name} - {result.error_description}")
            if result.is_iin_error:
                print("Outstation rejected request via IIN2 error bits")
    """

    __slots__ = ("success", "error", "_error_code")

    def __init__(self, success: bool, error_code=None):
        self.success = success
        self._error_code = error_code
        if error_code is not None:
            try:
                self.error = ReadError(error_code)
            except ValueError:
                self.error = error_code
        else:
            self.error = None

    def __bool__(self):
        return self.success

    def __repr__(self):
        if self.success:
            return "ReadResult(success=True)"
        return f"ReadResult(success=False, error={self.error_name})"

    @property
    def error_name(self) -> Optional[str]:
        if self.error is None:
            return None
        if isinstance(self.error, ReadError):
            return self.error.name.lower()
        return f"unknown({self.error})"

    @property
    def error_description(self) -> Optional[str]:
        if self.error is None:
            return None
        if isinstance(self.error, ReadError):
            return self.error.description
        return f"unknown error code {self.error}"

    @property
    def is_iin_error(self) -> bool:
        """True if the outstation rejected the request via IIN2 error bits."""
        return isinstance(self.error, ReadError) and self.error == ReadError.IIN_ERROR


class FileResult:
    """Result of a DNP3 file operation with full error detail.

    Boolean-truthy for backward compatibility: ``if result:`` works.
    When truthy, ``result.value`` contains the operation's return value.
    On failure, provides the error code and description.

    Attributes:
        success: True if the operation completed without error.
        value: The operation's return value on success (dict, list, bytes, etc.).
        error: FileError enum value on failure, None on success.
        error_name: Human-readable error name.
        error_description: Longer description of the error.

    Example::

        result = channel.get_file_info(assoc, ".")
        if result:
            print(f"File info: {result.value}")
        else:
            print(f"Failed: {result.error_name} - {result.error_description}")
    """

    # Error names matching the C FFI dnp3_file_error_t enum
    _FILE_ERROR_NAMES = {
        0: ("ok", "success"),
        1: ("bad_status", "outstation returned an unrecognized file status code"),
        2: ("no_permission", "outstation indicated no permission to access file"),
        3: ("bad_block_num", "unexpected block number in file transfer"),
        4: ("abort_by_user", "file transfer aborted by user"),
        5: ("max_length_exceeded", "file exceeded maximum allowed length"),
        6: ("wrong_handle", "file handle mismatch"),
        # Expanded FileStatus variants
        7: ("status_permission_denied", "permission denied (improper auth key, username, or password)"),
        8: ("status_invalid_mode", "unsupported or unknown file operation mode"),
        9: ("status_file_not_found", "requested file does not exist"),
        10: ("status_file_locked", "requested file is already in use"),
        11: ("status_too_many_open", "too many files open on outstation"),
        12: ("status_invalid_handle", "no file opened with the specified handle"),
        13: ("status_write_block_size", "outstation unable to negotiate write block size"),
        14: ("status_comm_lost", "communications lost with end device where file resides"),
        15: ("status_cannot_abort", "abort request unsuccessful"),
        16: ("status_not_opened", "file handle does not reference an opened file"),
        17: ("status_handle_expired", "file closed due to inactivity timeout"),
        18: ("status_buffer_overrun", "too much file data for outstation to process"),
        19: ("status_fatal", "fatal file processing error, no further activity possible"),
        20: ("status_block_seq", "block number sequence mismatch"),
        21: ("status_undefined", "undefined file error on outstation"),
        # Task errors
        22: ("too_many_requests", "too many user requests queued"),
        23: ("iin_error", "outstation IIN2 error (object_unknown, no_func_code_support, etc.)"),
        24: ("bad_response", "malformed response"),
        25: ("response_timeout", "response timeout"),
        26: ("write_error", "write/serialization error"),
        27: ("no_connection", "no connection"),
        28: ("shutdown", "master shutdown"),
        29: ("association_removed", "association removed"),
        30: ("bad_encoding", "bad encoding"),
    }

    __slots__ = ("success", "value", "error", "_error_code")

    def __init__(self, success: bool, value=None, error_code=None):
        self.success = success
        self.value = value
        self._error_code = error_code
        self.error = error_code

    def __bool__(self):
        return self.success

    def __repr__(self):
        if self.success:
            return f"FileResult(success=True, value={self.value!r})"
        return f"FileResult(success=False, error={self.error_name})"

    @property
    def error_name(self) -> Optional[str]:
        if self.error is None:
            return None
        info = self._FILE_ERROR_NAMES.get(self.error)
        return info[0] if info else f"unknown({self.error})"

    @property
    def error_description(self) -> Optional[str]:
        if self.error is None:
            return None
        info = self._FILE_ERROR_NAMES.get(self.error)
        return info[1] if info else f"unknown error code {self.error}"

    @property
    def is_iin_error(self) -> bool:
        """True if the outstation rejected the request via IIN2 error bits."""
        return self.error == 23  # IIN_ERROR


# --- Utility data types ---


class OctetStringValue:
    """Wraps a dnp3_octet_string_value_t* for building octet string point values.

    Used when updating octet string points in the outstation database::

        osv = OctetStringValue(b"hello")
        db.update_octet_string(0, osv)
    """

    def __init__(self, data: bytes = b""):
        """Create an octet string value.

        Args:
            data: Initial byte data to populate the value with.
        """
        self._ptr = lib.dnp3_octet_string_value_create()
        for b in data:
            lib.dnp3_octet_string_value_add(self._ptr, b)

    def add(self, byte_val: int):
        """Add a single byte to the value.

        Args:
            byte_val: Byte value (0-255).
        """
        lib.dnp3_octet_string_value_add(self._ptr, byte_val)

    def destroy(self):
        """Destroy the value and free memory."""
        if self._ptr is not None:
            lib.dnp3_octet_string_value_destroy(self._ptr)
            self._ptr = None

    def __del__(self):
        self.destroy()


class ByteCollection:
    """Wraps a dnp3_byte_collection_t* for building byte arrays.

    Used for write_file_block data and similar operations::

        bc = ByteCollection(b"file data here")
    """

    def __init__(self, data: bytes = b""):
        """Create a byte collection.

        Args:
            data: Initial byte data.
        """
        self._ptr = lib.dnp3_byte_collection_create(len(data))
        for b in data:
            lib.dnp3_byte_collection_add(self._ptr, b)

    def add(self, byte_val: int):
        """Add a single byte.

        Args:
            byte_val: Byte value (0-255).
        """
        lib.dnp3_byte_collection_add(self._ptr, byte_val)

    def destroy(self):
        """Destroy the collection and free memory."""
        if self._ptr is not None:
            lib.dnp3_byte_collection_destroy(self._ptr)
            self._ptr = None

    def __del__(self):
        self.destroy()


# --- Additional data classes for read handler iterators ---


@dataclass
class FrozenAnalogInput:
    """Frozen analog input value from a read operation."""
    index: int
    value: float
    flags: Flags
    time: Timestamp

    @classmethod
    def from_ffi(cls, c_obj) -> "FrozenAnalogInput":
        return cls(
            index=c_obj.index,
            value=c_obj.value,
            flags=Flags(c_obj.flags.value),
            time=Timestamp(c_obj.time.value, TimeQuality(c_obj.time.quality)),
        )


@dataclass
class AnalogOutputCommandEvent:
    """Analog output command event from a read operation."""
    index: int
    status: int
    commanded_value: float
    time: Timestamp

    @classmethod
    def from_ffi(cls, c_obj) -> "AnalogOutputCommandEvent":
        return cls(
            index=c_obj.index,
            status=int(c_obj.status),
            commanded_value=c_obj.commanded_value,
            time=Timestamp(c_obj.time.value, TimeQuality(c_obj.time.quality)),
        )


@dataclass
class BinaryOutputCommandEvent:
    """Binary output command event from a read operation."""
    index: int
    status: int
    commanded_state: bool
    time: Timestamp

    @classmethod
    def from_ffi(cls, c_obj) -> "BinaryOutputCommandEvent":
        return cls(
            index=c_obj.index,
            status=int(c_obj.status),
            commanded_state=bool(c_obj.commanded_state),
            time=Timestamp(c_obj.time.value, TimeQuality(c_obj.time.quality)),
        )


@dataclass
class AttributeItem:
    """Device attribute item from attribute iteration."""
    variation: int
    is_writable: bool

    @classmethod
    def from_ffi(cls, c_obj) -> "AttributeItem":
        return cls(
            variation=c_obj.variation,
            is_writable=bool(c_obj.properties.is_writable),
        )


@dataclass
class UnsignedInteger:
    """Unsigned integer value from a read operation."""
    index: int
    value: int

    @classmethod
    def from_ffi(cls, c_obj) -> "UnsignedInteger":
        return cls(
            index=c_obj.index,
            value=c_obj.value,
        )


# --- Library-level utility functions ---


def version() -> str:
    """Return the version string of the underlying dnp3 C library."""
    return ffi.string(lib.dnp3_version()).decode()


def parse_zero_length_strings(enable: bool):
    """Toggle whether zero-length strings are parsed by the library.

    Args:
        enable: True to parse zero-length strings, False to ignore them.
    """
    lib.dnp3_parse_zero_length_strings(enable)


def disable_client_tcp_no_delay():
    """Disable TCP_NODELAY on client sockets (enables Nagle's algorithm)."""
    lib.dnp3_disable_client_tcp_no_delay()


def disable_server_tcp_no_delay():
    """Disable TCP_NODELAY on server sockets (enables Nagle's algorithm)."""
    lib.dnp3_disable_server_tcp_no_delay()
