"""Browser domain implementation."""
