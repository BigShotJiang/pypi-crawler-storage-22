"""Async integration tests for hooks."""
