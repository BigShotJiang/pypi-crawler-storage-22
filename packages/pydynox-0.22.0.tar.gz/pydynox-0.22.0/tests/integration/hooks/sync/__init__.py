"""Sync integration tests for hooks."""
