"""Async integration tests for indexes."""
