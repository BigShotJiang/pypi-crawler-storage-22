"""Sync integration tests for indexes."""
