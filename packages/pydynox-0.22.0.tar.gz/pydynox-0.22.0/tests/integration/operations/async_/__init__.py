"""Async integration tests for operations."""
