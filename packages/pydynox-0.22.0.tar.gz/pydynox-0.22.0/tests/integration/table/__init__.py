"""Table operations integration tests."""
