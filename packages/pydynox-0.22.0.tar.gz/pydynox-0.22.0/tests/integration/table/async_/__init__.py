"""Async integration tests for table operations."""
