"""Sync integration tests for table operations."""
