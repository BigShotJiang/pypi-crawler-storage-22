"""Async integration tests for encryption."""
