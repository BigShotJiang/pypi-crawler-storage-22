"""Integration tests for GSI support."""
