from setuptools import setup, Extension
from Cython.Build import cythonize

import glob
import os
import subprocess
import sys

# Apply patches to enet submodule if needed
patches_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "patches")
enet_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "enet")
if os.path.isdir(patches_dir) and os.path.isdir(enet_dir):
    for patch_file in sorted(glob.glob(os.path.join(patches_dir, "*.patch"))):
        try:
            # Check if patch is already applied (reverse-apply dry run succeeds)
            subprocess.check_call(
                ["git", "apply", "--reverse", "--check", patch_file],
                cwd=enet_dir, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except (subprocess.CalledProcessError, FileNotFoundError):
            # Patch not yet applied, apply it
            try:
                subprocess.check_call(
                    ["git", "apply", patch_file],
                    cwd=enet_dir)
                print(f"pyenet: Applied patch {os.path.basename(patch_file)}")
            except (subprocess.CalledProcessError, FileNotFoundError):
                print(f"pyenet: Warning: Failed to apply patch {os.path.basename(patch_file)}")

source_files = ["enet.pyx"]

_enet_files = glob.glob("enet/*.c")
source_files.extend(_enet_files)


define_macros = [('HAS_POLL', None), ('HAS_FCNTL', None),
                 ('HAS_MSGHDR_FLAGS', None), ('HAS_SOCKLEN_T', None)]

libraries = []
include_dirs = ["enet/include/"]
library_dirs = ["enet/"]

if sys.platform == 'win32':
    define_macros.extend([('WIN32', None)])
    libraries.extend(['Winmm', 'ws2_32'])

if sys.platform != 'darwin':
    define_macros.extend([('HAS_GETHOSTBYNAME_R', None),
                          ('HAS_GETHOSTBYADDR_R', None)])

# Optional DTLS support via OpenSSL
have_dtls = False

if os.environ.get('PYENET_DISABLE_DTLS') != '1':
    # Try pkg-config first
    try:
        cflags = subprocess.check_output(
            ['pkg-config', '--cflags', 'openssl'],
            text=True, stderr=subprocess.DEVNULL).strip()
        libs = subprocess.check_output(
            ['pkg-config', '--libs', 'openssl'],
            text=True, stderr=subprocess.DEVNULL).strip()
        for flag in cflags.split():
            if flag.startswith('-I'):
                include_dirs.append(flag[2:])
        for flag in libs.split():
            if flag.startswith('-l'):
                libraries.append(flag[2:])
            elif flag.startswith('-L'):
                library_dirs.append(flag[2:])
        have_dtls = True
    except (subprocess.CalledProcessError, FileNotFoundError):
        # Try common locations
        for prefix in ['/usr', '/usr/local', '/opt/homebrew']:
            ssl_header = os.path.join(prefix, 'include', 'openssl', 'ssl.h')
            if os.path.exists(ssl_header):
                include_dirs.append(os.path.join(prefix, 'include'))
                library_dirs.append(os.path.join(prefix, 'lib'))
                libraries.extend(['ssl', 'crypto'])
                have_dtls = True
                break

    if sys.platform == 'win32' and not have_dtls:
        # On Windows, try to find OpenSSL via common install paths
        for prefix in [r'C:\OpenSSL-Win64', r'C:\OpenSSL-Win32',
                       r'C:\Program Files\OpenSSL',
                       r'C:\Program Files\OpenSSL-Win64']:
            ssl_header = os.path.join(prefix, 'include', 'openssl', 'ssl.h')
            if os.path.exists(ssl_header):
                include_dirs.append(os.path.join(prefix, 'include'))
                # Search all possible lib directories
                lib_search_dirs = []
                lib_vc = os.path.join(prefix, 'lib', 'VC')
                if os.path.isdir(lib_vc):
                    for arch_dir in ['x64', 'x86', 'static']:
                        d = os.path.join(lib_vc, arch_dir)
                        if os.path.isdir(d):
                            lib_search_dirs.append(d)
                    lib_search_dirs.append(lib_vc)
                lib_search_dirs.append(os.path.join(prefix, 'lib'))
                # Find the actual lib names (libssl.lib or libssl-3-x64.lib etc.)
                ssl_lib_names = None
                for d in lib_search_dirs:
                    if os.path.exists(os.path.join(d, 'libssl.lib')):
                        ssl_lib_names = ['libssl', 'libcrypto']
                        break
                    # Shining Light builds use versioned names
                    for f in glob.glob(os.path.join(d, 'libssl*.lib')):
                        name = os.path.splitext(os.path.basename(f))[0]
                        crypto_name = name.replace('libssl', 'libcrypto')
                        if os.path.exists(os.path.join(d, crypto_name + '.lib')):
                            ssl_lib_names = [name, crypto_name]
                            break
                    if ssl_lib_names:
                        break
                if ssl_lib_names:
                    library_dirs.extend(lib_search_dirs)
                    libraries.extend(ssl_lib_names)
                    have_dtls = True
                    print(f"pyenet: Found OpenSSL libs: {ssl_lib_names}")
                break

if have_dtls:
    print("pyenet: OpenSSL found, building with DTLS support")
else:
    print("pyenet: OpenSSL not found, building without DTLS support")

ext_modules = cythonize(
    [Extension(
        "enet",
        sources=source_files,
        include_dirs=include_dirs,
        define_macros=define_macros,
        libraries=libraries,
        library_dirs=library_dirs)],
    compiler_directives={'language_level': 3},
    compile_time_env={'HAVE_DTLS': have_dtls},
)

from setuptools.command.build_ext import build_ext as _build_ext
import shutil

class build_ext(_build_ext):
    def run(self):
        super().run()
        # Copy enet.pyi alongside the built extension
        pyi_src = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'enet.pyi')
        if os.path.exists(pyi_src) and self.build_lib:
            shutil.copy2(pyi_src, self.build_lib)

setup(
    ext_modules=ext_modules,
    cmdclass={'build_ext': build_ext},
)
