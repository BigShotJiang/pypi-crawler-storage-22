"""
pyepias - EPİAŞ (Turkish Electricity Market) Data API Client

A Python library for accessing EPİAŞ transparency platform data.

Author: Hasan Çağrı Güngör
Email: iletisim@cagrigungor.com
"""

from .client import EpiasClient

__version__ = "0.1.2"
__author__ = "Hasan Çağrı Güngör"
__email__ = "iletisim@cagrigungor.com"

__all__ = ["EpiasClient"]
