# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as f:
    LONG_DESCRIPTION = f.read()

NAME = 'pyepias'
VERSION = '0.1.5'
DESCRIPTION = 'EPİAŞ (Turkish Electricity Market) transparency platform data API client'
LONG_DESCRIPTION_CONTENT_TYPE = 'text/markdown'
URL = 'https://www.cagrigungor.com'
AUTHOR = 'Hasan Çağrı Güngör'
AUTHOR_EMAIL = 'iletisim@cagrigungor.com'
LICENSE = 'MIT'
KEYWORDS = 'epias electricity energy market turkey data api'

setup(
    name=NAME,
    version=VERSION,
    description=DESCRIPTION,
    long_description=LONG_DESCRIPTION,
    long_description_content_type=LONG_DESCRIPTION_CONTENT_TYPE,
    url=URL,
    author=AUTHOR,
    author_email=AUTHOR_EMAIL,
    license=LICENSE,
    keywords=KEYWORDS,
    classifiers=[
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
    packages=find_packages(),
    install_requires=[
        'requests>=2.25.0',
        'pandas>=1.2.0',
    ],
    python_requires='>=3.7',
)
