#!/usr/bin/env python
# coding: utf-8
"""
Optimization Model based on solvers
"""

from pyepo.model import opt
try:
    from pyepo.model import grb
except ImportError:
    pass
try:
    from pyepo.model import copt
except ImportError:
    pass
try:
    from pyepo.model import omo
except ImportError:
    pass
try:
    from pyepo.model import mpax
except ImportError:
    pass
