# pyfastyaml

[![PyPI version](https://badge.fury.io/py/pyfastyaml.svg)](https://pypi.org/project/pyfastyaml/)

**pyfastyaml** — Fast YAML parser for Python with C++/SIMD backend. **100–300× faster** than PyYAML and ruamel.yaml. API compatible with PyYAML for typical config use cases (Kubernetes, Ansible, CI, Docker Compose).

## Features

- **High performance**: C++17 implementation with AVX2 SIMD on x86 — orders of magnitude faster than pure-Python parsers
- **PyYAML compatible API**: `loads(s)`, `load(fp)` — drop-in replacement for config loading
- **Types**: dict, list, str, int, float, bool, null, nested structures
- **Indentation**: 2-space (preferred), 4-space, tabs

## Installation

```bash
pip install pyfastyaml
```

Requires Python 3.10+ and a C++ compiler with C++17 support.

## Usage

```python
import pyfastyaml

# Parse string
data = pyfastyaml.loads("""
key: value
nested:
  inner: 42
items:
  - a
  - b
""")
# {'key': 'value', 'nested': {'inner': 42}, 'items': ['a', 'b']}

# Parse file (path or file-like object)
data = pyfastyaml.load("config.yaml")
```

API matches PyYAML for common cases:

```python
# Drop-in replacement
import pyfastyaml as yaml  # instead of import yaml
data = yaml.loads(yaml_string)
data = yaml.load("config.yaml")
```

## Benchmark

Parsing time (μs, lower is better):

| Size     | pyfastyaml | PyYAML | ruamel | pyfastyaml vs PyYAML |
|----------|----------|--------|--------|--------------------|
| Small (~200 B)   | ~2   | ~229 | ~377 | **~112× faster** |
| Medium (~1.5 KB) | ~7   | ~1,034 | ~1,777 | **~141× faster** |
| Large (~15 KB)   | ~66  | ~11,153 | ~19,040 | **~170× faster** |
| Realworld        | ~5   | ~841 | ~1,544 | **~161× faster** |

Run benchmarks:

```bash
pip install pytest-benchmark PyYAML ruamel.yaml
pytest tests/test_benchmark.py -v --benchmark-only
```

## PyYAML Compatibility

pyfastyaml produces the same result as `yaml.safe_load()` for block-style YAML typical of configs. Compatibility tests included in `tests/test_pyyaml_compat.py`.

## MVP Limitations

pyfastyaml targets **config-style YAML** (K8s, Ansible, CI, Docker Compose). Not supported:

- **Flow syntax**: `[a, b, c]`, `{a: 1, b: 2}` — use block style instead
- **Multiline strings**: `|` (literal), `>` (folded)
- **Anchors and aliases**: `&anchor`, `*alias`
- **Custom tags**
- **Multi-document** (`---`)

Supported: block mappings, block sequences, scalars, comments, quoted strings, 2/4-space and tab indentation.

## Development

```bash
pip install -e ".[dev]"
python setup.py build_ext --inplace
pytest tests/
```

Benchmark commands:

```bash
pytest tests/test_benchmark.py -v --benchmark-only
pytest tests/test_benchmark.py -v --benchmark-only --benchmark-autosave
pytest tests/test_benchmark.py -v --benchmark-only --benchmark-compare
```

## Publishing (maintainers)

```bash
pip install build twine
python -m build
python -m twine upload dist/*
```

## License

MIT
