"""
Fast YAML parser for Python with C++/SIMD backend.

This module provides a fast YAML parser implemented in C++ with SIMD optimizations.
API compatible with PyYAML for typical config use cases (Kubernetes, Ansible, CI, Docker Compose).
"""
from __future__ import annotations

import re
from typing import BinaryIO, TextIO, Union

try:
    from ._native import loads as _loads
except ImportError as e:
    raise ImportError(
        "pyfastyaml native extension not found. "
        "Make sure the package is properly installed."
    ) from e


def _get_version() -> str:
    try:
        from importlib.metadata import version
        return version("pyfastyaml")
    except Exception:
        pass
    try:
        from pathlib import Path
        path = Path(__file__).resolve().parents[1] / "pyproject.toml"
        if path.exists():
            m = re.search(r'version\s*=\s*"([^"]+)"', path.read_text(encoding="utf-8"))
            return m.group(1) if m else "0.0.0"
    except Exception:
        pass
    return "0.0.0"


__version__ = _get_version()

__all__ = ["loads", "load", "__version__"]


def loads(s: str) -> dict | list:
    """
    Parse a YAML string and return a dictionary or list.

    Args:
        s: The YAML string to parse

    Returns:
        dict or list: Parsed YAML data (root mapping or sequence)

    Raises:
        ValueError: If parsing fails

    Example:
        >>> import pyfastyaml
        >>> data = pyfastyaml.loads('key: value')
        >>> print(data)
        {'key': 'value'}
    """
    try:
        return _loads(s)
    except RuntimeError as e:
        raise ValueError(str(e)) from e


def load(fp: Union[str, BinaryIO, TextIO]) -> dict | list:
    """
    Parse a YAML file and return a dictionary or list.

    Args:
        fp: File path (str) or file-like object open for reading (text or binary).

    Returns:
        Parsed YAML data (dict or list).

    Raises:
        ValueError: If the content is not valid YAML.
        FileNotFoundError: If fp is a path and the file does not exist.
        OSError: If the file cannot be read.
    """
    if hasattr(fp, 'read'):
        content = fp.read()
        if isinstance(content, bytes):
            content = content.decode('utf-8')
        return loads(content)
    else:
        with open(fp, 'r', encoding='utf-8') as f:
            return loads(f.read())
