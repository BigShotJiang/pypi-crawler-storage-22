#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "fastyaml/yaml_parser.hpp"
#include <memory>
#include <string>

namespace py = pybind11;
using namespace fastyaml;

// Forward declaration
py::object yaml_value_to_python(const YamlValue& value);

// Convert C++ Mapping to Python dict
py::dict mapping_to_dict(const Mapping& mapping) {
    py::dict result;
    for (const auto& [key, value] : mapping.values) {
        result[py::str(key)] = yaml_value_to_python(value);
    }
    return result;
}

// Convert C++ YamlValue to Python object
py::object yaml_value_to_python(const YamlValue& value) {
    return std::visit([](auto&& arg) -> py::object {
        using T = std::decay_t<decltype(arg)>;

        if constexpr (std::is_same_v<T, Null>) {
            return py::none();
        } else if constexpr (std::is_same_v<T, Integer>) {
            return py::cast(arg);
        } else if constexpr (std::is_same_v<T, Float>) {
            return py::cast(arg);
        } else if constexpr (std::is_same_v<T, Boolean>) {
            return py::cast(arg);
        } else if constexpr (std::is_same_v<T, String>) {
            return py::cast(arg);
        } else if constexpr (std::is_same_v<T, MappingPtr>) {
            return mapping_to_dict(*arg);
        } else if constexpr (std::is_same_v<T, SequencePtr>) {
            py::list result;
            for (const auto& elem : arg->elements) {
                result.append(yaml_value_to_python(elem));
            }
            return result;
        }
    }, value);
}

// Python loads function
py::object loads(const std::string& yaml_string) {
    YamlParser parser;
    YamlValue result = parser.parse(yaml_string);

    if (parser.has_error()) {
        throw std::runtime_error("YAML parse error: " + parser.get_error());
    }

    return yaml_value_to_python(result);
}

PYBIND11_MODULE(_native, m) {
    m.doc() = "Fast YAML parser for Python with C++/SIMD backend";

    m.def("loads", &loads, R"pbdoc(
        Parse a YAML string and return a dictionary or list.

        Args:
            yaml_string: The YAML string to parse

        Returns:
            dict or list: Parsed YAML data (PyYAML compatible)

        Raises:
            RuntimeError: If parsing fails
    )pbdoc", py::arg("yaml_string"));

    m.attr("__version__") = "0.1.0";
}
