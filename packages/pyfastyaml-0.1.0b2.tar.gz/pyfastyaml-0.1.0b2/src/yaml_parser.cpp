#include "fastyaml/yaml_parser.hpp"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <limits>
#include <sstream>

#ifdef __AVX2__
#include <immintrin.h>
#endif

// Cross-platform count trailing zeros
#ifdef _MSC_VER
#include <intrin.h>
inline int ctz(unsigned int x) {
    unsigned long index;
    _BitScanForward(&index, x);
    return (int)index;
}
inline int ctz(unsigned long long x) {
    unsigned long index;
    _BitScanForward64(&index, x);
    return (int)index;
}
#else
inline int ctz(unsigned int x) {
    return __builtin_ctz(x);
}
inline int ctz(unsigned long long x) {
    return __builtin_ctzll(x);
}
#endif

namespace fastyaml {

namespace simd_utils {

inline bool is_whitespace(char c) {
    return c == ' ' || c == '\t' || c == '\r' || c == '\n';
}

inline bool is_whitespace_no_nl(char c) {
    return c == ' ' || c == '\t' || c == '\r';
}

#if defined(__AVX2__)
const char* skip_whitespace(const char* ptr, const char* end) {
    if (end - ptr < 32) {
        while (ptr < end && is_whitespace(*ptr)) ++ptr;
        return ptr;
    }
    const __m256i space = _mm256_set1_epi8(' ');
    const __m256i tab = _mm256_set1_epi8('\t');
    const __m256i cr = _mm256_set1_epi8('\r');
    const __m256i nl = _mm256_set1_epi8('\n');
    while (end - ptr >= 32) {
        __m256i chunk = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(ptr));
        __m256i combined = _mm256_or_si256(
            _mm256_or_si256(_mm256_cmpeq_epi8(chunk, space), _mm256_cmpeq_epi8(chunk, tab)),
            _mm256_or_si256(_mm256_cmpeq_epi8(chunk, cr), _mm256_cmpeq_epi8(chunk, nl)));
        unsigned int mask = static_cast<unsigned int>(_mm256_movemask_epi8(combined));
        if (mask != 0xFFFFFFFFU) {
            return ptr + ctz(~mask);
        }
        ptr += 32;
    }
    while (ptr < end && is_whitespace(*ptr)) ++ptr;
    return ptr;
}

const char* skip_whitespace_no_nl(const char* ptr, const char* end) {
    if (end - ptr < 32) {
        while (ptr < end && is_whitespace_no_nl(*ptr)) ++ptr;
        return ptr;
    }
    const __m256i space = _mm256_set1_epi8(' ');
    const __m256i tab = _mm256_set1_epi8('\t');
    const __m256i cr = _mm256_set1_epi8('\r');
    while (end - ptr >= 32) {
        __m256i chunk = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(ptr));
        __m256i combined = _mm256_or_si256(
            _mm256_or_si256(_mm256_cmpeq_epi8(chunk, space), _mm256_cmpeq_epi8(chunk, tab)),
            _mm256_cmpeq_epi8(chunk, cr));
        unsigned int mask = static_cast<unsigned int>(_mm256_movemask_epi8(combined));
        if (mask != 0xFFFFFFFFU) {
            return ptr + ctz(~mask);
        }
        ptr += 32;
    }
    while (ptr < end && is_whitespace_no_nl(*ptr)) ++ptr;
    return ptr;
}

const char* find_char_simd(const char* ptr, const char* end, char c) {
    if (end - ptr < 32) {
        while (ptr < end && *ptr != c) ++ptr;
        return ptr;
    }
    const __m256i target = _mm256_set1_epi8(c);
    while (end - ptr >= 32) {
        __m256i chunk = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(ptr));
        unsigned int mask = static_cast<unsigned int>(_mm256_movemask_epi8(_mm256_cmpeq_epi8(chunk, target)));
        if (mask != 0) return ptr + ctz(mask);
        ptr += 32;
    }
    while (ptr < end && *ptr != c) ++ptr;
    return ptr;
}
#else
const char* skip_whitespace(const char* ptr, const char* end) {
    while (ptr < end && is_whitespace(*ptr)) ++ptr;
    return ptr;
}
const char* skip_whitespace_no_nl(const char* ptr, const char* end) {
    while (ptr < end && is_whitespace_no_nl(*ptr)) ++ptr;
    return ptr;
}
const char* find_char_simd(const char* ptr, const char* end, char c) {
    while (ptr < end && *ptr != c) ++ptr;
    return ptr;
}
#endif

const char* find_char_in_line(const char* ptr, const char* end, char c) {
    const char* line_end = find_char_simd(ptr, end, '\n');
    return find_char_simd(ptr, line_end, c);
}

}  // namespace simd_utils

// YamlParser implementation
YamlParser::YamlParser() : current_(nullptr), end_(nullptr) {}

YamlParser::~YamlParser() = default;

void YamlParser::set_error(const std::string& message) {
    if (error_message_.empty()) {
        error_message_ = message;
    }
}

void YamlParser::skip_whitespace() {
    current_ = simd_utils::skip_whitespace(current_, end_);
}

void YamlParser::skip_whitespace_no_nl() {
    current_ = simd_utils::skip_whitespace_no_nl(current_, end_);
}

void YamlParser::skip_comment() {
    if (!eof() && *current_ == '#') {
        while (!eof() && *current_ != '\n') {
            advance();
        }
    }
}

void YamlParser::expect_char(char c) {
    if (eof() || *current_ != c) {
        set_error(std::string("Expected '") + c + "'");
        return;
    }
    advance();
}

bool YamlParser::peek_char(char c) {
    return !eof() && *current_ == c;
}

char YamlParser::peek() {
    return eof() ? '\0' : *current_;
}

char YamlParser::advance() {
    if (eof()) return '\0';
    return *current_++;
}

bool YamlParser::eof() {
    return current_ >= end_;
}

int YamlParser::get_current_indent() {
    const char* p = current_;
    int indent = 0;
    while (p < end_ && (*p == ' ' || *p == '\t')) {
        indent += (*p == '\t') ? 2 : 1;  // treat tab as 2 spaces for simplicity
        ++p;
    }
    return indent;
}

void YamlParser::skip_to_next_line() {
    while (!eof() && *current_ != '\n') advance();
    if (!eof()) advance();  // skip newline
}

void YamlParser::skip_blank_lines() {
    while (!eof()) {
        skip_whitespace_no_nl();
        if (eof()) break;
        if (*current_ == '\n') {
            advance();
        } else if (*current_ == '#') {
            skip_comment();
        } else {
            break;
        }
    }
}

void YamlParser::skip_blank_lines_only() {
    while (!eof()) {
        const char* p = current_;
        while (p < end_ && *p != '\n' && (*p == ' ' || *p == '\t')) ++p;
        if (p >= end_) break;
        if (*p == '\n') {
            skip_to_next_line();
            continue;
        }
        if (*p == '#') {
            skip_to_next_line();
            continue;
        }
        break;
    }
}

void YamlParser::skip_to_next_content_line() {
    while (!eof()) {
        if (*current_ == '\n') {
            advance();
            continue;
        }
        // At start of a line — check if blank or comment
        const char* p = current_;
        while (p < end_ && *p != '\n' && (*p == ' ' || *p == '\t')) ++p;
        if (p >= end_) break;
        if (*p == '\n') {
            skip_to_next_line();
            continue;
        }
        if (*p == '#') {
            skip_to_next_line();
            continue;
        }
        break;  // Content line — leave current_ at line start (with indent)
    }
}

bool YamlParser::at_line_start() {
    const char* p = current_;
    while (p > end_ - (end_ - current_)) {
        --p;
        if (p < end_) break;
    }
    if (current_ == end_) return true;
    const char* line_start = current_;
    while (line_start > end_ - 1000 && line_start[-1] != '\n') --line_start;
    return current_ == line_start || simd_utils::is_whitespace(*(current_ - 1));
}

std::string YamlParser::parse_escape_sequence() {
    if (eof()) return "";
    char c = advance();
    switch (c) {
        case 'n': return "\n";
        case 'r': return "\r";
        case 't': return "\t";
        case '\\': return "\\";
        case '"': return "\"";
        case '\'': return "'";
        default: return std::string(1, c);
    }
}

String YamlParser::parse_quoted_string(char quote) {
    expect_char(quote);
    std::string result;
    while (!eof() && *current_ != quote) {
        if (*current_ == '\\') {
            advance();
            result += parse_escape_sequence();
        } else {
            result += advance();
        }
    }
    if (!eof()) advance();  // closing quote
    return result;
}

std::optional<YamlValue> YamlParser::try_parse_bool() {
    const char* p = current_;
    if (end_ - p >= 4 && (p[0] == 't' || p[0] == 'T') && (p[1] == 'r' || p[1] == 'R') &&
        (p[2] == 'u' || p[2] == 'U') && (p[3] == 'e' || p[3] == 'E')) {
        if (end_ - p == 4 || !std::isalnum(static_cast<unsigned char>(p[4])) && p[4] != '_') {
            current_ = p + 4;
            return YamlValue(true);
        }
    }
    if (end_ - p >= 5 && (p[0] == 'f' || p[0] == 'F') && (p[1] == 'a' || p[1] == 'A') &&
        (p[2] == 'l' || p[2] == 'L') && (p[3] == 's' || p[3] == 'S') && (p[4] == 'e' || p[4] == 'E')) {
        if (end_ - p == 5 || !std::isalnum(static_cast<unsigned char>(p[5])) && p[5] != '_') {
            current_ = p + 5;
            return YamlValue(false);
        }
    }
    return std::nullopt;
}

std::optional<YamlValue> YamlParser::try_parse_null() {
    const char* p = current_;
    if (end_ - p >= 4 && (p[0] == 'n' || p[0] == 'N') && (p[1] == 'u' || p[1] == 'U') &&
        (p[2] == 'l' || p[2] == 'L') && (p[3] == 'l' || p[3] == 'L')) {
        if (end_ - p == 4 || !std::isalnum(static_cast<unsigned char>(p[4])) && p[4] != '_') {
            current_ = p + 4;
            return YamlValue(Null{});
        }
    }
    if (end_ - p >= 1 && *p == '~') {
        if (end_ - p == 1 || !std::isalnum(static_cast<unsigned char>(p[1])) && p[1] != '_') {
            current_ = p + 1;
            return YamlValue(Null{});
        }
    }
    return std::nullopt;
}

std::optional<YamlValue> YamlParser::try_parse_number() {
    const char* start = current_;
    if (eof()) return std::nullopt;
    bool negative = false;
    if (*current_ == '-') {
        negative = true;
        advance();
    } else if (*current_ == '+') {
        advance();
    }
    if (eof() || !std::isdigit(static_cast<unsigned char>(*current_))) {
        current_ = start;
        return std::nullopt;
    }
    const char* p = current_;
    bool has_dot = false;
    bool has_exp = false;
    int dot_count = 0;
    while (p < end_) {
        char c = *p;
        if (std::isdigit(static_cast<unsigned char>(c))) {
            ++p;
        } else if (c == '.' && !has_exp) {
            has_dot = true;
            ++dot_count;
            ++p;
        } else if ((c == 'e' || c == 'E') && !has_exp) {
            has_exp = true;
            ++p;
            if (p < end_ && (*p == '+' || *p == '-')) ++p;
        } else {
            break;
        }
    }
    std::string num_str(start, p);
    current_ = p;
    if (has_dot && !has_exp && dot_count > 1) {
        current_ = start;
        return std::nullopt;  // IP-like (192.168.1.1), keep as string
    }
    if (has_dot || has_exp) {
        try {
            double val = std::stod(num_str);
            return YamlValue(val);
        } catch (...) {
            current_ = start;
            return std::nullopt;
        }
    } else {
        try {
            int64_t val = std::stoll(num_str);
            return YamlValue(val);
        } catch (...) {
            current_ = start;
            return std::nullopt;
        }
    }
}

String YamlParser::parse_unquoted_scalar() {
    std::string result;
    while (!eof()) {
        char c = *current_;
        if (c == '#' || c == '\n' || c == ':' || c == '|' || c == '>' || c == '&' || c == '*') {
            break;
        }
        if (c == ' ' || c == '\t') {
            const char* next = current_;
            while (next < end_ && (*next == ' ' || *next == '\t')) ++next;
            if (next < end_ && *next == '\n') break;
            if (next < end_ && *next == '#') break;
        }
        result += advance();
    }
    // Trim trailing whitespace
    while (!result.empty() && (result.back() == ' ' || result.back() == '\t')) {
        result.pop_back();
    }
    return result;
}

String YamlParser::parse_scalar() {
    skip_whitespace_no_nl();
    if (eof()) return "";
    if (*current_ == '"') return parse_quoted_string('"');
    if (*current_ == '\'') return parse_quoted_string('\'');
    return parse_unquoted_scalar();
}

YamlValue YamlParser::parse_value(int indent) {
    skip_whitespace_no_nl();
    if (eof()) return Null{};

    // Try bool, null, number first
    auto b = try_parse_bool();
    if (b) return *b;
    auto n = try_parse_null();
    if (n) return *n;
    auto num = try_parse_number();
    if (num) return *num;

    // Quoted string
    if (*current_ == '"' || *current_ == '\'') {
        return YamlValue(parse_scalar());
    }

    // Check for sequence: "- value"
    if (*current_ == '-' && (current_ + 1 >= end_ || current_[1] == ' ' || current_[1] == '\t')) {
        advance();
        skip_whitespace_no_nl();
        return parse_value(indent);
    }

    // Check for mapping: "key: value" - only on current line
    const char* line_end = simd_utils::find_char_simd(current_, end_, '\n');
    const char* colon = simd_utils::find_char_simd(current_, line_end, ':');
    if (colon < line_end) {
        const char* after_colon = colon + 1;
        bool key_ok = true;
        if (colon > current_) {
            const char* p = current_;
            while (p < colon) {
                if (*p == '\n' || *p == '#') {
                    key_ok = false;
                    break;
                }
                ++p;
            }
        }
        if (key_ok && (after_colon >= line_end || *after_colon == ' ' || *after_colon == '\t' || *after_colon == '\n')) {
            std::string key_str(current_, colon);
            current_ = colon + 1;
            skip_whitespace_no_nl();
            if (key_str.empty()) {
                set_error("Empty mapping key");
                return Null{};
            }
            // Trim key
            while (!key_str.empty() && (key_str.back() == ' ' || key_str.back() == '\t')) key_str.pop_back();

            YamlValue val;
            skip_whitespace_no_nl();
            if (eof() || *current_ == '\n' || *current_ == '#') {
                val = Null{};
            } else if (*current_ == '|' || *current_ == '>') {
                set_error("Multiline strings not supported in MVP");
                return Null{};
            } else {
                val = parse_value(indent);
            }
            auto mapping = std::make_shared<Mapping>();
            mapping->set(key_str, val);
            return YamlValue(mapping);
        }
    }

    // Plain scalar
    return YamlValue(parse_scalar());
}

YamlValue YamlParser::parse_sequence(int base_indent) {
    auto seq = std::make_shared<Sequence>();
    while (!eof()) {
        int ind = get_current_indent();
        if (ind > 0 && ind < base_indent) break;  // Sibling line — stop before consuming
        skip_blank_lines();
        if (eof()) break;
        current_ = simd_utils::skip_whitespace_no_nl(current_, end_);  // skip to content
        if (eof() || *current_ == '\n') break;
        if (*current_ != '-') break;
        advance();
        skip_whitespace_no_nl();
        if (eof() || *current_ == '\n' || *current_ == '#') {
            seq->append(Null{});
            skip_to_next_line();
        } else {
            const char* line_end = simd_utils::find_char_simd(current_, end_, '\n');
            const char* colon = simd_utils::find_char_simd(current_, line_end, ':');
            bool looks_like_mapping = (colon < line_end && colon > current_ &&
                (colon[1] == ' ' || colon[1] == '\t' || colon[1] == '\n'));
            if (looks_like_mapping) {
                int mapping_base = ind + 2;
                YamlValue v = parse_mapping(mapping_base, true);  // at content, no leading indent
                seq->append(v);
                // parse_mapping leaves current_ at next line, no skip needed
            } else {
                YamlValue v = parse_value(ind);
                seq->append(v);
                skip_to_next_line();
            }
        }
    }
    return YamlValue(seq);
}

YamlValue YamlParser::parse_mapping(int base_indent, bool at_content_start) {
    auto mapping = std::make_shared<Mapping>();
    bool first_key = true;
    while (!eof()) {
        skip_to_next_content_line();  // Position at next content line (preserve indent)
        if (eof()) break;
        int ind = get_current_indent();
        // Break when line has smaller indent (sibling/parent). Exception: first line when
        // at_content_start (caller positioned us at content, no leading spaces -> ind=0).
        if (ind < base_indent && (ind > 0 || !at_content_start || !first_key)) break;
        const char* line_start = simd_utils::skip_whitespace_no_nl(current_, end_);
        if (line_start >= end_ || *line_start == '\n') break;

        // Sequence item at same level - stop
        if (*line_start == '-' && (line_start + 1 >= end_ || line_start[1] == ' ' || line_start[1] == '\t')) {
            break;
        }
        current_ = line_start;

        const char* line_end = simd_utils::find_char_simd(current_, end_, '\n');
        const char* colon = simd_utils::find_char_simd(current_, line_end, ':');
        if (colon >= line_end) break;
        if (colon == current_) {
            set_error("Empty mapping key");
            break;
        }
        std::string key_str(current_, colon);
        current_ = colon + 1;
        skip_whitespace_no_nl();
        while (!key_str.empty() && (key_str.back() == ' ' || key_str.back() == '\t')) key_str.pop_back();
        if (key_str.empty()) break;

        YamlValue val;
        bool had_inline_value = false;
        if (eof() || *current_ == '\n' || *current_ == '#') {
            // Value on next line - check for nested structure
            skip_to_next_line();
            if (!eof()) {
                skip_blank_lines_only();  // Skip blank lines only, preserve indent of content line
                if (!eof()) {
                    int next_indent = get_current_indent();
                    if (next_indent > ind) {
                        const char* content = simd_utils::skip_whitespace_no_nl(current_, end_);
                        if (content < end_ && *content == '-') {
                            current_ = content;
                            val = parse_sequence(next_indent);
                        } else {
                            val = parse_mapping(next_indent, false);
                        }
                    } else {
                        val = Null{};
                    }
                } else {
                    val = Null{};
                }
            } else {
                val = Null{};
            }
        } else {
            val = parse_value(ind);
            had_inline_value = true;
        }

        if (std::holds_alternative<MappingPtr>(val)) {
            mapping->set(key_str, val);
        } else if (std::holds_alternative<SequencePtr>(val)) {
            mapping->set(key_str, val);
        } else {
            mapping->set(key_str, val);
        }
        first_key = false;

        if (eof()) break;
        if (had_inline_value) {
            skip_to_next_line();
        }
    }
    return YamlValue(mapping);
}

YamlValue YamlParser::parse_document() {
    skip_blank_lines();
    if (eof()) {
        return YamlValue(std::make_shared<Mapping>());
    }

    int base_indent = get_current_indent();

    // Sequence at root
    if (*current_ == '-' && (current_ + 1 >= end_ || current_[1] == ' ' || current_[1] == '\t')) {
        return parse_sequence(base_indent);
    }

    // Mapping at root
    return parse_mapping(base_indent);
}

YamlValue YamlParser::parse(const std::string& input) {
    error_message_.clear();
    current_ = input.data();
    end_ = input.data() + input.size();
    indent_stack_.clear();

    YamlValue result = parse_document();
    skip_whitespace();
    skip_comment();
    skip_whitespace();
    return result;
}

}  // namespace fastyaml
