# pyfsave

A simple Python library to upload and download files from a server.
