import requests
import os

class PyFSave:
    def __init__(self, server_url):
        # example: "http://127.0.0.1:5000"
        self.server_url = server_url.rstrip("/")

    def save_file(self, filepath):
        if not os.path.exists(filepath):
            raise FileNotFoundError("File not found")

        url = self.server_url + "/upload"

        with open(filepath, "rb") as f:
            files = {"file": f}
            r = requests.post(url, files=files)

        return r.text

    def download_file(self, filename, save_as=None):
        url = self.server_url + "/files/" + filename
        r = requests.get(url)

        if r.status_code != 200:
            raise Exception("Download failed")

        if save_as is None:
            save_as = filename

        with open(save_as, "wb") as f:
            f.write(r.content)

        return save_as
