from setuptools import setup

setup(
    name="pyfsave",
    version="0.1.0",
    py_modules=["pyfsave"],
    install_requires=["requests"],
    description="Simple file saver to a remote server",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Theo",
    url="https://github.com/YOURNAME/pyfsave",
)
