"""PyTorch Geometric-based multimodal hypergraph datasets."""

__version__ = "0.1.0"

# Config
from pyg_hyper_data.config import paths

# Utils
from pyg_hyper_data.utils import download, io

__all__ = [
    "__version__",
    "download",
    "io",
    "paths",
]
