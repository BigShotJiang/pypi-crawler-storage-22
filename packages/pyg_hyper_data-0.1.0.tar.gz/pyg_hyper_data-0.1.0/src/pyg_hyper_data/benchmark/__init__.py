"""Benchmark suite with standardized evaluation protocols."""

from pyg_hyper_data.benchmark.evaluator import HypergraphEvaluator
from pyg_hyper_data.benchmark.protocol import (
    BenchmarkProtocol,
    NodeClassificationProtocol,
)

__all__ = [
    "BenchmarkProtocol",
    "HypergraphEvaluator",
    "NodeClassificationProtocol",
]
