"""Configuration module."""

from pyg_hyper_data.config import paths

__all__ = ["paths"]
