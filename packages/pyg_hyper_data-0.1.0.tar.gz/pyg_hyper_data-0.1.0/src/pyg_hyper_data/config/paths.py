"""Configuration for default paths and directories."""

import os
from pathlib import Path


def get_pyg_hyper_home() -> Path:
    """Get the pyg-hyper home directory.

    Returns:
        Path to pyg-hyper home directory, defaults to ~/.pyg-hyper
    """
    default_home = Path.home() / ".pyg-hyper"
    env_home = os.environ.get("PYG_HYPER_HOME")

    if env_home:
        return Path(env_home)
    return default_home


def get_data_dir() -> Path:
    """Get the data directory for datasets.

    Returns:
        Path to data directory (~/.pyg-hyper/data)
    """
    return get_pyg_hyper_home() / "data"


def get_config_dir() -> Path:
    """Get the config directory.

    Returns:
        Path to config directory (~/.pyg-hyper/config)
    """
    return get_pyg_hyper_home() / "config"


def get_dataset_dir(dataset_name: str) -> Path:
    """Get the directory for a specific dataset.

    Args:
        dataset_name: Name of the dataset

    Returns:
        Path to dataset directory (~/.pyg-hyper/data/{dataset_name})
    """
    return get_data_dir() / dataset_name


def get_raw_dir(dataset_name: str) -> Path:
    """Get the raw data directory for a dataset.

    Args:
        dataset_name: Name of the dataset

    Returns:
        Path to raw directory
    """
    return get_dataset_dir(dataset_name) / "raw"


def get_processed_dir(dataset_name: str) -> Path:
    """Get the processed data directory for a dataset.

    Args:
        dataset_name: Name of the dataset

    Returns:
        Path to processed directory
    """
    return get_dataset_dir(dataset_name) / "processed"


def get_multimodal_dir(dataset_name: str) -> Path:
    """Get the multimodal data directory for a dataset.

    Args:
        dataset_name: Name of the dataset

    Returns:
        Path to multimodal directory
    """
    return get_dataset_dir(dataset_name) / "multimodal"


def get_text_embeddings_dir(dataset_name: str) -> Path:
    """Get the text embeddings directory for a dataset.

    Args:
        dataset_name: Name of the dataset

    Returns:
        Path to text embeddings directory
    """
    return get_multimodal_dir(dataset_name) / "text_embeddings"


def ensure_dir(path: Path) -> Path:
    """Ensure a directory exists, creating it if necessary.

    Args:
        path: Path to directory

    Returns:
        Path to the directory
    """
    path.mkdir(parents=True, exist_ok=True)
    return path
