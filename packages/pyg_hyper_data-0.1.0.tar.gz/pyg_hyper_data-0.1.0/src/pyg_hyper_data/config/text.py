"""Configuration for text feature handling with TAG dataset.

This module provides configuration and utilities for integrating text features
from the HuggingFace TAG (Text-Attributed-Graphs) dataset into pyg-hyper-data.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

# Supported datasets for TAG text features
# Maps dataset_name -> dataset_type
TAG_SUPPORTED_DATASETS = {
    "cora": "cocitation",
    "pubmed": "cocitation",
}

# Default sentence-transformer model
DEFAULT_ENCODER_MODEL = "all-mpnet-base-v2"

# HuggingFace repository for TAG dataset
TAG_HF_REPO = "Graph-COM/Text-Attributed-Graphs"


@dataclass
class TextEncoderConfig:
    """Configuration for sentence-transformer text encoding.

    Args:
        model_name: HuggingFace model name for sentence-transformers.
            Default: "all-mpnet-base-v2" (768-dim embeddings).
        batch_size: Batch size for encoding texts. Default: 32.
        device: Device to use for encoding ("cpu", "cuda", or None for auto).
            Default: None (auto-detect).
        max_seq_length: Maximum sequence length for tokenization. Default: 512.
        normalize_embeddings: Whether to L2-normalize embeddings. Default: True.
        show_progress_bar: Whether to show progress bar during encoding. Default: True.

    Example:
        >>> config = TextEncoderConfig(model_name="all-MiniLM-L6-v2")
        >>> print(config.model_name)
        'all-MiniLM-L6-v2'
    """

    model_name: str = DEFAULT_ENCODER_MODEL
    batch_size: int = 32
    device: Literal["cpu", "cuda"] | None = None
    max_seq_length: int = 512
    normalize_embeddings: bool = True
    show_progress_bar: bool = True


def get_tag_filename(dataset_name: str) -> str:
    """Get TAG dataset filename for a given dataset.

    Args:
        dataset_name: Name of the dataset (e.g., "cora", "pubmed").

    Returns:
        HuggingFace filename path for the dataset's raw_texts.pt file.

    Raises:
        ValueError: If dataset is not supported by TAG.

    Example:
        >>> get_tag_filename("cora")
        'cora/raw_texts.pt'
    """
    if dataset_name not in TAG_SUPPORTED_DATASETS:
        supported = ", ".join(TAG_SUPPORTED_DATASETS.keys())
        msg = (
            f"Dataset '{dataset_name}' is not supported by TAG. "
            f"Supported datasets: {supported}"
        )
        raise ValueError(msg)

    return f"{dataset_name}/raw_texts.pt"


def is_text_supported(dataset_name: str, dataset_type: str) -> bool:
    """Check if a dataset supports TAG text features.

    Args:
        dataset_name: Name of the dataset (e.g., "cora", "citeseer", "pubmed").
        dataset_type: Type of the dataset (e.g., "cocitation", "coauthorship").

    Returns:
        True if the dataset supports TAG text features, False otherwise.

    Example:
        >>> is_text_supported("cora", "cocitation")
        True
        >>> is_text_supported("citeseer", "cocitation")
        False
    """
    return (
        dataset_name in TAG_SUPPORTED_DATASETS
        and TAG_SUPPORTED_DATASETS[dataset_name] == dataset_type
    )


def get_supported_datasets() -> dict[str, str]:
    """Get dictionary of supported datasets and their types.

    Returns:
        Dictionary mapping dataset names to their types.

    Example:
        >>> get_supported_datasets()
        {'cora': 'cocitation', 'pubmed': 'cocitation'}
    """
    return TAG_SUPPORTED_DATASETS.copy()
