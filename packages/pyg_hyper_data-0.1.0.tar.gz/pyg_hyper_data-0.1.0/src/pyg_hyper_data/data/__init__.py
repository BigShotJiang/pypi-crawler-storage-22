"""Data structures for hypergraphs."""

from pyg_hyper_data.data.conversion import (
    hetero_to_hyperedge_index,
    hyperedge_index_to_hetero,
    validate_conversion,
)
from pyg_hyper_data.data.hyper_data import HyperData
from pyg_hyper_data.data.hyper_hetero_data import HyperHeteroData

__all__ = [
    "HyperData",
    "HyperHeteroData",
    "hetero_to_hyperedge_index",
    "hyperedge_index_to_hetero",
    "validate_conversion",
]
