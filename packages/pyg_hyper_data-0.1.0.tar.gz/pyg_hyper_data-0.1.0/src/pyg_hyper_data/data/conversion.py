"""Conversion utilities between HyperData and HyperHeteroData formats."""

import torch


def hyperedge_index_to_hetero(hyper_data: "HyperData") -> "HyperHeteroData":  # noqa: F821  # type: ignore[name-defined]
    """Convert HyperData (hyperedge_index) to HyperHeteroData (UBO bipartite).

    Algorithm:
    1. Create 'node' node type with all node data (x, y, multimodal attributes)
    2. Create 'hyperedge' node type with hyperedge data (hyperedge_attr if present)
    3. Create bidirectional edges from hyperedge_index
    4. Transfer all multimodal attributes
    5. For AttributedHyperData: Create attribute node types and entity-attribute edges

    Args:
        hyper_data: HyperData or AttributedHyperData object to convert

    Returns:
        HyperHeteroData object with equivalent structure

    Example:
        >>> hyper_data = HyperData(x=..., hyperedge_index=..., y=...)
        >>> hetero_data = hyperedge_index_to_hetero(hyper_data)

        >>> # With AttributedHyperData
        >>> attributed_data = AttributedHyperData(...)
        >>> hetero_data = hyperedge_index_to_hetero(attributed_data)
        >>> # Creates: 'entity', 'title', 'abstract', 'hyperedge' node types
    """
    from pyg_hyper_data.data.hyper_hetero_data import HyperHeteroData

    hetero_data = HyperHeteroData()

    # Check if this is AttributedHyperData
    is_attributed = hasattr(hyper_data, "attribute_types") and hasattr(
        hyper_data, "attribute_offsets"
    )

    # 1. Create node types
    if is_attributed:
        # For AttributedHyperData: Create 'entity' instead of 'node'
        entity_node_type = "entity"
        original_num_nodes = hyper_data.original_num_nodes

        # Entity nodes (original nodes only)
        if hyper_data.x is not None:
            hetero_data[entity_node_type].x = hyper_data.x

        if hyper_data.y is not None:
            hetero_data[entity_node_type].y = hyper_data.y

        hetero_data[entity_node_type].num_nodes = original_num_nodes

        # Create attribute node types
        attribute_types = hyper_data.attribute_types
        attribute_features = hyper_data.attribute_features
        attribute_offsets = hyper_data.attribute_offsets

        for attr_type in attribute_types:
            attr_features = attribute_features[attr_type]
            hetero_data[attr_type].x = attr_features
            hetero_data[attr_type].num_nodes = len(attr_features)

        # Transfer other multimodal attributes to entity
        exclude_attributed = {
            "x",
            "y",
            "hyperedge_index",
            "hyperedge_attr",
            "num_nodes",
            "edge_index",
            "attribute_types",
            "attribute_features",
            "attribute_offsets",
            "entity_attribute_edge_mask",
            "original_num_nodes",
            "original_num_edges",
            *attribute_types,  # Exclude attribute features
        }
        for key in hyper_data.keys():  # noqa: SIM118
            if key not in exclude_attributed:
                hetero_data[entity_node_type][key] = hyper_data[key]
    else:
        # For regular HyperData: Create 'node' type
        if hyper_data.x is not None:
            hetero_data["node"].x = hyper_data.x

        if hyper_data.y is not None:
            hetero_data["node"].y = hyper_data.y

        # Set num_nodes
        if hyper_data.num_nodes is not None:
            hetero_data["node"].num_nodes = hyper_data.num_nodes

        # Transfer multimodal attributes
        exclude = {
            "x",
            "y",
            "hyperedge_index",
            "hyperedge_attr",
            "num_nodes",
            "edge_index",
        }
        for key in hyper_data.keys():  # noqa: SIM118
            if key not in exclude:
                hetero_data["node"][key] = hyper_data[key]

    # 2. Create hyperedge node types
    if is_attributed:
        # For AttributedHyperData: Create typed hyperedge nodes
        entity_attr_edge_mask = hyper_data.entity_attribute_edge_mask
        original_num_edges = hyper_data.original_num_edges

        # Structural hyperedges
        hetero_data["structural_hyperedge"].num_nodes = original_num_edges

        # Entity-attribute hyperedges
        num_entity_attr_edges = hyper_data.num_hyperedges - original_num_edges
        hetero_data["entity_attribute_hyperedge"].num_nodes = num_entity_attr_edges

        # Transfer hyperedge_attr if present (to structural hyperedges only)
        hyperedge_attr = getattr(hyper_data, "hyperedge_attr", None)
        if hyperedge_attr is not None and len(hyperedge_attr) == original_num_edges:
            hetero_data["structural_hyperedge"].x = hyperedge_attr
    else:
        # For regular HyperData: Single hyperedge type
        num_hyperedges = hyper_data.num_hyperedges
        hetero_data["hyperedge"].num_nodes = num_hyperedges

        hyperedge_attr = getattr(hyper_data, "hyperedge_attr", None)
        if hyperedge_attr is not None:
            hetero_data["hyperedge"].x = hyperedge_attr

    # 3. Create edges
    if hyper_data.hyperedge_index is not None:
        if is_attributed:
            # For AttributedHyperData: Create typed hyperedge connections
            entity_attr_edge_mask = hyper_data.entity_attribute_edge_mask
            original_num_nodes = hyper_data.original_num_nodes

            # Structural hyperedges: entity-to-structural_hyperedge
            structural_mask = ~entity_attr_edge_mask
            structural_edges = hyper_data.hyperedge_index[:, structural_mask]

            # Structural hyperedge IDs are already 0-indexed
            hetero_data[
                entity_node_type, "member_of", "structural_hyperedge"
            ].edge_index = structural_edges
            hetero_data[
                "structural_hyperedge", "has_member", entity_node_type
            ].edge_index = structural_edges[[1, 0]]

            # Entity-attribute hyperedges
            entity_attr_edges = hyper_data.hyperedge_index[:, entity_attr_edge_mask]
            node_ids = entity_attr_edges[0]
            edge_ids = entity_attr_edges[1]

            # Remap entity-attribute hyperedge IDs to start from 0
            # Original edge IDs: [original_num_edges, num_hyperedges)
            # New edge IDs: [0, num_entity_attr_edges)
            edge_ids_remapped = edge_ids - original_num_edges

            # Create edges for each node type
            # Entity nodes
            entity_mask = node_ids < original_num_nodes
            entity_edges = torch.stack(
                [node_ids[entity_mask], edge_ids_remapped[entity_mask]]
            )

            hetero_data[
                entity_node_type, "member_of", "entity_attribute_hyperedge"
            ].edge_index = entity_edges
            hetero_data[
                "entity_attribute_hyperedge", "has_member", entity_node_type
            ].edge_index = entity_edges[[1, 0]]

            # Attribute nodes
            for attr_type in attribute_types:
                attr_offset = attribute_offsets[attr_type]
                attr_num_nodes = len(attribute_features[attr_type])
                attr_end = attr_offset + attr_num_nodes

                # Find attribute nodes of this type
                is_attr_type = (node_ids >= attr_offset) & (node_ids < attr_end)

                if is_attr_type.any():
                    # Remap attribute node IDs to 0-indexed for this type
                    attr_node_ids_remapped = node_ids[is_attr_type] - attr_offset
                    attr_edges = torch.stack(
                        [attr_node_ids_remapped, edge_ids_remapped[is_attr_type]]
                    )

                    hetero_data[
                        attr_type, "member_of", "entity_attribute_hyperedge"
                    ].edge_index = attr_edges
                    hetero_data[
                        "entity_attribute_hyperedge", "has_member", attr_type
                    ].edge_index = attr_edges[[1, 0]]
        else:
            # For regular HyperData: Simple node-to-hyperedge connections
            hetero_data[
                "node", "member_of", "hyperedge"
            ].edge_index = hyper_data.hyperedge_index

            # Reverse edge type for bidirectional access
            hetero_data[
                "hyperedge", "has_member", "node"
            ].edge_index = hyper_data.hyperedge_index[[1, 0]]

    return hetero_data


def hetero_to_hyperedge_index(hetero_data: "HyperHeteroData") -> "HyperData":  # noqa: F821  # type: ignore[name-defined]
    """Convert HyperHeteroData (UBO bipartite) to HyperData (hyperedge_index).

    Algorithm:
    1. Extract node data from 'node' node type (x, y, multimodal attributes)
    2. Extract hyperedge data from 'hyperedge' node type
    3. Extract edge_index from ('node', 'member_of', 'hyperedge')
    4. Transfer all multimodal attributes

    Args:
        hetero_data: HyperHeteroData object to convert

    Returns:
        HyperData object with equivalent structure

    Example:
        >>> hetero_data = HyperHeteroData()
        >>> # ... set up hetero_data ...
        >>> hyper_data = hetero_to_hyperedge_index(hetero_data)
    """
    from pyg_hyper_data.data.hyper_data import HyperData

    # Extract node data
    node_data = {}

    if "x" in hetero_data["node"]:
        node_data["x"] = hetero_data["node"].x

    if "y" in hetero_data["node"]:
        node_data["y"] = hetero_data["node"].y

    # Set num_nodes
    node_data["num_nodes"] = hetero_data["node"].num_nodes

    # Extract hyperedge data
    if "x" in hetero_data["hyperedge"]:
        node_data["hyperedge_attr"] = hetero_data["hyperedge"].x

    # Extract edge_index
    if ("node", "member_of", "hyperedge") in hetero_data.edge_types:
        node_data["hyperedge_index"] = hetero_data[
            "node", "member_of", "hyperedge"
        ].edge_index

    # Transfer multimodal attributes
    exclude = {"x", "y", "edge_index", "num_nodes", "batch", "ptr"}
    for key in hetero_data["node"].keys():  # noqa: SIM118
        if key not in exclude:
            node_data[key] = hetero_data["node"][key]

    return HyperData(**node_data)


def validate_conversion(
    data1: "HyperData | HyperHeteroData",  # noqa: F821  # type: ignore[name-defined]
    data2: "HyperData | HyperHeteroData",  # noqa: F821  # type: ignore[name-defined]
    check_multimodal: bool = True,
) -> bool:
    """Validate that two data objects are equivalent after conversion.

    This is used to verify round-trip conversion:
    HyperData -> HyperHeteroData -> HyperData (or vice versa)

    Args:
        data1: First data object
        data2: Second data object (after conversion)
        check_multimodal: Whether to check multimodal attributes

    Returns:
        True if equivalent, False otherwise

    Example:
        >>> original = HyperData(x=..., hyperedge_index=..., y=...)
        >>> hetero = original.to_hetero()
        >>> reconstructed = hetero.to_hyperedge_index()
        >>> assert validate_conversion(original, reconstructed)
    """
    from pyg_hyper_data.data.hyper_data import HyperData
    from pyg_hyper_data.data.hyper_hetero_data import HyperHeteroData

    # Convert both to HyperData for comparison
    if isinstance(data1, HyperHeteroData):
        data1 = hetero_to_hyperedge_index(data1)
    if isinstance(data2, HyperHeteroData):
        data2 = hetero_to_hyperedge_index(data2)

    # Now both are HyperData
    assert isinstance(data1, HyperData)
    assert isinstance(data2, HyperData)

    # Check num_nodes
    if data1.num_nodes != data2.num_nodes:
        return False

    # Check num_hyperedges
    if data1.num_hyperedges != data2.num_hyperedges:
        return False

    # Check x
    x1 = getattr(data1, "x", None)
    x2 = getattr(data2, "x", None)
    if (x1 is None) != (x2 is None):
        return False
    if x1 is not None and not torch.equal(x1, x2):  # type: ignore[arg-type]
        return False

    # Check y
    y1 = getattr(data1, "y", None)
    y2 = getattr(data2, "y", None)
    if (y1 is None) != (y2 is None):
        return False
    if y1 is not None and not torch.equal(y1, y2):  # type: ignore[arg-type]
        return False

    # Check hyperedge_index
    idx1 = getattr(data1, "hyperedge_index", None)
    idx2 = getattr(data2, "hyperedge_index", None)
    if (idx1 is None) != (idx2 is None):
        return False
    if idx1 is not None:
        # Sort for comparison (order might differ)
        def sort_hyperedge_index(idx: torch.Tensor) -> torch.Tensor:
            # Sort by hyperedge, then by node within each hyperedge
            sorted_indices = torch.argsort(idx[1] * 100000 + idx[0])
            return idx[:, sorted_indices]

        idx1_sorted = sort_hyperedge_index(idx1)
        idx2_sorted = sort_hyperedge_index(idx2)  # type: ignore[arg-type]

        if not torch.equal(idx1_sorted, idx2_sorted):
            return False

    # Check hyperedge_attr
    attr1 = getattr(data1, "hyperedge_attr", None)
    attr2 = getattr(data2, "hyperedge_attr", None)
    if (attr1 is None) != (attr2 is None):
        return False
    if attr1 is not None and not torch.equal(attr1, attr2):  # type: ignore[arg-type]
        return False

    # Check multimodal attributes
    if check_multimodal:
        exclude = {
            "x",
            "y",
            "hyperedge_index",
            "hyperedge_attr",
            "num_nodes",
            "edge_index",
        }
        keys1 = {k for k in data1.keys() if k not in exclude}  # noqa: SIM118
        keys2 = {k for k in data2.keys() if k not in exclude}  # noqa: SIM118

        if keys1 != keys2:
            return False

        for key in keys1:
            val1 = data1[key]
            val2 = data2[key]

            # Handle different types
            if isinstance(val1, torch.Tensor) and isinstance(val2, torch.Tensor):
                if not torch.equal(val1, val2):
                    return False
            elif val1 != val2:
                return False

    return True
