"""HyperData class for hypergraph representation (hyperedge_index format)."""

from typing import Any

import torch
from torch_geometric.data import Data


class HyperData(Data):
    """Hypergraph data in hyperedge_index format.

    This class extends PyTorch Geometric's Data class to represent hypergraphs
    using the traditional hyperedge_index format, where hyperedges are represented
    as a 2D tensor of connections between nodes and hyperedges.

    Attributes:
        x: Node feature matrix [num_nodes, num_node_features]
        hyperedge_index: Hyperedge connections [2, num_connections]
            - hyperedge_index[0, :]: node indices
            - hyperedge_index[1, :]: hyperedge indices
        hyperedge_attr: Hyperedge feature matrix [num_hyperedges, num_edge_features] (optional)
        y: Node labels [num_nodes] or [num_nodes, num_classes]
        num_nodes: Number of nodes (automatically computed if not provided)

    Example:
        >>> # Create a simple hypergraph with 4 nodes and 2 hyperedges
        >>> # Hyperedge 0: nodes {0, 1, 2}
        >>> # Hyperedge 1: nodes {1, 2, 3}
        >>> x = torch.randn(4, 16)  # 4 nodes, 16 features each
        >>> hyperedge_index = torch.tensor([
        ...     [0, 1, 2, 1, 2, 3],  # node indices
        ...     [0, 0, 0, 1, 1, 1]   # hyperedge indices
        ... ])
        >>> y = torch.tensor([0, 1, 1, 0])  # node labels
        >>> data = HyperData(x=x, hyperedge_index=hyperedge_index, y=y)
        >>> print(data.num_hyperedges)
        2
    """

    def __init__(
        self,
        x: torch.Tensor | None = None,
        hyperedge_index: torch.Tensor | None = None,
        hyperedge_attr: torch.Tensor | None = None,
        y: torch.Tensor | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize HyperData.

        Args:
            x: Node feature matrix
            hyperedge_index: Hyperedge connections [2, num_connections]
            hyperedge_attr: Hyperedge feature matrix (optional)
            y: Node labels
            **kwargs: Additional attributes (e.g., multimodal features like 'title', 'abstract')
        """
        super().__init__(x=x, y=y, **kwargs)
        self.hyperedge_index = hyperedge_index
        self.hyperedge_attr = hyperedge_attr

    def __inc__(
        self, key: str, value: Any, *args: Any, **kwargs: Any
    ) -> int | torch.Tensor:
        """Increment indices for batching.

        This method is called by PyTorch Geometric's batching mechanism to
        correctly increment indices when creating batches.

        Args:
            key: Attribute name
            value: Attribute value
            *args: Additional positional arguments
            **kwargs: Additional keyword arguments

        Returns:
            Increment value for the attribute
        """
        if key == "hyperedge_index":
            # Increment node indices (row 0) by num_nodes
            # Increment hyperedge indices (row 1) by num_hyperedges
            return torch.tensor([[self.num_nodes], [self.num_hyperedges]])
        return super().__inc__(key, value, *args, **kwargs)

    @property
    def num_hyperedges(self) -> int:
        """Return the number of hyperedges.

        Returns:
            Number of hyperedges in the hypergraph
        """
        hyperedge_index = getattr(self, "hyperedge_index", None)
        if hyperedge_index is not None:
            return int(hyperedge_index[1].max()) + 1
        return 0

    def hyperedge_sizes(self) -> torch.Tensor:
        """Return the size of each hyperedge.

        Returns:
            Tensor of hyperedge sizes [num_hyperedges]
        """
        hyperedge_index = getattr(self, "hyperedge_index", None)
        if hyperedge_index is None:
            return torch.tensor([])
        return torch.bincount(hyperedge_index[1], minlength=self.num_hyperedges)

    def node_degrees(self) -> torch.Tensor:
        """Return the degree of each node.

        The degree is the number of hyperedges a node belongs to.

        Returns:
            Tensor of node degrees [num_nodes]
        """
        hyperedge_index = getattr(self, "hyperedge_index", None)
        if hyperedge_index is None:
            return torch.tensor([])
        num_nodes = self.num_nodes if self.num_nodes is not None else 0
        return torch.bincount(hyperedge_index[0], minlength=num_nodes)

    def to_hetero(self) -> "HyperHeteroData":  # noqa: F821  # type: ignore[name-defined]
        """Convert to HyperHeteroData (UBO bipartite graph representation).

        Returns:
            HyperHeteroData object with equivalent graph structure
        """
        from pyg_hyper_data.data.conversion import hyperedge_index_to_hetero

        return hyperedge_index_to_hetero(self)

    def validate(self, raise_on_error: bool = True) -> bool:  # noqa: ARG002
        """Validate the hypergraph structure.

        Checks:
        - hyperedge_index has correct shape
        - node indices are within valid range
        - hyperedge indices are contiguous (0 to num_hyperedges-1)

        Args:
            raise_on_error: Whether to raise an exception on validation error

        Returns:
            True if valid, raises ValueError otherwise

        Raises:
            ValueError: If validation fails
        """
        if self.hyperedge_index is None:
            msg = "hyperedge_index is None"
            raise ValueError(msg)

        if self.hyperedge_index.dim() != 2:
            msg = f"hyperedge_index must be 2D, got {self.hyperedge_index.dim()}D"
            raise ValueError(msg)

        if self.hyperedge_index.size(0) != 2:
            msg = f"hyperedge_index must have shape [2, num_connections], got {self.hyperedge_index.shape}"
            raise ValueError(msg)

        # Check node indices
        if self.num_nodes is not None:
            max_node_idx = self.hyperedge_index[0].max()
            if max_node_idx >= self.num_nodes:
                msg = f"Node index {max_node_idx} exceeds num_nodes {self.num_nodes}"
                raise ValueError(msg)

        # Check hyperedge indices are contiguous
        hyperedge_indices = self.hyperedge_index[1].unique()
        expected_indices = torch.arange(self.num_hyperedges)
        if not torch.equal(hyperedge_indices.sort()[0], expected_indices):
            msg = "Hyperedge indices must be contiguous (0 to num_hyperedges-1)"
            raise ValueError(msg)

        return True

    def __repr__(self) -> str:
        """Return string representation of HyperData."""
        info = [f"num_nodes={self.num_nodes}"]
        info.append(f"num_hyperedges={self.num_hyperedges}")

        x = getattr(self, "x", None)
        if x is not None:
            info.append(f"num_node_features={x.size(1)}")

        hyperedge_attr = getattr(self, "hyperedge_attr", None)
        if hyperedge_attr is not None:
            info.append(f"num_edge_features={hyperedge_attr.size(1)}")

        y = getattr(self, "y", None)
        if y is not None:
            info.append(f"num_classes={int(y.max()) + 1}")

        # Add multimodal attributes
        exclude = {
            "x",
            "y",
            "hyperedge_index",
            "hyperedge_attr",
            "num_nodes",
            "edge_index",
        }
        multimodal = [k for k in self.keys() if k not in exclude]
        if multimodal:
            info.append(f"multimodal_attrs={multimodal}")

        return f"HyperData({', '.join(info)})"
