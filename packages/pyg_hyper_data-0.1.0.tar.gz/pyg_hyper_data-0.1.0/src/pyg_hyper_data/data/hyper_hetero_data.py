"""HyperHeteroData class for hypergraph representation (UBO bipartite graph format)."""

from typing import Any

import torch
from torch_geometric.data import HeteroData


class HyperHeteroData(HeteroData):
    """Hypergraph data in UBO (Universal Bipartite Object) format.

    This class extends PyTorch Geometric's HeteroData to represent hypergraphs
    as bipartite graphs, where both nodes and hyperedges are represented as
    node types, connected by bidirectional edges.

    Node types:
        - 'node': Original hypergraph nodes
        - 'hyperedge': Hyperedges represented as nodes

    Edge types:
        - ('node', 'member_of', 'hyperedge'): Nodes belonging to hyperedges
        - ('hyperedge', 'has_member', 'node'): Hyperedges containing nodes

    Benefits:
        - Natural storage of multimodal attributes (different dimensions per modality)
        - Full PyG ecosystem compatibility (HeteroConv, HGT, NeighborLoader, etc.)
        - Flexible attribute management (each node/hyperedge type can have different features)

    Example:
        >>> # Create a simple hypergraph with 4 nodes and 2 hyperedges
        >>> # Hyperedge 0: nodes {0, 1, 2}
        >>> # Hyperedge 1: nodes {1, 2, 3}
        >>> data = HyperHeteroData()
        >>>
        >>> # Node features
        >>> data['node'].x = torch.randn(4, 16)  # 4 nodes, 16 features
        >>> data['node'].y = torch.tensor([0, 1, 1, 0])  # labels
        >>>
        >>> # Hyperedge features (optional)
        >>> data['hyperedge'].x = torch.randn(2, 8)  # 2 hyperedges, 8 features
        >>>
        >>> # Connections
        >>> edge_index = torch.tensor([
        ...     [0, 1, 2, 1, 2, 3],  # node indices
        ...     [0, 0, 0, 1, 1, 1]   # hyperedge indices
        ... ])
        >>> data['node', 'member_of', 'hyperedge'].edge_index = edge_index
        >>> data['hyperedge', 'has_member', 'node'].edge_index = edge_index[[1, 0]]
        >>>
        >>> print(data.num_hyperedges)
        2
    """

    def __init__(self, **kwargs: Any) -> None:
        """Initialize HyperHeteroData.

        Args:
            **kwargs: Additional keyword arguments passed to HeteroData
        """
        super().__init__(**kwargs)

    @property
    def num_hyperedges(self) -> int:
        """Return the number of hyperedges.

        Returns:
            Number of hyperedges in the hypergraph
        """
        if "hyperedge" in self.node_types:
            return self["hyperedge"].num_nodes
        return 0

    def get_multimodal_attributes(self) -> list[str]:
        """Return list of multimodal attribute names.

        Returns:
            List of attribute names (excluding standard attributes like 'x', 'y', 'edge_index')
        """
        if "node" not in self.node_types:
            return []

        exclude = {"x", "y", "edge_index", "num_nodes", "batch", "ptr"}
        return [k for k in self["node"].keys() if k not in exclude]  # noqa: SIM118

    def to_hyperedge_index(self) -> "HyperData":  # noqa: F821  # type: ignore[name-defined]
        """Convert to HyperData (hyperedge_index format).

        Returns:
            HyperData object with equivalent graph structure
        """
        from pyg_hyper_data.data.conversion import hetero_to_hyperedge_index

        return hetero_to_hyperedge_index(self)

    def validate(self, raise_on_error: bool = True) -> bool:  # noqa: ARG002
        """Validate the UBO hypergraph structure.

        Checks:
        - 'node' and 'hyperedge' node types exist
        - Required edge types exist
        - Edge indices are consistent

        Args:
            raise_on_error: Whether to raise an exception on validation error

        Returns:
            True if valid, raises ValueError otherwise

        Raises:
            ValueError: If validation fails
        """
        # Check node types
        if "node" not in self.node_types:
            msg = "Missing 'node' node type"
            raise ValueError(msg)

        if "hyperedge" not in self.node_types:
            msg = "Missing 'hyperedge' node type"
            raise ValueError(msg)

        # Check edge types
        required_edge_types = [
            ("node", "member_of", "hyperedge"),
            ("hyperedge", "has_member", "node"),
        ]

        for edge_type in required_edge_types:
            if edge_type not in self.edge_types:
                msg = f"Missing edge type: {edge_type}"
                raise ValueError(msg)

        # Check edge index consistency
        member_of_edge = self["node", "member_of", "hyperedge"].edge_index
        has_member_edge = self["hyperedge", "has_member", "node"].edge_index

        if member_of_edge is None:
            msg = "('node', 'member_of', 'hyperedge').edge_index is None"
            raise ValueError(msg)

        if has_member_edge is None:
            msg = "('hyperedge', 'has_member', 'node').edge_index is None"
            raise ValueError(msg)

        # Check that edges are consistent (reversed)
        if not torch.equal(member_of_edge, has_member_edge[[1, 0]]):
            msg = "Edge indices are not consistent (should be reverse of each other)"
            raise ValueError(msg)

        # Check node indices are valid
        num_nodes = self["node"].num_nodes
        num_hyperedges = self["hyperedge"].num_nodes

        if member_of_edge[0].max() >= num_nodes:
            msg = f"Node index {member_of_edge[0].max()} exceeds num_nodes {num_nodes}"
            raise ValueError(msg)

        if member_of_edge[1].max() >= num_hyperedges:
            msg = f"Hyperedge index {member_of_edge[1].max()} exceeds num_hyperedges {num_hyperedges}"
            raise ValueError(msg)

        return True

    def get_data_with_attributes(
        self, attributes: list[str] | None = None
    ) -> "HyperHeteroData":
        """Return a copy with only specified multimodal attributes.

        This is useful for filtering multimodal attributes before passing
        to a model that only uses specific modalities.

        Args:
            attributes: List of attribute names to keep (e.g., ['title', 'abstract'])
                       If None, all attributes are kept

        Returns:
            New HyperHeteroData with only specified attributes

        Example:
            >>> # Keep only title and abstract embeddings
            >>> filtered_data = data.get_data_with_attributes(['title', 'abstract'])
        """
        # Create a new instance
        new_data = HyperHeteroData()

        # Copy node data
        for node_type in self.node_types:
            for key, value in self[node_type].items():
                if node_type == "node" and attributes is not None:
                    # Filter attributes for 'node' type
                    exclude = {"x", "y", "edge_index", "num_nodes", "batch", "ptr"}
                    if key in exclude or key in attributes:
                        new_data[node_type][key] = value
                else:
                    # Copy all attributes for other node types
                    new_data[node_type][key] = value

        # Copy edge data
        for edge_type in self.edge_types:
            for key, value in self[edge_type].items():
                new_data[edge_type][key] = value

        return new_data

    def __repr__(self) -> str:
        """Return string representation of HyperHeteroData."""
        info = []

        if "node" in self.node_types:
            num_nodes = self["node"].num_nodes
            info.append(f"num_nodes={num_nodes}")

            if "x" in self["node"]:
                num_features = self["node"].x.size(1)
                info.append(f"num_node_features={num_features}")

            if "y" in self["node"]:
                num_classes = int(self["node"].y.max()) + 1
                info.append(f"num_classes={num_classes}")

        if "hyperedge" in self.node_types:
            num_hyperedges = self["hyperedge"].num_nodes
            info.append(f"num_hyperedges={num_hyperedges}")

            if "x" in self["hyperedge"]:
                num_edge_features = self["hyperedge"].x.size(1)
                info.append(f"num_edge_features={num_edge_features}")

        # Add multimodal attributes
        multimodal = self.get_multimodal_attributes()
        if multimodal:
            info.append(f"multimodal_attrs={multimodal}")

        return f"HyperHeteroData({', '.join(info)})"
