"""Hypergraph datasets."""

from pyg_hyper_data.datasets.base import (
    BaseHyperDataset,
    InMemoryHyperDataset,
    TriclDataset,
)
from pyg_hyper_data.datasets.coauthorship import CoraCoauthorship, DBLPCoauthorship
from pyg_hyper_data.datasets.cocitation import (
    CiteseerCocitation,
    CoraCocitation,
    PubmedCocitation,
)
from pyg_hyper_data.datasets.shape import NTU2012, ModelNet40
from pyg_hyper_data.datasets.text import News20
from pyg_hyper_data.datasets.uci import Mushroom, Zoo

__all__ = [
    "NTU2012",
    "BaseHyperDataset",
    "CiteseerCocitation",
    "CoraCoauthorship",
    "CoraCocitation",
    "DBLPCoauthorship",
    "InMemoryHyperDataset",
    "ModelNet40",
    "Mushroom",
    "News20",
    "PubmedCocitation",
    "TriclDataset",
    "Zoo",
]
