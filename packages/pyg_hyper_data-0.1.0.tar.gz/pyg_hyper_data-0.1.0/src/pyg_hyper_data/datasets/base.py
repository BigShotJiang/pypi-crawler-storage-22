"""Base dataset class for hypergraph datasets."""

import json
import logging
import pickle
from pathlib import Path
from typing import Literal

import torch
from scipy import sparse
from torch_geometric.data import Dataset
from torch_geometric.data.collate import collate
from torch_scatter import scatter_add

from pyg_hyper_data.config.paths import get_dataset_dir
from pyg_hyper_data.data import HyperData
from pyg_hyper_data.utils.download import download_tricl_data
from pyg_hyper_data.utils.stats import compute_hypergraph_statistics, log_statistics

logger = logging.getLogger(__name__)


class BaseHyperDataset(Dataset):
    """Base class for hypergraph datasets.

    This class extends PyG's Dataset class to provide common functionality
    for hypergraph datasets, including:
    - Automatic directory management in ~/.pyg-hyper/data/
    - Download and processing utilities
    - Statistics computation
    - Logging

    Args:
        root: Root directory where dataset should be stored.
            If None, uses ~/.pyg-hyper/data/<dataset_name>
        transform: Optional transform to be applied to data objects
        pre_transform: Optional transform to be applied before saving
        pre_filter: Optional filter function applied before saving
        force_reload: If True, re-download and re-process the dataset

    Attributes:
        name: Dataset name (set by subclass)

    Example:
        >>> class MyDataset(BaseHyperDataset):
        ...     name = "my-dataset"
        ...
        ...     def download(self):
        ...         # Download implementation
        ...         pass
        ...
        ...     def process(self):
        ...         # Processing implementation
        ...         pass
        ...
        ...     def len(self):
        ...         return 1
        ...
        ...     def get(self, idx):
        ...         return self.data
        ...
        >>> dataset = MyDataset()
        >>> data = dataset[0]
    """

    name: str = "base"

    def __init__(
        self,
        root: str | Path | None = None,
        transform=None,  # noqa: ANN001
        pre_transform=None,  # noqa: ANN001
        pre_filter=None,  # noqa: ANN001
        force_reload: bool = False,
    ) -> None:
        """Initialize dataset."""
        # Set root directory
        root = get_dataset_dir(self.name) if root is None else Path(root)

        self.force_reload = force_reload

        super().__init__(str(root), transform, pre_transform, pre_filter)

        logger.info("Initialized %s dataset at %s", self.name, self.root)

    @property
    def raw_file_names(self) -> list[str]:
        """Names of raw files in the raw directory.

        Returns:
            List of raw file names

        Note:
            Override this in subclass to specify which files should be
            checked for existence to determine if download is needed
        """
        return []

    @property
    def processed_file_names(self) -> list[str]:
        """Names of processed files in the processed directory.

        Returns:
            List of processed file names

        Note:
            Override this in subclass to specify which files should be
            checked for existence to determine if processing is needed
        """
        return ["data.pt"]

    def download(self) -> None:
        """Download raw data.

        Note:
            Override this in subclass to implement downloading logic
        """
        msg = f"download() not implemented for {self.__class__.__name__}"
        raise NotImplementedError(msg)

    def process(self) -> None:
        """Process raw data and save to processed directory.

        Note:
            Override this in subclass to implement processing logic
        """
        msg = f"process() not implemented for {self.__class__.__name__}"
        raise NotImplementedError(msg)

    def statistics(self, idx: int = 0) -> dict[str, float | int | list[int]]:
        """Compute statistics for a data object.

        Args:
            idx: Index of data object to compute statistics for

        Returns:
            Dictionary of statistics

        Example:
            >>> dataset = MyDataset()
            >>> stats = dataset.statistics(0)
            >>> logger.info(f"Nodes: {stats['num_nodes']}")
        """
        data = self.get(idx)
        return compute_hypergraph_statistics(data)  # type: ignore[arg-type,return-value]

    def log_statistics(self, idx: int = 0) -> None:
        """Log statistics for a data object.

        Args:
            idx: Index of data object to log statistics for

        Example:
            >>> dataset = MyDataset()
            >>> dataset.log_statistics(0)
        """
        data = self.get(idx)
        log_statistics(data, name=f"{self.name} [idx={idx}]")  # type: ignore[arg-type]

    def __repr__(self) -> str:
        """Return string representation of dataset."""
        return f"{self.__class__.__name__}(name={self.name}, root={self.root}, len={len(self)})"


class InMemoryHyperDataset(BaseHyperDataset):
    """Base class for in-memory hypergraph datasets.

    For datasets that fit entirely in memory, this class provides
    a simplified interface where the entire dataset is loaded at once.

    Args:
        root: Root directory where dataset should be stored
        transform: Optional transform to be applied to data objects
        pre_transform: Optional transform to be applied before saving
        pre_filter: Optional filter function applied before saving
        force_reload: If True, re-download and re-process the dataset

    Attributes:
        data: Single HyperData object containing the entire dataset
        slices: Dictionary mapping attribute names to slice indices

    Example:
        >>> class MyInMemoryDataset(InMemoryHyperDataset):
        ...     name = "my-dataset"
        ...
        ...     def download(self):
        ...         # Download implementation
        ...         pass
        ...
        ...     def process(self):
        ...         # Create data objects
        ...         data_list = [...]
        ...         self.save_data_list(data_list)
        ...
        >>> dataset = MyInMemoryDataset()
        >>> data = dataset[0]
    """

    def __init__(
        self,
        root: str | Path | None = None,
        transform=None,  # noqa: ANN001
        pre_transform=None,  # noqa: ANN001
        pre_filter=None,  # noqa: ANN001
        force_reload: bool = False,
    ) -> None:
        """Initialize in-memory dataset."""
        self.data: HyperData | None = None
        self.slices: dict | None = None

        super().__init__(root, transform, pre_transform, pre_filter, force_reload)

        # Load processed data
        self.load()

    def load(self) -> None:
        """Load processed data from disk.

        Note:
            Subclass should implement this to load self.data and self.slices
        """
        msg = f"load() not implemented for {self.__class__.__name__}"
        raise NotImplementedError(msg)

    def len(self) -> int:
        """Return number of graphs in dataset."""
        if self.slices is None:
            return 0
        return len(self.slices[next(iter(self.slices.keys()))]) - 1

    def get(self, idx: int) -> HyperData:
        """Get a single data object.

        Args:
            idx: Index of data object to retrieve

        Returns:
            HyperData object
        """
        if self.data is None or self.slices is None:
            msg = "Dataset not loaded"
            raise RuntimeError(msg)

        # Get slices for this index
        data = HyperData()
        for key in self.data.keys():  # noqa: SIM118
            item = self.data[key]
            # Skip keys that don't have slices (like 'batch')
            if key not in self.slices:
                continue
            if self.slices[key] is not None:
                s = self.slices[key]
                data[key] = item[s[idx] : s[idx + 1]]
            else:
                data[key] = item

        return data


class TriclDataset(InMemoryHyperDataset):
    """Base class for datasets from the TriCL repository.

    This class provides common functionality for loading hypergraph datasets
    from the TriCL (Triangle Contrastive Learning) repository, which contains
    standard benchmark datasets for hypergraph learning research.

    The TriCL datasets are stored in pickle format with the following structure:
        - features.pickle: Node features (scipy sparse matrix or numpy array)
        - hypergraph.pickle: Hypergraph structure (dict[edge_id, list[node_ids]])
        - labels.pickle: Node labels (numpy array)
        - splits/: Train/val/test splits (multiple seeds)

    Subclasses should set:
        - dataset_name: Name of the dataset (e.g., "cora", "citeseer", "pubmed")
        - dataset_type: Type of hypergraph ("cocitation" or "coauthorship")

    Args:
        root: Root directory where dataset should be stored.
            If None, uses ~/.pyg-hyper/data/{dataset_type}-{dataset_name}
        transform: Optional transform to be applied to data objects
        pre_transform: Optional transform to be applied before saving
        pre_filter: Optional filter function applied before saving
        force_reload: If True, re-download and re-process the dataset

    Example:
        >>> class CoraCocitation(TriclDataset):
        ...     dataset_name = "cora"
        ...     dataset_type = "cocitation"
        ...
        >>> dataset = CoraCocitation()
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}, Hyperedges: {data.num_hyperedges}")
    """

    # Configuration to be set by subclasses
    dataset_name: str = ""  # e.g., "cora", "pubmed", "dblp"
    dataset_type: str = ""  # "cocitation" or "coauthorship"

    def __init__(
        self,
        root: str | Path | None = None,
        transform=None,  # noqa: ANN001
        pre_transform=None,  # noqa: ANN001
        pre_filter=None,  # noqa: ANN001
        force_reload: bool = False,
    ) -> None:
        """Initialize TriCL dataset."""
        if not self.dataset_name or not self.dataset_type:
            msg = (
                "Subclass must set dataset_name and dataset_type. "
                f"Got dataset_name='{self.dataset_name}', dataset_type='{self.dataset_type}'"
            )
            raise ValueError(msg)

        # Set name for directory structure
        self.name = f"{self.dataset_type}-{self.dataset_name}"

        super().__init__(root, transform, pre_transform, pre_filter, force_reload)

        # Load statistics
        self._load_stats()

        logger.info("Loaded %s dataset", self.name)
        logger.info("  Nodes: %d", self.data.num_nodes)  # type: ignore[union-attr]
        logger.info("  Hyperedges: %d", self.data.num_hyperedges)  # type: ignore[union-attr]
        logger.info("  Features: %d", self.data.x.shape[1])  # type: ignore[union-attr]
        logger.info("  Classes: %d", int(self.data.y.max()) + 1)  # type: ignore[union-attr]

    def load(self) -> None:
        """Load processed data from disk."""
        self.data, self.slices = torch.load(self.processed_paths[0], weights_only=False)

    @property
    def raw_dir(self) -> str:
        """Get the directory containing the raw data."""
        # Raw data is in root/{dataset_type}/{dataset_name}/
        return str(Path(self.root) / self.dataset_type / self.dataset_name)

    @property
    def processed_dir(self) -> str:
        """Get the directory containing the processed data."""
        # Processed data in root/processed/{dataset_type}-{dataset_name}/
        return str(Path(self.root) / "processed" / self.name)

    @property
    def raw_file_names(self) -> list[str]:
        """Names of raw files in the raw directory."""
        return ["features.pickle", "hypergraph.pickle", "labels.pickle", "splits"]

    @property
    def processed_file_names(self) -> list[str]:
        """Names of processed files."""
        return ["data.pt"]

    def download(self) -> None:
        """Download raw data from TriCL repository."""
        logger.info("Checking for %s dataset...", self.name)

        # Download TriCL data if not exists
        # download_tricl_data will check if data already exists
        root = Path(self.root)
        download_tricl_data(root)

    def process(self) -> None:
        """Process raw TriCL pickle data into HyperData format."""
        logger.info("Processing %s dataset...", self.name)

        raw_dir = Path(self.raw_dir)

        # Load pickle files
        with (raw_dir / "features.pickle").open("rb") as f:
            features = pickle.load(f)  # noqa: S301

        with (raw_dir / "hypergraph.pickle").open("rb") as f:
            hypergraph = pickle.load(f)  # noqa: S301

        with (raw_dir / "labels.pickle").open("rb") as f:
            labels = pickle.load(f)  # noqa: S301

        # Convert hypergraph dict to hyperedge_index tensor
        # Format: {edge_id: [node_ids]} -> tensor [[node, edge], ...]
        # Note: edge_ids may not be consecutive, so we need to remap them
        edge_list = []
        edge_ids = sorted(hypergraph.keys())  # Ensure consistent ordering

        for new_edge_id, old_edge_id in enumerate(edge_ids):
            node_ids = hypergraph[old_edge_id]
            edge_list.extend([[node_id, new_edge_id] for node_id in node_ids])

        hyperedge_index = torch.tensor(edge_list, dtype=torch.long).T.contiguous()

        # Convert features to tensor
        if sparse.issparse(features):
            x = torch.tensor(features.toarray(), dtype=torch.float)
        else:
            x = torch.tensor(features, dtype=torch.float)

        # Convert labels to tensor
        y = torch.tensor(labels, dtype=torch.long)

        # Create HyperData object
        data = HyperData(
            x=x,
            hyperedge_index=hyperedge_index,
            y=y,
            num_nodes=x.shape[0],
            num_hyperedges=len(edge_ids),
        )

        # Compute node and edge degrees
        data.node_degree = scatter_add(
            torch.ones(hyperedge_index.shape[1]),
            hyperedge_index[0],
            dim=0,
            dim_size=data.num_nodes,
        )
        data.edge_size = scatter_add(
            torch.ones(hyperedge_index.shape[1]),
            hyperedge_index[1],
            dim=0,
            dim_size=data.num_hyperedges,
        )

        logger.info(
            "Converted %d edges to %d hyperedges",
            hyperedge_index.shape[1],
            data.num_hyperedges,
        )

        # Apply pre-filter and pre-transform
        if self.pre_filter is not None and not self.pre_filter(data):
            logger.warning("Data filtered out by pre_filter")
            return

        if self.pre_transform is not None:
            data = self.pre_transform(data)

        # Save processed data
        collated_data, slices, _ = collate(HyperData, [data])
        torch.save((collated_data, slices), self.processed_paths[0])

        # Save statistics
        self._save_stats(data)

        logger.info("Saved processed data to %s", self.processed_paths[0])

    def _save_stats(self, data: HyperData) -> None:
        """Save dataset statistics to JSON file."""
        stats = compute_hypergraph_statistics(data)

        # Add label statistics
        stats["num_classes"] = int(data.y.max()) + 1  # type: ignore[union-attr]
        stats["num_features"] = int(data.x.shape[1])  # type: ignore[union-attr]

        # Save to JSON
        stats_path = Path(self.processed_dir) / "stats.json"
        with stats_path.open("w") as f:
            json.dump(stats, f, indent=2)

        logger.info("Saved statistics to %s", stats_path)

    def _load_stats(self) -> None:
        """Load dataset statistics from JSON file."""
        stats_path = Path(self.processed_dir) / "stats.json"
        if stats_path.exists():
            with stats_path.open("r") as f:
                self.stats = json.load(f)
        else:
            # Compute statistics if not saved
            self.stats = compute_hypergraph_statistics(self.data)  # type: ignore[arg-type]
            self.stats["num_classes"] = int(self.data.y.max()) + 1  # type: ignore[union-attr]
            self.stats["num_features"] = int(self.data.x.shape[1])  # type: ignore[union-attr]

    def get_split(self, seed: int = 0) -> dict[str, torch.Tensor]:
        """Get train/val/test split masks for a specific seed.

        Args:
            seed: Random seed for the split (default: 0)

        Returns:
            Dictionary with 'train_mask', 'val_mask', 'test_mask'

        Raises:
            FileNotFoundError: If split file for the given seed doesn't exist
        """
        splits_file = Path(self.raw_dir) / "splits" / f"{seed}.pickle"

        if not splits_file.exists():
            msg = f"Split file for seed {seed} not found at {splits_file}"
            raise FileNotFoundError(msg)

        with splits_file.open("rb") as f:
            splits = pickle.load(f)  # noqa: S301

        return {
            "train_mask": torch.tensor(splits["train_mask"], dtype=torch.bool),
            "val_mask": torch.tensor(splits["val_mask"], dtype=torch.bool),
            "test_mask": torch.tensor(splits["test_mask"], dtype=torch.bool),
        }


class DHGBenchDataset(InMemoryHyperDataset):
    """Base class for datasets from the DHG-Bench repository.

    This class provides functionality for loading hypergraph datasets from the
    DHG-Bench (Deep Hypergraph Learning Benchmark) repository, which contains
    standard benchmark datasets with preserved node IDs for multimodal feature collection.

    Key features:
        - Flexible isolated node handling (remove_isolated_nodes parameter)
        - Original node ID preservation for multimodal features
        - Planetoid-compatible node ordering
        - Compatible with TriCL statistics when isolated nodes are removed
        - Text features support via HuggingFace TAG dataset (Cora, Pubmed only)

    The DHG-Bench datasets are stored in pickle format with the following structure:
        - features.pickle: Node features (scipy sparse matrix or numpy array)
        - hypergraph.pickle: Hypergraph structure (dict[edge_id, set[node_ids]])
        - labels.pickle: Node labels (numpy array)
        - splits/: Train/val/test splits (10 seeds, 1.pickle to 10.pickle)

    Text Features Support:
        For Cora and Pubmed datasets, you can load text features (paper titles + abstracts)
        from the HuggingFace TAG dataset by setting load_text_features=True.
        This adds separate title and abstract attributes to the HyperData object:
        - data.title (list of title strings)
        - data.abstract (list of abstract strings)
        - data.title_embeddings (torch.Tensor)
        - data.abstract_embeddings (torch.Tensor)

        Use load_text_features="lazy" for memory-efficient on-demand loading via:
        - data.load_title()
        - data.load_abstract()
        - data.load_title_embeddings()
        - data.load_abstract_embeddings()

        Note: Citeseer is NOT supported due to incompatible node counts between
        DHG-Bench (3,312 nodes) and TAG (3,186 nodes).

    Subclasses should set:
        - dataset_name: Name of the dataset (e.g., "cora", "citeseer", "pubmed")
        - dataset_type: Type of hypergraph ("cocitation", "coauthorship", "shape", etc.)

    Args:
        root: Root directory where dataset should be stored.
            If None, uses ~/.pyg-hyper/data/{dataset_type}-{dataset_name}
        remove_isolated_nodes: If True, remove nodes not connected to any hyperedge.
            When True, statistics match TriCL. When False, all nodes are preserved.
            (default: True for backward compatibility)
        load_text_features: If True, load text features from HuggingFace TAG dataset.
            If "lazy", enable lazy loading (load on-demand via methods).
            Only supported for Cora and Pubmed. (default: False)
        encoder_model: Sentence-transformer model name for encoding texts.
            (default: "all-mpnet-base-v2" which produces 768-dim embeddings)
        transform: Optional transform to be applied to data objects
        pre_transform: Optional transform to be applied before saving
        pre_filter: Optional filter function applied before saving
        force_reload: If True, re-download and re-process the dataset

    Example:
        >>> # Basic usage (no text features)
        >>> dataset = CoraCocitation(remove_isolated_nodes=True)
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}")  # 1434
        >>>
        >>> # With text features (eager loading)
        >>> dataset = CoraCocitation(
        ...     remove_isolated_nodes=False,
        ...     load_text_features=True
        ... )
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}")  # 2708
        >>> print(f"Titles: {len(data.title)}")  # 2708
        >>> print(f"Abstracts: {len(data.abstract)}")  # 2708
        >>> print(f"Title embeddings: {data.title_embeddings.shape}")  # [2708, 768]
        >>> print(f"Abstract embeddings: {data.abstract_embeddings.shape}")  # [2708, 768]
        >>>
        >>> # With text features (lazy loading for large datasets)
        >>> dataset = PubmedCocitation(
        ...     remove_isolated_nodes=False,
        ...     load_text_features="lazy"
        ... )
        >>> data = dataset[0]
        >>> titles = data.load_title()  # Load on-demand
        >>> abstracts = data.load_abstract()
        >>> title_emb = data.load_title_embeddings()
        >>> abstract_emb = data.load_abstract_embeddings()

    References:
        - DHG-Bench: A Comprehensive Benchmark for Deep Hypergraph Learning (ICLR 2026)
        - https://github.com/Coco-Hut/DHG-Bench
        - TAG: HuggingFace Text-Attributed-Graphs dataset
        - https://huggingface.co/datasets/Graph-COM/Text-Attributed-Graphs
    """

    # Configuration to be set by subclasses
    dataset_name: str = ""  # e.g., "cora", "pubmed", "dblp"
    dataset_type: str = ""  # "cocitation", "coauthorship", "shape", etc.

    def __init__(
        self,
        root: str | Path | None = None,
        remove_isolated_nodes: bool = True,
        load_text_features: bool | Literal["lazy"] = False,
        encoder_model: str | None = None,
        transform=None,  # noqa: ANN001
        pre_transform=None,  # noqa: ANN001
        pre_filter=None,  # noqa: ANN001
        force_reload: bool = False,
    ) -> None:
        """Initialize DHG-Bench dataset."""
        if not self.dataset_name or not self.dataset_type:
            msg = (
                "Subclass must set dataset_name and dataset_type. "
                f"Got dataset_name='{self.dataset_name}', dataset_type='{self.dataset_type}'"
            )
            raise ValueError(msg)

        # Set name for directory structure
        self.name = f"{self.dataset_type}-{self.dataset_name}"
        self.remove_isolated_nodes = remove_isolated_nodes
        self.load_text_features = load_text_features
        self.encoder_model = encoder_model

        # Store node ID mapping for multimodal features
        self.node_id_map: dict[int, int] | None = None

        # Set up text features transform if requested
        if load_text_features:
            from pyg_hyper_data.config.text import (
                DEFAULT_ENCODER_MODEL,
                TextEncoderConfig,
                is_text_supported,
            )
            from pyg_hyper_data.transforms.text import (
                LazyTextFeaturesTransform,
                TextFeaturesTransform,
            )

            # Validate dataset support
            if not is_text_supported(self.dataset_name, self.dataset_type):
                msg = (
                    f"Dataset '{self.name}' does not support TAG text features. "
                    f"Supported: Cora (cocitation), Pubmed (cocitation). "
                    f"Citeseer is NOT supported (incompatible node counts: DHG 3,312 vs TAG 3,186)."
                )
                raise ValueError(msg)

            # Get multimodal directory
            if root is None:
                from pyg_hyper_data.config.paths import get_dataset_dir

                root = get_dataset_dir(self.name)
            multimodal_dir = Path(root) / "multimodal"

            # Create encoder config
            encoder_config = TextEncoderConfig(
                model_name=encoder_model or DEFAULT_ENCODER_MODEL
            )

            # Create transform (eager or lazy)
            transform_cls = (
                LazyTextFeaturesTransform
                if load_text_features == "lazy"
                else TextFeaturesTransform
            )

            text_transform = transform_cls(
                dataset_name=self.dataset_name,
                cache_dir=multimodal_dir,
                encoder_config=encoder_config,
                node_id_map=None,  # Updated later in process()
                force_redownload=force_reload,
                force_reencode=force_reload,
            )

            # Chain with existing pre_transform
            if pre_transform is not None:
                original_pre_transform = pre_transform

                def combined_pre_transform(data):  # noqa: ANN001
                    data = original_pre_transform(data)
                    return text_transform(data)

                pre_transform = combined_pre_transform
            else:
                pre_transform = text_transform

            # Store for node_id_map update in process()
            self._text_transform = text_transform

            logger.info(
                "Text features enabled: %s (encoder: %s)",
                "lazy" if load_text_features == "lazy" else "eager",
                encoder_config.model_name,
            )

        super().__init__(root, transform, pre_transform, pre_filter, force_reload)

        # Load statistics
        self._load_stats()

        logger.info("Loaded %s dataset", self.name)
        logger.info("  Nodes: %d", self.data.num_nodes)  # type: ignore[union-attr]
        logger.info("  Hyperedges: %d", self.data.num_hyperedges)  # type: ignore[union-attr]
        logger.info("  Features: %d", self.data.x.shape[1])  # type: ignore[union-attr]
        logger.info("  Classes: %d", int(self.data.y.max()) + 1)  # type: ignore[union-attr]
        logger.info("  Isolated nodes removed: %s", self.remove_isolated_nodes)

    def load(self) -> None:
        """Load processed data from disk."""
        self.data, self.slices = torch.load(self.processed_paths[0], weights_only=False)

        # Load node_id_map if it exists
        node_id_map_path = Path(self.processed_dir) / "node_id_map.json"
        if node_id_map_path.exists():
            with node_id_map_path.open("r") as f:
                # Convert string keys back to integers
                self.node_id_map = {int(k): v for k, v in json.load(f).items()}
            logger.info("Loaded node_id_map from %s", node_id_map_path)

    @property
    def raw_dir(self) -> str:
        """Get the directory containing the raw data."""
        # Raw data is in root/{dataset_type}/{dataset_name}/
        return str(Path(self.root) / self.dataset_type / self.dataset_name)

    @property
    def processed_dir(self) -> str:
        """Get the directory containing the processed data."""
        # Add suffix based on isolated node handling
        suffix = "no-isolated" if self.remove_isolated_nodes else "with-isolated"
        # Processed data in root/processed/{dataset_type}-{dataset_name}-{suffix}/
        return str(Path(self.root) / "processed" / f"{self.name}-{suffix}")

    @property
    def raw_file_names(self) -> list[str]:
        """Names of raw files in the raw directory."""
        return ["features.pickle", "hypergraph.pickle", "labels.pickle", "splits"]

    @property
    def processed_file_names(self) -> list[str]:
        """Names of processed files."""
        return ["data.pt"]

    def download(self) -> None:
        """Download raw data from DHG-Bench repository."""
        logger.info("Checking for %s dataset...", self.name)

        # Import here to avoid circular dependency
        from pyg_hyper_data.utils.download import download_dhgbench_data

        # Download DHG-Bench data if not exists
        root = Path(self.root)
        download_dhgbench_data(root, self.dataset_type, self.dataset_name)

    def process(self) -> None:
        """Process raw DHG-Bench pickle data into HyperData format."""
        logger.info("Processing %s dataset...", self.name)
        logger.info("  Remove isolated nodes: %s", self.remove_isolated_nodes)

        raw_dir = Path(self.raw_dir)

        # Load pickle files
        with (raw_dir / "features.pickle").open("rb") as f:
            features = pickle.load(f)  # noqa: S301

        with (raw_dir / "hypergraph.pickle").open("rb") as f:
            hypergraph = pickle.load(f)  # noqa: S301

        with (raw_dir / "labels.pickle").open("rb") as f:
            labels = pickle.load(f)  # noqa: S301

        # Convert labels to numpy array if it's a list
        import numpy as np

        if isinstance(labels, list):
            labels = np.array(labels)

        # Get total number of nodes from features
        total_nodes = features.shape[0]
        logger.info("  Total nodes in dataset: %d", total_nodes)

        # Identify connected nodes (nodes that appear in hypergraph)
        connected_nodes = set()
        for node_set in hypergraph.values():
            connected_nodes.update(node_set)

        num_connected = len(connected_nodes)
        num_isolated = total_nodes - num_connected
        logger.info("  Connected nodes: %d", num_connected)
        logger.info("  Isolated nodes: %d", num_isolated)

        if self.remove_isolated_nodes and num_isolated > 0:
            # Create node ID mapping: old_id -> new_id
            connected_nodes_list = sorted(connected_nodes)
            self.node_id_map = {
                old_id: new_id for new_id, old_id in enumerate(connected_nodes_list)
            }

            # Remap hypergraph node IDs
            remapped_hypergraph = {}
            for edge_id, node_set in hypergraph.items():
                remapped_hypergraph[edge_id] = [
                    self.node_id_map[node_id] for node_id in node_set
                ]

            # Filter features and labels
            if sparse.issparse(features):
                features = features[connected_nodes_list, :]
            else:
                features = features[connected_nodes_list]

            labels = labels[connected_nodes_list]

            hypergraph = remapped_hypergraph
            num_nodes = num_connected

            logger.info("  Removed %d isolated nodes", num_isolated)
            logger.info("  Remaining nodes: %d", num_nodes)
        else:
            # Keep all nodes, no ID remapping needed
            self.node_id_map = {i: i for i in range(total_nodes)}
            num_nodes = total_nodes

        # Convert hypergraph dict to hyperedge_index tensor
        # Format: {edge_id: [node_ids]} -> tensor [[node, edge], ...]
        # Note: edge_ids may not be consecutive, so we need to remap them
        edge_list = []
        edge_ids = sorted(hypergraph.keys())  # Ensure consistent ordering

        for new_edge_id, old_edge_id in enumerate(edge_ids):
            node_ids = hypergraph[old_edge_id]
            edge_list.extend([[node_id, new_edge_id] for node_id in node_ids])

        hyperedge_index = torch.tensor(edge_list, dtype=torch.long).T.contiguous()

        # Convert features to tensor
        if sparse.issparse(features):
            x = torch.tensor(features.toarray(), dtype=torch.float)
        else:
            x = torch.tensor(features, dtype=torch.float)

        # Convert labels to tensor
        y = torch.tensor(labels, dtype=torch.long)

        # Create HyperData object
        data = HyperData(
            x=x,
            hyperedge_index=hyperedge_index,
            y=y,
            num_nodes=num_nodes,
            num_hyperedges=len(edge_ids),
        )

        # Compute node and edge degrees
        data.node_degree = scatter_add(
            torch.ones(hyperedge_index.shape[1]),
            hyperedge_index[0],
            dim=0,
            dim_size=data.num_nodes,
        )
        data.edge_size = scatter_add(
            torch.ones(hyperedge_index.shape[1]),
            hyperedge_index[1],
            dim=0,
            dim_size=data.num_hyperedges,
        )

        logger.info(
            "Converted %d node-edge pairs to %d hyperedges",
            hyperedge_index.shape[1],
            data.num_hyperedges,
        )

        # Apply pre-filter and pre-transform
        if self.pre_filter is not None and not self.pre_filter(data):
            logger.warning("Data filtered out by pre_filter")
            return

        if self.pre_transform is not None:
            data = self.pre_transform(data)

            # Update text transform with node_id_map if text features enabled
            if hasattr(self, "_text_transform") and self.node_id_map is not None:
                self._text_transform.node_id_map = self.node_id_map
                logger.info(
                    "Updated text transform with node_id_map (%d nodes)",
                    len(self.node_id_map),
                )

        # Save processed data
        collated_data, slices, _ = collate(HyperData, [data])
        torch.save((collated_data, slices), self.processed_paths[0])

        # Save node_id_map if it exists
        if self.node_id_map is not None:
            node_id_map_path = Path(self.processed_dir) / "node_id_map.json"
            with node_id_map_path.open("w") as f:
                # Convert keys to strings for JSON serialization
                json.dump({str(k): v for k, v in self.node_id_map.items()}, f)
            logger.info("Saved node_id_map to %s", node_id_map_path)

        # Save statistics
        self._save_stats(data)

        logger.info("Saved processed data to %s", self.processed_paths[0])

    def _save_stats(self, data: HyperData) -> None:
        """Save dataset statistics to JSON file."""
        stats = compute_hypergraph_statistics(data)

        # Add label statistics
        stats["num_classes"] = int(data.y.max()) + 1  # type: ignore[union-attr]
        stats["num_features"] = int(data.x.shape[1])  # type: ignore[union-attr]
        stats["remove_isolated_nodes"] = self.remove_isolated_nodes

        # Save to JSON
        stats_path = Path(self.processed_dir) / "stats.json"
        with stats_path.open("w") as f:
            json.dump(stats, f, indent=2)

        logger.info("Saved statistics to %s", stats_path)

    def _load_stats(self) -> None:
        """Load dataset statistics from JSON file."""
        stats_path = Path(self.processed_dir) / "stats.json"
        if stats_path.exists():
            with stats_path.open("r") as f:
                self.stats = json.load(f)
        else:
            # Compute statistics if not saved
            self.stats = compute_hypergraph_statistics(self.data)  # type: ignore[arg-type]
            self.stats["num_classes"] = int(self.data.y.max()) + 1  # type: ignore[union-attr]
            self.stats["num_features"] = int(self.data.x.shape[1])  # type: ignore[union-attr]

    def get_split(
        self, seed: int = 1, val_ratio: float = 0.25
    ) -> dict[str, torch.Tensor]:
        """Get train/val/test split masks for a specific seed.

        Args:
            seed: Random seed for the split (1-10, default: 1)
            val_ratio: Ratio of training set to use for validation (default: 0.25)

        Returns:
            Dictionary with 'train_mask', 'val_mask', 'test_mask'

        Raises:
            FileNotFoundError: If split file for the given seed doesn't exist

        Note:
            DHG-Bench provides 10 pre-defined splits (seeds 1-10) with train/test only.
            This method creates a validation split by taking val_ratio of the training set.
            The masks are automatically adjusted if isolated nodes were removed.
        """
        import numpy as np

        splits_file = Path(self.raw_dir) / "splits" / f"{seed}.pickle"

        if not splits_file.exists():
            msg = f"Split file for seed {seed} not found at {splits_file}. DHG-Bench provides splits 1-10."
            raise FileNotFoundError(msg)

        with splits_file.open("rb") as f:
            splits = pickle.load(f)  # noqa: S301

        # Check format: DHG-Bench uses {'train': [indices], 'test': [indices]}
        # while TriCL uses {'train_mask': bool_array, 'val_mask': bool_array, 'test_mask': bool_array}
        if "train" in splits and "test" in splits:
            # DHG-Bench format: index lists
            train_indices = np.array(splits["train"])
            test_indices = np.array(splits["test"])

            # Determine total number of nodes (from raw data before filtering)
            num_total_nodes = len(train_indices) + len(test_indices)

            # Create validation split from training indices
            rng = np.random.default_rng(seed)
            rng.shuffle(train_indices)
            val_size = int(len(train_indices) * val_ratio)
            val_indices = train_indices[:val_size]
            train_indices = train_indices[val_size:]

            # Convert indices to boolean masks
            train_mask = np.zeros(num_total_nodes, dtype=bool)
            val_mask = np.zeros(num_total_nodes, dtype=bool)
            test_mask = np.zeros(num_total_nodes, dtype=bool)

            train_mask[train_indices] = True
            val_mask[val_indices] = True
            test_mask[test_indices] = True

        elif "train_mask" in splits and "val_mask" in splits and "test_mask" in splits:
            # TriCL format: boolean masks (legacy)
            train_mask = splits["train_mask"]
            val_mask = splits["val_mask"]
            test_mask = splits["test_mask"]

        else:
            msg = f"Unknown split format in {splits_file}. Expected either DHG-Bench format (train/test) or TriCL format (train_mask/val_mask/test_mask)"
            raise ValueError(msg)

        # If isolated nodes were removed, we need to adjust the masks
        if self.remove_isolated_nodes and self.node_id_map is not None:
            # Get original indices that were kept
            original_indices = sorted(self.node_id_map.keys())

            # Filter masks to only include kept nodes
            train_mask = train_mask[original_indices]
            val_mask = val_mask[original_indices]
            test_mask = test_mask[original_indices]

        return {
            "train_mask": torch.tensor(train_mask, dtype=torch.bool),
            "val_mask": torch.tensor(val_mask, dtype=torch.bool),
            "test_mask": torch.tensor(test_mask, dtype=torch.bool),
        }
