"""Co-authorship hypergraph datasets.

Co-authorship hypergraphs are constructed from citation networks where papers
written by the same group of authors are connected through hyperedges. Each
hyperedge represents a set of papers that share a common author.

This construction captures the collaboration patterns among papers, making it
useful for document classification tasks that leverage authorship information.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pyg_hyper_data.datasets.base import DHGBenchDataset

if TYPE_CHECKING:
    from pathlib import Path

__all__ = [
    "CoraCoauthorship",
    "DBLPCoauthorship",
]


class CoraCoauthorship(DHGBenchDataset):
    """Cora co-authorship hypergraph dataset from DHG-Bench.

    The Cora dataset contains scientific publications classified into seven
    categories: Case_Based, Genetic_Algorithms, Neural_Networks,
    Probabilistic_Methods, Reinforcement_Learning, Rule_Learning, and Theory.

    In the co-authorship construction, papers written by the same authors
    are connected through hyperedges.

    Statistics (with remove_isolated_nodes=True, TriCL-compatible):
        - Nodes: 2,388 papers (connected nodes only)
        - Hyperedges: 1,072 co-authorship hyperedges
        - Features: 1,433 bag-of-words features
        - Classes: 7 categories
        - Avg. hyperedge size: ~4.3 papers

    Statistics (with remove_isolated_nodes=False, full DHG-Bench):
        - Total nodes: 2,708 papers (320 isolated + 2,388 connected)
        - Hyperedges: 1,072 co-authorship hyperedges
        - Features: 1,433 bag-of-words features
        - Classes: 7 categories

    Args:
        root: Root directory where dataset should be stored.
            If None, uses ~/.pyg-hyper/data/coauthorship-cora
        remove_isolated_nodes: If True, remove isolated nodes for TriCL compatibility.
            If False, preserve all nodes including isolated ones (default: True)
        transform: Optional transform to be applied to data objects
        pre_transform: Optional transform to be applied before saving
        pre_filter: Optional filter function applied before saving
        force_reload: If True, re-download and re-process the dataset

    Example:
        >>> dataset = CoraCoauthorship()
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}, Hyperedges: {data.num_hyperedges}")
        Nodes: 2388, Hyperedges: 1072
        >>> # Get train/val/test split (DHG-Bench uses seeds 1-10)
        >>> splits = dataset.get_split(seed=1)
        >>> train_mask = splits['train_mask']

    References:
        - DHG-Bench: A Comprehensive Benchmark for Deep Hypergraph Learning (ICLR 2026)
        - HyperGCN: Hypergraph Convolutional Networks (Feng et al., 2019)
        - TriCL: Triangle-based Contrastive Learning (Woo et al., 2022)
    """

    dataset_name: str = "cora"
    dataset_type: str = "coauthorship"

    def __init__(
        self,
        root: str | Path | None = None,
        remove_isolated_nodes: bool = True,
        transform=None,  # noqa: ANN001
        pre_transform=None,  # noqa: ANN001
        pre_filter=None,  # noqa: ANN001
        force_reload: bool = False,
    ) -> None:
        """Initialize Cora co-authorship dataset."""
        super().__init__(
            root,
            remove_isolated_nodes,
            False,  # load_text_features (not supported)
            None,  # encoder_model (not supported)
            transform,
            pre_transform,
            pre_filter,
            force_reload,
        )


class DBLPCoauthorship(DHGBenchDataset):
    """DBLP co-authorship hypergraph dataset from DHG-Bench.

    The DBLP dataset contains scientific publications from the DBLP computer
    science bibliography, classified into six categories: Database, Data_Mining,
    AI, Information_Retrieval, and others.

    In the co-authorship construction, papers written by the same authors
    are connected through hyperedges.

    Statistics (with remove_isolated_nodes=True, TriCL-compatible):
        - Nodes: 41,302 papers (connected nodes only)
        - Hyperedges: 22,363 co-authorship hyperedges
        - Features: 1,425 bag-of-words features
        - Classes: 6 categories
        - Avg. hyperedge size: ~4.5 papers

    Statistics (with remove_isolated_nodes=False, full DHG-Bench):
        - Total nodes: 41,302 papers (0 isolated + 41,302 connected)
        - Hyperedges: 22,363 co-authorship hyperedges
        - Features: 1,425 bag-of-words features
        - Classes: 6 categories

    Args:
        root: Root directory where dataset should be stored.
            If None, uses ~/.pyg-hyper/data/coauthorship-dblp
        remove_isolated_nodes: If True, remove isolated nodes for TriCL compatibility.
            If False, preserve all nodes including isolated ones (default: True)
        transform: Optional transform to be applied to data objects
        pre_transform: Optional transform to be applied before saving
        pre_filter: Optional filter function applied before saving
        force_reload: If True, re-download and re-process the dataset

    Example:
        >>> dataset = DBLPCoauthorship()
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}, Hyperedges: {data.num_hyperedges}")
        Nodes: 41302, Hyperedges: 22363
        >>> # Get train/val/test split (DHG-Bench uses seeds 1-10)
        >>> splits = dataset.get_split(seed=1)
        >>> train_mask = splits['train_mask']

    References:
        - DHG-Bench: A Comprehensive Benchmark for Deep Hypergraph Learning (ICLR 2026)
        - HyperGCN: Hypergraph Convolutional Networks (Feng et al., 2019)
        - TriCL: Triangle-based Contrastive Learning (Woo et al., 2022)
    """

    dataset_name: str = "dblp"
    dataset_type: str = "coauthorship"

    def __init__(
        self,
        root: str | Path | None = None,
        remove_isolated_nodes: bool = True,
        transform=None,  # noqa: ANN001
        pre_transform=None,  # noqa: ANN001
        pre_filter=None,  # noqa: ANN001
        force_reload: bool = False,
    ) -> None:
        """Initialize DBLP co-authorship dataset."""
        super().__init__(
            root,
            remove_isolated_nodes,
            False,  # load_text_features (not supported)
            None,  # encoder_model (not supported)
            transform,
            pre_transform,
            pre_filter,
            force_reload,
        )
