"""Co-citation hypergraph datasets.

Co-citation hypergraphs are constructed from citation networks where papers that
cite the same references are connected through hyperedges. Each hyperedge represents
a set of papers that all cite a common reference.

This construction captures the semantic similarity of papers based on their
shared references, making it useful for document classification and clustering tasks.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from pyg_hyper_data.datasets.base import DHGBenchDataset

if TYPE_CHECKING:
    from pathlib import Path

__all__ = [
    "CiteseerCocitation",
    "CoraCocitation",
    "PubmedCocitation",
]


class CoraCocitation(DHGBenchDataset):
    """Cora co-citation hypergraph dataset from DHG-Bench.

    The Cora dataset contains scientific publications classified into seven
    categories: Case_Based, Genetic_Algorithms, Neural_Networks,
    Probabilistic_Methods, Reinforcement_Learning, Rule_Learning, and Theory.

    In the co-citation construction, papers that cite the same references
    are connected through hyperedges.

    Statistics (with remove_isolated_nodes=True, TriCL-compatible):
        - Nodes: 1,434 papers (connected nodes only)
        - Hyperedges: 1,579 co-citation hyperedges
        - Features: 1,433 bag-of-words features
        - Classes: 7 categories
        - Avg. hyperedge size: ~3.0 papers

    Statistics (with remove_isolated_nodes=False, full DHG-Bench):
        - Total nodes: 2,708 papers (1,274 isolated + 1,434 connected)
        - Hyperedges: 1,579 co-citation hyperedges
        - Features: 1,433 bag-of-words features
        - Classes: 7 categories

    Text Features Support:
        Cora supports text features from the HuggingFace TAG dataset! The TAG dataset
        provides perfect alignment with DHG-Bench (same 2,708 nodes, exact feature match).
        Text features include paper titles and abstracts encoded with sentence-transformers.

        Recommended: Use remove_isolated_nodes=False when loading text features to
        ensure alignment with the TAG dataset (2,708 nodes).

    Args:
        root: Root directory where dataset should be stored.
            If None, uses ~/.pyg-hyper/data/cocitation-cora
        remove_isolated_nodes: If True, remove isolated nodes for TriCL compatibility.
            If False, preserve all nodes including isolated ones (default: True)
        load_text_features: If True, load text features from HuggingFace TAG dataset.
            If "lazy", enable lazy loading for memory efficiency. (default: False)
        encoder_model: Sentence-transformer model for text encoding.
            (default: "all-mpnet-base-v2" for 768-dim embeddings)
        transform: Optional transform to be applied to data objects
        pre_transform: Optional transform to be applied before saving
        pre_filter: Optional filter function applied before saving
        force_reload: If True, re-download and re-process the dataset

    Example:
        >>> # Default: TriCL-compatible (isolated nodes removed, no text)
        >>> dataset = CoraCocitation()
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}, Hyperedges: {data.num_hyperedges}")
        Nodes: 1434, Hyperedges: 1579
        >>>
        >>> # With text features (eager loading)
        >>> dataset = CoraCocitation(
        ...     remove_isolated_nodes=False,
        ...     load_text_features=True
        ... )
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}")  # 2708
        >>> print(f"Titles: {len(data.title)}")  # 2708
        >>> print(f"Abstracts: {len(data.abstract)}")  # 2708
        >>> print(f"Title embeddings: {data.title_embeddings.shape}")  # [2708, 768]
        >>> print(data.title[0][:50])  # "Neural Networks..."
        >>>
        >>> # Get train/val/test split (DHG-Bench uses seeds 1-10)
        >>> splits = dataset.get_split(seed=1)
        >>> train_mask = splits['train_mask']

    References:
        - DHG-Bench: A Comprehensive Benchmark for Deep Hypergraph Learning (ICLR 2026)
        - TAG: HuggingFace Text-Attributed-Graphs
        - https://huggingface.co/datasets/Graph-COM/Text-Attributed-Graphs
        - HyperGCN: Hypergraph Convolutional Networks (Feng et al., 2019)
        - TriCL: Triangle-based Contrastive Learning (Woo et al., 2022)
    """

    dataset_name: str = "cora"
    dataset_type: str = "cocitation"

    def __init__(
        self,
        root: str | Path | None = None,
        remove_isolated_nodes: bool = True,
        load_text_features: bool | Literal["lazy"] = False,
        encoder_model: str | None = None,
        transform=None,  # noqa: ANN001
        pre_transform=None,  # noqa: ANN001
        pre_filter=None,  # noqa: ANN001
        force_reload: bool = False,
    ) -> None:
        """Initialize Cora co-citation dataset."""
        super().__init__(
            root,
            remove_isolated_nodes,
            load_text_features,
            encoder_model,
            transform,
            pre_transform,
            pre_filter,
            force_reload,
        )


class CiteseerCocitation(DHGBenchDataset):
    """Citeseer co-citation hypergraph dataset from DHG-Bench.

    The Citeseer dataset contains scientific publications classified into six
    categories: Agents, AI, DB, IR, ML, and HCI.

    In the co-citation construction, papers that cite the same references
    are connected through hyperedges.

    Statistics (with remove_isolated_nodes=True, TriCL-compatible):
        - Nodes: 1,458 papers (connected nodes only)
        - Hyperedges: 1,079 co-citation hyperedges
        - Features: 3,703 bag-of-words features
        - Classes: 6 categories
        - Avg. hyperedge size: ~3.6 papers

    Statistics (with remove_isolated_nodes=False, full DHG-Bench):
        - Total nodes: 3,327 papers (isolated + connected)
        - Hyperedges: 1,079 co-citation hyperedges
        - Features: 3,703 bag-of-words features
        - Classes: 6 categories

    Text Features Support:
        **WARNING**: Citeseer does NOT support text features from TAG dataset.
        The TAG Citeseer dataset has 3,186 nodes while DHG-Bench has 3,312 nodes,
        making them incompatible for node-level alignment.

        If you attempt to use load_text_features=True with Citeseer, a ValueError
        will be raised. For text features, please use Cora or Pubmed instead.

    Args:
        root: Root directory where dataset should be stored.
            If None, uses ~/.pyg-hyper/data/cocitation-citeseer
        remove_isolated_nodes: If True, remove isolated nodes for TriCL compatibility.
            If False, preserve all nodes including isolated ones (default: True)
        transform: Optional transform to be applied to data objects
        pre_transform: Optional transform to be applied before saving
        pre_filter: Optional filter function applied before saving
        force_reload: If True, re-download and re-process the dataset

    Example:
        >>> dataset = CiteseerCocitation()
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}, Hyperedges: {data.num_hyperedges}")
        Nodes: 1458, Hyperedges: 1079
        >>> # Get train/val/test split (DHG-Bench uses seeds 1-10)
        >>> splits = dataset.get_split(seed=1)
        >>> train_mask = splits['train_mask']

    References:
        - DHG-Bench: A Comprehensive Benchmark for Deep Hypergraph Learning (ICLR 2026)
        - HyperGCN: Hypergraph Convolutional Networks (Feng et al., 2019)
        - TriCL: Triangle-based Contrastive Learning (Woo et al., 2022)
    """

    dataset_name: str = "citeseer"
    dataset_type: str = "cocitation"

    def __init__(
        self,
        root: str | Path | None = None,
        remove_isolated_nodes: bool = True,
        transform=None,  # noqa: ANN001
        pre_transform=None,  # noqa: ANN001
        pre_filter=None,  # noqa: ANN001
        force_reload: bool = False,
    ) -> None:
        """Initialize Citeseer co-citation dataset."""
        super().__init__(
            root,
            remove_isolated_nodes,
            False,  # load_text_features (not supported - node count mismatch)
            None,  # encoder_model (not supported)
            transform,
            pre_transform,
            pre_filter,
            force_reload,
        )


class PubmedCocitation(DHGBenchDataset):
    """Pubmed co-citation hypergraph dataset from DHG-Bench.

    The Pubmed dataset contains scientific publications from PubMed database
    classified into three categories related to diabetes research:
    Diabetes_Mellitus_Experimental, Diabetes_Mellitus_Type_1, and
    Diabetes_Mellitus_Type_2.

    In the co-citation construction, papers that cite the same references
    are connected through hyperedges.

    Statistics (with remove_isolated_nodes=True, TriCL-compatible):
        - Nodes: 3,840 papers (connected nodes only)
        - Hyperedges: 7,963 co-citation hyperedges
        - Features: 500 bag-of-words features
        - Classes: 3 categories
        - Avg. hyperedge size: ~4.4 papers

    Statistics (with remove_isolated_nodes=False, full DHG-Bench):
        - Total nodes: 19,717 papers (isolated + connected)
        - Hyperedges: 7,963 co-citation hyperedges
        - Features: 500 bag-of-words features
        - Classes: 3 categories

    Text Features Support:
        Pubmed supports text features from the HuggingFace TAG dataset! The TAG dataset
        provides validated alignment with DHG-Bench (same 19,717 nodes, consistent ordering).
        Text features include paper titles and abstracts encoded with sentence-transformers.

        **Recommended**: Use load_text_features="lazy" for Pubmed due to the large dataset
        size (19,717 nodes). This enables on-demand loading via data.load_title(),
        data.load_abstract(), data.load_title_embeddings(), and data.load_abstract_embeddings()
        methods, which is more memory-efficient.

    Args:
        root: Root directory where dataset should be stored.
            If None, uses ~/.pyg-hyper/data/cocitation-pubmed
        remove_isolated_nodes: If True, remove isolated nodes for TriCL compatibility.
            If False, preserve all nodes including isolated ones (default: True)
        load_text_features: If True, load text features from HuggingFace TAG dataset.
            If "lazy", enable lazy loading for memory efficiency (RECOMMENDED). (default: False)
        encoder_model: Sentence-transformer model for text encoding.
            (default: "all-mpnet-base-v2" for 768-dim embeddings)
        transform: Optional transform to be applied to data objects
        pre_transform: Optional transform to be applied before saving
        pre_filter: Optional filter function applied before saving
        force_reload: If True, re-download and re-process the dataset

    Example:
        >>> # Default: TriCL-compatible (isolated nodes removed, no text)
        >>> dataset = PubmedCocitation()
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}, Hyperedges: {data.num_hyperedges}")
        Nodes: 3840, Hyperedges: 7963
        >>>
        >>> # With text features (lazy loading recommended)
        >>> dataset = PubmedCocitation(
        ...     remove_isolated_nodes=False,
        ...     load_text_features="lazy"
        ... )
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}")  # 19717
        >>> # Load on-demand
        >>> titles = data.load_title()  # 19717 titles
        >>> abstracts = data.load_abstract()  # 19717 abstracts
        >>> title_emb = data.load_title_embeddings()  # [19717, 768]
        >>> abstract_emb = data.load_abstract_embeddings()  # [19717, 768]
        >>>
        >>> # Get train/val/test split (DHG-Bench uses seeds 1-10)
        >>> splits = dataset.get_split(seed=1)
        >>> train_mask = splits['train_mask']

    References:
        - DHG-Bench: A Comprehensive Benchmark for Deep Hypergraph Learning (ICLR 2026)
        - TAG: HuggingFace Text-Attributed-Graphs
        - https://huggingface.co/datasets/Graph-COM/Text-Attributed-Graphs
        - HyperGCN: Hypergraph Convolutional Networks (Feng et al., 2019)
        - TriCL: Triangle-based Contrastive Learning (Woo et al., 2022)
    """

    dataset_name: str = "pubmed"
    dataset_type: str = "cocitation"

    def __init__(
        self,
        root: str | Path | None = None,
        remove_isolated_nodes: bool = True,
        load_text_features: bool | Literal["lazy"] = False,
        encoder_model: str | None = None,
        transform=None,  # noqa: ANN001
        pre_transform=None,  # noqa: ANN001
        pre_filter=None,  # noqa: ANN001
        force_reload: bool = False,
    ) -> None:
        """Initialize Pubmed co-citation dataset."""
        super().__init__(
            root,
            remove_isolated_nodes,
            load_text_features,
            encoder_model,
            transform,
            pre_transform,
            pre_filter,
            force_reload,
        )
