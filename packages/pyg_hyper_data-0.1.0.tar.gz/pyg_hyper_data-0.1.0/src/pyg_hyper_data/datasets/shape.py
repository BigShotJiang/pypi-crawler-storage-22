"""3D shape hypergraph datasets.

These datasets represent 3D shapes as hypergraphs where nodes correspond to
objects and hyperedges capture geometric or structural relationships between
shapes.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pyg_hyper_data.datasets.base import TriclDataset

if TYPE_CHECKING:
    from pathlib import Path

__all__ = [
    "NTU2012",
    "ModelNet40",
]


class NTU2012(TriclDataset):
    """NTU2012 3D shape hypergraph dataset.

    The NTU2012 dataset contains 3D human action sequences represented as
    hypergraphs. Each node represents a skeletal joint configuration, and
    hyperedges capture temporal and spatial relationships between actions.

    Statistics:
        - Nodes: 2,012 samples
        - Hyperedges: 2,012 hyperedges
        - Features: 100 shape descriptors
        - Classes: 67 action categories
        - Avg. hyperedge size: Variable

    Args:
        root: Root directory where dataset should be stored.
            If None, uses ~/.pyg-hyper/data/ntu2012
        transform: Optional transform to be applied to data objects
        pre_transform: Optional transform to be applied before saving
        pre_filter: Optional filter function applied before saving
        force_reload: If True, re-download and re-process the dataset

    Example:
        >>> dataset = NTU2012()
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}, Hyperedges: {data.num_hyperedges}")
        Nodes: 2012, Hyperedges: 2012
        >>> # Get train/val/test split
        >>> splits = dataset.get_split(seed=0)
        >>> train_mask = splits['train_mask']

    References:
        - NTU RGB+D Dataset: Shahroudy et al., 2016
        - TriCL: Triangle-based Contrastive Learning (Woo et al., 2022)
    """

    dataset_name: str = "NTU2012"
    dataset_type: str = ""  # Top-level dataset, not in subdirectory

    def __init__(
        self,
        root: str | Path | None = None,
        transform=None,  # noqa: ANN001
        pre_transform=None,  # noqa: ANN001
        pre_filter=None,  # noqa: ANN001
        force_reload: bool = False,
    ) -> None:
        """Initialize NTU2012 dataset."""
        # Override name to use lowercase for directory
        self.name = "ntu2012"
        # Call grandparent __init__ to avoid TriclDataset's name construction
        super(TriclDataset, self).__init__(
            root, transform, pre_transform, pre_filter, force_reload
        )

        # Load statistics
        self._load_stats()

        import logging

        logger = logging.getLogger(__name__)
        logger.info("Loaded %s dataset", self.name)
        logger.info("  Nodes: %d", self.data.num_nodes)  # type: ignore[union-attr]
        logger.info("  Hyperedges: %d", self.data.num_hyperedges)  # type: ignore[union-attr]
        logger.info("  Features: %d", self.data.x.shape[1])  # type: ignore[union-attr]
        logger.info("  Classes: %d", int(self.data.y.max()) + 1)  # type: ignore[union-attr]

    @property
    def raw_dir(self) -> str:
        """Get the directory containing the raw data."""
        from pathlib import Path

        return str(Path(self.root) / self.dataset_name)


class ModelNet40(TriclDataset):
    """ModelNet40 3D shape hypergraph dataset.

    The ModelNet40 dataset contains 3D CAD models from 40 object categories
    represented as hypergraphs. Each node represents a 3D shape, and
    hyperedges capture geometric similarity and structural relationships
    between shapes.

    Statistics:
        - Nodes: 12,311 shapes
        - Hyperedges: 12,311 hyperedges
        - Features: 100 shape descriptors
        - Classes: 40 object categories
        - Avg. hyperedge size: Variable

    Args:
        root: Root directory where dataset should be stored.
            If None, uses ~/.pyg-hyper/data/modelnet40
        transform: Optional transform to be applied to data objects
        pre_transform: Optional transform to be applied before saving
        pre_filter: Optional filter function applied before saving
        force_reload: If True, re-download and re-process the dataset

    Example:
        >>> dataset = ModelNet40()
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}, Hyperedges: {data.num_hyperedges}")
        Nodes: 12311, Hyperedges: 12311
        >>> # Get train/val/test split
        >>> splits = dataset.get_split(seed=0)
        >>> train_mask = splits['train_mask']

    References:
        - ModelNet: 3D ShapeNets (Wu et al., 2015)
        - TriCL: Triangle-based Contrastive Learning (Woo et al., 2022)
    """

    dataset_name: str = "ModelNet40"
    dataset_type: str = ""  # Top-level dataset, not in subdirectory

    def __init__(
        self,
        root: str | Path | None = None,
        transform=None,  # noqa: ANN001
        pre_transform=None,  # noqa: ANN001
        pre_filter=None,  # noqa: ANN001
        force_reload: bool = False,
    ) -> None:
        """Initialize ModelNet40 dataset."""
        # Override name to use lowercase for directory
        self.name = "modelnet40"
        # Call grandparent __init__ to avoid TriclDataset's name construction
        super(TriclDataset, self).__init__(
            root, transform, pre_transform, pre_filter, force_reload
        )

        # Load statistics
        self._load_stats()

        import logging

        logger = logging.getLogger(__name__)
        logger.info("Loaded %s dataset", self.name)
        logger.info("  Nodes: %d", self.data.num_nodes)  # type: ignore[union-attr]
        logger.info("  Hyperedges: %d", self.data.num_hyperedges)  # type: ignore[union-attr]
        logger.info("  Features: %d", self.data.x.shape[1])  # type: ignore[union-attr]
        logger.info("  Classes: %d", int(self.data.y.max()) + 1)  # type: ignore[union-attr]

    @property
    def raw_dir(self) -> str:
        """Get the directory containing the raw data."""
        from pathlib import Path

        return str(Path(self.root) / self.dataset_name)
