"""Text hypergraph datasets.

These datasets represent text documents as hypergraphs where nodes correspond
to documents and hyperedges capture semantic or topical relationships between
documents based on word co-occurrence or topic modeling.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pyg_hyper_data.datasets.base import TriclDataset

if TYPE_CHECKING:
    from pathlib import Path

__all__ = [
    "News20",
]


class News20(TriclDataset):
    """20 Newsgroups hypergraph dataset (W=100 window size).

    The 20 Newsgroups dataset contains approximately 20,000 newsgroup documents
    partitioned across 20 different newsgroups. This hypergraph variant uses
    a sliding window approach (W=100) to construct hyperedges based on word
    co-occurrence patterns.

    In the hypergraph representation, nodes represent documents, and hyperedges
    connect documents that share similar word co-occurrence patterns within
    a window of 100 words.

    Statistics:
        - Nodes: 16,242 documents
        - Hyperedges: 100 hyperedges
        - Features: 100 text features (word embeddings/TF-IDF)
        - Classes: 4 newsgroup categories
        - Avg. hyperedge size: ~162.4 documents

    Args:
        root: Root directory where dataset should be stored.
            If None, uses ~/.pyg-hyper/data/news20
        transform: Optional transform to be applied to data objects
        pre_transform: Optional transform to be applied before saving
        pre_filter: Optional filter function applied before saving
        force_reload: If True, re-download and re-process the dataset

    Example:
        >>> dataset = News20()
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}, Hyperedges: {data.num_hyperedges}")
        Nodes: 16242, Hyperedges: 100
        >>> # Get train/val/test split
        >>> splits = dataset.get_split(seed=0)
        >>> train_mask = splits['train_mask']

    References:
        - 20 Newsgroups Dataset: Ken Lang
        - TriCL: Triangle-based Contrastive Learning (Woo et al., 2022)
    """

    dataset_name: str = "20newsW100"
    dataset_type: str = ""  # Top-level dataset, not in subdirectory

    def __init__(
        self,
        root: str | Path | None = None,
        transform=None,  # noqa: ANN001
        pre_transform=None,  # noqa: ANN001
        pre_filter=None,  # noqa: ANN001
        force_reload: bool = False,
    ) -> None:
        """Initialize 20 Newsgroups dataset."""
        # Override name to use lowercase for directory
        self.name = "news20"
        # Call grandparent __init__ to avoid TriclDataset's name construction
        super(TriclDataset, self).__init__(
            root, transform, pre_transform, pre_filter, force_reload
        )

        # Load statistics
        self._load_stats()

        import logging

        logger = logging.getLogger(__name__)
        logger.info("Loaded %s dataset", self.name)
        logger.info("  Nodes: %d", self.data.num_nodes)  # type: ignore[union-attr]
        logger.info("  Hyperedges: %d", self.data.num_hyperedges)  # type: ignore[union-attr]
        logger.info("  Features: %d", self.data.x.shape[1])  # type: ignore[union-attr]
        logger.info("  Classes: %d", int(self.data.y.max()) + 1)  # type: ignore[union-attr]

    @property
    def raw_dir(self) -> str:
        """Get the directory containing the raw data."""
        from pathlib import Path

        return str(Path(self.root) / self.dataset_name)
