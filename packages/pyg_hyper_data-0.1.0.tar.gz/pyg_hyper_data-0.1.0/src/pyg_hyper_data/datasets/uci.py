"""UCI Machine Learning Repository hypergraph datasets.

These datasets are from the UCI Machine Learning Repository, converted to
hypergraph format where nodes represent data samples and hyperedges capture
feature-based relationships.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pyg_hyper_data.datasets.base import TriclDataset

if TYPE_CHECKING:
    from pathlib import Path

__all__ = [
    "Mushroom",
    "Zoo",
]


class Mushroom(TriclDataset):
    """Mushroom hypergraph dataset from UCI ML Repository.

    The Mushroom dataset contains descriptions of hypothetical samples
    corresponding to 23 species of gilled mushrooms from the Agaricus
    and Lepiota families. The task is to classify mushrooms as edible
    or poisonous based on their physical characteristics.

    In the hypergraph representation, nodes represent mushroom samples,
    and hyperedges connect samples with similar feature combinations.

    Statistics:
        - Nodes: 8,124 mushroom samples
        - Hyperedges: 298 hyperedges
        - Features: 22 categorical features
        - Classes: 2 (edible, poisonous)
        - Avg. hyperedge size: ~27.3 samples

    Args:
        root: Root directory where dataset should be stored.
            If None, uses ~/.pyg-hyper/data/mushroom
        transform: Optional transform to be applied to data objects
        pre_transform: Optional transform to be applied before saving
        pre_filter: Optional filter function applied before saving
        force_reload: If True, re-download and re-process the dataset

    Example:
        >>> dataset = Mushroom()
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}, Hyperedges: {data.num_hyperedges}")
        Nodes: 8124, Hyperedges: 298
        >>> # Get train/val/test split
        >>> splits = dataset.get_split(seed=0)
        >>> train_mask = splits['train_mask']

    References:
        - UCI ML Repository: Mushroom Dataset
        - TriCL: Triangle-based Contrastive Learning (Woo et al., 2022)
    """

    dataset_name: str = "Mushroom"
    dataset_type: str = ""  # Top-level dataset, not in subdirectory

    def __init__(
        self,
        root: str | Path | None = None,
        transform=None,  # noqa: ANN001
        pre_transform=None,  # noqa: ANN001
        pre_filter=None,  # noqa: ANN001
        force_reload: bool = False,
    ) -> None:
        """Initialize Mushroom dataset."""
        # Override name to use lowercase for directory
        self.name = "mushroom"
        # Call grandparent __init__ to avoid TriclDataset's name construction
        super(TriclDataset, self).__init__(
            root, transform, pre_transform, pre_filter, force_reload
        )

        # Load statistics
        self._load_stats()

        import logging

        logger = logging.getLogger(__name__)
        logger.info("Loaded %s dataset", self.name)
        logger.info("  Nodes: %d", self.data.num_nodes)  # type: ignore[union-attr]
        logger.info("  Hyperedges: %d", self.data.num_hyperedges)  # type: ignore[union-attr]
        logger.info("  Features: %d", self.data.x.shape[1])  # type: ignore[union-attr]
        logger.info("  Classes: %d", int(self.data.y.max()) + 1)  # type: ignore[union-attr]

    @property
    def raw_dir(self) -> str:
        """Get the directory containing the raw data."""
        from pathlib import Path

        return str(Path(self.root) / self.dataset_name)


class Zoo(TriclDataset):
    """Zoo hypergraph dataset from UCI ML Repository.

    The Zoo dataset contains 101 animals characterized by 16 boolean-valued
    attributes (e.g., has hair, has feathers, lays eggs). The task is to
    classify animals into 7 types: mammal, bird, reptile, fish, amphibian,
    insect, and invertebrate.

    In the hypergraph representation, nodes represent animals, and
    hyperedges connect animals with similar biological characteristics.

    Statistics:
        - Nodes: 101 animals
        - Hyperedges: 43 hyperedges
        - Features: 16 boolean attributes
        - Classes: 7 animal types
        - Avg. hyperedge size: ~2.3 animals

    Args:
        root: Root directory where dataset should be stored.
            If None, uses ~/.pyg-hyper/data/zoo
        transform: Optional transform to be applied to data objects
        pre_transform: Optional transform to be applied before saving
        pre_filter: Optional filter function applied before saving
        force_reload: If True, re-download and re-process the dataset

    Example:
        >>> dataset = Zoo()
        >>> data = dataset[0]
        >>> print(f"Nodes: {data.num_nodes}, Hyperedges: {data.num_hyperedges}")
        Nodes: 101, Hyperedges: 43
        >>> # Get train/val/test split
        >>> splits = dataset.get_split(seed=0)
        >>> train_mask = splits['train_mask']

    References:
        - UCI ML Repository: Zoo Dataset
        - TriCL: Triangle-based Contrastive Learning (Woo et al., 2022)
    """

    dataset_name: str = "zoo"
    dataset_type: str = ""  # Top-level dataset, not in subdirectory

    def __init__(
        self,
        root: str | Path | None = None,
        transform=None,  # noqa: ANN001
        pre_transform=None,  # noqa: ANN001
        pre_filter=None,  # noqa: ANN001
        force_reload: bool = False,
    ) -> None:
        """Initialize Zoo dataset."""
        # Override name to use lowercase for directory (already lowercase)
        self.name = "zoo"
        # Call grandparent __init__ to avoid TriclDataset's name construction
        super(TriclDataset, self).__init__(
            root, transform, pre_transform, pre_filter, force_reload
        )

        # Load statistics
        self._load_stats()

        import logging

        logger = logging.getLogger(__name__)
        logger.info("Loaded %s dataset", self.name)
        logger.info("  Nodes: %d", self.data.num_nodes)  # type: ignore[union-attr]
        logger.info("  Hyperedges: %d", self.data.num_hyperedges)  # type: ignore[union-attr]
        logger.info("  Features: %d", self.data.x.shape[1])  # type: ignore[union-attr]
        logger.info("  Classes: %d", int(self.data.y.max()) + 1)  # type: ignore[union-attr]

    @property
    def raw_dir(self) -> str:
        """Get the directory containing the raw data."""
        from pathlib import Path

        return str(Path(self.root) / self.dataset_name)
