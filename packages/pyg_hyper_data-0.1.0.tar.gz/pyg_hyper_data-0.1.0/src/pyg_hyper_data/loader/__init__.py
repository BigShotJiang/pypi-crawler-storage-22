"""Data loaders for hypergraph datasets."""

from pyg_hyper_data.loader.neighbor import HypergraphNeighborLoader

__all__ = [
    "HypergraphNeighborLoader",
]
