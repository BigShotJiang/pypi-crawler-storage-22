"""Hierarchical neighbor sampling for hypergraphs.

This module implements efficient sampling strategies to prevent neighborhood
explosion in hypergraphs, especially when dealing with large hyperedges
(the "Monster Hyperedge" problem described in the research reports).

Key features:
- Separate control of node->hyperedge and hyperedge->node sampling
- Cardinality-aware sampling to handle power-law degree distributions
- Compatible with both HyperData and HyperHeteroData formats
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

import torch
from torch_geometric.loader import NeighborLoader

if TYPE_CHECKING:
    from torch import Tensor

    from pyg_hyper_data.data import HyperData, HyperHeteroData

__all__ = ["HypergraphNeighborLoader"]


class HypergraphNeighborLoader(NeighborLoader):
    """Hierarchical neighbor sampling loader for hypergraphs.

    This loader extends PyG's NeighborLoader to handle hypergraph-specific
    sampling challenges:

    1. **Neighborhood Explosion**: Large hyperedges (e.g., popular items in
       e-commerce) can connect thousands of nodes. Naive sampling would
       include all of them, causing memory issues.

    2. **Two-level Sampling**: Hypergraphs require sampling at two levels:
       - Node -> Hyperedge: How many hyperedges a node belongs to
       - Hyperedge -> Node: How many nodes to sample from each hyperedge

    3. **Structural Awareness**: Maintains hypergraph structure while
       keeping computation bounded.

    The loader automatically converts HyperData to HyperHeteroData internally
    and applies appropriate sampling strategies based on the hypergraph topology.

    Args:
        data: HyperData or HyperHeteroData object
        num_neighbors_nodes: Number of hyperedges to sample per node (V->E).
            Can be int (same for all hops) or list of ints (per hop).
            Default: 10 (empirically chosen to balance coverage and efficiency)
        num_neighbors_edges: Max number of nodes to sample per hyperedge (E->V).
            This is critical for controlling explosion. Default: 20
        input_nodes: Node indices or node type for starting sampling.
            For HyperData, provide node indices. For HyperHeteroData,
            provide ('node', node_indices) tuple.
        batch_size: Number of input nodes per batch
        num_hops: Number of hops to sample (default: 2, one V->E->V round)
        replace: Whether to sample with replacement (default: False)
        shuffle: Whether to shuffle input nodes (default: True)
        **kwargs: Additional arguments passed to NeighborLoader

    Example:
        >>> from pyg_hyper_data.datasets import CoraCocitation
        >>> from pyg_hyper_data.loader import HypergraphNeighborLoader
        >>>
        >>> dataset = CoraCocitation()
        >>> data = dataset[0]
        >>>
        >>> # Create loader
        >>> loader = HypergraphNeighborLoader(
        ...     data,
        ...     num_neighbors_nodes=10,  # Sample up to 10 hyperedges per node
        ...     num_neighbors_edges=20,  # Sample up to 20 nodes per hyperedge
        ...     input_nodes=torch.arange(100),  # Train on first 100 nodes
        ...     batch_size=32,
        ...     num_hops=2,
        ... )
        >>>
        >>> # Iterate over batches
        >>> for batch in loader:
        ...     # batch is a HyperData object with sampled subgraph
        ...     print(f"Batch nodes: {batch.num_nodes}")
        ...     print(f"Batch hyperedges: {batch.num_hyperedges}")

    References:
        - GraphSAGE sampling: Hamilton et al., 2017
        - FastHGNN layer-wise sampling: Dong et al., 2020
        - AllSet multiset transformers: Chien et al., 2022
        - Research Report 1, Section 5.2: Hierarchical sampling strategies
        - Research Report 2, Section 4.5: HierarchicalHyperLoader design
    """

    def __init__(
        self,
        data: HyperData | HyperHeteroData,
        num_neighbors_nodes: int | list[int] = 10,
        num_neighbors_edges: int | list[int] = 20,
        input_nodes: Tensor | tuple[str, Tensor] | None = None,
        batch_size: int = 32,
        num_hops: int = 2,
        replace: bool = False,
        shuffle: bool = True,
        **kwargs,
    ) -> None:
        """Initialize hypergraph neighbor loader."""
        # Convert HyperData to HyperHeteroData if needed
        from pyg_hyper_data.data import HyperData, HyperHeteroData

        if isinstance(data, HyperData):
            # Convert to hetero representation for sampling
            data_hetero = data.to_hetero()
            self._original_format: Literal["hyper", "hetero"] = "hyper"

            # If input_nodes is tensor, convert to hetero format
            if input_nodes is not None and isinstance(input_nodes, torch.Tensor):
                input_nodes = ("node", input_nodes)
        elif isinstance(data, HyperHeteroData):
            data_hetero = data
            self._original_format = "hetero"

            # Ensure input_nodes is in correct format
            if input_nodes is not None and not isinstance(input_nodes, tuple):
                input_nodes = ("node", input_nodes)
        else:
            msg = f"data must be HyperData or HyperHeteroData, got {type(data)}"
            raise TypeError(msg)

        # Build num_neighbors dict for heterogeneous sampling
        # We need to specify sampling for each edge type
        num_neighbors = self._build_num_neighbors_dict(
            num_neighbors_nodes=num_neighbors_nodes,
            num_neighbors_edges=num_neighbors_edges,
            num_hops=num_hops,
        )

        # Initialize parent NeighborLoader with hetero data
        super().__init__(
            data=data_hetero,
            num_neighbors=num_neighbors,  # type: ignore[arg-type]
            input_nodes=input_nodes,
            batch_size=batch_size,
            replace=replace,
            shuffle=shuffle,
            **kwargs,
        )

    def _build_num_neighbors_dict(
        self,
        num_neighbors_nodes: int | list[int],
        num_neighbors_edges: int | list[int],
        num_hops: int,
    ) -> dict | list[dict]:
        """Build num_neighbors dict for hetero sampling.

        Args:
            num_neighbors_nodes: Sampling budget for node->hyperedge
            num_neighbors_edges: Sampling budget for hyperedge->node
            num_hops: Number of hops

        Returns:
            num_neighbors specification for NeighborLoader
        """
        # Normalize to lists
        if isinstance(num_neighbors_nodes, int):
            nodes_per_hop = [num_neighbors_nodes] * num_hops
        else:
            nodes_per_hop = list(num_neighbors_nodes)

        if isinstance(num_neighbors_edges, int):
            edges_per_hop = [num_neighbors_edges] * num_hops
        else:
            edges_per_hop = list(num_neighbors_edges)

        # Ensure same length
        if len(nodes_per_hop) != len(edges_per_hop):
            msg = (
                f"num_neighbors_nodes and num_neighbors_edges must have same length, "
                f"got {len(nodes_per_hop)} and {len(edges_per_hop)}"
            )
            raise ValueError(msg)

        # Build hop-specific sampling configuration
        # For each hop, we specify sampling for both edge types
        return {
            # Node -> Hyperedge: How many hyperedges to sample per node
            "node__member_of__hyperedge": nodes_per_hop,
            # Hyperedge -> Node: How many nodes to sample per hyperedge
            # This is THE critical parameter to prevent explosion
            "hyperedge__has_member__node": edges_per_hop,
        }

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"{self.__class__.__name__}(\n"
            f"  batch_size={self.batch_size},\n"
            f"  num_neighbors={self.num_neighbors},\n"  # type: ignore[attr-defined]
            f"  replace={self.replace},\n"  # type: ignore[attr-defined]
            f"  shuffle={self.shuffle}\n"  # type: ignore[attr-defined]
            f")"
        )
