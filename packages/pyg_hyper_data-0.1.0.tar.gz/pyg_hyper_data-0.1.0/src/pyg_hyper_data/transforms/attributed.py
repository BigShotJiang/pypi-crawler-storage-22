"""Transforms for creating entity-attribute hyperedges."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

import torch

from pyg_hyper_data.data import HyperData

if TYPE_CHECKING:
    from torch import Tensor


class AttributedHyperData(HyperData):
    """HyperData with entity-attribute hyperedges.

    This class extends HyperData to support heterogeneous hypergraphs where
    attributes (e.g., title, abstract) are represented as independent nodes,
    connected to entity nodes (e.g., papers) via entity-attribute hyperedges.

    Attributes:
        x: Entity node features [num_entities, entity_dim]
        hyperedge_index: Combined hyperedge index [2, num_connections]
            Contains both structural and entity-attribute hyperedges
        y: Entity labels [num_entities]
        attribute_types: List of attribute names (e.g., ["title", "abstract"])
        attribute_features: Dict mapping attribute names to feature tensors
        attribute_offsets: Dict mapping attribute names to node ID offsets
        entity_attribute_edge_mask: Boolean mask for entity-attribute edges
        original_num_nodes: Number of entity nodes (before adding attributes)
        original_num_edges: Number of structural edges (before adding attributes)
    """

    def __init__(self, **kwargs: Any) -> None:
        """Initialize AttributedHyperData."""
        super().__init__(**kwargs)


class AddEntityAttributeHyperedges:
    """Transform that adds entity-attribute hyperedges.

    This transform converts attribute tensors into independent attribute nodes
    and creates hyperedges connecting each entity to its corresponding attributes.

    The resulting hypergraph structure:
    - Entity nodes: [0, num_entities)
    - Attribute nodes: [num_entities, total_nodes)
      - For each attribute type, nodes are allocated sequentially

    Node ID Layout:
        [0, num_entities)                     : Entity nodes (e.g., papers)
        [num_entities, ...)                   : Attribute nodes
          [offset_attr1, offset_attr1 + N)    : Attribute type 1 nodes
          [offset_attr2, offset_attr2 + N)    : Attribute type 2 nodes
          ...

    Args:
        attributes: List of attribute names to convert into nodes
        one_to_one: If True, each entity has exactly one node per attribute
            If False, allows many-to-many relationships (not yet implemented)
        edge_type: How to create entity-attribute edges
            - "combined": One hyperedge per entity connecting all its attributes
            - "separate": One hyperedge per entity-attribute pair

    Example:
        >>> from pyg_hyper_data.datasets import CoraCocitation
        >>> from pyg_hyper_data.transforms import AddEntityAttributeHyperedges
        >>> transform = AddEntityAttributeHyperedges(
        ...     attributes=["title", "abstract"],
        ...     one_to_one=True,
        ...     edge_type="combined"
        ... )
        >>> dataset = CoraCocitation(
        ...     load_text_features=True,
        ...     pre_transform=transform
        ... )
        >>> data = dataset[0]
        >>> print(f"Entities: {data.original_num_nodes}")  # 2708
        >>> print(f"Total nodes: {data.num_nodes}")  # 2708 * 3 = 8124
    """

    def __init__(
        self,
        attributes: list[str],
        one_to_one: bool = True,
        edge_type: Literal["separate", "combined"] = "combined",
    ) -> None:
        """Initialize the transform.

        Args:
            attributes: List of attribute names
            one_to_one: Whether entities have one-to-one relationships with attributes
            edge_type: "separate" or "combined" edge creation strategy
        """
        if not attributes:
            msg = "At least one attribute must be specified"
            raise ValueError(msg)

        self.attributes = attributes
        self.one_to_one = one_to_one
        self.edge_type = edge_type

    def __call__(self, data: HyperData) -> AttributedHyperData:
        """Apply the transform.

        Args:
            data: Input HyperData with attribute tensors

        Returns:
            AttributedHyperData with entity-attribute hyperedges

        Raises:
            ValueError: If requested attributes don't exist in data
        """
        # 1. Validate attributes exist
        self._validate_attributes(data)

        # 2. Calculate node offsets
        num_entities = data.num_nodes
        if num_entities is None:
            msg = "Input data must have num_nodes set"
            raise ValueError(msg)

        num_original_edges = data.num_hyperedges
        if num_original_edges is None:
            msg = "Input data must have num_hyperedges set"
            raise ValueError(msg)

        attribute_offsets = self._calculate_attribute_offsets(data, num_entities)

        # 3. Create entity-attribute edges
        entity_attr_edges, entity_attr_edge_mask = (
            self._construct_entity_attribute_edges(
                data, num_entities, num_original_edges, attribute_offsets
            )
        )

        # 4. Combine with original edges
        if data.hyperedge_index is None:
            msg = "Input data must have hyperedge_index"
            raise ValueError(msg)
        combined_hyperedge_index = torch.cat(
            [data.hyperedge_index, entity_attr_edges], dim=1
        )

        # 5. Construct AttributedHyperData
        result = AttributedHyperData(
            x=data.x,
            hyperedge_index=combined_hyperedge_index,
            y=data.y,
            num_nodes=num_entities
            + sum(len(getattr(data, attr)) for attr in self.attributes),
            num_edges=num_original_edges + entity_attr_edge_mask.sum().item(),
        )

        # Store metadata
        result.attribute_types = self.attributes
        result.attribute_features = {
            attr: getattr(data, attr) for attr in self.attributes
        }
        result.attribute_offsets = attribute_offsets
        result.entity_attribute_edge_mask = entity_attr_edge_mask
        result.original_num_nodes = num_entities
        result.original_num_edges = num_original_edges

        # Transfer other attributes
        for key in data.keys():  # noqa: SIM118
            if key not in {
                "x",
                "y",
                "hyperedge_index",
                "num_nodes",
                "num_edges",
                *self.attributes,
            }:
                result[key] = data[key]

        return result

    def _validate_attributes(self, data: HyperData) -> None:
        """Validate that requested attributes exist in data.

        Args:
            data: Input HyperData

        Raises:
            ValueError: If any attribute is missing
        """
        for attr in self.attributes:
            if not hasattr(data, attr):
                msg = f"Attribute '{attr}' not found in data"
                raise ValueError(msg)

    def _calculate_attribute_offsets(
        self, data: HyperData, num_entities: int
    ) -> dict[str, int]:
        """Calculate node ID offsets for each attribute type.

        Args:
            data: Input HyperData
            num_entities: Number of entity nodes

        Returns:
            Dictionary mapping attribute names to their node ID offsets
        """
        offsets = {}
        current_offset = num_entities

        for attr in self.attributes:
            offsets[attr] = current_offset
            attr_tensor = getattr(data, attr)
            current_offset += len(attr_tensor)

        return offsets

    def _construct_entity_attribute_edges(
        self,
        data: HyperData,
        num_entities: int,
        num_original_edges: int,
        attribute_offsets: dict[str, int],
    ) -> tuple[Tensor, Tensor]:
        """Construct entity-attribute hyperedge index.

        Args:
            data: Input HyperData
            num_entities: Number of entity nodes
            num_original_edges: Number of original structural edges
            attribute_offsets: Node ID offsets for each attribute

        Returns:
            Tuple of (entity_attr_edges, mask) where:
                - entity_attr_edges: Hyperedge index tensor [2, num_connections]
                - mask: Boolean mask indicating entity-attribute edges in combined index
        """
        edges = []
        edge_offset = num_original_edges

        if self.edge_type == "combined":
            # One hyperedge per entity connecting all its attributes
            for entity_id in range(num_entities):
                edge_id = edge_offset + entity_id

                # Connect entity to this hyperedge
                edges.append([entity_id, edge_id])

                # Connect each attribute to this hyperedge
                for attr in self.attributes:
                    attr_node_id = attribute_offsets[attr] + entity_id
                    edges.append([attr_node_id, edge_id])

        elif self.edge_type == "separate":
            # One hyperedge per entity-attribute pair
            current_edge_id = edge_offset

            for entity_id in range(num_entities):
                for attr in self.attributes:
                    # Connect entity and attribute via a hyperedge
                    attr_node_id = attribute_offsets[attr] + entity_id

                    edges.append([entity_id, current_edge_id])
                    edges.append([attr_node_id, current_edge_id])

                    current_edge_id += 1

        entity_attr_edges = torch.tensor(edges, dtype=torch.long).t()

        # Create mask for the combined index
        # Original edges: False, Entity-attribute edges: True
        if data.hyperedge_index is None:
            msg = "Input data must have hyperedge_index"
            raise ValueError(msg)
        num_original_connections = data.hyperedge_index.shape[1]
        num_entity_attr_connections = entity_attr_edges.shape[1]

        mask = torch.cat(
            [
                torch.zeros(num_original_connections, dtype=torch.bool),
                torch.ones(num_entity_attr_connections, dtype=torch.bool),
            ]
        )

        return entity_attr_edges, mask

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"{self.__class__.__name__}("
            f"attributes={self.attributes}, "
            f"edge_type={self.edge_type})"
        )
