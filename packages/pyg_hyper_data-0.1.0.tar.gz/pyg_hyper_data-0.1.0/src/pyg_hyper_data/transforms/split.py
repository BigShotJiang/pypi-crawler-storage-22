"""Train/val/test split utilities for hypergraphs with structural leak prevention."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import torch

if TYPE_CHECKING:
    from pyg_hyper_data.data import HyperData

logger = logging.getLogger(__name__)


def random_hypergraph_split(
    num_nodes: int,
    train_ratio: float = 0.6,
    val_ratio: float = 0.2,
    test_ratio: float = 0.2,
    seed: int | None = None,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Create random train/val/test split for hypergraph nodes.

    This function creates a random split of nodes into train, validation,
    and test sets. The split is based on nodes only, which helps prevent
    structural information leakage in hypergraphs.

    **Structural Leakage in Hypergraphs:**
    In hypergraphs, a hyperedge connects multiple nodes. If we split by
    hyperedges, information about the structure can leak between splits.
    For example, if a hyperedge contains both train and test nodes, the
    model can learn from the structural relationship during training.

    By splitting only nodes and keeping all hyperedges, we ensure:
    1. No structural information is hidden during training
    2. The model sees the full hypergraph structure
    3. Only node labels are split into train/val/test

    Args:
        num_nodes: Total number of nodes in the hypergraph
        train_ratio: Fraction of nodes for training (default: 0.6)
        val_ratio: Fraction of nodes for validation (default: 0.2)
        test_ratio: Fraction of nodes for testing (default: 0.2)
        seed: Random seed for reproducibility

    Returns:
        Tuple of (train_mask, val_mask, test_mask) where each mask is a
        boolean tensor of shape [num_nodes]

    Raises:
        ValueError: If ratios don't sum to 1.0

    Example:
        >>> num_nodes = 100
        >>> train_mask, val_mask, test_mask = random_hypergraph_split(
        ...     num_nodes, train_ratio=0.6, val_ratio=0.2, test_ratio=0.2
        ... )
        >>> assert train_mask.sum() == 60
        >>> assert val_mask.sum() == 20
        >>> assert test_mask.sum() == 20

    Note:
        For node classification tasks, use these masks to split the labels:
        >>> data.train_mask = train_mask
        >>> data.val_mask = val_mask
        >>> data.test_mask = test_mask
        >>> train_labels = data.y[train_mask]
    """
    # Validate ratios
    if not abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6:
        msg = f"Ratios must sum to 1.0, got {train_ratio + val_ratio + test_ratio}"
        raise ValueError(msg)

    # Set seed for reproducibility
    if seed is not None:
        torch.manual_seed(seed)

    # Compute split sizes
    num_train = int(num_nodes * train_ratio)
    num_val = int(num_nodes * val_ratio)
    num_test = num_nodes - num_train - num_val  # Ensure exact split

    logger.info(
        "Creating split: train=%d (%.1f%%), val=%d (%.1f%%), test=%d (%.1f%%)",
        num_train,
        train_ratio * 100,
        num_val,
        val_ratio * 100,
        num_test,
        test_ratio * 100,
    )

    # Create random permutation
    perm = torch.randperm(num_nodes)

    # Create masks
    train_mask = torch.zeros(num_nodes, dtype=torch.bool)
    val_mask = torch.zeros(num_nodes, dtype=torch.bool)
    test_mask = torch.zeros(num_nodes, dtype=torch.bool)

    train_mask[perm[:num_train]] = True
    val_mask[perm[num_train : num_train + num_val]] = True
    test_mask[perm[num_train + num_val :]] = True

    # Verify masks
    assert train_mask.sum() == num_train
    assert val_mask.sum() == num_val
    assert test_mask.sum() == num_test
    assert (train_mask | val_mask | test_mask).all()  # All nodes covered
    assert not (train_mask & val_mask).any()  # No overlap
    assert not (train_mask & test_mask).any()  # No overlap
    assert not (val_mask & test_mask).any()  # No overlap

    return train_mask, val_mask, test_mask


def stratified_hypergraph_split(
    labels: torch.Tensor,
    train_ratio: float = 0.6,
    val_ratio: float = 0.2,
    test_ratio: float = 0.2,
    seed: int | None = None,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Create stratified train/val/test split maintaining class distribution.

    This function creates a stratified split where each class has the same
    train/val/test ratio. This is useful for imbalanced datasets to ensure
    each split has representation from all classes.

    Args:
        labels: Node labels tensor of shape [num_nodes]
        train_ratio: Fraction of nodes for training (default: 0.6)
        val_ratio: Fraction of nodes for validation (default: 0.2)
        test_ratio: Fraction of nodes for testing (default: 0.2)
        seed: Random seed for reproducibility

    Returns:
        Tuple of (train_mask, val_mask, test_mask) where each mask is a
        boolean tensor of shape [num_nodes]

    Raises:
        ValueError: If ratios don't sum to 1.0

    Example:
        >>> labels = torch.tensor([0, 0, 0, 1, 1, 1, 2, 2, 2])
        >>> train_mask, val_mask, test_mask = stratified_hypergraph_split(
        ...     labels, train_ratio=0.6, val_ratio=0.2, test_ratio=0.2
        ... )
        >>> # Each class has same proportion in train/val/test
        >>> train_labels = labels[train_mask]
        >>> assert (train_labels == 0).sum() >= 1  # At least 1 from class 0
        >>> assert (train_labels == 1).sum() >= 1  # At least 1 from class 1
        >>> assert (train_labels == 2).sum() >= 1  # At least 1 from class 2
    """
    # Validate ratios
    if not abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6:
        msg = f"Ratios must sum to 1.0, got {train_ratio + val_ratio + test_ratio}"
        raise ValueError(msg)

    # Set seed for reproducibility
    if seed is not None:
        torch.manual_seed(seed)

    num_nodes = labels.size(0)
    num_classes = int(labels.max()) + 1

    # Initialize masks
    train_mask = torch.zeros(num_nodes, dtype=torch.bool)
    val_mask = torch.zeros(num_nodes, dtype=torch.bool)
    test_mask = torch.zeros(num_nodes, dtype=torch.bool)

    # Split each class separately
    for c in range(num_classes):
        # Get indices for this class
        class_indices = (labels == c).nonzero(as_tuple=True)[0]
        num_class_nodes = class_indices.size(0)

        # Compute split sizes for this class
        num_train = int(num_class_nodes * train_ratio)
        num_val = int(num_class_nodes * val_ratio)
        num_test = num_class_nodes - num_train - num_val

        # Create random permutation for this class
        perm = torch.randperm(num_class_nodes)

        # Assign to splits
        train_indices = class_indices[perm[:num_train]]
        val_indices = class_indices[perm[num_train : num_train + num_val]]
        test_indices = class_indices[perm[num_train + num_val :]]

        train_mask[train_indices] = True
        val_mask[val_indices] = True
        test_mask[test_indices] = True

        logger.debug(
            "Class %d: train=%d, val=%d, test=%d (total=%d)",
            c,
            num_train,
            num_val,
            num_test,
            num_class_nodes,
        )

    logger.info(
        "Stratified split created: train=%d, val=%d, test=%d",
        train_mask.sum(),
        val_mask.sum(),
        test_mask.sum(),
    )

    # Verify masks
    assert (train_mask | val_mask | test_mask).all()  # All nodes covered
    assert not (train_mask & val_mask).any()  # No overlap
    assert not (train_mask & test_mask).any()  # No overlap
    assert not (val_mask & test_mask).any()  # No overlap

    return train_mask, val_mask, test_mask


def inductive_hypergraph_split(
    data: HyperData,
    train_ratio: float = 0.6,
    val_ratio: float = 0.2,
    test_ratio: float = 0.2,
    seed: int | None = None,
) -> tuple[HyperData, HyperData, HyperData]:
    """Create inductive split preventing structural leakage.

    In inductive learning, the test set consists of completely unseen nodes
    and hyperedges. This split creates three disjoint subgraphs by:

    1. Splitting nodes into train/val/test sets
    2. Splitting hyperedges based on their node membership
    3. Creating induced subgraphs where NO structural information leaks

    **Key Difference from Transductive Split:**
    - Transductive: All nodes visible, only labels masked (graph structure known)
    - Inductive: Test nodes AND their hyperedges completely hidden during training

    **Structural Leak Prevention:**
    This function ensures that:
    - Test hyperedges are NOT used in training graph structure
    - No message passing can occur between train and test nodes
    - Model must generalize to unseen graph regions

    **Hyperedge Assignment Strategy:**
    A hyperedge is assigned to a split based on its nodes:
    - If ALL nodes are in train set → train hyperedge
    - If ANY node is in test set → test hyperedge
    - If ANY node is in val set (and none in test) → val hyperedge

    This conservative strategy ensures no information leakage.

    Args:
        data: HyperData object with x, hyperedge_index, y, etc.
        train_ratio: Fraction of nodes for training (default: 0.6)
        val_ratio: Fraction of nodes for validation (default: 0.2)
        test_ratio: Fraction of nodes for testing (default: 0.2)
        seed: Random seed for reproducibility

    Returns:
        Tuple of (train_data, val_data, test_data) where each is a HyperData
        object containing only the nodes and hyperedges for that split.

    Example:
        >>> from pyg_hyper_data.datasets import CoraCocitation
        >>> from pyg_hyper_data.transforms import inductive_hypergraph_split
        >>>
        >>> dataset = CoraCocitation()
        >>> data = dataset[0]
        >>>
        >>> train_data, val_data, test_data = inductive_hypergraph_split(
        ...     data, train_ratio=0.6, val_ratio=0.2, test_ratio=0.2, seed=42
        ... )
        >>>
        >>> # Each split is completely independent
        >>> print(f"Train: {train_data.num_nodes} nodes, {train_data.num_hyperedges} edges")
        >>> print(f"Val: {val_data.num_nodes} nodes, {val_data.num_hyperedges} edges")
        >>> print(f"Test: {test_data.num_nodes} nodes, {test_data.num_hyperedges} edges")
        >>>
        >>> # Train model on train_data, evaluate on test_data
        >>> # No structural information from test set is visible during training

    Note:
        This split is appropriate for:
        - Inductive learning scenarios (production systems)
        - Evaluating generalization to new users/items
        - Temporal settings (train on old data, test on new)

        Use transductive split (random_hypergraph_split) when:
        - Full graph structure is known at test time
        - Only predicting labels for unlabeled nodes in known graph

    References:
        - GraphSAINT inductive sampling: Zeng et al., 2020
        - DataSAIL: Multifaceted strategies to prevent information leakage
        - Research Report 2, Section 4.4: Inductive Structural Split
    """
    # Validate ratios
    if not abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6:
        msg = f"Ratios must sum to 1.0, got {train_ratio + val_ratio + test_ratio}"
        raise ValueError(msg)

    # Set seed
    if seed is not None:
        torch.manual_seed(seed)

    num_nodes = data.num_nodes
    num_hyperedges = data.num_hyperedges

    # Step 1: Split nodes
    train_mask, val_mask, test_mask = random_hypergraph_split(
        num_nodes,  # type: ignore[arg-type]
        train_ratio,
        val_ratio,
        test_ratio,
        seed=seed,
    )

    # Get node indices for each split
    train_nodes = train_mask.nonzero(as_tuple=True)[0]
    val_nodes = val_mask.nonzero(as_tuple=True)[0]
    test_nodes = test_mask.nonzero(as_tuple=True)[0]

    # Step 2: Assign hyperedges to splits based on node membership
    # hyperedge_index shape: [2, num_connections]
    # row 0: node indices, row 1: hyperedge indices
    node_idx, edge_idx = data.hyperedge_index  # type: ignore[misc]

    # For each hyperedge, determine which nodes it contains
    hyperedge_train_mask = torch.zeros(num_hyperedges, dtype=torch.bool)
    hyperedge_val_mask = torch.zeros(num_hyperedges, dtype=torch.bool)
    hyperedge_test_mask = torch.zeros(num_hyperedges, dtype=torch.bool)

    for e in range(num_hyperedges):
        # Get all nodes in this hyperedge
        nodes_in_edge = node_idx[edge_idx == e]

        # Check overlap with each split
        has_test = test_mask[nodes_in_edge].any()
        has_val = val_mask[nodes_in_edge].any()
        has_train = train_mask[nodes_in_edge].any()

        # Conservative assignment to prevent leakage
        if has_test:
            # If ANY node is test, entire hyperedge is test
            hyperedge_test_mask[e] = True
        elif has_val:
            # If ANY node is val (and no test), hyperedge is val
            hyperedge_val_mask[e] = True
        elif has_train:
            # Only if ALL nodes are train, hyperedge is train
            hyperedge_train_mask[e] = True

    # Get hyperedge indices for each split
    train_edges = hyperedge_train_mask.nonzero(as_tuple=True)[0]
    val_edges = hyperedge_val_mask.nonzero(as_tuple=True)[0]
    test_edges = hyperedge_test_mask.nonzero(as_tuple=True)[0]

    logger.info(
        "Inductive split created:\n"
        "  Train: %d nodes (%d%%), %d hyperedges\n"
        "  Val: %d nodes (%d%%), %d hyperedges\n"
        "  Test: %d nodes (%d%%), %d hyperedges",
        len(train_nodes),
        int(train_ratio * 100),
        len(train_edges),
        len(val_nodes),
        int(val_ratio * 100),
        len(val_edges),
        len(test_nodes),
        int(test_ratio * 100),
        len(test_edges),
    )

    # Step 3: Create induced subgraphs
    train_data = _create_induced_subgraph(data, train_nodes, train_edges)
    val_data = _create_induced_subgraph(data, val_nodes, val_edges)
    test_data = _create_induced_subgraph(data, test_nodes, test_edges)

    return train_data, val_data, test_data


def _create_induced_subgraph(
    data: HyperData, node_indices: torch.Tensor, edge_indices: torch.Tensor
) -> HyperData:
    """Create induced subgraph from selected nodes and hyperedges.

    Args:
        data: Original HyperData
        node_indices: Nodes to include in subgraph
        edge_indices: Hyperedges to include in subgraph

    Returns:
        New HyperData with only selected nodes and hyperedges
    """
    from pyg_hyper_data.data import HyperData

    # Create node index mapping: old_idx -> new_idx
    node_mapping = torch.full((data.num_nodes,), -1, dtype=torch.long)  # type: ignore[arg-type]
    node_mapping[node_indices] = torch.arange(len(node_indices))

    # Create edge index mapping
    edge_mapping = torch.full((data.num_hyperedges,), -1, dtype=torch.long)
    edge_mapping[edge_indices] = torch.arange(len(edge_indices))

    # Filter hyperedge_index
    node_idx, edge_idx = data.hyperedge_index  # type: ignore[misc]

    # Keep connections where both node and edge are in the subgraph
    node_in_subgraph = torch.isin(node_idx, node_indices)
    edge_in_subgraph = torch.isin(edge_idx, edge_indices)
    connections_mask = node_in_subgraph & edge_in_subgraph

    # Extract and remap indices
    new_node_idx = node_mapping[node_idx[connections_mask]]
    new_edge_idx = edge_mapping[edge_idx[connections_mask]]
    new_hyperedge_index = torch.stack([new_node_idx, new_edge_idx], dim=0)

    # Create new data object
    subgraph = HyperData(
        x=data.x[node_indices] if data.x is not None else None,
        hyperedge_index=new_hyperedge_index,
        y=data.y[node_indices] if data.y is not None else None,  # type: ignore[index]
        num_nodes=len(node_indices),
        num_hyperedges=len(edge_indices),
    )

    # Copy hyperedge attributes if present
    if hasattr(data, "hyperedge_attr") and data.hyperedge_attr is not None:
        subgraph.hyperedge_attr = data.hyperedge_attr[edge_indices]

    # Copy any additional node attributes
    for key in data:  # type: ignore[attr-defined]
        if key not in ["x", "y", "hyperedge_index", "hyperedge_attr", "num_nodes"]:
            attr = data[key]
            if isinstance(attr, torch.Tensor) and attr.size(0) == data.num_nodes:
                subgraph[key] = attr[node_indices]

    return subgraph


def hyperedge_prediction_split(
    data: HyperData,
    train_ratio: float = 0.7,
    val_ratio: float = 0.1,
    test_ratio: float = 0.2,
    seed: int | None = None,
    negative_sampling_ratio: float = 1.0,
) -> dict[str, torch.Tensor | HyperData]:
    """Split hyperedges for link prediction task.

    Link prediction in hypergraphs aims to predict whether a set of nodes
    forms a hyperedge. This function splits hyperedges into train/val/test
    sets and optionally generates negative samples.

    **Task Definition:**
    - Positive samples: Existing hyperedges in the dataset
    - Negative samples: Sets of nodes that do NOT form hyperedges

    **Structural Leak Prevention:**
    - Test hyperedges are removed from training graph structure
    - Model cannot use test hyperedge information during training
    - Evaluation measures ability to predict unseen hyperedges

    **Negative Sampling Strategy:**
    For each positive hyperedge of size k:
    1. Sample k nodes uniformly that don't form a hyperedge
    2. Ensure sampled set doesn't appear in any split
    3. Control difficulty with negative_sampling_ratio

    Args:
        data: HyperData object with hyperedge_index
        train_ratio: Fraction of hyperedges for training (default: 0.7)
        val_ratio: Fraction for validation (default: 0.1)
        test_ratio: Fraction for testing (default: 0.2)
        seed: Random seed for reproducibility
        negative_sampling_ratio: Ratio of negative samples to positive samples
            (default: 1.0, meaning equal number of positive and negative)

    Returns:
        Dictionary containing:
        - 'train_data': HyperData with train hyperedges only
        - 'train_pos_edge': Positive train hyperedges [2, num_train_edges]
        - 'train_neg_edge': Negative train samples (if negative_sampling_ratio > 0)
        - 'val_pos_edge': Positive val hyperedges
        - 'val_neg_edge': Negative val samples
        - 'test_pos_edge': Positive test hyperedges
        - 'test_neg_edge': Negative test samples
        - 'train_mask': Boolean mask for train hyperedges
        - 'val_mask': Boolean mask for val hyperedges
        - 'test_mask': Boolean mask for test hyperedges

    Example:
        >>> from pyg_hyper_data.datasets import CoraCocitation
        >>> from pyg_hyper_data.transforms import hyperedge_prediction_split
        >>>
        >>> dataset = CoraCocitation()
        >>> data = dataset[0]
        >>>
        >>> split = hyperedge_prediction_split(
        ...     data,
        ...     train_ratio=0.7,
        ...     val_ratio=0.1,
        ...     test_ratio=0.2,
        ...     seed=42,
        ...     negative_sampling_ratio=1.0,
        ... )
        >>>
        >>> # Train data has train hyperedges only
        >>> train_data = split['train_data']
        >>> print(f"Train graph: {train_data.num_hyperedges} hyperedges")
        >>>
        >>> # Positive and negative samples for evaluation
        >>> val_pos = split['val_pos_edge']
        >>> val_neg = split['val_neg_edge']
        >>> print(f"Val: {val_pos.shape[1]} positive, {val_neg.shape[1]} negative")

    Note:
        For model training:
        1. Train on train_data.hyperedge_index (message passing graph)
        2. Use train_pos_edge and train_neg_edge for link prediction loss
        3. Evaluate on val_pos_edge vs val_neg_edge
        4. Final evaluation on test_pos_edge vs test_neg_edge

    References:
        - PyG RandomLinkSplit for pairwise graphs
        - Negative sampling in hypergraphs: Zhang et al., 2021
        - Research Report 2, Section 4.4: HyperedgeLinkSplit
    """
    from pyg_hyper_data.data import HyperData

    # Validate ratios
    if not abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6:
        msg = f"Ratios must sum to 1.0, got {train_ratio + val_ratio + test_ratio}"
        raise ValueError(msg)

    # Set seed
    if seed is not None:
        torch.manual_seed(seed)

    num_hyperedges = data.num_hyperedges

    # Step 1: Split hyperedges randomly
    num_train = int(num_hyperedges * train_ratio)
    num_val = int(num_hyperedges * val_ratio)
    num_test = num_hyperedges - num_train - num_val

    perm = torch.randperm(num_hyperedges)

    train_mask = torch.zeros(num_hyperedges, dtype=torch.bool)
    val_mask = torch.zeros(num_hyperedges, dtype=torch.bool)
    test_mask = torch.zeros(num_hyperedges, dtype=torch.bool)

    train_mask[perm[:num_train]] = True
    val_mask[perm[num_train : num_train + num_val]] = True
    test_mask[perm[num_train + num_val :]] = True

    train_edges = perm[:num_train]
    val_edges = perm[num_train : num_train + num_val]
    test_edges = perm[num_train + num_val :]

    logger.info(
        "Hyperedge prediction split:\n"
        "  Train: %d hyperedges (%d%%)\n"
        "  Val: %d hyperedges (%d%%)\n"
        "  Test: %d hyperedges (%d%%)",
        num_train,
        int(train_ratio * 100),
        num_val,
        int(val_ratio * 100),
        num_test,
        int(test_ratio * 100),
    )

    # Step 2: Extract positive samples (existing hyperedges)
    node_idx, edge_idx = data.hyperedge_index  # type: ignore[misc]

    train_pos_mask = torch.isin(edge_idx, train_edges)
    val_pos_mask = torch.isin(edge_idx, val_edges)
    test_pos_mask = torch.isin(edge_idx, test_edges)

    train_pos_edge = data.hyperedge_index[:, train_pos_mask]  # type: ignore[index]
    val_pos_edge = data.hyperedge_index[:, val_pos_mask]  # type: ignore[index]
    test_pos_edge = data.hyperedge_index[:, test_pos_mask]  # type: ignore[index]

    # Step 3: Create train_data (graph with only train hyperedges)
    # Remap edge indices to be contiguous [0, num_train)
    edge_mapping = torch.full((num_hyperedges,), -1, dtype=torch.long)
    edge_mapping[train_edges] = torch.arange(num_train)

    new_edge_idx = edge_mapping[edge_idx[train_pos_mask]]
    train_hyperedge_index = torch.stack([node_idx[train_pos_mask], new_edge_idx], dim=0)

    train_data = HyperData(
        x=data.x,
        hyperedge_index=train_hyperedge_index,
        y=data.y,  # type: ignore[arg-type]
        num_nodes=data.num_nodes,
        num_hyperedges=num_train,
    )

    # Copy hyperedge attributes for train edges
    if hasattr(data, "hyperedge_attr") and data.hyperedge_attr is not None:
        train_data.hyperedge_attr = data.hyperedge_attr[train_edges]

    # Step 4: Generate negative samples
    result = {
        "train_data": train_data,
        "train_pos_edge": train_pos_edge,
        "val_pos_edge": val_pos_edge,
        "test_pos_edge": test_pos_edge,
        "train_mask": train_mask,
        "val_mask": val_mask,
        "test_mask": test_mask,
    }

    if negative_sampling_ratio > 0:
        # Generate negative samples for each split
        train_neg = _generate_negative_hyperedges(
            data, train_pos_edge, int(num_train * negative_sampling_ratio), seed
        )
        val_neg = _generate_negative_hyperedges(
            data, val_pos_edge, int(num_val * negative_sampling_ratio), seed
        )
        test_neg = _generate_negative_hyperedges(
            data, test_pos_edge, int(num_test * negative_sampling_ratio), seed
        )

        result["train_neg_edge"] = train_neg
        result["val_neg_edge"] = val_neg
        result["test_neg_edge"] = test_neg

        logger.info(
            "Generated negative samples:\n"
            "  Train: %d negative\n"
            "  Val: %d negative\n"
            "  Test: %d negative",
            train_neg.shape[1] if train_neg.dim() > 1 else 0,
            val_neg.shape[1] if val_neg.dim() > 1 else 0,
            test_neg.shape[1] if test_neg.dim() > 1 else 0,
        )

    return result


def _generate_negative_hyperedges(
    data: HyperData,
    positive_edges: torch.Tensor,
    num_negative: int,
    seed: int | None = None,
) -> torch.Tensor:
    """Generate negative hyperedges that don't exist in the graph.

    For each positive hyperedge, generate a negative sample by randomly
    sampling nodes that don't form an actual hyperedge.

    Args:
        data: Original HyperData
        positive_edges: Positive hyperedge indices [2, num_pos]
        num_negative: Number of negative samples to generate
        seed: Random seed

    Returns:
        Negative hyperedge indices [2, num_negative]
    """
    if seed is not None:
        torch.manual_seed(seed)

    # Build set of existing hyperedges for fast lookup
    # Convert each hyperedge to a frozenset of nodes
    node_idx, edge_idx = data.hyperedge_index  # type: ignore[misc]
    existing_hyperedges = set()

    for e in range(data.num_hyperedges):
        nodes_in_edge = node_idx[edge_idx == e].tolist()
        existing_hyperedges.add(frozenset(nodes_in_edge))

    # Get hyperedge size distribution from positive samples
    pos_node_idx, pos_edge_idx = positive_edges
    unique_edges = torch.unique(pos_edge_idx)

    # Simple strategy: Sample nodes uniformly
    # For each negative sample, randomly select k nodes
    negative_samples = []
    attempts = 0
    max_attempts = num_negative * 10  # Prevent infinite loop

    while len(negative_samples) < num_negative and attempts < max_attempts:
        # Sample hyperedge size from positive distribution
        sample_edge = unique_edges[torch.randint(0, len(unique_edges), (1,))]
        nodes_in_sample = pos_node_idx[pos_edge_idx == sample_edge]
        k = len(nodes_in_sample)

        # Sample k random nodes
        sampled_nodes = torch.randint(0, data.num_nodes, (k,))  # type: ignore[arg-type]
        sampled_set = frozenset(sampled_nodes.tolist())

        # Check if this forms an existing hyperedge
        if sampled_set not in existing_hyperedges:
            # Create hyperedge_index format: repeat edge_id for each node
            edge_id = len(negative_samples)
            negative_samples.extend([node.item(), edge_id] for node in sampled_nodes)

        attempts += 1

    if len(negative_samples) == 0:
        # Fallback: return empty tensor
        return torch.zeros((2, 0), dtype=torch.long)

    # Convert to tensor [2, num_connections]
    return torch.tensor(negative_samples, dtype=torch.long).t()
