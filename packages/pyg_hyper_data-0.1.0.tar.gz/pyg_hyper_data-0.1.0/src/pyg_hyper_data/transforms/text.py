"""Transforms for adding TAG text features to HyperData objects."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

import torch

if TYPE_CHECKING:
    from pyg_hyper_data.config.text import TextEncoderConfig
    from pyg_hyper_data.data import HyperData

logger = logging.getLogger(__name__)


class TextFeaturesTransform:
    """Transform that adds TAG text features to HyperData during processing.

    This transform downloads raw texts from the HuggingFace TAG dataset,
    parses them into separate title and abstract, encodes them with
    sentence-transformers, and adds them as attributes to the HyperData object.

    The transform always provides separate title and abstract attributes:
    - data.title: List of title strings
    - data.abstract: List of abstract strings
    - data.title_embeddings: Tensor of title embeddings
    - data.abstract_embeddings: Tensor of abstract embeddings

    The transform handles caching to avoid re-downloading and re-encoding:
    - TAG raw_texts.pt is cached in {cache_dir}/tag_raw_texts.pt
    - Title embeddings cached in {cache_dir}/text_embeddings/{model}_title.pt
    - Abstract embeddings cached in {cache_dir}/text_embeddings/{model}_abstract.pt

    Args:
        dataset_name: Name of the dataset (e.g., "cora", "pubmed").
        cache_dir: Directory to cache downloaded and encoded data.
        encoder_config: Configuration for sentence-transformer encoding.
        node_id_map: Optional mapping from original node IDs to new node IDs
            (used when remove_isolated_nodes=True). Can be set after initialization.
        force_redownload: If True, force re-download TAG data even if cached.
        force_reencode: If True, force re-encode even if cached embeddings exist.

    Example:
        >>> from pyg_hyper_data.config.text import TextEncoderConfig
        >>> config = TextEncoderConfig(model_name="all-MiniLM-L6-v2")
        >>> transform = TextFeaturesTransform(
        ...     dataset_name="cora",
        ...     cache_dir=Path("~/.pyg-hyper/data/cocitation-cora/multimodal"),
        ...     encoder_config=config
        ... )
        >>> data = HyperData(x=x, hyperedge_index=edge_idx, y=y)
        >>> data = transform(data)
        >>> print(len(data.title))
        2708
        >>> print(data.title_embeddings.shape)
        torch.Size([2708, 384])
    """

    def __init__(
        self,
        dataset_name: str,
        cache_dir: Path,
        encoder_config: TextEncoderConfig,
        node_id_map: dict[int, int] | None = None,
        force_redownload: bool = False,
        force_reencode: bool = False,
    ) -> None:
        """Initialize text features transform."""
        self.dataset_name = dataset_name
        self.cache_dir = Path(cache_dir)
        self.encoder_config = encoder_config
        self.node_id_map = node_id_map
        self.force_redownload = force_redownload
        self.force_reencode = force_reencode

    def __call__(self, data: HyperData) -> HyperData:
        """Apply transform to add text features to HyperData.

        Args:
            data: HyperData object to add text features to.

        Returns:
            HyperData object with title, abstract, and their embeddings.
        """
        from pyg_hyper_data.utils.text import (
            apply_node_id_mapping,
            download_tag_texts,
            encode_texts,
            parse_tag_texts,
        )

        # Step 1: Download TAG texts
        logger.info("Loading TAG texts for %s", self.dataset_name)
        raw_texts = download_tag_texts(
            self.dataset_name,
            self.cache_dir,
            force_redownload=self.force_redownload,
        )
        total_nodes = len(raw_texts)
        logger.info("Loaded %d raw texts from TAG", total_nodes)

        # Step 2: Parse texts into title and abstract
        logger.info("Parsing texts into separate title and abstract")
        titles, abstracts = parse_tag_texts(raw_texts)
        logger.info("Parsed %d titles and %d abstracts", len(titles), len(abstracts))

        # Step 3: Encode title and abstract separately
        embeddings_cache_dir = self.cache_dir / "text_embeddings"
        embeddings_cache_dir.mkdir(parents=True, exist_ok=True)

        # Clean model name for filename
        model_slug = self.encoder_config.model_name.replace("/", "_").replace("-", "_")

        # Encode titles
        title_cache = embeddings_cache_dir / f"{model_slug}_title.pt"
        if self.force_reencode and title_cache.exists():
            logger.info("Force re-encoding: removing cached title embeddings")
            title_cache.unlink()

        title_embeddings = encode_texts(
            titles,
            self.encoder_config,
            cache_file=title_cache,
        )
        logger.info("Title embeddings shape: %s", title_embeddings.shape)

        # Encode abstracts
        abstract_cache = embeddings_cache_dir / f"{model_slug}_abstract.pt"
        if self.force_reencode and abstract_cache.exists():
            logger.info("Force re-encoding: removing cached abstract embeddings")
            abstract_cache.unlink()

        abstract_embeddings = encode_texts(
            abstracts,
            self.encoder_config,
            cache_file=abstract_cache,
        )
        logger.info("Abstract embeddings shape: %s", abstract_embeddings.shape)

        # Step 4: Apply node ID mapping if provided
        if self.node_id_map is not None:
            logger.info("Applying node ID mapping to text features")

            titles, title_embeddings = apply_node_id_mapping(
                titles,
                title_embeddings,
                self.node_id_map,
                total_nodes,
            )
            abstracts, abstract_embeddings = apply_node_id_mapping(
                abstracts,
                abstract_embeddings,
                self.node_id_map,
                total_nodes,
            )

            logger.info("Applied node ID mapping successfully")

        # Step 5: Add to HyperData
        data.title = titles
        data.abstract = abstracts
        data.title_embeddings = title_embeddings
        data.abstract_embeddings = abstract_embeddings

        logger.info(
            "Added text features to HyperData: %d titles, %d abstracts",
            len(titles) if titles else 0,
            len(abstracts) if abstracts else 0,
        )

        return data

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"{self.__class__.__name__}("
            f"dataset={self.dataset_name}, "
            f"encoder={self.encoder_config.model_name})"
        )


class LazyTextFeaturesTransform(TextFeaturesTransform):
    """Transform that enables lazy loading of text features.

    This transform ensures that TAG texts and embeddings are cached, but
    does NOT load them into the HyperData object immediately. Instead, it
    attaches methods that allow on-demand loading:
    - data.load_title() -> List[str]
    - data.load_abstract() -> List[str]
    - data.load_title_embeddings() -> torch.Tensor
    - data.load_abstract_embeddings() -> torch.Tensor

    This is useful for large datasets (e.g., Pubmed with 19,717 nodes) where
    loading all text data into memory may be unnecessary or expensive.

    Example:
        >>> transform = LazyTextFeaturesTransform(
        ...     dataset_name="pubmed",
        ...     cache_dir=Path("~/.pyg-hyper/data/cocitation-pubmed/multimodal"),
        ...     encoder_config=TextEncoderConfig()
        ... )
        >>> data = transform(data)
        >>> # Text data not loaded yet
        >>> titles = data.load_title()  # Load on-demand
        >>> abstracts = data.load_abstract()
        >>> title_emb = data.load_title_embeddings()
    """

    def __call__(self, data: HyperData) -> HyperData:
        """Apply lazy loading transform to HyperData.

        Args:
            data: HyperData object to attach lazy loading methods to.

        Returns:
            HyperData object with lazy loading methods for text features.
        """
        from pyg_hyper_data.utils.text import (
            apply_node_id_mapping,
            download_tag_texts,
            encode_texts,
            parse_tag_texts,
        )

        logger.info("Setting up lazy text features for %s", self.dataset_name)

        # Step 1: Ensure TAG texts are cached
        raw_texts = download_tag_texts(
            self.dataset_name,
            self.cache_dir,
            force_redownload=self.force_redownload,
        )
        total_nodes = len(raw_texts)
        logger.info("Cached %d raw texts from TAG", total_nodes)

        # Step 2: Parse and cache (to get counts)
        titles, abstracts = parse_tag_texts(raw_texts)
        logger.info("Parsed %d titles and %d abstracts", len(titles), len(abstracts))

        # Step 3: Ensure embeddings are cached
        embeddings_cache_dir = self.cache_dir / "text_embeddings"
        embeddings_cache_dir.mkdir(parents=True, exist_ok=True)

        model_slug = self.encoder_config.model_name.replace("/", "_").replace("-", "_")

        # Encode titles if not cached
        title_cache = embeddings_cache_dir / f"{model_slug}_title.pt"
        if self.force_reencode and title_cache.exists():
            logger.info("Force re-encoding: removing cached title embeddings")
            title_cache.unlink()

        if not title_cache.exists():
            logger.info("Pre-encoding titles for lazy loading")
            encode_texts(
                titles,
                self.encoder_config,
                cache_file=title_cache,
            )

        # Encode abstracts if not cached
        abstract_cache = embeddings_cache_dir / f"{model_slug}_abstract.pt"
        if self.force_reencode and abstract_cache.exists():
            logger.info("Force re-encoding: removing cached abstract embeddings")
            abstract_cache.unlink()

        if not abstract_cache.exists():
            logger.info("Pre-encoding abstracts for lazy loading")
            encode_texts(
                abstracts,
                self.encoder_config,
                cache_file=abstract_cache,
            )

        # Step 4: Store cache information in data
        data._text_features_cache_dir = self.cache_dir  # noqa: SLF001
        data._title_cache_file = title_cache  # noqa: SLF001
        data._abstract_cache_file = abstract_cache  # noqa: SLF001
        data._text_node_id_map = self.node_id_map  # noqa: SLF001
        data._text_total_nodes = total_nodes  # noqa: SLF001

        # Step 5: Attach lazy loading methods
        def load_title() -> list[str]:
            """Load titles on-demand."""
            logger.info("Lazy loading titles from cache")
            texts = torch.load(
                data._text_features_cache_dir / "tag_raw_texts.pt",  # noqa: SLF001
                weights_only=False,
            )
            titles_list, _ = parse_tag_texts(texts)

            if data._text_node_id_map is not None:  # noqa: SLF001
                titles_list, _ = apply_node_id_mapping(
                    titles_list,
                    None,
                    data._text_node_id_map,  # noqa: SLF001
                    data._text_total_nodes,  # noqa: SLF001
                )

            return titles_list  # type: ignore[return-value]

        def load_abstract() -> list[str]:
            """Load abstracts on-demand."""
            logger.info("Lazy loading abstracts from cache")
            texts = torch.load(
                data._text_features_cache_dir / "tag_raw_texts.pt",  # noqa: SLF001
                weights_only=False,
            )
            _, abstracts_list = parse_tag_texts(texts)

            if data._text_node_id_map is not None:  # noqa: SLF001
                abstracts_list, _ = apply_node_id_mapping(
                    abstracts_list,
                    None,
                    data._text_node_id_map,  # noqa: SLF001
                    data._text_total_nodes,  # noqa: SLF001
                )

            return abstracts_list  # type: ignore[return-value]

        def load_title_embeddings() -> torch.Tensor:
            """Load title embeddings on-demand."""
            logger.info("Lazy loading title embeddings from cache")
            embeddings = torch.load(
                data._title_cache_file,  # noqa: SLF001
                weights_only=True,
            )

            if data._text_node_id_map is not None:  # noqa: SLF001
                _, embeddings = apply_node_id_mapping(
                    None,
                    embeddings,
                    data._text_node_id_map,  # noqa: SLF001
                    data._text_total_nodes,  # noqa: SLF001
                )

            return embeddings  # type: ignore[return-value]

        def load_abstract_embeddings() -> torch.Tensor:
            """Load abstract embeddings on-demand."""
            logger.info("Lazy loading abstract embeddings from cache")
            embeddings = torch.load(
                data._abstract_cache_file,  # noqa: SLF001
                weights_only=True,
            )

            if data._text_node_id_map is not None:  # noqa: SLF001
                _, embeddings = apply_node_id_mapping(
                    None,
                    embeddings,
                    data._text_node_id_map,  # noqa: SLF001
                    data._text_total_nodes,  # noqa: SLF001
                )

            return embeddings  # type: ignore[return-value]

        data.load_title = load_title
        data.load_abstract = load_abstract
        data.load_title_embeddings = load_title_embeddings
        data.load_abstract_embeddings = load_abstract_embeddings

        logger.info(
            "Lazy text features ready: call data.load_title(), data.load_abstract(), "
            "data.load_title_embeddings(), or data.load_abstract_embeddings() to load on-demand"
        )

        return data

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"{self.__class__.__name__}("
            f"dataset={self.dataset_name}, "
            f"encoder={self.encoder_config.model_name}, "
            f"lazy=True)"
        )
