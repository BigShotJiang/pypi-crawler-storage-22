"""Utilities for downloading files from URLs."""

import logging
import shutil
import tarfile
import urllib.request
import zipfile
from pathlib import Path
from urllib.error import URLError

from tqdm import tqdm

logger = logging.getLogger(__name__)


def download_url(
    url: str,
    folder: str | Path,
    filename: str | None = None,
    log: bool = True,
) -> str:
    """Download a file from a URL to a folder.

    Args:
        url: URL to download from
        folder: Destination folder
        filename: Filename to save as (if None, inferred from URL)
        log: Whether to print download progress

    Returns:
        Path to the downloaded file

    Raises:
        URLError: If download fails
    """
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)

    if filename is None:
        filename = url.rpartition("/")[-1]
        filename = filename or "download"

    filepath = folder / filename

    # Skip if file already exists
    if filepath.exists():
        if log:
            print(f"File {filepath} already exists, skipping download")  # noqa: T201
        return str(filepath)

    if log:
        print(f"Downloading {url}")  # noqa: T201

    try:
        # Download with progress bar
        with urllib.request.urlopen(url) as response:  # noqa: S310
            total_size = int(response.headers.get("Content-Length", 0))

            with filepath.open("wb") as f:
                if total_size > 0:
                    with tqdm(
                        total=total_size,
                        unit="B",
                        unit_scale=True,
                        unit_divisor=1024,
                        disable=not log,
                    ) as pbar:
                        while True:
                            chunk = response.read(8192)
                            if not chunk:
                                break
                            f.write(chunk)
                            pbar.update(len(chunk))
                else:
                    # No content length, download without progress bar
                    f.write(response.read())

        if log:
            print(f"Downloaded to {filepath}")  # noqa: T201

    except URLError as e:
        if filepath.exists():
            filepath.unlink()
        msg = f"Failed to download {url}: {e}"
        raise URLError(msg) from e

    return str(filepath)


def extract_zip(
    zip_path: str | Path, extract_to: str | Path, remove_zip: bool = False
) -> Path:
    """Extract a zip file.

    Args:
        zip_path: Path to zip file
        extract_to: Directory to extract to
        remove_zip: Whether to remove zip file after extraction

    Returns:
        Path to extraction directory
    """
    zip_path = Path(zip_path)
    extract_to = Path(extract_to)
    extract_to.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(extract_to)  # noqa: S202

    if remove_zip:
        zip_path.unlink()

    return extract_to


def extract_tar(
    tar_path: str | Path,
    extract_to: str | Path,
    mode: str = "r:gz",
    remove_tar: bool = False,
) -> Path:
    """Extract a tar file.

    Args:
        tar_path: Path to tar file
        extract_to: Directory to extract to
        mode: Tar file mode ('r:gz' for .tar.gz, 'r:bz2' for .tar.bz2, etc.)
        remove_tar: Whether to remove tar file after extraction

    Returns:
        Path to extraction directory
    """
    tar_path = Path(tar_path)
    extract_to = Path(extract_to)
    extract_to.mkdir(parents=True, exist_ok=True)

    with tarfile.open(tar_path, mode) as tar_ref:  # type: ignore[call-overload]
        tar_ref.extractall(extract_to)  # noqa: S202

    if remove_tar:
        tar_path.unlink()

    return extract_to


def download_and_extract(
    url: str,
    folder: str | Path,
    filename: str | None = None,
    remove_archive: bool = True,
    log: bool = True,
) -> Path:
    """Download and extract an archive file.

    Supports .zip, .tar.gz, .tar.bz2, .tgz, .tbz2

    Args:
        url: URL to download from
        folder: Destination folder
        filename: Filename to save as (if None, inferred from URL)
        remove_archive: Whether to remove archive after extraction
        log: Whether to print progress

    Returns:
        Path to extraction directory
    """
    filepath = download_url(url, folder, filename, log=log)
    filepath = Path(filepath)

    if log:
        print(f"Extracting {filepath}")  # noqa: T201

    if filepath.suffix == ".zip":
        extract_to = filepath.parent / filepath.stem
        extract_zip(filepath, extract_to, remove_zip=remove_archive)
    elif filepath.suffix in [".gz", ".bz2"] and filepath.stem.endswith(".tar"):
        # .tar.gz or .tar.bz2
        extract_to = filepath.parent / filepath.stem.replace(".tar", "")
        mode = "r:gz" if filepath.suffix == ".gz" else "r:bz2"
        extract_tar(filepath, extract_to, mode=mode, remove_tar=remove_archive)
    elif filepath.suffix in [".tgz", ".tbz2"]:
        # .tgz or .tbz2
        extract_to = filepath.parent / filepath.stem
        mode = "r:gz" if filepath.suffix == ".tgz" else "r:bz2"
        extract_tar(filepath, extract_to, mode=mode, remove_tar=remove_archive)
    else:
        if log:
            print(f"Unknown archive format: {filepath.suffix}, skipping extraction")  # noqa: T201
        extract_to = filepath.parent

    if log:
        print(f"Extracted to {extract_to}")  # noqa: T201

    return extract_to


def download_tricl_data(root: Path) -> None:
    """Download and extract TriCL hypergraph datasets.

    Downloads the TriCL dataset repository which contains standard hypergraph
    benchmarks used in research. The data is downloaded from GitHub and extracted
    to the specified root directory.

    Expected structure after download:
        root/
        ├── cocitation/
        │   ├── cora/
        │   ├── citeseer/
        │   └── pubmed/
        ├── coauthorship/
        │   ├── cora/
        │   └── dblp/
        ├── NTU2012/
        ├── ModelNet40/
        ├── Mushroom/
        ├── 20newsW100/
        └── zoo/

    Args:
        root: Root directory to download and extract data to

    References:
        TriCL repository: https://github.com/wooner49/TriCL
    """
    root = Path(root)

    # Check if data already exists
    required_dirs = [
        root / "cocitation" / "cora",
        root / "cocitation" / "citeseer",
        root / "cocitation" / "pubmed",
        root / "coauthorship" / "cora",
        root / "coauthorship" / "dblp",
    ]

    if all(d.exists() for d in required_dirs):
        logger.info("TriCL data already exists in %s", root)
        return

    logger.info("Downloading TriCL dataset from GitHub...")

    # Download from TriCL repository
    url = "https://github.com/wooner49/TriCL/raw/refs/heads/main/dataset.zip"

    try:
        # Download zip file
        zip_path = root / "dataset.zip"
        download_url(url, root, "dataset.zip", log=True)

        logger.info("Extracting TriCL dataset...")

        # Extract zip
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(root)  # noqa: S202

        # Reorganize directory structure
        extracted_dir = root / "dataset"
        if extracted_dir.exists():
            logger.info("Reorganizing directory structure...")

            # Move cocitation datasets
            for dataset_name in ["cora", "citeseer", "pubmed"]:
                src = extracted_dir / "cocitation" / dataset_name
                if src.exists():
                    dst = root / "cocitation" / dataset_name
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    if dst.exists():
                        shutil.rmtree(dst)
                    shutil.move(str(src), str(dst))
                    logger.info("Moved %s to %s", src, dst)

            # Move coauthorship datasets
            for dataset_name in ["cora", "dblp"]:
                src = extracted_dir / "coauthorship" / dataset_name
                if src.exists():
                    dst = root / "coauthorship" / dataset_name
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    if dst.exists():
                        shutil.rmtree(dst)
                    shutil.move(str(src), str(dst))
                    logger.info("Moved %s to %s", src, dst)

            # Move other datasets
            for dataset_name in [
                "NTU2012",
                "ModelNet40",
                "Mushroom",
                "20newsW100",
                "zoo",
            ]:
                src = extracted_dir / dataset_name
                if src.exists():
                    dst = root / dataset_name
                    if dst.exists():
                        shutil.rmtree(dst)
                    shutil.move(str(src), str(dst))
                    logger.info("Moved %s to %s", src, dst)

            # Clean up extracted directory
            shutil.rmtree(extracted_dir)

        # Remove zip file
        zip_path.unlink()

        logger.info("TriCL dataset download and extraction complete")

    except Exception:
        logger.exception("Failed to download TriCL dataset")
        raise


def download_dhgbench_data(
    root: Path,
    dataset_type: str,
    dataset_name: str,
) -> None:
    """Download DHG-Bench dataset from GitHub.

    This function downloads DHG-Bench datasets from the official GitHub repository.
    DHG-Bench datasets preserve original node IDs and are essential for multimodal
    feature collection.

    Expected structure after download:
        root/
        ├── cocitation/
        │   ├── cora/
        │   │   ├── features.pickle
        │   │   ├── hypergraph.pickle
        │   │   ├── labels.pickle
        │   │   └── splits/
        │   ├── citeseer/
        │   └── pubmed/
        ├── coauthorship/
        │   ├── cora/
        │   └── dblp/
        └── [other dataset types]

    Args:
        root: Root directory for dataset
        dataset_type: Type of dataset (e.g., "cocitation", "coauthorship")
        dataset_name: Name of dataset (e.g., "cora", "pubmed", "dblp")

    Raises:
        FileNotFoundError: If dataset files are not found after extraction

    References:
        DHG-Bench: https://github.com/Coco-Hut/DHG-Bench

    Note:
        Downloads the entire data.zip file (~2GB) from DHG-Bench GitHub releases.
        The download is cached, so subsequent dataset loads will not re-download.
    """
    root = Path(root)
    dst = root / dataset_type / dataset_name

    # Check if data already exists
    required_files = ["features.pickle", "hypergraph.pickle", "labels.pickle"]
    if dst.exists() and all((dst / f).exists() for f in required_files):
        logger.info(
            "DHG-Bench %s/%s data already exists in %s", dataset_type, dataset_name, dst
        )
        return

    logger.info(
        "Downloading DHG-Bench %s/%s from GitHub...", dataset_type, dataset_name
    )

    # DHG-Bench data.zip URL (hosted on GitHub repository)
    # Note: This downloads the entire ~2GB data.zip file
    data_zip_url = "https://github.com/Coco-Hut/DHG-Bench/raw/main/data.zip"

    # Download data.zip to a temporary directory in root
    temp_dir = root / "_dhgbench_temp"
    temp_dir.mkdir(parents=True, exist_ok=True)
    zip_path = temp_dir / "data.zip"

    # Check if data.zip already downloaded
    if not zip_path.exists():
        logger.info("Downloading DHG-Bench data.zip (~2GB)...")
        logger.info("This is a one-time download and will be cached.")
        download_url(data_zip_url, temp_dir, "data.zip", log=True)
    else:
        logger.info("Using cached data.zip from %s", zip_path)

    # Extract the specific dataset
    logger.info("Extracting %s/%s from data.zip...", dataset_type, dataset_name)

    # Map dataset types to DHG-Bench directory structure
    type_mapping = {
        "cocitation": "trad_data/cocitation",
        "coauthorship": "trad_data/coauthorship",
    }

    dhgbench_subdir = type_mapping.get(dataset_type, f"trad_data/{dataset_type}")
    dataset_path_in_zip = f"data/{dhgbench_subdir}/{dataset_name}"

    # Extract only the required dataset files
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        # Get all files for this dataset
        dataset_files = [
            f for f in zip_ref.namelist() if f.startswith(dataset_path_in_zip + "/")
        ]

        if not dataset_files:
            msg = (
                f"Dataset {dataset_type}/{dataset_name} not found in data.zip. "
                f"Available paths: {[f for f in zip_ref.namelist() if dataset_name in f][:5]}"
            )
            raise FileNotFoundError(msg)

        # Extract to temporary location
        extract_temp = temp_dir / "extracted"
        for file in dataset_files:
            zip_ref.extract(file, extract_temp)

        # Move to final destination
        src = extract_temp / "data" / dhgbench_subdir / dataset_name
        dst.parent.mkdir(parents=True, exist_ok=True)

        if dst.exists():
            shutil.rmtree(dst)

        shutil.move(str(src), str(dst))
        logger.info("Moved %s to %s", src, dst)

        # Clean up extracted temp directory
        shutil.rmtree(extract_temp)

    # Verify all required files exist
    missing_files = [f for f in required_files if not (dst / f).exists()]
    if missing_files:
        msg = f"Missing required files in {dst}: {missing_files}"
        raise FileNotFoundError(msg)

    logger.info("DHG-Bench %s/%s download complete", dataset_type, dataset_name)
