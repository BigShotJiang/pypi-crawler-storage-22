"""Utilities for I/O operations with hypergraph data."""

import json
import pickle
from collections.abc import Iterator
from pathlib import Path
from typing import Any

import pandas as pd
import torch


def load_csv_hypergraph(
    filepath: str | Path,
) -> tuple[dict[int, dict[str, Any]], list[dict[str, Any]]]:
    """Load a hypergraph from CSV files.

    Expected format:
    - {filepath}_nodes.csv: node_id, feature_1, ..., feature_n, label
    - {filepath}_hyperedges.csv: hyperedge_id, node_1, node_2, ..., node_k

    Args:
        filepath: Base path (without _nodes or _hyperedges suffix)

    Returns:
        Tuple of (nodes, hyperedges) where:
        - nodes: dict mapping node_id to {'features': tensor, 'label': int}
        - hyperedges: list of {'nodes': list[int], 'features': tensor (optional)}
    """
    filepath = Path(filepath)

    # Load nodes
    nodes_path = filepath.parent / f"{filepath.stem}_nodes.csv"
    if not nodes_path.exists():
        msg = f"Nodes file not found: {nodes_path}"
        raise FileNotFoundError(msg)

    nodes_df = pd.read_csv(nodes_path)
    nodes = {}

    for _idx, row in nodes_df.iterrows():
        node_id = int(row["node_id"])
        label = int(row["label"])

        # Extract features (all columns except node_id and label)
        feature_cols = [
            col for col in nodes_df.columns if col not in ["node_id", "label"]
        ]
        features = row[feature_cols].to_numpy().astype(float)

        nodes[node_id] = {
            "features": torch.tensor(features, dtype=torch.float),
            "label": label,
        }

    # Load hyperedges
    edges_path = filepath.parent / f"{filepath.stem}_hyperedges.csv"
    if not edges_path.exists():
        msg = f"Hyperedges file not found: {edges_path}"
        raise FileNotFoundError(msg)

    edges_df = pd.read_csv(edges_path)
    hyperedges = []

    for _idx, row in edges_df.iterrows():
        # Get all node columns (excluding hyperedge_id)
        node_cols = [col for col in edges_df.columns if col.startswith("node_")]

        # Extract node IDs (filter out NaN)
        node_list = [int(row[col]) for col in node_cols if pd.notna(row[col])]

        hyperedges.append({"nodes": node_list})

    return nodes, hyperedges


def load_json_hypergraph(
    filepath: str | Path,
) -> tuple[dict[int, dict[str, Any]], list[dict[str, Any]]]:
    """Load a hypergraph from a JSON file.

    Expected format:
    {
        "nodes": [
            {"id": 0, "features": [...], "label": 0},
            ...
        ],
        "hyperedges": [
            {"id": 0, "nodes": [0, 1, 2], "features": [...]},
            ...
        ]
    }

    Args:
        filepath: Path to JSON file

    Returns:
        Tuple of (nodes, hyperedges) where:
        - nodes: dict mapping node_id to {'features': tensor, 'label': int}
        - hyperedges: list of {'nodes': list[int], 'features': tensor (optional)}
    """
    filepath = Path(filepath)

    with filepath.open() as f:
        data = json.load(f)

    # Process nodes
    nodes = {}
    for node in data["nodes"]:
        node_id = int(node["id"])
        nodes[node_id] = {
            "features": torch.tensor(node["features"], dtype=torch.float),
            "label": int(node["label"]),
        }

    # Process hyperedges
    hyperedges = []
    for he in data["hyperedges"]:
        he_dict = {"nodes": [int(n) for n in he["nodes"]]}

        # Add features if present
        if he.get("features"):
            he_dict["features"] = torch.tensor(he["features"], dtype=torch.float)

        hyperedges.append(he_dict)

    return nodes, hyperedges


def load_pickle(filepath: str | Path) -> Any:
    """Load data from a pickle file.

    Args:
        filepath: Path to pickle file

    Returns:
        Unpickled data
    """
    filepath = Path(filepath)

    with filepath.open("rb") as f:
        return pickle.load(f)  # noqa: S301


def save_pickle(data: Any, filepath: str | Path) -> None:
    """Save data to a pickle file.

    Args:
        data: Data to pickle
        filepath: Path to save pickle file
    """
    filepath = Path(filepath)
    filepath.parent.mkdir(parents=True, exist_ok=True)

    with filepath.open("wb") as f:
        pickle.dump(data, f)


def load_json(filepath: str | Path) -> dict:
    """Load data from a JSON file.

    Args:
        filepath: Path to JSON file

    Returns:
        JSON data as dict
    """
    filepath = Path(filepath)

    with filepath.open() as f:
        return json.load(f)


def save_json(data: dict, filepath: str | Path, indent: int = 2) -> None:
    """Save data to a JSON file.

    Args:
        data: Data to save
        filepath: Path to save JSON file
        indent: JSON indentation level
    """
    filepath = Path(filepath)
    filepath.parent.mkdir(parents=True, exist_ok=True)

    with filepath.open("w") as f:
        json.dump(data, f, indent=indent)


# ============================================================================
# Large-scale data support (memory-efficient I/O)
# ============================================================================


def load_csv_hypergraph_chunked(
    filepath: str | Path,
    chunksize: int = 10000,
    backend: str = "pandas",
) -> Iterator[tuple[dict[int, dict[str, Any]], list[dict[str, Any]]]]:
    """Load a hypergraph from CSV files in chunks (memory-efficient).

    This function is designed for large-scale datasets that don't fit in memory.
    It yields chunks of nodes and hyperedges that can be processed incrementally.

    Expected format:
    - {filepath}_nodes.csv: node_id, feature_1, ..., feature_n, label
    - {filepath}_hyperedges.csv: hyperedge_id, node_1, node_2, ..., node_k

    Args:
        filepath: Base path (without _nodes or _hyperedges suffix)
        chunksize: Number of rows to read per chunk
        backend: Backend to use ('pandas' or 'polars')

    Yields:
        Tuples of (nodes, hyperedges) for each chunk

    Example:
        >>> for nodes_chunk, edges_chunk in load_csv_hypergraph_chunked('data/large_graph'):
        ...     # Process chunk
        ...     process_chunk(nodes_chunk, edges_chunk)
    """
    filepath = Path(filepath)

    if backend == "pandas":
        yield from _load_csv_hypergraph_chunked_pandas(filepath, chunksize)
    elif backend == "polars":
        yield from _load_csv_hypergraph_chunked_polars(filepath, chunksize)
    else:
        msg = f"Unknown backend: {backend}. Use 'pandas' or 'polars'"
        raise ValueError(msg)


def _load_csv_hypergraph_chunked_pandas(
    filepath: Path, chunksize: int
) -> Iterator[tuple[dict[int, dict[str, Any]], list[dict[str, Any]]]]:
    """Pandas implementation of chunked CSV loading."""
    nodes_path = filepath.parent / f"{filepath.stem}_nodes.csv"
    edges_path = filepath.parent / f"{filepath.stem}_hyperedges.csv"

    if not nodes_path.exists():
        msg = f"Nodes file not found: {nodes_path}"
        raise FileNotFoundError(msg)
    if not edges_path.exists():
        msg = f"Hyperedges file not found: {edges_path}"
        raise FileNotFoundError(msg)

    # Read nodes in chunks
    for nodes_chunk in pd.read_csv(nodes_path, chunksize=chunksize):
        nodes = {}
        feature_cols = [
            col for col in nodes_chunk.columns if col not in ["node_id", "label"]
        ]

        for _, row in nodes_chunk.iterrows():
            node_id = int(row["node_id"])
            label = int(row["label"])
            features = row[feature_cols].to_numpy().astype(float)

            nodes[node_id] = {
                "features": torch.tensor(features, dtype=torch.float),
                "label": label,
            }

        # Read corresponding hyperedges chunk
        # Note: This is a simple implementation. For very large datasets,
        # you might want to coordinate node and edge chunks differently.
        hyperedges = []
        for edges_chunk in pd.read_csv(edges_path, chunksize=chunksize):
            node_cols = [col for col in edges_chunk.columns if col.startswith("node_")]

            for _, row in edges_chunk.iterrows():
                node_list = [int(row[col]) for col in node_cols if pd.notna(row[col])]

                hyperedges.append({"nodes": node_list})

            break  # Only read one chunk of edges per node chunk

        yield nodes, hyperedges


def _load_csv_hypergraph_chunked_polars(
    filepath: Path, chunksize: int
) -> Iterator[tuple[dict[int, dict[str, Any]], list[dict[str, Any]]]]:
    """Polars implementation of chunked CSV loading (lazy evaluation)."""
    try:
        import polars as pl  # type: ignore[import-not-found]
    except ImportError:
        msg = (
            "Polars is not installed. "
            "Install it with: pip install pyg-hyper-data[large-scale]"
        )
        raise ImportError(msg) from None

    nodes_path = filepath.parent / f"{filepath.stem}_nodes.csv"
    edges_path = filepath.parent / f"{filepath.stem}_hyperedges.csv"

    if not nodes_path.exists():
        msg = f"Nodes file not found: {nodes_path}"
        raise FileNotFoundError(msg)
    if not edges_path.exists():
        msg = f"Hyperedges file not found: {edges_path}"
        raise FileNotFoundError(msg)

    # Use Polars lazy API for memory efficiency
    nodes_lazy = pl.scan_csv(nodes_path)

    # Process in batches
    total_rows = nodes_lazy.select(pl.len()).collect().item()

    for offset in range(0, total_rows, chunksize):
        # Read nodes chunk with Polars
        nodes_chunk = nodes_lazy.slice(offset, chunksize).collect()

        nodes = {}
        feature_cols = [
            col for col in nodes_chunk.columns if col not in ["node_id", "label"]
        ]

        for row in nodes_chunk.iter_rows(named=True):
            node_id = int(row["node_id"])
            label = int(row["label"])
            features = [float(row[col]) for col in feature_cols]

            nodes[node_id] = {
                "features": torch.tensor(features, dtype=torch.float),
                "label": label,
            }

        # Read hyperedges chunk
        edges_lazy = pl.scan_csv(edges_path)
        edges_chunk = edges_lazy.slice(offset, chunksize).collect()

        hyperedges = []
        node_cols = [col for col in edges_chunk.columns if col.startswith("node_")]

        for row in edges_chunk.iter_rows(named=True):
            node_list = [int(row[col]) for col in node_cols if row[col] is not None]

            hyperedges.append({"nodes": node_list})

        yield nodes, hyperedges


def load_csv_hypergraph_polars(
    filepath: str | Path,
) -> tuple[dict[int, dict[str, Any]], list[dict[str, Any]]]:
    """Load a hypergraph from CSV files using Polars (fast and memory-efficient).

    Polars is typically 2-5x faster than Pandas and uses less memory.

    Expected format:
    - {filepath}_nodes.csv: node_id, feature_1, ..., feature_n, label
    - {filepath}_hyperedges.csv: hyperedge_id, node_1, node_2, ..., node_k

    Args:
        filepath: Base path (without _nodes or _hyperedges suffix)

    Returns:
        Tuple of (nodes, hyperedges) where:
        - nodes: dict mapping node_id to {'features': tensor, 'label': int}
        - hyperedges: list of {'nodes': list[int], 'features': tensor (optional)}
    """
    try:
        import polars as pl  # type: ignore[import-not-found]
    except ImportError:
        msg = (
            "Polars is not installed. "
            "Install it with: pip install pyg-hyper-data[large-scale]"
        )
        raise ImportError(msg) from None

    filepath = Path(filepath)

    # Load nodes
    nodes_path = filepath.parent / f"{filepath.stem}_nodes.csv"
    if not nodes_path.exists():
        msg = f"Nodes file not found: {nodes_path}"
        raise FileNotFoundError(msg)

    nodes_df = pl.read_csv(nodes_path)
    nodes = {}

    feature_cols = [col for col in nodes_df.columns if col not in ["node_id", "label"]]

    for row in nodes_df.iter_rows(named=True):
        node_id = int(row["node_id"])
        label = int(row["label"])
        features = [float(row[col]) for col in feature_cols]

        nodes[node_id] = {
            "features": torch.tensor(features, dtype=torch.float),
            "label": label,
        }

    # Load hyperedges
    edges_path = filepath.parent / f"{filepath.stem}_hyperedges.csv"
    if not edges_path.exists():
        msg = f"Hyperedges file not found: {edges_path}"
        raise FileNotFoundError(msg)

    edges_df = pl.read_csv(edges_path)
    hyperedges = []

    node_cols = [col for col in edges_df.columns if col.startswith("node_")]

    for row in edges_df.iter_rows(named=True):
        node_list = [int(row[col]) for col in node_cols if row[col] is not None]

        hyperedges.append({"nodes": node_list})

    return nodes, hyperedges


def load_jsonl_hypergraph(
    filepath: str | Path,
) -> Iterator[dict[str, Any]]:
    """Load a hypergraph from JSONLines format (streaming, memory-efficient).

    JSONLines format: one JSON object per line
    Each line can be either a node or a hyperedge:
    - Node: {"type": "node", "id": 0, "features": [...], "label": 0}
    - Hyperedge: {"type": "hyperedge", "id": 0, "nodes": [0, 1, 2]}

    This function is a generator that yields one object at a time,
    making it suitable for very large datasets.

    Args:
        filepath: Path to JSONLines file

    Yields:
        Dictionaries representing nodes or hyperedges

    Example:
        >>> nodes = {}
        >>> hyperedges = []
        >>> for obj in load_jsonl_hypergraph('data/large_graph.jsonl'):
        ...     if obj['type'] == 'node':
        ...         nodes[obj['id']] = obj
        ...     else:
        ...         hyperedges.append(obj)
    """
    filepath = Path(filepath)

    with filepath.open() as f:
        for raw_line in f:
            line = raw_line.strip()
            if line:  # Skip empty lines
                yield json.loads(line)


def save_jsonl_hypergraph(
    nodes: dict[int, dict[str, Any]],
    hyperedges: list[dict[str, Any]],
    filepath: str | Path,
) -> None:
    """Save a hypergraph to JSONLines format (streaming, memory-efficient).

    Args:
        nodes: Dictionary mapping node_id to node data
        hyperedges: List of hyperedge dictionaries
        filepath: Path to save JSONLines file
    """
    filepath = Path(filepath)
    filepath.parent.mkdir(parents=True, exist_ok=True)

    with filepath.open("w") as f:
        # Write nodes
        for node_id, node_data in nodes.items():
            obj = {"type": "node", "id": node_id, **node_data}
            # Convert tensors to lists for JSON serialization
            if "features" in obj and isinstance(obj["features"], torch.Tensor):
                obj["features"] = obj["features"].tolist()
            f.write(json.dumps(obj) + "\n")

        # Write hyperedges
        for he_id, he_data in enumerate(hyperedges):
            obj = {"type": "hyperedge", "id": he_id, **he_data}
            if "features" in obj and isinstance(obj["features"], torch.Tensor):
                obj["features"] = obj["features"].tolist()
            f.write(json.dumps(obj) + "\n")
