"""Statistical analysis utilities for hypergraphs."""

import logging

import torch
from torch_geometric.data import Data

logger = logging.getLogger(__name__)


def compute_hypergraph_statistics(data: Data) -> dict[str, float | int]:
    """Compute comprehensive statistics for a hypergraph.

    Args:
        data: HyperData object with hyperedge_index

    Returns:
        Dictionary containing statistics:
            - num_nodes: Number of nodes
            - num_hyperedges: Number of hyperedges
            - num_connections: Total node-hyperedge connections
            - avg_hyperedge_size: Average hyperedge cardinality
            - max_hyperedge_size: Maximum hyperedge size
            - min_hyperedge_size: Minimum hyperedge size
            - avg_node_degree: Average node degree
            - max_node_degree: Maximum node degree
            - min_node_degree: Minimum node degree
            - density: Hypergraph density

    Example:
        >>> data = HyperData(x=..., hyperedge_index=...)
        >>> stats = compute_hypergraph_statistics(data)
        >>> logger.info(f"Avg hyperedge size: {stats['avg_hyperedge_size']:.2f}")
    """
    hyperedge_index = data.hyperedge_index
    num_nodes = data.num_nodes if data.num_nodes is not None else 0

    # Basic counts
    num_connections = hyperedge_index.size(1)
    num_hyperedges = int(hyperedge_index[1].max()) + 1 if num_connections > 0 else 0

    # Hyperedge sizes
    hyperedge_sizes = torch.bincount(hyperedge_index[1], minlength=num_hyperedges)
    avg_hyperedge_size = float(hyperedge_sizes.float().mean())
    max_hyperedge_size = int(hyperedge_sizes.max()) if num_hyperedges > 0 else 0
    min_hyperedge_size = int(hyperedge_sizes.min()) if num_hyperedges > 0 else 0

    # Node degrees
    node_degrees = torch.bincount(hyperedge_index[0], minlength=num_nodes)
    avg_node_degree = float(node_degrees.float().mean())
    max_node_degree = int(node_degrees.max()) if num_nodes > 0 else 0
    min_node_degree = int(node_degrees.min()) if num_nodes > 0 else 0

    # Density: ratio of actual connections to possible connections
    # Possible connections = num_nodes * num_hyperedges
    possible_connections = (
        num_nodes * num_hyperedges if num_nodes > 0 and num_hyperedges > 0 else 1
    )
    density = num_connections / possible_connections

    return {
        "num_nodes": num_nodes,
        "num_hyperedges": num_hyperedges,
        "num_connections": num_connections,
        "avg_hyperedge_size": avg_hyperedge_size,
        "max_hyperedge_size": max_hyperedge_size,
        "min_hyperedge_size": min_hyperedge_size,
        "avg_node_degree": avg_node_degree,
        "max_node_degree": max_node_degree,
        "min_node_degree": min_node_degree,
        "density": density,
    }


def compute_label_statistics(data: Data) -> dict[str, int | float | list[int]]:
    """Compute label distribution statistics.

    Args:
        data: Data object with y (node labels)

    Returns:
        Dictionary containing:
            - num_classes: Number of unique classes
            - class_counts: List of counts per class
            - class_balance: Ratio of min to max class count (1.0 = perfectly balanced)

    Example:
        >>> data = HyperData(y=torch.tensor([0, 0, 1, 1, 2]))
        >>> stats = compute_label_statistics(data)
        >>> logger.info(f"Classes: {stats['num_classes']}, Balance: {stats['class_balance']:.2f}")
    """
    if not hasattr(data, "y") or data.y is None:
        return {"num_classes": 0, "class_counts": [], "class_balance": 0.0}

    y = data.y
    num_classes = int(y.max()) + 1  # type: ignore[union-attr]
    class_counts = torch.bincount(y, minlength=num_classes).tolist()  # type: ignore[arg-type]

    # Class balance: ratio of smallest to largest class
    if num_classes > 0 and max(class_counts) > 0:
        class_balance = min(class_counts) / max(class_counts)
    else:
        class_balance = 0.0

    return {
        "num_classes": num_classes,
        "class_counts": class_counts,
        "class_balance": class_balance,
    }


def log_statistics(data: Data, name: str = "Dataset") -> None:
    """Log formatted statistics for a hypergraph dataset.

    Args:
        data: HyperData object
        name: Dataset name for display

    Example:
        >>> data = HyperData(x=..., hyperedge_index=..., y=...)
        >>> log_statistics(data, "Cora")
    """
    logger.info("=" * 60)
    logger.info("%s Statistics", name)
    logger.info("=" * 60)

    # Hypergraph statistics
    hyper_stats = compute_hypergraph_statistics(data)
    logger.info("Hypergraph Structure:")
    logger.info("  Nodes:            %d", hyper_stats["num_nodes"])
    logger.info("  Hyperedges:       %d", hyper_stats["num_hyperedges"])
    logger.info("  Connections:      %d", hyper_stats["num_connections"])
    logger.info("  Density:          %.4f", hyper_stats["density"])

    logger.info("Hyperedge Sizes:")
    logger.info("  Average:          %.2f", hyper_stats["avg_hyperedge_size"])
    logger.info("  Min:              %d", hyper_stats["min_hyperedge_size"])
    logger.info("  Max:              %d", hyper_stats["max_hyperedge_size"])

    logger.info("Node Degrees:")
    logger.info("  Average:          %.2f", hyper_stats["avg_node_degree"])
    logger.info("  Min:              %d", hyper_stats["min_node_degree"])
    logger.info("  Max:              %d", hyper_stats["max_node_degree"])

    # Label statistics
    if hasattr(data, "y") and data.y is not None:
        label_stats = compute_label_statistics(data)
        logger.info("Label Distribution:")
        logger.info("  Classes:          %d", label_stats["num_classes"])
        logger.info("  Class balance:    %.2f", label_stats["class_balance"])
        logger.info("  Class counts:     %s", label_stats["class_counts"])

    # Feature statistics
    if hasattr(data, "x") and data.x is not None:
        logger.info("Node Features:")
        logger.info("  Dimensions:       %d", data.x.size(1))

    logger.info("=" * 60)
