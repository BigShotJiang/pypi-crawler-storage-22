"""Utilities for loading TAG text features and encoding with sentence-transformers."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import torch

if TYPE_CHECKING:
    from pathlib import Path

    from pyg_hyper_data.config.text import TextEncoderConfig

logger = logging.getLogger(__name__)


def parse_tag_text(text: str) -> tuple[str, str]:
    r"""Parse TAG text format into separate title and abstract.

    TAG texts are formatted as: "Title: {title} \t Abstract: {abstract}"

    Args:
        text: Combined text string from TAG dataset.

    Returns:
        Tuple of (title, abstract) strings.

    Example:
        >>> text = "Title: Neural Networks \t Abstract: This paper discusses..."
        >>> title, abstract = parse_tag_text(text)
        >>> print(title)
        'Neural Networks'
    """
    # Split by tab character
    parts = text.split("\t")

    if len(parts) >= 2:
        # Extract title (remove "Title: " prefix)
        title_part = parts[0].strip()
        title = title_part.removeprefix("Title: ")

        # Extract abstract (remove "Abstract: " prefix)
        abstract_part = parts[1].strip()
        abstract = abstract_part.removeprefix("Abstract: ")

        return title, abstract

    # Fallback: if format is unexpected, return original text for both
    logger.warning("Unexpected TAG text format (no tab separator): %s", text[:100])
    return text, ""


def parse_tag_texts(texts: list[str]) -> tuple[list[str], list[str]]:
    r"""Parse multiple TAG texts into separate titles and abstracts.

    Args:
        texts: List of combined text strings from TAG dataset.

    Returns:
        Tuple of (titles, abstracts) lists.

    Example:
        >>> texts = ["Title: A \t Abstract: B", "Title: C \t Abstract: D"]
        >>> titles, abstracts = parse_tag_texts(texts)
        >>> len(titles)
        2
    """
    titles = []
    abstracts = []

    for text in texts:
        title, abstract = parse_tag_text(text)
        titles.append(title)
        abstracts.append(abstract)

    return titles, abstracts


def download_tag_texts(
    dataset_name: str,
    cache_dir: Path,
    force_redownload: bool = False,
) -> list[str]:
    """Download TAG raw_texts.pt from HuggingFace and cache locally.

    Args:
        dataset_name: Name of the dataset (e.g., "cora", "pubmed").
        cache_dir: Directory to cache the downloaded file.
        force_redownload: If True, force re-download even if cached file exists.

    Returns:
        List of text strings [num_nodes], where each string is "Title: ... Abstract: ..."

    Raises:
        ValueError: If dataset is not supported by TAG.
        OSError: If download or caching fails.

    Example:
        >>> cache_dir = Path("~/.pyg-hyper/data/cocitation-cora/multimodal")
        >>> texts = download_tag_texts("cora", cache_dir)
        >>> len(texts)
        2708
    """
    from pyg_hyper_data.config.text import TAG_HF_REPO, get_tag_filename

    # Ensure cache directory exists
    cache_dir.mkdir(parents=True, exist_ok=True)

    # Check cache
    cached_file = cache_dir / "tag_raw_texts.pt"
    if cached_file.exists() and not force_redownload:
        logger.info("Loading cached TAG texts from %s", cached_file)
        return torch.load(cached_file, weights_only=False)

    # Download from HuggingFace
    logger.info("Downloading TAG texts for %s from HuggingFace...", dataset_name)

    try:
        from huggingface_hub import hf_hub_download
    except ImportError as e:
        msg = (
            "huggingface_hub is required for loading TAG text features. "
            "Install with: pip install pyg-hyper-data[multimodal]"
        )
        raise ImportError(msg) from e

    try:
        tag_filename = get_tag_filename(dataset_name)
        hf_path = hf_hub_download(
            repo_id=TAG_HF_REPO,
            filename=tag_filename,
            repo_type="dataset",
        )
        logger.info("Downloaded TAG texts to %s", hf_path)

        # Load texts
        texts = torch.load(hf_path, weights_only=False)

        # Cache locally
        torch.save(texts, cached_file)
        logger.info("Cached TAG texts to %s", cached_file)
    except Exception as e:
        msg = (
            f"Failed to download TAG texts for {dataset_name}. "
            f"Error: {e!s}. "
            f"Please check your internet connection and try again."
        )
        raise OSError(msg) from e
    else:
        return texts


def encode_texts(
    texts: list[str],
    encoder_config: TextEncoderConfig,
    cache_file: Path | None = None,
) -> torch.Tensor:
    """Encode texts with sentence-transformers model.

    Args:
        texts: List of text strings to encode.
        encoder_config: Configuration for sentence-transformer encoding.
        cache_file: Optional path to cache the embeddings. If provided and exists,
            load from cache instead of re-encoding.

    Returns:
        Tensor of embeddings [num_texts, embedding_dim].

    Raises:
        ImportError: If sentence-transformers is not installed.

    Example:
        >>> from pyg_hyper_data.config.text import TextEncoderConfig
        >>> config = TextEncoderConfig(model_name="all-MiniLM-L6-v2")
        >>> texts = ["Paper about neural networks", "Paper about graph theory"]
        >>> embeddings = encode_texts(texts, config)
        >>> embeddings.shape
        torch.Size([2, 384])
    """
    # Check cache
    if cache_file is not None and cache_file.exists():
        logger.info("Loading cached embeddings from %s", cache_file)
        return torch.load(cache_file, weights_only=True)

    # Load sentence-transformer model
    logger.info(
        "Encoding %d texts with sentence-transformer model: %s",
        len(texts),
        encoder_config.model_name,
    )

    try:
        from sentence_transformers import (  # type: ignore[import-untyped]
            SentenceTransformer,
        )
    except ImportError as e:
        msg = (
            "sentence-transformers is required for encoding text features. "
            "Install with: pip install pyg-hyper-data[multimodal]"
        )
        raise ImportError(msg) from e

    model = SentenceTransformer(encoder_config.model_name, device=encoder_config.device)

    # Encode texts
    embeddings = model.encode(
        texts,
        batch_size=encoder_config.batch_size,
        show_progress_bar=encoder_config.show_progress_bar,
        convert_to_tensor=True,
        normalize_embeddings=encoder_config.normalize_embeddings,
    )

    logger.info("Encoded texts to embeddings with shape %s", embeddings.shape)

    # Cache if requested
    if cache_file is not None:
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        torch.save(embeddings, cache_file)
        logger.info("Cached embeddings to %s", cache_file)

    return embeddings


def apply_node_id_mapping(
    texts: list[str] | None,
    embeddings: torch.Tensor | None,
    node_id_map: dict[int, int],
    total_nodes: int,
) -> tuple[list[str] | None, torch.Tensor | None]:
    """Apply node ID mapping when isolated nodes are removed.

    When remove_isolated_nodes=True, DHG-Bench filters out isolated nodes and
    creates a mapping from original node IDs to new consecutive IDs. This function
    reorders texts and embeddings to match the new node ordering.

    Args:
        texts: List of text strings [total_nodes] or None.
        embeddings: Tensor of embeddings [total_nodes, embedding_dim] or None.
        node_id_map: Mapping from original node ID to new node ID.
            Example: {5: 0, 10: 1, 15: 2} means original node 5 becomes node 0.
        total_nodes: Total number of nodes before filtering.

    Returns:
        Tuple of (reordered_texts, reordered_embeddings).

    Example:
        >>> texts = ["paper 0", "paper 1", "paper 2", "paper 3", "paper 4"]
        >>> embeddings = torch.randn(5, 768)
        >>> node_id_map = {1: 0, 3: 1}  # Only nodes 1 and 3 are connected
        >>> reordered_texts, reordered_emb = apply_node_id_mapping(
        ...     texts, embeddings, node_id_map, 5
        ... )
        >>> len(reordered_texts)
        2
        >>> reordered_texts
        ['paper 1', 'paper 3']
    """
    # Check if identity mapping (no filtering)
    if len(node_id_map) == total_nodes and all(
        old == new for old, new in node_id_map.items()
    ):
        logger.info("Node ID mapping is identity, no reordering needed")
        return texts, embeddings

    num_nodes = len(node_id_map)
    logger.info(
        "Applying node ID mapping: %d → %d nodes (removed %d isolated)",
        total_nodes,
        num_nodes,
        total_nodes - num_nodes,
    )

    # Reorder texts
    reordered_texts = None
    if texts is not None:
        reordered_texts = [None] * num_nodes
        for old_id, new_id in node_id_map.items():
            reordered_texts[new_id] = texts[old_id]

        # Verify no None values
        if any(text is None for text in reordered_texts):
            msg = "Some texts are missing after applying node ID mapping"
            raise ValueError(msg)

    # Reorder embeddings
    reordered_embeddings = None
    if embeddings is not None:
        # Get old indices in order of new indices
        old_indices = [
            old_id for old_id, _ in sorted(node_id_map.items(), key=lambda x: x[1])
        ]
        reordered_embeddings = embeddings[old_indices]

    return reordered_texts, reordered_embeddings  # type: ignore[return-value]
