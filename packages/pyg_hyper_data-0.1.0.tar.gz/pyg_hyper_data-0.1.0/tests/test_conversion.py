"""Tests for HyperData <-> HyperHeteroData conversion."""

import pytest
import torch

from pyg_hyper_data.data import (
    HyperData,
    HyperHeteroData,
    hetero_to_hyperedge_index,
    hyperedge_index_to_hetero,
    validate_conversion,
)
from pyg_hyper_data.datasets import CoraCocitation


class TestConversion:
    """Tests for conversion between HyperData and HyperHeteroData."""

    def test_hyperedge_index_to_hetero_basic(self) -> None:
        """Test basic conversion from HyperData to HyperHeteroData."""
        # Create simple HyperData
        data = HyperData(
            x=torch.randn(10, 5),
            hyperedge_index=torch.tensor([[0, 1, 2, 3], [0, 0, 1, 1]]),
            y=torch.tensor([0, 1, 0, 1, 0, 1, 0, 1, 0, 1]),
            num_nodes=10,
            num_hyperedges=2,
        )

        # Convert to HeteroData
        hetero = hyperedge_index_to_hetero(data)

        # Check node types
        assert set(hetero.node_types) == {"node", "hyperedge"}

        # Check edge types
        assert ("node", "member_of", "hyperedge") in hetero.edge_types
        assert ("hyperedge", "has_member", "node") in hetero.edge_types

        # Check node features
        assert data.x is not None
        assert data.y is not None
        assert isinstance(data.y, torch.Tensor)
        assert torch.equal(hetero["node"].x, data.x)
        assert torch.equal(hetero["node"].y, data.y)
        assert hetero["node"].num_nodes == 10

        # Check hyperedge nodes
        assert hetero["hyperedge"].num_nodes == 2

        # Check edge indices
        edge_index = hetero["node", "member_of", "hyperedge"].edge_index
        assert data.hyperedge_index is not None
        assert torch.equal(edge_index, data.hyperedge_index)

        # Check reverse edges
        reverse_edge_index = hetero["hyperedge", "has_member", "node"].edge_index
        assert torch.equal(reverse_edge_index, data.hyperedge_index[[1, 0]])

    def test_hetero_to_hyperedge_index_basic(self) -> None:
        """Test basic conversion from HyperHeteroData to HyperData."""
        # Create HyperHeteroData
        hetero = HyperHeteroData()
        hetero["node"].x = torch.randn(10, 5)
        hetero["node"].y = torch.tensor([0, 1, 0, 1, 0, 1, 0, 1, 0, 1])
        hetero["node"].num_nodes = 10
        hetero["hyperedge"].num_nodes = 2
        hetero["node", "member_of", "hyperedge"].edge_index = torch.tensor(
            [[0, 1, 2, 3], [0, 0, 1, 1]]
        )

        # Convert to HyperData
        data = hetero_to_hyperedge_index(hetero)

        # Check properties
        assert data.num_nodes == 10
        assert data.num_hyperedges == 2
        assert data.x is not None
        assert data.y is not None
        assert data.hyperedge_index is not None
        assert torch.equal(data.x, hetero["node"].x)
        assert torch.equal(data.y, hetero["node"].y)
        assert torch.equal(
            data.hyperedge_index,
            hetero["node", "member_of", "hyperedge"].edge_index,
        )

    def test_round_trip_conversion(self) -> None:
        """Test round-trip conversion: HyperData -> HyperHeteroData -> HyperData."""
        # Create original data
        original = HyperData(
            x=torch.randn(10, 5),
            hyperedge_index=torch.tensor([[0, 1, 2, 3, 4], [0, 0, 1, 1, 2]]),
            y=torch.tensor([0, 1, 0, 1, 0, 1, 0, 1, 0, 1]),
            num_nodes=10,
            num_hyperedges=3,
        )

        # Round trip
        hetero = hyperedge_index_to_hetero(original)
        reconstructed = hetero_to_hyperedge_index(hetero)

        # Verify equality
        assert reconstructed.num_nodes == original.num_nodes
        assert reconstructed.num_hyperedges == original.num_hyperedges
        assert reconstructed.x is not None
        assert original.x is not None
        assert reconstructed.y is not None
        assert original.y is not None
        assert isinstance(reconstructed.y, torch.Tensor)
        assert isinstance(original.y, torch.Tensor)
        assert reconstructed.hyperedge_index is not None
        assert original.hyperedge_index is not None
        assert torch.equal(reconstructed.x, original.x)
        assert torch.equal(reconstructed.y, original.y)
        assert torch.equal(reconstructed.hyperedge_index, original.hyperedge_index)

    def test_conversion_with_multimodal_attrs(self) -> None:
        """Test conversion preserves multimodal attributes."""
        # Create data with additional attributes
        data = HyperData(
            x=torch.randn(10, 5),
            hyperedge_index=torch.tensor([[0, 1, 2], [0, 0, 1]]),
            y=torch.tensor([0, 1, 0, 1, 0, 1, 0, 1, 0, 1]),
            num_nodes=10,
            num_hyperedges=2,
        )
        data.node_degree = torch.tensor([1, 1, 1, 0, 0, 0, 0, 0, 0, 0])
        data.edge_size = torch.tensor([2, 1])
        data.custom_attr = torch.randn(10, 3)

        # Convert to hetero
        hetero = hyperedge_index_to_hetero(data)

        # Check multimodal attributes transferred to node type
        assert hasattr(data, "node_degree")
        assert hasattr(data, "edge_size")
        assert hasattr(data, "custom_attr")
        assert torch.equal(hetero["node"].node_degree, data.node_degree)
        assert torch.equal(hetero["node"].edge_size, data.edge_size)
        assert torch.equal(hetero["node"].custom_attr, data.custom_attr)

        # Round trip back
        reconstructed = hetero_to_hyperedge_index(hetero)

        # Verify attributes preserved
        assert hasattr(reconstructed, "node_degree")
        assert hasattr(reconstructed, "edge_size")
        assert hasattr(reconstructed, "custom_attr")
        assert torch.equal(reconstructed.node_degree, data.node_degree)
        assert torch.equal(reconstructed.edge_size, data.edge_size)
        assert torch.equal(reconstructed.custom_attr, data.custom_attr)

    def test_conversion_with_hyperedge_attr(self) -> None:
        """Test conversion with hyperedge attributes."""
        # Create data with hyperedge attributes
        data = HyperData(
            x=torch.randn(10, 5),
            hyperedge_index=torch.tensor([[0, 1, 2], [0, 0, 1]]),
            hyperedge_attr=torch.randn(2, 3),
            num_nodes=10,
            num_hyperedges=2,
        )

        # Convert to hetero
        hetero = hyperedge_index_to_hetero(data)

        # Check hyperedge attributes become hyperedge node features
        assert hasattr(data, "hyperedge_attr")
        assert data.hyperedge_attr is not None
        assert torch.equal(hetero["hyperedge"].x, data.hyperedge_attr)

        # Round trip
        reconstructed = hetero_to_hyperedge_index(hetero)

        # Verify hyperedge attributes preserved
        assert hasattr(reconstructed, "hyperedge_attr")
        assert reconstructed.hyperedge_attr is not None
        assert torch.equal(reconstructed.hyperedge_attr, data.hyperedge_attr)

    @pytest.mark.skip(reason="Requires network access to download dataset")
    def test_conversion_with_real_dataset(self) -> None:
        """Test conversion with real dataset."""
        dataset = CoraCocitation()
        data = dataset[0]

        # Convert to hetero
        hetero = data.to_hetero()

        # Check structure
        assert "node" in hetero.node_types
        assert "hyperedge" in hetero.node_types
        assert hetero["node"].num_nodes == data.num_nodes
        assert hetero["hyperedge"].num_nodes == data.num_hyperedges

        # Convert back
        reconstructed = hetero.to_hyperedge_index()

        # Verify
        assert reconstructed.num_nodes == data.num_nodes
        assert reconstructed.num_hyperedges == data.num_hyperedges
        assert reconstructed.hyperedge_index is not None
        assert data.hyperedge_index is not None
        assert reconstructed.x is not None
        assert data.x is not None
        assert reconstructed.y is not None
        assert data.y is not None
        assert torch.equal(reconstructed.hyperedge_index, data.hyperedge_index)
        assert torch.equal(reconstructed.x, data.x)
        assert torch.equal(reconstructed.y, data.y)

    def test_validate_conversion(self) -> None:
        """Test conversion validation."""
        # Create valid data
        data = HyperData(
            x=torch.randn(10, 5),
            hyperedge_index=torch.tensor([[0, 1, 2], [0, 0, 1]]),
            num_nodes=10,
            num_hyperedges=2,
        )

        hetero = hyperedge_index_to_hetero(data)
        reconstructed = hetero_to_hyperedge_index(hetero)

        # Validate conversion
        assert validate_conversion(data, reconstructed)

    def test_method_api(self) -> None:
        """Test that conversion methods work through object API."""
        data = HyperData(
            x=torch.randn(5, 3),
            hyperedge_index=torch.tensor([[0, 1, 2], [0, 0, 1]]),
            num_nodes=5,
            num_hyperedges=2,
        )

        # Test to_hetero() method
        hetero = data.to_hetero()
        assert isinstance(hetero, HyperHeteroData)

        # Test to_hyperedge_index() method
        reconstructed = hetero.to_hyperedge_index()
        assert isinstance(reconstructed, HyperData)

        # Verify equivalence
        assert data.hyperedge_index is not None
        assert reconstructed.hyperedge_index is not None
        assert torch.equal(data.hyperedge_index, reconstructed.hyperedge_index)
