"""Tests for data structures."""
