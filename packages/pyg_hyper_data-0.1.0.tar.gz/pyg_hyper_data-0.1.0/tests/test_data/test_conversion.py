"""Tests for conversion between HyperData and HyperHeteroData."""

import pytest
import torch

from pyg_hyper_data.data import (
    HyperData,
    HyperHeteroData,
    hetero_to_hyperedge_index,
    hyperedge_index_to_hetero,
    validate_conversion,
)


def create_sample_hyper_data() -> HyperData:
    """Create a sample HyperData object for testing."""
    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor(
        [
            [0, 1, 2, 3, 4, 5, 6, 7],  # node indices
            [0, 0, 0, 1, 1, 1, 2, 2],  # hyperedge indices
        ]
    )
    hyperedge_attr = torch.randn(3, 8)
    y = torch.randint(0, 3, (10,))

    return HyperData(
        x=x, hyperedge_index=hyperedge_index, hyperedge_attr=hyperedge_attr, y=y
    )


def create_sample_hetero_data() -> HyperHeteroData:
    """Create a sample HyperHeteroData object for testing."""
    data = HyperHeteroData()

    data["node"].x = torch.randn(10, 16)
    data["node"].y = torch.randint(0, 3, (10,))

    data["hyperedge"].x = torch.randn(3, 8)

    edge_index = torch.tensor(
        [
            [0, 1, 2, 3, 4, 5, 6, 7],  # node indices
            [0, 0, 0, 1, 1, 1, 2, 2],  # hyperedge indices
        ]
    )
    data["node", "member_of", "hyperedge"].edge_index = edge_index
    data["hyperedge", "has_member", "node"].edge_index = edge_index[[1, 0]]

    return data


def test_hyperedge_index_to_hetero():
    """Test conversion from HyperData to HyperHeteroData."""
    hyper_data = create_sample_hyper_data()
    hetero_data = hyperedge_index_to_hetero(hyper_data)

    # Check node type
    assert hetero_data["node"].num_nodes == 10
    assert torch.equal(hetero_data["node"].x, hyper_data.x)
    assert torch.equal(hetero_data["node"].y, hyper_data.y)

    # Check hyperedge type
    assert hetero_data["hyperedge"].num_nodes == 3
    assert torch.equal(hetero_data["hyperedge"].x, hyper_data.hyperedge_attr)

    # Check edges
    assert torch.equal(
        hetero_data["node", "member_of", "hyperedge"].edge_index,
        hyper_data.hyperedge_index,
    )
    assert torch.equal(
        hetero_data["hyperedge", "has_member", "node"].edge_index,
        hyper_data.hyperedge_index[[1, 0]],
    )


def test_hetero_to_hyperedge_index():
    """Test conversion from HyperHeteroData to HyperData."""
    hetero_data = create_sample_hetero_data()
    hyper_data = hetero_to_hyperedge_index(hetero_data)

    # Check attributes
    assert hyper_data.num_nodes == 10
    assert hyper_data.num_hyperedges == 3
    assert torch.equal(hyper_data.x, hetero_data["node"].x)
    assert torch.equal(hyper_data.y, hetero_data["node"].y)
    assert torch.equal(hyper_data.hyperedge_attr, hetero_data["hyperedge"].x)

    # Check hyperedge_index
    assert torch.equal(
        hyper_data.hyperedge_index,
        hetero_data["node", "member_of", "hyperedge"].edge_index,
    )


def test_round_trip_hyper_to_hetero_to_hyper():
    """Test round-trip conversion: HyperData -> HyperHeteroData -> HyperData."""
    original = create_sample_hyper_data()

    # Convert to HeteroData
    hetero = hyperedge_index_to_hetero(original)

    # Convert back to HyperData
    reconstructed = hetero_to_hyperedge_index(hetero)

    # Validate
    assert validate_conversion(original, reconstructed)

    # Check all attributes are preserved
    assert torch.equal(original.x, reconstructed.x)
    assert torch.equal(original.y, reconstructed.y)
    assert torch.equal(original.hyperedge_attr, reconstructed.hyperedge_attr)

    # Note: hyperedge_index order might differ, so we use sorted comparison
    def sort_hyperedge_index(idx: torch.Tensor) -> torch.Tensor:
        sorted_indices = torch.argsort(idx[1] * 100000 + idx[0])
        return idx[:, sorted_indices]

    assert torch.equal(
        sort_hyperedge_index(original.hyperedge_index),
        sort_hyperedge_index(reconstructed.hyperedge_index),
    )


def test_round_trip_hetero_to_hyper_to_hetero():
    """Test round-trip conversion: HyperHeteroData -> HyperData -> HyperHeteroData."""
    original = create_sample_hetero_data()

    # Convert to HyperData
    hyper = hetero_to_hyperedge_index(original)

    # Convert back to HeteroData
    reconstructed = hyperedge_index_to_hetero(hyper)

    # Check attributes
    assert torch.equal(original["node"].x, reconstructed["node"].x)
    assert torch.equal(original["node"].y, reconstructed["node"].y)
    assert torch.equal(original["hyperedge"].x, reconstructed["hyperedge"].x)

    # Check edges
    assert torch.equal(
        original["node", "member_of", "hyperedge"].edge_index,
        reconstructed["node", "member_of", "hyperedge"].edge_index,
    )


def test_conversion_with_multimodal_attributes():
    """Test conversion preserves multimodal attributes."""
    # Create HyperData with multimodal attributes
    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    y = torch.randint(0, 3, (10,))
    title = torch.randn(10, 384)
    abstract = torch.randn(10, 768)

    hyper_data = HyperData(
        x=x, hyperedge_index=hyperedge_index, y=y, title=title, abstract=abstract
    )

    # Convert to HeteroData
    hetero_data = hyperedge_index_to_hetero(hyper_data)

    # Check multimodal attributes are preserved
    assert "title" in hetero_data["node"]
    assert "abstract" in hetero_data["node"]
    assert torch.equal(hetero_data["node"].title, title)
    assert torch.equal(hetero_data["node"].abstract, abstract)

    # Convert back to HyperData
    reconstructed = hetero_to_hyperedge_index(hetero_data)

    # Check multimodal attributes are still there
    assert "title" in reconstructed.keys()  # noqa: SIM118
    assert "abstract" in reconstructed.keys()  # noqa: SIM118
    assert torch.equal(reconstructed.title, title)
    assert torch.equal(reconstructed.abstract, abstract)

    # Validate conversion
    assert validate_conversion(hyper_data, reconstructed, check_multimodal=True)


def test_conversion_methods_on_objects():
    """Test to_hetero() and to_hyperedge_index() methods."""
    # Test HyperData.to_hetero()
    hyper_data = create_sample_hyper_data()
    hetero_data = hyper_data.to_hetero()

    assert isinstance(hetero_data, HyperHeteroData)
    assert hetero_data.num_hyperedges == hyper_data.num_hyperedges

    # Test HyperHeteroData.to_hyperedge_index()
    hetero_data = create_sample_hetero_data()
    hyper_data = hetero_data.to_hyperedge_index()

    assert isinstance(hyper_data, HyperData)
    assert hyper_data.num_hyperedges == hetero_data.num_hyperedges


def test_validate_conversion_function():
    """Test validate_conversion function."""
    # Valid conversion
    original = create_sample_hyper_data()
    hetero = original.to_hetero()
    reconstructed = hetero.to_hyperedge_index()

    assert validate_conversion(original, reconstructed)

    # Invalid conversion (different data)
    different = create_sample_hyper_data()
    assert not validate_conversion(original, different)


def test_conversion_with_empty_hyperedge_attr():
    """Test conversion when hyperedge_attr is None."""
    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    y = torch.randint(0, 3, (10,))

    hyper_data = HyperData(
        x=x, hyperedge_index=hyperedge_index, y=y
    )  # No hyperedge_attr

    # Convert to HeteroData
    hetero_data = hyperedge_index_to_hetero(hyper_data)

    # Convert back
    reconstructed = hetero_to_hyperedge_index(hetero_data)

    # Should still work
    assert validate_conversion(hyper_data, reconstructed)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
