"""Tests for HyperData class."""

import pytest
import torch
from torch_geometric.loader import DataLoader

from pyg_hyper_data.data import HyperData


def test_hyper_data_initialization():
    """Test basic HyperData initialization."""
    x = torch.randn(10, 16)  # 10 nodes, 16 features
    hyperedge_index = torch.tensor(
        [
            [0, 1, 2, 3, 4, 5],  # node indices
            [0, 0, 0, 1, 1, 1],  # hyperedge indices
        ]
    )
    y = torch.randint(0, 3, (10,))  # 10 nodes, 3 classes

    data = HyperData(x=x, hyperedge_index=hyperedge_index, y=y)

    assert data.num_nodes == 10
    assert data.num_hyperedges == 2
    assert data.x.shape == (10, 16)
    assert data.y.shape == (10,)
    assert data.hyperedge_index.shape == (2, 6)


def test_hyper_data_num_hyperedges():
    """Test num_hyperedges property."""
    # Hyperedge indices: 0, 0, 0, 1, 1, 2
    # Max index: 2 -> num_hyperedges = 3
    hyperedge_index = torch.tensor(
        [
            [0, 1, 2, 3, 4, 5],  # node indices
            [0, 0, 0, 1, 1, 2],  # hyperedge indices
        ]
    )

    data = HyperData(hyperedge_index=hyperedge_index)
    assert data.num_hyperedges == 3


def test_hyper_data_hyperedge_sizes():
    """Test hyperedge_sizes method."""
    # Hyperedge 0: 3 nodes
    # Hyperedge 1: 2 nodes
    # Hyperedge 2: 1 node
    hyperedge_index = torch.tensor(
        [
            [0, 1, 2, 3, 4, 5],  # node indices
            [0, 0, 0, 1, 1, 2],  # hyperedge indices
        ]
    )

    data = HyperData(hyperedge_index=hyperedge_index)
    sizes = data.hyperedge_sizes()

    assert sizes.shape == (3,)
    assert sizes[0] == 3
    assert sizes[1] == 2
    assert sizes[2] == 1


def test_hyper_data_node_degrees():
    """Test node_degrees method."""
    # Node 0: in hyperedge 0
    # Node 1: in hyperedges 0, 1
    # Node 2: in hyperedges 0, 1
    # Node 3: in hyperedge 1
    hyperedge_index = torch.tensor(
        [
            [0, 1, 2, 1, 2, 3],  # node indices
            [0, 0, 0, 1, 1, 1],  # hyperedge indices
        ]
    )

    data = HyperData(x=torch.randn(4, 8), hyperedge_index=hyperedge_index)
    degrees = data.node_degrees()

    assert degrees.shape == (4,)
    assert degrees[0] == 1  # node 0 in 1 hyperedge
    assert degrees[1] == 2  # node 1 in 2 hyperedges
    assert degrees[2] == 2  # node 2 in 2 hyperedges
    assert degrees[3] == 1  # node 3 in 1 hyperedge


def test_hyper_data_with_multimodal_attributes():
    """Test HyperData with multimodal attributes."""
    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor(
        [
            [0, 1, 2],  # node indices
            [0, 0, 0],  # hyperedge indices
        ]
    )
    y = torch.randint(0, 3, (10,))

    # Add multimodal attributes
    title = torch.randn(10, 384)
    abstract = torch.randn(10, 768)

    data = HyperData(
        x=x, hyperedge_index=hyperedge_index, y=y, title=title, abstract=abstract
    )

    assert data.x.shape == (10, 16)
    assert data.title.shape == (10, 384)
    assert data.abstract.shape == (10, 768)
    assert "title" in data.keys()  # noqa: SIM118
    assert "abstract" in data.keys()  # noqa: SIM118


def test_hyper_data_batching():
    """Test batching of HyperData objects."""
    # Create 3 HyperData objects
    data_list = []
    for _ in range(3):
        x = torch.randn(5, 8)
        hyperedge_index = torch.tensor(
            [
                [0, 1, 2, 3, 4],  # node indices
                [0, 0, 1, 1, 1],  # hyperedge indices
            ]
        )
        y = torch.randint(0, 2, (5,))
        data_list.append(HyperData(x=x, hyperedge_index=hyperedge_index, y=y))

    # Create DataLoader
    loader = DataLoader(data_list, batch_size=2)

    for batch in loader:
        # Check that indices are correctly incremented
        assert batch.hyperedge_index[0].max() < batch.num_nodes
        assert batch.hyperedge_index[1].max() < batch.num_hyperedges


def test_hyper_data_validation():
    """Test HyperData validation."""
    # Valid data
    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor(
        [
            [0, 1, 2, 3, 4],  # node indices
            [0, 0, 0, 1, 1],  # hyperedge indices
        ]
    )

    data = HyperData(x=x, hyperedge_index=hyperedge_index)
    assert data.validate()

    # Invalid: hyperedge_index is 1D
    data_invalid = HyperData(hyperedge_index=torch.tensor([0, 1, 2]))
    with pytest.raises(ValueError, match="must be 2D"):
        data_invalid.validate()

    # Invalid: hyperedge_index has wrong first dimension
    data_invalid = HyperData(
        hyperedge_index=torch.tensor([[0, 1, 2], [3, 4, 5], [6, 7, 8]])
    )
    with pytest.raises(ValueError, match="must have shape"):
        data_invalid.validate()

    # Invalid: node index exceeds num_nodes
    data_invalid = HyperData(
        x=torch.randn(5, 8),
        hyperedge_index=torch.tensor([[0, 1, 10], [0, 0, 0]]),  # 10 > num_nodes
    )
    with pytest.raises(ValueError, match="exceeds num_nodes"):
        data_invalid.validate()


def test_hyper_data_repr():
    """Test HyperData __repr__ method."""
    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    y = torch.randint(0, 3, (10,))
    title = torch.randn(10, 384)

    data = HyperData(x=x, hyperedge_index=hyperedge_index, y=y, title=title)
    repr_str = repr(data)

    assert "num_nodes=10" in repr_str
    assert "num_hyperedges=1" in repr_str
    assert "num_node_features=16" in repr_str
    assert "num_classes=3" in repr_str
    assert "multimodal_attrs" in repr_str
    assert "title" in repr_str


def test_hyper_data_empty():
    """Test HyperData with minimal initialization."""
    data = HyperData()

    assert data.num_hyperedges == 0
    assert data.hyperedge_sizes().shape == (0,)
    assert data.node_degrees().shape == (0,)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
