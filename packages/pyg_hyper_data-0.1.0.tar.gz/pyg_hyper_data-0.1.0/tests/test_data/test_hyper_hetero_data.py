"""Tests for HyperHeteroData class."""

import pytest
import torch

from pyg_hyper_data.data import HyperHeteroData


def test_hyper_hetero_data_initialization():
    """Test basic HyperHeteroData initialization."""
    data = HyperHeteroData()

    # Node data
    data["node"].x = torch.randn(10, 16)
    data["node"].y = torch.randint(0, 3, (10,))

    # Hyperedge data
    data["hyperedge"].x = torch.randn(2, 8)

    # Edges
    edge_index = torch.tensor([[0, 1, 2, 3, 4], [0, 0, 0, 1, 1]])
    data["node", "member_of", "hyperedge"].edge_index = edge_index
    data["hyperedge", "has_member", "node"].edge_index = edge_index[[1, 0]]

    assert data["node"].num_nodes == 10
    assert data["hyperedge"].num_nodes == 2
    assert data.num_hyperedges == 2


def test_hyper_hetero_data_num_hyperedges():
    """Test num_hyperedges property."""
    data = HyperHeteroData()
    data["node"].x = torch.randn(5, 8)
    data["hyperedge"].x = torch.randn(3, 4)

    assert data.num_hyperedges == 3


def test_hyper_hetero_data_multimodal_attributes():
    """Test get_multimodal_attributes method."""
    data = HyperHeteroData()

    # Standard attributes
    data["node"].x = torch.randn(10, 16)
    data["node"].y = torch.randint(0, 3, (10,))

    # Multimodal attributes
    data["node"].title = torch.randn(10, 384)
    data["node"].abstract = torch.randn(10, 768)
    data["node"].image = torch.randn(10, 2048)

    multimodal = data.get_multimodal_attributes()

    assert "title" in multimodal
    assert "abstract" in multimodal
    assert "image" in multimodal
    assert "x" not in multimodal
    assert "y" not in multimodal


def test_hyper_hetero_data_get_data_with_attributes():
    """Test get_data_with_attributes method."""
    data = HyperHeteroData()

    # Setup data
    data["node"].x = torch.randn(10, 16)
    data["node"].y = torch.randint(0, 3, (10,))
    data["node"].title = torch.randn(10, 384)
    data["node"].abstract = torch.randn(10, 768)
    data["node"].image = torch.randn(10, 2048)

    data["hyperedge"].x = torch.randn(2, 8)

    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    data["node", "member_of", "hyperedge"].edge_index = edge_index
    data["hyperedge", "has_member", "node"].edge_index = edge_index[[1, 0]]

    # Filter to only title and abstract
    filtered = data.get_data_with_attributes(["title", "abstract"])

    assert "x" in filtered["node"]
    assert "y" in filtered["node"]
    assert "title" in filtered["node"]
    assert "abstract" in filtered["node"]
    assert "image" not in filtered["node"]


def test_hyper_hetero_data_validation():
    """Test HyperHeteroData validation."""
    data = HyperHeteroData()

    # Valid data
    data["node"].x = torch.randn(10, 16)
    data["hyperedge"].x = torch.randn(2, 8)

    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    data["node", "member_of", "hyperedge"].edge_index = edge_index
    data["hyperedge", "has_member", "node"].edge_index = edge_index[[1, 0]]

    assert data.validate()

    # Invalid: missing 'node' node type
    data_invalid = HyperHeteroData()
    data_invalid["hyperedge"].x = torch.randn(2, 8)
    with pytest.raises(ValueError, match="Missing 'node'"):
        data_invalid.validate()

    # Invalid: missing edge type
    data_invalid = HyperHeteroData()
    data_invalid["node"].x = torch.randn(10, 16)
    data_invalid["hyperedge"].x = torch.randn(2, 8)
    with pytest.raises(ValueError, match="Missing edge type"):
        data_invalid.validate()

    # Invalid: inconsistent edge indices
    data_invalid = HyperHeteroData()
    data_invalid["node"].x = torch.randn(10, 16)
    data_invalid["hyperedge"].x = torch.randn(2, 8)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    data_invalid["node", "member_of", "hyperedge"].edge_index = edge_index
    data_invalid["hyperedge", "has_member", "node"].edge_index = torch.tensor(
        [[0, 0, 1], [0, 1, 2]]  # Different from reverse
    )
    with pytest.raises(ValueError, match="not consistent"):
        data_invalid.validate()


def test_hyper_hetero_data_repr():
    """Test HyperHeteroData __repr__ method."""
    data = HyperHeteroData()

    data["node"].x = torch.randn(10, 16)
    data["node"].y = torch.randint(0, 3, (10,))
    data["node"].title = torch.randn(10, 384)

    data["hyperedge"].x = torch.randn(2, 8)

    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    data["node", "member_of", "hyperedge"].edge_index = edge_index
    data["hyperedge", "has_member", "node"].edge_index = edge_index[[1, 0]]

    repr_str = repr(data)

    assert "num_nodes=10" in repr_str
    assert "num_hyperedges=2" in repr_str
    assert "num_node_features=16" in repr_str
    assert "num_edge_features=8" in repr_str
    assert "num_classes=3" in repr_str
    assert "multimodal_attrs" in repr_str
    assert "title" in repr_str


def test_hyper_hetero_data_empty():
    """Test HyperHeteroData with minimal initialization."""
    data = HyperHeteroData()

    assert data.num_hyperedges == 0
    assert data.get_multimodal_attributes() == []


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
