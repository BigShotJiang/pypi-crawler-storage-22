"""Tests for additional TriCL datasets (shape, UCI, text)."""

import pytest
import torch

from pyg_hyper_data.datasets import NTU2012, ModelNet40, Mushroom, News20, Zoo


class TestNTU2012:
    """Tests for NTU2012 3D shape dataset."""

    def test_initialization(self) -> None:
        """Test dataset initialization."""
        dataset = NTU2012()
        assert len(dataset) == 1
        assert dataset.name == "ntu2012"
        assert dataset.dataset_name == "NTU2012"

    def test_data_properties(self) -> None:
        """Test data properties match expected values."""
        dataset = NTU2012()
        data = dataset[0]

        # Verify statistics
        assert data.num_nodes == 2012, "NTU2012 should have 2,012 nodes"
        assert data.num_hyperedges == 2012, "NTU2012 should have 2,012 hyperedges"

        # Verify features and labels
        assert data.x.shape[0] == 2012
        assert data.x.shape[1] == 100, "NTU2012 should have 100 features"
        assert data.y.shape[0] == 2012
        assert data.y.max() == 66, "NTU2012 should have 67 classes (0-66)"
        assert data.y.min() >= 0

    def test_hyperedge_index(self) -> None:
        """Test hyperedge_index tensor properties."""
        dataset = NTU2012()
        data = dataset[0]

        assert data.hyperedge_index.shape[0] == 2
        assert data.hyperedge_index.dtype == torch.long
        assert data.hyperedge_index[0].min() >= 0
        assert data.hyperedge_index[0].max() < data.num_nodes
        assert data.hyperedge_index[1].min() >= 0
        assert data.hyperedge_index[1].max() < data.num_hyperedges

    def test_splits(self) -> None:
        """Test train/val/test splits."""
        dataset = NTU2012()
        splits = dataset.get_split(seed=0)

        assert "train_mask" in splits
        assert "val_mask" in splits
        assert "test_mask" in splits

        for mask in splits.values():
            assert mask.shape[0] == dataset.data.num_nodes
            assert mask.dtype == torch.bool


class TestModelNet40:
    """Tests for ModelNet40 3D shape dataset."""

    def test_initialization(self) -> None:
        """Test dataset initialization."""
        dataset = ModelNet40()
        assert len(dataset) == 1
        assert dataset.name == "modelnet40"
        assert dataset.dataset_name == "ModelNet40"

    def test_data_properties(self) -> None:
        """Test data properties match expected values."""
        dataset = ModelNet40()
        data = dataset[0]

        # Verify statistics
        assert data.num_nodes == 12311, "ModelNet40 should have 12,311 nodes"
        assert data.num_hyperedges == 12311, "ModelNet40 should have 12,311 hyperedges"

        # Verify features and labels
        assert data.x.shape[0] == 12311
        assert data.x.shape[1] == 100, "ModelNet40 should have 100 features"
        assert data.y.shape[0] == 12311
        assert data.y.max() == 39, "ModelNet40 should have 40 classes (0-39)"
        assert data.y.min() >= 0

    def test_splits(self) -> None:
        """Test train/val/test splits."""
        dataset = ModelNet40()
        splits = dataset.get_split(seed=0)

        assert len(splits) == 3
        for mask in splits.values():
            assert mask.shape[0] == dataset.data.num_nodes


class TestMushroom:
    """Tests for Mushroom UCI dataset."""

    def test_initialization(self) -> None:
        """Test dataset initialization."""
        dataset = Mushroom()
        assert len(dataset) == 1
        assert dataset.name == "mushroom"
        assert dataset.dataset_name == "Mushroom"

    def test_data_properties(self) -> None:
        """Test data properties match expected values."""
        dataset = Mushroom()
        data = dataset[0]

        # Verify statistics
        assert data.num_nodes == 8124, "Mushroom should have 8,124 nodes"
        assert data.num_hyperedges == 298, "Mushroom should have 298 hyperedges"

        # Verify features and labels
        assert data.x.shape[0] == 8124
        assert data.x.shape[1] == 22, "Mushroom should have 22 features"
        assert data.y.shape[0] == 8124
        assert data.y.max() == 1, "Mushroom should have 2 classes (0-1)"
        assert data.y.min() >= 0

    def test_splits(self) -> None:
        """Test train/val/test splits."""
        dataset = Mushroom()
        splits = dataset.get_split(seed=0)

        assert len(splits) == 3
        for mask in splits.values():
            assert mask.shape[0] == dataset.data.num_nodes


class TestZoo:
    """Tests for Zoo UCI dataset."""

    def test_initialization(self) -> None:
        """Test dataset initialization."""
        dataset = Zoo()
        assert len(dataset) == 1
        assert dataset.name == "zoo"
        assert dataset.dataset_name == "zoo"

    def test_data_properties(self) -> None:
        """Test data properties match expected values."""
        dataset = Zoo()
        data = dataset[0]

        # Verify statistics
        assert data.num_nodes == 101, "Zoo should have 101 nodes"
        assert data.num_hyperedges == 43, "Zoo should have 43 hyperedges"

        # Verify features and labels
        assert data.x.shape[0] == 101
        assert data.x.shape[1] == 16, "Zoo should have 16 features"
        assert data.y.shape[0] == 101
        assert data.y.max() == 6, "Zoo should have 7 classes (0-6)"
        assert data.y.min() >= 0

    def test_splits(self) -> None:
        """Test train/val/test splits."""
        dataset = Zoo()
        splits = dataset.get_split(seed=0)

        assert len(splits) == 3
        for mask in splits.values():
            assert mask.shape[0] == dataset.data.num_nodes


class TestNews20:
    """Tests for 20 Newsgroups text dataset."""

    def test_initialization(self) -> None:
        """Test dataset initialization."""
        dataset = News20()
        assert len(dataset) == 1
        assert dataset.name == "news20"
        assert dataset.dataset_name == "20newsW100"

    def test_data_properties(self) -> None:
        """Test data properties match expected values."""
        dataset = News20()
        data = dataset[0]

        # Verify statistics
        assert data.num_nodes == 16242, "News20 should have 16,242 nodes"
        assert data.num_hyperedges == 100, "News20 should have 100 hyperedges"

        # Verify features and labels
        assert data.x.shape[0] == 16242
        assert data.x.shape[1] == 100, "News20 should have 100 features"
        assert data.y.shape[0] == 16242
        assert data.y.max() == 3, "News20 should have 4 classes (0-3)"
        assert data.y.min() >= 0

    def test_splits(self) -> None:
        """Test train/val/test splits."""
        dataset = News20()
        splits = dataset.get_split(seed=0)

        assert len(splits) == 3
        for mask in splits.values():
            assert mask.shape[0] == dataset.data.num_nodes


@pytest.mark.parametrize(
    "dataset_class",
    [NTU2012, ModelNet40, Mushroom, Zoo, News20],
)
def test_dataset_reproducibility(dataset_class):
    """Test dataset loading is reproducible."""
    dataset1 = dataset_class()
    dataset2 = dataset_class()

    data1 = dataset1[0]
    data2 = dataset2[0]

    # Check tensors are identical
    assert torch.equal(data1.x, data2.x)
    assert torch.equal(data1.y, data2.y)
    assert torch.equal(data1.hyperedge_index, data2.hyperedge_index)
    assert torch.equal(data1.node_degree, data2.node_degree)
    assert torch.equal(data1.edge_size, data2.edge_size)


@pytest.mark.parametrize(
    ("dataset_class", "expected_nodes", "expected_edges"),
    [
        (NTU2012, 2012, 2012),
        (ModelNet40, 12311, 12311),
        (Mushroom, 8124, 298),
        (Zoo, 101, 43),
        (News20, 16242, 100),
    ],
)
def test_dataset_statistics(dataset_class, expected_nodes, expected_edges):
    """Test dataset statistics match expected values."""
    dataset = dataset_class()
    data = dataset[0]

    assert data.num_nodes == expected_nodes
    assert data.num_hyperedges == expected_edges

    # Test statistics computation
    stats = dataset.statistics()
    assert "num_nodes" in stats
    assert "num_hyperedges" in stats
    assert stats["num_nodes"] == expected_nodes
    assert stats["num_hyperedges"] == expected_edges
