"""Tests for co-citation datasets."""

import pytest
import torch

from pyg_hyper_data.datasets.cocitation import (
    CiteseerCocitation,
    CoraCocitation,
    PubmedCocitation,
)


class TestCoraCocitation:
    """Tests for Cora co-citation dataset."""

    def test_initialization(self) -> None:
        """Test dataset initialization."""
        dataset = CoraCocitation()
        assert len(dataset) == 1
        assert dataset.name == "cocitation-cora"
        assert dataset.dataset_name == "cora"
        assert dataset.dataset_type == "cocitation"

    def test_data_properties(self) -> None:
        """Test data properties match research standards."""
        dataset = CoraCocitation()
        data = dataset[0]

        # Verify statistics match research benchmarks
        assert data.num_nodes == 1434, "Cora co-citation should have 1,434 nodes"
        assert data.num_hyperedges == 1579, (
            "Cora co-citation should have 1,579 hyperedges"
        )

        # Verify features and labels
        assert data.x.shape[0] == 1434
        assert data.x.shape[1] == 1433, "Cora should have 1,433 features"
        assert data.y.shape[0] == 1434
        assert data.y.max() == 6, "Cora should have 7 classes (0-6)"
        assert data.y.min() >= 0

    def test_hyperedge_index(self) -> None:
        """Test hyperedge_index tensor properties."""
        dataset = CoraCocitation()
        data = dataset[0]

        # Check shape and type
        assert data.hyperedge_index.shape[0] == 2
        assert data.hyperedge_index.dtype == torch.long

        # Check valid node and edge indices
        assert data.hyperedge_index[0].min() >= 0
        assert data.hyperedge_index[0].max() < data.num_nodes
        assert data.hyperedge_index[1].min() >= 0
        assert data.hyperedge_index[1].max() < data.num_hyperedges

    def test_degrees(self) -> None:
        """Test node degrees and edge sizes."""
        dataset = CoraCocitation()
        data = dataset[0]

        # Check node degrees exist and are valid
        assert hasattr(data, "node_degree")
        assert data.node_degree.shape[0] == data.num_nodes
        assert data.node_degree.min() > 0, (
            "All nodes should have at least one connection"
        )

        # Check edge sizes exist and are valid
        assert hasattr(data, "edge_size")
        assert data.edge_size.shape[0] == data.num_hyperedges
        assert data.edge_size.min() >= 2, "Hyperedges should have at least 2 nodes"

    def test_splits(self) -> None:
        """Test train/val/test splits."""
        dataset = CoraCocitation()

        # Test DHG-Bench split (seed=1, DHG-Bench uses seeds 1-10)
        splits = dataset.get_split(seed=1)
        assert "train_mask" in splits
        assert "val_mask" in splits
        assert "test_mask" in splits

        # Check mask shapes
        for mask in splits.values():
            assert mask.shape[0] == dataset.data.num_nodes
            assert mask.dtype == torch.bool

        # Check masks are mutually exclusive
        train_mask = splits["train_mask"]
        val_mask = splits["val_mask"]
        test_mask = splits["test_mask"]

        assert not torch.any(train_mask & val_mask), "Train and val should not overlap"
        assert not torch.any(train_mask & test_mask), (
            "Train and test should not overlap"
        )
        assert not torch.any(val_mask & test_mask), "Val and test should not overlap"

        # Check all nodes are covered
        all_mask = train_mask | val_mask | test_mask
        assert torch.all(all_mask), "All nodes should be in some split"

    def test_statistics(self) -> None:
        """Test statistics computation."""
        dataset = CoraCocitation()
        stats = dataset.statistics()

        # Check statistics keys
        assert "num_nodes" in stats
        assert "num_hyperedges" in stats
        assert "num_connections" in stats
        assert "avg_node_degree" in stats
        assert "avg_hyperedge_size" in stats

        # Check statistics values
        assert stats["num_nodes"] == 1434
        assert stats["num_hyperedges"] == 1579


class TestCiteseerCocitation:
    """Tests for Citeseer co-citation dataset."""

    def test_initialization(self) -> None:
        """Test dataset initialization."""
        dataset = CiteseerCocitation()
        assert len(dataset) == 1
        assert dataset.name == "cocitation-citeseer"
        assert dataset.dataset_name == "citeseer"
        assert dataset.dataset_type == "cocitation"

    def test_data_properties(self) -> None:
        """Test data properties match research standards."""
        dataset = CiteseerCocitation()
        data = dataset[0]

        # Verify statistics match research benchmarks
        assert data.num_nodes == 1458, "Citeseer co-citation should have 1,458 nodes"
        assert data.num_hyperedges == 1079, (
            "Citeseer co-citation should have 1,079 hyperedges"
        )

        # Verify features and labels
        assert data.x.shape[0] == 1458
        assert data.x.shape[1] == 3703, "Citeseer should have 3,703 features"
        assert data.y.shape[0] == 1458
        assert data.y.max() == 5, "Citeseer should have 6 classes (0-5)"
        assert data.y.min() >= 0

    def test_splits(self) -> None:
        """Test train/val/test splits."""
        dataset = CiteseerCocitation()
        splits = dataset.get_split(seed=1)  # DHG-Bench uses seeds 1-10

        # Check basic properties
        assert len(splits) == 3
        for mask in splits.values():
            assert mask.shape[0] == dataset.data.num_nodes


class TestPubmedCocitation:
    """Tests for Pubmed co-citation dataset."""

    def test_initialization(self) -> None:
        """Test dataset initialization."""
        dataset = PubmedCocitation()
        assert len(dataset) == 1
        assert dataset.name == "cocitation-pubmed"
        assert dataset.dataset_name == "pubmed"
        assert dataset.dataset_type == "cocitation"

    def test_data_properties(self) -> None:
        """Test data properties match research standards."""
        dataset = PubmedCocitation()
        data = dataset[0]

        # Verify statistics match research benchmarks
        assert data.num_nodes == 3840, "Pubmed co-citation should have 3,840 nodes"
        assert data.num_hyperedges == 7963, (
            "Pubmed co-citation should have 7,963 hyperedges"
        )

        # Verify features and labels
        assert data.x.shape[0] == 3840
        assert data.x.shape[1] == 500, "Pubmed should have 500 features"
        assert data.y.shape[0] == 3840
        assert data.y.max() == 2, "Pubmed should have 3 classes (0-2)"
        assert data.y.min() >= 0

    def test_splits(self) -> None:
        """Test train/val/test splits."""
        dataset = PubmedCocitation()
        splits = dataset.get_split(seed=1)  # DHG-Bench uses seeds 1-10

        # Check basic properties
        assert len(splits) == 3
        for mask in splits.values():
            assert mask.shape[0] == dataset.data.num_nodes


@pytest.mark.parametrize(
    "dataset_class",
    [CoraCocitation, CiteseerCocitation, PubmedCocitation],
)
def test_dataset_reproducibility(dataset_class) -> None:
    """Test dataset loading is reproducible."""
    dataset1 = dataset_class()
    dataset2 = dataset_class()

    data1 = dataset1[0]
    data2 = dataset2[0]

    # Check tensors are identical
    assert torch.equal(data1.x, data2.x)
    assert torch.equal(data1.y, data2.y)
    assert torch.equal(data1.hyperedge_index, data2.hyperedge_index)
    assert torch.equal(data1.node_degree, data2.node_degree)
    assert torch.equal(data1.edge_size, data2.edge_size)


def test_citeseer_remove_isolated_nodes() -> None:
    """Test remove_isolated_nodes parameter for Citeseer dataset."""
    # Test with isolated nodes removed (default, TriCL-compatible)
    dataset_no_isolated = CiteseerCocitation(remove_isolated_nodes=True)
    data_no_isolated = dataset_no_isolated[0]

    assert data_no_isolated.num_nodes == 1458, (
        "With remove_isolated_nodes=True, should have 1,458 nodes (TriCL-compatible)"
    )
    assert data_no_isolated.num_hyperedges == 1079

    # Test with all nodes preserved (full DHG-Bench)
    dataset_with_isolated = CiteseerCocitation(remove_isolated_nodes=False)
    data_with_isolated = dataset_with_isolated[0]

    assert data_with_isolated.num_nodes == 3312, (
        "With remove_isolated_nodes=False, should have 3,312 nodes (full DHG-Bench)"
    )
    assert data_with_isolated.num_hyperedges == 1079, (
        "Hyperedge count should be the same regardless of isolated nodes"
    )

    # Check isolated nodes count
    isolated_count = data_with_isolated.num_nodes - data_no_isolated.num_nodes
    assert isolated_count == 1854, (
        f"Should have 1,854 isolated nodes (got {isolated_count})"
    )

    # Check that node_id_map exists and is correct
    assert dataset_no_isolated.node_id_map is not None
    assert len(dataset_no_isolated.node_id_map) == 1458, (
        "node_id_map should map all connected nodes"
    )

    assert dataset_with_isolated.node_id_map is not None
    assert len(dataset_with_isolated.node_id_map) == 3312, (
        "node_id_map should map all nodes when isolated nodes are kept"
    )


def test_cora_remove_isolated_nodes() -> None:
    """Test remove_isolated_nodes parameter for Cora dataset."""
    # Test with isolated nodes removed (default, TriCL-compatible)
    dataset_no_isolated = CoraCocitation(remove_isolated_nodes=True)
    data_no_isolated = dataset_no_isolated[0]

    assert data_no_isolated.num_nodes == 1434, (
        "With remove_isolated_nodes=True, should have 1,434 nodes (TriCL-compatible)"
    )
    assert data_no_isolated.num_hyperedges == 1579

    # Test with all nodes preserved (full DHG-Bench)
    dataset_with_isolated = CoraCocitation(remove_isolated_nodes=False)
    data_with_isolated = dataset_with_isolated[0]

    assert data_with_isolated.num_nodes == 2708, (
        "With remove_isolated_nodes=False, should have 2,708 nodes (full DHG-Bench)"
    )
    assert data_with_isolated.num_hyperedges == 1579, (
        "Hyperedge count should be the same regardless of isolated nodes"
    )

    # Check that node_id_map exists and is correct
    assert dataset_no_isolated.node_id_map is not None
    assert len(dataset_no_isolated.node_id_map) == 1434, (
        "node_id_map should map all connected nodes"
    )

    assert dataset_with_isolated.node_id_map is not None
    assert len(dataset_with_isolated.node_id_map) == 2708, (
        "node_id_map should map all nodes when isolated nodes are kept"
    )


def test_pubmed_remove_isolated_nodes() -> None:
    """Test remove_isolated_nodes parameter for Pubmed dataset."""
    # Test with isolated nodes removed (default)
    dataset_no_isolated = PubmedCocitation(remove_isolated_nodes=True)
    data_no_isolated = dataset_no_isolated[0]

    assert data_no_isolated.num_nodes == 3840, (
        "With remove_isolated_nodes=True, should have 3,840 connected nodes"
    )

    # Test with all nodes preserved
    dataset_with_isolated = PubmedCocitation(remove_isolated_nodes=False)
    data_with_isolated = dataset_with_isolated[0]

    # DHG-Bench Pubmed has 19,717 total nodes (matches Table A1 in paper)
    assert data_with_isolated.num_nodes == 19717, (
        "With remove_isolated_nodes=False, should have 19,717 nodes (matches DHG-Bench Table A1)"
    )
    assert data_with_isolated.num_hyperedges == 7963, (
        "Hyperedge count should be the same regardless of isolated nodes"
    )

    # Check isolated nodes count matches paper
    isolated_count = data_with_isolated.num_nodes - data_no_isolated.num_nodes
    assert isolated_count == 15877, (
        f"Should have 15,877 isolated nodes (got {isolated_count})"
    )

    # Check that node_id_map exists
    assert dataset_no_isolated.node_id_map is not None
    assert len(dataset_no_isolated.node_id_map) == 3840, (
        "node_id_map should map all connected nodes"
    )

    assert dataset_with_isolated.node_id_map is not None
    assert len(dataset_with_isolated.node_id_map) == 19717, (
        "node_id_map should map all nodes when isolated nodes are kept"
    )
