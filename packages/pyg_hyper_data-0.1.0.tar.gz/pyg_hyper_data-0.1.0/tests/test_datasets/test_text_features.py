"""Tests for HuggingFace TAG text features integration."""

from __future__ import annotations

import pytest

from pyg_hyper_data.datasets import CiteseerCocitation, CoraCocitation, PubmedCocitation

# Skip entire module - text features integration not yet implemented
pytestmark = pytest.mark.skip(
    reason="Text features integration not yet implemented (planned feature)"
)


class TestCoraTextFeatures:
    """Test text features for Cora dataset."""

    def test_load_text_features_eager(self) -> None:
        """Test eager loading of text features for Cora."""
        dataset = CoraCocitation(
            remove_isolated_nodes=False,
            load_text_features=True,
        )
        data = dataset[0]

        # Check basic properties
        assert data.num_nodes == 2708, "Cora should have 2708 nodes with TAG alignment"

        # Check text attributes exist (separate title and abstract)
        assert hasattr(data, "title"), "Should have title attribute"
        assert hasattr(data, "abstract"), "Should have abstract attribute"
        assert hasattr(data, "title_embeddings"), (
            "Should have title_embeddings attribute"
        )
        assert hasattr(data, "abstract_embeddings"), (
            "Should have abstract_embeddings attribute"
        )

        # Check text data properties
        assert len(data.title) == 2708, "Should have title for all 2708 nodes"
        assert len(data.abstract) == 2708, "Should have abstract for all 2708 nodes"
        assert data.title_embeddings.shape == (
            2708,
            768,
        ), "Should have 768-dim title embeddings (all-mpnet-base-v2)"
        assert data.abstract_embeddings.shape == (
            2708,
            768,
        ), "Should have 768-dim abstract embeddings (all-mpnet-base-v2)"

        # Check text content format
        sample_title = data.title[0]
        sample_abstract = data.abstract[0]
        assert isinstance(sample_title, str), "Title should be string"
        assert isinstance(sample_abstract, str), "Abstract should be string"
        assert len(sample_title) > 0, "Title should not be empty"

    def test_load_text_features_with_isolated_removed(self) -> None:
        """Test text features with isolated nodes removed."""
        dataset = CoraCocitation(
            remove_isolated_nodes=True,
            load_text_features=True,
        )
        data = dataset[0]

        # Check that isolated nodes were removed
        assert data.num_nodes == 1434, "Should have 1434 connected nodes"

        # Check text attributes exist
        assert hasattr(data, "title"), "Should have title attribute"
        assert hasattr(data, "abstract"), "Should have abstract attribute"
        assert hasattr(data, "title_embeddings"), (
            "Should have title_embeddings attribute"
        )
        assert hasattr(data, "abstract_embeddings"), (
            "Should have abstract_embeddings attribute"
        )

        # Check text data matches filtered node count
        assert len(data.title) == 1434, "Should have title for 1434 connected nodes"
        assert len(data.abstract) == 1434, (
            "Should have abstract for 1434 connected nodes"
        )
        assert data.title_embeddings.shape == (
            1434,
            768,
        ), "Should have title embeddings for 1434 nodes"
        assert data.abstract_embeddings.shape == (
            1434,
            768,
        ), "Should have abstract embeddings for 1434 nodes"

    def test_load_text_features_lazy(self) -> None:
        """Test lazy loading of text features for Cora."""
        dataset = CoraCocitation(
            remove_isolated_nodes=False,
            load_text_features="lazy",
        )
        data = dataset[0]

        # Text data should NOT be loaded yet
        assert not hasattr(data, "title"), "title should not be loaded"
        assert not hasattr(data, "abstract"), "abstract should not be loaded"
        assert not hasattr(data, "title_embeddings"), (
            "title_embeddings should not be loaded"
        )
        assert not hasattr(data, "abstract_embeddings"), (
            "abstract_embeddings should not be loaded"
        )

        # But lazy loading methods should exist
        assert hasattr(data, "load_title"), "Should have load_title method"
        assert hasattr(data, "load_abstract"), "Should have load_abstract method"
        assert hasattr(data, "load_title_embeddings"), (
            "Should have load_title_embeddings method"
        )
        assert hasattr(data, "load_abstract_embeddings"), (
            "Should have load_abstract_embeddings method"
        )
        assert callable(data.load_title), "load_title should be callable"
        assert callable(data.load_abstract), "load_abstract should be callable"
        assert callable(data.load_title_embeddings), (
            "load_title_embeddings should be callable"
        )
        assert callable(data.load_abstract_embeddings), (
            "load_abstract_embeddings should be callable"
        )

        # Load texts on-demand
        titles = data.load_title()
        abstracts = data.load_abstract()
        assert len(titles) == 2708, "Should load 2708 titles"
        assert len(abstracts) == 2708, "Should load 2708 abstracts"
        assert isinstance(titles[0], str), "Titles should be strings"
        assert isinstance(abstracts[0], str), "Abstracts should be strings"

        # Load embeddings on-demand
        title_embeddings = data.load_title_embeddings()
        abstract_embeddings = data.load_abstract_embeddings()
        assert title_embeddings.shape == (2708, 768), (
            "Should load correct title embeddings"
        )
        assert abstract_embeddings.shape == (2708, 768), (
            "Should load correct abstract embeddings"
        )

    def test_custom_encoder_model(self) -> None:
        """Test using a different encoder model."""
        dataset = CoraCocitation(
            remove_isolated_nodes=False,
            load_text_features=True,
            encoder_model="all-MiniLM-L6-v2",  # 384-dim model
        )
        data = dataset[0]

        # Should use 384-dim embeddings for both title and abstract
        assert data.title_embeddings.shape == (
            2708,
            384,
        ), "Should have 384-dim title embeddings (MiniLM)"
        assert data.abstract_embeddings.shape == (
            2708,
            384,
        ), "Should have 384-dim abstract embeddings (MiniLM)"

    def test_backward_compatibility_no_text(self) -> None:
        """Test that default behavior is unchanged (no text features)."""
        dataset = CoraCocitation(remove_isolated_nodes=True)
        data = dataset[0]

        # Default behavior: 1434 connected nodes, no text
        assert data.num_nodes == 1434, "Should have 1434 nodes (default)"
        assert not hasattr(data, "title"), "Should NOT have title by default"
        assert not hasattr(data, "abstract"), "Should NOT have abstract by default"
        assert not hasattr(data, "title_embeddings"), (
            "Should NOT have title_embeddings by default"
        )
        assert not hasattr(data, "abstract_embeddings"), (
            "Should NOT have abstract_embeddings by default"
        )
        assert not hasattr(data, "load_title"), "Should NOT have load_title"
        assert not hasattr(data, "load_abstract"), "Should NOT have load_abstract"
        assert not hasattr(data, "load_title_embeddings"), (
            "Should NOT have load_title_embeddings"
        )
        assert not hasattr(data, "load_abstract_embeddings"), (
            "Should NOT have load_abstract_embeddings"
        )

    def test_text_content_semantic_validation(self) -> None:
        """Test that text content contains expected academic keywords."""
        dataset = CoraCocitation(
            remove_isolated_nodes=False,
            load_text_features=True,
        )
        data = dataset[0]

        # Check that at least some texts contain academic keywords
        titles = data.title
        abstracts = data.abstract
        combined_text = " ".join(titles[:100] + abstracts[:100]).lower()

        # These are common words in computer science papers
        academic_keywords = [
            "neural",
            "learning",
            "network",
            "algorithm",
            "model",
            "data",
            "method",
        ]

        # At least one keyword should appear
        found_keywords = [kw for kw in academic_keywords if kw in combined_text]
        assert len(found_keywords) > 0, (
            f"Expected academic keywords, found: {found_keywords}"
        )


class TestPubmedTextFeatures:
    """Test text features for Pubmed dataset."""

    def test_load_text_features_eager(self) -> None:
        """Test eager loading of text features for Pubmed."""
        dataset = PubmedCocitation(
            remove_isolated_nodes=False,
            load_text_features=True,
        )
        data = dataset[0]

        # Check basic properties
        assert data.num_nodes == 19717, (
            "Pubmed should have 19717 nodes with TAG alignment"
        )

        # Check text attributes (separate title and abstract)
        assert hasattr(data, "title"), "Should have title attribute"
        assert hasattr(data, "abstract"), "Should have abstract attribute"
        assert hasattr(data, "title_embeddings"), (
            "Should have title_embeddings attribute"
        )
        assert hasattr(data, "abstract_embeddings"), (
            "Should have abstract_embeddings attribute"
        )

        # Check dimensions
        assert len(data.title) == 19717, "Should have title for all 19717 nodes"
        assert len(data.abstract) == 19717, "Should have abstract for all 19717 nodes"
        assert data.title_embeddings.shape == (19717, 768), (
            "Should have 768-dim title embeddings"
        )
        assert data.abstract_embeddings.shape == (19717, 768), (
            "Should have 768-dim abstract embeddings"
        )

    def test_load_text_features_lazy(self) -> None:
        """Test lazy loading of text features for Pubmed (recommended for large datasets)."""
        dataset = PubmedCocitation(
            remove_isolated_nodes=False,
            load_text_features="lazy",
        )
        data = dataset[0]

        # Text data should NOT be loaded yet
        assert not hasattr(data, "title"), "title should not be loaded"
        assert not hasattr(data, "abstract"), "abstract should not be loaded"
        assert not hasattr(data, "title_embeddings"), (
            "title_embeddings should not be loaded"
        )
        assert not hasattr(data, "abstract_embeddings"), (
            "abstract_embeddings should not be loaded"
        )

        # Lazy loading methods should exist
        assert hasattr(data, "load_title"), "Should have load_title method"
        assert hasattr(data, "load_abstract"), "Should have load_abstract method"
        assert hasattr(data, "load_title_embeddings"), (
            "Should have load_title_embeddings method"
        )
        assert hasattr(data, "load_abstract_embeddings"), (
            "Should have load_abstract_embeddings method"
        )

        # Load on-demand
        titles = data.load_title()
        abstracts = data.load_abstract()
        title_embeddings = data.load_title_embeddings()
        abstract_embeddings = data.load_abstract_embeddings()

        assert len(titles) == 19717, "Should load all titles"
        assert len(abstracts) == 19717, "Should load all abstracts"
        assert title_embeddings.shape == (19717, 768), (
            "Should load all title embeddings"
        )
        assert abstract_embeddings.shape == (19717, 768), (
            "Should load all abstract embeddings"
        )

    def test_load_text_features_with_isolated_removed(self) -> None:
        """Test text features with isolated nodes removed for Pubmed."""
        dataset = PubmedCocitation(
            remove_isolated_nodes=True,
            load_text_features=True,
        )
        data = dataset[0]

        # Check filtered node count
        assert data.num_nodes == 3840, "Should have 3840 connected nodes"

        # Check text data matches
        assert len(data.title) == 3840, "Should have title for 3840 nodes"
        assert len(data.abstract) == 3840, "Should have abstract for 3840 nodes"
        assert data.title_embeddings.shape == (3840, 768), (
            "Should have title embeddings for 3840 nodes"
        )
        assert data.abstract_embeddings.shape == (3840, 768), (
            "Should have abstract embeddings for 3840 nodes"
        )

    def test_pubmed_text_semantics(self) -> None:
        """Test that Pubmed texts contain medical/diabetes keywords."""
        dataset = PubmedCocitation(
            remove_isolated_nodes=False,
            load_text_features=True,
        )
        data = dataset[0]

        # Check for medical/diabetes keywords in sample
        titles = data.title
        abstracts = data.abstract
        combined_text = " ".join(titles[:100] + abstracts[:100]).lower()

        medical_keywords = [
            "diabetes",
            "insulin",
            "glucose",
            "patient",
            "treatment",
            "disease",
            "clinical",
        ]

        found_keywords = [kw for kw in medical_keywords if kw in combined_text]
        assert len(found_keywords) > 0, (
            f"Expected medical keywords, found: {found_keywords}"
        )


class TestCiteseerTextFeatures:
    """Test that Citeseer correctly rejects text features."""

    def test_citeseer_text_not_supported(self) -> None:
        """Test that Citeseer raises ValueError when text features requested."""
        with pytest.raises(ValueError, match="does not support TAG text features"):
            CiteseerCocitation(
                remove_isolated_nodes=False,
                load_text_features=True,
            )

        # Error message should mention incompatible node counts
        with pytest.raises(ValueError, match="incompatible node counts"):
            CiteseerCocitation(
                remove_isolated_nodes=True,
                load_text_features=True,
            )

    def test_citeseer_backward_compatibility(self) -> None:
        """Test that Citeseer still works without text features."""
        dataset = CiteseerCocitation(remove_isolated_nodes=True)
        data = dataset[0]

        # Should work normally without text
        assert data.num_nodes == 2110, "Should have 2110 nodes"
        assert not hasattr(data, "title"), "Should NOT have title"
        assert not hasattr(data, "abstract"), "Should NOT have abstract"
        assert not hasattr(data, "title_embeddings"), "Should NOT have title_embeddings"
        assert not hasattr(data, "abstract_embeddings"), (
            "Should NOT have abstract_embeddings"
        )


class TestTextFeaturesTransform:
    """Test text features transform functionality."""

    def test_transform_caching(self) -> None:
        """Test that caching works correctly."""
        # First load: downloads and encodes
        dataset1 = CoraCocitation(
            remove_isolated_nodes=False,
            load_text_features=True,
            force_reload=False,  # Use cache
        )
        data1 = dataset1[0]

        # Second load: should use cache
        dataset2 = CoraCocitation(
            remove_isolated_nodes=False,
            load_text_features=True,
            force_reload=False,
        )
        data2 = dataset2[0]

        # Both should have same shape and content
        assert data1.title_embeddings.shape == data2.title_embeddings.shape
        assert data1.abstract_embeddings.shape == data2.abstract_embeddings.shape
        assert len(data1.title) == len(data2.title)
        assert len(data1.abstract) == len(data2.abstract)

    def test_transform_node_id_mapping(self) -> None:
        """Test that node ID mapping is correctly applied."""
        # Load with all nodes
        dataset_full = CoraCocitation(
            remove_isolated_nodes=False,
            load_text_features=True,
        )
        data_full = dataset_full[0]

        # Load with isolated nodes removed
        dataset_filtered = CoraCocitation(
            remove_isolated_nodes=True,
            load_text_features=True,
        )
        data_filtered = dataset_filtered[0]

        # Full dataset should have more nodes
        assert data_full.num_nodes == 2708, "Full dataset: 2708 nodes"
        assert data_filtered.num_nodes == 1434, "Filtered dataset: 1434 nodes"

        # Text counts should match node counts
        assert len(data_full.title) == 2708
        assert len(data_full.abstract) == 2708
        assert len(data_filtered.title) == 1434
        assert len(data_filtered.abstract) == 1434
        assert data_full.title_embeddings.shape[0] == 2708
        assert data_full.abstract_embeddings.shape[0] == 2708
        assert data_filtered.title_embeddings.shape[0] == 1434
        assert data_filtered.abstract_embeddings.shape[0] == 1434
