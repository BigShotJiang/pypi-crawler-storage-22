"""Tests for entity-attribute hyperedge transforms."""

from __future__ import annotations

import pytest
import torch

from pyg_hyper_data.data import HyperData


class TestAddEntityAttributeHyperedges:
    """Test AddEntityAttributeHyperedges transform."""

    @pytest.fixture
    def simple_hyper_data(self) -> HyperData:
        """Create a simple HyperData with text attributes."""
        # 3 papers with features
        x = torch.randn(3, 10)

        # 2 hyperedges: {0, 1}, {1, 2}
        hyperedge_index = torch.tensor(
            [
                [0, 1, 1, 2],  # node indices
                [0, 0, 1, 1],  # hyperedge indices
            ]
        )

        y = torch.tensor([0, 1, 0])

        # Text attributes (title and abstract embeddings)
        title = torch.randn(3, 768)
        abstract = torch.randn(3, 768)

        return HyperData(
            x=x,
            hyperedge_index=hyperedge_index,
            y=y,
            title=title,
            abstract=abstract,
        )

    def test_basic_transform(self, simple_hyper_data: HyperData) -> None:
        """Test basic transformation with title and abstract attributes."""
        from pyg_hyper_data.transforms.attributed import AddEntityAttributeHyperedges

        transform = AddEntityAttributeHyperedges(
            attributes=["title", "abstract"],
            one_to_one=True,
            edge_type="combined",
        )

        result = transform(simple_hyper_data)

        # Check that result is AttributedHyperData
        from pyg_hyper_data.transforms.attributed import AttributedHyperData

        assert isinstance(result, AttributedHyperData)

        # Original: 3 nodes, After: 3 (papers) + 3 (titles) + 3 (abstracts) = 9
        assert result.num_nodes == 9
        assert result.original_num_nodes == 3

        # Check attribute metadata
        assert result.attribute_types == ["title", "abstract"]
        assert "title" in result.attribute_offsets
        assert "abstract" in result.attribute_offsets
        assert result.attribute_offsets["title"] == 3  # After papers
        assert result.attribute_offsets["abstract"] == 6  # After titles

    def test_node_offset_calculation(self, simple_hyper_data: HyperData) -> None:
        """Test that node offsets are calculated correctly."""
        from pyg_hyper_data.transforms.attributed import AddEntityAttributeHyperedges

        transform = AddEntityAttributeHyperedges(
            attributes=["title", "abstract"],
            one_to_one=True,
            edge_type="combined",
        )

        result = transform(simple_hyper_data)

        # Check node ID ranges
        # Papers: [0, 3)
        # Titles: [3, 6)
        # Abstracts: [6, 9)

        # Entity-attribute edges should connect papers to their attributes
        entity_attr_mask = result.entity_attribute_edge_mask
        entity_attr_edges = result.hyperedge_index[:, entity_attr_mask]

        # Check that paper nodes (0-2) are connected to attribute nodes
        paper_nodes = entity_attr_edges[0][entity_attr_edges[0] < 3]
        assert len(paper_nodes) > 0

        # Check that title nodes (3-5) and abstract nodes (6-8) are present
        title_nodes = entity_attr_edges[0][
            (entity_attr_edges[0] >= 3) & (entity_attr_edges[0] < 6)
        ]
        abstract_nodes = entity_attr_edges[0][entity_attr_edges[0] >= 6]

        assert len(title_nodes) > 0
        assert len(abstract_nodes) > 0

    def test_combined_edge_type(self, simple_hyper_data: HyperData) -> None:
        """Test combined edge type (one hyperedge per entity with all attributes)."""
        from pyg_hyper_data.transforms.attributed import AddEntityAttributeHyperedges

        transform = AddEntityAttributeHyperedges(
            attributes=["title", "abstract"],
            one_to_one=True,
            edge_type="combined",
        )

        result = transform(simple_hyper_data)

        # With combined edge type, should have 3 entity-attribute hyperedges (one per paper)
        entity_attr_mask = result.entity_attribute_edge_mask

        # Each paper connected to itself + title + abstract = 3 connections per paper
        # 3 papers x 3 connections = 9 connections total
        # But these are grouped into 3 hyperedges
        entity_attr_edge_ids = result.hyperedge_index[1, entity_attr_mask]
        unique_entity_attr_edges = torch.unique(entity_attr_edge_ids)

        assert len(unique_entity_attr_edges) == 3  # 3 entity-attribute hyperedges

    def test_separate_edge_type(self, simple_hyper_data: HyperData) -> None:
        """Test separate edge type (one hyperedge per entity-attribute pair)."""
        from pyg_hyper_data.transforms.attributed import AddEntityAttributeHyperedges

        transform = AddEntityAttributeHyperedges(
            attributes=["title", "abstract"],
            one_to_one=True,
            edge_type="separate",
        )

        result = transform(simple_hyper_data)

        # With separate edge type, should have more hyperedges
        # 3 papers x 2 attributes = 6 entity-attribute hyperedges
        entity_attr_mask = result.entity_attribute_edge_mask
        entity_attr_edge_ids = result.hyperedge_index[1, entity_attr_mask]
        unique_entity_attr_edges = torch.unique(entity_attr_edge_ids)

        assert len(unique_entity_attr_edges) == 6

    def test_attribute_features_preserved(self, simple_hyper_data: HyperData) -> None:
        """Test that attribute features are preserved in the result."""
        from pyg_hyper_data.transforms.attributed import AddEntityAttributeHyperedges

        transform = AddEntityAttributeHyperedges(
            attributes=["title", "abstract"],
            one_to_one=True,
            edge_type="combined",
        )

        result = transform(simple_hyper_data)

        # Check that attribute features are stored
        assert "title" in result.attribute_features
        assert "abstract" in result.attribute_features

        # Check shapes
        assert result.attribute_features["title"].shape == (3, 768)
        assert result.attribute_features["abstract"].shape == (3, 768)

        # Check that original features are preserved
        assert torch.equal(result.attribute_features["title"], simple_hyper_data.title)
        assert torch.equal(
            result.attribute_features["abstract"], simple_hyper_data.abstract
        )

    def test_original_hyperedges_preserved(self, simple_hyper_data: HyperData) -> None:
        """Test that original structural hyperedges are preserved."""
        from pyg_hyper_data.transforms.attributed import AddEntityAttributeHyperedges

        transform = AddEntityAttributeHyperedges(
            attributes=["title", "abstract"],
            one_to_one=True,
            edge_type="combined",
        )

        result = transform(simple_hyper_data)

        # Original hyperedges should be at the beginning
        original_mask = ~result.entity_attribute_edge_mask
        original_edges = result.hyperedge_index[:, original_mask]

        # Check that original edges are preserved
        assert original_edges.shape[1] == simple_hyper_data.hyperedge_index.shape[1]

        # Edge IDs for original edges should start from 0
        original_edge_ids = original_edges[1]
        assert original_edge_ids.min().item() == 0
        assert original_edge_ids.max().item() < result.original_num_edges

    def test_missing_attribute_error(self, simple_hyper_data: HyperData) -> None:
        """Test that requesting non-existent attributes raises an error."""
        from pyg_hyper_data.transforms.attributed import AddEntityAttributeHyperedges

        transform = AddEntityAttributeHyperedges(
            attributes=["nonexistent"],
            one_to_one=True,
            edge_type="combined",
        )

        with pytest.raises(ValueError, match="Attribute 'nonexistent' not found"):
            transform(simple_hyper_data)

    def test_single_attribute(self, simple_hyper_data: HyperData) -> None:
        """Test transform with only one attribute."""
        from pyg_hyper_data.transforms.attributed import AddEntityAttributeHyperedges

        transform = AddEntityAttributeHyperedges(
            attributes=["title"],
            one_to_one=True,
            edge_type="combined",
        )

        result = transform(simple_hyper_data)

        # 3 papers + 3 titles = 6 nodes
        assert result.num_nodes == 6
        assert result.attribute_types == ["title"]
        assert "abstract" not in result.attribute_features

    def test_empty_attributes_error(self, simple_hyper_data: HyperData) -> None:
        """Test that empty attributes list raises an error."""
        from pyg_hyper_data.transforms.attributed import AddEntityAttributeHyperedges

        with pytest.raises(
            ValueError, match="At least one attribute must be specified"
        ):
            AddEntityAttributeHyperedges(
                attributes=[],
                one_to_one=True,
                edge_type="combined",
            )
