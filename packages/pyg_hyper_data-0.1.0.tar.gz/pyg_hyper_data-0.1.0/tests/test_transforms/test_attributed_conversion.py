"""Tests for AttributedHyperData to HeteroData conversion."""

from __future__ import annotations

import pytest
import torch

from pyg_hyper_data.data import HyperData
from pyg_hyper_data.data.conversion import hyperedge_index_to_hetero


class TestAttributedHyperDataConversion:
    """Test conversion of AttributedHyperData to HyperHeteroData."""

    @pytest.fixture
    def attributed_hyper_data(self) -> HyperData:
        """Create AttributedHyperData for testing."""
        from pyg_hyper_data.transforms.attributed import AddEntityAttributeHyperedges

        # 3 papers with features
        x = torch.randn(3, 10)

        # 2 hyperedges: {0, 1}, {1, 2}
        hyperedge_index = torch.tensor(
            [
                [0, 1, 1, 2],  # node indices
                [0, 0, 1, 1],  # hyperedge indices
            ]
        )

        y = torch.tensor([0, 1, 0])

        # Text attributes
        title = torch.randn(3, 768)
        abstract = torch.randn(3, 768)

        data = HyperData(
            x=x,
            hyperedge_index=hyperedge_index,
            y=y,
            title=title,
            abstract=abstract,
        )

        # Apply transform
        transform = AddEntityAttributeHyperedges(
            attributes=["title", "abstract"],
            one_to_one=True,
            edge_type="combined",
        )

        return transform(data)

    def test_node_types_created(self, attributed_hyper_data: HyperData) -> None:
        """Test that correct node types are created."""
        hetero_data = hyperedge_index_to_hetero(attributed_hyper_data)

        # Check node types
        assert "entity" in hetero_data.node_types
        assert "title" in hetero_data.node_types
        assert "abstract" in hetero_data.node_types
        assert "structural_hyperedge" in hetero_data.node_types
        assert "entity_attribute_hyperedge" in hetero_data.node_types

        # Should NOT have generic 'node' or 'hyperedge' types
        assert "node" not in hetero_data.node_types
        assert "hyperedge" not in hetero_data.node_types

    def test_node_counts(self, attributed_hyper_data: HyperData) -> None:
        """Test that node counts are correct."""
        hetero_data = hyperedge_index_to_hetero(attributed_hyper_data)

        # Entity nodes
        assert hetero_data["entity"].num_nodes == 3

        # Attribute nodes
        assert hetero_data["title"].num_nodes == 3
        assert hetero_data["abstract"].num_nodes == 3

        # Hyperedges: 2 structural + 3 entity-attribute
        assert hetero_data["structural_hyperedge"].num_nodes == 2
        assert hetero_data["entity_attribute_hyperedge"].num_nodes == 3

    def test_entity_features_preserved(self, attributed_hyper_data: HyperData) -> None:
        """Test that entity features are preserved."""
        hetero_data = hyperedge_index_to_hetero(attributed_hyper_data)

        # Entity features
        assert hetero_data["entity"].x.shape == (3, 10)
        assert torch.equal(hetero_data["entity"].x, attributed_hyper_data.x)

        # Entity labels
        assert hetero_data["entity"].y.shape == (3,)
        assert torch.equal(hetero_data["entity"].y, attributed_hyper_data.y)

    def test_attribute_features_preserved(
        self, attributed_hyper_data: HyperData
    ) -> None:
        """Test that attribute features are preserved."""
        hetero_data = hyperedge_index_to_hetero(attributed_hyper_data)

        # Title features
        assert hetero_data["title"].x.shape == (3, 768)
        assert torch.equal(
            hetero_data["title"].x,
            attributed_hyper_data.attribute_features["title"],
        )

        # Abstract features
        assert hetero_data["abstract"].x.shape == (3, 768)
        assert torch.equal(
            hetero_data["abstract"].x,
            attributed_hyper_data.attribute_features["abstract"],
        )

    def test_structural_edges_preserved(self, attributed_hyper_data: HyperData) -> None:
        """Test that structural hyperedges are preserved."""
        hetero_data = hyperedge_index_to_hetero(attributed_hyper_data)

        # Check entity-to-structural_hyperedge edges
        assert (
            "entity",
            "member_of",
            "structural_hyperedge",
        ) in hetero_data.edge_types
        assert (
            "structural_hyperedge",
            "has_member",
            "entity",
        ) in hetero_data.edge_types

        # Should have 4 connections (original structural edges)
        structural_edges = hetero_data[
            "entity", "member_of", "structural_hyperedge"
        ].edge_index
        assert structural_edges.shape[1] == 4

    def test_entity_attribute_edges_created(
        self, attributed_hyper_data: HyperData
    ) -> None:
        """Test that entity-attribute edges are created."""
        hetero_data = hyperedge_index_to_hetero(attributed_hyper_data)

        # Check entity connections to entity_attribute_hyperedge
        assert (
            "entity",
            "member_of",
            "entity_attribute_hyperedge",
        ) in hetero_data.edge_types
        assert (
            "entity_attribute_hyperedge",
            "has_member",
            "entity",
        ) in hetero_data.edge_types

        # Check title connections to entity_attribute_hyperedge
        assert (
            "title",
            "member_of",
            "entity_attribute_hyperedge",
        ) in hetero_data.edge_types
        assert (
            "entity_attribute_hyperedge",
            "has_member",
            "title",
        ) in hetero_data.edge_types

        # Check abstract connections to entity_attribute_hyperedge
        assert (
            "abstract",
            "member_of",
            "entity_attribute_hyperedge",
        ) in hetero_data.edge_types
        assert (
            "entity_attribute_hyperedge",
            "has_member",
            "abstract",
        ) in hetero_data.edge_types

        # Each entity/title/abstract should have 3 connections (one per entity-attribute hyperedge)
        entity_edges = hetero_data[
            "entity", "member_of", "entity_attribute_hyperedge"
        ].edge_index
        title_edges = hetero_data[
            "title", "member_of", "entity_attribute_hyperedge"
        ].edge_index
        abstract_edges = hetero_data[
            "abstract", "member_of", "entity_attribute_hyperedge"
        ].edge_index

        assert entity_edges.shape[1] == 3
        assert title_edges.shape[1] == 3
        assert abstract_edges.shape[1] == 3

    def test_edge_connectivity(self, attributed_hyper_data: HyperData) -> None:
        """Test that edges connect correct nodes."""
        hetero_data = hyperedge_index_to_hetero(attributed_hyper_data)

        # Check entity-to-entity_attribute_hyperedge connectivity
        entity_edges = hetero_data[
            "entity", "member_of", "entity_attribute_hyperedge"
        ].edge_index

        # Each entity i should connect to entity_attribute_hyperedge i
        for i in range(3):
            # Find hyperedges connected to entity i
            entity_mask = entity_edges[0] == i
            hyperedge_ids = entity_edges[1, entity_mask]

            # Should connect to exactly one hyperedge (hyperedge i)
            assert len(hyperedge_ids) == 1
            assert i in hyperedge_ids

        # Check title-to-entity_attribute_hyperedge connectivity
        title_edges = hetero_data[
            "title", "member_of", "entity_attribute_hyperedge"
        ].edge_index

        # Each title i should connect to entity_attribute_hyperedge i
        for i in range(3):
            title_mask = title_edges[0] == i
            hyperedge_ids = title_edges[1, title_mask]

            assert len(hyperedge_ids) == 1
            assert i in hyperedge_ids

    def test_backward_compatibility(self) -> None:
        """Test that regular HyperData still works."""
        # Create regular HyperData (no attributes)
        x = torch.randn(3, 10)
        hyperedge_index = torch.tensor(
            [
                [0, 1, 1, 2],
                [0, 0, 1, 1],
            ]
        )
        y = torch.tensor([0, 1, 0])

        data = HyperData(x=x, hyperedge_index=hyperedge_index, y=y)

        # Convert to hetero
        hetero_data = hyperedge_index_to_hetero(data)

        # Should use 'node' type (not 'entity')
        assert "node" in hetero_data.node_types
        assert "entity" not in hetero_data.node_types

        # Should have standard edge types
        assert ("node", "member_of", "hyperedge") in hetero_data.edge_types

    def test_separate_edge_type(self) -> None:
        """Test conversion with separate edge type."""
        from pyg_hyper_data.transforms.attributed import AddEntityAttributeHyperedges

        # Create data
        x = torch.randn(3, 10)
        hyperedge_index = torch.tensor([[0, 1, 1, 2], [0, 0, 1, 1]])
        y = torch.tensor([0, 1, 0])
        title = torch.randn(3, 768)
        abstract = torch.randn(3, 768)

        data = HyperData(
            x=x, hyperedge_index=hyperedge_index, y=y, title=title, abstract=abstract
        )

        # Apply transform with separate edge type
        transform = AddEntityAttributeHyperedges(
            attributes=["title", "abstract"],
            one_to_one=True,
            edge_type="separate",
        )
        attributed_data = transform(data)

        # Convert to hetero
        hetero_data = hyperedge_index_to_hetero(attributed_data)

        # Should have more hyperedges
        # 2 structural + 3 x 2 (title + abstract) = 8
        assert hetero_data["structural_hyperedge"].num_nodes == 2
        assert hetero_data["entity_attribute_hyperedge"].num_nodes == 6

        # Entity-attribute edges should still be correct
        entity_edges = hetero_data[
            "entity", "member_of", "entity_attribute_hyperedge"
        ].edge_index
        title_edges = hetero_data[
            "title", "member_of", "entity_attribute_hyperedge"
        ].edge_index
        abstract_edges = hetero_data[
            "abstract", "member_of", "entity_attribute_hyperedge"
        ].edge_index

        # Each entity connects to 2 hyperedges (title and abstract)
        # Each title/abstract connects to 1 hyperedge
        assert entity_edges.shape[1] == 6  # 3 entities x 2 attributes
        assert title_edges.shape[1] == 3
        assert abstract_edges.shape[1] == 3
