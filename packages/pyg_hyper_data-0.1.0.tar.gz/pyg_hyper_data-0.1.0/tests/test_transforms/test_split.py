"""Tests for train/val/test split utilities."""

import pytest
import torch

from pyg_hyper_data.transforms.split import (
    random_hypergraph_split,
    stratified_hypergraph_split,
)


def test_random_hypergraph_split():
    """Test random split with default ratios."""
    num_nodes = 100
    train_mask, val_mask, test_mask = random_hypergraph_split(
        num_nodes, train_ratio=0.6, val_ratio=0.2, test_ratio=0.2
    )

    # Check sizes
    assert train_mask.sum() == 60
    assert val_mask.sum() == 20
    assert test_mask.sum() == 20

    # Check no overlap
    assert not (train_mask & val_mask).any()
    assert not (train_mask & test_mask).any()
    assert not (val_mask & test_mask).any()

    # Check all nodes covered
    assert (train_mask | val_mask | test_mask).all()


def test_random_hypergraph_split_reproducibility():
    """Test split reproducibility with seed."""
    num_nodes = 100

    # Same seed should produce same split
    train1, val1, test1 = random_hypergraph_split(num_nodes, seed=42)
    train2, val2, test2 = random_hypergraph_split(num_nodes, seed=42)

    assert torch.equal(train1, train2)
    assert torch.equal(val1, val2)
    assert torch.equal(test1, test2)

    # Different seed should produce different split
    train3, _val3, _test3 = random_hypergraph_split(num_nodes, seed=123)

    assert not torch.equal(train1, train3)


def test_random_hypergraph_split_custom_ratios():
    """Test random split with custom ratios."""
    num_nodes = 100
    train_mask, val_mask, test_mask = random_hypergraph_split(
        num_nodes, train_ratio=0.7, val_ratio=0.15, test_ratio=0.15
    )

    # Check approximate sizes (due to rounding)
    assert train_mask.sum() == 70
    assert val_mask.sum() == 15
    assert test_mask.sum() == 15


def test_random_hypergraph_split_invalid_ratios():
    """Test that invalid ratios raise ValueError."""
    num_nodes = 100

    with pytest.raises(ValueError, match=r"Ratios must sum to 1\.0"):
        random_hypergraph_split(
            num_nodes, train_ratio=0.5, val_ratio=0.3, test_ratio=0.3
        )


def test_stratified_hypergraph_split():
    """Test stratified split maintains class distribution."""
    # Create labels with 3 classes, 30 nodes each
    labels = torch.cat(
        [
            torch.zeros(30, dtype=torch.long),
            torch.ones(30, dtype=torch.long),
            torch.full((30,), 2, dtype=torch.long),
        ]
    )

    train_mask, val_mask, test_mask = stratified_hypergraph_split(
        labels, train_ratio=0.6, val_ratio=0.2, test_ratio=0.2
    )

    # Check overall sizes
    assert train_mask.sum() == 54  # 18 per class
    assert val_mask.sum() == 18  # 6 per class
    assert test_mask.sum() == 18  # 6 per class

    # Check class distribution in each split
    train_labels = labels[train_mask]
    val_labels = labels[val_mask]
    test_labels = labels[test_mask]

    # Each class should have equal representation
    for c in range(3):
        assert (train_labels == c).sum() == 18
        assert (val_labels == c).sum() == 6
        assert (test_labels == c).sum() == 6

    # Check no overlap
    assert not (train_mask & val_mask).any()
    assert not (train_mask & test_mask).any()
    assert not (val_mask & test_mask).any()

    # Check all nodes covered
    assert (train_mask | val_mask | test_mask).all()


def test_stratified_hypergraph_split_imbalanced():
    """Test stratified split with imbalanced classes."""
    # Create imbalanced labels: class 0 has 50, class 1 has 30, class 2 has 20
    labels = torch.cat(
        [
            torch.zeros(50, dtype=torch.long),
            torch.ones(30, dtype=torch.long),
            torch.full((20,), 2, dtype=torch.long),
        ]
    )

    train_mask, val_mask, test_mask = stratified_hypergraph_split(
        labels, train_ratio=0.6, val_ratio=0.2, test_ratio=0.2, seed=42
    )

    # Check each class maintains proportion
    train_labels = labels[train_mask]
    val_labels = labels[val_mask]
    test_labels = labels[test_mask]

    # Class 0: 50 * 0.6 = 30 train, 50 * 0.2 = 10 val, 10 test
    assert (train_labels == 0).sum() == 30
    assert (val_labels == 0).sum() == 10
    assert (test_labels == 0).sum() == 10

    # Class 1: 30 * 0.6 = 18 train, 30 * 0.2 = 6 val, 6 test
    assert (train_labels == 1).sum() == 18
    assert (val_labels == 1).sum() == 6
    assert (test_labels == 1).sum() == 6

    # Class 2: 20 * 0.6 = 12 train, 20 * 0.2 = 4 val, 4 test
    assert (train_labels == 2).sum() == 12
    assert (val_labels == 2).sum() == 4
    assert (test_labels == 2).sum() == 4


def test_stratified_hypergraph_split_reproducibility():
    """Test stratified split reproducibility with seed."""
    labels = torch.tensor([0, 0, 0, 1, 1, 1, 2, 2, 2])

    # Same seed should produce same split
    train1, val1, test1 = stratified_hypergraph_split(labels, seed=42)
    train2, val2, test2 = stratified_hypergraph_split(labels, seed=42)

    assert torch.equal(train1, train2)
    assert torch.equal(val1, val2)
    assert torch.equal(test1, test2)


def test_stratified_hypergraph_split_invalid_ratios():
    """Test that invalid ratios raise ValueError."""
    labels = torch.tensor([0, 0, 1, 1, 2, 2])

    with pytest.raises(ValueError, match=r"Ratios must sum to 1\.0"):
        stratified_hypergraph_split(
            labels, train_ratio=0.5, val_ratio=0.3, test_ratio=0.3
        )


def test_random_split_small_dataset():
    """Test random split with very small dataset."""
    num_nodes = 10
    train_mask, val_mask, test_mask = random_hypergraph_split(
        num_nodes, train_ratio=0.6, val_ratio=0.2, test_ratio=0.2
    )

    assert train_mask.sum() == 6
    assert val_mask.sum() == 2
    assert test_mask.sum() == 2


def test_stratified_split_small_class():
    """Test stratified split with small class sizes."""
    # Each class has only 3 nodes
    labels = torch.tensor([0, 0, 0, 1, 1, 1, 2, 2, 2])

    train_mask, val_mask, test_mask = stratified_hypergraph_split(
        labels, train_ratio=0.6, val_ratio=0.2, test_ratio=0.2
    )

    # With 3 nodes per class and 0.6/0.2/0.2 split:
    # train=1, val=0, test=2 per class (due to rounding)
    assert train_mask.sum() >= 3
    assert val_mask.sum() >= 0
    assert test_mask.sum() >= 0

    # All nodes should be covered
    assert (train_mask | val_mask | test_mask).all()
