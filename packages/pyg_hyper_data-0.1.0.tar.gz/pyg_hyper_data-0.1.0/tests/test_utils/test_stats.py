"""Tests for statistical utilities."""

import torch

from pyg_hyper_data.data import HyperData
from pyg_hyper_data.utils.stats import (
    compute_hypergraph_statistics,
    compute_label_statistics,
)


def test_compute_hypergraph_statistics():
    """Test hypergraph statistics computation."""
    # Create simple hypergraph
    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor(
        [
            [0, 1, 2, 3, 4, 5, 6, 7, 8],  # nodes
            [0, 0, 0, 1, 1, 1, 2, 2, 2],  # hyperedges
        ]
    )
    y = torch.tensor([0, 0, 0, 1, 1, 1, 2, 2, 2, 2])

    data = HyperData(x=x, hyperedge_index=hyperedge_index, y=y)

    stats = compute_hypergraph_statistics(data)

    assert stats["num_nodes"] == 10
    assert stats["num_hyperedges"] == 3
    assert stats["num_connections"] == 9
    assert stats["avg_hyperedge_size"] == 3.0
    assert stats["max_hyperedge_size"] == 3
    assert stats["min_hyperedge_size"] == 3
    assert stats["max_node_degree"] == 1
    assert stats["min_node_degree"] == 0


def test_compute_label_statistics():
    """Test label statistics computation."""
    # Balanced labels
    y = torch.tensor([0, 0, 1, 1, 2, 2])
    data = HyperData(y=y, hyperedge_index=torch.zeros((2, 0), dtype=torch.long))

    stats = compute_label_statistics(data)

    assert stats["num_classes"] == 3
    assert stats["class_counts"] == [2, 2, 2]
    assert stats["class_balance"] == 1.0

    # Imbalanced labels
    y = torch.tensor([0, 0, 0, 0, 1, 2])
    data = HyperData(y=y, hyperedge_index=torch.zeros((2, 0), dtype=torch.long))

    stats = compute_label_statistics(data)

    assert stats["num_classes"] == 3
    assert stats["class_counts"] == [4, 1, 1]
    assert abs(stats["class_balance"] - 0.25) < 1e-6


def test_compute_label_statistics_no_labels():
    """Test label statistics with no labels."""
    data = HyperData(hyperedge_index=torch.zeros((2, 0), dtype=torch.long))

    stats = compute_label_statistics(data)

    assert stats["num_classes"] == 0
    assert stats["class_counts"] == []
    assert stats["class_balance"] == 0.0


def test_hypergraph_statistics_empty():
    """Test statistics computation with empty hypergraph."""
    data = HyperData(hyperedge_index=torch.zeros((2, 0), dtype=torch.long))
    data.num_nodes = 10

    stats = compute_hypergraph_statistics(data)

    assert stats["num_nodes"] == 10
    assert stats["num_hyperedges"] == 0
    assert stats["num_connections"] == 0
    assert stats["max_node_degree"] == 0
    assert stats["min_node_degree"] == 0


def test_hypergraph_statistics_density():
    """Test density calculation."""
    # Full bipartite: each node connects to each hyperedge
    hyperedge_index = torch.tensor(
        [
            [0, 0, 1, 1, 2, 2],  # nodes
            [0, 1, 0, 1, 0, 1],  # hyperedges
        ]
    )
    data = HyperData(hyperedge_index=hyperedge_index)
    data.num_nodes = 3

    stats = compute_hypergraph_statistics(data)

    assert stats["num_nodes"] == 3
    assert stats["num_hyperedges"] == 2
    assert stats["num_connections"] == 6
    # Density = 6 / (3 * 2) = 1.0 (fully connected)
    assert abs(stats["density"] - 1.0) < 1e-6
