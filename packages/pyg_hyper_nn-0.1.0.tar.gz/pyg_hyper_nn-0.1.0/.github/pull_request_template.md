## 📝 Description

<!-- Provide a clear and concise description of your changes -->

## 🔗 Related Issue

<!-- Link to the related issue(s) -->

Closes #<!-- Issue number -->

## 🎯 Type of Change

<!-- Check all that apply -->

- [ ] 🐛 Bug fix (non-breaking change that fixes an issue)
- [ ] ✨ New feature (non-breaking change that adds functionality)
- [ ] 🧠 New model implementation
- [ ] 🔧 Layer/component enhancement
- [ ] ⚡ Performance improvement
- [ ] 📝 Documentation update
- [ ] ♻️ Code refactoring (no functional changes)
- [ ] 🎨 Style/formatting changes
- [ ] 🧪 Test additions or updates
- [ ] 🔨 Build/CI/CD changes
- [ ] 💥 Breaking change (fix or feature that would cause existing functionality to change)

## 📋 Changes Made

<!-- Detailed description of changes -->

### Modified Files
- `path/to/file.py`: Description of changes

### New Files
- `path/to/new/file.py`: Description of new file

### Deleted Files
- `path/to/deleted/file.py`: Reason for deletion

## 🧠 Model Implementation Details (if applicable)

<!-- For new model implementations -->

- **Model Name**:
- **Paper Reference**:
- **Key Features**:
  - Feature 1
  - Feature 2
- **API Example**:
```python
from pyg_hyper_nn.models import NewModel

model = NewModel(
    in_channels=16,
    hidden_channels=32,
    out_channels=7,
    num_layers=2,
)
out = model(x, hyperedge_index)
```

## 🧪 Testing

<!-- Describe the tests you ran and their results -->

### Test Coverage
```bash
# Run tests
uv run pytest tests/ -v

# Check coverage
uv run pytest --cov=src --cov-report=term
```

### Test Results
- [ ] All existing tests pass
- [ ] New tests added for new functionality
- [ ] Test coverage maintained or improved

### Quality Checks
```bash
# Code quality
uv run ruff check src/ tests/
uv run ty check src/

# Formatting
uv run ruff format src/ tests/
```

- [ ] Ruff linting passes
- [ ] Ty type checking passes
- [ ] Code is properly formatted

## 📊 Performance Impact (if applicable)

<!-- Describe any performance implications -->

### Benchmarks
```python
# Before: X seconds
# After: Y seconds
# Improvement: Z%
```

## 💥 Breaking Changes

<!-- Describe any breaking changes and migration path -->

- [ ] Yes (describe below)
- [ ] No

### Breaking Change Details
<!-- If yes, describe:
- What changed
- Why it was necessary
- How users should migrate
-->

## 🖼️ Screenshots (if applicable)

<!-- Add screenshots for UI changes or visual output differences -->

## ✅ Checklist

### Code Quality
- [ ] Code follows project style guidelines
- [ ] Self-review completed
- [ ] Comments added for complex logic
- [ ] No unnecessary console.log / debug statements

### Testing
- [ ] Unit tests added/updated
- [ ] All tests pass locally
- [ ] Test coverage maintained or improved
- [ ] Edge cases covered

### Type Safety
- [ ] All functions have type annotations
- [ ] Ty type checking passes
- [ ] No `type: ignore` comments without justification

### Documentation
- [ ] README updated (if needed)
- [ ] Docstrings added/updated
- [ ] Code examples provided
- [ ] API documentation updated

### Model Implementation (if applicable)
- [ ] Model follows standard interface (`forward`, `reset_parameters`)
- [ ] Paper reference included in docstring
- [ ] Gradient flow tested
- [ ] Model added to `models/__init__.py`
- [ ] Tests created in `tests/test_models/`

### Compatibility
- [ ] Changes are backwards compatible
- [ ] No breaking changes (or documented)
- [ ] Works with Python 3.12+
- [ ] Works with PyTorch 2.8+
- [ ] Works with PyG 2.6+

## 📚 Additional Context

<!-- Any additional information for reviewers -->

### Review Focus
<!-- Specific areas you'd like reviewers to focus on -->
-

### Open Questions
<!-- Any questions or concerns for discussion -->
-

### Future Work
<!-- Related work that could be done in future PRs -->
-

---

**Thank you for contributing to pyg-hyper-nn!** 🙏
