# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

PyG-Hyper-NN is a PyTorch Geometric-based hypergraph neural networks library implementing 26+ state-of-the-art models from research papers. The library prioritizes **research integrity** by maintaining faithful implementations of official model logic from [DHG-Bench](https://github.com/Coco-Hut/DHG-Bench).

**Critical**: All model implementations must preserve the exact mathematical operations and algorithmic logic from the original papers and official implementations. Never simplify or create "fake" implementations—this constitutes research fraud if used in academic papers.

## Development Commands

### Testing
```bash
# Run all tests (373 tests)
uv run pytest tests/ -v

# Run specific test suite
uv run pytest tests/test_models/test_basic.py -v
uv run pytest tests/test_layers/test_conv.py -v

# Run single test
uv run pytest tests/test_models/test_basic.py::test_hgnn_forward -v

# Run with coverage
uv run pytest tests/ --cov=src --cov-report=html

# Quick run without verbose output
uv run pytest tests/ -v --tb=no -q
```

### Code Quality
```bash
# Linting (must pass with ALL rules enabled)
uv run ruff check src/ tests/

# Auto-fix linting issues
uv run ruff check --fix src/ tests/

# Ignore PERF401 for list comprehensions in loops (project standard)
uv run ruff check src/ tests/ --ignore PERF401

# Type checking (must pass for src/)
uv run ty check src/

# Formatting
uv run ruff format src/ tests/
```

### Dependencies
```bash
# Add runtime dependency
uv add <package-name>

# Add dev dependency
uv add --dev <package-name>

# Update lockfile
uv lock --upgrade
```

## Architecture

### Two-Layer Design: `layers/` + `models/`

The codebase follows a strict separation between reusable components and complete models:

**`src/pyg_hyper_nn/layers/`** - Atomic building blocks:
- `conv.py`: HypergraphConv (supports both symdegnorm=True/False for HGNN/HCHA)
- `attention.py`: PMA (Pooling by Multihead Attention) for AllSet
- `mlp.py`: Reusable MLP blocks with configurable normalization
- `kernelized_attention.py`: O(N) complexity attention for HyperGT
- `sparse_linear.py`: Linear layers for sparse tensors (positional encodings)
- `preprocessing.py`: Incidence matrix construction, clique expansion
- `nodeformer_conv.py`: NodeFormer convolution for HyperGT
- `sheaf_builder.py`: Diagonal sheaf builder for SheafHyperGNN
- `sheaf_conv.py`: Hypergraph diffusion with diagonal sheaf structures
- `sheaf_utils.py`: Batched matrix power, sparse diagonal operations
- `hjrl_utils.py`: 4 propagation paths (HHT, H, HT, HTH) for HJRL
- `legcn_utils.py`: Line expansion for LEGCN
- `unigencoder_utils.py`: Pooling matrix computation with cosine similarity grouping
- `tmphn_utils.py`: Neighbor dictionary construction (foundation for TMPHN)
- `utils.py`: Parameter initialization (glorot, zeros, normalize_l2, SparseMM)

**`src/pyg_hyper_nn/models/`** - Complete end-to-end models:
- Each model is self-contained with forward pass, parameter initialization, and reset logic
- All models share the standardized interface (see below)

### Critical Implementation Rules

1. **No `args` Dependencies**: DHG-Bench models depend on ArgumentParser `args` objects. We extract these as explicit parameters:
   ```python
   # DHG-Bench (WRONG for this library)
   def __init__(self, args, in_channels, out_channels):
       self.use_norm = args.use_norm

   # pyg-hyper-nn (CORRECT)
   def __init__(self, in_channels: int, out_channels: int, use_norm: bool = False):
       self.use_norm = use_norm
   ```

2. **Preserve Original Logic**: When porting from DHG-Bench, preserve the exact mathematical operations:
   - HCHA uses `symdegnorm=False` (asymmetric normalization)
   - HGNN uses `symdegnorm=True` (symmetric normalization)
   - TFHNN's final power iteration term has no alpha multiplier
   - UniGCNII applies identity mapping with adaptive beta: `beta = log(lambda/(i+1) + 1)`

3. **Type Annotations**: All public APIs must have complete type annotations checked by `ty`:
   ```python
   def forward(
       self,
       x: Tensor,
       hyperedge_index: Tensor,
       hyperedge_weight: Optional[Tensor] = None,
   ) -> Tensor:
   ```

4. **Hyperedge Index Format**: COO format with shape `(2, num_edges)`:
   - `hyperedge_index[0]`: node indices
   - `hyperedge_index[1]`: hyperedge indices

### Standardized Model Interface

Every model must implement this interface:

```python
class ModelName(nn.Module):
    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        dropout: float = 0.5,
        **kwargs,  # Model-specific parameters
    ):
        super().__init__()
        # Store parameters as instance variables
        self.in_channels = in_channels
        ...

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        for conv in self.convs:
            conv.reset_parameters()

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,
    ) -> Tensor:
        """Forward pass returning (num_nodes, out_channels)."""
        ...
        return x

    def __repr__(self) -> str:
        """String representation for debugging."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers})"
        )
```

### Testing Requirements

When implementing a new model, create comprehensive tests in `tests/test_models/`:

```python
def test_model_forward():
    """Test basic forward pass with correct output shape."""
    model = ModelName(16, 32, 7, num_layers=2)
    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
    out = model(x, hyperedge_index)
    assert out.shape == (100, 7)

def test_model_gradient_flow():
    """Test gradient flow through the model."""
    model = ModelName(16, 32, 7, num_layers=2)
    x = torch.randn(100, 16, requires_grad=True)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    out = model(x, hyperedge_index)
    loss = out.sum()
    loss.backward()
    assert x.grad is not None

def test_model_single_layer():
    """Test model with num_layers=1 edge case."""
    model = ModelName(16, 32, 7, num_layers=1)
    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    out = model(x, hyperedge_index)
    assert out.shape == (100, 7)
```

## Model Verification Checklist

Before considering a model implementation complete:

1. **Compare with Official Implementation**: Read the official DHG-Bench implementation line-by-line and verify:
   - All mathematical operations match exactly
   - Parameter initialization follows the same logic
   - Forward pass computation order is identical
   - Special cases (e.g., empty hypergraphs) are handled

2. **Check Key Differences**:
   - HGNN vs HCHA: `symdegnorm=True` vs `symdegnorm=False`
   - UniGNN vs UniGCNII: GCNII adds initial residual + identity mapping
   - Power iteration models: Check if final term has alpha multiplier

3. **Test Coverage**:
   - Forward pass with different `num_layers` (1, 2, 5)
   - Gradient flow verification
   - Edge cases (empty hypergraph, single node, single hyperedge)
   - Device compatibility (CPU/CUDA if available)

4. **Quality Checks**:
   - `uv run pytest tests/ -v` → All tests pass
   - `uv run ruff check src/ tests/ --ignore PERF401` → No linting errors
   - `uv run ty check src/` → No type errors

## Common Patterns

### ModuleList Type Annotations

When using `nn.ModuleList`, add type ignores for union-attr and arg-type warnings:

```python
def reset_parameters(self) -> None:
    for conv in self.convs:
        conv.reset_parameters()  # type: ignore[union-attr]

for i, conv in enumerate(self.convs[:-1]):  # type: ignore[arg-type]
    x = conv(x, edge_index)
```

### Caching for Inference

For expensive preprocessing (clique expansion, incidence matrices), use buffers with training-aware cache invalidation:

```python
def __init__(self, ...):
    super().__init__()
    self.register_buffer("_cache", None, persistent=False)

def forward(self, x, hyperedge_index):
    if self.training:
        self._cache = None

    if self._cache is None:
        self._cache = expensive_preprocessing(hyperedge_index)

    return self.decoder(self._cache)
```

### Sparse Tensor Operations

For hypergraph incidence matrices and weighted clique expansion:

```python
# Create sparse COO tensor
indices = torch.stack([row_indices, col_indices])
values = torch.ones(num_edges, dtype=torch.float32, device=device)
H = torch.sparse_coo_tensor(indices, values, (num_nodes, num_hyperedges))

# Coalesce before operations
H = H.coalesce()

# Sparse matrix multiplication
result = torch.sparse.mm(H, dense_matrix)
```

## Project Status

**Current**: 19/26 models implemented

**Implemented models** (19):
- Basic: MLP, HGNN, HCHA, UniGNN, UniGCNII
- Set-based: AllSet, EquivSetGNN
- Diffusion: TFHNN, HyperND
- Phenomenological: PhenomNN, PhenomNNS
- Graph Expansion: CEGCN, CEGAT, HyperGCN, LEGCN
- Transformers: HyperGT
- Degree-based: HNHN, HJRL
- Advanced: SheafHyperGNN, PlainUnigencoder

**All tests passing**: 373/373 ✅

**Remaining models** (7/26) - **Implementation Status: Extremely Difficult**

The remaining 7 models are currently marked as "Coming Soon" but present significant implementation challenges:

1. **TMPHN** (Tensor Message Passing Hypergraph Network)
   - Requires custom `neig_dict` structure (neighbor dictionary)
   - Uses lambda functions to dynamically construct encoder stacks
   - Complex permutation/combination calculations for high-order message passing
   - Depends on `nn.Embedding` for feature storage
   - **Status**: Utility function `build_neighbor_dict()` implemented (6 tests passing)

2. **DPHGNN** (Dynamic Pooling HyperGNN)
   - Requires TAA (Topology-Aware Attention) with multiple graph expansions
   - Needs 3 different graph types: Clique Graph (CG), HyperGCN Graph (HG), Star Graph (SG)
   - Requires spectral layers with eigenvalue decomposition
   - Depends on custom data: A_cg, A_hyp, A_sg, L_hyp, L_cg, L_sg
   - **Complexity**: 519 lines with multiple specialized submodules

3. **EHNN Family** (Equivariant Hypergraph Neural Networks)
   - **EHNN** (235 lines): Main wrapper class
   - **EHNN_linear** (380 lines): Linear variant with hypernetwork
   - **EHNN_transformer** (675 lines): Transformer variant
   - Requires hypernetwork (dynamic weight generation)
   - Depends on `ehnn_cache` special data structure
   - 20+ args parameters (pe_dim, hyper_dim, force_broadcast, etc.)
   - **Total complexity**: 1,290 lines

**Why these models are difficult to implement**:

All remaining models share common barriers to standard PyG integration:

1. **Special Data Structures**: Require preprocessing beyond `hyperedge_index`:
   - TMPHN: `neig_dict` (dict mapping nodes to edge lists)
   - DPHGNN: Multiple adjacency/Laplacian matrices for different graph types
   - EHNN: `ehnn_cache` with edge orders, overlaps, incidence matrices

2. **Non-standard Interfaces**: Cannot be expressed with standard `forward(x, hyperedge_index)`:
   - TMPHN: Requires `target_idx` for selective node processing
   - DPHGNN: Needs pre-computed graph expansions
   - EHNN: Requires hypernet_info tuple and positional encodings

3. **Complex Dependencies**: Require specialized submodules:
   - TMPHN: Factorial permutation calculations
   - DPHGNN: TAA (spatial + spectral attention), ExpanNet, SmoothNet
   - EHNN: MLP_inner hypernetworks, separate V2E and E2V layers

4. **args Object Dependency**: Original implementations use 20+ ArgumentParser parameters that are deeply integrated into the model logic

**Potential Solutions** (for future consideration):

1. **Extended Interface**: Design a new interface supporting special data structures
2. **Preprocessing Library**: Create companion preprocessing functions for each model
3. **Simplified Variants**: Implement core functionality without advanced features
4. **Documentation**: Clearly document implementation challenges and DHG-Bench dependencies

## Implementation Highlights

### Complex Models Successfully Implemented

1. **SheafHyperGNN**: Sheaf-theoretic learning with CP decomposition
   - 4 normalization types (0, 1, 2, 3)
   - Diagonal restriction maps
   - Dynamic/static sheaf support
   - clear_flag option for inference

2. **HyperGT**: Graph Transformer with kernelized attention
   - O(N) complexity using random Fourier features
   - HEPE and HtEPE positional encodings
   - NodeFormer-style message passing

3. **PhenomNN/PhenomNNS**: Phenomenological modeling
   - Multi-scale iterative propagation
   - Two normalization schemes (node-level + full hypergraph)
   - Alpha decay scheduling

4. **HJRL**: Joint node-edge representation learning
   - 4 distinct propagation paths (HHT, H, HT, HTH)
   - Complex incidence matrix operations

5. **PlainUnigencoder**: MLP with group pooling
   - Cosine similarity-based node grouping
   - 3 threshold modes and 5 normalization types
   - 220+ lines of preprocessing logic accurately ported

### Testing Philosophy

**Every function and method is thoroughly tested**:
- 373 tests covering all models and utilities
- Each complex preprocessing function has 6-10 dedicated tests
- Edge cases: empty hypergraphs, single nodes, varying cardinalities
- Gradient flow verification for all models
- Device compatibility (CPU/CUDA)

### Code Quality Standards

**100% pass rate on all quality checks**:
- ✅ Ruff linting with ALL rules enabled (no ignored errors)
- ✅ Ty type checking for all source code
- ✅ Full type annotations on public APIs
- ✅ Comprehensive docstrings with examples

## Related Projects

- **pyg-hyper-data**: Sibling dataset library (located at `/home/nishide.21066/projects/pyg-hyper-data`)
- **DHG-Bench**: Official implementations source (`/home/nishide.21066/projects/pyg-hyper-data/_tmp/repo/DHG-Bench`)
