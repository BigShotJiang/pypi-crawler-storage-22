# Contributing to PyG-Hyper-NN

Thank you for your interest in contributing to PyG-Hyper-NN! This document provides guidelines and instructions for contributing.

## 🎯 Ways to Contribute

### 1. Model Implementation
Implement new hypergraph neural network models from research papers.

**Priority Models**:
- UniGCNII (extends UniGNN)
- AllSet (Transformers for hypergraphs)
- HyperGT (Graph Transformer)
- CEGCN/CEGAT (Clique expansion)
- EquivSetGNN (Equivariant DeepSets)

### 2. Bug Fixes
Fix bugs in existing models or infrastructure.

### 3. Documentation
Improve documentation, add examples, or create tutorials.

### 4. Testing
Add test cases, improve coverage, or create benchmarks.

### 5. Performance Optimization
Optimize existing models for speed or memory efficiency.

## 🚀 Getting Started

### 1. Fork and Clone

```bash
# Fork the repository on GitHub, then clone your fork
git clone https://github.com/YOUR_USERNAME/pyg-hyper-nn.git
cd pyg-hyper-nn

# Add upstream remote
git remote add upstream https://github.com/nishide-dev/pyg-hyper-nn.git
```

### 2. Set Up Development Environment

```bash
# Install dependencies
uv sync

# Verify installation
uv run python -c "from pyg_hyper_nn.models import HGNN; print('✅ Setup complete!')"
```

### 3. Create a Branch

```bash
# Update your main branch
git checkout main
git pull upstream main

# Create a feature branch
git checkout -b feature/your-feature-name
```

## 💻 Development Workflow

### 1. Make Your Changes

Follow the [Code Style Guidelines](#code-style-guidelines) below.

### 2. Run Tests

```bash
# Run all tests
uv run pytest tests/ -v

# Run specific test file
uv run pytest tests/test_models/test_basic.py -v

# Check coverage
uv run pytest --cov=src --cov-report=term
```

### 3. Check Code Quality

```bash
# Lint code
uv run ruff check src/ tests/

# Auto-fix issues
uv run ruff check --fix src/ tests/

# Format code
uv run ruff format src/ tests/

# Type check
uv run ty check src/
```

### 4. Commit Your Changes

```bash
git add .
git commit -m "feat: add UniGCNII model implementation"
```

**Commit Message Format**:
```
<type>: <description>

[optional body]

[optional footer]
```

**Types**:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation only
- `style`: Formatting changes
- `refactor`: Code refactoring
- `perf`: Performance improvement
- `test`: Adding tests
- `chore`: Maintenance tasks

### 5. Push and Create Pull Request

```bash
git push origin feature/your-feature-name
```

Then create a pull request on GitHub.

## 📐 Code Style Guidelines

### General Principles
1. **Clean and Readable**: Code should be self-explanatory
2. **Type Annotated**: All functions must have type hints
3. **Well Documented**: Docstrings for all public APIs
4. **Tested**: All new code must include tests

### Python Style
- **Line Length**: 88 characters (Ruff default)
- **Imports**: Sorted and organized
- **Type Hints**: Required for all functions
- **Docstrings**: Google style

### Example

```python
"""Module description.

Brief description of the module's purpose.
"""

from typing import Optional

import torch
from torch import Tensor, nn


class ExampleModel(nn.Module):
    """Example model for hypergraph node classification.

    Based on "Paper Title" (Author et al., Conference Year).

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features.
        out_channels: Number of output classes.
        num_layers: Number of convolution layers.
        dropout: Dropout probability. Default: 0.5.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        dropout: float = 0.5,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.dropout = dropout

        # Build layers
        self.convs = nn.ModuleList()
        # ... implementation

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        for conv in self.convs:
            conv.reset_parameters()

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights of shape (num_hyperedges,).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        # Implementation
        return x

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers})"
        )
```

## 🧠 Implementing a New Model

### 1. Study the Paper

- Read the original paper thoroughly
- Understand the architecture and key innovations
- Note any special requirements (preprocessing, data structures)

### 2. Check Existing Implementations

- DHG-Bench: `https://github.com/Coco-Hut/DHG-Bench`
- Original repository (if available)
- Other PyTorch implementations

### 3. Create the Model File

```bash
# Create model file
touch src/pyg_hyper_nn/models/your_model.py
```

### 4. Implement the Model

Follow the standard interface:

```python
class YourModel(nn.Module):
    """Your model description.

    Based on "Paper Title" (Authors, Conference Year).
    Paper: https://arxiv.org/abs/...

    Args:
        in_channels: Size of input features.
        hidden_channels: Size of hidden features.
        out_channels: Number of output classes.
        num_layers: Number of layers.
        dropout: Dropout probability. Default: 0.5.
        **kwargs: Model-specific parameters.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        dropout: float = 0.5,
        **kwargs,
    ):
        super().__init__()
        # Store parameters
        # Build layers

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        pass

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,
    ) -> Tensor:
        """Forward pass."""
        pass

    def __repr__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}(...)"
```

### 5. Add to Exports

```python
# src/pyg_hyper_nn/models/__init__.py
from pyg_hyper_nn.models.your_model import YourModel

__all__ = [
    # ... existing models
    "YourModel",
]
```

### 6. Write Tests

```python
# tests/test_models/test_your_model.py
import torch
from pyg_hyper_nn.models import YourModel


def test_your_model_forward():
    """Test forward pass."""
    model = YourModel(16, 32, 7, num_layers=2)
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_your_model_gradient_flow():
    """Test gradient flow."""
    model = YourModel(16, 32, 7, num_layers=2)
    x = torch.randn(100, 16, requires_grad=True)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None


def test_your_model_reset_parameters():
    """Test parameter reset."""
    model = YourModel(16, 32, 7, num_layers=2)
    model.reset_parameters()

    # Verify model can still do forward pass
    x = torch.randn(10, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    out = model(x, edge_index)

    assert out.shape[0] == 10
```

### 7. Run Quality Checks

```bash
# Run tests
uv run pytest tests/test_models/test_your_model.py -v

# Check code quality
uv run ruff check src/ tests/
uv run ty check src/
```

### 8. Update Documentation

Add your model to:
- `README.md` (Available Models section)
- `docs/models.md` (if exists)

## 🧪 Testing Guidelines

### Test Coverage Requirements
- **Minimum**: 80% code coverage
- **Critical paths**: 100% coverage
- **Edge cases**: Well covered

### Test Types

#### 1. Unit Tests
Test individual components in isolation.

```python
def test_layer_forward():
    """Test layer forward pass."""
    layer = YourLayer(16, 32)
    x = torch.randn(10, 16)
    out = layer(x)
    assert out.shape == (10, 32)
```

#### 2. Integration Tests
Test model end-to-end.

```python
def test_model_training():
    """Test model training loop."""
    model = YourModel(16, 32, 7, num_layers=2)
    optimizer = torch.optim.Adam(model.parameters())

    x = torch.randn(100, 16)
    y = torch.randint(0, 7, (100,))
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # Training step
    model.train()
    out = model(x, edge_index)
    loss = F.cross_entropy(out, y)
    loss.backward()
    optimizer.step()

    assert loss.item() >= 0
```

#### 3. Edge Case Tests
Test boundary conditions.

```python
def test_model_single_node():
    """Test model with single node."""
    model = YourModel(16, 32, 7, num_layers=2)
    x = torch.randn(1, 16)
    edge_index = torch.tensor([[0], [0]])

    out = model(x, edge_index)
    assert out.shape == (1, 7)


def test_model_empty_edges():
    """Test model with no edges."""
    model = YourModel(16, 32, 7, num_layers=2)
    x = torch.randn(10, 16)
    edge_index = torch.tensor([[], []]).long()

    out = model(x, edge_index)
    assert out.shape == (10, 7)
```

## 📝 Documentation Guidelines

### Docstring Format

Use Google style docstrings:

```python
def function(arg1: int, arg2: str) -> bool:
    """Short description (one line).

    Longer description providing more details about the function,
    its purpose, and any important notes.

    Args:
        arg1: Description of arg1.
        arg2: Description of arg2.

    Returns:
        Description of return value.

    Raises:
        ValueError: When input is invalid.

    Example:
        >>> result = function(42, "test")
        >>> print(result)
        True
    """
    pass
```

### README Updates

When adding a model:
1. Add to "Implemented Models" table
2. Include paper reference and link
3. Add to model count (e.g., "4/26 Complete")

## 🤝 Pull Request Guidelines

### Before Submitting

- [ ] All tests pass
- [ ] Code quality checks pass (ruff + ty)
- [ ] Documentation updated
- [ ] Commit messages follow conventions
- [ ] Branch is up to date with main

### PR Description

Include:
1. **Clear description** of changes
2. **Related issue** (if applicable)
3. **Test results** showing all checks pass
4. **Model details** (for new models)
5. **Breaking changes** (if any)

### Review Process

1. Automated checks must pass (CI/CD)
2. Code review by maintainers
3. Address review comments
4. Final approval and merge

## 🐛 Reporting Bugs

### Before Reporting

1. Search existing issues
2. Test with latest version
3. Create minimal reproducible example

### Bug Report Template

Use the bug report template when creating an issue. Include:
- **Description**: What's wrong?
- **Reproduction**: Minimal code to reproduce
- **Expected**: What should happen?
- **Actual**: What actually happens?
- **Environment**: Versions and system info

## 💡 Requesting Features

### Feature Request Template

Use the feature request template. Include:
- **Problem**: What needs to be solved?
- **Solution**: How should it be implemented?
- **Alternatives**: Other approaches considered?
- **References**: Papers, implementations, etc.

### Model Request Template

Use the model request template for new models. Include:
- **Model name** and paper reference
- **Description** and key features
- **Priority** and complexity
- **Dependencies** and requirements

## 📞 Getting Help

- **Discussions**: [GitHub Discussions](https://github.com/nishide-dev/pyg-hyper-nn/discussions)
- **Issues**: [GitHub Issues](https://github.com/nishide-dev/pyg-hyper-nn/issues)
- **Email**: nishide.dev@gmail.com

## 📜 Code of Conduct

- Be respectful and inclusive
- Provide constructive feedback
- Focus on what is best for the community
- Show empathy towards others

## 📄 License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

**Thank you for contributing to PyG-Hyper-NN!** 🙏
