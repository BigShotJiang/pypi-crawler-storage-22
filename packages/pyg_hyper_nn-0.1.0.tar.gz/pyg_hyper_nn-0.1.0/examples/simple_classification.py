"""Simple node classification example with multiple models.

This script demonstrates how to use different hypergraph neural network models
from pyg-hyper-nn for node classification tasks.
"""

import torch
import torch.nn.functional as F
from torch.optim import Adam

from pyg_hyper_nn.models import CEGCN, HGNN, MLP, AllSet, EquivSetGNN, UniGNN


def create_synthetic_hypergraph(
    num_nodes: int = 100,
    num_features: int = 16,
    num_classes: int = 7,
    num_hyperedges: int = 30,
    device: str = "cpu",
):
    """Create a synthetic hypergraph for demonstration.

    Args:
        num_nodes: Number of nodes in the hypergraph.
        num_features: Dimension of node features.
        num_classes: Number of classes for classification.
        num_hyperedges: Number of hyperedges.
        device: Device to place tensors on.

    Returns:
        Tuple of (x, hyperedge_index, y, train_mask, test_mask)
    """
    # Random node features
    x = torch.randn(num_nodes, num_features, device=device)

    # Create random hyperedges
    node_indices = []
    edge_indices = []

    for e_idx in range(num_hyperedges):
        # Random hyperedge size between 2 and 5
        edge_size = torch.randint(2, 6, (1,)).item()
        # Random nodes in this hyperedge
        nodes = torch.randperm(num_nodes)[:edge_size]

        for node in nodes:
            node_indices.append(node.item())
            edge_indices.append(e_idx)

    hyperedge_index = torch.tensor(
        [node_indices, edge_indices], dtype=torch.long, device=device
    )

    # Random labels
    y = torch.randint(0, num_classes, (num_nodes,), device=device)

    # Train/test split
    perm = torch.randperm(num_nodes)
    train_mask = torch.zeros(num_nodes, dtype=torch.bool, device=device)
    test_mask = torch.zeros(num_nodes, dtype=torch.bool, device=device)

    train_mask[perm[: num_nodes // 2]] = True
    test_mask[perm[num_nodes // 2 :]] = True

    return x, hyperedge_index, y, train_mask, test_mask


def train_model(
    model,
    x,
    hyperedge_index,
    y,
    train_mask,
    test_mask,
    epochs: int = 100,
    lr: float = 0.01,
    weight_decay: float = 5e-4,
):
    """Train a hypergraph neural network model.

    Args:
        model: The model to train.
        x: Node feature matrix.
        hyperedge_index: Hyperedge indices.
        y: Node labels.
        train_mask: Training node mask.
        test_mask: Test node mask.
        epochs: Number of training epochs.
        lr: Learning rate.
        weight_decay: Weight decay for regularization.

    Returns:
        Tuple of (train_accuracy, test_accuracy)
    """
    optimizer = Adam(model.parameters(), lr=lr, weight_decay=weight_decay)

    model.train()
    for epoch in range(epochs):
        optimizer.zero_grad()

        # Forward pass
        if isinstance(model, MLP):
            out = model(x)
        else:
            out = model(x, hyperedge_index)

        loss = F.cross_entropy(out[train_mask], y[train_mask])

        # Backward pass
        loss.backward()
        optimizer.step()

        if epoch % 20 == 0:
            print(f"  Epoch {epoch:3d} | Loss: {loss.item():.4f}")

    # Evaluation
    model.eval()
    with torch.no_grad():
        if isinstance(model, MLP):
            out = model(x)
        else:
            out = model(x, hyperedge_index)

        pred = out.argmax(dim=1)

        train_acc = (pred[train_mask] == y[train_mask]).float().mean().item()
        test_acc = (pred[test_mask] == y[test_mask]).float().mean().item()

    return train_acc, test_acc


def main():
    """Run simple classification example with multiple models."""
    print("=" * 60)
    print("PyG-Hyper-NN: Simple Node Classification Example")
    print("=" * 60)

    # Set device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\nDevice: {device}")

    # Create synthetic hypergraph
    print("\nCreating synthetic hypergraph...")
    x, hyperedge_index, y, train_mask, test_mask = create_synthetic_hypergraph(
        num_nodes=100,
        num_features=16,
        num_classes=7,
        num_hyperedges=30,
        device=str(device),
    )
    print(
        f"  Nodes: {x.shape[0]}, Features: {x.shape[1]}, Classes: {y.max().item() + 1}"
    )
    print(
        f"  Hyperedges: {hyperedge_index[1].max().item() + 1}, Connections: {hyperedge_index.shape[1]}"
    )

    # Model configurations
    models_to_test = [
        ("MLP", MLP(16, 32, 7, num_layers=2)),
        ("HGNN", HGNN(16, 32, 7, num_layers=2)),
        ("UniGNN", UniGNN(16, 32, 7, num_layers=2)),
        ("AllSet", AllSet(16, 32, 7, num_layers=2)),
        ("EquivSetGNN", EquivSetGNN(16, 32, 7, num_layers=2)),
        ("CEGCN", CEGCN(16, 32, 7, num_layers=2)),
    ]

    # Train and evaluate each model
    print("\n" + "=" * 60)
    print("Training Models")
    print("=" * 60)

    results = []

    for name, model in models_to_test:
        print(f"\n{name}:")
        print("-" * 40)

        model = model.to(device)

        train_acc, test_acc = train_model(
            model, x, hyperedge_index, y, train_mask, test_mask, epochs=100
        )

        results.append((name, train_acc, test_acc))

        print(f"  Train Accuracy: {train_acc:.4f}")
        print(f"  Test Accuracy:  {test_acc:.4f}")

    # Summary
    print("\n" + "=" * 60)
    print("Results Summary")
    print("=" * 60)
    print(f"{'Model':<15} {'Train Acc':<12} {'Test Acc':<12}")
    print("-" * 60)

    for name, train_acc, test_acc in results:
        print(f"{name:<15} {train_acc:>11.4f} {test_acc:>11.4f}")

    print("=" * 60)


if __name__ == "__main__":
    main()
