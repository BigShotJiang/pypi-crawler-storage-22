"""A PyTorch/CUDA deep learning project."""

__version__ = "0.1.0"


def hello() -> str:
    """Return a greeting message.

    Returns:
        A friendly greeting string.
    """
    return "Hello from pyg-hyper-nn!"


def check_cuda() -> dict[str, bool | str | int]:
    """Check CUDA availability and device information.

    Returns:
        Dictionary containing CUDA status information.
    """
    try:
        import torch

        return {
            "cuda_available": torch.cuda.is_available(),
            "cuda_version": torch.version.cuda or "N/A"  # type: ignore[attr-defined]
            if torch.cuda.is_available()
            else "N/A",
            "device_count": torch.cuda.device_count()
            if torch.cuda.is_available()
            else 0,
            "device_name": (
                torch.cuda.get_device_name(0)
                if torch.cuda.is_available() and torch.cuda.device_count() > 0
                else "N/A"
            ),
        }
    except ImportError:
        return {
            "cuda_available": False,
            "cuda_version": "PyTorch not installed",
            "device_count": 0,
            "device_name": "N/A",
        }
