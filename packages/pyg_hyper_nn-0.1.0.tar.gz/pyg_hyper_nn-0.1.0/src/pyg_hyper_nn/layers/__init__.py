"""Layer modules for hypergraph neural networks."""

from pyg_hyper_nn.layers.attention import PMA
from pyg_hyper_nn.layers.conv import HypergraphConv
from pyg_hyper_nn.layers.kernelized_attention import (
    create_projection_matrix,
    kernelized_softmax,
    softmax_kernel_transformation,
)
from pyg_hyper_nn.layers.mlp import MLP
from pyg_hyper_nn.layers.nodeformer_conv import NodeFormerConv
from pyg_hyper_nn.layers.preprocessing import (
    clique_expansion,
    construct_incidence_matrix,
)
from pyg_hyper_nn.layers.sheaf_builder import SheafBuilderDiag
from pyg_hyper_nn.layers.sheaf_conv import (
    HyperDiffusionDiagSheafConv,
    normalisation_matrices,
)
from pyg_hyper_nn.layers.sheaf_utils import (
    batched_sym_matrix_pow,
    generate_indices_general,
    sparse_diagonal,
)
from pyg_hyper_nn.layers.sparse_linear import SparseLinear
from pyg_hyper_nn.layers.unigencoder_utils import (
    build_edge_dict,
    compute_pooling_matrices,
    count_node_edges,
)
from pyg_hyper_nn.layers.utils import SparseMM, glorot, normalize_l2, zeros

__all__ = [
    "MLP",
    "PMA",
    "HyperDiffusionDiagSheafConv",
    "HypergraphConv",
    "NodeFormerConv",
    "SheafBuilderDiag",
    "SparseLinear",
    "SparseMM",
    "batched_sym_matrix_pow",
    "build_edge_dict",
    "clique_expansion",
    "compute_pooling_matrices",
    "construct_incidence_matrix",
    "count_node_edges",
    "create_projection_matrix",
    "generate_indices_general",
    "glorot",
    "kernelized_softmax",
    "normalisation_matrices",
    "normalize_l2",
    "softmax_kernel_transformation",
    "sparse_diagonal",
    "zeros",
]
