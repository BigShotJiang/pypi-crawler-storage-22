"""Attention mechanisms for hypergraph neural networks."""

from typing import Optional

import torch
from torch import Tensor, nn
from torch.nn import functional as functional_F
from torch_geometric.nn.conv import MessagePassing
from torch_geometric.typing import Adj, OptTensor, Size
from torch_geometric.utils import softmax
from torch_scatter import scatter

from pyg_hyper_nn.layers.mlp import MLP
from pyg_hyper_nn.layers.utils import glorot


class PMA(MessagePassing):
    """Pooling by Multihead Attention layer.

    Implements the PMA mechanism from "Set Transformer: A Framework for
    Attention-based Permutation-Invariant Neural Networks" (Lee et al., ICML 2019).

    This layer uses multi-head attention with learnable seed vectors to aggregate
    node features in hypergraphs. It combines attention-based pooling with a
    feed-forward network and layer normalization.

    Args:
        in_channels: Size of input features.
        hidden_dim: Size of hidden dimension (will be divided by heads).
        out_channels: Size of output features.
        num_layers: Number of MLP layers in the feed-forward network.
        heads: Number of attention heads. Default: 1.
        concat: If True, concatenate attention heads. Otherwise average.
            Default: True.
        negative_slope: LeakyReLU angle of negative slope. Default: 0.2.
        dropout: Dropout probability. Default: 0.0.
        bias: If True, adds a learnable bias. Default: False.
        **kwargs: Additional arguments for MessagePassing parent class.
    """

    _alpha: OptTensor

    def __init__(
        self,
        in_channels: int,
        hidden_dim: int,
        out_channels: int,
        num_layers: int,
        heads: int = 1,
        concat: bool = True,
        negative_slope: float = 0.2,
        dropout: float = 0.0,
        bias: bool = False,  # noqa: ARG002
        **kwargs,
    ):
        super().__init__(node_dim=0, **kwargs)

        self.in_channels = in_channels
        self.hidden = hidden_dim // heads
        self.out_channels = out_channels
        self.heads = heads
        self.concat = concat
        self.negative_slope = negative_slope
        self.dropout = dropout
        self.aggr = "add"

        # Key and Value transformations
        self.lin_K = nn.Linear(in_channels, self.heads * self.hidden)
        self.lin_V = nn.Linear(in_channels, self.heads * self.hidden)

        # Learnable seed vector for attention
        self.att_r = nn.Parameter(torch.empty(1, heads, self.hidden))

        # Feed-forward network (maintains dimension for skip connection)
        self.rFF = MLP(
            in_channels=self.heads * self.hidden,
            hidden_channels=self.heads * self.hidden,
            out_channels=self.heads * self.hidden,
            num_layers=num_layers,
            dropout=dropout,
            normalization="none",
        )

        # Layer normalization
        self.ln0 = nn.LayerNorm(self.heads * self.hidden)
        self.ln1 = nn.LayerNorm(self.heads * self.hidden)

        # Final projection to out_channels
        self.out_proj = nn.Linear(self.heads * self.hidden, out_channels)

        self.register_parameter("bias", None)
        self._alpha = None

        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        glorot(self.lin_K.weight)
        glorot(self.lin_V.weight)
        self.rFF.reset_parameters()
        glorot(self.out_proj.weight)
        self.ln0.reset_parameters()
        self.ln1.reset_parameters()
        nn.init.xavier_uniform_(self.att_r)

    def forward(
        self,
        x: Tensor,
        edge_index: Adj,
        size: Size = None,  # noqa: ARG002
        return_attention_weights: Optional[bool] = None,
    ) -> Tensor | tuple[Tensor, tuple[Tensor, Tensor]]:
        """Forward pass of PMA layer.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            edge_index: Graph connectivity in COO format.
            size: Size of the source and target node sets.
            return_attention_weights: If True, returns attention weights.
                Default: None (no attention weights returned).

        Returns:
            If return_attention_weights is False or None:
                Updated node features of shape (num_nodes, out_channels).
            If return_attention_weights is True:
                Tuple of (updated features, (edge_index, attention_weights)).
        """
        H, C = self.heads, self.hidden

        # Compute Key and Value transformations
        x_K = self.lin_K(x).view(-1, H, C)
        x_V = self.lin_V(x).view(-1, H, C)

        # Compute attention scores with seed vector
        alpha_r = (x_K * self.att_r).sum(dim=-1)

        # For hypergraphs: edge_index[0]=nodes, edge_index[1]=hyperedges
        # Step 1: Aggregate node features to hyperedges (V2E)
        num_nodes = x.shape[0]
        vertex, edges = edge_index[0], edge_index[1]  # type: ignore[index]

        # Handle empty edge case
        if edges.numel() == 0:
            # No edges: return zeros with seed vector
            out = self.att_r.expand(num_nodes, -1, -1)  # [N, H, C]
            alpha = None
        else:
            # Aggregate to hyperedges
            x_ve = x_V[vertex]  # [nnz, H, C]
            alpha_ve = alpha_r[vertex]  # [nnz, H]

            # Apply attention and aggregate to hyperedges
            alpha_ve = functional_F.leaky_relu(alpha_ve, self.negative_slope)
            alpha_ve = softmax(alpha_ve, edges, None, int(edges.max().item()) + 1)
            alpha_ve = functional_F.dropout(
                alpha_ve, p=self.dropout, training=self.training
            )

            x_e = scatter(
                x_ve * alpha_ve.unsqueeze(-1),
                edges,
                dim=0,
                reduce=self.aggr,  # type: ignore[arg-type]
            )  # [E, H, C]

            # Step 2: Propagate hyperedge features back to nodes (E2V)
            x_ev = x_e[edges]  # [nnz, H, C]
            out = scatter(
                x_ev,
                vertex,
                dim=0,
                reduce=self.aggr,  # type: ignore[arg-type]
                dim_size=num_nodes,
            )  # [N, H, C]

            alpha = alpha_ve

        self._alpha = alpha
        alpha = self._alpha
        self._alpha = None

        # Add seed vector (skip connection)
        out = out + self.att_r

        # Layer normalization
        out = self.ln0(out.view(-1, self.heads * self.hidden))

        # Feed-forward network with skip connection and second layer norm
        out = self.ln1(out + functional_F.relu(self.rFF(out)))

        # Final projection to out_channels
        out = self.out_proj(out)

        if isinstance(return_attention_weights, bool):
            if alpha is None:
                msg = "Attention weights are not available"
                raise RuntimeError(msg)
            if isinstance(edge_index, Tensor):
                return out, (edge_index, alpha)
            # For SparseTensor, would need special handling
            msg = "SparseTensor edge_index not yet supported for attention weights"
            raise NotImplementedError(msg)

        return out

    def message(  # type: ignore[override]
        self,
        x_j: Tensor,
        alpha_j: Tensor,
        index: Tensor,
        ptr: OptTensor,
        size_j: int,  # noqa: ARG002
    ) -> Tensor:
        """Construct messages with attention weights.

        Args:
            x_j: Features of neighbor nodes of shape (num_edges, heads, hidden).
            alpha_j: Attention scores of shape (num_edges, heads).
            index: Target node indices.
            ptr: Compressed storage format pointers (CSR format).
            size_j: Number of source nodes.

        Returns:
            Messages of shape (num_edges, heads, hidden).
        """
        # Apply LeakyReLU activation
        alpha = functional_F.leaky_relu(alpha_j, self.negative_slope)

        # Softmax normalization
        alpha = softmax(alpha, index, ptr, int(index.max().item()) + 1)
        self._alpha = alpha

        # Apply dropout
        alpha = functional_F.dropout(alpha, p=self.dropout, training=self.training)

        # Weight messages by attention
        return x_j * alpha.unsqueeze(-1)

    def aggregate(
        self,
        inputs: Tensor,
        index: Tensor,
        ptr: OptTensor = None,  # noqa: ARG002
        dim_size: Optional[int] = None,  # noqa: ARG002
    ) -> Tensor:
        """Aggregate messages from neighbors.

        Args:
            inputs: Messages to aggregate.
            index: Target node indices.
            ptr: Compressed storage format pointers (CSR format).
            dim_size: Size of output dimension.

        Returns:
            Aggregated messages.
        """
        return scatter(inputs, index, dim=self.node_dim, reduce=self.aggr)  # type: ignore[arg-type]

    def __repr__(self) -> str:
        """String representation of the layer."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.out_channels}, heads={self.heads})"
        )


__all__ = ["PMA"]
