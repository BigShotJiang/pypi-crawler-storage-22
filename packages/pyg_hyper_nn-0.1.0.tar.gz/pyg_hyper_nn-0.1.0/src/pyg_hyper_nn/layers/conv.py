"""Hypergraph convolution layers."""

from typing import Optional

import torch
from torch import Tensor, nn
from torch.nn import functional as functional_F
from torch_geometric.nn.conv import MessagePassing
from torch_geometric.utils import softmax
from torch_scatter import scatter_add

from pyg_hyper_nn.layers.utils import glorot, zeros


class HypergraphConv(MessagePassing):
    """Hypergraph convolution layer.

    Implements the hypergraph convolution operation from the paper
    "Hypergraph Neural Networks" (Feng et al., AAAI 2019).

    Args:
        in_channels: Size of each input sample.
        out_channels: Size of each output sample.
        symdegnorm: If True, use symmetric degree normalization (HGNN style).
            Otherwise use non-symmetric normalization. Default: False.
        use_attention: If True, use attention mechanism. Default: False.
        heads: Number of attention heads (only used if use_attention=True).
            Default: 1.
        concat: If True, concatenate attention heads. Otherwise average them
            (only used if use_attention=True). Default: True.
        negative_slope: LeakyReLU angle of negative slope
            (only used if use_attention=True). Default: 0.2.
        dropout: Dropout probability for attention weights
            (only used if use_attention=True). Default: 0.0.
        bias: If True, adds a learnable bias. Default: True.
        **kwargs: Additional arguments for MessagePassing parent class.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        symdegnorm: bool = False,
        use_attention: bool = False,
        heads: int = 1,
        concat: bool = True,
        negative_slope: float = 0.2,
        dropout: float = 0.0,
        bias: bool = True,
        **kwargs,
    ):
        kwargs.setdefault("aggr", "add")
        super().__init__(node_dim=0, **kwargs)

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.use_attention = use_attention
        self.symdegnorm = symdegnorm

        if self.use_attention:
            self.heads = heads
            self.concat = concat
            self.negative_slope = negative_slope
            self.dropout = dropout
            self.weight = nn.Parameter(torch.Tensor(in_channels, heads * out_channels))
            self.att = nn.Parameter(torch.Tensor(1, heads, 2 * out_channels))
        else:
            self.heads = 1
            self.concat = True
            self.weight = nn.Parameter(torch.Tensor(in_channels, out_channels))

        if bias and concat:
            self.bias = nn.Parameter(torch.Tensor(heads * out_channels))
        elif bias and not concat:
            self.bias = nn.Parameter(torch.Tensor(out_channels))
        else:
            self.register_parameter("bias", None)

        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        glorot(self.weight)
        if self.use_attention:
            glorot(self.att)
        zeros(self.bias)

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,
    ) -> tuple[Tensor, Tensor]:
        """Forward pass of hypergraph convolution.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges),
                where hyperedge_index[0] contains node indices and
                hyperedge_index[1] contains hyperedge indices.
            hyperedge_weight: Optional hyperedge weights of shape (num_hyperedges,).
                Default: None (uniform weights).

        Returns:
            Tuple of:
                - Updated node features of shape (num_nodes, out_channels * heads)
                  if concat=True, else (num_nodes, out_channels).
                - Hyperedge embeddings of shape (num_hyperedges, out_channels * heads)
                  if concat=True, else (num_hyperedges, out_channels).
        """
        num_nodes, num_edges = x.size(0), 0
        if hyperedge_index.numel() > 0:
            num_edges = int(hyperedge_index[1].max()) + 1

        if hyperedge_weight is None:
            hyperedge_weight = x.new_ones(num_edges, device=x.device)

        x = torch.matmul(x, self.weight)

        alpha = None
        if self.use_attention:
            x = x.view(-1, self.heads, self.out_channels)
            x_i, x_j = x[hyperedge_index[0]], x[hyperedge_index[1]]
            alpha = (torch.cat([x_i, x_j], dim=-1) * self.att).sum(dim=-1)
            alpha = functional_F.leaky_relu(alpha, self.negative_slope)
            alpha = softmax(alpha, hyperedge_index[0], num_nodes=x.size(0))
            alpha = functional_F.dropout(alpha, p=self.dropout, training=self.training)

        if not self.symdegnorm:
            # Non-symmetric degree normalization
            D = scatter_add(
                hyperedge_weight[hyperedge_index[1]],
                hyperedge_index[0],
                dim=0,
                dim_size=num_nodes,
            )
            D = 1.0 / D
            D[torch.isinf(D)] = 0.0

            B = scatter_add(
                x.new_ones(hyperedge_index.size(1), device=x.device),
                hyperedge_index[1],
                dim=0,
                dim_size=num_edges,
            )
            B = 1.0 / B
            B[torch.isinf(B)] = 0.0

            self.flow = "source_to_target"
            edge_embed = self.propagate(  # type: ignore[misc]
                edge_index=hyperedge_index,
                x=x,
                norm=B,
                alpha=alpha,
                size=(num_nodes, num_edges),
            )
            self.flow = "target_to_source"
            out = self.propagate(  # type: ignore[misc]
                edge_index=hyperedge_index,
                x=edge_embed,
                norm=D,
                alpha=alpha,
                size=(num_nodes, num_edges),
            )

        else:
            # Symmetric degree normalization (HGNN style)
            D = scatter_add(
                hyperedge_weight[hyperedge_index[1]],
                hyperedge_index[0],
                dim=0,
                dim_size=num_nodes,
            )
            D = 1.0 / D**0.5
            D[torch.isinf(D)] = 0.0

            B = scatter_add(
                x.new_ones(hyperedge_index.size(1), device=x.device),
                hyperedge_index[1],
                dim=0,
                dim_size=num_edges,
            )
            B = 1.0 / B
            B[torch.isinf(B)] = 0.0

            x = D.unsqueeze(-1) * x
            self.flow = "source_to_target"
            edge_embed = self.propagate(  # type: ignore[misc]
                edge_index=hyperedge_index,
                x=x,
                norm=B,
                alpha=alpha,
                size=(num_nodes, num_edges),
            )

            self.flow = "target_to_source"
            out = self.propagate(  # type: ignore[misc]
                edge_index=hyperedge_index,
                x=edge_embed,
                norm=D,
                alpha=alpha,
                size=(num_nodes, num_edges),
            )

        if self.concat:
            out = out.view(-1, self.heads * self.out_channels)
            edge_embed = edge_embed.view(-1, self.heads * self.out_channels)
        else:
            out = out.mean(dim=1)
            edge_embed = edge_embed.mean(dim=1)

        if self.bias is not None:
            out = out + self.bias

        return out, edge_embed

    def message(self, x_j: Tensor, norm_i: Tensor, alpha: Optional[Tensor]) -> Tensor:  # type: ignore[override]
        """Construct messages for propagation.

        Args:
            x_j: Features of neighbor nodes.
            norm_i: Normalization coefficients.
            alpha: Optional attention weights.

        Returns:
            Messages of shape (num_edges, heads, out_channels).
        """
        H, F = self.heads, self.out_channels

        out = norm_i.view(-1, 1, 1) * x_j.view(-1, H, F)

        if alpha is not None:
            out = alpha.view(-1, self.heads, 1) * out

        return out

    def __repr__(self) -> str:
        """String representation of the layer."""
        return f"{self.__class__.__name__}({self.in_channels}, {self.out_channels})"


__all__ = ["HypergraphConv"]
