"""Utility functions for HJRL (Hypergraph Joint Representation Learning).

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

This module implements preprocessing functions for HJRL, which uses normalized
incidence matrices and node/edge features for joint learning.
"""

from __future__ import annotations

import numpy as np
import scipy.sparse as sp
import torch
from torch import Tensor


def row_normalize(mx: sp.spmatrix) -> sp.spmatrix:
    """Row-normalize sparse matrix.

    Args:
        mx: Scipy sparse matrix to normalize.

    Returns:
        Row-normalized sparse matrix.
    """
    rowsum = np.array(mx.sum(1))  # type: ignore[union-attr]

    # Handle zero rows
    if np.where(rowsum == 0)[0].shape[0] != 0:
        indices = np.where(rowsum == 0)[0]
        for i in indices:
            rowsum[i] = float("inf")

    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.0
    r_mat_inv = sp.diags(r_inv)
    return r_mat_inv.dot(mx)


def normalize_sparse_hypergraph_symmetric(
    H: sp.spmatrix,
) -> tuple[sp.spmatrix, sp.spmatrix]:
    """Symmetrically normalize hypergraph incidence matrix.

    Computes:
    - HHT = D^{-1/2} H Omega B H^T D^{-1/2}
    - H_norm = D^{-1/2} H Omega B

    where D is node degree matrix, Omega is identity, and B is edge weight matrix.

    Args:
        H: Hypergraph incidence matrix of shape (num_nodes, num_edges).

    Returns:
        Tuple of (HHT, H_norm) normalized matrices.
    """
    # Row normalization: D^{-1/2}
    rowsum = np.array(H.sum(1))  # type: ignore[union-attr]
    r_inv_sqrt = np.power(rowsum, -0.5).flatten()
    r_inv_sqrt[np.isinf(r_inv_sqrt)] = 0.0
    D = sp.diags(r_inv_sqrt)

    # Column normalization: B^{-1}
    colsum = np.array(H.sum(0), dtype=float)  # type: ignore[union-attr]
    r_inv_sqrt = np.power(colsum, -1).flatten()
    r_inv_sqrt[np.isinf(r_inv_sqrt)] = 0.0
    B = sp.diags(r_inv_sqrt)

    # Identity matrix Omega
    Omega = sp.eye(B.shape[0])

    # Compute normalized matrices
    # HHT = D^{-1/2} H Omega B H^T D^{-1/2}
    HHT = D.dot(H).dot(Omega).dot(B).dot(H.transpose()).dot(D)  # type: ignore[union-attr]

    # H_norm = D^{-1/2} H Omega B
    H_norm = D.dot(H).dot(Omega).dot(B)

    return HHT, H_norm


def precompute_node_edge_features(H: sp.spmatrix, X: Tensor) -> tuple[Tensor, Tensor]:
    """Precompute normalized node and edge features for HJRL.

    Edge features are computed by aggregating node features through the
    incidence matrix, then binarizing and row-normalizing.

    Args:
        H: Hypergraph incidence matrix (sparse) of shape (num_nodes, num_edges).
        X: Node features of shape (num_nodes, num_features).

    Returns:
        Tuple of (normalized_X, normalized_E) where E is edge features.
    """
    X_np = X.detach().cpu().numpy()
    H_array = H.toarray()  # type: ignore[union-attr]
    H_T = H_array.T

    num_edges = H_array.shape[1]
    E = np.zeros((num_edges, X_np.shape[1]))

    # Aggregate node features to edges
    for i in range(num_edges):
        nodes_in_edge = np.where(H_T[i])[0]
        if len(nodes_in_edge) > 0:
            edge_features = X_np[nodes_in_edge].sum(0)
            E[i] = edge_features

    # Binarize edge features (1 if non-zero, 0 otherwise)
    E = np.where(E != 0, 1, 0).astype(float)

    # Row normalize both node and edge features
    X_norm = row_normalize(sp.csr_matrix(X_np))
    E_norm = row_normalize(sp.csr_matrix(E))

    # Convert to tensors
    X_tensor = torch.from_numpy(X_norm.toarray()).float()  # type: ignore[union-attr]
    E_tensor = torch.from_numpy(E_norm.toarray()).float()  # type: ignore[union-attr]

    return X_tensor, E_tensor


def ssm2tst(M: sp.spmatrix) -> Tensor:
    """Convert scipy sparse matrix to torch sparse tensor.

    Args:
        M: Scipy sparse matrix.

    Returns:
        PyTorch sparse tensor.
    """
    M = M.tocoo().astype(np.float32)  # type: ignore[union-attr]

    indices = torch.from_numpy(np.vstack((M.row, M.col))).long()
    values = torch.from_numpy(M.data)
    shape = torch.Size(M.shape)

    return torch.sparse_coo_tensor(indices, values, shape)


def hjrl_preprocessing(
    hyperedge_index: Tensor, x: Tensor, num_nodes: int, num_edges: int
) -> tuple[Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor]:
    """Preprocess hypergraph data for HJRL model.

    Computes normalized incidence matrices and node/edge features:
    - HHT: node-node adjacency via hyperedges
    - H: normalized incidence matrix (node to edge)
    - HT: transposed normalized incidence (edge to node)
    - HTH: edge-edge adjacency via nodes
    - norm_X: normalized node features
    - norm_E: normalized edge features

    Args:
        hyperedge_index: Hyperedge indices in COO format of shape (2, num_pairs).
        x: Node features of shape (num_nodes, num_features).
        num_nodes: Number of nodes in the hypergraph.
        num_edges: Number of hyperedges.

    Returns:
        Tuple of (H_ini, H, HT, HHT, HTH, norm_X, norm_E).
    """
    # Convert to numpy for scipy operations
    edge_index = hyperedge_index.cpu().numpy()
    row = edge_index[0]
    col = edge_index[1]
    values = np.ones(len(row))

    # Create incidence matrix H (num_nodes x num_edges)
    H_ini = sp.coo_matrix((values, (row, col)), shape=(num_nodes, num_edges)).astype(
        np.float32
    )

    # Compute normalized matrices
    HHT, H = normalize_sparse_hypergraph_symmetric(H_ini)
    HTH, HT = normalize_sparse_hypergraph_symmetric(H_ini.transpose())

    # Precompute normalized features
    norm_X, norm_E = precompute_node_edge_features(H_ini, x)

    # Convert to torch sparse tensors
    H_ini_tensor = torch.from_numpy(H_ini.toarray()).float()
    HHT_tensor = ssm2tst(HHT)
    H_tensor = ssm2tst(H)
    HT_tensor = ssm2tst(HT)
    HTH_tensor = ssm2tst(HTH)

    return H_ini_tensor, H_tensor, HT_tensor, HHT_tensor, HTH_tensor, norm_X, norm_E


__all__ = [
    "hjrl_preprocessing",
    "normalize_sparse_hypergraph_symmetric",
    "precompute_node_edge_features",
    "row_normalize",
    "ssm2tst",
]
