"""HyperGCN convolution layer.

Implements the HyperGCN convolution operation that applies graph convolution
on the approximated graph structure derived from hypergraphs.

Reference: "HyperGCN: A New Method For Training Graph Convolutional Networks on Hypergraphs"
"""

import math
from typing import Optional

import torch
from torch import Tensor, nn
from torch.autograd import Variable

from pyg_hyper_nn.layers.hypergcn_utils import hypergcn_laplacian
from pyg_hyper_nn.layers.utils import SparseMM


class HyperGCNConv(nn.Module):
    """HyperGCN convolution layer.

    Simple GCN-style layer that operates on the graph approximation
    of a hypergraph using supremum-infimum projection.

    Args:
        in_channels: Size of input features.
        out_channels: Size of output features.
        reapproximate: If True, recompute graph approximation at each forward pass.
            If False, use cached structure. Default: True.

    Shape:
        - Input: Node features (num_nodes, in_channels)
        - Output: Updated features (num_nodes, out_channels)
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        reapproximate: bool = True,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.reapproximate = reapproximate

        self.W = nn.Parameter(torch.empty(in_channels, out_channels))
        self.bias = nn.Parameter(torch.empty(out_channels))
        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Initialize parameters uniformly."""
        std = 1.0 / math.sqrt(self.W.size(1))
        self.W.data.uniform_(-std, std)
        self.bias.data.uniform_(-std, std)

    def forward(
        self,
        x: Tensor,
        structure: Optional[Tensor],
        hyperedge_dict: Optional[dict[int, list[int]]],
        m: bool = True,
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            structure: Precomputed graph structure (sparse tensor) or None.
            hyperedge_dict: Dictionary mapping hyperedge IDs to node lists.
                Required if reapproximate=True.
            m: If True, use mediator mode. Default: True.

        Returns:
            Output features of shape (num_nodes, out_channels).
        """
        # Transform features: H @ W
        HW = torch.mm(x, self.W)

        # Compute or reuse graph approximation
        if self.reapproximate and hyperedge_dict is not None:
            n = x.shape[0]
            X = HW.cpu().detach().numpy()
            A = hypergcn_laplacian(n, hyperedge_dict, X, m)
        elif structure is not None:
            A = structure
        else:
            msg = "Either structure must be provided or reapproximate must be True with hyperedge_dict"
            raise ValueError(msg)

        # Move to same device as input
        A = A.to(x.device)
        A = Variable(A)

        # Apply graph convolution: A @ (H @ W) + bias
        AHW = SparseMM.apply(A, HW)
        return AHW + self.bias

    def __repr__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self.in_channels}, {self.out_channels})"


__all__ = ["HyperGCNConv"]
