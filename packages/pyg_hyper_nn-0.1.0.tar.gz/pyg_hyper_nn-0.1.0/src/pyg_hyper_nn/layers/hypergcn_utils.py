"""Utility functions for HyperGCN model.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

This module implements the preprocessing and graph approximation functions
required for HyperGCN, which converts hypergraphs to graphs using
supremum-infimum projection with optional mediators.

Reference: "HyperGCN: A New Method For Training Graph Convolutional Networks on Hypergraphs"
"""

from __future__ import annotations

from collections import defaultdict

import numpy as np
import scipy.sparse as sp
import torch
from torch import Tensor


def get_hypergcn_he_dict(hyperedge_index: Tensor) -> dict[int, list[int]]:
    """Convert hyperedge_index to dictionary format for HyperGCN.

    Args:
        hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            Row 0 contains node indices, row 1 contains hyperedge indices.

    Returns:
        Dictionary mapping hyperedge IDs to lists of node IDs.

    Example:
        >>> hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
        >>> get_hypergcn_he_dict(hyperedge_index)
        {0: [0, 1, 2], 1: [1, 2, 3]}
    """
    edge_index = hyperedge_index.cpu().numpy()
    he_dict: dict[int, list[int]] = defaultdict(list)

    for node, he in zip(edge_index[0, :], edge_index[1, :], strict=False):
        he_dict[int(he)].append(int(node))

    return dict(he_dict)


def symnormalise(M: sp.spmatrix) -> sp.spmatrix:
    """Symmetrically normalize sparse matrix: D^{-1/2} M D^{-1/2}.

    Args:
        M: Scipy sparse matrix to normalize.

    Returns:
        Symmetrically normalized sparse matrix.
    """
    d = np.array(M.sum(1))  # type: ignore[union-attr]

    dhi = np.power(d, -1 / 2).flatten()
    dhi[np.isinf(dhi)] = 0.0
    DHI = sp.diags(dhi)  # D half inverse i.e. D^{-1/2}

    return (DHI.dot(M)).dot(DHI)


def adjacency(
    edges: list[list[int]],
    weights: dict[tuple[int, int], float],
    n: int,
) -> Tensor:
    """Construct sparse adjacency matrix from edges and weights.

    Args:
        edges: List of [source, target] pairs.
        weights: Dictionary mapping (source, target) tuples to edge weights.
        n: Number of nodes.

    Returns:
        Symmetrically normalized adjacency matrix as torch sparse tensor.
    """
    # Remove duplicate edges
    dictionary = {tuple(item): index for index, item in enumerate(edges)}
    edges_unique = [list(itm) for itm in dictionary]
    organised = []

    for e in edges_unique:
        i, j = e[0], e[1]
        w = weights[(i, j)]
        organised.append(w)

    edges_array, weights_array = np.array(edges_unique), np.array(organised)
    adj = sp.coo_matrix(
        (weights_array, (edges_array[:, 0], edges_array[:, 1])),
        shape=(n, n),
        dtype=np.float32,
    )
    adj = adj + sp.eye(n)

    A = symnormalise(sp.csr_matrix(adj, dtype=np.float32))
    return ssm2tst(A)


def ssm2tst(M: sp.spmatrix) -> Tensor:
    """Convert scipy sparse matrix to torch sparse tensor.

    Args:
        M: Scipy sparse matrix.

    Returns:
        PyTorch sparse tensor.
    """
    M = M.tocoo().astype(np.float32)  # type: ignore[union-attr]

    indices = torch.from_numpy(np.vstack((M.row, M.col))).long()
    values = torch.from_numpy(M.data)
    shape = torch.Size(M.shape)

    return torch.sparse_coo_tensor(indices, values, shape)


def hypergcn_laplacian(
    V: int,
    E: dict[int, list[int]],
    X: np.ndarray,
    m: bool,
) -> Tensor:
    """Approximate hypergraph Laplacian using supremum-infimum projection.

    This function implements the core HyperGCN approximation that converts
    a hypergraph to a graph by:
    1. For each hyperedge, project node features onto a random vector
    2. Select supremum (max) and infimum (min) nodes based on projection
    3. Connect supremum and infimum with edge weight 1/|e| (without mediators)
       or connect via mediators with weight 1/(2|e|-3) (with mediators)

    Args:
        V: Number of vertices.
        E: Hyperedge dictionary mapping hyperedge IDs to lists of node IDs.
        X: Node features of shape (num_nodes, num_features).
        m: If True, use mediator mode (two-star expansion).
           If False, use direct supremum-infimum connection.

    Returns:
        Normalized adjacency matrix as torch sparse tensor.

    Reference:
        HyperGCN: A New Method For Training Graph Convolutional Networks on Hypergraphs
        Section 3.2: Graph approximation via supremum-infimum projection
    """
    edges = []
    weights: dict[tuple[int, int], float] = defaultdict(float)

    # Random projection vector for supremum-infimum selection
    rv = np.random.rand(X.shape[1])
    X_proj = X @ rv  # shape: (n_nodes,)

    for hyperedge_set in E.values():
        hyperedge = list(hyperedge_set)
        proj = X_proj[hyperedge]

        # Find supremum (max) and infimum (min) based on projection
        s, i = np.argmax(proj), np.argmin(proj)
        Se, Ie = hyperedge[s], hyperedge[i]

        if m:
            # Mediator mode: connect supremum-infimum via intermediate nodes
            c = max(2 * len(hyperedge) - 3, 1)

            # Connect supremum and infimum directly
            edges.extend([[Se, Ie], [Ie, Se]])
            weights[(Se, Ie)] += 1.0 / c
            weights[(Ie, Se)] += 1.0 / c

            # Connect supremum and infimum with each mediator
            for mediator in hyperedge:
                if mediator not in (Se, Ie):
                    for u, v in [
                        (Se, mediator),
                        (Ie, mediator),
                        (mediator, Se),
                        (mediator, Ie),
                    ]:
                        edges.append([u, v])
                        weights[(u, v)] += 1.0 / c
        else:
            # Direct mode: only connect supremum and infimum
            e = len(hyperedge)
            edges.extend([[Se, Ie], [Ie, Se]])
            weights[(Se, Ie)] += 1.0 / e
            weights[(Ie, Se)] += 1.0 / e

    return adjacency(edges, weights, V)


__all__ = [
    "adjacency",
    "get_hypergcn_he_dict",
    "hypergcn_laplacian",
    "ssm2tst",
    "symnormalise",
]
