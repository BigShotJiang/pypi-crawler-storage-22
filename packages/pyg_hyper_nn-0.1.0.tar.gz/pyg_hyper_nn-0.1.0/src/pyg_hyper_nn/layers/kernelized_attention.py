"""Kernelized attention mechanisms for linear complexity transformers.

This module implements the kernelized softmax attention from the HyperGT paper,
which reduces attention complexity from O(N²) to O(N).

Reference: https://arxiv.org/abs/2402.02365
"""

import math
from typing import Optional

import torch
from torch import Tensor


def create_projection_matrix(
    m: int,
    d: int,
    seed: int = 0,
    device: Optional[torch.device] = None,
) -> Tensor:
    """Create random projection matrix for kernelized attention.

    Uses orthogonal random features for better approximation quality.

    Args:
        m: Number of random features.
        d: Dimension of input features.
        seed: Random seed for reproducibility.
        device: Device to place the matrix on.

    Returns:
        Projection matrix of shape (m, d).
    """
    nb_full_blocks = m // d
    block_list = []
    current_seed = seed

    for _ in range(nb_full_blocks):
        torch.manual_seed(current_seed)
        unstructured_block = torch.randn((d, d))
        q, _ = torch.linalg.qr(unstructured_block)
        q = q.t()
        block_list.append(q)
        current_seed += 1

    remaining_rows = m - nb_full_blocks * d
    if remaining_rows > 0:
        torch.manual_seed(current_seed)
        unstructured_block = torch.randn((d, d))
        q, _ = torch.linalg.qr(unstructured_block)
        q = q.t()
        block_list.append(q[0:remaining_rows])

    final_matrix = torch.vstack(block_list)

    current_seed += 1
    torch.manual_seed(current_seed)
    multiplier = torch.norm(torch.randn((m, d)), dim=1)

    projection = torch.matmul(torch.diag(multiplier), final_matrix)

    if device is not None:
        projection = projection.to(device)

    return projection


def softmax_kernel_transformation(
    data: Tensor,
    is_query: bool,
    projection_matrix: Tensor,
    numerical_stabilizer: float = 1e-6,
) -> Tensor:
    """Transform data using softmax kernel approximation.

    Args:
        data: Input tensor of shape (B, N, H, D).
        is_query: Whether this is a query (True) or key (False).
        projection_matrix: Random projection matrix of shape (M, D).
        numerical_stabilizer: Small constant for numerical stability.

    Returns:
        Transformed tensor of shape (B, N, H, M).
    """
    # Normalize by sqrt(d)
    data_normalizer = 1.0 / torch.sqrt(
        torch.sqrt(torch.tensor(data.shape[-1], dtype=torch.float32))
    )
    data = data_normalizer * data

    # Project to random features
    ratio = 1.0 / torch.sqrt(
        torch.tensor(projection_matrix.shape[0], dtype=torch.float32)
    )
    data_dash = torch.einsum("bnhd,md->bnhm", data, projection_matrix)

    # Compute squared norm
    diag_data = torch.square(data)
    diag_data = torch.sum(diag_data, dim=len(data.shape) - 1)
    diag_data = diag_data / 2.0
    diag_data = torch.unsqueeze(diag_data, dim=len(data.shape) - 1)

    last_dims_t = len(data_dash.shape) - 1
    attention_dims_t = len(data_dash.shape) - 3

    if is_query:
        data_dash = ratio * (
            torch.exp(
                data_dash
                - diag_data
                - torch.max(data_dash, dim=last_dims_t, keepdim=True)[0]
            )
            + numerical_stabilizer
        )
    else:
        data_dash = ratio * (
            torch.exp(
                data_dash
                - diag_data
                - torch.max(
                    torch.max(data_dash, dim=last_dims_t, keepdim=True)[0],
                    dim=attention_dims_t,
                    keepdim=True,
                )[0]
            )
            + numerical_stabilizer
        )

    return data_dash


def numerator(qs: Tensor, ks: Tensor, vs: Tensor) -> Tensor:
    """Compute numerator of kernelized attention.

    Args:
        qs: Query features of shape (N, B, H, M).
        ks: Key features of shape (N, B, H, M).
        vs: Value features of shape (N, B, H, D).

    Returns:
        Numerator tensor of shape (N, B, H, D).
    """
    kvs = torch.einsum("nbhm,nbhd->bhmd", ks, vs)
    return torch.einsum("nbhm,bhmd->nbhd", qs, kvs)


def denominator(qs: Tensor, ks: Tensor) -> Tensor:
    """Compute denominator of kernelized attention.

    Args:
        qs: Query features of shape (N, B, H, M).
        ks: Key features of shape (N, B, H, M).

    Returns:
        Denominator tensor of shape (N, B, H).
    """
    all_ones = torch.ones([ks.shape[0]], device=qs.device)
    ks_sum = torch.einsum("nbhm,n->bhm", ks, all_ones)
    return torch.einsum("nbhm,bhm->nbh", qs, ks_sum)


def kernelized_softmax(
    query: Tensor,
    key: Tensor,
    value: Tensor,
    projection_matrix: Tensor,
    tau: float = 0.25,
) -> Tensor:
    """Fast computation of all-pair attention with linear complexity.

    Args:
        query: Query tensor of shape (B, N, H, D).
        key: Key tensor of shape (B, N, H, D).
        value: Value tensor of shape (B, N, H, D).
        projection_matrix: Random projection matrix of shape (M, D).
        tau: Temperature parameter.

    Returns:
        Updated node embeddings of shape (B, N, H, D).
    """
    # Apply temperature scaling
    query = query / math.sqrt(tau)
    key = key / math.sqrt(tau)

    # Apply kernel transformation
    query_prime = softmax_kernel_transformation(
        query, True, projection_matrix
    )  # [B, N, H, M]
    key_prime = softmax_kernel_transformation(
        key, False, projection_matrix
    )  # [B, N, H, M]

    # Rearrange for computation
    query_prime = query_prime.permute(1, 0, 2, 3)  # [N, B, H, M]
    key_prime = key_prime.permute(1, 0, 2, 3)  # [N, B, H, M]
    value = value.permute(1, 0, 2, 3)  # [N, B, H, D]

    # Compute attention: O(N) complexity
    z_num = numerator(query_prime, key_prime, value)  # [N, B, H, D]
    z_den = denominator(query_prime, key_prime)  # [N, B, H]

    # Rearrange back
    z_num = z_num.permute(1, 0, 2, 3)  # [B, N, H, D]
    z_den = z_den.permute(1, 0, 2)  # [B, N, H]
    z_den = torch.unsqueeze(z_den, len(z_den.shape))  # [B, N, H, 1]

    return z_num / z_den


__all__ = [
    "create_projection_matrix",
    "denominator",
    "kernelized_softmax",
    "numerator",
    "softmax_kernel_transformation",
]
