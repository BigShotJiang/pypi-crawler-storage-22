"""Utility functions for LEGCN (Line Expansion GCN) model.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

This module implements line expansion preprocessing for LEGCN, which converts
hypergraphs to line graphs where each node-hyperedge pair becomes a vertex,
and edges connect pairs sharing a node or hyperedge.
"""

import torch
import torch_sparse
from torch import Tensor


def line_expansion(hyperedge_index: Tensor, num_nodes: int) -> Tensor:
    """Compute line expansion adjacency matrix for hypergraph.

    Line expansion creates a graph where:
    - Vertices: All node-hyperedge pairs (v, e) where v ∈ e
    - Edges: Connect pairs (v1, e1) and (v2, e2) if they share v or e

    Args:
        hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            Row 0 contains node indices, row 1 contains hyperedge indices.
        num_nodes: Number of nodes in the hypergraph.

    Returns:
        Line expansion adjacency in COO format of shape (2, num_line_edges).
        Indices correspond to node-hyperedge pairs.

    Example:
        >>> # Hypergraph with 3 nodes, 2 hyperedges: e0={0,1}, e1={1,2}
        >>> hyperedge_index = torch.tensor([[0, 1, 1, 2], [0, 0, 1, 1]])
        >>> le_adj = line_expansion(hyperedge_index, num_nodes=3)
        >>> # Creates line graph with 4 vertices (one per node-edge pair)
        >>> # and edges connecting pairs sharing nodes or hyperedges
    """
    # Ensure on CPU for sparse operations
    device = hyperedge_index.device
    hyperedge_index = hyperedge_index.cpu()

    V, E = hyperedge_index[0], hyperedge_index[1]

    num_pairs = hyperedge_index.shape[1]  # Number of (node, hyperedge) pairs

    # Handle empty hypergraph
    if num_pairs == 0:
        return torch.empty((2, 0), dtype=torch.long, device=device)

    # Offset hyperedge indices to make them distinct from node indices
    # This creates a bipartite representation [V | E]
    E_offset = E + num_nodes

    max_idx = E_offset.max().item() + 1  # Total vertices in bipartite graph

    # Create incidence matrix connections
    pair_indices = torch.arange(num_pairs, device=hyperedge_index.device)
    L1 = torch.stack([pair_indices, V], dim=0)  # Connect to nodes
    L2 = torch.stack([pair_indices, E_offset], dim=0)  # Connect to hyperedges
    L = torch.cat([L1, L2], dim=1)  # Shape: (2, 2 * num_pairs)

    # Transpose: L^T has shape (num_nodes + num_hyperedges, num_pairs)
    L_T = torch.stack([L[1], L[0]], dim=0)

    # Create weight vectors (all ones)
    ones = torch.ones(L.shape[1], device=hyperedge_index.device)

    # Compute L @ L^T to get line graph adjacency
    # Two pairs (v1, e1) and (v2, e2) are connected if:
    # - v1 == v2 (share a node), or
    # - e1 == e2 (share a hyperedge)
    adj, value = torch_sparse.spspmm(
        L, ones, L_T, ones, num_pairs, max_idx, num_pairs, coalesced=True
    )

    # Coalesce to sum duplicate edges
    adj, value = torch_sparse.coalesce(adj, value, num_pairs, num_pairs, op="add")

    return adj.to(device)


__all__ = ["line_expansion"]
