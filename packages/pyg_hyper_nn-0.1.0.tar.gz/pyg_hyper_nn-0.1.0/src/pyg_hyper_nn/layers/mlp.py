"""Multi-layer perceptron implementations for hypergraph neural networks."""

from torch import Tensor, nn
from torch.nn import functional as functional_F


class MLP(nn.Module):
    """Multi-layer perceptron with configurable normalization.

    Adapted from https://github.com/CUAI/CorrectAndSmooth/blob/master/gen_models.py

    Args:
        in_channels: Size of input features.
        hidden_channels: Size of hidden layer features.
        out_channels: Size of output features.
        num_layers: Number of layers (minimum 1).
        dropout: Dropout probability. Default: 0.5.
        normalization: Type of normalization ("bn", "ln", "none"). Default: "bn".
        input_norm: If True, apply normalization to input. Default: False.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        dropout: float = 0.5,
        normalization: str = "bn",
        input_norm: bool = False,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.dropout = dropout

        self.lins = nn.ModuleList()
        self.normalizations = nn.ModuleList()
        self.input_norm = input_norm

        norm_lower = normalization.lower()
        if norm_lower not in {"bn", "ln", "none"}:
            msg = f"Normalization must be 'bn', 'ln', or 'none', got {normalization}"
            raise ValueError(msg)

        if norm_lower == "bn":
            self._build_bn_layers(
                in_channels, hidden_channels, out_channels, num_layers
            )
        elif norm_lower == "ln":
            self._build_ln_layers(
                in_channels, hidden_channels, out_channels, num_layers
            )
        else:
            self._build_no_norm_layers(
                in_channels, hidden_channels, out_channels, num_layers
            )

    def _build_bn_layers(
        self, in_channels: int, hidden_channels: int, out_channels: int, num_layers: int
    ) -> None:
        """Build layers with batch normalization."""
        if num_layers == 1:
            if self.input_norm:
                self.normalizations.append(nn.BatchNorm1d(in_channels))
            else:
                self.normalizations.append(nn.Identity())
            self.lins.append(nn.Linear(in_channels, out_channels))
        else:
            if self.input_norm:
                self.normalizations.append(nn.BatchNorm1d(in_channels))
            else:
                self.normalizations.append(nn.Identity())
            self.lins.append(nn.Linear(in_channels, hidden_channels))
            self.normalizations.append(nn.BatchNorm1d(hidden_channels))
            for _ in range(num_layers - 2):
                self.lins.append(nn.Linear(hidden_channels, hidden_channels))
                self.normalizations.append(nn.BatchNorm1d(hidden_channels))
            self.lins.append(nn.Linear(hidden_channels, out_channels))

    def _build_ln_layers(
        self, in_channels: int, hidden_channels: int, out_channels: int, num_layers: int
    ) -> None:
        """Build layers with layer normalization."""
        if num_layers == 1:
            if self.input_norm:
                self.normalizations.append(nn.LayerNorm(in_channels))
            else:
                self.normalizations.append(nn.Identity())
            self.lins.append(nn.Linear(in_channels, out_channels))
        else:
            if self.input_norm:
                self.normalizations.append(nn.LayerNorm(in_channels))
            else:
                self.normalizations.append(nn.Identity())
            self.lins.append(nn.Linear(in_channels, hidden_channels))
            self.normalizations.append(nn.LayerNorm(hidden_channels))
            for _ in range(num_layers - 2):
                self.lins.append(nn.Linear(hidden_channels, hidden_channels))
                self.normalizations.append(nn.LayerNorm(hidden_channels))
            self.lins.append(nn.Linear(hidden_channels, out_channels))

    def _build_no_norm_layers(
        self, in_channels: int, hidden_channels: int, out_channels: int, num_layers: int
    ) -> None:
        """Build layers without normalization."""
        if num_layers == 1:
            self.normalizations.append(nn.Identity())
            self.lins.append(nn.Linear(in_channels, out_channels))
        else:
            self.normalizations.append(nn.Identity())
            self.lins.append(nn.Linear(in_channels, hidden_channels))
            self.normalizations.append(nn.Identity())
            for _ in range(num_layers - 2):
                self.lins.append(nn.Linear(hidden_channels, hidden_channels))
                self.normalizations.append(nn.Identity())
            self.lins.append(nn.Linear(hidden_channels, out_channels))

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        for lin in self.lins:
            lin.reset_parameters()  # type: ignore[misc]
        for normalization in self.normalizations:
            if normalization.__class__.__name__ != "Identity":
                normalization.reset_parameters()  # type: ignore[misc]

    def forward(self, x: Tensor) -> Tensor:
        """Forward pass.

        Args:
            x: Input features of shape (num_nodes, in_channels).

        Returns:
            Output features of shape (num_nodes, out_channels).
        """
        x = self.normalizations[0](x)
        for i, lin in enumerate(self.lins[:-1]):  # type: ignore[arg-type]
            x = lin(x)
            x = functional_F.relu(x, inplace=True)
            x = self.normalizations[i + 1](x)
            x = functional_F.dropout(x, p=self.dropout, training=self.training)
        return self.lins[-1](x)

    def __repr__(self) -> str:
        """String representation of the module."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels})"
        )


__all__ = ["MLP"]
