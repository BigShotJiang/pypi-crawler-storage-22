"""NodeFormerConv layer for HyperGT.

This module implements the NodeFormer convolution layer that uses
kernelized attention for O(N) complexity all-pair message passing.
"""

from typing import Optional

from torch import Tensor, nn

from pyg_hyper_nn.layers.kernelized_attention import (
    create_projection_matrix,
    kernelized_softmax,
)


class NodeFormerConv(nn.Module):
    """NodeFormer convolution layer with kernelized attention.

    This layer performs all-pair attentive aggregation with linear complexity
    using kernelized softmax attention.

    Args:
        in_channels: Size of input features.
        out_channels: Size of output features.
        num_heads: Number of attention heads. Default: 4.
        nb_random_features: Number of random features for kernel approximation. Default: 30.
        dropout: Dropout probability. Default: 0.0.
        tau: Temperature parameter for attention. Default: 0.25.

    Shape:
        - Input: (B, N, D) where B is batch size, N is number of nodes, D is in_channels.
        - Output: (B, N, out_channels)
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        num_heads: int = 4,
        nb_random_features: int = 30,
        dropout: float = 0.0,
        tau: float = 0.25,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_heads = num_heads
        self.nb_random_features = nb_random_features
        self.dropout = dropout
        self.tau = tau

        # Q, K, V projections
        self.Wq = nn.Linear(in_channels, out_channels * num_heads)
        self.Wk = nn.Linear(in_channels, out_channels * num_heads)
        self.Wv = nn.Linear(in_channels, out_channels * num_heads)

        # Output projection
        self.Wo = nn.Linear(out_channels * num_heads, out_channels)

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        self.Wq.reset_parameters()
        self.Wk.reset_parameters()
        self.Wv.reset_parameters()
        self.Wo.reset_parameters()

    def forward(self, x: Tensor, tau: Optional[float] = None) -> Tensor:
        """Forward pass.

        Args:
            x: Input node features of shape (B, N, in_channels).
            tau: Optional temperature override.

        Returns:
            Updated node features of shape (B, N, out_channels).
        """
        B, N = x.size(0), x.size(1)
        tau = tau if tau is not None else self.tau

        # Project to Q, K, V
        query = self.Wq(x).reshape(B, N, self.num_heads, self.out_channels)
        key = self.Wk(x).reshape(B, N, self.num_heads, self.out_channels)
        value = self.Wv(x).reshape(B, N, self.num_heads, self.out_channels)

        # Create projection matrix dynamically based on input
        dim = query.shape[-1]
        # Use a deterministic seed based on layer dimensions for reproducibility
        seed = (self.in_channels * 1000 + self.out_channels) % 10000
        projection_matrix = create_projection_matrix(
            self.nb_random_features, dim, seed=seed, device=query.device
        )

        # Apply kernelized attention
        z_next = kernelized_softmax(
            query, key, value, projection_matrix, tau=tau
        )  # [B, N, H, D]

        # Aggregate heads and return
        return self.Wo(z_next.flatten(-2, -1))  # [B, N, out_channels]

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.out_channels}, num_heads={self.num_heads})"
        )


__all__ = ["NodeFormerConv"]
