"""Preprocessing utilities for hypergraph neural networks."""

from typing import Optional

import numpy as np
import scipy.sparse as sp
import torch
from torch import Tensor

from pyg_hyper_nn.layers.utils import create_coo_from_edge_index, ssm2tst


def construct_incidence_matrix(
    hyperedge_index: Tensor,
    num_nodes: int,
    num_hyperedges: Optional[int] = None,
) -> Tensor:
    """Construct sparse incidence matrix H from hyperedge index.

    The incidence matrix H has shape (num_nodes, num_hyperedges) where
    H[i, j] = 1 if node i is in hyperedge j, else 0.

    Args:
        hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            First row contains node indices, second row contains hyperedge indices.
        num_nodes: Total number of nodes.
        num_hyperedges: Total number of hyperedges. If None, inferred from hyperedge_index.

    Returns:
        Sparse incidence matrix of shape (num_nodes, num_hyperedges).
    """
    device = hyperedge_index.device

    if hyperedge_index.shape[1] == 0:
        num_hyperedges = num_hyperedges or 0
        return torch.sparse_coo_tensor(
            torch.empty((2, 0), dtype=torch.long, device=device),
            torch.empty(0, dtype=torch.float32, device=device),
            (num_nodes, num_hyperedges),
            device=device,
        )

    vertex = hyperedge_index[0]  # Node indices
    edges = hyperedge_index[1]  # Hyperedge indices

    if num_hyperedges is None:
        num_hyperedges = int(edges.max().item()) + 1

    # Normalize indices to start from 0
    vertex_normalized = vertex - vertex.min()
    edges_normalized = edges - edges.min()

    # Create sparse matrix indices and values
    indices = torch.stack([vertex_normalized, edges_normalized])
    values = torch.ones(hyperedge_index.shape[1], dtype=torch.float32, device=device)

    # Construct and return sparse tensor
    return torch.sparse_coo_tensor(
        indices, values, (num_nodes, num_hyperedges), device=device
    )


def clique_expansion(
    hyperedge_index: Tensor,
    num_nodes: Optional[int] = None,
) -> Tensor:
    """Convert hypergraph to graph using clique expansion.

    Creates edges between all pairs of nodes in each hyperedge.
    Formally, for each hyperedge e, creates edges (u,v) for all u,v in e.

    Args:
        hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            Row 0 contains node indices, row 1 contains hyperedge indices.
        num_nodes: Number of nodes. If None, inferred from hyperedge_index.

    Returns:
        edge_index: Graph edge indices of shape (2, num_clique_edges).

    Example:
        >>> hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
        >>> edge_index = clique_expansion(hyperedge_index)
        >>> # Creates edges within each hyperedge: (0,1), (0,2), (1,2), (1,3), (2,3)
    """
    device = hyperedge_index.device
    vertex, edges = hyperedge_index[0], hyperedge_index[1]

    # Handle empty hypergraph
    if hyperedge_index.shape[1] == 0:
        return torch.empty((2, 0), dtype=torch.long, device=device)

    if num_nodes is None:
        num_nodes = int(vertex.max().item()) + 1

    num_hyperedges = int(edges.max().item()) + 1

    # Group nodes by hyperedge
    edge_list = []

    for e_idx in range(num_hyperedges):
        mask = edges == e_idx
        nodes_in_edge = vertex[mask]

        # Create all pairs (including self-loops)
        num_nodes_in_edge = len(nodes_in_edge)
        for i in range(num_nodes_in_edge):
            for j in range(num_nodes_in_edge):
                if i != j:  # Exclude self-loops
                    edge_list.append([nodes_in_edge[i].item(), nodes_in_edge[j].item()])

    if len(edge_list) == 0:
        # Empty hypergraph: return empty edge_index
        return torch.empty((2, 0), dtype=torch.long, device=device)

    # Convert to tensor
    edge_index = torch.tensor(edge_list, dtype=torch.long, device=device).t()

    # Remove duplicates by converting to set and back
    # PyG expects edge_index to potentially have duplicates (they are summed in aggregation)
    # But we coalesce here to reduce memory
    return torch.unique(edge_index, dim=1)


def phenomnn_expansion(
    hyperedge_index: Tensor,
    num_nodes: int,
    norm_type: str = "full",
) -> tuple[Tensor, Tensor, Tensor]:
    """Compute PhenomNN expansion: normalized adjacency matrix, degree matrix, and identity.

    This implements the preprocessing for PhenomNN models, computing the normalized
    adjacency matrix A_beta using either full normalization or node normalization.

    Args:
        hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
        num_nodes: Number of nodes in the hypergraph.
        norm_type: Type of normalization to apply:
            - "full": Full symmetric normalization D^{-1/2} (H B H^T + I) D^{-1/2}
            - "node": Node degree normalization D^{-1/2} (H H^T + I) D^{-1/2}

    Returns:
        Tuple of (A_beta, D_beta, I) where:
            - A_beta: Normalized adjacency matrix (sparse tensor)
            - D_beta: Row-sum degree matrix (sparse diagonal tensor)
            - I: Identity matrix (sparse diagonal tensor)

    Example:
        >>> hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
        >>> A_beta, D_beta, I = phenomnn_expansion(hyperedge_index, num_nodes=3)
        >>> # A_beta is the normalized adjacency matrix
    """
    device = hyperedge_index.device

    # Handle empty hypergraph
    if hyperedge_index.numel() == 0:
        indices = torch.arange(num_nodes, device=device).unsqueeze(0).repeat(2, 1)
        values = torch.ones(num_nodes, device=device)
        I = torch.sparse_coo_tensor(indices, values, (num_nodes, num_nodes))  # noqa: E741
        A_beta = I.clone()
        D_beta = I.clone()
        return A_beta, D_beta, I

    # Create incidence matrix H (num_nodes x num_edges)
    H = create_coo_from_edge_index(hyperedge_index, num_nodes=num_nodes)

    if norm_type == "full":
        # 1. H x B x H^{T} with full normalization
        colsum = np.array(H.sum(0), dtype=float)
        r_inv = np.power(colsum, -1).flatten()
        r_inv[np.isinf(r_inv)] = 0.0
        B = sp.diags(r_inv)

        A_beta = H.dot(B).dot(H.transpose())
        I = sp.eye(A_beta.shape[0])  # noqa: E741
        A_beta = A_beta + I

        # 2. D^{-1/2} x A_beta x D^{-1/2}
        rowsum = np.array(A_beta.sum(1), dtype=float)
        r_inv_sqrt = np.power(rowsum, -0.5).flatten()
        r_inv_sqrt[np.isinf(r_inv_sqrt)] = 0.0
        D = sp.diags(r_inv_sqrt)

        A_beta = D.dot(A_beta).dot(D)

        # Compute degree matrix
        rowsum_norm = np.array(A_beta.sum(1))
        rowsum_norm_flat = rowsum_norm.flatten()
        D_beta = sp.diags(rowsum_norm_flat)

    elif norm_type == "node":
        # Node normalization: H x H^{T} + I
        A_beta = H.dot(H.transpose())
        I = sp.eye(A_beta.shape[0])  # noqa: E741
        A_beta = A_beta + I

        # D^{-1/2} x A_beta x D^{-1/2}
        rowsum = np.array(A_beta.sum(1), dtype=float)
        r_inv_sqrt = np.power(rowsum, -0.5).flatten()
        r_inv_sqrt[np.isinf(r_inv_sqrt)] = 0.0
        D = sp.diags(r_inv_sqrt)

        A_beta = D.dot(A_beta).dot(D)

        # Compute degree matrix
        rowsum_norm = np.array(A_beta.sum(1))
        rowsum_norm_flat = rowsum_norm.flatten()
        D_beta = sp.diags(rowsum_norm_flat)

    else:
        msg = f"Unknown normalization type: {norm_type}"
        raise ValueError(msg)

    # Convert to torch sparse tensors
    return ssm2tst(A_beta), ssm2tst(D_beta), ssm2tst(I)


__all__ = ["clique_expansion", "construct_incidence_matrix", "phenomnn_expansion"]
