"""Sheaf builder for diagonal sheaf Laplacian construction.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

This module implements the restriction map predictor that learns diagonal blocks
for sheaf hypergraph neural networks (SheafHyperGNN).
"""

from typing import Literal

import torch
import torch.nn.functional as F
from torch import Tensor, nn
from torch_scatter import scatter, scatter_add, scatter_mean

from pyg_hyper_nn.layers.mlp import MLP


def predict_blocks_var1(
    x: Tensor, e: Tensor, hyperedge_index: Tensor, sheaf_lin: nn.Module, sheaf_act: str
) -> Tensor:
    """Predict diagonal sheaf blocks using MLP(x_v || e_j).

    Variant 1: Hyperedge features e are given explicitly.

    Args:
        x: Node features of shape (num_nodes, F).
        e: Hyperedge features of shape (num_edges, F).
        hyperedge_index: Hyperedge indices of shape (2, num_pairs).
        sheaf_lin: MLP to predict sheaf blocks.
        sheaf_act: Activation function ("sigmoid" or "tanh").

    Returns:
        Predicted diagonal values of shape (num_pairs, d).
    """
    row, col = hyperedge_index

    # Get features for each node-edge pair
    xs = torch.index_select(x, dim=0, index=row)
    es = torch.index_select(e, dim=0, index=col)

    # Predict sheaf blocks: sigma(MLP(x_v || h_e))
    h_sheaf = torch.cat((xs, es), dim=-1)  # (num_pairs, 2F)
    h_sheaf = sheaf_lin(h_sheaf)  # (num_pairs, d)

    if sheaf_act == "sigmoid":
        return F.sigmoid(h_sheaf)
    if sheaf_act == "tanh":
        return F.tanh(h_sheaf)
    return h_sheaf


def predict_blocks_var2(
    x: Tensor, hyperedge_index: Tensor, sheaf_lin: nn.Module, sheaf_act: str
) -> Tensor:
    """Predict diagonal sheaf blocks with e_j = mean(x_v).

    Variant 2: Hyperedge features computed as mean of incident node features.

    Args:
        x: Node features of shape (num_nodes, F).
        hyperedge_index: Hyperedge indices of shape (2, num_pairs).
        sheaf_lin: MLP to predict sheaf blocks.
        sheaf_act: Activation function ("sigmoid" or "tanh").

    Returns:
        Predicted diagonal values of shape (num_pairs, d).
    """
    row, col = hyperedge_index

    # Compute edge features as mean of node features
    e = scatter_mean(x[row], col, dim=0)

    xs = torch.index_select(x, dim=0, index=row)
    es = torch.index_select(e, dim=0, index=col)

    # Predict sheaf blocks
    h_sheaf = torch.cat((xs, es), dim=-1)
    h_sheaf = sheaf_lin(h_sheaf)

    if sheaf_act == "sigmoid":
        return F.sigmoid(h_sheaf)
    if sheaf_act == "tanh":
        return F.tanh(h_sheaf)
    return h_sheaf


def predict_blocks_var3(
    x: Tensor,
    hyperedge_index: Tensor,
    sheaf_lin: nn.Module,
    sheaf_lin2: nn.Module,
    sheaf_act: str,
) -> Tensor:
    """Predict diagonal sheaf blocks with e_j = sum(phi(x_v)).

    Variant 3: Universal approximation according to Equivariant Hypergraph
    Diffusion Neural Operators. Uses learned projection before aggregation.

    Args:
        x: Node features of shape (num_nodes, F).
        hyperedge_index: Hyperedge indices of shape (2, num_pairs).
        sheaf_lin: MLP to predict sheaf blocks.
        sheaf_lin2: MLP to project node features before aggregation.
        sheaf_act: Activation function ("sigmoid" or "tanh").

    Returns:
        Predicted diagonal values of shape (num_pairs, d).
    """
    row, col = hyperedge_index

    xs = torch.index_select(x, dim=0, index=row)

    # Apply learned projection phi(x_v) to node features
    x_e = sheaf_lin2(x)
    # Aggregate projected features: sum of phi(x_v) over nodes in each edge
    e = scatter_add(x_e[row], col, dim=0)
    es = torch.index_select(e, dim=0, index=col)

    # Predict sheaf blocks
    h_sheaf = torch.cat((xs, es), dim=-1)
    h_sheaf = sheaf_lin(h_sheaf)

    if sheaf_act == "sigmoid":
        return F.sigmoid(h_sheaf)
    if sheaf_act == "tanh":
        return F.tanh(h_sheaf)
    return h_sheaf


def predict_blocks_cp_decomp(
    x: Tensor,
    hyperedge_index: Tensor,
    cp_W: nn.Module,
    cp_V: nn.Module,
    sheaf_lin: nn.Module,
    sheaf_act: str,
) -> Tensor:
    """Predict diagonal sheaf blocks using CP decomposition.

    Variant 4: CP decomposition - uses element-wise multiplication to compute
    hyperedge features. This implements a universal approximator according to
    "Equivariant Hypergraph Diffusion Neural Operators".

    Args:
        x: Node features of shape (num_nodes, F).
        hyperedge_index: Hyperedge indices of shape (2, num_pairs).
        cp_W: MLP for node feature projection (F+1 → F).
        cp_V: MLP for edge feature projection (F → F).
        sheaf_lin: MLP to predict sheaf blocks.
        sheaf_act: Activation function ("sigmoid" or "tanh").

    Returns:
        Predicted diagonal values of shape (num_pairs, d).
    """
    row, col = hyperedge_index

    # Get node features for each pair
    xs = torch.index_select(x, dim=0, index=row)

    # Append ones column and project: tanh(W([x_v; 1]))
    xs_ones = torch.cat((xs, torch.ones(xs.shape[0], 1, device=xs.device)), dim=-1)
    xs_ones_proj = torch.tanh(cp_W(xs_ones))  # (num_pairs, F)

    # Aggregate using element-wise multiplication: prod(tanh(W([x_v; 1])))
    xs_prod = scatter(xs_ones_proj, col, dim=0, reduce="mul")  # (num_edges, F)

    # Project and add mean aggregation: ReLU(V(prod)) + ReLU(sum(x_v))
    e = torch.relu(cp_V(xs_prod))  # (num_edges, F)
    e = e + torch.relu(scatter_add(x[row], col, dim=0))  # (num_edges, F)

    # Get edge features for each pair
    es = torch.index_select(e, dim=0, index=col)

    # Predict sheaf blocks: sigma(MLP(x_v || h_e))
    h_sheaf = torch.cat((xs, es), dim=-1)
    h_sheaf = sheaf_lin(h_sheaf)

    if sheaf_act == "sigmoid":
        return F.sigmoid(h_sheaf)
    if sheaf_act == "tanh":
        return F.tanh(h_sheaf)
    return h_sheaf


class SheafBuilderDiag(nn.Module):
    """Build diagonal sheaf Laplacian for hypergraph diffusion.

    Predicts diagonal restriction maps for each (node, hyperedge) pair
    using learned MLPs. The sheaf blocks are dxd diagonal matrices where
    d is the stalk dimension.

    Args:
        hidden_channels: Hidden layer dimension for node/edge features.
        stalk_dim: Dimension of stalks (d).
        prediction_type: How to compute hyperedge features:
            - "MLP_var1": Use given edge features
            - "MLP_var2": Edge features as mean(node features)
            - "MLP_var3": Edge features as sum(MLP(node features))
            - "cp_decomp": CP decomposition with element-wise multiplication
        sheaf_act: Activation for sheaf prediction ("sigmoid", "tanh", "none").
        sheaf_dropout: Whether to apply dropout to sheaf predictions.
        dropout: Dropout probability.
        special_head: Add a head with diagonal [0,...,0,1] (similar to standard conv).
        input_norm: Whether to use input normalization in MLPs.
    """

    def __init__(
        self,
        hidden_channels: int,
        stalk_dim: int,
        prediction_type: Literal[
            "MLP_var1", "MLP_var2", "MLP_var3", "cp_decomp"
        ] = "MLP_var2",
        sheaf_act: str = "sigmoid",
        sheaf_dropout: bool = False,
        dropout: float = 0.5,
        special_head: bool = False,
        input_norm: bool = False,
    ):
        super().__init__()

        self.hidden_channels = hidden_channels
        self.d = stalk_dim
        self.prediction_type = prediction_type
        self.sheaf_act = sheaf_act
        self.sheaf_dropout = sheaf_dropout
        self.dropout = dropout
        self.special_head = special_head

        # Main MLP to predict diagonal elements
        self.sheaf_lin = MLP(
            in_channels=2 * hidden_channels,
            hidden_channels=hidden_channels,
            out_channels=self.d,
            num_layers=1,
            dropout=0.0,
            normalization="ln",
            input_norm=input_norm,
        )

        # Additional MLPs for variant 3
        if self.prediction_type == "MLP_var3":
            self.sheaf_lin2 = MLP(
                in_channels=hidden_channels,
                hidden_channels=hidden_channels,
                out_channels=hidden_channels,
                num_layers=1,
                dropout=0.0,
                normalization="ln",
                input_norm=input_norm,
            )
        else:
            self.sheaf_lin2 = None

        # Additional MLPs for CP decomposition
        if self.prediction_type == "cp_decomp":
            self.cp_W = MLP(
                in_channels=hidden_channels + 1,
                hidden_channels=hidden_channels,
                out_channels=hidden_channels,
                num_layers=1,
                dropout=0.0,
                normalization="ln",
                input_norm=input_norm,
            )
            self.cp_V = MLP(
                in_channels=hidden_channels,
                hidden_channels=hidden_channels,
                out_channels=hidden_channels,
                num_layers=1,
                dropout=0.0,
                normalization="ln",
                input_norm=input_norm,
            )
        else:
            self.cp_W = None
            self.cp_V = None

        # For testing: store predicted sheaf values
        self.h_sheaf: Tensor | None = None

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        self.sheaf_lin.reset_parameters()
        if self.sheaf_lin2 is not None:
            self.sheaf_lin2.reset_parameters()
        if self.cp_W is not None:
            self.cp_W.reset_parameters()
        if self.cp_V is not None:
            self.cp_V.reset_parameters()

    def forward(
        self, x: Tensor, e: Tensor, hyperedge_index: Tensor
    ) -> tuple[Tensor, Tensor]:
        """Predict sheaf restriction maps.

        Args:
            x: Node features of shape (Nd, F) where N is num_nodes.
            e: Hyperedge features of shape (Ed, F) where E is num_edges.
            hyperedge_index: Edge indices of shape (2, num_pairs).

        Returns:
            Tuple of (h_sheaf_index, h_sheaf_attributes):
                - h_sheaf_index: Expanded indices of shape (2, num_pairs*d).
                - h_sheaf_attributes: Diagonal values of shape (num_pairs*d,).
        """
        num_nodes = x.shape[0] // self.d
        num_edges = e.shape[0] // self.d  # Infer from e's shape, not hyperedge_index

        # Average features across stalk dimension: (Nd x f) -> (N x f)
        x = x.view(num_nodes, self.d, x.shape[-1]).mean(1)  # (N, f)
        e = e.view(num_edges, self.d, e.shape[-1]).mean(1)  # (E, f)

        # Predict diagonal elements for each (node, edge) pair
        if self.prediction_type == "MLP_var1":
            h_sheaf = predict_blocks_var1(
                x, e, hyperedge_index, self.sheaf_lin, self.sheaf_act
            )
        elif self.prediction_type == "MLP_var2":
            h_sheaf = predict_blocks_var2(
                x, hyperedge_index, self.sheaf_lin, self.sheaf_act
            )
        elif self.prediction_type == "MLP_var3":
            assert self.sheaf_lin2 is not None
            h_sheaf = predict_blocks_var3(
                x, hyperedge_index, self.sheaf_lin, self.sheaf_lin2, self.sheaf_act
            )
        elif self.prediction_type == "cp_decomp":
            assert self.cp_W is not None
            assert self.cp_V is not None
            h_sheaf = predict_blocks_cp_decomp(
                x, hyperedge_index, self.cp_W, self.cp_V, self.sheaf_lin, self.sheaf_act
            )
        else:
            msg = f"Unknown prediction_type: {self.prediction_type}"
            raise NotImplementedError(msg)

        # Apply dropout
        if self.sheaf_dropout:
            h_sheaf = F.dropout(h_sheaf, p=self.dropout, training=self.training)

        # Special head: force last diagonal entry to 1, others to learned values
        if self.special_head:
            new_head_mask = [1.0] * (self.d - 1) + [0.0]
            new_head = [0.0] * (self.d - 1) + [1.0]
            h_sheaf = h_sheaf * torch.tensor(
                new_head_mask, device=x.device
            ) + torch.tensor(new_head, device=x.device)

        # Store for testing
        self.h_sheaf = h_sheaf  # (num_pairs, d)

        # Reshape to vector of all diagonal elements
        h_sheaf_attributes = h_sheaf.reshape(-1)  # (num_pairs*d,)

        # Expand indices from NxE to (Nd)x(Ed) matrix
        # Each scalar index [i,j] becomes d diagonal entries in the dxd block
        d_range = (
            torch.arange(self.d, device=x.device).view(1, -1, 1).repeat(2, 1, 1)
        )  # (2, d, 1)
        hyperedge_index = hyperedge_index.unsqueeze(1)  # (2, 1, K)
        hyperedge_index = self.d * hyperedge_index + d_range  # (2, d, K)
        hyperedge_index = hyperedge_index.permute(0, 2, 1).reshape(2, -1)  # (2, d*K)
        h_sheaf_index = hyperedge_index

        return h_sheaf_index, h_sheaf_attributes


__all__ = [
    "SheafBuilderDiag",
    "predict_blocks_var1",
    "predict_blocks_var2",
    "predict_blocks_var3",
]
