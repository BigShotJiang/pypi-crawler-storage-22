"""Sheaf hypergraph convolution layers.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

This module implements diagonal sheaf Laplacian diffusion for hypergraphs using
learned restriction maps on the diagonal of dxd blocks (SheafHyperGNN).
"""

from typing import Literal

import torch
import torch_sparse
from torch import Tensor, nn
from torch_geometric.nn.conv import MessagePassing
from torch_scatter import scatter_add

from pyg_hyper_nn.layers.mlp import MLP
from pyg_hyper_nn.layers.sheaf_utils import generate_indices_general, sparse_diagonal
from pyg_hyper_nn.layers.utils import zeros


def normalisation_matrices(
    x: Tensor,
    hyperedge_index: Tensor,
    alpha: Tensor,
    num_nodes: int,
    num_edges: int,
    d: int,
    norm_type: Literal[
        "degree_norm", "sym_degree_norm", "block_norm", "sym_block_norm"
    ] = "degree_norm",
) -> tuple[Tensor, Tensor]:
    """Compute normalization matrices D and B for sheaf Laplacian.

    Args:
        x: Node features (used for device).
        hyperedge_index: Expanded sheaf indices of shape (2, num_pairs*d).
        alpha: Sheaf diagonal values of shape (num_pairs*d,).
        num_nodes: Number of nodes.
        num_edges: Number of hyperedges.
        d: Stalk dimension.
        norm_type: Type of normalization to apply.

    Returns:
        Tuple of (D_inv, B_inv) normalization tensors.
    """
    if norm_type == "degree_norm":
        # D^-1: inverse node degrees
        D = scatter_add(
            x.new_ones(hyperedge_index.size(1)),
            hyperedge_index[0],
            dim=0,
            dim_size=num_nodes * d,
        )
        D = 1.0 / D
        D[torch.isinf(D)] = 0.0

        # B^-1: inverse hyperedge degrees
        B = scatter_add(
            x.new_ones(hyperedge_index.size(1)),
            hyperedge_index[1],
            dim=0,
            dim_size=num_edges * d,
        )
        B = 1.0 / B
        B[torch.isinf(B)] = 0.0

        return D, B

    if norm_type == "sym_degree_norm":
        # D^-1/2: symmetric node normalization
        D = scatter_add(
            x.new_ones(hyperedge_index.size(1)),
            hyperedge_index[0],
            dim=0,
            dim_size=num_nodes * d,
        )
        D = D ** (-0.5)
        D[torch.isinf(D)] = 0.0

        # B^-1: inverse hyperedge degrees
        B = scatter_add(
            x.new_ones(hyperedge_index.size(1)),
            hyperedge_index[1],
            dim=0,
            dim_size=num_edges * d,
        )
        B = 1.0 / B
        B[torch.isinf(B)] = 0.0

        return D, B

    if norm_type == "block_norm":
        # Uses predicted sheaf values (alpha) for normalization
        D = scatter_add(
            alpha * alpha, hyperedge_index[0], dim=0, dim_size=num_nodes * d
        )
        D = 1.0 / D
        D[torch.isinf(D)] = 0.0

        B = scatter_add(
            x.new_ones(hyperedge_index.size(1)),
            hyperedge_index[1],
            dim=0,
            dim_size=num_edges * d,
        )
        B = 1.0 / B
        B[torch.isinf(B)] = 0.0

        return D, B

    if norm_type == "sym_block_norm":
        # Symmetric normalization with sheaf values
        D = scatter_add(
            alpha * alpha, hyperedge_index[0], dim=0, dim_size=num_nodes * d
        )
        D = D ** (-0.5)
        D[torch.isinf(D)] = 0.0

        B = scatter_add(
            x.new_ones(hyperedge_index.size(1)),
            hyperedge_index[1],
            dim=0,
            dim_size=num_edges * d,
        )
        B = 1.0 / B
        B[torch.isinf(B)] = 0.0

        return D, B

    msg = f"Unknown norm_type: {norm_type}"
    raise NotImplementedError(msg)


class HyperDiffusionDiagSheafConv(MessagePassing):
    """Sheaf Laplacian diffusion layer with diagonal blocks.

    Implements Y = (I - D^-1/2 L D^-1/2) X where L is the sheaf Laplacian
    constructed from learned diagonal restriction maps.

    Args:
        in_channels: Input feature dimension.
        out_channels: Output feature dimension.
        d: Stalk dimension (diagonal block size).
        device: Device to place tensors on.
        norm_type: Normalization type for the Laplacian.
        left_proj: Whether to apply left projection before diffusion.
        input_norm: Whether to use input normalization in MLPs.
        residual: Whether to add residual connection.
        bias: Whether to use bias in linear layers.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        d: int,
        device: torch.device | str,
        norm_type: Literal[
            "degree_norm", "sym_degree_norm", "block_norm", "sym_block_norm"
        ] = "degree_norm",
        left_proj: bool = False,
        input_norm: bool = False,
        residual: bool = False,
        bias: bool = True,
        clear_flag: bool = False,
        **kwargs,
    ):
        kwargs.setdefault("aggr", "add")
        super().__init__(flow="source_to_target", node_dim=0, **kwargs)

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.d = d
        self.norm_type = norm_type
        self.left_proj = left_proj
        self.input_norm = input_norm
        self.residual = residual
        self.clear_flag = clear_flag

        if self.left_proj:
            self.lin_left_proj = MLP(
                in_channels=d,
                hidden_channels=d,
                out_channels=d,
                num_layers=1,
                dropout=0.0,
                normalization="ln",
                input_norm=self.input_norm,
            )
        else:
            self.lin_left_proj = None

        self.lin = MLP(
            in_channels=in_channels,
            hidden_channels=out_channels,
            out_channels=out_channels,
            num_layers=1,
            dropout=0.0,
            normalization="ln",
            input_norm=self.input_norm,
        )

        if bias:
            self.bias = nn.Parameter(torch.empty(out_channels))
        else:
            self.register_parameter("bias", None)

        self.device = torch.device(device) if isinstance(device, str) else device

        # Cache for identity matrices (reused across forward passes)
        self.I_mask: Tensor | None = None
        self.Id: Tensor | None = None

        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        if self.lin_left_proj is not None:
            self.lin_left_proj.reset_parameters()
        self.lin.reset_parameters()
        zeros(self.bias)

        # Clear cached matrices
        self.I_mask = None
        self.Id = None

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        alpha: Tensor,
        num_nodes: int,
        num_edges: int,
    ) -> Tensor:
        """Forward pass: sheaf Laplacian diffusion.

        Args:
            x: Node features of shape (Nd, F).
            hyperedge_index: Expanded sheaf indices of shape (2, num_pairs*d).
            alpha: Sheaf diagonal values of shape (num_pairs*d,).
            num_nodes: Number of nodes.
            num_edges: Number of hyperedges.

        Returns:
            Output features of shape (Nd, F).
        """
        # Optional left projection: apply MLP to each stalk
        if self.lin_left_proj is not None:
            x = x.t().reshape(-1, self.d)  # (F, Nd) -> (F*N, d)
            x = self.lin_left_proj(x)
            x = x.reshape(-1, num_nodes * self.d).t()  # (F*N, d) -> (Nd, F)

        # Apply main linear transformation
        x = self.lin(x)
        data_x = x  # Store for residual

        # Compute normalization matrices
        D_inv, B_inv = normalisation_matrices(
            x, hyperedge_index, alpha, num_nodes, num_edges, self.d, self.norm_type
        )

        # Apply symmetric normalization if needed
        if self.norm_type in ["sym_degree_norm", "sym_block_norm"]:
            x = D_inv.unsqueeze(-1) * x

        # Construct sparse incidence matrices H and H^T
        H = torch.sparse_coo_tensor(
            hyperedge_index,
            alpha,
            size=(num_nodes * self.d, num_edges * self.d),
            device=x.device,
        )
        H_t = torch.sparse_coo_tensor(
            hyperedge_index.flip([0]),
            alpha,
            size=(num_edges * self.d, num_nodes * self.d),
            device=x.device,
        )

        # Create sparse diagonal matrices
        B_inv_sparse = sparse_diagonal(
            B_inv, shape=(num_edges * self.d, num_edges * self.d)
        )
        D_inv_sparse = sparse_diagonal(
            D_inv, shape=(num_nodes * self.d, num_nodes * self.d)
        )

        # Coalesce all sparse tensors
        B_inv_sparse = B_inv_sparse.coalesce()
        H_t = H_t.coalesce()
        H = H.coalesce()
        D_inv_sparse = D_inv_sparse.coalesce()

        # Compute -L = -D^-1 H B^-1 H^T (using sparse-sparse matrix multiplication)
        minus_L = torch_sparse.spspmm(
            B_inv_sparse.indices(),
            B_inv_sparse.values(),
            H_t.indices(),
            H_t.values(),
            B_inv_sparse.shape[0],
            B_inv_sparse.shape[1],
            H_t.shape[1],
        )
        minus_L = torch_sparse.spspmm(
            H.indices(),
            H.values(),
            minus_L[0],
            minus_L[1],
            H.shape[0],
            H.shape[1],
            H_t.shape[1],
        )
        minus_L = torch_sparse.spspmm(
            D_inv_sparse.indices(),
            D_inv_sparse.values(),
            minus_L[0],
            minus_L[1],
            D_inv_sparse.shape[0],
            D_inv_sparse.shape[1],
            H_t.shape[1],
        )
        minus_L = torch.sparse_coo_tensor(
            minus_L[0],
            minus_L[1],
            size=(num_nodes * self.d, num_nodes * self.d),
            device=x.device,
        )

        # Prepare identity mask (cached for efficiency)
        # Clear cache if device changed or clear_flag is set (for multi-graph scenarios)
        if self.I_mask is not None and self.I_mask.device != x.device:
            self.I_mask = None
            self.Id = None

        if self.I_mask is None or self.clear_flag:
            I_mask_indices = torch.stack(
                [
                    torch.arange(num_nodes, device=x.device),
                    torch.arange(num_nodes, device=x.device),
                ],
                dim=0,
            )
            I_mask_indices = generate_indices_general(I_mask_indices, self.d)
            I_mask_values = torch.ones(I_mask_indices.shape[1], device=x.device)
            self.I_mask = torch.sparse_coo_tensor(
                I_mask_indices,
                I_mask_values,
                size=(num_nodes * self.d, num_nodes * self.d),
                device=x.device,
            )

            self.Id = sparse_diagonal(
                torch.ones(num_nodes * self.d, device=x.device),
                shape=(num_nodes * self.d, num_nodes * self.d),
            )

        # Change sign of block diagonal entries
        minus_L = minus_L.coalesce()
        minus_L = torch.sparse_coo_tensor(
            minus_L.indices(), minus_L.values(), minus_L.size(), device=x.device
        )
        minus_L = minus_L - 2 * minus_L.mul(self.I_mask)

        # Add identity: I - L
        assert self.Id is not None, "Id cache should be initialized"
        minus_L = self.Id + minus_L

        # Apply diffusion: (I - L) X
        minus_L = minus_L.coalesce()
        out = torch_sparse.spmm(
            minus_L.indices(), minus_L.values(), minus_L.shape[0], minus_L.shape[1], x
        )

        # Add bias and residual
        if self.bias is not None:
            out = out + self.bias

        if self.residual:
            out = out + data_x

        return out


__all__ = [
    "HyperDiffusionDiagSheafConv",
    "normalisation_matrices",
]
