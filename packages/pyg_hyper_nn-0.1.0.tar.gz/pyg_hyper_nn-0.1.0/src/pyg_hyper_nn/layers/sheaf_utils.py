"""Utility functions for Sheaf hypergraph neural networks.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

This module implements helper functions for sheaf-based hypergraph learning (SheafHyperGNN),
including matrix power operations, sparse diagonal construction, and index generation.
"""

import torch
from torch import Tensor


def batched_sym_matrix_pow(matrices: Tensor, p: float) -> Tensor:
    """Compute matrix power using Singular Value Decomposition.

    Uses SVD which is faster than eigendecomposition for large batches.

    Args:
        matrices: Batch of symmetric matrices of shape (batch, N, N).
        p: Power to raise matrices to.

    Returns:
        Matrix power of each input matrix of shape (batch, N, N).
    """
    # SVD is much faster than eigh for large batches
    vecs, vals, _ = torch.linalg.svd(matrices)

    # Filter out small singular values (numerical stability)
    good = (
        vals > vals.max(-1, True).values * vals.size(-1) * torch.finfo(vals.dtype).eps
    )
    vals = vals.pow(p).where(
        good, torch.zeros((), device=matrices.device, dtype=matrices.dtype)
    )

    # Reconstruct matrix using U * S^p * V^T
    return (vecs * vals.unsqueeze(-2)) @ torch.transpose(vecs, -2, -1)


def sparse_diagonal(diag: Tensor, shape: tuple[int, int]) -> Tensor:
    """Create sparse diagonal matrix from diagonal values.

    Args:
        diag: Diagonal values of shape (N,).
        shape: Shape of output matrix (N, N).

    Returns:
        Sparse diagonal matrix of shape (N, N).
    """
    r, c = shape
    assert r == c, f"Shape must be square, got {shape}"

    indexes = torch.arange(r, device=diag.device)
    indexes = torch.stack([indexes, indexes], dim=0)

    return torch.sparse_coo_tensor(indexes, diag, shape, device=diag.device)


def generate_indices_general(indexes: Tensor, d: int) -> Tensor:
    """Generate block-diagonal indices for sheaf Laplacian construction.

    Expands scalar indices [i,j] to block indices for dxd blocks:
    [i,j] -> [d*i, d*i+1, ..., d*i+d-1; d*j, d*j+1, ..., d*j+d-1]

    Args:
        indexes: Edge indices of shape (2, E).
        d: Block dimension (stalk dimension).

    Returns:
        Expanded indices of shape (2, E*d*d).
    """
    d_range = torch.arange(d, device=indexes.device)
    d_range_edges = d_range.repeat(d).view(-1, 1)  # 0,1..d,0,1..d.. (d*d elems)
    d_range_nodes = d_range.repeat_interleave(d).view(
        -1, 1
    )  # 0,0..0,1,1..1..d,d..d (d*d elems)

    indexes = indexes.unsqueeze(1)

    large_indexes_0 = d * indexes[0] + d_range_nodes
    large_indexes_0 = large_indexes_0.permute((1, 0)).reshape(1, -1)
    large_indexes_1 = d * indexes[1] + d_range_edges
    large_indexes_1 = large_indexes_1.permute((1, 0)).reshape(1, -1)
    return torch.concat((large_indexes_0, large_indexes_1), 0)


__all__ = [
    "batched_sym_matrix_pow",
    "generate_indices_general",
    "sparse_diagonal",
]
