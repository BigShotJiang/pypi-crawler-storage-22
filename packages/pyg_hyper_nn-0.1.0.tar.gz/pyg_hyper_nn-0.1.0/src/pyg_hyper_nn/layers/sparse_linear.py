"""Sparse linear layer for hypergraph positional encodings.

This module implements a linear layer that operates on sparse tensors,
used for encoding hypergraph structure information in HyperGT.
"""

import math
from typing import ClassVar

import torch
from torch import Tensor
from torch.nn import Module, init
from torch.nn.parameter import Parameter


class SparseLinear(Module):
    """Linear transformation for sparse tensors.

    This layer performs matrix multiplication with sparse input tensors,
    commonly used for positional encodings based on sparse incidence matrices.

    Args:
        in_features: Size of each input sample.
        out_features: Size of each output sample.
        bias: If True, adds a learnable bias. Default: True.

    Shape:
        - Input: (*, in_features) where * means any number of dimensions.
          Input must be a sparse tensor.
        - Output: (*, out_features)
    """

    __constants__: ClassVar[list[str]] = ["in_features", "out_features"]
    in_features: int
    out_features: int
    weight: Tensor

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
    ) -> None:
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.empty((out_features, in_features)))
        if bias:
            self.bias = Parameter(torch.empty(out_features))
        else:
            self.register_parameter("bias", None)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Initialize parameters using Kaiming uniform initialization."""
        init.kaiming_uniform_(self.weight, a=math.sqrt(5))

        if self.bias is not None:
            fan_in, _ = init._calculate_fan_in_and_fan_out(self.weight)  # noqa: SLF001
            bound = 1 / math.sqrt(fan_in) if fan_in > 0 else 0
            init.uniform_(self.bias, -bound, bound)

    def forward(self, sparse_input: Tensor) -> Tensor:
        """Forward pass with sparse input.

        Args:
            sparse_input: Sparse tensor of shape (*, in_features).

        Returns:
            Output tensor of shape (*, out_features).
        """
        # Sparse matrix multiplication: sparse_input @ weight.T
        wb = torch.sparse.mm(sparse_input, self.weight.T)

        if self.bias is not None:
            return wb + self.bias
        return wb

    def extra_repr(self) -> str:
        """Extra representation of module for printing."""
        return f"in_features={self.in_features}, out_features={self.out_features}, bias={self.bias is not None}"


__all__ = ["SparseLinear"]
