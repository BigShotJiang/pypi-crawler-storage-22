"""Utility functions for TMPHN (Tensor Message Passing Hypergraph Network).

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

This module provides helper functions for TMPHN, including neighbor dictionary
construction for tensor-based message passing on hypergraphs.
"""

from torch import Tensor


def build_neighbor_dict(hyperedge_index: Tensor) -> dict[int, list[list[int]]]:
    """Build neighbor dictionary from hyperedge_index.

    Creates a mapping from node_id to list of hyperedges containing that node.
    Each hyperedge is represented as a list of node IDs.

    Args:
        hyperedge_index: Hyperedge indices of shape (2, num_pairs).
            Row 0 contains node indices, row 1 contains edge indices.

    Returns:
        Dictionary mapping node_id -> list of hyperedges (each hyperedge is a list of node_ids).

    Example:
        >>> hyperedge_index = torch.tensor([[0, 1, 2, 1, 3], [0, 0, 0, 1, 1]])
        >>> neig_dict = build_neighbor_dict(hyperedge_index)
        >>> neig_dict
        {0: [[0, 1, 2]], 1: [[0, 1, 2], [1, 3]], 2: [[0, 1, 2]], 3: [[1, 3]]}
    """
    V, E = hyperedge_index

    # First, build edge_dict: edge_id -> list of node_ids
    edge_dict: dict[int, list[int]] = {}
    for i in range(hyperedge_index.shape[1]):
        edge_id = E[i].item()
        node_id = V[i].item()
        if edge_id not in edge_dict:
            edge_dict[edge_id] = []
        edge_dict[edge_id].append(node_id)

    # Build neighbor dictionary: node_id -> list of edges containing this node
    num_nodes = V.max().item() + 1
    neig_dict: dict[int, list[list[int]]] = {i: [] for i in range(num_nodes)}

    for nodes in edge_dict.values():
        for node_id in nodes:
            neig_dict[node_id].append(nodes.copy())

    return neig_dict


__all__ = [
    "build_neighbor_dict",
]
