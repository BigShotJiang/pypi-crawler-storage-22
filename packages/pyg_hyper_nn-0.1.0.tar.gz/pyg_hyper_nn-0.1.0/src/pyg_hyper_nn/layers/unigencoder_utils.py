"""Utility functions for PlainUnigencoder pooling matrix computation.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

This module implements the uni_expansion preprocessing for PlainUnigencoder,
which computes pooling matrices based on node feature similarity.
"""

import torch
import torch.nn.functional as F
from torch import Tensor


def build_edge_dict(hyperedge_index: Tensor) -> dict[int, list[int]]:
    """Build hyperedge dictionary from hyperedge_index.

    Creates a mapping from edge_id to list of node_ids. Adds self-loop edges
    for any isolated nodes (nodes not in any hyperedge).

    Args:
        hyperedge_index: Hyperedge indices of shape (2, num_pairs).
            Row 0 contains node indices, row 1 contains edge indices.

    Returns:
        Dictionary mapping edge_id -> list of node_ids in that edge.

    Example:
        >>> hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 0, 1, 1]])
        >>> edge_dict = build_edge_dict(hyperedge_index)
        >>> edge_dict
        {0: [0, 1], 1: [2, 3]}
    """
    V, E = hyperedge_index

    # Build edge dictionary: edge_id -> [node_ids]
    edge_dict = {}
    for i in range(hyperedge_index.shape[1]):
        edge_id = E[i].item()
        node_id = V[i].item()
        if edge_id not in edge_dict:
            edge_dict[edge_id] = []
        edge_dict[edge_id].append(node_id)

    # Find nodes that already have self-loop edges (edges with single node)
    self_set = set()
    for nodes in edge_dict.values():
        if len(nodes) == 1:
            self_set.add(nodes[0])

    # Add self-loop edges for nodes not in self_set
    num_nodes = V.max().item() + 1
    num_existing_edges = len(edge_dict)

    if len(self_set) < num_nodes:
        edge_counter = 0
        for node_id in range(num_nodes):
            if node_id not in self_set:
                new_edge_id = num_existing_edges + edge_counter
                edge_dict[new_edge_id] = [node_id]
                edge_counter += 1

    return edge_dict


def count_node_edges(edge_dict: dict[int, list[int]]) -> dict[int, int]:
    """Count number of edges each node appears in.

    Args:
        edge_dict: Dictionary mapping edge_id -> list of node_ids.

    Returns:
        Dictionary mapping node_id -> number of edges containing that node.

    Example:
        >>> edge_dict = {0: [0, 1], 1: [1, 2]}
        >>> count_node_edges(edge_dict)
        {0: 0, 1: 1, 2: 0}  # Node 1 appears in 2 edges (counts from 0)
    """
    node_num_edge = {}
    for nodes in edge_dict.values():
        for node_id in nodes:
            if node_id not in node_num_edge:
                node_num_edge[node_id] = 0
            else:
                node_num_edge[node_id] += 1
    return node_num_edge


def compute_pooling_matrices(
    x: Tensor,
    hyperedge_index: Tensor,
    threshold: float = 0.5,
    norm_type: int = 0,
    init_val: float = 1.0,
    init_type: int = 0,
) -> tuple[Tensor, Tensor]:
    """Compute pooling matrices Pv and PvT for PlainUnigencoder.

    Implements the uni_expansion preprocessing from DHG-Bench. This function
    groups nodes based on cosine similarity (for threshold >= -1.0) or other
    strategies, then applies normalization.

    Args:
        x: Node features of shape (num_nodes, feature_dim).
        hyperedge_index: Hyperedge indices of shape (2, num_pairs).
        threshold: Grouping threshold. Default: 0.5.
            - If threshold >= -1.0: Group edges by cosine similarity
            - If -2.0 <= threshold < -1.0: Each node becomes separate group
            - If threshold < -2.0: Similar to middle range with init values
        norm_type: Normalization type (0, 1, 2, 3, or other). Default: 0.
            - 0: Row-normalize Pv, column-normalize PvT (sum rows to 1)
            - 1: Column-normalize Pv, column-normalize PvT
            - 2: Column-normalize Pv, row-normalize PvT
            - 3: Row-normalize Pv, row-normalize PvT
            - Other: No normalization
        init_val: Initial value for pooling matrix entries. Default: 1.0.
        init_type: Initialization type (0 or 1). Default: 0.
            - 0: Use init_val for all entries
            - 1: Scale init_val by node degree for self-loops

    Returns:
        Tuple of (Pv, PvT) sparse COO tensors.
        - Pv: Pooling matrix of shape (num_groups, num_nodes)
        - PvT: Transpose pooling matrix of shape (num_nodes, num_groups)

    Example:
        >>> x = torch.randn(100, 16)
        >>> hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
        >>> Pv, PvT = compute_pooling_matrices(x, hyperedge_index, threshold=0.5)
        >>> Pv.shape, PvT.shape
        (torch.Size([num_groups, 100]), torch.Size([100, num_groups]))
    """
    # Build edge dictionary with self-loops for all nodes
    edge_dict = build_edge_dict(hyperedge_index)
    node_num_edge = count_node_edges(edge_dict)

    V, _ = hyperedge_index
    num_nodes = V.max().item() + 1

    # Initialize pooling matrix indices and values
    pv_rows: list[int] = []
    pv_cols: list[int] = []
    pv_init_val: list[float] = []

    n_count = 0

    if threshold >= -1.0:
        # Cosine similarity-based grouping
        # Normalize features to unit vectors
        norm = F.normalize(x, p=2.0, dim=-1)  # [num_nodes, feature_dim]
        sim = torch.mm(norm, norm.t())  # [num_nodes, num_nodes]

        for i in range(len(edge_dict)):
            neighbor_indices = edge_dict.get(i, [])

            if len(neighbor_indices) > 1:
                # Multi-node edge: check cosine similarity
                idx = torch.tensor(neighbor_indices)
                # Extract submatrix of similarities for nodes in this edge
                edge_sim = sim[idx][:, idx]
                # Set diagonal to 0 (ignore self-similarity)
                edge_sim[torch.eye(len(idx)).bool()] = 0.0
                # Compute mean similarity (excluding diagonal)
                sim_mean = edge_sim.sum() / (len(idx) * (len(idx) - 1))

                if sim_mean > threshold:
                    # Group nodes together (same group ID)
                    for p in neighbor_indices:
                        pv_rows.append(n_count)
                        pv_cols.append(p)
                        pv_init_val.append(1.0)
                    n_count += 1
                # If similarity too low, don't include this edge
            else:
                # Single-node edge (self-loop): always include
                for p in neighbor_indices:
                    pv_rows.append(n_count)
                    pv_cols.append(p)
                    pv_init_val.append(1.0)
                    n_count += 1

    elif -2.0 <= threshold < -1.0:
        # Each node in each edge becomes separate group
        for i in range(len(edge_dict)):
            neighbor_indices = edge_dict.get(i, [])
            for p in neighbor_indices:
                pv_rows.append(n_count)
                pv_cols.append(p)
                pv_init_val.append(1.0)
                n_count += 1

    else:  # threshold < -2.0
        # Similar to middle range, but with init values for self-loops
        for i in range(len(edge_dict)):
            neighbor_indices = edge_dict.get(i, [])
            for p in neighbor_indices:
                # Determine initial value
                if len(neighbor_indices) == 1:
                    # Self-loop edge
                    if p in node_num_edge:
                        if init_type == 1:
                            val = node_num_edge[p] * init_val
                        else:
                            val = init_val
                    else:
                        val = 1.0
                else:
                    # Multi-node edge
                    val = 1.0

                pv_rows.append(n_count)
                pv_cols.append(p)
                pv_init_val.append(val)

                # Increment group counter after last node in edge
                if p == neighbor_indices[-1]:
                    n_count += 1

    n_groups = n_count

    # Convert lists to tensors
    pv_rows_tensor = torch.tensor(pv_rows, dtype=torch.long)
    pv_cols_tensor = torch.tensor(pv_cols, dtype=torch.long)
    pv_values = torch.tensor(pv_init_val, dtype=torch.float32)
    pv_indices = torch.stack([pv_rows_tensor, pv_cols_tensor], dim=0)

    # Create sparse pooling matrices
    Pv = torch.sparse_coo_tensor(pv_indices, pv_values, size=(n_groups, num_nodes))
    PvT = torch.sparse_coo_tensor(
        torch.stack([pv_cols_tensor, pv_rows_tensor], dim=0),
        pv_values,
        size=(num_nodes, n_groups),
    )

    # Apply normalization
    if norm_type == 0:
        # Row-normalize Pv (sum of each row = 1)
        Pv_row_sum = torch.sparse.sum(Pv, dim=1)
        Pv_diag_indices = Pv_row_sum.indices()[0]
        Pv_diag_values = torch.reciprocal(Pv_row_sum.values())
        Pv_diag = torch.sparse_coo_tensor(
            torch.stack([Pv_diag_indices, Pv_diag_indices]),
            Pv_diag_values,
            size=(Pv_row_sum.shape[0], Pv_row_sum.shape[0]),
        )
        Pv = torch.sparse.mm(Pv_diag, Pv)

        # Column-normalize PvT (sum of each column = 1)
        PvT_col_sum = torch.sparse.sum(PvT, dim=1)
        PvT_diag_indices = PvT_col_sum.indices()[0]
        PvT_diag_values = torch.reciprocal(PvT_col_sum.values())
        PvT_diag = torch.sparse_coo_tensor(
            torch.stack([PvT_diag_indices, PvT_diag_indices]),
            PvT_diag_values,
            size=(PvT_col_sum.shape[0], PvT_col_sum.shape[0]),
        )
        PvT = torch.sparse.mm(PvT_diag, PvT)

    elif norm_type == 1:
        # Column-normalize Pv
        Pv_col_sum = torch.sparse.sum(Pv, dim=0)
        Pv_diag_indices = Pv_col_sum.indices()[0]
        Pv_diag_values = torch.reciprocal(Pv_col_sum.values())
        Pv_diag = torch.sparse_coo_tensor(
            torch.stack([Pv_diag_indices, Pv_diag_indices]),
            Pv_diag_values,
            size=(Pv_col_sum.shape[0], Pv_col_sum.shape[0]),
        )
        Pv = torch.sparse.mm(Pv, Pv_diag)

        # Column-normalize PvT
        PvT_col_sum = torch.sparse.sum(PvT, dim=1)
        PvT_diag_indices = PvT_col_sum.indices()[0]
        PvT_diag_values = torch.reciprocal(PvT_col_sum.values())
        PvT_diag = torch.sparse_coo_tensor(
            torch.stack([PvT_diag_indices, PvT_diag_indices]),
            PvT_diag_values,
            size=(PvT_col_sum.shape[0], PvT_col_sum.shape[0]),
        )
        PvT = torch.sparse.mm(PvT_diag, PvT)

    elif norm_type == 2:
        # Column-normalize Pv
        Pv_col_sum = torch.sparse.sum(Pv, dim=0)
        Pv_diag_indices = Pv_col_sum.indices()[0]
        Pv_diag_values = torch.reciprocal(Pv_col_sum.values())
        Pv_diag = torch.sparse_coo_tensor(
            torch.stack([Pv_diag_indices, Pv_diag_indices]),
            Pv_diag_values,
            size=(Pv_col_sum.shape[0], Pv_col_sum.shape[0]),
        )
        Pv = torch.sparse.mm(Pv, Pv_diag)

        # Row-normalize PvT
        PvT_row_sum = torch.sparse.sum(PvT, dim=0)
        PvT_diag_indices = PvT_row_sum.indices()[0]
        PvT_diag_values = torch.reciprocal(PvT_row_sum.values())
        PvT_diag = torch.sparse_coo_tensor(
            torch.stack([PvT_diag_indices, PvT_diag_indices]),
            PvT_diag_values,
            size=(PvT_row_sum.shape[0], PvT_row_sum.shape[0]),
        )
        PvT = torch.sparse.mm(PvT, PvT_diag)

    elif norm_type == 3:
        # Row-normalize Pv
        Pv_row_sum = torch.sparse.sum(Pv, dim=1)
        Pv_diag_indices = Pv_row_sum.indices()[0]
        Pv_diag_values = torch.reciprocal(Pv_row_sum.values())
        Pv_diag = torch.sparse_coo_tensor(
            torch.stack([Pv_diag_indices, Pv_diag_indices]),
            Pv_diag_values,
            size=(Pv_row_sum.shape[0], Pv_row_sum.shape[0]),
        )
        Pv = torch.sparse.mm(Pv_diag, Pv)

        # Row-normalize PvT
        PvT_row_sum = torch.sparse.sum(PvT, dim=0)
        PvT_diag_indices = PvT_row_sum.indices()[0]
        PvT_diag_values = torch.reciprocal(PvT_row_sum.values())
        PvT_diag = torch.sparse_coo_tensor(
            torch.stack([PvT_diag_indices, PvT_diag_indices]),
            PvT_diag_values,
            size=(PvT_row_sum.shape[0], PvT_row_sum.shape[0]),
        )
        PvT = torch.sparse.mm(PvT, PvT_diag)

    # For other norm_type values, no normalization is applied

    return Pv, PvT


__all__ = [
    "build_edge_dict",
    "compute_pooling_matrices",
    "count_node_edges",
]
