"""Utility functions for layer initialization and operations."""

import math

import numpy as np
import scipy.sparse as sp
import torch
from torch import Tensor


def glorot(tensor: Tensor | None) -> None:
    """Initialize tensor with Glorot/Xavier uniform initialization.

    Args:
        tensor: Tensor to initialize. If None, does nothing.
    """
    if tensor is not None:
        stdv = math.sqrt(6.0 / (tensor.size(-2) + tensor.size(-1)))
        tensor.data.uniform_(-stdv, stdv)


def zeros(tensor: Tensor | None) -> None:
    """Initialize tensor with zeros.

    Args:
        tensor: Tensor to initialize. If None, does nothing.
    """
    if tensor is not None:
        tensor.data.fill_(0)


def normalize_l2(x: Tensor) -> Tensor:
    """Row-wise L2 normalization of tensor.

    Args:
        x: Input tensor of shape (N, D).

    Returns:
        L2-normalized tensor of shape (N, D).
    """
    rownorm = x.detach().norm(dim=1, keepdim=True)
    scale = rownorm.pow(-1)
    scale[torch.isinf(scale)] = 0.0
    return x * scale


class SparseMM(torch.autograd.Function):
    """Sparse x dense matrix multiplication with autograd support.

    Implementation by Soumith Chintala:
    https://discuss.pytorch.org/t/does-pytorch-support-autograd-on-sparse-matrix/6156/7
    """

    @staticmethod
    def forward(ctx, m1: Tensor, m2: Tensor) -> Tensor:
        """Forward pass: sparse @ dense matrix multiplication.

        Args:
            ctx: Context for backward pass.
            m1: Sparse matrix.
            m2: Dense matrix.

        Returns:
            Result of m1 @ m2.
        """
        ctx.save_for_backward(m1, m2)
        return torch.mm(m1, m2)

    @staticmethod
    def backward(ctx, g: Tensor) -> tuple[Tensor | None, Tensor | None]:  # type: ignore[override]
        """Backward pass: compute gradients.

        Args:
            ctx: Context from forward pass.
            g: Gradient from upstream.

        Returns:
            Gradients with respect to m1 and m2.
        """
        m1, m2 = ctx.saved_tensors
        m1 = m1.float()
        m2 = m2.float()
        g1 = g2 = None

        if ctx.needs_input_grad[0]:
            g = g.float()
            g1 = torch.mm(g, m2.t())

        if ctx.needs_input_grad[1]:
            g = g.float()
            g2 = torch.mm(m1.t(), g)

        return g1, g2


def create_coo_from_edge_index(
    hyperedge_index: Tensor, num_nodes: int | None = None, num_edges: int | None = None
) -> sp.coo_matrix:
    """Convert hyperedge_index to scipy sparse COO matrix (incidence matrix).

    Args:
        hyperedge_index: Hyperedge indices in COO format of shape (2, num_pairs).
            Row 0 contains node indices, row 1 contains hyperedge indices.
        num_nodes: Number of nodes. If None, inferred from hyperedge_index.
        num_edges: Number of hyperedges. If None, inferred from hyperedge_index.

    Returns:
        Scipy COO sparse matrix H of shape (num_nodes, num_edges).
    """
    edge_index_cpu = hyperedge_index.cpu()

    row = edge_index_cpu[0].numpy()
    col = edge_index_cpu[1].numpy()
    values = np.ones(len(row))

    if num_nodes is None:
        num_nodes = int(row.max()) + 1 if len(row) > 0 else 0
    if num_edges is None:
        num_edges = int(col.max()) + 1 if len(col) > 0 else 0

    return sp.coo_matrix((values, (row, col)), shape=(num_nodes, num_edges)).astype(
        np.float32
    )


def ssm2tst(M: sp.spmatrix) -> Tensor:
    """Convert scipy sparse matrix to torch sparse tensor.

    Args:
        M: Scipy sparse matrix.

    Returns:
        PyTorch sparse COO tensor.
    """
    M = M.tocoo().astype(np.float32)  # type: ignore[union-attr]

    indices = torch.from_numpy(np.vstack((M.row, M.col))).long()
    values = torch.from_numpy(M.data)
    shape = torch.Size(M.shape)

    return torch.sparse_coo_tensor(indices, values, shape)


__all__ = [
    "SparseMM",
    "create_coo_from_edge_index",
    "glorot",
    "normalize_l2",
    "ssm2tst",
    "zeros",
]
