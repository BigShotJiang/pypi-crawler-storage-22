"""Model implementations for hypergraph neural networks."""

from pyg_hyper_nn.models.allset import AllSet, AllSetConv
from pyg_hyper_nn.models.cegnn import CEGAT, CEGCN
from pyg_hyper_nn.models.edgnn import EquivSetConv, EquivSetGNN
from pyg_hyper_nn.models.hgnn import HCHA, HGNN
from pyg_hyper_nn.models.hjrl import HJRL, HJRLConv
from pyg_hyper_nn.models.hnhn import HNHN, HNHNConv
from pyg_hyper_nn.models.hypergcn import HyperGCN
from pyg_hyper_nn.models.hypergt import HyperGT
from pyg_hyper_nn.models.hypernd import HyperND
from pyg_hyper_nn.models.legcn import LEGCN
from pyg_hyper_nn.models.mlp import MLP
from pyg_hyper_nn.models.phenomnn import PhenomNN, PhenomNNMultiConv
from pyg_hyper_nn.models.phenomnns import PhenomNNS, PhenomNNSMultiConv
from pyg_hyper_nn.models.sheaf_hypergnn import SheafHyperGNN
from pyg_hyper_nn.models.tfhnn import TFHNN
from pyg_hyper_nn.models.unigcn2 import UniGCNII, UniGCNIIConv
from pyg_hyper_nn.models.unigencoder import PlainUnigencoder
from pyg_hyper_nn.models.unignn import UniGINConv, UniGNN

__all__ = [
    "CEGAT",
    "CEGCN",
    "HCHA",
    "HGNN",
    "HJRL",
    "HNHN",
    "LEGCN",
    "MLP",
    "TFHNN",
    "AllSet",
    "AllSetConv",
    "EquivSetConv",
    "EquivSetGNN",
    "HJRLConv",
    "HNHNConv",
    "HyperGCN",
    "HyperGT",
    "HyperND",
    "PhenomNN",
    "PhenomNNMultiConv",
    "PhenomNNS",
    "PhenomNNSMultiConv",
    "PlainUnigencoder",
    "SheafHyperGNN",
    "UniGCNII",
    "UniGCNIIConv",
    "UniGINConv",
    "UniGNN",
]
