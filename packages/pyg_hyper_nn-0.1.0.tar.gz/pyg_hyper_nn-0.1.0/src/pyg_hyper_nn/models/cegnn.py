"""CEGCN and CEGAT models using clique expansion.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Note:
    These are baseline methods that convert hypergraphs to graphs via clique expansion,
    connecting all pairs of nodes within each hyperedge, then apply standard GNN models:
    - CEGCN: Clique Expansion + Graph Convolutional Network (GCN)
    - CEGAT: Clique Expansion + Graph Attention Network (GAT)
"""

from typing import Optional

import torch.nn.functional as F
from torch import Tensor, nn
from torch_geometric.nn import GATConv, GCNConv

from pyg_hyper_nn.layers.preprocessing import clique_expansion


class CEGCN(nn.Module):
    """Clique Expansion + GCN model.

    Converts hypergraphs to graphs using clique expansion, then applies
    standard GCN layers for node classification.

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features.
        out_channels: Number of output classes.
        num_layers: Number of GCN layers.
        dropout: Dropout probability. Default: 0.5.
        use_bn: Whether to use batch normalization. Default: True.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        dropout: float = 0.5,
        use_bn: bool = True,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.dropout = dropout
        self.use_bn = use_bn

        self.convs: nn.ModuleList = nn.ModuleList()
        self.bns = nn.ModuleList()

        # Clique expansion cache (computed once per forward pass)
        self._clique_cache: Optional[Tensor] = None

        if num_layers == 1:
            self.convs.append(GCNConv(in_channels, out_channels))
        else:
            self.convs.append(GCNConv(in_channels, hidden_channels))
            if use_bn:
                self.bns.append(nn.BatchNorm1d(hidden_channels))

            for _ in range(num_layers - 2):
                self.convs.append(GCNConv(hidden_channels, hidden_channels))
                if use_bn:
                    self.bns.append(nn.BatchNorm1d(hidden_channels))

            self.convs.append(GCNConv(hidden_channels, out_channels))

    def reset_parameters(self) -> None:
        """Reset all learnable parameters and clear cache."""
        self._clique_cache = None
        for conv in self.convs:
            conv.reset_parameters()  # type: ignore[union-attr]
        if self.use_bn:
            for bn in self.bns:
                bn.reset_parameters()  # type: ignore[union-attr]

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        # Clear cache if training (to recompute clique expansion)
        if self.training:
            self._clique_cache = None

        # Compute clique expansion if not cached
        if self._clique_cache is None:
            self._clique_cache = clique_expansion(hyperedge_index, num_nodes=x.shape[0])

        edge_index = self._clique_cache

        # Apply GCN layers
        for i, conv in enumerate(self.convs[:-1]):  # type: ignore[arg-type]
            x = conv(x, edge_index)
            if self.use_bn:
                x = self.bns[i](x)
            x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)

        return self.convs[-1](x, edge_index)

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers})"
        )


class CEGAT(nn.Module):
    """Clique Expansion + GAT model.

    Converts hypergraphs to graphs using clique expansion, then applies
    standard GAT (Graph Attention Network) layers for node classification.

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features.
        out_channels: Number of output classes.
        num_layers: Number of GAT layers.
        dropout: Dropout probability. Default: 0.5.
        heads: Number of attention heads for hidden layers. Default: 4.
        use_bn: Whether to use batch normalization. Default: True.
        concat: Whether to concatenate attention heads in hidden layers. Default: True.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        dropout: float = 0.5,
        heads: int = 4,
        use_bn: bool = True,
        concat: bool = True,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.dropout = dropout
        self.heads = heads
        self.use_bn = use_bn
        self.concat = concat

        self.convs: nn.ModuleList = nn.ModuleList()
        self.bns = nn.ModuleList()

        # Clique expansion cache (computed once per forward pass)
        self._clique_cache: Optional[Tensor] = None

        if num_layers == 1:
            self.convs.append(
                GATConv(
                    in_channels,
                    out_channels,
                    heads=1,
                    concat=False,
                )
            )
        else:
            # First layer
            self.convs.append(
                GATConv(
                    in_channels,
                    hidden_channels,
                    heads=heads,
                    concat=concat,
                )
            )
            if use_bn:
                dim1 = hidden_channels * heads if concat else hidden_channels
                self.bns.append(nn.BatchNorm1d(dim1))

            # Hidden layers
            for _ in range(num_layers - 2):
                in_dim = hidden_channels * heads if concat else hidden_channels
                self.convs.append(
                    GATConv(
                        in_dim,
                        hidden_channels,
                        heads=heads,
                        concat=concat,
                    )
                )
                if use_bn:
                    out_dim = hidden_channels * heads if concat else hidden_channels
                    self.bns.append(nn.BatchNorm1d(out_dim))

            # Final layer
            final_in = hidden_channels * heads if concat else hidden_channels
            self.convs.append(
                GATConv(
                    final_in,
                    out_channels,
                    heads=1,
                    concat=False,
                )
            )

    def reset_parameters(self) -> None:
        """Reset all learnable parameters and clear cache."""
        self._clique_cache = None
        for conv in self.convs:
            conv.reset_parameters()  # type: ignore[union-attr]
        if self.use_bn:
            for bn in self.bns:
                bn.reset_parameters()  # type: ignore[union-attr]

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        # Clear cache if training (to recompute clique expansion)
        if self.training:
            self._clique_cache = None

        # Compute clique expansion if not cached
        if self._clique_cache is None:
            self._clique_cache = clique_expansion(hyperedge_index, num_nodes=x.shape[0])

        edge_index = self._clique_cache

        # Apply GAT layers
        for i, conv in enumerate(self.convs[:-1]):  # type: ignore[arg-type]
            x = conv(x, edge_index)
            if self.use_bn:
                x = self.bns[i](x)
            x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)

        return self.convs[-1](x, edge_index)

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers}, heads={self.heads})"
        )


__all__ = ["CEGAT", "CEGCN"]
