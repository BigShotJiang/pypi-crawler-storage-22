"""EquivSetGNN (EDGNN) model for hypergraph node classification.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Reference:
    Huang, J., Wang, M., Lermen, F., Thost, V., Weißenberger, C., & Staudt, H. (2023).
    Equivariant hypergraph diffusion neural operators.
    In International Conference on Learning Representations (ICLR 2023).
    https://openreview.net/forum?id=RiTjKoscnNd

Note:
    Also referred to as ED-HNN (Equivariant Diffusion Hypergraph Neural Network).
    Paper: https://arxiv.org/abs/2207.06680
"""

from typing import Optional

import torch
from torch import Tensor, nn
from torch.nn import functional as functional_F
from torch_scatter import scatter

from pyg_hyper_nn.layers.mlp import MLP


class EquivSetConv(nn.Module):
    """Equivariant Set Convolution layer.

    Implements permutation-equivariant set operations with learnable MLPs
    and residual connections.

    Args:
        in_channels: Size of input features.
        out_channels: Size of output features.
        mlp1_layers: Number of layers in first MLP (node→hyperedge). Default: 1.
        mlp2_layers: Number of layers in second MLP (hyperedge→node). Default: 1.
        mlp3_layers: Number of layers in third MLP (output). Default: 1.
        aggr: Aggregation method ("add", "mean", "max"). Default: "add".
        alpha: Initial residual weight (0 to 1). Default: 0.5.
        dropout: Dropout probability. Default: 0.0.
        normalization: Normalization type ("bn", "ln", "none"). Default: "none".
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        mlp1_layers: int = 1,
        mlp2_layers: int = 1,
        mlp3_layers: int = 1,
        aggr: str = "add",
        alpha: float = 0.5,
        dropout: float = 0.0,
        normalization: str = "none",
    ):
        super().__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.aggr = aggr
        self.alpha = alpha

        # MLP 1: Node features → Hyperedge aggregation
        if mlp1_layers > 0:
            self.W1 = MLP(
                in_channels=in_channels,
                hidden_channels=out_channels,
                out_channels=out_channels,
                num_layers=mlp1_layers,
                dropout=dropout,
                normalization=normalization,
            )
        else:
            self.W1 = nn.Identity()

        # MLP 2: Hyperedge features → Node features
        if mlp2_layers > 0:
            self.W2 = MLP(
                in_channels=in_channels + out_channels,
                hidden_channels=out_channels,
                out_channels=out_channels,
                num_layers=mlp2_layers,
                dropout=dropout,
                normalization=normalization,
            )
        else:
            # If no MLP, just take the hyperedge features part
            self.W2 = None

        # MLP 3: Output transformation
        if mlp3_layers > 0:
            self.W3 = MLP(
                in_channels=out_channels,
                hidden_channels=out_channels,
                out_channels=out_channels,
                num_layers=mlp3_layers,
                dropout=dropout,
                normalization=normalization,
            )
        else:
            self.W3 = nn.Identity()

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        if isinstance(self.W1, MLP):
            self.W1.reset_parameters()
        if isinstance(self.W2, MLP):
            self.W2.reset_parameters()
        if isinstance(self.W3, MLP):
            self.W3.reset_parameters()

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        x0: Tensor,
    ) -> tuple[Tensor, Tensor]:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            x0: Initial node features from first layer for residual connection.

        Returns:
            Tuple of:
                - Updated node features of shape (num_nodes, out_channels).
                - Hyperedge embeddings of shape (num_hyperedges, out_channels).
        """
        num_nodes = x.shape[0]
        vertex, edges = hyperedge_index[0], hyperedge_index[1]

        # V2E: Aggregate nodes to hyperedges
        x_ve = self.W1(x)[vertex]  # [nnz, C]
        x_e = scatter(x_ve, edges, dim=0, reduce=self.aggr)  # [E, C]

        # E2V: Propagate hyperedges to nodes
        x_ev = x_e[edges]  # [nnz, C]

        if self.W2 is not None:
            # Concatenate original node features with hyperedge features
            x_ev = self.W2(torch.cat([x[vertex], x_ev], dim=-1))
        else:
            # Just use the hyperedge features part (skip first in_channels)
            pass

        x_v = scatter(x_ev, vertex, dim=0, reduce=self.aggr, dim_size=num_nodes)

        # Initial residual connection
        x = (1 - self.alpha) * x_v + self.alpha * x0

        # Final transformation
        x = self.W3(x)

        return x, x_e

    def __repr__(self) -> str:
        """String representation of the layer."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.out_channels}, alpha={self.alpha})"
        )


class EquivSetGNN(nn.Module):
    """Equivariant Set Graph Neural Network for hypergraphs.

    Implements equivariant set operations with deep residual connections
    and flexible MLP architectures.

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features.
        out_channels: Number of output classes.
        num_layers: Number of EquivSetConv layers. Default: 2.
        mlp1_layers: Number of layers in first MLP of each conv. Default: 2.
        mlp2_layers: Number of layers in second MLP of each conv. Default: 2.
        mlp3_layers: Number of layers in third MLP of each conv. Default: 2.
        decoder_layers: Number of layers in decoder MLP. Default: 2.
        alpha: Initial residual weight (0 to 1). Default: 0.5.
        aggr: Aggregation method ("add", "mean", "max"). Default: "add".
        dropout: Dropout probability. Default: 0.5.
        activation: Activation function ("relu", "prelu", "none"). Default: "relu".
        normalization: Normalization type ("bn", "ln", "none"). Default: "bn".
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int = 2,
        mlp1_layers: int = 2,
        mlp2_layers: int = 2,
        mlp3_layers: int = 2,
        decoder_layers: int = 2,
        alpha: float = 0.5,
        aggr: str = "add",
        dropout: float = 0.5,
        activation: str = "relu",
        normalization: str = "bn",
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.dropout = dropout

        # Activation function
        if activation == "relu":
            self.act = nn.ReLU()
        elif activation == "prelu":
            self.act = nn.PReLU()
        elif activation == "none":
            self.act = nn.Identity()
        else:
            msg = f"Activation must be 'relu', 'prelu', or 'none', got {activation}"
            raise ValueError(msg)

        # Input transformation
        self.lin_in = nn.Linear(in_channels, hidden_channels)

        # Equivariant set convolution
        self.conv = EquivSetConv(
            in_channels=hidden_channels,
            out_channels=hidden_channels,
            mlp1_layers=mlp1_layers,
            mlp2_layers=mlp2_layers,
            mlp3_layers=mlp3_layers,
            alpha=alpha,
            aggr=aggr,
            dropout=dropout,
            normalization=normalization,
        )

        # Decoder MLP
        self.decoder = MLP(
            in_channels=hidden_channels,
            hidden_channels=hidden_channels,
            out_channels=out_channels,
            num_layers=decoder_layers,
            dropout=dropout,
            normalization=normalization,
        )

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        self.lin_in.reset_parameters()
        self.conv.reset_parameters()
        self.decoder.reset_parameters()

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        # Input transformation
        x = functional_F.relu(self.lin_in(x))
        x = functional_F.dropout(x, p=self.dropout, training=self.training)
        x0 = x  # Store initial features for residual connections

        # Apply equivariant set convolutions
        for _ in range(self.num_layers):
            x, _edge_embed = self.conv(x, hyperedge_index, x0)
            x = self.act(x)
            x = functional_F.dropout(x, p=self.dropout, training=self.training)

        # Final classification
        return self.decoder(x)

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers})"
        )


__all__ = ["EquivSetConv", "EquivSetGNN"]
