"""HGNN and HCHA models for hypergraph node classification.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

References:
    - HGNN: Feng, Y., You, H., Zhang, Z., Ji, R., & Gao, Y. (2019).
      Hypergraph neural networks. In Proceedings of the AAAI Conference on
      Artificial Intelligence (Vol. 33, No. 01, pp. 3558-3565).
      https://cdn.aaai.org/ojs/4235/4235-13-7289-1-10-20190705.pdf

    - HCHA: Bai, S., Zhang, F., & Torr, P. H. (2021). Hypergraph convolution
      and hypergraph attention. Pattern Recognition, 110, 107637.
      https://www.sciencedirect.com/science/article/abs/pii/S0031320320304404
"""

from typing import Optional

from torch import Tensor, nn
from torch.nn import functional as functional_F

from pyg_hyper_nn.layers import HypergraphConv


class HGNN(nn.Module):
    """Hypergraph Neural Network (HGNN) model.

    Implements the HGNN architecture from "Hypergraph Neural Networks"
    (Feng et al., AAAI 2019), which uses symmetric degree normalization:
    D_v^{-1/2} H W D_e^{-1} H^T D_v^{-1/2}

    Faithfully ported from DHG-Bench implementation.

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features.
        out_channels: Number of output classes.
        num_layers: Number of convolution layers (minimum 1).
        dropout: Dropout probability. Default: 0.6.
        use_attention: If True, use attention mechanism. Default: False.
        heads: Number of attention heads (only used if use_attention=True).
            Default: 1.
        concat: If True, concatenate attention heads (only used if
            use_attention=True). Default: True.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        dropout: float = 0.6,
        use_attention: bool = False,
        heads: int = 1,
        concat: bool = True,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.dropout = dropout

        # Build convolution layers
        self.convs: nn.ModuleList = nn.ModuleList()
        if num_layers == 1:
            self.convs.append(
                HypergraphConv(
                    in_channels,
                    out_channels,
                    symdegnorm=True,
                    use_attention=use_attention,
                    heads=heads,
                    concat=concat,
                )
            )
        else:
            # First layer
            self.convs.append(
                HypergraphConv(
                    in_channels,
                    hidden_channels,
                    symdegnorm=True,
                    use_attention=use_attention,
                    heads=heads,
                    concat=concat,
                )
            )
            # Hidden layers
            for _ in range(num_layers - 2):
                self.convs.append(
                    HypergraphConv(
                        hidden_channels,
                        hidden_channels,
                        symdegnorm=True,
                        use_attention=use_attention,
                        heads=heads,
                        concat=concat,
                    )
                )
            # Output layer
            self.convs.append(
                HypergraphConv(
                    hidden_channels,
                    out_channels,
                    symdegnorm=True,
                    use_attention=use_attention,
                    heads=1,  # Output heads is 1
                    concat=True,
                )
            )

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        for conv in self.convs:
            conv.reset_parameters()  # type: ignore[misc]

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights of shape (num_hyperedges,).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        # Apply all but last convolution with activation and dropout
        for conv in self.convs[:-1]:  # type: ignore[assignment]
            x, _edge_embed = conv(x, hyperedge_index, hyperedge_weight)
            x = functional_F.elu(x)
            x = functional_F.dropout(x, p=self.dropout, training=self.training)

        # Apply last convolution without activation
        x, _edge_embed = self.convs[-1](x, hyperedge_index, hyperedge_weight)

        return x

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers})"
        )


class HCHA(nn.Module):
    """Hypergraph Convolution with Hypergraph Attention (HCHA) model.

    Implements the HCHA architecture from "Hypergraph convolution and
    hypergraph attention" (Bai et al., Pattern Recognition 2020), which
    uses asymmetric normalization (symdegnorm=False) without D_v^{-1/2}.

    Faithfully ported from DHG-Bench implementation.

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features.
        out_channels: Number of output classes.
        num_layers: Number of convolution layers (minimum 1).
        dropout: Dropout probability. Default: 0.6.
        use_attention: If True, use attention mechanism. Default: False.
        heads: Number of attention heads (only used if use_attention=True).
            Default: 1.
        concat: If True, concatenate attention heads (only used if
            use_attention=True). Default: True.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        dropout: float = 0.6,
        use_attention: bool = False,
        heads: int = 1,
        concat: bool = True,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.dropout = dropout

        # Build convolution layers with symdegnorm=False (HCHA)
        self.convs: nn.ModuleList = nn.ModuleList()
        if num_layers == 1:
            self.convs.append(
                HypergraphConv(
                    in_channels,
                    out_channels,
                    symdegnorm=False,  # Key difference: HCHA uses asymmetric normalization
                    use_attention=use_attention,
                    heads=heads,
                    concat=concat,
                )
            )
        else:
            # First layer
            self.convs.append(
                HypergraphConv(
                    in_channels,
                    hidden_channels,
                    symdegnorm=False,  # Key difference: HCHA uses asymmetric normalization
                    use_attention=use_attention,
                    heads=heads,
                    concat=concat,
                )
            )
            # Hidden layers
            for _ in range(num_layers - 2):
                self.convs.append(
                    HypergraphConv(
                        hidden_channels,
                        hidden_channels,
                        symdegnorm=False,  # Key difference: HCHA uses asymmetric normalization
                        use_attention=use_attention,
                        heads=heads,
                        concat=concat,
                    )
                )
            # Output layer
            self.convs.append(
                HypergraphConv(
                    hidden_channels,
                    out_channels,
                    symdegnorm=False,  # Key difference: HCHA uses asymmetric normalization
                    use_attention=use_attention,
                    heads=1,  # Output heads is 1
                    concat=True,
                )
            )

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        for conv in self.convs:
            conv.reset_parameters()  # type: ignore[misc]

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights of shape (num_hyperedges,).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        # Apply all but last convolution with activation and dropout
        for conv in self.convs[:-1]:  # type: ignore[assignment]
            x, _edge_embed = conv(x, hyperedge_index, hyperedge_weight)
            x = functional_F.elu(x)
            x = functional_F.dropout(x, p=self.dropout, training=self.training)

        # Apply last convolution without activation
        x, _edge_embed = self.convs[-1](x, hyperedge_index, hyperedge_weight)

        return x

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers})"
        )


__all__ = ["HCHA", "HGNN"]
