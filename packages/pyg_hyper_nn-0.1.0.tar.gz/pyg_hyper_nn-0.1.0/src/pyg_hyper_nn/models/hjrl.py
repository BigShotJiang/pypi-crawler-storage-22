"""HJRL model for hypergraph neural networks.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Reference:
    Ju, W., Luo, Y., Fang, Y., Zhang, Z., & Zhang, M. (2024).
    Hypergraph Joint Representation Learning for Hypervertices and Hyperedges via Cross Expansion.
    In Proceedings of the AAAI Conference on Artificial Intelligence (Vol. 38, pp. 8633-8641).
    https://openreview.net/forum?id=fxLaL5s6UH
"""

import math
from typing import Literal, Optional

import torch
import torch.nn.functional as F
from torch import Tensor, nn

from pyg_hyper_nn.layers.hjrl_utils import hjrl_preprocessing
from pyg_hyper_nn.layers.utils import SparseMM


class HJRLConv(nn.Module):
    """HJRL convolution layer with sparse matrix multiplication.

    Applies weight transformation followed by sparse adjacency multiplication:
    output = adj @ (input @ weight) + bias

    Args:
        in_features: Size of input features.
        out_features: Size of output features.
        activation: Activation function. Options: "relu", "elu", "leaky_relu", None.
            Default: "leaky_relu".
        neg_slope: Negative slope for leaky_relu. Default: 0.01.
        bias: If True, adds learnable bias. Default: False.

    Shape:
        - Input: features (num_nodes_or_edges, in_features)
        - Adj: sparse adjacency matrix
        - Output: (num_nodes_or_edges, out_features)
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        activation: Optional[Literal["relu", "elu", "leaky_relu"]] = "leaky_relu",
        neg_slope: float = 0.01,
        bias: bool = False,
    ):
        super().__init__()

        self.in_features = in_features
        self.out_features = out_features
        self.activation = activation
        self.neg_slope = neg_slope

        # Activation functions
        self.act_dict = {"relu": F.relu, "elu": F.elu, "leaky_relu": F.leaky_relu}

        self.weight = nn.Parameter(torch.empty(in_features, out_features))
        if bias:
            self.bias = nn.Parameter(torch.empty(out_features))
        else:
            self.register_parameter("bias", None)

        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Initialize parameters uniformly."""
        stdv = 1.0 / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input_features: Tensor, adj: Tensor) -> Tensor:
        """Forward pass with sparse matrix multiplication.

        Args:
            input_features: Input features of shape (num_items, in_features).
            adj: Sparse adjacency matrix.

        Returns:
            Output features of shape (num_items, out_features).
        """
        # Apply weight transformation: input @ weight
        support = torch.mm(input_features, self.weight)

        # Apply sparse adjacency: adj @ support
        output = SparseMM.apply(adj, support)

        # Add bias if present
        if self.bias is not None:
            output = output + self.bias

        # Apply activation
        if self.activation is not None:
            if self.activation == "leaky_relu":
                output = F.leaky_relu(output, negative_slope=self.neg_slope)
            else:
                output = self.act_dict[self.activation](output)

        return output

    def __repr__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self.in_features} -> {self.out_features})"


class HJRL(nn.Module):
    """HJRL model for node classification on hypergraphs.

    HJRL jointly learns node and edge representations by propagating information
    through four paths:
    - HHT: node features through node-node adjacency
    - H: edge features through node-edge incidence
    - HT: node features through edge-node incidence
    - HTH: edge features through edge-edge adjacency

    The final node representation combines HHT and H outputs, while edge
    representation combines HT and HTH outputs.

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features.
        out_channels: Number of output classes.
        num_layers: Number of convolution layers.
        activation: Activation function. Options: "relu", "elu", "leaky_relu".
            Default: "leaky_relu".
        neg_slope: Negative slope for leaky_relu. Default: 0.01.
        dropout: Dropout probability. Default: 0.6.
        cache_preprocessing: If True, cache preprocessing results. Default: True.

    Reference:
        Based on hypergraph joint representation learning.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        activation: Literal["relu", "elu", "leaky_relu"] = "leaky_relu",
        neg_slope: float = 0.01,
        dropout: float = 0.6,
        cache_preprocessing: bool = True,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.activation = activation
        self.neg_slope = neg_slope
        self.dropout = dropout
        self.cache_preprocessing = cache_preprocessing

        # Cached preprocessing results
        self._cached_data: Optional[tuple] = None
        self._cached_hyperedge_index: Optional[Tensor] = None

        # Build convolution layers
        self.convs: nn.ModuleList = nn.ModuleList()
        if num_layers == 1:
            # Single layer: no activation on output
            self.convs.append(HJRLConv(in_channels, out_channels, activation=None))
        else:
            # First layer
            self.convs.append(
                HJRLConv(in_channels, hidden_channels, activation, neg_slope)
            )
            # Middle layers
            for _ in range(num_layers - 2):
                self.convs.append(
                    HJRLConv(hidden_channels, hidden_channels, activation, neg_slope)
                )
            # Last layer: no activation
            self.convs.append(HJRLConv(hidden_channels, out_channels, activation=None))

    def reset_parameters(self) -> None:
        """Reset all learnable parameters and clear cache."""
        self._cached_data = None
        self._cached_hyperedge_index = None
        for layer in self.convs:
            layer.reset_parameters()  # type: ignore[union-attr]

    def _preprocess(
        self, x: Tensor, hyperedge_index: Tensor
    ) -> tuple[Tensor, Tensor, Tensor, Tensor, Tensor, Tensor, Tensor]:
        """Preprocess hypergraph data and cache if enabled.

        Args:
            x: Node features.
            hyperedge_index: Hyperedge indices.

        Returns:
            Tuple of (H_ini, H, HT, HHT, HTH, norm_X, norm_E).
        """
        # Check if we can reuse cache
        if (
            self.cache_preprocessing
            and self._cached_data is not None
            and self._cached_hyperedge_index is not None
            and torch.equal(self._cached_hyperedge_index, hyperedge_index)
        ):
            return self._cached_data

        # Compute preprocessing
        num_nodes = x.shape[0]
        num_edges = (
            int(hyperedge_index[1].max().item()) + 1
            if hyperedge_index.numel() > 0
            else 0
        )

        result = hjrl_preprocessing(hyperedge_index, x, num_nodes, num_edges)

        # Cache if enabled
        if self.cache_preprocessing:
            self._cached_data = result
            self._cached_hyperedge_index = hyperedge_index.clone()

        return result

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass with joint node-edge representation learning.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output node predictions of shape (num_nodes, out_channels).
        """
        # Preprocess to get normalized matrices
        H_ini, H, HT, HHT, HTH, _, _ = self._preprocess(x, hyperedge_index)

        # Move to same device as input
        device = x.device
        HHT = HHT.to(device)
        H = H.to(device)
        HT = HT.to(device)
        HTH = HTH.to(device)
        H_ini = H_ini.to(device)

        # Initialize features - use original input for nodes
        x_current = x
        # For edge features, aggregate node features through incidence matrix
        num_edges = (
            int(hyperedge_index[1].max().item()) + 1
            if hyperedge_index.numel() > 0
            else 0
        )
        if num_edges > 0:
            y_current = torch.zeros(num_edges, x.shape[1], device=device)
            for edge_id in range(num_edges):
                edge_mask = hyperedge_index[1] == edge_id
                edge_nodes = hyperedge_index[0][edge_mask]
                if edge_nodes.numel() > 0:
                    y_current[edge_id] = x[edge_nodes].mean(dim=0)
        else:
            y_current = torch.zeros(0, x.shape[1], device=device)

        # Single layer case
        if self.num_layers == 1:
            HHT_l = self.convs[0](x_current, HHT)
            H_l = self.convs[0](y_current, H)
            HT_l = self.convs[0](x_current, HT)
            HTH_l = self.convs[0](y_current, HTH)
        else:
            # Multi-layer case
            for conv in self.convs[:-1]:  # type: ignore[index]
                HHT_l = conv(x_current, HHT)
                H_l = conv(y_current, H)
                HT_l = conv(x_current, HT)
                HTH_l = conv(y_current, HTH)

                # Apply dropout
                HHT_l = F.dropout(HHT_l, p=self.dropout, training=self.training)
                H_l = F.dropout(H_l, p=self.dropout, training=self.training)
                HT_l = F.dropout(HT_l, p=self.dropout, training=self.training)
                HTH_l = F.dropout(HTH_l, p=self.dropout, training=self.training)

                # Combine for next layer
                x_current = HHT_l + H_l
                y_current = HT_l + HTH_l

            # Last layer
            HHT_l = self.convs[-1](x_current, HHT)
            H_l = self.convs[-1](y_current, H)
            HT_l = self.convs[-1](x_current, HT)
            HTH_l = self.convs[-1](y_current, HTH)

        # Apply final activation
        HHT_l = F.leaky_relu(HHT_l, negative_slope=self.neg_slope)
        H_l = F.leaky_relu(H_l, negative_slope=self.neg_slope)
        HT_l = F.leaky_relu(HT_l, negative_slope=self.neg_slope)
        HTH_l = F.leaky_relu(HTH_l, negative_slope=self.neg_slope)

        # Combine node and edge representations
        return HHT_l + H_l  # Node representation

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers})"
        )


__all__ = ["HJRL", "HJRLConv"]
