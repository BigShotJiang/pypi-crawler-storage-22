"""HNHN model for hypergraph neural networks.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Reference:
    Dong, Y., Sawin, W., & Bengio, Y. (2020).
    HNHN: Hypergraph Networks with Hyperedge Neurons.
    In ICML 2020 Workshop on Graph Representation Learning and Beyond.
    https://grlplus.github.io/papers/40.pdf
"""

from typing import Optional

import torch
import torch.nn.functional as F
from torch import Tensor, nn
from torch.nn import Linear
from torch_geometric.nn.conv import MessagePassing
from torch_scatter import scatter_add


class HNHNConv(MessagePassing):
    """HNHN convolution layer with two-stage message passing.

    Performs vertex→hyperedge→vertex message passing with degree-based
    normalization controlled by parameters alpha and beta.

    Args:
        in_channels: Size of input features.
        hidden_channels: Size of intermediate hyperedge features.
        out_channels: Size of output features.
        alpha: Exponent for hyperedge degree normalization. Default: -0.5.
        beta: Exponent for vertex degree normalization. Default: -0.5.
        nonlinear_inbetween: Apply ReLU between vertex→edge and edge→vertex.
            Default: True.

    Shape:
        - Input: Node features (num_nodes, in_channels)
        - Output: (node_output (num_nodes, out_channels),
                  edge_embeddings (num_edges, hidden_channels))
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        alpha: float = -0.5,
        beta: float = -0.5,
        nonlinear_inbetween: bool = True,
    ):
        super().__init__(node_dim=0, aggr="add")

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.alpha = alpha
        self.beta = beta
        self.nonlinear_inbetween = nonlinear_inbetween

        # Learnable transformations
        self.weight_v2e = Linear(in_channels, hidden_channels)
        self.weight_e2v = Linear(hidden_channels, out_channels)

        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Reset learnable parameters."""
        self.weight_v2e.reset_parameters()
        self.weight_e2v.reset_parameters()

    def _compute_normalization(
        self, hyperedge_index: Tensor, num_nodes: int, num_edges: int
    ) -> tuple[Tensor, Tensor, Tensor, Tensor]:
        """Compute degree-based normalization terms.

        Args:
            hyperedge_index: Hyperedge indices in COO format.
            num_nodes: Number of nodes.
            num_edges: Number of hyperedges.

        Returns:
            Tuple of (D_v_beta, D_e_beta_inv, D_e_alpha, D_v_alpha_inv).
        """
        device = hyperedge_index.device
        ones = torch.ones(hyperedge_index.shape[1], device=device)

        # Compute degrees
        D_v = scatter_add(
            ones, hyperedge_index[0], dim=0, dim_size=num_nodes
        )  # Node degrees
        D_e = scatter_add(
            ones, hyperedge_index[1], dim=0, dim_size=num_edges
        )  # Edge degrees

        # Alpha part: D_e^alpha normalization
        D_e_alpha = torch.pow(D_e, self.alpha)
        D_e_alpha[torch.isinf(D_e_alpha)] = 0

        # Sum of edge degrees for each node
        D_v_alpha = scatter_add(
            D_e[hyperedge_index[1]], hyperedge_index[0], dim=0, dim_size=num_nodes
        )
        D_v_alpha_inv = 1.0 / D_v_alpha
        D_v_alpha_inv[torch.isinf(D_v_alpha_inv)] = 0

        # Beta part: D_v^beta normalization
        D_v_beta = torch.pow(D_v, self.beta)
        D_v_beta[torch.isinf(D_v_beta)] = 0

        # Sum of node degrees for each edge
        D_e_beta = scatter_add(
            D_v[hyperedge_index[0]], hyperedge_index[1], dim=0, dim_size=num_edges
        )
        D_e_beta_inv = 1.0 / D_e_beta
        D_e_beta_inv[torch.isinf(D_e_beta_inv)] = 0

        return D_v_beta, D_e_beta_inv, D_e_alpha, D_v_alpha_inv

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        num_edges: Optional[int] = None,
    ) -> tuple[Tensor, Tensor]:
        """Forward pass with two-stage message passing.

        Args:
            x: Node features of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format.
            num_edges: Number of hyperedges. If None, inferred from hyperedge_index.

        Returns:
            Tuple of (node_output, edge_embeddings).
        """
        num_nodes = x.shape[0]

        if num_edges is None:
            if hyperedge_index.numel() > 0:
                num_edges = int(hyperedge_index[1].max().item()) + 1
            else:
                num_edges = 0

        # Compute normalization terms
        D_v_beta, D_e_beta_inv, D_e_alpha, D_v_alpha_inv = self._compute_normalization(
            hyperedge_index, num_nodes, num_edges
        )

        # Stage 1: Vertex → Hyperedge
        x = self.weight_v2e(x)
        x = D_v_beta.unsqueeze(-1) * x  # Apply D_v^beta

        self.flow = "source_to_target"
        edge_features = self.propagate(  # type: ignore
            hyperedge_index,  # type: ignore
            x=x,
            norm=D_e_beta_inv,
            size=(num_nodes, num_edges),
        )

        # Apply nonlinearity between stages
        if self.nonlinear_inbetween:
            edge_features = F.relu(edge_features)

        # Stage 2: Hyperedge → Vertex
        out = self.weight_e2v(edge_features)
        out = D_e_alpha.unsqueeze(-1) * out  # Apply D_e^alpha

        self.flow = "target_to_source"
        out = self.propagate(  # type: ignore
            hyperedge_index,  # type: ignore
            x=out,
            norm=D_v_alpha_inv,
            size=(num_nodes, num_edges),
        )

        return out, edge_features

    def message(self, x_j: Tensor, norm_i: Tensor) -> Tensor:  # type: ignore[override]
        """Compute messages with degree normalization.

        Args:
            x_j: Source features.
            norm_i: Normalization coefficients for target nodes.

        Returns:
            Normalized messages.
        """
        return norm_i.view(-1, 1) * x_j

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels})"
        )


class HNHN(nn.Module):
    """HNHN model for node classification on hypergraphs.

    HNHN uses two-stage message passing (vertex→edge→vertex) with learnable
    degree-based normalization parameters alpha and beta for flexible information
    aggregation.

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features.
        out_channels: Number of output classes.
        num_layers: Number of HNHN convolution layers.
        alpha: Exponent for hyperedge degree normalization. Default: -0.5.
        beta: Exponent for vertex degree normalization. Default: -0.5.
        dropout: Dropout probability. Default: 0.5.
        nonlinear_inbetween: Apply ReLU between v→e and e→v stages. Default: True.

    Reference:
        Based on hypergraph neural network with degree-aware normalization.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        alpha: float = -0.5,
        beta: float = -0.5,
        dropout: float = 0.5,
        nonlinear_inbetween: bool = True,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.alpha = alpha
        self.beta = beta
        self.dropout = dropout
        self.nonlinear_inbetween = nonlinear_inbetween

        # Build convolution layers
        self.convs: nn.ModuleList = nn.ModuleList()
        if num_layers == 1:
            self.convs.append(
                HNHNConv(
                    in_channels,
                    hidden_channels,
                    out_channels,
                    alpha=alpha,
                    beta=beta,
                    nonlinear_inbetween=nonlinear_inbetween,
                )
            )
        else:
            # First layer
            self.convs.append(
                HNHNConv(
                    in_channels,
                    hidden_channels,
                    hidden_channels,
                    alpha=alpha,
                    beta=beta,
                    nonlinear_inbetween=nonlinear_inbetween,
                )
            )
            # Middle layers
            for _ in range(num_layers - 2):
                self.convs.append(
                    HNHNConv(
                        hidden_channels,
                        hidden_channels,
                        hidden_channels,
                        alpha=alpha,
                        beta=beta,
                        nonlinear_inbetween=nonlinear_inbetween,
                    )
                )
            # Last layer
            self.convs.append(
                HNHNConv(
                    hidden_channels,
                    hidden_channels,
                    out_channels,
                    alpha=alpha,
                    beta=beta,
                    nonlinear_inbetween=nonlinear_inbetween,
                )
            )

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        for conv in self.convs:
            conv.reset_parameters()  # type: ignore[union-attr]

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        # Infer number of edges
        num_edges = None
        if hyperedge_index.numel() > 0:
            num_edges = int(hyperedge_index[1].max().item()) + 1

        # Single layer case
        if self.num_layers == 1:
            x, _ = self.convs[0](x, hyperedge_index, num_edges)
            return x

        # Multi-layer case
        for conv in self.convs[:-1]:  # type: ignore[index]
            x, _ = conv(x, hyperedge_index, num_edges)
            x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)

        # Last layer
        x, _ = self.convs[-1](x, hyperedge_index, num_edges)

        return x

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers}, alpha={self.alpha}, beta={self.beta})"
        )


__all__ = ["HNHN", "HNHNConv"]
