"""HyperGCN model for hypergraph neural networks.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Reference:
    Yadati, N., Nimishakavi, M., Yadav, P., Nitin, V., Louis, A., & Talukdar, P. (2019).
    HyperGCN: A new method for training graph convolutional networks on hypergraphs.
    In Advances in Neural Information Processing Systems (Vol. 32).
    https://proceedings.neurips.cc/paper/2019/file/1efa39bcaec6f3900149160693694536-Paper.pdf
"""

from typing import Optional

import torch.nn.functional as F
from torch import Tensor, nn

from pyg_hyper_nn.layers.hypergcn_conv import HyperGCNConv
from pyg_hyper_nn.layers.hypergcn_utils import get_hypergcn_he_dict, hypergcn_laplacian


class HyperGCN(nn.Module):
    """HyperGCN model for node classification on hypergraphs.

    HyperGCN converts hypergraphs to graphs using a novel supremum-infimum
    projection method that selects representative nodes based on feature projections.
    It supports two modes:
    - Fast mode: Precomputes graph approximation once
    - Slow mode: Reapproximates graph at each layer based on updated features

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features.
        out_channels: Number of output classes.
        num_layers: Number of convolution layers.
        dropout: Dropout probability. Default: 0.5.
        fast: If True, precompute structure once (fast mode).
              If False, reapproximate at each forward (slow but more accurate).
              Default: True.
        mediators: If True, use mediator nodes (two-star expansion).
                   If False, only connect supremum-infimum directly.
                   Default: True.

    Reference:
        "HyperGCN: A New Method For Training Graph Convolutional Networks on Hypergraphs"
        Yadati et al., NeurIPS 2019
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        dropout: float = 0.5,
        fast: bool = True,
        mediators: bool = True,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.dropout = dropout
        self.fast = fast
        self.mediators = mediators

        # Structure will be cached on first forward pass
        self.structure: Optional[Tensor] = None
        self._hyperedge_dict: Optional[dict[int, list[int]]] = None

        # Build convolution layers
        self.convs: nn.ModuleList = nn.ModuleList()
        if num_layers == 1:
            self.convs.append(
                HyperGCNConv(in_channels, out_channels, reapproximate=(not fast))
            )
        else:
            self.convs.append(
                HyperGCNConv(in_channels, hidden_channels, reapproximate=(not fast))
            )
            for _ in range(num_layers - 2):
                self.convs.append(
                    HyperGCNConv(
                        hidden_channels, hidden_channels, reapproximate=(not fast)
                    )
                )
            self.convs.append(
                HyperGCNConv(hidden_channels, out_channels, reapproximate=(not fast))
            )

    def reset_parameters(self) -> None:
        """Reset all learnable parameters and clear cache."""
        self.structure = None
        self._hyperedge_dict = None
        for layer in self.convs:
            layer.reset_parameters()  # type: ignore[union-attr]

    def _precompute_structure(
        self, x: Tensor, hyperedge_index: Tensor
    ) -> tuple[Tensor, dict[int, list[int]]]:
        """Precompute graph structure from hypergraph (fast mode only).

        Args:
            x: Node features of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format.

        Returns:
            Tuple of (structure tensor, hyperedge dictionary).
        """
        # Convert hyperedge_index to dictionary
        hyperedge_dict = get_hypergcn_he_dict(hyperedge_index)

        # Compute graph approximation
        X_np = x.cpu().detach().numpy()
        structure = hypergcn_laplacian(
            V=x.shape[0], E=hyperedge_dict, X=X_np, m=self.mediators
        )

        return structure, hyperedge_dict

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        # Precompute structure on first forward pass (fast mode only)
        if self.fast and self.structure is None:
            self.structure, self._hyperedge_dict = self._precompute_structure(
                x, hyperedge_index
            )
        elif not self.fast:
            # For slow mode, always compute hyperedge dict
            self._hyperedge_dict = get_hypergcn_he_dict(hyperedge_index)

        H = x

        # Apply convolutions
        for i, conv in enumerate(self.convs):
            H = F.relu(
                conv(
                    H,
                    structure=self.structure if self.fast else None,
                    hyperedge_dict=self._hyperedge_dict,
                    m=self.mediators,
                )
            )

            # Apply dropout to all but last layer
            if i < self.num_layers - 1:
                H = F.dropout(H, p=self.dropout, training=self.training)

        return H

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers}, fast={self.fast}, "
            f"mediators={self.mediators})"
        )


__all__ = ["HyperGCN"]
