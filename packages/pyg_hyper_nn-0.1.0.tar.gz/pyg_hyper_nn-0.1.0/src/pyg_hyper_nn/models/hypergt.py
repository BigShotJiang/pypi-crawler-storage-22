"""HyperGT: Hypergraph Transformer with Kernelized Attention.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Reference:
    Gao, Z., Zhang, C., Zhang, Z., Zhu, F., Li, J., & Yu, J. (2024).
    Hypergraph Transformer for Semi-Supervised Classification.
    In ICASSP 2024 - 2024 IEEE International Conference on Acoustics, Speech and Signal
    Processing (pp. 5690-5694).
    https://ieeexplore.ieee.org/stamp/stamp.jsp?tp=&arnumber=10446248

Note:
    Official implementation: https://github.com/zeroxleo/HyperGT
"""

from typing import Optional

import torch
import torch.nn.functional as F
from torch import Tensor, nn

from pyg_hyper_nn.layers.nodeformer_conv import NodeFormerConv
from pyg_hyper_nn.layers.preprocessing import construct_incidence_matrix
from pyg_hyper_nn.layers.sparse_linear import SparseLinear


class HyperGT(nn.Module):
    """HyperGT model with kernelized attention.

    This is the full HyperGT implementation using NodeFormer layers
    with O(N) complexity kernelized attention.

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features.
        out_channels: Number of output classes.
        num_layers: Number of NodeFormer layers.
        num_heads: Number of attention heads. Default: 4.
        nb_random_features: Number of random features for kernel. Default: 30.
        dropout: Dropout probability. Default: 0.0.
        use_bn: Whether to use layer normalization. Default: True.
        use_residual: Whether to use residual connections. Default: True.
        use_jk: Whether to use jumping knowledge. Default: False.
        use_hepe: Whether to use hyperedge positional encoding. Default: False.
        use_htepe: Whether to use hyperedge transpose positional encoding. Default: False.
        tau: Temperature parameter for attention. Default: 0.25.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        num_heads: int = 4,
        nb_random_features: int = 30,
        dropout: float = 0.0,
        use_bn: bool = True,
        use_residual: bool = True,
        use_jk: bool = False,
        use_hepe: bool = False,
        use_htepe: bool = False,
        tau: float = 0.25,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.num_heads = num_heads
        self.nb_random_features = nb_random_features
        self.dropout = dropout
        self.use_bn = use_bn
        self.use_residual = use_residual
        self.use_jk = use_jk
        self.use_hepe = use_hepe
        self.use_htepe = use_htepe
        self.tau = tau

        # Input projection
        self.fcs = nn.ModuleList()
        self.fcs.append(nn.Linear(in_channels, hidden_channels))

        # Layer normalization
        self.bns = nn.ModuleList()
        if use_bn:
            self.bns.append(nn.LayerNorm(hidden_channels))

        # NodeFormer layers
        self.convs: nn.ModuleList = nn.ModuleList()
        for _ in range(num_layers):
            self.convs.append(
                NodeFormerConv(
                    hidden_channels,
                    hidden_channels,
                    num_heads=num_heads,
                    nb_random_features=nb_random_features,
                    dropout=dropout,
                    tau=tau,
                )
            )
            if use_bn:
                self.bns.append(nn.LayerNorm(hidden_channels))

        # Output projection
        if use_jk:
            self.fcs.append(nn.Linear(hidden_channels * (num_layers + 1), out_channels))
        else:
            self.fcs.append(nn.Linear(hidden_channels, out_channels))

        # Positional encodings (will be initialized on first forward)
        self.he_sparse_encoder: Optional[SparseLinear] = None
        self.hte_sparse_encoder: Optional[SparseLinear] = None

        # Activation function
        self.activation = F.elu

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        for fc in self.fcs:
            fc.reset_parameters()  # type: ignore[union-attr]
        for conv in self.convs:
            conv.reset_parameters()  # type: ignore[union-attr]
        if self.use_bn:
            for bn in self.bns:
                bn.reset_parameters()  # type: ignore[union-attr]
        if self.he_sparse_encoder is not None:
            self.he_sparse_encoder.reset_parameters()
        if self.hte_sparse_encoder is not None:
            self.hte_sparse_encoder.reset_parameters()

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        num_nodes = x.shape[0]

        # Construct incidence matrix H
        H = construct_incidence_matrix(hyperedge_index, num_nodes)
        num_hyperedges = H.shape[1]

        # Initialize positional encodings on first forward
        if self.use_hepe and self.he_sparse_encoder is None:
            self.he_sparse_encoder = SparseLinear(
                num_hyperedges, self.hidden_channels
            ).to(x.device)

        if self.use_htepe and self.hte_sparse_encoder is None:
            self.hte_sparse_encoder = SparseLinear(num_nodes, self.hidden_channels).to(
                x.device
            )

        # Add batch dimension: [N, D] -> [1, N, D]
        x = x.unsqueeze(0)

        # Input projection
        z = self.fcs[0](x)  # [1, N, H]

        # Add positional encodings
        if self.use_hepe and self.he_sparse_encoder is not None:
            he_pe = self.he_sparse_encoder(H).unsqueeze(0)  # [1, num_hyperedges, H]
            # Pad to match node dimension
            if he_pe.shape[1] < z.shape[1]:
                padding = torch.zeros(
                    z.shape[0],
                    z.shape[1] - he_pe.shape[1],
                    z.shape[2],
                    device=z.device,
                )
                he_pe = torch.cat([he_pe, padding], dim=1)
            z = z + he_pe

        if self.use_htepe and self.hte_sparse_encoder is not None:
            H_T = H.t()  # Transpose incidence matrix
            hte_pe = self.hte_sparse_encoder(H_T).unsqueeze(0)  # [1, num_nodes, H]
            # Pad at beginning
            if hte_pe.shape[1] < z.shape[1]:
                padding = torch.zeros(
                    z.shape[0],
                    z.shape[1] - hte_pe.shape[1],
                    z.shape[2],
                    device=z.device,
                )
                hte_pe = torch.cat([padding, hte_pe], dim=1)
            z = z + hte_pe

        # First normalization and activation
        if self.use_bn:
            z = self.bns[0](z)
        z = self.activation(z)
        z = F.dropout(z, p=self.dropout, training=self.training)

        # Store layer outputs for jumping knowledge
        layer_outputs = []
        if self.use_jk:
            layer_outputs.append(z)

        # NodeFormer layers
        for i, conv in enumerate(self.convs):
            # Store input for residual
            z_input = z

            # Apply NodeFormer convolution
            z = conv(z, tau=self.tau)

            # Residual connection
            if self.use_residual:
                z = z + z_input

            # Normalization and activation
            if self.use_bn:
                z = self.bns[i + 1](z)
            z = self.activation(z)
            z = F.dropout(z, p=self.dropout, training=self.training)

            if self.use_jk:
                layer_outputs.append(z)

        # Jumping knowledge
        if self.use_jk:
            z = torch.cat(layer_outputs, dim=-1)

        # Remove batch dimension and apply output projection
        z = z.squeeze(0)  # [N, H]
        return self.fcs[-1](z)  # [N, out_channels]

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers}, num_heads={self.num_heads})"
        )


__all__ = ["HyperGT"]
