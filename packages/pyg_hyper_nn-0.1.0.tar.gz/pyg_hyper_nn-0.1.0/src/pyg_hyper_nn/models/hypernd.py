"""HyperND model for hypergraph neural networks.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Reference:
    Prokopchik, K., Besta, M., & Hoefler, T. (2022).
    Nonlinear feature diffusion on hypergraphs.
    In International Conference on Machine Learning (ICML 2022, pp. 17932-17951).
    https://proceedings.mlr.press/v162/prokopchik22a/prokopchik22a.pdf
"""

from typing import Literal, Optional

import torch
from torch import Tensor, nn
from torch_scatter import scatter, scatter_add

from pyg_hyper_nn.layers.mlp import MLP


class HyperND(nn.Module):
    """HyperND model for node classification on hypergraphs.

    HyperND performs iterative diffusion using p-norm based vertex-edge-vertex
    message passing with personalized PageRank-style restart.

    The diffusion process:
    1. Normalize features: U = X / phi(X)
    2. Iterate: G = (1-alpha) * E2V(V2E(F)) + alpha * U
    3. Normalize: F = G / phi(G)
    4. Repeat until convergence or max_steps

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features.
        out_channels: Number of output classes.
        num_layers: Number of MLP decoder layers.
        p: Order of the p-norm for diffusion. Default: 2.0.
        tol: Convergence tolerance. Default: 1e-5.
        max_steps: Maximum number of diffusion steps. Default: 50.
        alpha: Restart probability (personalized PageRank). Default: 0.1.
        aggregation: Aggregation method for scatter operations.
            Options: "sum", "mean", "max". Default: "sum".
        dropout: Dropout probability. Default: 0.5.
        normalization: Normalization type for MLP decoder.
            Options: "bn", "ln", "gn", None. Default: "bn".
        cache_diffusion: If True, cache diffusion results. Default: True.

    Reference:
        Based on hypergraph neural diffusion with p-norm propagation.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int = 2,
        p: float = 2.0,
        tol: float = 1e-5,
        max_steps: int = 50,
        alpha: float = 0.1,
        aggregation: Literal["sum", "mean", "max"] = "sum",
        dropout: float = 0.5,
        normalization: Optional[Literal["bn", "ln", "gn"]] = "bn",
        cache_diffusion: bool = True,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.p = p
        self.tol = tol
        self.max_steps = max_steps
        self.alpha = alpha
        self.aggregation = aggregation
        self.dropout = dropout
        self.normalization = normalization
        self.cache_diffusion = cache_diffusion

        # Cached diffusion result
        self._cached_features: Optional[Tensor] = None
        self._cached_hyperedge_index: Optional[Tensor] = None

        # Decoder MLP
        self.decoder = MLP(
            in_channels=in_channels,
            hidden_channels=hidden_channels,
            out_channels=out_channels,
            num_layers=num_layers,
            dropout=dropout,
            normalization=normalization or "bn",
        )

    def reset_parameters(self) -> None:
        """Reset all learnable parameters and clear cache."""
        self._cached_features = None
        self._cached_hyperedge_index = None
        self.decoder.reset_parameters()

    def _compute_phi(self, z: Tensor, v: Tensor, e: Tensor, de: Tensor) -> Tensor:
        """Compute phi(Z) = 2 * sqrt(sum(||P||_2^2)) where P = V2E(Z).

        Args:
            z: Node features of shape (num_nodes, num_features).
            v: Node indices in hyperedge_index[0].
            e: Edge indices in hyperedge_index[1].
            de: Edge degrees (number of nodes per edge).

        Returns:
            Scalar phi value.
        """
        device = z.device
        num_nodes = z.shape[0]

        # Compute node degrees
        ones = torch.ones(v.shape[0], device=device, dtype=torch.float32)
        d = scatter_add(ones, v, dim=0, dim_size=num_nodes)

        # V2E: vertex to edge
        z_norm = z / torch.pow(d + 1e-10, 0.5).unsqueeze(-1)

        # Apply rho (p-norm)
        xve = torch.pow(z_norm[v], self.p)

        # Aggregate to edges
        xe = scatter(xve, e, dim=0, reduce=self.aggregation)

        # Apply sigma (inverse p-norm and edge degree normalization)
        xe = xe / (de.unsqueeze(-1) + 1e-10)
        xe = torch.pow(xe + 1e-10, 1.0 / self.p)

        # Compute phi: 2 * sqrt(sum(||P||_2^2))
        p_norm = torch.linalg.norm(xe, dim=-1, ord=2.0) ** 2.0
        return 2.0 * torch.sqrt(p_norm.sum() + 1e-10)

    def _v2e(self, z: Tensor, v: Tensor, e: Tensor, d: Tensor, de: Tensor) -> Tensor:
        """Vertex to edge propagation with p-norm.

        Args:
            z: Node features of shape (num_nodes, num_features).
            v: Node indices in hyperedge_index[0].
            e: Edge indices in hyperedge_index[1].
            d: Node degrees.
            de: Edge degrees.

        Returns:
            Edge features of shape (num_edges, num_features).
        """
        # Normalize by node degree^{0.5}
        z_norm = z / torch.pow(d + 1e-10, 0.5).unsqueeze(-1)

        # Apply rho (p-norm)
        xve = torch.pow(z_norm[v] + 1e-10, self.p)

        # Aggregate to edges
        xe = scatter(xve, e, dim=0, reduce=self.aggregation)

        # Apply sigma (inverse p-norm and edge degree normalization)
        xe = xe / (de.unsqueeze(-1) + 1e-10)
        return torch.pow(xe + 1e-10, 1.0 / self.p)

    def _e2v(
        self, z: Tensor, v: Tensor, e: Tensor, d: Tensor, num_nodes: int
    ) -> Tensor:
        """Edge to vertex propagation.

        Args:
            z: Edge features of shape (num_edges, num_features).
            v: Node indices in hyperedge_index[0].
            e: Edge indices in hyperedge_index[1].
            d: Node degrees.
            num_nodes: Number of nodes.

        Returns:
            Node features of shape (num_nodes, num_features).
        """
        # Select edge features for each node-edge pair
        xev = z[e]

        # Aggregate to nodes
        xv = scatter(xev, v, dim=0, dim_size=num_nodes, reduce=self.aggregation)

        # Normalize by node degree
        return xv / torch.pow(d + 1e-10, 0.5).unsqueeze(-1)

    def _diffusion(self, x: Tensor, hyperedge_index: Tensor) -> Tensor:
        """Perform iterative hypergraph diffusion.

        Args:
            x: Node features of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format.

        Returns:
            Diffused node features of shape (num_nodes, in_channels).
        """
        # Check cache
        if (
            self.cache_diffusion
            and self._cached_features is not None
            and self._cached_hyperedge_index is not None
            and torch.equal(self._cached_hyperedge_index, hyperedge_index)
        ):
            return self._cached_features

        device = x.device
        num_nodes = x.shape[0]
        v, e = hyperedge_index[0], hyperedge_index[1]

        # Handle empty hypergraph
        if hyperedge_index.numel() == 0:
            if self.cache_diffusion:
                self._cached_features = x
                self._cached_hyperedge_index = hyperedge_index.clone()
            return x

        # Compute degrees
        ones = torch.ones(v.shape[0], device=device, dtype=torch.float32)
        d = scatter_add(ones, v, dim=0, dim_size=num_nodes)  # Node degrees
        de = scatter_add(ones, e, dim=0)  # Edge degrees

        # Initial normalization: U = X / phi(X)
        phi_x = self._compute_phi(x, v, e, de)
        u = x / (phi_x + 1e-10)
        f = u

        # Iterative diffusion
        for _ in range(self.max_steps):
            f_last = f

            # Diffusion step
            edge_features = self._v2e(f, v, e, d, de)
            propagated = self._e2v(edge_features, v, e, d, num_nodes)
            g = (1.0 - self.alpha) * propagated + self.alpha * u

            # Normalize
            phi_g = self._compute_phi(g, v, e, de)
            f = g / (phi_g + 1e-10)

            # Check convergence
            f_norm = torch.linalg.norm(f, ord="fro")
            if f_norm > 0:
                diff = torch.linalg.norm(f - f_last, ord="fro") / f_norm
                if diff < self.tol:
                    break

        # Cache result
        if self.cache_diffusion:
            self._cached_features = f
            self._cached_hyperedge_index = hyperedge_index.clone()

        return f

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass with hypergraph diffusion.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        # Perform diffusion
        f = self._diffusion(x, hyperedge_index)

        # Decode
        return self.decoder(f)

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers}, p={self.p}, "
            f"max_steps={self.max_steps}, alpha={self.alpha})"
        )


__all__ = ["HyperND"]
