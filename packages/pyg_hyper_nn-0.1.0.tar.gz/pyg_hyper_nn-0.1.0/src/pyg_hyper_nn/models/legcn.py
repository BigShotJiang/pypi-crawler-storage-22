"""LEGCN model for hypergraph neural networks.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Reference:
    Zhang, R., Zou, Y., & Ma, J. (2022).
    Semi-supervised Hypergraph Node Classification on Hypergraph Line Expansion.
    In Proceedings of the 31st ACM International Conference on Information and Knowledge
    Management (CIKM 2022).
    https://arxiv.org/pdf/2005.04843
"""

from typing import Optional

import torch
import torch.nn.functional as F
from torch import Tensor, nn
from torch_geometric.nn import GCNConv
from torch_scatter import scatter

from pyg_hyper_nn.layers.legcn_utils import line_expansion


class LEGCN(nn.Module):
    """LEGCN model for node classification on hypergraphs.

    LEGCN converts hypergraphs to line graphs where each node-hyperedge pair
    becomes a vertex. GCN layers are applied on this line graph, and predictions
    are aggregated back to nodes using scatter operations.

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features.
        out_channels: Number of output classes.
        num_layers: Number of GCN layers.
        dropout: Dropout probability. Default: 0.5.
        aggregation: How to aggregate line graph node features back to original nodes.
            Options: "mean", "sum", "max". Default: "mean".

    Reference:
        Based on line graph expansion for hypergraph neural networks.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        dropout: float = 0.5,
        aggregation: str = "mean",
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.dropout = dropout
        self.aggregation = aggregation

        # Line expansion adjacency (cached after first forward)
        self._le_adj: Optional[Tensor] = None
        self._cached_hyperedge_index: Optional[Tensor] = None

        # Build GCN layers
        self.convs: nn.ModuleList = nn.ModuleList()
        if num_layers == 1:
            self.convs.append(GCNConv(in_channels, out_channels))
        else:
            self.convs.append(GCNConv(in_channels, hidden_channels))
            for _ in range(num_layers - 2):
                self.convs.append(GCNConv(hidden_channels, hidden_channels))
            self.convs.append(GCNConv(hidden_channels, out_channels))

    def reset_parameters(self) -> None:
        """Reset all learnable parameters and clear cache."""
        self._le_adj = None
        self._cached_hyperedge_index = None
        for layer in self.convs:
            layer.reset_parameters()  # type: ignore[union-attr]

    def _compute_line_expansion(
        self, hyperedge_index: Tensor, num_nodes: int
    ) -> Tensor:
        """Compute and cache line expansion adjacency.

        Args:
            hyperedge_index: Hyperedge indices in COO format.
            num_nodes: Number of nodes in the hypergraph.

        Returns:
            Line expansion adjacency matrix.
        """
        # Check if we can reuse cached adjacency
        if (
            self._le_adj is not None
            and self._cached_hyperedge_index is not None
            and torch.equal(self._cached_hyperedge_index, hyperedge_index)
        ):
            return self._le_adj

        # Compute line expansion
        self._le_adj = line_expansion(hyperedge_index, num_nodes)
        self._cached_hyperedge_index = hyperedge_index.clone()

        return self._le_adj

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        num_nodes = x.shape[0]

        # Compute line expansion adjacency and move to same device as x
        le_adj = self._compute_line_expansion(hyperedge_index, num_nodes)
        le_adj = le_adj.to(x.device)

        # Expand node features to line graph:
        # Each (node, hyperedge) pair gets the features of its node
        node_indices = hyperedge_index[0].to(x.device)  # Shape: (num_pairs,)
        x_expanded = x[node_indices]  # Shape: (num_pairs, in_channels)

        # Apply GCN layers on line graph
        h = x_expanded
        for i, conv in enumerate(self.convs):
            h = conv(h, le_adj)

            # Apply activation and dropout to all but last layer
            if i < self.num_layers - 1:
                h = F.relu(h)
                h = F.dropout(h, p=self.dropout, training=self.training)

        # Aggregate predictions back to nodes
        # h has shape (num_pairs, out_channels)
        # We aggregate over all pairs belonging to each node
        return scatter(
            h, node_indices, dim=0, dim_size=num_nodes, reduce=self.aggregation
        )

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers}, aggregation={self.aggregation})"
        )


__all__ = ["LEGCN"]
