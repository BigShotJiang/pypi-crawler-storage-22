"""PhenomNN (Phenomenological Neural Network) for hypergraphs.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Reference:
    Wang, Y., Yao, Q., Kwok, J. T., & Ni, L. M. (2023).
    From hypergraph energy functions to hypergraph neural networks.
    In International Conference on Machine Learning (ICML 2023, pp. 36433-36448).
    https://proceedings.mlr.press/v202/wang23d/wang23d.pdf
"""

from typing import Optional

import torch
import torch.nn.functional as F
from torch import Tensor, nn

from pyg_hyper_nn.layers.mlp import MLP
from pyg_hyper_nn.layers.preprocessing import phenomnn_expansion


class PhenomNNMultiConv(nn.Module):
    """PhenomNN multi-scale convolution layer.

    Performs iterative propagation using two adjacency matrices (A_beta, A_gamma)
    with different normalization schemes, modeling multi-scale hypergraph dynamics.

    Args:
        lam0: Weight for first-order adjacency (node normalization). Default: 0.5.
        lam1: Weight for second-order adjacency (full normalization). Default: 0.5.
        alpha: Restart probability for propagation. If 0, computed as 1/(1+lam0+lam1). Default: 0.0.
        num_steps: Number of propagation steps. Default: 2.
    """

    def __init__(
        self,
        lam0: float = 0.5,
        lam1: float = 0.5,
        alpha: float = 0.0,
        num_steps: int = 2,
    ):
        super().__init__()

        self.lam0 = lam0
        self.lam1 = lam1
        self.alpha = alpha if alpha != 0 else 1.0 / (1.0 + lam0 + lam1)
        self.num_steps = num_steps

    def forward(
        self,
        X: Tensor,
        A_beta: Tensor,
        A_gamma: Tensor,
        D_beta: Tensor,
        D_gamma: Tensor,
        I: Tensor,  # noqa: E741
    ) -> Tensor:
        """Forward pass with multi-scale propagation.

        Args:
            X: Node features of shape (num_nodes, channels).
            A_beta: First adjacency matrix (node norm) - sparse tensor.
            A_gamma: Second adjacency matrix (full norm) - sparse tensor.
            D_beta: Degree matrix for A_beta - sparse tensor.
            D_gamma: Degree matrix for A_gamma - sparse tensor.
            I: Identity matrix - sparse tensor.

        Returns:
            Propagated node features of shape (num_nodes, channels).
        """
        Y = Y0 = X

        # Compute Q_tild = lam0 * D_beta + lam1 * D_gamma + I
        # Convert to dense for inversion
        Q_tild = (
            self.lam0 * D_beta.to_dense()
            + self.lam1 * D_gamma.to_dense()
            + I.to_dense()
        )

        # Compute inverse of Q_tild
        Q_tild_inv = torch.linalg.inv(Q_tild)

        # Iteratively compute new Y by equation in the paper
        for _ in range(self.num_steps):
            Y_hat = self.lam0 * torch.sparse.mm(A_beta, Y) + Y0
            Y_hat = Y_hat + self.lam1 * torch.sparse.mm(A_gamma, Y)

            Y = F.relu((1 - self.alpha) * Y + self.alpha * (Q_tild_inv @ Y_hat))

        return Y


class PhenomNN(nn.Module):
    """PhenomNN model for node classification on hypergraphs.

    PhenomNN uses multi-scale phenomenological modeling with two adjacency
    matrices (node-normalized and fully-normalized) for iterative propagation.

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features in projector/decoder.
        out_channels: Number of output classes.
        encoder_layers: Number of MLP layers in projector encoder. Default: 2.
        decoder_layers: Number of MLP layers in decoder. Default: 2.
        lam0: Weight for first-order adjacency (node norm). Default: 0.5.
        lam1: Weight for second-order adjacency (full norm). Default: 0.5.
        alpha: Restart probability. If 0, computed as 1/(1+lam0+lam1). Default: 0.0.
        num_steps: Number of propagation steps. Default: 2.
        dropout: Dropout probability. Default: 0.5.
        normalization: Normalization type ("bn", "ln", "none"). Default: "bn".

    Reference:
        Based on phenomenological modeling of hypergraph neural networks.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        encoder_layers: int = 2,
        decoder_layers: int = 2,
        lam0: float = 0.5,
        lam1: float = 0.5,
        alpha: float = 0.0,
        num_steps: int = 2,
        dropout: float = 0.5,
        normalization: str = "bn",
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.lam0 = lam0
        self.lam1 = lam1
        self.alpha = alpha
        self.num_steps = num_steps
        self.dropout = dropout

        # Projector: encode input features
        self.projector = MLP(
            in_channels=in_channels,
            hidden_channels=hidden_channels,
            out_channels=hidden_channels,
            num_layers=encoder_layers,
            dropout=dropout,
            normalization=normalization,
        )

        # Convolution layer
        self.conv = PhenomNNMultiConv(
            lam0=lam0,
            lam1=lam1,
            alpha=alpha,
            num_steps=num_steps,
        )

        # Decoder: map to output classes
        self.decoder = MLP(
            in_channels=hidden_channels,
            hidden_channels=hidden_channels,
            out_channels=out_channels,
            num_layers=decoder_layers,
            dropout=dropout,
            normalization=normalization,
        )

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        self.projector.reset_parameters()
        self.decoder.reset_parameters()

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        num_nodes = x.shape[0]

        # Compute multi-scale adjacency matrices
        # A_beta: node normalization, A_gamma: full normalization
        A_beta, D_beta, I = phenomnn_expansion(  # noqa: E741
            hyperedge_index, num_nodes, norm_type="node"
        )
        A_gamma, D_gamma, _ = phenomnn_expansion(
            hyperedge_index, num_nodes, norm_type="full"
        )

        # Move to same device as x
        A_beta = A_beta.to(x.device)
        A_gamma = A_gamma.to(x.device)
        D_beta = D_beta.to(x.device)
        D_gamma = D_gamma.to(x.device)
        I = I.to(x.device)  # noqa: E741

        # Encode
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = F.relu(self.projector(x))

        # Multi-scale convolution
        x = self.conv(x, A_beta, A_gamma, D_beta, D_gamma, I)

        # Decode
        x = F.dropout(x, p=self.dropout, training=self.training)
        return self.decoder(x)

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"lam0={self.lam0}, lam1={self.lam1}, num_steps={self.num_steps})"
        )


__all__ = ["PhenomNN", "PhenomNNMultiConv"]
