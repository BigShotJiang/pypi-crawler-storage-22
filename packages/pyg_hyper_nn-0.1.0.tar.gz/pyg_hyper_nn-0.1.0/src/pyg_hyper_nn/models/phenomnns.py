"""PhenomNNS (Phenomenological Neural Network Simplified) for hypergraphs.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Reference:
    Wang, Y., Yao, Q., Kwok, J. T., & Ni, L. M. (2023).
    From hypergraph energy functions to hypergraph neural networks.
    In International Conference on Machine Learning (ICML 2023, pp. 36433-36448).
    https://proceedings.mlr.press/v202/wang23d/wang23d.pdf

Note:
    PhenomNNS is a simplified variant that uses a single combined adjacency matrix
    instead of the multi-scale approach in PhenomNN for faster computation.
"""

from typing import Optional

import torch
import torch.nn.functional as F
from torch import Tensor, nn

from pyg_hyper_nn.layers.mlp import MLP
from pyg_hyper_nn.layers.preprocessing import phenomnn_expansion


class PhenomNNSMultiConv(nn.Module):
    """PhenomNNS simplified convolution layer.

    Performs iterative propagation using a single combined adjacency matrix,
    simplifying the multi-scale approach of PhenomNN.

    Args:
        lam0: Weight for first-order adjacency (node normalization). Default: 0.5.
        lam1: Weight for second-order adjacency (full normalization). Default: 0.5.
        alpha: Restart probability for propagation. If 0, computed as 1/(1+lam0+lam1). Default: 0.0.
        num_steps: Number of propagation steps. Default: 2.
    """

    def __init__(
        self,
        lam0: float = 0.5,
        lam1: float = 0.5,
        alpha: float = 0.0,
        num_steps: int = 2,
    ):
        super().__init__()

        self.lam0 = lam0
        self.lam1 = lam1
        self.alpha = alpha if alpha != 0 else 1.0 / (1.0 + lam0 + lam1)
        self.num_steps = num_steps

    def forward(self, X: Tensor, A: Tensor, D: Tensor, I: Tensor) -> Tensor:  # noqa: E741
        """Forward pass with simplified propagation.

        Args:
            X: Node features of shape (num_nodes, channels).
            A: Combined adjacency matrix - sparse tensor.
            D: Combined degree matrix - sparse tensor.
            I: Identity matrix - sparse tensor.

        Returns:
            Propagated node features of shape (num_nodes, channels).
        """
        Y = Y0 = X

        Q_tild = D.to_dense() + I.to_dense()

        # Compute inverse of Q_tild
        Q_tild_inv = torch.linalg.inv(Q_tild)

        # Iteratively compute new Y
        for _ in range(self.num_steps):
            Y_hat = torch.sparse.mm(A, Y) + Y0

            Y = F.relu((1 - self.alpha) * Y + self.alpha * (Q_tild_inv @ Y_hat))

        return Y


class PhenomNNS(nn.Module):
    """PhenomNNS (Simplified) model for node classification on hypergraphs.

    PhenomNNS is a simplified version of PhenomNN that uses a single combined
    adjacency matrix A = lam0 * A_beta + lam1 * A_gamma instead of maintaining
    separate matrices.

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features in projector/decoder.
        out_channels: Number of output classes.
        encoder_layers: Number of MLP layers in projector encoder. Default: 2.
        decoder_layers: Number of MLP layers in decoder. Default: 2.
        lam0: Weight for first-order adjacency (node norm). Default: 0.5.
        lam1: Weight for second-order adjacency (full norm). Default: 0.5.
        alpha: Restart probability. If 0, computed as 1/(1+lam0+lam1). Default: 0.0.
        num_steps: Number of propagation steps. Default: 2.
        dropout: Dropout probability. Default: 0.5.
        normalization: Normalization type ("bn", "ln", "none"). Default: "bn".

    Reference:
        Based on simplified phenomenological modeling of hypergraph neural networks.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        encoder_layers: int = 2,
        decoder_layers: int = 2,
        lam0: float = 0.5,
        lam1: float = 0.5,
        alpha: float = 0.0,
        num_steps: int = 2,
        dropout: float = 0.5,
        normalization: str = "bn",
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.lam0 = lam0
        self.lam1 = lam1
        self.alpha = alpha
        self.num_steps = num_steps
        self.dropout = dropout

        # Projector: encode input features
        self.projector = MLP(
            in_channels=in_channels,
            hidden_channels=hidden_channels,
            out_channels=hidden_channels,
            num_layers=encoder_layers,
            dropout=dropout,
            normalization=normalization,
        )

        # Convolution layer
        self.conv = PhenomNNSMultiConv(
            lam0=lam0,
            lam1=lam1,
            alpha=alpha,
            num_steps=num_steps,
        )

        # Decoder: map to output classes
        self.decoder = MLP(
            in_channels=hidden_channels,
            hidden_channels=hidden_channels,
            out_channels=out_channels,
            num_layers=decoder_layers,
            dropout=dropout,
            normalization=normalization,
        )

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        self.projector.reset_parameters()
        self.decoder.reset_parameters()

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        num_nodes = x.shape[0]

        # Compute adjacency matrices
        A_beta, D_beta, I = phenomnn_expansion(  # noqa: E741
            hyperedge_index, num_nodes, norm_type="node"
        )
        A_gamma, D_gamma, _ = phenomnn_expansion(
            hyperedge_index, num_nodes, norm_type="full"
        )

        # Convert to dense for weighted sum, then back to sparse
        A_combined_dense = (
            self.lam0 * A_beta.to_dense() + self.lam1 * A_gamma.to_dense()
        )
        D_combined_dense = (
            self.lam0 * D_beta.to_dense() + self.lam1 * D_gamma.to_dense()
        )

        # Convert back to sparse COO tensors
        A = A_combined_dense.to_sparse_coo()
        D = D_combined_dense.to_sparse_coo()

        # Move to same device as x
        A = A.to(x.device)
        D = D.to(x.device)
        I = I.to(x.device)  # noqa: E741

        # Encode
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = F.relu(self.projector(x))

        # Simplified convolution
        x = self.conv(x, A, D, I)

        # Decode
        x = F.dropout(x, p=self.dropout, training=self.training)
        return self.decoder(x)

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"lam0={self.lam0}, lam1={self.lam1}, num_steps={self.num_steps})"
        )


__all__ = ["PhenomNNS", "PhenomNNSMultiConv"]
