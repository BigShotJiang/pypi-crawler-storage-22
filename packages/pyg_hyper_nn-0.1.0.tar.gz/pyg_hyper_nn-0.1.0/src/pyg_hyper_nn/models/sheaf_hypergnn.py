"""SheafHyperGNN - Sheaf-based hypergraph neural network with diagonal Laplacian.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Reference:
    Yu, T., Li, J., Gong, H., & Li, M. (2023).
    Sheaf hypergraph networks.
    In Advances in Neural Information Processing Systems (Vol. 36, pp. 76714-76733).
    https://proceedings.neurips.cc/paper_files/paper/2023/file/27f243af2887d7f248f518d9b967a882-Paper-Conference.pdf
"""

from typing import Literal, Optional

import torch
import torch.nn.functional as F
from torch import Tensor, nn
from torch_scatter import scatter_mean

from pyg_hyper_nn.layers.mlp import MLP
from pyg_hyper_nn.layers.sheaf_builder import SheafBuilderDiag
from pyg_hyper_nn.layers.sheaf_conv import HyperDiffusionDiagSheafConv


class SheafHyperGNN(nn.Module):
    """Sheaf hypergraph neural network with diagonal restriction maps.

    Uses learnable diagonal dxd blocks in the sheaf Laplacian to capture
    higher-order interactions in hypergraphs.

    Args:
        in_channels: Input node feature dimension.
        hidden_channels: Hidden layer dimension.
        out_channels: Output dimension (number of classes).
        num_layers: Number of sheaf diffusion layers. Default: 2.
        stalk_dim: Dimension of stalks (d). Default: 4.
        dropout: Dropout probability. Default: 0.5.
        prediction_type: How to compute hyperedge features ("MLP_var1", "MLP_var2",
            "MLP_var3", "cp_decomp"). Default: "MLP_var2".
        sheaf_act: Activation for sheaf prediction. Default: "sigmoid".
        norm_type: Laplacian normalization type. Default: "degree_norm".
        left_proj: Whether to use left projection in convolution. Default: False.
        residual: Whether to use residual connections. Default: False.
        dynamic_sheaf: Whether sheaf changes per layer. Default: False.
        init_hedge: How to initialize hyperedge features ("avg" or "rand"). Default: "avg".
        input_norm: Whether to use input normalization. Default: False.
        clear_flag: Whether to clear cache between graphs (for hypergraph classification).
            Default: False.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int = 2,
        stalk_dim: int = 4,
        dropout: float = 0.5,
        prediction_type: Literal[
            "MLP_var1", "MLP_var2", "MLP_var3", "cp_decomp"
        ] = "MLP_var2",
        sheaf_act: str = "sigmoid",
        norm_type: Literal[
            "degree_norm", "sym_degree_norm", "block_norm", "sym_block_norm"
        ] = "degree_norm",
        left_proj: bool = False,
        residual: bool = False,
        dynamic_sheaf: bool = False,
        init_hedge: str = "avg",
        input_norm: bool = False,
        clear_flag: bool = False,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.d = stalk_dim
        self.dropout = dropout
        self.init_hedge = init_hedge
        self.dynamic_sheaf = dynamic_sheaf
        self.clear_flag = clear_flag
        self.device = torch.device("cpu")  # Will be updated on first forward

        # Initial projection: N x in_channels -> (Nd) x hidden_channels
        self.lin = MLP(
            in_channels=in_channels,
            hidden_channels=hidden_channels,
            out_channels=hidden_channels * self.d,
            num_layers=1,
            dropout=0.0,
            normalization="ln",
            input_norm=False,
        )

        # Sheaf diffusion layers
        self.convs: nn.ModuleList = nn.ModuleList()
        for _ in range(num_layers):
            self.convs.append(
                HyperDiffusionDiagSheafConv(
                    in_channels=hidden_channels,
                    out_channels=hidden_channels,
                    d=self.d,
                    device=self.device,
                    norm_type=norm_type,
                    left_proj=left_proj,
                    input_norm=input_norm,
                    residual=residual,
                    clear_flag=self.clear_flag,
                )
            )

        # Sheaf builders (restriction map predictors)
        self.sheaf_builder: nn.ModuleList = nn.ModuleList()
        if dynamic_sheaf:
            # Create separate builder for each layer
            for _ in range(num_layers):
                self.sheaf_builder.append(
                    SheafBuilderDiag(
                        hidden_channels=hidden_channels,
                        stalk_dim=self.d,
                        prediction_type=prediction_type,
                        sheaf_act=sheaf_act,
                        sheaf_dropout=False,
                        dropout=dropout,
                        special_head=False,
                        input_norm=input_norm,
                    )
                )
        else:
            # Single builder shared across all layers
            self.sheaf_builder.append(
                SheafBuilderDiag(
                    hidden_channels=hidden_channels,
                    stalk_dim=self.d,
                    prediction_type=prediction_type,
                    sheaf_act=sheaf_act,
                    sheaf_dropout=False,
                    dropout=dropout,
                    special_head=False,
                    input_norm=input_norm,
                )
            )

        # Final projection: (Nd) x hidden_channels -> N x out_channels
        self.lin2 = nn.Linear(hidden_channels * self.d, out_channels, bias=False)

        # Hyperedge features (initialized on first forward)
        self.hyperedge_attr: Tensor | None = None

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        self.lin.reset_parameters()
        self.lin2.reset_parameters()
        for conv in self.convs:
            conv.reset_parameters()  # type: ignore[call-non-callable]
        for builder in self.sheaf_builder:
            builder.reset_parameters()  # type: ignore[call-non-callable]

        # Clear hyperedge attributes
        self.hyperedge_attr = None

    def init_hyperedge_attr(
        self, num_edges: int, x: Tensor, hyperedge_index: Tensor
    ) -> Tensor:
        """Initialize hyperedge attributes.

        Args:
            num_edges: Number of hyperedges.
            x: Node features.
            hyperedge_index: Hyperedge indices.

        Returns:
            Initialized hyperedge attributes of shape (num_edges, in_channels).
        """
        if self.init_hedge == "rand":
            return torch.randn((num_edges, self.in_channels), device=x.device)
        if self.init_hedge == "avg":
            return scatter_mean(x[hyperedge_index[0]], hyperedge_index[1], dim=0)
        msg = f"Unknown init_hedge: {self.init_hedge}"
        raise NotImplementedError(msg)

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node features of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices of shape (2, num_pairs).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        num_nodes = x.shape[0]
        num_edges = (
            int(hyperedge_index[1].max().item()) + 1
            if hyperedge_index.numel() > 0
            else 0
        )

        # Update device
        self.device = x.device

        # Initialize hyperedge attributes (once per training run)
        if self.hyperedge_attr is None or self.hyperedge_attr.shape[0] != num_edges:
            self.hyperedge_attr = self.init_hyperedge_attr(
                num_edges, x, hyperedge_index
            )

        # Expand features: N x in_channels -> (Nd) x hidden_channels
        x = self.lin(x)
        x = x.view(num_nodes * self.d, self.hidden_channels)  # (Nd, hidden_channels)

        hyperedge_attr = self.lin(self.hyperedge_attr)
        hyperedge_attr = hyperedge_attr.view(num_edges * self.d, self.hidden_channels)

        # Apply sheaf diffusion layers
        for i, conv in enumerate(self.convs[:-1]):  # type: ignore[arg-type]
            # Predict sheaf restriction maps
            if i == 0 or self.dynamic_sheaf:
                builder_idx = i if self.dynamic_sheaf else 0
                h_sheaf_index, h_sheaf_attributes = self.sheaf_builder[builder_idx](
                    x, hyperedge_attr, hyperedge_index
                )

            # Sheaf Laplacian diffusion
            x = F.elu(
                conv(
                    x,
                    hyperedge_index=h_sheaf_index,
                    alpha=h_sheaf_attributes,
                    num_nodes=num_nodes,
                    num_edges=num_edges,
                )
            )
            x = F.dropout(x, p=self.dropout, training=self.training)

        # Last layer
        if len(self.convs) == 1 or self.dynamic_sheaf:
            builder_idx = -1 if self.dynamic_sheaf else 0
            h_sheaf_index, h_sheaf_attributes = self.sheaf_builder[builder_idx](
                x, hyperedge_attr, hyperedge_index
            )

        x = self.convs[-1](
            x,
            hyperedge_index=h_sheaf_index,
            alpha=h_sheaf_attributes,
            num_nodes=num_nodes,
            num_edges=num_edges,
        )

        # Collapse stalks: (Nd) x hidden_channels -> N x (d*hidden_channels)
        x = x.view(num_nodes, -1)

        # Final projection: N x (d*hidden_channels) -> N x out_channels
        return self.lin2(x)

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers}, stalk_dim={self.d})"
        )


__all__ = ["SheafHyperGNN"]
