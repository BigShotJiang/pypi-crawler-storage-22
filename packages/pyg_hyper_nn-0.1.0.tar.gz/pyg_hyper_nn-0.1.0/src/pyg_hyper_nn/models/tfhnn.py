"""TFHNN (Tensor Factorization Hypergraph Neural Network) model.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Reference:
    Luo, B., Lin, Z., Feng, Y., Wu, Z.-J., & Wang, S. Z. (2025).
    Training-Free Message Passing for Learning on Hypergraphs.
    In The Thirteenth International Conference on Learning Representations (ICLR 2025).
    https://openreview.net/pdf?id=4AuyYxt7A2
"""

from typing import Optional

import numpy as np
import scipy.sparse as sp
import torch
from torch import Tensor, nn

from pyg_hyper_nn.layers.mlp import MLP
from pyg_hyper_nn.layers.utils import create_coo_from_edge_index, ssm2tst


class TFHNN(nn.Module):
    """Tensor Factorization Hypergraph Neural Network.

    Implements a hypergraph neural network using weighted clique expansion
    and personalized PageRank-style propagation with power iterations.

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features in decoder.
        out_channels: Number of output classes.
        num_layers: Number of propagation steps (power iterations). Default: 2.
        decoder_layers: Number of MLP layers in decoder. Default: 2.
        alpha: Restart probability (personalized PageRank). Default: 0.15.
        dropout: Dropout probability. Default: 0.5.
        normalization: Normalization type ("bn", "ln", "none"). Default: "bn".
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int = 2,
        decoder_layers: int = 2,
        alpha: float = 0.15,
        dropout: float = 0.5,
        normalization: str = "bn",
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.alpha = alpha
        self.dropout = dropout

        # Cache for propagation matrix (reset on forward if training)
        self.register_buffer("_cache", None, persistent=False)

        # Decoder MLP
        self.decoder = MLP(
            in_channels=in_channels,
            hidden_channels=hidden_channels,
            out_channels=out_channels,
            num_layers=decoder_layers,
            dropout=dropout,
            normalization=normalization,
        )

    def reset_parameters(self) -> None:
        """Reset all learnable parameters and clear cache."""
        self._cache = None
        self.decoder.reset_parameters()

    def _compute_weighted_ce_graph(
        self, hyperedge_index: Tensor, num_nodes: int
    ) -> Tensor:
        """Compute weighted clique expansion graph: D^{-1/2} (H B H^T + I) D^{-1/2}.

        This follows the exact DHG-Bench implementation using scipy sparse matrices.

        Args:
            hyperedge_index: Hyperedge indices in COO format.
            num_nodes: Number of nodes.

        Returns:
            Normalized adjacency matrix as torch sparse tensor.
        """
        # Handle empty hypergraph
        if hyperedge_index.numel() == 0:
            # Empty hypergraph: return identity matrix
            device = hyperedge_index.device
            indices = torch.arange(num_nodes, device=device).unsqueeze(0).repeat(2, 1)
            values = torch.ones(num_nodes, device=device)
            return torch.sparse_coo_tensor(indices, values, (num_nodes, num_nodes))

        # Create incidence matrix H (num_nodes x num_edges)
        H = create_coo_from_edge_index(hyperedge_index, num_nodes=num_nodes)

        # 1. Compute H x B x H^T where B = diag(1/|e|) for each edge e
        colsum = np.array(H.sum(0), dtype=float)
        r_inv = np.power(colsum, -1).flatten()
        r_inv[np.isinf(r_inv)] = 0.0
        B = sp.diags(r_inv)

        A_beta = H.dot(B).dot(H.transpose())

        # Add self-loops
        I = sp.eye(A_beta.shape[0])  # noqa: E741
        A_beta = A_beta + I

        # 2. Symmetric normalization: D^{-1/2} A D^{-1/2}
        rowsum = np.array(A_beta.sum(1), dtype=float)
        r_inv_sqrt = np.power(rowsum, -0.5).flatten()
        r_inv_sqrt[np.isinf(r_inv_sqrt)] = 0.0
        D = sp.diags(r_inv_sqrt)

        A_normalized = D.dot(A_beta).dot(D)

        return ssm2tst(A_normalized)

    def _diffusion(self, x: Tensor, hyperedge_index: Tensor) -> Tensor:
        """Perform diffusion with personalized PageRank restart.

        Computes: X_out = alpha * sum_{l=0}^{L} (1-alpha)^l * W^l * X

        This follows the exact DHG-Bench implementation.

        Args:
            x: Node features of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format.

        Returns:
            Diffused node features of shape (num_nodes, in_channels).
        """
        # Return cached result if available
        if self._cache is not None:
            return self._cache

        num_nodes = x.shape[0]

        # Compute normalized weighted clique expansion graph
        norm_W = self._compute_weighted_ce_graph(hyperedge_index, num_nodes)

        # Move to same device as x
        norm_W = norm_W.to(x.device)

        # Ensure sparse COO format and coalesce
        if norm_W.layout != torch.sparse_coo:
            msg = f"Expected sparse_coo layout, got {norm_W.layout}"
            raise ValueError(msg)
        norm_W = norm_W.coalesce()

        # Diffusion: X_out = alpha * sum_{l=0}^{L} (1-alpha)^l * W^l * X
        # l = 0: alpha * X
        X_out = self.alpha * x

        # Iteratively compute W^l * X
        W_power_X = x.clone()

        for step in range(1, self.num_layers):
            W_power_X = torch.sparse.mm(norm_W, W_power_X)
            X_out = X_out + self.alpha * ((1 - self.alpha) ** step) * W_power_X

        # Final step: l = L (note: different coefficient - no alpha multiplier)
        W_L_X = torch.sparse.mm(norm_W, W_power_X)
        X_out = X_out + ((1 - self.alpha) ** self.num_layers) * W_L_X

        # Cache result
        self._cache = X_out

        return X_out

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass with hypergraph diffusion.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        # Clear cache if training (to recompute diffusion)
        if self.training:
            self._cache = None

        # Perform diffusion
        F = self._diffusion(x, hyperedge_index)

        # Decode
        return self.decoder(F)

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers}, alpha={self.alpha})"
        )


__all__ = ["TFHNN"]
