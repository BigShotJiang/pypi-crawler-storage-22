"""UniGCNII model for hypergraph node classification.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Reference:
    Huang, J., & Yang, J. (2021).
    UniGNN: a Unified Framework for Graph and Hypergraph Neural Networks.
    In Proceedings of the Thirtieth International Joint Conference on Artificial Intelligence
    (IJCAI-21, pp. 2563-2569).
    https://www.ijcai.org/proceedings/2021/0353.pdf

Note:
    UniGCNII extends UniGNN with GCNII-style initial residual connections and
    adaptive identity mapping for improved training of deep hypergraph networks.
"""

import math
from typing import Optional

from torch import Tensor, nn
from torch.nn import functional as functional_F
from torch_scatter import scatter

from pyg_hyper_nn.layers.utils import normalize_l2


class UniGCNIIConv(nn.Module):
    """UniGCNII convolution layer with initial residual and identity mapping.

    Extends UniGNN convolution with:
    - Initial residual connection (alpha parameter)
    - Identity mapping (beta parameter)
    These modifications improve training of deep hypergraph networks.

    Args:
        in_channels: Size of input features.
        out_channels: Size of output features.
        reduce: Aggregation method for vertex-to-hyperedge ("mean", "sum", "max").
            Default: "mean".
        use_norm: If True, apply L2 normalization. Default: False.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        reduce: str = "mean",
        use_norm: bool = False,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.reduce = reduce
        self.use_norm = use_norm

        self.W = nn.Linear(in_channels, out_channels, bias=False)

        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        self.W.reset_parameters()

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        alpha: float,
        beta: float,
        x0: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> tuple[Tensor, Tensor]:
        """Forward pass with initial residual and identity mapping.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges),
                where hyperedge_index[0] contains node indices and
                hyperedge_index[1] contains hyperedge indices.
            alpha: Initial residual weight (0 to 1).
            beta: Identity mapping weight (0 to 1).
            x0: Initial node features from first layer.
            hyperedge_weight: Ignored (for interface compatibility).

        Returns:
            Tuple of:
                - Updated node features of shape (num_nodes, out_channels).
                - Hyperedge embeddings of shape (num_hyperedges, out_channels).
        """
        num_nodes = x.shape[0]
        vertex, edges = hyperedge_index[0], hyperedge_index[1]

        # Vertex to hyperedge aggregation
        x_ve = x[vertex]  # [nnz, C]
        x_e = scatter(x_ve, edges, dim=0, reduce=self.reduce)  # [E, C]

        # Hyperedge to vertex aggregation
        x_ev = x_e[edges]  # [nnz, C]
        x_v = scatter(x_ev, vertex, dim=0, reduce=self.reduce, dim_size=num_nodes)

        x = x_v

        # Optional L2 normalization
        if self.use_norm:
            x = normalize_l2(x)

        # Initial residual connection (GCNII-style)
        x_i = (1 - alpha) * x + alpha * x0

        # Identity mapping with learnable transformation
        x = (1 - beta) * x_i + beta * self.W(x_i)

        return x, x_e

    def __repr__(self) -> str:
        """String representation of the layer."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.out_channels}, reduce={self.reduce})"
        )


class UniGCNII(nn.Module):
    """Universal Graph Convolutional Network II for hypergraphs.

    Extends UniGNN with GCNII-style initial residual and identity mapping
    to enable training of deeper hypergraph neural networks.

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features.
        out_channels: Number of output classes.
        num_layers: Number of convolution layers (minimum 1).
        alpha: Initial residual weight (0 to 1). Default: 0.1.
        lamda: Identity mapping base weight. Default: 0.5.
        dropout: Dropout probability. Default: 0.2.
        input_dropout: Input dropout probability. Default: 0.6.
        activation: Activation function ("relu" or "prelu"). Default: "relu".
        reduce: Aggregation method for vertex-to-hyperedge
            ("sum", "mean", "max"). Default: "mean".
        use_norm: If True, apply L2 normalization. Default: False.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        alpha: float = 0.1,
        lamda: float = 0.5,
        dropout: float = 0.2,
        input_dropout: float = 0.6,
        activation: str = "relu",
        reduce: str = "mean",
        use_norm: bool = False,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.alpha = alpha
        self.lamda = lamda

        # Build layers
        self.convs: nn.ModuleList = nn.ModuleList()

        # Input transformation
        self.convs.append(nn.Linear(in_channels, hidden_channels))

        # Hidden layers
        for _ in range(num_layers):
            self.convs.append(
                UniGCNIIConv(
                    hidden_channels,
                    hidden_channels,
                    reduce=reduce,
                    use_norm=use_norm,
                )
            )

        # Output layer
        self.convs.append(nn.Linear(hidden_channels, out_channels))

        # Activation function
        if activation == "relu":
            self.act = nn.ReLU()
        elif activation == "prelu":
            self.act = nn.PReLU()
        else:
            msg = f"Activation must be 'relu' or 'prelu', got {activation}"
            raise ValueError(msg)

        # Dropout
        self.input_drop = nn.Dropout(input_dropout)
        self.dropout = nn.Dropout(dropout)

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        for conv in self.convs:
            conv.reset_parameters()  # type: ignore[union-attr]

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        # Input dropout
        x = self.input_drop(x)

        # Input transformation
        x = functional_F.relu(self.convs[0](x))
        x0 = x  # Store initial features

        # Apply hidden layers with initial residual and identity mapping
        for i, conv in enumerate(self.convs[1:-1]):  # type: ignore[arg-type]
            x = self.dropout(x)
            # Adaptive beta based on layer depth
            beta = math.log(self.lamda / (i + 1) + 1)
            x, _edge_embed = conv(x, hyperedge_index, self.alpha, beta, x0)
            x = self.act(x)

        # Output layer
        x = self.dropout(x)
        return self.convs[-1](x)

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers}, alpha={self.alpha}, "
            f"lamda={self.lamda})"
        )


__all__ = ["UniGCNII", "UniGCNIIConv"]
