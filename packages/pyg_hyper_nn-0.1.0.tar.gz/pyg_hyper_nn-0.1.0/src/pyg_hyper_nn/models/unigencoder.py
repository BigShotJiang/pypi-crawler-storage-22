"""PlainUnigencoder - Simple MLP with group pooling for hypergraphs.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Note:
    PlainUnigencoder is a utility model that implements group pooling operations
    by aggregating node features into groups, applying MLP transformations, and
    distributing back to nodes. This is used as a baseline or preprocessing component.
"""

import torch
import torch.nn.functional as F
from torch import Tensor, nn


class PlainUnigencoder(nn.Module):
    """PlainUnigencoder with group pooling.

    This model uses pooling matrices Pv and PvT to aggregate node features
    into groups, process with MLPs, and distribute back to nodes.

    The architecture is:
    1. Pool: x_grouped = Pv @ x  (nodes -> groups)
    2. Transform: Apply MLP layers with ReLU and dropout
    3. Unpool: x_out = PvT @ x_grouped  (groups -> nodes)

    Args:
        in_channels: Input node feature dimension.
        hidden_channels: Hidden layer dimension.
        out_channels: Output dimension (number of classes).
        num_layers: Number of MLP layers. Default: 2.
        dropout: Dropout probability. Default: 0.5.

    Note:
        The pooling matrices Pv and PvT must be provided in the forward pass.
        Pv is of shape (num_groups, num_nodes) and PvT is (num_nodes, num_groups).
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int = 2,
        dropout: float = 0.5,
    ):
        super().__init__()

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.dropout = dropout

        # Build MLP layers
        self.lins = nn.ModuleList()

        if num_layers == 1:
            # Single layer: in_channels -> out_channels
            self.lins.append(nn.Linear(in_channels, out_channels))
        else:
            # First layer: in_channels -> hidden_channels
            self.lins.append(nn.Linear(in_channels, hidden_channels))

            # Middle layers: hidden_channels -> hidden_channels
            for _ in range(num_layers - 2):
                self.lins.append(nn.Linear(hidden_channels, hidden_channels))

            # Last layer: hidden_channels -> out_channels
            self.lins.append(nn.Linear(hidden_channels, out_channels))

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        for lin in self.lins:
            lin.reset_parameters()  # type: ignore[call-non-callable]

    def forward(
        self,
        x: Tensor,
        Pv: Tensor,
        PvT: Tensor,
        hyperedge_index: Tensor | None = None,  # noqa: ARG002
    ) -> Tensor:
        """Forward pass with group pooling.

        Args:
            x: Node features of shape (num_nodes, in_channels).
            Pv: Pooling matrix of shape (num_groups, num_nodes). Sparse tensor.
            PvT: Transpose pooling matrix of shape (num_nodes, num_groups). Sparse tensor.
            hyperedge_index: Optional hyperedge indices (not used, for API consistency).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        # Pool nodes to groups: (num_groups, num_nodes) @ (num_nodes, F) -> (num_groups, F)
        x = torch.spmm(Pv, x)

        # Apply MLP layers (except last)
        for lin in self.lins[:-1]:  # type: ignore[not-iterable]
            x = lin(x)
            x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)

        # Last layer (no activation)
        x = self.lins[-1](x)

        # Unpool groups to nodes: (num_nodes, num_groups) @ (num_groups, F) -> (num_nodes, F)
        return torch.spmm(PvT, x)

    def __repr__(self) -> str:
        """Return string representation of the model."""
        return (
            f"{self.__class__.__name__}("
            f"{self.in_channels}, {self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers}, dropout={self.dropout})"
        )


__all__ = ["PlainUnigencoder"]
