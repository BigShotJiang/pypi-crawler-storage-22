"""UniGNN model for hypergraph node classification.

Implementation based on DHG-Bench:
https://github.com/Coco-Hut/DHG-Bench

Reference:
    Huang, J., & Yang, J. (2021).
    UniGNN: a Unified Framework for Graph and Hypergraph Neural Networks.
    In Proceedings of the Thirtieth International Joint Conference on Artificial Intelligence
    (IJCAI-21, pp. 2563-2569).
    https://www.ijcai.org/proceedings/2021/0353.pdf
"""

from typing import Optional

import torch
from torch import Tensor, nn
from torch_scatter import scatter

from pyg_hyper_nn.layers.utils import normalize_l2, zeros


class UniGINConv(nn.Module):
    """Universal Graph Isomorphism Network convolution layer.

    Implements a message passing scheme that works on both graphs and hypergraphs
    by using vertex-to-hyperedge and hyperedge-to-vertex aggregation.

    Args:
        in_channels: Size of input features.
        out_channels: Size of output features.
        heads: Number of attention heads. Default: 1.
        dropout: Dropout probability. Default: 0.0.
        first_aggregate: Aggregation method for vertex-to-hyperedge
            ("sum", "mean", "max"). Default: "mean".
        use_norm: If True, apply L2 normalization. Default: False.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        heads: int = 1,
        dropout: float = 0.0,
        first_aggregate: str = "mean",
        use_norm: bool = False,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.heads = heads
        self.dropout = dropout
        self.first_aggregate = first_aggregate
        self.use_norm = use_norm

        self.W = nn.Linear(in_channels, heads * out_channels, bias=False)
        self.eps = nn.Parameter(torch.empty(1))

        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        nn.init.xavier_uniform_(self.W.weight)
        zeros(self.eps)

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,  # noqa: ARG002
    ) -> tuple[Tensor, Tensor]:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges),
                where hyperedge_index[0] contains node indices and
                hyperedge_index[1] contains hyperedge indices.
            hyperedge_weight: Ignored (for interface compatibility).

        Returns:
            Tuple of:
                - Updated node features of shape (num_nodes, heads * out_channels).
                - Hyperedge embeddings of shape (num_hyperedges, heads * out_channels).
        """
        num_nodes = x.shape[0]
        vertex, edges = hyperedge_index[0], hyperedge_index[1]

        # Transform node features
        x = self.W(x)

        # Vertex to hyperedge aggregation
        x_ve = x[vertex]  # [nnz, C]
        x_e = scatter(x_ve, edges, dim=0, reduce=self.first_aggregate)  # [E, C]

        # Hyperedge to vertex aggregation
        x_ev = x_e[edges]  # [nnz, C]
        x_v = scatter(x_ev, vertex, dim=0, reduce="sum", dim_size=num_nodes)  # [N, C]

        # Skip connection with learnable epsilon
        x = (1 + self.eps) * x + x_v

        # Optional L2 normalization
        if self.use_norm:
            x = normalize_l2(x)

        return x, x_e

    def __repr__(self) -> str:
        """String representation of the layer."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.out_channels}, heads={self.heads})"
        )


class UniGNN(nn.Module):
    """Universal Graph Neural Network for hypergraphs.

    Implements the UniGNN architecture that unifies graph and hypergraph
    neural networks through vertex-hyperedge message passing.

    Args:
        in_channels: Size of input node features.
        hidden_channels: Size of hidden layer features.
        out_channels: Number of output classes.
        num_layers: Number of convolution layers (minimum 2).
        heads: Number of attention heads for hidden layers. Default: 1.
        dropout: Dropout probability. Default: 0.5.
        input_dropout: Input dropout probability. Default: 0.0.
        activation: Activation function ("relu" or "prelu"). Default: "relu".
        first_aggregate: Aggregation method for vertex-to-hyperedge
            ("sum", "mean", "max"). Default: "mean".
        use_norm: If True, apply L2 normalization. Default: False.
    """

    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        out_channels: int,
        num_layers: int,
        heads: int = 1,
        dropout: float = 0.5,
        input_dropout: float = 0.0,
        activation: str = "relu",
        first_aggregate: str = "mean",
        use_norm: bool = False,
    ):
        super().__init__()

        if num_layers < 2:
            msg = "UniGNN requires at least 2 layers"
            raise ValueError(msg)

        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        self.num_layers = num_layers

        # Build convolution layers
        self.convs: nn.ModuleList = nn.ModuleList()

        # First layer
        self.convs.append(
            UniGINConv(
                in_channels,
                hidden_channels,
                heads=heads,
                first_aggregate=first_aggregate,
                use_norm=use_norm,
            )
        )

        # Hidden layers
        for _ in range(num_layers - 2):
            self.convs.append(
                UniGINConv(
                    hidden_channels * heads,
                    hidden_channels,
                    heads=heads,
                    first_aggregate=first_aggregate,
                    use_norm=use_norm,
                )
            )

        # Output layer
        self.conv_out = UniGINConv(
            hidden_channels * heads,
            out_channels,
            heads=1,
            first_aggregate=first_aggregate,
            use_norm=use_norm,
        )

        # Activation function
        if activation == "relu":
            self.act = nn.ReLU()
        elif activation == "prelu":
            self.act = nn.PReLU()
        else:
            msg = f"Activation must be 'relu' or 'prelu', got {activation}"
            raise ValueError(msg)

        # Dropout
        self.input_drop = nn.Dropout(input_dropout)
        self.dropout = nn.Dropout(dropout)

    def reset_parameters(self) -> None:
        """Reset all learnable parameters."""
        for conv in self.convs:
            conv.reset_parameters()  # type: ignore[misc]
        self.conv_out.reset_parameters()

    def forward(
        self,
        x: Tensor,
        hyperedge_index: Tensor,
        hyperedge_weight: Optional[Tensor] = None,
    ) -> Tensor:
        """Forward pass.

        Args:
            x: Node feature matrix of shape (num_nodes, in_channels).
            hyperedge_index: Hyperedge indices in COO format of shape (2, num_edges).
            hyperedge_weight: Optional hyperedge weights (ignored).

        Returns:
            Output predictions of shape (num_nodes, out_channels).
        """
        # Input dropout
        x = self.input_drop(x)

        # Apply hidden layers with activation and dropout
        for conv in self.convs:
            x, _edge_embed = conv(x, hyperedge_index, hyperedge_weight)
            x = self.act(x)
            x = self.dropout(x)

        # Apply output layer
        x, _edge_embed = self.conv_out(x, hyperedge_index, hyperedge_weight)

        return x

    def __repr__(self) -> str:
        """String representation of the model."""
        return (
            f"{self.__class__.__name__}({self.in_channels}, "
            f"{self.hidden_channels}, {self.out_channels}, "
            f"num_layers={self.num_layers})"
        )


__all__ = ["UniGINConv", "UniGNN"]
