"""Tests for attention layers."""

import torch

from pyg_hyper_nn.layers import PMA


def test_pma_forward():
    """Test PMA forward pass with basic inputs."""
    pma = PMA(
        in_channels=16,
        hidden_dim=32,
        out_channels=24,
        num_layers=2,
        heads=4,
    )
    x = torch.randn(10, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = pma(x, edge_index)

    assert out.shape == (10, 24), f"Expected shape (10, 24), got {out.shape}"


def test_pma_single_head():
    """Test PMA with single attention head."""
    pma = PMA(
        in_channels=16,
        hidden_dim=32,
        out_channels=24,
        num_layers=2,
        heads=1,
    )
    x = torch.randn(10, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = pma(x, edge_index)

    assert out.shape == (10, 24)


def test_pma_return_attention_weights():
    """Test PMA with attention weights return."""
    pma = PMA(
        in_channels=16,
        hidden_dim=32,
        out_channels=24,
        num_layers=2,
        heads=4,
    )
    x = torch.randn(10, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out, (edge_idx, alpha) = pma(x, edge_index, return_attention_weights=True)

    assert out.shape == (10, 24)
    assert torch.equal(edge_idx, edge_index)
    assert alpha.shape[0] == edge_index.shape[1], "Alpha should match edge count"


def test_pma_with_dropout():
    """Test PMA with dropout enabled."""
    pma = PMA(
        in_channels=16,
        hidden_dim=32,
        out_channels=24,
        num_layers=2,
        heads=4,
        dropout=0.5,
    )
    pma.train()  # Enable training mode for dropout

    x = torch.randn(10, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = pma(x, edge_index)

    assert out.shape == (10, 24)


def test_pma_eval_mode():
    """Test PMA in evaluation mode."""
    pma = PMA(
        in_channels=16,
        hidden_dim=32,
        out_channels=24,
        num_layers=2,
        heads=4,
        dropout=0.5,
    )
    pma.eval()  # Evaluation mode

    x = torch.randn(10, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out1 = pma(x, edge_index)
    out2 = pma(x, edge_index)

    # In eval mode with same input, should get same output
    assert torch.allclose(out1, out2)


def test_pma_empty_edges():
    """Test PMA with empty edge index."""
    pma = PMA(
        in_channels=16,
        hidden_dim=32,
        out_channels=24,
        num_layers=2,
    )
    x = torch.randn(10, 16)
    edge_index = torch.empty((2, 0), dtype=torch.long)

    out = pma(x, edge_index)

    assert out.shape == (10, 24)


def test_pma_single_node():
    """Test PMA with single node."""
    pma = PMA(
        in_channels=8,
        hidden_dim=16,
        out_channels=12,
        num_layers=2,
    )
    x = torch.randn(1, 8)
    edge_index = torch.tensor([[0], [0]])

    out = pma(x, edge_index)

    assert out.shape == (1, 12)


def test_pma_gradient_flow():
    """Test that gradients flow through PMA."""
    pma = PMA(
        in_channels=16,
        hidden_dim=32,
        out_channels=24,
        num_layers=2,
        heads=4,
    )
    x = torch.randn(10, 16, requires_grad=True)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = pma(x, edge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None, "Gradients should flow to input"
    assert pma.lin_K.weight.grad is not None, "Gradients should flow to lin_K"
    assert pma.lin_V.weight.grad is not None, "Gradients should flow to lin_V"


def test_pma_reset_parameters():
    """Test that reset_parameters properly reinitializes weights."""
    pma = PMA(
        in_channels=16,
        hidden_dim=32,
        out_channels=24,
        num_layers=2,
    )

    # Store initial weights
    initial_lin_K = pma.lin_K.weight.clone()
    initial_att_r = pma.att_r.clone()

    # Reset parameters
    pma.reset_parameters()

    # Weights should be different (with high probability)
    assert not torch.allclose(pma.lin_K.weight, initial_lin_K), (
        "lin_K weights should be reinitialized"
    )
    assert not torch.allclose(pma.att_r, initial_att_r), "att_r should be reinitialized"


def test_pma_repr():
    """Test string representation of PMA."""
    pma = PMA(
        in_channels=16,
        hidden_dim=32,
        out_channels=24,
        num_layers=2,
        heads=4,
    )
    repr_str = repr(pma)

    assert "PMA" in repr_str
    assert "16" in repr_str
    assert "24" in repr_str
    assert "heads=4" in repr_str


def test_pma_multiple_layers():
    """Test PMA with different numbers of MLP layers."""
    for num_layers in [1, 2, 3]:
        pma = PMA(
            in_channels=16,
            hidden_dim=32,
            out_channels=24,
            num_layers=num_layers,
        )
        x = torch.randn(10, 16)
        edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        out = pma(x, edge_index)

        assert out.shape == (10, 24), f"Failed with num_layers={num_layers}"


def test_pma_large_graph():
    """Test PMA with larger graph."""
    pma = PMA(
        in_channels=16,
        hidden_dim=32,
        out_channels=24,
        num_layers=2,
        heads=4,
    )
    x = torch.randn(100, 16)
    # Create multiple hyperedges
    edge_index = torch.tensor(
        [[i for i in range(50) for _ in range(3)], [i // 3 for i in range(150)]]
    )

    out = pma(x, edge_index)

    assert out.shape == (100, 24)


def test_pma_negative_slope():
    """Test PMA with different negative slope values."""
    pma = PMA(
        in_channels=16,
        hidden_dim=32,
        out_channels=24,
        num_layers=2,
        negative_slope=0.1,
    )
    x = torch.randn(10, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = pma(x, edge_index)

    assert out.shape == (10, 24)


def test_pma_deterministic():
    """Test that PMA produces deterministic results in eval mode."""
    torch.manual_seed(42)
    pma = PMA(
        in_channels=16,
        hidden_dim=32,
        out_channels=24,
        num_layers=2,
    )
    pma.eval()

    x = torch.randn(10, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # First forward pass
    out1 = pma(x, edge_index)

    # Second forward pass with same inputs
    out2 = pma(x, edge_index)

    assert torch.allclose(out1, out2), "Forward pass should be deterministic"
