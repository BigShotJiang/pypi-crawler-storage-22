"""Tests for hypergraph convolution layers."""

import torch

from pyg_hyper_nn.layers import HypergraphConv


def test_hypergraph_conv_forward():
    """Test HypergraphConv forward pass with basic inputs."""
    conv = HypergraphConv(in_channels=16, out_channels=32)
    x = torch.randn(10, 16)
    # Hyperedge index: nodes [0,1,2] in edge 0, nodes [1,2,3] in edge 1
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out, edge_embed = conv(x, edge_index)

    assert out.shape == (10, 32), f"Expected shape (10, 32), got {out.shape}"
    assert edge_embed.shape == (2, 32), (
        f"Expected shape (2, 32), got {edge_embed.shape}"
    )


def test_hypergraph_conv_with_weights():
    """Test HypergraphConv with hyperedge weights."""
    conv = HypergraphConv(in_channels=8, out_channels=16)
    x = torch.randn(5, 8)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    edge_weight = torch.tensor([2.0])

    out, edge_embed = conv(x, edge_index, edge_weight)

    assert out.shape == (5, 16)
    assert edge_embed.shape == (1, 16)


def test_hypergraph_conv_symmetric_norm():
    """Test HypergraphConv with symmetric degree normalization."""
    conv = HypergraphConv(in_channels=16, out_channels=32, symdegnorm=True)
    x = torch.randn(10, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out, edge_embed = conv(x, edge_index)

    assert out.shape == (10, 32)
    assert edge_embed.shape == (2, 32)


def test_hypergraph_conv_with_attention():
    """Test HypergraphConv with attention mechanism."""
    conv = HypergraphConv(
        in_channels=16,
        out_channels=32,
        use_attention=True,
        heads=4,
        concat=True,
    )
    x = torch.randn(10, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out, edge_embed = conv(x, edge_index)

    # Output should be (num_nodes, heads * out_channels)
    assert out.shape == (10, 4 * 32)
    assert edge_embed.shape == (2, 4 * 32)


def test_hypergraph_conv_attention_average():
    """Test HypergraphConv with attention averaging (concat=False)."""
    conv = HypergraphConv(
        in_channels=16,
        out_channels=32,
        use_attention=True,
        heads=4,
        concat=False,
    )
    x = torch.randn(10, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out, edge_embed = conv(x, edge_index)

    # Output should be (num_nodes, out_channels) when concat=False
    assert out.shape == (10, 32)
    assert edge_embed.shape == (2, 32)


def test_hypergraph_conv_with_bias():
    """Test HypergraphConv with bias."""
    conv = HypergraphConv(in_channels=16, out_channels=32, bias=True)
    x = torch.randn(10, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out, _edge_embed = conv(x, edge_index)

    assert out.shape == (10, 32)
    assert conv.bias is not None


def test_hypergraph_conv_without_bias():
    """Test HypergraphConv without bias."""
    conv = HypergraphConv(in_channels=16, out_channels=32, bias=False)

    assert conv.bias is None


def test_hypergraph_conv_empty_edges():
    """Test HypergraphConv with empty hyperedge index."""
    conv = HypergraphConv(in_channels=16, out_channels=32)
    x = torch.randn(10, 16)
    edge_index = torch.empty((2, 0), dtype=torch.long)

    out, edge_embed = conv(x, edge_index)

    assert out.shape == (10, 32)
    assert edge_embed.shape == (0, 32)


def test_hypergraph_conv_single_node():
    """Test HypergraphConv with single node."""
    conv = HypergraphConv(in_channels=8, out_channels=16)
    x = torch.randn(1, 8)
    edge_index = torch.tensor([[0], [0]])

    out, edge_embed = conv(x, edge_index)

    assert out.shape == (1, 16)
    assert edge_embed.shape == (1, 16)


def test_hypergraph_conv_gradient_flow():
    """Test that gradients flow through HypergraphConv."""
    conv = HypergraphConv(in_channels=16, out_channels=32)
    x = torch.randn(10, 16, requires_grad=True)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out, _edge_embed = conv(x, edge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None, "Gradients should flow to input"
    assert conv.weight.grad is not None, "Gradients should flow to weight"


def test_hypergraph_conv_reset_parameters():
    """Test that reset_parameters properly reinitializes weights."""
    conv = HypergraphConv(in_channels=16, out_channels=32, bias=True)

    # Store initial weights
    initial_weight = conv.weight.clone()
    initial_bias = conv.bias.clone() if conv.bias is not None else None

    # Reset parameters
    conv.reset_parameters()

    # Weights should be different (with high probability)
    assert not torch.allclose(conv.weight, initial_weight), (
        "Weights should be reinitialized"
    )
    if initial_bias is not None:
        # Bias should be zeros
        assert torch.allclose(conv.bias, torch.zeros_like(conv.bias)), (
            "Bias should be zeros"
        )


def test_hypergraph_conv_repr():
    """Test string representation of HypergraphConv."""
    conv = HypergraphConv(in_channels=16, out_channels=32)
    repr_str = repr(conv)

    assert "HypergraphConv" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str


def test_hypergraph_conv_large_hyperedges():
    """Test HypergraphConv with large hyperedges."""
    conv = HypergraphConv(in_channels=8, out_channels=16)
    x = torch.randn(100, 8)
    # Create large hyperedge with many nodes
    nodes = torch.arange(50)
    edges = torch.zeros(50, dtype=torch.long)
    edge_index = torch.stack([nodes, edges])

    out, edge_embed = conv(x, edge_index)

    assert out.shape == (100, 16)
    assert edge_embed.shape == (1, 16)


def test_hypergraph_conv_multiple_components():
    """Test HypergraphConv with disconnected components."""
    conv = HypergraphConv(in_channels=8, out_channels=16)
    x = torch.randn(10, 8)
    # Two disconnected components
    edge_index = torch.tensor([[0, 1, 2, 7, 8, 9], [0, 0, 0, 1, 1, 1]])

    out, edge_embed = conv(x, edge_index)

    assert out.shape == (10, 16)
    assert edge_embed.shape == (2, 16)


def test_hypergraph_conv_deterministic():
    """Test that HypergraphConv produces deterministic results."""
    torch.manual_seed(42)
    conv = HypergraphConv(in_channels=8, out_channels=16)
    x = torch.randn(10, 8)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # First forward pass
    out1, _edge1 = conv(x, edge_index)

    # Second forward pass with same inputs
    out2, _edge2 = conv(x, edge_index)

    assert torch.allclose(out1, out2), "Forward pass should be deterministic"
