"""Tests for HJRL utility functions."""

import numpy as np
import scipy.sparse as sp
import torch

from pyg_hyper_nn.layers.hjrl_utils import (
    hjrl_preprocessing,
    normalize_sparse_hypergraph_symmetric,
    precompute_node_edge_features,
    row_normalize,
    ssm2tst,
)


def test_row_normalize():
    """Test row normalization of sparse matrix."""
    # Create simple matrix
    mx = sp.csr_matrix(np.array([[1, 2], [3, 4], [5, 6]], dtype=np.float32))

    mx_norm = row_normalize(mx)

    # Check that rows sum to 1
    row_sums = np.array(mx_norm.sum(1)).flatten()
    assert np.allclose(row_sums, np.ones(3))


def test_row_normalize_zero_rows():
    """Test row normalization with zero rows."""
    # Include a zero row
    mx = sp.csr_matrix(np.array([[1, 2], [0, 0], [3, 4]], dtype=np.float32))

    mx_norm = row_normalize(mx)

    # Non-zero rows should sum to 1, zero rows should remain zero
    row_sums = np.array(mx_norm.sum(1)).flatten()
    assert np.allclose(row_sums[0], 1.0)
    assert np.allclose(row_sums[1], 0.0)
    assert np.allclose(row_sums[2], 1.0)


def test_normalize_sparse_hypergraph_symmetric():
    """Test symmetric hypergraph normalization."""
    # Create incidence matrix H (3 nodes, 2 edges)
    H = sp.coo_matrix(
        ([1.0, 1.0, 1.0, 1.0], ([0, 1, 1, 2], [0, 0, 1, 1])),
        shape=(3, 2),
        dtype=np.float32,
    )

    HHT, H_norm = normalize_sparse_hypergraph_symmetric(H)

    # Check shapes
    assert HHT.shape == (3, 3)  # Node-node
    assert H_norm.shape == (3, 2)  # Node-edge


def test_ssm2tst():
    """Test scipy sparse to torch sparse conversion."""
    # Create scipy sparse matrix
    M = sp.coo_matrix(
        ([1.0, 2.0, 3.0], ([0, 1, 2], [1, 2, 0])),
        shape=(3, 3),
        dtype=np.float32,
    )

    M_torch = ssm2tst(M)

    # Check it's a sparse tensor
    assert M_torch.is_sparse

    # Check shape
    assert M_torch.shape == (3, 3)

    # Check values
    M_dense = M_torch.to_dense()
    assert M_dense[0, 1] == 1.0
    assert M_dense[1, 2] == 2.0
    assert M_dense[2, 0] == 3.0


def test_precompute_node_edge_features():
    """Test node and edge feature precomputation."""
    # Create incidence matrix
    H = sp.coo_matrix(
        ([1.0, 1.0, 1.0], ([0, 1, 2], [0, 0, 0])),
        shape=(3, 1),
        dtype=np.float32,
    )

    # Node features
    X = torch.randn(3, 4)

    X_norm, E_norm = precompute_node_edge_features(H, X)

    # Check shapes
    assert X_norm.shape == (3, 4)
    assert E_norm.shape == (1, 4)  # 1 edge

    # Check row normalization (rows should sum to 1)
    X_row_sums = X_norm.sum(1)
    # Non-zero rows should sum to approximately 1
    for i in range(3):
        if X_norm[i].abs().sum() > 1e-6:
            assert torch.allclose(X_row_sums[i], torch.tensor(1.0), atol=1e-5)


def test_hjrl_preprocessing_basic():
    """Test HJRL preprocessing with basic hypergraph."""
    # Simple hypergraph: e0={0,1,2}
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    x = torch.randn(3, 4)
    num_nodes = 3
    num_edges = 1

    result = hjrl_preprocessing(hyperedge_index, x, num_nodes, num_edges)
    H_ini, H, HT, HHT, HTH, norm_X, norm_E = result

    # Check shapes
    assert H_ini.shape == (3, 1)
    assert H.is_sparse and H.shape == (3, 1)
    assert HT.is_sparse and HT.shape == (1, 3)
    assert HHT.is_sparse and HHT.shape == (3, 3)
    assert HTH.is_sparse and HTH.shape == (1, 1)
    assert norm_X.shape == (3, 4)
    assert norm_E.shape == (1, 4)


def test_hjrl_preprocessing_multiple_edges():
    """Test HJRL preprocessing with multiple hyperedges."""
    # e0={0,1}, e1={1,2}
    hyperedge_index = torch.tensor([[0, 1, 1, 2], [0, 0, 1, 1]])
    x = torch.randn(3, 4)
    num_nodes = 3
    num_edges = 2

    result = hjrl_preprocessing(hyperedge_index, x, num_nodes, num_edges)
    H_ini, H, HT, HHT, HTH, norm_X, norm_E = result

    # Check shapes
    assert H_ini.shape == (3, 2)
    assert H.is_sparse and H.shape == (3, 2)
    assert HT.is_sparse and HT.shape == (2, 3)
    assert HHT.is_sparse and HHT.shape == (3, 3)
    assert HTH.is_sparse and HTH.shape == (2, 2)
    assert norm_X.shape == (3, 4)
    assert norm_E.shape == (2, 4)


def test_hjrl_preprocessing_deterministic():
    """Test that preprocessing is deterministic."""
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
    x = torch.randn(4, 8)
    num_nodes = 4
    num_edges = 2

    result1 = hjrl_preprocessing(hyperedge_index, x, num_nodes, num_edges)
    result2 = hjrl_preprocessing(hyperedge_index, x, num_nodes, num_edges)

    # Check that results are identical
    for r1, r2 in zip(result1, result2):
        if isinstance(r1, torch.Tensor) and r1.is_sparse:
            assert torch.equal(r1.to_dense(), r2.to_dense())
        else:
            assert torch.equal(r1, r2)


def test_hjrl_preprocessing_empty():
    """Test preprocessing with empty hypergraph."""
    hyperedge_index = torch.tensor([[], []], dtype=torch.long).reshape(2, 0)
    x = torch.randn(5, 4)
    num_nodes = 5
    num_edges = 0

    result = hjrl_preprocessing(hyperedge_index, x, num_nodes, num_edges)
    H_ini, _H, _HT, _HHT, _HTH, norm_X, norm_E = result

    # Check shapes
    assert H_ini.shape == (5, 0)
    assert norm_X.shape == (5, 4)
    assert norm_E.shape == (0, 4)
