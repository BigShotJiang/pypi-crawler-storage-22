"""Tests for HyperGCNConv layer."""

import numpy as np
import pytest
import torch

from pyg_hyper_nn.layers.hypergcn_conv import HyperGCNConv
from pyg_hyper_nn.layers.hypergcn_utils import (
    get_hypergcn_he_dict,
    hypergcn_laplacian,
)


def test_hypergcn_conv_forward():
    """Test HyperGCNConv forward pass with reapproximation."""
    conv = HyperGCNConv(16, 32, reapproximate=True)

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
    hyperedge_dict = get_hypergcn_he_dict(hyperedge_index)

    np.random.seed(42)
    out = conv(x, structure=None, hyperedge_dict=hyperedge_dict, m=True)

    assert out.shape == (10, 32)


def test_hypergcn_conv_with_structure():
    """Test HyperGCNConv with precomputed structure."""
    conv = HyperGCNConv(16, 32, reapproximate=False)

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
    hyperedge_dict = get_hypergcn_he_dict(hyperedge_index)

    # Precompute structure
    X_np = x.detach().numpy()
    np.random.seed(42)
    structure = hypergcn_laplacian(10, hyperedge_dict, X_np, m=True)

    out = conv(x, structure=structure, hyperedge_dict=None, m=True)

    assert out.shape == (10, 32)


def test_hypergcn_conv_no_mediator():
    """Test HyperGCNConv without mediators."""
    conv = HyperGCNConv(16, 32, reapproximate=True)

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
    hyperedge_dict = get_hypergcn_he_dict(hyperedge_index)

    np.random.seed(42)
    out = conv(x, structure=None, hyperedge_dict=hyperedge_dict, m=False)

    assert out.shape == (10, 32)


def test_hypergcn_conv_gradient_flow():
    """Test gradient flow through HyperGCNConv."""
    conv = HyperGCNConv(16, 32, reapproximate=False)

    x = torch.randn(10, 16, requires_grad=True)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    hyperedge_dict = get_hypergcn_he_dict(hyperedge_index)

    # Precompute structure to avoid recomputation
    X_np = x.detach().numpy()
    np.random.seed(42)
    structure = hypergcn_laplacian(10, hyperedge_dict, X_np, m=True)

    out = conv(x, structure=structure, hyperedge_dict=None, m=True)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None
    assert conv.W.grad is not None
    assert conv.bias.grad is not None


def test_hypergcn_conv_reset_parameters():
    """Test parameter reset."""
    conv = HyperGCNConv(16, 32)

    # Save initial parameters
    W_before = conv.W.data.clone()
    bias_before = conv.bias.data.clone()

    # Reset
    conv.reset_parameters()

    # Parameters should change (with high probability)
    assert not torch.allclose(W_before, conv.W.data)
    assert not torch.allclose(bias_before, conv.bias.data)


def test_hypergcn_conv_single_layer():
    """Test with single node per hyperedge."""
    conv = HyperGCNConv(16, 32, reapproximate=True)

    x = torch.randn(3, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 1, 2]])
    hyperedge_dict = get_hypergcn_he_dict(hyperedge_index)

    np.random.seed(42)
    out = conv(x, structure=None, hyperedge_dict=hyperedge_dict, m=True)

    assert out.shape == (3, 32)


def test_hypergcn_conv_different_output_dim():
    """Test with different output dimensions."""
    conv = HyperGCNConv(16, 64)

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    hyperedge_dict = get_hypergcn_he_dict(hyperedge_index)

    np.random.seed(42)
    out = conv(x, structure=None, hyperedge_dict=hyperedge_dict, m=True)

    assert out.shape == (10, 64)


def test_hypergcn_conv_repr():
    """Test string representation."""
    conv = HyperGCNConv(16, 32)
    repr_str = repr(conv)

    assert "HyperGCNConv" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str


def test_hypergcn_conv_missing_structure_error():
    """Test error when structure is missing and reapproximate is False."""
    conv = HyperGCNConv(16, 32, reapproximate=False)

    x = torch.randn(10, 16)

    with pytest.raises(ValueError, match="Either structure must be provided"):
        conv(x, structure=None, hyperedge_dict=None, m=True)


def test_hypergcn_conv_cuda():
    """Test HyperGCNConv on CUDA if available."""
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")

    device = torch.device("cuda")
    conv = HyperGCNConv(16, 32, reapproximate=False).to(device)

    x = torch.randn(10, 16, device=device)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    hyperedge_dict = get_hypergcn_he_dict(hyperedge_index)

    # Precompute structure on CPU
    X_np = x.cpu().detach().numpy()
    np.random.seed(42)
    structure = hypergcn_laplacian(10, hyperedge_dict, X_np, m=True)

    out = conv(x, structure=structure, hyperedge_dict=None, m=True)

    assert out.device.type == device.type
    assert out.shape == (10, 32)
