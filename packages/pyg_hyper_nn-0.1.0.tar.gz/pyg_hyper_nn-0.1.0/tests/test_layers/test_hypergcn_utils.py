"""Tests for HyperGCN utility functions."""

import numpy as np
import scipy.sparse as sp
import torch

from pyg_hyper_nn.layers.hypergcn_utils import (
    adjacency,
    get_hypergcn_he_dict,
    hypergcn_laplacian,
    ssm2tst,
    symnormalise,
)


def test_get_hypergcn_he_dict():
    """Test conversion of hyperedge_index to dictionary format."""
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
    he_dict = get_hypergcn_he_dict(hyperedge_index)

    assert len(he_dict) == 2
    assert set(he_dict[0]) == {0, 1, 2}
    assert set(he_dict[1]) == {1, 2, 3}


def test_get_hypergcn_he_dict_single_node():
    """Test with hyperedges containing single nodes."""
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 1, 2]])
    he_dict = get_hypergcn_he_dict(hyperedge_index)

    assert len(he_dict) == 3
    assert he_dict[0] == [0]
    assert he_dict[1] == [1]
    assert he_dict[2] == [2]


def test_symnormalise():
    """Test symmetric normalization of sparse matrix."""
    # Create simple adjacency matrix
    adj = sp.csr_matrix(np.array([[0, 1, 1], [1, 0, 1], [1, 1, 0]], dtype=np.float32))

    norm_adj = symnormalise(adj)

    # Check shape preserved
    assert norm_adj.shape == (3, 3)

    # Convert to dense for checking
    norm_dense = norm_adj.toarray()

    # Check symmetry
    assert np.allclose(norm_dense, norm_dense.T)

    # Check row sums are approximately 1 (normalized)
    row_sums = np.array(norm_adj.sum(1)).flatten()
    assert np.allclose(row_sums, np.ones(3), atol=1e-6)


def test_ssm2tst():
    """Test conversion from scipy sparse to torch sparse."""
    # Create scipy sparse matrix
    M = sp.coo_matrix(
        ([1.0, 2.0, 3.0], ([0, 1, 2], [1, 2, 0])),
        shape=(3, 3),
        dtype=np.float32,
    )

    # Convert to torch
    M_torch = ssm2tst(M)

    # Check it's a sparse tensor
    assert M_torch.is_sparse

    # Check shape
    assert M_torch.shape == (3, 3)

    # Check values
    M_dense = M_torch.to_dense()
    assert M_dense[0, 1] == 1.0
    assert M_dense[1, 2] == 2.0
    assert M_dense[2, 0] == 3.0


def test_adjacency():
    """Test adjacency matrix construction."""
    edges = [[0, 1], [1, 0], [1, 2], [2, 1]]
    weights = {(0, 1): 0.5, (1, 0): 0.5, (1, 2): 0.3, (2, 1): 0.3}
    n = 3

    adj = adjacency(edges, weights, n)

    # Check it's a sparse tensor
    assert adj.is_sparse

    # Check shape
    assert adj.shape == (3, 3)

    # Convert to dense for checking
    adj_dense = adj.to_dense()

    # Check self-loops added and normalized
    assert (adj_dense.diag() > 0).all()


def test_adjacency_duplicate_edges():
    """Test adjacency with duplicate edges (weights should be summed)."""
    edges = [[0, 1], [0, 1], [1, 0]]
    weights = {(0, 1): 0.5, (1, 0): 0.3}
    n = 2

    adj = adjacency(edges, weights, n)

    # Should handle duplicates correctly
    assert adj.shape == (2, 2)


def test_hypergcn_laplacian_no_mediator():
    """Test HyperGCN Laplacian without mediators."""
    # Create simple hypergraph
    E = {0: [0, 1, 2], 1: [1, 2, 3]}
    V = 4
    X = np.random.randn(V, 16).astype(np.float32)

    np.random.seed(42)
    A = hypergcn_laplacian(V, E, X, m=False)

    # Check output is sparse tensor
    assert A.is_sparse

    # Check shape
    assert A.shape == (V, V)

    # Convert to dense
    A_dense = A.to_dense()

    # Check self-loops present
    assert (A_dense.diag() > 0).all()

    # Check symmetric
    assert torch.allclose(A_dense, A_dense.t(), atol=1e-6)


def test_hypergcn_laplacian_with_mediator():
    """Test HyperGCN Laplacian with mediators."""
    # Create simple hypergraph
    E = {0: [0, 1, 2], 1: [1, 2, 3]}
    V = 4
    X = np.random.randn(V, 16).astype(np.float32)

    np.random.seed(42)
    A = hypergcn_laplacian(V, E, X, m=True)

    # Check output is sparse tensor
    assert A.is_sparse

    # Check shape
    assert A.shape == (V, V)

    # Convert to dense
    A_dense = A.to_dense()

    # Check self-loops present
    assert (A_dense.diag() > 0).all()

    # Check symmetric
    assert torch.allclose(A_dense, A_dense.t(), atol=1e-6)


def test_hypergcn_laplacian_single_node_hyperedge():
    """Test with hyperedge containing single node."""
    E = {0: [0]}
    V = 1
    X = np.random.randn(V, 16).astype(np.float32)

    np.random.seed(42)
    A = hypergcn_laplacian(V, E, X, m=False)

    # Should still work
    assert A.shape == (V, V)


def test_hypergcn_laplacian_determinism():
    """Test that same seed produces same result."""
    E = {0: [0, 1, 2]}
    V = 3
    X = np.random.randn(V, 16).astype(np.float32)

    np.random.seed(42)
    A1 = hypergcn_laplacian(V, E, X, m=False)

    np.random.seed(42)
    A2 = hypergcn_laplacian(V, E, X, m=False)

    # Should be identical
    assert torch.allclose(A1.to_dense(), A2.to_dense())
