"""Tests for kernelized attention mechanisms."""

import torch

from pyg_hyper_nn.layers.kernelized_attention import (
    create_projection_matrix,
    denominator,
    kernelized_softmax,
    numerator,
    softmax_kernel_transformation,
)


def test_create_projection_matrix():
    """Test random projection matrix creation."""
    m, d = 64, 32
    proj = create_projection_matrix(m, d, seed=42)

    assert proj.shape == (m, d)
    assert not torch.isnan(proj).any()
    assert not torch.isinf(proj).any()


def test_create_projection_matrix_deterministic():
    """Test that same seed produces same matrix."""
    m, d = 64, 32
    proj1 = create_projection_matrix(m, d, seed=42)
    proj2 = create_projection_matrix(m, d, seed=42)

    assert torch.allclose(proj1, proj2)


def test_softmax_kernel_transformation_query():
    """Test softmax kernel transformation for queries."""
    B, N, H, D = 1, 10, 4, 32
    M = 64

    data = torch.randn(B, N, H, D)
    proj = create_projection_matrix(M, D, seed=42)

    transformed = softmax_kernel_transformation(
        data, is_query=True, projection_matrix=proj
    )

    assert transformed.shape == (B, N, H, M)
    assert not torch.isnan(transformed).any()
    assert (transformed > 0).all()  # Should be positive after exp


def test_softmax_kernel_transformation_key():
    """Test softmax kernel transformation for keys."""
    B, N, H, D = 1, 10, 4, 32
    M = 64

    data = torch.randn(B, N, H, D)
    proj = create_projection_matrix(M, D, seed=42)

    transformed = softmax_kernel_transformation(
        data, is_query=False, projection_matrix=proj
    )

    assert transformed.shape == (B, N, H, M)
    assert not torch.isnan(transformed).any()
    assert (transformed > 0).all()


def test_numerator():
    """Test numerator computation."""
    N, B, H, M, D = 10, 1, 4, 64, 32

    qs = torch.randn(N, B, H, M)
    ks = torch.randn(N, B, H, M)
    vs = torch.randn(N, B, H, D)

    result = numerator(qs, ks, vs)

    assert result.shape == (N, B, H, D)
    assert not torch.isnan(result).any()


def test_denominator():
    """Test denominator computation."""
    N, B, H, M, D = 10, 1, 4, 64, 32

    # Use kernel-transformed features (positive values)
    data_q = torch.randn(B, N, H, D)
    data_k = torch.randn(B, N, H, D)
    proj = create_projection_matrix(M, D, seed=42)

    qs = softmax_kernel_transformation(data_q, True, proj).permute(1, 0, 2, 3)
    ks = softmax_kernel_transformation(data_k, False, proj).permute(1, 0, 2, 3)

    result = denominator(qs, ks)

    assert result.shape == (N, B, H)
    assert not torch.isnan(result).any()
    assert (result > 0).all()  # Should be positive after kernel transformation


def test_kernelized_softmax():
    """Test full kernelized softmax attention."""
    B, N, H, D = 1, 20, 4, 32
    M = 64

    query = torch.randn(B, N, H, D)
    key = torch.randn(B, N, H, D)
    value = torch.randn(B, N, H, D)
    proj = create_projection_matrix(M, D, seed=42)

    output = kernelized_softmax(query, key, value, proj, tau=0.25)

    assert output.shape == (B, N, H, D)
    assert not torch.isnan(output).any()
    assert not torch.isinf(output).any()


def test_kernelized_softmax_gradient():
    """Test gradient flow through kernelized softmax."""
    B, N, H, D = 1, 20, 4, 32
    M = 64

    query = torch.randn(B, N, H, D, requires_grad=True)
    key = torch.randn(B, N, H, D, requires_grad=True)
    value = torch.randn(B, N, H, D, requires_grad=True)
    proj = create_projection_matrix(M, D, seed=42)

    output = kernelized_softmax(query, key, value, proj)
    loss = output.sum()
    loss.backward()

    assert query.grad is not None
    assert key.grad is not None
    assert value.grad is not None
    assert not torch.isnan(query.grad).any()


def test_kernelized_softmax_batch():
    """Test kernelized softmax with batch size > 1."""
    B, N, H, D = 4, 20, 4, 32
    M = 64

    query = torch.randn(B, N, H, D)
    key = torch.randn(B, N, H, D)
    value = torch.randn(B, N, H, D)
    proj = create_projection_matrix(M, D, seed=42)

    output = kernelized_softmax(query, key, value, proj)

    assert output.shape == (B, N, H, D)
    assert not torch.isnan(output).any()
