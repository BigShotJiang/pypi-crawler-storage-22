"""Tests for LEGCN utility functions."""

import torch

from pyg_hyper_nn.layers.legcn_utils import line_expansion


def test_line_expansion_basic():
    """Test line expansion with simple hypergraph."""
    # Hypergraph: e0={0,1}, e1={1,2}
    hyperedge_index = torch.tensor([[0, 1, 1, 2], [0, 0, 1, 1]])
    num_nodes = 3

    le_adj = line_expansion(hyperedge_index, num_nodes)

    # Should have 4 pairs: (0,e0), (1,e0), (1,e1), (2,e1)
    assert le_adj.shape[0] == 2  # COO format
    assert le_adj.shape[1] > 0  # Has edges


def test_line_expansion_single_hyperedge():
    """Test with single hyperedge."""
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    num_nodes = 3

    le_adj = line_expansion(hyperedge_index, num_nodes)

    # Should have 3 pairs
    assert le_adj.shape[0] == 2


def test_line_expansion_isolated_node():
    """Test with node not in any hyperedge."""
    # Node 3 is isolated
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    num_nodes = 4

    le_adj = line_expansion(hyperedge_index, num_nodes)

    # Should still work, isolated node won't appear in line graph
    assert le_adj.shape[0] == 2


def test_line_expansion_multiple_hyperedges():
    """Test with multiple overlapping hyperedges."""
    # e0={0,1,2}, e1={1,2,3}, e2={2,3,4}
    hyperedge_index = torch.tensor(
        [[0, 1, 2, 1, 2, 3, 2, 3, 4], [0, 0, 0, 1, 1, 1, 2, 2, 2]]
    )
    num_nodes = 5

    le_adj = line_expansion(hyperedge_index, num_nodes)

    # Should have 9 pairs
    assert le_adj.shape[0] == 2
    assert le_adj.shape[1] > 0


def test_line_expansion_device_consistency():
    """Test that output device matches input device."""
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    num_nodes = 3

    # CPU
    le_adj = line_expansion(hyperedge_index, num_nodes)
    assert le_adj.device.type == hyperedge_index.device.type

    # CUDA (if available)
    if torch.cuda.is_available():
        hyperedge_index_cuda = hyperedge_index.cuda()
        le_adj_cuda = line_expansion(hyperedge_index_cuda, num_nodes)
        assert le_adj_cuda.device.type == "cuda"


def test_line_expansion_edge_connectivity():
    """Test that pairs sharing nodes or hyperedges are connected."""
    # e0={0,1}
    hyperedge_index = torch.tensor([[0, 1], [0, 0]])
    num_nodes = 2

    le_adj = line_expansion(hyperedge_index, num_nodes)

    # The two pairs (0,e0) and (1,e0) should be connected
    # because they share hyperedge e0
    assert le_adj.shape[0] == 2
    assert le_adj.shape[1] >= 2  # At least self-loops + connection


def test_line_expansion_deterministic():
    """Test that line expansion is deterministic."""
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
    num_nodes = 4

    le_adj1 = line_expansion(hyperedge_index, num_nodes)
    le_adj2 = line_expansion(hyperedge_index, num_nodes)

    # Should produce identical results
    assert torch.equal(le_adj1, le_adj2)


def test_line_expansion_empty():
    """Test with empty hypergraph."""
    hyperedge_index = torch.tensor([[], []], dtype=torch.long).reshape(2, 0)
    num_nodes = 5

    le_adj = line_expansion(hyperedge_index, num_nodes)

    # Should return empty adjacency
    assert le_adj.shape[0] == 2
    assert le_adj.shape[1] == 0


def test_line_expansion_large_hypergraph():
    """Test with larger hypergraph."""
    # 100 nodes, 20 hyperedges, random connections
    torch.manual_seed(42)
    nodes = torch.randint(0, 100, (500,))
    edges = torch.randint(0, 20, (500,))
    hyperedge_index = torch.stack([nodes, edges])
    num_nodes = 100

    le_adj = line_expansion(hyperedge_index, num_nodes)

    # Should handle large inputs
    assert le_adj.shape[0] == 2
    assert le_adj.shape[1] > 0
