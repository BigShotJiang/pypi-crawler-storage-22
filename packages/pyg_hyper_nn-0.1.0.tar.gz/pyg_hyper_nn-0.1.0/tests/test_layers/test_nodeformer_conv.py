"""Tests for NodeFormerConv layer."""

import torch

from pyg_hyper_nn.layers.nodeformer_conv import NodeFormerConv


def test_nodeformer_conv_forward():
    """Test NodeFormerConv forward pass."""
    B, N, D_in, D_out = 2, 20, 32, 16
    num_heads = 4

    layer = NodeFormerConv(D_in, D_out, num_heads=num_heads)
    x = torch.randn(B, N, D_in)

    output = layer(x)

    assert output.shape == (B, N, D_out)
    assert not torch.isnan(output).any()


def test_nodeformer_conv_single_batch():
    """Test with single batch."""
    B, N, D_in, D_out = 1, 10, 16, 8

    layer = NodeFormerConv(D_in, D_out, num_heads=2)
    x = torch.randn(B, N, D_in)

    output = layer(x)

    assert output.shape == (B, N, D_out)


def test_nodeformer_conv_gradient():
    """Test gradient flow through NodeFormerConv."""
    B, N, D_in, D_out = 1, 10, 16, 8

    layer = NodeFormerConv(D_in, D_out)
    x = torch.randn(B, N, D_in, requires_grad=True)

    output = layer(x)
    loss = output.sum()
    loss.backward()

    assert x.grad is not None
    assert not torch.isnan(x.grad).any()


def test_nodeformer_conv_temperature():
    """Test with different temperature values."""
    B, N, D_in, D_out = 1, 10, 16, 8

    layer = NodeFormerConv(D_in, D_out, tau=0.25)
    x = torch.randn(B, N, D_in)

    # Use default tau
    output1 = layer(x)

    # Override tau
    output2 = layer(x, tau=0.5)

    assert output1.shape == output2.shape
    # Outputs should be different due to different temperature
    assert not torch.allclose(output1, output2)


def test_nodeformer_conv_reset_parameters():
    """Test parameter reset."""
    layer = NodeFormerConv(16, 8)

    # Get initial weights
    wq_before = layer.Wq.weight.clone()

    # Reset
    layer.reset_parameters()

    # Weights should be different after reset
    wq_after = layer.Wq.weight
    assert not torch.allclose(wq_before, wq_after)


def test_nodeformer_conv_repr():
    """Test string representation."""
    layer = NodeFormerConv(16, 8, num_heads=4)
    repr_str = repr(layer)

    assert "NodeFormerConv" in repr_str
    assert "16" in repr_str
    assert "8" in repr_str
    assert "num_heads=4" in repr_str


def test_nodeformer_conv_deterministic():
    """Test that same input produces same output."""
    B, N, D_in, D_out = 1, 10, 16, 8

    layer = NodeFormerConv(D_in, D_out, nb_random_features=32)
    x = torch.randn(B, N, D_in)

    # Two forward passes with same input
    layer.eval()
    with torch.no_grad():
        output1 = layer(x)
        output2 = layer(x)

    # Should be identical (deterministic seed)
    assert torch.allclose(output1, output2)
