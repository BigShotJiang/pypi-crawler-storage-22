"""Tests for PhenomNN preprocessing utilities."""

import pytest
import torch

from pyg_hyper_nn.layers.preprocessing import phenomnn_expansion


def test_phenomnn_expansion_basic_full():
    """Test phenomnn_expansion with basic hypergraph and full normalization."""
    # Simple hypergraph: edge 0 contains nodes [0, 1, 2]
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    num_nodes = 3

    A_beta, D_beta, I = phenomnn_expansion(hyperedge_index, num_nodes, norm_type="full")

    # Check shapes
    assert A_beta.shape == (3, 3)
    assert D_beta.shape == (3, 3)
    assert I.shape == (3, 3)

    # Check that all are sparse
    assert A_beta.is_sparse
    assert D_beta.is_sparse
    assert I.is_sparse

    # Check that A_beta is symmetric
    A_dense = A_beta.to_dense()
    assert torch.allclose(A_dense, A_dense.t(), atol=1e-6)

    # Check that I is identity
    I_dense = I.to_dense()
    expected_I = torch.eye(3)
    assert torch.allclose(I_dense, expected_I, atol=1e-6)

    # Check that D_beta is diagonal
    D_dense = D_beta.to_dense()
    assert torch.allclose(D_dense, torch.diag(torch.diag(D_dense)), atol=1e-6)


def test_phenomnn_expansion_basic_node():
    """Test phenomnn_expansion with basic hypergraph and node normalization."""
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    num_nodes = 3

    A_beta, D_beta, I = phenomnn_expansion(hyperedge_index, num_nodes, norm_type="node")

    # Check shapes
    assert A_beta.shape == (3, 3)
    assert D_beta.shape == (3, 3)
    assert I.shape == (3, 3)

    # Check that A_beta is symmetric
    A_dense = A_beta.to_dense()
    assert torch.allclose(A_dense, A_dense.t(), atol=1e-6)

    # All nodes should be connected (in same hyperedge)
    assert (A_dense > 0).all()


def test_phenomnn_expansion_multiple_edges():
    """Test phenomnn_expansion with multiple hyperedges."""
    # Two hyperedges: [0,1,2] and [1,2,3]
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
    num_nodes = 4

    A_beta, _D_beta, _I = phenomnn_expansion(
        hyperedge_index, num_nodes, norm_type="full"
    )

    assert A_beta.shape == (4, 4)
    A_dense = A_beta.to_dense()

    # Nodes 0,1,2 should be connected (edge 0)
    assert A_dense[0, 1] > 0
    assert A_dense[0, 2] > 0
    assert A_dense[1, 2] > 0

    # Nodes 1,2,3 should be connected (edge 1)
    assert A_dense[1, 3] > 0
    assert A_dense[2, 3] > 0


def test_phenomnn_expansion_empty_hypergraph():
    """Test phenomnn_expansion with empty hypergraph."""
    hyperedge_index = torch.tensor([[], []]).long()
    num_nodes = 5

    A_beta, D_beta, I = phenomnn_expansion(hyperedge_index, num_nodes, norm_type="full")

    assert A_beta.shape == (5, 5)
    assert D_beta.shape == (5, 5)
    assert I.shape == (5, 5)

    # Should be identity matrices
    A_dense = A_beta.to_dense()
    D_dense = D_beta.to_dense()
    I_dense = I.to_dense()

    expected_I = torch.eye(5)
    assert torch.allclose(A_dense, expected_I, atol=1e-6)
    assert torch.allclose(D_dense, expected_I, atol=1e-6)
    assert torch.allclose(I_dense, expected_I, atol=1e-6)


def test_phenomnn_expansion_single_node():
    """Test phenomnn_expansion with single node hyperedge."""
    hyperedge_index = torch.tensor([[0], [0]])
    num_nodes = 1

    A_beta, D_beta, I = phenomnn_expansion(hyperedge_index, num_nodes, norm_type="full")

    assert A_beta.shape == (1, 1)
    assert D_beta.shape == (1, 1)
    assert I.shape == (1, 1)


def test_phenomnn_expansion_full_vs_node():
    """Test that full and node normalization give different results."""
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
    num_nodes = 4

    A_full, _D_full, I_full = phenomnn_expansion(
        hyperedge_index, num_nodes, norm_type="full"
    )
    A_node, _D_node, I_node = phenomnn_expansion(
        hyperedge_index, num_nodes, norm_type="node"
    )

    # Identity matrices should be the same
    assert torch.allclose(I_full.to_dense(), I_node.to_dense(), atol=1e-6)

    # Adjacency matrices should be different (due to different normalization)
    assert not torch.allclose(A_full.to_dense(), A_node.to_dense(), atol=1e-3)


def test_phenomnn_expansion_invalid_norm_type():
    """Test phenomnn_expansion with invalid normalization type."""
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    num_nodes = 3

    with pytest.raises(ValueError, match="Unknown normalization type"):
        phenomnn_expansion(hyperedge_index, num_nodes, norm_type="invalid")


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_phenomnn_expansion_cuda():
    """Test phenomnn_expansion on CUDA device."""
    device = torch.device("cuda")
    hyperedge_index = torch.tensor(
        [[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]], device=device
    )
    num_nodes = 4

    A_beta, D_beta, I = phenomnn_expansion(hyperedge_index, num_nodes, norm_type="full")

    # Results should be on CPU (scipy operations are CPU-only)
    # But they should be valid tensors
    assert A_beta.shape == (4, 4)
    assert D_beta.shape == (4, 4)
    assert I.shape == (4, 4)


def test_phenomnn_expansion_consistency_with_tfhnn():
    """Test that phenomnn_expansion is consistent with TFHNN's weighted_ce_graph."""
    # Both use similar matrix operations: D^{-1/2} (H B H^T + I) D^{-1/2}
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    num_nodes = 3

    A_beta, _D_beta, _I = phenomnn_expansion(
        hyperedge_index, num_nodes, norm_type="full"
    )

    A_dense = A_beta.to_dense()

    # Should be symmetric
    assert torch.allclose(A_dense, A_dense.t(), atol=1e-6)

    # Should have positive values
    assert (A_dense >= 0).all()

    # Diagonal should be positive (self-loops from identity)
    assert (torch.diag(A_dense) > 0).all()
