"""Tests for preprocessing utilities."""

import torch

from pyg_hyper_nn.layers.preprocessing import (
    clique_expansion,
    construct_incidence_matrix,
)


def test_construct_incidence_matrix_basic():
    """Test basic incidence matrix construction."""
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
    num_nodes = 4

    H = construct_incidence_matrix(hyperedge_index, num_nodes)

    assert H.shape == (num_nodes, 2)  # 2 hyperedges
    assert H.is_sparse

    # Convert to dense for checking
    H_dense = H.to_dense()
    assert H_dense[0, 0] == 1  # Node 0 in hyperedge 0
    assert H_dense[1, 0] == 1  # Node 1 in hyperedge 0
    assert H_dense[2, 0] == 1  # Node 2 in hyperedge 0
    assert H_dense[1, 1] == 1  # Node 1 in hyperedge 1
    assert H_dense[2, 1] == 1  # Node 2 in hyperedge 1
    assert H_dense[3, 1] == 1  # Node 3 in hyperedge 1


def test_construct_incidence_matrix_empty():
    """Test with empty hypergraph."""
    hyperedge_index = torch.empty((2, 0), dtype=torch.long)
    num_nodes = 5

    H = construct_incidence_matrix(hyperedge_index, num_nodes, num_hyperedges=0)

    assert H.shape == (num_nodes, 0)
    assert H.is_sparse


def test_construct_incidence_matrix_specified_hyperedges():
    """Test with explicitly specified number of hyperedges."""
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    num_nodes = 4
    num_hyperedges = 3  # More hyperedges than in data

    H = construct_incidence_matrix(hyperedge_index, num_nodes, num_hyperedges)

    assert H.shape == (num_nodes, num_hyperedges)


def test_clique_expansion_basic():
    """Test basic clique expansion."""
    # Single hyperedge {0, 1, 2}
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    edge_index = clique_expansion(hyperedge_index, num_nodes=3)

    # Should create edges: (0,1), (0,2), (1,0), (1,2), (2,0), (2,1)
    assert edge_index.shape[0] == 2
    assert edge_index.shape[1] == 6  # 3 nodes -> 3*2 directed edges


def test_clique_expansion_multiple_hyperedges():
    """Test clique expansion with multiple hyperedges."""
    # Two hyperedges: {0, 1, 2} and {1, 2, 3}
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    edge_index = clique_expansion(hyperedge_index, num_nodes=4)

    # First hyperedge: (0,1), (0,2), (1,0), (1,2), (2,0), (2,1) = 6 edges
    # Second hyperedge: (1,2), (1,3), (2,1), (2,3), (3,1), (3,2) = 6 edges
    # Some edges overlap (e.g., (1,2) appears in both)
    # After unique: should have fewer edges
    assert edge_index.shape[0] == 2
    # Unique edges: (0,1), (0,2), (1,0), (1,2), (1,3), (2,0), (2,1), (2,3), (3,1), (3,2)
    assert edge_index.shape[1] <= 12


def test_clique_expansion_single_node():
    """Test clique expansion with single-node hyperedge."""
    # Single-node hyperedge {0}
    hyperedge_index = torch.tensor([[0], [0]])

    edge_index = clique_expansion(hyperedge_index, num_nodes=1)

    # Single node -> no edges (self-loops excluded)
    assert edge_index.shape[1] == 0


def test_clique_expansion_empty():
    """Test clique expansion with empty hypergraph."""
    hyperedge_index = torch.tensor([[], []], dtype=torch.long)

    edge_index = clique_expansion(hyperedge_index, num_nodes=0)

    assert edge_index.shape == (2, 0)


def test_clique_expansion_infer_num_nodes():
    """Test clique expansion with inferred num_nodes."""
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # Don't specify num_nodes
    edge_index = clique_expansion(hyperedge_index)

    assert edge_index.shape[0] == 2
    assert edge_index.shape[1] > 0


def test_clique_expansion_device():
    """Test clique expansion preserves device."""
    if not torch.cuda.is_available():
        # Skip if CUDA not available
        return

    device = torch.device("cuda")
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]], device=device)

    edge_index = clique_expansion(hyperedge_index)

    assert edge_index.device.type == device.type
