"""Tests for sheaf builder (diagonal restriction map predictor)."""

import pytest
import torch

from pyg_hyper_nn.layers.sheaf_builder import (
    SheafBuilderDiag,
    predict_blocks_var1,
    predict_blocks_var2,
    predict_blocks_var3,
)


def test_predict_blocks_var1_basic():
    """Test predict_blocks_var1 with basic inputs."""
    x = torch.randn(10, 16)  # 10 nodes, 16 features
    e = torch.randn(5, 16)  # 5 edges, 16 features
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 0, 1, 1]])  # 4 pairs

    # Create simple MLP
    sheaf_lin = torch.nn.Linear(32, 4)  # 2*16 -> 4

    h_sheaf = predict_blocks_var1(x, e, hyperedge_index, sheaf_lin, "sigmoid")

    assert h_sheaf.shape == (4, 4)  # 4 pairs, 4 diagonal elements each
    assert torch.all((h_sheaf >= 0) & (h_sheaf <= 1))  # sigmoid range


def test_predict_blocks_var1_tanh():
    """Test predict_blocks_var1 with tanh activation."""
    x = torch.randn(10, 16)
    e = torch.randn(5, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 1]])

    sheaf_lin = torch.nn.Linear(32, 3)

    h_sheaf = predict_blocks_var1(x, e, hyperedge_index, sheaf_lin, "tanh")

    assert h_sheaf.shape == (3, 3)
    assert torch.all((h_sheaf >= -1) & (h_sheaf <= 1))  # tanh range


def test_predict_blocks_var2_basic():
    """Test predict_blocks_var2 with mean aggregation."""
    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 0, 1, 1]])

    sheaf_lin = torch.nn.Linear(32, 4)

    h_sheaf = predict_blocks_var2(x, hyperedge_index, sheaf_lin, "sigmoid")

    assert h_sheaf.shape == (4, 4)
    assert torch.all((h_sheaf >= 0) & (h_sheaf <= 1))


def test_predict_blocks_var3_basic():
    """Test predict_blocks_var3 with learned aggregation."""
    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 0, 1, 1]])

    sheaf_lin = torch.nn.Linear(32, 4)
    sheaf_lin2 = torch.nn.Linear(16, 16)

    h_sheaf = predict_blocks_var3(x, hyperedge_index, sheaf_lin, sheaf_lin2, "sigmoid")

    assert h_sheaf.shape == (4, 4)
    assert torch.all((h_sheaf >= 0) & (h_sheaf <= 1))


def test_sheaf_builder_diag_init():
    """Test SheafBuilderDiag initialization."""
    builder = SheafBuilderDiag(
        hidden_channels=32,
        stalk_dim=4,
        prediction_type="MLP_var2",
        sheaf_act="sigmoid",
    )

    assert builder.hidden_channels == 32
    assert builder.d == 4
    assert builder.prediction_type == "MLP_var2"
    assert builder.sheaf_act == "sigmoid"


def test_sheaf_builder_diag_var1_forward():
    """Test SheafBuilderDiag forward pass with var1."""
    builder = SheafBuilderDiag(
        hidden_channels=16,
        stalk_dim=3,
        prediction_type="MLP_var1",
        sheaf_act="sigmoid",
    )

    # Create inputs: (Nd x f), (Ed x f)
    num_nodes, num_edges = 5, 3
    d = 3
    x = torch.randn(num_nodes * d, 16)  # 15 x 16
    e = torch.randn(num_edges * d, 16)  # 9 x 16
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2], [0, 0, 0, 1, 1]])

    h_sheaf_index, h_sheaf_attributes = builder(x, e, hyperedge_index)

    # 5 pairs, each expanded to d diagonal entries
    assert h_sheaf_index.shape == (2, 5 * d)
    assert h_sheaf_attributes.shape == (5 * d,)
    assert torch.all((h_sheaf_attributes >= 0) & (h_sheaf_attributes <= 1))


def test_sheaf_builder_diag_var2_forward():
    """Test SheafBuilderDiag forward pass with var2."""
    builder = SheafBuilderDiag(
        hidden_channels=16,
        stalk_dim=2,
        prediction_type="MLP_var2",
        sheaf_act="tanh",
    )

    num_nodes, num_edges = 10, 5
    d = 2
    x = torch.randn(num_nodes * d, 16)
    e = torch.randn(num_edges * d, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 3, 4, 5], [0, 0, 1, 1, 2, 2]])

    h_sheaf_index, h_sheaf_attributes = builder(x, e, hyperedge_index)

    assert h_sheaf_index.shape == (2, 6 * d)
    assert h_sheaf_attributes.shape == (6 * d,)
    assert torch.all((h_sheaf_attributes >= -1) & (h_sheaf_attributes <= 1))


def test_sheaf_builder_diag_var3_forward():
    """Test SheafBuilderDiag forward pass with var3."""
    builder = SheafBuilderDiag(
        hidden_channels=16,
        stalk_dim=4,
        prediction_type="MLP_var3",
        sheaf_act="sigmoid",
    )

    num_nodes, num_edges = 8, 4
    d = 4
    x = torch.randn(num_nodes * d, 16)
    e = torch.randn(num_edges * d, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 3, 4], [0, 0, 1, 1, 2]])

    h_sheaf_index, h_sheaf_attributes = builder(x, e, hyperedge_index)

    assert h_sheaf_index.shape == (2, 5 * d)
    assert h_sheaf_attributes.shape == (5 * d,)


def test_sheaf_builder_diag_special_head():
    """Test SheafBuilderDiag with special head enabled."""
    builder = SheafBuilderDiag(
        hidden_channels=16,
        stalk_dim=3,
        prediction_type="MLP_var2",
        sheaf_act="sigmoid",
        special_head=True,
    )

    num_nodes, num_edges = 5, 3
    d = 3
    x = torch.randn(num_nodes * d, 16)
    e = torch.randn(num_edges * d, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 1]])

    _h_sheaf_index, h_sheaf_attributes = builder(x, e, hyperedge_index)

    # Check that last element of each d-block is 1
    h_sheaf_attributes = h_sheaf_attributes.view(-1, d)
    assert torch.allclose(h_sheaf_attributes[:, -1], torch.ones(3))


def test_sheaf_builder_diag_dropout():
    """Test SheafBuilderDiag with dropout enabled."""
    builder = SheafBuilderDiag(
        hidden_channels=16,
        stalk_dim=2,
        prediction_type="MLP_var2",
        sheaf_act="sigmoid",
        sheaf_dropout=True,
        dropout=0.5,
    )

    num_nodes, num_edges = 10, 5
    d = 2
    x = torch.randn(num_nodes * d, 16)
    e = torch.randn(num_edges * d, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 0, 1, 1]])

    # Training mode: dropout applied
    builder.train()
    out1 = builder(x, e, hyperedge_index)
    out2 = builder(x, e, hyperedge_index)

    # Outputs should differ due to dropout
    assert not torch.allclose(out1[1], out2[1])

    # Eval mode: no dropout
    builder.eval()
    out3 = builder(x, e, hyperedge_index)
    out4 = builder(x, e, hyperedge_index)

    # Outputs should be identical
    assert torch.allclose(out3[1], out4[1])


def test_sheaf_builder_diag_index_expansion():
    """Test that indices are correctly expanded for block diagonal."""
    builder = SheafBuilderDiag(
        hidden_channels=8, stalk_dim=2, prediction_type="MLP_var2"
    )

    num_nodes, num_edges = 3, 2
    d = 2
    x = torch.randn(num_nodes * d, 8)
    e = torch.randn(num_edges * d, 8)

    # Single pair (0, 0)
    hyperedge_index = torch.tensor([[0], [0]])

    h_sheaf_index, _h_sheaf_attributes = builder(x, e, hyperedge_index)

    # Should expand to 2 diagonal entries
    assert h_sheaf_index.shape == (2, 2)
    # Node indices: [0, 1] (0*d+0, 0*d+1)
    assert torch.all(h_sheaf_index[0] == torch.tensor([0, 1]))
    # Edge indices: [0, 1] (0*d+0, 0*d+1)
    assert torch.all(h_sheaf_index[1] == torch.tensor([0, 1]))


def test_sheaf_builder_diag_reset_parameters():
    """Test SheafBuilderDiag reset_parameters."""
    builder = SheafBuilderDiag(
        hidden_channels=16, stalk_dim=3, prediction_type="MLP_var2"
    )

    # Store initial parameters
    initial_weight = builder.sheaf_lin.lins[0].weight.clone()

    # Reset
    builder.reset_parameters()

    # Parameters should change
    assert not torch.allclose(builder.sheaf_lin.lins[0].weight, initial_weight)


def test_sheaf_builder_diag_gradient_flow():
    """Test gradient flow through SheafBuilderDiag."""
    builder = SheafBuilderDiag(
        hidden_channels=8, stalk_dim=2, prediction_type="MLP_var2"
    )

    num_nodes, num_edges = 5, 3
    d = 2
    x = torch.randn(num_nodes * d, 8, requires_grad=True)
    e = torch.randn(num_edges * d, 8)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 1]])

    _h_sheaf_index, h_sheaf_attributes = builder(x, e, hyperedge_index)

    # Compute loss and backprop
    loss = h_sheaf_attributes.sum()
    loss.backward()

    assert x.grad is not None
    assert not torch.isnan(x.grad).any()


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_sheaf_builder_diag_cuda():
    """Test SheafBuilderDiag on CUDA device."""
    device = torch.device("cuda")
    builder = SheafBuilderDiag(
        hidden_channels=16, stalk_dim=3, prediction_type="MLP_var2"
    ).to(device)

    num_nodes, num_edges = 10, 5
    d = 3
    x = torch.randn(num_nodes * d, 16, device=device)
    e = torch.randn(num_edges * d, 16, device=device)
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 0, 1, 1]], device=device)

    h_sheaf_index, h_sheaf_attributes = builder(x, e, hyperedge_index)

    assert h_sheaf_index.device.type == "cuda"
    assert h_sheaf_attributes.device.type == "cuda"


def test_sheaf_builder_cp_decomp():
    """Test CP decomposition prediction variant."""
    builder = SheafBuilderDiag(
        hidden_channels=16, stalk_dim=4, prediction_type="cp_decomp"
    )

    # Check that CP MLPs were created
    assert builder.cp_W is not None
    assert builder.cp_V is not None

    num_nodes, num_edges = 5, 2
    d = 4
    x = torch.randn(num_nodes * d, 16)
    e = torch.randn(num_edges * d, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 1]])

    h_sheaf_index, h_sheaf_attributes = builder(x, e, hyperedge_index)

    # Check output shapes
    expected_pairs = hyperedge_index.shape[1]
    assert h_sheaf_index.shape == (2, expected_pairs * d)
    assert h_sheaf_attributes.shape == (expected_pairs * d,)

    # Check values are in [0, 1] for sigmoid activation
    assert torch.all(h_sheaf_attributes >= 0)
    assert torch.all(h_sheaf_attributes <= 1)


def test_sheaf_builder_cp_decomp_gradient_flow():
    """Test gradient flow through CP decomposition."""
    builder = SheafBuilderDiag(
        hidden_channels=16, stalk_dim=3, prediction_type="cp_decomp"
    )

    num_nodes, num_edges = 4, 2
    d = 3
    x = torch.randn(num_nodes * d, 16, requires_grad=True)
    e = torch.randn(num_edges * d, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 1]])

    _, h_sheaf_attributes = builder(x, e, hyperedge_index)

    # Backpropagate
    loss = h_sheaf_attributes.sum()
    loss.backward()

    # Check gradients
    assert x.grad is not None
    assert not torch.all(x.grad == 0)


def test_sheaf_builder_cp_decomp_vs_var2():
    """Test that CP decomposition produces different results than var2."""
    torch.manual_seed(42)
    builder_cp = SheafBuilderDiag(
        hidden_channels=16, stalk_dim=3, prediction_type="cp_decomp"
    )
    torch.manual_seed(42)
    builder_var2 = SheafBuilderDiag(
        hidden_channels=16, stalk_dim=3, prediction_type="MLP_var2"
    )

    num_nodes, num_edges = 4, 2
    d = 3
    x = torch.randn(num_nodes * d, 16)
    e = torch.randn(num_edges * d, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 1]])

    _, attr_cp = builder_cp(x, e, hyperedge_index)
    _, attr_var2 = builder_var2(x, e, hyperedge_index)

    # Different prediction methods should produce different results
    assert not torch.allclose(attr_cp, attr_var2)
