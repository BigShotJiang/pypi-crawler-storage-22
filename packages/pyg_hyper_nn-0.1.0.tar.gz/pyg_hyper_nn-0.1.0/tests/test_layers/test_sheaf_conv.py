"""Tests for sheaf hypergraph convolution layers."""

import pytest
import torch

from pyg_hyper_nn.layers.sheaf_conv import (
    HyperDiffusionDiagSheafConv,
    normalisation_matrices,
)


def test_normalisation_matrices_degree_norm():
    """Test degree normalization."""
    x = torch.randn(10, 8)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
    alpha = torch.ones(6)
    num_nodes, num_edges, d = 5, 2, 1

    D, B = normalisation_matrices(
        x, hyperedge_index, alpha, num_nodes, num_edges, d, "degree_norm"
    )

    assert D.shape == (5,)
    assert B.shape == (2,)
    assert not torch.isnan(D).any()
    assert not torch.isnan(B).any()
    assert not torch.isinf(D).any()


def test_normalisation_matrices_sym_degree_norm():
    """Test symmetric degree normalization."""
    x = torch.randn(10, 8)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    alpha = torch.ones(3)
    num_nodes, num_edges, d = 3, 1, 1

    D, B = normalisation_matrices(
        x, hyperedge_index, alpha, num_nodes, num_edges, d, "sym_degree_norm"
    )

    assert D.shape == (3,)
    assert B.shape == (1,)


def test_normalisation_matrices_block_norm():
    """Test block normalization with sheaf values."""
    x = torch.randn(10, 8)
    # Indices should be within [0, num_nodes*d) and [0, num_edges*d)
    hyperedge_index = torch.tensor([[0, 1, 2, 0, 1, 2], [0, 0, 0, 1, 1, 1]])
    alpha = torch.rand(6)  # Non-uniform values
    num_nodes, num_edges, d = 3, 2, 1

    D, B = normalisation_matrices(
        x, hyperedge_index, alpha, num_nodes, num_edges, d, "block_norm"
    )

    assert D.shape == (3,)
    assert B.shape == (2,)


def test_normalisation_matrices_expanded_indices():
    """Test normalization with expanded stalk indices."""
    x = torch.randn(20, 8)
    # 2 pairs, expanded to d=3: 6 total indices
    hyperedge_index = torch.tensor(
        [[0, 1, 2, 3, 4, 5], [0, 1, 2, 0, 1, 2]]  # Nodes  # Edges
    )
    alpha = torch.ones(6)
    num_nodes, num_edges, d = 2, 1, 3

    D, B = normalisation_matrices(
        x, hyperedge_index, alpha, num_nodes, num_edges, d, "degree_norm"
    )

    assert D.shape == (6,)  # 2 nodes * 3 stalks
    assert B.shape == (3,)  # 1 edge * 3 stalks


def test_hyperdiffusion_diag_sheaf_conv_init():
    """Test HyperDiffusionDiagSheafConv initialization."""
    conv = HyperDiffusionDiagSheafConv(
        in_channels=16,
        out_channels=32,
        d=4,
        device="cpu",
        norm_type="degree_norm",
    )

    assert conv.in_channels == 16
    assert conv.out_channels == 32
    assert conv.d == 4
    assert conv.norm_type == "degree_norm"


def test_hyperdiffusion_diag_sheaf_conv_forward_basic():
    """Test HyperDiffusionDiagSheafConv forward pass."""
    conv = HyperDiffusionDiagSheafConv(
        in_channels=8, out_channels=8, d=2, device="cpu", norm_type="degree_norm"
    )

    num_nodes, num_edges, d = 5, 3, 2
    x = torch.randn(num_nodes * d, 8)  # 10 x 8

    # Create simple expanded indices (3 pairs)
    hyperedge_index = torch.tensor(
        [
            [0, 1, 2, 3, 4, 5],  # Node indices (expanded)
            [0, 1, 0, 1, 2, 3],  # Edge indices (expanded)
        ]
    )
    alpha = torch.ones(6)

    out = conv(x, hyperedge_index, alpha, num_nodes, num_edges)

    assert out.shape == (10, 8)
    assert not torch.isnan(out).any()


def test_hyperdiffusion_diag_sheaf_conv_with_left_proj():
    """Test HyperDiffusionDiagSheafConv with left projection."""
    conv = HyperDiffusionDiagSheafConv(
        in_channels=8,
        out_channels=8,
        d=3,
        device="cpu",
        norm_type="degree_norm",
        left_proj=True,
    )

    num_nodes, num_edges, d = 4, 2, 3
    x = torch.randn(num_nodes * d, 8)
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 1, 2, 3]])
    alpha = torch.ones(4)

    out = conv(x, hyperedge_index, alpha, num_nodes, num_edges)

    assert out.shape == (12, 8)


def test_hyperdiffusion_diag_sheaf_conv_with_residual():
    """Test HyperDiffusionDiagSheafConv with residual connection."""
    conv = HyperDiffusionDiagSheafConv(
        in_channels=8,
        out_channels=8,
        d=2,
        device="cpu",
        norm_type="degree_norm",
        residual=True,
    )

    num_nodes, num_edges, d = 5, 3, 2
    x = torch.randn(num_nodes * d, 8)
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 1, 0, 1]])
    alpha = torch.ones(4)

    out = conv(x, hyperedge_index, alpha, num_nodes, num_edges)

    assert out.shape == (10, 8)


def test_hyperdiffusion_diag_sheaf_conv_sym_norm():
    """Test HyperDiffusionDiagSheafConv with symmetric normalization."""
    conv = HyperDiffusionDiagSheafConv(
        in_channels=8,
        out_channels=8,
        d=2,
        device="cpu",
        norm_type="sym_degree_norm",
    )

    num_nodes, num_edges, d = 5, 3, 2
    x = torch.randn(num_nodes * d, 8)
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 1, 0, 1]])
    alpha = torch.ones(4)

    out = conv(x, hyperedge_index, alpha, num_nodes, num_edges)

    assert out.shape == (10, 8)


def test_hyperdiffusion_diag_sheaf_conv_block_norm():
    """Test HyperDiffusionDiagSheafConv with block normalization."""
    conv = HyperDiffusionDiagSheafConv(
        in_channels=8, out_channels=8, d=2, device="cpu", norm_type="block_norm"
    )

    num_nodes, num_edges, d = 5, 3, 2
    x = torch.randn(num_nodes * d, 8)
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 1, 0, 1]])
    alpha = torch.rand(4)  # Non-uniform sheaf values

    out = conv(x, hyperedge_index, alpha, num_nodes, num_edges)

    assert out.shape == (10, 8)


def test_hyperdiffusion_diag_sheaf_conv_reset_parameters():
    """Test HyperDiffusionDiagSheafConv reset_parameters."""
    conv = HyperDiffusionDiagSheafConv(in_channels=8, out_channels=8, d=2, device="cpu")

    # Store initial parameters
    initial_weight = conv.lin.lins[0].weight.clone()

    # Reset
    conv.reset_parameters()

    # Parameters should change
    assert not torch.allclose(conv.lin.lins[0].weight, initial_weight)
    # Cached matrices should be cleared
    assert conv.I_mask is None
    assert conv.Id is None


def test_hyperdiffusion_diag_sheaf_conv_gradient_flow():
    """Test gradient flow through HyperDiffusionDiagSheafConv."""
    conv = HyperDiffusionDiagSheafConv(in_channels=8, out_channels=8, d=2, device="cpu")

    num_nodes, num_edges, d = 5, 3, 2
    x = torch.randn(num_nodes * d, 8, requires_grad=True)
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 1, 0, 1]])
    alpha = torch.ones(4, requires_grad=True)

    out = conv(x, hyperedge_index, alpha, num_nodes, num_edges)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None
    assert not torch.isnan(x.grad).any()
    # Note: alpha.grad may be None due to sparse operations not propagating gradients


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_hyperdiffusion_diag_sheaf_conv_cuda():
    """Test HyperDiffusionDiagSheafConv on CUDA device."""
    device = torch.device("cuda")
    conv = HyperDiffusionDiagSheafConv(
        in_channels=8, out_channels=8, d=2, device=device
    ).to(device)

    num_nodes, num_edges, d = 5, 3, 2
    x = torch.randn(num_nodes * d, 8, device=device)
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 1, 0, 1]], device=device)
    alpha = torch.ones(4, device=device)

    out = conv(x, hyperedge_index, alpha, num_nodes, num_edges)

    assert out.device.type == "cuda"
    assert out.shape == (10, 8)


def test_hyperdiffusion_diag_sheaf_conv_caching():
    """Test that identity matrices are cached correctly."""
    conv = HyperDiffusionDiagSheafConv(in_channels=8, out_channels=8, d=2, device="cpu")

    num_nodes, num_edges, d = 5, 3, 2
    x = torch.randn(num_nodes * d, 8)
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 1, 0, 1]])
    alpha = torch.ones(4)

    # First forward: caches should be created
    assert conv.I_mask is None
    assert conv.Id is None

    conv(x, hyperedge_index, alpha, num_nodes, num_edges)

    assert conv.I_mask is not None
    assert conv.Id is not None

    # Store references
    I_mask_ref = conv.I_mask
    Id_ref = conv.Id

    # Second forward: should reuse caches
    conv(x, hyperedge_index, alpha, num_nodes, num_edges)

    # Same objects (not recreated)
    assert conv.I_mask is I_mask_ref
    assert conv.Id is Id_ref
