"""Tests for sheaf utility functions."""

import pytest
import torch

from pyg_hyper_nn.layers.sheaf_utils import (
    batched_sym_matrix_pow,
    generate_indices_general,
    sparse_diagonal,
)


def test_sparse_diagonal_basic():
    """Test sparse_diagonal creates correct diagonal matrix."""
    diag = torch.tensor([1.0, 2.0, 3.0])
    sparse_mat = sparse_diagonal(diag, shape=(3, 3))

    assert sparse_mat.shape == (3, 3)
    assert sparse_mat.is_sparse

    # Convert to dense and check diagonal
    dense = sparse_mat.to_dense()
    expected = torch.diag(diag)
    assert torch.allclose(dense, expected)


def test_sparse_diagonal_zeros():
    """Test sparse_diagonal with zero values."""
    diag = torch.zeros(5)
    sparse_mat = sparse_diagonal(diag, shape=(5, 5))

    dense = sparse_mat.to_dense()
    assert torch.allclose(dense, torch.zeros(5, 5))


def test_sparse_diagonal_cuda():
    """Test sparse_diagonal on CUDA device."""
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")

    device = torch.device("cuda")
    diag = torch.tensor([1.0, 2.0, 3.0], device=device)
    sparse_mat = sparse_diagonal(diag, shape=(3, 3))

    assert sparse_mat.device.type == "cuda"
    dense = sparse_mat.to_dense()
    expected = torch.diag(diag)
    assert torch.allclose(dense, expected)


def test_sparse_diagonal_shape_mismatch():
    """Test sparse_diagonal raises error for non-square shape."""
    diag = torch.tensor([1.0, 2.0, 3.0])

    with pytest.raises(AssertionError):
        sparse_diagonal(diag, shape=(3, 4))


def test_generate_indices_general_basic():
    """Test generate_indices_general for block indices."""
    # Simple case: 2 edges, block dimension 2
    indexes = torch.tensor([[0, 1], [0, 1]])  # 2 edges: (0,0) and (1,1)
    d = 2

    large_indexes = generate_indices_general(indexes, d)

    # Expected: each scalar index expanded to 2x2 block
    # (0,0) -> [(0,0), (0,1), (1,0), (1,1)]
    # (1,1) -> [(2,2), (2,3), (3,2), (3,3)]
    assert large_indexes.shape == (2, 8)  # 2 edges * 2*2 block = 8 entries

    # Check first block (0,0)
    # Node indices repeat: 0,0,1,1 (for each edge: 0*d+0, 0*d+0, 0*d+1, 0*d+1)
    assert torch.all(large_indexes[0, :4] == torch.tensor([0, 0, 1, 1]))
    # Edge indices: 0,1,0,1 (for each node: 0*d+0, 0*d+1, 0*d+0, 0*d+1)
    assert torch.all(large_indexes[1, :4] == torch.tensor([0, 1, 0, 1]))

    # Check second block (1,1)
    assert torch.all(large_indexes[0, 4:] == torch.tensor([2, 2, 3, 3]))
    assert torch.all(large_indexes[1, 4:] == torch.tensor([2, 3, 2, 3]))


def test_generate_indices_general_single_edge():
    """Test generate_indices_general with single edge."""
    indexes = torch.tensor([[0], [1]])  # Single edge (0,1)
    d = 3

    large_indexes = generate_indices_general(indexes, d)

    assert large_indexes.shape == (2, 9)  # 1 edge * 3*3 block = 9 entries

    # Check node indices: 0,0,0, 1,1,1, 2,2,2
    expected_nodes = torch.tensor([0, 0, 0, 1, 1, 1, 2, 2, 2])
    assert torch.all(large_indexes[0] == expected_nodes)

    # Check edge indices: 3,4,5, 3,4,5, 3,4,5
    expected_edges = torch.tensor([3, 4, 5, 3, 4, 5, 3, 4, 5])
    assert torch.all(large_indexes[1] == expected_edges)


def test_generate_indices_general_dimension_one():
    """Test generate_indices_general with d=1 (no expansion)."""
    indexes = torch.tensor([[0, 1, 2], [0, 1, 2]])
    d = 1

    large_indexes = generate_indices_general(indexes, d)

    # With d=1, should be same as input
    assert large_indexes.shape == (2, 3)
    assert torch.all(large_indexes == indexes)


def test_batched_sym_matrix_pow_identity():
    """Test batched_sym_matrix_pow with identity matrices."""
    # Identity matrix to any power is identity
    batch_size = 3
    n = 4
    matrices = torch.eye(n).unsqueeze(0).repeat(batch_size, 1, 1)

    result = batched_sym_matrix_pow(matrices, p=2.0)

    assert result.shape == (batch_size, n, n)
    for i in range(batch_size):
        assert torch.allclose(result[i], torch.eye(n), atol=1e-5)


def test_batched_sym_matrix_pow_diagonal():
    """Test batched_sym_matrix_pow with diagonal matrices."""
    # Diagonal matrix [2,3,4] to power 2 should be [4,9,16]
    diag = torch.tensor([2.0, 3.0, 4.0])
    matrix = torch.diag(diag).unsqueeze(0)

    result = batched_sym_matrix_pow(matrix, p=2.0)

    expected = torch.diag(diag**2)
    assert torch.allclose(result[0], expected, atol=1e-5)


def test_batched_sym_matrix_pow_sqrt():
    """Test batched_sym_matrix_pow with square root."""
    # Create positive definite matrix
    A = torch.tensor([[4.0, 0.0], [0.0, 9.0]]).unsqueeze(0)

    result = batched_sym_matrix_pow(A, p=0.5)

    # Square root of diagonal [4,9] should be [2,3]
    expected = torch.tensor([[2.0, 0.0], [0.0, 3.0]])
    assert torch.allclose(result[0], expected, atol=1e-5)


def test_batched_sym_matrix_pow_inverse():
    """Test batched_sym_matrix_pow with inverse (p=-1)."""
    # Create invertible matrix
    A = torch.tensor([[2.0, 0.0], [0.0, 4.0]]).unsqueeze(0)

    result = batched_sym_matrix_pow(A, p=-1.0)

    expected = torch.tensor([[0.5, 0.0], [0.0, 0.25]])
    assert torch.allclose(result[0], expected, atol=1e-5)


def test_batched_sym_matrix_pow_multiple_matrices():
    """Test batched_sym_matrix_pow with multiple different matrices."""
    # Create batch of 3 different diagonal matrices
    matrices = torch.stack(
        [
            torch.diag(torch.tensor([1.0, 2.0])),
            torch.diag(torch.tensor([3.0, 4.0])),
            torch.diag(torch.tensor([5.0, 6.0])),
        ]
    )

    result = batched_sym_matrix_pow(matrices, p=2.0)

    assert result.shape == (3, 2, 2)

    # Check each result
    assert torch.allclose(result[0], torch.diag(torch.tensor([1.0, 4.0])), atol=1e-5)
    assert torch.allclose(result[1], torch.diag(torch.tensor([9.0, 16.0])), atol=1e-5)
    assert torch.allclose(result[2], torch.diag(torch.tensor([25.0, 36.0])), atol=1e-5)


def test_batched_sym_matrix_pow_zero_power():
    """Test batched_sym_matrix_pow with p=0 (should give identity)."""
    A = torch.tensor([[2.0, 0.0], [0.0, 4.0]]).unsqueeze(0)

    result = batched_sym_matrix_pow(A, p=0.0)

    expected = torch.eye(2)
    assert torch.allclose(result[0], expected, atol=1e-5)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_batched_sym_matrix_pow_cuda():
    """Test batched_sym_matrix_pow on CUDA device."""
    device = torch.device("cuda")
    matrices = torch.eye(3).unsqueeze(0).to(device)

    result = batched_sym_matrix_pow(matrices, p=2.0)

    assert result.device.type == "cuda"
    assert torch.allclose(result[0], torch.eye(3, device=device), atol=1e-5)
