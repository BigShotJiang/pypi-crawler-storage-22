"""Tests for sparse linear layer."""

import torch

from pyg_hyper_nn.layers.sparse_linear import SparseLinear


def test_sparse_linear_forward():
    """Test SparseLinear forward pass."""
    in_features, out_features = 20, 16
    layer = SparseLinear(in_features, out_features)

    # Create sparse input
    indices = torch.tensor([[0, 1, 2, 3], [0, 5, 10, 15]])
    values = torch.tensor([1.0, 2.0, 3.0, 4.0])
    sparse_input = torch.sparse_coo_tensor(indices, values, (4, in_features))

    output = layer(sparse_input)

    assert output.shape == (4, out_features)
    assert not torch.isnan(output).any()


def test_sparse_linear_without_bias():
    """Test SparseLinear without bias."""
    in_features, out_features = 20, 16
    layer = SparseLinear(in_features, out_features, bias=False)

    assert layer.bias is None

    indices = torch.tensor([[0, 1], [0, 5]])
    values = torch.tensor([1.0, 2.0])
    sparse_input = torch.sparse_coo_tensor(indices, values, (2, in_features))

    output = layer(sparse_input)

    assert output.shape == (2, out_features)


def test_sparse_linear_reset_parameters():
    """Test parameter reset."""
    layer = SparseLinear(20, 16)

    weight_before = layer.weight.clone()
    layer.reset_parameters()
    weight_after = layer.weight

    # Weights should change after reset
    assert not torch.allclose(weight_before, weight_after)


def test_sparse_linear_gradient():
    """Test gradient flow through SparseLinear."""
    layer = SparseLinear(20, 16)

    indices = torch.tensor([[0, 1, 2], [0, 5, 10]])
    values = torch.tensor([1.0, 2.0, 3.0])
    sparse_input = torch.sparse_coo_tensor(indices, values, (3, 20))

    output = layer(sparse_input)
    loss = output.sum()
    loss.backward()

    assert layer.weight.grad is not None
    if layer.bias is not None:
        assert layer.bias.grad is not None


def test_sparse_linear_repr():
    """Test string representation."""
    layer = SparseLinear(20, 16, bias=True)
    repr_str = repr(layer)

    assert "20" in repr_str
    assert "16" in repr_str
    assert "bias=True" in repr_str
