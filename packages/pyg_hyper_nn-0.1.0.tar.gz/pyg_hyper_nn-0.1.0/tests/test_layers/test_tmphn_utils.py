"""Tests for TMPHN utility functions."""

import torch

from pyg_hyper_nn.layers.tmphn_utils import build_neighbor_dict


def test_build_neighbor_dict_basic():
    """Test basic neighbor dictionary construction."""
    # Edge 0: {0, 1, 2}, Edge 1: {1, 3}
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 3], [0, 0, 0, 1, 1]])

    neig_dict = build_neighbor_dict(hyperedge_index)

    # Node 0 appears in edge 0
    assert len(neig_dict[0]) == 1
    assert set(neig_dict[0][0]) == {0, 1, 2}

    # Node 1 appears in edges 0 and 1
    assert len(neig_dict[1]) == 2
    assert set(neig_dict[1][0]) == {0, 1, 2}
    assert set(neig_dict[1][1]) == {1, 3}

    # Node 2 appears in edge 0
    assert len(neig_dict[2]) == 1
    assert set(neig_dict[2][0]) == {0, 1, 2}

    # Node 3 appears in edge 1
    assert len(neig_dict[3]) == 1
    assert set(neig_dict[3][0]) == {1, 3}


def test_build_neighbor_dict_single_node_edges():
    """Test with single-node hyperedges (self-loops)."""
    # Edge 0: {0}, Edge 1: {1}, Edge 2: {2}
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 1, 2]])

    neig_dict = build_neighbor_dict(hyperedge_index)

    assert len(neig_dict[0]) == 1
    assert neig_dict[0][0] == [0]

    assert len(neig_dict[1]) == 1
    assert neig_dict[1][0] == [1]

    assert len(neig_dict[2]) == 1
    assert neig_dict[2][0] == [2]


def test_build_neighbor_dict_overlapping_edges():
    """Test with nodes appearing in multiple overlapping edges."""
    # Edge 0: {0, 1}, Edge 1: {1, 2}, Edge 2: {0, 2}
    hyperedge_index = torch.tensor([[0, 1, 1, 2, 0, 2], [0, 0, 1, 1, 2, 2]])

    neig_dict = build_neighbor_dict(hyperedge_index)

    # Node 0 appears in edges 0 and 2
    assert len(neig_dict[0]) == 2

    # Node 1 appears in edges 0 and 1
    assert len(neig_dict[1]) == 2

    # Node 2 appears in edges 1 and 2
    assert len(neig_dict[2]) == 2


def test_build_neighbor_dict_large_edge():
    """Test with large hyperedge."""
    # Edge 0: {0, 1, 2, 3, 4}
    hyperedge_index = torch.tensor([[0, 1, 2, 3, 4], [0, 0, 0, 0, 0]])

    neig_dict = build_neighbor_dict(hyperedge_index)

    # All nodes should have the same single edge
    for node_id in range(5):
        assert len(neig_dict[node_id]) == 1
        assert set(neig_dict[node_id][0]) == {0, 1, 2, 3, 4}


def test_build_neighbor_dict_empty_edges():
    """Test with empty hypergraph (no edges)."""
    # Create hypergraph with 3 nodes but no edges
    hyperedge_index = torch.tensor([[0], [0]])  # Minimal valid input

    neig_dict = build_neighbor_dict(hyperedge_index)

    # Node 0 should have one edge containing itself
    assert len(neig_dict[0]) == 1
    assert neig_dict[0][0] == [0]


def test_build_neighbor_dict_varying_cardinality():
    """Test with edges of varying cardinality."""
    # Edge 0: {0, 1} (cardinality 2)
    # Edge 1: {1, 2, 3} (cardinality 3)
    # Edge 2: {3, 4, 5, 6} (cardinality 4)
    hyperedge_index = torch.tensor(
        [[0, 1, 1, 2, 3, 3, 4, 5, 6], [0, 0, 1, 1, 1, 2, 2, 2, 2]]
    )

    neig_dict = build_neighbor_dict(hyperedge_index)

    # Node 0: in edge 0 only
    assert len(neig_dict[0]) == 1
    assert len(neig_dict[0][0]) == 2

    # Node 1: in edges 0 and 1
    assert len(neig_dict[1]) == 2
    assert len(neig_dict[1][0]) == 2
    assert len(neig_dict[1][1]) == 3

    # Node 3: in edges 1 and 2
    assert len(neig_dict[3]) == 2
    assert len(neig_dict[3][0]) == 3
    assert len(neig_dict[3][1]) == 4
