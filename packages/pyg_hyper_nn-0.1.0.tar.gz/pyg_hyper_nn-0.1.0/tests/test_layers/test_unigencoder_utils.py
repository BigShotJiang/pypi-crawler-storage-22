"""Tests for PlainUnigencoder utility functions."""

import torch

from pyg_hyper_nn.layers.unigencoder_utils import (
    build_edge_dict,
    compute_pooling_matrices,
    count_node_edges,
)


def test_build_edge_dict_basic():
    """Test basic edge dictionary construction."""
    # Simple hypergraph: edge 0 has nodes [0,1], edge 1 has nodes [2,3]
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 0, 1, 1]])

    edge_dict = build_edge_dict(hyperedge_index)

    # Check edge contents
    assert 0 in edge_dict
    assert 1 in edge_dict
    assert set(edge_dict[0]) == {0, 1}
    assert set(edge_dict[1]) == {2, 3}


def test_build_edge_dict_with_isolated_nodes():
    """Test that isolated nodes get self-loop edges."""
    # Hypergraph with nodes 0-4, but only nodes 0,1,2 are in edge 0
    # Nodes 3,4 don't appear in hyperedge_index, so num_nodes=3 (V.max()+1)
    # Since edge 0 has 3 nodes, none have self-loops yet
    # So self-loops will be added for nodes 0, 1, 2
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    edge_dict = build_edge_dict(hyperedge_index)

    # Original edge
    assert 0 in edge_dict
    assert set(edge_dict[0]) == {0, 1, 2}

    # Self-loops for all nodes since none have self-loops yet
    assert 1 in edge_dict  # Self-loop for node 0
    assert 2 in edge_dict  # Self-loop for node 1
    assert 3 in edge_dict  # Self-loop for node 2
    assert edge_dict[1] == [0]
    assert edge_dict[2] == [1]
    assert edge_dict[3] == [2]


def test_build_edge_dict_with_existing_self_loops():
    """Test when some nodes already have self-loop edges."""
    # Edge 0 has nodes [0, 1], edge 1 has node [0] (self-loop)
    # num_nodes = 2 (V.max()+1 = 1+1)
    # Node 0 already has self-loop (edge 1), node 1 needs one
    hyperedge_index = torch.tensor([[0, 1, 0], [0, 0, 1]])

    edge_dict = build_edge_dict(hyperedge_index)

    # Original edges
    assert 0 in edge_dict
    assert 1 in edge_dict
    assert set(edge_dict[0]) == {0, 1}
    assert edge_dict[1] == [0]  # Self-loop

    # Node 1 should get self-loop (edge 2)
    assert 2 in edge_dict
    assert edge_dict[2] == [1]


def test_build_edge_dict_single_edge():
    """Test with single hyperedge."""
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    edge_dict = build_edge_dict(hyperedge_index)

    # Edge 0 has 3 nodes, plus self-loops for all 3 nodes = 4 edges total
    assert len(edge_dict) == 4
    assert set(edge_dict[0]) == {0, 1, 2}
    assert edge_dict[1] == [0]
    assert edge_dict[2] == [1]
    assert edge_dict[3] == [2]


def test_build_edge_dict_all_self_loops():
    """Test when all nodes have self-loops."""
    # Each node has its own edge
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 1, 2]])

    edge_dict = build_edge_dict(hyperedge_index)

    # Should have exactly 3 edges (one per node)
    assert len(edge_dict) == 3
    assert edge_dict[0] == [0]
    assert edge_dict[1] == [1]
    assert edge_dict[2] == [2]


def test_build_edge_dict_overlapping_edges():
    """Test with node appearing in multiple edges."""
    # Node 1 appears in both edges
    hyperedge_index = torch.tensor([[0, 1, 1, 2], [0, 0, 1, 1]])

    edge_dict = build_edge_dict(hyperedge_index)

    assert 0 in edge_dict
    assert 1 in edge_dict
    assert set(edge_dict[0]) == {0, 1}
    assert set(edge_dict[1]) == {1, 2}


def test_count_node_edges_basic():
    """Test basic node edge counting."""
    edge_dict = {0: [0, 1], 1: [1, 2], 2: [2, 3]}

    node_counts = count_node_edges(edge_dict)

    # Node 0: appears in 1 edge (edge 0) -> count = 0
    # Node 1: appears in 2 edges (edges 0,1) -> count = 1
    # Node 2: appears in 2 edges (edges 1,2) -> count = 1
    # Node 3: appears in 1 edge (edge 2) -> count = 0
    assert node_counts[0] == 0
    assert node_counts[1] == 1
    assert node_counts[2] == 1
    assert node_counts[3] == 0


def test_count_node_edges_isolated():
    """Test counting with isolated nodes (self-loops)."""
    edge_dict = {0: [0, 1], 1: [2]}  # Node 2 has self-loop

    node_counts = count_node_edges(edge_dict)

    assert node_counts[0] == 0  # Appears in 1 edge
    assert node_counts[1] == 0  # Appears in 1 edge
    assert node_counts[2] == 0  # Appears in 1 edge (self-loop)


def test_count_node_edges_high_degree():
    """Test counting for high-degree nodes."""
    # Node 0 appears in 4 edges
    edge_dict = {0: [0, 1], 1: [0, 2], 2: [0, 3], 3: [0, 4]}

    node_counts = count_node_edges(edge_dict)

    assert node_counts[0] == 3  # Appears in 4 edges -> count = 3
    assert node_counts[1] == 0  # Appears in 1 edge
    assert node_counts[2] == 0
    assert node_counts[3] == 0
    assert node_counts[4] == 0


def test_count_node_edges_empty():
    """Test with empty edge dict."""
    edge_dict = {}

    node_counts = count_node_edges(edge_dict)

    assert len(node_counts) == 0


def test_build_edge_dict_integration():
    """Integration test: build edge dict and count node edges."""
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 3], [0, 0, 0, 1, 1]])

    edge_dict = build_edge_dict(hyperedge_index)
    node_counts = count_node_edges(edge_dict)

    # Edge 0: [0, 1, 2], Edge 1: [1, 3]
    # Self-loops added: Edge 2: [0], Edge 3: [1], Edge 4: [2], Edge 5: [3]
    # Node 0: 2 edges (edge 0, edge 2) -> count = 1
    # Node 1: 3 edges (edge 0, edge 1, edge 3) -> count = 2
    # Node 2: 2 edges (edge 0, edge 4) -> count = 1
    # Node 3: 2 edges (edge 1, edge 5) -> count = 1
    assert node_counts[0] == 1
    assert node_counts[1] == 2
    assert node_counts[2] == 1
    assert node_counts[3] == 1


def test_compute_pooling_matrices_basic():
    """Test basic pooling matrix computation with threshold >= -1.0."""
    # Create simple hypergraph
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 0, 1, 1]])
    # Create features with high similarity for nodes in same edges
    x = torch.randn(4, 16)

    Pv, PvT = compute_pooling_matrices(x, hyperedge_index, threshold=0.0, norm_type=0)

    # Check shapes
    assert Pv.shape[1] == 4  # num_nodes
    assert PvT.shape[0] == 4  # num_nodes
    assert Pv.shape[0] == PvT.shape[1]  # num_groups must match

    # Check that matrices are sparse
    assert Pv.is_sparse
    assert PvT.is_sparse


def test_compute_pooling_matrices_high_similarity():
    """Test that high similarity groups nodes together."""
    # Create hypergraph with one edge containing 3 nodes
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # Create features with very high similarity (all same direction)
    x = torch.ones(3, 16)

    Pv, _ = compute_pooling_matrices(x, hyperedge_index, threshold=0.9, norm_type=0)

    # With high threshold and high similarity, should group edge together
    # Plus self-loops for all 3 nodes = 4 groups total
    assert Pv.shape[0] == 4  # 1 grouped edge + 3 self-loops


def test_compute_pooling_matrices_low_similarity():
    """Test that low similarity splits nodes apart."""
    # Create hypergraph with one edge
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # Create features with orthogonal directions (low similarity)
    x = torch.eye(3, 16)

    Pv, _ = compute_pooling_matrices(x, hyperedge_index, threshold=0.9, norm_type=0)

    # With high threshold and low similarity, edge won't be grouped
    # Only self-loops remain = 3 groups
    assert Pv.shape[0] == 3


def test_compute_pooling_matrices_threshold_ranges():
    """Test different threshold ranges produce different behaviors."""
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    x = torch.randn(3, 16)

    # threshold >= -1.0: cosine similarity grouping
    Pv1, PvT1 = compute_pooling_matrices(x, hyperedge_index, threshold=0.5, norm_type=0)

    # -2.0 <= threshold < -1.0: each node separate
    Pv2, PvT2 = compute_pooling_matrices(
        x, hyperedge_index, threshold=-1.5, norm_type=0
    )

    # threshold < -2.0: similar to middle with init values
    Pv3, PvT3 = compute_pooling_matrices(
        x, hyperedge_index, threshold=-3.0, norm_type=0
    )

    # All should produce valid matrices
    assert Pv1.is_sparse and PvT1.is_sparse
    assert Pv2.is_sparse and PvT2.is_sparse
    assert Pv3.is_sparse and PvT3.is_sparse


def test_compute_pooling_matrices_normalization_types():
    """Test all normalization types."""
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    x = torch.randn(3, 16)

    for norm_type in [0, 1, 2, 3, 99]:
        Pv, PvT = compute_pooling_matrices(
            x, hyperedge_index, threshold=0.0, norm_type=norm_type
        )

        assert Pv.is_sparse
        assert PvT.is_sparse
        assert not torch.isnan(Pv.coalesce().values()).any()
        assert not torch.isnan(PvT.coalesce().values()).any()


def test_compute_pooling_matrices_norm_type_0():
    """Test norm_type=0: row-normalize both Pv and PvT."""
    hyperedge_index = torch.tensor([[0, 1], [0, 0]])
    x = torch.randn(2, 8)

    Pv, PvT = compute_pooling_matrices(x, hyperedge_index, threshold=-1.5, norm_type=0)

    # Convert to dense for checking normalization
    Pv_dense = Pv.to_dense()
    PvT_dense = PvT.to_dense()

    # Each row of Pv should sum to 1
    row_sums_pv = Pv_dense.sum(dim=1)
    assert torch.allclose(row_sums_pv, torch.ones_like(row_sums_pv), atol=1e-6)

    # Each row of PvT should sum to 1
    row_sums_pvt = PvT_dense.sum(dim=1)
    assert torch.allclose(row_sums_pvt, torch.ones_like(row_sums_pvt), atol=1e-6)


def test_compute_pooling_matrices_init_values():
    """Test init_val and init_type parameters."""
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    x = torch.randn(3, 16)

    # Test with different init values
    Pv1, PvT1 = compute_pooling_matrices(
        x, hyperedge_index, threshold=-3.0, init_val=1.0, init_type=0
    )

    Pv2, PvT2 = compute_pooling_matrices(
        x, hyperedge_index, threshold=-3.0, init_val=2.0, init_type=1
    )

    # Both should produce valid sparse matrices
    assert Pv1.is_sparse and PvT1.is_sparse
    assert Pv2.is_sparse and PvT2.is_sparse


def test_compute_pooling_matrices_single_node():
    """Test with single node."""
    hyperedge_index = torch.tensor([[0], [0]])
    x = torch.randn(1, 8)

    Pv, PvT = compute_pooling_matrices(x, hyperedge_index, threshold=0.0, norm_type=0)

    assert Pv.shape == (1, 1)
    assert PvT.shape == (1, 1)


def test_compute_pooling_matrices_empty_threshold():
    """Test that empty edges (filtered by threshold) are handled."""
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 0, 1, 1]])
    # Create orthogonal features (very low similarity)
    x = torch.zeros(4, 16)
    x[0, 0] = 1.0
    x[1, 1] = 1.0
    x[2, 2] = 1.0
    x[3, 3] = 1.0

    Pv, _ = compute_pooling_matrices(x, hyperedge_index, threshold=0.99, norm_type=0)

    # High threshold with orthogonal features means edges won't be grouped
    # Only self-loops remain
    assert Pv.shape[0] == 4  # 4 self-loops
