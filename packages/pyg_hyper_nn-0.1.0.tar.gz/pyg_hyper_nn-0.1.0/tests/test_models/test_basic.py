"""Basic tests for hypergraph models."""

import torch

from pyg_hyper_nn.models import (
    CEGAT,
    CEGCN,
    HCHA,
    HGNN,
    MLP,
    TFHNN,
    AllSet,
    EquivSetGNN,
    UniGCNII,
    UniGNN,
)


def test_mlp_forward():
    """Test MLP forward pass."""
    model = MLP(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16)

    out = model(x)

    assert out.shape == (100, 7), f"Expected shape (100, 7), got {out.shape}"


def test_mlp_single_layer():
    """Test MLP with single layer."""
    model = MLP(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=1,
    )
    x = torch.randn(100, 16)

    out = model(x)

    assert out.shape == (100, 7)


def test_hgnn_forward():
    """Test HGNN forward pass."""
    model = HGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3, 4, 5], [0, 0, 0, 1, 1, 1, 2, 2]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_hgnn_single_layer():
    """Test HGNN with single layer."""
    model = HGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=1,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_hgnn_gradient_flow():
    """Test gradient flow through HGNN."""
    model = HGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16, requires_grad=True)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None, "Gradients should flow to input"


def test_hcha_forward():
    """Test HCHA forward pass with asymmetric normalization."""
    model = HCHA(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3, 4, 5], [0, 0, 0, 1, 1, 1, 2, 2]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_hcha_single_layer():
    """Test HCHA with single layer."""
    model = HCHA(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=1,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_hcha_gradient_flow():
    """Test gradient flow through HCHA."""
    model = HCHA(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16, requires_grad=True)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None, "Gradients should flow to input"


def test_hcha_vs_hgnn_difference():
    """Test that HCHA (symdegnorm=False) produces different outputs than HGNN (symdegnorm=True)."""
    torch.manual_seed(42)
    hgnn = HGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        dropout=0.0,
    )

    torch.manual_seed(42)
    hcha = HCHA(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        dropout=0.0,
    )

    torch.manual_seed(123)
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    hgnn.eval()
    hcha.eval()

    out_hgnn = hgnn(x, edge_index)
    out_hcha = hcha(x, edge_index)

    # Outputs should be different due to different normalization
    assert not torch.allclose(out_hgnn, out_hcha), (
        "HCHA and HGNN should produce different outputs"
    )


def test_unignn_forward():
    """Test UniGNN forward pass."""
    model = UniGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_unignn_with_heads():
    """Test UniGNN with multiple heads."""
    model = UniGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=3,
        heads=4,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_unignn_gradient_flow():
    """Test gradient flow through UniGNN."""
    model = UniGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16, requires_grad=True)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None, "Gradients should flow to input"


def test_unigcnii_forward():
    """Test UniGCNII forward pass."""
    model = UniGCNII(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        alpha=0.1,
        lamda=0.5,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_unigcnii_deep_layers():
    """Test UniGCNII with many layers (testing GCNII benefits)."""
    model = UniGCNII(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=8,  # Deep network
        alpha=0.2,
        lamda=1.0,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_unigcnii_gradient_flow():
    """Test gradient flow through UniGCNII."""
    model = UniGCNII(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16, requires_grad=True)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None, "Gradients should flow to input"


def test_allset_forward():
    """Test AllSet forward pass with attention."""
    model = AllSet(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        use_attention=True,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_allset_without_attention():
    """Test AllSet with MLP instead of PMA."""
    model = AllSet(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        use_attention=False,
        mlp_num_layers=2,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_allset_multi_head():
    """Test AllSet with multiple attention heads."""
    model = AllSet(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        use_attention=True,
        heads=4,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_allset_single_layer():
    """Test AllSet with single layer."""
    model = AllSet(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=1,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_allset_gradient_flow():
    """Test gradient flow through AllSet."""
    model = AllSet(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16, requires_grad=True)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None, "Gradients should flow to input"


def test_equivsetgnn_forward():
    """Test EquivSetGNN forward pass."""
    model = EquivSetGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_equivsetgnn_single_layer():
    """Test EquivSetGNN with single layer."""
    model = EquivSetGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=1,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_equivsetgnn_different_activation():
    """Test EquivSetGNN with different activation functions."""
    for activation in ["relu", "prelu", "none"]:
        model = EquivSetGNN(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=2,
            activation=activation,
        )
        x = torch.randn(100, 16)
        edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        out = model(x, edge_index)

        assert out.shape == (100, 7)


def test_equivsetgnn_gradient_flow():
    """Test gradient flow through EquivSetGNN."""
    model = EquivSetGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16, requires_grad=True)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None, "Gradients should flow to input"


def test_tfhnn_forward():
    """Test TFHNN forward pass."""
    model = TFHNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_tfhnn_single_layer():
    """Test TFHNN with single propagation step."""
    model = TFHNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=1,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_tfhnn_different_alpha():
    """Test TFHNN with different restart probabilities."""
    for alpha in [0.0, 0.15, 0.5]:
        model = TFHNN(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=2,
            alpha=alpha,
        )
        x = torch.randn(100, 16)
        edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        out = model(x, edge_index)

        assert out.shape == (100, 7)


def test_tfhnn_gradient_flow():
    """Test gradient flow through TFHNN."""
    model = TFHNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16, requires_grad=True)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None, "Gradients should flow to input"


def test_cegcn_forward():
    """Test CEGCN forward pass."""
    model = CEGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_cegcn_single_layer():
    """Test CEGCN with single layer."""
    model = CEGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=1,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_cegcn_without_bn():
    """Test CEGCN without batch normalization."""
    model = CEGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        use_bn=False,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_cegcn_gradient_flow():
    """Test gradient flow through CEGCN."""
    model = CEGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16, requires_grad=True)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None, "Gradients should flow to input"


def test_cegat_forward():
    """Test CEGAT forward pass."""
    model = CEGAT(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        heads=4,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_cegat_single_layer():
    """Test CEGAT with single layer."""
    model = CEGAT(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=1,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_cegat_no_concat():
    """Test CEGAT without concatenating attention heads."""
    model = CEGAT(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        heads=4,
        concat=False,
    )
    x = torch.randn(100, 16)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)

    assert out.shape == (100, 7)


def test_cegat_gradient_flow():
    """Test gradient flow through CEGAT."""
    model = CEGAT(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )
    x = torch.randn(100, 16, requires_grad=True)
    edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, edge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None, "Gradients should flow to input"


def test_model_reset_parameters():
    """Test reset_parameters for all models."""
    models = [
        MLP(16, 32, 7, 2),
        HGNN(16, 32, 7, 2),
        UniGNN(16, 32, 7, 2),
        UniGCNII(16, 32, 7, 2),
        AllSet(16, 32, 7, 2),
        EquivSetGNN(16, 32, 7, 2),
        TFHNN(16, 32, 7, 2),
        CEGCN(16, 32, 7, 2),
        CEGAT(16, 32, 7, 2),
    ]

    for model in models:
        # Just ensure reset_parameters runs without error
        model.reset_parameters()

        # Verify model can still do forward pass
        x = torch.randn(10, 16)
        edge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

        out = model(x) if isinstance(model, MLP) else model(x, edge_index)

        assert out.shape[0] == 10, (
            f"Forward pass failed after reset in {model.__class__.__name__}"
        )


def test_model_repr():
    """Test string representation of models."""
    models = [
        MLP(16, 32, 7, 2),
        HGNN(16, 32, 7, 2),
        UniGNN(16, 32, 7, 2),
        UniGCNII(16, 32, 7, 2),
        AllSet(16, 32, 7, 2),
        EquivSetGNN(16, 32, 7, 2),
        TFHNN(16, 32, 7, 2),
        CEGCN(16, 32, 7, 2),
        CEGAT(16, 32, 7, 2),
    ]

    for model in models:
        repr_str = repr(model)
        assert model.__class__.__name__ in repr_str
        assert "16" in repr_str
        assert "7" in repr_str
