"""Tests for HJRL model."""

import pytest
import torch

from pyg_hyper_nn.models.hjrl import HJRL, HJRLConv


def test_hjrl_conv_forward():
    """Test HJRLConv forward pass."""
    conv = HJRLConv(16, 32)

    x = torch.randn(10, 16)
    # Create simple sparse adjacency
    indices = torch.tensor([[0, 1, 2], [1, 2, 0]])
    values = torch.ones(3)
    adj = torch.sparse_coo_tensor(indices, values, (10, 10))

    out = conv(x, adj)

    assert out.shape == (10, 32)


def test_hjrl_conv_activations():
    """Test HJRLConv with different activations."""
    x = torch.randn(10, 16)
    indices = torch.tensor([[0, 1, 2], [1, 2, 0]])
    values = torch.ones(3)
    adj = torch.sparse_coo_tensor(indices, values, (10, 10))

    for activation in ["relu", "elu", "leaky_relu", None]:
        conv = HJRLConv(16, 32, activation=activation)
        out = conv(x, adj)
        assert out.shape == (10, 32)


def test_hjrl_forward():
    """Test HJRL forward pass."""
    model = HJRL(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)


def test_hjrl_single_layer():
    """Test HJRL with single layer."""
    model = HJRL(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=1,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)


def test_hjrl_different_activations():
    """Test HJRL with different activation functions."""
    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    for activation in ["relu", "elu", "leaky_relu"]:
        model = HJRL(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=2,
            activation=activation,
        )

        out = model(x, hyperedge_index)
        assert out.shape == (50, 7)


def test_hjrl_gradient_flow():
    """Test gradient flow through HJRL."""
    model = HJRL(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    x = torch.randn(100, 16, requires_grad=True)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None


def test_hjrl_reset_parameters():
    """Test parameter reset clears cache."""
    model = HJRL(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # First forward pass caches preprocessing
    model(x, hyperedge_index)
    assert model._cached_data is not None

    # Reset should clear cache
    model.reset_parameters()
    assert model._cached_data is None


def test_hjrl_caching():
    """Test that preprocessing is cached."""
    model = HJRL(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        cache_preprocessing=True,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # First forward pass should cache
    model(x, hyperedge_index)
    cached_data1 = model._cached_data

    # Second forward pass should reuse cache
    out2 = model(x, hyperedge_index)
    cached_data2 = model._cached_data

    assert cached_data1 is cached_data2
    assert out2.shape == (100, 7)


def test_hjrl_no_caching():
    """Test HJRL without caching."""
    model = HJRL(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        cache_preprocessing=False,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)

    # Should not cache
    assert model._cached_data is None
    assert out.shape == (100, 7)


def test_hjrl_training_mode():
    """Test HJRL in training vs eval mode."""
    model = HJRL(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        dropout=0.5,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # Training mode
    model.train()
    torch.manual_seed(42)
    out_train = model(x, hyperedge_index)

    # Eval mode
    model.eval()
    torch.manual_seed(42)
    out_eval = model(x, hyperedge_index)

    # Outputs should differ due to dropout
    assert not torch.allclose(out_train, out_eval)


def test_hjrl_different_hypergraph_sizes():
    """Test HJRL with different numbers of nodes and hyperedges."""
    model = HJRL(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    # Small hypergraph
    x1 = torch.randn(10, 16)
    hyperedge_index1 = torch.tensor([[0, 1, 2], [0, 0, 0]])
    out1 = model(x1, hyperedge_index1)
    assert out1.shape == (10, 7)

    # Large hypergraph (cache should be invalidated)
    model.reset_parameters()
    x2 = torch.randn(50, 16)
    hyperedge_index2 = torch.tensor([[0, 1, 2, 3, 4, 5], [0, 0, 1, 1, 2, 2]])
    out2 = model(x2, hyperedge_index2)
    assert out2.shape == (50, 7)


def test_hjrl_repr():
    """Test string representation."""
    model = HJRL(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    repr_str = repr(model)
    assert "HJRL" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str
    assert "7" in repr_str


def test_hjrl_conv_repr():
    """Test HJRLConv string representation."""
    conv = HJRLConv(16, 32)
    repr_str = repr(conv)

    assert "HJRLConv" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str


def test_hjrl_multiple_layers():
    """Test HJRL with various layer counts."""
    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    for num_layers in [1, 2, 3, 4]:
        model = HJRL(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=num_layers,
        )

        out = model(x, hyperedge_index)
        assert out.shape == (50, 7)


def test_hjrl_empty_hypergraph():
    """Test HJRL with empty hypergraph."""
    model = HJRL(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[], []], dtype=torch.long).reshape(2, 0)

    out = model(x, hyperedge_index)

    # Should handle empty case gracefully
    assert out.shape == (10, 7)


def test_hjrl_cuda():
    """Test HJRL on CUDA if available."""
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")

    device = torch.device("cuda")
    model = HJRL(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    ).to(device)

    x = torch.randn(50, 16, device=device)
    hyperedge_index = torch.tensor(
        [[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]], device=device
    )

    out = model(x, hyperedge_index)

    assert out.device.type == device.type
    assert out.shape == (50, 7)
