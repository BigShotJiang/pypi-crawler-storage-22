"""Tests for HNHN model."""

import pytest
import torch

from pyg_hyper_nn.models.hnhn import HNHN, HNHNConv


def test_hnhn_conv_forward():
    """Test HNHNConv forward pass."""
    conv = HNHNConv(16, 32, 64)

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out, edge_embed = conv(x, hyperedge_index, num_edges=2)

    assert out.shape == (100, 64)
    assert edge_embed.shape == (2, 32)


def test_hnhn_forward():
    """Test HNHN forward pass."""
    model = HNHN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)


def test_hnhn_single_layer():
    """Test HNHN with single layer."""
    model = HNHN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=1,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)


def test_hnhn_different_alpha_beta():
    """Test HNHN with different alpha and beta values."""
    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    for alpha, beta in [(-0.5, -0.5), (-1.0, -1.0), (0.5, 0.5), (-0.5, -1.0)]:
        model = HNHN(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=2,
            alpha=alpha,
            beta=beta,
        )

        out = model(x, hyperedge_index)
        assert out.shape == (50, 7)


def test_hnhn_nonlinear_inbetween():
    """Test HNHN with and without nonlinear activation between stages."""
    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    model_with = HNHN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        nonlinear_inbetween=True,
    )

    model_without = HNHN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        nonlinear_inbetween=False,
    )

    out_with = model_with(x, hyperedge_index)
    out_without = model_without(x, hyperedge_index)

    assert out_with.shape == (50, 7)
    assert out_without.shape == (50, 7)
    # Outputs should differ due to nonlinearity
    assert not torch.allclose(out_with, out_without)


def test_hnhn_gradient_flow():
    """Test gradient flow through HNHN."""
    model = HNHN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    x = torch.randn(100, 16, requires_grad=True)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None


def test_hnhn_reset_parameters():
    """Test parameter reset."""
    model = HNHN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    # Save initial parameters
    params_before = [p.clone() for p in model.parameters()]

    # Reset
    model.reset_parameters()

    # Parameters should change (with high probability)
    params_after = list(model.parameters())
    assert len(params_before) == len(params_after)

    changed = False
    for p_before, p_after in zip(params_before, params_after):
        if not torch.allclose(p_before, p_after):
            changed = True
            break
    assert changed


def test_hnhn_training_mode():
    """Test HNHN in training vs eval mode."""
    model = HNHN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        dropout=0.5,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # Training mode
    model.train()
    torch.manual_seed(42)
    out_train = model(x, hyperedge_index)

    # Eval mode
    model.eval()
    torch.manual_seed(42)
    out_eval = model(x, hyperedge_index)

    # Outputs should differ due to dropout
    assert not torch.allclose(out_train, out_eval)


def test_hnhn_different_hypergraph_sizes():
    """Test HNHN with different numbers of nodes and hyperedges."""
    model = HNHN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    # Small hypergraph
    x1 = torch.randn(10, 16)
    hyperedge_index1 = torch.tensor([[0, 1, 2], [0, 0, 0]])
    out1 = model(x1, hyperedge_index1)
    assert out1.shape == (10, 7)

    # Large hypergraph
    x2 = torch.randn(50, 16)
    hyperedge_index2 = torch.tensor([[0, 1, 2, 3, 4, 5], [0, 0, 1, 1, 2, 2]])
    out2 = model(x2, hyperedge_index2)
    assert out2.shape == (50, 7)


def test_hnhn_repr():
    """Test string representation."""
    model = HNHN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        alpha=-0.5,
        beta=-1.0,
    )

    repr_str = repr(model)
    assert "HNHN" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str
    assert "7" in repr_str
    assert "-0.5" in repr_str
    assert "-1.0" in repr_str


def test_hnhn_conv_repr():
    """Test HNHNConv string representation."""
    conv = HNHNConv(16, 32, 64)
    repr_str = repr(conv)

    assert "HNHNConv" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str
    assert "64" in repr_str


def test_hnhn_multiple_layers():
    """Test HNHN with various layer counts."""
    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    for num_layers in [1, 2, 3, 4]:
        model = HNHN(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=num_layers,
        )

        out = model(x, hyperedge_index)
        assert out.shape == (50, 7)


def test_hnhn_empty_hypergraph():
    """Test HNHN with empty hypergraph."""
    model = HNHN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[], []], dtype=torch.long).reshape(2, 0)

    out = model(x, hyperedge_index)

    # Should handle empty case gracefully
    assert out.shape == (10, 7)


def test_hnhn_cuda():
    """Test HNHN on CUDA if available."""
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")

    device = torch.device("cuda")
    model = HNHN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    ).to(device)

    x = torch.randn(50, 16, device=device)
    hyperedge_index = torch.tensor(
        [[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]], device=device
    )

    out = model(x, hyperedge_index)

    assert out.device.type == device.type
    assert out.shape == (50, 7)
