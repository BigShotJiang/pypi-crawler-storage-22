"""Tests for HyperGCN model."""

import numpy as np
import pytest
import torch

from pyg_hyper_nn.models.hypergcn import HyperGCN


def test_hypergcn_forward_fast():
    """Test HyperGCN forward pass in fast mode."""
    model = HyperGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        fast=True,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    np.random.seed(42)
    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)


def test_hypergcn_forward_slow():
    """Test HyperGCN forward pass in slow mode (reapproximation)."""
    model = HyperGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        fast=False,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    np.random.seed(42)
    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)


def test_hypergcn_no_mediators():
    """Test HyperGCN without mediators."""
    model = HyperGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        mediators=False,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    np.random.seed(42)
    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)


def test_hypergcn_single_layer():
    """Test HyperGCN with single layer."""
    model = HyperGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=1,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    np.random.seed(42)
    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)


def test_hypergcn_gradient_flow():
    """Test gradient flow through HyperGCN."""
    model = HyperGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    x = torch.randn(100, 16, requires_grad=True)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    np.random.seed(42)
    out = model(x, hyperedge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None


def test_hypergcn_reset_parameters():
    """Test parameter reset clears cache."""
    model = HyperGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        fast=True,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # First forward pass caches structure
    np.random.seed(42)
    model(x, hyperedge_index)
    assert model.structure is not None

    # Reset should clear cache
    model.reset_parameters()
    assert model.structure is None


def test_hypergcn_caching():
    """Test that fast mode caches structure."""
    model = HyperGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        fast=True,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # First forward pass should cache
    np.random.seed(42)
    model(x, hyperedge_index)
    structure1 = model.structure

    # Second forward pass should reuse cache
    out2 = model(x, hyperedge_index)
    structure2 = model.structure

    assert structure1 is structure2
    assert out2.shape == (100, 7)


def test_hypergcn_training_mode():
    """Test HyperGCN in training vs eval mode."""
    model = HyperGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        dropout=0.5,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # Training mode
    model.train()
    np.random.seed(42)
    out_train = model(x, hyperedge_index)

    # Eval mode
    model.eval()
    np.random.seed(42)
    out_eval = model(x, hyperedge_index)

    # Outputs should differ due to dropout
    assert not torch.allclose(out_train, out_eval)


def test_hypergcn_different_hypergraph_sizes():
    """Test HyperGCN with different numbers of nodes and hyperedges."""
    model = HyperGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    # Small hypergraph
    x1 = torch.randn(10, 16)
    hyperedge_index1 = torch.tensor([[0, 1, 2], [0, 0, 0]])
    np.random.seed(42)
    out1 = model(x1, hyperedge_index1)
    assert out1.shape == (10, 7)

    # Large hypergraph
    model.reset_parameters()  # Clear cache
    x2 = torch.randn(50, 16)
    hyperedge_index2 = torch.tensor([[0, 1, 2, 3, 4, 5], [0, 0, 1, 1, 2, 2]])
    np.random.seed(42)
    out2 = model(x2, hyperedge_index2)
    assert out2.shape == (50, 7)


def test_hypergcn_repr():
    """Test string representation."""
    model = HyperGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        fast=True,
        mediators=False,
    )

    repr_str = repr(model)
    assert "HyperGCN" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str
    assert "7" in repr_str
    assert "fast=True" in repr_str
    assert "mediators=False" in repr_str


def test_hypergcn_fast_vs_slow_modes():
    """Test that fast and slow modes both work correctly."""
    torch.manual_seed(42)
    model_fast = HyperGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        fast=True,
        dropout=0.0,
    )

    torch.manual_seed(42)
    model_slow = HyperGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        fast=False,
        dropout=0.0,
    )

    torch.manual_seed(123)
    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    model_fast.eval()
    model_slow.eval()

    np.random.seed(42)
    out_fast = model_fast(x, hyperedge_index)

    np.random.seed(42)
    out_slow = model_slow(x, hyperedge_index)

    # Both modes should produce valid outputs
    assert out_fast.shape == (50, 7)
    assert out_slow.shape == (50, 7)


def test_hypergcn_cuda():
    """Test HyperGCN on CUDA if available."""
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")

    device = torch.device("cuda")
    model = HyperGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    ).to(device)

    x = torch.randn(50, 16, device=device)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    np.random.seed(42)
    out = model(x, hyperedge_index)

    assert out.device.type == device.type
    assert out.shape == (50, 7)
