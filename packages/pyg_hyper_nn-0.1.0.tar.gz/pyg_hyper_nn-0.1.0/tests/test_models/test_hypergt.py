"""Tests for HyperGT model."""

import torch

from pyg_hyper_nn.models.hypergt import HyperGT


def test_hypergt_forward():
    """Test HyperGT forward pass."""
    model = HyperGT(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        num_heads=4,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)
    assert not torch.isnan(out).any()


def test_hypergt_with_jk():
    """Test HyperGT with jumping knowledge."""
    model = HyperGT(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=3,
        use_jk=True,
    )

    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)

    assert out.shape == (50, 7)


def test_hypergt_without_residual():
    """Test HyperGT without residual connections."""
    model = HyperGT(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        use_residual=False,
    )

    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)

    assert out.shape == (50, 7)


def test_hypergt_with_positional_encodings():
    """Test HyperGT with HEPE and HtEPE."""
    model = HyperGT(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        use_hepe=True,
        use_htepe=True,
    )

    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.shape == (50, 7)
    # Check that encoders were initialized
    assert model.he_sparse_encoder is not None
    assert model.hte_sparse_encoder is not None


def test_hypergt_gradient_flow():
    """Test gradient flow through HyperGT."""
    model = HyperGT(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    x = torch.randn(50, 16, requires_grad=True)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None
    assert not torch.isnan(x.grad).any()


def test_hypergt_reset_parameters():
    """Test parameter reset."""
    model = HyperGT(16, 32, 7, 2)

    # Get initial weights
    fc_weight_before = model.fcs[0].weight.clone()

    # Reset
    model.reset_parameters()

    # Weights should be different
    fc_weight_after = model.fcs[0].weight
    assert not torch.allclose(fc_weight_before, fc_weight_after)


def test_hypergt_repr():
    """Test string representation."""
    model = HyperGT(16, 32, 7, 2, num_heads=4)
    repr_str = repr(model)

    assert "HyperGT" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str
    assert "7" in repr_str
    assert "num_layers=2" in repr_str
    assert "num_heads=4" in repr_str


def test_hypergt_single_layer():
    """Test HyperGT with single layer."""
    model = HyperGT(16, 32, 7, num_layers=1)

    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)

    assert out.shape == (50, 7)


def test_hypergt_empty_hypergraph():
    """Test HyperGT with empty hypergraph."""
    model = HyperGT(16, 32, 7, 2)

    x = torch.randn(10, 16)
    hyperedge_index = torch.empty((2, 0), dtype=torch.long)

    out = model(x, hyperedge_index)

    assert out.shape == (10, 7)
