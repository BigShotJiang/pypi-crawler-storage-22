"""Tests for HyperND model."""

import pytest
import torch

from pyg_hyper_nn.models.hypernd import HyperND


def test_hypernd_forward():
    """Test HyperND forward pass."""
    model = HyperND(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        max_steps=10,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)


def test_hypernd_single_layer():
    """Test HyperND with single layer."""
    model = HyperND(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=1,
    )

    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)

    assert out.shape == (50, 7)


def test_hypernd_different_p():
    """Test HyperND with different p values."""
    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    for p in [1.0, 1.5, 2.0, 3.0]:
        model = HyperND(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=2,
            p=p,
            max_steps=5,
        )

        out = model(x, hyperedge_index)
        assert out.shape == (50, 7)


def test_hypernd_different_alpha():
    """Test HyperND with different restart alpha values."""
    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    for alpha in [0.0, 0.1, 0.5, 1.0]:
        model = HyperND(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=2,
            alpha=alpha,
            max_steps=5,
        )

        out = model(x, hyperedge_index)
        assert out.shape == (50, 7)


def test_hypernd_different_aggregations():
    """Test HyperND with different aggregation methods."""
    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    for aggregation in ["sum", "mean", "max"]:
        model = HyperND(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=2,
            aggregation=aggregation,
            max_steps=5,
        )

        out = model(x, hyperedge_index)
        assert out.shape == (50, 7)


def test_hypernd_gradient_flow():
    """Test gradient flow through HyperND."""
    model = HyperND(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        max_steps=5,
    )

    x = torch.randn(50, 16, requires_grad=True)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None


def test_hypernd_reset_parameters():
    """Test parameter reset clears cache."""
    model = HyperND(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        max_steps=5,
        cache_diffusion=True,
    )

    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # First forward pass caches diffusion
    model(x, hyperedge_index)
    assert model._cached_features is not None

    # Reset should clear cache
    model.reset_parameters()
    assert model._cached_features is None


def test_hypernd_caching():
    """Test that diffusion is cached."""
    model = HyperND(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        max_steps=5,
        cache_diffusion=True,
    )

    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # First forward pass should cache
    model(x, hyperedge_index)
    cached_features1 = model._cached_features

    # Second forward pass should reuse cache
    out2 = model(x, hyperedge_index)
    cached_features2 = model._cached_features

    assert cached_features1 is cached_features2
    assert out2.shape == (50, 7)


def test_hypernd_no_caching():
    """Test HyperND without caching."""
    model = HyperND(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        max_steps=5,
        cache_diffusion=False,
    )

    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)

    # Should not cache
    assert model._cached_features is None
    assert out.shape == (50, 7)


def test_hypernd_empty_hypergraph():
    """Test HyperND with empty hypergraph."""
    model = HyperND(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        max_steps=5,
    )

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[], []], dtype=torch.long).reshape(2, 0)

    out = model(x, hyperedge_index)

    # Should handle empty case gracefully (returns decoder(x))
    assert out.shape == (10, 7)


def test_hypernd_convergence():
    """Test that diffusion can converge early."""
    model = HyperND(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        max_steps=100,
        tol=1e-3,  # Loose tolerance for early convergence
    )

    x = torch.randn(30, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)

    # Should converge and return valid output
    assert out.shape == (30, 7)
    assert not torch.isnan(out).any()
    assert not torch.isinf(out).any()


def test_hypernd_numerical_stability():
    """Test HyperND numerical stability with various inputs."""
    model = HyperND(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        max_steps=10,
    )

    # Test with small values
    x_small = torch.randn(30, 16) * 0.01
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    out = model(x_small, hyperedge_index)
    assert not torch.isnan(out).any()
    assert not torch.isinf(out).any()

    # Test with large values
    model.reset_parameters()
    x_large = torch.randn(30, 16) * 100
    out = model(x_large, hyperedge_index)
    assert not torch.isnan(out).any()
    assert not torch.isinf(out).any()


def test_hypernd_cuda():
    """Test HyperND on CUDA if available."""
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")

    device = torch.device("cuda")
    model = HyperND(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        max_steps=5,
    ).to(device)

    x = torch.randn(50, 16, device=device)
    hyperedge_index = torch.tensor(
        [[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]], device=device
    )

    out = model(x, hyperedge_index)

    assert out.device.type == device.type
    assert out.shape == (50, 7)


def test_hypernd_repr():
    """Test string representation."""
    model = HyperND(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        p=2.0,
        max_steps=50,
        alpha=0.1,
    )

    repr_str = repr(model)
    assert "HyperND" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str
    assert "7" in repr_str
    assert "p=2.0" in repr_str
