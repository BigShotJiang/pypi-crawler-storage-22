"""Tests for LEGCN model."""

import pytest
import torch

from pyg_hyper_nn.models.legcn import LEGCN


def test_legcn_forward():
    """Test LEGCN forward pass."""
    model = LEGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)


def test_legcn_single_layer():
    """Test LEGCN with single layer."""
    model = LEGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=1,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)


def test_legcn_different_aggregations():
    """Test LEGCN with different aggregation methods."""
    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    for agg in ["mean", "sum", "max"]:
        model = LEGCN(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=2,
            aggregation=agg,
        )

        out = model(x, hyperedge_index)
        assert out.shape == (50, 7)


def test_legcn_gradient_flow():
    """Test gradient flow through LEGCN."""
    model = LEGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    x = torch.randn(100, 16, requires_grad=True)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None


def test_legcn_reset_parameters():
    """Test parameter reset clears cache."""
    model = LEGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # First forward pass caches line expansion
    model(x, hyperedge_index)
    assert model._le_adj is not None

    # Reset should clear cache
    model.reset_parameters()
    assert model._le_adj is None


def test_legcn_caching():
    """Test that line expansion is cached."""
    model = LEGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # First forward pass should cache
    model(x, hyperedge_index)
    le_adj1 = model._le_adj

    # Second forward pass should reuse cache
    out2 = model(x, hyperedge_index)
    le_adj2 = model._le_adj

    assert le_adj1 is le_adj2
    assert out2.shape == (100, 7)


def test_legcn_training_mode():
    """Test LEGCN in training vs eval mode."""
    model = LEGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        dropout=0.5,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # Training mode
    model.train()
    torch.manual_seed(42)
    out_train = model(x, hyperedge_index)

    # Eval mode
    model.eval()
    torch.manual_seed(42)
    out_eval = model(x, hyperedge_index)

    # Outputs should differ due to dropout
    assert not torch.allclose(out_train, out_eval)


def test_legcn_different_hypergraph_sizes():
    """Test LEGCN with different numbers of nodes and hyperedges."""
    model = LEGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    # Small hypergraph
    x1 = torch.randn(10, 16)
    hyperedge_index1 = torch.tensor([[0, 1, 2], [0, 0, 0]])
    out1 = model(x1, hyperedge_index1)
    assert out1.shape == (10, 7)

    # Large hypergraph (cache should be invalidated)
    model.reset_parameters()
    x2 = torch.randn(50, 16)
    hyperedge_index2 = torch.tensor([[0, 1, 2, 3, 4, 5], [0, 0, 1, 1, 2, 2]])
    out2 = model(x2, hyperedge_index2)
    assert out2.shape == (50, 7)


def test_legcn_repr():
    """Test string representation."""
    model = LEGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        aggregation="sum",
    )

    repr_str = repr(model)
    assert "LEGCN" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str
    assert "7" in repr_str
    assert "sum" in repr_str


def test_legcn_isolated_nodes():
    """Test LEGCN with isolated nodes (not in any hyperedge)."""
    model = LEGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    # Node 3 is isolated
    x = torch.randn(4, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    out = model(x, hyperedge_index)

    # Should still produce output for all nodes
    assert out.shape == (4, 7)
    # Isolated node should have zero output (no incoming messages)
    assert torch.allclose(out[3], torch.zeros(7), atol=1e-6)


def test_legcn_multiple_layers():
    """Test LEGCN with various layer counts."""
    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    for num_layers in [1, 2, 3, 4]:
        model = LEGCN(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=num_layers,
        )

        out = model(x, hyperedge_index)
        assert out.shape == (50, 7)


def test_legcn_cuda():
    """Test LEGCN on CUDA if available."""
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")

    device = torch.device("cuda")
    model = LEGCN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    ).to(device)

    x = torch.randn(50, 16, device=device)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.device.type == device.type
    assert out.shape == (50, 7)
