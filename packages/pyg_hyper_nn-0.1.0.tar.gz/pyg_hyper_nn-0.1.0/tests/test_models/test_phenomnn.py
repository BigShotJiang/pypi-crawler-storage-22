"""Tests for PhenomNN model."""

import pytest
import torch

from pyg_hyper_nn.layers.preprocessing import phenomnn_expansion
from pyg_hyper_nn.models.phenomnn import PhenomNN, PhenomNNMultiConv


def test_phenomnn_multiconv_init():
    """Test PhenomNNMultiConv initialization."""
    conv = PhenomNNMultiConv(lam0=0.5, lam1=0.5, alpha=0.15, num_steps=3)

    assert conv.lam0 == 0.5
    assert conv.lam1 == 0.5
    assert conv.alpha == 0.15
    assert conv.num_steps == 3


def test_phenomnn_multiconv_alpha_default():
    """Test PhenomNNMultiConv alpha default computation."""
    conv = PhenomNNMultiConv(lam0=0.5, lam1=0.5, alpha=0.0, num_steps=2)

    # alpha should be 1 / (1 + lam0 + lam1) = 1 / 2 = 0.5
    assert conv.alpha == 0.5


def test_phenomnn_multiconv_forward():
    """Test PhenomNNMultiConv forward pass."""
    conv = PhenomNNMultiConv(lam0=0.5, lam1=0.5, alpha=0.15, num_steps=2)

    # Create simple test data
    X = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    # Compute adjacency matrices
    A_beta, D_beta, I = phenomnn_expansion(
        hyperedge_index, num_nodes=10, norm_type="node"
    )
    A_gamma, D_gamma, _ = phenomnn_expansion(
        hyperedge_index, num_nodes=10, norm_type="full"
    )

    # Forward pass
    out = conv(X, A_beta, A_gamma, D_beta, D_gamma, I)

    assert out.shape == (10, 16)
    assert not torch.isnan(out).any()
    assert not torch.isinf(out).any()


def test_phenomnn_multiconv_num_steps():
    """Test PhenomNNMultiConv with different num_steps."""
    X = torch.randn(5, 8)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    A_beta, D_beta, I = phenomnn_expansion(
        hyperedge_index, num_nodes=5, norm_type="node"
    )
    A_gamma, D_gamma, _ = phenomnn_expansion(
        hyperedge_index, num_nodes=5, norm_type="full"
    )

    outputs = []
    for num_steps in [1, 2, 5]:
        conv = PhenomNNMultiConv(num_steps=num_steps)
        out = conv(X, A_beta, A_gamma, D_beta, D_gamma, I)
        outputs.append(out)

    # Different num_steps should give different results
    assert not torch.allclose(outputs[0], outputs[1], atol=1e-3)
    assert not torch.allclose(outputs[1], outputs[2], atol=1e-3)


def test_phenomnn_init():
    """Test PhenomNN initialization."""
    model = PhenomNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        encoder_layers=2,
        decoder_layers=2,
        lam0=0.5,
        lam1=0.5,
        alpha=0.15,
        num_steps=3,
        dropout=0.5,
    )

    assert model.in_channels == 16
    assert model.hidden_channels == 32
    assert model.out_channels == 7
    assert model.lam0 == 0.5
    assert model.lam1 == 0.5
    assert model.alpha == 0.15
    assert model.num_steps == 3
    assert model.dropout == 0.5


def test_phenomnn_forward():
    """Test PhenomNN forward pass."""
    model = PhenomNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_steps=2,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)
    assert not torch.isnan(out).any()
    assert not torch.isinf(out).any()


def test_phenomnn_reset_parameters():
    """Test PhenomNN reset_parameters."""
    model = PhenomNN(in_channels=16, hidden_channels=32, out_channels=7)

    # Store initial parameters
    projector_weight = model.projector.lins[0].weight.clone()

    # Reset parameters
    model.reset_parameters()

    # Parameters should change (with high probability)
    assert not torch.allclose(model.projector.lins[0].weight, projector_weight)


def test_phenomnn_gradient_flow():
    """Test gradient flow through PhenomNN."""
    model = PhenomNN(in_channels=16, hidden_channels=32, out_channels=7, num_steps=2)

    x = torch.randn(20, 16, requires_grad=True)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None
    assert not torch.isnan(x.grad).any()
    assert (x.grad.abs() > 0).any()  # Some gradients should be non-zero


def test_phenomnn_different_lam():
    """Test PhenomNN with different lambda values."""
    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    outputs = []
    for lam0, lam1 in [(0.3, 0.7), (0.5, 0.5), (0.7, 0.3)]:
        model = PhenomNN(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            lam0=lam0,
            lam1=lam1,
            num_steps=2,
        )
        out = model(x, hyperedge_index)
        outputs.append(out)

    # Different lambda values should give different results
    for i in range(len(outputs) - 1):
        assert not torch.allclose(outputs[i], outputs[i + 1], atol=1e-3)


def test_phenomnn_different_num_steps():
    """Test PhenomNN with different numbers of propagation steps."""
    for num_steps in [1, 2, 5]:
        model = PhenomNN(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_steps=num_steps,
        )

        x = torch.randn(50, 16)
        hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

        out = model(x, hyperedge_index)
        assert out.shape == (50, 7)


def test_phenomnn_training_vs_eval():
    """Test that dropout behavior differs between training and eval modes."""
    model = PhenomNN(in_channels=16, hidden_channels=32, out_channels=7, dropout=0.5)

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # Training mode
    model.train()
    out_train1 = model(x, hyperedge_index)
    out_train2 = model(x, hyperedge_index)

    # Outputs should be different due to dropout
    assert not torch.allclose(out_train1, out_train2)

    # Eval mode
    model.eval()
    out_eval1 = model(x, hyperedge_index)
    out_eval2 = model(x, hyperedge_index)

    # Outputs should be identical in eval mode
    assert torch.allclose(out_eval1, out_eval2)


def test_phenomnn_empty_hypergraph():
    """Test PhenomNN with empty hypergraph."""
    model = PhenomNN(in_channels=16, hidden_channels=32, out_channels=7)

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[], []]).long()

    out = model(x, hyperedge_index)

    assert out.shape == (10, 7)
    assert not torch.isnan(out).any()


def test_phenomnn_single_node():
    """Test PhenomNN with single node."""
    model = PhenomNN(in_channels=16, hidden_channels=32, out_channels=7)
    model.eval()  # Set to eval mode to avoid batch norm issues

    x = torch.randn(1, 16)
    hyperedge_index = torch.tensor([[0], [0]])

    out = model(x, hyperedge_index)

    assert out.shape == (1, 7)


def test_phenomnn_repr():
    """Test PhenomNN string representation."""
    model = PhenomNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        lam0=0.5,
        lam1=0.5,
        num_steps=3,
    )

    repr_str = repr(model)
    assert "PhenomNN" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str
    assert "7" in repr_str
    assert "0.5" in repr_str
    assert "3" in repr_str


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_phenomnn_cuda():
    """Test PhenomNN on CUDA device."""
    device = torch.device("cuda")
    model = PhenomNN(in_channels=16, hidden_channels=32, out_channels=7).to(device)

    x = torch.randn(50, 16, device=device)
    hyperedge_index = torch.tensor(
        [[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]], device=device
    )

    out = model(x, hyperedge_index)

    assert out.device.type == device.type
    assert out.shape == (50, 7)
