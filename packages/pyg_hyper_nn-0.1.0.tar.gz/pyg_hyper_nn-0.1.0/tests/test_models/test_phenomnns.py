"""Tests for PhenomNNS model."""

import pytest
import torch

from pyg_hyper_nn.layers.preprocessing import phenomnn_expansion
from pyg_hyper_nn.models.phenomnns import PhenomNNS, PhenomNNSMultiConv


def test_phenomnns_multiconv_init():
    """Test PhenomNNSMultiConv initialization."""
    conv = PhenomNNSMultiConv(lam0=0.5, lam1=0.5, alpha=0.15, num_steps=3)

    assert conv.lam0 == 0.5
    assert conv.lam1 == 0.5
    assert conv.alpha == 0.15
    assert conv.num_steps == 3


def test_phenomnns_multiconv_alpha_default():
    """Test PhenomNNSMultiConv alpha default computation."""
    conv = PhenomNNSMultiConv(lam0=0.5, lam1=0.5, alpha=0.0, num_steps=2)

    # alpha should be 1 / (1 + lam0 + lam1) = 1 / 2 = 0.5
    assert conv.alpha == 0.5


def test_phenomnns_multiconv_forward():
    """Test PhenomNNSMultiConv forward pass."""
    conv = PhenomNNSMultiConv(lam0=0.5, lam1=0.5, alpha=0.15, num_steps=2)

    # Create simple test data
    X = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    # Compute adjacency matrices
    A_beta, D_beta, I = phenomnn_expansion(
        hyperedge_index, num_nodes=10, norm_type="node"
    )
    A_gamma, D_gamma, _ = phenomnn_expansion(
        hyperedge_index, num_nodes=10, norm_type="full"
    )

    # Combine matrices
    A = (0.5 * A_beta.to_dense() + 0.5 * A_gamma.to_dense()).to_sparse_coo()
    D = (0.5 * D_beta.to_dense() + 0.5 * D_gamma.to_dense()).to_sparse_coo()

    # Forward pass
    out = conv(X, A, D, I)

    assert out.shape == (10, 16)
    assert not torch.isnan(out).any()
    assert not torch.isinf(out).any()


def test_phenomnns_multiconv_num_steps():
    """Test PhenomNNSMultiConv with different num_steps."""
    X = torch.randn(5, 8)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    A_beta, D_beta, I = phenomnn_expansion(
        hyperedge_index, num_nodes=5, norm_type="node"
    )
    A_gamma, D_gamma, _ = phenomnn_expansion(
        hyperedge_index, num_nodes=5, norm_type="full"
    )

    A = (0.5 * A_beta.to_dense() + 0.5 * A_gamma.to_dense()).to_sparse_coo()
    D = (0.5 * D_beta.to_dense() + 0.5 * D_gamma.to_dense()).to_sparse_coo()

    outputs = []
    for num_steps in [1, 2, 5]:
        conv = PhenomNNSMultiConv(num_steps=num_steps)
        out = conv(X, A, D, I)
        outputs.append(out)

    # Different num_steps should give different results
    assert not torch.allclose(outputs[0], outputs[1], atol=1e-3)
    assert not torch.allclose(outputs[1], outputs[2], atol=1e-3)


def test_phenomnns_init():
    """Test PhenomNNS initialization."""
    model = PhenomNNS(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        encoder_layers=2,
        decoder_layers=2,
        lam0=0.5,
        lam1=0.5,
        alpha=0.15,
        num_steps=3,
        dropout=0.5,
    )

    assert model.in_channels == 16
    assert model.hidden_channels == 32
    assert model.out_channels == 7
    assert model.lam0 == 0.5
    assert model.lam1 == 0.5
    assert model.alpha == 0.15
    assert model.num_steps == 3
    assert model.dropout == 0.5


def test_phenomnns_forward():
    """Test PhenomNNS forward pass."""
    model = PhenomNNS(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_steps=2,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)
    assert not torch.isnan(out).any()
    assert not torch.isinf(out).any()


def test_phenomnns_reset_parameters():
    """Test PhenomNNS reset_parameters."""
    model = PhenomNNS(in_channels=16, hidden_channels=32, out_channels=7)

    # Store initial parameters
    projector_weight = model.projector.lins[0].weight.clone()

    # Reset parameters
    model.reset_parameters()

    # Parameters should change (with high probability)
    assert not torch.allclose(model.projector.lins[0].weight, projector_weight)


def test_phenomnns_gradient_flow():
    """Test gradient flow through PhenomNNS."""
    model = PhenomNNS(in_channels=16, hidden_channels=32, out_channels=7, num_steps=2)

    x = torch.randn(20, 16, requires_grad=True)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None
    assert not torch.isnan(x.grad).any()
    assert (x.grad.abs() > 0).any()  # Some gradients should be non-zero


def test_phenomnns_different_lam():
    """Test PhenomNNS with different lambda values."""
    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    outputs = []
    for lam0, lam1 in [(0.3, 0.7), (0.5, 0.5), (0.7, 0.3)]:
        model = PhenomNNS(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            lam0=lam0,
            lam1=lam1,
            num_steps=2,
        )
        out = model(x, hyperedge_index)
        outputs.append(out)

    # Different lambda values should give different results
    for i in range(len(outputs) - 1):
        assert not torch.allclose(outputs[i], outputs[i + 1], atol=1e-3)


def test_phenomnns_different_num_steps():
    """Test PhenomNNS with different numbers of propagation steps."""
    for num_steps in [1, 2, 5]:
        model = PhenomNNS(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_steps=num_steps,
        )

        x = torch.randn(50, 16)
        hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

        out = model(x, hyperedge_index)
        assert out.shape == (50, 7)


def test_phenomnns_training_vs_eval():
    """Test that dropout behavior differs between training and eval modes."""
    model = PhenomNNS(in_channels=16, hidden_channels=32, out_channels=7, dropout=0.5)

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # Training mode
    model.train()
    out_train1 = model(x, hyperedge_index)
    out_train2 = model(x, hyperedge_index)

    # Outputs should be different due to dropout
    assert not torch.allclose(out_train1, out_train2)

    # Eval mode
    model.eval()
    out_eval1 = model(x, hyperedge_index)
    out_eval2 = model(x, hyperedge_index)

    # Outputs should be identical in eval mode
    assert torch.allclose(out_eval1, out_eval2)


def test_phenomnns_empty_hypergraph():
    """Test PhenomNNS with empty hypergraph."""
    model = PhenomNNS(in_channels=16, hidden_channels=32, out_channels=7)

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[], []]).long()

    out = model(x, hyperedge_index)

    assert out.shape == (10, 7)
    assert not torch.isnan(out).any()


def test_phenomnns_single_node():
    """Test PhenomNNS with single node."""
    model = PhenomNNS(in_channels=16, hidden_channels=32, out_channels=7)
    model.eval()  # Set to eval mode to avoid batch norm issues

    x = torch.randn(1, 16)
    hyperedge_index = torch.tensor([[0], [0]])

    out = model(x, hyperedge_index)

    assert out.shape == (1, 7)


def test_phenomnns_repr():
    """Test PhenomNNS string representation."""
    model = PhenomNNS(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        lam0=0.5,
        lam1=0.5,
        num_steps=3,
    )

    repr_str = repr(model)
    assert "PhenomNNS" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str
    assert "7" in repr_str
    assert "0.5" in repr_str
    assert "3" in repr_str


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_phenomnns_cuda():
    """Test PhenomNNS on CUDA device."""
    device = torch.device("cuda")
    model = PhenomNNS(in_channels=16, hidden_channels=32, out_channels=7).to(device)

    x = torch.randn(50, 16, device=device)
    hyperedge_index = torch.tensor(
        [[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]], device=device
    )

    out = model(x, hyperedge_index)

    assert out.device.type == device.type
    assert out.shape == (50, 7)


def test_phenomnn_vs_phenomnns():
    """Test that PhenomNN and PhenomNNS give similar (but not identical) results."""
    from pyg_hyper_nn.models.phenomnn import PhenomNN

    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    # Both models with same hyperparameters
    model_phenomnn = PhenomNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        lam0=0.5,
        lam1=0.5,
        num_steps=2,
    )
    model_phenomnns = PhenomNNS(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        lam0=0.5,
        lam1=0.5,
        num_steps=2,
    )

    model_phenomnn.eval()
    model_phenomnns.eval()

    out_phenomnn = model_phenomnn(x, hyperedge_index)
    out_phenomnns = model_phenomnns(x, hyperedge_index)

    # Shapes should be the same
    assert out_phenomnn.shape == out_phenomnns.shape

    # Results should be different (different architectures)
    # But not too different (same underlying concept)
    assert not torch.allclose(out_phenomnn, out_phenomnns, atol=1e-3)
