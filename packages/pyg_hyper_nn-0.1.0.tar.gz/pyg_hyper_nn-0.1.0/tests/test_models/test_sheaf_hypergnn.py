"""Tests for SheafHyperGNN model."""

import pytest
import torch

from pyg_hyper_nn.models.sheaf_hypergnn import SheafHyperGNN


def test_sheaf_hypergnn_init():
    """Test SheafHyperGNN initialization."""
    model = SheafHyperGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        stalk_dim=4,
    )

    assert model.in_channels == 16
    assert model.hidden_channels == 32
    assert model.out_channels == 7
    assert model.num_layers == 2
    assert model.d == 4


def test_sheaf_hypergnn_forward():
    """Test SheafHyperGNN forward pass."""
    model = SheafHyperGNN(
        in_channels=16, hidden_channels=32, out_channels=7, num_layers=2, stalk_dim=3
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)
    assert not torch.isnan(out).any()


def test_sheaf_hypergnn_single_layer():
    """Test SheafHyperGNN with single layer."""
    model = SheafHyperGNN(
        in_channels=8, hidden_channels=16, out_channels=5, num_layers=1, stalk_dim=2
    )

    x = torch.randn(50, 8)
    hyperedge_index = torch.tensor([[0, 1, 2, 3], [0, 0, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.shape == (50, 5)


def test_sheaf_hypergnn_dynamic_sheaf():
    """Test SheafHyperGNN with dynamic sheaf (changes per layer)."""
    model = SheafHyperGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=3,
        stalk_dim=4,
        dynamic_sheaf=True,
    )

    # Should have 3 sheaf builders (one per layer)
    assert len(model.sheaf_builder) == 3

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)


def test_sheaf_hypergnn_static_sheaf():
    """Test SheafHyperGNN with static sheaf (shared across layers)."""
    model = SheafHyperGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=3,
        stalk_dim=4,
        dynamic_sheaf=False,
    )

    # Should have 1 sheaf builder (shared)
    assert len(model.sheaf_builder) == 1

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)


def test_sheaf_hypergnn_residual():
    """Test SheafHyperGNN with residual connections."""
    model = SheafHyperGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        stalk_dim=4,
        residual=True,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)


def test_sheaf_hypergnn_reset_parameters():
    """Test SheafHyperGNN reset_parameters."""
    model = SheafHyperGNN(
        in_channels=16, hidden_channels=32, out_channels=7, stalk_dim=4
    )

    # Store initial parameters
    initial_weight = model.lin.lins[0].weight.clone()

    # Reset
    model.reset_parameters()

    # Parameters should change
    assert not torch.allclose(model.lin.lins[0].weight, initial_weight)
    # Hyperedge attributes should be cleared
    assert model.hyperedge_attr is None


def test_sheaf_hypergnn_gradient_flow():
    """Test gradient flow through SheafHyperGNN."""
    model = SheafHyperGNN(
        in_channels=16, hidden_channels=32, out_channels=7, num_layers=2, stalk_dim=3
    )

    x = torch.randn(50, 16, requires_grad=True)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None
    assert not torch.isnan(x.grad).any()


def test_sheaf_hypergnn_training_vs_eval():
    """Test that dropout behavior differs between training and eval modes."""
    model = SheafHyperGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
        stalk_dim=3,
        dropout=0.5,
    )

    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    # Training mode
    model.train()
    model(x, hyperedge_index)
    model(x, hyperedge_index)

    # Outputs may differ due to dropout
    # (not guaranteed due to randomness, but likely)

    # Eval mode
    model.eval()
    # Reset hyperedge_attr to ensure deterministic behavior
    model.hyperedge_attr = None
    out_eval1 = model(x, hyperedge_index)
    model.hyperedge_attr = None
    out_eval2 = model(x, hyperedge_index)

    # Outputs should be identical in eval mode
    assert torch.allclose(out_eval1, out_eval2)


def test_sheaf_hypergnn_empty_hypergraph():
    """Test SheafHyperGNN with empty hypergraph."""
    model = SheafHyperGNN(
        in_channels=16, hidden_channels=32, out_channels=7, stalk_dim=3
    )
    model.eval()

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[], []]).long()

    out = model(x, hyperedge_index)

    assert out.shape == (10, 7)
    assert not torch.isnan(out).any()


def test_sheaf_hypergnn_different_stalk_dims():
    """Test SheafHyperGNN with different stalk dimensions."""
    for stalk_dim in [2, 4, 8]:
        model = SheafHyperGNN(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=2,
            stalk_dim=stalk_dim,
        )

        x = torch.randn(50, 16)
        hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

        out = model(x, hyperedge_index)

        assert out.shape == (50, 7)


def test_sheaf_hypergnn_different_prediction_types():
    """Test SheafHyperGNN with different sheaf prediction variants."""
    for pred_type in ["MLP_var1", "MLP_var2", "MLP_var3", "cp_decomp"]:
        model = SheafHyperGNN(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=2,
            stalk_dim=4,
            prediction_type=pred_type,
        )

        x = torch.randn(50, 16)
        hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

        out = model(x, hyperedge_index)

        assert out.shape == (50, 7)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_sheaf_hypergnn_cuda():
    """Test SheafHyperGNN on CUDA device."""
    device = torch.device("cuda")
    model = SheafHyperGNN(
        in_channels=16, hidden_channels=32, out_channels=7, stalk_dim=4
    ).to(device)

    x = torch.randn(50, 16, device=device)
    hyperedge_index = torch.tensor(
        [[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]], device=device
    )

    out = model(x, hyperedge_index)

    assert out.device.type == "cuda"
    assert out.shape == (50, 7)


def test_sheaf_hypergnn_repr():
    """Test SheafHyperGNN string representation."""
    model = SheafHyperGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=3,
        stalk_dim=5,
    )

    repr_str = repr(model)

    assert "SheafHyperGNN" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str
    assert "7" in repr_str
    assert "num_layers=3" in repr_str
    assert "stalk_dim=5" in repr_str


def test_sheaf_hypergnn_clear_flag():
    """Test clear_flag functionality for multi-graph scenarios."""
    # Model with clear_flag=True should recompute cache on each forward
    model = SheafHyperGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        stalk_dim=3,
        clear_flag=True,
    )

    # First graph
    x1 = torch.randn(10, 16)
    hyperedge_index1 = torch.tensor([[0, 1, 2], [0, 0, 0]])
    out1 = model(x1, hyperedge_index1)

    # Second graph with different size
    x2 = torch.randn(15, 16)
    hyperedge_index2 = torch.tensor([[0, 1, 2, 3], [0, 0, 1, 1]])
    out2 = model(x2, hyperedge_index2)

    # Check outputs have correct shapes
    assert out1.shape == (10, 7)
    assert out2.shape == (15, 7)


def test_sheaf_hypergnn_clear_flag_vs_no_flag():
    """Test that clear_flag affects caching behavior."""
    # Model without clear_flag (default)
    model_no_flag = SheafHyperGNN(
        in_channels=16, hidden_channels=32, out_channels=7, stalk_dim=3
    )

    # Model with clear_flag
    model_with_flag = SheafHyperGNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        stalk_dim=3,
        clear_flag=True,
    )

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # Both should produce outputs
    out_no_flag = model_no_flag(x, hyperedge_index)
    out_with_flag = model_with_flag(x, hyperedge_index)

    assert out_no_flag.shape == (10, 7)
    assert out_with_flag.shape == (10, 7)
