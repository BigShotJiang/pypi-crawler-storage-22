"""Tests for TFHNN model."""

import pytest
import torch

from pyg_hyper_nn.models.tfhnn import TFHNN


def test_tfhnn_init():
    """Test TFHNN initialization."""
    model = TFHNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=3,
        alpha=0.15,
    )

    assert model.in_channels == 16
    assert model.hidden_channels == 32
    assert model.out_channels == 7
    assert model.num_layers == 3
    assert model.alpha == 0.15


def test_tfhnn_forward():
    """Test TFHNN forward pass."""
    model = TFHNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=2,
    )

    x = torch.randn(100, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)

    assert out.shape == (100, 7)
    assert not torch.isnan(out).any()
    assert not torch.isinf(out).any()


def test_tfhnn_compute_weighted_ce_graph_basic():
    """Test _compute_weighted_ce_graph method with basic input."""
    model = TFHNN(in_channels=16, hidden_channels=32, out_channels=7)

    # Simple hypergraph: edge 0 contains nodes [0, 1, 2]
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])
    num_nodes = 3

    adj = model._compute_weighted_ce_graph(hyperedge_index, num_nodes)

    assert adj.shape == (3, 3)
    assert adj.is_sparse
    assert adj.layout == torch.sparse_coo

    # Check that adjacency is symmetric
    adj_dense = adj.to_dense()
    assert torch.allclose(adj_dense, adj_dense.t(), atol=1e-6)

    # All nodes should be connected (in same hyperedge)
    assert (adj_dense > 0).all()


def test_tfhnn_compute_weighted_ce_graph_multiple_edges():
    """Test _compute_weighted_ce_graph with multiple hyperedges."""
    model = TFHNN(in_channels=16, hidden_channels=32, out_channels=7)

    # Two hyperedges: [0,1,2] and [1,2,3]
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])
    num_nodes = 4

    adj = model._compute_weighted_ce_graph(hyperedge_index, num_nodes)

    assert adj.shape == (4, 4)
    adj_dense = adj.to_dense()

    # Nodes 0,1,2 should be connected (edge 0)
    assert adj_dense[0, 1] > 0
    assert adj_dense[0, 2] > 0
    assert adj_dense[1, 2] > 0

    # Nodes 1,2,3 should be connected (edge 1)
    assert adj_dense[1, 3] > 0
    assert adj_dense[2, 3] > 0

    # Node 0 and 3 should not be directly connected (no common hyperedge)
    # But they might have non-zero values due to self-loops
    assert adj_dense[0, 0] > 0  # Self-loop


def test_tfhnn_compute_weighted_ce_graph_empty():
    """Test _compute_weighted_ce_graph with empty hypergraph."""
    model = TFHNN(in_channels=16, hidden_channels=32, out_channels=7)

    hyperedge_index = torch.tensor([[], []]).long()
    num_nodes = 5

    adj = model._compute_weighted_ce_graph(hyperedge_index, num_nodes)

    assert adj.shape == (5, 5)
    adj_dense = adj.to_dense()

    # Should be identity matrix (only self-loops)
    expected = torch.eye(5)
    assert torch.allclose(adj_dense, expected, atol=1e-6)


def test_tfhnn_propagate():
    """Test TFHNN _diffusion method."""
    model = TFHNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=3,
        alpha=0.15,
    )

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    propagated = model._diffusion(x, hyperedge_index)

    assert propagated.shape == x.shape
    assert not torch.isnan(propagated).any()
    assert not torch.isinf(propagated).any()

    # Propagated features should be different from input
    assert not torch.allclose(propagated, x)


def test_tfhnn_propagate_caching():
    """Test that _diffusion caches results correctly."""
    model = TFHNN(in_channels=16, hidden_channels=32, out_channels=7)
    model.eval()  # Set to eval mode to enable caching

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # First call
    out1 = model._diffusion(x, hyperedge_index)

    # Second call should use cache
    out2 = model._diffusion(x, hyperedge_index)

    assert torch.allclose(out1, out2)
    assert model._cache is not None


def test_tfhnn_reset_parameters():
    """Test reset_parameters clears cache."""
    model = TFHNN(in_channels=16, hidden_channels=32, out_channels=7)
    model.eval()

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # Populate cache
    _ = model._diffusion(x, hyperedge_index)
    assert model._cache is not None

    # Reset should clear cache
    model.reset_parameters()
    assert model._cache is None


def test_tfhnn_gradient_flow():
    """Test gradient flow through TFHNN."""
    model = TFHNN(in_channels=16, hidden_channels=32, out_channels=7, num_layers=2)

    x = torch.randn(20, 16, requires_grad=True)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    out = model(x, hyperedge_index)
    loss = out.sum()
    loss.backward()

    assert x.grad is not None
    assert not torch.isnan(x.grad).any()
    assert (x.grad.abs() > 0).any()  # Some gradients should be non-zero


def test_tfhnn_different_num_layers():
    """Test TFHNN with different numbers of diffusion layers."""
    for num_layers in [1, 2, 5, 10]:
        model = TFHNN(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=num_layers,
        )

        x = torch.randn(50, 16)
        hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

        out = model(x, hyperedge_index)
        assert out.shape == (50, 7)


def test_tfhnn_different_alpha():
    """Test TFHNN with different alpha values."""
    x = torch.randn(50, 16)
    hyperedge_index = torch.tensor([[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]])

    outputs = []
    for alpha in [0.01, 0.1, 0.5, 0.9]:
        model = TFHNN(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=2,
            alpha=alpha,
        )
        out = model(x, hyperedge_index)
        outputs.append(out)

    # Different alpha values should give different results
    for i in range(len(outputs) - 1):
        assert not torch.allclose(outputs[i], outputs[i + 1], atol=1e-3)


def test_tfhnn_training_vs_eval():
    """Test that caching behavior differs between training and eval modes."""
    model = TFHNN(in_channels=16, hidden_channels=32, out_channels=7)

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # Training mode: cache should be cleared
    model.train()
    _ = model(x, hyperedge_index)

    # Eval mode: cache should persist
    model.eval()
    _ = model(x, hyperedge_index)
    cache_after_eval = model._cache

    # In eval mode, cache is populated
    assert cache_after_eval is not None


def test_tfhnn_empty_hypergraph():
    """Test TFHNN with empty hypergraph."""
    model = TFHNN(in_channels=16, hidden_channels=32, out_channels=7)

    x = torch.randn(10, 16)
    hyperedge_index = torch.tensor([[], []]).long()

    out = model(x, hyperedge_index)

    assert out.shape == (10, 7)
    assert not torch.isnan(out).any()


def test_tfhnn_single_node():
    """Test TFHNN with single node."""
    model = TFHNN(in_channels=16, hidden_channels=32, out_channels=7)
    model.eval()  # Set to eval mode to avoid batch norm issues

    x = torch.randn(1, 16)
    hyperedge_index = torch.tensor([[0], [0]])

    out = model(x, hyperedge_index)

    assert out.shape == (1, 7)


def test_tfhnn_repr():
    """Test TFHNN string representation."""
    model = TFHNN(
        in_channels=16,
        hidden_channels=32,
        out_channels=7,
        num_layers=3,
        alpha=0.15,
    )

    repr_str = repr(model)
    assert "TFHNN" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str
    assert "7" in repr_str
    assert "3" in repr_str
    assert "0.15" in repr_str


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_tfhnn_cuda():
    """Test TFHNN on CUDA device."""
    device = torch.device("cuda")
    model = TFHNN(in_channels=16, hidden_channels=32, out_channels=7).to(device)

    x = torch.randn(50, 16, device=device)
    hyperedge_index = torch.tensor(
        [[0, 1, 2, 1, 2, 3], [0, 0, 0, 1, 1, 1]], device=device
    )

    out = model(x, hyperedge_index)

    assert out.device.type == device.type
    assert out.shape == (50, 7)
