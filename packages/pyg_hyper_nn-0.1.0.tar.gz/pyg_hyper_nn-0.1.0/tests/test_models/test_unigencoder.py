"""Tests for PlainUnigencoder model."""

import pytest
import torch

from pyg_hyper_nn.models import PlainUnigencoder


def create_simple_pooling_matrices(num_nodes: int, num_groups: int) -> tuple:
    """Create simple pooling matrices for testing.

    Each group contains consecutive nodes. For example, if num_nodes=6 and
    num_groups=3, then groups are: [0,1], [2,3], [4,5].

    Returns:
        Tuple of (Pv, PvT) as sparse COO tensors.
    """
    nodes_per_group = num_nodes // num_groups
    indices = []
    for group_idx in range(num_groups):
        start_node = group_idx * nodes_per_group
        end_node = start_node + nodes_per_group
        for node_idx in range(start_node, end_node):
            indices.append([group_idx, node_idx])

    indices = torch.tensor(indices).t()
    values = torch.ones(indices.shape[1])

    Pv = torch.sparse_coo_tensor(
        indices, values, size=(num_groups, num_nodes), dtype=torch.float32
    )
    PvT = torch.sparse_coo_tensor(
        indices.flip(0), values, size=(num_nodes, num_groups), dtype=torch.float32
    )

    return Pv, PvT


def test_plain_unigencoder_init():
    """Test PlainUnigencoder initialization."""
    model = PlainUnigencoder(
        in_channels=16, hidden_channels=32, out_channels=7, num_layers=3, dropout=0.5
    )

    assert model.in_channels == 16
    assert model.hidden_channels == 32
    assert model.out_channels == 7
    assert model.num_layers == 3
    assert model.dropout == 0.5
    assert len(model.lins) == 3  # in->hidden, hidden->hidden, hidden->out


def test_plain_unigencoder_forward():
    """Test PlainUnigencoder forward pass."""
    model = PlainUnigencoder(
        in_channels=16, hidden_channels=32, out_channels=7, num_layers=2
    )

    num_nodes, num_groups = 12, 4
    x = torch.randn(num_nodes, 16)
    Pv, PvT = create_simple_pooling_matrices(num_nodes, num_groups)

    out = model(x, Pv, PvT)

    assert out.shape == (num_nodes, 7)
    assert not torch.isnan(out).any()
    assert not torch.isinf(out).any()


def test_plain_unigencoder_reset_parameters():
    """Test reset_parameters method."""
    model = PlainUnigencoder(in_channels=16, hidden_channels=32, out_channels=7)

    # Get initial parameters
    initial_params = [p.clone() for p in model.parameters()]

    # Reset parameters
    model.reset_parameters()

    # Check that parameters changed
    for initial, current in zip(initial_params, model.parameters()):
        assert not torch.allclose(initial, current)


def test_plain_unigencoder_gradient_flow():
    """Test gradient flow through the model."""
    model = PlainUnigencoder(
        in_channels=16, hidden_channels=32, out_channels=7, num_layers=2
    )

    num_nodes, num_groups = 10, 5
    x = torch.randn(num_nodes, 16, requires_grad=True)
    Pv, PvT = create_simple_pooling_matrices(num_nodes, num_groups)

    out = model(x, Pv, PvT)
    loss = out.sum()
    loss.backward()

    # Check gradients exist
    assert x.grad is not None
    assert not torch.all(x.grad == 0)

    # Check model parameter gradients
    for param in model.parameters():
        assert param.grad is not None
        assert not torch.all(param.grad == 0)


def test_plain_unigencoder_training_vs_eval():
    """Test model behavior in training vs eval mode."""
    model = PlainUnigencoder(
        in_channels=16, hidden_channels=32, out_channels=7, dropout=0.6
    )

    num_nodes, num_groups = 10, 5
    x = torch.randn(num_nodes, 16)
    Pv, PvT = create_simple_pooling_matrices(num_nodes, num_groups)

    # Training mode - dropout active
    model.train()
    _ = model(x, Pv, PvT)  # First call with dropout
    _ = model(x, Pv, PvT)  # Second call with dropout

    # Outputs may differ due to dropout (though not guaranteed with small data)

    # Eval mode - deterministic
    model.eval()
    out_eval1 = model(x, Pv, PvT)
    out_eval2 = model(x, Pv, PvT)

    # Eval mode should be deterministic
    assert torch.allclose(out_eval1, out_eval2)


def test_plain_unigencoder_different_num_layers():
    """Test with different number of layers."""
    for num_layers in [1, 2, 3, 4]:
        model = PlainUnigencoder(
            in_channels=16,
            hidden_channels=32,
            out_channels=7,
            num_layers=num_layers,
        )

        num_nodes, num_groups = 10, 5
        x = torch.randn(num_nodes, 16)
        Pv, PvT = create_simple_pooling_matrices(num_nodes, num_groups)

        out = model(x, Pv, PvT)

        assert out.shape == (num_nodes, 7)
        assert len(model.lins) == num_layers


def test_plain_unigencoder_with_hyperedge_index():
    """Test that model accepts hyperedge_index (for API consistency)."""
    model = PlainUnigencoder(in_channels=16, hidden_channels=32, out_channels=7)

    num_nodes, num_groups = 10, 5
    x = torch.randn(num_nodes, 16)
    Pv, PvT = create_simple_pooling_matrices(num_nodes, num_groups)
    hyperedge_index = torch.tensor([[0, 1, 2], [0, 0, 0]])

    # Should work even though hyperedge_index is not used
    out = model(x, Pv, PvT, hyperedge_index=hyperedge_index)

    assert out.shape == (num_nodes, 7)


def test_plain_unigencoder_pooling_unpooling():
    """Test that pooling and unpooling work correctly."""
    model = PlainUnigencoder(
        in_channels=4, hidden_channels=4, out_channels=4, num_layers=1
    )

    # Create identity-like pooling (each group has 1 node)
    num_nodes = 4
    num_groups = 4
    indices = torch.tensor([[i, i] for i in range(4)]).t()
    values = torch.ones(4)

    Pv = torch.sparse_coo_tensor(
        indices, values, size=(num_groups, num_nodes), dtype=torch.float32
    )
    PvT = torch.sparse_coo_tensor(
        indices.flip(0), values, size=(num_nodes, num_groups), dtype=torch.float32
    )

    x = torch.eye(4)  # Identity matrix as input

    out = model(x, Pv, PvT)

    # Output should have same number of nodes
    assert out.shape == (4, 4)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_plain_unigencoder_cuda():
    """Test PlainUnigencoder on CUDA device."""
    device = torch.device("cuda")
    model = PlainUnigencoder(in_channels=16, hidden_channels=32, out_channels=7).to(
        device
    )

    num_nodes, num_groups = 10, 5
    x = torch.randn(num_nodes, 16, device=device)
    Pv, PvT = create_simple_pooling_matrices(num_nodes, num_groups)
    Pv = Pv.to(device)
    PvT = PvT.to(device)

    out = model(x, Pv, PvT)

    assert out.device.type == "cuda"
    assert out.shape == (num_nodes, 7)


def test_plain_unigencoder_repr():
    """Test PlainUnigencoder string representation."""
    model = PlainUnigencoder(
        in_channels=16, hidden_channels=32, out_channels=7, num_layers=3, dropout=0.6
    )

    repr_str = repr(model)

    assert "PlainUnigencoder" in repr_str
    assert "16" in repr_str
    assert "32" in repr_str
    assert "7" in repr_str
    assert "num_layers=3" in repr_str
    assert "dropout=0.6" in repr_str


def test_plain_unigencoder_asymmetric_pooling():
    """Test with asymmetric pooling (different sizes for groups)."""
    # Create pooling where group 0 has 3 nodes, group 1 has 2 nodes
    num_nodes = 5
    num_groups = 2

    indices = [
        [0, 0],  # group 0, node 0
        [0, 1],  # group 0, node 1
        [0, 2],  # group 0, node 2
        [1, 3],  # group 1, node 3
        [1, 4],  # group 1, node 4
    ]
    indices = torch.tensor(indices).t()
    values = torch.ones(5)

    Pv = torch.sparse_coo_tensor(
        indices, values, size=(num_groups, num_nodes), dtype=torch.float32
    )
    PvT = torch.sparse_coo_tensor(
        indices.flip(0), values, size=(num_nodes, num_groups), dtype=torch.float32
    )

    model = PlainUnigencoder(in_channels=8, hidden_channels=16, out_channels=4)
    x = torch.randn(num_nodes, 8)

    out = model(x, Pv, PvT)

    assert out.shape == (num_nodes, 4)
