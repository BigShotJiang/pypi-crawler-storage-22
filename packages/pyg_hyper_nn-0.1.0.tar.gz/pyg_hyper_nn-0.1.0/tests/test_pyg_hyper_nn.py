"""Tests for pyg_hyper_nn."""

from pyg_hyper_nn import check_cuda, hello


def test_hello() -> None:
    """Test the hello function."""
    result = hello()
    assert isinstance(result, str)
    assert "pyg-hyper-nn" in result
    assert result == "Hello from pyg-hyper-nn!"


def test_hello_return_type() -> None:
    """Test that hello returns a string."""
    result = hello()
    assert isinstance(result, str)


def test_check_cuda_returns_dict() -> None:
    """Test that check_cuda returns a dictionary."""
    result = check_cuda()
    assert isinstance(result, dict)
    assert "cuda_available" in result
    assert "cuda_version" in result
    assert "device_count" in result
    assert "device_name" in result


def test_check_cuda_types() -> None:
    """Test that check_cuda returns correct types."""
    result = check_cuda()
    assert isinstance(result["cuda_available"], bool)
    assert isinstance(result["device_count"], int)
    assert result["device_count"] >= 0


class TestHello:
    """Test class for hello function."""

    def test_hello_not_empty(self) -> None:
        """Test that hello returns a non-empty string."""
        result = hello()
        assert len(result) > 0

    def test_hello_contains_project_name(self) -> None:
        """Test that hello contains the project name."""
        result = hello()
        assert "pyg-hyper-nn" in result


class TestCUDA:
    """Test class for CUDA functionality."""

    def test_cuda_check_structure(self) -> None:
        """Test that CUDA check returns expected structure."""
        result = check_cuda()
        expected_keys = {
            "cuda_available",
            "cuda_version",
            "device_count",
            "device_name",
        }
        assert set(result.keys()) == expected_keys
