# Changelog

All notable changes to PyGEAI-Orchestration will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial project structure and configuration
- Core base classes for agents, orchestrators, and patterns
- CLI framework with `geai-orch` command
- Reflection pattern for iterative improvement
- Tool Use pattern for function calling
- ReAct pattern for reasoning and acting
- Planning pattern for multi-step execution
- Multi-Agent pattern for collaborative workflows
- Comprehensive test suite with unit and integration tests
- Documentation and examples for all patterns
- GitHub Actions CI/CD workflows
- 9 working code snippets demonstrating all patterns:
  - `reflection_explanation.py` - Iterative explanation improvement
  - `reflection_code_review.py` - Code review with self-critique
  - `react_research.py` - Structured research tasks
  - `react_problem_solving.py` - Step-by-step problem solving
  - `planning_project.py` - Project planning and breakdown
  - `planning_analysis.py` - Data analysis planning
  - `tool_use_calculator.py` - Mathematical operations with tools
  - `tool_use_data_processing.py` - Data validation and transformation
  - `multi_agent_collaboration.py` - Collaborative multi-agent workflow

### Changed
- **BREAKING**: Refactored entire import system to use absolute imports only
  - All imports now use full module paths: `from pygeai_orchestration.core.base import ...`
  - Removed all relative imports (`.module` style)
- **BREAKING**: Removed `get_logger()` and `OrchestrationLogger` from public API
  - All modules now use standard `logging.getLogger("pygeai_orchestration")`
  - Logging disabled by default with `NullHandler` (follows PyGEAI pattern)
  - Users can enable logging by configuring the `"pygeai_orchestration"` logger
- **BREAKING**: Renamed all snippet files from `*_snippet.py` to `<pattern>_<topic>.py` format
  - More descriptive naming that indicates pattern and use case
  - Example: `reflection_snippet.py` → `reflection_explanation.py`
- Updated `GEAIAgent` to use actual PyGEAI Session and ChatManager APIs
  - Proper integration with PyGEAI chat completion
  - Correct credential loading from `~/.geai/credentials`
  - Support for provider-prefixed model names (e.g., `openai/gpt-4o-mini`)
- Tool system improvements:
  - `BaseTool` subclasses must implement `validate_parameters()` method
  - `ToolConfig` uses `parameters_schema` field (not `parameters`)
  - Clear ToolCategory enum values: SEARCH, COMPUTATION, DATA_ACCESS, COMMUNICATION, CUSTOM
- All pattern implementations updated to use absolute imports and standard logging

### Fixed
- PyGEAI integration now uses correct Session and ChatManager APIs
- Removed incorrect assumptions about `Session.agents` and `Session.chats` attributes
- Fixed message formatting to use proper PyGEAI `ChatMessageList` and `ChatMessage` models
- Fixed credential loading to delegate to PyGEAI's configuration system
- Corrected model naming to include provider prefix as required by PyGEAI

### Removed
- **BREAKING**: Removed PyGEAI availability checks
  - PyGEAI is now a required dependency
  - No fallback or mock implementations
- Removed `get_logger()` utility function from `pygeai_orchestration.core.utils`
- Removed `OrchestrationLogger` singleton class
- Removed all relative import statements across the codebase

## [0.1.0b1] - 2026-02-05

### Added
- Initial beta release of PyGEAI-Orchestration
- Foundation for agentic AI orchestration patterns
- Integration with PyGEAI SDK
- Basic project structure and tooling
