PyGEAI Orchestration Documentation
===================================

**PyGEAI Orchestration** is an advanced orchestration framework built on top of the PyGEAI SDK,
providing powerful patterns and utilities for building complex AI agent workflows.

Features
--------

* **5 Orchestration Patterns**: Reflection, Tool Use, ReAct, Planning, Multi-Agent
* **Robust Error Handling**: Custom exceptions and retry mechanisms
* **State Management**: Checkpoint and restore capabilities
* **Memory Systems**: Short-term and long-term memory management
* **Type-Safe**: Full type hints and Pydantic models
* **Well-Tested**: 116 tests with 100% pass rate

Quick Start
-----------

Installation::

    pip install pygeai-orchestration

Basic Usage::

    from pygeai_orchestration import GEAIAgent, AgentConfig, ReflectionPattern

    # Create an agent
    config = AgentConfig(
        name="assistant",
        model="gpt-4",
        temperature=0.7
    )
    agent = GEAIAgent(config)

    # Use a pattern
    pattern = ReflectionPattern(agent=agent, max_iterations=3)
    result = await pattern.execute("Write a technical article...")

    print(result.output)

Table of Contents
-----------------

.. toctree::
   :maxdepth: 2
   :caption: User Guide

   quickstart
   patterns
   examples

.. toctree::
   :maxdepth: 3
   :caption: API Reference

   api/core
   api/patterns
   api/exceptions

.. toctree::
   :maxdepth: 1
   :caption: Development

   contributing
   changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
