"""
Base commands for the geai-orch CLI.
"""

from typing import List, Tuple

from pygeai_orchestration import __version__
from pygeai_orchestration.cli.commands import Command, Option, ArgumentsEnum
from pygeai_orchestration.cli.texts.help import (
    CLI_USAGE,
    VERSION_TEXT,
    HELP_REFLECTION,
    HELP_TOOL_USE,
    HELP_REACT,
    HELP_PLANNING,
    HELP_MULTI_AGENT,
)


def show_help(option_list: List[Tuple[Option, str]] = None):
    """
    Display help information for geai-orch CLI.

    :param option_list: Optional list of options (unused, for compatibility)
    """
    print(CLI_USAGE)


def show_version(option_list: List[Tuple[Option, str]] = None):
    """
    Display version information.

    :param option_list: Optional list of options (unused, for compatibility)
    """
    print(VERSION_TEXT.format(version=__version__))


def show_reflection_help(option_list: List[Tuple[Option, str]] = None):
    """Display help for reflection command."""
    print(HELP_REFLECTION)


def show_tool_use_help(option_list: List[Tuple[Option, str]] = None):
    """Display help for tool-use command."""
    print(HELP_TOOL_USE)


def show_react_help(option_list: List[Tuple[Option, str]] = None):
    """Display help for react command."""
    print(HELP_REACT)


def show_planning_help(option_list: List[Tuple[Option, str]] = None):
    """Display help for planning command."""
    print(HELP_PLANNING)


def show_multi_agent_help(option_list: List[Tuple[Option, str]] = None):
    """Display help for multi-agent command."""
    print(HELP_MULTI_AGENT)


def placeholder_handler(option_list: List[Tuple[Option, str]] = None):
    """
    Placeholder handler for commands not yet implemented.

    :param option_list: List of parsed options
    """
    print("⚠️  This command is not yet implemented.")
    print("This feature is under development and will be available soon.")


help_command = Command(
    name="help",
    identifiers=["help", "-h", "--help"],
    description="Show help information",
    action=show_help,
    additional_args=ArgumentsEnum.NOT_AVAILABLE,
    subcommands=[],
    options=[],
)

version_command = Command(
    name="version",
    identifiers=["version", "-V", "--version"],
    description="Show version information",
    action=show_version,
    additional_args=ArgumentsEnum.NOT_AVAILABLE,
    subcommands=[],
    options=[],
)

reflection_command = Command(
    name="reflection",
    identifiers=["reflection", "reflect"],
    description="Run reflection pattern for iterative improvement",
    action=placeholder_handler,
    additional_args=ArgumentsEnum.OPTIONAL,
    subcommands=[],
    options=[
        Option("agent", ["-a", "--agent"], "Agent ID to use for reflection", True),
        Option("iterations", ["-i", "--iterations"], "Number of reflection iterations", True),
        Option("task", ["-t", "--task"], "Task or text to improve", True),
        Option("output", ["-o", "--output"], "Output file for results", True),
        Option("verbose", ["-v", "--verbose"], "Show detailed output", False),
        Option("help", ["-h", "--help"], "Show help for this command", False),
    ],
)

tool_use_command = Command(
    name="tool-use",
    identifiers=["tool-use", "tools"],
    description="Execute tool use pattern with function calling",
    action=placeholder_handler,
    additional_args=ArgumentsEnum.OPTIONAL,
    subcommands=[],
    options=[
        Option("agent", ["-a", "--agent"], "Agent ID to use", True),
        Option("tools", ["-t", "--tools"], "Tools configuration file", True),
        Option("task", ["--task"], "Task description", True),
        Option("output", ["-o", "--output"], "Output file for results", True),
        Option("verbose", ["-v", "--verbose"], "Show detailed output", False),
        Option("help", ["-h", "--help"], "Show help for this command", False),
    ],
)

react_command = Command(
    name="react",
    identifiers=["react"],
    description="Run ReAct (Reasoning + Acting) pattern",
    action=placeholder_handler,
    additional_args=ArgumentsEnum.OPTIONAL,
    subcommands=[],
    options=[
        Option("agent", ["-a", "--agent"], "Agent ID to use", True),
        Option("task", ["-t", "--task"], "Task to solve", True),
        Option("max_steps", ["--max-steps"], "Maximum reasoning-acting steps", True),
        Option("output", ["-o", "--output"], "Output file for results", True),
        Option("verbose", ["-v", "--verbose"], "Show detailed reasoning trace", False),
        Option("help", ["-h", "--help"], "Show help for this command", False),
    ],
)

planning_command = Command(
    name="planning",
    identifiers=["planning", "plan"],
    description="Execute planning pattern for multi-step tasks",
    action=placeholder_handler,
    additional_args=ArgumentsEnum.OPTIONAL,
    subcommands=[],
    options=[
        Option("agent", ["-a", "--agent"], "Planner agent ID", True),
        Option("task", ["-t", "--task"], "Task to plan and execute", True),
        Option("plan_only", ["--plan-only"], "Only create plan, don't execute", False),
        Option("output", ["-o", "--output"], "Output file for results", True),
        Option("verbose", ["-v", "--verbose"], "Show detailed execution trace", False),
        Option("help", ["-h", "--help"], "Show help for this command", False),
    ],
)

multi_agent_command = Command(
    name="multi-agent",
    identifiers=["multi-agent", "multi"],
    description="Run multi-agent coordination pattern",
    action=placeholder_handler,
    additional_args=ArgumentsEnum.OPTIONAL,
    subcommands=[],
    options=[
        Option("config", ["-c", "--config"], "Agent configuration file", True),
        Option("task", ["-t", "--task"], "Task for agents to collaborate on", True),
        Option("strategy", ["--strategy"], "Coordination strategy", True),
        Option("output", ["-o", "--output"], "Output file for results", True),
        Option("verbose", ["-v", "--verbose"], "Show agent communication details", False),
        Option("help", ["-h", "--help"], "Show help for this command", False),
    ],
)

base_commands = [
    help_command,
    version_command,
    reflection_command,
    tool_use_command,
    react_command,
    planning_command,
    multi_agent_command,
]

base_options = [
    Option("alias", ["-a", "--alias"], "Use a specific credentials profile", True),
    Option("credentials", ["--credentials", "--creds"], "Path to custom credentials file", True),
    Option("verbose", ["-v", "--verbose"], "Enable verbose logging", False),
]
