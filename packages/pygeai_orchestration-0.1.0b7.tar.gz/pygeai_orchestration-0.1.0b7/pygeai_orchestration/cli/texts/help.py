"""
Help text for the geai-orch CLI.
"""

CLI_USAGE = """
geai-orch - Agentic AI Orchestration CLI for Globant Enterprise AI

USAGE:
    geai-orch [OPTIONS] <COMMAND> [ARGS]

OPTIONS:
    -a, --alias <ALIAS>         Use a specific credentials profile
    --credentials <FILE>        Path to custom credentials file
    -v, --verbose              Enable verbose logging
    -h, --help                 Show help information
    --version                  Show version information

COMMANDS:
    help                       Show help information
    version                    Show version information
    reflection                 Run reflection pattern
    tool-use                   Execute tool use pattern
    react                      Run ReAct (Reasoning + Acting) pattern
    planning                   Execute planning pattern
    multi-agent                Run multi-agent coordination pattern
    run                        Quick run a pattern

EXAMPLES:
    # Show help
    geai-orch help

    # Run reflection pattern
    geai-orch reflection --agent my-agent --iterations 3

    # Execute ReAct pattern with custom task
    geai-orch react --task "Solve complex problem" --max-steps 10

    # Multi-agent collaboration
    geai-orch multi-agent --config agents.yaml

    # Use specific credentials profile
    geai-orch --alias production reflection --agent my-agent

For more information, visit: https://github.com/genexus-books/pygeai-orchestration
"""

VERSION_TEXT = """
geai-orch version {version}
PyGEAI-Orchestration - Agentic AI Orchestration Patterns

Copyright © 2026 Globant
Licensed under the MIT License
"""

HELP_REFLECTION = """
reflection - Run reflection pattern for iterative improvement

USAGE:
    geai-orch reflection [OPTIONS]

OPTIONS:
    -a, --agent <ID>           Agent ID to use for reflection
    -i, --iterations <N>       Number of reflection iterations (default: 3)
    -t, --task <TEXT>          Task or text to improve
    -o, --output <FILE>        Output file for results
    -v, --verbose              Show detailed output

DESCRIPTION:
    The reflection pattern enables agents to self-critique and iteratively
    improve their outputs through multiple reflection cycles.

EXAMPLES:
    geai-orch reflection --agent critic --task "Write a summary" --iterations 5
    geai-orch reflection -a my-agent -t "Improve this code" -o result.txt
"""

HELP_TOOL_USE = """
tool-use - Execute tool use pattern with function calling

USAGE:
    geai-orch tool-use [OPTIONS]

OPTIONS:
    -a, --agent <ID>           Agent ID to use
    -t, --tools <FILE>         Tools configuration file (YAML/JSON)
    --task <TEXT>              Task description
    -o, --output <FILE>        Output file for results
    -v, --verbose              Show detailed output

DESCRIPTION:
    The tool use pattern integrates function calling and external tool
    execution into agent workflows.

EXAMPLES:
    geai-orch tool-use --agent worker --tools tools.yaml --task "Search for info"
    geai-orch tool-use -a my-agent --task "Execute calculation"
"""

HELP_REACT = """
react - Run ReAct (Reasoning + Acting) pattern

USAGE:
    geai-orch react [OPTIONS]

OPTIONS:
    -a, --agent <ID>           Agent ID to use
    -t, --task <TEXT>          Task to solve
    --max-steps <N>            Maximum reasoning-acting steps (default: 10)
    -o, --output <FILE>        Output file for results
    -v, --verbose              Show detailed reasoning trace

DESCRIPTION:
    The ReAct pattern implements a Reasoning + Acting loop for step-by-step
    problem solving with explicit reasoning traces.

EXAMPLES:
    geai-orch react --agent reasoning-agent --task "Research topic" --max-steps 15
    geai-orch react -a solver --task "Multi-step problem" -v
"""

HELP_PLANNING = """
planning - Execute planning pattern for multi-step tasks

USAGE:
    geai-orch planning [OPTIONS]

OPTIONS:
    -a, --agent <ID>           Planner agent ID
    -t, --task <TEXT>          Task to plan and execute
    --plan-only                Only create plan, don't execute
    -o, --output <FILE>        Output file for results
    -v, --verbose              Show detailed execution trace

DESCRIPTION:
    The planning pattern creates and executes multi-step plans with
    adaptive execution and progress tracking.

EXAMPLES:
    geai-orch planning --agent planner --task "Build web app"
    geai-orch planning -a my-planner --task "Complex project" --plan-only
"""

HELP_MULTI_AGENT = """
multi-agent - Run multi-agent coordination pattern

USAGE:
    geai-orch multi-agent [OPTIONS]

OPTIONS:
    -c, --config <FILE>        Agent configuration file (YAML/JSON)
    -t, --task <TEXT>          Task for agents to collaborate on
    --strategy <NAME>          Coordination strategy (default: sequential)
    -o, --output <FILE>        Output file for results
    -v, --verbose              Show agent communication details

DESCRIPTION:
    The multi-agent pattern coordinates multiple agents working
    collaboratively on complex tasks with defined roles.

STRATEGIES:
    sequential    - Agents work one after another
    parallel      - Agents work simultaneously
    hierarchical  - Leader-worker coordination
    consensus     - Agents reach consensus

EXAMPLES:
    geai-orch multi-agent --config agents.yaml --task "Research report"
    geai-orch multi-agent -c team.yaml -t "Complex analysis" --strategy consensus
"""
