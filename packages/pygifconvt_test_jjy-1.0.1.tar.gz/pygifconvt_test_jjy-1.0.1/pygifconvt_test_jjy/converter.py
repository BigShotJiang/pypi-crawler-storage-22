import glob
from PIL import Image

class GifConverter:
    def __init__(self, path_in=None, path_out=None, resize=(320, 240)):
        """
        :param path_in: 원본 여러 이미지 경로(Ex: images/*.png)
        :param path_out: 결과 이미지 경로(Ex: output/filename.png)
        :param resize: 리사이징 크기((320, 240))
        """
        self.path_in = path_in or './*.png'
        self.path_out = path_out or './output.gif'
        self.resize = resize

    def convert_gif(self):
        """
        :return: GIF 이미지 변환 기능 수행
        """
        print(self.path_in, self.path_out, self.resize)
        img, *images = [
            Image.open(f).resize(self.resize, Image.LANCZOS) for f in sorted(glob.glob(self.path_in))
        ]

        try:
            img.save(
                fp=self.path_out,
                format='GIF',
                append_images=images,
                save_all=True,
                duration=500,
                loop=0
            )
        except IOError:
            print('Cannot conver!', img)

# 직접 실행할 때만 실행됨.
if __name__ == '__main__':
    # 클래스
    c = GifConverter('../project/images/*.png', '../project/image_out/result77.gif', (320, 240))

    # 변환
    c.convert_gif()

    print(GifConverter.convert_gif.__doc__)