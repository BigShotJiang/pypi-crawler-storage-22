from setuptools import setup, find_packages

setup(
    name             = 'pygifconvt_test_jjy',
    version          = '1.0.1',
    description      = 'Test package for distribution',
    author           = 'Jaeyeong',
    author_email     = 'zzz26lk@gmail.com',
    url              = '',
    download_url     = '',
    install_requires = ['pillow'], # 자동 설치
	include_package_data=True,
	packages=find_packages(),
    keywords         = ['GIFCONVERTER', 'gifconverter'],
    python_requires  = '>=3', # 파이썬 버전이 3.x 이상이여야 함
    zip_safe=False,
    classifiers      = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    ]
) 