# pygraphos

Python bindings for Graphos, a pure-Rust, high-performance, embeddable graph database.

## Installation

```bash
pip install pygraphos
```

## Usage

```python
import pygraphos
```

## License

Apache-2.0
