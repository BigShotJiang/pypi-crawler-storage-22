# "Settings" Dialog Example

Shows howto manage a settings dialog in a simple application.

Application and Dialog UI are defined in same UI file.

Using designer code generator, two classes are defined to mantain 
dialog and application logic separated.

The dialog window is invoqued from main ui with a button.
