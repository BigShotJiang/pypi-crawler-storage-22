# Tkinterweb

This folder contains basic usage examples for
[HtmlLabel](https://github.com/alejandroautalan/pygubu-designer/tree/master/examples/plugin_tkinterweb/demo1),
[HtmlFrame](https://github.com/alejandroautalan/pygubu-designer/tree/master/examples/plugin_tkinterweb/demo2)
and
[Notebook](https://github.com/alejandroautalan/pygubu-designer/tree/master/examples/plugin_tkinterweb/demo3)
widgets created with pygubu-designer.
