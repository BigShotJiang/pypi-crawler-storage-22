# Treeview demo 2

Shows behavior of column stretching options.
