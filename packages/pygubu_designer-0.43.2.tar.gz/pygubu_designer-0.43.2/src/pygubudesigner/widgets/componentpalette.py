#
# Copyright 2012-2022 Alejandro Autalán
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.

import tkinter as tk
import tkinter.ttk as ttk

import pygubu.widgets.simpletooltip as tooltip

from .toolbarframe import ToolbarFrame


class ComponentPalette(ttk.Frame):
    def __init__(self, master=None, notebook=True, **kw):
        ttk.Frame.__init__(self, master, **kw)
        component_palette = ttk.Frame(master)
        fbuttons = ttk.Frame(component_palette)
        fbuttons.configure(padding=1)
        rb_tk = ttk.Radiobutton(fbuttons)
        self.gvalue = gvalue = tk.StringVar(value="")
        rb_tk.config(
            style="Toolbutton",
            text="tk",
            value="tk",
            variable=gvalue,
            command=self._on_tk_clicked,
        )
        rb_tk.pack(expand="true", fill="both", side="top")
        rb_ttk = ttk.Radiobutton(fbuttons)
        rb_ttk.config(
            style="Toolbutton",
            text="ttk",
            value="ttk",
            variable=gvalue,
            command=self._on_ttk_clicked,
        )
        rb_ttk.pack(expand="true", fill="both", side="top")
        fbuttons.pack(fill="y", side="left")
        fbntab = ttk.Frame(component_palette)
        if notebook:
            self.notebook = ttk.Notebook(fbntab)
            self.notebook.config(
                height="50",
                width="300",
                style="ComponentPalette.TNotebook",
                takefocus=True,
            )
            self.notebook.pack(side="top", expand=True, fill="x")
        else:
            self.notebook = None
            self.frame = ToolbarFrame(fbntab)
            self.frame.pack(side="top", expand=True, fill="both")
        fbntab.config(height="200", width="200")
        fbntab.pack(side="left", expand=True, fill="x")
        component_palette.config(height="200", padding="2", width="200")
        component_palette.pack(side="top", expand=True, fill="x")
        self._tabs = {}
        self._buttons = []

    def _on_tk_clicked(self):
        self.show_group("tk")

    def _on_ttk_clicked(self):
        self.show_group("ttk")

    def add_tab(self, tabid, label):
        # frame_1 = ttk.Frame(self.notebook)
        if not self.notebook:
            return
        frame_1 = ToolbarFrame(self.notebook)
        frame_1.configure(padding=2)
        frame_1.pack(expand="true", fill="both", side="top")
        self.notebook.add(frame_1, text=label)
        self._tabs[tabid] = frame_1

    def add_button(self, tabid, group, label, ttiplabel, image, callback):
        master = self._tabs[tabid].child_master() if self.notebook else self.frame.child_master()
        # master = self._tabs[tabid]
        b = ttk.Button(
            master,
            text=label,
            image=image,
            style="ComponentPalette.Toolbutton",
            command=callback,
            compound="top",
            takefocus=True,
        )
        tooltip.create(b, ttiplabel)
        b.pack(side="left")
        self._buttons.append((b, group))

    def show_group(self, group):
        for b, g in self._buttons:
            if g == group:
                b.pack(side="left")
            else:
                b.pack_forget()
        self.gvalue.set(group)


if __name__ == "__main__":
    root = tk.Tk()
    widget = ComponentPalette(root)
    widget.pack(expand=True, fill="both")
    root.mainloop()
