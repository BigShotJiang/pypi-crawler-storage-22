import os, sys, ctypes
_package_dir = os.path.dirname(os.path.abspath(__file__))
_dll_dir_handle = None
if sys.platform == 'win32':
    if hasattr(os, 'add_dll_directory'):
        _dll_dir_handle = os.add_dll_directory(_package_dir)
    os.environ['PATH'] = _package_dir + os.pathsep + os.environ.get('PATH', '')
    for _f in sorted(os.listdir(_package_dir)):
        if _f.endswith('.dll') and 'iec61850' in _f.lower():
            try:
                ctypes.WinDLL(os.path.join(_package_dir, _f), winmode=0)
                break
            except Exception as _e:
                print(f'Warning: Failed to load {_f}: {_e}')
else:
    for _f in os.listdir(_package_dir):
        if _f.startswith('libiec61850.so'):
            try:
                ctypes.CDLL(os.path.join(_package_dir, _f))
                break
            except Exception:
                pass
try:
    from . import tase2
except ImportError:
    pass
try:
    from . import mms
except ImportError:
    pass
try:
    from . import goose
except ImportError:
    pass
try:
    from . import sv
except ImportError:
    pass
try:
    from . import server
except ImportError:
    pass
__all__ = ['tase2', 'mms', 'goose', 'sv', 'server']
