"""Binary download and management for pyINLA.

This module handles downloading INLA binaries on-demand, similar to R-INLA's
inla.binary.install() function.

Downloads are driven by a local binaries.json manifest that maps each platform
to a tested download URL on download.pyinla.org, with optional SHA-256 verification.
"""

import hashlib
import json
import os
import platform
import re
import shutil
import struct
import subprocess
import sys
import tarfile
import tempfile
import urllib.request
import zipfile
from pathlib import Path
from typing import Optional, List, Dict


class BinaryManager:
    """Manages INLA binary downloads and installation."""

    def __init__(self):
        """Initialize binary manager."""
        # Parent.parent because we're in pyinla/binary/manager.py
        self.package_dir = Path(__file__).parent.parent
        self.bin_dir = self.package_dir / "bin"

    # ------------------------------------------------------------------ #
    #  Manifest-based download (primary, safe)                            #
    # ------------------------------------------------------------------ #

    def _load_manifest(self) -> dict:
        """Load the binaries.json manifest file."""
        manifest_path = Path(__file__).parent / "binaries.json"
        if not manifest_path.exists():
            raise FileNotFoundError(
                f"Binary manifest not found at {manifest_path}. "
                "Package may be corrupted. Reinstall with: pip install --force-reinstall pyinla"
            )
        with open(manifest_path, 'r') as f:
            return json.load(f)

    def _platform_key(self) -> str:
        """Map current platform to a manifest key.

        Returns one of: linux_x86_64, linux_aarch64, windows_x86_64,
        macos_arm64, macos_x86_64.
        """
        system = platform.system().lower()
        machine = platform.machine().lower()

        if system == "linux":
            if machine in ("aarch64", "arm64"):
                return "linux_aarch64"
            return "linux_x86_64"
        elif system == "darwin":
            if machine in ("arm64", "aarch64"):
                return "macos_arm64"
            return "macos_x86_64"
        elif system == "windows" or system.startswith("win"):
            return "windows_x86_64"
        else:
            raise RuntimeError(f"Unsupported platform: {system} {machine}")

    def download_from_manifest(self, force: bool = False) -> Path:
        """Download INLA binary using the JSON manifest.

        This is the preferred download method. It looks up the current
        platform in binaries.json and downloads the exact URL for this
        architecture.

        Args:
            force: Force re-download even if binary already exists.

        Returns:
            Path to installed binary.
        """
        platform_name = self.detect_platform()
        binary_path = self.get_binary_path(platform_name)

        if not force and self.is_installed(platform_name):
            print(f"INLA binary already installed at: {binary_path}")
            return binary_path

        pkey = self._platform_key()
        manifest = self._load_manifest()
        binaries = manifest.get("binaries", {})

        if pkey not in binaries:
            raise RuntimeError(
                f"No binary available for platform '{pkey}'. "
                f"Available platforms: {list(binaries.keys())}"
            )

        entry = binaries[pkey]

        # For Linux, try to match a distro-specific build
        distro_entry = None
        if pkey.startswith("linux_"):
            distro_entry = self._match_distro_key(entry)

        if distro_entry:
            url = distro_entry["url"]
            version = distro_entry.get("version", entry.get("version", "unknown"))
            expected_sha256 = distro_entry.get("sha256", entry.get("sha256"))
            archive_format = distro_entry.get("format", entry.get("format", "tgz"))
        else:
            url = entry["url"]
            version = entry.get("version", "unknown")
            expected_sha256 = entry.get("sha256")
            archive_format = entry.get("format", "tgz")

        print(f"Platform: {pkey} (Version {version})")

        with tempfile.TemporaryDirectory() as tmpdir:
            ext = "zip" if archive_format == "zip" else "tgz"
            archive_path = Path(tmpdir) / f"binary.{ext}"

            self._download_file(url, archive_path, "Downloading binary")

            # Verify SHA-256 if provided
            if expected_sha256:
                self._verify_sha256(archive_path, expected_sha256)

            # Extract
            print("Extracting...")
            self._safe_extract(archive_path, tmpdir, archive_format)

            # Find the extracted binary directory
            extracted_dir = self._find_extracted_dir(
                Path(tmpdir), platform_name, pkey
            )

            # Install files
            self._install_extracted_files(
                extracted_dir, binary_path, platform_name
            )

        # Ensure entry-point binary exists
        self._ensure_binary_entry_point(binary_path.parent, platform_name)

        # Post-download architecture verification
        self._verify_architecture(binary_path, pkey)

        # Save version info
        self._save_version(binary_path, version, pkey, url)

        print(f"Installed INLA binary to: {binary_path}")
        return binary_path

    @staticmethod
    def _safe_extract(archive_path: Path, dest: str, fmt: str) -> None:
        """Extract an archive safely, using tarfile filter when available."""
        if fmt == "zip":
            with zipfile.ZipFile(archive_path, 'r') as zf:
                zf.extractall(dest)
        else:
            with tarfile.open(archive_path, 'r:gz') as tar:
                # Python 3.12+ supports filter='data' to prevent path traversal
                if sys.version_info >= (3, 12):
                    tar.extractall(dest, filter='data')
                else:
                    tar.extractall(dest)

    def _find_extracted_dir(self, tmpdir: Path, platform_name: str,
                            pkey: str) -> Path:
        """Find the directory containing binaries inside an extracted archive.

        Handles both CDN archives (64bit/ at root) and R-INLA Mac packages
        (INLA/bin/<platform>/ structure).
        """
        # Try 64bit/ at root first (CDN archive format, all platforms)
        bits_dir = tmpdir / "64bit"
        if bits_dir.exists():
            return bits_dir

        # For Mac, try R-INLA package structure (INLA/bin/...)
        if pkey.startswith("macos_"):
            try:
                return self._find_mac_binary_dir(tmpdir, platform_name)
            except RuntimeError:
                pass

        # Fallback: binaries directly in tmpdir
        return tmpdir

    def _save_version(self, binary_path: Path, version: str,
                      platform_key: str, url: str) -> None:
        """Save version info to a JSON file next to the installed binary."""
        from datetime import datetime
        version_file = binary_path.parent / "inla_version.json"
        info = {
            "version": version,
            "platform": platform_key,
            "url": url,
            "installed": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        with open(version_file, 'w') as f:
            json.dump(info, f, indent=2)
        print(f"Version saved: {version_file}")

    def get_installed_version(self, platform_name: str = None) -> Optional[dict]:
        """Read the installed INLA binary version info.

        Returns:
            Dict with version, platform, url, installed date, or None if
            no version file found.
        """
        if platform_name is None:
            platform_name = self.detect_platform()
        binary_path = self.get_binary_path(platform_name)
        version_file = binary_path.parent / "inla_version.json"
        if not version_file.exists():
            return None
        with open(version_file, 'r') as f:
            return json.load(f)

    def _verify_sha256(self, file_path: Path, expected: str) -> None:
        """Verify file SHA-256 checksum."""
        sha256 = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        actual = sha256.hexdigest()
        if actual != expected:
            raise RuntimeError(
                f"SHA-256 mismatch.\n"
                f"  Expected: {expected}\n"
                f"  Got:      {actual}\n"
                f"The download may be corrupted. Try again with force=True."
            )
        print(f"SHA-256 verified: {actual[:16]}...")

    def _find_mac_binary_dir(self, tmpdir: Path, platform_name: str) -> Path:
        """Find the binary directory inside an extracted Mac R package."""
        if platform_name == "mac.arm64":
            bin_subdir = "mac.arm64"
        else:
            bin_subdir = "mac/64bit"

        extracted = tmpdir / "INLA" / "bin" / bin_subdir
        if extracted.exists():
            return extracted

        # Fallback: search for inla.run
        for root, dirs, files in os.walk(tmpdir / "INLA" / "bin"):
            for f in files:
                if f in ("inla.run", "inla"):
                    return Path(root)

        raise RuntimeError("Could not find INLA binary directory in Mac package")

    def _install_extracted_files(
        self, src_dir: Path, binary_path: Path, platform_name: str
    ) -> None:
        """Install extracted binary files to the target directory."""
        if platform_name == "linux":
            binary_names = ["inla.mkl.run", "inla.run", "inla"]
        elif platform_name == "windows":
            binary_names = ["inla.exe", "inla"]
        else:
            binary_names = ["inla.run", "inla"]

        found = any((src_dir / name).exists() for name in binary_names)
        if not found:
            raise RuntimeError(
                f"Could not find INLA binary in extracted files at {src_dir}"
            )

        # Skip archive files that may be present when src_dir is tmpdir
        _archive_exts = {".tgz", ".tar.gz", ".zip", ".gz"}

        binary_path.parent.mkdir(parents=True, exist_ok=True)

        for item in src_dir.iterdir():
            if item.is_file():
                if any(item.name.endswith(ext) for ext in _archive_exts):
                    continue
                dst = binary_path.parent / item.name
                # Remove existing file or dangling symlink before copying
                if dst.exists() or dst.is_symlink():
                    dst.unlink()
                shutil.copy2(item, dst)
                if platform_name != "windows":
                    dst.chmod(0o755)
            elif item.is_dir():
                dst_dir = binary_path.parent / item.name
                if dst_dir.exists() or dst_dir.is_symlink():
                    if dst_dir.is_symlink():
                        dst_dir.unlink()
                    else:
                        shutil.rmtree(dst_dir)
                shutil.copytree(item, dst_dir)

        # Linux: ensure inla.mkl exists (the .run wrapper expects it)
        if platform_name == "linux":
            inla_mkl = binary_path.parent / "inla.mkl"
            inla_plain = binary_path.parent / "inla"
            if not inla_mkl.exists() and inla_plain.exists():
                inla_mkl.symlink_to(inla_plain.name)

        installed_count = sum(
            1 for item in src_dir.iterdir()
            if not any(item.name.endswith(ext) for ext in _archive_exts)
        )
        print(f"Installed {installed_count} files to: {binary_path.parent}")

    def _verify_architecture(self, binary_path: Path, platform_key: str) -> None:
        """Verify that the downloaded binary matches the expected architecture.

        Reads the ELF/PE file header to check architecture. Falls back to
        the 'file' command on Unix systems.
        """
        bin_dir = binary_path.parent
        if platform_key.startswith("linux_"):
            actual_binary = bin_dir / "inla.mkl"
            if not actual_binary.exists():
                actual_binary = bin_dir / "inla"
        elif platform_key.startswith("windows_"):
            actual_binary = binary_path
        else:
            actual_binary = binary_path

        if not actual_binary.exists() or actual_binary.is_symlink():
            # Resolve symlink
            resolved = actual_binary.resolve()
            if not resolved.exists():
                return
            actual_binary = resolved

        try:
            with open(actual_binary, 'rb') as f:
                magic = f.read(4)

                # ELF binary (Linux)
                if magic == b'\x7fELF':
                    f.seek(18)  # e_machine offset
                    e_machine = struct.unpack('<H', f.read(2))[0]
                    # 0x3E = x86_64, 0xB7 = aarch64
                    if e_machine == 0xB7 and "x86_64" in platform_key:
                        raise RuntimeError(
                            f"Architecture mismatch: downloaded aarch64 binary "
                            f"but expected x86_64 for platform '{platform_key}'"
                        )
                    if e_machine == 0x3E and "aarch64" in platform_key:
                        raise RuntimeError(
                            f"Architecture mismatch: downloaded x86_64 binary "
                            f"but expected aarch64 for platform '{platform_key}'"
                        )
                    return

                # PE binary (Windows)
                if magic[:2] == b'MZ':
                    f.seek(0x3C)
                    pe_offset = struct.unpack('<I', f.read(4))[0]
                    f.seek(pe_offset + 4)
                    machine = struct.unpack('<H', f.read(2))[0]
                    if machine != 0x8664 and "x86_64" in platform_key:
                        raise RuntimeError(
                            f"Architecture mismatch: binary machine type "
                            f"0x{machine:04x} does not match expected x86_64"
                        )
                    return

            # Fallback: 'file' command on Unix
            if platform.system().lower() != "windows":
                result = subprocess.run(
                    ["file", str(actual_binary)],
                    capture_output=True, text=True, timeout=5
                )
                if result.returncode == 0:
                    output = result.stdout.lower()
                    if ("aarch64" in output or "arm64" in output) \
                            and "x86_64" in platform_key:
                        raise RuntimeError(
                            f"Architecture mismatch: binary is aarch64/arm64 "
                            f"but platform expects {platform_key}"
                        )
                    if ("x86-64" in output or "x86_64" in output) \
                            and "aarch64" in platform_key:
                        raise RuntimeError(
                            f"Architecture mismatch: binary is x86_64 "
                            f"but platform expects {platform_key}"
                        )

        except RuntimeError:
            raise
        except Exception:
            pass  # Non-fatal: if verification fails, proceed anyway

    def _detect_bits(self) -> str:
        """Detect if 32 or 64-bit Python."""
        return "64" if sys.maxsize > 2**32 else "32"

    def _detect_linux_distro(self) -> Optional[str]:
        """Detect Linux distribution from /etc/os-release.

        Returns:
            A string like "Ubuntu-24.04" or None if detection fails.
        """
        try:
            os_release = Path("/etc/os-release")
            if not os_release.exists():
                return None

            info = {}
            for line in os_release.read_text().splitlines():
                if "=" in line:
                    key, _, value = line.partition("=")
                    info[key.strip()] = value.strip().strip('"')

            name = info.get("NAME", "")
            version_id = info.get("VERSION_ID", "")

            if name and version_id:
                # Build something like "Ubuntu-24.04" or "Fedora-43"
                # Strip "Linux" from names like "Rocky Linux" and collapse whitespace
                clean_name = " ".join(name.replace("Linux", "").split())
                return f"{clean_name}-{version_id}".replace(" ", "-")
            return None
        except Exception:
            return None

    def _match_distro_key(self, entry: dict) -> Optional[dict]:
        """Match current Linux distro against distro-specific entries in manifest.

        Reads /etc/os-release to determine the distro, then looks up a
        matching key in entry["distros"]. Returns the distro sub-entry
        (with url and version) if matched, or None to use the default.
        """
        distros = entry.get("distros")
        if not distros:
            return None

        detected = self._detect_linux_distro()
        if not detected:
            return None

        detected_lower = detected.lower()

        # Try matching against distro keys
        # distro keys are like: ubuntu_22, ubuntu_24, ubuntu_25, fedora, rocky_9, rocky_10
        best_match = None
        best_specificity = 0

        for key, sub_entry in distros.items():
            # Convert key "ubuntu_22" to match pattern "ubuntu" + "22"
            parts = key.split("_", 1)
            distro_name = parts[0]  # "ubuntu", "fedora", "rocky"
            distro_ver = parts[1] if len(parts) > 1 else ""  # "22", "9", ""

            # Check if the detected distro matches the name
            if distro_name not in detected_lower:
                continue

            # Name matches, check version specificity
            # Use word-boundary match to avoid "9" matching "19" or "29"
            if distro_ver and re.search(r'(?<![0-9])' + re.escape(distro_ver) + r'(?![0-9])', detected_lower):
                # Both name and version match (e.g., "ubuntu" + "24" in "ubuntu-24.04")
                specificity = len(distro_name) + len(distro_ver)
                if specificity > best_specificity:
                    best_match = sub_entry
                    best_specificity = specificity
            elif not distro_ver:
                # Name-only match (e.g., "fedora" matches any Fedora)
                specificity = len(distro_name)
                if specificity > best_specificity:
                    best_match = sub_entry
                    best_specificity = specificity
            elif best_match is None:
                # Name matches but version does not, use as weak fallback
                best_match = sub_entry
                best_specificity = 1

        if best_match:
            print(f"Detected distro: {detected}, matched: {best_match.get('version', 'default')}")

        return best_match

    def detect_platform(self) -> str:
        """Detect current platform."""
        system = platform.system().lower()

        if system == "linux":
            return "linux"
        elif system == "darwin":
            machine = platform.machine().lower()
            if "arm" in machine or "aarch64" in machine:
                return "mac.arm64"
            else:
                return "mac"
        elif system == "windows":
            return "windows"
        else:
            raise RuntimeError(f"Unsupported platform: {system}")

    def get_binary_path(self, platform_name: Optional[str] = None) -> Path:
        """Get path where binary should be installed.

        This must match the paths expected by inla_call.py:
        - Linux: bin/linux/64bit/inla.mkl.run
        - Mac Intel: bin/mac/64bit/inla.run
        - Mac ARM: bin/mac.arm64/inla.run
        - Windows: bin/windows/64bit/inla.exe
        """
        if platform_name is None:
            platform_name = self.detect_platform()

        if platform_name == "linux":
            bits = self._detect_bits()
            return self.bin_dir / "linux" / f"{bits}bit" / "inla.mkl.run"
        elif platform_name == "mac":
            bits = self._detect_bits()
            return self.bin_dir / "mac" / f"{bits}bit" / "inla.run"
        elif platform_name == "mac.arm64":
            return self.bin_dir / "mac.arm64" / "inla.run"
        elif platform_name == "windows":
            bits = self._detect_bits()
            return self.bin_dir / "windows" / f"{bits}bit" / "inla.exe"
        else:
            raise ValueError(f"Unknown platform: {platform_name}")

    def is_installed(self, platform_name: Optional[str] = None) -> bool:
        """Check if binary is already installed."""
        if platform_name is None:
            platform_name = self.detect_platform()

        binary_path = self.get_binary_path(platform_name)
        if not (binary_path.exists() and binary_path.is_file()):
            return False

        # On Linux, the wrapper (.run) needs the actual binary too
        if platform_name == "linux":
            bin_dir = binary_path.parent
            has_binary = (bin_dir / "inla.mkl").exists() or (bin_dir / "inla").exists()
            return has_binary

        return True

    def _download_file(self, url: str, dest: Path, desc: str = "Downloading") -> None:
        """Download a file with progress display."""
        print(f"{desc}: {url}")

        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "pyINLA/0.1 (https://pyinla.org)"
            })
            with urllib.request.urlopen(req, timeout=60) as response:
                total_size = int(response.headers.get('content-length', 0))
                downloaded = 0
                chunk_size = 8192

                with open(dest, 'wb') as f:
                    while True:
                        chunk = response.read(chunk_size)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)

                        if total_size > 0:
                            percent = (downloaded / total_size) * 100
                            mb_down = downloaded / (1024 * 1024)
                            mb_total = total_size / (1024 * 1024)
                            print(f"\rProgress: {percent:.1f}% ({mb_down:.1f}/{mb_total:.1f} MB)", end='', flush=True)

                print()  # New line after progress

        except Exception as e:
            if dest.exists():
                dest.unlink()
            raise RuntimeError(f"Download failed: {e}")

    def download_from_url(self, url: str, force: bool = False) -> Path:
        """Download and install an INLA binary from a direct URL.

        Use this when you have a specific download link, for example from
        list_remote_binaries() or the R-INLA server.

        Args:
            url: Direct download URL to a .tgz or .zip binary archive.
            force: Force re-download even if binary already exists.

        Returns:
            Path to installed binary.
        """
        if url.startswith("http://"):
            import warnings
            warnings.warn(
                "Downloading binary over plain HTTP (not HTTPS). "
                "Consider using an https:// URL for secure downloads.",
                stacklevel=2,
            )

        platform_name = self.detect_platform()
        binary_path = self.get_binary_path(platform_name)
        pkey = self._platform_key()

        if not force and self.is_installed(platform_name):
            print(f"INLA binary already installed at: {binary_path}")
            print("Use force=True to re-download.")
            return binary_path

        # Detect archive format from URL
        if url.endswith(".zip"):
            archive_format = "zip"
        else:
            archive_format = "tgz"

        # Try to extract version from URL (e.g. "Version_26.02.06" or "v26.02.06")
        version = "unknown"
        ver_match = re.search(r'Version_([0-9][0-9.a-z-]+)', url)
        if ver_match:
            version = ver_match.group(1)
        else:
            ver_match = re.search(r'v([0-9][0-9.]+)', url)
            if ver_match:
                version = ver_match.group(1)

        print(f"Platform: {pkey}")
        print(f"URL: {url}")

        with tempfile.TemporaryDirectory() as tmpdir:
            ext = "zip" if archive_format == "zip" else "tgz"
            archive_path = Path(tmpdir) / f"binary.{ext}"

            self._download_file(url, archive_path, "Downloading binary")

            # Extract
            print("Extracting...")
            self._safe_extract(archive_path, tmpdir, archive_format)

            # Find the extracted binary directory
            extracted_dir = self._find_extracted_dir(
                Path(tmpdir), platform_name, pkey
            )

            # Install files
            self._install_extracted_files(
                extracted_dir, binary_path, platform_name
            )

        # Ensure entry-point binary exists
        self._ensure_binary_entry_point(binary_path.parent, platform_name)

        # Post-download architecture verification
        self._verify_architecture(binary_path, pkey)

        # Save version info
        self._save_version(binary_path, version, pkey, url)

        print(f"Installed INLA binary to: {binary_path}")
        return binary_path

    def download_binary(self, force: bool = False) -> Path:
        """Download INLA binary for the current platform.

        Uses the JSON manifest to select the correct binary for this
        platform and architecture. Downloads from download.pyinla.org.

        Args:
            force: Force re-download even if binary already exists.

        Returns:
            Path to installed binary.
        """
        return self.download_from_manifest(force=force)

    def link_binary(self, path: str, force: bool = False) -> Path:
        """Link an existing INLA binary from the local system.

        Instead of downloading, this points pyINLA at a binary that already
        exists on disk (e.g. installed by R-INLA or built from source).

        The path can be:
        - A directory containing INLA binaries (e.g. /opt/R/inla/bin/linux/64bit/)
        - A parent directory with a 64bit/ subdirectory
        - A specific binary file (e.g. /usr/local/bin/inla)

        Creates symlinks from pyINLA's expected bin/ layout to the target.

        Args:
            path: Path to a binary file or directory containing binaries.
            force: Overwrite existing binary if already installed.

        Returns:
            Path to the linked binary (pyINLA's internal path).
        """
        source = Path(path).resolve()
        if not source.exists():
            raise FileNotFoundError(f"Path does not exist: {source}")

        platform_name = self.detect_platform()
        binary_path = self.get_binary_path(platform_name)
        pkey = self._platform_key()

        if not force and self.is_installed(platform_name):
            print(f"INLA binary already installed at: {binary_path}")
            print("Use force=True to overwrite.")
            return binary_path

        # Determine what we're linking to
        if source.is_file():
            src_dir = source.parent
        elif source.is_dir():
            src_dir = self._resolve_binary_dir(source, platform_name)
        else:
            raise ValueError(f"Path is not a file or directory: {source}")

        # Validate it has an INLA binary
        src_binary = self._find_binary_in_dir(src_dir, platform_name)
        if not src_binary.exists():
            raise FileNotFoundError(f"Binary not found: {src_binary}")

        print(f"Platform: {pkey}")
        print(f"Source: {src_dir}")

        # Create target directory
        target_dir = binary_path.parent
        target_dir.mkdir(parents=True, exist_ok=True)

        # Clear existing files in target
        if force and target_dir.exists():
            for item in target_dir.iterdir():
                if item.is_symlink() or item.is_file():
                    item.unlink()
                elif item.is_dir():
                    shutil.rmtree(item)

        # Link (or copy on Windows) all files and directories from source
        use_symlinks = platform.system().lower() != "windows"
        linked = 0
        for item in src_dir.iterdir():
            dst = target_dir / item.name
            if dst.exists() or dst.is_symlink():
                if dst.is_symlink() or dst.is_file():
                    dst.unlink()
                elif dst.is_dir():
                    shutil.rmtree(dst)

            if use_symlinks:
                dst.symlink_to(item.resolve())
            elif item.is_dir():
                shutil.copytree(item, dst)
            else:
                shutil.copy2(item, dst)
            linked += 1

        # Ensure the expected entry-point binary exists for this platform
        self._ensure_binary_entry_point(target_dir, platform_name)

        # Verify architecture
        self._verify_architecture(binary_path, pkey)

        # Save version info
        self._save_version(binary_path, "linked", pkey, str(source))

        verb = "Linked" if use_symlinks else "Copied"
        print(f"{verb} {linked} files from: {src_dir}")
        print(f"Binary available at: {binary_path}")
        return binary_path

    def _resolve_binary_dir(self, directory: Path, platform_name: str) -> Path:
        """Find the directory containing binaries, checking subdirs like 64bit/.

        If the given directory directly contains binaries, returns it.
        Otherwise looks for a 64bit/ (or 32bit/) subdirectory.
        """
        # Check if binaries are directly in this directory
        try:
            self._find_binary_in_dir(directory, platform_name)
            return directory
        except FileNotFoundError:
            pass

        # Check <bits>bit/ subdirectory (e.g. 64bit/)
        bits_dir = directory / f"{self._detect_bits()}bit"
        if bits_dir.exists():
            try:
                self._find_binary_in_dir(bits_dir, platform_name)
                return bits_dir
            except FileNotFoundError:
                pass

        raise FileNotFoundError(
            f"No INLA binary found in {directory} or {directory}/{self._detect_bits()}bit/. "
            f"Please point to the directory containing the INLA binary files."
        )

    def _ensure_binary_entry_point(self, target_dir: Path, platform_name: str) -> None:
        """Ensure the entry-point binary that call.py expects exists.

        Creates symlinks as fallbacks when the expected wrapper is missing:
        - Linux: call.py looks for inla.mkl.run
        - Mac: call.py looks for inla.run
        - Windows: call.py looks for inla.exe
        """
        if platform_name == "linux":
            # call.py expects inla.mkl.run
            mkl_run = target_dir / "inla.mkl.run"
            if not mkl_run.exists():
                for fallback in ["inla.run", "inla"]:
                    src = target_dir / fallback
                    if src.exists():
                        mkl_run.symlink_to(fallback)
                        break

            # The .run wrapper typically calls inla.mkl
            inla_mkl = target_dir / "inla.mkl"
            if not inla_mkl.exists():
                inla_plain = target_dir / "inla"
                if inla_plain.exists():
                    inla_mkl.symlink_to("inla")

        elif platform_name in ("mac", "mac.arm64"):
            # call.py expects inla.run
            inla_run = target_dir / "inla.run"
            if not inla_run.exists():
                inla_plain = target_dir / "inla"
                if inla_plain.exists():
                    inla_run.symlink_to("inla")

        # Windows: call.py expects inla.exe, no wrapper to create

    def _find_binary_in_dir(self, directory: Path, platform_name: str) -> Path:
        """Find the main INLA binary inside a directory."""
        if platform_name == "linux":
            candidates = ["inla.mkl.run", "inla.mkl", "inla.run", "inla"]
        elif platform_name == "windows":
            candidates = ["inla.exe"]
        else:
            candidates = ["inla.run", "inla"]

        for name in candidates:
            p = directory / name
            if p.exists():
                return p

        raise FileNotFoundError(
            f"No INLA binary found in {directory}. "
            f"Expected one of: {', '.join(candidates)}"
        )

    def remove_binary(self, platform_name: Optional[str] = None) -> None:
        """Remove installed binary (or unlink a linked binary)."""
        if platform_name is None:
            platform_name = self.detect_platform()

        binary_path = self.get_binary_path(platform_name)

        if binary_path.exists() or binary_path.is_symlink():
            # Remove all files/symlinks in the binary directory
            bin_dir = binary_path.parent
            removed = 0
            for item in bin_dir.iterdir():
                if item.is_symlink() or item.is_file():
                    item.unlink()
                    removed += 1
                elif item.is_dir():
                    shutil.rmtree(item)
                    removed += 1
            print(f"Removed {removed} files from: {bin_dir}")
        else:
            print(f"No binary found at: {binary_path}")


# Global instance
_manager = BinaryManager()


def download_binary(force: bool = False) -> Path:
    """Download INLA binary for the current platform.

    Automatically detects your OS and architecture, then downloads the
    correct binary from download.pyinla.org.

    Args:
        force: Force re-download even if binary already exists.

    Returns:
        Path to installed binary.

    Example:
        >>> from pyinla import download_binary
        >>> download_binary()        # Auto-detect platform
        >>> download_binary(force=True)  # Force re-download
    """
    return _manager.download_binary(force=force)


def download_binary_from_url(url: str, force: bool = False) -> Path:
    """Download and install an INLA binary from a direct URL.

    Use this when you have a specific download link, for example from
    list_remote_binaries() or the R-INLA server.

    Args:
        url: Direct download URL to a .tgz or .zip binary archive.
        force: Force re-download even if binary already exists.

    Returns:
        Path to installed binary.

    Example:
        >>> from pyinla.binary import list_remote_binaries, download_binary_from_url
        >>> rows = list_remote_binaries("ubuntu")
        >>> download_binary_from_url(rows[-1]["url"])
    """
    return _manager.download_from_url(url, force=force)


def link_binary(path: str, force: bool = False) -> Path:
    """Link an existing INLA binary from the local system.

    Instead of downloading, this points pyINLA at a binary that already
    exists on disk (e.g. installed by R-INLA or built from source).

    Args:
        path: Path to a binary file or a directory containing INLA binaries.
            For example: "/opt/R/inla/bin/linux/64bit/" or "/usr/local/bin/inla"
        force: Overwrite existing binary if already linked/installed.

    Returns:
        Path to the linked binary (pyINLA's internal path).

    Example:
        >>> from pyinla.binary import link_binary
        >>> link_binary("/opt/R/x86_64-pc-linux-gnu-library/4.3/INLA/bin/linux/64bit")
        >>> link_binary("/usr/local/bin/inla")
    """
    return _manager.link_binary(path, force=force)


def list_available_binaries() -> Dict[str, dict]:
    """List all available binaries from the manifest.

    Returns:
        Dict mapping platform keys to their manifest entries
        (url, version, format).

    Example:
        >>> from pyinla import list_available_binaries
        >>> binaries = list_available_binaries()
        >>> for platform, info in binaries.items():
        ...     print(f"{platform}: v{info['version']}")
    """
    manifest = _manager._load_manifest()
    return manifest.get("binaries", {})


def list_remote_binaries(os_filter: str = None) -> List[Dict[str, str]]:
    """Fetch and parse the R-INLA server listings for all platforms.

    Scrapes the FILES index from inla.r-inla-download.org for Linux, Mac,
    and Windows builds, then returns a list of dicts with distro, arch,
    and version columns.

    Args:
        os_filter: Optional filter string (e.g. "ubuntu", "fedora", "mac").
            Case-insensitive. If None, returns all entries.

    Returns:
        List of dicts, each with keys: "os", "distro", "arch", "version", "url".

    Example:
        >>> from pyinla.binary import list_remote_binaries
        >>> rows = list_remote_binaries("ubuntu")
        >>> for r in rows[-5:]:
        ...     print(f"{r['distro']:45s} {r['arch']:10s} {r['version']}")
    """
    base = "https://inla.r-inla-download.org"
    sources = [
        ("linux", f"{base}/Linux-builds/FILES", f"{base}/Linux-builds"),
        ("mac", f"{base}/Mac-builds/FILES", f"{base}/Mac-builds"),
        ("windows", f"{base}/Windows-builds/FILES", f"{base}/Windows-builds"),
    ]

    rows: List[Dict[str, str]] = []

    for os_name, url, base_url in sources:
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "pyINLA/0.1 (https://pyinla.org)"
            })
            with urllib.request.urlopen(req, timeout=30) as resp:
                text = resp.read().decode("utf-8", errors="replace")
        except Exception as e:
            print(f"Warning: could not fetch {url}: {e}")
            continue

        for line in text.splitlines():
            line = line.strip()
            if not line or not line.startswith("./"):
                continue

            # Build download URL from relative path (URL-encode spaces etc.)
            rel_path = line[2:]  # strip leading ./
            download_url = base_url + "/" + urllib.request.quote(rel_path)

            # Remove leading ./
            parts = rel_path.split("/")

            if len(parts) < 2:
                continue

            # Skip meta-files like FILES, HOWTO
            if parts[0] in ("FILES", "HOWTO"):
                continue

            distro_raw = parts[0]
            version_raw = parts[1] if len(parts) > 1 else ""

            # --- Parse architecture from distro string ---
            arch = ""
            distro = distro_raw

            # Check for [arch] at end: "Ubuntu-25.04 (Plucky Puffin) [x86_64]"
            bracket_match = re.search(r'\s*\[(\w+)\]\s*$', distro_raw)
            if bracket_match:
                arch = bracket_match.group(1)
                distro = distro_raw[:bracket_match.start()].strip()
            else:
                # Check for bare arch at end: "Ubuntu-25.04 (Plucky Puffin) x86_64"
                bare_match = re.search(r'\s+(x86_64|aarch64|arm64)\s*$', distro_raw)
                if bare_match:
                    arch = bare_match.group(1)
                    distro = distro_raw[:bare_match.start()].strip()

            # Defaults for entries without explicit arch
            if not arch:
                if os_name == "linux":
                    arch = "x86_64"
                elif os_name == "mac":
                    if "arm64" in distro_raw.lower():
                        arch = "arm64"
                    elif "x86_64" in distro_raw.lower():
                        arch = "x86_64"
                    else:
                        arch = "unknown"
                elif os_name == "windows":
                    arch = "x86_64"

            # Mac distro cleanup: "Mac-26.2--arm64" -> "macOS 26.2"
            if os_name == "mac":
                mac_match = re.match(r'Mac-([0-9.]+)--(\w+)', distro_raw)
                if mac_match:
                    distro = f"macOS {mac_match.group(1)}"
                    arch = mac_match.group(2)

            # Windows: "windows64" -> "Windows"
            if os_name == "windows":
                if distro_raw.startswith("windows"):
                    distro = "Windows"

            # --- Parse version ---
            version = version_raw
            if version.startswith("Version_"):
                version = version[len("Version_"):]
            elif version == "devel":
                version = "devel"

            rows.append({
                "os": os_name,
                "distro": distro,
                "arch": arch,
                "version": version,
                "url": download_url,
            })

    # Apply filter
    if os_filter:
        f = os_filter.lower()
        rows = [r for r in rows if f in r["distro"].lower() or f in r["os"].lower()]

    # Sort by os, distro, version
    rows.sort(key=lambda r: (r["os"], r["distro"], r["version"]))
    return rows


def print_remote_binaries(os_filter: str = None, latest_only: bool = False) -> None:
    """Fetch and print available R-INLA binaries in a table.

    Args:
        os_filter: Optional filter (e.g. "ubuntu", "fedora", "mac", "windows").
        latest_only: If True, only show the latest version per distro+arch.

    Example:
        >>> from pyinla.binary import print_remote_binaries
        >>> print_remote_binaries("ubuntu", latest_only=True)
    """
    rows = list_remote_binaries(os_filter=os_filter)
    if not rows:
        print("No binaries found.")
        return

    if latest_only:
        # Keep only the last version for each (distro, arch) pair
        seen: Dict[tuple, dict] = {}
        for r in rows:
            key = (r["distro"], r["arch"])
            seen[key] = r  # rows are sorted, so last one is latest
        rows = sorted(seen.values(), key=lambda r: (r["os"], r["distro"], r["version"]))

    # Column widths
    w_distro = max(len(r["distro"]) for r in rows)
    w_arch = max(len(r["arch"]) for r in rows)
    w_ver = max(len(r["version"]) for r in rows)

    w_distro = max(w_distro, 6)  # "Distro"
    w_arch = max(w_arch, 4)      # "Arch"
    w_ver = max(w_ver, 7)        # "Version"

    header = f"{'Distro':<{w_distro}}  {'Arch':<{w_arch}}  {'Version':<{w_ver}}  URL"
    separator = f"{'-' * w_distro}  {'-' * w_arch}  {'-' * w_ver}  {'-' * 3}"

    print(header)
    print(separator)
    for r in rows:
        print(f"{r['distro']:<{w_distro}}  {r['arch']:<{w_arch}}  {r['version']:<{w_ver}}  {r['url']}")

    print(f"\nTotal: {len(rows)} entries")


def is_binary_installed(platform: Optional[str] = None) -> bool:
    """Check if binary is installed for current or specified platform."""
    return _manager.is_installed(platform_name=platform)


def get_binary_version(platform: Optional[str] = None) -> Optional[dict]:
    """Get the installed INLA binary version info.

    Returns:
        Dict with keys: version, platform, url, installed (date string),
        or None if no version info found.

    Example:
        >>> from pyinla.binary import get_binary_version
        >>> info = get_binary_version()
        >>> print(info)
        {'version': '25.12.16', 'platform': 'linux_x86_64', 'url': '...', 'installed': '2026-02-15 14:30:00'}
    """
    return _manager.get_installed_version(platform_name=platform)


def ensure_binary() -> Path:
    """Ensure binary is installed, download if missing.

    This is called automatically on first use of pyinla.

    Returns:
        Path to binary.
    """
    if not _manager.is_installed():
        print("INLA binary not found. Downloading...")
        return _manager.download_binary()
    return _manager.get_binary_path()


def _cli_install():
    """CLI entry point for installing INLA binary.

    Run after pip install:
        pyinla-install
        pyinla-install --force
        pyinla-install --info
    """
    import argparse

    parser = argparse.ArgumentParser(
        description="Download and install INLA binary for pyINLA",
        prog="pyinla-install"
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Force re-download even if binary exists"
    )
    parser.add_argument(
        "--info",
        action="store_true",
        help="Show installed binary version and available platforms"
    )
    parser.add_argument(
        "--remote",
        nargs="?",
        const="",
        default=None,
        metavar="FILTER",
        help="List binaries available on the R-INLA server. Optional filter: ubuntu, fedora, rocky, mac, windows"
    )
    parser.add_argument(
        "--latest",
        action="store_true",
        help="With --remote, show only the latest version per distro"
    )
    parser.add_argument(
        "--url",
        metavar="URL",
        help="Download and install a binary from a direct URL"
    )
    parser.add_argument(
        "--link",
        metavar="PATH",
        help="Link an existing local INLA binary instead of downloading"
    )

    args = parser.parse_args()

    if args.link:
        try:
            path = link_binary(args.link, force=args.force)
            print(f"\nSuccess! Binary linked at: {path}")
        except Exception as e:
            print(f"\nError: {e}")
            sys.exit(1)
        return

    if args.url:
        try:
            path = download_binary_from_url(args.url, force=args.force)
            print(f"\nSuccess! Binary installed at: {path}")
        except Exception as e:
            print(f"\nError: {e}")
            sys.exit(1)
        return

    if args.remote is not None:
        os_filter = args.remote if args.remote else None
        print_remote_binaries(os_filter=os_filter, latest_only=args.latest)
        return

    if args.info:
        pkey = _manager._platform_key()
        print(f"Platform: {pkey}")

        # Show installed version
        version_info = _manager.get_installed_version()
        if version_info:
            print(f"Installed: v{version_info['version']} ({version_info['installed']})")
            print(f"Source: {version_info['url']}")
        else:
            print("Installed: not yet")

        # Show manifest info
        try:
            manifest = _manager._load_manifest()
            binaries = manifest.get("binaries", {})
            print(f"\nAvailable binaries ({manifest.get('_cdn', '')}):")
            for key, entry in binaries.items():
                marker = " <-- current" if key == pkey else ""
                print(f"  {key}: v{entry['version']}{marker}")
                if key.startswith("linux_") and "distros" in entry:
                    for dk, dv in entry["distros"].items():
                        print(f"    {dk}: v{dv['version']}")
        except FileNotFoundError:
            print("\nManifest file not found. Package may need reinstalling.")
        return

    try:
        path = download_binary(force=args.force)
        print(f"\nSuccess! Binary installed at: {path}")
        print("\nYou can now use pyINLA:")
        print("  import pyinla")
    except Exception as e:
        print(f"\nError: {e}")
        sys.exit(1)
