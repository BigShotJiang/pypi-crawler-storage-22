"""Core wrapper functions for R's fmesher package using rpy2.

This module provides Python wrappers for R's fmesher package functions,
primarily for creating constrained Delaunay triangulations (fm_mesh_2d),
computing finite element matrices (fm_fem), and projecting mesh values
onto regular grids (fm_evaluator / fm_evaluate).

Architecture
------------
All mesh computation is performed by R's fmesher C++ backend. This module
acts purely as a translation layer:

    Python (numpy/scipy)  -->  rpy2  -->  R fmesher  -->  C++ (fmesher_rcdt)

The workflow for each function is:
    1. Convert Python arguments (numpy arrays, floats) to R objects
       (R matrices, FloatVector, IntVector) using the conversion utilities.
    2. Call the corresponding R function via rpy2.
    3. Convert the R result back to Python objects (numpy arrays,
       scipy sparse matrices, dataclass instances).

No mesh computation, triangulation, or FEM logic is implemented here.

Dependencies
------------
- rpy2: Python-to-R bridge (required for all functions in this module).
- R's fmesher package: provides fm_mesh_2d, fm_fem, fm_evaluator, etc.
- R's sf package: required only for fm_nonconvex_hull and fm_hexagon_lattice.

R Object Lifetime
-----------------
R mesh objects are stored in R's global environment (via _store_r_mesh)
to prevent premature garbage collection by R. This is necessary because
rpy2 uses weak references that can become invalid if R collects the object.
The stored mesh ID is kept in the Python FmMesh._r_mesh field so that
subsequent calls (e.g., fm_evaluator) can retrieve the original R object.

Call cleanup_all_meshes() periodically in long-running sessions to free
R memory, or _cleanup_r_mesh(mesh._r_mesh) to free a specific mesh.

Platform Notes
--------------
- Linux: best supported. rpy2 and R work out of the box.
- macOS: ensure R and Python use the same architecture (arm64 or x86_64).
- Windows: set R_HOME environment variable and add R's bin directory to PATH.

Functions
---------
Public API:
    fm_mesh_2d          Create a 2D triangular mesh.
    fm_segm             Create a mesh boundary or interior segment.
    fm_nonconvex_hull   Create a non-convex hull boundary (requires sf).
    fm_hexagon_lattice  Generate a hexagonal point lattice (requires sf).
    fm_fem              Compute FEM mass and stiffness matrices from a mesh.
    fm_evaluator        Create a projector from mesh vertices to a regular grid.
    fm_evaluate         Project mesh vertex values onto a grid using the projector.
    get_utm_crs         Determine the appropriate UTM CRS for a location.
    check_fmesher_available  Check whether rpy2 and fmesher are available.
    cleanup_all_meshes  Free all stored R mesh objects from memory.

Internal:
    _store_r_mesh       Store an R mesh in R's global environment.
    _get_stored_r_mesh  Retrieve a stored R mesh by ID.
    _cleanup_r_mesh     Remove a stored R mesh by ID.
    _check_rpy2         Raise if rpy2 is not installed (with platform hints).
    _get_fmesher        Lazily import and cache the fmesher R package.
    _numpy_to_r_matrix  Convert a numpy array to an R matrix.
    _r_matrix_to_numpy  Convert an R matrix to a numpy array.
    _segment_to_r       Convert a Python FmSegment to an R fm_segm object.
    _r_segment_to_python  Convert an R segment to a Python FmSegment.
    _r_mesh_to_fm_mesh  Convert an R fm_mesh_2d result to a Python FmMesh.
    _r_sparse_to_scipy  Convert an R sparse matrix to a scipy sparse matrix.
    _make_closed_indices  Create closed polygon index pairs from n vertices.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Tuple, Union
import warnings

import numpy as np
from scipy import sparse

from .mesh import FmMesh, FmSegment, FmFEM, FmEvaluator
from .exceptions import FmesherNotAvailableError, Rpy2NotAvailableError

# Global flag for rpy2 availability
_HAS_RPY2 = False
_RPY2_ERROR: Optional[str] = None

try:
    import rpy2.robjects as ro
    from rpy2.robjects.packages import importr
    from rpy2.robjects.vectors import FloatVector, IntVector, ListVector, Matrix
    from rpy2.rinterface_lib.embedded import RRuntimeError

    _HAS_RPY2 = True
except ImportError as e:
    _RPY2_ERROR = str(e)

# Global reference to the fmesher R package
_fmesher_r: Optional[Any] = None

# Global counter for unique mesh IDs
_mesh_id_counter: int = 0


def _store_r_mesh(r_mesh: Any) -> str:
    """Store an R mesh object in R's global environment and return a unique ID.

    rpy2 holds R objects via weak references. When the Python-side reference
    goes out of scope, R may garbage-collect the underlying object, causing
    segfaults or "RObject not found" errors on later access. To prevent this,
    we assign the mesh to a named variable in R's global environment
    (e.g., .pyinla_mesh_0, .pyinla_mesh_1, ...) which acts as a strong
    reference that keeps the R object alive.

    The returned ID string is stored in FmMesh._r_mesh so that subsequent
    functions (fm_evaluator, fm_fem) can retrieve the original R object
    via _get_stored_r_mesh() instead of reconstructing it from Python data.

    Parameters
    ----------
    r_mesh : rpy2 R object
        The R fm_mesh_2d object to store.

    Returns
    -------
    str
        A unique ID string (e.g., ".pyinla_mesh_3") that can be used
        to retrieve the object from R's global environment.
    """
    global _mesh_id_counter
    mesh_id = f".pyinla_mesh_{_mesh_id_counter}"
    _mesh_id_counter += 1
    ro.globalenv[mesh_id] = r_mesh
    return mesh_id


def _get_stored_r_mesh(mesh_id: str) -> Optional[Any]:
    """Retrieve a previously stored R mesh object by its ID.

    Looks up the R object in R's global environment using the ID returned
    by _store_r_mesh(). Returns None if the object is no longer available
    (e.g., if the R environment was cleared).

    Parameters
    ----------
    mesh_id : str
        The ID string returned by _store_r_mesh().

    Returns
    -------
    rpy2 R object or None
        The stored R fm_mesh_2d object, or None if not found.
    """
    try:
        return ro.globalenv[mesh_id]
    except Exception:
        return None


def _cleanup_r_mesh(mesh_id: str) -> bool:
    """Remove a stored R mesh from R's global environment to free memory.

    Parameters
    ----------
    mesh_id : str
        The ID returned by _store_r_mesh().

    Returns
    -------
    bool
        True if the mesh was found and removed, False otherwise.
    """
    if not _HAS_RPY2:
        return False
    try:
        if mesh_id in list(ro.globalenv.keys()):
            ro.r(f'rm("{mesh_id}", envir=.GlobalEnv)')
            return True
    except Exception:
        pass
    return False


def cleanup_all_meshes() -> int:
    """Remove all stored pyinla meshes and temporaries from R's global environment.

    Call this periodically in long-running sessions to free R memory.
    Each call to fm_mesh_2d stores the R mesh object in R's global
    environment to prevent garbage collection. Over many mesh
    creations, this accumulates memory.

    Returns
    -------
    int
        Number of R objects removed.

    Examples
    --------
    >>> from pyinla.fmesher import cleanup_all_meshes
    >>> n = cleanup_all_meshes()
    >>> print(f"Freed {n} stored R objects")
    """
    if not _HAS_RPY2:
        return 0

    count = 0
    try:
        keys = list(ro.globalenv.keys())
        for key in keys:
            if key.startswith(".pyinla_"):
                ro.r(f'rm("{key}", envir=.GlobalEnv)')
                count += 1
    except Exception:
        pass
    return count


def _check_rpy2() -> None:
    """Raise Rpy2NotAvailableError if rpy2 was not successfully imported.

    Called at the start of every function that needs R. The import is
    attempted once at module load time (see the try/except block at the
    top of this file). If it failed, _HAS_RPY2 is False and the original
    import error message is stored in _RPY2_ERROR.

    Includes platform-specific hints for common installation issues:
      - Windows: R_HOME environment variable and PATH setup.
      - macOS: architecture mismatch (arm64 vs x86_64) between R and Python.
    """
    if not _HAS_RPY2:
        import sys

        lines = [
            "rpy2 is not installed or failed to load.",
            f"Install with: pip install rpy2",
            f"Original error: {_RPY2_ERROR}",
        ]

        if sys.platform == "win32":
            import os

            r_home = os.environ.get("R_HOME", "")
            if not r_home:
                lines.append(
                    "\nWindows: R_HOME environment variable is not set. "
                    "Set it to your R installation directory "
                    '(e.g., set R_HOME=C:\\Program Files\\R\\R-4.4.0) '
                    "and ensure R's bin directory is on PATH."
                )
            else:
                lines.append(f"\nWindows: R_HOME is set to: {r_home}")
                if not os.path.isdir(r_home):
                    lines.append(
                        f"  WARNING: R_HOME directory does not exist: {r_home}"
                    )
        elif sys.platform == "darwin":
            import platform as plat

            lines.append(
                f"\nmacOS ({plat.machine()}): ensure R and Python use the "
                f"same architecture (both arm64 or both x86_64). "
                f"Install R from CRAN or Homebrew: brew install r"
            )

        raise Rpy2NotAvailableError("\n".join(lines))


def _get_fmesher() -> Any:
    """Get or lazily initialize the fmesher R package handle.

    On first call, uses rpy2's importr() to load R's fmesher package
    (equivalent to library(fmesher) in R). The package handle is cached
    in the module-level _fmesher_r variable so subsequent calls return
    immediately without re-importing.

    Returns
    -------
    rpy2 package object
        A handle to R's fmesher package. Methods on this object
        (e.g., _get_fmesher().fm_mesh_2d(...)) call the corresponding
        R functions.

    Raises
    ------
    Rpy2NotAvailableError
        If rpy2 is not installed.
    FmesherNotAvailableError
        If the fmesher R package is not installed in R.
    """
    global _fmesher_r

    _check_rpy2()

    if _fmesher_r is not None:
        return _fmesher_r

    try:
        _fmesher_r = importr("fmesher")
        return _fmesher_r
    except RRuntimeError as e:
        raise FmesherNotAvailableError(
            f"fmesher R package is not installed. Install with R command:\n"
            f"  install.packages('fmesher')\n"
            f"Original error: {e}"
        ) from e


# =============================================================================
# Type conversion utilities
# =============================================================================


def _numpy_to_r_matrix(arr: np.ndarray) -> "Matrix":
    """Convert a numpy array to an R matrix via rpy2.

    R stores matrices in column-major (Fortran) order, so the numpy array
    is flattened in column-major order before constructing the R matrix
    with the correct (nrow, ncol) dimensions.

    If the input is 1D, it is reshaped to a single-column matrix.

    Parameters
    ----------
    arr : np.ndarray
        A 1D or 2D numpy array.

    Returns
    -------
    rpy2 Matrix
        An R matrix with the same data and dimensions.
    """
    if arr.ndim == 1:
        arr = arr.reshape(-1, 1)

    # Flatten column-major for R
    flat = arr.flatten(order="F")
    vec = FloatVector(flat.tolist())

    # Create matrix with correct dimensions
    r_matrix = ro.r["matrix"](vec, nrow=arr.shape[0], ncol=arr.shape[1])
    return r_matrix


def _r_matrix_to_numpy(r_mat: Any) -> np.ndarray:
    """Convert an R matrix to a numpy array.

    Reads the flat data from the R object and reshapes it in column-major
    order (matching R's storage layout) to reconstruct the original matrix
    dimensions. If the R object is a vector (no dim attribute), returns
    a 1D numpy array.

    Parameters
    ----------
    r_mat : rpy2 R object
        An R matrix or vector.

    Returns
    -------
    np.ndarray
        A 1D or 2D numpy array with the same data.
    """
    dims = ro.r["dim"](r_mat)
    if dims is ro.NULL:
        # It's a vector
        return np.array(list(r_mat))

    nrow, ncol = int(dims[0]), int(dims[1])
    flat = np.array(list(r_mat))

    # R stores column-major
    return flat.reshape((nrow, ncol), order="F")


def _segment_to_r(segment: FmSegment) -> Any:
    """Convert a Python FmSegment to an R fm_segm object.

    Converts the segment's loc (vertex coordinates) and idx (edge indices)
    to R matrices, adjusting idx from 0-based (Python) to 1-based (R)
    indexing. Then calls R's fmesher::fm_segm() to create a properly
    classed R segment object that fm_mesh_2d can accept as a boundary
    or interior argument.

    Parameters
    ----------
    segment : FmSegment
        A Python segment with loc, idx, and is_bnd fields.

    Returns
    -------
    rpy2 R object
        An R fm_segm object with class attributes set correctly.
    """
    fmesher = _get_fmesher()

    loc_r = _numpy_to_r_matrix(segment.loc)
    # R uses 1-based indexing
    idx_r = _numpy_to_r_matrix((segment.idx + 1).astype(float))

    # Use R's fm_segm to create a proper segment object with correct class
    r_segm = fmesher.fm_segm(
        loc=loc_r,
        idx=idx_r,
        **{"is.bnd": ro.BoolVector([segment.is_bnd])}
    )

    return r_segm


def _r_segment_to_python(segm_r: Any, is_bnd: bool = True) -> Optional[FmSegment]:
    """Convert an R segment object to a Python FmSegment.

    Extracts loc (vertex coordinates), idx (edge indices), and optionally
    grp (group labels) from the R segment. Adjusts idx from 1-based (R)
    to 0-based (Python) indexing.

    Returns None if the R segment is NULL or extraction fails (e.g., if
    the mesh has no boundary or interior segments).

    Parameters
    ----------
    segm_r : rpy2 R object
        An R fm_segm object.
    is_bnd : bool
        Whether this is a boundary segment (True) or interior segment (False).

    Returns
    -------
    FmSegment or None
        The converted segment, or None if the R object was empty/invalid.
    """
    try:
        loc_r = segm_r.rx2("loc")
        idx_r = segm_r.rx2("idx")

        if loc_r is ro.NULL or idx_r is ro.NULL:
            return None

        loc = _r_matrix_to_numpy(loc_r)
        idx = _r_matrix_to_numpy(idx_r).astype(np.int64) - 1  # 0-based

        grp = None
        try:
            grp_r = segm_r.rx2("grp")
            if grp_r is not ro.NULL:
                grp = np.array(list(grp_r), dtype=np.int64)
        except Exception as e:
            warnings.warn(f"Could not extract grp from R segment: {e}")

        return FmSegment(loc=loc, idx=idx, is_bnd=is_bnd, grp=grp)
    except Exception as e:
        warnings.warn(f"Failed to convert R segment to Python: {e}")
        return None


def _r_mesh_to_fm_mesh(r_mesh: Any) -> FmMesh:
    """Convert an R fm_mesh_2d result to a Python FmMesh dataclass.

    Extracts all components from the R mesh object:
      - loc: vertex coordinates (n x 3 matrix, converted from 1-based R)
      - graph$tv: triangle-vertex indices (converted to 0-based)
      - graph$vv: vertex-vertex edge list (if available)
      - graph$tt: triangle-triangle adjacency (if available, with R's 0
        meaning "no neighbor" converted to -1)
      - manifold: coordinate manifold type (default "R2")
      - crs: coordinate reference system (if set)
      - segm$bnd: boundary segments
      - segm$int: interior segments

    The original R mesh object is stored in R's global environment
    (via _store_r_mesh) to prevent garbage collection, and its ID is
    saved in FmMesh._r_mesh for later retrieval.

    Parameters
    ----------
    r_mesh : rpy2 R object
        An R fm_mesh_2d object returned by fmesher::fm_mesh_2d().

    Returns
    -------
    FmMesh
        A Python dataclass containing all extracted mesh data.
    """
    # Extract loc (vertex locations)
    loc_r = r_mesh.rx2("loc")
    loc = _r_matrix_to_numpy(loc_r)

    # Extract graph components
    graph = r_mesh.rx2("graph")

    # Triangle vertices - R uses 1-based indexing
    tv_r = graph.rx2("tv")
    tv = _r_matrix_to_numpy(tv_r).astype(np.int64) - 1

    # Vertex-vertex edges: derive from triangle connectivity (tv)
    # R stores vv as an S4 sparse matrix which is hard to extract via rpy2,
    # so we compute the edge list directly from the triangles instead.
    edges = set()
    for tri in tv:
        a, b, c = int(tri[0]), int(tri[1]), int(tri[2])
        edges.add((min(a, b), max(a, b)))
        edges.add((min(b, c), max(b, c)))
        edges.add((min(a, c), max(a, c)))
    vv = np.array(sorted(edges), dtype=np.int64) if edges else np.empty((0, 2), dtype=np.int64)

    # Triangle-triangle adjacency (optional)
    tt = np.empty((0, 3), dtype=np.int64)
    try:
        tt_r = graph.rx2("tt")
        if tt_r is not ro.NULL:
            tt_raw = _r_matrix_to_numpy(tt_r).astype(np.int64)
            # Convert 0 to -1 (R uses 0 for no neighbor, we use -1)
            tt = np.where(tt_raw == 0, -1, tt_raw - 1)
    except Exception as e:
        warnings.warn(f"Could not extract tt (triangle-triangle adjacency) from R mesh: {e}")

    # Extract manifold
    manifold = "R2"
    try:
        manifold_r = r_mesh.rx2("manifold")
        if manifold_r is not ro.NULL:
            manifold = str(manifold_r[0])
    except Exception as e:
        warnings.warn(f"Could not extract manifold from R mesh, defaulting to 'R2': {e}")

    # Extract CRS
    crs = None
    try:
        crs_r = r_mesh.rx2("crs")
        if crs_r is not ro.NULL:
            crs = str(crs_r)
    except Exception as e:
        warnings.warn(f"Could not extract CRS from R mesh: {e}")

    # Extract segments
    segm_bnd: List[FmSegment] = []
    segm_int: List[FmSegment] = []

    try:
        segm_r = r_mesh.rx2("segm")
        if segm_r is not ro.NULL:
            # Boundary segments
            try:
                bnd_r = segm_r.rx2("bnd")
                if bnd_r is not ro.NULL:
                    seg = _r_segment_to_python(bnd_r, is_bnd=True)
                    if seg is not None:
                        segm_bnd.append(seg)
            except Exception as e:
                warnings.warn(f"Could not extract boundary segments from R mesh: {e}")

            # Interior segments
            try:
                int_r = segm_r.rx2("int")
                if int_r is not ro.NULL:
                    seg = _r_segment_to_python(int_r, is_bnd=False)
                    if seg is not None:
                        segm_int.append(seg)
            except Exception as e:
                warnings.warn(f"Could not extract interior segments from R mesh: {e}")
    except Exception as e:
        warnings.warn(f"Could not extract segments from R mesh: {e}")

    # Store R mesh in global storage to prevent garbage collection
    mesh_id = _store_r_mesh(r_mesh)

    return FmMesh(
        loc=loc,
        tv=tv,
        vv=vv,
        tt=tt,
        segm_bnd=segm_bnd,
        segm_int=segm_int,
        manifold=manifold,
        crs=crs,
        _r_mesh=mesh_id,  # Store ID instead of direct reference
    )


# =============================================================================
# Public API functions
# =============================================================================


def fm_mesh_2d(
    loc: Optional[np.ndarray] = None,
    loc_domain: Optional[np.ndarray] = None,
    offset: Optional[Union[float, Sequence[float]]] = None,
    n: Optional[Union[int, Sequence[int]]] = None,
    boundary: Optional[FmSegment] = None,
    interior: Optional[FmSegment] = None,
    max_edge: Optional[Union[float, Sequence[float]]] = None,
    min_angle: Optional[Union[float, Sequence[float]]] = None,
    cutoff: Optional[float] = None,
) -> FmMesh:
    """Create a 2D triangular mesh using R's fmesher::fm_mesh_2d.

    This function wraps R's fmesher package to create constrained refined
    Delaunay triangulations. It is a pure translation layer: all arguments
    are converted from Python types to R types, then R's fm_mesh_2d() is
    called, and the R result is converted back to a Python FmMesh.

    The actual meshing algorithm (constrained Delaunay triangulation with
    Ruppert refinement) runs entirely in R's fmesher C++ backend. Before
    reaching C++, R's fm_mesh_2d performs its own preprocessing:
      - Coordinate unification (fm_unify_coords): standardizes inputs to
        3-column matrices.
      - Boundary construction (fm_as_segm): converts boundary specs to
        segment objects.
      - Parameter expansion: normalizes max_edge, min_angle, offset, n to
        consistent 2-element vectors for inner/outer regions.
      - Then calls fmesher_rcdt() (the C++ entry point).

    Processing steps in this Python wrapper:
      1. Convert loc/loc_domain from numpy arrays to R matrices.
      2. Convert scalar/sequence parameters to R FloatVector/IntVector.
      3. Convert FmSegment objects to R fm_segm objects (with 0-to-1-based
         index adjustment).
      4. Call R's fmesher::fm_mesh_2d(**kwargs).
      5. Convert the R result to a Python FmMesh via _r_mesh_to_fm_mesh().

    Parameters
    ----------
    loc : np.ndarray, optional
        Matrix of point locations to include in the mesh.
        Shape (n, 2) or (n, 3). These points become mesh vertices
        (additional Steiner points may be added by the refinement algorithm).
    loc_domain : np.ndarray, optional
        Matrix of point locations used to determine the domain extent.
        The convex hull of these points defines the domain boundary.
        Unlike loc, these points are not forced to be mesh vertices.
    offset : float or sequence of float, optional
        The automatic extension distance beyond the domain boundary.
        If negative, interpreted as a factor of the approximate data diameter.
        Can be a 2-element sequence [inner, outer] for inner domain and
        outer extension distances.
    n : int or sequence of int, optional
        Initial number of points on the automatically constructed extended
        boundary. Can be a 2-element sequence [inner, outer].
    boundary : FmSegment, optional
        Explicit boundary specification. Create with fm_segm(is_bnd=True).
        When provided, overrides the automatic boundary derived from
        loc/loc_domain.
    interior : FmSegment, optional
        Interior constraint specification. Create with fm_segm(is_bnd=False).
        Forces triangle edges to align with the specified segments (e.g.,
        to represent barriers or domain subdivisions).
    max_edge : float or sequence of float, optional
        Maximum allowed triangle edge length. Can be a 2-element sequence
        [inner, outer] for inner and outer regions.
    min_angle : float or sequence of float, optional
        Minimum allowed triangle angle in degrees. Higher values produce
        better-quality triangles but may require more vertices. Values
        above ~34 degrees may prevent the algorithm from terminating.
    cutoff : float, optional
        Minimum distance allowed between points. Points closer than this
        are merged, which helps avoid degenerate triangles when input
        points are very close together.

    Returns
    -------
    FmMesh
        A mesh object containing:
        - loc: vertex coordinates (n_vertices x 3)
        - tv: triangle-vertex indices (n_triangles x 3, 0-based)
        - vv: vertex-vertex edges (if extracted)
        - tt: triangle-triangle adjacency (if extracted)
        - segm_bnd/segm_int: boundary and interior segments

    Raises
    ------
    Rpy2NotAvailableError
        If rpy2 is not installed.
    FmesherNotAvailableError
        If the fmesher R package is not installed.
    TypeError
        If boundary or interior is not an FmSegment.

    Examples
    --------
    >>> import numpy as np
    >>> from pyinla.fmesher import fm_mesh_2d
    >>>
    >>> # Create mesh from random points
    >>> locs = np.random.randn(100, 2)
    >>> mesh = fm_mesh_2d(loc=locs, max_edge=[0.5, 1.0], cutoff=0.1)
    >>> print(f"Mesh has {mesh.n} vertices and {mesh.n_triangle} triangles")

    >>> # Create mesh with automatic boundary extension
    >>> mesh = fm_mesh_2d(loc=locs, offset=[-0.1, -0.2], max_edge=[0.3, 0.6])
    """
    # Step 1: Get handle to R's fmesher package (lazy-loaded, cached)
    fmesher = _get_fmesher()

    # Step 2: Build keyword arguments dict for the R function call.
    # Each Python argument is converted to its R equivalent and added
    # to kwargs with the R parameter name (using dots, e.g., "max.edge").
    kwargs: Dict[str, Any] = {}

    # Step 2a: Convert location matrices (numpy -> R matrix)
    if loc is not None:
        loc_arr = np.asarray(loc, dtype=float)
        if loc_arr.ndim == 1:
            loc_arr = loc_arr.reshape(-1, 2)
        kwargs["loc"] = _numpy_to_r_matrix(loc_arr)

    if loc_domain is not None:
        loc_domain_arr = np.asarray(loc_domain, dtype=float)
        if loc_domain_arr.ndim == 1:
            loc_domain_arr = loc_domain_arr.reshape(-1, 2)
        kwargs["loc.domain"] = _numpy_to_r_matrix(loc_domain_arr)

    # Step 2b: Convert numeric parameters (scalar/list -> R FloatVector/IntVector)
    if offset is not None:
        if isinstance(offset, (int, float)):
            kwargs["offset"] = FloatVector([float(offset)])
        else:
            kwargs["offset"] = FloatVector([float(x) for x in offset])

    if n is not None:
        if isinstance(n, int):
            kwargs["n"] = IntVector([n])
        else:
            kwargs["n"] = IntVector(list(n))

    if max_edge is not None:
        if isinstance(max_edge, (int, float)):
            kwargs["max.edge"] = FloatVector([float(max_edge)])
        else:
            kwargs["max.edge"] = FloatVector([float(x) for x in max_edge])

    if min_angle is not None:
        if isinstance(min_angle, (int, float)):
            kwargs["min.angle"] = FloatVector([float(min_angle)])
        else:
            kwargs["min.angle"] = FloatVector([float(x) for x in min_angle])

    if cutoff is not None:
        kwargs["cutoff"] = float(cutoff)

    # Step 2c: Convert boundary/interior segments (FmSegment -> R fm_segm)
    if boundary is not None:
        if not isinstance(boundary, FmSegment):
            raise TypeError(
                f"boundary must be an FmSegment (create with fm_segm()), "
                f"got {type(boundary).__name__}"
            )
        kwargs["boundary"] = _segment_to_r(boundary)

    if interior is not None:
        if not isinstance(interior, FmSegment):
            raise TypeError(
                f"interior must be an FmSegment (create with fm_segm()), "
                f"got {type(interior).__name__}"
            )
        kwargs["interior"] = _segment_to_r(interior)

    # Step 3: Call R's fmesher::fm_mesh_2d() with the converted arguments.
    # This triggers R's preprocessing (coordinate unification, boundary
    # construction, parameter expansion) followed by the C++ fmesher_rcdt()
    # call that performs the actual constrained Delaunay triangulation.
    r_mesh = fmesher.fm_mesh_2d(**kwargs)

    # Step 4: Convert the R result back to a Python FmMesh dataclass.
    # This extracts loc, tv, vv, tt, segments, manifold, and CRS from
    # the R object and adjusts indices from 1-based to 0-based.
    return _r_mesh_to_fm_mesh(r_mesh)


def _make_closed_indices(n: int) -> np.ndarray:
    """Create closed polygon edge indices from n vertices.

    Generates an (n, 2) array of edge pairs connecting consecutive vertices
    in a closed loop: [[0,1], [1,2], ..., [n-2,n-1], [n-1,0]].
    Used by fm_nonconvex_hull to build boundary segment indices from
    the extracted hull coordinates.

    Parameters
    ----------
    n : int
        Number of vertices in the polygon.

    Returns
    -------
    np.ndarray
        Shape (n, 2) array of 0-based edge index pairs, or (0, 2) if n < 2.
    """
    if n < 2:
        return np.empty((0, 2), dtype=np.int64)
    indices = np.column_stack(
        [np.arange(n, dtype=np.int64), np.roll(np.arange(n, dtype=np.int64), -1)]
    )
    return indices


def fm_nonconvex_hull(
    loc: np.ndarray,
    convex: Union[float, Sequence[float]] = -0.15,
    concave: Optional[Union[float, Sequence[float]]] = None,
    resolution: Union[int, Sequence[int]] = 40,
) -> FmSegment:
    """Create a non-convex hull boundary using R's fmesher::fm_nonconvex_hull.

    This creates a boundary that follows the shape of the point cloud more
    closely than a convex hull.

    Parameters
    ----------
    loc : np.ndarray
        Matrix of point locations. Shape (n, 2).
    convex : float or sequence, optional
        Convexity parameter. Negative values are relative to data extent.
        Default is -0.15 (15% of extent).
    concave : float or sequence, optional
        Concavity parameter. If None, uses the convex value.
    resolution : int or sequence, optional
        Number of points for the hull approximation. Can be a single int
        or a sequence of two ints (e.g., [100, 90]). Default is 40.

    Returns
    -------
    FmSegment
        A boundary segment representing the non-convex hull.

    Notes
    -----
    Requires the 'sf' R package: install.packages('sf')

    Examples
    --------
    >>> import numpy as np
    >>> from pyinla.fmesher import fm_nonconvex_hull, fm_mesh_2d
    >>>
    >>> locs = np.random.randn(100, 2)
    >>> boundary = fm_nonconvex_hull(locs, convex=-0.1)
    >>> mesh = fm_mesh_2d(loc=locs, boundary=boundary, max_edge=0.5)
    """
    fmesher = _get_fmesher()

    # Need sf package for polygon conversion and coordinate extraction
    try:
        sf = importr("sf")
    except RRuntimeError as e:
        raise FmesherNotAvailableError(
            "fm_nonconvex_hull requires the 'sf' R package.\n"
            "Install with R command: install.packages('sf')"
        ) from e

    loc_arr = np.asarray(loc, dtype=float)
    if loc_arr.ndim == 1:
        loc_arr = loc_arr.reshape(-1, 2)

    # Convert boundary coordinates to sf polygon (matching R behavior)
    # Close the polygon if not already closed
    if not np.allclose(loc_arr[0], loc_arr[-1]):
        loc_arr = np.vstack([loc_arr, loc_arr[0]])
    coords_r = _numpy_to_r_matrix(loc_arr)
    r_list = ro.r['list'](coords_r)
    r_polygon = sf.st_polygon(r_list)
    r_sfc = sf.st_sfc(r_polygon)

    if isinstance(resolution, (int, float)):
        r_resolution = IntVector([int(resolution)])
    else:
        r_resolution = IntVector([int(x) for x in resolution])

    kwargs: Dict[str, Any] = {
        "x": r_sfc,
        "resolution": r_resolution,
    }

    if isinstance(convex, (int, float)):
        kwargs["convex"] = float(convex)
    else:
        kwargs["convex"] = FloatVector([float(x) for x in convex])

    if concave is not None:
        if isinstance(concave, (int, float)):
            kwargs["concave"] = float(concave)
        else:
            kwargs["concave"] = FloatVector([float(x) for x in concave])

    r_hull = fmesher.fm_nonconvex_hull(**kwargs)

    # Get coordinates from sf geometry
    coords_r = sf.st_coordinates(r_hull)
    loc_out = _r_matrix_to_numpy(coords_r)[:, :2]  # Take only X, Y columns

    # Remove last point if it duplicates first (closed polygon)
    n_pts = loc_out.shape[0]
    if n_pts > 1 and np.allclose(loc_out[0], loc_out[-1]):
        loc_out = loc_out[:-1]
        n_pts = loc_out.shape[0]

    idx_out = _make_closed_indices(n_pts)

    return FmSegment(loc=loc_out, idx=idx_out, is_bnd=True)


def fm_segm(
    loc: np.ndarray,
    is_bnd: bool = True,
) -> FmSegment:
    """Create a mesh boundary or interior segment using R's fmesher::fm_segm.

    Wraps R's fm_segm() to create segment objects that can be passed to
    fm_mesh_2d as the boundary or interior argument. The segment defines
    a set of edges (line segments) connecting specified vertices.

    R's fm_segm auto-generates indices connecting consecutive vertices
    in a closed loop: [[0,1], [1,2], ..., [n-1,0]].

    Processing steps:
      1. Convert loc to a numpy array, reshape to (n, 2) if needed.
      2. Convert loc to an R matrix.
      3. Call R's fmesher::fm_segm(loc, is.bnd).
      4. Extract loc and idx from the R result, adjusting idx back to
         0-based indexing.

    Parameters
    ----------
    loc : np.ndarray
        Matrix of vertex coordinates. Shape (n, 2).
    is_bnd : bool, optional
        True for boundary segments (default), False for interior
        constraints. Boundary segments define the outer/inner domain
        edges. Interior segments force triangle edges to align with
        the specified lines without defining domain boundaries.

    Returns
    -------
    FmSegment
        A segment with loc, idx (0-based), and is_bnd fields.

    Examples
    --------
    >>> import numpy as np
    >>> from pyinla.fmesher import fm_segm, fm_mesh_2d
    >>>
    >>> # Create a square boundary
    >>> corners = np.array([[0, 0], [1, 0], [1, 1], [0, 1]])
    >>> boundary = fm_segm(corners, is_bnd=True)
    >>> mesh = fm_mesh_2d(boundary=boundary, max_edge=0.2)
    """
    fmesher = _get_fmesher()

    loc_arr = np.asarray(loc, dtype=float)
    if loc_arr.ndim == 1:
        loc_arr = loc_arr.reshape(-1, 2)

    kwargs: Dict[str, Any] = {
        "loc": _numpy_to_r_matrix(loc_arr),
        "is.bnd": ro.BoolVector([is_bnd]),
    }

    r_segm = fmesher.fm_segm(**kwargs)

    # Extract result
    loc_r = r_segm.rx2("loc")
    idx_r = r_segm.rx2("idx")

    loc_out = _r_matrix_to_numpy(loc_r)
    idx_out = _r_matrix_to_numpy(idx_r).astype(np.int64) - 1

    return FmSegment(loc=loc_out, idx=idx_out, is_bnd=is_bnd)


def fm_hexagon_lattice(
    boundary: np.ndarray,
    edge_len: float,
    buffer_n: float = 0.49,
    align: Union[str, Sequence[float]] = "origin",
    geo_buffer: float = 0.0,
) -> np.ndarray:
    """Create a hexagonal lattice of points within a boundary.

    Wraps R's fmesher::fm_hexagon_lattice to generate evenly-spaced
    points in a hexagonal pattern within the specified boundary.
    By default, the lattice is anchored at the coordinate system origin
    so that grids with different but overlapping boundaries will have
    matching points.

    Parameters
    ----------
    boundary : np.ndarray
        Matrix of boundary coordinates. Shape (n, 2).
    edge_len : float
        Triangle edge length (spacing between points).
    buffer_n : float, optional
        Number of triangle-height multiples for the inward buffer
        between the boundary and the start of the lattice. Default
        is 0.49 (just under half a triangle height), matching R's default.
    align : str or sequence of float, optional
        Alignment anchor for the hexagon lattice. Default is "origin"
        (aligned to coordinate origin). Can also be a length-2 sequence
        [x, y] specifying a custom anchor point.
    geo_buffer : float, optional
        Distance to expand the boundary polygon geometry (via
        sf::st_buffer) before generating lattice points. This is
        separate from buffer_n: geo_buffer expands the polygon itself,
        while buffer_n offsets the lattice inward from the (possibly
        expanded) boundary. Default is 0.0 (no expansion).

    Returns
    -------
    np.ndarray
        Array of (x, y) coordinates of the hexagon lattice points.

    Notes
    -----
    Requires the 'sf' R package: install.packages('sf')

    Examples
    --------
    >>> import numpy as np
    >>> from pyinla.fmesher import fm_hexagon_lattice, fm_mesh_2d
    >>>
    >>> # Create boundary
    >>> boundary = np.array([[0, 0], [100, 0], [100, 100], [0, 100]])
    >>> # Generate hexagon lattice
    >>> points = fm_hexagon_lattice(boundary, edge_len=20)
    >>> # Use points to create mesh
    >>> mesh = fm_mesh_2d(loc=points, max_edge=50)
    >>>
    >>> # Custom alignment and tighter inward buffer
    >>> points = fm_hexagon_lattice(boundary, edge_len=20,
    ...                             buffer_n=0.1, align=[50, 50])
    """
    fmesher = _get_fmesher()

    try:
        sf = importr("sf")
    except RRuntimeError as e:
        raise FmesherNotAvailableError(
            "fm_hexagon_lattice requires the 'sf' R package.\n"
            "Install with R command: install.packages('sf')"
        ) from e

    # Convert boundary to numpy array
    bnd_arr = np.asarray(boundary, dtype=float)
    if bnd_arr.ndim == 1:
        bnd_arr = bnd_arr.reshape(-1, 2)

    # Close the polygon if not already closed
    if not np.allclose(bnd_arr[0], bnd_arr[-1]):
        bnd_arr = np.vstack([bnd_arr, bnd_arr[0]])

    # Create sf polygon from boundary coordinates
    coords_r = _numpy_to_r_matrix(bnd_arr)
    r_list = ro.r['list'](coords_r)
    r_polygon = sf.st_polygon(r_list)
    r_sfc = sf.st_sfc(r_polygon)

    # Expand boundary geometry if requested
    if geo_buffer > 0:
        r_sfc = sf.st_buffer(r_sfc, float(geo_buffer))

    # Build keyword arguments for R's fm_hexagon_lattice
    kwargs: Dict[str, Any] = {
        "edge_len": float(edge_len),
        "buffer_n": float(buffer_n),
    }

    # Convert align to R
    if isinstance(align, str):
        kwargs["align"] = align
    else:
        kwargs["align"] = FloatVector([float(x) for x in align])

    # Call fm_hexagon_lattice
    r_points = fmesher.fm_hexagon_lattice(r_sfc, **kwargs)

    # Extract coordinates from sf points
    coords_r = sf.st_coordinates(r_points)
    coords = _r_matrix_to_numpy(coords_r)[:, :2]  # Take only X, Y columns

    return coords


def get_utm_crs(
    gdf_or_coords: Union[Any, np.ndarray, Tuple[float, float]],
    units: str = "km",
) -> str:
    """Get the appropriate UTM CRS for a location or GeoDataFrame.

    Automatically determines the correct UTM zone based on the centroid
    of the input geometry or coordinates.

    Parameters
    ----------
    gdf_or_coords : GeoDataFrame, ndarray, or tuple
        Input can be:
        - A GeoDataFrame (uses centroid of all geometries)
        - A numpy array of shape (n, 2) with lon/lat coordinates
        - A tuple of (longitude, latitude) for a single point
    units : str, optional
        'km' for kilometers (default), 'm' for meters.
        Using 'km' is recommended for numerical stability in large regions.

    Returns
    -------
    str
        PROJ4 string for the appropriate UTM zone.

    Notes
    -----
    UTM (Universal Transverse Mercator) divides the world into 60 zones,
    each 6 degrees wide. The zone number is calculated from longitude:

        zone = floor((longitude + 180) / 6) + 1

    The hemisphere (north/south) is determined by latitude.

    Examples
    --------
    >>> import geopandas as gpd
    >>> from pyinla.fmesher import get_utm_crs
    >>>
    >>> # From a GeoDataFrame
    >>> world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
    >>> brazil = world[world['name'] == 'Brazil']
    >>> crs = get_utm_crs(brazil, units='km')
    >>> print(crs)
    +proj=utm +zone=23 +south +datum=WGS84 +units=km +no_defs
    >>>
    >>> # From coordinates (lon, lat)
    >>> crs = get_utm_crs((46.7, 24.7), units='km')  # Saudi Arabia
    >>> print(crs)
    +proj=utm +zone=38 +datum=WGS84 +units=km +no_defs
    >>>
    >>> # From numpy array of points
    >>> import numpy as np
    >>> points = np.array([[46.7, 24.7], [35.5, 33.9], [36.3, 33.5]])
    >>> crs = get_utm_crs(points, units='km')
    """
    # Determine centroid based on input type
    if hasattr(gdf_or_coords, "geometry"):
        # It's a GeoDataFrame
        centroid = gdf_or_coords.dissolve().centroid.iloc[0]
        lon, lat = centroid.x, centroid.y
    elif isinstance(gdf_or_coords, np.ndarray):
        # It's a numpy array of coordinates
        if gdf_or_coords.ndim == 1:
            lon, lat = gdf_or_coords[0], gdf_or_coords[1]
        else:
            lon = gdf_or_coords[:, 0].mean()
            lat = gdf_or_coords[:, 1].mean()
    elif isinstance(gdf_or_coords, (tuple, list)):
        # It's a (lon, lat) tuple
        lon, lat = gdf_or_coords[0], gdf_or_coords[1]
    else:
        raise TypeError(
            f"Expected GeoDataFrame, ndarray, or tuple, got {type(gdf_or_coords)}"
        )

    # Calculate UTM zone from longitude
    utm_zone = int((lon + 180) / 6) + 1

    # Determine hemisphere
    south_flag = "" if lat >= 0 else " +south"

    # Build PROJ4 string
    unit_str = "+units=km" if units == "km" else "+units=m"
    crs = f"+proj=utm +zone={utm_zone}{south_flag} +datum=WGS84 {unit_str} +no_defs"

    return crs


def check_fmesher_available() -> Tuple[bool, Optional[str]]:
    """Check if fmesher is available and return status.

    Returns
    -------
    tuple
        (is_available, error_message) - error_message is None if available.

    Examples
    --------
    >>> from pyinla.fmesher import check_fmesher_available
    >>>
    >>> available, error = check_fmesher_available()
    >>> if available:
    ...     print("fmesher is ready to use!")
    ... else:
    ...     print(f"fmesher not available: {error}")
    """
    if not _HAS_RPY2:
        return False, f"rpy2 not installed: {_RPY2_ERROR}"

    try:
        _get_fmesher()
        return True, None
    except FmesherNotAvailableError as e:
        return False, str(e)
    except Exception as e:
        return False, f"Unexpected error: {e}"


def _r_sparse_to_scipy(r_sparse: Any) -> sparse.csr_matrix:
    """Convert an R sparse matrix to a scipy CSR sparse matrix.

    Handles three common R sparse matrix classes from the Matrix package:
      - dgCMatrix (compressed sparse column): extracts @x, @i, @p slots
        to build a scipy CSC matrix, then converts to CSR.
      - dgTMatrix (triplet/COO format): extracts @x, @i, @j slots to
        build a scipy COO matrix, then converts to CSR.
      - ddiMatrix (diagonal): extracts @x slot to build a scipy diagonal.

    If the class is not recognized, falls back to converting via R's
    as.matrix() (dense conversion), which is slower but universal.

    Parameters
    ----------
    r_sparse : rpy2 R object
        An R sparse matrix (typically from the Matrix package).

    Returns
    -------
    scipy.sparse.csr_matrix
        The equivalent scipy sparse matrix in CSR format.
    """
    # Get dimensions
    dims = ro.r["dim"](r_sparse)
    nrow, ncol = int(dims[0]), int(dims[1])

    # Check matrix class
    r_class = ro.r["class"](r_sparse)[0]

    if "dgCMatrix" in r_class:
        # Compressed sparse column format
        # Extract slots: @x (data), @i (row indices, 0-based), @p (column pointers)
        x = np.array(list(r_sparse.slots["x"]))
        i = np.array(list(r_sparse.slots["i"]), dtype=np.int32)
        p = np.array(list(r_sparse.slots["p"]), dtype=np.int32)

        mat = sparse.csc_matrix((x, i, p), shape=(nrow, ncol))
        return mat.tocsr()

    elif "dgTMatrix" in r_class:
        # Triplet format
        x = np.array(list(r_sparse.slots["x"]))
        i = np.array(list(r_sparse.slots["i"]), dtype=np.int32)
        j = np.array(list(r_sparse.slots["j"]), dtype=np.int32)

        mat = sparse.coo_matrix((x, (i, j)), shape=(nrow, ncol))
        return mat.tocsr()

    elif "ddiMatrix" in r_class:
        # Diagonal matrix
        diag = np.array(list(r_sparse.slots["x"]))
        return sparse.diags(diag, format="csr")

    else:
        # Try to convert via as.matrix (dense) - fallback
        r_dense = ro.r["as.matrix"](r_sparse)
        arr = _r_matrix_to_numpy(r_dense)
        return sparse.csr_matrix(arr)


def fm_fem(
    mesh: FmMesh,
    order: int = 2,
) -> FmFEM:
    """Compute Finite Element Method matrices from a mesh.

    Wraps R's fmesher::fm_fem to compute the mass and stiffness matrices
    needed for SPDE-based spatial modeling. These matrices discretize the
    SPDE on the triangular mesh using piecewise linear basis functions.

    Processing steps:
      1. Reconstruct a minimal R fm_mesh_2d object from the Python mesh's
         loc and tv arrays (with 0-to-1-based index adjustment). This is
         done by building an R list with the correct S3 class attributes
         rather than calling fm_mesh_2d again.
      2. Call R's fmesher::fm_fem(r_mesh, order=order).
      3. Extract result matrices:
         - c0 (diagonal sparse) -> scipy sparse -> numpy diagonal vector
         - c1, g1, g2 (sparse) -> scipy CSR via _r_sparse_to_scipy
         - va, ta (dense R matrices) -> numpy vectors via _r_matrix_to_numpy

    Parameters
    ----------
    mesh : FmMesh
        A mesh object created by fm_mesh_2d.
    order : int, optional
        The FEM order. Default is 2. Order 1 computes only c0, c1, g1.
        Order 2 additionally computes g2 (second-order stiffness).

    Returns
    -------
    FmFEM
        Object containing FEM matrices:
        - c0: Lumped mass matrix diagonal (n,). The row sums of c1,
          representing the area associated with each vertex.
        - c1: Full mass matrix, sparse (n, n). Symmetric positive definite.
        - g1: First-order stiffness matrix, sparse (n, n). Encodes the
          gradient inner products of the piecewise linear basis functions.
        - g2: Second-order stiffness matrix, sparse (n, n) if order >= 2.
          Computed as g1 @ diag(1/c0) @ g1.
        - va: Voronoi areas for each vertex (n,).
        - ta: Triangle areas (n_triangles,).

    Raises
    ------
    Rpy2NotAvailableError
        If rpy2 is not installed.
    FmesherNotAvailableError
        If the fmesher R package is not installed.

    Notes
    -----
    The FEM matrices are used to construct the SPDE precision matrix Q.
    For the Matern SPDE with alpha=2:
        Q = kappa^4 * C + 2 * kappa^2 * G + G * C^{-1} * G

    where C is the mass matrix and G is the stiffness matrix.

    Examples
    --------
    >>> import numpy as np
    >>> from pyinla.fmesher import fm_mesh_2d, fm_fem
    >>>
    >>> # Create a mesh
    >>> locs = np.random.randn(100, 2)
    >>> mesh = fm_mesh_2d(loc=locs, max_edge=[0.5, 1.0], cutoff=0.1)
    >>>
    >>> # Compute FEM matrices
    >>> fem = fm_fem(mesh, order=2)
    >>> print(fem.summary())
    """
    fmesher = _get_fmesher()

    # Use the cached R mesh if available (stored in R's global environment).
    # This preserves boundary segments, CRS, and other metadata that the
    # minimal reconstruction below would lose.
    mesh_id = mesh._r_mesh
    if mesh_id is not None and mesh_id in list(ro.globalenv.keys()):
        r_mesh = ro.globalenv[mesh_id]
    else:
        # Fallback: reconstruct a minimal R fm_mesh_2d from Python data.
        # This loses boundary/interior segments and CRS, but is sufficient
        # for FEM computation on simple meshes.
        loc_r = _numpy_to_r_matrix(mesh.loc)
        tv_r = _numpy_to_r_matrix((mesh.tv + 1).astype(float))  # 1-based indexing

        r_mesh = ro.r(
            """
            function(loc, tv) {
                mesh <- list()
                mesh$loc <- loc
                mesh$graph <- list(tv = tv)
                mesh$n <- nrow(loc)
                mesh$manifold <- "R2"
                class(mesh) <- c("fm_mesh_2d", "inla.mesh")
                return(mesh)
            }
            """
        )(loc_r, tv_r)

    # Call fm_fem
    r_fem = fmesher.fm_fem(r_mesh, order=order)

    # Extract results
    # c0: lumped mass - sparse diagonal matrix, extract diagonal as vector
    c0_r = r_fem.rx2("c0")
    c0_sparse = _r_sparse_to_scipy(c0_r)
    c0 = np.asarray(c0_sparse.diagonal())

    # c1: full mass matrix (sparse)
    c1_r = r_fem.rx2("c1")
    c1 = _r_sparse_to_scipy(c1_r)

    # g1: first-order stiffness (sparse)
    g1_r = r_fem.rx2("g1")
    g1 = _r_sparse_to_scipy(g1_r)

    # g2: second-order stiffness (sparse) - only if order >= 2
    g2 = None
    if order >= 2:
        try:
            g2_r = r_fem.rx2("g2")
            if g2_r is not ro.NULL:
                g2 = _r_sparse_to_scipy(g2_r)
        except Exception:
            pass

    # va: Voronoi areas - matrix, flatten to vector
    va_r = r_fem.rx2("va")
    va = _r_matrix_to_numpy(va_r).flatten()

    # ta: triangle areas - matrix, flatten to vector
    ta_r = r_fem.rx2("ta")
    ta = _r_matrix_to_numpy(ta_r).flatten()

    return FmFEM(
        c0=c0,
        c1=c1,
        g1=g1,
        va=va,
        ta=ta,
        order=order,
        g2=g2,
    )


def fm_evaluator(
    mesh: FmMesh,
    xlim: Optional[Tuple[float, float]] = None,
    ylim: Optional[Tuple[float, float]] = None,
    dims: Optional[Union[int, Tuple[int, int], Sequence[int]]] = None,
) -> FmEvaluator:
    """Create an evaluator/projector for mapping mesh values to a regular grid.

    Wraps R's fmesher::fm_evaluator to create a sparse projection matrix A
    that interpolates values from mesh vertices to points on a regular grid.
    The projection uses barycentric interpolation within each triangle.

    Processing steps (two paths depending on whether the R mesh is cached):

    Path A (cached R mesh available, via _r_mesh field):
      1. Store xlim, ylim, dims in R's global environment.
      2. Execute an R script that calls fm_evaluator on the stored R mesh,
         converts the projection matrix to triplet format (TsparseMatrix),
         and returns all components as a flat R list.
      3. Build scipy sparse matrix from the triplets (i, j, x).
      This path avoids rpy2 weak reference issues by keeping everything
      in R until the final extraction.

    Path B (no cached R mesh, fallback):
      1. Reconstruct a minimal R fm_mesh_2d object from Python's loc/tv/vv/tt.
      2. Call R's fm_evaluator directly via rpy2.
      3. Extract components by navigating the nested R result object.

    Parameters
    ----------
    mesh : FmMesh
        A mesh object created by fm_mesh_2d.
    xlim : tuple of (float, float), optional
        X-axis limits (min, max). If not provided, uses mesh bounding box.
    ylim : tuple of (float, float), optional
        Y-axis limits (min, max). If not provided, uses mesh bounding box.
    dims : int or tuple of (int, int), optional
        Grid dimensions (nx, ny). If a single int, uses the same for both.
        If not provided, defaults to (100, 100).

    Returns
    -------
    FmEvaluator
        An evaluator object containing:
        - x, y: Grid coordinates along each axis (1D arrays).
        - proj_A: Sparse projection matrix (n_grid_points x n_vertices).
          Multiplying proj_A @ field gives interpolated values at grid points.
        - lattice_loc: Grid point locations as (n_points, 2) array.
        - xlim, ylim, dims: The grid specification used.

    Raises
    ------
    Rpy2NotAvailableError
        If rpy2 is not installed.
    FmesherNotAvailableError
        If the fmesher R package is not installed.

    Examples
    --------
    >>> import numpy as np
    >>> from pyinla.fmesher import fm_mesh_2d, fm_evaluator, fm_evaluate
    >>>
    >>> # Create a mesh
    >>> locs = np.random.randn(100, 2)
    >>> mesh = fm_mesh_2d(loc=locs, max_edge=[0.5, 1.0], cutoff=0.1)
    >>>
    >>> # Create evaluator for a grid
    >>> proj = fm_evaluator(mesh, xlim=(-3, 3), ylim=(-3, 3), dims=(50, 50))
    >>> print(proj.summary())
    >>>
    >>> # Project some values (e.g., from spatial effect)
    >>> field = np.random.randn(mesh.n)
    >>> grid_values = fm_evaluate(proj, field)
    """
    fmesher = _get_fmesher()

    # Set defaults from mesh bounding box
    bbox = mesh.bbox
    if xlim is None:
        xlim = bbox["x"]
    if ylim is None:
        ylim = bbox["y"]
    if dims is None:
        dims = (100, 100)
    elif isinstance(dims, int):
        dims = (dims, dims)
    else:
        dims = tuple(dims)

    # Use the cached R mesh if available (stored in R's global environment)
    # This avoids rpy2 weak reference issues when passing R objects
    mesh_id = mesh._r_mesh

    if mesh_id is not None and mesh_id in ro.globalenv.keys():
        # Call fm_evaluator entirely in R using the stored mesh by name
        # Extract all data within R to avoid rpy2 weak reference issues
        # Pass xlim/ylim as R variables to preserve full precision
        ro.globalenv[".pyinla_xlim"] = FloatVector([float(xlim[0]), float(xlim[1])])
        ro.globalenv[".pyinla_ylim"] = FloatVector([float(ylim[0]), float(ylim[1])])
        ro.globalenv[".pyinla_dims"] = IntVector([int(dims[0]), int(dims[1])])

        r_result = ro.r(
            f"""
            .pyinla_eval <- fm_evaluator(
                {mesh_id},
                xlim = .pyinla_xlim,
                ylim = .pyinla_ylim,
                dims = .pyinla_dims
            )
            .pyinla_A_t <- as(.pyinla_eval$proj$A, "TsparseMatrix")
            list(
                x = .pyinla_eval$x,
                y = .pyinla_eval$y,
                lattice_loc = .pyinla_eval$lattice$loc,
                A_i = .pyinla_A_t@i,
                A_j = .pyinla_A_t@j,
                A_x = .pyinla_A_t@x,
                A_nrow = nrow(.pyinla_eval$proj$A),
                A_ncol = ncol(.pyinla_eval$proj$A)
            )
            """
        )

        # Extract from list result (safer than accessing nested R objects)
        x = np.array(list(r_result.rx2("x")))
        y = np.array(list(r_result.rx2("y")))
        lattice_loc = _r_matrix_to_numpy(r_result.rx2("lattice_loc"))

        # Build sparse matrix from triplets
        A_i = np.array(list(r_result.rx2("A_i")), dtype=np.int64)
        A_j = np.array(list(r_result.rx2("A_j")), dtype=np.int64)
        A_x = np.array(list(r_result.rx2("A_x")))
        A_nrow = int(r_result.rx2("A_nrow")[0])
        A_ncol = int(r_result.rx2("A_ncol")[0])
        proj_A = sparse.csr_matrix((A_x, (A_i, A_j)), shape=(A_nrow, A_ncol))

    else:
        # Fallback: reconstruct R mesh from Python data, store it in R's
        # global environment, then use the same R-script extraction as
        # Path A. This avoids the chained .rx2() calls (e.g.,
        # r_evaluator.rx2("proj").rx2("A")) that are vulnerable to rpy2
        # weak reference issues where intermediate R objects get
        # garbage-collected between Python calls.
        loc_r = _numpy_to_r_matrix(mesh.loc)
        tv_r = _numpy_to_r_matrix((mesh.tv + 1).astype(float))  # 1-based indexing

        vv_r = _numpy_to_r_matrix((mesh.vv + 1).astype(float)) if mesh.vv.size > 0 else ro.NULL
        tt_r = _numpy_to_r_matrix((mesh.tt + 1).astype(float)) if mesh.tt.size > 0 else ro.NULL

        r_mesh_obj = ro.r(
            """
            function(loc, tv, vv, tt) {
                mesh <- list()
                mesh$loc <- loc
                mesh$graph <- list(tv = tv)
                if (!is.null(vv)) mesh$graph$vv <- vv
                if (!is.null(tt)) mesh$graph$tt <- tt
                mesh$n <- nrow(loc)
                mesh$manifold <- "R2"
                class(mesh) <- c("fm_mesh_2d", "inla.mesh")
                return(mesh)
            }
            """
        )(loc_r, tv_r, vv_r, tt_r)

        # Store in global env so the R-script below can reference it safely
        temp_mesh_id = _store_r_mesh(r_mesh_obj)

        ro.globalenv[".pyinla_xlim"] = FloatVector([float(xlim[0]), float(xlim[1])])
        ro.globalenv[".pyinla_ylim"] = FloatVector([float(ylim[0]), float(ylim[1])])
        ro.globalenv[".pyinla_dims"] = IntVector([int(dims[0]), int(dims[1])])

        r_result = ro.r(
            f"""
            .pyinla_eval <- fm_evaluator(
                {temp_mesh_id},
                xlim = .pyinla_xlim,
                ylim = .pyinla_ylim,
                dims = .pyinla_dims
            )
            .pyinla_A_t <- as(.pyinla_eval$proj$A, "TsparseMatrix")
            list(
                x = .pyinla_eval$x,
                y = .pyinla_eval$y,
                lattice_loc = .pyinla_eval$lattice$loc,
                A_i = .pyinla_A_t@i,
                A_j = .pyinla_A_t@j,
                A_x = .pyinla_A_t@x,
                A_nrow = nrow(.pyinla_eval$proj$A),
                A_ncol = ncol(.pyinla_eval$proj$A)
            )
            """
        )

        x = np.array(list(r_result.rx2("x")))
        y = np.array(list(r_result.rx2("y")))
        lattice_loc = _r_matrix_to_numpy(r_result.rx2("lattice_loc"))

        A_i = np.array(list(r_result.rx2("A_i")), dtype=np.int64)
        A_j = np.array(list(r_result.rx2("A_j")), dtype=np.int64)
        A_x = np.array(list(r_result.rx2("A_x")))
        A_nrow = int(r_result.rx2("A_nrow")[0])
        A_ncol = int(r_result.rx2("A_ncol")[0])
        proj_A = sparse.csr_matrix((A_x, (A_i, A_j)), shape=(A_nrow, A_ncol))

    return FmEvaluator(
        x=x,
        y=y,
        proj_A=proj_A,
        xlim=xlim,
        ylim=ylim,
        dims=dims,
        lattice_loc=lattice_loc,
    )


def fm_evaluate(
    evaluator: FmEvaluator,
    field: np.ndarray,
    reshape: bool = True,
) -> np.ndarray:
    """Project mesh vertex values onto a regular grid.

    This is a pure Python function (no R call needed). It uses the sparse
    projection matrix A from fm_evaluator to interpolate values from mesh
    vertices to grid points via sparse matrix-vector multiplication:

        grid_values = A @ field

    Grid points that fall outside the mesh domain (where A has all-zero
    rows) are set to NaN, matching R's behavior.

    Processing steps:
      1. Flatten the field to a 1D vector.
      2. Validate that field length matches A's column count.
      3. Compute grid_values = proj_A @ field (sparse mat-vec multiply).
      4. Identify grid points outside the mesh (rows with zero sum in A)
         and set those values to NaN.
      5. If reshape=True, reshape from 1D to 2D grid in column-major
         (Fortran) order to match R's storage convention.

    Parameters
    ----------
    evaluator : FmEvaluator
        An evaluator object created by fm_evaluator.
    field : np.ndarray
        Values at mesh vertices, shape (n_vertices,).
    reshape : bool, optional
        If True (default), reshape the result to a 2D grid (nx, ny).
        If False, return a 1D array of length (nx * ny).

    Returns
    -------
    np.ndarray
        Interpolated values at grid points.
        If reshape=True: shape (nx, ny)
        If reshape=False: shape (nx * ny,)

    Examples
    --------
    >>> import numpy as np
    >>> from pyinla.fmesher import fm_mesh_2d, fm_evaluator, fm_evaluate
    >>>
    >>> # Create mesh and evaluator
    >>> locs = np.random.randn(100, 2)
    >>> mesh = fm_mesh_2d(loc=locs, max_edge=[0.5, 1.0], cutoff=0.1)
    >>> proj = fm_evaluator(mesh, xlim=(-3, 3), ylim=(-3, 3), dims=(50, 50))
    >>>
    >>> # Create some field values (e.g., from SPDE spatial effect)
    >>> field = np.sin(mesh.loc[:, 0]) * np.cos(mesh.loc[:, 1])
    >>>
    >>> # Project to grid
    >>> grid_values = fm_evaluate(proj, field)
    >>> print(f"Grid shape: {grid_values.shape}")
    >>>
    >>> # Visualize with matplotlib
    >>> import matplotlib.pyplot as plt
    >>> plt.imshow(grid_values.T, origin='lower',
    ...            extent=[proj.xlim[0], proj.xlim[1], proj.ylim[0], proj.ylim[1]])
    >>> plt.colorbar()
    >>> plt.show()
    """
    field = np.asarray(field).flatten()

    if len(field) != evaluator.proj_A.shape[1]:
        raise ValueError(
            f"Field length ({len(field)}) does not match projection matrix "
            f"columns ({evaluator.proj_A.shape[1]})"
        )

    # Project using sparse matrix multiplication
    grid_values = evaluator.proj_A @ field

    # Set grid points outside the mesh to NaN (matching R's behavior)
    # These are rows where the projection matrix has all zeros (row sum = 0)
    row_sums = np.array(evaluator.proj_A.sum(axis=1)).flatten()
    outside_mask = row_sums == 0
    grid_values[outside_mask] = np.nan

    if reshape:
        # Reshape to 2D grid (nx, ny)
        # Note: R stores in column-major order, so we reshape accordingly
        grid_values = grid_values.reshape(evaluator.shape, order="F")

    return grid_values
