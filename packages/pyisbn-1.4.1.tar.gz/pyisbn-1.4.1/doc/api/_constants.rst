.. currentmodule:: pyisbn

Internal constants
==================

.. automodule:: pyisbn._constants
