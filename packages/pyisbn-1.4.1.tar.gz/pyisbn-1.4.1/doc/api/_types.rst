.. currentmodule:: pyisbn

Type definitions
================

.. automodule:: pyisbn._types
