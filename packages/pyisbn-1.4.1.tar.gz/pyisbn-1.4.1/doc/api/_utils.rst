.. currentmodule:: pyisbn

Internal utilities
==================

.. automodule:: pyisbn._utils
