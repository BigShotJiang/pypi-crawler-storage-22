.. currentmodule:: pyisbn

Handling ISBN-10
================

.. autoclass:: Isbn10
