.. currentmodule:: pyisbn

Handling ISBN-13
================

.. autoclass:: Isbn13
