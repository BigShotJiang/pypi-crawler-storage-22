.. currentmodule:: pyisbn

Handling SBNs
=============

.. autoclass:: Sbn
