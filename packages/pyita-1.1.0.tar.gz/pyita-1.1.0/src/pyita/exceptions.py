"""Custom exceptions for pyita library."""


class PyTAException(Exception):
    """Base exception class for all pyita errors."""
    pass


class PyTAExceptionIndicatorNotFound(PyTAException):
    """Raised when an indicator is not found.
    
    This exception is raised when trying to access an indicator that doesn't exist
    in the indicators directory or cannot be imported.
    
    Attributes:
        indicator_name: Name of the indicator that was not found
    """
    
    def __init__(self, indicator_name):
        """Initialize the exception.
        
        Args:
            indicator_name: Name of the indicator that was not found
        """
        self.indicator_name = indicator_name
        super().__init__(f'Indicator "{self.indicator_name}" not found.')


class PyTAExceptionBadParameterValue(PyTAException):
    """Raised when a parameter has an invalid value.
    
    This exception is raised when an indicator or function receives a parameter
    with an invalid value (e.g., negative period, invalid type, etc.).
    
    Attributes:
        reason: Description of why the parameter value is invalid
    """
    
    def __init__(self, reason):
        """Initialize the exception.
        
        Args:
            reason: Description of why the parameter value is invalid
        """
        self.reason = reason
        super().__init__(f'Bad parameter value: {reason}')


class PyTAExceptionBadSeriesData(PyTAException):
    """Raised when series data is invalid or malformed.
    
    This exception is raised when DataSeries initialization fails due to invalid
    or incompatible data (e.g., missing required columns, incompatible array lengths, etc.).
    
    Attributes:
        reason: Description of why the series data is invalid
    """
    
    def __init__(self, reason):
        """Initialize the exception.
        
        Args:
            reason: Description of why the series data is invalid
        """
        self.reason = reason
        super().__init__(f'Bad series data: {reason}')


class PyTAExceptionTooLittleData(PyTAException):
    """Raised when there is insufficient data for calculation.
    
    This exception is raised when an indicator or function requires more data
    than is available (e.g., period > data length).
    
    Attributes:
        reason: Description of why there is insufficient data
    """
    
    def __init__(self, reason):
        """Initialize the exception.
        
        Args:
            reason: Description of why there is insufficient data
        """
        self.reason = reason
        super().__init__(f'Too little data: {reason}')


class PyTAExceptionDataSeriesNonFound(PyTAException):
    """Raised when a required data series is not found.
    
    This exception is raised when an indicator or function requires a data series
    (e.g., volume, time) that is not present in the Quotes object.
    
    Attributes:
        series_name: Name of the data series that was not found
    """
    
    def __init__(self, series_name):
        """Initialize the exception.
        
        Args:
            series_name: Name of the data series that was not found
        """
        self.series_name = series_name
        super().__init__(f'Data series "{self.series_name}" not found.')


class PyTAExceptionMetadataParseError(PyTAException):
    """Raised when metadata parsing fails.
    
    This exception is raised when parsing indicator metadata from docstring fails.
    
    Attributes:
        indicator_name: Name of the indicator that failed to parse
        reason: Description of why parsing failed
    """
    
    def __init__(self, indicator_name, reason):
        """Initialize the exception.
        
        Args:
            indicator_name: Name of the indicator that failed to parse
            reason: Description of why parsing failed
        """
        self.indicator_name = indicator_name
        self.reason = reason
        super().__init__(f'Failed to parse metadata for indicator "{indicator_name}": {reason}')


class PyTAExceptionMetadataError(PyTAException):
    """Raised when metadata file operations fail.
    
    This exception is raised when reading or accessing metadata file fails.
    
    Attributes:
        reason: Description of why the operation failed
    """
    
    def __init__(self, reason):
        """Initialize the exception.
        
        Args:
            reason: Description of why the operation failed
        """
        self.reason = reason
        super().__init__(f'Metadata error: {reason}')

