import os
from .setup_utils import download_model

if not os.environ.get("PYIXRD_SKIP_MODEL_DOWNLOAD"):  
    download_model()
    
from .symmetry import symmetry

__version__ = "0.1.0"
__all__ = ["symmetry", "__version__"]



