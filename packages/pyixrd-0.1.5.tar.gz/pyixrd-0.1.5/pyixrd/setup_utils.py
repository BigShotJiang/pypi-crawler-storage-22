# pyixrd/setup_utils.py
import os
import sys
import requests
from pathlib import Path
from typing import Optional

try:
    from tqdm import tqdm

    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False

try:
    from huggingface_hub import hf_hub_download, configure_http_backend
    from huggingface_hub.utils import HfHubHTTPError

    HF_HUB_AVAILABLE = True

    def setup_hf_mirror():
        mirror_endpoints = [
            "https://hf-mirror.com",
            "https://hf-mirror.sjtu.edu.cn",
            "https://huggingface.co"
        ]

        for endpoint in mirror_endpoints:
            os.environ["HF_ENDPOINT"] = endpoint
            try:
                response = requests.get(f"{endpoint}/api/models", timeout=3)
                if response.status_code == 200:
                    print(f"[HF Mirror] Using available endpoint: {endpoint}")
                    return endpoint
            except Exception:
                continue

        os.environ["HF_ENDPOINT"] = "https://huggingface.co"
        print("[HF Mirror] No mirror available, use official endpoint")
        return "https://huggingface.co"

    HF_ENDPOINT = setup_hf_mirror()

except ImportError:
    HF_HUB_AVAILABLE = False
    print(
        "[Warning] huggingface_hub not installed, use requests with mirror url (install it for better experience: pip install huggingface_hub)")

    def convert_hf_url_to_mirror(url: str) -> str:
        mirror = "https://hf-mirror.com"
        if "huggingface.co" in url:
            return url.replace("https://huggingface.co", mirror)
        return url

HF_REPO_ID = "Yi-he/pyixrd"
HF_REVISION = "main"

MODEL_FILES = [
    {"name": "crystal_system", "filename": "crystal_system.pth"},
    {"name": "space_group", "filename": "space_group.pth"}
]

# save path: site-packages/pyixrd/utils
def get_model_path(model_name: str) -> Path:
    try:
        import pyixrd
        pkg_dir = Path(pyixrd.__file__).parent
    except ImportError:
        pkg_dir = Path.home() / ".pyixrd"
    model_path = pkg_dir / "utils" / f"{model_name}.pth"
    model_path.parent.mkdir(parents=True, exist_ok=True)
    return model_path

def download_single_model(model_info: dict) -> bool:
    model_name = model_info["name"]
    model_filename = model_info["filename"]
    model_path = get_model_path(model_name)

    if model_path.exists() and model_path.stat().st_size > 1024:
        print(f"Model already exists: {model_path}")
        return True

    print(f"\nStart downloading {model_name}.pth...")
    try:
        if HF_HUB_AVAILABLE:
            downloaded_path = hf_hub_download(
                repo_id=HF_REPO_ID,
                filename=model_filename,
                revision=HF_REVISION,
                endpoint=HF_ENDPOINT,
                local_dir=str(model_path.parent),
                local_dir_use_symlinks=False,  
                resume_download=True, 
                progress=TQDM_AVAILABLE  
            )
            if Path(downloaded_path).resolve() == model_path.resolve():
                print(f"\nFinished: {model_path}")
                return True
            else:
                Path(downloaded_path).rename(model_path)
                print(f"\nFinished (moved to target path): {model_path}")
                return True

        else:
            original_url = f"https://huggingface.co/{HF_REPO_ID}/resolve/{HF_REVISION}/{model_filename}"
            mirror_url = convert_hf_url_to_mirror(original_url)

            headers = {}
            downloaded_size = 0
            if model_path.exists() and model_path.stat().st_size > 0:
                downloaded_size = model_path.stat().st_size
                headers["Range"] = f"bytes={downloaded_size}-"

            response = requests.get(
                mirror_url,
                stream=True,
                headers=headers,
                allow_redirects=True,
                timeout=30 
            )
            response.raise_for_status()

            if "Content-Range" in response.headers:
                total_size = int(response.headers["Content-Range"].split("/")[-1])
            else:
                total_size = int(response.headers.get("content-length", 0))

            if total_size == 0:
                print(f"Warning: Unable to get size of {model_name}.pth, skip download")
                return False

            mode = "ab" if downloaded_size > 0 else "wb"
            with open(model_path, mode) as f:
                pbar = None
                if TQDM_AVAILABLE:
                    pbar = tqdm(
                        desc=str(model_path),
                        total=total_size,
                        initial=downloaded_size,
                        unit="B",
                        unit_scale=True,
                        unit_divisor=1024,
                        file=sys.stdout,
                    )
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        if pbar:
                            pbar.update(len(chunk))
                if pbar:
                    pbar.close()

            print(f"\nFinished: {model_path}")
            return True

    except (Exception, HfHubHTTPError) as e:
        error_msg = f"\nError: Failed to download {model_name}.pth (manual path: {model_path}): {str(e)}"
        print(error_msg)
        if model_path.exists() and model_path.stat().st_size < 1024:
            model_path.unlink()
            print(f"Removed invalid file: {model_path}")
        return False

def download_model():
    if HF_HUB_AVAILABLE:
        setup_hf_mirror()

    all_success = True
    for model_info in MODEL_FILES:
        if not download_single_model(model_info):
            all_success = False

    if all_success:
        print("\n✅  All models downloaded successfully!")
    else:
        print("\n⚠️  Some models failed to download, please manually download to the specified path.")
        print("\nManual download info:")
        for model_info in MODEL_FILES:
            model_name = model_info["name"]
            model_path = get_model_path(model_name)
            if HF_HUB_AVAILABLE:
                manual_url = f"{HF_ENDPOINT}/{HF_REPO_ID}/resolve/{HF_REVISION}/{model_info['filename']}"
            else:
                manual_url = convert_hf_url_to_mirror(
                    f"https://huggingface.co/{HF_REPO_ID}/resolve/{HF_REVISION}/{model_info['filename']}")
            print(f"- {model_name}.pth: {manual_url} (save to: {model_path})")

