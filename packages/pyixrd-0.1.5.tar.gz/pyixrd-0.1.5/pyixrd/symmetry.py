import torch
import torch.nn as nn
import numpy as np
import os

class BiDepthConv_add(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=(1, 3), stride=(1, 1), padding=(0, 1)):
        super(BiDepthConv_add, self).__init__()
        self.depthwise = nn.Conv2d(in_channels, in_channels, kernel_size=kernel_size, stride=stride, padding=padding,
                                   groups=in_channels)
        self.pointwise = nn.Conv2d(in_channels, out_channels, kernel_size=(1, 1))
        self.bn = nn.BatchNorm2d(in_channels)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        identity = x

        out_forward = self.depthwise(x)
        out_forward = self.pointwise(out_forward)

        x_flipped = torch.flip(x, dims=[3])
        out_backward = self.depthwise(x_flipped)
        out_backward = self.pointwise(out_backward)
        out_backward = torch.flip(out_backward, dims=[3])

        out = out_forward + out_backward
        atten = identity + out
        return atten

class MultiScaleCNN(nn.Module):
    def __init__(self, classes_num, n_channel):
        super(MultiScaleCNN, self).__init__()
        # Shared initial convolution block
        self.shared_conv = nn.Sequential(
            nn.Conv2d(n_channel, 32, kernel_size=(1, 25), stride=(1, 1), padding=(0, 12)),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=(1, 3), stride=(1, 3))
        )

        # Branch 1: smaller kernel size
        self.branch1 = nn.Sequential(
            BiDepthConv_add(32, 32),
            nn.Conv2d(32, 64, kernel_size=(1, 32), stride=(1, 1), padding=(0, 16)),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=(1, 3), stride=(1, 3)),

            BiDepthConv_add(64, 64),
            nn.Conv2d(64, 128, kernel_size=(1, 32), stride=(1, 1), padding=(0, 16)),
            nn.BatchNorm2d(128),
            nn.ReLU(),

            BiDepthConv_add(128, 128),
            nn.Conv2d(128, 256, kernel_size=(1, 32), stride=(1, 1), padding=(0, 16)),
            nn.BatchNorm2d(256),
            nn.ReLU(),

            BiDepthConv_add(256, 256),
            nn.Conv2d(256, 512, kernel_size=(1, 32), stride=(1, 1), padding=(0, 16)),
            nn.BatchNorm2d(512),
            nn.ReLU(),

            nn.AdaptiveMaxPool2d((1, 1))
        )

        # Branch 2: medium kernel size
        self.branch2 = nn.Sequential(
            BiDepthConv_add(32, 32),
            nn.Conv2d(32, 64, kernel_size=(1, 64), stride=(1, 1), padding=(0, 32)),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=(1, 3), stride=(1, 3)),

            BiDepthConv_add(64, 64),
            nn.Conv2d(64, 128, kernel_size=(1, 64), stride=(1, 1), padding=(0, 32)),
            nn.BatchNorm2d(128),
            nn.ReLU(),

            BiDepthConv_add(128, 128),
            nn.Conv2d(128, 256, kernel_size=(1, 64), stride=(1, 1), padding=(0, 32)),
            nn.BatchNorm2d(256),
            nn.ReLU(),

            BiDepthConv_add(256, 256),
            nn.Conv2d(256, 512, kernel_size=(1, 64), stride=(1, 1), padding=(0, 32)),
            nn.BatchNorm2d(512),
            nn.ReLU(),

            nn.AdaptiveMaxPool2d((1, 1))
        )

        # Branch 3: larger kernel size
        self.branch3 = nn.Sequential(
            BiDepthConv_add(32, 32),
            nn.Conv2d(32, 64, kernel_size=(1, 128), stride=(1, 1), padding=(0, 64)),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=(1, 3), stride=(1, 3)),

            BiDepthConv_add(64, 64),
            nn.Conv2d(64, 128, kernel_size=(1, 128), stride=(1, 1), padding=(0, 64)),
            nn.BatchNorm2d(128),
            nn.ReLU(),

            BiDepthConv_add(128, 128),
            nn.Conv2d(128, 256, kernel_size=(1, 128), stride=(1, 1), padding=(0, 64)),
            nn.BatchNorm2d(256),
            nn.ReLU(),

            BiDepthConv_add(256, 256),
            nn.Conv2d(256, 512, kernel_size=(1, 128), stride=(1, 1), padding=(0, 64)),
            nn.BatchNorm2d(512),
            nn.ReLU(),

            nn.AdaptiveMaxPool2d((1, 1))
        )
        self.fc = nn.Sequential(
            nn.Linear(512 * 3, 512),
            nn.ReLU(),
            nn.Linear(512, classes_num)
        )

    def forward(self, x):
        x = x.unsqueeze(0).unsqueeze(2)
        x = self.shared_conv(x)
        branch1_out = self.branch1(x).flatten(start_dim=1)
        branch2_out = self.branch2(x).flatten(start_dim=1)
        branch3_out = self.branch3(x).flatten(start_dim=1)
        concat_out = torch.cat([branch1_out, branch2_out, branch3_out], dim=1)
        output = self.fc(concat_out)
        return output

def gaussian(mean=0, std=0.6, max_attempts=100):
    for _ in range(max_attempts):
        num = np.random.normal(mean, std)
        if num > 0:
            return round(float(num), 3)
    return 1e-3

def get_result_xrd():
    angle = [round(0.01 * i + 5.0, 2) for i in range(8501)]
    result_xrd = {i: gaussian(mean=0, std=0.6) for i in angle}
    return result_xrd

def normalize_dict_values(dictionary):
    if not dictionary:
        raise FileNotFoundError(f"File data is empty!")

    values = list(dictionary.values())
    max_val = max(values)
    min_val = min(values)

    if max_val == min_val:
        return {key: 0.0 for key, value in dictionary.items()}

    normalized_dict = {key: round(((value - min_val) / (max_val - min_val) * 100), 3) for key, value in
                       dictionary.items()}
    return normalized_dict

def get_xrd(origin_xrd):
    result_xrd = get_result_xrd()
    for k in origin_xrd.keys():
        if k in result_xrd.keys():
            result_xrd[k] = origin_xrd[k]
    return result_xrd

def load_data(filename):
    if not os.path.exists(filename):
        raise FileNotFoundError(f"Data unavailable: {filename}")

    origin_xrd = {}
    with open(filename, 'r') as f:
        for line_idx, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            # Test two separators: comma+space or comma
            parts = line.strip().split(', ')
            if len(parts) != 2:
                parts = line.strip().split(',')

            if len(parts) == 2:
                angle = round(float(parts[0]), 2)
                d_value = round(float(parts[1]), 3)
                origin_xrd[angle] = d_value
            else:
                continue

    origin_xrd = normalize_dict_values(origin_xrd)
    result_xrd = get_xrd(origin_xrd)

    sorted_items = sorted(result_xrd.items(), key=lambda x: x[0])
    angles = [item[0] for item in sorted_items]
    values = [item[1] for item in sorted_items]

    all_data = np.array([values, angles])
    test_data = torch.tensor(all_data, dtype=torch.float32)
    return test_data

def load_model(flag):
    cs_model_path = r'./pyixrd/utils/crystal_system.pth'
    sg_model_path = r'./pyixrd/utils/space_group.pth'

    if flag == 'crystal system':
        model = MultiScaleCNN(classes_num=7, n_channel=2)
        cs_checkpoint = torch.load(cs_model_path, map_location=torch.device('cpu'))
        model.load_state_dict(cs_checkpoint['model_state_dict'])
    elif flag == 'space group':
        model = MultiScaleCNN(classes_num=230, n_channel=2)
        sg_checkpoint = torch.load(sg_model_path, map_location=torch.device('cpu'))
        model.load_state_dict(sg_checkpoint)

    return model

def test(model, data_tensor, flag: str = 'crystal system',k: int = None):
    model.eval()
    cs = {1: 'Triclinic', 2: 'Monoclinic', 3: 'Orthorhombic', 4: 'Tetragonal', 5: 'Trigonal', 6: 'Hexagonal',
          7: 'Cubic'}
    sg = {1: 'P1', 2: 'P-1', 3: 'P121', 4: 'P12_1-1', 5: 'C121', 6: 'P1m1', 7: 'P1c1', 8: 'C1m1', 9: 'C1c1',
          10: 'P12/m1', 11: 'P12_1/m1', 12: 'C12/m1', 13: 'P12/c1', 14: 'P12_1/c1', 15: 'C12/c1', 16: 'P222',
          17: 'P222_1', 18: 'P2_12_12', 19: 'P2_1-2_12-1', 20: 'C222_1', 21: 'C222', 22: 'F222', 23: 'I222',
          24: 'I2_1-2_12-1', 25: 'Pmm2', 26: 'Pmc2_1', 27: 'Pcc2', 28: 'Pma2', 29: 'Pca2_1', 30: 'Pnc2', 31: 'Pmn2_1',
          32: 'Pba2', 33: 'Pna2_1', 34: 'Pnn2', 35: 'Cmm2', 36: 'Cmc2_1', 37: 'Ccc2', 38: 'Amm2', 39: 'Aem2',
          40: 'Ama2', 41: 'Aea2', 42: 'Fmm2', 43: 'Fdd2', 44: 'Imm2', 45: 'Iba2', 46: 'Ima2', 47: 'Pmmm', 48: 'Pnnn1',
          49: 'Pccm', 50: 'Pban',
          51: 'Pmma', 52: 'Pnna', 53: 'Pmna', 54: 'Pcca', 55: 'Pbam', 56: 'Pccn', 57: 'Pbcm', 58: 'Pnnm', 59: 'Pmmn',
          60: 'Pbcn', 61: 'Pbca', 62: 'Pnma', 63: 'Cmcm', 64: 'Cmce', 65: 'Cmmm', 66: 'Cccm', 67: 'Cmme', 68: 'Ccce',
          69: 'Fmmm', 70: 'Fddd1', 71: 'Immm', 72: 'Ibam', 73: 'Ibca', 74: 'Imma', 75: 'P4', 76: 'P4_1', 77: 'P4_2',
          78: 'P4_3', 79: 'I4', 80: 'I4_1', 81: 'P-4', 82: 'I-4', 83: 'P4/m', 84: 'P4_2/m', 85: 'P4/n1', 86: 'P4_2/n',
          87: 'I4/m', 88: 'I4_1/a', 89: 'P422', 90: 'P42_1-2', 91: 'P4_12-2', 92: 'P4_1-2_1-2', 93: 'P4_22-2',
          94: 'P4_2-2_1-2', 95: 'P4_32-2', 96: 'P4_3-2_1-2', 97: 'I422', 98: 'I4_12-2', 99: 'P4mm', 100: 'P4bm',
          101: 'P4_2cm', 102: 'P4_2nm', 103: 'P4cc', 104: 'P4nc', 105: 'P4_2mc', 106: 'P4_2bc', 107: 'I4mm',
          108: 'I4cm', 109: 'I4_1md', 110: 'I4_1cd', 111: 'P-42m', 112: 'P-42c', 113: 'P-42_1m', 114: 'P-42_1c',
          115: 'P-4m2', 116: 'P-4c2', 117: 'P-4b2', 118: 'P-4n2', 119: 'I-4m2', 120: 'I-4c2', 121: 'I-42m',
          122: 'I-42d', 123: 'P4/mmm', 124: 'P4/mcc', 125: 'P4/nbm1', 126: 'P4/nnc1', 127: 'P4/mbm', 128: 'P4/mnc',
          129: 'P4/nmm1', 130: 'P4/ncc1', 131: 'P4_2/mmc', 132: 'P4_2/mcm', 133: 'P4_2/nbc', 134: 'P4_2/nnm',
          135: 'P4_2/mbc', 136: 'P4_2/mnm', 137: 'P4_2/nmc', 138: 'P4_2/ncm', 139: 'I4/mmm', 140: 'I4/mcm',
          141: 'I4_1/amd', 142: 'I4_1/acd',
          143: 'P3', 144: 'P3_1', 145: 'P3_2', 146: 'R3', 147: 'P-3', 148: 'R-3', 149: 'P312', 150: 'P321',
          151: 'P3_11-2', 152: 'P3_12-1', 153: 'P3_21-2', 154: 'P3_22-1', 155: 'R32', 156: 'P3m1', 157: 'P31m',
          158: 'P3c1', 159: 'P31c', 160: 'R3m', 161: 'R3c', 162: 'P-31m', 163: 'P-31c', 164: 'P-3m1', 165: 'P-3c1',
          166: 'R-3m', 167: 'R-3c', 168: 'P6', 169: 'P6_1', 170: 'P6_5', 171: 'P6_2', 172: 'P6_4', 173: 'P6_3',
          174: 'P-6', 175: 'P6/m', 176: 'P6_3/m', 177: 'P622', 178: 'P6_12-2', 179: 'P6_52-2', 180: 'P6_22-2',
          181: 'P6_42-2', 182: 'P6_32-2', 183: 'P6mm', 184: 'P6cc', 185: 'P6_3cm', 186: 'P6_3mc', 187: 'P-6m2',
          188: 'P-6c2', 189: 'P-62m',
          190: 'P-62c', 191: 'P6/mmm', 192: 'P6/mcc', 193: 'P6_3/mcm', 194: 'P6_3/mmc', 195: 'P23', 196: 'F23',
          197: 'I23', 198: 'P2_1-3', 199: 'I2_1-3', 200: 'Pm-3', 201: 'Pn-31', 202: 'Fm-3', 203: 'Fd-31', 204: 'Im-3',
          205: 'Pa-3', 206: 'Ia-3', 207: 'P432', 208: 'P4_23-2', 209: 'F432', 210: 'F4_13-2', 211: 'I432',
          212: 'P4_33-2', 213: 'P4_13-2', 214: 'I4_13-2', 215: 'P-43m', 216: 'F-43m', 217: 'I-43m', 218: 'P-43n',
          219: 'F-43c', 220: 'I-43d', 221: 'Pm-3m', 222: 'Pn-3n1', 223: 'Pm-3n', 224: 'Pn-3m1', 225: 'Fm-3m',
          226: 'Fm-3c', 227: 'Fd-3m1', 228: 'Fd-3c1', 229: 'Im-3m', 230: 'Ia-3d'}

    if not k:
        if flag == 'crystal system':
            k = 3
        elif flag == 'space group':
            k = 5
    else:
        if flag == 'crystal system' and (k>7 or k<1):
            raise ValueError("topk should be greater than 0 and less than or equal to 7")
        elif flag == 'space group' and (k>230 or k<1):
            raise ValueError("topk should be greater than 0 and less than or equal to 230")

    with torch.no_grad():
        outputs = model(data_tensor)
        _, topk_indices = torch.topk(outputs, k, dim=1)

    topk = topk_indices.tolist()
    rows = len(topk)
    columns = len(topk[0])
    result = np.full((rows, columns), 'empty', dtype=object)
    for i in range(rows):
        for j in range(columns):
            if flag == 'crystal system':
                result[i][j] = cs[int(topk[i][j]) + 1]
            elif flag == 'space group':
                t = sg[int(topk[i][j]) + 1] + ' (' + str(int(topk[i][j]) + 1) + ')'
                result[i][j] = t

    return result

def symmetry(data, level:str='crystal system', topk:int=None):
    if type(level) is str and level in ['crystal system', 'space group']:
        if (not topk) or (type(topk) is int):
            model = load_model(level)
            data_tensor = load_data(data)
            topk_pred = test(model, data_tensor, flag=level, k=topk)
            return topk_pred.tolist()[0]
        else:
            raise TypeError("topk should be 'int'")
    else:
        raise ValueError('level should be "crystal system" or "space group"')
