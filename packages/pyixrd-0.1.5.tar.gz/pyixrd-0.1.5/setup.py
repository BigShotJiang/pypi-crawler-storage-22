from setuptools import setup, find_packages
from setuptools.command.install import install
import sys
import os

class PostInstallCommand(install):
    def run(self):
        install.run(self)
        is_build_phase = any(cmd in sys.argv for cmd in ["sdist", "bdist_wheel", "build"])
        if is_build_phase:
            print("\ndownload pass")
            return

        try:
            sys.path.insert(0, self.install_lib)
            from pyixrd.setup_utils import download_model
            download_model()
        except Exception as e:
            print(f"\nModel download failed!")
            print("Model can be manually downloaded：python -c 'from pyixrd.setup_utils import download_model; download_model()'")


setup(
    name='pyixrd',
    version='0.1.5',
    description="Toolkit for crystal XRD analysis",
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    author='Yihe Pang',
    author_email='pangyh@ihep.ac.cn',
    maintainer='Jing Li',
    maintainer_email='2559096110@qq.com',
    license='MIT License',
    packages=find_packages(),
    cmdclass={"install": PostInstallCommand},
    python_requires='>=3.8',
    install_requires=['torch','numpy',"requests>=2.25.0","tqdm>=4.60.0","huggingface_hub>=0.19.0"],
    zip_safe=False,
)


