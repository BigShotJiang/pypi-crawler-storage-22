from __future__ import annotations

from ..protocols import PhonemeProcessor

__all__ = ["PhonemeProcessor"]
