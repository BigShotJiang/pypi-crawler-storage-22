from __future__ import annotations

from ..protocols import Synthesizer

__all__ = ["Synthesizer"]
