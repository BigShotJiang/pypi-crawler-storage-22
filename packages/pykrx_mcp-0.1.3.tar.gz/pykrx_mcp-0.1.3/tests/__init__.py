"""Tests for pykrx-mcp."""
