# Stub file for type hints

import serial
import serial.tools.list_ports

def scan_available_ports(): ...
def to_bytes(content): ...
