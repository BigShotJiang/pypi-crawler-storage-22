import logging
logger = logging.getLogger("pylambdatasks")
logger.addHandler(logging.NullHandler())
logger.setLevel(logging.NOTSET)