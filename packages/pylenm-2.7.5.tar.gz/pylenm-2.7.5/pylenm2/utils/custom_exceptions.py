class UnreachableCodeError(Exception):
    """Exception raised when an unreachable code path is executed."""
    pass