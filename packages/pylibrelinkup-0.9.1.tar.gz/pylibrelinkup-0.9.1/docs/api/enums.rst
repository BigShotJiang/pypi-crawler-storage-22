Enums
=====

.. automodule:: pylibrelinkup.api_url

.. autoenum:: pylibrelinkup.api_url.APIUrl
