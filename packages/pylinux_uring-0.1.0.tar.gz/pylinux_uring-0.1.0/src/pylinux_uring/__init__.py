def hello() -> str:
    return "Hello from pylinux-uring!"
