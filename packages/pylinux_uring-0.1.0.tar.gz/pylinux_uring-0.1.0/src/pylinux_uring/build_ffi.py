import os
from cffi import FFI


ffibuilder = FFI()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CSRC_DIR = os.path.normpath(os.path.join(BASE_DIR, "../../csrc"))

with open(os.path.join(CSRC_DIR, "wrapper.h"), "r") as f:
    ffibuilder.cdef(f.read())

ffibuilder.set_source(
    "pylinux_uring._uring",
    '#include "wrapper.h"',
    sources=[os.path.join(CSRC_DIR, "wrapper.c")],
    include_dirs=[CSRC_DIR],
    libraries=["uring"],     # WICHTIG: Linkt gegen liburing (System-Library)
)

if __name__ == "__main__":
    ffibuilder.compile(verbose=True)
