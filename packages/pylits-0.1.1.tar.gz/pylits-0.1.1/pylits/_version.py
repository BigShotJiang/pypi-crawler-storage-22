__version__ = "0.1.1"

ENGINE_VERSION = "2025-07-08" # YYYY-MM-DD