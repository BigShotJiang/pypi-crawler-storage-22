"""
The pymagnetos package.

It provides analysis tools for high magnetic field experiments performed at LNCMI-T.

Experiment-specific library are specialized implementations of the base classes found in
the `core` subpackage. They should be generic enough to be used to build any pipeline
relying on a 'configuration > analysis > store' workflow :

1. Configuration : handled by the `Config` object, which uses `pydantic` models to read
and validate TOML configuration files. One needs to define the `pydantic` models. The
`BaseConfig` object provides the TOML parser and writer and interface with `pydantic`.
2. Analysis : handled by the `Processor` objects. It is initialized with the path to a
configuration file. The `BaseProcessor` object provides the base framework and some
shared methods related to magnetic field computation.
3. Store : the `Processor` objects uses the `nexusformat` library to store data
in-memory. The whole data structure can be easily dumped to a NeXus-compliant HDF5 file,
and can be consolidated (i.e. add sample- and experiment-related metadata) via the
configuration file. The output NeXus file is self-contained : it has the raw and
processed data, along with the analysis configuration. The `Processor` objects can be
initialized with such a file instead of a configuration file.

Graphical user interface
------------------------
pymagnetos provides graphical applications built with PyQt6. Each subpackages have a
`gui` submodule (that are not imported by default). The `core.gui` module contains the
base components to build an app with a configuration panel, a zone with graphs, action
buttons and a log text box. It interfaces with a `Worker` object, which is a `Processor`
instance set in its own thread. The components are Qt widgets that can be built upon and
re-used.

Available subpackages
---------------------
- `core` : base classes and components.
- `pytdo` : a library for TDO experiments.
- `pyuson` : a library for ultra-sound experiments.

Available modules
-----------------
- `sp` : signal processing functions.
- `utils` : utilities for dictionary manipulation.
- `cli` : used to run the applications.
"""

import nexusformat.nexus as nx

from . import core, pytdo, pyuson
from .core import sp, utils

__all__ = ["core", "pytdo", "pyuson", "sp", "utils"]

# Configure NeXus globally
nx.nxsetconfig(compression=None, encoding="utf-8", lock=0, memory=8000, recursive=True)
