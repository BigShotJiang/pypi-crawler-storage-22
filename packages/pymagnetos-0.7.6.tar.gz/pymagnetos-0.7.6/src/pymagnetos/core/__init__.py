"""
The core subpackage, containing base classes and components.

Those are meant to be subclassed to build experiment-specific objects.

Provides
--------
- `BaseConfig` : the base class for the `Config` object.
- `BaseProcessor` : the base class for the `Processor` object.
- `BaseData` : NeXus base interface.
- `DataRaw` : NeXus interface for a raw data container.
- `DataProcessed` : NeXus interface for a processed data container.
- `config_models` : `pydantic` models to define the configuration.
- `sp` : signal processing functions.
- `utils` : dictionary manipulation utility functions.
"""

from . import config_models, utils
from . import signal_processing as sp
from ._baseprocessor import BaseProcessor
from ._config import BaseConfig
from ._data import BaseData, DataProcessed, DataRaw

__all__ = [
    "BaseConfig",
    "BaseProcessor",
    "BaseData",
    "DataProcessed",
    "DataRaw",
    "config_models",
    "sp",
    "utils",
]
