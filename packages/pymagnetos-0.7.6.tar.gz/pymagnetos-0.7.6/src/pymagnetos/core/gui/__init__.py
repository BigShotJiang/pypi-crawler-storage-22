"""Shared Graphical User Interface (GUI) components."""

from . import widgets
from .main import BaseMainWindow

__all__ = ["BaseMainWindow", "widgets"]
