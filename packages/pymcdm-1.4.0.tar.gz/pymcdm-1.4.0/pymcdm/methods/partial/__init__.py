from .promethee_i import PROMETHEE_I

__all__ = ['PROMETHEE_I']