class InvalidMdoc(Exception):
    """
    """


class UnsupportedMsoDataFormat(Exception):
    pass


class MsoPrivateKeyRequired(Exception):
    pass


class MsoX509ChainNotFound(Exception):
    pass
