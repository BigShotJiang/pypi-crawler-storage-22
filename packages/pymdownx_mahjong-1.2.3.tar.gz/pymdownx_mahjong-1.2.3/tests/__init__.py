"""Tests for pymdownx-mahjong."""
