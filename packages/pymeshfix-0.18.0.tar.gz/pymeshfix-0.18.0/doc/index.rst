.. include:: ../README.rst

.. toctree::
   :hidden:

   self

.. toctree::
   :maxdepth: 2
   :caption: Examples
   :hidden:

   examples/index

.. toctree::
   :maxdepth: 2
   :caption: API Reference
   :hidden:

   api
