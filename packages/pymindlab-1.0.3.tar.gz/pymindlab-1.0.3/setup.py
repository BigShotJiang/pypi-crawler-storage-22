from setuptools import find_packages
from setuptools import setup
import os

root_path = os.path.dirname(__file__)
require = open(os.path.join(root_path, 'requirements.txt')).readlines()

setup(
    name='PyMINDLab',
    version='1.0.3',
    url='https://github.com/housenli/PyMIND',
    description='Python implementation of Multiscale Nemirovski Dantzig Estimators',
    packages=find_packages(),
    package_dir={'PyMINDLab': 'pymindlab'},
    author={'Leo Claus Weber', 'Housen Li'},
    install_requires=[require]
)
