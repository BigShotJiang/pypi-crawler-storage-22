# Mirage-Core

日本語文章解析エンジン。伝統的な自然言語処理（NLP）とLLMを組み合わせたハイブリッドアーキテクチャを採用しています。

## 🚀 クイックスタート

### Docker Hub から実行（最も簡単）

```bash
# Docker Hub から最新イメージを取得
docker pull stayforge/mirage:latest

# コンテナを起動
docker run -d -p 8000:8000 stayforge/mirage:latest

# API にアクセス
curl http://localhost:8000/analysis/health
```

### Docker Compose で実行

```bash
# リポジトリをクローン
git clone https://github.com/[your-repo]/Mirage-Core.git
cd Mirage-Core

# Docker Compose で起動
docker-compose up -d

# API にアクセス
curl http://localhost:8000/analysis/health
```

詳細は [DOCKER.md](./DOCKER.md) を参照

### ローカル環境で実行

```bash
# 依存関係をインストール
pip install -r requirements.txt

# UniDic 辞書をダウンロード（初回のみ）
python -m unidic download

# API サーバーを起動
python main.py
```

## 📚 API ドキュメント

起動後、以下の URL でアクセス：

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **API ガイド**: [API.md](./API.md)

## 🧪 テスト

```bash
# 全テストを実行
pytest tests/ -v

# API テストのみ
pytest tests/test_api.py -v

# 分析機能テストのみ
pytest tests/test_analysis.py -v
```

## 🔄 CI/CD

GitHub Actions による自動ビルド・デプロイを設定済み

- **main ブランチ**: `stayforge/mirage:latest`
- **dev ブランチ**: `stayforge/mirage:dev`
- **バージョンタグ**: `stayforge/mirage:v1.0.0`

セットアップ方法: [CI_SETUP.md](./CI_SETUP.md)

## 🛠️ Tools

A tool to convert other formats (mainly Aozora Bunko) to .MDI

Supported file(text) formats:
- Plain text (.txt)
- Markdown (.md)
- [HTML](./samples/蜃気楼/芥川龍之介-蜃気楼.html)（青空文庫）
- [illusion Markdown](https://github.com/Iktahana/illusions/blob/main/MDI.md) (.imd)

