"""
Mirage API
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routers import analysis

# FastAPIアプリケーション作成 (Create FastAPI application)
app = FastAPI(
    title="Mirage API",
    description="日本語テキスト形態素・語彙分析API (Japanese Text Morphological & Lexical Analysis API)",
    version="0.1.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS設定 (CORS configuration)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ルーター登録 (Register routers)
app.include_router(analysis.router)


@app.get("/", tags=["root"])
async def root():
    """
    ルートエンドポイント
    (Root endpoint)
    """
    return {
        "message": "Mirage API",
        "version": "0.1.0",
        "docs": "/docs",
        "health": "/analysis/health"
    }
