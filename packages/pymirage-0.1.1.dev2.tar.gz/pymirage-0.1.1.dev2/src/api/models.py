"""
APIリクエスト・レスポンスモデル
(API Request/Response Models)
"""
from pydantic import BaseModel, Field


class AnalyzeRequest(BaseModel):
    """
    形態素・語彙分析リクエスト
    (Morphological and lexical analysis request)
    """
    text: str = Field(..., description="分析対象のテキスト (Text to analyze)")
    include_positions: bool = Field(
        default=True,
        description="文字位置を含めるか (Whether to include character positions)"
    )


class WordInfo(BaseModel):
    """
    語彙情報
    (Word information)
    """
    surface: str = Field(..., description="表層形 (Surface form)")
    count: int = Field(..., description="出現回数 (Frequency count)")
    pos: str = Field(..., description="品詞 (Part of speech)")
    lemma: str | None = Field(None, description="基本形 (Lemma)")
    positions: list[tuple[int, int]] = Field(
        default_factory=list,
        description="ノード位置 [(インデックス, 品詞ID), ...] (Node positions)"
    )
    char_positions: list[int] = Field(
        default_factory=list,
        description="文字位置 (Character positions in text)"
    )


class AnalyzeResponse(BaseModel):
    """
    分析結果レスポンス
    (Analysis result response)
    """
    total_words: int = Field(..., description="総語彙数 (Total unique words)")
    total_tokens: int = Field(..., description="総形態素数 (Total tokens)")
    words: list[WordInfo] = Field(..., description="語彙リスト (Word list)")


class WordContextRequest(BaseModel):
    """
    語彙文脈取得リクエスト
    (Word context retrieval request)
    """
    text: str = Field(..., description="分析対象のテキスト (Text to analyze)")
    word: str = Field(..., description="検索する語彙 (Word to search)")
    context_length: int = Field(
        default=20,
        ge=5,
        le=100,
        description="前後の文字数 (Characters before/after, 5-100)"
    )


class ContextInfo(BaseModel):
    """
    文脈情報
    (Context information)
    """
    position: int = Field(..., description="文字位置 (Character position)")
    before: str = Field(..., description="前の文脈 (Context before)")
    word: str = Field(..., description="語彙 (Word)")
    after: str = Field(..., description="後の文脈 (Context after)")


class WordContextResponse(BaseModel):
    """
    語彙文脈レスポンス
    (Word context response)
    """
    word: str = Field(..., description="検索した語彙 (Searched word)")
    count: int = Field(..., description="出現回数 (Occurrence count)")
    contexts: list[ContextInfo] = Field(..., description="文脈リスト (Context list)")


class FilterByPosRequest(BaseModel):
    """
    品詞フィルタリングリクエスト
    (POS filtering request)
    """
    text: str = Field(..., description="分析対象のテキスト (Text to analyze)")
    pos_tags: list[str] = Field(
        ...,
        description="品詞タグリスト（例: ['名詞', '動詞']）(POS tags, e.g., ['名詞', '動詞'])"
    )
    limit: int | None = Field(
        default=None,
        ge=1,
        le=1000,
        description="最大取得数 (Maximum results, 1-1000)"
    )
