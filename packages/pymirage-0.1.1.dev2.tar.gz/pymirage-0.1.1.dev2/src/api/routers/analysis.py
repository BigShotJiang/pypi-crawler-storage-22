"""
語彙分析APIルーター
(Lexical Analysis API Router)
"""
from fastapi import APIRouter, HTTPException
from pymirage.analysis.morphological import MorphologicalAnalysis
from pymirage.analysis.words import WordsAnalysis

from ..models import (
    AnalyzeRequest,
    AnalyzeResponse,
    WordInfo,
    WordContextRequest,
    WordContextResponse,
    ContextInfo,
    FilterByPosRequest,
)

router = APIRouter(prefix="/analysis", tags=["analysis"])


@router.post("/words", response_model=AnalyzeResponse, summary="語彙分析")
async def analyze_words(request: AnalyzeRequest):
    """
    テキストの語彙統計分析を実行
    (Execute lexical statistics analysis on text)
    
    - **text**: 分析対象のテキスト (Text to analyze)
    - **include_positions**: 文字位置を含めるか (Include character positions)
    
    Returns:
        語彙統計結果 (Lexical statistics results)
    """
    try:
        # 形態素解析 (Morphological analysis)
        morphological = MorphologicalAnalysis(request.text)
        nodes = morphological.analyze()
        
        # 語彙統計 (Lexical statistics)
        text_param = request.text if request.include_positions else None
        words_analysis = WordsAnalysis(nodes=nodes, text=text_param)
        data = words_analysis.analyze()
        
        # レスポンス構築 (Build response)
        words_list = []
        for surface, word in data.items():
            word_info = WordInfo(
                surface=surface,
                count=word.count,
                pos=word.unidic_node.feature.pos1 if word.unidic_node else "不明",
                lemma=word.unidic_node.feature.lemma if word.unidic_node else None,
                positions=word.positions,
                char_positions=word.char_positions if request.include_positions else []
            )
            words_list.append(word_info)
        
        # 頻度順にソート (Sort by frequency)
        words_list.sort(key=lambda x: x.count, reverse=True)
        
        return AnalyzeResponse(
            total_words=len(data),
            total_tokens=len(nodes),
            words=words_list
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"分析エラー: {str(e)}")


@router.post("/context", response_model=WordContextResponse, summary="語彙文脈取得")
async def get_word_context(request: WordContextRequest):
    """
    特定の語彙の出現位置とその文脈を取得
    (Get occurrence positions and contexts of a specific word)
    
    - **text**: 分析対象のテキスト (Text to analyze)
    - **word**: 検索する語彙 (Word to search)
    - **context_length**: 前後の文字数 (Characters before/after)
    
    Returns:
        語彙の出現位置と文脈 (Word positions and contexts)
    """
    try:
        # 形態素解析 (Morphological analysis)
        morphological = MorphologicalAnalysis(request.text)
        nodes = morphological.analyze()
        
        # 語彙統計 (Lexical statistics)
        words_analysis = WordsAnalysis(nodes=nodes, text=request.text)
        data = words_analysis.analyze()
        
        # 指定された語彙をチェック (Check if word exists)
        if request.word not in data:
            raise HTTPException(
                status_code=404,
                detail=f"語彙 '{request.word}' はテキスト内に見つかりませんでした"
            )
        
        # 文脈取得 (Get contexts)
        contexts = words_analysis.get_word_context(
            request.word,
            data=data,
            context_length=request.context_length
        )
        
        context_list = [
            ContextInfo(
                position=ctx['position'],
                before=ctx['before'],
                word=ctx['word'],
                after=ctx['after']
            )
            for ctx in contexts
        ]
        
        return WordContextResponse(
            word=request.word,
            count=data[request.word].count,
            contexts=context_list
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"分析エラー: {str(e)}")


@router.post("/filter-pos", response_model=AnalyzeResponse, summary="品詞フィルタリング")
async def filter_by_pos(request: FilterByPosRequest):
    """
    品詞タグで語彙をフィルタリング
    (Filter words by part-of-speech tags)
    
    - **text**: 分析対象のテキスト (Text to analyze)
    - **pos_tags**: 品詞タグリスト（例: ['名詞', '動詞']）(POS tags)
    - **limit**: 最大取得数 (Maximum results)
    
    Returns:
        フィルタリングされた語彙リスト (Filtered word list)
    """
    try:
        # 形態素解析 (Morphological analysis)
        morphological = MorphologicalAnalysis(request.text)
        nodes = morphological.analyze()
        
        # 語彙統計 (Lexical statistics)
        words_analysis = WordsAnalysis(nodes=nodes, text=request.text)
        filtered_data = words_analysis.filter_by_pos(request.pos_tags)
        
        # レスポンス構築 (Build response)
        words_list = []
        for surface, word in filtered_data.items():
            word_info = WordInfo(
                surface=surface,
                count=word.count,
                pos=word.unidic_node.feature.pos1 if word.unidic_node else "不明",
                lemma=word.unidic_node.feature.lemma if word.unidic_node else None,
                positions=word.positions,
                char_positions=word.char_positions
            )
            words_list.append(word_info)
        
        # 頻度順にソート (Sort by frequency)
        words_list.sort(key=lambda x: x.count, reverse=True)
        
        # limit適用 (Apply limit)
        if request.limit:
            words_list = words_list[:request.limit]
        
        return AnalyzeResponse(
            total_words=len(filtered_data),
            total_tokens=len(nodes),
            words=words_list
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"分析エラー: {str(e)}")


@router.get("/health", summary="ヘルスチェック")
async def health_check():
    """
    APIの健全性チェック
    (API health check)
    """
    return {"status": "ok", "service": "lexical-analysis"}
