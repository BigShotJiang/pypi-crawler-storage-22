"""
形態素解析
"""
from pathlib import Path

import fugashi
from fugashi import UnidicNode


class MorphologicalAnalysis:
    """
    Handles the process of performing morphological analysis on input text.

    Provides functionality to analyze and process textual data for linguistic
    structure, typically breaking it into smaller units such as words, stems,
    and affixes.

    :ivar text: The *Plain text* content to be analyzed.
    """

    def __init__(self, text: str):
        self.text = text

        self.tagger = fugashi.Tagger()

    def analyze(self) -> list[UnidicNode]:
        """
        形態素解析
        """
        return self.tagger(self.text)


if __name__ == '__main__':
    current_dir = Path(__file__).parent
    file_path = current_dir / "../../../samples/蜃気楼/蜃気楼.txt"

    with open(file_path, "r", encoding='utf-8') as f:
        text = f.read()

    analysis = MorphologicalAnalysis(text)
    results = analysis.analyze()

    print("=== 全テストケース (All Available Test Cases) ===\n")

    for i, result in enumerate(results, 1):
        print(f"--- トークン {i}: {result.surface} ---")

        # Result オブジェクト属性
        print(f"result.surface:      {result.surface}")
        print(f"result.pos:          {result.pos}")
        print(f"result.feature_raw:  {result.feature_raw}")
        print(f"result.length:       {result.length}")
        print(f"result.rlength:      {result.rlength}")
        print(f"result.posid:        {result.posid}")
        print(f"result.char_type:    {result.char_type}")
        print(f"result.is_unk:       {result.is_unk}")
        print(f"result.white_space:  '{result.white_space}'")
        print(f"result.stat:         {result.stat}")

        # Feature 属性
        print(f"\n# 基本品詞情報")
        print(f"result.feature.pos1:       {result.feature.pos1}")
        print(f"result.feature.pos2:       {result.feature.pos2}")
        print(f"result.feature.pos3:       {result.feature.pos3}")
        print(f"result.feature.pos4:       {result.feature.pos4}")

        print(f"\n# 語彙形式")
        print(f"result.feature.lemma:      {result.feature.lemma}")
        print(f"result.feature.orth:       {result.feature.orth}")
        print(f"result.feature.orthBase:   {result.feature.orthBase}")
        print(f"result.feature.lemma_id:   {result.feature.lemma_id}")

        print(f"\n# 読み情報")
        print(f"result.feature.kana:       {result.feature.kana}")
        print(f"result.feature.kanaBase:   {result.feature.kanaBase}")
        print(f"result.feature.pron:       {result.feature.pron}")
        print(f"result.feature.pronBase:   {result.feature.pronBase}")
        print(f"result.feature.form:       {result.feature.form}")
        print(f"result.feature.formBase:   {result.feature.formBase}")

        print(f"\n# 活用情報 (動詞・形容詞用)")
        print(f"result.feature.cType:      {result.feature.cType}")
        print(f"result.feature.cForm:      {result.feature.cForm}")

        print(f"\n# その他言語学情報")
        print(f"result.feature.goshu:      {result.feature.goshu}")

        print("\n" + "=" * 60 + "\n")

    print(results)
