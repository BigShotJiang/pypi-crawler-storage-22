"""
語彙分析 (Lexical Analysis)
"""
from pathlib import Path
from typing import Any

from fugashi import UnidicNode
from pydantic import BaseModel, ConfigDict, Field

from src.pymirage.analysis.morphological import MorphologicalAnalysis


class Word(BaseModel):
    """
    語彙情報を表すモデル
    (Model representing word information)
    """
    model_config = ConfigDict(arbitrary_types_allowed=True)
    
    surface: str  # 表層形 (Surface form)
    count: int = 1  # 出現回数 (Frequency count)
    positions: list[tuple[int, int]] = Field(default_factory=list)  # (ノードインデックス, 品詞ID) / (Node index, POS ID)
    char_positions: list[int] = Field(default_factory=list)  # 原文における文字位置 (Character positions in original text)
    unidic_node: Any = None  # UnidicNodeオブジェクト (UnidicNode object)


class WordsAnalysis:
    """
    語彙統計分析クラス
    (Lexical statistics analysis class)
    
    形態素解析結果から語彙の出現頻度と位置を統計する。
    (Analyzes frequency and positions of words from morphological analysis results)
    """
    
    def __init__(self, nodes: list[UnidicNode], text: str | None = None):
        """
        Args:
            nodes: 形態素解析結果のノードリスト (List of morphological analysis nodes)
            text: 原文テキスト。Noneの場合は文字位置統計を行わない
                  (Original text. If None, character position analysis is skipped)
        """
        self.nodes = nodes
        self.text = text

    def analyze(self) -> dict[str, Word]:
        """
        語彙統計を実行
        (Execute lexical statistics analysis)
        
        Returns:
            表層形をキーとした語彙情報の辞書
            (Dictionary of word information keyed by surface form)
        """
        data = {}
        
        # テキストが提供されている場合のみ文字位置を計算
        # (Calculate character positions only when text is provided)
        char_positions_map = {}
        if self.text is not None:
            char_positions_map = self._calculate_char_positions()

        for i, node in enumerate(self.nodes, 1):
            surface = node.surface  # キャッシュして属性アクセスを削減 (Cache to reduce attribute access)
            char_pos = char_positions_map.get(i - 1, -1) if self.text is not None else -1

            if surface in data:
                # 既存の語彙：統計を更新 (Existing word: update statistics)
                word = data[surface]
                word.count += 1
                word.positions.append((i, node.posid))
                if self.text is not None and char_pos != -1:
                    word.char_positions.append(char_pos)
            else:
                # 初出現：新規レコードを作成 (First occurrence: create new record)
                char_pos_list = [char_pos] if self.text is not None and char_pos != -1 else []
                data[surface] = Word(
                    surface=surface,
                    count=1,
                    positions=[(i, node.posid)],
                    char_positions=char_pos_list,
                    unidic_node=node
                )

        return data
    
    def _calculate_char_positions(self) -> dict[int, int]:
        """
        原文における各ノードの文字位置を計算
        (Calculate character position for each node in the original text)
        
        Returns:
            ノードインデックス -> 文字位置のマッピング辞書
            (Dictionary mapping node_index -> char_position in text)
        """
        if not self.text:
            return {}
        
        positions = {}
        text_pos = 0
        
        for idx, node in enumerate(self.nodes):
            surface = node.surface
            
            # テキスト内で次の出現位置を検索 (Find the next occurrence in the text)
            found_pos = self.text.find(surface, text_pos)
            
            if found_pos != -1:
                positions[idx] = found_pos
                text_pos = found_pos + len(surface)
            else:
                # 見つからない場合（通常は発生しない）、-1とマーク
                # (If not found (shouldn't happen), mark as -1)
                positions[idx] = -1
        
        return positions
    
    def get_word_context(self, word: str, data: dict[str, Word] | None = None, context_length: int = 20) -> list[dict]:
        """
        語彙の各出現位置の文脈を取得
        (Get context around each occurrence of a word)
        
        Args:
            word: 検索する語彙 (The word to search for)
            data: 事前に解析されたデータ（オプション、Noneの場合はanalyze()を呼び出す）
                  (Pre-analyzed data, optional - calls analyze() if None)
            context_length: 語彙の前後の文字数 (Number of characters before and after the word)
            
        Returns:
            位置と文脈情報を含む辞書のリスト
            (List of dicts with position and context information)
        """
        if data is None:
            data = self.analyze()
            
        if word not in data or self.text is None:
            return []
        
        word_obj = data[word]
        contexts = []
        
        for pos in word_obj.char_positions:
            start = max(0, pos - context_length)
            end = min(len(self.text), pos + len(word) + context_length)
            
            contexts.append({
                'position': pos,
                'before': self.text[start:pos],
                'word': word,
                'after': self.text[pos + len(word):end],
                'full_context': self.text[start:end]
            })
        
        return contexts
    
    def filter_by_pos(self, pos_tags: list[str]) -> dict[str, Word]:
        """
        品詞タグで語彙をフィルタリング
        (Filter words by part-of-speech tags)
        
        Args:
            pos_tags: 含める品詞タグのリスト（例: ['名詞', '動詞']）
                      (List of POS tags to include, e.g., ['名詞', '動詞'])
            
        Returns:
            フィルタリングされた語彙辞書
            (Filtered dictionary of words)
        """
        data = self.analyze()
        return {
            surface: word 
            for surface, word in data.items() 
            if word.unidic_node and word.unidic_node.feature.pos1 in pos_tags
        }


if __name__ == '__main__':
    file_path = Path(__file__).parents[3] / "samples/蜃気楼/蜃気楼.txt"

    with open(file_path, "r", encoding='utf-8') as f:
        text = f.read()

    # 形態素解析 (Morphological analysis)
    analysis = MorphologicalAnalysis(text)
    results = analysis.analyze()

    # 語彙統計（文字位置を含む）(Lexical statistics with character positions)
    wa = WordsAnalysis(text=text, nodes=results)
    data = wa.analyze()

    print(f"総語彙数: {len(data)}")
    print("\n" + "=" * 60)
    print("高頻度語彙統計（上位20語）")
    print("=" * 60)
    sorted_words = sorted(data.values(), key=lambda x: x.count, reverse=True)
    for idx, word in enumerate(sorted_words[:20], 1):
        print(f"{idx:2d}. {word.surface:8s} - 出現 {word.count:3d} 回")
        if word.char_positions:
            # 最初の3つの出現位置を表示 (Show first 3 occurrence positions)
            pos_sample = word.char_positions[:3]
            pos_str = ", ".join(f"{p}文字目" for p in pos_sample)
            if len(word.char_positions) > 3:
                pos_str += f" ... (計{len(word.char_positions)}箇所)"
            print(f"    位置: {pos_str}")
    
    # 例：特定語彙の詳細情報を確認 (Example: Check detailed information of a specific word)
    print("\n" + "=" * 60)
    print("例：'僕' の詳細情報")
    print("=" * 60)
    if '僕' in data:
        word = data['僕']
        print(f"語彙: {word.surface}")
        print(f"出現回数: {word.count}")
        print(f"品詞: {word.unidic_node.feature.pos1}")
        print(f"文字位置: {word.char_positions[:10]}")  # 最初の10箇所を表示 (Show first 10 positions)
        
        # 文脈を表示 (Show context)
        if word.char_positions and text:
            print("\n最初の3箇所の出現位置における文脈:")
            for i, pos in enumerate(word.char_positions[:3], 1):
                start = max(0, pos - 10)
                end = min(len(text), pos + 10)
                context = text[start:end]
                print(f"  {i}. [{pos}] ...{context}...")
