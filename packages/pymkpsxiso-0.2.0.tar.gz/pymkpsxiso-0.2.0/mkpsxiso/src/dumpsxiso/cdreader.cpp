#include "cdreader.h"
#include "platform.h"

cd::IsoReader::IsoReader()
{
}

cd::IsoReader::~IsoReader()
{
    if (filePtr != NULL)
		fclose(filePtr);

}


bool cd::IsoReader::Open(const fs::path& fileName)
{
	Close();

    filePtr = OpenFile(fileName, "rb");

    if (filePtr == NULL)
		return(false);

	fseek(filePtr, 0, SEEK_END);
	totalSectors = ftell(filePtr) / CD_SECTOR_SIZE;
	fseek(filePtr, 0, SEEK_SET);

    if (fread(sectorBuff, CD_SECTOR_SIZE, 1, filePtr) != 1) {
		Close();
		return false;
	}

    currentByte		= 0;
    currentSector	= 0;

    sectorM2F1 = (cd::SECTOR_M2F1*)sectorBuff;
    sectorM2F2 = (cd::SECTOR_M2F2*)sectorBuff;

	return(true);

}

size_t cd::IsoReader::ReadBytes(void* ptr, size_t bytes, bool singleSector)
{
	if (currentSector >= totalSectors) {
		return 0;
	}

	size_t bytesRead = 0;
    char* const dataPtr = (char*)ptr;

    while(bytes > 0)
	{
		const size_t toRead = std::min(F1_DATA_SIZE - currentByte, bytes);

        memcpy(dataPtr+bytesRead, &sectorM2F1->data[currentByte], toRead);

		currentByte += toRead;
		bytesRead += toRead;
		bytes -= toRead;

		if (currentByte >= F1_DATA_SIZE)
		{
			if (singleSector || !PrepareNextSector())
			{
				return bytesRead;
			}
		}
    }

    return bytesRead;

}

size_t cd::IsoReader::ReadBytesXA(void* ptr, size_t bytes, bool singleSector)
{
	if (currentSector >= totalSectors) {
		return 0;
	}

	size_t bytesRead = 0;
    char* const dataPtr = (char*)ptr;

    while(bytes > 0)
	{
		const size_t toRead = std::min(XA_DATA_SIZE - currentByte, bytes);

        memcpy(dataPtr+bytesRead, &sectorM2F2->subHead[currentByte], toRead);

		currentByte += toRead;
		bytesRead += toRead;
		bytes -= toRead;

		if (currentByte >= XA_DATA_SIZE)
		{
			if (singleSector || !PrepareNextSector())
			{
				return bytesRead;
			}
		}
    }

    return bytesRead;

}

size_t cd::IsoReader::ReadBytesDA(void* ptr, size_t bytes, bool singleSector)
{
	if (currentSector >= totalSectors) {
		return 0;
	}

	size_t bytesRead = 0;
    char* const dataPtr = (char*)ptr;

    while(bytes > 0)
	{
		const size_t toRead = std::min(CD_SECTOR_SIZE - currentByte, bytes);

        memcpy(dataPtr+bytesRead, &sectorBuff[currentByte], toRead);

		currentByte += toRead;
		bytesRead += toRead;
		bytes -= toRead;

		if (currentByte >= CD_SECTOR_SIZE)
		{
			if (singleSector || !PrepareNextSector())
			{
				return bytesRead;
			}
		}
    }

	return bytesRead;

}

size_t cd::IsoReader::SkipBytes(size_t bytes, bool singleSector) {

	if (currentSector >= totalSectors) {
		return 0;
	}

	size_t bytesRead = 0;
    while(bytes > 0) {

        const size_t toRead = std::min(F1_DATA_SIZE - currentByte, bytes);

		currentByte += toRead;
		bytesRead += toRead;
		bytes -= toRead;

		if (currentByte >= F1_DATA_SIZE) {

            if (singleSector || !PrepareNextSector())
			{
				return bytesRead;
			}
		}
    }

	return bytesRead;
}

bool cd::IsoReader::SeekToSector(int sector) {

	if (sector >= totalSectors || filePtr == nullptr)
		return false;

    fseek(filePtr, CD_SECTOR_SIZE*sector, SEEK_SET);
	if (fread(sectorBuff, CD_SECTOR_SIZE, 1, filePtr) != 1) {
		return false;
	}

	currentSector = sector;
	currentByte = 0;

	sectorM2F1 = (cd::SECTOR_M2F1*)sectorBuff;
    sectorM2F2 = (cd::SECTOR_M2F2*)sectorBuff;

	return !ferror(filePtr);

}

size_t cd::IsoReader::SeekToByte(size_t offs) {

	int sector = (offs/CD_SECTOR_SIZE);

	fseek(filePtr, CD_SECTOR_SIZE*sector, SEEK_SET);
    if (fread(sectorBuff, CD_SECTOR_SIZE, 1, filePtr) != 1) {
		return 0;
	}

	currentSector = sector;
	currentByte = offs%CD_SECTOR_SIZE;

	sectorM2F1 = (cd::SECTOR_M2F1*)sectorBuff;
    sectorM2F2 = (cd::SECTOR_M2F2*)sectorBuff;

	return (CD_SECTOR_SIZE*static_cast<size_t>(currentSector))+currentByte;

}

size_t cd::IsoReader::GetPos() const
{
    return (CD_SECTOR_SIZE*static_cast<size_t>(currentSector))+currentByte;
}

void cd::IsoReader::Close() {

    if (filePtr != NULL) {
		fclose(filePtr);
		filePtr = NULL;
    }

}

bool cd::IsoReader::PrepareNextSector()
{
	currentByte = 0;
	currentSector++;

    if (fread(sectorBuff, CD_SECTOR_SIZE, 1, filePtr) != 1)
	{
		return false;
    }

    sectorM2F1 = (cd::SECTOR_M2F1*)sectorBuff;
	sectorM2F2 = (cd::SECTOR_M2F2*)sectorBuff;
	return true;
}


void cd::IsoPathTable::FreePathTable()
{
	pathTableList.clear();
}

size_t cd::IsoPathTable::ReadPathTable(cd::IsoReader* reader, int lba, unsigned int size)
{
	if (lba < 0 || !reader->SeekToSector(lba) || size <= sizeof(ISO_PATHTABLE_ENTRY))
		return 0;

	FreePathTable();

	size_t bytesRead = 0;
	while (bytesRead < size)
	{
		Entry pathTableEntry;
		bytesRead += reader->ReadBytes(&pathTableEntry.entry, sizeof(pathTableEntry.entry));

		// Its the end of the path table when its nothing but zeros
		// ECMA-119 7.6.3 - The length of a Directory Identifier shall not exceed 31
		if (pathTableEntry.entry.identifierLen == 0 || pathTableEntry.entry.identifierLen > 31)
			break;


		// Read entry name
		{
			const size_t length = pathTableEntry.entry.identifierLen;
			pathTableEntry.name.resize(length);
			bytesRead += reader->ReadBytes(pathTableEntry.name.data(), length);

			// ECMA-119 9.4.6 - 00 field present only if entry length is an odd number
			if ((length % 2) != 0)
			{
				bytesRead += reader->SkipBytes(1);
			}

			// Strip trailing zeroes, if any
			pathTableEntry.name.resize(strlen(pathTableEntry.name.c_str()));
		}

		pathTableList.emplace_back(std::move(pathTableEntry));
	}

	return pathTableList.size();

}

fs::path cd::IsoPathTable::GetFullDirPath(int dirEntry) const
{
	fs::path path;

	while (true)
	{
		if (pathTableList[dirEntry].name.empty())
			break;

		// Prepend!
		path = pathTableList[dirEntry].name / path;

        dirEntry = pathTableList[dirEntry].entry.parentDirIndex-1;
	}

	return path;
}

cd::IsoDirEntries::IsoDirEntries(ListView<Entry> view)
	: dirEntryList(std::move(view))
{
}

static EntryType GetXAEntryType(unsigned short xa_attr)
{
	// we try to guess the file type. Usually, the xa_attr should tell this, but there are many games
	// that do not follow the standard, and sometime leave some or all the attributes unset.
	if (xa_attr & 0x40)
	{
		// if the cddata flag is set, we assume this is the case
		return EntryType::EntryDA;
	}
	if (xa_attr & 0x80)
	{
		// if the directory flag is set, we assume this is the case
		return EntryType::EntryDir;
	}
	if ( (xa_attr & 0x08) && !(xa_attr & 0x10) )
	{
		// if the mode 2 form 1 flag is set, and form 2 is not, we assume this is a regular file.
		return EntryType::EntryFile;
	}
	if ( (xa_attr & 0x10) && !(xa_attr & 0x08) )
	{
		// if the mode 2 form 2 flag is set, and form 1 is not, we assume this is a pure audio xa file.
		return EntryType::EntryXA;
	}

	// here all flags are set to the same value. From what I could see until now, when both flags are the same,
	// this is interpreted in the following two ways, which both lead us to choose str/xa type.
	// 1. Both values are 1, which means there is an indication by the mode 2 form 2 flag that the data is not
	//    regular mode 2 form 1 data (i.e., it is either mixed or just xa).
	// 2. Both values are 0. The fact that the mode 2 form 2 flag is 0 simply means that the data might not
	//    be *pure* mode 2 form 2 data (i.e., xa), so, we do not conclude it is regular mode 2 form 1 data.
	//    We thus give priority to the mode 2 form 1 flag, which is also zero,
	//	  and conclude that the data is not regular mode 2 form 1 data, and thus can be either mode 2 form 2 or mixed.

	// Remark: Some games (Legend of Mana), use a very strange STR+XA format that is stored in plain mode 2 form 1.
	// This is properly marked in the xa_attr, and there is nothing wrong in extracting them as data.
	return EntryType::EntryXA;
}

void cd::IsoDirEntries::ReadDirEntries(cd::IsoReader* reader, int lba, int sectors)
{
	short order = 0;
	size_t numEntries = 0; // Used to skip the first two entries, . and ..
    for (int sec = 0; sec < sectors; sec++)
    {
        reader->SeekToSector(lba + sec);
		while (true)
		{
			auto entry = ReadEntry(reader);
			if (!entry)
			{
				// Either end of the table, or end of sector
				break;
			}

			if (numEntries++ >= 2)
			{
				if (*global::new_type)
				{
					entry->order = order++;
				}
				dirEntryList.emplace(std::move(entry.value()));
			}
		}
    }

	// Sort the directory by LBA for pretty printing
	dirEntryList.SortView([](const auto& left, const auto& right)
		{
			return left.get().entry.entryOffs.lsb < right.get().entry.entryOffs.lsb;
		});

	// Delete orders if all are correct to avoid populate the xml with unnecessary strings
	if (*global::new_type)
	{
		auto& entriesInDir = dirEntryList.GetView();
		for (int index = 0; index < entriesInDir.size(); index++)
		{
			if (*entriesInDir[index].get().order != index)
				return;
		}
		for (auto& entry : entriesInDir)
		{
			entry.get().order.reset();
		}
	}
}

std::optional<cd::IsoDirEntries::Entry> cd::IsoDirEntries::ReadEntry(cd::IsoReader* reader) const
{
	Entry entry;

	// Read 33 byte directory entry
	size_t bytesRead = reader->ReadBytes(&entry.entry, sizeof(entry.entry), true);

	// The file entry table usually ends with null bytes so break if we reached that area
	// ECMA-119 7.5.1 - The length of a File Identifier shall not exceed 31 + ';1'
	if (bytesRead != sizeof(entry.entry) || entry.entry.entryLength == 0 || entry.entry.identifierLen > 33)
		return std::nullopt;

	// Read identifier string
	entry.identifier.resize(entry.entry.identifierLen);
	bytesRead += reader->ReadBytes(entry.identifier.data(), entry.entry.identifierLen, true);

	// Strip trailing zeroes, if any
	entry.identifier.resize(strlen(entry.identifier.c_str()));

	// ECMA-119 9.1.12 - 00 field present only if file identifier length is an even number
	if ((entry.entry.identifierLen % 2) == 0)
    {
		bytesRead += reader->SkipBytes(1);
    }

	// Read XA attribute data
	bytesRead += reader->ReadBytes(&entry.extData, sizeof(entry.extData), true);

	// XA attributes are big endian, swap them
	entry.extData.ownergroupid = SwapBytes16(entry.extData.ownergroupid);
	entry.extData.owneruserid = SwapBytes16(entry.extData.owneruserid);
	if ((entry.extData.attributes & 0x0FFF) != 0x0800) // HACK for conflictive images that has the attributes written as little endian
	{
		entry.extData.attributes = SwapBytes16(entry.extData.attributes);
	}

	// Skip unsupported System Use extensions
	if (bytesRead < entry.entry.entryLength)
	{
		bytesRead += reader->SkipBytes(entry.entry.entryLength - bytesRead, true);
	}

	// If there is still a difference, then it's either an invalid entry or a corrupted sector
	if (bytesRead != entry.entry.entryLength)
		return std::nullopt;

	// Add the EntryType here so as to not keep calculating it everytime later
	// Check for file number first to determine if it's a STR/XA file, because some games (Mega Man X3) has flagged them as DATA but currently they are not
	entry.type = entry.extData.filenum ? EntryType::EntryXA : GetXAEntryType((entry.extData.attributes & cdxa::XA_ATTRIBUTES_MASK) >> 8);
	entry.trackid = "01"; // This helps detect unreferenced entries more easily

	return entry;
}

void cd::IsoDirEntries::ReadRootDir(cd::IsoReader* reader, int lba)
{
	reader->SeekToSector(lba);
	auto entry = ReadEntry(reader);
	if (entry)
	{
		dirEntryList.emplace(std::move(entry.value()));
	}
}
