#include "platform.h"
#include "xml.h"
#include "cue.h"
#include <map>
#include <format>

#ifndef MKPSXISO_NO_LIBFLAC
#include "FLAC/stream_encoder.h"
#endif

typedef enum {
	EAF_WAV  = 1 << 0,
	EAF_FLAC = 1 << 1,
	EAF_PCM  = 1 << 2
} EncoderAudioFormats;

typedef struct {
	const char *codec;
	EncoderAudioFormats eaf;
	const char *notcompiledmessage;
} EncodingCodec;

static const EncodingCodec EncodingCodecs[] = {
	{"wave", EAF_WAV, ""},
	{"flac", EAF_FLAC, "ERROR: dumpsxiso was NOT built with libFLAC support!\n"},
	{"pcm",  EAF_PCM, ""}
};

const unsigned BUILTIN_CODECS = (EAF_WAV | EAF_PCM);
#define BUILTIN_CODEC_TEXT "wave, pcm"
#ifndef MKPSXISO_NO_LIBFLAC
	#define LIBFLAC_SUPPORTED EAF_FLAC
	#define LIBFLAC_CODEC_TEXT ", flac"
#else
    #define LIBFLAC_SUPPORTED 0
	#define LIBFLAC_CODEC_TEXT ""
#endif
const unsigned SUPPORTED_CODECS  = (BUILTIN_CODECS | LIBFLAC_SUPPORTED);
#define SUPPORTED_CODEC_TEXT BUILTIN_CODEC_TEXT LIBFLAC_CODEC_TEXT

namespace param {

    fs::path isoFile;
    fs::path outPath;
    fs::path xmlFile;
	bool lba = false;
	bool raw = false;
	bool force = false;
	bool noxml = false;
	bool noWarns = false;
	bool QuietMode = false;
	bool pathTable = false;
    bool outputSortedByDir = false;
	EncoderAudioFormats encodingFormat = EAF_WAV;
}

namespace global
{
	CueFile cueFile;
	std::optional<bool> new_type;
}

fs::path GetEncodedDAPath(const fs::path& inputPath)
{
	fs::path outputPath(inputPath); 
	if(param::encodingFormat == EAF_WAV)
	{
		outputPath.replace_extension(".WAV");
	}
#ifndef MKPSXISO_NO_LIBFLAC
	else if(param::encodingFormat == EAF_FLAC)
	{
		outputPath.replace_extension(".FLAC");
	}
#endif
	else
	{
		outputPath.replace_extension(".PCM");
	}
	return outputPath;
}

template<size_t N>
void PrintId(const char* label, char (&id)[N])
{
	std::string_view view;

	const std::string_view id_view(id, N);
	const size_t last_char = id_view.find_last_not_of(' ');
	if (last_char != std::string_view::npos)
	{
		view = id_view.substr(0, last_char+1);
	}

	if (!view.empty())
	{
		printf("%s%.*s\n", label, static_cast<int>(view.length()), view.data());
	}
}

void PrintDate(const char* label, const cd::ISO_LONG_DATESTAMP& date)
{
	auto ZERO_DATE = GetUnspecifiedLongDate();
	if (memcmp(&date, &ZERO_DATE, sizeof(date)))
	{
		printf("%s%s\n", label, LongDateToString(date).c_str());
	}
}

template<size_t N>
static std::string_view CleanDescElement(char (&id)[N])
{
	std::string_view result;

	const std::string_view view(id, N);
	const size_t last_char = view.find_last_not_of(' ');
	if (last_char != std::string_view::npos)
	{
		result = view.substr(0, last_char+1);
	}

    return result;
}

void prepareRIFFHeader(cd::RIFF_HEADER* header, int dataSize) {
	memcpy(header->chunkID,"RIFF",4);
	header->chunkSize = 36 + dataSize;
	memcpy(header->format, "WAVE", 4);

	memcpy(header->subchunk1ID, "fmt ", 4);
	header->subchunk1Size = 16;
	header->audioFormat = 1;
	header->numChannels = 2;
	header->sampleRate = 44100;
	header->bitsPerSample = 16;
	header->byteRate = (header->sampleRate * header->numChannels * header->bitsPerSample) / 8;
	header->blockAlign = (header->numChannels * header->bitsPerSample) / 8;

	memcpy(header->subchunk2ID, "data", 4);
	header->subchunk2Size = dataSize;
}

// This will ensure that the EDC remains the same as in the original file. Games built with an old, buggy Sony's mastering tool version
// don't have EDC Form2 data (this can be checked at redump.org) and some games rely on this to do anti-piracy checks like DDR.
const bool CheckEDCXA(cd::IsoReader &reader) {
	cd::SECTOR_M2F2 sector;
	while (reader.ReadBytesXA(sector.subHead, XA_DATA_SIZE, true))
	{
		if (sector.subHead[2] & 0x20) {
			if (!memcmp(sector.edc, "\0\0\0\0", sizeof(sector.edc)))
			{
				return false;
			}
			return true;
		}
	}
	return true;
}

// Games from 2003 and onwards apparenly has built with a newer Sony's mastering tool.
// These has different submode in the descriptor sectors, a correct root year value and files are sorted by LBA instead by name.
const bool CheckISOver(cd::IsoReader &reader, bool& ps2)
{
	cd::SECTOR_M2F2 sector;
	reader.SeekToSector(15);
	reader.ReadBytesXA(sector.subHead, XA_DATA_SIZE);
	if (sector.subHead[2] & 0x08)
	{
		ps2 = true;
	}
	reader.ReadBytesXA(sector.subHead, XA_DATA_SIZE, true);
	if (sector.subHead[2] & 0x01)
	{
		return false;
	}
	return true;
}

std::unique_ptr<cd::ISO_LICENSE> ReadLicense(cd::IsoReader& reader) {
	auto license = std::make_unique<cd::ISO_LICENSE>();

	reader.SeekToSector(0);
	reader.ReadBytesXA(license->data, sizeof(license->data));

	return license;
}

void SaveLicense(const cd::ISO_LICENSE& license) {
	if (!param::QuietMode)
	{
		printf("\n  Creating license data...");
	}

	FILE* outFile = OpenFile(param::outPath / "license_data.dat", "wb");

	if (outFile == NULL)
	{
		printf("\nERROR: Cannot create license file.\n");
        exit(EXIT_FAILURE);
    }
	else if (!param::QuietMode)
	{
		printf(" Ok.\n");
	}

    fwrite(license.data, 1, sizeof(license.data), outFile);
    fclose(outFile);
}

void writePCMFile(FILE *outFile, cd::IsoReader& reader, const size_t cddaSize, const bool isInvalid)
{
	constexpr size_t bufferSize = 64 * 1024; // Use a 64KiB buffer for better I/O performance
	unsigned char copyBuff[bufferSize]{};
	size_t bytesLeft = cddaSize;
	while (bytesLeft > 0) {

    	size_t bytesToRead = bytesLeft;

    	if (bytesToRead > bufferSize)
    		bytesToRead = bufferSize;

		if (!isInvalid)
    		reader.ReadBytesDA(copyBuff, bytesToRead);

    	fwrite(copyBuff, 1, bytesToRead, outFile);

    	bytesLeft -= bytesToRead;
    }
}

void writeWaveFile(FILE *outFile, cd::IsoReader& reader, const size_t cddaSize, const bool isInvalid)
{
    cd::RIFF_HEADER riffHeader;
    prepareRIFFHeader(&riffHeader, cddaSize);
    fwrite((void*)&riffHeader, 1, sizeof(cd::RIFF_HEADER), outFile);

    writePCMFile(outFile, reader, cddaSize, isInvalid);
}

#ifndef MKPSXISO_NO_LIBFLAC
void writeFLACFile(FILE *outFile, cd::IsoReader& reader, const int cddaSize, const bool isInvalid)
{
	FLAC__bool ok = true;
	FLAC__StreamEncoder *encoder = 0;
	FLAC__StreamEncoderInitStatus init_status;
	if((encoder = FLAC__stream_encoder_new()) == NULL)
	{
		fprintf(stderr, "\nERROR: allocating encoder.\n");
		exit(EXIT_FAILURE);
	}
	unsigned sample_rate = 44100;
	unsigned channels = 2;
	unsigned bps = 16;
	unsigned total_samples = cddaSize / (channels * (bps/8));

	ok &= FLAC__stream_encoder_set_verify(encoder, true);
	ok &= FLAC__stream_encoder_set_compression_level(encoder, 5);
	ok &= FLAC__stream_encoder_set_channels(encoder, channels);
	ok &= FLAC__stream_encoder_set_bits_per_sample(encoder, bps);
	ok &= FLAC__stream_encoder_set_sample_rate(encoder, sample_rate);
	ok &= FLAC__stream_encoder_set_total_samples_estimate(encoder, total_samples);
	if(!ok)
	{
		fprintf(stderr, "\nERROR: setting encoder settings.\n");
		goto writeFLACFile_cleanup;
	}

	init_status = FLAC__stream_encoder_init_FILE(encoder, outFile, /*progress_callback=*/NULL, /*client_data=*/NULL);
	if(init_status != FLAC__STREAM_ENCODER_INIT_STATUS_OK)
	{
		fprintf(stderr, "\nERROR: initializing encoder: %s.\n", FLAC__StreamEncoderInitStatusString[init_status]);
		ok = false;
		goto writeFLACFile_cleanup;
	}

    {
    size_t left = (size_t)total_samples;
	size_t max_pcmframe_read = CD_SECTOR_SIZE / (channels * (bps/8));

    std::unique_ptr<int32_t[]> pcm(new int32_t[channels * max_pcmframe_read]);
	while (left && ok) {

		unsigned char copyBuff[CD_SECTOR_SIZE]{};

		size_t need = (left > max_pcmframe_read ? max_pcmframe_read : left);
		size_t needBytes = need * (channels * (bps/8));
		if(!isInvalid)
			reader.ReadBytesDA(copyBuff, needBytes);

    	/* convert the packed little-endian 16-bit PCM samples from WAVE into an interleaved FLAC__int32 buffer for libFLAC */
		for(size_t i = 0; i < need*channels; i++)
		{
			/* inefficient but simple and works on big- or little-endian machines */
			pcm[i] = (FLAC__int32)(((FLAC__int16)(FLAC__int8)copyBuff[2*i+1] << 8) | (FLAC__int16)copyBuff[2*i]);
		}
		/* feed samples to encoder */
		ok = FLAC__stream_encoder_process_interleaved(encoder, pcm.get(), need);
		left -= need;
    }
    }
	ok &= FLAC__stream_encoder_finish(encoder); // closes outFile
	if(!ok)
	{
		fprintf(stderr, "\nencoding: FAILED\n");
		fprintf(stderr, "   state: %s\n", FLAC__StreamEncoderStateString[FLAC__stream_encoder_get_state(encoder)]);
	}

writeFLACFile_cleanup:
	FLAC__stream_encoder_delete(encoder);
	if(!ok)
	{
		exit(EXIT_FAILURE);
	}
}
#endif

// XML attribute stuff
struct EntryAttributeCounters
{
	std::map<int, unsigned int> GMTOffs;
	std::map<int, unsigned int> HFLAG;
	std::map<int, unsigned int> XAAttrib;
	std::map<int, unsigned int> XAPerm;
	std::map<int, unsigned int> GID;
	std::map<int, unsigned int> UID;
};

static void WriteOptionalXMLAttribs(tinyxml2::XMLElement* element, const cd::IsoDirEntries::Entry& entry, EntryType type, EntryAttributeCounters& attributeCounters)
{
	element->SetAttribute(xml::attrib::GMT_OFFSET, entry.entry.entryDate.GMToffs);
	++attributeCounters.GMTOffs[entry.entry.entryDate.GMToffs];

	// xa_attrib only makes sense on XA files
	if (type == EntryType::EntryXA)
	{
		const auto XAAtrib = (entry.extData.attributes & cdxa::XA_ATTRIBUTES_MASK) >> 8;
		element->SetAttribute(xml::attrib::XA_ATTRIBUTES, XAAtrib);
		++attributeCounters.XAAttrib[XAAtrib];
	}
	const auto XAPerm = entry.extData.attributes & cdxa::XA_PERMISSIONS_MASK;
	element->SetAttribute(xml::attrib::XA_PERMISSIONS, XAPerm);
	++attributeCounters.XAPerm[XAPerm];

	element->SetAttribute(xml::attrib::XA_GID, entry.extData.ownergroupid);
	element->SetAttribute(xml::attrib::XA_UID, entry.extData.owneruserid);
	++attributeCounters.GID[entry.extData.ownergroupid];
	++attributeCounters.UID[entry.extData.owneruserid];

	const auto HFLAG = entry.entry.flags & 0x20 ? entry.entry.flags & 0x03 : entry.entry.flags & 0x01; // 5th bit simulates obfuscation
	element->SetAttribute(xml::attrib::HIDDEN_FLAG, HFLAG);
	++attributeCounters.HFLAG[HFLAG];

	if (entry.order.has_value())
	{
		element->SetAttribute(xml::attrib::ORDER, *entry.order);
	}
	if (param::lba)
	{
		element->SetAttribute(xml::attrib::OFFSET, entry.entry.entryOffs.lsb);
	}
}

static EntryAttributes EstablishXMLAttributeDefaults(tinyxml2::XMLElement* defaultAttributesElement, const EntryAttributeCounters& attributeCounters)
{
	// First establish "defaults" - that is, the most commonly occurring attributes
	auto findMaxElement = [](const auto& map)
	{
		if (!map.empty()) {
			return std::max_element(map.begin(), map.end(), [](const auto& left, const auto& right) { return left.second < right.second; })->first;
		}
		return 0;
	};

	EntryAttributes defaultAttributes;
	defaultAttributes.GMTOffs = static_cast<signed char>(findMaxElement(attributeCounters.GMTOffs));
	defaultAttributes.HFLAG = static_cast<unsigned char>(findMaxElement(attributeCounters.HFLAG));
	defaultAttributes.XAAttrib = static_cast<unsigned char>(findMaxElement(attributeCounters.XAAttrib));
	defaultAttributes.XAPerm = static_cast<unsigned short>(findMaxElement(attributeCounters.XAPerm));
	defaultAttributes.GID = static_cast<unsigned short>(findMaxElement(attributeCounters.GID));
	defaultAttributes.UID = static_cast<unsigned short>(findMaxElement(attributeCounters.UID));

	// Write them out to the XML
	defaultAttributesElement->SetAttribute(xml::attrib::GMT_OFFSET, defaultAttributes.GMTOffs);
	defaultAttributesElement->SetAttribute(xml::attrib::XA_ATTRIBUTES, defaultAttributes.XAAttrib);
	defaultAttributesElement->SetAttribute(xml::attrib::XA_PERMISSIONS, defaultAttributes.XAPerm);
	defaultAttributesElement->SetAttribute(xml::attrib::XA_GID, defaultAttributes.GID);
	defaultAttributesElement->SetAttribute(xml::attrib::XA_UID, defaultAttributes.UID);
	if (defaultAttributes.HFLAG) // Set only if not zero
	{
		defaultAttributesElement->SetAttribute(xml::attrib::HIDDEN_FLAG, defaultAttributes.HFLAG);
	}

	return defaultAttributes;
}

static void SimplifyDefaultXMLAttributes(tinyxml2::XMLElement* element, const EntryAttributes& defaults)
{
	// DeleteAttribute can be safely called even if that attribute doesn't exist, so treating failure and default values
	// as equal simplifies logic
	auto deleteAttribute = [element](const char* name, auto defaultValue)
	{
		bool deleteAttribute = false;
		if constexpr (std::is_unsigned_v<decltype(defaultValue)>)
		{
			deleteAttribute = element->UnsignedAttribute(name, defaultValue) == defaultValue;
		}
		else
		{
			deleteAttribute = element->IntAttribute(name, defaultValue) == defaultValue;
		}
		if (deleteAttribute)
		{
			element->DeleteAttribute(name);
		}
	};

	deleteAttribute(xml::attrib::GMT_OFFSET, defaults.GMTOffs);
	deleteAttribute(xml::attrib::HIDDEN_FLAG, defaults.HFLAG);
	deleteAttribute(xml::attrib::XA_ATTRIBUTES, defaults.XAAttrib);
	deleteAttribute(xml::attrib::XA_PERMISSIONS, defaults.XAPerm);
	deleteAttribute(xml::attrib::XA_GID, defaults.GID);
	deleteAttribute(xml::attrib::XA_UID, defaults.UID);

	for (tinyxml2::XMLElement* child = element->FirstChildElement(); child != nullptr; child = child->NextSiblingElement())
	{
		SimplifyDefaultXMLAttributes(child, defaults);
	}
}

std::unique_ptr<cd::IsoDirEntries> ParseSubdirectory(cd::IsoReader& reader, ListView<cd::IsoDirEntries::Entry> view, int offs, int sectors,
	const fs::path& path)
{
    auto dirEntries = std::make_unique<cd::IsoDirEntries>(std::move(view));
	dirEntries->ReadDirEntries(&reader, offs, sectors);

    for (auto& e : dirEntries->dirEntryList.GetView())
	{
		auto& entry = e.get();

		entry.virtualPath = path;
        if (entry.entry.flags & 0x2)
		{
            entry.subdir = ParseSubdirectory(reader, dirEntries->dirEntryList.NewView(), entry.entry.entryOffs.lsb, GetSizeInSectors(entry.entry.entrySize.lsb),
				path / CleanIdentifier(entry.identifier));
        }
    }

	return dirEntries;
}

std::unique_ptr<cd::IsoDirEntries> ParsePathTable(cd::IsoReader& reader, ListView<cd::IsoDirEntries::Entry> view, const std::vector<cd::IsoPathTable::Entry>& pathTableList,
	int index, const fs::path& path)
{
    auto dirEntries = std::make_unique<cd::IsoDirEntries>(std::move(view));

	// Calculate Directory Record sector size
	int dirRecordSectors = 0;
	if (*global::new_type && pathTableList.size() != index + 1)
	{
		dirRecordSectors = pathTableList[index + 1].entry.dirOffs - pathTableList[index].entry.dirOffs;
	}
	else
	{
		reader.SeekToSector(pathTableList[index].entry.dirOffs);
		cd::SECTOR_M2F1 sector;
		do {
			dirRecordSectors++;
			reader.ReadBytesXA(sector.subHead, XA_DATA_SIZE);
		} while (!(sector.subHead[2] & 0x81)); // Directory records normally ends with submode 0x89
	}

	dirEntries->ReadDirEntries(&reader, pathTableList[index].entry.dirOffs, dirRecordSectors);

	// Only add the missing directories to the list
    for (int i = 1; i < pathTableList.size(); i++) {
        auto& e = pathTableList[i];
		if (e.entry.parentDirIndex - 1 == index &&
			!std::any_of(dirEntries->dirEntryList.GetView().begin(), dirEntries->dirEntryList.GetView().end(), [&e](const auto& entry)
				{
					return entry.get().identifier == e.name;
				}))
		{
            dirEntries->ReadRootDir(&reader, e.entry.dirOffs);
			dirEntries->dirEntryList.GetView().back().get().entry.flags |= 0x22; // We are setting the reserved 5th bit to simulate obfuscation
        }
    } 

    for (auto& e : dirEntries->dirEntryList.GetView()) {
    		auto& entry = e.get();
										
    		entry.virtualPath = path;

        if (entry.entry.flags & 0x2) {
						int index = -1;
						std::string s;
						for (int i = 1; i < pathTableList.size(); i++) {
								auto& ee = pathTableList[i];
								if (ee.entry.dirOffs == entry.entry.entryOffs.lsb) {
										index = i;
										s = ee.name;
										break;
								}
						}

						if (index < 0) continue;
						entry.identifier = s;
				
						entry.subdir = ParsePathTable(reader, dirEntries->dirEntryList.NewView(), pathTableList, index, path / s);
				}
    }
  
    return dirEntries;  
}

std::unique_ptr<cd::IsoDirEntries> ParseRoot(cd::IsoReader& reader, ListView<cd::IsoDirEntries::Entry> view, const std::vector<cd::IsoPathTable::Entry>& pathTableList)
{
    auto dirEntries = std::make_unique<cd::IsoDirEntries>(std::move(view));
	dirEntries->ReadRootDir(&reader, pathTableList[0].entry.dirOffs);

	if (dirEntries->dirEntryList.GetView().empty())
	{
		printf("\nERROR: Root directory is empty or invalid.\n");
		exit(EXIT_FAILURE);
	}
	auto& entry = dirEntries->dirEntryList.GetView().front().get();
	entry.subdir = !param::pathTable
		? ParseSubdirectory(reader, dirEntries->dirEntryList.NewView(), entry.entry.entryOffs.lsb, GetSizeInSectors(entry.entry.entrySize.lsb), entry.identifier)
		: ParsePathTable(reader, dirEntries->dirEntryList.NewView(), pathTableList, 0, entry.identifier);

	return dirEntries;
}

std::list<cd::IsoDirEntries::Entry*> ParseDAfiles(cd::IsoReader& reader, std::list<cd::IsoDirEntries::Entry>& entries)
{
	std::list<cd::IsoDirEntries::Entry*> DAfiles;
	unsigned tracknum = 2;

	// Get referenced DA files and assign them an ID number
	for(auto& entry : entries)
	{
		if(entry.type == EntryType::EntryDA)
		{
			entry.trackid = std::format("{:02}", tracknum);
			tracknum++;
			DAfiles.push_back(&entry);
		}
	}

	if (tracknum <= global::cueFile.tracks.size())
	{
		std::vector<cd::IsoDirEntries::Entry> unrefDAbuff;
		// Create a buffer of unreferenced DA tracks
		for(const auto& track : global::cueFile.tracks)
		{
			// Skip non audio tracks
			if (track.type != "AUDIO")
				continue;
			// Skip referenced DA tracks
			if (tracknum > 2 && std::any_of(DAfiles.begin(), DAfiles.end(), [&track](const auto& entry)
									{
										return entry->entry.entryOffs.lsb == track.startSector;
									}))
			{
				continue;
			}

			// Add the unreferenced DA track to the buffer
			auto& entry = unrefDAbuff.emplace_back();
			entry.entry.entryOffs.lsb = track.startSector;
			entry.entry.entrySize.lsb = track.sizeInSectors * F1_DATA_SIZE;
			entry.identifier = GetEncodedDAPath("TRACK-" + track.number).string() + ";1";
			entry.type = EntryType::EntryDA;

			// Additional safety check in case the .cue file had a wrong pause size
			// For ex, Mega Man X3 track 30 had 149 sectors pause, but at redump.org says it was a 150 standard one
			unsigned char sectorBuff[CD_SECTOR_SIZE];
			unsigned char emptyBuff[CD_SECTOR_SIZE] {};
			while (true)
			{
				if (!reader.SeekToSector(entry.entry.entryOffs.lsb - 1) && !multiBinSeeker(entry.entry.entryOffs.lsb - 1, entry, reader, global::cueFile))
					break;

				reader.ReadBytesDA(sectorBuff, CD_SECTOR_SIZE, true);
				if (memcmp(sectorBuff, emptyBuff, CD_SECTOR_SIZE))
				{
					entry.entry.entryOffs.lsb--;
					entry.entry.entrySize.lsb += F1_DATA_SIZE;
				}
				else
				{
					break;
				}
			}
		}

		// Add unreferenced DA tracks to entries for further extraction
		for (auto& entry : unrefDAbuff)
		{
			entries.emplace_back(std::move(entry));
			DAfiles.push_back(&entries.back());
		}

		// Sort DA files by LBA
		DAfiles.sort([](const auto& left, const auto& right)
			{
				return left->entry.entryOffs.lsb < right->entry.entryOffs.lsb;
			});

		// Only recalculate the track id's if there were unreferenced tracks among the referenced ones
		// This is just for a prettier XML sort, because unsorted track id's have no impact at build time
		if (tracknum > 2)
		{
			tracknum = 2;
			for(const auto& entry : DAfiles)
			{
				if(!entry->trackid.empty())
				{
					entry->trackid = std::format("{:02}", tracknum);
				}
				tracknum++;
			}
		}

		// Reopen the first file for safety
		reader.Open(global::cueFile.tracks[0].filePath);
	}

	return DAfiles;
}

void BruteForce(cd::IsoReader& reader, std::list<cd::IsoDirEntries::Entry>& entries, unsigned int currentLBA, unsigned int totalLenLBA)
{
	cd::SECTOR_M2F2 sector;
	int filenum = 0;

	auto processGaps = [&](unsigned int endLBA)
	{
		cd::IsoDirEntries::Entry* gapEntry = &entries.front(); // Get root stats
		signed char rootGMTOff = gapEntry->entry.entryDate.GMToffs;
		unsigned short rootGID = gapEntry->extData.ownergroupid;
		unsigned short rootUID = gapEntry->extData.owneruserid;
		unsigned short rootPrm = gapEntry->extData.attributes & cdxa::XA_PERMISSIONS_MASK;
		bool processingFile = false;
		reader.SeekToSector(currentLBA);
		for (; currentLBA < endLBA; currentLBA++)
		{
			reader.ReadBytesXA(sector.subHead, XA_DATA_SIZE);

			// Process only non dummy sectors
			if (!processingFile && sector.subHead[2] != 0x20 && sector.subHead[2] != 0x00)
			{
				processingFile = true;
				gapEntry = &entries.emplace_front();
				gapEntry->entry.entryOffs.lsb 	  = currentLBA;
				gapEntry->entry.entrySize.lsb 	  = F1_DATA_SIZE;
				gapEntry->entry.entryDate.GMToffs = rootGMTOff;
				gapEntry->entry.flags 			  = 0x22; // We are setting the reserved 5th bit to simulate obfuscation
				gapEntry->extData.ownergroupid 	  = rootGID;
				gapEntry->extData.owneruserid 	  = rootUID;
				gapEntry->extData.attributes 	  = rootPrm;
				if ((sector.subHead[2] & 0x7E) == 0x08)
				{
					gapEntry->identifier = std::format("UNKN{:04}.{};1", filenum++, "DAT");
					gapEntry->type = EntryType::EntryFile;
				}
				else
				{
					gapEntry->identifier = std::format("UNKN{:04}.{};1", filenum++, "STR");
					gapEntry->type = EntryType::EntryXA;
				}
			}
			else if (processingFile)
			{
				gapEntry->entry.entrySize.lsb += F1_DATA_SIZE;
			}

			// Process file until EoF or EoR is set
			if (sector.subHead[2] & 0x81)
				processingFile = false;
		}
	};

	for (const auto& entry : entries)
	{
		if (currentLBA < entry.entry.entryOffs.lsb)
		{
			processGaps(entry.entry.entryOffs.lsb);
		}
		currentLBA += GetSizeInSectors(entry.entry.entrySize.lsb);
	}

	if (currentLBA < totalLenLBA)
	{
		processGaps(totalLenLBA);
	}

	entries.sort([](const auto& left, const auto& right)
		{
			return left.entry.entryOffs.lsb < right.entry.entryOffs.lsb;
		});
}

void ExtractFiles(cd::IsoReader& reader, const std::list<cd::IsoDirEntries::Entry>& files, const fs::path& rootPath)
{
	bool printedDA = false;
    for (const auto& entry : files)
	{
        if (entry.subdir == nullptr) // Do not extract directories, they're already prepared
		{
			const fs::path outputPath = rootPath / entry.virtualPath / CleanIdentifier(entry.identifier);
			if (entry.type == EntryType::EntryXA)
			{
				// Extract XA or STR file.
				// For both XA and STR files, we need to extract the data 2336 bytes per sector.
				// When rebuilding the bin using mkpsxiso, we mark the file with mixed.
				// The source file will anyway be stored on our hard drive in raw form.
				if (!param::QuietMode)
				{
					printf("    Extracting XA \"%s\"... ", outputPath.string().c_str());
				}
				fflush(stdout);

				FILE* outFile = OpenFile(outputPath, "wb");

				if (outFile == NULL || !reader.SeekToSector(entry.entry.entryOffs.lsb))
				{
					printf("\nERROR: Cannot create file \"%s\"\n", outputPath.filename().string().c_str());
					exit(EXIT_FAILURE);
				}

				// this is the data to be read 2336 bytes per sector, both if the file is an STR or XA,
				// because the STR contains audio.
				size_t sectorsToRead = GetSizeInSectors(entry.entry.entrySize.lsb);

				// Copy loop
				{
				constexpr size_t bufferSize = 64 * 1024; // Use a 64KiB buffer for better I/O performance
				unsigned char copyBuff[bufferSize];
				auto ptrReadFunc = !param::raw ? &cd::IsoReader::ReadBytesXA : &cd::IsoReader::ReadBytesDA;
				size_t bytesLeft = (!param::raw ? XA_DATA_SIZE : CD_SECTOR_SIZE) * sectorsToRead;
				while(bytesLeft > 0) {

					size_t bytesToRead = bytesLeft;

					if (bytesToRead > bufferSize)
						bytesToRead = bufferSize;

					(reader.*ptrReadFunc)(copyBuff, bytesToRead, false);

					fwrite(copyBuff, 1, bytesToRead, outFile);

					bytesLeft -= bytesToRead;

				}
				}

				fclose(outFile);
			}
			else if (entry.type == EntryType::EntryDA)
			{
				// Extract CDDA file
				if (!printedDA && !param::QuietMode)
				{
					printf("\n  Creating CDDA files...\n");
					printedDA = true;
				}
				bool isInvalid = !global::cueFile.multiBIN
					? !reader.SeekToSector(entry.entry.entryOffs.lsb)
					: !multiBinSeeker(entry.entry.entryOffs.lsb, entry, reader, global::cueFile);
                auto daOutPath = GetEncodedDAPath(outputPath);
				auto outFile = OpenScopedFile(daOutPath, "wb");

				if (isInvalid && !param::noWarns)
				{
					printf( "\nWARNING: The CDDA file \"%s\" is out of the iso file bounds.\n"
							"\t This usually means that the game has audio tracks, and they are on separate files.\n", daOutPath.filename().string().c_str() );
					if (global::cueFile.tracks.empty())
					{
						printf("\t Try using a .cue file, instead of an ISO image, to be able to access those files.\n");
					}
					printf( "\t DUMPSXISO will write the file as a dummy (silent) cdda file.\n"
							"\t This is generally fine, when the real CDDA file is also a dummy file.\n"
							"\t If it is not dummy, you WILL lose this audio data in the rebuilt iso... " );
					if (param::QuietMode)
					{
						printf("\n");
					}
				}
				else if (!param::QuietMode)
				{
					printf("    Extracting audio \"%s\"... ", daOutPath.string().c_str());
				}
				fflush(stdout);

				if (!outFile) {
					printf("\nERROR: Cannot create file \"%s\"\n", daOutPath.filename().string().c_str());
					exit(EXIT_FAILURE);
				}

				size_t sectorsToRead = GetSizeInSectors(entry.entry.entrySize.lsb);
				size_t cddaSize = CD_SECTOR_SIZE * sectorsToRead;

				if(param::encodingFormat == EAF_WAV)
				{
					writeWaveFile(outFile.get(), reader, cddaSize, isInvalid);
				}
#ifndef MKPSXISO_NO_LIBFLAC
				else if(param::encodingFormat == EAF_FLAC)
				{
					// libflac closes outFile
					writeFLACFile(outFile.release(), reader, cddaSize, isInvalid);
				}
#endif
				else
				{
					writePCMFile(outFile.get(), reader, cddaSize, isInvalid);
				}

				if (global::cueFile.multiBIN)
				{
					reader.Open(global::cueFile.tracks[0].filePath);
				}
			}
			else if (entry.type == EntryType::EntryFile)
			{
				// Extract regular file
				if (!param::QuietMode)
				{
					printf("    Extracting \"%s\"... ", outputPath.string().c_str());
					fflush(stdout);
				}

				reader.SeekToSector(entry.entry.entryOffs.lsb);

				FILE* outFile = OpenFile(outputPath, "wb");

				if (outFile == NULL) {
					printf("\nERROR: Cannot create file \"%s\"\n", outputPath.filename().string().c_str());
					exit(EXIT_FAILURE);
				}

				{
				constexpr size_t bufferSize = 64 * 1024; // Use a 64KiB buffer for better I/O performance
				unsigned char copyBuff[bufferSize];
				auto ptrReadFunc = !param::raw ? &cd::IsoReader::ReadBytes : &cd::IsoReader::ReadBytesDA;
				size_t bytesLeft = !param::raw ? entry.entry.entrySize.lsb : CD_SECTOR_SIZE * GetSizeInSectors(entry.entry.entrySize.lsb);
				while(bytesLeft > 0) {

					size_t bytesToRead = bytesLeft;

					if (bytesToRead > bufferSize)
						bytesToRead = bufferSize;

					(reader.*ptrReadFunc)(copyBuff, bytesToRead, false);
					fwrite(copyBuff, 1, bytesToRead, outFile);

					bytesLeft -= bytesToRead;

				}
				}

				fclose(outFile);
			}
			else
			{
				if (!param::noWarns)
				{
					printf("WARNING: File %s is of invalid type.\n", entry.identifier.c_str());
				}
				continue;
			}
			if (!param::QuietMode)
			{
				printf("Done.\n");
			}
        }
    }

	// Update timestamps AFTER all files have been extracted
	// else directories will have their timestamps discarded when files are being unpacked into them!
	for (const auto& entry : files)
	{
		if(entry.trackid.empty())
			continue; // Skip unreferenced entries

		fs::path toChange(rootPath / entry.virtualPath / CleanIdentifier(entry.identifier));
		if(entry.type == EntryType::EntryDA)
		{
			toChange = GetEncodedDAPath(toChange);
		}
		UpdateTimestamps(toChange, entry.entry.entryDate);
	}
}

tinyxml2::XMLElement* WriteXMLEntry(const cd::IsoDirEntries::Entry& entry, tinyxml2::XMLElement* dirElement, fs::path* currentVirtualPath,
	const fs::path& sourcePath, EntryAttributeCounters& attributeCounters)
{
	tinyxml2::XMLElement* newelement;

	const fs::path outputPath = sourcePath / entry.virtualPath / CleanIdentifier(entry.identifier);
	if (entry.type == EntryType::EntryDir)
	{
		if (!entry.identifier.empty())
		{
			newelement = dirElement->InsertNewChildElement("dir");
			newelement->SetAttribute(xml::attrib::ENTRY_NAME, entry.identifier.c_str());
			newelement->SetAttribute(xml::attrib::ENTRY_SOURCE, outputPath.generic_string().c_str());
		}
		else
		{
			// Root directory
			newelement = dirElement->InsertNewChildElement(xml::elem::DIRECTORY_TREE);
		}

		dirElement = newelement;
		if (currentVirtualPath != nullptr)
		{
			*currentVirtualPath /= entry.identifier;
		}
    }
	else
	{
        newelement = dirElement->InsertNewChildElement("file");
		newelement->SetAttribute(xml::attrib::ENTRY_NAME, CleanIdentifier(entry.identifier).c_str());
		if(entry.type != EntryType::EntryDA)
		{
			newelement->SetAttribute(xml::attrib::ENTRY_SOURCE, outputPath.generic_string().c_str());
			newelement->SetAttribute(xml::attrib::ENTRY_TYPE, entry.type == EntryType::EntryFile ? "data" : "mixed");	
		}
		else
		{
			newelement->SetAttribute(xml::attrib::TRACK_ID, entry.trackid.c_str());
			newelement->SetAttribute(xml::attrib::ENTRY_TYPE, "da");
		}
	}
	WriteOptionalXMLAttribs(newelement, entry, entry.type, attributeCounters);
	return dirElement;
}

void WriteXMLGap(const unsigned int numSectors, tinyxml2::XMLElement* dirElement, const unsigned int startSector, cd::IsoReader &reader)
{
	if (numSectors < 1) {
		return;
	}
	cd::SECTOR_M2F1 sector;
	reader.SeekToSector(startSector);
	reader.ReadBytesXA(sector.subHead, XA_DATA_SIZE);
	tinyxml2::XMLElement* newelement = dirElement->InsertNewChildElement("dummy");
	newelement->SetAttribute(xml::attrib::NUM_DUMMY_SECTORS, numSectors);
	newelement->SetAttribute(xml::attrib::ENTRY_TYPE, sector.subHead[2]);
	if (param::lba)
	{
		newelement->SetAttribute(xml::attrib::OFFSET, startSector);
	}
}

void WriteXMLPostGap(const unsigned int& postGap, tinyxml2::XMLElement* dirTree, unsigned int& currentLBA, cd::IsoReader& reader)
{
	if (!postGap)
		return;

	// There are some CD-DA games that have a non-zero adrress ECC calculation in the last postgap sector. So, we are checking it.
	// Idk if this behavior could happen in other sectors, but apparently it's only related to CD-DA games postgaps (maybe a bug).
	cd::SECTOR_M2F1 sector;
	reader.SeekToSector(currentLBA + postGap - 1);
	reader.ReadBytesXA(sector.subHead, XA_DATA_SIZE);
	if (memcmp(sector.ecc, "\0\0\0\0", sizeof(sector.edc)))
	{
		WriteXMLGap(postGap - 1, dirTree, currentLBA, reader);
		WriteXMLGap(1, dirTree, currentLBA + postGap - 1, reader);
		dirTree->LastChildElement()->SetAttribute(xml::attrib::ECC_ADDRES, true);
	}
	else
	{
		WriteXMLGap(postGap, dirTree, currentLBA, reader);
	}
	currentLBA += postGap;
}

void WriteXMLByLBA(const std::list<cd::IsoDirEntries::Entry>& files, tinyxml2::XMLElement* dirElement, const fs::path& sourcePath, unsigned int& expectedLBA,
	EntryAttributeCounters& attributeCounters, cd::IsoReader& reader, const unsigned int& postGap)
{
	fs::path currentVirtualPath; // Used to find out whether to traverse 'dir' up or down the chain
	bool writedPostGap = false;
	for (const auto& entry : files)
	{
		// if this is a DA file we are at the end of filesystem
		if (entry.type != EntryType::EntryDA)
		{
			// only check for gaps, update LBA if it's inside the iso filesystem
			if (entry.entry.entryOffs.lsb > expectedLBA)
			{
				WriteXMLGap(entry.entry.entryOffs.lsb - expectedLBA, dirElement, expectedLBA, reader);
			}
			expectedLBA = entry.entry.entryOffs.lsb + GetSizeInSectors(entry.entry.entrySize.lsb);
		}
		else if (entry.trackid.empty())
		{
			continue; // Skip if it's an unreferenced DA file
		}
		else if (!writedPostGap)
		{
			WriteXMLPostGap(postGap, dirElement, expectedLBA, reader);
			writedPostGap = true;
		}

		// Work out the relative position between the current directory and the element to create
		const fs::path relative = entry.virtualPath.lexically_relative(currentVirtualPath);
		for (const fs::path& part : relative)
		{
			if (part == "..")
			{
				// Go up in XML
				dirElement = dirElement->Parent()->ToElement();
				currentVirtualPath = currentVirtualPath.parent_path();
				continue;
			}
			if (part == ".")
			{
				// Do nothing
				continue;
			}

			// "Enter" the directory
			dirElement = dirElement->InsertNewChildElement("dir");
			dirElement->SetAttribute(xml::attrib::ENTRY_NAME, part.generic_string().c_str());

			currentVirtualPath /= part;
		}

		dirElement = WriteXMLEntry(entry, dirElement, &currentVirtualPath, sourcePath, attributeCounters);
	}

	if (!writedPostGap)
	{
		WriteXMLPostGap(postGap, dirElement, expectedLBA, reader);
	}
}

void WriteXMLByDirectories(const cd::IsoDirEntries* directory, tinyxml2::XMLElement* dirElement, const fs::path& sourcePath, unsigned int& expectedLBA,
	EntryAttributeCounters& attributeCounters)
{
	for (const auto& e : directory->dirEntryList.GetView())
	{
		const auto& entry = e.get();

		if (entry.type != EntryType::EntryDA)
		{
			// Update the LBA to the max encountered value
			expectedLBA = std::max(expectedLBA, entry.entry.entryOffs.lsb + GetSizeInSectors(entry.entry.entrySize.lsb));
		}

		tinyxml2::XMLElement* child = WriteXMLEntry(entry, dirElement, nullptr, sourcePath, attributeCounters);
		// Recursively write children if there are any
		if (const cd::IsoDirEntries* subdir = entry.subdir.get(); subdir != nullptr)
		{
			WriteXMLByDirectories(subdir, child, sourcePath, expectedLBA, attributeCounters);
		}
	}
}

void ParseISO(cd::IsoReader& reader) {

    cd::ISO_DESCRIPTOR descriptor;
	bool ps2 = false;
	auto license = ReadLicense(reader);
	const bool xa_edc = CheckEDCXA(reader);
	global::new_type = CheckISOver(reader, ps2);

    reader.SeekToSector(16);
    reader.ReadBytes(&descriptor, F1_DATA_SIZE);


	if (!param::QuietMode)
	{
		printf( "Scanning tracks...\n\n"
				"  Track #1 data:\n"
				"    Identifiers:\n" );
		PrintId("      System ID         : ", descriptor.systemID);
		PrintId("      Volume ID         : ", descriptor.volumeID);
		PrintId("      Volume Set ID     : ", descriptor.volumeSetIdentifier);
		PrintId("      Publisher ID      : ", descriptor.publisherIdentifier);
		PrintId("      Data Preparer ID  : ", descriptor.dataPreparerIdentifier);
		PrintId("      Application ID    : ", descriptor.applicationIdentifier);
		PrintId("      Copyright ID      : ", descriptor.copyrightFileIdentifier);

		PrintDate("      Creation Date     : ", descriptor.volumeCreateDate);
		PrintDate("      Modification Date : ", descriptor.volumeModifyDate);
		PrintDate("      Expiration Date   : ", descriptor.volumeExpiryDate);
	}

    cd::IsoPathTable pathTable;

	size_t numEntries = pathTable.ReadPathTable(&reader, descriptor.pathTable1Offs, descriptor.pathTableSize.lsb);

    if (numEntries == 0) {
		printf("\nNo files to find.\n");
        return;
    }

	if (pathTable.pathTableList[0].entry.dirOffs != descriptor.rootDirRecord.entryOffs.lsb)
	{
		printf("\nERROR: Root directory offset in path table does not match the one in volume descriptor.\n"
				 "       The ISO image may be corrupted or invalid.\n");
		exit(EXIT_FAILURE);
	}

	// Prepare output directories
	for(size_t i=0; i<numEntries; i++)
	{
		const fs::path dirPath = param::outPath / pathTable.GetFullDirPath(i);

		std::error_code ec;
		fs::create_directories(dirPath, ec);
		if (ec)
		{
			printf("\nERROR: Cannot create directory \"%s\". %s\n", dirPath.parent_path().string().c_str(), ec.message().c_str());
			exit(EXIT_FAILURE);
		}
	}

	if (!param::QuietMode)
	{
		if (!param::noxml)
		{
			printf("\n    License file: \"%s\"\n", (param::outPath / "license_data.dat").string().c_str());
		}
		printf("\n    Parsing directory tree...\n");
	}

	std::list<cd::IsoDirEntries::Entry> entries;
	std::unique_ptr<cd::IsoDirEntries> rootDir = ParseRoot(reader, ListView(entries), pathTable.pathTableList);

	// Sort files by LBA for "strict" output
	entries.sort([](const auto& left, const auto& right)
		{
			return left.entry.entryOffs.lsb < right.entry.entryOffs.lsb;
		});

	// Process DA tracks and add them to the entries list
	auto DAfiles = ParseDAfiles(reader, entries);

	unsigned totalLenLBA = descriptor.volumeSize.lsb;
	if (param::force)
	{
		BruteForce(reader, entries, descriptor.rootDirRecord.entryOffs.lsb, totalLenLBA);
	}

	// SYSTEM DESCRIPTION CD-ROM XA Ch.II 2.3, postgap should be always >= 150 sectors for CD-DA discs and optionally for non CD-DA.
	unsigned endFS, postGap = 150;
	for (auto it = entries.rbegin(); it != entries.rend(); it++)
	{
		if (it->type != EntryType::EntryDA)
	 	{
	 		endFS = it->entry.entryOffs.lsb + GetSizeInSectors(it->entry.entrySize.lsb);
			if (!global::cueFile.tracks.empty() && global::cueFile.tracks[0].endSector <= totalLenLBA)
			{
				endFS += postGap = global::cueFile.tracks[0].endSector - endFS;
			}
			else if (!DAfiles.empty())
			{
				endFS += postGap = (DAfiles.front()->entry.entryOffs.lsb - endFS) / 2;
			}
			else if (totalLenLBA - endFS < postGap)
			{
				endFS += postGap = totalLenLBA - endFS;
				if (postGap && !param::noWarns)
				{
					printf("    WARNING: Size of DATA track postgap is of %u sectors instead of 150.\n", postGap);
				}
			}
			break;
		}
	}

	if (!param::QuietMode)
	{
		printf("      Files Total: %zu\n", entries.size() - numEntries);
		printf("      Directories: %zu\n", numEntries - 1);
		printf("      Total file system size: %u bytes (%u sectors)\n", endFS * CD_SECTOR_SIZE, endFS);

		int tracknum = 2;
		for(const auto& entry : DAfiles)
		{
			printf("\n  Track #%d audio:\n", tracknum);
			printf("    DA File \"%s\"\n", CleanIdentifier(entry->identifier).c_str());
			tracknum++;
		}
		printf( "\nExtracting ISO...\n"
				"  Creating files...\n" );
	}

	ExtractFiles(reader, entries, param::outPath);

	if (!param::noxml)
	{
		SaveLicense(*license);
		if (!param::QuietMode)
		{
			printf("  Creating XML document...");
		}
		if (FILE* file = OpenFile(param::xmlFile, "wb"); file != nullptr)
		{
			if (!param::QuietMode)
			{
				printf(" Ok.\n\n");
			}
			tinyxml2::XMLDocument xmldoc;

			tinyxml2::XMLElement *baseElement = static_cast<tinyxml2::XMLElement*>(xmldoc.InsertFirstChild(xmldoc.NewElement(xml::elem::ISO_PROJECT)));
			baseElement->SetAttribute(xml::attrib::IMAGE_NAME, "mkpsxiso.bin");
			baseElement->SetAttribute(xml::attrib::CUE_SHEET, "mkpsxiso.cue");

			tinyxml2::XMLElement *trackElement = baseElement->InsertNewChildElement(xml::elem::TRACK);
			trackElement->SetAttribute(xml::attrib::TRACK_TYPE, "data");
			trackElement->SetAttribute(xml::attrib::XA_EDC, xa_edc);
			trackElement->SetAttribute(xml::attrib::NEW_TYPE, *global::new_type);
			if (ps2)
			{
				trackElement->SetAttribute(xml::attrib::PS2, ps2);
			}

			{
				tinyxml2::XMLElement *newElement = trackElement->InsertNewChildElement(xml::elem::IDENTIFIERS);
				auto setAttributeIfNotEmpty = [newElement](const char* name, std::string_view value)
				{
					if (!value.empty())
					{
						newElement->SetAttribute(name, std::string(value).c_str());
					}
				};

				setAttributeIfNotEmpty(xml::attrib::SYSTEM_ID, CleanDescElement(descriptor.systemID));
				setAttributeIfNotEmpty(xml::attrib::APPLICATION, CleanDescElement(descriptor.applicationIdentifier));
				setAttributeIfNotEmpty(xml::attrib::VOLUME_ID, CleanDescElement(descriptor.volumeID));
				setAttributeIfNotEmpty(xml::attrib::VOLUME_SET, CleanDescElement(descriptor.volumeSetIdentifier));
				setAttributeIfNotEmpty(xml::attrib::PUBLISHER, CleanDescElement(descriptor.publisherIdentifier));
				setAttributeIfNotEmpty(xml::attrib::DATA_PREPARER, CleanDescElement(descriptor.dataPreparerIdentifier));
				setAttributeIfNotEmpty(xml::attrib::COPYRIGHT, CleanDescElement(descriptor.copyrightFileIdentifier));
				newElement->SetAttribute(xml::attrib::CREATION_DATE, LongDateToString(descriptor.volumeCreateDate).c_str());
				if (auto ZERO_DATE = GetUnspecifiedLongDate(); memcmp(&descriptor.volumeModifyDate, &ZERO_DATE, sizeof(descriptor.volumeModifyDate)) != 0)
				{
					// Set only if not zero
					newElement->SetAttribute(xml::attrib::MODIFICATION_DATE, LongDateToString(descriptor.volumeModifyDate).c_str());
				}
			}

			const fs::path xmlPath = param::xmlFile.parent_path();
			const fs::path sourcePath = xmlPath.is_absolute() ? fs::absolute(param::outPath) : param::outPath.lexically_proximate(xmlPath);

			// Add license element to the xml
			{
				tinyxml2::XMLElement *newElement = trackElement->InsertNewChildElement(xml::elem::LICENSE);
				newElement->SetAttribute(xml::attrib::LICENSE_FILE,	(sourcePath / "license_data.dat").generic_string().c_str());
			}

			// Create <default_attributes> now so it lands before the directory tree
			tinyxml2::XMLElement* defaultAttributesElement = trackElement->InsertNewChildElement(xml::elem::DEFAULT_ATTRIBUTES);

			EntryAttributeCounters attributeCounters;
			unsigned currentLBA = descriptor.rootDirRecord.entryOffs.lsb;
			if (param::outputSortedByDir)
			{
				WriteXMLByDirectories(rootDir.get(), trackElement, sourcePath, currentLBA, attributeCounters);		
				WriteXMLPostGap(postGap, trackElement->LastChildElement(), currentLBA, reader);
			}
			else
			{
				WriteXMLByLBA(entries, trackElement, sourcePath, currentLBA, attributeCounters, reader, postGap);
			}

			tinyxml2::XMLElement *dirtree = trackElement->FirstChildElement(xml::elem::DIRECTORY_TREE);
			SimplifyDefaultXMLAttributes(dirtree, EstablishXMLAttributeDefaults(defaultAttributesElement, attributeCounters));

			// Write CD-DA tracks
			tinyxml2::XMLNode *modifyProject = trackElement->Parent();
			tinyxml2::XMLElement *addAfter = trackElement;
			for(const auto& dafile : DAfiles)
			{
				// SYSTEM DESCRIPTION CD-ROM XA Ch.II 2.3, pause should be always >= 150 sectors.
				unsigned pregap_sectors = 150;
				dafile->virtualPath = GetEncodedDAPath(sourcePath / dafile->virtualPath / CleanIdentifier(dafile->identifier));
				if(dafile->entry.entryOffs.lsb != currentLBA)
				{
					pregap_sectors = dafile->entry.entryOffs.lsb - currentLBA;
					currentLBA += pregap_sectors;
				}
				currentLBA += GetSizeInSectors(dafile->entry.entrySize.lsb);
				tinyxml2::XMLElement *newtrack = xmldoc.NewElement(xml::elem::TRACK);
				newtrack->SetAttribute(xml::attrib::TRACK_TYPE, "audio");
				if (!dafile->trackid.empty())
				{
					newtrack->SetAttribute(xml::attrib::TRACK_ID, dafile->trackid.c_str());
				}
				newtrack->SetAttribute(xml::attrib::TRACK_SOURCE, dafile->virtualPath.generic_string().c_str());
				// only write the pregap element if it's non default
				if(pregap_sectors != 150)
				{
					tinyxml2::XMLElement *pregap = newtrack->InsertNewChildElement(xml::elem::TRACK_PREGAP);
					pregap->SetAttribute(xml::attrib::PREGAP_DURATION, SectorsToTimecode(pregap_sectors).c_str());
				}

				modifyProject->InsertAfterChild(addAfter, newtrack);
				addAfter = newtrack;
			}

			// Check if there is still an EoF gap
			if (!param::noWarns && (postGap > 150 || currentLBA < totalLenLBA))
			{
				printf( "WARNING: There is still a gap of %u sectors at the end of file system.\n"
						"\t This could mean that there are missing files or tracks.\n", postGap > 150 ? postGap : totalLenLBA - currentLBA);
				if (global::cueFile.tracks.empty())
				{
					printf("\t Try using a .cue file instead of an ISO image.\n");
				}
				else
				{
					printf("\t Try using the -pt or/and -f command, helps with obfuscated file systems.\n");
				}
			}

			xmldoc.SaveFile(file);
			fclose(file);
		}
		else
		{
			printf("\nERROR: Cannot create xml file \"%s\". %s\n", param::xmlFile.string().c_str(), strerror(errno));
			exit(EXIT_FAILURE);
		}
	}

	if (!param::QuietMode)
	{
		printf("ISO image dumped successfully.\n");
	}
}

int Main(int argc, char *argv[])
{
	static constexpr const char* HELP_TEXT =
		"Usage: dumpsxiso [options <file>] <isofile>\n\n"
		"  <isofile>\t\tFile name of the bin/cue file (supports any 2352 byte/sector images)\n\n"
		"Options:\n"
		"  -h|--help\t\tShows this help text\n"
		"  -q|--quiet\t\tQuiet mode (suppress all but warnings and errors)\n"
		"  -w|--warns\t\tSuppress all warnings (can be used along with -q)\n"
		"  -x <path>\t\tOptional destination directory for extracted files (defaults to working dir)\n"
		"  -s <file>\t\tOptional XML name/destination for MKPSXISO script (defaults to working dir)\n"
		"  -pt|--path-table\tGo through every known directory in order; helps on soft obfuscated games (like DMW3)\n"
		"  -f|--force\t\tScans all unknown sectors for files; helps on heavy obfuscated games (like Xenogears)\n"
		"  -e|--encode <codec>\tCodec to encode CDDA/DA audio; supports " SUPPORTED_CODEC_TEXT " (defaults to wave)\n"
		"  -l|--lba\t\tWrites all lba offsets in the xml to force them at build time\n"
		"  -n|--noxml\t\tDo not generate an XML file and license file\n"
		"  -r|--raw\t\tDumps all files in raw format (forces --noxml option)\n"
		"  -S|--sort-by-dir\tOutputs a \"pretty\" XML script where entries are grouped in directories\n"
		"\t\t\t(instead of strictly following their original order on the disc)\n";

	static constexpr const char* VERSION_TEXT =
		"DUMPSXISO " VERSION " - PlayStation ISO dumping tool\n"
		"Get the latest version at https://github.com/Lameguy64/mkpsxiso\n"
		"Original work: Meido-Tek Productions (John \"Lameguy\" Wilbert Villamor/Lameguy64)\n"
		"Maintained by: Silent (CookiePLMonster) and spicyjpeg\n"
		"Contributions: marco-calautti, G4Vi, Nagtan and all the ones from github\n\n";

	if (argc == 1)
	{
		printf(VERSION_TEXT);
		printf(HELP_TEXT);
		return EXIT_SUCCESS;
	}

	for (char** args = argv+1; *args != nullptr; args++)
	{
		// Is it a switch?
		if ((*args)[0] == '-')
		{
			if (ParseArgument(args, "h", "help"))
			{
				printf(VERSION_TEXT);
				printf(HELP_TEXT);
				return EXIT_SUCCESS;
			}
			if (ParseArgument(args, "f", "force"))
			{
				param::force = true;
				continue;
			}
			if (ParseArgument(args, "l", "lba"))
			{
				param::lba = true;
				continue;
			}
			if (ParseArgument(args, "n", "noxml"))
			{
				param::noxml = true;
				continue;
			}
			if (ParseArgument(args, "pt", "path-table"))
			{
				param::pathTable = true;
				continue;
			}
			if (ParseArgument(args, "q", "quiet"))
			{
				param::QuietMode = true;
				continue;
			}
			if (ParseArgument(args, "r", "raw"))
			{
				param::raw = true;
				param::noxml = true;
				param::encodingFormat = EAF_PCM;
				continue;
			}
			if (ParseArgument(args, "w", "warns"))
			{
				param::noWarns = true;
				continue;
			}
			if (ParseArgument(args, "S", "sort-by-dir"))
			{
				param::outputSortedByDir = true;
				continue;
			}
			if (auto outPath = ParsePathArgument(args, "x"); outPath.has_value())
			{
				param::outPath = outPath->lexically_normal();
				continue;
			}
			if (auto xmlPath = ParsePathArgument(args, "s"); xmlPath.has_value())
			{
				param::xmlFile = xmlPath->lexically_normal();
				continue;
			}
			if(auto encodingStr = ParseStringArgument(args, "e", "encode"); encodingStr.has_value())
			{
				unsigned i;
				for(i = 0; i < std::size(EncodingCodecs); i++)
				{
					if(CompareICase(*encodingStr, EncodingCodecs[i].codec))
					{
						break;
					}
				}
				if(i == std::size(EncodingCodecs))
				{
					printf("Unknown codec: %s\n", (*encodingStr).c_str());
					printf("Supported codecs: %s\n", SUPPORTED_CODEC_TEXT);
				    return EXIT_FAILURE;
				}
				if(EncodingCodecs[i].eaf & SUPPORTED_CODECS)
				{
					param::encodingFormat = EncodingCodecs[i].eaf;
					continue;
				}
				printf("%s", EncodingCodecs[i].notcompiledmessage);
				return EXIT_FAILURE;
			}

			// If we reach this point, an unknown parameter was passed
			printf("Unknown parameter: %s\n", *args);
			return EXIT_FAILURE;
		}

		if (param::isoFile.empty())
		{
			param::isoFile = fs::path(*args).lexically_normal().lexically_proximate(fs::current_path());
		}
		else
		{
			printf("Only one ISO file is supported.\n");
			return EXIT_FAILURE;
		}
	}

	if (param::isoFile.empty())
	{
		printf("No iso file specified.\n");
		return EXIT_FAILURE;
	}

	if (!param::QuietMode)
	{
		printf(VERSION_TEXT);
	}

	if (param::outPath.empty())
	{
		param::outPath = param::isoFile.stem();
	}

	if (param::xmlFile.empty())
	{
		param::xmlFile = param::isoFile.stem() += ".xml";
	}

	if (CompareICase(param::isoFile.extension().string(), ".cue"))
	{
		global::cueFile = parseCueFile(param::isoFile);
	}

	cd::IsoReader reader;

	if (!reader.Open(param::isoFile)) {

		printf("ERROR: Cannot open file \"%s\"\n", param::isoFile.string().c_str());
		return EXIT_FAILURE;

	}
	
	// Check if file has a valid ISO9660 header
	{
		cd::ISO_DESCRIPTOR descriptor;
		if (!reader.SeekToSector(16) || !reader.ReadBytes(&descriptor, F1_DATA_SIZE, true) || memcmp(&descriptor.header, "\1CD001\1", 7))
		{
			printf("ERROR: File does not contain a valid ISO9660 file system.\n");
			return EXIT_FAILURE;
		}
	}

	if (!param::QuietMode)
	{
		printf("Output directory : \"%s\"\n\n", param::outPath.string().c_str());
	}

	tzset(); // Initializes the time-related environment variables
    ParseISO(reader);
	return EXIT_SUCCESS;
}
