#define VERSION "2.20"
#include "mkpsxiso/src/mkpsxiso/main.cpp"
#define MALLOC_CHECK(var) if (var == NULL) { PyErr_NoMemory(); return NULL; }

extern "C"
{
    #include <Python.h>

    static PyObject *method_run(PyObject *self, PyObject *args, PyObject *kwargs)
    {
        char *filename = NULL;
        char *cuename = NULL;
        char *xml = NULL;

        static char *kwlist[] = {"filename", "cuename", "xml",
                                 NULL};

        if(!PyArg_ParseTupleAndKeywords(args, kwargs, "sss", kwlist,
                                        &filename, &cuename, &xml))
            return NULL;

        int argc = 7;
        char** argv = (char**)PyMem_Malloc(sizeof(char*) * (argc + 1));
        MALLOC_CHECK(argv);
        argv[0] = "mkpsxiso";
        argv[1] = "-y";
        argv[2] = "-c";
        argv[3] = cuename;
        argv[4] = "-o";
        argv[5] = filename;
        argv[6] = xml;
        argv[7] = NULL;
        int result = Main(argc, argv);
        PyMem_Free(argv);
        return PyBool_FromLong((long)(result == 0));
    }

    static PyMethodDef PymkpsxisoMethods[] = {
        {"run", (PyCFunction)method_run, METH_VARARGS | METH_KEYWORDS, "Call mkpsxiso command."},
        {NULL, NULL, 0, NULL}
    };

    static struct PyModuleDef pymkpsxisomodule = {
        PyModuleDef_HEAD_INIT,
        "pymkpsxiso",
        "Python interface for mkpsxiso.",
        -1,
        PymkpsxisoMethods
    };

    PyMODINIT_FUNC PyInit_pymkpsxiso(void)
    {
        return PyModule_Create(&pymkpsxisomodule);
    }
}
