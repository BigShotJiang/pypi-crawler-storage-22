""":class:`~pymkv.MKVFile` is the core class of pymkv. It is used to import, create, modify, and mux MKV files.

Examples
--------
Below are some basic examples of how the :class:`~pymkv.MKVFile` objects can be used.

Create and mux a new MKV. This example takes an standalone video and audio track and combines them into an MKV file.

>>> from pymkv import MKVFile
>>> mkv = MKVFile()
>>> mkv.add_track('/path/to/track.h264')  # doctest: +SKIP
>>> mkv.add_track(MKVTrack('/path/to/track.aac'))  # doctest: +SKIP
>>> mkv.mux('/path/to/output.mkv')  # doctest: +SKIP

Generate the mkvmerge command to mux an MKV. This is example is identical to the first example except the command is
only generated, not executed.

>>> mkv = MKVFile()  # doctest: +SKIP
>>> mkv.add_track('/path/to/track.h264')  # doctest: +SKIP
>>> mkv.add_track(MKVTrack('/path/to/another/track.aac'))  # doctest: +SKIP
>>> mkv.command('/path/to/output.mkv')  # doctest: +SKIP

Add chapters to an MKV file using chapter objects:

>>> from pymkv.chapters import ChapterAtom, ChapterDisplay  # doctest: +SKIP
>>> atom = ChapterAtom(time_start="00:00:00.000", displays=[ChapterDisplay(string="Intro")])  # doctest: +SKIP
>>> mkv.add_chapter(atom)  # doctest: +SKIP

Import an existing MKV and remove a track. This example will import an MKV that already exists on your filesystem,
remove a track and allow you to mux that change into a new file.

>>> mkv = MKVFile('/path/to/file.mkv')  # doctest: +SKIP
>>> mkv.get_track(0).track_name = 'Some Name'  # doctest: +SKIP
>>> mkv.mux('/path/to/output.mkv')  # doctest: +SKIP

Combine two MKVs. This example takes two existing MKVs and combines their tracks into a single MKV file.

>>> mkv1 = MKVFile('/path/to/file1.mkv')  # doctest: +SKIP
>>> mkv2 = MKVFile('/path/to/file2.mkv')  # doctest: +SKIP
>>> mkv1.add_file(mkv2)  # doctest: +SKIP
>>> mkv1.mux('/path/to/output.mkv')  # doctest: +SKIP
>>>
>>> # Use a progress handler to track muxing progress
>>> def progress(p):
...     print(f"Progress: {p}%")
>>>
>>> mkv = MKVFile('/path/to/file.mkv')  # doctest: +SKIP
>>> mkv.mux('/path/to/output.mkv', progress_handler=progress)  # doctest: +SKIP
>>>
>>> # Inspect attachments from an existing file
>>> mkv = MKVFile('/path/to/with_attachments.mkv')  # doctest: +SKIP
>>> for attachment in mkv.attachments:
...     print(f"Attachment: {attachment.name}, MIME: {attachment.mime_type}")
"""

from __future__ import annotations

import itertools
import logging
import os
import re
import subprocess as sp
import tempfile
from collections.abc import Callable, Iterable, Sequence
from pathlib import Path
from typing import Any, TypeVar, cast

import bitmath
import msgspec

from pymkv.chapters import (
    ChapterAtom,
    Chapters,
    EditionEntry,
    export_to_xml,
)
from pymkv.command_generators import (
    AttachmentOptions,
    BaseOptions,
    ChapterOptions,
    CommandGeneratorBase,
    GlobalOptions,
    LinkingOptions,
    SplitOptions,
    TrackOptions,
    TrackOrderOptions,
)
from pymkv.ISO639_2 import is_iso639_2
from pymkv.MKVAttachment import MKVAttachment
from pymkv.MKVTrack import MKVTrack
from pymkv.models import MkvMergeOutput, TrackProperties
from pymkv.Timestamp import Timestamp
from pymkv.utils import prepare_mkvtoolnix_path
from pymkv.Verifications import (
    checking_file_path,
    get_file_info,
    verify_mkvmerge,
)

T = TypeVar("T")


class MKVFile:
    """
    A class that represents an MKV file.

    The :class:`~pymkv.MKVFile` class can either import a pre-existing MKV file or create a new one. After an
    :class:`~pymkv.MKVFile` object has been instantiated, :class:`~pymkv.MKVTrack` objects or other
    :class:`~pymkv.MKVFile` objects can be added using :meth:`~pymkv.MKVFile.add_track` and
    :meth:`~pymkv.MKVFile.add_file` respectively.

    Tracks are always added in the same order that they exist in a file or are added in. They can be reordered
    using :meth:`~pymkv.MKVFile.move_track_front`, :meth:`~pymkv.MKVFile.move_track_end`,
    :meth:`~pymkv.MKVFile.move_track_forward`, :meth:`~pymkv.MKVFile.move_track_backward`,
    or :meth:`~pymkv.MKVFile.swap_tracks`.

    After an :class:`~pymkv.MKVFile` has been created, an mkvmerge command can be generated using
    :meth:`~pymkv.MKVFile.command` or the file can be muxed using :meth:`~pymkv.MKVFile.mux`.

    Parameters
    ----------
    file_path : str, optional
        Path to a pre-existing MKV file. The file will be imported into the new :class:`~pymkv.MKVFile` object.
    title : str, optional
        The internal title given to the :class:`~pymkv.MKVFile`. If `title` is not specified, the title of the
        pre-existing file will be used if it exists.
    mkvmerge_path : str, optional
        The path where pymkv looks for the mkvmerge executable. pymkv relies on the mkvmerge executable to parse
        files. By default, it is assumed mkvmerge is in your shell's $PATH variable. If it is not, you need to set
        *mkvmerge_path* to the executable location.

    Raises
    ------
    FileNotFoundError
        Raised if the path to mkvmerge could not be verified.
    """

    def __init__(
        self,
        file_path: str | os.PathLike | None = None,
        title: str | None = None,
        mkvmerge_path: str | os.PathLike | Iterable[str] = "mkvmerge",
    ) -> None:
        self.mkvmerge_path: tuple[str, ...] = prepare_mkvtoolnix_path(mkvmerge_path)
        self.title = title
        self._chapters_file: str | None = None
        self.chapters_obj: Chapters | None = None
        self._temp_chapters_file: str | None = None
        self._chapter_language: str | None = None
        self._global_tags_file: str | None = None
        self._link_to_previous_file: str | None = None
        self._link_to_next_file: str | None = None
        self.tracks: list[MKVTrack] = []
        self.attachments: list[MKVAttachment] = []
        self._number_file = 0
        self._info_json: MkvMergeOutput | None = None
        self._global_tag_entries = 0

        # exclusions
        self.no_track_statistics_tags = False

        if not verify_mkvmerge(mkvmerge_path=self.mkvmerge_path):
            msg = "mkvmerge is not at the specified path, add it there or changed mkvmerge_path property"
            raise FileNotFoundError(msg)

        if file_path is not None:
            file_path = checking_file_path(file_path)
            try:
                # Get raw output and decode using msgspec
                # Get info using get_file_info which returns MkvMergeOutput
                info_struct = get_file_info(
                    file_path,
                    self.mkvmerge_path,
                    check_path=False,
                )
                self._info_json = info_struct
            except (sp.CalledProcessError, msgspec.ValidationError) as e:
                # Wrap msgspec validation error or process error
                if isinstance(e, sp.CalledProcessError):
                    error_output = e.output.decode()
                    raise sp.CalledProcessError(
                        e.returncode,
                        e.cmd,
                        output=error_output,
                    ) from e
                msg = f"Invalid JSON or schema from mkvmerge: {e}"
                raise ValueError(msg) from e

            if not info_struct.container.supported:
                msg = f"The file '{file_path}' is not a valid Matroska file or is not supported."
                raise ValueError(msg)

            if self.title is None and info_struct.container.properties.title:
                self.title = info_struct.container.properties.title

            self._global_tag_entries = sum(t.num_entries for t in info_struct.global_tags)

            # dictionary associating track_id to the number of tag entries:
            # We used info_json.get("track_tags", []) before. Struct has track_tags list.
            track_tag_entries: dict[int, int] = {
                t.track_id: t.num_entries for t in info_struct.track_tags if t.track_id is not None
            }

            # add tracks with info
            for track_info in info_struct.tracks:
                track_id = track_info.id
                new_track = MKVTrack(
                    file_path,
                    track_id=track_id,
                    mkvmerge_path=self.mkvmerge_path,
                    existing_info=info_struct,
                    tag_entries=track_tag_entries.get(track_id, 0),
                )

                # Declarative mapping using msgspec struct fields
                props = track_info.properties
                # Iterate over defined fields in TrackProperties
                for field_info in msgspec.structs.fields(TrackProperties):
                    field_name = field_info.name
                    value = getattr(props, field_name)
                    if value is not None:
                        setattr(new_track, field_name, value)

                self.add_track(new_track, new_file=False)

            if info_struct.attachments:
                for attachment in info_struct.attachments:
                    attachment_id = attachment.id
                    properties = attachment.properties
                    name = attachment.file_name or properties.name
                    description = attachment.description or properties.description
                    mime_type = attachment.content_type or properties.mime_type

                    new_attachment = MKVAttachment(file_path)
                    new_attachment.name = name
                    new_attachment.description = description
                    new_attachment.mime_type = mime_type
                    new_attachment.source_id = attachment_id
                    new_attachment.source_file = file_path
                    self.attachments.append(new_attachment)

        # split options
        self._split_options: list[str] = []
        self._progress_handler = None

    def __repr__(self) -> str:
        """
        Return a string representation of the MKVFile object.

        Returns:
            str: A string representation of the object's attributes.
        """
        return repr(self.__dict__)

    @property
    def chapter_language(self) -> str | None:
        """
        Get the language code of the chapters in the MKVFile object.

        Returns:
            str: The ISO 639-2 language code of the chapters.

        Raises:
            ValueError: If the stored language code is not a valid ISO 639-2 language code.
        """
        return self._chapter_language

    @chapter_language.setter
    def chapter_language(self, language: str | None) -> None:
        """
        Set the language code of the chapters in the MKVFile object.

        Args:
            language (str): The language code for the chapters. Must be a valid ISO 639-2 language code.

        Raises:
            ValueError: If the provided language code is not a valid ISO 639-2 language code.
        """
        if language is not None and not is_iso639_2(language):
            msg = "The provided language code is not a valid ISO 639-2 language code."
            raise ValueError(msg)
        self._chapter_language = language

    @property
    def global_tag_entries(self) -> int:
        """
        Gets the number of global tag entries in the MKVFile object.

        Returns:
            int: The number of entries.
        """
        return self._global_tag_entries

    def command(
        self,
        output_path: str,
        subprocess: bool = False,
    ) -> str | list[str]:
        """
        Generates an mkvmerge command based on the configured :class:`~pymkv.MKVFile`.

        Parameters
        ----------
        output_path : str
            The path to be used as the output file in the mkvmerge command.
        subprocess : bool
            Will return the command as a list so it can be used easily with the :mod:`subprocess` module.

        Returns
        -------
        str, list of str
            The full command to mux the :class:`~pymkv.MKVFile` as a string containing spaces. Will be returned as a
            list of strings with no spaces if `subprocess` is True.

        Examples
        --------
        >>> mkv = MKVFile()
        >>> mkv.add_track('path/to/track.h264')  # doctest: +SKIP
        >>> # Generate command string
        >>> cmd_str = mkv.command('output.mkv')  # doctest: +SKIP
        >>> print(cmd_str)  # doctest: +SKIP
        mkvmerge -o output.mkv path/to/track.h264
        >>> # Generate command list for subprocess
        >>> cmd_list = mkv.command('output.mkv', subprocess=True)  # doctest: +SKIP
        >>> print(cmd_list)  # doctest: +SKIP
        ['mkvmerge', '-o', 'output.mkv', 'path/to/track.h264']
        """

        self.output_path = str(Path(output_path).expanduser())

        # Handle object-based chapters
        if self.chapters_obj and not self._chapters_file:
            self._write_chapters_xml()

        # Pre-assign file IDs
        unique_file_dict: dict[str, int] = {}
        for track in self.tracks:
            if track.file_path not in unique_file_dict:
                unique_file_dict[track.file_path] = len(unique_file_dict)
            track.file_id = unique_file_dict[track.file_path]

        pipeline: list[CommandGeneratorBase] = [
            BaseOptions(),
            GlobalOptions(),
            TrackOptions(),
            AttachmentOptions(),
            ChapterOptions(),
            LinkingOptions(),
            TrackOrderOptions(),
            SplitOptions(),
        ]

        command_args = list(self.mkvmerge_path)
        generated_args = list(itertools.chain.from_iterable(p.generate(self) for p in pipeline))
        command_args.extend(generated_args)

        return command_args if subprocess else " ".join(command_args)

    def mux(
        self,
        output_path: str | os.PathLike,
        silent: bool = False,
        ignore_warning: bool = False,
        progress_handler: Callable[[int], None] | None = None,
    ) -> int:
        """
        Mixes the specified :class:`~pymkv.MKVFile`.

        Parameters
        ----------
        output_path : str
            The path to be used as the output file in the mkvmerge command.
        silent : bool, optional
            By default the mkvmerge output will be shown unless silent is True.
        ignore_warning : bool, optional
            If set to True, the muxing process will ignore any warnings (exit code 1) from mkvmerge.
        progress_handler : Callable[[int], None], optional
            A callback function that will be called with the current progress percentage (0-100).

        Returns
        -------
        int
            return code

        Raises
        ------
        ValueError
            Raised if the external mkvmerge command fails with a non-zero exit status
            (except for warnings when ignore_warning is True).

        Examples
        --------
        >>> mkv = MKVFile()
        >>> mkv.add_track('video.h264')  # doctest: +SKIP
        >>> # Basic muxing
        >>> mkv.mux('output.mkv')  # doctest: +SKIP
        0
        >>> # Muxing silently
        >>> mkv.mux('output.mkv', silent=True)  # doctest: +SKIP
        0
        >>> # Muxing with progress handler
        >>> def progress(p):
        ...     print(f"Progress: {p}%")
        >>> mkv.mux('output.mkv', progress_handler=progress)  # doctest: +SKIP
        0
        """
        output_path = str(Path(output_path).expanduser())
        args = self.command(output_path, subprocess=True)

        if progress_handler:
            stdout_target = sp.PIPE
            text_mode = True
        elif silent:
            stdout_target = sp.DEVNULL
            text_mode = False
        else:
            stdout_target = None  # Inherit stdout (print to console)
            text_mode = False

        stderr_target = sp.PIPE  # Always capture stderr for error reporting

        proc = sp.Popen(  # noqa: S603
            args,
            stdout=stdout_target,
            stderr=stderr_target,
            text=text_mode,
            bufsize=1 if text_mode else -1,
        )

        # Process stdout if handling progress
        if progress_handler and proc.stdout:
            progress_re = re.compile(r"Progress:\s*(\d+)%")
            for line in proc.stdout:
                if match := progress_re.search(line):
                    percent = int(match.group(1))
                    progress_handler(percent)

        # Wait for completion and get stderr
        _, err = proc.communicate()

        if proc.returncode != 0:
            # Handle warnings (exit code 1) if ignore_warning is True
            if proc.returncode == 1 and ignore_warning:
                logging.warning("Process completed with warnings, but ignored as per the setting.")
            else:
                # For other non-zero exit codes, raise an exception
                error_message = f"Command failed with non-zero exit status {proc.returncode}"
                if err:
                    error_details = err.decode() if isinstance(err, bytes) else err
                    error_message += f"\nError Output:\n{error_details}"
                    logging.error(error_details)
                logging.error(
                    "Non-zero exit status when running %s (%s)",
                    args,
                    proc.returncode,
                )
                raise ValueError(error_message)

        return proc.returncode

    def _write_chapters_xml(self) -> None:
        """
        Write chapter objects to a temporary XML file.
        """
        if not self.chapters_obj:
            return

        with tempfile.NamedTemporaryFile(mode="w", suffix=".xml", delete=False, encoding="utf-8") as tf:
            xml_content = export_to_xml(self.chapters_obj)
            tf.write(xml_content)

        self._temp_chapters_file = tf.name
        self._chapters_file = tf.name

    def add_chapter(self, chapter: ChapterAtom | EditionEntry) -> None:
        """
        Add a chapter or edition entry to the MKVFile.

        If a ChapterAtom is provided, it is added to the first EditionEntry (creating one if needed).
        If an EditionEntry is provided, it is added to the list of editions.

        Parameters
        ----------
        chapter : ChapterAtom | EditionEntry
            The chapter object to add.

        Examples
        --------
        >>> from pymkv import MKVFile, MKVTrack
        >>> from pymkv.chapters import ChapterAtom, ChapterDisplay
        >>>
        >>> mkv = MKVFile()
        >>>
        >>> # Method 1: Add simple chapter directly
        >>> atom = ChapterAtom(
        ...     time_start="00:00:00.000",
        ...     displays=[ChapterDisplay(string="Intro")]
        ... )
        >>> mkv.add_chapter(atom)
        >>>
        >>> # Method 2: Use helper on internal object
        >>> # Ensure chapters_obj is initialized if accessing directly
        >>> if mkv.chapters_obj is None:
        ...     from pymkv.chapters import Chapters
        ...     mkv.chapters_obj = Chapters()
        >>> mkv.chapters_obj.add_simple_chapter("00:10:00.000", "Part 2")
        >>>
        >>> # XML is automatically generated during mux/command
        >>> # cmd = mkv.command("output.mkv")
        """
        if self.chapters_obj is None:
            self.chapters_obj = Chapters()

        if isinstance(chapter, ChapterAtom):
            if not self.chapters_obj.editions:
                self.chapters_obj.editions.append(EditionEntry())
            self.chapters_obj.editions[0].atoms.append(chapter)
        elif isinstance(chapter, EditionEntry):
            self.chapters_obj.editions.append(chapter)
        else:
            msg = "chapter must be ChapterAtom or EditionEntry"
            raise TypeError(msg)

    def add_file(self, file: MKVFile | str | os.PathLike) -> None:
        """
        Add an MKV file into the :class:`~pymkv.MKVFile` object.

        Parameters
        ----------
        file : str, :class:`~pymkv.MKVFile`, os.PathLike
            The file to be combined with the :class:`~pymkv.MKVFile` object.

        Raises
        ------
        TypeError
            Raised if if `file` is not a string-like path to an MKV file or an :class:`~pymkv.MKVFile` object.

        Examples
        --------
        >>> mkv1 = MKVFile('part1.mkv')  # doctest: +SKIP
        >>> mkv2 = MKVFile('part2.mkv')  # doctest: +SKIP
        >>> # Concatenate mkv2 to mkv1
        >>> mkv1.add_file(mkv2)  # doctest: +SKIP
        >>> # Add file directly from path
        >>> mkv1.add_file('part3.mkv')  # doctest: +SKIP
        """
        if isinstance(file, (str, os.PathLike)):
            self._number_file += 1
            new_tracks = MKVFile(file).tracks
            for track in new_tracks:
                track.file_id = self._number_file
            self.tracks = self.tracks + new_tracks
        elif isinstance(file, MKVFile):
            self._number_file += 1
            for track in file.tracks:
                track.file_id = self._number_file
            self.tracks = self.tracks + file.tracks
        else:
            msg = "track is not str or MKVFile"
            raise TypeError(msg)
        self.order_tracks_by_file_id()

    def add_track(self, track: str | MKVTrack, new_file: bool = True) -> None:
        """
        Add a track to the :class:`~pymkv.MKVFile`.

        Parameters
        ----------
        track : str, :class:`~pymkv.MKVTrack`
            The track to be added to the :class:`~pymkv.MKVFile` object.
        new_file : bool, optional
            If set to True, the file_id for the added track is not incremented. This can be used to preserve
            original track numbering from a source file.

        Raises
        ------
        TypeError
            Raised if `track` is not a string-like path to a track file or an :class:`~pymkv.MKVTrack`.

        Examples
        --------
        >>> mkv = MKVFile()
        >>> # Add a track from a file path
        >>> mkv.add_track('video.h264')  # doctest: +SKIP
        >>> # Add an MKVTrack object
        >>> track = MKVTrack('audio.aac', language='eng')  # doctest: +SKIP
        >>> mkv.add_track(track)  # doctest: +SKIP
        """
        if isinstance(track, str):
            new_track = MKVTrack(
                track,
                mkvmerge_path=self.mkvmerge_path,
                existing_info=self._info_json,
            )
            self._extracted_from_add_track(new_track, new_file)
        elif isinstance(track, MKVTrack):
            self._extracted_from_add_track(track, new_file)
        else:
            msg = "track is not str or MKVTrack"
            raise TypeError(msg)
        self.order_tracks_by_file_id()

    def _extracted_from_add_track(
        self,
        track: MKVTrack,
        new_file: bool = False,
    ) -> None:
        if new_file:
            self._number_file += 1
        track.file_id = self._number_file
        self.tracks.append(track)

    def add_attachment(self, attachment: str | MKVAttachment) -> None:
        """
        Add an attachment to the :class:`~pymkv.MKVFile`.

        Parameters
        ----------
        attachment : str, :class:`~pymkv.MKVAttachment`
            The attachment to be added to the :class:`~pymkv.MKVFile` object.

        Raises
        ------
        TypeError
            Raised if if `attachment` is not a string-like path to an attachment file
            or an :class:`~pymkv.MKVAttachment`.

        Examples
        --------
        >>> mkv = MKVFile()
        >>> # Add attachment from file path
        >>> mkv.add_attachment('cover.jpg')  # doctest: +SKIP
        >>> # Add MKVAttachment object
        >>> att = MKVAttachment('font.ttf', name='Font')  # doctest: +SKIP
        >>> mkv.add_attachment(att)  # doctest: +SKIP
        """
        if isinstance(attachment, str):
            self.attachments.append(MKVAttachment(attachment))
        elif isinstance(attachment, MKVAttachment):
            self.attachments.append(attachment)
        else:
            msg = "Attachment is not str of MKVAttachment"
            raise TypeError(msg)

    def get_track(self, track_num: int | None = None) -> MKVTrack | list[MKVTrack]:
        """
        Get a :class:`~pymkv.MKVTrack` from the :class:`~pymkv.MKVFile` object.

        Parameters
        ----------
        track_num : int, optional
            Index of track to retrieve. Will return list of :class:`~pymkv.MKVTrack` objects if argument is not
            provided.

        Returns
        -------
        :class:`~pymkv.MKVTrack`, list of :class:`~pymkv.MKVTrack`
            A list of all :class:`~pymkv.MKVTrack` objects in an :class:`~pymkv.MKVFile`. Returns a specific
            :class:`~pymkv.MKVTrack` if `track_num` is specified.

        Examples
        --------
        >>> mkv = MKVFile('input.mkv')  # doctest: +SKIP
        >>> # Get all tracks
        >>> all_tracks = mkv.get_track()  # doctest: +SKIP
        >>> # Get the first track
        >>> first_track = mkv.get_track(0)  # doctest: +SKIP
        """
        return self.tracks if track_num is None else self.tracks[track_num]

    def move_track_front(self, track_num: int) -> None:
        """
        Set a track as the first in the :class:`~pymkv.MKVFile` object.

        Parameters
        ----------
        track_num : int
            The track number of the track to move to the front.

        Raises
        ------
        IndexError
            Raised if `track_num` is is out of range of the track list.

        Examples
        --------
        >>> mkv = MKVFile()
        >>> mkv.add_track('track1.mkv')  # doctest: +SKIP
        >>> mkv.add_track('track2.mkv')  # doctest: +SKIP
        >>> mkv.move_track_front(1)  # doctest: +SKIP
        """
        if not 0 <= track_num < len(self.tracks):
            msg = "track index out of range"
            raise IndexError(msg)
        self.tracks.insert(0, self.tracks.pop(track_num))
        self.order_tracks_by_file_id()

    def move_track_end(self, track_num: int) -> None:
        """
        Set as track as the last in the :class:`~pymkv.MKVFile` object.

        Parameters
        ----------
        track_num : int
            The track number of the track to move to the back.

        Raises
        ------
        IndexError
            Raised if `track_num` is is out of range of the track list.

        Examples
        --------
        >>> mkv = MKVFile()
        >>> mkv.add_track('track1.mkv')  # doctest: +SKIP
        >>> mkv.add_track('track2.mkv')  # doctest: +SKIP
        >>> mkv.move_track_end(0)  # doctest: +SKIP
        """
        if not 0 <= track_num < len(self.tracks):
            msg = "track index out of range"
            raise IndexError(msg)
        self.tracks.append(self.tracks.pop(track_num))
        self.order_tracks_by_file_id()

    def move_track_forward(self, track_num: int) -> None:
        """
        Move a track forward in the :class:`~pymkv.MKVFile` object.

        Parameters
        ----------
        track_num : int
            The track number of the track to move forward.

        Raises
        ------
        IndexError
            Raised if `track_num` is is out of range of the track list.

        Examples
        --------
        >>> mkv = MKVFile()
        >>> mkv.add_track('track1.mkv')  # doctest: +SKIP
        >>> mkv.add_track('track2.mkv')  # doctest: +SKIP
        >>> mkv.move_track_forward(0)  # doctest: +SKIP
        """
        if not 0 <= track_num < len(self.tracks) - 1:
            msg = "Track index out of range"
            raise IndexError(msg)
        self.tracks[track_num], self.tracks[track_num + 1] = (
            self.tracks[track_num + 1],
            self.tracks[track_num],
        )
        self.order_tracks_by_file_id()

    def move_track_backward(self, track_num: int) -> None:
        """
        Move a track backward in the :class:`~pymkv.MKVFile` object.

        Parameters
        ----------
        track_num : int
            The track number of the track to move backward.

        Raises
        ------
        IndexError
            Raised if `track_num` is is out of range of the track list.

        Examples
        --------
        >>> mkv = MKVFile()
        >>> mkv.add_track('track1.mkv')  # doctest: +SKIP
        >>> mkv.add_track('track2.mkv')  # doctest: +SKIP
        >>> mkv.move_track_backward(1)  # doctest: +SKIP
        """
        if not 0 < track_num < len(self.tracks):
            msg = "Track index out of range"
            raise IndexError(msg)
        self.tracks[track_num], self.tracks[track_num - 1] = (
            self.tracks[track_num - 1],
            self.tracks[track_num],
        )
        self.order_tracks_by_file_id()

    def swap_tracks(self, track_num_1: int, track_num_2: int) -> None:
        """
        Swap the position of two tracks in the :class:`~pymkv.MKVFile` object.

        Parameters
        ----------
        track_num_1 : int
            The track number of one track to swap.
        track_num_2 : int
            The track number of the other track to swap

        Raises
        ------
        IndexError
            Raised if `track_num_1` or `track_num_2` are out of range of the track list.

        Examples
        --------
        >>> mkv = MKVFile()
        >>> mkv.add_track('track1.mkv')  # doctest: +SKIP
        >>> mkv.add_track('track2.mkv')  # doctest: +SKIP
        >>> mkv.swap_tracks(0, 1)  # doctest: +SKIP
        """
        if not 0 <= track_num_1 < len(self.tracks) or not 0 <= track_num_2 < len(
            self.tracks,
        ):
            msg = "Track index out of range"
            raise IndexError(msg)
        self.tracks[track_num_1], self.tracks[track_num_2] = (
            self.tracks[track_num_2],
            self.tracks[track_num_1],
        )
        self.order_tracks_by_file_id()

    def replace_track(self, track_num: int, track: MKVTrack) -> None:
        """
        Replace a track with another track in the :class:`~pymkv.MKVFile` object.

        Parameters
        ----------
        track_num : int
            The track number of the track to replace.
        track : :class:`~pymkv.MKVTrack`
            The :class:`~pymkv.MKVTrack` to be replaced into the file.

        Raises
        ------
        IndexError
            Raised if `track_num` is is out of range of the track list.

        Examples
        --------
        >>> mkv = MKVFile()
        >>> mkv.add_track('t1.mkv')  # doctest: +SKIP
        >>> mkv.replace_track(0, MKVTrack('new.mkv'))  # doctest: +SKIP
        """
        if not 0 <= track_num < len(self.tracks):
            msg = "track index out of range"
            raise IndexError(msg)
        self.tracks[track_num] = track
        self.order_tracks_by_file_id()

    def remove_track(self, track_num: int) -> None:
        """
        Remove a track from the :class:`~pymkv.MKVFile` object.

        Parameters
        ----------
        track_num : int
            The track number of the track to remove.

        Raises
        ------
        IndexError
            Raised if `track_num` is is out of range of the track list.

        Examples
        --------
        >>> mkv = MKVFile()
        >>> mkv.add_track('t1.mkv')  # doctest: +SKIP
        >>> mkv.remove_track(0)  # doctest: +SKIP
        """
        if not 0 <= track_num < len(self.tracks):
            msg = "track index out of range"
            raise IndexError(msg)
        del self.tracks[track_num]
        self.order_tracks_by_file_id()

    def split_none(self) -> None:
        """Remove all splitting options."""
        self._split_options = []

    def split_size(
        self,
        size: bitmath.Bitmath | int,
        link: bool | None = False,
    ) -> None:
        """
        Split the output file into parts by size.

        Parameters
        ----------
        size : :obj:`bitmath`, int
            The size of each split file. Takes either a :obj:`bitmath` size object or an integer representing the
            number of bytes.
        link : bool, optional
            Determines if the split files should be linked together after splitting.

        Raises
        ------
        TypeError
            Raised if if `size` is not a bitmath object or an integer.

        Examples
        --------
        >>> import bitmath
        >>> mkv = MKVFile('input.mkv')  # doctest: +SKIP
        >>> # Split by 100MB
        >>> mkv.split_size(100 * 1024 * 1024)  # doctest: +SKIP
        >>> # Split by bitmath object
        >>> mkv.split_size(bitmath.MiB(50))  # doctest: +SKIP
        """
        if getattr(size, "__module__", None) == bitmath.__name__:
            size = cast("bitmath.Bitmath", size).bytes
        elif not isinstance(size, int):
            msg = "size is not a bitmath object or integer"
            raise TypeError(msg)
        self._split_options = ["--split", f"size:{size}"]
        if link:
            self._split_options.append("--link")

    def split_duration(self, duration: str | int, link: bool | None = False) -> None:
        """
        Split the output file into parts by duration.

        Parameters
        ----------
        duration : str, int
            The duration of each split file. Takes either a str formatted to HH:MM:SS.nnnnnnnnn or an integer
            representing the number of seconds. The duration string requires formatting of at least M:S.
        link : bool, optional
            Determines if the split files should be linked together after splitting.

        Examples
        --------
        >>> mkv = MKVFile('input.mkv')  # doctest: +SKIP
        >>> # Split every 1 minute
        >>> mkv.split_duration('00:01:00')  # doctest: +SKIP
        >>> # Split every 600 seconds
        >>> mkv.split_duration(600)  # doctest: +SKIP
        """
        self._split_options = ["--split", f"duration:{Timestamp(duration)!s}"]
        if link:
            self._split_options.append("--link")

    def split_timestamps(
        self,
        *timestamps: Iterable[str | int],
        link: bool | None = False,
    ) -> None:
        """
        Split the output file into parts by timestamps.

        Parameters
        ----------
        *timestamps : Iterable[str | int]
            The timestamps to split the file by. Can be passed as any combination of strs and ints, inside or outside
            an :obj:`Iterable` object. Any lists will be flattened. Timestamps must be ints, representing seconds,
            or strs in the form HH:MM:SS.nnnnnnnnn. The timestamp string requires formatting of at least M:S.
        link : bool, optional
            Determines if the split files should be linked together after splitting.

        Raises
        ------
        ValueError
            Raised if invalid or improperly formatted timestamps are passed in for `*timestamps`.

        Examples
        --------
        >>> mkv = MKVFile('input.mkv')  # doctest: +SKIP
        >>> # Split at specific timestamps
        >>> mkv.split_timestamps('00:01:00', '00:05:30')  # doctest: +SKIP
        >>> # Split at seconds
        >>> mkv.split_timestamps(60, 330)  # doctest: +SKIP
        """
        # check if in timestamps form
        ts_flat: list[str | int] = MKVFile.flatten(timestamps)
        if not ts_flat:
            msg = f'"{timestamps}" are not properly formatted timestamps'
            raise ValueError(msg)
        if None in ts_flat:
            msg = f'"{timestamps}" are not properly formatted timestamps'
            raise ValueError(msg)
        for ts_1, ts_2 in zip(ts_flat[:-1], ts_flat[1:]):
            if Timestamp(ts_1) >= Timestamp(ts_2):
                msg = f'"{timestamps}" are not properly formatted timestamps'
                raise ValueError(msg)

        # build ts_string from timestamps
        ts_string = "timestamps:"
        for ts in ts_flat:
            ts_string += f"{Timestamp(ts)!s},"
        self._split_options = ["--split", ts_string[:-1]]
        if link:
            self._split_options.append("--link")

    def split_frames(
        self,
        *frames: int | Iterable[int],
        link: bool | None = False,
    ) -> None:
        """
        Split the output file into parts by frames.

        Parameters
        ----------
        *frames : int, list, tuple
            The frames to split the file by. Can be passed as any combination of ints, inside or outside an
            :obj:`Iterable` object. Any lists will be flattened. Frames must be ints.
        link : bool, optional
            Determines if the split files should be linked together after splitting.

        Raises
        ------
        TypeError
            Raised if non-int frames are passed in for `*frames` or within the `*frames` iterable.
        ValueError
            Raised if improperly formatted frames are passed in for `*frames`.

        Examples
        --------
        >>> mkv = MKVFile('input.mkv')  # doctest: +SKIP
        >>> # Split at specific frame numbers
        >>> mkv.split_frames(1000, 5000)  # doctest: +SKIP
        """
        # check if in frames form
        frames_flat: list[int] = MKVFile.flatten(frames)
        if not frames_flat:
            msg = f'"{frames}" are not properly formatted frames'
            raise ValueError(msg)
        for f in frames_flat:
            if not isinstance(f, int):
                msg = f'frame "{f}" not an int'
                raise TypeError(msg)
        for f_1, f_2 in zip(frames_flat[:-1], frames_flat[1:]):
            if f_1 >= f_2:
                msg = f'"{frames}" are not properly formatted frames'
                raise ValueError(msg)

        # build f_string from frames
        f_string = "frames:"
        for f in frames_flat:
            f_string += f"{f!s},"
        self._split_options = ["--split", f_string[:-1]]
        if link:
            self._split_options.append("--link")

    def split_timestamp_parts(
        self,
        timestamp_parts: Iterable[list[str] | tuple[str, ...]],
        link: bool | None = False,
    ) -> None:
        """
        Split the output in parts by time parts.

        Parameters
        ----------
        timestamp_parts : list, tuple
            An Iterable of timestamp sets. Each timestamp set should be an Iterable of an even number of timestamps
            or any number of timestamp pairs. The very first and last timestamps are permitted to be None. Timestamp
            sets containing 4 or more timestamps will output as one file containing the parts specified.
        link : bool, optional
            Determines if the split files should be linked together after splitting.

        Raises
        ------
        TypeError
            Raised if any of the timestamp sets are not a list or tuple.
        ValueError
            Raised if `timestamp_parts` contains improperly formatted parts.
        """
        ts_flat: list[str | int | Timestamp] = MKVFile.flatten(timestamp_parts)
        if not ts_flat:
            msg = f'"{timestamp_parts}" are not properly formatted parts'
            raise ValueError(msg)

        if None in ts_flat[1:-1]:
            msg = f'"{timestamp_parts}" are not properly formatted parts'
            raise ValueError(msg)

        for ts_1, ts_2 in zip(ts_flat[:-1], ts_flat[1:]):
            if None not in (ts_1, ts_2) and Timestamp(ts_1) >= Timestamp(ts_2):
                msg = f'"{timestamp_parts}" are not properly formatted parts'
                raise ValueError(msg)

        ts_string = "parts:"
        for ts_set in timestamp_parts:
            ts_set = MKVFile.flatten(ts_set)  # noqa: PLW2901
            if not isinstance(ts_set, (list, tuple)):
                msg = "set is not of type list or tuple"
                raise TypeError(msg)
            if len(ts_set) < 2 or len(ts_set) % 2 != 0:  # noqa: PLR2004
                msg = f'"{ts_set}" is not a properly formatted set'
                raise ValueError(msg)
            for index, ts in enumerate(ts_set):
                if index % 2 == 0 and index > 0:
                    ts_string += "+"
                if ts is not None:
                    ts_string += str(Timestamp(ts))
                ts_string += "-" if index % 2 == 0 else ","
        self._split_options = ["--split", ts_string[:-1]]
        if link:
            self._split_options.append("--link")

    def split_parts_frames(
        self,
        frame_parts: Iterable[int],
        link: bool | None = False,
    ) -> None:
        """
        Split the output in parts by frames.

        Parameters
        ----------
        frame_parts : list, tuple
            An Iterable of frame sets. Each frame set should be an :obj:`Iterable` object of an even number of frames
            or any
            number of frame pairs. The very first and last frames are permitted to be None. Frame sets containing four
            or more frames will output as one file containing the parts specified.
        link : bool, optional
            Determines if the split files should be linked together after splitting.

        Raises
        ------
        TypeError
            Raised if any of the frame sets are not a list or tuple.
        ValueError
            Raised if `frame_parts` contains improperly formatted parts.
        """
        f_flat: list[int] = MKVFile.flatten(frame_parts)
        if not f_flat:
            msg = f'"{frame_parts}" are not properly formatted parts'
            raise ValueError(msg)
        if None in f_flat[1:-1]:
            msg = f'"{frame_parts}" are not properly formatted parts'
            raise ValueError(msg)
        for f_1, f_2 in zip(f_flat[:-1], f_flat[1:]):
            if None not in (f_1, f_2) and f_1 >= f_2:
                msg = f'"{frame_parts}" are not properly formatted parts'
                raise ValueError(msg)
        f_string = "parts:"
        for fp in frame_parts:
            f_set = MKVFile.flatten(fp)
            if not isinstance(f_set, (list, tuple)):
                msg = "set is not of type list or tuple"
                raise TypeError(msg)
            if len(f_set) < 2 or len(f_set) % 2 != 0:  # noqa: PLR2004
                msg = f'"{f_set}" is not a properly formatted set'
                raise ValueError(msg)
            for index, f in enumerate(f_set):
                if not isinstance(f, int) and f is not None:
                    msg = f'frame "{f}" not an int'
                    raise TypeError(msg)
                if index % 2 == 0 and index > 0:
                    f_string += "+"
                if f is not None:
                    f_string += str(f)
                f_string += "-" if index % 2 == 0 else ","
        self._split_options = ["--split", f_string[:-1]]
        if link:
            self._split_options.append("--link")

    def split_chapters(
        self,
        *chapters: int | Iterable[int],
        link: bool = False,
    ) -> None:
        """
        Split the output file into parts by chapters.

        Parameters
        ----------
        *chapters : int, list, tuple
           The chapters to split the file by. Can be passed as any combination of ints, inside or outside an
           :obj:`Iterable` object. Any lists will be flattened. Chapters must be ints.
        link : bool, optional
            Determines if the split files should be linked together after splitting.

        Raises
        ------
        TypeError
            Raised if any chapters in `*chapters` are not of type int.
        ValueError
            Raised if `*chapters` contains improperly formatted chapters.
        """
        c_flat: list[int] = MKVFile.flatten(chapters)
        if not chapters:
            self._split_options = ["--split", "chapters:all"]
            return
        for c in c_flat:
            if not isinstance(c, int):
                msg = f'chapter "{c}" not an int'
                raise TypeError(msg)
            if c < 1:
                msg = f'"{chapters}" are not properly formatted chapters'
                raise ValueError(msg)
        for c_1, c_2 in zip(c_flat[:-1], c_flat[1:]):
            if c_1 >= c_2:
                msg = f'"{chapters}" are not properly formatted chapters'
                raise ValueError(msg)
        c_string = "chapters:"
        for c in c_flat:
            c_string += f"{c!s},"
        self._split_options = ["--split", c_string[:-1]]
        if link:
            self._split_options.append("--link")

    def link_to_previous(self, file_path: str) -> None:
        """
        Link the output file as the predecessor of the `file_path` file.

        Parameters
        ----------
        file_path : str
            Path of the file to be linked to.

        Raises
        ------
        TypeError
            Raised if `file_path` is not of type str.
        ValueError
            Raised if file at `file_path` cannot be verified as an MKV.
        """
        self._link_to_previous_file = checking_file_path(file_path)

    def link_to_next(self, file_path: str) -> None:
        """
        Link the output file as the successor of the `file_path` file.

        Parameters
        ----------
        file_path : str
            Path of the file to be linked to.

        Raises
        ------
        TypeError
            Raised if `file_path` is not of type str.
        ValueError
            Raised if file at `file_path` cannot be verified as an MKV.
        """
        self._link_to_next_file = checking_file_path(file_path)

    def link_to_none(self) -> None:
        """
        Remove all linking to previous and next files.

        This method clears any existing links to previous or next files,
        effectively removing the file linking options for the current MKVFile object.
        """
        self._link_to_previous_file = None
        self._link_to_next_file = None

    def chapters(self, file_path: str, language: str | None = None) -> None:
        """
        Add a chapters file to the :class:`~pymkv.MKVFile` object.

        Parameters
        ----------
        file_path : str
            The chapters file to be added to the :class:`~pymkv.MKVFile` object.
        language : str, optional
            Must be an ISO639-2 language code. Only applied if no existing language information exists in chapters.

        Raises
        ------
        FileNotFoundError
            Raised if the file at `file_path` does not exist.
        TypeError
            Raised if `file_path` is not of type str.
        """
        self._chapters_file = checking_file_path(file_path)
        self.chapter_language = language

    def global_tags(self, file_path: str) -> None:
        """
        Add global tags to the :class:`~pymkv.MKVFile` object.

        Parameters
        ----------
        file_path : str
            The tags file to be added to the :class:`~pymkv.MKVFile` object.

        Raises
        ------
        FileNotFoundError
            Raised if the file at `file_path` does not exist.
        TypeError
            Raised if `file_path` is not of type str.
        """
        self._global_tags_file = checking_file_path(file_path)

    def track_tags(
        self,
        *track_ids: int | list | tuple,
        exclusive: bool | None = False,
    ) -> None:
        """
        Include or exclude tags from specific tracks.

        Parameters
        ----------
        *track_ids : int, list, tuple
            Track ids to have tags included or excluded from.
        exclusive : bool, optional
            Determines if the `track_ids` should have their tags kept or removed. `exclusive` is False by default and
            will remove tags from unspecified tracks.

        Raises
        ------
        IndexError
            Raised if any ids from `*track_ids` is is out of range of the track list.
        TypeError
            Raised if an ids from `*track_ids` are not of type int.
        ValueError
            Raised if `*track_ids` are improperly formatted.
        """
        ids_flat: list[int] = MKVFile.flatten(track_ids)
        if not track_ids:
            msg = f'"{track_ids}" are not properly formatted track ids'
            raise ValueError(msg)
        for tid in ids_flat:
            if not isinstance(tid, int):
                msg = f'track id "{tid}" not an int'
                raise TypeError(msg)
            if tid < 0 or tid >= len(self.tracks):
                msg = "track id out of range"
                raise IndexError(msg)
        for tid in ids_flat if exclusive else list(set(range(len(self.tracks))) - set(ids_flat)):
            self.tracks[tid].no_track_tags = True

    def no_chapters(self) -> None:
        """
        Ignore the existing chapters of all tracks in the :class:`~pymkv.MKVFile` object.

        This method sets the `no_chapters` attribute to True for all tracks in the MKVFile.
        """
        for track in self.tracks:
            track.no_chapters = True

    def no_global_tags(self) -> None:
        """
        Ignore the existing global tags of all tracks in the :class:`~pymkv.MKVFile` object.

        This method sets the `no_global_tags` attribute to True for all tracks in the MKVFile.
        """
        for track in self.tracks:
            track.no_global_tags = True

    def no_track_tags(self) -> None:
        """
        Ignore the existing track tags of all tracks in the :class:`~pymkv.MKVFile` object.

        This method sets the `no_track_tags` attribute to True for all tracks in the MKVFile.
        """
        for track in self.tracks:
            track.no_track_tags = True

    def no_attachments(self) -> None:
        """
        Ignore the existing attachments of all tracks in the :class:`~pymkv.MKVFile` object.

        This method sets the `no_attachments` attribute to True for all tracks in the MKVFile.
        """
        for track in self.tracks:
            track.no_attachments = True

    @staticmethod
    def flatten(item: Any) -> list[Any]:  # noqa: ANN401
        """
        Flatten a list or a tuple.

        Takes a list or a tuple that contains other lists or tuples and flattens into a non-nested list.

        Examples
        --------
        >>> tup = ((1, 2), (3, (4, 5)))
        >>> MKVFile.flatten(tup)
        [1, 2, 3, 4, 5]

        >>> tup = (["abc", "d"])
        >>> MKVFile.flatten(tup)
        ['abc', 'd']

        Parameters
        ----------
        item : list, tuple
            A list or a tuple object with nested lists or tuples to be flattened.

        Returns
        -------
        list
            A flattened version of `item`.
        """

        def _flatten(item: Any) -> Iterable[Any]:  # noqa: ANN401
            if isinstance(item, Sequence) and not isinstance(item, str):
                for subitem in item:
                    yield from _flatten(subitem)
            else:
                yield item

        return list(_flatten(item))

    def order_tracks_by_file_id(self) -> None:
        """
        Assigns file IDs to tracks based on their source files.

        Creates a mapping of unique file paths to numeric IDs,
        then assigns each track a file ID corresponding to its source file.
        Tracks from the same file will have the same file ID.

        This method modifies the file_id attribute of each track in self.tracks.
        """
        unique_file_dict: dict[str, int] = {}
        try:
            for track in self.tracks:
                if track.file_path not in unique_file_dict:
                    unique_file_dict[track.file_path] = len(unique_file_dict)

            for track in self.tracks:
                track.file_id = unique_file_dict[track.file_path]
        except KeyError as e:
            raise ValueError from e

    def get_attachment(self, attachment_num: int | None = None) -> MKVAttachment | list[MKVAttachment]:
        """
        Get an :class:`~pymkv.MKVAttachment` from the :class:`~pymkv.MKVFile` object.

        Parameters
        ----------
        attachment_num : int, optional
            Index of attachment to retrieve. Will return a list of :class:`~pymkv.MKVAttachment` objects if argument is
            not provided.

        Returns
        -------
        :class:`~pymkv.MKVAttachment`, list of :class:`~pymkv.MKVAttachment`
            A list of all :class:`~pymkv.MKVAttachment` objects in a :class:`~pymkv.MKVFile`. Returns a specific
            :class:`~pymkv.MKVAttachment` if `attachment_num` is specified.
        """
        return self.attachments if attachment_num is None else self.attachments[attachment_num]

    def remove_attachment(self, attachment_num: int) -> None:
        """
        Remove an attachment from the :class:`~pymkv.MKVFile` object.

        Parameters
        ----------
        attachment_num : int
            The attachment number of the attachment to remove.

        Raises
        ------
        IndexError
            Raised if `attachment_num` is out of range of the attachment list.
        """
        if not 0 <= attachment_num < len(self.attachments):
            msg = "attachment index out of range"
            raise IndexError(msg)
        del self.attachments[attachment_num]

    def remove_all_attachments(self) -> None:
        """
        Remove all attachments from the :class:`~pymkv.MKVFile` object.

        This will clear the attachment list, effectively removing all attachments
        that would otherwise be included in the output file.
        """
        self.attachments = []
