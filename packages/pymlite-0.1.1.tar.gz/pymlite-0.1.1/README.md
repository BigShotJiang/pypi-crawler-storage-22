# PyMLite

Lightweight Machine Learning library for Python 3.13

## Features

- Easy-to-use Linear Regression implementation from scratch
- Preprocessing utilities like MinMax Scaler and automatic transformation
- Evaluation metrics: RMSE, R² Score
- Simple ML pipeline to chain preprocessing and models
- Fully compatible with Python 3.13
- Only dependency: NumPy

## Installation

```bash
pip install PyMLite
