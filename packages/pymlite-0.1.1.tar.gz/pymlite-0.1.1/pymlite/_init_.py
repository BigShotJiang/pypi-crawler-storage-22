"""
PyMLite - Lightweight Machine Learning Library for Python 3.13
Author: Pushkar Kaushalendra Sharma
Version: 0.1.0
"""

from .preprocessing import auto_transform, Scaler
from .models import LinearRegression
from .metrics import rmse, r2_score
from .pipeline import Pipeline

__all__ = [
    "auto_transform",
    "Scaler",
    "LinearRegression",
    "rmse",
    "r2_score",
    "Pipeline",
]

__version__ = "0.1.0"
