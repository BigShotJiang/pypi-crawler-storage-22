"""
Machine Learning Models for PyMLite
Lightweight implementation using only NumPy
"""

import numpy as np
from typing import Optional

class LinearRegression:
    """
    Simple Linear Regression from scratch
    Compatible with Python 3.13
    """
    def __init__(self, lr: float = 0.01, epochs: int = 1000):
        self.lr: float = lr
        self.epochs: int = epochs
        self.weights: Optional[np.ndarray] = None
        self.bias: float = 0.0

    def fit(self, X: np.ndarray, y: np.ndarray):
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)
        self.bias = 0.0

        for _ in range(self.epochs):
            y_pred = X @ self.weights + self.bias
            dw = (1/n_samples) * (X.T @ (y_pred - y))
            db = (1/n_samples) * np.sum(y_pred - y)
            self.weights -= self.lr * dw
            self.bias -= self.lr * db

    def predict(self, X: np.ndarray) -> np.ndarray:
        return X @ self.weights + self.bias
