"""
Pipeline utility for PyMLite
Allows chaining preprocessing and models
"""

from typing import List, Any
import numpy as np

class Pipeline:
    """
    Simple ML pipeline supporting multiple steps
    Each step can be a preprocessing object or a ML model
    """

    def __init__(self, steps: List[Any]):
        self.steps: List[Any] = steps

    def fit(self, X: np.ndarray, y: np.ndarray):
        data = X
        # Fit preprocessing steps
        for step in self.steps[:-1]:
            if hasattr(step, "fit_transform"):
                data = step.fit_transform(data)
            elif hasattr(step, "fit"):
                step.fit(data, y)
        # Fit the final model
        self.steps[-1].fit(data, y)

    def predict(self, X: np.ndarray) -> np.ndarray:
        data = X
        # Apply preprocessing
        for step in self.steps[:-1]:
            if hasattr(step, "transform"):
                data = step.transform(data)
        return self.steps[-1].predict(data)
