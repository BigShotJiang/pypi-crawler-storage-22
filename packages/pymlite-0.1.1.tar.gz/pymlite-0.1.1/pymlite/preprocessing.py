"""
Preprocessing module for PyMLite
Contains scaling and automatic transformation utilities
"""

import numpy as np
from typing import Any

def auto_transform(X: np.ndarray) -> np.ndarray:
    """
    Automatically scales numeric columns between 0 and 1
    Compatible with Python 3.13
    """
    X = np.array(X, dtype=float)
    X_min = X.min(axis=0)
    X_max = X.max(axis=0)
    scale = np.where(X_max - X_min != 0, X_max - X_min, 1)
    return (X - X_min) / scale

class Scaler:
    """
    Simple MinMax scaler for numeric data
    Usage:
        scaler = Scaler()
        X_scaled = scaler.fit_transform(X)
    """
    def __init__(self):
        self.min_ = None
        self.scale_ = None

    def fit(self, X: np.ndarray):
        self.min_ = X.min(axis=0)
        self.scale_ = np.where(X.max(axis=0) - self.min_ != 0, X.max(axis=0) - self.min_, 1)

    def transform(self, X: np.ndarray) -> np.ndarray:
        return (X - self.min_) / self.scale_

    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        self.fit(X)
        return self.transform(X)
