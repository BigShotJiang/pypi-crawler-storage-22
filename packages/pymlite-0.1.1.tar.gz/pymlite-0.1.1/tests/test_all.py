import numpy as np
from pymlite import auto_transform, Scaler, LinearRegression, rmse, Pipeline

# Sample data
X = np.array([[1, 2], [2, 3], [4, 5], [3, 4]])
y = np.array([3, 5, 9, 7])

# Test auto_transform
X_scaled = auto_transform(X)
print("Scaled X:\n", X_scaled)

# Test Linear Regression
model = LinearRegression(lr=0.01, epochs=500)
model.fit(X_scaled, y)
y_pred = model.predict(X_scaled)
print("RMSE:", rmse(y, y_pred))

# Test Pipeline
pipe = Pipeline([
    Scaler(),
    LinearRegression(lr=0.01, epochs=500)
])
pipe.fit(X, y)
y_pred_pipe = pipe.predict(X)
print("Pipeline RMSE:", rmse(y, y_pred_pipe))
