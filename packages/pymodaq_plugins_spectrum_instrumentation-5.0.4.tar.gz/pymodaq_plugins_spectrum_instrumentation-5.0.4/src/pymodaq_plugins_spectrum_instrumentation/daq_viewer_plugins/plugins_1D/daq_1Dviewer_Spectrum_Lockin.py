import numpy as np
from pymodaq.utils.daq_utils import ThreadCommand, getLineInfo
from pymodaq.utils.data import DataFromPlugins, Axis, DataToExport
from pymodaq.control_modules.viewer_utility_classes import DAQ_Viewer_base, comon_parameters, main
from pymodaq.utils.parameter import Parameter
import os
import sys


from pymodaq_plugins_spectrum_instrumentation.daq_viewer_plugins.plugins_1D.daq_1Dviewer_Spectrum import DAQ_1DViewer_Spectrum
from pymodaq_plugins_spectrum_instrumentation.hardware.SpectrumCard_wrapper_Single import Spectrum_Wrapper_Single


class DAQ_1DViewer_Spectrum_Lockin(DAQ_1DViewer_Spectrum):
    """ Instrument plugin class for a 1D viewer.

    Attributes:
    -----------
    controller: object
        The particular object that allow the communication with the hardware, in general a python wrapper around the
         hardware library.

        """

    params = DAQ_1DViewer_Spectrum.params + [

        {'title': 'Lock-in', 'name': 'lock_in', 'type': 'group', 'children': [
            {'title': 'Difference channel', 'name': 'diffChannel', 'type':'list', 'limits': ["CH0", "CH1", "CH2", "CH3", "CH4"], "value":"CH2" },
            {'title': 'Intensity channel:', 'name': 'sumChannel',  'type':'list', 'limits': ["CH0", "CH1", "CH2", "CH3", "CH4"], "value":"CH4" },
            {'title': 'Lock In freq.:', 'name': 'LI_PulseFreq', 'type': 'int', 'value': 500, 'default': 500, 'suffix':'Hz'},
            {'title': 'Subtract background', 'name': 'BG_sub', 'type': 'bool', 'value': True, 'default': True},
            {'title': 'Background Proportion', 'name': 'BG_prop', 'type': 'slide', 'value': 70, 'default': 70, 'min': 0, 'max': 100, 'subtype': 'linear', 'suffix':'%'},
            {'title': 'PD gain: (read only) ', 'name': 'Gain', 'type': 'float', 'value': 10, 'default': 10, 'readonly': True},
            {'title': 'Conversion factor: (read only) ', 'name': 'Conversion', 'type': 'float', 'value': 2, 'default': 2, 'readonly': True},

            {'title': 'Plotting & Saving', 'name': 'PlotSave', 'type': 'group', 'children': [
                {'title': 'Show trace', 'name': 'Trace', 'type': 'led_push', 'value': True, 'default': True},
                {'title': 'Pulse train', 'name': 'PulseTrain', 'type': 'led_push', 'value': False, 'default': False},
                {'title': 'Pulse average', 'name': 'PulseAverage', 'type': 'led_push', 'value': False, 'default': False},
                {'title': 'I_Bd', 'name': 'I_Bd', 'type': 'led_push', 'value': False, 'default': False},
                {'title': 'I_Ba', 'name': 'I_Ba', 'type': 'led_push', 'value': False, 'default': False},
                {'title': 'D_Bd', 'name': 'D_Bd', 'type': 'led_push', 'value': False, 'default': False},
                {'title': 'D_Ba', 'name': 'D_Ba', 'type': 'led_push', 'value': False, 'default': False},
                {'title': 'ND_Bd', 'name': 'ND_Bd', 'type': 'led_push', 'value': True, 'default': True},
                {'title': 'ND_Ba', 'name': 'ND_Ba', 'type': 'led_push', 'value': False, 'default': False},
                {'title': 'phi_Bd', 'name': 'phi_Bd', 'type': 'led_push', 'value': False, 'default': False},
                {'title': 'phi_Ba', 'name': 'phi_Ba', 'type': 'led_push', 'value': False, 'default': False},
                {'title': 'phi_Pd', 'name': 'phi_Pd', 'type': 'led_push', 'value': False, 'default': False},
                {'title': 'phi_Pa', 'name': 'phi_Pa', 'type': 'led_push', 'value': False, 'default': False},
                {'title': 'Show & save STD', 'name': 'STD', 'type': 'bool', 'value': False, 'default': False}
                ], 'expanded': False}]
        },
    ]


    def __init__(self, parent=None, params_state=None):
        super().__init__(parent, params_state)

        # --- Calculate some Lock In Parameters
        self.LI_pulseFreq = self.settings.child('lock_in', 'LI_PulseFreq').value()*2 *1e-3   # kHz
        self.num_pulses = self.settings.child('timing', 'Num_Pulses').value()
        self.num_LI_period = int( self.settings.child('timing', 'Range').value() * self.LI_pulseFreq)          # LI = Lock In, LI_Period = Up or Down
        self.points_per_pulse = self.settings.child('timing', 'Sample_per_Pulse').value() # Points per pulse
        self.pulse_per_LI_Period = int(self.num_pulses/self.num_LI_period) # Pulses per Period

        chan_str = [param.title() for param in self.settings.child("channels").children() if param.type()=="led_push" and param.value()]
        self.settings.child('lock_in', 'diffChannel').setLimits( chan_str )
        self.settings.child('lock_in', 'sumChannel').setLimits( chan_str )

        print("\n--- Lock In Info")
        print(f"Number of Pulses = {self.num_pulses}")
        print(f"Number of LI periods = {self.num_LI_period}") 
        print(f"Points per pulse = {self.points_per_pulse}")
        print(f"Pulse Per LI Period = {self.pulse_per_LI_Period}")


    def commit_settings(self, param):
        super().commit_settings(param)

        if param.name()=="BG_sub":
            if param.value(): self.settings.child("lock_in", "BG_prop").show()
            else: self.settings.child("lock_in", "BG_prop").hide()
    


    def grab_data(self, Naverage=1, **kwargs):
        """ Start a grab from the detector
        """

        # --- Grab a Trace
        post_trig =  (1-self.settings.child("trig_params", "preTrig").value()/100) * self.settings.child("timing", "Range").value() / self.settings.child("timing", "Num_Pulses").value()
        try:  data_tot = self.controller.grab_trace( post_trig_ms = post_trig )
        except Exception as e:
            print("Capture Failed !")
            print(e)
            self.emit_status(ThreadCommand('Update_Status', ['Card asked while running ']))
            self.hit_except = True


        # --- Seperate sum and diff
        ii = self.controller.activated_str.index( self.settings.child('lock_in', 'diffChannel').value() )
        index = len(self.controller.activated_str[:ii])
        diff_data = data_tot[index]

        ii = self.controller.activated_str.index( self.settings.child('lock_in', 'sumChannel').value() )
        index = len(self.controller.activated_str[:ii])
        sum_data = data_tot[index]

        # --- Lock In Process
        try: sum_data_int, I_a, I_Ba, I_Bd, diff_data_int, D_a, D_Ba, D_Bd, ND_a, ND_Ba, ND_Bd, phi_a, phi_Ba, phi_Bd = self.lock_in(diff_data, sum_data)
        except Exception as e:
            print(" - Problem during lockin Process")
            print(e)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)

            self.emit_status(ThreadCommand('Update_Status', [ 'Problem During the LockIn Process ! ! ']))
            self.hit_except = True
            

        # --- Create Pymodaq export
        self.x_axis = Axis(data=self.controller.get_the_x_axis(), label='Time', units="s", index=0)

        # Integrated Trace, only one to always export
        dwa_int = DataFromPlugins(name='Pulse train', data=[diff_data_int, sum_data_int], dim='Data1D', labels=['D', 'I'], do_plot=self.settings.child('lock_in', 'PlotSave', 'PulseTrain').value())
        data_to_export = [dwa_int]

        # Also deal with Trace separately as it is 1D
        if self.settings.child('lock_in', 'PlotSave', 'Trace').value():
            # dwa_trace = DataFromPlugins(name='Trace', data=data_tot, dim='Data1D', labels=self.controller.activated_str, axes=[self.x_axis])
            # data_to_export.append(dwa_trace)

            # Add visualisation
            data_trace = np.sign( np.sin( self.settings.child('lock_in', 'LI_PulseFreq').value() * self.x_axis.get_data()) ) * np.max( np.abs(data_tot) )
            dwa_trace = DataFromPlugins(name='Trace', data=data_tot + [data_trace], dim='Data1D', labels=self.controller.activated_str+ ["Lock In Trace"], axes=[self.x_axis])
            data_to_export.append(dwa_trace)

        # Iterate through the calculated data "I_Ba"n "I_Bd"...
        export = {'I_Bd':I_Bd, 'I_Ba':I_Ba, 'D_Bd':D_Bd, 'D_Ba':D_Ba, 'ND_Bd':ND_Bd, 'ND_Ba':ND_Ba, 'phi_Bd':phi_Bd, 'phi_Ba':phi_Ba }
        types = [ param.name() for param in self.settings.child('lock_in', 'PlotSave').children() if (param.value() and param.type()=="led_push" and param.name()!="Pulse train" and param.name()!="Trace") ]
        for type in types:
            dwa = DataFromPlugins(name=type, data=export[type], dim='Data0D', labels=[type])
            data_to_export.append(dwa)

        data = DataToExport('SPLockIn', data=data_to_export)
        self.dte_signal.emit(data)




    def lock_in(self, diff_data, sum_data):
        """
        From 2 traces, calculate all relevant values
        """


        # --- Reshape to correct size (TODO: way of avoiding ? Or just expected that num sample != actual num samples )
        diff_data = diff_data[: int(self.num_pulses*self.points_per_pulse) ]
        sum_data = sum_data[: int(self.num_pulses*self.points_per_pulse) ]

        # --- Integrate Pulses and remove Background
        diff_chan_reshaped = diff_data.reshape(self.num_pulses, self.points_per_pulse)
        sum_chan_reshaped = sum_data.reshape(self.num_pulses, self.points_per_pulse)

        if self.settings.child('lock_in', 'BG_sub').value() == True:    # TODO : Make background subtraction more smart
            cutoff = int(self.points_per_pulse * self.settings.child("lock_in", "BG_prop").value()/100)
            diff_data_int = np.sum( diff_chan_reshaped[:,:cutoff], axis=1 ) * (1-self.settings.child('lock_in', 'BG_sub').value()/100) - np.sum(diff_chan_reshaped[:,cutoff:], axis=1) * self.settings.child('lock_in', 'BG_sub').value()/100
            sum_data_int = np.sum( sum_chan_reshaped[:,:cutoff], axis=1 ) * (1-self.settings.child('lock_in', 'BG_sub').value()/100) - np.sum(sum_chan_reshaped[:,cutoff:], axis=1) * self.settings.child('lock_in', 'BG_sub').value()/100



        else:
            diff_data_int = np.sum(diff_chan_reshaped, axis=1)
            sum_data_int = np.sum(sum_chan_reshaped, axis=1)

        # - Compute I_a and D_a

        D_a = np.mean(diff_data_int)
        I_a = np.mean(sum_data_int)


        # - Compute I_Ba and I_Bd
        sum_data_int_reshaped = sum_data_int.reshape(self.num_LI_period, self.pulse_per_LI_Period)
        mean_sum_over_B_pulse = np.mean(sum_data_int_reshaped, axis=1)           # TODO : Don't really get what is happening here
        # Reduce if you cannot divide by 2
        if len(mean_sum_over_B_pulse)%2 !=0 : mean_sum_over_B_pulse = mean_sum_over_B_pulse[:-1]
        I_Bd =   mean_sum_over_B_pulse [::2] - mean_sum_over_B_pulse [1::2]
        I_Bd = np.mean(I_Bd)
        I_Ba = np.mean(mean_sum_over_B_pulse)


        # - Compute D_Ba and D_Bd
        diff_data_int_reshaped = diff_data_int.reshape(self.num_LI_period, self.pulse_per_LI_Period)
        mean_diff_over_B_pulse = np.mean(diff_data_int_reshaped, axis=1)
        # Reduce if you cannot divide by 2
        if len(mean_diff_over_B_pulse)%2 !=0 : mean_diff_over_B_pulse = mean_diff_over_B_pulse[:-1]
        D_Bd =   mean_diff_over_B_pulse [::2] - mean_diff_over_B_pulse [1::2]
        D_Bd = np.mean(D_Bd)
        D_Ba = np.mean(mean_diff_over_B_pulse)


        # - Compute ND_Ba and ND_Bd
        ND_int = np.divide(diff_data_int, sum_data_int) / self.settings.child('lock_in', 'Gain').value() / 2
        ND_a = np.mean(ND_int)

        ND_reshaped = ND_int.reshape(self.num_LI_period, self.pulse_per_LI_Period)
        mean_ND_over_B_pulse = np.mean(ND_reshaped, axis=1)
        # Reduce if you cannot divide by 2
        if len(mean_ND_over_B_pulse)%2 !=0 : mean_ND_over_B_pulse = mean_ND_over_B_pulse[:-1]
        ND_Bd = mean_ND_over_B_pulse[::2] - mean_ND_over_B_pulse[1::2]
        ND_Bd = np.mean(ND_Bd)
        ND_Ba = np.mean(mean_ND_over_B_pulse)

        # - Computing phi_Ba and phi_Bd
        phi_a = ND_a / self.settings.child('lock_in', 'Conversion').value()
        phi_Ba = ND_Ba / self.settings.child('lock_in', 'Conversion').value()
        phi_Bd = ND_Bd / self.settings.child('lock_in', 'Conversion').value()

        return sum_data_int, I_a, I_Ba, I_Bd, diff_data_int, D_a, D_Ba, D_Bd, ND_a, ND_Ba, ND_Bd, phi_a, phi_Ba, phi_Bd






if __name__ == "__main__":
    main(__file__)