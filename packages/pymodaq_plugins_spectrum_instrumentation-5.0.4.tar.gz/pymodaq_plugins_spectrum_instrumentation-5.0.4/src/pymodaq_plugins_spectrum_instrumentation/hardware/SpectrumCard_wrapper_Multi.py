# -*- coding: utf-8 -*-
"""
Created on Tue Jun  4 11:46:01 2024

@author: dqml-lab
"""

import spcm
from spcm import units  # spcm uses the pint library for unit handling (units is a UnitRegistry object)
from spcm.classes_unit_conversion import UnitConversion
import sys
import numpy as np

from pymodaq_plugins_spectrum_instrumentation.hardware.SpectrumCard_wrapper_Single import Spectrum_Wrapper_Single



class Spectrum_Wrapper_Multi(Spectrum_Wrapper_Single):
    

    def initialise_device(self, clock_mode : str = "external reference", clock_frequency : float = 80, channels_to_activate : list[bool] = [0,0,1,0,1,0,0,0], channel_amplitude : int = 5000, channel_offset : int = 0, trigger_settings : dict = {"trigger_type":"None", "trigger_channel":"CH0", "trigger_mode":"Rising edge", "trigger_level":5000}) -> bool:
        """
        Initializes the spectrum device in Single Mode
        Input :
            - clock_mode : str ["internal PLL", "external reference", "external"]
            - clock_frequency : float [MHz]
            - channels_to_activate : list[bool] list of lenght 8 of 0 and 1 depending on the channels to activate
            - channel_amplitude : int [mV]
            - channel_offset : int [mV]
            - trigger_settings : dict with : {"trigger_type", "trigger_channel", "trigger_mode", "trigger_level"}. 
                - trigger_type = 'None', 'Software trigger', 'External analog trigger'
                - trigger_channel = 'CH0', 'CH1' ...
                - trigger_mode = 'Rising Edge', 'Falling Edge', 'Both'
                - trigger_level [mV]
        """

        
        # --- Determine Some Properties
        Num_Samples = int( (self.duration*1e-3) * (self.sample_rate*1e6) )                 # Total Number of Samples
        print("\n--- Initializing SPCM Card --- Mode : Multi")
        print("Duration = ", round(self.duration,5), "ms")
        print("Number of Samples = ", Num_Samples)
        print("Sampling Frequency = ", round(self.sample_rate,5), "MHz")

        try:

            # --- Choose Mode
            self.card.card_mode(spcm.SPC_REC_STD_MULTI)  # Multi Mode
            self.card.timeout(5 * units.s)  # timeout 50 s

            # --- Setup External Clock
            clock = spcm.Clock(self.card)
            if clock_mode == "internal PLL":
                clock.mode(spcm.SPC_CM_INTPLL)  # clock mode internal PLL

            elif clock_mode == "external reference":
                clock.mode(spcm.SPC_CM_EXTREFCLOCK)  # external reference clock
                clock.reference_clock(clock_frequency * units.MHz)

            else : print("ERROR : Unknown Clock type")
            
            clock.sample_rate(self.sample_rate * units.MHz, return_unit=units.MHz)

            # - DO THIS IN DAQ VIEWER
            # # - Check if Given Parameters Work    
            # if int(Num_B_Pulse) != Num_B_Pulse : print("Duration is not an integer amount of Lock-In Pulses !"); exit()
            # if Num_B_Pulse%2 != 0 : print("Not an even amount ou Lock-In Pulses ! Will not be able to calculate Bd"); exit()

            # --- Activate Channels
            activated_channels = []

            for ii in range( len(channels_to_activate) ):
                if channels_to_activate[ii] == True:
                    self.activated_str.append('CH'+str(ii))
                    match ii:
                        case 0: activated_channels.append(spcm.CHANNEL0)
                        case 1: activated_channels.append(spcm.CHANNEL1)
                        case 2: activated_channels.append(spcm.CHANNEL2)
                        case 3: activated_channels.append(spcm.CHANNEL3)
                        case 4: activated_channels.append(spcm.CHANNEL4)
                        case 5: activated_channels.append(spcm.CHANNEL5)
                        case 6: activated_channels.append(spcm.CHANNEL6)
                        case 7: activated_channels.append(spcm.CHANNEL7)

            # Can only activate certain number of channels ...
            if len(activated_channels) == 1:
                self.channels = spcm.Channels(self.card, card_enable=activated_channels[0])
            elif len(activated_channels) == 2:
                self.channels = spcm.Channels(self.card, card_enable=activated_channels[0] | activated_channels[1])
            elif len(activated_channels) == 3:
                self.channels = spcm.Channels(self.card, card_enable=activated_channels[0] | activated_channels[1] | activated_channels[2] | spcm.CHANNEL7)
            elif len(activated_channels) == 4:
                self.channels = spcm.Channels(self.card, card_enable=activated_channels[0] | activated_channels[1] | activated_channels[2] | activated_channels[3])
            elif len(activated_channels) == 5:
                self.channels = spcm.Channels(self.card, card_enable=activated_channels[0] | activated_channels[1] | activated_channels[2] | activated_channels[3] | activated_channels[4] | activated_channels[5])

            
            # Set Amplitude and Offset
            self.channels.amp(channel_amplitude * units.mV)
            for chan in self.channels:
                chan.offset(channel_offset * units.mV, return_unit=units.mV)
                chan.termination(0)

            # --- Activate Triggering Channel Triggering
            trigger = spcm.Trigger(self.card)

            if trigger_settings["trigger_type"] == 'None':          # trigger set to none
                # trigger.or_mask(spcm.SPC_TMASK_NONE)
                trigger.or_mask(spcm.SPC_TMASK_SOFTWARE)  
            elif trigger_settings["trigger_type"] == 'Software trigger':        # trigger set to software
                trigger.or_mask(spcm.SPC_TMASK_SOFTWARE)  
            elif trigger_settings["trigger_type"] == 'External analog trigger':     # trigger set to external analog
                trigger.or_mask(spcm.SPC_TMASK_EXT0)  
            elif trigger_settings['trigger_type'] == 'Channel trigger':  # trigger set channel
                trigger.or_mask(spcm.SPC_TMASK_NONE)
                if trigger_settings['trigger_channel'] == 'CH0':
                    trigger.ch_or_mask0(spcm.SPC_TMASK0_CH0)
                elif trigger_settings['trigger_channel'] == 'CH1':
                    trigger.ch_or_mask0(spcm.SPC_TMASK0_CH1)
                elif trigger_settings['trigger_channel'] == 'CH2':
                    trigger.ch_or_mask0(spcm.SPC_TMASK0_CH2)
                elif trigger_settings['trigger_channel'] == 'CH3':
                    trigger.ch_or_mask0(spcm.SPC_TMASK0_CH3)
                elif trigger_settings['trigger_channel'] == 'CH4':
                    trigger.ch_or_mask0(spcm.SPC_TMASK0_CH4)
                elif trigger_settings['trigger_channel'] == 'CH5':
                    trigger.ch_or_mask0(spcm.SPC_TMASK0_CH5)
                elif trigger_settings['trigger_channel'] == 'CH6':
                    trigger.ch_or_mask0(spcm.SPC_TMASK0_CH6)
                elif trigger_settings['trigger_channel'] == 'CH7':
                    trigger.ch_or_mask0(spcm.SPC_TMASK0_CH7)
                else: print("ERROR : unknown trigger Channel")
            else : print("ERROR : unknown trigger type")

            trigger.and_mask(spcm.SPC_TMASK_NONE)  # no AND mask

            if trigger_settings['trigger_type'] == 'Channel trigger':
                if trigger_settings['trigger_mode'] == 'Rising edge':
                    trigger.ch_mode(self.channels[0], spcm.SPC_TM_POS)
                elif trigger_settings['trigger_mode'] == 'Falling edge':
                    trigger.ch_mode(self.channels[0], spcm.SPC_TM_NEG)
                elif trigger_settings['trigger_mode'] == 'Both':
                    trigger.ch_mode(self.channels[0], spcm.SPC_TM_BOTH)
                else: print("ERROR : unknown triggering mode")

                trigger.ch_level0(self.channels[0], trigger_settings['trigger_level'] * units.mV, return_unit=units.mV)
            
            elif trigger_settings['trigger_type'] == 'External analog trigger':
                if trigger_settings['trigger_mode'] == 'Rising edge':
                    trigger.ext0_mode(spcm.SPC_TM_POS)
                elif trigger_settings['trigger_mode'] == 'Falling edge':
                    trigger.ext0_mode(spcm.SPC_TM_NEG)
                elif trigger_settings['trigger_mode'] == 'Both':
                    trigger.ext0_mode(spcm.SPC_TM_BOTH)
                else: print("ERROR : unknown triggering mode")

                trigger.ext0_level0(trigger_settings['trigger_level'] * units.mV, return_unit=units.mV)

            # --- Set Up data transfer

            samples_per_segment = Num_Samples
            num_segments = 1
            num_samples = num_segments * samples_per_segment

            print("Samples per Segment = ", samples_per_segment)


            self.data_transfer = spcm.Multi(self.card)
            self.data_transfer.memory_size(num_samples)
            self.data_transfer.allocate_buffer(samples_per_segment, num_segments) 


            post_trigger = self.get_closest_8multiple(int(num_samples * 3/5 ))
            post_trigger = num_samples-8
            self.data_transfer.post_trigger(post_trigger) # Post trigger seems to need to be a multiple of 8, and be bigger than Num_Sample * 3/5

            initialized = True


        except Exception as e:
            import os
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(" -- ERROR IN INITIALIZATION : ")
            print("Error Type : ", e)
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, "in", fname, "at line", exc_tb.tb_lineno)
            print("--")
            
            hit_except = True
            initialized = False

 

        return initialized



    def get_the_x_axis(self):
        return self.data_transfer.time_data().magnitude


    def grab_trace(self, post_trig_ms : float = 0):
        self.card.start(spcm.M2CMD_CARD_ENABLETRIGGER, spcm.M2CMD_CARD_WAITREADY)

        # Start DMA transfer and wait until the data is transferred
        self.data_transfer.start_buffer_transfer(spcm.M2CMD_DATA_STARTDMA, spcm.M2CMD_DATA_WAITDMA)

        data = self.data_transfer.buffer
        all_data = []
        for channel in self.channels:
            segment=0
            all_data.append( np.array(channel.convert_data(data[segment, :, channel], units.V).magnitude) )


        return all_data



    def get_closest_8multiple(self, n:int):
        res = (n//8+1) * 8  # For now just take the next 8 multiple
        return res




def main():
    
    controller = Spectrum_Wrapper_Multi(duration=     10, 
                                        sample_rate=   0.2)

    initialized = controller.initialise_device(clock_mode=             ["internal PLL", "external", "external reference"][0],
                                                    clock_frequency=        80,
                                                    channels_to_activate=   [0,1,1,0],
                                                    channel_amplitude=      5000,
                                                    trigger_settings=       {"trigger_type":        [ "None", "Channel trigger", "Software trigger", "External analog trigger" ][0],
                                                                                "trigger_channel":  ["CH0", "CH1", "CH2", "CH3", "CH4", "CH5", "CH6", "CH7"][0],
                                                                                "trigger_mode":     [ "Rising edge", "Falling edge", "Both"][0],
                                                                                "trigger_level":    100}
                                                    )

    controller.get_device_info(print_info=True)

    data = controller.grab_trace()
    x = controller.get_the_x_axis()*1e3

    import matplotlib.pyplot as plt
    plt.plot(x, data[0])
    plt.plot(x, data[1])
    plt.show()



if __name__=="__main__":
    main()