# Copyright (c) 2022-2025 The pymovements Project Authors
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
"""Provides a definition for the ChineseReading dataset."""
from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field
from dataclasses import KW_ONLY
from typing import Any

from pymovements.dataset.dataset_definition import DatasetDefinition
from pymovements.dataset.resources import ResourceDefinitions


@dataclass
class ChineseReading(DatasetDefinition):
    """ChineseReading dataset :cite:p:`ChineseReading`.

    This dataset includes eye tracking data from more than 300 participants recorded in a single
    session. Precomputed events and word-level reading measures are reported.

    Each participant is instructed to read several sentences.

    Check the respective paper for details :cite:p:`ChineseReading`.

    Attributes
    ----------
    name: str
        The name of the dataset.

    resources: ResourceDefinitions
        A list of dataset gaze_resources. Each list entry must be a dictionary with the following
        keys:
        - `resource`: The url suffix of the resource. This will be concatenated with the mirror.
        - `filename`: The filename under which the file is saved as.
        - `md5`: The MD5 checksum of the respective file.

    filename_format: dict[str, str] | None
        Regular expression, which will be matched before trying to load the file. Namedgroups will
        appear in the `fileinfo` dataframe.

    filename_format_schema_overrides: dict[str, dict[str, type]] | None
        If named groups are present in the `filename_format`, this makes it possible to cast
        specific named groups to a particular datatype.

    trial_columns: list[str] | None
            The name of the trial columns in the input data frame. If the list is empty or None,
            the input data frame is assumed to contain only one trial. If the list is not empty,
            the input data frame is assumed to contain multiple trials, and the transformation
            methods will be applied to each trial separately.

    column_map: dict[str, str] | None
        The keys are the columns to read, the values are the names to which they should be renamed.

    custom_read_kwargs: dict[str, dict[str, Any]] | None
        If specified, these keyword arguments will be passed to the file reading function.
        (default: None)

    Examples
    --------
    Initialize your :py:class:`~pymovements.dataset.Dataset` object with the
    :py:class:`~pymovements.datasets.ChineseReading` definition:

    >>> import pymovements as pm
    >>>
    >>> dataset = pm.Dataset("ChineseReading", path='data/ChineseReading')

    Download the dataset resources:

    >>> dataset.download()# doctest: +SKIP

    Load the data into memory:

    >>> dataset.load()# doctest: +SKIP
    """

    # pylint: disable=similarities
    # The DatasetDefinition child classes potentially share code chunks for definitions.

    name: str = 'ChineseReading'

    _: KW_ONLY  # all fields below can only be passed as a positional argument.

    resources: ResourceDefinitions = field(
        default_factory=lambda: ResourceDefinitions(
            [
                {
                    'content': 'precomputed_events',
                    'url': 'https://files.osf.io/v1/resources/94wue/providers/osfstorage/6253cb37840dd726e75c831a',  # noqa: E501 # pylint: disable=line-too-long
                    'filename': 'Raw Data.txt',
                    'md5': None,  # type: ignore
                    'filename_pattern': 'Raw Data.txt',
                    'load_kwargs': {
                        'trial_columns': ['Subject', 'Sentence_ID'],
                        'read_csv_kwargs': {'separator': '\t'},
                    },
                },
                {
                    'content': 'precomputed_reading_measures',
                    'url': 'https://files.osf.io/v1/resources/94wue/providers/osfstorage/?zip=',
                    'filename': 'chinese_reading_measures.zip',
                    'md5': None,  # type: ignore
                    'filename_pattern': r'{measure_type:s} Measures.xlsx',
                    'load_kwargs': {
                        'read_excel_kwargs': {'sheet_name': 'Sheet 1'},
                    },
                },
            ],
        ),
    )

    filename_format: dict[str, str] | None = None

    filename_format_schema_overrides: dict[str, dict[str, type]] | None = None

    trial_columns: list[str] | None = None

    column_map: dict[str, str] | None = None

    custom_read_kwargs: dict[str, dict[str, Any]] | None = None
