# Request

::: pynetbox.core.query.RequestError
    handler: python
    options:
        members: false

::: pynetbox.core.query.ContentError
    handler: python
    options:
        members: false

::: pynetbox.core.query.AllocationError
    handler: python
    options:
        members: false 