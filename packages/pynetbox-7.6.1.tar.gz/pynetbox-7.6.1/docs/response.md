# Response

::: pynetbox.core.response.Record
    handler: python
    options:
        members:
            - delete
            - full_details
            - save
            - serialize
            - update
            - updates
        show_source: true
        show_root_heading: true

::: pynetbox.core.response.RecordSet
    handler: python
    options:
        members: true
    options:
        members:
            - delete
            - update
        show_source: true
        show_root_heading: true
