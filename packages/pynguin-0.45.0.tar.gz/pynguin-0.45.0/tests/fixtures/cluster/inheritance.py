#  This file is part of Pynguin.
#
#  SPDX-FileCopyrightText: 2019–2026 Pynguin Contributors
#
#  SPDX-License-Identifier: MIT
#
class Foo:
    def foo(self) -> None:
        pass


class Bar(Foo):
    def bar(self) -> None:
        pass
