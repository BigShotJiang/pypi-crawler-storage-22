#  This file is part of Pynguin.
#
#  SPDX-FileCopyrightText: 2019–2026 Pynguin Contributors
#
#  SPDX-License-Identifier: MIT
#


def impossible(x: int, y: int):
    if x > y > x:
        print("Impossible")
