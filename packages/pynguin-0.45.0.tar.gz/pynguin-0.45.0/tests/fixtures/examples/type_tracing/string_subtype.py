#  This file is part of Pynguin.
#
#  SPDX-FileCopyrightText: 2019–2026 Pynguin Contributors
#
#  SPDX-License-Identifier: MIT
def my_str_fun(my_input):
    if my_input.startswith("a") and my_input.endswith("z"):
        return "a*z"
    else:
        return "other"
