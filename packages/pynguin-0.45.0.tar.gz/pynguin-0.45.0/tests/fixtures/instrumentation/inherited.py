#  This file is part of Pynguin.
#
#  SPDX-FileCopyrightText: 2019–2026 Pynguin Contributors
#
#  SPDX-License-Identifier: MIT
#


class SimpleClass:
    def some_method(self):
        pass


def some_function():
    pass
