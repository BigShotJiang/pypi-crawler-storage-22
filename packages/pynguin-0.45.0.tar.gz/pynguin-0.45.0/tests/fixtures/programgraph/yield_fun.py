#  This file is part of Pynguin.
#
#  SPDX-FileCopyrightText: 2019–2026 Pynguin Contributors
#
#  SPDX-License-Identifier: MIT
#

def yield_fun():
    y = 0
    while True:
        if y == 0:
            yield y
