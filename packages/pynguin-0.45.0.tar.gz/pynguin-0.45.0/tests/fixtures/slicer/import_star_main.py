#  This file is part of Pynguin.
#
#  SPDX-FileCopyrightText: 2019–2026 Pynguin Contributors
#
#  SPDX-License-Identifier: MIT
#
# Idea and structure are taken from the pyChecco project, see:
# https://github.com/ipsw1/pychecco

from tests.fixtures.slicer.import_star_def import *  # noqa


def func():
    result = star_imported  # noqa
    return result
