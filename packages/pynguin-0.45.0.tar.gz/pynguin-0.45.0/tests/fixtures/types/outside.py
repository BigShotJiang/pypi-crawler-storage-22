#  This file is part of Pynguin.
#
#  SPDX-FileCopyrightText: 2019–2026 Pynguin Contributors
#
#  SPDX-License-Identifier: MIT
#
class Foo:
    pass


class Bar(Foo):
    pass


class Baz(Bar):
    pass
