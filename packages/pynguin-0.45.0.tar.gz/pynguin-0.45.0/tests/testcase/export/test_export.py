#  This file is part of Pynguin.
#
#  SPDX-FileCopyrightText: 2019–2026 Pynguin Contributors
#
#  SPDX-License-Identifier: MIT
#
import ast
import importlib
import tempfile
from pathlib import Path
from unittest import mock

import pytest

import pynguin.configuration as config
import pynguin.ga.generationalgorithmfactory as gaf
import pynguin.ga.testcasechromosome as tcc
import pynguin.generator as gen
from pynguin.analyses.constants import EmptyConstantProvider
from pynguin.analyses.module import generate_test_cluster
from pynguin.analyses.seeding import AstToTestCaseTransformer
from pynguin.instrumentation.machinery import install_import_hook
from pynguin.instrumentation.tracer import SubjectProperties
from pynguin.testcase import export
from pynguin.testcase.execution import TestCaseExecutor
from pynguin.testcase.export import PyTestChromosomeToAstVisitor
from tests.testutils import extract_test_case_0


def test_export_sequence(exportable_test_case, tmp_path):
    path = tmp_path / "generated.py"
    exporter = export.PyTestChromosomeToAstVisitor()
    exportable_test_case.accept(exporter)
    exportable_test_case.accept(exporter)
    export.save_module_to_file(exporter.to_module(), path)
    assert (
        path.read_text()
        == export._PYNGUIN_FILE_HEADER
        + """import pytest
import tests.fixtures.accessibles.accessible as module_0


def test_case_0():
    int_0 = 5
    some_type_0 = module_0.SomeType(int_0)
    assert some_type_0 == 5
    float_0 = 42.23
    float_1 = module_0.simple_function(float_0)
    assert float_1 == pytest.approx(42.23, abs=0.01, rel=0.01)


def test_case_1():
    int_0 = 5
    some_type_0 = module_0.SomeType(int_0)
    assert some_type_0 == 5
    float_0 = 42.23
    float_1 = module_0.simple_function(float_0)
    assert float_1 == pytest.approx(42.23, abs=0.01, rel=0.01)
"""
    )


def test_export_sequence_expected_exception(
    exportable_test_case_with_expected_asserted_exception, tmp_path
):
    """An expected asserted exception is an exception that was raised and is expected.

    It is expected because the SUT code declares that it may raise this exception
    or has an assert statement.
    It is asserted because an assertion for that exception was generated, which leads
    to a ``with pytest.raises(...):`` statement.
    """
    path = tmp_path / "expected_asserted_exception.py"
    exporter = export.PyTestChromosomeToAstVisitor()
    exportable_test_case_with_expected_asserted_exception.accept(exporter)
    export.save_module_to_file(exporter.to_module(), path)
    assert (
        path.read_text()
        == export._PYNGUIN_FILE_HEADER
        + """import pytest
import tests.fixtures.accessibles.accessible as module_0


def test_case_0():
    float_0 = 42.23
    with pytest.raises(ValueError):
        module_0.simple_function(float_0)
"""
    )


def test_export_sequence_unexpected_exception(
    exportable_test_case_with_expected_not_asserted_exception, tmp_path
):
    """An expected not asserted exception is an exception that was raised and is not expected.

    It is expected because the SUT code declares that it may raise this exception
    or has an assert statement.
    No assertion for the exception was generated, thus the exported test case passes.
    """
    path = tmp_path / "expected_not_asserted_exception.py"
    exporter = export.PyTestChromosomeToAstVisitor()
    exportable_test_case_with_expected_not_asserted_exception.accept(exporter)
    export.save_module_to_file(exporter.to_module(), path)
    assert (
        path.read_text()
        == export._PYNGUIN_FILE_HEADER
        + """import tests.fixtures.accessibles.accessible as module_0


def test_case_0():
    float_0 = 42.23
    module_0.simple_function(float_0)
"""
    )


def test_export_lambda(exportable_test_case_with_lambda, tmp_path):
    path = tmp_path / "generated_with_unexpected_exception.py"
    exporter = export.PyTestChromosomeToAstVisitor(store_call_return=True)
    exportable_test_case_with_lambda.accept(exporter)
    export.save_module_to_file(exporter.to_module(), path)
    assert (
        path.read_text()
        == export._PYNGUIN_FILE_HEADER
        + """import tests.conftest as module_0


def test_case_0():
    int_0 = 1
    int_1 = module_0.just_z(int_0)
"""
    )


def test_export_lambda_complex(exportable_test_case_with_lambda_complex, tmp_path):
    path = tmp_path / "generated_with_unexpected_exception.py"
    exporter = export.PyTestChromosomeToAstVisitor(store_call_return=True)
    exportable_test_case_with_lambda_complex.accept(exporter)
    export.save_module_to_file(exporter.to_module(), path)
    assert (
        path.read_text()
        == export._PYNGUIN_FILE_HEADER
        + """import tests.conftest as module_0


def test_case_0():
    complex_0 = 3 + 4j
    complex_1 = 1 + 0j
    float_0 = 0.1
    float_1 = 0.3
    complex_2 = module_0.weighted_avg(complex_0, complex_1, float_0, float_1)
"""
    )


def test_invalid_export(exportable_test_case, tmp_path):
    path = tmp_path / "invalid.py"
    exporter = export.PyTestChromosomeToAstVisitor()
    exportable_test_case.accept(exporter)

    from black.parsing import InvalidInput  # noqa: PLC0415

    with mock.patch("black.format_str", side_effect=InvalidInput("Invalid input")):
        export.save_module_to_file(exporter.to_module(), path)

    assert (
        path.read_text()
        == export._PYNGUIN_FILE_HEADER
        + """import pytest
import tests.fixtures.accessibles.accessible as module_0

def test_case_0():
    int_0 = 5
    some_type_0 = module_0.SomeType(int_0)
    assert some_type_0 == 5
    float_0 = 42.23
    float_1 = module_0.simple_function(float_0)
    assert float_1 == pytest.approx(42.23, abs=0.01, rel=0.01)"""
    )


def _imports_from_module(module: ast.Module) -> list[ast.Import]:
    """Collect plain import statements from a module AST."""
    return [node for node in module.body if isinstance(node, ast.Import)]


@pytest.mark.parametrize(
    ("module_name", "expected_canonical"),
    [
        # Single-file stdlib module
        ("pathlib", "pathlib"),
        # Dotted stdlib submodule that resolves to a file
        ("importlib.util", "importlib.util"),
        # Built-in module falls back to spec.name
        ("builtins", "builtins"),
        # Local package module from this project
        ("src.pynguin.utils.namingscope", "pynguin.utils.namingscope"),
        ("pynguin.utils.namingscope", "pynguin.utils.namingscope"),
        # Non-existent name falls back to the provided name unchanged
        ("_pynguin_this_does_not_exist_", "_pynguin_this_does_not_exist_"),
    ],
)
def test_canonical_module_name(module_name: str, expected_canonical: str) -> None:
    """Test that various module names are canonicalised as expected."""
    visitor = PyTestChromosomeToAstVisitor()

    # Register an alias for the module name to force creation of an import with alias.
    alias_name = visitor.module_aliases.get_name(module_name)

    module_ast = visitor.to_module()

    imports = _imports_from_module(module_ast)

    # Find the import that uses our alias and verify its name is canonicalised.
    matched: list[str] = []
    for imp in imports:
        matched.extend(alias.name for alias in imp.names if alias.asname == alias_name)

    # Exactly one import should match the alias we registered
    assert matched == [expected_canonical]


def test_export_integration(subject_properties: SubjectProperties, tmp_path: Path):
    module_name = "tests.fixtures.examples.unasserted_exceptions"
    config.configuration.module_name = module_name
    config.configuration.algorithm = config.Algorithm.DYNAMOSA
    config.configuration.stopping.maximum_iterations = 20
    config.configuration.search_algorithm.min_initial_tests = 10
    config.configuration.search_algorithm.max_initial_tests = 10
    config.configuration.search_algorithm.population = 20
    config.configuration.test_creation.none_weight = 1
    config.configuration.test_creation.any_weight = 1
    config.configuration.seeding.seed = 1
    config.configuration.test_case_output.output_path = tmp_path
    gen._setup_random_number_generator()

    expected = (
        export._PYNGUIN_FILE_HEADER
        + """import pytest
import tests.fixtures.examples.unasserted_exceptions as module_0


def test_case_0():
    bool_0 = True
    module_0.foo(bool_0)


@pytest.mark.xfail(strict=True)
def test_case_1():
    none_type_0 = None
    module_0.foo(none_type_0)
"""
    )

    with install_import_hook(module_name, subject_properties):
        with subject_properties.instrumentation_tracer:
            module = importlib.import_module(module_name)
            importlib.reload(module)

        executor = TestCaseExecutor(subject_properties)
        cluster = generate_test_cluster(module_name)
        search_algorithm = gaf.TestSuiteGenerationAlgorithmFactory(
            executor, cluster
        ).get_search_algorithm()
        test_cases = search_algorithm.generate_tests()
        assert test_cases.size() >= 0

        target_file = Path(config.configuration.test_case_output.output_path).resolve() / "test.py"
        export_visitor = export.PyTestChromosomeToAstVisitor(store_call_return=False)
        test_cases.accept(export_visitor)
        export.save_module_to_file(
            export_visitor.to_module(),
            target_file,
            format_with_black=config.configuration.test_case_output.format_with_black,
        )
    assert target_file.exists()
    content = target_file.read_text(encoding="utf-8")
    assert expected == content


def _import_execute_export(
    module_name: str, test_case_code: str, *, store_call_return: bool = True
) -> str:
    """Import a test case, execute it and export it again.

    Args:
        module_name: The name of the SUT module.
        test_case_code: The test case code to add assertions for.
        store_call_return: Whether to store the return value of each call.

    Returns:
        The exported test case.
    """
    subject_properties = SubjectProperties()
    config.configuration.module_name = module_name
    test_case_code = "import " + module_name + " as module_0\n\n" + test_case_code

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)

        # Parse seed into DefaultTestCase
        test_cluster = generate_test_cluster(module_name)
        transformer = AstToTestCaseTransformer(
            test_cluster=test_cluster,
            create_assertions=False,  # do not import assertions
            constant_provider=EmptyConstantProvider(),
        )
        transformer.visit(ast.parse(test_case_code))
        assert transformer.testcases, "No test case parsed from seed source"
        test_case_chrom = tcc.TestCaseChromosome(transformer.testcases[0])

        # Instrument and import target module for assertion generation
        with install_import_hook(module_name, subject_properties):
            with subject_properties.instrumentation_tracer:
                module = importlib.import_module(module_name)
                importlib.reload(module)

            # Execute the imported test case
            executor = TestCaseExecutor(subject_properties)
            execution_result = executor.execute(test_case_chrom.test_case)
            test_case_chrom.set_last_execution_result(execution_result)

            # Export the augmented test with assertions
            export_path = tmp_path / "test_with_assertions.py"
            exporter = export.PyTestChromosomeToAstVisitor(store_call_return=store_call_return)
            test_case_chrom.accept(exporter)
            export.save_module_to_file(
                exporter.to_module(),
                export_path,
                format_with_black=config.configuration.test_case_output.format_with_black,
            )

        exported = export_path.read_text(encoding="utf-8")
        return extract_test_case_0(exported)


@pytest.mark.parametrize(
    "module_name,test_case_code,expected_code,store_call_return",
    [
        # Simple example
        (
            "tests.fixtures.accessibles.accessible",
            """def test_case_0():
    int_0 = 5
    some_type_0 = module_0.SomeType(int_0)
    float_0 = 42.23
    float_1 = module_0.simple_function(float_0)""",
            None,
            True,
        ),
        # Don't add @pytest.mark.xfail(strict=True) for a non-failing test
        (
            "tests.fixtures.examples.unasserted_exceptions",
            """def test_case_0():
    bool_0 = True
    bool_1 = module_0.foo(bool_0)""",
            None,
            True,
        ),
        # Remove @pytest.mark.xfail(strict=True) for a non-failing test
        (
            "tests.fixtures.examples.unasserted_exceptions",
            """@pytest.mark.xfail(strict=True)
def test_case_0():
    bool_0 = True
    bool_1 = module_0.foo(bool_0)""",
            """def test_case_0():
    bool_0 = True
    bool_1 = module_0.foo(bool_0)""",
            True,
        ),
        # Keep @pytest.mark.xfail(strict=True) for a failing test
        (
            "tests.fixtures.examples.unasserted_exceptions",
            """@pytest.mark.xfail(strict=True)
def test_case_0():
    none_type_0 = None
    bool_0 = module_0.foo(none_type_0)""",
            None,
            True,
        ),
        # Add @pytest.mark.xfail(strict=True) for a failing test
        (
            "tests.fixtures.examples.unasserted_exceptions",
            """def test_case_0():
    none_type_0 = None
    bool_0 = module_0.foo(none_type_0)""",
            """@pytest.mark.xfail(strict=True)
def test_case_0():
    none_type_0 = None
    bool_0 = module_0.foo(none_type_0)""",
            True,
        ),
        # The same cases with store_call_return=False
        (
            "tests.fixtures.accessibles.accessible",
            """def test_case_0():
    int_0 = 5
    module_0.SomeType(int_0)
    float_0 = 42.23
    module_0.simple_function(float_0)""",
            None,
            False,
        ),
        (
            "tests.fixtures.examples.unasserted_exceptions",
            """def test_case_0():
    bool_0 = True
    module_0.foo(bool_0)""",
            None,
            False,
        ),
        (
            "tests.fixtures.examples.unasserted_exceptions",
            """@pytest.mark.xfail(strict=True)
def test_case_0():
    bool_0 = True
    module_0.foo(bool_0)""",
            """def test_case_0():
    bool_0 = True
    module_0.foo(bool_0)""",
            False,
        ),
        (
            "tests.fixtures.examples.unasserted_exceptions",
            """@pytest.mark.xfail(strict=True)
def test_case_0():
    none_type_0 = None
    module_0.foo(none_type_0)""",
            None,
            False,
        ),
        (
            "tests.fixtures.examples.unasserted_exceptions",
            """def test_case_0():
    none_type_0 = None
    module_0.foo(none_type_0)""",
            """@pytest.mark.xfail(strict=True)
def test_case_0():
    none_type_0 = None
    module_0.foo(none_type_0)""",
            False,
        ),
        (
            "tests.fixtures.examples.unasserted_exceptions",
            """def test_case_0():
    bool_0 = True
    bool_1 = module_0.foo(bool_0)
    module_0.foo(bool_1)""",
            None,
            False,
        ),
    ],
)
def test_import_export_parameterized(
    module_name: str, test_case_code: str, expected_code: str | None, *, store_call_return: bool
) -> None:
    exported = _import_execute_export(
        module_name, test_case_code, store_call_return=store_call_return
    )
    if expected_code is None:
        assert exported == test_case_code
    else:
        assert exported == expected_code
