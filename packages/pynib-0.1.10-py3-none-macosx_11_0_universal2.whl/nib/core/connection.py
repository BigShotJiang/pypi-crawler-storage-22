"""Connection layer for communicating with the Swift runtime.

This module provides the :class:`Connection` class that handles all
communication between Python and the Swift runtime over Unix sockets
using MessagePack serialization.

The communication protocol uses length-prefixed MessagePack messages:

- **Python → Swift messages**: ``render``, ``patch``, ``notify``, ``quit``,
  ``clipboard``, ``fileDialog``, ``userDefaults``
- **Swift → Python messages**: ``event`` (user interactions)

Note:
    This module is for internal use. Applications should use the high-level
    :class:`~nib.App` API instead of interacting with Connection directly.
"""

import queue
import socket
import struct
import threading
from typing import Callable, Optional, Any
import msgpack

from .logging import logger


class Connection:
    """Unix socket connection to the Swift runtime.

    Manages bidirectional communication with the nib-runtime Swift process
    using length-prefixed MessagePack messages over a Unix domain socket.

    Messages are sent with a 4-byte big-endian length prefix followed by
    the MessagePack-encoded payload. Events from Swift are received on
    a background thread and dispatched to a registered handler.

    Attributes:
        socket_path: Path to the Unix domain socket.

    Example:
        Internal usage by App::

            conn = Connection("/tmp/nib-12345.sock")
            if conn.connect():
                conn.set_event_handler(handle_event)
                conn.send_render(root=view_tree)
                # ... later ...
                conn.send_quit()
                conn.disconnect()
    """

    def __init__(self, socket_path: str) -> None:
        """Initialize a new Connection.

        Args:
            socket_path: Path to the Unix domain socket file.
        """
        self.socket_path = socket_path
        self._socket: Optional[socket.socket] = None
        self._connected = False
        self._read_thread: Optional[threading.Thread] = None
        self._event_thread: Optional[threading.Thread] = None
        self._event_queue: queue.Queue = queue.Queue()
        self._on_event: Optional[Callable[[str, str], None]] = None
        self._send_lock = threading.Lock()

    def connect(self, retries: int = 50, initial_delay: float = 0.05) -> bool:
        """Connect to the Swift runtime socket.

        Attempts to connect to the Unix socket with retries using exponential
        backoff. Starts with fast retries and gradually slows down.

        Args:
            retries: Maximum number of connection attempts.
            initial_delay: Initial delay between attempts (grows exponentially).

        Returns:
            True if connection succeeded, False otherwise.
        """
        import time

        delay = initial_delay
        max_delay = 0.5  # Cap at 500ms between retries

        for attempt in range(retries):
            try:
                self._socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                self._socket.connect(self.socket_path)
                self._connected = True
                self._start_read_thread()
                return True
            except (FileNotFoundError, ConnectionRefusedError):
                if attempt < retries - 1:
                    time.sleep(delay)
                    # Exponential backoff: 0.05, 0.075, 0.11, 0.17, 0.25, 0.38, 0.5, 0.5...
                    delay = min(delay * 1.5, max_delay)
                else:
                    return False
        return False

    def disconnect(self) -> None:
        """Disconnect from the Swift runtime.

        Closes the socket connection and stops the read thread.
        Safe to call multiple times.
        """
        self._connected = False
        if self._socket:
            try:
                self._socket.close()
            except Exception:
                pass
            self._socket = None

    def send_render(
        self,
        root: Optional[dict],
        icon: Optional[str] = None,
        title: Optional[str] = None,
        width: Optional[float] = None,
        height: Optional[float] = None,
        menu: Optional[list] = None,
        hotkeys: Optional[list] = None,
        fonts: Optional[dict] = None,
    ) -> None:
        """Send a full render message to the Swift runtime.

        This sends the complete view tree and app configuration to Swift
        for rendering. Used for initial render or when incremental
        patching would be too complex.

        Args:
            root: Serialized view tree dictionary.
            icon: Menu bar icon (SF Symbol name or config dict).
            title: Menu bar title text.
            width: Popover window width in points.
            height: Popover window height in points.
            menu: List of serialized menu item dictionaries.
            hotkeys: List of hotkey strings to register.
            fonts: Dictionary mapping font names to paths/URLs.
        """
        window = {}
        if width is not None:
            window["width"] = float(width)
        if height is not None:
            window["height"] = float(height)

        message = {
            "type": "render",
            "payload": {
                "root": root,
                "statusBar": {"icon": icon, "title": title},
                "window": window if window else None,
                "menu": menu,
                "hotkeys": hotkeys,
                "fonts": fonts,
            },
        }
        self._send(message)

    def send_flat_render(
        self,
        nodes: list[dict],
        root_id: str,
        icon: Optional[str] = None,
        title: Optional[str] = None,
        width: Optional[float] = None,
        height: Optional[float] = None,
        menu: Optional[list] = None,
        hotkeys: Optional[list] = None,
        fonts: Optional[dict] = None,
    ) -> None:
        """Send a flat render message to the Swift runtime.

        Uses flat node list instead of nested tree structure.
        This enables iterative (non-recursive) parsing on Swift side,
        preventing stack overflow with deeply nested views.

        Args:
            nodes: List of flat node dictionaries with parentId references.
            root_id: ID of the root node.
            icon: Menu bar icon (SF Symbol name or config dict).
            title: Menu bar title text.
            width: Popover window width in points.
            height: Popover window height in points.
            menu: List of serialized menu item dictionaries.
            hotkeys: List of hotkey strings to register.
            fonts: Dictionary mapping font names to paths/URLs.
        """
        window = {}
        if width is not None:
            window["width"] = float(width)
        if height is not None:
            window["height"] = float(height)

        message = {
            "type": "flatRender",
            "payload": {
                "nodes": nodes,
                "rootId": root_id,
                "statusBar": {"icon": icon, "title": title},
                "window": window if window else None,
                "menu": menu,
                "hotkeys": hotkeys,
                "fonts": fonts,
            },
        }
        self._send(message)

    def send_patch(
        self,
        patches: list,
        icon: Optional[str] = None,
        title: Optional[str] = None,
        width: Optional[float] = None,
        height: Optional[float] = None,
    ) -> None:
        """Send incremental patches to the Swift runtime.

        Instead of re-rendering the entire view tree, this sends only
        the changes (patches) needed to update the UI.

        Note:
            Currently disabled in favor of full renders due to Swift-side
            handling issues.

        Args:
            patches: List of patch operations from :func:`diff_trees`.
            icon: Menu bar icon (SF Symbol name or config dict).
            title: Menu bar title text.
            width: Popover window width in points.
            height: Popover window height in points.
        """
        window = {}
        if width is not None:
            window["width"] = float(width)
        if height is not None:
            window["height"] = float(height)

        message = {
            "type": "patch",
            "payload": {
                "patches": patches,
                "statusBar": {"icon": icon, "title": title},
                "window": window if window else None,
            },
        }
        self._send(message)

    def send_quit(self) -> None:
        """Send a quit message to terminate the Swift runtime."""
        self._send({"type": "quit"})

    def send_notify(
        self,
        title: str,
        body: Optional[str] = None,
        subtitle: Optional[str] = None,
        sound: bool = True,
        identifier: Optional[str] = None,
    ) -> None:
        """Send a macOS notification through the Swift runtime.

        Args:
            title: The notification title (required).
            body: The notification body text.
            subtitle: A subtitle shown below the title.
            sound: Whether to play the default notification sound.
            identifier: Unique ID for updating/removing the notification.
        """
        message = {
            "type": "notify",
            "payload": {
                "title": title,
                "body": body,
                "subtitle": subtitle,
                "sound": sound,
                "identifier": identifier,
            },
        }
        self._send(message)

    def send_clipboard_write(self, content: str) -> None:
        """Write content to the system clipboard.

        Args:
            content: The text to copy to the clipboard.
        """
        message = {
            "type": "clipboard",
            "payload": {
                "action": "write",
                "content": content,
            },
        }
        self._send(message)

    def send_clipboard_read(self, request_id: str) -> None:
        """Request clipboard content asynchronously.

        The clipboard content will be returned via an event callback
        with the format ``clipboard:<content>``.

        Args:
            request_id: Unique ID to match the response callback.
        """
        message = {
            "type": "clipboard",
            "payload": {
                "action": "read",
                "requestId": request_id,
            },
        }
        self._send(message)

    def send_file_dialog(
        self,
        action: str,
        request_id: str,
        title: Optional[str] = None,
        message: Optional[str] = None,
        button_label: Optional[str] = None,
        directory: Optional[str] = None,
        shows_hidden_files: bool = False,
        resolves_aliases: bool = True,
        multiple: bool = False,
        extensions: Optional[list] = None,
        uttypes: Optional[list] = None,
        allows_other_file_types: bool = False,
        treats_packages_as_directories: bool = False,
        can_create_directories: bool = True,
        filename: Optional[str] = None,
        name_field_label: Optional[str] = None,
        shows_tag_field: bool = True,
    ) -> None:
        """Show a file picker or save dialog.

        The response will be sent as a fileDialogResponse message.

        Args:
            action: "pickFiles", "pickDirectory", or "saveFile".
            request_id: Unique ID to match the response.
            title: Dialog window title.
            message: Prompt text below the title.
            button_label: Text for the OK/Save button.
            directory: Starting directory path.
            shows_hidden_files: Show hidden files.
            resolves_aliases: Follow alias files to targets.
            multiple: Allow selecting multiple items.
            extensions: Allowed file extensions (e.g., ["txt", "md"]).
            uttypes: Allowed UTIs (e.g., ["public.image"]).
            allows_other_file_types: Allow files outside allowed types.
            treats_packages_as_directories: Treat .app as folders.
            can_create_directories: Allow creating new folders.
            filename: Suggested filename (save only).
            name_field_label: Label for filename field (save only).
            shows_tag_field: Show Finder tags selector (save only).
        """
        payload = {
            "action": action,
            "requestId": request_id,
        }
        if title is not None:
            payload["title"] = title
        if message is not None:
            payload["message"] = message
        if button_label is not None:
            payload["buttonLabel"] = button_label
        if directory is not None:
            payload["directory"] = directory
        if shows_hidden_files:
            payload["showsHiddenFiles"] = shows_hidden_files
        if not resolves_aliases:
            payload["resolvesAliases"] = resolves_aliases
        if multiple:
            payload["multiple"] = multiple
        if extensions:
            payload["extensions"] = extensions
        if uttypes:
            payload["uttypes"] = uttypes
        if allows_other_file_types:
            payload["allowsOtherFileTypes"] = allows_other_file_types
        if treats_packages_as_directories:
            payload["treatsPackagesAsDirectories"] = treats_packages_as_directories
        if not can_create_directories:
            payload["canCreateDirectories"] = can_create_directories
        if filename is not None:
            payload["filename"] = filename
        if name_field_label is not None:
            payload["nameFieldLabel"] = name_field_label
        if not shows_tag_field:
            payload["showsTagField"] = shows_tag_field

        msg = {
            "type": "fileDialog",
            "payload": payload,
        }
        self._send(msg)

    def send_user_defaults(
        self,
        action: str,
        key: Optional[str] = None,
        value: Any = None,
        prefix: Optional[str] = None,
        request_id: Optional[str] = None,
    ) -> None:
        """Send a UserDefaults operation to the Swift runtime.

        Args:
            action: Operation type - "set", "get", "remove", "clear",
                "containsKey", or "getKeys".
            key: The key for get/set/remove/containsKey operations.
            value: The value to store (set operation only).
            prefix: Key prefix filter (getKeys operation only).
            request_id: Unique ID for async response matching.
        """
        import json
        # Encode value as JSON string to avoid MessagePack/Swift Codable issues
        value_json = None
        if value is not None:
            value_json = json.dumps(value)

        message = {
            "type": "userDefaults",
            "payload": {
                "action": action,
                "key": key,
                "valueJson": value_json,  # JSON-encoded string (preferred)
                "prefix": prefix,
                "requestId": request_id,
            },
        }
        self._send(message)

    def send_service_query(
        self,
        service: str,
        action: str,
        request_id: str,
        params: Optional[dict] = None,
    ) -> None:
        """Query a system service.

        Args:
            service: Service name ("battery", "connectivity", "screen").
            action: Action to perform (e.g., "status", "info", "setBrightness").
            request_id: Unique ID to match the response callback.
            params: Optional parameters for the action.
        """
        message = {
            "type": "service",
            "payload": {
                "service": service,
                "action": action,
                "requestId": request_id,
            },
        }
        if params:
            message["payload"]["params"] = params
        self._send(message)

    def send_action(
        self,
        node_id: str,
        action: str,
        params: Optional[dict] = None,
    ) -> None:
        """Send an action to a specific view node.

        Used for triggering actions on views like WebView (reload, goBack, etc.).

        Args:
            node_id: The ID of the target view node.
            action: The action to perform (e.g., "reload", "goBack", "goForward").
            params: Optional parameters for the action.
        """
        message = {
            "type": "action",
            "payload": {
                "nodeId": node_id,
                "action": action,
            },
        }
        if params:
            message["payload"]["params"] = params
        self._send(message)

    def send_settings_render(self, settings_config: dict) -> None:
        """Send settings page configuration to the Swift runtime.

        This creates or updates the settings window with the specified
        tabs and content.

        Args:
            settings_config: Dictionary with width, height, title, and tabs.
        """
        message = {
            "type": "settingsRender",
            "payload": settings_config,
        }
        self._send(message)

    def send_settings_open(self) -> None:
        """Open the settings window.

        The settings window must have been rendered first via
        send_settings_render().
        """
        message = {
            "type": "settingsOpen",
            "payload": {},
        }
        self._send(message)

    def send_settings_close(self) -> None:
        """Close the settings window."""
        message = {
            "type": "settingsClose",
            "payload": {},
        }
        self._send(message)

    def send_notification_action(
        self,
        action: str,
        request_id: Optional[str] = None,
        notification: Optional[dict] = None,
        notification_id: Optional[str] = None,
        trigger: Optional[dict] = None,
    ) -> None:
        """Send a notification action to the Swift runtime.

        Args:
            action: Action type - "push", "schedule", "cancel", "cancelAll",
                   "getScheduled", "getDelivered", "getScheduledById",
                   "getDeliveredById", "requestPermission".
            request_id: Unique ID for async response matching.
            notification: Notification data dictionary (for push/schedule).
            notification_id: Target notification ID (for cancel/get by id).
            trigger: Trigger configuration (for schedule).
        """
        payload: dict = {"action": action}

        if request_id is not None:
            payload["requestId"] = request_id
        if notification is not None:
            payload["notification"] = notification
        if notification_id is not None:
            payload["notificationId"] = notification_id
        if trigger is not None:
            payload["trigger"] = trigger

        message = {
            "type": "notification",
            "payload": payload,
        }
        self._send(message)

    def set_event_handler(self, handler: Callable[[str, str], None]) -> None:
        """Set the handler for events from the Swift runtime.

        Args:
            handler: Callback function receiving (node_id, event_string).
                The event string format varies by event type:
                - "tap" - User tapped a button
                - "change:<value>" - Value changed (TextField, Toggle, etc.)
                - "hotkey:<shortcut>" - Global hotkey pressed
                - "drop:<paths>" - Files dropped on a view
                - "clipboard:<content>" - Clipboard read response
                - "fileDialog:<paths>" - File dialog response
        """
        self._on_event = handler

    def _send(self, message: Any) -> None:
        """Send a message to the Swift runtime.

        Messages are serialized with MessagePack and sent with a 4-byte
        big-endian length prefix.

        Args:
            message: Dictionary to serialize and send.
        """
        if not self._connected or not self._socket:
            return

        with self._send_lock:
            try:
                packed = msgpack.packb(message, use_bin_type=True)
                # Length prefix (4 bytes, big-endian)
                length = struct.pack(">I", len(packed))
                self._socket.sendall(length + packed)
            except Exception as e:
                logger.error("Error sending message", exc=e)
                self._connected = False

    def _start_read_thread(self) -> None:
        """Start background threads for reading messages and dispatching events.

        Creates a daemon thread that continuously reads messages from
        the Swift runtime, and a separate event dispatch thread that
        processes events sequentially to avoid concurrent view mutations.
        """
        self._read_thread = threading.Thread(target=self._read_loop, daemon=True)
        self._read_thread.start()
        self._event_thread = threading.Thread(target=self._event_loop, daemon=True)
        self._event_thread.start()

    def _event_loop(self) -> None:
        """Sequential event dispatch loop.

        Pulls (node_id, event) tuples from the queue and calls
        _dispatch_event one at a time, ensuring event handlers never
        run concurrently.
        """
        while True:
            item = self._event_queue.get()
            if item is None:
                break
            node_id, event = item
            self._dispatch_event(node_id, event)

    def _read_loop(self) -> None:
        """Background loop for reading events from the Swift runtime.

        Continuously reads length-prefixed MessagePack messages from
        the socket and passes them to :meth:`_handle_message`.
        """
        buffer = b""

        while self._connected and self._socket:
            try:
                data = self._socket.recv(4096)
                if not data:
                    break

                buffer += data

                # Extract complete messages
                while len(buffer) >= 4:
                    length = struct.unpack(">I", buffer[:4])[0]
                    if len(buffer) < 4 + length:
                        break

                    message_data = buffer[4 : 4 + length]
                    buffer = buffer[4 + length :]

                    try:
                        message = msgpack.unpackb(message_data, raw=False)
                        self._handle_message(message)
                    except Exception as e:
                        logger.error("Error unpacking message", exc=e)

            except Exception as e:
                if self._connected:
                    logger.error("Error reading from socket", exc=e)
                break

        self._connected = False

    def _handle_message(self, message: dict) -> None:
        """Handle a message from the Swift runtime."""
        msg_type = message.get("type")
        logger.info("Received message", type=msg_type)

        if msg_type == "event" and self._on_event:
            node_id = message.get("nodeId", "")
            event = message.get("event", "")
            logger.info("Dispatching event", node_id=node_id, event=event)
            # Queue events for sequential dispatch to avoid concurrent view mutations
            self._event_queue.put((node_id, event))

        elif msg_type == "serviceResponse":
            self._handle_service_response(message)

        elif msg_type == "notificationResponse":
            self._handle_notification_response(message)

        elif msg_type == "fileDialogResponse":
            self._handle_file_dialog_response(message)

    def _handle_file_dialog_response(self, message: dict) -> None:
        """Handle a file dialog response."""
        from .file_picker import _handle_file_dialog_response
        _handle_file_dialog_response(message)

    def _dispatch_event(self, node_id: str, event: str) -> None:
        """Dispatch an event to the handler (runs on separate thread)."""
        try:
            self._on_event(node_id, event)
        except Exception as e:
            logger.error("Error in event handler", exc=e, node_id=node_id, event=event)

    def _handle_service_response(self, message: dict) -> None:
        """Handle a service query response."""
        service = message.get("service", "")
        request_id = message.get("requestId", "")
        data = message.get("data", {})

        try:
            # Handle camera stream frames specially (no request_id)
            if service == "camera" and data.get("isStreamFrame"):
                from ..services.camera import Camera
                Camera._handle_stream_frame(data)
                return

            # All other service responses go through Service base class
            from ..services.base import Service
            Service._handle_response(request_id, data)
        except Exception as e:
            logger.error("Error handling service response", exc=e, service=service)

    def _handle_notification_response(self, message: dict) -> None:
        """Handle a notification response from Swift."""
        request_id = message.get("requestId", "")
        data = message.get("data", {})

        try:
            # Import here to avoid circular import
            from ..notifications.manager import NotificationManager

            # Find the manager instance - it's stored on the App
            # This is a bit of a hack, but we need to route the response
            # to the correct manager instance
            if hasattr(self, "_notification_manager") and self._notification_manager:
                self._notification_manager._handle_response(request_id, data)
        except Exception as e:
            logger.error("Error handling notification response", exc=e)

    def set_notification_manager(self, manager: "NotificationManager") -> None:
        """Set the notification manager for handling responses."""
        self._notification_manager = manager
