# pynoblox

A minimal async Roblox API client for Python, including support for
editing GamePass details and price, inspired by noblox.js.
