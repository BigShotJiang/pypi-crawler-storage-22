pyobvector.client package
=========================

Submodules
----------

pyobvector.client.collection\_schema module
-------------------------------------------

.. automodule:: pyobvector.client.collection_schema
   :members:
   :undoc-members:
   :show-inheritance:

pyobvector.client.enum module
-----------------------------

.. automodule:: pyobvector.client.enum
   :members:
   :undoc-members:
   :show-inheritance:

pyobvector.client.exceptions module
-----------------------------------

.. automodule:: pyobvector.client.exceptions
   :members:
   :undoc-members:
   :show-inheritance:

pyobvector.client.index\_param module
-------------------------------------

.. automodule:: pyobvector.client.index_param
   :members:
   :undoc-members:
   :show-inheritance:

pyobvector.client.milvus\_like\_client module
---------------------------------------------

.. automodule:: pyobvector.client.milvus_like_client
   :members:
   :undoc-members:
   :show-inheritance:

pyobvector.client.ob\_vec\_client module
----------------------------------------

.. automodule:: pyobvector.client.ob_vec_client
   :members:
   :undoc-members:
   :show-inheritance:

pyobvector.client.partitions module
-----------------------------------

.. automodule:: pyobvector.client.partitions
   :members:
   :undoc-members:
   :show-inheritance:

pyobvector.client.schema\_type module
-------------------------------------

.. automodule:: pyobvector.client.schema_type
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pyobvector.client
   :members:
   :undoc-members:
   :show-inheritance:
