from pytest import fixture


@fixture()
def olan_teardrop():
    return "`````4,3if``ry.'22"


@fixture()
def olan_figure_n():
    return "/~~+++..''1.'n('5if,3.).,8.---~"