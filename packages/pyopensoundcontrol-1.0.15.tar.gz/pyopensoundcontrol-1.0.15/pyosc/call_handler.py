import queue
import threading
from typing import overload

from oscparser import OSCMessage
from pydantic import BaseModel, ValidationError

from .peer import Peer


class Call:
    def __init__[T: BaseModel](self, queue: queue.Queue[T], validator: type[T]):
        self.queue = queue
        self.validator = validator


class CallHandlerValidationError(ValueError):
    pass


class CallHandler:
    """A call handler is a way of communicating with a peer that is more akin to a restuful API from the user point of view. You send a request, it gives you a response."""

    def __init__(self, peer: Peer):
        self.peer = peer
        self.queues: dict[str, Call] = {}
        self.queue_lock = threading.Lock()

    @overload
    def call(
        self,
        message: OSCMessage,
        *,
        return_address: str | None = None,
        timeout: float = 5.0,
    ) -> OSCMessage | None: ...

    @overload
    def call[T: BaseModel](
        self,
        message: OSCMessage,
        *,
        return_address: str | None = None,
        validator: type[T],
        timeout: float = 5.0,
    ) -> T | None: ...

    def call(
        self,
        message: OSCMessage,
        *,
        return_address: str | None = None,
        validator: type[BaseModel] | None = None,
        timeout: float = 5.0,
    ) -> BaseModel | None:
        """Calling a call handler will send a message to the peer, and await a response that meets the critieria.

        Args:
            ``message (OSCMessage)``: An OSCMessage to send to the peer.
            ``return_address (str | None, optional)``: The address to listen for a response on. Defaults to None.
            ``validator (type[BaseModel] | None, optional)``: A Pydantic model to validate the response against. Defaults to None.
            ``timeout (float, optional)``: How long to wait for a response before timing out. Defaults to 5.0.

        Returns:
            BaseModel | None: The validated response model if received within the timeout period, otherwise None.
        """

        if validator is None:
            validator = OSCMessage
        if not return_address:
            return_address = message.address
        responseq = queue.Queue()
        with self.queue_lock:
            self.queues[return_address] = Call(responseq, validator)
            self.peer.Dispatcher.add_handler(return_address, self)
        self.peer.send_message(message)
        try:
            response = responseq.get(timeout=timeout)
            return response
        except queue.Empty:
            return None
        finally:
            with self.queue_lock:
                self.peer.Dispatcher.remove_handler(return_address)
                if return_address in self.queues:
                    del self.queues[return_address]

    def __call__(self, message: OSCMessage):
        with self.queue_lock:
            if message.address in self.queues:
                try:
                    validated_msg = self.queues[message.address].validator.model_validate(message.model_dump())
                    self.queues[message.address].queue.put(validated_msg)
                except ValidationError as e:
                    raise CallHandlerValidationError(f"CallHandler validation error: {e}") from e
