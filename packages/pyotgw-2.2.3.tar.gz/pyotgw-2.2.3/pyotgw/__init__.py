"""The main pyotgw __init__ file"""

from pyotgw.pyotgw import OpenThermGateway

__all__ = ["OpenThermGateway"]
