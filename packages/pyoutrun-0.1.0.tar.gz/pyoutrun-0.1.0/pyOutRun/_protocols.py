# SPDX-FileCopyrightText: Copyright © 2024-2026 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from typing import Protocol

import numpy as np
import numpy.typing as npt

__all__ = ["FitnessFunction"]

class FitnessFunction(Protocol):
	def __call__(self,
				 params: npt.NDArray[np.float64],
				 x_vector: npt.NDArray[np.float64],
				 y_array: npt.NDArray[np.float64],
				 *args,
) -> np.float64:
		...
