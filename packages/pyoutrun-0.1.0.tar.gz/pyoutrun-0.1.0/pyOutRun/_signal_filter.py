# SPDX-FileCopyrightText: Copyright © 2025 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Functions for downsampling of real signals."""

import numpy as np
from scipy import signal as ssig
from numpy import typing as npt

__all__ = ["find_butter_lowpass_wn", "downsampling"]

def find_butter_lowpass_wn(order: int,
						   cutoff_freq: float,
						   fs: float,
						   threshold: float = 0.999,
						   min_step: float = 1e-12,
						   start_exp: int = 0,
) -> tuple[np.float64, np.ndarray, np.ndarray]:
	"""
	Optimizes a low-pass Butterworth filter based on input parameters.

	Parameters
	----------
	order : int
		The order of the Butterworth filter.
	cutoff_freq : float
		The target cutoff frequency of the filter, in Hertz.
	fs : float
		The sampling frequency, in Hertz.
	threshold : float, optional
		The amplitude threshold at the cutoff frequency. Default is 0.999.
	min_step : float, optional
		The minimum resolution for the frequency step during optimization.
		Default is 1e-12.
	start_exp : int, optional
		The power of ten for the initial step size. Default is 0.

	Returns
	-------
	tuple[np.float64, np.ndarray, np.ndarray]
		- The optimized cutoff frequency.
		- The frequency array.
		- The corresponding frequency response.
	"""
	f_iter = cutoff_freq
	step_exp = start_exp
	f_tol_exp = np.int16(np.ceil(np.log10(min_step)))

	while True:
		sos = ssig.butter(order * 2, f_iter, btype="low", fs=fs, output="sos")
		freq, h = ssig.freqz_sos(sos, worN=fs, fs=fs)

		step = np.power(10.0, step_exp)

		if freq[np.argmax(np.abs(h) < threshold)] >= cutoff_freq:
			if step_exp == f_tol_exp:
				break
			else:
				f_iter = f_iter - step
				step_exp = step_exp - 1
		else:
			f_iter = f_iter + step

	return f_iter, freq, h


def downsampling(signal: np.ndarray,
				 time: npt.NDArray,
				 new_fs: float,
				 cutoff_freq_filter: float | None = None,
				 order: int = 5,
) -> tuple[np.ndarray, np.ndarray]:
	"""
	Downsamples a given signal by applying a low-pass filter and interpolation.

	Parameters
	----------
	signal : np.ndarray
		The input signal (columns are channels).
	time : npt.NDArray
		The time array corresponding to the input signal.
	new_fs : float
		The new, lower sampling frequency.
	cutoff_freq_filter : float or None, optional
		The cutoff frequency for the low-pass filter. If `None` defaults to `new_fs`.
	order : int, optional, default=5
		The order of the low-pass filter.

	Returns
	-------
	tuple of (np.ndarray, np.ndarray)
		- Downsampled signal array.
		- New time array.
	"""
	if cutoff_freq_filter is None:
		cutoff_freq_filter = new_fs

	dt = np.float64(np.median(np.diff(time)))

	sos = ssig.butter(order, cutoff_freq_filter, btype="low", fs=1 / dt, output="sos")
	sig_lowpass = ssig.sosfiltfilt(sos, signal, axis=0)

	time_new = np.arange(np.int_(np.floor(time[-1] - time[0]) * new_fs)) / new_fs + time[0]
	signal_new = np.zeros((time_new.size, signal.shape[1]))
	for a in range(signal.shape[1]):
		signal_new[:, a] = np.interp(time_new, time, sig_lowpass[:, a])

	return signal_new, time_new
