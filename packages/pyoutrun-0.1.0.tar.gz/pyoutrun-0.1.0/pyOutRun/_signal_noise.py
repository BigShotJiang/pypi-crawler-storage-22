# SPDX-FileCopyrightText: Copyright © 2025 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Functions for calculating the signal-to-noise ratio (SNR) and scaling the noise to achieve a specific SNR."""

import numpy as np
import numpy.typing as npt

__all__ = ["get_noise_scaling"]


def _signal_power(signal: npt.NDArray[np.float64],
) -> npt.NDArray[np.float64]:
	"""Calculate signal power."""
	return np.sum(np.square(signal)) / signal.size


def _get_snr(signal: npt.NDArray[np.float64],
			 noise: npt.NDArray[np.float64],
) -> npt.NDArray[np.float64]:
	"""Calculate SNR from known signal with known noise."""
	p_sig = _signal_power(signal)
	p_noise = _signal_power(noise)
	return 10 * np.log10(p_sig / p_noise)


def get_noise_scaling(signal: npt.NDArray[np.float64],
					  noise: npt.NDArray[np.float64],
					  snr: float
) -> float:
	"""Determine the factor by which the defined SNR can be adjusted by scaling the noise."""
	if np.isposinf(snr):
		factor = np.float64(0)
	else:
		p_sig = _signal_power(signal)
		p_noise = _signal_power(noise)
		factor = np.sqrt(p_sig / p_noise * np.power(10, -(snr / 10)))

	return factor
