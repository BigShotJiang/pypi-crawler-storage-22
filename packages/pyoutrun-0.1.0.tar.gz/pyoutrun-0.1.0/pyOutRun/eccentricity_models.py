# SPDX-FileCopyrightText: Copyright © 2024-2026 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Simulate position sensor signals for an eccentrically rotating circle."""

import numpy as np
import numpy.typing as npt
from typing import Literal

__all__ = ["eccentricity_geometry"]


def eccentricity_geometry(phi: npt.NDArray[np.float64],
						  radius: float,
						  eccentricity: npt.NDArray[np.float64],
						  sensor_pos: npt.NDArray[np.float64],
						  mode: Literal['xy', 'ra'] = 'xy'
)-> tuple[npt.NDArray[np.float64],
		  npt.NDArray[np.float64],
		  npt.NDArray[np.float64]]:
	"""
	Simulate position sensor signals for an eccentrically rotating circle.

	Parameters
	----------
	phi : array_like
		Angular lines (radians).
	radius : scalar
		Circle radius.
	eccentricity : array_like
		Center displacement (x, y) or (radius, angle).
	sensor_pos : array_like
		Sensor angular positions.
	mode : {'xy', 'ra'}, optional
		Format of eccentricity: Cartesian ('xy') or polar ('ra').

	Returns
	-------
	delta_s : ndarray
		Simulated signals.
	gamma : ndarray
		Angle between the x-axis and the intersection of the sensor axis with the eccentric circle.
	l1 : ndarray
		Distance of the centre point shift parallel to the sensor axis.
	"""

	phi = np.asarray(phi, dtype=np.float64)
	radius = np.float64(radius)
	eccentricity = np.asarray(eccentricity, dtype=np.float64)
	sensor_pos = np.atleast_1d(np.asarray(sensor_pos, dtype=np.float64))

	if 'xy' in mode:
		abs_exc = np.linalg.norm(eccentricity) # Magnitude of eccentricity
		alpha = np.arctan2(eccentricity[1], eccentricity[0]) # Offset angle of eccentricity position vector
	elif 'ra' in mode:
		abs_exc = eccentricity[0]
		alpha = eccentricity[1]
	else:
		raise ValueError('"mode" must be "xy" or "ra".')

	if abs_exc > radius:
		raise ValueError('Eccentricity too large, circle leaves measurement axis.')

	angle = phi + alpha # Running angle of position vector
	x_r_phi = abs_exc * np.cos(angle) # Running x and y coordinates of actual center
	y_r_phi = abs_exc * np.sin(angle)

	delta_s = np.zeros((phi.size, sensor_pos.size), dtype=np.float64) # Initialize arrays
	gamma = np.zeros(delta_s.shape)
	l1 = np.zeros(delta_s.shape)

	for a in range(sensor_pos.size): # for each sensor position:
		k = abs_exc * np.sin(angle - sensor_pos[a]) # Aux segment k
		l1[:, a] = abs_exc * np.cos(angle - sensor_pos[a]) # Aux segment l1, center shift parallel to sensor axis
		l2 = np.sqrt(np.square(radius) - np.square(k)) # Aux segment l2
		s = l1[:, a] + l2 # Distance target axis to intersection of measurement axis with circle
		delta_s[:, a] = s - radius # Deviation of measured value from (theor.) measured value target circle path
		gamma_raw = np.arctan2(s * np.sin(sensor_pos[a]) - y_r_phi, # Angle between intersection measurement axis, shifted center, and shifted x-axis
							   s * np.cos(sensor_pos[a]) - x_r_phi)
		gamma[:, a] = np.unwrap(gamma_raw) # Remove jumps from angle

	return delta_s, gamma, l1
