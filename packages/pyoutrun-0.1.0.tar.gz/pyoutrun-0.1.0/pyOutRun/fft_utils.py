# SPDX-FileCopyrightText: Copyright © 2025 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Functions for calculating the (inverse) Fourier transform with correct normalization for real signals."""

import numpy as np
import numpy.typing as npt
from scipy import signal as ssig

__all__ = ["rfft_tukey_corrected", "irfft_corrected"]

def rfft_tukey_corrected(x: npt.NDArray[np.float64],
						 fs: float,
						 axis: int = 0,
						 tukey: float = 0.05,
) -> tuple[np.ndarray, np.ndarray]:
	"""
	Applies a Tukey window to the input signal along the specified axis, performs a normalized
	real-valued fast Fourier transform (RFFT), and corrects the spectrum for a real-valued input
	signal. The function also computes the corresponding frequency values.

	Parameters
	----------
	x : ndarray
		Input signal data array.
	fs : float
		Sampling frequency of the input signal.
	axis : int, default=0
		The axis over which the computation is performed. Default is 0.
	tukey : float, default=0.05
		The alpha parameter for the Tukey window. Determines the fraction of the window inside
		the cosine taper. Default is 0.05.

	Returns
	-------
	tuple of (np.ndarray, np.ndarray)
		- The first element is the spectrum of the input signal after applying the Tukey window and
		  performing the RFFT.
		- The second element is the array of frequency values corresponding to the computed spectrum.
	"""
	shape_to = np.ones(x.ndim, dtype=np.int_)  # Required shape of the Tukey window vector
	shape_to[axis] = -1
	# noinspection PyUnresolvedReferences
	window = ssig.windows.tukey(x.shape[axis], alpha=tukey, sym=False).reshape(tuple(shape_to))

	spectrum = np.fft.rfft(x * window, axis=axis, norm='forward')

	spectrum = _helper_normalization(spectrum, axis, inverse=False)  # Normalize for real input signal

	freq = np.fft.rfftfreq(x.shape[axis], d=1/fs)

	return spectrum, freq


def irfft_corrected(spectrum: npt.NDArray[np.complex128],
					axis: int = 0,
) -> np.ndarray:
	"""
	Computes the inverse real-to-complex FFT on the input spectrum after reversing the normalization.

	Parameters
	----------
	spectrum : npt.NDArray[np.complex128]
		The input frequency-domain spectrum.
	axis : int, optional
		The axis along which the reverse FFT is performed. The default is 0.

	Returns
	-------
	np.ndarray
		The real-valued time-domain signal array.
	"""
	spectrum = _helper_normalization(spectrum, axis, inverse=True)

	return np.fft.irfft(spectrum, norm='forward', axis=axis)


def _helper_normalization(spectrum, axis, inverse=False):
	"""
	Handles the normalization of a spectrum along a specified axis.

	Parameters
	----------
	spectrum : numpy.ndarray
		The spectrum to be normalized.
	axis : int
		The axis along which the normalization is applied.
	inverse : bool, optional
		A flag indicating whether the normalization is being undone for iFFT
		(True) or applied for a forward FFT (False). By default, this is False.

	Returns
	-------
	numpy.ndarray
		The normalized spectrum with its original axis order restored.
	"""
	spectrum = np.moveaxis(spectrum, axis, 0)  # Move normalization axis to 0
	if inverse:
		spectrum[1:-1] = 0.5 * spectrum[1:-1]  # Reverse normalization for iFFT
	else:
		spectrum[1:-1] = 2 * spectrum[1:-1]    # Normalize for real input signal
	spectrum = np.moveaxis(spectrum, 0, axis)  # Restore axis order

	return spectrum
