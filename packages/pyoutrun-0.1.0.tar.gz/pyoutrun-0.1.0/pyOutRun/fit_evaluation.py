# SPDX-FileCopyrightText: Copyright © 2024-2026 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import numpy as np
import numpy.typing as npt
from scipy import signal as ssig
from scipy import optimize as sop
from typing import Literal

from .runout_fit import runout_fit
from ._protocols import FitnessFunction
from ._signal_noise import get_noise_scaling

__all__ = ["evaluate_fit", "simulate_roundness_error"]


def evaluate_fit(x_vector: npt.NDArray[np.float64],
				 y_true: npt.NDArray[np.float64],
				 y_noise: npt.NDArray[np.float64],
				 snr: float,
				 radius: float,
				 fitfunc: FitnessFunction | Literal['cos', 'exc'],
				 bounds: sop.Bounds | None,
				 lowpass: float,
				 fs: float,
				 ) -> sop.OptimizeResult:
	"""
	Evaluates the fit function by applying scaled noise to the known signal.

	Parameters
	----------
	x_vector : npt.NDArray[np.float64]
		Independent variable data.
	y_true : npt.NDArray[np.float64]
		True signal data without noise.
	y_noise : npt.NDArray[np.float64]
		Noise data to be added.
	snr : float
		Desired Signal-to-Noise Ratio (SNR).
	radius : float
		Radius parameter.
	fitfunc : FitnessFunction or Literal['cos', 'exc']
		The fitness function type.
	bounds : sop.Bounds or None
		Constraints for optimization.
	lowpass : float
		Cutoff frequency for the lowpass filter.
	fs : float
		Sampling frequency.

	Returns
	-------
	sop.OptimizeResult
		The result of the fitting process.
	"""
	scale_factor = get_noise_scaling(y_true, y_noise, snr)  # Determine scaling factor for noise to reach SNR
	y_noisy = y_true + scale_factor * y_noise  # Add scaled noise to signal

	butter_sos = ssig.butter(10, lowpass, output='sos', fs=fs)
	data_ds = ssig.sosfiltfilt(butter_sos, y_noisy, axis=0)

	return runout_fit(x_vector, data_ds, radius, fitfunc, bounds)


def simulate_roundness_error(phi: npt.NDArray[np.float64],
							 f_limit: float,
							 seed: int = 555,
							 filter_order: int = 10,
							 ) -> npt.NDArray[np.float64]:
	"""
	Generate simulated surface deviations based on filtered random noise.

	Parameters
	----------
	phi : numpy.ndarray
		Angular lines (in radians).
	f_limit : float
		Cutoff frequency (multiples of rotational frequency).
	seed : int, optional
		Random seed (default 555).
	filter_order : int, optional
		Order of the Butterworth filter (default 10).

	Returns
	-------
	numpy.ndarray
		Normalized simulated roundness error signal.
	"""

	len_gen = 5  # Initial length of generated error signal as multiple of phi.size
	settling = filter_order * 100  # Cut off filter settling phase generously
	a = 0  # Initial start point of window

	while len_gen < 25:  # Limit for length of error signal search
		error_raw = np.asarray(np.random.default_rng(seed).standard_normal(len_gen * phi.size))  # Create normal dist error
		error_smooth = np.asarray(_butterworth_lowpass(error_raw, filter_order, phi.size, f_limit))  # Smooth via lowpass
		tol = np.abs(np.mean(np.diff(error_smooth)))  # Jump from end to start should not be larger than median of jumps

		while a < ((len_gen - 1) * phi.size - settling):  # Window in error signal range
			jump_val = error_smooth[settling + a] - error_smooth[settling + a + phi.size - 1]  # Magnitude of jump
			if np.abs(jump_val) <= tol:  # If jump is within tolerance:
				error_cut = error_smooth[settling + a: settling + phi.size + a]  # Cut out matching values
				error_scaled = error_cut / np.std(error_cut)  # Normalize standard deviation to 1
				return error_scaled
			a = a + 1  # Shift window
		len_gen = len_gen + 1  # If no suitable window found, generate longer signal

	raise Exception('No suitable segment found. Change "seed" and try again.')


def _butterworth_lowpass(signal: npt.NDArray[np.float64],
						 order: int,
						 fs: float,
						 cutoff_freq: float,
						 ) -> npt.NDArray[np.float64]:
	"""Butterworth low-pass filter"""
	butter_sos = ssig.butter(order, cutoff_freq, btype='lowpass', output='sos', fs=fs)
	return ssig.sosfiltfilt(butter_sos, signal, axis=0)
