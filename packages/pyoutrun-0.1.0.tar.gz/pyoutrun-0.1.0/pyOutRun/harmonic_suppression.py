# SPDX-FileCopyrightText: Copyright © 2024-2026 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Functions for determining properties of harmonic suppression."""

import logging
import numba as nb
import numpy as np
from numpy import typing as npt
from scipy import interpolate as sip, signal as ssig

from .fft_utils import rfft_tukey_corrected, irfft_corrected
from ._signal_filter import find_butter_lowpass_wn

logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.WARNING)

__all__ = ["probe_angle_condition", "harmonic_components"]

@nb.njit(cache=True, parallel=True)
def probe_angle_condition(freq: npt.NDArray[np.float64],
						  positions: npt.NDArray[np.float64],
) -> npt.NDArray[np.float64]:
	"""
	Determines the condition of the sensor position matrix.

	Parameters
	----------
	freq : npt.NDArray[np.float64]
		Frequency lines.
	positions : npt.NDArray[np.float64]
		Sensor angle positions in rad.

	Returns
	-------
	npt.NDArray[np.float64]
		  Condition numbers.
	"""
	pos_vector = np.exp(1j * positions)
	condition = np.empty(freq.shape[0], dtype=np.float64)
	for f in nb.prange(freq.shape[0]):
		pos_matrix = np.column_stack((pos_vector, # own `pos_matrix` for each thread, else race conditions
									  np.exp(1j * freq[f] * positions)))
		condition[f] = np.linalg.cond(pos_matrix)

	return condition


def harmonic_components(x_data: npt.NDArray[np.float64],
						y_data: npt.NDArray[np.float64],
						period: float,
						lb: int = 0,
						ub: int | None = None,
						reverse: bool = False,
						filter_order: int = 20,
) -> tuple[npt.NDArray[np.float64], npt.NDArray[np.float64]]:
	"""
	Extracts or suppresses harmonic components.

	Parameters
	----------
	x_data : npt.NDArray[np.float64]
		Independent variable.
	y_data : npt.NDArray[np.float64]
		Signal values.
	period : float
		Period of the base frequency.
	lb : int, optional
		Lower bound harmonic.
	ub : int or None, optional
		Upper bound harmonic.
	reverse : bool, optional
		If True, returns non-harmonic components.
	filter_order : int, optional
		Filter order.

	Returns
	-------
	tuple
		(x_data_resampled, y_data_processed)
	"""

	if period <= 0 or period > np.ptp(x_data):
		raise ValueError("Invalid period. Period must be positive and smaller than signal length.")
	x_data = x_data / period # scale so that period is 1

	fs = 1 / np.float64(np.median(np.diff(x_data)))
	ub_max = np.floor(fs / 2) # highest possible harmonic

	if ub is None:
		ub = ub_max
	elif ub > ub_max:
		logging.warning(f"Invalid upper bound. Upper bound set to max possible value for current `x_data` (={ub_max:.3g}).")
		ub = ub_max
	if lb < 0 or lb >= ub:
		raise ValueError(f"Lower bound must be greater than 0 and smaller than `ub` (={ub:.3g}).")

	threshold, *_ = find_butter_lowpass_wn(filter_order, ub, fs, start_exp=-2) # determine cutoff freq of Butterworth filter
	sos = ssig.butter(filter_order, # coefficients of lowpass filter
					  threshold,
					  fs=fs,
					  output='sos')
	y_data_lp = ssig.sosfiltfilt(sos, y_data, axis=0) # lowpass filter signal

	num_ds = np.floor(x_data.size / fs * 2 * ub) # length of new signal
	x_data_h = np.arange(num_ds) / (2 * ub) + x_data[0] # x-vector of new signal

	signal_ds = sip.make_interp_spline(x_data, y_data_lp, axis=0, k=1).__call__(x_data_h) # resample signal

	spectrum, freq = rfft_tukey_corrected(signal_ds, fs=2 * ub, axis=0, tukey=0.05) # transform to frequency domain

	bool_lb = lb <= freq # selection of all frequencies >= `lb`

	bool_harmonics = np.zeros(freq.shape, dtype=np.bool_) # selection of all frequencies that are multiples of base freq
	for h in range(lb, ub + 1):
		bool_harmonics[np.argmin(np.abs(freq - h))] = True # freq value closest to harmonic `h`

	if reverse: # exclude harmonics, but consider `lb`
		spectrum[np.logical_and(bool_lb, bool_harmonics)] = 0
	else: # select only harmonics, considering `lb`
		spectrum[np.logical_and(bool_lb, np.logical_not(bool_harmonics))] = 0

	y_data_h = irfft_corrected(spectrum) # inverse transform from frequency domain
	x_data_h = x_data_h * period # undo scaling

	return x_data_h, y_data_h
