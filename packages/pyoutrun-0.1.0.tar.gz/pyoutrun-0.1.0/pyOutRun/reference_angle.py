# SPDX-FileCopyrightText: Copyright © 2024-2026 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Functions for determining the sensor angle position from measurements taken with adhesive tape on the measuring track."""

import numpy as np
from numba import njit
from scipy import optimize as sop, signal as ssig

__all__ = ["angle_pos_from_correlation", "angle_pos_from_shift", "angle_pos_from_rf"]

def angle_pos_from_correlation(phi: np.ndarray,
                               signal: np.ndarray):
    positions = np.zeros(signal.shape[1])
    lags = ssig.correlation_lags(phi.size, phi.size)

    for a in range(1, signal.shape[1]):
        corr = ssig.correlate(signal[:, a], signal[:, 0])
        max_corr = np.squeeze(lags[corr == np.max(corr)])

        positions[a] = 360 - np.mod(phi[-max_corr] - phi[0], 360)

    return positions


def angle_pos_from_shift(phi: np.ndarray,
                         signal: np.ndarray,
) -> tuple[np.ndarray, list[sop.OptimizeResult]]:
    """
    Computes angles from given phase shifts using optimization.

    Parameters
    ----------
    phi : np.ndarray
        Phase values.
    signal : np.ndarray
        2D array where each column represents a signal measurement at various time steps.

    Returns
    -------
    tuple
        First element is a 1D numpy array of computed positions for
	    each signal, and the second element is a list of optimization result objects
	    containing detailed information about the optimization for each signal.
    """
    positions = np.zeros(signal.shape[1])
    meta = list()

    for a in range(1, signal.shape[1]): # all further signals are referenced to the first
        result = sop.minimize_scalar(_fun_shift, # determine phase shift,
                                     bounds=(0.0, 360), # staying in range [0°, 360°]
                                     args=(phi, # angle line vector
                                           signal[:, 0] - np.median(signal[:, 0]), # reference signal, remove amplitude offset if possible
                                           signal[:, a] - np.median(signal[:, a]))) # signal to shift

        positions[a] = result.x
        meta.append(result) # output complete solver output separately

    return positions, meta


def angle_pos_from_rf(phi: np.ndarray,
                      signal: np.ndarray,
                      threshold_perc: float = 99.5,
                      threshold_grad: int = 30,
                      floor_rot_count: bool = True,
) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    """
    Computes sensor angles based on rotational feedback (RF) signal data.

    Parameters
    ----------
    phi : np.ndarray
        Array of angles in degrees.
    signal : np.ndarray
        2D array of signal data where columns represent individual sensor channels.
    threshold_perc : float, optional
        Percentile for gradient threshold (default 99.5).
    threshold_grad : int, optional
        Minimum consecutive valid gradient values (default 30).
    floor_rot_count : bool, optional
        Use floor of rotation count (default True).

    Returns
    -------
    tuple
        A tuple containing:
	    - sensorAngles: 1D array of mean angle positions for each sensor channel.
	    - meta: dict with the keys "std" and "stdN", containing the standard deviations of
	    the angle positions for each channel, and the number of samples used to calculate
	    the standard deviation.
    """
    if floor_rot_count:
        num_rot = np.int_(np.floor(np.ptp(phi) / 360)) # Number of full rotations
    else:
        num_rot = np.int_(np.round(np.ptp(phi) / 360))

    sensor_angles = np.zeros(signal.shape[1])
    deviation = np.zeros(signal.shape[1])
    std_n = np.zeros(signal.shape[1], dtype=np.int_)

    for a in range(signal.shape[1]): # each sensor channel
        mean_pos = np.ones(num_rot) * np.nan # one flank per rotation
        shift = 0.0 # set angle window normal for each channel initially
        angle_0 = phi - phi[0] # aux angle vector starts at 0; indices on `angle_0` correspond to those on `phi`!
        for r in range(num_rot): # for each rotation
            if shift != 0 and r == (num_rot - 1):
                break # last rotation would go beyond end of vector due to shift

            while True:
                idx_rot_select = np.nonzero(np.logical_and(((r * 360 + shift) < angle_0), # range of current rotation
                                                           (angle_0 < ((r + 1) * 360 + shift))))[0]
                signal_gradients = np.gradient(signal[idx_rot_select, a], angle_0[idx_rot_select]) # calculate gradients
                gradient_thresh = np.percentile(signal_gradients, threshold_perc) # gradient threshold for flank determination
                bool_above_thresh = signal_gradients > gradient_thresh # mask of gradient values above threshold

                bool_valid = _filter_bool_min_len(bool_above_thresh, threshold_grad) # filter outliers; at least ``threshold_grad`` values must be consecutive

                mean_pos[r] = np.mod(np.nanmean(angle_0[idx_rot_select[bool_valid]]) + phi[0], 360) # calculate mean sensor position
                # mean angle value of gradient area as sensor position of current rotation; limited to 360 degrees
                if r == 0 and shift == 0:
                    if not 30 < mean_pos[r] < 330:
                        shift = 180.0
                        continue
                break

        sensor_angles[a] = np.nanmean(mean_pos) # average determined angular position of all rotations
        deviation[a] = np.nanstd(mean_pos) # standard deviation of determined angular positions
        std_n[a] = np.count_nonzero(~np.isnan(mean_pos))

    meta = {"std": deviation, "stdN": std_n}

    return sensor_angles, meta


@njit(cache=True)
def _fun_shift(shift, phi, sig_ref, sig_shift):
    """Computes SSD between reference and shifted signal."""
    idx_stop = np.argmax(phi > (phi[-1] - shift)) # signal is shifted forward, so reference signal must be shortened at the end
    shifted = np.interp(phi[:idx_stop], phi - shift, sig_shift) # shift and interpolate signal
    ssq = np.sum(np.square(sig_ref[:idx_stop] - shifted)) # sum of squared errors
    return ssq


def _filter_bool_min_len(x: np.ndarray,
                         num_min_len: int,
) -> np.ndarray:
    """Filters boolean array for minimum run length."""
    mask = np.convolve(x, np.ones(num_min_len, dtype=np.int_), mode='same') >= num_min_len
    return x & mask
