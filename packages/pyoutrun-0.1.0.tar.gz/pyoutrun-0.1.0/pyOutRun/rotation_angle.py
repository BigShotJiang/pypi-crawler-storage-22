# SPDX-FileCopyrightText: Copyright © 2024-2026 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Identify areas of constant rotational speed and its frequency from an angle signal."""

import numpy as np
from scipy import signal as ssig

__all__ = ["rotation_angle", "get_const_gradient_idx"]

def rotation_angle(time: np.ndarray,
				   angle: np.ndarray,
				   percentile: float = 75,
) -> tuple[np.float64, np.float64]:
	"""
	Calculates the velocity and offset based on the gradient of an angle sequence.

	Parameters
	----------
	time : numpy.ndarray
		1D array containing time values.
	angle : numpy.ndarray
		1D array of angles.
	percentile : float, default=75
		Percentile value used to determine significant angle change rate.

	Returns
	-------
	tuple[numpy.float64, numpy.float64]
		(speed, offset)
	"""
	angle_gradient = np.gradient(angle, time) # Determine rate of angle change
	angle_speed = np.percentile(angle_gradient, percentile) # Threshold

	bool_mask = angle_gradient > angle_speed # Values above threshold
	bool_mask[np.argmax(angle):] = False # Do not use values after max angle

	A = np.column_stack((time[bool_mask], np.ones(np.count_nonzero(bool_mask))))
	x, _, _, _ = np.linalg.lstsq(A, angle[bool_mask], rcond=None)

	speed = x[0]
	offset = x[1]

	return speed, offset


def get_const_gradient_idx(x: np.ndarray,
						   y: np.ndarray,
						   fit_slope: float,
						   fit_intercept: float,
						   percentile: float = 25,
) -> np.ndarray:
	"""
	Identifies the range where gradients remain within specified deviations from a linear fit.

	Parameters
	----------
	x : np.ndarray
		Independent variable.
	y : np.ndarray
		Dependent variable.
	fit_slope : float
		Slope of linear fit.
	fit_intercept : float
		Intercept of linear fit.
	percentile : float, optional
		Threshold percentile.

	Returns
	-------
	np.ndarray
		Indices of first and last local minima below threshold.
	"""
	deviation = np.abs(x * fit_slope + fit_intercept - y) # Deviation Fit vs Measure
	idx_all_mins, _ = ssig.find_peaks(-1 * deviation) # Indices of all local minima

	threshold = np.percentile(deviation, percentile) # Max magnitude of deviation

	idx_pct = np.nonzero(deviation < threshold)[0] # Indices below threshold
	idx_mins = np.intersect1d(idx_all_mins, idx_pct) # Minima below threshold

	if idx_mins.size == 0:
		raise ValueError("No minima found below threshold.")

	idx_cut = idx_mins[[0, -1]] # First and last minimum

	return idx_cut
