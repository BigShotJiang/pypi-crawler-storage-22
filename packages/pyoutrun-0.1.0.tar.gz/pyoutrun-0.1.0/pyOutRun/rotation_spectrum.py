# SPDX-FileCopyrightText: Copyright © 2024-2026 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Determine the rotational speed of a shaft from the spectrum of its radial displacement."""

import numba as nb
import numpy as np
import numpy.typing as npt
from scipy import optimize as sop
from scipy import signal as ssig  # Peak finding
from typing import Literal

__all__ = ["rotation_spectrum"]


def rotation_spectrum(frequency_lines: npt.NDArray[np.float64],
					  spectrum: npt.NDArray[np.complex128],
					  tol: float | None = None,
					  percentile_val: float = 75,
					  harmonic_range: int | tuple[int, int] | None = None,
					  mode: Literal['prominence', 'magnitude'] = 'prominence',
					  position_zero: bool = True,
					  verbose: bool = False
					  ) -> tuple[np.float64, npt.NDArray[np.float64] | None, npt.NDArray[np.int_]]:
	r"""
	Determine the rotational speed of a shaft from the spectrum of its radial displacement.

	Parameters
	----------
	frequency_lines : (M,) array_like
		Frequency lines of the spectrum.
	spectrum : {(M,), (M, K)} array_like
		Spectrum of one or spectra of `K` synchronously recorded displacement signals.
	tol : {float, None}, default=None
		Half tolerance width of the search algorithm, as a coefficient of the distance from ``frequency lines``.
		Permissible values lie in the interval (0, 0.5). ``None`` sets the tolerance to half the frequency line spacing.
		Defaults to ``None``.
	percentile_val : scalar, default=75
		Value of the percentile of the peaks found that are not used to determine the rotational frequency.
	harmonic_range : int | tuple[int, int] | None
		Limits the order of harmonics used for rotation frequency detection.
		If an ``int`` is provided, it will be treated as ``(1,int)`` internally.
		If a tuple of two integers is provided, it will be used directly.
		``None`` allows the use of all possible harmonics.
		Defaults to ``None``.
	mode : {'prominence', 'magnitude'}, default='prominence'
		Selection method for peaks of the rotational speed harmonics. The peak of the `n`th harmonic is only taken into account
		if it lies in the range

		:math:`f_n = n * (f_rot \pm tol)`.
		``“magnitude”`` takes into account all remaining peaks whose magnitude is above the selected percentile.
		``“prominence”``, on the other hand, selects the peaks whose notch height is above the selected percentile.
		Defaults to ``'prominence'``.
	position_zero : bool, default=True
		Sets the first sensor position to zero; all further sensor positions are relative to the first.
	verbose : bool, default=False
		Enables debug output.

	Returns
	-------
	tuple
		- f_rot : np.float64
			The determined rotation frequency.
		- pos_angle : {(K-1,) ndarray, None}
			Estimated sensor angular positions (if K>1).
		- i_peaks : (L,) ndarray
			Orders `n` of the harmonics used.
	"""
	frequency_lines = np.squeeze(np.asanyarray(frequency_lines))  # Convert to ndarray if necessary and remove empty dims;
	spectrum = np.squeeze(np.asanyarray(spectrum))  # `frequency_lines` should now be a 1D array

	_check_args(**locals())  # Check validity of passed arguments

	if spectrum.ndim > 1:
		if spectrum.shape[1] > spectrum.shape[0]:  # Ensure column-wise orientation of channels
			spectrum = spectrum.T
		sum_spectrum = np.sum(np.abs(spectrum), axis=1)  # Sum magnitudes of all channels
	else:
		sum_spectrum = np.abs(np.ravel(spectrum))

	if sum_spectrum[0] > sum_spectrum[1]:
		idx_minima, _ = ssig.find_peaks(-sum_spectrum, distance=3)  # Find all local minima of the spectrum sum
		idx_minima = np.asanyarray(idx_minima, dtype=np.int_)  # Fix: Explicit type for linter
		idx_rot = np.argmax(sum_spectrum[idx_minima[0]:]) + idx_minima[0]  # Find index of max peak after the first minimum
		f_rot_est = frequency_lines[idx_rot]  # This frequency corresponds roughly to rotation freq
	else:  # For very low frequency resolutions, there might be no minimum before the maximum
		f_rot_est = frequency_lines[np.argmax(sum_spectrum)]

	if verbose:
		print(f"Initial rotation estimate: {f_rot_est:.3f} Hz ({f_rot_est * 60:.2f} rpm). Verify plausibility!")

	if tol is None:
		tol = np.mean(np.diff(frequency_lines)) / (2 * f_rot_est)  # Relative tolerance is +/- half relative frequency resolution at f_rot_est
		if verbose:
			print(f"Tolerance: {tol:.4f}")

	f_res = np.mean(np.diff(frequency_lines))  # Frequency resolution
	x_est = np.arange(1, frequency_lines[-1] / f_rot_est) * f_rot_est  # All harmonics of the initial estimate in range
	x_bounds = np.atleast_2d(x_est).T * np.array([1 - tol, 1 + tol])  # Tolerance bounds around harmonics; grows with order

	x_peak_dist = np.int_(np.floor(f_rot_est / f_res * (1 - tol)))  # Min allowed distance between peaks

	idx_peaks, _ = ssig.find_peaks(sum_spectrum, distance=x_peak_dist)  # Find peak indices (with distance constraint)
	idx_peaks = np.asanyarray(idx_peaks, dtype=np.int_)  # Fix: Explicit type for linter

	x_peaks_all = np.atleast_2d(frequency_lines[idx_peaks]).T  # Frequency lines of those peaks
	mask_freq = np.any((x_bounds[:, 0] < x_peaks_all) & (x_peaks_all < x_bounds[:, 1]), axis=1)  # Mask peaks inside tolerance
	x_peaks_tol = x_peaks_all[mask_freq]  # Frequency lines of valid peaks

	if 'mag' in mode:  # Select peaks by magnitude:
		y_peaks_valid = sum_spectrum[idx_peaks[mask_freq]]  # Magnitudes of peaks in tolerance range
		percentile = np.percentile(y_peaks_valid, percentile_val)
		mask_perc = y_peaks_valid >= percentile  # Mask peaks above percentile
		x_peaks_perc = x_peaks_tol[mask_perc]  # Frequency lines of valid peaks
	else:  # Select peaks by prominence (catch invalid modes via exception later)
		prominence, *_ = ssig.peak_prominences(sum_spectrum, idx_peaks[mask_freq])  # Get prominence
		percentile = np.percentile(prominence, percentile_val)
		mask_perc = prominence >= percentile
		x_peaks_perc = x_peaks_tol[mask_perc]

	if verbose:
		print(f"Usable peaks ({mode}): {x_peaks_perc.size}")

	if x_peaks_perc.size < 1:
		raise Exception('No valid peaks found.')

	i_peaks = np.rint(x_peaks_perc / f_rot_est)  # Determine order of found peaks

	if harmonic_range is not None:
		if isinstance(harmonic_range, int):  # Only upper bound provided
			harmonic_range = (1, harmonic_range)
		if isinstance(harmonic_range, tuple):
			i_peaks_mask = np.logical_and(harmonic_range[0] <= i_peaks,  # Peaks within range
										  i_peaks <= harmonic_range[1])
			i_peaks_mask = np.squeeze(i_peaks_mask)  # Ensure 2D arrays stay correct
			i_peaks = i_peaks[i_peaks_mask]  # Keep only peaks in range: orders
			x_peaks_perc = x_peaks_perc[i_peaks_mask]  # and frequencies
		else:
			raise ValueError('harmonic_range must be int, tuple[int, int] or None.')

	# Check if peaks remain after filtering
	if i_peaks.size == 0:
		raise ValueError("No peaks remaining after harmonic filtering.")

	f_rot, *_ = np.linalg.lstsq(i_peaks, x_peaks_perc, rcond=None)  # Determine rotation freq via LSQ (weights higher freqs more)
	f_rot = np.squeeze(f_rot)

	pos_angle = None
	if spectrum.ndim == 2:  # If angles between channels can be determined:
		phase = np.angle(spectrum[idx_peaks[mask_freq][mask_perc], :])  # Phase responses

		res = sop.least_squares(_fitness_position,  # Determine sensor positions via LSQ from valid harmonics
								x0=phase[0, :],  # Initial guess: phase angle of f_rot line
								args=(phase, i_peaks),
								bounds=(-np.ones(phase.shape[1]) * np.pi,
										np.ones(phase.shape[1]) * np.pi))

		pos_angle = -1 * res.x  # Negate because positive sensor angle leads to negative phase shift

		if position_zero:
			pos_angle = np.mod(pos_angle - pos_angle[0] + (2 * np.pi), (2 * np.pi))  # Set first sensor to zero

	return f_rot, pos_angle, i_peaks


@nb.njit(cache=True)
def _fitness_position(phase_offset: npt.NDArray[np.float64],
					  phase: npt.NDArray[np.float64],
					  harm_order: npt.NDArray[np.float64]
					  ) -> np.float64:
	# phase[harm_order, sensor]
	sum_sq = np.float64(0)
	for z in range(harm_order.size):  # For all valid harmonics
		for s in range(phase_offset.size):  # and all phase offsets from sensor positions:
			sim_phase = phase_offset[s] * harm_order[z]  # Calculate phase from estimated params
			sim_phase = np.mod(sim_phase + np.pi, 2 * np.pi)[0] - np.pi  # Limit to [-pi, pi)
			sum_sq = sum_sq + np.square(phase[z, s] - sim_phase)  # Sum of squared errors

	return sum_sq


def _check_args(**kwargs):
	assert "frequency_lines" in kwargs
	assert "spectrum" in kwargs
	assert "tol" in kwargs
	assert "percentile_val" in kwargs
	assert "mode" in kwargs

	if kwargs["frequency_lines"].ndim != 1:
		raise ValueError('"frequency_lines" must be a 1D array.')
	if not np.all(np.diff(kwargs["frequency_lines"]) > 0):
		raise ValueError('"frequency_lines" must be strictly monotonically increasing.')
	if not (kwargs["frequency_lines"].size in kwargs["spectrum"].shape):
		raise ValueError('"frequency_lines" and "spectrum" shapes do not match.')
	if kwargs["tol"] is not None:
		if not (0 < kwargs["tol"] < 0.5):
			raise ValueError('"tol" must be in the open interval (0, 0.5) or None.')
	if not (0 <= kwargs["percentile_val"] <= 100):
		raise ValueError('"percentile_val" must be in [0, 100].')
	if not kwargs["mode"] in ['prominence', 'magnitude']:
		raise ValueError('"mode" must be "prominence" or "magnitude".')
