# SPDX-FileCopyrightText: Copyright © 2024-2026 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Analyze eccentric motion data measured over time using numerical and signal processing techniques."""

import logging
from typing import Literal

import numpy as np
import numpy.typing as npt
from numba import njit, prange as nbprange
from scipy import optimize as sop, signal as ssig

from ._protocols import FitnessFunction
from .rotation_spectrum import rotation_spectrum

logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.WARNING)

__all__ = ["runout_fit"]

def runout_fit(x_vector: npt.NDArray[np.float64],
			   y_array: npt.NDArray[np.float64],
			   radius: float = 1.0,
			   fitfunc: FitnessFunction | Literal['cos', 'exc'] = 'exc',
			   bounds: sop.Bounds | None = None,
			   position_zero: bool = True,
) -> sop.OptimizeResult:
	"""
	Fits a mathematical model to the data points using differential evolution.

	Parameters
	----------
	x_vector : npt.NDArray[np.float64]
		Time series for measurements.
	y_array : npt.NDArray[np.float64]
		Measurement data (columns = sensors).
	radius : float, default=1.0
		Radius parameter.
	fitfunc : {'cos', 'exc'} or Callable, default='exc'
		Fitness function type.
	bounds : scipy.optimize.Bounds or None, default=None
		Boundary constraints.
	position_zero : bool, default=True
		Sets first sensor position to zero.

	Returns
	-------
	scipy.optimize.OptimizeResult
		Optimization result.
	"""
	# params = [f_rot, eccentricity, angle_s1, offset_s1, ..., angle_sN, offset_sN]

	if np.squeeze(y_array).ndim == 1:       # if only one channel,
		y_array = np.reshape(y_array, (-1, 1)) # force 2D column vector

	tol_factor = 50
	if isinstance(fitfunc, str):
		if fitfunc == 'cos':
			fun_de = _fitness_cos
			tol_factor = 150
		elif fitfunc == 'exc':
			fun_de = _fitness_eccenter
		else:
			raise ValueError("Valid values for 'fitfunc' are 'cos', 'exc' or a valid fitness function.")
	else:
		fun_de = fitfunc

	x0 = None
	if bounds is None:                                                          # if no bounds were passed:
		l_bounds, u_bounds, x0 = _bounds_runout_fit(x_vector, y_array, tol_factor) # determine plausible bounds automatically
		bounds = sop.Bounds(lb=l_bounds, ub=u_bounds)                           # and convert to suitable format

	res1 = sop.differential_evolution(fun_de,                               # fit model function:
									  bounds=bounds,                    #   with selected bounds
									  args=(x_vector, y_array, radius), #   and values remaining constant during fit;
									  x0=x0,                                #   initial values, if passed
									  init='sobol',                     #   method for creating initial population; special behavior for 'sobol' see docs;
									  polish=False)                     #   use best individual after evolutionary algorithm
																		#       as starting point for gradient method

	res = sop.least_squares(fun_de,
							bounds=bounds,
							x0=res1.x,
							args=(x_vector, y_array, radius),
							max_nfev=10_000)

	slack = tuple(bounds.residual(res.x))
	if np.any(slack[0] == 0) or np.any(slack[1] == 0):
		logging.warning("One or more position parameters correspond to the solver limit for this parameter.")

	if position_zero:
		res.x[2::2] = np.mod(res.x[2::2] - res.x[2] + (2*np.pi), (2*np.pi)) # Set position of first sensor to zero, subsequent positions relative to it

	return res


def _bounds_runout_fit(x_vector: npt.NDArray[np.float64],
					   y_array: npt.NDArray[np.float64],
					   tol_factor: float = 50,
) -> tuple[npt.NDArray[np.float64], npt.NDArray[np.float64], npt.NDArray[np.float64]]:
	"""Determine boundaries for fitting."""
	# params = [f_rot, eccentricity, angle_s1, offset_s1, ..., angle_sN, offset_sN]
	tukey_alpha = 0.2 # Fraction of Tukey window

	dt = np.float64(np.mean(np.diff(x_vector)))                                 # Sampling time step
	freq = np.fft.rfftfreq(x_vector.size, d=dt).astype(np.float64, copy=False)  # Create frequency line vector
	df = 1 / (x_vector[-1] - x_vector[0])                                       # and determine frequency line spacing from measurement duration

	window = np.atleast_2d(ssig.windows.tukey(x_vector.size, alpha=tukey_alpha, sym=False)).T # Create window
	spectra = np.fft.rfft(y_array * window, axis=0, norm='forward')   # Calculate FFT
	spectra[1:-1, :] = 2 * spectra[1:-1, :]                           # and normalize result (for real input signal)

	f_rot, angle, _ = rotation_spectrum(freq, spectra)  # estimated rotation frequency and sensor angle positions (relative
														# to eccentricity position at start of measurement)
	angle_tol = tol_factor * f_rot * dt * 2 * np.pi     # `tol_factor` times the max angle the axis can rotate between two time steps

	max_exc = 1.1 * np.max(np.abs(np.ptp(y_array, axis=0)) / 2) # eccentricity cannot be larger than max measured magnitude, +10% safety

	percentiles = np.percentile(y_array, [25, 75, 50], axis=0) # static offset of each channel lies in IQR; also median for solver start value

	l_bounds = np.asanyarray([f_rot - df, 0])       # lower bound: determined rotation freq minus freq line spacing; no eccentricity
	u_bounds = np.asanyarray([f_rot + df, max_exc]) # upper bound: f_rot plus freq line spacing; max possible eccentricity
	x0 = np.asanyarray([f_rot, max_exc])            # solver start value

	if y_array.shape[1] == 1: # catch case where no angle can be determined with only one measurement channel
		angle = [np.pi]
		angle_tol = np.pi

	for a in range(y_array.shape[1]):                               # for each channel add its bounds:
		l_bounds = np.append(l_bounds, [angle[a] - angle_tol, percentiles[0, a]]) # lower bound
		u_bounds = np.append(u_bounds, [angle[a] + angle_tol, percentiles[1, a]]) # upper bound
		x0 = np.append(x0, [angle[a], percentiles[2, a]])                         # solver start value

	return l_bounds, u_bounds, x0


@njit(parallel=True, cache=True)
def _fitness_eccenter(params: list[float],
					  x_vector: npt.NDArray[np.float64],
					  y_array: npt.NDArray[np.float64],
					  radius: float,
) -> np.float64:
	"""Calculates fitness for eccentric model."""
	# params = [f_rot, eccentricity, angle_s1, offset_s1, ..., angle_sN, offset_sN]

	ang_freq = 2 * np.pi * params[0]
	exc = params[1]
	sq_radius = np.square(radius)

	error = np.float64(0)
	for p in nbprange(y_array.shape[1]):
		idx_p = np.int_(2 + 2 * p)

		for t in range(x_vector.shape[0]):
			phi = ang_freq * x_vector[t] # Create angle value from estimated parameters
			phi_shifted = phi - params[idx_p] # positive angular position in rotation direction leads to negative phase shift

			k = exc * np.sin(phi_shifted)
			l1 = exc * np.cos(phi_shifted)
			l2 = np.sqrt(sq_radius - np.square(k))
			s = l1 + l2
			delta_s = s - radius + params[idx_p + 1]

			error = error + np.square(y_array[t, p] - delta_s)

	return error


@njit(parallel=True, cache=True)
def _fitness_cos(params: list[float],
				 x_vector: npt.NDArray[np.float64],
				 y_array: npt.NDArray[np.float64],
				 *args,
) -> np.float64:
	"""Computes fitness for cosine model."""
	# params = [f_rot, eccentricity, angle_s1, offset_s1, ..., angle_sN, offset_sN]
	ang_freq = 2 * np.pi * params[0]
	exc = params[1]

	error = np.float64(0)
	for p in nbprange(y_array.shape[1]):
		idx_p = np.int_(2 + 2 * p)

		for t in range(x_vector.shape[0]):
			phi = ang_freq * x_vector[t] # Create angle value from estimated parameters
			phi_shifted = phi - params[idx_p] # positive angular position in rotation direction leads to negative phase shift

			delta_s = exc * np.cos(phi_shifted) + params[idx_p + 1]

			error = error + np.square(y_array[t, p] - delta_s)

	return error
