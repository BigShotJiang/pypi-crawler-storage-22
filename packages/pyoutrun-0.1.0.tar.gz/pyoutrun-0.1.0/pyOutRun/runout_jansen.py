# SPDX-FileCopyrightText: Copyright © 2024-2026 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Functions for performing the Jansen method to determine runout and form deviations."""

import numba as nb
import numpy as np
import numpy.typing as npt
from typing import Literal

from .fft_utils import rfft_tukey_corrected, irfft_corrected

__all__ = ["runout_jansen"]


def runout_jansen(sensor_signals: npt.NDArray[np.float64],
				  sensor_pos: npt.NDArray[np.float64],
				  samples_per_rev: float,
				  orientation: Literal['co', 'counter'] = 'co',
				  f_rot_ignore: bool = False,
				  ) -> tuple[npt.NDArray[np.float64], npt.NDArray[np.float64]]:
	"""
	Calculates eccentricity and form deviations from sensor signals using the Jansen method.

	Parameters
	----------
	sensor_signals : npt.NDArray[np.float64]
		Sensor signals. Each column contains the signal of one sensor.
	sensor_pos : npt.NDArray[np.float64]
		Sensor angular positions in radians.
	samples_per_rev : float
		Number of samples per revolution.
	orientation : {'co', 'counter'}, default='co'
		Direction of the angle vector on the rotating axis.
		'co': Axis rotation angle and sensor position angle point in the same direction.
		'counter': They point in opposite directions.
	f_rot_ignore : bool, default=False
		Ignore radius deviation occurring with period 2π.

	Returns
	-------
	eccentricity : np.ndarray
		x and y coordinates of eccentricity in the angular domain.
	radius_phi : np.ndarray
		Radius deviation in the angular domain.
	"""

	_check_args(**locals())

	if orientation == 'co':
		sensor_signals = np.flipud(sensor_signals)

	sensor_signals = sensor_signals - sensor_signals[0, :]
	spectra, freq = rfft_tukey_corrected(sensor_signals, samples_per_rev, tukey=0.0)
	spectra[0, :] = np.zeros_like(spectra[0, :])

	result = _reference_calculation(freq, spectra, sensor_pos, f_rot_ignore)
	# result, condition = _reference_calculation_fallback(freq, spectra, sensor_pos, f_rot_ignore)

	eccentricity = irfft_corrected(result[:2, :], axis=1).T
	radius_phi = irfft_corrected(result[2, :])

	if orientation == 'co':
		eccentricity = np.flipud(eccentricity)

	return eccentricity, radius_phi  # , condition


@nb.njit(cache=True, parallel=True)
def _reference_calculation(freq: npt.NDArray[np.float64],
						   spectra: npt.NDArray[np.complex128],
						   positions: npt.NDArray[np.float64],
						   f_rot_ignore: bool,
						   ) -> npt.NDArray[np.complex128]:
	"""
	Determines spectra of eccentricity and radius deviation.

	Parameters
	----------
	freq : npt.NDArray[np.float64]
		Harmonic orders (since calculated with samples_per_rev).
	spectra : npt.NDArray[np.complex128]
		Amplitude spectra of sensor signals.
	positions : npt.NDArray[np.float64]
		Sensor angular positions in radians.
	f_rot_ignore : bool
		Ignore 1st harmonic in radius deviation.

	Returns
	-------
	npt.NDArray[np.complex128]
		Spectra of [x-eccentricity, y-eccentricity, radius deviation].
	"""

	pos_vector = np.exp(1j * positions)
	result = np.empty((2, spectra.shape[0]), dtype=np.complex128)

	for f in nb.prange(spectra.shape[0]):
		pos_matrix = np.column_stack((pos_vector,  # own `pos_matrix` for each thread to avoid race conditions
									  np.exp(1j * freq[f] * positions)))

		# Workaround for rank detection; `pos_matrix` usually loses full column rank
		# only for f==1 -> extremely poor condition
		if np.linalg.cond(pos_matrix) > 10000:
			if f_rot_ignore:
				result[:, f] = np.zeros((1, 2), dtype=np.complex128)
				continue
			else:
				# Attribute runout entirely to radius
				pos_matrix[:, 0] = np.zeros(positions.size, dtype=np.complex128)

		# Calculate radius and eccentricity
		sol, _, _, _ = np.linalg.lstsq(pos_matrix, spectra[f, :].T)
		result[:, f] = sol

	return np.vstack((result[0, :], 1j * result[0, :], result[1, :]))


# @nb.njit(cache=True, parallel=False) # DO NOT activate; numba apparently cannot determine rank correctly
def _reference_calculation_fallback(freq: npt.NDArray[np.float64],
									spectra: npt.NDArray[np.complex128],
									positions: npt.NDArray[np.float64],
									f_rot_ignore: bool = False,
									) -> tuple[npt.NDArray[np.complex128], npt.NDArray[np.float64]]:
	"""
	Determines spectra of eccentricity and radius deviation.
	Alternative function with explicit calculation and output of the condition number.
	"""

	pos_matrix = np.ones((positions.size, 2), dtype=np.complex128)
	pos_matrix[:, 0] = np.exp(1j * positions)

	result = np.zeros((2, spectra.shape[0]), dtype=np.complex128)
	condition = np.zeros(spectra.shape[0])

	for f in range(spectra.shape[0]):
		pos_matrix[:, 1] = np.exp(1j * freq[f] * positions)
		condition[f] = np.linalg.cond(pos_matrix)

		result[:, f], _, rank, _ = np.linalg.lstsq(pos_matrix, spectra[f, :].T)

		# pos_matrix might not lose full column rank because f is not exactly 1, but is extremely ill-conditioned
		if (rank < 2) | (condition[f] > 10000):
			if f_rot_ignore:
				result[:, f] = np.zeros((1, 2), dtype=np.complex128)  # Overwrite result with 0
			else:
				pos_matrix[:, 0] = np.zeros(positions.size, dtype=np.complex128)  # Attribute runout entirely to radius
				result[:, f], *_ = np.linalg.lstsq(pos_matrix, spectra[f, :].T)

				pos_matrix[:, 0] = np.exp(1j * positions)  # Restore pos_matrix to original state

	return np.vstack((result[0, :], 1j * result[0, :], result[1, :])), condition


def _check_args(**kwargs):
	assert "sensor_pos" in kwargs
	assert "sensor_signals" in kwargs
	assert "orientation" in kwargs

	if not (kwargs["sensor_pos"].size in kwargs["sensor_signals"].shape):
		raise ValueError('Number of channels in "sensor_signals" and "sensor_pos" do not match.')
	if not kwargs["orientation"] in ['co', 'counter']:
		raise ValueError('Valid values for "orientation" are "co" or "counter".')
	if kwargs["sensor_signals"].ndim != 2:
		raise ValueError('"sensor_signals" must be an (M,N) ndarray.')
	if np.min(kwargs["sensor_signals"].shape) < 3:
		raise ValueError('"sensor_signals" must contain at least three channels.')
