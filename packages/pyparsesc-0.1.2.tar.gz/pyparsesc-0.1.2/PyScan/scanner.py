class Scan:
    def __init__(self, text: str):
        self.text = text
        self.lines = [l.strip() for l in text.splitlines() if l.strip()]
        self.config = {}

    def cfg(self, startdic=":", enddic="end", define="NAME=VALUE"):
        self.config = {
            "start": startdic,
            "end": enddic,
            "define": define
        }

    def parse(self):
        result = {}
        current_block = None

        for line in self.lines:
            # início de bloco
            if line.endswith(self.config["start"]):
                block_name = line[:-1]
                result[block_name] = {}
                current_block = block_name
                continue

            # fim de bloco
            if line == self.config["end"]:
                current_block = None
                continue

            # definição NAME=VALUE
            if current_block and "=" in line:
                name, value = line.split("=", 1)
                result[current_block][name.strip()] = value.strip()

        return result