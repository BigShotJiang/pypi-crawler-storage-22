class Tool:
  @staticmethod
  def nothere():
    print("Not Here")
        