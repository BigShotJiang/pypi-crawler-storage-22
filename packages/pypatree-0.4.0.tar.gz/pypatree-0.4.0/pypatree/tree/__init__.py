import logging
from typing import Any, Optional

from pypatree.introspection import get_module_items

log = logging.getLogger(__name__)

Tree = dict[str, Any]


def get_subtree(tree: Tree, path: list[str]) -> Optional[Tree]:
    """Navigate to a subtree by path components. Returns None if not found."""
    node = tree
    for part in path:
        if part not in node:
            return None
        node = node[part]
    return node


def build_tree(
    submods: list[str],
    pkg_name: str,
    exclude: Optional[str],
    show_defaults: bool,
) -> Tree:
    """Build nested tree from flat module list."""
    log.debug("Building tree for %s from %d submodules", pkg_name, len(submods))
    tree: Tree = {}

    for modname in sorted(submods):
        if modname == pkg_name:
            tree["__items__"] = get_module_items(
                modname, exclude=exclude, show_defaults=show_defaults
            )
            continue

        parts = modname[len(pkg_name) + 1 :].split(".")
        node = tree
        for part in parts:
            node = node.setdefault(part, {})
        node["__items__"] = get_module_items(
            modname, exclude=exclude, show_defaults=show_defaults
        )

    log.debug("Tree built with %d top-level entries", len(tree))
    return tree
