import instructor
from openai import OpenAI
import os

from phi.config import get_api_key, load_or_init_config
from phi.agent.schema import CommandPlan

from phi.prompts.system_prompt import prompt_v2


def format_tools(tools: list[dict]) -> str:
    if not tools:
        return "None"

    return "\n".join(
        f"- {t['name']}: {t['description']}"
        for t in tools
    )


def get_cmd(instruction: str) -> CommandPlan:
    # Load persisted user config
    config = load_or_init_config()
    tools_context = format_tools(config.get("preferred_tools", []))

    # Create Instructor-wrapped OpenAI client
    provider, api_key = get_api_key()
    client = instructor.from_openai(
        OpenAI(api_key=api_key)
    )

    system_prompt = prompt_v2.format(
        os=config["os"],
        shell=config["shell"],
        preferred_tools=config["preferred_tools"] or "None"
    )
    

    plan = client.chat.completions.create(
        model="gpt-4o-mini",
        response_model=CommandPlan,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": instruction}
        ],
        temperature=0
    )

    return plan