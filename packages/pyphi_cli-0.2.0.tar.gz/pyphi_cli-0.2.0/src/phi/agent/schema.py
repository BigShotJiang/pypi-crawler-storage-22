from pydantic import BaseModel, Field
from typing import List, Literal, Optional


RiskLevel = Literal["low", "medium", "high"]


class ShellCommand(BaseModel):
    command: str = Field(
        ...,
        description="A valid shell command"
    )
    risk: RiskLevel = Field(
        ...,
        description="Risk level of executing this command"
    )
    requires_confirmation: bool = Field(
        ...,
        description="Whether user confirmation is required before execution"
    )
    reason: Optional[str] = Field(
        None,
        description="Short explanation of why this command is risky"
    )


class CommandPlan(BaseModel):
    commands: List[ShellCommand]