import json
import os
import platform
from pathlib import Path

def get_config_path() -> Path:
    if platform.system() == "Windows":
        base = Path(os.environ["APPDATA"])
    else:
        base = Path.home() / ".config"

    return base / "phi" / "config.json"


def load_or_init_config() -> dict:
    path = get_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    if path.exists():
        return json.loads(path.read_text())

    config = {
        "os": platform.system(),
        "shell": os.environ.get("SHELL", "sh"),
        "provider": "openai",
        "preferred_tools": []
    }

    path.write_text(json.dumps(config, indent=2))
    return config

def get_api_key():
    if os.getenv("OPENAI_API_KEY"):
        return ("openai", os.getenv("OPENAI_API_KEY"))
    if os.getenv("ANTHROPIC_API_KEY"):
        return ("anthropic", os.getenv("ANTHROPIC_API_KEY"))
    if os.getenv("GEMINI_API_KEY"):
        return ("gemini", os.getenv("GEMINI_API_KEY"))
    raise RuntimeError("No API key found. Set OPENAI_API_KEY / ANTHROPIC_API_KEY / GEMINI_API_KEY")