import sys
from phi.agent.entry import get_cmd
from phi.run import run_cmd
from phi.config import load_or_init_config

def main():
    config = load_or_init_config()
    if len(sys.argv) < 2:
        print("Usage: phi <natural language>")
        raise SystemExit(1)

    instruction = " ".join(sys.argv[1:])
    plan = get_cmd(instruction)
    run_cmd(plan)