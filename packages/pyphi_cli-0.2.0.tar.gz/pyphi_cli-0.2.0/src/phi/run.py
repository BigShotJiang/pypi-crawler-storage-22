import subprocess
from phi.agent.schema import CommandPlan
from gleam import print, print_error

def run_cmd(plan: CommandPlan):
    for i, step in enumerate(plan.commands, start=1):
        print(f"\n→ Step {i}: {step.command}")

        if step.requires_confirmation:
            print(f"⚠️  Risk level: {step.risk}")
            if step.reason:
                print(f"Reason: {step.reason}")

            answer = input("Run anyway? (y/N): ")
            if answer.lower() != "y":
                raise RuntimeError("Command aborted by user")

        result = subprocess.run(
            step.command,
            shell=True,
            text=True,
            capture_output=True
        )

        if result.stdout:
            print(result.stdout)

        if result.returncode != 0 and result.stderr.strip():
            print_error(result.stderr)