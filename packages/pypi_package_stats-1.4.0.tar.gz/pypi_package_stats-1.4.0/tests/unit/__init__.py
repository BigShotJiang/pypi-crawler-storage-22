"""Unit tests for pypi-package-stats."""
