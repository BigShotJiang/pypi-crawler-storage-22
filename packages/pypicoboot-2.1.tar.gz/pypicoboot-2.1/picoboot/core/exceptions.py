"""
/*
 * This file is part of the pypicoboot distribution (https://github.com/polhenarejos/pypicoboot).
 * Copyright (c) 2025 Pol Henarejos.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */
"""


class PicoBootError(Exception):
    pass

class PicoBootNotFoundError(PicoBootError):
    pass

class PicoBootInvalidStateError(PicoBootError):
    pass


class EspBootError(Exception):
    pass

class EspBootNotFoundError(EspBootError):
    pass

class EspBootInvalidStateError(EspBootError):
    pass
