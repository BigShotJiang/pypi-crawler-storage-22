
Contrib + Core access
=====================

Inside of your app you can access the instance and it's contribution- and core components.
To access the instance you can simply use this code statement:

.. code-block:: python

  self.instance

From there you can access most of the controllers components.
For the full list of the properties of the ``instance`` class. Look at :doc:`Instance Class </api/core_instance>`
