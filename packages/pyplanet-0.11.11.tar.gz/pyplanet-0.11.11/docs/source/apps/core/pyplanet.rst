PyPlanet Core/Toolbox
=====================

Information
-----------
Name:
  ``pyplanet.apps.core.pyplanet``
Depends on:
  -
Game:
  -

Features
--------
This app does some of the core things of the controller.
It also provides the toolbox and several build-in views. To disable the player toolbar, edit //settings.
