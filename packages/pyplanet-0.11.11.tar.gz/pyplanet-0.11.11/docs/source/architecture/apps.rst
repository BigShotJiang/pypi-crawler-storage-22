
Apps Architecture
-----------------

More information about the apps itself, please go to :doc:`Apps Dev Documentation </apps/index>`

..  image:: /_static/apps/architecture.png
