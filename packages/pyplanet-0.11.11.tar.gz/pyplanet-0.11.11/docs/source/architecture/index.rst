
Architecture & Design
=====================

.. contents::

.. include:: core.rst
.. include:: apps.rst
