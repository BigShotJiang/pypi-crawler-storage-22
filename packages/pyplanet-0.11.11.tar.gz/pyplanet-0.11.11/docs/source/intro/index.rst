
==============================
Getting Started (installation)
==============================

.. toctree::
  :glob:
  :maxdepth: 1

  requirements
  installation-linux
  installation-windows
