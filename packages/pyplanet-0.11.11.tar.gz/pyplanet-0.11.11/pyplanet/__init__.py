"""
PyPlanet, a robust and simple Maniaplanet Server Controller for Python 3.6+.
Please see LICENSE file in root of project.
"""
__version__ = '0.11.11'
__author__ = 'Tom Valk'
