from . import CurrentCPs as RealCurrentCPs

CurrentCPs = RealCurrentCPs
