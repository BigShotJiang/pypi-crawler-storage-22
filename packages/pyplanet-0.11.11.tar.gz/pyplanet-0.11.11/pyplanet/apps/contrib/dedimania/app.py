
from . import Dedimania as RealDedimania

Dedimania = RealDedimania
