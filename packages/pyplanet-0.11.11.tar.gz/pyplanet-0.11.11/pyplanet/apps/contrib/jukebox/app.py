
from . import Jukebox as RealJukebox

Jukebox = RealJukebox
