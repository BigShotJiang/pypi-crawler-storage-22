
from . import Karma as RealKarma

Karma = RealKarma
