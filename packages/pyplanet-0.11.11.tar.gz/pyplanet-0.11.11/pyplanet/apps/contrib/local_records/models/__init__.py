from .local_record import LocalRecord

__all__ = [
	'LocalRecord',
]
