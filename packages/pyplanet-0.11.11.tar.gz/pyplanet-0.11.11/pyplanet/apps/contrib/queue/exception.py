
class PlayerAlreadyInQueue(Exception):
	"""
	The player is already in the queue!
	"""
	pass
