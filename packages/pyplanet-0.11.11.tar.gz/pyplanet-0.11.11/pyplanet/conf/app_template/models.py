"""
{{ app_name }} Models.
"""

