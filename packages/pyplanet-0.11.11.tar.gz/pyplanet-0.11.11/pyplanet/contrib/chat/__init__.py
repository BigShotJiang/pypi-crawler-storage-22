"""
The chat contrib makes it possible to send chat messages way more easy and faster. It also maintains some other features
related to the chat.
"""
from .manager import ChatManager

__all__ = [
	'ChatManager'
]
