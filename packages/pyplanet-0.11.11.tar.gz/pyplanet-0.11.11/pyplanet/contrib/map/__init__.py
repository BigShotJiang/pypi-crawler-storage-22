"""
The map contrib will provide map list and information to the apps and core.
"""
from .manager import MapManager

__all__ = [
	'MapManager',
]
