"""
The player contrib will provide player list and information to the apps and core.
"""
from .manager import PlayerManager

__all__ = [
	'PlayerManager'
]
