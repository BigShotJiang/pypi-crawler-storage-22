"""
Exceptions for Map Manager.
"""

class PlayerNotFound(Exception):
	"""Player not found"""
