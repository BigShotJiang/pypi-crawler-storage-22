
from .manialink import StaticManiaLink, DynamicManiaLink

__all__ = [
	'StaticManiaLink',
	'DynamicManiaLink',
]
