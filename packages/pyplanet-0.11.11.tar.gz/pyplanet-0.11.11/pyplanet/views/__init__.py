from .base import View
from .template import TemplateView

__all__ = [
	'View',
	'TemplateView'
]
