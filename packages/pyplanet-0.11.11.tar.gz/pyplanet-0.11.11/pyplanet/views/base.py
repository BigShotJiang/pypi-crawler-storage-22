from pyplanet.core.ui.components.manialink import StaticManiaLink


class View(StaticManiaLink):
	"""
	Base view. The base view will inherit from ``StaticManiaLink`` class.
	"""
	pass
