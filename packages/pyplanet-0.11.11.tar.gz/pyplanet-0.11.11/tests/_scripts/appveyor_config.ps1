new-item -Name settings -ItemType directory
copy tests\_scripts\appveyor\settings\* settings
