# PyPNM database
Data model and persistence strategy for PyPNM (if applicable).
