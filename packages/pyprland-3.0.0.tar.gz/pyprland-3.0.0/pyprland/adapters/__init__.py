"""Adapter functions for pyprland."""

from .proxy import BackendProxy

__all__ = ["BackendProxy"]
