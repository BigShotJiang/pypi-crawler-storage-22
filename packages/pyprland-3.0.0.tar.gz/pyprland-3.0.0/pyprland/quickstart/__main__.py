"""Allow running the quickstart wizard as a module."""

from pyprland.quickstart import main

if __name__ == "__main__":
    main()
