"""Package version."""

VERSION = "3.0.0"
