# pyproject-fmt

[![PyPI](https://img.shields.io/pypi/v/pyproject-fmt?style=flat-square)](https://pypi.org/project/pyproject-fmt)
[![PyPI - Implementation](https://img.shields.io/pypi/implementation/pyproject-fmt?style=flat-square)](https://pypi.org/project/pyproject-fmt)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyproject-fmt?style=flat-square)](https://pypi.org/project/pyproject-fmt)
[![Downloads](https://static.pepy.tech/badge/pyproject-fmt/month)](https://pepy.tech/project/pyproject-fmt)
[![PyPI - License](https://img.shields.io/pypi/l/pyproject-fmt?style=flat-square)](https://opensource.org/licenses/MIT)
[![Build pyproject-fmt](https://github.com/tox-dev/toml-fmt/actions/workflows/pyproject_fmt_build.yaml/badge.svg)](https://github.com/tox-dev/toml-fmt/actions/workflows/pyproject_fmt_build.yaml)
[![Test pyproject-fmt](https://github.com/tox-dev/toml-fmt/actions/workflows/pyproject_fmt_test.yaml/badge.svg)](https://github.com/tox-dev/toml-fmt/actions/workflows/pyproject_fmt_test.yaml)
[![Documentation
status](https://readthedocs.org/projects/tox-toml-fmt/badge/?version=latest)](https://tox-toml-fmt.readthedocs.io/en/latest/)
