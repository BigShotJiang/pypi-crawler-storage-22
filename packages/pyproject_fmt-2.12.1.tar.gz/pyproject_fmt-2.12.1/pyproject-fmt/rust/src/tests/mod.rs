mod build_systems_tests;
mod dependency_groups_tests;
mod global_tests;
mod main_tests;
mod project_tests;
mod ruff_tests;
