"""Version information for pyptine package."""

__version__ = "0.3.2"
