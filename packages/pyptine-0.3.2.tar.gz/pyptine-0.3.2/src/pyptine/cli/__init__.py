"""Command-line interface for pyptine."""

from pyptine.cli.main import cli

__all__ = ["cli"]
