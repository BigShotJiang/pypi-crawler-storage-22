"""Search and discovery functionality for pyptine."""

from pyptine.search.catalog import CatalogueBrowser

__all__ = ["CatalogueBrowser"]
