Architecture Documentation
==========================

This section contains detailed architecture documentation for pyqt-reactive's
core systems and design patterns.

Core Form System
----------------

.. toctree::
   :maxdepth: 1

   parameter_form_service_architecture
   parameter_form_lifecycle
   parametric_widget_creation
   widget_protocol_system
   field_change_dispatcher
   tabbed_form_registry_pattern

Service Layer
-------------

.. toctree::
   :maxdepth: 1

   ui_services_architecture
   service-layer-architecture
   service_registry
   scope_window_factory
   server_scanning_and_polling

Widget Components
-----------------

.. toctree::
   :maxdepth: 1

   abstract_manager_widget
   abstract_table_browser
   zmq_server_browser_widget
   tree_state_sync_system
   button_panel
   list_item_preview_system
   scope_visual_feedback_system
   styling_architecture
   system_monitor

Animation & Performance
-----------------------

.. toctree::
   :maxdepth: 1

   flash_animation_system
   flash_callback_system
   gui_performance_patterns
   cross_window_update_optimization
   tree_aggregation_strategy

Utility Systems
----------------

.. toctree::
   :maxdepth: 1

   log_viewer_system
   system_monitor_core
   persistent_system_monitor
