from __future__ import annotations
__all__: list[str] = list()
__version__: str = '0.2.0.dev0'
