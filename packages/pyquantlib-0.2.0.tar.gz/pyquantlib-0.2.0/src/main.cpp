/*
 * PyQuantLib: Python bindings for QuantLib
 * https://github.com/quantales/pyquantlib
 *
 * Copyright (c) 2025 Yassine Idyiahia
 * SPDX-License-Identifier: BSD-3-Clause
 * See LICENSE for details.
 *
 * ---
 * QuantLib is Copyright (c) 2000-2025 The QuantLib Authors
 * https://www.quantlib.org/
 */

#include <ql/version.hpp>
#include <ql/errors.hpp>
#include <pybind11/pybind11.h>
#include "pyquantlib/version.h"
#include "pyquantlib/pyquantlib.h"
#include "pyquantlib/binding_manager.h"

namespace py = pybind11;

PYBIND11_MODULE(_pyquantlib, m) {
    // Module metadata
    m.doc() = "PyQuantLib: Python bindings for QuantLib";
    m.attr("__version__") = PYQUANTLIB_VERSION;
    m.attr("QL_VERSION") = QL_VERSION;
    m.attr("QL_VERSION_HEX") = QL_HEX_VERSION;
    m.attr("BOOST_VERSION") = QuantLib::compiledBoostVersion();

    // Pybind11 exception translation for QuantLib exceptions
    py::register_exception<QuantLib::Error>(m, "Error");

    // Initialize binding manager
    BindingManager manager(m, "pyquantlib");

    submodules_bindings(manager);        // Creates "base" submodule
    patterns_bindings(manager);          // Observer/Observable pattern
    utilities_bindings(manager);         // Utility classes
    time_bindings(manager);              // Date, Calendar, Period, etc.
    math_bindings(manager);              // Array, Matrix, math functions
    core_bindings(manager);              // Constants, Settings, etc.
    quotes_bindings(manager);            // Quote implementations
    currencies_bindings(manager);        // Currency definitions
    cashflows_bindings(manager);         // Cash flow implementations
    indexes_bindings(manager);           // Index implementations
    termstructures_bindings(manager);    // Term structure implementations
    processes_bindings(manager);         // Stochastic process implementations
    models_bindings(manager);            // Pricing models
    instruments_bindings(manager);       // Financial instruments
    methods_bindings(manager);           // Numerical methods
    pricingengines_bindings(manager);    // Pricing engines
    experimental_bindings(manager);      // Experimental features

    // Finalize all bindings
    manager.finalize();

}
