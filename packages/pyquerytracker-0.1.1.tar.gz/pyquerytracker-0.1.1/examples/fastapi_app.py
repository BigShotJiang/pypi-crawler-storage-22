import asyncio
import random
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pyquerytracker import monitor_queries, configure, StatsCollector

# Initialize StatsCollector globally
stats_collector = StatsCollector()

# Configure pyquerytracker
configure(
    default_threshold_ms=500,  # Set threshold to 500ms
    json_export_enabled=True,
    json_export_path="query_stats.json"
)

app = FastAPI(title="PyQueryTracker Demo")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@monitor_queries(threshold_ms=300)
async def fast_query():
    """A query that should be under threshold"""
    await asyncio.sleep(0.1)  # 100ms
    return {"status": "success", "message": "Fast query completed"}

@monitor_queries(threshold_ms=300)
async def slow_query():
    """A query that should exceed threshold"""
    await asyncio.sleep(0.4)  # 400ms
    return {"status": "success", "message": "Slow query completed"}

@monitor_queries(threshold_ms=300)
async def error_query():
    """A query that will raise an error"""
    await asyncio.sleep(0.2)  # 200ms
    raise HTTPException(status_code=500, detail="Simulated error")

@app.get("/fast")
async def get_fast():
    """Endpoint that executes a fast query"""
    try:
        result = await fast_query()
        return JSONResponse(
            content=result,
            media_type="application/json"
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"error": str(e)},
            media_type="application/json"
        )

@app.get("/slow")
async def get_slow():
    """Endpoint that executes a slow query"""
    try:
        result = await slow_query()
        return JSONResponse(
            content=result,
            media_type="application/json"
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"error": str(e)},
            media_type="application/json"
        )

@app.get("/error")
async def get_error():
    """Endpoint that executes a query that will error"""
    try:
        await error_query()
    except HTTPException as e:
        return JSONResponse(
            status_code=e.status_code,
            content={"error": e.detail},
            media_type="application/json"
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"error": str(e)},
            media_type="application/json"
        )

@app.get("/random")
async def get_random():
    """Endpoint with random response time"""
    try:
        delay = random.uniform(0.1, 0.5)
        await asyncio.sleep(delay)
        return JSONResponse(
            content={
                "status": "success",
                "message": f"Random query completed in {delay:.2f}s"
            },
            media_type="application/json"
        )
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"error": str(e)},
            media_type="application/json"
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080) 