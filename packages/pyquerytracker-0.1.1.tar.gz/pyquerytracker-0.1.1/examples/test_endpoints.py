import asyncio
import aiohttp
import time
from pyquerytracker.cli import report
from pyquerytracker.decorator import monitor_queries

async def test_endpoint(session: aiohttp.ClientSession, endpoint: str, expected_status: int = 200) -> None:
    """Test an endpoint and print the result"""
    try:
        async with session.get(f"http://localhost:8000{endpoint}") as response:
            if response.status == expected_status:
                data = await response.json()
                print(f"Success testing {endpoint}: {data}")
            else:
                error_text = await response.text()
                print(f"Error testing {endpoint}: {response.status}, {error_text}")
    except Exception as e:
        print(f"Error testing {endpoint}: {str(e)}")

@monitor_queries(name="test_fast")
async def test_fast(session: aiohttp.ClientSession) -> None:
    """Test the fast endpoint"""
    await test_endpoint(session, "/fast")

@monitor_queries(name="test_slow")
async def test_slow(session: aiohttp.ClientSession) -> None:
    """Test the slow endpoint"""
    await test_endpoint(session, "/slow")

@monitor_queries(name="test_error")
async def test_error(session: aiohttp.ClientSession) -> None:
    """Test the error endpoint"""
    await test_endpoint(session, "/error", expected_status=500)

@monitor_queries(name="test_random")
async def test_random(session: aiohttp.ClientSession) -> None:
    """Test the random endpoint"""
    await test_endpoint(session, "/random")

async def main():
    """Main test function"""
    async with aiohttp.ClientSession() as session:
        # Test fast endpoint multiple times
        for _ in range(15):
            await test_fast(session)
        
        # Test random endpoint
        for _ in range(10):
            await test_random(session)
        
        # Test error endpoint
        for _ in range(15):
            await test_error(session)
        
        # Test random endpoint again
        for _ in range(10):
            await test_random(session)
        
        # Test slow endpoint
        for _ in range(20):
            await test_slow(session)
        
        # Test random endpoint one more time
        for _ in range(10):
            await test_random(session)

if __name__ == "__main__":
    # Run tests
    asyncio.run(main())
    
    # Generate report
    print("\nGenerating statistics report...")
    report() 