# Quipu 系统全局常量规范

# Git 空树的哈希值，作为所有历史图谱的绝对起点 (Genesis)
EMPTY_TREE_HASH = "4b825dc642cb6eb9a060e54bf8d69288fbee4904"
