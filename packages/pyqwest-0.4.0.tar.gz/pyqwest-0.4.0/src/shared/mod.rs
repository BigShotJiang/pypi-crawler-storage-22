/// Backoff utility for retry middleware.
pub(crate) mod backoff;
/// Shared utilities for bytes buffers.
pub(crate) mod buffer;
/// Shared constants.
pub(crate) mod constants;
/// Shared utilities for `OTel` instrumentation.
pub(crate) mod otel;
/// Shared utilities for request handling.
pub(crate) mod request;
/// Shared utilities for response handling.
pub(crate) mod response;
/// Shared utilities for creating transports.
pub(crate) mod transport;
/// Shared utilities for validating arguments.
pub(crate) mod validation;
