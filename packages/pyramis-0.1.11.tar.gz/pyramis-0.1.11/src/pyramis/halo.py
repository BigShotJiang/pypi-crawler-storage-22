import os
import pickle as pkl

from san_scripts.misc.yzics_ht import halo
from . import config
from .utils.fortranfile import FortranFile

def _get_halomaker_struct(double_precision=True):
    ftype = 'f8' if double_precision else 'f4'
    return [
        ('nparts', 'i4'), ('id', 'i4'), ('timestep', 'i4'), ('level', 'i4'),
        ('host', 'i4'), ('hostsub', 'i4'), ('nbsub', 'i4'), ('nextsub', 'i4'),
        ('aexp', ftype), ('m', ftype), ('x', ftype), ('y', ftype), ('z', ftype),
        ('vx', ftype), ('vy', ftype), ('vz', ftype),
        ('Lx', ftype), ('Ly', ftype), ('Lz', ftype),
        ('r', ftype), ('a', ftype), ('b', ftype), ('c', ftype),
        ('ek', ftype), ('ep', ftype), ('et', ftype), ('spin', ftype),
        ('sigma', ftype), ('rvir', ftype), ('mvir', ftype), ('tvir', ftype), ('cvel', ftype),
        ('rho0', ftype), ('rc', ftype)]

def _get_galaxymaker_struct(double_precision=True, profile=True, nbin=10):
    ftype = 'f8' if double_precision else 'f4'
    struct = _get_halomaker_struct(double_precision) + [
        ('sigma_bulge', ftype), ('m_bulge', ftype)]
    if profile:
        struct += [('nbin', 'i4'), ('rbin', ftype, (nbin,)), ('rho', ftype, (nbin,))]
    return struct


def read_halomaker(path: str, iout:int | None=None, galaxy=False, double_precision: bool=True):
    if halo:

    def _read_halo(row, f: FortranFile):
        
        

    if iout is not None:
        if galaxy:
            path = os.path.join(path, config['FILENAME_FORMAT_GALAXYMAKER'].format(iout=iout))
        else:
            path = os.path.join(path, config['FILENAME_FORMAT_HALOMAKER'].format(iout=iout))
    
    with FortranFile(path, 'r') as f:
        nbodies = f.read_ints('i4')
        massp = f.read_reals('f4')
        if double_precision:
            aexp = f.read_reals('f8')
        else:
            aexp = f.read_reals('f4')
        
        omega_t = f.read_reals('f4')
        age_univ = f.read_reals('f4')
        nb_of_halos, nb_of_subhalos = f.read_ints('i4')
        nhalo_snap = nb_of_halos + nb_of_subhalos

        for i in range(nhalo_snap):
            _read_halo(f)



def read_ptree(path: str, iout:int | None=None, all=False):
    if iout is not None:
        path = os.path.join(path, config['FILENAME_FORMAT_PTREE'].format(iout=iout))
    return pkl.load(open(path, "rb"))