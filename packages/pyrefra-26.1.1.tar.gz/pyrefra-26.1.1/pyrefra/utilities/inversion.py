# -*- coding: utf-8 -*-
"""
Created on Wed Sep  3 18:56:39 2025

@author: Hermann
"""

import os
from PyQt5 import QtWidgets
import matplotlib.pyplot as plt
from matplotlib import colors
from matplotlib.gridspec import GridSpec
from matplotlib.path import Path
from mpl_toolkits.axes_grid1 import make_axes_locatable
import colorcet as cc
import numpy as np

from ..plotting.refraPlot import newWindow


class Inversion():

    def __init__(self, main):
        self.main = main
        self.traces = main.traces
        try:
            from pygimli.physics import TravelTimeManager
        except ModuleNotFoundError:
            _ = QtWidgets.QMessageBox.warning(
                None, "Warning", "Pygimli is not installed.\n "
                + "Tomography cannot be executed.\n",
                QtWidgets.QMessageBox.Close, QtWidgets.QMessageBox.Close)
            return

        answer = self.main.test_function()
        if not answer:
            return
        try:
            import pygimli as pg
        except ModuleNotFoundError:
            _ = QtWidgets.QMessageBox.warning(
                None, "Warning", "PyGimli is not installed\n"
                + "Tomography connot be executed\n", QtWidgets.QMessageBox.Ok,
                QtWidgets.QMessageBox.Ok)
            return
        self.pg = pg
        self.TT = TravelTimeManager
# Store picks in Gimli format (picks.sgt)
        self.traces.saveGimli()

    def vel_scale(self, ncol=128, scale="specialP"):
        if "special" in scale:
            cmp = colors.LinearSegmentedColormap.from_list(
                'velocities',
                ['violet', 'darkgreen', 'forestgreen', 'cyan', 'blue',
                 'springgreen', 'lime', 'greenyellow', 'yellow', 'yellow',
                 'gold', 'orange', 'orangered', 'red'], N=ncol)
        elif "rainbow" in scale:
            cmp = cc.cm.rainbow4
        else:
            cmp = plt.get_cmap(scale)

        cmp.set_under('pink')
        cmp.set_over('darkred')
        cols = cmp(np.linspace(0, 1, ncol))
        return cmp, cols

    def tick_size(self):
        self.tick_size_mod = 12
        self.tick_size_sec = 8

    def run(self, code=0):
        """
        Function uses Pygimly for tomography inversion.

        For nicer plots, modify numbering format in drawDataMatrix
        The function is found in file
        Environment_path/Lib/site-packages/pygimli/viewer/mpl
        For me, Environment path is C:/Users/Hermann/anaconda3/
        There go to lines 458 and 462 starting with
        ax.set_xticklabels and
        ax.set_yticklabels
        and change the rounding to 0 ciphers instead of the default 2 ciphers

        Needs:
        pygimli.physics.TravelTimeManager
        matplotlib as mpl
        matplotlib.gridspec.GridSpec
        matplotlib.path.Path
        matplotlib.tri
        mpl_toolkits.axes_grid1.make_axes_locatable
        copy
        matplotlib.pyplot as plt
        colorcet as cc

        Returns
        -------
        None.

        """

# If code == 0, color scale and maximum depth for model plot are calculated
#    automatically
# scheme contains the coordinates of shot and receiver points as  well as the
# measured travel times in seconds.
# scheme("s").array() gives the numbers of the shot points for every pick
# scheme("g").array() gives the numbers of the receiver points for every pick
# scheme("t").array() gives the measured travel times
# scheme("err").array() gives the travel time uncertainties
# scheme.sensors().array() gives a numpy array with 3 colums containing the
#       coordinates of all sensors and shots ordered by position.
        if code == 0:
            self.scheme = self.pg.load("picks.sgt", verbose=True)
            self.px = self.pg.x(self.scheme)
            self.gx = np.asarray([self.px[g] for g in self.scheme.id("g")])
            self.sx = np.asarray([self.px[s] for s in self.scheme.id("s")])
            self.sens = np.array(self.scheme.sensors().array(), dtype=float)
            self.offsets =\
                self.pg.physics.traveltime.shotReceiverDistances(self.scheme)
            self.zmax = np.round(np.max(self.offsets)*0.333)
            gx_min = self.gx.min()
            gx_max = self.gx.max()
            sx_min = self.sx.min()
            sx_max = self.sx.max()
            self.xax_min = min(gx_min, sx_min)
            self.xax_max = max(gx_max, sx_max)
# Call dialog window for input of a number of inversion control parameters
            results, okButton = self.main.dialog(
                    ["Maximum depth (m, positive down)",
                     "Initial smoothing parameter (<0: optimize)",
                     "Smoothing reduction per iteration",
                     "Smoothing in z direction (0...1):",
                     "Maximum iterations (0 = automatic)",
                     "Initial velocity at surface [m/s]",
                     "Initial velocity at bottom [m/s]",
                     "Minimum allowed velocity [m/s]",
                     "Maximum allowed velocity [m/s]",
                     "\nIf min or max is 0, the corresponding limit\n"
                     + " of the color scale is calculated automatically\n",
                     "Velocity color scale min [m/s]",
                     "Velocity color scale max [m/s]",
                     "Type of color scale:",
                     self.model_colors,
                     "Plot rays on final model"],
                    ["e", "e", "e", "e", "e", "e", "e", "e", "e", "l", "e",
                     "e", "l", "b", "c"],
                    [self.zmax, self.smooth, self.s_fact, self.zSmooth,
                     self.maxiter, self.vmin, self.vmax, self.vmin_limit,
                     self.vmax_limit, None, self.v_scale_min, self.v_scale_max,
                     None, None, None], "Inversion parameters")

            if not okButton:
                print("\n Inversion cancelled")
                self.main.function = "main"
                return

            self.zmax = float(results[0])
            self.smooth = float(results[1])
            if self.smooth < 0:
                opt_flag = True
                self.smooth *= -1.
            else:
                opt_flag = False
            self.s_fact = float(results[2])
            self.zSmooth = float(results[3])
            self.maxiter = int(results[4])
# Avoid maximum number of iteration being 1, since this would not produce a
#   final model (self.endModel is empty). It seems that pygimli counts the
#   forward calculation of the starting model as first iteration.
            if self.maxiter > 0:
                self.maxiter = max(self.maxiter, 2)
            else:
                self.maxiter = 0
            self.vmin = float(results[5])
            self.vmax = float(results[6])
            self.vmin_limit = float(results[7])
            self.vmax_limit = float(results[8])
            try:
                self.v_scale_min = float(results[10])
                self.v_scale_max = float(results[11])
            except IndexError:
                self.v_scale_min = 150
                self.v_scale_max = 6000
            color_scale = self.model_colors[int(results[13])]
            if "Special" in color_scale:
                if "1500" in color_scale:
                    color_scale = "specialP"
                else:
                    color_scale = "specialS"
            if int(results[14]) > -1:
                self.rays_flag = True
            else:
                self.rays_flag = False

# Initialize PyGimli TravelTime Manager and set control parameters
            self.mgr = self.pg.physics.TravelTimeManager()
            if opt_flag:
                self.mgr.inv.inv.setOptimizeLambda(True)
# Do tomography inversion. If maxiter == 0, stop iterationautomatically if
# chi2<1 of if error does not decrease by more than 1% (dPhi=0.01) if
# maxiter>0 stop iterations latest after maxiter iterations (but earlier if
# one of the other conditions is fulfilled)
            if self.maxiter < 1:
                if self.vmin_limit == 0 and self.vmax_limit == 0:
                    self.mgr.invert(
                        self.scheme, secNodes=3, paraMaxCellSize=5.0,
                        zWeight=self.zSmooth, vTop=self.vmin,
                        vBottom=self.vmax, verbose=1, paraDepth=self.zmax,
                        dPhi=0.01, lam=self.smooth, lambdaFactor=self.s_fact,
                        maxIter=1000)
                else:
                    self.mgr.invert(
                        self.scheme, secNodes=3, paraMaxCellSize=5.0,
                        zWeight=self.zSmooth, vTop=self.vmin,
                        vBottom=self.vmax, verbose=1, paraDepth=self.zmax,
                        dPhi=0.01, lam=self.smooth,
                        limits=[self.vmin_limit, self.vmax_limit],
                        lambdaFactor=self.s_fact, maxIter=1000)
            else:
                self.mgr.invert(
                    self.scheme, secNodes=3, paraMaxCellSize=5.0,
                    zWeight=self.zSmooth, vTop=self.vmin, vBottom=self.vmax,
                    maxIter=self.maxiter, verbose=1, paraDepth=self.zmax,
                    dPhi=0.01, lam=self.smooth,
                    limits=[self.vmin_limit, self.vmax_limit],
                    lambdaFactor=self.s_fact)
# pass starting model from slowness to velocity
            self.startModel = 1./self.mgr.fop.startModel()
# get final model
            self.endModel_all = self.mgr.model.array()
# Get coverage
            self.mesh_coor_all = self.mgr.paraDomain.cellCenters().array()
# Get path where PyGimly stores its results: date-time/TravelTime/Manager
            self.path = self.mgr.saveResult()
            p = os.path.split(self.path)[:-1]
            self.p_aim = ""
            for pp in p:
                self.p_aim = os.path.join(self.p_aim, pp)
            try:
                self.cover = self.mgr.inv.cov_sum
                mesh_x = self.mesh_coor_all[:, 0]
                mesh_y = self.mesh_coor_all[:, 1]
                mesh_v = self.mesh_coor_all[:, 2]
                mesh_x = mesh_x[self.cover > 0.]
                mesh_y = mesh_y[self.cover > 0.]
                mesh_v = mesh_v[self.cover > 0.]
                self.mesh_coor = np.zeros((len(mesh_x), 3))
                self.mesh_coor[:, 0] = mesh_x
                self.mesh_coor[:, 1] = mesh_y
                self.mesh_coor[:, 2] = mesh_v
                self.cell_rays = np.array(self.mgr.inv.cell_rays)
                self.ncover = np.sum(self.cell_rays, axis=0)
                nchi = self.cell_rays.shape[0]
                with open(os.path.join(self.p_aim, "vel&cover.txt"), "w")\
                        as fo:
                    fo.write("   X     Z     V     L_cum     nRay_cum   "
                             + f"{nchi} x nRay\n")
                    for i, c in enumerate(self.cover):
                        fo.write(f"{self.mesh_coor_all[i,0]:0.3f} "
                                 + f"{self.mesh_coor_all[i,1]:0.3f} "
                                 + f"{self.endModel_all[i]:0.0f}    "
                                 + f"{c:0.2f}       {self.ncover[i]}    "
                                 + f"{' '.join(map(str,self.cell_rays[:,i]))}"
                                 + "\n")
                self.cov_txt = "Coverage and rays"
                del mesh_x, mesh_y, mesh_v
                self.endModel = self.endModel_all[self.cover > 0.]
            except:
                self.cover =\
                    self.mgr.coverage()/self.mgr.mesh.cellSizes().array()
                cov_true = self.cover[self.cover > 0.]
                mesh_x = self.mesh_coor_all[:, 0]
                mesh_y = self.mesh_coor_all[:, 1]
                mesh_v = self.mesh_coor_all[:, 2]
                mesh_x = mesh_x[self.cover > 0.]
                mesh_y = mesh_y[self.cover > 0.]
                mesh_v = mesh_v[self.cover > 0.]
                self.mesh_coor = np.zeros((len(mesh_x), 3))
                self.mesh_coor[:, 0] = mesh_x
                self.mesh_coor[:, 1] = mesh_y
                self.mesh_coor[:, 2] = mesh_v
                self.endModel = self.endModel_all[self.cover > 0.]
                with open(os.path.join(self.p_aim, "vel&cover.txt"), "w")\
                        as fo:
                    fo.write("   X     Z     V     cover\n")
                    for i, c in enumerate(cov_true):
                        fo.write(f"{self.mesh_coor[i,0]:0.3f} "
                                 + f"{self.mesh_coor[i,1]:0.3f} "
                                 + f"{self.endModel[i]:0.0f}    {c:0.2f}\n")
                self.cov_txt = "log10(Coverage) and rays"
# pass pick times and calculated times from seconds to miliseconds
            self.v_nmo()
            self.dat = self.mgr.fop.data("t")*1000
            self.calc = self.mgr.inv.response.array()*1000
# Calculate minimum and maximum velocities for automatic color scale
#   First find minimum and maximum velocity of both starting and final model
#         (min_vel, max_vel)
            self.min_end = np.min(self.endModel)
            self.max_end = np.max(self.endModel)
# Now find the values of the 1% and 99% quantiles of both models and calculate
# another option for minimum and maximum of velocity color scale (min_v, max_v)
            self.q1_start = np.quantile(self.startModel, 0.01)
            self.q2_start = np.quantile(self.startModel, 0.99)
            self.q1_end = np.quantile(self.endModel, 0.01)
            self.q2_end = np.quantile(self.endModel, 0.99)
# Set maximum depth for model plotting to zmax (from dialog box)
            self.zmax_plt = self.zmax
# Store Control parameters from dialog box into file "inversion_parameters.txt"
            with open(os.path.join(self.p_aim, "inversion_parameters.txt"),
                      "w") as fo:
                fo.write(f"maximum_depth: {self.zmax:0.1f}\n")
                fo.write(f"initial_smoothing: {self.smooth:0.1f}\n")
                fo.write(f"smoothing_reduction_factor: {self.s_fact:0.3f}\n")
                fo.write(f"Z_smoothing: {self.zSmooth:0.1f}\n")
                if self.maxiter > 0:
                    fo.write(f"maximum_iterations: {self.maxiter}\n")
                fo.write(f"minimum_initial_velocity: {self.vmin:0.1f}\n")
                fo.write(f"maximum_initial_velocity: {self.vmax:0.1f}\n")
                fo.write(f"minimum_allowed_velocity: {self.vmin_limit:0.1f}\n")
                fo.write(f"maximum_allowed_velocity: {self.vmax_limit:0.1f}\n")

            print("\nInversion finished")
# If "C" was pressed, call another dialog box to change color scale
#    and/or maximum plotted depth
        else:
            res, okBut = self.main.dialog(
                ["If min or max is 0, the corresponding limit\n"
                 + " of the color scale is calculated automatically\n",
                 "Velocity color scale min [m/s]",
                 "Velocity color scale max [m/s]",
                 "Type of color scale:", self.model_colors,
                 "Maximum depth [m]", "Plot rays on final model"],
                ["l", "e", "e", "l", "b", "e", "c"],
                [None, self.v_scale_min, self.v_scale_max, None, 0,
                 self.zmax_plt, None], "Change color scale")
            if okBut is False:
                self.main.function = "main"
                return
            self.zmax_plt = float(res[5])
            try:
                self.v_scale_min = float(res[1])
                self.v_scale_max = float(res[2])
            except (IndexError, ValueError):
                self.v_scale_min = 150
                self.v_scale_max = 6000
            color_scale = self.model_colors[int(res[4])]
            if "Special" in color_scale:
                if "1500" in color_scale:
                    color_scale = "specialP"
                else:
                    color_scale = "specialS"
            if int(res[6]) > -1:
                self.rays_flag = True
            else:
                self.rays_flag = False
# If color scales are negative (default in first dialog box), they are set
#    to the quantiles rounded to the next 100 m/s
        self.main.function = "inver"
        ncol = 128
        if "special" in color_scale:
            lin_scale = False
        else:
            lin_scale = True
        if self.v_scale_min <= 0:
            self.v_scale_min = max(self.q1_start, self.q1_end)
            self.v_scale_min = np.round(self.v_scale_min/100, 0)*100
        if self.v_scale_max <= 0:
            self.v_scale_max = max(self.q2_start, self.q2_end)
            self.v_scale_max = np.round(self.v_scale_max/100, 0)*100
        if self.v_scale_max < 1600 and color_scale == "specialP":
            _ = QtWidgets.QMessageBox.warning(
                None, "Warning", "Maximum velocity < 1600\nColor scale "
                + "changed to rainbow\nOnce the plot is finished, you may "
                + "press 'C' to change color scale",
                QtWidgets.QMessageBox.Close)
            lin_scale = True
            color_scale = "rainbow"
# Define color scale and colors for values above and below extreme scale values
        cmp, cols = vel_scale(self, ncol=ncol, scale=color_scale)
        if lin_scale:
            self.levels = np.linspace(self.v_scale_min, self.v_scale_max, 128)
        else:
            if color_scale == "specialP":
                ncyan = int(ncol/16*4)
                self.levels = list(np.linspace(self.v_scale_min, 1500, ncyan))
                self.levels += list(np.linspace(1501, self.v_scale_max,
                                                ncol-ncyan))
            elif color_scale == "specialS":
                ncyan = int(ncol/16*4)
                self.levels = list(np.linspace(self.v_scale_min, 500, ncyan))
                self.levels += list(np.linspace(501, self.v_scale_max,
                                                ncol-ncyan))
            else:
                self.levels = list(np.linspace(self.v_scale_min,
                                               self.v_scale_max, 128))
            self.levels = np.array(self.levels)

# Define grid for different partial figures
        if code == 0:
            self.w_tomo = newWindow("Tomography results")
        else:
            self.figinv.clf()
        self.figinv = self.w_tomo.fig
        plt.tight_layout()
        self.gs = GridSpec(16, 13, figure=self.figinv)
# Axis for final model
        self.ax_mod = self.figinv.add_subplot(self.gs[:6, :])
# Acis for initial model
        self.ax_start = self.figinv.add_subplot(self.gs[8:11, 0:4])
# Axis for ray and coverage plot
        self.ax_rays = self.figinv.add_subplot(self.gs[13:16, 0:4])
# Axis for measured travel time plot
        self.ax_tt = self.figinv.add_subplot(self.gs[8:11, 5:8])
# Axis for difference between measured and calculated travel times
        self.ax_diff = self.figinv.add_subplot(self.gs[13:16, 5:8])
# Axis for average differences of shot gathers and receiver gathers
        self.ax_av_diff = self.figinv.add_subplot(self.gs[13:16, 9:12])
# Axis for chi2-evolution
        self.ax_chi = self.figinv.add_subplot(self.gs[8:11, 9:12])
# Define ticks for horizontal and vertical axes of model plots
# For horizontal axis, use sensor positions from pick file (picks.sgt")
# For vertical axis suppose that the topmost values is zero, which implies that
# the shot and receiver coordinates in files shots.geo and receivers.geo
# have been shifted vertically such that the topmost of both is at 0m.
# The reason for this is that PyGimly does not seem to invert for velocities
# in grid cells at negative Z coordinates, although it seems to create those
# Function Save_Gimli called at the beginning of this function takes care of
# this.
        self.ticks_x = self.window.set_ticks(np.min(self.sens),
                                             np.max(self.sens[:, 0]))
        self.ticks_y = self.window.set_ticks(-self.zmax, 0.)
# Define annotated levels of velocity color scales
        self.levs = np.linspace(self.v_scale_min, self.v_scale_max, 20,
                                endpoint=True)

# Plot starting model
        pg.viewer.showMesh(pg.Mesh(
            self.mgr.paraDomain), data=self.startModel, ax=self.ax_start,
            cMap=cmp, cMin=self.v_scale_min, cMax=self.v_scale_max,
            logScale=False, orientation="vertical", label="Velocity [m/s]",
            fitView=False)
        self.ax_start.set_xticks(self.ticks_x)
        self.ax_start.set_yticks(self.ticks_y)
        self.ax_start.set_xlim(left=self.xax_min, right=self.xax_max)
        self.ax_start.set_xlabel("Distance [m]", fontsize=self.tick_size_sec)
        self.ax_start.set_ylabel("Depth [m]", fontsize=self.tick_size_sec)
        self.ax_start.tick_params(axis='both', labelsize=self.tick_size_sec)
        self.ax_start.set_title("Starting model",
                                fontsize=self.tick_size_sec+2)
        ax_xmin, ax_xmax = self.ax_start.get_xlim()
        ax_ymin, ax_ymax = self.ax_start.get_ylim()
        xtxt = ax_xmin+(ax_xmax-ax_xmin)*0.02
        ytxt = ax_ymin+(ax_ymax-ax_ymin)*0.05
        txt = self.ax_start.text(xtxt, ytxt, "B", horizontalalignment="left",
                                 verticalalignment="bottom", fontsize=12)
        txt.set_bbox(dict(facecolor="white"))
# Share x and y axis parameters with ray plot and plot of final model
        self.ax_rays.sharex(self.ax_start)
        self.ax_mod.sharex(self.ax_start)
        self.ax_rays.sharey(self.ax_start)
        self.ax_mod.sharey(self.ax_start)
        print("Starting model plotted")

# Plot coverage and rays of final model
        cov_min = np.min(self.cover[self.cover > -np.inf])
        cov_max = np.max(self.cover[self.cover < np.inf])
        cmp = cc.cm.fire_r
        data = deepcopy(self.cover)
        data[np.isclose(data, 0.)] = np.nan
        pg.viewer.showMesh(pg.Mesh(
            self.mgr.paraDomain), data=data, ax=self.ax_rays, cMap=cmp,
            cMin=cov_min, cMax=cov_max, orientation="vertical",
            label="coverage [m]", fitView=False)
        rays = self.mgr.drawRayPaths(ax=self.ax_rays, color="black", lw=0.3,
                                     alpha=0.5)
        self.ax_rays.set_xticks(self.ticks_x)
        self.ax_rays.set_yticks(self.ticks_y)
        self.ax_rays.set_xlim(left=self.xax_min, right=self.xax_max)
        self.ax_rays.set_xlabel("Distance [m]", fontsize=self.tick_size_sec)
        self.ax_rays.set_ylabel("Depth [m]", fontsize=self.tick_size_sec)
        self.ax_rays.tick_params(axis='both', labelsize=self.tick_size_sec)
        self.ax_rays.set_title(self.cov_txt, fontsize=self.tick_size_sec+2)
        ax_xmin, ax_xmax = self.ax_rays.get_xlim()
        ax_ymin, ax_ymax = self.ax_rays.get_ylim()
        xtxt = ax_xmin+(ax_xmax-ax_xmin)*0.02
        ytxt = ax_ymin+(ax_ymax-ax_ymin)*0.05
        txt = self.ax_rays.text(xtxt, ytxt, "C", horizontalalignment="left",
                                verticalalignment="bottom", fontsize=12)
        txt.set_bbox(dict(facecolor="white"))
        print("Rays plotted")
# Interpolate coverage like final model
        self.triang = tri.Triangulation(
            self.mesh_coor_all[:, 0], self.mesh_coor_all[:, 1])
        isbad = np.isclose(self.cover, 0.)
        self.mask = np.all(np.where(isbad[self.triang.triangles], True, False),
                           axis=1)
        self.triang.set_mask(self.mask)
# Plot final model
        gci0 = self.ax_mod.tricontourf(
            self.triang, self.endModel_all, extend='both', levels=self.levels,
            colors=cols)
# self.scheme contains all shot and receiver coordinates as well as measured
# travel times, obtained at the beginning of the function from file picks.sgt
        y = pg.y(self.scheme)
# If there is topography present (not all receivers/shots at z=0), calculate
# the outline of the model (z positions of shots and receivers and the two
# corners of the base of the model) and define this outline as clipping path
        if min(y) < 0:
            x = pg.x(self.scheme)
            x = np.array(list(x)+[max(x), min(x), min(x)])
            y = np.array(list(y)+[-self.zmax_plt, -self.zmax_plt, y[0]])
            clip = np.zeros((len(x), 2))
            clip[:, 0] = x
            clip[:, 1] = y
# clip contains the coordinates of the clipping path. codes will contain the
# way to connect clipping points (move to the first point of the path, draw
# lines to all other points and finally close the path)
            codes = []
            Pat = Path
            codes += [Pat.MOVETO]
            codes += [Pat.LINETO]*(len(x)-2)
            codes += [Pat.CLOSEPOLY]
# set clipping
            clip_path = Path(clip, codes)
            del x, clip
            self.ax_mod.set_clip_on(True)
            gci0.set_clip_path(clip_path, transform=self.ax_mod.transData)
        del y
# Define positions of ticks along vertical axis such that 4 to 5 numbers are
# plotted
        dtk = round(self.zmax_plt/6., 0)
        dtk = max(dtk, 1.)
        ticks_y_mod = self.window.set_ticks(-self.zmax_plt, 0., dtick=dtk)
# Plot color bar
        if self.v_scale_max > 2000:
            ticks_vel = np.array([200, 500, 1000, 1500, 2000, 2500, 3000, 3500,
                                  4000, 4500, 5000, 5500, 6000])
        else:
            ticks_vel = np.array([200, 500, 750, 1000, 1250, 1500, 1750, 2000])
        ticks_vel = ticks_vel[ticks_vel <= self.v_scale_max]
        if ticks_vel[-1] < self.v_scale_max-100:
            ticks_vel = np.array(list(ticks_vel) + [self.v_scale_max])
        self.ax_mod.set_aspect('equal', adjustable='box', anchor='W')
        divider = make_axes_locatable(self.ax_mod)
        cax = divider.append_axes("right", size="2%", pad=0.2)
        cb = plt.colorbar(
            gci0, cmap=cmp, cax=cax, format='%.0f', label="Velocity [m/s]",
            ticks=ticks_vel, orientation='vertical', aspect=25, shrink=0.9,
            extend='both')

        cb.ax.tick_params(labelsize=10)
        if self.rays_flag:
            _ = self.mgr.drawRayPaths(ax=self.ax_mod, color="black", lw=0.3,
                                      alpha=0.5)
        ticks_x_mod = self.window.set_ticks(self.xax_min, self.xax_max,
                                            ntick=10)
        self.ax_mod.set_xticks(ticks_x_mod)
        self.ax_mod.set_yticks(ticks_y_mod)
        self.ax_mod.set_xlim(left=self.xax_min, right=self.xax_max)
        self.ax_mod.grid(which='minor', axis='both', color="gray")
        self.ax_mod.grid(which='major', axis='both', color="k")
        self.ax_mod.set_xlabel("Distance [m]", fontsize=self.tick_size_mod)
        self.ax_mod.set_ylabel("Depth [m]", fontsize=self.tick_size_mod)
        self.ax_mod.tick_params(axis='both', labelsize=self.tick_size_mod)
        self.ax_mod.set_ylim(-self.zmax_plt, 0)
        self.ax_mod.set_title(
              f"Model velocities (min:{self.min_end:0.0f}, "
              + f"max:{self.max_end:0.0f})", fontsize=self.tick_size_mod+2)
        ax_xmin, ax_xmax = self.ax_mod.get_xlim()
        ax_ymin, ax_ymax = self.ax_mod.get_ylim()
        self.ax_mod.text(
            ax_xmin, ax_ymax+(ax_ymax-ax_ymin)*0.01, self.main.dir_start,
            horizontalalignment="left", verticalalignment="bottom",
            fontsize=14)
        self.ax_mod.text(
            ax_xmax, ax_ymax+(ax_ymax-ax_ymin)*0.01, self.main.dir_end,
            horizontalalignment="right", verticalalignment="bottom",
            fontsize=14)
        xtxt = ax_xmin+(ax_xmax-ax_xmin)*0.02
        ytxt = ax_ymin+(ax_ymax-ax_ymin)*0.05
        txt = self.ax_mod.text(xtxt, ytxt, "A", horizontalalignment="left",
                               verticalalignment="bottom", fontsize=12)
        txt.set_bbox(dict(facecolor="white"))
        self.figinv.suptitle(self.main.title, fontsize=16, fontweight="heavy")
        self.figinv.subplots_adjust(top=0.92)

        print("Final model plotted")

# Store calculated picks into file calc_picks.dat
        with open("calc_picks.dat", "w") as fo:
            spu = np.round(np.array([self.geom.sht_dict[d]["x"]
                                     for d in self.geom.sht_dict]), 2)
            rpu = np.round(np.array([self.geom.rec_dict[d]["x"]
                                     for d in self.geom.rec_dict]), 2)
            shts = list(self.geom.sht_dict.keys())
            recs = list(self.geom.rec_dict.keys())
            for i, p in enumerate(rays.get_paths()):
                ispt = self.mgr.fop.data.id("s")[i]
                irpt = self.mgr.fop.data.id("g")[i]
                cs = np.round(self.scheme.sensors().array()[ispt], 2)[0]
                cr = np.round(self.scheme.sensors().array()[irpt], 2)[0]
                try:
                    ispt = shts[np.where(spu == cs)[0][0]]
                except IndexError:
                    continue
                try:
                    irpt = recs[np.where(rpu == cr)[0][0]]
                except IndexError:
                    continue
                fo.write(f"{ispt+1} {irpt+1} {self.calc[i]:0.4f}\n")
            self.window.PlotCalculatedTimes.setEnabled(True)

# Store average differences between calculated and measured travel times for
# every shot point and every receiver point into file Differences.dat
# In the first column, the number of the shot or receiver is given, not a
#   coordinate.
            diff_abs = self.calc-self.dat
            gxu = np.unique(self.gx)
            sxu = np.unique(self.sx)
            diff_mean_shots = np.zeros(len(sxu))
            diff_mean_recs = np.zeros(len(gxu))
            for i, s in enumerate(sxu):
                diff_mean_shots[i] = np.mean(
                    diff_abs[np.where(self.sx == s)[0]])
            for i, g in enumerate(gxu):
                diff_mean_recs[i] = np.mean(
                    diff_abs[np.where(self.gx == g)[0]])
            with open(os.path.join(self.p_aim, "Differences.dat"), "w") as fo:
                fo.write("Point  shot   receiver\n")
                lsxu = len(sxu)
                lgxu = len(gxu)
                for i in range(max(lsxu, lgxu)):
                    if i < lsxu and i < lgxu:
                        fo.write(f"{i} {diff_mean_shots[i]:0.4f} "
                                 + f"{diff_mean_recs[i]:0.4f}\n")
                    elif i < lsxu:
                        fo.write(f"{i} {diff_mean_shots[i]:0.4f} 0.000\n")
                    else:
                        fo.write(f"{i} 0.0000 {diff_mean_recs[i]:0.4f}\n")

# Store ray paths for final model into file rays.dat
            with open(os.path.join(self.p_aim, "rays.dat"), "w") as fo:
                for i, p in enumerate(rays.get_paths()):
                    ispt = self.mgr.fop.data.id("s")[i]
                    irpt = self.mgr.fop.data.id("g")[i]
                    cs = self.scheme.sensors().array()[ispt]
                    cr = self.scheme.sensors().array()[irpt]
                    fo.write(f"{len(p.vertices)} : ray {i}, shot {ispt} {cs}, "
                             + f"rec {irpt} {cr}     "
                             + f"calc: {self.calc[i]:0.4f} ms, calc-meas: "
                             + f"{diff_abs[i]:0.4f} ms\n")
                    for vert in p.vertices:
                        fo.write(f"{vert[0]:0.3f} {vert[1]:0.3f}\n")
# Plot evolution of chi2
            chi_ev = np.log10(np.array(self.mgr.inv.chi2History))
            nit = len(chi_ev)
            self.ax_chi.plot(np.arange(nit)+1, chi_ev)
            self.ax_chi.set_ylabel("log10(chi2)", fontsize=self.tick_size_sec)
            self.ax_chi.set_xlabel("iteration #", fontsize=self.tick_size_sec)
            self.ax_chi.set_title(f"smoothing:\nini: {int(self.smooth)}, "
                                  + f"fac: {self.s_fact:0.2f}, "
                                  + f"z: {self.zSmooth:0.2f}",
                                  fontsize=self.tick_size_sec+2)
            self.ax_chi.tick_params(axis='both', labelsize=self.tick_size_sec)
            ticks_x_chi = self.window.set_ticks(1., nit, ntick=10, dtick=1)
            self.ax_chi.set_xticks(ticks_x_chi)
            ax_xmin, ax_xmax = self.ax_chi.get_xlim()
            ax_ymin, ax_ymax = self.ax_chi.get_ylim()
            self.ax_chi.set_ylim(0., ax_ymax)
            xtxt = ax_xmin+(ax_xmax-ax_xmin)*0.02
            ytxt = ax_ymin+(ax_ymax-ax_ymin)*0.05
            txt = self.ax_chi.text(xtxt, ytxt, "F", horizontalalignment="left",
                                   verticalalignment="bottom", fontsize=12)
            txt.set_bbox(dict(facecolor="white"))
#            self.ax_chi.tick_params(axis='both', labelsize=18)

# Plot average traveltime differences for shots and receivers
            self.ax_av_diff.plot(sxu, diff_mean_shots, label="shots")
            self.ax_av_diff.plot(gxu, diff_mean_recs, label="receivers")
            self.ax_av_diff.set_ylabel("Time misfit [ms]",
                                       fontsize=self.tick_size_sec)
            self.ax_av_diff.set_xlabel("Position [m]",
                                       fontsize=self.tick_size_sec)
            self.ax_av_diff.set_title("Average differences\ncalc.-meas. ",
                                      fontsize=self.tick_size_sec+2)
            self.ax_chi.tick_params(axis='both', labelsize=self.tick_size_sec)
            self.ax_av_diff.grid(which='major', axis='x', color='k')
            self.ax_av_diff.grid(which='major', axis='y', color='k')
            self.ax_av_diff.grid(which='minor', axis='y', color='gray')
            self.ax_av_diff.legend(bbox_to_anchor=(1, 1), loc="upper right")
            ax_xmin, ax_xmax = self.ax_av_diff.get_xlim()
            ax_ymin, ax_ymax = self.ax_av_diff.get_ylim()
            xtxt = ax_xmin+(ax_xmax-ax_xmin)*0.02
            ytxt = ax_ymin+(ax_ymax-ax_ymin)*0.05
            txt = self.ax_av_diff.text(xtxt, ytxt, "G",
                                       horizontalalignment="left",
                                       verticalalignment="bottom", fontsize=12)
            txt.set_bbox(dict(facecolor="white"))
#            self.ax_av_diff.tick_params(axis='both', labelsize=18)
            print("Average differences plotted")

# Plot measured travel times using the PyGimli utility
            maxval1 = np.max(self.dat)
            maxval2 = np.max(self.calc)
            maxval = max(maxval1, maxval2)
            minval = 0
            ticks = self.window.set_ticks(minval, maxval, 8, 5.)
            dmin = np.quantile(diff_abs, 0.01)
            dmax = np.quantile(diff_abs, 0.99)
            dext = max(dmax, -dmin)
            dmax = dext
            dmin = -dext
            ticks_d = self.window.set_ticks(dmin, dmax, 8, 0.5)

            gci1 = pg.viewer.mpl.dataview.drawVecMatrix(
                self.ax_tt, self.gx,  self.sx, self.dat, squeeze=True,
                logScale=False, cMin=0, cMax=maxval, aspect='equal',
                fitView=True)
            self.ax_tt.set_aspect('equal', adjustable='box', anchor='C')
            self.ax_tt.set_ylabel("Source positions [m]",
                                  fontsize=self.tick_size_sec)
            self.ax_tt.set_title("Measured travel times",
                                 fontsize=self.tick_size_sec+2)
            self.ax_tt.tick_params(axis='both', labelsize=self.tick_size_sec)
            ax_xmin, ax_xmax = self.ax_tt.get_xlim()
            ax_ymin, ax_ymax = self.ax_tt.get_ylim()
            xtxt = ax_xmin+(ax_xmax-ax_xmin)*0.02
            ytxt = ax_ymin+(ax_ymax-ax_ymin)*0.05
            txt = self.ax_tt.text(xtxt, ytxt, "D", horizontalalignment="left",
                                  verticalalignment="bottom", fontsize=12)
            txt.set_bbox(dict(facecolor="white"))
            _ = plt.colorbar(gci1, ax=self.ax_tt, format='%.0f',
                             label="Times (ms)", ticks=ticks,
                             orientation='vertical', aspect=20)
            print("Travel times plotted")

# Plot differences between calculated and measured travel times using the
#   Pygimli utility
            gci3 = pg.viewer.mpl.dataview.drawVecMatrix(
                self.ax_diff, self.gx, self.sx, diff_abs, squeeze=True,
                cMap="seismic", logScale=False, cMin=dmin,
                cMax=dmax, aspect='equal', fitView=True)
            self.ax_diff.set_aspect('equal', adjustable='box', anchor='C')
            self.ax_diff.set_xlabel("Receiver positions [m]",
                                    fontsize=self.tick_size_sec)
            self.ax_diff.set_ylabel("Source positions [m]",
                                    fontsize=self.tick_size_sec)
            self.ax_diff.set_title(
                f"Misfit after {self.mgr.inv.inv.iter()+1} "
                + f"iterations:\nchi2={self.mgr.inv.chi2():0.2f}; "
                + f"abs_rms={self.mgr.inv.inv.absrms()*1000:0.1f}ms",
                fontsize=self.tick_size_sec+2)
            self.ax_diff.tick_params(axis='both', labelsize=self.tick_size_sec)
            ax_xmin, ax_xmax = self.ax_diff.get_xlim()
            ax_ymin, ax_ymax = self.ax_diff.get_ylim()
            xtxt = ax_xmin+(ax_xmax-ax_xmin)*0.02
            ytxt = ax_ymin+(ax_ymax-ax_ymin)*0.05
            txt = self.ax_diff.text(xtxt, ytxt, "E",
                                    horizontalalignment="left",
                                    verticalalignment="bottom", fontsize=12)
            txt.set_bbox(dict(facecolor="white"))
            _ = plt.colorbar(gci3, ax=self.ax_diff, format='%.1f',
                             label="Calc - meas (ms)", ticks=ticks_d,
                             orientation='vertical', aspect=20)
            print("Misfits plotted")

# Plot title above the final model and store plot
# If plot is done with automatic scaling, the name is
#    inversion_results-auto.png
#    if not, it is inversion_results.png. So, the automatic scaling is always
#    stored, if scales are changed, only the last version is stored.
#           self.window.figs[ip].suptitle(self.main.title, fontsize="xx-large",
#                                         fontweight="heavy")
            # self.figinv.suptitle(self.main.title, fontsize="xx-large",\
            #                               fontweight="heavy")
#        self.w_tomo.showMaximized()
        self.w_tomo.show()
        if code != 67:
            self.figinv.savefig(os.path.join(self.p_aim,
                                             "inversion_results_auto.png"))
            self.figinv.savefig(os.path.join(self.p_aim,
                                             "inversion_results_auto.png"))
            with open(os.path.join(self.p_aim, "velocities.dat"), "w") as fo:
                for i, e in enumerate(self.endModel):
                    fo.write(f"{self.mesh_coor[i,0]:0.3f} "
                             + f"{self.mesh_coor[i,1]:0.3f} "
                             + f"{e:0.0f}\n")
            self.window.Change_colors.setEnabled(True)
# Interpolate model on regular quadratic grid for use with Sofi2D

            self.prepare_FWI()
# Move all files from folder TravelTimeManager to its base folder, the name of
#      which is date-hour in the format YYYYMMDD-hh.mm
# Then delete folder TravelTimeManager
# The reason is just practical, not to have to search the results deeper
#     in the path tree than necessary
            try:
                get_files = os.listdir(self.path)
                for g in get_files:
                    os.replace(os.path.join(self.path, g),
                               os.path.join(self.p_aim, g))
                os.rmdir(self.path)
            except Exception as error:
                print(f'Error: {error}\nPath {self.path} not found.\n',
                      'Tomography results stay in original folder')

        else:
            self.figinv.savefig(os.path.join(self.p_aim,
                                "inversion_results.png"))
        code = 0
        self.traces.calc_picks = False
        self.traces.readCalcPicks()

    def invCol(self):
        """

        Call function Inversion with code 67 (decimal ASCII code for letter
        "C"). This gives the possibility to change color scale and/or depth
        scale for plotting of inversion results

        This function is called when "Utilities-> Change colors tomo" or "C"
        is pressed.

        Returns
        -------
        None.

        """
        self.main.function = "main"
        self.inversion(code=67)

    def prepare_FWI(self):
        """
        Choice of output format for different Full-waveform inversions (FWI)

        Returns
        -------
        None.

        """
        res, okBut = self.main.dialog(
            ["Save model for FWI inversion with:",
             ["SOFI2D", "ShaVi", "None"]],
            ["l", "r"], [None, 2], "Choose FWI format")
        if not okBut or int(res[1]) == 2:
            print("\nNo FWI output written\n")
            return
        elif int(res[1]) == 0:
            self.prepareSofi2D()
        else:
            self.prepareShaVi()

    def prepareSOFI2D(self):
        """
        Write final model with estimated v_s and densities to binary files for
        use with SOFI2D and prepare a sample json file for SOFI2D

        Returns
        -------
        None.

        """
        x = self.mgr.paraDomain.cellCenters().array()[:, 0]
        z = self.mgr.paraDomain.cellCenters().array()[:, 1]
        v = self.mgr.model.array()
        vmin = v.min()/2.
        vmax = v.max()
# Get some control parameters
        res, okBut = self.main.dialog(
            ["Central frequency [Hz]",
             "Source signal length [number periods]",
             "Calculation time [s]",
             "Absorbing boundary [number of cells]",
             "Absorbing boundary at surface (0: free surface)",
             "Nr. of processors in X direction",
             "Nr. of processors in Z direction",
             "Cell step X for snapshots",
             "Cell step Z for snapshots"],
            ["e", "e", "e", "e", "e", "e", "e", "e", "e"],
            [50, 2, 0.1, 20, 0, 2, 2, 4, 2], "Settings for Sofi2D")
        if not okBut:
            print("\nSOFI2D output not written\n")
            return
# fc is the central frequency of the source signal
# dx is the cell size, calculated following the stability criteria given in
#    SOFI2D manual and rounded to the next lower 2.5 cm.
        fc = float(res[0])
        dx = vmin/(16*fc)
        dx = int(dx/0.025)*0.025
# ts is length of simulated source signal
        ts = float(res[1])/fc
# tmax is length of traces to be calculated
        tmax = float(res[2])
# nbound is the number of cells to be added at the left, right and lower
# edges for wave attenuation and avoiding reflections from those boundaries
# X coordinates of the shot and receiver points are increased by bound
        nbound = int(res[3])
        bound = nbound*dx
# n_surface_bound is the number of cells to be added to the model for wave
# attenuation at the upper surface. If it is 0, free surface is assumed. If it
# is >0, the shot and receiver points are placed at depth bound_s+0.05
        n_surface_bound = int(res[4])
        bound_s = n_surface_bound*dx
# proc_x*proc_z is the number of CPU processors that will be used. The whole
# domain will be split into proc_x blocks in X-direction and proc_z blocks in
# Z-direction
        proc_x = int(res[5])
        proc_z = int(res[6])
# SOFI2D writes snapshot files. In these files, every idx-th point is writte in
# X direction and every idz-th point in Z direction
        idx = int(res[7])
        idz = int(res[8])
        dt = 0.55*dx/vmax
        dt = int(dt*1E6)/1E6
        ndt = max(int(0.001/dt), 1)
        print(f"tmax: {tmax}")
        xmin = np.floor(x.min())-bound
        xmax = np.ceil(x.max())+bound
        zmin = np.floor(z.min())-bound
        zmax = np.ceil(z.max())+bound_s
        print(f"zmin: {zmin:0.3f}, zmax: {zmax:0.3f}")
        nx = int((xmax-xmin)/dx+1)
        nz = int((zmax-zmin)/dx+1)
        ix = proc_x*idx
        iz = proc_z*idz
        if nx % ix != 0:
            nx += ix - nx % ix
        if nz % iz != 0:
            nz += iz - nz % iz

# Define X and Z coordinates of interpolated mesh
        xi = np.linspace(xmin, xmax, nx)
        zi = np.linspace(zmin, zmax, nz)

# Perform linear interpolation of the data given on original positions (x,z)
# on a grid defined by (xi,zi)
        Xi, Zi = np.meshgrid(xi, zi)
        data_p = griddata(self.mgr.paraDomain.cellCenters().array()[:, :2],
                          v, (Xi, Zi), method='linear')
        dpf = data_p.flatten()
        Xif = Xi.flatten()
        Zif = Zi.flatten()
        Xi_nan = Xif[~np.isnan(dpf)]
        Zi_nan = Zif[~np.isnan(dpf)]
        centers = np.zeros((len(Xi_nan), 2))
        centers[:, 0] = Xi_nan
        centers[:, 1] = Zi_nan
        data_p_nan = dpf[~np.isnan(dpf)]
        data_p = griddata(centers, data_p_nan, (Xi, Zi), method='nearest')
        data_p = np.flip(np.transpose(data_p))
# For S-wave velocity suppose that for very small P-velocities, vs = vp/2 and
# for 6 km/s, vs = vp/sqrt(3), in between: linear function
        data_s = data_p/((np.sqrt(3)-2)/6000.*data_p+2.)
# For densities suppose that for very small P-velocities, rho = 2000 and
# for 6 km/s, rho = 2700, in between: linear function
        data_r = data_p*(1000./6000.)+1700.
        print(f"SOFI2D model: nx = {nx}, nz = {nz}, bytes = {nx*nz*4}")
        print(f"              dx: {dx:0.3f}, dt: {dt:0.6f}\n")
# Write inary files for P and S velocities and for densities
        np.array(data_p.astype('float32')).\
            tofile(os.path.join(self.p_aim, "model.vp"))
        np.array(data_s.astype('float32')).\
            tofile(os.path.join(self.p_aim, "model.vs"))
        np.array(data_r.astype('float32')).\
            tofile(os.path.join(self.p_aim, "model.rho"))
        with open(os.path.join(self.p_aim, "sofi2D.json"), "w") as fo:
            fo.write("#---------------------------------------------\n")
            fo.write("#      JSON PARAMETER FILE FOR SOFI2D\n")
            fo.write("#---------------------------------------------\n")
            fo.write("# description:\n")
            fo.write("# description/name of the model:/n#\n{\n")
            fo.write('"Domain Decomposition" : "comment",\n')
            fo.write(f'			"NPROCX" : "{proc_x}",\n')
            fo.write(f'			"NPROCY" : "{proc_z}",\n\n')
            fo.write('"FD stencil" : "comment",\n')
            fo.write('			"RSG" : "0",\n\n')
            fo.write('"FD order" : "comment",\n')
            fo.write('			"FDORDER" : "8",\n')
            fo.write('			"MAXRELERROR" : "1",\n\n')
            fo.write('"2-D Grid" : "comment",\n')
            fo.write(f'			"NX" : "{nx}",\n')
            fo.write(f'			"NY" : "{nz}",\n')
            fo.write(f'			"DH" : "{dx:0.3f}",\n\n')
            fo.write('"Time Stepping" : "comment",\n')
            fo.write(f'			"TIME" : "{tmax:0.3f}",\n')
            fo.write(f'			"DT" : "{dt:0.6f}",\n\n')
            fo.write('"Source" : "comment",\n')
            fo.write('			"SOURCE_SHAPE" : "2",\n')
            fo.write('			"SOURCE_SHAPE values: ricker=1;fumue=2;'
                     + 'from_SIGNAL_FILE=3;SIN**3=4" : "comment",\n')
            fo.write('			"SIGNAL_FILE" : "signal_mseis.tz",\n')
            fo.write('			"SOURCE_TYPE" : "3",\n')
            fo.write('			"SOURCE_TYPE values (point_source): explosive'
                     + '=1; force_in_x=2; force_in_y=3; custom_force=4" : '
                     + '"comment",\n')
            fo.write('			"SRCREC" : "1",\n')
            fo.write('			"SRCREC values :  read from SOURCE_FILE=1,'
                     + ' PLANE_WAVE=2 (internal)" : "comment"\n')
            fo.write('			"SOURCE_FILE" : "./source_pts.dat",\n')
            fo.write('			"RUN_MULTIPLE_SHOTS" : "1",\n')
            fo.write('			"PLANE_WAVE_DEPTH" : "0.0",\n')
            fo.write('			"PLANE_WAVE_ANGLE" : "0.0",\n')
            fo.write(f'			"TS" : "{ts:0.6f}",\n\n')
            fo.write('"Model" : "comment",\n')
            fo.write('			"READMOD" : "1",\n')
            fo.write('			"MFILE" : "model/model",\n')
            fo.write('			"WRITE_MODELFILES" : "0",\n\n')
            fo.write('"Q-approximation" : "comment",\n')
            fo.write('			"L" : "0",\n')
            fo.write('			"FL1" : "5.0",\n')
            fo.write('			"TAU" : "0.00001",\n\n')
            if n_surface_bound > 0:
                free = 0
            else:
                free = 1
            fo.write('"Boundary Conditions" : "comment",\n')
            fo.write(f'			"FREE_SURF" : "{free}",\n')
            fo.write('			"ABS_TYPE" : "1",\n')
            fo.write('			"ABS_TYPE values : CPML-Boundary=1; '
                     + 'Damping-Boundary=2" : "comment",\n')
            fo.write(f'			"FW" : "{nbound}",\n')
            fo.write('			"DAMPING" : "8.0",\n')
            fo.write('			"BOUNDARY" : "0",\n\n')
            fo.write('"Snapshots" : "comment",\n')
            fo.write('			"SNAP" : "1",\n')
            fo.write('			"TSNAP1" : "2e-3",\n')
            fo.write(f'			"TSNAP2" : "{np.round(tmax,3):0.3f}",\n')
            fo.write('			"TSNAPINC" : "0.002",\n')
            fo.write(f'			"IDX" : "{idx}",\n')
            fo.write(f'			"IDY" : "{idz}",\n')
            fo.write('			"SNAP_FORMAT" : "3",\n')
            fo.write('			"SNAP_FILE" : "snap/snapshots",\n\n')
            fo.write('"Receiver" : "comment",\n')
            fo.write('			"SEISMO" : "1",\n')
            fo.write('			"READREC" : "1",\n')
            fo.write('			"REC_FILE" : "receiver_pts.dat",\n')
            fo.write('			"REFRECX, REFRECY" : "0.0 , 0.0",\n')
            fo.write('			"XREC1,YREC1" : "54.0 , 2106.0",\n')
            fo.write('			"XREC2,YREC2" : "5400.0 , 2106.0",\n')
            fo.write('			"NGEOPH" : "1",\n\n')
            fo.write('"Receiver array" : "comment",\n')
            fo.write('			"REC_ARRAY" : "0",\n')
            fo.write('			"REC_ARRAY_DEPTH" : "70.0",\n')
            fo.write('			"REC_ARRAY_DIST" : "40.0",\n')
            fo.write('			"DRX" : "4",\n\n')
            fo.write('"Seismograms" : "comment",\n')
            fo.write(f'			"NDT" : "{ndt}",\n')
            fo.write('			"SEIS_FORMAT" : "1",\n')
            fo.write('			"SEIS_FILE" : "su/record",\n\n')
            fo.write('"Monitoring the simulation" : "comment",\n')
            fo.write('			"LOG_FILE" : "log/test.log",\n')
            fo.write('			"LOG" : "1",\n')
            fo.write('			"OUT_TIMESTEP_INFO" : "100",\n\n')
            fo.write('"Checkpoints" : "comment",\n')
            fo.write('			"CHECKPTREAD" : "0",\n')
            fo.write('			"CHECKPTWRITE" : "0",\n')
            fo.write('			"CHECKPT_FILE" : "tmp/checkpoint_sofi2D",\n}\n')
        nrec = np.unique(self.traces.receiver)
        xrec = np.zeros(len(nrec))
        zrec = np.zeros(len(nrec))
        for i, n in enumerate(nrec):
            if self.geom.x_dir:
                xrec[i] = self.geom.rec_dict[n]["x"]
            else:
                xrec[i] = self.geom.rec_dict[n]["y"]
            zrec[i] = self.geom.rec_dict[n]["z"]
        nshot = np.unique(self.traces.shot)
        xshot = np.zeros(len(nshot))
        zshot = np.zeros(len(nshot))
        for i, n in enumerate(nshot):
            if self.geom.x_dir:
                xshot[i] = self.geom.sht_dict[nrec[i]]["x"]
            else:
                xshot[i] = self.geom.sht_dict[nrec[i]]["y"]
            zshot[i] = self.geom.sht_dict[nrec[i]]["z"]
        xmnr = xrec.min()
        xmns = xshot.min()
        dx_stn = dx*nbound - min(xmnr, xmns)
        xrec += dx_stn
        xshot += dx_stn
        zrec += bound_s+0.05
        zshot += bound_s+0.05
        with open(os.path.join(self.p_aim, "receiver_pts.dat"), "w") as fo:
            for i, xs in enumerate(xrec):
                fo.write(f"{xs:0.3f} {zrec[i]:0.3f}\n")
        with open(os.path.join(self.p_aim, "source_pts.dat"), "w") as fo:
            for i, xs in enumerate(xshot):
                fo.write(f"{xs:0.3f} {zshot[i]:0.3f} "
                         + f"0.0 {fc:0.1f} 1.0\n")

    def prepareShaVi(self):
        """
        Write final model and data to text files for
        use with ShaVi and prepare a sample parameter file

        Returns
        -------
        None.

        """
        def ricker_wavelet(f, size, dt=1):
            """
            Create a Ricker signal starting at -1/f with a total length of size
            samples. Calculation starts at t0 = -1./f, returned as time = 0.

            Parameters
            ----------
            f : float
                Central frequency [Hz].
            size : int
                Total number of samples.
            dt : float, optional
                sampling step [s]. The default is 1.

            Returns
            -------
            t : numpy float array with length size
                time vector [s]
            y : numpy float array with length size
                ricker wavelet values

            """
            t0 = 1./f
            t = np.arange(size)*dt-t0
            y = (1.0 - 2.0*(np.pi**2)*(f**2)*(t**2)) *\
                np.exp(-(np.pi**2)*(f**2)*(t**2))
            return t+t0, y

        folder = "ShaVi"
        if not os.path.isdir(folder):
            os.makedirs(folder)
        os.chdir(folder)
        x = self.mgr.paraDomain.cellCenters().array()[:, 0]
        v = self.mgr.model.array()
# Get some control parameters
        res, okBut = self.main.dialog(
            ["Central frequency [Hz]",
             "Use every n'th shot point",
             "Reduce sampling rate by factor",
             "Maximum time to be stored [s]",
             "Grid spacing [m]",
             "Absorbing boundary [number of cells]",
             "Absorbing boundary at surface (0: free surface)",
             "Nr. of processors",
             "Nr. of iterations",
             "Objective function:",
             ["X-correlation", "Norm"]],
            ["e", "e", "e", "e", "e", "e", "e", "e", "e", "l", "r"],
            [50, 1, 4, 0.2, 1, 8, 3, 4, 50, None, 2], "Settings for ShaVi")
        if not okBut:
            print("\nShaVi output not written\n")
            return
# fc is the central frequency of the source signal
# dx is the cell size, calculated following the stability criteria given in
#    SOFI2D manual and rounded to the next lower 2.5 cm.
        fc = float(res[0])
        nd_shot = int(res[1])
        nd_time = int(res[2])
        s_inter = self.data.dt*nd_time
# tmax is length of traces to be calculated
        tmax = float(res[3])
        n_time_min = abs(int(self.data.t0/self.data.dt))
        n_time = int(tmax/self.data.dt)
        n_time_max = n_time_min+n_time
        time_samples = list(range(n_time_min, n_time_max+1, nd_time))
        nt_store = len(time_samples)
        dx = float(res[4])
# nbound is the number of cells to be added at the left, right and lower
# edges for wave attenuation and avoiding reflections from those boundaries
# X coordinates of the shot and receiver points are increased by bound
        nbound = int(res[5])
# n_surface_bound is the number of cells to be added to the model for wave
# attenuation at the upper surface. If it is 0, free surface is assumed. If it
# is >0, the shot and receiver points are placed at depth n_surface_bound
        n_surface_bound = int(res[6])
# proc is the number of CPU processors that will be used.
        proc = int(res[7])
        max_iter = int(res[8])
        object_type = int(res[10])
        x0m = dx*(nbound+5)
        depth_model = self.zmax_plt+x0m
        nz_size = int(depth_model/dx)
        x_min = x.min() - dx*(nbound+5)
        x_max = x.max() + dx*(nbound+5)
        nx_size = int((x_max-x_min)/dx)
# Write data file and store shot positions into list sh_pos and receiver
# positions into dictionary rec_pos_dir with key = conscurive number of
# stored shot and as value a list of receiver positions for each shot.
        sht_pts = list(self.traces.sht_pt_dict.keys())
        rec_pos_dir = {}
        sh_pos = []
        data = np.zeros((len(time_samples),
                         len(self.traces.sht_pt_dict[sht_pts[0]]["file"])))
        with open("data.txt", "w") as fo:
            for i, key in enumerate(sht_pts):
                if key % nd_shot != 0:
                    continue
                r = self.traces.sht_pt_dict[key]["receiver"][0]
                tr = self.traces.sht_rec_dict[(key, r)]
                sh_pos.append(self.traces.shot_pos[tr])
                rec_pos_dir[i] = []
                f_nr = []
                tf_nr = []
                r_nr = []
                for k, f in enumerate(self.traces.sht_pt_dict[key]["file"]):
                    r = self.traces.sht_pt_dict[key]["receiver"][k]
                    tr = self.traces.sht_rec_dict[(key, r)]
                    if np.isclose(self.traces.offset[tr], 0.):
                        continue
                    f = self.traces.sht_pt_dict[key]["file"][k]
                    t = self.traces.sht_pt_dict[key]["trace"][k]
                    f_nr.append(f)
                    tf_nr.append(t)
                    r_nr.append(r)
                    rec_pos_dir[i].append(self.traces.receiver_pos[tr])
                    data[:, k] = self.data.st[f][t].data[time_samples]
                index = np.argsort(np.array(r_nr))
                for j in range(data.shape[0]):
                    for k in index:
                        fo.write(f"{data[j,k]:0.4e}\n")

# Write sources and receivers per source into their files in terms of
# grid point numbers
        with open("sources.txt", "w") as fo:
            for s in sh_pos:
                fo.write(f"{int((s-x_min)/dx)}\n")
        with open("receivers.txt", "w") as fo:
            for i in range(len(rec_pos_dir[0])):
                for key in rec_pos_dir.keys():
                    ri = int((rec_pos_dir[key][i]-x_min)/dx)
                    fo.write(f"{ri} ")
                fo.write("\n")

# Write parameter file
        with open("parameter.txt", "w") as fo:
            fo.write(f"number_sample  {nt_store}\n")
            fo.write(f"sampling_intrvl  {s_inter:0.6f}\n")
            fo.write(f"depth_model  {nz_size}\n")
            fo.write(f"lateral_model  {nx_size}\n")
            fo.write(f"grid_space  {dx:0.2f}\n")
            fo.write(f"depth_source  {n_surface_bound}\n")
            fo.write(f"depth_receiver  {n_surface_bound}\n")
            fo.write(f"number_src  {len(sh_pos)}\n")
            fo.write(f"number_rcr  {len(rec_pos_dir[0])}\n")
            fo.write(f"processors  {proc}\n")
            fo.write(f"max_iteration  {max_iter}\n")
            fo.write("boundary_key  1\n")
            fo.write(f"absorb_lay  {nbound}\n")
            fo.write(f"obj_fun  {object_type}\n")
            fo.write(f"upper_avoid  {n_surface_bound}\n")
            fo.write("data_order  1\n")

# Export tomography model as starting model
        xmin = x_min
        xmax = x_max
        zmin = -3.*dx
        zmax = zmin + nz_size*dx
        print(f"zmin: {zmin:0.3f}, zmax: {zmax:0.3f}")
        nx = nx_size
        nz = nz_size

# Define X and Z coordinates of interpolated mesh
        xi = np.linspace(xmin, xmax, nx)
        zi = np.linspace(zmin, zmax, nz)

# Perform linear interpolation of the data given on original positions (x,z)
# on a grid defined by (xi,zi)
        Xi, Zi = np.meshgrid(xi, zi)
        points = self.mgr.paraDomain.cellCenters().array()[:, :2]
        points[:, 1] *= -1.
        index = np.isfinite(v)
        points = points[index, :]
        v = v[index]
        data_p = griddata(points, v, (Xi, Zi), method='linear')
# Fill nan's with neighbouring values
# First fill rows
        for i in range(data_p.shape[0]):
            ok = np.where(np.isfinite(data_p[i, :]))[0]
# If no valid data exist in the row, skip row
            if len(ok) == 0:
                continue
# If nans exist at the beginning of the row, fill them with the first valid
#    value encountered in the row
            if ok[0] > 0:
                data_p[i, :ok[0]] = data_p[i, ok[0]]
# If nans exist at the end of the row, fill them with the last valid
#    value encountered in the row
            if ok[-1] < nx_size-1:
                data_p[i, ok[-1]+1:] = data_p[i, ok[-1]]
# Fill intermediate nans with value of the left neighbour
            na = np.where(np.isnan(data_p[i, :]))[0]
            if len(na) == 0:
                continue
            for j in na:
                data_p[i, j] = data_p[i, j-1]
# Now do the same procedure for columns
        for i in range(data_p.shape[1]):
            ok = np.where(np.isfinite(data_p[:, i]))[0]
            if len(ok) == 0:
                continue
            if ok[0] > 0:
                data_p[:ok[0], i] = data_p[ok[0], i]
            if ok[-1] < nz_size-1:
                data_p[ok[-1]+1:, i] = data_p[ok[-1], i]
            na = np.where(np.isnan(data_p[:, i]))[0]
            if len(na) == 0:
                continue
            for j in na:
                data_p[j, i] = data_p[j-1, i]
        with open("initial_model.txt", "w") as fo:
            for i in range(data_p.shape[0]):
                for j in range(data_p.shape[1]):
                    fo.write(f"{data_p[i,j]:0.3f} ")
                fo.write("\n")
        w_shavi = newWindow("Shavi interpolated")
        figsha = w_shavi.fig
        _ = figsha.add_subplot(111)
        plt.imshow(data_p, extent=(Xi.min()-dx/2, Xi.max()+dx/2,
                                   -Zi.max()-dx/2, -Zi.min()+dx/2))
        plt.plot(points[:, 0], -points[:, 1], "k.", ms=1)
        plt.show()

        print(f"ShaVi model: nx = {nx}, nz = {nz}, bytes = {nx*nz*4}")
        print(f"             dx: {dx:0.3f}, dt: {s_inter:0.6f}\n")
# Create source signal
        times, data = ricker_wavelet(fc, len(time_samples), dt=s_inter)
        with open("source_signal.txt", "w") as fo:
            for d in data:
                fo.write(f"{d:0.6f}\n")
        os.chdir("..")
