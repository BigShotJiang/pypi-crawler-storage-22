"""
PyRender - A beautiful and simple rendering library for Python
"""

from .renderer import Renderer, RenderMode
from .primitives import (
    Primitive,
    Rectangle,
    Circle,
    Line,
    Polygon,
    Text,
    Gradient,
    Image
)
from .color import Color, ColorPalette
from .scene import Scene
from .camera import Camera
from .transform import Transform, Matrix3x3
from .effects import (
    Effect,
    ShadowEffect,
    BlurEffect,
    GlowEffect,
    OutlineEffect
)

__version__ = "0.1.0"
__author__ = "ZloyVanek Team"
__all__ = [
    "Renderer",
    "RenderMode",
    "Primitive",
    "Rectangle",
    "Circle",
    "Line",
    "Polygon",
    "Text",
    "Gradient",
    "Image",
    "Color",
    "ColorPalette",
    "Scene",
    "Camera",
    "Transform",
    "Matrix3x3",
    "Effect",
    "ShadowEffect",
    "BlurEffect",
    "GlowEffect",
    "OutlineEffect",
]
