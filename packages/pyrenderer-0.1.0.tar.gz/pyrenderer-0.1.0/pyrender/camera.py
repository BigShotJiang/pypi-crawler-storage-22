"""Camera system for PyRender"""

from .transform import Transform, Matrix3x3


class Camera:
    """Camera for controlling viewport and transformations"""
    
    def __init__(self, width: int, height: int):
        """
        Initialize camera.
        
        Args:
            width: Viewport width
            height: Viewport height
        """
        self.width = width
        self.height = height
        self.transform = Transform()
        self.zoom = 1.0
    
    def set_position(self, x: float, y: float) -> 'Camera':
        """Set camera position"""
        self.transform.x = x
        self.transform.y = y
        return self
    
    def move(self, dx: float, dy: float) -> 'Camera':
        """Move camera by offset"""
        self.transform.x += dx
        self.transform.y += dy
        return self
    
    def set_zoom(self, zoom: float) -> 'Camera':
        """Set camera zoom level"""
        self.zoom = max(0.1, zoom)
        return self
    
    def zoom_in(self, factor: float = 1.2) -> 'Camera':
        """Zoom in by factor"""
        self.zoom *= factor
        return self
    
    def zoom_out(self, factor: float = 1.2) -> 'Camera':
        """Zoom out by factor"""
        self.zoom /= factor
        return self
    
    def get_view_matrix(self) -> Matrix3x3:
        """Get camera view transformation matrix"""
        # Center the camera
        center_x = self.width / 2
        center_y = self.height / 2
        
        # Create transformation: translate to center, apply zoom, translate camera position
        mat_to_center = Matrix3x3.translation(center_x, center_y)
        mat_zoom = Matrix3x3.scale(self.zoom, self.zoom)
        mat_cam_pos = Matrix3x3.translation(-self.transform.x, -self.transform.y)
        
        return mat_to_center * mat_zoom * mat_cam_pos
    
    def world_to_screen(self, world_x: float, world_y: float):
        """Convert world coordinates to screen coordinates"""
        return self.get_view_matrix().transform_point(world_x, world_y)
    
    def screen_to_world(self, screen_x: float, screen_y: float):
        """Convert screen coordinates to world coordinates"""
        # Inverse of world_to_screen
        center_x = self.width / 2
        center_y = self.height / 2
        
        world_x = (screen_x - center_x) / self.zoom + self.transform.x
        world_y = (screen_y - center_y) / self.zoom + self.transform.y
        
        return (world_x, world_y)
    
    def __repr__(self) -> str:
        return f"Camera(pos=({self.transform.x}, {self.transform.y}), zoom={self.zoom:.2f})"
