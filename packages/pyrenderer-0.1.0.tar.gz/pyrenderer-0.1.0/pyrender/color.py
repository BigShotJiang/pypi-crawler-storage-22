"""Color utilities for PyRender"""

from typing import Tuple, Union
import colorsys


class Color:
    """Represents a color with RGB(A) components"""
    
    def __init__(self, r: float, g: float, b: float, a: float = 1.0):
        """
        Initialize a color.
        
        Args:
            r: Red component (0-1)
            g: Green component (0-1)
            b: Blue component (0-1)
            a: Alpha component (0-1), default 1.0
        """
        self.r = max(0.0, min(1.0, r))
        self.g = max(0.0, min(1.0, g))
        self.b = max(0.0, min(1.0, b))
        self.a = max(0.0, min(1.0, a))
    
    @classmethod
    def from_rgb(cls, r: int, g: int, b: int, a: int = 255) -> 'Color':
        """Create color from RGB values (0-255)"""
        return cls(r / 255, g / 255, b / 255, a / 255)
    
    @classmethod
    def from_hex(cls, hex_str: str) -> 'Color':
        """Create color from hex string (#RRGGBB or #RRGGBBAA)"""
        hex_str = hex_str.lstrip('#')
        if len(hex_str) == 6:
            r, g, b = int(hex_str[0:2], 16), int(hex_str[2:4], 16), int(hex_str[4:6], 16)
            return cls.from_rgb(r, g, b)
        elif len(hex_str) == 8:
            r, g, b, a = int(hex_str[0:2], 16), int(hex_str[2:4], 16), int(hex_str[4:6], 16), int(hex_str[6:8], 16)
            return cls.from_rgb(r, g, b, a)
        raise ValueError(f"Invalid hex color: {hex_str}")
    
    @classmethod
    def from_hsv(cls, h: float, s: float, v: float, a: float = 1.0) -> 'Color':
        """Create color from HSV values (0-1)"""
        r, g, b = colorsys.hsv_to_rgb(h, s, v)
        return cls(r, g, b, a)
    
    def to_tuple(self) -> Tuple[float, float, float, float]:
        """Convert to (r, g, b, a) tuple"""
        return (self.r, self.g, self.b, self.a)
    
    def to_rgb_tuple(self) -> Tuple[int, int, int, int]:
        """Convert to (r, g, b, a) tuple with 0-255 values"""
        return (
            int(self.r * 255),
            int(self.g * 255),
            int(self.b * 255),
            int(self.a * 255)
        )
    
    def to_hex(self) -> str:
        """Convert to hex string"""
        r, g, b, a = self.to_rgb_tuple()
        if a == 255:
            return f"#{r:02x}{g:02x}{b:02x}"
        return f"#{r:02x}{g:02x}{b:02x}{a:02x}"
    
    def blend(self, other: 'Color', factor: float) -> 'Color':
        """Blend this color with another"""
        factor = max(0.0, min(1.0, factor))
        return Color(
            self.r + (other.r - self.r) * factor,
            self.g + (other.g - self.g) * factor,
            self.b + (other.b - self.b) * factor,
            self.a + (other.a - self.a) * factor
        )
    
    def __repr__(self) -> str:
        return f"Color({self.r:.3f}, {self.g:.3f}, {self.b:.3f}, {self.a:.3f})"


class ColorPalette:
    """Predefined color palettes"""
    
    # Basic colors
    BLACK = Color(0, 0, 0)
    WHITE = Color(1, 1, 1)
    RED = Color(1, 0, 0)
    GREEN = Color(0, 1, 0)
    BLUE = Color(0, 0, 1)
    YELLOW = Color(1, 1, 0)
    CYAN = Color(0, 1, 1)
    MAGENTA = Color(1, 0, 1)
    
    # Grays
    GRAY_LIGHT = Color(0.75, 0.75, 0.75)
    GRAY = Color(0.5, 0.5, 0.5)
    GRAY_DARK = Color(0.25, 0.25, 0.25)
    
    # Material Design colors
    INDIGO = Color.from_hex("#3F51B5")
    PURPLE = Color.from_hex("#9C27B0")
    PINK = Color.from_hex("#E91E63")
    ORANGE = Color.from_hex("#FF9800")
    TEAL = Color.from_hex("#009688")
    
    # Transparent
    TRANSPARENT = Color(0, 0, 0, 0)
    
    @staticmethod
    def gradient(color1: Color, color2: Color, steps: int) -> list[Color]:
        """Generate a gradient between two colors"""
        return [color1.blend(color2, i / (steps - 1)) for i in range(steps)]
