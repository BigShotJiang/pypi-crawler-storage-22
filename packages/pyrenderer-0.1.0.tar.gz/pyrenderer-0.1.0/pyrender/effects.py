"""Visual effects for PyRender"""

from abc import ABC, abstractmethod
from .color import Color, ColorPalette


class Effect(ABC):
    """Base class for visual effects"""
    
    def __init__(self, enabled: bool = True):
        self.enabled = enabled
    
    @abstractmethod
    def apply(self, primitive, buffer):
        """Apply effect to a primitive"""
        pass


class ShadowEffect(Effect):
    """Shadow effect for primitives"""
    
    def __init__(self, offset_x: float = 2, offset_y: float = 2, 
                 blur_radius: float = 5, color: Color = None):
        super().__init__()
        self.offset_x = offset_x
        self.offset_y = offset_y
        self.blur_radius = blur_radius
        self.color = color or Color(0, 0, 0, 0.5)
    
    def apply(self, primitive, buffer):
        """Apply shadow effect"""
        pass  # Implemented in renderer


class BlurEffect(Effect):
    """Blur effect for primitives"""
    
    def __init__(self, radius: float = 5):
        super().__init__()
        self.radius = radius
    
    def apply(self, primitive, buffer):
        """Apply blur effect"""
        pass  # Implemented in renderer


class GlowEffect(Effect):
    """Glow effect for primitives"""
    
    def __init__(self, radius: float = 10, intensity: float = 1.0, 
                 color: Color = None):
        super().__init__()
        self.radius = radius
        self.intensity = intensity
        self.color = color or ColorPalette.WHITE
    
    def apply(self, primitive, buffer):
        """Apply glow effect"""
        pass  # Implemented in renderer


class OutlineEffect(Effect):
    """Outline effect for primitives"""
    
    def __init__(self, width: float = 2, color: Color = None):
        super().__init__()
        self.width = width
        self.color = color or ColorPalette.BLACK
    
    def apply(self, primitive, buffer):
        """Apply outline effect"""
        pass  # Implemented in renderer
