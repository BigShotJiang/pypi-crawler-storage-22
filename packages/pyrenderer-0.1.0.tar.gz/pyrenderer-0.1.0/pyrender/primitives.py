"""Rendering primitives for PyRender"""

from abc import ABC, abstractmethod
from typing import List, Tuple, Optional
from .color import Color, ColorPalette
from .transform import Transform


class Primitive(ABC):
    """Base class for all renderable primitives"""
    
    def __init__(self, transform: Transform = None, color: Color = None):
        self.transform = transform or Transform()
        self.color = color or ColorPalette.WHITE
        self.visible = True
        self.z_index = 0
    
    @abstractmethod
    def get_bounds(self) -> Tuple[float, float, float, float]:
        """Get bounding box (x_min, y_min, x_max, y_max)"""
        pass
    
    @abstractmethod
    def render_to_buffer(self, buffer: 'RenderBuffer'):
        """Render primitive to buffer"""
        pass


class Rectangle(Primitive):
    """Rectangular primitive"""
    
    def __init__(self, x: float, y: float, width: float, height: float,
                 color: Color = None, fill: bool = True, stroke_width: float = 1.0):
        super().__init__(Transform(x, y), color)
        self.width = width
        self.height = height
        self.fill = fill
        self.stroke_width = stroke_width
        self.corner_radius = 0.0
    
    def set_corner_radius(self, radius: float) -> 'Rectangle':
        """Set corner radius for rounded rectangles"""
        self.corner_radius = max(0, radius)
        return self
    
    def get_bounds(self) -> Tuple[float, float, float, float]:
        x, y = self.transform.x, self.transform.y
        w, h = self.width * self.transform.scale_x, self.height * self.transform.scale_y
        return (x, y, x + w, y + h)
    
    def render_to_buffer(self, buffer):
        """Render rectangle to buffer"""
        pass  # Implemented in renderer


class Circle(Primitive):
    """Circular primitive"""
    
    def __init__(self, x: float, y: float, radius: float, 
                 color: Color = None, fill: bool = True, stroke_width: float = 1.0):
        super().__init__(Transform(x, y), color)
        self.radius = radius
        self.fill = fill
        self.stroke_width = stroke_width
    
    def get_bounds(self) -> Tuple[float, float, float, float]:
        x, y = self.transform.x, self.transform.y
        r = self.radius * max(self.transform.scale_x, self.transform.scale_y)
        return (x - r, y - r, x + r, y + r)
    
    def render_to_buffer(self, buffer):
        """Render circle to buffer"""
        pass  # Implemented in renderer


class Line(Primitive):
    """Line primitive"""
    
    def __init__(self, x1: float, y1: float, x2: float, y2: float,
                 color: Color = None, width: float = 1.0):
        super().__init__(Transform(), color)
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2
        self.width = width
    
    def get_bounds(self) -> Tuple[float, float, float, float]:
        return (
            min(self.x1, self.x2),
            min(self.y1, self.y2),
            max(self.x1, self.x2),
            max(self.y1, self.y2)
        )
    
    def render_to_buffer(self, buffer):
        """Render line to buffer"""
        pass  # Implemented in renderer


class Polygon(Primitive):
    """Polygon primitive"""
    
    def __init__(self, points: List[Tuple[float, float]], 
                 color: Color = None, fill: bool = True, stroke_width: float = 1.0):
        super().__init__(Transform(), color)
        self.points = points
        self.fill = fill
        self.stroke_width = stroke_width
    
    def get_bounds(self) -> Tuple[float, float, float, float]:
        if not self.points:
            return (0, 0, 0, 0)
        xs = [p[0] for p in self.points]
        ys = [p[1] for p in self.points]
        return (min(xs), min(ys), max(xs), max(ys))
    
    def render_to_buffer(self, buffer):
        """Render polygon to buffer"""
        pass  # Implemented in renderer


class Text(Primitive):
    """Text primitive"""
    
    def __init__(self, x: float, y: float, text: str, 
                 color: Color = None, font_size: int = 16, font_family: str = "Arial"):
        super().__init__(Transform(x, y), color)
        self.text = text
        self.font_size = font_size
        self.font_family = font_family
        self.bold = False
        self.italic = False
    
    def set_bold(self, bold: bool = True) -> 'Text':
        """Set bold style"""
        self.bold = bold
        return self
    
    def set_italic(self, italic: bool = True) -> 'Text':
        """Set italic style"""
        self.italic = italic
        return self
    
    def get_bounds(self) -> Tuple[float, float, float, float]:
        # Approximate bounds based on font size
        width = len(self.text) * self.font_size * 0.6
        height = self.font_size * 1.2
        x, y = self.transform.x, self.transform.y
        return (x, y, x + width, y + height)
    
    def render_to_buffer(self, buffer):
        """Render text to buffer"""
        pass  # Implemented in renderer


class Gradient(Primitive):
    """Gradient primitive"""
    
    def __init__(self, x: float, y: float, width: float, height: float,
                 color_start: Color, color_end: Color, angle: float = 0):
        super().__init__(Transform(x, y), color_start)
        self.width = width
        self.height = height
        self.color_start = color_start
        self.color_end = color_end
        self.angle = angle  # Gradient angle in radians
    
    def get_bounds(self) -> Tuple[float, float, float, float]:
        x, y = self.transform.x, self.transform.y
        return (x, y, x + self.width, y + self.height)
    
    def render_to_buffer(self, buffer):
        """Render gradient to buffer"""
        pass  # Implemented in renderer


class Image(Primitive):
    """Image primitive"""
    
    def __init__(self, x: float, y: float, image_path: str = None, 
                 width: float = None, height: float = None):
        super().__init__(Transform(x, y), None)
        self.image_path = image_path
        self.width = width
        self.height = height
        self.opacity = 1.0
    
    def set_opacity(self, opacity: float) -> 'Image':
        """Set image opacity (0-1)"""
        self.opacity = max(0.0, min(1.0, opacity))
        return self
    
    def get_bounds(self) -> Tuple[float, float, float, float]:
        x, y = self.transform.x, self.transform.y
        w = self.width or 100
        h = self.height or 100
        return (x, y, x + w, y + h)
    
    def render_to_buffer(self, buffer):
        """Render image to buffer"""
        pass  # Implemented in renderer
