"""Core rendering engine for PyRender"""

from enum import Enum
from typing import Optional
import math

try:
    from PIL import Image, ImageDraw, ImageFont, ImageFilter
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

from .scene import Scene
from .camera import Camera
from .primitives import (
    Rectangle, Circle, Line, Polygon, Text, Gradient, Image as ImagePrimitive
)
from .color import Color


class RenderMode(Enum):
    """Rendering modes"""
    NORMAL = "normal"
    WIREFRAME = "wireframe"
    DEBUG = "debug"


class Renderer:
    """Main rendering engine"""
    
    def __init__(self, width: int, height: int, mode: RenderMode = RenderMode.NORMAL):
        """
        Initialize renderer.
        
        Args:
            width: Canvas width in pixels
            height: Canvas height in pixels
            mode: Rendering mode
        """
        if not PIL_AVAILABLE:
            raise ImportError("Pillow library is required. Install with: pip install Pillow")
        
        self.width = width
        self.height = height
        self.mode = mode
        self.camera = Camera(width, height)
        
        # Anti-aliasing settings
        self.antialiasing = True
        self.aa_scale = 2  # Supersampling factor
    
    def render(self, scene: Scene) -> Image.Image:
        """
        Render a scene to an image.
        
        Args:
            scene: Scene to render
            
        Returns:
            PIL Image object
        """
        # Create canvas with supersampling for antialiasing
        if self.antialiasing:
            canvas_width = self.width * self.aa_scale
            canvas_height = self.height * self.aa_scale
        else:
            canvas_width = self.width
            canvas_height = self.height
        
        # Create image and draw context
        bg_color = scene.background_color.to_rgb_tuple()[:3]
        image = Image.new('RGBA', (canvas_width, canvas_height), bg_color + (255,))
        draw = ImageDraw.Draw(image, 'RGBA')
        
        # Get sorted primitives
        primitives = scene.get_primitives_sorted()
        
        # Render each primitive
        for primitive in primitives:
            self._render_primitive(primitive, draw, image)
        
        # Downsample if antialiasing
        if self.antialiasing:
            image = image.resize((self.width, self.height), Image.LANCZOS)
        
        return image
    
    def _render_primitive(self, primitive, draw: ImageDraw.ImageDraw, image: Image.Image):
        """Render a single primitive"""
        scale = self.aa_scale if self.antialiasing else 1
        
        if isinstance(primitive, Rectangle):
            self._render_rectangle(primitive, draw, scale)
        elif isinstance(primitive, Circle):
            self._render_circle(primitive, draw, scale)
        elif isinstance(primitive, Line):
            self._render_line(primitive, draw, scale)
        elif isinstance(primitive, Polygon):
            self._render_polygon(primitive, draw, scale)
        elif isinstance(primitive, Text):
            self._render_text(primitive, draw, scale)
        elif isinstance(primitive, Gradient):
            self._render_gradient(primitive, draw, image, scale)
    
    def _render_rectangle(self, rect: Rectangle, draw: ImageDraw.ImageDraw, scale: float):
        """Render rectangle primitive"""
        x = rect.transform.x * scale
        y = rect.transform.y * scale
        w = rect.width * rect.transform.scale_x * scale
        h = rect.height * rect.transform.scale_y * scale
        
        bounds = [(x, y), (x + w, y + h)]
        color = rect.color.to_rgb_tuple()
        
        if rect.corner_radius > 0:
            # Rounded rectangle
            radius = rect.corner_radius * scale
            if rect.fill:
                draw.rounded_rectangle(bounds, radius=radius, fill=color)
            else:
                draw.rounded_rectangle(bounds, radius=radius, outline=color, 
                                      width=int(rect.stroke_width * scale))
        else:
            # Regular rectangle
            if rect.fill:
                draw.rectangle(bounds, fill=color)
            else:
                draw.rectangle(bounds, outline=color, width=int(rect.stroke_width * scale))
    
    def _render_circle(self, circle: Circle, draw: ImageDraw.ImageDraw, scale: float):
        """Render circle primitive"""
        x = circle.transform.x * scale
        y = circle.transform.y * scale
        r = circle.radius * max(circle.transform.scale_x, circle.transform.scale_y) * scale
        
        bounds = [(x - r, y - r), (x + r, y + r)]
        color = circle.color.to_rgb_tuple()
        
        if circle.fill:
            draw.ellipse(bounds, fill=color)
        else:
            draw.ellipse(bounds, outline=color, width=int(circle.stroke_width * scale))
    
    def _render_line(self, line: Line, draw: ImageDraw.ImageDraw, scale: float):
        """Render line primitive"""
        x1 = line.x1 * scale
        y1 = line.y1 * scale
        x2 = line.x2 * scale
        y2 = line.y2 * scale
        
        color = line.color.to_rgb_tuple()
        width = int(line.width * scale)
        
        draw.line([(x1, y1), (x2, y2)], fill=color, width=width)
    
    def _render_polygon(self, polygon: Polygon, draw: ImageDraw.ImageDraw, scale: float):
        """Render polygon primitive"""
        if not polygon.points:
            return
        
        points = [(x * scale, y * scale) for x, y in polygon.points]
        color = polygon.color.to_rgb_tuple()
        
        if polygon.fill:
            draw.polygon(points, fill=color)
        else:
            draw.polygon(points, outline=color, width=int(polygon.stroke_width * scale))
    
    def _render_text(self, text: Text, draw: ImageDraw.ImageDraw, scale: float):
        """Render text primitive"""
        x = text.transform.x * scale
        y = text.transform.y * scale
        font_size = int(text.font_size * scale)
        color = text.color.to_rgb_tuple()
        
        # Try to load font
        try:
            font = ImageFont.truetype(text.font_family, font_size)
        except:
            try:
                # Try default font
                font = ImageFont.load_default()
            except:
                font = None
        
        draw.text((x, y), text.text, fill=color, font=font)
    
    def _render_gradient(self, gradient: Gradient, draw: ImageDraw.ImageDraw, 
                        image: Image.Image, scale: float):
        """Render gradient primitive"""
        x = int(gradient.transform.x * scale)
        y = int(gradient.transform.y * scale)
        w = int(gradient.width * scale)
        h = int(gradient.height * scale)
        
        # Create gradient image
        grad_img = Image.new('RGBA', (w, h))
        
        # Generate gradient
        for i in range(w):
            factor = i / max(w - 1, 1)
            color = gradient.color_start.blend(gradient.color_end, factor)
            rgb = color.to_rgb_tuple()
            
            for j in range(h):
                grad_img.putpixel((i, j), rgb)
        
        # Rotate if needed
        if gradient.angle != 0:
            grad_img = grad_img.rotate(math.degrees(gradient.angle), expand=True)
        
        # Paste onto main image
        image.paste(grad_img, (x, y), grad_img)
    
    def save(self, scene: Scene, filename: str):
        """
        Render scene and save to file.
        
        Args:
            scene: Scene to render
            filename: Output filename
        """
        image = self.render(scene)
        image.save(filename)
        return image
    
    def set_antialiasing(self, enabled: bool, scale: int = 2) -> 'Renderer':
        """Enable/disable antialiasing"""
        self.antialiasing = enabled
        self.aa_scale = max(1, scale)
        return self
    
    def set_mode(self, mode: RenderMode) -> 'Renderer':
        """Set rendering mode"""
        self.mode = mode
        return self
    
    def __repr__(self) -> str:
        return f"Renderer({self.width}x{self.height}, mode={self.mode.value})"
