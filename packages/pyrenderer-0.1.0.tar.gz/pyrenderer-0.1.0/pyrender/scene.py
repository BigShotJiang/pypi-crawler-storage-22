"""Scene management for PyRender"""

from typing import List, Optional
from .primitives import Primitive
from .color import Color, ColorPalette


class Scene:
    """Container for renderable objects"""
    
    def __init__(self, background_color: Color = None):
        """
        Initialize scene.
        
        Args:
            background_color: Background color for the scene
        """
        self.primitives: List[Primitive] = []
        self.background_color = background_color or ColorPalette.WHITE
        self._next_id = 0
    
    def add(self, primitive: Primitive) -> Primitive:
        """Add a primitive to the scene"""
        self.primitives.append(primitive)
        return primitive
    
    def remove(self, primitive: Primitive) -> bool:
        """Remove a primitive from the scene"""
        if primitive in self.primitives:
            self.primitives.remove(primitive)
            return True
        return False
    
    def clear(self):
        """Remove all primitives from the scene"""
        self.primitives.clear()
    
    def get_primitives_sorted(self) -> List[Primitive]:
        """Get all primitives sorted by z-index"""
        return sorted(
            [p for p in self.primitives if p.visible],
            key=lambda p: p.z_index
        )
    
    def find_at_position(self, x: float, y: float) -> Optional[Primitive]:
        """Find the top-most primitive at given position"""
        sorted_primitives = self.get_primitives_sorted()
        
        # Search from top to bottom
        for primitive in reversed(sorted_primitives):
            x_min, y_min, x_max, y_max = primitive.get_bounds()
            if x_min <= x <= x_max and y_min <= y <= y_max:
                return primitive
        
        return None
    
    def get_bounds(self):
        """Get bounding box of all primitives in scene"""
        if not self.primitives:
            return (0, 0, 0, 0)
        
        bounds = [p.get_bounds() for p in self.primitives if p.visible]
        if not bounds:
            return (0, 0, 0, 0)
        
        x_mins = [b[0] for b in bounds]
        y_mins = [b[1] for b in bounds]
        x_maxs = [b[2] for b in bounds]
        y_maxs = [b[3] for b in bounds]
        
        return (min(x_mins), min(y_mins), max(x_maxs), max(y_maxs))
    
    def __len__(self) -> int:
        return len(self.primitives)
    
    def __repr__(self) -> str:
        return f"Scene(primitives={len(self.primitives)})"
