"""Transform and matrix utilities for PyRender"""

import math
from typing import Tuple


class Matrix3x3:
    """3x3 transformation matrix for 2D graphics"""
    
    def __init__(self, data: list[list[float]] = None):
        if data is None:
            self.data = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
        else:
            self.data = [row[:] for row in data]
    
    @staticmethod
    def identity() -> 'Matrix3x3':
        """Create identity matrix"""
        return Matrix3x3()
    
    @staticmethod
    def translation(x: float, y: float) -> 'Matrix3x3':
        """Create translation matrix"""
        return Matrix3x3([
            [1, 0, x],
            [0, 1, y],
            [0, 0, 1]
        ])
    
    @staticmethod
    def rotation(angle: float) -> 'Matrix3x3':
        """Create rotation matrix (angle in radians)"""
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        return Matrix3x3([
            [cos_a, -sin_a, 0],
            [sin_a, cos_a, 0],
            [0, 0, 1]
        ])
    
    @staticmethod
    def scale(sx: float, sy: float = None) -> 'Matrix3x3':
        """Create scale matrix"""
        if sy is None:
            sy = sx
        return Matrix3x3([
            [sx, 0, 0],
            [0, sy, 0],
            [0, 0, 1]
        ])
    
    def multiply(self, other: 'Matrix3x3') -> 'Matrix3x3':
        """Multiply this matrix with another"""
        result = [[0, 0, 0] for _ in range(3)]
        for i in range(3):
            for j in range(3):
                for k in range(3):
                    result[i][j] += self.data[i][k] * other.data[k][j]
        return Matrix3x3(result)
    
    def transform_point(self, x: float, y: float) -> Tuple[float, float]:
        """Transform a point using this matrix"""
        new_x = self.data[0][0] * x + self.data[0][1] * y + self.data[0][2]
        new_y = self.data[1][0] * x + self.data[1][1] * y + self.data[1][2]
        return (new_x, new_y)
    
    def __mul__(self, other: 'Matrix3x3') -> 'Matrix3x3':
        return self.multiply(other)


class Transform:
    """Represents a 2D transformation (position, rotation, scale)"""
    
    def __init__(self, x: float = 0, y: float = 0, rotation: float = 0, 
                 scale_x: float = 1, scale_y: float = 1):
        """
        Initialize a transform.
        
        Args:
            x: X position
            y: Y position
            rotation: Rotation in radians
            scale_x: X scale factor
            scale_y: Y scale factor
        """
        self.x = x
        self.y = y
        self.rotation = rotation
        self.scale_x = scale_x
        self.scale_y = scale_y
    
    def translate(self, dx: float, dy: float) -> 'Transform':
        """Translate the transform"""
        self.x += dx
        self.y += dy
        return self
    
    def rotate(self, angle: float) -> 'Transform':
        """Rotate the transform (angle in radians)"""
        self.rotation += angle
        return self
    
    def scale(self, sx: float, sy: float = None) -> 'Transform':
        """Scale the transform"""
        if sy is None:
            sy = sx
        self.scale_x *= sx
        self.scale_y *= sy
        return self
    
    def to_matrix(self) -> Matrix3x3:
        """Convert to transformation matrix"""
        # Order: Scale -> Rotate -> Translate
        mat_scale = Matrix3x3.scale(self.scale_x, self.scale_y)
        mat_rotate = Matrix3x3.rotation(self.rotation)
        mat_translate = Matrix3x3.translation(self.x, self.y)
        
        return mat_translate * mat_rotate * mat_scale
    
    def apply_to_point(self, x: float, y: float) -> Tuple[float, float]:
        """Apply this transform to a point"""
        return self.to_matrix().transform_point(x, y)
    
    def copy(self) -> 'Transform':
        """Create a copy of this transform"""
        return Transform(self.x, self.y, self.rotation, self.scale_x, self.scale_y)
    
    def __repr__(self) -> str:
        return f"Transform(x={self.x}, y={self.y}, rot={self.rotation:.2f}, scale=({self.scale_x}, {self.scale_y}))"
