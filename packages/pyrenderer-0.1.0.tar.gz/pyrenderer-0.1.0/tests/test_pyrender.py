"""Unit tests for PyRender"""

import pytest
import math
from pyrender import (
    Renderer, Scene, Rectangle, Circle, Line, Polygon, Text,
    Color, ColorPalette, Transform, Matrix3x3, Camera
)


class TestColor:
    """Tests for Color class"""
    
    def test_color_creation(self):
        color = Color(0.5, 0.5, 0.5, 1.0)
        assert color.r == 0.5
        assert color.g == 0.5
        assert color.b == 0.5
        assert color.a == 1.0
    
    def test_color_from_rgb(self):
        color = Color.from_rgb(255, 128, 0)
        assert color.r == 1.0
        assert abs(color.g - 0.502) < 0.01
        assert color.b == 0.0
    
    def test_color_from_hex(self):
        color = Color.from_hex("#FF8000")
        assert color.r == 1.0
        assert abs(color.g - 0.502) < 0.01
        assert color.b == 0.0
    
    def test_color_to_hex(self):
        color = Color(1.0, 0.5, 0.0)
        hex_str = color.to_hex()
        assert hex_str.startswith("#")
    
    def test_color_blend(self):
        red = Color(1, 0, 0)
        blue = Color(0, 0, 1)
        purple = red.blend(blue, 0.5)
        assert purple.r == 0.5
        assert purple.g == 0.0
        assert purple.b == 0.5


class TestTransform:
    """Tests for Transform class"""
    
    def test_transform_creation(self):
        transform = Transform(10, 20, math.pi / 4, 2.0, 3.0)
        assert transform.x == 10
        assert transform.y == 20
        assert transform.rotation == math.pi / 4
        assert transform.scale_x == 2.0
        assert transform.scale_y == 3.0
    
    def test_translate(self):
        transform = Transform(0, 0)
        transform.translate(10, 20)
        assert transform.x == 10
        assert transform.y == 20
    
    def test_rotate(self):
        transform = Transform()
        transform.rotate(math.pi / 2)
        assert abs(transform.rotation - math.pi / 2) < 0.001
    
    def test_scale(self):
        transform = Transform()
        transform.scale(2.0, 3.0)
        assert transform.scale_x == 2.0
        assert transform.scale_y == 3.0
    
    def test_copy(self):
        t1 = Transform(10, 20, 0.5, 2.0, 3.0)
        t2 = t1.copy()
        assert t2.x == t1.x
        assert t2.y == t1.y
        assert t2 is not t1


class TestMatrix3x3:
    """Tests for Matrix3x3 class"""
    
    def test_identity(self):
        mat = Matrix3x3.identity()
        x, y = mat.transform_point(5, 10)
        assert x == 5
        assert y == 10
    
    def test_translation(self):
        mat = Matrix3x3.translation(10, 20)
        x, y = mat.transform_point(0, 0)
        assert x == 10
        assert y == 20
    
    def test_scale(self):
        mat = Matrix3x3.scale(2, 3)
        x, y = mat.transform_point(5, 10)
        assert x == 10
        assert y == 30
    
    def test_rotation(self):
        mat = Matrix3x3.rotation(math.pi / 2)
        x, y = mat.transform_point(1, 0)
        assert abs(x) < 0.001
        assert abs(y - 1) < 0.001
    
    def test_multiply(self):
        mat1 = Matrix3x3.translation(10, 20)
        mat2 = Matrix3x3.scale(2, 2)
        mat3 = mat1.multiply(mat2)
        assert mat3 is not None


class TestPrimitives:
    """Tests for primitive shapes"""
    
    def test_rectangle_creation(self):
        rect = Rectangle(10, 20, 100, 50, color=ColorPalette.RED)
        assert rect.transform.x == 10
        assert rect.transform.y == 20
        assert rect.width == 100
        assert rect.height == 50
    
    def test_rectangle_bounds(self):
        rect = Rectangle(10, 20, 100, 50)
        bounds = rect.get_bounds()
        assert bounds == (10, 20, 110, 70)
    
    def test_circle_creation(self):
        circle = Circle(100, 100, 50, color=ColorPalette.BLUE)
        assert circle.transform.x == 100
        assert circle.transform.y == 100
        assert circle.radius == 50
    
    def test_circle_bounds(self):
        circle = Circle(100, 100, 50)
        bounds = circle.get_bounds()
        assert bounds == (50, 50, 150, 150)
    
    def test_line_creation(self):
        line = Line(0, 0, 100, 100, color=ColorPalette.BLACK)
        assert line.x1 == 0
        assert line.y1 == 0
        assert line.x2 == 100
        assert line.y2 == 100
    
    def test_polygon_creation(self):
        points = [(0, 0), (100, 0), (50, 100)]
        polygon = Polygon(points, color=ColorPalette.GREEN)
        assert len(polygon.points) == 3
    
    def test_text_creation(self):
        text = Text(10, 10, "Hello", color=ColorPalette.BLACK, font_size=16)
        assert text.text == "Hello"
        assert text.font_size == 16


class TestScene:
    """Tests for Scene class"""
    
    def test_scene_creation(self):
        scene = Scene(background_color=ColorPalette.WHITE)
        assert scene.background_color == ColorPalette.WHITE
        assert len(scene) == 0
    
    def test_add_primitive(self):
        scene = Scene()
        rect = Rectangle(0, 0, 100, 100)
        scene.add(rect)
        assert len(scene) == 1
    
    def test_remove_primitive(self):
        scene = Scene()
        rect = Rectangle(0, 0, 100, 100)
        scene.add(rect)
        result = scene.remove(rect)
        assert result is True
        assert len(scene) == 0
    
    def test_clear(self):
        scene = Scene()
        scene.add(Rectangle(0, 0, 100, 100))
        scene.add(Circle(50, 50, 25))
        scene.clear()
        assert len(scene) == 0
    
    def test_z_index_sorting(self):
        scene = Scene()
        rect1 = Rectangle(0, 0, 100, 100)
        rect1.z_index = 2
        rect2 = Rectangle(0, 0, 100, 100)
        rect2.z_index = 1
        scene.add(rect1)
        scene.add(rect2)
        
        sorted_prims = scene.get_primitives_sorted()
        assert sorted_prims[0].z_index == 1
        assert sorted_prims[1].z_index == 2


class TestCamera:
    """Tests for Camera class"""
    
    def test_camera_creation(self):
        camera = Camera(800, 600)
        assert camera.width == 800
        assert camera.height == 600
        assert camera.zoom == 1.0
    
    def test_camera_position(self):
        camera = Camera(800, 600)
        camera.set_position(100, 200)
        assert camera.transform.x == 100
        assert camera.transform.y == 200
    
    def test_camera_move(self):
        camera = Camera(800, 600)
        camera.move(50, 75)
        assert camera.transform.x == 50
        assert camera.transform.y == 75
    
    def test_camera_zoom(self):
        camera = Camera(800, 600)
        camera.set_zoom(2.0)
        assert camera.zoom == 2.0
        
        camera.zoom_in(2.0)
        assert camera.zoom == 4.0
        
        camera.zoom_out(2.0)
        assert camera.zoom == 2.0


class TestRenderer:
    """Tests for Renderer class"""
    
    def test_renderer_creation(self):
        renderer = Renderer(800, 600)
        assert renderer.width == 800
        assert renderer.height == 600
    
    def test_render(self):
        renderer = Renderer(400, 300)
        scene = Scene(background_color=ColorPalette.WHITE)
        scene.add(Rectangle(50, 50, 100, 100, color=ColorPalette.BLUE))
        
        image = renderer.render(scene)
        assert image is not None
        assert image.size == (400, 300)
    
    def test_antialiasing(self):
        renderer = Renderer(400, 300)
        renderer.set_antialiasing(True, scale=2)
        assert renderer.antialiasing is True
        assert renderer.aa_scale == 2


class TestColorPalette:
    """Tests for ColorPalette"""
    
    def test_basic_colors(self):
        assert ColorPalette.RED.r == 1.0
        assert ColorPalette.GREEN.g == 1.0
        assert ColorPalette.BLUE.b == 1.0
    
    def test_gradient(self):
        gradient = ColorPalette.gradient(ColorPalette.RED, ColorPalette.BLUE, 5)
        assert len(gradient) == 5
        assert gradient[0].r == 1.0
        assert gradient[-1].b == 1.0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
