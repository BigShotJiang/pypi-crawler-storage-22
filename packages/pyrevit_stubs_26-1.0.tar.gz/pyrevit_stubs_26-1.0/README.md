# pyrevit-stubs-26
_Typing & Autocomplete stubs for RevitAPI 2026 and pyRevit modules._

Prepared by Erik Frits from www.LearnRevitAPI.com

---

## Installation
Install like any other python package:
```bash
pip install pyrevit-stubs-26
```

💡 **Tip:** After installation give your IDE some time to index all new files.

---

## Usage:
You should see autocomplete suggestions while you type RevitAPI / pyRevit code.

For Example:
```py
from Autodesk.Revit.DB import *
collector = FilteredElementCollector(doc).OfClass(Wall).ToElements()
```

---

## Notes:
- Install only one pyrevit-stubs version at a time
- Stubs are for autocomplete & typing only 
- Code will be execute by pyRevit's engine NOT YOUR IDE! 

---

## Disclaimer

**This package provides unofficial type stubs for Autodesk Revit API and pyRevit modules.**
**Autodesk Revit is a trademark of Autodesk, Inc.**
**These stubs are independently created and are not affiliated with or endorsed by Autodesk.**

Dear Autodesk, don't sue me...
