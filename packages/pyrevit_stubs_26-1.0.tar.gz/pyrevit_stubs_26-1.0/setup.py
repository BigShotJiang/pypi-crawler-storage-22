from pathlib import Path
from setuptools import setup, find_packages

# Read README
this_dir = Path(__file__).parent
long_description = (this_dir / "README.md").read_text(encoding='utf-8')


setup(
    name='pyrevit-stubs-26',
    version='1.0',
    author ='Erik Frits',
    author_email='support@learnrevitapi.com',
    description='Autocomplete stubs for Revit API and pyRevit modules.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    packages=find_packages(where="stubs"),
    install_requires=[ ],
    package_dir={"": "stubs"},
    include_package_data=True,
    package_data={"": ["*.pyi", "py.typed"]},
    keywords= ['revit api', 'revitapi', 'pyrevit', 'revit-api']
)
