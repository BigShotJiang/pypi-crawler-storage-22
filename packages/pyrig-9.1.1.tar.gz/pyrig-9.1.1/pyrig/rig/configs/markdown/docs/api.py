"""Configuration management for docs/api.md files.

Manages docs/api.md with mkdocstrings directive (`:::`) to auto-generate API
documentation from Python docstrings (Google style, source links, inherited members).

See Also:
    mkdocstrings: https://mkdocstrings.github.io/
    pyrig.rig.configs.docs.mkdocs.MkdocsConfigFile
"""

from pathlib import Path

from pyrig.rig.configs.base.markdown import MarkdownConfigFile
from pyrig.rig.configs.pyproject import PyprojectConfigFile
from pyrig.rig.tools.docs_builder import DocsBuilder


class ApiConfigFile(MarkdownConfigFile):
    """API reference page configuration manager.

    Generates docs/api.md with mkdocstrings directive to auto-generate API
    documentation from Python docstrings. Content: "# API Reference" header
    and `::: project_name` directive.

    Examples:
        Generate docs/api.md::

            ApiConfigFile()

        Generated file::

            # API Reference

            ::: myproject

    See Also:
        pyrig.rig.configs.docs.mkdocs.MkdocsConfigFile
        pyrig.rig.configs.pyproject.PyprojectConfigFile
    """

    @classmethod
    def parent_path(cls) -> Path:
        """Get the parent directory for api.md.

        Returns:
            Path: docs directory.
        """
        return DocsBuilder.L.docs_dir()

    @classmethod
    def lines(cls) -> list[str]:
        """Get the api.md file content.

        Returns:
            List of lines with "# API Reference" and `::: project_name` directive.

        Note:
            Reads project name from pyproject.toml.
        """
        project_name = PyprojectConfigFile.L.project_name()
        return ["# API Reference", "", f"::: {project_name}"]
