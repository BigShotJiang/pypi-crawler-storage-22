"""Configuration for .scratch.py scratch file.

Generates .scratch.py at project root for local experimentation. Automatically
added to .gitignore (never committed).

See Also:
    pyrig.rig.configs.git.gitignore.GitignoreConfigFile
"""

from pathlib import Path

from pyrig.rig.configs.base.python import PythonConfigFile


class DotScratchConfigFile(PythonConfigFile):
    """Manages .scratch.py scratch file.

    Generates .scratch.py at project root for local experimentation. Automatically
    excluded from version control via .gitignore.

    Examples:
        Generate .scratch.py::

            DotScratchConfigFile.validate()

    Note:
        Automatically added to .gitignore by GitignoreConfigFile.

    See Also:
        pyrig.rig.configs.git.gitignore.GitignoreConfigFile
    """

    @classmethod
    def filename(cls) -> str:
        """Get the scratch filename.

        Returns:
            str: ".scratch" (extension .py added by parent class).
        """
        return ".scratch"

    @classmethod
    def parent_path(cls) -> Path:
        """Get the parent directory for .scratch.py.

        Returns:
            Path: Empty Path() (project root).
        """
        return Path()

    @classmethod
    def lines(cls) -> list[str]:
        """Get the .scratch.py file content.

        Returns:
            list[str]: Content lines for the scratch file.
        """
        return ['"""This file is for scratch work and is ignored by git."""']

    @classmethod
    def is_correct(cls) -> bool:
        """Check if the .scratch.py file is valid.

        Returns:
            bool: True if the file exists.
        """
        return cls.path().exists()
