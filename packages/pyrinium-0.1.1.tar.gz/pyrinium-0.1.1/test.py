import src.pyrinium.core as p

c = p.Pyrinium()
c.get_initial_data()
print(c.get_schedule("К0709-24/2"))
c.change_week(1)
print(c.get_schedule("К0709-24/2"))
c.change_week(1)
print(c.get_schedule("К0709-24/2"))
