from .Message import Message
from typing import TYPE_CHECKING


from pyromax.mixins.ReplyMixin import ReplyMixin

if TYPE_CHECKING:
    from ..api.MaxApi import MaxApi


class Update(Message, ReplyMixin):
    def __init__(self, update: dict, max_api: 'MaxApi'):
        if not update:
            return
        super().__init__(update['message'])
        self.max_api = max_api
        self.chat_id = update['chatId']
        self.mark = update['mark']
        self.unread = update['unread']


