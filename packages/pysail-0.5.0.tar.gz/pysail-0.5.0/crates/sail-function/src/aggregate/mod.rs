pub mod kurtosis;
pub mod max_min_by;
pub mod mode;
pub mod percentile_disc;
pub mod percentile_disc_groups;
pub mod skewness;
pub mod try_avg;
pub mod utils;
