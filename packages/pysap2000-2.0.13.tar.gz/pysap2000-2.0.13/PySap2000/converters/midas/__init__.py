# -*- coding: utf-8 -*-
"""
Midas Civil/Gen 导出模块

用于将 SAP2000 模型导出到 Midas Civil 或 Midas Gen
"""

# 待实现
__all__ = []
