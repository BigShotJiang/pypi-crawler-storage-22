# PyScratches

`PyScratches` is a lightweight utility library for Python that allows you to **repeat actions, wait for time intervals, and execute functions conditionally or repeatedly**. Ideal for simple scripts, quick tests, or basic automation.

## Main Functions

### `repeat(string, times)`

Prints a string multiple times.

**Parameters:**

- `string` (str): The text to print.
- `times` (int): The number of times to print the text.

**Example:**

```python
from pyextension import repeat

repeat("Hello", 3)
# Output:
# Hello
# Hello
# Hello
```

### `wait(seconds)`

Pauses the program execution for a given number of seconds.

Parameters:

seconds (float): Time to wait in seconds.

Example:

```python
from pyextension import wait


wait(2)  # Pauses for 2 seconds
print("Done!")
```

### `forever(func, delay=None)`

Executes a function indefinitely. Optionally, a delay can be added between each execution.

Parameters:

func (callable): The function to execute.

delay (float, optional): Seconds to wait between executions. Default is None.

Example:

```py
from pyextension import forever

def greet():
print("Hello")

forever(greet, delay=1) # Prints "Hello" every second
```

### `when(condition, func)`

Executes a function when a condition becomes True (continuously evaluated).

Parameters:

condition (callable → bool): Condition that is checked repeatedly until True.

func (callable): Function to execute when the condition is True.

Example:

```py
from pyextension import when

x = 0

def cond():
return x > 5

def action():
print("x is greater than 5!")

when(cond, action)
```

### `until(condition, func)`

Executes a function while a condition is True (stops when the condition becomes False).

Parameters:

condition (callable → bool): Condition that is checked continuously.

func (callable): Function to execute when the condition is False.

Example:

```py
from pyextension import until


x = 5


def cond():
    return x > 0


def action():
    print("x is still positive")


until(cond, action)
```

### PyExtension is very simple, but useful for scripts that need to repeat tasks, wait for intervals, or execute functions conditionally without relying on external libraries.
