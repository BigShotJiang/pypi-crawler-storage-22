def repeat(string, times):
    for i in range(times):
        print(string)
def wait(seconds):
    import time
    time.sleep(seconds)
def forever(func, delay=None):
    while True:
        func()
        if delay is not None:
            wait(delay)
def when(condition, func):
    while not condition():
        pass
    func()
def until(condition, func):
    while condition():
        pass
    func()