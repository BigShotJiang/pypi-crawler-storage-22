from pyscratches import repeat
repeat("Hello, World!", 3)