"""particle attribute sampling logic"""
