# PySentry - pip-audit Benchmark Report

**Generated:** 2026-02-01 01:38:29
**Duration:** 1m 33.27s
**Total Tests:** 20

## Executive Summary

**Overall Success Rate:** 100.0% (20/20 successful runs)

### Small_Requirements Dataset - Cold Cache
- **Fastest:** pysentry-pypi (0.281s) - 31.26x faster than slowest
- **Memory Efficient:** pysentry-pypi (11.31 MB) - 7.47x less memory than highest

### Small_Requirements Dataset - Hot Cache
- **Fastest:** pysentry-pypi (0.217s) - 36.85x faster than slowest
- **Memory Efficient:** pysentry-osv (10.48 MB) - 9.02x less memory than highest

### Large_Requirements Dataset - Cold Cache
- **Fastest:** pysentry-pypi (0.812s) - 19.32x faster than slowest
- **Memory Efficient:** pysentry-pypi (39.11 MB) - 3.03x less memory than highest

### Large_Requirements Dataset - Hot Cache
- **Fastest:** pysentry-pypi (0.687s) - 20.86x faster than slowest
- **Memory Efficient:** pysentry-pypi (7.97 MB) - 11.91x less memory than highest

## Test Environment

- **Platform:** Linux-6.11.0-1018-azure-x86_64-with-glibc2.39
- **Python Version:** 3.11.14
- **CPU Cores:** 4
- **Total Memory:** 15.62 GB
- **Available Memory:** 14.69 GB

## Performance Comparison

### Small_Requirements Dataset - Cold Cache

#### Execution Time Comparison

| Tool Configuration | Execution Time | Relative Performance |
|---------------------|---------------------|---------------------|
| 🥇 pysentry-pypi | 0.281s | 1.00x |
| 🥈 pysentry-osv | 0.560s | 1.99x |
|  pysentry-all-sources | 1.038s | 3.69x |
|  pysentry-pypa | 1.200s | 4.27x |
|  pip-audit-default | 8.791s | 31.26x |

#### Memory Usage Comparison

| Tool Configuration | Peak Memory | Relative Performance |
|---------------------|---------------------|---------------------|
| 🥇 pysentry-pypi | 11.31 MB | 1.00x |
| 🥈 pysentry-osv | 19.28 MB | 1.70x |
|  pip-audit-default | 45.65 MB | 4.04x |
|  pysentry-pypa | 66.60 MB | 5.89x |
|  pysentry-all-sources | 84.52 MB | 7.47x |

### Small_Requirements Dataset - Hot Cache

#### Execution Time Comparison

| Tool Configuration | Execution Time | Relative Performance |
|---------------------|---------------------|---------------------|
| 🥇 pysentry-pypi | 0.217s | 1.00x |
| 🥈 pysentry-osv | 0.436s | 2.01x |
|  pysentry-pypa | 0.686s | 3.16x |
|  pysentry-all-sources | 0.835s | 3.85x |
|  pip-audit-default | 7.995s | 36.85x |

#### Memory Usage Comparison

| Tool Configuration | Peak Memory | Relative Performance |
|---------------------|---------------------|---------------------|
| 🥇 pysentry-osv | 10.48 MB | 1.00x |
| 🥈 pysentry-pypi | 11.99 MB | 1.14x |
|  pip-audit-default | 44.41 MB | 4.24x |
|  pysentry-pypa | 47.40 MB | 4.52x |
|  pysentry-all-sources | 94.52 MB | 9.02x |

### Large_Requirements Dataset - Cold Cache

#### Execution Time Comparison

| Tool Configuration | Execution Time | Relative Performance |
|---------------------|---------------------|---------------------|
| 🥇 pysentry-pypi | 0.812s | 1.00x |
| 🥈 pysentry-osv | 1.065s | 1.31x |
|  pysentry-all-sources | 1.376s | 1.69x |
|  pysentry-pypa | 1.391s | 1.71x |
|  pip-audit-default | 15.699s | 19.32x |

#### Memory Usage Comparison

| Tool Configuration | Peak Memory | Relative Performance |
|---------------------|---------------------|---------------------|
| 🥇 pysentry-pypi | 39.11 MB | 1.00x |
| 🥈 pysentry-osv | 40.73 MB | 1.04x |
|  pip-audit-default | 47.57 MB | 1.22x |
|  pysentry-pypa | 88.57 MB | 2.26x |
|  pysentry-all-sources | 118.45 MB | 3.03x |

### Large_Requirements Dataset - Hot Cache

#### Execution Time Comparison

| Tool Configuration | Execution Time | Relative Performance |
|---------------------|---------------------|---------------------|
| 🥇 pysentry-pypi | 0.687s | 1.00x |
| 🥈 pysentry-osv | 1.041s | 1.51x |
|  pysentry-all-sources | 1.223s | 1.78x |
|  pysentry-pypa | 1.418s | 2.06x |
|  pip-audit-default | 14.340s | 20.86x |

#### Memory Usage Comparison

| Tool Configuration | Peak Memory | Relative Performance |
|---------------------|---------------------|---------------------|
| 🥇 pysentry-pypi | 7.97 MB | 1.00x |
| 🥈 pysentry-osv | 11.75 MB | 1.47x |
|  pip-audit-default | 47.49 MB | 5.96x |
|  pysentry-pypa | 61.80 MB | 7.75x |
|  pysentry-all-sources | 94.99 MB | 11.91x |

## Detailed Analysis

### Pysentry Performance

- **Execution Time:** Avg: 0.892s, Min: 0.217s, Max: 1.418s

- **Memory Usage:** Avg: 50.59 MB, Min: 7.97 MB, Max: 118.45 MB

- **Success Rate:** 100.0% (16/16)

### Pip-Audit Performance

- **Execution Time:** Avg: 11.706s, Min: 7.995s, Max: 15.699s

- **Memory Usage:** Avg: 46.28 MB, Min: 44.41 MB, Max: 47.57 MB

- **Success Rate:** 100.0% (4/4)