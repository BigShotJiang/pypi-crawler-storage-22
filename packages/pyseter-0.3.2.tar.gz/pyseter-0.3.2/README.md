# Pyseter

Pyseter is an open-source Python package for automating photo-identification. Pyseter includes functions for:

- Extracting feature vectors from images with the [AnyDorsal](https://besjournals.onlinelibrary.wiley.com/doi/10.1111/2041-210X.14167) algorithm 
- Clustering images by a proposed ID
- Sorting images into directories by proposed ID then encounter
- Grading images by distinctiveness (experimental)
- Identifying individuals using a reference set
- Evaluating photo-ID algorithms

## Introduction 

Please see the [Getting Started](getting-started.qmd) page for a demonstration of the basic functionality of Pyseter using an example of spinner dolphins.

## Installation

Users can install Pyseter with pip, uv, or pixi. For example, 

```bash
pip install pyseter
```

We imagine that most Pyseter users will be more familiar with R than Python. If this is you, please see the [R users who are new to Python](install-r.qmd) page for detailed instructions on the steps needed to work with Pyseter. 