# Pypack Demo

This is a demo application to showcase the pypack workflow packaging tool.

## Installation

Ensure pypack is installed:

```bash
cd sfi/pypack
pip install -e .
```

## Usage

### Basic Build

```bash
cd sfi/examples/pack_demo
pypack build
```

This will:

1. Parse the `pyproject.toml` file
2. Pack the source code
3. Install Python runtime
4. Generate a console loader
5. Assemble the final package

### Advanced Build Options

```bash
# Build with GUI loader
pypack build --loader-type gui

# Build with specific Python version
pypack build --python-version 3.11.5

# Skip loader generation (faster for development)
pypack build --no-loader

# Build with verbose logging
pypack build --debug
```

## Output

After successful build, the output will be in `dist/package/`:

```
dist/package/
├── src/              # Packed source code
├── runtime/          # Python runtime
├── main.exe          # Generated loader
└── metadata.json     # Package metadata
```

## Running the Packaged Application

Run the generated loader:

```bash
cd dist/package
./main.exe
```

## Workflow Stages

The packaging process executes the following stages:

1. **Parse Project**: Extract project information from `pyproject.toml`
2. **Pack Source & Install Python**: Parallel execution of source packing and Python installation
3. **Generate Loader**: Create cross-platform loader executable
4. **Assemble Package**: Combine all components into final package

Each stage can run independently or in parallel based on dependencies, maximizing efficiency.
