"""Alarm clock module for pysfi."""

from __future__ import annotations
