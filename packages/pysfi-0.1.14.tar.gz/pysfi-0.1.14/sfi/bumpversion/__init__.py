"""Bumpversion - Automated version number management tool."""

from __future__ import annotations

__version__ = "0.1.14"
