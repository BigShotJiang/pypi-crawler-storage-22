from __future__ import annotations

import argparse

from sfi import __version__ as VERSION


def main() -> None:
    """Main entry point for the pysfi CLI tool.

    Parses command line arguments and handles version printing.

    This is the central entry point for all pysfi subcommands.
    Currently supports:
    - Version information display

    Future enhancements will include routing to specific
    module commands based on subcommands.
    """
    parser = argparse.ArgumentParser(
        prog="pysfi",
        description="Python Single File Interactive - A collection of Python utility tools",
        epilog="Use 'pysfi <command> --help' for more information on a specific command",
    )
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"%(prog)s v{VERSION}",
        help="Print version and exit",
    )
    parser.parse_args()
