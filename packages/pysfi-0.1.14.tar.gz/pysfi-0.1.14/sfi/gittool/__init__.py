"""Git tool module.
"""
