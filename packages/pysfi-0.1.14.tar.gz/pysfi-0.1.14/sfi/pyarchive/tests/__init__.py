"""Tests for pyarchive module."""
