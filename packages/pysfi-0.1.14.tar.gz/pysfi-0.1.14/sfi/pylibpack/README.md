# pylibpack

Python library packer with caching support for packaging project dependencies.

## Features

- Parse dependencies from `requirements.txt` or `pyproject.toml`
- Download dependencies to local cache (`.cache/pylibpack`)
- Pack dependencies into distributable archives (zip, tar, gztar, bztar, xztar)
- Prioritize local cache for subsequent pack operations
- Concurrent downloading for improved performance
- Automatic package index generation

## Installation

```bash
uv add pylibpack
```

or

```bash
pip install pylibpack
```

## Usage

### Command Line

```bash
# Pack dependencies
pylibpack pack -d /path/to/project -o /path/to/output

# Pack with custom cache directory
pylibpack pack --cache-dir /custom/cache -d /path/to/project

# Pack with custom format
pylibpack pack --format gztar -d /path/to/project

# Clear cache
pylibpack cache-clear

# Show version
pylibpack version
```

### Python API

```python
from pathlib import Path
from sfi.pylibpack.pylibpack import PyLibPack

# Initialize packer
packer = PyLibPack(cache_dir=None, python_version="3.8.10")

# Pack dependencies
result = packer.pack(
    project_dir=Path("./my_project"),
    output_dir=Path("./dist"),
    max_workers=4,
    archive_format="zip",
    include_index=True,
)

print(f"Packed {result['successful']}/{result['total']} packages")
```

### As Part of pypack

```bash
# Use pypack with library packing enabled
pypack build --pack-libs --cache-dir /custom/cache --archive-format zip
```

## Cache Structure

```
~/.pysfi/.cache/pylibpack/
├── metadata.json          # Cache metadata
└── {package_name}/
    ├── package/            # Package files (if directory)
    └── {filename}.whl      # Wheel file (if wheel)
```

## Output Structure

```
output_dir/
├── packages/              # Downloaded package files
├── packages_index.json    # Package index
└── dependencies_{os}.{format}  # Packaged archive
```

## Requirements

- Python >= 3.8
- `toml` >= 0.10.2
- `packaging` >= 21.0

## License

MIT License
