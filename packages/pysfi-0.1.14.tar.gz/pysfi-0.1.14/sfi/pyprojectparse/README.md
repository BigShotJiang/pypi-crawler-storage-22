# pyprojectparse

A Python module for parsing `pyproject.toml` files and extracting project metadata.

## Overview

The `pyprojectparse` module provides tools to analyze Python projects by parsing their `pyproject.toml` files. It offers a structured way to extract and work with project metadata, dependencies, and configuration settings.

## Features

- **Project Analysis**: Parse and extract metadata from `pyproject.toml` files
- **Multi-Project Support**: Scan directories recursively to find and analyze multiple projects
- **Caching**: Automatically cache parsed data to `projects.json` for faster subsequent loads
- **Dependency Analysis**: Extract and normalize dependency information
- **Framework Detection**: Identify GUI frameworks (Qt-based libraries like PySide, PyQt)
- **Flexible Loading**: Support loading from TOML files, JSON files, or directory scanning

## Classes

### Project

Represents a single Python project with its metadata and dependencies. Key features:

- Contains all project information from `pyproject.toml`
- Provides utility properties like `dep_names`, `has_qt`, `is_gui`, etc.
- Normalizes project names and extracts dependency information
- Supports serialization to/from dictionaries for JSON storage

### Solution

Manages a collection of Project instances found in a directory tree. Key features:

- Scans directories recursively for `pyproject.toml` files
- Parses multiple projects into a unified interface
- Handles caching to `projects.json` files
- Provides methods for loading from various sources

## Usage

### Command Line Interface

```bash
# Parse projects in current directory
python -m sfi.pyprojectparse.py

# Parse projects in specific directory
python -m sfi.pyprojectparse.py /path/to/directory

# Force update (skip cache)
python -m sfi.pyprojectparse.py --update /path/to/directory

# Enable debug mode
python -m sfi.pyprojectparse.py --debug
```

### Programmatic Usage

```python
from sfi.pyprojectparse.pyprojectparse import Solution

# Parse all projects in a directory
solution = Solution.from_directory('/path/to/projects')

# Access individual projects
for project_name, project in solution.projects.items():
    print(f"Project: {project.name}")
    print(f"Version: {project.version}")
    print(f"Dependencies: {project.dependencies}")
    print(f"Has Qt: {project.has_qt}")
```

## Properties

### Project Properties

- `normalized_name`: Project name with hyphens replaced by underscores
- `dep_names`: Set of normalized dependency names
- `has_qt`: Boolean indicating if project uses Qt-based libraries
- `qt_libname`: Name of Qt library used (if any)
- `is_gui`: Boolean indicating if project is a GUI application
- `loader_type`: Either "gui" or "console" based on project type

### Solution Properties

- `json_file`: Path to the cache file (`projects.json`)
- `projects`: Dictionary mapping project names to Project instances

## Installation

This module is part of the `pysfi` package:

```bash
pip install pysfi
```

Or install directly from the source:

```bash
pip install -e .
```

## License

MIT License
