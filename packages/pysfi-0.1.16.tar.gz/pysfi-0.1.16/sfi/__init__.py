"""Single File commands for Interactive python.

pysfi (Python Single File Interactive) is a collection of Python utility
tools designed to streamline development workflows and enhance productivity.

This package provides:
- Document processing utilities (docscan, docdiff, pdfsplit, img2pdf)
- Development tools (makepython, bumpversion, cleanbuild)
- System management utilities (filedate, taskkill, gittool)
- AI/LLM tools (llmclient, llmserver, llmquantize)
- And many more specialized utilities

Each module can be used independently as a command-line tool
or imported as a Python library.
"""

from __future__ import annotations

__version__ = "0.1.16"
__all__ = ["__version__"]
