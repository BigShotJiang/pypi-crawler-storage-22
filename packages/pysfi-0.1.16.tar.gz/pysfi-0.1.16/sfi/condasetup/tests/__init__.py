"""Tests for condasetup module."""
