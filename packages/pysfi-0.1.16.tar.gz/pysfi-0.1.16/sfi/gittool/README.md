# Git Tool

A command-line wrapper for common Git operations with simplified syntax and enhanced functionality.

## Features

- **Simplified commands**: Short, memorable command names for common Git operations
- **Batch operations**: Perform multiple Git actions with single commands
- **Safety checks**: Built-in validation to prevent common mistakes
- **Cross-platform**: Works on Windows, Linux, and macOS
- **Enhanced workflows**: Streamlined operations for typical development workflows

## Available Commands

| Command | Description              | Equivalent Git Command                                    |
| ------- | ------------------------ | --------------------------------------------------------- |
| `i`     | Initialize repository    | `git init && git add . && git commit -m "initial commit"` |
| `a`     | Stage and commit changes | `git add . && git commit`                                 |
| `c`     | Clean untracked files    | `git clean -xd`                                           |
| `p`     | Push to remote           | `git push`                                                |
| `pl`    | Pull from remote         | `git pull`                                                |
| `co`    | Checkout branch          | `git checkout`                                            |
| `b`     | List/manage branches     | `git branch`                                              |

## Installation

Install the package in development mode:

```bash
pip install -e .
```

## Usage

### Repository Initialization

Initialize a new Git repository with initial commit:

```bash
gittool i
```

### Staging and Committing

Stage all changes and commit them:

```bash
gittool a
```

### Cleaning

Remove untracked files and directories:

```bash
gittool c
```

Force clean (without confirmation):

```bash
gittool c -f
```

### Push Operations

Push current branch:

```bash
gittool p
```

Push all branches:

```bash
gittool p --all
```

### Pull Operations

Pull from remote:

```bash
gittool pl
```

Pull with rebase:

```bash
gittool pl --rebase
```

### Branch Management

Checkout existing branch:

```bash
gittool co main
```

Create and checkout new branch:

```bash
gittool co feature/new-feature -b
```

List local branches:

```bash
gittool b
```

List all branches (local and remote):

```bash
gittool b --all
```

Delete branch:

```bash
gittool b --delete feature/old-feature
```

## Command Line Options

### Global Options
- `-h, --help`: Show help message

### Clean Command (`c`)
- `-f, --force`: Force clean without confirmation

### Push Command (`p`)
- `--all, -a`: Push all branches

### Pull Command (`pl`)
- `--rebase, -r`: Pull with rebase instead of merge

### Checkout Command (`co`)
- `-b, --create`: Create new branch

### Branch Command (`b`)
- `-a, --all`: List all branches
- `-d, --delete BRANCH`: Delete specified branch

## Safety Features

### Uncommitted Changes Check

Before certain operations, the tool checks for uncommitted changes:

```bash
gittool i  # Will warn if there are uncommitted changes
```

### Protected Directories

The clean command automatically excludes:
- `.venv` (virtual environments)
- `node_modules` (Node.js dependencies)
- `.git` (Git metadata)
- `.idea` (IntelliJ IDEA)
- `.vscode` (VS Code)

## Examples

### Typical Workflow

```bash
# 1. Initialize repository
gittool i

# 2. Make changes and commit
gittool a

# 3. Push to remote
gittool p

# 4. Create feature branch
gittool co feature/new-feature -b

# 5. Work on feature...
# 6. Commit feature changes
gittool a

# 7. Push feature branch
gittool p

# 8. Return to main and pull latest changes
gittool co main
gittool pl

# 9. Clean up temporary files
gittool c
```

### Batch Operations

```bash
# Clean workspace and reset to last commit
gittool c -f && gittool pl
```

## Error Handling

The tool provides clear error messages for common issues:

- **Git not found**: "Git is not installed or not in PATH"
- **Repository not initialized**: "Not a git repository"
- **Uncommitted changes**: "Uncommitted changes exist, please commit changes first"
- **Network issues**: Standard Git network error messages

## Dependencies

- Python 3.7+
- Git (must be installed and in PATH)
- Standard library modules: subprocess, argparse, logging

## Troubleshooting

### Git Not Found

Ensure Git is installed and accessible:

```bash
git --version
```

### Permission Denied

Some operations may require appropriate permissions:

```bash
# On Unix-like systems
chmod +x your_script.py
```

### Network Issues

For push/pull operations, ensure:
- Remote repository exists
- Proper authentication configured
- Network connectivity

## Development

### Adding New Commands

To add new commands:

1. Create a new dataclass inheriting from the command pattern
2. Add the command to `_COMMAND_MAP`
3. Update argument parsing in `parse_args()`
4. Add tests for the new functionality

### Running Tests

```bash
python -m pytest tests/ -v
```

## Best Practices

1. **Always check status** before major operations
2. **Backup important changes** before cleaning
3. **Use descriptive commit messages** when staging changes
4. **Verify remote connections** before push operations
5. **Test branch operations** in a safe environment first

## License

MIT License