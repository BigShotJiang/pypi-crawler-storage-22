"""Tests for gittool module."""
