"""Which module - Find executable paths for commands cross-platform."""

from __future__ import annotations

from .which import find_executable, main

__all__ = ["find_executable", "main"]
