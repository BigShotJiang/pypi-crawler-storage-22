"""Main entry point for the which module."""

from __future__ import annotations

from .which import main

if __name__ == "__main__":
    main()
