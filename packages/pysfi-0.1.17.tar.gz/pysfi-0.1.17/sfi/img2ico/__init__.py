"""Image to ICO conversion module.

This module provides functionality to convert various image formats to ICO files.
Includes both command-line and GUI interfaces.
"""

from __future__ import annotations

from sfi.img2ico.img2ico import (
    ImageToIcoConfig,
    ImageToIcoRunner,
    is_valid_image,
    main,
    parse_sizes,
)

__all__ = [
    "ImageToIcoConfig",
    "ImageToIcoRunner",
    "is_valid_image",
    "main",
    "parse_sizes",
]
