"""Main entry point for LSCSIM application."""

from __future__ import annotations

import sys

from PySide2.QtWidgets import QApplication

from sfi.lscsim.core.application_controller import (
    ApplicationController as MainController,
)
from sfi.lscsim.utils.logger import logger
from sfi.lscsim.views.main_window import MainWindow


def main() -> None:
    """Main application entry point."""
    logger.info("Starting LSCSIM application")

    # Create Qt application
    app = QApplication(sys.argv)
    app.setApplicationName("LSCSIM")
    app.setApplicationVersion("0.1.0")

    try:
        # Create main controller
        controller = MainController()

        # Create main window
        window = MainWindow(controller)
        window.show()

        logger.info("Application started successfully")

        # Run application
        sys.exit(app.exec_())

    except Exception as e:
        logger.error(f"Failed to start application: {e}")
        print(f"Error starting application: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
