"""Music player module for pysfi project."""
