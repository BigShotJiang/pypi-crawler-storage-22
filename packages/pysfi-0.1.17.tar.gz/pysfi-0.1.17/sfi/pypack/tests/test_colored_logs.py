#!/usr/bin/env python3
"""
Test for colored log display functionality in pypack GUI.
"""

import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(project_root))

import pytest
from PySide2.QtWidgets import QApplication

from sfi.pypack.pypack_gui import LogDisplayWidget


class TestColoredLogDisplay:
    """Test colored log display functionality."""

    @pytest.fixture(scope="class")
    def app(self):
        """Create QApplication instance."""
        app = QApplication.instance()
        if app is None:
            app = QApplication([])
        return app

    def test_log_color_detection(self, app):
        """Test that log color detection works correctly."""
        log_widget = LogDisplayWidget()

        # Test error colors
        assert log_widget._get_log_color("ERROR: Something went wrong") == "#ef4444"
        assert log_widget._get_log_color("Failed to build project") == "#ef4444"
        assert log_widget._get_log_color("Exception occurred") == "#ef4444"

        # Test warning colors
        assert log_widget._get_log_color("WARNING: Deprecated feature") == "#f59e0b"
        assert log_widget._get_log_color("Caution: Low disk space") == "#f59e0b"

        # Test success colors
        assert log_widget._get_log_color("✓ Build completed successfully!") == "#10b981"
        assert log_widget._get_log_color("SUCCESS: Operation finished") == "#10b981"
        assert log_widget._get_log_color("Completed packaging process") == "#10b981"

        # Test info colors
        assert log_widget._get_log_color("INFO: Starting build process") == "#3b82f6"
        assert log_widget._get_log_color("Processing dependencies...") == "#3b82f6"

        # Test debug colors
        assert log_widget._get_log_color("DEBUG: Verbose output enabled") == "#8b5cf6"
        assert log_widget._get_log_color("Detailed analysis complete") == "#8b5cf6"

        # Test default color
        assert log_widget._get_log_color("Regular log message") == "#94a3b8"
        assert log_widget._get_log_color("Some random text") == "#94a3b8"

    def test_colored_log_append(self, app):
        """Test that colored log appending works correctly."""
        log_widget = LogDisplayWidget()

        # Test appending different types of messages
        test_messages = [
            "ERROR: Build failed",
            "WARNING: Missing dependencies",
            "✓ Build completed successfully!",
            "INFO: Starting packaging workflow",
            "DEBUG: Detailed processing info",
            "Regular status message",
        ]

        # Append all messages
        for message in test_messages:
            log_widget.append_log(message)

        # Check that content was added (check all relevant tabs)
        # ERROR messages go to error_text
        error_content = log_widget.error_text.toHtml()
        assert "ERROR: Build failed" in error_content

        # WARNING messages go to warning_text
        warning_content = log_widget.warning_text.toHtml()
        assert "WARNING: Missing dependencies" in warning_content

        # SUCCESS/INFO/DEBUG/regular messages go to info_text
        info_content = log_widget.info_text.toHtml()
        assert "✓ Build completed successfully!" in info_content

        # Check that HTML color formatting is present (check each tab separately)
        assert "color:#ef4444" in error_content.replace(" ", "")  # Error color
        assert "color:#f59e0b" in warning_content.replace(" ", "")  # Warning color
        assert "color:#10b981" in info_content.replace(" ", "")  # Success color

    def test_case_insensitive_detection(self, app):
        """Test that color detection is case insensitive."""
        log_widget = LogDisplayWidget()

        # Test with different cases
        assert log_widget._get_log_color("error: lowercase") == "#ef4444"
        assert log_widget._get_log_color("ERROR: uppercase") == "#ef4444"
        assert log_widget._get_log_color("Error: mixed case") == "#ef4444"

        assert log_widget._get_log_color("success message") == "#10b981"
        assert log_widget._get_log_color("SUCCESS MESSAGE") == "#10b981"
        assert log_widget._get_log_color("Success Message") == "#10b981"

    def test_partial_keyword_matching(self, app):
        """Test that partial keyword matching works."""
        log_widget = LogDisplayWidget()

        # Should match because keywords are contained in the text
        assert log_widget._get_log_color("Operation failed miserably") == "#ef4444"
        assert log_widget._get_log_color("Warning signs detected") == "#f59e0b"
        assert log_widget._get_log_color("Process completed successfully") == "#10b981"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
