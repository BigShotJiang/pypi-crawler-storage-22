#!/usr/bin/env python3
"""
Test for pypack GUI archive settings simplification.
"""

import sys
from pathlib import Path

import pytest
from PySide2.QtWidgets import QApplication

from sfi.pypack.pypack_gui import PypackGUI

# Add project root to path
project_root = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(project_root))


class TestPypackGUIArchive:
    """Test pypack GUI archive settings."""

    @pytest.fixture(scope="class")
    def app(self):
        """Create QApplication instance."""
        app = QApplication.instance()
        if app is None:
            app = QApplication([])
        return app

    def test_gui_creation_without_groupbox(self, app):
        """Test that GUI creates successfully without GroupBox for archive settings."""
        # Create GUI instance
        gui = PypackGUI()

        # Check that there's no archive group box in main GUI (settings moved to dialog)
        # The key point is that archive settings are now in SettingsDialog
        assert not hasattr(gui, "final_archive_combo"), (
            "Archive settings should be in SettingsDialog, not main GUI"
        )

        # Test that SettingsDialog can be created and has the archive combo
        from sfi.pypack.pypack_gui import SettingsDialog

        settings_dialog = SettingsDialog(gui, gui.config_manager)

        # Check that final archive combo box exists in SettingsDialog
        assert hasattr(settings_dialog, "archive_type_combo"), (
            "Archive type combo should exist in SettingsDialog"
        )

        # Check that it has the expected options
        expected_options = [
            "(不创建)",
            "zip",
            "tar",
            "gztar",
            "bztar",
            "xztar",
            "7z",
            "nsis",
        ]
        actual_options = [
            settings_dialog.archive_type_combo.itemText(i)
            for i in range(settings_dialog.archive_type_combo.count())
        ]
        assert actual_options == expected_options, (
            f"Expected {expected_options}, got {actual_options}"
        )

        # Clean up
        settings_dialog.close()
        gui.close()

    def test_archive_section_structure(self, app):
        """Test that archive section is properly integrated into SettingsDialog."""
        gui = PypackGUI()
        from sfi.pypack.pypack_gui import SettingsDialog

        settings_dialog = SettingsDialog(gui, gui.config_manager)

        # Verify the combo box exists and has items
        # Note: Height validation is skipped as it's 0 before showing dialog
        assert settings_dialog.archive_type_combo.count() > 0, (
            "Combo box should have items"
        )
        # Note: SettingsDialog uses archive_type_combo, not final_archive_combo

        # Check that current index is valid (0-7)
        current_index = settings_dialog.archive_type_combo.currentIndex()
        assert 0 <= current_index <= 7, (
            f"Current index {current_index} should be between 0 and 7"
        )

        # Clean up
        settings_dialog.close()
        gui.close()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
