# Qt Styles - Professional Qt StyleSheet Themes

A collection of professional, production-ready Qt stylesheet themes for creating beautiful and consistent desktop applications.

## Features

- 🎨 **Beautiful Themes**: Professionally designed color schemes and layouts
- 🔧 **Easy Integration**: Simple API for applying themes to Qt applications
- 🌐 **Cross-Platform**: Consistent styling across Windows, macOS, and Linux
- ♿ **Accessible**: Proper color contrast ratios and readable typography
- 📱 **Responsive**: Interactive hover and active states for all components
- 🎯 **Comprehensive**: Covers all major Qt widgets and components

## Installation

```bash
# Install as part of the SFI toolkit
cd sfi/qtstyles
pip install -e .
```

## Quick Start

### Basic Usage

```python
from PySide2.QtWidgets import QApplication, QPushButton
from sfi.qtstyles import ModernBlueTheme

app = QApplication([])

# Apply theme to entire application
app.setStyleSheet(ModernBlueTheme.get_stylesheet())

# Create your widgets
button = QPushButton("Click Me")
button.show()

app.exec_()
```

### Alternative Methods

```python
from sfi.qtstyles import apply_theme, ModernBlueTheme

# Method 1: Apply to QApplication
apply_theme(app)

# Method 2: Apply to specific widget
apply_theme(my_widget)

# Method 3: Get stylesheet string manually
stylesheet = ModernBlueTheme.get_stylesheet()
widget.setStyleSheet(stylesheet)
```

## Available Themes

### Modern Blue Theme

A clean, professional blue-themed design inspired by modern UI principles.

**Key Features:**
- Professional blue color palette
- Clean card-based layouts
- Smooth gradient backgrounds
- Consistent rounded corners
- Intuitive interactive states

**Color Palette:**
- Primary Blue: `#3b82f6`
- Secondary Blue: `#2563eb`
- Background: `#f8fafc`
- Text: `#0f172a`

## Theme Components

The themes provide styling for all major Qt components:

### Containers & Layouts
- QMainWindow, QDialog
- QGroupBox with gradient titles
- QWidget panels

### Input Controls
- QPushButton with hover effects
- QLineEdit, QTextEdit with focus states
- QComboBox dropdowns
- QSpinBox numeric inputs

### Selection Controls
- QCheckBox with custom indicators
- QRadioButton with circular design
- QListWidget, QTreeWidget, QTableWidget

### Navigation & Menus
- QMenuBar with dark background
- QMenu with hover highlighting
- QTabWidget with modern tabs

### Feedback Components
- QProgressBar with animated chunks
- QSlider with custom handles
- QStatusBar for application status

### Utility Components
- QScrollBar with modern styling
- QToolTip with dark theme
- QCalendarWidget

## Advanced Usage

### Customizing Theme Properties

```python
from sfi.qtstyles import (
    get_theme_colors,
    get_theme_dimensions, 
    get_theme_fonts
)

# Access theme constants
colors = get_theme_colors()
dimensions = get_theme_dimensions()
fonts = get_theme_fonts()

print(f"Primary color: {colors['PRIMARY_BLUE']}")
print(f"Button height: {dimensions['BUTTON_HEIGHT']}px")
print(f"Font family: {fonts['FONT_FAMILY']}")
```

### Extending Themes

```python
from sfi.qtstyles import ModernBlueTheme

# Extend the base theme
class CustomTheme(ModernBlueTheme):
    @classmethod
    def get_custom_stylesheet(cls):
        base = cls.get_stylesheet()
        custom = """
        /* Your custom styles */
        #myCustomWidget {
            background-color: #ff6b6b;
        }
        """
        return base + custom
```

### Object Name Styling

The themes support custom styling through object names:

```python
# In your UI code
button = QPushButton("Special Button")
button.setObjectName("specialButton")

# The theme provides base styling, you can add customizations
button.setStyleSheet("""
    #specialButton {
        background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                  stop:0 #ff6b6b, stop:1 #ee5a52);
    }
    #specialButton:hover {
        background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                  stop:0 #ee5a52, stop:1 #d94841);
    }
""")
```

## Theme Constants Reference

### Colors
All color constants are accessible through `ModernBlueTheme.COLORS`:

| Constant         | Value   | Usage             |
| ---------------- | ------- | ----------------- |
| PRIMARY_BLUE     | #3b82f6 | Main accent color |
| SECONDARY_BLUE   | #2563eb | Secondary accent  |
| BACKGROUND_LIGHT | #ffffff | Light backgrounds |
| BACKGROUND_SOFT  | #f8fafc | Soft backgrounds  |
| TEXT_DARK        | #0f172a | Primary text      |
| BORDER_NORMAL    | #cbd5e1 | Standard borders  |

### Dimensions
Access through `ModernBlueTheme.DIMENSIONS`:

| Constant             | Value | Usage                  |
| -------------------- | ----- | ---------------------- |
| BORDER_RADIUS_MEDIUM | 8     | Standard corner radius |
| PADDING_MEDIUM       | 12    | Standard padding       |
| BUTTON_HEIGHT        | 36    | Minimum button height  |
| INPUT_HEIGHT         | 32    | Minimum input height   |

### Fonts
Access through `ModernBlueTheme.FONTS`:

| Constant           | Value                        | Usage              |
| ------------------ | ---------------------------- | ------------------ |
| FONT_FAMILY        | Microsoft YaHei UI, Segoe UI | Primary font stack |
| MONOSPACE_FONT     | Consolas, Courier New        | Monospace font     |
| FONT_SIZE_MEDIUM   | 15px                         | Standard text size |
| FONT_WEIGHT_MEDIUM | 500                          | Medium font weight |

## Best Practices

### 1. Consistent Application
Apply themes consistently across your entire application for the best user experience.

### 2. Accessibility
The themes are designed with accessibility in mind, but always test with your specific use cases.

### 3. Performance
Themes are lightweight and won't impact application performance significantly.

### 4. Customization
While the themes provide comprehensive styling, you can always extend them for specific needs.

## Contributing

We welcome contributions! Please see our contributing guidelines for:
- Adding new themes
- Improving existing themes
- Reporting issues
- Feature requests

## License

This project is part of the PySFI toolkit and follows the same licensing terms.

## Related Projects

- [PySFI Toolkit](https://github.com/your-org/pysfi) - Main toolkit repository
- [QDarkStyle](https://github.com/ColinDuquesnoy/QDarkStyleSheet) - Inspiration for dark themes
- [Qt Documentation](https://doc.qt.io/) - Official Qt styling documentation
