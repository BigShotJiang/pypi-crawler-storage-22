"""
Qt Styles - Professional Qt StyleSheet Themes
================================================

A collection of professional, production-ready Qt stylesheet themes
for creating beautiful and consistent desktop applications.

Available Themes:
- ModernBlue: Clean, professional blue-themed design

Usage:
    from sfi.qtstyles import ModernBlueTheme

    # Apply to entire application
    app.setStyleSheet(ModernBlueTheme.get_stylesheet())

    # Or apply to specific widget
    widget.setStyleSheet(ModernBlueTheme.get_stylesheet())

Features:
- Consistent cross-platform styling
- Accessible color schemes
- Responsive hover and active states
- Comprehensive component coverage
- Easy integration with existing Qt applications
"""

from .composition import (
    BaseTheme,
    CustomTheme,
    ThemeBuilder,
    ThemeConfig,
    ThemeManager,
    apply_registered_theme,
    create_custom_theme,
    register_and_apply_theme,
)
from .preview import (
    LiveThemeEditor,
    PreviewConfig,
    PreviewMode,
    ThemePreviewManager,
    ThemePreviewState,
    bind_widget_to_preview,
    create_preview_manager,
)
from .styles.dark_blue import (
    DarkBlueTheme,
    apply_dark_theme,
    get_dark_theme_colors,
    get_dark_theme_colors_enum,
    get_dark_theme_dimensions,
    get_dark_theme_dimensions_enum,
    get_dark_theme_fonts,
    get_dark_theme_fonts_enum,
)
from .styles.high_contrast import (
    HighContrastTheme,
    apply_high_contrast_theme,
    get_high_contrast_theme_colors,
    get_high_contrast_theme_colors_enum,
    get_high_contrast_theme_dimensions,
    get_high_contrast_theme_dimensions_enum,
    get_high_contrast_theme_fonts,
    get_high_contrast_theme_fonts_enum,
)
from .styles.modern_blue import (
    ModernBlueTheme,
    apply_theme,
    get_theme_colors,
    get_theme_colors_enum,
    get_theme_dimensions,
    get_theme_dimensions_enum,
    get_theme_fonts,
    get_theme_fonts_enum,
)
from .validation import (
    ColorValidator,
    DimensionValidator,
    FontValidator,
    ThemeValidator,
    ValidationError,
    validate_single_color,
    validate_single_dimension,
    validate_single_font,
    validate_theme_config,
)

__version__ = "0.1.17"
__author__ = "PySFI Development Team"
__all__ = [
    "ModernBlueTheme",
    "DarkBlueTheme",
    "HighContrastTheme",
    "BaseTheme",
    "CustomTheme",
    "ThemeBuilder",
    "ThemeManager",
    "ThemeConfig",
    "ColorValidator",
    "DimensionValidator",
    "FontValidator",
    "ThemeValidator",
    "ValidationError",
    "ThemePreviewManager",
    "LiveThemeEditor",
    "PreviewMode",
    "PreviewConfig",
    "ThemePreviewState",
    "apply_theme",
    "apply_dark_theme",
    "apply_high_contrast_theme",
    "create_custom_theme",
    "apply_registered_theme",
    "register_and_apply_theme",
    "validate_theme_config",
    "validate_single_color",
    "validate_single_dimension",
    "validate_single_font",
    "create_preview_manager",
    "bind_widget_to_preview",
    "get_theme_colors",
    "get_theme_colors_enum",
    "get_theme_dimensions",
    "get_theme_dimensions_enum",
    "get_theme_fonts",
    "get_theme_fonts_enum",
    "get_dark_theme_colors",
    "get_dark_theme_colors_enum",
    "get_dark_theme_dimensions",
    "get_dark_theme_dimensions_enum",
    "get_dark_theme_fonts",
    "get_dark_theme_fonts_enum",
    "get_high_contrast_theme_colors",
    "get_high_contrast_theme_colors_enum",
    "get_high_contrast_theme_dimensions",
    "get_high_contrast_theme_dimensions_enum",
    "get_high_contrast_theme_fonts",
    "get_high_contrast_theme_fonts_enum",
]
