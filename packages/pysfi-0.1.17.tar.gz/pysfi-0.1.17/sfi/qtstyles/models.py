from __future__ import annotations

from enum import Enum


class Color(str, Enum):
    """Color constants for the Modern Blue theme."""

    PRIMARY_BLUE = "#3b82f6"
    SECONDARY_BLUE = "#2563eb"
    DARK_BLUE = "#1d4ed8"
    DARKEST_BLUE = "#1e40af"
    BACKGROUND_LIGHT = "#ffffff"
    BACKGROUND_SOFT = "#f8fafc"
    BACKGROUND_CARD = "#f1f5f9"
    BACKGROUND_DARK = "#0f172a"
    TEXT_DARK = "#0f172a"
    TEXT_PRIMARY = "#334155"
    TEXT_SECONDARY = "#64748b"
    TEXT_LIGHT = "#94a3b8"
    BORDER_LIGHT = "#e2e8f0"
    BORDER_NORMAL = "#cbd5e1"
    BORDER_DARK = "#94a3b8"
    SUCCESS_GREEN = "#22c55e"
    WARNING_YELLOW = "#f59e0b"
    ERROR_RED = "#ef4444"
    INFO_BLUE = "#3b82f6"
    SELECTION_LIGHT = "#dbeafe"
    SELECTION_DARK = "#1e40af"
    HOVER_LIGHT = "#f1f5f9"
    HOVER_MEDIUM = "#e2e8f0"
    HOVER_DARK = "#cbd5e1"

    def __str__(self) -> str:
        return self.value


class Dimension(int, Enum):
    """Dimension constants for the Modern Blue theme."""

    BORDER_RADIUS_SMALL = 4
    BORDER_RADIUS_MEDIUM = 8
    BORDER_RADIUS_LARGE = 12
    BORDER_RADIUS_XL = 16
    PADDING_SMALL = 8
    PADDING_MEDIUM = 12
    PADDING_LARGE = 16
    PADDING_XL = 20
    SPACING_TIGHT = 4
    SPACING_COMPACT = 8
    SPACING_NORMAL = 12
    SPACING_WIDE = 16
    BUTTON_HEIGHT = 36
    INPUT_HEIGHT = 32
    MIN_CONTROL_HEIGHT = 24
    SCROLLBAR_WIDTH = 12
    SCROLLBAR_HANDLE_MIN = 20

    def __str__(self) -> str:
        return str(self.value)


class Font(str, Enum):
    """Font constants for the Modern Blue theme."""

    FONT_FAMILY = "'Microsoft YaHei UI', 'Segoe UI', 'PingFang SC', sans-serif"
    MONOSPACE_FONT = "'Consolas', 'Courier New', monospace"
    FONT_SIZE_SMALL = "12px"
    FONT_SIZE_NORMAL = "14px"
    FONT_SIZE_MEDIUM = "15px"
    FONT_SIZE_LARGE = "16px"
    FONT_SIZE_XL = "18px"
    FONT_WEIGHT_NORMAL = "400"
    FONT_WEIGHT_MEDIUM = "500"
    FONT_WEIGHT_BOLD = "600"

    def __str__(self) -> str:
        return self.value
