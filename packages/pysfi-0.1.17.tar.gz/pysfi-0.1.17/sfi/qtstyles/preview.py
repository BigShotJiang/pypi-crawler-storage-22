"""
Real-time Theme Preview System
==============================

提供动态主题切换和实时预览功能的高级系统。
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from threading import Lock, Thread
from typing import Any, Callable


class PreviewMode(Enum):
    """预览模式枚举."""

    INSTANT = "instant"  # 立即预览
    DELAYED = "delayed"  # 延迟预览
    BATCH = "batch"  # 批量预览


@dataclass
class PreviewConfig:
    """预览配置."""

    mode: PreviewMode = PreviewMode.INSTANT
    delay_ms: int = 300  # 延迟毫秒数
    batch_size: int = 10  # 批量大小
    enable_transitions: bool = True
    transition_duration: float = 0.3  # 过渡持续时间(秒)


@dataclass
class ThemePreviewState:
    """主题预览状态."""

    current_theme: str | None = None
    pending_changes: dict[str, Any] = field(default_factory=dict)
    is_transitioning: bool = False
    last_update_time: float = 0.0


class ThemePreviewManager:
    """主题预览管理器."""

    def __init__(self, config: PreviewConfig | None = None):
        self.config = config or PreviewConfig()
        self.state = ThemePreviewState()
        self._widgets: list[Any] = []
        self._callbacks: list[Callable] = []
        self._lock = Lock()
        self._preview_thread: Thread | None = None
        self._should_stop = False

    def register_widget(self, widget) -> None:
        """注册需要预览的控件."""
        with self._lock:
            if widget not in self._widgets:
                self._widgets.append(widget)

    def unregister_widget(self, widget) -> None:
        """取消注册控件."""
        with self._lock:
            if widget in self._widgets:
                self._widgets.remove(widget)

    def add_preview_callback(self, callback: Callable[[str], None]) -> None:
        """添加预览回调函数."""
        with self._lock:
            if callback not in self._callbacks:
                self._callbacks.append(callback)

    def remove_preview_callback(self, callback: Callable) -> None:
        """移除预览回调函数."""
        with self._lock:
            if callback in self._callbacks:
                self._callbacks.remove(callback)

    def preview_theme(self, theme_name: str, **kwargs) -> None:
        """预览主题."""
        current_time = time.time()

        with self._lock:
            # 更新状态
            self.state.pending_changes.update(kwargs)
            self.state.last_update_time = current_time

            # 根据模式决定处理方式
            if self.config.mode == PreviewMode.INSTANT:
                self._apply_preview_immediately(theme_name)
            elif self.config.mode == PreviewMode.DELAYED:
                self._schedule_delayed_preview(theme_name)
            elif self.config.mode == PreviewMode.BATCH:
                self._queue_batch_preview(theme_name)

    def _apply_preview_immediately(self, theme_name: str) -> None:
        """立即应用预览."""
        self.state.current_theme = theme_name
        self.state.is_transitioning = self.config.enable_transitions

        # 应用到所有注册的控件
        for widget in self._widgets:
            try:
                self._apply_theme_to_widget(widget, theme_name)
            except Exception as e:
                print(f"预览应用错误: {e}")

        # 调用回调函数
        for callback in self._callbacks:
            try:
                callback(theme_name)
            except Exception as e:
                print(f"回调执行错误: {e}")

        self.state.is_transitioning = False

    def _schedule_delayed_preview(self, theme_name: str) -> None:
        """调度延迟预览."""
        if self._preview_thread and self._preview_thread.is_alive():
            return  # 已有正在进行的预览

        def delayed_apply():
            time.sleep(self.config.delay_ms / 1000.0)
            if not self._should_stop:
                self._apply_preview_immediately(theme_name)

        self._preview_thread = Thread(target=delayed_apply, daemon=True)
        self._preview_thread.start()

    def _queue_batch_preview(self, theme_name: str) -> None:
        """队列批量预览."""
        # 批量处理逻辑可以在这里实现
        # 目前简化为延迟预览
        self._schedule_delayed_preview(theme_name)

    def _apply_theme_to_widget(self, widget, theme_name: str) -> None:
        """将主题应用到特定控件."""
        # 这里需要根据具体的 Qt 绑定实现
        # 示例实现：
        try:
            if hasattr(widget, "setStyleSheet"):
                # 获取主题样式表
                stylesheet = self._get_theme_stylesheet(theme_name)
                if stylesheet:
                    widget.setStyleSheet(stylesheet)
        except Exception as e:
            print(f"应用主题到控件失败: {e}")

    def _get_theme_stylesheet(self, theme_name: str) -> str | None:
        """获取主题样式表."""
        # 这里需要集成现有的主题系统
        try:
            from sfi.qtstyles import ThemeManager

            theme = ThemeManager.get_theme(theme_name)
            if theme:
                return theme.get_stylesheet()
        except ImportError:
            pass
        except Exception as e:
            print(f"获取主题样式表失败: {e}")

        return None

    def commit_preview(self, theme_name: str) -> None:
        """提交预览更改."""
        with self._lock:
            self.state.current_theme = theme_name
            self.state.pending_changes.clear()

    def cancel_preview(self) -> None:
        """取消预览."""
        with self._lock:
            self.state.pending_changes.clear()
            # 恢复到之前的状态

    def get_preview_state(self) -> ThemePreviewState:
        """获取当前预览状态."""
        with self._lock:
            # 返回副本以避免外部修改
            return ThemePreviewState(
                current_theme=self.state.current_theme,
                pending_changes=self.state.pending_changes.copy(),
                is_transitioning=self.state.is_transitioning,
                last_update_time=self.state.last_update_time,
            )

    def set_preview_config(self, config: PreviewConfig) -> None:
        """设置预览配置."""
        self.config = config

    def get_preview_config(self) -> PreviewConfig:
        """获取预览配置."""
        return self.config

    def stop(self) -> None:
        """停止预览管理器."""
        self._should_stop = True
        if self._preview_thread and self._preview_thread.is_alive():
            self._preview_thread.join(timeout=1.0)


class LiveThemeEditor:
    """实时主题编辑器."""

    def __init__(self, preview_manager: ThemePreviewManager):
        self.preview_manager = preview_manager
        self._edit_history: list[dict[str, Any]] = []
        self._max_history_size = 50

    def edit_color(self, color_name: str, new_value: str) -> None:
        """编辑颜色."""
        self._save_to_history("color", color_name, new_value)
        self.preview_manager.preview_theme(
            self.preview_manager.state.current_theme or "default",
            **{f"color_{color_name}": new_value},
        )

    def edit_dimension(self, dim_name: str, new_value: int) -> None:
        """编辑尺寸."""
        self._save_to_history("dimension", dim_name, new_value)
        self.preview_manager.preview_theme(
            self.preview_manager.state.current_theme or "default",
            **{f"dimension_{dim_name}": new_value},
        )

    def edit_font(self, font_name: str, new_value: str) -> None:
        """编辑字体."""
        self._save_to_history("font", font_name, new_value)
        self.preview_manager.preview_theme(
            self.preview_manager.state.current_theme or "default",
            **{f"font_{font_name}": new_value},
        )

    def _save_to_history(self, edit_type: str, name: str, value: Any) -> None:
        """保存到编辑历史."""
        history_item = {
            "type": edit_type,
            "name": name,
            "value": value,
            "timestamp": time.time(),
        }

        self._edit_history.append(history_item)

        # 限制历史记录大小
        if len(self._edit_history) > self._max_history_size:
            self._edit_history.pop(0)

    def undo(self) -> bool:
        """撤销操作."""
        if not self._edit_history:
            return False

        last_edit = self._edit_history.pop()
        # 这里需要实现实际的撤销逻辑
        print(f"撤销操作: {last_edit}")
        return True

    def redo(self) -> bool:
        """重做操作."""
        # 需要维护重做栈
        print("重做功能待实现")
        return False

    def get_edit_history(self) -> list[dict[str, Any]]:
        """获取编辑历史."""
        return self._edit_history.copy()


# 便利函数
def create_preview_manager(
    mode: PreviewMode = PreviewMode.INSTANT,
    delay_ms: int = 300,
    enable_transitions: bool = True,
) -> ThemePreviewManager:
    """创建预览管理器的便利函数."""
    config = PreviewConfig(
        mode=mode, delay_ms=delay_ms, enable_transitions=enable_transitions
    )
    return ThemePreviewManager(config)


def bind_widget_to_preview(widget, preview_manager: ThemePreviewManager) -> None:
    """将控件绑定到预览管理器."""
    preview_manager.register_widget(widget)

    # 可选：添加事件监听
    if hasattr(widget, "destroyed"):

        def cleanup():
            preview_manager.unregister_widget(widget)

        widget.destroyed.connect(cleanup)
