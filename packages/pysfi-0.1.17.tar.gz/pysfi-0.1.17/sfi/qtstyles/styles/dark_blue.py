"""
Dark Theme Variant for Qt Styles
===============================

深色主题变体，提供更好的夜间使用体验和视觉舒适度。
"""

from __future__ import annotations

from typing import ClassVar

from sfi.qtstyles.models import Color, Dimension, Font


class DarkBlueTheme:
    """深蓝色主题变体 - 专为暗环境设计."""

    # 使用 __slots__ 优化内存使用
    __slots__ = ()

    # 缓存生成的样式表以提高性能
    _cached_stylesheet: ClassVar[str | None] = None

    @classmethod
    def apply_theme(cls, widget) -> None:
        """应用深色主题到控件或应用程序.

        Args:
            widget: QApplication 或 QWidget 实例
        """
        widget.setStyleSheet(cls.get_stylesheet())

    @classmethod
    def get_stylesheet(cls) -> str:
        """生成完整的深色主题样式表.

        Returns:
            包含所有组件样式的完整 QSS 样式表字符串
        """
        # 使用缓存提高性能，避免重新生成大字符串
        if cls._cached_stylesheet is None:
            cls._cached_stylesheet = cls._generate_base_stylesheet()
        return cls._cached_stylesheet

    @classmethod
    def invalidate_cache(cls) -> None:
        """使样式表缓存失效。当主题常量被修改时调用此方法。"""
        cls._cached_stylesheet = None

    @classmethod
    def _generate_base_stylesheet(cls) -> str:
        """生成基础样式表，包含所有组件定义。"""
        # 预提取常量到局部变量以提高访问性能

        # 使用字符串构建器模式改善大字符串拼接性能
        return f"""
/* =============================================================================
   DARK BLUE THEME - BASE STYLES
   ============================================================================= */

/* 全局应用程序样式 */
QMainWindow, QDialog {{
    background-color: {Color.BACKGROUND_DARK};
    font-family: {Font.FONT_FAMILY};
    font-size: {Font.FONT_SIZE_LARGE};
    color: {Color.TEXT_LIGHT};
}}

QWidget {{
    font-family: {Font.FONT_FAMILY};
    font-size: {Font.FONT_SIZE_LARGE};
    color: {Color.TEXT_LIGHT};
    background-color: transparent;
}}

/* =============================================================================
   窗口和容器样式
   ============================================================================= */

/* 主窗口样式 */
QMainWindow {{
    background-color: {Color.BACKGROUND_DARK};
    border: none;
}}

/* 对话框样式，采用现代卡片设计 */
QDialog {{
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                    stop:0 {Color.BACKGROUND_DARK},
                                    stop:1 #1e293b);
    border: 1px solid {Color.BORDER_DARK};
    border-radius: {Dimension.BORDER_RADIUS_XL}px;
}}

/* 中央控件 */
#centralWidget {{
    background-color: transparent;
}}

/* =============================================================================
   分组框样式
   ============================================================================= */

QGroupBox {{
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                    stop:0 #1e293b,
                                    stop:1 {Color.BACKGROUND_DARK});
    border: 2px solid {Color.BORDER_DARK};
    border-radius: {Dimension.BORDER_RADIUS_LARGE}px;
    margin: {Dimension.SPACING_COMPACT}px;
    padding-top: {Dimension.PADDING_LARGE + 12}px;
    padding-left: {Dimension.PADDING_MEDIUM}px;
    padding-right: {Dimension.PADDING_MEDIUM}px;
    padding-bottom: {Dimension.PADDING_MEDIUM}px;
    font-weight: {Font.FONT_WEIGHT_MEDIUM};
    color: {Color.TEXT_LIGHT};
}}

QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                              stop:0 {Color.PRIMARY_BLUE},
                              stop:1 {Color.SECONDARY_BLUE});
    color: white;
    border-top-left-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    border-top-right-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    border-bottom: 2px solid {Color.DARK_BLUE};
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-weight: {Font.FONT_WEIGHT_BOLD};
}}

/* =============================================================================
   按钮样式
   ============================================================================= */

QPushButton {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 {Color.PRIMARY_BLUE},
                              stop:1 {Color.SECONDARY_BLUE});
    color: white;
    border: none;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-weight: {Font.FONT_WEIGHT_MEDIUM};
    font-family: {Font.FONT_FAMILY};
    min-height: {Dimension.BUTTON_HEIGHT}px;
    min-width: 80px;
}}

QPushButton:hover {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 {Color.SECONDARY_BLUE},
                              stop:1 {Color.DARK_BLUE});
}}

QPushButton:pressed {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 {Color.DARK_BLUE},
                              stop:1 {Color.DARKEST_BLUE});
}}

QPushButton:disabled {{
    background: #334155;
    color: #64748b;
}}

QPushButton:checked {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 {Color.DARKEST_BLUE},
                              stop:1 {Color.DARK_BLUE});
    border: 1px solid {Color.DARKEST_BLUE};
}}

/* 平面按钮变体 */
QPushButton.flat {{
    background: transparent;
    border: 1px solid {Color.BORDER_DARK};
    color: {Color.TEXT_LIGHT};
}}

QPushButton.flat:hover {{
    background: #334155;
    border: 1px solid {Color.PRIMARY_BLUE};
}}

/* =============================================================================
   输入控件样式
   ============================================================================= */

QLineEdit, QTextEdit, QPlainTextEdit {{
    background-color: #1e293b;
    border: 2px solid {Color.BORDER_DARK};
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    font-family: {Font.MONOSPACE_FONT};
    font-size: {Font.FONT_SIZE_NORMAL};
    color: {Color.TEXT_LIGHT};
    selection-background-color: {Color.SELECTION_DARK};
}}

QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {{
    border: 2px solid {Color.PRIMARY_BLUE};
    background-color: #334155;
}}

QLineEdit:disabled, QTextEdit:disabled, QPlainTextEdit:disabled {{
    background-color: #0f172a;
    color: #475569;
    border: 2px solid #334155;
}}

/* 密码输入框 */
QLineEdit[type="password"] {{
    font-family: {Font.MONOSPACE_FONT};
}}

/* =============================================================================
   标签和文本显示
   ============================================================================= */

QLabel {{
    color: {Color.TEXT_LIGHT};
    font-family: {Font.FONT_FAMILY};
    font-size: {Font.FONT_SIZE_LARGE};
}}

QLabel:disabled {{
    color: #64748b;
}}

/* 链接标签 */
QLabel[href] {{
    color: {Color.INFO_BLUE};
    text-decoration: underline;
}}

QLabel[href]:hover {{
    color: {Color.PRIMARY_BLUE};
}}

/* 标题标签 */
QLabel.title {{
    font-size: {Font.FONT_SIZE_XL};
    font-weight: {Font.FONT_WEIGHT_BOLD};
    color: {Color.TEXT_LIGHT};
}}

QLabel.subtitle {{
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-weight: {Font.FONT_WEIGHT_MEDIUM};
    color: {Color.TEXT_SECONDARY};
}}

/* =============================================================================
   组合框样式
   ============================================================================= */

QComboBox {{
    background-color: #1e293b;
    border: 2px solid {Color.BORDER_DARK};
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    font-size: {Font.FONT_SIZE_NORMAL};
    color: {Color.TEXT_LIGHT};
    min-height: {Dimension.INPUT_HEIGHT}px;
}}

QComboBox:hover {{
    border: 2px solid {Color.BORDER_NORMAL};
}}

QComboBox:focus {{
    border: 2px solid {Color.PRIMARY_BLUE};
}}

QComboBox:disabled {{
    background-color: #0f172a;
    color: #475569;
    border: 2px solid #334155;
}}

QComboBox::drop-down {{
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: {Dimension.BUTTON_HEIGHT}px;
    border-left: 1px solid {Color.BORDER_DARK};
    border-top-right-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    border-bottom-right-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
}}

QComboBox::down-arrow {{
    image: url(:/icons/arrow_down_light.svg);
    width: 16px;
    height: 16px;
}}

/* =============================================================================
   列表和表格样式
   ============================================================================= */

QListWidget, QTreeWidget, QTableWidget {{
    background-color: #1e293b;
    alternate-background-color: #334155;
    border: 2px solid {Color.BORDER_DARK};
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    gridline-color: {Color.BORDER_DARK};
    color: {Color.TEXT_LIGHT};
}}

QListWidget::item, QTreeWidget::item, QTableWidget::item {{
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
    border-bottom: 1px solid #334155;
}}

QListWidget::item:selected, QTreeWidget::item:selected, QTableWidget::item:selected {{
    background-color: {Color.SELECTION_DARK};
    color: white;
}}

QListWidget::item:hover:!selected, QTreeWidget::item:hover:!selected, QTableWidget::item:hover:!selected {{
    background-color: #475569;
}}

/* 表头样式 */
QHeaderView::section {{
    background-color: {Color.DARK_BLUE};
    color: white;
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
    border: 1px solid {Color.DARKEST_BLUE};
    font-weight: {Font.FONT_WEIGHT_BOLD};
}}

/* =============================================================================
   滚动条样式
   ============================================================================= */

QScrollBar:vertical {{
    background-color: #0f172a;
    width: {Dimension.SCROLLBAR_WIDTH}px;
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
}}

QScrollBar::handle:vertical {{
    background-color: #475569;
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    min-height: {Dimension.SCROLLBAR_HANDLE_MIN}px;
}}

QScrollBar::handle:vertical:hover {{
    background-color: #64748b;
}}

QScrollBar::sub-line:vertical, QScrollBar::add-line:vertical {{
    height: 0px;
}}

QScrollBar:horizontal {{
    background-color: #0f172a;
    height: {Dimension.SCROLLBAR_WIDTH}px;
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
}}

QScrollBar::handle:horizontal {{
    background-color: #475569;
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    min-width: {Dimension.SCROLLBAR_HANDLE_MIN}px;
}}

QScrollBar::handle:horizontal:hover {{
    background-color: #64748b;
}}

QScrollBar::sub-line:horizontal, QScrollBar::add-line:horizontal {{
    width: 0px;
}}

/* =============================================================================
   进度条样式
   ============================================================================= */

QProgressBar {{
    border: 2px solid {Color.BORDER_DARK};
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    text-align: center;
    color: {Color.TEXT_LIGHT};
    background-color: #1e293b;
}}

QProgressBar::chunk {{
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                    stop:0 {Color.PRIMARY_BLUE},
                                    stop:1 {Color.SECONDARY_BLUE});
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
}}

/* =============================================================================
   工具提示样式
   ============================================================================= */

QToolTip {{
    background-color: #1e293b;
    color: {Color.TEXT_LIGHT};
    border: 1px solid {Color.BORDER_DARK};
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
    font-family: {Font.FONT_FAMILY};
    font-size: {Font.FONT_SIZE_NORMAL};
}}

/* =============================================================================
   菜单和菜单栏样式
   ============================================================================= */

QMenuBar {{
    background-color: {Color.BACKGROUND_DARK};
    color: {Color.TEXT_LIGHT};
    border-bottom: 1px solid {Color.BORDER_DARK};
}}

QMenuBar::item {{
    background: transparent;
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
}}

QMenuBar::item:selected {{
    background-color: #334155;
}}

QMenu {{
    background-color: #1e293b;
    color: {Color.TEXT_LIGHT};
    border: 1px solid {Color.BORDER_DARK};
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
}}

QMenu::item {{
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_LARGE}px;
}}

QMenu::item:selected {{
    background-color: {Color.SELECTION_DARK};
}}

QMenu::separator {{
    height: 1px;
    background-color: {Color.BORDER_DARK};
    margin: {Dimension.SPACING_TIGHT}px 0px;
}}

/* =============================================================================
   状态栏样式
   ============================================================================= */

QStatusBar {{
    background-color: {Color.BACKGROUND_DARK};
    color: {Color.TEXT_SECONDARY};
    border-top: 1px solid {Color.BORDER_DARK};
}}

/* =============================================================================
   特殊用途样式
   ============================================================================= */

/* 成功/信息显示区域 */
#successDisplay {{
    background-color: #064e3b;
    border: 2px solid #10b981;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    font-family: {Font.MONOSPACE_FONT};
    font-size: {Font.FONT_SIZE_NORMAL};
    color: #6ee7b7;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
}}

/* 警告输入区域 */
#warningInput {{
    background-color: #7c2d12;
    border: 2px solid #f97316;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
}}

#warningInput:focus {{
    border: 2px solid {Color.WARNING_YELLOW};
    background-color: #9a3412;
}}

/* 错误显示区域 */
#errorDisplay {{
    background-color: #7f1d1d;
    border: 2px solid #ef4444;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    font-family: {Font.MONOSPACE_FONT};
    font-size: {Font.FONT_SIZE_NORMAL};
    color: #fca5a5;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
}}

/* =============================================================================
   工具类
   ============================================================================= */

/* 卡片式容器 */
.CardContainer {{
    background-color: #1e293b;
    border: 1px solid {Color.BORDER_DARK};
    border-radius: {Dimension.BORDER_RADIUS_LARGE}px;
    padding: {Dimension.PADDING_LARGE}px;
}}

/* 高亮面板 */
.HighlightPanel {{
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                    stop:0 #1e293b,
                                    stop:1 #334155);
    border: 1px solid #0ea5e9;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_MEDIUM}px;
}}

/* =============================================================================
   样式表结束
   ============================================================================= */
"""


# 便利函数便于使用
def apply_dark_theme(widget) -> None:
    """应用深色主题到控件或应用程序.

    Args:
        widget: QApplication 或 QWidget 实例
    """
    widget.setStyleSheet(DarkBlueTheme.get_stylesheet())


def get_dark_theme_colors() -> dict[str, str]:
    """获取深色主题使用的调色板.

    Returns:
        颜色常量字典
    """
    return {color.name: color.value for color in Color}


def get_dark_theme_colors_enum():
    """获取深色主题的颜色枚举.

    Returns:
        包含所有颜色常量的颜色枚举类
    """
    return Color


def get_dark_theme_dimensions() -> dict[str, int]:
    """获取深色主题使用的尺寸常量.

    Returns:
        尺寸常量字典
    """
    return {dim.name: dim.value for dim in Dimension}


def get_dark_theme_dimensions_enum():
    """获取深色主题的尺寸枚举.

    Returns:
        包含所有尺寸常量的尺寸枚举类
    """
    return Dimension


def get_dark_theme_fonts() -> dict[str, str]:
    """获取深色主题使用的字体常量.

    Returns:
        字体常量字典
    """
    return {font.name: font.value for font in Font}


def get_dark_theme_fonts_enum():
    """获取深色主题的字体枚举.

    Returns:
        包含所有字体常量的字体枚举类
    """
    return Font
