"""
High Contrast Theme Variant for Qt Styles
=========================================

高对比度主题变体，为视力障碍用户提供更好的可访问性支持。
"""

from __future__ import annotations

from typing import ClassVar

from sfi.qtstyles.models import Color, Dimension, Font


class HighContrastTheme:
    """高对比度主题 - 专注于最大化的视觉可区分性."""

    # 使用 __slots__ 优化内存使用
    __slots__ = ()

    # 缓存生成的样式表以提高性能
    _cached_stylesheet: ClassVar[str | None] = None

    @classmethod
    def apply_theme(cls, widget) -> None:
        """应用高对比度主题到控件或应用程序.

        Args:
            widget: QApplication 或 QWidget 实例
        """
        widget.setStyleSheet(cls.get_stylesheet())

    @classmethod
    def get_stylesheet(cls) -> str:
        """生成完整的高对比度主题样式表.

        Returns:
            包含所有组件样式的完整 QSS 样式表字符串
        """
        # 使用缓存提高性能，避免重新生成大字符串
        if cls._cached_stylesheet is None:
            cls._cached_stylesheet = cls._generate_base_stylesheet()
        return cls._cached_stylesheet

    @classmethod
    def invalidate_cache(cls) -> None:
        """使样式表缓存失效。当主题常量被修改时调用此方法。"""
        cls._cached_stylesheet = None

    @classmethod
    def _generate_base_stylesheet(cls) -> str:
        """生成基础样式表，包含所有组件定义。"""
        # 预提取常量到局部变量以提高访问性能

        # 使用字符串构建器模式改善大字符串拼接性能
        return f"""
/* =============================================================================
   HIGH CONTRAST THEME - ACCESSIBILITY FOCUSED
   ============================================================================= */

/* 全局应用程序样式 - 黑白高对比度 */
QMainWindow, QDialog {{
    background-color: black;
    font-family: {Font.FONT_FAMILY};
    font-size: {Font.FONT_SIZE_LARGE};
    color: white;
}}

QWidget {{
    font-family: {Font.FONT_FAMILY};
    font-size: {Font.FONT_SIZE_LARGE};
    color: white;
    background-color: black;
}}

/* =============================================================================
   窗口和容器样式
   ============================================================================= */

/* 主窗口样式 */
QMainWindow {{
    background-color: black;
    border: 2px solid white;
}}

/* 对话框样式 - 强烈的边框强调 */
QDialog {{
    background-color: black;
    border: 3px solid white;
    border-radius: {Dimension.BORDER_RADIUS_LARGE}px;
}}

/* 中央控件 */
#centralWidget {{
    background-color: black;
}}

/* =============================================================================
   分组框样式 - 强烈的视觉分离
   ============================================================================= */

QGroupBox {{
    background-color: #1a1a1a;
    border: 3px solid white;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    margin: {Dimension.SPACING_COMPACT}px;
    padding-top: {Dimension.PADDING_LARGE + 12}px;
    padding-left: {Dimension.PADDING_MEDIUM}px;
    padding-right: {Dimension.PADDING_MEDIUM}px;
    padding-bottom: {Dimension.PADDING_MEDIUM}px;
    font-weight: {Font.FONT_WEIGHT_BOLD};
    color: white;
}}

QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    background: white;
    color: black;
    border-top-left-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    border-top-right-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    border-bottom: 3px solid white;
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-weight: {Font.FONT_WEIGHT_BOLD};
}}

/* =============================================================================
   按钮样式 - 最大可见性
   ============================================================================= */

QPushButton {{
    background: white;
    color: black;
    border: 3px solid white;
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-weight: {Font.FONT_WEIGHT_BOLD};
    font-family: {Font.FONT_FAMILY};
    min-height: {Dimension.BUTTON_HEIGHT}px;
    min-width: 80px;
}}

QPushButton:hover {{
    background: #e0e0e0;
    border: 3px solid #ffff00;
}}

QPushButton:pressed {{
    background: #c0c0c0;
    border: 3px solid #ffff00;
}}

QPushButton:disabled {{
    background: #404040;
    color: #808080;
    border: 3px solid #808080;
}}

QPushButton:checked {{
    background: #ffff00;
    color: black;
    border: 3px solid #ffff00;
}}

/* 平面按钮变体 */
QPushButton.flat {{
    background: black;
    border: 2px solid white;
    color: white;
}}

QPushButton.flat:hover {{
    background: #202020;
    border: 2px solid #ffff00;
}}

/* =============================================================================
   输入控件样式 - 清晰的焦点指示
   ============================================================================= */

QLineEdit, QTextEdit, QPlainTextEdit {{
    background-color: black;
    border: 3px solid white;
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    font-family: {Font.MONOSPACE_FONT};
    font-size: {Font.FONT_SIZE_NORMAL};
    color: white;
    selection-background-color: #ffff00;
    selection-color: black;
}}

QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {{
    border: 3px solid #ffff00;
    background-color: #202020;
}}

QLineEdit:disabled, QTextEdit:disabled, QPlainTextEdit:disabled {{
    background-color: black;
    color: #808080;
    border: 3px solid #808080;
}}

/* 密码输入框 */
QLineEdit[type="password"] {{
    font-family: {Font.MONOSPACE_FONT};
}}

/* =============================================================================
   标签和文本显示 - 最大可读性
   ============================================================================= */

QLabel {{
    color: white;
    font-family: {Font.FONT_FAMILY};
    font-size: {Font.FONT_SIZE_LARGE};
    font-weight: {Font.FONT_WEIGHT_NORMAL};
}}

QLabel:disabled {{
    color: #808080;
}}

/* 链接标签 - 明确的视觉指示 */
QLabel[href] {{
    color: #ffff00;
    text-decoration: underline;
    font-weight: {Font.FONT_WEIGHT_BOLD};
}}

QLabel[href]:hover {{
    color: #ffff00;
    background-color: #404040;
}}

/* 标题标签 */
QLabel.title {{
    font-size: {Font.FONT_SIZE_XL};
    font-weight: {Font.FONT_WEIGHT_BOLD};
    color: white;
}}

QLabel.subtitle {{
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-weight: {Font.FONT_WEIGHT_BOLD};
    color: white;
}}

/* =============================================================================
   组合框样式 - 清晰的选择反馈
   ============================================================================= */

QComboBox {{
    background-color: black;
    border: 3px solid white;
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    font-size: {Font.FONT_SIZE_NORMAL};
    color: white;
    min-height: {Dimension.INPUT_HEIGHT}px;
}}

QComboBox:hover {{
    border: 3px solid #ffff00;
}}

QComboBox:focus {{
    border: 3px solid #ffff00;
    background-color: #202020;
}}

QComboBox:disabled {{
    background-color: black;
    color: #808080;
    border: 3px solid #808080;
}}

QComboBox::drop-down {{
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: {Dimension.BUTTON_HEIGHT}px;
    border-left: 2px solid white;
    background: white;
}}

QComboBox::down-arrow {{
    image: url(:/icons/arrow_down_black.svg);
    width: 16px;
    height: 16px;
}}

/* =============================================================================
   列表和表格样式 - 清晰的项目区分
   ============================================================================= */

QListWidget, QTreeWidget, QTableWidget {{
    background-color: black;
    alternate-background-color: #1a1a1a;
    border: 3px solid white;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    gridline-color: white;
    color: white;
}}

QListWidget::item, QTreeWidget::item, QTableWidget::item {{
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
    border-bottom: 1px solid #404040;
}}

QListWidget::item:selected, QTreeWidget::item:selected, QTableWidget::item:selected {{
    background-color: #ffff00;
    color: black;
    font-weight: {Font.FONT_WEIGHT_BOLD};
}}

QListWidget::item:hover:!selected, QTreeWidget::item:hover:!selected, QTableWidget::item:hover:!selected {{
    background-color: #404040;
}}

/* 表头样式 - 强烈的视觉层次 */
QHeaderView::section {{
    background-color: white;
    color: black;
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
    border: 2px solid black;
    font-weight: {Font.FONT_WEIGHT_BOLD};
}}

/* =============================================================================
   滚动条样式 - 最大可见性
   ============================================================================= */

QScrollBar:vertical {{
    background-color: black;
    width: {Dimension.SCROLLBAR_WIDTH + 4}px;
    border: 2px solid white;
}}

QScrollBar::handle:vertical {{
    background-color: white;
    border: 1px solid black;
    min-height: {Dimension.SCROLLBAR_HANDLE_MIN}px;
}}

QScrollBar::handle:vertical:hover {{
    background-color: #ffff00;
}}

QScrollBar::sub-line:vertical, QScrollBar::add-line:vertical {{
    height: 0px;
}}

QScrollBar:horizontal {{
    background-color: black;
    height: {Dimension.SCROLLBAR_WIDTH + 4}px;
    border: 2px solid white;
}}

QScrollBar::handle:horizontal {{
    background-color: white;
    border: 1px solid black;
    min-width: {Dimension.SCROLLBAR_HANDLE_MIN}px;
}}

QScrollBar::handle:horizontal:hover {{
    background-color: #ffff00;
}}

QScrollBar::sub-line:horizontal, QScrollBar::add-line:horizontal {{
    width: 0px;
}}

/* =============================================================================
   进度条样式 - 清晰的状态指示
   ============================================================================= */

QProgressBar {{
    border: 3px solid white;
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    text-align: center;
    color: white;
    background-color: black;
    font-weight: {Font.FONT_WEIGHT_BOLD};
}}

QProgressBar::chunk {{
    background-color: #ffff00;
    color: black;
}}

/* =============================================================================
   工具提示样式 - 最大可读性
   ============================================================================= */

QToolTip {{
    background-color: black;
    color: white;
    border: 2px solid white;
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
    font-family: {Font.FONT_FAMILY};
    font-size: {Font.FONT_SIZE_NORMAL};
    font-weight: {Font.FONT_WEIGHT_BOLD};
}}

/* =============================================================================
   菜单和菜单栏样式 - 清晰的导航
   ============================================================================= */

QMenuBar {{
    background-color: black;
    color: white;
    border-bottom: 2px solid white;
}}

QMenuBar::item {{
    background: transparent;
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
    border: 1px solid transparent;
}}

QMenuBar::item:selected {{
    background-color: white;
    color: black;
    border: 1px solid white;
}}

QMenu {{
    background-color: black;
    color: white;
    border: 2px solid white;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
}}

QMenu::item {{
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_LARGE}px;
    border: 1px solid transparent;
}}

QMenu::item:selected {{
    background-color: #ffff00;
    color: black;
    font-weight: {Font.FONT_WEIGHT_BOLD};
}}

QMenu::separator {{
    height: 2px;
    background-color: white;
    margin: {Dimension.SPACING_TIGHT}px 0px;
}}

/* =============================================================================
   状态栏样式
   ============================================================================= */

QStatusBar {{
    background-color: black;
    color: white;
    border-top: 2px solid white;
    font-weight: {Font.FONT_WEIGHT_BOLD};
}}

/* =============================================================================
   特殊用途样式 - 明确的状态指示
   ============================================================================= */

/* 成功/信息显示区域 */
#successDisplay {{
    background-color: black;
    border: 3px solid #00ff00;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    font-family: {Font.MONOSPACE_FONT};
    font-size: {Font.FONT_SIZE_NORMAL};
    color: #00ff00;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    font-weight: {Font.FONT_WEIGHT_BOLD};
}}

/* 警告输入区域 */
#warningInput {{
    background-color: black;
    border: 3px solid #ffff00;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    color: #ffff00;
}}

#warningInput:focus {{
    border: 3px solid #ffff00;
    background-color: #404000;
}}

/* 错误显示区域 */
#errorDisplay {{
    background-color: black;
    border: 3px solid #ff0000;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    font-family: {Font.MONOSPACE_FONT};
    font-size: {Font.FONT_SIZE_NORMAL};
    color: #ff0000;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    font-weight: {Font.FONT_WEIGHT_BOLD};
}}

/* =============================================================================
   工具类 - 清晰的视觉分组
   ============================================================================= */

/* 卡片式容器 */
.CardContainer {{
    background-color: #1a1a1a;
    border: 2px solid white;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_LARGE}px;
}}

/* 高亮面板 */
.HighlightPanel {{
    background-color: black;
    border: 3px solid #ffff00;
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    padding: {Dimension.PADDING_MEDIUM}px;
}}

/* =============================================================================
   样式表结束
   ============================================================================= */
"""


# 便利函数便于使用
def apply_high_contrast_theme(widget) -> None:
    """应用高对比度主题到控件或应用程序.

    Args:
        widget: QApplication 或 QWidget 实例
    """
    widget.setStyleSheet(HighContrastTheme.get_stylesheet())


def get_high_contrast_theme_colors() -> dict[str, str]:
    """获取高对比度主题使用的调色板.

    Returns:
        颜色常量字典
    """
    return {color.name: color.value for color in Color}


def get_high_contrast_theme_colors_enum():
    """获取高对比度主题的颜色枚举.

    Returns:
        包含所有颜色常量的颜色枚举类
    """
    return Color


def get_high_contrast_theme_dimensions() -> dict[str, int]:
    """获取高对比度主题使用的尺寸常量.

    Returns:
        尺寸常量字典
    """
    return {dim.name: dim.value for dim in Dimension}


def get_high_contrast_theme_dimensions_enum():
    """获取高对比度主题的尺寸枚举.

    Returns:
        包含所有尺寸常量的尺寸枚举类
    """
    return Dimension


def get_high_contrast_theme_fonts() -> dict[str, str]:
    """获取高对比度主题使用的字体常量.

    Returns:
        字体常量字典
    """
    return {font.name: font.value for font in Font}


def get_high_contrast_theme_fonts_enum():
    """获取高对比度主题的字体枚举.

    Returns:
        包含所有字体常量的字体枚举类
    """
    return Font
