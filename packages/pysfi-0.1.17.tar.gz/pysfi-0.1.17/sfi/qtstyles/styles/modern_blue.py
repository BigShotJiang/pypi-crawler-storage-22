"""
Modern Blue Qt Stylesheet Theme
================================

A professional, modern blue-themed stylesheet for Qt applications.
Inspired by modern UI design principles and aligned with industry standards.

Features:
- Clean, professional blue color scheme
- Consistent component styling
- Responsive hover and active states
- Cross-platform compatibility
- Accessible color contrast ratios

Color Palette:
- Primary Blue: #3b82f6
- Secondary Blue: #2563eb
- Dark Blue: #1d4ed8
- Light Background: #f8fafc
- Dark Text: #0f172a
- Border Colors: #cbd5e1, #e2e8f0
"""

from __future__ import annotations

from sfi.qtstyles.models import Color, Dimension, Font


class ModernBlueTheme:
    """Modern Blue theme constants and stylesheet generator."""

    # Use __slots__ to optimize memory usage
    __slots__ = ()

    # Cache generated stylesheet for performance improvement
    _cached_stylesheet: str = None

    @classmethod
    def apply_theme(cls, widget) -> None:
        """Apply modern blue theme to a widget or application.

        Args:
            widget: QApplication or QWidget instance
        """
        widget.setStyleSheet(cls.get_stylesheet())

    @classmethod
    def get_stylesheet(cls) -> str:
        """Generate complete modern blue stylesheet.

        Returns:
            Complete QSS stylesheet string with all component styles
        """
        # Use cache for performance, avoid regenerating large strings
        if cls._cached_stylesheet is None:
            cls._cached_stylesheet = cls._generate_base_stylesheet()
        return cls._cached_stylesheet

    @classmethod
    def invalidate_cache(cls) -> None:
        """Invalidate the stylesheet cache. Call this if theme constants are modified."""
        cls._cached_stylesheet = None

    @classmethod
    def _generate_base_stylesheet(cls) -> str:
        """Generate base stylesheet with all component definitions."""
        # Pre-extract constants to local variables for better access performance

        # Use string builder pattern to improve large string concatenation performance
        return f"""
/* =============================================================================
   MODERN BLUE THEME - BASE STYLES
   ============================================================================= */

/* Global application styling */
QMainWindow, QDialog {{
    background-color: {Color.BACKGROUND_SOFT};
    font-family: {Font.FONT_FAMILY};
    font-size: {Font.FONT_SIZE_LARGE};
}}

QWidget {{
    font-family: {Font.FONT_FAMILY};
    font-size: {Font.FONT_SIZE_LARGE};
    color: {Color.TEXT_DARK};
}}

/* =============================================================================
   WINDOW AND CONTAINER STYLES
   ============================================================================= */

/* Main window styling */
QMainWindow {{
    background-color: {Color.BACKGROUND_SOFT};
    border: none;
}}

/* Dialog styling with modern card design */
QDialog {{
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                    stop:0 {Color.BACKGROUND_LIGHT},
                                    stop:1 {Color.BACKGROUND_CARD});
    border: 1px solid {Color.BORDER_LIGHT};
    border-radius: {Dimension.BORDER_RADIUS_XL}px;
}}

/* Central widget */
#centralWidget {{
    background-color: transparent;
}}

/* =============================================================================
   GROUP BOX STYLING
   ============================================================================= */

QGroupBox {{
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                    stop:0 {Color.BACKGROUND_LIGHT},
                                    stop:1 {Color.BACKGROUND_SOFT});
    border: 2px solid {Color.BORDER_NORMAL};  /* Increase border width to ensure visibility */
    border-radius: {Dimension.BORDER_RADIUS_LARGE}px;
    margin: {Dimension.SPACING_COMPACT}px;
    padding-top: {Dimension.PADDING_LARGE + 12}px;
    padding-left: {Dimension.PADDING_MEDIUM}px;
    padding-right: {Dimension.PADDING_MEDIUM}px;
    padding-bottom: {Dimension.PADDING_MEDIUM}px;
    font-weight: {Font.FONT_WEIGHT_MEDIUM};
    color: {Color.TEXT_DARK};
}}

QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                              stop:0 {Color.PRIMARY_BLUE},
                              stop:1 {Color.DARK_BLUE});
    color: white;
    border-top-left-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    border-top-right-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    border-bottom: 2px solid {Color.DARKEST_BLUE};
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-weight: {Font.FONT_WEIGHT_BOLD};
}}

/* =============================================================================
   BUTTON STYLING
   ============================================================================= */

QPushButton {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 {Color.PRIMARY_BLUE},
                              stop:1 {Color.SECONDARY_BLUE});
    color: white;
    border: none;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-weight: {Font.FONT_WEIGHT_MEDIUM};
    font-family: {Font.FONT_FAMILY};
    min-height: {Dimension.BUTTON_HEIGHT}px;
    min-width: 80px;
}}

QPushButton:hover {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 {Color.SECONDARY_BLUE},
                              stop:1 {Color.DARK_BLUE});
}}

QPushButton:pressed {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 {Color.DARK_BLUE},
                              stop:1 {Color.DARKEST_BLUE});
}}

QPushButton:disabled {{
    background: {Color.TEXT_LIGHT};
    color: {Color.BORDER_NORMAL};
}}

QPushButton:checked {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 {Color.DARKEST_BLUE},
                              stop:1 {Color.DARK_BLUE});
    border: 1px solid {Color.DARKEST_BLUE};
}}

/* Flat button variant */
QPushButton.flat {{
    background: transparent;
    border: 1px solid {Color.BORDER_NORMAL};
    color: {Color.TEXT_PRIMARY};
}}

QPushButton.flat:hover {{
    background: {Color.HOVER_LIGHT};
    border: 1px solid {Color.PRIMARY_BLUE};
}}

/* =============================================================================
   INPUT CONTROL STYLING
   ============================================================================= */

/* Line edits and text areas */
QLineEdit, QTextEdit, QPlainTextEdit {{
    background-color: {Color.BACKGROUND_LIGHT};
    border: 2px solid {Color.BORDER_NORMAL};
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    font-size: {Font.FONT_SIZE_LARGE};
    font-family: {Font.MONOSPACE_FONT};
    selection-background-color: {Color.SELECTION_LIGHT};
    selection-color: {Color.SELECTION_DARK};
    min-height: {Dimension.INPUT_HEIGHT}px;
}}

QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {{
    border: 2px solid {Color.PRIMARY_BLUE};
    outline: none;
    background-color: {Color.BACKGROUND_SOFT};
}}

QLineEdit:disabled, QTextEdit:disabled, QPlainTextEdit:disabled {{
    background-color: {Color.HOVER_LIGHT};
    color: {Color.TEXT_LIGHT};
    border: 2px solid {Color.BORDER_LIGHT};
}}

/* Placeholders */
QLineEdit:!focus, QTextEdit:!focus {{
    color: {Color.TEXT_SECONDARY};
}}

/* =============================================================================
   COMBO BOX AND SPIN BOX STYLING
   ============================================================================= */

QComboBox {{
    background-color: {Color.BACKGROUND_LIGHT};
    border: 2px solid {Color.BORDER_NORMAL};
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-family: {Font.MONOSPACE_FONT};
    min-height: {Dimension.INPUT_HEIGHT}px;
}}

QComboBox:hover {{
    border: 2px solid {Color.BORDER_DARK};
}}

QComboBox:focus {{
    border: 2px solid {Color.PRIMARY_BLUE};
}}

QComboBox:disabled {{
    background-color: {Color.HOVER_LIGHT};
    color: {Color.TEXT_LIGHT};
}}

QComboBox::drop-down {{
    border: none;
    width: 20px;
}}

QComboBox::down-arrow {{
    image: none;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 5px solid {Color.TEXT_SECONDARY};
}}

QSpinBox, QDoubleSpinBox {{
    background-color: {Color.BACKGROUND_LIGHT};
    border: 2px solid {Color.BORDER_NORMAL};
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-family: {Font.MONOSPACE_FONT};
    min-height: {Dimension.INPUT_HEIGHT}px;
}}

QSpinBox:hover, QDoubleSpinBox:hover {{
    border: 2px solid {Color.BORDER_DARK};
}}

QSpinBox:focus, QDoubleSpinBox:focus {{
    border: 2px solid {Color.PRIMARY_BLUE};
}}

/* =============================================================================
   CHECKBOX AND RADIO BUTTON STYLING
   ============================================================================= */

QCheckBox {{
    spacing: 8px;
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-family: {Font.FONT_FAMILY};
    color: {Color.TEXT_DARK};
}}

QCheckBox::indicator {{
    width: 18px;
    height: 18px;
    border-radius: 4px;
    border: 2px solid {Color.BORDER_NORMAL};
    background-color: {Color.BACKGROUND_LIGHT};
}}

QCheckBox::indicator:hover {{
    border: 2px solid {Color.PRIMARY_BLUE};
}}

QCheckBox::indicator:checked {{
    background-color: {Color.PRIMARY_BLUE};
    border: 2px solid {Color.PRIMARY_BLUE};
}}

QCheckBox::indicator:unchecked:disabled {{
    background-color: {Color.HOVER_LIGHT};
    border: 2px solid {Color.BORDER_LIGHT};
}}

QCheckBox::indicator:checked:disabled {{
    background-color: {Color.TEXT_LIGHT};
    border: 2px solid {Color.TEXT_LIGHT};
}}

QRadioButton {{
    spacing: 8px;
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-family: {Font.FONT_FAMILY};
    color: {Color.TEXT_DARK};
}}

QRadioButton::indicator {{
    width: 18px;
    height: 18px;
    border-radius: 9px;
    border: 2px solid {Color.BORDER_NORMAL};
    background-color: {Color.BACKGROUND_LIGHT};
}}

QRadioButton::indicator:hover {{
    border: 2px solid {Color.PRIMARY_BLUE};
}}

QRadioButton::indicator:checked {{
    background-color: {Color.PRIMARY_BLUE};
    border: 2px solid {Color.PRIMARY_BLUE};
}}

/* =============================================================================
   LABEL AND TEXT STYLING
   ============================================================================= */

QLabel {{
    font-size: {Font.FONT_SIZE_MEDIUM};
    color: {Color.TEXT_PRIMARY};
    font-family: {Font.FONT_FAMILY};
}}

QLabel:disabled {{
    color: {Color.TEXT_LIGHT};
}}

/* Status labels with special styling */
.StatusLabelReady {{
    color: {Color.TEXT_PRIMARY};
    background-color: rgba(255, 255, 255, 0.95);
    border: 1px solid {Color.BORDER_NORMAL};
}}

.StatusLabelSuccess {{
    color: #166534;
    background-color: rgba(240, 253, 244, 0.95);
    border: 1px solid #86efac;
}}

.StatusLabelError {{
    color: #b91c1c;
    background-color: rgba(254, 242, 242, 0.95);
    border: 1px solid #fecaca;
}}

.StatusLabelWarning {{
    color: #92400e;
    background-color: rgba(254, 243, 199, 0.95);
    border: 1px solid #fbbf24;
}}

/* =============================================================================
   LIST AND TABLE WIDGETS
   ============================================================================= */

QListWidget, QTreeWidget, QTableWidget {{
    background-color: {Color.BACKGROUND_LIGHT};
    border: 2px solid {Color.BORDER_NORMAL};
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_SMALL}px;
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-family: {Font.MONOSPACE_FONT};
    alternate-background-color: {Color.BACKGROUND_SOFT};
    selection-background-color: {Color.PRIMARY_BLUE};
    selection-color: white;
}}

QListWidget::item, QTreeWidget::item, QTableWidget::item {{
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    margin: 1px 0;
}}

QListWidget::item:hover, QTreeWidget::item:hover, QTableWidget::item:hover {{
    background-color: {Color.HOVER_LIGHT};
}}

QListWidget::item:selected, QTreeWidget::item:selected, QTableWidget::item:selected {{
    background-color: {Color.PRIMARY_BLUE};
    color: white;
}}

/* Table header styling */
QHeaderView::section {{
    background-color: {Color.PRIMARY_BLUE};
    color: white;
    padding: {Dimension.PADDING_SMALL}px;
    font-weight: {Font.FONT_WEIGHT_BOLD};
    border: 1px solid {Color.BORDER_NORMAL};
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
}}

/* =============================================================================
   SCROLLBAR STYLING
   ============================================================================= */

QScrollBar:vertical {{
    border: none;
    background-color: {Color.BACKGROUND_CARD};
    width: {Dimension.SCROLLBAR_WIDTH}px;
    border-radius: {Dimension.SCROLLBAR_WIDTH // 2}px;
    margin: 2px;
}}

QScrollBar:horizontal {{
    border: none;
    background-color: {Color.BACKGROUND_CARD};
    height: {Dimension.SCROLLBAR_WIDTH}px;
    border-radius: {Dimension.SCROLLBAR_WIDTH // 2}px;
    margin: 2px;
}}

QScrollBar::handle:vertical {{
    background-color: {Color.TEXT_LIGHT};
    border-radius: {Dimension.SCROLLBAR_WIDTH // 2}px;
    min-height: {Dimension.SCROLLBAR_HANDLE_MIN}px;
}}

QScrollBar::handle:horizontal {{
    background-color: {Color.TEXT_LIGHT};
    border-radius: {Dimension.SCROLLBAR_WIDTH // 2}px;
    min-width: {Dimension.SCROLLBAR_HANDLE_MIN}px;
}}

QScrollBar::handle:vertical:hover, QScrollBar::handle:horizontal:hover {{
    background-color: {Color.TEXT_SECONDARY};
}}

QScrollBar::handle:vertical:pressed, QScrollBar::handle:horizontal:pressed {{
    background-color: {Color.TEXT_PRIMARY};
}}

QScrollBar::add-line, QScrollBar::sub-line {{
    height: 0px;
    width: 0px;
}}

/* =============================================================================
   MENU AND MENUBAR STYLING
   ============================================================================= */

QMenuBar {{
    background-color: {Color.BACKGROUND_DARK};
    color: white;
    border-bottom: 1px solid {Color.TEXT_SECONDARY};
    padding: {Dimension.PADDING_SMALL}px;
    font-size: {Font.FONT_SIZE_NORMAL};
    font-family: {Font.FONT_FAMILY};
}}

QMenuBar::item {{
    background: transparent;
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    margin: 0 {Dimension.SPACING_TIGHT}px;
}}

QMenuBar::item:selected {{
    background-color: {Color.PRIMARY_BLUE};
}}

QMenuBar::item:pressed {{
    background-color: {Color.SECONDARY_BLUE};
}}

QMenu {{
    background-color: {Color.BACKGROUND_LIGHT};
    color: {Color.TEXT_DARK};
    border: 1px solid {Color.BORDER_LIGHT};
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_SMALL}px 0px;
}}

QMenu::item {{
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-family: {Font.FONT_FAMILY};
}}

QMenu::item:selected {{
    background-color: {Color.SELECTION_LIGHT};
    color: {Color.SELECTION_DARK};
}}

QMenu::separator {{
    height: 1px;
    background-color: {Color.BORDER_LIGHT};
    margin: {Dimension.SPACING_TIGHT}px 0;
}}

/* =============================================================================
   TAB WIDGET STYLING
   ============================================================================= */

QTabWidget::pane {{
    border: 2px solid {Color.BORDER_NORMAL};
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    background-color: {Color.BACKGROUND_LIGHT};
}}

QTabBar::tab {{
    background-color: {Color.BACKGROUND_SOFT};
    color: {Color.TEXT_PRIMARY};
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_LARGE}px;
    margin: {Dimension.SPACING_TIGHT}px;
    border: 1px solid {Color.BORDER_NORMAL};
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    font-family: {Font.FONT_FAMILY};
    font-size: {Font.FONT_SIZE_NORMAL};
    font-weight: {Font.FONT_WEIGHT_MEDIUM};
}}

QTabBar::tab:selected {{
    background-color: {Color.PRIMARY_BLUE};
    color: white;
    border-color: {Color.SECONDARY_BLUE};
}}

QTabBar::tab:hover:!selected {{
    background-color: {Color.HOVER_MEDIUM};
}}

/* =============================================================================
   PROGRESS BAR AND SLIDER STYLING
   ============================================================================= */

QProgressBar {{
    border: 2px solid {Color.BORDER_NORMAL};
    border-radius: {Dimension.BORDER_RADIUS_LARGE}px;
    text-align: center;
    font-size: {Font.FONT_SIZE_NORMAL};
    font-weight: {Font.FONT_WEIGHT_BOLD};
    background-color: {Color.BACKGROUND_CARD};
    min-height: {Dimension.INPUT_HEIGHT}px;
}}

QProgressBar::chunk {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                              stop:0 {Color.PRIMARY_BLUE},
                              stop:1 {Color.SECONDARY_BLUE});
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
}}

QSlider::groove:horizontal {{
    border: 1px solid {Color.BORDER_NORMAL};
    height: 6px;
    background: {Color.BACKGROUND_CARD};
    border-radius: 3px;
}}

QSlider::handle:horizontal {{
    background: {Color.PRIMARY_BLUE};
    border: 2px solid {Color.BACKGROUND_LIGHT};
    width: 16px;
    margin: -6px 0;
    border-radius: 8px;
}}

QSlider::handle:horizontal:hover {{
    background: {Color.SECONDARY_BLUE};
    border-color: {Color.PRIMARY_BLUE};
}}

QSlider::sub-page:horizontal {{
    background: {Color.PRIMARY_BLUE};
    border-radius: 3px;
}}

/* =============================================================================
   STATUS BAR STYLING
   ============================================================================= */

QStatusBar {{
    background-color: {Color.BACKGROUND_SOFT};
    border-top: 1px solid {Color.BORDER_NORMAL};
    font-size: {Font.FONT_SIZE_SMALL};
    color: {Color.TEXT_SECONDARY};
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
}}

/* =============================================================================
   TOOLTIP STYLING
   ============================================================================= */

QToolTip {{
    background-color: {Color.BACKGROUND_DARK};
    color: white;
    border: 1px solid {Color.TEXT_SECONDARY};
    border-radius: {Dimension.BORDER_RADIUS_SMALL}px;
    padding: {Dimension.PADDING_SMALL}px {Dimension.PADDING_MEDIUM}px;
    font-size: {Font.FONT_SIZE_SMALL};
    font-family: {Font.FONT_FAMILY};
}}

/* =============================================================================
   SPECIALIZED COMPONENT STYLING
   ============================================================================= */

/* Calendar widget */
QCalendarWidget QToolButton {{
    height: 30px;
    width: 150px;
    color: {Color.TEXT_DARK};
    font-size: {Font.FONT_SIZE_MEDIUM};
    font-weight: {Font.FONT_WEIGHT_BOLD};
    icon-size: 20px;
}}

QCalendarWidget QWidget#qt_calendar_navigationbar {{
    background-color: {Color.PRIMARY_BLUE};
}}

QCalendarWidget QAbstractItemView:enabled {{
    font-size: {Font.FONT_SIZE_NORMAL};
    color: {Color.TEXT_DARK};
    background-color: {Color.BACKGROUND_LIGHT};
    selection-background-color: {Color.PRIMARY_BLUE};
    selection-color: white;
}}

/* Date/time edit */
QDateEdit, QDateTimeEdit {{
    background-color: {Color.BACKGROUND_LIGHT};
    border: 2px solid {Color.BORDER_NORMAL};
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
    font-size: {Font.FONT_SIZE_MEDIUM};
    min-height: {Dimension.INPUT_HEIGHT}px;
}}

QDateEdit:hover, QDateTimeEdit:hover {{
    border: 2px solid {Color.BORDER_DARK};
}}

QDateEdit:focus, QDateTimeEdit:focus {{
    border: 2px solid {Color.PRIMARY_BLUE};
}}

/* =============================================================================
   CUSTOM OBJECT NAME STYLING
   ============================================================================= */

/* Success result areas */
#successResult, #m_teChecksum {{
    background-color: #f0fdf4;
    border: 2px solid #86efac;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    font-family: {Font.MONOSPACE_FONT};
    font-size: {Font.FONT_SIZE_NORMAL};
    color: #166534;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
}}

#successResult:focus, #m_teChecksum:focus {{
    border: 2px solid {Color.SUCCESS_GREEN};
    background-color: #dcfce7;
}}

/* Warning input areas */
#warningInput, #m_leCompare {{
    background-color: #fffbeb;
    border: 2px solid #fbbf24;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
}}

#warningInput:focus, #m_leCompare:focus {{
    border: 2px solid {Color.WARNING_YELLOW};
    background-color: #fef3c7;
}}

/* Error display areas */
#errorDisplay {{
    background-color: #fef2f2;
    border: 2px solid #fecaca;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    font-family: {Font.MONOSPACE_FONT};
    font-size: {Font.FONT_SIZE_NORMAL};
    color: #b91c1c;
    padding: {Dimension.PADDING_MEDIUM}px {Dimension.PADDING_LARGE}px;
}}

/* =============================================================================
   UTILITY CLASSES
   ============================================================================= */

/* Card-like containers */
.CardContainer {{
    background-color: {Color.BACKGROUND_LIGHT};
    border: 1px solid {Color.BORDER_LIGHT};
    border-radius: {Dimension.BORDER_RADIUS_LARGE}px;
    padding: {Dimension.PADDING_LARGE}px;
}}

/* Highlight panels */
.HighlightPanel {{
    background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                    stop:0 {Color.BACKGROUND_LIGHT},
                                    stop:1 {Color.BACKGROUND_LIGHT});
    border: 1px solid #bae6fd;
    border-radius: {Dimension.BORDER_RADIUS_MEDIUM}px;
    padding: {Dimension.PADDING_MEDIUM}px;
}}

/* =============================================================================
   END OF STYLESHEET
   ============================================================================= */
"""


# Convenience functions for easy usage
def apply_theme(widget, theme_class=ModernBlueTheme) -> None:
    """Apply modern blue theme to a widget or application.

    Args:
        widget: QApplication or QWidget instance
        theme_class: Theme class to use (default: ModernBlueTheme)
    """
    # Directly use cached stylesheet for performance improvement
    widget.setStyleSheet(theme_class.get_stylesheet())


def get_theme_colors() -> dict[str, str]:
    """Get the color palette used in the modern blue theme.

    Returns:
        Dictionary of color constants
    """
    return {color.name: color.value for color in Color}


def get_theme_colors_enum():
    """Get the Color enum for the modern blue theme.

    Returns:
        Color enum class with all color constants
    """
    return Color


def get_theme_dimensions() -> dict[str, int]:
    """Get the dimension constants used in the modern blue theme.

    Returns:
        Dictionary of dimension constants
    """
    return {dim.name: dim.value for dim in Dimension}


def get_theme_dimensions_enum():
    """Get the Dimension enum for the modern blue theme.

    Returns:
        Dimension enum class with all dimension constants
    """
    return Dimension


def get_theme_fonts() -> dict[str, str]:
    """Get the font constants used in the modern blue theme.

    Returns:
        Dictionary of font constants
    """
    return {font.name: font.value for font in Font}


def get_theme_fonts_enum():
    """Get the Font enum for the modern blue theme.

    Returns:
        Font enum class with all font constants
    """
    return Font
