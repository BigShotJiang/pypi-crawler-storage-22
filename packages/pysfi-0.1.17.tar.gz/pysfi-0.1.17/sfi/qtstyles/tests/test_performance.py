"""
Performance tests for Qt Styles themes
"""

import time

from ..styles.modern_blue import ModernBlueTheme


class TestPerformance:
    """Performance benchmark tests."""

    def test_stylesheet_generation_performance(self):
        """Test stylesheet generation performance with caching."""
        # 清除缓存
        ModernBlueTheme.invalidate_cache()

        # 第一次生成（无缓存）
        start_time = time.perf_counter()
        stylesheet1 = ModernBlueTheme.get_stylesheet()
        first_gen_time = time.perf_counter() - start_time

        # 第二次生成（使用缓存）
        start_time = time.perf_counter()
        stylesheet2 = ModernBlueTheme.get_stylesheet()
        cached_gen_time = time.perf_counter() - start_time

        # 验证结果一致
        assert stylesheet1 == stylesheet2
        assert len(stylesheet1) > 1000  # 确保生成了实质性内容

        # 缓存版本应该显著更快（至少快5倍）
        speedup = (
            first_gen_time / cached_gen_time if cached_gen_time > 0 else float("inf")
        )
        print("\nPerformance Results:")
        print(f"First generation: {first_gen_time:.6f}s")
        print(f"Cached generation: {cached_gen_time:.6f}s")
        print(f"Speedup factor: {speedup:.2f}x")

        # 断言缓存确实提供了性能提升
        assert cached_gen_time < first_gen_time
        assert speedup > 2.0, f"Expected at least 2x speedup, got {speedup:.2f}x"

    def test_multiple_theme_applications(self):
        """Test performance of applying theme multiple times."""
        # 跳过Qt依赖的测试部分
        import pytest

        pytest.skip(
            "Qt application performance test skipped due to environment constraints"
        )

    def test_cache_invalidation(self):
        """Test cache invalidation works correctly."""
        # 生成初始样式表
        initial_sheet = ModernBlueTheme.get_stylesheet()

        # 修改主题类的缓存状态来模拟变化
        # 我们通过调用invalidate_cache来测试缓存失效
        ModernBlueTheme.invalidate_cache()

        # 再次生成样式表（应该重新生成）
        new_sheet = ModernBlueTheme.get_stylesheet()

        # 验证两次生成的结果相同（因为常量未真正改变）
        assert new_sheet == initial_sheet

        # 验证缓存机制正常工作
        ModernBlueTheme.invalidate_cache()


if __name__ == "__main__":
    # Run performance tests manually
    test_instance = TestPerformance()

    print("Running Performance Tests...")

    try:
        test_instance.test_stylesheet_generation_performance()
        print("✓ Stylesheet generation performance test passed")

        test_instance.test_multiple_theme_applications()
        print("✓ Multiple theme applications test passed")

        test_instance.test_cache_invalidation()
        print("✓ Cache invalidation test passed")

        print("\nAll performance tests passed! ✓")

    except Exception as e:
        print(f"\nPerformance test failed: {e}")
        import sys

        sys.exit(1)
