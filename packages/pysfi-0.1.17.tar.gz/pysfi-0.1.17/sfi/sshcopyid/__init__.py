"""SSH key deployment utility."""

from .sshcopyid import (
    SSHAuthenticationError,
    SSHConnectionError,
    SSHCopyIDConfig,
    SSHKeyNotFoundError,
    main,
    ssh_copy_id,
)

try:
    from .sshcopyid_gui import SSHCopyIDGUI
    from .sshcopyid_gui import main as gui_main

    HAS_GUI = True
except ImportError:
    HAS_GUI = False
    SSHCopyIDGUI = None
    gui_main = None

__all__ = [
    "SSHAuthenticationError",
    "SSHConnectionError",
    "SSHCopIDConfig",
    "SSHKeyNotFoundError",
    "main",
    "ssh_copy_id",
]

if HAS_GUI:
    __all__.extend(["SSHCopIDGUI", "gui_main"])
