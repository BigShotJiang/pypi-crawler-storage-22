# pyshielder - Python Code Shield

![Python Version](https://img.shields.io/badge/python-3.x-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

`pyshielder` (formerly `pyxblend`) is a powerful tool to protect your Python code. It combines advanced multi-layer bytecode obfuscation with native compilation to create highly secure executable scripts.

## Features

- **Advanced Layering**: Compiles code to bytecode, serializes with Marshal, compresses with Zlib, encodes with Base64, and obfuscates the structure.
- **Strong Encryption**: Wraps the obfuscated payload in a secure loader encrypted with rolling-key XOR and SHA-512.
- **Native Compilation**: The final loader is compiled into a native C binary using Cython and GCC, executing directly in memory.
- **Tamper Resistant**: No original source code or simple bytecode is visible. Reverse engineering requires reconstructing multiple layers of obscured logic.
- **Self-contained**: The output is a single Python script that self-compiles and executes.

## Installation

```bash
pip install pyshielder
```

*Note: You need `gcc` (or `clang`) and `python3-dev` installed on your system to use the encryption tool and to run the generated protected scripts.*

## Usage

### Command Line Interface

You can use `pyshielder` directly from the command line:

```bash
# Encrypt a file
pyshielder my_script.py

# Specify output directory
pyshielder my_script.py --output dist/protected_script.py
```

### Python API

```python
from pyshielder import encrypt

# Encrypt a script string
code = "print('Hello, protected world!')"
loader_code = encrypt(code)

# Save the loader to a file
with open("protected_script.py", "w") as f:
    f.write(loader_code)
```

## How it works

1. **Layer 1 (Bytecode & Encoding)**: Source code is compiled to bytecode, marshaled, compressed (Zlib), Base64 encoded, and structurally manipulated.
2. **Layer 2 (Encryption)**: The encoded payload is encrypted using a rolling-key XOR algorithm derived from SHA-512.
3. **Layer 3 (Native Translation)**: The decryption logic is translated into C code using Cython.
4. **Layer 4 (Loader Generation)**: A Python loader is generated that compiles the C code into a native extension at runtime and executes it in memory.

## License

MIT License - see [LICENSE](LICENSE) for details.
