from .core import PyShielder, encrypt

__version__ = '1.0.4'
