# Changelog

All notable changes to PyShrink will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned
- Progress bars for long operations
- Config file support (`.pyshrinkrc`)
- Plugin system for custom cleanup rules
- Dry-run mode to preview changes
- Statistics report (files removed, size saved)

---

## [1.0.0] - 2024-02-07

### Added
- Initial release of PyShrink CLI
- Interactive mode for step-by-step cleanup
- Automatic README.md generation with project structure
- Automatic requirements.txt generation from imports
- Full cleanup mode (--full flag)
- Custom arguments mode (--readme, --req flags)
- Rich terminal UI with colors and formatting
- Safe copy-based operation (original never modified)
- Timestamped ZIP file creation
- Smart junk file detection and removal
- VS Code extension integration
- Cross-platform support (Windows, macOS, Linux)

### Removed (Cleanup Targets)
- Python bytecode files (*.pyc, *.pyo, *.pyd)
- Cache directories (__pycache__, .pytest_cache, .mypy_cache)
- Virtual environments (.venv, venv, env)
- Git repository (.git)
- Build artifacts (build/, dist/, *.egg-info)
- System files (.DS_Store, Thumbs.db)
- Log files (*.log)
- Temporary files (*.tmp, *.temp)

### Features
- 🧹 Deep recursive cleanup
- 📦 Automatic packaging
- 📝 Documentation generation
- 📋 Dependency detection
- 🎨 Beautiful CLI with Rich
- 🔒 Safe operation (works on copy)
- ⚡ Fast execution
- 🌍 Cross-platform

---

## Version History Notes

### Version Numbering
- **MAJOR** version for incompatible API changes
- **MINOR** version for new functionality (backward compatible)
- **PATCH** version for bug fixes

### Release Process
1. Update version in `pyproject.toml`
2. Update this CHANGELOG.md
3. Commit changes
4. Create git tag: `git tag -a v1.0.0 -m "Release 1.0.0"`
5. Push tag: `git push origin v1.0.0`
6. Build package: `python -m build`
7. Test on TestPyPI: `twine upload --repository testpypi dist/*`
8. Publish to PyPI: `twine upload dist/*`

---

[Unreleased]: https://github.com/yourusername/pyshrink/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/yourusername/pyshrink/releases/tag/v1.0.0
