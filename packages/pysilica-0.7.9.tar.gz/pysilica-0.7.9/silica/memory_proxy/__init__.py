"""Memory Proxy Service - Remote KV proxy for blob storage with sync support."""

__version__ = "0.1.0"
