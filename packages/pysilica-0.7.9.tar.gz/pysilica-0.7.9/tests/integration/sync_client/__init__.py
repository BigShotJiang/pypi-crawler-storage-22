"""Integration tests for sync client against real memory proxy service."""
