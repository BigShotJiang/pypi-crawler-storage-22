from __future__ import annotations

from pyspark_cdc.entry import capture

__all__ = ["capture"]
