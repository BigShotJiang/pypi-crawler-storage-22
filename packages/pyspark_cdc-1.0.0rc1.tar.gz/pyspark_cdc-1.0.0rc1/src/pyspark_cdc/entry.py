from __future__ import annotations

from pyspark_cdc.capture import CapturerBuilder

capture = CapturerBuilder
