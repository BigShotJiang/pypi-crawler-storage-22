from __future__ import annotations

from pyspark_cdc.optimizer.delta_optimizer import delta_optimize

__all__ = ["delta_optimize"]
