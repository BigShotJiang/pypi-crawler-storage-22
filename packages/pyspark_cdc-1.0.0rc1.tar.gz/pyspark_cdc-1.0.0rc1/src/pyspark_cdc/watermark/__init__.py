from __future__ import annotations

from pyspark_cdc.watermark.models import WATERMARK_TYPES, Watermark

__all__ = ["WATERMARK_TYPES", "Watermark"]
