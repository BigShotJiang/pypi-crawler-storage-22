from typing import Union, List

from pyspark.sql import DataFrame

from pyspark_connectby.connectby_query import ConnectByQuery, CONNECT_BY_PATH_SEPARATOR


def connectBy(df: DataFrame, prior: str, to: str, start_with: Union[List[str], str] = None,
              connect_by_path_cols: [str] = None, connect_by_path_separator: str = CONNECT_BY_PATH_SEPARATOR) -> DataFrame:
    """ Returns a new :class:`DataFrame` with result for Connect By(hiearchical) query.
    It is very similar to connect_by clause in Oracle or Redshift.

    Parameters
    ----------
    df: :class:`DataFrame`
        contains hierarchical data. e.g. has child_id and parent_id columns: `emp_id` and `manager_id`
    prior:
        prior child_id column. e.g. `emp_id`
    to:
        connect to parent_id column. e.g `manager_id`
    start_with: str, or list of str, optional.
        specifies the root id(s) of the hierarchy. e.g `1` or `['1', '2']`.
        If you omit this parameter, all child_id in the df will be used as root ids.

    Examples
    --------
    The following performs a connect_by query on ``df``. `emp_id` '1' is used as root id.

    >>> from pyspark.sql import SparkSession
    >>> schema = 'emp_id string, manager_id string, name string'
    >>> data = [[1, None, 'Carlos'], \
                [11, 1, 'John'], \
                [111, 11, 'Jorge'], \
                [112, 11, 'Kwaku'], \
                [113, 11, 'Liu'], \
                [2, None, 'Mat']]
    >>> spark = SparkSession.builder.getOrCreate()
    >>> df = spark.createDataFrame(data, schema)
    >>> df2 = df.connectBy(prior='emp_id', to='manager_id', start_with='1')
    >>> df2.show()
    +------+----------+-----+-----------------+----------+------+
    |emp_id|START_WITH|LEVEL|CONNECT_BY_ISLEAF|manager_id|  name|
    +------+----------+-----+-----------------+----------+------+
    |     1|         1|    1|            false|      null|Carlos|
    |    11|         1|    2|            false|         1|  John|
    |   111|         1|    3|             true|        11| Jorge|
    |   112|         1|    3|             true|        11| Kwaku|
    |   113|         1|    3|             true|        11|   Liu|
    +------+----------+-----+-----------------+----------+------+
    """
    query = ConnectByQuery(df, child_col=prior, parent_col=to, start_with=start_with,
                           connect_by_path_cols=connect_by_path_cols, connect_by_path_separator=connect_by_path_separator)
    return query.get_result_df()


DataFrame.connectBy = connectBy
