# Documentation

This directory contains documentation for the PySpark UDTF project.

## Design Documents
- [Meta CAPI Design](design/meta_capi.md): Design documentation for the Meta CAPI integration.
