import re
from pyspedas.projects.mms.mms_load_data import mms_load_data
from pyspedas.projects.mms.fgm_tools.mms_fgm_remove_flags import mms_fgm_remove_flags
from pyspedas.projects.mms.fgm_tools.mms_fgm_set_metadata import mms_fgm_set_metadata
from pyspedas.projects.mms.fgm_tools.mms_split_fgm_data import mms_split_fgm_data
from pyspedas.projects.mms.mms_config import CONFIG
from pyspedas.tplot_tools import data_exists
from pyspedas import del_data


def mms_load_fgm(trange=['2015-10-16', '2015-10-17'], probe='1', data_rate='srvy',
    level='l2', instrument='fgm', datatype='', varformat=None, exclude_format='*rdeltahalf*', varnames=[], suffix='',
    keep_flagged=False, get_support_data=True, time_clip=False, no_update=False,
    available=False, notplot=False, latest_version=False, major_version=False, 
    min_version=None, cdf_version=None, spdf=False, always_prompt=False, no_split_vars=False,
    get_fgm_ephemeris=False):
    """
    Load MMS fluxgate magnetometer data
    
    Parameters
    ----------
        trange : list of str
            time range of interest [start time, end time] with the format
            'YYYY-MM-DD','YYYY-MM-DD'] or to specify more or less than a day 
            ['YYYY-MM-DD/hh:mm:ss','YYYY-MM-DD/hh:mm:ss']
            Default: ['2015-10-16', '2015-10-17']

        probe : str or list of str
            list of probes, valid values for MMS probes are ['1','2','3','4'].
            Default: '1'

        data_rate : str or list of str
            instrument data rates for FGM include 'brst' 'fast' 'slow' 'srvy'. The
            default is 'srvy'.
            Default: 'srvy'

        level : str
            indicates level of data processing. the default if no level is specified is 'l2'
            Default: 'l2'

        datatype : str or list of str
            Do not use: defined only for consistency with other load routines.  All FGM data will be loaded.
            Default: ''

        get_support_data: bool
            Data with an attribute "VAR_TYPE" with a value of "support_data"
            will be loaded into tplot.
            Default: True

        time_clip: bool
            Data will be clipped to the exact trange specified by the trange keyword.
            Default: False
            
        varformat: str
            The file variable formats to load into tplot.  Wildcard character
            "*" is accepted.
            Default: None (all variables are loaded)

        exclude_format: str
            Variables matching this pattern will not be processed while loading the CDFs.
            Wildcard character "*" is allowed.
            Default: '*rdeltahalf*'

        varnames: list of str
            List of variable names to load. If list is empty or not specified,
            all data variables are loaded.
            Default: []

        suffix: str
            The tplot variable names will be given this suffix.
            Default: None

        notplot: bool
            If True, then data are returned in a hash table instead of 
            being stored in tplot variables (useful for debugging, and
            access to multidimensional data products)
            Default: False

        available: bool
            If True, simply return the available data files (without downloading)
            for the requested parameters
            Default: False

        no_update: bool
            Set this flag to preserve the original data. if not set and newer 
            data is found the existing data will be overwritten
            Default: False

        cdf_version: str
            Specify a specific CDF version # to load (e.g., cdf_version='4.3.0')
            Default: None

        min_version: str
            Specify a minimum CDF version # to load
            Default: None

        latest_version: bool
            Only grab the latest CDF version in the requested time interval
            Default: False

        major_version: bool
            Only open the latest major CDF version (e.g., X in vX.Y.Z) in the requested time interval
            Default: False

        keep_flagged: bool
            If True, don't remove flagged data (flagged data are set to NaNs by
            default, this keyword turns this off)
            Default: False

        always_prompt: bool
            Set this keyword to always prompt for the user's username and password;
            useful if you accidentally save an incorrect password, or if your SDC password has changed
            Default: False

        spdf: bool
            If True, download the data from the SPDF instead of the SDC
            Default: False

        get_fgm_ephemeris: bool
            Keep the ephemeris variables in the FGM files
            Default: False
            
    Returns
    -------
        list of str
            List of tplot variables created.

    Example
    -------

    >>> import pyspedas
    >>> from pyspedas import tplot
    >>> fgm_vars = pyspedas.projects.mms.mms_load_fgm(trange=['2015-10-16', '2015-10-17'])
    >>> tplot('mms1_fgm_b_gsm_srvy_l2')

    """
    if (varformat is not None) and (not keep_flagged) and (not available) and (not notplot):
        varformat_fetch = varformat+'|*_flag_*'
    else:
        varformat_fetch = varformat

    tvars = mms_load_data(trange=trange, notplot=notplot, probe=probe, data_rate=data_rate, level=level, instrument=instrument,
            datatype=datatype, varformat=varformat_fetch, exclude_format=exclude_format, varnames=varnames, suffix=suffix, get_support_data=get_support_data,
            time_clip=time_clip, no_update=no_update, available=available, latest_version=latest_version, major_version=major_version, 
            min_version=min_version, cdf_version=cdf_version, spdf=spdf, always_prompt=always_prompt)
    
    if tvars is None or available or notplot or CONFIG['download_only']:
        return tvars

    if not isinstance(probe, list): probe = [probe]
    if not isinstance(data_rate, list): data_rate = [data_rate]
    if not isinstance(level, list): level = [level]

    # the probes will need to be strings beyond this point
    if isinstance(probe, list):
        probe = [str(p) for p in probe]

    # remove flagged data
    if not keep_flagged:
        mms_fgm_remove_flags(probe, data_rate, level, instrument, suffix=suffix)
        # Delete the flags variable if it was not originally requested
        if varformat is not None:
            regex = re.compile(varformat.replace("*", ".*"))
            tvars_to_delete = [tvar for tvar in tvars if not re.match(regex, tvar)]
            for tvar in tvars_to_delete:
                del_data(tvar)
                tvars.remove(tvar)

    for prb in probe:
        for drate in data_rate:
            for lvl in level:
                if not no_split_vars:
                    out = mms_split_fgm_data(prb, drate, lvl, instrument, suffix=suffix)
                    tvars.extend(out)

                if lvl.lower() != 'ql':
                    # delete the ephemeris variables if not requested
                    if not get_fgm_ephemeris:
                        if data_exists('mms'+prb+'_'+instrument+'_r_gse_'+drate+'_'+lvl+suffix):
                            del_data('mms'+prb+'_'+instrument+'_r_gse_'+drate+'_'+lvl+suffix)
                            tvars.remove('mms'+prb+'_'+instrument+'_r_gse_'+drate+'_'+lvl+suffix)
                        if data_exists('mms'+prb+'_'+instrument+'_r_gsm_'+drate+'_'+lvl+suffix):
                            del_data('mms'+prb+'_'+instrument+'_r_gsm_'+drate+'_'+lvl+suffix)
                            tvars.remove('mms'+prb+'_'+instrument+'_r_gsm_'+drate+'_'+lvl+suffix)
                        if data_exists('mms'+prb+'_pos_gse'+suffix):
                            del_data('mms'+prb+'_pos_gse'+suffix)
                            tvars.remove('mms'+prb+'_pos_gse'+suffix)
                        if data_exists('mms'+prb+'_pos_gsm'+suffix):
                            del_data('mms'+prb+'_pos_gsm'+suffix)
                            tvars.remove('mms'+prb+'_pos_gsm'+suffix)

    mms_fgm_set_metadata(probe, data_rate, level, instrument, suffix=suffix)

    return tvars
