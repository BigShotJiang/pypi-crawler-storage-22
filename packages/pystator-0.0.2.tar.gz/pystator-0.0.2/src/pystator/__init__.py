"""PyStator — Configuration-driven Finite State Machine library for Python.

Quick start::

    from pystator import StateMachine, GuardRegistry, Event

    machine = StateMachine.from_yaml("order_fsm.yaml")
    guards  = GuardRegistry()
    guards.register("is_full_fill", lambda ctx: ctx["fill_qty"] >= ctx["order_qty"])
    machine.bind_guards(guards)

    result = machine.process("OPEN", "execution_report", {"fill_qty": 100, "order_qty": 100})
    if result.success:
        print(f"{result.source_state} -> {result.target_state}")
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Version
# ---------------------------------------------------------------------------

try:
    from importlib.metadata import version

    __version__ = version("pystator")
except Exception:
    __version__ = "0.0.1"

# ---------------------------------------------------------------------------
# Core
# ---------------------------------------------------------------------------

from pystator.core.errors import (
    ActionNotFoundError,
    ConfigurationError,
    ErrorPolicy,
    FSMError,
    GuardNotFoundError,
    GuardRejectedError,
    InvalidTransitionError,
    TerminalStateError,
    TimeoutExpiredError,
    UndefinedStateError,
    UndefinedTriggerError,
)
from pystator.core.event import Event
from pystator.core.machine import StateMachine
from pystator.core.parallel import ParallelStateConfig, ParallelStateManager
from pystator.core.state import Region, State, StateType, Timeout
from pystator.core.state_store import AsyncStateStore, InMemoryStateStore, StateStore
from pystator.core.transition import (
    ActionSpec,
    GuardSpec,
    Transition,
    TransitionResult,
    parse_delay,
)

# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------

from pystator.guards.builtins import (
    all_of,
    always_false,
    always_true,
    any_of,
    equals,
    greater_or_equal,
    greater_than,
    has_key,
    in_list,
    is_not_none,
    is_truthy,
    less_or_equal,
    less_than,
    negate,
    none_of,
    not_equals,
    not_in_list,
    register_builtins,
)
from pystator.guards.evaluator import GuardEvaluator
from pystator.guards.registry import (
    AnyGuardFunc,
    AsyncGuardFunc,
    GuardFunc,
    GuardRegistry,
    GuardResult,
)

# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------

from pystator.actions.executor import ActionExecutor, ExecutionMode, ExecutionResult
from pystator.actions.registry import (
    ActionFunc,
    ActionRegistry,
    ActionResult,
    AnyActionFunc,
    AsyncActionFunc,
)
from pystator.actions.retry import RetryExecutor, RetryPolicy, RetryResult

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

from pystator.config.loader import ConfigLoader, load_config
from pystator.config.validator import ConfigValidator, validate_config

# ---------------------------------------------------------------------------
# Builder
# ---------------------------------------------------------------------------

from pystator.builder import StateMachineBuilder

# ---------------------------------------------------------------------------
# Scheduler
# ---------------------------------------------------------------------------

from pystator.scheduler import (
    AsyncioScheduler,
    ScheduledTask,
    SchedulerAdapter,
    TaskStatus,
)

# ---------------------------------------------------------------------------
# Timeout
# ---------------------------------------------------------------------------

from pystator.timeout.manager import (
    TimeoutInfo,
    TimeoutManager,
    check_timeout,
    get_timeout_info,
)

# ---------------------------------------------------------------------------
# Visualization
# ---------------------------------------------------------------------------

from pystator.visualization import (
    get_statistics,
    to_dot,
    to_mermaid,
    to_mermaid_flowchart,
)

# ---------------------------------------------------------------------------
# Observability
# ---------------------------------------------------------------------------

from pystator.observability import (
    LoggingHook,
    MetricsCollector,
    TransitionHook,
    TransitionMetrics,
    TransitionObserver,
    with_timing,
)

# ---------------------------------------------------------------------------
# Idempotency
# ---------------------------------------------------------------------------

from pystator.idempotency import (
    IdempotencyBackend,
    IdempotencyChecker,
    IdempotencyRecord,
    IdempotencyResult,
    InMemoryIdempotencyBackend,
    NoOpIdempotencyBackend,
)

# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

from pystator.orchestration import Orchestrator

# ---------------------------------------------------------------------------
# Serialization utilities
# ---------------------------------------------------------------------------

from pystator.utils.serialization import (
    deserialize_state,
    deserialize_transition_result,
    serialize_state,
    serialize_transition_result,
)

# ---------------------------------------------------------------------------
# Lazy imports for optional backends (sqlalchemy, redis)
# ---------------------------------------------------------------------------


def __getattr__(name: str):  # type: ignore[override]
    _lazy = {
        "SQLAlchemyStateStore": "pystator.state_stores.sqlalchemy_store",
        "AsyncSQLAlchemyStateStore": "pystator.state_stores.sqlalchemy_store",
        "RedisStateStore": "pystator.state_stores.redis_store",
    }
    module_path = _lazy.get(name)
    if module_path:
        import importlib

        mod = importlib.import_module(module_path)
        return getattr(mod, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

__all__ = [
    "__version__",
    # Core
    "StateMachine",
    "StateMachineBuilder",
    "State",
    "StateType",
    "Timeout",
    "Region",
    "Transition",
    "TransitionResult",
    "GuardSpec",
    "ActionSpec",
    "parse_delay",
    "Event",
    "ParallelStateConfig",
    "ParallelStateManager",
    # Errors
    "FSMError",
    "ConfigurationError",
    "InvalidTransitionError",
    "GuardRejectedError",
    "UndefinedStateError",
    "UndefinedTriggerError",
    "TimeoutExpiredError",
    "GuardNotFoundError",
    "ActionNotFoundError",
    "TerminalStateError",
    "ErrorPolicy",
    # Guards
    "GuardRegistry",
    "GuardFunc",
    "AsyncGuardFunc",
    "AnyGuardFunc",
    "GuardResult",
    "GuardEvaluator",
    "register_builtins",
    "always_true",
    "always_false",
    "is_not_none",
    "is_truthy",
    "equals",
    "not_equals",
    "greater_than",
    "less_than",
    "greater_or_equal",
    "less_or_equal",
    "in_list",
    "not_in_list",
    "has_key",
    "all_of",
    "any_of",
    "none_of",
    "negate",
    # Actions
    "ActionRegistry",
    "ActionFunc",
    "AsyncActionFunc",
    "AnyActionFunc",
    "ActionResult",
    "ActionExecutor",
    "ExecutionResult",
    "ExecutionMode",
    "RetryPolicy",
    "RetryResult",
    "RetryExecutor",
    # Configuration
    "ConfigLoader",
    "ConfigValidator",
    "load_config",
    "validate_config",
    # Scheduler
    "SchedulerAdapter",
    "ScheduledTask",
    "TaskStatus",
    "AsyncioScheduler",
    # Timeout
    "TimeoutManager",
    "TimeoutInfo",
    "check_timeout",
    "get_timeout_info",
    # Visualization
    "to_mermaid",
    "to_mermaid_flowchart",
    "to_dot",
    "get_statistics",
    # Observability
    "TransitionMetrics",
    "TransitionHook",
    "LoggingHook",
    "MetricsCollector",
    "TransitionObserver",
    "with_timing",
    # Idempotency
    "IdempotencyBackend",
    "IdempotencyRecord",
    "IdempotencyResult",
    "IdempotencyChecker",
    "InMemoryIdempotencyBackend",
    "NoOpIdempotencyBackend",
    # Orchestration
    "Orchestrator",
    "StateStore",
    "AsyncStateStore",
    "InMemoryStateStore",
    # State stores (lazy)
    "SQLAlchemyStateStore",
    "AsyncSQLAlchemyStateStore",
    "RedisStateStore",
    # Serialization
    "serialize_state",
    "deserialize_state",
    "serialize_transition_result",
    "deserialize_transition_result",
]
