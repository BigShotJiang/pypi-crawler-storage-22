"""CLI entry-point for PyStator: ``pystator api | ui | db``."""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(
        description="PyStator — FSM library",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", help="Command", required=True)

    # --- api ---------------------------------------------------------------
    api_p = sub.add_parser("api", help="Start the API server")
    api_p.add_argument("--host", default="0.0.0.0")
    api_p.add_argument("--port", type=int, default=8000)
    api_p.add_argument("--reload", action="store_true", default=True)
    api_p.add_argument("--no-reload", dest="reload", action="store_false")

    # --- ui ----------------------------------------------------------------
    ui_p = sub.add_parser("ui", help="UI commands")
    ui_sub = ui_p.add_subparsers(dest="ui_command", required=True)

    serve_p = ui_sub.add_parser("serve", help="Serve built UI")
    serve_p.add_argument("--api-url", default=None)
    serve_p.add_argument("--host", default="127.0.0.1")
    serve_p.add_argument("--port", type=int, default=3000)

    dev_p = ui_sub.add_parser("dev", help="Run UI dev server")
    dev_p.add_argument("--api-url", default=None)
    dev_p.add_argument("--port", type=int, default=3000)

    ui_sub.add_parser("build", help="Build UI for production")

    # --- db ----------------------------------------------------------------
    sub.add_parser(
        "db",
        help="Database management commands",
        description="Manage PyStator database: init, upgrade, downgrade, seed, truncate",
    )

    args, remaining = parser.parse_known_args()

    # -- dispatch -----------------------------------------------------------

    if args.command == "api":
        return _run_api(args)

    if args.command == "db":
        return _run_db(remaining)

    if args.command == "ui":
        return _run_ui(args)

    return 0


# ---------------------------------------------------------------------------
# Sub-command handlers
# ---------------------------------------------------------------------------


def _run_api(args: argparse.Namespace) -> int:
    try:
        import uvicorn
    except ImportError:
        print("uvicorn is required. Install with: pip install pystator[api]", file=sys.stderr)
        return 1
    uvicorn.run(
        "pystator.api.main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )
    return 0


def _run_db(remaining: list[str]) -> int:
    try:
        from pystator.db.cli import main as db_main
    except ImportError as e:
        print(f"Database CLI not available: {e}", file=sys.stderr)
        return 1
    sys.argv = ["pystator db", *remaining]
    return db_main()


def _run_ui(args: argparse.Namespace) -> int:
    ui_path = Path(__file__).parent / "ui"
    if not ui_path.exists():
        print("UI module not found.", file=sys.stderr)
        return 1

    api_url = args.api_url or os.getenv("PYSTATOR_API_URL")

    if args.ui_command == "serve":
        from pystator.ui.server import serve_ui

        serve_ui(api_url=api_url, host=args.host, port=args.port)
        return 0

    if args.ui_command == "dev":
        from pystator.ui.dev import run_dev

        run_dev(api_url=api_url, port=args.port)
        return 0

    if args.ui_command == "build":
        from pystator.ui.build import build_ui

        return build_ui()

    return 1


if __name__ == "__main__":
    sys.exit(main())
