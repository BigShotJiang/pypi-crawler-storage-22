"""
State store implementations for PyStator.

Available implementations:
- SQLAlchemyStateStore: Database-backed store using SQLAlchemy (PostgreSQL, SQLite, etc.)
- RedisStateStore: High-throughput Redis-backed store
- InMemoryStateStore: (from core.state_store) For testing and simple use cases

All stores implement the StateStore and/or AsyncStateStore protocols.
"""

from pystator.core.state_store import InMemoryStateStore, StateStore, AsyncStateStore

__all__ = [
    "SQLAlchemyStateStore",
    "AsyncSQLAlchemyStateStore",
    "RedisStateStore",
    "InMemoryStateStore",
    "StateStore",
    "AsyncStateStore",
]

# Lazy imports to avoid requiring sqlalchemy/redis for basic usage
def __getattr__(name: str):
    if name == "SQLAlchemyStateStore":
        from pystator.state_stores.sqlalchemy_store import SQLAlchemyStateStore
        return SQLAlchemyStateStore
    if name == "AsyncSQLAlchemyStateStore":
        from pystator.state_stores.sqlalchemy_store import AsyncSQLAlchemyStateStore
        return AsyncSQLAlchemyStateStore
    if name == "RedisStateStore":
        from pystator.state_stores.redis_store import RedisStateStore
        return RedisStateStore
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
