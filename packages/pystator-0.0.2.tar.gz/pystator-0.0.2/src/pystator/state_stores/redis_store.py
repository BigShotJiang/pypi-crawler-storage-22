"""
Redis-based state store for PyStator.

High-throughput state store using Redis HSET/HGET. Suitable for high-traffic
scenarios where database writes would be a bottleneck.

Usage:
    import redis.asyncio as redis
    from pystator.state_stores import RedisStateStore

    redis_client = redis.from_url("redis://localhost:6379")
    store = RedisStateStore(redis_client)

Note: This store is async-only. If you need sync access, use SQLAlchemyStateStore.
"""

from __future__ import annotations

import json
import logging
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    import redis.asyncio

logger = logging.getLogger(__name__)


class RedisStateStore:
    """Async Redis state store.

    Implements the AsyncStateStore protocol using Redis HSET/HGET.
    Each entity's state is stored as a hash with fields: state, context, machine_name.

    Key pattern: {prefix}{entity_id}
    Hash fields:
        - state: Current state name
        - context: JSON-encoded context dict
        - machine_name: Optional machine name
    """

    def __init__(
        self,
        redis_client: "redis.asyncio.Redis",
        *,
        prefix: str = "pystator:entity:",
        machine_name: str | None = None,
        persist_context: bool = False,
        ttl_seconds: int | None = None,
    ) -> None:
        """Initialize the Redis state store.

        Args:
            redis_client: Async Redis client (redis.asyncio.Redis).
            prefix: Key prefix for entity state hashes.
            machine_name: Optional machine name to store with each entity.
            persist_context: If True, also persist context on aset_state.
            ttl_seconds: Optional TTL for entity keys (for auto-cleanup).
        """
        self._redis = redis_client
        self._prefix = prefix
        self._machine_name = machine_name
        self._persist_context = persist_context
        self._ttl = ttl_seconds

    def _key(self, entity_id: str) -> str:
        """Get the Redis key for an entity."""
        return f"{self._prefix}{entity_id}"

    async def aget_state(self, entity_id: str) -> str | None:
        """Return the current FSM state for the entity.

        Args:
            entity_id: Unique identifier for the entity.

        Returns:
            Current state name, or None if entity not found.
        """
        key = self._key(entity_id)
        state = await self._redis.hget(key, "state")
        if state is None:
            return None
        return state.decode("utf-8") if isinstance(state, bytes) else state

    async def aset_state(
        self,
        entity_id: str,
        state: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Persist the new FSM state.

        Args:
            entity_id: Unique identifier for the entity.
            state: The new state name to persist.
            metadata: Optional metadata.
        """
        key = self._key(entity_id)
        mapping: dict[str, str] = {"state": state}

        if self._machine_name:
            mapping["machine_name"] = self._machine_name

        if self._persist_context and metadata and "context" in metadata:
            mapping["context"] = json.dumps(metadata["context"])

        await self._redis.hset(key, mapping=mapping)

        if self._ttl:
            await self._redis.expire(key, self._ttl)

        logger.debug(f"Set state for {entity_id} to {state}")

    async def aget_context(self, entity_id: str) -> dict[str, Any]:
        """Return stored context for the entity.

        Args:
            entity_id: Unique identifier for the entity.

        Returns:
            Context dict, or empty dict if not found.
        """
        key = self._key(entity_id)
        context_json = await self._redis.hget(key, "context")
        if context_json is None:
            return {}
        if isinstance(context_json, bytes):
            context_json = context_json.decode("utf-8")
        try:
            return json.loads(context_json)
        except (json.JSONDecodeError, TypeError):
            return {}

    async def adelete_entity(self, entity_id: str) -> bool:
        """Delete an entity's state record.

        Args:
            entity_id: Unique identifier for the entity.

        Returns:
            True if a record was deleted, False if not found.
        """
        key = self._key(entity_id)
        deleted = await self._redis.delete(key)
        return deleted > 0

    async def aexists(self, entity_id: str) -> bool:
        """Check if an entity exists.

        Args:
            entity_id: Unique identifier for the entity.

        Returns:
            True if entity exists, False otherwise.
        """
        key = self._key(entity_id)
        return await self._redis.exists(key) > 0

    async def alist_entities(
        self,
        *,
        pattern: str = "*",
        limit: int = 100,
    ) -> list[str]:
        """List entity IDs matching a pattern.

        Args:
            pattern: Glob pattern for entity IDs (after prefix).
            limit: Maximum number of entities to return.

        Returns:
            List of entity IDs.
        """
        key_pattern = f"{self._prefix}{pattern}"
        cursor = 0
        entities: list[str] = []

        while len(entities) < limit:
            cursor, keys = await self._redis.scan(
                cursor=cursor,
                match=key_pattern,
                count=min(limit - len(entities), 100),
            )
            for key in keys:
                if isinstance(key, bytes):
                    key = key.decode("utf-8")
                entity_id = key[len(self._prefix) :]
                entities.append(entity_id)
            if cursor == 0:
                break

        return entities[:limit]
