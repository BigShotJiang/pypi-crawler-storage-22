"""
SQLAlchemy-based state store for PyStator.

Works with any SQLAlchemy-supported database (PostgreSQL, SQLite, MySQL, etc.).
Uses the EntityStateModel for persistence.

Usage (sync):
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from pystator.state_stores import SQLAlchemyStateStore

    engine = create_engine("postgresql://...")
    SessionLocal = sessionmaker(bind=engine)
    store = SQLAlchemyStateStore(SessionLocal)

Usage (async):
    from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
    from pystator.state_stores import AsyncSQLAlchemyStateStore

    engine = create_async_engine("postgresql+asyncpg://...")
    AsyncSessionLocal = async_sessionmaker(bind=engine)
    store = AsyncSQLAlchemyStateStore(AsyncSessionLocal)
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Any, Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from sqlalchemy.orm import Session
    from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)


class SQLAlchemyStateStore:
    """Sync SQLAlchemy state store.

    Implements the StateStore protocol using SQLAlchemy sessions.
    Stores entity state in the entity_states table.
    """

    def __init__(
        self,
        session_factory: Callable[[], "Session"],
        *,
        machine_name: str | None = None,
        persist_context: bool = False,
    ) -> None:
        """Initialize the state store.

        Args:
            session_factory: Callable that returns a new SQLAlchemy Session.
                Typically sessionmaker(bind=engine).
            machine_name: Optional machine name filter (for multi-machine setups).
            persist_context: If True, also persist context_json on set_state.
        """
        self._session_factory = session_factory
        self._machine_name = machine_name
        self._persist_context = persist_context

    @contextmanager
    def _session(self):
        """Context manager for session handling."""
        session = self._session_factory()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def get_state(self, entity_id: str) -> str | None:
        """Return the current FSM state for the entity.

        Args:
            entity_id: Unique identifier for the entity.

        Returns:
            Current state name, or None if entity not found.
        """
        # Import here to avoid circular imports and to make sqlalchemy optional
        from pystator.db.models import EntityStateModel

        with self._session() as session:
            query = session.query(EntityStateModel).filter(
                EntityStateModel.entity_id == entity_id
            )
            if self._machine_name:
                query = query.filter(EntityStateModel.machine_name == self._machine_name)
            row = query.first()
            return row.current_state if row else None

    def set_state(
        self,
        entity_id: str,
        state: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Persist the new FSM state.

        Args:
            entity_id: Unique identifier for the entity.
            state: The new state name to persist.
            metadata: Optional metadata (e.g., trigger, source_state, target_state).
                If persist_context is True and metadata contains 'context',
                it will be stored in context_json.
        """
        from pystator.db.models import EntityStateModel

        with self._session() as session:
            query = session.query(EntityStateModel).filter(
                EntityStateModel.entity_id == entity_id
            )
            if self._machine_name:
                query = query.filter(EntityStateModel.machine_name == self._machine_name)

            row = query.first()
            if row:
                row.current_state = state
                if self._persist_context and metadata and "context" in metadata:
                    row.context_json = metadata["context"]
            else:
                row = EntityStateModel(
                    entity_id=entity_id,
                    current_state=state,
                    machine_name=self._machine_name,
                )
                if self._persist_context and metadata and "context" in metadata:
                    row.context_json = metadata["context"]
                session.add(row)

            logger.debug(f"Set state for {entity_id} to {state}")

    def get_context(self, entity_id: str) -> dict[str, Any]:
        """Return stored context for the entity.

        Args:
            entity_id: Unique identifier for the entity.

        Returns:
            Context dict (from context_json), or empty dict if not found.
        """
        from pystator.db.models import EntityStateModel

        with self._session() as session:
            query = session.query(EntityStateModel).filter(
                EntityStateModel.entity_id == entity_id
            )
            if self._machine_name:
                query = query.filter(EntityStateModel.machine_name == self._machine_name)
            row = query.first()
            if row and row.context_json:
                return dict(row.context_json)
            return {}

    def delete_entity(self, entity_id: str) -> bool:
        """Delete an entity's state record.

        Args:
            entity_id: Unique identifier for the entity.

        Returns:
            True if a record was deleted, False if not found.
        """
        from pystator.db.models import EntityStateModel

        with self._session() as session:
            query = session.query(EntityStateModel).filter(
                EntityStateModel.entity_id == entity_id
            )
            if self._machine_name:
                query = query.filter(EntityStateModel.machine_name == self._machine_name)
            deleted = query.delete()
            return deleted > 0


class AsyncSQLAlchemyStateStore:
    """Async SQLAlchemy state store.

    Implements the AsyncStateStore protocol using async SQLAlchemy sessions.
    Stores entity state in the entity_states table.
    """

    def __init__(
        self,
        async_session_factory: Callable[[], "AsyncSession"],
        *,
        machine_name: str | None = None,
        persist_context: bool = False,
    ) -> None:
        """Initialize the async state store.

        Args:
            async_session_factory: Callable that returns a new async Session.
                Typically async_sessionmaker(bind=async_engine).
            machine_name: Optional machine name filter (for multi-machine setups).
            persist_context: If True, also persist context_json on aset_state.
        """
        self._session_factory = async_session_factory
        self._machine_name = machine_name
        self._persist_context = persist_context

    async def aget_state(self, entity_id: str) -> str | None:
        """Return the current FSM state for the entity (async).

        Args:
            entity_id: Unique identifier for the entity.

        Returns:
            Current state name, or None if entity not found.
        """
        from sqlalchemy import select
        from pystator.db.models import EntityStateModel

        async with self._session_factory() as session:
            stmt = select(EntityStateModel).where(
                EntityStateModel.entity_id == entity_id
            )
            if self._machine_name:
                stmt = stmt.where(EntityStateModel.machine_name == self._machine_name)
            result = await session.execute(stmt)
            row = result.scalar_one_or_none()
            return row.current_state if row else None

    async def aset_state(
        self,
        entity_id: str,
        state: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Persist the new FSM state (async).

        Args:
            entity_id: Unique identifier for the entity.
            state: The new state name to persist.
            metadata: Optional metadata.
        """
        from sqlalchemy import select
        from pystator.db.models import EntityStateModel

        async with self._session_factory() as session:
            stmt = select(EntityStateModel).where(
                EntityStateModel.entity_id == entity_id
            )
            if self._machine_name:
                stmt = stmt.where(EntityStateModel.machine_name == self._machine_name)
            result = await session.execute(stmt)
            row = result.scalar_one_or_none()

            if row:
                row.current_state = state
                if self._persist_context and metadata and "context" in metadata:
                    row.context_json = metadata["context"]
            else:
                row = EntityStateModel(
                    entity_id=entity_id,
                    current_state=state,
                    machine_name=self._machine_name,
                )
                if self._persist_context and metadata and "context" in metadata:
                    row.context_json = metadata["context"]
                session.add(row)

            await session.commit()
            logger.debug(f"Set state for {entity_id} to {state}")

    async def aget_context(self, entity_id: str) -> dict[str, Any]:
        """Return stored context for the entity (async).

        Args:
            entity_id: Unique identifier for the entity.

        Returns:
            Context dict (from context_json), or empty dict if not found.
        """
        from sqlalchemy import select
        from pystator.db.models import EntityStateModel

        async with self._session_factory() as session:
            stmt = select(EntityStateModel).where(
                EntityStateModel.entity_id == entity_id
            )
            if self._machine_name:
                stmt = stmt.where(EntityStateModel.machine_name == self._machine_name)
            result = await session.execute(stmt)
            row = result.scalar_one_or_none()
            if row and row.context_json:
                return dict(row.context_json)
            return {}

    async def adelete_entity(self, entity_id: str) -> bool:
        """Delete an entity's state record (async).

        Args:
            entity_id: Unique identifier for the entity.

        Returns:
            True if a record was deleted, False if not found.
        """
        from sqlalchemy import delete
        from pystator.db.models import EntityStateModel

        async with self._session_factory() as session:
            stmt = delete(EntityStateModel).where(
                EntityStateModel.entity_id == entity_id
            )
            if self._machine_name:
                stmt = stmt.where(EntityStateModel.machine_name == self._machine_name)
            result = await session.execute(stmt)
            await session.commit()
            return result.rowcount > 0
