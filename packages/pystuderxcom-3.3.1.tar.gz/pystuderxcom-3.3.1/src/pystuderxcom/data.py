##
## Class implementing Xcom protocol data objects
##
## See the studer document: "Technical Specification - Xtender serial protocol"
## Download from:
##   https://studer-innotec.com/downloads/ 
##   -> Downloads -> software + updates -> communication protocol xcom 232i
##


import asyncio
from dataclasses import dataclass
import io
import logging
import struct
import uuid

from io import BufferedWriter, BufferedReader, BytesIO
from typing import Any, Iterable

from .const import (
    XcomFormat,
    XcomAggregationType,
    XcomParamException,
)

_LOGGER = logging.getLogger(__name__)

MULTI_INFO_REQ_MAX = 76


@dataclass
class XcomDiscoveredClient:
    ip: str = None
    guid: str = None


@dataclass
class XcomDiscoveredDevice:
    # Base info
    code: str
    addr: int
    family_id: str
    family_model: str

    # Extended info
    device_model: str = None
    hw_version: str = None
    sw_version: str = None
    fid: str = None


class XcomData:
    NONE = b''

    @staticmethod
    def unpack(value: bytes, format):
        match format:
            case XcomFormat.BOOL: return struct.unpack("<?", value)[0]          # 1 byte, little endian, bool
            case XcomFormat.ERROR: return struct.unpack("<H", value)[0]         # 2 bytes, little endian, unsigned short/int16
            case XcomFormat.FORMAT: return struct.unpack("<H", value)[0]        # 2 bytes, little endian, unsigned short/int16
            case XcomFormat.SHORT_ENUM: return struct.unpack("<H", value)[0]    # 2 bytes, little endian, unsigned short/int16
            case XcomFormat.FLOAT: return struct.unpack("<f", value)[0]         # 4 bytes, little endian, float
            case XcomFormat.INT32: return struct.unpack("<i", value)[0]         # 4 bytes, little endian, signed long/int32
            case XcomFormat.LONG_ENUM: return struct.unpack("<I", value)[0]     # 4 bytes, little endian, unsigned long/int32
            case XcomFormat.GUID: return XcomData._bytes_to_guid(value)         # 16 bytes, little endian
            case XcomFormat.STRING: return value.decode('iso-8859-15')          # n bytes, ISO_8859-15 string of 8 bit characters
            case _: 
                msg = "Unknown data format '{format}"
                raise TypeError(msg)

    @staticmethod
    def pack(value, format) -> bytes:
        match format:
            case XcomFormat.BOOL: return struct.pack("<?", int(value))         # 1 byte, little endian, bool
            case XcomFormat.ERROR: return struct.pack("<H", int(value))        # 2 bytes, little endian, unsigned short/int16
            case XcomFormat.SHORT_ENUM: return struct.pack("<H", int(value))   # 2 bytes, little endian, unsigned short/int16
            case XcomFormat.FLOAT: return struct.pack("<f", float(value))      # 4 bytes, little endian, float
            case XcomFormat.INT32: return struct.pack("<i", int(value))        # 4 bytes, little endian, signed long/int32
            case XcomFormat.LONG_ENUM: return struct.pack("<I", int(value))    # 4 bytes, little endian, unsigned long/int32
            case XcomFormat.GUID: return XcomData._guid_to_bytes(value)        # 16 bytes, little endian
            case XcomFormat.STRING: return value.encode('iso-8859-15')         # n bytes, ISO_8859-15 string of 8 bit characters
            case _: 
                msg = "Unknown data format '{format}"
                raise TypeError(msg)

    @staticmethod
    def cast(value: float, format):
        match format:
            case XcomFormat.BOOL: return bool(value)
            case XcomFormat.ERROR: return int(value)
            case XcomFormat.FORMAT: return int(value)
            case XcomFormat.SHORT_ENUM: return int(value)
            case XcomFormat.FLOAT: return value
            case XcomFormat.INT32: return int(value)
            case XcomFormat.LONG_ENUM: return int(value)
            case XcomFormat.STRING: return value.decode('iso-8859-15') 
            case _: 
                msg = f"Unknown data format '{format}"
                raise TypeError(msg)

    @staticmethod      
    def _bytes_to_guid(value: bytes) -> str:
        guid_obj = uuid.UUID(int=int.from_bytes(value, byteorder='little'))
        return str(guid_obj)
    
    @staticmethod      
    def _guid_to_bytes(value: str) -> bytes:
        guid_obj = uuid.UUID(hex=value)
        guid_int = guid_obj.int
        return guid_int.to_bytes(16, byteorder='little')


class XcomDataMultiInfoReqItem():
    user_info_ref: int
    aggregation_type: XcomAggregationType

    def __init__(self, user_info_ref: int, aggregation_type: Any):

        self.user_info_ref = user_info_ref
        self.aggregation_type = aggregation_type 

    def __str__(self) -> str:
        return f"Item(user_info_ref={self.user_info_ref}, aggregation_type={self.aggregation_type})"


class XcomDataMultiInfoReq:
    items: Iterable[XcomDataMultiInfoReqItem]

    def __init__(self, items: Iterable[XcomDataMultiInfoReqItem]):
        
        # Sanity check
        if len(items) < 1:
            raise XcomParamException("No values items passed")
        if len(items) > MULTI_INFO_REQ_MAX:
            raise XcomParamException(f"Too values items passed, maximum is {MULTI_INFO_REQ_MAX} in one request")

        self.items = items

    @staticmethod
    def unpack(buf: bytes) -> 'XcomDataMultiInfoReq':
        f = BytesIO(buf)
        f_len = f.getbuffer().nbytes
        items = list()

        while f_len >= 3:
            user_info_ref = read_uint16(f)
            aggr = read_uint8(f)
            f_len -= 3

            items.append(XcomDataMultiInfoReqItem(
                user_info_ref,
                XcomAggregationType(aggr),
            ))

        return XcomDataMultiInfoReq(items)

    def pack(self) -> bytes:
        f = BytesIO()
        for item in self.items:
            write_uint16(f, item.user_info_ref)
            write_uint8(f, item.aggregation_type)
        return f.getvalue()

    def __len__(self) -> int:
        return 3 * len(self.items)

    def __str__(self) -> str:
        return f"(len={len(self.items)})"


class XcomDataMultiInfoRspItem():
    user_info_ref: int
    aggregation_type: XcomAggregationType
    data: float

    def __init__(self, user_info_ref: int, aggregation_type: XcomAggregationType, data: float):
        self.user_info_ref = user_info_ref
        self.aggregation_type = aggregation_type
        self.data = data

    def __str__(self) -> str:
        return f"Item(user_info_ref={self.user_info_ref}, aggregation_type={self.aggregation_type}, value={self.value})"


class XcomDataMultiInfoRsp:
    flags: int
    datetime: int
    items: list[XcomDataMultiInfoRspItem]

    def __init__(self, flags, datetime, items):
        self.flags = flags
        self.datetime = datetime
        self.items = items

    @staticmethod
    def unpack(buf: bytes) -> 'XcomDataMultiInfoRsp':
        f = BytesIO(buf)
        f_len = f.getbuffer().nbytes

        flags = read_uint32(f)
        datetime= read_uint32(f)
        items = list()
        f_len -= 8

        while f_len >= 7:
            user_info_ref = read_uint16(f)
            aggr = read_uint8(f)
            data = read_bytes(f, 4)
            f_len -= 7

            items.append(XcomDataMultiInfoRspItem(
                user_info_ref,
                XcomAggregationType(aggr),
                XcomData.unpack(data, XcomFormat.FLOAT)
            ))

        return XcomDataMultiInfoRsp(flags, datetime, items)

    def pack(self) -> bytes:
        f = BytesIO()
        write_uint32(f, self.flags)
        write_uint32(f, self.datetime)
        for item in self.items:
            write_uint16(f, item.user_info_ref)
            write_uint8(f, item.aggregation_type)
            write_bytes(f, XcomData.pack(item.data, XcomFormat.FLOAT))

        return f.getvalue()
    
    def __len__(self) -> int:
        return 2*4 + len(self.items)*(2+1+4)

    def __str__(self) -> str:
        return f"(flags={self.flags}, datetime={self.datetime}, len={len(self.items)})"


class XcomDataMessageRsp:
    message_total: int      # 4 bytes
    message_number: int     # 2 bytes
    source_address: int     # 4 bytes
    timestamp: int          # 4 bytes
    value: int              # 4 bytes

    def __init__(self, message_total, message_number, source_address, timestamp, value):
        self.message_total = message_total
        self.message_number = message_number
        self.source_address = source_address
        self.timestamp = int(timestamp)
        self.value = int(value)

    @staticmethod
    def unpack(buf: bytes) -> 'XcomDataMessageRsp':
        f = BytesIO(buf)
        
        msg_total = read_uint32(f)
        msg_number= read_uint16(f)
        src = read_uint32(f)
        timestamp = read_uint32(f)
        value = read_uint32(f)

        return XcomDataMessageRsp(msg_total, msg_number, src, timestamp, value)

    def pack(self) -> bytes:
        f = BytesIO()
        write_uint32(f, self.message_total)
        write_uint16(f, self.message_number)
        write_uint32(f, self.source_address)
        write_uint32(f, self.timestamp)
        write_uint32(f, self.value)

        return f.getvalue()


##

class AsyncReader(asyncio.StreamReader):
    def __init__(self, buf: bytes):
        super().__init__()
        self.feed_data(buf)

class SyncReader(io.BytesIO):
    def __init__(self, buf: bytes):
        super().__init__(buf)


def read_float(f: BufferedReader) -> float:
    return struct.unpack('<f', f.read(4))

def write_float(f: BufferedReader, value: float) -> int:
    return f.write(struct.pack("<f", float(value)))


def read_sint32(f: BufferedReader) -> int:
    return int.from_bytes(f.read(4), byteorder="little", signed=True)

def write_sint32(f: BufferedWriter, value: int) -> int:
    return f.write(value.to_bytes(4, byteorder="little", signed=True))


def read_uint32(f: BufferedReader) -> int:
    return int.from_bytes(f.read(4), byteorder="little", signed=False)

def write_uint32(f: BufferedWriter, value: int) -> int:
    return f.write(value.to_bytes(4, byteorder="little", signed=False))

def read_uint16(f: BufferedReader) -> int:
    return int.from_bytes(f.read(2), byteorder="little", signed=False)

def write_uint16(f: BufferedWriter, value: int) -> int:
    return f.write(value.to_bytes(2, byteorder="little", signed=False))


def read_uint8(f: BufferedReader) -> int:
    return int.from_bytes(f.read(1), byteorder="little", signed=False)

def write_uint8(f: BufferedWriter, value: int) -> int:
    return f.write(value.to_bytes(1, byteorder="little", signed=False))


def read_bytes(f: BufferedReader, length: int) -> int:
    return f.read(length)

def write_bytes(f: BufferedWriter, value: bytes) -> int:
    return f.write(value)
