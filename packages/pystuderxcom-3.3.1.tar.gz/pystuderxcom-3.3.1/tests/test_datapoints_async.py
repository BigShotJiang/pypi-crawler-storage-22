import pytest
import pytest_asyncio

from pystuderxcom import (
    XcomDataset, 
    XcomVoltage, 
    XcomFormat, 
    XcomCategory, 
    XcomDatapointUnknownException,
    AsyncXcomFactory,
    XcomFactory,
)


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "voltageAC, voltageDC, exp_len",
    [
        (XcomVoltage.AC120, XcomVoltage.DC12, 1451),
        (XcomVoltage.AC120, XcomVoltage.DC24, 1451),
        (XcomVoltage.AC120, XcomVoltage.DC48, 1451),
        (XcomVoltage.AC240, XcomVoltage.DC12, 1451),
        (XcomVoltage.AC240, XcomVoltage.DC24, 1451),
        (XcomVoltage.AC240, XcomVoltage.DC48, 1451),
    ]
)
async def test_create(voltageAC, voltageDC, exp_len):
    dataset = await AsyncXcomFactory.create_dataset(voltageAC, voltageDC)    

    assert len(dataset._datapoints) == exp_len


@pytest.mark.asyncio
async def test_nr():
    dataset = await AsyncXcomFactory.create_dataset(XcomVoltage.AC240, XcomVoltage.DC48)

    param = dataset.get_by_nr(1107)
    assert param.family_id == "xt"
    assert param.nr == 1107
    assert param.format == XcomFormat.FLOAT
    assert param.category == XcomCategory.PARAMETER

    param = dataset.get_by_nr(1552)
    assert param.family_id == "xt"
    assert param.nr == 1552
    assert param.format == XcomFormat.LONG_ENUM
    assert param.category == XcomCategory.PARAMETER
    assert param.options != None
    assert type(param.options) is dict
    assert len(param.options) == 3

    param = dataset.get_by_nr(3000)
    assert param.family_id == "xt"
    assert param.nr == 3000
    assert param.format == XcomFormat.FLOAT
    assert param.category == XcomCategory.INFO

    param = dataset.get_by_nr(3000, "xt")
    assert param.family_id == "xt"
    assert param.nr == 3000
    assert param.format == XcomFormat.FLOAT
    assert param.category == XcomCategory.INFO

    param = dataset.get_by_nr(5012, "rcc")
    assert param.family_id == "rcc"
    assert param.nr == 5012
    assert param.format == XcomFormat.LONG_ENUM
    assert param.category == XcomCategory.PARAMETER
    assert param.options != None
    assert type(param.options) is dict

    with pytest.raises(XcomDatapointUnknownException):
        param = dataset.get_by_nr(9999)

    with pytest.raises(XcomDatapointUnknownException):
        param = dataset.get_by_nr(3000, "bsp")


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "voltageAC, voltageDC, nr, exp_unit, exp_def, exp_min, exp_max",
    [
        (XcomVoltage.AC120, XcomVoltage.DC48, 1286, "Vac", 120, 55, 140),
        (XcomVoltage.AC240, XcomVoltage.DC48, 1286, "Vac", 230, 110, 280),

        (XcomVoltage.AC120, XcomVoltage.DC12, 1108, "Vdc", 11.6, 9.0, 18.0),
        (XcomVoltage.AC120, XcomVoltage.DC24, 1108, "Vdc", 23.1, 18.0, 36.0),
        (XcomVoltage.AC120, XcomVoltage.DC48, 1108, "Vdc", 46.3, 36.0, 72.0),
        (XcomVoltage.AC240, XcomVoltage.DC12, 1108, "Vdc", 11.6, 9.0, 18.0),
        (XcomVoltage.AC240, XcomVoltage.DC24, 1108, "Vdc", 23.1, 18.0, 36.0),
        (XcomVoltage.AC240, XcomVoltage.DC48, 1108, "Vdc", 46.3, 36.0, 72.0),
    ]
)
async def test_voltage(voltageAC, voltageDC, nr, exp_unit, exp_def, exp_min, exp_max):
    dataset = await AsyncXcomFactory.create_dataset(voltageAC, voltageDC)    
    
    param = dataset.get_by_nr(nr)
    assert param.unit == exp_unit
    assert param.default == exp_def
    assert param.min == exp_min
    assert param.max == exp_max


@pytest.mark.asyncio
async def test_enum():
    dataset = await AsyncXcomFactory.create_dataset(XcomVoltage.AC240, XcomVoltage.DC48)

    param = dataset.get_by_nr(1552)
    assert param.options != None
    assert type(param.options) is dict
    assert len(param.options) == 3

    assert param.enum_value(1) == "Slow"
    assert param.enum_value("1") == "Slow"
    assert param.enum_value(0) == "0"
    assert param.enum_value("0") == "0"

    assert param.enum_key("Slow") == 1
    assert param.enum_key("Unknown") == None
    assert param.enum_key(1) == None
    assert param.enum_key("1") == None


@pytest.mark.asyncio
async def test_menu():
    dataset = await AsyncXcomFactory.create_dataset(XcomVoltage.AC240, XcomVoltage.DC48)
    
    root_items = dataset.get_menu_items(0)
    assert len(root_items) == 12

    for item in root_items:
        sub_items = dataset.get_menu_items(item.nr)
        assert len(sub_items) > 0

