"""Build script for pySurprise C++ extension from repository root."""

from pybind11.setup_helpers import Pybind11Extension, build_ext
from setuptools import setup

VERSION = "1.0.1"

ext_modules = [
    Pybind11Extension(
        "pysurprise._core",
        sources=[
            "pysurprise/csrc/bindings.cpp",
            "pysurprise/csrc/surprise.cpp",
        ],
        include_dirs=["pysurprise/csrc"],
        cxx_std=11,
        define_macros=[("VERSION_INFO", f'"{VERSION}"')],
    ),
]

setup(
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext},
)
