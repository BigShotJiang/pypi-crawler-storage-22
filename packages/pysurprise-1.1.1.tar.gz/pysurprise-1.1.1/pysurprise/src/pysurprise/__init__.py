"""
pySurprise - Python bindings for the Surprise network community metric.

Surprise is a metric for evaluating the quality of community structure
in complex networks. It is based on a cumulative hypergeometric distribution
that quantifies how surprising a given partition is.

References
----------
    Aldecoa R, Marín I (2011)
    Deciphering network community structure by Surprise
    PLoS ONE 6(9): e24195

    Aldecoa R, Marín I (2013)
    Surprise maximization reveals the community structure of complex networks
    Scientific Reports 3, 1060
"""

from pysurprise._core import (
    compute_surprise,
    log_hyper_probability,
    surprise_from_partition,
    surprise_from_partition_dict,
)
from pysurprise._api import surprise
from pysurprise import algorithms

__version__ = "1.1.1"

__all__ = [
    "surprise",
    "compute_surprise",
    "log_hyper_probability",
    "surprise_from_partition",
    "surprise_from_partition_dict",
    "algorithms",
    "__version__",
]
