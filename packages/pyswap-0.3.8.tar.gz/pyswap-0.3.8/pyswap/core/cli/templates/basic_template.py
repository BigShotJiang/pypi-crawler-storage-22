import pyswap as psp

metadata = psp.components.Metadata(
    author="{author}",
    institution="{institution}",
    email="{email}",
    project="{project}",
    swap_ver="{swap_version}",
    comment="{comment}",
)
