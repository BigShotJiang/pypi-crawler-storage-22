"""Integration tests for pytest-agents."""
