"""pytest-agents - Pytest plugin framework with AI agent capabilities."""

__version__ = "1.0.15"

from pytest_agents.plugin import PytestAgentsPlugin

__all__ = ["PytestAgentsPlugin", "__version__"]
