"""Dependency injection container for pytest-agents."""
