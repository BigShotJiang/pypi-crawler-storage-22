"""Infrastructure implementations for dependency injection."""
