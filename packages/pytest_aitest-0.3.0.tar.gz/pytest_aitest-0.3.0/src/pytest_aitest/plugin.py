"""pytest plugin for aitest."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

import pytest

from pytest_aitest.reporting import (
    TestReport,
    build_suite_report,
    generate_html,
    generate_json,
    generate_md,
)

if TYPE_CHECKING:
    from _pytest.config import Config
    from _pytest.config.argparsing import Parser
    from _pytest.nodes import Item
    from _pytest.reports import TestReport as PytestTestReport
    from _pytest.terminal import TerminalReporter

    from pytest_aitest.core.agent import Agent
    from pytest_aitest.core.result import AgentResult
    from pytest_aitest.reporting import SuiteReport
    from pytest_aitest.reporting.insights import InsightsResult


# Key for storing test reports in config
COLLECTOR_KEY = pytest.StashKey[list[TestReport]]()
# Key for storing session messages for @pytest.mark.session
SESSION_MESSAGES_KEY = pytest.StashKey[dict[str, list[dict[str, Any]]]]()
# Export for use in fixtures
__all__ = ["COLLECTOR_KEY", "SESSION_MESSAGES_KEY"]


class _RecordingLLMAssert:
    """Wrapper that records LLM assertions for report rendering."""

    def __init__(self, inner: Any, store: list[dict[str, Any]]) -> None:
        self._inner = inner
        self._store = store

    def __call__(self, content: str, criterion: str) -> Any:
        result = self._inner(content, criterion)
        self._store.append(
            {
                "type": "llm",
                "passed": bool(result),
                "message": result.criterion,
                "details": result.reasoning,
            }
        )
        return result

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


@pytest.hookimpl(hookwrapper=True)
def pytest_pyfunc_call(pyfuncitem: Item) -> Any:
    """Wrap llm_assert fixture values before test function execution."""
    funcargs = getattr(pyfuncitem, "funcargs", {})
    llm_assert = funcargs.get("llm_assert")
    if llm_assert is not None and not isinstance(llm_assert, _RecordingLLMAssert):
        store = getattr(pyfuncitem, "_aitest_assertions", None)
        if store is None:
            store = []
            pyfuncitem._aitest_assertions = store  # type: ignore[attr-defined]

        pyfuncitem.funcargs["llm_assert"] = _RecordingLLMAssert(llm_assert, store)  # type: ignore[index]

    yield


def _get_timestamped_path(
    base_name: str, test_name: str | None = None, default_dir: Path | None = None
) -> Path:
    """Generate timestamped filename for unique report names.

    Args:
        base_name: Base filename with extension (e.g., 'results.json', 'report.html')
        test_name: Name of the test/suite to include in filename
        default_dir: Directory to store the file (default: 'aitest-reports')

    Returns:
        Path with format: {dir}/{prefix}_{test_name}_{ISO8601-timestamp}.{ext}
    """
    if default_dir is None:
        default_dir = Path("aitest-reports")

    # Use ISO8601 timestamp: YYYY-MM-DDTHH-MM-SS (seconds precision, : replaced with -)
    timestamp = datetime.now().isoformat(timespec="seconds").replace(":", "-")

    # Sanitize test name (remove paths, lowercase, replace spaces/special chars)
    if test_name:
        # Remove file extensions and paths
        safe_name = (
            test_name.split("/")[-1].split(".")[0].lower().replace(" ", "-").replace("_", "-")
        )
    else:
        safe_name = None

    # Split filename and extension
    if "." in base_name:
        name_part, ext = base_name.rsplit(".", 1)
        if safe_name:
            filename = f"{name_part}_{safe_name}_{timestamp}.{ext}"
        else:
            filename = f"{name_part}_{timestamp}.{ext}"
    else:
        if safe_name:
            filename = f"{base_name}_{safe_name}_{timestamp}"
        else:
            filename = f"{base_name}_{timestamp}"

    return default_dir / filename


def pytest_addoption(parser: Parser) -> None:
    """Add pytest CLI options for aitest.

    Note: LLM authentication is handled via standard environment variables:
    - Azure: AZURE_API_BASE + `az login` (Entra ID)
    - OpenAI: OPENAI_API_KEY
    - Anthropic: ANTHROPIC_API_KEY
    - etc.

    See https://ai.pydantic.dev/ for supported providers.
    """
    group = parser.getgroup("aitest", "AI agent testing")

    # Model selection for AI summary (use the most capable model you can afford)
    group.addoption(
        "--aitest-summary-model",
        default=None,
        help=(
            "Model for AI analysis. Required when generating reports. "
            "Use the most capable model you can afford (e.g., gpt-5.1-chat, claude-opus-4)."
        ),
    )

    # Custom analysis prompt file
    group.addoption(
        "--aitest-analysis-prompt",
        metavar="PATH",
        default=None,
        help=(
            "Path to a custom analysis prompt file for AI insights. "
            "Overrides the built-in prompt and any plugin-provided prompt."
        ),
    )

    # Report options
    group.addoption(
        "--aitest-html",
        metavar="PATH",
        default=None,
        help="Generate HTML report to given path (e.g., report.html)",
    )
    group.addoption(
        "--aitest-json",
        metavar="PATH",
        default=None,
        help="Generate JSON report to given path (e.g., results.json)",
    )
    group.addoption(
        "--aitest-md",
        metavar="PATH",
        default=None,
        help="Generate Markdown report to given path (e.g., report.md)",
    )
    group.addoption(
        "--aitest-min-pass-rate",
        metavar="N",
        type=int,
        default=None,
        help=(
            "Minimum pass rate threshold (0-100). If the overall pass rate falls below "
            "this percentage, the test session exits with failure. "
            "Example: --aitest-min-pass-rate=80"
        ),
    )

    # LLM judge model for llm_assert fixture
    group.addoption(
        "--llm-model",
        default="openai/gpt-5-mini",
        help=(
            "Model for llm_assert semantic assertions. "
            "Defaults to --aitest-summary-model if set, otherwise openai/gpt-5-mini."
        ),
    )


def pytest_configure(config: Config) -> None:
    """Configure the aitest plugin."""
    # Register custom hookspecs so downstream plugins can extend behavior
    from pytest_aitest.hooks import AitestHookSpec

    config.pluginmanager.add_hookspecs(AitestHookSpec)

    # Register markers
    config.addinivalue_line(
        "markers",
        "aitest: Mark test as an AI agent test (optional, enables filtering with -m aitest)",
    )
    config.addinivalue_line(
        "markers",
        "aitest_skip_report: Exclude this test from AI test reports",
    )
    config.addinivalue_line(
        "markers",
        "session(name): Mark tests as part of a named session for multi-turn conversations. "
        "Tests with the same session name share conversation history automatically.",
    )

    # Always initialize report collection - JSON is always generated
    config.stash[COLLECTOR_KEY] = []
    # Initialize session message storage
    config.stash[SESSION_MESSAGES_KEY] = {}


def pytest_collection_modifyitems(
    session: pytest.Session,
    config: Config,
    items: list[pytest.Item],
) -> None:
    """Auto-mark tests that use aitest fixtures."""
    for item in items:
        # Check if test uses any aitest fixtures
        fixturenames = getattr(item, "fixturenames", [])
        aitest_fixtures = {"aitest_run"}
        if (aitest_fixtures & set(fixturenames)) and not any(
            m.name == "aitest" for m in item.iter_markers()
        ):
            item.add_marker(pytest.mark.aitest)


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item: Item, call: Any) -> Any:
    """Capture test results for reporting."""
    outcome = yield
    report: PytestTestReport = outcome.get_result()

    # Only process call phase (not setup/teardown)
    if report.when != "call":
        return

    # Check if reporting is enabled
    tests = item.config.stash.get(COLLECTOR_KEY, None)
    if tests is None:
        return

    # Skip if marked to exclude from report
    if any(m.name == "aitest_skip_report" for m in item.iter_markers()):
        return

    # Get agent result if available
    agent_result = getattr(item, "_aitest_result", None)

    # Only collect tests that actually used aitest (have an agent result)
    # This prevents unit tests from triggering AI analysis for reports
    if agent_result is None:
        return

    # Get agent identity directly from the Agent object stashed by the fixture
    agent = getattr(item, "_aitest_agent", None)

    # Get test function docstring if available
    docstring = None
    func = getattr(item, "function", None)
    if func is not None and func.__doc__:
        docstring = func.__doc__

    # Get test class docstring if available
    class_docstring = None
    parent = getattr(item, "parent", None)
    if parent is not None:
        parent_obj = getattr(parent, "obj", None)
        if parent_obj is not None and hasattr(parent_obj, "__doc__") and parent_obj.__doc__:
            # Only use class docstrings (not module docstrings)
            import inspect

            if inspect.isclass(parent_obj):
                class_docstring = parent_obj.__doc__

    # Extract assertions recorded by the llm_assert fixture
    assertions = getattr(item, "_aitest_assertions", [])

    # Capture error message — just the assertion/exception, never raw tracebacks.
    # Tracebacks contain file paths, line numbers, and nodeids that pollute
    # AI analysis and user-facing reports.
    error_msg = None
    if report.failed:
        error_text = str(report.longrepr)
        error_lines = error_text.split("\n")

        # Extract lines starting with "E " — pytest's assertion/exception lines
        e_lines = [line.strip()[2:] for line in error_lines if line.strip().startswith("E ")]

        if e_lines:
            error_msg = "\n".join(e_lines)
        else:
            # No E-lines: grab the last non-empty line (typically "ExceptionType: message")
            for line in reversed(error_lines):
                stripped = line.strip()
                if stripped:
                    error_msg = stripped
                    break

    # Build agent identity from the Agent object
    agent_id = agent.id if agent else ""
    if agent:
        raw = agent.provider.model
        model = raw.split("/")[-1] if "/" in raw else raw
    else:
        model = ""
    agent_name = agent.name if agent else ""
    system_prompt_name = agent.system_prompt_name if agent else None
    skill_name = agent.skill.name if agent and agent.skill else None

    # Create test report with typed identity fields
    test_report = TestReport(
        name=item.nodeid,
        outcome=report.outcome,
        duration_ms=report.duration * 1000,
        agent_result=agent_result,
        error=error_msg,
        assertions=assertions,
        docstring=docstring,
        class_docstring=class_docstring,
        agent_id=agent_id,
        agent_name=agent_name,
        model=model,
        system_prompt_name=system_prompt_name,
        skill_name=skill_name,
    )

    tests.append(test_report)

    # Enrich JUnit XML with agent metadata (user_properties → <property> elements)
    _add_junit_properties(report, agent_result, agent)


def _add_junit_properties(
    report: PytestTestReport,
    agent_result: AgentResult,
    agent: Agent | None = None,
) -> None:
    """Add agent metadata to pytest report for JUnit XML output.

    Properties are added to report.user_properties which pytest writes
    as <property> elements in JUnit XML output.

    Example output:
        <testcase name="test_balance">
          <properties>
            <property name="aitest.agent.name" value="banking-agent"/>
            <property name="aitest.model" value="gpt-5-mini"/>
            <property name="aitest.skill" value="financial-advisor"/>
            <property name="aitest.tools.called" value="get_balance,transfer"/>
          </properties>
        </testcase>
    """
    if not hasattr(report, "user_properties"):
        return

    props = []

    # Agent identity (from Agent object)
    if agent:
        model = agent.provider.model
        display_model = model.split("/")[-1] if "/" in model else model
        props.append(("aitest.agent.name", agent.name))
        props.append(("aitest.model", display_model))
        if agent.system_prompt_name:
            props.append(("aitest.prompt", agent.system_prompt_name))

    # Skill
    if agent_result.skill_info:
        props.append(("aitest.skill", agent_result.skill_info.name))

    # MCP servers (from agent config)
    if agent and agent.mcp_servers:
        server_names = []
        for server in agent.mcp_servers:
            # Use server.name if available, otherwise derive from command
            name = getattr(server, "name", None)
            if not name and hasattr(server, "command") and server.command:
                name = server.command[-1].split("/")[-1].split(".")[0]
            if name:
                server_names.append(name)
        if server_names:
            props.append(("aitest.servers", ",".join(server_names)))

    # Allowed tools filter (from agent config)
    if agent and agent.allowed_tools:
        props.append(("aitest.allowed_tools", ",".join(sorted(agent.allowed_tools))))

    # Token usage
    if agent_result.token_usage:
        prompt = agent_result.token_usage.get("prompt", 0)
        completion = agent_result.token_usage.get("completion", 0)
        if prompt:
            props.append(("aitest.tokens.input", str(prompt)))
        if completion:
            props.append(("aitest.tokens.output", str(completion)))
        total = prompt + completion
        if total:
            props.append(("aitest.tokens.total", str(total)))

    # Cost
    if agent_result.cost_usd > 0:
        props.append(("aitest.cost_usd", f"{agent_result.cost_usd:.6f}"))

    # Turns
    if agent_result.turns:
        props.append(("aitest.turns", str(len(agent_result.turns))))

    # Tools called (unique, comma-separated)
    tools_called = set()
    for turn in agent_result.turns:
        for tc in turn.tool_calls:
            tools_called.add(tc.name)
    if tools_called:
        props.append(("aitest.tools.called", ",".join(sorted(tools_called))))

    # Success/failure
    props.append(("aitest.success", str(agent_result.success).lower()))

    # Add all properties to report
    report.user_properties.extend(props)


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    """Generate reports and enforce minimum pass rate at end of test session."""
    config = session.config
    tests = config.stash.get(COLLECTOR_KEY, None)

    if tests is None or not tests:
        return

    html_path = config.getoption("--aitest-html")
    json_path = config.getoption("--aitest-json")
    md_path = config.getoption("--aitest-md")
    min_pass_rate: int | None = config.getoption("--aitest-min-pass-rate")

    # Extract suite docstring from first test's parent class/module
    suite_docstring = None
    if session.items:
        first_item = session.items[0]
        # Try to get docstring from test class first
        if hasattr(first_item, "parent") and first_item.parent:
            parent = first_item.parent
            # Check if parent is a class
            parent_obj = getattr(parent, "obj", None)
            if parent_obj and hasattr(parent_obj, "__doc__"):
                suite_docstring = parent_obj.__doc__
                if suite_docstring:
                    # Get first line only
                    suite_docstring = suite_docstring.strip().split("\n")[0].strip()

    # Build suite report first (to get the test name for default filenames)
    default_dir = Path("aitest-reports")
    suite_report = build_suite_report(
        tests,
        name=session.name or "pytest-aitest",
        suite_docstring=suite_docstring,
    )

    # Generate default paths with test name included
    default_json_path = _get_timestamped_path(
        "results.json", test_name=suite_report.name, default_dir=default_dir
    )
    default_html_path = _get_timestamped_path(
        "report.html", test_name=suite_report.name, default_dir=default_dir
    )

    # Generate AI insights if HTML/MD report requested OR summary model specified
    summary_model = config.getoption("--aitest-summary-model")
    insights = None
    if html_path or md_path or summary_model:
        insights = _generate_structured_insights(
            config, suite_report, required=bool(html_path or md_path)
        )

    # Always generate JSON report (to default or custom path)
    json_output_path = Path(json_path) if json_path else default_json_path
    json_output_path.parent.mkdir(parents=True, exist_ok=True)
    generate_json(suite_report, json_output_path, insights=insights)
    _log_report_path(config, "JSON", json_output_path)

    # Generate HTML report (use default timestamped name if not specified)
    html_output_path = Path(html_path) if html_path else default_html_path
    html_output_path.parent.mkdir(parents=True, exist_ok=True)

    # Generate AI insights if HTML requested (even if using default path)
    if insights is None:
        insights = _generate_structured_insights(config, suite_report, required=True)

    assert insights is not None  # guaranteed by required=True above
    generate_html(suite_report, html_output_path, insights=insights, min_pass_rate=min_pass_rate)
    _log_report_path(config, "HTML", html_output_path)

    # Generate Markdown report if requested
    if md_path:
        md_output_path = Path(md_path)
        md_output_path.parent.mkdir(parents=True, exist_ok=True)

        if insights is None:
            insights = _generate_structured_insights(config, suite_report, required=True)

        # required=True guarantees insights is not None (raises on failure)
        assert insights is not None  # noqa: S101
        generate_md(suite_report, md_output_path, insights=insights, min_pass_rate=min_pass_rate)
        _log_report_path(config, "Markdown", md_output_path)

    # Enforce minimum pass rate threshold
    if min_pass_rate is not None:
        actual_rate = suite_report.pass_rate
        terminalreporter: TerminalReporter | None = config.pluginmanager.get_plugin(
            "terminalreporter"
        )
        if actual_rate < min_pass_rate:
            if terminalreporter:
                terminalreporter.write_line(
                    f"\naitest: FAILED - pass rate {actual_rate:.1f}% "
                    f"is below minimum threshold {min_pass_rate}% "
                    f"({suite_report.passed}/{suite_report.total} passed)",
                    red=True,
                    bold=True,
                )
            session.exitstatus = pytest.ExitCode.TESTS_FAILED
        elif terminalreporter:
            terminalreporter.write_line(
                f"\naitest: pass rate {actual_rate:.1f}% meets minimum threshold {min_pass_rate}%",
            )


def _log_report_path(config: Config, format_name: str, path: Path) -> None:
    """Log report path to terminal."""
    terminalreporter: TerminalReporter | None = config.pluginmanager.get_plugin("terminalreporter")
    if terminalreporter:
        terminalreporter.write_line(f"aitest {format_name} report: {path}")


def _resolve_analysis_prompt(config: Config) -> str | None:
    """Resolve the analysis prompt from CLI option, plugin hook, or default.

    Priority: CLI option > plugin hook > None (let insights.py use built-in).
    """
    # 1. CLI option takes highest precedence
    prompt_path = config.getoption("--aitest-analysis-prompt", default=None)
    if prompt_path:
        path = Path(prompt_path)
        if not path.exists():
            raise pytest.UsageError(f"Analysis prompt file not found: {path}")
        return path.read_text(encoding="utf-8")

    # 2. Plugin hook (firstresult=True — first non-None wins)
    result = config.pluginmanager.hook.pytest_aitest_analysis_prompt(config=config)
    if result:
        return result

    # 3. Fall back to built-in default (None signals insights.py to use its default)
    return None


def _generate_structured_insights(
    config: Config, report: SuiteReport, *, required: bool = False
) -> InsightsResult | None:
    """Generate structured AI insights from test results.

    Args:
        config: pytest config
        report: Suite report with test results
        required: If True, raise error when model not configured (for report generation)

    Returns:
        InsightsResult or None if generation fails/skipped.

    Raises:
        pytest.UsageError: If required=True and model not configured.
    """
    import asyncio

    try:
        from pytest_aitest.reporting.insights import generate_insights

        # Require dedicated summary model - no fallback
        model = config.getoption("--aitest-summary-model")
        if not model:
            if required:
                raise pytest.UsageError(
                    "AI analysis is required for report generation.\n"
                    "Please specify --aitest-summary-model with a capable model.\n"
                    "Example: --aitest-summary-model=azure/gpt-4.1\n"
                    "         --aitest-summary-model=openai/gpt-4o"
                )
            return None

        # Collect tool info and skill info from test results
        tool_info: list[Any] = []
        skill_info: list[Any] = []
        prompts: dict[str, str] = {}

        for test in report.tests:
            if test.agent_result:
                # Collect tools (deduplicate by name)
                seen_tools = {t.name for t in tool_info}
                for t in getattr(test.agent_result, "available_tools", []) or []:
                    if t.name not in seen_tools:
                        tool_info.append(t)
                        seen_tools.add(t.name)

                # Collect skills (deduplicate by name)
                skill = getattr(test.agent_result, "skill_info", None)
                if skill and skill.name not in {s.name for s in skill_info}:
                    skill_info.append(skill)

                # Collect effective system prompts as prompt variants
                effective_prompt = getattr(test.agent_result, "effective_system_prompt", "")
                if effective_prompt:
                    prompt_label = test.system_prompt_name or "default"
                    if prompt_label not in prompts:
                        prompts[prompt_label] = effective_prompt

        # Generate insights using async function
        analysis_prompt = _resolve_analysis_prompt(config)

        async def _run() -> InsightsResult:
            return await generate_insights(
                suite_report=report,
                tool_info=tool_info,
                skill_info=skill_info,
                prompts=prompts,
                model=model,
                min_pass_rate=config.getoption("--aitest-min-pass-rate"),
                analysis_prompt=analysis_prompt,
            )

        # Use asyncio.run() instead of deprecated get_event_loop().run_until_complete()
        result = asyncio.run(_run())

        # Log generation stats
        terminalreporter: TerminalReporter | None = config.pluginmanager.get_plugin(
            "terminalreporter"
        )
        if terminalreporter:
            tokens_str = f"{result.tokens_used:,}" if result.tokens_used else "N/A"
            cost_str = f"${result.cost_usd:.4f}" if result.cost_usd else "N/A"
            cached_str = " (cached)" if result.cached else ""
            terminalreporter.write_line(
                f"\nAI Insights generated{cached_str}: {tokens_str} tokens, {cost_str}"
            )

        return result

    except pytest.UsageError:
        # Re-raise configuration errors
        raise
    except Exception as e:
        if required:
            raise pytest.UsageError(
                f"AI analysis failed (required for report generation): {e}\n"
                "Check your model configuration and credentials."
            ) from e
        terminalreporter: TerminalReporter | None = config.pluginmanager.get_plugin(
            "terminalreporter"
        )
        if terminalreporter:
            terminalreporter.write_line(f"Warning: AI insights generation failed: {e}")
        return None


# Register fixtures from fixtures module
pytest_plugins = ["pytest_aitest.fixtures"]
