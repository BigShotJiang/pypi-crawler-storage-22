"""pytest-bdd-md-report: Markdown test report formatter for pytest-bdd."""

__version__ = "1.0.0"
