"""pytest-describe-beautifully: Beautiful terminal and HTML output for pytest-describe."""

__version__ = "0.1.0"
