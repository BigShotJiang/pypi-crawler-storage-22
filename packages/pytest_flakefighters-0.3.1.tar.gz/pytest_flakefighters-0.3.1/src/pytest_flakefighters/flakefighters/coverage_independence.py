"""
This module implements the CoverageIndependence FlakeFighter.
"""

import pandas as pd
from scipy.cluster.hierarchy import fcluster, linkage
from scipy.spatial.distance import pdist

from pytest_flakefighters.database_management import (
    FlakefighterResult,
    Run,
    TestExecution,
)
from pytest_flakefighters.flakefighters.abstract_flakefighter import FlakeFighter


class CoverageIndependence(FlakeFighter):
    """
    Classify tests as flaky if they fail independently of passing test cases that exercise overlapping code.

    :ivar run_live: Run detection "live" after each test. Otherwise run as a postprocessing step after the test suite.
                    This is always False as live classification is not supported.
    :ivar threshold: The minimum distance to consider as "similar", expressed as a proportion 0 <= threshold < 1 where 0
        represents no difference and 1 represents complete difference.
    :ivar metric: The distance metric to use. For a full list of valid values,see the `SciPy documentation for spatial
        distances <https://docs.scipy.org/doc/scipy/reference/spatial.distance.html>`_.
    :ivar linkage_method: From `scipy.cluster.hierarchy.linkage`: ['single', 'complete', 'average', 'weighted',
        'centroid', 'median', 'ward']
    """

    def __init__(self, threshold: float = 0, metric: str = "jaccard", linkage_method="single"):
        super().__init__(False)
        self.threshold = threshold
        self.metric = metric
        self.linkage_method = linkage_method

    @classmethod
    def from_config(cls, config: dict):
        """
        Factory method to create a new instance from a pytest configuration.
        """
        return CoverageIndependence(
            threshold=config.get("threshold", 0),
            metric=config.get("metric", "jaccard"),
            linkage_method=config.get("linkage_method", "single"),
        )

    def params(self):
        """
        Convert the key parameters into a dictionary so that the object can be replicated.
        :return A dictionary of the parameters used to create the object.
        """
        return {"threshold": self.threshold, "metric": self.metric, "linkage_method": self.linkage_method}

    def flaky_test_live(self, execution: TestExecution):
        """
        NOT SUPPORTED.
        Detect whether a given test execution is flaky and append the result to its `flakefighter_results` attribute.
        :param execution: The test execution to classify.
        """
        raise NotImplementedError("Coverage independence cannot be measured live")

    def flaky_tests_post(self, run: Run):
        """
        Go through each test in the test suite and append the result to its `flakefighter_results` attribute.
        :param run: Run object representing the pytest run, with tests accessible through run.tests.
        """
        coverage = []
        # Enumerating tests and executions since they won't have IDs if they are not yet in the database
        for test in run.tests:
            for execution in test.executions:
                coverage.append(
                    {"test": test, "execution": execution}
                    | {f"{file}:{line}": True for file in execution.coverage for line in execution.coverage[file]}
                )

        # Can't compute the pairwise distance of a single execution
        if len(coverage) < 2:
            return

        coverage = pd.DataFrame(coverage)
        coverage[coverage.columns.drop(["test", "execution"])] = (
            coverage[coverage.columns.drop(["test", "execution"])].astype(pd.BooleanDtype()).fillna(False).astype(bool)
        )
        # Calculate the distance between each pair of test executions
        raw_coverage = coverage.drop(["test", "execution"], axis=1).to_numpy()
        distances = pdist(raw_coverage, metric=self.metric)
        # Assign each test execution to a cluster
        coverage["cluster"] = fcluster(
            linkage(distances, method=self.linkage_method), t=self.threshold, criterion="distance"
        )

        for _, group in coverage.groupby("cluster"):
            for test in group["test"]:
                result = FlakefighterResult(
                    name=self.__class__.__name__,
                    flaky=len(set(map(lambda x: x.outcome, group["execution"]))) > 1,
                )
                if result not in test.flakefighter_results:
                    test.flakefighter_results.append(result)
