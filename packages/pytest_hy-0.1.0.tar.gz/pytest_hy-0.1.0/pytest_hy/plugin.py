import hy  # noqa: F401
import pytest


def pytest_collect_file(file_path, parent):
    if file_path.suffix == ".hy":
        return pytest.Module.from_parent(parent, path=file_path)
