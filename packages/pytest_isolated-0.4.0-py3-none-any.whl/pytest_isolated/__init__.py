"""pytest-isolated: Run pytest tests in isolated subprocesses."""

__version__ = "0.4.0"
