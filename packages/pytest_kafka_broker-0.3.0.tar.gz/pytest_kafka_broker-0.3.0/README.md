# pytest-kafka-broker

A Pytest plugin to run a single-broker Kafka cluster.
