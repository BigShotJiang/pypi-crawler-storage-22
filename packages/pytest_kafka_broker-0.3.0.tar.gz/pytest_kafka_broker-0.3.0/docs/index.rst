pytest-kafka-broker documentation
=================================

This is a pytest plugin to run a temporary, local, single-broker Kafka cluster.

*******
Example
*******

.. literalinclude:: ../tests/test_kafka.py

*********
Reference
*********

.. automodapi:: pytest_kafka_broker
