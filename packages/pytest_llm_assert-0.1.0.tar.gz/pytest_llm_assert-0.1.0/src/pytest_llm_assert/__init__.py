"""pytest-llm-assert: Simple LLM-powered assertions for any pytest test."""

from pytest_llm_assert.core import LLMAssert

__all__ = ["LLMAssert"]
__version__ = "0.1.0"
