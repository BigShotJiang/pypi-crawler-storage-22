# Pytest Podman Plugin

A Pytest plugin for managing Podman containers during tests, similar to `pytest-docker` but tailored for Podman. It simplifies integration testing by automatically starting and stopping services defined in a `podman-compose.yml` file.

## Features

- **Automatic Lifecycle Management**: Starts services (`podman compose up`) before tests and stops them (`podman compose down`) afterwards.
- **Service Discovery**: Helper methods to find the host port mapped to a container port.
- **Readiness Waiting**: Built-in mechanism to wait for services to become responsive.
- **Scoped Fixtures**: Configurable scope (default: `session`) to share containers across tests or restart them per test.

## Installation

You can install the plugin via pip:

```bash
pip install podman_pytest
```

## Usage

### 1. Create a `podman-compose.yml`

Create a `podman-compose.yml` file in your `tests/` directory (or configure the path).

```yaml
version: '3'
services:
  httpbin:
    image: kennethreitz/httpbin
    ports:
      - "80"
```