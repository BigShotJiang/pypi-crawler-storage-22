import pytest

from .plugin import (
    podman_cleanup,
    podman_compose_command,
    podman_compose_file,
    podman_compose_project_name,
    podman_ip,
    podman_services,
    podman_setup,
    Services,
)

__all__ = [
    "podman_compose_command",
    "podman_compose_file",
    "podman_compose_project_name",
    "podman_ip",
    "podman_setup",
    "podman_cleanup",
    "podman_services",
    "Services",
]


def pytest_addoption(parser: pytest.Parser) -> None:
    group = parser.getgroup("podman")
    group.addoption(
        "--container-scope",
        type=str,
        action="store",
        default="session",
        help="The pytest fixture scope for reusing containers between tests."
        " For available scopes and descriptions, "
        "   see https://docs.pytest.org/en/6.2.x/fixture.html#fixture-scopes",
    )
