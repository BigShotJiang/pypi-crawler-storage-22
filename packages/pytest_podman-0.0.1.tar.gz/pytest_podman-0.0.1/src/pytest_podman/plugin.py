import contextlib
import os
from pathlib import Path
import re
import subprocess
import time
import timeit
from typing import Any, Dict, Iterable, Iterator, List, Optional, Tuple, Union

import attr
import pytest
from _pytest.config import Config
from _pytest.fixtures import FixtureRequest


@pytest.fixture
def container_scope_fixture(request: FixtureRequest) -> Any:
    return request.config.getoption("--container-scope")


def containers_scope(fixture_name: str, config: Config) -> Any:
    return config.getoption("--container-scope", "session")


def execute(
    command: str, success_codes: Iterable[int] = (0,), ignore_stderr: bool = False
) -> Union[bytes, Any]:
    """Run a shell command."""
    try:
        stderr_pipe = subprocess.DEVNULL if ignore_stderr else subprocess.STDOUT
        output = subprocess.check_output(command, stderr=stderr_pipe, shell=True)
        status = 0
    except subprocess.CalledProcessError as error:
        output = error.output or b""
        status = error.returncode
        command = error.cmd

    if status not in success_codes:
        raise Exception(
            'Command {} returned {}: """{}""".'.format(
                command, status, output.decode("utf-8")
            )
        )
    return output


def get_podman_ip() -> Union[str, Any]:
    # When talking to the podman daemon via a UNIX socket, route all TCP
    # traffic to podman containers via the TCP loopback interface.
    podman_host = os.environ.get("podman_HOST", "").strip()
    if not podman_host or podman_host.startswith("unix://"):
        return "127.0.0.1"

    # Return just plain address without prefix and port
    return re.sub(r"^[^:]+://(.+):\d+$", r"\1", podman_host)


@pytest.fixture(scope=containers_scope)
def podman_ip() -> Union[str, Any]:
    """Determine the IP address for TCP connections to podman containers."""

    return get_podman_ip()


@attr.s(frozen=True)
class Services:
    _podman_compose: Any = attr.ib()
    _services: Dict[Any, Dict[Any, Any]] = attr.ib(
        init=False, default=attr.Factory(dict)
    )

    def port_for(self, service: str, container_port: int) -> int:
        """Return the "host" port for `service` and `container_port`.

        E.g. If the service is defined like this:

            version: '2'
            services:
              httpbin:
                build: .
                ports:
                  - "8000:80"

        this method will return 8000 for container_port=80.
        """

        # Lookup in the cache.
        cache: Optional[int] = self._services.get(service, {}).get(container_port, None)
        if cache is not None:
            return cache

        output = self._podman_compose.execute("port %s %d" % (service, container_port))
        endpoint = output.strip().decode("utf-8")
        if not endpoint:
            raise ValueError(
                'Could not detect port for "%s:%d".' % (service, container_port)
            )

        # This handles messy output that might contain warnings or other text
        if len(endpoint.split("\n")) > 1:
            endpoint = endpoint.split("\n")[-1]

        # Usually, the IP address here is 0.0.0.0, so we don't use it.
        match = int(endpoint.split(":", 1)[-1])

        # Store it in cache in case we request it multiple times.
        self._services.setdefault(service, {})[container_port] = match

        return match

    def wait_until_responsive(
        self,
        check: Any,
        timeout: float,
        pause: float,
        clock: Any = timeit.default_timer,
    ) -> None:
        """Wait until a service is responsive."""

        ref = clock()
        now = ref
        while (now - ref) < timeout:
            if check():
                return
            time.sleep(pause)
            now = clock()

        raise Exception("Timeout reached while waiting on service!")


def str_to_list(
    arg: Union[str, Path, List[Any], Tuple[Any]],
) -> Union[List[Any], Tuple[Any]]:
    if isinstance(arg, (list, tuple)):
        return arg
    return [arg]


@attr.s(frozen=True)
class podmanComposeExecutor:
    _compose_command: str = attr.ib()
    _compose_files: Any = attr.ib(converter=str_to_list)
    _compose_project_name: str = attr.ib()

    def execute(self, subcommand: str, **kwargs: Any) -> Union[bytes, Any]:
        command = self._compose_command
        for compose_file in self._compose_files:
            command += ' -f "{}"'.format(compose_file)
        command += ' --project-name "{}" {}'.format(
            self._compose_project_name, subcommand
        )
        return execute(command, **kwargs)


@pytest.fixture(scope=containers_scope)
def podman_compose_command() -> str:
    return "podman compose"


@pytest.fixture(scope=containers_scope)
def podman_compose_file(pytestconfig: Any) -> Union[List[str], str]:
    """Get an absolute path to the  `podman-compose.yml` file. Override this
    fixture in your tests if you need a custom location."""

    return os.path.join(str(pytestconfig.rootdir), "tests", "podman-compose.yml")


@pytest.fixture(scope=containers_scope)
def podman_compose_project_name() -> str:
    """Generate a project name using the current process PID. Override this
    fixture in your tests if you need a particular project name."""

    return "pytest{}".format(os.getpid())


def get_cleanup_command() -> Union[List[str], str]:
    return ["down -v"]


@pytest.fixture(scope=containers_scope)
def podman_cleanup() -> Union[List[str], str]:
    """Get the podman_compose command to be executed for test clean-up actions.
    Override this fixture in your tests if you need to change clean-up actions.
    Returning anything that would evaluate to False will skip this command."""

    return get_cleanup_command()


def get_setup_command() -> Union[List[str], str]:
    return ["up --build -d"]


@pytest.fixture(scope=containers_scope)
def podman_setup() -> Union[List[str], str]:
    """Get the podman_compose command to be executed for test setup actions.
    Override this fixture in your tests if you need to change setup actions.
    Returning anything that would evaluate to False will skip this command."""

    return get_setup_command()


@contextlib.contextmanager
def get_podman_services(
    podman_compose_command: str,
    podman_compose_file: Union[List[str], str],
    podman_compose_project_name: str,
    podman_setup: Union[List[str], str],
    podman_cleanup: Union[List[str], str],
) -> Iterator[Services]:
    podman_compose = podmanComposeExecutor(
        podman_compose_command, podman_compose_file, podman_compose_project_name
    )
    print('step 1: setup podman services...')

    # setup containers.
    if podman_setup:
        print('step 2: executing podman setup commands...')
        # Maintain backwards compatibility with the string format.
        if isinstance(podman_setup, str):
            print('step 3: podman setup is string, converting to list...')
            podman_setup = [podman_setup]
        for command in podman_setup:
            print('step 4: executing command:', command)
            podman_compose.execute(command)

    try:
        # Let test(s) run.
        yield Services(podman_compose)
    finally:
        # Clean up.
        if podman_cleanup:
            # Maintain backwards compatibility with the string format.
            if isinstance(podman_cleanup, str):
                podman_cleanup = [podman_cleanup]
            for command in podman_cleanup:
                podman_compose.execute(command)


@pytest.fixture(scope=containers_scope)
def podman_services(
    podman_compose_command: str,
    podman_compose_file: Union[List[str], str],
    podman_compose_project_name: str,
    podman_setup: str,
    podman_cleanup: str,
) -> Iterator[Services]:
    """Start all services from a podman compose file (`podman-compose up`).
    After test are finished, shutdown all services (`podman-compose down`)."""

    with get_podman_services(
        podman_compose_command,
        podman_compose_file,
        podman_compose_project_name,
        podman_setup,
        podman_cleanup,
    ) as podman_service:
        yield podman_service
