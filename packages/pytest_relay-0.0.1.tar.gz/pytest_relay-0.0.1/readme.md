
# `pytest` streaming plugin

Relays `pytest` state and result information via its `Observer` interface.
