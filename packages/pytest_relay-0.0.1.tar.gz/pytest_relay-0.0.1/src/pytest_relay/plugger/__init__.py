"""
Package handling test update reports.
"""

from .plugin import RelayPlugin

__all__ = [
    "RelayPlugin",
]
