# from pythagoras._320_logging_code_portals import LoggingCodePortal
# from pythagoras import _PortalTester
# from parameterizable import smoketest_parameterizable_class
#
#
# def test_basic_portal_get_params(tmpdir):
#     with _PortalTester(LoggingCodePortal, root_dict = tmpdir) :
#         smoketest_parameterizable_class(LoggingCodePortal)
#
