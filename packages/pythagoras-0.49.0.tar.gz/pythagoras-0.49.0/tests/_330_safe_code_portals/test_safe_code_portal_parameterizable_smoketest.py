# from pythagoras._330_safe_code_portals import SafeCodePortal
# from pythagoras import _PortalTester
# from parameterizable import smoketest_parameterizable_class
#
#
# def test_basic_portal_get_params(tmpdir):
#     with _PortalTester(SafeCodePortal, root_dict = tmpdir) :
#         smoketest_parameterizable_class(SafeCodePortal)
#
