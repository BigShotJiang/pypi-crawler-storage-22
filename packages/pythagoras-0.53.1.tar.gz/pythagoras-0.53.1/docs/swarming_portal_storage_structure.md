# Swarming Portal Tree Storage Structure

This document describes the hierarchical storage architecture used by `SwarmingPortal` in Pythagoras.

## Storage Tree Overview

```
_root_dict (PersiDict / FileDirDict)
│
├─── value_store/ ─────────────────────────────────── WriteOnceDict [append_only=True, pkl]
│    │                                                 Content-addressed value storage
│    │
│    └─── {shard}/ ────────────────────────────────── 3-char hash prefix (e.g., "abc")
│         │
│         └─── {subshard}/ ────────────────────────── 3-char hash prefix (e.g., "def")
│              │
│              └─── {descriptor}/ ─────────────────── Type/shape info (e.g., "dict_len_5")
│                   │
│                   └─── {hash_tail}.pkl ──────────── Pickled value file
│                                                      Key: ValueAddr(shard, subshard, descriptor, hash_tail)
│
├─── portal_cfg/ ──────────────────────────────────── PersiDict [append_only=False, pkl]
│    │                                                 Portal-wide configuration settings
│    │
│    └─── {setting_name}.pkl ──────────────────────── Individual setting values
│
├─── node_cfg/ ────────────────────────────────────── PersiDict
│    │                                                 Per-node configuration namespace
│    │
│    └─── {node_hash[:8]}/ ────────────────────────── Node-specific subdirectory
│         │                                            (8-char hash of machine identity)
│         │
│         ├─── {setting_name}.pkl ─────────────────── Local node settings
│         │
│         └─── all_workers/ ───────────────────────── PersiDict [SwarmingPortal-specific]
│              │                                       Worker process tracking
│              │
│              └─── ({pid}, {start_time})/ ────────── Compound key: (process_id, timestamp)
│                   │
│                   └─── DescendantProcessInfo.pkl ── Worker metadata:
│                                                       - process_id: int
│                                                       - process_start_time: int
│                                                       - ancestor_process_id: int
│                                                       - ancestor_process_start_time: int
│                                                       - process_type: str
│
├─── crash_history/ ───────────────────────────────── PersiDict [append_only=True, json]
│    │                                                 Application-level exception log
│    │
│    └─── {YYYY-MM-DD}/ ───────────────────────────── Date-partitioned subdirectory
│         │
│         └─── {exception_id}.json ────────────────── Exception payload with environment context
│
├─── event_history/ ───────────────────────────────── PersiDict [append_only=True, json]
│    │                                                 Application-level event log
│    │
│    └─── {YYYY-MM-DD}/ ───────────────────────────── Date-partitioned subdirectory
│         │
│         └─── {event_id}.json ────────────────────── Event payload with environment context
│
├─── run_history/ ─────────────────────────────────── OverlappingMultiDict
│    │                                                 Multi-format execution history
│    │
│    ├─── .json/ ──────────────────────────────────── [append_only=True] Execution metadata
│    │    │
│    │    └─── {call_signature_addr}/ ─────────────── Per-function-call namespace
│    │         │
│    │         ├─── attempts/
│    │         │    └─── run_{session_id}_attempt.json    Execution environment snapshot
│    │         │
│    │         ├─── crashes/
│    │         │    └─── run_{session_id}_crash_{n}.json  Exception details
│    │         │
│    │         └─── events/
│    │              └─── run_{session_id}_event_{n}.json  Custom event payloads
│    │
│    ├─── .py/ ────────────────────────────────────── [append_only=False] Source code
│    │    │
│    │    └─── {call_signature_addr}/
│    │         └─── source.py ─────────────────────── Function source code
│    │
│    ├─── .txt/ ───────────────────────────────────── [append_only=True] Captured output
│    │    │
│    │    └─── {call_signature_addr}/
│    │         └─── outputs/
│    │              └─── run_{session_id}_output.txt   stdout/stderr/logging
│    │
│    └─── .pkl/ ───────────────────────────────────── [append_only=True] Results
│         │
│         └─── {call_signature_addr}/
│              └─── results/
│                   └─── run_{session_id}_result.pkl   ValueAddr of return value
│
├─── execution_results/ ───────────────────────────── WriteOnceDict [append_only=True, pkl]
│    │                                                 Pure function result cache
│    │
│    └─── {shard}/
│         └─── {subshard}/
│              └─── {fn_name}_result_addr/
│                   └─── {hash_tail}.pkl
│                        │
│                        └─── ValueAddr ───────────── Points to result in value_store
│
└─── execution_requests/ ──────────────────────────── PersiDict [append_only=False, pkl]
     │                                                 Mutable execution queue
     │
     └─── {shard}/
          └─── {subshard}/
               └─── {fn_name}_result_addr/
                    └─── {hash_tail}.pkl
                         │
                         └─── True ────────────────── Pending request marker
```

---

## Portal Class Hierarchy

Each level adds storage components:

```
BasicPortal
│   └── _root_dict: PersiDict
│
└── DataPortal
    │   └── _global_value_store: WriteOnceDict ──────────── value_store/
    │
    └── TunablePortal
        │   ├── _global_portal_settings: PersiDict ──────── portal_cfg/
        │   ├── _local_node_settings: PersiDict ─────────── node_cfg/{node_hash}/
        │   └── _local_node_value_store: PersiDict ──────── (alias to _local_node_settings)
        │
        └── OrdinaryCodePortal
            │
            └── LoggingCodePortal
                │   ├── _crash_history: PersiDict ───────── crash_history/
                │   ├── _event_history: PersiDict ───────── event_history/
                │   └── _run_history: OverlappingMultiDict  run_history/
                │
                └── SafeCodePortal
                    │
                    └── AutonomousCodePortal
                        │
                        └── ProtectedCodePortal
                            │
                            └── PureCodePortal
                                │   ├── _execution_results: WriteOnceDict ─ execution_results/
                                │   └── _execution_requests: PersiDict ──── execution_requests/
                                │
                                └── SwarmingPortal
                                        └── _all_workers: PersiDict ────── node_cfg/{hash}/all_workers/
```

---

## Address Structures

### HashAddr (Base Class)

Content-addressed storage identifier:

```
hash_signature (SHA-256, base32-encoded)
┌─────────┬─────────┬──────────────────────────────────────┐
│ shard   │subshard │ hash_tail                            │
│ (3 chr) │ (3 chr) │ (remaining characters)               │
└─────────┴─────────┴──────────────────────────────────────┘

+ descriptor: human-readable type/shape info (e.g., "dict_len_5", "ndarray_shape_10_20")

Storage path: {shard}/{subshard}/{descriptor}/{hash_tail}.pkl
```

### ValueAddr

Used for content-addressed storage of arbitrary Python objects.

| Property | Description |
|----------|-------------|
| Location | `value_store/{shard}/{subshard}/{descriptor}/{hash_tail}.pkl` |
| Example | `ValueAddr({"name": "test"})` → `value_store/abc/def/dict_len_1/ghijklmnop.pkl` |

### PureFnExecutionResultAddr

Used for addressing pure function execution results.

| Property | Description |
|----------|-------------|
| Descriptor | `{fn_name}_result_addr` |
| In execution_results | `execution_results/{shard}/{subshard}/{fn_name}_result_addr/{hash_tail}.pkl` containing `ValueAddr` pointing to actual result |
| In execution_requests | `execution_requests/{shard}/{subshard}/{fn_name}_result_addr/{hash_tail}.pkl` containing `True` (pending marker) |

### LoggingFnCallSignature

Composition of `fn_addr` (ValueAddr) + `kwargs_addr` (ValueAddr).

Structure under `run_history`:
```
{call_signature.addr}/
    ├── attempts/run_{session_id}_attempt.json
    ├── results/run_{session_id}_result.pkl
    ├── outputs/run_{session_id}_output.txt
    ├── crashes/run_{session_id}_crash_{n}.json
    ├── events/run_{session_id}_event_{n}.json
    └── source.py
```

---

## Swarming Portal Data Flow

```
                              ┌───────────────────────┐
                              │      User Code        │
                              │                       │
                              │  pure_fn.swarm(**kw)  │
                              └───────────┬───────────┘
                                          │
                                          ▼
                        ┌─────────────────────────────────────┐
                        │      PureFnExecutionResultAddr      │
                        │    (hash of function + arguments)   │
                        └─────────────────┬───────────────────┘
                                          │
                   ┌──────────────────────┴──────────────────────┐
                   │                                             │
                   ▼                                             ▼
┌─────────────────────────────────┐         ┌─────────────────────────────────┐
│      execution_requests/        │         │      execution_results/         │
│ ┌─────────────────────────────┐ │         │ ┌─────────────────────────────┐ │
│ │ {addr}: True                │ │         │ │ {addr}: ValueAddr(result)   │ │
│ │ (pending request)           │ │         │ │ (cached result)             │ │
│ └─────────────────────────────┘ │         │ └─────────────────────────────┘ │
└────────────────┬────────────────┘         └─────────────────────────────────┘
                 │
                 │ random_key()
                 ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                       Background Worker Pool                            │
│ ┌─────────────────────────────────────────────────────────────────────┐ │
│ │ _launch_many_background_workers (maintains worker count)            │ │
│ │                                                                     │ │
│ │  ┌─────────────┐   ┌─────────────┐   ┌─────────────┐                │ │
│ │  │  Worker 1   │   │  Worker 2   │   │  Worker N   │  ...           │ │
│ │  │ _background │   │ _background │   │ _background │                │ │
│ │  │   _worker   │   │   _worker   │   │   _worker   │                │ │
│ │  └──────┬──────┘   └──────┬──────┘   └──────┬──────┘                │ │
│ │         │                 │                 │                       │ │
│ │         ▼                 ▼                 ▼                       │ │
│ │  ┌────────────────────────────────────────────────────────────────┐ │ │
│ │  │ _process_random_execution_request                              │ │ │
│ │  │   1. Pick random request from execution_requests               │ │ │
│ │  │   2. Validate dependencies (can_be_executed)                   │ │ │
│ │  │   3. Execute pure function                                     │ │ │
│ │  │   4. Store result in execution_results                         │ │ │
│ │  │   5. Remove from execution_requests                            │ │ │
│ │  └────────────────────────────────────────────────────────────────┘ │ │
│ └─────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────┘
                 │
                 │ register_descendant_process
                 ▼
┌─────────────────────────────────┐
│         all_workers/            │
│ ┌─────────────────────────────┐ │
│ │ (pid, start_time):          │ │
│ │   DescendantProcessInfo     │ │
│ │     - process_id            │ │
│ │     - process_start_time    │ │
│ │     - ancestor_process_id   │ │
│ │     - process_type          │ │
│ └─────────────────────────────┘ │
└─────────────────────────────────┘
```

---

## Storage Configuration Summary

| Storage Component | Mode | Format | Purpose |
|-------------------|------|--------|---------|
| `value_store/` | append_only | pkl | Immutable content-addressed values |
| `portal_cfg/` | mutable | pkl | Portal-wide settings |
| `node_cfg/{hash}/` | mutable | pkl | Per-node settings |
| `node_cfg/{hash}/all_workers/` | mutable | pkl | Worker process tracking |
| `crash_history/` | append_only | json | Exception logs |
| `event_history/` | append_only | json | Application events |
| `run_history/.json/` | append_only | json | Execution metadata |
| `run_history/.py/` | mutable | py | Function source code |
| `run_history/.txt/` | append_only | txt | Captured stdout/stderr |
| `run_history/.pkl/` | append_only | pkl | Execution results |
| `execution_results/` | append_only | pkl | Pure function result cache |
| `execution_requests/` | mutable | pkl | Pending execution queue |

---

## Process Hierarchy

SwarmingPortal spawns background workers with ancestor tracking for cleanup:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Ancestor Process (User's Python script)                                    │
│  PID: 1234, start_time: 1706000000                                          │
│                                                                             │
│  with SwarmingPortal() as portal:                                           │
│      my_fn.swarm(x=1)                                                       │
│            │                                                                │
│            │ spawns                                                         │
│            ▼                                                                │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  _launch_many_background_workers                                       │ │
│  │  PID: 1235                                                             │ │
│  │  ancestor: (1234, 1706000000)                                          │ │
│  │           │                                                            │ │
│  │           │ spawns & maintains pool                                    │ │
│  │           ▼                                                            │ │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                  │ │
│  │  │  Worker 1    │  │  Worker 2    │  │  Worker 3    │                  │ │
│  │  │  PID: 1236   │  │  PID: 1237   │  │  PID: 1238   │                  │ │
│  │  │  ancestor:   │  │  ancestor:   │  │  ancestor:   │                  │ │
│  │  │  (1234,      │  │  (1234,      │  │  (1234,      │                  │ │
│  │  │   170600000) │  │   170600000) │  │   170600000) │                  │ │
│  │  └──────────────┘  └──────────────┘  └──────────────┘                  │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘

Lifecycle:
  • Workers periodically check: ancestor_runtime_is_live()
  • When ancestor (1234) dies → all workers detect this and exit gracefully
  • PID + start_time tuple prevents false positives from OS PID reuse
```

---

## Concrete Example with Real Paths

Example: `@pure_fn def my_add(a, b): return a + b` called with `my_add(a=1, b=2)` → returns `3`

```
STEP 1: Store the actual result (3) in value_store
─────────────────────────────────────────────────────────────────────────────

value_store/
└── k7x/                              ← shard (first 3 chars of result's hash)
    └── m2p/                          ← subshard (chars 4-6)
        └── int/                      ← descriptor (type of value)
            └── q9r4t5w8y1z2.pkl      ← hash_tail (remaining chars)
                │
                └── 3                 ← THE ACTUAL RESULT


STEP 2: Store pointer in execution_results (links call → result location)
─────────────────────────────────────────────────────────────────────────────

execution_results/
└── abc/                              ← shard (first 3 chars of call's hash)
    └── def/                          ← subshard (chars 4-6)
        └── my_add_result_addr/       ← descriptor (function name + suffix)
            └── gh1j2k3l4m5n.pkl      ← hash_tail
                │
                └── ValueAddr(        ← POINTER to value_store
                      shard="k7x",
                      subshard="m2p",
                      descriptor="int",
                      hash_tail="q9r4t5w8y1z2"
                    )


STEP 3: execution_requests (deleted after completion)
─────────────────────────────────────────────────────────────────────────────

execution_requests/
└── abc/
    └── def/
        └── my_add_result_addr/
            └── gh1j2k3l4m5n.pkl      ← DELETED after worker completes
                │
                └── True              ← Was: pending marker


RETRIEVAL PATH:
─────────────────────────────────────────────────────────────────────────────

my_add.get(a=1, b=2)
       │
       ▼
  compute PureFnExecutionResultAddr
  (abc, def, my_add_result_addr, gh1j2k3l4m5n)
       │
       ▼
  lookup in execution_results/abc/def/my_add_result_addr/gh1j2k3l4m5n.pkl
       │
       ▼
  get ValueAddr(k7x, m2p, int, q9r4t5w8y1z2)
       │
       ▼
  lookup in value_store/k7x/m2p/int/q9r4t5w8y1z2.pkl
       │
       ▼
  return 3
```

---

## Key Design Patterns

### 1. Content-Addressed Storage
- `ValueAddr` uses SHA-256 hash split into shard/subshard/hash_tail
- Enables filesystem optimization (distributes load across directories)
- Supports S3-compatible cloud storage patterns

### 2. Hierarchical Nesting
- `get_subdict(key)` creates logical sub-dictionaries
- Physical storage organized by directory/prefix structure
- Enables per-date, per-node, per-function partitioning

### 3. Append-Only vs. Mutable
- **Append-only** stores for results/history (immutable, safe for distribution)
- **Mutable** stores for requests/settings (tracked for execution dispatch)

### 4. Multi-Format Support
- `OverlappingMultiDict` allows simultaneous view of data in multiple formats
- Enables logging metadata (JSON), code (Python), outputs (text), results (pickle)
