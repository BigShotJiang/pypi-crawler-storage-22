"""Initialise pythinfer package."""
