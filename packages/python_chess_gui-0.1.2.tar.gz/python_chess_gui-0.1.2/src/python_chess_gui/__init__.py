"""Python Chess GUI - A chess application with pygame interface."""

__version__ = "0.1.0"
