"""python-date-calc: A date calculation library written in Python."""

from importlib.metadata import version

__version__ = version("python-date-calc")
