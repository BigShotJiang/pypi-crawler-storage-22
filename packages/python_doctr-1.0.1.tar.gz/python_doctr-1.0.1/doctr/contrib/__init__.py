from .artefacts import ArtefactDetector
