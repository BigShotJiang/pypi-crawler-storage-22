# About<a id="about"></a>

This is a version of the Eigen python library [python-eigen-ingenuity](https://pypi.org/project/python-eigen-ingenuity/) without the cli tool for building assetmodels. The model builder is still available in the code, but the always-active cli functionality is removed.

Th reason for this is that on some user computers that are locked down for security reasons, the library will fail to install with the cli present.

For the full documentation on how to use the library please refer to the ReadMe of the [Main Project](https://pypi.org/project/python-eigen-ingenuity/)

