"""HistorianMulti module tests"""
