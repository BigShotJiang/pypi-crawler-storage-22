"""python-excel-csv: A Python library for Excel and CSV file operations."""

from importlib.metadata import version

__version__ = version("python-excel-csv")
