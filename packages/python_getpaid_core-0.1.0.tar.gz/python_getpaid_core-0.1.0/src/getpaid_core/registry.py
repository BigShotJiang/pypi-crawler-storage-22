"""Plugin registry for payment backends.

Primary discovery via entry_points. Manual registration for
testing and dynamic scenarios.
"""

from importlib.metadata import entry_points

from getpaid_core.processor import BaseProcessor


ENTRY_POINT_GROUP = "getpaid.backends"


class PluginRegistry:
    """Discovers and stores payment backend processors."""

    def __init__(self) -> None:
        self._backends: dict[str, type[BaseProcessor]] = {}
        self._discovered = False

    def discover(self) -> None:
        """Load all backends registered via entry_points."""
        eps = entry_points(group=ENTRY_POINT_GROUP)
        for ep in eps:
            processor_class = ep.load()
            if isinstance(processor_class, type) and issubclass(
                processor_class, BaseProcessor
            ):
                self._backends[processor_class.slug] = processor_class
        self._discovered = True

    def register(self, processor_class: type[BaseProcessor]) -> None:
        """Manual registration for testing or dynamic use."""
        self._backends[processor_class.slug] = processor_class

    def unregister(self, slug: str) -> None:
        """Remove a backend by slug."""
        self._backends.pop(slug, None)

    def get_for_currency(self, currency: str) -> list[type[BaseProcessor]]:
        """Return all backends supporting the given currency."""
        self._ensure_discovered()
        return [
            b
            for b in self._backends.values()
            if currency in b.accepted_currencies
        ]

    def get_choices(self, currency: str) -> list[tuple[str, str]]:
        """Return (slug, display_name) pairs for a currency."""
        return [
            (b.slug, b.display_name) for b in self.get_for_currency(currency)
        ]

    def get_by_slug(self, slug: str) -> type[BaseProcessor]:
        """Return a backend class by slug. Raises KeyError."""
        self._ensure_discovered()
        return self._backends[slug]

    def get_all_currencies(self) -> set[str]:
        """Return all currencies supported by all backends."""
        self._ensure_discovered()
        currencies: set[str] = set()
        for b in self._backends.values():
            currencies.update(b.accepted_currencies)
        return currencies

    def _ensure_discovered(self) -> None:
        if not self._discovered:
            self.discover()


registry = PluginRegistry()
