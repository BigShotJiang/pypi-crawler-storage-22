# http-helper

#### 介绍


#### 软件架构
软件架构说明


#### 安装教程

- 1. 构建包
  - python -m build
  - 会生成文件
    - dist/python-http-helper-0.1.0.tar.gz
    - dist/python-http-helper-0.1.0-py3-none-any.whl
- 2. 发布
  -  twine upload dist/* 或者 twine upload -r public dist/* 或者 twine upload --repository pypi dist/* --skip-existing --verbose --cert false  忽略证书
    
#### 使用说明

1.  xxxx
2.  xxxx
3.  xxxx

#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request