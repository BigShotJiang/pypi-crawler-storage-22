# This file was auto generated; Do not modify, if you value your sanity!
import ctypes
import enum

from ics.structures.ethernet_settings2 import *


class flags(ctypes.Structure):
    _pack_ = 2
    _fields_ = [
        ('enableLatencyTest', ctypes.c_uint16, 1),
        ('reserved', ctypes.c_uint16, 15),
    ]



class srad_gemini_settings(ctypes.Structure):
    _pack_ = 2
    _fields_ = [
        ('perf_en', ctypes.c_uint16),
        ('ethernet1', ETHERNET_SETTINGS2),
        ('ethernet2', ETHERNET_SETTINGS2),
        ('autoEthernet1', ETHERNET_SETTINGS2),
        ('autoEthernet2', ETHERNET_SETTINGS2),
        ('network_enabled_on_boot', ctypes.c_uint16),
        ('network_enables', ctypes.c_uint16),
        ('network_enables_2', ctypes.c_uint16),
        ('network_enables_3', ctypes.c_uint16),
        ('network_enables_4', ctypes.c_uint16),
        ('network_enables_5', ctypes.c_uint64),
        ('flags', flags),
    ]


_SRADGeminiSettings = srad_gemini_settings
SRADGeminiSettings = srad_gemini_settings

