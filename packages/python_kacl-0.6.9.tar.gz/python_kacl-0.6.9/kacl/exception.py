class KACLException(Exception):
    pass
