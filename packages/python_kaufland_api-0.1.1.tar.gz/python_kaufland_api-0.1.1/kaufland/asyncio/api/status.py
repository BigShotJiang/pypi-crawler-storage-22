from kaufland.asyncio import Client
from kaufland.base import ApiResponse, kaufland_endpoint


class Status(Client):
    """Status Kaufland API Client."""

    @kaufland_endpoint("/status/ping", method="GET")
    async def ping(self, **kwargs) -> ApiResponse:
        """
        Ping the Marketplace Seller API by Kaufland

        A simple method you can call that will return a constant value as long as everything is good.
        """
        return await self._request(
            kwargs.pop("path"), params=kwargs, add_storefront=False
        )
