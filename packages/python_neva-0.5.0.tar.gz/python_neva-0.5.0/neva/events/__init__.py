"""Defines the events system."""
