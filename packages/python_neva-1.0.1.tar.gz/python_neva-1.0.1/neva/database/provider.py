"""Database service provider."""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Self, override

from tortoise import Tortoise

from neva import Err, Ok, Result
from neva.arch import ServiceProvider
from neva.config.repository import ConfigRepository
from neva.database.connection import TransactionContext
from neva.database.manager import DatabaseManager
from neva.obs import LogManager


class DatabaseServiceProvider(ServiceProvider):
    """Database service provider."""

    @override
    def register(self) -> Result[Self, str]:
        self.app.bind(TransactionContext)
        self.app.bind(DatabaseManager)
        return Ok(self)

    @asynccontextmanager
    async def lifespan(self) -> AsyncIterator[None]:
        """Initialize and cleanup database connections."""
        match self.app.make(ConfigRepository).unwrap().get("database"):
            case Ok(config):
                await Tortoise.init(config=config, _create_db=True)
                yield
                await Tortoise.close_connections()
            case Err(err):
                logger = self.app.make(LogManager).unwrap()
                logger.error(f"Failed to load database configuration: {err}")
                yield
