"""Connection manager."""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import final

from tortoise.transactions import in_transaction

from neva import Nothing, Option, Some, from_optional
from neva.database.transaction import Transaction, TransactionState
from neva.obs import LogManager


@dataclass
class TransactionRegistry:
    """A registry of ongoing transactions."""

    by_connection: dict[str, Transaction] = field(default_factory=dict)
    stack: list[Transaction] = field(default_factory=list)

    def extend(self, transaction: Transaction) -> "TransactionRegistry":
        """Adds a new transaction to the registry.

        Returns:
            A new registry with the new transaction added.
        """
        return TransactionRegistry(
            by_connection={**self.by_connection, transaction.conn_name: transaction},
            stack=[*self.stack, transaction],
        )


_tx_registry: ContextVar[TransactionRegistry | None] = ContextVar(
    "_tx_registry",
    default=None,
)


class TransactionContext:
    """Transaction context."""

    def __init__(self) -> None:
        if _tx_registry.get() is None:
            _ = _tx_registry.set(TransactionRegistry())

    def current(self, connection: str | None = None) -> Option[Transaction]:
        """Get the current transaction.

        Returns:
            The current transaction, if any.
        """
        registry = _tx_registry.get()
        if registry is None:
            return Nothing()

        if connection is not None:
            tx = registry.by_connection.get(connection)
            return from_optional(tx)

        if registry.stack:
            return Some(registry.stack[-1])
        return Nothing()


@final
class ConnectionManager:
    """Connection manager."""

    def __init__(
        self,
        name: str,
        tx_context: TransactionContext,
        logger: LogManager | None,
    ) -> None:
        self.name = name
        self.tx_context = tx_context
        self.logger = logger

    @asynccontextmanager
    async def transaction(
        self,
    ) -> AsyncIterator[Transaction]:
        """Open a new transaction.

        Yields:
            Transaction: The new transaction.
        """
        parent = self.tx_context.current(self.name)
        tx = Transaction(self.name)
        tx.parent = parent
        old_registry = _tx_registry.get()
        token = (
            _tx_registry.set(old_registry.extend(tx))
            if old_registry is not None
            else _tx_registry.set(TransactionRegistry())
        )

        try:
            async with in_transaction(self.name):
                yield tx
            tx.state = TransactionState.COMMITTED
            if tx.is_root:
                for result in await tx.execute_on_commit_callbacks():
                    if result.is_err and self.logger is not None:
                        self.logger.error(
                            "commit callback failed",
                            error=result.err().unwrap(),
                            connection=self.name,
                        )
        except BaseException:
            tx.state = TransactionState.ROLLED_BACK
            if tx.is_root:
                for result in await tx.execute_on_rollback_callbacks():
                    if result.is_err and self.logger is not None:
                        self.logger.error(
                            "rollback callback failed",
                            error=result.err().unwrap(),
                            connection=self.name,
                        )
            raise
        finally:
            _tx_registry.reset(token)
