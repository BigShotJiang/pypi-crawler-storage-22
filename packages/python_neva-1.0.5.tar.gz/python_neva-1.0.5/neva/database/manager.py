"""Database manager."""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import final

from neva import Option
from neva.database.connection import ConnectionManager, TransactionContext
from neva.database.transaction import Transaction
from neva.obs import LogManager


@final
class DatabaseManager:
    """Database manager."""

    def __init__(self, tx_context: TransactionContext, logger: LogManager) -> None:
        self._tx_context = tx_context
        self._logger = logger
        self._connections: dict[str, ConnectionManager] = {}

    def connection(self, name: str) -> ConnectionManager:
        """Returns a new connection manager."""
        return self._connections.setdefault(
            name, ConnectionManager(name, self._tx_context, self._logger)
        )

    def current(self, connection: str | None = None) -> Option[Transaction]:
        """Returns the current transaction.

        If no connection is specified, this will return the most recent transaction on
        any connection. This is something to keep in mind.
        """
        return self._tx_context.current(connection)

    @asynccontextmanager
    async def transaction(self, name: str = "default") -> AsyncIterator[Transaction]:
        """Returns a transaction to the default connection.

        Yields:
            Transaction: The transaction.
        """
        async with self.connection(name).transaction() as tx:
            yield tx
