"""Type stub for DB facade."""

from contextlib import AbstractAsyncContextManager
from typing import override

from neva import Option
from neva.arch import Facade
from neva.database import Transaction
from neva.database.connection import ConnectionManager

class DB(Facade):
    @classmethod
    @override
    def get_facade_accessor(cls) -> type: ...
    @classmethod
    def connection(cls, name: str) -> ConnectionManager:
        """Returns a connection manager for the given connection name."""

    @classmethod
    def current(cls, connection: str | None = None) -> Option[Transaction]:
        """Returns the current transaction.

        Args:
            connection: If provided, returns the transaction for that specific
                connection. If None, returns the innermost transaction.
        """

    @classmethod
    def transaction(
        cls, name: str = "default"
    ) -> AbstractAsyncContextManager[Transaction]:
        """Open a transaction on the specified connection.

        Args:
            name: The connection name.

        Yields:
            Transaction: The transaction.
        """
