"""Event facade."""

from typing import override

from neva import Result, events
from neva.arch import Facade
from neva.events import EventListener

class Event(Facade):
    """Event system facade."""

    @classmethod
    @override
    def get_facade_accessor(cls) -> type: ...
    @classmethod
    async def dispatch(cls, event: events.Event) -> list[Result[None, str]]: ...
    @classmethod
    def listen[T: events.Event](
        cls,
        event_cls: type[T],
        listener_cls: type[EventListener[T]],
    ) -> None: ...
