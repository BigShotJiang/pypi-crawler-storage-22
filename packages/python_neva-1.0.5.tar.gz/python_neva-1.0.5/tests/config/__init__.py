"""Configuration module test suite."""
