"""Shared fixtures for database tests."""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

import pytest
from flexmock import flexmock

import neva.database.connection as connection
from neva.database.connection import TransactionContext


@asynccontextmanager
async def _noop_transaction(connection_name: str) -> AsyncIterator[None]:
    """Stand-in for tortoise.transactions.in_transaction."""
    yield


@pytest.fixture(autouse=True)
def _mock_tortoise() -> None:
    _ = (
        flexmock(connection)
        .should_receive("in_transaction")
        .replace_with(_noop_transaction)
    )


@pytest.fixture
def tx_context() -> TransactionContext:
    return TransactionContext()
