"""Database manager tests."""

import pytest

from neva.database.connection import ConnectionManager, TransactionContext
from neva.database.manager import DatabaseManager
from neva.obs import LogManager


@pytest.fixture
def db(tx_context: TransactionContext) -> DatabaseManager:
    return DatabaseManager(tx_context, LogManager())


class TestDatabaseManager:
    async def test_transaction_uses_default_connection(
        self, db: DatabaseManager
    ) -> None:
        async with db.transaction() as tx:
            assert tx.conn_name == "default"

    async def test_transaction_uses_specified_connection(
        self, db: DatabaseManager
    ) -> None:
        async with db.transaction("analytics") as tx:
            assert tx.conn_name == "analytics"

    async def test_current_delegates_to_transaction_context(
        self, db: DatabaseManager
    ) -> None:
        assert db.current().is_nothing

        async with db.transaction():
            assert db.current().is_some

    async def test_current_with_connection_delegates_correctly(
        self, db: DatabaseManager
    ) -> None:
        async with db.transaction("analytics"):
            assert db.current("analytics").is_some
            assert db.current("default").is_nothing

    def test_connection_returns_cached_connection_manager(
        self, db: DatabaseManager
    ) -> None:
        first = db.connection("default")
        second = db.connection("default")

        assert first is second

    def test_connection_creates_new_manager_for_new_name(
        self, db: DatabaseManager
    ) -> None:
        default = db.connection("default")
        analytics = db.connection("analytics")

        assert default is not analytics
        assert isinstance(default, ConnectionManager)
        assert isinstance(analytics, ConnectionManager)
