"""Transaction context tests."""

from neva.database.connection import ConnectionManager, TransactionContext
from neva.obs import LogManager


class TestTransactionContext:
    async def test_current_returns_nothing_when_no_transaction(
        self, tx_context: TransactionContext
    ) -> None:
        assert tx_context.current().is_nothing

    async def test_current_returns_transaction_when_active(
        self, tx_context: TransactionContext
    ) -> None:
        manager = ConnectionManager("default", tx_context, LogManager())

        async with manager.transaction() as tx:
            current = tx_context.current()

            assert current.is_some
            assert current.unwrap() is tx

    async def test_current_with_connection_returns_specific_transaction(
        self, tx_context: TransactionContext
    ) -> None:
        manager_a = ConnectionManager("conn_a", tx_context, LogManager())
        manager_b = ConnectionManager("conn_b", tx_context, LogManager())

        async with manager_a.transaction() as tx_a, manager_b.transaction():
            result = tx_context.current("conn_a")

            assert result.is_some
            assert result.unwrap() is tx_a

    async def test_current_with_connection_returns_nothing_if_not_active(
        self, tx_context: TransactionContext
    ) -> None:
        manager = ConnectionManager("default", tx_context, LogManager())

        async with manager.transaction():
            assert tx_context.current("other").is_nothing

    async def test_current_returns_innermost_transaction(
        self, tx_context: TransactionContext
    ) -> None:
        manager_a = ConnectionManager("conn_a", tx_context, LogManager())
        manager_b = ConnectionManager("conn_b", tx_context, LogManager())

        async with manager_a.transaction() as tx_a:
            assert tx_context.current().unwrap() is tx_a

            async with manager_b.transaction() as tx_b:
                assert tx_context.current().unwrap() is tx_b
