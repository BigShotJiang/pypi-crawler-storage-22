"""Event system test suite."""
