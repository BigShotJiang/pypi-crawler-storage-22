"""Shared fixtures for event tests."""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from random import randint

import pydantic
import pytest
from flexmock import flexmock

import neva.database.connection as connection
from neva.arch import Application
from neva.database.connection import TransactionContext
from neva.database.manager import DatabaseManager
from neva.events import Event, EventDispatcher
from neva.obs import LogManager


class OrderPlaced(Event[int]):
    """An immediate event used across test modules."""

    id: int = pydantic.Field(default=randint(0, 200))  # noqa: S311
    order_id: int


class UserCreated(Event[int]):
    """A deferred event used across test modules."""

    user_id: int


@asynccontextmanager
async def _noop_transaction(connection_name: str) -> AsyncIterator[None]:
    """Stand-in for tortoise.transactions.in_transaction."""
    yield


@pytest.fixture(autouse=True)
def _mock_tortoise() -> None:
    _ = (
        flexmock(connection)
        .should_receive("in_transaction")
        .replace_with(_noop_transaction)
    )


@pytest.fixture
def tx_context() -> TransactionContext:
    return TransactionContext()


@pytest.fixture
def db(tx_context: TransactionContext) -> DatabaseManager:
    return DatabaseManager(tx_context, LogManager())


@pytest.fixture
def dispatcher(application: Application, db: DatabaseManager) -> EventDispatcher:
    return EventDispatcher(app=application, db=db)
