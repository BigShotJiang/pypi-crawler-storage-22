"""Core event dispatch tests."""

from typing import override

from neva import Err, Ok, Result
from neva.events import EventDispatcher, EventListener
from tests.events.conftest import OrderPlaced


class TestEventDispatch:
    async def test_dispatching_calls_registered_listener(
        self, dispatcher: EventDispatcher
    ) -> None:
        called = False

        class OrderPlacedListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                nonlocal called
                called = True
                return Ok(None)

        dispatcher.listen(OrderPlaced, OrderPlacedListener)
        _ = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert called

    async def test_listener_receives_the_dispatched_event(
        self, dispatcher: EventDispatcher
    ) -> None:
        received: OrderPlaced | None = None

        class OrderPlacedListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                nonlocal received
                received = event
                return Ok(None)

        dispatcher.listen(OrderPlaced, OrderPlacedListener)
        event = OrderPlaced(event_id=2, order_id=42)
        _ = await dispatcher.dispatch(event)

        assert received is event

    async def test_multiple_listeners_called_in_registration_order(
        self, dispatcher: EventDispatcher
    ) -> None:
        order: list[str] = []

        class FirstListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                order.append("first")
                return Ok(None)

        class SecondListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                order.append("second")
                return Ok(None)

        dispatcher.listen(OrderPlaced, FirstListener)
        dispatcher.listen(OrderPlaced, SecondListener)
        _ = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert order == ["first", "second"]

    async def test_dispatch_collects_listener_results(
        self, dispatcher: EventDispatcher
    ) -> None:
        class FailingListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                return Err("failed")

        class SucceedingListener(EventListener[OrderPlaced]):
            @override
            async def handle(self, event: OrderPlaced) -> Result[None, str]:
                return Ok(None)

        dispatcher.listen(OrderPlaced, FailingListener)
        dispatcher.listen(OrderPlaced, SucceedingListener)
        results = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert len(results) == 2
        assert results[0].is_err
        assert results[1].is_ok

    async def test_dispatch_with_no_listeners_returns_empty(
        self, dispatcher: EventDispatcher
    ) -> None:
        results = await dispatcher.dispatch(OrderPlaced(event_id=1, order_id=1))

        assert results == []
