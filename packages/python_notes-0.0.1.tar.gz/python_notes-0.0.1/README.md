# python-notes

A small notes app written in Python.