"""python-notes: A small notes app written in Python."""

from importlib.metadata import version

__version__ = version("python-notes")