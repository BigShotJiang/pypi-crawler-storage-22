import b as O
import b as O
from b import b as O
import b as O, b as O, b as O
from b import b as O, b as O
from b import b as O, b as O
from b import b as O, b as O

class O:

    def __init__(O, O=12):
        print(O)
        O.O = O
        O.O = 'toto'

    def O(O, O=1, O=None):
        O.O = 2
        print(O.O)

    @classmethod
    def O(O, O=1, O=None, O=17):
        O.O = 2
        print(O.O)
O = O()
O.O()
print(getattr(O, 'O'))
print('bbb')
print(O.__dict__['O'])
print('a')
O = O.__dict__['O']
print(O)
print('a')
print(O.titi())
