# -*- coding: utf-8 -*-
"""
# ---------------------------------------------------------------------------------------------------------
# ProjectName:  python-ocr-helper
# FileName:     __init__.py
# Description:  核心包
# Author:       zhouhanlin
# CreateDate:   2025/12/27
# Copyright ©2011-2025. Hunan xxxxxxx Company limited. All rights reserved.
# ---------------------------------------------------------------------------------------------------------
"""
