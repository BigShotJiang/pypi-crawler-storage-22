# -*- coding: utf-8 -*-
"""
# ---------------------------------------------------------------------------------------------------------
# ProjectName:  python-qdairlines-helper
# FileName:     yeepay_cashdesk.py
# Description:  易宝支付控制器
# Author:       ASUS
# CreateDate:   2026/01/22
# Copyright ©2011-2026. Hunan xxxxxxx Company limited. All rights reserved.
# ---------------------------------------------------------------------------------------------------------
"""
import inspect
from logging import Logger
from typing import Callable, Dict, Any
from playwright.async_api import BrowserContext
import qdairlines_helper.config.url_const as url_const
from qdairlines_helper.po.yeepay_cashdesk_page import YeepayCashDeskPage
from playwright_helper.utils.browser_utils import switch_for_table_window
from flight_helper.models.dto.payment import YBAccountPaymentInputDTO, PaymentResultDTO


async def load_yeepay_cash_desk_po(
        *, context: BrowserContext, logger: Logger, domain: str, protocol: str, timeout: float = 60.0
) -> YeepayCashDeskPage:
    url_prefix = f"{protocol}://{domain}"
    yeepay_cashdesk_url = url_prefix + url_const.yeepay_cashdesk_url

    current_page = await switch_for_table_window(
        browser=context, url_keyword=url_const.yeepay_cashdesk_url, wait_time=int(timeout)
    )

    nhlms_cashdesk_po = YeepayCashDeskPage(page=current_page, url=yeepay_cashdesk_url)
    await nhlms_cashdesk_po.url_wait_for(url=yeepay_cashdesk_url, timeout=timeout)
    logger.info(f"即将进入汇付天下收银台页面，页面URL<{current_page.url}>")
    return nhlms_cashdesk_po


async def yb_account_payment(
        *, page: YeepayCashDeskPage, logger: Logger, order_no: int, order_id: int, pre_check_of_payment: Callable,
        qlv_cookie: Dict[str, Any], yb_account_payment_dto: YBAccountPaymentInputDTO, timeout: float = 60.0
) -> PaymentResultDTO:
    # 1. 获取收银台支付流水
    pay_transaction = await page.get_order_transaction(timeout=timeout)
    logger.info(f"易宝支付收银台页面，支付流水<{pay_transaction}>获取完成")

    # 2. 获取订单支付金额
    actual_payment_amount = await page.get_order_amount(timeout=timeout)
    logger.info(f"易宝支付收银台页面，支付金额<{actual_payment_amount}>获取完成")

    # 3. 获取付款方式tab
    payment_type_tab = await page.get_payment_type_tab(
        payment_type=yb_account_payment_dto.payment_type, timeout=timeout
    )
    await payment_type_tab.click(button="left")
    logger.info(f"易宝支付收银台页面，【{yb_account_payment_dto.payment_type}】Tab点击完成")

    # 4. 输入易宝账号
    username_input = await page.get_username_input(timeout=timeout)
    await username_input.fill(value=yb_account_payment_dto.account)
    logger.info(f"易宝支付收银台页面，易宝账号<{yb_account_payment_dto.account}>输入完成")

    # 5. 输入交易密码
    password_input = await page.get_password_input(timeout=timeout)
    await password_input.fill(value=yb_account_payment_dto.password)
    logger.info(f"易宝支付收银台页面，交易密码<{yb_account_payment_dto.password}>输入完成")

    # 5.1. 前置检查，为何放在此处
    if inspect.iscoroutinefunction(pre_check_of_payment):
        await pre_check_of_payment(
            order_id=order_id, logger=logger, qlv_cookie=qlv_cookie,
            payment_type=yb_account_payment_dto.payment_type
        )
    else:
        pre_check_of_payment(
            order_id=order_id, logger=logger, qlv_cookie=qlv_cookie,
            payment_type=yb_account_payment_dto.payment_type
        )

    # 6. 点击【下一步】
    next_step_btn = await page.get_next_step_btn(timeout=timeout)
    await next_step_btn.click(button="left")
    logger.info("易宝支付收银台页面，【下一步】按钮点击完成")
    return PaymentResultDTO(
        channel_name=yb_account_payment_dto.channel_name,
        payment_type=yb_account_payment_dto.payment_type,
        account=yb_account_payment_dto.account,
        password=yb_account_payment_dto.password,
        order_no=order_no,
        pay_amount=actual_payment_amount,
        pay_transaction=pay_transaction
    )