# Python SDK Remote Python Package

## TODOs

TODO Add Requests.post() method which wraps requests.post() and adds logging and error handling similar to OurAxios.post() in typescript-sdk-remote repo

TODO If we don't have DatetimeRange, develop DatetimeRange which has start_datetime and end_datetime data members

TODO create OurObfuscation class with methods for each PII field obfuscation_first_name() - can have persistant mapping table in memory, obfuscation_last_name() - can have persistant mapping table in memory, obfuscation_organizataion_name() - can be persitant mapping table in memory, obfuscation_email_address() - can be emails in our development domain, obfuscation_organization(), obfuscation_phone_number() - preferable invalid phone numbers, obfuscation_social_id() - preferable valid social ids - obfuscation only when environment is not Prod1 and not Dvlp1.
Should do the same both in python-sdk-remote and typeScript-sdk-remote<br>

TODO Rewrite more examples

## Permission to the repo
Many Team Members (python-team, typescript-team, reactjs-team ...) are using makec/make_py/make_ts to CreateDevelopmentEnvironment.ps and they need read access to this repo to build their local environment.

## Usage in Serverless.com

In serverless, use this decorator:
```py
from python_sdk_remote.http_response import handler_decorator
from logger_local.Logger import Logger
logger = Logger.create_logger(object=your_logger_object)
@handler_decorator(logger=logger)
def my_handler(request_parameters: dict) -> dict:
  # Here you can use both camelCase and snake_case keys from request_parameters
```

## Versions

0.0.151 for PRINT_STARS
0.0.152 LogMessageSeverity and StartEndEnum values in UPPERCASE
