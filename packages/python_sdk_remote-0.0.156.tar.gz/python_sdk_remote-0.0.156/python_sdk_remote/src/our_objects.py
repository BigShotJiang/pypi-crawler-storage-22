# TODO Please update and use in at least one package, i.e., user-external
#class OurObjects:
#    objects_list: list(OurObjects)

# TODO Implement get_by_location( self, location Location, distance Distance): with iterator
