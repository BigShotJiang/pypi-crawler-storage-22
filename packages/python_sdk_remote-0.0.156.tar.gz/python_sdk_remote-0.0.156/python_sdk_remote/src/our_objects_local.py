# TODO This is DAL wrapping the database of specific entity. Update this class and use it for example in UserExternalsLocal
# class OurObjectsLocal
#
#    entity_id: EntityId
#
#    # Returns all the active Objects
#    # TODO implement using active_by_filer(filter)
#    def active() -> OurObjects:
#
#    # TODO implement using GenericCrud and where
#    def active_by_filter (Filter) -> OurObjects:

