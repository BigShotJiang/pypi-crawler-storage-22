# TODO should have the same methods as in OurObjectsLocal
#
# class OurObjectsRemote:
#
#    def active_by_filter( Filter )
