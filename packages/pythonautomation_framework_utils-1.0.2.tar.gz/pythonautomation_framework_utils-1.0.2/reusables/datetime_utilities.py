import datetime, calendar

def GetPresentDate(dateformat):
    today = datetime.date.today()
    return today.strftime(dateformat)

def GetPreviousdate(dateformat, daystosubtract = 0, monthstosubtract = 0, yearstosubstract = 0):#####333
    today = datetime.date.today()
    if daystosubtract != 0:
        today = today - datetime.timedelta(days = daystosubtract)
    if monthstosubtract != 0:
        years_to_subtract = monthstosubtract // 12
        remaining_months = monthstosubtract % 12
        today = today.replace(year=today.year - years_to_subtract)
        if remaining_months:
            new_month = today.month - remaining_months
            new_year = today.year - 1 if new_month <= 0 else today.year
            new_month = 12 if new_month <= 0 else new_month
            today = today.replace(year=new_year, month=new_month)
    if yearstosubstract != 0:
        new_year = today.year - yearstosubstract
        today = datetime.datetime(new_year, today.month, today.day)
    return today.strftime(dateformat)

def GetPreviousdatefromGivendate(date_string, dateformat, daystosubtract = 0, monthstosubtract = 0, yearstosubstract = 0):#####333
    getdate = datetime.datetime.strptime(date_string, dateformat)
    if daystosubtract != 0:
        getdate = getdate - datetime.timedelta(days = daystosubtract)
    if monthstosubtract != 0:
        years_to_subtract = monthstosubtract // 12
        remaining_months = monthstosubtract % 12
        getdate = getdate.replace(year=getdate.year - years_to_subtract)
        if remaining_months:
            new_month = getdate.month - remaining_months
            new_year = getdate.year - 1 if new_month <= 0 else getdate.year
            new_month = 12 if new_month <= 0 else new_month
            getdate = getdate.replace(year=new_year, month=new_month)
    if yearstosubstract != 0:
        new_year = getdate.year - yearstosubstract
        getdate = datetime.datetime(new_year, getdate.month, getdate.day)
    return getdate.strftime(dateformat)

def GetFuturedate(dateformat, daystoadd = 0, monthstoadd = 0, yearstoadd = 0):############
    today = datetime.date.today()
    if daystoadd != 0:
        today = today + datetime.timedelta(days = daystoadd)
    if monthstoadd != 0:
        new_year = today.year + (today.month + monthstoadd - 1) // 12
        new_month = (today.month + monthstoadd - 1) % 12 + 1
        new_day = min(today.day,calendar.monthrange(new_year, new_month)[1])
        today = datetime.datetime(new_year, new_month, new_day)
    if yearstoadd != 0:
        new_year = today.year + yearstoadd
        today = datetime.datetime(new_year, today.month, today.day)
    return today.strftime(dateformat)

def GetFuturedatefromGivendate(date_string, dateformat, daystoadd = 0, monthstoadd = 0, yearstoadd = 0):############
    getdate = datetime.datetime.strptime(date_string, dateformat)
    if daystoadd != 0:
        getdate = getdate + datetime.timedelta(days = daystoadd)
    if monthstoadd != 0:
        new_year = getdate.year + (getdate.month + monthstoadd - 1) // 12
        new_month = (getdate.month + monthstoadd - 1) % 12 + 1
        new_day = min(getdate.day,calendar.monthrange(new_year, new_month)[1])
        getdate = datetime.datetime(new_year, new_month, new_day)
    if yearstoadd != 0:
        new_year = getdate.year + yearstoadd
        getdate = datetime.datetime(new_year, getdate.month, getdate.day)
    return getdate.strftime(dateformat)

def FirstDate_PreviousMonth(dateformat):
    last_day_of_prev_month = datetime.date.today().replace(day=1) - datetime.timedelta(days=1)
    start_day_of_prev_month = datetime.date.today().replace(day=1) - datetime.timedelta(days=last_day_of_prev_month.day)
    start_day_of_prev_month = start_day_of_prev_month.strftime(dateformat)
    return(start_day_of_prev_month)

def LastDate_PreviousMonth(dateformat):
    last_day_of_prev_month = datetime.date.today().replace(day=1) - datetime.timedelta(days=1)
    last_day_of_prev_month = last_day_of_prev_month.strftime(dateformat)
    return(last_day_of_prev_month)

def ConverttoDatetime(date_str, date_format='%d-%m-%Y'):
    date = datetime.datetime.strptime(date_str, date_format)
    return date

def FirstDate_CurrentMonth(dateformat):
    return datetime.date.today().replace(day=1).strftime(dateformat)

def LastDate_CurrentMonth(dateformat):
    date = datetime.date.today().replace(day=28) + datetime.timedelta(days=4)
    return (date - datetime.timedelta(days=date.day)).strftime(dateformat)
    
def FirstDate_NextMonth(dateformat):
    return ((datetime.date.today().replace(day=1) + datetime.timedelta(days=32)).replace(day=1)).strftime(dateformat)

def LastDate_NextMonth(dateformat):
    date = (datetime.date.today().replace(day=1) + datetime.timedelta(days=32)).replace(day=1)
    NextMonth = date.replace(day=28) + datetime.timedelta(days=4)
    LastDate = NextMonth - datetime.timedelta(days=NextMonth.day)
    return LastDate.strftime(dateformat)
    
def GetCurrentDay(): # returns weekday
    return (datetime.datetime.now().strftime('%A'))

def GetCurrentMonth(): # return Month number
    return (datetime.datetime.now().strftime('%B'))

def GetCurrentYear(): # return Year number
    return (datetime.datetime.now().strftime('%Y'))

def GetDayfromGivendate(date_string, dateformat): # return Day 
    return (datetime.datetime.strptime(date_string, dateformat).strftime('%A'))

def GetMonthfromGivendate(date_string, dateformat): # return Day 
    return (datetime.datetime.strptime(date_string, dateformat).strftime('%B'))

def GetYearfromGivendate(date_string, dateformat): # return Day 
    return (datetime.datetime.strptime(date_string, dateformat).strftime('%Y'))

def StartDatefromGivendate(date, dateformat):
    return date.replace(day=1).strftime(dateformat)

def EndDatefromGivendate(date, dateformat):
    NextMonth = date.replace(day=28) + datetime.timedelta(days=4)
    LastDate = NextMonth - datetime.timedelta(days=NextMonth.day)
    return LastDate.strftime(dateformat)

def GetDateDifference(StartDate, EndDate, dateformat):
    Value = datetime.datetime.strptime(StartDate, dateformat) - datetime.datetime.strptime(EndDate, dateformat)
    return abs(Value.days)

def GetCurrentTime(timeformat):
    return (datetime.datetime.now()).strftime(timeformat)

def GetPastTime(timeformat, Hour=0, Min=0, Sec=0):
    now = datetime.datetime.now()
    return (now - datetime.timedelta(hours=Hour, minutes=Min, seconds=Sec)).strftime(timeformat)

def GetFutureTime(timeformat, Hour=0, Min=0, Sec=0):
    now = datetime.datetime.now()
    return (now + datetime.timedelta(hours=Hour, minutes=Min, seconds=Sec)).strftime(timeformat)
