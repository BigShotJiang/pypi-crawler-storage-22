import os, time, shutil, glob, datetime
import smtplib, win32gui, win32com.client, threading
import pandas
from pywinauto.application import Application
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

def delay(delay:int):
    print(f"Delay: {delay}")
    time.sleep(delay)
    
def fileexits(filepath:str):
    try:
        if os.path.exists(filepath):
            print(f"Exists: {filepath}")
            return True
        else:
            print(f"Not Exists: {filepath}")
            return False
    except:
        pass
    
def createdirectory(folderpath:str):
    try:
        os.makedirs(folderpath)
        print(f"Created: {folderpath}")
    except:
        pass

def deletedirectory(folderpath:str):
    try:
        shutil.rmtree(folderpath)
        print(f"Deleted: {folderpath}")
    except:
        pass
    
def deleteallfiles(folderpath:str, extention:str):
    try:
        for file in glob.glob(os.path.join(folderpath, extention)):
            os.remove(file)
            print(f"Deleted: {file}")
    except:
        pass
    
def getfilelist(folderpath:str):
    print(f"Get file list: {folderpath}")
    return (os.listdir(folderpath))
    
def createzipfolder(pathtosavezip:str, zipfoldername:str, pathtocreatezip:str):
    shutil.make_archive(pathtosavezip +'\\'+ zipfoldername, 'zip', pathtocreatezip)
    print(f"ZIP Created Zip: {pathtosavezip}")
    
def Email(from_email:str, to_email:str, subject:str, body:str, smtp:str, smtp_password:str=None,authenticated:bool=True,cc_email:str=None, bcc_email:str=None, attachments:list=None, folder_path:str=None):
    print(f"Sending SMTP email")
    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    if cc_email and bcc_email:
        msg['Cc'] = ",".join([cc_email, bcc_email])
    elif cc_email:
        msg['Cc'] = cc_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))
    if attachments:
        for attachment in attachments:
            with open(attachment, 'rb') as file:
                part = MIMEApplication(file.read())
            part['Content-Disposition'] = f'attachment; filename="{os.path.basename(attachment)}"'
            msg.attach(part)
    if folder_path:
        for file_name in os.listdir(folder_path):
            file_path = os.path.join(folder_path, file_name)
            if os.path.isfile(file_path):
                with open(file_path, 'rb') as file:
                    p = MIMEBase('application', 'octet-stream')
                    p.set_payload((file).read())
                    encoders.encode_base64(p)
                    p.add_header('Content-Disposition', "attachment; filename= %s" % file_name)
                    msg.attach(p)
    s = smtplib.SMTP(smtp)
    if authenticated:
        s.login(from_email, smtp_password)
    text = msg.as_string()
    s.sendmail( msg['From'],  msg['To'].split(',') + msg['Cc'].split(','), text)
    s.quit()

def getfilepath(folderpath:str, filename:str):
    print(f"Get file path: {filename}")
    return os.path.join(folderpath, filename)

def getfilecount(folderpath:str):
    print(f"Get file path: {folderpath}")
    return len(os.listdir(folderpath))

def exceldialog():
    timeout = time.time() + 30*.25
    while True:
        if(win32gui.FindWindow("#32770", "Microsoft Excel")):
            app = Application().connect(title="Microsoft Excel")
            app["Microsoft Excel"].Yes.Click()
            break
        if time.time() > timeout:
            break

def converttoxlsx(filename:str): #Converting .xls into xlsx#
    print(f"Converting .xls format to .xlsx format")
    excel = win32com.client.gencache.EnsureDispatch('Excel.Application')
    e = threading.Thread(name='excel',target=exceldialog())
    e.start()
    wb = excel.Workbooks.Open(filename)
    e.join()
    doc_sense_label = wb.SensitivityLabel
    label_info = wb.SensitivityLabel.CreateLabelInfo()
    label_info.LabelId = '134277c1-31d4-4dba-9248-3ba93a3f3112'
    label_info.LabelName = 'Internal sub1'
    label_info.SiteId = 'eb70b763-b6d7-4486-8555-8831709a784e'
    doc_sense_label.SetLabel(label_info, label_info)
    wb.SaveAs(filename + "x", FileFormat=51) #FileFormat = 56 is for .xls extension
    wb.Close() 
    excel.Application.Quit()
    return filename + "x"

def createdataframe(**kwargs):
    print(f"Empty Dataframe created")
    return (pandas.DataFrame(**kwargs))

def readexcelfile(excelfilepath:str, **kwargs):
    return (pandas.read_excel(excelfilepath, **kwargs))

def writeexcelfile(dataframe, excelfilepath:str, **kwargs):
    dataframe.to_excel(excelfilepath, **kwargs)

def readcsvfile(csvfilepath:str, **kwargs):
    return (pandas.read_excel(csvfilepath, **kwargs))

def writecsvfile(dataframe, csvfilepath:str, **kwargs):
    dataframe.to_csv(csvfilepath, **kwargs)

def closeexcel():
    print(f"Close excel files")
    os.system("taskkill /im Excel.exe /f >nul 2>&1")
    
def killapplication(application:str):
    print(f"Close application: {application}")
    os.system("taskkill /im Excel.exe /f >nul 2>&1")
    
def killmultipleapplication(applications:list):
    for application in applications:
        print(f"Close application: {application}")
        os.system("taskkill /im "+application+" /f >nul 2>&1")

def getuserprofilepath():
    return os.environ.get("USERPROFILE")

def GetAbsolutePath(RelativePath:str):
    return (os.path.abspath(RelativePath))

def MoveFilesTo_OtherDirectory(source_dir, target_dir, allfiles = False, filename =''):
    if allfiles:
        file_names = os.listdir(source_dir)
        for file_name in file_names:
            shutil.move(os.path.join(source_dir, file_name), target_dir)
    else:
        file_names = os.listdir(source_dir)
        for file_name in file_names:
            if file_name == filename:
                shutil.move(os.path.join(source_dir, file_name), target_dir)

def CopyDataframe_toClipboard(Dataframe, **kwargs):
    return Dataframe.to_clipboard(**kwargs)

def CopyData_toClipboard(Data): # Either List or Stirng or integer
    command = 'echo ' + str(Data).strip() + '| clip'
    os.system(command)

def Write_dfs_toMultipleWorkSheets(file_name, dataframes, worksheet_names, **kwargs):
    writer = pandas.ExcelWriter(file_name, engine='xlsxwriter')
    for dataframe, worksheet_name in zip(dataframes, worksheet_names):
        dataframe.to_excel(writer, sheet_name=worksheet_name, **kwargs)
    writer.save()

def Write_dfs_toSingleWorkSheet(file_name, dataframes, worksheet_name, startrows, startcols, **kwargs):
    writer = pandas.ExcelWriter(file_name, engine='xlsxwriter')
    for dataframe ,startrow, startcol in zip(dataframes, startrows, startcols):
        dataframe.to_excel(writer, sheet_name=worksheet_name, startrow = startrow, startcol = startcol, **kwargs)
    writer.save()

def AppendDataframe_toExcel(filepath, sheet_name, dataframe):
    df = readexcelfile(filepath,sheet_name = sheet_name)
    pandas.read_excel(filepath, sheet_name = sheet_name)
    df_append = df.append(dataframe, ignore_index=True)
    df_append.to_excel(filepath, index=False, header=True)

def Merge_dataframes(left_dataframe, right_dataframe, **kwargs):
    left_dataframe = left_dataframe.merge(right_dataframe, **kwargs)
    return left_dataframe

def Dataframecolumn_tolist(dataframe, column_name):
    return dataframe[column_name].tolist()

def Remove_NaN_fromlist(listname):
    return [x for x in listname if x == x]

def ConvertList_toString(Delimiter, List):
    string = Delimiter.join(str(i) for i in List)
    return string

def Splitstring_tolist(string, Delimiter, maxsplit):
    my_list = string.split(Delimiter, maxsplit)
    return (my_list)

def String_Replace(string, old_value, new_value, count=None):
    if count is not None:
        return (str(string).replace(str(old_value), str(new_value), count))
    else:
        return (str(string).replace(str(old_value), str(new_value)))

def String_Strip(string, character):
    new_string = string.strip(character)
    return (new_string)

def String_lstrip(string, character):
    left_string = string.lstrip(character)
    return (left_string)

def String_rstrip(string, character):
    right_string = string.rstrip(character)
    return (right_string)
    
def List_sum(List):
    return sum(List)
