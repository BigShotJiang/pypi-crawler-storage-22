from setuptools import setup, find_packages

setup(
    name="pythonautomation-framework-utils",   # unique package name
    version="1.0.2",                     # follow semantic versioning
    description="Reusable utilities for automation frameworks",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="SabarishM",
    author_email="mrsabarishmurugan@gmail.com",
    url="https://github.com/sabarishmurugan/automation-framework-utils",
    license="MIT",
    packages=find_packages(),
    install_requires=["requests"],       # dependencies
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)