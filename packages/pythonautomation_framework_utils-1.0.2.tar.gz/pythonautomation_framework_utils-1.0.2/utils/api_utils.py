import requests

def get_json(url, params=None, headers=None):
    response = requests.get(url, params=params, headers=headers)
    response.raise_for_status()
    return response.json()

def post_json(url, data, headers=None):
    response = requests.post(url, json=data, headers=headers)
    response.raise_for_status()
    return response.json()
