import time

def retry(func, retries=3, delay=2, exceptions=(Exception,)):
    for attempt in range(retries):
        try:
            return func()
        except exceptions as e:
            if attempt < retries - 1:
                time.sleep(delay)
            else:
                raise e
