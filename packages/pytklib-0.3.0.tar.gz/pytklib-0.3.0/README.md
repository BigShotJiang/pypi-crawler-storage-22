# pytklib

**pytklib** is an easy-to-use Tkinter helper library for Python.  
It lets you add buttons, labels, images, and sounds easily in Tkinter projects.

## Features

- Add unlimited buttons and labels
- Add images to buttons and labels
- Play sounds on Windows
- Change window title and size
- Easy to start and hide windows

## Update releases
- 0.1.0 is the og release
- 0.2.0 adds moving and names system
- 0.2.1 adds a required python amount

## Example

```python
import pytklib

pytklib.add_label("Hello World!", 10, 10)
pytklib.add_button("Click Me", lambda: print("Hi!"), 50, 50)
pytklib.startwin()
