from tkinter import Tk, Button, Label, PhotoImage, Entry

# ---- Base Window ----
root = Tk()
root.title("Pytklib Base Title")
root.geometry("400x300")

# ---- Storage ----
objects = {}  # store all widgets by name
pics = []

initvarsdone = False

# ---- Core Functions ----
def change_title(title):
    root.title(title)

def change_geometry(x, y):
    global gx, gy
    gx = x
    gy = y
    root.geometry(f"{x}x{y}")

def startwin():
    root.mainloop()

def initvars():
    global initvarsdone
    initvarsdone = True

def easysetup(geox, geoy, title):
    change_geometry(geox, geoy)
    change_title(title)
    initvars()

# ---- Add Widgets ----
def add_button(name, text, command=None, x=0, y=0, image_path=None, width=None, height=None, bg=None, fg=None):
    if image_path:
        img = PhotoImage(file=image_path)
        btn = Button(root, image=img, command=command)
        btn.image = img  # keep reference!
    else:
        btn = Button(root, text=text, command=command)

    if width: btn.config(width=width)
    if height: btn.config(height=height)
    if bg: btn.config(bg=bg)
    if fg: btn.config(fg=fg)

    btn.place(x=x, y=y)
    objects[name] = btn  # store by name
    return btn

def add_label(name, text, x=0, y=0):
    lbl = Label(root, text=text)
    lbl.place(x=x, y=y)
    objects[name] = lbl
    return lbl

def add_photo_lbl(name, path, x=0, y=0):
    img = PhotoImage(file=path)
    lbl = Label(root, image=img)
    lbl.place(x=x, y=y)
    lbl.image = img  # keep reference!
    objects[name] = lbl
    pics.append(lbl)
    return lbl
def add_field(name, text, x=0, y=0):
    fld = Entry(root)
    fld.place(x=x, y=y)
    objects[name] = fld
    return fld
def get_text(name):
    widget = objects.get(name)
    if widget is None:
        raise KeyError(f"No widget named {name!r}")
    return widget.get()  # Entry.get() returns the current text


# ---- Move Widget by Name ----
def move(name, x, y):
    if name in objects:
        objects[name].place(x=x, y=y)
    else:
        print(f"No object named '{name}' found.")
def del_obj(name):
    global gx, gy
    delgx = gx + 10000
    delgy = gy + 10000
    move(name, delgx, delgy)



