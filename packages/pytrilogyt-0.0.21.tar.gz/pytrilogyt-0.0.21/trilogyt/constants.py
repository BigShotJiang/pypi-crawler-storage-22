from logging import Logger, getLogger

TRILOGY_NAMESPACE = "_trilogyt"

OPTIMIZATION_NAMESPACE = "optimization"

OPTIMIZATION_FILE = "_internal_cached_intermediates"

OPT_PREFIX = "_opt_"

IGNORED_PREFIX = "_internal"


logger: Logger = getLogger("trilogyt")
