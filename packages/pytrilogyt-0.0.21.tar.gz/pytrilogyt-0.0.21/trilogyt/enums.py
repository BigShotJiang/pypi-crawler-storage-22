from enum import Enum


class PreqltMetrics(Enum):
    CREATED_AT = "_created_at"


class Backend(Enum):
    DBT = "dbt"
