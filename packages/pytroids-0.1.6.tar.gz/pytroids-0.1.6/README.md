# Pytroids

**Pytroids** — Python on Steroids 💪

A collection of handy Python utilities for day-today or advance usages.

## Features

- Generate Fibbonacci
- Checks Number Types
- Various List Utilities

## Installation

```bash
pip install pytroids
```
