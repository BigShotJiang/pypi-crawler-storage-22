"""
Initialize the module
"""

LOGGER_NAME = "pytubekit"
