#
# Trellis Object
#

import itertools
from typing import Tuple

import numpy as np


class Trellis(object):
    @staticmethod
    def butterfly(path_metrics, branch_metrics):
        result = [path + branch for path, branch in zip(path_metrics, branch_metrics)]
        return np.max(result)

    def __init__(self):
        self.transition_matrix_input = np.array(
            [[-1, None, 1, None], [1, None, -1, None], [None, -1, None, 1], [None, 1, None, -1]]
        )
        self.transition_matrix_output = np.array(
            [[-1, None, 1, None], [-1, None, 1, None], [None, -1, None, 1], [None, -1, None, 1]]
        )

        self.past_states = [(0, 1), (2, 3), (0, 1), (2, 3)]
        self.future_states = [(0, 2), (0, 2), (1, 3), (1, 3)]

        all_transitions = list(itertools.product([0, 1, 2, 3], repeat=2))
        self.possible_transitions = [
            t for t in all_transitions if self.transition_matrix_input[t] is not None
        ]

    def transition_to_symbols(self, state: int, next_state: int) -> Tuple[int, int]:
        i = self.transition_matrix_input[state, next_state]
        o = self.transition_matrix_output[state, next_state]
        return i, o
