fn main() {
    pyo3_build_config::use_pyo3_cfgs();
}
