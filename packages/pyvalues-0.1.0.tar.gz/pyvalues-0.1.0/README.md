# pyvalues

Python library for processing, evaluating, and visualizing (Schwartz) human value scores
