"""Version information for pyvergeos."""

__version__ = "0.1.0"
