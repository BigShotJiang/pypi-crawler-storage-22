"""Data models for pyvergeos (optional Pydantic integration)."""
