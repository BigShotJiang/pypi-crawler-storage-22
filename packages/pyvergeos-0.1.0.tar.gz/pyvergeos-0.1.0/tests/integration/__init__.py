"""Integration tests for pyvergeos.

These tests require a live VergeOS instance.
Set environment variables:
- VERGE_HOST
- VERGE_USERNAME
- VERGE_PASSWORD
"""
