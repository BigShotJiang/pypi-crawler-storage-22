"""Report domain examples package."""
