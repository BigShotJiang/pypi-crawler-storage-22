"""CFX transport adapter for AMQP messaging."""

from pywats_cfx.transport.cfx_transport import CFXTransport

__all__ = ["CFXTransport"]
