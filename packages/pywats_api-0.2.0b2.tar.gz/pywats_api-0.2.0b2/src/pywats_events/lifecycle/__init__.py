"""Lifecycle management for event system components."""

from pywats_events.lifecycle.manager import LifecycleManager

__all__ = ["LifecycleManager"]
