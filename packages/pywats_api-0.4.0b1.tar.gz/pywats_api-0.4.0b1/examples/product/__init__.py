"""Product domain examples package."""
