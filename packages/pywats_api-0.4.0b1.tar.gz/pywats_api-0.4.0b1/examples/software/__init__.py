"""Software domain examples package."""
