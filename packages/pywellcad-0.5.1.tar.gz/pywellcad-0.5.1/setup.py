import setuptools
setuptools.setup()
