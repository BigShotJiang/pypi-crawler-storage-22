"""WeMo device API."""
