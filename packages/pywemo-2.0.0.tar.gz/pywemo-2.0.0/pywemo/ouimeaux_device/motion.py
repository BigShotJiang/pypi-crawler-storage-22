"""Representation of a WeMo Motion device."""

from . import Device


class Motion(Device):
    """Representation of a WeMo Motion device."""
