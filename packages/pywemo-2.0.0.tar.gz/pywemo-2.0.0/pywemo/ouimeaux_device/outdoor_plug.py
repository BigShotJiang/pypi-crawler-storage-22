"""Representation of a WeMo OutdoorPlug device."""

from .switch import Switch


class OutdoorPlug(Switch):
    """Representation of a WeMo Motion device."""
