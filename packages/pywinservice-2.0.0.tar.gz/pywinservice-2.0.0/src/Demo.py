"""Demo Python Service."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from logging import Logger
from typing import override

from pyservice import Service
from pyservice import ServiceConfig

logger: Logger = logging.getLogger()


@dataclass(frozen=True, kw_only=True)
class DemoConfig(ServiceConfig):
    """Config for Demo service."""


class Demo(Service):
    """Demo service."""

    svc_name = __qualname__
    svc_version = "0.0.0"
    svc_display_name = "Demo Service"
    svc_description = "Demo Service Description"
    svc_dependencies = None

    config_class = DemoConfig
    config: DemoConfig

    should_start: bool = True
    should_start_fail: bool = False
    should_stop_fail: bool = False
    should_run_fail: bool = False

    @override
    def on_start(self) -> bool:
        """Service tasks to do when the service is starting.

        :return: True if the service has successfully started, False otherwise.
        """
        logger.info("Demo Service Start")
        if self.should_start_fail:
            raise RuntimeError
        return self.should_start

    @override
    def on_run(self) -> None:
        """Service tasks to do when the timer elapses."""
        logger.info("Demo Service Run")
        if self.should_run_fail:
            raise RuntimeError

    @override
    def on_run_success(self, time_taken: float) -> None:
        """Service tasks to do on a successful run.

        :param time_taken: The time in seconds that the run took.
        """
        super().on_run_success(time_taken)
        logger.info("Demo Service Run Success")

    @override
    def on_run_failed(self, time_taken: float, exc: Exception) -> None:
        """Service tasks to do on a successful run.

        :param time_taken: The time in seconds that the run took.
        :param exc: The exception that was raised.
        """
        super().on_run_failed(time_taken, exc)
        logger.info("Demo Service Run Failed")

    @override
    def on_stop(self) -> None:
        """Service tasks to do when the service is stopping."""
        logger.info("Demo Service Stop")
        if self.should_stop_fail:
            raise RuntimeError


if __name__ == "__main__":
    Demo.handle_main()
