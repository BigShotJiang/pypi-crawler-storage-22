call .\.venv\Scripts\activate.bat

pyinstaller ^
    --onefile ^
    --specpath build ^
    --hidden-import win32timezone ^
    -n Demo src/Demo.py
python -c "import shutil; shutil.copy('dist/Demo.exe', 'run')"
