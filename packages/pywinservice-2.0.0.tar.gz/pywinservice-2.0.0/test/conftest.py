"""Common fixtures for all tests."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Mapping
    from collections.abc import Sequence


def make_fixture_simple[T](arg_name: str, *values: T) -> Mapping[str, ...]:
    """Make pytest.fixture arguments."""
    return {
        "params": values,
        "ids": [f"{arg_name}={v}" for v in values],
    }


def make_params_simple[T](arg_name: str, *values: T) -> Mapping[str, ...]:
    """Make pytest.mark.parametrize arguments."""
    return {
        "argnames": arg_name,
        "argvalues": values,
        "ids": [f"{arg_name}={v}" for v in values],
    }


def make_params[T](arg_names: tuple[str, ...], values: Sequence[tuple[T, ...]]) -> Mapping[str, ...]:
    """Make pytest.mark.parametrize arguments."""
    return {
        "argnames": arg_names,
        "argvalues": values,
        "ids": ["-".join(f"{n}={v}" for n, v in zip(arg_names, v_tuple, strict=True)) for v_tuple in values],
    }
