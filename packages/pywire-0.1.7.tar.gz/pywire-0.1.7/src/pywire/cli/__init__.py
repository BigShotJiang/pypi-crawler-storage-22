"""CLI module."""
