"""Entry point for running the CLI as a module: python -m pyworkflow.cli"""

from pyworkflow.cli import main

if __name__ == "__main__":
    main()
