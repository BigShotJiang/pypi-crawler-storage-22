# pyxblend - Python Code Encryption

![Python Version](https://img.shields.io/badge/python-3.x-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

`pyxblend` (formerly encodify) is a powerful, advanced Python module designed to provide a suite of robust encoding and obfuscation techniques for Python scripts. It leverages multi-layered compression, base64 encoding, and custom cryptographic methods to secure your code.

## Table of Contents

- [Installation](#installation)
- [Usage](#usage)
  - [Basic Encoding](#basic-encoding)
  - [Advanced Encryption](#advanced-encryption)
  - [Randomized Obfuscation](#randomized-obfuscation)
- [Available Methods](#available-methods)
- [License](#license)

## Installation

```bash
pip install pyxblend
```

## Usage

### Importing the Module

```python
from pyxblend import PyxBlend
```

### Basic Usage

```python
obfuscator = PyxBlend()

code = "print('Hello, PyxBlend!')"

# Use a specific method (e.g., method 2 for strong compression+encoding)
encoded = obfuscator.encrypt(code, method=2)
print(encoded)
```

### Advanced Encryption

PyxBlend includes a robust encryption method that derives keys using PBKDF2 and uses a hash-based stream cipher, making it significantly more secure than simple obfuscation.

```python
# Encrypt with a custom key
secure_code = obfuscator.secure_encrypt(code, key="my_secret_password", iterations=100000)
# The output is a self-executing script that decrypts itself at runtime
```

### Randomized Obfuscation

To make reverse engineering harder, apply a random encoding method:

```python
# Randomly select a method and apply it 3 times recursively
random_encoded = obfuscator.random_encrypt(code, iterations=3)
```

## Available Methods

`pyxblend` supports over 30 encoding variations combining:
- **Compression**: LZMA, Gzip, Zlib, BZ2
- **Encoding**: Base64, Base85, Base32
- **Serialization**: Marshal
- **Encryption**: Custom Hash-based Stream Cipher (XOR with PBKDF2 derived keys)
- **Minification**: Python Minifier

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
