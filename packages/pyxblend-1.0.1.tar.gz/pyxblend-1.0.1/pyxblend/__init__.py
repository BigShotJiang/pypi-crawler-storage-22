"""
PyxBlend - Advanced Python Code Obfuscation and Encryption Module
Author: PythonToday
"""

import random
import string
import marshal
import base64
import gzip
import lzma
import zlib
import bz2
import hashlib
import secrets
import python_minifier
import struct
import time

class PyxBlend:
    """
    PyxBlend provides advanced obfuscation and encryption techniques for Python code.
    It supports multi-layered compression, encoding, and cryptographic transformation
    to protect source code from casual inspection and reverse engineering.
    """

    def __init__(self):
        self.layers = [
            self.m1, self.m2, self.m3, self.m4, self.m5,
            self.m6, self.m7, self.m8, self.m9, self.m10,
            self.m11, self.m20
        ]

    def _compile_and_dump(self, code):
        """Helper to compile and marshal code."""
        if isinstance(code, str):
            try:
                # Try to minify first for extra obfuscation
                try:
                    code = python_minifier.minify(code)
                except:
                    pass
                code = compile(code, "<pyxblend>", "exec")
            except Exception:
                # If compilation fails (e.g. partial code), marshal as string (less secure)
                pass
        return marshal.dumps(code)

    # --- Core Encoding Methods (Obfuscation) ---

    def m1(self, code):
        data = self._compile_and_dump(code)
        en = gzip.compress(data)
        return (
            f"import marshal,gzip\n"
            f"exec(marshal.loads(gzip.decompress({en})))"
        )

    def m2(self, code):
        data = self._compile_and_dump(code)
        en = lzma.compress(base64.b64encode(data))
        return (
            f"import marshal,base64,lzma\n"
            f"exec(marshal.loads(base64.b64decode(lzma.decompress({en}))))"
        )

    def m3(self, code):
        data = self._compile_and_dump(code)
        en = lzma.compress(base64.b85encode(data))
        return (
            f"import marshal,base64,lzma\n"
            f"exec(marshal.loads(base64.b85decode(lzma.decompress({en}))))"
        )

    def m4(self, code):
        data = self._compile_and_dump(code)
        en = lzma.compress(data)
        return (
            f"import marshal,lzma\n"
            f"exec(marshal.loads(lzma.decompress({en})))"
        )

    def m5(self, code):
        data = self._compile_and_dump(code)
        en = base64.b64encode(lzma.compress(data))
        return (
            f"import marshal,base64,lzma\n"
            f"exec(marshal.loads(lzma.decompress(base64.b64decode({en}))))"
        )

    def m6(self, code):
        data = self._compile_and_dump(code)
        en = lzma.compress(zlib.compress(data))
        return (
            f"import marshal,zlib,lzma\n"
            f"exec(marshal.loads(zlib.decompress(lzma.decompress({en}))))"
        )

    def m7(self, code):
        data = self._compile_and_dump(code)
        en = lzma.compress(gzip.compress(data))
        return (
            f"import marshal,gzip,lzma\n"
            f"exec(marshal.loads(gzip.decompress(lzma.decompress({en}))))"
        )

    def m8(self, code):
        # Same as m4 but explicitly included for compatibility/variety
        return self.m4(code)

    def m9(self, code):
        data = self._compile_and_dump(code)
        en = base64.b64encode(gzip.compress(data))
        return (
            f"import marshal,base64,gzip\n"
            f"exec(marshal.loads(gzip.decompress(base64.b64decode({en}))))"
        )

    def m10(self, code):
        data = self._compile_and_dump(code)
        # Mix algorithms: Marshal -> Gzip -> Base64 (reversed) -> LZMA -> Base64
        step1 = gzip.compress(data)
        step2 = base64.b64encode(step1)[::-1] # Simple reversal
        step3 = lzma.compress(step2)
        en = base64.b64encode(step3)
        return (
            f"import marshal,base64,gzip,lzma\n"
            f"exec(marshal.loads(gzip.decompress(base64.b64decode(lzma.decompress(base64.b64decode({en})).decode()[::-1].encode()))))"
        )

    def m11(self, code):
        # Complex chain
        data = self._compile_and_dump(code)
        en = base64.b85encode(zlib.compress(base64.b64encode(data)))
        return (
            f"import marshal,base64,zlib\n"
            f"exec(marshal.loads(base64.b64decode(zlib.decompress(base64.b85decode({en})))))"
        )

    def m20(self, code):
        """Minify + Obfuscate"""
        try:
            minified = python_minifier.minify(code)
        except:
            minified = code
        return self.m2(minified)


    # --- Advanced Encryption Methods ---

    def _derive_key(self, password: str, salt: bytes, iterations: int = 200000) -> bytes:
        """Derive a cryptographic key using PBKDF2HMAC (SHA256) with high iterations."""
        return hashlib.pbkdf2_hmac(
            'sha256',
            password.encode(),
            salt,
            iterations
        )

    def _dynamic_block_cipher(self, data: bytes, key: bytes) -> bytes:
        """
        A custom dynamic block cipher.
        1. It uses SHAKE256 to generate a master keystream.
        2. For every 16-byte block, it mutates the key using the block's index and content.
        3. This creates a non-linear dependency where identical blocks encrypt differently.
        """
        encrypted = bytearray()
        block_size = 32
        
        # Initial state derived from key
        state = hashlib.sha256(key).digest()
        
        for i in range(0, len(data), block_size):
            chunk = data[i:i+block_size]
            
            # Generate a unique key for this block based on current state
            block_key_gen = hashlib.shake_256(state + str(i).encode())
            block_key = block_key_gen.digest(len(chunk))
            
            # XOR Encrypt
            encrypted_chunk = bytes(a ^ b for a, b in zip(chunk, block_key))
            encrypted.extend(encrypted_chunk)
            
            # Update state: The new state depends on the previous state AND the encrypted chunk
            # This creates a blockchain-like dependency (Cipher Block Chaining - CBC style but with hashes)
            state = hashlib.sha256(state + encrypted_chunk).digest()
            
        return bytes(encrypted)

    def secure_encrypt(self, code, key=None, iterations=200000):
        """
        Advanced encryption using PBKDF2 key derivation and a Dynamic State Block Cipher.
        The decryption loader is polymorphically generated to resist static signature detection.
        """
        if key is None:
            # Generate a random strong key if none provided
            key = secrets.token_urlsafe(64) # Increased key entropy
        
        salt = secrets.token_bytes(32) # Increased salt size
        derived_key = self._derive_key(key, salt, iterations)
        
        # Compile and marshal first
        payload = self._compile_and_dump(code)
        
        # Encrypt with dynamic block cipher
        encrypted_data = self._dynamic_block_cipher(payload, derived_key)
        
        # Encode for transport
        b64_salt = base64.b85encode(salt).decode()
        b64_data = base64.b85encode(encrypted_data).decode()
        
        # Polymorphic Variable Names
        # We generate random variable names for the loader logic so it looks different every time
        v_key = ''.join(random.choices(string.ascii_letters, k=random.randint(4, 8)))
        v_salt = ''.join(random.choices(string.ascii_letters, k=random.randint(4, 8)))
        v_data = ''.join(random.choices(string.ascii_letters, k=random.randint(4, 8)))
        v_derived = ''.join(random.choices(string.ascii_letters, k=random.randint(4, 8)))
        v_state = ''.join(random.choices(string.ascii_letters, k=random.randint(4, 8)))
        v_decrypted = ''.join(random.choices(string.ascii_letters, k=random.randint(4, 8)))
        v_chunk = ''.join(random.choices(string.ascii_letters, k=random.randint(4, 8)))
        v_i = ''.join(random.choices(string.ascii_letters, k=random.randint(1, 2)))
        v_bk_gen = ''.join(random.choices(string.ascii_letters, k=random.randint(4, 8)))
        v_bk = ''.join(random.choices(string.ascii_letters, k=random.randint(4, 8)))
        
        # Create the polymorphic loader stub
        loader = (
            f"# Encrypted with PyxBlend by PythonToday\n"
            f"import marshal, base64, hashlib\n"
            f"{v_key} = '{key}'\n" 
            f"{v_salt} = base64.b85decode('{b64_salt}')\n"
            f"{v_data} = base64.b85decode('{b64_data}')\n"
            f"{v_derived} = hashlib.pbkdf2_hmac('sha256', {v_key}.encode(), {v_salt}, {iterations})\n"
            f"{v_decrypted} = bytearray()\n"
            f"{v_state} = hashlib.sha256({v_derived}).digest()\n"
            f"for {v_i} in range(0, len({v_data}), 32):\n"
            f"    {v_chunk} = {v_data}[{v_i}:{v_i}+32]\n"
            f"    {v_bk_gen} = hashlib.shake_256({v_state} + str({v_i}).encode())\n"
            f"    {v_bk} = {v_bk_gen}.digest(len({v_chunk}))\n"
            f"    {v_decrypted}.extend(bytes(a ^ b for a, b in zip({v_chunk}, {v_bk})))\n"
            f"    {v_state} = hashlib.sha256({v_state} + {v_chunk}).digest()\n"
            f"exec(marshal.loads({v_decrypted}))"
        )
        
        # Obfuscate the loader itself using m2 (strong compression)
        # This adds another layer: you have to unpack m2 to even see the decryption logic
        return self.m2(loader)

    # --- Utility Methods ---
    
    def encrypt(self, code, method=2):
        """Encrypt/Obfuscate code using a specific method number (1-11, 20)."""
        method_name = f"m{method}"
        if hasattr(self, method_name):
            return getattr(self, method_name)(code)
        else:
            raise ValueError(f"Method m{method} not found.")

    def random_encrypt(self, code, iterations=1):
        """Apply random encoding layers recursively."""
        current_code = code
        for _ in range(iterations):
            method = random.choice(self.layers)
            current_code = method(current_code)
        return current_code

    def gen_payload(self, choice, data):
        """Legacy compatibility wrapper."""
        return self.encrypt(data, method=choice)

    def random_payload(self, data, iterations=1):
        """Legacy compatibility wrapper."""
        return self.random_encrypt(data, iterations=iterations)
