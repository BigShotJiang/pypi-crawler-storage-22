from setuptools import setup, find_packages

setup(
    name='pyxblend',
    version='1.0.1',
    packages=find_packages(),
    author='PythonToday',
    author_email='pythontodayz@gmail.com',
    description='A simple module for advanced Python code encoding.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/PythonTodayz/pyxblend',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Topic :: Security',
        'Topic :: Software Development :: Build Tools',
    ],
    install_requires=[
        'python_minifier',
    ],
    python_requires='>=3.6',
)
