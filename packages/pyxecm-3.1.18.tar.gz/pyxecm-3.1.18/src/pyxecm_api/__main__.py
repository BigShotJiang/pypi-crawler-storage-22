"""Wrapper to start the Customizer API."""

from pyxecm_api import run_api

if __name__ == "__main__":
    run_api()
