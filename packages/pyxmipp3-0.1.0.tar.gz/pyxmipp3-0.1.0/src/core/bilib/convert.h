/*--------------------------------------------------------------------------*/
extern float ConvertDoubleToFloat
    (
        double Argument   /* value to convert */
    );

/*--------------------------------------------------------------------------*/
extern int  ConvertDoubleToInt
    (
        double Argument   /* value to round */
    );

/*--------------------------------------------------------------------------*/
extern long  ConvertDoubleToLong
    (
        double Argument   /* value to round */
    );

/*--------------------------------------------------------------------------*/
extern short ConvertDoubleToShort
    (
        double Argument   /* value to round */
    );

/*--------------------------------------------------------------------------*/
extern int  ConvertFloatToInt
    (
        float Argument   /* value to round */
    );

/*--------------------------------------------------------------------------*/
extern long  ConvertFloatToLong
    (
        float Argument   /* value to round */
    );

/*--------------------------------------------------------------------------*/
extern short ConvertFloatToShort
    (
        float Argument   /* value to round */
    );

/*--------------------------------------------------------------------------*/
extern short ConvertIntToShort
    (
        int  Argument   /* value to convert */
    );

/*--------------------------------------------------------------------------*/
extern int  ConvertLongToInt
    (
        long Argument   /* value to convert */
    );

/*--------------------------------------------------------------------------*/
extern short ConvertLongToShort
    (
        long Argument   /* value to convert */
    );

