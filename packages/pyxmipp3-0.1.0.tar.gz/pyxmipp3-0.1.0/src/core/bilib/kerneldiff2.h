/*--------------------------------------------------------------------------*/
extern int  BlipDiff2
    (
        long Degree,    /* degree */
        double Argument,   /* input */
        double *Result    /* output */
    );

/*--------------------------------------------------------------------------*/
extern double Blip00Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Blip01Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Blip03Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern int  BsplineDiff2
    (
        long Degree,    /* degree */
        double Argument,   /* input */
        double *Result    /* output */
    );

/*--------------------------------------------------------------------------*/
extern double Bspline00Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Bspline01Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Bspline02Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Bspline03Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Bspline04Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Bspline05Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Bspline06Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Bspline07Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Bspline08Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Bspline09Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Bspline10Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Bspline11Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double DodgsonDiff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double German04Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double KeysOptimalDiff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern int  OmomsDiff2
    (
        long Degree,    /* degree */
        double Argument,   /* input */
        double *Result    /* output */
    );

/*--------------------------------------------------------------------------*/
extern double Omoms00Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Omoms01Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Omoms02Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double Omoms03Diff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double PositiveDiff2
    (
        double Argument   /* input */
    );

/*--------------------------------------------------------------------------*/
extern double SincDiff2
    (
        double Argument   /* input */
    );

