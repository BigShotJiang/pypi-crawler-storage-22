#include <stdio.h>

extern int MessageDisplay(const char *_str) {
   printf("%s\n",_str);
   return 0;
}

