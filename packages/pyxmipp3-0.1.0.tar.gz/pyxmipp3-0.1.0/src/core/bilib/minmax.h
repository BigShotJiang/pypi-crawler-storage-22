/*--------------------------------------------------------------------------*/
extern double MaxDouble
    (
        double Argument1,   /* first argument */
        double Argument2   /* second argument */
    );

/*--------------------------------------------------------------------------*/
extern float MaxFloat
    (
        float Argument1,   /* first argument */
        float Argument2   /* second argument */
    );

/*--------------------------------------------------------------------------*/
extern int  MaxInt
    (
        int  Argument1,   /* first argument */
        int  Argument2   /* second argument */
    );

/*--------------------------------------------------------------------------*/
extern long  MaxLong
    (
        long Argument1,   /* first argument */
        long Argument2   /* second argument */
    );

/*--------------------------------------------------------------------------*/
extern short MaxShort
    (
        short Argument1,   /* first argument */
        short Argument2   /* second argument */
    );

/*--------------------------------------------------------------------------*/
extern double MinDouble
    (
        double Argument1,   /* first argument */
        double Argument2   /* second argument */
    );

/*--------------------------------------------------------------------------*/
extern float MinFloat
    (
        float Argument1,   /* first argument */
        float Argument2   /* second argument */
    );

/*--------------------------------------------------------------------------*/
extern int  MinInt
    (
        int  Argument1,   /* first argument */
        int  Argument2   /* second argument */
    );

/*--------------------------------------------------------------------------*/
extern long  MinLong
    (
        long Argument1,   /* first argument */
        long Argument2   /* second argument */
    );

/*--------------------------------------------------------------------------*/
extern short MinShort
    (
        short Argument1,   /* first argument */
        short Argument2   /* second argument */
    );

