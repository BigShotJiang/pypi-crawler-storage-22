/*--------------------------------------------------------------------------*/
extern double RoundDoubleToDouble
    (
        double Argument   /* value to round */
    );

/*--------------------------------------------------------------------------*/
extern float RoundDoubleToFloat
    (
        double Argument   /* value to round */
    );

/*--------------------------------------------------------------------------*/
extern float RoundFloatToFloat
    (
        float Argument   /* value to round */
    );

