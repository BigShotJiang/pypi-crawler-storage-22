/*--------------------------------------------------------------------------*/
extern int  FirstIndex3DLine6Connected
    (
        struct TTraceLine
        *LineData   /* line description */
    );

/*--------------------------------------------------------------------------*/
extern int  NextIndex3DLine6Connected
    (
        struct TTraceLine
        *LineData   /* line description */
    );

