from src.pyznuny.ticket.create import main


def test_main():
    

    main(" Test")
    # Verifica se a funcao main pode ser chamada sem erros
    assert True