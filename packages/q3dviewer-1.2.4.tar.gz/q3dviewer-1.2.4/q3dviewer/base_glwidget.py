"""
Copyright 2024 Panasonic Advanced Technology Development Co.,Ltd. (Liu Yang)
Distributed under MIT license. See LICENSE for more information.
"""

from OpenGL.GL import *
from math import radians, tan
import numpy as np
from q3dviewer.Qt import QtCore, QtGui
from q3dviewer.utils.maths import frustum, euler_to_matrix, makeT
from q3dviewer.Qt.QtWidgets import QOpenGLWidget


class BaseGLWidget(QOpenGLWidget):
    def __init__(self, parent=None):
        QOpenGLWidget.__init__(self, parent)
        self.setFocusPolicy(QtCore.Qt.FocusPolicy.ClickFocus)
        self.reset()
        self._fov = 60
        self.items = []
        self.keyTimer = QtCore.QTimer()
        self.color = np.array([0, 0, 0, 0])
        self.dist = 40
        self.euler = np.array([np.pi/3, 0, np.pi/4])
        self.center = np.array([0, 0, 0.])
        self.active_keys = set()
        self.show_center = False
        self.enable_show_center = True
        self.need_recalc_view = True
        self.view_matrix = self.get_view_matrix()
        self.projection_matrix = self.get_projection_matrix()

    def keyPressEvent(self, ev: QtGui.QKeyEvent):
        if ev.key() == QtCore.Qt.Key_Up or  \
            ev.key() == QtCore.Qt.Key_Down or \
            ev.key() == QtCore.Qt.Key_Left or \
            ev.key() == QtCore.Qt.Key_Right or \
            ev.key() == QtCore.Qt.Key_Z or \
            ev.key() == QtCore.Qt.Key_X or \
            ev.key() == QtCore.Qt.Key_A or \
            ev.key() == QtCore.Qt.Key_D or \
            ev.key() == QtCore.Qt.Key_W or \
            ev.key() == QtCore.Qt.Key_S:
            self.active_keys.add(ev.key())
        self.active_keys.add(ev.key())

    def keyReleaseEvent(self, ev: QtGui.QKeyEvent):
        self.active_keys.discard(ev.key())

    def current_width(self):
        """
        Return the current width of the widget.
        """
        return int(self.width() * self.devicePixelRatioF())

    def current_height(self):
        """
        Return the current height of the widget.
        """
        return int(self.height() * self.devicePixelRatioF())

    def reset(self):
        pass

    def add_item(self, item):
        """
        Add the item to the glwidget.
        """
        self.items.append(item)
        item.set_glwidget(self)
        
    def remove_item(self, item):
        """
        Remove the item from the glwidget.
        """
        self.items.remove(item)
        item.set_glwidget(None)

    def clear(self):
        """
        Remove all items from the glwidget.
        """
        for item in self.items:
            item.set_glwidget(None)
        self.items = []
        
    def initializeGL(self):
        """
        the method is herted from QOpenGLWidget, 
        and it is called when the widget is first shown.
        """
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LESS)
        
        for item in self.items:
            item.initialize()
        # initialize the projection matrix and model view matrix
        self.projection_matrix = self.get_projection_matrix()
        self.update_model_projection()
        self.view_matrix = self.get_view_matrix()
        self.update_model_view()

    def set_view_matrix(self, view_matrix):
        self.view_matrix = view_matrix
        self.need_recalc_view = False

    def mouseReleaseEvent(self, ev):
        if hasattr(self, 'mousePos'):
            delattr(self, 'mousePos')

    def set_dist(self, dist):
        self.dist = dist
        self.need_recalc_view = True

    def update_dist(self, delta):
        self.dist += delta
        if self.dist < 0.1:
            self.dist = 0.1
        self.need_recalc_view = True

    def wheelEvent(self, ev):
        delta = ev.angleDelta().x()
        if delta == 0:
            delta = ev.angleDelta().y()
        self.update_dist(-delta * self.dist * 0.001)
        self.show_center = True


    def rotate_keep_cam_pos(self, rx=0, ry=0, rz=0):
        """
        Rotate the camera while keeping the current camera position. 
        This updates both the Euler angles and the center point.
        """
        new_euler = self.euler + np.array([rx, ry, rz])
        new_euler = (new_euler + np.pi) % (2 * np.pi) - np.pi
        
        Rwc_old = euler_to_matrix(self.euler)
        tco = np.array([0, 0, self.dist])
        twc = self.center + Rwc_old @ tco
        
        Rwc_new = euler_to_matrix(new_euler)
        self.center = twc - Rwc_new @ tco
        self.euler = new_euler
        self.need_recalc_view = True

    def mouseMoveEvent(self, ev):
        lpos = ev.localPos()
        if not hasattr(self, 'mousePos'):
            self.mousePos = lpos
        diff = lpos - self.mousePos
        self.mousePos = lpos
        if ev.buttons() == QtCore.Qt.MouseButton.RightButton:
            rot_speed = 0.2
            dyaw = radians(-diff.x() * rot_speed)
            droll = radians(-diff.y() * rot_speed)
            if ev.modifiers() & QtCore.Qt.ShiftModifier:
                self.rotate_keep_cam_pos(droll, 0, dyaw)
            else:
                self.rotate(droll, 0, dyaw)
        elif ev.buttons() == QtCore.Qt.MouseButton.LeftButton:
            Rwc = euler_to_matrix(self.euler)
            Kinv = np.linalg.inv(self.get_K())
            dist = max(self.dist, 0.5)
            self.translate(Rwc @ Kinv @ np.array([-diff.x(), diff.y(), 0]) * dist)
        self.show_center = True

    def set_center(self, center):
        self.center = center
        self.need_recalc_view = True

    def paintGL(self):
        # if the camera is moved, update the model view matrix.
        if self.need_recalc_view:
            self.view_matrix = self.get_view_matrix()
            self.need_recalc_view = False
        self.update_model_view()

        # set the background color
        bgcolor = self.color
        glClearColor(*bgcolor)
        glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT)
        for item in self.items:
            if not item.visible():
                continue
            if not item.is_initialized():
                """
                The item may not be initialized if it is added
                after the widget is shown, so we need to initialize it here.
                """
                item.initialize()
            glMatrixMode(GL_MODELVIEW)
            glPushMatrix()
            glPushAttrib(GL_ALL_ATTRIB_BITS)
            try:
                item.paint()
            finally:
                glPopAttrib()
                glMatrixMode(GL_MODELVIEW)
                glPopMatrix()
        
        # Show center as a point if updated by mouse move event
        if self.enable_show_center and self.show_center:
            point_size = np.clip((self.get_K()[0, 0] / self.dist), 10, 100)
            glPointSize(point_size)
            glBegin(GL_POINTS)
            glColor3f(1.0, 0.0, 0.0)  # Red color for the center point
            glVertex3f(*self.center)
            glEnd()
            self.show_center = False
    
    def update_movement(self):
        """
        Update the movement of the camera based on the active keys.
        """
        if not self.active_keys:
            return
        rot_speed = 0.5
        trans_speed = max(self.dist * 0.005, 0.1)
        shift_pressed = QtCore.Qt.Key_Shift in self.active_keys
        # Handle rotation keys
        if QtCore.Qt.Key_Up in self.active_keys:
            if shift_pressed:
                self.rotate_keep_cam_pos(radians(rot_speed), 0, 0)
            else:
                self.rotate(radians(rot_speed), 0, 0)
        if QtCore.Qt.Key_Down in self.active_keys:
            if shift_pressed:
                self.rotate_keep_cam_pos(radians(-rot_speed), 0, 0)
            else:
                self.rotate(radians(-rot_speed), 0, 0)
        if QtCore.Qt.Key_Left in self.active_keys:
            if shift_pressed:
                self.rotate_keep_cam_pos(0, 0, radians(rot_speed))
            else:
                self.rotate(0, 0, radians(rot_speed))
        if QtCore.Qt.Key_Right in self.active_keys:
            if shift_pressed:
                self.rotate_keep_cam_pos(0, 0, radians(-rot_speed))
            else:
                self.rotate(0, 0, radians(-rot_speed))
        # Handle zoom keys
        xz_keys = {QtCore.Qt.Key_Z, QtCore.Qt.Key_X}
        if self.active_keys & xz_keys:
            Rwc = euler_to_matrix(self.euler)
            if QtCore.Qt.Key_Z in self.active_keys:
                self.translate(Rwc @ np.array([0, 0, -trans_speed]))
            if QtCore.Qt.Key_X in self.active_keys:
                self.translate(Rwc @ np.array([0, 0, trans_speed]))
        # Handle translation keys on the z plane
        dir_keys = {QtCore.Qt.Key_W, QtCore.Qt.Key_S, QtCore.Qt.Key_A, QtCore.Qt.Key_D}
        if self.active_keys & dir_keys:
            Rz = euler_to_matrix([0, 0, self.euler[2]])
            if QtCore.Qt.Key_W in self.active_keys:
                self.translate(Rz @ np.array([0, trans_speed, 0]))
            if QtCore.Qt.Key_S in self.active_keys:
                self.translate(Rz @ np.array([0, -trans_speed, 0]))
            if QtCore.Qt.Key_A in self.active_keys:
                self.translate(Rz @ np.array([-trans_speed, 0, 0]))
            if QtCore.Qt.Key_D in self.active_keys:
                self.translate(Rz @ np.array([trans_speed, 0, 0]))

    def update_model_view(self):
        glMatrixMode(GL_MODELVIEW)
        glLoadMatrixf(self.view_matrix.T)
        
    def get_view_matrix(self):
        two = self.center # the origin(center) in the world frame
        tco = np.array([0, 0, self.dist]) # the origin(center) in camera frame
        Rwc = euler_to_matrix(self.euler)
        twc = two + Rwc @ tco
        Rcw = Rwc.T
        tcw = -Rcw @ twc
        Tcw = makeT(Rcw, tcw)
        return Tcw

    def set_cam_position(self, **kwargs):
        center = kwargs.get('center', None)
        distance = kwargs.get('distance', None)
        euler = kwargs.get('euler', None)
        if center is not None:
            self.set_center(center)
        if distance is not None:
            self.set_dist(distance)
        if euler is not None:
            self.set_euler(euler)
    
    def set_euler(self, euler):
        self.euler = euler
        self.need_recalc_view = True

    def set_color(self, color):
        self.color = color

    def update(self):
        self.update_movement()
        super().update()

    def update_model_projection(self):
        glMatrixMode(GL_PROJECTION)
        glLoadMatrixf(self.projection_matrix.T)

    def get_projection_matrix(self):
        w, h = self.current_width(), self.current_height()
        dist = self.dist
        near = dist * 0.001
        far = dist * 10000.
        r = near * tan(0.5 * radians(self._fov))
        t = r * h / max(w, 1)
        matrix = frustum(-r, r, -t, t, near, far)
        return matrix

    def get_K(self):
        project_matrix = self.get_projection_matrix()
        width = self.current_width()
        height = self.current_height()
        fx = project_matrix[0, 0] * width / 2
        fy = project_matrix[1, 1] * height / 2
        cx = width / 2
        cy = height / 2
        K = np.array([
            [fx, 0, cx],
            [0, fy, cy],
            [0, 0, 1]
        ])
        return K
            
    def rotate(self, rx=0, ry=0, rz=0):
        # update the euler angles
        self.euler += np.array([rx, ry, rz])
        self.euler[2] = (self.euler[2] + np.pi) % (2 * np.pi) - np.pi
        self.euler[1] = (self.euler[1] + np.pi) % (2 * np.pi) - np.pi
        self.euler[0] = np.clip(self.euler[0], 0, np.pi)
        self.need_recalc_view = True

    def translate(self, trans):
        self.center += trans
        self.need_recalc_view = True

    def change_show_center(self, state):
        self.enable_show_center = state

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.projection_matrix = self.get_projection_matrix()
        self.update_model_projection()

    def capture_frame(self):
        self.makeCurrent()  # Ensure the OpenGL context is current
        width = self.current_width()
        height = self.current_height()
        pixels = glReadPixels(0, 0, width, height, GL_RGB, GL_UNSIGNED_BYTE)
        frame = np.frombuffer(pixels, dtype=np.uint8).reshape(height, width, 3)
        frame = np.flip(frame, 0)
        return frame
    
    def depth_to_meters(self, depth_buffer):
        """
        Convert normalized depth buffer values [0,1] to actual distances in meters.
        
        Args:
            depth_buffer: numpy array with depth values in range [0,1]
            
        Returns:
            numpy array with distances in meters
        """
        # Get near and far clipping planes
        near = self.dist * 0.001
        far = self.dist * 10000.
        
        # Convert from normalized depth [0,1] to linear depth in meters
        # OpenGL depth buffer formula: depth = (1/z - 1/near) / (1/far - 1/near)
        # Solving for z: z = 1 / (depth * (1/far - 1/near) + 1/near)
        
        # Avoid division by zero for depth = 1.0 (far plane)
        depth_clamped = np.clip(depth_buffer, 0.0, 0.999999)
        
        linear_depth = 1.0 / (depth_clamped * (1.0/far - 1.0/near) + 1.0/near)
        
        return linear_depth


    def get_point(self, x0, y0, radius=5):
        """
        Get the 3D point in world coordinates corresponding to the given
        screen coordinates (x0, y0). It searches within a radius around the
        given pixel to find a valid depth value.
        """
        self.makeCurrent()  # Ensure the OpenGL context is current
        width = self.current_width()
        height = self.current_height()  

        # Scale mouse coordinates by device pixel ratio for PySide6 compatibility
        pixel_ratio = self.devicePixelRatioF()

        points = []
        for dx in range(-radius, radius + 1):
            for dy in range(-radius, radius + 1):
                if dx * dx + dy * dy <= radius * radius:
                    points.append((x0 + dx, y0 + dy))
        points = sorted(points, key=lambda p: (p[0]-x0)**2 + (p[1]-y0)**2)

        gl_y0 = height - y0 - 1
        z = 1.0
        for x, y in points:
            x = int(x * pixel_ratio)
            y = int(y * pixel_ratio)

            gl_y = height - y - 1
            z = glReadPixels(x, gl_y, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT)
            z = np.frombuffer(z, dtype=np.float32)[0]
            if z != 1.0 and z != 0.0:
                break

        if z == 1.0 or z == 0.0:
            return None

        # Retrieve OpenGL matrices (column-major), convert to numpy arrays and transpose
        view = np.array(glGetFloatv(GL_MODELVIEW_MATRIX), dtype=np.float32).reshape((4,4)).T
        proj = np.array(glGetFloatv(GL_PROJECTION_MATRIX), dtype=np.float32).reshape((4,4)).T   

        # Convert screen (x, y, z) to normalized device coordinates (NDC)
        ndc_x = (x0 / width) * 2.0 - 1.0
        ndc_y = (gl_y0 / height) * 2.0 - 1.0
        ndc_z = 2.0 * z - 1.0
        ndc = np.array([ndc_x, ndc_y, ndc_z, 1.0], dtype=np.float32)    

        inv_projview = np.linalg.inv(proj @ view)
        world_p = inv_projview @ ndc
        world_p /= world_p[3]
        return world_p[:3]
