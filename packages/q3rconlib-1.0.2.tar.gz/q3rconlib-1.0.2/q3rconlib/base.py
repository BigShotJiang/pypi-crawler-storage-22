# mypy: disable-error-code="attr-defined"

import logging
import socket

from .error import Q3RconLibLoginError
from .packet import Request, Response

logger = logging.getLogger(__name__)


class Base:
    def __init__(self, **kwargs):
        self.logger = logger.getChild(self.__class__.__name__)
        defaultkwargs = {
            'host': 'localhost',
            'port': 28960,
            'password': '',
            'default_timeout': 0.05,
            'timeouts': {},
        }
        kwargs = defaultkwargs | kwargs
        for attr, val in kwargs.items():
            setattr(self, attr, val)

        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    def send(self, cmd: str) -> str:
        """send a rcon command to the server

        Args:
            cmd (str): command string that takes the form "<cmd> <args>"

        Returns:
            str: the entire command response (all fragments) as one string
        """
        timeout: float = self.timeouts.get(
            cmd.split(' ', maxsplit=1)[0], self.default_timeout
        )
        self._sock.settimeout(timeout)

        try:
            self._sock.sendto(
                Request.from_credentials(self.password).to_bytes(cmd),
                (socket.gethostbyname(self.host), self.port),
            )
            self.logger.debug(f'sending: {cmd}')
        except socket.gaierror:
            raise Q3RconLibLoginError(f"unable to resolve host '{self.host}'")

        fragments: list[str] = []
        try:
            while resp := self._sock.recv(2048):
                try:
                    resp_str = Response.from_bytes(resp)
                    self.logger.debug(f'received fragment: {resp_str!r}')
                    fragments.append(resp_str)
                except ValueError:
                    self.logger.debug('received invalid response fragment, ignoring')
        except TimeoutError:
            self.logger.debug('finished collecting response fragments')

        return ''.join(fragments)

    def close(self):
        self._sock.close()
