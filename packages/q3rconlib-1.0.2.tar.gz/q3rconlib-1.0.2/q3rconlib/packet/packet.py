"""Packet classes for handling Quake3 RCON protocol communication."""


class Packet:
    """Base packet class for Quake3 RCON protocol."""

    MAGIC = b'\xff\xff\xff\xff'

    def __init__(self) -> None:
        """Initialize a packet instance."""
        pass


class Request(Packet):
    """RCON request packet for sending commands to the server."""

    def __init__(self, password: str) -> None:
        """Initialize a request packet with password and command.

        Args:
            password: RCON password for authentication
            command: Command to send to the server
        """
        super().__init__()
        self.password = password

    def to_bytes(self, command: str) -> bytes:
        """Convert the request to bytes for transmission.

        Returns:
            Byte representation of the RCON request
        """
        return self.MAGIC + f'rcon {self.password} {command}\n'.encode()

    @classmethod
    def from_credentials(cls, password: str) -> 'Request':
        """Create a request packet from password.

        Args:
            password: RCON password for authentication

        Returns:
            New Request instance
        """
        return cls(password)


class Response(Packet):
    """RCON response packet for handling server responses."""

    def __init__(self) -> None:
        """Initialize a response packet."""
        super().__init__()
        self._header = self.MAGIC + b'print\n'

    @property
    def header(self) -> bytes:
        """Get the response header bytes.

        Returns:
            Header bytes for RCON responses
        """
        return self._header

    @classmethod
    def from_bytes(cls, data: bytes) -> str:
        """Create a response packet from bytes.

        Args:
            data: Byte data received from the server
        Returns:
            Decoded response string without header
        """
        instance = cls()
        if not data.startswith(instance.header):
            raise ValueError('Invalid response header')
        return data.removeprefix(instance.header).decode()
