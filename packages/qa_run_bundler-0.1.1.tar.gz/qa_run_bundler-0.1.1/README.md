# qa-run-bundler

Create a **self-contained QA run bundle** (ZIP + `index.html` viewer) from automation artifacts.

- Package: `qa-run-bundler`
- CLI: `qa-bundle`
- Also includes a pytest plugin (`--qa-bundle`).

## Goals
- **No Allure dependency**: viewer is standalone and works via `file://` by default.
- Still compatible with Allure: you can attach the bundle ZIP / link to the HTML if you want.
- **No overwrite**: each run is written under a timestamped run folder.

## Install (dev)
```bash
pip install -e .
```

## CLI usage
Build a bundle from an existing run folder:
```bash
qa-bundle build --root test_report/<project>/<env>/runs/<run_id>
```

Output (default):
- `<root>/qa_bundle/index.html`
- `<root>/qa_bundle/bundle.zip`

## Pytest plugin
By default this plugin is **ON**.

Disable via env (recommended for IDE users):
```bash
export QA_BUNDLE=0
```

Or disable via CLI:
```bash
pytest --no-qa-bundle
```

Explicit enable (optional):
```bash
pytest --qa-bundle --project consumer_website --env dev --test-env qa
```

The plugin will create:
`test_report/<project>/<env>/<test_env>/runs/<run_id>/qa_bundle/...` (non-prod)
`test_report/<project>/prod/runs/<run_id>/qa_bundle/...` (prod)

## Notes
This is v0.1.0 scaffolding focused on **bundling + viewer**. Playwright-specific auto capture hooks (trace/video/HAR) can be layered on top by pointing artifacts into the run folder.
