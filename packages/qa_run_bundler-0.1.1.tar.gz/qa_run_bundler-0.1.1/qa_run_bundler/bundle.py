from __future__ import annotations

import json
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .utils import atomic_write, read_json


@dataclass
class BundleResult:
    report_dir: Path
    index_html: Path
    bundle_zip: Path


def _escape_inline_script_json(text: str) -> str:
    return text.replace("</script>", "<\\/script>")


def _load_viewer_template() -> str:
    here = Path(__file__).resolve().parent
    tpl = here / "viewer" / "template.html"
    return tpl.read_text(encoding="utf-8")


def _inject_embedded_payload(html: str, payload_obj: dict[str, Any]) -> str:
    payload = "\n<script id=\"qa_bundle_data\" type=\"application/json\">" + _escape_inline_script_json(
        json.dumps(payload_obj, separators=(",", ":"))
    ) + "</script>\n"
    if "</body>" in html:
        return html.replace("</body>", payload + "</body>")
    return html + payload


def build_bundle(root: Path, *, out_dir: Path | None = None, zip_limit_bytes: int = 1_000_000_000) -> BundleResult:
    root = root.resolve()
    report_dir = (out_dir or (root / "qa_bundle")).resolve()
    report_dir.mkdir(parents=True, exist_ok=True)

    manifest = read_json(root / "qa_bundle" / "manifest.json", {})
    if not manifest:
        # Try to generate minimal manifest from root structure
        manifest = {
            "schema": "qa-run-bundle-manifest/v1",
            "root": str(root),
            "project": manifest.get("project") if isinstance(manifest, dict) else None,
        }

    tests = read_json(root / "qa_bundle" / "tests.json", [])

    embedded = {
        "schema": "qa-run-bundle-embedded/v1",
        "manifest": manifest,
        "tests": tests,
    }

    viewer_html = _inject_embedded_payload(_load_viewer_template(), embedded)
    index_html = report_dir / "index.html"
    atomic_write(index_html, viewer_html)

    # Build ZIP
    bundle_zip = report_dir / "bundle.zip"
    with zipfile.ZipFile(bundle_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        # Always include viewer
        z.write(index_html, arcname="index.html")

        # Include common artifacts if present
        for rel in [
            "allure-results",
            "screenshots",
            "videos",
            "network",
            "traces",
            "logs",
        ]:
            p = root / rel
            if not p.exists():
                continue
            for f in p.rglob("*"):
                if f.is_dir():
                    continue
                arc = str(Path(rel) / f.relative_to(p))
                z.write(f, arcname=arc)

        # Include metadata
        atomic_write(report_dir / "manifest.json", json.dumps(manifest, indent=2))
        atomic_write(report_dir / "tests.json", json.dumps(tests, indent=2))
        z.write(report_dir / "manifest.json", arcname="manifest.json")
        z.write(report_dir / "tests.json", arcname="tests.json")

    # Size guard
    if bundle_zip.stat().st_size > zip_limit_bytes:
        # Leave report_dir intact; user can zip manually.
        raise RuntimeError(f"bundle.zip exceeds limit: {bundle_zip.stat().st_size} bytes")

    return BundleResult(report_dir=report_dir, index_html=index_html, bundle_zip=bundle_zip)
