from __future__ import annotations

import argparse
from pathlib import Path

from .bundle import build_bundle


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="qa-bundle")
    sub = ap.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("build", help="Build a QA bundle report + zip from a run root")
    b.add_argument("--root", required=True, help="Run root folder (contains screenshots/videos/network/etc)")
    b.add_argument("--out", default="", help="Output dir (default: <root>/qa_bundle)")
    b.add_argument("--zip-limit-mb", type=int, default=1024, help="ZIP size limit in MB (default: 1024)")

    ns = ap.parse_args(argv)

    if ns.cmd == "build":
        root = Path(ns.root)
        out = Path(ns.out) if ns.out else None
        res = build_bundle(root, out_dir=out, zip_limit_bytes=int(ns.zip_limit_mb) * 1024 * 1024)
        print(str(res.report_dir))
        print(str(res.bundle_zip))
        return 0

    raise SystemExit(2)
