from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
import uuid


@dataclass(frozen=True)
class RunContext:
    project: str
    env: str
    test_env: str | None
    run_id: str
    run_root: Path


def default_run_id() -> str:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"run_{ts}_{uuid.uuid4().hex[:8]}"


def compute_run_root(*, project: str, env: str, test_env: str | None, run_id: str) -> Path:
    # Requirement: prod/runs (no test_env segment)
    if env.lower() == "prod":
        return Path("test_report") / project / "prod" / "runs" / run_id

    # non-prod: include test_env if present
    if test_env:
        return Path("test_report") / project / env / test_env / "runs" / run_id

    return Path("test_report") / project / env / "runs" / run_id


def current_context(run_id: str | None = None) -> RunContext:
    project = os.getenv("PROJECT_NAME") or os.getenv("PROJECT") or "default"
    env = (os.getenv("ENV") or "dev").lower()
    test_env = (os.getenv("TEST_ENV") or "").lower().strip() or None
    rid = run_id or os.getenv("QA_RUN_ID") or default_run_id()
    root = compute_run_root(project=project, env=env, test_env=test_env, run_id=rid)
    return RunContext(project=project, env=env, test_env=test_env, run_id=rid, run_root=root)
