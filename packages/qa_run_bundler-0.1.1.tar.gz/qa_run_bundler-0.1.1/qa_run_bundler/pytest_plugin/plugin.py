from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from qa_run_bundler.bundle import build_bundle
from qa_run_bundler.paths import current_context
from qa_run_bundler.utils import atomic_write


def pytest_addoption(parser: pytest.Parser) -> None:
    g = parser.getgroup("qa-run-bundler")
    g.addoption(
        "--qa-bundle",
        action="store_true",
        help="Enable QA bundle generation (index.html + zip) after run (default: enabled)",
    )
    g.addoption(
        "--no-qa-bundle",
        action="store_true",
        help="Disable QA bundle generation",
    )
    g.addoption("--project", action="store", default="", help="Project name (used in test_report/<project>/...) ")


def _is_enabled(config: pytest.Config) -> bool:
    import os

    # Highest priority: explicit disable
    if config.getoption("--no-qa-bundle"):
        return False

    # Env toggle (intended for .env usage)
    v = (os.getenv("QA_BUNDLE") or "").strip().lower()
    if v in {"0", "false", "no", "off"}:
        return False
    if v in {"1", "true", "yes", "on"}:
        return True

    # CLI enable flag (optional; default is ON anyway)
    if config.getoption("--qa-bundle"):
        return True

    # Default: ON
    return True


def pytest_configure(config: pytest.Config) -> None:
    if not _is_enabled(config):
        return

    proj = config.getoption("--project") or None
    if proj:
        import os

        os.environ.setdefault("PROJECT_NAME", proj)

    ctx = current_context()
    ctx.run_root.mkdir(parents=True, exist_ok=True)

    # Store ctx for later
    config._qa_run_bundler_ctx = ctx  # type: ignore[attr-defined]
    config._qa_run_bundler_tests = []  # type: ignore[attr-defined]


def pytest_runtest_logreport(report: pytest.TestReport) -> None:
    config = report.config  # type: ignore[attr-defined]
    if not getattr(config, "_qa_run_bundler_tests", None):
        return

    if report.when != "call":
        return

    status = "passed" if report.passed else "failed" if report.failed else "skipped"
    config._qa_run_bundler_tests.append(
        {
            "nodeid": report.nodeid,
            "status": status,
            "duration_ms": int((report.duration or 0.0) * 1000),
        }
    )


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    config = session.config
    if not _is_enabled(config):
        return

    ctx = getattr(config, "_qa_run_bundler_ctx", None)
    tests = getattr(config, "_qa_run_bundler_tests", [])
    if not ctx:
        return

    qa_dir = ctx.run_root / "qa_bundle"
    qa_dir.mkdir(parents=True, exist_ok=True)

    manifest: dict[str, Any] = {
        "schema": "qa-run-bundle-manifest/v1",
        "project": ctx.project,
        "env": ctx.env,
        "test_env": ctx.test_env,
        "run_id": ctx.run_id,
        "run_root": str(ctx.run_root),
    }

    atomic_write(qa_dir / "manifest.json", json.dumps(manifest, indent=2))
    atomic_write(qa_dir / "tests.json", json.dumps(tests, indent=2))

    # Build embedded viewer + zip under qa_bundle/
    build_bundle(ctx.run_root, out_dir=qa_dir, zip_limit_bytes=1_000_000_000)
