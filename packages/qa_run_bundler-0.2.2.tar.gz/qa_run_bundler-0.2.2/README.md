# qa-run-bundler

Create a **self-contained QA run bundle** (**ZIP + `index.html` viewer**) from automation artifacts.

- PyPI: `qa-run-bundler`
- CLI: `qa-bundle`
- Includes a pytest plugin (AUTO-ON by default)

## What it does today (v0.2.0)
This release adds **Playwright auto-capture** (pytest-playwright).

It:
- creates a timestamped run folder under `test_report/.../runs/<run_id>/`
- writes a standalone viewer: `<run_root>/qa_bundle/index.html` (**works on `file://` by default**)
- generates `<run_root>/qa_bundle/bundle.zip` (size limit **1GB**)
- records a **basic test summary** (nodeid/status/duration)

### Auto-captured (Playwright)
Enabled by default (can be disabled via env/CLI flags):
- ✅ **Video** recording (Playwright page video)
- ✅ **HAR** network recording (`network/network.har`, with `content=embed`)
- ✅ **Console logs** capture (`tests/<test>/logs/console.log`)
- ✅ **Trace** capture (`tests/<test>/traces/trace.zip`)
- ✅ **Screenshot on failure** (`tests/<test>/screenshot_failed.png`)

### Disable via .env
```env
QA_BUNDLE=0
# or individual toggles
QA_VIDEO=0
QA_HAR=0
QA_TRACE=0
QA_CONSOLE=0
QA_SCREENSHOT_ON_FAIL=0
```

---

## Requirements / Scope
- **Python + Playwright only** (pytest-based).
- This package is intended for **Playwright UI automation** runs and will not capture Selenium/Appium by default.

## Install
```bash
pip install qa-run-bundler
```

## CLI usage (non-pytest users)
```bash
qa-bundle build --root test_report/<project>/<env>/runs/<run_id>
```

Output:
- `<root>/qa_bundle/index.html`
- `<root>/qa_bundle/bundle.zip`

## Pytest plugin (AUTO-ON)
This plugin runs even when you click **PyCharm Play**.

### Disable via .env / env var
```bash
QA_BUNDLE=0
```

or
```bash
pytest --no-qa-bundle
```

### Recommend env vars (to control output path)
```bash
PROJECT_NAME=consumer_website
ENV=dev
TEST_ENV=qa
```

### Output paths
- **Prod**: `test_report/<project>/prod/runs/<run_id>/...` (no `TEST_ENV` segment)
- **Non-prod**:
  - with `TEST_ENV`: `test_report/<project>/<env>/<test_env>/runs/<run_id>/...`
  - without `TEST_ENV`: `test_report/<project>/<env>/runs/<run_id>/...`

---

## Planned features (recommended next)
If you want, I’ll add these in the next versions:
1) **Playwright auto-capture** (pytest-playwright integration):
   - trace.zip per test
   - video per test
   - screenshots on failure
   - network capture (HAR) + optional response bodies (size-capped)
2) **Viewer upgrades**:
   - filters (failed-only / search / slow tests)
   - per-test attachments UI (open video/trace/logs directly)
   - network table view with cURL copy
3) **Console log capture**:
   - Playwright page console + page errors into `logs/console.log`
