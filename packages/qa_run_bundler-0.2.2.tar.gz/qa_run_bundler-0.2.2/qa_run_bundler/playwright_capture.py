from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass
class PWPaths:
    test_dir: Path
    video_dir: Path
    traces_dir: Path
    network_dir: Path
    logs_dir: Path

    @property
    def trace_zip(self) -> Path:
        return self.traces_dir / "trace.zip"

    @property
    def har_path(self) -> Path:
        return self.network_dir / "network.har"

    @property
    def console_log(self) -> Path:
        return self.logs_dir / "console.log"


def ensure_test_dirs(test_dir: Path) -> PWPaths:
    test_dir.mkdir(parents=True, exist_ok=True)
    video_dir = test_dir / "videos"
    traces_dir = test_dir / "traces"
    network_dir = test_dir / "network"
    logs_dir = test_dir / "logs"
    for d in (video_dir, traces_dir, network_dir, logs_dir):
        d.mkdir(parents=True, exist_ok=True)
    return PWPaths(test_dir=test_dir, video_dir=video_dir, traces_dir=traces_dir, network_dir=network_dir, logs_dir=logs_dir)


def safe_filename(name: str, max_len: int = 160) -> str:
    import re

    s = re.sub(r"[^A-Za-z0-9_.-]+", "_", name).strip("_")
    if len(s) > max_len:
        s = s[:max_len]
    return s or "test"


def add_console_listeners(page, out_path: Path) -> None:
    """Attach Playwright page console/pageerror listeners.

    We keep it lightweight: one combined log file per test.
    """

    def _write(line: str) -> None:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with out_path.open("a", encoding="utf-8") as f:
            f.write(line + "\n")

    page.on(
        "console",
        lambda msg: _write(f"[{msg.type}] {msg.text}"),
    )
    page.on(
        "pageerror",
        lambda err: _write(f"[pageerror] {err}"),
    )


async def start_tracing(context, *, title: str) -> None:
    try:
        await context.tracing.start(screenshots=True, snapshots=True, sources=True, title=title)
    except Exception:
        # tracing not supported or already started
        return


async def stop_tracing(context, *, path: Path) -> None:
    try:
        await context.tracing.stop(path=path)
    except Exception:
        return


def maybe_pick_video_file(video_dir: Path) -> Optional[Path]:
    # Playwright stores videos as .webm by default; there may be multiple.
    cands = list(video_dir.rglob("*.webm")) + list(video_dir.rglob("*.mp4"))
    if not cands:
        return None
    cands.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return cands[0]
