from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

import pytest

from qa_run_bundler.bundle import build_bundle
from qa_run_bundler.paths import current_context
from qa_run_bundler.playwright_capture import add_console_listeners, ensure_test_dirs, safe_filename
from qa_run_bundler.utils import atomic_write


def pytest_addoption(parser: pytest.Parser) -> None:
    g = parser.getgroup("qa-run-bundler")
    g.addoption(
        "--qa-bundle",
        action="store_true",
        help="Enable QA bundle generation (index.html + zip) after run (default: enabled)",
    )
    g.addoption(
        "--no-qa-bundle",
        action="store_true",
        help="Disable QA bundle generation",
    )
    g.addoption("--project", action="store", default="", help="Project name (used in test_report/<project>/...) ")

    # Playwright capture toggles
    g.addoption("--qa-video", action="store_true", help="Enable Playwright video recording (default: on)")
    g.addoption("--qa-no-video", action="store_true", help="Disable Playwright video recording")
    g.addoption("--qa-trace", action="store_true", help="Enable Playwright tracing (default: on)")
    g.addoption("--qa-no-trace", action="store_true", help="Disable Playwright tracing")
    g.addoption("--qa-har", action="store_true", help="Enable HAR recording (default: on)")
    g.addoption("--qa-no-har", action="store_true", help="Disable HAR recording")
    g.addoption("--qa-console", action="store_true", help="Capture page console logs (default: on)")
    g.addoption("--qa-no-console", action="store_true", help="Disable page console logs capture")
    g.addoption("--qa-screenshot-on-fail", action="store_true", help="Screenshot on failure (default: on)")
    g.addoption("--qa-no-screenshot-on-fail", action="store_true", help="Disable screenshot on failure")


def _env_bool(name: str) -> Optional[bool]:
    import os

    v = (os.getenv(name) or "").strip().lower()
    if not v:
        return None
    if v in {"1", "true", "yes", "on"}:
        return True
    if v in {"0", "false", "no", "off"}:
        return False
    return None


def _is_enabled(config: pytest.Config) -> bool:
    import os

    if config.getoption("--no-qa-bundle"):
        return False

    v = (os.getenv("QA_BUNDLE") or "").strip().lower()
    if v in {"0", "false", "no", "off"}:
        return False
    if v in {"1", "true", "yes", "on"}:
        return True

    if config.getoption("--qa-bundle"):
        return True

    return True


def _feature_enabled(config: pytest.Config, *, name: str, cli_on: str, cli_off: str) -> bool:
    # priority: explicit cli off > explicit cli on > env override > default on
    if config.getoption(cli_off):
        return False
    if config.getoption(cli_on):
        return True
    env = _env_bool(name)
    if env is not None:
        return env
    return True


def pytest_configure(config: pytest.Config) -> None:
    if not _is_enabled(config):
        return

    proj = config.getoption("--project") or None
    if proj:
        import os

        os.environ.setdefault("PROJECT_NAME", proj)

    ctx = current_context()
    ctx.run_root.mkdir(parents=True, exist_ok=True)

    config._qa_run_bundler_ctx = ctx  # type: ignore[attr-defined]
    config._qa_run_bundler_tests = []  # type: ignore[attr-defined]
    config._qa_run_bundler_tests_by_id = {}  # type: ignore[attr-defined]

    config._qa_feat = {
        "video": _feature_enabled(config, name="QA_VIDEO", cli_on="--qa-video", cli_off="--qa-no-video"),
        "trace": _feature_enabled(config, name="QA_TRACE", cli_on="--qa-trace", cli_off="--qa-no-trace"),
        "har": _feature_enabled(config, name="QA_HAR", cli_on="--qa-har", cli_off="--qa-no-har"),
        "console": _feature_enabled(config, name="QA_CONSOLE", cli_on="--qa-console", cli_off="--qa-no-console"),
        "screenshot_on_fail": _feature_enabled(
            config, name="QA_SCREENSHOT_ON_FAIL", cli_on="--qa-screenshot-on-fail", cli_off="--qa-no-screenshot-on-fail"
        ),
    }  # type: ignore[attr-defined]


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item: pytest.Item, call: pytest.CallInfo):
    outcome = yield
    rep = outcome.get_result()

    config = item.config
    if not _is_enabled(config):
        return

    # On failure, try to screenshot if a Playwright page fixture exists
    if rep.when == "call" and rep.failed:
        feat = getattr(config, "_qa_feat", {})
        if feat.get("screenshot_on_fail"):
            page = item.funcargs.get("page") if hasattr(item, "funcargs") else None
            if page is not None:
                ctx = getattr(config, "_qa_run_bundler_ctx", None)
                if ctx:
                    worker = getattr(item.config, "workerinput", None)
                    wid = worker.get("workerid") if isinstance(worker, dict) else None
                    suffix = f"__{wid}" if wid else ""
                    test_dir = ctx.run_root / "tests" / (safe_filename(item.nodeid) + suffix)
                    paths = ensure_test_dirs(test_dir)
                    shot = paths.test_dir / "screenshot_failed.png"
                    try:
                        page.screenshot(path=str(shot), full_page=True)
                    except Exception:
                        pass


@pytest.fixture(scope="function", autouse=True)
def qa_capture_console(request: pytest.FixtureRequest):
    config = request.config
    if not _is_enabled(config):
        yield
        return

    feat = getattr(config, "_qa_feat", {})
    if not feat.get("console"):
        yield
        return

    # Attach only if Playwright page fixture is present
    page = request.getfixturevalue("page") if "page" in request.fixturenames else None
    if page is None:
        yield
        return

    ctx = getattr(config, "_qa_run_bundler_ctx", None)
    if not ctx:
        yield
        return

    worker = getattr(request.config, "workerinput", None)
    wid = worker.get("workerid") if isinstance(worker, dict) else None
    suffix = f"__{wid}" if wid else ""
    test_dir = ctx.run_root / "tests" / (safe_filename(request.node.nodeid) + suffix)
    paths = ensure_test_dirs(test_dir)
    add_console_listeners(page, paths.console_log)
    yield


@pytest.fixture(scope="function", autouse=True)
def qa_playwright_tracing(request: pytest.FixtureRequest):
    config = request.config
    if not _is_enabled(config):
        yield
        return

    feat = getattr(config, "_qa_feat", {})
    if not feat.get("trace"):
        yield
        return

    # pytest-playwright (sync) provides `context` fixture
    context = request.getfixturevalue("context") if "context" in request.fixturenames else None
    if context is None:
        yield
        return

    ctx = getattr(config, "_qa_run_bundler_ctx", None)
    if not ctx:
        yield
        return

    import inspect

    # xdist-safe: include worker id if present
    worker = getattr(request.config, "workerinput", None)
    wid = worker.get("workerid") if isinstance(worker, dict) else None
    suffix = f"__{wid}" if wid else ""
    test_dir = ctx.run_root / "tests" / (safe_filename(request.node.nodeid) + suffix)
    paths = ensure_test_dirs(test_dir)

    # Start tracing (sync or async)
    try:
        r = context.tracing.start(screenshots=True, snapshots=True, sources=True, title=request.node.nodeid)
        if inspect.isawaitable(r):
            # If someone uses async fixtures in future, we don't crash.
            import asyncio

            asyncio.get_event_loop().run_until_complete(r)
    except Exception:
        pass

    yield

    # Stop tracing
    try:
        r = context.tracing.stop(path=str(paths.trace_zip))
        if inspect.isawaitable(r):
            import asyncio

            asyncio.get_event_loop().run_until_complete(r)
    except Exception:
        pass


@pytest.fixture(scope="session")
def browser_context_args(browser_context_args, request):
    """pytest-playwright hook: modify context args to enable video + har recording."""

    config = request.config
    if not _is_enabled(config):
        return browser_context_args

    ctx = getattr(config, "_qa_run_bundler_ctx", None)
    if not ctx:
        return browser_context_args

    feat = getattr(config, "_qa_feat", {})
    args = dict(browser_context_args)

    # Video
    if feat.get("video"):
        videos_dir = ctx.run_root / "videos"
        videos_dir.mkdir(parents=True, exist_ok=True)
        args.setdefault("record_video_dir", str(videos_dir))

    # HAR (embed content by default)
    if feat.get("har"):
        network_dir = ctx.run_root / "network"
        network_dir.mkdir(parents=True, exist_ok=True)
        args.setdefault("record_har_path", str(network_dir / "network.har"))
        args.setdefault("record_har_content", "embed")
        args.setdefault("record_har_mode", "full")

    return args


def pytest_runtest_logreport(report: pytest.TestReport) -> None:
    """Collect per-test status even when failures happen in setup/teardown.

    This ensures we can generate a report even if execution stops early (-x)
    or if a test errors before reaching the call phase.
    """

    config = report.config  # type: ignore[attr-defined]
    store = getattr(config, "_qa_run_bundler_tests", None)
    if store is None:
        return

    # Keep a dict by nodeid to merge phases (setup/call/teardown)
    d = getattr(config, "_qa_run_bundler_tests_by_id", None)
    if d is None:
        d = {}
        config._qa_run_bundler_tests_by_id = d  # type: ignore[attr-defined]

    nodeid = report.nodeid
    cur = d.get(nodeid) or {
        "nodeid": nodeid,
        "status": "passed",
        "duration_ms": 0,
        "phases": {},
    }

    phase_status = "passed" if report.passed else "failed" if report.failed else "skipped"
    cur["phases"][report.when] = {
        "status": phase_status,
        "duration_ms": int((report.duration or 0.0) * 1000),
    }

    # Accumulate total duration
    cur["duration_ms"] = int(cur.get("duration_ms") or 0) + int((report.duration or 0.0) * 1000)

    # Final status precedence: failed > skipped > passed
    phases = cur.get("phases") or {}
    statuses = [p.get("status") for p in phases.values() if isinstance(p, dict)]
    if "failed" in statuses:
        cur["status"] = "failed"
    elif "skipped" in statuses and cur.get("status") != "failed":
        cur["status"] = "skipped"
    else:
        cur["status"] = "passed"

    d[nodeid] = cur

    # For backwards compatibility, also keep a list snapshot (will be overwritten at sessionfinish)
    store.append({"nodeid": nodeid, "status": cur["status"], "duration_ms": cur["duration_ms"]})


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    config = session.config
    if not _is_enabled(config):
        return

    ctx = getattr(config, "_qa_run_bundler_ctx", None)
    if not ctx:
        return

    tests_by_id = getattr(config, "_qa_run_bundler_tests_by_id", {})
    tests = list(tests_by_id.values()) if isinstance(tests_by_id, dict) and tests_by_id else getattr(config, "_qa_run_bundler_tests", [])

    qa_dir = ctx.run_root / "qa_bundle"
    qa_dir.mkdir(parents=True, exist_ok=True)

    manifest: dict[str, Any] = {
        "schema": "qa-run-bundle-manifest/v1",
        "project": ctx.project,
        "env": ctx.env,
        "test_env": ctx.test_env,
        "run_id": ctx.run_id,
        "run_root": str(ctx.run_root),
    }

    atomic_write(qa_dir / "manifest.json", json.dumps(manifest, indent=2))
    atomic_write(qa_dir / "tests.json", json.dumps(tests, indent=2))

    res = build_bundle(ctx.run_root, out_dir=qa_dir, zip_limit_bytes=1_000_000_000)

    # Export paths for Slack/Email/Jira/Allure integrations
    import os

    os.environ["QA_RUN_ROOT"] = str(ctx.run_root)
    os.environ["QA_BUNDLE_HTML"] = str(res.index_html)
    os.environ["QA_BUNDLE_ZIP"] = str(res.bundle_zip)

    paths_payload = {
        "run_root": str(ctx.run_root),
        "report_html": str(res.index_html),
        "bundle_zip": str(res.bundle_zip),
    }
    atomic_write(qa_dir / "qa_bundle_paths.json", json.dumps(paths_payload, indent=2))
