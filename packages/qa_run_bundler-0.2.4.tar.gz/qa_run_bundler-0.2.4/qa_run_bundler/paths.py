from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
import uuid
import subprocess


@dataclass(frozen=True)
class RunContext:
    project: str
    env: str
    test_env: str | None
    run_id: str
    run_root: Path


def default_run_id() -> str:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"run_{ts}_{uuid.uuid4().hex[:8]}"


def _find_repo_root(cwd: Path) -> Path:
    """Return git repo root if inside a git repo, else cwd.

    Requirement: report folder should be created at root level even if user runs tests
    from any subfolder.
    """

    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=str(cwd),
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()
        if out:
            return Path(out)
    except Exception:
        pass
    return cwd


def compute_run_root(*, project: str, env: str, test_env: str | None, run_id: str, base_dir: Path | None = None) -> Path:
    base = base_dir or _find_repo_root(Path.cwd())
    base = base.resolve()

    # Requirement: prod/runs (no test_env segment)
    if env.lower() == "prod":
        return base / "test_report" / project / "prod" / "runs" / run_id

    # non-prod: include test_env if present
    if test_env:
        return base / "test_report" / project / env / test_env / "runs" / run_id

    return base / "test_report" / project / env / "runs" / run_id


def current_context(run_id: str | None = None) -> RunContext:
    project = os.getenv("PROJECT_NAME") or os.getenv("PROJECT") or "default"
    env = (os.getenv("ENV") or "dev").lower()
    test_env = (os.getenv("TEST_ENV") or "").lower().strip() or None
    rid = run_id or os.getenv("QA_RUN_ID") or default_run_id()
    root = compute_run_root(project=project, env=env, test_env=test_env, run_id=rid)
    return RunContext(project=project, env=env, test_env=test_env, run_id=rid, run_root=root)
