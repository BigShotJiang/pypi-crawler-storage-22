# ----------------------------------------------------------------------------
# Description    : Configuration management constants
# Git repository : https://gitlab.com/qblox/packages/software/qblox_instruments.git
# Copyright (C) Qblox BV (2021)
# ----------------------------------------------------------------------------

# Client version.
VERSION = (0, 2, 0)
