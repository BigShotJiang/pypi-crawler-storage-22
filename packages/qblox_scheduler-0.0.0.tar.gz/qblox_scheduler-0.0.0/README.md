![qblox-scheduler logo](https://gitlab.com/qblox/packages/software/qblox-scheduler/-/raw/main/docs/source/images/Qblox%20Scheduler%20Logo%20Primary.svg)

⚠️⚠️⚠️ **qblox-scheduler is in a beta phase and has no stable release on PyPI yet.**

Please checkout the [release page](https://pypi.org/project/qblox-scheduler/#history) for an overview of available versions.

If installing this package gives an error, please try one of the following:

- use `pip install --pre qblox-scheduler` instead of `pip install qblox-scheduler`
- use `uv add --prerelease qblox-scheduler` instead of `uv add qblox-scheduler`
- in requirements.txt, replace `qblox-scheduler` with `"qblox-scheduler>=1.0.0b1"`
- in pyproject.toml, replace `qblox-scheduler` with `"qblox-scheduler >=1.0.0b1"`

more information on how to install the pre-release can be found at
https://docs.qblox.com/en/main/quickstart/installation/software/python.html#qblox-scheduler

[<img src="https://gitlab.com/qblox/packages/software/qblox-scheduler/-/raw/main/docs/source/images/Qblox_logo.svg" alt="Qblox logo" width=200px/>](https://www.qblox.com)
&nbsp;
&nbsp;

The software is free to use under the conditions specified in the [license](https://gitlab.com/qblox/packages/software/qblox-scheduler/-/raw/main/LICENSE).