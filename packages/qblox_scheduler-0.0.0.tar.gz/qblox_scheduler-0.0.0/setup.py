from __future__ import annotations

import os

from setuptools import setup
from setuptools.command.egg_info import egg_info
from setuptools.command.install import install

try:
    from wheel.bdist_wheel import bdist_wheel  # type: ignore
except Exception:  # pragma: no cover
    bdist_wheel = None  # type: ignore[assignment]


_MESSAGE: str = (
    "qblox-scheduler is in beta phase and has no stable release yet. "
    "\n"
    "Here's how to fix this error in most cases:\n"
    "- use `pip install --pre qblox-scheduler` instead of `pip install qblox-scheduler`\n"
    "- use `uv add --prerelease qblox-scheduler` instead of `uv add qblox-scheduler`\n"
    '- in requirements.txt, replace `qblox-scheduler` with `"qblox-scheduler>=1.0.0b1"`\n'
    '- in pyproject.toml, replace `qblox-scheduler` with `"qblox-scheduler >=1.0.0b1"`\n'
    "\n"
    "more information on how to install the pre-release can be found at\n"
    "https://docs.qblox.com/en/main/quickstart/installation/software/python.html#qblox-scheduler"
)


def _should_abort() -> bool:
    return os.environ.get("ALLOW_QBLOX_SCHEDULER_PLACEHOLDER_BUILD", "0") not in {
        "1",
        "true",
        "TRUE",
    }


class AbortEggInfo(egg_info):
    def run(self) -> None:  # type: ignore[override]
        if _should_abort():
            raise SystemExit(_MESSAGE)
        super().run()


class AbortInstall(install):
    def run(self) -> None:
        if _should_abort():
            raise SystemExit(_MESSAGE)
        super().run()


if bdist_wheel is not None:

    class AbortWheel(bdist_wheel):  # type: ignore[misc]
        def run(self) -> None:  # type: ignore[override]
            if _should_abort():
                raise SystemExit(_MESSAGE)
            super().run()
else:  # pragma: no cover
    AbortWheel = None  # type: ignore[assignment]


cmdclass = {"egg_info": AbortEggInfo, "install": AbortInstall}
if bdist_wheel is not None and AbortWheel is not None:
    cmdclass["bdist_wheel"] = AbortWheel


if __name__ == "__main__":
    setup(cmdclass=cmdclass)
