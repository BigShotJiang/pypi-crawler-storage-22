# IODATA is an input and output module for quantum chemistry.
# Copyright (C) 2011-2019 The IODATA Development Team
#
# This file is part of IODATA.
#
# IODATA is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 3
# of the License, or (at your option) any later version.
#
# IODATA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, see <http://www.gnu.org/licenses/>
# --
"""Test iodata.formats.gromacs module."""

from importlib.resources import as_file, files

from numpy.testing import assert_allclose, assert_equal

from ..api import load_many, load_one
from ..utils import nanometer, picosecond


def test_load_water():
    """Test gro file of one water."""
    with as_file(files("iodata.test.data").joinpath("water.gro")) as fn_gro:
        mol = load_one(str(fn_gro))
    check_water(mol)


def check_water(mol):
    """Test some things on a water file."""
    assert mol.title == "MD of 2 waters"
    assert mol.atcoords.shape == (6, 3)
    assert_allclose(mol.atcoords[-1] / nanometer, [1.326, 0.120, 0.568])
    assert mol.atffparams["attypes"][2] == "HW3"
    assert mol.atffparams["resnames"][-1] == "WATER"
    assert_equal(mol.atffparams["resnums"][2:4], [1, 2])
    assert_allclose(mol.cellvecs[0][0], 1.82060 * nanometer, atol=1.0e-5)
    assert mol.extra["velocities"].shape == (6, 3)
    vel = mol.extra["velocities"][-1]
    assert_allclose(vel * (picosecond / nanometer), [1.9427, -0.8216, -0.0244])


def test_load_many():
    """Test water gro file with two frames."""
    with as_file(files("iodata.test.data").joinpath("water2.gro")) as fn_gro:
        mols = list(load_many(str(fn_gro)))
    assert len(mols) == 2
    assert mols[0].extra["time"] == 0.0 * picosecond
    assert mols[1].extra["time"] == 1.0 * picosecond
    for mol in mols:
        check_water(mol)


def test_load_without_velocities():
    """A GRO file without velocity columns should set velocities to None."""
    with as_file(files("iodata.test.data").joinpath("water_no_vel.gro")) as fn_gro:
        mol = load_one(str(fn_gro))

    # basic checks
    assert mol.title == "MD of 2 waters"
    assert mol.atcoords.shape == (6, 3)

    # coordinates should match the ones in the file (compare in nm)
    assert_allclose(mol.atcoords[-1] / nanometer, [1.326, 0.120, 0.568])

    # velocities should be present in extra but None
    assert "velocities" in mol.extra
    assert mol.extra["velocities"] is None
