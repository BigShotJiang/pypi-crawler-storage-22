"""Schema version tracking and migration support."""

from __future__ import annotations

from pathlib import Path

from psycopg import AsyncConnection


CURRENT_SCHEMA_VERSION = 6


async def get_schema_version(conn: AsyncConnection) -> int | None:
    """Return the current schema version, or None if the table doesn't exist."""
    result = await conn.execute(
        "SELECT EXISTS ("
        "  SELECT 1 FROM information_schema.tables "
        "  WHERE table_name = 'schema_version'"
        ")"
    )
    row = await result.fetchone()
    if not row or not row[0]:
        return None

    result = await conn.execute(
        "SELECT MAX(version) FROM schema_version"
    )
    row = await result.fetchone()
    return row[0] if row else None


_MIGRATION_V4 = """\
CREATE TABLE IF NOT EXISTS file_progress (
    raw_file_path TEXT NOT NULL,
    source TEXT NOT NULL,
    last_line_read INT NOT NULL DEFAULT 0,
    content_hash TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (raw_file_path, source)
);

INSERT INTO schema_version (version) VALUES (4) ON CONFLICT DO NOTHING;
"""


async def _migrate_to_v4(conn: AsyncConnection) -> None:
    """Create file_progress table for existing databases."""
    await conn.execute(_MIGRATION_V4)
    await conn.commit()


_MIGRATION_V5 = """\
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'sessions' AND column_name = 'org'
    ) THEN
        ALTER TABLE sessions ADD COLUMN org TEXT;
        CREATE INDEX idx_sessions_org ON sessions (org);
    END IF;
END $$;

INSERT INTO schema_version (version) VALUES (5) ON CONFLICT DO NOTHING;
"""


async def _migrate_to_v5(conn: AsyncConnection) -> None:
    """Add org column to sessions table."""
    await conn.execute(_MIGRATION_V5)
    await conn.commit()


_MIGRATION_V6 = """\
CREATE TABLE IF NOT EXISTS version_config (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

INSERT INTO schema_version (version) VALUES (6) ON CONFLICT DO NOTHING;
"""


async def _migrate_to_v6(conn: AsyncConnection) -> None:
    """Create version_config table for server-controlled version gating."""
    await conn.execute(_MIGRATION_V6)
    await conn.commit()


def _read_schema_sql() -> str:
    """Read the schema.sql file bundled with the package."""
    schema_path = Path(__file__).parent / "schema.sql"
    return schema_path.read_text()


async def ensure_schema(conn: AsyncConnection) -> int:
    """Apply the schema if not present. Returns the current version.

    This is idempotent — safe to call on every startup.
    """
    version = await get_schema_version(conn)
    if version is None:
        sql = _read_schema_sql()
        await conn.execute(sql)
        await conn.commit()
        return CURRENT_SCHEMA_VERSION
    if version < 4:
        await _migrate_to_v4(conn)
        version = 4
    if version < 5:
        await _migrate_to_v5(conn)
        version = 5
    if version < 6:
        await _migrate_to_v6(conn)
        version = 6
    return version
