"""Daemon configuration."""

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_PORT = 19777
DEFAULT_INGEST_URL = "https://trace.quickcall.dev/ingest"


def _default_base_dir() -> Path:
    return Path.home() / ".quickcall-trace"


def _default_ingest_url() -> str:
    return os.environ.get("QC_TRACE_INGEST_URL", DEFAULT_INGEST_URL)


@dataclass
class DaemonConfig:
    """Configuration for the quickcall daemon."""

    # Polling
    poll_interval: float = 5.0  # seconds

    # Paths
    base_dir: Path = field(default_factory=_default_base_dir)

    # Ingest server (override with QC_TRACE_INGEST_URL env var)
    ingest_url: str = field(default_factory=_default_ingest_url)

    # File limits
    max_file_size: int = 100 * 1024 * 1024  # 100MB
    max_retries_per_file: int = 3

    # Retry / pusher
    retry_backoff_base: float = 1.0  # seconds
    retry_backoff_max: float = 60.0  # seconds
    retry_queue_max: int = 10_000  # max messages in retry queue
    retry_timeout: float = 300.0  # 5 min persistent failure threshold
    retry_cooldown: float = 300.0  # seconds before backoff decays

    # Batch size for push
    batch_size: int = 500

    # Organization (set via QC_TRACE_ORG env var or config.json)
    org: str | None = None

    # API key for server auth (set via QC_TRACE_API_KEY env var or config.json)
    api_key: str | None = None

    # Device ID (persistent UUID generated at install, read from config.json)
    device_id: str | None = None

    # Source glob patterns (relative to home)
    claude_code_glob: str = ".claude/projects/**/*.jsonl"
    codex_cli_glob: str = ".codex/sessions/*/*/*/rollout-*.jsonl"
    gemini_cli_glob: str = ".gemini/tmp/*/chats/session-*.json"
    cursor_glob: str = ".cursor/projects/*/agent-transcripts/*.txt"

    def __post_init__(self) -> None:
        """Resolve org and api_key from env var > config.json > None."""
        config_data: dict | None = None
        config_path = self.base_dir / "config.json"
        if config_path.exists():
            try:
                config_data = json.loads(config_path.read_text())
            except (json.JSONDecodeError, OSError):
                pass

        # Resolve org: env > config.json > None
        if self.org is None:
            env_org = os.environ.get("QC_TRACE_ORG")
            if env_org:
                self.org = env_org
            elif config_data:
                self.org = config_data.get("org")

        # Resolve api_key: env > config.json > None
        if self.api_key is None:
            env_key = os.environ.get("QC_TRACE_API_KEY")
            if env_key:
                self.api_key = env_key
            elif config_data:
                self.api_key = config_data.get("api_key")

        # Resolve device_id from config.json
        if self.device_id is None and config_data:
            self.device_id = config_data.get("device_id")

        # Resolve ingest_url: explicit arg > env > config.json > default
        if self.ingest_url == DEFAULT_INGEST_URL:
            env_url = os.environ.get("QC_TRACE_INGEST_URL")
            if env_url:
                self.ingest_url = env_url
            elif config_data and config_data.get("ingest_url"):
                self.ingest_url = config_data["ingest_url"]

    @property
    def state_file(self) -> Path:
        return self.base_dir / "state.json"

    @property
    def pid_file(self) -> Path:
        return self.base_dir / "quickcall.pid"
