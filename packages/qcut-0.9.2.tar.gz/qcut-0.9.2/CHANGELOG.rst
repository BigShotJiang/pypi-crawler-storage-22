=========
Changelog
=========

Version 0.9.2
=============
- Minor fix

Version 0.9.1
=============
- Fixes for issues for subcircuit construction with Qiskit > 1.2
    - Qiskit version requirement updated to >= 1.0, < 2.0
- This major version (0.9.x) will be the last to support Qiskit < 2.0
- Version 1.0 will add Qiskit 2.0+ support and drop Qiskit 1.0 support

Version 0.9.0
=============
- Migrate from index based Z-observables to Qiskits SparsePauliOps
    * The observables parameter for all functions now takes a list of Qiskits :code:`SparsePauliOp` objects instead of lists of qubit indices.
    * This allows for more general observables to be calculated, including multi-qubit observables and observables with different Pauli operators.
    * Check documentation for details on how to use.

Version 0.8.0
=============
- Support for cutting 2 qubit gates
    * Added :code:`cutGate` function for cutting 2 qubit gates directly.
    * Cutting done by transpiling the 2 qubit gate into a cut CZ gate with appropriate basis changes.
    * For non CZ family gates this results in suboptimal decompositions. More optimised decompositions will be added in future releases.
    * Check documentation for details on how to use.

Version 0.7.0
=============
- Rework transpilation workflow
    * Transpilation now done per subcircuit instead of per experiment circuit.
         * Per experiment transpilation still provided for more control.
         * Users can of course still manually transpile circuits before passing to QCut.
    * This greatly reduces the number of transpilation calls needed, improving performance.
    * Check documentation for details on how to use.
- Bug fixes

Version 0.6.0
=============
- Support cutting CZ gates
    * Added support for cutting CZ gates in addition wire cuts.
    * Check documentation for details on how to use.
- Added automatic cut finding feature
    * Added :code:`QCutFind` module for automatically finding good cut locations in a circuit.
    * Check documentation for details on how to use.
- Bug fixes
- Drop windows support for the time being due to METIS issues
    * Windows users should use WSL

Version 0.3.0
=============
- Support for IQM Qiskit 17.8
    * Added support for IQM Qiskit 17.8.
- Removed built in :code:`mitigate` flag
- Bug fixes
- Remove old two qubit gate :code:`CutWire` operation
    * Users using the old method can consult documentation for migration help

Version 0.2.4
=============
- Bugfix for incorrect partitioning for cases where there are multipe cuts on a single wire

Version 0.2.3
=============
- Major optimisation on :code:`_move_to_new_wire` method.
    * Old version took around 11s for a random circuit with depth of 50 and 50 qubits.
    * New version takes around 0.2s for the same circuit.

Version 0.2.2
=============
- Bugfix for array overflow in :code:`get_experiment_circuits`

Version 0.2.1
=============
- Hotfix for incorrect version of qiskit-aer in pyproject.toml.
- Fix pypi workflow

Version 0.2.0
=============
- Single qubit cut gate now the default cut method
    * Greatly simplifies placing cuts.
    * Old two qubit gate deprecated and will be removed soon.
    * Check out documentation for migration help.

Version 0.1.3
=============
- Hotfix for source files not included in pypi build.
    * 0.1.0 - 0.1.2 not installable.

Version 0.1.2
=============
- Add Qiskit 1.0 support.
    * Supported versions now >= 0.45.3, < 1.2.
    * No worflow changes. No migration required.
    * Compatible with qiskit-iqm 13.15
- Add Python 3.11 support.
    * Supported versions now >= 3.9, < 3.12.
- Fix bug in :code:`_get_bounds()` method.
- Use :code:`pickle.loads(pickle.dumps())` instead of :code:`deepcopy()` in :code:`_get_experiment_circuits()`.
    * Slight performance improvement.
- Revert back to vx.x.x versioning scheme.


Version 0.1.1
=============

- Code quality improvements:
    * Move to pyproject.toml. Contents of ruff.toml and setup.py now live in pyproject.toml.
    * Relative imports are now absolute imports.
    * All images are now located under the _static folder.
- Added Github workflows:
    * Added github actions workflows for building the documentation and testing that the documentation can be built.
    * Added github actions workflows for testing the code.
    * Added github actions workflows for publishing to pypi.
    * Added github actions workflows for linting.
- Revamped documentation:
    * Documentation now uses the Book theme.
    * Fixed all warnings from sphinx when building the documentation.
    * Fixed spelling mistakes.
    * Added a new page for the changelog.
- README now contains the information to build the docs.
- Change versioning scheme to "x.x.x" instead of "vx.x.x".

Version 0.1.0
=============

- First stable release
