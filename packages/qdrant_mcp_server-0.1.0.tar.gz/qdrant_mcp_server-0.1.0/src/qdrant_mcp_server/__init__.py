"""
Qdrant MCP Server

A Model Context Protocol (MCP) server for Qdrant vector database 
with semantic search capabilities.
"""

__version__ = "0.1.0"
__author__ = "fiyen"
__email__ = "623320480@qq.com"

from .server import create_server, QdrantMCPServer
from .__main__ import main, run

__all__ = [
    "create_server",
    "QdrantMCPServer",
    "main",
    "run",
]
