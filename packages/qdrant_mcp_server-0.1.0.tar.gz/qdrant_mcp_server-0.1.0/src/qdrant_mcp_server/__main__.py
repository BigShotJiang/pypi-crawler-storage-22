#!/usr/bin/env python3
"""
Qdrant MCP Server 主入口点
"""

import asyncio
import logging

from mcp.server.models import InitializationOptions
from mcp.server.lowlevel import NotificationOptions
import mcp.server.stdio

from .server import create_server

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def main():
    """主函数"""
    server, qdrant_server = create_server()
    
    try:
        async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="qdrant-mcp",
                    server_version="0.1.0",
                    capabilities=server.get_capabilities(
                        notification_options=NotificationOptions(),
                        experimental_capabilities={},
                    ),
                ),
            )
    finally:
        await qdrant_server.close()


def run():
    """命令行入口点"""
    asyncio.run(main())


if __name__ == "__main__":
    run()
