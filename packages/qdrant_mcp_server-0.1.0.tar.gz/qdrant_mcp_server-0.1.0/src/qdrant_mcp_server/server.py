#!/usr/bin/env python3
"""
Qdrant MCP Server - 标准实现

基于Qdrant向量数据库的MCP（Model Context Protocol）工具包
提供知识记录、搜索、更新和删除功能
"""

import asyncio
import json
import logging
import os
import uuid
from typing import Any, Dict, List, Optional, Union

import httpx
from sentence_transformers import SentenceTransformer
from dotenv import load_dotenv

from mcp.server.lowlevel import NotificationOptions, Server
from mcp.server.models import InitializationOptions
import mcp.server.stdio
import mcp.types as types

# 加载环境变量
load_dotenv()

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class QdrantMCPServer:
    """Qdrant MCP服务器类"""

    def __init__(self):
        self.qdrant_url = os.getenv("QDRANT_URL", "http://localhost:6333")
        self.qdrant_token = os.getenv("QDRANT_API_KEY") or os.getenv("QDRANT_TOKEN")
        self.collection_name = os.getenv("COLLECTION_NAME", "default_collection")
        self.embedding_model_name = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
        self.jina_token = os.getenv("JINA_TOKEN")

        # 从环境变量读取向量名称配置
        self.vector_name = os.getenv("VECTOR_NAME")

        # HTTP客户端将在需要时延迟初始化
        self.http_client = None
        self._initialized = False

        # 判断使用哪种嵌入方式（兼容多种别名）
        normalized_name = str(self.embedding_model_name).strip().lower().replace("_", "-")
        self.use_jina_embedding = normalized_name in {"jina-embeddings-v3", "jina-embedding-v3"}

        if self.use_jina_embedding:
            # 使用Jina在线嵌入
            if not self.jina_token:
                raise ValueError("使用JINA在线嵌入时必须设置JINA_TOKEN环境变量")
            self.embedding_model = None
            # 如果没有指定向量名称，使用默认的Jina向量名称
            if not self.vector_name:
                self.vector_name = "jina-embeddings-v3"
            logger.info(f"已配置Jina在线嵌入模型: {normalized_name} → 使用向量名称: {self.vector_name}")
        else:
            # 使用本地sentence-transformers模型
            try:
                self.embedding_model = SentenceTransformer(self.embedding_model_name)
                # 如果没有指定向量名称，使用默认的本地模型向量名称
                if not self.vector_name:
                    self.vector_name = "fast-all-minilm-l6-v2"
                logger.info(f"已加载本地嵌入模型: {self.embedding_model_name}，向量名称: {self.vector_name}")
            except Exception as e:
                logger.error(f"加载嵌入模型失败: {e}")
                raise
        
        logger.info(f"Qdrant MCP服务器配置完成，连接到: {self.qdrant_url}")

    async def _ensure_http_client(self):
        """确保HTTP客户端已初始化"""
        if self.http_client is None or self.http_client.is_closed:
            headers = {"Content-Type": "application/json"}
            if self.qdrant_token:
                headers["Authorization"] = f"Bearer {self.qdrant_token}"

            self.http_client = httpx.AsyncClient(
                base_url=self.qdrant_url,
                headers=headers,
                timeout=30.0
            )
            self._initialized = True
            logger.info("HTTP客户端已初始化")

    async def _make_request(self, method: str, url: str, **kwargs) -> httpx.Response:
        """发送HTTP请求"""
        await self._ensure_http_client()

        if method.upper() == "GET":
            return await self.http_client.get(url, **kwargs)
        elif method.upper() == "POST":
            return await self.http_client.post(url, **kwargs)
        elif method.upper() == "PUT":
            return await self.http_client.put(url, **kwargs)
        elif method.upper() == "DELETE":
            return await self.http_client.delete(url, **kwargs)
        else:
            raise ValueError(f"不支持的HTTP方法: {method}")
    
    async def generate_embedding(self, text: str) -> List[float]:
        """生成文本嵌入向量"""
        try:
            if self.use_jina_embedding:
                return await self._generate_jina_embedding(text)
            else:
                embedding = self.embedding_model.encode(text)
                return embedding.tolist()
        except Exception as e:
            logger.error(f"生成嵌入向量失败: {e}")
            raise

    async def _generate_jina_embedding(self, text: str) -> List[float]:
        """使用Jina API生成嵌入向量"""
        try:
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.jina_token}"
            }

            payload = {
                "model": "jina-embeddings-v3",
                "task": "text-matching",  # 用于语义相似度匹配
                "input": [text],
                "normalized": True,  # L2标准化
                "embedding_type": "float"
            }

            async with httpx.AsyncClient() as client:
                response = await client.post(
                    "https://api.jina.ai/v1/embeddings",
                    headers=headers,
                    json=payload,
                    timeout=30.0
                )

                if response.status_code == 200:
                    result = response.json()
                    embedding = result["data"][0]["embedding"]
                    logger.debug(f"Jina API返回嵌入向量，维度: {len(embedding)}")
                    return embedding
                else:
                    raise Exception(f"Jina API请求失败: {response.status_code} - {response.text}")

        except Exception as e:
            logger.error(f"Jina嵌入生成失败: {e}")
            raise
    
    async def ensure_collection_exists(self) -> bool:
        """确保集合存在，如果不存在则创建"""
        try:
            # 检查集合是否存在
            response = await self._make_request("GET", f"/collections/{self.collection_name}")
            if response.status_code == 200:
                logger.info(f"集合 {self.collection_name} 已存在")
                return True

            # 创建集合，使用配置的向量名称和正确的向量维度
            vector_size = 1024 if self.use_jina_embedding else 384
            collection_config = {
                "vectors": {
                    self.vector_name: {
                        "size": vector_size,
                        "distance": "Cosine"
                    }
                }
            }

            logger.info(f"创建集合 {self.collection_name}，向量名称: {self.vector_name}，向量维度: {vector_size}")

            response = await self._make_request(
                "PUT",
                f"/collections/{self.collection_name}",
                json=collection_config
            )

            if response.status_code in [200, 201]:
                logger.info(f"成功创建集合 {self.collection_name}")
                return True
            else:
                logger.error(f"创建集合失败: {response.status_code} - {response.text}")
                return False

        except Exception as e:
            logger.error(f"确保集合存在时出错: {e}")
            return False

    
    async def record_knowledge(self, document: str, metadata: Optional[Dict[str, Any]] = None, point_id: Optional[Union[str, int]] = None) -> Dict[str, Any]:
        """记录知识到Qdrant，使用document+metadata格式"""
        try:
            # 确保集合存在
            if not await self.ensure_collection_exists():
                raise Exception("无法创建或访问集合")

            # 生成嵌入向量
            vector = await self.generate_embedding(document)

            # 准备点数据
            if point_id is None:
                point_id = str(uuid.uuid4())

            # 使用document+metadata格式
            payload = {
                "document": document
            }

            # 如果有metadata，添加到payload中
            if metadata:
                payload["metadata"] = metadata

            point_data = {
                "points": [{
                    "id": point_id,
                    "vector": {
                        self.vector_name: vector  # 使用配置的向量名称
                    },
                    "payload": payload
                }]
            }
            
            # 上传到Qdrant
            response = await self._make_request(
                "PUT",
                f"/collections/{self.collection_name}/points",
                json=point_data
            )
            
            if response.status_code in [200, 201]:
                result = response.json()
                return {
                    "success": True,
                    "point_id": point_id,
                    "operation_id": result.get("result", {}).get("operation_id"),
                    "message": "知识记录成功"
                }
            else:
                raise Exception(f"记录失败: {response.status_code} - {response.text}")
                
        except Exception as e:
            logger.error(f"记录知识失败: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def search_knowledge(self, query: str, limit: int = 5, score_threshold: float = 0.0, filter_conditions: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """搜索相关知识"""
        try:
            # 确保集合存在
            if not await self.ensure_collection_exists():
                raise Exception("无法访问集合")
            
            # 生成查询向量
            query_vector = await self.generate_embedding(query)

            # 准备搜索请求，使用配置的向量名称
            search_data = {
                "vector": {
                    "name": self.vector_name,  # 使用配置的向量名称
                    "vector": query_vector
                },
                "limit": limit,
                "score_threshold": score_threshold,
                "with_payload": True,
                "with_vector": False
            }
            
            # 添加过滤条件
            if filter_conditions:
                search_data["filter"] = filter_conditions
            
            # 执行搜索
            response = await self._make_request(
                "POST",
                f"/collections/{self.collection_name}/points/search",
                json=search_data
            )
            
            if response.status_code == 200:
                result = response.json()
                search_results = result.get("result", [])
                
                return {
                    "success": True,
                    "query": query,
                    "results": [
                        {
                            "id": item["id"],
                            "score": item["score"],
                            "document": item["payload"].get("document", item["payload"].get("text", "")),  # 兼容新旧格式
                            "metadata": item["payload"].get("metadata", {k: v for k, v in item["payload"].items() if k not in ["document", "text"]})
                        }
                        for item in search_results
                    ],
                    "total_found": len(search_results)
                }
            else:
                raise Exception(f"搜索失败: {response.status_code} - {response.text}")
                
        except Exception as e:
            logger.error(f"搜索知识失败: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def update_knowledge(self, point_id: Union[str, int], document: Optional[str] = None, metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """更新已存储的知识条目，使用document+metadata格式"""
        try:
            # 确保集合存在
            if not await self.ensure_collection_exists():
                raise Exception("无法访问集合")

            # 获取现有点数据
            response = await self._make_request(
                "GET",
                f"/collections/{self.collection_name}/points/{point_id}"
            )

            if response.status_code != 200:
                raise Exception(f"找不到ID为 {point_id} 的知识条目")

            existing_data = response.json()["result"]
            existing_payload = existing_data.get("payload", {})

            # 准备更新数据，使用document+metadata格式
            update_payload = {}

            # 更新文档内容和向量（如果提供了新文档）
            if document is not None:
                update_payload["document"] = document
                vector = {
                    self.vector_name: await self.generate_embedding(document)  # 使用配置的向量名称
                }
            else:
                # 保持原有文档内容
                update_payload["document"] = existing_payload.get("document", existing_payload.get("text", ""))
                vector = existing_data.get("vector")

            # 更新元数据
            if metadata:
                update_payload["metadata"] = metadata
            else:
                # 保持原有元数据
                update_payload["metadata"] = existing_payload.get("metadata", {})
            
            # 执行更新
            point_data = {
                "points": [{
                    "id": point_id,
                    "vector": vector,
                    "payload": update_payload
                }]
            }
            
            response = await self._make_request(
                "PUT",
                f"/collections/{self.collection_name}/points",
                json=point_data
            )
            
            if response.status_code in [200, 201]:
                result = response.json()
                return {
                    "success": True,
                    "point_id": point_id,
                    "operation_id": result.get("result", {}).get("operation_id"),
                    "message": "知识更新成功"
                }
            else:
                raise Exception(f"更新失败: {response.status_code} - {response.text}")
                
        except Exception as e:
            logger.error(f"更新知识失败: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def delete_knowledge(self, point_ids: Union[str, int, List[Union[str, int]]], filter_conditions: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """删除知识条目"""
        try:
            # 确保集合存在
            if not await self.ensure_collection_exists():
                raise Exception("无法访问集合")
            
            # 准备删除请求
            delete_data = {}
            
            if point_ids is not None:
                # 按ID删除
                if not isinstance(point_ids, list):
                    point_ids = [point_ids]
                delete_data["points"] = point_ids
            
            if filter_conditions:
                # 按条件删除
                delete_data["filter"] = filter_conditions
            
            if not delete_data:
                raise Exception("必须提供point_ids或filter_conditions")
            
            # 执行删除
            response = await self._make_request(
                "POST",
                f"/collections/{self.collection_name}/points/delete",
                json=delete_data
            )
            
            if response.status_code == 200:
                result = response.json()
                return {
                    "success": True,
                    "operation_id": result.get("result", {}).get("operation_id"),
                    "message": "知识删除成功"
                }
            else:
                raise Exception(f"删除失败: {response.status_code} - {response.text}")
                
        except Exception as e:
            logger.error(f"删除知识失败: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def close(self):
        """优雅关闭HTTP客户端"""
        try:
            if self.http_client and not self.http_client.is_closed:
                await self.http_client.aclose()
                logger.info("HTTP客户端已关闭")
        except Exception as e:
            logger.warning(f"关闭HTTP客户端时出错: {e}")


def create_server() -> Server:
    """创建并配置MCP服务器"""
    # 创建全局实例
    qdrant_server = QdrantMCPServer()
    
    # 创建MCP服务器
    server = Server("qdrant-mcp")
    
    @server.list_tools()
    async def handle_list_tools() -> list[types.Tool]:
        """列出可用的工具"""
        return [
            types.Tool(
                name="qdrant-record",
                description="将文档信息转换为向量并存储到Qdrant集合中，使用document+metadata格式",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "document": {
                            "type": "string",
                            "description": "要存储的文档内容"
                        },
                        "metadata": {
                            "type": "object",
                            "description": "可选的元数据信息",
                            "additionalProperties": True
                        },
                        "point_id": {
                            "type": ["string", "integer", "null"],
                            "description": "可选的点ID，如果不提供将自动生成UUID"
                        }
                    },
                    "required": ["document"]
                }
            ),
            types.Tool(
                name="qdrant-search",
                description="基于语义相似度搜索相关知识条目",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "搜索查询文本"
                        },
                        "limit": {
                            "type": "integer",
                            "description": "返回结果数量限制",
                            "default": 5,
                            "minimum": 1,
                            "maximum": 100
                        },
                        "score_threshold": {
                            "type": "number",
                            "description": "相似度分数阈值",
                            "default": 0.0,
                            "minimum": 0.0,
                            "maximum": 1.0
                        },
                        "filter_conditions": {
                            "type": "object",
                            "description": "可选的过滤条件",
                            "additionalProperties": True
                        }
                    },
                    "required": ["query"]
                }
            ),
            types.Tool(
                name="qdrant-update",
                description="修改已存储的知识条目内容或元数据，使用document+metadata格式",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "point_id": {
                            "type": ["string", "integer"],
                            "description": "要更新的点ID"
                        },
                        "document": {
                            "type": "string",
                            "description": "新的文档内容（可选）"
                        },
                        "metadata": {
                            "type": "object",
                            "description": "要更新的元数据",
                            "additionalProperties": True
                        }
                    },
                    "required": ["point_id"]
                }
            ),
            types.Tool(
                name="qdrant-delete",
                description="删除指定的知识条目",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "point_ids": {
                            "type": ["string", "integer", "array"],
                            "description": "要删除的点ID或ID列表",
                            "items": {
                                "type": ["string", "integer"]
                            }
                        },
                        "filter_conditions": {
                            "type": "object",
                            "description": "按条件删除的过滤器",
                            "additionalProperties": True
                        }
                    }
                }
            )
        ]
    
    @server.call_tool()
    async def handle_call_tool(name: str, arguments: Dict[str, Any]) -> list[types.TextContent]:
        """处理工具调用"""
        try:
            if name == "qdrant-record":
                result = await qdrant_server.record_knowledge(
                    document=arguments["document"],
                    metadata=arguments.get("metadata"),
                    point_id=arguments.get("point_id")
                )
            elif name == "qdrant-search":
                result = await qdrant_server.search_knowledge(
                    query=arguments["query"],
                    limit=arguments.get("limit", 5),
                    score_threshold=arguments.get("score_threshold", 0.0),
                    filter_conditions=arguments.get("filter_conditions")
                )
            elif name == "qdrant-update":
                result = await qdrant_server.update_knowledge(
                    point_id=arguments["point_id"],
                    document=arguments.get("document"),
                    metadata=arguments.get("metadata")
                )
            elif name == "qdrant-delete":
                result = await qdrant_server.delete_knowledge(
                    point_ids=arguments.get("point_ids"),
                    filter_conditions=arguments.get("filter_conditions")
                )
            else:
                raise ValueError(f"未知工具: {name}")

            return [
                types.TextContent(
                    type="text",
                    text=json.dumps(result, ensure_ascii=False, indent=2)
                )
            ]

        except Exception as e:
            logger.error(f"工具调用失败 {name}: {e}")
            return [
                types.TextContent(
                    type="text",
                    text=json.dumps({
                        "success": False,
                        "error": str(e)
                    }, ensure_ascii=False, indent=2)
                )
            ]
    
    return server, qdrant_server
