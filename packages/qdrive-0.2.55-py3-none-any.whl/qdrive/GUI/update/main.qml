import QtQuick 2.15
import QtQuick.Controls 2.15

import QtQuick.Controls.Material 2.12

ApplicationWindow {
    id : main
    visible: true
    width: 400
    height: 500
    title: "Update Available"

    Rectangle {
        anchors.fill: parent
        anchors.margins: 5

        Column {
            spacing: 1

            Text {
                text: "A new version of qdrive is Available " + update_model.new_version_number() + " !"
                font.pixelSize: 18
            }
            Item { height : 8; width : 1}

            Text {
                text: "The app can be updated using the following command :"
                font.pixelSize: 12
            }

            Item { height : 5; width : 1}

            Rectangle{
                anchors.margins: 3
                height : 36
                width : main.width -8
                radius : 2
                border.color : "#AAAAAA"
                border.width : 1

                TextInput {
                    id: singleLineText
                    anchors.left : parent.left
                    anchors.top : parent.top
                    anchors.topMargin : 10
                    anchors.leftMargin: 10
                    text: update_model.update_command()
                    width: main.width
                    selectByMouse: true
                    readOnly: true
                    wrapMode: Text.Wrap
                    font.family: "Verdana"
                    font.pixelSize: 12
                    color : "#333333"
                }
                Button {
                    id: roundedIconButton
                    anchors.top : parent.top
                    anchors.topMargin : 3
                    anchors.left : parent.left
                    anchors.leftMargin : parent.width - 33
                    width: 30
                    height: 30
                    background: Rectangle {
                        color: roundedIconButton.pressed ? "#EEEEEE" : "#DDDDDD"
                        radius: 3
                        border.color: "#CCCCCC"
                        border.width: 0.5
                    }
                    icon.name: "content-copy"
                    icon.source: "./icons/copy.svg"
                    icon.width: 20
                    icon.height: 20
                    onClicked: {
                        Qt.callLater(function() {
                            update_model.copy_to_clipboard();
                        });
                    }
                }
            }

            Item { height : 8; width : 1}

            Text{
                text: "Release Notes:"
                font.pixelSize : 14
            }     
            TextArea {
                id: releaseNotes
                text: update_model.get_release_notes()
                readOnly: true
                selectByMouse : true
                wrapMode: Text.Wrap
            }

            Item { height : 12; width : 1}
            Text{
                text: "Compatibilty Notes:"
                font.pixelSize : 14
            }
            TextArea {
                id : versioncompat
                text: update_model.get_compatibility_notes()
                readOnly: true
                selectByMouse : true
                wrapMode: Text.Wrap
                font.pixelSize : 12
            }

        }
        Button {
            anchors.right : parent.right
            anchors.bottom : parent.bottom
            text: "Close"
            onClicked: main.close()
        }
    }
}
