Getting Started
===============

QForge is designed to be user-friendly and interactive.

Interactive Mode
----------------

The easiest way to start is using the interactive wizard:

.. code-block:: bash

    $ qforge --interactive

This will guide you through creating qubits, analyzing them, and simulating gates.

Command Line Interface
----------------------

You can also use the CLI directly for scripting and quick tasks.

1. **Create a Qubit**

   .. code-block:: bash

       $ qforge qubit create transmon --name my_qubit --EJ 15 --EC 0.3

2. **Analyze Spectrum**

   .. code-block:: bash

       $ qforge qubit analyze --name my_qubit --plot

3. **Simulate a Gate**

   .. code-block:: bash

       $ qforge gate simulate --qubit my_qubit --gate X --duration 40
