# qianli (千里)

Search Chinese content platforms from the terminal. Named after 千里眼 — the far-seeing deity.

Covers WeChat 公众号, Xiaohongshu (RED), Zhihu, 36kr.

Work in progress.
