"""qianli — Search Chinese content platforms from the terminal."""
__version__ = "0.0.1"
