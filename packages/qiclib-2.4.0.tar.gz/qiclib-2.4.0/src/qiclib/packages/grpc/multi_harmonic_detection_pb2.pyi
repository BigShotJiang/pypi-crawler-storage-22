import qiclib.packages.grpc.datatypes_pb2 as _datatypes_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class SystemInfo(_message.Message):
    __slots__ = ("chip_id", "chip_version")
    CHIP_ID_FIELD_NUMBER: _ClassVar[int]
    CHIP_VERSION_FIELD_NUMBER: _ClassVar[int]
    chip_id: int
    chip_version: int
    def __init__(self, chip_id: _Optional[int] = ..., chip_version: _Optional[int] = ...) -> None: ...

class AcquisitionData(_message.Message):
    __slots__ = ("acquisition_count", "nsum")
    ACQUISITION_COUNT_FIELD_NUMBER: _ClassVar[int]
    NSUM_FIELD_NUMBER: _ClassVar[int]
    acquisition_count: int
    nsum: _containers.RepeatedScalarFieldContainer[float]
    def __init__(self, acquisition_count: _Optional[int] = ..., nsum: _Optional[_Iterable[float]] = ...) -> None: ...
