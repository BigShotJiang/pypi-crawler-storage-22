
import random
import json
import typing
print("Imported modules, now going to print some text")
if True:
    print(
        'Some long', 'text to ', 'see how', 'parameters', ' will', ' be', 'spread', 'over', 'multiple lines'
    )


# %% foo -------------------------------------------------------------

print("Trying foo again")


def bar():
    print('baz')


# %% bar -------------------------------------------------------------
print("Now running in bar")


def bar():
    print('baz')


# %% prime -----------------------------------------------------------


def isPrime(n, k):
    if n < 2:
        return False
    if n < 4:
        return True
    if n % 2 == 0:
        return False    # speedup

    # now n is odd > 3
    s = 0
    d = n - 1
    while d % 2 == 0:
        s += 1
        d //= 2
    # n = 2^s * d where d is odd

    for i in range(k):                  # Outer loop
        a = random.randrange(2, n - 1)    # 2 <= a <= n-2
        x = (a**d) % n
        if x == 1:
            continue             # -> next iteration of outer loop (next i)
        for j in range(s):              # Inner loop
            if x == n - 1:
                # exits inner loop -> next iteration of outer loop (next i)
                break
            x = (x * x) % n
        else:
            # all j iterations were successful -> returns (exits both loops)
            return False
    return True                         # returns after all outer loop iterations were done


print("Running in eof")
# end-of-file ---------------------------------------------------------
