# This file is generated - do not edit
"""Entangle - entangles code from ipython notebook cells to python .py files"""

import os
import collections
import typing
import logging
import argparse
import autopep8

from IPython.core.magic import Magics, magics_class, cell_magic, line_cell_magic, line_magic
from qitangle import split_line_args, extract_module_filepath, run_fixer

__all__ = [
    "CodeCell", "entangle_cells", "load_ipython_extension"
]

CodeText_T = str
Label_T = str
Dependency_T = str


class CodeCell(typing.NamedTuple):
    """Passive object with code, label and dependencies attributes"""
    code: CodeText_T
    label: Label_T
    dependencies: list[Dependency_T]


CodeCellCollection_T = dict[str, CodeCell]
CodeCellIterator_T = typing.Iterator[CodeCell]


def entangle_cells(cell_collection: CodeCellCollection_T) -> CodeCellIterator_T:
    """ Entangles a collection of code cells (depth first tree visit)"""

    collection = cell_collection.copy()

    def _entangle_cell(current_label) -> CodeCellIterator_T:
        """ visit cell depencies and cell """

        current_cell = collection.pop(current_label)

        for dependency in current_cell.dependencies:
            if dependency in collection:
                yield from _entangle_cell(dependency)

        yield current_cell

    while collection:
        yield from _entangle_cell(next(iter(collection)))


def entangle_cells_for(

    cell_collection: CodeCellCollection_T,
    *only_these_labels: Label_T

) -> CodeCellIterator_T:
    """ Entangles a collection of code cells for selected labels only"""

    collection = cell_collection.copy()

    def _entangle_cells(*_labels) -> CodeCellIterator_T:
        """ visit cell depencies and cell """
        if not _labels:
            return

        head, *tail = _labels
        if head in collection:
            current_cell = collection.pop(head)
            yield from _entangle_cells(*current_cell.dependencies)
            yield current_cell

        if tail:
            yield from _entangle_cells(*tail)

    yield from _entangle_cells(*only_these_labels)


_missing_dependency_T = collections.namedtuple("missing_dependency", ["label", "dependency"])


def validate_cell_sequence(
    cell_sequence: typing.Iterable[CodeCell]
) -> typing.Iterator[_missing_dependency_T]:

    seen = set()
    for cell in cell_sequence:
        seen.add(cell.label)
        for dependency in cell.dependencies:
            if dependency not in seen:
                yield _missing_dependency_T(cell.label, dependency)
    if not seen:
        yield _missing_dependency_T("", "")


CodeCellSequenceProcessor_T = typing.Callable[[CodeCellIterator_T], CodeCellIterator_T]


class CellCollection(typing.NamedTuple):
    update: typing.Callable[[str, str, list[str]], CodeCellIterator_T]
    travel: typing.Callable[[CodeCellSequenceProcessor_T], CodeCellIterator_T]


def create_cell_collection() -> CellCollection:

    logger = logging.getLogger(__name__)

    cell_collection = CodeCellCollection_T()
    failed = set[Label_T]()

    def recover_failed() -> CodeCellIterator_T:
        for cell in entangle_cells(cell_collection):
            if cell.label in failed:
                if not any(validate_cell_sequence(
                        entangle_cells_for(cell_collection, cell.label))):
                    failed.remove(cell.label)
                    yield cell

    def update_collection(

            code: CodeText_T,
            label: Label_T,
            dependencies: list[Dependency_T]

    ) -> CodeCellIterator_T:

        cell_collection[label] = CodeCell(code, label, dependencies)

        failed.add(label)
        yield from recover_failed()

    def travel_collection(

            visit_sequence: CodeCellSequenceProcessor_T,
            *labels: Label_T

    ) -> CodeCellIterator_T:

        if labels:
            yield from visit_sequence(entangle_cells_for(cell_collection, *labels))

        else:
            yield from visit_sequence(entangle_cells(cell_collection))

    return CellCollection(update_collection, travel_collection)


CodeCellTextTransformer_T = typing.Callable[[CodeCell], CodeText_T]
FilePath_T = str


def create_file_writer(
        filepath: FilePath_T,
        cell_process: CodeCellTextTransformer_T = lambda c: str(c.code),
        post_process: typing.Callable[[FilePath_T], None] = lambda f: None,

) -> CodeCellSequenceProcessor_T:

    os.makedirs(os.path.split(filepath)[0], exist_ok=True)

    def write_sequence(code_cells: CodeCellIterator_T) -> CodeCellIterator_T:

        with open(filepath, 'w') as f:
            for cell in code_cells:
                f.write(cell_process(cell))
                yield cell

        post_process(filepath)

    return write_sequence


def create_export_cell_code_visitor() -> CodeCellTextTransformer_T:
    first_cell = True

    def cell_to_text(cell: CodeCell) -> str:
        nonlocal first_cell
        if first_cell:
            first_cell = False
            return f'{cell.code}\n'
        elif len(cell.code.splitlines()) > 2:
            return f'\n\n# %% {cell.label} '.ljust(72, '-') + f'\n{cell.code}\n'
        else:
            return f'{cell.code}\n'

    return cell_to_text


def create_export_test_visitor(report: typing.Callable) -> CodeCellTextTransformer_T:
    seen_cells = set[Label_T]()

    def visit(cell: CodeCell) -> str:
        nonlocal seen_cells

        seen_cells.add(cell.label)
        missing_dependencies = set(cell.dependencies) - seen_cells

        report(cell.label, *missing_dependencies)

    def travel(code_cells: CodeCellIterator_T) -> CodeCellIterator_T:
        for cell in code_cells:
            visit(cell)
            yield cell

    return travel


def create_cell_analysis_traveler(

        unused_cells: set[Label_T],
        missing_deps: set[Label_T]

) -> CodeCellSequenceProcessor_T:

    seen_cells = set[Label_T]()

    def visit(cell: CodeCell):
        nonlocal unused_cells, missing_deps, seen_cells

        seen_cells.add(cell.label)
        unused_cells.add(cell.label)

        deps = set(cell.dependencies)
        unused_cells -= deps
        missing_deps |= (deps - seen_cells)

    def travel(code_cells: CodeCellIterator_T) -> CodeCellIterator_T:
        for cell in code_cells:
            visit(cell)
            yield cell

    return travel


def create_entangler_creation_parser() -> argparse.ArgumentParser:
    """Creates a parser for the entangler"""
    parser = argparse.ArgumentParser(f'%tangle', exit_on_error=False, add_help=True, suggest_on_error=True)
    parser.add_argument('-f', '--fix', help='Fix/reFormat code after tangling', action='store_true')
    parser.add_argument('-l', '--lib', action='store', help='lib directory name if not in module-path', default="")
    parser.add_argument('modulepath', nargs='?', help='the label for the code cell')

    return parser


def create_entangler_line_argument_parser() -> argparse.ArgumentParser:
    """Creates a parser for the entangler"""
    parser = argparse.ArgumentParser(f'%tangle', exit_on_error=False, add_help=True, suggest_on_error=True)
    parser.add_argument('-r', '--report', help='report unused and missing dependencies', action='store_true')
    parser.add_argument('-e', '--export', help='export code cells', action='store_true')
    parser.add_argument('-m', '--missing', help='list missing dependencies', action='store_true')
    parser.add_argument('labels', nargs='*', help='the labels of code cells (all if omitted)')

    return parser


def create_entangler_cell_argument_parser() -> argparse.ArgumentParser:
    """Creates a parser for the entangler"""
    parser = argparse.ArgumentParser(f'%%entangle', exit_on_error=False, add_help=True, suggest_on_error=True)
    parser.add_argument('-f', '--fix', help='Fix/reFormat code', action='store_true')
    parser.add_argument('label', nargs='?', help='the label for the code cell')
    parser.add_argument('dependencies', nargs='*', help='the dependencies for the code cell')

    return parser


@magics_class
class TangleMagic(Magics):

    def __init__(self, shell, **kwargs):
        super(TangleMagic, self).__init__(shell)

        self.cell_parser = create_entangler_cell_argument_parser()
        self.line_parser = create_entangler_line_argument_parser()
        self.create_parser = create_entangler_creation_parser()

        self.fix = kwargs.get("fix", False)
        self.filename = kwargs.get("filename", "")
        self.collection = create_cell_collection()

    def parse_args(self, parser: ArgumentParser, line: str):
        try:
            return parser.parse_args(split_line_args(line))
        except Exception as err:
            logging.getLogger(__name__).exception(f"Yikes, something ({err}) went wrong parsing your input...", exc_info=False)

        # parser.print_help()

    def update_collection(self, cell, label, dependencies, fix):
        yield from self.collection.update(
            autopep8.fix_code(cell) if fix else cell,
            label, dependencies
        )

    def export_collection(self, *labels):
        collections.deque(self.collection.travel(
            create_file_writer(
                self.filename,
                create_export_cell_code_visitor(),
                run_fixer if self.fix else lambda f: None,
            ),
            *labels
        ), 0)

    def test_missing(self, *labels):

        def report(label, *missing):
            left_kol = f"{label:<20}"
            right_kol = ""
            for dep in missing:
                if len(right_kol) + len(dep) < 39:
                    right_kol = " ".join([right_kol, dep])
                else:
                    print(f"{left_kol} - {right_kol}")
                    left_kol = f"{' ':<20}"
                    right_kol = f"{dep}"
            if right_kol:
                print(f"{left_kol} - {right_kol}")

        collections.deque(self.collection.travel(
            create_export_test_visitor(report),
            *labels
        ), 0)

    def list_collection(self, *labels):
        """Lists missing dependencies and unused cells"""
        unused_cells = set[Label_T]()
        missing_deps = set[Label_T]()

        collections.deque(self.collection.travel(
            create_cell_analysis_traveler(unused_cells, missing_deps),
            *labels
        ), 0)

        if unused_cells:
            print("Cells not used as dependency:")
            print(unused_cells)
        if missing_deps:
            print("Missing dependencies:")
            print(missing_deps)

    @line_magic
    def tangle(self, line):
        # Line operation -> controls

        if self.filename:
            args = self.parse_args(self.line_parser, line)
            if args is not None:

                if args.export:
                    self.export_collection(*args.labels)

                elif args.report:
                    self.list_collection(*args.labels)

                elif args.missing:
                    self.test_missing(*args.labels)

            else:
                self.line_parser.print_help()

        else:
            args = self.parse_args(self.create_parser, line)
            if args is not None and args.modulepath is not None:
                if not self.filename:
                    self.filename = extract_module_filepath(args.modulepath, args.lib)
                    self.fix = args.fix
                    print(f"Collection now inititalized for {self.filename}")

                else:
                    print(f"Collection already inititalized for {self.filename}")

            else:
                self.create_parser.print_help()

    @cell_magic
    def entangle(self, line: str, cell: str):
        "Entangles a code cell"

        args = self.parse_args(self.cell_parser, line)
        if args is not None and args.label:
            for c in self.update_collection(cell, args.label, args.dependencies, args.fix):
                try:
                    self.shell.run_cell(c.code)
                except Exception as err:
                    syslog.exception(f"Caught exception {err}\n")

        else:
            self.cell_parser.print_help()


def load_ipython_extension(ipython):
    ipython.register_magics(TangleMagic)
