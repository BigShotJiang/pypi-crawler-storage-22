
import json
import typing
print("Imported modules, now going to print some text")
if True:
    print(
        'Some long', 'text to ', 'see how', 'parameters', ' will', ' be', 'spread', 'over', 'multiple lines'
    )


# %% foo -------------------------------------------------------------

print("Trying foo again")


def foo():
    print('function foo() called')


# %% bar -------------------------------------------------------------
print("Running in cell bar, calling foo()")
foo()


def bar():
    print('function bar() called')


print("Running in eof")
# end-of-file ---------------------------------------------------------
