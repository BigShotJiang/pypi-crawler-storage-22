import json
import typing
print("Imported some modules")


# %% foo -------------------------------------------------------------

print("Running in cell foo")


def foo():
    print('function foo() called')


# %% bar -------------------------------------------------------------
print("Running in cell bar, calling foo()")

foo()


def bar():
    print('function bar() called')


print("Running in eof")
# end-of-file ---------------------------------------------------------
