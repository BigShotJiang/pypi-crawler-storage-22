## Ansaetze

```python
from qml_essentials.ansaetze import Ansaetze
```

::: qml_essentials.ansaetze.Ansaetze
    options:
      heading_level: 3

## Gates

As the structure of the different classes used to realize pulse and unitary gates can be a bit confusing, the following diagram might help:

![Gate Structure](figures/pulses_structure_light.png#center#only-light)
![Gate Structure](figures/pulses_structure_dark.png#center#only-dark)

```python
from qml_essentials.ansaetze import Gates
```

::: qml_essentials.ansaetze.Gates
    options:
      heading_level: 3

```python
from qml_essentials.ansaetze import UnitaryGates
```

### Unitary Gates

::: qml_essentials.ansaetze.UnitaryGates
    options:
      heading_level: 4

### Pulse Gates

```python
from qml_essentials.ansaetze import PulseGates
```

::: qml_essentials.ansaetze.PulseGates
    options:
      heading_level: 4

### Pulse Structure

```python
from qml_essentials.ansaetze import PulseParams
```

::: qml_essentials.ansaetze.PulseParams
    options:
      heading_level: 4

## Model

```python
from qml_essentials.model import Model
```

::: qml_essentials.model.Model
    options:
      heading_level: 3

## Entanglement

```python
from qml_essentials.entanglement import Entanglement
```

::: qml_essentials.entanglement.Entanglement
    options:
      heading_level: 3

## Expressibility

```python
from qml_essentials.expressibility import Expressibility
```

::: qml_essentials.expressibility.Expressibility
    options:
      heading_level: 3

## Coefficients

```python
from qml_essentials.coefficients import Coefficients
```

::: qml_essentials.coefficients.Coefficients
    options:
      heading_level: 3