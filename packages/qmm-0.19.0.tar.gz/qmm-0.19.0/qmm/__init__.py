__version__ = "0.19.0"
__version_info__ = tuple(int(elem) for elem in __version__.split("."))

from .qmm import *
