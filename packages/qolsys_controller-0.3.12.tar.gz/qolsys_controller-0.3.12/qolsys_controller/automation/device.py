import logging
from abc import ABC
from typing import TYPE_CHECKING

from qolsys_controller.automation.protocol_battery import BatteryProtocol
from qolsys_controller.automation.protocol_lock import LockProtocol
from qolsys_controller.automation.protocol_service import ServiceProtocol
from qolsys_controller.automation.service import AutomationService
from qolsys_controller.automation_powerg.service_battery import BatteryServicePowerG
from qolsys_controller.automation_powerg.service_lock import LockServicePowerG
from qolsys_controller.enum import AutomationDeviceProtocol
from qolsys_controller.observable import QolsysObservable

if TYPE_CHECKING:
    from qolsys_controller.controller import QolsysController

LOGGER = logging.getLogger(__name__)


class QolsysAutomationDevice(QolsysObservable, ABC):
    def __init__(self, controller: "QolsysController", dict: dict[str, str]) -> None:
        super().__init__()

        self._controller: QolsysController = controller

        # Main device identifier
        self._virtual_node_id: str = dict.get("virtual_node_id", "")

        self._id: str = dict.get("_id", "")
        self._partition_id: str = dict.get("partition_id", "")
        self._device_id: str = dict.get("device_id", "")
        self._device_name: str = dict.get("device_name", "")
        self._device_type: str = dict.get("device_type", "")
        self._protocol: str = dict.get("protocol", "")
        self._state: str = dict.get("state", "")
        self._status: str = dict.get("status", "")
        self._version: str = dict.get("version", "")
        self._end_point: str = dict.get("end_point", "")
        self._is_autolocking_enabled: str = dict.get("is_autolocking_enabled", "")
        self._endpoint_secure_cmd_classes: str = dict.get("endpoint_secure_cmd_classes", "")
        self._automation_id: str = dict.get("automation_id", "")
        self._node_battery_level_value: str = dict.get("node_battery_level_value", "")
        self._last_updated_date: str = dict.get("last_updated_date", "")
        self._manufacturer_id: str = dict.get("manufacturer_id", "")
        self._endpoint_cmd_classes: str = dict.get("endpoint_cmd_classes", "")
        self._nodeid_cmd_classes: str = dict.get("nodeid_cmd_classes", "")
        self._is_device_hidden: str = dict.get("is_device_hidden", "")
        self._nodeid_secure_cmd_classes: str = dict.get("nodeid_secure_cmd_classes", "")
        self._created_date: str = dict.get("created_date", "")
        self._smart_energy_optimizer: str = dict.get("smart_energy_optimizer", "")
        self._linked_security_zone: str = dict.get("linked_security_zone", "")

        self._services: list[AutomationService] = []

    def service_add(self, service: AutomationService) -> None:
        if not isinstance(service, ServiceProtocol):
            LOGGER.error(
                "AutomationDevice%s [%s] (%s) - Unable to add Service (not a ServiceProtocol): %s",
                self.virtual_node_id,
                self.protocol,
                self.device_name,
                type(service),
            )
            return

        if isinstance(service, BatteryProtocol):
            self._services.append(service)
            LOGGER.debug(
                "AutomationDevice%s [%s] (%s) - Adding Battery Service ",
                self.virtual_node_id,
                self.protocol,
                self.device_name,
            )
            return

        if isinstance(service, LockProtocol):
            self._services.append(service)
            LOGGER.debug(
                "AutomationDevice%s [%s] (%s) - Adding Lock Service ",
                self.virtual_node_id,
                self.protocol,
                self.device_name,
            )
            return

        LOGGER.error(
            "AutomationDevice%s [%s] (%s) - Unable to add Service (unknown type): %s",
            self.virtual_node_id,
            self.protocol,
            self.device_name,
            type(service),
        )

    def service_add_lock_service(self) -> None:
        lock_service: AutomationService | None = None
        if self.protocol == AutomationDeviceProtocol.POWERG:
            lock_service = LockServicePowerG(self)

        if lock_service is not None:
            self._services.append(lock_service)
            return

        LOGGER.error(
            "AutomationDevice%s [%s] (%s) - Unable to add Lock Service",
            self.virtual_node_id,
            self.protocol,
            self.device_name,
        )

    def service_add_battery_service(self) -> None:
        battery_service: AutomationService | None = None
        if self.protocol == AutomationDeviceProtocol.POWERG:
            battery_service = BatteryServicePowerG(automation_device=self)

        if self.protocol == AutomationDeviceProtocol.Z_WAVE:
            battery_service = BatteryServicePowerG(automation_device=self)

        if battery_service is not None:
            self.service_add(battery_service)
            return

        LOGGER.error(
            "AutomationDevice%s [%s] (%s) - Unable to add Battery Service",
            self.virtual_node_id,
            self.protocol,
            self.device_name,
        )

    def update_automation_device(self, data: dict[str, str]) -> None:
        # Check if we are updating same virtual_node_id
        virtual_node_id_update = data.get("virtual_node_id", "")
        if virtual_node_id_update != self._virtual_node_id:
            LOGGER.error(
                "Updating AutomationDevice%s (%s) with %s (different virtual_node_id)",
                self._virtual_node_id,
                self._device_name,
                virtual_node_id_update,
            )
            return

        self.start_batch_update()

        if "device_name" in data:
            self._device_name = data.get("device_name", "")

        if "partition_id" in data:
            self._partition_id = data.get("partition_id", "")

        if "state" in data:
            self._state = data.get("state", "")

        if "status" in data:
            self._status = data.get("status", "")

        self.end_batch_update()

    # -----------------------------
    # properties + setters
    # -----------------------------

    @property
    def device_id(self) -> str:
        return self._device_id

    @device_id.setter
    def device_id(self, value: str) -> None:
        if self._device_id != value:
            LOGGER.debug("AutomationDevice%s (%s) - device_id: %s", self.device_id, self.device_name, value)
            self._device_id = value
            self.notify()

    @property
    def virtual_node_id(self) -> str:
        return self._virtual_node_id

    @virtual_node_id.setter
    def virtual_node_id(self, value: str) -> None:
        if self._virtual_node_id != value:
            LOGGER.debug("AutomationDevice%s (%s) - virtual_node_id: %s", self.device_id, self.device_name, value)
            self._virtual_node_id = value
            self.notify()

    @property
    def partition_id(self) -> str:
        return self._partition_id

    @partition_id.setter
    def partition_id(self, value: str) -> None:
        if self._partition_id != value:
            LOGGER.debug("AutomationDevice%s (%s) - partition_id: %s", self.device_id, self.device_name, value)
            self._partition_id = value
            self.notify()

    @property
    def state(self) -> str:
        return self._state

    @state.setter
    def state(self, value: str) -> None:
        if self._state != value:
            LOGGER.debug("AutomationDevice%s (%s) - state: %s", self.device_id, self.device_name, value)
            self._state = value
            self.notify()

    @property
    def status(self) -> str:
        return self._status

    @status.setter
    def status(self, value: str) -> None:
        if self._status != value:
            LOGGER.debug("AutomationDevice%s (%s) - status: %s", self.device_id, self.device_name, value)
            self._status = value
            self.notify()

    @property
    def device_name(self) -> str:
        return self._device_name

    @device_name.setter
    def device_name(self, value: str) -> None:
        if self._device_name != value:
            LOGGER.debug("AutomationDevice%s (%s) - device_name: %s", self.device_id, self.device_name, value)
            self._device_name = value
            self.notify()

    @property
    def device_type(self) -> str:
        return self._device_type

    @device_type.setter
    def device_type(self, value: str) -> None:
        if self._device_type != value:
            LOGGER.debug("AutomationDevice%s (%s) - device_type: %s", self.device_id, self.device_name, value)
            self._device_type = value
            self.notify()

    @property
    def protocol(self) -> str:
        try:
            return AutomationDeviceProtocol(self._protocol)
        except ValueError:
            return AutomationDeviceProtocol.UNKNOWN

    @protocol.setter
    def protocol(self, value: str) -> None:
        if self._protocol != value:
            LOGGER.debug("AutomationDevice%s (%s) - protocol: %s", self.device_id, self.device_name, value)
            self._protocol = value
            self.notify()

    def to_dict(self) -> dict[str, str]:
        return {
            "_id": self._id,
            "virtual_node_id": self._virtual_node_id,
            "partition_id": self._partition_id,
            "device_id": self._device_id,
            "device_name": self._device_name,
            "device_type": self._device_type,
            "protocol": self._protocol,
            "state": self._state,
            "status": self._status,
            "version": self._version,
            "end_point": self._end_point,
            "is_autolocking_enabled": self._is_autolocking_enabled,
            "endpoint_secure_cmd_classes": self._endpoint_secure_cmd_classes,
            "automation_id": self._automation_id,
            "node_battery_level_value": self._node_battery_level_value,
            "last_updated_date": self._last_updated_date,
            "manufacturer_id": self._manufacturer_id,
            "endpoint_cmd_classes": self._endpoint_cmd_classes,
            "nodeid_cmd_classes": self._nodeid_cmd_classes,
            "is_device_hidden": self._is_device_hidden,
            "nodeid_secure_cmd_classes": self._nodeid_secure_cmd_classes,
            "created_date": self._created_date,
            "smart_energy_optimizer": self._smart_energy_optimizer,
        }
