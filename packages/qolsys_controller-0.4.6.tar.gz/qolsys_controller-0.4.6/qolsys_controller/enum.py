from enum import StrEnum


class QolsysEvent(StrEnum):
    EVENT_PANEL_PARTITION_ADD = "EVENT_PANEL_PARTITION_ADD"
    EVENT_PANEL_ZONE_ADD = "EVENT_PANEL_ZONE_ADD"
    EVENT_PANEL_DOORBELL = "EVENT_PANEL_DOORBELL"
    EVENT_PANEL_CHIME = "EVENT_PANEL_CHIME"
    EVENT_ZWAVE_DEVICE_ADD = "EVENT_ZWAVE_MULTILEVELSENSOR_ADD"
    EVENT_ZWAVE_MULTILEVELSENSOR_ADD = "EVENT_ZWAVE_MULTILEVELSENSOR_ADD"
    EVENT_ZWAVE_METER_ADD = "EVENT_ZWAVE_METER_ADD"


class PartitionSystemStatus(StrEnum):
    ARM_STAY = "ARM-STAY"
    ARM_AWAY = "ARM-AWAY"
    ARM_NIGHT = "ARM-NIGHT"
    DISARM = "DISARM"
    ARM_AWAY_EXIT_DELAY = "ARM-AWAY-EXIT-DELAY"
    ARM_STAY_EXIT_DELAY = "ARM-STAY-EXIT-DELAY"
    ARM_NIGHT_EXIT_DELAY = "ARM-NIGHT-EXIT-DELAY"
    UNKNOWN = "UNKNOWN"


class PartitionArmingType(StrEnum):
    ARM_STAY = "ui_armstay"
    ARM_AWAY = "ui_armaway"
    ARM_NIGHT = "ui_armnight"


class PartitionAlarmState(StrEnum):
    NONE = "None"
    DELAY = "Delay"
    ALARM = "Alarm"
    UNKNOWN = "UNKNOWN"


class PartitionAlarmType(StrEnum):
    POLICE_EMERGENCY = "Police Emergency"
    FIRE_EMERGENCY = "Fire Emergency"
    AUXILIARY_EMERGENCY = "Auxiliary Emergency"
    SILENT_AUXILIARY_EMERGENCY = "Silent Auxiliary Emergency"
    SILENT_POLICE_EMERGENCY = "Silent Police Emergency"
    GLASS_BREAK_AWAY_ONLY = "glassbreakawayonly"
    GLASS_BREAK = "glassbreak"
    ENTRY_EXIT_NORMAL_DELAY = "entryexitdelay"
    ENTRY_EXIT_LONG_DELAY = "entryexitlongdelay"
    INSTANT_PERIMETER_DW = "instantperimeter"
    INSTANT_INTERIOR_DOOR = "instantinterior"
    AWAY_INSTANT_FOLLOWER_DELAY = "awayinstantfollowerdelay"
    REPORTING_SAFETY_SENSOR = "reportingsafety"
    DELAYED_REPORTING_SAFETY_SENSOR = "delayedreportingsafety"
    AWAY_INSTANT_MOTION = "awayinstantmotion"
    STAY_INSTANT_MOTION = "stayinstantmotion"
    STAY_DELAY_MOTION = "staydelaymotion"
    AWAY_DELAY_MOTION = "awaydelaymotion"
    EMPTY = ""


class ZoneStatus(StrEnum):
    ACTIVE = "Active"
    ACTIVATED = "Activated"
    ALARMED = "Alarmed"
    ARM_AWAY = "Arm-Away"
    ARM_STAY = "Arm-Stay"
    BELL_TROUBLE = "Bell Trouble"
    CLOSED = "Closed"
    CONNECTED = "connected"
    DISARM = "Disarm"
    OPEN = "Open"
    INACTIVE = "Inactive"
    IDLE = "Idle"
    NORMAL = "Normal"
    UNREACHABLE = "Unreachable"
    TAMPERED = "Tampered"
    SYNCHRONIZING = "Synchronizing"
    DISCONNECTED = "disconnected"
    FAILURE = "Failure"
    NOT_NETWORKED = "Not Networked"


class DeviceCapability(StrEnum):
    SRF = "SRF"
    WIFI = "WiFi"
    POWERG = "POWERG"
    ZWAVE = "Z-Wave"
    S_LINE = "S-Line"


class AutomationDeviceProtocol(StrEnum):
    ADC = "ADC"
    POWERG = "PowerG"
    ZWAVE = "Z-Wave"
    UNKNOWN = "Unknown"


class ZoneSensorType(StrEnum):
    AUXILIARY_PENDANT = "Auxiliary Pendant"
    BLUETOOTH = "Bluetooth"
    CO_DETECTOR = "CODetector"
    DOORBELL = "Doorbell"
    DOOR_WINDOW = "Door_Window"
    DOOR_WINDOW_M = "Door_Window_M"
    FREEZE = "Freeze"
    GLASS_BREAK = "GlassBreak"
    HEAT = "Heat"
    HIGH_TEMPERATURE = "High Temperature"
    KEY_FOB = "KeyFob"
    KEYPAD = "Keypad"
    MOTION = "Motion"
    OCCUPANCY = "Occupancy Sensor"
    PANEL_GLASS_BREAK = "Panel Glass Break"
    PANEL_MOTION = "Panel Motion"
    SIREN = "Siren"
    SHOCK = "Shock"
    SMOKE_DETECTOR = "SmokeDetector"
    SMOKE_M = "Smoke_M"
    TAKEOVER_MODULE = "TakeoverModule"
    TAMPER = "Tamper Sensor"
    TEMPERATURE = "Temperature"
    TILT = "Tilt"
    TRANSLATOR = "Translator"
    UNKNOWN = "Unknown"
    WATER = "Water"


class ZoneSensorGroup(StrEnum):
    CO = "co"
    FIXED_INTRUSION = "fixedintrusion"
    FIXED_SILENT = "fixedsilentkey"
    MOBILE_INTRUSION = "mobileintrusion"
    MOBILE_SILENT = "mobilesilentkey"
    FIXED_AUXILIARY = "fixedmedical"
    FIXED_SILENT_AUXILIARY = "fixedsilentmedical"
    LOCAL_SAFETY_SENSOR = "localsafety"
    MOBILE_AUXILIARY = "mobilemedical"
    MOBILE_SILENT_AUXILIARY = "mobilesilentmedical"
    SAFETY_MOTION = "safetymotion"
    GLASS_BREAK = "glassbreak"
    GLASS_BREAK_AWAY_ONLY = "glassbreakawayonly"
    SMOKE_HEAT = "smoke_heat"
    TAMPER_ZONE = "tamperzone"
    SHOCK = "shock"
    ENTRY_EXIT_NORMAL_DELAY = "entryexitdelay"
    ENTRY_EXIT_LONG_DELAY = "entryexitlongdelay"
    INSTANT_PERIMETER_DW = "instantperimeter"
    INSTANT_INTERIOR_DOOR = "instantinterior"
    AWAY_INSTANT_FOLLOWER_DELAY = "awayinstantfollowerdelay"
    REPORTING_SAFETY_SENSOR = "reportingsafety"
    DELAYED_REPORTING_SAFETY_SENSOR = "delayedreportingsafety"
    AWAY_INSTANT_MOTION = "awayinstantmotion"
    STAY_INSTANT_MOTION = "stayinstantmotion"
    STAY_DELAY_MOTION = "staydelaymotion"
    AWAY_DELAY_MOTION = "awaydelaymotion"
    WATER = "WaterSensor"


class ZWaveNodeStatus(StrEnum):
    NORMAL = "Normal"
    UNREACHABLE = "Unreachable"


class QolsysHvacMode(StrEnum):
    OFF = "off"
    HEAT = "heat"
    COOL = "cool"
    AUTO = "auto"
    HEAT_COOL = "heat_cool"
    FAN_ONLY = "fan_only"
    DRY = "dry"


class QolsysFanMode(StrEnum):
    FAN_ON = "on"
    FAN_OFF = "off"
    FAN_AUTO = "auto"
    FAN_LOW = "low"
    FAN_MEDIUM = "medium"
    FAN_HIGH = "high"
    FAN_CIRCULATE = "circulate"


class QolsysHvacAction(StrEnum):
    OFF = "off"
    PREHEATING = "preheating"
    HEATING = "heating"
    COOLING = "cooling"
    DRYING = "drying"
    FAN = "fan"
    IDLE = "idle"
    DEFROSTING = "defrosting"


class QolsysTemperatureUnit(StrEnum):
    CELSIUS = "C"
    FAHRENHEIT = "F"
