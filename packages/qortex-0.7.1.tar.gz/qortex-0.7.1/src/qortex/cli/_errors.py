"""CLI error handling and decorators."""

from __future__ import annotations

import functools
import logging
from collections.abc import Callable
from typing import Any

import typer

from qortex.cli._config import get_config

logger = logging.getLogger(__name__)

# Module-level holder for the connected backend (set by require_memgraph)
_current_backend: Any = None


def get_backend() -> Any:
    """Get the backend set by the require_memgraph decorator."""
    return _current_backend


def require_memgraph(f: Callable) -> Callable:
    """Decorator that checks Memgraph connectivity before running a command.

    If Memgraph is not reachable, prints a helpful error and exits.
    Sets the backend accessible via get_backend().
    """

    @functools.wraps(f)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        global _current_backend
        config = get_config()
        try:
            from qortex.core.backend import MemgraphBackend, MemgraphCredentials

            # Convert CLI credentials to backend credentials
            creds = MemgraphCredentials.from_tuple(config.memgraph_credentials.auth_tuple)
            backend = MemgraphBackend(
                uri=config.get_memgraph_uri(),
                credentials=creds,
            )
            backend.connect()
        except Exception:
            logger.debug("Memgraph connection failed", exc_info=True)
            uri = config.get_memgraph_uri()
            typer.echo(
                f"Could not connect to Memgraph at {uri}.\n"
                f"\n"
                f"Start it with: qortex infra up\n"
                f"Or check: qortex infra status",
                err=True,
            )
            raise typer.Exit(1)
        _current_backend = backend
        return f(*args, **kwargs)

    return wrapper


def handle_error(msg: str) -> None:
    """Print an error message and exit."""
    typer.echo(f"Error: {msg}", err=True)
    raise typer.Exit(1)
