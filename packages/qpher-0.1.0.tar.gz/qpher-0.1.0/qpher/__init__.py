"""Qpher Python SDK - Official client for the Qpher Post-Quantum Cryptography API."""

from qpher.client import Qpher
from qpher.errors import (
    QpherError,
    AuthenticationError,
    RateLimitError,
    NotFoundError,
    ValidationError,
    ForbiddenError,
    ServerError,
    TimeoutError,
    ConnectionError,
)
from qpher.types import (
    EncryptResult,
    DecryptResult,
    SignResult,
    VerifyResult,
    KeyInfo,
    KeyListResult,
    RotateResult,
    GenerateResult,
    RetireResult,
)
from qpher._version import __version__

__all__ = [
    # Main client
    "Qpher",
    # Errors
    "QpherError",
    "AuthenticationError",
    "RateLimitError",
    "NotFoundError",
    "ValidationError",
    "ForbiddenError",
    "ServerError",
    "TimeoutError",
    "ConnectionError",
    # Types
    "EncryptResult",
    "DecryptResult",
    "SignResult",
    "VerifyResult",
    "KeyInfo",
    "KeyListResult",
    "RotateResult",
    "GenerateResult",
    "RetireResult",
    # Version
    "__version__",
]
