"""Main Qpher client class."""

from qpher.http_client import _HttpClient
from qpher.kem import KEMModule
from qpher.signatures import SignaturesModule
from qpher.keys import KeysModule

DEFAULT_BASE_URL = "https://api.qpher.ai"
DEFAULT_TIMEOUT = 30
DEFAULT_MAX_RETRIES = 3


class Qpher:
    """Qpher PQC API client.

    Args:
        api_key: Your Qpher API key (starts with "qph_").
        base_url: API base URL. Defaults to "https://api.qpher.ai".
        timeout: Request timeout in seconds. Defaults to 30.
        max_retries: Max retries for transient errors (429, 502, 503, 504). Defaults to 3.

    Example:
        >>> from qpher import Qpher
        >>> client = Qpher(api_key="qph_live_abc123")
        >>> result = client.kem.encrypt(plaintext=b"Hello!", key_version=1)
        >>> print(result.ciphertext)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        if not api_key.startswith("qph_"):
            raise ValueError("api_key must start with 'qph_'")

        self._http = _HttpClient(
            api_key=api_key,
            base_url=base_url.rstrip("/"),
            timeout=timeout,
            max_retries=max_retries,
        )

        self.kem = KEMModule(self._http)
        self.signatures = SignaturesModule(self._http)
        self.keys = KeysModule(self._http)
