"""Internal HTTP client with authentication, retries, and error handling."""

import time
from typing import Any, Dict, Optional

import requests

from qpher._version import __version__
from qpher.errors import QpherError, _parse_error_response


RETRYABLE_STATUS_CODES = {429, 502, 503, 504}


class _HttpClient:
    """Internal HTTP client with authentication, retries, and error handling."""

    def __init__(
        self,
        api_key: str,
        base_url: str,
        timeout: int,
        max_retries: int,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url
        self._timeout = timeout
        self._max_retries = max_retries
        self._session = requests.Session()
        self._session.headers.update(
            {
                "x-api-key": api_key,
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": f"qpher-python/{__version__}",
            }
        )

    def request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make an HTTP request with retries.

        Returns the parsed JSON response body.
        Raises QpherError on API errors.
        """
        url = f"{self._base_url}{path}"
        last_exception: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                response = self._session.request(
                    method=method,
                    url=url,
                    json=json,
                    params=params,
                    timeout=self._timeout,
                )

                if response.status_code >= 400:
                    error = _parse_error_response(response)
                    if (
                        response.status_code in RETRYABLE_STATUS_CODES
                        and attempt < self._max_retries
                    ):
                        last_exception = error
                        self._backoff(attempt)
                        continue
                    raise error

                return response.json()

            except requests.exceptions.Timeout as e:
                last_exception = e
                if attempt < self._max_retries:
                    self._backoff(attempt)
                    continue
                from qpher.errors import TimeoutError

                raise TimeoutError(
                    message="Request timed out",
                    error_code="ERR_TIMEOUT_001",
                    status_code=504,
                    request_id=None,
                ) from e

            except requests.exceptions.ConnectionError as e:
                last_exception = e
                if attempt < self._max_retries:
                    self._backoff(attempt)
                    continue
                from qpher.errors import ConnectionError

                raise ConnectionError(
                    message="Connection failed",
                    error_code="ERR_SERVICE_001",
                    status_code=503,
                    request_id=None,
                ) from e

        # Should not reach here, but just in case
        if last_exception:
            if isinstance(last_exception, QpherError):
                raise last_exception
            raise RuntimeError("Unexpected retry loop exit") from last_exception
        raise RuntimeError("Unexpected retry loop exit")

    def get(
        self, path: str, params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Make a GET request."""
        return self.request("GET", path, params=params)

    def post(
        self, path: str, json: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Make a POST request."""
        return self.request("POST", path, json=json)

    @staticmethod
    def _backoff(attempt: int) -> None:
        """Exponential backoff: 0.5s, 1s, 2s, ..."""
        delay = 0.5 * (2**attempt)
        time.sleep(min(delay, 10))
