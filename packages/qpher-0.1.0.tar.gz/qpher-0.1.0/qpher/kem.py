"""Kyber768 KEM encrypt/decrypt operations."""

import base64
from typing import Optional

from qpher.http_client import _HttpClient
from qpher.types import EncryptResult, DecryptResult


class KEMModule:
    """Kyber768 KEM encrypt/decrypt operations.

    All binary data (plaintext, ciphertext) is automatically
    base64-encoded for the wire and decoded in results.
    """

    def __init__(self, http: _HttpClient) -> None:
        self._http = http

    def encrypt(
        self,
        plaintext: bytes,
        key_version: int,
        mode: str = "standard",
        salt: Optional[bytes] = None,
    ) -> EncryptResult:
        """Encrypt data using Kyber768 KEM.

        Args:
            plaintext: Data to encrypt (max 1MB).
            key_version: Active key version to use.
            mode: "standard" (default) or "deterministic".
            salt: Required if mode="deterministic" (min 32 bytes).

        Returns:
            EncryptResult with ciphertext bytes and metadata.

        Raises:
            ValidationError: If parameters are invalid.
            NotFoundError: If key_version not found.
        """
        body = {
            "plaintext": base64.b64encode(plaintext).decode("ascii"),
            "key_version": key_version,
            "mode": mode,
        }
        if salt is not None:
            body["salt"] = base64.b64encode(salt).decode("ascii")

        resp = self._http.post("/api/v1/kem/encrypt", json=body)
        data = resp["data"]

        return EncryptResult(
            ciphertext=base64.b64decode(data["ciphertext"]),
            key_version=data["key_version"],
            algorithm=data["algorithm"],
            request_id=resp["request_id"],
        )

    def decrypt(
        self,
        ciphertext: bytes,
        key_version: int,
    ) -> DecryptResult:
        """Decrypt data using Kyber768 KEM.

        Args:
            ciphertext: Encrypted data from encrypt().
            key_version: Key version used during encryption.

        Returns:
            DecryptResult with plaintext bytes and metadata.

        Raises:
            ValidationError: If ciphertext is invalid.
            NotFoundError: If key_version not found.
        """
        body = {
            "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
            "key_version": key_version,
        }

        resp = self._http.post("/api/v1/kem/decrypt", json=body)
        data = resp["data"]

        return DecryptResult(
            plaintext=base64.b64decode(data["plaintext"]),
            key_version=data["key_version"],
            algorithm=data["algorithm"],
            request_id=resp["request_id"],
        )
