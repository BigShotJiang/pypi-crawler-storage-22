"""Dilithium3 digital signature operations."""

import base64

from qpher.http_client import _HttpClient
from qpher.types import SignResult, VerifyResult


class SignaturesModule:
    """Dilithium3 digital signature operations."""

    def __init__(self, http: _HttpClient) -> None:
        self._http = http

    def sign(self, message: bytes, key_version: int) -> SignResult:
        """Sign a message using Dilithium3.

        Args:
            message: Message to sign (max 1MB).
            key_version: Active signing key version.

        Returns:
            SignResult with signature bytes (3,293 bytes raw).

        Raises:
            ValidationError: If parameters are invalid.
            NotFoundError: If key_version not found.
        """
        body = {
            "message": base64.b64encode(message).decode("ascii"),
            "key_version": key_version,
        }

        resp = self._http.post("/api/v1/signature/sign", json=body)
        data = resp["data"]

        return SignResult(
            signature=base64.b64decode(data["signature"]),
            key_version=data["key_version"],
            algorithm=data["algorithm"],
            request_id=resp["request_id"],
        )

    def verify(
        self,
        message: bytes,
        signature: bytes,
        key_version: int,
    ) -> VerifyResult:
        """Verify a Dilithium3 signature.

        Args:
            message: Original message.
            signature: Signature to verify.
            key_version: Key version used during signing.

        Returns:
            VerifyResult with valid=True/False.

        Raises:
            ValidationError: If parameters are invalid.
            NotFoundError: If key_version not found.
        """
        body = {
            "message": base64.b64encode(message).decode("ascii"),
            "signature": base64.b64encode(signature).decode("ascii"),
            "key_version": key_version,
        }

        resp = self._http.post("/api/v1/signature/verify", json=body)
        data = resp["data"]

        return VerifyResult(
            valid=data["valid"],
            key_version=data["key_version"],
            algorithm=data["algorithm"],
            request_id=resp["request_id"],
        )
