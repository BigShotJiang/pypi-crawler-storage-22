"""Response dataclasses for Qpher SDK."""

from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class EncryptResult:
    """Result of a KEM encrypt operation."""

    ciphertext: bytes
    key_version: int
    algorithm: str
    request_id: str


@dataclass(frozen=True)
class DecryptResult:
    """Result of a KEM decrypt operation."""

    plaintext: bytes
    key_version: int
    algorithm: str
    request_id: str


@dataclass(frozen=True)
class SignResult:
    """Result of a signature sign operation."""

    signature: bytes
    key_version: int
    algorithm: str
    request_id: str


@dataclass(frozen=True)
class VerifyResult:
    """Result of a signature verify operation."""

    valid: bool
    key_version: int
    algorithm: str
    request_id: str


@dataclass(frozen=True)
class KeyInfo:
    """Information about a PQC key."""

    key_version: int
    algorithm: str
    status: str
    public_key: bytes
    created_at: str


@dataclass(frozen=True)
class KeyListResult:
    """Result of a key list operation."""

    keys: List[KeyInfo]
    total: int
    request_id: str


@dataclass(frozen=True)
class RotateResult:
    """Result of a key rotation operation."""

    key_version: int
    algorithm: str
    public_key: bytes
    old_key_version: int
    request_id: str


@dataclass(frozen=True)
class GenerateResult:
    """Result of a key generation operation."""

    key_version: int
    algorithm: str
    status: str
    public_key: bytes
    created_at: str
    request_id: str


@dataclass(frozen=True)
class RetireResult:
    """Result of a key retire operation."""

    key_version: int
    algorithm: str
    status: str
    public_key: bytes
    created_at: str
    request_id: str
