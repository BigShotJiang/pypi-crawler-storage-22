"""Shared test fixtures for Qpher SDK tests."""

import pytest
import responses

from qpher import Qpher


@pytest.fixture
def client():
    """Create a test client with a mock API key."""
    return Qpher(api_key="qph_test_key_12345", base_url="https://api.test.qpher.ai")


@pytest.fixture
def mock_api():
    """Yields a responses.RequestsMock context for HTTP mocking."""
    with responses.RequestsMock() as rsps:
        yield rsps


@pytest.fixture
def base_url():
    """Return the test base URL."""
    return "https://api.test.qpher.ai"


@pytest.fixture
def sample_request_id():
    """Return a sample request ID."""
    return "550e8400-e29b-41d4-a716-446655440000"


@pytest.fixture
def sample_timestamp():
    """Return a sample timestamp."""
    return "2026-02-15T10:30:45.123Z"
