"""Tests for error handling and parsing."""

from unittest.mock import Mock

import pytest

from qpher.errors import (
    QpherError,
    AuthenticationError,
    ValidationError,
    NotFoundError,
    ForbiddenError,
    RateLimitError,
    ServerError,
    _parse_error_response,
)


class TestQpherError:
    """Tests for QpherError base class."""

    def test_error_attributes(self):
        """QpherError should store all attributes."""
        error = QpherError(
            message="Test error",
            error_code="ERR_TEST_001",
            status_code=400,
            request_id="req-123",
        )

        assert error.message == "Test error"
        assert error.error_code == "ERR_TEST_001"
        assert error.status_code == 400
        assert error.request_id == "req-123"

    def test_error_str(self):
        """QpherError __str__ should return message."""
        error = QpherError(
            message="Test error",
            error_code="ERR_TEST_001",
            status_code=400,
        )

        assert str(error) == "Test error"

    def test_error_repr(self):
        """QpherError __repr__ should include all info."""
        error = QpherError(
            message="Test error",
            error_code="ERR_TEST_001",
            status_code=400,
        )

        repr_str = repr(error)
        assert "ERR_TEST_001" in repr_str
        assert "400" in repr_str
        assert "Test error" in repr_str

    def test_error_without_request_id(self):
        """QpherError should work without request_id."""
        error = QpherError(
            message="Test error",
            error_code="ERR_TEST_001",
            status_code=500,
        )

        assert error.request_id is None


class TestErrorHierarchy:
    """Tests for error class hierarchy."""

    def test_authentication_error_is_qpher_error(self):
        """AuthenticationError should be a QpherError."""
        error = AuthenticationError(
            message="Invalid key",
            error_code="ERR_AUTH_001",
            status_code=401,
        )
        assert isinstance(error, QpherError)

    def test_validation_error_is_qpher_error(self):
        """ValidationError should be a QpherError."""
        error = ValidationError(
            message="Invalid input",
            error_code="ERR_INVALID_001",
            status_code=400,
        )
        assert isinstance(error, QpherError)

    def test_not_found_error_is_qpher_error(self):
        """NotFoundError should be a QpherError."""
        error = NotFoundError(
            message="Not found",
            error_code="ERR_NOT_FOUND_001",
            status_code=404,
        )
        assert isinstance(error, QpherError)

    def test_forbidden_error_is_qpher_error(self):
        """ForbiddenError should be a QpherError."""
        error = ForbiddenError(
            message="Forbidden",
            error_code="ERR_FORBIDDEN_001",
            status_code=403,
        )
        assert isinstance(error, QpherError)

    def test_rate_limit_error_is_qpher_error(self):
        """RateLimitError should be a QpherError."""
        error = RateLimitError(
            message="Rate limited",
            error_code="ERR_RATE_001",
            status_code=429,
        )
        assert isinstance(error, QpherError)

    def test_server_error_is_qpher_error(self):
        """ServerError should be a QpherError."""
        error = ServerError(
            message="Internal error",
            error_code="ERR_INTERNAL_001",
            status_code=500,
        )
        assert isinstance(error, QpherError)


class TestParseErrorResponse:
    """Tests for _parse_error_response function."""

    def test_parse_400_returns_validation_error(self):
        """400 response should return ValidationError."""
        response = Mock()
        response.status_code = 400
        response.json.return_value = {
            "error": {
                "error_code": "ERR_INVALID_001",
                "message": "Invalid input",
            },
            "request_id": "req-123",
        }

        error = _parse_error_response(response)

        assert isinstance(error, ValidationError)
        assert error.error_code == "ERR_INVALID_001"
        assert error.request_id == "req-123"

    def test_parse_401_returns_authentication_error(self):
        """401 response should return AuthenticationError."""
        response = Mock()
        response.status_code = 401
        response.json.return_value = {
            "error": {
                "error_code": "ERR_AUTH_001",
                "message": "Invalid API key",
            },
            "request_id": "req-123",
        }

        error = _parse_error_response(response)

        assert isinstance(error, AuthenticationError)

    def test_parse_403_returns_forbidden_error(self):
        """403 response should return ForbiddenError."""
        response = Mock()
        response.status_code = 403
        response.json.return_value = {
            "error": {
                "error_code": "ERR_FORBIDDEN_001",
                "message": "Operation not allowed",
            },
            "request_id": "req-123",
        }

        error = _parse_error_response(response)

        assert isinstance(error, ForbiddenError)

    def test_parse_404_returns_not_found_error(self):
        """404 response should return NotFoundError."""
        response = Mock()
        response.status_code = 404
        response.json.return_value = {
            "error": {
                "error_code": "ERR_NOT_FOUND_001",
                "message": "Resource not found",
            },
            "request_id": "req-123",
        }

        error = _parse_error_response(response)

        assert isinstance(error, NotFoundError)

    def test_parse_429_returns_rate_limit_error(self):
        """429 response should return RateLimitError."""
        response = Mock()
        response.status_code = 429
        response.json.return_value = {
            "error": {
                "error_code": "ERR_RATE_001",
                "message": "Rate limit exceeded",
            },
            "request_id": "req-123",
        }

        error = _parse_error_response(response)

        assert isinstance(error, RateLimitError)

    def test_parse_500_returns_server_error(self):
        """500 response should return ServerError."""
        response = Mock()
        response.status_code = 500
        response.json.return_value = {
            "error": {
                "error_code": "ERR_INTERNAL_001",
                "message": "Internal error",
            },
            "request_id": "req-123",
        }

        error = _parse_error_response(response)

        assert isinstance(error, ServerError)

    def test_parse_invalid_json_response(self):
        """Invalid JSON response should still return error."""
        response = Mock()
        response.status_code = 500
        response.json.side_effect = ValueError("Invalid JSON")
        response.text = "Internal Server Error"

        error = _parse_error_response(response)

        assert isinstance(error, ServerError)
        assert error.error_code == "ERR_UNKNOWN_500"
        assert error.message == "Internal Server Error"

    def test_parse_missing_error_code(self):
        """Missing error_code should use default."""
        response = Mock()
        response.status_code = 400
        response.json.return_value = {
            "error": {
                "message": "Some error",
            },
            "request_id": "req-123",
        }

        error = _parse_error_response(response)

        assert error.error_code == "ERR_UNKNOWN_400"

    def test_parse_extracts_request_id(self):
        """Request ID should be extracted from response."""
        response = Mock()
        response.status_code = 400
        response.json.return_value = {
            "error": {
                "error_code": "ERR_INVALID_001",
                "message": "Error",
            },
            "request_id": "550e8400-e29b-41d4-a716-446655440000",
        }

        error = _parse_error_response(response)

        assert error.request_id == "550e8400-e29b-41d4-a716-446655440000"
