"""Tests for key management operations."""

import base64

import pytest
import responses

from qpher import Qpher, NotFoundError, ValidationError
from qpher.types import KeyInfo, KeyListResult, RotateResult, GenerateResult, RetireResult


class TestKeysGenerate:
    """Tests for key generation."""

    @responses.activate
    def test_generate_success(self, base_url, sample_request_id):
        """Generate should return GenerateResult on success."""
        public_key = b"kyber768_public_key_bytes"

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kms/keys/generate",
            json={
                "data": {
                    "key_version": 1,
                    "algorithm": "Kyber768",
                    "status": "active",
                    "public_key": base64.b64encode(public_key).decode(),
                    "created_at": "2026-02-15T10:30:45.123Z",
                },
                "request_id": sample_request_id,
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        result = client.keys.generate(algorithm="Kyber768")

        assert isinstance(result, GenerateResult)
        assert result.key_version == 1
        assert result.algorithm == "Kyber768"
        assert result.status == "active"
        assert result.public_key == public_key
        assert result.request_id == sample_request_id


class TestKeysRotate:
    """Tests for key rotation."""

    @responses.activate
    def test_rotate_success(self, base_url, sample_request_id):
        """Rotate should return RotateResult with new and old key versions."""
        public_key = b"new_public_key"

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kms/keys/rotate",
            json={
                "data": {
                    "key_version": 2,
                    "algorithm": "Kyber768",
                    "public_key": base64.b64encode(public_key).decode(),
                    "old_key_version": 1,
                },
                "request_id": sample_request_id,
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        result = client.keys.rotate(algorithm="Kyber768")

        assert isinstance(result, RotateResult)
        assert result.key_version == 2
        assert result.old_key_version == 1
        assert result.algorithm == "Kyber768"
        assert result.public_key == public_key


class TestKeysGetActive:
    """Tests for getting active key."""

    @responses.activate
    def test_get_active_success(self, base_url):
        """Get active should return KeyInfo for active key."""
        public_key = b"active_key_bytes"

        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys/active",
            json={
                "data": {
                    "key_version": 2,
                    "algorithm": "Kyber768",
                    "status": "active",
                    "public_key": base64.b64encode(public_key).decode(),
                    "created_at": "2026-02-15T10:30:45.123Z",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        result = client.keys.get_active(algorithm="Kyber768")

        assert isinstance(result, KeyInfo)
        assert result.key_version == 2
        assert result.status == "active"

    @responses.activate
    def test_get_active_not_found(self, base_url):
        """Get active should raise NotFoundError when no active key."""
        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys/active",
            json={
                "error": {
                    "error_code": "ERR_NOT_FOUND_001",
                    "message": "No active key for algorithm",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=404,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)

        with pytest.raises(NotFoundError):
            client.keys.get_active(algorithm="Kyber768")


class TestKeysGet:
    """Tests for getting specific key version."""

    @responses.activate
    def test_get_success(self, base_url):
        """Get should return KeyInfo for specific version."""
        public_key = b"key_bytes"

        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys/1",
            json={
                "data": {
                    "key_version": 1,
                    "algorithm": "Dilithium3",
                    "status": "retired",
                    "public_key": base64.b64encode(public_key).decode(),
                    "created_at": "2026-02-10T10:30:45.123Z",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        result = client.keys.get(algorithm="Dilithium3", key_version=1)

        assert isinstance(result, KeyInfo)
        assert result.key_version == 1
        assert result.status == "retired"


class TestKeysList:
    """Tests for listing keys."""

    @responses.activate
    def test_list_all_success(self, base_url, sample_request_id):
        """List should return all keys when no filter."""
        key1 = {
            "key_version": 1,
            "algorithm": "Kyber768",
            "status": "retired",
            "public_key": base64.b64encode(b"key1").decode(),
            "created_at": "2026-02-10T10:30:45.123Z",
        }
        key2 = {
            "key_version": 2,
            "algorithm": "Kyber768",
            "status": "active",
            "public_key": base64.b64encode(b"key2").decode(),
            "created_at": "2026-02-15T10:30:45.123Z",
        }

        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys",
            json={
                "data": {
                    "keys": [key1, key2],
                    "total": 2,
                },
                "request_id": sample_request_id,
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        result = client.keys.list()

        assert isinstance(result, KeyListResult)
        assert result.total == 2
        assert len(result.keys) == 2
        assert result.keys[0].key_version == 1
        assert result.keys[1].key_version == 2

    @responses.activate
    def test_list_with_algorithm_filter(self, base_url):
        """List should filter by algorithm."""
        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys",
            json={
                "data": {
                    "keys": [],
                    "total": 0,
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        client.keys.list(algorithm="Dilithium3")

        assert "algorithm=Dilithium3" in responses.calls[0].request.url

    @responses.activate
    def test_list_with_status_filter(self, base_url):
        """List should filter by status."""
        responses.add(
            responses.GET,
            f"{base_url}/api/v1/kms/keys",
            json={
                "data": {
                    "keys": [],
                    "total": 0,
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        client.keys.list(status="active")

        assert "status=active" in responses.calls[0].request.url


class TestKeysRetire:
    """Tests for key retirement."""

    @responses.activate
    def test_retire_success(self, base_url, sample_request_id):
        """Retire should return RetireResult with updated status."""
        public_key = b"retired_key"

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/kms/keys/retire",
            json={
                "data": {
                    "key_version": 1,
                    "algorithm": "Kyber768",
                    "status": "retired",
                    "public_key": base64.b64encode(public_key).decode(),
                    "created_at": "2026-02-10T10:30:45.123Z",
                },
                "request_id": sample_request_id,
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        result = client.keys.retire(algorithm="Kyber768", key_version=1)

        assert isinstance(result, RetireResult)
        assert result.key_version == 1
        assert result.status == "retired"
