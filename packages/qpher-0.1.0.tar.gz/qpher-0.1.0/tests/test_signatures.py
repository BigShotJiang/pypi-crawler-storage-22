"""Tests for signature sign/verify operations."""

import base64
import json

import pytest
import responses

from qpher import Qpher, NotFoundError, ValidationError
from qpher.types import SignResult, VerifyResult


class TestSignaturesSign:
    """Tests for signature sign operation."""

    @responses.activate
    def test_sign_success(self, base_url, sample_request_id):
        """Sign should return SignResult on success."""
        message = b"Invoice #12345"
        signature = b"dilithium_signature_bytes" * 100  # Simulated 3293-byte signature

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/signature/sign",
            json={
                "data": {
                    "signature": base64.b64encode(signature).decode(),
                    "key_version": 1,
                    "algorithm": "Dilithium3",
                },
                "request_id": sample_request_id,
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        result = client.signatures.sign(message=message, key_version=1)

        assert isinstance(result, SignResult)
        assert result.signature == signature
        assert result.key_version == 1
        assert result.algorithm == "Dilithium3"
        assert result.request_id == sample_request_id

    @responses.activate
    def test_sign_sends_correct_request(self, base_url):
        """Sign should send properly formatted request."""
        message = b"Test message"

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/signature/sign",
            json={
                "data": {
                    "signature": base64.b64encode(b"sig").decode(),
                    "key_version": 1,
                    "algorithm": "Dilithium3",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        client.signatures.sign(message=message, key_version=1)

        assert len(responses.calls) == 1
        request_body = json.loads(responses.calls[0].request.body)
        assert request_body["message"] == base64.b64encode(message).decode()
        assert request_body["key_version"] == 1

    @responses.activate
    def test_sign_key_not_found(self, base_url):
        """Sign should raise NotFoundError when key version not found."""
        responses.add(
            responses.POST,
            f"{base_url}/api/v1/signature/sign",
            json={
                "error": {
                    "error_code": "ERR_SIG_003",
                    "message": "Key version 99 not found",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=404,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)

        with pytest.raises(NotFoundError) as exc_info:
            client.signatures.sign(message=b"message", key_version=99)

        assert exc_info.value.error_code == "ERR_SIG_003"


class TestSignaturesVerify:
    """Tests for signature verify operation."""

    @responses.activate
    def test_verify_success_valid(self, base_url, sample_request_id):
        """Verify should return VerifyResult with valid=True for valid signature."""
        message = b"Invoice #12345"
        signature = b"valid_signature"

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/signature/verify",
            json={
                "data": {
                    "valid": True,
                    "key_version": 1,
                    "algorithm": "Dilithium3",
                },
                "request_id": sample_request_id,
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        result = client.signatures.verify(
            message=message, signature=signature, key_version=1
        )

        assert isinstance(result, VerifyResult)
        assert result.valid is True
        assert result.key_version == 1
        assert result.algorithm == "Dilithium3"

    @responses.activate
    def test_verify_success_invalid(self, base_url, sample_request_id):
        """Verify should return VerifyResult with valid=False for invalid signature."""
        message = b"Invoice #12345"
        signature = b"invalid_signature"

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/signature/verify",
            json={
                "data": {
                    "valid": False,
                    "key_version": 1,
                    "algorithm": "Dilithium3",
                },
                "request_id": sample_request_id,
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        result = client.signatures.verify(
            message=message, signature=signature, key_version=1
        )

        assert result.valid is False

    @responses.activate
    def test_verify_sends_correct_request(self, base_url):
        """Verify should send properly formatted request."""
        message = b"Test message"
        signature = b"Test signature"

        responses.add(
            responses.POST,
            f"{base_url}/api/v1/signature/verify",
            json={
                "data": {
                    "valid": True,
                    "key_version": 1,
                    "algorithm": "Dilithium3",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=200,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)
        client.signatures.verify(message=message, signature=signature, key_version=1)

        assert len(responses.calls) == 1
        request_body = json.loads(responses.calls[0].request.body)
        assert request_body["message"] == base64.b64encode(message).decode()
        assert request_body["signature"] == base64.b64encode(signature).decode()
        assert request_body["key_version"] == 1

    @responses.activate
    def test_verify_invalid_encoding(self, base_url):
        """Verify should raise ValidationError for invalid encoding."""
        responses.add(
            responses.POST,
            f"{base_url}/api/v1/signature/verify",
            json={
                "error": {
                    "error_code": "ERR_SIG_002",
                    "message": "Invalid signature encoding",
                },
                "request_id": "req-123",
                "timestamp": "2026-02-15T10:30:45.123Z",
            },
            status=400,
        )

        client = Qpher(api_key="qph_test_key", base_url=base_url)

        with pytest.raises(ValidationError) as exc_info:
            client.signatures.verify(message=b"msg", signature=b"sig", key_version=1)

        assert exc_info.value.error_code == "ERR_SIG_002"
