"""Tests for response dataclasses."""

import pytest

from qpher.types import (
    EncryptResult,
    DecryptResult,
    SignResult,
    VerifyResult,
    KeyInfo,
    KeyListResult,
    RotateResult,
    GenerateResult,
    RetireResult,
)


class TestEncryptResult:
    """Tests for EncryptResult dataclass."""

    def test_encrypt_result_fields(self):
        """EncryptResult should have all expected fields."""
        result = EncryptResult(
            ciphertext=b"encrypted",
            key_version=1,
            algorithm="Kyber768",
            request_id="req-123",
        )

        assert result.ciphertext == b"encrypted"
        assert result.key_version == 1
        assert result.algorithm == "Kyber768"
        assert result.request_id == "req-123"

    def test_encrypt_result_is_frozen(self):
        """EncryptResult should be immutable."""
        result = EncryptResult(
            ciphertext=b"encrypted",
            key_version=1,
            algorithm="Kyber768",
            request_id="req-123",
        )

        with pytest.raises(AttributeError):
            result.ciphertext = b"modified"  # type: ignore


class TestDecryptResult:
    """Tests for DecryptResult dataclass."""

    def test_decrypt_result_fields(self):
        """DecryptResult should have all expected fields."""
        result = DecryptResult(
            plaintext=b"decrypted",
            key_version=1,
            algorithm="Kyber768",
            request_id="req-123",
        )

        assert result.plaintext == b"decrypted"
        assert result.key_version == 1

    def test_decrypt_result_is_frozen(self):
        """DecryptResult should be immutable."""
        result = DecryptResult(
            plaintext=b"decrypted",
            key_version=1,
            algorithm="Kyber768",
            request_id="req-123",
        )

        with pytest.raises(AttributeError):
            result.plaintext = b"modified"  # type: ignore


class TestSignResult:
    """Tests for SignResult dataclass."""

    def test_sign_result_fields(self):
        """SignResult should have all expected fields."""
        result = SignResult(
            signature=b"signature",
            key_version=1,
            algorithm="Dilithium3",
            request_id="req-123",
        )

        assert result.signature == b"signature"
        assert result.algorithm == "Dilithium3"


class TestVerifyResult:
    """Tests for VerifyResult dataclass."""

    def test_verify_result_valid_true(self):
        """VerifyResult should store valid=True."""
        result = VerifyResult(
            valid=True,
            key_version=1,
            algorithm="Dilithium3",
            request_id="req-123",
        )

        assert result.valid is True

    def test_verify_result_valid_false(self):
        """VerifyResult should store valid=False."""
        result = VerifyResult(
            valid=False,
            key_version=1,
            algorithm="Dilithium3",
            request_id="req-123",
        )

        assert result.valid is False


class TestKeyInfo:
    """Tests for KeyInfo dataclass."""

    def test_key_info_fields(self):
        """KeyInfo should have all expected fields."""
        info = KeyInfo(
            key_version=2,
            algorithm="Kyber768",
            status="active",
            public_key=b"public_key_bytes",
            created_at="2026-02-15T10:30:45.123Z",
        )

        assert info.key_version == 2
        assert info.algorithm == "Kyber768"
        assert info.status == "active"
        assert info.public_key == b"public_key_bytes"
        assert info.created_at == "2026-02-15T10:30:45.123Z"


class TestKeyListResult:
    """Tests for KeyListResult dataclass."""

    def test_key_list_result_fields(self):
        """KeyListResult should have all expected fields."""
        keys = [
            KeyInfo(
                key_version=1,
                algorithm="Kyber768",
                status="retired",
                public_key=b"key1",
                created_at="2026-02-10T10:30:45.123Z",
            ),
            KeyInfo(
                key_version=2,
                algorithm="Kyber768",
                status="active",
                public_key=b"key2",
                created_at="2026-02-15T10:30:45.123Z",
            ),
        ]

        result = KeyListResult(
            keys=keys,
            total=2,
            request_id="req-123",
        )

        assert len(result.keys) == 2
        assert result.total == 2
        assert result.keys[0].key_version == 1
        assert result.keys[1].key_version == 2


class TestRotateResult:
    """Tests for RotateResult dataclass."""

    def test_rotate_result_fields(self):
        """RotateResult should have all expected fields."""
        result = RotateResult(
            key_version=3,
            algorithm="Kyber768",
            public_key=b"new_public_key",
            old_key_version=2,
            request_id="req-123",
        )

        assert result.key_version == 3
        assert result.old_key_version == 2
        assert result.public_key == b"new_public_key"


class TestGenerateResult:
    """Tests for GenerateResult dataclass."""

    def test_generate_result_fields(self):
        """GenerateResult should have all expected fields."""
        result = GenerateResult(
            key_version=1,
            algorithm="Dilithium3",
            status="active",
            public_key=b"public_key",
            created_at="2026-02-15T10:30:45.123Z",
            request_id="req-123",
        )

        assert result.key_version == 1
        assert result.algorithm == "Dilithium3"
        assert result.status == "active"


class TestRetireResult:
    """Tests for RetireResult dataclass."""

    def test_retire_result_fields(self):
        """RetireResult should have all expected fields."""
        result = RetireResult(
            key_version=1,
            algorithm="Kyber768",
            status="retired",
            public_key=b"public_key",
            created_at="2026-02-10T10:30:45.123Z",
            request_id="req-123",
        )

        assert result.status == "retired"
