"""QTasks builds utilities."""

import ast
import datetime
import json
from dataclasses import field, fields, is_dataclass, make_dataclass


def _infer_type(value: str):
    try:
        parsed = ast.literal_eval(value)
        return type(parsed)
    except Exception:
        return str


def _convert_value(field_type, value):
    try:
        if field_type is int:
            return int(value)
        elif field_type is float:
            return float(value)
        elif field_type is bool:
            return str(value).lower() == "true"
        elif field_type in (list, dict):
            return json.loads(value)
        elif field_type is datetime.datetime:
            return datetime.datetime.fromtimestamp(float(value))
        else:
            return value
    except Exception:
        return value


def _build_task(cls, **kwargs):
    if not is_dataclass(cls):
        raise TypeError("Expected a dataclass instance")
    if isinstance(cls, type):
        raise TypeError("Expected a dataclass instance")

    base_cls = type(cls)
    base_field_defs = fields(base_cls)
    base_field_names = {f.name for f in base_field_defs}

    known_fields = {}
    for f in base_field_defs:
        if f.name in kwargs:
            known_fields[f.name] = _convert_value(f.type, kwargs[f.name])
        else:
            known_fields[f.name] = getattr(cls, f.name)

    extra_fields = []
    extra_values = {}
    for key, value in kwargs.items():
        if key not in base_field_names:
            field_type = _infer_type(value)
            extra_fields.append((key, field_type, field(default=None)))
            extra_values[key] = _convert_value(field_type, value)

    if extra_fields:
        NewCls = make_dataclass(cls.__class__.__name__, extra_fields, bases=(base_cls,))
    else:
        NewCls = base_cls

    return NewCls(**known_fields, **extra_values)
