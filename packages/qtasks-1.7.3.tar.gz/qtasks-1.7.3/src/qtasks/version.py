"""Version of the qtasks package."""

__version__ = "1.7.3"
