import { ChevronDown, ChevronUp, Sparkles } from "lucide-react";
import { useState, useEffect } from "react";

import { MarkdownContainer } from "../MarkdownContainer";

interface ThinkingProps {
  reasoningContent: string;
  isOpen?: boolean;
  className?: string;
}

function Thinking({ reasoningContent, isOpen = false }: ThinkingProps) {
  const [open, setOpen] = useState(isOpen);

  useEffect(() => {
    setOpen(isOpen);
  }, [isOpen]);

  if (!reasoningContent || reasoningContent.trim() === "") {
    return null;
  }

  return (
    <div className={"text-sm"}>
      <button
        type="button"
        role="button"
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-1 py-2 text-left hover:cursor-pointer hover:opacity-90 transition-colors focus:outline-none active:opacity-80"
        aria-expanded={open}
        aria-controls="thinking-panel-content"
      >
        <Sparkles className="h-4 w-4 text-primary" aria-hidden="true" />
        <span className="font-medium select-none">
          {open ? "Hide thinking" : "Show thinking"}
        </span>
        {open ? (
          <ChevronUp className="h-4 w-4 opacity-70" aria-hidden="true" />
        ) : (
          <ChevronDown className="h-4 w-4 opacity-70" aria-hidden="true" />
        )}
      </button>
      {open && (
        <div className="flex pb-3 pt-1 pr-3" id="thinking-panel-content">
          <div
            aria-hidden="true"
            className="w-px bg-neutral-400/40 rounded-sm"
          />
          <div className="flex-1">
            <MarkdownContainer>{reasoningContent}</MarkdownContainer>
          </div>
        </div>
      )}
    </div>
  );
}

export { Thinking };
