"""Test suite for quack-diff."""
