"""Tests for quack_diff.cli module."""
