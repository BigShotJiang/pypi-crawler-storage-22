"""Tests for quack_diff.core module."""
