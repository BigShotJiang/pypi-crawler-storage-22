"""Command-line interface for quack-diff."""

from quack_diff.cli.main import app

__all__ = ["app"]
