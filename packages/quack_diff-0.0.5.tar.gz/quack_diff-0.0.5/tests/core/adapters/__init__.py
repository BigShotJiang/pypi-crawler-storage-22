"""Tests for quack_diff.core.adapters module."""
