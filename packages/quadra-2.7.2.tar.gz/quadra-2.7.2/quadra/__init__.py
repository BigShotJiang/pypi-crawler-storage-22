__version__ = "2.7.2"


def get_version():
    """Returns the version of the package."""
    return __version__
