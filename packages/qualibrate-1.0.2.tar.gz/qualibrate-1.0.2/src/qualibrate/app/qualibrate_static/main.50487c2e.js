"use strict";
(self["webpackChunkqualibrate_frontend_ui"] = self["webpackChunkqualibrate_frontend_ui"] || []).push([[792],{

/***/ 8689:
/***/ (function(__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {


// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(4848);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(6540);
// EXTERNAL MODULE: ./node_modules/react-router/dist/index.js
var dist = __webpack_require__(7767);
;// ./src/utils/api/apiRoutes.ts
const HOME_URL = "/";
const LOGIN_URL = "/login";
const ALL_SNAPSHOTS = (query = "", branchName = "main") => `api/branch/${branchName}/snapshots_history?${query}`;
/***************************************** TAGS *****************************************/
const CREATE_NEW_TAG = () => "api/snapshot/tag/create";
const ALL_SNAPSHOT_TAGS = () => "api/snapshot/tags";
const DELETE_TAG = () => "api/snapshot/tag/remove";
/********************************* SNAPSHOT TAGS *****************************************/
const ADD_TAGS_TO_SNAPSHOT = (snapshotId) => `api/snapshot/${snapshotId}/tags`;
const REMOVE_TAG_FROM_SNAPSHOT = (snapshotId) => `api/snapshot/${snapshotId}/tag/remove`;
const ALL_TAGS_FOR_ONE_SNAPSHOT = (snapshotId) => `api/snapshot/${snapshotId}/tags`;
/***************************************** COMMENTS *****************************************/
const ADD_COMMENT_TO_SNAPSHOT = (snapshotId) => `api/snapshot/${snapshotId}/comment/create`;
const UPDATE_COMMENT_SNAPSHOT = (snapshotId) => `api/snapshot/${snapshotId}/comment/update`;
const ALL_COMMENTS_FOR_ONE_SNAPSHOT = (snapshotId) => `api/snapshot/${snapshotId}/comments`;
const REMOVE_COMMENT_FROM_SNAPSHOT = (snapshotId) => `api/snapshot/${snapshotId}/comment/remove`;
const ONE_SNAPSHOT = (snapshotId) => `api/snapshot/${snapshotId}/`;
const SNAPSHOT_RESULT = (snapshotId) => `api/data_file/${snapshotId}/content`;
const SNAPSHOT_DIFF = (currentSnapshotId, newSnapshotId) => `api/snapshot/${currentSnapshotId}/compare?id_to_compare=${newSnapshotId}`;
const UPDATE_SNAPSHOT = (id) => `api/snapshot/${id}/update_entry`;
const UPDATE_SNAPSHOTS = (id) => `api/snapshot/${id}/update_entries`;
const ALL_PROJECTS = () => "api/projects/";
const ACTIVE_PROJECT = () => "api/project/active";
const SHOULD_REDIRECT_USER_TO_SPECIFIC_PAGE = () => "api/redirect";
const CREATE_PROJECT = () => "api/project/create";
const STOP_RUNNING = () => "execution/stop";
const ALL_NODES = () => "execution/get_nodes";
const ALL_GRAPHS = () => "execution/get_graphs";
const GET_WORKFLOW_GRAPH = () => "execution/get_graph/cytoscape";
const SUBMIT_NODE_RUN = () => "execution/submit/node";
const SUBMIT_WORKFLOW_RUN = () => "execution/submit/workflow";
const GET_EXECUTION_HISTORY = () => "execution/last_run/workflow/execution_history?reverse=true";
const GET_LAST_RUN = () => "execution/last_run/";
const GET_LAST_RUN_WORKFLOW_STATUS = () => "execution/last_run/workflow/status";
const GET_LOGS = ({ after, before, num_entries, reverse, }) => {
    const query = new URLSearchParams({
        ...(after && { after }),
        ...(before && { before }),
        num_entries: num_entries,
        reverse: reverse ? "true" : "false",
    });
    return `execution/output_logs?${query.toString()}`;
};

// EXTERNAL MODULE: ./node_modules/react-redux/dist/react-redux.mjs
var react_redux = __webpack_require__(1468);
// EXTERNAL MODULE: ./node_modules/@mui/material/Tooltip/Tooltip.js + 5 modules
var Tooltip = __webpack_require__(2666);
;// ./src/modules/SidebarMenu/styles/MenuItem.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var MenuItem_module = ({"itemWrapper":"MenuItem-module__itemWrapper","selected":"MenuItem-module__selected"});
;// ./src/utils/colors.ts
const MAIN_TEXT_COLOR = "var(--font)";
const BACKGROUND_COLOR = "var(--background-color)";
const ACCENT_COLOR_LIGHT = "var(--sub-text-color)";
const GREY_FONT = "var(--sub-text-color)";
const MENU_TEXT_COLOR = "var(--menu-text-color)";

;// ./src/utils/classnames.ts
const classNames = (...cls) => {
    return cls
        .map((v) => {
        if (typeof v === "undefined" || v === false) {
            // ignore
        }
        else if (typeof v === "string") {
            return v;
        }
        else if (v?.length && !!v[1]) {
            return v[0];
        }
        return null;
    })
        .filter((v) => !!v)
        .join(" ");
};

// EXTERNAL MODULE: ./node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs + 2 modules
var redux_toolkit_modern = __webpack_require__(5452);
;// ./src/stores/NavigationStore/NavigationStore.ts

const initialState = {
    activePage: null,
    openedOncePages: [],
};
const navigationSlice = (0,redux_toolkit_modern/* createSlice */.Z0)({
    name: "mainPage",
    initialState,
    reducers: {
        setActivePage: (state, action) => {
            state.activePage = action.payload;
            state.openedOncePages = [...state.openedOncePages, action.payload];
        },
    }
});
/* harmony default export */ var NavigationStore = (navigationSlice.reducer);

;// ./src/stores/GraphStores/GraphLibrary/GraphLibraryStore.ts

const initialGraphLibraryState = {
    allGraphs: undefined,
    selectedWorkflowName: undefined,
    selectedNodeNameInWorkflow: undefined,
    lastRunInfo: undefined,
    isRescanningGraphs: false,
    errorObject: undefined,
    subgraphBreadcrumbs: {}
};
const graphLibrarySlice = (0,redux_toolkit_modern/* createSlice */.Z0)({
    name: "graph/library",
    reducerPath: "library",
    initialState: initialGraphLibraryState,
    reducers: {
        setAllGraphs: (state, action) => {
            state.allGraphs = action.payload;
            const applyDefaultValue = (workflow) => Object.values(workflow || {}).map(graph => {
                Object.values(graph.parameters || {}).map(parameter => parameter.value = parameter.default);
                graph.nodes && applyDefaultValue(graph.nodes);
            });
            applyDefaultValue(state.allGraphs);
        },
        setSelectedWorkflowName: (state, action) => {
            state.selectedWorkflowName = action.payload;
        },
        setSelectedNodeNameInWorkflow: (state, action) => {
            state.selectedNodeNameInWorkflow = action.payload;
        },
        setLastRunInfo: (state, action) => {
            state.lastRunInfo = action.payload;
        },
        setLastRunActive: (state) => {
            state.lastRunInfo = {
                ...state.lastRunInfo,
                active: true,
            };
        },
        setIsRescanningGraphs: (state, action) => {
            state.isRescanningGraphs = action.payload;
        },
        setNodeParameter: (state, action) => {
            const { paramKey, newValue, nodeId, subgraphBreadcrumbs, selectedWorkflowName } = action.payload;
            const { allGraphs } = state;
            if (!allGraphs || !selectedWorkflowName)
                return state;
            let graph = subgraphBreadcrumbs.reduce((currentGraph, key) => {
                const node = currentGraph.nodes?.[key];
                return node ?? currentGraph;
            }, allGraphs[selectedWorkflowName]);
            if (graph.nodes && nodeId) {
                graph = graph.nodes[nodeId];
            }
            if (graph.parameters)
                graph.parameters[paramKey].value = newValue;
        },
        setErrorObject: (state, action) => {
            state.errorObject = action.payload;
        },
        setSubgraphBreadcrumbs: (state, action) => {
            if (state.selectedWorkflowName)
                state.subgraphBreadcrumbs[state.selectedWorkflowName] = action.payload;
        },
        setSubgraphForward: (state, action) => {
            if (state.selectedWorkflowName) {
                state.subgraphBreadcrumbs[state.selectedWorkflowName] = state.subgraphBreadcrumbs[state.selectedWorkflowName]
                    ? [...state.subgraphBreadcrumbs[state.selectedWorkflowName], action.payload]
                    : [action.payload];
            }
        },
        setSubgraphBack: (state, action) => {
            if (state.selectedWorkflowName)
                state.subgraphBreadcrumbs[state.selectedWorkflowName].splice(action.payload, state.selectedWorkflowName.length);
        },
    },
});

;// ./src/utils/api/index.ts
const AUTH_HEADER = {
    Authorization: "Basic bWVhc3VyZW1lbnQ6ZW50YW5nbGU=",
};
const BASIC_HEADERS = {
    "Content-Type": "application/json",
    Accept: "application/json",
    "Access-Control-Allow-Origin": "*",
    ...AUTH_HEADER,
};
const API_ADDRESS = "api/v0/";
class Api {
    static get address() {
        if (false) // removed by dead control flow
{}
        return "http://127.0.0.1:8001/" ?? 0;
    }
    static api(path) {
        return this.address + API_ADDRESS + path;
    }
    static divideProperties(props, extractArrays = false) {
        return Object.fromEntries(Object.entries(props).filter(([, value]) => (extractArrays ? Array.isArray(value) : !Array.isArray(value))));
    }
    static formQuery(options = {}) {
        if (!options || !Object.keys(options).length) {
            return "";
        }
        const arrayProperties = this.divideProperties(options, true);
        if (!Object.keys(arrayProperties).length) {
            return "?" + new URLSearchParams(options);
        }
        const plainProperties = this.divideProperties(options, false);
        const plainParams = new URLSearchParams(plainProperties);
        const arrayQuery = Object.keys(arrayProperties)
            .map((arrayName) => arrayProperties[arrayName].map((value) => `&${arrayName}=${value}`))
            .join("")
            .replace(/,/g, "");
        return `?${plainParams}${arrayQuery}`;
    }
    static async _fetch(path, method, options) {
        const { queryParams, body, ...restOptions } = options || {};
        const urlQuery = this.formQuery(queryParams);
        try {
            const res = await fetch(`${path}${urlQuery}`, {
                method: method,
                headers: { ...BASIC_HEADERS, "Content-Type": "application/json" },
                body,
                credentials: "include",
                ...restOptions,
            });
            return this.getResult(res);
        }
        catch (e) {
            return {
                isOk: false,
                error: "" + e,
            };
        }
    }
    static async fetchData(path, method, options) {
        const { queryParams, body, ...restOptions } = options || {};
        const urlQuery = this.formQuery(queryParams);
        try {
            const response = await fetch(`${path}${urlQuery}`, {
                method: method,
                headers: { ...BASIC_HEADERS, "Content-Type": "application/json" },
                body,
                credentials: "include",
                ...restOptions,
            });
            const data = await response.json();
            if (!response.ok) {
                //throw new Error(`Request failed with status ${response.status}`);
                return {
                    error: `${data?.detail[0].msg}`,
                };
            }
            return data;
        }
        catch (e) {
            return {
                error: `${e}`,
            };
        }
    }
    static async fetch([path, method], options) {
        const { queryParams, body, ...restOptions } = options || {};
        const urlQuery = this.formQuery(queryParams);
        try {
            const res = await fetch(this.api(`${path}${urlQuery}`), {
                method,
                headers: { ...BASIC_HEADERS, "Content-Type": "application/json" },
                body,
                credentials: "include",
                ...restOptions,
            });
            return this.getResult(res);
        }
        catch (e) {
            return {
                isOk: false,
                error: "" + e,
            };
        }
    }
    static async setupOkResponse(res, message) {
        let result = undefined;
        try {
            const contentType = res.headers.get("content-type") || "";
            if (contentType.includes("application/json")) {
                const text = await res.text();
                if (text) {
                    result = JSON.parse(text);
                }
            }
        }
        catch (e) {
            console.warn("JSON parsing failed in setupOkResponse:", e);
        }
        return {
            isOk: true,
            result,
            message,
        };
    }
    static async setupErrorResponse(res, message) {
        return {
            isOk: false,
            error: await res.json(),
            message,
        };
    }
    static async getResult(res) {
        return res.ok ? this.setupOkResponse(res) : this.setupErrorResponse(res);
    }
}

;// ./src/utils/api/types.ts
var API_METHODS;
(function (API_METHODS) {
    API_METHODS["GET"] = "GET";
    API_METHODS["POST"] = "POST";
})(API_METHODS || (API_METHODS = {}));

;// ./src/stores/GraphStores/GraphLibrary/api/GraphLibraryApi.tsx



class GraphLibraryApi extends Api {
    constructor() {
        super();
    }
    static api(path) {
        return this.address + path;
    }
    static fetchAllGraphs(rescan = false) {
        return this._fetch(this.api(ALL_GRAPHS()), API_METHODS.GET, {
            headers: BASIC_HEADERS,
            queryParams: { rescan },
        });
    }
    static fetchGraph(name) {
        return this._fetch(this.api(GET_WORKFLOW_GRAPH()), API_METHODS.GET, {
            headers: BASIC_HEADERS,
            queryParams: { name },
        });
    }
    static submitWorkflow(name, workflow) {
        return this._fetch(this.api(SUBMIT_WORKFLOW_RUN()), API_METHODS.POST, {
            headers: BASIC_HEADERS,
            body: JSON.stringify(workflow),
            queryParams: { name },
        });
    }
    static fetchExecutionHistory() {
        return this._fetch(this.api(GET_EXECUTION_HISTORY()), API_METHODS.GET, {
            headers: BASIC_HEADERS,
        });
    }
}

// EXTERNAL MODULE: ./node_modules/reselect/dist/reselect.mjs
var reselect = __webpack_require__(5508);
;// ./src/stores/GraphStores/selectors.ts
const getGraphState = (state) => state.graph;

;// ./src/stores/GraphStores/GraphLibrary/selectors.ts


const getGraphLibraryState = (0,reselect/* createSelector */.Mz)(getGraphState, (graphState) => graphState.library);
const getSelectedWorkflowName = (0,reselect/* createSelector */.Mz)(getGraphLibraryState, (libraryState) => libraryState.selectedWorkflowName);
const getSelectedNodeNameInWorkflow = (0,reselect/* createSelector */.Mz)(getGraphLibraryState, (libraryState) => libraryState.selectedNodeNameInWorkflow);
const getSubgraphBreadcrumbs = (0,reselect/* createSelector */.Mz)(getGraphLibraryState, getSelectedWorkflowName, (libraryState, selectedWorkflowName) => libraryState.subgraphBreadcrumbs[selectedWorkflowName || ""] || []);
const getAllGraphs = (0,reselect/* createSelector */.Mz)(getGraphLibraryState, (libraryState) => libraryState.allGraphs);
const getSelectedWorkflow = (0,reselect/* createSelector */.Mz)(getAllGraphs, getSelectedWorkflowName, getSubgraphBreadcrumbs, (allGraphs = {}, selectedWorkflowName = "", subgraphBreadcrumbs) => subgraphBreadcrumbs.reduce((currentGraph, key) => {
    const node = currentGraph.nodes?.[key];
    return node ?? currentGraph;
}, allGraphs[selectedWorkflowName]));
const getLastRunInfo = (0,reselect/* createSelector */.Mz)(getGraphLibraryState, (libraryState) => libraryState.lastRunInfo);
const getLastRunNodeName = (0,reselect/* createSelector */.Mz)(getLastRunInfo, (lastRunInfo) => lastRunInfo?.activeNodeName);
const getLastRunWorkflowName = (0,reselect/* createSelector */.Mz)(getLastRunInfo, (lastRunInfo) => lastRunInfo?.workflowName);
const getLastRunError = (0,reselect/* createSelector */.Mz)(getLastRunInfo, (lastRunInfo) => lastRunInfo?.error);
const getIsRescanningGraphs = (0,reselect/* createSelector */.Mz)(getGraphLibraryState, (libraryState) => libraryState.isRescanningGraphs);
const getErrorObject = (0,reselect/* createSelector */.Mz)(getGraphLibraryState, (libraryState) => libraryState.errorObject);

;// ./src/stores/GraphStores/GraphStatus/GraphStatusStore.ts

const initialGraphStatusState = {
    allMeasurements: [],
    trackLatest: false,
    subgraphBreadcrumbs: [],
    selectedNodeNameInWorkflow: undefined,
};
const graphStatusSlice = (0,redux_toolkit_modern/* createSlice */.Z0)({
    name: "graph/status",
    reducerPath: "status",
    initialState: initialGraphStatusState,
    reducers: {
        setAllMeasurements: (state, action) => {
            state.allMeasurements = action.payload;
        },
        setTrackLatest: (state, action) => {
            state.trackLatest = action.payload;
        },
        setSelectedNodeNameInWorkflow: (state, action) => {
            state.selectedNodeNameInWorkflow = action.payload;
        },
        setSubgraphBreadcrumbs: (state, action) => {
            state.subgraphBreadcrumbs = action.payload;
        },
        setSubgraphForward: (state, action) => {
            state.subgraphBreadcrumbs = state.subgraphBreadcrumbs ? [...state.subgraphBreadcrumbs, action.payload] : [action.payload];
        },
        setSubgraphBack: (state, action) => {
            state.subgraphBreadcrumbs.splice(action.payload, state.subgraphBreadcrumbs.length);
        },
    },
});
/* harmony default export */ var GraphStatusStore = (graphStatusSlice);

;// ./src/stores/GraphStores/GraphStatus/actions.ts


const { setAllMeasurements, setTrackLatest, setSelectedNodeNameInWorkflow: setGraphStatusSelectedNodeNameInWorkflow, setSubgraphBreadcrumbs: setGraphStatusSubgraphBreadcrumbs, setSubgraphForward: setGraphStatusSubgraphForward, setSubgraphBack: setGraphStasetSubgraphBack, } = GraphStatusStore.actions;
const fetchAllMeasurements = () => async (dispatch) => {
    try {
        const response = await GraphLibraryApi.fetchExecutionHistory();
        if (response.isOk) {
            if (response.result && response.result.items) {
                dispatch(setAllMeasurements(response.result.items));
                return response.result.items;
            }
        }
        else if (response.error) {
            console.log(response.error);
        }
    }
    catch (error) {
        console.log(error);
    }
    return [];
};

;// ./src/stores/GraphStores/GraphStatus/selectors.ts


const getGraphStatusState = (0,reselect/* createSelector */.Mz)(getGraphState, (graphState) => graphState.status);
const getAllMeasurements = (0,reselect/* createSelector */.Mz)(getGraphStatusState, (statusState) => statusState.allMeasurements);
const getTrackLatest = (0,reselect/* createSelector */.Mz)(getGraphStatusState, (statusState) => statusState.trackLatest);
const getGraphStatuSubgraphBreadcrumbs = (0,reselect/* createSelector */.Mz)(getGraphStatusState, (statusState) => statusState.subgraphBreadcrumbs);
const getGraphStatuSelectedNodeNameInWorkflow = (0,reselect/* createSelector */.Mz)(getGraphStatusState, (statusState) => statusState.selectedNodeNameInWorkflow);

;// ./src/stores/GraphStores/GraphStatus/index.ts




;// ./src/stores/GraphStores/GraphLibrary/actions.ts






const { setAllGraphs, setSelectedWorkflowName, setSelectedNodeNameInWorkflow, setLastRunInfo, setLastRunActive, setIsRescanningGraphs, setNodeParameter, setErrorObject, setSubgraphForward, setSubgraphBack, setSubgraphBreadcrumbs, } = graphLibrarySlice.actions;
const updateObject = (obj) => {
    const modifyParameters = (parameters, isNodeLevel = false) => {
        if (parameters?.targets_name) {
            if (isNodeLevel) {
                const targetKey = parameters.targets_name.default?.toString();
                if (targetKey && parameters.targets_name.default) {
                    // eslint-disable-next-line @typescript-eslint/no-unused-vars
                    const { targets_name, [targetKey]: _, ...rest } = parameters;
                    return rest;
                }
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const { targets_name, ...rest } = parameters;
                return rest;
            }
            else {
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const { targets_name, ...rest } = parameters;
                return rest;
            }
        }
        return parameters;
    };
    obj.parameters = modifyParameters(obj.parameters, false);
    if (obj.nodes) {
        Object.keys(obj.nodes).forEach((nodeKey) => {
            const node = obj.nodes[nodeKey];
            node.parameters = modifyParameters(node.parameters, true);
        });
    }
    return obj;
};
const updateAllGraphs = (allFetchedGraphs) => {
    const updatedGraphs = {};
    Object.entries(allFetchedGraphs).forEach(([key, graph]) => {
        updatedGraphs[key] = updateObject(graph);
    });
    return updatedGraphs;
};
const fetchAllCalibrationGraphs = (rescan = false) => async (dispatch) => {
    dispatch(setIsRescanningGraphs(true));
    const response = await GraphLibraryApi.fetchAllGraphs(rescan);
    if (response.isOk) {
        const allFetchedGraphs = response.result;
        const updatedGraphs = updateAllGraphs(allFetchedGraphs);
        dispatch(setAllGraphs(updatedGraphs));
    }
    else if (response.error) {
        console.log(response.error);
    }
    // Uncomment to use mocks
    // dispatch(setAllGraphs(MOCK_ALL_GRAPHS));
    dispatch(setIsRescanningGraphs(false));
};
/**
 * Submits workflow for execution and opens graph-status panel.
 * Sets `lastRunInfo.active` to trigger UI updates via GraphContext.
 */
const submitWorkflow = () => async (dispatch, getState) => {
    const state = getState();
    const allGraphs = getAllGraphs(state);
    const selectedWorkflowName = getSelectedWorkflowName(state);
    const transformParameters = (params) => {
        let transformedParams = {};
        if (!params)
            return transformedParams;
        for (const key in params) {
            transformedParams = { ...transformedParams, [key]: params[key].value };
        }
        return transformedParams;
    };
    const transformGraph = (graph) => {
        const transformed = {
            parameters: transformParameters(graph.parameters),
            nodes: {},
        };
        for (const nodeKey in graph.nodes) {
            const node = graph.nodes[nodeKey];
            const isNodeAGraph = "nodes" in node;
            if (isNodeAGraph) {
                const graph = node;
                transformed.nodes[nodeKey] = transformGraph(graph);
                continue;
            }
            transformed.nodes[nodeKey] = {
                parameters: transformParameters(node.parameters),
            };
        }
        return transformed;
    };
    const transformDataForSubmit = () => {
        const input = allGraphs?.[selectedWorkflowName ?? ""];
        if (!input)
            return;
        return transformGraph(input);
    };
    if (selectedWorkflowName) {
        dispatch(setLastRunActive());
        const response = await GraphLibraryApi.submitWorkflow(selectedWorkflowName, transformDataForSubmit());
        if (response.isOk) {
            dispatch(setErrorObject(undefined)); // This is a bugfix - previously it didn't clear errorObject on success
            dispatch(setActivePage(GRAPH_STATUS_KEY));
            dispatch(setTrackLatest(true));
        }
        else {
            dispatch(setErrorObject(response.error));
        }
    }
};
const setGraphNodeParameter = (paramKey, newValue, nodeId) => (dispatch, getState) => {
    const subgraphBreadcrumbs = getSubgraphBreadcrumbs(getState());
    const selectedWorkflowName = getSelectedWorkflowName(getState());
    dispatch(setNodeParameter({ paramKey, newValue, nodeId, subgraphBreadcrumbs, selectedWorkflowName }));
};

;// ./src/stores/GraphStores/GraphLibrary/index.ts





;// ./src/stores/NodesStore/NodesStore.ts

const NodesStore_initialState = {
    selectedNode: undefined,
    submitNodeResponseError: undefined,
    runningNode: undefined,
    runningNodeInfo: undefined,
    allNodes: undefined,
    isNodeRunning: false,
    results: undefined,
    isAllStatusesUpdated: false,
    updateAllButtonPressed: false,
    isRescanningNodes: false,
};
const nodesSlice = (0,redux_toolkit_modern/* createSlice */.Z0)({
    name: "nodes",
    initialState: NodesStore_initialState,
    reducers: {
        setSelectedNode: (state, action) => {
            state.selectedNode = action.payload;
        },
        setSubmitNodeResponseError: (state, action) => {
            state.submitNodeResponseError = action.payload;
        },
        setRunningNode: (state, action) => {
            state.runningNode = action.payload;
        },
        runNode: (state, action) => {
            state.isNodeRunning = true;
            state.results = {};
            state.updateAllButtonPressed = false;
            state.isAllStatusesUpdated = false;
            state.runningNode = action.payload;
            state.submitNodeResponseError = undefined;
        },
        setRunningNodeInfo: (state, action) => {
            state.runningNodeInfo = action.payload;
        },
        setAllNodes: (state, action) => {
            state.allNodes = action.payload;
            Object.values(state.allNodes || {}).map((node) => Object.values(node.parameters || {}).map(parameter => parameter.value = parameter.default));
        },
        setNodeParameter: (state, action) => {
            const { nodeKey, paramKey, newValue } = action.payload;
            if (state.allNodes && state.allNodes[nodeKey].parameters)
                state.allNodes[nodeKey].parameters[paramKey].value = newValue;
        },
        setIsNodeRunning: (state, action) => {
            state.isNodeRunning = action.payload;
        },
        setResults: (state, action) => {
            state.results = action.payload;
        },
        setIsAllStatusesUpdated: (state, action) => {
            state.isAllStatusesUpdated = action.payload;
        },
        setUpdateAllButtonPressed: (state, action) => {
            state.updateAllButtonPressed = action.payload;
        },
        setIsRescanningNodes: (state, action) => {
            state.isRescanningNodes = action.payload;
        },
    }
});
/* harmony default export */ var NodesStore = (nodesSlice.reducer);

;// ./src/stores/NodesStore/api/NodesAPI.tsx



class NodesApi extends Api {
    constructor() {
        super();
    }
    static api(path) {
        return this.address + path;
    }
    static fetchAllNodes(rescan = false) {
        return this._fetch(this.api(ALL_NODES()), API_METHODS.GET, {
            headers: BASIC_HEADERS,
            queryParams: { rescan },
        });
    }
    static submitNodeParameters(nodeName, inputParameter) {
        return this._fetch(this.api(SUBMIT_NODE_RUN()), API_METHODS.POST, {
            headers: BASIC_HEADERS,
            body: JSON.stringify(inputParameter),
            queryParams: { name: nodeName },
        });
    }
    static fetchLastRunInfo() {
        return this._fetch(this.api(GET_LAST_RUN()), API_METHODS.GET, {
            headers: BASIC_HEADERS,
        });
    }
    static getLogs(after = null, before = null, num_entries = "300", reverse = true) {
        return this._fetch(this.api(GET_LOGS({ after, before, num_entries, reverse })), API_METHODS.GET, {
            headers: BASIC_HEADERS,
        });
    }
}

;// ./src/stores/SnapshotsStore/SnapshotsStore.ts

var SortType;
(function (SortType) {
    SortType["Name"] = "name";
    SortType["Date"] = "date";
    SortType["Status"] = "status";
})(SortType || (SortType = {}));
const SnapshotsStore_initialState = {
    trackLatestSidePanel: true,
    trackPreviousSnapshot: true,
    totalPages: 0,
    pageNumber: 1,
    allSnapshots: [],
    isLoadingSnapshots: false,
    snapshotsFilters: {
        tags: [],
        sortType: SortType.Date,
        searchString: "",
        minDate: "",
        maxDate: "",
    },
    selectedSnapshot: undefined,
    selectedWorkflow: undefined,
    selectedNodeInWorkflowId: undefined,
    breadCrumbs: [],
    allTags: [],
    selectedSnapshotId: undefined,
    latestSnapshotId: undefined,
    clickedForSnapshotSelection: false,
    jsonData: {},
    jsonDataSidePanel: {},
    diffData: undefined,
    result: {},
    firstId: "0",
    secondId: "0",
};
const SnapshotsSlice = (0,redux_toolkit_modern/* createSlice */.Z0)({
    name: "snapshots",
    initialState: SnapshotsStore_initialState,
    reducers: {
        setTrackLatestSidePanel: (state, action) => {
            state.trackLatestSidePanel = action.payload;
        },
        setTrackPreviousSnapshot: (state, action) => {
            state.trackPreviousSnapshot = action.payload;
        },
        setPageNumber: (state, action) => {
            if (state.pageNumber !== action.payload) {
                state.pageNumber = action.payload;
                state.isLoadingSnapshots = true;
            }
        },
        setTotalPages: (state, action) => {
            state.totalPages = action.payload;
        },
        setAllSnapshots: (state, action) => {
            state.allSnapshots = action.payload;
            state.isLoadingSnapshots = false;
        },
        setIsLoadingSnapshots: (state, action) => {
            state.isLoadingSnapshots = action.payload;
        },
        setSnapshotsFilters: (state, action) => {
            state.snapshotsFilters = action.payload;
            state.isLoadingSnapshots = true;
        },
        setSelectedSnapshot: (state, action) => {
            state.selectedSnapshot = action.payload;
        },
        setSelectedWorkflow: (state, action) => {
            state.selectedWorkflow = action.payload;
        },
        setSelectedNodeInWorkflowId: (state, action) => {
            state.selectedNodeInWorkflowId = action.payload;
        },
        setSubgraphForward: (state, action) => {
            state.breadCrumbs = [...state.breadCrumbs, action.payload];
        },
        setSubgraphBack: (state, action) => {
            state.breadCrumbs.splice(action.payload, state.breadCrumbs.length);
        },
        setAllTags: (state, action) => {
            state.allTags = action.payload;
        },
        setSelectedSnapshotId: (state, action) => {
            state.selectedSnapshotId = action.payload;
        },
        setLatestSnapshotId: (state, action) => {
            state.latestSnapshotId = action.payload;
        },
        setClickedForSnapshotSelection: (state, action) => {
            state.clickedForSnapshotSelection = action.payload;
        },
        setJsonData: (state, action) => {
            state.jsonData = action.payload;
        },
        setJsonDataSidePanel: (state, action) => {
            state.jsonDataSidePanel = action.payload;
        },
        setDiffData: (state, action) => {
            state.diffData = action.payload;
        },
        clearData: (state) => {
            state.selectedSnapshotId = undefined;
            state.selectedSnapshot = undefined;
            state.selectedWorkflow = undefined;
            state.selectedNodeInWorkflowId = undefined;
            state.jsonData = undefined;
            state.result = undefined;
            state.diffData = undefined;
            state.isLoadingSnapshots = false;
        },
        setResult: (state, action) => {
            state.result = action.payload;
        },
        setFirstId: (state, action) => {
            state.firstId = action.payload;
        },
        setSecondId: (state, action) => {
            state.secondId = action.payload;
        },
        setReset: (state, action) => {
            state.isLoadingSnapshots = action.payload;
        },
    },
});
/* harmony default export */ var SnapshotsStore = (SnapshotsSlice.reducer);

;// ./src/stores/SnapshotsStore/api/SnapshotsApi.tsx



class SnapshotsApi extends Api {
    constructor() {
        super();
    }
    static api(path) {
        return this.address + path;
    }
    static fetchAllSnapshots(query) {
        return this._fetch(this.api(ALL_SNAPSHOTS(query)), API_METHODS.GET, {
            headers: BASIC_HEADERS,
        });
    }
    static fetchSnapshot(id, loadTypeFlag) {
        const url = this.api(ONE_SNAPSHOT(id));
        const params = new URLSearchParams();
        // Use DataWithMachine as default if no load type flag is provided
        const flagsToUse = loadTypeFlag && loadTypeFlag.length > 0 ? loadTypeFlag : ["Full"];
        flagsToUse.forEach((flag) => params.append("load_type_flag", flag));
        const urlWithParams = `${url}?${params.toString()}`;
        return this._fetch(urlWithParams, API_METHODS.GET, {
            headers: BASIC_HEADERS,
        });
    }
    static fetchSnapshotResult(id) {
        return this._fetch(this.api(SNAPSHOT_RESULT(id)), API_METHODS.GET, {
            headers: BASIC_HEADERS,
        });
    }
    static fetchSnapshotUpdate(currentId, newId) {
        return this._fetch(this.api(SNAPSHOT_DIFF(currentId, newId)), API_METHODS.GET, {
            headers: BASIC_HEADERS,
        });
    }
    static updateState(snapshotId, data_path, value) {
        return this._fetch(this.api(UPDATE_SNAPSHOT(snapshotId)), API_METHODS.POST, {
            headers: BASIC_HEADERS,
            body: JSON.stringify({ data_path, value }),
        });
    }
    static updateStates(snapshotId, listOfUpdates) {
        return this._fetch(this.api(UPDATE_SNAPSHOTS(snapshotId)), API_METHODS.POST, {
            headers: BASIC_HEADERS,
            body: JSON.stringify({ items: listOfUpdates }),
        });
    }
    static stopNodeRunning() {
        return this._fetch(this.api(STOP_RUNNING()), API_METHODS.POST, {
            headers: BASIC_HEADERS,
        });
    }
    static createNewTag(tag) {
        return this._fetch(this.api(CREATE_NEW_TAG()), API_METHODS.POST, {
            headers: BASIC_HEADERS,
            body: JSON.stringify({ name: tag }),
        });
    }
    static fetchAllTags() {
        return this._fetch(this.api(ALL_SNAPSHOT_TAGS()), API_METHODS.GET, {
            headers: BASIC_HEADERS,
        });
    }
    static deleteTag(tag) {
        return this._fetch(this.api(DELETE_TAG()), API_METHODS.POST, {
            headers: BASIC_HEADERS,
            body: JSON.stringify({ name: tag }),
        });
    }
    static addTagsToSnapshot(snapshotId, tags) {
        return this._fetch(this.api(ADD_TAGS_TO_SNAPSHOT(snapshotId)), API_METHODS.POST, {
            headers: BASIC_HEADERS,
            body: JSON.stringify({ tags }),
        });
    }
    static removeTagFromSnapshot(snapshotId, tag) {
        return this._fetch(this.api(REMOVE_TAG_FROM_SNAPSHOT(snapshotId)), API_METHODS.POST, {
            headers: BASIC_HEADERS,
            body: JSON.stringify({ name: tag }),
        });
    }
    static fetchAllTagsForSnapshot(snapshotId) {
        return this._fetch(this.api(ALL_TAGS_FOR_ONE_SNAPSHOT(snapshotId)), API_METHODS.GET, {
            headers: BASIC_HEADERS,
        });
    }
    static addCommentToSnapshot(snapshotId, commentText) {
        return this._fetch(this.api(ADD_COMMENT_TO_SNAPSHOT(snapshotId)), API_METHODS.POST, {
            headers: BASIC_HEADERS,
            body: JSON.stringify({ value: commentText }),
        });
    }
    static updateSnapshotComment(snapshotId, comment) {
        return this._fetch(this.api(UPDATE_COMMENT_SNAPSHOT(snapshotId)), API_METHODS.POST, {
            headers: BASIC_HEADERS,
            body: JSON.stringify(comment),
        });
    }
    static fetchAllCommentsForSnapshot(snapshotId) {
        return this._fetch(this.api(ALL_COMMENTS_FOR_ONE_SNAPSHOT(snapshotId)), API_METHODS.GET, {
            headers: BASIC_HEADERS,
        });
    }
    static removeCommentFromSnapshot(snapshotId, commentId) {
        return this._fetch(this.api(REMOVE_COMMENT_FROM_SNAPSHOT(snapshotId)), API_METHODS.POST, {
            headers: BASIC_HEADERS,
            body: JSON.stringify({ id: commentId }),
        });
    }
}

;// ./src/stores/SnapshotsStore/selectors.ts

const getSnapshotsState = (state) => state.snapshots;
const getNodesState = (state) => state.nodes;
const getTrackLatestSidePanel = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.trackLatestSidePanel);
const getTrackPreviousSnapshot = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.trackPreviousSnapshot);
const getTotalPages = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.totalPages);
const getPageNumber = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.pageNumber);
const getAllSnapshots = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.allSnapshots);
const getIsLoadingSnapshots = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.isLoadingSnapshots);
const getSnapshotsSearchQuery = (0,reselect/* createSelector */.Mz)(getSnapshotsState, getPageNumber, (state, pageNumber) => {
    const { tags, sortType, searchString, minDate, maxDate } = state.snapshotsFilters;
    const baseParams = {
        page: pageNumber.toString(),
        per_page: "100",
        descending: "true",
        sort: sortType,
        grouped: "true",
        ...(searchString && { name_part: searchString }),
        ...(minDate && { min_date: minDate }),
        ...(maxDate && { max_date: maxDate }),
    };
    const tagParams = tags?.reduce((acc, tag) => {
        acc.push(["tag_name", tag]);
        return acc;
    }, []) ?? [];
    return new URLSearchParams([
        ...Object.entries(baseParams),
        ...tagParams,
    ]).toString();
});
const getSelectedSnapshot = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.selectedSnapshot);
const getAllTags = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.allTags);
const selectors_getSelectedWorkflow = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.selectedWorkflow);
const getSelectedNodeInWorkflowName = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.selectedNodeInWorkflowId);
const getBreadCrumbs = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.breadCrumbs);
const findByBreadcrumbs = (items, breadcrumbs) => breadcrumbs.reduce((current, name, index) => {
    const source = index === 0 ? items : current?.type_of_execution === "workflow" ? current.items : undefined;
    if (!source)
        return undefined;
    return source.find((item) => item.metadata?.name === name);
}, undefined);
const getSelectedWorkflowForGraph = (0,reselect/* createSelector */.Mz)(getAllSnapshots, getBreadCrumbs, (allSnapshots = [], breadcrumbs = []) => breadcrumbs.length ? findByBreadcrumbs(allSnapshots, breadcrumbs) : undefined);
const getSelectedSnapshotId = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.selectedSnapshotId);
const getLatestSnapshotId = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.latestSnapshotId);
const getClickedForSnapshotSelection = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.clickedForSnapshotSelection);
const getJsonData = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.jsonData);
const getJsonDataSidePanel = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.jsonDataSidePanel);
const getDiffData = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.diffData);
const getResult = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.result);
const getFirstId = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.firstId);
const getSecondId = (0,reselect/* createSelector */.Mz)(getSnapshotsState, (state) => state.secondId);
const getSelectedSnapshotNode = (0,reselect/* createSelector */.Mz)(getSnapshotsState, getNodesState, getJsonData, (snapshotState, nodesState, jsonData) => {
    const node = nodesState?.allNodes ? nodesState?.allNodes[snapshotState.selectedSnapshot?.metadata?.name ?? ""] : undefined;
    const model = jsonData.parameters?.model;
    if (!node || !model)
        return undefined;
    const newParameters = {};
    Object.entries(node.parameters || {}).forEach(([key, param]) => {
        const modelParamValue = model[key];
        newParameters[key] = {
            ...param,
            default: modelParamValue || ""
        };
    });
    return {
        ...node,
        parameters: newParameters,
    };
});

;// ./src/stores/SnapshotsStore/utils.ts

const fetchSnapshotJsonData = (id) => {
    try {
        return SnapshotsApi.fetchSnapshot(id);
    }
    catch (e) {
        console.error(`Failed to fetch a snapshot (id=${id}):`, e);
        return null;
    }
};
const fetchSnapshotResults = (id) => {
    try {
        return SnapshotsApi.fetchSnapshotResult(id);
    }
    catch (e) {
        console.error(`Failed to fetch results for the snapshot (id=${id}):`, e);
        return undefined;
    }
};
const fetchSnapshotDiff = (id2, id1) => {
    try {
        return SnapshotsApi.fetchSnapshotUpdate(id1, id2);
    }
    catch (e) {
        console.error(`Failed to fetch snapshot updates for the snapshots (id2=${id2}, id1=${id1}):`, e);
        return undefined;
    }
};
const fetchAllSnapshots = (query) => {
    try {
        return SnapshotsApi.fetchAllSnapshots(query);
    }
    catch (e) {
        console.error(`Failed to fetch all snapshots (${query}):`, e);
        return null;
    }
};
const fetchAllTags = () => {
    try {
        return SnapshotsApi.fetchAllTags();
    }
    catch (e) {
        console.error("Failed to fetch all snapshot tags:", e);
        return null;
    }
};
const addTagsToSnapshot = (snapshotId, selectedTags) => {
    try {
        return SnapshotsApi.addTagsToSnapshot(snapshotId.toString(), selectedTags);
    }
    catch (e) {
        console.error("Failed to add/remove snapshot tags:", e);
        return null;
    }
};
const addCommentToSnapshot = (snapshotId, commentText) => {
    try {
        return SnapshotsApi.addCommentToSnapshot(snapshotId.toString(), commentText);
    }
    catch (e) {
        console.error(`Failed to add new comment to snapshotId=:${snapshotId}`, e);
        return undefined;
    }
};
const updateSnapshotComment = (snapshotId, comment) => {
    try {
        return SnapshotsApi.updateSnapshotComment(snapshotId.toString(), comment);
    }
    catch (e) {
        console.error(`Failed to update comment with commentId=${comment.id} for snapshotId=:${snapshotId}`, e);
        return null;
    }
};
const fetchAllCommentsForSnapshot = (snapshotId) => {
    try {
        return SnapshotsApi.fetchAllCommentsForSnapshot(snapshotId.toString());
    }
    catch (e) {
        console.error(`Failed to fetch comments for snapshotId=:${snapshotId}`, e);
        return null;
    }
};
const removeCommentFromSnapshot = (snapshotId, commentId) => {
    try {
        return SnapshotsApi.removeCommentFromSnapshot(snapshotId.toString(), commentId.toString());
    }
    catch (e) {
        console.error(`Failed to remove comment with commentId=${commentId} for snapshotId=:${snapshotId}`, e);
        return null;
    }
};

;// ./src/stores/SnapshotsStore/actions.ts








const { setTrackLatestSidePanel, setTrackPreviousSnapshot, setPageNumber, setTotalPages, setAllSnapshots, setIsLoadingSnapshots, setSnapshotsFilters, setSelectedWorkflow, setSelectedNodeInWorkflowId, setSubgraphForward: actions_setSubgraphForward, setSubgraphBack: actions_setSubgraphBack, setAllTags, setSelectedSnapshotId, setSelectedSnapshot, setLatestSnapshotId, setClickedForSnapshotSelection, setJsonData, setJsonDataSidePanel, setDiffData, clearData, setResult, setFirstId, setSecondId, } = SnapshotsSlice.actions;
const fetchOneSnapshot = (snapshotId, snapshotId2, updateResult = true, fetchUpdate = false) => async (dispatch, getState) => {
    const id1 = (snapshotId ?? 0).toString();
    const id2 = snapshotId2 ? snapshotId2.toString() : snapshotId - 1 >= 0 ? (snapshotId - 1).toString() : "0";
    const resSnapshotJsonData = await fetchSnapshotJsonData(id1);
    if (resSnapshotJsonData?.isOk) {
        if (updateResult) {
            dispatch(setJsonData(resSnapshotJsonData.result?.data));
            const resSnapshotResults = await fetchSnapshotResults(id1);
            if (resSnapshotResults?.isOk) {
                dispatch(setResult(resSnapshotResults?.result));
            }
        }
        dispatch(setJsonDataSidePanel(resSnapshotJsonData?.result?.data?.quam ?? {}));
    }
    if (id1 !== id2 && fetchUpdate) {
        const resSnapshotDiff = await fetchSnapshotDiff(id2, id1);
        if (resSnapshotDiff?.isOk) {
            dispatch(setDiffData(resSnapshotDiff?.result ?? {}));
        }
    }
    else {
        dispatch(setDiffData({}));
    }
};
const fetchGitgraphSnapshots = (firstTime) => async (dispatch, getState) => {
    const trackLatestSidePanel = getTrackLatestSidePanel(getState());
    const trackPreviousSnapshot = getTrackPreviousSnapshot(getState());
    const secondId = getSecondId(getState());
    const selectedSnapshotId = getSelectedSnapshotId(getState());
    const query = getSnapshotsSearchQuery(getState());
    dispatch(setIsLoadingSnapshots(true));
    const resAllSnapshots = await fetchAllSnapshots(query);
    dispatch(setIsLoadingSnapshots(false));
    if (resAllSnapshots && resAllSnapshots?.isOk) {
        const items = resAllSnapshots.result?.items;
        dispatch(setTotalPages(resAllSnapshots.result?.total_pages ?? 1));
        dispatch(setPageNumber(resAllSnapshots.result?.page ?? 1));
        dispatch(setAllSnapshots(resAllSnapshots.result?.items ?? []));
        // Uncomment this line to use MOCKS for Execution History page
        let lastElId = 0;
        if (items) {
            lastElId = items.length > 0 ? items[0]?.id : 0;
            dispatch(setLatestSnapshotId(lastElId));
            dispatch(setSelectedSnapshot(items.find((snapshot) => snapshot.id === lastElId)));
            dispatch(setSelectedNodeInWorkflowId(lastElId));
            dispatch(setSelectedSnapshotId(lastElId));
            dispatch(fetchOneSnapshot(lastElId, lastElId - 1, true, true));
            if (trackLatestSidePanel) {
                const snapshotId1 = lastElId;
                const snapshotId2 = trackPreviousSnapshot ? lastElId - 1 : Number(secondId);
                dispatch(fetchOneSnapshot(snapshotId1, snapshotId2, false, true));
            }
        }
        if (firstTime && !items && selectedSnapshotId) {
            dispatch(fetchOneSnapshot(selectedSnapshotId));
        }
    }
};
const fetchSnapshotTags = () => async (dispatch, getState) => {
    const resAllSnapshotTags = await fetchAllTags();
    if (resAllSnapshotTags && resAllSnapshotTags?.isOk) {
        dispatch(setAllTags(resAllSnapshotTags.result));
    }
    // TODO Uncomment this code to use mocked data
    // dispatch(
    //   setAllTags([
    //     "resonance",
    //     "characterization",
    //     "calibration",
    //     "rabi",
    //     "relaxation",
    //     "error",
    //     "tomography",
    //     "validation",
    //     "benchmarking",
    //     "multi-qubit",
    //     "quick-check",
    //   ])
    // );
};
const setSelectedSnapshotInSnapshotList = (snapshotName) => async (dispatch, getState) => {
    const state = getState();
    if (state.snapshots.selectedWorkflow && state.snapshots.selectedWorkflow.items) {
        const snapshot = state.snapshots.selectedWorkflow?.items?.find((s) => s.metadata?.name === snapshotName);
        if (snapshot) {
            dispatch(setSelectedSnapshot(snapshot));
            dispatch(setSelectedSnapshotId(snapshot?.id));
            dispatch(fetchOneSnapshot(snapshot?.id));
        }
    }
};
const setSelectedWorkflowFromBreadcrumbs = () => (dispatch, getState) => {
    const state = getState();
    const selectedWorkflow = getSelectedWorkflowForGraph(state);
    if (!selectedWorkflow) {
        return;
    }
    dispatch(setSelectedWorkflow(selectedWorkflow));
    dispatch(setSelectedSnapshot(selectedWorkflow));
};
const goBackOneLevel = () => (dispatch, getState) => {
    const stateBeforeGoingBack = getState();
    const breadcrumbs = getBreadCrumbs(stateBeforeGoingBack);
    dispatch(actions_setSubgraphBack(breadcrumbs.length - 1));
    const stateAfterBack = getState();
    const selectedWorkflow = getSelectedWorkflowForGraph(stateAfterBack);
    const allSnapshots = getAllSnapshots(stateAfterBack);
    const breadcrumbsAfterGoingBack = getBreadCrumbs(stateAfterBack);
    if (breadcrumbsAfterGoingBack.length === 0 && allSnapshots?.length > 0) {
        dispatch(setSelectedWorkflow(undefined));
        dispatch(setSelectedSnapshotId(allSnapshots[0].id));
        dispatch(fetchOneSnapshot(allSnapshots[0].id));
        dispatch(setSelectedSnapshot(allSnapshots[0]));
        dispatch(setSelectedNodeInWorkflowId(allSnapshots[0].id));
    }
    else {
        dispatch(setSelectedWorkflow(selectedWorkflow)); // hack for top navigation to refresh the redux
        dispatch(setSelectedSnapshotId(selectedWorkflow?.id));
        dispatch(setSelectedSnapshot(selectedWorkflow));
        dispatch(setSelectedNodeInWorkflowId(selectedWorkflow?.id));
    }
};
const updateSnapshotsRecursive = (snapshots, targetName, selectedTags) => {
    return snapshots.reduce((acc, snapshot) => {
        if (snapshot.metadata?.name === targetName) {
            acc.push({
                ...snapshot,
                tags: selectedTags,
            });
        }
        else {
            acc.push({
                ...snapshot,
                items: snapshot.items ? updateSnapshotsRecursive(snapshot.items, targetName, selectedTags) : snapshot.items,
            });
        }
        return acc;
    }, []);
};
const updateSnapshotTags = (selectedTags) => (dispatch, getState) => {
    const state = getState();
    const allSnapshots = getAllSnapshots(state);
    const breadcrumbs = getBreadCrumbs(state);
    const selectedSnapshot = getSelectedSnapshot(state);
    if (breadcrumbs.length === 0) {
        const updatedSnapshots = allSnapshots.reduce((acc, snapshot) => {
            if (snapshot.metadata?.name === selectedSnapshot?.metadata?.name) {
                // update snapshots tags
                acc.push({ ...snapshot, tags: selectedTags });
            }
            else {
                acc.push(snapshot);
            }
            return acc;
        }, []);
        dispatch(setAllSnapshots(updatedSnapshots));
    }
    else if (selectedSnapshot) {
        const updatedSnapshots = updateSnapshotsRecursive(allSnapshots, selectedSnapshot?.metadata?.name, selectedTags);
        dispatch(setAllSnapshots(updatedSnapshots));
    }
};
const runNodeOfSelectedSnapshot = () => (dispatch, getState) => {
    const state = getState();
    const selectedSnapshot = getSelectedSnapshot(state);
    if (selectedSnapshot) {
        const nodeOfSnapshot = getSelectedSnapshotNode(state);
        if (nodeOfSnapshot) {
            dispatch(handleRunNode(nodeOfSnapshot));
        }
    }
};
const runWorkflowOfSelectedSnapshot = () => async (dispatch, getState) => {
    const state = getState();
    const selectedSnapshot = getSelectedSnapshot(state);
    const jsonData = getJsonData(state);
    if (selectedSnapshot?.metadata.name && jsonData) {
        dispatch(setLastRunActive());
        const response = await GraphLibraryApi.submitWorkflow(selectedSnapshot.metadata.name, jsonData.parameters?.model);
        if (response.isOk) {
            dispatch(setErrorObject(undefined)); // This is a bugfix - previously it didn't clear errorObject on success
            dispatch(setActivePage(GRAPH_STATUS_KEY));
            dispatch(setTrackLatest(true));
        }
        else {
            dispatch(setErrorObject(response.error));
        }
    }
};

// EXTERNAL MODULE: ./node_modules/redux/dist/redux.mjs
var redux = __webpack_require__(4644);
;// ./src/stores/AuthStore/AuthStore.ts

const AuthStore_initialState = {
    isAuthorized: true,
    triedLoginWithEmptyString: false,
    authError: undefined
};
const authSlice = (0,redux_toolkit_modern/* createSlice */.Z0)({
    name: "auth",
    initialState: AuthStore_initialState,
    reducers: {
        setAuthorize: (state, action) => {
            state.isAuthorized = action.payload;
        },
        setError: (state, action) => {
            state.authError = action.payload;
        },
        setTriedLoginWithEmptyString: state => {
            state.triedLoginWithEmptyString = true;
        }
    }
});
/* harmony default export */ var AuthStore = (authSlice.reducer);

;// ./src/stores/AuthStore/selectors.ts

const getAuthState = (state) => state.auth;
const getIsAuthorized = (0,reselect/* createSelector */.Mz)(getAuthState, (state) => state.isAuthorized);
const getAuthError = (0,reselect/* createSelector */.Mz)(getAuthState, (state) => state.authError);
const getIsTriedLoginWithEmptyString = (0,reselect/* createSelector */.Mz)(getAuthState, (state) => state.triedLoginWithEmptyString);

;// ./src/stores/AuthStore/api/AuthApiRoutes.ts
const LOGIN = "login";

;// ./src/stores/AuthStore/api/AuthApi.ts



class AuthApi extends Api {
    constructor() {
        super();
    }
    static api(path) {
        return this.address + path;
    }
    static login(password) {
        return this._fetch(this.api(LOGIN), API_METHODS.POST, {
            headers: BASIC_HEADERS,
            body: JSON.stringify(password),
        });
    }
}

;// ./src/stores/AuthStore/actions.ts

const { setAuthorize, setError, setTriedLoginWithEmptyString, } = authSlice.actions;

;// ./src/stores/AuthStore/hooks.ts






const getCookieStartingWith = (prefix) => {
    const cookies = document.cookie.split("; ");
    for (const cookie of cookies) {
        if (cookie.startsWith(prefix)) {
            return cookie;
        }
    }
    return null;
};
const checkIfThereIsCookie = () => {
    const cookiePrefix = "Qualibrate-Token=";
    const token = getCookieStartingWith(cookiePrefix);
    return token !== null;
};
const useLogin = () => {
    const dispatch = useRootDispatch();
    const navigate = (0,dist/* useNavigate */.Zp)();
    const login = async (password) => {
        const { isOk } = await AuthApi.login(password);
        dispatch(setAuthorize(isOk));
        dispatch(setError(isOk ? undefined : "Failed to authorize"));
        if (isOk) {
            navigate(HOME_URL);
        }
    };
    (0,react.useEffect)(() => {
        const initializeAuth = async () => {
            if (checkIfThereIsCookie()) {
                dispatch(setAuthorize(true));
                navigate(HOME_URL);
            }
            else {
                login("").then(() => {
                    dispatch(setTriedLoginWithEmptyString());
                });
                if (checkIfThereIsCookie()) {
                    dispatch(setAuthorize(true));
                    navigate(HOME_URL);
                }
            }
        };
        initializeAuth();
    }, []);
    return login;
};

;// ./src/stores/AuthStore/index.ts




;// ./src/stores/ProjectStore/ProjectStore.ts

const ProjectStore_initialState = {
    allProjects: [],
    activeProject: undefined,
    shouldGoToProjectPage: true,
    isScanningProjects: false,
};
const createSlice = (0,redux_toolkit_modern/* buildCreateSlice */.Xq)({
    creators: { asyncThunk: redux_toolkit_modern/* asyncThunkCreator */.Vj },
});
const projectsSlice = createSlice({
    name: "projects",
    initialState: ProjectStore_initialState,
    reducers: {
        setAllProjects: (state, action) => {
            state.allProjects = action.payload;
        },
        addProject: (state, action) => {
            state.allProjects = [action.payload, ...state.allProjects];
        },
        setActiveProject: (state, action) => {
            state.activeProject = action.payload;
        },
        handleSelectActiveProject: (state, action) => {
            state.activeProject = action.payload;
        },
        setShouldGoToProjectPage: (state, action) => {
            state.shouldGoToProjectPage = action.payload;
        },
        setScanningProjects: (state, action) => {
            state.isScanningProjects = action.payload;
        }
    }
});
/* harmony default export */ var ProjectStore = (projectsSlice.reducer);

;// ./src/stores/ProjectStore/api/ProjectViewAPI.tsx



class ProjectViewApi extends Api {
    constructor() {
        super();
    }
    static api(path) {
        return this.address + path;
    }
    static fetchAllProjects() {
        return this._fetch(this.api(ALL_PROJECTS()), API_METHODS.GET, {
            headers: BASIC_HEADERS,
        });
    }
    static fetchActiveProjectName() {
        return this._fetch(this.api(ACTIVE_PROJECT()), API_METHODS.GET, {
            headers: BASIC_HEADERS,
        });
    }
    static fetchShouldRedirectUserToProjectPage() {
        return this._fetch(this.api(SHOULD_REDIRECT_USER_TO_SPECIFIC_PAGE()), API_METHODS.GET, {
            headers: BASIC_HEADERS,
        });
    }
    static selectActiveProject(projectName) {
        return this._fetch(this.api(ACTIVE_PROJECT()), API_METHODS.POST, {
            headers: BASIC_HEADERS,
            body: JSON.stringify(projectName),
        });
    }
    static createProject(formData) {
        const body = {
            ...(formData.dataPath && { storage_location: formData.dataPath }),
            ...(formData.calibrationPath && { calibration_library_folder: formData.calibrationPath }),
            ...(formData.quamPath && { quam_state_path: formData.quamPath }),
        };
        return this._fetch(this.api(CREATE_PROJECT()), API_METHODS.POST, {
            headers: BASIC_HEADERS,
            body: JSON.stringify(body),
            queryParams: { project_name: formData.projectName },
        });
    }
}

;// ./src/stores/ProjectStore/actions.ts


const { setAllProjects, addProject, setActiveProject, setShouldGoToProjectPage, setScanningProjects, } = projectsSlice.actions;
const fetchProjectsAndActive = () => async (dispatch) => {
    const [projectsRes, activeNameRes] = await Promise.all([
        ProjectViewApi.fetchAllProjects(),
        ProjectViewApi.fetchActiveProjectName()
    ]);
    dispatch(setScanningProjects(true));
    if (projectsRes.isOk && projectsRes.result) {
        const fetchedProjects = projectsRes.result;
        dispatch(setAllProjects(fetchedProjects));
        if (activeNameRes.isOk && activeNameRes.result) {
            const fetchedActiveProject = fetchedProjects.find((p) => p.name === activeNameRes.result);
            dispatch(setActiveProject(fetchedActiveProject));
        }
        else if (!activeNameRes.isOk && activeNameRes.error) {
            console.error("Error fetching projects or active project:", activeNameRes.error);
        }
    }
    else {
        if (!projectsRes.isOk && projectsRes.error) {
            console.error("Error fetching projects or active project:", projectsRes.error);
        }
    }
    dispatch(setScanningProjects(false));
};
const fetchShouldRedirectUserToProjectPage = () => async (dispatch) => {
    const response = await ProjectViewApi.fetchShouldRedirectUserToProjectPage();
    if (response.isOk && response.result) {
        localStorage.setItem("backandWorking", "true");
        dispatch(setShouldGoToProjectPage(response.result.page === "project"));
    }
    else if (!response.isOk && response.error) {
        console.error("Error fetching should user be redirected to project page:", response.error);
    }
};
const selectActiveProject = (project) => async (dispatch) => {
    try {
        const { isOk, result } = await ProjectViewApi.selectActiveProject(project.name);
        if (isOk && result === project.name) {
            dispatch(setActiveProject(project));
            dispatch(setShouldGoToProjectPage(false));
        }
    }
    catch (err) {
        console.error("Failed to activate project:", err);
    }
};

;// ./src/stores/ProjectStore/selectors.ts

const getProjectsState = (state) => state.projects;
const getIsScanningProjects = (0,reselect/* createSelector */.Mz)(getProjectsState, (state) => state.isScanningProjects);
const getAllProjects = (0,reselect/* createSelector */.Mz)(getProjectsState, (state) => state.allProjects);
const getActiveProject = (0,reselect/* createSelector */.Mz)(getProjectsState, (state) => state.activeProject);
const getShouldGoToProjectPage = (0,reselect/* createSelector */.Mz)(getProjectsState, (state) => state.shouldGoToProjectPage);

;// ./src/stores/ProjectStore/hooks.ts



const useInitProjects = () => {
    const dispatch = useRootDispatch();
    (0,react.useEffect)(() => {
        dispatch(fetchProjectsAndActive());
        dispatch(fetchShouldRedirectUserToProjectPage());
    }, []);
};

;// ./src/stores/ProjectStore/index.ts






;// ./src/stores/GraphStores/hooks.ts



const useInitGraphs = () => {
    const dispatch = useRootDispatch();
    (0,react.useEffect)(() => {
        dispatch(fetchAllCalibrationGraphs());
    }, []);
};

;// ./src/stores/GraphStores/index.ts



const GraphStore = (0,redux_toolkit_modern/* combineSlices */.fP)(graphLibrarySlice, GraphStatusStore);


;// ./src/stores/WebSocketStore/WebSocketStore.ts

const WebSocketStore_initialState = {
    runStatus: null,
    history: null,
    snapshotInfo: null,
    snapshotUpdateRequired: false,
    showConnectionErrorDialog: false,
    connectionLostAt: null,
    connectionLostSeconds: 0,
};
const webSocketSlice = (0,redux_toolkit_modern/* createSlice */.Z0)({
    name: "webSocket",
    initialState: WebSocketStore_initialState,
    reducers: {
        setRunStatus: (state, action) => {
            state.runStatus = action.payload;
        },
        setHistory: (state, action) => {
            state.history = action.payload;
        },
        setSnapshotInfo: (state, action) => {
            state.snapshotInfo = action.payload;
            state.snapshotUpdateRequired = action.payload.update_required;
        },
        setSnapshotUpdateRequired: (state, action) => {
            state.snapshotUpdateRequired = action.payload;
        },
        setShowConnectionErrorDialog: (state, action) => {
            state.showConnectionErrorDialog = action.payload;
        },
        setConnectionLostAt: (state, action) => {
            state.connectionLostAt = action.payload;
        },
        setConnectionLostSeconds: (state, action) => {
            state.connectionLostSeconds = action.payload;
        },
    }
});
/* harmony default export */ var WebSocketStore = (webSocketSlice.reducer);

;// ./src/stores/WebSocketStore/selectors.ts

const getWebSocketState = (state) => state.webSocket;
const getRunStatus = (0,reselect/* createSelector */.Mz)(getWebSocketState, (webSocketState) => webSocketState.runStatus);
const getHistory = (0,reselect/* createSelector */.Mz)(getWebSocketState, (webSocketState) => webSocketState.history);
const getShowConnectionErrorDialog = (0,reselect/* createSelector */.Mz)(getWebSocketState, (webSocketState) => webSocketState.showConnectionErrorDialog);
const getConnectionLostAt = (0,reselect/* createSelector */.Mz)(getWebSocketState, (webSocketState) => webSocketState.connectionLostAt);
const getConnectionLostSeconds = (0,reselect/* createSelector */.Mz)(getWebSocketState, (webSocketState) => webSocketState.connectionLostSeconds);
/**
 * runStatus selectors
 */
const getRunStatusIsRunning = (0,reselect/* createSelector */.Mz)(getRunStatus, (runStatusState) => runStatusState?.is_running);
const getRunStatusType = (0,reselect/* createSelector */.Mz)(getRunStatus, (runStatusState) => runStatusState?.runnable_type);
const getRunResultNodeError = (0,reselect/* createSelector */.Mz)(getRunStatus, (runStatusState) => runStatusState?.node?.run_results?.error);
/**
 * graph selectors
 */
const getRunStatusGraph = (0,reselect/* createSelector */.Mz)(getRunStatus, (runStatusState) => runStatusState?.graph);
const getRunStatusGraphName = (0,reselect/* createSelector */.Mz)(getRunStatusGraph, (runStatusGraphState) => runStatusGraphState?.name);
const getRunStatusGraphTotalNodes = (0,reselect/* createSelector */.Mz)(getRunStatusGraph, (runStatusGraphState) => runStatusGraphState?.total_nodes);
const getRunStatusGraphStatus = (0,reselect/* createSelector */.Mz)(getRunStatusGraph, (runStatusGraphState) => runStatusGraphState?.status);
const getRunStatusGraphPercentageComplete = (0,reselect/* createSelector */.Mz)(getRunStatusGraph, (runStatusGraphState) => runStatusGraphState?.percentage_complete);
const getRunStatusGraphFinishedNodes = (0,reselect/* createSelector */.Mz)(getRunStatusGraph, (runStatusGraphState) => runStatusGraphState?.finished_nodes);
const getRunStatusGraphTimeRemaining = (0,reselect/* createSelector */.Mz)(getRunStatusGraph, (runStatusGraphState) => runStatusGraphState?.time_remaining);
const getRunStatusGraphRunStart = (0,reselect/* createSelector */.Mz)(getRunStatusGraph, (runStatusGraphState) => runStatusGraphState?.run_start);
const getRunStatusGraphRunDuration = (0,reselect/* createSelector */.Mz)(getRunStatusGraph, (runStatusGraphState) => runStatusGraphState?.run_duration);
const getRunStatusGraphError = (0,reselect/* createSelector */.Mz)(getRunStatusGraph, (runStatusGraphState) => runStatusGraphState?.run_results?.error);
/**
 * runStatus Node selectors
 */
const getRunStatusNode = (0,reselect/* createSelector */.Mz)(getRunStatus, (runStatusState) => runStatusState?.node);
const getRunStatusNodeName = (0,reselect/* createSelector */.Mz)(getRunStatusNode, (runStatusNodeState) => runStatusNodeState?.name);
const getIsLastRunNode = (0,reselect/* createSelector */.Mz)(getRunStatusNodeName, (runStatusNodeName, nodeKey) => nodeKey, (runStatusNodeName, nodeKey) => runStatusNodeName === nodeKey);
const getRunStatusNodeStatus = (0,reselect/* createSelector */.Mz)(getRunStatusNode, (runStatusNodeState) => runStatusNodeState?.status);
const getRunStatusNodeRunDuration = (0,reselect/* createSelector */.Mz)(getRunStatusNode, (runStatusNodeState) => runStatusNodeState?.run_duration);
const getRunStatusNodePercentage = (0,reselect/* createSelector */.Mz)(getRunStatusNode, (runStatusNodeState) => runStatusNodeState?.percentage_complete);
const getRunStatusNodeId = (0,reselect/* createSelector */.Mz)(getRunStatusNode, (runStatusNodeState) => runStatusNodeState?.id);
const getRunStatusNodeCurrentAction = (0,reselect/* createSelector */.Mz)(getRunStatusNode, (runStatusNodeState) => runStatusNodeState?.current_action);
const getRunStatusNodeTimeRemaining = (0,reselect/* createSelector */.Mz)(getRunStatusNode, (runStatusNodeState) => runStatusNodeState?.time_remaining);
/**
 * snapshotInfo selectors
 */
const getSnapshotInfo = (0,reselect/* createSelector */.Mz)(getWebSocketState, (webSocketState) => webSocketState.snapshotInfo);
const getIsSnapshotUpdateRequired = (0,reselect/* createSelector */.Mz)(getWebSocketState, (snapshotInfo) => snapshotInfo?.snapshotUpdateRequired);

;// ./src/stores/WebSocketStore/actions.ts




const { setRunStatus, setHistory, setSnapshotInfo, setSnapshotUpdateRequired, setShowConnectionErrorDialog, setConnectionLostAt, setConnectionLostSeconds, } = webSocketSlice.actions;
const handleShowConnectionErrorDialog = () => (dispatch, getState) => {
    const connectionLostAt = getConnectionLostAt(getState());
    if (localStorage.getItem("backandWorking") !== "true") {
        return;
    }
    if (connectionLostAt === null) {
        const now = Date.now();
        dispatch(setConnectionLostAt(now));
        dispatch(setConnectionLostSeconds(0));
    }
    dispatch(setShowConnectionErrorDialog(true));
    localStorage.setItem("backandWorking", "false");
};
const handleHideConnectionErrorDialog = () => (dispatch, getState) => {
    const showConnectionErrorDialog = getShowConnectionErrorDialog(getState());
    if (!showConnectionErrorDialog)
        return;
    localStorage.setItem("backandWorking", "true");
    dispatch(setConnectionLostAt(null));
    dispatch(setConnectionLostSeconds(0));
    dispatch(fetchShouldRedirectUserToProjectPage());
    dispatch(setShowConnectionErrorDialog(false));
};
const handleSetRunStatus = (runStatus) => (dispatch, getState) => {
    const lastRunInfo = getLastRunInfo(getState());
    dispatch(setRunStatus(runStatus));
    dispatch(setLastRunInfo({
        ...lastRunInfo,
        active: runStatus.is_running,
        workflowName: runStatus.graph?.name,
        activeNodeName: runStatus.node?.name ?? "",
        nodesCompleted: runStatus.graph?.finished_nodes,
        nodesTotal: runStatus.graph?.total_nodes,
        runDuration: runStatus.graph?.run_duration,
        error: runStatus.graph?.run_results?.error || undefined,
    }));
};

;// ./src/services/webSocketRoutes.ts
const WS_GET_STATUS = "execution/ws/run_status";
const WS_EXECUTION_HISTORY = "execution/ws/workflow_execution_history";
const WS_SNAPSHOT_INFO = "ws/update_snapshots_history_required";
const WS_LOGS = "ws/output_logs";

;// ./src/services/WebSocketService.ts
/**
 * @fileoverview WebSocket client with automatic reconnection and pub/sub pattern.
 *
 * Used by WebSocketContext for two connections: run status and execution history.
 * Auto-reconnects every second until server available.
 *
 * **Primary Use Case**:
 * Used by WebSocketContext.tsx to manage two real-time connections for quantum calibration:
 * - Run status updates: Real-time node/graph execution progress
 * - Execution history: Historical calibration data for timeline visualization
 *
 * **Key Features**:
 * - Type-safe message handling via TypeScript generics
 * - Automatic reconnection every second until the server becomes available again
 * - Pub/sub pattern allowing multiple callbacks per WebSocket connection
 * - JSON serialization/deserialization of all messages
 * - Robust connection state tracking with 5-state state machine (ConnectionState enum)
 *
 * **Architecture Pattern**:
 * The service implements a facade pattern over the native WebSocket API, adding
 * resilience features (reconnection) and developer experience improvements (pub/sub,
 * type safety) without requiring changes to consuming code.
 *
 * @see WebSocketContext
 */
/** WebSocket lifecycle states. Auto-reconnects on failure. */
var ConnectionState;
(function (ConnectionState) {
    ConnectionState["DISCONNECTED"] = "disconnected";
    ConnectionState["CONNECTING"] = "connecting";
    ConnectionState["CONNECTED"] = "connected";
    ConnectionState["RECONNECTING"] = "reconnecting";
    ConnectionState["FAILED"] = "failed";
})(ConnectionState || (ConnectionState = {}));
/**
 * WebSocket client with automatic reconnection and pub/sub pattern.
 * Messages must be JSON-serializable.
 *
 * @template T - Message type for this connection
 * @see WebSocketContext
 */
class WebSocketService {
    ws = null;
    url;
    connectionState = ConnectionState.DISCONNECTED;
    reconnectAttempt = 0;
    shouldReconnect = true;
    reconnectTimeoutId = null;
    retryDelay = 1000;
    onMessage;
    onConnected;
    onClose;
    subscribers = [];
    /**
     * @param url - WebSocket URL
     * @param onMessage - Callback for received messages
     * @param onConnected - Optional callback when connection established
     * @param onClose - Optional callback when connection closed
     */
    constructor(url, onMessage, onConnected, onClose) {
        this.url = url;
        this.onMessage = onMessage;
        this.onConnected = onConnected;
        this.onClose = onClose;
    }
    /**
     * Establish WebSocket connection with automatic retry on failure.
     *
     * Sets up event handlers for connection lifecycle (onopen, onmessage, onerror, onclose)
     * and implements automatic reconnection with linear backoff strategy.
     *
     * **Connection Process**:
     * 1. Check if already connected (early return if yes)
     * 2. Create new WebSocket instance with this.url
     * 3. Set isConnected=true on successful open
     * 4. Handle incoming messages by parsing JSON and notifying callbacks
     * 5. On connection close, retry automatically after a short delay
     *
     * **Reconnection Behavior**:
     * - Attempts to reconnect indefinitely
     * - Uses a fixed one second delay between attempts (no exponential backoff)
     * - Logs each retry to the console for visibility
     *
     * **Error Handling**:
     * - Constructor errors caught and logged (connection attempt failures)
     * - Message parsing errors caught in onmessage handler (invalid JSON)
     * - All errors only log to console, no user-facing notifications
     * - No distinction between recoverable vs permanent failures
     *
     * Connect to WebSocket with automatic reconnection.
     *
     * @param retryDelay - Milliseconds between reconnection attempts (default: 1000)
     */
    connect(retryDelay = 1000) {
        if (this.connectionState === ConnectionState.CONNECTED) {
            console.warn("⚠️ WebSocket is already connected:", this.url);
            return;
        }
        this.shouldReconnect = true;
        this.reconnectAttempt = 0;
        this.retryDelay = retryDelay;
        this.clearReconnectTimeout();
        this.tryConnect();
    }
    /**
     * Send message over WebSocket. Silently fails if not connected.
     * @param data - Message to send (must be JSON-serializable)
     */
    send(data) {
        if (!this.isConnected()) {
            console.warn("❌ Cannot send message: WebSocket not connected:", this.url);
            return;
        }
        try {
            this.ws.send(JSON.stringify(data));
        }
        catch (err) {
            console.warn("❌ Failed to send data over WebSocket:", err);
        }
    }
    /** Disconnect and stop auto-reconnection. Subscribers persist. */
    disconnect() {
        this.shouldReconnect = false;
        this.clearReconnectTimeout();
        this.reconnectAttempt = 0;
        if (this.ws) {
            const socket = this.ws;
            socket.close();
            this.ws = null;
        }
        this.connectionState = ConnectionState.DISCONNECTED;
    }
    /**
     * Subscribe to WebSocket messages.
     * @param cb - Callback invoked on each message
     * @returns Unsubscribe function
     */
    subscribe(cb) {
        if (!this.subscribers.includes(cb)) {
            this.subscribers.push(cb);
        }
        return () => {
            this.subscribers = this.subscribers.filter((s) => s !== cb);
        };
    }
    getConnectionState() {
        return this.connectionState;
    }
    /** Check if connected and ready to send/receive messages. */
    isConnected() {
        return this.connectionState === ConnectionState.CONNECTED && this.ws?.readyState === WebSocket.OPEN;
    }
    tryConnect() {
        if (!this.shouldReconnect) {
            this.connectionState = ConnectionState.DISCONNECTED;
            return;
        }
        this.connectionState = ConnectionState.CONNECTING;
        try {
            this.ws = new WebSocket(this.url);
            this.ws.onopen = () => {
                this.connectionState = ConnectionState.CONNECTED;
                this.reconnectAttempt = 0;
                this.clearReconnectTimeout();
                console.log("✅ WebSocket connected:", this.url);
                if (this.onConnected) {
                    this.onConnected();
                }
            };
            this.ws.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    this.onMessage(data);
                    this.subscribers.forEach((cb) => {
                        try {
                            cb(data);
                        }
                        catch (error) {
                            console.error("❌ Error in WebSocket subscriber:", error);
                        }
                    });
                }
                catch (e) {
                    console.warn("⚠️ Failed to parse WebSocket message:", event.data, e);
                }
            };
            this.ws.onerror = (err) => {
                console.warn("⚠️ WebSocket error on", this.url, err);
            };
            this.ws.onclose = () => {
                this.ws = null;
                this.clearReconnectTimeout();
                if (!this.shouldReconnect || this.connectionState === ConnectionState.DISCONNECTED) {
                    this.connectionState = ConnectionState.DISCONNECTED;
                    return;
                }
                console.warn("🔌 WebSocket closed:", this.url);
                this.connectionState = ConnectionState.FAILED;
                if (this.onClose) {
                    this.onClose();
                }
                this.scheduleReconnect();
            };
        }
        catch (err) {
            console.warn("❌ Failed to connect WebSocket:", this.url, err);
            this.connectionState = ConnectionState.FAILED;
            this.scheduleReconnect();
        }
    }
    clearReconnectTimeout() {
        if (this.reconnectTimeoutId !== null) {
            clearTimeout(this.reconnectTimeoutId);
            this.reconnectTimeoutId = null;
        }
    }
    scheduleReconnect() {
        if (!this.shouldReconnect) {
            this.connectionState = ConnectionState.DISCONNECTED;
            return;
        }
        this.connectionState = ConnectionState.RECONNECTING;
        const delayMs = this.retryDelay;
        console.warn(`⏳ Attempting to reconnect to ${this.url} in ${delayMs}ms (attempt ${this.reconnectAttempt + 1})`);
        this.reconnectAttempt += 1;
        this.reconnectTimeoutId = setTimeout(() => {
            this.reconnectTimeoutId = null;
            this.tryConnect();
        }, delayMs);
    }
}

;// ./src/stores/WebSocketStore/hooks.ts








const useInitWebSocket = () => {
    const dispatch = useRootDispatch();
    const showConnectionErrorDialog = (0,react_redux/* useSelector */.d4)(getShowConnectionErrorDialog);
    const connectionLostAt = (0,react_redux/* useSelector */.d4)(getConnectionLostAt);
    const runStatusWS = (0,react.useRef)(null);
    const historyWS = (0,react.useRef)(null);
    const snapshotInfoWS = (0,react.useRef)(null);
    const flattenHistory = (history) => {
        if (!history?.items)
            return [];
        return history.items.flatMap((item) => {
            if (item.elements_history?.items) {
                return [...item.elements_history.items].reverse();
            }
            return [item];
        });
    };
    (0,react.useEffect)(() => {
        if (!showConnectionErrorDialog || connectionLostAt === null) {
            return;
        }
        dispatch(setConnectionLostSeconds(Math.floor((Date.now() - connectionLostAt) / 1000)));
        const intervalId = window.setInterval(() => {
            dispatch(setConnectionLostSeconds(Math.floor((Date.now() - connectionLostAt) / 1000)));
        }, 1000);
        return () => {
            clearInterval(intervalId);
        };
    }, [showConnectionErrorDialog, connectionLostAt]);
    const handleSetHistory = (history) => {
        dispatch(setHistory(history));
        dispatch(setAllMeasurements(flattenHistory(history)));
    };
    // Establish WebSocket connections on mount, disconnect on unmount
    // Empty dependency array [] ensures this runs once per component lifecycle
    (0,react.useEffect)(() => {
        const protocol = window.location.protocol === "http:" ? "ws" : "wss";
        const location = "127.0.0.1:8001/" || 0;
        const host = "127.0.0.1:8001/" || 0;
        const runStatusUrl = `${protocol}://${host}${WS_GET_STATUS}`;
        const historyUrl = `${protocol}://${host}${WS_EXECUTION_HISTORY}`;
        const snapshotInfoUrl = `${protocol}://${host}${WS_SNAPSHOT_INFO}`;
        runStatusWS.current = new WebSocketService(runStatusUrl, (runStatus) => dispatch(handleSetRunStatus(runStatus)), () => dispatch(handleHideConnectionErrorDialog()), () => dispatch(handleShowConnectionErrorDialog()));
        historyWS.current = new WebSocketService(historyUrl, handleSetHistory, () => dispatch(handleHideConnectionErrorDialog()), () => dispatch(handleShowConnectionErrorDialog()));
        snapshotInfoWS.current = new WebSocketService(snapshotInfoUrl, (snapshotInfo) => dispatch(setSnapshotInfo(snapshotInfo)), () => dispatch(handleHideConnectionErrorDialog()), () => dispatch(handleShowConnectionErrorDialog()));
        if (runStatusWS.current && !runStatusWS.current.isConnected()) {
            runStatusWS.current.connect();
        }
        if (historyWS.current && !historyWS.current.isConnected()) {
            historyWS.current.connect();
        }
        if (snapshotInfoWS.current && !snapshotInfoWS.current.isConnected()) {
            snapshotInfoWS.current.connect();
        }
        // Cleanup function: disconnect WebSockets when component unmounts
        // Prevents memory leaks and dangling connections
        return () => {
            if (runStatusWS.current && runStatusWS.current.isConnected()) {
                runStatusWS.current.disconnect();
            }
            if (historyWS.current && historyWS.current.isConnected()) {
                historyWS.current.disconnect();
            }
            if (snapshotInfoWS.current && snapshotInfoWS.current.isConnected()) {
                snapshotInfoWS.current.disconnect();
            }
        };
    }, []);
    // Methods for sending data through WebSocket.
    const sendRunStatus = (data) => runStatusWS.current?.send(data);
    const sendHistory = (data) => historyWS.current?.send(data);
    const sendSnapshotInfo = (data) => snapshotInfoWS.current?.send(data);
    return {
        sendRunStatus,
        sendHistory,
        sendSnapshotInfo,
    };
};

;// ./src/stores/WebSocketStore/index.ts





;// ./src/stores/index.ts









const rootReducer = (0,redux/* combineReducers */.HY)({
    auth: AuthStore,
    projects: ProjectStore,
    graph: GraphStore,
    nodes: NodesStore,
    navigation: NavigationStore,
    webSocket: WebSocketStore,
    snapshots: SnapshotsStore
});
const store = (0,redux_toolkit_modern/* configureStore */.U1)({
    reducer: rootReducer
});
const useRootDispatch = react_redux/* useDispatch */.wA.withTypes();
/* harmony default export */ var stores = (store);

;// ./src/stores/SnapshotsStore/hooks.ts






const useInitSnapshots = () => {
    const dispatch = useRootDispatch();
    const isUpdateRequired = (0,react_redux/* useSelector */.d4)(getIsSnapshotUpdateRequired);
    const snapshotsSearchQuery = (0,react_redux/* useSelector */.d4)(getSnapshotsSearchQuery);
    (0,react.useEffect)(() => {
        dispatch(fetchGitgraphSnapshots(true));
        dispatch(fetchSnapshotTags());
    }, []);
    (0,react.useEffect)(() => {
        if (isUpdateRequired) {
            dispatch(fetchGitgraphSnapshots(false));
        }
    }, [isUpdateRequired]);
    (0,react.useEffect)(() => {
        dispatch(fetchGitgraphSnapshots(false));
    }, [snapshotsSearchQuery]);
};

;// ./src/stores/SnapshotsStore/index.ts






;// ./src/stores/NodesStore/selectors.ts

const selectors_getNodesState = (state) => state.nodes;
const getSubmitNodeResponseError = (0,reselect/* createSelector */.Mz)(selectors_getNodesState, (state) => state.submitNodeResponseError);
const getIsNodeSelected = (0,reselect/* createSelector */.Mz)(selectors_getNodesState, (state, nodeKey) => nodeKey, (state, nodeKey) => state.selectedNode === nodeKey);
const getRunningNode = (0,reselect/* createSelector */.Mz)(selectors_getNodesState, (state) => state.runningNode);
const getRunningNodeInfo = (0,reselect/* createSelector */.Mz)(selectors_getNodesState, (state) => state.runningNodeInfo);
const getAllNodes = (0,reselect/* createSelector */.Mz)(selectors_getNodesState, (state) => state.allNodes);
const getNode = (0,reselect/* createSelector */.Mz)(getAllNodes, (_, nodeKey) => nodeKey, (allNodes, key) => allNodes[key]);
const getIsNodeRunning = (0,reselect/* createSelector */.Mz)(selectors_getNodesState, (state) => state.isNodeRunning);
const getResults = (0,reselect/* createSelector */.Mz)(selectors_getNodesState, (state) => state.results);
const getIsAllStatusesUpdated = (0,reselect/* createSelector */.Mz)(selectors_getNodesState, (state) => state.isAllStatusesUpdated);
const getUpdateAllButtonPressed = (0,reselect/* createSelector */.Mz)(selectors_getNodesState, (state) => state.updateAllButtonPressed);
const getIsRescanningNodes = (0,reselect/* createSelector */.Mz)(selectors_getNodesState, (state) => state.isRescanningNodes);

;// ./src/utils/formatDateTime.ts
/**
 * Formats ISO 8601 timestamp to "YYYY-MM-DD HH:MM:SS" format.
 */
const formatDateTime = (dateTimeString) => {
    const [date, time] = dateTimeString.split("T");
    const timeWithoutZone = time.split("+")[0].split("Z")[0];
    const timeWithoutMilliseconds = timeWithoutZone.split(".")[0];
    return `${date} ${timeWithoutMilliseconds}`;
};
/**
 * Formats ISO 8601 timestamp to "YYYY-MM-DD" format.
 */
const formatDate = (dateTimeString) => {
    const dateAndTime = dateTimeString.split("T");
    return `${dateAndTime[0]} `;
};

;// ./src/stores/NodesStore/actions.ts





const { setSelectedNode, setSubmitNodeResponseError, runNode, setRunningNode, setRunningNodeInfo, setAllNodes, setNodeParameter: actions_setNodeParameter, setIsNodeRunning, setResults, setIsAllStatusesUpdated, setUpdateAllButtonPressed, setIsRescanningNodes, } = nodesSlice.actions;
const fetchAllNodes = (rescan) => async (dispatch) => {
    dispatch(setAllNodes(undefined));
    dispatch(setIsRescanningNodes(true));
    const response = await NodesApi.fetchAllNodes(rescan);
    if (response.isOk) {
        dispatch(setAllNodes(response.result));
    }
    else if (response.error) {
        console.error("Failed to fetch all nodes:", response.error);
    }
    dispatch(setIsRescanningNodes(false));
};
function parseDateString(dateString) {
    const [datePart, timePart] = dateString.split(" ");
    const [year, month, day] = datePart.split("/").map(Number);
    const [hours, minutes, seconds] = timePart.split(":").map(Number);
    return new Date(year, month - 1, day, hours, minutes, seconds);
}
const formatString = (str) => {
    return str
        .split("_")
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ");
};
const fetchNodeResults = () => async (dispatch, getState) => {
    const lastRunResponse = await NodesApi.fetchLastRunInfo();
    if (lastRunResponse && lastRunResponse.isOk) {
        const lastRunResponseResult = lastRunResponse.result;
        if (lastRunResponseResult && lastRunResponseResult.status !== "error") {
            const idx = lastRunResponseResult.idx.toString();
            if (lastRunResponseResult.idx) {
                const snapshotResponse = await SnapshotsApi.fetchSnapshotResult(idx);
                if (snapshotResponse && snapshotResponse.isOk) {
                    const state = getState();
                    const runningNodeInfo = getRunningNodeInfo(state);
                    const runningNode = getRunningNode(state);
                    const state_updates = {};
                    if (lastRunResponseResult.state_updates) {
                        Object.entries(lastRunResponseResult.state_updates).forEach(([key, graph]) => {
                            state_updates[key] = { ...graph, stateUpdated: false };
                        });
                    }
                    if (runningNodeInfo && runningNodeInfo.timestampOfRun) {
                        const startDateAndTime = parseDateString(runningNodeInfo?.timestampOfRun);
                        const now = new Date();
                        const diffInMs = now.getTime() - startDateAndTime.getTime();
                        const diffInSeconds = Math.floor(diffInMs / 1000);
                        dispatch(setRunningNodeInfo({
                            ...runningNodeInfo,
                            runDuration: diffInSeconds.toFixed(2),
                            status: lastRunResponseResult.status,
                            idx: lastRunResponseResult.idx.toString(),
                            state_updates,
                        }));
                    }
                    else if (!runningNodeInfo?.timestampOfRun) {
                        dispatch(setRunningNodeInfo({
                            ...runningNodeInfo,
                            lastRunNodeName: lastRunResponseResult.name,
                            status: lastRunResponseResult.status,
                            idx: lastRunResponseResult.idx.toString(),
                            state_updates,
                        }));
                        let parameters = {};
                        Object.entries(lastRunResponseResult.passed_parameters ?? {}).forEach(([key, value]) => {
                            parameters = {
                                ...parameters,
                                [key]: {
                                    default: value,
                                    title: formatString(key),
                                    type: "string",
                                },
                            };
                        });
                        dispatch(setRunningNode({
                            ...runningNode,
                            parameters,
                            // parameters: { sadada: { dadasda: "dadasda" } },
                        }));
                    }
                    dispatch(setResults(snapshotResponse.result));
                }
                else {
                    console.error("Failed to fetch snapshot result:", snapshotResponse.error);
                }
            }
            else {
                console.warn("Last run idx is falsy:", lastRunResponseResult.idx);
            }
        }
        else {
            const state = getState();
            const runningNodeInfo = getRunningNodeInfo(state);
            const runningNode = getRunningNode(state);
            const error = lastRunResponseResult && lastRunResponseResult.error ? lastRunResponseResult.error : undefined;
            if (!lastRunResponseResult) {
                dispatch(setRunningNodeInfo({
                    ...runningNodeInfo,
                    status: "pending",
                    error,
                }));
            }
            else if (lastRunResponseResult && lastRunResponseResult.status === "error") {
                let parameters = {};
                Object.entries(lastRunResponseResult.run_result?.parameters ?? {}).forEach(([key, value]) => {
                    parameters = {
                        ...parameters,
                        [key]: {
                            default: value,
                            title: formatString(key),
                            type: "string",
                        },
                    };
                });
                dispatch(setRunningNode({
                    ...runningNode,
                    parameters,
                    // parameters: { sadada: { dadasda: "dadasda" } },
                }));
                dispatch(setRunningNodeInfo({
                    ...runningNodeInfo,
                    status: "error",
                    timestampOfRun: formatDateTime(lastRunResponseResult.run_result?.created_at ?? ""),
                    runDuration: lastRunResponseResult.run_result?.run_duration?.toString(),
                    state_updates: lastRunResponseResult.state_updates,
                    idx: lastRunResponseResult.idx.toString(),
                    // parameters: lastRunResponseResult.run_result?.parameters,
                    error,
                }));
                console.error("Last run status was error", lastRunResponse);
            }
        }
    }
    else {
        if (!lastRunResponse.isOk) { // Do nothing if isOK, since this means that there was no last run
            console.log("Failed to fetch last run info:", lastRunResponse);
        }
    }
};
/**
 * Format Date object to "YYYY/MM/DD HH:mm:ss" string for display.
 *
 * Used to display execution timestamps in the UI. This format matches
 * the NodesContext.parseDateString() format for bidirectional conversion.
 */
const actions_formatDate = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");
    return `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`;
};
/**
 * Extract parameter values from parameter definitions for API submission.
 *
 * Transforms parameter metadata objects into a simple key-value map containing
 * only the default values needed for backend execution.
 *
 * @param parameters - Full parameter definitions with type, title, description
 * @returns Simplified map of parameter names to values for API payload
 */
const transformInputParameters = (parameters) => {
    return Object.entries(parameters).reduce((acc, [key, parameter]) => {
        acc[key] = parameter.value ?? null;
        return acc;
    }, {});
};
/**
 * Submit node execution request to backend and update execution state.
 *
 * Handles the complete flow of starting a calibration run:
 * 1. Reset execution state and clear previous results
 * 2. Submit parameters to backend API
 * 3. Update UI state based on success/failure
 * 4. Trigger snapshot refresh if tracking latest results
 *
 * After successful submission, WebSocket updates will drive further state changes
 * (progress updates, completion status, etc.) via NodesContext.
 *
 * @remarks
 * **FRAGILE: Error Handling**:
 * Assumes error format matches ErrorWithDetails structure with detail[0].
 * If backend returns different error format, will throw accessing undefined properties.
 * No try-catch wrapping the API call - network errors will crash the component.
 *
 * **State Synchronization**:
 * Sets initial status to "running" optimistically before WebSocket confirms.
 * WebSocket updates (via NodesContext useEffect) will override this with actual status.
 *
 * **Side Effect: Snapshot Fetching**:
 * Conditionally fetches snapshot if trackLatestSidePanel is enabled. This coupling
 * between node execution and snapshot state makes the flow harder to follow.
 */
const handleRunNode = (node) => async (dispatch, getState) => {
    dispatch(runNode(node));
    const result = await NodesApi.submitNodeParameters(node.name, transformInputParameters(node.parameters));
    if (result.isOk) {
        dispatch(setRunningNodeInfo({ timestampOfRun: actions_formatDate(new Date()), status: "running" }));
    }
    else {
        const errorWithDetails = result.error;
        dispatch(setSubmitNodeResponseError({
            nodeName: node.name,
            name: `${errorWithDetails.detail[0].type ?? "Error msg"}: `,
            msg: errorWithDetails.detail[0].msg,
        }));
        dispatch(setRunningNodeInfo({
            timestampOfRun: actions_formatDate(new Date()),
            status: "error",
        }));
    }
    if (getTrackLatestSidePanel(getState())) {
        dispatch(fetchOneSnapshot(Number(getFirstId(getState())), Number(getSecondId(getState())), false, true));
    }
};

;// ./src/stores/NodesStore/hooks.ts






const useInitNodes = () => {
    const dispatch = useRootDispatch();
    const isNodeRunning = (0,react_redux/* useSelector */.d4)(getIsNodeRunning);
    const runningNodeInfo = (0,react_redux/* useSelector */.d4)(getRunningNodeInfo);
    const runStatusType = (0,react_redux/* useSelector */.d4)(getRunStatusType);
    const isRunStatusRunning = (0,react_redux/* useSelector */.d4)(getRunStatusIsRunning);
    (0,react.useEffect)(() => {
        if (!isNodeRunning) {
            dispatch(fetchNodeResults());
            if (runningNodeInfo?.status === "running") {
                dispatch(setRunningNodeInfo({
                    ...runningNodeInfo,
                    status: "finished",
                }));
            }
        }
    }, [isNodeRunning]);
    (0,react.useEffect)(() => {
        if (runStatusType === "node" && isNodeRunning !== isRunStatusRunning) {
            dispatch(setIsNodeRunning(isRunStatusRunning));
        }
    }, [runStatusType, isRunStatusRunning]);
};

;// ./src/stores/NodesStore/index.ts






;// ./src/stores/NavigationStore/selectors.ts


const getNavigationState = (state) => state.navigation;
const getActivePage = (0,reselect/* createSelector */.Mz)(getNavigationState, (navigationState) => navigationState.activePage);
const getOpenedOncePages = (0,reselect/* createSelector */.Mz)(getNavigationState, (navigationState) => navigationState.openedOncePages);
const getIsRefreshButtonShown = (0,reselect/* createSelector */.Mz)(getActivePage, (activePage) => activePage && [NODES_KEY, GRAPH_LIBRARY_KEY].includes(activePage));

;// ./src/stores/NavigationStore/actions.ts





const { setActivePage, } = navigationSlice.actions;
const refreshPage = () => (dispatch, getState) => {
    const activePage = getActivePage(getState());
    switch (activePage) {
        case NODES_KEY:
            dispatch(fetchAllNodes(true));
            break;
        case GRAPH_LIBRARY_KEY:
            dispatch(fetchAllCalibrationGraphs(true));
            break;
        default:
            break;
    }
};

;// ./src/stores/NavigationStore/index.ts




;// ./src/modules/SidebarMenu/MenuItem.tsx








const MenuItem = ({ menuItem, keyId, hideText, onClick, isSelected = false, isDisabled = false }) => {
    const dispatch = useRootDispatch();
    if (!menuItem) {
        return null;
    }
    const { dataCy, title, sideBarTitle, icon: Icon, atBottom } = menuItem;
    const displayTitle = sideBarTitle || title;
    const handleClick = () => {
        if (!atBottom) {
            dispatch(setActivePage(keyId));
        }
        onClick?.();
    };
    const button = ((0,jsx_runtime.jsxs)("button", { disabled: isDisabled, onClick: handleClick, className: classNames(MenuItem_module.itemWrapper, isSelected && MenuItem_module.selected), "data-cy": dataCy, "data-testid": `menu-item-${keyId}`, children: [Icon && (0,jsx_runtime.jsx)(Icon, { color: MENU_TEXT_COLOR }), !hideText && displayTitle && (0,jsx_runtime.jsxs)("div", { "data-testid": `menu-item-title-${keyId}`, children: [" ", displayTitle, " "] })] }));
    return isDisabled ? ((0,jsx_runtime.jsx)(Tooltip/* default */.A, { title: "Please select a project before accessing these pages", placement: "right", children: (0,jsx_runtime.jsx)("span", { children: button }) })) : (button);
};
/* harmony default export */ var SidebarMenu_MenuItem = (MenuItem);

;// ./src/modules/SidebarMenu/styles/SidebarMenu.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var SidebarMenu_module = ({"container":"SidebarMenu-module__container","sidebarMenu":"SidebarMenu-module__sidebarMenu","opened":"SidebarMenu-module__opened","collapsed":"SidebarMenu-module__collapsed","expanded":"SidebarMenu-module__expanded","qualibrateLogo":"SidebarMenu-module__qualibrateLogo","menuContent":"SidebarMenu-module__menuContent","menuBottomContent":"SidebarMenu-module__menuBottomContent","menuUpperContent":"SidebarMenu-module__menuUpperContent","themeToggleContainer":"SidebarMenu-module__themeToggleContainer"});
;// ./src/utils/cyKeys.ts
const cyKeys = {
    LOGIN_PAGE: "login-page",
    PROJECT_TAB: "project-tab",
    DATA_TAB: "data-tab",
    HELP_TAB: "help-tab",
    TOGGLE_SIDEBAR: "toggle-sidebar",
    CALIBRATION_TAB: "calibration-tab",
    NODES_TAB: "nodes-tab",
    HOME_PAGE: "home-page",
    projects: {
        LETS_START_BUTTON: "lets-start-button",
        PROJECT: "project-item",
    },
};
/* harmony default export */ var utils_cyKeys = (cyKeys);

;// ./src/modules/themeModule/prismColors.ts
const prismColors = {
    "--code-highlight-comment-color": { light: "#008000", dark: "#6272a4" },
    "--code-highlight-prolog-color": { light: "#008000", dark: "#cfcfc2" },
    "--code-highlight-doctype-color": { light: "#008000", dark: "#6272a4" },
    "--code-highlight-cdata-color": { light: "#008000", dark: "#6272a4" },
    "--code-highlight-tag-color": { light: "#c92c2c", dark: "#dc68aa" },
    "--code-highlight-entity-color": { light: "#a67f59", dark: "#8be9fd" },
    "--code-highlight-atrule-color": { light: "#00f", dark: "#62ef75" },
    "--code-highlight-url-color": { light: "#a67f59", dark: "#66d9ef" },
    "--code-highlight-selector-color": { light: "#2f9c0a", dark: "#cfcfc2" },
    "--code-highlight-string-color": { light: "#2f9c0a", dark: "#f1fa8c" },
    "--code-highlight-property-color": { light: "#c92c2c", dark: "#ffb86c" },
    "--code-highlight-important-color": { light: "#e90", dark: "#ff79c6" },
    "--code-highlight-punctuation-color": { light: "#5f6364", dark: "#e6db74" },
    "--code-highlight-number-color": { light: "#c92c2c", dark: "#bd93f9" },
    "--code-highlight-function-color": { light: "#2f9c0a", dark: "#50fa7b" },
    "--code-highlight-class-name-color": { light: "#00f", dark: "#ffb86c" },
    "--code-highlight-keyword-color": { light: "#00f", dark: "#ff79c6" },
    "--code-highlight-boolean-color": { light: "#c92c2c", dark: "#ffb86c" },
    "--code-highlight-operator-color": { light: "#a67f59", dark: "#8be9fd" },
    "--code-highlight-char-color": { light: "#2f9c0a", dark: "#ff879d" },
    "--code-highlight-regex-color": { light: "#e90", dark: "#50fa7b" },
    "--code-highlight-variable-color": { light: "#a67f59", dark: "#50fa7b" },
    "--code-highlight-constant-color": { light: "#c92c2c", dark: "#ffb86c" },
    "--code-highlight-symbol-color": { light: "#c92c2c", dark: "#ffb86c" },
    "--code-highlight-function-name-color": { light: "#c92c2c", dark: "#ffb86c" },
    "--code-highlight-builtin-color": { light: "#2f9c0a", dark: "#ff79c6" },
    "--code-highlight-attr-name-color": { light: "#2f9c0a", dark: "#cfcfc2" },
    "--code-highlight-attr-value-color": { light: "#00f", dark: "#7ec699" },
    "--code-highlight-inserted-color": { light: "#2f9c0a", dark: "#7ec699" },
    "--code-highlight-deleted-color": { light: "#c92c2c", dark: "#e2777a" },
    "--code-highlight-namespace-color": { light: "#c92c2c", dark: "#e2777a" },
};
/* harmony default export */ var themeModule_prismColors = (prismColors);

;// ./src/modules/themeModule/diffColors.ts
const diffColors = {
    "--diff-gutter-delete-background-color": {
        dark: "#9b2147",
        light: "#ff8989",
    },
    "--diff-gutter-insert-background-color": {
        dark: "#0c8466",
        light: "#76e9c8",
    },
    "--diff-gutter-selected-background-color": {
        dark: "#736628",
        light: "#d99e0a",
    },
    "--diff-code-delete-background-color": {
        dark: "#37212b",
        light: "#ffeded",
    },
    "--diff-code-insert-background-color": {
        dark: "#1f3331",
        light: "#ebfcf7",
    },
    "--diff-code-selected-background-color": {
        dark: "#383427",
        light: "#fcf3bf",
    },
    "--diff-code-insert-edit-background-color": {
        dark: "#156451",
        light: "#bcf4e4",
    },
    "--diff-code-delete-edit-background-color": {
        dark: "#73223c",
        light: "#ffc5c5",
    },
};
/* harmony default export */ var themeModule_diffColors = (diffColors);

;// ./src/modules/themeModule/themeHelper.ts


const DARK = "dark";
const LIGHT = "light";
const updateColorTheme = () => {
    const theme = getColorTheme();
    const arrayOfVariableKeys = Object.keys(colors);
    const arrayOfVariableValues = Object.values(colors);
    arrayOfVariableKeys.forEach((cssVariableKey, index) => {
        document.documentElement.style.setProperty(cssVariableKey, arrayOfVariableValues[index][theme]);
    });
};
const toggleColorTheme = () => {
    const cur = getColorTheme();
    return setColorTheme(cur === LIGHT ? DARK : LIGHT);
};
const setColorTheme = (theme) => {
    localStorage.setItem("colorTheme", theme);
    updateColorTheme();
    return theme;
};
const getColorTheme = () => {
    const color = localStorage.getItem("colorTheme") || "";
    if (![DARK, LIGHT].includes(color)) {
        return DARK;
    }
    return color;
};
const colors = {
    ...themeModule_prismColors,
    ...themeModule_diffColors,
    "--disabled-tab": {
        dark: "rgba(43, 44, 50, 0.5)",
        light: "rgba(246, 249, 250, 0.6)",
    },
    "--selected-tab": { dark: "#2b2c32", light: "#F6F9FA" },
    "--layout-background": { dark: "#212125", light: "#e1e9ec" },
    "--background-color": { dark: "#2b2c32", light: "#f6f9fa" },
    "--active-text": { dark: "#2ccbe5", light: "#0FB0CB" },
    "--copy-field": { dark: "#C6CDD626", light: "#C2D1D64D" },
    //buttons
    "--blue-button": { dark: "#05869c", light: "#0FB0CB" },
    "--blue-button-text": { dark: "#ffffff", light: "#ffffff" },
    "--blue-button-disabled": { dark: "#42424c", light: "rgba(33, 33, 37, 0.1)" },
    "--blue-button-disabled-text": {
        dark: "rgba(255, 255, 255, 0.6)",
        light: "rgba(33, 33, 37, 0.6)",
    },
    "--secondary-blue-button": { dark: "#2ccbe5", light: "#0FB0CB" },
    "--secondary-blue-button-disabled": {
        dark: "#c6cdd6",
        light: "rgba(33, 33, 37, 0.6)",
    },
    // outline button
    "--outline-button": { light: "#FFFFFF", dark: "#323339" },
    "--outline-button-border": { light: "#c2d1d6", dark: "#42424c" },
    "--outline-button-text": { light: "#212125", dark: "#ffffff" },
    "--outline-button-disabled-text": { light: "#78797b", dark: "#a5abb3" },
    "--outline-button-active": {
        light: "rgba(15,176,203,0.1)",
        dark: "rgba(44, 203, 229, 0.1)",
    },
    "--outline-button-active-border": { light: "#018ca3", dark: "#2b5964" },
    "--outline-button-active-text": { light: "#018ca3", dark: "#2ccbe5" },
    "--box-background": { dark: "rgba(36,36,41,0.4)", light: "#FFFFFF" },
    // tooltip
    "--tooltip": { dark: "#2a2b31", light: "#ffffff" },
    "--tooltip-border": { dark: "#42424c", light: "rgba(194, 209, 214, 0.5)" },
    "--tooltip-shadow": {
        dark: "0px 4px 8px rgba(0, 0, 0, 0.25)",
        light: "0px 4px 8px rgba(0, 0, 0, 0.25)",
    },
    "--table-header": { dark: "#323339", light: "#FFFFFF" },
    "--table-background": { dark: "#2B2C32", light: "#F6F9FA4D" },
    "--table-hover": { dark: "#2CCBE50D", light: "#2CCBE533" },
    // popup
    "--popup-background": { dark: "#323339", light: "#FFFFFF" },
    "--overlay-background": { dark: "#212125CC", light: "#212125CC" },
    "--overlay-background-blocking": { dark: "#212125", light: "#c2d1d6" },
    // label
    "--label-background": { dark: "#484a50", light: "#e0e9ec" },
    "--font": { dark: "#ffffff", light: "#212125" },
    "--body-font": { dark: "#a5abb3", light: "#212125" },
    "--sub-text-color": { dark: "#a5abb3", light: "#78797b" },
    "--hover-grey": {
        dark: "rgba(198, 205, 214, 0.03)",
        light: "rgba(33, 33, 37, 0.1)",
    },
    "--border-color": { dark: "#42424c", light: "#c2d1d6" },
    "--input-background": { dark: "#2A2B31", light: "#ffffff" },
    "--input-border": { dark: "#42424C", light: "rgba(194, 209, 214, 0.5)" },
    "--input-border-active": { dark: "#c6cdd6", light: "rgba(33, 33, 37, 0.6)" },
    "--input-outline": {
        dark: "rgba(44, 203, 229, 0.3)",
        light: "rgba(44, 203, 229, 0.3)",
    },
    // checkbox
    "--checkbox-background": { dark: "#C6CDD60D", light: "#C6CDD60D" },
    "--checkbox-border": { dark: "#42424C", light: "#c2d1d6" },
    "--checkbox-hover-border": { dark: "#94e5f2", light: "#94e5f2" },
    "--checkbox-active-background": { dark: "#2ccbe5", light: "#0FB0CB" },
    "--icon-thumbnail": { dark: "#42424c", light: "rgba(33, 33, 37, 0.15)" },
    "--error": { dark: "#ff2463", light: "#ff2463" },
    "--warning": { dark: "#ac9730", light: "#C9780099" },
    "--warning-bright": { dark: "#FFDB2C", light: "#C97800" },
    "--warning-border": { dark: "#FFDB2C33", light: "#C9780099" },
    "--log-background": { dark: "#1e1e1e", light: "#ffffff" },
    "--log-color": { dark: "#fff", light: "#1e1e1e" },
    //admin
    "--admin-header-background": { dark: "#242429", light: "#ffffff" },
    "--code-background": { dark: "#2b2c32", light: "#F6F9FA" },
    "--code-background-hover": { dark: "#36383e", light: "#0FB0CB" },
    // experiments
    "--job-list-header": { dark: "#212125", light: "#e1e9ec" },
    "--job-list-background": { dark: "#242429", light: "#FFFFFF" },
    // welcome page
    "--selection-color": {
        dark: "rgba(198, 205, 214, 0.03)",
        light: "#2CCBE51A",
    },
    // jobs
    "--grouping-border": { dark: "rgba(198, 205, 214, 0.6)", light: "#C2D1D6" },
    "--grouping-border-hover": {
        dark: "rgba(198, 205, 214, 1)",
        light: "#9ea8af",
    },
    "--grouping-border-active": { dark: "#fff", light: "#212125" },
    // statuses
    "--green": { dark: "#bdff94", light: "#008F68" },
    "--green-light": { dark: "#2e392d", light: "#13D9A133" },
    "--yellow": { dark: "#fed465", light: "#C97800" },
    "--yellow-light": { dark: "#403931", light: "#FFDB2C4D" },
    "--blue": { dark: "#81e1ff", light: "#0073DD" },
    "--blue-light": { dark: "#2e3846", light: "#48A7FF33" },
    "--red": { dark: "#ff8484", light: "#E80043" },
    "--red-light": { dark: "#40333a", light: "#edd9e5" },
    "--grey": { dark: "#c6cdd6", light: "rgba(33, 33, 37, 0.6)" },
    "--grey-light": {
        dark: "#37393f",
        light: "rgba(33, 33, 37, 0.1)",
    },
};

;// ./src/modules/themeModule/GlobalThemeContext.tsx



const GlobalThemeContext = react.createContext(null);
function GlobalThemeContextProvider(props) {
    const { children } = props;
    const [theme, _setTheme] = (0,react.useState)(getColorTheme());
    const [pinSideMenu, setPinSideMenu] = (0,react.useState)(true);
    const toggleTheme = (0,react.useCallback)(() => {
        _setTheme(toggleColorTheme());
    }, [_setTheme]);
    return ((0,jsx_runtime.jsx)(GlobalThemeContext.Provider, { value: {
            theme,
            toggleTheme,
            pinSideMenu,
            setPinSideMenu,
        }, children: children }));
}
/* harmony default export */ var themeModule_GlobalThemeContext = (GlobalThemeContext);

;// ./src/components/ArraySelector/components/EnumSelectorDropdown/EnumSelectorDropdown.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var EnumSelectorDropdown_module = ({"popupWrapper":"EnumSelectorDropdown-module__popupWrapper","popup":"EnumSelectorDropdown-module__popup","popupInput":"EnumSelectorDropdown-module__popupInput","searchField":"EnumSelectorDropdown-module__searchField","clearSearchButton":"EnumSelectorDropdown-module__clearSearchButton","popupList":"EnumSelectorDropdown-module__popupList","popupOption":"EnumSelectorDropdown-module__popupOption","selected":"EnumSelectorDropdown-module__selected"});
;// ./src/components/ArraySelector/utils.ts
const getSearchStringIndex = (sourceString, searchValue) => sourceString.trim().toLowerCase().indexOf(searchValue.trim().toLowerCase());

;// ./src/utils/hooks/useClickOutside.ts

const useClickOutside = (callback) => {
    const ref = (0,react.useRef)(null);
    const handleCallback = (0,react.useCallback)((evt) => {
        if (ref?.current && !ref.current.contains(evt.target)) {
            callback();
        }
    }, [callback]);
    (0,react.useEffect)(() => {
        window.addEventListener("mouseup", handleCallback);
        window.addEventListener("touchend", handleCallback);
        return () => {
            window.removeEventListener("mouseup", handleCallback);
            window.removeEventListener("touchend", handleCallback);
        };
    }, [callback]);
    return ref;
};
/* harmony default export */ var hooks_useClickOutside = (useClickOutside);

;// ./src/components/ArraySelector/components/EnumSelectorDropdown/EnumSelectorDropdown.tsx






const EnumSelectorDropdown = ({ open, onClose, onChange, options, value, }) => {
    const [searchValue, setSearchValue] = (0,react.useState)("");
    const inputRef = (0,react.useRef)(null);
    const buttonRef = hooks_useClickOutside(onClose);
    const filteredOptions = (0,react.useMemo)(() => options.filter(option => getSearchStringIndex(option, searchValue) !== -1), [value, options, searchValue]);
    const handleEnterSearchValue = (evt) => setSearchValue(evt.target.value);
    const handleClearSearchValue = () => setSearchValue("");
    const handleSelect = (0,react.useCallback)((id) => {
        onChange(id);
        onClose();
    }, [value]);
    (0,react.useEffect)(() => {
        const handleEsc = (evt) => {
            open && evt.key === "Escape" && onClose();
        };
        window.addEventListener("keydown", handleEsc);
        return () => {
            window.removeEventListener("keydown", handleEsc);
        };
    }, [open]);
    (0,react.useEffect)(() => {
        open && inputRef.current?.focus();
    }, [open]);
    const renderSelectorOption = (option) => {
        const isSelected = value.includes(option);
        const searchStringIndex = getSearchStringIndex(option, searchValue);
        const parts = [
            option.slice(0, searchStringIndex),
            option.slice(searchStringIndex, searchStringIndex + searchValue.trim().length),
            option.slice(searchStringIndex + searchValue.trim().length),
        ];
        return (0,jsx_runtime.jsx)("span", { onClick: () => handleSelect(option), "data-value": option, className: classNames(EnumSelectorDropdown_module.popupOption, isSelected && EnumSelectorDropdown_module.selected), children: parts.map((part, index) => index === 1 ? (0,jsx_runtime.jsx)("strong", { children: part }, part) : part) }, option);
    };
    return open && ((0,jsx_runtime.jsx)("div", { className: EnumSelectorDropdown_module.popupWrapper, children: (0,jsx_runtime.jsxs)("div", { className: EnumSelectorDropdown_module.popup, ref: buttonRef, children: [(0,jsx_runtime.jsxs)("div", { className: EnumSelectorDropdown_module.popupInput, children: [(0,jsx_runtime.jsx)("input", { className: EnumSelectorDropdown_module.searchField, value: searchValue, onChange: handleEnterSearchValue, ref: inputRef, type: "text", placeholder: "Search option..." }), (0,jsx_runtime.jsx)("button", { className: EnumSelectorDropdown_module.clearSearchButton, onClick: handleClearSearchValue, children: "\u00D7" })] }), (0,jsx_runtime.jsx)("div", { className: EnumSelectorDropdown_module.popupList, children: filteredOptions.map(renderSelectorOption) })] }) }));
};
/* harmony default export */ var EnumSelectorDropdown_EnumSelectorDropdown = (EnumSelectorDropdown);

;// ./src/components/ArraySelector/components/ArraySelectorTrigger/ArraySelectorTrigger.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var ArraySelectorTrigger_module = ({"wrapper":"ArraySelectorTrigger-module__wrapper","disabled":"ArraySelectorTrigger-module__disabled","list":"ArraySelectorTrigger-module__list","counter":"ArraySelectorTrigger-module__counter","error":"ArraySelectorTrigger-module__error"});
;// ./src/components/ArraySelector/components/ArraySelectorTrigger/ArraySelectorTrigger.tsx




const MAX_SHOWN_VALUES = 2;
const ArraySelectorTrigger = ({ value, disabled, onClick, icon, }) => ((0,jsx_runtime.jsxs)("div", { className: classNames(ArraySelectorTrigger_module.wrapper, disabled && ArraySelectorTrigger_module.disabled), onClick: () => !disabled && onClick(), children: [(0,jsx_runtime.jsxs)("span", { className: ArraySelectorTrigger_module.list, children: [Array.isArray(value)
                    ? value.slice(0, MAX_SHOWN_VALUES).join(", ")
                    : value, value && (0,jsx_runtime.jsx)("span", { className: ArraySelectorTrigger_module.counter, children: (value.length > MAX_SHOWN_VALUES) ? `+${(value.length - MAX_SHOWN_VALUES)}` : "" })] }), !disabled && icon] }));
/* harmony default export */ var ArraySelectorTrigger_ArraySelectorTrigger = (ArraySelectorTrigger);

;// ./src/components/Icons/utils.ts
const getSvgOptions = ({ rotationDegree }) => {
    return {
        style: {
            transform: `rotate(${rotationDegree || 0}deg)`,
            transition: "all 0.25s ease-in",
        },
    };
};

;// ./src/components/Icons/ArrowIcon.tsx




const ArrowIcon = ({ width = 10, height = 5, color = MAIN_TEXT_COLOR, options }) => {
    const svgOptions = getSvgOptions({
        rotationDegree: options?.rotationDegree || 0,
    });
    return ((0,jsx_runtime.jsx)("svg", { width: width, height: height, viewBox: "0 0 10 5", fill: "none", xmlns: "http://www.w3.org/2000/svg", ...svgOptions, transform: "rotate(90)", children: (0,jsx_runtime.jsx)("path", { d: "M5 4.7998L9.33013 0.299805H0.669873L5 4.7998Z", fill: color }) }));
};

;// ./src/components/Icons/CheckMarkAfterIcon.tsx


const CheckMarkAfterIcon = ({ width = 24, height = 24 }) => ((0,jsx_runtime.jsx)("svg", { width: width, height: height, viewBox: "0 0 24 25", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: (0,jsx_runtime.jsx)("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M0 12.251C0 5.62356 5.37258 0.250977 12 0.250977C18.6274 0.250977 24 5.62356 24 12.251C24 18.8784 18.6274 24.251 12 24.251C5.37258 24.251 0 18.8784 0 12.251ZM17.6999 9.46519C18.0944 9.07863 18.1008 8.4455 17.7142 8.05105C17.3277 7.6566 16.6945 7.6502 16.3001 8.03676L9.85714 14.3508L7.69993 12.2368C7.30548 11.8502 6.67235 11.8566 6.28579 12.251C5.89923 12.6455 5.90562 13.2786 6.30007 13.6652L9.15721 16.4652C9.54604 16.8462 10.1682 16.8462 10.5571 16.4652L17.6999 9.46519Z", fill: "#00D59A" }) }));

;// ./src/components/Icons/CheckMarkBeforeIcon.tsx


const CheckMarkBeforeIcon = ({ width = 24, height = 24 }) => ((0,jsx_runtime.jsxs)("svg", { width: width, height: height, viewBox: "0 0 26 27", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: [(0,jsx_runtime.jsx)("path", { opacity: "0.5", fillRule: "evenodd", clipRule: "evenodd", d: "M13 1.12549C6.37258 1.12549 1 6.49807 1 13.1255V13.1255C1 19.7529 6.37258 25.1255 13 25.1255V25.1255C19.6274 25.1255 25 19.7529 25 13.1255V13.1255C25 6.49807 19.6274 1.12549 13 1.12549V1.12549Z", stroke: "#3CDEF8", strokeWidth: "2" }), (0,jsx_runtime.jsx)("path", { d: "M8 13.8255L10.8571 16.6255L18 9.62549", stroke: "#3CDEF8", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" })] }));

;// ./src/components/Icons/CheckmarkIcon.tsx


const CheckmarkIcon = ({ width = 38, height = 38, className, ...props }) => {
    return ((0,jsx_runtime.jsxs)("svg", { className: className, width: width, height: height, viewBox: "0 0 38 38", fill: "none", xmlns: "http://www.w3.org/2000/svg", ...props, children: [(0,jsx_runtime.jsx)("circle", { cx: "19", cy: "19", r: "18", stroke: "#32FFC6", strokeWidth: "2", opacity: "0.3", vectorEffect: "non-scaling-stroke" }), (0,jsx_runtime.jsx)("path", { d: "M13 20.4L17 24L27 15", stroke: "#32FFC6", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", vectorEffect: "non-scaling-stroke" })] }));
};
/* harmony default export */ var Icons_CheckmarkIcon = (CheckmarkIcon);

;// ./src/components/Icons/CircularLoaderPercentage.tsx


const CircularLoaderPercentage = ({ percentage = 0, color = "#3CDEF8", width = 30, height = 30, }) => {
    const normalizedPercentage = Math.max(0, Math.min(percentage, 100));
    const radius = 14;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference * (1 - normalizedPercentage / 100);
    return ((0,jsx_runtime.jsxs)("svg", { xmlns: "http://www.w3.org/2000/svg", width: width, height: height, viewBox: "0 0 30 30", fill: "none", children: [(0,jsx_runtime.jsx)("circle", { cx: "15", cy: "15", r: "14", stroke: "#42424C", strokeWidth: "1", fill: "none" }), (0,jsx_runtime.jsx)("circle", { cx: "15", cy: "15", r: "14", stroke: color, strokeWidth: "1.8", fill: "none", strokeDasharray: circumference, strokeDashoffset: offset, strokeLinecap: "round", style: {
                    transition: "stroke-dashoffset 0.5s ease-in-out",
                    transform: "rotate(-90deg)",
                    transformOrigin: "50% 50%",
                } }), (0,jsx_runtime.jsxs)("text", { x: "50%", y: "52%", textAnchor: "middle", dominantBaseline: "middle", fill: color, fontFamily: "Roboto, sans-serif", fontSize: "9px", fontWeight: "700", children: [Math.round(normalizedPercentage), "%"] })] }));
};
/* harmony default export */ var Icons_CircularLoaderPercentage = (CircularLoaderPercentage);

;// ./src/components/Icons/CircularLoaderProgress.tsx

const CircularLoaderProgress = ({ percentage = 0, strokeColor = "#2CCBE5", size = 16, strokeWidth = 3, }) => {
    const normalized = Math.max(0, Math.min(percentage, 100)) / 100;
    const radius = (size - strokeWidth) / 2;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference * (1 - normalized);
    return ((0,jsx_runtime.jsx)("svg", { width: size, height: size, viewBox: `0 0 ${size} ${size}`, fill: "none", children: (0,jsx_runtime.jsx)("path", { d: `
            M ${size / 2} ${strokeWidth / 2}
            A ${radius} ${radius} 0 1 1 ${(size / 2) - 0.01} ${strokeWidth / 2}
          `, stroke: strokeColor, strokeWidth: strokeWidth, strokeLinecap: "round", strokeDasharray: circumference, strokeDashoffset: offset, fill: "none", style: {
                transition: "stroke-dashoffset 0.4s ease-in-out",
                transformOrigin: "center",
            } }) }));
};
/* harmony default export */ var Icons_CircularLoaderProgress = (CircularLoaderProgress);

;// ./src/components/Icons/CollapseSideMenuIcon.tsx


const CollapseSideMenuIcon = () => {
    return ((0,jsx_runtime.jsxs)("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 16 16", fill: "none", style: { width: "16px", height: "16px", flexShrink: 0 }, children: [(0,jsx_runtime.jsx)("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M9.26278 8L16 15.3441L15.3154 16L7.97648 8L15.3154 0L16 0.655904L9.26278 8Z", fill: "var(--grey-highlight)" }), (0,jsx_runtime.jsx)("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M1.2863 8L8.02352 15.3441L7.33892 16L0 8L7.33892 0L8.02352 0.655904L1.2863 8Z", fill: "var(--grey-highlight)" })] }));
};
/* harmony default export */ var Icons_CollapseSideMenuIcon = (CollapseSideMenuIcon);

;// ./src/components/Icons/DataIcon.tsx


const DataIcon = ({ width = 25, height = 24, className, }) => {
    return ((0,jsx_runtime.jsxs)("svg", { className: className, xmlns: "http://www.w3.org/2000/svg", width: width, height: height, viewBox: "0 0 25 24", fill: "none", children: [(0,jsx_runtime.jsx)("path", { d: "M7 16L10.3876 9.72807C10.9439 8.69828 12.2616 8.36407 13.2414 9.00429L14.7586 9.99571C15.7384 10.6359 17.0561 10.3017 17.6124 9.27193L21 3", stroke: "#ffffff", strokeWidth: "1.2" }), (0,jsx_runtime.jsx)("path", { d: "M22 21L2.5 21L2.5 2", stroke: "#ffffff", strokeWidth: "1.5", strokeDasharray: "1 1" })] }));
};
/* harmony default export */ var Icons_DataIcon = (DataIcon);

;// ./src/components/Icons/ErrorIcon.tsx


const ErrorIcon = ({ width = 38, height = 38, ...props }) => ((0,jsx_runtime.jsxs)("svg", { xmlns: "http://www.w3.org/2000/svg", width: width, height: height, viewBox: "0 0 38 38", fill: "none", ...props, children: [(0,jsx_runtime.jsx)("circle", { cx: "19", cy: "19", r: "18", stroke: "#FF6173", strokeWidth: "2", opacity: "0.3" }), (0,jsx_runtime.jsxs)("g", { transform: "translate(7 7)", children: [(0,jsx_runtime.jsx)("path", { d: "M10.4343 6.45598C10.4343 5.73199 10.8796 5.13512 11.5958 4.94721C12.3119 4.79246 13.028 5.10748 13.3349 5.72646C13.4372 5.94753 13.4733 6.16859 13.4733 6.41729C13.4552 6.76271 13.4297 7.10812 13.4041 7.45354C13.3785 7.79895 13.3529 8.14436 13.3349 8.48978C13.3018 9.02311 13.2672 9.55644 13.2326 10.0898C13.198 10.6231 13.1634 11.1564 13.1303 11.6897C13.0942 12.0379 13.0942 12.3529 13.0942 12.6955C13.0641 13.2648 12.5827 13.7014 11.9689 13.7014C11.355 13.7014 10.8796 13.2924 10.8435 12.7287C10.7924 11.897 10.7412 11.0735 10.6901 10.25C10.6389 9.42655 10.5878 8.60308 10.5366 7.77132C10.5186 7.55302 10.502 7.33333 10.4855 7.11365C10.4689 6.89397 10.4524 6.67428 10.4343 6.45598Z", fill: "#FF6173" }), (0,jsx_runtime.jsx)("path", { d: "M10.4592 17.7084C10.4592 16.9567 11.1452 16.3267 11.9636 16.3267C12.7881 16.3267 13.4681 16.9512 13.432 17.7415C13.4681 18.46 12.752 19.09 11.9636 19.09C11.1452 19.09 10.4592 18.46 10.4592 17.7084Z", fill: "#FF6173" })] })] }));
/* harmony default export */ var Icons_ErrorIcon = (ErrorIcon);

;// ./src/components/Icons/ExpandIcon.tsx


const ExpandIcon = (props) => (0,jsx_runtime.jsx)("svg", { xmlns: "http://www.w3.org/2000/svg", width: "12", height: "8", viewBox: "0 0 12 8", fill: "none", ...props, children: (0,jsx_runtime.jsx)("path", { d: "M1 1L6 6L11 1", stroke: "#7d8590", strokeWidth: "2", strokeLinecap: "round" }) });
/* harmony default export */ var Icons_ExpandIcon = (ExpandIcon);

;// ./src/components/Icons/ExpandSideMenuIcon.tsx


const ExpandSideMenuIcon = () => {
    return ((0,jsx_runtime.jsxs)("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 16 16", fill: "none", style: { width: "16px", height: "16px", flexShrink: 0 }, children: [(0,jsx_runtime.jsx)("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M6.73722 8L0 0.655904L0.684604 0L8.02352 8L0.684604 16L0 15.3441L6.73722 8Z", fill: "var(--grey-highlight)" }), (0,jsx_runtime.jsx)("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M14.7137 8L7.97648 0.655904L8.66108 0L16 8L8.66108 16L7.97648 15.3441L14.7137 8Z", fill: "var(--grey-highlight)" })] }));
};
/* harmony default export */ var Icons_ExpandSideMenuIcon = (ExpandSideMenuIcon);

;// ./src/components/Icons/GraphLibraryIcon.tsx


const GraphLibraryIcon = ({ width = 25, height = 24, className, }) => {
    return ((0,jsx_runtime.jsxs)("svg", { className: className, xmlns: "http://www.w3.org/2000/svg", width: width, height: height, viewBox: "0 0 25 24", fill: "none", children: [(0,jsx_runtime.jsxs)("g", { clipPath: "url(#clip0)", children: [(0,jsx_runtime.jsx)("circle", { cx: "20.5", cy: "19.5", r: "3.5", stroke: "#ffffff", strokeWidth: "1.2" }), (0,jsx_runtime.jsx)("circle", { cx: "13", cy: "12", r: "3.5", stroke: "#ffffff", strokeWidth: "1.2" }), (0,jsx_runtime.jsx)("circle", { cx: "4.5", cy: "4.5", r: "3.5", stroke: "#ffffff", strokeWidth: "1.2" }), (0,jsx_runtime.jsx)("path", { d: "M7 7L10.5 10", stroke: "#ffffff", strokeWidth: "1.5" }), (0,jsx_runtime.jsx)("path", { d: "M15.5 14L18.5 17", stroke: "#ffffff", strokeWidth: "1.5" }), (0,jsx_runtime.jsx)("path", { d: "M24.5 2.63398C25.1667 3.01888 25.1667 3.98113 24.5 4.36603L20.75 6.53109C20.0833 6.91599 19.25 6.43486 19.25 5.66506L19.25 1.33493C19.25 0.565134 20.0833 0.0840107 20.75 0.468911L24.5 2.63398Z", fill: "#18DAA4" })] }), (0,jsx_runtime.jsx)("defs", { children: (0,jsx_runtime.jsx)("clipPath", { id: "clip0", children: (0,jsx_runtime.jsx)("rect", { width: "25", height: "24", fill: "white" }) }) })] }));
};
/* harmony default export */ var Icons_GraphLibraryIcon = (GraphLibraryIcon);

;// ./src/components/Icons/GraphStatusIcon.tsx


const GraphStatusIcon = ({ width = 25, height = 24, className, }) => {
    return ((0,jsx_runtime.jsxs)("svg", { className: className, xmlns: "http://www.w3.org/2000/svg", width: width, height: height, viewBox: "0 0 25 24", fill: "none", children: [(0,jsx_runtime.jsxs)("g", { clipPath: "url(#clip0)", children: [(0,jsx_runtime.jsx)("circle", { cx: "20.5", cy: "19.5", r: "3.5", stroke: "#ffffff", strokeWidth: "1.2" }), (0,jsx_runtime.jsx)("circle", { cx: "13", cy: "12", r: "3.5", stroke: "#ffffff", strokeWidth: "1.2" }), (0,jsx_runtime.jsx)("circle", { cx: "4.5", cy: "4.5", r: "3.5", stroke: "#ffffff", strokeWidth: "1.2" }), (0,jsx_runtime.jsx)("path", { d: "M7 7L10.5 10", stroke: "#ffffff", strokeWidth: "1.5" }), (0,jsx_runtime.jsx)("path", { d: "M15.5 14L18.5 17", stroke: "#ffffff", strokeWidth: "1.5" }), (0,jsx_runtime.jsx)("path", { d: "M19 3.5C19 4.88071 20.1193 6 21.5 6C22.8807 6 24 4.88071 24 3.5C24 2.11929 22.8807 1 21.5 1", stroke: "#3CDEF8", strokeWidth: "1.6", strokeLinecap: "round" })] }), (0,jsx_runtime.jsx)("defs", { children: (0,jsx_runtime.jsx)("clipPath", { id: "clip0", children: (0,jsx_runtime.jsx)("rect", { width: "25", height: "24", fill: "white" }) }) })] }));
};
/* harmony default export */ var Icons_GraphStatusIcon = (GraphStatusIcon);

;// ./src/components/Icons/HelpIcon.tsx



const HelpIcon = ({ width = 24, height = 24, color = ACCENT_COLOR_LIGHT }) => ((0,jsx_runtime.jsxs)("svg", { xmlns: "http://www.w3.org/2000/svg", width: width, height: height, viewBox: "0 0 24 24", fill: "none", children: [(0,jsx_runtime.jsx)("circle", { cx: "12", cy: "12", r: "10.4", stroke: color, strokeWidth: "1.2" }), (0,jsx_runtime.jsx)("path", { fill: color, d: "M12.795 14.89h-1.826c-.005-.26-.007-.417-.007-.474 0-.585.098-1.066.293-1.444.196-.377.587-.802 1.175-1.274.587-.471.938-.78 1.052-.927a1.23 1.23 0 00.265-.764c0-.387-.157-.717-.472-.99-.31-.279-.73-.418-1.26-.418-.511 0-.939.144-1.283.432-.343.287-.58.726-.709 1.316l-1.847-.227c.052-.844.415-1.561 1.088-2.15.678-.59 1.566-.886 2.664-.886 1.156 0 2.075.3 2.757.9.683.594 1.025 1.287 1.025 2.08 0 .438-.127.854-.38 1.245-.248.392-.783.925-1.604 1.6-.425.349-.69.63-.795.842-.1.212-.146.592-.136 1.14zm-1.826 2.675v-1.989h2.012v1.99H10.97z" })] }));

;// ./src/components/Icons/InfoIcon.tsx



const InfoIcon = ({ width = 18, height = 18, color = ACCENT_COLOR_LIGHT, }) => ((0,jsx_runtime.jsxs)("svg", { xmlns: "http://www.w3.org/2000/svg", width: width, height: height, viewBox: "0 0 20 20", fill: "none", children: [(0,jsx_runtime.jsx)("circle", { cx: "10", cy: "10", r: "9", stroke: color, strokeWidth: "1" }), (0,jsx_runtime.jsx)("circle", { cx: "10", cy: "6", r: "1.2", fill: color }), (0,jsx_runtime.jsx)("path", { d: "M10 9.5V14", stroke: color, strokeWidth: "2", strokeLinecap: "round" })] }));

;// ./src/components/Icons/NewProjectButtonIcon.tsx


const NewProjectButtonIcon = ({ width = 160, height = 38, }) => {
    return ((0,jsx_runtime.jsxs)("svg", { width: width, height: height, viewBox: "0 0 160 38", fill: "none", children: [(0,jsx_runtime.jsx)("rect", { width: "160", height: "38", rx: "19", fill: "rgba(0, 147, 128, 0.6)" }), (0,jsx_runtime.jsx)("path", { d: "M26.583 17.917H32V20.083H26.583V25.5H24.417V20.083H19V17.917H24.417V12.5H26.583V17.917Z", fill: "white" }), (0,jsx_runtime.jsx)("text", { x: "40", y: "24", fill: "white", fontSize: "15", fontWeight: "bold", fontFamily: "Arial, sans-serif", children: "Create Project" })] }));
};
/* harmony default export */ var Icons_NewProjectButtonIcon = (NewProjectButtonIcon);

;// ./src/components/Icons/NodeLibraryIcon.tsx


const NodeLibraryIcon_GraphStatusIcon = ({ width = 24, height = 24, className, }) => {
    return ((0,jsx_runtime.jsxs)("svg", { className: className, xmlns: "http://www.w3.org/2000/svg", width: width, height: height, viewBox: "0 0 25 24", fill: "none", children: [(0,jsx_runtime.jsxs)("g", { clipPath: "url(#clip0)", children: [(0,jsx_runtime.jsx)("circle", { cx: "18.1734", cy: "6.64683", r: "4.5", transform: "rotate(-60 18.1734 6.64683)", stroke: "#ffffff", strokeWidth: "1.2" }), (0,jsx_runtime.jsx)("circle", { cx: "13.2224", cy: "19.9547", r: "3", transform: "rotate(-60 13.2224 19.9547)", stroke: "#ffffff", strokeWidth: "1.5", strokeDasharray: "1 1" }), (0,jsx_runtime.jsx)("circle", { cx: "4.09803", cy: "9.09821", r: "3", transform: "rotate(-60 4.09803 9.09821)", stroke: "#ffffff", strokeWidth: "1.5", strokeDasharray: "1 1" }), (0,jsx_runtime.jsx)("path", { d: "M14.0394 15.808L16.3265 10.7776M13.5093 6.72617L6.99985 8.49902", stroke: "#ffffff", strokeWidth: "1.5", strokeDasharray: "1 1" })] }), (0,jsx_runtime.jsx)("defs", { children: (0,jsx_runtime.jsx)("clipPath", { id: "clip0", children: (0,jsx_runtime.jsx)("rect", { width: "25", height: "24", fill: "white" }) }) })] }));
};
/* harmony default export */ var NodeLibraryIcon = (NodeLibraryIcon_GraphStatusIcon);

;// ./src/components/Icons/NoGraphRunningIcon.tsx


const NoGraphRunningIcon = ({ width = 28, height = 28 }) => {
    return ((0,jsx_runtime.jsx)("svg", { xmlns: "http://www.w3.org/2000/svg", width: width, height: height, viewBox: "0 0 28 28", fill: "none", children: (0,jsx_runtime.jsx)("path", { opacity: "0.5", d: "M20.5 20.5L16.6765 16.6765M11.3235 11.3235L7.5 7.5M19.3529 23.1765C19.3529 25.2881 21.0648 27 23.1765 27C25.2881 27 27 25.2881 27 23.1765C27 21.0648 25.2881 19.3529 23.1765 19.3529C21.0648 19.3529 19.3529 21.0648 19.3529 23.1765ZM10.1765 14C10.1765 16.1117 11.8883 17.8235 14 17.8235C16.1117 17.8235 17.8235 16.1117 17.8235 14C17.8235 11.8883 16.1117 10.1765 14 10.1765C11.8883 10.1765 10.1765 11.8883 10.1765 14ZM1 4.82353C1 6.93521 2.71185 8.64706 4.82353 8.64706C6.93521 8.64706 8.64706 6.93521 8.64706 4.82353C8.64706 2.71185 6.93521 1 4.82353 1C2.71185 1 1 2.71185 1 4.82353Z", stroke: "#A5ACB6", strokeWidth: "1.6" }) }));
};
/* harmony default export */ var Icons_NoGraphRunningIcon = (NoGraphRunningIcon);

;// ./src/components/Icons/NoItemsIcon.tsx



const NoItemsIcon = ({ width = 100, height = 102, color = ACCENT_COLOR_LIGHT }) => ((0,jsx_runtime.jsxs)("svg", { width: width, height: height, viewBox: "0 0 100 102", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: [(0,jsx_runtime.jsx)("path", { d: "M77.8351 43.333V1.5C77.8351 1.22386 77.6113 1 77.3351 1H1.08594C0.809795 1 0.585938 1.22386 0.585938 1.5V86.3324C0.585938 86.6086 0.809794 86.8324 1.08594 86.8324H43.6273", stroke: color }), (0,jsx_runtime.jsx)("path", { d: "M15 41.7087H63", stroke: color, strokeWidth: "1.2" }), (0,jsx_runtime.jsx)("path", { d: "M15 62.7087L34.7482 62.7087", stroke: color, strokeWidth: "1.2" }), (0,jsx_runtime.jsx)("path", { d: "M15 20.0987L63.0662 20.0987", stroke: color, strokeWidth: "1.2" }), (0,jsx_runtime.jsx)("circle", { cx: "75.0586", cy: "77.7087", r: "5.5", stroke: color }), (0,jsx_runtime.jsx)("path", { d: "M90.5428 80.6407C90.359 80.5355 90.2621 80.326 90.2951 80.1168C90.5498 78.499 90.5456 76.8361 90.2731 75.1918C90.2384 74.9828 90.3337 74.7726 90.5167 74.666L94.9937 72.0586C95.2323 71.9196 95.3131 71.6135 95.1742 71.3749L90.5052 63.3581C90.3663 63.1195 90.0601 63.0387 89.8215 63.1777L85.3445 65.7851C85.1615 65.8917 84.9316 65.8708 84.767 65.7375C83.4708 64.6883 82.0268 63.8647 80.4941 63.288C80.2959 63.2134 80.1615 63.0259 80.1608 62.8141L80.1418 57.6368C80.1407 57.3606 79.916 57.1375 79.6398 57.1386L70.361 57.1745C70.0849 57.1756 69.862 57.4002 69.863 57.6763L69.882 62.8536C69.8828 63.0655 69.7496 63.2542 69.5516 63.3296C68.7932 63.6187 68.0467 63.9661 67.3197 64.3894C66.5945 64.8118 65.9238 65.2897 65.2966 65.8078C65.1332 65.9426 64.9035 65.9653 64.7197 65.8601L60.2261 63.2886C59.9865 63.1515 59.681 63.2346 59.5438 63.4742L54.9339 71.527C54.7967 71.7667 54.8798 72.0722 55.1195 72.2094L59.6137 74.7816C59.7977 74.8869 59.8944 75.0966 59.8613 75.306C59.605 76.9243 59.61 78.5849 59.8829 80.2299C59.9176 80.4388 59.8223 80.6491 59.6393 80.7556L55.1624 83.3628C54.9238 83.5018 54.843 83.8079 54.982 84.0465L59.6508 92.0633C59.7897 92.3019 60.0958 92.3827 60.3345 92.2437L64.8115 89.6363C64.9945 89.5297 65.2243 89.5506 65.389 89.6838C66.6843 90.7323 68.1268 91.5573 69.6597 92.1315C69.8584 92.2059 69.9932 92.3936 69.994 92.6058L70.0135 97.7838C70.0145 98.06 70.2392 98.283 70.5154 98.2819L79.794 98.2461C80.0702 98.2451 80.2932 98.0203 80.2921 97.7442L80.2719 92.5685C80.271 92.3569 80.4037 92.1684 80.6013 92.0928C81.3617 91.802 82.1106 91.4545 82.8361 91.032C83.5633 90.6085 84.2338 90.1292 84.8614 89.6117C85.0246 89.4771 85.2541 89.4547 85.4377 89.5599L89.929 92.1315C90.1687 92.2687 90.4742 92.1856 90.6114 91.946L95.2212 83.8933C95.3584 83.6536 95.2753 83.3481 95.0356 83.2109L90.5428 80.6407Z", stroke: color })] }));

;// ./src/components/Icons/NoNodeRunningIcon.tsx


const NoNodeRunningIcon = ({ className, width = 28, height = 28, }) => {
    return ((0,jsx_runtime.jsxs)("svg", { className: className, width: width, height: height, viewBox: "0 0 28 28", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: [(0,jsx_runtime.jsxs)("g", { opacity: "0.5", children: [(0,jsx_runtime.jsx)("path", { d: "M19.3529 23.1765C19.3529 25.2881 21.0648 27 23.1765 27C25.2881 27 27 25.2881 27 23.1765C27 21.0648 25.2881 19.3529 23.1765 19.3529C21.0648 19.3529 19.3529 21.0648 19.3529 23.1765Z", stroke: "var(--grey-highlight)", strokeWidth: "1.6", strokeDasharray: "1 1" }), (0,jsx_runtime.jsx)("path", { d: "M1 4.82353C1 6.93521 2.71185 8.64706 4.82353 8.64706C6.93521 8.64706 8.64706 6.93521 8.64706 4.82353C8.64706 2.71185 6.93521 1 4.82353 1C2.71185 1 1 2.71185 1 4.82353Z", stroke: "var(--grey-highlight)", strokeWidth: "1.6", strokeDasharray: "1 1" })] }), (0,jsx_runtime.jsx)("circle", { opacity: "0.5", cx: "14", cy: "14", r: "6", stroke: "#A5ACB6", strokeWidth: "1.6" })] }));
};
/* harmony default export */ var Icons_NoNodeRunningIcon = (NoNodeRunningIcon);

;// ./src/components/Icons/ProjectCheckIcon.tsx


const ProjectCheckIcon = ({ className, width = 19, height = 12, stroke = "var(--grey-highlight)", }) => {
    return ((0,jsx_runtime.jsx)("svg", { className: className, width: width, height: height, viewBox: "0 0 21 14", fill: "none", children: (0,jsx_runtime.jsx)("path", { d: "M1 8.2L6.42857 13L20 1", stroke: stroke, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }) }));
};
/* harmony default export */ var Icons_ProjectCheckIcon = (ProjectCheckIcon);

;// ./src/components/Icons/ProjectFolderIcon.tsx


const ProjectFolderIcon = ({ initials, width = 36, height = 36, fillColor = "#5175BD", textColor = "#FFFFFF", fontSize = 14, }) => {
    return ((0,jsx_runtime.jsxs)("svg", { width: width, height: height, viewBox: "0 0 30 30", children: [(0,jsx_runtime.jsx)("path", { opacity: "0.4", d: "M4 6C4 3.79086 5.79086 2 8 2H25C27.2091 2 29 3.79086 29 6H4Z", fill: fillColor }), (0,jsx_runtime.jsx)("path", { opacity: "0.2", d: "M4 2C4 0.895431 4.89543 0 6 0H20C21.1046 0 22 0.895431 22 2H4Z", fill: fillColor }), (0,jsx_runtime.jsx)("path", { d: "M0 4C0 1.79086 1.79086 0 4 0H6.3915C7.08108 0 7.72202 0.355239 8.0875 0.940002L9.4125 3.06C9.77798 3.64476 10.4189 4 11.1085 4H26C28.2091 4 30 5.79086 30 8V26C30 28.2091 28.2091 30 26 30H4C1.79086 30 0 28.2091 0 26V4Z", fill: fillColor }), (0,jsx_runtime.jsx)("text", { x: "15", y: "20", textAnchor: "middle", fill: textColor, fontSize: fontSize, fontWeight: "bold", fontFamily: "Arial, sans-serif", children: initials })] }));
};
/* harmony default export */ var Icons_ProjectFolderIcon = (ProjectFolderIcon);

;// ./src/components/Icons/ProjectIcon.tsx


const ProjectIcon = ({ width = 24, height = 24, className, }) => {
    return ((0,jsx_runtime.jsxs)("svg", { className: className, xmlns: "http://www.w3.org/2000/svg", width: width, height: height, viewBox: "0 0 24 24", fill: "none", children: [(0,jsx_runtime.jsx)("rect", { x: "2", y: "11", width: "20", height: "10", rx: "2", stroke: "#fff", strokeWidth: "1.2" }), (0,jsx_runtime.jsx)("path", { d: "M4 11V9C4 7.89543 4.89543 7 6 7H18C19.1046 7 20 7.89543 20 9V11", stroke: "#fff", strokeWidth: "1.2" }), (0,jsx_runtime.jsx)("path", { d: "M7 7V6C7 4.89543 7.89543 4 9 4H15C16.1046 4 17 4.89543 17 6V7", stroke: "#fff", strokeWidth: "1.2" })] }));
};
/* harmony default export */ var Icons_ProjectIcon = (ProjectIcon);

;// ./src/components/Icons/QUAlibrateLogoIcon.tsx


const QUAlibrateLogoIcon = ({ width = 149, height = 75 }) => {
    return ((0,jsx_runtime.jsxs)("svg", { width: width, height: height, viewBox: "0 0 600 304", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: [(0,jsx_runtime.jsxs)("g", { clipPath: "url(#clip0_34438_91)", children: [(0,jsx_runtime.jsx)("path", { d: "M341.742 204.266C350.541 204.027 357.849 211.049 358.087 219.931V220.516C358.064 224.164 356.824 227.693 354.618 230.566L358.171 233.785L354.892 237.457L351.375 233.976C348.585 236.062 345.199 237.135 341.742 237.088C332.836 237.147 325.564 229.91 325.504 220.933V220.504C325.397 211.634 332.431 204.373 341.229 204.266H341.742ZM341.742 231.842C343.697 231.842 345.617 231.246 347.262 230.161L343.745 226.811L347.024 223.198L350.457 226.632C351.59 224.784 352.186 222.674 352.186 220.504C352.436 214.721 348.013 209.821 342.279 209.547C336.544 209.285 331.692 213.756 331.417 219.538V220.48C331.095 226.405 335.59 231.46 341.48 231.782H341.754V231.83L341.742 231.842Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M363.607 204.802H369.342V225.153C369.342 229.04 372.477 232.2 376.328 232.2C380.179 232.2 383.315 229.04 383.315 225.153V204.802H389.025V225.153C389.025 232.271 383.935 237.1 376.352 237.1C368.77 237.1 363.572 232.271 363.572 225.153L363.619 204.802H363.607Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M411.082 228.42H400.042L397.383 236.563H391.481L402.557 204.802H408.566L419.642 236.563H413.764L411.082 228.42ZM405.55 210.31C405.55 210.31 404.846 213.422 404.203 215.234L401.413 223.83H409.675L406.861 215.234C406.289 213.434 405.621 210.31 405.621 210.31H405.538H405.55Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M423.338 204.802H429.072L441.006 223.151C441.96 224.736 442.842 226.37 443.605 228.074C443.605 228.074 443.283 225.022 443.283 223.151V204.802H448.97V236.563H443.391L431.457 218.262C430.503 216.677 429.621 215.043 428.834 213.339C428.834 213.339 429.156 216.391 429.156 218.262V236.563H423.421L423.338 204.802Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M463.158 209.774H452.821V204.814H479.217V209.774H468.881V236.563H463.146V209.774H463.158Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M482.746 204.802H488.481V225.153C488.481 229.04 491.616 232.2 495.467 232.2C499.318 232.2 502.453 229.04 502.453 225.153V204.802H508.188V225.153C508.188 232.271 503.073 237.1 495.407 237.1C487.741 237.1 482.627 232.271 482.627 225.153L482.758 204.802H482.746Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M516.665 204.802H522.805L528.969 220.504C529.696 222.376 530.566 225.142 530.566 225.142H530.673C530.673 225.142 531.508 222.376 532.211 220.504L538.387 204.802H544.503L547.043 236.563H541.38L540.032 218.799C539.901 216.653 540.032 213.875 540.032 213.875C540.032 213.875 539.09 216.975 538.351 218.799L533.106 231.115H528.098L523.031 218.799C522.28 216.975 521.303 213.839 521.303 213.839V218.799L519.955 236.563H514.245L516.677 204.802H516.665Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M350.851 253.755H356.967L363.142 269.456C363.846 271.328 364.74 274.094 364.74 274.094C364.74 274.094 365.586 271.328 366.29 269.456L372.442 253.755H378.582L381.121 285.528H375.434L374.111 267.763C373.968 265.617 374.111 262.84 374.111 262.84C374.111 262.84 373.193 265.916 372.43 267.763L367.339 280.079H362.308L357.253 267.763C356.49 265.916 355.524 262.804 355.524 262.804V267.763L354.093 285.528H348.359L350.827 253.755H350.851Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M404.036 277.385H392.996L390.337 285.528H384.435L395.511 253.755H401.52L412.596 285.528H406.694L404.036 277.385ZM398.492 259.251C398.492 259.251 397.788 262.387 397.144 264.175L394.355 272.771H402.617L399.803 264.175C399.231 262.387 398.563 259.251 398.563 259.251H398.48H398.492Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M429.513 253.218C433.793 253.051 437.978 254.589 441.149 257.51L438.383 261.802C435.999 259.74 432.995 258.56 429.859 258.452C424.208 258.214 419.439 262.661 419.201 268.36V269.516C418.855 275.441 423.338 280.52 429.215 280.866H429.859C433.317 280.735 436.571 279.292 439.003 276.824L442.008 280.997C438.753 284.347 434.27 286.219 429.633 286.159C420.87 286.434 413.561 279.495 413.311 270.672V269.516C413.12 260.706 420.047 253.397 428.798 253.206H429.501L429.525 253.23L429.513 253.218Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M446.419 253.755H452.13V267.227H466.556V253.755H472.29V285.528H466.556V272.187H452.13V285.528H446.419V253.755Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M479.825 253.755H485.536V285.528H479.825V253.755Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M492.975 253.755H498.71L510.644 272.103C511.598 273.689 512.48 275.322 513.267 277.027C513.267 277.027 512.945 273.975 512.945 272.103V253.755H518.632V285.528H512.945L501.142 267.227C500.188 265.641 499.306 264.008 498.519 262.303C498.519 262.303 498.841 265.331 498.841 267.227V285.528H493.106L492.975 253.755Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M526.238 253.755H545.099V258.786H531.973V267.096H542.631V272.079H531.973V280.675H545.886V285.659H526.322L526.238 253.755Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M552.277 277.385C554.423 279.388 557.2 280.568 560.121 280.735C562.53 280.735 564.699 279.471 564.699 276.884C564.699 271.185 549.785 272.175 549.785 262.422C549.785 257.141 554.327 253.206 560.443 253.206C563.901 253.075 567.287 254.303 569.862 256.628L567.394 261.337C565.439 259.656 562.983 258.679 560.419 258.571C557.761 258.571 555.674 260.145 555.674 262.374C555.674 268.002 570.589 266.666 570.589 276.765C570.589 281.832 566.75 286.088 560.193 286.088C556.139 286.171 552.241 284.621 549.32 281.796L552.277 277.396V277.385Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M319.054 286.47L319.018 286.386L281.499 193.202C280.2 190.007 277.159 187.933 273.75 187.909C270.316 187.909 267.276 189.959 265.976 193.119L249.786 232.224L248.689 234.882L247.592 232.224L231.402 193.119C230.09 189.947 227.05 187.909 223.664 187.909C220.278 187.909 217.191 189.983 215.879 193.202L183.284 274.118L182.664 275.644L181.4 274.583L175.582 269.683L174.879 269.099L175.272 268.276C179.028 260.265 180.935 251.716 180.935 242.87C180.911 209.989 154.396 183.247 121.801 183.247C89.2055 183.247 62.6905 209.989 62.6905 242.858C62.6905 275.728 89.2055 302.469 121.801 302.469C138.075 302.469 153.264 295.9 164.554 283.954L165.329 283.131L166.187 283.859L180.721 296.079C182.223 297.343 184.13 298.034 186.086 298.034C186.789 298.034 187.48 297.951 188.112 297.796C190.711 297.14 192.857 295.256 193.859 292.765L222.627 221.327L223.712 218.62L224.833 221.315L240.904 260.133C240.904 260.133 240.928 260.157 240.94 260.181C241.011 260.3 241.083 260.42 241.13 260.551C241.273 260.861 241.464 261.254 241.691 261.588C241.762 261.683 241.87 261.803 241.965 261.934C242.036 262.017 242.096 262.101 242.168 262.172C242.227 262.244 242.299 262.339 242.382 262.434C242.501 262.589 242.621 262.744 242.752 262.864C242.907 263.019 243.11 263.174 243.336 263.341H243.36L243.396 263.376C243.479 263.448 243.574 263.531 243.67 263.603C243.789 263.71 243.92 263.817 244.051 263.913C244.254 264.032 244.457 264.139 244.671 264.247L244.993 264.414C245.089 264.473 245.172 264.521 245.244 264.569C245.279 264.592 245.315 264.616 245.363 264.64L245.506 264.688C246.066 264.914 246.567 265.069 247.044 265.153C247.223 265.189 247.366 265.2 247.521 265.212C247.652 265.212 247.795 265.236 247.938 265.248C248.069 265.248 248.2 265.272 248.331 265.296C248.463 265.308 248.582 265.332 248.713 265.332C248.904 265.332 249.106 265.308 249.357 265.272L249.691 265.236L249.941 265.212C250.084 265.212 250.215 265.2 250.299 265.177C250.954 265.034 251.443 264.89 251.896 264.688L252.087 264.604C252.087 264.604 252.111 264.592 252.123 264.58L252.278 264.485L252.313 264.461L252.361 264.437C252.755 264.247 253.076 264.08 253.375 263.889C253.518 263.794 253.649 263.674 253.792 263.555L253.971 263.4C254.054 263.329 254.149 263.245 254.245 263.174C254.388 263.066 254.519 262.959 254.65 262.84C254.769 262.721 254.865 262.589 254.96 262.458C255.032 262.363 255.115 262.256 255.199 262.16C255.258 262.089 255.33 262.005 255.401 261.922C255.497 261.815 255.592 261.707 255.676 261.576C255.854 261.302 256.009 260.992 256.176 260.646L256.248 260.503C256.295 260.384 256.367 260.277 256.427 260.169C256.439 260.145 256.462 260.122 256.474 260.098L272.534 221.303L273.654 218.608L274.739 221.315L303.507 292.753C304.795 295.972 307.859 298.046 311.293 298.046C312.342 298.046 313.439 297.832 314.452 297.426C318.732 295.686 320.807 290.762 319.09 286.422L319.054 286.47ZM161.991 256.14L161.442 257.821L160.083 256.676L149.532 247.806C148.03 246.542 146.122 245.851 144.155 245.851C141.651 245.851 139.303 246.959 137.705 248.879C134.736 252.467 135.213 257.833 138.766 260.825L151.404 271.436L152.405 272.27L151.487 273.188C144.191 280.461 134.713 284.729 124.543 285.397L124.626 285.48L121.789 285.504C98.4572 285.504 79.477 266.369 79.477 242.846C79.477 219.324 98.4691 200.2 121.801 200.2C145.133 200.2 164.113 219.336 164.113 242.858C164.113 247.341 163.398 251.8 161.991 256.14Z", fill: "#EBEBEC" })] }), (0,jsx_runtime.jsx)("path", { d: "M68.3063 135.381L54.8502 120.822C51.5413 121.778 47.9016 122.255 43.9309 122.255C36.7984 122.255 30.2174 120.601 24.1879 117.292C18.2319 113.91 13.4892 109.241 9.95972 103.285C6.50378 97.255 4.77581 90.4902 4.77581 82.9901C4.77581 75.4899 6.50378 68.7619 9.95972 62.8059C13.4892 56.8499 18.2319 52.2175 24.1879 48.9086C30.2174 45.5262 36.7984 43.835 43.9309 43.835C51.1369 43.835 57.7179 45.5262 63.6739 48.9086C69.7034 52.2175 74.4461 56.8499 77.9021 62.8059C81.358 68.7619 83.086 75.4899 83.086 82.9901C83.086 90.049 81.5419 96.4462 78.4536 102.182C75.4388 107.843 71.2476 112.402 65.8798 115.858L84.2993 135.381H68.3063ZM17.6804 82.9901C17.6804 88.6519 18.7834 93.652 20.9893 97.9903C23.2688 102.255 26.3938 105.564 30.3645 107.917C34.3351 110.196 38.8573 111.336 43.9309 111.336C49.0045 111.336 53.5267 110.196 57.4973 107.917C61.468 105.564 64.5563 102.255 66.7622 97.9903C69.0416 93.652 70.1814 88.6519 70.1814 82.9901C70.1814 77.3282 69.0416 72.3649 66.7622 68.1001C64.5563 63.8353 61.468 60.5632 57.4973 58.2838C53.5267 56.0043 49.0045 54.8646 43.9309 54.8646C38.8573 54.8646 34.3351 56.0043 30.3645 58.2838C26.3938 60.5632 23.2688 63.8353 20.9893 68.1001C18.7834 72.3649 17.6804 77.3282 17.6804 82.9901ZM107.143 44.8276V93.6888C107.143 99.4977 108.65 103.873 111.665 106.814C114.753 109.755 119.018 111.226 124.459 111.226C129.974 111.226 134.239 109.755 137.253 106.814C140.342 103.873 141.886 99.4977 141.886 93.6888V44.8276H154.46V93.4682C154.46 99.7183 153.099 105.013 150.379 109.351C147.658 113.689 144.018 116.924 139.459 119.057C134.9 121.189 129.864 122.255 124.349 122.255C118.834 122.255 113.797 121.189 109.238 119.057C104.753 116.924 101.187 113.689 98.5395 109.351C95.8924 105.013 94.5688 99.7183 94.5688 93.4682V44.8276H107.143ZM212.633 105.821H180.537L175.022 121.483H161.897L189.361 44.7174H203.92L231.383 121.483H218.148L212.633 105.821ZM209.104 95.5638L196.64 59.9382L184.066 95.5638H209.104ZM250.494 39.8643V121.483H242.773V39.8643H250.494ZM270.735 49.9013C269.191 49.9013 267.867 49.3498 266.764 48.2468C265.661 47.1439 265.11 45.7835 265.11 44.1659C265.11 42.5482 265.661 41.2246 266.764 40.1952C267.867 39.0923 269.191 38.5408 270.735 38.5408C272.279 38.5408 273.603 39.0923 274.706 40.1952C275.809 41.2246 276.36 42.5482 276.36 44.1659C276.36 45.7835 275.809 47.1439 274.706 48.2468C273.603 49.3498 272.279 49.9013 270.735 49.9013ZM274.595 61.2618V121.483H266.875V61.2618H274.595ZM298.586 74.6076C300.572 70.4163 303.623 66.9972 307.741 64.3501C311.932 61.7029 316.859 60.3794 322.521 60.3794C328.035 60.3794 332.962 61.6662 337.3 64.2397C341.639 66.7398 345.021 70.3428 347.447 75.0488C349.948 79.6812 351.198 85.0857 351.198 91.2623C351.198 97.4389 349.948 102.88 347.447 107.586C345.021 112.292 341.602 115.932 337.19 118.505C332.852 121.079 327.962 122.366 322.521 122.366C316.785 122.366 311.822 121.079 307.631 118.505C303.513 115.858 300.498 112.439 298.586 108.248V121.483H290.976V39.8643H298.586V74.6076ZM343.367 91.2623C343.367 86.2622 342.374 81.9607 340.389 78.3576C338.477 74.6811 335.83 71.8869 332.447 69.9751C329.065 68.0633 325.241 67.1074 320.976 67.1074C316.859 67.1074 313.072 68.1001 309.616 70.0854C306.234 72.0708 303.55 74.9017 301.564 78.5782C299.579 82.2548 298.586 86.5196 298.586 91.3726C298.586 96.2256 299.579 100.49 301.564 104.167C303.55 107.843 306.234 110.674 309.616 112.66C313.072 114.645 316.859 115.638 320.976 115.638C325.241 115.638 329.065 114.682 332.447 112.77C335.83 110.785 338.477 107.954 340.389 104.277C342.374 100.527 343.367 96.1888 343.367 91.2623ZM372.022 71.9605C373.713 68.2104 376.287 65.306 379.743 63.2471C383.272 61.1882 387.574 60.1588 392.647 60.1588V68.2104H390.552C384.963 68.2104 380.478 69.7178 377.096 72.7325C373.713 75.7473 372.022 80.7842 372.022 87.8431V121.483H364.301V61.2618H372.022V71.9605ZM399.63 91.2623C399.63 85.0857 400.843 79.6812 403.269 75.0488C405.769 70.3428 409.189 66.7398 413.527 64.2397C417.939 61.6662 422.902 60.3794 428.417 60.3794C434.152 60.3794 439.079 61.7029 443.197 64.3501C447.388 66.9972 450.403 70.3796 452.241 74.4973V61.2618H459.962V121.483H452.241V108.138C450.329 112.255 447.277 115.674 443.086 118.395C438.968 121.042 434.042 122.366 428.307 122.366C422.865 122.366 417.939 121.079 413.527 118.505C409.189 115.932 405.769 112.292 403.269 107.586C400.843 102.88 399.63 97.4389 399.63 91.2623ZM452.241 91.3726C452.241 86.5196 451.248 82.2548 449.263 78.5782C447.277 74.9017 444.557 72.0708 441.101 70.0854C437.718 68.1001 433.968 67.1074 429.851 67.1074C425.586 67.1074 421.762 68.0633 418.38 69.9751C414.997 71.8869 412.314 74.6811 410.328 78.3576C408.416 81.9607 407.461 86.2622 407.461 91.2623C407.461 96.1888 408.416 100.527 410.328 104.277C412.314 107.954 414.997 110.785 418.38 112.77C421.762 114.682 425.586 115.638 429.851 115.638C433.968 115.638 437.718 114.645 441.101 112.66C444.557 110.674 447.277 107.843 449.263 104.167C451.248 100.49 452.241 96.2256 452.241 91.3726ZM486.521 67.7692V105.16C486.521 108.836 487.22 111.373 488.617 112.77C490.014 114.167 492.477 114.866 496.007 114.866H503.066V121.483H494.794C489.352 121.483 485.308 120.233 482.661 117.733C480.014 115.16 478.69 110.969 478.69 105.16V67.7692H470.308V61.2618H478.69V46.1512H486.521V61.2618H503.066V67.7692H486.521ZM569.182 88.2843C569.182 90.9314 569.109 92.9535 568.962 94.3506H518.997C519.218 98.9095 520.321 102.807 522.306 106.042C524.292 109.277 526.902 111.741 530.137 113.432C533.373 115.049 536.902 115.858 540.726 115.858C545.726 115.858 549.917 114.645 553.3 112.219C556.755 109.792 559.035 106.52 560.138 102.402H568.3C566.829 108.285 563.667 113.101 558.814 116.851C554.035 120.527 548.005 122.366 540.726 122.366C535.064 122.366 529.99 121.116 525.505 118.616C521.02 116.042 517.49 112.439 514.916 107.807C512.416 103.101 511.166 97.6227 511.166 91.3726C511.166 85.1225 512.416 79.6444 514.916 74.9385C517.417 70.2325 520.909 66.6295 525.395 64.1295C529.88 61.6294 534.99 60.3794 540.726 60.3794C546.461 60.3794 551.461 61.6294 555.726 64.1295C560.064 66.6295 563.373 70.0119 565.653 74.2767C568.006 78.4679 569.182 83.1371 569.182 88.2843ZM561.351 88.0637C561.425 83.5783 560.506 79.7547 558.594 76.5929C556.755 73.4311 554.219 71.0413 550.983 69.4237C547.748 67.806 544.218 66.9972 540.395 66.9972C534.659 66.9972 529.77 68.8354 525.726 72.512C521.681 76.1885 519.439 81.3724 518.997 88.0637H561.351Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("path", { d: "M24.1927 201.14C25.453 201.339 26.5972 201.853 27.6254 202.683C28.6866 203.512 29.5158 204.54 30.1128 205.767C30.7429 206.994 31.058 208.304 31.058 209.697C31.058 211.455 30.6102 213.047 29.7148 214.473C28.8193 215.866 27.5093 216.977 25.7847 217.806C24.0932 218.602 22.0867 219 19.7651 219H6.83061V184.326H19.2677C21.6224 184.326 23.6289 184.723 25.2872 185.519C26.9455 186.282 28.1892 187.327 29.0183 188.654C29.8474 189.98 30.262 191.473 30.262 193.131C30.262 195.187 29.6982 196.895 28.5706 198.255C27.4761 199.582 26.0168 200.543 24.1927 201.14ZM11.3577 199.3H18.9692C21.0918 199.3 22.7334 198.802 23.8942 197.807C25.055 196.812 25.6354 195.436 25.6354 193.678C25.6354 191.92 25.055 190.544 23.8942 189.549C22.7334 188.554 21.0586 188.057 18.8697 188.057H11.3577V199.3ZM19.3672 215.269C21.6224 215.269 23.3802 214.738 24.6405 213.677C25.9007 212.616 26.5309 211.14 26.5309 209.249C26.5309 207.326 25.8676 205.817 24.541 204.722C23.2143 203.595 21.44 203.031 19.2179 203.031H11.3577V215.269H19.3672ZM59.6274 184.326L48.3346 205.916V219H43.8075V205.916L32.4649 184.326H37.4895L46.0462 201.887L54.6029 184.326H59.6274Z", fill: "#EBEBEC" }), (0,jsx_runtime.jsx)("defs", { children: (0,jsx_runtime.jsx)("clipPath", { id: "clip0_34438_91", children: (0,jsx_runtime.jsx)("rect", { width: "509.079", height: "121.607", fill: "white", transform: "translate(61.4982 182.055)" }) }) })] }));
};
/* harmony default export */ var Icons_QUAlibrateLogoIcon = (QUAlibrateLogoIcon);

;// ./src/components/Icons/QualibrateLogoSmall.tsx


const QualibrateLogoSmallIcon = ({ width = 26, height = 23 }) => {
    return ((0,jsx_runtime.jsx)("svg", { width: width, height: height, viewBox: "0 0 215.53 100", xmlns: "http://www.w3.org/2000/svg", fill: "#ebebec", children: (0,jsx_runtime.jsx)("path", { d: "M215.03,86.58l-.03-.07-31.47-78.16c-1.09-2.68-3.64-4.42-6.5-4.44-2.88,0-5.43,1.72-6.52,4.37l-13.58,32.8-.92,2.23-.92-2.23-13.58-32.8c-1.1-2.66-3.65-4.37-6.49-4.37s-5.43,1.74-6.53,4.44l-27.34,67.87-.52,1.28-1.06-.89-4.88-4.11-.59-.49.33-.69c3.15-6.72,4.75-13.89,4.75-21.31C99.16,22.43,76.92,0,49.58,0S0,22.43,0,50s22.24,50,49.58,50c13.65,0,26.39-5.51,35.86-15.53l.65-.69.72.61,12.19,10.25c1.26,1.06,2.86,1.64,4.5,1.64.59,0,1.17-.07,1.7-.2,2.18-.55,3.98-2.13,4.82-4.22l24.13-59.92.91-2.27.94,2.26,13.48,32.56s.02.02.03.04c.06.1.12.2.16.31.12.26.28.59.47.87.06.08.15.18.23.29.06.07.11.14.17.2.05.06.11.14.18.22.1.13.2.26.31.36.13.13.3.26.49.4h.02s.03.03.03.03c.07.06.15.13.23.19.1.09.21.18.32.26.17.1.34.19.52.28l.27.14c.08.05.15.09.21.13.03.02.06.04.1.06l.12.04c.47.19.89.32,1.29.39.15.03.27.04.4.05.11,0,.23.02.35.03.11,0,.22.02.33.04.11.01.21.03.32.03.16,0,.33-.02.54-.05l.28-.03.21-.02c.12,0,.23-.01.3-.03.55-.12.96-.24,1.34-.41l.16-.07s.02-.01.03-.02l.13-.08.03-.02.04-.02c.33-.16.6-.3.85-.46.12-.08.23-.18.35-.28l.15-.13c.07-.06.15-.13.23-.19.12-.09.23-.18.34-.28.1-.1.18-.21.26-.32.06-.08.13-.17.2-.25.05-.06.11-.13.17-.2.08-.09.16-.18.23-.29.15-.23.28-.49.42-.78l.06-.12c.04-.1.1-.19.15-.28.01-.02.03-.04.04-.06l13.47-32.54.94-2.26.91,2.27,24.13,59.92c1.08,2.7,3.65,4.44,6.53,4.44.88,0,1.8-.18,2.65-.52,3.59-1.46,5.33-5.59,3.89-9.23ZM83.29,61.14l-.46,1.41-1.14-.96-8.85-7.44c-1.26-1.06-2.86-1.64-4.51-1.64-2.1,0-4.07.93-5.41,2.54-2.49,3.01-2.09,7.51.89,10.02l10.6,8.9.84.7-.77.77c-6.12,6.1-14.07,9.68-22.6,10.24l.07.07-2.38.02c-19.57,0-35.49-16.05-35.49-35.78S30.01,14.22,49.58,14.22s35.49,16.05,35.49,35.78c0,3.76-.6,7.5-1.78,11.14Z" }) }));
};
/* harmony default export */ var QualibrateLogoSmall = (QualibrateLogoSmallIcon);

;// ./src/components/Icons/RightArrowIcon.tsx


const RightArrowIcon = ({ width = 10, height = 10 }) => ((0,jsx_runtime.jsx)("svg", { width: width, height: height, viewBox: "0 0 10 8", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: (0,jsx_runtime.jsx)("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M7.29287 3.62553L5.14642 1.47908L5.85353 0.771973L8.85353 3.77197L9.20708 4.12553L8.85353 4.47908L5.85353 7.47908L5.14642 6.77197L7.29287 4.62553H0V3.62553H7.29287Z", fill: "var(--grey-highlight)" }) }));

;// ./src/components/Icons/RunIcon.tsx


const RunIcon = ({ className }) => ((0,jsx_runtime.jsx)("svg", { className: className, xmlns: "http://www.w3.org/2000/svg", width: "10", height: "10", viewBox: "0 0 12 13", fill: "none", children: (0,jsx_runtime.jsx)("path", { d: "M10.6579 5.71292C11.3246 6.09782 11.3246 7.06007 10.6579 7.44497L2.28947 12.2765C1.62281 12.6614 0.789476 12.1803 0.789476 11.4105L0.789476 1.74744C0.789476 0.977635 1.62281 0.496511 2.28948 0.881412L10.6579 5.71292Z", fill: "white" }) }));

;// ./src/components/Icons/SearchIcon.tsx



const SearchIcon = ({ width = 24, height = 24, color = ACCENT_COLOR_LIGHT }) => ((0,jsx_runtime.jsx)("svg", { width: width, height: height, viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: (0,jsx_runtime.jsx)("path", { d: "m21.878 20.7-5.81-5.81a7.876 7.876 0 0 0 1.765-4.973C17.833 5.55 14.282 2 9.917 2 5.55 2 2 5.551 2 9.917c0 4.365 3.551 7.916 7.917 7.916a7.876 7.876 0 0 0 4.973-1.765l5.81 5.81a.417.417 0 0 0 .589 0l.589-.59a.417.417 0 0 0 0-.588ZM9.917 16.166a6.257 6.257 0 0 1-6.25-6.25 6.257 6.257 0 0 1 6.25-6.25 6.257 6.257 0 0 1 6.25 6.25 6.257 6.257 0 0 1-6.25 6.25Z", fill: color }) }));

;// ./src/components/Icons/StopButtonIcon.tsx


const StopButtonIcon = ({ className, height = 24 }) => {
    return ((0,jsx_runtime.jsxs)("svg", { className: className, height: height, viewBox: "0 0 42 18", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: [(0,jsx_runtime.jsx)("rect", { x: "0.5", y: "0.5", width: "41", height: "17", rx: "8", stroke: "#FF5586", strokeOpacity: "0.4", strokeWidth: "1" ///* <--- thinner stroke */
                , fill: "none" }), (0,jsx_runtime.jsx)("rect", { x: "6", y: "6", width: "6", height: "6", rx: "0.5", fill: "#FF5586" }), (0,jsx_runtime.jsx)("text", { x: "16", y: "12", fill: "#FF5586", fontSize: "8", fontWeight: "500", fontFamily: "Roboto, sans-serif", textAnchor: "start", dominantBaseline: "center", children: "STOP" })] }));
};
/* harmony default export */ var Icons_StopButtonIcon = (StopButtonIcon);

;// ./src/components/Icons/StopIcon.tsx


const StopIcon = () => ((0,jsx_runtime.jsxs)("svg", { width: "34", height: "34", viewBox: "0 0 34 34", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: [(0,jsx_runtime.jsx)("path", { opacity: "0.7", fillRule: "evenodd", clipRule: "evenodd", d: "M17 1C8.16345 1 1 8.16344 1 17V17C1 25.8366 8.16345 33 17 33V33C25.8366 33 33 25.8366 33 17V17C33 8.16344 25.8366 1 17 1V1Z", stroke: "#FF4077", strokeWidth: "2" }), (0,jsx_runtime.jsx)("rect", { x: "11.9474", y: "11.9474", width: "10.1053", height: "10.1053", rx: "1", fill: "#FF4077" })] }));

;// ./src/components/Icons/UndoIcon.tsx


const UndoIcon = ({ width = 17, height = 17 }) => ((0,jsx_runtime.jsx)("svg", { width: width, height: height, viewBox: "0 0 17 17", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: (0,jsx_runtime.jsx)("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M5.38412 2.41501C5.59241 2.62328 5.59241 2.96097 5.38412 3.16924L4.16125 4.39212H9.807C12.458 4.39212 14.607 6.54116 14.607 9.19212C14.607 11.8431 12.458 13.9921 9.807 13.9921H5.54033C5.24579 13.9921 5.007 13.7533 5.007 13.4588C5.007 13.1643 5.24579 12.9255 5.54033 12.9255H9.807C11.8689 12.9255 13.5403 11.254 13.5403 9.19212C13.5403 7.13026 11.8689 5.45879 9.807 5.45879H4.16125L5.38412 6.68167C5.59241 6.88995 5.59241 7.22763 5.38412 7.43591C5.17584 7.6442 4.83816 7.6442 4.62988 7.43591L2.49655 5.30258C2.28826 5.0943 2.28826 4.75662 2.49655 4.54834L4.62988 2.41501C4.83816 2.20672 5.17584 2.20672 5.38412 2.41501Z", fill: "#3CDEF8" }) }));

;// ./src/components/Icons/WorkflowPlaceholderIcon.tsx



const WorkflowPlaceHolderIcon = ({ width = 373, height = 155, color = MAIN_TEXT_COLOR }) => ((0,jsx_runtime.jsxs)("svg", { width: width, height: height, viewBox: "0 0 373 155", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: [(0,jsx_runtime.jsx)("path", { opacity: "0.6", d: "M173.5 81L298 126L357 16.5", stroke: color, strokeDasharray: "2 2" }), (0,jsx_runtime.jsx)("path", { opacity: "0.6", d: "M71.5 79L101 16L173.5 85L239.5 32", stroke: color, strokeDasharray: "2 2" }), (0,jsx_runtime.jsx)("circle", { cx: "51", cy: "105", r: "21", fill: BACKGROUND_COLOR, stroke: color, strokeDasharray: "2 2" }), (0,jsx_runtime.jsx)("path", { d: "M116 16C116 24.2843 109.284 31 101 31C92.7157 31 86 24.2843 86 16C86 7.71573 92.7157 1 101 1C109.284 1 116 7.71573 116 16Z", fill: BACKGROUND_COLOR, stroke: color }), (0,jsx_runtime.jsx)("path", { d: "M189.5 82C189.5 90.2843 182.784 97 174.5 97C166.216 97 159.5 90.2843 159.5 82C159.5 73.7157 166.216 67 174.5 67C182.784 67 189.5 73.7157 189.5 82Z", fill: BACKGROUND_COLOR, stroke: color }), (0,jsx_runtime.jsx)("path", { d: "M313 124C313 132.284 306.284 139 298 139C289.716 139 283 132.284 283 124C283 115.716 289.716 109 298 109C306.284 109 313 115.716 313 124Z", fill: BACKGROUND_COLOR, stroke: color }), (0,jsx_runtime.jsx)("path", { d: "M84 105C84 123.225 69.2254 138 51 138C32.7746 138 18 123.225 18 105C18 86.7746 32.7746 72 51 72C69.2254 72 84 86.7746 84 105Z", stroke: color }), (0,jsx_runtime.jsx)("path", { d: "M25.5 126L1 150.5L4 153.5L28.5 129", stroke: color }), (0,jsx_runtime.jsx)("path", { d: "M372.5 16C372.5 24.2843 365.784 31 357.5 31C349.216 31 342.5 24.2843 342.5 16C342.5 7.71573 349.216 1 357.5 1C365.784 1 372.5 7.71573 372.5 16Z", fill: BACKGROUND_COLOR, stroke: color }), (0,jsx_runtime.jsx)("path", { d: "M254.5 32C254.5 40.2843 247.784 47 239.5 47C231.216 47 224.5 40.2843 224.5 32C224.5 23.7157 231.216 17 239.5 17C247.784 17 254.5 23.7157 254.5 32Z", fill: BACKGROUND_COLOR, stroke: color })] }));

;// ./src/components/Icons/DateFilterIcon.tsx


const DateFilterIcon = ({ width = 24, height = 24 }) => ((0,jsx_runtime.jsxs)("svg", { width: width, height: height, viewBox: "0 0 24 24", fill: "none", stroke: "#7d8590", strokeWidth: "2", children: [(0,jsx_runtime.jsx)("rect", { x: "3", y: "4", width: "18", height: "18", rx: "2", ry: "2" }), (0,jsx_runtime.jsx)("line", { x1: "16", y1: "2", x2: "16", y2: "6" }), (0,jsx_runtime.jsx)("line", { x1: "8", y1: "2", x2: "8", y2: "6" }), (0,jsx_runtime.jsx)("line", { x1: "3", y1: "10", x2: "21", y2: "10" })] }));

;// ./src/components/Icons/SortIcon.tsx


const SortIcon = ({ width = 24, height = 24 }) => ((0,jsx_runtime.jsxs)("svg", { width: width, height: height, viewBox: "0 0 24 24", fill: "none", stroke: "#7d8590", strokeWidth: "2", children: [(0,jsx_runtime.jsx)("line", { x1: "4", y1: "6", x2: "20", y2: "6" }), (0,jsx_runtime.jsx)("line", { x1: "4", y1: "12", x2: "20", y2: "12" }), (0,jsx_runtime.jsx)("line", { x1: "4", y1: "18", x2: "20", y2: "18" })] }));
/* harmony default export */ var Icons_SortIcon = (SortIcon);

;// ./src/components/Icons/TagFilterIcon.tsx


const TagFilterIcon = ({ width = 10, height = 5 }) => {
    return ((0,jsx_runtime.jsxs)("svg", { width: width, height: height, viewBox: "0 0 24 24", fill: "none", stroke: "#7d8590", strokeWidth: "2", children: [(0,jsx_runtime.jsx)("path", { d: "M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" }), (0,jsx_runtime.jsx)("line", { x1: "7", y1: "7", x2: "7.01", y2: "7" })] }));
};
/* harmony default export */ var Icons_TagFilterIcon = (TagFilterIcon);

;// ./src/components/Icons/index.ts




































;// ./src/components/ArraySelector/ArraySelector.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var ArraySelector_module = ({"field":"ArraySelector-module__field","expanded":"ArraySelector-module__expanded","chipsContainer":"ArraySelector-module__chipsContainer","chip":"ArraySelector-module__chip","chipLabel":"ArraySelector-module__chipLabel","chipRemoveButton":"ArraySelector-module__chipRemoveButton","openPopupTrigger":"ArraySelector-module__openPopupTrigger","showMore":"ArraySelector-module__showMore","showMoreButton":"ArraySelector-module__showMoreButton","showLessButton":"ArraySelector-module__showLessButton","enumIconExpanded":"ArraySelector-module__enumIconExpanded"});
;// ./src/components/ArraySelector/EnumSelector.tsx






// eslint-disable-next-line css-modules/no-unused-class

const EnumSelector = ({ disabled, value, options, onChange, }) => {
    const [isPopupOpen, setIsPopupOpen] = (0,react.useState)(false);
    const handleTogglePopup = () => setIsPopupOpen(prev => !prev);
    const handleClosePopup = () => setIsPopupOpen(false);
    return (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)(ArraySelectorTrigger_ArraySelectorTrigger, { onClick: handleTogglePopup, value: value, disabled: disabled, icon: (0,jsx_runtime.jsx)(Icons_ExpandIcon, { className: classNames(isPopupOpen && ArraySelector_module.enumIconExpanded) }) }), (0,jsx_runtime.jsx)(EnumSelectorDropdown_EnumSelectorDropdown, { open: isPopupOpen, onClose: handleClosePopup, onChange: onChange, options: options, value: value })] });
};
/* harmony default export */ var ArraySelector_EnumSelector = (EnumSelector);

;// ./src/components/ArraySelector/components/QubitsSelectorPopup/QubitsSelectorPopup.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var QubitsSelectorPopup_module = ({"popup":"QubitsSelectorPopup-module__popup","popupHeader":"QubitsSelectorPopup-module__popupHeader","popupContent":"QubitsSelectorPopup-module__popupContent","popupFooter":"QubitsSelectorPopup-module__popupFooter","popupFooterCounter":"QubitsSelectorPopup-module__popupFooterCounter","popupControls":"QubitsSelectorPopup-module__popupControls","popupInput":"QubitsSelectorPopup-module__popupInput","searchField":"QubitsSelectorPopup-module__searchField","clearSearchButton":"QubitsSelectorPopup-module__clearSearchButton","button":"QubitsSelectorPopup-module__button","selectButton":"QubitsSelectorPopup-module__selectButton","cancelButton":"QubitsSelectorPopup-module__cancelButton","applyButton":"QubitsSelectorPopup-module__applyButton","popupList":"QubitsSelectorPopup-module__popupList","popupOption":"QubitsSelectorPopup-module__popupOption","selected":"QubitsSelectorPopup-module__selected","offline":"QubitsSelectorPopup-module__offline","popupOptionLabel":"QubitsSelectorPopup-module__popupOptionLabel","popupOptionStatus":"QubitsSelectorPopup-module__popupOptionStatus","popupOptionFooter":"QubitsSelectorPopup-module__popupOptionFooter"});
// EXTERNAL MODULE: ./node_modules/@mui/material/Dialog/Dialog.js + 10 modules
var Dialog = __webpack_require__(4728);
// EXTERNAL MODULE: ./node_modules/@mui/material/Button/Button.js + 3 modules
var Button = __webpack_require__(6990);
;// ./src/components/ArraySelector/components/QubitsSelectorPopup/QubitsSelectorPopup.tsx






const Qubit = ({ option, metadata, handleSelect, handleRemoveItem, selection, searchValue, }) => {
    const searchStringIndex = getSearchStringIndex(option, searchValue);
    const isActive = metadata.active;
    const isSelected = selection.includes(option);
    const parts = [
        option.slice(0, searchStringIndex),
        option.slice(searchStringIndex, searchStringIndex + searchValue.trim().length),
        option.slice(searchStringIndex + searchValue.trim().length),
    ];
    const handleClick = () => {
        if (!isActive)
            return;
        isSelected
            ? handleRemoveItem(option)
            : handleSelect(option);
    };
    return (0,jsx_runtime.jsxs)("div", { onClick: handleClick, "data-value": option, "data-testid": `option_${option}`, className: classNames(QubitsSelectorPopup_module.popupOption, !isActive && QubitsSelectorPopup_module.offline, isSelected && QubitsSelectorPopup_module.selected), children: [(0,jsx_runtime.jsx)("span", { className: QubitsSelectorPopup_module.popupOptionLabel, title: parts.join(""), children: parts.map((part, index) => index === 1 ? (0,jsx_runtime.jsx)("strong", { children: part }, part) : part) }), (0,jsx_runtime.jsx)("div", { className: QubitsSelectorPopup_module.popupOptionStatus, children: isActive ? "active" : "inactive" }), (0,jsx_runtime.jsxs)("span", { className: QubitsSelectorPopup_module.popupOptionFooter, children: [metadata.fidelity, "%"] })] });
};
const QubitsSelectorPopup = ({ open, onClose, value, metadata, onChange, }) => {
    const [searchValue, setSearchValue] = (0,react.useState)("");
    const [selection, setSelection] = (0,react.useState)([]);
    const options = Object.keys(metadata);
    const inputRef = (0,react.useRef)(null);
    const filteredOptions = (0,react.useMemo)(() => options.filter(option => getSearchStringIndex(option, searchValue) !== -1), [options, searchValue]);
    const handleSelect = (id) => setSelection(prev => [...prev, id]);
    const handleRemoveItem = (0,react.useCallback)((id) => setSelection(selection.filter(option => option !== id)), [selection]);
    const handleSelectAll = (0,react.useCallback)(() => setSelection(filteredOptions), [filteredOptions]);
    const handleClear = () => setSelection([]);
    const handleSelectOnline = () => setSelection(options.filter(option => metadata[option].active));
    const handleApply = () => {
        onChange(selection);
        onClose();
    };
    const handleCancel = () => {
        setSelection(value || []);
        onClose();
    };
    const handleEnterSearchValue = (evt) => setSearchValue(evt.target.value);
    const handleClearSearchValue = () => setSearchValue("");
    (0,react.useEffect)(() => {
        open && inputRef.current?.focus();
    }, [open]);
    (0,react.useEffect)(() => {
        setSelection(value || []);
    }, [value]);
    return (0,jsx_runtime.jsxs)(Dialog/* default */.A, { open: open, onClose: handleCancel, classes: { paper: QubitsSelectorPopup_module.popup }, children: [(0,jsx_runtime.jsx)("div", { className: QubitsSelectorPopup_module.popupHeader, children: "Select qubits..." }), (0,jsx_runtime.jsxs)("div", { className: QubitsSelectorPopup_module.popupContent, children: [(0,jsx_runtime.jsxs)("div", { className: QubitsSelectorPopup_module.popupControls, children: [(0,jsx_runtime.jsxs)("div", { className: QubitsSelectorPopup_module.popupInput, children: [(0,jsx_runtime.jsx)("input", { className: QubitsSelectorPopup_module.searchField, value: searchValue, onChange: handleEnterSearchValue, role: "search", ref: inputRef, type: "text", placeholder: "Search option..." }), (0,jsx_runtime.jsx)("button", { className: QubitsSelectorPopup_module.clearSearchButton, onClick: handleClearSearchValue, children: "\u00D7" })] }), (0,jsx_runtime.jsx)(Button/* default */.A, { className: classNames(QubitsSelectorPopup_module.button, QubitsSelectorPopup_module.selectButton), onClick: handleSelectAll, "data-testid": "selectAll", children: "Select All" }), (0,jsx_runtime.jsx)(Button/* default */.A, { className: classNames(QubitsSelectorPopup_module.button, QubitsSelectorPopup_module.selectButton), onClick: handleClear, "data-testid": "clearAll", children: "Clear All" }), (0,jsx_runtime.jsx)(Button/* default */.A, { className: classNames(QubitsSelectorPopup_module.button, QubitsSelectorPopup_module.selectButton), onClick: handleSelectOnline, "data-testid": "onlineOnly", children: "Online Only" })] }), (0,jsx_runtime.jsx)("div", { className: QubitsSelectorPopup_module.popupList, children: filteredOptions.map((option) => ((0,jsx_runtime.jsx)(Qubit, { option: option, metadata: metadata[option], handleSelect: handleSelect, handleRemoveItem: handleRemoveItem, selection: selection, searchValue: searchValue }, option))) })] }), (0,jsx_runtime.jsxs)("div", { className: QubitsSelectorPopup_module.popupFooter, children: [(0,jsx_runtime.jsxs)("span", { className: QubitsSelectorPopup_module.popupFooterCounter, children: [(0,jsx_runtime.jsx)("strong", { children: selection.length }), " qubits selected"] }), (0,jsx_runtime.jsxs)("div", { children: [(0,jsx_runtime.jsx)(Button/* default */.A, { className: classNames(QubitsSelectorPopup_module.button, QubitsSelectorPopup_module.cancelButton), onClick: handleCancel, role: "cancel", children: "Cancel" }), (0,jsx_runtime.jsx)(Button/* default */.A, { className: classNames(QubitsSelectorPopup_module.button, QubitsSelectorPopup_module.applyButton), onClick: handleApply, role: "apply", children: "Apply Selection" })] })] })] });
};
/* harmony default export */ var QubitsSelectorPopup_QubitsSelectorPopup = (QubitsSelectorPopup);

;// ./src/components/ArraySelector/QubitsSelector.tsx




const QubitsSelector = ({ disabled, value, metadata, onChange, }) => {
    const [isPopupOpen, setIsPopupOpen] = (0,react.useState)(false);
    const handleTogglePopup = () => setIsPopupOpen(prev => !prev);
    const handleClosePopup = () => setIsPopupOpen(false);
    return (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)(ArraySelectorTrigger_ArraySelectorTrigger, { onClick: handleTogglePopup, value: value, disabled: disabled }), (0,jsx_runtime.jsx)(QubitsSelectorPopup_QubitsSelectorPopup, { open: isPopupOpen, onClose: handleClosePopup, onChange: onChange, metadata: metadata, value: value })] });
};
/* harmony default export */ var ArraySelector_QubitsSelector = (QubitsSelector);

;// ./src/components/ArraySelector/index.ts



// EXTERNAL MODULE: ./node_modules/@mui/material/DialogTitle/DialogTitle.js
var DialogTitle = __webpack_require__(6831);
// EXTERNAL MODULE: ./node_modules/@mui/material/DialogContent/DialogContent.js + 1 modules
var DialogContent = __webpack_require__(2477);
// EXTERNAL MODULE: ./node_modules/@mui/material/DialogContentText/DialogContentText.js + 1 modules
var DialogContentText = __webpack_require__(7867);
// EXTERNAL MODULE: ./node_modules/@mui/material/DialogActions/DialogActions.js + 1 modules
var DialogActions = __webpack_require__(8763);
;// ./src/components/BasicDialog/BasicDialog.tsx



const BasicDialog = ({ open, title, description, onClose, buttons }) => {
    const handleClose = () => {
        if (onClose) {
            onClose();
        }
    };
    return ((0,jsx_runtime.jsxs)(Dialog/* default */.A, { "data-test-id": true, open: open, onClose: handleClose, children: [title && (0,jsx_runtime.jsx)(DialogTitle/* default */.A, { children: title }), (0,jsx_runtime.jsx)(DialogContent/* default */.A, { children: (0,jsx_runtime.jsx)(DialogContentText/* default */.A, { "data-testid": "dialog-content-text", children: description }) }), buttons && (0,jsx_runtime.jsx)(DialogActions/* default */.A, { children: buttons.map((button) => button) })] }));
};

;// ./src/components/Button/BlueButton.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var BlueButton_module = ({"blueButton":"BlueButton-module__blueButton","big":"BlueButton-module__big","isCircle":"BlueButton-module__isCircle","primary":"BlueButton-module__primary","secondary":"BlueButton-module__secondary"});
;// ./src/components/Button/BlueButton.tsx




const BlueButton = (props) => {
    const { className, children, isSecondary, isBig, isCircle, ...restProps } = props;
    return ((0,jsx_runtime.jsx)("button", { className: classNames(BlueButton_module.blueButton, isBig && BlueButton_module.big, isSecondary ? BlueButton_module.secondary : BlueButton_module.primary, isCircle && BlueButton_module.isCircle, className), ...restProps, children: children }));
};
/* harmony default export */ var Button_BlueButton = (BlueButton);

;// ./src/components/Error/ErrorStatusWrapper.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var ErrorStatusWrapper_module = ({"statusErrorWrapper":"ErrorStatusWrapper-module__statusErrorWrapper","statusErrorHeaderWrapper":"ErrorStatusWrapper-module__statusErrorHeaderWrapper","statusErrorRowWrapper":"ErrorStatusWrapper-module__statusErrorRowWrapper"});
;// ./src/components/Error/ErrorResponseWrapper.tsx


// eslint-disable-next-line css-modules/no-unused-class

const ErrorResponseWrapper = (props) => {
    const { error } = props;
    let errorMessage = error?.name;
    if (errorMessage) {
        errorMessage += "";
    }
    else {
        errorMessage += "Error message: ";
    }
    if (error?.msg) {
        errorMessage += error?.msg;
    }
    return ((0,jsx_runtime.jsx)(jsx_runtime.Fragment, { children: error && ((0,jsx_runtime.jsxs)("div", { className: ErrorStatusWrapper_module.statusErrorWrapper, children: [error?.name && (0,jsx_runtime.jsx)("div", { children: "Error occurred:" }), (0,jsx_runtime.jsxs)("div", { className: ErrorStatusWrapper_module.statusErrorWrapper, children: [" ", errorMessage] })] })) }));
};

// EXTERNAL MODULE: ./node_modules/@mui/material/CircularProgress/CircularProgress.js + 1 modules
var CircularProgress = __webpack_require__(3357);
;// ./src/components/Iframe/Iframe.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var Iframe_module = ({"notLoaded":"Iframe-module__notLoaded","iframe":"Iframe-module__iframe"});
;// ./src/components/Iframe/Iframe.tsx




const Iframe = ({ targetUrl }) => {
    const [isAvailable, setIsAvailable] = (0,react.useState)(null);
    (0,react.useEffect)(() => {
        const checkURL = async () => {
            try {
                const response = await fetch(targetUrl, { method: "HEAD" });
                setIsAvailable(response.ok);
            }
            catch (error) {
                setIsAvailable(false);
            }
        };
        checkURL();
    }, [targetUrl]);
    if (isAvailable === null) {
        return (0,jsx_runtime.jsx)(CircularProgress/* default */.A, { size: "2rem" });
    }
    if (!isAvailable) {
        return (0,jsx_runtime.jsx)("div", { className: Iframe_module.notLoaded });
    }
    return (0,jsx_runtime.jsx)("iframe", { className: Iframe_module.iframe, src: targetUrl, title: "Embedded Page" });
};
/* harmony default export */ var Iframe_Iframe = (Iframe);

;// ./src/components/Input/Input.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var Input_module = ({"inputWrapper":"Input-module__inputWrapper","withIcon":"Input-module__withIcon","disabledInput":"Input-module__disabledInput","inputIcon":"Input-module__inputIcon","input":"Input-module__input","error":"Input-module__error","label":"Input-module__label","inputTitle":"Input-module__inputTitle","inputController":"Input-module__inputController","newLineBetween":"Input-module__newLineBetween","inputControllerWithLock":"Input-module__inputControllerWithLock","inputName":"Input-module__inputName","inputField":"Input-module__inputField","inputSelect":"Input-module__inputSelect","addBottomPadding":"Input-module__addBottomPadding","lockValue":"Input-module__lockValue","errorMsg":"Input-module__errorMsg","inputIcon_inner":"Input-module__inputIcon_inner","inputIconInner":"Input-module__inputIcon_inner","labelWrapper":"Input-module__labelWrapper"});
;// ./src/components/Input/InputField.tsx


// eslint-disable-next-line css-modules/no-unused-class


var IconType;
(function (IconType) {
    IconType["INNER"] = "INNER";
})(IconType || (IconType = {}));
const InputField = (props) => {
    const { dataTestId, name = "", value = "", onChange, typeOfField, className, error, icon, label, iconType, inputClassName: inputCN, disabled = false, ...restProps } = props;
    const handleChange = (event) => {
        if (onChange) {
            onChange(event.target.value, event);
        }
    };
    const inputClassName = classNames(Input_module.input, error && Input_module.error, inputCN, disabled && Input_module.disabledInput);
    return ((0,jsx_runtime.jsxs)("div", { "data-testid": dataTestId, className: classNames(Input_module.inputWrapper, icon && Input_module.withIcon, className), children: [(label || icon) && ((0,jsx_runtime.jsxs)("div", { className: Input_module.labelWrapper, children: [label && (0,jsx_runtime.jsx)("label", { className: Input_module.label, children: label }), icon && (0,jsx_runtime.jsx)("div", { className: classNames(Input_module.inputIcon, iconType === IconType.INNER && Input_module.inputIcon_inner), children: icon })] })), (0,jsx_runtime.jsx)("input", { name: name, autoComplete: "new-password", className: inputClassName, value: value, onChange: handleChange, type: typeOfField === "password" ? "password" : "text", placeholder: props.placeholder ?? "Enter a value", disabled: props.disabled, ...restProps }), (0,jsx_runtime.jsx)("div", { className: Input_module.errorMsg, children: error })] }));
};
/* harmony default export */ var Input_InputField = (InputField);

;// ./src/components/Input/ProjectFormField.tsx



// eslint-disable-next-line css-modules/no-unused-class

const ProjectFormField = ({ id, label, placeholder, value, onChange, type = "text", error }) => {
    return ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)("label", { htmlFor: id, className: error ? Input_module.error : undefined, children: label }), (0,jsx_runtime.jsx)(Input_InputField, { id: id, type: type, placeholder: placeholder, value: value, onChange: onChange, error: error })] }));
};
/* harmony default export */ var Input_ProjectFormField = (ProjectFormField);

// EXTERNAL MODULE: ./node_modules/jsonpath/jsonpath.js
var jsonpath = __webpack_require__(5615);
var jsonpath_default = /*#__PURE__*/__webpack_require__.n(jsonpath);
// EXTERNAL MODULE: ./node_modules/@textea/json-viewer/dist/index.mjs + 1 modules
var json_viewer_dist = __webpack_require__(4191);
;// ./src/components/JSONEditor/JSONSwitch/JSONSwitch.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var JSONSwitch_module = ({"firstRowWrapper":"JSONSwitch-module__firstRowWrapper","switchWrapper":"JSONSwitch-module__switchWrapper","switchOption":"JSONSwitch-module__switchOption","selected":"JSONSwitch-module__selected"});
;// ./src/components/JSONEditor/JSONSwitch/JSONSwitch.tsx


const JSONSwitch = ({ title, activeTab, setActiveTab }) => {
    return ((0,jsx_runtime.jsxs)("div", { className: JSONSwitch_module.firstRowWrapper, children: [(0,jsx_runtime.jsx)("h1", { children: title }), (0,jsx_runtime.jsxs)("div", { className: JSONSwitch_module.switchWrapper, children: [(0,jsx_runtime.jsx)("div", { className: `${JSONSwitch_module.switchOption} ${activeTab === "live" ? JSONSwitch_module.selected : ""}`, onClick: () => setActiveTab("live"), children: "Live" }), (0,jsx_runtime.jsx)("div", { className: `${JSONSwitch_module.switchOption} ${activeTab === "final" ? JSONSwitch_module.selected : ""}`, onClick: () => setActiveTab("final"), children: "Final" })] })] }));
};
/* harmony default export */ var JSONSwitch_JSONSwitch = (JSONSwitch);

;// ./src/components/JSONEditor/JSONEditor.tsx









const JSONEditor = ({ title, jsonDataProp, height, showSearch = true, toggleSwitch = false }) => {
    const isNodeRunning = (0,react_redux/* useSelector */.d4)(getIsNodeRunning);
    const [searchTerm, setSearchTerm] = (0,react.useState)("");
    const [jsonData, setJsonData] = (0,react.useState)(jsonDataProp);
    const [activeTab, setActiveTab] = (0,react.useState)("final");
    (0,react.useEffect)(() => {
        setJsonData(jsonDataProp);
    }, [jsonDataProp]);
    // Listen for postMessage events to switch to live
    (0,react.useEffect)(() => {
        const handleMessage = (event) => {
            if (event.data && event.data.action === "data-dashboard-update") {
                console.log("PostMessage indicates to switch to live tab and node is running.");
                setActiveTab("live");
            }
        };
        window.addEventListener("message", handleMessage);
        return () => window.removeEventListener("message", handleMessage);
    }, []);
    // Switch back to final when a node finishes running
    (0,react.useEffect)(() => {
        if (!isNodeRunning) {
            console.log("Node is not running. Switching to final tab.");
            setActiveTab("final");
        }
    }, [isNodeRunning]);
    const filterData = (data, term) => {
        if (!term)
            return data;
        try {
            const jsonPathQuery = term.replace("#", "$").replace(/\*/g, "*").replace(/\//g, ".");
            const result = jsonpath_default().nodes(data, jsonPathQuery);
            return result.reduce((acc, { path, value, }) => {
                let current = acc;
                for (let i = 1; i < path.length - 1; i++) {
                    const key = path[i];
                    if (!current[key])
                        current[key] = {};
                    current = current[key];
                }
                const lastKey = path[path.length - 1];
                current[lastKey] = value;
                return acc;
            }, {});
        }
        catch (error) {
            console.error("Invalid JSONPath query:", error);
            return data;
        }
    };
    const handleSearch = (_val, e) => {
        setSearchTerm(e.target.value);
        const filteredData = filterData(jsonDataProp, e.target.value);
        setJsonData(filteredData);
    };
    const imageDataType = (0,json_viewer_dist/* defineDataType */.S3)({
        is: (value) => typeof value === "string" && value.startsWith("data:image"),
        Component: ({ value }) => {
            const handleImageClick = () => {
                const win = window.open();
                win?.document.write(`<img src='${value}' alt='${value}' style="max-width: 100%; height: auto;" />`);
            };
            return ((0,jsx_runtime.jsxs)("div", { children: [(0,jsx_runtime.jsx)("br", {}), (0,jsx_runtime.jsx)("div", { className: "figure-container", children: (0,jsx_runtime.jsx)("a", { onClick: handleImageClick, style: { cursor: "pointer" }, children: (0,jsx_runtime.jsx)("img", { style: { maxWidth: "100%", height: "auto" }, src: value, alt: "Base64 figure" }) }) })] }));
        },
    });
    const handleOnSelect = async (path) => {
        let searchPath = "#";
        path.forEach((a) => {
            searchPath += "/" + a;
        });
        setSearchTerm(searchPath);
        const filteredData = filterData(jsonDataProp, searchPath);
        await navigator.clipboard.writeText(searchPath);
        setJsonData(filteredData);
    };
    const currentURL = new URL(window.location.pathname, "http://127.0.0.1:8001" ?? 0);
    const iframeURL = new URL("dashboards/data-dashboard", currentURL);
    return ((0,jsx_runtime.jsxs)("div", { "data-testid": "json-editor", style: {
            display: "flex",
            flexDirection: "column",
            flex: 1,
            color: "#d9d5d4",
            height: height,
            marginLeft: "20px",
            marginRight: "20px",
        }, children: [!toggleSwitch && (0,jsx_runtime.jsx)("h1", { style: { paddingTop: "10px", paddingBottom: "5px" }, children: title }), toggleSwitch && (0,jsx_runtime.jsx)(JSONSwitch_JSONSwitch, { title: title, activeTab: activeTab, setActiveTab: setActiveTab }), showSearch && ((0,jsx_runtime.jsx)(Input_InputField, { value: searchTerm, title: "Search", onChange: (_e, event) => handleSearch(event.target.value, event) })), (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)("div", { style: {
                            width: "100%",
                            height: "100%",
                            display: activeTab === "final" ? "block" : "none",
                            overflowY: "auto",
                        }, children: (0,jsx_runtime.jsx)(json_viewer_dist/* JsonViewer */.p2, { rootName: false, onSelect: (path) => handleOnSelect(path), theme: "dark", value: jsonData, valueTypes: [imageDataType], displayDataTypes: false, defaultInspectDepth: 3, style: { overflowY: "auto", height: "100%" } }) }), toggleSwitch && ((0,jsx_runtime.jsx)("div", { style: { width: "100%", height: "100%", display: activeTab === "live" ? "block" : "none" }, children: (0,jsx_runtime.jsx)(Iframe_Iframe, { targetUrl: iframeURL.href }) }))] })] }));
};

;// ./src/components/Loader/LoaderPage.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var LoaderPage_module = ({"container":"LoaderPage-module__container","text":"LoaderPage-module__text"});
;// ./src/components/Loader/Loader.tsx


const yellowStates = [
    "M44.0676 51H29.9324C27.8068 51 26 49.1111 26 46.8889V45.1111C26 42.8889 27.8068 41 29.9324 41H44.0676C46.1932 41 48 42.8889 48 45.1111V46.8889C48 49.1111 46.1932 51 44.0676 51Z",
    "M51.9324 51H66.0676C68.1932 51 70 49.1111 70 46.8889V45.1111C70 42.8889 68.1932 41 66.0676 41H51.9324C49.8068 41 48 42.8889 48 45.1111V46.8889C48 49.1111 49.8068 51 51.9324 51Z",
    "M44.0676 51H29.9324C27.8068 51 26 49.1111 26 46.8889V45.1111C26 42.8889 27.8068 41 29.9324 41H44.0676C46.1932 41 48 42.8889 48 45.1111V46.8889C48 49.1111 46.1932 51 44.0676 51Z",
    "M51.9324 51H66.0676C68.1932 51 70 49.1111 70 46.8889V45.1111C70 42.8889 68.1932 41 66.0676 41H51.9324C49.8068 41 48 42.8889 48 45.1111V46.8889C48 49.1111 49.8068 51 51.9324 51Z",
    "M44.0676 51H29.9324C27.8068 51 26 49.1111 26 46.8889V45.1111C26 42.8889 27.8068 41 29.9324 41H44.0676C46.1932 41 48 42.8889 48 45.1111V46.8889C48 49.1111 46.1932 51 44.0676 51Z",
    "M44.0676 51H29.9324C27.8068 51 26 49.1111 26 46.8889V45.1111C26 42.8889 27.8068 41 29.9324 41H44.0676C46.1932 41 48 42.8889 48 45.1111V46.8889C48 49.1111 46.1932 51 44.0676 51Z",
    "M44.0676 51H29.9324C27.8068 51 26 49.1111 26 46.8889V45.1111C26 42.8889 27.8068 41 29.9324 41H44.0676C46.1932 41 48 42.8889 48 45.1111V46.8889C48 49.1111 46.1932 51 44.0676 51Z",
    "M44.0676 51H29.9324C27.8068 51 26 49.1111 26 46.8889V45.1111C26 42.8889 27.8068 41 29.9324 41H44.0676C46.1932 41 48 42.8889 48 45.1111V46.8889C48 49.1111 46.1932 51 44.0676 51Z",
    "M44.0676 51H29.9324C27.8068 51 26 49.1111 26 46.8889V45.1111C26 42.8889 27.8068 41 29.9324 41H44.0676C46.1932 41 48 42.8889 48 45.1111V46.8889C48 49.1111 46.1932 51 44.0676 51Z",
];
const greenStates = [
    "M 26 36 h 0 C 26 36 26 32 26 32 s -0 -5 -0 -5 H 26 C 26 27 26 27 26 27 v 6.111 c 0 1 0 1.778 0 1.778 z",
    "M 26 36 h 0 C 26 36 26 32 26 32 s -0 -5 -0 -5 H 26 C 26 27 26 27 26 27 v 6.111 c 0 1 0 1.778 0 1.778 z",
    "M 26 36 h 0 C 26 36 26 32 26 32 s -0 -5 -0 -5 H 26 C 26 27 26 27 26 27 v 6.111 c 0 1 0 1.778 0 1.778 z",
    "M 26 36 h 0 C 26 36 26 32 26 32 s -0 -5 -0 -5 H 26 C 26 27 26 27 26 27 v 6.111 c 0 1 0 1.778 0 1.778 z",
    "M 26 36 h 0 C 26 36 26 32 26 32 s -0 -5 -0 -5 H 26 C 26 27 26 27 26 27 v 6.111 c 0 1 0 1.778 0 1.778 z",
    "M27.571 36h26.715C56.905 36 59 33.778 59 31s-2.095-5-4.714-5H27.99C26.944 26 26 27 26 28.111v6.111c0 1 .733 1.778 1.571 1.778z",
    "M27.571 36h26.715C56.905 36 59 33.778 59 31s-2.095-5-4.714-5H27.99C26.944 26 26 27 26 28.111v6.111c0 1 .733 1.778 1.571 1.778z",
    "M27.571 36h26.715C56.905 36 59 33.778 59 31s-2.095-5-4.714-5H27.99C26.944 26 26 27 26 28.111v6.111c0 1 .733 1.778 1.571 1.778z",
    "M 26 36 h 0 C 26 36 26 32 26 32 s -0 -5 -0 -5 H 26 C 26 27 26 27 26 27 v 6.111 c 0 1 0 1.778 0 1.778 z",
];
const ANIMATE_TIME = "6s";
function Icon() {
    return ((0,jsx_runtime.jsxs)("svg", { xmlns: "http://www.w3.org/2000/svg", width: "99", height: "94", fill: "none", children: [(0,jsx_runtime.jsx)("path", { fill: "#2CCBE5", d: "M69.003 35C71.183 35 73 33.182 73 31s-1.817-4-3.997-4c-2.18 0-3.997 1.818-3.997 4-.121 2.182 1.695 4 3.997 4z" }), (0,jsx_runtime.jsx)("path", { fill: "#00D59A", d: "M27.571 36h26.715C56.905 36 59 33.778 59 31s-2.095-5-4.714-5H27.99C26.944 26 26 27 26 28.111v6.111c0 1 .733 1.778 1.571 1.778z", children: (0,jsx_runtime.jsx)("animate", { attributeName: "d", attributeType: "XML", values: greenStates.join(";"), dur: ANIMATE_TIME, repeatCount: "indefinite" }) }), (0,jsx_runtime.jsx)("g", { children: (0,jsx_runtime.jsx)("path", { fill: "#FF2463", "transform-origin": "26 58", d: "M26 65.202v-7.146C26 56.88 26.942 56 28.198 56h30.766c1.151 0 1.465 1.273.314 1.566L27.36 65.985c-.732.098-1.36-.294-1.36-.783z", children: (0,jsx_runtime.jsx)("animateTransform", { attributeName: "transform", type: "scale", values: "0;0;0;0;0;0;1;0;0", dur: ANIMATE_TIME, repeatCount: "indefinite" }) }) }), (0,jsx_runtime.jsx)("path", { fill: "#FFDB2C", d: "M44.068 51H29.932C27.807 51 26 49.111 26 46.889V45.11c0-2.22 1.807-4.11 3.932-4.11h14.136C46.193 41 48 42.889 48 45.111v1.778C48 49.11 46.193 51 44.068 51z", children: (0,jsx_runtime.jsx)("animate", { attributeName: "d", attributeType: "XML", values: yellowStates.join(";"), dur: ANIMATE_TIME, repeatCount: "indefinite" }) })] }));
}
/* harmony default export */ var Loader = (Icon);

;// ./src/components/Loader/LoaderPage.tsx




function LoaderPage({ text }) {
    return ((0,jsx_runtime.jsxs)("div", { className: LoaderPage_module.container, children: [(0,jsx_runtime.jsx)(Loader, {}), text && (0,jsx_runtime.jsx)("div", { className: LoaderPage_module.text, children: text })] }));
}

;// ./src/components/Loader/LoadingBar.tsx




// eslint-disable-next-line css-modules/no-unused-class

const DEFAULT_LOADING_PHRASE = "Loading...";
const LoadingBar = ({ text = DEFAULT_LOADING_PHRASE, icon = (0,jsx_runtime.jsx)(WorkflowPlaceHolderIcon, {}), className, actionButton }) => {
    const formatError = (error) => {
        if (typeof error === "string") {
            return error.split("\\n").map((item, idx) => {
                return ((0,jsx_runtime.jsxs)("span", { children: [item, (0,jsx_runtime.jsx)("br", {})] }, idx));
            });
        }
        else {
            return (0,jsx_runtime.jsx)("span", { children: error.detail }, error.detail);
        }
    };
    return ((0,jsx_runtime.jsxs)("div", { className: classNames(className), style: { whiteSpace: "pre-wrap" }, children: [icon, (0,jsx_runtime.jsx)("div", { className: LoaderPage_module.text, children: formatError(text) }), actionButton] }));
};
/* harmony default export */ var Loader_LoadingBar = (LoadingBar);

;// ./src/components/CircularLoadingBar/CircularLoadingBar.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var CircularLoadingBar_module = ({"progress":"CircularLoadingBar-module__progress"});
;// ./src/components/CircularLoadingBar/CircularLoadingBar.tsx



const CircularLoadingBar = ({ percentage, trackColor = "#4E5058", progressColor, height = 4, }) => {
    const normalized = Math.max(0, Math.min(percentage, 100));
    const viewBoxWidth = 1000;
    const progressWidth = (normalized / 100) * viewBoxWidth;
    const rx = height / 2;
    return ((0,jsx_runtime.jsxs)("svg", { width: "100%", height: height, viewBox: `0 0 ${viewBoxWidth} ${height}`, preserveAspectRatio: "none", children: [(0,jsx_runtime.jsx)("rect", { x: 0, y: 0, width: viewBoxWidth, height: height, rx: rx, fill: trackColor }), (0,jsx_runtime.jsx)("rect", { className: CircularLoadingBar_module.progress, x: 0, y: 0, width: progressWidth, height: height, rx: rx, fill: progressColor || "var(--progress-color)" })] }));
};
/* harmony default export */ var CircularLoadingBar_CircularLoadingBar = (CircularLoadingBar);

;// ./src/components/MeasurementElementInfoSection/MeasurementElementInfoSection.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var MeasurementElementInfoSection_module = ({"sectionTitle":"MeasurementElementInfoSection-module__sectionTitle","outcomesTitle":"MeasurementElementInfoSection-module__outcomesTitle","infoContent":"MeasurementElementInfoSection-module__infoContent","infoItem":"MeasurementElementInfoSection-module__infoItem","label":"MeasurementElementInfoSection-module__label","info":"MeasurementElementInfoSection-module__info","value":"MeasurementElementInfoSection-module__value","outcomes":"MeasurementElementInfoSection-module__outcomes","outcomeContainer":"MeasurementElementInfoSection-module__outcomeContainer","outcomeBubble":"MeasurementElementInfoSection-module__outcomeBubble","success":"MeasurementElementInfoSection-module__success","failure":"MeasurementElementInfoSection-module__failure","qubitLabel":"MeasurementElementInfoSection-module__qubitLabel","outcomeStatus":"MeasurementElementInfoSection-module__outcomeStatus"});
;// ./src/components/MeasurementElementInfoSection/MeasurementElementInfoSection.tsx

/**
 * @fileoverview Reusable components for displaying measurement run info and outcomes.
 *
 * MeasurementElementStatusInfoAndParameters: Generic key-value display for run
 * metadata and parameters with optional filtering and spacing.
 *
 * MeasurementElementOutcomes: Per-qubit outcome badges (success/failure) displayed
 * as colored bubbles with qubit labels.
 *
 * @see MeasurementElement - Uses these for expandable details
 */



/**
 * Generic key-value display component for measurement metadata and parameters.
 *
 * @param filterEmpty - Hide entries with null/undefined/empty string values
 * @param evenlySpaced - Apply flexbox space-evenly layout (used for run info section)
 */
const MeasurementElementStatusInfoAndParameters = ({ title, data, isInfoSection = false, filterEmpty = false, className, evenlySpaced = false, }) => {
    const filteredData = filterEmpty
        ? Object.entries(data ?? {}).filter(([, value]) => value != null && value !== "")
        : Object.entries(data ?? {});
    if (filteredData.length === 0)
        return null;
    return ((0,jsx_runtime.jsxs)("div", { className: className, children: [title && (0,jsx_runtime.jsx)("div", { className: MeasurementElementInfoSection_module.sectionTitle, children: title }), (0,jsx_runtime.jsx)("div", { className: MeasurementElementInfoSection_module.infoContent, style: evenlySpaced ? { height: "100%", display: "flex", flexDirection: "column", justifyContent: "space-evenly" } : {}, children: filteredData.map(([key, value]) => ((0,jsx_runtime.jsxs)("div", { className: MeasurementElementInfoSection_module.infoItem, children: [(0,jsx_runtime.jsxs)("div", { className: classNames(MeasurementElementInfoSection_module.label, isInfoSection && MeasurementElementInfoSection_module.info), children: [key, ":"] }), (0,jsx_runtime.jsx)("div", { className: MeasurementElementInfoSection_module.value, children: Array.isArray(value) ? value.join(", ") : value?.toString() || "N/A" })] }, key))) })] }));
};
/**
 * Displays per-qubit calibration outcomes as colored badges.
 * Green for "successful", red for failures.
 */
const MeasurementElementOutcomes = ({ outcomes }) => {
    if (!outcomes || Object.keys(outcomes).length === 0)
        return null;
    return ((0,jsx_runtime.jsxs)("div", { className: MeasurementElementInfoSection_module.outcomes, children: [(0,jsx_runtime.jsx)("div", { className: MeasurementElementInfoSection_module.outcomesTitle, children: "Outcomes" }), (0,jsx_runtime.jsx)("div", { className: MeasurementElementInfoSection_module.outcomeContainer, children: Object.entries(outcomes).map(([qubit, result]) => {
                    const isSuccess = result === "successful";
                    return ((0,jsx_runtime.jsxs)("span", { className: classNames(MeasurementElementInfoSection_module.outcomeBubble, isSuccess ? MeasurementElementInfoSection_module.success : MeasurementElementInfoSection_module.failure), children: [(0,jsx_runtime.jsxs)("span", { className: classNames(MeasurementElementInfoSection_module.qubitLabel, isSuccess ? MeasurementElementInfoSection_module.success : MeasurementElementInfoSection_module.failure), children: [qubit || "N/A", " "] }), (0,jsx_runtime.jsx)("span", { className: MeasurementElementInfoSection_module.outcomeStatus, children: result })] }, qubit));
                }) })] }));
};

;// ./src/components/Parameters/Parameters.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var Parameters_module = ({"parametersWrapper":"Parameters-module__parametersWrapper","arrowIconWrapper":"Parameters-module__arrowIconWrapper","nodeNotSelected":"Parameters-module__nodeNotSelected","parameterTitle":"Parameters-module__parameterTitle","parameterValues":"Parameters-module__parameterValues","parameterLabel":"Parameters-module__parameterLabel","parameterValue":"Parameters-module__parameterValue","parameterValueSelector":"Parameters-module__parameterValueSelector","input":"Parameters-module__input","error":"Parameters-module__error","descriptionWrapper":"Parameters-module__descriptionWrapper","descriptionTooltip":"Parameters-module__descriptionTooltip"});
;// ./src/components/Parameters/Parameters.tsx



// eslint-disable-next-line css-modules/no-unused-class






const Parameters = ({ parametersExpanded = false, show = false, showTitle = true, title, currentItem, getInputElement, }) => {
    const selectedNodeNameInWorkflow = (0,react_redux/* useSelector */.d4)(getSelectedNodeNameInWorkflow);
    const [expanded, setExpanded] = react.useState(selectedNodeNameInWorkflow === title || parametersExpanded);
    (0,react.useEffect)(() => {
        if (selectedNodeNameInWorkflow === title || parametersExpanded) {
            setExpanded(true);
        }
        else {
            setExpanded(false);
        }
    }, [selectedNodeNameInWorkflow]);
    return ((0,jsx_runtime.jsxs)("div", { className: classNames(Parameters_module.parametersWrapper, !show && Parameters_module.nodeNotSelected), "data-testid": "node-parameters-wrapper", children: [showTitle && Object.entries(currentItem?.parameters ?? {}).length > 0 && ((0,jsx_runtime.jsxs)("div", { className: Parameters_module.parameterTitle, children: [(0,jsx_runtime.jsx)("div", { className: Parameters_module.arrowIconWrapper, onClick: () => {
                            setExpanded(!expanded);
                        }, children: (0,jsx_runtime.jsx)(ArrowIcon, { options: { rotationDegree: expanded ? 0 : -90 } }) }), title ?? "Parameters"] })), expanded &&
                Object.entries(currentItem?.parameters ?? {}).map(([key, parameter]) => {
                    if (parameter.title.toLowerCase() !== "targets name") {
                        return ((0,jsx_runtime.jsxs)("div", { className: Parameters_module.parameterValues, "data-testid": `parameter-values-${key}`, children: [(0,jsx_runtime.jsxs)("div", { className: Parameters_module.parameterLabel, children: [parameter.title, ":"] }), (0,jsx_runtime.jsx)("div", { className: Parameters_module.parameterValue, "data-testid": "parameter-value", children: getInputElement(key, parameter, currentItem) }), (0,jsx_runtime.jsx)("div", { className: Parameters_module.descriptionWrapper, children: parameter.description && ((0,jsx_runtime.jsx)(Tooltip/* default */.A, { title: (0,jsx_runtime.jsxs)("div", { className: Parameters_module.descriptionTooltip, children: [parameter.description, " "] }), placement: "left-start", arrow: true, children: (0,jsx_runtime.jsx)("span", { children: (0,jsx_runtime.jsx)(InfoIcon, {}) }) })) })] }, key));
                    }
                })] }));
};

// EXTERNAL MODULE: ./node_modules/@mui/material/Checkbox/Checkbox.js + 6 modules
var Checkbox = __webpack_require__(4389);
;// ./src/components/Parameters/utils.ts
const getParameterType = (parameter) => {
    return {
        type: parameter.type || (parameter.anyOf || []).find(({ type }) => type !== "null")?.type,
        allowEmpty: parameter.type === "null" || (parameter.anyOf || []).some(({ type }) => type === "null"),
    };
};
const validate = (parameter, value) => {
    const { type, allowEmpty } = getParameterType(parameter);
    if (!allowEmpty && (value === undefined || value === null || value === "" || (Array.isArray(value) && value.length === 0))) {
        return {
            isValid: false,
            error: "Must be not empty",
        };
    }
    const num = Number(value);
    switch (type) {
        case "number":
            if (!allowEmpty && isNaN(num)) {
                return {
                    isValid: false,
                    error: "Must be a number"
                };
            }
            return { isValid: true, error: undefined };
        case "integer":
            if (!allowEmpty && (isNaN(num) || !Number.isInteger(num))) {
                return {
                    isValid: false,
                    error: "Must be an integer"
                };
            }
            return { isValid: true, error: undefined };
        case "array":
        default:
            return { isValid: true, error: undefined };
    }
};

;// ./src/components/Parameters/ParameterSelector.tsx




// eslint-disable-next-line css-modules/no-unused-class




const ParameterSelector = ({ parameterKey, parameter, node, onChange, }) => {
    const [error, setError] = (0,react.useState)(undefined);
    const [inputValue, setInputValue] = (0,react.useState)(parameter.value);
    const handleBlur = (0,react.useCallback)((value) => {
        const { isValid, error } = validate(parameter, value);
        onChange(parameterKey, value, isValid, node?.name);
        setError(error);
    }, [inputValue]);
    const handleChangeBoolean = (0,react.useCallback)(() => {
        setInputValue(!inputValue);
        handleBlur(!inputValue);
    }, [handleBlur]);
    /**
     * Render appropriate input component based on parameter type.
     *
     * Creates type-specific input elements for parameter editing. Currently
     * supports boolean (Checkbox) and all other types (InputField with string coercion).
     *
     * @remarks
     * **FRAGILE: Limited Type Support**:
     * Only boolean has dedicated UI - all other types (number, string, etc.) use
     * generic InputField with string coercion. Number validation happens at submission
     * time on backend, not during input. Consider adding number input with validation.
     */
    const renderInput = (0,react.useCallback)(() => {
        const { type } = getParameterType(parameter);
        if (type === "boolean")
            return ((0,jsx_runtime.jsx)(Checkbox/* default */.A, { checked: inputValue, onClick: handleChangeBoolean, inputProps: { "aria-label": "controlled" }, "data-testid": `input-field-${parameterKey}` }));
        if (parameter.enum)
            return ((0,jsx_runtime.jsx)(ArraySelector_EnumSelector, { disabled: false, value: Array.isArray(inputValue) ? inputValue : (inputValue || "").split(","), onChange: (value) => {
                    setInputValue(value);
                    handleBlur(value);
                }, options: parameter.enum }, parameterKey));
        if (parameterKey === "qubits" && parameter.metadata)
            return ((0,jsx_runtime.jsx)(ArraySelector_QubitsSelector, { disabled: false, value: inputValue, onChange: (value) => {
                    setInputValue(value);
                    handleBlur(value);
                }, metadata: parameter.metadata }, parameterKey));
        return ((0,jsx_runtime.jsx)(Input_InputField, { placeholder: parameterKey, value: inputValue || undefined, onChange: (value) => setInputValue(value || undefined), onBlur: () => handleBlur(inputValue), className: Parameters_module.input, type: ["number", "integer"].includes(type) ? "number" : "string", "data-testid": `input-field-${parameterKey}` }));
    }, [inputValue, parameter.default]);
    return (0,jsx_runtime.jsxs)("div", { className: classNames(Parameters_module.parameterValueSelector, error && Parameters_module.error), children: [renderInput(), error && (0,jsx_runtime.jsx)("span", { className: Parameters_module.error, children: error })] });
};
/* harmony default export */ var Parameters_ParameterSelector = (ParameterSelector);

;// ./src/components/Parameters/ParameterList.tsx




const ParameterList = ({ showParameters = false, mapOfItems, onChange }) => {
    const renderInputElement = (key, parameter, node) => (0,jsx_runtime.jsx)(Parameters_ParameterSelector, { parameterKey: key, parameter: parameter, node: node, onChange: onChange });
    return ((0,jsx_runtime.jsx)(jsx_runtime.Fragment, { children: Object.entries(mapOfItems ?? {}).map(([key, parameter]) => {
            return ((0,jsx_runtime.jsx)(Parameters, { show: showParameters, showTitle: true, title: parameter.name, currentItem: parameter, getInputElement: renderInputElement }, key));
        }) }));
};

;// ./src/components/Results/Results.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var Results_module = ({"wrapper":"Results-module__wrapper","errorWrapper":"Results-module__errorWrapper","errorHeader":"Results-module__errorHeader","errorIcon":"Results-module__errorIcon","errorHeaderTitle":"Results-module__errorHeaderTitle","errorContent":"Results-module__errorContent","errorLabel":"Results-module__errorLabel","errorText":"Results-module__errorText","tracebackHeader":"Results-module__tracebackHeader","tracebackIcon":"Results-module__tracebackIcon"});
// EXTERNAL MODULE: ./node_modules/@mui/material/Collapse/Collapse.js + 1 modules
var Collapse = __webpack_require__(2848);
// EXTERNAL MODULE: ./node_modules/@mui/icons-material/ChevronRight.js
var ChevronRight = __webpack_require__(7562);
// EXTERNAL MODULE: ./node_modules/@mui/icons-material/ExpandMore.js
var ExpandMore = __webpack_require__(2048);
;// ./src/components/Results/Results.tsx








const ResultsError = ({ style, errorObject }) => {
    const [isTracebackExpanded, setIsTracebackExpanded] = (0,react.useState)(false);
    const toggleTraceback = () => {
        setIsTracebackExpanded(!isTracebackExpanded);
    };
    const hasTraceback = errorObject.traceback && errorObject.traceback.length > 0;
    return ((0,jsx_runtime.jsxs)("div", { className: Results_module.errorWrapper, style: style, "data-testid": "results-wrapper", children: [(0,jsx_runtime.jsxs)("div", { className: Results_module.errorHeader, children: [(0,jsx_runtime.jsx)("div", { className: Results_module.errorIcon, children: (0,jsx_runtime.jsx)(Icons_ErrorIcon, { height: 20, width: 20 }) }), (0,jsx_runtime.jsx)("div", { className: Results_module.errorHeaderTitle, children: "Error" })] }), (0,jsx_runtime.jsxs)("div", { className: Results_module.errorContent, children: [(0,jsx_runtime.jsxs)("div", { children: [(0,jsx_runtime.jsxs)("div", { className: Results_module.errorLabel, children: [errorObject.error_class, " occurred:"] }), (0,jsx_runtime.jsx)("div", { className: Results_module.errorText, children: errorObject.message })] }), (errorObject.details_headline || errorObject.details) && ((0,jsx_runtime.jsxs)("div", { children: [errorObject.details_headline && (0,jsx_runtime.jsx)("div", { className: Results_module.errorLabel, children: errorObject.details_headline }), errorObject.details && (0,jsx_runtime.jsx)("div", { className: Results_module.errorText, style: { whiteSpace: "pre-wrap" }, children: errorObject.details })] })), hasTraceback && ((0,jsx_runtime.jsxs)("div", { children: [(0,jsx_runtime.jsx)("div", { className: Results_module.tracebackHeader, onClick: toggleTraceback, role: "button", tabIndex: 0, onKeyDown: (e) => {
                                    if (e.key === "Enter" || e.key === " ") {
                                        e.preventDefault();
                                        toggleTraceback();
                                    }
                                }, "aria-expanded": isTracebackExpanded, "aria-label": "Toggle error traceback", "data-testid": "traceback-toggle", children: isTracebackExpanded ? ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)("div", { className: Results_module.errorLabel, children: "Error traceback:" }), (0,jsx_runtime.jsx)("div", { className: Results_module.tracebackIcon, children: (0,jsx_runtime.jsx)(ExpandMore/* default */.A, { fontSize: "small", "data-testid": "expand-more-icon" }) })] })) : ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)("div", { className: Results_module.errorLabel, children: "Show error traceback:" }), (0,jsx_runtime.jsx)("div", { className: Results_module.tracebackIcon, children: (0,jsx_runtime.jsx)(ChevronRight/* default */.A, { fontSize: "small", "data-testid": "chevron-right-icon" }) })] })) }), (0,jsx_runtime.jsx)(Collapse/* default */.A, { in: isTracebackExpanded, timeout: "auto", children: (0,jsx_runtime.jsx)("div", { className: Results_module.errorText, "data-testid": "traceback-content", children: (errorObject.traceback ?? []).map((row, index) => ((0,jsx_runtime.jsx)("div", { children: row }, `${row}-${index}`))) }) })] }))] })] }));
};
const Results = ({ title, jsonObject, showSearch = true, toggleSwitch = false, style, errorObject }) => {
    if (errorObject) {
        return (0,jsx_runtime.jsx)(ResultsError, { style: style, errorObject: errorObject });
    }
    return ((0,jsx_runtime.jsx)("div", { className: Results_module.wrapper, style: style, "data-testid": "results-wrapper", children: (0,jsx_runtime.jsx)(JSONEditor, { title: title ?? "Results", jsonDataProp: jsonObject, height: "100%", showSearch: showSearch, toggleSwitch: toggleSwitch }) }));
};

// EXTERNAL MODULE: ./node_modules/react-toastify/dist/react-toastify.esm.mjs
var react_toastify_esm = __webpack_require__(9571);
// EXTERNAL MODULE: ./node_modules/react-toastify/dist/ReactToastify.css
var ReactToastify = __webpack_require__(7333);
;// ./src/components/Toast/Toast.tsx




const Toast = () => {
    return ((0,jsx_runtime.jsx)(react_toastify_esm/* ToastContainer */.N9, { position: "bottom-center", autoClose: 5000, hideProgressBar: true, newestOnTop: false, closeOnClick: true, rtl: false, pauseOnFocusLoss: true, draggable: true, pauseOnHover: true, theme: "dark" }));
};
/* harmony default export */ var Toast_Toast = (Toast);

;// ./src/components/ToggleSwitch/ToggleSwitch.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var ToggleSwitch_module = ({"toggleSwitch":"ToggleSwitch-module__toggleSwitch","toggleOn":"ToggleSwitch-module__toggleOn","toggleOff":"ToggleSwitch-module__toggleOff","toggleKnob":"ToggleSwitch-module__toggleKnob"});
;// ./src/components/ToggleSwitch/ToggleSwitch.tsx



const ToggleSwitch = ({ isOn, onToggle }) => ((0,jsx_runtime.jsx)("div", { className: `${ToggleSwitch_module.toggleSwitch} ${isOn ? ToggleSwitch_module.toggleOn : ToggleSwitch_module.toggleOff}`, onClick: onToggle, children: (0,jsx_runtime.jsx)("div", { className: `${ToggleSwitch_module.toggleKnob} ${isOn ? ToggleSwitch_module.toggleOn : ToggleSwitch_module.toggleOff}` }) }));

;// ./src/components/WebSocketConnectionErrorDialog/WebSocketConnectionErrorDialog.tsx





const WebSocketConnectionErrorDialog = () => {
    const showConnectionErrorDialog = (0,react_redux/* useSelector */.d4)(getShowConnectionErrorDialog);
    const connectionLostSeconds = (0,react_redux/* useSelector */.d4)(getConnectionLostSeconds);
    const formatElapsed = (seconds) => {
        const minutes = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return minutes > 0 ? `${minutes}m ${secs.toString().padStart(2, "0")}s` : `${secs}s`;
    };
    if (!showConnectionErrorDialog)
        return (0,jsx_runtime.jsx)(jsx_runtime.Fragment, {});
    return (0,jsx_runtime.jsx)(BasicDialog, { open: showConnectionErrorDialog, title: "Connection lost", description: (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: ["Connection with the server has been lost.", (0,jsx_runtime.jsx)("br", {}), "Retrying for ", formatElapsed(connectionLostSeconds), "..."] }) });
};
/* harmony default export */ var WebSocketConnectionErrorDialog_WebSocketConnectionErrorDialog = (WebSocketConnectionErrorDialog);

;// ./src/components/SearchField/SearchField.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var SearchField_module = ({"searchBoxInput":"SearchField-module__searchBoxInput"});
;// ./src/components/Input/index.ts


;// ./src/components/SearchField/SearchField.tsx




const SearchField = ({ placeholder, value, onChange, debounceMs = 300 }) => {
    const [internalValue, setInternalValue] = (0,react.useState)(value);
    const timeoutRef = (0,react.useRef)(null);
    (0,react.useEffect)(() => {
        setInternalValue(value);
    }, [value]);
    (0,react.useEffect)(() => {
        if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
        }
        timeoutRef.current = window.setTimeout(() => {
            onChange(internalValue);
        }, debounceMs);
        return () => {
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }
        };
    }, [internalValue, debounceMs, onChange]);
    return ((0,jsx_runtime.jsx)(Input_InputField, { dataTestId: "search-field", inputClassName: SearchField_module.searchBoxInput, name: "search", type: "search", value: internalValue, placeholder: placeholder, autoComplete: "off", onChange: (val) => setInternalValue(val) }));
};
/* harmony default export */ var SearchField_SearchField = (SearchField);

;// ./src/components/SearchField/index.ts


;// ./src/components/DateFilter/DateFilter.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var DateFilter_module = ({"wrapper":"DateFilter-module__wrapper","filterButton":"DateFilter-module__filterButton","dateFilterDropdown":"DateFilter-module__dateFilterDropdown","active":"DateFilter-module__active","dateFilterOption":"DateFilter-module__dateFilterOption","selected":"DateFilter-module__selected","dateRangeInputs":"DateFilter-module__dateRangeInputs","dateInputGroup":"DateFilter-module__dateInputGroup"});
;// ./src/components/DateFilter/DateFilter.tsx



// eslint-disable-next-line css-modules/no-unused-class



var DateOption;
(function (DateOption) {
    DateOption["Today"] = "Today";
    DateOption["LastWeek"] = "LastWeek";
    DateOption["LastMonth"] = "LastMonth";
})(DateOption || (DateOption = {}));
const DateFilter = ({ options, from, to, setFrom, setTo, onSelect }) => {
    const [showOptions, setShowOptions] = react.useState(false);
    const ref = hooks_useClickOutside(() => setShowOptions(false));
    const toggleDropdown = (e) => {
        e.stopPropagation();
        setShowOptions(!showOptions);
    };
    const selectPreset = (e, option) => {
        e.stopPropagation();
        setShowOptions(false);
        if (onSelect)
            onSelect(option);
    };
    const handleDateChange = (e, type, value) => {
        const parts = value.split("-");
        if (parts.length === 3) {
            let year = parts[0];
            const month = parts[1];
            const day = parts[2];
            if (year.length > 4) {
                year = year.slice(0, 4);
                e.preventDefault();
            }
            value = `${year}-${("0" + month).slice(-2)}-${("0" + day).slice(-2)}`;
        }
        if (type === "from" && setFrom)
            setFrom(value);
        if (type === "to" && setTo)
            setTo(value);
    };
    return ((0,jsx_runtime.jsxs)("div", { className: DateFilter_module.wrapper, children: [(0,jsx_runtime.jsx)("div", { "data-testid": "date-filter", className: DateFilter_module.filterButton, onClick: toggleDropdown, children: (0,jsx_runtime.jsx)(DateFilterIcon, { width: 16, height: 16 }) }), (0,jsx_runtime.jsxs)("div", { className: classNames(DateFilter_module.dateFilterDropdown, showOptions && DateFilter_module.active), ref: ref, children: [options.map((option) => ((0,jsx_runtime.jsx)("div", { onClick: (e) => selectPreset(e, option), className: DateFilter_module.dateFilterOption, "data-filter": option, children: option.label }, option.value))), (0,jsx_runtime.jsxs)("div", { className: DateFilter_module.dateRangeInputs, children: [(0,jsx_runtime.jsxs)("div", { className: DateFilter_module.dateInputGroup, children: [(0,jsx_runtime.jsx)("label", { children: "From" }), (0,jsx_runtime.jsx)("input", { "data-testid": "execution-history-date-filter-input-from", type: "date", value: from || "", onChange: (e) => handleDateChange(e, "from", e.target.value) })] }), (0,jsx_runtime.jsxs)("div", { className: DateFilter_module.dateInputGroup, children: [(0,jsx_runtime.jsx)("label", { children: "To" }), (0,jsx_runtime.jsx)("input", { "data-testid": "execution-history-date-filter-input-to", type: "date", value: to || "", onChange: (e) => handleDateChange(e, "to", e.target.value) })] })] })] })] }));
};
/* harmony default export */ var DateFilter_DateFilter = (DateFilter);

;// ./src/components/DateFilter/index.ts



;// ./src/components/SortButton/SortButton.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var SortButton_module = ({"wrapper":"SortButton-module__wrapper","filterButton":"SortButton-module__filterButton","sortDropdown":"SortButton-module__sortDropdown","active":"SortButton-module__active","sortOption":"SortButton-module__sortOption","selected":"SortButton-module__selected"});
;// ./src/components/SortButton/SortButton.tsx



// eslint-disable-next-line css-modules/no-unused-class



const SortButton = ({ options, onSelect }) => {
    const [showOptions, setShowOptions] = (0,react.useState)(false);
    const [selectedOption, setSelectedOption] = (0,react.useState)(options[0].value);
    const ref = hooks_useClickOutside(() => setShowOptions(false));
    const onClickHandler = () => {
        setShowOptions(!showOptions);
    };
    const selectOptionHandler = (option) => {
        setSelectedOption(option);
        setShowOptions(false);
        onSelect(option);
    };
    return ((0,jsx_runtime.jsxs)("div", { "data-testid": "sort-button", className: SortButton_module.wrapper, children: [(0,jsx_runtime.jsx)("div", { className: SortButton_module.filterButton, id: "dateFilterBtn", onClick: onClickHandler, children: (0,jsx_runtime.jsx)(Icons_SortIcon, { width: 16, height: 16 }) }), (0,jsx_runtime.jsx)("div", { className: classNames(SortButton_module.sortDropdown, showOptions && SortButton_module.active), id: "dateFilterDropdown", ref: ref, children: options.map((option) => ((0,jsx_runtime.jsx)("div", { onClick: () => selectOptionHandler(option.value), className: classNames(SortButton_module.sortOption, selectedOption === option.value && SortButton_module.selected), "data-filter": option, children: option.label }, option.value))) })] }));
};
/* harmony default export */ var SortButton_SortButton = (SortButton);

;// ./src/components/SortButton/index.ts


;// ./src/components/AppliedFilterLabel/AppliedFilterLabel.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var AppliedFilterLabel_module = ({"selectedFiltersRow":"AppliedFilterLabel-module__selectedFiltersRow","activeDateFilter":"AppliedFilterLabel-module__activeDateFilter","filterLabel":"AppliedFilterLabel-module__filterLabel","dot":"AppliedFilterLabel-module__dot","removeFilter":"AppliedFilterLabel-module__removeFilter"});
;// ./src/components/AppliedFilterLabel/AppliedFilterLabel.tsx



const AppliedFilterLabel = ({ label, showDot = false, dotColor = "#123", value, onRemove }) => {
    return ((0,jsx_runtime.jsx)("div", { className: AppliedFilterLabel_module.selectedFiltersRow, children: (0,jsx_runtime.jsxs)("div", { className: AppliedFilterLabel_module.activeDateFilter, children: [label && (0,jsx_runtime.jsx)("span", { className: AppliedFilterLabel_module.filterLabel, children: label }), showDot && (0,jsx_runtime.jsx)("div", { "data-testid": "filter-dot", className: AppliedFilterLabel_module.dot, style: { backgroundColor: dotColor ?? "" } }), (0,jsx_runtime.jsx)("span", { children: value }), (0,jsx_runtime.jsx)("span", { className: AppliedFilterLabel_module.removeFilter, onClick: onRemove, children: "\u00D7" })] }) }));
};
/* harmony default export */ var AppliedFilterLabel_AppliedFilterLabel = (AppliedFilterLabel);

;// ./src/components/AppliedFilterLabel/index.ts


;// ./src/components/VerticalResizableComponent/VerticalResizableComponent.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var VerticalResizableComponent_module = ({"contentSidebar":"VerticalResizableComponent-module__contentSidebar","collapsed":"VerticalResizableComponent-module__collapsed","displayCard":"VerticalResizableComponent-module__displayCard","sidebarToggleArrow":"VerticalResizableComponent-module__sidebarToggleArrow","displayCardTabs":"VerticalResizableComponent-module__displayCardTabs","displayCardTab":"VerticalResizableComponent-module__displayCardTab","active":"VerticalResizableComponent-module__active","displayCardContent":"VerticalResizableComponent-module__displayCardContent","displayCardPanel":"VerticalResizableComponent-module__displayCardPanel","displayCardPanelBody":"VerticalResizableComponent-module__displayCardPanelBody","displayParam":"VerticalResizableComponent-module__displayParam","displayParamLabel":"VerticalResizableComponent-module__displayParamLabel","displayParamValue":"VerticalResizableComponent-module__displayParamValue"});
;// ./src/utils/formatNames.ts
/**
 * Formats text replacing all underscores with space and makes all first letters of words capital.
 */
const formatNames = (value) => {
    return value.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
};

;// ./src/components/VerticalResizableComponent/SnapshotComments/SnapshotComments.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var SnapshotComments_module = ({"commentSection":"SnapshotComments-module__commentSection","commentHeader":"SnapshotComments-module__commentHeader","commentsList":"SnapshotComments-module__commentsList","commentItem":"SnapshotComments-module__commentItem","commentItemHeader":"SnapshotComments-module__commentItemHeader","commentTimestamp":"SnapshotComments-module__commentTimestamp","commentItemAction":"SnapshotComments-module__commentItemAction","editCommentBtn":"SnapshotComments-module__editCommentBtn","deleteCommentBtn":"SnapshotComments-module__deleteCommentBtn","commentItemText":"SnapshotComments-module__commentItemText","commentLabel":"SnapshotComments-module__commentLabel","addCommentBtn":"SnapshotComments-module__addCommentBtn","noComment":"SnapshotComments-module__noComment"});
;// ./src/components/VerticalResizableComponent/CommentModal/CommentModal.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var CommentModal_module = ({"modal":"CommentModal-module__modal","modalContent":"CommentModal-module__modalContent","modalHeader":"CommentModal-module__modalHeader","modalBody":"CommentModal-module__modalBody","commentTextarea":"CommentModal-module__commentTextarea","modalFooter":"CommentModal-module__modalFooter","modalBtn":"CommentModal-module__modalBtn","modalBtnSecondary":"CommentModal-module__modalBtnSecondary","modalBtnPrimary":"CommentModal-module__modalBtnPrimary","modalBtnDelete":"CommentModal-module__modalBtnDelete"});
;// ./src/components/VerticalResizableComponent/CommentModal/CommentModal.tsx







const CommentModal = ({ mode, comment, handleOnClose, handleOnSave }) => {
    const selectedSnapshot = (0,react_redux/* useSelector */.d4)(getSelectedSnapshot);
    const [commentText, setCommentText] = (0,react.useState)(comment?.value ?? "");
    if (!selectedSnapshot) {
        return null;
    }
    let title = "Add comment";
    if (mode === "edit") {
        title = "Edit comment";
    }
    else if (mode === "delete") {
        title = "Delete comment";
    }
    return ((0,jsx_runtime.jsx)(Dialog/* default */.A, { classes: { paper: CommentModal_module.modal }, open: true, onClose: handleOnClose, children: (0,jsx_runtime.jsxs)("div", { className: CommentModal_module.modalContent, children: [(0,jsx_runtime.jsx)("div", { className: CommentModal_module.modalHeader, children: (0,jsx_runtime.jsx)("h3", { children: title }) }), (0,jsx_runtime.jsxs)("div", { className: CommentModal_module.modalBody, children: [mode !== "delete" && ((0,jsx_runtime.jsx)("textarea", { value: commentText, onChange: (e) => setCommentText(e.target.value), className: CommentModal_module.commentTextarea, id: "commentTextarea", placeholder: "Add your notes..." })), mode === "delete" && (0,jsx_runtime.jsx)("p", { children: "Are you sure you want to delete this comment? This action cannot be undone." })] }), (0,jsx_runtime.jsxs)("div", { className: CommentModal_module.modalFooter, children: [(0,jsx_runtime.jsx)("button", { className: classNames(CommentModal_module.modalBtn, CommentModal_module.modalBtnSecondary), onClick: handleOnClose, children: "Cancel" }), (0,jsx_runtime.jsx)("button", { className: classNames(CommentModal_module.modalBtn, CommentModal_module.modalBtnPrimary, mode === "delete" && CommentModal_module.modalBtnDelete), onClick: () => handleOnSave({ mode, comment, commentText }), children: mode === "delete" ? "Yes, Delete" : "Save" })] })] }) }));
};
/* harmony default export */ var CommentModal_CommentModal = (CommentModal);

;// ./src/components/VerticalResizableComponent/CommentModal/index.ts


;// ./src/components/VerticalResizableComponent/SnapshotComments/SnapshotComments.tsx








const SnapshotComments = () => {
    const selectedSnapshotId = (0,react_redux/* useSelector */.d4)(getSelectedSnapshotId);
    const selectedSnapshot = (0,react_redux/* useSelector */.d4)(getSelectedSnapshot);
    const [showCommentModal, setShowCommentModal] = (0,react.useState)(false);
    const [modalDialogMode, setModalDialogMode] = (0,react.useState)("add");
    const [commentForModal, setCommentForModal] = (0,react.useState)(undefined);
    const [comments, setComments] = (0,react.useState)([]);
    const handleOpenDialogOnClick = (mode, comment) => {
        if (comment) {
            setCommentForModal(comment);
        }
        setModalDialogMode(mode);
        setShowCommentModal(true);
    };
    const handleOnAddNewComment = async (commentText) => {
        if (!selectedSnapshot)
            return;
        const response = await addCommentToSnapshot(selectedSnapshot?.id, commentText);
        if (response && response?.isOk && response?.result) {
            const newComment = response?.result;
            setComments((prev) => [...prev, newComment]);
        }
        // TODO Uncomment this to demo mocks
        // const newComment = { id: comments.length, value: commentText, createdAt: "2025-11-16 14:30:00" };
        // setComments((prev) => [...prev, newComment]);
    };
    const handleOnEditNewComment = async (comment, commentText) => {
        if (!selectedSnapshot)
            return;
        const updatedComment = { ...comment, value: commentText };
        const response = await updateSnapshotComment(selectedSnapshot.id, updatedComment);
        if (response?.isOk && response?.result) {
            setComments((prev) => prev.map((c) => (c.id === comment.id ? updatedComment : c)));
        }
        // TODO Uncomment this to demo mocks
        // setComments((prev) => prev.map((c) => (c.id === comment.id ? updatedComment : c)));
    };
    const handleOnRemoveCommentClick = async (comment) => {
        if (!selectedSnapshot)
            return;
        const response = await removeCommentFromSnapshot(selectedSnapshot.id, comment.id);
        if (response?.isOk && response?.result) {
            setComments((prev) => prev.filter((c) => c.id !== comment.id));
        }
        // TODO Uncomment this to demo mocks
        // setComments((prev) => prev.filter((c) => c.id !== comment.id));
    };
    const handleOnDialogClose = () => {
        setShowCommentModal(false);
        setCommentForModal(undefined);
    };
    const handleOnDialogSave = async ({ mode, comment, commentText }) => {
        if (mode === "add" && commentText) {
            await handleOnAddNewComment(commentText);
        }
        else if (mode === "edit" && comment && commentText) {
            await handleOnEditNewComment(comment, commentText);
        }
        else if (mode === "delete" && comment) {
            await handleOnRemoveCommentClick(comment);
        }
        handleOnDialogClose();
    };
    const fetchComments = (0,react.useCallback)(async () => {
        if (!selectedSnapshotId)
            return;
        const response = await fetchAllCommentsForSnapshot(selectedSnapshotId);
        if (response?.isOk && response.result) {
            setComments(response.result);
        }
        // TODO Uncomment this to use mocks
        // setComments([
        //   {
        //     id: 1,
        //     value: "Comment 1",
        //     createdAt: "2024-11-16 14:30:00",
        //   },
        //   {
        //     id: 2,
        //     value: "Comment 2",
        //     createdAt: "2024-11-16 14:30:00",
        //   },
        //   {
        //     id: 3,
        //     value: "Comment 3",
        //     createdAt: "2024-11-16 14:30:00",
        //   },
        //   {
        //     id: 4,
        //     value: "Comment 4",
        //     createdAt: "2024-11-16 14:30:00",
        //   },
        //   {
        //     id: 5,
        //     value: "Comment 5",
        //     createdAt: "2024-11-16 14:30:00",
        //   },
        //   {
        //     id: 6,
        //     value: "Comment 6",
        //     createdAt: "2024-11-16 14:30:00",
        //   },
        //   {
        //     id: 7,
        //     value: "Comment 7",
        //     createdAt: "2024-11-16 14:30:00",
        //   },
        // ]);
    }, [selectedSnapshotId]);
    (0,react.useEffect)(() => {
        fetchComments();
    }, [fetchComments]);
    if (!selectedSnapshot) {
        return null;
    }
    return ((0,jsx_runtime.jsxs)("div", { className: SnapshotComments_module.commentSection, children: [(0,jsx_runtime.jsxs)("div", { className: SnapshotComments_module.commentHeader, children: [(0,jsx_runtime.jsx)("div", { className: SnapshotComments_module.commentLabel, children: "Comments" }), (0,jsx_runtime.jsx)("button", { "data-testid": "add-comment-btn", className: SnapshotComments_module.addCommentBtn, onClick: () => handleOpenDialogOnClick("add"), title: "Add comment", children: "+" })] }), comments?.length === 0 && (0,jsx_runtime.jsx)("div", { className: SnapshotComments_module.noComment, children: "No comments yet" }), comments?.length > 0 && ((0,jsx_runtime.jsx)("div", { className: SnapshotComments_module.commentsList, children: comments.map((comment, index) => ((0,jsx_runtime.jsxs)("div", { className: SnapshotComments_module.commentItem, children: [(0,jsx_runtime.jsxs)("div", { className: SnapshotComments_module.commentItemHeader, children: [(0,jsx_runtime.jsx)("div", { className: SnapshotComments_module.commentTimestamp, children: formatDateTime(comment.createdAt) }), (0,jsx_runtime.jsxs)("div", { className: SnapshotComments_module.commentItemAction, children: [(0,jsx_runtime.jsx)("button", { "data-testid": `edit-comment-btn${index}`, className: SnapshotComments_module.editCommentBtn, onClick: () => handleOpenDialogOnClick("edit", comment), title: "Edit comment", children: "\u270E" }), (0,jsx_runtime.jsx)("button", { "data-testid": `delete-comment-btn${index}`, className: SnapshotComments_module.deleteCommentBtn, onClick: () => handleOpenDialogOnClick("delete", comment), title: "Delete comment", children: "\uD83D\uDDD1" })] })] }), (0,jsx_runtime.jsx)("div", { className: SnapshotComments_module.commentItemText, children: comment.value })] }, `${comment.id}-${index}`))) })), showCommentModal && ((0,jsx_runtime.jsx)(CommentModal_CommentModal, { mode: modalDialogMode, comment: commentForModal, handleOnSave: handleOnDialogSave, handleOnClose: handleOnDialogClose }))] }));
};
/* harmony default export */ var SnapshotComments_SnapshotComments = (SnapshotComments);

;// ./src/components/VerticalResizableComponent/SnapshotComments/index.ts


;// ./src/components/VerticalResizableComponent/VerticalResizableComponent.tsx







const VerticalResizableComponent = ({ tabNames = ["Metadata", "Parameters"], tabData, hasCommentSection = true }) => {
    const [expanded, setExpanded] = react.useState(true);
    const [activeTabName, setActiveTabName] = react.useState(tabNames[0]);
    const handleOnToggleSidebar = () => {
        setExpanded(!expanded);
    };
    const handleOnSwitchTab = (0,react.useCallback)((tabName) => {
        setActiveTabName(tabName);
    }, []);
    const detailsObject = tabData ? tabData[activeTabName.toLowerCase()] : {};
    const showComments = hasCommentSection && activeTabName.toLowerCase() === "metadata";
    const formatParamValue = (key, value) => {
        if (["run_end", "run_start"].includes(key))
            return formatDateTime(value);
        return value === null || value === undefined
            ? "—"
            : typeof value === "object"
                ? JSON.stringify(value, null, 2)
                : value;
    };
    return ((0,jsx_runtime.jsxs)("div", { "data-testid": "vertical-component", className: classNames(VerticalResizableComponent_module.contentSidebar, !expanded && VerticalResizableComponent_module.collapsed), id: "contentSidebar", children: [(0,jsx_runtime.jsx)("button", { className: VerticalResizableComponent_module.sidebarToggleArrow, id: "sidebarToggle", onClick: handleOnToggleSidebar, children: expanded ? "◀" : "▶" }), (0,jsx_runtime.jsxs)("div", { className: VerticalResizableComponent_module.displayCard, children: [(0,jsx_runtime.jsx)("div", { className: VerticalResizableComponent_module.displayCardTabs, children: tabNames.map((tabName) => ((0,jsx_runtime.jsx)("div", { className: classNames(VerticalResizableComponent_module.displayCardTab, activeTabName === tabName && VerticalResizableComponent_module.active), onClick: () => handleOnSwitchTab(tabName), id: `tab${tabName}`, children: tabName }, tabName))) }), (0,jsx_runtime.jsx)("div", { className: VerticalResizableComponent_module.displayCardContent, children: (0,jsx_runtime.jsxs)("div", { className: VerticalResizableComponent_module.displayCardPanelBody, children: [detailsObject &&
                                    Object.keys(detailsObject).map((keyValue) => {
                                        const detailValue = detailsObject[keyValue];
                                        return ((0,jsx_runtime.jsx)("div", { className: classNames(VerticalResizableComponent_module.displayCardPanel, VerticalResizableComponent_module.active), id: `panel${activeTabName}`, children: (0,jsx_runtime.jsxs)("div", { className: VerticalResizableComponent_module.displayParam, children: [(0,jsx_runtime.jsx)("div", { className: VerticalResizableComponent_module.displayParamLabel, children: formatNames(keyValue) }), (0,jsx_runtime.jsx)("div", { className: VerticalResizableComponent_module.displayParamValue, children: formatParamValue(keyValue, detailValue) })] }) }, keyValue));
                                    }), showComments && (0,jsx_runtime.jsx)(SnapshotComments_SnapshotComments, {})] }) })] })] }));
};
/* harmony default export */ var VerticalResizableComponent_VerticalResizableComponent = (VerticalResizableComponent);

;// ./src/components/VerticalResizableComponent/index.ts


;// ./src/components/TagFilter/TagFilter.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var TagFilter_module = ({"wrapper":"TagFilter-module__wrapper","filterButton":"TagFilter-module__filterButton","tagDropdown":"TagFilter-module__tagDropdown","active":"TagFilter-module__active"});
;// ./src/components/TagFilter/TagOption/TagOption.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var TagOption_module = ({"tagFilterOption":"TagOption-module__tagFilterOption","tagFilterCheckbox":"TagOption-module__tagFilterCheckbox","tagFilterRow":"TagOption-module__tagFilterRow","tagDot":"TagOption-module__tagDot","selected":"TagOption-module__selected"});
;// ./src/modules/Data/components/ExecutionCard/components/TagsList/helpers.ts
const stringToHexColor = (str) => {
    const hash = [...str].reduce((acc, char) => char.charCodeAt(0) + ((acc << 5) - acc), 0);
    return "#" + [0, 1, 2].map((i) => ((hash >> (i * 8)) & 0xff).toString(16).padStart(2, "0")).join("");
};

;// ./src/components/TagFilter/TagOption/TagOption.tsx





const TagOption = ({ tag, handleToggleTag, isSelected, showCheckbox = true }) => {
    return ((0,jsx_runtime.jsxs)("div", { "data-testid": `tag-option-${tag}`, className: TagOption_module.tagFilterOption, onClick: () => handleToggleTag(tag), "data-filter": tag, children: [showCheckbox && (0,jsx_runtime.jsx)("div", { "data-testid": "tag-checkbox", className: classNames(TagOption_module.tagFilterCheckbox, isSelected && TagOption_module.selected) }), (0,jsx_runtime.jsxs)("div", { className: TagOption_module.tagFilterRow, children: [(0,jsx_runtime.jsx)("div", { className: TagOption_module.tagDot, style: { background: stringToHexColor(tag) } }), (0,jsx_runtime.jsx)("div", { children: tag })] })] }));
};
/* harmony default export */ var TagOption_TagOption = (TagOption);

;// ./src/components/TagFilter/TagOption/index.ts


;// ./src/components/TagFilter/TagFilter.tsx









const TagFilter = ({ selectedTags, handleToggleTag }) => {
    const allTags = (0,react_redux/* useSelector */.d4)(getAllTags);
    const [showTags, setShowTags] = (0,react.useState)(false);
    const ref = hooks_useClickOutside(() => setShowTags(false));
    const onClickHandler = () => {
        setShowTags(!showTags);
    };
    return ((0,jsx_runtime.jsxs)("div", { "data-testid": "tag-filter", className: TagFilter_module.wrapper, children: [(0,jsx_runtime.jsx)("div", { "data-testid": "tag-filter-icon-button", className: TagFilter_module.filterButton, id: "tagFilterBtn", onClick: onClickHandler, children: (0,jsx_runtime.jsx)(Icons_TagFilterIcon, { width: 16, height: 16 }) }), (0,jsx_runtime.jsx)("div", { "data-testid": "tag-dropdown", className: classNames(TagFilter_module.tagDropdown, showTags && TagFilter_module.active), id: "dateFilterDropdown", ref: ref, children: allTags.map((tag) => {
                    const isTagSelected = selectedTags.includes(tag);
                    return ((0,jsx_runtime.jsx)(TagOption_TagOption, { tag: tag, handleToggleTag: handleToggleTag, isSelected: isTagSelected }, tag));
                }) })] }));
};
/* harmony default export */ var TagFilter_TagFilter = (TagFilter);

;// ./src/components/TagFilter/index.ts


;// ./src/components/index.ts





























;// ./src/modules/Project/components/Project/Project.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var Project_module = ({"projectActions":"Project-module__projectActions","checkWrapper":"Project-module__checkWrapper","projectChecked":"Project-module__projectChecked","projectActive":"Project-module__projectActive","projectWrapper":"Project-module__projectWrapper","project":"Project-module__project","projectInfo":"Project-module__projectInfo","projectDetails":"Project-module__projectDetails","projectName":"Project-module__projectName","projectDate":"Project-module__projectDate","projectThumbnail":"Project-module__projectThumbnail","pageActions":"Project-module__pageActions","actionButton":"Project-module__actionButton"});
;// ./src/modules/Project/constants.ts
const colorPalette = [
    "#AC51BD",
    "#5175BD",
    "#268A50",
    "#097F8C",
    "#986800",
    "#7351BD",
    "#1268D0",
];

;// ./src/modules/Project/helpers.ts

const extractInitials = (name) => {
    if (!name)
        return "";
    const parts = name.trim().split(" ").slice(0, 2);
    const first = parts[0] ?? "";
    const second = parts[1] ?? "";
    return (first[0] ?? "").toUpperCase() + (second[0] ?? "").toUpperCase();
};
const getColorIndex = (name) => {
    if (!name)
        return 0;
    let hash = 2166136261;
    for (let i = 0; i < name.length; i++) {
        hash ^= name.charCodeAt(i);
        hash *= 16777619;
    }
    const index = Math.abs(hash) % colorPalette.length;
    return Math.max(0, Math.min(index, colorPalette.length - 1));
};

;// ./src/modules/TopbarMenu/TitleBarMenu.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var TitleBarMenu_module = ({"wrapper":"TitleBarMenu-module__wrapper","menuCardsWrapper":"TitleBarMenu-module__menuCardsWrapper","refreshButtonWrapper":"TitleBarMenu-module__refreshButtonWrapper","pageName":"TitleBarMenu-module__pageName"});
;// ./src/modules/TopbarMenu/components/TitleBarGraphCard/styles/TitleBarGraphCard.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var TitleBarGraphCard_module = ({"graphCardWrapper":"TitleBarGraphCard-module__graphCardWrapper","defaultGraphCardContent":"TitleBarGraphCard-module__defaultGraphCardContent","running":"TitleBarGraphCard-module__running","finished":"TitleBarGraphCard-module__finished","error":"TitleBarGraphCard-module__error","pending":"TitleBarGraphCard-module__pending","indicatorWrapper":"TitleBarGraphCard-module__indicatorWrapper","textWrapper":"TitleBarGraphCard-module__textWrapper","hoverRegion":"TitleBarGraphCard-module__hoverRegion","graphTitleDefault":"TitleBarGraphCard-module__graphTitleDefault","graphTitle":"TitleBarGraphCard-module__graphTitle","graphStatusRow":"TitleBarGraphCard-module__graphStatusRow","statusText":"TitleBarGraphCard-module__statusText","statusRunning":"TitleBarGraphCard-module__statusRunning","statusFinished":"TitleBarGraphCard-module__statusFinished","statusError":"TitleBarGraphCard-module__statusError","statusPending":"TitleBarGraphCard-module__statusPending","nodeCount":"TitleBarGraphCard-module__nodeCount","graphCardContent":"TitleBarGraphCard-module__graphCardContent","stopAndTimeWrapper":"TitleBarGraphCard-module__stopAndTimeWrapper","stopButton":"TitleBarGraphCard-module__stopButton","nodeStopButton":"TitleBarGraphCard-module__nodeStopButton","timeRemaining":"TitleBarGraphCard-module__timeRemaining","timeElapsedText":"TitleBarGraphCard-module__timeElapsedText"});
;// ./src/modules/TopbarMenu/components/TitleBarNodeCard/styles/TitleBarNodeCard.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var TitleBarNodeCard_module = ({"wrapper":"TitleBarNodeCard-module__wrapper","hoverRegion":"TitleBarNodeCard-module__hoverRegion","indicatorWrapper":"TitleBarNodeCard-module__indicatorWrapper","textWrapper":"TitleBarNodeCard-module__textWrapper","topRowWrapper":"TitleBarNodeCard-module__topRowWrapper","bottomRowWrapper":"TitleBarNodeCard-module__bottomRowWrapper","statusContainer":"TitleBarNodeCard-module__statusContainer","running":"TitleBarNodeCard-module__running","timeRemainingText":"TitleBarNodeCard-module__timeRemainingText","statusRunning":"TitleBarNodeCard-module__statusRunning","statusRunningValue":"TitleBarNodeCard-module__statusRunningValue","finished":"TitleBarNodeCard-module__finished","statusFinished":"TitleBarNodeCard-module__statusFinished","error":"TitleBarNodeCard-module__error","statusError":"TitleBarNodeCard-module__statusError","pending":"TitleBarNodeCard-module__pending","statusPending":"TitleBarNodeCard-module__statusPending","nodeRunningLabel":"TitleBarNodeCard-module__nodeRunningLabel","noNodeRunningLabel":"TitleBarNodeCard-module__noNodeRunningLabel"});
;// ./src/modules/TopbarMenu/components/TitleBarNodeCard/styles/TitleBarTooltipContent.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var TitleBarTooltipContent_module = ({"tooltipContent":"TitleBarTooltipContent-module__tooltipContent","tooltipRow":"TitleBarTooltipContent-module__tooltipRow","tooltipLabel":"TitleBarTooltipContent-module__tooltipLabel","tooltipValue":"TitleBarTooltipContent-module__tooltipValue"});
;// ./src/modules/TopbarMenu/helpers.ts
const formatTime = (sec) => {
    if (sec === null)
        return "";
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = Math.floor(sec % 60);
    return `${h ? `${h}h ` : ""}${m ? `${m}m ` : ""}${s}s`;
};
const helpers_formatDate = (date) => {
    if (!date)
        return "—";
    const d = typeof date === "string" ? new Date(date) : date;
    return (d.toLocaleDateString("en-GB") +
        " " +
        d.toLocaleTimeString("en-GB", {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
            hour12: false,
        }));
};
const capitalize = (text) => {
    if (text && text.length > 0) {
        return text.charAt(0).toUpperCase() + text.slice(1);
    }
    return text;
};
const getWrapperClass = (status, styles) => {
    if (status === "running")
        return styles.running;
    if (status === "finished")
        return styles.finished;
    if (status === "error")
        return styles.error;
    return styles.pending;
};
const getStatusClass = (status, styles) => {
    if (status === "running")
        return styles.statusRunning;
    if (status === "finished")
        return styles.statusFinished;
    if (status === "error")
        return styles.statusError;
    return styles.statusPending;
};

;// ./src/modules/TopbarMenu/components/TitleBarNodeCard/TitleBarNodeTooltipContent.tsx






const TitleBarTooltipContent = () => {
    const runStatusNode = (0,react_redux/* useSelector */.d4)(getRunStatusNode);
    return ((0,jsx_runtime.jsxs)("div", { className: TitleBarTooltipContent_module.tooltipContent, children: [(0,jsx_runtime.jsxs)("div", { className: TitleBarTooltipContent_module.tooltipRow, children: [(0,jsx_runtime.jsx)("div", { className: TitleBarTooltipContent_module.tooltipLabel, children: "Run start:" }), (0,jsx_runtime.jsx)("div", { className: TitleBarTooltipContent_module.tooltipValue, children: helpers_formatDate(runStatusNode?.run_start) })] }), (0,jsx_runtime.jsxs)("div", { className: TitleBarTooltipContent_module.tooltipRow, children: [(0,jsx_runtime.jsx)("div", { className: TitleBarTooltipContent_module.tooltipLabel, children: "Status:" }), (0,jsx_runtime.jsx)("div", { className: TitleBarTooltipContent_module.tooltipValue, children: capitalize(runStatusNode?.status ?? "") })] }), (0,jsx_runtime.jsxs)("div", { className: TitleBarTooltipContent_module.tooltipRow, children: [(0,jsx_runtime.jsx)("div", { className: TitleBarTooltipContent_module.tooltipLabel, children: "Run duration:" }), (0,jsx_runtime.jsx)("div", { className: TitleBarTooltipContent_module.tooltipValue, children: formatTime(runStatusNode?.run_duration ?? 0) })] }), runStatusNode?.id && runStatusNode?.id !== -1 && ((0,jsx_runtime.jsxs)("div", { className: TitleBarTooltipContent_module.tooltipRow, children: [(0,jsx_runtime.jsx)("div", { className: TitleBarTooltipContent_module.tooltipLabel, children: "idx:" }), (0,jsx_runtime.jsx)("div", { className: TitleBarTooltipContent_module.tooltipValue, children: runStatusNode?.id })] }))] }));
};

;// ./src/modules/TopbarMenu/components/TitleBarStatusIndicator/TitleBarStatusIndicator.tsx



const StatusIndicator = (status, percentage, sizes, useNodeIcons = false) => {
    if (status === "Running") {
        const { width = 48, height = 48 } = sizes?.Running || {};
        return (0,jsx_runtime.jsx)(Icons_CircularLoaderPercentage, { percentage: percentage ?? 0, width: width, height: height });
    }
    if (status === "Finished") {
        const { width = 48, height = 48 } = sizes?.Finished || {};
        return (0,jsx_runtime.jsx)(Icons_CheckmarkIcon, { width: width, height: height });
    }
    if (status === "Error") {
        const { width = 48, height = 48 } = sizes?.Error || {};
        return (0,jsx_runtime.jsx)(Icons_ErrorIcon, { width: width, height: height });
    }
    if (status === "Pending") {
        const { width = 32, height = 32 } = sizes?.Pending || {};
        const PendingIcon = useNodeIcons ? Icons_NoNodeRunningIcon : Icons_NoGraphRunningIcon;
        return (0,jsx_runtime.jsx)(PendingIcon, { width: width, height: height });
    }
    return null;
};

;// ./src/modules/TopbarMenu/components/TitleBarNodeCard/TitleBarGetStatusLabelElement.tsx


/* eslint-disable css-modules/no-unused-class */


const getStatusLabelElement = (status, currentAction) => {
    const normalizedStatus = status?.toLowerCase();
    if (normalizedStatus === "running") {
        return ((0,jsx_runtime.jsxs)("div", { className: classNames(TitleBarNodeCard_module.statusContainer, TitleBarNodeCard_module.statusRunning), children: ["Running", (0,jsx_runtime.jsx)("span", { className: TitleBarNodeCard_module.statusRunningValue, children: currentAction ? `: ${currentAction}` : "" })] }));
    }
    if (normalizedStatus === "finished") {
        return (0,jsx_runtime.jsx)("div", { className: classNames(TitleBarNodeCard_module.statusContainer, TitleBarNodeCard_module.statusFinished), children: "Finished" });
    }
    if (normalizedStatus === "error") {
        return (0,jsx_runtime.jsx)("div", { className: classNames(TitleBarNodeCard_module.statusContainer, TitleBarNodeCard_module.statusError), children: "Error" });
    }
    return (0,jsx_runtime.jsx)("div", { className: classNames(TitleBarNodeCard_module.statusContainer, TitleBarNodeCard_module.statusPending), children: "Select and Run Node" });
};

;// ./src/modules/TopbarMenu/constants.ts
const DEFAULT_TOOLTIP_SX = {
    backgroundColor: "#42424C",
    padding: "12px",
    borderRadius: "6px",
    boxShadow: "0 2px 6px rgba(0,0,0,0.3)",
};

;// ./src/modules/TopbarMenu/components/TitleBarNodeCard/TitleBarNodeCard.tsx



/* eslint-disable css-modules/no-unused-class */












const TitleBarNodeCard = () => {
    const dispatch = useRootDispatch();
    const runStatusNodeName = (0,react_redux/* useSelector */.d4)(getRunStatusNodeName);
    const runStatusNodeStatus = (0,react_redux/* useSelector */.d4)(getRunStatusNodeStatus);
    const runStatusNodePercentage = (0,react_redux/* useSelector */.d4)(getRunStatusNodePercentage);
    const runStatusNodeId = (0,react_redux/* useSelector */.d4)(getRunStatusNodeId);
    const runStatusNodeCurrentAction = (0,react_redux/* useSelector */.d4)(getRunStatusNodeCurrentAction);
    const runStatusNodeTimeRemaining = (0,react_redux/* useSelector */.d4)(getRunStatusNodeTimeRemaining);
    const handleOnClick = () => {
        dispatch(setActivePage(NODES_KEY));
    };
    return ((0,jsx_runtime.jsx)(Tooltip/* default */.A, { title: (0,jsx_runtime.jsx)(TitleBarTooltipContent, {}), placement: "bottom", componentsProps: { tooltip: { sx: DEFAULT_TOOLTIP_SX } }, children: (0,jsx_runtime.jsx)("div", { onClick: handleOnClick, className: TitleBarNodeCard_module.hoverRegion, children: (0,jsx_runtime.jsxs)("div", { className: classNames(TitleBarNodeCard_module.wrapper, getWrapperClass(runStatusNodeStatus ?? "", TitleBarNodeCard_module)), children: [(0,jsx_runtime.jsx)("div", { className: TitleBarNodeCard_module.indicatorWrapper, children: StatusIndicator(capitalize(runStatusNodeStatus ?? "pending"), runStatusNodePercentage ?? 0, {
                            Running: { width: 30, height: 30 },
                            Finished: { width: 38, height: 38 },
                            Error: { width: 20, height: 20 },
                            Pending: { width: 26, height: 26 },
                        }, true) }), (0,jsx_runtime.jsxs)("div", { className: TitleBarNodeCard_module.textWrapper, children: [(0,jsx_runtime.jsx)("div", { className: TitleBarNodeCard_module.topRowWrapper, children: runStatusNodeStatus?.toLowerCase() === "pending" ? ((0,jsx_runtime.jsx)("div", { className: TitleBarNodeCard_module.noNodeRunningLabel, children: "No node is running" })) : ((0,jsx_runtime.jsxs)("div", { className: TitleBarNodeCard_module.nodeRunningLabel, children: [runStatusNodeId || runStatusNodeName ? "Active Node:" : "No node is running", "\u00A0\u00A0", runStatusNodeId === -1
                                            ? runStatusNodeName
                                            : runStatusNodeId && runStatusNodeName
                                                ? `#${runStatusNodeId} ${runStatusNodeName}`
                                                : ""] })) }), (0,jsx_runtime.jsxs)("div", { className: TitleBarNodeCard_module.bottomRowWrapper, children: [getStatusLabelElement(runStatusNodeStatus ?? undefined, runStatusNodeCurrentAction ?? undefined), runStatusNodeStatus?.toLowerCase() === "running" && runStatusNodePercentage && runStatusNodePercentage > 0 && ((0,jsx_runtime.jsxs)("div", { className: TitleBarNodeCard_module.timeRemainingText, children: [formatTime(runStatusNodeTimeRemaining ?? 0), "\u00A0left"] }))] })] })] }) }) }));
};
/* harmony default export */ var TitleBarNodeCard_TitleBarNodeCard = (TitleBarNodeCard);

;// ./src/modules/TopbarMenu/components/TitleBarGraphCard/styles/TitleBarTooltipContent.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var styles_TitleBarTooltipContent_module = ({"tooltipContent":"TitleBarTooltipContent-module__tooltipContent","tooltipRow":"TitleBarTooltipContent-module__tooltipRow","tooltipLabel":"TitleBarTooltipContent-module__tooltipLabel","tooltipValue":"TitleBarTooltipContent-module__tooltipValue"});
;// ./src/modules/TopbarMenu/components/TitleBarGraphCard/TitleBarGraphTooltipContent.tsx






const TitleBarGraphTooltipContent = () => {
    const runStart = (0,react_redux/* useSelector */.d4)(getRunStatusGraphRunStart);
    const runStatusGraphStatus = (0,react_redux/* useSelector */.d4)(getRunStatusGraphStatus);
    const runDuration = (0,react_redux/* useSelector */.d4)(getRunStatusGraphRunDuration);
    const finishedNodes = (0,react_redux/* useSelector */.d4)(getRunStatusGraphFinishedNodes);
    const runStatusGraphTotalNodes = (0,react_redux/* useSelector */.d4)(getRunStatusGraphTotalNodes);
    return ((0,jsx_runtime.jsxs)("div", { className: styles_TitleBarTooltipContent_module.tooltipContent, children: [(0,jsx_runtime.jsxs)("div", { className: styles_TitleBarTooltipContent_module.tooltipRow, children: [(0,jsx_runtime.jsx)("div", { className: styles_TitleBarTooltipContent_module.tooltipLabel, children: "Run start:" }), (0,jsx_runtime.jsx)("div", { className: styles_TitleBarTooltipContent_module.tooltipValue, children: helpers_formatDate(runStart) })] }), (0,jsx_runtime.jsxs)("div", { className: styles_TitleBarTooltipContent_module.tooltipRow, children: [(0,jsx_runtime.jsx)("div", { className: styles_TitleBarTooltipContent_module.tooltipLabel, children: "Status:" }), (0,jsx_runtime.jsx)("div", { className: styles_TitleBarTooltipContent_module.tooltipValue, children: capitalize(runStatusGraphStatus ?? "pending") })] }), (0,jsx_runtime.jsxs)("div", { className: styles_TitleBarTooltipContent_module.tooltipRow, children: [(0,jsx_runtime.jsx)("div", { className: styles_TitleBarTooltipContent_module.tooltipLabel, children: "Run duration:" }), (0,jsx_runtime.jsx)("div", { className: styles_TitleBarTooltipContent_module.tooltipValue, children: formatTime(runDuration ?? 0) })] }), (0,jsx_runtime.jsxs)("div", { className: styles_TitleBarTooltipContent_module.tooltipRow, children: [(0,jsx_runtime.jsx)("div", { className: styles_TitleBarTooltipContent_module.tooltipLabel, children: "Graph progress:" }), (0,jsx_runtime.jsxs)("div", { className: styles_TitleBarTooltipContent_module.tooltipValue, children: [finishedNodes, "/", runStatusGraphTotalNodes, " nodes completed"] })] })] }));
};
/* harmony default export */ var TitleBarGraphCard_TitleBarGraphTooltipContent = (TitleBarGraphTooltipContent);

;// ./src/modules/TopbarMenu/components/TitleBarGraphCard/TitleBarGraphCard.tsx



/* eslint-disable css-modules/no-unused-class */













const RunningNode = ({ handleStopClick }) => {
    const timeRemaining = (0,react_redux/* useSelector */.d4)(getRunStatusGraphTimeRemaining);
    return (0,jsx_runtime.jsxs)("div", { className: TitleBarGraphCard_module.stopAndTimeWrapper, children: [(0,jsx_runtime.jsx)("div", { className: TitleBarGraphCard_module.stopButton, onClick: handleStopClick, children: (0,jsx_runtime.jsx)(Icons_StopButtonIcon, {}) }), timeRemaining && ((0,jsx_runtime.jsxs)("div", { className: TitleBarGraphCard_module.timeRemaining, children: [formatTime(timeRemaining), " left"] }))] });
};
const TitleBarGraphCard = () => {
    const dispatch = useRootDispatch();
    const runStatusNodeStatus = (0,react_redux/* useSelector */.d4)(getRunStatusNodeStatus);
    const runStatusNodeRunDuration = (0,react_redux/* useSelector */.d4)(getRunStatusNodeRunDuration);
    const runStatusGraphName = (0,react_redux/* useSelector */.d4)(getRunStatusGraphName);
    const runStatusGraphStatus = (0,react_redux/* useSelector */.d4)(getRunStatusGraphStatus);
    const percentageComplete = (0,react_redux/* useSelector */.d4)(getRunStatusGraphPercentageComplete);
    const finishedNodes = (0,react_redux/* useSelector */.d4)(getRunStatusGraphFinishedNodes);
    const runDuration = (0,react_redux/* useSelector */.d4)(getRunStatusGraphRunDuration);
    const runStatusGraphTotalNodes = (0,react_redux/* useSelector */.d4)(getRunStatusGraphTotalNodes);
    const handleOnClick = (0,react.useCallback)(() => {
        dispatch(setActivePage(runStatusGraphStatus === "pending" ? GRAPH_LIBRARY_KEY : GRAPH_STATUS_KEY));
    }, [setActivePage, runStatusGraphStatus]);
    const renderElapsedTime = (time) => ((0,jsx_runtime.jsx)("div", { className: TitleBarGraphCard_module.stopAndTimeWrapper, children: (0,jsx_runtime.jsxs)("div", { className: TitleBarGraphCard_module.timeRemaining, children: [(0,jsx_runtime.jsx)("div", { children: "Elapsed time:" }), (0,jsx_runtime.jsx)("div", { className: TitleBarGraphCard_module.timeElapsedText, children: formatTime(time) })] }) }));
    const handleStopClick = async () => {
        SnapshotsApi.stopNodeRunning();
    };
    return ((0,jsx_runtime.jsx)("div", { className: `${TitleBarGraphCard_module.graphCardWrapper} ${getWrapperClass(runStatusGraphStatus ?? "pending", TitleBarGraphCard_module)}`, children: (0,jsx_runtime.jsxs)("div", { className: runStatusGraphStatus === "pending" ? TitleBarGraphCard_module.defaultGraphCardContent : TitleBarGraphCard_module.graphCardContent, children: [(0,jsx_runtime.jsx)(Tooltip/* default */.A, { title: (0,jsx_runtime.jsx)(TitleBarGraphCard_TitleBarGraphTooltipContent, {}), placement: "bottom", componentsProps: { tooltip: { sx: DEFAULT_TOOLTIP_SX } }, children: (0,jsx_runtime.jsxs)("div", { onClick: handleOnClick, className: TitleBarGraphCard_module.hoverRegion, children: [(0,jsx_runtime.jsx)("div", { className: TitleBarGraphCard_module.indicatorWrapper, children: StatusIndicator(capitalize(runStatusGraphStatus ?? "pending"), percentageComplete ?? 0, {
                                    Running: { width: 48, height: 48 },
                                    Finished: { width: 48, height: 48 },
                                    Error: { width: 48, height: 48 },
                                    Pending: { width: 32, height: 32 },
                                }, false) }), (0,jsx_runtime.jsx)("div", { className: TitleBarGraphCard_module.textWrapper, children: !runStatusGraphStatus ? ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)("div", { className: TitleBarGraphCard_module.graphTitleDefault, children: "No graph is running" }), (0,jsx_runtime.jsx)("div", { className: TitleBarGraphCard_module.graphStatusRow, children: (0,jsx_runtime.jsx)("div", { className: TitleBarGraphCard_module.statusPending, children: "Select and Run Calibration Graph" }) })] })) : ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsxs)("div", { className: TitleBarGraphCard_module.graphTitle, children: ["Graph: ", runStatusGraphName || "No graph is running"] }), (0,jsx_runtime.jsxs)("div", { className: TitleBarGraphCard_module.graphStatusRow, children: [(0,jsx_runtime.jsx)("div", { className: `${TitleBarGraphCard_module.statusText} ${getStatusClass(runStatusGraphStatus ?? "pending", TitleBarGraphCard_module)}`, children: runStatusGraphStatus }), runStatusGraphStatus !== "finished" && ((0,jsx_runtime.jsxs)("div", { className: TitleBarGraphCard_module.nodeCount, children: [finishedNodes, "/", runStatusGraphTotalNodes, " nodes finished"] }))] })] })) })] }) }), (0,jsx_runtime.jsx)(TitleBarNodeCard_TitleBarNodeCard, {}), runStatusGraphStatus === "running" && (0,jsx_runtime.jsx)(RunningNode, { handleStopClick: handleStopClick }), ["finished", "error"].includes(runStatusGraphStatus ?? "pending") &&
                    runDuration &&
                    runDuration > 0 &&
                    renderElapsedTime(runDuration), runStatusGraphStatus === "pending" && runStatusNodeStatus === "running" && ((0,jsx_runtime.jsx)("div", { className: TitleBarGraphCard_module.nodeStopButton, onClick: handleStopClick, children: (0,jsx_runtime.jsx)(Icons_StopButtonIcon, {}) })), runStatusGraphStatus === "pending" &&
                    ["finished", "error"].includes(runStatusNodeStatus ?? "pending") &&
                    runStatusNodeRunDuration &&
                    runStatusNodeRunDuration > 0 &&
                    renderElapsedTime(runStatusNodeRunDuration)] }) }));
};
/* harmony default export */ var TitleBarGraphCard_TitleBarGraphCard = (TitleBarGraphCard);

;// ./src/modules/TopbarMenu/TitleBarMenu.tsx


// eslint-disable-next-line css-modules/no-unused-class







const TopBar = () => {
    const activePage = (0,react_redux/* useSelector */.d4)(getActivePage);
    return activePage === PROJECT_KEY ? null : (0,jsx_runtime.jsx)(TitleBarGraphCard_TitleBarGraphCard, {});
};
const TitleBarMenu = ({ customTitle }) => {
    const dispatch = useRootDispatch();
    const activePage = (0,react_redux/* useSelector */.d4)(getActivePage);
    const IsRefreshButtonShown = (0,react_redux/* useSelector */.d4)(getIsRefreshButtonShown);
    return ((0,jsx_runtime.jsxs)("div", { className: TitleBarMenu_module.wrapper, children: [(0,jsx_runtime.jsx)("h1", { className: TitleBarMenu_module.pageName, children: AppRoutes_ModulesRegistry[activePage ?? ""]?.menuItem?.title }), (0,jsx_runtime.jsx)("h2", { children: customTitle }), IsRefreshButtonShown && ((0,jsx_runtime.jsx)("div", { className: TitleBarMenu_module.refreshButtonWrapper, "data-testid": "refresh-button", children: (0,jsx_runtime.jsx)(Button_BlueButton, { onClick: () => dispatch(refreshPage()), children: "Refresh" }) })), (0,jsx_runtime.jsx)("div", { className: TitleBarMenu_module.menuCardsWrapper, children: (0,jsx_runtime.jsx)(TopBar, {}) })] }));
};
/* harmony default export */ var TopbarMenu_TitleBarMenu = (TitleBarMenu);

;// ./src/modules/TopbarMenu/index.ts



;// ./src/modules/Project/components/Project/ProjectInfo.tsx


// eslint-disable-next-line css-modules/no-unused-class




const ProjectInfo = ({ name, date, colorIcon }) => {
    return ((0,jsx_runtime.jsxs)("div", { className: Project_module.projectInfo, children: [(0,jsx_runtime.jsx)("div", { className: Project_module.projectThumbnail, children: (0,jsx_runtime.jsx)(Icons_ProjectFolderIcon, { initials: extractInitials(name), fillColor: colorIcon }) }), (0,jsx_runtime.jsxs)("div", { className: Project_module.projectDetails, children: [(0,jsx_runtime.jsx)("div", { className: Project_module.projectName, children: name || "" }), date && (0,jsx_runtime.jsxs)("div", { className: Project_module.projectDate, children: ["Last updated: ", helpers_formatDate(date)] })] })] }));
};
/* harmony default export */ var Project_ProjectInfo = (ProjectInfo);

;// ./src/modules/Project/components/Project/ProjectActions.tsx


// eslint-disable-next-line css-modules/no-unused-class








const ProjectActions = ({ isCurrentProject, projectName, selectedProject }) => {
    const dispatch = useRootDispatch();
    const handleSubmit = (0,react.useCallback)(() => {
        if (!selectedProject)
            return;
        dispatch(selectActiveProject(selectedProject));
        dispatch(clearData());
        dispatch(fetchGitgraphSnapshots(true));
        dispatch(setActivePage(NODES_KEY));
    }, [selectedProject]);
    return ((0,jsx_runtime.jsxs)("div", { className: Project_module.pageActions, children: [selectedProject?.name === projectName && ((0,jsx_runtime.jsx)(Button_BlueButton, { onClick: handleSubmit, className: Project_module.actionButton, disabled: selectedProject === undefined, "data-cy": utils_cyKeys.projects.LETS_START_BUTTON, "data-testid": "lets-start-button-" + projectName, isBig: true, children: "Let\u2019s Start" })), isCurrentProject && (0,jsx_runtime.jsx)(Icons_ProjectCheckIcon, {})] }));
};
/* harmony default export */ var Project_ProjectActions = (ProjectActions);

;// ./src/modules/Project/components/Project/Project.tsx




// eslint-disable-next-line css-modules/no-unused-class







const Project = ({ isActive = false, lastModifiedAt = "", project, selectedProject, setSelectedProject }) => {
    const activeProject = (0,react_redux/* useSelector */.d4)(getActiveProject);
    const isCurrentProjectActive = activeProject?.name === project.name;
    const index = (0,react.useMemo)(() => getColorIndex(project.name), [project.name]);
    const projectColor = colorPalette[index];
    const handleOnClick = (0,react.useCallback)((project) => {
        setSelectedProject(project);
    }, [setSelectedProject]);
    return ((0,jsx_runtime.jsx)("div", { className: Project_module.projectWrapper, "data-testid": "project-wrapper-" + project.name, children: (0,jsx_runtime.jsxs)("div", { className: classNames(Project_module.project, isActive && Project_module.projectActive, isCurrentProjectActive && Project_module.projectChecked), onClick: () => handleOnClick(project), "data-cy": utils_cyKeys.projects.PROJECT, children: [(0,jsx_runtime.jsx)(Project_ProjectInfo, { name: project.name, colorIcon: projectColor, date: lastModifiedAt ? new Date(lastModifiedAt) : undefined }), (0,jsx_runtime.jsx)(Project_ProjectActions, { isCurrentProject: isCurrentProjectActive, projectName: project.name, selectedProject: selectedProject })] }) }));
};
/* harmony default export */ var Project_Project = (Project);

;// ./src/modules/Project/components/ProjectList/ProjectList.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var ProjectList_module = ({"splash":"ProjectList-module__splash","splashNoProject":"ProjectList-module__splashNoProject"});
;// ./src/modules/Project/components/ProjectList/ProjectList.tsx

 // eslint-disable-next-line css-modules/no-unused-class





const ProjectList = ({ projects, selectedProject, setSelectedProject }) => {
    const isScanningProjects = (0,react_redux/* useSelector */.d4)(getIsScanningProjects);
    const sortedProjects = (0,react.useMemo)(() => {
        return [...projects].sort((a, b) => new Date(b.last_modified_at).getTime() - new Date(a.last_modified_at).getTime());
    }, [projects]);
    if (!isScanningProjects && projects?.length === 0) {
        return ((0,jsx_runtime.jsx)("div", { className: ProjectList_module.splashNoProject, children: (0,jsx_runtime.jsx)(Loader_LoadingBar, { icon: (0,jsx_runtime.jsx)(NoItemsIcon, { height: 204, width: 200 }), text: "No projects found" }) }));
    }
    return ((0,jsx_runtime.jsx)("div", { className: ProjectList_module.splash, children: sortedProjects.map((project, index) => ((0,jsx_runtime.jsx)(Project_Project, { isActive: selectedProject?.name === project.name, project: project, lastModifiedAt: project.last_modified_at, selectedProject: selectedProject, setSelectedProject: setSelectedProject }, index))) }));
};
/* harmony default export */ var ProjectList_ProjectList = (ProjectList);

;// ./src/modules/Project/components/ProjectTitleBar/ProjectTitleBar.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var ProjectTitleBar_module = ({"createProjectWrapper":"ProjectTitleBar-module__createProjectWrapper","createProjectButton":"ProjectTitleBar-module__createProjectButton","createProjectPanelWrapper":"ProjectTitleBar-module__createProjectPanelWrapper"});
;// ./src/modules/Project/components/CreateNewProjectForm/CreateNewProjectForm.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var CreateNewProjectForm_module = ({"createProjectPanel":"CreateNewProjectForm-module__createProjectPanel","header":"CreateNewProjectForm-module__header","error":"CreateNewProjectForm-module__error","errorMessage":"CreateNewProjectForm-module__errorMessage","actions":"CreateNewProjectForm-module__actions","button":"CreateNewProjectForm-module__button","create":"CreateNewProjectForm-module__create","cancel":"CreateNewProjectForm-module__cancel"});
;// ./src/modules/Project/components/CreateNewProjectForm/useProjectFormValidation.ts

const useProjectFormValidation = () => {
    const validatePath = (0,react.useCallback)((value, fieldName) => {
        if (value.trim() === "")
            return `${fieldName} is required`;
        const trimmedValue = value.trim();
        if (!trimmedValue.startsWith("/") && !trimmedValue.startsWith("./") && !trimmedValue.startsWith("../")) {
            return `${fieldName} should be absolute or relative (starting with /, ./, or ../)`;
        }
        return undefined;
    }, []);
    const validateProjectName = (0,react.useCallback)((value) => {
        if (value.trim() === "")
            return "Project name is required";
        const trimmedValue = value.trim();
        if (trimmedValue.length < 2) {
            return "Project name must be at least 2 characters long";
        }
        if (trimmedValue.length > 50) {
            return "Project name must be no more than 50 characters long";
        }
        const invalidChars = /[<>:"/\\|?*]/;
        if (invalidChars.test(trimmedValue)) {
            return 'Project name cannot contain invalid characters: < > : " / \\ | ? *';
        }
        for (let i = 0; i < trimmedValue.length; i++) {
            const charCode = trimmedValue.charCodeAt(i);
            if (charCode < 32) {
                return "Project name cannot contain control characters";
            }
        }
        const reservedNames = /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9]|\.|\.\.)$/i;
        if (reservedNames.test(trimmedValue)) {
            return "Project name cannot be a reserved system name";
        }
        if (trimmedValue.startsWith(" ") || trimmedValue.endsWith(" ") || trimmedValue.startsWith(".") || trimmedValue.endsWith(".")) {
            return "Project name cannot start or end with spaces or dots";
        }
        if (/\s{2,}/.test(trimmedValue) || /\.{2,}/.test(trimmedValue)) {
            return "Project name cannot contain consecutive spaces or dots";
        }
        const validPattern = /^[a-zA-Z0-9_\-\s.]+$/;
        if (!validPattern.test(trimmedValue)) {
            return "Project name can only contain letters, numbers, spaces, hyphens, underscores, and dots";
        }
        return undefined;
    }, []);
    return {
        validatePath,
        validateProjectName,
    };
};

;// ./src/modules/Project/components/CreateNewProjectForm/CreateNewProjectForm.tsx


// eslint-disable-next-line css-modules/no-unused-class






const initialFormData = {
    projectName: "",
};
const CreateNewProjectForm = ({ closeNewProjectForm }) => {
    const [formData, setFormData] = (0,react.useState)(initialFormData);
    const [errors, setErrors] = (0,react.useState)({});
    const [isSubmitting, setIsSubmitting] = (0,react.useState)(false);
    const { validatePath, validateProjectName } = useProjectFormValidation();
    const allProjects = (0,react_redux/* useSelector */.d4)(getAllProjects);
    const dispatch = useRootDispatch();
    const validateField = (0,react.useCallback)((field, value) => {
        let error;
        if (field === "projectName") {
            error = validateProjectName(value);
        }
        else if (value.trim()) {
            const labelMap = {
                projectName: "Project name",
                dataPath: "Data path",
                quamPath: "QUAM path",
                calibrationPath: "Calibration path",
            };
            error = validatePath(value, labelMap[field]);
        }
        else {
            error = undefined;
        }
        setErrors((prev) => ({ ...prev, [field]: error }));
        return !error;
    }, [validatePath, validateProjectName]);
    const isFormValid = (0,react.useCallback)(() => {
        return !validateProjectName(formData.projectName);
    }, [formData.projectName, validateProjectName]);
    const handleCloseNewProjectForm = (0,react.useCallback)(() => {
        setFormData(initialFormData);
        setErrors({});
        closeNewProjectForm();
    }, [closeNewProjectForm]);
    const checkProjectNameExists = (0,react.useCallback)((projectName) => allProjects.some((project) => project.name === projectName), [allProjects]);
    const handleSubmit = (0,react.useCallback)(async (event) => {
        event.preventDefault();
        if (!isFormValid())
            return;
        setIsSubmitting(true);
        try {
            if (checkProjectNameExists(formData.projectName)) {
                setErrors((prev) => ({
                    ...prev,
                    projectName: "A project with this name already exists",
                }));
                return;
            }
            const { isOk, error, result } = await ProjectViewApi.createProject(formData);
            if (isOk) {
                console.log("Project created successfully:", result);
                if (result) {
                    dispatch(addProject(result));
                }
                handleCloseNewProjectForm();
            }
            else {
                console.error("Failed to create project:", error);
            }
        }
        catch (err) {
            console.error("Error creating project:", err);
        }
        finally {
            setIsSubmitting(false);
        }
    }, [formData, isFormValid, checkProjectNameExists, handleCloseNewProjectForm]);
    const createChangeHandler = (0,react.useCallback)((field) => (val) => {
        setFormData((prev) => ({ ...prev, [field]: val }));
        setTimeout(() => validateField(field, val), 300);
    }, [validateField]);
    const handleProjectNameChange = createChangeHandler("projectName");
    const handleDataPathChange = createChangeHandler("dataPath");
    const handleQuamPathChange = createChangeHandler("quamPath");
    const handleCalibrationPathChange = createChangeHandler("calibrationPath");
    return ((0,jsx_runtime.jsxs)("div", { className: CreateNewProjectForm_module.createProjectPanel, children: [(0,jsx_runtime.jsx)("h3", { className: CreateNewProjectForm_module.header, children: "Create New Project" }), (0,jsx_runtime.jsx)(Input_ProjectFormField, { id: "project_name", label: "Project name*", placeholder: "Enter project name", value: formData.projectName, onChange: handleProjectNameChange, error: errors.projectName }), (0,jsx_runtime.jsx)(Input_ProjectFormField, { id: "data_path", label: "Data path", placeholder: "Enter data path", value: formData.dataPath ?? "", onChange: handleDataPathChange, error: errors.dataPath }), (0,jsx_runtime.jsx)(Input_ProjectFormField, { id: "quam_state_path", label: "QUAM state path", placeholder: "Enter QUAM path", value: formData.quamPath ?? "", onChange: handleQuamPathChange, error: errors.quamPath }), (0,jsx_runtime.jsx)(Input_ProjectFormField, { id: "calibration_library_path", label: "Calibration library path", placeholder: "Enter calibration path", value: formData.calibrationPath ?? "", onChange: handleCalibrationPathChange, error: errors.calibrationPath }), (0,jsx_runtime.jsxs)("div", { className: CreateNewProjectForm_module.actions, children: [(0,jsx_runtime.jsx)("button", { type: "button", onClick: handleCloseNewProjectForm, className: CreateNewProjectForm_module.cancel, disabled: isSubmitting, children: "Cancel" }), (0,jsx_runtime.jsx)("button", { type: "submit", onClick: handleSubmit, className: CreateNewProjectForm_module.create, disabled: !isFormValid() || isSubmitting, children: isSubmitting ? "Creating..." : "Create" })] })] }));
};
/* harmony default export */ var CreateNewProjectForm_CreateNewProjectForm = (CreateNewProjectForm);

;// ./src/modules/Project/components/ProjectTitleBar/ProjectTitleBar.tsx

 // eslint-disable-next-line css-modules/no-unused-class



const ProjectTitleBar = () => {
    const [showCreateNewProjectForm, setShowCreateNewProjectForm] = (0,react.useState)(false);
    const handleTogglePanel = (0,react.useCallback)(() => {
        setShowCreateNewProjectForm((prev) => !prev);
    }, []);
    const handleCancel = (0,react.useCallback)(() => {
        setShowCreateNewProjectForm(false);
    }, []);
    return ((0,jsx_runtime.jsxs)("div", { className: ProjectTitleBar_module.createProjectWrapper, children: [(0,jsx_runtime.jsx)("button", { title: "Create new project", onClick: handleTogglePanel, className: ProjectTitleBar_module.createProjectButton, children: (0,jsx_runtime.jsx)(Icons_NewProjectButtonIcon, {}) }), showCreateNewProjectForm && ((0,jsx_runtime.jsx)("div", { className: ProjectTitleBar_module.createProjectPanelWrapper, children: (0,jsx_runtime.jsx)(CreateNewProjectForm_CreateNewProjectForm, { closeNewProjectForm: handleCancel }) }))] }));
};
/* harmony default export */ var ProjectTitleBar_ProjectTitleBar = (ProjectTitleBar);

;// ./src/modules/Project/Project.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var Project_Project_module = ({"projectPageWrapper":"Project-module__projectPageWrapper","splashNoProject":"Project-module__splashNoProject","searchProjectField":"Project-module__searchProjectField"});
;// ./src/modules/Project/Project.tsx






// eslint-disable-next-line css-modules/no-unused-class





const Project_Project_Project = () => {
    const dispatch = useRootDispatch();
    const allProjects = (0,react_redux/* useSelector */.d4)(getAllProjects);
    const activeProject = (0,react_redux/* useSelector */.d4)(getActiveProject);
    const isScanningProjects = (0,react_redux/* useSelector */.d4)(getIsScanningProjects);
    const [listedProjects, setListedProjects] = (0,react.useState)(allProjects);
    const [selectedProject, setSelectedProject] = (0,react.useState)(undefined);
    (0,react.useEffect)(() => {
        setSelectedProject(activeProject ?? undefined);
    }, [activeProject]);
    (0,react.useEffect)(() => {
        if (activeProject) {
            dispatch(fetchAllNodes());
            dispatch(fetchAllCalibrationGraphs());
        }
    }, [activeProject]);
    (0,react.useEffect)(() => {
        setListedProjects(allProjects);
    }, [allProjects, setListedProjects]);
    const handleSearchChange = (0,react.useCallback)((searchTerm) => {
        setListedProjects(allProjects.filter((p) => p.name.startsWith(searchTerm)));
    }, [allProjects]);
    if (isScanningProjects) {
        return (0,jsx_runtime.jsx)(LoaderPage, {});
    }
    return ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsxs)("div", { className: Project_Project_module.projectPageWrapper, children: [(0,jsx_runtime.jsxs)("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [(0,jsx_runtime.jsx)("div", { children: "Please select a Project" }), (0,jsx_runtime.jsx)(ProjectTitleBar_ProjectTitleBar, {})] }), (0,jsx_runtime.jsx)(Input_InputField, { name: "search", iconType: IconType.INNER, placeholder: "Project Name", className: Project_Project_module.searchProjectField, onChange: handleSearchChange, icon: (0,jsx_runtime.jsx)(SearchIcon, { height: 18, width: 18 }) })] }), (0,jsx_runtime.jsx)(ProjectList_ProjectList, { projects: listedProjects, selectedProject: selectedProject, setSelectedProject: setSelectedProject }), isScanningProjects && listedProjects?.length === 0 && ((0,jsx_runtime.jsx)("div", { className: Project_Project_module.splashNoProject, children: (0,jsx_runtime.jsx)(Loader_LoadingBar, { icon: (0,jsx_runtime.jsx)(NoItemsIcon, { height: 204, width: 200 }), text: "No projects found" }) }))] }));
};
/* harmony default export */ var modules_Project_Project = (Project_Project_Project);

;// ./src/modules/Project/index.ts




;// ./src/modules/SidebarMenu/SidebarMenu.tsx





// import { THEME_TOGGLE_VISIBLE } from "../../dev.config";
// import ThemeToggle from "../themeModule/ThemeToggle";










const SidebarMenu = () => {
    const { pinSideMenu } = (0,react.useContext)(themeModule_GlobalThemeContext);
    const [minify, setMinify] = (0,react.useState)(false);
    const dispatch = useRootDispatch();
    const activePage = (0,react_redux/* useSelector */.d4)(getActivePage);
    const containerClassName = classNames(SidebarMenu_module.sidebarMenu, minify ? SidebarMenu_module.collapsed : SidebarMenu_module.expanded);
    const activeProject = (0,react_redux/* useSelector */.d4)(getActiveProject);
    const shouldGoToProjectPage = (0,react_redux/* useSelector */.d4)(getShouldGoToProjectPage);
    const handleProjectClick = (0,react.useCallback)(() => {
        dispatch(setActivePage(PROJECT_KEY));
    }, [setActivePage]);
    const handleHelpClick = (0,react.useCallback)(() => {
        window.open("https://qua-platform.github.io/qualibrate/", "_blank", "noopener,noreferrer,width=800,height=600");
    }, []);
    (0,react.useEffect)(() => {
        setMinify(!pinSideMenu);
    }, [pinSideMenu]);
    return ((0,jsx_runtime.jsx)(jsx_runtime.Fragment, { children: (0,jsx_runtime.jsxs)("div", { className: containerClassName, children: [(0,jsx_runtime.jsx)("button", { className: SidebarMenu_module.qualibrateLogo, "data-cy": utils_cyKeys.HOME_PAGE, children: minify ? (0,jsx_runtime.jsx)(QualibrateLogoSmall, {}) : (0,jsx_runtime.jsx)(Icons_QUAlibrateLogoIcon, {}) }), (0,jsx_runtime.jsxs)("div", { className: SidebarMenu_module.menuContent, children: [(0,jsx_runtime.jsx)("div", { className: SidebarMenu_module.menuUpperContent, children: menuItems.map((item) => {
                                return ((0,react.createElement)(SidebarMenu_MenuItem, { ...item, key: item.keyId, hideText: minify, onClick: () => dispatch(setActivePage(item.keyId)), isSelected: activePage === item.keyId, isDisabled: !activeProject || shouldGoToProjectPage, "data-testid": `menu-item-${item.keyId}` }));
                            }) }), (0,jsx_runtime.jsx)("div", { className: SidebarMenu_module.menuBottomContent, children: bottomMenuItems.map((item) => {
                                const menuItem = { ...item.menuItem };
                                let handleOnClick = () => { };
                                if (item.keyId === TOGGLE_SIDEBAR_KEY) {
                                    handleOnClick = () => setMinify(!minify);
                                    menuItem.icon = minify ? Icons_ExpandSideMenuIcon : Icons_CollapseSideMenuIcon;
                                }
                                else if (item.keyId === HELP_KEY) {
                                    handleOnClick = handleHelpClick;
                                }
                                else if (item.keyId === PROJECT_KEY) {
                                    handleOnClick = handleProjectClick;
                                    if (activeProject) {
                                        menuItem.sideBarTitle = activeProject.name;
                                        menuItem.icon = () => ((0,jsx_runtime.jsx)(Icons_ProjectFolderIcon, { initials: extractInitials(activeProject.name), fillColor: colorPalette[getColorIndex(activeProject.name)], width: 28, height: 28, fontSize: 13 }));
                                    }
                                }
                                return ((0,react.createElement)(SidebarMenu_MenuItem, { ...item, menuItem: menuItem, key: item.keyId, hideText: minify, isSelected: item.keyId === PROJECT_KEY && activePage === PROJECT_KEY, onClick: handleOnClick }));
                            }) })] })] }) }));
};
/* harmony default export */ var SidebarMenu_SidebarMenu = (SidebarMenu);

;// ./src/modules/SidebarMenu/index.ts


;// ./src/modules/AppRoutes/components/MainLayout/Layout.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var Layout_module = ({"sidebarWrapper":"Layout-module__sidebarWrapper","titlebarWrapper":"Layout-module__titlebarWrapper","rightsidePanelWrapper":"Layout-module__rightsidePanelWrapper","contentWrapper":"Layout-module__contentWrapper"});
;// ./src/modules/RightSidebar/styles/RightSidePanel.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var RightSidePanel_module = ({"wrapper":"RightSidePanel-module__wrapper","tabContainer":"RightSidePanel-module__tabContainer","tabContainerSelected":"RightSidePanel-module__tabContainerSelected","sliderPanelWrapperLogger":"RightSidePanel-module__sliderPanelWrapperLogger","sliderPanelWrapper":"RightSidePanel-module__sliderPanelWrapper"});
;// ./src/modules/RightSidebar/Logs/styles/LogsPanel.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var LogsPanel_module = ({"panelHeader":"LogsPanel-module__panelHeader","panelHeaderSpan":"LogsPanel-module__panelHeaderSpan","panelContent":"LogsPanel-module__panelContent","logsTimestamp":"LogsPanel-module__logsTimestamp","logsMessage":"LogsPanel-module__logsMessage"});
;// ./src/modules/RightSidebar/Logs/LogsPanel.tsx








const LogsPanel = () => {
    const [logs, setLogs] = (0,react.useState)([]);
    const logsWS = (0,react.useRef)(null);
    const dispatch = useRootDispatch();
    (0,react.useEffect)(() => {
        const protocol = window.location.protocol === "http:" ? "ws" : "wss";
        const host = "127.0.0.1:8001/" || 0;
        const logsUrl = `${protocol}://${host}${WS_LOGS}`;
        logsWS.current = new WebSocketService(logsUrl, (logItem) => setLogs(prev => [logItem, ...prev]), () => dispatch(handleHideConnectionErrorDialog()), () => dispatch(handleShowConnectionErrorDialog()));
        if (logsWS.current && !logsWS.current.isConnected()) {
            logsWS.current.connect();
        }
        return () => {
            if (logsWS.current && logsWS.current.isConnected()) {
                logsWS.current.disconnect();
            }
        };
    }, []);
    return ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)("div", { className: LogsPanel_module.panelHeader, children: (0,jsx_runtime.jsx)("span", { className: LogsPanel_module.panelHeaderSpan, children: "LOGS" }) }), (0,jsx_runtime.jsx)("div", { className: LogsPanel_module.panelContent, children: logs.map((log, index) => {
                    return ((0,jsx_runtime.jsxs)("div", { children: [(0,jsx_runtime.jsx)("div", { className: LogsPanel_module.logsTimestamp, children: `${formatDateTime(log.asctime)} - ${log.name} - ${log.levelname}` }), (0,jsx_runtime.jsxs)("div", { className: LogsPanel_module.logsMessage, children: [log.message?.split("\\n").map((item, idx) => {
                                        return ((0,jsx_runtime.jsxs)("span", { children: [item, (0,jsx_runtime.jsx)("br", {})] }, idx));
                                    }), log.exc_info ? (0,jsx_runtime.jsx)("br", {}) : "", log.exc_info?.split("\\n").map((item, idx) => {
                                        return ((0,jsx_runtime.jsxs)("span", { children: [item, (0,jsx_runtime.jsx)("br", {})] }, idx));
                                    })] })] }, `${log.name}_${index}`));
                }) })] }));
};

;// ./src/modules/RightSidebar/QuamPanel/styles/QuamPanel.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var QuamPanel_module = ({"panelHeader":"QuamPanel-module__panelHeader","panelHeaderContent":"QuamPanel-module__panelHeaderContent","panelContent":"QuamPanel-module__panelContent","trackLatestWrapper":"QuamPanel-module__trackLatestWrapper","idWrapper":"QuamPanel-module__idWrapper"});
;// ./src/modules/RightSidebar/QuamPanel/components/PanelHeader/PanelHeader.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var PanelHeader_module = ({"panelHeader":"PanelHeader-module__panelHeader","panelHeaderSpan":"PanelHeader-module__panelHeaderSpan","panelHeaderContent":"PanelHeader-module__panelHeaderContent","trackLatestWrapper":"PanelHeader-module__trackLatestWrapper","idWrapper":"PanelHeader-module__idWrapper","title":"PanelHeader-module__title"});
;// ./src/modules/RightSidebar/QuamPanel/components/IdInputField/IdInputField.tsx



const IdInputField = ({ onChange, onConfirm, value, isFirstId, disabled, onFocus }) => ((0,jsx_runtime.jsx)(Input_InputField, { disabled: disabled, value: value, placeholder: "", onChange: onChange, onFocus: onFocus, onKeyDown: (e) => {
        if (e.key === "Enter" && onConfirm) {
            onConfirm(e.target.value, !!isFirstId);
        }
    } }));

;// ./src/modules/RightSidebar/QuamPanel/components/PanelHeader/PanelHeader.tsx


// eslint-disable-next-line css-modules/no-unused-class



const PanelHeader = ({ trackLatest, onToggleTrackLatest, onIdChange, idValue, onConfirm, onFocus }) => ((0,jsx_runtime.jsxs)("div", { className: PanelHeader_module.panelHeader, children: [(0,jsx_runtime.jsx)("span", { className: PanelHeader_module.panelHeaderSpan, children: "QUAM" }), (0,jsx_runtime.jsx)("div", { className: PanelHeader_module.panelHeaderContent, children: (0,jsx_runtime.jsxs)("div", { className: PanelHeader_module.trackLatestWrapper, children: [(0,jsx_runtime.jsx)("span", { children: "Track latest" }), (0,jsx_runtime.jsx)(ToggleSwitch, { isOn: trackLatest, onToggle: onToggleTrackLatest })] }) }), (0,jsx_runtime.jsxs)("div", { className: PanelHeader_module.idWrapper, children: [(0,jsx_runtime.jsx)("div", { children: "ID:" }), (0,jsx_runtime.jsx)(IdInputField, { onChange: onIdChange, value: idValue, onConfirm: onConfirm, isFirstId: true, disabled: trackLatest, onFocus: onFocus })] })] }));

;// ./src/modules/RightSidebar/QuamPanel/components/PanelUpdates/PanelUpdates.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var PanelUpdates_module = ({"panelUpdates":"PanelUpdates-module__panelUpdates","panelHeaderSpan":"PanelUpdates-module__panelHeaderSpan","panelHeaderContent":"PanelUpdates-module__panelHeaderContent","idWrapper":"PanelUpdates-module__idWrapper","trackLatestWrapper":"PanelUpdates-module__trackLatestWrapper"});
;// ./src/modules/RightSidebar/QuamPanel/components/PanelUpdates/PanelUpdates.tsx


// eslint-disable-next-line css-modules/no-unused-class



const PanelUpdates = ({ previousSnapshot, onTogglePrevious, onSecondIdChange, idValue, onConfirm }) => ((0,jsx_runtime.jsxs)("div", { className: PanelUpdates_module.panelUpdates, children: [(0,jsx_runtime.jsx)("div", { children: (0,jsx_runtime.jsx)("span", { className: PanelUpdates_module.panelHeaderSpan, children: "QUAM Updates" }) }), (0,jsx_runtime.jsx)("div", { className: PanelUpdates_module.panelHeaderContent, children: (0,jsx_runtime.jsxs)("div", { className: PanelUpdates_module.idWrapper, children: [(0,jsx_runtime.jsx)("div", { children: "Compare with:" }), (0,jsx_runtime.jsxs)("div", { className: PanelUpdates_module.trackLatestWrapper, children: [(0,jsx_runtime.jsx)("span", { children: "Prev" }), (0,jsx_runtime.jsx)(ToggleSwitch, { isOn: previousSnapshot, onToggle: onTogglePrevious })] }), (0,jsx_runtime.jsxs)("div", { className: PanelUpdates_module.idWrapper, children: [(0,jsx_runtime.jsx)("div", { children: "ID:" }), (0,jsx_runtime.jsx)(IdInputField, { onChange: onSecondIdChange, value: idValue, onConfirm: onConfirm, disabled: previousSnapshot })] })] }) })] }));

;// ./src/modules/RightSidebar/QuamPanel/QuamPanel.tsx

 // eslint-disable-next-line css-modules/no-unused-class







const QuamPanel = () => {
    // const [trackLatestSidePanel, setTrackLatestSidePanel] = useState(true);
    // const [trackPreviousSnapshot, setTrackPreviousSnapshot] = useState(true);
    const [firstIdSelectionMode, setFirstIdSelectionMode] = (0,react.useState)("latest");
    const dispatch = useRootDispatch();
    const trackLatestSidePanel = (0,react_redux/* useSelector */.d4)(getTrackLatestSidePanel);
    const trackPreviousSnapshot = (0,react_redux/* useSelector */.d4)(getTrackPreviousSnapshot);
    const jsonDataSidePanel = (0,react_redux/* useSelector */.d4)(getJsonDataSidePanel);
    const diffData = (0,react_redux/* useSelector */.d4)(getDiffData);
    const latestSnapshotId = (0,react_redux/* useSelector */.d4)(getLatestSnapshotId);
    const selectedSnapshotId = (0,react_redux/* useSelector */.d4)(getSelectedSnapshotId);
    const clickedForSnapshotSelection = (0,react_redux/* useSelector */.d4)(getClickedForSnapshotSelection);
    const firstId = (0,react_redux/* useSelector */.d4)(getFirstId);
    const secondId = (0,react_redux/* useSelector */.d4)(getSecondId);
    // const { selectedPageName } = useFlexLayoutContext();
    (0,react.useEffect)(() => {
        if (clickedForSnapshotSelection) {
            setFirstIdSelectionMode("selection");
            dispatch(setTrackLatestSidePanel(false));
            if (trackPreviousSnapshot) {
                dispatch(fetchOneSnapshot(Number(selectedSnapshotId), Number(selectedSnapshotId) - 1, false, true));
            }
            else {
                dispatch(fetchOneSnapshot(Number(selectedSnapshotId), Number(secondId), false, true));
            }
            dispatch(setClickedForSnapshotSelection(false));
        }
    }, [clickedForSnapshotSelection]);
    (0,react.useEffect)(() => {
        if (trackPreviousSnapshot) {
            dispatch(setSecondId((firstId && Number(firstId) - 1 >= 0 ? Number(firstId) - 1 : 0).toString()));
        }
    }, [firstId, trackPreviousSnapshot]);
    (0,react.useEffect)(() => {
        // if (selectedPageName === "data") {
        if (firstIdSelectionMode === "latest") {
            dispatch(setFirstId(latestSnapshotId?.toString() ?? "0"));
        }
        else if (firstIdSelectionMode === "selection") {
            dispatch(setFirstId(selectedSnapshotId?.toString() ?? "0"));
            if (latestSnapshotId && selectedSnapshotId && latestSnapshotId === selectedSnapshotId) {
                dispatch(setTrackLatestSidePanel(true));
            }
            else {
                dispatch(setTrackLatestSidePanel(false));
            }
            // setFirstIdSelectionMode("selection");
        }
        else if (firstIdSelectionMode === "input") {
            dispatch(setTrackLatestSidePanel(false));
            dispatch(setClickedForSnapshotSelection(false));
        }
        // }
    }, [firstIdSelectionMode, selectedSnapshotId, latestSnapshotId]);
    const onConfirm = (value, isFirstId) => {
        if (isFirstId) {
            dispatch(setFirstId(value));
        }
        else {
            dispatch(setSecondId(value));
        }
        dispatch(fetchOneSnapshot(Number(firstId), Number(secondId), false, true));
    };
    const onFocus = () => {
        setFirstIdSelectionMode("input");
    };
    const onToggleTrackLatest = () => {
        if (!trackLatestSidePanel) {
            setFirstIdSelectionMode("latest");
            dispatch(setClickedForSnapshotSelection(false));
            dispatch(fetchOneSnapshot(Number(latestSnapshotId), Number(latestSnapshotId) - 1, false, true));
        }
        else {
            setFirstIdSelectionMode("selection");
            if (trackPreviousSnapshot) {
                dispatch(fetchOneSnapshot(Number(selectedSnapshotId), Number(selectedSnapshotId) - 1, false, true));
            }
            else {
                dispatch(fetchOneSnapshot(Number(selectedSnapshotId), Number(secondId), false, true));
            }
        }
        dispatch(setTrackLatestSidePanel(!trackLatestSidePanel));
    };
    const onToggleTrackPrevious = () => {
        if (!trackPreviousSnapshot) {
            if (trackLatestSidePanel) {
                dispatch(fetchOneSnapshot(Number(latestSnapshotId), Number(latestSnapshotId) - 1, false, true));
            }
            else {
                dispatch(fetchOneSnapshot(Number(selectedSnapshotId), Number(selectedSnapshotId) - 1, false, true));
            }
        }
        else {
            dispatch(fetchOneSnapshot(Number(firstId), Number(secondId), false, true));
        }
        dispatch(setTrackPreviousSnapshot(!trackPreviousSnapshot));
    };
    return ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)(PanelHeader, { trackLatest: trackLatestSidePanel, onToggleTrackLatest: onToggleTrackLatest, onIdChange: (value) => dispatch(setFirstId(value)), idValue: firstId, onConfirm: onConfirm, onFocus: onFocus }), (0,jsx_runtime.jsx)("div", { className: QuamPanel_module.panelContent, children: jsonDataSidePanel && (0,jsx_runtime.jsx)(JSONEditor, { title: "", jsonDataProp: jsonDataSidePanel, height: "100%" }) }), (0,jsx_runtime.jsx)(PanelUpdates, { previousSnapshot: trackPreviousSnapshot, onTogglePrevious: onToggleTrackPrevious, onSecondIdChange: (value) => dispatch(setSecondId(value)), 
                // idValue={selectedSnapshotId && selectedSnapshotId - 1 > 0 ? selectedSnapshotId - 1 : 0}
                idValue: secondId, onConfirm: onConfirm }), (0,jsx_runtime.jsx)("div", { className: QuamPanel_module.panelContent, children: diffData && (0,jsx_runtime.jsx)(JSONEditor, { title: "", jsonDataProp: diffData, height: "94%" }) })] }));
};

;// ./src/modules/RightSidebar/RightSidePanel.tsx






const RightSidePanel = () => {
    const [isQuamOpen, setIsQuamOpen] = (0,react.useState)(false);
    const [isLogsOpen, setIsLogsOpen] = (0,react.useState)(false);
    const onQuamClick = () => {
        setIsQuamOpen(!isQuamOpen);
        setIsLogsOpen(false);
    };
    const onLogsClick = () => {
        setIsLogsOpen(!isLogsOpen);
        setIsQuamOpen(false);
    };
    return ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsxs)("div", { className: RightSidePanel_module.wrapper, children: [(0,jsx_runtime.jsx)("div", { className: classNames(RightSidePanel_module.tabContainer, isQuamOpen && RightSidePanel_module.tabContainerSelected), onClick: onQuamClick, children: (0,jsx_runtime.jsx)("span", { children: "QUAM" }) }), (0,jsx_runtime.jsx)("div", { className: classNames(RightSidePanel_module.tabContainer, isLogsOpen && RightSidePanel_module.tabContainerSelected), onClick: onLogsClick, children: (0,jsx_runtime.jsx)("span", { children: "LOGS" }) })] }), (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [isLogsOpen && ((0,jsx_runtime.jsx)("div", { className: RightSidePanel_module.sliderPanelWrapperLogger, children: (0,jsx_runtime.jsx)(LogsPanel, {}) })), isQuamOpen && ((0,jsx_runtime.jsx)("div", { className: RightSidePanel_module.sliderPanelWrapper, children: (0,jsx_runtime.jsx)(QuamPanel, {}) }))] })] }));
};

;// ./src/modules/RightSidebar/index.ts


;// ./src/modules/Nodes/NodesPage.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var NodesPage_module = ({"wrapper":"NodesPage-module__wrapper","nodesAndRunningJobInfoWrapper":"NodesPage-module__nodesAndRunningJobInfoWrapper","nodesContainerTop":"NodesPage-module__nodesContainerTop","nodesContainerDown":"NodesPage-module__nodesContainerDown","nodeResultWrapper":"NodesPage-module__nodeResultWrapper","nodeRunningJobInfoWrapper":"NodesPage-module__nodeRunningJobInfoWrapper","nodeElementListWrapper":"NodesPage-module__nodeElementListWrapper","listWrapper":"NodesPage-module__listWrapper","dot":"NodesPage-module__dot","loadingContainer":"NodesPage-module__loadingContainer","logsText":"NodesPage-module__logsText"});
;// ./src/modules/Nodes/components/NodeElement/NodeElement.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var NodeElement_module = ({"rowWrapper":"NodeElement-module__rowWrapper","nodeSelectedFinished":"NodeElement-module__nodeSelectedFinished","nodeSelectedRunning":"NodeElement-module__nodeSelectedRunning","nodeSelectedError":"NodeElement-module__nodeSelectedError","nodeSelectedPending":"NodeElement-module__nodeSelectedPending","row":"NodeElement-module__row","highlightRunningRow":"NodeElement-module__highlightRunningRow","dot":"NodeElement-module__dot","greyDot":"NodeElement-module__greyDot","redDot":"NodeElement-module__redDot","greenDot":"NodeElement-module__greenDot","runButton":"NodeElement-module__runButton","runButtonIcon":"NodeElement-module__runButtonIcon","runButtonText":"NodeElement-module__runButtonText","dotWrapper":"NodeElement-module__dotWrapper","titleOrNameWrapper":"NodeElement-module__titleOrNameWrapper","titleOrName":"NodeElement-module__titleOrName","descriptionTooltip":"NodeElement-module__descriptionTooltip","descriptionWrapper":"NodeElement-module__descriptionWrapper","description":"NodeElement-module__description","descriptionText":"NodeElement-module__descriptionText","updateAllButton":"NodeElement-module__updateAllButton"});
;// ./src/modules/Nodes/components/NodeElement/NodeElementStatusVisuals.tsx

/**
 * @fileoverview Visual status indicators for calibration node execution state.
 *
 * Renders status-specific UI elements: progress spinner for running nodes,
 * colored dots for completed/error/pending states.
 */

// eslint-disable-next-line css-modules/no-unused-class




/**
 * Render status indicator based on calibration execution state.
 *
 * Visual mapping:
 * - running: Circular progress spinner with percentage
 * - finished: Green dot
 * - error: Red dot
 * - pending: Grey dot (default)
 *
 * @param status - Execution status from WebSocket updates
 * @param percentage - Progress percentage (0-100) for running state
 */
const StatusVisuals = ({ status = "pending" }) => {
    const percentage = (0,react_redux/* useSelector */.d4)(getRunStatusNodePercentage);
    if (status === "running") {
        return (0,jsx_runtime.jsx)(Icons_CircularLoaderProgress, { percentage: Math.round(percentage ?? 0) });
    }
    else if (status === "finished") {
        return (0,jsx_runtime.jsx)("div", { className: `${NodeElement_module.dot} ${NodeElement_module.greenDot}` });
    }
    else if (status === "error") {
        return (0,jsx_runtime.jsx)("div", { className: `${NodeElement_module.dot} ${NodeElement_module.redDot}` });
    }
    return (0,jsx_runtime.jsx)("div", { className: `${NodeElement_module.dot} ${NodeElement_module.greyDot}` });
};

;// ./src/modules/Nodes/components/NodeElement/helpers.ts
/**
 * @fileoverview Styling helper for NodeElement based on execution status.
 *
 * Determines CSS classes for node rows to visually indicate selection state
 * and calibration execution status (pending, running, finished, error).
 */
// eslint-disable-next-line css-modules/no-unused-class

/**
 * Compute CSS class names for node row based on selection and execution status.
 *
 * Status precedence: running > error > finished > pending.
 * Applies different visual styles for each status to provide clear user feedback.
 *
 * @param nodeName - Name of this node
 * @param selectedItemName - Currently selected node in UI
 * @param runStatus - Current execution status from WebSocket (null if no active run)
 * @returns Space-separated CSS class names for styling
 */
const getNodeRowClass = ({ isSelected, isLastRun, runStatus, }) => {
    const nodeStatus = (isLastRun && runStatus) ? runStatus : "pending";
    // Visual priority: finished > error > running > pending
    if (isLastRun && nodeStatus === "finished") {
        return `${NodeElement_module.rowWrapper} ${NodeElement_module.nodeSelectedFinished}`;
    }
    else if (isLastRun && nodeStatus === "error") {
        return `${NodeElement_module.rowWrapper} ${NodeElement_module.nodeSelectedError}`;
    }
    else if (isLastRun && nodeStatus === "running") {
        return `${NodeElement_module.rowWrapper} ${NodeElement_module.nodeSelectedRunning} ${NodeElement_module.highlightRunningRow}`;
    }
    else if (isSelected && nodeStatus === "pending") {
        return `${NodeElement_module.rowWrapper} ${NodeElement_module.nodeSelectedPending}`;
    }
    return NodeElement_module.rowWrapper;
};

;// ./src/modules/Nodes/components/NodeElement/NodeElement.tsx

/**
 * @fileoverview Interactive quantum calibration node component with real-time execution status.
 *
 * Displays a single calibration node with parameter editing, execution controls, and
 * live status updates via WebSocket. Each node represents a quantum calibration procedure
 * (e.g., resonator_spectroscopy, qubit_spectroscopy) that can be executed with custom parameters.
 *
 * **Key Responsibilities**:
 * - Render node title, description, and status indicator
 * - Provide inline parameter editing for calibration inputs
 * - Handle node execution submission via API
 * - Display real-time progress updates from WebSocket
 * - Show validation errors from backend parameter validation
 *
 * **State Synchronization Flow**:
 * 1. User clicks Run button → handleClick() calls NodesApi.submitNodeParameters()
 * 2. Backend validates parameters and starts execution
 * 3. WebSocket pushes status updates every ~500ms to WebSocketContext
 * 4. NodesContext consumes runStatus and updates isNodeRunning
 * 5. Component reflects current status via StatusVisuals (green dot, red dot, progress spinner)
 *
 * **Integration Points**:
 * - NodesContext: Execution state, parameter updates, error handling
 * - SelectionContext: Tracks which node is currently selected in UI
 * - SnapshotsContext: Fetches calibration results after execution completes
 * - WebSocketContext: Real-time status updates (runStatus.node.status/percentage_complete)
 *
 * **FRAGILE: Error Handling**:
 * - No validation before submission - relies entirely on backend validation
 * - Parameter type coercion happens at submission time without user feedback
 * - API errors only shown after submission completes (no loading state error recovery)
 *
 * **FRAGILE: State Management**:
 * - No debouncing on parameter input changes
 *
 * @see NodesContext for execution state management
 * @see WebSocketContext for real-time status updates (WebSocketContext.tsx:265-269)
 * @see Parameters for the collapsible parameter editing UI
 */

// eslint-disable-next-line css-modules/no-unused-class











/**
 * Interactive calibration node component with real-time execution tracking.
 *
 * Renders a single quantum calibration node with parameter inputs, execution controls,
 * and live status visualization. Supports inline parameter editing and displays
 * real-time progress updates via WebSocket during calibration execution.
 *
 * @param nodeKey - Unique key for this node instance (used for React list rendering)
 * @param node - Node definition containing name, parameters, and metadata
 *
 * @remarks
 * **Rendering Behavior**:
 * - Selected node expands to show parameters and Run button
 * - Non-selected nodes show only title and status indicator
 * - Status indicators: grey dot (pending), green dot (finished), red dot (error), progress spinner (running)
 *
 * **WebSocket Status Updates**:
 * Real-time status updates flow from WebSocket → NodesContext → this component:
 * - runStatus.node.name matches this node → show current execution status
 * - runStatus.node.percentage_complete → drives progress spinner
 * - runStatus.is_running → show Run button or CircularProgress
 *
 * **FRAGILE: Multiple Context Dependencies**:
 * This component depends on 4 different contexts (NodesContext, SelectionContext,
 * SnapshotsContext, WebSocketContext), creating tight coupling and making testing difficult.
 *
 * @see NodesContext for execution state and parameter management
 * @see getNodeRowClass for dynamic styling based on execution status (helpers.ts)
 * @see StatusVisuals for status indicator rendering (NodeElementStatusVisuals.tsx)
 */
const NodeElement = ({ nodeKey }) => {
    const dispatch = useRootDispatch();
    const node = (0,react_redux/* useSelector */.d4)(state => getNode(state, nodeKey));
    const isNodeSelected = (0,react_redux/* useSelector */.d4)(state => getIsNodeSelected(state, nodeKey));
    const submitNodeResponseError = (0,react_redux/* useSelector */.d4)(getSubmitNodeResponseError);
    const runStatusIsRunning = (0,react_redux/* useSelector */.d4)(getRunStatusIsRunning);
    const isLastRunNode = (0,react_redux/* useSelector */.d4)(state => getIsLastRunNode(state, nodeKey));
    const runStatusNodeStatus = (0,react_redux/* useSelector */.d4)(getRunStatusNodeStatus);
    const [errors, setErrors] = (0,react.useState)(new Set());
    const handleSetError = (key, isValid) => {
        const newSet = new Set(errors);
        if (isValid)
            newSet.delete(key);
        else
            newSet.add(key);
        setErrors(newSet);
    };
    /**
     * Update a single parameter value in the node's parameter map.
     *
     * Modifies the parameter's default value while preserving other metadata
     * (title, type, description). Triggers a full NodesContext state update,
     * causing re-render of all consumers.
     */
    const updateParameter = (paramKey, newValue, isValid) => {
        handleSetError(paramKey, isValid);
        dispatch(actions_setNodeParameter({ nodeKey, paramKey, newValue }));
    };
    const renderInputElement = (key, parameter, node) => (0,jsx_runtime.jsx)(Parameters_ParameterSelector, { parameterKey: key, parameter: parameter, node: node, onChange: updateParameter });
    const handleClick = async () => dispatch(handleRunNode(node));
    /**
     * Insert spaces into long strings to enable line wrapping at fixed intervals.
     *
     * Prevents UI overflow when displaying long node names like "resonator_spectroscopy_with_flux_sweep"
     * without natural word breaks. Inserts a space every N characters to allow CSS word-wrap to break the line.
     */
    const insertSpaces = (str, interval = 40) => str.replace(new RegExp(`(.{${interval}})`, "g"), "$1 ").trim();
    return ((0,jsx_runtime.jsxs)("div", { 
        // Dynamic styling based on selection state and execution status
        // See helpers.ts:getNodeRowClass for styling logic
        className: getNodeRowClass({
            isSelected: isNodeSelected,
            isLastRun: isLastRunNode,
            runStatus: runStatusNodeStatus,
        }), "data-testid": `node-element-${nodeKey}`, onClick: () => {
            dispatch(setSelectedNode(node.name));
        }, children: [(0,jsx_runtime.jsxs)("div", { className: NodeElement_module.row, children: [(0,jsx_runtime.jsx)("div", { className: NodeElement_module.titleOrNameWrapper, children: (0,jsx_runtime.jsx)("div", { className: NodeElement_module.titleOrName, "data-testid": `title-or-name-${nodeKey}`, children: insertSpaces(node.title ?? node.name) }) }), (0,jsx_runtime.jsx)("div", { className: NodeElement_module.descriptionWrapper, children: node.description && ((0,jsx_runtime.jsx)(Tooltip/* default */.A, { title: (0,jsx_runtime.jsxs)("div", { className: NodeElement_module.descriptionTooltip, children: [node.description, " "] }), placement: "left-start", arrow: true, children: (0,jsx_runtime.jsx)("span", { children: (0,jsx_runtime.jsx)(InfoIcon, {}) }) })) }), (0,jsx_runtime.jsx)("div", { className: NodeElement_module.dotWrapper, "data-testid": `dot-wrapper-${nodeKey}`, children: (isLastRunNode || (isNodeSelected && runStatusNodeStatus !== "pending")) && ((0,jsx_runtime.jsx)(StatusVisuals, { status: isLastRunNode ? runStatusNodeStatus : "pending" })) }), !runStatusIsRunning && isNodeSelected && errors.size === 0 && ((0,jsx_runtime.jsxs)(Button_BlueButton, { className: NodeElement_module.runButton, "data-testid": "run-button", onClick: handleClick, children: [(0,jsx_runtime.jsx)(RunIcon, { className: NodeElement_module.runButtonIcon }), (0,jsx_runtime.jsx)("span", { className: NodeElement_module.runButtonText, children: "Run" })] })), runStatusIsRunning && isNodeSelected && (0,jsx_runtime.jsx)(CircularProgress/* default */.A, { size: 32 })] }), isNodeSelected && node.name === submitNodeResponseError?.nodeName && ((0,jsx_runtime.jsx)(ErrorResponseWrapper, { error: submitNodeResponseError })), Object.keys(node?.parameters ?? {}).length > 0 && ((0,jsx_runtime.jsx)(Parameters, { parametersExpanded: true, showTitle: true, show: isNodeSelected, currentItem: node, getInputElement: renderInputElement, "data-testid": `parameters-${nodeKey}` }, node.name))] }));
};

;// ./src/modules/Nodes/components/NodeElement/NodeElementList.tsx

/**
 * @fileoverview Container component rendering all available calibration nodes.
 *
 * Displays the complete list of quantum calibration nodes from the node library.
 * Shows a loading spinner during node library rescanning.
 */


// eslint-disable-next-line css-modules/no-unused-class




/**
 * Render list of all calibration nodes with loading state handling.
 *
 * Displays LoaderPage while rescanning the node library (triggered by
 * NodesApi.fetchAllNodes with rescan=true). Once loaded, renders each
 * node as an interactive NodeElement.
 */
const NodeElementList = () => {
    const allNodes = (0,react_redux/* useSelector */.d4)(getAllNodes, 
    // make sure that list rerenders only is map keys have changed
    { equalityFn: (prev, curr) => Object.keys(prev || {}).join() === Object.keys(curr || {}).join() });
    const isRescanningNodes = (0,react_redux/* useSelector */.d4)(getIsRescanningNodes);
    if (isRescanningNodes) {
        return (0,jsx_runtime.jsx)(LoaderPage, {});
    }
    return (allNodes && ((0,jsx_runtime.jsx)("div", { className: NodesPage_module.listWrapper, "data-testid": "node-list-wrapper", children: Object.keys(allNodes).map((key) => {
            return (0,jsx_runtime.jsx)(NodeElement, { nodeKey: key, "data-testid": `node-element-${key}` }, key);
        }) })));
};

;// ./src/modules/Nodes/components/RunningJob/RunningJob.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var RunningJob_module = ({"wrapper":"RunningJob-module__wrapper","title":"RunningJob-module__title","runningJobWrapper":"RunningJob-module__runningJobWrapper","runningJobNameWrapper":"RunningJob-module__runningJobNameWrapper","runningJobName":"RunningJob-module__runningJobName","greenDot":"RunningJob-module__greenDot","redDot":"RunningJob-module__redDot","greyDot":"RunningJob-module__greyDot","stopButtonContainer":"RunningJob-module__stopButtonContainer","stopButtonWrapper":"RunningJob-module__stopButtonWrapper","stopButton":"RunningJob-module__stopButton","parameterStatesWrapper":"RunningJob-module__parameterStatesWrapper","parameterColumnWrapper":"RunningJob-module__parameterColumnWrapper","statesColumnWrapper":"RunningJob-module__statesColumnWrapper","runInfoWrapper":"RunningJob-module__runInfoWrapper","runInfoColumn":"RunningJob-module__runInfoColumn","jobInfoKey":"RunningJob-module__jobInfoKey","jobInfoKeySecondColumn":"RunningJob-module__jobInfoKeySecondColumn","jobInfoValue":"RunningJob-module__jobInfoValue","jobInfoValueText":"RunningJob-module__jobInfoValueText","runInfoRow":"RunningJob-module__runInfoRow","parametersWrapper":"RunningJob-module__parametersWrapper","parameterTitleWrapper":"RunningJob-module__parameterTitleWrapper","parameterValues":"RunningJob-module__parameterValues","parameterLabel":"RunningJob-module__parameterLabel","parameterValue":"RunningJob-module__parameterValue","stateWrapper":"RunningJob-module__stateWrapper","stateTitle":"RunningJob-module__stateTitle","updateAllButton":"RunningJob-module__updateAllButton","stateUpdatesTopWrapper":"RunningJob-module__stateUpdatesTopWrapper","stateUpdateWrapper":"RunningJob-module__stateUpdateWrapper","stateUpdateOrderNumberAndTitleWrapper":"RunningJob-module__stateUpdateOrderNumberAndTitleWrapper","stateUpdateOrderNumber":"RunningJob-module__stateUpdateOrderNumber","stateUpdateOrderKey":"RunningJob-module__stateUpdateOrderKey","stateUpdateValueWrapper":"RunningJob-module__stateUpdateValueWrapper","stateUpdateValueOld":"RunningJob-module__stateUpdateValueOld","stateUpdateRightArrowIconWrapper":"RunningJob-module__stateUpdateRightArrowIconWrapper","stateUpdateUndoIconWrapper":"RunningJob-module__stateUpdateUndoIconWrapper","stateUpdateValueNew":"RunningJob-module__stateUpdateValueNew","valueContainer":"RunningJob-module__valueContainer","valueContainerEditable":"RunningJob-module__valueContainerEditable","valueContainerDisabled":"RunningJob-module__valueContainerDisabled","stateUpdateIconBeforeWrapper":"RunningJob-module__stateUpdateIconBeforeWrapper","stateUpdateIconAfterWrapper":"RunningJob-module__stateUpdateIconAfterWrapper","stateUpdateComponentTextWrapper":"RunningJob-module__stateUpdateComponentTextWrapper","stateUpdateKeyText":"RunningJob-module__stateUpdateKeyText","upArrowIconWrapper":"RunningJob-module__upArrowIconWrapper","stateUpdateValueText":"RunningJob-module__stateUpdateValueText","stateUpdateValueTextWrapper":"RunningJob-module__stateUpdateValueTextWrapper","editIconWrapper":"RunningJob-module__editIconWrapper","newValueOfState":"RunningJob-module__newValueOfState","jobInfoContainer":"RunningJob-module__jobInfoContainer","topRow":"RunningJob-module__topRow","leftStatus":"RunningJob-module__leftStatus","nodeText":"RunningJob-module__nodeText","nodeName":"RunningJob-module__nodeName","rightStatus":"RunningJob-module__rightStatus","percentage":"RunningJob-module__percentage","loadingBarWrapper":"RunningJob-module__loadingBarWrapper","finishedText":"RunningJob-module__finishedText","errorText":"RunningJob-module__errorText","bar_running":"RunningJob-module__bar_running","barRunning":"RunningJob-module__bar_running","bar_pending":"RunningJob-module__bar_pending","barPending":"RunningJob-module__bar_pending","bar_finished":"RunningJob-module__bar_finished","barFinished":"RunningJob-module__bar_finished","bar_error":"RunningJob-module__bar_error","barError":"RunningJob-module__bar_error"});
;// ./src/modules/Nodes/components/StateUpdates/ValueComponent.tsx


// eslint-disable-next-line css-modules/no-unused-class


const ValueComponent = ({ inputRef, defaultValue, disabled, onClick, onChange, }) => {
    const adjustWidth = (0,react.useCallback)(() => {
        if (inputRef?.current) {
            const value = defaultValue.toString() || "";
            const canvas = document.createElement("canvas");
            const context = canvas.getContext("2d");
            if (context) {
                context.font = getComputedStyle(inputRef.current).font;
                const textWidth = context.measureText(value).width;
                inputRef.current.style.width = `${Math.ceil(textWidth)}px`;
            }
        }
    }, [defaultValue]);
    (0,react.useEffect)(() => {
        adjustWidth();
    }, [defaultValue, adjustWidth]);
    if (!onClick) {
        return ((0,jsx_runtime.jsx)("div", { className: RunningJob_module.valueContainer, "data-testid": "value-container", children: defaultValue }));
    }
    return ((0,jsx_runtime.jsx)(jsx_runtime.Fragment, { children: (0,jsx_runtime.jsx)(Tooltip/* default */.A, { title: "Edit", children: (0,jsx_runtime.jsx)("input", { ref: inputRef, className: disabled ? RunningJob_module.valueContainerDisabled : RunningJob_module.valueContainerEditable, "data-testid": "value-input", disabled: disabled, onBlur: (e) => {
                    onChange && onChange(e);
                }, defaultValue: defaultValue }) }) }));
};

;// ./src/modules/Nodes/components/StateUpdates/ValueRow.tsx


// eslint-disable-next-line css-modules/no-unused-class


 // export const ValueRow = ({
const ValueRow = ({ oldValue, previousValue, customValue, setCustomValue, parameterUpdated, setParameterUpdated, }) => {
    const inputRef = (0,react.useRef)(null);
    const handleChange = (event) => {
        setCustomValue(event.target.value);
    };
    return ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)("div", { className: RunningJob_module.stateUpdateValueOld, children: (0,jsx_runtime.jsx)(ValueComponent, { defaultValue: oldValue }) }), (0,jsx_runtime.jsx)("div", { className: RunningJob_module.stateUpdateRightArrowIconWrapper, children: (0,jsx_runtime.jsx)(RightArrowIcon, {}) }), !parameterUpdated && ((0,jsx_runtime.jsxs)("div", { className: RunningJob_module.stateUpdateValueNew, children: [(0,jsx_runtime.jsx)(ValueComponent, { inputRef: inputRef, defaultValue: customValue, onClick: () => {
                            setParameterUpdated(true);
                        }, onChange: handleChange }), customValue !== previousValue && ((0,jsx_runtime.jsx)("div", { className: RunningJob_module.stateUpdateUndoIconWrapper, "data-testid": "undo-icon-wrapper", onClick: () => {
                            if (inputRef.current) {
                                inputRef.current.value = previousValue.toString();
                            }
                            setCustomValue(previousValue);
                        }, children: (0,jsx_runtime.jsx)(UndoIcon, {}) }))] })), parameterUpdated && ((0,jsx_runtime.jsx)("div", { className: RunningJob_module.stateUpdateValueNew, children: (0,jsx_runtime.jsx)(ValueComponent, { defaultValue: customValue, disabled: parameterUpdated }) }))] }));
};

;// ./src/modules/Nodes/components/StateUpdates/StateUpdateElement.tsx


// eslint-disable-next-line css-modules/no-unused-class








const StateUpdateElement = (props) => {
    const dispatch = useRootDispatch();
    const { stateKey, index, stateUpdateObject, runningNodeInfo, updateAllButtonPressed } = props;
    const [runningUpdate, setRunningUpdate] = react.useState(false);
    const [parameterUpdated, setParameterUpdated] = (0,react.useState)(false);
    const [customValue, setCustomValue] = (0,react.useState)(JSON.stringify(stateUpdateObject.val ?? stateUpdateObject.new ?? ""));
    const previousValue = JSON.stringify(stateUpdateObject.val ?? stateUpdateObject.new ?? "");
    const secondId = (0,react_redux/* useSelector */.d4)(getSecondId);
    const trackLatestSidePanel = (0,react_redux/* useSelector */.d4)(getTrackLatestSidePanel);
    const latestSnapshotId = (0,react_redux/* useSelector */.d4)(getLatestSnapshotId);
    const handleUpdateClick = async () => {
        if (runningNodeInfo && runningNodeInfo.idx && stateUpdateObject && ("val" in stateUpdateObject || "new" in stateUpdateObject)) {
            setRunningUpdate(true);
            const stateUpdateValue = customValue ? customValue : (stateUpdateObject.val ?? stateUpdateObject.new);
            const response = await SnapshotsApi.updateState(runningNodeInfo?.idx, stateKey, stateUpdateValue);
            const stateUpdate = { ...stateUpdateObject, stateUpdated: response.result };
            if (response.isOk && response.result && trackLatestSidePanel) {
                dispatch(fetchOneSnapshot(Number(latestSnapshotId), Number(secondId), false, true));
            }
            dispatch(setRunningNodeInfo({
                ...runningNodeInfo,
                state_updates: { ...runningNodeInfo.state_updates, [stateKey]: stateUpdate },
            }));
            setParameterUpdated(response.result);
            setRunningUpdate(false);
        }
    };
    return ((0,jsx_runtime.jsxs)("div", { className: RunningJob_module.stateUpdateWrapper, "data-testid": `state-update-wrapper-${stateKey}`, children: [(0,jsx_runtime.jsxs)("div", { className: RunningJob_module.stateUpdateOrderNumberAndTitleWrapper, children: [(0,jsx_runtime.jsx)("div", { className: RunningJob_module.stateUpdateOrderNumber, children: index + 1 }), (0,jsx_runtime.jsx)("div", { className: RunningJob_module.stateUpdateOrderKey, "data-testid": `state-update-key-${index}`, children: stateKey })] }), (0,jsx_runtime.jsxs)("div", { className: RunningJob_module.stateUpdateValueWrapper, "data-testid": `state-update-value-wrapper-${index}`, children: [(0,jsx_runtime.jsx)(ValueRow, { oldValue: JSON.stringify(stateUpdateObject.old), previousValue: previousValue, customValue: customValue, setCustomValue: setCustomValue, parameterUpdated: parameterUpdated || updateAllButtonPressed, setParameterUpdated: setParameterUpdated }), !runningUpdate && !parameterUpdated && !updateAllButtonPressed && ((0,jsx_runtime.jsx)("div", { className: RunningJob_module.stateUpdateIconBeforeWrapper, "data-testid": "update-before-icon", onClick: handleUpdateClick, children: (0,jsx_runtime.jsx)(CheckMarkBeforeIcon, {}) })), runningUpdate && !parameterUpdated && ((0,jsx_runtime.jsx)("div", { className: RunningJob_module.stateUpdateIconAfterWrapper, "data-testid": "update-in-progress", children: (0,jsx_runtime.jsx)(CircularProgress/* default */.A, { size: 17 }) })), (parameterUpdated || updateAllButtonPressed) && ((0,jsx_runtime.jsx)("div", { className: RunningJob_module.stateUpdateIconAfterWrapper, "data-testid": "update-after-icon", children: (0,jsx_runtime.jsx)(CheckMarkAfterIcon, {}) }))] })] }, `${stateKey}-wrapper`));
};

;// ./src/modules/Nodes/components/StateUpdates/StateUpdates.tsx



// eslint-disable-next-line css-modules/no-unused-class



// import { ErrorStatusWrapper } from "../../../common/Error/ErrorStatusWrapper";



const StateUpdates = () => {
    const dispatch = useRootDispatch();
    const trackLatestSidePanel = (0,react_redux/* useSelector */.d4)(getTrackLatestSidePanel);
    const latestSnapshotId = (0,react_redux/* useSelector */.d4)(getLatestSnapshotId);
    const secondId = (0,react_redux/* useSelector */.d4)(getSecondId);
    const runningNodeInfo = (0,react_redux/* useSelector */.d4)(getRunningNodeInfo);
    const updateAllButtonPressed = (0,react_redux/* useSelector */.d4)(getUpdateAllButtonPressed);
    const handleClick = async (stateUpdates) => {
        const litOfUpdates = Object.entries(stateUpdates ?? {})
            .filter(([, stateUpdateObject]) => !stateUpdateObject.stateUpdated)
            .map(([key, stateUpdateObject]) => {
            return {
                data_path: key,
                value: stateUpdateObject.val ?? stateUpdateObject.new,
            };
        });
        const result = await SnapshotsApi.updateStates(runningNodeInfo?.idx ?? "", litOfUpdates);
        if (result.isOk) {
            dispatch(setUpdateAllButtonPressed(result.result));
            if (result.result && trackLatestSidePanel) {
                dispatch(fetchOneSnapshot(Number(latestSnapshotId), Number(secondId), false, true));
            }
        }
    };
    return ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsxs)("div", { className: RunningJob_module.stateWrapper, "data-testid": "state-wrapper", children: [(0,jsx_runtime.jsxs)("div", { className: RunningJob_module.stateTitle, "data-testid": "state-title", children: ["State updates\u00A0", runningNodeInfo?.state_updates && Object.keys(runningNodeInfo?.state_updates).length > 0
                                ? `(${Object.keys(runningNodeInfo?.state_updates).length})`
                                : ""] }), updateAllButtonPressed ||
                        (Object.entries(runningNodeInfo?.state_updates ?? {}).filter(([, stateUpdateObject]) => !stateUpdateObject.stateUpdated).length >
                            0 && ((0,jsx_runtime.jsx)(Button/* default */.A, { className: RunningJob_module.updateAllButton, "data-testid": "update-all-button", disabled: updateAllButtonPressed, onClick: () => handleClick(runningNodeInfo?.state_updates ?? {}), children: "Accept All" })))] }), runningNodeInfo?.state_updates && ((0,jsx_runtime.jsx)("div", { className: RunningJob_module.stateUpdatesTopWrapper, "data-testid": "state-updates-top-wrapper", children: Object.entries(runningNodeInfo?.state_updates ?? {}).map(([key, stateUpdateObject], index) => ((0,jsx_runtime.jsx)(StateUpdateElement, { stateKey: key, index: index, stateUpdateObject: stateUpdateObject, runningNodeInfo: runningNodeInfo, updateAllButtonPressed: updateAllButtonPressed }, key))) }))] }));
};

;// ./src/modules/Nodes/components/RunningJob/RunningJobStatusLabel.tsx


// eslint-disable-next-line css-modules/no-unused-class


const RunningJobStatusLabel = ({ status, percentage = 0, onStop }) => {
    if (status === "finished") {
        return ((0,jsx_runtime.jsxs)("div", { className: RunningJob_module.finishedText, children: ["Finished ", (0,jsx_runtime.jsx)(Icons_CheckmarkIcon, { height: 30, width: 30 }), " "] }));
    }
    else if (status === "error") {
        return ((0,jsx_runtime.jsxs)("div", { className: RunningJob_module.errorText, children: ["Error ", (0,jsx_runtime.jsx)(Icons_ErrorIcon, { height: 22, width: 22 }), " "] }));
    }
    else if (status === "running") {
        return ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsxs)("div", { className: RunningJob_module.percentage, children: [Math.round(percentage), "%"] }), (0,jsx_runtime.jsxs)("button", { className: RunningJob_module.stopButton, onClick: onStop, title: "Stop Node", children: [" ", (0,jsx_runtime.jsx)(StopIcon, {}), " "] })] }));
    }
    return null;
};

;// ./src/modules/Nodes/components/RunningJob/RunningJobStatusVisuals.tsx


// eslint-disable-next-line css-modules/no-unused-class


const RunningJobStatusVisuals = ({ status = "pending", percentage }) => {
    if (status === "running") {
        return (0,jsx_runtime.jsx)(Icons_CircularLoaderProgress, { percentage: percentage });
    }
    else if (status === "finished") {
        return (0,jsx_runtime.jsx)("div", { className: RunningJob_module.greenDot });
    }
    else if (status === "error") {
        return (0,jsx_runtime.jsx)("div", { className: RunningJob_module.redDot });
    }
    return (0,jsx_runtime.jsx)("div", { className: RunningJob_module.greyDot });
};

;// ./src/modules/Nodes/components/RunningJob/RunningJobNodeProgressTracker.tsx



// eslint-disable-next-line css-modules/no-unused-class








const RunningJobNodeProgressTracker = () => {
    const dispatch = useRootDispatch();
    const runNodeName = (0,react_redux/* useSelector */.d4)(getRunStatusNodeName);
    const runNodeStatus = (0,react_redux/* useSelector */.d4)(getRunStatusNodeStatus);
    const runNodePercentage = (0,react_redux/* useSelector */.d4)(getRunStatusNodePercentage);
    const handleStopClick = async () => {
        const res = await SnapshotsApi.stopNodeRunning();
        if (res.isOk && res.result) {
            dispatch(setIsNodeRunning(false));
        }
    };
    return ((0,jsx_runtime.jsxs)("div", { className: RunningJob_module.jobInfoContainer, children: [(0,jsx_runtime.jsxs)("div", { className: RunningJob_module.topRow, children: [(0,jsx_runtime.jsxs)("div", { className: RunningJob_module.leftStatus, children: [(0,jsx_runtime.jsx)(RunningJobStatusVisuals, { status: runNodeStatus, percentage: Math.round(runNodePercentage ?? 0) }), (0,jsx_runtime.jsxs)("div", { className: RunningJob_module.nodeText, children: ["Node: ", (0,jsx_runtime.jsx)("span", { className: RunningJob_module.nodeName, children: runNodeName || "Unnamed" })] })] }), (0,jsx_runtime.jsx)("div", { className: RunningJob_module.rightStatus, children: (0,jsx_runtime.jsx)(RunningJobStatusLabel, { status: runNodeStatus, percentage: runNodePercentage, onStop: handleStopClick }) })] }), (0,jsx_runtime.jsx)("div", { className: `${RunningJob_module.loadingBarWrapper} ${RunningJob_module[`bar_${runNodeStatus}`]}`, children: (0,jsx_runtime.jsx)(CircularLoadingBar_CircularLoadingBar, { percentage: Math.round(runNodePercentage ?? 0) }) })] }));
};

;// ./src/modules/Nodes/components/RunningJob/RunningJobParameters.tsx


// eslint-disable-next-line css-modules/no-unused-class



const RunningJobParameters = () => {
    const runningNode = (0,react_redux/* useSelector */.d4)(getRunningNode);
    return ((0,jsx_runtime.jsx)("div", { className: RunningJob_module.parametersWrapper, "data-testid": "parameters-wrapper", children: (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)("div", { className: RunningJob_module.parameterTitleWrapper, "data-testid": "parameter-title", children: "Parameters" }), (0,jsx_runtime.jsx)("div", { "data-testid": "parameters-list", children: 
                    // expanded &&
                    Object.entries(runningNode?.parameters ?? {}).map(([key, parameter]) => ((0,jsx_runtime.jsxs)("div", { className: RunningJob_module.parameterValues, "data-testid": `parameter-item-${key}`, children: [(0,jsx_runtime.jsxs)("div", { className: RunningJob_module.parameterLabel, "data-testid": `parameter-label-${key}`, children: [parameter.title, ":"] }), (0,jsx_runtime.jsx)("div", { className: RunningJob_module.parameterValue, "data-testid": `parameter-value-${key}`, children: parameter.value?.toString() })] }, key))) })] }) }));
};

;// ./src/modules/Nodes/components/RunningJob/RunningJob.tsx



// eslint-disable-next-line css-modules/no-unused-class





const RunningJob = () => {
    const runNodeStatus = (0,react_redux/* useSelector */.d4)(getRunStatusNodeStatus);
    return ((0,jsx_runtime.jsxs)("div", { className: RunningJob_module.wrapper, "data-testid": "running-job-wrapper", children: [runNodeStatus !== undefined && (0,jsx_runtime.jsx)(RunningJobNodeProgressTracker, {}), (0,jsx_runtime.jsxs)("div", { className: RunningJob_module.parameterStatesWrapper, children: [(0,jsx_runtime.jsx)("div", { className: RunningJob_module.parameterColumnWrapper, children: (0,jsx_runtime.jsx)(RunningJobParameters, {}) }), (0,jsx_runtime.jsx)("div", { className: RunningJob_module.statesColumnWrapper, "data-testid": "states-column-wrapper", children: (0,jsx_runtime.jsx)(StateUpdates, {}) })] })] }));
};

;// ./src/modules/Nodes/Nodes.tsx


// eslint-disable-next-line css-modules/no-unused-class








const NodesPage = () => {
    const isRescanningNodes = (0,react_redux/* useSelector */.d4)(getIsRescanningNodes);
    const results = (0,react_redux/* useSelector */.d4)(getResults);
    const runResultError = (0,react_redux/* useSelector */.d4)(getRunResultNodeError);
    return ((0,jsx_runtime.jsx)("div", { className: NodesPage_module.wrapper, "data-testid": "nodes-page-wrapper", children: (0,jsx_runtime.jsxs)("div", { className: NodesPage_module.nodesAndRunningJobInfoWrapper, "data-testid": "nodes-and-job-wrapper", children: [(0,jsx_runtime.jsx)("div", { className: NodesPage_module.nodesContainerTop, children: (0,jsx_runtime.jsxs)("div", { className: NodesPage_module.nodeElementListWrapper, children: [isRescanningNodes && ((0,jsx_runtime.jsxs)("div", { className: NodesPage_module.loadingContainer, children: [(0,jsx_runtime.jsx)(CircularProgress/* default */.A, { size: 32 }), "Node library scan in progress", (0,jsx_runtime.jsxs)("div", { children: ["See ", (0,jsx_runtime.jsx)("span", { className: NodesPage_module.logsText, children: "LOGS" }), " for details (bottomright)", " "] })] })), !isRescanningNodes && (0,jsx_runtime.jsx)(NodeElementList, {})] }) }), (0,jsx_runtime.jsxs)("div", { className: NodesPage_module.nodesContainerDown, children: [(0,jsx_runtime.jsx)("div", { className: NodesPage_module.nodeRunningJobInfoWrapper, children: (0,jsx_runtime.jsx)(RunningJob, {}) }), (0,jsx_runtime.jsx)(Results, { jsonObject: results ?? {}, showSearch: false, toggleSwitch: true, errorObject: runResultError })] })] }) }));
};
/* harmony default export */ var Nodes = (NodesPage);

;// ./src/modules/Nodes/index.ts


;// ./src/modules/GraphLibrary/GraphLibrary.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var GraphLibrary_module = ({"wrapper":"GraphLibrary-module__wrapper","nodesContainer":"GraphLibrary-module__nodesContainer","refreshButtonWrapper":"GraphLibrary-module__refreshButtonWrapper","searchAndRefresh":"GraphLibrary-module__searchAndRefresh","buttonWrapper":"GraphLibrary-module__buttonWrapper","listWrapper":"GraphLibrary-module__listWrapper","loadingContainer":"GraphLibrary-module__loadingContainer","logsText":"GraphLibrary-module__logsText"});
;// ./src/modules/GraphLibrary/components/GraphElement/GraphElement.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var GraphElement_module = ({"wrapper":"GraphElement-module__wrapper","upperContainer":"GraphElement-module__upperContainer","bottomContainer":"GraphElement-module__bottomContainer","parametersContainer":"GraphElement-module__parametersContainer","graphContainer":"GraphElement-module__graphContainer","graphContainerVisible":"GraphElement-module__graphContainerVisible","leftContainer":"GraphElement-module__leftContainer","rightContainer":"GraphElement-module__rightContainer","runButtonWrapper":"GraphElement-module__runButtonWrapper","refreshButtonWrapper":"GraphElement-module__refreshButtonWrapper","calibrationGraphSelected":"GraphElement-module__calibrationGraphSelected"});
// EXTERNAL MODULE: ./node_modules/@xyflow/system/dist/esm/index.js + 109 modules
var esm = __webpack_require__(5154);
// EXTERNAL MODULE: ./node_modules/@xyflow/react/dist/esm/index.js + 3 modules
var dist_esm = __webpack_require__(6770);
;// ./src/modules/Graph/components/DefaultNode/DefaultNode.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var DefaultNode_module = ({"defaultNode":"DefaultNode-module__defaultNode","defaultNodeLabel":"DefaultNode-module__defaultNodeLabel","defaultNodeHandle":"DefaultNode-module__defaultNodeHandle","selected":"DefaultNode-module__selected","subgraph":"DefaultNode-module__subgraph"});
;// ./src/modules/Graph/components/DefaultNode/DefaultNode.tsx





const DefaultNode = (props) => {
    return ((0,jsx_runtime.jsxs)("div", { className: classNames(DefaultNode_module.defaultNode, props.selected && DefaultNode_module.selected, !!props.data.subgraph && DefaultNode_module.subgraph), "data-id": props.data.label, children: [(0,jsx_runtime.jsx)("label", { className: DefaultNode_module.defaultNodeLabel, children: props.data.label }), (0,jsx_runtime.jsx)(dist_esm/* Handle */.h7, { className: DefaultNode_module.defaultNodeHandle, type: "target", position: esm/* Position */.yX.Left }), (0,jsx_runtime.jsx)(dist_esm/* Handle */.h7, { className: DefaultNode_module.defaultNodeHandle, type: "source", position: esm/* Position */.yX.Right })] }));
};
/* harmony default export */ var DefaultNode_DefaultNode = (DefaultNode);

;// ./src/modules/Graph/components/LoopingEdge/LoopingEdge.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var LoopingEdge_module = ({"loopLabel":"LoopingEdge-module__loopLabel","iterations":"LoopingEdge-module__iterations"});
;// ./src/modules/Graph/components/LoopingEdge/LoopingEdge.tsx




const edgeColor = "#70767d";
const loopingEdgeOptions = {
    markerEnd: {
        type: esm/* MarkerType */.TG.ArrowClosed,
        width: 60,
        height: 8,
        color: edgeColor,
    },
    style: {
        strokeWidth: 2,
        stroke: edgeColor,
    },
};
const getLabelsFromData = (edgeData) => {
    const hasCondition = Boolean(edgeData?.loop?.content);
    const hasMax = edgeData?.loop?.max_iterations !== undefined && edgeData?.loop?.max_iterations !== null;
    const label = edgeData?.loop?.label;
    const firstLabel = label ?? (hasCondition ? "condition" : undefined);
    const secondLabel = hasMax ? `max ${edgeData?.loop?.max_iterations}` : undefined;
    // case: only max_iterations (5x)
    if (!hasCondition && !label && hasMax) {
        return { firstLabel: undefined, secondLabel: `${edgeData?.loop?.max_iterations}` };
    }
    return { firstLabel, secondLabel };
};
const LoopingEdge = (props) => {
    if (props.source !== props.target) {
        return (0,jsx_runtime.jsx)(dist_esm/* BezierEdge */.xX, { ...props });
    }
    const { sourceX, sourceY, targetX, targetY, id, data, markerEnd, style } = props;
    const radiusX = (sourceX - targetX) * 0.6;
    const radiusY = 30;
    const edgePath = `M ${sourceX} ${sourceY} A ${radiusX} ${radiusY} 0 1 0 ${targetX} ${targetY}`;
    const { firstLabel, secondLabel } = getLabelsFromData(data);
    const leftLabel = firstLabel ? `${firstLabel}` : undefined;
    const rightLabel = secondLabel ? `${secondLabel}` : undefined;
    return ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)(dist_esm/* BaseEdge */.tE, { id: id, path: edgePath, markerEnd: markerEnd, style: style }), (0,jsx_runtime.jsx)(dist_esm/* EdgeLabelRenderer */.rV, { children: (0,jsx_runtime.jsxs)("div", { className: LoopingEdge_module.loopLabel, style: { transform: `translate(-60%, -20%) translate(${sourceX - radiusX / 2}px, ${sourceY - radiusY * 2}px)` }, children: [leftLabel, leftLabel && rightLabel && (0,jsx_runtime.jsxs)("span", { className: LoopingEdge_module.iterations, children: [rightLabel, "\u00D7"] }), !leftLabel && rightLabel && (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [rightLabel, "\u00D7"] })] }) })] }));
};
/* harmony default export */ var LoopingEdge_LoopingEdge = (LoopingEdge);

;// ./src/modules/Graph/components/ConditionalEdge/ConditionalEdge.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var ConditionalEdge_module = ({"conditionLabel":"ConditionalEdge-module__conditionLabel"});
;// ./src/modules/Graph/components/ConditionalEdge/ConditionalEdge.tsx




const ConditionalEdge = (props) => {
    const { id, data, sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition, markerEnd, style } = props;
    const [edgePath, labelX, labelY] = (0,esm/* getBezierPath */.Fp)({
        sourceX,
        sourceY,
        targetX,
        targetY,
        sourcePosition,
        targetPosition,
    });
    return ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)(dist_esm/* BaseEdge */.tE, { id: id, path: edgePath, markerEnd: markerEnd, style: style }), (0,jsx_runtime.jsx)(dist_esm/* EdgeLabelRenderer */.rV, { children: (0,jsx_runtime.jsx)("div", { "data-testid": `conditional-edge-${data?.condition?.label ?? "condition"}`, className: ConditionalEdge_module.conditionLabel, style: {
                        transform: `translate(-50%, -50%) translate(${labelX}px, ${labelY}px)`,
                    }, children: data?.condition?.label ?? "Condition" }) })] }));
};
/* harmony default export */ var ConditionalEdge_ConditionalEdge = (react.memo(ConditionalEdge));

;// ./src/modules/Graph/components/index.ts




const DEFAULT_NODE_TYPE = "DefaultNode";
const LOOPING_EDGE_TYPE = "LoopingNode";
const CONDITIONAL_EDGE_TYPE = "ConditionalEdge";
const components_edgeColor = "#40464d";
const edgeOptions = {
    markerEnd: {
        type: esm/* MarkerType */.TG.ArrowClosed,
        width: 60,
        height: 8,
        color: components_edgeColor,
    },
    style: {
        strokeWidth: 2,
        stroke: components_edgeColor,
    },
    selectable: false,
};
/* harmony default export */ var components = ({
    nodeTypes: {
        [DEFAULT_NODE_TYPE]: DefaultNode_DefaultNode,
    },
    edgeTypes: {
        [LOOPING_EDGE_TYPE]: LoopingEdge_LoopingEdge,
        [CONDITIONAL_EDGE_TYPE]: ConditionalEdge_ConditionalEdge,
    },
});

;// ./src/modules/Graph/Graph.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var Graph_module = ({"wrapper":"Graph-module__wrapper"});
// EXTERNAL MODULE: ./node_modules/@xyflow/react/dist/style.css
var style = __webpack_require__(2514);
// EXTERNAL MODULE: ./node_modules/elkjs/lib/elk.bundled.js
var elk_bundled = __webpack_require__(2954);
var elk_bundled_default = /*#__PURE__*/__webpack_require__.n(elk_bundled);
;// ./src/modules/Graph/utils.ts


const elk = new (elk_bundled_default())();
const spacingBetweenLayers = "100";
const spacingBetweenNodes = "80";
const layoutOptions = {
    "elk.algorithm": "layered",
    "elk.layered.spacing.nodeNodeBetweenLayers": spacingBetweenLayers,
    "elk.spacing.nodeNode": spacingBetweenNodes,
    "elk.direction": "RIGHT",
    "elk.layered.wrapping.strategy": "SINGLE_EDGE",
};
const getLayoutedElements = ({ nodes = [], edges = [] }) => {
    const loopingEdges = [];
    const children = nodes.map((node) => ({
        ...node,
        id: node.name,
        targetPosition: "left",
        sourcePosition: "right",
        // Hardcode a width and height for elk to use when layouting.
        width: 70,
        height: 70,
    }));
    const graph = {
        id: "root",
        layoutOptions,
        children,
        edges: [...edges, ...loopingEdges].map((edge) => {
            const loopEdgeType = (edge.data && "loop" in edge.data) ? LOOPING_EDGE_TYPE : undefined;
            const conditionalEdgeType = edge.data?.condition?.label ? CONDITIONAL_EDGE_TYPE : undefined;
            const typeOfAnEdge = loopEdgeType ?? conditionalEdgeType ?? undefined;
            return {
                ...edge,
                id: String(edge.id),
                source: String(edge.source),
                target: String(edge.target),
                sources: [String(edge.source)],
                targets: [String(edge.target)],
                type: typeOfAnEdge,
            };
        }),
    };
    return elk
        .layout(graph)
        .then((layoutedGraph) => ({
        nodes: layoutedGraph.children?.map((node) => ({
            ...node,
            type: DEFAULT_NODE_TYPE,
            // React Flow expects a position property on the node instead of `x` and `y` fields.
            position: { x: node.x, y: node.y },
        })) || [],
        edges: layoutedGraph.edges,
    }))
        .catch(console.error);
};

;// ./src/modules/Graph/hooks.ts





const DEFAULT_COLOR = "#40464d";
const LIGHT_GREAY = "#70767d";
const GREEN = "#4caf50";
const RED = "#f44336";
const useGraphData = (selectedWorkflowName, subgraphBreadcrumbs) => {
    const unformattedWorkflowElements = (0,react.useRef)(undefined);
    const [nodes, setNodes] = (0,react.useState)([]);
    const [edges, setEdges] = (0,react.useState)([]);
    const [shouldResetView, setShouldResetView] = (0,react.useState)(true);
    (0,react.useEffect)(() => {
        const fetchWorkflowGraph = async (workflowName) => {
            try {
                const response = await GraphLibraryApi.fetchGraph(workflowName);
                if (response.isOk && response.result) {
                    unformattedWorkflowElements.current = response.result;
                    // Uncomment to use mocks
                    // unformattedWorkflowElements.current = MOCK_WORKFLOW_ELEMENTS;
                    if (subgraphBreadcrumbs?.length !== 0) {
                        setSubgraph();
                    }
                    else {
                        layoutAndSetNodesAndEdges(response.result);
                        // Uncomment to use mocks
                        // layoutAndSetNodesAndEdges(MOCK_WORKFLOW_ELEMENTS);
                    }
                }
                else if (response.error) {
                    console.log(response.error);
                }
            }
            catch (error) {
                console.log(error);
            }
        };
        if (selectedWorkflowName)
            fetchWorkflowGraph(selectedWorkflowName);
    }, [selectedWorkflowName]);
    const resetWorkflowGraphElements = () => {
        unformattedWorkflowElements.current = undefined;
        setNodes([]);
        setEdges([]);
    };
    const layoutAndSetNodesAndEdges = (data) => getLayoutedElements(data).then((res) => {
        if (res) {
            setNodes(res.nodes);
            setEdges(res.edges.map((edge) => {
                let color = DEFAULT_COLOR;
                if (edge.type === LOOPING_EDGE_TYPE) {
                    color = LIGHT_GREAY;
                }
                else {
                    if (edge.data?.connect_on === true) {
                        color = GREEN;
                    }
                    else if (edge.data?.connect_on === false) {
                        color = RED;
                    }
                }
                return {
                    ...edge,
                    style: {
                        strokeWidth: 2,
                        stroke: color,
                    },
                    markerEnd: {
                        type: esm/* MarkerType */.TG.ArrowClosed,
                        width: 60,
                        height: 8,
                        color,
                    },
                };
            }));
            setShouldResetView(true);
        }
    });
    (0,react.useEffect)(() => {
        setSubgraph();
        setShouldResetView(true);
    }, [subgraphBreadcrumbs]);
    const setSubgraph = (0,react.useCallback)(() => {
        if (!unformattedWorkflowElements.current) {
            resetWorkflowGraphElements();
            return;
        }
        const graph = (subgraphBreadcrumbs || []).reduce((currentGraph, key) => {
            const node = currentGraph.nodes.find((n) => n.data.label === key);
            return node?.data.subgraph ?? currentGraph;
        }, unformattedWorkflowElements.current);
        layoutAndSetNodesAndEdges(graph);
    }, [unformattedWorkflowElements, subgraphBreadcrumbs]);
    const selectNode = (0,react.useCallback)((selectedNode) => {
        setNodes(nodes.map((node) => ({
            ...node,
            selected: selectedNode === node.data.label,
        })));
    }, [nodes]);
    return {
        nodes,
        edges,
        setNodes,
        setEdges,
        shouldResetView,
        setShouldResetView,
        selectNode,
    };
};
/* harmony default export */ var hooks = (useGraphData);

;// ./src/modules/Graph/components/EdgePopup/EdgePopUp.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var EdgePopUp_module = ({"conditionModalWrapper":"EdgePopUp-module__conditionModalWrapper","conditionModalContent":"EdgePopUp-module__conditionModalContent","conditionModalHeader":"EdgePopUp-module__conditionModalHeader","conditionModalTitle":"EdgePopUp-module__conditionModalTitle","conditionNodeVisual":"EdgePopUp-module__conditionNodeVisual","conditionModalGraphWrapper":"EdgePopUp-module__conditionModalGraphWrapper","conditionNodeCircle":"EdgePopUp-module__conditionNodeCircle","conditionNodeLabel":"EdgePopUp-module__conditionNodeLabel","conditionNodeArrow":"EdgePopUp-module__conditionNodeArrow","conditionModalClose":"EdgePopUp-module__conditionModalClose","conditionModalBody":"EdgePopUp-module__conditionModalBody","conditionModalInputGroup":"EdgePopUp-module__conditionModalInputGroup","conditionModalInputLabel":"EdgePopUp-module__conditionModalInputLabel","conditionModalInputTextarea":"EdgePopUp-module__conditionModalInputTextarea","conditionModalInputTextareaLogic":"EdgePopUp-module__conditionModalInputTextareaLogic"});
;// ./src/modules/Graph/components/EdgePopup/EdgePopUp.tsx




const EdgePopUp = (props) => {
    const { source, target, open, info: { label, content } = {}, onClose } = props;
    return ((0,jsx_runtime.jsx)(Dialog/* default */.A, { classes: { paper: EdgePopUp_module.conditionModalWrapper }, "data-test-id": true, open: open, onClose: onClose, children: (0,jsx_runtime.jsxs)("div", { "data-testid": "conditional-edge-pop-up-content", className: EdgePopUp_module.conditionModalContent, children: [(0,jsx_runtime.jsxs)("div", { className: EdgePopUp_module.conditionModalHeader, children: [(0,jsx_runtime.jsxs)("div", { children: [(0,jsx_runtime.jsx)("div", { className: EdgePopUp_module.conditionModalTitle, children: "Condition details" }), (0,jsx_runtime.jsxs)("div", { className: EdgePopUp_module.conditionNodeVisual, id: "conditionNodeVisual", children: [(0,jsx_runtime.jsxs)("div", { className: EdgePopUp_module.conditionModalGraphWrapper, children: [(0,jsx_runtime.jsx)("div", { className: EdgePopUp_module.conditionNodeCircle }), (0,jsx_runtime.jsx)("div", { className: EdgePopUp_module.conditionNodeLabel, children: source })] }), (0,jsx_runtime.jsx)("div", { className: EdgePopUp_module.conditionNodeArrow, children: "\u2192" }), (0,jsx_runtime.jsxs)("div", { className: EdgePopUp_module.conditionModalGraphWrapper, children: [(0,jsx_runtime.jsx)("div", { className: EdgePopUp_module.conditionNodeCircle }), (0,jsx_runtime.jsx)("div", { className: EdgePopUp_module.conditionNodeLabel, children: target })] })] })] }), (0,jsx_runtime.jsx)("button", { className: EdgePopUp_module.conditionModalClose, onClick: onClose, children: "\u00D7" })] }), (0,jsx_runtime.jsxs)("div", { className: EdgePopUp_module.conditionModalBody, children: [(0,jsx_runtime.jsxs)("div", { className: EdgePopUp_module.conditionModalInputGroup, children: [(0,jsx_runtime.jsx)("label", { className: EdgePopUp_module.conditionModalInputLabel, children: "Condition Label" }), (0,jsx_runtime.jsx)("textarea", { readOnly: true, className: EdgePopUp_module.conditionModalInputTextarea, id: "conditionTextarea", placeholder: "Enter condition label...", defaultValue: label })] }), (0,jsx_runtime.jsxs)("div", { className: EdgePopUp_module.conditionModalInputGroup, children: [(0,jsx_runtime.jsx)("label", { className: EdgePopUp_module.conditionModalInputLabel, children: "Logic" }), (0,jsx_runtime.jsx)("textarea", { readOnly: true, className: EdgePopUp_module.conditionModalInputTextareaLogic, id: "conditionLogicTextarea", placeholder: "Enter condition label...", defaultValue: content })] })] })] }) }));
};
/* harmony default export */ var EdgePopup_EdgePopUp = (EdgePopUp);

;// ./src/modules/Graph/Graph.tsx

/**
 * @fileoverview Interactive graph visualization component using ReactFlow.
 *
 * Renders calibration workflow graphs with node selection, auto-layout, and
 * real-time status updates.
 *
 * @see GraphCommonStore - Manages graph and node selection state
 * @see GraphElement - Uses this for workflow preview
 * @see MeasurementElementGraph - Uses this for execution status visualization
 */







const backgroundColor = "#0d1117";
const Graph = ({ onNodeClick, selectedWorkflowName, subgraphBreadcrumbs, onNodeSecondClick, selectedNodeNameInWorkflow }) => {
    const { nodes, edges, setNodes, setEdges, shouldResetView, setShouldResetView, selectNode } = hooks(selectedWorkflowName, subgraphBreadcrumbs);
    const { fitView } = (0,dist_esm/* useReactFlow */.VH)();
    const [selectedEdge, setSelectedEdge] = (0,react.useState)(null);
    const handleEdgeClick = (0,react.useCallback)((evt, edge) => {
        if (edge.data?.condition?.label || edge.data?.loop)
            setSelectedEdge(edge);
    }, []);
    (0,react.useLayoutEffect)(() => {
        fitView({
            padding: 0.5,
        });
    }, []);
    (0,react.useEffect)(() => {
        if (shouldResetView) {
            fitView({
                padding: 0.5,
            });
            setShouldResetView(false);
        }
    }, [shouldResetView]);
    (0,react.useEffect)(() => {
        selectedNodeNameInWorkflow && selectNode(selectedNodeNameInWorkflow);
    }, [selectedNodeNameInWorkflow]);
    const handleSelectNode = (id) => {
        selectNode(id);
    };
    const handleClosePopup = () => {
        setSelectedEdge(null);
    };
    const handleNodeClick = (_, node) => {
        if (node.selected) {
            onNodeSecondClick && onNodeSecondClick(node.data.label, !!node.data.subgraph);
            handleSelectNode(undefined);
        }
        else {
            handleSelectNode(node.data.label);
            onNodeClick && node.data.label && onNodeClick(node.data.label);
        }
    };
    const handleBackgroundClick = (evt) => {
        // Clear selection when clicking graph background
        handleSelectNode(undefined);
    };
    const onNodesChange = (0,react.useCallback)((changes) => {
        // Apply changes and dispatch the updated nodes
        setNodes((0,dist_esm/* applyNodeChanges */._0)(changes, nodes));
    }, [nodes]);
    const onEdgesChange = (0,react.useCallback)((changes) => {
        // Apply changes and dispatch the updated edges
        setEdges((0,dist_esm/* applyEdgeChanges */.zW)(changes, edges));
    }, [edges]);
    return ((0,jsx_runtime.jsxs)("div", { className: Graph_module.wrapper, "data-testid": "react-flow-graph", children: [(0,jsx_runtime.jsx)(dist_esm/* ReactFlow */.Gc, { nodes: nodes, edges: edges, ...components, connectionLineType: esm/* ConnectionLineType */.Do.SmoothStep, onPaneClick: handleBackgroundClick, onNodesChange: onNodesChange, onEdgesChange: onEdgesChange, onNodeClick: handleNodeClick, onEdgeClick: handleEdgeClick, minZoom: 0.1, defaultEdgeOptions: edgeOptions, fitView: true, children: (0,jsx_runtime.jsx)(dist_esm/* Background */.VS, { color: backgroundColor, bgColor: backgroundColor }) }), selectedEdge && ((0,jsx_runtime.jsx)(EdgePopup_EdgePopUp, { open: true, onClose: handleClosePopup, source: selectedEdge.source, target: selectedEdge.target, info: selectedEdge.data?.condition || selectedEdge.data?.loop }))] }));
};
/* harmony default export */ var Graph_Graph = (({ onNodeClick, selectedWorkflowName, subgraphBreadcrumbs, onNodeSecondClick, selectedNodeNameInWorkflow }) => ((0,jsx_runtime.jsx)(dist_esm/* ReactFlowProvider */.Ln, { children: (0,jsx_runtime.jsx)(Graph, { onNodeClick: onNodeClick, selectedWorkflowName: selectedWorkflowName, selectedNodeNameInWorkflow: selectedNodeNameInWorkflow, subgraphBreadcrumbs: subgraphBreadcrumbs, onNodeSecondClick: onNodeSecondClick }) })));

;// ./src/modules/Graph/components/SubgraphBreadcrumbs/SubgraphBreadcrumbs.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var SubgraphBreadcrumbs_module = ({"breadcrumbsContainer":"SubgraphBreadcrumbs-module__breadcrumbsContainer","breadcrumbsButton":"SubgraphBreadcrumbs-module__breadcrumbsButton","breadcrumbsSeparator":"SubgraphBreadcrumbs-module__breadcrumbsSeparator"});
;// ./src/modules/Graph/components/SubgraphBreadcrumbs/SubgraphBreadcrumbs.tsx




const SubgraphBreadcrumbs = ({ className, subgraphBreadcrumbs, selectedWorkflowName, onBreadcrumbClick, }) => ((0,jsx_runtime.jsxs)("div", { className: classNames(SubgraphBreadcrumbs_module.breadcrumbsContainer, className), children: [subgraphBreadcrumbs.length !== 0 &&
            (0,jsx_runtime.jsx)("button", { className: SubgraphBreadcrumbs_module.breadcrumbsButton, onClick: () => onBreadcrumbClick(0), children: selectedWorkflowName }, "reset"), subgraphBreadcrumbs.map((key, index) => (0,jsx_runtime.jsxs)(react.Fragment, { children: [(0,jsx_runtime.jsx)("span", { className: SubgraphBreadcrumbs_module.breadcrumbsSeparator, children: "\u2192" }), (0,jsx_runtime.jsx)("button", { className: SubgraphBreadcrumbs_module.breadcrumbsButton, onClick: () => onBreadcrumbClick(index + 1), disabled: index === subgraphBreadcrumbs.length - 1, children: key })] }, `${key}_${index}`))] }));
/* harmony default export */ var SubgraphBreadcrumbs_SubgraphBreadcrumbs = (SubgraphBreadcrumbs);

;// ./src/modules/Graph/index.ts




;// ./src/modules/GraphLibrary/components/GraphElementErrorWrapper/GraphElementErrorWrapper.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var GraphElementErrorWrapper_module = ({"wrapper":"GraphElementErrorWrapper-module__wrapper","titleAndIconWrapper":"GraphElementErrorWrapper-module__titleAndIconWrapper","arrowIconWrapper":"GraphElementErrorWrapper-module__arrowIconWrapper","errorObjectWrapper":"GraphElementErrorWrapper-module__errorObjectWrapper"});
;// ./src/modules/GraphLibrary/components/GraphElementErrorWrapper/GraphElementErrorWrapper.tsx

/**
 * @fileoverview Collapsible error display for graph execution failures.
 *
 * Auto-expands when error appears, shows JSON-stringified error object.
 * Used in GraphElement to display API submission errors.
 */





const GraphElementErrorWrapper = () => {
    const errorObject = (0,react_redux/* useSelector */.d4)(getErrorObject);
    const [expanded, setExpanded] = react.useState(!!errorObject);
    // Auto-expand when error appears, collapse when cleared
    (0,react.useEffect)(() => {
        if (errorObject) {
            setExpanded(true);
        }
        else {
            setExpanded(false);
        }
    }, [errorObject]);
    return ((0,jsx_runtime.jsxs)("div", { className: GraphElementErrorWrapper_module.wrapper, children: [errorObject !== undefined && ((0,jsx_runtime.jsxs)("div", { className: GraphElementErrorWrapper_module.titleAndIconWrapper, children: [(0,jsx_runtime.jsx)("div", { className: GraphElementErrorWrapper_module.arrowIconWrapper, onClick: () => {
                            setExpanded(!expanded);
                        }, children: (0,jsx_runtime.jsx)(ArrowIcon, { options: { rotationDegree: expanded ? 0 : -90 } }) }), "Error"] })), expanded && (0,jsx_runtime.jsx)("div", { className: GraphElementErrorWrapper_module.errorObjectWrapper, children: JSON.stringify(errorObject) })] }));
};

;// ./src/modules/GraphLibrary/components/GraphElement/GraphElement.tsx

/**
 * @fileoverview Collapsible graph workflow card with parameters and visualization.
 *
 * Displays a calibration graph with editable parameters, node details, and a
 * Cytoscape preview. Handles parameter transformation for API submission and
 * opens the graph-status panel when execution starts.
 *
 * @see GraphList - Renders multiple GraphElements
 * @see CytoscapeGraph - Embedded graph visualization
 * @see GraphContext - Manages graph selection and execution state
 */


// eslint-disable-next-line css-modules/no-unused-class







const GraphElement = ({ calibrationGraphKey }) => {
    const dispatch = useRootDispatch();
    const selectedWorkflow = (0,react_redux/* useSelector */.d4)(getSelectedWorkflow);
    const selectedWorkflowName = (0,react_redux/* useSelector */.d4)(getSelectedWorkflowName);
    const selectedNodeNameInWorkflow = (0,react_redux/* useSelector */.d4)(getSelectedNodeNameInWorkflow);
    const subgraphBreadcrumbs = (0,react_redux/* useSelector */.d4)(getSubgraphBreadcrumbs, 
    // avoid unnecessary re-renders
    { equalityFn: (prev, curr) => prev.join() === curr.join() });
    const [errors, setErrors] = (0,react.useState)(new Set());
    const handleSubmit = () => dispatch(submitWorkflow());
    const handleSelectWorkflow = () => dispatch(setSelectedWorkflowName(calibrationGraphKey));
    const handleSelectNode = (nodeName) => dispatch(setSelectedNodeNameInWorkflow(nodeName));
    const handleSetSubgraphBreadcrumbs = (key, isWorkflow) => isWorkflow && dispatch(setSubgraphForward(key));
    const handleBreadcrumbClick = (index) => dispatch(setSubgraphBack(index));
    const handleSetError = (key, isValid) => {
        const newSet = new Set(errors);
        if (isValid)
            newSet.delete(key);
        else
            newSet.add(key);
        setErrors(newSet);
    };
    const onNodeParameterChange = (parameterKey, newValue, isValid, nodeId) => {
        handleSetError(parameterKey, isValid);
        dispatch(setGraphNodeParameter(parameterKey, newValue, nodeId));
    };
    const renderInputElement = (key, parameter) => ((0,jsx_runtime.jsx)(Parameters_ParameterSelector, { parameterKey: key, parameter: parameter, onChange: onNodeParameterChange }));
    const show = selectedWorkflowName === calibrationGraphKey;
    return ((0,jsx_runtime.jsxs)("div", { className: classNames(GraphElement_module.wrapper, show ? GraphElement_module.calibrationGraphSelected : ""), onClick: handleSelectWorkflow, children: [(0,jsx_runtime.jsxs)("div", { className: GraphElement_module.upperContainer, children: [(0,jsx_runtime.jsxs)("div", { className: GraphElement_module.leftContainer, children: [(0,jsx_runtime.jsx)("div", { children: calibrationGraphKey }), (0,jsx_runtime.jsx)("div", { className: GraphElement_module.runButtonWrapper, children: (0,jsx_runtime.jsx)(Button_BlueButton, { disabled: !show || errors.size !== 0, onClick: handleSubmit, children: "Run" }) })] }), "\u00A0 \u00A0 \u00A0 \u00A0", (show || selectedWorkflow?.description) && ((0,jsx_runtime.jsxs)("div", { className: GraphElement_module.rightContainer, children: [show && ((0,jsx_runtime.jsx)(SubgraphBreadcrumbs_SubgraphBreadcrumbs, { selectedWorkflowName: selectedWorkflowName, subgraphBreadcrumbs: subgraphBreadcrumbs, onBreadcrumbClick: handleBreadcrumbClick })), selectedWorkflow?.description && (0,jsx_runtime.jsx)("div", { children: selectedWorkflow?.description })] }))] }), (0,jsx_runtime.jsxs)("div", { className: GraphElement_module.bottomContainer, children: [(0,jsx_runtime.jsxs)("div", { className: GraphElement_module.parametersContainer, children: [(0,jsx_runtime.jsx)(GraphElementErrorWrapper, {}), (0,jsx_runtime.jsx)(Parameters, { show: show, showTitle: true, currentItem: selectedWorkflow, getInputElement: renderInputElement, parametersExpanded: true }, calibrationGraphKey), selectedWorkflow && (0,jsx_runtime.jsx)(ParameterList, { showParameters: show, mapOfItems: selectedWorkflow.nodes, onChange: onNodeParameterChange })] }), show && ((0,jsx_runtime.jsx)("div", { className: GraphElement_module.graphContainer, children: (0,jsx_runtime.jsx)(Graph_Graph, { selectedWorkflowName: calibrationGraphKey, selectedNodeNameInWorkflow: selectedNodeNameInWorkflow, onNodeClick: handleSelectNode, subgraphBreadcrumbs: subgraphBreadcrumbs, onNodeSecondClick: handleSetSubgraphBreadcrumbs }) }))] })] }));
};

;// ./src/modules/GraphLibrary/components/GraphList.tsx

/**
 * @fileoverview Main graph library view listing all available calibration workflows.
 *
 * Fetches and displays all graphs from GraphContext. Each graph is rendered as
 * a collapsible GraphElement card with parameters and visualization.
 *
 * @see GraphElement - Individual graph card component
 * @see GraphContext - Provides allGraphs data
 */


// eslint-disable-next-line css-modules/no-unused-class



const GraphList = () => {
    const allGraphs = (0,react_redux/* useSelector */.d4)(getAllGraphs);
    if (!allGraphs || Object.entries(allGraphs).length === 0)
        return (0,jsx_runtime.jsx)("div", { children: "No calibration graphs" });
    return ((0,jsx_runtime.jsx)("div", { className: GraphLibrary_module.listWrapper, children: Object.keys(allGraphs ?? {}).map((key) => {
            return (0,jsx_runtime.jsx)(GraphElement, { calibrationGraphKey: key }, key);
        }) }));
};

;// ./src/modules/GraphLibrary/GraphLibrary.tsx


// eslint-disable-next-line css-modules/no-unused-class





const GraphLibrary = () => {
    const isRescanningGraphs = (0,react_redux/* useSelector */.d4)(getIsRescanningGraphs);
    return ((0,jsx_runtime.jsx)("div", { className: GraphLibrary_module.wrapper, children: (0,jsx_runtime.jsxs)("div", { className: GraphLibrary_module.nodesContainer, children: [isRescanningGraphs && ((0,jsx_runtime.jsxs)("div", { className: GraphLibrary_module.loadingContainer, children: [(0,jsx_runtime.jsx)(CircularProgress/* default */.A, { size: 32 }), "Graph library scan in progress", (0,jsx_runtime.jsxs)("div", { children: ["See ", (0,jsx_runtime.jsx)("span", { className: GraphLibrary_module.logsText, children: "LOGS" }), " for details (bottomright)"] })] })), (0,jsx_runtime.jsx)(GraphList, {})] }) }));
};
/* harmony default export */ var GraphLibrary_GraphLibrary = (GraphLibrary);

;// ./src/modules/GraphLibrary/index.ts


;// ./src/modules/GraphStatus/GraphStatus.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var GraphStatus_module = ({"wrapper":"GraphStatus-module__wrapper","graphContainer":"GraphStatus-module__graphContainer","graphAndHistoryWrapper":"GraphStatus-module__graphAndHistoryWrapper","leftContainer":"GraphStatus-module__leftContainer","rightContainer":"GraphStatus-module__rightContainer"});
;// ./src/modules/GraphStatus/components/MeasurementHistory/MeasurementHistory.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var MeasurementHistory_module = ({"wrapper":"MeasurementHistory-module__wrapper","titleRow":"MeasurementHistory-module__titleRow","title":"MeasurementHistory-module__title","trackLatestWrapper":"MeasurementHistory-module__trackLatestWrapper","toggleSwitch":"MeasurementHistory-module__toggleSwitch","toggleOn":"MeasurementHistory-module__toggleOn","toggleOff":"MeasurementHistory-module__toggleOff","toggleKnob":"MeasurementHistory-module__toggleKnob","contentContainer":"MeasurementHistory-module__contentContainer","lowerContainer":"MeasurementHistory-module__lowerContainer"});
;// ./src/modules/GraphStatus/components/MeasurementElementList/MeasurementElementList.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var MeasurementElementList_module = ({"wrapper":"MeasurementElementList-module__wrapper"});
;// ./src/modules/GraphStatus/components/MeasurementElement/MeasurementElement.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var MeasurementElement_module = ({"rowWrapper":"MeasurementElement-module__rowWrapper","row":"MeasurementElement-module__row","dot":"MeasurementElement-module__dot","titleOrName":"MeasurementElement-module__titleOrName","descriptionWrapper":"MeasurementElement-module__descriptionWrapper","descriptionTooltip":"MeasurementElement-module__descriptionTooltip","expandedContent":"MeasurementElement-module__expandedContent","runInfoAndParameters":"MeasurementElement-module__runInfoAndParameters","runInfo":"MeasurementElement-module__runInfo","parameters":"MeasurementElement-module__parameters"});
;// ./src/modules/GraphStatus/components/MeasurementElement/MeasurementElement.tsx

/**
 * @fileoverview Collapsible measurement list item showing node execution results.
 *
 * Displays measurement ID, name, status dot (success/failure ratio), and expandable
 * details including run info, parameters, and per-qubit outcomes. Clicking fetches
 * snapshot data and displays in Results panel.
 *
 * @see MeasurementHistory - Parent list component
 * @see MeasurementElementInfoSection - Renders expandable details
 */










// TODO: probably merge with src/modules/Data/components/SnapshotElement/SnapshotElement.tsx
// and move to src/components
const MeasurementElement = ({ element, dataMeasurementId }) => {
    const dispatch = useRootDispatch();
    const selectedNodeNameInWorkflow = (0,react_redux/* useSelector */.d4)(getGraphStatuSelectedNodeNameInWorkflow);
    const trackLatest = (0,react_redux/* useSelector */.d4)(getTrackLatest);
    // Check if selected via list click or Cytoscape graph node click
    const measurementSelected = selectedNodeNameInWorkflow &&
        (selectedNodeNameInWorkflow === element.id?.toString() || selectedNodeNameInWorkflow === element.metadata?.name);
    const cytoscapeNodeSelected = selectedNodeNameInWorkflow &&
        (selectedNodeNameInWorkflow === element.id?.toString() || selectedNodeNameInWorkflow === element.metadata?.name);
    /**
     * Generates conic gradient for status dot based on outcome success ratio.
     * Green segment shows success percentage, red shows failures.
     */
    const getDotStyle = () => {
        if (!element.data?.outcomes || Object.keys(element.data?.outcomes).length === 0) {
            return { backgroundColor: "#40a8f5" };
        }
        const outcomes = Object.values(element.data?.outcomes);
        const total = outcomes.length;
        const successes = outcomes.filter((status) => status === "successful").length;
        const successPercentage = total !== 0 ? (successes / total) * 100 : 0;
        return {
            background: `conic-gradient(rgb(40, 167, 69, 0.9) ${successPercentage}%, rgb(220, 53, 69, 0.9) 0)`,
        };
    };
    const handleOnClick = () => {
        if (selectedNodeNameInWorkflow !== element.metadata?.name && trackLatest) {
            dispatch(setTrackLatest(false));
        }
        dispatch(setGraphStatusSelectedNodeNameInWorkflow(element.metadata?.name));
        if (element.id) {
            dispatch(setSelectedSnapshotId(element.id));
            dispatch(setSelectedSnapshot(element));
            dispatch(setClickedForSnapshotSelection(true));
            dispatch(fetchOneSnapshot(element.id));
        }
        else {
            dispatch(setResult({}));
            dispatch(setDiffData({}));
        }
    };
    return ((0,jsx_runtime.jsxs)("div", { "data-measurement-id": dataMeasurementId, className: classNames(MeasurementElement_module.rowWrapper), children: [(0,jsx_runtime.jsxs)("div", { className: MeasurementElement_module.row, onClick: handleOnClick, children: [(0,jsx_runtime.jsx)("div", { className: MeasurementElement_module.dot, style: getDotStyle() }), (0,jsx_runtime.jsxs)("div", { className: MeasurementElement_module.titleOrName, children: ["#", element.id, " ", element.metadata?.name] }), (0,jsx_runtime.jsx)("div", { className: MeasurementElement_module.descriptionWrapper, children: element.metadata?.description && ((0,jsx_runtime.jsx)(Tooltip/* default */.A, { title: (0,jsx_runtime.jsx)("div", { className: MeasurementElement_module.descriptionTooltip, children: element.metadata?.description ?? "" }), placement: "left-start", arrow: true, children: (0,jsx_runtime.jsx)("span", { children: (0,jsx_runtime.jsx)(InfoIcon, {}) }) })) })] }), (measurementSelected || cytoscapeNodeSelected) && ((0,jsx_runtime.jsxs)("div", { className: MeasurementElement_module.expandedContent, children: [(0,jsx_runtime.jsxs)("div", { className: MeasurementElement_module.runInfoAndParameters, children: [(0,jsx_runtime.jsx)(MeasurementElementStatusInfoAndParameters, { data: {
                                    Status: element.metadata?.status || "Unknown",
                                    ...(element.metadata?.run_start && { "Run start": formatDateTime(element.metadata?.run_start) }),
                                    ...(element.metadata?.run_end && { "Run end": formatDateTime(element.metadata?.run_end) }),
                                    ...(element.metadata?.run_duration && { "Run duration": `${element.metadata?.run_duration}s` }),
                                }, isInfoSection: true, className: MeasurementElement_module.runInfo, evenlySpaced: true }), (0,jsx_runtime.jsx)(MeasurementElementStatusInfoAndParameters, { title: "Parameters", data: element.data?.parameters || {}, filterEmpty: true, className: MeasurementElement_module.parameters })] }), (0,jsx_runtime.jsx)(MeasurementElementOutcomes, { outcomes: element.data?.outcomes })] }))] }));
};

;// ./src/modules/GraphStatus/components/MeasurementElementList/MeasurementElementList.tsx

/**
 * @fileoverview Simple list renderer for measurement elements.
 *
 * @see MeasurementElement - Individual list item component
 * @see MeasurementHistory - Parent component providing measurements array
 */



const MeasurementElementList = ({ listOfMeasurements }) => {
    return ((0,jsx_runtime.jsx)("div", { className: MeasurementElementList_module.wrapper, children: listOfMeasurements.map((el, index) => ((0,jsx_runtime.jsx)(MeasurementElement, { element: el, dataMeasurementId: el.metadata?.name ?? "" }, `${el.id ?? el.metadata?.name ?? "-"}-${index}`))) }));
};

;// ./src/modules/GraphStatus/components/MeasurementHistory/MeasurementHistory.tsx

/**
 * @fileoverview Execution history panel with "track latest" auto-selection.
 *
 * Displays list of measurements from recent graph executions. When "track latest"
 * is enabled, automatically selects and displays results from the most recent
 * measurement as they arrive via WebSocket updates.
 *
 * @see GraphStatusContext - Provides allMeasurements and trackLatest state
 * @see MeasurementElementList - Renders the measurement list
 */







const MeasurementHistory = ({ title = "Execution history" }) => {
    const dispatch = useRootDispatch();
    const allMeasurements = (0,react_redux/* useSelector */.d4)(getAllMeasurements, (prev, current) => JSON.stringify(prev) === JSON.stringify(current));
    const trackLatest = (0,react_redux/* useSelector */.d4)(getTrackLatest);
    const trackLatestSidePanel = (0,react_redux/* useSelector */.d4)(getTrackLatestSidePanel);
    const [latestId, setLatestId] = (0,react.useState)();
    const [latestName, setLatestName] = (0,react.useState)();
    const handleOnClick = () => {
        dispatch(setTrackLatest(!trackLatest));
    };
    /**
     * Auto-selects latest measurement when trackLatest is enabled.
     * Fetches snapshot with diff data if trackLatestSidePanel is enabled.
     * Only updates if latest measurement ID or name has changed.
     */
    (0,react.useEffect)(() => {
        if (trackLatest) {
            if (allMeasurements) {
                const element = allMeasurements[0];
                if (element && (element.id !== latestId || element.metadata?.name !== latestName)) {
                    setLatestId(element.id);
                    setLatestName(element.metadata?.name);
                    dispatch(setGraphStatusSelectedNodeNameInWorkflow(element?.metadata?.name));
                    if (element.id) {
                        dispatch(setLatestSnapshotId(element.id));
                        if (trackLatestSidePanel) {
                            dispatch(fetchOneSnapshot(element.id, element.id - 1, true, true));
                        }
                        else {
                            dispatch(fetchOneSnapshot(element.id));
                        }
                    }
                    else {
                        dispatch(setResult({}));
                        dispatch(setDiffData({}));
                    }
                }
            }
        }
    }, [trackLatest, allMeasurements, latestId, latestName]);
    return ((0,jsx_runtime.jsxs)("div", { className: MeasurementHistory_module.wrapper, children: [(0,jsx_runtime.jsxs)("div", { className: MeasurementHistory_module.titleRow, children: [(0,jsx_runtime.jsx)("div", { className: MeasurementHistory_module.title, children: title }), (0,jsx_runtime.jsxs)("div", { className: MeasurementHistory_module.trackLatestWrapper, children: [(0,jsx_runtime.jsx)("span", { children: "Track latest" }), (0,jsx_runtime.jsx)("div", { className: `${MeasurementHistory_module.toggleSwitch} ${trackLatest ? MeasurementHistory_module.toggleOn : MeasurementHistory_module.toggleOff}`, onClick: handleOnClick, children: (0,jsx_runtime.jsx)("div", { className: `${MeasurementHistory_module.toggleKnob} ${trackLatest ? MeasurementHistory_module.toggleOn : MeasurementHistory_module.toggleOff}` }) })] })] }), allMeasurements && allMeasurements?.length > 0 && ((0,jsx_runtime.jsx)("div", { className: MeasurementHistory_module.contentContainer, children: (0,jsx_runtime.jsx)(MeasurementElementList, { listOfMeasurements: allMeasurements }) })), (!allMeasurements || allMeasurements?.length === 0) && ((0,jsx_runtime.jsx)("div", { className: MeasurementHistory_module.contentContainer, children: (0,jsx_runtime.jsx)("div", { className: MeasurementHistory_module.lowerContainer, children: "No measurements found" }) }))] }));
};

;// ./src/modules/GraphStatus/components/MeasurementElementGraph/MeasurementElementGraph.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var MeasurementElementGraph_module = ({"calibrationTitle":"MeasurementElementGraph-module__calibrationTitle","dot":"MeasurementElementGraph-module__dot","defaultBlue":"MeasurementElementGraph-module__defaultBlue","blinkingYellow":"MeasurementElementGraph-module__blinkingYellow","blink-animation":"MeasurementElementGraph-module__blink-animation","blinkAnimation":"MeasurementElementGraph-module__blink-animation","solidGreen":"MeasurementElementGraph-module__solidGreen","wrapper":"MeasurementElementGraph-module__wrapper","insideWrapper":"MeasurementElementGraph-module__insideWrapper","lowerContainer":"MeasurementElementGraph-module__lowerContainer","lowerUpperContainer":"MeasurementElementGraph-module__lowerUpperContainer","label":"MeasurementElementGraph-module__label","tuneUpName":"MeasurementElementGraph-module__tuneUpName","lowerUpperLeftContainer":"MeasurementElementGraph-module__lowerUpperLeftContainer","lowerUpperRightContainer":"MeasurementElementGraph-module__lowerUpperRightContainer","lowerLowerContainer":"MeasurementElementGraph-module__lowerLowerContainer","subgraphBreadcrumbs":"MeasurementElementGraph-module__subgraphBreadcrumbs"});
;// ./src/modules/GraphStatus/components/MeasurementElementGraph/MeasurementElementGraph.tsx

/**
 * @fileoverview Active graph execution visualization with real-time status.
 *
 * Displays Cytoscape graph with blinking status dot, run progress, and stop button.
 * Updates via WebSocket runStatus for graph name, status, duration, and node progress.
 *
 * @see CytoscapeGraph - Graph visualization component
 * @see GraphStatus - Parent component
 * @see WebSocketContext - Provides real-time runStatus updates
 */











const MeasurementElementGraph = ({ onNodeClick }) => {
    const dispatch = useRootDispatch();
    const runStatusGraphStatus = (0,react_redux/* useSelector */.d4)(getRunStatusGraphStatus);
    const runStatusGraphFinishedNodes = (0,react_redux/* useSelector */.d4)(getRunStatusGraphFinishedNodes);
    const runStatusGraphTotalNodes = (0,react_redux/* useSelector */.d4)(getRunStatusGraphTotalNodes);
    const runStatusGraphName = (0,react_redux/* useSelector */.d4)(getRunStatusGraphName);
    const runStatusGraphRunDuration = (0,react_redux/* useSelector */.d4)(getRunStatusGraphRunDuration);
    const subgraphBreadcrumbs = (0,react_redux/* useSelector */.d4)(getGraphStatuSubgraphBreadcrumbs);
    const selectedNodeNameInWorkflow = (0,react_redux/* useSelector */.d4)(getGraphStatuSelectedNodeNameInWorkflow);
    const handleSetSubgraphBreadcrumbs = (key, isWorkflow) => isWorkflow && dispatch(setGraphStatusSubgraphForward(key));
    const handleBreadcrumbClick = (index) => dispatch(setGraphStasetSubgraphBack(index));
    const isRunning = runStatusGraphStatus === "running";
    const graphProgressMessage = runStatusGraphFinishedNodes && runStatusGraphTotalNodes
        ? `${runStatusGraphFinishedNodes}/${runStatusGraphTotalNodes} node${runStatusGraphFinishedNodes > 1 ? "s" : ""} completed`
        : "-";
    const handleStopClick = (0,react.useCallback)(() => {
        SnapshotsApi.stopNodeRunning();
    }, []);
    return ((0,jsx_runtime.jsxs)("div", { className: MeasurementElementGraph_module.wrapper, "data-testid": "measurement-element-graph", children: [(0,jsx_runtime.jsxs)("div", { className: MeasurementElementGraph_module.calibrationTitle, children: [(0,jsx_runtime.jsx)("span", { className: classNames(MeasurementElementGraph_module.dot, isRunning ? MeasurementElementGraph_module.blinkingYellow : runStatusGraphStatus === "finished" ? MeasurementElementGraph_module.solidGreen : MeasurementElementGraph_module.defaultBlue) }), (0,jsx_runtime.jsx)("span", { className: MeasurementElementGraph_module.label, children: "Active Calibration Graph:" }), (0,jsx_runtime.jsx)("span", { className: MeasurementElementGraph_module.tuneUpName, children: runStatusGraphName || "Unknown Tune-up" })] }), (0,jsx_runtime.jsx)("div", { className: MeasurementElementGraph_module.insideWrapper, children: (0,jsx_runtime.jsxs)("div", { className: MeasurementElementGraph_module.lowerContainer, children: [(0,jsx_runtime.jsxs)("div", { className: MeasurementElementGraph_module.lowerUpperContainer, children: [(0,jsx_runtime.jsxs)("div", { className: MeasurementElementGraph_module.lowerUpperLeftContainer, children: [(0,jsx_runtime.jsxs)("div", { children: ["Status: ", runStatusGraphStatus] }), (0,jsx_runtime.jsxs)("div", { children: ["Run duration:\u00A0", runStatusGraphRunDuration ? `${runStatusGraphRunDuration}s` : undefined] }), (0,jsx_runtime.jsxs)("div", { children: ["Graph progress:\u00A0", graphProgressMessage ?? (0,jsx_runtime.jsx)(CircularProgress/* default */.A, { size: "2rem" })] })] }), (0,jsx_runtime.jsx)("div", { className: MeasurementElementGraph_module.lowerUpperRightContainer, children: runStatusGraphStatus === "running" && (0,jsx_runtime.jsx)(Button_BlueButton, { onClick: handleStopClick, children: "Stop" }) })] }), (0,jsx_runtime.jsxs)("div", { className: MeasurementElementGraph_module.lowerLowerContainer, children: [(0,jsx_runtime.jsx)(SubgraphBreadcrumbs_SubgraphBreadcrumbs, { className: MeasurementElementGraph_module.subgraphBreadcrumbs, selectedWorkflowName: runStatusGraphName, subgraphBreadcrumbs: subgraphBreadcrumbs, onBreadcrumbClick: handleBreadcrumbClick }), (0,jsx_runtime.jsx)(Graph_Graph, { selectedWorkflowName: runStatusGraphName, selectedNodeNameInWorkflow: selectedNodeNameInWorkflow, onNodeClick: onNodeClick, subgraphBreadcrumbs: subgraphBreadcrumbs, onNodeSecondClick: handleSetSubgraphBreadcrumbs })] })] }) })] }));
};

;// ./src/modules/GraphStatus/GraphStatus.tsx

/**
 * @fileoverview Graph execution status view with real-time updates.
 *
 * Displays running graph visualization, execution history, and node results.
 * Coordinates state between GraphStatusContext, SnapshotsContext, and WebSocket
 * updates. Handles node selection to fetch and display measurement snapshots.
 *
 * @see GraphStatusContext - Manages measurements and track-latest state
 * @see MeasurementElementGraph - Graph visualization with run status
 * @see MeasurementHistory - Execution history list with track-latest toggle
 */


// eslint-disable-next-line css-modules/no-unused-class












const GraphStatus = () => {
    const dispatch = useRootDispatch();
    // const nodes = useSelector(getWorkflowGraphNodes);
    const activePage = (0,react_redux/* useSelector */.d4)(getActivePage);
    const allMeasurements = (0,react_redux/* useSelector */.d4)(getAllMeasurements, (prev, current) => JSON.stringify(prev) === JSON.stringify(current));
    const selectedNodeNameInWorkflow = (0,react_redux/* useSelector */.d4)(getGraphStatuSelectedNodeNameInWorkflow);
    const runStatusGraphName = (0,react_redux/* useSelector */.d4)(getRunStatusGraphName);
    const runStatusGraphTotalNodes = (0,react_redux/* useSelector */.d4)(getRunStatusGraphTotalNodes);
    const lastRunNodeName = (0,react_redux/* useSelector */.d4)(getLastRunNodeName);
    const lastRunError = (0,react_redux/* useSelector */.d4)(getLastRunError);
    const result = (0,react_redux/* useSelector */.d4)(getResult);
    (0,react.useEffect)(() => {
        dispatch(fetchAllMeasurements());
    }, []);
    const getMeasurementId = (measurementName, measurements) => {
        return measurements?.find((measurement) => measurement.metadata?.name === measurementName)?.id;
    };
    /**
     * Ensures measurements are loaded before lookup.
     * Returns fetched measurements or empty array if already loaded.
     */
    const setupAllMeasurements = async () => {
        if (!allMeasurements || allMeasurements.length === 0) {
            return await dispatch(fetchAllMeasurements());
        }
        return [];
    };
    /**
     * Handles node clicks from Cytoscape graph.
     * Fetches measurement snapshot and displays results in right panel.
     * Disables track-latest mode when manually selecting a node.
     */
    const handleOnGraphNodeClick = async (name) => {
        const temp = await setupAllMeasurements();
        const measurements = temp && temp.length > 0 ? temp : (allMeasurements ?? []);
        dispatch(setTrackLatest(false));
        // Disable "track latest" when manually selecting a node
        dispatch(setGraphStatusSelectedNodeNameInWorkflow(undefined));
        const measurementId = name && getMeasurementId(name, measurements);
        if (measurementId) {
            dispatch(setGraphStatusSelectedNodeNameInWorkflow(name));
            dispatch(setSelectedSnapshotId(measurementId));
            dispatch(setClickedForSnapshotSelection(true));
            dispatch(fetchOneSnapshot(measurementId, measurementId - 1, true, true));
        }
        else {
            dispatch(setResult({}));
            dispatch(setDiffData({}));
        }
    };
    return ((0,jsx_runtime.jsxs)("div", { className: GraphStatus_module.wrapper, children: [(0,jsx_runtime.jsx)("div", { className: GraphStatus_module.leftContainer, children: (0,jsx_runtime.jsxs)("div", { className: GraphStatus_module.graphAndHistoryWrapper, children: [activePage === GRAPH_STATUS_KEY && ((0,jsx_runtime.jsx)(MeasurementElementGraph, { onNodeClick: handleOnGraphNodeClick }, `${runStatusGraphName}-${runStatusGraphTotalNodes}`)), (0,jsx_runtime.jsx)(MeasurementHistory, {})] }) }), (0,jsx_runtime.jsx)("div", { className: GraphStatus_module.rightContainer, children: (0,jsx_runtime.jsx)(Results, { jsonObject: selectedNodeNameInWorkflow && allMeasurements && allMeasurements.length > 0 && result ? result : {}, toggleSwitch: true, style: { height: "100%", flex: "0 1 auto" }, errorObject: selectedNodeNameInWorkflow === lastRunNodeName ? lastRunError : undefined }) })] }));
};
/* harmony default export */ var GraphStatus_GraphStatus = (GraphStatus);

;// ./src/modules/GraphStatus/index.ts


;// ./src/modules/Data/Data.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var Data_module = ({"titlebarWrapper":"Data-module__titlebarWrapper","rightsidePanelWrapper":"Data-module__rightsidePanelWrapper","contentWrapper":"Data-module__contentWrapper"});
;// ./src/modules/Data/Data.tsx

 // eslint-disable-next-line css-modules/no-unused-class






const Data = () => {
    const selectedSnapshot = (0,react_redux/* useSelector */.d4)(getSelectedSnapshot);
    return ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)(DataLeftPanel_DataLeftPanel, {}), (0,jsx_runtime.jsxs)("div", { className: Data_module.titlebarWrapper, children: [(0,jsx_runtime.jsx)(TopbarMenu_TitleBarMenu, { customTitle: `${selectedSnapshot?.id ?? ""} ${selectedSnapshot?.metadata?.name ?? ""}` }), (0,jsx_runtime.jsxs)("div", { className: Data_module.rightsidePanelWrapper, children: [(0,jsx_runtime.jsx)("div", { className: Data_module.contentWrapper, children: (0,jsx_runtime.jsx)(DataRightPanel_DataRightPanel, {}) }), (0,jsx_runtime.jsx)(RightSidePanel, {})] })] })] }));
};
/* harmony default export */ var Data_Data = (Data);

;// ./src/modules/Data/components/DataLeftPanel/DataLeftPanel.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var DataLeftPanel_module = ({"titleArrow":"DataLeftPanel-module__titleArrow","titleSlash":"DataLeftPanel-module__titleSlash","title":"DataLeftPanel-module__title","dataWrapper":"DataLeftPanel-module__dataWrapper","data":"DataLeftPanel-module__data","headerPanel":"DataLeftPanel-module__headerPanel","searchFilterContainer":"DataLeftPanel-module__searchFilterContainer","wrapAppliedFilters":"DataLeftPanel-module__wrapAppliedFilters","snapshotsWrapper":"DataLeftPanel-module__snapshotsWrapper"});
;// ./src/modules/Data/components/SnapshotsTimeline/SnapshotsTimeline.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var SnapshotsTimeline_module = ({"wrapper":"SnapshotsTimeline-module__wrapper","nodeTitleWrapper":"SnapshotsTimeline-module__nodeTitleWrapper","nodeTitle":"SnapshotsTimeline-module__nodeTitle"});
;// ./src/modules/Data/components/ExecutionCard/ExecutionCard.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var ExecutionCard_module = ({"executionCard":"ExecutionCard-module__executionCard","selected":"ExecutionCard-module__selected","executionHeader":"ExecutionCard-module__executionHeader","executionHeaderLeft":"ExecutionCard-module__executionHeaderLeft","executionName":"ExecutionCard-module__executionName","executionStatus":"ExecutionCard-module__executionStatus","statusRunning":"ExecutionCard-module__statusRunning","statusPending":"ExecutionCard-module__statusPending","statusSuccess":"ExecutionCard-module__statusSuccess","statusError":"ExecutionCard-module__statusError","statusFailure":"ExecutionCard-module__statusFailure","statusDotRunning":"ExecutionCard-module__statusDotRunning","statusDotPending":"ExecutionCard-module__statusDotPending","statusDotSuccess":"ExecutionCard-module__statusDotSuccess","statusDotError":"ExecutionCard-module__statusDotError","statusDotFailure":"ExecutionCard-module__statusDotFailure","statusDot":"ExecutionCard-module__statusDot","pulse":"ExecutionCard-module__pulse","executionMeta":"ExecutionCard-module__executionMeta","executionMetaItem":"ExecutionCard-module__executionMetaItem","executionMetaItemGraphCard":"ExecutionCard-module__executionMetaItemGraphCard","executionTypeBadge":"ExecutionCard-module__executionTypeBadge"});
;// ./src/utils/formatTimeDuration.ts
/**
 * Formats number of seconds into "2h 22m 5s" format.
 */
const formatTimeDuration = (duration) => {
    if (duration <= 0) {
        return "0s";
    }
    const hours = Math.floor(duration / 3600);
    const minutes = Math.floor((duration % 3600) / 60);
    const seconds = Math.floor(duration % 60);
    return [hours && `${hours}h`, minutes && `${minutes}m`, seconds || (!hours && !minutes) ? `${seconds}s` : null].filter(Boolean).join(" ");
};

;// ./src/modules/Data/components/ExecutionCard/components/TagsList/TagsList.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var TagsList_module = ({"executionTags":"TagsList-module__executionTags","tag":"TagsList-module__tag","tagDot":"TagsList-module__tagDot","tagRemove":"TagsList-module__tagRemove","addTagButton":"TagsList-module__addTagButton"});
;// ./src/modules/Data/components/ExecutionCard/components/TagsList/TagsList.tsx







const TagsList = ({ snapshot, handleOnAddTagClick }) => {
    const dispatch = useRootDispatch();
    const handleOnRemoveClick = (selectedTag) => {
        dispatch(setSelectedSnapshot(snapshot));
        if (snapshot) {
            const newTagArray = snapshot?.tags?.filter((tag) => tag !== selectedTag) ?? [];
            dispatch(updateSnapshotTags(newTagArray));
            addTagsToSnapshot(snapshot.id, newTagArray);
        }
    };
    if (!snapshot) {
        return null;
    }
    return ((0,jsx_runtime.jsxs)("div", { className: TagsList_module.executionTags, children: [snapshot?.tags?.map((tag, index) => ((0,jsx_runtime.jsxs)("div", { className: TagsList_module.tag, children: [(0,jsx_runtime.jsx)("div", { className: TagsList_module.tagDot, style: { background: stringToHexColor(tag) } }), tag, (0,jsx_runtime.jsx)("span", { className: TagsList_module.tagRemove, onClick: () => handleOnRemoveClick(tag), children: "\u00D7" })] }, `${tag}${index}`))), (0,jsx_runtime.jsx)("button", { className: TagsList_module.addTagButton, onClick: handleOnAddTagClick, children: "+ Tag" })] }));
};
/* harmony default export */ var TagsList_TagsList = (TagsList);

;// ./src/modules/Data/components/ExecutionCard/components/TagsList/index.ts


;// ./src/modules/Data/components/ExecutionCard/components/ManageTagsModal/ManageTagsModal.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var ManageTagsModal_module = ({"modal":"ManageTagsModal-module__modal","modalContent":"ManageTagsModal-module__modalContent","modalHeader":"ManageTagsModal-module__modalHeader","modalBody":"ManageTagsModal-module__modalBody","tagList":"ManageTagsModal-module__tagList","tagItem":"ManageTagsModal-module__tagItem","selected":"ManageTagsModal-module__selected","tagCheckbox":"ManageTagsModal-module__tagCheckbox","tagInfo":"ManageTagsModal-module__tagInfo","tagDot":"ManageTagsModal-module__tagDot","newTagInput":"ManageTagsModal-module__newTagInput","modalFooter":"ManageTagsModal-module__modalFooter","modalBtn":"ManageTagsModal-module__modalBtn","secondary":"ManageTagsModal-module__secondary","primary":"ManageTagsModal-module__primary"});
;// ./src/modules/Data/components/ExecutionCard/components/ManageTagsModal/ManageTagsModal.tsx











const ManageTagsModal = ({ currentSelectedTags = [], handleOnClose }) => {
    const dispatch = useRootDispatch();
    const allTags = (0,react_redux/* useSelector */.d4)(getAllTags);
    const selectedSnapshot = (0,react_redux/* useSelector */.d4)(getSelectedSnapshot);
    const [newTag, setNewTag] = (0,react.useState)("");
    const [selectedTags, setSelectedTags] = (0,react.useState)(currentSelectedTags);
    const handleToggleTag = (newTagName) => {
        setSelectedTags((prev) => (prev.includes(newTagName) ? prev.filter((tag) => tag !== newTagName) : [...prev, newTagName]));
    };
    const handleOnSave = () => {
        if (!selectedSnapshot)
            return;
        const shouldAddNewTag = newTag && !allTags.includes(newTag);
        const finalTags = shouldAddNewTag ? [...selectedTags, newTag] : selectedTags;
        dispatch(updateSnapshotTags(finalTags));
        addTagsToSnapshot(selectedSnapshot.id, finalTags);
        if (shouldAddNewTag) {
            dispatch(setAllTags([...allTags, newTag]));
            setSelectedTags(finalTags);
        }
        handleOnClose();
    };
    if (!allTags) {
        return null;
    }
    return ((0,jsx_runtime.jsx)(Dialog/* default */.A, { classes: { paper: ManageTagsModal_module.modal }, open: true, onClose: handleOnClose, children: (0,jsx_runtime.jsxs)("div", { className: ManageTagsModal_module.modalContent, children: [(0,jsx_runtime.jsx)("div", { className: ManageTagsModal_module.modalHeader, children: (0,jsx_runtime.jsx)("h3", { children: "Manage Tags" }) }), (0,jsx_runtime.jsxs)("div", { className: ManageTagsModal_module.modalBody, children: [(0,jsx_runtime.jsx)("div", { className: ManageTagsModal_module.tagList, children: allTags.map((tag) => {
                                const isSelected = selectedTags.includes(tag);
                                return ((0,jsx_runtime.jsxs)("div", { className: classNames(ManageTagsModal_module.tagItem, isSelected && ManageTagsModal_module.selected), onClick: () => handleToggleTag(tag), children: [(0,jsx_runtime.jsx)("div", { className: ManageTagsModal_module.tagCheckbox }), (0,jsx_runtime.jsxs)("div", { className: ManageTagsModal_module.tagInfo, children: [(0,jsx_runtime.jsx)("div", { className: ManageTagsModal_module.tagDot, style: { background: stringToHexColor(tag) } }), (0,jsx_runtime.jsx)("span", { children: tag })] })] }, tag));
                            }) }), (0,jsx_runtime.jsx)(Input_InputField, { dataTestId: "search-field", inputClassName: ManageTagsModal_module.newTagInput, name: "search", placeholder: "Create new tag...", value: newTag, autoComplete: "off", onChange: (val) => setNewTag(val) })] }), (0,jsx_runtime.jsxs)("div", { className: ManageTagsModal_module.modalFooter, children: [(0,jsx_runtime.jsx)("button", { className: `${ManageTagsModal_module.modalBtn} ${ManageTagsModal_module.secondary}`, onClick: handleOnClose, children: "Cancel" }), (0,jsx_runtime.jsx)("button", { className: `${ManageTagsModal_module.modalBtn} ${ManageTagsModal_module.primary}`, onClick: handleOnSave, children: "Save" })] })] }) }));
};
/* harmony default export */ var ManageTagsModal_ManageTagsModal = (ManageTagsModal);

;// ./src/modules/Data/components/ExecutionCard/components/ManageTagsModal/index.ts


;// ./src/modules/Data/components/ExecutionCard/components/index.ts



;// ./src/modules/Data/components/ExecutionCard/ExecutionCard.tsx










const ExecutionCard = ({ snapshot, isSelected = true, handleOnClick, handleOnAddTagClick }) => {
    const dispatch = useRootDispatch();
    const selectedNodeInWorkflowName = (0,react_redux/* useSelector */.d4)(getSelectedNodeInWorkflowName);
    const selectedWorkflow = (0,react_redux/* useSelector */.d4)(selectors_getSelectedWorkflow);
    const isHighlighted = snapshot.id === selectedNodeInWorkflowName || isSelected;
    const statusClassMap = {
        running: ExecutionCard_module.statusRunning,
        pending: ExecutionCard_module.statusPending,
        completed: ExecutionCard_module.statusSuccess,
        failure: ExecutionCard_module.statusFailure,
        error: ExecutionCard_module.statusError,
    };
    const statusDotClassMap = {
        running: ExecutionCard_module.statusDotRunning,
        pending: ExecutionCard_module.statusDotPending,
        completed: ExecutionCard_module.statusDotSuccess,
        failure: ExecutionCard_module.statusDotFailure,
        error: ExecutionCard_module.statusDotError,
    };
    const executionId = snapshot.id;
    const executionName = snapshot.metadata?.name;
    const executionStatus = (snapshot.metadata?.status === "finished" || !snapshot.metadata?.status) ? "completed" : snapshot.metadata?.status;
    const runStart = snapshot.metadata?.run_start;
    const runDuration = snapshot.metadata?.run_duration ?? 0;
    const isWorkflowType = snapshot.metadata.type_of_execution?.toLocaleLowerCase() === "workflow";
    const handleOnGraphClick = (event) => {
        event.stopPropagation();
        dispatch(setSelectedWorkflow(snapshot));
        dispatch(setSelectedSnapshotId(snapshot?.id));
        dispatch(setSelectedSnapshot(snapshot));
        dispatch(setSelectedNodeInWorkflowId(snapshot?.id));
        if (snapshot?.metadata?.name !== selectedWorkflow?.metadata?.name) {
            dispatch(actions_setSubgraphForward(snapshot.metadata.name));
        }
    };
    return ((0,jsx_runtime.jsxs)("div", { className: classNames(ExecutionCard_module.executionCard, isHighlighted && ExecutionCard_module.selected), onClick: handleOnClick, children: [(0,jsx_runtime.jsxs)("div", { className: ExecutionCard_module.executionHeader, children: [(0,jsx_runtime.jsx)("div", { className: ExecutionCard_module.executionHeaderLeft, children: (0,jsx_runtime.jsx)("span", { className: ExecutionCard_module.executionName, title: executionName, children: executionName }) }), (0,jsx_runtime.jsxs)("div", { className: classNames(ExecutionCard_module.executionStatus, statusClassMap[executionStatus]), children: [(0,jsx_runtime.jsx)("div", { className: classNames(ExecutionCard_module.statusDot, statusDotClassMap[executionStatus]) }), executionStatus] })] }), (0,jsx_runtime.jsxs)("div", { className: ExecutionCard_module.executionMeta, children: [(0,jsx_runtime.jsx)("div", { className: ExecutionCard_module.executionMetaItem, children: (0,jsx_runtime.jsxs)("span", { className: ExecutionCard_module.executionId, children: ["#", executionId] }) }), (0,jsx_runtime.jsxs)("div", { className: ExecutionCard_module.executionMetaItem, children: [(0,jsx_runtime.jsxs)("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: [(0,jsx_runtime.jsx)("circle", { cx: "12", cy: "12", r: "10" }), (0,jsx_runtime.jsx)("polyline", { points: "12 6 12 12 16 14" })] }), formatTimeDuration(runDuration)] }), (0,jsx_runtime.jsxs)("div", { className: ExecutionCard_module.executionMetaItem, children: [(0,jsx_runtime.jsxs)("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: [(0,jsx_runtime.jsx)("rect", { x: "3", y: "4", width: "18", height: "18", rx: "2", ry: "2" }), (0,jsx_runtime.jsx)("line", { x1: "16", y1: "2", x2: "16", y2: "6" }), (0,jsx_runtime.jsx)("line", { x1: "8", y1: "2", x2: "8", y2: "6" }), (0,jsx_runtime.jsx)("line", { x1: "3", y1: "10", x2: "21", y2: "10" })] }), runStart && formatDate(runStart)] }), isWorkflowType && ((0,jsx_runtime.jsx)("div", { className: ExecutionCard_module.executionMetaItemGraphCard, children: (0,jsx_runtime.jsxs)("span", { className: ExecutionCard_module.executionTypeBadge, onClick: handleOnGraphClick, children: ["GRAPH", (0,jsx_runtime.jsx)("svg", { width: "10", height: "10", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "3", children: (0,jsx_runtime.jsx)("polyline", { points: "9 18 15 12 9 6" }) })] }) }))] }), (0,jsx_runtime.jsx)(TagsList_TagsList, { snapshot: snapshot, handleOnAddTagClick: handleOnAddTagClick })] }));
};
/* harmony default export */ var ExecutionCard_ExecutionCard = (ExecutionCard);

;// ./src/modules/Data/components/ExecutionCard/index.ts



;// ./src/modules/Data/components/SnapshotsTimeline/SnapshotsTimeline.tsx









const SnapshotsTimeline = () => {
    const dispatch = useRootDispatch();
    const selectedSnapshotId = (0,react_redux/* useSelector */.d4)(getSelectedSnapshotId);
    const selectedSnapshot = (0,react_redux/* useSelector */.d4)(getSelectedSnapshot);
    const selectedWorkflowGraph = (0,react_redux/* useSelector */.d4)(getSelectedWorkflowForGraph);
    const allSnapshots = (0,react_redux/* useSelector */.d4)(getAllSnapshots);
    const [showTagsModal, setShowTagsModal] = (0,react.useState)(false);
    const handleOnClick = (snapshot) => {
        dispatch(setSelectedSnapshotId(snapshot.id));
        dispatch(setSelectedNodeInWorkflowId(snapshot?.id));
        dispatch(setClickedForSnapshotSelection(true));
        dispatch(fetchOneSnapshot(snapshot.id));
        dispatch(setSelectedSnapshot(snapshot));
    };
    const handleOnAddTagClick = () => {
        setShowTagsModal(true);
    };
    const handleOnClose = () => {
        setShowTagsModal(false);
        dispatch(setSnapshotUpdateRequired(true));
    };
    return ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)("div", { className: SnapshotsTimeline_module.wrapper, children: selectedWorkflowGraph && ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)(ExecutionCard_ExecutionCard, { snapshot: selectedWorkflowGraph, isSelected: false, handleOnClick: () => handleOnClick(selectedWorkflowGraph), handleOnAddTagClick: handleOnAddTagClick }), (0,jsx_runtime.jsx)("div", { className: SnapshotsTimeline_module.nodeTitleWrapper, children: (0,jsx_runtime.jsx)("div", { className: SnapshotsTimeline_module.nodeTitle, children: "Nodes in this graph" }) })] })) }), (selectedWorkflowGraph?.items?.length || allSnapshots) && ((0,jsx_runtime.jsx)("div", { className: SnapshotsTimeline_module.wrapper, children: (selectedWorkflowGraph?.items || allSnapshots)?.map((snapshot) => ((0,jsx_runtime.jsx)(ExecutionCard_ExecutionCard, { snapshot: snapshot, isSelected: snapshot.id === selectedSnapshotId, handleOnClick: () => handleOnClick(snapshot), handleOnAddTagClick: handleOnAddTagClick }, snapshot.id))) })), showTagsModal && (0,jsx_runtime.jsx)(ManageTagsModal_ManageTagsModal, { currentSelectedTags: selectedSnapshot?.tags || [], handleOnClose: handleOnClose })] }));
};
/* harmony default export */ var SnapshotsTimeline_SnapshotsTimeline = (SnapshotsTimeline);

;// ./src/modules/Data/components/SnapshotsTimeline/index.ts


// EXTERNAL MODULE: ./node_modules/@mui/material/Pagination/Pagination.js + 8 modules
var Pagination = __webpack_require__(6378);
;// ./src/modules/Data/components/Pagination/PaginationWrapper.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var PaginationWrapper_module = ({"wrapper":"PaginationWrapper-module__wrapper"});
;// ./src/modules/Data/components/Pagination/PaginationWrapper.tsx







const PaginationWrapper = ({ defaultPage = 1, siblingCount = 0, boundaryCount = 2, }) => {
    const dispatch = useRootDispatch();
    const numberOfPages = (0,react_redux/* useSelector */.d4)(getTotalPages);
    const isLoading = (0,react_redux/* useSelector */.d4)(getIsLoadingSnapshots);
    return ((0,jsx_runtime.jsx)("div", { className: PaginationWrapper_module.wrapper, children: (0,jsx_runtime.jsx)(Pagination/* default */.A, { sx: {
                "& .Mui-selected": {
                    opacity: "initial",
                    color: "#2CCBE5",
                    backgroundColor: "transparent !important",
                },
            }, count: numberOfPages, defaultPage: defaultPage, siblingCount: siblingCount, boundaryCount: boundaryCount, disabled: isLoading, onChange: (event, page) => {
                dispatch(setPageNumber(page));
            } }) }));
};
/* harmony default export */ var Pagination_PaginationWrapper = (PaginationWrapper);

;// ./src/modules/Data/components/Pagination/index.ts


;// ./src/modules/Data/components/DataLeftPanel/DataLeftPanel.tsx













const defaultOptions = [
    {
        label: "Today",
        value: DateOption.Today,
    },
    {
        label: "Last 7 days",
        value: DateOption.LastWeek,
    },
    {
        label: "Last 30 days",
        value: DateOption.LastMonth,
    },
];
const sortOptions = [
    {
        label: "Date (Newest first)",
        value: SortType.Date
    },
    {
        label: "Name (A-Z)",
        value: SortType.Name
    },
    {
        label: "Result (Success First)",
        value: SortType.Status
    },
];
const DataLeftPanel = () => {
    const dispatch = useRootDispatch();
    const selectedWorkflow = (0,react_redux/* useSelector */.d4)(selectors_getSelectedWorkflow);
    const breadCrumbs = (0,react_redux/* useSelector */.d4)(getBreadCrumbs);
    const [selectedDateFilter, setSelectedDateFilter] = (0,react.useState)(undefined);
    const [selectedSortType, setSelectedSortType] = (0,react.useState)(SortType.Date);
    const [searchText, setSearchText] = (0,react.useState)("");
    const [fromDate, setFromDate] = (0,react.useState)("");
    const [toDate, setToDate] = (0,react.useState)("");
    const [selectedTags, setSelectedTags] = (0,react.useState)([]);
    let firstNavigationValue = undefined;
    if (breadCrumbs.length === 1) {
        firstNavigationValue = "← History";
    }
    else if (breadCrumbs.length >= 2) {
        firstNavigationValue = `← ${breadCrumbs[breadCrumbs.length - 2]}`;
    }
    const handleOnDateFilterSelect = (dateFilterType) => {
        setSelectedDateFilter(dateFilterType?.label);
        const today = new Date();
        const dateToString = (date) => {
            const year = date.getFullYear();
            const month = date.getMonth() + 1;
            const day = date.getDate();
            return `${year}-${("0" + month).slice(-2)}-${("0" + day).slice(-2)}`;
        };
        switch (dateFilterType?.value) {
            case DateOption.Today: {
                setFromDate(dateToString(today));
                setToDate(dateToString(today));
                break;
            }
            case DateOption.LastWeek: {
                const weekBefore = new Date(today);
                weekBefore.setDate(today.getDate() - 7);
                setFromDate(dateToString(weekBefore));
                setToDate(dateToString(today));
                break;
            }
            case DateOption.LastMonth: {
                const monthBefore = new Date(today);
                monthBefore.setMonth(today.getMonth() - 1);
                setFromDate(dateToString(monthBefore));
                setToDate(dateToString(today));
                break;
            }
        }
    };
    (0,react.useEffect)(() => {
        dispatch(setSnapshotsFilters({
            tags: selectedTags,
            sortType: selectedSortType,
            searchString: searchText,
            minDate: fromDate,
            maxDate: toDate,
        }));
    }, [selectedSortType, searchText, fromDate, toDate, selectedTags]);
    const handleOnDateFilterRemove = (filterName) => {
        setSelectedDateFilter(undefined);
        if (filterName === "From") {
            setFromDate("");
        }
        else if (filterName === "To") {
            setToDate("");
        }
        else {
            setFromDate("");
            setToDate("");
        }
    };
    const handleGoingBackOneLevel = () => {
        dispatch(goBackOneLevel());
    };
    const handleOnSortSelect = (sortType) => {
        setSelectedSortType(sortType);
    };
    const handleSetFrom = (from) => {
        setSelectedDateFilter(undefined);
        setFromDate(from);
    };
    const handleSetTo = (to) => {
        setSelectedDateFilter(undefined);
        setToDate(to);
    };
    const handleToggleTag = (tagName) => {
        const indexOfSelectedTag = selectedTags.indexOf(tagName);
        if (indexOfSelectedTag === -1) {
            setSelectedTags([...selectedTags, tagName]);
        }
        else {
            setSelectedTags([...selectedTags.filter((tag) => tag !== tagName)]);
        }
    };
    return ((0,jsx_runtime.jsx)("div", { className: DataLeftPanel_module.dataWrapper, children: (0,jsx_runtime.jsxs)("div", { className: DataLeftPanel_module.data, children: [(0,jsx_runtime.jsxs)("div", { className: DataLeftPanel_module.headerPanel, children: [selectedWorkflow && ((0,jsx_runtime.jsxs)("h2", { children: [(0,jsx_runtime.jsx)("span", { className: DataLeftPanel_module.titleArrow, onClick: () => handleGoingBackOneLevel(), children: firstNavigationValue }), breadCrumbs.length > 0 && ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)("span", { className: DataLeftPanel_module.titleSlash, children: "/" }), (0,jsx_runtime.jsx)("span", { className: DataLeftPanel_module.title, children: selectedWorkflow?.metadata?.name })] }))] })), !selectedWorkflow && (0,jsx_runtime.jsx)("h2", { children: "Execution History" }), (0,jsx_runtime.jsxs)("div", { className: DataLeftPanel_module.searchFilterContainer, children: [(0,jsx_runtime.jsx)(SearchField_SearchField, { placeholder: "Search executions...", value: searchText, onChange: setSearchText, debounceMs: 500 }), (0,jsx_runtime.jsx)(DateFilter_DateFilter, { options: defaultOptions, from: fromDate, to: toDate, setFrom: handleSetFrom, setTo: handleSetTo, onSelect: handleOnDateFilterSelect }), (0,jsx_runtime.jsx)(SortButton_SortButton, { options: sortOptions, onSelect: handleOnSortSelect }, "sortFilter"), (0,jsx_runtime.jsx)(TagFilter_TagFilter, { selectedTags: selectedTags, handleToggleTag: handleToggleTag }, "tagFilter")] }), (0,jsx_runtime.jsxs)("div", { className: classNames(DataLeftPanel_module.searchFilterContainer, DataLeftPanel_module.wrapAppliedFilters), children: [selectedDateFilter &&
                                    (0,jsx_runtime.jsx)(AppliedFilterLabel_AppliedFilterLabel, { value: selectedDateFilter, onRemove: handleOnDateFilterRemove, label: "Date" }), !selectedDateFilter && fromDate &&
                                    (0,jsx_runtime.jsx)(AppliedFilterLabel_AppliedFilterLabel, { value: fromDate, onRemove: () => handleOnDateFilterRemove("From"), label: "From" }), !selectedDateFilter && toDate &&
                                    (0,jsx_runtime.jsx)(AppliedFilterLabel_AppliedFilterLabel, { value: toDate, onRemove: () => handleOnDateFilterRemove("To"), label: "To" }), selectedTags.map(tag => (0,jsx_runtime.jsx)(AppliedFilterLabel_AppliedFilterLabel, { value: tag, showDot: true, dotColor: stringToHexColor(tag), onRemove: () => handleToggleTag(tag) }))] })] }), (0,jsx_runtime.jsx)("div", { className: DataLeftPanel_module.snapshotsWrapper, children: (0,jsx_runtime.jsx)(SnapshotsTimeline_SnapshotsTimeline, {}) }), !selectedWorkflow && (0,jsx_runtime.jsx)(Pagination_PaginationWrapper, {})] }) }));
};
/* harmony default export */ var DataLeftPanel_DataLeftPanel = (DataLeftPanel);

;// ./src/modules/Data/components/DataLeftPanel/index.ts


;// ./src/modules/Data/components/DataRightPanel/DataRightPanel.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var DataRightPanel_module = ({"viewer":"DataRightPanel-module__viewer","floatingRerunButton":"DataRightPanel-module__floatingRerunButton"});
;// ./src/components/VerticalResizableComponent/helpers.tsx
const snapshotMetadataToParameters = (metadata) => {
    if (!metadata)
        return {};
    return {
        description: metadata.description,
        data_path: metadata.data_path,
        name: metadata.name,
        run_start: metadata.run_start,
        run_end: metadata.run_end,
        run_duration: metadata.run_duration,
        status: metadata.status,
    };
};

;// ./src/modules/Data/components/DataRightPanel/GraphView.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var GraphView_module = ({"contentArea":"GraphView-module__contentArea","contentMain":"GraphView-module__contentMain","graphVisualization":"GraphView-module__graphVisualization","graphExecSummary":"GraphView-module__graphExecSummary","summaryStat":"GraphView-module__summaryStat","error":"GraphView-module__error","success":"GraphView-module__success","statLabel":"GraphView-module__statLabel","statValue":"GraphView-module__statValue","mainLayout":"GraphView-module__mainLayout","graphCanvasContainer":"GraphView-module__graphCanvasContainer","sidePanel":"GraphView-module__sidePanel","sidePanelHeader":"GraphView-module__sidePanelHeader","sidePanelTitle":"GraphView-module__sidePanelTitle","qubitList":"GraphView-module__qubitList"});
;// ./src/modules/Data/components/DataRightPanel/QubitStatusList.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var QubitStatusList_module = ({"card":"QubitStatusList-module__card","cardHeader":"QubitStatusList-module__cardHeader","qubitName":"QubitStatusList-module__qubitName","status":"QubitStatusList-module__status","statusDot":"QubitStatusList-module__statusDot","statusText":"QubitStatusList-module__statusText","success":"QubitStatusList-module__success","failure":"QubitStatusList-module__failure","failureInfo":"QubitStatusList-module__failureInfo","failureLabel":"QubitStatusList-module__failureLabel","failureValue":"QubitStatusList-module__failureValue"});
;// ./src/modules/Data/components/DataRightPanel/QubitStatusList.tsx



const QubitStatusList = ({ outcomes }) => {
    if (!outcomes) {
        return null;
    }
    return ((0,jsx_runtime.jsx)(jsx_runtime.Fragment, { children: Object.entries(outcomes).map(([qubitName, data]) => {
            const isFailure = data.status === "failure";
            return ((0,jsx_runtime.jsxs)("div", { className: QubitStatusList_module.card, children: [(0,jsx_runtime.jsxs)("div", { className: QubitStatusList_module.cardHeader, children: [(0,jsx_runtime.jsx)("span", { className: QubitStatusList_module.qubitName, children: qubitName }), (0,jsx_runtime.jsxs)("div", { className: QubitStatusList_module.status, children: [(0,jsx_runtime.jsx)("span", { className: `${QubitStatusList_module.statusDot} ${isFailure ? QubitStatusList_module.failure : QubitStatusList_module.success}` }), (0,jsx_runtime.jsx)("span", { className: `${QubitStatusList_module.statusText} ${isFailure ? QubitStatusList_module.failure : QubitStatusList_module.success}`, children: data.status?.toUpperCase() })] })] }), isFailure && data.failed_on && ((0,jsx_runtime.jsxs)("div", { className: QubitStatusList_module.failureInfo, children: [(0,jsx_runtime.jsx)("div", { className: QubitStatusList_module.failureLabel, children: "Failed on" }), (0,jsx_runtime.jsx)("div", { className: QubitStatusList_module.failureValue, children: data.failed_on })] }))] }, qubitName));
        }) }));
};
/* harmony default export */ var DataRightPanel_QubitStatusList = (QubitStatusList);

;// ./src/modules/Data/components/DataRightPanel/GraphView.tsx









const GraphView = () => {
    const dispatch = useRootDispatch();
    const selectedSnapshotWithWorkflowType = (0,react_redux/* useSelector */.d4)(getSelectedSnapshot);
    const selectedWorkflow = (0,react_redux/* useSelector */.d4)(selectors_getSelectedWorkflow);
    const breadCrumbs = (0,react_redux/* useSelector */.d4)(getBreadCrumbs);
    const jsonData = (0,react_redux/* useSelector */.d4)(getJsonData);
    // const nodesFailed = selectedSnapshotWithWorkflowType?.nodes_completed !== selectedSnapshotWithWorkflowType?.nodes_total;
    // const nodesSuccess = !nodesFailed && selectedSnapshotWithWorkflowType?.nodes_completed !== null;
    const qubitsFailed = selectedSnapshotWithWorkflowType?.qubits_completed !== selectedSnapshotWithWorkflowType?.qubits_total;
    const qubitsSuccess = !qubitsFailed && selectedSnapshotWithWorkflowType?.qubits_completed !== null;
    const handleOnNodeClick = (name) => {
        const id = selectedWorkflow?.items?.find(node => node.metadata.name === name)?.id;
        if (id)
            dispatch(setSelectedNodeInWorkflowId(id));
    };
    const handleOnNodeSecondClick = (name, isWorkflow) => {
        const id = selectedWorkflow?.items?.find(node => node.metadata.name === name)?.id;
        if (isWorkflow) {
            if (breadCrumbs.length === 0) {
                dispatch(actions_setSubgraphForward(selectedSnapshotWithWorkflowType?.metadata?.name));
                dispatch(setSelectedWorkflow(selectedSnapshotWithWorkflowType));
            }
            else {
                dispatch(actions_setSubgraphForward(name));
                // dispatch(setSelectedWorkflow(selectedSnapshotWithWorkflowType));
                dispatch(setSelectedWorkflowFromBreadcrumbs());
            }
            if (id)
                dispatch(setSelectedNodeInWorkflowId(id));
            dispatch(setSelectedSnapshotInSnapshotList(name));
        }
        else {
            if (selectedWorkflow?.metadata?.name !== selectedSnapshotWithWorkflowType?.metadata?.name) {
                dispatch(actions_setSubgraphForward(selectedSnapshotWithWorkflowType?.metadata?.name));
                dispatch(setSelectedWorkflow(selectedSnapshotWithWorkflowType));
            }
            dispatch(setSelectedSnapshotInSnapshotList(name));
            if (id)
                dispatch(setSelectedNodeInWorkflowId(id));
        }
    };
    return ((0,jsx_runtime.jsx)("div", { className: GraphView_module.contentArea, id: "contentArea", children: (0,jsx_runtime.jsx)("div", { className: GraphView_module.contentMain, children: (0,jsx_runtime.jsxs)("div", { className: GraphView_module.graphVisualization, children: [(0,jsx_runtime.jsx)("div", { className: GraphView_module.graphExecSummary, children: (0,jsx_runtime.jsxs)("div", { className: classNames(GraphView_module.summaryStat, qubitsFailed && GraphView_module.error, qubitsSuccess && GraphView_module.success), children: [(0,jsx_runtime.jsx)("div", { className: GraphView_module.statLabel, children: "Qubits Success" }), (0,jsx_runtime.jsxs)("div", { className: GraphView_module.statValue, children: [selectedSnapshotWithWorkflowType?.qubits_completed ?? "unavailable", "/", selectedSnapshotWithWorkflowType?.qubits_total ?? "unavailable"] })] }) }), (0,jsx_runtime.jsxs)("div", { className: GraphView_module.mainLayout, children: [(0,jsx_runtime.jsx)("div", { className: GraphView_module.graphCanvasContainer, children: (0,jsx_runtime.jsx)(Graph_Graph, { selectedWorkflowName: breadCrumbs[0] ?? selectedSnapshotWithWorkflowType?.metadata?.name, selectedNodeNameInWorkflow: selectedSnapshotWithWorkflowType?.metadata?.name, onNodeClick: handleOnNodeClick, subgraphBreadcrumbs: selectedSnapshotWithWorkflowType?.metadata?.name
                                        ? [...breadCrumbs.slice(1), selectedSnapshotWithWorkflowType?.metadata?.name]
                                        : breadCrumbs.slice(1), onNodeSecondClick: handleOnNodeSecondClick }) }), (0,jsx_runtime.jsxs)("div", { className: GraphView_module.sidePanel, children: [(0,jsx_runtime.jsx)("div", { className: GraphView_module.sidePanelHeader, children: (0,jsx_runtime.jsx)("div", { className: GraphView_module.sidePanelTitle, children: "By Qubit" }) }), (0,jsx_runtime.jsx)("div", { className: GraphView_module.qubitList, children: (0,jsx_runtime.jsx)(DataRightPanel_QubitStatusList, { outcomes: jsonData?.outcomes }) })] })] })] }) }) }));
};
/* harmony default export */ var DataRightPanel_GraphView = (GraphView);

;// ./src/modules/Data/components/DataRightPanel/DataRightPanel.tsx











const DataRightPanel = () => {
    const dispatch = useRootDispatch();
    const result = (0,react_redux/* useSelector */.d4)(getResult);
    const selectedSnapshot = (0,react_redux/* useSelector */.d4)(getSelectedSnapshot);
    const jsonData = (0,react_redux/* useSelector */.d4)(getJsonData);
    const breadcrumbs = (0,react_redux/* useSelector */.d4)(getBreadCrumbs);
    const isNodeRunning = !!(0,react_redux/* useSelector */.d4)(getRunStatusIsRunning);
    const isSelectedSnapshotTypeOfWorkflow = selectedSnapshot?.metadata.type_of_execution?.toLocaleLowerCase() === "workflow";
    const showRunButton = selectedSnapshot && breadcrumbs.length === 0;
    const handleOnClickRunButton = () => {
        if (selectedSnapshot?.metadata.type_of_execution === "node") {
            dispatch(runNodeOfSelectedSnapshot());
        }
        else if (selectedSnapshot?.metadata.type_of_execution === "workflow") {
            dispatch(runWorkflowOfSelectedSnapshot());
        }
    };
    if (isSelectedSnapshotTypeOfWorkflow) {
        return ((0,jsx_runtime.jsxs)(jsx_runtime.Fragment, { children: [(0,jsx_runtime.jsx)(DataRightPanel_GraphView, {}), showRunButton && ((0,jsx_runtime.jsx)("button", { disabled: isNodeRunning, title: isNodeRunning ? "Node is already running" : "", className: DataRightPanel_module.floatingRerunButton, id: "floatingRerunBtn", onClick: handleOnClickRunButton, children: "\u25B6 Rerun" }))] }));
    }
    return ((0,jsx_runtime.jsxs)("div", { className: DataRightPanel_module.viewer, children: [(0,jsx_runtime.jsx)(VerticalResizableComponent_VerticalResizableComponent, { tabData: {
                    metadata: snapshotMetadataToParameters(selectedSnapshot?.metadata),
                    parameters: jsonData?.parameters?.model ?? {},
                } }), result && (0,jsx_runtime.jsx)(JSONEditor, { title: "RESULTS", jsonDataProp: result, height: "100%" }), showRunButton && ((0,jsx_runtime.jsx)("button", { disabled: isNodeRunning, title: isNodeRunning ? "Node is already running" : "", className: DataRightPanel_module.floatingRerunButton, id: "floatingRerunBtn", onClick: handleOnClickRunButton, children: "\u25B6 Rerun" }))] }));
};
/* harmony default export */ var DataRightPanel_DataRightPanel = (DataRightPanel);

;// ./src/modules/Data/components/DataRightPanel/index.ts


;// ./src/modules/Data/index.ts




;// ./src/modules/AppRoutes/ModulesRegistry.ts







const DATA_KEY = "execution-history";
const NODES_KEY = "nodes";
const PROJECT_KEY = "project";
const GRAPH_LIBRARY_KEY = "graph-library";
const GRAPH_STATUS_KEY = "graph-status";
const HELP_KEY = "help";
const TOGGLE_SIDEBAR_KEY = "toggle";
const ModulesRegistry = [
    {
        keyId: NODES_KEY,
        path: "nodes",
        Component: Nodes,
        menuItem: {
            sideBarTitle: "Node Library",
            title: "Run calibration node",
            icon: NodeLibraryIcon,
            dataCy: utils_cyKeys.NODES_TAB,
        },
    },
    {
        keyId: GRAPH_LIBRARY_KEY,
        path: "GRAPH_LIBRARY",
        Component: GraphLibrary_GraphLibrary,
        menuItem: {
            sideBarTitle: "Graph Library",
            title: "Run calibration graph",
            icon: Icons_GraphLibraryIcon,
            dataCy: utils_cyKeys.CALIBRATION_TAB,
        },
    },
    {
        keyId: GRAPH_STATUS_KEY,
        path: "graph-status",
        Component: GraphStatus_GraphStatus,
        menuItem: {
            sideBarTitle: "Graph Status",
            title: "Graph Status",
            icon: Icons_GraphStatusIcon,
            dataCy: utils_cyKeys.NODES_TAB,
        },
    },
    {
        keyId: DATA_KEY,
        path: "execution-history",
        Component: Data_Data,
        menuItem: {
            sideBarTitle: "History",
            title: "",
            icon: Icons_DataIcon,
            dataCy: utils_cyKeys.DATA_TAB,
        },
    },
    {
        keyId: PROJECT_KEY,
        path: "projects",
        Component: modules_Project_Project,
        menuItem: {
            sideBarTitle: "Projects",
            title: "Projects",
            icon: Icons_ProjectIcon,
            dataCy: utils_cyKeys.PROJECT_TAB,
            atBottom: true,
        },
    },
    {
        keyId: HELP_KEY,
        path: "help",
        Component: Data_Data,
        menuItem: {
            sideBarTitle: "Help",
            icon: HelpIcon,
            title: "Help",
            dataCy: utils_cyKeys.HELP_TAB,
            atBottom: true,
        },
    },
    {
        keyId: TOGGLE_SIDEBAR_KEY,
        path: "toggle",
        Component: Data_Data,
        menuItem: {
            dataCy: utils_cyKeys.TOGGLE_SIDEBAR,
            atBottom: true,
        },
    },
];
const modulesMap = {};
ModulesRegistry.map((el) => {
    modulesMap[el.keyId] = el;
});
/* harmony default export */ var AppRoutes_ModulesRegistry = (modulesMap);
const bottomMenuItems = ModulesRegistry.filter((m) => m.menuItem && m.menuItem.atBottom);
const menuItems = ModulesRegistry.filter((m) => m.menuItem && !m.menuItem.atBottom);

;// ./src/modules/AppRoutes/components/MainLayout/MainLayout.tsx











const MainLayout = ({ children }) => {
    const activePage = (0,react_redux/* useSelector */.d4)(getActivePage);
    const isDataPage = activePage === DATA_KEY;
    return ((0,jsx_runtime.jsxs)("div", { className: Layout_module.sidebarWrapper, children: [(0,jsx_runtime.jsx)(SidebarMenu_SidebarMenu, {}), isDataPage ? ((0,jsx_runtime.jsx)(Data_Data, {})) : ((0,jsx_runtime.jsxs)("div", { className: Layout_module.titlebarWrapper, children: [(0,jsx_runtime.jsx)(TopbarMenu_TitleBarMenu, {}), (0,jsx_runtime.jsxs)("div", { className: Layout_module.rightsidePanelWrapper, children: [(0,jsx_runtime.jsx)("div", { className: Layout_module.contentWrapper, children: children }), (0,jsx_runtime.jsx)(RightSidePanel, {})] })] })), (0,jsx_runtime.jsx)(Toast_Toast, {}), (0,jsx_runtime.jsx)(WebSocketConnectionErrorDialog_WebSocketConnectionErrorDialog, {})] }));
};
/* harmony default export */ var MainLayout_MainLayout = (MainLayout);

;// ./src/modules/AppRoutes/components/MainPage/MainPage.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var MainPage_module = ({"pageWrapper":"MainPage-module__pageWrapper","active":"MainPage-module__active","emptyPlaceholder":"MainPage-module__emptyPlaceholder"});
;// ./src/modules/AppRoutes/components/MainPage/MainPage.tsx


















const PageWrapper = ({ nodeKey, children }) => {
    const activePage = (0,react_redux/* useSelector */.d4)(getActivePage);
    const openedOncePages = (0,react_redux/* useSelector */.d4)(getOpenedOncePages);
    return openedOncePages.includes(nodeKey) ? ((0,jsx_runtime.jsx)("div", { className: classNames(MainPage_module.pageWrapper, activePage === nodeKey && MainPage_module.active), children: children })) : ((0,jsx_runtime.jsx)(jsx_runtime.Fragment, {}));
};
const MainPage = () => {
    const isAuthorized = (0,react_redux/* useSelector */.d4)(getIsAuthorized);
    const dispatch = useRootDispatch();
    const openedOncePages = (0,react_redux/* useSelector */.d4)(getOpenedOncePages);
    const activeProject = (0,react_redux/* useSelector */.d4)(getActiveProject);
    const shouldGoToProjectPage = (0,react_redux/* useSelector */.d4)(getShouldGoToProjectPage);
    const navigate = (0,dist/* useNavigate */.Zp)();
    (0,react.useEffect)(() => {
        const checkVersion = async () => {
            const localVersion = localStorage.getItem("appVersion");
            try {
                const response = await fetch("manifest.json");
                const { version } = await response.json();
                if (localVersion && version !== localVersion) {
                    handleRefresh();
                }
                // Update the local storage with the current version
                localStorage.setItem("appVersion", version);
            }
            catch (error) {
                console.error("Failed to fetch version:", error);
            }
        };
        checkVersion();
    }, []);
    const handleRefresh = () => {
        try {
            // @ts-expect-error: Small fix to force hard refresh in order to clear the cache
            window.location.reload(true); // Hard refresh to clear cache
        }
        catch (error) {
            console.error("Failed to do the hard refresh and clear the cache:", error);
        }
    };
    (0,react.useEffect)(() => {
        if (!isAuthorized) {
            navigate(LOGIN_URL);
        }
        else if (!activeProject || shouldGoToProjectPage) {
            dispatch(setActivePage(PROJECT_KEY));
        }
        else {
            dispatch(setActivePage(NODES_KEY));
        }
    }, [isAuthorized, activeProject, shouldGoToProjectPage]);
    return ((0,jsx_runtime.jsxs)(MainLayout_MainLayout, { children: [(0,jsx_runtime.jsx)(PageWrapper, { nodeKey: NODES_KEY, children: (0,jsx_runtime.jsx)(Nodes, {}) }), (0,jsx_runtime.jsx)(PageWrapper, { nodeKey: GRAPH_LIBRARY_KEY, children: (0,jsx_runtime.jsx)(GraphLibrary_GraphLibrary, {}) }), (0,jsx_runtime.jsx)(PageWrapper, { nodeKey: GRAPH_STATUS_KEY, children: (0,jsx_runtime.jsx)(GraphStatus_GraphStatus, {}) }), (0,jsx_runtime.jsx)(PageWrapper, { nodeKey: PROJECT_KEY, children: (0,jsx_runtime.jsx)(modules_Project_Project, {}) }), openedOncePages.length === 0 && ((0,jsx_runtime.jsx)("div", { className: MainPage_module.emptyPlaceholder, children: (0,jsx_runtime.jsx)(Icons_QUAlibrateLogoIcon, { height: 200, width: 400 }) }))] }));
};
/* harmony default export */ var MainPage_MainPage = (MainPage);

;// ./src/modules/Login/Login.module.scss
// extracted by mini-css-extract-plugin
/* harmony default export */ var Login_module = ({"content":"Login-module__content","welcomeInfo":"Login-module__welcomeInfo","wave":"Login-module__wave","welcomeContent":"Login-module__welcomeContent","rightPart":"Login-module__rightPart","version":"Login-module__version","form":"Login-module__form","title":"Login-module__title","inputWrapper":"Login-module__inputWrapper","input":"Login-module__input","loginButton":"Login-module__loginButton","errorMsg":"Login-module__errorMsg"});
;// ./src/modules/Login/welcomeWaves.png
var welcomeWaves_namespaceObject = __webpack_require__.p + "assets/welcomeWaves.346ba70b.png";
;// ./src/modules/Login/Login.tsx








const Login = () => {
    const [password, setPassword] = (0,react.useState)("");
    const login = useLogin();
    const authError = (0,react_redux/* useSelector */.d4)(getAuthError);
    const validate = (value) => {
        if (value.length < 8) {
            return false;
        }
    };
    (0,react.useEffect)(() => {
        validate(password);
    }, [password]);
    const handleLogin = (0,react.useCallback)(() => {
        login(password);
    }, [password]);
    const handleLoginByEnter = (event) => {
        if (event.key === "Enter") {
            handleLogin();
        }
    };
    const inputDefaultProps = { onKeyUp: handleLoginByEnter };
    return ((0,jsx_runtime.jsxs)("div", { className: Login_module.content, children: [(0,jsx_runtime.jsx)(WelcomeInfo, {}), (0,jsx_runtime.jsxs)("div", { className: Login_module.rightPart, children: [(0,jsx_runtime.jsx)("div", { className: Login_module.version }), (0,jsx_runtime.jsxs)("div", { className: Login_module.form, onKeyUp: handleLoginByEnter, children: [(0,jsx_runtime.jsx)("div", { className: Login_module.title, children: "Login" }), (0,jsx_runtime.jsx)(Input_InputField, { inputClassName: Login_module.input, className: Login_module.inputWrapper, onChange: setPassword, type: "password", label: "Password", value: password, placeholder: "", ...inputDefaultProps }), (0,jsx_runtime.jsx)(Button_BlueButton, { className: Login_module.loginButton, onClick: handleLogin, ...inputDefaultProps, isBig: true, children: "Log In" }), (0,jsx_runtime.jsx)("div", { className: Login_module.errorMsg, children: authError })] }), (0,jsx_runtime.jsx)("div", {})] })] }));
};
function WelcomeInfo() {
    return ((0,jsx_runtime.jsxs)("div", { className: Login_module.welcomeInfo, children: [(0,jsx_runtime.jsx)("img", { src: welcomeWaves_namespaceObject, alt: "", className: Login_module.wave }), (0,jsx_runtime.jsxs)("div", { className: Login_module.welcomeContent, children: [(0,jsx_runtime.jsx)(Icons_QUAlibrateLogoIcon, {}), (0,jsx_runtime.jsx)("div", { children: "Welcome to QUAlibrate!" })] })] }));
}

;// ./src/modules/Login/index.ts


;// ./src/modules/AppRoutes/AppRoutes.tsx















const useInitApp = () => {
    useLogin();
    useInitNodes();
    useInitProjects();
    useInitGraphs();
    useInitWebSocket();
    useInitSnapshots();
};
const ProtectedRoute = ({ children }) => {
    const isAuthorized = (0,react_redux/* useSelector */.d4)(getIsAuthorized);
    const triedLoginWithEmptyString = (0,react_redux/* useSelector */.d4)(getIsTriedLoginWithEmptyString);
    if (!isAuthorized) {
        if (!triedLoginWithEmptyString) {
            return (0,jsx_runtime.jsx)(LoaderPage, {});
        }
        return (0,jsx_runtime.jsx)(dist/* Navigate */.C5, { to: LOGIN_URL, replace: true });
    }
    return children;
};
const AppRoutes = () => {
    useInitApp();
    return ((0,jsx_runtime.jsx)(jsx_runtime.Fragment, { children: (0,jsx_runtime.jsxs)(dist/* Routes */.BV, { children: [(0,jsx_runtime.jsx)(dist/* Route */.qh, { path: LOGIN_URL, element: (0,jsx_runtime.jsx)(Login, {}) }), (0,jsx_runtime.jsx)(dist/* Route */.qh, { path: HOME_URL, element: (0,jsx_runtime.jsx)(ProtectedRoute, { children: (0,jsx_runtime.jsx)(MainPage_MainPage, {}) }) }), (0,jsx_runtime.jsx)(dist/* Route */.qh, { path: "*", element: (0,jsx_runtime.jsx)(ProtectedRoute, { children: (0,jsx_runtime.jsx)(dist/* Navigate */.C5, { to: "/" }) }) })] }) }));
};
/* harmony default export */ var AppRoutes_AppRoutes = (AppRoutes);

;// ./src/modules/AppRoutes/index.ts




// EXTERNAL MODULE: ./node_modules/react-router-dom/dist/index.js
var react_router_dom_dist = __webpack_require__(4976);
// EXTERNAL MODULE: ./node_modules/react-dom/client.js
var client = __webpack_require__(5338);
;// ./src/index.tsx











const RouterProvider =  false ? 0 : react_router_dom_dist/* BrowserRouter */.Kd;
const Application = () => {
    (0,react.useEffect)(updateColorTheme, []);
    return ((0,jsx_runtime.jsx)(react_redux/* Provider */.Kq, { store: stores, children: (0,jsx_runtime.jsx)(GlobalThemeContextProvider, { children: (0,jsx_runtime.jsx)(RouterProvider, { children: (0,jsx_runtime.jsx)(AppRoutes_AppRoutes, {}) }) }) }));
};
const container = document.getElementById("root");
if (container) {
    const root = (0,client/* createRoot */.H)(container);
    root.render((0,jsx_runtime.jsx)(react.StrictMode, { children: (0,jsx_runtime.jsx)(Application, {}) }));
}


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, [644,678,96], function() { return __webpack_exec__(8689); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.50487c2e.js.map