import uvicorn
from fastapi import FastAPI

from qualibrate.runner.api.middleware.process_time import ProcessTimeMiddleware
from qualibrate.runner.api.routes import base_router
from qualibrate.runner.api.sockets import base_ws_router
from qualibrate.runner.core.app.lifespan import app_lifespan

app = FastAPI(lifespan=app_lifespan)
app.add_middleware(ProcessTimeMiddleware)
app.include_router(base_router)
app.include_router(base_ws_router)


def main(port: int, reload: bool, log_level: str = "info") -> None:
    uvicorn.run("qualibrate.runner.app:app", port=port, reload=reload, log_level=log_level)


if __name__ == "__main__":
    main(port=8002, reload=False)
