# quality-analysis-cli

🔍 AI-powered Python code quality and security analyzer using Groq LLM.

## Features

- 🤖 LLM-powered code analysis using Groq (Llama 3.1)
- 🔴 Severity classification (High, Medium, Low)
- 📊 Quality scoring (0-100)
- 🎨 Beautiful terminal reports with Rich
- 🚀 CI/CD integration support (exits with code 1 on high-severity issues)

## Installation

## Quick Start

### 1. Install the package
```bash
pip install quality-analysis-cli

### 2. Get a Groq API Key
Go to console.groq.com
Create a free account and generate an API key

###3. Navigate to your project folder
cd /path/to/your/project


###4. Run the scan
## Usage

### Basic Scan
```bash
quality-analysis-cli scan <path>


# Scan a single file
quality-analysis-cli scan main.py

# Scan a directory
quality-analysis-cli scan ./src

# Scan with custom API key
quality-analysis-cli scan ./src --api-key YOUR_GROQ_API_KEY

# Exclude specific patterns
quality-analysis-cli scan ./src --exclude "tests,__pycache__"

# Verbose output
quality-analysis-cli scan ./src --verbose

# Skip confirmation prompt for large scans
quality-analysis-cli scan ./src --yes


5. View your report
The tool will display a quality score (0-100) with issues grouped by severity:

🔴 High - Critical issues to fix immediately
🟡 Medium - Should be addressed soon
🟢 Low - Minor improvements