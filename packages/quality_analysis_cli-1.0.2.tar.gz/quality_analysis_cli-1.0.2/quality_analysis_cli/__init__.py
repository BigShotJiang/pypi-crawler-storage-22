"""
Quality Analysis CLI - AI-powered Python code quality analyzer.
"""

__version__ = "1.0.0"
__author__ = "Mohana Krishna"