"""CLI entry point for quality-analysis-cli."""
import typer
from pathlib import Path
from typing import List, Optional
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn

from quality_analysis_cli.scanner.file_collector import collect_python_files
from quality_analysis_cli.scanner.snippet_extractor import extract_snippets
from quality_analysis_cli.llm.analyzer import analyze_snippets
from quality_analysis_cli.evaluator.scoring import calculate_score, get_grade, has_critical_issues, count_by_severity
from quality_analysis_cli.report.console import print_report

app = typer.Typer(
    name="quality-analysis-cli",
    help="AI-powered code quality and security analysis tool.",
    add_completion=False,
)
console = Console()


def version_callback(value: bool):
    """Print version and exit."""
    if value:
        console.print("quality-analysis-cli version 0.1.0")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None, "--version", "-V", callback=version_callback, is_eager=True,
        help="Show version and exit."
    ),
):
    """Quality Analysis CLI - AI-powered code quality scanner."""
    pass


@app.command()
def scan(
    repo_path: Path = typer.Argument(
        ...,
        help="Path to the repository to scan.",
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
    ),
    max_files: int = typer.Option(
        30,  # Reduced from 50 for faster scans
        "--max-files", "-m",
        help="Maximum number of files to scan.",
        min=1,
        max=500,
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose", "-v",
        help="Enable verbose output.",
    ),
    exclude: Optional[List[str]] = typer.Option(
        None,
        "--exclude", "-e",
        help="Additional directories to exclude (can be used multiple times).",
    ),
    yes: bool = typer.Option(
        False,
        "--yes", "-y",
        help="Skip confirmation prompt for large scans.",
    ),
):
    """Scan a repository for code quality and security issues."""
    
    if verbose:
        console.print(f"Scanning: {repo_path}")
        console.print(f"Max files: {max_files}")
        if exclude:
            console.print(f"Extra excludes: {', '.join(exclude)}")
    
    # Collect Python files
    extra_excludes = list(exclude) if exclude else []
    files = collect_python_files(repo_path, max_files=max_files, extra_excludes=extra_excludes)
    
    if not files:
        console.print("[yellow]No Python files found in the specified path.[/yellow]")
        raise typer.Exit(code=0)
    
    console.print(f"Found {len(files)} Python files")
    
    # Extract code snippets
    snippets = []
    for file_path in files:
        snippets.extend(extract_snippets(file_path))

    console.print(f"Extracted {len(snippets)} code snippets")
    
    if not snippets:
        console.print("[yellow]No code snippets extracted for analysis.[/yellow]")
        raise typer.Exit(code=0)
    
    # Estimate time (~2 seconds per snippet for API calls)
    estimated_seconds = len(snippets) * 2
    estimated_minutes = estimated_seconds / 60
    
    console.print(f"[dim]Estimated time: {estimated_minutes:.1f} minutes ({estimated_seconds} seconds)[/dim]")
    
    # Confirmation for large scans
    if len(snippets) > 100 and not yes:
        console.print(f"\n[yellow]⚠️  Large scan detected: {len(snippets)} snippets[/yellow]")
        if not typer.confirm("This may take a while. Continue?", default=True):
            console.print("[dim]Scan cancelled.[/dim]")
            raise typer.Exit(code=0)
    
    # Analyze with progress bar
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Analyzing code with AI...", total=len(snippets))
        
        issues = analyze_snippets(
            snippets,
            verbose=verbose,
            progress_callback=lambda current, total, msg: (
                progress.update(task, completed=current, description=f"Analyzing: {msg[:50]}..." if len(msg) > 50 else f"Analyzing: {msg}")
            )
        )
    
    # Calculate results
    score = calculate_score(issues)
    grade = get_grade(score)
    severity_counts = count_by_severity(issues)
    
    # Print report
    print_report(
        repo_path=str(repo_path),
        files_scanned=len(files),
        score=score,
        grade=grade,
        severity_counts=severity_counts,
        issues=issues,
    )
    
    # Exit with error code if critical issues found
    if has_critical_issues(issues):
        raise typer.Exit(code=1)
    
    raise typer.Exit(code=0)


if __name__ == "__main__":
    app()
