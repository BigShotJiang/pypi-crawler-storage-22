"""
Evaluator module for scoring and issue classification.
"""

from quality_analysis_cli.evaluator.scoring import calculate_score, has_critical_issues

__all__ = ["calculate_score", "has_critical_issues"]
