"""
Scoring logic for code quality evaluation.
"""

from typing import List, Dict, Any

# Severity weights for score calculation
SEVERITY_WEIGHTS = {
    "high": 10,
    "medium": 5,
    "low": 2,
}


def calculate_score(issues: List[Dict[str, Any]]) -> int:
    """
    Calculate quality score from 0-100 based on issues found.
    
    Args:
        issues: List of issue dictionaries with 'severity' key
        
    Returns:
        Integer score from 0 to 100
    """
    if not issues:
        return 100
    
    total_deduction = 0
    
    for issue in issues:
        severity = issue.get("severity", "low").lower()
        weight = SEVERITY_WEIGHTS.get(severity, 2)
        total_deduction += weight
    
    # Cap deduction at 100
    total_deduction = min(total_deduction, 100)
    
    return max(0, 100 - total_deduction)


def get_grade(score: int) -> str:
    """
    Convert numeric score to letter grade.
    
    Args:
        score: Integer score from 0-100
        
    Returns:
        Letter grade (A, B, C, D, F)
    """
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "F"


def has_critical_issues(issues: List[Dict[str, Any]]) -> bool:
    """
    Check if any high-severity issues exist.
    
    Args:
        issues: List of issue dictionaries
        
    Returns:
        True if high-severity issues found
    """
    return any(
        issue.get("severity", "").lower() == "high" 
        for issue in issues
    )


def count_by_severity(issues: List[Dict[str, Any]]) -> Dict[str, int]:
    """
    Count issues by severity level.
    
    Args:
        issues: List of issue dictionaries
        
    Returns:
        Dictionary with severity counts
    """
    counts = {"high": 0, "medium": 0, "low": 0}
    
    for issue in issues:
        severity = issue.get("severity", "low").lower()
        if severity in counts:
            counts[severity] += 1
    
    return counts
