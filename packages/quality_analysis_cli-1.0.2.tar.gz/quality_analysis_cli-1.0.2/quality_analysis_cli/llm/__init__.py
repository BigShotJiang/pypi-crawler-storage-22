"""
LLM module for AI-powered code analysis.
"""

from quality_analysis_cli.llm.analyzer import analyze_snippets
from quality_analysis_cli.llm.groq_client import GroqClient

__all__ = ["analyze_snippets", "GroqClient"]
