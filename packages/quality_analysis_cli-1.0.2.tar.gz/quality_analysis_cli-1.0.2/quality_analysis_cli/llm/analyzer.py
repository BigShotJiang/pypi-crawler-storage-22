"""LLM-based code analyzer module."""
from typing import List, Tuple, Dict, Any, Optional, Callable

from quality_analysis_cli.llm.groq_client import GroqClient


def analyze_snippets(
    snippets: List[Tuple[str, str, str]],
    verbose: bool = False,
    progress_callback: Optional[Callable[[int, int, str], None]] = None,
) -> List[Dict[str, Any]]:
    """
    Analyze code snippets using LLM.
    
    Args:
        snippets: List of (file_path, snippet_name, code) tuples.
        verbose: Enable verbose output.
        progress_callback: Optional callback(current, total, message) for progress updates.
    
    Returns:
        List of detected issues.
    """
    client = GroqClient()
    issues: List[Dict[str, Any]] = []
    total = len(snippets)
    
    for i, (file_path, snippet_name, code) in enumerate(snippets, 1):
        # Update progress
        if progress_callback:
            progress_callback(i, total, f"{snippet_name}")
        
        try:
            result = client.analyze_code(
                code_snippet=code,
                snippet_name=snippet_name,  # ✅ correct
                file_path=file_path,
            )
            
            if result and result.get("issue_detected", False):
                issue = {
                    "file": file_path,
                    "snippet": snippet_name,
                    "category": result.get("category", "Unknown"),
                    "severity": result.get("severity", "low"),
                    "title": result.get("title", "Issue detected"),
                    "why_it_matters": result.get("why_it_matters", ""),
                    "how_to_fix": result.get("how_to_fix", ""),
                    "impact_if_ignored": result.get("impact_if_ignored", ""),
                }
                issues.append(issue)
                
                if verbose:
                    print(f"  Found: {issue['title']}")
        
        except Exception as e:
            if verbose:
                print(f"  Error analyzing {snippet_name}: {e}")
            continue
    
    return issues


def analyze_single_file(
    file_path: str,
    code: str,
    verbose: bool = False,
) -> List[Dict[str, Any]]:
    """
    Analyze a single file's code.
    
    Args:
        file_path: Path to the file.
        code: The file's source code.
        verbose: Enable verbose output.
    
    Returns:
        List of detected issues.
    """
    client = GroqClient()
    issues: List[Dict[str, Any]] = []
    
    try:
        result = client.analyze_code(
            code_snippet=code,
            file_path=file_path,
        )
        
        if result and result.get("issue_detected", False):
            issue = {
                "file": file_path,
                "snippet": "full_file",
                "category": result.get("category", "Unknown"),
                "severity": result.get("severity", "low"),
                "title": result.get("title", "Issue detected"),
                "why_it_matters": result.get("why_it_matters", ""),
                "how_to_fix": result.get("how_to_fix", ""),
                "impact_if_ignored": result.get("impact_if_ignored", ""),
            }
            issues.append(issue)
            
            if verbose:
                print(f"  Found: {issue['title']}")
    
    except Exception as e:
        if verbose:
            print(f"  Error analyzing file: {e}")
    
    return issues
