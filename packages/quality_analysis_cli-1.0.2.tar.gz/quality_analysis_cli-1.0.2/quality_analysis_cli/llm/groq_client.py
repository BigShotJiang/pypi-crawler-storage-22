"""
Groq LLM client for code quality analysis.
"""
import os
import json
from typing import Optional, Dict
from groq import Groq


SYSTEM_PROMPT = """You are a senior Python code reviewer. Your job is to analyze code snippets and identify REAL, CONCRETE issues only.

CRITICAL RULES:
1. Only report issues you are 100% certain about
2. If the code looks fine, respond with {"issue_detected": false}
3. Never hallucinate or make up issues
4. Focus on: security vulnerabilities, bugs, performance problems, and maintainability issues
5. Be conservative - it's better to miss an issue than report a false positive

You must respond ONLY with valid JSON in this exact format:
{
    "issue_detected": true/false,
    "category": "security|performance|maintainability|error_handling|best_practices",
    "severity": "high|medium|low",
    "title": "Brief issue title",
    "why_it_matters": "Why this is a problem",
    "how_to_fix": "Specific fix recommendation",
    "impact_if_ignored": "What happens if not fixed"
}

If no issue exists, respond with:
{"issue_detected": false}"""


class GroqClient:
    """Client for interacting with Groq API for code analysis."""
    
    def __init__(self):
        """Initialize the Groq client."""
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key:
            raise ValueError(
                "GROQ_API_KEY environment variable is not set. "
                "Please set it with: export GROQ_API_KEY='your-api-key'"
            )
        self.client = Groq(api_key=api_key)
        self.model = "llama-3.1-8b-instant"
    
    def analyze_code(
        self, 
        code_snippet: str, 
        snippet_name: str,
        file_path: Optional[str] = None
    ) -> Optional[Dict]:
        """
        Analyze a code snippet for quality issues.
        
        Args:
            code_snippet: The code to analyze
            snippet_name: Name/identifier of the snippet
            file_path: Optional path to the file containing the snippet
            
        Returns:
            Dictionary with issue details if found, None otherwise
        """
        try:
            # Truncate long snippets to avoid token limits
            lines = code_snippet.split('\n')
            if len(lines) > 15:
                truncated_lines = lines[:7] + ['    # ... truncated ...'] + lines[-3:]
                code_snippet = '\n'.join(truncated_lines)
            
            # Build context string
            context = f"Snippet name: {snippet_name}"
            if file_path:
                context += f"\nFile: {file_path}"
            
            user_prompt = (
                "Analyze this Python code snippet for quality issues:\n\n"
                "```python\n"
                f"{code_snippet}\n"
                "```\n\n"
                f"{context}\n\n"
                "Respond with JSON only. If no real issue exists, respond with: "
                '{"issue_detected": false}'
            )
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.1,
                max_tokens=500,
                response_format={"type": "json_object"}
            )
            
            result_text = response.choices[0].message.content.strip()
            result = json.loads(result_text)
            
            # Check if issue was detected
            if not result.get("issue_detected", False):
                return None
            
            # Validate required fields
            required_fields = ["category", "severity", "title", "why_it_matters", "how_to_fix"]
            if not all(field in result for field in required_fields):
                return None
            
            # Add file path to result if provided
            if file_path:
                result["file_path"] = file_path
            result["snippet_name"] = snippet_name
            
            return result
            
        except json.JSONDecodeError as e:
            print(f"  JSON parse error: {e}")
            return None
        except Exception as e:
            print(f"  Error analyzing {snippet_name}: {e}")
            return None


# Singleton instance
_client: Optional[GroqClient] = None


def get_groq_client() -> GroqClient:
    """Get or create the Groq client singleton."""
    global _client
    if _client is None:
        _client = GroqClient()
    return _client
