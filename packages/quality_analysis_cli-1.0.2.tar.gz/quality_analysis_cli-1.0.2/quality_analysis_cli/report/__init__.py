"""Report generation module."""

from quality_analysis_cli.report.console import print_report

__all__ = ["print_report"]
