"""Console report printer with rich formatting."""

from typing import Dict, List
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text


console = Console()


def get_grade_color(grade: str) -> str:
    """Get color for grade display."""
    colors = {
        "A": "green",
        "B": "blue", 
        "C": "yellow",
        "D": "orange1",
        "F": "red"
    }
    return colors.get(grade, "white")


def print_report(
    repo_path: str,
    files_scanned: int,
    score: int,
    grade: str,
    severity_counts: Dict[str, int],
    issues: List[Dict]
) -> None:
    """Print the analysis report to console."""
    
    # Header panel
    grade_color = get_grade_color(grade)
    
    header_text = Text()
    header_text.append("📁 Repository: ", style="bold")
    header_text.append(f"{repo_path}\n")
    header_text.append("📄 Files Scanned: ", style="bold")
    header_text.append(f"{files_scanned}\n")
    header_text.append("📊 Quality Score: ", style="bold")
    header_text.append(f"{score}/100 ", style=f"bold {grade_color}")
    header_text.append(f"(Grade: {grade})", style=f"bold {grade_color}")
    
    console.print(Panel(header_text, title="[bold blue]Code Quality Analysis[/bold blue]", border_style="blue"))
    
    # Severity summary
    severity_text = Text()
    severity_text.append("🔴 High: ", style="bold red")
    severity_text.append(f"{severity_counts.get('high', 0)}  ")
    severity_text.append("🟡 Medium: ", style="bold yellow")
    severity_text.append(f"{severity_counts.get('medium', 0)}  ")
    severity_text.append("🟢 Low: ", style="bold green")
    severity_text.append(f"{severity_counts.get('low', 0)}")
    
    console.print(Panel(severity_text, title="[bold]Issue Summary[/bold]", border_style="cyan"))
    
    # Issues table
    if issues:
        table = Table(title="Issues Found", show_header=True, header_style="bold magenta")
        table.add_column("Severity", style="bold", width=10)
        table.add_column("Category", width=15)
        table.add_column("Title", width=30)
        table.add_column("File", width=40)
        
        # Sort by severity
        severity_order = {"high": 0, "medium": 1, "low": 2}
        sorted_issues = sorted(issues, key=lambda x: severity_order.get(x.get("severity", "low"), 3))
        
        for issue in sorted_issues:
            severity = issue.get("severity", "low")
            if severity == "high":
                sev_style = "red"
                sev_icon = "🔴"
            elif severity == "medium":
                sev_style = "yellow"
                sev_icon = "🟡"
            else:
                sev_style = "green"
                sev_icon = "🟢"
            
            table.add_row(
                Text(f"{sev_icon} {severity.upper()}", style=sev_style),
                issue.get("category", "N/A"),
                issue.get("title", "N/A"),
                issue.get("file_path", "N/A")[:40]
            )
        
        console.print(table)
        
        # Detailed issues
        console.print("\n[bold cyan]═══ Issue Details ═══[/bold cyan]\n")
        
        for i, issue in enumerate(sorted_issues, 1):
            severity = issue.get("severity", "low")
            sev_color = "red" if severity == "high" else "yellow" if severity == "medium" else "green"
            
            console.print(f"[bold {sev_color}]#{i} {issue.get('title', 'Unknown Issue')}[/bold {sev_color}]")
            console.print(f"   [dim]File:[/dim] {issue.get('file_path', 'N/A')}")
            console.print(f"   [dim]Category:[/dim] {issue.get('category', 'N/A')}")
            console.print(f"   [bold]Why it matters:[/bold] {issue.get('why_it_matters', 'N/A')}")
            console.print(f"   [bold]How to fix:[/bold] {issue.get('how_to_fix', 'N/A')}")
            if issue.get("impact_if_ignored"):
                console.print(f"   [bold]Impact if ignored:[/bold] {issue.get('impact_if_ignored')}")
            console.print()
    else:
        console.print(Panel(
            "[bold green]✅ No issues found! Your code looks great.[/bold green]",
            border_style="green"
        ))
