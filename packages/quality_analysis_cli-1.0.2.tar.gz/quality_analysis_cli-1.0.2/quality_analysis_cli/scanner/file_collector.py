"""File collector module for scanning Python files."""
import fnmatch
from pathlib import Path
from typing import List, Set, Optional

# Expanded ignore patterns
IGNORED_DIRECTORIES: Set[str] = {
    # Version control
    '.git', '.svn', '.hg',
    # Python environments (common names)
    'venv', '.venv', 'env', '.env', 'virtualenv',
    'test_env', 'dev_env', 'prod_env',
    # Python caches
    '__pycache__', '.pytest_cache', '.mypy_cache',
    # Build artifacts
    'build', 'dist', '.eggs',
    # Package directories
    'site-packages', 'node_modules',
    # Testing environments
    '.tox', '.nox',
}

# Patterns to match with fnmatch
IGNORED_PATTERNS: List[str] = [
    '*_env',       # Any folder ending with _env
    '*venv*',      # Any folder containing venv
    '*.egg-info',  # Egg info directories
]


def _is_virtual_environment(path: Path) -> bool:
    """Detect if a directory is a Python virtual environment."""
    # Check for pyvenv.cfg (Python 3 venv marker)
    if (path / 'pyvenv.cfg').exists():
        return True
    # Check for Scripts/python.exe (Windows venv)
    if (path / 'Scripts' / 'python.exe').exists():
        return True
    # Check for bin/python (Unix venv)
    if (path / 'bin' / 'python').exists():
        return True
    return False


def _should_ignore(path: Path, extra_excludes: Optional[List[str]] = None) -> bool:
    """Check if a path should be ignored."""
    name = path.name
    extra_excludes = extra_excludes or []
    
    # Check extra excludes first
    if name in extra_excludes:
        return True
    
    # Direct name match
    if name in IGNORED_DIRECTORIES:
        return True
    
    # Pattern matching
    for pattern in IGNORED_PATTERNS:
        if fnmatch.fnmatch(name, pattern):
            return True
    
    # Smart venv detection for directories
    if path.is_dir() and _is_virtual_environment(path):
        return True
    
    return False


def collect_python_files(
    repo_path: Path,
    max_files: int = 30,
    extra_excludes: Optional[List[str]] = None
) -> List[Path]:
    """
    Collect Python files from the repository.
    
    Args:
        repo_path: Path to the repository root.
        max_files: Maximum number of files to collect.
        extra_excludes: Additional directory names to exclude.
    
    Returns:
        List of paths to Python files.
    """
    extra_excludes = extra_excludes or []
    python_files: List[Path] = []
    
    def scan_directory(directory: Path):
        """Recursively scan directory for Python files."""
        if len(python_files) >= max_files:
            return
        
        try:
            for item in sorted(directory.iterdir()):
                if len(python_files) >= max_files:
                    return
                
                if _should_ignore(item, extra_excludes):
                    continue
                
                if item.is_dir():
                    scan_directory(item)
                elif item.is_file() and item.suffix == '.py':
                    python_files.append(item)
        except PermissionError:
            pass  # Skip directories we can't access
    
    scan_directory(repo_path)
    return python_files


def get_file_info(file_path: Path) -> dict:
    """Get basic information about a file."""
    return {
        'path': str(file_path),
        'name': file_path.name,
        'size': file_path.stat().st_size if file_path.exists() else 0,
    }
