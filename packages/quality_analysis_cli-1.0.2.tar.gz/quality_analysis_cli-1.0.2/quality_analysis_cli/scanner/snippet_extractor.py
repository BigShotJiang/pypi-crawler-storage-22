"""
Code snippet extractor for function and class definitions.
"""

import re
from pathlib import Path
from typing import List, Tuple, Optional


# Regex patterns for Python constructs
FUNCTION_PATTERN = re.compile(
    r'^(\s*)(async\s+)?def\s+(\w+)\s*\([^)]*\)\s*(?:->\s*[^:]+)?:',
    re.MULTILINE
)

CLASS_PATTERN = re.compile(
    r'^(\s*)class\s+(\w+)\s*(?:\([^)]*\))?\s*:',
    re.MULTILINE
)


def extract_snippets(file_path: Path) -> List[Tuple[str, str, str]]:
    """
    Extract code snippets from a Python file.
    Returns list of (file_path, snippet_name, code) tuples.
    
    Falls back to entire file content if no functions/classes found.
    """
    try:
        content = file_path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return []
    
    snippets = []
    lines = content.split('\n')
    
    # Pattern to match function and class definitions
    pattern = r'^\s*(def \w+|class \w+)'
    
    current_snippet_start = None
    current_snippet_name = None
    current_indent = 0
    
    for i, line in enumerate(lines):
        match = re.match(pattern, line)
        if match:
            if current_snippet_name is not None:
                snippet_code = '\n'.join(lines[current_snippet_start:i])
                snippets.append((str(file_path), current_snippet_name, snippet_code.strip()))
            
            current_snippet_name = match.group(1)
            current_snippet_start = i
            current_indent = len(line) - len(line.lstrip())
    
    if current_snippet_name is not None:
        snippet_code = '\n'.join(lines[current_snippet_start:])
        snippets.append((str(file_path), current_snippet_name, snippet_code.strip()))
    
    # Fallback: analyze entire file if no functions/classes found
    if not snippets and content.strip():
        snippets.append((str(file_path), f"entire_file:{file_path.name}", content.strip()))
    
    return snippets

def _extract_from_content(
    content: str,
    file_path: str,
    min_lines: int,
    max_lines: int
) -> List[Tuple[str, str, str]]:
    """
    Extract snippets from file content.
    
    Args:
        content: File content as string
        file_path: Path to the file (for reporting)
        min_lines: Minimum lines per snippet
        max_lines: Maximum lines per snippet
        
    Returns:
        List of tuples (file_path, name, code)
    """
    snippets = []
    lines = content.split("\n")
    
    # Find functions
    for match in FUNCTION_PATTERN.finditer(content):
        name = match.group(3)
        start_pos = match.start()
        line_num = content[:start_pos].count("\n")
        
        snippet = _extract_lines(lines, line_num, min_lines, max_lines)
        if snippet and len(snippet.strip()) > 0:
            snippets.append((file_path, f"def {name}", snippet))
    
    # Find classes
    for match in CLASS_PATTERN.finditer(content):
        name = match.group(2)
        start_pos = match.start()
        line_num = content[:start_pos].count("\n")
        
        snippet = _extract_lines(lines, line_num, min_lines, max_lines)
        if snippet and len(snippet.strip()) > 0:
            snippets.append((file_path, f"class {name}", snippet))
    
    return snippets


def _extract_lines(
    lines: List[str],
    start_line: int,
    min_lines: int,
    max_lines: int
) -> Optional[str]:
    """
    Extract a range of lines from content.
    
    Args:
        lines: List of all lines
        start_line: Starting line number (0-indexed)
        min_lines: Minimum lines to extract
        max_lines: Maximum lines to extract
        
    Returns:
        Extracted code snippet or None
    """
    if start_line >= len(lines):
        return None
    
    end_line = min(start_line + max_lines, len(lines))
    extracted = lines[start_line:end_line]
    
    # Ensure we have at least min_lines of actual code
    non_empty = [l for l in extracted if l.strip()]
    if len(non_empty) < min_lines:
        return None
    
    return "\n".join(extracted)


def extract_imports(content: str) -> List[str]:
    """
    Extract import statements from Python content.
    
    Args:
        content: Python file content
        
    Returns:
        List of import statements
    """
    import_pattern = re.compile(
        r'^(?:from\s+[\w.]+\s+)?import\s+.+$',
        re.MULTILINE
    )
    
    return import_pattern.findall(content)
