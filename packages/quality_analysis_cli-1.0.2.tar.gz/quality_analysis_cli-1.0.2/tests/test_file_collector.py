"""Tests for the file collector module."""
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from quality_analysis_cli.scanner.file_collector import (
    collect_python_files,
    _should_ignore,
    _is_virtual_environment,
    get_file_info,
    IGNORED_DIRECTORIES,
)


class TestShouldIgnore:
    """Tests for _should_ignore function."""
    
    def test_ignores_git_directory(self, tmp_path):
        """Should ignore .git directories."""
        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        assert _should_ignore(git_dir) is True
    
    def test_ignores_venv_directory(self, tmp_path):
        """Should ignore venv directories."""
        venv_dir = tmp_path / "venv"
        venv_dir.mkdir()
        assert _should_ignore(venv_dir) is True
    
    def test_ignores_pycache(self, tmp_path):
        """Should ignore __pycache__ directories."""
        cache_dir = tmp_path / "__pycache__"
        cache_dir.mkdir()
        assert _should_ignore(cache_dir) is True
    
    def test_ignores_node_modules(self, tmp_path):
        """Should ignore node_modules directories."""
        node_dir = tmp_path / "node_modules"
        node_dir.mkdir()
        assert _should_ignore(node_dir) is True
    
    def test_ignores_egg_info(self, tmp_path):
        """Should ignore .egg-info directories."""
        egg_dir = tmp_path / "package.egg-info"
        egg_dir.mkdir()
        assert _should_ignore(egg_dir) is True
    
    def test_ignores_env_suffix_pattern(self, tmp_path):
        """Should ignore directories ending with _env."""
        test_env = tmp_path / "test_env"
        test_env.mkdir()
        assert _should_ignore(test_env) is True
        
        dev_env = tmp_path / "dev_env"
        dev_env.mkdir()
        assert _should_ignore(dev_env) is True
    
    def test_ignores_venv_pattern(self, tmp_path):
        """Should ignore directories containing 'venv'."""
        my_venv = tmp_path / "my_venv_project"
        my_venv.mkdir()
        assert _should_ignore(my_venv) is True
    
    def test_ignores_site_packages(self, tmp_path):
        """Should ignore site-packages directories."""
        site_pkg = tmp_path / "site-packages"
        site_pkg.mkdir()
        assert _should_ignore(site_pkg) is True
    
    def test_ignores_tox_nox(self, tmp_path):
        """Should ignore .tox and .nox directories."""
        tox_dir = tmp_path / ".tox"
        tox_dir.mkdir()
        assert _should_ignore(tox_dir) is True
        
        nox_dir = tmp_path / ".nox"
        nox_dir.mkdir()
        assert _should_ignore(nox_dir) is True
    
    def test_allows_normal_directories(self, tmp_path):
        """Should allow normal source directories."""
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        assert _should_ignore(src_dir) is False
        
        lib_dir = tmp_path / "lib"
        lib_dir.mkdir()
        assert _should_ignore(lib_dir) is False
    
    def test_allows_normal_python_files(self, tmp_path):
        """Should allow normal Python files."""
        py_file = tmp_path / "main.py"
        py_file.touch()
        assert _should_ignore(py_file) is False
    
    def test_respects_extra_excludes(self, tmp_path):
        """Should ignore directories in extra_excludes."""
        custom_dir = tmp_path / "my_custom_folder"
        custom_dir.mkdir()
        
        assert _should_ignore(custom_dir) is False
        assert _should_ignore(custom_dir, extra_excludes=["my_custom_folder"]) is True


class TestIsVirtualEnvironment:
    """Tests for _is_virtual_environment function."""
    
    def test_detects_pyvenv_cfg(self, tmp_path):
        """Should detect venv by pyvenv.cfg file."""
        venv_dir = tmp_path / "myenv"
        venv_dir.mkdir()
        (venv_dir / "pyvenv.cfg").touch()
        
        assert _is_virtual_environment(venv_dir) is True
    
    def test_detects_windows_venv(self, tmp_path):
        """Should detect Windows venv by Scripts/python.exe."""
        venv_dir = tmp_path / "winenv"
        venv_dir.mkdir()
        scripts_dir = venv_dir / "Scripts"
        scripts_dir.mkdir()
        (scripts_dir / "python.exe").touch()
        
        assert _is_virtual_environment(venv_dir) is True
    
    def test_detects_unix_venv(self, tmp_path):
        """Should detect Unix venv by bin/python."""
        venv_dir = tmp_path / "unixenv"
        venv_dir.mkdir()
        bin_dir = venv_dir / "bin"
        bin_dir.mkdir()
        (bin_dir / "python").touch()
        
        assert _is_virtual_environment(venv_dir) is True
    
    def test_rejects_non_venv(self, tmp_path):
        """Should not detect regular directories as venv."""
        normal_dir = tmp_path / "src"
        normal_dir.mkdir()
        
        assert _is_virtual_environment(normal_dir) is False


class TestCollectPythonFiles:
    """Tests for collect_python_files function."""
    
    def test_collects_python_files(self, tmp_path):
        """Should collect .py files."""
        (tmp_path / "main.py").touch()
        (tmp_path / "utils.py").touch()
        (tmp_path / "readme.txt").touch()
        
        files = collect_python_files(tmp_path)
        
        assert len(files) == 2
        assert all(f.suffix == ".py" for f in files)
    
    def test_collects_nested_files(self, tmp_path):
        """Should collect Python files in subdirectories."""
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        (src_dir / "app.py").touch()
        (tmp_path / "main.py").touch()
        
        files = collect_python_files(tmp_path)
        
        assert len(files) == 2
    
    def test_respects_max_files(self, tmp_path):
        """Should respect max_files limit."""
        for i in range(10):
            (tmp_path / f"file{i}.py").touch()
        
        files = collect_python_files(tmp_path, max_files=5)
        
        assert len(files) == 5
    
    def test_ignores_venv_directory(self, tmp_path):
        """Should ignore venv directories."""
        venv_dir = tmp_path / "venv"
        venv_dir.mkdir()
        (venv_dir / "pyvenv.cfg").touch()
        (venv_dir / "lib.py").touch()
        (tmp_path / "main.py").touch()
        
        files = collect_python_files(tmp_path)
        
        assert len(files) == 1
        assert files[0].name == "main.py"
    
    def test_ignores_test_env_directory(self, tmp_path):
        """Should ignore test_env directories."""
        env_dir = tmp_path / "test_env"
        env_dir.mkdir()
        (env_dir / "module.py").touch()
        (tmp_path / "app.py").touch()
        
        files = collect_python_files(tmp_path)
        
        assert len(files) == 1
        assert files[0].name == "app.py"
    
    def test_ignores_site_packages(self, tmp_path):
        """Should ignore site-packages."""
        venv_dir = tmp_path / "env"
        lib_dir = venv_dir / "Lib" / "site-packages"
        lib_dir.mkdir(parents=True)
        (lib_dir / "numpy.py").touch()
        (tmp_path / "main.py").touch()
        
        files = collect_python_files(tmp_path)
        
        assert len(files) == 1
        assert files[0].name == "main.py"
    
    def test_ignores_pycache(self, tmp_path):
        """Should ignore __pycache__ directories."""
        cache_dir = tmp_path / "__pycache__"
        cache_dir.mkdir()
        (cache_dir / "module.cpython-39.pyc").touch()
        (tmp_path / "module.py").touch()
        
        files = collect_python_files(tmp_path)
        
        assert len(files) == 1
    
    def test_ignores_git_directory(self, tmp_path):
        """Should ignore .git directories."""
        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        (git_dir / "hooks.py").touch()
        (tmp_path / "main.py").touch()
        
        files = collect_python_files(tmp_path)
        
        assert len(files) == 1
    
    def test_extra_excludes(self, tmp_path):
        """Should respect extra_excludes parameter."""
        custom_dir = tmp_path / "vendor"
        custom_dir.mkdir()
        (custom_dir / "external.py").touch()
        (tmp_path / "main.py").touch()
        
        files = collect_python_files(tmp_path, extra_excludes=["vendor"])
        
        assert len(files) == 1
        assert files[0].name == "main.py"
    
    def test_returns_empty_for_no_python_files(self, tmp_path):
        """Should return empty list when no Python files exist."""
        (tmp_path / "readme.md").touch()
        (tmp_path / "config.json").touch()
        
        files = collect_python_files(tmp_path)
        
        assert files == []
    
    def test_handles_permission_error(self, tmp_path):
        """Should handle permission errors gracefully."""
        (tmp_path / "main.py").touch()
        
        # This should not raise, even if some directories are unreadable
        files = collect_python_files(tmp_path)
        
        assert len(files) >= 1


class TestGetFileInfo:
    """Tests for get_file_info function."""
    
    def test_returns_file_info(self, tmp_path):
        """Should return correct file information."""
        test_file = tmp_path / "test.py"
        test_file.write_text("print('hello')")
        
        info = get_file_info(test_file)
        
        assert info["name"] == "test.py"
        assert str(test_file) in info["path"]
        assert info["size"] > 0
    
    def test_handles_missing_file(self, tmp_path):
        """Should handle non-existent files."""
        missing_file = tmp_path / "missing.py"
        
        info = get_file_info(missing_file)
        
        assert info["name"] == "missing.py"
        assert info["size"] == 0
