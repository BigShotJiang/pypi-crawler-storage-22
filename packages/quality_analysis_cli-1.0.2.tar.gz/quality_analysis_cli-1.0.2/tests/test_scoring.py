"""
Tests for the scoring module.
"""

import pytest

from quality_analysis_cli.evaluator.scoring import (
    calculate_score,
    get_grade,
    has_critical_issues,
    count_by_severity,
)


class TestCalculateScore:
    """Tests for calculate_score function."""
    
    def test_perfect_score_no_issues(self):
        """Should return 100 when no issues."""
        score = calculate_score([])
        assert score == 100
    
    def test_high_severity_deduction(self):
        """High severity should deduct 10 points each."""
        issues = [{"severity": "high"}]
        score = calculate_score(issues)
        assert score == 90
    
    def test_medium_severity_deduction(self):
        """Medium severity should deduct 5 points each."""
        issues = [{"severity": "medium"}]
        score = calculate_score(issues)
        assert score == 95
    
    def test_low_severity_deduction(self):
        """Low severity should deduct 2 points each."""
        issues = [{"severity": "low"}]
        score = calculate_score(issues)
        assert score == 98
    
    def test_multiple_issues(self):
        """Should accumulate deductions."""
        issues = [
            {"severity": "high"},    # -10
            {"severity": "medium"},  # -5
            {"severity": "low"},     # -2
        ]
        score = calculate_score(issues)
        assert score == 83  # 100 - 17
    
    def test_score_minimum_zero(self):
        """Score should not go below 0."""
        issues = [{"severity": "high"} for _ in range(15)]  # -150 total
        score = calculate_score(issues)
        assert score == 0


class TestGetGrade:
    """Tests for get_grade function."""
    
    @pytest.mark.parametrize("score,expected", [
        (100, "A"),
        (95, "A"),
        (90, "A"),
        (89, "B"),
        (80, "B"),
        (79, "C"),
        (70, "C"),
        (69, "D"),
        (60, "D"),
        (59, "F"),
        (0, "F"),
    ])
    def test_grade_thresholds(self, score: int, expected: str):
        """Should return correct grade for score thresholds."""
        assert get_grade(score) == expected


class TestHasCriticalIssues:
    """Tests for has_critical_issues function."""
    
    def test_no_issues(self):
        """Should return False for empty list."""
        assert has_critical_issues([]) is False
    
    def test_only_low_severity(self):
        """Should return False for only low severity."""
        issues = [{"severity": "low"}, {"severity": "low"}]
        assert has_critical_issues(issues) is False
    
    def test_only_medium_severity(self):
        """Should return False for only medium severity."""
        issues = [{"severity": "medium"}]
        assert has_critical_issues(issues) is False
    
    def test_has_high_severity(self):
        """Should return True when high severity exists."""
        issues = [
            {"severity": "low"},
            {"severity": "high"},
            {"severity": "medium"},
        ]
        assert has_critical_issues(issues) is True


class TestCountBySeverity:
    """Tests for count_by_severity function."""
    
    def test_empty_list(self):
        """Should return zeros for empty list."""
        counts = count_by_severity([])
        assert counts == {"high": 0, "medium": 0, "low": 0}
    
    def test_counts_correctly(self):
        """Should count each severity correctly."""
        issues = [
            {"severity": "high"},
            {"severity": "high"},
            {"severity": "medium"},
            {"severity": "low"},
            {"severity": "low"},
            {"severity": "low"},
        ]
        counts = count_by_severity(issues)
        assert counts == {"high": 2, "medium": 1, "low": 3}
