"""基本面数据模块

提供批量获取东方财富基本面数据的接口。
"""

from .provider import FundamentalsProvider

__all__ = ["FundamentalsProvider"]
