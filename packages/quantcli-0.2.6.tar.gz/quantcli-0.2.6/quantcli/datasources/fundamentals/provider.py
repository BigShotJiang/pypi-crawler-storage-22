"""基本面数据 Provider - 批量获取东方财富基本面数据"""

from datetime import date
from typing import Dict, List, Optional
import pandas as pd

import akshare as ak

from ...utils import get_logger
from ...utils.symbol_utils import to_mysql_from_akshare

logger = get_logger(__name__)


class FundamentalsProvider:
    """基本面数据提供者（批量获取）

    使用东方财富数据中心接口，一次获取指定日期的所有股票基本面数据。
    支持缓存，避免重复请求。

    使用示例:
        >>> provider = FundamentalsProvider()
        >>> df = provider.get_yjbb("20240630")
        >>> reports = provider.get_all_reports(["20240331", "20240630"])
    """

    # 字段映射：原始字段 -> 标准字段名
    YJBB_FIELDS = {
        '股票代码': 'symbol',
        '每股收益': 'eps',
        '净利润': 'net_profits',
        '营业总收入-营业总收入': 'revenue',
        '营业总收入-同比增长': 'revenue_yoy',
        '净利润-同比增长': 'netprofit_yoy',
        '净利润-季度环比增长': 'netprofit_qoq',
        '销售毛利率': 'grossprofitmargin',
        '每股净资产': 'bps',  # 每股净资产
        '净资产收益率': 'roe',
        '每股经营现金流量': 'ocf_per_share',
        '最新公告日期': 'announce_date',
    }

    LRB_FIELDS = {
        '股票代码': 'symbol',
        '净利润': 'net_profits',
        '净利润同比': 'netprofit_yoy',
        '营业总收入': 'revenue',
        '营业总收入同比': 'revenue_yoy',
    }

    ZCFZ_FIELDS = {
        '股票代码': 'symbol',
    }

    XJLL_FIELDS = {
        '股票代码': 'symbol',
        '经营活动产生的现金流量净额': 'ocf',
    }

    def __init__(self, use_cache: bool = True):
        """初始化 Provider

        Args:
            use_cache: 是否缓存请求结果，默认 True
        """
        self._use_cache = use_cache
        self._cache: Dict[str, pd.DataFrame] = {}

    def _fetch_and_cache(self, report_type: str, date: str) -> pd.DataFrame:
        """获取数据并缓存"""
        cache_key = f"{report_type}_{date}"

        if self._use_cache and cache_key in self._cache:
            logger.debug(f"缓存命中: {cache_key}")
            return self._cache[cache_key].copy()

        # 根据类型调用接口
        fetchers = {
            'yjbb': ak.stock_yjbb_em,
            'lrb': ak.stock_lrb_em,
            'zcfz': ak.stock_zcfz_em,
            'xjll': ak.stock_xjll_em,
        }

        fetcher = fetchers.get(report_type)
        if not fetcher:
            raise ValueError(f"未知报表类型: {report_type}")

        try:
            df = fetcher(date=date)
            if df.empty:
                logger.warning(f"无数据: {report_type} {date}")
                return pd.DataFrame()

            # 转换代码格式
            df['symbol'] = df['股票代码'].apply(to_mysql_from_akshare)

            # 缓存
            if self._use_cache:
                self._cache[cache_key] = df.copy()

            return df
        except Exception as e:
            logger.error(f"获取 {report_type} {date} 失败: {e}")
            return pd.DataFrame()

    def get_yjbb(self, date: str) -> pd.DataFrame:
        """获取业绩报表数据

        Args:
            date: 财报日期，如 "20240630"

        Returns:
            包含所有股票的业绩报表数据
        """
        df = self._fetch_and_cache('yjbb', date)
        if df.empty:
            return pd.DataFrame(columns=['symbol', 'eps', 'net_profits', 'revenue',
                                        'revenue_yoy', 'netprofit_yoy', 'grossprofitmargin',
                                        'bps', 'roe'])

        # 原始列名 -> 重命名后列名（注意：symbol 已由 _fetch_and_cache 转换）
        rename_map = {
            '每股收益': 'eps',
            '净利润-净利润': 'net_profits',
            '营业总收入-营业总收入': 'revenue',
            '营业总收入-同比增长': 'revenue_yoy',
            '净利润-同比增长': 'netprofit_yoy',
            '净利润-季度环比增长': 'netprofit_qoq',
            '销售毛利率': 'grossprofitmargin',
            '每股净资产': 'bps',
            '净资产收益率': 'roe',
            '每股经营现金流量': 'ocf_per_share',
            '最新公告日期': 'announce_date',
        }

        # symbol 已由 _fetch_and_cache 转换好，只选择需要的列
        columns = ['symbol'] + [k for k in rename_map.keys() if k in df.columns]
        result = df[columns].rename(columns=rename_map)

        # 将 NaN 替换为 None（用于 MySQL）
        import numpy as np
        result = result.replace({np.nan: None})
        return result

    def get_lrb(self, date: str) -> pd.DataFrame:
        """获取利润表数据

        Args:
            date: 财报日期，如 "20240630"

        Returns:
            包含所有股票的利润表数据
        """
        df = self._fetch_and_cache('lrb', date)
        if df.empty:
            return pd.DataFrame(columns=['symbol', 'net_profits', 'revenue'])

        columns = ['symbol', 'net_profits', 'revenue']
        available = [c for c in columns if c in df.columns]
        return df[available].copy()

    def get_zcfz(self, date: str) -> pd.DataFrame:
        """获取资产负债表数据"""
        df = self._fetch_and_cache('zcfz', date)
        if df.empty:
            return pd.DataFrame(columns=['symbol'])
        return df[['symbol']].copy()

    def get_xjll(self, date: str) -> pd.DataFrame:
        """获取现金流量表数据"""
        df = self._fetch_and_cache('xjll', date)
        if df.empty:
            return pd.DataFrame(columns=['symbol', 'ocf'])
        columns = ['symbol', 'ocf']
        available = [c for c in columns if c in df.columns]
        return df[available].copy()

    def get_all_reports(self, dates: List[str]) -> Dict[str, Dict[str, pd.DataFrame]]:
        """批量获取多个日期的所有报表数据

        Args:
            dates: 财报日期列表，如 ["20240331", "20240630"]

        Returns:
            嵌套字典: {日期: {报表类型: DataFrame}}
        """
        result = {}
        for d in dates:
            result[d] = {
                'yjbb': self.get_yjbb(d),
                'lrb': self.get_lrb(d),
                'zcfz': self.get_zcfz(d),
                'xjll': self.get_xjll(d),
            }
        return result

    def get_merged_fundamentals(self, dates: List[str]) -> pd.DataFrame:
        """获取合并后的基本面数据

        将多个日期的报表数据合并，按股票代码和报告日期对齐。

        Args:
            dates: 财报日期列表

        Returns:
            合并后的基本面数据 DataFrame
        """
        all_data = []

        for d in dates:
            # 只获取业绩报表，包含主要财务指标
            yjbb = self.get_yjbb(d)

            if yjbb.empty:
                continue

            # 重命名 YJBB 中的关键字段，匹配 MySQL 表结构
            rename_map = {
                '净资产收益率': 'roe',
                '销售毛利率': 'grossprofitmargin',
            }
            merged = yjbb.copy()
            for old_name, new_name in rename_map.items():
                if old_name in merged.columns:
                    merged = merged.rename(columns={old_name: new_name})

            merged['report_date'] = d
            all_data.append(merged)

        if not all_data:
            return pd.DataFrame()

        return pd.concat(all_data, ignore_index=True)

    @staticmethod
    def generate_report_dates(start_year: int, end_year: int) -> List[str]:
        """生成财报日期列表

        Args:
            start_year: 开始年份
            end_year: 结束年份

        Returns:
            日期列表，如 ["20200331", "20200630", ...]
        """
        dates = []
        for year in range(start_year, end_year + 1):
            # 季度财报日期
            dates.extend([
                f"{year}0331",  # 一季报
                f"{year}0630",  # 中报
                f"{year}0930",  # 三季报
                f"{year}1231",  # 年报
            ])
        return dates

    def clear_cache(self, date: str = None):
        """清除缓存

        Args:
            date: 指定日期则清除该日期缓存，默认清除全部
        """
        if date:
            keys_to_remove = [k for k in self._cache if k.endswith(f"_{date}")]
            for k in keys_to_remove:
                del self._cache[k]
            logger.info(f"已清除缓存: {date}")
        else:
            self._cache.clear()
            logger.info("已清除全部缓存")

    def get_cache_info(self) -> Dict[str, int]:
        """获取缓存信息"""
        return {
            "cached_dates": len(self._cache),
            "cache_keys": list(self._cache.keys())[:10],  # 只返回前10个
        }
