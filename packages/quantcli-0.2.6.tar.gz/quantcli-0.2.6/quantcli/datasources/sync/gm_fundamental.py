"""
掘金量化基本面数据同步

使用掘金量化的 stk_get_finance_prime_pt API 获取财务主要指标，
包括 ROE、净利润率、PE、PB 等关键指标。
"""

import pandas as pd
from datetime import date, datetime
from typing import Dict, List, Optional
from tqdm import tqdm
import logging

from ...utils import get_logger
from ...models.bar import DailyBar
from ..mysql import MySQLDataSource

logger = get_logger(__name__)

GM_AVAILABLE = None


def _check_gm():
    global GM_AVAILABLE
    if GM_AVAILABLE is None:
        try:
            import gm

            GM_AVAILABLE = True
        except ImportError:
            GM_AVAILABLE = False
    return GM_AVAILABLE


class GmFundamentalSync:
    """掘金基本面数据同步器

    使用掘金量化的 API 获取财务主要指标并同步到 MySQL。

    Attributes:
        mysql: MySQL 数据源
        batch_size: 每批处理的股票数量（掘金限制每次最多 200 只）

    使用示例:
        >>> sync = GmFundamentalSync(mysql_datasource)
        >>> result = sync.sync_fundamental(['600519', '000001'])
        >>> print(result)
        {'600519': 5, '000001': 4}
    """

    def __init__(self, mysql_datasource: MySQLDataSource):
        """初始化 GmFundamentalSync

        Args:
            mysql_datasource: MySQLDataSource 实例
        """
        self._mysql = mysql_datasource
        self.batch_size = 200  # 掘金限制每次最多 200 只股票

    def sync_fundamental(
        self, symbols: List[str], report_date: Optional[date] = None
    ) -> Dict[str, int]:
        """同步基本面数据到 MySQL

        使用掘金量化的 stk_get_finance_prime_pt API 获取财务主要指标，
        包括 ROE、净利润率、毛利率、PE、PB 等。

        Args:
            symbols: 股票代码列表（支持任意格式）
            report_date: 报告日期（默认为最新日期）

        Returns:
            {symbol: 同步记录数} 字典
        """
        if not _check_gm():
            logger.warning("掘金 SDK 未安装，基本面同步将使用降级方案")
            return {}

        # 初始化掘金
        try:
            gm.login()
        except Exception as e:
            logger.error(f"掘金登录失败: {e}")
            return {}

        try:
            # 转换股票代码为掘金格式
            gm_symbols = self._to_gm_symbols(symbols)

            # 需要的基本面字段
            fields = [
                "roe",  # 全面摊薄净资产收益率 (%)
                "roe_weight_avg",  # 加权平均净资产收益率 (%)
                "eps_basic",  # 基本每股收益
                "net_profit_pcom",  # 归属于母公司股东的净利润
                "net_prof_pcom_cut",  # 扣除非经常性损益后归属于母公司股东的净利润
                "ttl_inc_oper",  # 营业总收入
                "inc_oper",  # 营业收入
                "oper_prof",  # 营业利润
                "ttl_prof",  # 利润总额
                "bps_pcom_ps",  # 归属于母公司股东的每股净资产
            ]

            result = {}
            total_symbols = len(gm_symbols)

            for i in tqdm(
                range(0, total_symbols, self.batch_size),
                desc="同步基本面数据",
                unit="批",
            ):
                batch = gm_symbols[i : i + self.batch_size]
                batch_symbols = symbols[i : i + self.batch_size]

                try:
                    # 调用掘金 API
                    df = gm.stk_get_finance_prime_pt(
                        symbols=batch,
                        fields=",".join(fields),
                        rpt_type=None,
                        data_type=102,  # 合并调整
                        date=None,  # 最新发布
                        df=True,
                    )

                    if df.empty:
                        logger.debug(f"批次 {i // self.batch_size + 1}: 无数据")
                        for sym in batch_symbols:
                            result[sym] = 0
                        continue

                    # 同步到 MySQL
                    count = self._save_to_mysql(df)
                    for sym in batch_symbols:
                        result[sym] = count

                    logger.debug(
                        f"批次 {i // self.batch_size + 1}: 成功同步 {count} 条记录"
                    )

                except Exception as e:
                    logger.error(f"批次 {i // self.batch_size + 1} 失败: {e}")
                    for sym in batch_symbols:
                        result[sym] = -1

            return result

        finally:
            try:
                gm.logout()
            except:
                pass

    def _to_gm_symbols(self, symbols: List[str]) -> List[str]:
        """将任意格式的股票代码转换为掘金格式

        Args:
            symbols: 股票代码列表

        Returns:
            掘金格式的股票代码列表
        """
        gm_symbols = []
        for sym in symbols:
            sym = str(sym).strip()
            # 如果已经是掘金格式，直接添加
            if sym.startswith(("SHSE.", "SZSE.", "BJSE.")):
                gm_symbols.append(sym)
            # 如果是纯数字，尝试识别市场
            elif sym.isdigit():
                if len(sym) == 6:
                    # 沪市
                    if sym[0] in ["6", "9"]:
                        gm_symbols.append(f"SHSE.{sym}")
                    # 深市
                    elif sym[0] in ["0", "3"]:
                        gm_symbols.append(f"SZSE.{sym}")
                    else:
                        gm_symbols.append(f"SZSE.{sym}")
                else:
                    gm_symbols.append(f"SZSE.{sym}")
            else:
                gm_symbols.append(f"SZSE.{sym}")

        return gm_symbols

    def _save_to_mysql(self, df: pd.DataFrame) -> int:
        """将基本面数据保存到 MySQL

        Args:
            df: 包含基本面数据的 DataFrame

        Returns:
            保存的记录数
        """
        if df.empty:
            return 0

        conn = self._mysql._get_connection()
        table = self._mysql._table("fundamental_data")

        # 计算净利润率 = 归属于母公司股东的净利润 / 营业收入
        df["netprofitmargin"] = df.apply(
            lambda row: (
                float(row["net_profit_pcom"]) / float(row["inc_oper"])
                if pd.notna(row["net_profit_pcom"])
                and pd.notna(row["inc_oper"])
                and float(row["inc_oper"]) != 0
                else None
            ),
            axis=1,
        )

        # 计算毛利率 = (营业收入 - 营业成本) / 营业收入
        # 使用营业利润近似
        df["grossprofitmargin"] = df.apply(
            lambda row: (
                float(row["oper_prof"]) / float(row["inc_oper"])
                if pd.notna(row["oper_prof"])
                and pd.notna(row["inc_oper"])
                and float(row["inc_oper"]) != 0
                else None
            ),
            axis=1,
        )

        # 计算 PE = 归属于母公司股东的每股净资产 / 基本每股收益
        df["pe_ttm"] = df.apply(
            lambda row: (
                float(row["bps_pcom_ps"]) / float(row["eps_basic"])
                if pd.notna(row["bps_pcom_ps"])
                and pd.notna(row["eps_basic"])
                and float(row["eps_basic"]) != 0
                else None
            ),
            axis=1,
        )

        # 计算 PB = 归属于母公司股东的每股净资产 / 股票价格
        # 这里简化处理，使用账面价值代替

        count = 0
        with conn.cursor() as cursor:
            for _, row in df.iterrows():
                symbol = row["symbol"]
                report_date = row["rpt_date"]
                pub_date = row["pub_date"]

                try:
                    cursor.execute(
                        f"""
                        INSERT INTO {table}
                        (symbol, report_date, roe, netprofitmargin, grossprofitmargin, pe_ttm, pb)
                        VALUES (%s, %s, %s, %s, %s, %s, %s)
                        ON DUPLICATE KEY UPDATE
                        roe = VALUES(roe),
                        netprofitmargin = VALUES(netprofitmargin),
                        grossprofitmargin = VALUES(grossprofitmargin),
                        pe_ttm = VALUES(pe_ttm),
                        pb = VALUES(pb)
                    """,
                        (
                            symbol,
                            report_date,
                            row["roe"] if pd.notna(row["roe"]) else None,
                            row["netprofitmargin"],
                            row["grossprofitmargin"],
                            row["pe_ttm"],
                            None,  # PB 暂不计算
                        ),
                    )
                    count += 1
                except Exception as e:
                    logger.error(f"保存 {symbol} 失败: {e}")

        conn.commit()
        return count


def create_gm_fundamental_sync(mysql_datasource: MySQLDataSource) -> GmFundamentalSync:
    """创建掘金基本面同步器的工厂函数

    Args:
        mysql_datasource: MySQLDataSource 实例

    Returns:
        GmFundamentalSync 实例
    """
    return GmFundamentalSync(mysql_datasource)
