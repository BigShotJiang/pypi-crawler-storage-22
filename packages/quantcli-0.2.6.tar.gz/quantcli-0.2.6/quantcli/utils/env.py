import os
from pathlib import Path
from typing import Dict, Optional

_env_cache: Optional[Dict[str, str]] = None


def load_env(file_path: str = "~/.env") -> Dict[str, str]:
    """加载 .env 文件

    Args:
        file_path: .env 文件路径，默认 ~/.env

    Returns:
        环境变量字典
    """
    global _env_cache
    if _env_cache is not None:
        return _env_cache

    _env_cache = {}
    path = Path(file_path).expanduser()
    if path.exists():
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    _env_cache[k.strip()] = v.strip()
    return _env_cache


def get_env(key: str, default: str = None) -> str:
    """获取环境变量，优先从 ~/.env 读取

    优先级（如果 ~/.env 存在）：
    1. ~/.env 文件
    2. 系统环境变量
    3. 默认值

    如果 ~/.env 不存在：
    1. 系统环境变量
    2. 默认值

    Args:
        key: 环境变量名
        default: 默认值

    Returns:
        环境变量值
    """
    # 检查 ~/.env 是否存在
    env_file = Path("~/.env").expanduser()
    if env_file.exists():
        # 优先从 ~/.env 读取
        env = load_env()
        if key in env:
            return env[key]
        # 然后检查系统环境变量
        value = os.getenv(key)
        if value is not None:
            return value
        return default
    else:
        # 没有 ~/.env 时，使用系统环境变量
        value = os.getenv(key)
        if value is not None:
            return value
        return default


def get_env_int(key: str, default: int = None) -> int:
    """获取整数类型的环境变量"""
    value = get_env(key, str(default) if default is not None else None)
    if value is None:
        return default
    return int(value)
