"""DataManager 单元测试 - get_daily 缓存逻辑"""

import pytest
import tempfile
import os
from datetime import date, timedelta
from unittest.mock import MagicMock, patch
import pandas as pd

from quantcli.core import DataManager, DataConfig


@pytest.fixture
def mock_datasource():
    """模拟数据源"""
    mock = MagicMock()

    def mock_get_daily(symbol, start_date, end_date, **kwargs):
        # 生成模拟数据
        dates = pd.date_range(start=start_date, end=end_date, freq="B")
        return pd.DataFrame(
            {
                "date": dates,
                "symbol": [symbol] * len(dates),
                "open": [10.0] * len(dates),
                "high": [11.0] * len(dates),
                "low": [9.0] * len(dates),
                "close": [10.5] * len(dates),
                "volume": [1000000] * len(dates),
            }
        )

    mock.get_daily.side_effect = mock_get_daily
    # get_trading_calendar 默认返回日期列表
    mock.get_trading_calendar.return_value = list(
        pd.date_range("2023-01-01", periods=30, freq="B").date
    )
    return mock


@pytest.fixture
def temp_cache_dir():
    """创建临时缓存目录"""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


class TestGetDailyCacheLogic:
    """测试 get_daily 缓存逻辑"""

    def test_cache_exists_and_complete_returns_cached(
        self, temp_cache_dir, mock_datasource
    ):
        """缓存存在且完整 → 直接返回缓存"""
        config = DataConfig(cache_dir=temp_cache_dir, source="mock", cache_raw=True)
        dm = DataManager(config)
        dm._datasource = mock_datasource

        # 预先填充缓存（完整数据）
        cache_file = dm.cache_dir / "raw" / "stock_daily" / "600519.parquet"
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        cached_data = pd.DataFrame(
            {
                "date": [date(2023, 1, 2), date(2023, 1, 3), date(2023, 1, 4)],
                "symbol": ["600519"] * 3,
                "open": [10.0] * 3,
                "high": [11.0] * 3,
                "low": [9.0] * 3,
                "close": [10.5] * 3,
                "volume": [1000000] * 3,
            }
        )
        cached_data.to_parquet(cache_file, index=False)

        # 写入交易日历
        calendar_file = dm.cache_dir / "cache" / "calendar_SSE.json"
        calendar_file.parent.mkdir(parents=True, exist_ok=True)
        with open(calendar_file, "w") as f:
            import json

            json.dump(
                [
                    d.isoformat()
                    for d in pd.date_range("2023-01-01", periods=30, freq="B")
                ],
                f,
            )

        # 调用 get_daily
        result = dm.get_daily("600519", date(2023, 1, 2), date(2023, 1, 4))

        # 验证：直接从缓存返回，没有调用数据源
        assert len(result) == 3
        mock_datasource.get_daily.assert_not_called()

    def test_cache_incomplete_fetches_full_data(self, temp_cache_dir, mock_datasource):
        """缓存不完整 → 全量拉取"""
        config = DataConfig(cache_dir=temp_cache_dir, source="mock", cache_raw=True)
        dm = DataManager(config)
        dm._datasource = mock_datasource

        # 预先填充缓存（不完整数据）
        cache_file = dm.cache_dir / "raw" / "stock_daily" / "600519.parquet"
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        cached_data = pd.DataFrame(
            {
                "date": [date(2023, 1, 2), date(2023, 1, 3)],  # 只有2天数据
                "symbol": ["600519"] * 2,
                "open": [10.0] * 2,
                "high": [11.0] * 2,
                "low": [9.0] * 2,
                "close": [10.5] * 2,
                "volume": [1000000] * 2,
            }
        )
        cached_data.to_parquet(cache_file, index=False)

        # 写入交易日历（预期3个交易日）
        calendar_file = dm.cache_dir / "cache" / "calendar_SSE.json"
        calendar_file.parent.mkdir(parents=True, exist_ok=True)
        with open(calendar_file, "w") as f:
            import json

            json.dump(
                [
                    d.isoformat()
                    for d in pd.date_range("2023-01-01", periods=30, freq="B")
                ],
                f,
            )

        # 调用 get_daily
        result = dm.get_daily("600519", date(2023, 1, 2), date(2023, 1, 4))

        # 验证：调用数据源全量拉取
        assert mock_datasource.get_daily.called
        assert len(result) >= 3  # 新拉取的数据

    def test_no_cache_fetches_full_data(self, temp_cache_dir, mock_datasource):
        """缓存不存在 → 全量拉取"""
        config = DataConfig(cache_dir=temp_cache_dir, source="mock", cache_raw=True)
        dm = DataManager(config)
        dm._datasource = mock_datasource

        # 写入交易日历
        calendar_file = dm.cache_dir / "cache" / "calendar_SSE.json"
        calendar_file.parent.mkdir(parents=True, exist_ok=True)
        with open(calendar_file, "w") as f:
            import json

            json.dump(
                [
                    d.isoformat()
                    for d in pd.date_range("2023-01-01", periods=30, freq="B")
                ],
                f,
            )

        # 调用 get_daily（不预先填充缓存）
        result = dm.get_daily("600519", date(2023, 1, 2), date(2023, 1, 4))

        # 验证：调用数据源
        assert mock_datasource.get_daily.called
        assert len(result) >= 3

    def test_no_calendar_fetches_full_data(self, temp_cache_dir, mock_datasource):
        """交易日历不可用 → 直接拉取，不使用缓存"""
        config = DataConfig(cache_dir=temp_cache_dir, source="mock", cache_raw=True)
        dm = DataManager(config)
        dm._datasource = mock_datasource

        # 模拟交易日历不可用
        mock_datasource.get_trading_calendar.side_effect = Exception(
            "Calendar unavailable"
        )

        # 预先填充缓存
        cache_file = dm.cache_dir / "raw" / "stock_daily" / "600519.parquet"
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        cached_data = pd.DataFrame(
            {
                "date": [date(2023, 1, 2), date(2023, 1, 3), date(2023, 1, 4)],
                "symbol": ["600519"] * 3,
                "open": [10.0] * 3,
                "high": [11.0] * 3,
                "low": [9.0] * 3,
                "close": [10.5] * 3,
                "volume": [1000000] * 3,
            }
        )
        cached_data.to_parquet(cache_file, index=False)

        # 调用 get_daily
        result = dm.get_daily("600519", date(2023, 1, 2), date(2023, 1, 4))

        # 验证：直接拉取，不使用缓存
        assert mock_datasource.get_daily.called

    def test_no_calendar_no_cache_fetches_full_data(
        self, temp_cache_dir, mock_datasource
    ):
        """交易日历不可用 + 无缓存 → 全量拉取"""
        config = DataConfig(cache_dir=temp_cache_dir, source="mock", cache_raw=True)
        dm = DataManager(config)
        dm._datasource = mock_datasource

        # 模拟交易日历不可用
        mock_datasource.get_trading_calendar.side_effect = Exception(
            "Calendar unavailable"
        )

        # 调用 get_daily
        result = dm.get_daily("600519", date(2023, 1, 2), date(2023, 1, 4))

        # 验证：调用数据源
        assert mock_datasource.get_daily.called
        assert len(result) >= 3


class TestGetDailyBatch:
    """测试 get_daily_batch 批量获取"""

    def test_batch_uses_parallel_when_enabled(self, temp_cache_dir, mock_datasource):
        """批量获取启用并行"""
        config = DataConfig(
            cache_dir=temp_cache_dir, source="mock", parallel=2, cache_raw=True
        )
        dm = DataManager(config)
        dm._datasource = mock_datasource

        symbols = ["600519", "000001"]
        result = dm.get_daily_batch(
            symbols, date(2023, 1, 2), date(2023, 1, 4), parallel=True
        )

        assert len(symbols) == 2
        assert mock_datasource.get_daily.call_count == 2


class TestCacheCleanup:
    """测试缓存清理"""

    def test_clear_cache_removes_files(self, temp_cache_dir, mock_datasource):
        """清理缓存删除文件"""
        config = DataConfig(cache_dir=temp_cache_dir, source="mock", cache_raw=True)
        dm = DataManager(config)
        dm._datasource = mock_datasource

        # 创建缓存文件
        cache_file = dm.cache_dir / "raw" / "stock_daily" / "600519.parquet"
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(
            {
                "date": [date(2023, 1, 2)],
                "symbol": ["600519"],
                "open": [10.0],
                "high": [11.0],
                "low": [9.0],
                "close": [10.5],
                "volume": [1000000],
            }
        ).to_parquet(cache_file, index=False)

        # 验证文件存在
        assert cache_file.exists()

        # 清理
        count = dm.clear_cache(pattern="*.parquet")

        # 验证
        assert count >= 1
        assert not cache_file.exists()
