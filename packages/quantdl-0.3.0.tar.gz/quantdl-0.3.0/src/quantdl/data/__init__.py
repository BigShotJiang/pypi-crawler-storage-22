"""Data fetchers for QuantDL."""
