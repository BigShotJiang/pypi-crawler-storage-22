import numpy as np

def classical_isfft(x):
    N, M = x.shape
    X = np.zeros((N, M), dtype=complex)

    for n in range(N):
        for m in range(M):
            for k in range(N):
                for l in range(M):
                    X[n, m] += x[k, l] * np.exp(
                        1j * 2 * np.pi * ((n*k)/N - (m*l)/M)
                    )

    return X / np.sqrt(N*M)
