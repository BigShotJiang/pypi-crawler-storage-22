from qiskit.quantum_info import state_fidelity

def compute_fidelity(state1, state2):
    return state_fidelity(state1, state2)
