import numpy as np

def qam4_gray(bits):
    mapping = {
        "00": 1+1j,
        "01": -1+1j,
        "11": -1-1j,
        "10": 1-1j
    }

    symbols = []
    for i in range(0, len(bits), 2):
        symbols.append(mapping[bits[i:i+2]])

    return np.array(symbols)
