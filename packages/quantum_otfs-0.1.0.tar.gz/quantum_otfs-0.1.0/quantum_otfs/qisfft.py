from qiskit import QuantumCircuit
from qiskit.circuit.library import QFT

def build_qisfft(n_doppler, n_delay):

    total_qubits = n_doppler + n_delay
    qc = QuantumCircuit(total_qubits)

    doppler = list(range(n_doppler))
    delay = list(range(n_doppler, total_qubits))

    # Inverse QFT on Doppler qubits
    qc.append(QFT(n_doppler, inverse=True), doppler)

    # QFT on Delay qubits
    qc.append(QFT(n_delay), delay)

    return qc
