from qiskit import QuantumCircuit
from qiskit.circuit.library import QFT



def build_qsfft(n_doppler, n_delay):

    total_qubits = n_doppler + n_delay
    qc = QuantumCircuit(total_qubits)

    doppler = list(range(n_doppler))
    delay = list(range(n_doppler, total_qubits))

    # QFT on Doppler
    qc.append(QFT(n_doppler), doppler)

    # Inverse QFT on Delay
    qc.append(QFT(n_delay, inverse=True), delay)

    return qc
