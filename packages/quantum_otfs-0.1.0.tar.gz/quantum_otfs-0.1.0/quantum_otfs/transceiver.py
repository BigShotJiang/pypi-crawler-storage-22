from .qisfft import build_qisfft
from .qsfft import build_qsfft
from .utils import amplitude_encode

def quantum_otfs_tx_rx(data, n_doppler, n_delay):

    state = amplitude_encode(data)

    qisfft = build_qisfft(n_doppler, n_delay)
    qsfft = build_qsfft(n_doppler, n_delay)

    state = state.evolve(qisfft)
    state = state.evolve(qsfft)

    return state
