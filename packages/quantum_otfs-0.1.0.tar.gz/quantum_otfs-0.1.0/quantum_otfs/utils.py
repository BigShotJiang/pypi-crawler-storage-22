from qiskit.quantum_info import Statevector
import numpy as np

def amplitude_encode(data):

    flat = data.flatten()
    norm = np.linalg.norm(flat)

    if norm == 0:
        raise ValueError("Zero vector cannot be encoded")

    state = flat / norm
    return Statevector(state)
