import numpy as np

def relative_error(classical, quantum):
    return np.linalg.norm(classical - quantum) / np.linalg.norm(classical)
