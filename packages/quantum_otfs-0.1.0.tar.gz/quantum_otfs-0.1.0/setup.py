from setuptools import setup, find_packages

setup(
    name="quantum_otfs",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "qiskit",
        "numpy",
        "scipy",
        "matplotlib"
    ],
    author="Your Name",
    description="Quantum-assisted OTFS Transceiver using QISFFT and QSFFT",
    python_requires=">=3.8",
)
