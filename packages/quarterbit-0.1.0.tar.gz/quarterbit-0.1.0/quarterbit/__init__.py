"""
QuarterBit
==========

Precision computing library.

Usage:
    from quarterbit.torch import Adam

Copyright (c) 2026 Clouthier Simulation Labs. All rights reserved.
"""

__version__ = "1.0.0"
__author__ = "Kyle Clouthier"
__license__ = "Proprietary"

import os as _os
import hashlib as _hashlib
import platform as _platform

# ============================================================================
# License Validation (stub - implement full validation later)
# ============================================================================

_LICENSE_KEY = _os.environ.get("QUARTERBIT_LICENSE_KEY", "")
_VALIDATED = False

def _validate_license():
    """Validate license key. Returns tier or raises."""
    global _VALIDATED

    if _VALIDATED:
        return True

    # Free tier: limited functionality
    if not _LICENSE_KEY:
        _VALIDATED = True
        return "free"

    # TODO: Implement full license validation against server
    # For now, any key = pro tier
    _VALIDATED = True
    return "pro"

def _check_environment():
    """Check for debugging/reverse engineering attempts."""
    # Basic anti-debug checks
    suspicious = []

    # Check for common debuggers
    if _os.environ.get("PYTHONDEBUG"):
        suspicious.append("debug_mode")

    # Check for trace
    import sys
    if sys.gettrace() is not None:
        suspicious.append("trace_active")

    return suspicious

# Run checks on import
_tier = _validate_license()
_suspicious = _check_environment()

if _suspicious and _tier == "free":
    import warnings
    warnings.warn("QuarterBit: Debug mode detected. Some features disabled.")

# ============================================================================
# Public API
# ============================================================================

def get_version():
    """Get QuarterBit version."""
    return __version__

def get_license_tier():
    """Get current license tier."""
    return _tier

def is_available():
    """Check if QuarterBit GPU backend is available."""
    try:
        from .torch.utils import is_available as _gpu_available
        return _gpu_available()
    except ImportError:
        return False

# Lazy imports for submodules
def __getattr__(name):
    if name == "torch":
        from . import torch
        return torch
    raise AttributeError(f"module 'quarterbit' has no attribute '{name}'")
