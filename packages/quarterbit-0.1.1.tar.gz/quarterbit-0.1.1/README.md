# QuarterBit

**The Pareto-Optimal Optimizer for PyTorch**

Better precision. Less memory. Faster training. No tradeoffs.

## The Problem

Standard FP32 training loses precision over long runs. Tiny gradient updates get rounded away, causing:
- Stalled convergence in late training
- Wasted GPU hours
- Suboptimal final models

## The Solution

QuarterBit's `CompactEFTAdam` combines **compressed storage** with **EFT (Error-Free Transformation) arithmetic** to achieve:

| Metric | PyTorch Adam | CompactEFTAdam | Improvement |
|--------|--------------|----------------|-------------|
| Precision | Loses 100% of tiny updates | Loses 0% | **1,000,000x** |
| Memory | 16 B/param | 9.25-13.25 B/param | **17-42% savings** |
| Convergence | 41 steps to target | 27 steps | **34% faster** |

## Installation

```bash
pip install quarterbit
```

## Quick Start

```python
from quarterbit.torch import CompactEFTAdam

# Drop-in replacement for torch.optim.Adam
optimizer = CompactEFTAdam(model.parameters(), lr=1e-3)

# Train as usual
for batch in dataloader:
    loss = model(batch)
    loss.backward()
    optimizer.step()
    optimizer.zero_grad()
```

## Why QuarterBit?

### 1. Precision That Matters
After 500K training steps, standard FP32 loses **100%** of tiny gradient updates. QuarterBit's EFT arithmetic preserves every bit.

### 2. Memory Efficiency
Train larger models on the same GPU. CompactEFTAdam uses compressed FP16+FP4 storage, saving 17-42% memory.

### 3. Faster Convergence
Better precision = faster convergence. Reach your target loss in 34% fewer steps.

### 4. Drop-In Replacement
No code changes needed. Just swap your optimizer.

## Benchmarks

See our [Kaggle notebook](https://www.kaggle.com/code/kyleclouthier/quarterbit-benchmark-v2) for full benchmarks on GPT-2.

## Requirements

- Python 3.8+
- PyTorch 2.0+
- NVIDIA GPU with CUDA support

## Pricing

| Tier | Price | Use Case |
|------|-------|----------|
| **Free** | $0 | Personal, research, evaluation (<10 GPU-hrs/mo) |
| **Pro** | $299/mo | Commercial use, up to 10 GPUs |
| **Team** | $2,499/mo | Up to 100 GPUs, priority support |
| **Enterprise** | Custom | Unlimited GPUs, custom SLA |

See [quarterbit.dev/pricing](https://quarterbit.dev/pricing) for details.

## License

Proprietary - see [LICENSE](LICENSE) for details. Free tier available for non-commercial use.

## Links

- Website: [quarterbit.dev](https://quarterbit.dev)
- GitHub: [github.com/DigitalMax321/quarterbit](https://github.com/DigitalMax321/quarterbit)
- Email: info@quarterbit.dev
