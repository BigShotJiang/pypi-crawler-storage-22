"""
QuarterBit
==========

Precision optimizer for PyTorch. 1,000,000x more accurate than FP32.

Usage:
    from quarterbit.torch import CompactEFTAdam
    optimizer = CompactEFTAdam(model.parameters(), lr=1e-3)

Activate license:
    quarterbit activate <YOUR_LICENSE_KEY>

Copyright (c) 2026 Clouthier Simulation Labs. All rights reserved.
"""

__version__ = "0.1.4"
__author__ = "Kyle Clouthier"
__license__ = "Proprietary"

from .license import (
    get_license_info,
    activate,
    deactivate,
    check_license,
    track_usage,
    LicenseError,
    UsageLimitError,
)

# Get current license tier on import
_license_info = get_license_info()
_tier = _license_info["tier"]

# Show activation message for free tier (only once)
if not _license_info["activated"]:
    import sys
    if sys.stderr.isatty():
        print(
            f"QuarterBit v{__version__} (Free tier - {_license_info['usage']['gpu_hours_limit']} GPU-hrs/month)\n"
            f"Activate: quarterbit activate <YOUR_KEY> | Get key: quarterbit.dev",
            file=sys.stderr
        )


def get_version():
    """Get QuarterBit version."""
    return __version__


def get_tier():
    """Get current license tier."""
    return _tier


def is_available():
    """Check if QuarterBit GPU backend is available."""
    try:
        from .torch.utils import is_available as _gpu_available
        return _gpu_available()
    except ImportError:
        return False


# Lazy imports for submodules
def __getattr__(name):
    if name == "torch":
        from . import torch
        return torch
    if name == "license":
        from . import license
        return license
    raise AttributeError(f"module 'quarterbit' has no attribute '{name}'")
