"""
QuarterBit PyTorch Backend
==========================

Precision optimizers for PyTorch.

Usage:
    from quarterbit.torch import Adam
    optimizer = Adam(model.parameters(), lr=1e-3)

Copyright (c) 2026 Clouthier Simulation Labs. All rights reserved.
"""

try:
    import torch
except ImportError:
    raise ImportError(
        "PyTorch is required but not installed.\n"
        "Install it first: pip install torch\n"
        "See https://pytorch.org/get-started for CUDA-specific versions."
    )

from .optim import SGD, Adam, AdamW, CompactAdam, CompactEFTAdam
from .functional import eft_matmul, eft_sum, eft_accumulate
from .utils import get_backend_info, is_available

__all__ = [
    'SGD', 'Adam', 'AdamW', 'CompactAdam', 'CompactEFTAdam',
    'eft_matmul', 'eft_sum', 'eft_accumulate',
    'get_backend_info', 'is_available'
]
