"""
QuarterBit Build Script
=======================

Compiles Python modules to binary extensions using Cython.
This protects the proprietary EFT algorithms from inspection.

Usage:
    python setup.py build_ext --inplace   # Build locally
    python setup.py bdist_wheel           # Build wheel for PyPI
"""

import os
import sys
from setuptools import setup, find_packages
from Cython.Build import cythonize
from Cython.Distutils import build_ext
from setuptools.extension import Extension

# Modules to compile (protect these)
CYTHON_MODULES = [
    "quarterbit/torch/optim.py",
    "quarterbit/torch/functional.py",
    "quarterbit/torch/utils.py",
    "quarterbit/license.py",
]

# Create Extension objects
extensions = []
for module_path in CYTHON_MODULES:
    if os.path.exists(module_path):
        module_name = module_path.replace("/", ".").replace("\\", ".").replace(".py", "")
        extensions.append(
            Extension(
                module_name,
                [module_path],
                # Compiler directives for optimization
                define_macros=[("CYTHON_TRACE", "0")],
            )
        )

# Cython compiler directives
cython_directives = {
    "language_level": "3",
    "boundscheck": False,
    "wraparound": False,
    "cdivision": True,
    "embedsignature": False,  # Don't embed signatures (hide API)
}

setup(
    name="quarterbit",
    version="0.1.4",
    description="Precision optimizer for PyTorch - 1,000,000x more accurate than FP32",
    author="Kyle Clouthier",
    author_email="info@quarterbit.dev",
    url="https://quarterbit.dev",
    packages=find_packages(),
    ext_modules=cythonize(
        extensions,
        compiler_directives=cython_directives,
        annotate=False,  # Don't generate HTML annotation files
    ),
    cmdclass={"build_ext": build_ext},
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.20",
        "requests>=2.20",
    ],
    entry_points={
        "console_scripts": [
            "quarterbit=quarterbit.license:main",
        ],
    },
    package_data={
        "quarterbit": ["bin/*.so", "bin/*.dll"],
    },
    include_package_data=True,
    zip_safe=False,
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
