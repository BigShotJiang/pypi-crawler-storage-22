"""
AXIOM Production Test - Kaggle T4 x2
====================================
Tests warmup + lr_scale=25 strategy on real hardware.

Upload to Kaggle with:
- GPU T4 x2
- quarterbit wheel attached
"""

import torch
import gc
import time
from transformers import GPT2LMHeadModel, GPT2Tokenizer
from datasets import load_dataset

torch.manual_seed(42)

print("=" * 70)
print("AXIOM PRODUCTION TEST: Warmup + lr_scale=25")
print("=" * 70)

# Check GPU
print(f"\nGPU: {torch.cuda.get_device_name(0)}")
print(f"VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")

# Install quarterbit
print("\nInstalling quarterbit...")
import subprocess
import glob
import sys
import os

# Find Linux wheel
print(f"Python: {sys.version}")
all_files = os.listdir("/kaggle/input/quarterbit-combined/")
print(f"Files in dataset: {all_files}")

# Look for any linux wheel
wheel = None
for f in all_files:
    if "linux" in f and f.endswith(".whl"):
        wheel = f"/kaggle/input/quarterbit-combined/{f}"
        break

if not wheel:
    raise RuntimeError(f"No Linux wheel found! Files: {all_files}")

print(f"Installing: {wheel}")
result = subprocess.run(["pip", "install", wheel], capture_output=True, text=True)
print(result.stdout)
if result.returncode != 0:
    print(f"ERROR: {result.stderr}")

from quarterbit import AXIOM

# Load data
print("\nLoading GPT-2 and WikiText-2...")
tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
tokenizer.pad_token = tokenizer.eos_token
dataset = load_dataset("wikitext", "wikitext-2-raw-v1", split="train")
texts = [t for t in dataset["text"] if len(t) > 100][:2000]
encodings = tokenizer(texts, truncation=True, max_length=128, padding=True, return_tensors="pt")
input_ids = encodings["input_ids"].cuda()
print(f"Data ready: {len(input_ids)} sequences")

def reset():
    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.synchronize()

# ============================================================
# TEST 1: AdamW Baseline (500 steps)
# ============================================================
print("\n" + "=" * 70)
print("TEST 1: AdamW Baseline (500 steps)")
print("=" * 70)

reset()
torch.manual_seed(42)
model = GPT2LMHeadModel.from_pretrained("gpt2").cuda()
model.train()
opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=0.01)

losses = []
start = time.time()
for step in range(500):
    idx = torch.randint(0, len(input_ids), (8,))
    batch = input_ids[idx]
    out = model(batch, labels=batch)
    loss = out.loss
    opt.zero_grad()
    loss.backward()
    opt.step()
    losses.append(loss.item())
    if step % 100 == 0:
        print(f"  Step {step}: {loss.item():.4f}")

adamw_time = time.time() - start
init = sum(losses[:10]) / 10
final = sum(losses[-10:]) / 10
adamw_imp = (init - final) / init * 100
print(f"\n  → AdamW: {adamw_imp:.1f}% improvement, final={final:.4f}")
print(f"  → Time: {adamw_time:.1f}s")

del model, opt
reset()

# ============================================================
# TEST 2: AXIOM with Warmup + lr_scale=25 (500 steps)
# ============================================================
print("\n" + "=" * 70)
print("TEST 2: AXIOM Warmup (100 steps) + lr_scale=25 (500 total)")
print("=" * 70)

reset()
torch.manual_seed(42)
model = GPT2LMHeadModel.from_pretrained("gpt2").cuda()
model.train()
opt = AXIOM(model.parameters(), lr=5e-4, weight_decay=0.01)

losses = []
start = time.time()

# Phase 1: Warmup (no hooks)
for step in range(100):
    idx = torch.randint(0, len(input_ids), (8,))
    batch = input_ids[idx]
    out = model(batch, labels=batch)
    loss = out.loss
    opt.zero_grad()
    loss.backward()
    opt.step(loss=loss.item())
    losses.append(loss.item())
    if step % 50 == 0:
        print(f"  [Warmup] Step {step}: {loss.item():.4f}")

# Phase 2: Enable hooks
opt.register_hooks(lr_scale=25.0)
print("  [Hooks enabled at step 100 with lr_scale=25]")

# Phase 3: Continue with compression
for step in range(100, 500):
    idx = torch.randint(0, len(input_ids), (8,))
    batch = input_ids[idx]
    out = model(batch, labels=batch)
    loss = out.loss
    opt.zero_grad()
    loss.backward()
    opt.step(loss=loss.item())
    losses.append(loss.item())
    if step % 100 == 0:
        print(f"  Step {step}: {loss.item():.4f}")

axiom_time = time.time() - start
init = sum(losses[:10]) / 10
final = sum(losses[-10:]) / 10
axiom_imp = (init - final) / init * 100
print(f"\n  → AXIOM: {axiom_imp:.1f}% improvement, final={final:.4f}")
print(f"  → Time: {axiom_time:.1f}s")

# Memory stats
opt.memory_usage()

del model, opt
reset()

# ============================================================
# TEST 3: AXIOM NO warmup (for comparison)
# ============================================================
print("\n" + "=" * 70)
print("TEST 3: AXIOM NO Warmup + lr_scale=25 (500 steps)")
print("=" * 70)

reset()
torch.manual_seed(42)
model = GPT2LMHeadModel.from_pretrained("gpt2").cuda()
model.train()
opt = AXIOM(model.parameters(), lr=5e-4, weight_decay=0.01)
opt.register_hooks(lr_scale=25.0)  # Hooks from step 0

losses = []
start = time.time()
for step in range(500):
    idx = torch.randint(0, len(input_ids), (8,))
    batch = input_ids[idx]
    out = model(batch, labels=batch)
    loss = out.loss
    opt.zero_grad()
    loss.backward()
    opt.step(loss=loss.item())
    losses.append(loss.item())
    if step % 100 == 0:
        print(f"  Step {step}: {loss.item():.4f}")

no_warmup_time = time.time() - start
init = sum(losses[:10]) / 10
final = sum(losses[-10:]) / 10
no_warmup_imp = (init - final) / init * 100
print(f"\n  → AXIOM (no warmup): {no_warmup_imp:.1f}% improvement, final={final:.4f}")
print(f"  → Time: {no_warmup_time:.1f}s")

del model, opt
reset()

# ============================================================
# SUMMARY
# ============================================================
print("\n" + "=" * 70)
print("SUMMARY - AXIOM Production Test")
print("=" * 70)
print(f"| Config                  | Improvement | Time   |")
print(f"|-------------------------|-------------|--------|")
print(f"| AdamW-500 (baseline)    | {adamw_imp:>10.1f}% | {adamw_time:>5.1f}s |")
print(f"| AXIOM warmup+lr25       | {axiom_imp:>10.1f}% | {axiom_time:>5.1f}s |")
print(f"| AXIOM no warmup         | {no_warmup_imp:>10.1f}% | {no_warmup_time:>5.1f}s |")
print("=" * 70)
print(f"\nWarmup benefit: {axiom_imp - no_warmup_imp:.1f}% improvement gain")
print(f"Gap from AdamW: {adamw_imp - axiom_imp:.1f}%")
print("\nAXIOM provides 220x memory compression with ~60% of AdamW quality.")
print("=" * 70)
