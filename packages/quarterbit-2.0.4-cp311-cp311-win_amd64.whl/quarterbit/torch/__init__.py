"""
QuarterBit PyTorch Backend
==========================

Memory-efficient precision optimizer for PyTorch.

Usage:
    from quarterbit.torch import CompactEFTAdam
    optimizer = CompactEFTAdam(model.parameters(), lr=1e-3)

Copyright (c) 2026 Clouthier Simulation Labs. All rights reserved.
"""

try:
    import torch
except ImportError:
    raise ImportError(
        "PyTorch is required but not installed.\n"
        "Install it first: pip install torch\n"
        "See https://pytorch.org/get-started for CUDA-specific versions."
    )

# v2 is the primary optimizer
from .optim_v2 import CompactEFTAdamV2

# Aliases - CompactEFTAdam now points to v2
CompactEFTAdam = CompactEFTAdamV2

from .utils import get_backend_info, is_available

__all__ = [
    'CompactEFTAdam',      # Primary (v2)
    'CompactEFTAdamV2',    # Explicit v2
    'get_backend_info',
    'is_available',
]
