"""
QuarterBit
==========

Memory-efficient optimizer for PyTorch.

Usage:
    from quarterbit import Axiom
    optimizer = Axiom(model.parameters(), lr=1e-3)

Copyright (c) 2026 Clouthier Simulation Labs. All rights reserved.
"""

__version__ = "4.0.1"
__author__ = "Kyle Clouthier"

from .torch.optim import Axiom

__all__ = ['Axiom']
