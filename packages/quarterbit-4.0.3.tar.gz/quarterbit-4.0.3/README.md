# QuarterBit AXIOM

**World's Most Memory-Efficient Drift-Free Optimizer**

90%+ memory savings. Zero precision loss. Train larger models.

## The Problem

Training large AI models requires massive GPU memory for optimizer states. Adam stores 8 bytes per parameter just for momentum and variance - that's 8GB for a 1B parameter model.

Additionally, long training runs suffer from **floating-point drift** - tiny gradient updates accumulate rounding errors over millions of steps, causing:
- Stalled convergence in late training
- Numerical instability
- Suboptimal final models

## The Solution

QuarterBit **AXIOM** solves both problems:

| Metric | Adam | AXIOM | Improvement |
|--------|------|-------|-------------|
| Memory per param | 8.0 bytes | 0.76 bytes | **90%+ savings** |
| Precision drift | Accumulates errors | **Drift-free** | Eliminated |
| Max model (16GB GPU) | ~1.0B params | ~2.7B params | **2.7x larger** |

## Installation

```bash
pip install quarterbit
```

**Supported GPUs:**
- NVIDIA T4, V100, A100, L4, L40
- NVIDIA RTX 30 series (3060-3090)
- NVIDIA RTX 40 series (4060-4090)
- NVIDIA H100, H200

## Quick Start

```python
from quarterbit import Axiom

# Drop-in replacement for Adam
optimizer = Axiom(model.parameters(), lr=1e-3)

# Optional: set training schedule for adaptive LR
optimizer.set_schedule(total_steps=10000, warmup_steps=1000)

# Train as usual
for batch in dataloader:
    loss = model(batch)
    loss.backward()
    optimizer.step()
    optimizer.zero_grad()
```

## Why AXIOM?

### 1. Massive Memory Savings
Train 2.7x larger models on the same GPU. AXIOM uses proprietary compression to reduce optimizer state from 8 bytes to under 1 byte per parameter.

### 2. Drift-Free Training
Proprietary precision algorithms eliminate floating-point accumulation errors. Your model trains with perfect numerical stability from step 1 to step 1,000,000+.

### 3. Cloud Cost Reduction
Less memory = fewer GPUs = lower costs. Typical savings of 30-50% on cloud training bills.

### 4. Drop-In Replacement
Same API as PyTorch Adam. Change one line of code.

## Benchmarks

Validated on GPT-2 (124M parameters):

| Optimizer | Final Loss | Memory | Status |
|-----------|-----------|--------|--------|
| AdamW | 3.12 | 1,024 MB | Baseline |
| 8-bit Adam | 3.14 | 640 MB | -37% |
| Adafactor | 3.18 | 512 MB | -50% |
| **AXIOM** | **3.11** | **95 MB** | **-91%** |

See our [Kaggle benchmark](https://www.kaggle.com/code/kyleclouthier/quarterbit-axiom-benchmark) for full results including OOM stress tests and cost analysis.

## Requirements

- Python 3.8+
- PyTorch 1.8+
- NVIDIA GPU with CUDA support
- Linux or Windows

## Pricing

| Tier | Price | Use Case |
|------|-------|----------|
| **Free** | $0 | Personal, research, evaluation |
| **Pro** | $299/mo | Commercial use, up to 10 GPUs |
| **Team** | $2,499/mo | Up to 100 GPUs, priority support |
| **Enterprise** | Custom | Unlimited, custom SLA |

See [quarterbit.dev/pricing](https://quarterbit.dev/pricing) for details.

## License

Proprietary - see [LICENSE](LICENSE) for details. Free tier available.

## Links

- Website: [quarterbit.dev](https://quarterbit.dev)
- Documentation: [quarterbit.dev/docs](https://quarterbit.dev/docs)
- Email: info@quarterbit.dev

---

Copyright (c) 2026 Clouthier Simulation Labs. All rights reserved.
