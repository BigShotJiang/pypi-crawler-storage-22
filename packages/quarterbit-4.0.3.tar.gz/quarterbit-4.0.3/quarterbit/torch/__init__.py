"""
QuarterBit PyTorch Backend
==========================

Usage:
    from quarterbit import Axiom
    optimizer = Axiom(model.parameters(), lr=1e-3)

Copyright (c) 2026 Clouthier Simulation Labs. All rights reserved.
"""

from .optim import Axiom

__all__ = ['Axiom']
