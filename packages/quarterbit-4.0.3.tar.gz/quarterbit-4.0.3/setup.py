"""
QuarterBit Build Script
=======================

Compiles Python to binary extensions using Cython for IP protection.

Usage:
    python setup.py build_ext --inplace   # Build locally
    python setup.py bdist_wheel           # Build wheel for PyPI

Copyright (c) 2026 Clouthier Simulation Labs. All rights reserved.
"""

import os
import sys
import platform
from setuptools import setup, find_packages
from setuptools.extension import Extension

# Check for Cython
try:
    from Cython.Build import cythonize
    from Cython.Distutils import build_ext
    USE_CYTHON = True
except ImportError:
    USE_CYTHON = False
    print("Cython not found - building without compilation")

# Version
VERSION = "4.0.3"

# Modules to compile (protect these)
CYTHON_MODULES = [
    "quarterbit/torch/optim.py",
]

# Platform-specific library files
if platform.system() == "Windows":
    LIB_FILES = ["lib/*.dll"]
else:
    LIB_FILES = ["lib/*.so"]

# Create extensions if Cython available
extensions = []
if USE_CYTHON:
    for module_path in CYTHON_MODULES:
        if os.path.exists(module_path):
            module_name = module_path.replace("/", ".").replace("\\", ".").replace(".py", "")
            extensions.append(
                Extension(
                    module_name,
                    [module_path],
                    define_macros=[("CYTHON_TRACE", "0")],
                )
            )

# Cython compiler directives
cython_directives = {
    "language_level": "3",
    "boundscheck": False,
    "wraparound": False,
    "cdivision": True,
    "embedsignature": False,  # Hide API signatures
}

# Setup configuration
setup_kwargs = dict(
    name="quarterbit",
    version=VERSION,
    description="Memory-efficient optimizer for PyTorch",
    long_description=open("README.md").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="Kyle Clouthier",
    author_email="info@clouthiersimulation.com",
    url="https://github.com/clouthiersimulation/quarterbit",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "torch>=1.8",
        "numpy>=1.20",
    ],
    package_data={
        "quarterbit": LIB_FILES,
    },
    include_package_data=True,
    zip_safe=False,
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="optimizer pytorch deep-learning machine-learning",
)

# Add Cython compilation if available
if USE_CYTHON and extensions:
    setup_kwargs["ext_modules"] = cythonize(
        extensions,
        compiler_directives=cython_directives,
        annotate=False,
    )
    setup_kwargs["cmdclass"] = {"build_ext": build_ext}

setup(**setup_kwargs)
