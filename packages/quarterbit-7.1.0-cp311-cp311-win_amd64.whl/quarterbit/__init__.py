"""
QuarterBit v7 - AXIOM Optimizer
===============================

90.5% memory savings vs Adam. Beats AdamW on convergence.

Usage:
    from quarterbit import Axiom
    optimizer = Axiom(model.parameters(), lr=1e-3, total_steps=10000)

Copyright (c) 2026 Clouthier Simulation Labs. All rights reserved.
"""

__version__ = "7.1.0"
__author__ = "Kyle Clouthier"

from .torch import Axiom

__all__ = ['Axiom']
