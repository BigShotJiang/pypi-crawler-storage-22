"""
QuarterBit Memory Utilities
===========================

Optional utilities for memory-constrained training:
- ActivationCheckpoint: 62% activation memory reduction
- GradientCompressor: 62% gradient memory reduction for DDP

Copyright (c) 2026 Clouthier Simulation Labs. All rights reserved.
"""

import torch
import ctypes
import os
from typing import Optional


def _load_lib(name: str):
    """Load a CUDA library by name."""
    if os.name == 'nt':
        lib_name = f'{name}.dll'
    else:
        lib_name = f'lib{name}.so'

    search_paths = [
        os.path.join(os.path.dirname(__file__), '..', 'lib', lib_name),
        os.path.join(os.path.dirname(__file__), '..', '..', 'build', lib_name),
        os.path.join(os.path.dirname(__file__), '..', '..', '..', 'build', lib_name),
        os.path.join('C:', 'QuarterBit', 'build', lib_name),
        '/kaggle/working/build/' + lib_name,
    ]

    for path in search_paths:
        if os.path.exists(path):
            try:
                return ctypes.CDLL(path)
            except Exception:
                continue
    return None


class ActivationCheckpoint:
    """
    Compressed activation storage for gradient checkpointing.

    Compresses FP32 activations to FP4 L1 format (62% memory reduction).
    Use as drop-in replacement for storing activations during forward pass.

    Args:
        max_slots: Number of checkpoint slots (e.g., num_layers)
        max_elements: Maximum elements per activation tensor

    Example:
        >>> actcp = ActivationCheckpoint(num_layers=12, max_elements=1024*1024)
        >>> # During forward:
        >>> actcp.store(activation, slot=layer_idx)
        >>> # During backward:
        >>> restored = actcp.restore(slot=layer_idx, shape=activation.shape)
    """

    def __init__(self, max_slots: int, max_elements: int):
        self._lib = _load_lib('axiom_actcp')
        if self._lib is None:
            raise RuntimeError("ActivationCheckpoint CUDA library not found")

        # Setup function signatures
        self._lib.axiom_actcp_create.argtypes = [ctypes.c_int, ctypes.c_int]
        self._lib.axiom_actcp_create.restype = ctypes.c_void_p

        self._lib.axiom_actcp_store.argtypes = [
            ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int
        ]
        self._lib.axiom_actcp_store.restype = ctypes.c_int

        self._lib.axiom_actcp_restore.argtypes = [
            ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int
        ]
        self._lib.axiom_actcp_restore.restype = ctypes.c_int

        self._lib.axiom_actcp_clear_slot.argtypes = [ctypes.c_void_p, ctypes.c_int]
        self._lib.axiom_actcp_clear_all.argtypes = [ctypes.c_void_p]

        self._lib.axiom_actcp_memory.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)
        ]

        self._lib.axiom_actcp_destroy.argtypes = [ctypes.c_void_p]

        self._handle = self._lib.axiom_actcp_create(max_slots, max_elements)
        if not self._handle:
            raise RuntimeError("Failed to create ActivationCheckpoint handle")

        self._max_slots = max_slots
        self._max_elements = max_elements
        self._shapes = {}  # slot -> original shape

    def store(self, tensor: torch.Tensor, slot: int) -> None:
        """
        Store activation tensor in compressed format.

        Args:
            tensor: CUDA FP32 tensor to store
            slot: Slot index (0 to max_slots-1)
        """
        if not tensor.is_cuda or tensor.dtype != torch.float32:
            raise ValueError("Tensor must be CUDA float32")
        if slot < 0 or slot >= self._max_slots:
            raise ValueError(f"Slot {slot} out of range [0, {self._max_slots})")

        flat = tensor.contiguous().view(-1)
        n = flat.numel()

        if n > self._max_elements:
            raise ValueError(f"Tensor size {n} exceeds max_elements {self._max_elements}")

        self._shapes[slot] = tensor.shape

        ret = self._lib.axiom_actcp_store(self._handle, flat.data_ptr(), n, slot)
        if ret != 0:
            raise RuntimeError(f"axiom_actcp_store failed with code {ret}")

    def restore(self, slot: int, shape: Optional[tuple] = None) -> torch.Tensor:
        """
        Restore activation tensor from compressed format.

        Args:
            slot: Slot index
            shape: Output shape (uses stored shape if None)

        Returns:
            Restored tensor
        """
        if slot < 0 or slot >= self._max_slots:
            raise ValueError(f"Slot {slot} out of range")

        if shape is None:
            shape = self._shapes.get(slot)
            if shape is None:
                raise ValueError(f"No shape stored for slot {slot}, provide shape explicitly")

        n = 1
        for s in shape:
            n *= s

        out = torch.empty(n, dtype=torch.float32, device='cuda')
        ret = self._lib.axiom_actcp_restore(self._handle, out.data_ptr(), n, slot)
        if ret != 0:
            raise RuntimeError(f"axiom_actcp_restore failed with code {ret}")

        return out.view(shape)

    def clear(self, slot: Optional[int] = None) -> None:
        """Clear one slot or all slots."""
        if slot is not None:
            self._lib.axiom_actcp_clear_slot(self._handle, slot)
            self._shapes.pop(slot, None)
        else:
            self._lib.axiom_actcp_clear_all(self._handle)
            self._shapes.clear()

    def memory_info(self) -> dict:
        """Get memory usage statistics."""
        actual = ctypes.c_size_t()
        fp32 = ctypes.c_size_t()
        self._lib.axiom_actcp_memory(self._handle, ctypes.byref(actual), ctypes.byref(fp32))
        return {
            'actual_bytes': actual.value,
            'fp32_bytes': fp32.value,
            'savings_pct': (1 - actual.value / max(fp32.value, 1)) * 100
        }

    def __del__(self):
        if hasattr(self, '_handle') and self._handle:
            self._lib.axiom_actcp_destroy(self._handle)


class GradientCompressor:
    """
    Drift-free gradient compression with error feedback.

    Compresses FP32 gradients to FP4 L1 format (62% memory reduction).
    Error feedback ensures no gradient information is lost over time.

    Useful for distributed training (DDP) to reduce communication.

    Args:
        num_elements: Number of gradient elements

    Example:
        >>> compressor = GradientCompressor(model_param.numel())
        >>> # Compress gradients before all-reduce
        >>> compressed = compressor.compress(param.grad)
        >>> # ... communicate compressed ...
        >>> # Decompress after communication
        >>> param.grad = compressor.decompress(compressed)
    """

    def __init__(self, num_elements: int):
        self._lib = _load_lib('axiom_gradcomp')
        if self._lib is None:
            raise RuntimeError("GradientCompressor CUDA library not found")

        # Setup function signatures
        self._lib.axiom_gradcomp_create.argtypes = [ctypes.c_int]
        self._lib.axiom_gradcomp_create.restype = ctypes.c_void_p

        self._lib.axiom_gradcomp_compress.argtypes = [
            ctypes.c_void_p,
            ctypes.c_void_p,  # grads
            ctypes.c_void_p, ctypes.c_void_p,  # q, qs
            ctypes.c_void_p, ctypes.c_void_p,  # r, rs
            ctypes.c_int
        ]
        self._lib.axiom_gradcomp_compress.restype = ctypes.c_int

        self._lib.axiom_gradcomp_decompress.argtypes = [
            ctypes.c_void_p,
            ctypes.c_void_p, ctypes.c_void_p,
            ctypes.c_void_p, ctypes.c_void_p,
            ctypes.c_void_p, ctypes.c_int
        ]
        self._lib.axiom_gradcomp_decompress.restype = ctypes.c_int

        self._lib.axiom_gradcomp_reset.argtypes = [ctypes.c_void_p]
        self._lib.axiom_gradcomp_destroy.argtypes = [ctypes.c_void_p]

        self._lib.axiom_gradcomp_alloc_output.argtypes = [
            ctypes.c_int,
            ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.c_void_p),
            ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.c_void_p)
        ]
        self._lib.axiom_gradcomp_alloc_output.restype = ctypes.c_int

        self._lib.axiom_gradcomp_free_output.argtypes = [
            ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p
        ]

        self._handle = self._lib.axiom_gradcomp_create(num_elements)
        if not self._handle:
            raise RuntimeError("Failed to create GradientCompressor handle")

        self._n = num_elements

        # Allocate output buffers
        self._q = ctypes.c_void_p()
        self._qs = ctypes.c_void_p()
        self._r = ctypes.c_void_p()
        self._rs = ctypes.c_void_p()

        ret = self._lib.axiom_gradcomp_alloc_output(
            num_elements,
            ctypes.byref(self._q), ctypes.byref(self._qs),
            ctypes.byref(self._r), ctypes.byref(self._rs)
        )
        if ret != 0:
            raise RuntimeError("Failed to allocate gradient compression buffers")

    def compress(self, grads: torch.Tensor) -> dict:
        """
        Compress gradients with error feedback.

        Args:
            grads: CUDA FP32 gradient tensor

        Returns:
            Dict with compressed buffer pointers (for communication)
        """
        if not grads.is_cuda or grads.dtype != torch.float32:
            raise ValueError("Gradients must be CUDA float32")

        flat = grads.contiguous().view(-1)
        n = flat.numel()

        if n > self._n:
            raise ValueError(f"Gradient size {n} exceeds allocated {self._n}")

        ret = self._lib.axiom_gradcomp_compress(
            self._handle, flat.data_ptr(),
            self._q, self._qs, self._r, self._rs, n
        )
        if ret != 0:
            raise RuntimeError(f"axiom_gradcomp_compress failed with code {ret}")

        return {
            'q': self._q, 'qs': self._qs,
            'r': self._r, 'rs': self._rs,
            'n': n, 'shape': grads.shape
        }

    def decompress(self, compressed: dict) -> torch.Tensor:
        """
        Decompress gradients.

        Args:
            compressed: Dict from compress()

        Returns:
            Decompressed gradient tensor
        """
        n = compressed['n']
        shape = compressed['shape']

        out = torch.empty(n, dtype=torch.float32, device='cuda')

        ret = self._lib.axiom_gradcomp_decompress(
            self._handle,
            compressed['q'], compressed['qs'],
            compressed['r'], compressed['rs'],
            out.data_ptr(), n
        )
        if ret != 0:
            raise RuntimeError(f"axiom_gradcomp_decompress failed with code {ret}")

        return out.view(shape)

    def reset(self) -> None:
        """Reset error feedback accumulator."""
        self._lib.axiom_gradcomp_reset(self._handle)

    def __del__(self):
        if hasattr(self, '_lib') and self._lib:
            if hasattr(self, '_q'):
                self._lib.axiom_gradcomp_free_output(
                    self._q, self._qs, self._r, self._rs
                )
            if hasattr(self, '_handle') and self._handle:
                self._lib.axiom_gradcomp_destroy(self._handle)
