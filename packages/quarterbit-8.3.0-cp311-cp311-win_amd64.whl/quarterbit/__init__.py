"""
QuarterBit - Advanced Neural Network Training
==============================================

Products:
    - Axiom:  Memory-efficient quantized optimizer (73% memory savings)
    - Verity: Bit-perfect cross-hardware reproducible optimizer

Usage:
    from quarterbit.axiom import Axiom      # Memory efficient
    from quarterbit.verity import Verity    # Bit-perfect reproducible

See quarterbit.dev for documentation and benchmarks.

Copyright (c) 2026 Clouthier Simulation Labs. All rights reserved.
"""

__version__ = "8.3.0"
__author__ = "Kyle Clouthier"

# Check for PyTorch
try:
    import torch
except ImportError:
    raise ImportError(
        "QuarterBit requires PyTorch. Install with:\n"
        "  pip install torch                                              (CPU)\n"
        "  pip install torch --index-url https://download.pytorch.org/whl/cu121  (CUDA 12.1)\n"
        "  pip install torch --index-url https://download.pytorch.org/whl/cu124  (CUDA 12.4)\n"
        "\nSee https://pytorch.org/get-started for more options."
    )

# Subpackages
from quarterbit import axiom
from quarterbit import verity

__all__ = ['axiom', 'verity']
