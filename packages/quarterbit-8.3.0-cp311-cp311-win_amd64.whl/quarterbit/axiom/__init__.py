"""
Axiom - Memory-Efficient Quantized Optimizer
=============================================

Usage:
    from quarterbit.axiom import Axiom, ActivationCheckpoint, GradientCompressor

    optimizer = Axiom(model.parameters(), lr=1e-3)
    actcp = ActivationCheckpoint(max_slots=12, max_elements=batch*seq*dim)
    gradcomp = GradientCompressor(max_elements=model_params)

Copyright (c) 2026 Clouthier Simulation Labs
"""

from quarterbit.axiom.torch.axiom import Axiom
from quarterbit.axiom.torch.actcp import ActivationCheckpoint
from quarterbit.axiom.torch.gradcomp import GradientCompressor

__version__ = "1.0.0"
__all__ = ["Axiom", "ActivationCheckpoint", "GradientCompressor"]
