"""Axiom PyTorch optimizer."""

from quarterbit.axiom.torch.axiom import Axiom

__all__ = ["Axiom"]
