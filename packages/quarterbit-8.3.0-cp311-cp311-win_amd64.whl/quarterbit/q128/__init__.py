"""Q128 - 130-bit precision computing"""
from .q128 import Q128

# Import EFT functions - may be limited in compiled .so version
try:
    from .q128_eft import TripleWord, two_sum, two_product
except ImportError:
    # Compiled .so may not have all exports
    try:
        from .q128_eft import two_sum, two_product
        TripleWord = None
    except ImportError:
        two_sum = None
        two_product = None
        TripleWord = None

