"""
Verity - Bit-Perfect Reproducible Training
===========================================

Usage:
    from quarterbit.verity import Verity

    optimizer = Verity(model.parameters(), lr=1e-3)

Copyright (c) 2026 Clouthier Simulation Labs
"""

from quarterbit.verity.torch.verity import Verity

__version__ = "2.0.0"
__all__ = ["Verity"]
