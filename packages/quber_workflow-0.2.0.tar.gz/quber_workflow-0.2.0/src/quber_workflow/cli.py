"""CLI entry point for quber-workflow package."""

import click
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from .config import WorkflowConfig
from .version import __version__

console = Console()


@click.group()
@click.version_option(version=__version__)
def main():
    """Quber Workflow - Shared Claude Code workflow for Quber projects.

    Provides Jira + GitHub automation, agents, skills, and templates.
    """
    pass


@main.command()
@click.option(
    "--config",
    "config_path",
    type=click.Path(exists=True),
    help="YAML config file",
)
@click.option("--project", help="Project name (e.g., quber-analyst)")
@click.option("--repo", help="GitHub repo (e.g., xmandeng/quber-analyst)")
@click.option("--jira-prefix", help="Jira project prefix (e.g., QUE)")
@click.option("--jira-label", help="Jira project label (e.g., quber-analyst)")
@click.option(
    "--jira-url", help="Jira instance URL (e.g., https://mandeng.atlassian.net)"
)
@click.option("--no-epic-manager", is_flag=True, help="Disable epic-manager agent")
@click.option("--no-langsmith", is_flag=True, help="Disable LangSmith tracing hooks")
@click.option("--enable-logfire", is_flag=True, help="Enable Pydantic Logfire observability")
@click.option("--no-agent-teams", is_flag=True, help="Disable experimental agent teams")
def init(
    config_path,
    project,
    repo,
    jira_prefix,
    jira_label,
    jira_url,
    no_epic_manager,
    no_langsmith,
    enable_logfire,
    no_agent_teams,
):
    """Initialize quber workflow in current project."""
    if config_path:
        config = WorkflowConfig.from_yaml(Path(config_path))
    else:
        # Use CLI args with interactive fallback for missing values
        if not project:
            project = Prompt.ask("Project name", default=Path.cwd().name)
        if not repo:
            repo = Prompt.ask("GitHub repo (owner/repo)")
        if not jira_prefix:
            jira_prefix = Prompt.ask("Jira project prefix", default="QUE")
        if not jira_label:
            jira_label = Prompt.ask("Jira project label", default=project)
        if not jira_url:
            jira_url = Prompt.ask(
                "Jira instance URL", default="https://mandeng.atlassian.net"
            )

        config = WorkflowConfig(
            project_name=project,
            repo_name=repo,
            jira_prefix=jira_prefix,
            jira_label=jira_label,
            jira_url=jira_url,
            epic_manager=not no_epic_manager,
            enable_langsmith=not no_langsmith,
            enable_logfire=enable_logfire,
            enable_agent_teams=not no_agent_teams,
        )

    # Validate
    errors = config.validate()
    if errors:
        for error in errors:
            console.print(f"[bold red]Error:[/bold red] {error}")
        raise click.Abort()

    console.print(
        Panel.fit(
            f"[bold green]Initializing Quber Workflow[/bold green]\n\n"
            f"Project: {config.project_name}\n"
            f"Repo: {config.repo_name}\n"
            f"Jira: {config.jira_prefix} ({config.jira_url})\n"
            f"Label: {config.jira_label}\n"
            f"Epic Manager: {'Yes' if config.epic_manager else 'No'}\n"
            f"LangSmith: {'Yes' if config.enable_langsmith else 'No'}\n"
            f"Logfire: {'Yes' if config.enable_logfire else 'No'}\n"
            f"Agent Teams: {'Yes' if config.enable_agent_teams else 'No'}",
            border_style="green",
        )
    )

    from .commands.init import run_init

    run_init(config)


@main.command()
def update():
    """Update workflow files to latest version."""
    console.print("[bold yellow]Updating Quber Workflow...[/bold yellow]")
    from .commands.update import run_update

    run_update()


@main.command()
def migrate():
    """Migrate existing project to use Quber Workflow."""
    console.print("[bold blue]Migrating to Quber Workflow...[/bold blue]")
    from .commands.migrate import run_migrate

    run_migrate()


@main.command()
def clean():
    """Remove workflow-managed files from .git/info/exclude."""
    console.print("[bold cyan]Cleaning up git exclude entries...[/bold cyan]")
    from .git_utils import remove_from_git_exclude

    current_dir = Path.cwd()
    git_dir = current_dir / ".git"

    if not git_dir.exists():
        console.print("[bold red]Not a git repository![/bold red]")
        return

    exclude_file = git_dir / "info" / "exclude"
    if not exclude_file.exists():
        console.print("[yellow]No .git/info/exclude file found.[/yellow]")
        return

    content = exclude_file.read_text()
    lines = content.splitlines()
    patterns_found = []
    in_quber_section = False

    for line in lines:
        if "# Files managed by quber-workflow" in line:
            in_quber_section = True
            continue
        if in_quber_section:
            if line.strip() and not line.strip().startswith("#"):
                patterns_found.append(line.strip())
            elif line.strip().startswith("#"):
                break

    if not patterns_found:
        console.print("[green]No workflow-managed entries found.[/green]")
        return

    console.print(f"\nFound {len(patterns_found)} workflow-managed entries:")
    for pattern in patterns_found:
        console.print(f"  {pattern}")

    from rich.prompt import Confirm

    if Confirm.ask("\nRemove these entries?", default=True):
        removed = remove_from_git_exclude(None, current_dir)
        console.print(
            f"\n[bold green]Removed {removed} entries from .git/info/exclude[/bold green]"
        )
    else:
        console.print("[yellow]Cleanup cancelled[/yellow]")


if __name__ == "__main__":
    main()
