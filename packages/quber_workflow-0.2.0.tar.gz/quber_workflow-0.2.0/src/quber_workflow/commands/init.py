"""Initialize quber workflow in a project."""

import shutil
from pathlib import Path
from typing import Dict, List

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from ..config import WorkflowConfig
from ..git_utils import add_to_git_exclude
from ..renderer import TemplateRenderer

console = Console()

# Template path (relative to rendered/) → output path (relative to target)
RENDER_MAP: Dict[str, str] = {
    "agents/jira-workflow.md.j2": ".claude/agents/jira-workflow.md",
    "agents/github-workflow.md.j2": ".claude/agents/github-workflow.md",
    "skills/github-operations-SKILL.md.j2": ".claude/skills/github-operations/SKILL.md",
    "skills/jira-operations-SKILL.md.j2": ".claude/skills/jira-operations/SKILL.md",
    "docs/ISSUES_SPEC.md.j2": "docs/ISSUES_SPEC.md",
    "docs/GITHUB_WORKFLOW_SPEC.md.j2": "docs/GITHUB_WORKFLOW_SPEC.md",
    "docs/PR_EVIDENCE_GUIDELINES.md.j2": "docs/PR_EVIDENCE_GUIDELINES.md",
    "docs/PR_EVIDENCE_CHECKLIST.md.j2": "docs/PR_EVIDENCE_CHECKLIST.md",
    "settings.json.j2": ".claude/settings.json",
    "CLAUDE.md.j2": "CLAUDE.md",
    "env.example.j2": ".env.example",
}

# Conditional templates: flag_name → (template_path, output_path)
CONDITIONAL_RENDER_MAP: Dict[str, tuple] = {
    "epic_manager": ("agents/epic-manager.md.j2", ".claude/agents/epic-manager.md"),
}

# Conditional static directories: flag_name → (src_relative_to_static, dest_relative_to_target)
CONDITIONAL_STATIC_DIR_MAP: Dict[str, tuple] = {
    "enable_langsmith": ("hooks", ".claude/hooks"),
}

# Static directories (relative to static/) → output path (relative to target)
STATIC_DIR_MAP: Dict[str, str] = {
    "skills/github-operations/scripts": ".claude/skills/github-operations/scripts",
    "skills/jira-operations/scripts": ".claude/skills/jira-operations/scripts",
}

# Static files (relative to static/) → output path (relative to target)
# Note: GitHub workflows must be committed, so they are NOT added to git exclude
STATIC_FILE_MAP: Dict[str, str] = {
    "github-workflows/jira-transition.yml": ".github/workflows/jira-transition.yml",
}

# Saved config location within target project
CONFIG_FILE = ".claude/.quber-workflow.yaml"


def _collect_files_for_git_exclude(target: Path, config: WorkflowConfig) -> List[str]:
    """Collect files to add to .git/info/exclude.

    Excludes .github/ files since those must be committed.
    """
    files = []

    # Rendered files
    for output_path in RENDER_MAP.values():
        files.append(output_path)

    # Conditional rendered files
    for flag, (_, output_path) in CONDITIONAL_RENDER_MAP.items():
        if getattr(config, flag, False):
            files.append(output_path)

    # Static script directories
    for dest in STATIC_DIR_MAP.values():
        dest_path = target / dest
        if dest_path.exists():
            for f in dest_path.rglob("*"):
                if f.is_file():
                    files.append(str(f.relative_to(target)))

    # Conditional static directories
    for flag, (_, dest) in CONDITIONAL_STATIC_DIR_MAP.items():
        if getattr(config, flag, False):
            dest_path = target / dest
            if dest_path.exists():
                for f in dest_path.rglob("*"):
                    if f.is_file():
                        files.append(str(f.relative_to(target)))

    # Config file
    files.append(CONFIG_FILE)

    return files


def run_init(config: WorkflowConfig) -> None:
    """Initialize quber workflow in the current project.

    Args:
        config: Validated WorkflowConfig
    """
    template_dir = Path(__file__).parent.parent / "templates"
    target = Path.cwd()
    context = config.to_template_context()

    renderer = TemplateRenderer(template_dir / "rendered")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Rendering templates...", total=None)

        # 1. Render all Jinja2 templates
        for template_path, output_path in RENDER_MAP.items():
            progress.update(task, description=f"Rendering {output_path}...")
            renderer.render_to_file(template_path, target / output_path, context)

        # 2. Render conditional templates
        for flag, (template_path, output_path) in CONDITIONAL_RENDER_MAP.items():
            if getattr(config, flag, False):
                progress.update(task, description=f"Rendering {output_path}...")
                renderer.render_to_file(
                    template_path, target / output_path, context
                )

        # 3. Copy static directories
        progress.update(task, description="Copying scripts...")
        for src, dest in STATIC_DIR_MAP.items():
            src_path = template_dir / "static" / src
            dest_path = target / dest
            if src_path.exists():
                shutil.copytree(src_path, dest_path, dirs_exist_ok=True)

        # 3b. Copy conditional static directories
        for flag, (src, dest) in CONDITIONAL_STATIC_DIR_MAP.items():
            if getattr(config, flag, False):
                src_path = template_dir / "static" / src
                dest_path = target / dest
                if src_path.exists():
                    progress.update(task, description=f"Copying {dest}...")
                    shutil.copytree(src_path, dest_path, dirs_exist_ok=True)

        # 4. Copy static files
        for src, dest in STATIC_FILE_MAP.items():
            src_path = template_dir / "static" / src
            dest_path = target / dest
            if src_path.exists():
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src_path, dest_path)

        # 5. Make scripts executable
        progress.update(task, description="Setting script permissions...")
        for script in (target / ".claude" / "skills").rglob("*.sh"):
            script.chmod(0o755)
        for script in (target / ".claude" / "hooks").rglob("*.sh"):
            script.chmod(0o755)

        # 6. Save config for update command
        progress.update(task, description="Saving configuration...")
        config.to_yaml(target / CONFIG_FILE)

        # 7. Add to .git/info/exclude
        progress.update(task, description="Updating git exclude...")
        installed = _collect_files_for_git_exclude(target, config)
        add_to_git_exclude(installed, target)

        progress.update(task, description="Done!", completed=True)

    console.print("\n[bold green]Quber workflow initialized![/bold green]\n")
    console.print("Next steps:")
    console.print("  1. Review [cyan].claude/settings.json[/cyan] for permissions")
    console.print("  2. Set required environment variables (see [cyan].env.example[/cyan])")
    console.print("  3. Configure GitHub secrets for Jira automation")
    console.print(f"\n[dim]Project: {config.project_name} ({config.repo_name})[/dim]")
