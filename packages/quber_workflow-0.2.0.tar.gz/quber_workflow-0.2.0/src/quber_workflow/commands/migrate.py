"""Migrate existing project to use quber workflow."""

import shutil
from pathlib import Path
from datetime import datetime

from rich.console import Console
from rich.prompt import Confirm, Prompt
from rich.progress import Progress, SpinnerColumn, TextColumn

from ..config import WorkflowConfig

console = Console()


def run_migrate() -> None:
    """Migrate an existing project to use quber workflow.

    Backs up existing .claude/ and .github/workflows/, then runs init
    with user-provided configuration.
    """
    current_dir = Path.cwd()
    claude_dir = current_dir / ".claude"

    console.print("[bold yellow]Migration Warning[/bold yellow]")
    console.print(
        "This will replace existing workflow files with quber-workflow templates."
    )
    console.print("Existing files will be backed up.\n")

    if not Confirm.ask("Continue with migration?"):
        console.print("[yellow]Migration cancelled[/yellow]")
        return

    # Collect project info interactively
    project_name = Prompt.ask("Project name", default=current_dir.name)
    repo_name = Prompt.ask("GitHub repo (owner/repo)")
    jira_prefix = Prompt.ask("Jira project prefix", default="QUE")
    jira_label = Prompt.ask("Jira project label", default=project_name)
    jira_url = Prompt.ask(
        "Jira instance URL", default="https://mandeng.atlassian.net"
    )

    config = WorkflowConfig(
        project_name=project_name,
        repo_name=repo_name,
        jira_prefix=jira_prefix,
        jira_label=jira_label,
        jira_url=jira_url,
    )

    errors = config.validate()
    if errors:
        for error in errors:
            console.print(f"[bold red]Error:[/bold red] {error}")
        return

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Migrating project...", total=None)

        # Backup existing files
        progress.update(task, description="Backing up existing files...")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = current_dir / f".claude.backup-{timestamp}"

        if claude_dir.exists():
            shutil.copytree(claude_dir, backup_dir / ".claude")

        gh_workflows = current_dir / ".github" / "workflows"
        if gh_workflows.exists():
            backup_dir.mkdir(parents=True, exist_ok=True)
            shutil.copytree(gh_workflows, backup_dir / ".github" / "workflows")

        # Preserve settings.local.json
        settings_local = None
        if claude_dir.exists():
            settings_local_path = claude_dir / "settings.local.json"
            if settings_local_path.exists():
                settings_local = settings_local_path.read_text()

        progress.update(task, description="Installing templates...")

    # Run initialization (has its own progress display)
    from .init import run_init

    run_init(config)

    # Restore settings.local.json
    if settings_local:
        (claude_dir / "settings.local.json").write_text(settings_local)
        console.print("[dim]Restored settings.local.json[/dim]")

    console.print(f"\n[dim]Backup at: {backup_dir}[/dim]")
