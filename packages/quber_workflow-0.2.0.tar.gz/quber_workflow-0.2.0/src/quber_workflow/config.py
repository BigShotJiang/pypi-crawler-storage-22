"""Configuration model for quber-workflow initialization."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


@dataclass
class WorkflowConfig:
    """Workflow configuration model.

    All fields map directly to Jinja2 template variables.
    """

    project_name: str  # e.g., "quber-analyst"
    repo_name: str  # e.g., "xmandeng/quber-analyst"
    jira_prefix: str  # e.g., "QUE"
    jira_label: str  # e.g., "quber-analyst"
    jira_url: str  # e.g., "https://mandeng.atlassian.net"
    epic_manager: bool = True
    enable_langsmith: bool = True
    enable_logfire: bool = False
    enable_agent_teams: bool = True
    additional_env_vars: Dict[str, str] = field(default_factory=dict)
    custom_permissions: Optional[Dict[str, List[str]]] = None

    @property
    def package_name(self) -> str:
        """Derive Python package name from project name."""
        return self.project_name.replace("-", "_")

    @classmethod
    def from_yaml(cls, path: Path) -> "WorkflowConfig":
        """Load configuration from YAML file."""
        with open(path) as f:
            data = yaml.safe_load(f)
        return cls(
            project_name=data["project_name"],
            repo_name=data["repo_name"],
            jira_prefix=data["jira_prefix"],
            jira_label=data["jira_label"],
            jira_url=data["jira_url"],
            epic_manager=data.get("epic_manager", True),
            enable_langsmith=data.get("enable_langsmith", True),
            enable_logfire=data.get("enable_logfire", False),
            enable_agent_teams=data.get("enable_agent_teams", True),
            additional_env_vars=data.get("additional_env_vars", {}),
            custom_permissions=data.get("custom_permissions"),
        )

    def to_yaml(self, path: Path) -> None:
        """Save configuration to YAML file."""
        data: Dict[str, Any] = {
            "project_name": self.project_name,
            "repo_name": self.repo_name,
            "jira_prefix": self.jira_prefix,
            "jira_label": self.jira_label,
            "jira_url": self.jira_url,
            "epic_manager": self.epic_manager,
            "enable_langsmith": self.enable_langsmith,
            "enable_logfire": self.enable_logfire,
            "enable_agent_teams": self.enable_agent_teams,
        }
        if self.additional_env_vars:
            data["additional_env_vars"] = self.additional_env_vars
        if self.custom_permissions:
            data["custom_permissions"] = self.custom_permissions
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)

    def to_template_context(self) -> Dict:
        """Convert config to template context for Jinja2 rendering."""
        ctx: Dict[str, Any] = {
            "project_name": self.project_name,
            "package_name": self.package_name,
            "repo_name": self.repo_name,
            "jira_prefix": self.jira_prefix,
            "jira_label": self.jira_label,
            "jira_url": self.jira_url,
            "enable_langsmith": self.enable_langsmith,
            "enable_logfire": self.enable_logfire,
            "enable_agent_teams": self.enable_agent_teams,
        }
        if self.additional_env_vars:
            ctx["additional_env_vars"] = self.additional_env_vars
        if self.custom_permissions:
            ctx["custom_permissions"] = self.custom_permissions
        return ctx

    def validate(self) -> List[str]:
        """Validate configuration and return list of errors."""
        errors = []
        if not self.project_name:
            errors.append("Project name is required")
        if not self.repo_name:
            errors.append("Repository name is required")
        if "/" not in self.repo_name:
            errors.append("Repository name must be in format 'owner/repo'")
        if not self.jira_prefix:
            errors.append("Jira project prefix is required")
        if not self.jira_label:
            errors.append("Jira project label is required")
        if not self.jira_url.startswith("http"):
            errors.append("Jira URL must start with http:// or https://")
        return errors
