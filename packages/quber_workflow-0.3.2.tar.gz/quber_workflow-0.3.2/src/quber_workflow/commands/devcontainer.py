"""Generate devcontainer files for a project."""

from pathlib import Path
from typing import Dict

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from ..config import WorkflowConfig
from ..renderer import TemplateRenderer

console = Console()

# Devcontainer templates: committed to repo (NOT git-excluded)
DEVCONTAINER_RENDER_MAP: Dict[str, str] = {
    "devcontainer/Dockerfile.j2": ".devcontainer/Dockerfile",
    "devcontainer/devcontainer.json.j2": ".devcontainer/devcontainer.json",
    "devcontainer/docker-compose.yml.j2": ".devcontainer/docker-compose.yml",
    "devcontainer/startup.sh.j2": ".devcontainer/startup.sh",
    "devcontainer/setup.sh.j2": ".devcontainer/setup.sh",
    "devcontainer/test-tokens.sh.j2": ".devcontainer/test-tokens.sh",
}


def run_devcontainer(config: WorkflowConfig) -> None:
    """Generate devcontainer files for the current project.

    Args:
        config: Validated WorkflowConfig with devcontainer settings
    """
    template_dir = Path(__file__).parent.parent / "templates"
    target = Path.cwd()
    context = config.to_template_context()

    renderer = TemplateRenderer(template_dir / "rendered")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Generating devcontainer...", total=None)

        # 1. Render devcontainer templates
        for template_path, output_path in DEVCONTAINER_RENDER_MAP.items():
            progress.update(task, description=f"Rendering {output_path}...")
            renderer.render_to_file(template_path, target / output_path, context)

        # 2. Make scripts executable
        progress.update(task, description="Setting script permissions...")
        for script in (target / ".devcontainer").rglob("*.sh"):
            script.chmod(0o755)

        # 3. Copy quber-workflow.yaml into .devcontainer for container startup
        progress.update(task, description="Saving configuration...")
        config.to_yaml(target / ".devcontainer" / "quber-workflow.yaml")

        progress.update(task, description="Done!", completed=True)

    console.print("\n[bold green]Devcontainer files generated![/bold green]\n")
    console.print("Generated files:")
    for output_path in DEVCONTAINER_RENDER_MAP.values():
        console.print(f"  [cyan]{output_path}[/cyan]")
    console.print(f"  [cyan].devcontainer/quber-workflow.yaml[/cyan]")
    console.print(
        f"\n[dim]These files should be committed to the repo.[/dim]"
    )
    console.print(f"[dim]Project: {config.project_name} ({config.repo_name})[/dim]")
