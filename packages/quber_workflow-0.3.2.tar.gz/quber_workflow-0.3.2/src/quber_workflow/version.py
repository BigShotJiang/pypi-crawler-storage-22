"""Version information for quber-workflow package."""

__version__ = "0.3.0"
