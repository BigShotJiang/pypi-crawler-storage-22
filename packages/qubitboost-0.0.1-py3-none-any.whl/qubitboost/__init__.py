"""QubitBoost — Quantum Error Infrastructure Platform."""
__version__ = "0.0.1"
