"""QubitBoost SDK — Enterprise quantum error infrastructure."""
__version__ = "0.0.1"
