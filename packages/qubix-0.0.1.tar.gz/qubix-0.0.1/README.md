# Qubix

Distributed GPU job queue for LLM inference.

**Status: Coming Soon**

This package is under active development. Stay tuned!

## Features (planned)
- Distributed job queue with Redis backend
- GPU worker management
- Support for multiple LLM backends (vLLM, SGLang, TGI)
- Priority-based job scheduling
- Automatic retries and fault tolerance

## Links
- GitHub: https://github.com/muid-io/qubix
- Documentation: Coming soon
