"""queenbee library."""
