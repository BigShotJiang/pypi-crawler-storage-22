"""Export Prometheus metrics generated from SQL queries."""

__version__ = "4.0.1"
