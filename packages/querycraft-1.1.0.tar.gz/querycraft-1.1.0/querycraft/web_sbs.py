#!/usr/bin/env python3
"""
Application web Flask pour QueryCraft
Permet l'exécution pas à pas de requêtes SQL via une interface web

Fichier généré initialement avec l'aide de Claude Code / Claude Sonnet 4.5 - le 2026-02-12

(c) E. Desmontils, Nantes Université, 2026
"""

import importlib.resources
import os

import colorama
from flask import Flask, render_template, request, jsonify

from querycraft.Database import DBSQLite, DBPGSQL, DBMySQL
from querycraft.SQL import SQL
from querycraft.SQLException import SQLException, SQLQueryException
from querycraft.__init__ import __version__
from querycraft.logger import setup_logger, get_logger
from querycraft.tools import readConfigFile, existFile, format_table_1, format_table_3, cadre, \
    colorize_sql_html, markdown_to_html
from querycraft.LLM import format_ia,manage_ia

app = Flask(__name__)

# Configuration globale chargée au démarrage
config = readConfigFile()
level = 'INFO'
with (importlib.resources.path("querycraft.logs",
                               f"querycraft-{__version__}-{os.getlogin()}.log")
      as log_file):
    logger = setup_logger(
        name=f"querycraft",
        level=level,
        log_file=log_file,
        verbose=config.getboolean('Autre', 'verbose'),
        console=config.getboolean('Autre', 'debug')
    )


def get_database_from_config(debug=False, verbose=False, output='html'):
    """
    Récupère la connexion à la base de données depuis la configuration

    Args:
        debug: Mode debug
        verbose: Mode verbose
        output: Format de sortie ('txt', 'html', 'md')

    Returns:
        Instance de Database (DBSQLite, DBPGSQL ou DBMySQL)
    """
    db_type = config.get('Database', 'type')
    database = config.get('Database', 'database')
    log = get_logger('querycraft.web.get_database_from_config')
    if db_type == 'sqlite':
        # SQLite: db = chemin du fichier
        # db = DBSQLite(db=str(database), debug=debug, verbose=verbose, output=output)
        if not (existFile(database)):
            log.error(f'database file not found : {database}')
            package_files = importlib.resources.files("querycraft.data")
            log.info(f'trying to search in default databases')
            if not (existFile(package_files / database)):
                log.error(f' default database file not found')
                exit(1)
            else:
                database = package_files / database
                log.info('database exists')
        else:
            log.info('database exists')
        db = DBSQLite(db=str(database), debug=debug, verbose=verbose, output=output)
    elif db_type == 'pgsql':
        # PostgreSQL: db = chaîne de connexion
        username = config.get('Database', 'username')
        password = config.get('Database', 'password')
        host = config.get('Database', 'host', fallback='localhost')
        port = config.get('Database', 'port', fallback='5432')

        connection_string = f"dbname={database} user={username} password={password} host={host} port={port}"
        db = DBPGSQL(db=connection_string, debug=debug, verbose=verbose, output=output)

    elif db_type == 'mysql':
        # MySQL: db = tuple (user, password, host, database)
        username = config.get('Database', 'username')
        password = config.get('Database', 'password')
        host = config.get('Database', 'host', fallback='localhost')

        db = DBMySQL(db=(username, password, host, database), debug=debug, verbose=verbose, output=output)

    else:
        raise ValueError(f"Type de base de données non supporté : {db_type}")

    return db


def execute_query_sbs(sql_query, step_by_step=True, verbose=False):
    """
    Exécute une requête SQL en mode pas à pas

    Args:
        sql_query: Requête SQL à exécuter
        step_by_step: Mode pas à pas activé
        verbose: Mode verbose avec aide de l'IA

    Returns:
        dict: Résultat contenant 'success', 'output', 'error', 'html_output'
    """
    result = {
        'success': False,
        'output': '',
        'error': '',
        'html_output': ''
    }

    try:
        # Vérifier le mode debug et verbose depuis la config
        debug = config.getboolean('Autre', 'debug', fallback=False)

        # Récupérer la connexion à la base de données
        db = get_database_from_config(debug=debug, verbose=verbose, output='html')
        SQLQueryException.setCfg(config)

        # Créer l'objet SQL
        sql = SQL(db.db, db.dbtype, None, None, debug, verbose, step_by_step, output='html')
        sql.setSQL(sql_query)
        html_output = []

        html_output.append(
            f"<h3>Requête étudiée</h3><div style='background:# f5f5f5;padding:15px;border-radius:5px;border-left:4px solid  # 667eea;font-family:monospace;'>{colorize_sql_html(sql_query)} </div> ")

        if verbose and config['IA']['mode'] == 'on':
            rep = manage_ia('explain', config, verbose, f"{sql_query}", sql.getDB(), None, None, sql, None, None,
                            output='html')
            rep_str = format_ia(rep, "Explication de la requête", 'html')
            html_output.append(rep_str)

        if step_by_step:
            # Exécution pas à pas : récupérer les étapes
            from querycraft.tools import format_table_2

            nb_steps, steps = sql.sbs()

            # Affichage des étapes
            for i, s in steps:
                if (i < nb_steps - 1):
                    html_output.append(
                        '<hr style="border: none; border-top: 1px solid #dee2e6; margin: 20px 0;">')
                    html_output.append(cadre(f"Étape N°{i + 1}/{nb_steps}", '—', 'html'))
                else:
                    html_output.append(
                        '<hr style="border: none; border-top: 1px solid #dee2e6; margin: 20px 0;">')
                    html_output.append(cadre(f"Étape N°{i + 1}/{nb_steps} (Résultat)", '—', 'html'))

                # Affichage des étapes intermédiaires :
                #  - textes : id = 0
                #  - tables : id in [1,3]
                #  - SQL : id = 10
                for j in s:
                    (id, t) = j
                    if id == 0:
                        if t:  # Nombre de lignes de la table
                            html_output.append(f"<p>{t}</p> <br> ")
                        else:
                            html_output.append(f"&nbsp;&nbsp;&nbsp;&nbsp;⬇︎ ")
                    elif id == 10:  # Texte formater de la requête SQL
                        # html_output.append(f"<p><pre><code>{t}</code></pre></p>")
                        html_output.append(
                            f"<div style='background:#e8f4f8;padding:15px;border-radius:5px;border-left:4px solid  # 17a2b8;font-family:monospace;'>{colorize_sql_html(t)} </div> ")
                    else:  # table(s)
                        (col, row, dif) = t
                        if id == 1:
                            html_output.append(f"{format_table_1(col, row, dif, output='html')}")
                        elif id == 2:
                            html_output.append(f"{format_table_2(col, row, dif, output='html')}")
                        elif id == 3:
                            html_output.append(f"{format_table_3(col, row, dif, output='html', inter=True)}")
                        else:
                            pass

            result['html_output'] = "\n".join(html_output)
        else:
            # Exécution directe
            from querycraft.tools import format_table_2

            headers, rows = sql.getTable()
            html_output = []

            html_output.append(f"<h3>Résultat :</h3>")

            if rows:
                table_html = format_table_2(headers, rows, output='html')
                html_output.append(table_html)
                html_output.append(f"<p><strong>{len(rows)} ligne(s) retournée(s)</strong></p>")
            else:
                html_output.append("<p><em>Aucun résultat</em></p>")

            result['html_output'] = "\n".join(html_output)

        result['success'] = True
    except SQLQueryException as e:
        result['success'] = True
        if e.hints :
            h = format_ia(e.hints, "Explication de l'erreur", output='html')
        else :
            h = ""
        result['html_output'] = e.err + '\n<br>'+ h
        #(markdown_to_html('\n'.join(e.hints)) if e.hints else "")
    except Exception as e:
        result['error'] = f"<strong>Erreur :</strong><br>{str(e)}"
        import traceback
        result['error'] += f"<br><br><pre style='background:#fff3cd;padding:10px;'>{traceback.format_exc()}</pre>"

    return result


@app.route('/')
def index():
    """Page d'accueil avec le formulaire de requête"""
    db_type = config.get('Database', 'type')
    db_name = config.get('Database', 'database')
    ia_mode = config.get('IA', 'mode', fallback='off')
    ia_service = config.get('IA', 'service', fallback='')

    return render_template('index.html',
                           db_type=db_type,
                           db_name=db_name,
                           ia_mode=ia_mode,
                           ia_service=ia_service,
                           version=__version__)


@app.route('/execute', methods=['POST'])
def execute():
    """Exécute la requête SQL et retourne le résultat"""
    data = request.get_json()
    sql_query = data.get('query', '').strip()
    step_by_step = data.get('step_by_step', True)
    verbose = data.get('verbose', False) and config.getboolean('Autre', 'verbose', fallback=False)

    if not sql_query:
        return jsonify({
            'success': False,
            'error': 'Veuillez entrer une requête SQL'
        })

    result = execute_query_sbs(sql_query, step_by_step, verbose)
    return jsonify(result)


@app.route('/schema', methods=['POST'])
def schema():
    """Affiche le schéma de la base de données"""
    data = request.get_json()
    verbose = data.get('verbose', False) and config.getboolean('Autre', 'verbose', fallback=False)

    try:
        debug = config.getboolean('Autre', 'debug', fallback=False)
        #verbose = verbose or config.getboolean('Autre', 'verbose', fallback=False)
        log = get_logger("describe")
        db = get_database_from_config(debug=debug, verbose=verbose, output='html')
        schema_html = db.describe(config, output='html')

        return jsonify({
            'success': True,
            'html_output': schema_html
        })
    except Exception as e:
        import traceback
        return jsonify({
            'success': False,
            'error': f"<strong>Erreur lors de la récupération du schéma :</strong><br>{str(e)}<br><br><pre style='background:#fff3cd;padding:10px;'>{traceback.format_exc()}</pre>"
        })


def main():
    """Point d'entrée principal de l'application web"""
    import argparse

    parser = argparse.ArgumentParser(
        description="Interface web pour QueryCraft (c) E. Desmontils, Nantes Université, 2025"
    )
    parser.add_argument('--host', default='127.0.0.1', help='Adresse IP du serveur (défaut: 127.0.0.1)')
    parser.add_argument('--port', type=int, default=5000, help='Port du serveur (défaut: 5000)')
    parser.add_argument('--debug', action='store_true', help='Mode debug Flask')

    args = parser.parse_args()

    print(f"🚀 QueryCraft Web - Démarrage du serveur...")
    print(f"📊 Base de données : {config.get('Database', 'type')} - {config.get('Database', 'database')}")
    print(f"🤖 IA : {config.get('IA', 'mode')} ({config.get('IA', 'service')})")
    print(f"🌐 Accès : http://{args.host}:{args.port}")
    print(f"\nAppuyez sur Ctrl+C pour arrêter le serveur")

    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == '__main__':
    main()
