"""CLI module for QuerySense."""

