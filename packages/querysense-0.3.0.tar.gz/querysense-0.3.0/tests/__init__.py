"""QuerySense test suite."""

