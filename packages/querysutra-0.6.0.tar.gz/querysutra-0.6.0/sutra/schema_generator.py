"""SQL schema generation from unstructured text using AI"""

import openai
import config

class SchemaGenerator:
    """Generate SQL schema from unstructured data using OpenAI"""
    
    def __init__(self, api_key: str, model_name: str = "gpt-3.5-turbo"):
        openai.api_key = api_key
        self.model_name = model_name
        self.temperature = config.TEMPERATURE
    
    def generate_schema(self, unstructured_data: str) -> str:
        """Generate SQL schema from unstructured text"""
        
        # Truncate if too long
        if len(unstructured_data) > config.MAX_TEXT_LENGTH:
            unstructured_data = unstructured_data[:config.MAX_TEXT_LENGTH]
            print(f"⚠️ Data truncated to {config.MAX_TEXT_LENGTH} characters")
        
        prompt = f"""
Convert this unstructured text into a SQLite database:

{unstructured_data}

CRITICAL Requirements:
1. Identify all entities in the text and create a table for each
2. **MANDATORY:** Add FOREIGN KEY constraints to connect related tables
   - If table A references table B, add: FOREIGN KEY (column_name) REFERENCES table_b(id)
   - Example: If employees belong to departments, employees table must have:
     department_id INTEGER, FOREIGN KEY (department_id) REFERENCES departments(id)
3. Extract ALL data from the text - don't add anything not in the text
4. Use INTEGER PRIMARY KEY AUTOINCREMENT for all ID columns
5. Ensure parent tables (referenced tables) are created BEFORE child tables

Return ONLY executable SQLite statements in this order:
1. DROP TABLE IF EXISTS statements (child tables first, parent tables last)
2. CREATE TABLE statements (parent tables first, child tables last)
3. INSERT statements (parent tables first, child tables last)

No markdown, no code blocks, no explanations - just SQL statements.
"""
        
        print("🔄 Generating schema via OpenAI API...")
        
        response = openai.ChatCompletion.create(
            model=self.model_name,
            messages=[{"role": "user", "content": prompt}],
            temperature=self.temperature
        )
        
        generated_schema = response['choices'][0]['message']['content'].strip()
        generated_schema = generated_schema.replace('```sql', '').replace('```', '').strip()
        
        print("✅ Schema generated!")
        return generated_schema