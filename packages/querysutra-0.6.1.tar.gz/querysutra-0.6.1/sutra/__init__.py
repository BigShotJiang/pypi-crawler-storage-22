"""QuerySUTRA v0.6.1 - AI-powered data analysis for structured and unstructured data"""
__version__ = "0.6.1"

from .sutra import SUTRA, QueryResult

__all__ = ["SUTRA", "QueryResult", "__version__"]
