class QueuedAlready(Exception):
    pass

class Cancelled(Exception):
    pass

class Queuefull(Exception):
    pass
