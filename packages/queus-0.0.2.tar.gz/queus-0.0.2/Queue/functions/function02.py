Queues = []
QUEUES = {}
