appname = 'queus'
version = '0.0.3'
pythons = '~=3.10'
clinton = 'Clinton Abraham'
mention = ['queue', 'queues', 'telegram']
profile = 'https://github.com/Clinton-Abraham'

DATA03 = 'Python queue'
DATA01 = "clintonabrahamc@gmail.com"
DATA02 = ['Natural Language :: English',
          'Intended Audience :: Developers',
          'Operating System :: OS Independent',
          'Programming Language :: Python :: 3.10',
          'Programming Language :: Python :: 3.11',
          'Programming Language :: Python :: 3.12',
          'Programming Language :: Python :: 3.13',
          'Programming Language :: Python :: 3.14',
         ]
