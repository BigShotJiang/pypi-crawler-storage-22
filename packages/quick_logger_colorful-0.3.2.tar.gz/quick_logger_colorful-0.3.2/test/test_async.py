import tempfile
import pytest
import asyncio
from quick_logger import asynclog

@pytest.fixture
def temp_log_dir():
    with tempfile.TemporaryDirectory() as tmp_dir:
        yield tmp_dir

# 测试异步日志输出（无阻塞）
@pytest.mark.asyncio
async def test_async_log_output(temp_log_dir):
    logger = asynclog.Logger(name="test_async", log_dir=temp_log_dir)
    
    # 异步写入日志
    msg = "async INFO message"
    await logger.info(msg)
    
    # 校验日志文件
    log_file = os.path.join(temp_log_dir, f"{logger.get_today_date()}.log")
    assert os.path.exists(log_file)
    with open(log_file, "r", encoding="utf-8") as f:
        assert msg in f.read()

# 测试异步装饰器异常捕获
@pytest.mark.asyncio
async def test_async_decorator_exception(temp_log_dir):
    @asynclog.start_logger(fatal_excs=[ValueError], log_dir=temp_log_dir)
    async def async_test_func():
        await async_test_func.logger.info("async func start")
        raise ValueError("async fatal error")
    
    # 调用异步函数（捕获异常）
    with pytest.raises(ValueError):
        await async_test_func()
    
    # 校验 FATAL 标记
    log_file = os.path.join(temp_log_dir, f"{asynclog.Logger.get_today_date()}.log")
    with open(log_file, "r", encoding="utf-8") as f:
        log_content = f.read()
        assert "[FATAL]" in log_content
        assert "async fatal error" in log_content

# 测试异步日志与事件循环兼容（无阻塞）
@pytest.mark.asyncio
async def test_async_non_blocking(temp_log_dir):
    logger = asynclog.Logger(name="test_async_non_blocking", log_dir=temp_log_dir)
    
    # 同时运行日志写入和耗时任务
    async def log_task():
        for i in range(5):
            await logger.info(f"log {i}")
            await asyncio.sleep(0.01)  # 模拟短延迟
    
    async def work_task():
        result = 0
        for i in range(1000):
            result += i
        return result
    
    # 并发执行（验证日志不阻塞工作任务）
    log_fut = asyncio.create_task(log_task())
    work_fut = asyncio.create_task(work_task())
    
    await asyncio.gather(log_fut, work_fut)
    
    # 校验工作任务完成 + 日志全部写入
    assert work_fut.result() == 499500
    log_file = os.path.join(temp_log_dir, f"{logger.get_today_date()}.log")
    with open(log_file, "r", encoding="utf-8") as f:
        assert f.read().count("log ") == 5