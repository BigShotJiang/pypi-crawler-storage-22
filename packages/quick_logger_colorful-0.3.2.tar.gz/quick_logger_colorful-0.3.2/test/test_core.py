import os
import re
import sys
import tempfile
import pytest
from quick_logger.core import Logger, start_logger

# 临时目录装饰器：自动清理测试产生的日志文件
@pytest.fixture
def temp_log_dir():
    with tempfile.TemporaryDirectory() as tmp_dir:
        yield tmp_dir

# 测试分级日志输出（文件+终端）
def test_log_grading(temp_log_dir):
    # 初始化 logger，指定临时目录（避免污染真实日志）
    logger = Logger(name="test_grading", log_dir=temp_log_dir)
    
    # 写入不同级别日志
    debug_msg = "DEBUG test message"
    info_msg = "INFO test message"
    warn_msg = "WARN test message"
    error_msg = "ERROR test message"
    fatal_msg = "FATAL test message"
    
    logger.debug(debug_msg)
    logger.info(info_msg)
    logger.warn(warn_msg)
    logger.error(error_msg)
    logger.fatal(fatal_msg)
    
    # 校验日志文件内容
    log_file = os.path.join(temp_log_dir, f"{logger.get_today_date()}.log")
    assert os.path.exists(log_file)
    
    with open(log_file, "r", encoding="utf-8") as f:
        log_content = f.read()
        # 校验所有级别日志都写入
        assert debug_msg in log_content
        assert info_msg in log_content
        assert warn_msg in log_content
        assert error_msg in log_content
        assert fatal_msg in log_content
        # 校验日志级别标记（匹配格式：[DEBUG] xxxx）
        assert re.search(r"\[DEBUG\] " + debug_msg, log_content)
        assert re.search(r"\[FATAL\] " + fatal_msg, log_content)

# 测试装饰器异常捕获 & FATAL 标记
def test_decorator_exception(temp_log_dir):
    # 自定义 FATAL 异常列表
    @start_logger(fatal_excs=[KeyError], log_dir=temp_log_dir)
    def test_func():
        test_func.logger.info("test func start")
        raise KeyError("test fatal error")
    
    # 调用函数（捕获异常，避免测试崩溃）
    with pytest.raises(KeyError):
        test_func()
    
    # 校验日志中 KeyError 被标记为 FATAL
    log_file = os.path.join(temp_log_dir, f"{Logger.get_today_date()}.log")
    with open(log_file, "r", encoding="utf-8") as f:
        log_content = f.read()
        assert "[FATAL]" in log_content
        assert "test fatal error" in log_content
        assert "KeyError" in log_content

# 测试生产模式（-O）隐藏 DEBUG 日志
def test_production_mode(temp_log_dir, monkeypatch):
    # 模拟命令行传入 -O 参数（monkeypatch 修改 sys.argv）
    monkeypatch.setattr(sys, "argv", ["test_script.py", "-O"])
    logger = Logger(name="test_prod", log_dir=temp_log_dir)
    
    logger.debug("DEBUG should be hidden")
    logger.info("INFO should be shown")
    
    # 校验日志文件中无 DEBUG 内容
    log_file = os.path.join(temp_log_dir, f"{logger.get_today_date()}.log")
    with open(log_file, "r", encoding="utf-8") as f:
        log_content = f.read()
        assert "DEBUG should be hidden" not in log_content
        assert "INFO should be shown" in log_content