# setup.py
from setuptools import setup

setup(
    author="Alabhya Dahal",
    author_email="alabhya.dahal@gmail.com",
    
)