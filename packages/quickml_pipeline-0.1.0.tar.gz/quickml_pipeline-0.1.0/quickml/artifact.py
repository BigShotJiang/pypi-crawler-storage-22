import joblib
from typing import Dict, Any

from quickml.decisions import DecisionLog


class ArtifactManager:
    VERSION = "0.1.0"

    @staticmethod
    def save(path: str, payload: Dict[str, Any]) -> None:
        joblib.dump(payload, path)

    @staticmethod
    def load(path: str) -> Dict[str, Any]:
        return joblib.load(path)
