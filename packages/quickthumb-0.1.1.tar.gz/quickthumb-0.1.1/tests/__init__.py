# Tests for quickthumb library
