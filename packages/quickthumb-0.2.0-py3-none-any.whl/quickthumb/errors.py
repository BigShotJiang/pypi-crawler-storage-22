class QuickthumbError(Exception):
    pass


class ValidationError(QuickthumbError):
    pass


class RenderingError(QuickthumbError):
    pass
