"""Version information for quiz-gen package."""

from importlib.metadata import version

__version__ = version("quiz-gen")
