import requests
from bs4 import BeautifulSoup as bs
import pandas as pd

def scrape_quote():
    BASE_URL = "https://quotes.toscrape.com/"
    url = BASE_URL
    data = []

    while url:
        response = requests.get(url)
        if response.status_code != 200:
            print("Load error", url)
            break

        soup = bs(response.text, "html.parser")
        quotes = soup.find_all("div", class_="quote")
        for quote in quotes:
            text = quote.find("span", class_="text").get_text()
            author = quote.find("small", class_="author").get_text()
            tags = [tag.get_text() for tag in quote.find_all("a", class_="tag")]
            data.append({
                "text": text,
                "author": author,
                "tags": tags
            })

        next_btn = soup.find("li", class_="next")
        if next_btn:
            url = BASE_URL + next_btn.find("a")["href"]
        else:
            url = None

    return data

quotes = scrape_quote()
df = pd.DataFrame(quotes)
df["tags_str"] = df["tags"].apply(lambda x: ", ".join(x))
all_tags = sorted({tag for tags in df["tags"] for tag in tags})
all_tags.insert(0, "All")

all_authors = sorted(df["author"].unique().tolist())
all_authors.insert(0, "All")


