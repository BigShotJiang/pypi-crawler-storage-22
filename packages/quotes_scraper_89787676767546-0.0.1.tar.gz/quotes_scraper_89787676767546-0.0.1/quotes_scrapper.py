import requests
from bs4 import BeautifulSoup
import pandas as pd

def scrape_quotes():
    BASE_URL = "https://quotes.toscrape.com/"
    url = BASE_URL
    data = []

    while url:
        response = requests.get(url)
        if response.status_code != 200:
            print("Load error", url)
            continue
        soup = BeautifulSoup(response.text, "html.parser")
        quotes = soup.find_all("div", class_="quote")
        for q in quotes:
            text = q.find("span", class_="text").get_text()
            author = q.find("small", class_="author").get_text()
            tags = [t.get_text() for t in q.find_all("a", class_="tag")]
            data.append({
                "text": text,
                "author": author,
                "tags": tags
            })

        next_btn = soup.find("li", class_="next")
        if next_btn:
            url = BASE_URL + next_btn.find("a")["href"]
        else:
            url = None

    return data

quotes_data = scrape_quotes()
df = pd.DataFrame(quotes_data)
df["tags_str"] = df["tags"].apply(lambda x: ", ".join(x))
all_tags = sorted({t for tags in df["tags"] for t in tags})
all_tags.insert(0, "All")
