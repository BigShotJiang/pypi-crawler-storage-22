from typing import TYPE_CHECKING

from quraite.adapters.base import BaseAdapter, DummyAdapter
from quraite.adapters.http_adapter import HttpAdapter

if TYPE_CHECKING:
    from quraite.adapters.agno_adapter import AgnoAdapter
    from quraite.adapters.bedrock_agents_adapter import BedrockAgentsAdapter
    from quraite.adapters.flowise_adapter import FlowiseAdapter
    from quraite.adapters.google_adk_adapter import GoogleADKAdapter
    from quraite.adapters.langchain_adapter import LangchainAdapter
    from quraite.adapters.langchain_server_adapter import LangchainServerAdapter
    from quraite.adapters.langflow_adapter import LangflowAdapter
    from quraite.adapters.n8n_adapter import N8nAdapter
    from quraite.adapters.openai_agents_adapter import OpenaiAgentsAdapter
    from quraite.adapters.pydantic_ai_adapter import PydanticAIAdapter
    from quraite.adapters.smolagents_adapter import SmolagentsAdapter


__all__ = [
    "AgnoAdapter",
    "BaseAdapter",
    "BedrockAgentsAdapter",
    "DummyAdapter",
    "FlowiseAdapter",
    "GoogleADKAdapter",
    "LangflowAdapter",
    "LangchainAdapter",
    "LangchainServerAdapter",
    "N8nAdapter",
    "OpenaiAgentsAdapter",
    "PydanticAIAdapter",
    "HttpAdapter",
    "SmolagentsAdapter",
]


def __getattr__(name: str):
    if name == "AgnoAdapter":
        from quraite.adapters.agno_adapter import AgnoAdapter

        return AgnoAdapter

    elif name == "BedrockAgentsAdapter":
        from quraite.adapters.bedrock_agents_adapter import BedrockAgentsAdapter

        return BedrockAgentsAdapter

    elif name == "FlowiseAdapter":
        from quraite.adapters.flowise_adapter import FlowiseAdapter

        return FlowiseAdapter

    elif name == "GoogleADKAdapter":
        from quraite.adapters.google_adk_adapter import GoogleADKAdapter

        return GoogleADKAdapter

    elif name == "LangflowAdapter":
        from quraite.adapters.langflow_adapter import LangflowAdapter

        return LangflowAdapter

    elif name == "LangchainAdapter":
        from quraite.adapters.langchain_adapter import LangchainAdapter

        return LangchainAdapter

    elif name == "LangchainServerAdapter":
        from quraite.adapters.langchain_server_adapter import LangchainServerAdapter

        return LangchainServerAdapter

    elif name == "N8nAdapter":
        from quraite.adapters.n8n_adapter import N8nAdapter

        return N8nAdapter

    elif name == "OpenaiAgentsAdapter":
        from quraite.adapters.openai_agents_adapter import OpenaiAgentsAdapter

        return OpenaiAgentsAdapter

    elif name == "PydanticAIAdapter":
        from quraite.adapters.pydantic_ai_adapter import PydanticAIAdapter

        return PydanticAIAdapter

    elif name == "SmolagentsAdapter":
        from quraite.adapters.smolagents_adapter import SmolagentsAdapter

        return SmolagentsAdapter

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
