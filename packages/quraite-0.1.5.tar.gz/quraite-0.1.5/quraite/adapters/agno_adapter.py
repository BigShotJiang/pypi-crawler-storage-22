import uuid

from agno.agent import Agent
from agno.team import Team
from openinference.instrumentation.agno.utils import _AGNO_PARENT_NODE_CONTEXT_KEY
from opentelemetry import context as context_api
from opentelemetry.trace import TracerProvider

from quraite.adapters.base import BaseAdapter
from quraite.constants.framework import Framework
from quraite.logger import get_logger
from quraite.schema.invoke import InvokeInput, InvokeOutput
from quraite.tracing.trace import AgentSpan, AgentTrace

logger = get_logger(__name__)


class AgnoAdapter(BaseAdapter):
    """Agno adapter for Agent and Team (requires tracing)."""

    def __init__(
        self,
        agent: Agent | Team,
        *,
        tracer_provider: TracerProvider | None = None,
        agent_name: str = "Agno Agent",
    ):
        """
        Initialize Agno adapter.

        Args:
            agent: Agno Agent or Team instance
            tracer_provider: TracerProvider from setup_tracing() (required)
            agent_name: Agent name for metadata
        """
        if tracer_provider is None:
            raise ValueError(
                "Agno adapter requires tracing. Use setup_tracing([Framework.AGNO]) first."
            )

        self.agent: Agent | Team = agent
        self.agent_name = agent_name
        self._init_tracer(tracer_provider)
        logger.info("AgnoAdapter initialized")

    async def ainvoke(self, input: InvokeInput) -> InvokeOutput:
        """Invoke Agno agent and return response with trace."""
        logger.info("ainvoke called (session_id=%s)", input.session_id)
        session_id = input.session_id or str(uuid.uuid4())

        try:
            return await self._ainvoke_with_tracing(
                input.user_message_str(), session_id
            )
        except Exception as e:
            logger.exception("Error invoking Agno agent")
            raise RuntimeError(f"Error invoking Agno agent: {e}") from e

    async def _ainvoke_with_tracing(
        self,
        user_message: str,
        session_id: str,
    ) -> InvokeOutput:
        """Execute ainvoke with tracing enabled."""
        with self.tracer.start_as_current_span("agno_invocation") as span:
            # Workaround: openinference-instrumentation-agno>=0.1.25 forces a new root
            # trace for Team instances unless _AGNO_PARENT_NODE_CONTEXT_KEY is set.
            # This ensures child spans inherit our trace_id.
            # See: https://github.com/Arize-ai/openinference/pull/2533
            #
            # Context API notes:
            # - set_value() creates a new Context with the key-value pair (doesn't activate it)
            # - attach() makes the context active and returns a token (restore point)
            # - detach(token) restores the previous context (cleanup)
            ctx = context_api.set_value(
                _AGNO_PARENT_NODE_CONTEXT_KEY,
                format(span.get_span_context().span_id, '016x')
            )
            token = context_api.attach(ctx)
            trace_id = span.get_span_context().trace_id

            logger.debug(
                "Starting traced invocation (session_id=%s) with trace_id=%s",
                session_id,
                trace_id,
            )
            try:
                await self.agent.arun(user_message, session_id=session_id)
            finally:
                context_api.detach(token)

        # Get trace spans
        trace_readable_spans = self.quraite_span_exporter.get_spans_by_trace_id(
            trace_id
        )

        if trace_readable_spans:
            logger.info(
                "Retrieved %d spans for trace_id=%s",
                len(trace_readable_spans),
                trace_id,
            )
            agent_trace = AgentTrace(
                spans=[
                    AgentSpan.from_readable_oi_span(span)
                    for span in trace_readable_spans
                ],
            )
        else:
            logger.warning("No spans found for trace_id=%s", trace_id)

        return InvokeOutput(
            agent_trace=agent_trace,
            agent_trajectory=agent_trace.to_agent_trajectory(framework=Framework.AGNO),
        )
