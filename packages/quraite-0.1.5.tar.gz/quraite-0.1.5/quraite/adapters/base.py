from abc import ABC, abstractmethod

from opentelemetry.sdk.trace import TracerProvider as SDKTracerProvider
from opentelemetry.trace import Tracer, TracerProvider

from quraite.logger import get_logger
from quraite.schema.invoke import InvokeInput, InvokeOutput
from quraite.schema.message import AssistantMessage, MessageContentText
from quraite.tracing.constants import QURAITE_TRACER_NAME
from quraite.tracing.span_exporter import QuraiteSpanExporter
from quraite.tracing.span_processor import QuraiteSpanProcessor

logger = get_logger(__name__)


class BaseAdapter(ABC):
    """Base adapter for all framework adapters."""

    tracer_provider: TracerProvider | None = None
    tracer: Tracer | None = None
    quraite_span_exporter: QuraiteSpanExporter = QuraiteSpanExporter()

    def _init_tracer(self, tracer_provider: SDKTracerProvider | None) -> None:
        """Initialize tracer components from TracerProvider."""
        if tracer_provider is None:
            return

        self.tracer_provider = tracer_provider
        self.tracer = tracer_provider.get_tracer(QURAITE_TRACER_NAME)

        # Find Quraite span exporter
        quraite_span_exporter = next(
            (
                processor.span_exporter
                for processor in tracer_provider._active_span_processor._span_processors
                if isinstance(processor, QuraiteSpanProcessor)
            ),
            None,
        )

        if quraite_span_exporter is None:
            raise ValueError(
                "Quraite span exporter not found. "
                "Use setup_tracing() to configure tracing properly."
            )

        self.quraite_span_exporter = quraite_span_exporter

    @abstractmethod
    async def ainvoke(
        self,
        input: InvokeInput,
    ) -> InvokeOutput:
        """Invoke agent with input and return response."""
        raise NotImplementedError("Not implemented")


class DummyAdapter(BaseAdapter):
    """Dummy adapter for testing."""

    async def ainvoke(
        self,
        input: InvokeInput,
    ) -> InvokeOutput:
        """Returns dummy response."""
        return InvokeOutput(
            agent_trajectory=[
                input.user_message,
                AssistantMessage(
                    content=[MessageContentText(text="Dummy response")],
                ),
            ]
        )
