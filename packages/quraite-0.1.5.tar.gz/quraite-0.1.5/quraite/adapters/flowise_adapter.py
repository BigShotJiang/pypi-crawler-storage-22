import asyncio
import json
from typing import Any

import aiohttp

from quraite.adapters.base import BaseAdapter
from quraite.logger import get_logger
from quraite.schema.invoke import InvokeInput, InvokeOutput
from quraite.schema.message import (
    AgentMessage,
    AssistantMessage,
    MessageContentText,
    ToolCall,
    ToolMessage,
)

logger = get_logger(__name__)


class FlowiseAdapter(BaseAdapter):
    def __init__(
        self, api_url: str, headers: dict[str, str] | None = None, timeout: int = 60
    ):
        self.api_url = api_url
        self.headers = headers or {}
        self.timeout = timeout

        if "Content-Type" not in self.headers:
            self.headers["Content-Type"] = "application/json"
        logger.info(
            "FlowiseAdapter initialized (api_url=%s, timeout=%s)", self.api_url, timeout
        )

    AGENT_NODE_NAME = "agentAgentflow"

    def _convert_api_output_to_messages(
        self,
        response: dict[str, Any],
        request_messages: list[AgentMessage] | None = None,
    ) -> list[AgentMessage]:
        logger.debug(
            "Converting Flowise response to messages (has_agent_node=%s)",
            bool(response.get("agentFlowExecutedData")),
        )

        def _append_text(content_obj: Any, bucket: list[MessageContentText]) -> None:
            if isinstance(content_obj, str):
                if content_obj:
                    bucket.append(MessageContentText(type="text", text=content_obj))
            elif isinstance(content_obj, list):
                for item in content_obj:
                    _append_text(item, bucket)
            elif isinstance(content_obj, dict):
                text_value = content_obj.get("text")
                if text_value:
                    bucket.append(MessageContentText(type="text", text=text_value))

        agent_node = self._find_agentflow_node(response)
        if agent_node:
            converted: list[AgentMessage] = []
            messages_section = agent_node.get("input")
            raw_messages = []
            if isinstance(messages_section, dict):
                potential_messages = messages_section.get("messages")
                if isinstance(potential_messages, list):
                    raw_messages = potential_messages

            latest_turn: list[dict[str, Any]] = []
            for raw in reversed(raw_messages):
                if not isinstance(raw, dict):
                    continue
                if raw.get("role") == "user":
                    break
                latest_turn.append(raw)
            latest_turn.reverse()

            for raw in latest_turn:
                role = raw.get("role")
                if role not in {"assistant", "system", "tool"}:
                    continue

                if role == "assistant":
                    text_content: list[MessageContentText] = []
                    _append_text(raw.get("content"), text_content)
                    tool_calls_list: list[ToolCall] = []
                    tool_calls = raw.get("tool_calls")
                    if isinstance(tool_calls, list):
                        for call in tool_calls:
                            if not isinstance(call, dict):
                                continue
                            arguments = call.get("args")
                            if not isinstance(arguments, dict):
                                arguments = {"value": arguments}
                            tool_calls_list.append(
                                ToolCall(
                                    id=call.get("id"),
                                    name=call.get("name"),
                                    arguments=arguments,
                                )
                            )

                    converted.append(
                        AssistantMessage(
                            content=text_content if text_content else None,
                            tool_calls=tool_calls_list if tool_calls_list else None,
                        )
                    )

                elif role == "tool":
                    payload = raw.get("content")
                    tool_result = (
                        payload if isinstance(payload, dict) else {"output": payload}
                    )
                    converted.append(
                        ToolMessage(
                            tool_name=raw.get("name"),
                            tool_call_id=raw.get("tool_call_id"),
                            content=[
                                MessageContentText(
                                    type="text", text=json.dumps(tool_result)
                                )
                            ],
                        )
                    )

            output_section = agent_node.get("output")
            if isinstance(output_section, dict):
                final_segments: list[MessageContentText] = []
                _append_text(output_section.get("content"), final_segments)

                if final_segments:
                    converted.append(AssistantMessage(content=final_segments))

            if converted:
                return converted

        if request_messages:
            logger.debug("Falling back to request messages; no agent output found")
            return list(request_messages)

        return []

    def _find_agentflow_node(
        self, response: dict[str, Any]
    ) -> dict[str, Any] | None:
        executed_data = response.get("agentFlowExecutedData")
        if not isinstance(executed_data, list):
            return None

        for entry in executed_data:
            node_data = entry.get("data")
            if not isinstance(node_data, dict):
                continue

            if node_data.get("name") == self.AGENT_NODE_NAME:
                return node_data

        return None

    async def _aapi_call(
        self,
        question: str,
        history: list[dict[str, Any]] | None = None,
        override_config: dict[str, Any] | None = None,
        form: dict[str, Any] | None = None,
        human_input: str | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        logger.debug(
            "Calling Flowise API (history=%s, form=%s, human_input=%s)",
            bool(history),
            bool(form),
            bool(human_input),
        )
        payload = {
            "question": question,
            "overrideConfig": override_config or {},
            **kwargs,
        }

        if history is not None:
            payload["history"] = history

        if form is not None:
            payload["form"] = form

        if human_input is not None:
            payload["humanInput"] = human_input

        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(
                    self.api_url,
                    headers=self.headers,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=self.timeout),
                ) as response:
                    response.raise_for_status()
                    logger.info(
                        "Flowise API call succeeded (status=%s)", response.status
                    )
                    return await response.json()

            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                logger.exception("Flowise API request failed")
                raise aiohttp.ClientError(f"Async API request failed: {str(e)}") from e

            except json.JSONDecodeError as e:
                logger.exception("Flowise API response decoding failed")
                raise ValueError(f"Failed to decode JSON response: {e}") from e

    async def ainvoke(self, input: InvokeInput) -> InvokeOutput:
        """Invoke Flowise agent and return response."""
        logger.info("Flowise ainvoke called (session_id=%s)", input.session_id)

        try:
            agent_output = await self._aapi_call(
                question=input.user_message_str(),
                override_config=(
                    {"sessionId": input.session_id} if input.session_id else None
                ),
            )
            agent_trajectory = self._convert_api_output_to_messages(
                agent_output, [input.user_message]
            )
            logger.info(
                "Flowise conversion produced %d trajectory messages",
                len(agent_trajectory),
            )
            return InvokeOutput(agent_trajectory=agent_trajectory)
        except Exception as e:
            logger.exception("Error calling Flowise endpoint")
            raise RuntimeError(f"Error calling Flowise endpoint: {e}") from e
