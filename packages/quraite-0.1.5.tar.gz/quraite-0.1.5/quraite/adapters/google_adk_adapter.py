import uuid

from google.adk.agents import Agent
from google.adk.apps.app import App
from google.adk.errors.already_exists_error import AlreadyExistsError
from google.adk.runners import Runner
from google.adk.sessions import BaseSessionService, InMemorySessionService
from google.genai import types
from opentelemetry.trace import TracerProvider

from quraite.adapters.base import BaseAdapter
from quraite.constants.framework import Framework
from quraite.logger import get_logger
from quraite.schema.invoke import InvokeInput, InvokeOutput
from quraite.tracing.trace import AgentSpan, AgentTrace

logger = get_logger(__name__)


class GoogleADKAdapter(BaseAdapter):
    """Google ADK adapter for Agent (requires tracing)."""

    def __init__(
        self,
        agent: Agent,
        *,
        tracer_provider: TracerProvider | None = None,
        agent_name: str = "Google ADK Agent",
        app_name: str = "google_adk_agent",
        user_id: str = str(uuid.uuid4()),
        session_service: BaseSessionService = InMemorySessionService(),
    ):
        """
        Initialize Google ADK adapter.

        Args:
            agent: Google ADK Agent instance
            tracer_provider: TracerProvider from setup_tracing() (required)
            agent_name: Agent name for metadata
            app_name: Application name for ADK runner
            user_id: User ID for session management
            session_service: Session service for multi-turn conversations
        """
        if tracer_provider is None:
            raise ValueError(
                "Google ADK adapter requires tracing. Use setup_tracing([Framework.GOOGLE_ADK]) first."
            )

        self.agent: Agent = agent
        self.app_name = app_name
        self.agent_name = agent_name
        self.session_service = session_service
        self.user_id = user_id
        self.app = App(name=app_name, root_agent=agent)
        self.runner = Runner(app=self.app, session_service=session_service)
        self._init_tracer(tracer_provider)
        logger.info("GoogleADKAdapter initialized")

    async def ainvoke(self, input: InvokeInput) -> InvokeOutput:
        """Invoke Google ADK agent and return response with trace."""
        logger.info("Google ADK ainvoke called (session_id=%s)", input.session_id)
        session_id = input.session_id or str(uuid.uuid4())

        try:
            return await self._ainvoke_with_tracing(
                input.user_message_str(), session_id
            )
        except Exception as e:
            logger.exception("Error invoking Google ADK agent")
            raise RuntimeError(f"Error invoking Google ADK agent: {e}") from e

    async def _ainvoke_with_tracing(
        self,
        agent_input: str,
        session_id: str,
    ) -> InvokeOutput:
        """Execute ainvoke with tracing enabled."""
        logger.debug(
            "Starting Google ADK traced invocation (session_id=%s)",
            session_id,
        )

        with self.tracer.start_as_current_span("google_adk_invocation") as span:
            trace_id = span.get_span_context().trace_id
            logger.debug(
                "Starting Google ADK traced invocation (trace_id=%s, session_id=%s)",
                trace_id,
                session_id,
            )
            # Create session if it doesn't exist
            try:
                await self.session_service.create_session(
                    app_name=self.app_name,
                    user_id=self.user_id,
                    session_id=session_id,
                )
            except AlreadyExistsError:
                logger.info("Session already exists: %s", session_id)
            except Exception as e:
                logger.exception("Error creating Google ADK session")
                raise RuntimeError(f"Error creating session: {e}") from e

            # Create content for ADK
            content = types.Content(
                role="user",
                parts=[types.Part(text=agent_input)],
            )

            # Run async and consume events
            events = self.runner.run_async(
                new_message=content,
                user_id=self.user_id,
                session_id=session_id,
            )

            # Consume all events (tracing captures everything)
            async for event in events:
                pass  # Just consume events, tracing handles capture

        # Get trace spans
        trace_readable_spans = self.quraite_span_exporter.get_spans_by_trace_id(
            trace_id
        )

        if trace_readable_spans:
            agent_trace = AgentTrace(
                spans=[
                    AgentSpan.from_readable_oi_span(span)
                    for span in trace_readable_spans
                ],
            )
            logger.info(
                "Google ADK trace collected %d spans for trace_id=%s",
                len(trace_readable_spans),
                trace_id,
            )
        else:
            logger.warning("No spans exported for Google ADK trace_id=%s", trace_id)

        return InvokeOutput(
            agent_trace=agent_trace,
            agent_trajectory=agent_trace.to_agent_trajectory(
                framework=Framework.GOOGLE_ADK
            ),
        )
