import json

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.runnables import RunnableConfig
from langgraph.graph.state import CompiledStateGraph
from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace import TracerProvider as SDKTracerProvider

from quraite.adapters.base import BaseAdapter
from quraite.constants.framework import Framework
from quraite.logger import get_logger
from quraite.schema.invoke import InvokeInput, InvokeOutput
from quraite.schema.message import (
    AgentMessage,
    AssistantMessage,
    MessageContentText,
    ToolCall,
    UserMessage,
)
from quraite.schema.message import SystemMessage as QuraiteSystemMessage
from quraite.schema.message import ToolMessage as QuraiteToolMessage
from quraite.tracing.trace import AgentSpan, AgentTrace

LangchainMessage = HumanMessage | SystemMessage | AIMessage | ToolMessage

logger = get_logger(__name__)


class LangchainAdapter(BaseAdapter):
    """LangChain adapter for CompiledStateGraph agents."""

    def __init__(
        self,
        agent_graph: CompiledStateGraph,
        *,
        tracer_provider: SDKTracerProvider | None = None,
        agent_name: str = "LangChain Agent",
    ):
        """
        Initialize LangChain adapter.

        Args:
            agent_graph: LangChain CompiledStateGraph
            tracer_provider: Optional TracerProvider from setup_tracing()
            agent_name: Agent name for metadata
        """
        self.agent_graph = agent_graph
        self.agent_name = agent_name
        self._init_tracer(tracer_provider)
        logger.info("LangchainAdapter initialized (tracing=%s)", bool(tracer_provider))

    def _convert_langchain_messages_to_quraite_messages(
        self,
        messages: list[LangchainMessage],
    ) -> list[AgentMessage]:
        """Convert LangChain messages to Quraite format."""
        logger.debug(
            "Converting %d langchain messages to quraite format", len(messages)
        )
        converted_messages: list[AgentMessage] = []

        for idx, msg in enumerate(messages):
            match msg:
                case SystemMessage():
                    logger.debug("Converting SystemMessage at index %d", idx)
                    converted_messages.append(
                        QuraiteSystemMessage(
                            content=[MessageContentText(type="text", text=msg.content or "")]
                        )
                    )

                case HumanMessage():
                    logger.debug("Converting HumanMessage at index %d", idx)
                    converted_messages.append(
                        UserMessage(
                            content=[MessageContentText(type="text", text=msg.content or "")]
                        )
                    )

                case AIMessage():
                    logger.debug(
                        "Converting AIMessage at index %d (has_tool_calls=%s)",
                        idx,
                        bool(msg.tool_calls),
                    )
                    text_content, tool_calls = self._extract_ai_message_content(msg)
                    converted_messages.append(
                        AssistantMessage(
                            content=text_content,
                            tool_calls=tool_calls,
                        )
                    )

                case ToolMessage():
                    logger.debug(
                        "Converting ToolMessage at index %d (tool_call_id=%s)",
                        idx,
                        msg.tool_call_id,
                    )
                    if not msg.content:
                        tool_message_content = ""
                    elif isinstance(msg.content, str):
                        tool_message_content = msg.content
                    else:
                        tool_message_content = json.dumps(msg.content)

                    converted_messages.append(
                        QuraiteToolMessage(
                            tool_call_id=msg.tool_call_id,
                            content=[
                                MessageContentText(
                                    type="text", text=tool_message_content
                                )
                            ],
                        )
                    )

        logger.info("Converted %d messages successfully", len(converted_messages))
        return converted_messages

    def _extract_ai_message_content(
        self, msg: AIMessage
    ) -> tuple[list[MessageContentText], list[ToolCall]]:
        """Extract text and tool calls from AIMessage."""
        text_content = []

        if msg.content:
            match msg.content:
                case str(text):
                    text_content.append(MessageContentText(type="text", text=text))
                case list():
                    text_content.extend(
                        MessageContentText(type="text", text=content.get("text", ""))
                        for content in msg.content
                        if isinstance(content, dict) and content.get("type") == "text"
                    )

        tool_calls = []
        if msg.tool_calls:
            logger.debug("Extracting %d tool calls from AIMessage", len(msg.tool_calls))
            tool_calls.extend(
                ToolCall(
                    id=tool_call.get("id", ""),     
                    name=tool_call.get("name", ""),
                    arguments=tool_call.get("args", {}),  
                )
                for tool_call in msg.tool_calls
            )

        return text_content, tool_calls

    async def ainvoke(self, input: InvokeInput) -> InvokeOutput:
        """Invoke LangChain agent and return response."""
        logger.info("ainvoke called (session_id=%s)", input.session_id)

        agent_input = {"messages": [HumanMessage(content=input.user_message_str())]}
        config: RunnableConfig = (
            {"configurable": {"thread_id": input.session_id}}
            if input.session_id
            else {}
        )

        if self.tracer_provider:
            return await self._ainvoke_with_tracing(agent_input, config)
        return await self._ainvoke_without_tracing(agent_input, config)

    async def _ainvoke_with_tracing(
        self,
        agent_input: dict[str, list[HumanMessage]],
        config: RunnableConfig,
    ) -> InvokeOutput:
        """Execute ainvoke with tracing enabled."""
        with self.tracer.start_as_current_span("langchain_invocation") as span:
            trace_id = span.get_span_context().trace_id
            logger.debug(
                "Starting LangChain traced invocation (trace_id=%s)",
                trace_id,
            )
            _ = await self.agent_graph.ainvoke(agent_input, config=config)

        trace_readable_spans: list[ReadableSpan] = self.quraite_span_exporter.get_spans_by_trace_id(
            trace_id
        )

        if trace_readable_spans:
            logger.info("Retrieved %d spans from trace", len(trace_readable_spans))
            agent_trace = AgentTrace(
                spans=[
                    AgentSpan.from_readable_oi_span(span)
                    for span in trace_readable_spans
                ]
            )

            trajectory = agent_trace.to_agent_trajectory(framework=Framework.LANGCHAIN)
            logger.debug("Generated trajectory with %d messages", len(trajectory))

            return InvokeOutput(
                agent_trace=agent_trace,
                agent_trajectory=trajectory,
            )

        logger.warning("No trace spans found for trace_id=%s", trace_id)
        return InvokeOutput()

    async def _ainvoke_without_tracing(
        self,
        agent_input: dict[str, list[HumanMessage]],
        config: RunnableConfig,
    ) -> InvokeOutput:
        """Execute ainvoke without tracing."""
        logger.debug("Starting non-traced invocation")
        agent_messages = []

        try:
            async for event in self.agent_graph.astream(agent_input, config=config):
                logger.debug(
                    "Received stream event with %d values", len(event.values())
                )
                for result in event.values():
                    if messages := result.get("messages"):
                        logger.debug("Processing %d messages from event", len(messages))
                        agent_messages.extend(messages)

            logger.info(
                "Streaming complete, received %d total messages", len(agent_messages)
            )

            agent_trajectory = self._convert_langchain_messages_to_quraite_messages(
                agent_messages
            )

            return InvokeOutput(
                agent_trajectory=agent_trajectory,
            )

        except ValueError:
            logger.exception("Error converting messages to List[AgentMessage]")
            return InvokeOutput()
