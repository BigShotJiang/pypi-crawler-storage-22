from __future__ import annotations

from langchain_core.messages import HumanMessage, ToolMessage
from langgraph.pregel.remote import RemoteGraph
from langgraph_sdk import get_client, get_sync_client

from quraite.adapters.base import BaseAdapter
from quraite.logger import get_logger
from quraite.schema.invoke import InvokeInput, InvokeOutput
from quraite.schema.message import (
    AgentMessage,
    AssistantMessage,
    MessageContentText,
    ToolCall,
    ToolMessage,
    UserMessage,
)
from quraite.schema.message import SystemMessage as QuraiteSystemMessage

logger = get_logger(__name__)


class LangchainServerAdapter(BaseAdapter):
    """Remote LangChain server adapter based on langgraph-sdk.

    Args:
        base_url: The base URL of the LangChain server
        assistant_id: The ID of the assistant to invoke
        **kwargs: Additional keyword arguments passed directly to
                 langgraph_sdk.get_client() and get_sync_client().
                 Common options include:
                 - api_key: API key for authentication
                 - headers: Additional HTTP headers
                 - timeout: Request timeout configuration
    """

    def __init__(
        self,
        *,
        base_url: str,
        assistant_id: str | None = None,
        graph_name: str | None = None,
        **kwargs,
    ) -> None:
        self.base_url = base_url
        self.assistant_id = assistant_id
        self.graph_name = graph_name

        logger.debug(
            "Initializing LangchainServerAdapter (base_url=%s, assistant_id=%s, graph_name=%s)",
            base_url,
            assistant_id,
            graph_name,
        )
        try:
            sync_client = get_sync_client(url=self.base_url, **kwargs)
            async_client = get_client(url=self.base_url, **kwargs)
            if self.assistant_id:
                self.remote_graph = RemoteGraph(
                    self.assistant_id,
                    url=self.base_url,
                    sync_client=sync_client,
                    client=async_client,
                )
            else:
                self.remote_graph = RemoteGraph(
                    self.graph_name,
                    url=self.base_url,
                    sync_client=sync_client,
                    client=async_client,
                )
        except Exception as exc:
            raise RuntimeError(
                f"Failed to initialize LangChain RemoteGraph for {self.base_url}: {exc}"
            )
        logger.info(
            "LangchainServerAdapter initialized (assistant_id=%s, graph_name=%s)",
            self.assistant_id,
            self.graph_name,
        )

    def _convert_langchain_messages_to_quraite_messages(
        self,
        messages: list[dict],
    ) -> list[AgentMessage]:
        logger.debug(
            "Converting %d Langchain server messages to quraite format", len(messages)
        )
        converted_messages: list[AgentMessage] = []

        for msg in messages:
            if msg.get("type") == "system":
                converted_messages.append(
                    QuraiteSystemMessage(
                        content=[
                            MessageContentText(type="text", text=msg.get("content", ""))
                        ],
                    )
                )

            elif msg.get("type") == "human":
                converted_messages.append(
                    UserMessage(
                        content=[
                            MessageContentText(type="text", text=msg.get("content", ""))
                        ],
                    )
                )

            elif msg.get("type") == "ai":
                text_content: list[MessageContentText] = []
                tool_calls_list: list[ToolCall] = []

                # Extract text content - sometimes it's a string, sometimes a list of dicts
                content = msg.get("content")
                if isinstance(content, str) and content:
                    text_content.append(MessageContentText(type="text", text=content))
                elif isinstance(content, list):
                    for content_item in content:
                        if isinstance(content_item, dict):
                            if content_item.get("type") == "text" and content_item.get(
                                "text"
                            ):
                                text_content.append(
                                    MessageContentText(
                                        type="text", text=content_item.get("text")
                                    )
                                )

                # Extract tool calls if present
                if msg.get("tool_calls"):
                    for tool_call in msg.get("tool_calls"):
                        if isinstance(tool_call, dict):
                            tool_calls_list.append(
                                ToolCall(
                                    id=tool_call.get("id", ""),
                                    name=tool_call.get("name", ""),
                                    arguments=tool_call.get("args", {}),
                                )
                            )

                converted_messages.append(
                    AssistantMessage(
                        content=text_content if text_content else None,
                        tool_calls=tool_calls_list if tool_calls_list else None,
                    )
                )

            elif msg.get("type") == "tool":
                tool_content = msg.get("content", "") or ""
                converted_messages.append(
                    ToolMessage(
                        tool_call_id=msg.get("tool_call_id", ""),
                        content=[
                            MessageContentText(type="text", text=str(tool_content or ""))
                        ],
                    )
                )

            else:
                # Skip unsupported message types
                continue

        logger.info(
            "Langchain server message conversion produced %d messages",
            len(converted_messages),
        )
        return converted_messages

    async def ainvoke(self, input: InvokeInput) -> InvokeOutput:
        """Invoke LangChain server agent and return response."""
        logger.info("Langchain server ainvoke called (session_id=%s)", input.session_id)

        agent_input = {
            "messages": [HumanMessage(content=input.user_message_str()).model_dump()]
        }
        config = (
            {"configurable": {"thread_id": input.session_id}}
            if input.session_id
            else {}
        )

        try:
            agent_messages = []
            async for event in self.remote_graph.astream(agent_input, config=config):
                for _, result in event.items():
                    if result.get("messages"):
                        agent_messages += result.get("messages")

            agent_trajectory = self._convert_langchain_messages_to_quraite_messages(
                agent_messages
            )
            logger.info(
                "Langchain server produced %d trajectory messages",
                len(agent_trajectory),
            )
            return InvokeOutput(agent_trajectory=agent_trajectory)
        except Exception as e:
            logger.exception("Error invoking Langchain remote graph")
            raise RuntimeError(f"Error invoking LangChain agent: {e}") from e
