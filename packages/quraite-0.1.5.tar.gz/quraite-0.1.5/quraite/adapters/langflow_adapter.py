import asyncio
import json
import uuid
from typing import Any

import aiohttp

from quraite.adapters.base import BaseAdapter
from quraite.logger import get_logger
from quraite.schema.invoke import InvokeInput, InvokeOutput
from quraite.schema.message import (
    AgentMessage,
    AssistantMessage,
    MessageContentText,
    ToolCall,
    ToolMessage,
)

logger = get_logger(__name__)


class LangflowAdapter(BaseAdapter):
    def __init__(self, api_url: str, x_api_key: str, timeout: int = 60):
        self.api_url = api_url
        self.x_api_key = x_api_key
        self.headers = {"Content-Type": "application/json", "x-api-key": self.x_api_key}
        self.timeout = timeout
        logger.info(
            "LangflowAdapter initialized (api_url=%s, timeout=%s)",
            self.api_url,
            timeout,
        )

    def _convert_api_output_to_messages(
        self,
        response: dict[str, Any],
    ) -> list[AgentMessage]:
        logger.debug(
            "Converting Langflow response (root_keys=%s)",
            list(response.keys()),
        )
        content_blocks = response["outputs"][0]["outputs"][0]["results"]["message"][
            "content_blocks"
        ]
        contents = content_blocks[0]["contents"]

        # Assume everything sequential.
        ai_trajectory: list[AgentMessage] = []
        for step in contents:
            if step["type"] == "text":
                if step["header"]["title"] == "Input":
                    continue
                else:
                    ai_trajectory.append(
                        AssistantMessage(
                            content=[
                                MessageContentText(type="text", text=step["text"])
                            ],
                        )
                    )
            elif step["type"] == "tool_use":
                tool_id = str(uuid.uuid4())
                tool_input = step.get("tool_input", {})
                if not isinstance(tool_input, dict):
                    tool_input = {"value": tool_input}

                # Create AssistantMessage with tool call
                ai_trajectory.append(
                    AssistantMessage(
                        tool_calls=[
                            ToolCall(
                                id=tool_id,
                                name=step["name"],
                                arguments=tool_input,
                            )
                        ],
                    )
                )
                # Create ToolMessage with tool result
                tool_output = step.get("output", "")
                ai_trajectory.append(
                    ToolMessage(
                        tool_name=step["name"],
                        tool_call_id=tool_id,
                        content=[
                            MessageContentText(type="text", text=str(tool_output))
                        ],
                    )
                )

        logger.info(
            "Converted Langflow response into %d trajectory messages",
            len(ai_trajectory),
        )
        return ai_trajectory

    async def _aapi_call(
        self,
        query: str,
        sessionId: str,
    ) -> dict[str, Any]:
        payload = {
            "output_type": "chat",
            "input_type": "chat",
            "input_value": query,
            "session_id": sessionId,
        }

        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(
                    self.api_url,
                    headers=self.headers,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=self.timeout),
                ) as response:
                    response.raise_for_status()
                    logger.info(
                        "Langflow API call succeeded (status=%s)", response.status
                    )
                    return await response.json()

            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                logger.exception("Langflow API request failed")
                raise aiohttp.ClientError(f"Async API request failed: {str(e)}") from e

            except json.JSONDecodeError as e:
                logger.exception("Langflow API response decoding failed")
                raise ValueError(f"Failed to decode JSON response: {e}") from e

    async def ainvoke(self, input: InvokeInput) -> InvokeOutput:
        """Invoke Langflow agent and return response."""
        logger.info("Langflow ainvoke called (session_id=%s)", input.session_id)

        try:
            agent_output = await self._aapi_call(
                query=input.user_message_str(),
                sessionId=input.session_id if input.session_id else str(uuid.uuid4()),
            )
            agent_trajectory = self._convert_api_output_to_messages(agent_output)
            logger.info(
                "Langflow produced %d trajectory messages", len(agent_trajectory)
            )
            return InvokeOutput(agent_trajectory=agent_trajectory)
        except Exception as e:
            logger.exception("Error calling Langflow endpoint")
            raise RuntimeError(f"Error calling Langflow endpoint: {e}") from e
