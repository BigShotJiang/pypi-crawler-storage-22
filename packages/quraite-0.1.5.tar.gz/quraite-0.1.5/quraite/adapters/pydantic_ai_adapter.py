from typing import Any

from opentelemetry.trace import TracerProvider
from pydantic_ai import Agent
from pydantic_ai.messages import (
    BuiltinToolCallPart,
    SystemPromptPart,
    TextPart,
    ToolCallPart,
    ToolReturnPart,
    UserPromptPart,
)

from quraite.adapters.base import BaseAdapter
from quraite.constants.framework import Framework
from quraite.logger import get_logger
from quraite.schema.invoke import InvokeInput, InvokeOutput
from quraite.schema.message import (
    AgentMessage,
    AssistantMessage,
    MessageContentText,
    ToolCall,
    ToolMessage,
)
from quraite.tracing.trace import AgentSpan, AgentTrace

logger = get_logger(__name__)


class PydanticAIAdapter(BaseAdapter):
    """Pydantic AI adapter for Agent."""

    def __init__(
        self,
        agent: Agent,
        *,
        tracer_provider: TracerProvider | None = None,
        agent_name: str = "Pydantic AI Agent",
    ):
        """
        Initialize Pydantic AI adapter.

        Args:
            agent: Pydantic AI Agent instance
            tracer_provider: Optional TracerProvider from setup_tracing()
            agent_name: Agent name for metadata
        """
        self.agent = agent
        self.agent_name = agent_name
        self._sessions: dict[str, Any] = {}
        self._init_tracer(tracer_provider)
        logger.info("PydanticAIAdapter initialized (tracing=%s)", bool(tracer_provider))

    def _convert_pydantic_ai_messages_to_messages(
        self, messages: list[Any]
    ) -> list[AgentMessage]:
        """Convert Pydantic AI messages to Quraite format."""
        converted_messages: list[AgentMessage] = []

        for msg in messages:
            if not hasattr(msg, "parts"):
                continue

            content: list[MessageContentText] = []
            tool_calls_list: list[ToolCall] = []

            for part in msg.parts:
                if isinstance(part, SystemPromptPart) or isinstance(
                    part, UserPromptPart
                ):
                    continue

                elif isinstance(part, TextPart):
                    if part.content:
                        content.append(
                            MessageContentText(type="text", text=part.content)
                        )
                elif isinstance(part, ToolCallPart) or isinstance(
                    part, BuiltinToolCallPart
                ):
                    tool_call_id = part.tool_call_id
                    tool_name = part.tool_name
                    args = part.args

                    tool_calls_list.append(
                        ToolCall(
                            id=tool_call_id,
                            name=tool_name,
                            arguments=args if isinstance(args, dict) else {},
                        )
                    )

                elif isinstance(part, ToolReturnPart):
                    if content or tool_calls_list:
                        converted_messages.append(
                            AssistantMessage(
                                content=content if content else None,
                                tool_calls=tool_calls_list if tool_calls_list else None,
                            )
                        )
                        content = []
                        tool_calls_list = []

                    tool_call_id = part.tool_call_id

                    converted_messages.append(
                        ToolMessage(
                            tool_name=part.tool_name,
                            tool_call_id=tool_call_id,
                            content=[
                                MessageContentText(type="text", text=str(part.content))
                            ],
                        )
                    )

            if content or tool_calls_list:
                converted_messages.append(
                    AssistantMessage(
                        content=content if content else None,
                        tool_calls=tool_calls_list if tool_calls_list else None,
                    )
                )

        logger.info(
            "Converted %d Pydantic AI messages to agent messages",
            len(converted_messages),
        )
        return converted_messages

    async def ainvoke(self, input: InvokeInput) -> InvokeOutput:
        """Invoke Pydantic AI agent and return response."""
        logger.info("Pydantic AI ainvoke called (session_id=%s)", input.session_id)
        agent_input = input.user_message_str()
        session_id = input.session_id or "default"

        try:
            # Get message history for this session (for multi-turn conversations)
            message_history = self._sessions.get(session_id, None)

            # Run with or without tracing depending on configuration
            if self.tracer_provider:
                return await self._ainvoke_with_tracing(
                    agent_input, session_id, message_history
                )

            return await self._ainvoke_without_tracing(
                agent_input, session_id, message_history
            )

        except Exception as e:
            logger.exception("Error invoking Pydantic AI agent")
            raise RuntimeError(f"Error invoking Pydantic AI agent: {e}") from e

    async def _ainvoke_with_tracing(
        self,
        agent_input: str,
        session_id: str,
        message_history: Any | None,
    ) -> InvokeOutput:
        """Execute ainvoke with tracing enabled."""
        with self.tracer.start_as_current_span("pydantic_invocation") as span:
            trace_id = span.get_span_context().trace_id
            logger.debug(
                "Starting Pydantic AI traced invocation (trace_id=%s session_id=%s)",
                trace_id,
                session_id,
            )
            # Run the agent asynchronously with message history for context
            if message_history:
                result = await self.agent.run(
                    agent_input,
                    message_history=message_history,
                )
            else:
                result = await self.agent.run(agent_input)

        # Store the complete updated message history for this session
        self._sessions[session_id] = result.all_messages()

        trace_readable_spans = self.quraite_span_exporter.get_spans_by_trace_id(
            trace_id
        )

        if trace_readable_spans:
            agent_trace = AgentTrace(
                spans=[
                    AgentSpan.from_readable_oi_span(span)
                    for span in trace_readable_spans
                ]
            )
            logger.info(
                "Pydantic AI trace collected %d spans for trace_id=%s",
                len(trace_readable_spans),
                trace_id,
            )
        else:
            logger.warning("No spans exported for Pydantic AI trace_id=%s", trace_id)

        return InvokeOutput(
            agent_trace=agent_trace,
            agent_trajectory=agent_trace.to_agent_trajectory(
                framework=Framework.PYDANTIC_AI
            ),
        )

    async def _ainvoke_without_tracing(
        self,
        agent_input: str,
        session_id: str,
        message_history: Any | None,
    ) -> InvokeOutput:
        """Execute ainvoke without tracing."""
        # Run the agent asynchronously with message history for context
        if message_history:
            result = await self.agent.run(
                agent_input,
                message_history=message_history,
            )
        else:
            result = await self.agent.run(agent_input)

        # Store the complete updated message history for this session
        self._sessions[session_id] = result.all_messages()

        # Convert only the NEW messages to SDK Message format
        agent_trajectory = self._convert_pydantic_ai_messages_to_messages(
            result.new_messages()
        )

        logger.info(
            "Pydantic AI produced %d trajectory messages without tracing",
            len(agent_trajectory),
        )

        return InvokeOutput(
            agent_trajectory=agent_trajectory,
        )
