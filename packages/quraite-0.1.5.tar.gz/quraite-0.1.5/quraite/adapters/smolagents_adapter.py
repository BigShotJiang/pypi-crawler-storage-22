import asyncio

from opentelemetry.trace import TracerProvider
from smolagents import CodeAgent

from quraite.adapters.base import BaseAdapter
from quraite.constants.framework import Framework
from quraite.logger import get_logger
from quraite.schema.invoke import InvokeInput, InvokeOutput
from quraite.tracing.trace import AgentSpan, AgentTrace

logger = get_logger(__name__)


class SmolagentsAdapter(BaseAdapter):
    """Smolagents adapter for CodeAgent (requires tracing)."""

    def __init__(
        self,
        agent: CodeAgent,
        *,
        tracer_provider: TracerProvider | None = None,
        agent_name: str = "Smolagents Agent",
    ):
        """
        Initialize Smolagents adapter.

        Args:
            agent: Smolagents CodeAgent instance
            tracer_provider: TracerProvider from setup_tracing() (required)
            agent_name: Agent name for metadata
        """
        if tracer_provider is None:
            raise ValueError(
                "Smolagents adapter requires tracing. Use setup_tracing([Framework.SMOLAGENTS]) first."
            )

        self.agent = agent
        self.agent_name = agent_name
        self._init_tracer(tracer_provider)
        logger.info("SmolagentsAdapter initialized")

    async def ainvoke(self, input: InvokeInput) -> InvokeOutput:
        """Invoke Smolagents agent and return response with trace."""
        logger.info("Smolagents ainvoke called (session_id=%s)", input.session_id)

        try:
            return await self._ainvoke_with_tracing(input.user_message_str())
        except Exception as exc:
            logger.exception("Error invoking Smolagents agent")
            raise RuntimeError(f"Error invoking Smolagents agent: {exc}") from exc

    async def _ainvoke_with_tracing(self, agent_input: str) -> InvokeOutput:
        """Execute ainvoke with tracing enabled."""
        with self.tracer.start_as_current_span("smolagents_invocation") as span:
            trace_id = span.get_span_context().trace_id
            logger.debug(
                "Starting Smolagents traced invocation (trace_id=%s)", trace_id
            )
            # Run the agent synchronously inside a thread to avoid blocking
            await asyncio.to_thread(self.agent.run, agent_input)

        trace_readable_spans = self.quraite_span_exporter.get_spans_by_trace_id(
            trace_id
        )

        if trace_readable_spans:
            logger.info(
                "Smolagents trace collected %d spans for trace_id=%s",
                len(trace_readable_spans),
                trace_id,
            )
            agent_trace = AgentTrace(
                spans=[
                    AgentSpan.from_readable_oi_span(span)
                    for span in trace_readable_spans
                ],
            )
        else:
            logger.warning("No spans captured for Smolagents trace_id=%s", trace_id)

        return InvokeOutput(
            agent_trace=agent_trace,
            agent_trajectory=agent_trace.to_agent_trajectory(
                framework=Framework.SMOLAGENTS
            ),
        )
