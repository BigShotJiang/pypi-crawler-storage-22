"""Request and response models for agent invocation endpoints."""


from collections.abc import Sequence

from pydantic import BaseModel

from quraite.schema.message import AgentMessage, UserMessage
from quraite.tracing.trace import AgentTrace


class InvokeInput(BaseModel):
    """
    Request model for agent invocation endpoints.

    Attributes:
        user_message: UserMessage object
        session_id: Optional conversation thread identifier
    """

    user_message: UserMessage
    session_id: str | None = None

    def user_message_str(self) -> str:
        """Extract text content from user message."""
        if not self.user_message.content:
            raise ValueError("User message has no content")

        for content_item in self.user_message.content:
            if content_item.type == "text" and content_item.text:
                return content_item.text

        raise ValueError("No text content found in user message")


class InvokeOutput(BaseModel):
    """
    Output model for agent invocation endpoints.

    Attributes:
        agent_trace: AgentTrace object representing agent trace
        agent_trajectory: List of AgentMessage objects representing agent trajectory
    """

    agent_trace: AgentTrace | None = None
    agent_trajectory: Sequence[AgentMessage] | None = None
