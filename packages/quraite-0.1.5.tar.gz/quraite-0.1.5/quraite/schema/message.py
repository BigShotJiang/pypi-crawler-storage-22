from collections.abc import Sequence
from typing import Any, Literal, TypeAlias

from pydantic import BaseModel, Field


class MessageContentText(BaseModel):
    type: Literal["text"] = "text"
    text: str


class MessageContentReasoning(BaseModel):
    type: Literal["reasoning"] = "reasoning"
    reasoning: str


class UserMessage(BaseModel):
    role: Literal["user"] = "user"
    name: str | None = None
    content: list[MessageContentText]


class DeveloperMessage(BaseModel):
    role: Literal["developer"] = "developer"
    content: list[MessageContentText]


class SystemMessage(BaseModel):
    role: Literal["system"] = "system"
    content: list[MessageContentText]


class ToolCall(BaseModel):
    id: str
    name: str
    arguments: dict[str, Any]


class ModelInfo(BaseModel):
    model_name: str = Field(default="")
    model_provider: str = Field(default="")


class CostInfo(BaseModel):
    input_cost: float = Field(default=0.0)
    output_cost: float = Field(default=0.0)


class TokenInfo(BaseModel):
    input_tokens: int = Field(default=0)
    output_tokens: int = Field(default=0)


class LatencyInfo(BaseModel):
    start_time: float = Field(default=0.0)
    end_time: float = Field(default=0.0)


class AssistantMessageMetadata(BaseModel):
    """Structured metadata for assistant messages."""

    tokens: TokenInfo | None = None
    cost: CostInfo | None = None
    latency: LatencyInfo | None = None
    model_info: ModelInfo | None = None


class ToolMessageMetadata(BaseModel):
    """Structured metadata for tool messages."""

    latency: LatencyInfo | None = None


class AssistantMessage(BaseModel):
    role: Literal["assistant"] = "assistant"
    agent_name: str | None = None
    content: Sequence[MessageContentText | MessageContentReasoning] | None = None
    tool_calls: list[ToolCall] | None = None
    metadata: AssistantMessageMetadata | None = None


class ToolMessage(BaseModel):
    role: Literal["tool"] = "tool"
    tool_name: str | None = None
    tool_call_id: str | None = None
    content: list[MessageContentText]
    metadata: ToolMessageMetadata | None = None


AgentMessage: TypeAlias = UserMessage | DeveloperMessage | SystemMessage | AssistantMessage | ToolMessage
