"""Simplified agent runner API for Quraite."""

import asyncio
import os
from typing import Any, Literal

import httpx
import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from quraite.adapters.base import BaseAdapter
from quraite.logger import get_logger
from quraite.schema import InvokeInput, InvokeOutput

logger = get_logger(__name__)


class TunnelConfig(BaseModel):
    tunnel_obj: Any
    agent_url: str
    tunnel_type: Literal["ngrok", "cloudflare", "none"]


def setup_tunnel(
    port: int,
    host: str = "0.0.0.0",
    tunnel: Literal["ngrok", "cloudflare"] = "cloudflare",
) -> TunnelConfig:
    """
    Setup tunnel connection.

    Args:
        port: Local port to expose
        host: Local host address
        tunnel: Tunnel type

    Returns:
        Tuple of (public_url, tunnel_object)
    """
    if tunnel == "ngrok":
        try:
            from pyngrok import ngrok
        except ImportError as e:
            raise ImportError(
                "Failed to import pyngrok. Install with: pip install 'quraite[pyngrok]'"
            ) from e

        try:
            ngrok_tunnel = ngrok.connect(port)
            public_url = ngrok_tunnel.public_url
            logger.info("Ngrok tunnel established: %s", public_url)
            return TunnelConfig(
                tunnel_obj=ngrok_tunnel, agent_url=public_url, tunnel_type="ngrok"
            )
        except Exception as e:
            logger.error(
                "Failed to create ngrok tunnel: %s. "
                "Make sure ngrok is installed and authenticated: https://ngrok.com/download",
                e,
            )
            raise

    elif tunnel == "cloudflare":
        from quraite.serve.cloudflared import connect

        cloudflared_tunnel = connect(
            port, host=host if host != "0.0.0.0" else "localhost"
        )
        public_url = cloudflared_tunnel.public_url
        logger.info("Cloudflare tunnel established: %s", public_url)
        return TunnelConfig(
            tunnel_obj=cloudflared_tunnel,
            agent_url=public_url,
            tunnel_type="cloudflare",
        )


def _cleanup_tunnel(tunnel_obj: Any, tunnel_type: Literal["ngrok", "cloudflare", "none"]) -> None:
    """Clean up tunnel connection."""
    try:
        if tunnel_type == "ngrok":
            from pyngrok import ngrok

            ngrok.disconnect(tunnel_obj.public_url)
            ngrok.kill()
            logger.info("Ngrok tunnel closed")
        elif tunnel_type == "cloudflare":
            if hasattr(tunnel_obj, "disconnect"):
                tunnel_obj.disconnect()
            elif hasattr(tunnel_obj, "stop"):
                tunnel_obj.stop()
            elif hasattr(tunnel_obj, "close"):
                tunnel_obj.close()
            logger.info("Cloudflare tunnel closed")
    except Exception as e:
        logger.warning("Error closing %s tunnel: %s", tunnel_type, e)


async def _update_backend_agent_url(
    agent_id: str,
    agent_url: str | None,
    quraite_endpoint: str = "https://api.quraite.ai",
) -> None:
    """
    Update backend with agent URL.

    Args:
        agent_id: Quraite platform agent ID
        agent_url: Agent base URL
        quraite_endpoint: Quraite API endpoint
    """
    if not agent_id or not agent_url:
        return

    endpoint = f"{quraite_endpoint.rstrip('/')}/agents/{agent_id}/config/url"
    full_url = f"{agent_url.rstrip('/')}/v1/agents/completions"
    payload = {"config": {"url": full_url}}

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.patch(endpoint, json=payload)
            response.raise_for_status()
            logger.info("Agent URL registered with Quraite platform: %s", full_url)
    except httpx.HTTPStatusError as e:
        logger.warning(
            "Failed to update agent URL in Quraite platform: HTTP %s - %s. Update manually with URL: %s",
            e.response.status_code,
            e.response.text,
            full_url,
        )
    except httpx.RequestError as e:
        logger.warning(
            "Failed to connect to Quraite backend at %s: %s",
            quraite_endpoint,
            e,
        )
    except Exception as e:
        logger.warning("Unexpected error updating agent URL: %s", e)


def create_app(
    agent_adapter: BaseAdapter,
    *,
    agent_id: str | None = None,
    tunnel_config: TunnelConfig | None = None,
) -> FastAPI:
    """
    Create a standalone FastAPI app for an agent.

    Returns a FastAPI application that developers can run with any ASGI server
    (uvicorn, hypercorn, etc.). The app is self-contained with lifespan management.

    Args:
        agent_adapter: The agent adapter instance (must inherit from BaseAdapter)
        agent_id: Optional Quraite platform agent ID for backend registration
        tunnel_config: Optional TunnelConfig object. This is required if you are using a tunnel. To get the tunnel config, use the setup_tunnel function.

    Returns:
        FastAPI application instance with agent endpoints
    """
    logger.info("Creating FastAPI app with agent adapter")

    adapter = agent_adapter

    # Extract tunnel info
    tunnel_obj = tunnel_config.tunnel_obj if tunnel_config else None
    agent_url = tunnel_config.agent_url if tunnel_config else None
    tunnel_type = tunnel_config.tunnel_type if tunnel_config else None

    # Create lifespan with tunnel and backend registration
    from contextlib import asynccontextmanager

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Startup
        logger.info("Agent server started successfully")
        path = "/v1/agents/completions"

        # Register with Quraite backend if agent_id and tunnel provided
        if agent_id and tunnel_type:
            quraite_endpoint = os.getenv("QURAITE_ENDPOINT", "https://api.quraite.ai")
            await _update_backend_agent_url(agent_id, agent_url, quraite_endpoint)

        if tunnel_type:
            logger.info(f"Agent publicly available at {agent_url}{path}")
            if not agent_id:
                logger.info(
                    f"Add this URL to your agent in the Quraite platform: {agent_url}{path}"
                )
        elif agent_url:
            logger.info(
                f"Agent running locally at {agent_url}{path}. Use tunnel option to make it publicly available."
            )

        yield

        # Shutdown - cleanup tunnel
        if tunnel_obj and tunnel_type:
            logger.info("Closing %s tunnel...", tunnel_type)
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, _cleanup_tunnel, tunnel_obj, tunnel_type)

    # Create FastAPI app with lifespan
    app = FastAPI(title="Quraite Agent Server", lifespan=lifespan)

    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Health check endpoint
    @app.get("/")
    def health_check():
        """Health check endpoint."""
        return {
            "status": "ok",
            "message": "Agent server is running",
        }

    # Agent invocation endpoint
    @app.post("/v1/agents/completions", response_model=InvokeOutput)
    async def invoke_agent(request: InvokeInput) -> InvokeOutput:
        """
        Agent invocation endpoint.

        Args:
            request: InvokeInput containing user_message and session_id

        Returns:
            InvokeOutput with agent response

        Raises:
            HTTPException: If agent invocation fails
        """
        try:
            response = await adapter.ainvoke(input=request)
            return response
        except Exception as e:
            logger.exception("Agent invocation failed")
            raise HTTPException(
                status_code=500,
                detail=f"Agent invocation failed: {str(e)}",
            ) from e

    logger.info("FastAPI app created successfully")
    return app


def run_agent(
    agent_adapter: BaseAdapter,
    *,
    agent_id: str | None = None,
    port: int = 8080,
    host: str = "0.0.0.0",
    tunnel: Literal["none", "cloudflare", "ngrok"] = "none",
) -> None:
    """
    Run an agent with a single line of code.

    This function starts a FastAPI server for the provided agent adapter,
    providing the best developer experience.

    Args:
        agent_adapter: The agent adapter instance (must inherit from BaseAdapter)
        agent_id: Optional Quraite platform agent ID
        port: Port number for the local server (default: 8080)
        host: Host address (default: "0.0.0.0")
        tunnel: Tunnel type ("none", "cloudflare", "ngrok") for public access

    Example:
        ```python
        from quraite import run_agent
        from quraite.adapters.langchain_adapter import LangchainAdapter

        # Create adapter with tracing enabled
        adapter = LangchainAdapter(agent_graph=my_graph, tracing=True)

        # Run with tunnel
        run_agent(adapter, tunnel="cloudflare", agent_id="agent-123")
        ```
    """
    logger.info(
        "Starting agent runner (port=%d, tunnel=%s, agent_id=%s)",
        port,
        tunnel,
        agent_id,
    )

    # Setup tunnel if requested
    tunnel_config = None
    if tunnel != "none":
        logger.info("Setting up %s tunnel on port %s...", tunnel, port)
        tunnel_config = setup_tunnel(port, host, tunnel)

    # Create app with tunnel config
    app = create_app(agent_adapter, agent_id=agent_id, tunnel_config=tunnel_config)

    # Run server
    uvicorn.run(app, host=host, port=port)
