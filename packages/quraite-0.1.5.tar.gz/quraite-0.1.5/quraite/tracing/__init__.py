"""Tracing infrastructure for OpenTelemetry span collection and processing."""

from quraite.constants.framework import Framework
from quraite.tracing.setup import setup_tracing
from quraite.tracing.span_exporter import QuraiteSpanExporter
from quraite.tracing.span_processor import QuraiteSpanProcessor
from quraite.tracing.tool_extractors import ToolCallInfo, get_tool_extractor
from quraite.tracing.trace import AgentSpan, AgentTrace, CostInfo, TokenInfo
from quraite.tracing.types import Event, Link, Resource, SpanContext, Status

__all__ = [
    "AgentSpan",
    "AgentTrace",
    "CostInfo",
    "TokenInfo",
    "Framework",
    "Tool",
    "ToolCallInfo",
    "get_tool_extractor",
    "QuraiteSpanExporter",
    "QuraiteSpanProcessor",
    "Event",
    "Link",
    "Resource",
    "SpanContext",
    "Status",
    "setup_tracing",
]
