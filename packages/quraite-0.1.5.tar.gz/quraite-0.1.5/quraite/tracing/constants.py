QURAITE_TRACER_NAME = "quraite.instrumentation"
