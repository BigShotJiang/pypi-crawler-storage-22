"""Centralized tracing setup and framework instrumentation."""


from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider as SDKTracerProvider

from quraite.constants.framework import Framework
from quraite.logger import get_logger
from quraite.tracing.span_exporter import QuraiteSpanExporter
from quraite.tracing.span_processor import QuraiteSpanProcessor

logger = get_logger(__name__)


def setup_tracing(
    frameworks: list[Framework | str] = [],
    tracer_provider: SDKTracerProvider | None = None,
) -> SDKTracerProvider:
    """
    Configure tracing once at app startup.

    Args:
        frameworks: Frameworks to instrument (e.g., [Framework.LANGCHAIN])
        tracer_provider: Optional existing provider (auto-creates if None)

    Returns:
        Configured TracerProvider to pass to adapters
    """
    provider = tracer_provider or _create_tracer_provider()
    _inject_quraite_processor(provider)

    for framework in frameworks:
        _instrument_framework(framework, provider)

    logger.info("Tracing setup complete for frameworks: %s", frameworks)
    return provider


def _create_tracer_provider() -> SDKTracerProvider:
    """Create TracerProvider or use existing global provider."""
    global_provider = trace.get_tracer_provider()
    if isinstance(global_provider, SDKTracerProvider):
        logger.debug("Using existing global TracerProvider")
        return global_provider

    logger.debug("Creating new TracerProvider")
    return SDKTracerProvider()


def _inject_quraite_processor(provider: SDKTracerProvider) -> None:
    """Inject QuraiteSpanProcessor if not already present."""
    has_quraite_processor = any(
        isinstance(processor, QuraiteSpanProcessor)
        for processor in provider._active_span_processor._span_processors
    )

    if not has_quraite_processor:
        logger.debug("Injecting QuraiteSpanProcessor")
        exporter = QuraiteSpanExporter()
        processor = QuraiteSpanProcessor(exporter)
        provider.add_span_processor(processor)
        logger.info("QuraiteSpanProcessor injected")
    else:
        logger.debug("QuraiteSpanProcessor already present")


def _instrument_framework(
    framework: Framework | str, provider: SDKTracerProvider
) -> None:
    """Instrument a specific framework (idempotent)."""
    framework_str = framework.value if isinstance(framework, Framework) else framework

    match framework_str:
        case Framework.LANGCHAIN | "langchain":
            try:
                from openinference.instrumentation.langchain import (
                    LangChainInstrumentor,
                )

                LangChainInstrumentor().instrument(tracer_provider=provider)
            except ImportError as e:
                raise ImportError(
                    f"Failed to import LangChain openinference instrumentation. "
                    f"Please install the 'langchain-oi' optional dependency: pip install 'quraite[langchain-oi]'"
                ) from e

        case Framework.AGNO | "agno":
            try:
                from openinference.instrumentation.agno import AgnoInstrumentor

                AgnoInstrumentor().instrument(tracer_provider=provider)
            except ImportError as e:
                raise ImportError(
                    f"Failed to import Agno openinference instrumentation. "
                    f"Please install the 'agno-oi' optional dependency: pip install 'quraite[agno-oi]'"
                ) from e

        case Framework.PYDANTIC_AI | "pydantic_ai":
            try:
                from openinference.instrumentation.pydantic_ai import (
                    OpenInferenceSpanProcessor,
                )

                # Pydantic AI instrumentation requires the tracer provider to be set globally
                trace.set_tracer_provider(provider)
                provider.add_span_processor(OpenInferenceSpanProcessor())
            except ImportError as e:
                raise ImportError(
                    f"Failed to import Pydantic AI openinference span processor. "
                    f"Please install the 'pydantic-ai-oi' optional dependency: pip install 'quraite[pydantic-ai-oi]'"
                ) from e

        case Framework.GOOGLE_ADK | "google_adk":
            try:
                from openinference.instrumentation.google_adk import (
                    GoogleADKInstrumentor,
                )

                GoogleADKInstrumentor().instrument(tracer_provider=provider)
            except ImportError as e:
                raise ImportError(
                    f"Failed to import Google ADK openinference instrumentation. "
                    f"Please install the 'google-adk-oi' optional dependency: pip install 'quraite[google-adk-oi]'"
                ) from e

        case Framework.SMOLAGENTS | "smolagents":
            try:
                from openinference.instrumentation.smolagents import (
                    SmolagentsInstrumentor,
                )

                SmolagentsInstrumentor().instrument(tracer_provider=provider)
            except ImportError as e:
                raise ImportError(
                    f"Failed to import Smolagents openinference instrumentation. "
                    f"Please install the 'smolagents-oi' optional dependency: pip install 'quraite[smolagents-oi]'"
                ) from e

        case Framework.OPENAI_AGENTS | "openai_agents":
            try:
                from openinference.instrumentation.openai_agents import (
                    OpenAIAgentsInstrumentor,
                )

                OpenAIAgentsInstrumentor().instrument(tracer_provider=provider)
            except ImportError as e:
                raise ImportError(
                    f"Failed to import OpenAI Agents openinference instrumentation. "
                    f"Please install the 'openai-agents-oi' optional dependency: pip install 'quraite[openai-agents-oi]'"
                ) from e
        case Framework.OPENAI | "openai":
            try:
                from openinference.instrumentation.openai import OpenAIInstrumentor

                OpenAIInstrumentor().instrument(tracer_provider=provider)
            except ImportError as e:
                raise ImportError(
                    f"Failed to import OpenAI openinference instrumentation. "
                    f"Please install the 'openai-oi' optional dependency: pip install 'quraite[openai-oi]'"
                ) from e
        case _:
            logger.warning("Unknown framework: %s", framework_str)
            return

    logger.info("Instrumented framework: %s", framework_str)
