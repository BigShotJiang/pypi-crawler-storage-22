import re
import re
import sys
import os


from Levenshtein import opcodes

from quran_transcript.phonetics.conv_base_operation import MappingPos
from quran_transcript.phonetics.tajweed_rulses import (
    NormalMaddRule,
    TajweedRule,
    LangName,
)


"""
Taks: 
I have sequential re.sub operation I want to be able to map every char in the output string to the input string
the function takes previous mapping and returns the new mapping from the first input to the fresh new substiuted string.
Use Levenestein opcdes for this task:

The regs are complicated so try to be wise the regs are in: quran_transcript.phonetics.operations
Make your changes are here so I will plant in the code later

opcodes docs:
    Find sequence of edit operations transforming one string to another.

    opcodes(source_string, destination_string)
    opcodes(edit_operations, source_length, destination_length)

    The result is a list of 5-tuples with the same meaning as in
    SequenceMatcher's get_opcodes() output.  But since the algorithms
    differ, the actual sequences from Levenshtein and SequenceMatcher
    may differ too.

    Examples
    --------
    >>> for x in opcodes('spam', 'park'):
    ...     print(x)
    ...
    ('delete', 0, 1, 0, 0)
    ('equal', 1, 3, 0, 2)
    ('insert', 3, 3, 2, 3)
    ('replace', 3, 4, 3, 4)

    The alternate form opcodes(editops, source_string, destination_string)
    can be used for conversion from editops (triples) to opcodes (you can
    pass strings or their lengths, it doesn't matter).

"""

out = [
    MappingPos(pos=(0, 3)),
    MappingPos(pos=(3, 4)),
    MappingPos(pos=(4, 5)),
    MappingPos(pos=(5, 6)),
]


def merge_mappings(
    mappings: list[MappingPos | None] | None, new_mappings: list[MappingPos | None]
):
    if mappings is None:
        return new_mappings

    # TODO: add Tajweed rules depencance
    merged_mappings = [None] * len(mappings)
    for idx, old_map in enumerate(mappings):
        if old_map is not None:
            start_map = None
            end_map = None
            for start_map in new_mappings[old_map.pos[0] : old_map.pos[1]]:
                if start_map is not None:
                    break
            for end_map in new_mappings[old_map.pos[0] : old_map.pos[1]][::-1]:
                if end_map is not None:
                    break

            if start_map is not None and end_map is not None:
                merged_mappings[idx] = MappingPos(
                    pos=(start_map.pos[0], end_map.pos[1])
                )
            elif start_map is not None:
                merged_mappings[idx] = MappingPos(pos=start_map.pos)
            elif end_map is not None:
                merged_mappings[idx] = MappingPos(pos=end_map.pos)

    return merged_mappings


def sub_with_mapping(
    pattern: str,
    repl,
    text: str,
    mappings: list[MappingPos | None] | None = None,
    tajweed_rule: TajweedRule | None = None,
) -> tuple[str, list[MappingPos | None]]:
    """
    Examples:

        pattern: r"(a)"
        repl: r"\1\1\1"
        text: "abcd"
        tajweed_rule = NormalMadd()

        Output:
    (
        "aaabcd",
        [
            MappingPos(pos=(0, 3), tajweed_rules=[NormalMadd()]),
            MappingPos(pos=(3, 4)),
            MappingPos(pos=(4, 5)),
            MappingPos(pos=(5, 6)),
        ],
    )


    ----------------
        pattern: r"d$"
        repl: r""
        text: "aaabcd"
        mappings:
            [
                MappingPos(pos=(0, 3), tajweed_rules=[NormalMadd()]),
                MappingPos(pos=(3, 4)),
                MappingPos(pos=(4, 5)),
                MappingPos(pos=(5, 6)),
            ]

        Output:
    (
        "aaabc",
        [
            MappingPos(pos=(0, 3), tajweed_rules=[NormalMadd()]),
            MappingPos(pos=(3, 4)),
            MappingPos(pos=(4, 5)),
            None,
        ],
    )
    ----------------

    """
    if text == "":
        return "", []

    # Apply the regex substitution
    new_text = re.sub(pattern, repl, text)

    # rev_mapings = {}
    # if mappings:
    #     for m_idx, map_pos in enumerate(mappings):
    #         if map_pos is not None:
    #             for idx in range(map_pos.pos[0], map_pos.pos[1]):
    #                 rev_mapings[idx] = m_idx

    # NOTE: Opcoes operation order is: equal, insert, replace
    ops = opcodes(text, new_text)
    print(ops)
    """
    to_overwrite_tajweed_rules: if a rule in the future occupy in the same span ignore the new rule in the `to_overwrite_tajweed_rules` and keep the old rule
    Cases:

    * Madd ALif Complete partial replacement:
    abcd -> aaabcd (equal[a] + insert[a]) or (insert[a] + equal[a])

    * Madd Alif with ~:
    abcd -> aaaacd (equal + insert + replace) && insert[0] == last_eqaul == replace[0]

    * Complete replacement
    abcd -> kkkabcd (replace or insert + replace or replace + insert)

    * Complete Deletion
    * abcd -> abc
    """
    new_mappings: list[None | MappingPos] = [None] * len(text)

    last_op = None
    curr_op = ops[0]
    next_op = ops[1] if len(ops) > 1 else None
    to_del_poses = set()
    for op_idx in range(len(ops)):
        next_op = ops[op_idx + 1] if len(ops) > (op_idx + 1) else None
        if curr_op[0] == "insert":
            eq_ins = False
            if last_op is not None:
                # equal before
                if (
                    last_op[0] == "equal"
                    and new_text[last_op[4] - 1] == new_text[curr_op[3]]
                ):
                    # increae the end pos to append the insert
                    new_mappings[last_op[2] - 1].pos = (
                        new_mappings[last_op[2] - 1].pos[0],
                        curr_op[4],
                    )
                    new_mappings[last_op[2] - 1].add_tajweed_rule(tajweed_rule)
                    eq_ins = True

            if next_op is not None:
                # equal + insert + replace
                if eq_ins:
                    # equal before
                    if (
                        next_op[0] == "replace"
                        and new_text[curr_op[4] - 1] == new_text[next_op[3]]
                    ):
                        # #increase the end
                        new_mappings[last_op[2] - 1].pos = (
                            new_mappings[last_op[2] - 1].pos[0],
                            next_op[4],
                        )
                        # increae the end pos to append the insert
                        for old_idx in range(next_op[1], next_op[2]):
                            new_mappings[old_idx] = None
                            to_del_poses.add(old_idx)
                # insert + replace
                else:
                    if (
                        next_op[0] == "replace"
                        # and new_text[curr_op[4] - 1] == new_text[next_op[3]]
                    ):
                        # increae the end pos to append the insert
                        new_map_pos = MappingPos(pos=(curr_op[3], next_op[4]))
                        new_map_pos.add_tajweed_rule(tajweed_rule)
                        new_mappings[next_op[1]] = new_map_pos
                        # assignign the rest to None
                        for old_idx in range(next_op[1] + 1, next_op[2]):
                            new_mappings[old_idx] = None
                            to_del_poses.add(old_idx)

        elif curr_op[0] == "replace":
            for old_idx, new_idx in zip(
                range(curr_op[1], curr_op[2]), range(curr_op[3], curr_op[4])
            ):
                if new_mappings[old_idx] is None and old_idx not in to_del_poses:
                    new_map_pos = MappingPos(pos=(new_idx, new_idx + 1))
                    new_map_pos.add_tajweed_rule(tajweed_rule)
                    new_mappings[old_idx] = new_map_pos

        elif curr_op[0] == "equal":
            for old_idx, new_idx in zip(
                range(curr_op[1], curr_op[2]), range(curr_op[3], curr_op[4])
            ):
                new_mappings[old_idx] = MappingPos(pos=(new_idx, new_idx + 1))
        elif curr_op[0] == "delete":
            ...

        last_op = curr_op
        curr_op = next_op

    new_mappings = merge_mappings(mappings, new_mappings)

    return new_text, new_mappings


if __name__ == "__main__":
    text = "abcd"
    out_text, mappings = sub_with_mapping("", "", text)
    print(text)
    print(out_text)
    print(mappings)
    print("-" * 40)

    # equal + insert
    text = "abcd"
    out_text, mappings = sub_with_mapping("a", "aaaa", text)
    print(text)
    print(out_text)
    print(mappings)
    print("-" * 40)

    # equal + insert + replace
    text = "abcd"
    out_text, mappings = sub_with_mapping("ab", "aaaa", text)
    print(text)
    print(out_text)
    print(mappings)
    print("-" * 40)

    #  insert + replace
    text = "abcd"
    out_text, mappings = sub_with_mapping("ab", "mmmm", text)
    print(text)
    print(out_text)
    print(mappings)
    print("-" * 40)

    #  insert + replace
    text = "abcd"
    out_text, mappings = sub_with_mapping("a", "mn", text)
    print(text)
    print(out_text)
    print(mappings)
    print("-" * 40)

    #  delete
    text = "abcd"
    out_text, mappings = sub_with_mapping("b", "", text)
    print(text)
    print(out_text)
    print(mappings)
    print("-" * 40)

    #  replace
    text = "abcd"
    out_text, mappings = sub_with_mapping("bc", "mn", text)
    print(text)
    print(out_text)
    print(mappings)
    print("-" * 40)

    #  replace + delete
    text = "abcd"
    out_text, mappings = sub_with_mapping("bcd", "mn", text)
    print(text)
    print(out_text)
    print(mappings)
    print("-" * 40)

    # equal + insert + replace + delete
    text = "abcd"
    out_text, mappings = sub_with_mapping("ab(.)d$", r"aaaa\1", text)
    print(text)
    print(out_text)
    print(mappings)
    print("-" * 40)
