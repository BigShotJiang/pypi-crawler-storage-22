"""Utility modules for Quran unified API."""
