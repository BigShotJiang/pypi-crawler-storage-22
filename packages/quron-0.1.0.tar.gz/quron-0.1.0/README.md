# Quron

![Python](https://img.shields.io/badge/python-≥3.11-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Status](https://img.shields.io/badge/status-experimental-orange)

Binary Autoencoder-based QUBO optimization library for Python.

## Overview

Quron は、組合せ最適化問題を QUBO (Quadratic Unconstrained Binary Optimization) に自動変換するための Python ライブラリです。

**基本フロー:**

1. 解空間を `Variable` で定義
2. `AEBuilder` で解をバイナリ潜在ベクトルに圧縮
3. Factorization Machine (FM) で目的関数の surrogate を学習
4. FM を QUBO に変換
5. イジングマシン（Amplify / D-Wave）で最適化

## Installation

```bash
pip install quron
```

### Optional Dependencies

ソルバーを使用する場合は、対応するオプションをインストールしてください。

```bash
# Amplify solver
pip install quron[amplify]

# D-Wave solver
pip install quron[dwave]

# Both solvers
pip install quron[solvers]
```

## Quick Start

```python
from quron import Variable, AEBuilder, Optimizer, AmplifySolver

# 1. 解空間の定義
var = Variable(length=5, var_type="integer", min_value=0, max_value=3)

# 2. 目的関数の定義（最小化）
def objective(solution):
    return sum(solution)

# 3. 初期解の生成
initial_solutions = var.sample_random(20)
initial_values = [objective(sol) for sol in initial_solutions]

# 4. オートエンコーダの学習
ae = AEBuilder(var, latent_dim=8)
ae.train(initial_solutions)

# 5. ソルバーの設定
solver = AmplifySolver(token="YOUR_AMPLIFY_TOKEN")

# 6. 最適化
optimizer = Optimizer(var, ae, objective, solver)
optimizer.add_initial_data(initial_solutions, initial_values)
optimizer.optimize(num_iterations=5)

# 7. 結果の取得
print(f"Best solution: {optimizer.best_solution}")
print(f"Best value: {optimizer.best_value}")
```

## API Reference

詳細は [docs/reference.md](docs/reference.md) を参照してください。

- **Variable** - 解空間の定義
- **AEBuilder** - RNN (GRU) ベースのオートエンコーダ
- **Solver** - QUBO ソルバー（AmplifySolver, DWaveSolver）
- **Optimizer** - AE + FM + Solver を組み合わせた最適化ループ

## Requirements

- Python >= 3.11
- numpy >= 1.24.0
- torch >= 2.0.0
- pandas >= 2.0.0

## License

MIT License
