# Quron API Spec (v1)

対象ライブラリ名: `quron`
Python: 3.11+
主要依存: `numpy`, `torch`, `pandas` (optional)

---

## 全体方針

### 対象問題

整数 or カテゴリ変数からなる **1次元シーケンス** で表される組合せ最適化問題

例: TSP の都市列、スケジューリングのスロット列など

### 基本フロー

1. 解空間を `Variable` で定義
2. `AEBuilder` で「解 → バイナリ潜在変数」への圧縮器を構築
3. `FMModel` で「潜在バイナリ → 目的関数値」の surrogate を学習
4. `FMModel.to_qubo()` で QUBO を構築
5. `Solver.solve_qubo()` で QUBO をイジングマシン / ソルバに投げる
6. 最良解は `Optimizer` が管理する

### v1 の制約

- 変数型は **全て整数** or **全てカテゴリ** のどちらか一種類のみ
- AE は事前学習のみ（オンライン更新なし）
- 制約は objective 関数内でペナルティとして表現

---

## モジュール構成

```text
quron/
  __init__.py
  spaces.py      # 解空間の定義
  ae.py          # Autoencoder（RNN-based）
  fm.py          # Factorization Machine surrogate（内部API）
  solver.py      # QUBO ソルバ抽象 & 実装
  optimize.py    # 最適化ループ
```

---

## `quron.spaces.Variable`

```python
class Variable:
    def __init__(
        self,
        length: int,
        var_type: Literal["integer", "category"],
        min_value: int | None = None,
        max_value: int | None = None,
        labels: Sequence[str] | None = None,
    ): ...
```

### パラメータ

| パラメータ | 説明 |
|-----------|------|
| `length` | 解の長さ（シーケンス長）、`length > 0` |
| `var_type` | `"integer"` または `"category"` |
| `min_value`, `max_value` | 整数モード時に必須 |
| `labels` | カテゴリモード時に必須 |

### メソッド

```python
def sample_random(self, n: int) -> list[list]
def validate(self, solution: list) -> bool
def to_internal_ids(self, solution: list) -> list[int]
def from_internal_ids(self, ids: list[int]) -> list
```

---

## `quron.ae.AEBuilder`

RNN（GRU）ベースのオートエンコーダ。Straight-through estimator でバイナリ潜在ベクトルを生成。

```python
class AEBuilder:
    def __init__(
        self,
        space: Variable,
        latent_dim: int | None = None,
        alpha: float = 0.5,
        seed: int | None = None,
        *,
        hidden_dim: int = 128,
        num_layers: int = 2,
        epochs: int = 50,
        batch_size: int = 64,
        learning_rate: float = 1e-3,
        device: str | None = None,
    ): ...
```

`latent_dim` が `None` の場合、`alpha * length * log2(vocab_size)` で自動計算。

### メソッド

```python
def train(self, solutions: Iterable[list]) -> None
def encode(self, solutions: Iterable[list]) -> np.ndarray  # shape: (N, latent_dim), {0,1}
def decode(self, latents: np.ndarray) -> list[list]
def save(self, path: str) -> None
def load(self, path: str) -> None
```

---

## `quron.fm.FMModel`（内部 API）

> `FMModel` は `Optimizer` が内部で利用するクラス。公開 API ではない。

```python
class FMModel(nn.Module):
    def __init__(self, num_features: int, k: int = 16, l2_reg: float = 0.0): ...
    def fit(self, latents: np.ndarray, values: np.ndarray, **kwargs) -> None
    def predict(self, latents: np.ndarray) -> np.ndarray
    def to_qubo(self) -> tuple[np.ndarray, float]  # (Q, constant)
```

---

## `quron.solver.Solver`

```python
class Solver(ABC):
    @abstractmethod
    def solve_qubo(
        self,
        Q: np.ndarray,
        num_reads: int,
        auto_scale: bool = True,
        **kwargs,
    ) -> list[dict]:
        """
        Returns:
            list of {"sample": np.ndarray, "energy": float}
        """
```

### `AmplifySolver`

```python
class AmplifySolver(Solver):
    def __init__(self, token: str, *, time_limit: float | None = None, backend: str | None = None): ...
```

### `DWaveSolver`

```python
class DWaveSolver(Solver):
    def __init__(self, api_token: str, *, solver_name: str | None = None, chain_strength: float | None = None): ...
```

---

## `quron.optimize.Optimizer`

```python
class Optimizer:
    def __init__(
        self,
        space: Variable,
        builder: AEBuilder,
        objective: Callable[[list], float],
        solver: Solver,
        *,
        num_samples_per_iter: int = 1,
        random_state: int | None = None,
    ): ...
```

### メソッド

```python
def add_initial_data(self, solutions: list[list], values: list[float] | None = None) -> None
def optimize(self, num_iterations: int) -> None
```

### プロパティ

```python
best_solution: list      # 最良解
best_value: float        # 最良値
trials: list[dict]       # {"solution", "value", "latent", "iteration"}
```

---

## 公開 API

```python
from quron import (
    Variable,
    AEBuilder,
    Solver,
    AmplifySolver,
    DWaveSolver,
    Optimizer,
)
```
