# Quron Roadmap

## 現在のバージョン: v1.0

v1 は完成済み。基本的な FMQA ワークフローが動作する状態。

---

## v2 計画

### Phase 1: 観測性の向上

| 機能 | 説明 | 優先度 |
|------|------|--------|
| **History / Logger** | 最適化の進捗ログ、可視化機能（`plot_history()` 等） | 高 |
| **io.py** | trials の CSV 入出力、最適化の保存・再開 | 中 |

### Phase 2: アルゴリズム拡張

| 機能 | 説明 | 優先度 |
|------|------|--------|
| **Kernel QA オプション** | FM ではなく Kernel ベースのサロゲートモデル | 高 |
| **AE オンライン更新** | 最適化中に AE を追加学習し潜在空間を改善 | 中 |

### Phase 3: 制約処理の高度化

| 機能 | 説明 | 優先度 |
|------|------|--------|
| **制約 FM 分離** | 目的関数と制約を別々の FM で学習し合成 | 高 |
| **Constraint クラス** | `equal_to()`, `less_equal()` のような宣言的制約定義 | 中 |

### Phase 4: 拡張性

| 機能 | 説明 | 優先度 |
|------|------|--------|
| **カスタム AE** | ユーザーが自作 AE（Transformer 等）を差し込める機構 | 中 |
| **追加ソルバ** | ローカル SA、他クラウドソルバ対応 | 低 |
| **変数混合型** | integer と category を同時に使用可能に | 低 |
| **目的関数値の変換** | FM 学習用のラベル加工オプション | 低 |

---

## 設計メモ: カスタム AE

### 方針: 継承パターン

`AEBuilder` を継承し、`_build_model()` をオーバーライドする形式。

```python
class AEBuilder:
    def _build_model(self) -> nn.Module:
        """オーバーライドしてカスタムモデルを返す"""
        return _OneHotAutoEncoder(...)

class CustomAEBuilder(AEBuilder):
    def _build_model(self):
        return MyTransformerAutoEncoder(...)
```

### モデルの必須インターフェース

カスタムモデルは以下のメソッドを実装する必要がある:

```python
class CustomAutoEncoder(nn.Module):
    def encode(self, x: Tensor) -> Tensor:
        """[batch, seq] int → [batch, latent_dim] binary {0,1}"""
        ...

    def decode(self, latent: Tensor) -> Tensor:
        """[batch, latent_dim] → [batch, seq, vocab_size] logits"""
        ...

    def forward(self, x: Tensor, use_teacher_forcing: bool) -> tuple[Tensor, Tensor]:
        """学習用: (outputs, latent) を返す"""
        ...
```

### コンポーネント構成

| コンポーネント | 入力 | 出力 | 自由度 |
|---------------|------|------|--------|
| **embedding** | `[batch, seq]` int | `[batch, seq, ?]` | 高（One-hot, Learned, CNN等） |
| **encoder** | embedding出力 | `[batch, hidden]` | 高（GRU, LSTM, Transformer） |
| **latent** | encoder出力 | `[batch, latent_dim]` **binary** | 中（出力は{0,1}必須） |
| **decoder** | latent | `[batch, seq, vocab]` | 高（アーキテクチャ自由） |

### 制約

1. **latent は必ずバイナリ** - Straight-through estimator で `{0, 1}` を出力
2. **入出力は Variable 形式** - 親クラスが変換処理を担当
3. **train/encode/decode は親クラスを使用** - `_build_model()` のみオーバーライド

### 実装時の修正箇所

`ae.py` の `AEBuilder.__init__` 内のモデル構築を `_build_model()` メソッドに分離する。

---

## v1 の制約（現在の仕様）

- 変数型は **全て整数** または **全てカテゴリ** のどちらか一種類のみ
- AE は事前学習のみ（オンライン更新なし）
- 制約は objective 関数内でペナルティとして表現

---

## 設計思想

**制約処理のアプローチ**: 制約をペナルティで表現するのではなく、制約充足解のみで AE を学習することで、潜在空間自体を制約充足解の空間に限定する。これにより、QUBO で探索しても常に制約を満たす解が得られる。

---

## 参考

- [Amplify-BBOpt](https://amplify.fixstars.com/en/docs/amplify-bbopt/v0/index.html) - FMQA / Kernel QA の両方をサポート
