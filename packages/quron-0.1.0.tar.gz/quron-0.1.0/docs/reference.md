# API Reference

## Variable

解空間を定義するクラス。

### コンストラクタ

```python
Variable(
    length: int,
    var_type: str,
    min_value: int = None,    # var_type="integer" の場合に必須
    max_value: int = None,    # var_type="integer" の場合に必須
    labels: list[str] = None, # var_type="category" の場合に必須
)
```

**Parameters:**

| パラメータ | 型 | 説明 |
|-----------|------|------|
| `length` | int | 解の長さ（要素数） |
| `var_type` | str | `"integer"` または `"category"` |
| `min_value` | int | 整数変数の最小値 |
| `max_value` | int | 整数変数の最大値 |
| `labels` | list[str] | カテゴリ変数のラベルリスト |

**Example:**

```python
# 整数変数（各要素が 0〜9 の整数、長さ5）
var = Variable(length=5, var_type="integer", min_value=0, max_value=9)

# カテゴリ変数
var = Variable(length=5, var_type="category", labels=["A", "B", "C"])
```

### Methods

#### sample_random(n)

ランダムに n 個の解を生成。

```python
solutions = var.sample_random(100)
```

#### validate(solution)

解が有効かどうかを検証。

```python
is_valid = var.validate([0, 1, 2, 3, 4])  # True or False
```

#### to_internal_ids(solution) / from_internal_ids(ids)

ユーザ表現と内部ID間の変換。

---

## AEBuilder

RNN (GRU) ベースのオートエンコーダ。Straight-through estimator でバイナリ潜在ベクトルを生成。

### コンストラクタ

```python
AEBuilder(
    space: Variable,
    latent_dim: int | None = None,
    seed: int | None = None,
    *,
    hidden_dim: int = 64,
    num_layers: int = 2,
    device: str | None = None,
)
```

**Parameters:**

| パラメータ | 型 | デフォルト | 説明 |
|-----------|------|-----------|------|
| `space` | Variable | (必須) | 解空間の定義 |
| `latent_dim` | int \| None | None | バイナリ潜在ベクトルの次元。None の場合は自動計算: `max(4, length * log2(vocab_size) // 2)` |
| `seed` | int \| None | None | 乱数シード |
| `hidden_dim` | int | 64 | GRU の隠れ層次元 |
| `num_layers` | int | 2 | GRU の層数 |
| `device` | str \| None | None | デバイス（None で自動検出） |

### train(solutions, ...)

オートエンコーダを学習。

```python
ae.train(
    solutions: Iterable[list],
    *,
    epochs: int = 2000,
    batch_size: int | None = None,
    learning_rate: float = 1e-3,
)
```

**Parameters:**

| パラメータ | 型 | デフォルト | 説明 |
|-----------|------|-----------|------|
| `solutions` | Iterable[list] | (必須) | 学習用の解リスト |
| `epochs` | int | 2000 | エポック数 |
| `batch_size` | int \| None | None | バッチサイズ。None の場合は自動計算: `max(32, len(solutions) // 30)` |
| `learning_rate` | float | 1e-3 | 学習率 |

### encode(solutions)

解をバイナリ潜在ベクトルに変換。

```python
latents = ae.encode(solutions)  # shape: (n_samples, latent_dim), dtype: int32
```

### decode(latents)

潜在ベクトルから解を復元。

```python
solutions = ae.decode(latents)  # list[list]
```

### save(path) / load(path)

モデルの保存・読み込み。

```python
ae.save("model.pt")
ae.load("model.pt")
```

---

## Solver

QUBO を解くソルバーの抽象クラス。

### AmplifySolver

Fixstars Amplify を使用するソルバー。

```python
AmplifySolver(
    token: str,
    time_limit: float = 1.0,
    **kwargs,
)
```

**Parameters:**

| パラメータ | 型 | デフォルト | 説明 |
|-----------|------|-----------|------|
| `token` | str | (必須) | Amplify API トークン |
| `time_limit` | float | 1.0 | 求解時間制限（秒） |

### DWaveSolver

D-Wave を使用するソルバー。

```python
DWaveSolver(
    api_token: str,
    solver_name: str = "Advantage_system6.4",
    **kwargs,
)
```

**Parameters:**

| パラメータ | 型 | デフォルト | 説明 |
|-----------|------|-----------|------|
| `api_token` | str | (必須) | D-Wave API トークン |
| `solver_name` | str | "Advantage_system6.4" | ソルバー名 |

---

## Optimizer

AE + FM + Solver を組み合わせた最適化ループ。

### コンストラクタ

```python
Optimizer(
    space: Variable,
    builder: AEBuilder,
    objective: Callable[[list], float],
    solver: Solver,
    *,
    num_samples_per_iter: int = 1,
    random_state: int | None = None,
)
```

**Parameters:**

| パラメータ | 型 | デフォルト | 説明 |
|-----------|------|-----------|------|
| `space` | Variable | (必須) | 解空間の定義 |
| `builder` | AEBuilder | (必須) | 学習済みオートエンコーダ |
| `objective` | Callable | (必須) | 目的関数（最小化） |
| `solver` | Solver | (必須) | QUBO ソルバー |
| `num_samples_per_iter` | int | 1 | イテレーションあたりのサンプル数 |
| `random_state` | int \| None | None | 乱数シード |

### configure_fm(**kwargs)

FM サロゲートモデルのパラメータを設定。

```python
optimizer.configure_fm(
    k: int | None = None,
    epochs: int | None = None,
    batch_size: int | None = None,
    learning_rate: float | None = None,
    l2_reg: float | None = None,
)
```

**Parameters:**

| パラメータ | 型 | デフォルト | 説明 |
|-----------|------|-----------|------|
| `k` | int | min(10, latent_dim) | Factorization のランク |
| `epochs` | int | 1000 | エポック数 |
| `batch_size` | int | 20 | バッチサイズ |
| `learning_rate` | float | 0.1 | 学習率 |
| `l2_reg` | float | 0.0 | L2 正則化係数 |

### add_initial_data(solutions, values)

初期データを追加。

```python
optimizer.add_initial_data(solutions, values=None)
```

`values` が None の場合、`objective` 関数で自動計算。

### optimize(num_iterations)

最適化を実行。

```python
optimizer.optimize(num_iterations=10)
```

### Properties

| プロパティ | 型 | 説明 |
|-----------|------|------|
| `best_solution` | list | 最良解 |
| `best_value` | float | 最良値 |
| `trials` | list[dict] | 全試行履歴 |
