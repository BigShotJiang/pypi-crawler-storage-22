"""
End-to-end test: ユーザー目線でデータの用意から解取得まで
"""

import os
from dotenv import load_dotenv
load_dotenv()

from quron import Variable, AEBuilder, Optimizer, AmplifySolver


def main():
    # 1. 変数空間の定義
    var = Variable(length=5, var_type="integer", min_value=0, max_value=3)
    print(f"変数空間: {var}")

    # 2. 初期解の生成と評価
    def objective(solution):
        return sum(solution)  # 最小化（最適解は全て0）

    initial_solutions = var.sample_random(20)
    initial_values = [objective(sol) for sol in initial_solutions]
    print(f"初期ベスト: {min(initial_values)}")

    # 3. オートエンコーダの学習
    ae = AEBuilder(var, latent_dim=8, epochs=20, seed=42)
    ae.train(initial_solutions)
    print(f"AE学習完了: {ae}")

    # 4. 最適化の実行
    token = os.getenv("AMPLIFY_TOKEN")
    solver = AmplifySolver(token=token)

    optimizer = Optimizer(var, ae, objective, solver, num_samples_per_iter=2)
    optimizer.add_initial_data(initial_solutions, initial_values)
    optimizer.optimize(num_iterations=3)

    # 5. 結果
    print(f"最終ベスト: {optimizer.best_value}")
    print(f"ベスト解: {optimizer.best_solution}")


if __name__ == "__main__":
    main()
