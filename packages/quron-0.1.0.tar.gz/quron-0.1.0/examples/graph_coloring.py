"""
Graph Coloring example using Quron.

グラフ彩色問題をquronで解く。
各頂点に色を割り当て、隣接頂点が同色にならない制約の下で
彩色コストを最小化する。

非順列・カテゴリ変数の例。同じ色を複数頂点に使える点がTSP/QAPと異なる。

"""

import os

import numpy as np
from dotenv import load_dotenv

load_dotenv()

from quron import AEBuilder, DWaveSolver, Optimizer, Variable


def generate_graph(n_vertices: int, edge_prob: float, seed: int = 0) -> list[tuple[int, int]]:
    """ランダムグラフ（Erdos-Renyi）を生成する。"""
    rng = np.random.default_rng(seed)
    edges = []
    for i in range(n_vertices):
        for j in range(i + 1, n_vertices):
            if rng.random() < edge_prob:
                edges.append((i, j))
    return edges


def is_valid_coloring(coloring: list, edges: list[tuple[int, int]]) -> bool:
    """彩色が有効（隣接頂点が同色でない）か判定する。"""
    for i, j in edges:
        if coloring[i] == coloring[j]:
            return False
    return True


def generate_valid_colorings(
    n_vertices: int, colors: list[str], edges: list[tuple[int, int]],
    n_samples: int, seed: int = 0,
) -> list[list]:
    """棄却サンプリングで有効な彩色（制約充足解）を生成する。"""
    rng = np.random.default_rng(seed)
    colorings = []
    while len(colorings) < n_samples:
        c = [colors[i] for i in rng.integers(0, len(colors), size=n_vertices)]
        if is_valid_coloring(c, edges):
            colorings.append(c)
    return colorings


def coloring_cost(
    coloring: list, colors: list[str], vertex_costs: np.ndarray,
) -> float:
    """頂点ごとの色コストの合計を計算する。"""
    idx = {c: i for i, c in enumerate(colors)}
    return sum(vertex_costs[i, idx[c]] for i, c in enumerate(coloring))


def main():
    n_vertices = 8
    colors = ["R", "G", "B"]

    # 1. グラフと頂点コストの生成
    edges = generate_graph(n_vertices, edge_prob=0.4, seed=42)
    print(f"頂点数: {n_vertices}, 辺数: {len(edges)}, 色: {colors}")
    print(f"辺: {edges}")

    rng = np.random.default_rng(42)
    vertex_costs = rng.uniform(0, 10, size=(n_vertices, len(colors)))
    print(f"頂点コスト:\n{np.round(vertex_costs, 1)}")

    # 2. 変数空間の定義（各頂点に色を割当 — 同じ色の重複OK）
    var = Variable(length=n_vertices, var_type="category", labels=colors)

    # 3. 目的関数（コストのみ — 制約ペナルティ不要）
    def objective(solution):
        return coloring_cost(solution, colors, vertex_costs)

    # 4. AEの学習（有効な彩色のみで学習）
    ae_solutions = generate_valid_colorings(n_vertices, colors, edges, 1000, seed=0)
    ae = AEBuilder(var, latent_dim=8, seed=42)
    ae.train(ae_solutions, epochs=1000)
    print(f"\nAE学習完了: {ae}")

    # 5. 最適化の初期データ
    initial_solutions = generate_valid_colorings(n_vertices, colors, edges, 20, seed=1)
    initial_values = [objective(sol) for sol in initial_solutions]
    print(f"初期解数: {len(initial_solutions)}")
    print(f"初期ベストコスト: {min(initial_values):.2f}")

    # 6. 最適化
    token = "YOUR_API_TOKEN"
    solver = DWaveSolver(api_token=token)

    optimizer = Optimizer(var, ae, objective, solver, num_samples_per_iter=1)
    optimizer.add_initial_data(initial_solutions, initial_values)
    optimizer.optimize(num_iterations=5)

    # 7. 結果
    print(f"\n=== 結果 ===")
    print(f"最終ベストコスト: {optimizer.best_value:.2f}")
    print(f"ベスト彩色:       {optimizer.best_solution}")
    print(f"評価回数:         {len(optimizer.trials)}")


if __name__ == "__main__":
    main()
