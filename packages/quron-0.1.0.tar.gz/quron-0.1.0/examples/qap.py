"""
QAP (Quadratic Assignment Problem) example using Quron.

N個の施設をN箇所の拠点に割り当てるQAPをquronで解く。
解は割り当て（カテゴリ順列）で表現する。solution[i] = 施設iの配置先拠点。

TSPがinteger変数の例であるのに対し、こちらはcategory変数の例。

"""

import os

import numpy as np
from dotenv import load_dotenv

load_dotenv()

from quron import AEBuilder, DWaveSolver, Optimizer, Variable


def generate_qap_instance(n: int, seed: int = 0) -> tuple[np.ndarray, np.ndarray]:
    """ランダムなQAPインスタンス（フロー行列と距離行列）を生成する。"""
    rng = np.random.default_rng(seed)
    # フロー行列（施設間の物量）
    flow = rng.integers(0, 10, size=(n, n))
    np.fill_diagonal(flow, 0)
    # 距離行列（拠点間の距離）
    locations = rng.uniform(0, 100, size=(n, 2))
    dist = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            dist[i, j] = np.sqrt(np.sum((locations[i] - locations[j]) ** 2))
    return flow, dist


def qap_cost(flow: np.ndarray, dist: np.ndarray, labels: list[str], assignment: list) -> float:
    """QAPの目的関数値を計算する。sum_{i,j} flow[i,j] * dist[p(i), p(j)]"""
    n = len(assignment)
    label_to_idx = {label: i for i, label in enumerate(labels)}
    cost = 0.0
    for i in range(n):
        for j in range(n):
            li = label_to_idx[assignment[i]]
            lj = label_to_idx[assignment[j]]
            cost += flow[i, j] * dist[li, lj]
    return cost


def generate_permutations(labels: list[str], n_samples: int, seed: int = 0) -> list[list]:
    """ランダムな順列（制約充足解）を生成する。"""
    rng = np.random.default_rng(seed)
    n = len(labels)
    perms = []
    for _ in range(n_samples):
        indices = rng.permutation(n)
        perm = [labels[i] for i in indices]
        perms.append(perm)
    return perms


def main():
    n = 6
    labels = [f"L{i}" for i in range(n)]

    # 1. QAPインスタンスの生成
    flow, dist = generate_qap_instance(n, seed=42)
    print(f"施設数: {n}, 拠点: {labels}")
    print(f"フロー行列:\n{flow}")
    print(f"距離行列:\n{np.round(dist, 1)}")

    # 2. 変数空間の定義（カテゴリ順列）
    var = Variable(length=n, var_type="category", labels=labels)

    # 3. 目的関数
    def objective(solution):
        return qap_cost(flow, dist, labels, solution)

    # 4. AEの学習
    ae_solutions = generate_permutations(labels, n_samples=1000, seed=0)
    ae = AEBuilder(var, latent_dim=8, seed=42)
    ae.train(ae_solutions, epochs=1000)
    print(f"\nAE学習完了: {ae}")

    # 5. 最適化の初期データ
    initial_solutions = generate_permutations(labels, n_samples=20, seed=1)
    initial_values = [objective(sol) for sol in initial_solutions]
    print(f"初期解数: {len(initial_solutions)}")
    print(f"初期ベストコスト: {min(initial_values):.2f}")

    # 6. 最適化
    token = "YOUR_API_TOKEN"
    solver = DWaveSolver(api_token=token)

    optimizer = Optimizer(var, ae, objective, solver, num_samples_per_iter=1)
    optimizer.add_initial_data(initial_solutions, initial_values)
    optimizer.optimize(num_iterations=5)

    # 7. 結果
    print(f"\n=== 結果 ===")
    print(f"最終ベストコスト: {optimizer.best_value:.2f}")
    print(f"ベスト割り当て:   {optimizer.best_solution}")
    print(f"評価回数:         {len(optimizer.trials)}")


if __name__ == "__main__":
    main()
