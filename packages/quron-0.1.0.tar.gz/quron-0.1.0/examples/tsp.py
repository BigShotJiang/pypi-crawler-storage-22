"""
TSP (Traveling Salesman Problem) example using Quron.

N都市のTSPをquronで解く。
解は都市の訪問順序（整数順列）で表現する。

"""

import os

import numpy as np
from dotenv import load_dotenv

load_dotenv()

from quron import AEBuilder, DWaveSolver, Optimizer, Variable


def generate_cities(n_cities: int, seed: int = 0) -> np.ndarray:
    """ランダムにN都市の2D座標を生成する。"""
    rng = np.random.default_rng(seed)
    return rng.uniform(0, 100, size=(n_cities, 2))


def tour_distance(cities: np.ndarray, tour: list) -> float:
    """巡回路の総距離を計算する（最後に出発地へ戻る）。"""
    total = 0.0
    n = len(tour)
    for i in range(n):
        c1 = cities[tour[i]]
        c2 = cities[tour[(i + 1) % n]]
        total += np.sqrt((c1[0] - c2[0]) ** 2 + (c1[1] - c2[1]) ** 2)
    return total


def generate_permutations(n_cities: int, n_samples: int, seed: int = 0) -> list[list]:
    """ランダムな順列（制約充足解）を生成する。"""
    rng = np.random.default_rng(seed)
    perms = []
    for _ in range(n_samples):
        perm = rng.permutation(n_cities).tolist()
        perms.append(perm)
    return perms


def main():
    n_cities = 6

    # 1. 都市の生成
    cities = generate_cities(n_cities, seed=42)
    print(f"都市数: {n_cities}")
    for i, (x, y) in enumerate(cities):
        print(f"  都市{i}: ({x:.1f}, {y:.1f})")

    # 2. 変数空間の定義（順列 = 長さN, 各要素 0〜N-1）
    var = Variable(length=n_cities, var_type="integer", min_value=0, max_value=n_cities - 1)

    # 3. 目的関数
    def objective(solution):
        return tour_distance(cities, solution)

    # 4. AEの学習
    ae_solutions = generate_permutations(n_cities, n_samples=1000, seed=0)
    ae = AEBuilder(var, latent_dim=8, seed=42)
    ae.train(ae_solutions, epochs=1000)
    print(f"\nAE学習完了: {ae}")

    # 5. 最適化の初期データ
    initial_solutions = generate_permutations(n_cities, n_samples=20, seed=1)
    initial_values = [objective(sol) for sol in initial_solutions]
    print(f"初期解数: {len(initial_solutions)}")
    print(f"初期ベスト距離: {min(initial_values):.2f}")

    # 6. 最適化
    token = "YOUR_API_TOKEN"
    solver = DWaveSolver(api_token=token)

    optimizer = Optimizer(var, ae, objective, solver, num_samples_per_iter=1)
    optimizer.add_initial_data(initial_solutions, initial_values)
    optimizer.optimize(num_iterations=5)

    # 7. 結果
    print(f"\n=== 結果 ===")
    print(f"最終ベスト距離: {optimizer.best_value:.2f}")
    print(f"ベスト巡回路:   {optimizer.best_solution}")
    print(f"評価回数:       {len(optimizer.trials)}")


if __name__ == "__main__":
    main()
