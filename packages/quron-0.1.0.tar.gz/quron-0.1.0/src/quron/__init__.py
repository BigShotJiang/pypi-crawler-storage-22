"""
Quron: Binary Autoencoder-based QUBO optimization library.

This library provides tools for solving combinatorial optimization problems
using a surrogate-based approach with:
- Autoencoder (AE) for compressing solutions to binary latent vectors
- Factorization Machine (FM) for learning objective function surrogates
- QUBO solvers (Amplify, D-Wave) for optimization

Basic usage:
    >>> from quron import Variable, AEBuilder, Optimizer, AmplifySolver
    >>>
    >>> # Define solution space
    >>> space = Variable(length=10, var_type="integer",
    ...                               min_value=0, max_value=9)
    >>>
    >>> # Build and train autoencoder
    >>> builder = AEBuilder(space, latent_dim=16)
    >>> builder.train(initial_solutions)
    >>>
    >>> # Setup optimizer
    >>> solver = AmplifySolver(token="your-token")
    >>> optimizer = Optimizer(space, builder, objective_function, solver)
    >>>
    >>> # Run optimization
    >>> optimizer.add_initial_data(initial_solutions)
    >>> optimizer.optimize(num_iterations=10)
    >>> print(optimizer.best_solution, optimizer.best_value)
"""

from .spaces import Variable
from .ae import AEBuilder
from .solver import Solver, AmplifySolver, DWaveSolver
from .optimize import Optimizer

__version__ = "0.1.0"

__all__ = [
    "Variable",
    "AEBuilder",
    "Solver",
    "AmplifySolver",
    "DWaveSolver",
    "Optimizer",
]
