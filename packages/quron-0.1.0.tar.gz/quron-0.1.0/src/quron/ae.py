"""
Autoencoder for compressing discrete solutions to binary latent vectors.

RNN-based autoencoder with GRU encoder/decoder and binary latent layer.
"""

from typing import Iterable, Tuple, Dict
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

from .spaces import Variable


# =============================================================================
# Layer Components
# =============================================================================

class _OneHotEmbedding(nn.Module):
    """One-hot embedding layer."""

    def __init__(self, vocab_size: int):
        super().__init__()
        self.vocab_size = vocab_size

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: [batch_size, sequence_length]
        Returns:
            [batch_size, sequence_length, vocab_size]
        """
        return nn.functional.one_hot(x.long(), num_classes=self.vocab_size).float()


class _RNNEncoder(nn.Module):
    """GRU-based RNN encoder."""

    def __init__(self, input_size: int, hidden_size: int, num_layers: int, dropout: float = 0.1):
        super().__init__()
        self.gru = nn.GRU(
            input_size, hidden_size, num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            x: [batch_size, sequence_length, input_size]
        Returns:
            outputs: [batch_size, sequence_length, hidden_size]
            hidden_state: [batch_size, hidden_size] (last layer's hidden state)
        """
        outputs, state = self.gru(x)
        outputs = self.dropout(outputs)
        hidden_state = state[-1]  # Last layer's hidden state
        return outputs, hidden_state


class _LatentLayer(nn.Module):
    """Binary latent layer with straight-through estimator."""

    def __init__(self, hidden_size: int, latent_size: int):
        super().__init__()
        self.linear = nn.Linear(hidden_size, latent_size)

    def forward(self, state: torch.Tensor, deterministic: bool = False) -> torch.Tensor:
        """
        Args:
            state: [batch_size, hidden_size]
            deterministic: If True, use threshold. If False, use Bernoulli sampling.
        Returns:
            latent: [batch_size, latent_size] binary values
        """
        logits = self.linear(state)
        prob = torch.sigmoid(logits)

        if deterministic:
            latent = (prob > 0.5).float()
        else:
            latent = torch.bernoulli(prob)

        # Straight-through estimator: forward uses binary, backward uses prob
        latent = latent + prob - prob.detach()

        return latent


class _RNNDecoder(nn.Module):
    """GRU-based RNN decoder."""

    def __init__(self, latent_size: int, hidden_size: int, output_size: int,
                 sequence_length: int, num_layers: int, dropout: float = 0.1):
        super().__init__()
        self.latent_size = latent_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.sequence_length = sequence_length
        self.num_layers = num_layers

        self.gru = nn.GRU(
            output_size, hidden_size, num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0
        )
        self.projection = nn.Linear(hidden_size, output_size, bias=False)

        # Latent to initial hidden state
        self.latent_to_hidden = nn.ModuleList([
            nn.Linear(latent_size, hidden_size) for _ in range(num_layers)
        ])

    def forward(self, latent: torch.Tensor, target: torch.Tensor = None,
                use_teacher_forcing: bool = True) -> torch.Tensor:
        """
        Args:
            latent: [batch_size, latent_size]
            target: [batch_size, sequence_length, output_size] (for teacher forcing)
            use_teacher_forcing: Whether to use teacher forcing
        Returns:
            outputs: [batch_size, sequence_length, output_size]
        """
        batch_size = latent.size(0)
        device = latent.device

        # Initialize hidden state from latent
        hidden = torch.stack([
            self.latent_to_hidden[i](latent) for i in range(self.num_layers)
        ])  # [num_layers, batch_size, hidden_size]

        # Initialize decoder input (zeros)
        decoder_input = torch.zeros(batch_size, 1, self.output_size, device=device)

        outputs = []
        for t in range(self.sequence_length):
            output, hidden = self.gru(decoder_input, hidden)
            output = self.projection(output)  # [batch_size, 1, output_size]
            outputs.append(output)

            if use_teacher_forcing and target is not None:
                decoder_input = target[:, t:t+1, :]
            else:
                # Argmax for next input
                binary_output = (output == output.max(dim=2, keepdim=True).values).float()
                decoder_input = binary_output

        return torch.cat(outputs, dim=1)  # [batch_size, sequence_length, output_size]


class _OneHotAutoEncoder(nn.Module):
    """Complete RNN-based autoencoder for one-hot encoded sequences."""

    def __init__(self, vocab_size: int, sequence_length: int, hidden_size: int,
                 latent_size: int, num_layers: int, dropout: float = 0.1):
        super().__init__()
        self.vocab_size = vocab_size
        self.sequence_length = sequence_length

        self.embedding = _OneHotEmbedding(vocab_size)
        self.encoder = _RNNEncoder(vocab_size, hidden_size, num_layers, dropout)
        self.latent_layer = _LatentLayer(hidden_size, latent_size)
        self.decoder = _RNNDecoder(latent_size, hidden_size, vocab_size,
                                   sequence_length, num_layers, dropout)

    def forward(self, x: torch.Tensor, use_teacher_forcing: bool = True
                ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            x: [batch_size, sequence_length] integer indices
            use_teacher_forcing: Whether to use teacher forcing in decoder
        Returns:
            outputs: [batch_size, sequence_length, vocab_size]
            latent: [batch_size, latent_size]
        """
        embedded = self.embedding(x)  # [batch_size, seq_len, vocab_size]
        _, hidden_state = self.encoder(embedded)
        latent = self.latent_layer(hidden_state, deterministic=False)

        target = embedded if use_teacher_forcing else None
        outputs = self.decoder(latent, target, use_teacher_forcing)

        return outputs, latent

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        """Encode input to binary latent vector (deterministic)."""
        embedded = self.embedding(x)
        _, hidden_state = self.encoder(embedded)
        latent = self.latent_layer(hidden_state, deterministic=True)
        return latent

    def decode(self, latent: torch.Tensor) -> torch.Tensor:
        """Decode latent vector to output."""
        outputs = self.decoder(latent, target=None, use_teacher_forcing=False)
        return outputs


# =============================================================================
# AEBuilder (Public API)
# =============================================================================

class AEBuilder:
    """
    Builds and trains an RNN Autoencoder to compress discrete solutions
    into binary latent vectors.

    Parameters
    ----------
    space : Variable
        The solution space definition
    latent_dim : int | None
        Dimension of the binary latent space. If None, automatically computed
        as 50% of the theoretical bits needed: `max(4, length * log2(vocab_size) // 2)`.
    seed : int | None
        Random seed for reproducibility.
    hidden_dim : int
        Hidden layer dimension for the neural network.
    num_layers : int
        Number of GRU layers.
    device : str | None
        Device to use ('cpu', 'cuda', etc.). If None, auto-detected.

    Attributes
    ----------
    space : Variable
        The solution space
    latent_dim : int
        Dimension of the binary latent vectors
    model : _OneHotAutoEncoder
        The autoencoder model
    """

    def __init__(
        self,
        space: Variable,
        latent_dim: int | None = None,
        seed: int | None = None,
        *,
        hidden_dim: int = 64,
        num_layers: int = 2,
        device: str | None = None,
    ):
        self.space = space
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers

        # Set random seed
        if seed is not None:
            torch.manual_seed(seed)
            np.random.seed(seed)

        # Auto-compute latent_dim if not provided
        # Formula: 50% of the theoretical bits needed to represent the solution space
        # bits_needed = length * log2(vocab_size)
        if latent_dim is None:
            vocab_size = space.vocab_size
            length = space.length
            latent_dim = max(4, int(length * np.log2(vocab_size)) // 2)

        self.latent_dim = latent_dim

        # Device setup
        if device is None:
            self.device = self._auto_select_device()
        else:
            self.device = torch.device(device)

        # Build model
        self.model = _OneHotAutoEncoder(
            vocab_size=space.vocab_size,
            sequence_length=space.length,
            hidden_size=hidden_dim,
            latent_size=latent_dim,
            num_layers=num_layers,
        )
        self.model.to(self.device)

        self._trained = False

    def _auto_select_device(self) -> torch.device:
        """
        Auto-select the best available device.

        Supports CUDA (NVIDIA) and MPS (Apple Silicon).
        """
        if torch.cuda.is_available():
            return torch.device("cuda")
        if torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")

    def _solutions_to_indices(self, solutions: list[list]) -> np.ndarray:
        """Convert solutions to internal ID indices."""
        n_samples = len(solutions)
        indices = np.zeros((n_samples, self.space.length), dtype=np.int64)

        for i, sol in enumerate(solutions):
            ids = self.space.to_internal_ids(sol)
            indices[i] = ids

        return indices

    def _logits_to_solutions(self, logits: np.ndarray) -> list[list]:
        """Convert decoder output logits to solutions."""
        n_samples = logits.shape[0]
        solutions = []

        for i in range(n_samples):
            ids = []
            for pos in range(self.space.length):
                id_val = int(np.argmax(logits[i, pos, :]))
                ids.append(id_val)
            solution = self.space.from_internal_ids(ids)
            solutions.append(solution)

        return solutions

    def train(
        self,
        solutions: Iterable[list],
        *,
        epochs: int = 2000,
        batch_size: int | None = None,
        learning_rate: float = 1e-3,
        weight_decay: float = 1e-5,
        lr_min: float = 0.0,
    ) -> None:
        """
        Train the autoencoder on a collection of solutions.

        Parameters
        ----------
        solutions : Iterable[list]
            Training solutions from the solution space
        epochs : int
            Number of training epochs. Default is 2000.
        batch_size : int | None
            Training batch size. If None, automatically set based on dataset size:
            max(32, len(solutions) // 30). Default is None.
        learning_rate : float
            Learning rate for the AdamW optimizer. Default is 1e-3.
        weight_decay : float
            Weight decay (L2 regularization) coefficient. Default is 1e-5.
        lr_min : float
            Minimum learning rate for CosineAnnealingLR scheduler. Default is 0.0.

        Raises
        ------
        ValueError
            If no valid solutions are provided
        """
        solutions = list(solutions)
        if len(solutions) == 0:
            raise ValueError("No solutions provided for training")

        # Validate solutions
        for sol in solutions:
            if not self.space.validate(sol):
                raise ValueError(f"Invalid solution for the space: {sol}")

        # Convert to indices
        X = self._solutions_to_indices(solutions)
        X_tensor = torch.tensor(X, dtype=torch.long)

        # Auto-compute batch_size if not provided
        if batch_size is None:
            batch_size = max(32, len(solutions) // 30)

        # Create dataset and dataloader
        dataset = TensorDataset(X_tensor)
        dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

        # Setup optimizer with AdamW
        optimizer = optim.AdamW(
            self.model.parameters(),
            lr=learning_rate,
            weight_decay=weight_decay,
        )

        # Learning rate scheduler
        scheduler = optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=epochs, eta_min=lr_min
        )

        # Mixed precision training (AMP)
        use_amp = self.device.type == "cuda"
        scaler = torch.amp.GradScaler("cuda") if use_amp else None

        # Training loop
        self.model.train()

        for epoch in range(epochs):
            total_loss = 0.0
            for (batch_x,) in dataloader:
                batch_x = batch_x.to(self.device)

                optimizer.zero_grad(set_to_none=True)

                if use_amp:
                    with torch.amp.autocast("cuda"):
                        outputs, _ = self.model(batch_x, use_teacher_forcing=True)
                        loss = self._compute_mse_loss(outputs, batch_x)
                    scaler.scale(loss).backward()
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    outputs, _ = self.model(batch_x, use_teacher_forcing=True)
                    loss = self._compute_mse_loss(outputs, batch_x)
                    loss.backward()
                    optimizer.step()

                total_loss += loss.item()

            scheduler.step()

            if (epoch + 1) % 10 == 0:
                avg_loss = total_loss / len(dataloader)
                current_lr = scheduler.get_last_lr()[0]
                print(f"Epoch {epoch+1}/{epochs}, Loss: {avg_loss:.6f}, LR: {current_lr:.2e}")

        self._trained = True

    def _compute_mse_loss(
        self, outputs: torch.Tensor, targets: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute MSE loss between softmax probabilities and one-hot targets.

        Parameters
        ----------
        outputs : torch.Tensor
            Model output logits of shape [batch, seq_len, vocab_size]
        targets : torch.Tensor
            Target indices of shape [batch, seq_len]

        Returns
        -------
        torch.Tensor
            MSE loss value
        """
        probs = outputs.softmax(dim=-1)  # [batch, seq_len, vocab_size]
        target_onehot = nn.functional.one_hot(
            targets, num_classes=self.space.vocab_size
        ).float()  # [batch, seq_len, vocab_size]
        return nn.functional.mse_loss(probs, target_onehot)

    def encode(self, solutions: Iterable[list]) -> np.ndarray:
        """
        Encode solutions to binary latent vectors.

        Parameters
        ----------
        solutions : Iterable[list]
            Solutions to encode

        Returns
        -------
        np.ndarray
            Binary latent vectors of shape (n_samples, latent_dim) with values in {0, 1}
        """
        if not self._trained:
            raise RuntimeError("Encoder has not been trained. Call train() first.")

        solutions = list(solutions)
        if len(solutions) == 0:
            return np.zeros((0, self.latent_dim), dtype=np.int32)

        for sol in solutions:
            if not self.space.validate(sol):
                raise ValueError(f"Invalid solution: {sol}")

        X = self._solutions_to_indices(solutions)
        X_tensor = torch.tensor(X, dtype=torch.long).to(self.device)

        self.model.eval()
        with torch.no_grad():
            latent = self.model.encode(X_tensor)
            binary_latent = (latent >= 0.5).cpu().numpy().astype(np.int32)

        return binary_latent

    def decode(self, latents: np.ndarray) -> list[list]:
        """
        Decode binary latent vectors back to solutions.

        Parameters
        ----------
        latents : np.ndarray
            Binary latent vectors of shape (n_samples, latent_dim)

        Returns
        -------
        list[list]
            Decoded solutions
        """
        if not self._trained:
            raise RuntimeError("Decoder has not been trained. Call train() first.")

        if latents.shape[1] != self.latent_dim:
            raise ValueError(
                f"Expected latent dimension {self.latent_dim}, got {latents.shape[1]}"
            )

        if len(latents) == 0:
            return []

        latents_tensor = torch.tensor(latents, dtype=torch.float32).to(self.device)

        self.model.eval()
        with torch.no_grad():
            outputs = self.model.decode(latents_tensor)
            outputs = outputs.cpu().numpy()

        solutions = self._logits_to_solutions(outputs)
        return solutions

    def save(self, path: str) -> None:
        """Save the trained autoencoder to a file."""
        if not self._trained:
            raise RuntimeError("Cannot save untrained model")

        state = {
            "model_state": self.model.state_dict(),
            "latent_dim": self.latent_dim,
            "space_config": {
                "length": self.space.length,
                "var_type": self.space.var_type,
                "min_value": self.space.min_value,
                "max_value": self.space.max_value,
                "labels": self.space.labels,
            },
            "hidden_dim": self.hidden_dim,
            "num_layers": self.num_layers,
        }
        torch.save(state, path)

    def load(self, path: str) -> None:
        """Load a trained autoencoder from a file."""
        state = torch.load(path, map_location=self.device)

        if state["latent_dim"] != self.latent_dim:
            raise ValueError("Loaded model has incompatible latent dimension")

        self.model.load_state_dict(state["model_state"])
        self._trained = True

    def __repr__(self) -> str:
        """String representation."""
        status = "trained" if self._trained else "untrained"
        return (f"AEBuilder(latent_dim={self.latent_dim}, "
                f"hidden_dim={self.hidden_dim}, "
                f"status='{status}')")
