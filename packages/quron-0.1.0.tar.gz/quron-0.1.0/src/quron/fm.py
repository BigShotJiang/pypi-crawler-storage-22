"""
Factorization Machine for surrogate modeling and QUBO conversion.

This module is INTERNAL API - not exposed to end users.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset


class FMModel(nn.Module):
    """
    Factorization Machine for predicting objective values from binary latent vectors.

    This is an INTERNAL API class used by the Optimizer. It learns a surrogate
    model that approximates: latent_binary -> objective_value

    The FM can be converted to a QUBO matrix for optimization on quantum annealers
    or other QUBO solvers.

    Parameters
    ----------
    num_features : int
        Number of binary features (latent dimension)
    k : int
        Dimension of factorization (embedding dimension for interactions)
    l2_reg : float
        L2 regularization coefficient

    Attributes
    ----------
    w0 : nn.Parameter
        Global bias term
    w : nn.Parameter
        Linear weights of shape (num_features,)
    V : nn.Parameter
        Factorization matrix of shape (num_features, k) for interactions
    """

    # Thresholds for automatic GPU usage
    _GPU_THRESHOLD_FEATURES = 500
    _GPU_THRESHOLD_SAMPLES = 500

    def __init__(
        self,
        num_features: int,
        k: int = 16,
        l2_reg: float = 0.0,
    ):
        super().__init__()

        if num_features <= 0:
            raise ValueError(f"num_features must be positive, got {num_features}")
        if k <= 0:
            raise ValueError(f"k must be positive, got {k}")

        self.num_features = num_features
        self.k = k
        self.l2_reg = l2_reg

        # Parameters
        self.w0 = nn.Parameter(torch.zeros(1))
        self.w = nn.Parameter(torch.randn(num_features) * 0.01)
        self.V = nn.Parameter(torch.randn(num_features, k) * 0.01)

        self._fitted = False
        self._device = torch.device("cpu")

    def _select_device(self, n_samples: int) -> torch.device:
        """
        Select device based on problem size.

        Uses GPU if available and problem is large enough to benefit from it.
        Supports CUDA (NVIDIA) and MPS (Apple Silicon).
        """
        is_large_problem = (
            self.num_features > self._GPU_THRESHOLD_FEATURES
            and n_samples > self._GPU_THRESHOLD_SAMPLES
        )

        if not is_large_problem:
            return torch.device("cpu")

        # Check available GPU backends
        if torch.cuda.is_available():
            return torch.device("cuda")
        if torch.backends.mps.is_available():
            return torch.device("mps")

        return torch.device("cpu")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass of the Factorization Machine.

        Parameters
        ----------
        x : torch.Tensor
            Input features of shape (batch_size, num_features)

        Returns
        -------
        torch.Tensor
            Predictions of shape (batch_size,)
        """
        # Linear term: w0 + sum(w_i * x_i)
        linear = self.w0 + torch.matmul(x, self.w)

        # Interaction term: 0.5 * sum_f ((sum_i v_if * x_i)^2 - sum_i (v_if * x_i)^2)
        # This is the efficient FM formulation
        interactions = 0.5 * torch.sum(
            torch.pow(torch.matmul(x, self.V), 2) -
            torch.matmul(torch.pow(x, 2), torch.pow(self.V, 2)),
            dim=1
        )

        return linear + interactions

    def fit(
        self,
        latents: np.ndarray,
        values: np.ndarray,
        *,
        epochs: int = 100,
        batch_size: int = 64,
        learning_rate: float = 1e-3,
    ) -> None:
        """
        Train the Factorization Machine on latent vectors and objective values.

        Parameters
        ----------
        latents : np.ndarray
            Binary latent vectors of shape (n_samples, num_features)
        values : np.ndarray
            Objective values of shape (n_samples,)
        epochs : int
            Number of training epochs
        batch_size : int
            Training batch size
        learning_rate : float
            Learning rate for optimizer

        Raises
        ------
        ValueError
            If input dimensions are invalid or don't match
        """
        if len(latents) == 0:
            raise ValueError("No training data provided")
        if len(latents) != len(values):
            raise ValueError(
                f"Mismatch: {len(latents)} latent vectors but {len(values)} values"
            )
        if latents.shape[1] != self.num_features:
            raise ValueError(
                f"Expected {self.num_features} features, got {latents.shape[1]}"
            )

        # Select device based on problem size
        self._device = self._select_device(len(latents))
        self.to(self._device)

        # Convert to tensors and move to device
        X = torch.tensor(latents, dtype=torch.float32, device=self._device)
        y = torch.tensor(values, dtype=torch.float32, device=self._device)

        # Create dataset and dataloader
        dataset = TensorDataset(X, y)
        dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

        # Setup optimizer
        optimizer = optim.AdamW(self.parameters(), lr=learning_rate)
        criterion = nn.MSELoss()

        # Training loop
        self.train()
        for epoch in range(epochs):
            total_loss = 0.0
            for batch_x, batch_y in dataloader:
                # Forward pass
                predictions = self(batch_x)
                loss = criterion(predictions, batch_y)

                # Add L2 regularization
                if self.l2_reg > 0:
                    l2_penalty = (
                        self.l2_reg * (torch.sum(self.w ** 2) + torch.sum(self.V ** 2))
                    )
                    loss = loss + l2_penalty

                # Backward pass
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                total_loss += loss.item()

            # Optional: print progress
            if (epoch + 1) % 20 == 0:
                avg_loss = total_loss / len(dataloader)
                print(f"Epoch {epoch+1}/{epochs}, Loss: {avg_loss:.6f}")

        self._fitted = True

    def predict(self, latents: np.ndarray) -> np.ndarray:
        """
        Predict objective values for given latent vectors.

        Parameters
        ----------
        latents : np.ndarray
            Binary latent vectors of shape (n_samples, num_features)

        Returns
        -------
        np.ndarray
            Predicted objective values of shape (n_samples,)

        Raises
        ------
        RuntimeError
            If the model has not been fitted
        ValueError
            If input dimensions are invalid
        """
        if not self._fitted:
            raise RuntimeError("Model has not been fitted. Call fit() first.")

        if latents.shape[1] != self.num_features:
            raise ValueError(
                f"Expected {self.num_features} features, got {latents.shape[1]}"
            )

        X = torch.tensor(latents, dtype=torch.float32, device=self._device)

        self.eval()
        with torch.no_grad():
            predictions = self(X)

        return predictions.cpu().numpy()

    def to_qubo(self) -> tuple[np.ndarray, float]:
        """
        Convert the trained FM to a QUBO formulation.

        The FM model is: f(x) = w0 + sum(w_i * x_i) + interactions(x)
        where interactions are computed from the factorization matrix V.

        For QUBO: minimize x^T Q x + c
        We construct Q such that the quadratic form approximates the FM.

        Returns
        -------
        Q : np.ndarray
            QUBO matrix of shape (num_features, num_features), symmetric
        c : float
            Constant offset term

        Raises
        ------
        RuntimeError
            If the model has not been fitted

        Notes
        -----
        The QUBO formulation is:
        - Diagonal Q[i,i] contains linear term w[i]
        - Off-diagonal Q[i,j] contains pairwise interaction from V
        - c contains the global bias w0
        """
        if not self._fitted:
            raise RuntimeError("Model has not been fitted. Call fit() first.")

        # Initialize QUBO matrix
        Q = np.zeros((self.num_features, self.num_features), dtype=np.float64)

        # Extract parameters (move to CPU for numpy conversion)
        w = self.w.detach().cpu().numpy()
        V = self.V.detach().cpu().numpy()  # shape: (num_features, k)

        # Linear terms go to diagonal
        for i in range(self.num_features):
            Q[i, i] = w[i]

        # Pairwise interactions from factorization
        # The FM interaction term can be expanded to pairwise form:
        # For features i, j: sum_f (v_if * v_jf) * x_i * x_j
        for i in range(self.num_features):
            for j in range(i + 1, self.num_features):
                interaction = np.dot(V[i], V[j])  # sum over k
                Q[i, j] = interaction
                Q[j, i] = interaction  # Keep symmetric

        # Constant term
        c = self.w0.item()

        return Q, c

    def __repr__(self) -> str:
        """String representation."""
        status = "fitted" if self._fitted else "unfitted"
        return (f"FMModel(num_features={self.num_features}, "
                f"k={self.k}, "
                f"l2_reg={self.l2_reg}, "
                f"status='{status}')")
