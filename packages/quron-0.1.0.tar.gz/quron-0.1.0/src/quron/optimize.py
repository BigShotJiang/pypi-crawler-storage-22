"""
Optimization loop integrating AE, FM, and Solver.
"""

from collections.abc import Callable
from typing import Any

import numpy as np

from .spaces import Variable
from .ae import AEBuilder
from .fm import FMModel
from .solver import Solver


class Optimizer:
    """
    High-level optimizer that integrates AE, FM, and Solver for QUBO-based optimization.

    This class implements the main optimization loop:
    1. Encode solutions to binary latent vectors using AE
    2. Train FM to predict objective values from latent vectors
    3. Convert FM to QUBO and solve using the provided Solver
    4. Decode solutions and evaluate with the objective function
    5. Repeat for the specified number of iterations

    Parameters
    ----------
    space : Variable
        The solution space definition.
    builder : AEBuilder
        Pre-trained autoencoder builder for encoding/decoding solutions.
    objective : Callable[[list], float]
        Objective function to minimize. Takes a solution and returns a float.
    solver : Solver
        QUBO solver (e.g., AmplifySolver, DWaveSolver).
    num_samples_per_iter : int
        Number of samples to generate per iteration from the solver.
    random_state : int | None
        Random seed for reproducibility.

    Examples
    --------
    >>> space = Variable(length=5, var_type="integer",
    ...                               min_value=0, max_value=9)
    >>> builder = AEBuilder(space, latent_dim=8)
    >>> # Train builder with initial solutions...
    >>> def objective(sol):
    ...     return sum(sol)  # Minimize sum
    >>> solver = AmplifySolver(token="your-token")
    >>> opt = Optimizer(space, builder, objective, solver)
    >>> opt.add_initial_data(initial_solutions)
    >>> opt.optimize(num_iterations=10)
    >>> print(opt.best_solution, opt.best_value)
    """

    def __init__(
        self,
        space: Variable,
        builder: AEBuilder,
        objective: Callable[[list], float],
        solver: Solver,
        *,
        num_samples_per_iter: int = 1,
        random_state: int | None = None,
    ):
        if num_samples_per_iter <= 0:
            raise ValueError(
                f"num_samples_per_iter must be positive, got {num_samples_per_iter}"
            )

        self.space = space
        self.builder = builder
        self.objective = objective
        self.solver = solver
        self.num_samples_per_iter = num_samples_per_iter
        self.random_state = random_state

        if random_state is not None:
            np.random.seed(random_state)

        # Internal state
        self._solutions: list[list] = []
        self._values: list[float] = []
        self._latents: list[np.ndarray] = []
        self._iterations: list[int] = []
        self._current_iteration = 0

        # FM model (created during optimization)
        self._fm: FMModel | None = None

        # FM configuration (can be customized via configure_fm)
        self._fm_k: int | None = None  # None means auto: min(10, latent_dim)
        self._fm_epochs: int = 1000
        self._fm_learning_rate: float = 0.1
        self._fm_batch_size: int = 20
        self._fm_l2_reg: float = 0.0

    def configure_fm(
        self,
        *,
        k: int | None = None,
        epochs: int | None = None,
        batch_size: int | None = None,
        learning_rate: float | None = None,
        l2_reg: float | None = None,
    ) -> None:
        """
        Configure the Factorization Machine (FM) surrogate model parameters.

        Call this method before `optimize()` to customize FM behavior.
        Parameters not specified will retain their current values.

        Parameters
        ----------
        k : int | None
            Factorization rank (embedding dimension for interactions).
            Default is `min(10, latent_dim)`. Larger values can capture
            more complex interactions but may overfit on small datasets.
        epochs : int | None
            Number of training epochs per iteration. Default is 1000.
        batch_size : int | None
            Training batch size. Default is 20.
        learning_rate : float | None
            Learning rate for the Adam optimizer. Default is 0.1.
        l2_reg : float | None
            L2 regularization coefficient. Default is 0.0.

        Examples
        --------
        >>> optimizer = Optimizer(space, builder, objective, solver)
        >>> optimizer.configure_fm(k=20, epochs=500)
        >>> optimizer.add_initial_data(solutions)
        >>> optimizer.optimize(num_iterations=10)
        """
        if k is not None:
            if k <= 0:
                raise ValueError(f"k must be positive, got {k}")
            self._fm_k = k
        if epochs is not None:
            if epochs <= 0:
                raise ValueError(f"epochs must be positive, got {epochs}")
            self._fm_epochs = epochs
        if batch_size is not None:
            if batch_size <= 0:
                raise ValueError(f"batch_size must be positive, got {batch_size}")
            self._fm_batch_size = batch_size
        if learning_rate is not None:
            if learning_rate <= 0:
                raise ValueError(f"learning_rate must be positive, got {learning_rate}")
            self._fm_learning_rate = learning_rate
        if l2_reg is not None:
            if l2_reg < 0:
                raise ValueError(f"l2_reg must be non-negative, got {l2_reg}")
            self._fm_l2_reg = l2_reg

    def add_initial_data(
        self,
        solutions: list[list],
        values: list[float] | None = None,
    ) -> None:
        """
        Add initial solutions and optionally their objective values.

        If values are not provided, the objective function will be called
        to evaluate each solution.

        Parameters
        ----------
        solutions : list[list]
            List of initial solutions.
        values : list[float] | None
            Objective values for each solution. If None, computed using
            the objective function.

        Raises
        ------
        ValueError
            If solutions is empty or values length doesn't match.
        """
        if len(solutions) == 0:
            raise ValueError("solutions must not be empty")

        if values is not None and len(values) != len(solutions):
            raise ValueError(
                f"Length mismatch: {len(solutions)} solutions but {len(values)} values"
            )

        # Validate and add solutions
        for i, sol in enumerate(solutions):
            if not self.space.validate(sol):
                raise ValueError(f"Invalid solution at index {i}: {sol}")

            self._solutions.append(list(sol))

            if values is not None:
                self._values.append(float(values[i]))
            else:
                self._values.append(float(self.objective(sol)))

            self._iterations.append(0)  # Initial data is iteration 0

    def optimize(self, num_iterations: int) -> None:
        """
        Run the optimization loop for the specified number of iterations.

        Each iteration:
        1. Encode all solutions to latent space
        2. Train FM on (latent, value) pairs
        3. Convert FM to QUBO
        4. Solve QUBO to get new latent vectors
        5. Decode latent vectors to solutions
        6. Evaluate solutions with objective function
        7. Add new (solution, value) pairs to the dataset

        Parameters
        ----------
        num_iterations : int
            Number of optimization iterations to run.

        Raises
        ------
        ValueError
            If num_iterations is not positive.
        RuntimeError
            If no initial data has been added.
        """
        if num_iterations <= 0:
            raise ValueError(f"num_iterations must be positive, got {num_iterations}")

        if len(self._solutions) == 0:
            raise RuntimeError(
                "No initial data. Call add_initial_data() before optimize()."
            )

        for iteration in range(1, num_iterations + 1):
            self._current_iteration = iteration
            self._run_iteration()

    def _run_iteration(self) -> None:
        """Run a single optimization iteration."""
        # Step 1: Encode all solutions to latent space
        latents = self.builder.encode(self._solutions)
        self._latents = [latents[i] for i in range(len(latents))]

        # Step 2: Train FM on (latent, value) pairs
        latent_array = np.array(self._latents)
        value_array = np.array(self._values)

        latent_dim = latent_array.shape[1]

        # Create FM only on first iteration, reuse afterwards
        if self._fm is None:
            fm_k = self._fm_k if self._fm_k is not None else min(10, latent_dim)
            self._fm = FMModel(num_features=latent_dim, k=fm_k, l2_reg=self._fm_l2_reg)

        # Re-train FM with all accumulated data
        self._fm.fit(
            latent_array,
            value_array,
            epochs=self._fm_epochs,
            batch_size=min(self._fm_batch_size, len(self._solutions)),
            learning_rate=self._fm_learning_rate,
        )

        # Step 3: Convert FM to QUBO
        Q, c = self._fm.to_qubo()

        # Step 4: Solve QUBO
        results = self.solver.solve_qubo(
            Q,
            num_reads=self.num_samples_per_iter,
            auto_scale=True,
        )

        # Step 5 & 6: Decode and evaluate new solutions
        for result in results:
            latent = result["sample"].astype(np.float32)

            # Decode latent to solution
            decoded = self.builder.decode(latent.reshape(1, -1))
            if len(decoded) == 0:
                continue

            new_solution = decoded[0]

            # Validate the decoded solution
            # Note: In practice, decode() always returns valid solutions because
            # it uses argmax over the one-hot logits, which always produces valid IDs.
            # This check is kept as a safety guard.
            if not self.space.validate(new_solution):
                continue

            # Check if this solution is already in our dataset
            is_duplicate = any(
                new_solution == existing for existing in self._solutions
            )

            if not is_duplicate:
                # Evaluate with objective function
                new_value = float(self.objective(new_solution))

                # Add to dataset
                self._solutions.append(new_solution)
                self._values.append(new_value)
                self._latents.append(latent)
                self._iterations.append(self._current_iteration)

    @property
    def best_solution(self) -> list:
        """
        Return the best solution found so far.

        Returns
        -------
        list
            The solution with the lowest objective value.

        Raises
        ------
        RuntimeError
            If no solutions have been evaluated.
        """
        if len(self._solutions) == 0:
            raise RuntimeError("No solutions available. Run optimization first.")

        best_idx = int(np.argmin(self._values))
        return self._solutions[best_idx]

    @property
    def best_value(self) -> float:
        """
        Return the best (lowest) objective value found so far.

        Returns
        -------
        float
            The lowest objective value.

        Raises
        ------
        RuntimeError
            If no solutions have been evaluated.
        """
        if len(self._values) == 0:
            raise RuntimeError("No values available. Run optimization first.")

        return float(min(self._values))

    @property
    def trials(self) -> list[dict]:
        """
        Return all evaluated solutions with their metadata.

        Returns
        -------
        list[dict]
            List of trial dictionaries, each containing:
            - "solution": list, the solution
            - "value": float, the objective value
            - "latent": np.ndarray, the latent representation
            - "iteration": int, the iteration when this solution was found
        """
        # Ensure latents are up to date
        if len(self._latents) < len(self._solutions):
            # Encode missing solutions
            latents = self.builder.encode(self._solutions)
            self._latents = [latents[i] for i in range(len(latents))]

        result = []
        for i in range(len(self._solutions)):
            trial = {
                "solution": self._solutions[i],
                "value": self._values[i],
                "latent": self._latents[i] if i < len(self._latents) else None,
                "iteration": self._iterations[i],
            }
            result.append(trial)

        return result

    def __repr__(self) -> str:
        """String representation."""
        n_trials = len(self._solutions)
        best_val = f"{self.best_value:.4f}" if n_trials > 0 else "N/A"
        return (
            f"Optimizer(n_trials={n_trials}, "
            f"best_value={best_val}, "
            f"current_iteration={self._current_iteration})"
        )
