"""
QUBO solver abstraction and implementations.

This module provides an abstract base class for QUBO solvers and concrete
implementations for various backends (Amplify, D-Wave).
"""

from abc import ABC, abstractmethod
from typing import Any

import numpy as np


class Solver(ABC):
    """
    Abstract base class for QUBO solvers.

    A solver takes a QUBO matrix and returns one or more solutions.
    Subclasses must implement the `solve_qubo` method.

    Notes
    -----
    The QUBO problem is: minimize x^T Q x
    where x is a binary vector {0, 1}^n and Q is an n x n matrix.
    """

    @abstractmethod
    def solve_qubo(
        self,
        Q: np.ndarray,
        num_reads: int,
        auto_scale: bool = True,
        **kwargs: Any,
    ) -> list[dict]:
        """
        Solve the QUBO problem.

        Parameters
        ----------
        Q : np.ndarray
            QUBO matrix of shape (n, n). Can be symmetric or upper triangular.
        num_reads : int
            Number of solution samples to return.
        auto_scale : bool
            If True, automatically scale the QUBO coefficients.
        **kwargs : Any
            Additional solver-specific parameters.

        Returns
        -------
        list[dict]
            List of solutions, each containing:
            - "sample": np.ndarray of shape (n,) with binary values {0, 1}
            - "energy": float, the QUBO energy (x^T Q x)

        Raises
        ------
        ValueError
            If Q is not a valid 2D square matrix or num_reads is invalid.
        """
        pass

    def _validate_qubo(self, Q: np.ndarray) -> None:
        """
        Validate the QUBO matrix.

        Parameters
        ----------
        Q : np.ndarray
            QUBO matrix to validate.

        Raises
        ------
        ValueError
            If Q is not a valid 2D square matrix.
        """
        if not isinstance(Q, np.ndarray):
            raise ValueError("Q must be a numpy array")
        if Q.ndim != 2:
            raise ValueError(f"Q must be 2D, got {Q.ndim}D")
        if Q.shape[0] != Q.shape[1]:
            raise ValueError(f"Q must be square, got shape {Q.shape}")
        if Q.shape[0] == 0:
            raise ValueError("Q must not be empty")

    def _compute_energy(self, x: np.ndarray, Q: np.ndarray) -> float:
        """
        Compute the QUBO energy for a given solution.

        Parameters
        ----------
        x : np.ndarray
            Binary solution vector of shape (n,)
        Q : np.ndarray
            QUBO matrix of shape (n, n)

        Returns
        -------
        float
            Energy value x^T Q x
        """
        return float(x @ Q @ x)


class AmplifySolver(Solver):
    """
    QUBO solver using the Fixstars Amplify SDK.

    Parameters
    ----------
    token : str
        Amplify API token.
    time_limit : float | None
        Time limit for solving in milliseconds. Default is 1000ms.
    backend : str | None
        Name of the Amplify backend to use. If None, uses default.
    **kwargs : Any
        Additional configuration parameters passed to the client.

    Examples
    --------
    >>> solver = AmplifySolver(token="your-token", time_limit=5000)
    >>> Q = np.array([[1, -1], [-1, 2]])
    >>> results = solver.solve_qubo(Q, num_reads=5)
    >>> len(results)
    5

    Notes
    -----
    Requires the `amplify` package to be installed:
    ``pip install quron[amplify]``
    """

    def __init__(
        self,
        token: str,
        *,
        time_limit: float | None = None,
        backend: str | None = None,
        **kwargs: Any,
    ):
        if not token:
            raise ValueError("token must be provided")

        self.token = token
        self.time_limit = time_limit if time_limit is not None else 1000.0
        self.backend = backend
        self._extra_config = kwargs

        # Verify amplify is available
        try:
            import amplify  # noqa: F401
        except ImportError:
            raise ImportError(
                "amplify package is required for AmplifySolver. "
                "Install it with: pip install quron[amplify]"
            )

    def solve_qubo(
        self,
        Q: np.ndarray,
        num_reads: int,
        auto_scale: bool = True,
        **kwargs: Any,
    ) -> list[dict]:
        """
        Solve the QUBO problem using Fixstars Amplify.

        Parameters
        ----------
        Q : np.ndarray
            QUBO matrix of shape (n, n).
        num_reads : int
            Number of solution samples to return.
        auto_scale : bool
            If True, automatically scale the QUBO coefficients.
        **kwargs : Any
            Additional solver-specific parameters.

        Returns
        -------
        list[dict]
            List of solutions with "sample" and "energy" keys.

        Raises
        ------
        ValueError
            If inputs are invalid.
        RuntimeError
            If the solver fails to find solutions.
        """
        from amplify import VariableGenerator, Model, FixstarsClient, solve

        self._validate_qubo(Q)
        if num_reads <= 0:
            raise ValueError(f"num_reads must be positive, got {num_reads}")

        n = Q.shape[0]

        # Create binary variables
        gen = VariableGenerator()
        x = gen.array("Binary", n)

        # Build QUBO expression from matrix
        # f(x) = sum_i sum_j Q[i,j] * x[i] * x[j]
        objective = sum(
            Q[i, j] * x[i] * x[j]
            for i in range(n)
            for j in range(n)
            if Q[i, j] != 0
        )

        model = Model(objective)

        # Configure client
        client = FixstarsClient()
        client.token = self.token
        client.parameters.timeout = int(self.time_limit)

        if self.backend is not None:
            client.parameters.outputs.duplicate = True  # Allow duplicate solutions

        # Solve
        result = solve(model, client)

        num_solutions = len(result.solutions)
        if num_solutions == 0:
            raise RuntimeError("Amplify solver returned no solutions")

        # Convert results
        results = []
        for i in range(min(num_reads, num_solutions)):
            sol = result.solutions[i]
            sample = np.array([int(sol.values[x[j]]) for j in range(n)], dtype=np.int8)
            energy = self._compute_energy(sample, Q)
            results.append({
                "sample": sample,
                "energy": energy,
            })

        # If we need more samples, duplicate existing ones
        while len(results) < num_reads:
            idx = len(results) % num_solutions
            results.append(results[idx].copy())

        # Sort by energy (lowest first)
        results.sort(key=lambda r: r["energy"])

        return results[:num_reads]

    def __repr__(self) -> str:
        """String representation."""
        return (f"AmplifySolver(token='***', "
                f"time_limit={self.time_limit}, "
                f"backend={self.backend!r})")


class DWaveSolver(Solver):
    """
    QUBO solver using the D-Wave Ocean SDK.

    Parameters
    ----------
    api_token : str
        D-Wave API token.
    solver_name : str | None
        Name of the D-Wave solver to use. If None, uses default.
        Examples: "Advantage_system4.1", "hybrid_binary_quadratic_model_version2"
    chain_strength : float | None
        Chain strength for embedding. If None, auto-calculated.
    use_hybrid : bool
        If True, use hybrid sampler (recommended for larger problems).
        Default is True.
    **kwargs : Any
        Additional configuration parameters.

    Examples
    --------
    >>> solver = DWaveSolver(api_token="your-token")
    >>> Q = np.array([[1, -1], [-1, 2]])
    >>> results = solver.solve_qubo(Q, num_reads=5)
    >>> len(results)
    5

    Notes
    -----
    Requires the `dwave-ocean-sdk` package to be installed:
    ``pip install quron[dwave]``
    """

    def __init__(
        self,
        api_token: str,
        *,
        solver_name: str | None = None,
        chain_strength: float | None = None,
        use_hybrid: bool = True,
        **kwargs: Any,
    ):
        if not api_token:
            raise ValueError("api_token must be provided")

        self.api_token = api_token
        self.solver_name = solver_name
        self.chain_strength = chain_strength
        self.use_hybrid = use_hybrid
        self._extra_config = kwargs

        # Verify dwave packages are available
        try:
            import dimod  # noqa: F401
            import dwave.system  # noqa: F401
        except ImportError:
            raise ImportError(
                "dwave-ocean-sdk package is required for DWaveSolver. "
                "Install it with: pip install quron[dwave]"
            )

    def solve_qubo(
        self,
        Q: np.ndarray,
        num_reads: int,
        auto_scale: bool = True,
        **kwargs: Any,
    ) -> list[dict]:
        """
        Solve the QUBO problem using D-Wave.

        Parameters
        ----------
        Q : np.ndarray
            QUBO matrix of shape (n, n).
        num_reads : int
            Number of solution samples to return.
        auto_scale : bool
            If True, automatically scale the QUBO coefficients.
        **kwargs : Any
            Additional solver-specific parameters.

        Returns
        -------
        list[dict]
            List of solutions with "sample" and "energy" keys.

        Raises
        ------
        ValueError
            If inputs are invalid.
        RuntimeError
            If the solver fails to find solutions.
        """
        import dimod
        from dwave.system import DWaveSampler, EmbeddingComposite, LeapHybridSampler

        self._validate_qubo(Q)
        if num_reads <= 0:
            raise ValueError(f"num_reads must be positive, got {num_reads}")

        n = Q.shape[0]

        # Convert QUBO matrix to dictionary format
        Q_dict = {}
        for i in range(n):
            for j in range(n):
                if Q[i, j] != 0:
                    if i == j:
                        Q_dict[(i, i)] = float(Q[i, i])
                    elif i < j:
                        # Combine Q[i,j] and Q[j,i] for off-diagonal
                        val = float(Q[i, j] + Q[j, i])
                        if val != 0:
                            Q_dict[(i, j)] = val

        # Create BQM from QUBO
        bqm = dimod.BinaryQuadraticModel.from_qubo(Q_dict)

        # Auto-scale if requested
        if auto_scale:
            bqm.normalize()

        # Select sampler
        if self.use_hybrid:
            sampler = LeapHybridSampler(token=self.api_token)
            # Hybrid sampler doesn't support num_reads directly
            sampleset = sampler.sample(bqm, **kwargs)
        else:
            base_sampler = DWaveSampler(
                token=self.api_token,
                solver=self.solver_name,
            )
            sampler = EmbeddingComposite(base_sampler)

            sampler_kwargs = {"num_reads": num_reads}
            if self.chain_strength is not None:
                sampler_kwargs["chain_strength"] = self.chain_strength
            sampler_kwargs.update(kwargs)

            sampleset = sampler.sample(bqm, **sampler_kwargs)

        if len(sampleset) == 0:
            raise RuntimeError("D-Wave solver returned no solutions")

        # Convert results
        results = []
        for sample, energy in sampleset.data(['sample', 'energy']):
            # Convert sample dict to numpy array
            sample_array = np.array([sample[i] for i in range(n)], dtype=np.int8)
            # Recompute energy from original Q (not normalized)
            actual_energy = self._compute_energy(sample_array, Q)
            results.append({
                "sample": sample_array,
                "energy": actual_energy,
            })

        # Sort by energy (lowest first)
        results.sort(key=lambda r: r["energy"])

        return results[:num_reads]

    def __repr__(self) -> str:
        """String representation."""
        return (f"DWaveSolver(api_token='***', "
                f"solver_name={self.solver_name!r}, "
                f"chain_strength={self.chain_strength}, "
                f"use_hybrid={self.use_hybrid})")
