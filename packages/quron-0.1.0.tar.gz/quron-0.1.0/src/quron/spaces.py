"""
Solution space definition for discrete optimization problems.
"""

from typing import Literal, Sequence
import numpy as np
from collections.abc import Iterable


class Variable:
    """
    Defines the solution space for discrete sequence optimization problems.

    The solution space consists of sequences of fixed length where each element
    is either an integer within a specified range or a category from a predefined set.

    Parameters
    ----------
    length : int
        Length of the solution sequence. Must be positive.
    var_type : Literal["integer", "category"]
        Type of variables in the sequence.
        - "integer": Each element is an integer in [min_value, max_value]
        - "category": Each element is one of the labels
    min_value : int | None
        Minimum value for integer variables (required if var_type="integer")
    max_value : int | None
        Maximum value for integer variables (required if var_type="integer")
    labels : Sequence[str] | None
        List of category labels (required if var_type="category")

    Raises
    ------
    ValueError
        If required parameters are missing or invalid

    Examples
    --------
    Integer space for TSP-like problems:
    >>> space = Variable(length=5, var_type="integer",
    ...                               min_value=0, max_value=9)

    Category space for scheduling:
    >>> space = Variable(length=10, var_type="category",
    ...                               labels=["A", "B", "C"])
    """

    def __init__(
        self,
        length: int,
        var_type: Literal["integer", "category"],
        min_value: int | None = None,
        max_value: int | None = None,
        labels: Sequence[str] | None = None,
    ):
        if length <= 0:
            raise ValueError(f"length must be positive, got {length}")

        self.length = length
        self.var_type = var_type

        if var_type == "integer":
            if min_value is None or max_value is None:
                raise ValueError("min_value and max_value are required for integer type")
            if min_value > max_value:
                raise ValueError(f"min_value ({min_value}) must be <= max_value ({max_value})")
            self.min_value = min_value
            self.max_value = max_value
            self.labels = None
            self._vocab_size = max_value - min_value + 1

        elif var_type == "category":
            if labels is None or len(labels) == 0:
                raise ValueError("labels are required for category type")
            self.labels = list(labels)
            self.min_value = None
            self.max_value = None
            self._vocab_size = len(self.labels)
            # Create label to ID mapping
            self._label_to_id = {label: i for i, label in enumerate(self.labels)}

        else:
            raise ValueError(f"var_type must be 'integer' or 'category', got '{var_type}'")

    @property
    def vocab_size(self) -> int:
        """
        Returns the number of distinct values each element can take.

        Returns
        -------
        int
            Vocabulary size (number of possible values per position)
        """
        return self._vocab_size

    def sample_random(self, n: int) -> list[list]:
        """
        Generate n random solutions uniformly from the solution space.

        Parameters
        ----------
        n : int
            Number of solutions to generate

        Returns
        -------
        list[list]
            List of n solutions, each solution is a list of length `self.length`

        Examples
        --------
        >>> space = Variable(length=3, var_type="integer",
        ...                               min_value=0, max_value=2)
        >>> solutions = space.sample_random(2)
        >>> len(solutions)
        2
        >>> all(len(sol) == 3 for sol in solutions)
        True
        """
        if n <= 0:
            return []

        if self.var_type == "integer":
            # Generate random integers in [min_value, max_value]
            samples = np.random.randint(
                self.min_value,
                self.max_value + 1,
                size=(n, self.length)
            )
            return samples.tolist()

        else:  # category
            # Generate random indices and map to labels
            indices = np.random.randint(0, len(self.labels), size=(n, self.length))
            return [[self.labels[idx] for idx in row] for row in indices]

    def validate(self, solution: list) -> bool:
        """
        Check if a solution satisfies the space constraints.

        Parameters
        ----------
        solution : list
            A solution to validate

        Returns
        -------
        bool
            True if the solution is valid, False otherwise

        Examples
        --------
        >>> space = Variable(length=3, var_type="integer",
        ...                               min_value=0, max_value=2)
        >>> space.validate([0, 1, 2])
        True
        >>> space.validate([0, 1, 3])  # 3 is out of range
        False
        >>> space.validate([0, 1])  # wrong length
        False
        """
        if not isinstance(solution, (list, tuple)):
            return False

        if len(solution) != self.length:
            return False

        if self.var_type == "integer":
            for val in solution:
                if not isinstance(val, (int, np.integer)):
                    return False
                if val < self.min_value or val > self.max_value:
                    return False
            return True

        else:  # category
            for val in solution:
                if val not in self._label_to_id:
                    return False
            return True

    def to_internal_ids(self, solution: list) -> list[int]:
        """
        Convert a solution from user representation to internal IDs (0 to K-1).

        Parameters
        ----------
        solution : list
            A solution in user representation

        Returns
        -------
        list[int]
            Solution as internal IDs (0-indexed integers)

        Raises
        ------
        ValueError
            If the solution is invalid

        Examples
        --------
        >>> space = Variable(length=3, var_type="integer",
        ...                               min_value=5, max_value=7)
        >>> space.to_internal_ids([5, 6, 7])
        [0, 1, 2]

        >>> space = Variable(length=2, var_type="category",
        ...                               labels=["A", "B", "C"])
        >>> space.to_internal_ids(["B", "C"])
        [1, 2]
        """
        if not self.validate(solution):
            raise ValueError(f"Invalid solution: {solution}")

        if self.var_type == "integer":
            return [int(val - self.min_value) for val in solution]
        else:  # category
            return [self._label_to_id[val] for val in solution]

    def from_internal_ids(self, ids: list[int]) -> list:
        """
        Convert internal IDs (0 to K-1) back to user representation.

        Parameters
        ----------
        ids : list[int]
            Solution as internal IDs

        Returns
        -------
        list
            Solution in user representation (int for integer type, str for category)

        Raises
        ------
        ValueError
            If the IDs are invalid

        Examples
        --------
        >>> space = Variable(length=3, var_type="integer",
        ...                               min_value=5, max_value=7)
        >>> space.from_internal_ids([0, 1, 2])
        [5, 6, 7]

        >>> space = Variable(length=2, var_type="category",
        ...                               labels=["A", "B", "C"])
        >>> space.from_internal_ids([1, 2])
        ['B', 'C']
        """
        if len(ids) != self.length:
            raise ValueError(f"Expected length {self.length}, got {len(ids)}")

        if self.var_type == "integer":
            result = []
            for id_val in ids:
                if not (0 <= id_val < self._vocab_size):
                    raise ValueError(f"ID {id_val} out of range [0, {self._vocab_size})")
                result.append(int(id_val + self.min_value))
            return result

        else:  # category
            result = []
            for id_val in ids:
                if not (0 <= id_val < self._vocab_size):
                    raise ValueError(f"ID {id_val} out of range [0, {self._vocab_size})")
                result.append(self.labels[id_val])
            return result

    def __repr__(self) -> str:
        """String representation of the space."""
        if self.var_type == "integer":
            return (f"Variable(length={self.length}, "
                   f"var_type='integer', min_value={self.min_value}, "
                   f"max_value={self.max_value})")
        else:
            return (f"Variable(length={self.length}, "
                   f"var_type='category', labels={self.labels})")
