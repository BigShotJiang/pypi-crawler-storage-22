"""
Tests for quron.ae module.
"""

import pytest
import numpy as np
import tempfile
import os

from quron.spaces import Variable
from quron.ae import AEBuilder


class TestAEBuilderInteger:
    """Tests for AEBuilder with integer space."""

    def test_init_auto_latent_dim(self):
        """Test automatic latent dimension calculation."""
        space = Variable(
            length=10,
            var_type="integer",
            min_value=0,
            max_value=9
        )
        builder = AEBuilder(space, latent_dim=None)

        # vocab_size = 10, length = 10
        # expected: max(4, int(10 * log2(10)) // 2) = max(4, 33 // 2) = max(4, 16) = 16
        expected_dim = max(4, int(10 * np.log2(10)) // 2)
        assert builder.latent_dim == expected_dim

    def test_init_explicit_latent_dim(self):
        """Test explicit latent dimension."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=4
        )
        builder = AEBuilder(space, latent_dim=8)
        assert builder.latent_dim == 8

    def test_init_with_seed(self):
        """Test initialization with random seed."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=4
        )
        builder1 = AEBuilder(space, latent_dim=8, seed=42)
        builder2 = AEBuilder(space, latent_dim=8, seed=42)

        # Both should be initialized (though exact weight comparison would be complex)
        assert builder1.latent_dim == builder2.latent_dim

    def test_train_basic(self):
        """Test basic training functionality."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        builder = AEBuilder(space, latent_dim=4, seed=42)

        # Generate training data
        solutions = space.sample_random(20)

        # Train
        builder.train(solutions, epochs=5, batch_size=8)
        assert builder._trained is True

    def test_train_empty_solutions(self):
        """Test that training with empty solutions raises error."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        builder = AEBuilder(space, latent_dim=4)

        with pytest.raises(ValueError, match="No solutions provided"):
            builder.train([])

    def test_train_invalid_solution(self):
        """Test that training with invalid solution raises error."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        builder = AEBuilder(space, latent_dim=4)

        invalid_solutions = [[0, 1, 2, 3, 4]]  # 3 and 4 are out of range

        with pytest.raises(ValueError, match="Invalid solution"):
            builder.train(invalid_solutions)

    def test_encode_basic(self):
        """Test basic encoding functionality."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        builder = AEBuilder(space, latent_dim=4, seed=42)

        # Train
        train_solutions = space.sample_random(20)
        builder.train(train_solutions, epochs=5, batch_size=8)

        # Encode
        test_solutions = space.sample_random(5)
        latents = builder.encode(test_solutions)

        # Check output shape and type
        assert latents.shape == (5, 4)
        assert latents.dtype == np.int32
        assert np.all((latents == 0) | (latents == 1))  # Binary values

    def test_encode_before_train(self):
        """Test that encoding before training raises error."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        builder = AEBuilder(space, latent_dim=4)

        solutions = space.sample_random(5)
        with pytest.raises(RuntimeError, match="has not been trained"):
            builder.encode(solutions)

    def test_encode_empty(self):
        """Test encoding empty list."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        builder = AEBuilder(space, latent_dim=4, seed=42)

        # Train first
        train_solutions = space.sample_random(20)
        builder.train(train_solutions, epochs=5)

        # Encode empty
        latents = builder.encode([])
        assert latents.shape == (0, 4)

    def test_decode_basic(self):
        """Test basic decoding functionality."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        builder = AEBuilder(space, latent_dim=4, seed=42)

        # Train
        train_solutions = space.sample_random(30)
        builder.train(train_solutions, epochs=10, batch_size=8)

        # Create random binary latents
        latents = np.random.randint(0, 2, size=(5, 4)).astype(np.int32)

        # Decode
        decoded_solutions = builder.decode(latents)

        # Check output
        assert len(decoded_solutions) == 5
        for sol in decoded_solutions:
            assert len(sol) == 5
            assert space.validate(sol)

    def test_decode_before_train(self):
        """Test that decoding before training raises error."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        builder = AEBuilder(space, latent_dim=4)

        latents = np.random.randint(0, 2, size=(5, 4)).astype(np.int32)
        with pytest.raises(RuntimeError, match="has not been trained"):
            builder.decode(latents)

    def test_decode_wrong_dimension(self):
        """Test that decoding with wrong dimension raises error."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        builder = AEBuilder(space, latent_dim=4, seed=42)

        # Train
        train_solutions = space.sample_random(20)
        builder.train(train_solutions, epochs=5)

        # Wrong dimension
        latents = np.random.randint(0, 2, size=(5, 8)).astype(np.int32)
        with pytest.raises(ValueError, match="Expected latent dimension"):
            builder.decode(latents)

    def test_roundtrip(self):
        """Test encode-decode round trip."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        builder = AEBuilder(space, latent_dim=8, seed=42)

        # Train with sufficient data
        train_solutions = space.sample_random(100)
        builder.train(train_solutions, epochs=20, batch_size=16)

        # Test roundtrip
        test_solutions = space.sample_random(10)
        latents = builder.encode(test_solutions)
        decoded = builder.decode(latents)

        # All decoded solutions should be valid
        for sol in decoded:
            assert space.validate(sol)

        # Note: We don't expect perfect reconstruction for small latent dim,
        # but solutions should be valid

    def test_save_load(self):
        """Test saving and loading model."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        builder1 = AEBuilder(space, latent_dim=4, seed=42)

        # Train
        train_solutions = space.sample_random(20)
        builder1.train(train_solutions, epochs=5)

        # Save
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = os.path.join(tmpdir, "ae_model.pt")
            builder1.save(save_path)

            # Create new builder and load
            builder2 = AEBuilder(space, latent_dim=4)
            builder2.load(save_path)

            assert builder2._trained is True

            # Test that loaded model works
            test_solutions = space.sample_random(5)
            latents = builder2.encode(test_solutions)
            assert latents.shape == (5, 4)

    def test_save_before_train(self):
        """Test that saving before training raises error."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        builder = AEBuilder(space, latent_dim=4)

        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = os.path.join(tmpdir, "ae_model.pt")
            with pytest.raises(RuntimeError, match="Cannot save untrained model"):
                builder.save(save_path)


class TestAEBuilderCategory:
    """Tests for AEBuilder with category space."""

    def test_train_category(self):
        """Test training with category space."""
        space = Variable(
            length=5,
            var_type="category",
            labels=["A", "B", "C"]
        )
        builder = AEBuilder(space, latent_dim=4, seed=42)

        solutions = space.sample_random(20)
        builder.train(solutions, epochs=5)
        assert builder._trained is True

    def test_encode_category(self):
        """Test encoding with category space."""
        space = Variable(
            length=5,
            var_type="category",
            labels=["X", "Y", "Z"]
        )
        builder = AEBuilder(space, latent_dim=4, seed=42)

        # Train
        train_solutions = space.sample_random(20)
        builder.train(train_solutions, epochs=5)

        # Encode
        test_solutions = space.sample_random(3)
        latents = builder.encode(test_solutions)

        assert latents.shape == (3, 4)
        assert np.all((latents == 0) | (latents == 1))

    def test_decode_category(self):
        """Test decoding with category space."""
        space = Variable(
            length=5,
            var_type="category",
            labels=["Red", "Green", "Blue"]
        )
        builder = AEBuilder(space, latent_dim=4, seed=42)

        # Train
        train_solutions = space.sample_random(30)
        builder.train(train_solutions, epochs=10)

        # Decode
        latents = np.random.randint(0, 2, size=(5, 4)).astype(np.int32)
        decoded = builder.decode(latents)

        assert len(decoded) == 5
        for sol in decoded:
            assert space.validate(sol)

    def test_roundtrip_category(self):
        """Test roundtrip with category space."""
        space = Variable(
            length=5,
            var_type="category",
            labels=["A", "B", "C", "D"]
        )
        builder = AEBuilder(space, latent_dim=8, seed=42)

        # Train
        train_solutions = space.sample_random(100)
        builder.train(train_solutions, epochs=20)

        # Roundtrip
        test_solutions = space.sample_random(10)
        latents = builder.encode(test_solutions)
        decoded = builder.decode(latents)

        for sol in decoded:
            assert space.validate(sol)


class TestAEBuilderGeneral:
    """General tests for AEBuilder."""

    def test_repr_untrained(self):
        """Test string representation of untrained model."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        builder = AEBuilder(space, latent_dim=4)
        repr_str = repr(builder)

        assert "AEBuilder" in repr_str
        assert "untrained" in repr_str
        assert "latent_dim=4" in repr_str

    def test_repr_trained(self):
        """Test string representation of trained model."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        builder = AEBuilder(space, latent_dim=4, seed=42)

        train_solutions = space.sample_random(20)
        builder.train(train_solutions, epochs=5)

        repr_str = repr(builder)
        assert "trained" in repr_str


class TestAEBuilderTrainParams:
    """Tests for train() parameters."""

    def test_train_custom_epochs(self):
        """Test training with custom epochs."""
        space = Variable(length=5, var_type="integer", min_value=0, max_value=2)
        builder = AEBuilder(space, latent_dim=4, seed=42)

        solutions = space.sample_random(20)
        builder.train(solutions, epochs=10)
        assert builder._trained is True

    def test_train_custom_batch_size(self):
        """Test training with custom batch size."""
        space = Variable(length=5, var_type="integer", min_value=0, max_value=2)
        builder = AEBuilder(space, latent_dim=4, seed=42)

        solutions = space.sample_random(20)
        builder.train(solutions, epochs=5, batch_size=4)
        assert builder._trained is True

    def test_train_custom_learning_rate(self):
        """Test training with custom learning rate."""
        space = Variable(length=5, var_type="integer", min_value=0, max_value=2)
        builder = AEBuilder(space, latent_dim=4, seed=42)

        solutions = space.sample_random(20)
        builder.train(solutions, epochs=5, learning_rate=0.01)
        assert builder._trained is True

    def test_train_all_custom_params(self):
        """Test training with all custom parameters."""
        space = Variable(length=5, var_type="integer", min_value=0, max_value=2)
        builder = AEBuilder(space, latent_dim=4, seed=42)

        solutions = space.sample_random(20)
        builder.train(solutions, epochs=10, batch_size=8, learning_rate=0.005)
        assert builder._trained is True
