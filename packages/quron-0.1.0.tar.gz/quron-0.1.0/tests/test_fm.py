"""
Tests for quron.fm module.
"""

import pytest
import numpy as np

from quron.fm import FMModel


class TestFMModelInit:
    """Tests for FMModel initialization."""

    def test_init_valid(self):
        """Test valid initialization."""
        fm = FMModel(num_features=10, k=8, l2_reg=0.01)
        assert fm.num_features == 10
        assert fm.k == 8
        assert fm.l2_reg == 0.01
        assert fm._fitted is False

    def test_init_defaults(self):
        """Test initialization with default parameters."""
        fm = FMModel(num_features=10)
        assert fm.num_features == 10
        assert fm.k == 16  # default
        assert fm.l2_reg == 0.0  # default

    def test_init_invalid_num_features(self):
        """Test that invalid num_features raises error."""
        with pytest.raises(ValueError, match="must be positive"):
            FMModel(num_features=0)

        with pytest.raises(ValueError, match="must be positive"):
            FMModel(num_features=-5)

    def test_init_invalid_k(self):
        """Test that invalid k raises error."""
        with pytest.raises(ValueError, match="must be positive"):
            FMModel(num_features=10, k=0)

        with pytest.raises(ValueError, match="must be positive"):
            FMModel(num_features=10, k=-1)


class TestFMModelFit:
    """Tests for FMModel fitting."""

    def test_fit_basic(self):
        """Test basic fitting functionality."""
        fm = FMModel(num_features=5, k=4)

        # Create dummy data
        np.random.seed(42)
        latents = np.random.randint(0, 2, size=(50, 5)).astype(np.float32)
        values = np.random.randn(50).astype(np.float32)

        # Fit
        fm.fit(latents, values, epochs=10, batch_size=16)
        assert fm._fitted is True

    def test_fit_empty_data(self):
        """Test that fitting with empty data raises error."""
        fm = FMModel(num_features=5, k=4)

        latents = np.empty((0, 5), dtype=np.float32)
        values = np.empty(0, dtype=np.float32)

        with pytest.raises(ValueError, match="No training data"):
            fm.fit(latents, values)

    def test_fit_dimension_mismatch(self):
        """Test that mismatched dimensions raise error."""
        fm = FMModel(num_features=5, k=4)

        latents = np.random.randint(0, 2, size=(50, 5)).astype(np.float32)
        values = np.random.randn(30).astype(np.float32)  # Wrong size

        with pytest.raises(ValueError, match="Mismatch"):
            fm.fit(latents, values)

    def test_fit_wrong_num_features(self):
        """Test that wrong number of features raises error."""
        fm = FMModel(num_features=5, k=4)

        latents = np.random.randint(0, 2, size=(50, 8)).astype(np.float32)  # 8 != 5
        values = np.random.randn(50).astype(np.float32)

        with pytest.raises(ValueError, match="Expected 5 features"):
            fm.fit(latents, values)

    def test_fit_learns_linear_relationship(self):
        """Test that FM can learn a simple linear relationship."""
        fm = FMModel(num_features=3, k=4, l2_reg=0.0)

        # Create linear relationship: y = 2*x0 + 3*x1 - x2 + 5
        np.random.seed(42)
        latents = np.random.randint(0, 2, size=(200, 3)).astype(np.float32)
        values = (2 * latents[:, 0] + 3 * latents[:, 1] - latents[:, 2] + 5).astype(np.float32)

        # Fit
        fm.fit(latents, values, epochs=100, batch_size=32, learning_rate=0.01)

        # Predict on training data
        predictions = fm.predict(latents)

        # Should have low error
        mse = np.mean((predictions - values) ** 2)
        assert mse < 1.5  # Reasonable threshold for learning (FM may not perfectly fit linear)


class TestFMModelPredict:
    """Tests for FMModel prediction."""

    def test_predict_basic(self):
        """Test basic prediction functionality."""
        fm = FMModel(num_features=5, k=4)

        # Train
        np.random.seed(42)
        train_latents = np.random.randint(0, 2, size=(50, 5)).astype(np.float32)
        train_values = np.random.randn(50).astype(np.float32)
        fm.fit(train_latents, train_values, epochs=10)

        # Predict
        test_latents = np.random.randint(0, 2, size=(10, 5)).astype(np.float32)
        predictions = fm.predict(test_latents)

        assert predictions.shape == (10,)
        assert predictions.dtype == np.float32

    def test_predict_before_fit(self):
        """Test that prediction before fitting raises error."""
        fm = FMModel(num_features=5, k=4)

        latents = np.random.randint(0, 2, size=(10, 5)).astype(np.float32)

        with pytest.raises(RuntimeError, match="has not been fitted"):
            fm.predict(latents)

    def test_predict_wrong_num_features(self):
        """Test that prediction with wrong features raises error."""
        fm = FMModel(num_features=5, k=4)

        # Train
        train_latents = np.random.randint(0, 2, size=(50, 5)).astype(np.float32)
        train_values = np.random.randn(50).astype(np.float32)
        fm.fit(train_latents, train_values, epochs=10)

        # Try to predict with wrong dimension
        test_latents = np.random.randint(0, 2, size=(10, 8)).astype(np.float32)

        with pytest.raises(ValueError, match="Expected 5 features"):
            fm.predict(test_latents)


class TestFMModelToQUBO:
    """Tests for QUBO conversion."""

    def test_to_qubo_basic(self):
        """Test basic QUBO conversion."""
        fm = FMModel(num_features=5, k=4)

        # Train
        np.random.seed(42)
        latents = np.random.randint(0, 2, size=(50, 5)).astype(np.float32)
        values = np.random.randn(50).astype(np.float32)
        fm.fit(latents, values, epochs=10)

        # Convert to QUBO
        Q, c = fm.to_qubo()

        # Check output
        assert Q.shape == (5, 5)
        assert isinstance(c, float)

        # Q should be symmetric
        assert np.allclose(Q, Q.T)

    def test_to_qubo_before_fit(self):
        """Test that QUBO conversion before fitting raises error."""
        fm = FMModel(num_features=5, k=4)

        with pytest.raises(RuntimeError, match="has not been fitted"):
            fm.to_qubo()

    def test_to_qubo_structure(self):
        """Test that QUBO structure is correct."""
        fm = FMModel(num_features=3, k=2)

        # Simple training data
        latents = np.array([[1, 0, 1], [0, 1, 0], [1, 1, 1]], dtype=np.float32)
        values = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        fm.fit(latents, values, epochs=20)

        Q, c = fm.to_qubo()

        # Diagonal contains linear terms
        assert Q.shape == (3, 3)

        # Off-diagonal contains interactions
        # Q should be symmetric
        for i in range(3):
            for j in range(i + 1, 3):
                assert np.isclose(Q[i, j], Q[j, i])

    def test_to_qubo_evaluation(self):
        """Test that QUBO evaluation matches FM prediction."""
        fm = FMModel(num_features=4, k=3, l2_reg=0.0)

        # Train with simple data
        np.random.seed(42)
        latents = np.random.randint(0, 2, size=(100, 4)).astype(np.float32)
        values = np.random.randn(100).astype(np.float32)
        fm.fit(latents, values, epochs=50, learning_rate=0.01)

        Q, c = fm.to_qubo()

        # Test that QUBO evaluation is close to FM prediction
        test_latents = np.random.randint(0, 2, size=(10, 4)).astype(np.float32)
        fm_predictions = fm.predict(test_latents)

        # Evaluate QUBO: x^T Q x + c
        qubo_predictions = []
        for x in test_latents:
            qubo_val = x @ Q @ x + c
            qubo_predictions.append(qubo_val)
        qubo_predictions = np.array(qubo_predictions)

        # Should be reasonably close (some difference due to conversion)
        mse = np.mean((fm_predictions - qubo_predictions) ** 2)
        # The conversion is approximate, but should be close
        assert mse < 2.0


class TestFMModelGeneral:
    """General tests for FMModel."""

    def test_repr_unfitted(self):
        """Test string representation of unfitted model."""
        fm = FMModel(num_features=5, k=4, l2_reg=0.01)
        repr_str = repr(fm)

        assert "FMModel" in repr_str
        assert "num_features=5" in repr_str
        assert "k=4" in repr_str
        assert "unfitted" in repr_str

    def test_repr_fitted(self):
        """Test string representation of fitted model."""
        fm = FMModel(num_features=5, k=4)

        # Train
        latents = np.random.randint(0, 2, size=(50, 5)).astype(np.float32)
        values = np.random.randn(50).astype(np.float32)
        fm.fit(latents, values, epochs=10)

        repr_str = repr(fm)
        assert "fitted" in repr_str

    def test_l2_regularization(self):
        """Test that L2 regularization affects training."""
        np.random.seed(42)
        latents = np.random.randint(0, 2, size=(50, 5)).astype(np.float32)
        values = np.random.randn(50).astype(np.float32)

        # Train without regularization
        fm1 = FMModel(num_features=5, k=4, l2_reg=0.0)
        fm1.fit(latents, values, epochs=20)

        # Train with regularization
        fm2 = FMModel(num_features=5, k=4, l2_reg=0.1)
        fm2.fit(latents, values, epochs=20)

        # Both should be fitted
        assert fm1._fitted is True
        assert fm2._fitted is True

        # Regularized model should have smaller weights (in general)
        # This is a weak test but checks that regularization has some effect
        w1_norm = np.linalg.norm(fm1.w.detach().numpy())
        w2_norm = np.linalg.norm(fm2.w.detach().numpy())

        # With regularization, weights tend to be smaller (not always guaranteed in small samples)
        # Just check that both are reasonable
        assert w1_norm >= 0
        assert w2_norm >= 0
