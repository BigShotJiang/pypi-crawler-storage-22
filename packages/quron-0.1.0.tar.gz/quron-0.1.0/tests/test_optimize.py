"""
Tests for quron.optimize module.
"""

import pytest
import numpy as np

from quron.spaces import Variable
from quron.ae import AEBuilder
from quron.fm import FMModel
from quron.solver import Solver
from quron.optimize import Optimizer


class MockSolver(Solver):
    """Mock solver for testing that returns random binary solutions."""

    def __init__(self, latent_dim: int):
        self.latent_dim = latent_dim

    def solve_qubo(
        self,
        Q: np.ndarray,
        num_reads: int,
        auto_scale: bool = True,
        **kwargs,
    ) -> list[dict]:
        self._validate_qubo(Q)
        results = []
        for _ in range(num_reads):
            sample = np.random.randint(0, 2, size=Q.shape[0]).astype(np.int8)
            energy = self._compute_energy(sample, Q)
            results.append({"sample": sample, "energy": energy})
        results.sort(key=lambda x: x["energy"])
        return results


class TestOptimizerInit:
    """Tests for Optimizer initialization."""

    @pytest.fixture
    def space(self):
        """Create a simple integer space."""
        return Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=9,
        )

    @pytest.fixture
    def builder(self, space):
        """Create and train a simple AE builder."""
        builder = AEBuilder(space, latent_dim=8, seed=42)
        solutions = space.sample_random(20)
        builder.train(solutions, epochs=5)
        return builder

    @pytest.fixture
    def objective(self):
        """Simple objective function (minimize sum)."""
        return lambda sol: sum(sol)

    @pytest.fixture
    def solver(self):
        """Mock solver."""
        return MockSolver(latent_dim=8)

    def test_init_valid(self, space, builder, objective, solver):
        """Test valid initialization."""
        opt = Optimizer(
            space=space,
            builder=builder,
            objective=objective,
            solver=solver,
            num_samples_per_iter=3,
            random_state=42,
        )

        assert opt.space is space
        assert opt.builder is builder
        assert opt.solver is solver
        assert opt.num_samples_per_iter == 3
        assert opt.random_state == 42

    def test_init_defaults(self, space, builder, objective, solver):
        """Test initialization with defaults."""
        opt = Optimizer(
            space=space,
            builder=builder,
            objective=objective,
            solver=solver,
        )

        assert opt.num_samples_per_iter == 1
        assert opt.random_state is None

    def test_init_invalid_num_samples(self, space, builder, objective, solver):
        """Test that invalid num_samples_per_iter raises error."""
        with pytest.raises(ValueError, match="must be positive"):
            Optimizer(
                space=space,
                builder=builder,
                objective=objective,
                solver=solver,
                num_samples_per_iter=0,
            )


class TestOptimizerAddInitialData:
    """Tests for Optimizer.add_initial_data."""

    @pytest.fixture
    def optimizer(self):
        """Create an optimizer for testing."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=0,
            max_value=5,
        )
        builder = AEBuilder(space, latent_dim=6, seed=42)
        solutions = space.sample_random(20)
        builder.train(solutions, epochs=5)

        objective = lambda sol: sum(sol)
        solver = MockSolver(latent_dim=6)

        return Optimizer(
            space=space,
            builder=builder,
            objective=objective,
            solver=solver,
        )

    def test_add_initial_data_with_values(self, optimizer):
        """Test adding initial data with pre-computed values."""
        solutions = [[1, 2, 3], [0, 0, 0], [5, 5, 5]]
        values = [6.0, 0.0, 15.0]

        optimizer.add_initial_data(solutions, values)

        assert len(optimizer._solutions) == 3
        assert len(optimizer._values) == 3
        assert optimizer._values == values

    def test_add_initial_data_without_values(self, optimizer):
        """Test adding initial data without values (computed automatically)."""
        solutions = [[1, 2, 3], [0, 0, 0], [5, 5, 5]]

        optimizer.add_initial_data(solutions)

        assert len(optimizer._solutions) == 3
        assert len(optimizer._values) == 3
        # Values should be computed using objective function (sum)
        assert optimizer._values[0] == 6.0
        assert optimizer._values[1] == 0.0
        assert optimizer._values[2] == 15.0

    def test_add_initial_data_empty_raises(self, optimizer):
        """Test that empty solutions raises error."""
        with pytest.raises(ValueError, match="must not be empty"):
            optimizer.add_initial_data([])

    def test_add_initial_data_length_mismatch(self, optimizer):
        """Test that mismatched lengths raises error."""
        solutions = [[1, 2, 3], [0, 0, 0]]
        values = [6.0]  # Wrong length

        with pytest.raises(ValueError, match="Length mismatch"):
            optimizer.add_initial_data(solutions, values)

    def test_add_initial_data_invalid_solution(self, optimizer):
        """Test that invalid solution raises error."""
        solutions = [[1, 2, 10]]  # 10 is out of range [0, 5]

        with pytest.raises(ValueError, match="Invalid solution"):
            optimizer.add_initial_data(solutions)


class TestOptimizerOptimize:
    """Tests for Optimizer.optimize."""

    @pytest.fixture
    def optimizer_with_data(self):
        """Create an optimizer with initial data."""
        space = Variable(
            length=4,
            var_type="integer",
            min_value=0,
            max_value=3,
        )
        builder = AEBuilder(space, latent_dim=8, seed=42)
        solutions = space.sample_random(30)
        builder.train(solutions, epochs=10)

        objective = lambda sol: sum(sol)
        solver = MockSolver(latent_dim=8)

        opt = Optimizer(
            space=space,
            builder=builder,
            objective=objective,
            solver=solver,
            num_samples_per_iter=2,
            random_state=42,
        )

        # Add initial data
        initial = space.sample_random(10)
        opt.add_initial_data(initial)

        return opt

    def test_optimize_basic(self, optimizer_with_data):
        """Test basic optimization run."""
        opt = optimizer_with_data
        initial_count = len(opt._solutions)

        opt.optimize(num_iterations=3)

        # Should have added some new solutions
        assert len(opt._solutions) >= initial_count
        assert opt._current_iteration == 3

    def test_optimize_no_initial_data_raises(self):
        """Test that optimize without initial data raises error."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=0,
            max_value=5,
        )
        builder = AEBuilder(space, latent_dim=6, seed=42)
        builder.train(space.sample_random(20), epochs=5)

        opt = Optimizer(
            space=space,
            builder=builder,
            objective=lambda sol: sum(sol),
            solver=MockSolver(latent_dim=6),
        )

        with pytest.raises(RuntimeError, match="No initial data"):
            opt.optimize(num_iterations=1)

    def test_optimize_invalid_iterations(self, optimizer_with_data):
        """Test that invalid num_iterations raises error."""
        with pytest.raises(ValueError, match="must be positive"):
            optimizer_with_data.optimize(num_iterations=0)

        with pytest.raises(ValueError, match="must be positive"):
            optimizer_with_data.optimize(num_iterations=-1)


class TestOptimizerProperties:
    """Tests for Optimizer properties."""

    @pytest.fixture
    def optimizer_with_trials(self):
        """Create an optimizer with some trials."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=0,
            max_value=5,
        )
        builder = AEBuilder(space, latent_dim=6, seed=42)
        builder.train(space.sample_random(30), epochs=10)

        objective = lambda sol: sum(sol)
        solver = MockSolver(latent_dim=6)

        opt = Optimizer(
            space=space,
            builder=builder,
            objective=objective,
            solver=solver,
            num_samples_per_iter=2,
            random_state=42,
        )

        # Add initial data with known best
        opt.add_initial_data(
            [[0, 0, 0], [1, 1, 1], [5, 5, 5]],
            [0.0, 3.0, 15.0],
        )

        return opt

    def test_best_solution(self, optimizer_with_trials):
        """Test best_solution property."""
        best = optimizer_with_trials.best_solution
        assert best == [0, 0, 0]

    def test_best_value(self, optimizer_with_trials):
        """Test best_value property."""
        best_val = optimizer_with_trials.best_value
        assert best_val == 0.0

    def test_trials(self, optimizer_with_trials):
        """Test trials property."""
        trials = optimizer_with_trials.trials

        assert len(trials) == 3
        for trial in trials:
            assert "solution" in trial
            assert "value" in trial
            assert "latent" in trial
            assert "iteration" in trial

    def test_best_solution_empty_raises(self):
        """Test that best_solution on empty optimizer raises error."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=0,
            max_value=5,
        )
        builder = AEBuilder(space, latent_dim=6, seed=42)
        builder.train(space.sample_random(20), epochs=5)

        opt = Optimizer(
            space=space,
            builder=builder,
            objective=lambda sol: sum(sol),
            solver=MockSolver(latent_dim=6),
        )

        with pytest.raises(RuntimeError, match="No solutions available"):
            _ = opt.best_solution

    def test_best_value_empty_raises(self):
        """Test that best_value on empty optimizer raises error."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=0,
            max_value=5,
        )
        builder = AEBuilder(space, latent_dim=6, seed=42)
        builder.train(space.sample_random(20), epochs=5)

        opt = Optimizer(
            space=space,
            builder=builder,
            objective=lambda sol: sum(sol),
            solver=MockSolver(latent_dim=6),
        )

        with pytest.raises(RuntimeError, match="No values available"):
            _ = opt.best_value


class TestOptimizerIntegration:
    """Integration tests for the full optimization loop."""

    def test_full_optimization_integer(self):
        """Test full optimization with integer space."""
        np.random.seed(42)

        # Setup
        space = Variable(
            length=4,
            var_type="integer",
            min_value=0,
            max_value=3,
        )

        builder = AEBuilder(space, latent_dim=8, seed=42)
        initial_solutions = space.sample_random(50)
        builder.train(initial_solutions, epochs=20)

        # Objective: minimize sum of elements
        def objective(sol):
            return sum(sol)

        solver = MockSolver(latent_dim=8)

        opt = Optimizer(
            space=space,
            builder=builder,
            objective=objective,
            solver=solver,
            num_samples_per_iter=3,
            random_state=42,
        )

        # Add initial data
        opt.add_initial_data(initial_solutions[:20])

        initial_best = opt.best_value

        # Run optimization
        opt.optimize(num_iterations=5)

        # Check results
        assert len(opt._solutions) >= 20
        assert opt.best_value <= initial_best  # Should not get worse
        assert len(opt.trials) == len(opt._solutions)

    def test_full_optimization_category(self):
        """Test full optimization with category space."""
        np.random.seed(42)

        # Setup
        space = Variable(
            length=3,
            var_type="category",
            labels=["A", "B", "C"],
        )

        builder = AEBuilder(space, latent_dim=6, seed=42)
        initial_solutions = space.sample_random(50)
        builder.train(initial_solutions, epochs=20)

        # Objective: count number of 'A's (minimize)
        def objective(sol):
            return -sum(1 for x in sol if x == "A")  # Negative to maximize A's

        solver = MockSolver(latent_dim=6)

        opt = Optimizer(
            space=space,
            builder=builder,
            objective=objective,
            solver=solver,
            num_samples_per_iter=2,
            random_state=42,
        )

        # Add initial data
        opt.add_initial_data(initial_solutions[:15])

        # Run optimization
        opt.optimize(num_iterations=3)

        # Check results
        assert len(opt._solutions) >= 15
        assert opt.best_solution is not None
        assert opt.best_value <= 0  # At least one 'A' or negative count


class TestOptimizerConfigureFM:
    """Tests for Optimizer.configure_fm."""

    @pytest.fixture
    def optimizer(self):
        """Create an optimizer for testing."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=0,
            max_value=5,
        )
        builder = AEBuilder(space, latent_dim=6, seed=42)
        solutions = space.sample_random(20)
        builder.train(solutions, epochs=5)

        objective = lambda sol: sum(sol)
        solver = MockSolver(latent_dim=6)

        return Optimizer(
            space=space,
            builder=builder,
            objective=objective,
            solver=solver,
        )

    def test_configure_fm_defaults(self, optimizer):
        """Test default FM configuration."""
        assert optimizer._fm_k is None  # Auto: min(10, latent_dim)
        assert optimizer._fm_epochs == 1000
        assert optimizer._fm_batch_size == 20
        assert optimizer._fm_learning_rate == 0.1
        assert optimizer._fm_l2_reg == 0.0

    def test_configure_fm_k(self, optimizer):
        """Test configuring FM k parameter."""
        optimizer.configure_fm(k=32)
        assert optimizer._fm_k == 32

    def test_configure_fm_epochs(self, optimizer):
        """Test configuring FM epochs."""
        optimizer.configure_fm(epochs=100)
        assert optimizer._fm_epochs == 100

    def test_configure_fm_learning_rate(self, optimizer):
        """Test configuring FM learning rate."""
        optimizer.configure_fm(learning_rate=0.01)
        assert optimizer._fm_learning_rate == 0.01

    def test_configure_fm_batch_size(self, optimizer):
        """Test configuring FM batch size."""
        optimizer.configure_fm(batch_size=32)
        assert optimizer._fm_batch_size == 32

    def test_configure_fm_l2_reg(self, optimizer):
        """Test configuring FM L2 regularization."""
        optimizer.configure_fm(l2_reg=0.1)
        assert optimizer._fm_l2_reg == 0.1

    def test_configure_fm_multiple(self, optimizer):
        """Test configuring multiple FM parameters at once."""
        optimizer.configure_fm(k=20, epochs=200, batch_size=16, learning_rate=0.05, l2_reg=0.01)
        assert optimizer._fm_k == 20
        assert optimizer._fm_epochs == 200
        assert optimizer._fm_batch_size == 16
        assert optimizer._fm_learning_rate == 0.05
        assert optimizer._fm_l2_reg == 0.01

    def test_configure_fm_invalid_k(self, optimizer):
        """Test that invalid k raises error."""
        with pytest.raises(ValueError, match="k must be positive"):
            optimizer.configure_fm(k=0)
        with pytest.raises(ValueError, match="k must be positive"):
            optimizer.configure_fm(k=-1)

    def test_configure_fm_invalid_epochs(self, optimizer):
        """Test that invalid epochs raises error."""
        with pytest.raises(ValueError, match="epochs must be positive"):
            optimizer.configure_fm(epochs=0)

    def test_configure_fm_invalid_batch_size(self, optimizer):
        """Test that invalid batch_size raises error."""
        with pytest.raises(ValueError, match="batch_size must be positive"):
            optimizer.configure_fm(batch_size=0)

    def test_configure_fm_invalid_learning_rate(self, optimizer):
        """Test that invalid learning_rate raises error."""
        with pytest.raises(ValueError, match="learning_rate must be positive"):
            optimizer.configure_fm(learning_rate=0)

    def test_configure_fm_invalid_l2_reg(self, optimizer):
        """Test that invalid l2_reg raises error."""
        with pytest.raises(ValueError, match="l2_reg must be non-negative"):
            optimizer.configure_fm(l2_reg=-0.1)

    def test_configure_fm_used_in_optimization(self):
        """Test that FM configuration is used during optimization."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=0,
            max_value=3,
        )
        builder = AEBuilder(space, latent_dim=6, seed=42)
        builder.train(space.sample_random(30), epochs=5)

        optimizer = Optimizer(
            space=space,
            builder=builder,
            objective=lambda sol: sum(sol),
            solver=MockSolver(latent_dim=6),
        )

        # Configure FM with custom k
        optimizer.configure_fm(k=4, epochs=10)

        # Add data and run
        optimizer.add_initial_data(space.sample_random(10))
        optimizer.optimize(num_iterations=1)

        # Check that FM was created with configured k
        assert optimizer._fm is not None
        assert optimizer._fm.k == 4


class TestOptimizerRepr:
    """Tests for Optimizer string representation."""

    def test_repr_empty(self):
        """Test repr before any data."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=0,
            max_value=5,
        )
        builder = AEBuilder(space, latent_dim=6, seed=42)
        builder.train(space.sample_random(20), epochs=5)

        opt = Optimizer(
            space=space,
            builder=builder,
            objective=lambda sol: sum(sol),
            solver=MockSolver(latent_dim=6),
        )

        repr_str = repr(opt)
        assert "Optimizer" in repr_str
        assert "n_trials=0" in repr_str

    def test_repr_with_data(self):
        """Test repr with data."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=0,
            max_value=5,
        )
        builder = AEBuilder(space, latent_dim=6, seed=42)
        builder.train(space.sample_random(20), epochs=5)

        opt = Optimizer(
            space=space,
            builder=builder,
            objective=lambda sol: sum(sol),
            solver=MockSolver(latent_dim=6),
        )

        opt.add_initial_data([[0, 0, 0], [1, 1, 1]])

        repr_str = repr(opt)
        assert "n_trials=2" in repr_str
        assert "best_value=0.0000" in repr_str
