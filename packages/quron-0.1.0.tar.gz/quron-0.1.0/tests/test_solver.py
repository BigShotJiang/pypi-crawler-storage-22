"""
Tests for quron.solver module.
"""

import pytest
import numpy as np

from quron.solver import Solver, AmplifySolver, DWaveSolver


# Check if SDKs are available
try:
    import amplify
    HAS_AMPLIFY = True
except ImportError:
    HAS_AMPLIFY = False

try:
    import dimod
    import dwave.system
    HAS_DWAVE = True
except ImportError:
    HAS_DWAVE = False


class TestSolverAbstract:
    """Tests for Solver abstract base class."""

    def test_cannot_instantiate_abstract(self):
        """Test that Solver cannot be instantiated directly."""
        with pytest.raises(TypeError):
            Solver()

    def test_subclass_must_implement_solve_qubo(self):
        """Test that subclasses must implement solve_qubo."""

        class IncompleteSolver(Solver):
            pass

        with pytest.raises(TypeError):
            IncompleteSolver()


class TestAmplifySolverInit:
    """Tests for AmplifySolver initialization."""

    @pytest.mark.skipif(not HAS_AMPLIFY, reason="amplify not installed")
    def test_init_valid(self):
        """Test valid initialization."""
        solver = AmplifySolver(token="my-token", time_limit=10.0, backend="fixstars")
        assert solver.token == "my-token"
        assert solver.time_limit == 10.0
        assert solver.backend == "fixstars"

    @pytest.mark.skipif(not HAS_AMPLIFY, reason="amplify not installed")
    def test_init_defaults(self):
        """Test initialization with default parameters."""
        solver = AmplifySolver(token="my-token")
        assert solver.token == "my-token"
        assert solver.time_limit == 1000.0  # default 1000ms
        assert solver.backend is None

    @pytest.mark.skipif(not HAS_AMPLIFY, reason="amplify not installed")
    def test_init_empty_token(self):
        """Test that empty token raises error."""
        with pytest.raises(ValueError, match="token must be provided"):
            AmplifySolver(token="")

    @pytest.mark.skipif(not HAS_AMPLIFY, reason="amplify not installed")
    def test_init_extra_kwargs(self):
        """Test that extra kwargs are stored."""
        solver = AmplifySolver(
            token="my-token",
            time_limit=5.0,
            custom_param="value",
        )
        assert solver._extra_config.get("custom_param") == "value"

    @pytest.mark.skipif(HAS_AMPLIFY, reason="amplify is installed")
    def test_init_without_amplify_raises_import_error(self):
        """Test that initializing without amplify raises ImportError."""
        with pytest.raises(ImportError, match="amplify package is required"):
            AmplifySolver(token="test-token")


class TestAmplifySolverRepr:
    """Tests for AmplifySolver string representation."""

    @pytest.mark.skipif(not HAS_AMPLIFY, reason="amplify not installed")
    def test_repr_hides_token(self):
        """Test that repr hides the token value."""
        solver = AmplifySolver(token="secret-token-123")
        repr_str = repr(solver)

        assert "AmplifySolver" in repr_str
        assert "secret-token-123" not in repr_str
        assert "***" in repr_str

    @pytest.mark.skipif(not HAS_AMPLIFY, reason="amplify not installed")
    def test_repr_shows_config(self):
        """Test that repr shows configuration."""
        solver = AmplifySolver(token="test", time_limit=5.0, backend="my-backend")
        repr_str = repr(solver)

        assert "time_limit=5.0" in repr_str
        assert "my-backend" in repr_str


class TestDWaveSolverInit:
    """Tests for DWaveSolver initialization."""

    @pytest.mark.skipif(not HAS_DWAVE, reason="dwave-ocean-sdk not installed")
    def test_init_valid(self):
        """Test valid initialization."""
        solver = DWaveSolver(
            api_token="my-token",
            solver_name="DW_2000Q_6",
            chain_strength=1.5,
        )
        assert solver.api_token == "my-token"
        assert solver.solver_name == "DW_2000Q_6"
        assert solver.chain_strength == 1.5

    @pytest.mark.skipif(not HAS_DWAVE, reason="dwave-ocean-sdk not installed")
    def test_init_defaults(self):
        """Test initialization with default parameters."""
        solver = DWaveSolver(api_token="my-token")
        assert solver.api_token == "my-token"
        assert solver.solver_name is None
        assert solver.chain_strength is None
        assert solver.use_hybrid is True

    @pytest.mark.skipif(not HAS_DWAVE, reason="dwave-ocean-sdk not installed")
    def test_init_empty_token(self):
        """Test that empty token raises error."""
        with pytest.raises(ValueError, match="api_token must be provided"):
            DWaveSolver(api_token="")

    @pytest.mark.skipif(not HAS_DWAVE, reason="dwave-ocean-sdk not installed")
    def test_init_extra_kwargs(self):
        """Test that extra kwargs are stored."""
        solver = DWaveSolver(
            api_token="my-token",
            num_spin_reversal_transforms=5,
        )
        assert solver._extra_config.get("num_spin_reversal_transforms") == 5

    @pytest.mark.skipif(HAS_DWAVE, reason="dwave-ocean-sdk is installed")
    def test_init_without_dwave_raises_import_error(self):
        """Test that initializing without dwave raises ImportError."""
        with pytest.raises(ImportError, match="dwave-ocean-sdk package is required"):
            DWaveSolver(api_token="test-token")


class TestDWaveSolverRepr:
    """Tests for DWaveSolver string representation."""

    @pytest.mark.skipif(not HAS_DWAVE, reason="dwave-ocean-sdk not installed")
    def test_repr_hides_token(self):
        """Test that repr hides the token value."""
        solver = DWaveSolver(api_token="my-secret-token")
        repr_str = repr(solver)

        assert "DWaveSolver" in repr_str
        assert "my-secret-token" not in repr_str
        assert "***" in repr_str

    @pytest.mark.skipif(not HAS_DWAVE, reason="dwave-ocean-sdk not installed")
    def test_repr_shows_config(self):
        """Test that repr shows configuration."""
        solver = DWaveSolver(
            api_token="test",
            solver_name="Advantage_system4.1",
            chain_strength=2.0,
        )
        repr_str = repr(solver)

        assert "Advantage_system4.1" in repr_str
        assert "chain_strength=2.0" in repr_str


# =============================================================================
# Integration tests - require actual API tokens
# Run with: pytest tests/test_solver.py -m integration
# =============================================================================

@pytest.mark.integration
class TestAmplifySolverIntegration:
    """Integration tests for AmplifySolver with real API."""

    @pytest.fixture
    def amplify_token(self):
        """Get Amplify token from environment variable."""
        import os
        token = os.environ.get("AMPLIFY_TOKEN")
        if not token:
            pytest.skip("AMPLIFY_TOKEN environment variable not set")
        return token

    @pytest.mark.skipif(not HAS_AMPLIFY, reason="amplify not installed")
    def test_solve_simple_qubo(self, amplify_token):
        """Test solving a simple QUBO problem."""
        solver = AmplifySolver(token=amplify_token, time_limit=1000)

        # Simple QUBO: minimize -x0 - x1 + 2*x0*x1
        # Optimal solution: x0=1, x1=0 or x0=0, x1=1 (energy=-1)
        Q = np.array([[-1, 1], [1, -1]], dtype=np.float64)

        results = solver.solve_qubo(Q, num_reads=5)

        assert len(results) == 5
        for result in results:
            assert "sample" in result
            assert "energy" in result
            assert result["sample"].shape == (2,)
            assert set(result["sample"]).issubset({0, 1})

        # Best solution should have energy -1
        assert results[0]["energy"] == -1.0

    @pytest.mark.skipif(not HAS_AMPLIFY, reason="amplify not installed")
    def test_solve_larger_qubo(self, amplify_token):
        """Test solving a larger QUBO problem."""
        solver = AmplifySolver(token=amplify_token, time_limit=3000)

        n = 10
        np.random.seed(42)
        Q = np.random.randn(n, n)
        Q = (Q + Q.T) / 2  # Make symmetric

        results = solver.solve_qubo(Q, num_reads=10)

        assert len(results) == 10
        for result in results:
            assert result["sample"].shape == (n,)

        # Results should be sorted by energy
        energies = [r["energy"] for r in results]
        assert energies == sorted(energies)


@pytest.mark.integration
class TestDWaveSolverIntegration:
    """Integration tests for DWaveSolver with real API."""

    @pytest.fixture
    def dwave_token(self):
        """Get D-Wave token from environment variable."""
        import os
        token = os.environ.get("DWAVE_TOKEN")
        if not token:
            pytest.skip("DWAVE_TOKEN environment variable not set")
        return token

    @pytest.mark.skipif(not HAS_DWAVE, reason="dwave-ocean-sdk not installed")
    def test_solve_simple_qubo_hybrid(self, dwave_token):
        """Test solving a simple QUBO problem with hybrid sampler."""
        solver = DWaveSolver(api_token=dwave_token, use_hybrid=True)

        # Simple QUBO: minimize -x0 - x1 + 2*x0*x1
        Q = np.array([[-1, 1], [1, -1]], dtype=np.float64)

        results = solver.solve_qubo(Q, num_reads=5)

        assert len(results) >= 1  # Hybrid may return fewer samples
        for result in results:
            assert "sample" in result
            assert "energy" in result
            assert result["sample"].shape == (2,)
            assert set(result["sample"]).issubset({0, 1})

    @pytest.mark.skipif(not HAS_DWAVE, reason="dwave-ocean-sdk not installed")
    def test_solve_larger_qubo_hybrid(self, dwave_token):
        """Test solving a larger QUBO problem with hybrid sampler."""
        solver = DWaveSolver(api_token=dwave_token, use_hybrid=True)

        n = 20
        np.random.seed(42)
        Q = np.random.randn(n, n)
        Q = (Q + Q.T) / 2

        results = solver.solve_qubo(Q, num_reads=10)

        assert len(results) >= 1
        for result in results:
            assert result["sample"].shape == (n,)

        # Results should be sorted by energy
        energies = [r["energy"] for r in results]
        assert energies == sorted(energies)


# =============================================================================
# Validation tests (don't require SDK)
# =============================================================================

class TestSolverValidation:
    """Tests for QUBO validation shared by all solvers."""

    def test_validate_qubo_helper(self):
        """Test the _validate_qubo helper method."""
        # Create a concrete subclass for testing
        class TestSolver(Solver):
            def solve_qubo(self, Q, num_reads, auto_scale=True, **kwargs):
                self._validate_qubo(Q)
                return []

        solver = TestSolver()

        # Valid QUBO
        Q = np.array([[1, -1], [-1, 2]])
        solver._validate_qubo(Q)  # Should not raise

        # Not an array
        with pytest.raises(ValueError, match="must be a numpy array"):
            solver._validate_qubo([[1, 2], [2, 1]])

        # Not 2D
        with pytest.raises(ValueError, match="must be 2D"):
            solver._validate_qubo(np.array([1, 2, 3]))

        # Not square
        with pytest.raises(ValueError, match="must be square"):
            solver._validate_qubo(np.array([[1, 2, 3], [4, 5, 6]]))

        # Empty
        with pytest.raises(ValueError, match="must not be empty"):
            solver._validate_qubo(np.empty((0, 0)))

    def test_compute_energy_helper(self):
        """Test the _compute_energy helper method."""
        class TestSolver(Solver):
            def solve_qubo(self, Q, num_reads, auto_scale=True, **kwargs):
                return []

        solver = TestSolver()

        Q = np.array([[2, -1], [-1, 3]], dtype=np.float64)

        # x = [0, 0] -> energy = 0
        assert solver._compute_energy(np.array([0, 0]), Q) == 0.0

        # x = [1, 0] -> energy = 2
        assert solver._compute_energy(np.array([1, 0]), Q) == 2.0

        # x = [0, 1] -> energy = 3
        assert solver._compute_energy(np.array([0, 1]), Q) == 3.0

        # x = [1, 1] -> energy = 2 - 1 - 1 + 3 = 3
        assert solver._compute_energy(np.array([1, 1]), Q) == 3.0
