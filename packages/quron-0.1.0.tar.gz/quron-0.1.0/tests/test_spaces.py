"""
Tests for quron.spaces module.
"""

import pytest
import numpy as np
from quron.spaces import Variable


class TestVariableInteger:
    """Tests for Variable with integer variables."""

    def test_init_valid_integer(self):
        """Test valid initialization for integer type."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=10
        )
        assert space.length == 5
        assert space.var_type == "integer"
        assert space.min_value == 0
        assert space.max_value == 10
        assert space.vocab_size == 11

    def test_init_missing_params_integer(self):
        """Test that missing min/max_value raises error."""
        with pytest.raises(ValueError, match="min_value and max_value are required"):
            Variable(length=5, var_type="integer")

        with pytest.raises(ValueError, match="min_value and max_value are required"):
            Variable(length=5, var_type="integer", min_value=0)

    def test_init_invalid_range(self):
        """Test that min_value > max_value raises error."""
        with pytest.raises(ValueError, match="must be <="):
            Variable(
                length=5,
                var_type="integer",
                min_value=10,
                max_value=5
            )

    def test_sample_random_integer(self):
        """Test random sampling for integer type."""
        space = Variable(
            length=10,
            var_type="integer",
            min_value=5,
            max_value=15
        )
        samples = space.sample_random(100)

        assert len(samples) == 100
        assert all(len(sol) == 10 for sol in samples)

        # Check all values are in range
        for sol in samples:
            assert all(5 <= val <= 15 for val in sol)
            assert all(isinstance(val, (int, np.integer)) for val in sol)

    def test_sample_random_empty(self):
        """Test sampling with n=0."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=10
        )
        samples = space.sample_random(0)
        assert samples == []

    def test_validate_integer_valid(self):
        """Test validation of valid integer solutions."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        assert space.validate([0, 1, 2]) is True
        assert space.validate([2, 2, 0]) is True
        assert space.validate([1, 1, 1]) is True

    def test_validate_integer_invalid_range(self):
        """Test validation fails for out-of-range values."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        assert space.validate([0, 1, 3]) is False  # 3 is out of range
        assert space.validate([-1, 1, 2]) is False  # -1 is out of range

    def test_validate_integer_invalid_length(self):
        """Test validation fails for wrong length."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        assert space.validate([0, 1]) is False  # too short
        assert space.validate([0, 1, 2, 3]) is False  # too long

    def test_validate_integer_invalid_type(self):
        """Test validation fails for non-integer values."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        assert space.validate([0.5, 1, 2]) is False
        assert space.validate(["a", "b", "c"]) is False
        assert space.validate("not a list") is False

    def test_to_internal_ids_integer(self):
        """Test conversion to internal IDs for integer type."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=5,
            max_value=7
        )
        assert space.to_internal_ids([5, 6, 7]) == [0, 1, 2]
        assert space.to_internal_ids([7, 5, 6]) == [2, 0, 1]

    def test_from_internal_ids_integer(self):
        """Test conversion from internal IDs for integer type."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=5,
            max_value=7
        )
        assert space.from_internal_ids([0, 1, 2]) == [5, 6, 7]
        assert space.from_internal_ids([2, 0, 1]) == [7, 5, 6]

    def test_roundtrip_integer(self):
        """Test round-trip conversion for integer type."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=10,
            max_value=20
        )
        original = [10, 15, 20, 12, 18]
        ids = space.to_internal_ids(original)
        recovered = space.from_internal_ids(ids)
        assert recovered == original

    def test_to_internal_ids_invalid_solution(self):
        """Test that invalid solutions raise error in to_internal_ids."""
        space = Variable(
            length=3,
            var_type="integer",
            min_value=0,
            max_value=2
        )
        with pytest.raises(ValueError, match="Invalid solution"):
            space.to_internal_ids([0, 1, 3])  # out of range


class TestVariableCategory:
    """Tests for Variable with category variables."""

    def test_init_valid_category(self):
        """Test valid initialization for category type."""
        space = Variable(
            length=5,
            var_type="category",
            labels=["A", "B", "C"]
        )
        assert space.length == 5
        assert space.var_type == "category"
        assert space.labels == ["A", "B", "C"]
        assert space.vocab_size == 3

    def test_init_missing_labels(self):
        """Test that missing labels raises error."""
        with pytest.raises(ValueError, match="labels are required"):
            Variable(length=5, var_type="category")

        with pytest.raises(ValueError, match="labels are required"):
            Variable(length=5, var_type="category", labels=[])

    def test_sample_random_category(self):
        """Test random sampling for category type."""
        space = Variable(
            length=10,
            var_type="category",
            labels=["Red", "Green", "Blue"]
        )
        samples = space.sample_random(50)

        assert len(samples) == 50
        assert all(len(sol) == 10 for sol in samples)

        # Check all values are valid labels
        valid_labels = {"Red", "Green", "Blue"}
        for sol in samples:
            assert all(val in valid_labels for val in sol)

    def test_validate_category_valid(self):
        """Test validation of valid category solutions."""
        space = Variable(
            length=3,
            var_type="category",
            labels=["X", "Y", "Z"]
        )
        assert space.validate(["X", "Y", "Z"]) is True
        assert space.validate(["Z", "Z", "X"]) is True
        assert space.validate(["Y", "Y", "Y"]) is True

    def test_validate_category_invalid_label(self):
        """Test validation fails for invalid labels."""
        space = Variable(
            length=3,
            var_type="category",
            labels=["X", "Y", "Z"]
        )
        assert space.validate(["X", "Y", "W"]) is False  # W is not a valid label
        assert space.validate(["A", "B", "C"]) is False

    def test_validate_category_invalid_length(self):
        """Test validation fails for wrong length."""
        space = Variable(
            length=3,
            var_type="category",
            labels=["X", "Y", "Z"]
        )
        assert space.validate(["X", "Y"]) is False  # too short
        assert space.validate(["X", "Y", "Z", "X"]) is False  # too long

    def test_to_internal_ids_category(self):
        """Test conversion to internal IDs for category type."""
        space = Variable(
            length=3,
            var_type="category",
            labels=["A", "B", "C"]
        )
        assert space.to_internal_ids(["A", "B", "C"]) == [0, 1, 2]
        assert space.to_internal_ids(["C", "A", "B"]) == [2, 0, 1]
        assert space.to_internal_ids(["B", "B", "B"]) == [1, 1, 1]

    def test_from_internal_ids_category(self):
        """Test conversion from internal IDs for category type."""
        space = Variable(
            length=3,
            var_type="category",
            labels=["A", "B", "C"]
        )
        assert space.from_internal_ids([0, 1, 2]) == ["A", "B", "C"]
        assert space.from_internal_ids([2, 0, 1]) == ["C", "A", "B"]
        assert space.from_internal_ids([1, 1, 1]) == ["B", "B", "B"]

    def test_roundtrip_category(self):
        """Test round-trip conversion for category type."""
        space = Variable(
            length=5,
            var_type="category",
            labels=["Red", "Green", "Blue", "Yellow"]
        )
        original = ["Red", "Blue", "Yellow", "Red", "Green"]
        ids = space.to_internal_ids(original)
        recovered = space.from_internal_ids(ids)
        assert recovered == original

    def test_from_internal_ids_invalid_id(self):
        """Test that invalid IDs raise error in from_internal_ids."""
        space = Variable(
            length=3,
            var_type="category",
            labels=["A", "B", "C"]
        )
        with pytest.raises(ValueError, match="out of range"):
            space.from_internal_ids([0, 1, 3])  # 3 is out of range


class TestVariableGeneral:
    """General tests for Variable."""

    def test_init_invalid_length(self):
        """Test that non-positive length raises error."""
        with pytest.raises(ValueError, match="must be positive"):
            Variable(length=0, var_type="integer", min_value=0, max_value=10)

        with pytest.raises(ValueError, match="must be positive"):
            Variable(length=-5, var_type="integer", min_value=0, max_value=10)

    def test_init_invalid_var_type(self):
        """Test that invalid var_type raises error."""
        with pytest.raises(ValueError, match="must be 'integer' or 'category'"):
            Variable(length=5, var_type="float", min_value=0, max_value=10)

    def test_repr_integer(self):
        """Test string representation for integer type."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=0,
            max_value=10
        )
        repr_str = repr(space)
        assert "Variable" in repr_str
        assert "length=5" in repr_str
        assert "var_type='integer'" in repr_str
        assert "min_value=0" in repr_str
        assert "max_value=10" in repr_str

    def test_repr_category(self):
        """Test string representation for category type."""
        space = Variable(
            length=5,
            var_type="category",
            labels=["A", "B", "C"]
        )
        repr_str = repr(space)
        assert "Variable" in repr_str
        assert "length=5" in repr_str
        assert "var_type='category'" in repr_str
        assert "labels=" in repr_str

    def test_vocab_size_integer(self):
        """Test vocab_size property for integer type."""
        space = Variable(
            length=5,
            var_type="integer",
            min_value=3,
            max_value=7
        )
        assert space.vocab_size == 5  # 3, 4, 5, 6, 7

    def test_vocab_size_category(self):
        """Test vocab_size property for category type."""
        space = Variable(
            length=5,
            var_type="category",
            labels=["A", "B", "C", "D"]
        )
        assert space.vocab_size == 4
