from supabase import create_client


class ADB:

    def __init__(self, url, key):
        self.db = create_client(url, key)

    # ========= AUTH =========

    def a_kayit_ol(self, email, sifre):
        return self.db.auth.sign_up({
            "email": email,
            "password": sifre
        })

    def a_giris_yap(self, email, sifre):
        sonuc = self.db.auth.sign_in_with_password({
            "email": email,
            "password": sifre
        })
        return sonuc.user.id   # uid döner

    # ========= TABLO =========

    def add(self, tablo, uid, **veriler):
        """
        Örnek:
        add("users_data", uid, username="Ali Kaya", skor=34)
        """
        veriler["user_id"] = uid
        return self.db.table(tablo).insert(veriler).execute()

    def get(self, tablo, uid):
        return self.db.table(tablo) \
            .select("*") \
            .eq("user_id", uid) \
            .single() \
            .execute().data

    def update(self, tablo, uid, **veriler):
        return self.db.table(tablo) \
            .update(veriler) \
            .eq("user_id", uid) \
            .execute()