from supabase import create_client
from threading import Thread


class ADB:

    def __init__(self, url, key):
        self.db = create_client(url, key)
        self.current_uid = None

    # ================= THREAD SİSTEM =================

    def _async(self, func, callback=None, verify=None):
        def run():
            try:
                sonuc = func()
                if verify is not None:
                    verify.clear()
                    verify.append(True)
                if callback:
                    callback(sonuc)
            except Exception as e:
                if verify is not None:
                    verify.clear()
                    verify.append(False)
                print("ADB HATA:", e)

        Thread(target=run, daemon=True).start()

    # ================= AUTH =================

    def a_kayit_ol(self, email, sifre, callback=None, verify=None):
        self._async(
            lambda: self.db.auth.sign_up({
                "email": email,
                "password": sifre
            }),
            callback,
            verify
        )

    def a_giris_yap(self, email, sifre, callback=None, verify=None):

        def islem():
            res = self.db.auth.sign_in_with_password({
                "email": email,
                "password": sifre
            })
            self.current_uid = res.user.id
            return self.current_uid

        self._async(islem, callback, verify)

    def cikis_yap(self, verify=None):

        def islem():
            self.db.auth.sign_out()
            self.current_uid = None

        self._async(islem, verify=verify)

    # ================= VERİ TABANI =================

    def add(self, tablo, uid=None, callback=None, verify=None, **veriler):

        def islem():
            uid_kullan = uid if uid is not None else self.current_uid
            if uid_kullan is None:
                raise Exception("UID yok, önce giriş yap")

            veriler["user_id"] = uid_kullan
            return self.db.table(tablo).insert(veriler).execute()

        self._async(islem, callback, verify)

    def get(self, tablo, uid=None, callback=None, verify=None):

        def islem():
            uid_kullan = uid if uid is not None else self.current_uid
            if uid_kullan is None:
                raise Exception("UID yok")

            return self.db.table(tablo)\
                .select("*")\
                .eq("user_id", uid_kullan)\
                .execute().data

        self._async(islem, callback, verify)

    def update(self, tablo, uid=None, callback=None, verify=None, **veriler):

        def islem():
            uid_kullan = uid if uid is not None else self.current_uid
            if uid_kullan is None:
                raise Exception("UID yok")

            return self.db.table(tablo)\
                .update(veriler)\
                .eq("user_id", uid_kullan)\
                .execute()

        self._async(islem, callback, verify)

    def delete(self, tablo, uid=None, callback=None, verify=None):

        def islem():
            uid_kullan = uid if uid is not None else self.current_uid
            if uid_kullan is None:
                raise Exception("UID yok")

            return self.db.table(tablo)\
                .delete()\
                .eq("user_id", uid_kullan)\
                .execute()

        self._async(islem, callback, verify)


# ================= KULLANIMI DAHA BASİT OLSUN DİYE =================

_db = None


def baslat(url, key):
    global _db
    _db = ADB(url, key)


def a_kayit_ol(email, sifre, callback=None, verify=None):
    _db.a_kayit_ol(email, sifre, callback, verify)


def a_giris_yap(email, sifre, callback=None, verify=None):
    _db.a_giris_yap(email, sifre, callback, verify)


def cikis_yap(verify=None):
    _db.cikis_yap(verify)


def add(tablo, uid=None, callback=None, verify=None, **veriler):
    _db.add(tablo, uid, callback, verify, **veriler)


def get(tablo, uid=None, callback=None, verify=None):
    _db.get(tablo, uid, callback, verify)


def update(tablo, uid=None, callback=None, verify=None, **veriler):
    _db.update(tablo, uid, callback, verify, **veriler)


def delete(tablo, uid=None, callback=None, verify=None):
    _db.delete(tablo, uid, callback, verify)