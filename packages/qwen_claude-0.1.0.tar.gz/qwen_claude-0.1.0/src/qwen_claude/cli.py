#!/usr/bin/env python3
import site
import sys
import json
import os
import time
import shutil
import subprocess
from pathlib import Path
from typing import Optional


# ------------------- CONFIG (EDIT IF NEEDED) -------------------
QWEN_OAUTH = Path(os.environ["USERPROFILE"]) / ".qwen" / "oauth_creds.json"
CCR_CONFIG = Path(os.environ["USERPROFILE"]) / ".claude-code-router" / "config.json"
SCHEMA_FILE = Path(__file__).parent / "schema.json"

REFRESH_BUFFER_SECONDS = 120
RESTART_CCR_ON_CHANGE = True
RUN_CCR_CODE = True
# ---------------------------------------------------------------


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def save_json_atomic(path: Path, data: dict) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    tmp.replace(path)


def is_expiring_soon(oauth: dict, buffer_seconds: int) -> bool:
    exp_ms = int(oauth.get("expiry_date", 0))
    if exp_ms <= 0:
        return True
    exp_s = exp_ms / 1000.0
    return time.time() >= (exp_s - buffer_seconds)


def which(cmd: str) -> Optional[str]:
    return shutil.which(cmd)


# ------------------- DEPENDENCY & SCHEMA CHECKS -------------------
def verify_required_tools() -> None:
    requirements = [
        {
            "name": "qwen",
            "binary": "qwen",
            "install": "npm install -g @qwen-code/qwen-code@latest",
        },
        {
            "name": "claude-code-router",
            "binary": "ccr",
            "install": "npm install -g @musistudio/claude-code-router",
        },
        {
            "name": "claude",
            "binary": "claude",
            "install": "npm install -g @anthropic-ai/claude-code",
        },
    ]
    for req in requirements:
        path = which(req["binary"])
        if not path:
            print(
                f"[ERR] Required package '{req['name']}' is not installed.\n      Install: {req['install']}"
            )
            raise SystemExit(1)
        print(f"[OK] Found {req['name']} → {path}")


def schema_validation() -> None:
    """
    Checks for api_base_url within the 'qwen' provider in config.json.
    """
    target_url = "https://portal.qwen.ai/v1/chat/completions"

    if not SCHEMA_FILE.exists():
        print(f"[ERR] Schema file missing at {SCHEMA_FILE}.")
        return

    if not CCR_CONFIG.exists():
        print(f"[INFO] {CCR_CONFIG.name} missing. Initializing from schema...")
        save_json_atomic(CCR_CONFIG, load_json(SCHEMA_FILE))
        return

    try:
        config_data = load_json(CCR_CONFIG)
    except Exception:
        config_data = {}

    # Find the qwen provider block
    providers = config_data.get("Providers", [])
    qwen_provider = next(
        (p for p in providers if isinstance(p, dict) and p.get("name") == "qwen"), None
    )

    needs_reset = False
    if not qwen_provider:
        print("[INFO] 'qwen' provider block missing in config.")
        needs_reset = True
    elif "api_base_url" not in qwen_provider:
        print("[INFO] 'api_base_url' missing in qwen provider config.")
        needs_reset = True
    elif qwen_provider.get("api_base_url") != target_url:
        print(f"[INFO] URL mismatch. Found: {qwen_provider.get('api_base_url')}")
        needs_reset = True

    if needs_reset:
        print(f"[INFO] Rewriting {CCR_CONFIG.name} using {SCHEMA_FILE.name}...")
        save_json_atomic(CCR_CONFIG, load_json(SCHEMA_FILE))
    else:
        print("[OK] Schema validation passed.")


# -------------------------------------------------------------


def run_windows_cmd(exe_path: str, args: list[str], quiet: bool = True) -> int:
    exe_lower = exe_path.lower()
    stdout = subprocess.DEVNULL if quiet else None
    stderr = subprocess.DEVNULL if quiet else None

    if exe_lower.endswith(".ps1"):
        cmd = [
            "powershell",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            exe_path,
            *args,
        ]
        return subprocess.run(cmd, check=False, stdout=stdout, stderr=stderr).returncode
    if exe_lower.endswith(".cmd") or exe_lower.endswith(".bat"):
        cmdline = subprocess.list2cmdline([exe_path, *args])
        return subprocess.run(
            ["cmd.exe", "/d", "/s", "/c", cmdline],
            check=False,
            stdout=stdout,
            stderr=stderr,
        ).returncode
    return subprocess.run(
        [exe_path, *args], check=False, stdout=stdout, stderr=stderr
    ).returncode


def force_qwen_refresh(qwen_path: str) -> None:
    run_windows_cmd(qwen_path, ["--version"], quiet=True)


def update_ccr_api_key(ccr_config: Path, new_token: str) -> bool:
    cfg = load_json(ccr_config)
    providers = cfg.get("Providers", [])
    changed = False
    for p in providers:
        if isinstance(p, dict) and p.get("name") == "qwen":
            if p.get("api_key") != new_token:
                p["api_key"] = new_token
                changed = True

    if changed:
        save_json_atomic(ccr_config, cfg)
    return changed


def print_install_info():
    print("[INFO] qwen-claude installed at:")
    for p in site.getsitepackages():
        if "qwen_claude" in p:
            print("   ", p)

    print("[INFO] Executable location:")
    print("   ", Path(sys.executable).parent)


def main() -> int:
    print_install_info()
    verify_required_tools()
    schema_validation()

    qwen_path = which("qwen")
    ccr_path = which("ccr")

    # Auth logic
    if not QWEN_OAUTH.exists():
        print("[INFO] Launching Qwen for authentication...")
        proc = subprocess.Popen([qwen_path])
        while not QWEN_OAUTH.exists():
            if proc.poll() is not None:
                return 6
            time.sleep(1)
        proc.terminate()

    oauth = load_json(QWEN_OAUTH)
    if is_expiring_soon(oauth, REFRESH_BUFFER_SECONDS):
        force_qwen_refresh(qwen_path)
        oauth = load_json(QWEN_OAUTH)

    access_token = oauth.get("access_token")
    changed = update_ccr_api_key(CCR_CONFIG, access_token)

    # RESTART LOGIC FIX: Only restart once
    ccr_needs_restart = changed and RESTART_CCR_ON_CHANGE

    if ccr_needs_restart:
        print("[OK] Token updated. Restarting CCR...")
        run_windows_cmd(ccr_path, ["restart"], quiet=False)
    else:
        print("[OK] CCR config is up to date.")

    if RUN_CCR_CODE and ccr_path:
        # If we didn't just restart it above, we might need to restart/start it here
        # or just run 'code'. Since you had a restart here before, I'll keep it
        # but ensure it doesn't double-trigger if changed was true.
        if not ccr_needs_restart:
            print("[INFO] Starting CCR...")
            run_windows_cmd(ccr_path, ["restart"], quiet=False)

        print("[INFO] Launching Claude Code...")
        run_windows_cmd(ccr_path, ["code"], quiet=False)

    return 0


def run():
    raise SystemExit(main())


if __name__ == "__main__":
    raise SystemExit(main())
