This is looking like a high-quality production tool. Since this is now a public package on PyPI, I’ve updated the `README.md` to prioritize the standard installation method while keeping the technical details that make your project look professional.

---

# 🚀 Qwen-Claude Bridge

[![PyPI version](https://img.shields.io/pypi/v/qwen-claude.svg)](https://pypi.org/project/qwen-claude/)
[![Python Version](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Qwen-Claude** is a high-performance automation CLI that bridges the gap between [Qwen’s](https://qwenlm.github.io/) authentication and the [Claude Code Router (CCR)](https://github.com/musistudio/claude-code-router). It automates the extraction of OAuth tokens and manages configuration synchronization, allowing you to use Qwen models within Claude Code seamlessly.

## ✨ Features

* **🔄 Automated Token Sync:** Extracts the latest Qwen OAuth access token and injects it directly into your CCR configuration.
* **🛡️ Smart Schema Validation:** Ensures your `config.json` is always valid and correctly points to the Qwen portal.
* **⚡ Dependency Guard:** Automatically verifies that `qwen`, `ccr`, and `claude` CLIs are installed and accessible in your PATH.
* **🪟 Windows Optimized:** Built-in support for Windows execution logic, handling `.ps1`, `.bat`, and `.cmd` wrappers natively.
* **🤖 Intelligent Fallback:** Detects expired sessions, triggers an interactive login when needed, and resumes the workflow.

---

## 🛠️ Installation

Install the package directly from PyPI:

```bash
pip install qwen-claude
```

### Required Global Tools

The bridge coordinates with the following Node.js-based tools. Ensure they are installed on your system:

| Tool | Purpose | Install Command |
| --- | --- | --- |
| **Qwen CLI** | Auth Provider | `npm install -g @qwen-code/qwen-code@latest` |
| **CCR** | Router Engine | `npm install -g @musistudio/claude-code-router` |
| **Claude** | AI Interface | `npm install -g @anthropic-ai/claude-code` |

---

## 🚀 Usage

Launch the bridge using the `qc` command. This will validate your environment, refresh tokens if necessary, and start your Claude Code session:

```bash
qc
```

### Checking Version

To check your current version of the bridge:

```bash
qc -v
# OR
qc --version
```

### Workflow Overview

1. **Verify:** Checks for the presence of required global binaries.
2. **Validate:** Ensures `~/.claude-code-router/config.json` matches the standard schema.
3. **Refresh:** If the token expires in < 120 seconds, it triggers a refresh via the Qwen CLI.
4. **Inject:** Updates the CCR configuration with the new `access_token`.
5. **Execute:** Restarts the CCR service and enters the Claude Code environment.

---

## ⚙️ Configuration

The bridge initializes your router using a pre-defined schema optimized for Qwen 3 Coder:

```json
{
  "Providers": [
    {
      "name": "qwen",
      "api_base_url": "https://portal.qwen.ai/v1/chat/completions",
      "models": ["qwen3-coder-plus"]
    }
  ],
  "Router": {
    "default": "qwen,qwen3-coder-plus",
    "think": "qwen,qwen3-coder-plus"
  }
}
```

---

## 📁 Project Structure


```text
QWEN_CLAUDE
├── .github/
│   └── workflows/
│       └── publish.yml    # CI/CD Pipeline
├── src/
│   └── qwen_claude/
│       ├── __init__.py    # Version metadata
│       ├── cli.py         # Automation logic
│       └── schema.json    # Default CCR configuration
├── CODE_OF_CONDUCT.md     # Community standards
├── CONTRIBUTING.md        # Contribution guidelines
├── LICENSE                # MIT License
├── pyproject.toml         # Build & Entry points
└── README.md              # Documentation
```

---

## 🤝 Contributing

Contributions are what make the open-source community such an amazing place to learn, inspire, and create. Any contributions you make to **Qwen-Claude** are **greatly appreciated**.

To maintain a high standard of code and community health, please follow these steps:

1. **Read the Guidelines:** Before starting, please review our [CONTRIBUTING.md](https://github.com/SaadKamran0804/qwen-claude/blob/main/CONTRIBUTING.md) for technical instructions and our [CODE_OF_CONDUCT.md](https://github.com/SaadKamran0804/qwen-claude/blob/main/CODE_OF_CONDUCT.md) to understand our community standards.
2. **Fork & Clone:** Fork the repository to your own GitHub account and clone it locally.
3. **Create a Branch:** Dedicated to your fix or feature (`git checkout -b feature/AmazingFeature`).
4. **Develop & Test:** Make your changes and ensure the logic remains robust.
5. **Commit & Push:** Commit your changes with clear messages (`git commit -m 'Add some AmazingFeature'`) and push to your fork.
6. **Open a Pull Request:** Submit your PR against the `main` branch. We will review it as soon as possible!