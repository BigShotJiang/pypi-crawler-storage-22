#!/usr/bin/env python3

from qwen_claude.main import main


def run():
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n[INFO] Interrupted by user. Exiting...")
        raise SystemExit(130)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n[INFO] Interrupted by user. Exiting...")
        raise SystemExit(130)
