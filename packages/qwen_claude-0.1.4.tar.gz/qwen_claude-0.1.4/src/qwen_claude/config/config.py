import os
from pathlib import Path
import json

QWEN_OAUTH = Path(os.environ["USERPROFILE"]) / ".qwen" / "oauth_creds.json"
CCR_CONFIG = Path(os.environ["USERPROFILE"]) / ".claude-code-router" / "config.json"
SCHEMA_FILE = Path(__file__).parent / "schema.json"

REFRESH_BUFFER_SECONDS = 120
RESTART_CCR_ON_CHANGE = True
RUN_CCR_CODE = True


def save_json_atomic(path: Path, data: dict) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    tmp.replace(path)


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)
