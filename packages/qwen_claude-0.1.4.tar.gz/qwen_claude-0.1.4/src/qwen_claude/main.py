from qwen_claude.utils.version import qc_version
from qwen_claude.utils.qwen import launch_qwen, refresh_qwen
from qwen_claude.utils.path import print_install_info, update_ccr_api_key
from qwen_claude.utils.schema_validation import schema_validation
from qwen_claude.utils.tools_validation import verify_required_tools
from qwen_claude.utils.window import which, run_windows_cmd
from qwen_claude.utils.token import force_qwen_refresh, is_expiring_soon, is_old_token
from qwen_claude.config.config import (
    load_json,
    QWEN_OAUTH,
    CCR_CONFIG,
    REFRESH_BUFFER_SECONDS,
    RUN_CCR_CODE,
)


def main() -> int:
    qc_version()
    print_install_info()
    verify_required_tools()
    schema_validation()

    qwen_path = which("qwen")
    ccr_path = which("ccr")

    if not QWEN_OAUTH.exists():
        print(f"[WARN] Qwen oauth file not found: {QWEN_OAUTH}")
        print("[INFO] Launching Qwen for authentication...")
        launch_qwen(qwen_path)

    if not CCR_CONFIG.exists():
        print(f"[ERR] CCR config file not found: {CCR_CONFIG}")
        print("[INFO] Edit CCR_CONFIG in the script to the correct location.")
        return 5

    oauth = load_json(QWEN_OAUTH)

    if is_expiring_soon(oauth, REFRESH_BUFFER_SECONDS):
        print("[INFO] Token expired/near expiry → triggering Qwen refresh...")
        is_old = is_old_token()
        rc = force_qwen_refresh(qwen_path, is_old)

        if rc == 0:
            oauth = load_json(QWEN_OAUTH)
            new_token = oauth.get("access_token")
            if new_token != is_old:
                print("[INFO] Qwen access_token is updated successfully")

    access_token = oauth.get("access_token")
    if is_expiring_soon(oauth, REFRESH_BUFFER_SECONDS) and access_token == is_old:
        print("[WARN] Silent refresh failed. Interactive login required.")

        refresh_qwen(qwen_path)

        # Reload oauth after interactive login
        oauth = load_json(QWEN_OAUTH)
        access_token = oauth.get("access_token")

        if not access_token:
            print("[ERR] access_token still missing after interactive login.")
            return 7

    changed = update_ccr_api_key(CCR_CONFIG, access_token)
    if changed:
        print("[OK] Updated CCR config with latest Qwen access_token.")
    else:
        print("[OK] CCR config already has the latest token.")

    if RUN_CCR_CODE and ccr_path:
        print("[INFO] Restarting CCR...")
        run_windows_cmd(ccr_path, ["restart"], quiet=False)

        print("[INFO] Launching Claude Code via CCR (ccr code)...")
        try:
            run_windows_cmd(ccr_path, ["code"], quiet=False)
        except KeyboardInterrupt:
            print("\n[INFO] CCR session interrupted by user.")
            return 130

    return 0
