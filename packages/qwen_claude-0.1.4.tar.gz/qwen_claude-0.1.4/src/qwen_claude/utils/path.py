import site
import sys
import shutil
from pathlib import Path
from qwen_claude.config.config import (
    load_json,
    save_json_atomic,
)

def print_install_info():
    for p in site.getsitepackages():
        if "qwen_claude" in p:
            print(f"[INFO] Path `{p}`")

    print(f"[INFO] Executable Path: '{Path(sys.executable).parent}'")


def update_ccr_api_key(ccr_config: Path, new_token: str) -> bool:
    cfg = load_json(ccr_config)
    providers = cfg.get("Providers", [])
    if not isinstance(providers, list) or not providers:
        raise RuntimeError("CCR config has no Providers[] array.")

    changed = False
    for p in providers:
        if isinstance(p, dict) and p.get("name") == "qwen":
            if p.get("api_key") != new_token:
                p["api_key"] = new_token
                changed = True

    if changed:
        try:
            shutil.copy2(ccr_config, ccr_config.with_suffix(".json.bak"))
        except Exception:
            pass
        save_json_atomic(ccr_config, cfg)

    return changed
