import subprocess
import time
from qwen_claude.config.config import QWEN_OAUTH, load_json
from qwen_claude.utils.token import is_old_token


def launch_qwen(qwen_path):
    # Launch qwen interactively
    proc = subprocess.Popen(
        [qwen_path], creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
    )

    # Wait for oauth file to appear
    print("[INFO] Waiting for Qwen authentication to complete...")
    while True:
        if QWEN_OAUTH.exists():
            print("[OK] Qwen authentication completed.")
            break

        # If user closed Qwen without authenticating
        if proc.poll() is not None:
            print("[ERR] Qwen exited before authentication completed.")
            return 6

        time.sleep(1)

    # Stop qwen after successful auth
    try:
        subprocess.run(
            ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        print("[INFO] Qwen CLI is Terminated...")
    except Exception:
        pass


def refresh_qwen(qwen_path):
    # Launch qwen interactively
    proc = subprocess.Popen(
        [qwen_path], creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
    )

    oauth = load_json(QWEN_OAUTH)
    new_token = oauth.get("access_token")
    # Wait for oauth file to appear
    print("[INFO] Waiting for Qwen authentication to complete...")
    while True:
        is_old = is_old_token()
        if QWEN_OAUTH.exists() and new_token != is_old:
            print("[OK] Qwen authentication completed.")
            break

        # If user closed Qwen without authenticating
        if proc.poll() is not None:
            print("[ERR] Qwen exited before authentication completed.")
            return 6

        time.sleep(1)

    # Stop qwen after successful auth
    try:
        subprocess.run(
            ["taskkill", "/PID", str(proc.pid), "/T", "/F"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        print("[INFO] Qwen CLI is Terminated...")
    except Exception:
        pass
