from qwen_claude.config.config import (
    CCR_CONFIG,
    SCHEMA_FILE,
    load_json,
    save_json_atomic,
)


def schema_validation() -> None:
    """
    Checks for api_base_url within the 'qwen' provider in config.json.
    """
    target_url = "https://portal.qwen.ai/v1/chat/completions"

    if not SCHEMA_FILE.exists():
        print(f"[ERR] Schema file missing at {SCHEMA_FILE}.")
        return

    if not CCR_CONFIG.exists():
        print(f"[INFO] {CCR_CONFIG.name} missing. Initializing from schema...")
        save_json_atomic(CCR_CONFIG, load_json(SCHEMA_FILE))
        return

    try:
        config_data = load_json(CCR_CONFIG)
    except Exception:
        config_data = {}

    # Find the qwen provider block
    providers = config_data.get("Providers", [])
    qwen_provider = next(
        (p for p in providers if isinstance(p, dict) and p.get("name") == "qwen"), None
    )

    needs_reset = False
    if not qwen_provider:
        print("[INFO] 'qwen' provider block missing in 'ccr' config.")
        needs_reset = True
    elif "api_base_url" not in qwen_provider:
        print("[INFO] 'api_base_url' missing in 'ccr' config.")
        needs_reset = True
    elif qwen_provider.get("api_base_url") != target_url:
        print(f"[INFO] URL mismatch. Found: {qwen_provider.get('api_base_url')}")
        needs_reset = True

    if needs_reset:
        print(f"[INFO] Rewriting {CCR_CONFIG.name} using {SCHEMA_FILE.name}...")
        save_json_atomic(CCR_CONFIG, load_json(SCHEMA_FILE))
    else:
        print("[OK] Schema validation passed.")
