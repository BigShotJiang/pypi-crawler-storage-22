import time
from qwen_claude.utils.window import run_windows_cmd
from qwen_claude.config.config import QWEN_OAUTH, load_json


def is_old_token():
    oauth = load_json(QWEN_OAUTH)
    old_access_token = oauth.get("access_token")
    return old_access_token


def is_expiring_soon(oauth: dict, buffer_seconds: int) -> bool:
    exp_ms = int(oauth.get("expiry_date", 0))
    if exp_ms <= 0:
        return True
    exp_s = exp_ms / 1000.0
    return time.time() >= (exp_s - buffer_seconds)


def force_qwen_refresh(qwen_path: str, is_old) -> None | int:
    """
    Trigger Qwen so it refreshes credentials if refresh_token is valid.
    """
    candidates = [["--version"], ["--help"], ["-h"], ["-p", "ping"]]
    # ["hi"],
    # ["hey"],
    # ["yo"],
    # ["what's up"],
    for args in candidates:
        rc = run_windows_cmd(qwen_path, args, quiet=True)
        oauth = load_json(QWEN_OAUTH)
        new_token = oauth.get("access_token")
        if new_token != is_old:
            break

    return rc
