from qwen_claude.utils.window import which


def verify_required_tools() -> None:
    """
    Ensure required global CLIs are installed before continuing.
    """
    requirements = [
        {
            "name": "qwen",
            "binary": "qwen",
            "install": "npm install -g @qwen-code/qwen-code@latest",
        },
        {
            "name": "claude-code-router",
            "binary": "ccr",
            "install": "npm install -g @musistudio/claude-code-router",
        },
        {
            "name": "claude",
            "binary": "claude",
            "install": "npm install -g @anthropic-ai/claude-code",
        },
    ]

    for req in requirements:
        path = which(req["binary"])
        if not path:
            print(
                f"[ERR] Required package '{req['name']}' is not installed or not in PATH."
            )
            print(f"[INFO] Install it with: `{req['install']}`")
            raise SystemExit(1)
        else:
            print(f"[OK] Found {req['name']} → `{path}`")
