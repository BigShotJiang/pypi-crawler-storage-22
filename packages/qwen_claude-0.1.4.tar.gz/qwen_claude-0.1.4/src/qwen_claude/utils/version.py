import argparse
from qwen_claude import __version__


def qc_version():
    parser = argparse.ArgumentParser(prog="qc")

    parser.add_argument(
        "-v", "--version", action="version", version=f"qc {__version__}"
    )

    return parser.parse_args()
