import subprocess
import shutil
from typing import Optional


def which(cmd: str) -> Optional[str]:
    return shutil.which(cmd)


def run_windows_cmd(exe_path: str, args: list[str], quiet: bool = True) -> int:
    """
    Windows-safe runner:
      - .ps1 => powershell -File
      - .cmd/.bat => cmd.exe /c <properly quoted>
      - else => direct execute
    """
    exe_lower = exe_path.lower()
    stdout = subprocess.DEVNULL if quiet else None
    stderr = subprocess.DEVNULL if quiet else None

    if exe_lower.endswith(".ps1"):
        cmd = [
            "powershell",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            exe_path,
            *args,
        ]
        p = subprocess.run(cmd, check=False, stdout=stdout, stderr=stderr)
        return p.returncode

    if exe_lower.endswith(".cmd") or exe_lower.endswith(".bat"):
        cmdline = subprocess.list2cmdline([exe_path, *args])
        p = subprocess.run(
            ["cmd.exe", "/d", "/s", "/c", cmdline],
            check=False,
            stdout=stdout,
            stderr=stderr,
        )
        return p.returncode

    p = subprocess.run([exe_path, *args], check=False, stdout=stdout, stderr=stderr)
    return p.returncode
