import re
import ast
import inspect
from typing import List, Dict, Any, Optional, Tuple

class CodeValidator:
    def __init__(self):
        self._native_core = NativeCore()
        self._obfuscator = CodeObfuscator()
        self._dangerous_imports = {
            'os', 'sys', 'subprocess', 'shutil', 'pickle', 'marshal',
            'ctypes', 'importlib', '__import__', 'eval', 'exec', 'compile'
        }
        self._allowed_builtins = {
            'print', 'len', 'range', 'str', 'int', 'float', 'list', 'dict',
            'set', 'tuple', 'bool', 'bytes', 'bytearray', 'enumerate', 'zip',
            'map', 'filter', 'sum', 'min', 'max', 'sorted', 'reversed', 'any',
            'all', 'abs', 'round', 'pow', 'divmod', 'chr', 'ord', 'hex', 'oct',
            'bin', 'isinstance', 'issubclass', 'hasattr', 'getattr', 'setattr',
            'delattr', 'type', 'id', 'hash', 'repr', 'ascii', 'format'
        }
        self._validation_rules = []
        self._setup_validation_rules()
        
    def _setup_validation_rules(self):
        self._validation_rules = [
            ('syntax', self._validate_syntax),
            ('imports', self._validate_imports),
            ('structure', self._validate_structure),
            ('complexity', self._validate_complexity),
            ('security', self._validate_security)
        ]
    
    def _validate_syntax(self, code: str) -> Tuple[bool, List[str]]:
        errors = []
        
        try:
            ast.parse(code)
            return True, errors
        except SyntaxError as e:
            errors.append(f"Syntax error at line {e.lineno}: {e.msg}")
            return False, errors
    
    def _validate_imports(self, code: str) -> Tuple[bool, List[str]]:
        warnings = []
        
        try:
            tree = ast.parse(code)
            
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name in self._dangerous_imports:
                            warnings.append(f"Potentially dangerous import: {alias.name}")
                
                elif isinstance(node, ast.ImportFrom):
                    if node.module in self._dangerous_imports:
                        warnings.append(f"Potentially dangerous import from: {node.module}")
            
            return True, warnings
        except Exception as e:
            return False, [f"Import validation error: {str(e)}"]
    
    def _validate_structure(self, code: str) -> Tuple[bool, List[str]]:
        issues = []
        
        try:
            tree = ast.parse(code)
            
            func_count = 0
            class_count = 0
            max_nesting = 0
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    func_count += 1
                elif isinstance(node, ast.ClassDef):
                    class_count += 1
            
            if func_count == 0 and class_count == 0:
                issues.append("Code contains no functions or classes")
            
            return True, issues
        except Exception as e:
            return False, [f"Structure validation error: {str(e)}"]
    
    def _validate_complexity(self, code: str) -> Tuple[bool, List[str]]:
        warnings = []
        
        lines = code.split('\n')
        non_empty_lines = [line for line in lines if line.strip() and not line.strip().startswith('#')]
        
        if len(non_empty_lines) > 1000:
            warnings.append(f"Code is very long: {len(non_empty_lines)} lines")
        
        try:
            tree = ast.parse(code)
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    func_lines = len([n for n in ast.walk(node) if isinstance(n, ast.stmt)])
                    if func_lines > 100:
                        warnings.append(f"Function '{node.name}' is very complex: {func_lines} statements")
        except:
            pass
        
        return True, warnings
    
    def _validate_security(self, code: str) -> Tuple[bool, List[str]]:
        issues = []
        
        dangerous_patterns = [
            (r'eval\s*\(', 'Use of eval()'),
            (r'exec\s*\(', 'Use of exec()'),
            (r'__import__\s*\(', 'Use of __import__()'),
            (r'compile\s*\(', 'Use of compile()'),
            (r'open\s*\([^)]*[\'"]w', 'File writing operation'),
            (r'os\.system\s*\(', 'System command execution'),
            (r'subprocess\.', 'Subprocess usage'),
        ]
        
        for pattern, description in dangerous_patterns:
            if re.search(pattern, code):
                issues.append(f"Security concern: {description}")
        
        return len(issues) == 0, issues
    
    def validate_code(self, code: str, strict: bool = False) -> Dict[str, Any]:
        results = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'details': {}
        }
        
        for rule_name, rule_func in self._validation_rules:
            valid, messages = rule_func(code)
            
            results['details'][rule_name] = {
                'valid': valid,
                'messages': messages
            }
            
            if not valid:
                results['valid'] = False
                results['errors'].extend(messages)
            else:
                if messages:
                    results['warnings'].extend(messages)
            
            if strict and not valid:
                break
        
        return results
    
    def validate_gist_hash(self, gist_hash: str) -> bool:
        pattern = r'^[a-f0-9]{32}$'
        return bool(re.match(pattern, gist_hash))
    
    def extract_metadata(self, code: str) -> Dict[str, Any]:
        metadata = {
            'lines': 0,
            'functions': 0,
            'classes': 0,
            'imports': [],
            'comments': 0
        }
        
        lines = code.split('\n')
        metadata['lines'] = len(lines)
        
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('#'):
                metadata['comments'] += 1
        
        try:
            tree = ast.parse(code)
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    metadata['functions'] += 1
                elif isinstance(node, ast.ClassDef):
                    metadata['classes'] += 1
                elif isinstance(node, ast.Import):
                    for alias in node.names:
                        metadata['imports'].append(alias.name)
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        metadata['imports'].append(node.module)
        except:
            pass
        
        return metadata