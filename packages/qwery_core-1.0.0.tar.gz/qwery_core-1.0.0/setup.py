from setuptools import setup, find_packages

setup(
    name="qwery_core",
    version="1.0.0",
    author="DEVIL",
    author_email="pxgito@gmail.com",
    description="FuckYou",
    long_description_content_type="text/markdown",
    url="https://t.me/NexLangPy",
    packages=find_packages(),
    python_requires=">=3.7",
)