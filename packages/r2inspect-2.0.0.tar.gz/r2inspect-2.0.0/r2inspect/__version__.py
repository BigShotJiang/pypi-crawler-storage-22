"""Version information for r2inspect."""

__version__ = "1.0.0"
__author__ = "Marc Rivero"
__author_email__ = "mriverolopez@gmail.com"
__license__ = "GPL-3.0"
__url__ = "https://github.com/seifreed/r2inspect"
