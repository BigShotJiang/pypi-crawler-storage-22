# Radiant: A single-file Python runtime bridge (CPython ↔ Brython)

A lightweight and Python-first runtime bridge for building web applications with Brython.

![GitHub top language](https://img.shields.io/github/languages/top/dunderlab/radiant-runtime-bridge?)
![PyPI - License](https://img.shields.io/pypi/l/radiant-runtime-bridge?)
![PyPI](https://img.shields.io/pypi/v/radiant-runtime-bridge?)
![PyPI - Status](https://img.shields.io/pypi/status/radiant-runtime-bridge?)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/radiant-runtime-bridge?)
![GitHub last commit](https://img.shields.io/github/last-commit/dunderlab/radiant-runtime-bridge?)
![CodeFactor Grade](https://img.shields.io/codefactor/grade/github/dunderlab/radiant-runtime-bridge?)


