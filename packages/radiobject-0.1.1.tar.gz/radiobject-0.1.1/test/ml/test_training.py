"""Integration tests for training loop."""

from __future__ import annotations

from typing import TYPE_CHECKING

import torch
import torch.nn as nn
from monai.transforms import NormalizeIntensityd

from radiobject.ml.config import DatasetConfig, LoadingMode
from radiobject.ml.datasets import VolumeCollectionDataset
from radiobject.ml.factory import create_training_dataloader

if TYPE_CHECKING:
    from radiobject.radi_object import RadiObject


class SimpleCNN(nn.Module):
    """Minimal 3D CNN for testing."""

    def __init__(self, in_channels: int = 1, num_classes: int = 2):
        super().__init__()
        self.conv = nn.Conv3d(in_channels, 4, kernel_size=3, padding=1)
        self.pool = nn.AdaptiveAvgPool3d(1)
        self.fc = nn.Linear(4, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = torch.relu(self.conv(x))
        x = self.pool(x).flatten(1)
        return self.fc(x)


class TestTrainingIntegration:
    """Integration tests for training workflow."""

    def test_single_forward_pass(self, ml_dataset: VolumeCollectionDataset) -> None:
        """Test forward pass through model with real data."""
        sample = ml_dataset[0]
        image = sample["image"].unsqueeze(0)

        model = SimpleCNN(in_channels=2)
        output = model(image)

        assert output.shape == (1, 2)

    def test_gradient_flow(self, ml_dataset: VolumeCollectionDataset) -> None:
        """Test gradients flow through model."""
        sample = ml_dataset[0]
        image = sample["image"].unsqueeze(0)
        target = torch.tensor([0])

        model = SimpleCNN(in_channels=2)
        criterion = nn.CrossEntropyLoss()

        output = model(image)
        loss = criterion(output, target)
        loss.backward()

        for param in model.parameters():
            if param.grad is not None:
                assert not torch.all(param.grad == 0)

    def test_training_epoch(self, populated_radi_object_module: "RadiObject") -> None:
        """Test complete training epoch with DataLoader."""
        config = DatasetConfig(loading_mode=LoadingMode.FULL_VOLUME)
        collection = populated_radi_object_module.collection("flair")
        dataset = VolumeCollectionDataset(collection, config=config)

        loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=True, drop_last=False)

        model = SimpleCNN(in_channels=1)
        optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
        criterion = nn.CrossEntropyLoss()

        model.train()
        epoch_loss = 0.0
        batch_count = 0
        for i, batch in enumerate(loader):
            images = batch["image"]
            targets = torch.tensor([i % 2], dtype=torch.long)

            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item()
            batch_count += 1

        assert batch_count > 0
        assert epoch_loss > 0

    def test_multimodal_stacking(self, populated_radi_object_module: "RadiObject") -> None:
        """Test multimodal data stacks correctly along channel dimension."""
        config = DatasetConfig(loading_mode=LoadingMode.FULL_VOLUME)
        collections = [
            populated_radi_object_module.collection("flair"),
            populated_radi_object_module.collection("T1w"),
        ]
        dataset = VolumeCollectionDataset(collections, config=config)

        sample = dataset[0]
        assert sample["image"].shape[0] == 2

        model = SimpleCNN(in_channels=2)
        output = model(sample["image"].unsqueeze(0))
        assert output.shape == (1, 2)


class TestFactoryDataloader:
    """Tests for factory-created dataloaders."""

    def test_create_training_dataloader(self, populated_radi_object_module: "RadiObject") -> None:
        """Test factory creates valid dataloader."""
        collection = populated_radi_object_module.collection("flair")
        loader = create_training_dataloader(
            collection,
            batch_size=1,
            num_workers=0,
        )

        batch = next(iter(loader))
        assert "image" in batch
        assert batch["image"].shape[0] == 1

    def test_dataloader_with_patch(self, populated_radi_object_module: "RadiObject") -> None:
        """Test dataloader with patch extraction."""
        collection = populated_radi_object_module.collection("flair")
        loader = create_training_dataloader(
            collection,
            patch_size=(32, 32, 32),
            batch_size=2,
            num_workers=0,
        )

        batch = next(iter(loader))
        assert batch["image"].shape == (2, 1, 32, 32, 32)

    def test_dataloader_multimodal(self, populated_radi_object_module: "RadiObject") -> None:
        """Test factory with multiple collections."""
        collections = [
            populated_radi_object_module.collection("flair"),
            populated_radi_object_module.collection("T1w"),
        ]
        loader = create_training_dataloader(
            collections,
            batch_size=1,
            num_workers=0,
        )

        batch = next(iter(loader))
        assert batch["image"].shape[1] == 2


class TestTransformIntegration:
    """Tests for transform integration with MONAI."""

    def test_transform_applied(self, populated_radi_object_module: "RadiObject") -> None:
        """Test MONAI transforms are applied to samples."""
        transform = NormalizeIntensityd(keys="image", channel_wise=True)

        config = DatasetConfig(loading_mode=LoadingMode.FULL_VOLUME)
        collection = populated_radi_object_module.collection("flair")
        dataset = VolumeCollectionDataset(collection, config=config, transform=transform)

        sample = dataset[0]
        image = sample["image"].float()
        mean = image.mean().item()
        std = image.std().item()

        assert abs(mean) < 0.5
        assert abs(std - 1.0) < 0.5


class TestParameterizedTraining:
    """Training tests parameterized by storage backend."""

    def test_training_with_backend(self, ml_dataset_param: VolumeCollectionDataset) -> None:
        """Test training works with both local and S3 backends."""
        sample = ml_dataset_param[0]
        image = sample["image"].unsqueeze(0)

        model = SimpleCNN(in_channels=2)
        output = model(image)

        assert output.shape == (1, 2)
