<!--
SPDX-FileCopyrightText: 2026 Martin Kirchgessner

SPDX-License-Identifier: AGPL-3.0-or-later
-->

# Radiotomate release notes

## 0.1

This first beta release settles Radiotomate's architecture by implementing the most
important features:

* Auto-DJ as non-overlapping time period that select via a (weighted) Beets filter(s)
* Carts as a collection of sounds picked in order or randomly
* "simple" mode for timed carts: pick a weekday and a HH:MM
* "advanced" mode: cron formulas for timed carts
* Relay external streams
* External stream input
* Automated switch to the first available source among external/relay/carts/autoDJ
* "Live" page displaying what's currently playing
* Log metadata and relay it to other HTTP endpoints
* Configurable outputs, to Icecast or ALSA
* Apply replay gain to music, carts and jingles
* Basic user account creation and access rights
* A minimalist History page
* A fairly complete automated test suite that also checks the interface remains
  accessible to screen readers
* A command-line interface for installation, updates and user management

All of that implemented in light, asynchronous web-apps, storing to SQlite and rendering
server-side, using HTMX when we need some dynamic rendering.

It also comes with an automated pod creator, using two images:
a playout container, based on Liquidsoap's, and a webapps container.

The installer hardcodes that interface is on `:6811`, scheduler on `:6822`, playout on
`:6833` and playout input on `:6800` - we leave ports choice to the host,
and the pod creation provides:

* transparent paths bindings in containers, so application's data has the same path in and outside the contaniner
* provide `beets` and `radiotomate` commands working on the usual `$PATH` outside the container
* a parameter to configure pulseaudio bind or not
* ... without ever being root

And minor/less visible things:

* automated developer environment installation
* carts' maximum duration
* integrate beets 2.5, with drop2beets
* ensure external.stop when switching to live
* configurable logging to files
* Liquidsoap script crash when no output is configured, and suggests to check the config
* save who uploaded a sound/music
* ability to push cart on the autodj queue (for promo spots)
* so much documentation!
