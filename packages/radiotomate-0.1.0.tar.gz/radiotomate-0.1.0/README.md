<!--
SPDX-FileCopyrightText: 2026 Martin Kirchgessner

SPDX-License-Identifier: AGPL-3.0-or-later
-->

# 📻 Radiotomate 🍅

Radiotomate is a free and accessible broadcast automation system designed for community radios. It allows you to quickly start streaming from your music library, pre-recorded shows or external streams, even on a (virtual) machine with low resources. 

Please find more information in its documentation on [radiotomate.org](https://radiotomate.org/)
