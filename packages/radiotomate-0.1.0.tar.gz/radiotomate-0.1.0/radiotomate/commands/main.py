# SPDX-FileCopyrightText: 2026 Martin Kirchgessner
#
# SPDX-License-Identifier: AGPL-3.0-or-later

# load sub-commands
from radiotomate.commands import (  # noqa: F401
    install,
    interface,
    radiotomate_cli,
    scheduler,
    update,
    users,
)

if __name__ == "__main__":
    radiotomate_cli()
