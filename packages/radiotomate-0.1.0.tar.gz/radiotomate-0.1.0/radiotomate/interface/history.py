# SPDX-FileCopyrightText: 2026 Martin Kirchgessner
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import logging

from quart import Blueprint, g, render_template

from radiotomate.auth import login_required
from radiotomate.models import MetadataLog

_log = logging.getLogger(__name__)

blueprint = Blueprint("history", __name__, template_folder="templates")


@blueprint.get("/history")
@login_required
async def index():
    history = await MetadataLog.get(g.dbsession, 200)
    return await render_template("history/index.jinja", history=history)
