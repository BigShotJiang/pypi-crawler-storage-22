# SPDX-FileCopyrightText: 2026 Martin Kirchgessner
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""
# Root module of the Scheduler Web application

All endpoints are defined in sub-modules, with one blueprint per sub-module.
"""
