from Radium.auth import AccountSystem

account = AccountSystem()