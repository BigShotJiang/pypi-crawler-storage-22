import numpy as np
from radnn.system.filesystem import FileStore


class MLExperimentLog:
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, filename: str, experiment_info: dict | None = None, is_autoinit: bool = False):
    self.filename = filename
    if experiment_info is None:
      experiment_info = {}
    self.experiment_info = experiment_info
    self.is_autoinit = is_autoinit
    if self.is_autoinit:
      self.logs = {"experiment": experiment_info, "epoch": [], "epoch_time": []}
    else:
      self.logs = {"experiment": experiment_info, "epoch": [], "epoch_time": [],
                   "train_step_loss": [],
                   "train_step_accuracy": [],
                   "train_loss": [],
                   "train_accuracy": [],
                   "val_loss": [],
                   "val_accuracy": [],
                   "learning_rate": []}
  
  # --------------------------------------------------------------------------------------------------------------------
  def assign_series(self, **kwargs):
    if self.is_autoinit:
      for key, value in kwargs.items():
        if key not in self.logs:
          self.logs[key] = []
    
    for key, value in kwargs.items():
      self.logs[key] = value
  
  # --------------------------------------------------------------------------------------------------------------------
  def append(self, **kwargs):
    if self.is_autoinit:
      for key, value in kwargs.items():
        if key not in self.logs:
          self.logs[key] = []
    
    for key, value in kwargs.items():
      self.logs[key].append(value)
    return self
  
  # --------------------------------------------------------------------------------------------------------------------
  def load(self, experiment_fs: FileStore):
    self.logs = experiment_fs.json.load(self.filename)
    return self
  
  # --------------------------------------------------------------------------------------------------------------------
  def save(self, experiment_fs: FileStore):
    experiment_fs.json.save(self.logs, self.filename)
    return self
  # --------------------------------------------------------------------------------------------------------------------
