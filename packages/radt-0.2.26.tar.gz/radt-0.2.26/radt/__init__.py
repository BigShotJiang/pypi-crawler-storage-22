"""Resource-Aware Data systems Tracker (radT) for automatically tracking and training machine learning software."""

__version__ = "0.2.26"

from .radt import cli, schedule_external
from .run import log_metric, log_metrics
