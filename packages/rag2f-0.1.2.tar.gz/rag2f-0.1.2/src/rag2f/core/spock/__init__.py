"""Spock configuration package."""
