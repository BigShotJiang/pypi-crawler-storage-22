from .secrets import get_secret_key

__all__ = ["get_secret_key"]
