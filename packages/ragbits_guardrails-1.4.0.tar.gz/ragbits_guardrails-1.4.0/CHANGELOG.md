# CHANGELOG

## Unreleased

## 1.4.0 (2026-02-04)

### Changed

- ragbits-core updated to version v1.4.0

## 1.3.0 (2025-09-11)

### Changed

- ragbits-core updated to version v1.3.0

## 1.2.2 (2025-08-08)

### Changed

- ragbits-core updated to version v1.2.2

## 1.2.1 (2025-08-04)

### Changed

- ragbits-core updated to version v1.2.1

## 1.2.0 (2025-08-01)

### Changed

- ragbits-core updated to version v1.2.0

- Fix double openai optional dependency version mismatch
- Introduce new API for attachments in prompts (#711)

## 1.1.0 (2025-07-09)

### Changed

- ragbits-core updated to version v1.1.0

## 1.0.0 (2025-06-04)

### Changed

- ragbits-core updated to version v1.0.0

## 0.20.1 (2025-06-04)

### Changed

- ragbits-core updated to version v0.20.1

## 0.20.0 (2025-06-03)

### Changed

- ragbits-core updated to version v0.20.0

## 0.19.1 (2025-05-27)

### Changed

- ragbits-core updated to version v0.19.1

## 0.19.0 (2025-05-27)

### Changed

- ragbits-core updated to version v0.19.0

## 0.18.0 (2025-05-22)

### Changed

- ragbits-core updated to version v0.18.0

## 0.17.1 (2025-05-09)

### Changed

- ragbits-core updated to version v0.17.1

## 0.17.0 (2025-05-06)

### Changed

- ragbits-core updated to version v0.17.0

## 0.16.0 (2025-04-29)

### Changed

- ragbits-core updated to version v0.16.0

## 0.15.0 (2025-04-28)

### Changed

- ragbits-core updated to version v0.15.0

## 0.14.0 (2025-04-22)

### Changed

- ragbits-core updated to version v0.14.0

## 0.13.0 (2025-04-02)

### Changed

- ragbits-core updated to version v0.13.0

## 0.12.0 (2025-03-25)

### Changed

- ragbits-core updated to version v0.12.0

## 0.11.0 (2025-03-25)

### Changed

- ragbits-core updated to version v0.11.0

## 0.10.2 (2025-03-21)

### Changed

- ragbits-core updated to version v0.10.2

## 0.10.1 (2025-03-19)

### Changed

- ragbits-core updated to version v0.10.1

## 0.10.0 (2025-03-17)

### Changed

- ragbits-core updated to version v0.10.0

## 0.9.0 (2025-02-25)

### Changed

- ragbits-core updated to version v0.9.0

## 0.8.0 (2025-01-29)

### Changed

- ragbits-core updated to version v0.8.0

## 0.7.0 (2025-01-21)

### Changed

- ragbits-core updated to version v0.7.0

## 0.6.0 (2024-12-27)

### Changed

- ragbits-core updated to version v0.6.0

## 0.5.1 (2024-12-09)

### Changed

- ragbits-core updated to version v0.5.1

## 0.5.0 (2024-12-05)

### Changed

- ragbits-core updated to version v0.5.0

## 0.4.0 (2024-11-27)

### Changed

- ragbits-core updated to version v0.4.0

## 0.3.0 (2024-11-06)

### Added

- Initial release of the package (#169).
- First guardrail with OpenAI Moderation.

