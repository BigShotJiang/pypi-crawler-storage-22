def main():
    print("Hello from ragdk!")


if __name__ == "__main__":
    main()
