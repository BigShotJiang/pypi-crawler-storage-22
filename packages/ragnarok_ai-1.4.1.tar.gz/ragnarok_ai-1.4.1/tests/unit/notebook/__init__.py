"""Tests for notebook module."""
