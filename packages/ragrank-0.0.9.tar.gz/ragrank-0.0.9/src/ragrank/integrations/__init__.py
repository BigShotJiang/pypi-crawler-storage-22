"""Base class for integrations"""
