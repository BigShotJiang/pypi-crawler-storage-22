"""
Memory storage for ragtime.

Handles structured memory storage in .ragtime/ directory.
Each memory is a markdown file with YAML frontmatter.
"""

from pathlib import Path
from dataclasses import dataclass, field
from datetime import date
from typing import Optional
import uuid
import hashlib
import re
import yaml


@dataclass
class Memory:
    """A single memory entry."""
    content: str
    namespace: str
    type: str
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    component: Optional[str] = None
    confidence: str = "medium"
    confidence_reason: Optional[str] = None
    source: str = "manual"
    status: str = "active"
    added: str = field(default_factory=lambda: date.today().isoformat())
    author: Optional[str] = None
    issue: Optional[str] = None
    epic: Optional[str] = None
    branch: Optional[str] = None
    supersedes: Optional[str] = None
    # Internal: actual file path when loaded from disk (not serialized)
    _file_path: Optional[str] = field(default=None, repr=False)

    def to_frontmatter(self) -> dict:
        """Convert to YAML frontmatter dict."""
        data = {
            "id": self.id,
            "namespace": self.namespace,
            "type": self.type,
            "confidence": self.confidence,
            "source": self.source,
            "status": self.status,
            "added": self.added,
        }

        # Add optional fields if present
        if self.component:
            data["component"] = self.component
        if self.confidence_reason:
            data["confidence_reason"] = self.confidence_reason
        if self.author:
            data["author"] = self.author
        if self.issue:
            data["issue"] = self.issue
        if self.epic:
            data["epic"] = self.epic
        if self.branch:
            data["branch"] = self.branch
        if self.supersedes:
            data["supersedes"] = self.supersedes

        return data

    def to_markdown(self) -> str:
        """Convert to markdown with YAML frontmatter."""
        frontmatter = yaml.dump(self.to_frontmatter(), default_flow_style=False, sort_keys=False)
        return f"---\n{frontmatter}---\n\n{self.content}\n"

    def to_metadata(self) -> dict:
        """Convert to metadata dict for ChromaDB."""
        meta = self.to_frontmatter()
        # Use actual file path if loaded from disk, otherwise generate it
        meta["file"] = self._file_path if self._file_path else self.get_relative_path()
        return meta

    def get_relative_path(self) -> str:
        """Get the relative path for this memory's file."""
        slug = self._slugify(self.content[:50])

        if self.namespace == "app":
            if self.component:
                # Sanitize component to prevent path traversal
                safe_component = self._slugify(self.component)
                return f"app/{safe_component}/{self.id}-{slug}.md"
            return f"app/{self.id}-{slug}.md"
        elif self.namespace == "team":
            return f"team/{self.id}-{slug}.md"
        elif self.namespace.startswith("user-"):
            # Sanitize username to prevent path traversal
            username = self._slugify(self.namespace.replace("user-", ""))
            return f"users/{username}/{self.id}-{slug}.md"
        elif self.namespace.startswith("branch-"):
            branch_slug = self._slugify(self.namespace.replace("branch-", ""))
            return f"branches/{branch_slug}/{self.id}-{slug}.md"
        else:
            # Sanitize namespace to prevent path traversal
            safe_namespace = self._slugify(self.namespace)
            return f"other/{safe_namespace}/{self.id}-{slug}.md"

    @staticmethod
    def _slugify(text: str) -> str:
        """Convert text to a filename-safe slug."""
        # Lowercase and replace spaces/special chars with hyphens
        slug = re.sub(r'[^\w\s-]', '', text.lower())
        slug = re.sub(r'[-\s]+', '-', slug).strip('-')
        return slug[:40]  # Limit length

    @classmethod
    def _infer_metadata_from_path(cls, relative_path: str) -> dict:
        """
        Infer namespace, component, and type from folder structure.

        Supports:
          app/{component}/*.md → namespace=app, component={component}
          app/*.md → namespace=app
          team/*.md → namespace=team
          users/{username}/*.md → namespace=user-{username}
          branches/{branch}/*.md → namespace=branch-{branch}
        """
        parts = relative_path.replace("\\", "/").split("/")
        metadata = {}

        if len(parts) >= 1:
            first = parts[0]
            if first == "app":
                metadata["namespace"] = "app"
                if len(parts) >= 3:  # app/{component}/file.md
                    metadata["component"] = parts[1]
            elif first == "team":
                metadata["namespace"] = "team"
            elif first == "users" and len(parts) >= 2:
                metadata["namespace"] = f"user-{parts[1]}"
            elif first == "branches" and len(parts) >= 2:
                metadata["namespace"] = f"branch-{parts[1]}"

        return metadata

    @classmethod
    def from_file(cls, path: Path, relative_to: Optional[Path] = None) -> "Memory":
        """
        Parse a memory from a markdown file with YAML frontmatter.

        If no frontmatter exists, infers metadata from folder structure.

        Args:
            path: Full path to the markdown file
            relative_to: Base directory to compute relative path from (for indexing)
        """
        text = path.read_text()

        # Compute relative path for inference and indexing
        file_path = None
        if relative_to:
            try:
                file_path = str(path.relative_to(relative_to))
            except ValueError:
                pass

        # Handle files without frontmatter - infer from path
        if not text.startswith("---"):
            inferred = cls._infer_metadata_from_path(file_path or str(path))
            # Generate stable ID from path
            memory_id = hashlib.sha256((file_path or str(path)).encode()).hexdigest()[:8]

            return cls(
                id=memory_id,
                content=text.strip(),
                namespace=inferred.get("namespace", "app"),
                type=inferred.get("type", "note"),
                component=inferred.get("component"),
                source="file",
                _file_path=file_path,
            )

        # Split frontmatter and content
        parts = text.split("---", 2)
        if len(parts) < 3:
            raise ValueError(f"Invalid frontmatter format in {path}")

        frontmatter = yaml.safe_load(parts[1]) or {}
        content = parts[2].strip()

        # Infer missing metadata from folder structure
        inferred = cls._infer_metadata_from_path(file_path or str(path))

        # Use frontmatter ID if present, otherwise derive stable ID from file path
        # This ensures reindex is idempotent - same file always gets same ID
        if "id" in frontmatter:
            memory_id = frontmatter["id"]
        elif file_path:
            # Stable hash of relative path
            memory_id = hashlib.sha256(file_path.encode()).hexdigest()[:8]
        else:
            # Fallback: hash of absolute path
            memory_id = hashlib.sha256(str(path).encode()).hexdigest()[:8]

        return cls(
            id=memory_id,
            content=content,
            # Use frontmatter if present, fall back to inferred, then defaults
            namespace=frontmatter.get("namespace") or inferred.get("namespace", "app"),
            type=frontmatter.get("type") or inferred.get("type", "note"),
            component=frontmatter.get("component") or inferred.get("component"),
            confidence=frontmatter.get("confidence", "medium"),
            confidence_reason=frontmatter.get("confidence_reason"),
            source=frontmatter.get("source", "file"),
            status=frontmatter.get("status", "active"),
            added=frontmatter.get("added", date.today().isoformat()),
            author=frontmatter.get("author"),
            issue=frontmatter.get("issue"),
            epic=frontmatter.get("epic"),
            branch=frontmatter.get("branch"),
            supersedes=frontmatter.get("supersedes"),
            _file_path=file_path,
        )


class MemoryStore:
    """
    File-based memory storage.

    Stores memories as markdown files with YAML frontmatter.
    Also maintains a ChromaDB index for semantic search.
    """

    def __init__(self, project_path: Path, db):
        """
        Initialize the memory store.

        Args:
            project_path: Root of the project
            db: RagtimeDB instance for vector search
        """
        self.project_path = project_path
        self.memory_dir = project_path / ".ragtime"
        self.db = db

    def save(self, memory: Memory) -> Path:
        """
        Save a memory to disk and index it.

        Returns:
            Path to the saved file
        """
        # Determine file path
        relative_path = memory.get_relative_path()
        file_path = self.memory_dir / relative_path

        # Create directory if needed
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # Write file
        file_path.write_text(memory.to_markdown())

        # Index in ChromaDB
        self.db.upsert(
            ids=[memory.id],
            documents=[memory.content],
            metadatas=[memory.to_metadata()],
        )

        return file_path

    def get(self, memory_id: str) -> Optional[Memory]:
        """Get a memory by ID."""
        # Search in ChromaDB to find the memory
        results = self.db.collection.get(ids=[memory_id], include=["documents", "metadatas"])

        if not results["ids"]:
            return None

        metadata = results["metadatas"][0]
        content = results["documents"][0] if results["documents"] else ""
        file_rel_path = metadata.get("file", "")

        # Try to read from file first (has full frontmatter data)
        if file_rel_path:
            file_path = self.memory_dir / file_rel_path
            if file_path.exists():
                return Memory.from_file(file_path, relative_to=self.memory_dir)

        # Fall back to constructing from ChromaDB data
        # This handles cases where file path is wrong or file was deleted
        return Memory(
            id=memory_id,
            content=content,
            namespace=metadata.get("namespace", "unknown"),
            type=metadata.get("type", "unknown"),
            component=metadata.get("component"),
            confidence=metadata.get("confidence", "medium"),
            confidence_reason=metadata.get("confidence_reason"),
            source=metadata.get("source", "unknown"),
            status=metadata.get("status", "active"),
            added=metadata.get("added", ""),
            author=metadata.get("author"),
            issue=metadata.get("issue"),
            epic=metadata.get("epic"),
            branch=metadata.get("branch"),
            _file_path=file_rel_path,
        )

    def delete(self, memory_id: str) -> bool:
        """Delete a memory by ID."""
        memory = self.get(memory_id)
        if not memory:
            return False

        # Delete file
        file_path = self.memory_dir / memory.get_relative_path()
        if file_path.exists():
            file_path.unlink()

            # Clean up empty directories
            self._cleanup_empty_dirs(file_path.parent)

        # Remove from index
        self.db.delete([memory_id])

        return True

    def update_status(self, memory_id: str, status: str) -> bool:
        """Update a memory's status (e.g., graduated, abandoned)."""
        memory = self.get(memory_id)
        if not memory:
            return False

        memory.status = status
        self.save(memory)
        return True

    def graduate(self, memory_id: str, new_confidence: str = "high") -> Optional[Memory]:
        """
        Graduate a branch memory to app namespace.

        Creates a copy in app namespace and marks original as graduated.
        """
        memory = self.get(memory_id)
        if not memory:
            return None

        if not memory.namespace.startswith("branch-"):
            raise ValueError("Can only graduate branch memories")

        # Create graduated copy
        graduated = Memory(
            content=memory.content,
            namespace="app",
            type=memory.type,
            component=memory.component,
            confidence=new_confidence,
            confidence_reason="pr-graduate",
            source="pr-graduate",
            status="active",
            author=memory.author,
            issue=memory.issue,
            epic=memory.epic,
        )

        # Save the graduated memory
        self.save(graduated)

        # Mark original as graduated
        memory.status = "graduated"
        self.save(memory)

        return graduated

    def list_memories(
        self,
        namespace: Optional[str] = None,
        type_filter: Optional[str] = None,
        status: Optional[str] = None,
        component: Optional[str] = None,
        limit: int = 100,
    ) -> list[Memory]:
        """List memories with optional filters."""
        # Build filter conditions
        conditions = []
        namespace_prefix = None

        if namespace:
            if namespace.endswith("*"):
                # Prefix match - filter in Python after fetching
                namespace_prefix = namespace[:-1]
            else:
                conditions.append({"namespace": namespace})

        if type_filter:
            conditions.append({"type": type_filter})

        if status:
            conditions.append({"status": status})

        if component:
            conditions.append({"component": component})

        # Exclude docs/code entries - they use type="docs" or type="code"
        # while memories use types like "architecture", "feature", etc.
        # This is especially important for wildcard queries
        conditions.append({"type": {"$nin": ["docs", "code"]}})

        # Build where clause with $and if multiple conditions
        if len(conditions) == 1:
            where = conditions[0]
        else:
            where = {"$and": conditions}

        # When using prefix match, fetch more results since we'll filter some out
        fetch_limit = limit * 5 if namespace_prefix else limit

        # Get from ChromaDB
        results = self.db.collection.get(
            where=where,
            limit=fetch_limit,
        )

        memories = []
        for i, mem_id in enumerate(results["ids"]):
            metadata = results["metadatas"][i]
            content = results["documents"][i] if results["documents"] else ""

            # Handle namespace prefix filtering
            if namespace_prefix:
                if not metadata.get("namespace", "").startswith(namespace_prefix):
                    continue

            memories.append(Memory(
                id=mem_id,
                content=content,
                namespace=metadata.get("namespace", "unknown"),
                type=metadata.get("type", "unknown"),
                component=metadata.get("component"),
                confidence=metadata.get("confidence", "medium"),
                source=metadata.get("source", "unknown"),
                status=metadata.get("status", "active"),
                added=metadata.get("added", ""),
                author=metadata.get("author"),
            ))

            # Stop once we have enough
            if len(memories) >= limit:
                break

        return memories

    def store_document(self, file_path: Path, namespace: str, doc_type: str = "handoff") -> Memory:
        """
        Store a document verbatim (like handoff.md).

        The file content becomes the memory content without processing.
        """
        content = file_path.read_text()

        memory = Memory(
            content=content,
            namespace=namespace,
            type=doc_type,
            source="store-doc",
            confidence="medium",
            confidence_reason="document",
        )

        self.save(memory)
        return memory

    def reindex(self) -> int:
        """
        Reindex all memory files.

        Scans .ragtime/ and indexes files. Removes old entries for each file
        before upserting to prevent duplicates from ID changes.

        Returns count of files indexed.
        """
        if not self.memory_dir.exists():
            return 0

        count = 0
        for md_file in self.memory_dir.rglob("*.md"):
            try:
                # Compute relative path for this file
                rel_path = str(md_file.relative_to(self.memory_dir))

                # Delete any existing entries for this file path (handles ID changes)
                self.db.delete_by_file([rel_path])

                # Parse and index with stable ID
                memory = Memory.from_file(md_file, relative_to=self.memory_dir)
                self.db.upsert(
                    ids=[memory.id],
                    documents=[memory.content],
                    metadatas=[memory.to_metadata()],
                )
                count += 1
            except Exception as e:
                print(f"Warning: Could not index {md_file}: {e}")

        return count

    def _cleanup_empty_dirs(self, dir_path: Path) -> None:
        """Remove empty directories up to memory_dir."""
        # Resolve paths to handle symlinks and ensure we stay within bounds
        try:
            dir_path = dir_path.resolve()
            memory_dir_resolved = self.memory_dir.resolve()
        except OSError:
            return  # Can't resolve paths, bail out safely

        # Ensure dir_path is actually under memory_dir
        try:
            dir_path.relative_to(memory_dir_resolved)
        except ValueError:
            return  # dir_path is not under memory_dir, bail out

        while dir_path != memory_dir_resolved and dir_path.exists():
            try:
                if not any(dir_path.iterdir()):
                    dir_path.rmdir()
                    dir_path = dir_path.parent.resolve()
                else:
                    break
            except OSError:
                break  # Permission error or other issue, stop cleanup
