"""
Configuration management for ragtime.

Config lives in .ragtime/config.yaml in the project root.
"""

from pathlib import Path
from dataclasses import dataclass, field
import yaml


@dataclass
class DocsConfig:
    """Configuration for docs indexing."""
    # Note: .ragtime/ is NOT included here - memories are indexed separately via 'reindex'
    # to avoid duplicate entries (same file indexed as both doc and memory)
    paths: list[str] = field(default_factory=lambda: ["docs"])
    patterns: list[str] = field(default_factory=lambda: ["**/*.md"])
    exclude: list[str] = field(default_factory=lambda: [
        "**/node_modules/**",
        "**/.git/**",
        "**/.ragtime/**",  # Memories indexed separately
    ])


@dataclass
class CodeConfig:
    """Configuration for code indexing."""
    paths: list[str] = field(default_factory=lambda: ["."])
    languages: list[str] = field(default_factory=lambda: ["python", "typescript", "javascript", "vue", "dart"])
    exclude: list[str] = field(default_factory=lambda: [
        "**/node_modules/**",
        "**/.git/**",
        "**/build/**",
        "**/dist/**",
        "**/.dart_tool/**",
        # Generated code (Prisma, GraphQL, OpenAPI, etc.)
        "**/generated/**",
        "**/*.generated.*",
        "**/*.g.dart",
        # TypeScript declaration files (often auto-generated)
        "**/*.d.ts",
        # Test files (usually not needed in search)
        "**/__tests__/**",
        "**/*.test.*",
        "**/*.spec.*",
        # Python virtual environments and cache
        "**/venv/**",
        "**/.venv/**",
        "**/site-packages/**",
        "**/__pycache__/**",
        "**/__init__.py",
    ])


@dataclass
class ConventionsConfig:
    """Configuration for convention checking and storage."""
    # Reading conventions
    files: list[str] = field(default_factory=lambda: [".ragtime/CONVENTIONS.md"])
    also_search_memories: bool = True
    # Writing conventions
    storage: str = "auto"  # "auto" | "file" | "memory" | "ask"
    default_file: str = ".ragtime/CONVENTIONS.md"
    folder: str = ".ragtime/conventions/"
    scan_docs_for_sections: list[str] = field(default_factory=lambda: ["docs/"])


@dataclass
class NarrativeConfig:
    """Configuration for narrative retrieval strategy."""
    enabled: bool = False
    index_file: str = ".ragtime/narrative-index.md"
    serve_full_docs: bool = True
    max_doc_tokens: int = 2000  # Skip full-doc serving for very large files
    fallback_to_vector: bool = True  # When no manifest match, use vector search


@dataclass
class RagtimeConfig:
    """Main ragtime configuration."""
    docs: DocsConfig = field(default_factory=DocsConfig)
    code: CodeConfig = field(default_factory=CodeConfig)
    conventions: ConventionsConfig = field(default_factory=ConventionsConfig)
    narrative: NarrativeConfig = field(default_factory=NarrativeConfig)

    @classmethod
    def load(cls, project_path: Path) -> "RagtimeConfig":
        """Load config from .ragtime/config.yaml or return defaults."""
        config_path = project_path / ".ragtime" / "config.yaml"

        if not config_path.exists():
            return cls()

        try:
            with open(config_path) as f:
                data = yaml.safe_load(f) or {}
        except (IOError, yaml.YAMLError):
            return cls()

        docs_data = data.get("docs", {})
        code_data = data.get("code", {})
        conventions_data = data.get("conventions", {})
        narrative_data = data.get("narrative", {})

        return cls(
            docs=DocsConfig(
                paths=docs_data.get("paths", DocsConfig().paths),
                patterns=docs_data.get("patterns", DocsConfig().patterns),
                exclude=docs_data.get("exclude", DocsConfig().exclude),
            ),
            code=CodeConfig(
                paths=code_data.get("paths", CodeConfig().paths),
                languages=code_data.get("languages", CodeConfig().languages),
                exclude=code_data.get("exclude", CodeConfig().exclude),
            ),
            conventions=ConventionsConfig(
                files=conventions_data.get("files", ConventionsConfig().files),
                also_search_memories=conventions_data.get(
                    "also_search_memories", ConventionsConfig().also_search_memories
                ),
                storage=conventions_data.get("storage", ConventionsConfig().storage),
                default_file=conventions_data.get("default_file", ConventionsConfig().default_file),
                folder=conventions_data.get("folder", ConventionsConfig().folder),
                scan_docs_for_sections=conventions_data.get(
                    "scan_docs_for_sections", ConventionsConfig().scan_docs_for_sections
                ),
            ),
            narrative=NarrativeConfig(
                enabled=narrative_data.get("enabled", NarrativeConfig().enabled),
                index_file=narrative_data.get("index_file", NarrativeConfig().index_file),
                serve_full_docs=narrative_data.get("serve_full_docs", NarrativeConfig().serve_full_docs),
                max_doc_tokens=narrative_data.get("max_doc_tokens", NarrativeConfig().max_doc_tokens),
                fallback_to_vector=narrative_data.get("fallback_to_vector", NarrativeConfig().fallback_to_vector),
            ),
        )

    def save(self, project_path: Path) -> None:
        """Save config to .ragtime/config.yaml."""
        config_dir = project_path / ".ragtime"
        config_dir.mkdir(parents=True, exist_ok=True)
        config_path = config_dir / "config.yaml"

        data = {
            "docs": {
                "paths": self.docs.paths,
                "patterns": self.docs.patterns,
                "exclude": self.docs.exclude,
            },
            "code": {
                "paths": self.code.paths,
                "languages": self.code.languages,
                "exclude": self.code.exclude,
            },
            "conventions": {
                "files": self.conventions.files,
                "also_search_memories": self.conventions.also_search_memories,
                "storage": self.conventions.storage,
                "default_file": self.conventions.default_file,
                "folder": self.conventions.folder,
                "scan_docs_for_sections": self.conventions.scan_docs_for_sections,
            },
            "narrative": {
                "enabled": self.narrative.enabled,
                "index_file": self.narrative.index_file,
                "serve_full_docs": self.narrative.serve_full_docs,
                "max_doc_tokens": self.narrative.max_doc_tokens,
                "fallback_to_vector": self.narrative.fallback_to_vector,
            },
        }

        with open(config_path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)


def init_config(project_path: Path) -> RagtimeConfig:
    """Initialize a new config file with defaults."""
    config = RagtimeConfig()
    config.save(project_path)
    return config
