# Changelog

All notable changes to RAGuard will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.0.0] - 2026-02-14

### Added

#### TypeScript SDK (`sdk-ts/`)
- Full TypeScript/Node.js SDK published as `raguard` on npm, mirroring the Python SDK
- `RAGuard` class with async `scan()` and `filter()` methods
- Zero runtime dependencies — all detection runs in pure TypeScript
- TF-IDF vectorizer for lightweight document embeddings (no ML model downloads)
- All 3 detectors ported: Consensus Clustering (agglomerative clustering), Semantic Anomaly (distance-based outlier detection, contradiction patterns, coordinated injection), Source Reputation (40+ trusted domains, metadata, content quality)
- Accepts multiple document formats: plain strings, objects with `content`, LangChain `page_content` format, `Document` class
- Dual CJS/ESM output with full type declarations
- npm package README with install, quick start, full examples, and configuration docs

#### Dashboard Docs Page
- New `/docs` route in the Next.js dashboard with full SDK documentation
- Python/TypeScript language toggle that switches all code examples
- Sidebar navigation: Installation, Quick Start, Scanning, Filtering, Document Formats, Configuration, Detectors, Scan Result, Integrations, API Mode
- Copy-to-clipboard code blocks
- Configuration and Scan Result reference tables
- API Mode "Coming Soon" callout section
- Updated navbar and footer links to point to internal `/docs` page

#### CI/CD
- GitHub Actions workflow for PyPI publishing (`publish-pypi.yml`) — triggered on release, uses trusted publishing (OIDC)
- GitHub Actions workflow for npm publishing (`publish-npm.yml`) — triggered on release, uses `NPM_TOKEN` secret with provenance

### Changed
- Version set to `0.0.0` across all packages (Python SDK, TypeScript SDK, API server) for initial release
- Python SDK now raises `ValueError` with helpful message when `api_key` is passed (API mode coming soon)
- TypeScript SDK throws `Error` with same message when `apiKey` is passed
- Root README updated with dual Python/TypeScript quick start, npm badge, and both-language examples

## [0.1.0] - 2026-02-13

### Added

#### Core SDK
- `RAGuard` class with `scan()` and `filter()` methods as the main entry point
- Local mode (no API key, fully offline) and hosted API mode
- Auto-normalization of input formats: plain strings, dicts, LangChain-style dicts, and `Document` objects
- Configurable risk thresholds (`risk_threshold`, `warning_threshold`)
- Three-tier recommendation system: `proceed`, `cite_with_warning`, `block`

#### Detection Engines
- **Consensus Clustering Detector** — identifies Hallucination Propagation Chains (HPCs) using sentence-transformers embeddings (`all-MiniLM-L6-v2`), agglomerative clustering, and a weighted risk formula (similarity uniformity, source diversity, temporal clustering, lexical overlap)
- **Semantic Anomaly Detector** — isolation forest outlier detection, contradiction pattern matching, coordinated injection detection (low query relevance + high inter-document similarity)
- **Source Reputation Detector** — heuristic scoring with 40+ curated trusted domains (NIST, CISA, MITRE, OWASP, major vendors), metadata completeness checks, content quality analysis (promotional language, Unicode anomalies, repetition)

#### Framework Integrations
- **LangChain** — `RAGuardTransformer` (BaseDocumentTransformer), drops into any LCEL chain as a pipe stage
- **LlamaIndex** — `RAGuardPostProcessor` (BaseNodePostprocessor), plugs into query engine config

#### API Server
- FastAPI server with `POST /v1/scan`, `GET /health`, `GET /v1/usage` endpoints
- Bearer token authentication middleware (`rg_` prefixed API keys)
- In-memory rate limiting (per-minute sliding window) with tier-based limits
- ML model preloading on startup to avoid cold-start latency
- CORS middleware enabled

#### Data Models
- `Document` — content + metadata + auto-generated doc_id
- `ScanRequest` / `ScanResult` — full scan contract with per-detector breakdowns
- `DetectorResult` — risk score, flagged indices, and detailed analysis per detector
- `RAGuardConfig` — nested config for all detectors with sensible defaults

#### Utilities
- Lazy-loaded sentence-transformers with model caching
- Cosine similarity matrix computation (normalized embeddings)
- Content fingerprinting (SHA-256 hashing, n-gram extraction, n-gram overlap)
- Suspicious pattern detection (promotional density, repetition, Unicode anomalies)
- Domain extraction from URLs

#### Landing Page (Next.js + Tailwind)
- Dark-themed landing page at `dashboard/` with 6 sections: Navbar, Hero, Threat Explainer, Features, Pricing, Early Access Signup
- Hero section with animated code snippet showing 3-line RAGuard integration
- AHE threat explainer with 3-step attack breakdown and RAGuard solution callout
- Interactive tabbed integration demo (Vanilla Python, LangChain, LlamaIndex) with live code switching
- 3 detector feature cards (Consensus Clustering, Semantic Anomaly, Source Reputation)
- 3-tier pricing table (Free / Pro $499/mo / Enterprise) with feature comparison
- Early access email signup form with success state (Supabase integration in Week 2)
- Responsive design with sticky navbar, smooth scroll anchors, and animated entrance effects
- SEO metadata with Open Graph and Twitter Card tags

#### Interactive Playground
- `/playground` route with full document scanning simulation
- Pre-loaded examples: Clean Docs, Poisoned Docs (HPC), Mixed (Real Attack)
- Document input cards with content textarea and source URL fields
- Add/remove documents dynamically
- Simulated scan engine matching real SDK detection logic
- Results panel with: overall risk score, recommendation badge, flagged document count, latency
- Per-detector breakdown cards with risk badges (LOW/MEDIUM/HIGH)
- Visual flagging — poisoned documents highlighted red in the input panel
- Expandable raw JSON response viewer
- Loading spinner animation during scan

#### Documentation Site (MkDocs Material)
- `mkdocs.yml` with Material theme, dark/light toggle, code copy, search
- **Home** — overview, architecture diagram, quick example
- **Getting Started** — install, first scan, understanding results, input formats, configuration
- **Installation** — pip install options, framework extras, dev setup, server setup
- **LangChain Integration** — 1-line setup, full chain example, custom config
- **LlamaIndex Integration** — node postprocessor setup, full query engine example
- **API Reference: RAGuard Class** — constructor, scan(), filter(), modes, configuration
- **API Reference: Models** — Document, ScanResult, DetectorResult, Recommendation, ScanRequest
- **API Reference: Detectors** — all 3 detectors with algorithms, config options, and custom detector guide
- **Threat Model** — full AHE attack explanation, HPC mechanics, research findings, RAGuard detection mapping

#### Infrastructure
- `pyproject.toml` with hatchling build system, optional dependency groups (`langchain`, `llamaindex`, `server`, `dev`, `all`)
- GitHub Actions CI: ruff lint, pytest across Python 3.10/3.11/3.12, auto-publish to PyPI on tag
- 39 tests covering all detectors, SDK orchestration, API endpoints, auth, and rate limiting
- Test fixtures with realistic clean (NIST, OWASP, CISA sourced) and poisoned (DarkNebula HPC) document sets
- Next.js 16 dashboard with TypeScript, Tailwind CSS v4, static export for Vercel deployment
