# RAGuard MVP Execution Plan

## Context
RAGuard is a security middleware API for RAG pipelines that detects Adversarial Hallucination Engineering (AHE) -- where attackers plant fake documents to poison AI outputs. Team: 1 ML + 1 Backend + 1 Full-stack. Budget: $0. Timeline: 4 weeks.

---

## Architecture

```
User's RAG Pipeline
        |
   Retrieved Docs
        |
        v
+------------------+
|  RAGuard SDK     |  <-- pip install raguard
|  (Python pkg)    |
+------------------+
        |
  Local or API mode
        |
        v
+------------------+
| Detection Engine |
| - Consensus      |  Detects doc clusters forming HPCs
| - Anomaly        |  Detects semantic drift from baselines
| - Reputation     |  Scores source trustworthiness
| - Entropy        |  Detects confusion/contradiction patterns
+------------------+
        |
        v
  ScanResult JSON
  {safe, risk_score, flagged_docs, recommendation}
        |
        v
  Clean docs -> LLM
```

## Project Structure

```
raguard/
  pyproject.toml
  raguard/                   # SDK (published to PyPI)
    __init__.py
    sdk.py                   # RAGuard class - main entry point
    client.py                # API client for hosted mode
    config.py                # Settings, thresholds, tiers
    models.py                # Pydantic models (shared contract)
    detectors/
      base.py                # Abstract BaseDetector
      consensus.py           # Consensus Clustering (core differentiator)
      anomaly.py             # Semantic Anomaly Detection
      reputation.py          # Source Reputation Scoring
      entropy.py             # Token Entropy / CoTA heuristics
    integrations/
      langchain.py           # LangChain transformer + middleware
      llamaindex.py          # LlamaIndex NodePostProcessor
    utils/
      embeddings.py          # sentence-transformers helpers
      hashing.py             # Content fingerprinting
  server/                    # API server (not in PyPI)
    main.py                  # FastAPI app
    routers/
      scan.py                # POST /v1/scan
      health.py              # GET /health
      usage.py               # GET /v1/usage
    middleware/
      auth.py                # API key validation
      rate_limiter.py        # Upstash Redis rate limiting
      usage_tracker.py       # Query counting per tier
    services/
      scan_service.py
      billing_service.py
    db/
      supabase_client.py
  tests/
    test_consensus.py
    test_anomaly.py
    test_reputation.py
    test_sdk.py
    test_api.py
  dashboard/                 # Next.js on Vercel (Week 3)
```

## Infrastructure (All Free Tier)

| Component | Service | Why |
|-----------|---------|-----|
| API Server | **Koyeb** | Free always-on web service (disable scale-to-zero for ML model) |
| Database | **Supabase** | Free 500MB + built-in auth (magic link, no password system) |
| Rate Limiting | **Upstash Redis** | Free 500K commands/month |
| Landing Page | **Vercel** | Free Next.js hosting |
| ML Embeddings | **sentence-transformers/all-MiniLM-L6-v2** | Free, 80MB, runs in-process |
| Docs | **GitHub Pages + MkDocs** | Free |
| CI/CD | **GitHub Actions** | Free 2000 min/month |
| Monitoring | **Better Stack** | Free uptime monitoring |
| Email | **Resend** | Free 3000 emails/month |
| Analytics | **PostHog** | Free 1M events/month |
| Payments | **Stripe** | No monthly fee, transaction-only |

---

## Week-by-Week Execution

### WEEK 1: Core Engine + SDK (Days 1-7)

**Goal**: `pip install raguard` works locally with consensus detection.

#### ML Engineer (Person M)

| Day | Deliverable |
|-----|-------------|
| 1-2 | **Consensus Clustering Detector** - Embed docs with MiniLM-L6-v2, compute pairwise cosine similarity, agglomerative clustering, flag suspicious clusters. Risk = 0.4*similarity_uniformity + 0.3*(1-source_diversity) + 0.2*temporal_clustering + 0.1*lexical_overlap |
| 3-4 | **Semantic Anomaly Detector** - Deviation from baseline centroid, contradiction detection (negation patterns), isolation forest outlier scoring, query relevance check |
| 5-7 | **Source Reputation Scorer** (heuristic v1) - Known-good domain list (Majestic Million), metadata completeness scoring, content quality heuristics (promotional language, spelling anomalies) |

#### Backend Engineer (Person B)

| Day | Deliverable |
|-----|-------------|
| 1-2 | **Project scaffolding** - pyproject.toml, monorepo structure, Pydantic models (Document, ScanRequest, ScanResult, DetectorResult) |
| 3-4 | **SDK orchestrator** (`raguard/sdk.py`) - RAGuard class with `scan()` and `filter()` methods, local/API mode switching, document normalization |
| 5 | **LangChain integration** - RAGuardTransformer (BaseDocumentTransformer), LCEL pipe compatible |
| 6 | **LlamaIndex integration** - RAGuardPostProcessor (BaseNodePostprocessor) |
| 7 | **Tests + CI** - pytest fixtures with clean + poisoned doc sets, GitHub Actions for lint/type/test |

#### Full-Stack Engineer (Person F)

| Day | Deliverable |
|-----|-------------|
| 1-3 | **Landing page** (Vercel/Next.js) - Hero, 3-step integration demo, AHE threat explainer, pricing table, early access signup (emails to Supabase) |
| 4-5 | **Documentation site** (MkDocs + GitHub Pages) - Getting started (<5 min), API reference (auto-gen from Pydantic), integration guides |
| 6-7 | **Interactive demo/playground** - Paste docs, click Scan, see verdict with risk visualization. Pre-loaded with example poisoned docs. Primary conversion tool. |

---

### WEEK 2: Hosted API + Auth (Days 8-14)

**Goal**: Live API at `api.raguard.dev`. Users sign up, get API key, make scans.

#### ML Engineer (Person M)

| Day | Deliverable |
|-----|-------------|
| 8-10 | **Token Entropy Detector** (heuristic mode) - Contradiction markers, encoding anomaly detection (Unicode tricks, homoglyphs), prompt injection pattern detection, claim density analysis |
| 11-14 | **Evaluation framework** - 50 clean + 50 poisoned scenarios, precision/recall/F1 measurement, threshold tuning. Target: >90% precision, >70% recall |

#### Backend Engineer (Person B)

| Day | Deliverable |
|-----|-------------|
| 8-9 | **FastAPI server** - POST /v1/scan, GET /health, GET /v1/usage. Request validation, detector orchestration |
| 10-11 | **Auth + API keys** - Supabase schema (profiles, api_keys, usage_logs, usage_monthly), bcrypt key hashing, `rg_live_` prefix format, show-once creation flow |
| 12 | **Rate limiting** - Upstash Redis sliding window. Free: 1K/month + 10/min. Pro: 10K/month + 100/min |
| 13-14 | **Deploy to Koyeb** - Dockerfile (Python 3.11-slim), disable scale-to-zero, Better Stack monitoring, DNS `api.raguard.dev` |

#### Full-Stack Engineer (Person F)

| Day | Deliverable |
|-----|-------------|
| 8-10 | **Signup flow + dashboard** - Supabase Auth magic link, API key management (create/revoke/copy), usage bar chart, personalized quickstart snippet |
| 11-12 | **Interactive docs** - "Try it" buttons hitting live API with demo key, copy-paste code examples |
| 13-14 | **Onboarding emails** (Resend) - Welcome + quickstart (immediate), "Did you scan?" (Day 2), upgrade nudge (Day 7) |

---

### WEEK 3: Polish + Content (Days 15-21)

**Goal**: Feature-complete MVP. Content marketing starts. First beta users.

#### ML Engineer (Person M)

| Day | Deliverable |
|-----|-------------|
| 15-17 | **Cite-or-Silent mode** (Pro feature) - Generates LLM prompt addendum forcing citation from verified sources only. Returned as `prompt_addendum` in ScanResult |
| 18-21 | **Technical blog post** - "Adversarial Hallucination Engineering: How Attackers Poison RAG Systems" (2000-3000 words). Diagrams, code examples, RAGuard as solution. **This is the #1 content marketing asset.** |

#### Backend Engineer (Person B)

| Day | Deliverable |
|-----|-------------|
| 15-16 | **Stripe integration** - Product + Price for Pro ($499/mo), webhook handler for upgrade/downgrade |
| 17-18 | **Analytics pipeline** - Scan logging to Supabase, aggregate queries (total scans, threats, latency), PostHog tracking (signup, first scan, upgrade) |
| 19-21 | **PyPI publishing** - Clean pyproject.toml, README with badges, `pip install raguard` verified from fresh env, GitHub Actions auto-publish on tag |

#### Full-Stack Engineer (Person F)

| Day | Deliverable |
|-----|-------------|
| 15-17 | **Pro dashboard** - Scan history, threat timeline chart, document risk heatmap, CSV export |
| 18-19 | **Blog setup** + publish AHE post with OpenGraph images |
| 20-21 | **Launch assets** - Product Hunt listing, Twitter thread (10 tweets), Reddit posts (r/MachineLearning, r/LangChain, r/cybersecurity), HN "Show HN" draft, 3 LinkedIn posts |

---

### WEEK 4: Launch + First Revenue (Days 22-28)

**Goal**: Public launch. 50+ signups. 1-2 paid conversions.

#### Day 22-23: Pre-launch Checklist (ALL)

- [ ] `pip install raguard` + demo scan works
- [ ] `api.raguard.dev/health` returns 200
- [ ] Signup -> API key -> first scan end-to-end
- [ ] Landing page < 2s load time
- [ ] Docs: quickstart, LangChain, LlamaIndex, API ref
- [ ] Demo playground works with examples
- [ ] Stripe checkout live
- [ ] Onboarding emails fire

#### Day 24: LAUNCH DAY (Tuesday - optimal for HN/PH)

- 12:01 AM PST: Product Hunt live
- Morning: Twitter/X with demo GIF, "Show HN" post, Reddit cross-posts
- All day: Person F on PH comments, Person B on server health, Person M on HN/Reddit technical questions

#### Day 25-28: First 10 Customers Sprint

**Direct outreach to 50 companies:**
1. Search GitHub for repos with `langchain` + `pinecone`/`weaviate` in requirements.txt
2. LinkedIn search: "RAG engineer" at 50-500 employee companies
3. Twitter/X: people posting about RAG issues
4. Company engineering blogs mentioning RAG

**Outreach template:**
> Hi [Name], I noticed [Company] is building with [LangChain/LlamaIndex]. We just released RAGuard - a 1-line middleware that detects when attackers plant fake documents that poison RAG outputs. Recent research shows just 5 poisoned docs can achieve 90% attack success. Would you be open to a 15-min call? We'll scan your pipeline for free.

**Community presence:**
- Answer RAG accuracy/hallucination questions on Stack Overflow, Reddit, Discord
- Write "How to Audit Your RAG Pipeline" tutorial (blog post #2)

---

## SDK Design (1-Line Integration)

```python
# Vanilla Python
from raguard import RAGuard
guard = RAGuard(api_key="rg_live_xxxxx")
safe_docs = guard.filter(retrieved_docs, query=query)

# LangChain (1 line added to existing chain)
from raguard.integrations.langchain import RAGuardTransformer
chain = retriever | RAGuardTransformer(api_key="rg_live_xxxxx") | prompt | llm

# LlamaIndex (1 line in query engine config)
from raguard.integrations.llamaindex import RAGuardPostProcessor
engine = index.as_query_engine(
    node_postprocessors=[RAGuardPostProcessor(api_key="rg_live_xxxxx")]
)

# Local mode (no API key, open source, free forever)
guard = RAGuard()  # runs offline with local detectors
```

---

## Pricing

| Tier | Price | Queries/mo | Features |
|------|-------|-----------|----------|
| Free | $0 | 1,000 | 4 detectors, local mode, basic API |
| Pro | $499/mo | 10,000 | + Cite-or-Silent, dashboard, priority support |
| Enterprise | Custom | Unlimited | + On-prem, SLA, custom thresholds |

---

## Revenue Target

```
1,000 signups -> 200 regular users -> 10 Pro @ $499 = $4,990 MRR
```

---

## What to Defer (NOT in MVP)

- ML-based reputation model (needs training data)
- Logprob-based entropy analysis (needs LLM provider integration)
- Webhook notifications
- Team/org management
- SOC 2 compliance
- Custom model training
- Slack/Teams integration
- Self-hosted enterprise deployment
- Multi-language SDKs (JS/Go)

---

## Risk Mitigation

| Risk | Mitigation |
|------|-----------|
| Koyeb OOM (512MB + ML model) | MiniLM-L6-v2 quantized (~40MB); fallback to HuggingFace Inference API |
| Cold start latency | Disable scale-to-zero; preload model in startup event |
| Supabase pauses after inactivity | GitHub Actions cron ping every 6 days |
| False positives driving churn | Default high-precision thresholds; make configurable |
| $499 too expensive for startups | Add $99 Starter tier (3K queries) if needed |

---

## Content Marketing Calendar (Weeks 3-8)

| Week | Content | Channel | Owner |
|------|---------|---------|-------|
| 3 | "Adversarial Hallucination Engineering" deep-dive | Blog, HN | M |
| 4 | Launch announcement | PH, HN, Reddit, Twitter | F |
| 4 | "How to Audit Your RAG Pipeline" tutorial | Blog, Reddit | M |
| 5 | "We scanned 1000 RAG queries: here's what we found" | Blog, Twitter | M |
| 6 | LangChain integration tutorial (with video) | Blog, YouTube, Discord | F |
| 7 | "RAG Security Checklist" (PDF lead magnet) | Landing page, LinkedIn | F |
| 8 | Case study with first paying customer | Blog, LinkedIn, Twitter | B |

---

## Conversion Funnel

```
Awareness (blog, HN, Reddit, Twitter)
    |  ~1000 visitors/week (target)
    v
Interest (landing page visit)
    |  ~30% click "Get Started"
    v
Signup (free tier)
    |  ~50% complete signup
    v
Activation (first scan)
    |  ~40% run first scan within 48h
    v
Engagement (regular usage)
    |  ~20% use regularly (>10 scans/week)
    v
Revenue (upgrade to Pro)
    |  ~5% of regular users upgrade
    v
10 paying customers @ $499/mo = $4,990 MRR
```

---

## Key Technical Decisions

**Why sentence-transformers/all-MiniLM-L6-v2?**
- Free, no API key, runs locally, 80MB model
- 384 dimensions sufficient for document similarity
- No per-query cost (critical for bootstrapped)

**Why Koyeb over Railway/Render/Fly.io?**
- Railway: 30-day trial only, then $5/mo minimum
- Render: Free tier static only, dynamic starts $7/mo
- Fly.io: No real free tier anymore
- Koyeb: Permanent free tier with always-on web service

**Why Supabase?**
- Built-in auth (magic link = no password system to build)
- Row Level Security for multi-tenant isolation
- 500MB free, REST API works from edge

**Why monorepo?**
- Shared Pydantic models between SDK and server
- Single CI pipeline
- Same detector code in local and hosted mode

**Why open-source core + hosted API?**
- Open source builds dev trust
- Free local mode = zero friction adoption
- Hosted API = monetization path
- Pro features justify $499 pricing

---

## Supabase Schema

```sql
CREATE TABLE profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id),
    email TEXT NOT NULL,
    tier TEXT NOT NULL DEFAULT 'free',
    company TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE api_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES profiles(id),
    key_hash TEXT NOT NULL,
    key_prefix TEXT NOT NULL,
    name TEXT DEFAULT 'default',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE usage_logs (
    id BIGSERIAL PRIMARY KEY,
    user_id UUID REFERENCES profiles(id),
    scan_id TEXT NOT NULL,
    documents_count INT NOT NULL,
    detectors_used TEXT[] NOT NULL,
    risk_score FLOAT,
    latency_ms FLOAT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE usage_monthly (
    user_id UUID REFERENCES profiles(id),
    month DATE NOT NULL,
    query_count INT DEFAULT 0,
    PRIMARY KEY (user_id, month)
);
```

---

## Metrics to Track

### Pre-launch (Weeks 1-2)
- Detectors passing >90% of test scenarios
- SDK install + first scan in <30 seconds
- API p95 latency <500ms for 10-doc scan

### Launch (Weeks 3-4)
- Landing page visitors (target: 500+ launch week)
- Signups (target: 50+ launch week)
- First scans completed (target: 25+)
- GitHub stars (target: 100+ first month)
- PyPI downloads (target: 200+ first month)

### Post-launch (Month 2+)
- MAU (monthly active users)
- Activation rate (signup -> first scan)
- Free-to-paid conversion rate
- MRR
- Churn rate
- NPS from active users
