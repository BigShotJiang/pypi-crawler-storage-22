# RAGuard Design System

OpenAI-inspired design language: clean, minimal, monochrome with light and dark themes.

---

## Color Tokens

### Light Theme (default — `:root`)

| Token                  | Value     | Usage                        |
|------------------------|-----------|------------------------------|
| `--background`         | `#ffffff` | Page background              |
| `--background-secondary`| `#f7f7f8`| Section backgrounds          |
| `--foreground`         | `#0d0d0d` | Primary text                 |
| `--foreground-secondary`| `#6e6e80`| Secondary text               |
| `--muted`              | `#8e8ea0` | Muted text, placeholders     |
| `--border`             | `#e5e5e5` | Default borders              |
| `--border-muted`       | `#ececf1` | Subtle borders               |
| `--card`               | `#f7f7f8` | Card backgrounds             |
| `--card-elevated`      | `#ffffff` | Elevated/hover card bg       |
| `--accent`             | `#0d0d0d` | Primary buttons (black)      |
| `--accent-hover`       | `#2b2b2b` | Primary button hover         |
| `--success`            | `#10a37f` | OpenAI green — used sparingly|
| `--danger`             | `#ef4146` | Error/danger states          |
| `--warning`            | `#f59e0b` | Warning states               |

### Dark Theme (`:root.dark`)

| Token                  | Value     | Usage                        |
|------------------------|-----------|------------------------------|
| `--background`         | `#0d0d0d` | Page background              |
| `--background-secondary`| `#1a1a1a`| Section backgrounds          |
| `--foreground`         | `#ececf1` | Primary text                 |
| `--foreground-secondary`| `#acacbe`| Secondary text               |
| `--muted`              | `#8e8ea0` | Muted text, placeholders     |
| `--border`             | `#2f2f2f` | Default borders              |
| `--border-muted`       | `#1e1e1e` | Subtle borders               |
| `--card`               | `#1a1a1a` | Card backgrounds             |
| `--card-elevated`      | `#212121` | Elevated/hover card bg       |
| `--accent`             | `#ffffff` | Primary buttons (white)      |
| `--accent-hover`       | `#d1d1d1` | Primary button hover         |
| `--success`            | `#10a37f` | OpenAI green                 |
| `--danger`             | `#ef4146` | Error/danger states          |
| `--warning`            | `#f59e0b` | Warning states               |

---

## Typography

| Element      | Tailwind Classes                                        |
|-------------|----------------------------------------------------------|
| H1          | `text-5xl font-semibold tracking-tight md:text-6xl`      |
| H2          | `text-3xl font-semibold tracking-tight md:text-4xl`      |
| H3          | `text-xl font-semibold`                                  |
| Body        | `text-base font-normal leading-relaxed`                  |
| Body small  | `text-sm leading-relaxed`                                |
| Caption     | `text-xs`                                                |
| Code/Mono   | `font-mono text-sm`                                      |

**Fonts**: Inter (sans), JetBrains Mono (mono)

---

## Buttons

### Primary (pill, high-contrast)
```
bg-accent text-background rounded-full px-5 py-2.5 font-medium
hover:bg-accent-hover transition
```

### Secondary (outlined pill)
```
border border-border bg-transparent text-foreground rounded-full px-5 py-2.5 font-medium
hover:bg-card transition
```

### Ghost
```
text-foreground-secondary bg-transparent
hover:text-foreground transition
```

---

## Cards

```
border border-border bg-card rounded-2xl p-6
hover:border-border hover:bg-card-elevated transition
```

---

## Border Radius

| Element  | Value            |
|----------|------------------|
| Buttons  | `rounded-full`   |
| Cards    | `rounded-2xl`    |
| Badges   | `rounded-full`   |
| Inputs   | `rounded-xl`     |

---

## Shadows

Minimal. Only for elevated elements:
```
shadow-sm  →  0 1px 2px rgba(0,0,0,0.05)
```

---

## Animations

- `fade-in`: translateY(20px) → 0, opacity 0 → 1, 0.6s ease-out
- `fade-up`: translateY(10px) → 0, opacity 0 → 1, 0.5s ease-out (subtle variant)
- Stagger delays: 0.2s, 0.4s

---

## Theme Switching

- Light is default (`:root`)
- Dark uses `.dark` class on `<html>` (`:root.dark`)
- System preference detected via inline script before render
- User toggle persists to `localStorage` key `"theme"`
- `@media (prefers-color-scheme: dark)` used as initial fallback

---

## Selection

```css
::selection {
  background: var(--foreground);
  color: var(--background);
}
```
