import { ImageResponse } from "next/og";

export const size = { width: 32, height: 32 };
export const contentType = "image/png";

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: 32,
          height: 32,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <svg
          viewBox="0 0 32 32"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          width="32"
          height="32"
        >
          <path
            d="M16 2L4 8v8c0 7.73 5.12 14.95 12 16 6.88-1.05 12-8.27 12-16V8L16 2z"
            fill="#0d0d0d"
          />
          <path
            d="M16 6L8 10v5c0 5.15 3.41 9.97 8 10.67 4.59-.7 8-5.52 8-10.67v-5L16 6z"
            fill="white"
          />
          <path
            d="M16 10L11 12.5v3c0 3.09 2.04 5.98 5 6.4 2.96-.42 5-3.31 5-6.4v-3L16 10z"
            fill="#0d0d0d"
          />
        </svg>
      </div>
    ),
    { ...size }
  );
}
