import type { Metadata } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { PostHogProvider } from "./providers";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  variable: "--font-jetbrains",
  subsets: ["latin"],
  display: "swap",
});

const DOMAIN = "https://raguard.deepseal.ai";

export const metadata: Metadata = {
  metadataBase: new URL(DOMAIN),
  title: {
    default:
      "RAGuard by DeepSeal | Detect Poisoned Documents in RAG Pipelines",
    template: "%s | RAGuard by DeepSeal",
  },
  description:
    "RAGuard is a security API that detects adversarial document poisoning in RAG pipelines. Ships as Python and TypeScript SDKs with native LangChain and LlamaIndex support. Built by DeepSeal.",
  applicationName: "RAGuard",
  authors: [{ name: "DeepSeal", url: "https://deepseal.ai" }],
  creator: "DeepSeal",
  publisher: "DeepSeal",
  generator: "Next.js",
  referrer: "origin-when-cross-origin",
  keywords: [
    "RAG security",
    "RAG poisoning detection",
    "hallucination detection API",
    "LLM security middleware",
    "adversarial hallucination engineering",
    "retrieval augmented generation security",
    "document poisoning detection",
    "LangChain security",
    "LlamaIndex security",
    "AI security API",
    "RAG pipeline protection",
    "enterprise AI security",
    "SOC AI security",
    "hallucination propagation chain",
    "DeepSeal",
    "RAGuard",
  ],
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  alternates: {
    canonical: DOMAIN,
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: DOMAIN,
    siteName: "RAGuard by DeepSeal",
    title: "RAGuard | Detect Poisoned Documents in RAG Pipelines",
    description:
      "Security API that catches adversarial document poisoning before it reaches your LLM. Python and TypeScript SDKs with LangChain and LlamaIndex support.",
    images: [
      {
        url: `${DOMAIN}/og-image.png`,
        width: 1200,
        height: 630,
        alt: "RAGuard by DeepSeal — RAG Pipeline Security",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "RAGuard | Detect Poisoned Documents in RAG Pipelines",
    description:
      "Security API for RAG pipelines. Catches adversarial document poisoning in real-time. By DeepSeal.",
    creator: "@deaborai",
    images: [`${DOMAIN}/og-image.png`],
  },
  category: "technology",
  classification: "AI Security",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: "RAGuard",
    applicationCategory: "SecurityApplication",
    operatingSystem: "Cross-platform",
    url: DOMAIN,
    author: {
      "@type": "Organization",
      name: "DeepSeal",
      url: "https://deepseal.ai",
    },
    offers: [
      {
        "@type": "Offer",
        name: "Free",
        price: "0",
        priceCurrency: "USD",
        description: "1,000 scans per month",
      },
      {
        "@type": "Offer",
        name: "Pro",
        price: "499",
        priceCurrency: "USD",
        billingIncrement: "P1M",
        description: "10,000 scans per month with Cite-or-Silent enforcement",
      },
    ],
    description:
      "Security middleware that detects adversarial document poisoning in RAG pipelines. Python and TypeScript SDKs with LangChain and LlamaIndex integrations.",
    softwareVersion: "0.1.0",
    programmingLanguage: ["Python", "TypeScript"],
  };

  const orgJsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "DeepSeal",
    url: "https://deepseal.ai",
    logo: `${DOMAIN}/deepseal-logo.png`,
    sameAs: [],
  };

  // Inline script to detect system theme before render (prevents flash)
  const themeScript = `
    (function() {
      try {
        var stored = localStorage.getItem('theme');
        if (stored === 'dark') {
          document.documentElement.classList.add('dark');
        } else if (stored === 'light') {
          document.documentElement.classList.remove('dark');
        } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
          document.documentElement.classList.add('dark');
        }
      } catch (e) {}
    })();
  `;

  return (
    <html lang="en" className="scroll-smooth" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
        <link rel="canonical" href={DOMAIN} />
        <link rel="sitemap" href="/sitemap.xml" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(orgJsonLd) }}
        />
      </head>
      <body className={`${inter.variable} ${jetbrains.variable} antialiased`}>
        <PostHogProvider>{children}</PostHogProvider>
      </body>
    </html>
  );
}
