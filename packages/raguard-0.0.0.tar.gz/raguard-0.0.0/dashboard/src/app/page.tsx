"use client";

import { useState, useEffect } from "react";

/* ─────────────────────── SVG Icons ─────────────────────── */

function CheckIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 16 16" fill="none" className={className} xmlns="http://www.w3.org/2000/svg">
      <polyline
        points="3.5,8 6.5,11 12.5,5"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  );
}

function SunIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="12" r="5" stroke="currentColor" strokeWidth="1.5" />
      <line x1="12" y1="1" x2="12" y2="3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <line x1="12" y1="21" x2="12" y2="23" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <line x1="1" y1="12" x2="3" y2="12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <line x1="21" y1="12" x2="23" y2="12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

function MoonIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

/* ─────────────────────── Theme Toggle ─────────────────────── */
function ThemeToggle() {
  const [dark, setDark] = useState(false);

  useEffect(() => {
    setDark(document.documentElement.classList.contains("dark"));
  }, []);

  const toggle = () => {
    const next = !dark;
    setDark(next);
    const el = document.documentElement;
    if (next) {
      el.classList.add("dark");
    } else {
      el.classList.remove("dark");
    }
    localStorage.setItem("theme", next ? "dark" : "light");
  };

  return (
    <button
      onClick={toggle}
      className="flex h-9 w-9 items-center justify-center rounded-full border border-border text-foreground-secondary transition hover:text-foreground"
      aria-label="Toggle theme"
    >
      {dark ? <SunIcon /> : <MoonIcon />}
    </button>
  );
}

/* ─────────────────────── Navbar ─────────────────────── */
function Navbar() {
  return (
    <nav className="fixed top-0 z-50 w-full border-b border-border/50 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
        <a href="/" className="flex items-center gap-2">
          <span className="text-lg font-semibold tracking-tight">RAGuard</span>
          <span className="text-xs text-muted">by DeepSeal</span>
        </a>
        <div className="hidden items-center gap-8 text-sm text-foreground-secondary md:flex">
          <a href="#threat" className="transition hover:text-foreground">
            The Threat
          </a>
          <a href="#features" className="transition hover:text-foreground">
            Features
          </a>
          <a href="#pricing" className="transition hover:text-foreground">
            Pricing
          </a>
          <a href="/playground" className="transition hover:text-foreground">
            Playground
          </a>
          <a
            href="/docs"
            className="transition hover:text-foreground"
          >
            Docs
          </a>
        </div>
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <a
            href="#signup"
            className="rounded-full bg-accent/60 px-5 py-2 text-sm font-medium text-background cursor-default"
          >
            API Coming Soon
          </a>
        </div>
      </div>
    </nav>
  );
}

/* ─────────────────────── Hero ─────────────────────── */
function Hero() {
  return (
    <section className="relative flex min-h-screen flex-col items-center justify-center px-6 pt-16 text-center">
      <div className="animate-fade-in relative z-10">
        <p className="mb-6 font-mono text-sm text-muted">
          pip install raguard &middot; npm install raguard
        </p>
        <h1 className="mx-auto max-w-4xl text-5xl font-semibold leading-tight tracking-tight md:text-7xl">
          Your RAG Pipeline Has{" "}
          <span className="text-success">a Poisoning Problem</span>
        </h1>
      </div>

      <p className="animate-fade-in-delay relative z-10 mt-6 max-w-2xl text-lg leading-relaxed text-foreground-secondary md:text-xl">
        5 fake documents. That&apos;s all it takes to make your AI recommend
        whitelisting malware. RAGuard is the security layer that sits between
        your retriever and your LLM, catching{" "}
        <strong className="text-foreground">
          Hallucination Propagation Chains
        </strong>{" "}
        before they do damage.
      </p>

      <div className="animate-fade-in-delay-2 relative z-10 mt-10 flex flex-col gap-4 sm:flex-row">
        <a
          href="#signup"
          className="rounded-full bg-accent/60 px-8 py-3 text-base font-semibold text-background cursor-default"
        >
          API Coming Soon
        </a>
        <a
          href="/playground"
          className="rounded-full border border-border bg-transparent px-8 py-3 text-base font-semibold transition hover:bg-card"
        >
          See It In Action
        </a>
      </div>

      {/* Code snippet */}
      <div className="animate-fade-in-delay-2 relative z-10 mt-16 w-full max-w-2xl">
        <div className="rounded-2xl border border-border bg-card p-6 text-left font-mono text-sm">
          <div className="mb-3 flex items-center gap-2">
            <span className="text-xs text-muted">your_rag_app.py</span>
          </div>
          <code className="text-foreground">
            <span className="text-syntax-keyword">from</span> raguard{" "}
            <span className="text-syntax-keyword">import</span>{" "}
            <span className="text-syntax-variable">RAGuard</span>
            <br />
            <br />
            guard = <span className="text-syntax-variable">RAGuard</span>()
            <br />
            safe_docs = guard.
            <span className="text-syntax-function">filter</span>(retrieved_docs, query=
            <span className="text-syntax-string">&quot;...&quot;</span>)
            <br />
            <span className="text-syntax-comment">
              # Poisoned documents never reach your LLM
            </span>
          </code>
        </div>
      </div>

      {/* Trust signals */}
      <p className="relative z-10 mt-12 text-sm text-muted">
        Python &amp; TypeScript SDKs &middot; LangChain &amp; LlamaIndex &middot; Local or API mode
      </p>
    </section>
  );
}

/* ─────────────────────── Threat Explainer ─────────────────────── */
function ThreatExplainer() {
  const steps = [
    {
      title: "Attacker Plants Fake Documents",
      desc: "Multiple documents containing the same false claim get injected into public wikis, web pages, or directly into your vector database.",
      severity: "STEP 1",
    },
    {
      title: "Your Retriever Takes the Bait",
      desc: 'The retriever pulls 5+ sources that all "agree" with each other. The LLM sees consensus and treats the lie as established fact.',
      severity: "STEP 2",
    },
    {
      title: "Your AI Gives Dangerous Advice",
      desc: '"DarkNebula is safe — whitelist it." Research shows a 38% attack success rate with just 5 poisoned documents. Bigger models are more vulnerable.',
      severity: "STEP 3",
    },
  ];

  return (
    <section id="threat" className="py-24 px-6">
      <div className="mx-auto max-w-6xl">
        <h2 className="text-center text-3xl font-semibold tracking-tight md:text-4xl">
          The Attack Nobody&apos;s Talking About
        </h2>
        <p className="mx-auto mt-4 max-w-2xl text-center text-foreground-secondary">
          <strong className="text-foreground">
            Adversarial Hallucination Engineering
          </strong>{" "}
          doesn&apos;t target your LLM. It targets the documents your LLM
          trusts. No jailbreak needed — just fake consensus.
        </p>

        <div className="mx-auto mt-16 max-w-2xl space-y-10">
          {steps.map((step, idx) => (
            <div key={idx}>
              <p className="text-sm font-medium text-muted">{step.severity}</p>
              <h3 className="mt-1 text-xl font-semibold">{step.title}</h3>
              <p className="mt-2 leading-relaxed text-foreground-secondary">{step.desc}</p>
            </div>
          ))}
        </div>

        <div className="mx-auto mt-16 max-w-2xl text-center">
          <h3 className="text-2xl font-semibold text-success">
            RAGuard Catches This
          </h3>
          <p className="mt-2 leading-relaxed text-foreground-secondary">
            Three detection engines — consensus clustering, semantic anomaly,
            and source reputation — analyze every retrieved document{" "}
            <strong className="text-foreground">
              before it reaches your LLM
            </strong>
            . Poisoned clusters get flagged. Clean documents pass through.
          </p>
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────── Features / Integration Demo ─────────────────────── */
function Features() {
  const integrations = [
    {
      name: "Python",
      code: `from raguard import RAGuard

guard = RAGuard()  # local mode, no API key needed
result = guard.scan(retrieved_docs, query=query)

if result.safe:
    # pass docs to your LLM
    ...
else:
    # result.flagged_documents tells you which ones to drop
    safe_docs = guard.filter(retrieved_docs, query=query)`,
    },
    {
      name: "TypeScript",
      code: `import { RAGuard } from "raguard";

const guard = new RAGuard();
const result = await guard.scan(retrievedDocs, { query });

if (result.safe) {
  // pass docs to your LLM
} else {
  // result.flaggedDocuments tells you which ones to drop
  const safeDocs = await guard.filter(retrievedDocs, { query });
}`,
    },
    {
      name: "LangChain",
      code: `from raguard.integrations.langchain import RAGuardTransformer

# One line added to your existing LCEL chain
chain = retriever | RAGuardTransformer() | prompt | llm

# That's it. Poisoned docs get dropped before the prompt.`,
    },
    {
      name: "LlamaIndex",
      code: `from raguard.integrations.llamaindex import RAGuardPostProcessor

engine = index.as_query_engine(
    node_postprocessors=[RAGuardPostProcessor()]
)

# RAGuard runs as a postprocessor on every query.`,
    },
  ];

  const [active, setActive] = useState(0);

  return (
    <section id="features" className="bg-background-secondary py-24 px-6">
      <div className="mx-auto max-w-6xl">
        <h2 className="text-center text-3xl font-semibold tracking-tight md:text-4xl">
          Drop-In Integration.{" "}
          <span className="text-success">Zero Infrastructure.</span>
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-center text-foreground-secondary">
          RAGuard runs locally by default. No API key, no external calls, no
          data leaving your network. Add it in one line.
        </p>

        <div className="mt-12 flex justify-center gap-2">
          {integrations.map((item, i) => (
            <button
              key={item.name}
              onClick={() => setActive(i)}
              className={`rounded-full px-5 py-2 text-sm font-medium transition ${
                active === i
                  ? "bg-accent text-background"
                  : "border border-border bg-transparent text-foreground-secondary hover:text-foreground"
              }`}
            >
              {item.name}
            </button>
          ))}
        </div>

        <div className="mx-auto mt-6 max-w-2xl rounded-2xl border border-border bg-background p-6 font-mono text-sm">
          <pre className="overflow-x-auto whitespace-pre text-foreground-secondary">
            {integrations[active].code}
          </pre>
        </div>

        {/* Detectors */}
        <div className="mx-auto mt-20 max-w-2xl space-y-10">
          <div>
            <h3 className="text-lg font-semibold">Consensus Clustering</h3>
            <p className="mt-2 leading-relaxed text-foreground-secondary">
              Detects Hallucination Propagation Chains — when multiple documents suspiciously agree with each other. Uses sentence embeddings, agglomerative clustering, and a weighted risk formula across 4 signals.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold">Semantic Anomaly</h3>
            <p className="mt-2 leading-relaxed text-foreground-secondary">
              Isolation forest outlier detection, contradiction pattern matching, and coordinated injection detection. Catches documents that are statistically wrong for the context.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold">Source Reputation</h3>
            <p className="mt-2 leading-relaxed text-foreground-secondary">
              Scores every document against 40+ trusted domains (NIST, CISA, MITRE, OWASP). Penalizes missing metadata, promotional language, and suspicious content patterns.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────── Pricing ─────────────────────── */
function Pricing() {
  const plans = [
    {
      name: "Free",
      price: "$0",
      period: "forever",
      desc: "For side projects and evaluation",
      metrics: {
        Scans: "1K / mo",
        Detectors: "3",
        Mode: "Local",
        Support: "Community",
      },
      features: [
        "LangChain + LlamaIndex",
        "Full offline mode",
        "Basic dashboard",
      ],
      cta: "Coming Soon",
      highlight: false,
    },
    {
      name: "Pro",
      price: "$499",
      period: "/month",
      desc: "For production RAG pipelines",
      metrics: {
        Scans: "10K / mo",
        Detectors: "All",
        Mode: "API + Local",
        Support: "Priority",
      },
      features: [
        "Cite-or-Silent enforcement",
        "Usage dashboard & analytics",
        "Source reputation tracking",
        "Custom detection thresholds",
      ],
      cta: "Coming Soon",
      highlight: true,
    },
    {
      name: "Enterprise",
      price: "Custom",
      period: "",
      desc: "For regulated industries and SOCs",
      metrics: {
        Scans: "Unlimited",
        Detectors: "All + Custom",
        Mode: "On-prem",
        Support: "Dedicated",
      },
      features: [
        "SLA guarantee",
        "Dedicated support engineer",
        "Audit-ready compliance reports",
        "Custom model training",
      ],
      cta: "Coming Soon",
      highlight: false,
    },
  ];

  return (
    <section id="pricing" className="py-24 px-6">
      <div className="mx-auto max-w-6xl">
        <h2 className="text-center text-3xl font-semibold tracking-tight md:text-4xl">
          Pricing That Scales With You
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-center text-foreground-secondary">
          Start with the free tier. Upgrade when your pipeline goes to
          production.
        </p>

        <div className="mt-16 grid gap-16 md:grid-cols-3">
          {plans.map((plan) => (
            <div key={plan.name}>
              {plan.highlight && (
                <p className="mb-2 text-xs font-bold uppercase tracking-wider text-success">
                  Most Popular
                </p>
              )}
              <h3 className="text-xl font-semibold">{plan.name}</h3>
              <div className="mt-3">
                <span className="text-4xl font-semibold">{plan.price}</span>
                <span className="text-muted">{plan.period}</span>
              </div>
              <p className="mt-2 text-sm text-foreground-secondary">{plan.desc}</p>

              {/* Metrics */}
              <div className="mt-6 space-y-1 text-sm">
                {Object.entries(plan.metrics).map(([key, value]) => (
                  <p key={key} className="text-foreground-secondary">
                    <span className="text-muted">{key}:</span>{" "}
                    <span className="font-medium text-foreground">{value}</span>
                  </p>
                ))}
              </div>

              {/* Feature list */}
              <ul className="mt-5 space-y-1.5">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <span className="mt-0.5 text-success">
                      <CheckIcon />
                    </span>
                    <span className="text-foreground-secondary">{f}</span>
                  </li>
                ))}
              </ul>

              <span
                className={`mt-8 block w-full cursor-default rounded-full py-3 text-center text-sm font-semibold ${
                  plan.highlight
                    ? "bg-accent/60 text-background"
                    : "border border-border text-muted"
                }`}
              >
                {plan.cta}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────── Signup / Coming Soon ─────────────────────── */
function Signup() {
  return (
    <section id="signup" className="bg-background-secondary py-24 px-6">
      <div className="mx-auto max-w-xl text-center">
        <h2 className="text-3xl font-semibold tracking-tight md:text-4xl">
          API Coming Soon
        </h2>
        <p className="mt-4 text-foreground-secondary">
          We&apos;re building the hosted API with free and pro tiers.
          In the meantime, run RAGuard locally with the SDK.
        </p>
        <p className="mt-6 font-mono text-sm text-foreground-secondary">
          pip install raguard &middot; npm install raguard
        </p>
      </div>
    </section>
  );
}

/* ─────────────────────── Footer ─────────────────────── */
function Footer() {
  return (
    <footer className="border-t border-border py-12 px-6">
      <div className="mx-auto max-w-6xl">
        <div className="flex flex-col items-center justify-between gap-8 md:flex-row md:items-start">
          {/* Brand */}
          <div className="flex flex-col items-center md:items-start">
            <a href="/" className="flex items-center gap-2">
              <span className="text-lg font-semibold tracking-tight">RAGuard</span>
            </a>
            <p className="mt-2 text-xs text-muted">
              Built by{" "}
              <a
                href="https://deepseal.ai"
                className="text-foreground underline underline-offset-2 transition hover:text-foreground-secondary"
                target="_blank"
                rel="noopener noreferrer"
              >
                DeepSeal
              </a>
            </p>
          </div>

          {/* Links */}
          <div className="flex gap-12 text-sm">
            <div className="flex flex-col gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-muted">
                Product
              </span>
              <a
                href="/playground"
                className="text-foreground-secondary transition hover:text-foreground"
              >
                Playground
              </a>
              <a
                href="#pricing"
                className="text-foreground-secondary transition hover:text-foreground"
              >
                Pricing
              </a>
              <a
                href="/docs"
                className="text-foreground-secondary transition hover:text-foreground"
              >
                Docs
              </a>
            </div>
            <div className="flex flex-col gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-muted">
                Company
              </span>
              <a
                href="https://deepseal.ai"
                className="text-foreground-secondary transition hover:text-foreground"
                target="_blank"
                rel="noopener noreferrer"
              >
                DeepSeal
              </a>
              <a
                href="https://x.com/deaborai"
                className="text-foreground-secondary transition hover:text-foreground"
                target="_blank"
                rel="noopener noreferrer"
              >
                Twitter/X
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 border-t border-border pt-6 text-center text-xs text-muted">
          &copy; {new Date().getFullYear()} DeepSeal. All rights reserved.
        </div>
      </div>
    </footer>
  );
}

/* ─────────────────────── Page ─────────────────────── */
export default function Home() {
  return (
    <>
      <Navbar />
      <Hero />
      <ThreatExplainer />
      <Features />
      <Pricing />
      <Signup />
      <Footer />
    </>
  );
}
