# Detectors

RAGuard ships with 3 detection engines. Each runs independently and produces its own `DetectorResult`.

## Consensus Clustering

**Name:** `consensus_clustering`

Detects Hallucination Propagation Chains (HPCs) — clusters of documents that are suspiciously similar, suggesting coordinated poisoning.

**How it works:**

1. Embeds all documents using sentence-transformers
2. Computes pairwise cosine similarity matrix
3. Runs agglomerative clustering with a distance threshold
4. Scores suspicious clusters based on 4 signals:

| Signal | Weight | What it measures |
|--------|--------|-----------------|
| Similarity uniformity | 0.4 | How identical the cluster members are |
| Source diversity | 0.3 | Low diversity = suspicious |
| Temporal clustering | 0.2 | Published around the same time |
| Lexical overlap | 0.1 | Shared unusual n-grams |

**Configuration:**

```python
RAGuard(config={
    "consensus": {
        "similarity_threshold": 0.75,  # Clustering distance threshold
        "min_cluster_size": 2,         # Minimum docs to form a cluster
    }
})
```

---

## Semantic Anomaly

**Name:** `semantic_anomaly`

Catches documents that are statistically anomalous in the retrieved set.

**Signals detected:**

- **Isolation forest outliers** — documents that don't fit the embedding distribution
- **Low query relevance** — documents retrieved but not relevant to the query
- **Contradiction patterns** — negation language ("however", "actually not", "incorrect")
- **Coordinated injection** — low-relevance documents that are similar to each other

**Configuration:**

```python
RAGuard(config={
    "anomaly": {
        "contamination": 0.1,         # Expected fraction of outliers
        "min_relevance_score": 0.3,   # Below this = low relevance
    }
})
```

!!! note
    Requires at least 3 documents to run isolation forest. Returns zero risk for smaller sets.

---

## Source Reputation

**Name:** `source_reputation`

Scores document trustworthiness based on provenance signals.

**Checks performed:**

1. **Domain trust** — matched against a curated database of 40+ trusted security domains (NIST, CISA, MITRE, OWASP, major vendors)
2. **Metadata completeness** — documents with `source`, `author`, `date`, `title` score higher
3. **Content quality** — penalizes promotional language, unusual Unicode characters, excessive repetition

**Configuration:**

```python
RAGuard(config={
    "reputation": {
        "unknown_domain_score": 0.4,   # Score for unlisted domains
    }
})
```

**Adding custom trusted domains:**

```python
from raguard.detectors.reputation import SourceReputationDetector

detector = SourceReputationDetector(
    custom_trusted_domains={
        "internal.company.com": 0.95,
        "wiki.company.com": 0.90,
    }
)
```

---

## Writing custom detectors

Extend `BaseDetector` to add your own:

```python
from raguard.detectors.base import BaseDetector
from raguard.models import DetectorResult, Document
import numpy as np

class MyDetector(BaseDetector):
    name = "my_detector"

    def detect(
        self,
        documents: list[Document],
        query: str | None = None,
        embeddings: np.ndarray | None = None,
        query_embedding: np.ndarray | None = None,
        **kwargs,
    ) -> DetectorResult:
        # Your detection logic here
        return DetectorResult(
            detector_name=self.name,
            risk_score=0.0,
            flagged_indices=[],
            details={},
        )
```

Register it:

```python
from raguard.detectors import DETECTOR_REGISTRY
DETECTOR_REGISTRY["my_detector"] = MyDetector

guard = RAGuard(detectors=["my_detector", "consensus_clustering"])
```
