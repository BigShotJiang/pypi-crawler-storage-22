# Data Models

All models are Pydantic v2 BaseModels defined in `raguard.models`.

## Document

```python
from raguard import Document

doc = Document(
    content="CVE-2024-1234 is a critical vulnerability...",
    metadata={
        "source": "https://nvd.nist.gov/vuln/CVE-2024-1234",
        "author": "NIST",
        "date": "2024-03-15",
        "title": "CVE-2024-1234 Detail",
    },
    doc_id="abc123",  # Optional, auto-generated if not provided
)
```

| Field | Type | Description |
|-------|------|-------------|
| `content` | `str` | Document text content (required) |
| `metadata` | `dict[str, Any]` | Arbitrary metadata. `source`, `author`, `date`, `title` are used by detectors. |
| `doc_id` | `str \| None` | Unique ID. Auto-generated if omitted. |

## ScanResult

Returned by `guard.scan()`.

```python
result = guard.scan(documents)
```

| Field | Type | Description |
|-------|------|-------------|
| `safe` | `bool` | `True` if risk is below `warning_threshold` |
| `overall_risk_score` | `float` | 0.0 (safe) to 1.0 (dangerous) |
| `recommendation` | `Recommendation` | `proceed`, `cite_with_warning`, or `block` |
| `flagged_documents` | `list[int]` | Indices of flagged documents |
| `detectors` | `dict[str, DetectorResult]` | Per-detector results |
| `scan_id` | `str` | Unique scan identifier |
| `latency_ms` | `float` | Processing time in milliseconds |
| `documents_scanned` | `int` | Number of documents processed |
| `prompt_addendum` | `str \| None` | Cite-or-Silent prompt (Pro feature) |

## DetectorResult

Per-detector output, nested inside `ScanResult.detectors`.

| Field | Type | Description |
|-------|------|-------------|
| `detector_name` | `str` | Name of the detector |
| `risk_score` | `float` | 0.0 to 1.0 |
| `flagged_indices` | `list[int]` | Document indices flagged by this detector |
| `details` | `dict[str, Any]` | Detector-specific details |

## Recommendation

```python
from raguard import Recommendation

Recommendation.PROCEED           # "proceed" — safe to use
Recommendation.CITE_WITH_WARNING # "cite_with_warning" — use with caution
Recommendation.BLOCK             # "block" — do not use these documents
```

## ScanRequest

Used by the API server. Not needed for SDK usage.

| Field | Type | Description |
|-------|------|-------------|
| `documents` | `list[Document]` | Documents to scan |
| `query` | `str \| None` | Original query |
| `detectors` | `list[str] \| None` | Detectors to run |
| `config` | `dict \| None` | Config overrides |
