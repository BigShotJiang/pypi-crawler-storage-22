# RAGuard Class

The main entry point for scanning documents.

## Constructor

```python
RAGuard(
    api_key: str | None = None,
    config: RAGuardConfig | dict | None = None,
    detectors: list[str] | None = None,
    api_url: str | None = None,
)
```

| Parameter | Description |
|-----------|-------------|
| `api_key` | If provided, uses hosted API. Otherwise runs locally. |
| `config` | Configuration overrides (dict or `RAGuardConfig`). |
| `detectors` | List of detector names to enable. `None` = all. |
| `api_url` | Custom API URL for self-hosted deployments. |

## Methods

### `scan()`

```python
result = guard.scan(
    documents: list[Document | dict | str],
    query: str | None = None,
) -> ScanResult
```

Scans documents and returns a full result with per-detector breakdowns.

### `filter()`

```python
safe_docs = guard.filter(
    documents: list[Document | dict | str],
    query: str | None = None,
) -> list[Document]
```

Convenience method — scans and returns only safe documents.

## Modes

### Local mode (default)

```python
guard = RAGuard()  # No API key = runs locally
```

- All detection runs in-process
- Uses sentence-transformers for embeddings (~200MB model, downloaded once)
- No network calls
- Free forever

### API mode

```python
guard = RAGuard(api_key="rg_live_xxxxx")
```

- Sends documents to hosted RAGuard API
- Server-side detection with full engine suite
- Usage tracked against your plan quota

## Configuration

```python
guard = RAGuard(config={
    "risk_threshold": 0.7,          # Score above this → BLOCK
    "warning_threshold": 0.4,       # Score above this → CITE_WITH_WARNING
    "embedding_model": "all-MiniLM-L6-v2",
    "enabled_detectors": [
        "consensus_clustering",
        "semantic_anomaly",
        "source_reputation",
    ],
    "consensus": {
        "similarity_threshold": 0.75,
        "min_cluster_size": 2,
    },
    "anomaly": {
        "contamination": 0.1,
        "min_relevance_score": 0.3,
    },
    "reputation": {
        "unknown_domain_score": 0.4,
    },
})
```

## Available detectors

| Name | Description |
|------|-------------|
| `consensus_clustering` | Detects Hallucination Propagation Chains via document clustering |
| `semantic_anomaly` | Isolation forest outliers, contradiction detection |
| `source_reputation` | Domain trust scoring, metadata completeness |
