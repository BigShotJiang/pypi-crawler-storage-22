# RAGuard

**Security middleware for RAG pipelines — detect adversarial hallucination attacks before they reach your LLM.**

---

## What is RAGuard?

RAGuard protects your Retrieval-Augmented Generation pipeline from **Adversarial Hallucination Engineering (AHE)** — where attackers plant fake documents that trick your AI into producing dangerous outputs.

It detects **Hallucination Propagation Chains (HPCs)**: clusters of fake documents that "agree" with each other to create a false consensus that fools your LLM.

## How it works

```
Your RAG Pipeline
       |
  Retrieved Docs
       |
       v
+--------------+
|   RAGuard    |  ← scans for adversarial content
+--------------+
       |
  Safe Docs Only
       |
       v
  Your LLM
```

RAGuard runs 3 detection engines on every retrieval:

| Detector | What It Catches |
|----------|----------------|
| **Consensus Clustering** | Groups of documents suspiciously saying the same thing |
| **Semantic Anomaly** | Documents that are statistical outliers or contradict baselines |
| **Source Reputation** | Documents from untrusted or unknown sources |

## Quick example

```python
from raguard import RAGuard

guard = RAGuard()
safe_docs = guard.filter(retrieved_docs, query="What is CVE-2024-1234?")
# Only verified documents reach your LLM
```

## Next steps

- [Getting Started](getting-started.md) — install and run your first scan in under 5 minutes
- [LangChain Integration](integrations/langchain.md) — add RAGuard to your LCEL chain
- [LlamaIndex Integration](integrations/llamaindex.md) — use as a node postprocessor
- [API Reference](api/raguard.md) — full SDK documentation
