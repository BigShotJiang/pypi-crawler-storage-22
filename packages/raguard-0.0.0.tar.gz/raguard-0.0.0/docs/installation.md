# Installation

## Basic install

```bash
pip install raguard
```

This installs the core SDK with all 3 detection engines. Works fully offline — no API key needed.

## With framework integrations

=== "LangChain"
    ```bash
    pip install raguard[langchain]
    ```

=== "LlamaIndex"
    ```bash
    pip install raguard[llamaindex]
    ```

=== "Everything"
    ```bash
    pip install raguard[all]
    ```

## For development

```bash
git clone https://github.com/sarmadnawaz/raguard.git
cd raguard
python -m venv .venv && source .venv/bin/activate
pip install -e ".[all]"
pytest tests/ -v
```

## Running the API server

```bash
pip install raguard[server]
uvicorn server.main:app --reload --port 8000
```

Then use with an API key:

```python
guard = RAGuard(api_key="rg_live_xxxxx", api_url="http://localhost:8000")
```

## Requirements

- Python 3.10+
- ~200MB disk space (for sentence-transformers model, downloaded on first use)
