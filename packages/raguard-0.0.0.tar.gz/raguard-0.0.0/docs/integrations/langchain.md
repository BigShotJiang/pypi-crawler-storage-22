# LangChain Integration

Add RAGuard to any LangChain LCEL chain with 1 line.

## Install

```bash
pip install raguard[langchain]
```

## Basic usage

```python
from raguard.integrations.langchain import RAGuardTransformer

guard = RAGuardTransformer()

# Add to your existing LCEL chain
chain = retriever | guard | prompt | llm | output_parser
```

That's it. RAGuard will filter out adversarial documents before they reach the prompt.

## With API key (hosted mode)

```python
guard = RAGuardTransformer(api_key="rg_live_xxxxx")
chain = retriever | guard | prompt | llm
```

## Custom configuration

```python
guard = RAGuardTransformer(
    risk_threshold=0.6,                        # More aggressive filtering
    detectors=["consensus_clustering"],         # Only run consensus detector
    config={"warning_threshold": 0.3},          # Lower warning threshold
)
```

## Full chain example

```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from raguard.integrations.langchain import RAGuardTransformer

# Your existing setup
retriever = vectorstore.as_retriever(search_kwargs={"k": 10})
prompt = ChatPromptTemplate.from_template(
    "Answer based on context:\n{context}\n\nQuestion: {question}"
)
llm = ChatOpenAI(model="gpt-4")

# Add RAGuard (1 new line)
guard = RAGuardTransformer()

# Build chain
chain = (
    {"context": retriever | guard, "question": lambda x: x}
    | prompt
    | llm
    | StrOutputParser()
)

response = chain.invoke("What is CVE-2024-1234?")
```

## How it works

`RAGuardTransformer` implements LangChain's `BaseDocumentTransformer`:

1. Receives documents from the retriever
2. Converts them to RAGuard's format
3. Runs all detection engines
4. Returns only safe documents to the next chain step
5. Flagged documents are silently removed
