# LlamaIndex Integration

Add RAGuard to any LlamaIndex query engine as a node postprocessor.

## Install

```bash
pip install raguard[llamaindex]
```

## Basic usage

```python
from raguard.integrations.llamaindex import RAGuardPostProcessor

query_engine = index.as_query_engine(
    node_postprocessors=[RAGuardPostProcessor()]
)

response = query_engine.query("What is CVE-2024-1234?")
```

## With API key (hosted mode)

```python
query_engine = index.as_query_engine(
    node_postprocessors=[RAGuardPostProcessor(api_key="rg_live_xxxxx")]
)
```

## Custom configuration

```python
guard = RAGuardPostProcessor(
    risk_threshold=0.6,
    detectors=["consensus_clustering", "source_reputation"],
)

query_engine = index.as_query_engine(
    node_postprocessors=[guard]
)
```

## Full example

```python
from llama_index.core import VectorStoreIndex, SimpleDirectoryReader
from raguard.integrations.llamaindex import RAGuardPostProcessor

# Load and index documents
documents = SimpleDirectoryReader("./data").load_data()
index = VectorStoreIndex.from_documents(documents)

# Create query engine with RAGuard protection
query_engine = index.as_query_engine(
    similarity_top_k=10,
    node_postprocessors=[RAGuardPostProcessor()]
)

# Poisoned documents are filtered before response synthesis
response = query_engine.query("Is DarkNebula malware safe?")
print(response)
```

## How it works

`RAGuardPostProcessor` implements LlamaIndex's `BaseNodePostprocessor`:

1. Receives retrieved nodes after similarity search
2. Converts nodes to RAGuard documents (preserving metadata)
3. Runs all detection engines with the query context
4. Returns only safe nodes to the response synthesizer
5. Flagged nodes are removed from the result set
