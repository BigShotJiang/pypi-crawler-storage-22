"""HTTP client for the RAGuard hosted API."""

from __future__ import annotations

import httpx

from raguard.models import Document, ScanRequest, ScanResult

DEFAULT_API_URL = "https://api.raguard.deepseal.ai"


class RAGuardAPIClient:
    """Client for the RAGuard hosted API."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_API_URL,
        timeout: float = 30.0,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "raguard-python/0.0.0",
            },
            timeout=timeout,
        )

    def scan(
        self,
        documents: list[Document],
        query: str | None = None,
        detectors: list[str] | None = None,
        config: dict | None = None,
    ) -> ScanResult:
        """Send a scan request to the hosted API."""
        request = ScanRequest(
            documents=documents,
            query=query,
            detectors=detectors,
            config=config,
        )
        response = self._client.post(
            "/v1/scan",
            content=request.model_dump_json(),
        )
        response.raise_for_status()
        return ScanResult.model_validate(response.json())

    def usage(self) -> dict:
        """Get current usage stats."""
        response = self._client.get("/v1/usage")
        response.raise_for_status()
        return response.json()

    def health(self) -> bool:
        """Check API health."""
        try:
            response = self._client.get("/health")
            return response.status_code == 200
        except httpx.HTTPError:
            return False

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> RAGuardAPIClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
