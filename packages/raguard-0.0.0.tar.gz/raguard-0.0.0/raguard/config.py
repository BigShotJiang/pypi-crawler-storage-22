"""Configuration and thresholds for RAGuard."""

from __future__ import annotations

from pydantic import BaseModel, Field


class ConsensusConfig(BaseModel):
    similarity_threshold: float = Field(default=0.75, ge=0.0, le=1.0)
    min_cluster_size: int = Field(default=2, ge=2)
    weight_similarity: float = 0.4
    weight_source_diversity: float = 0.3
    weight_temporal: float = 0.2
    weight_lexical: float = 0.1


class AnomalyConfig(BaseModel):
    contamination: float = Field(default=0.1, ge=0.01, le=0.5)
    min_relevance_score: float = Field(default=0.3, ge=0.0, le=1.0)


class ReputationConfig(BaseModel):
    unknown_domain_score: float = Field(default=0.4, ge=0.0, le=1.0)
    metadata_weight: float = Field(default=0.2, ge=0.0, le=1.0)
    content_quality_weight: float = Field(default=0.15, ge=0.0, le=1.0)


class RAGuardConfig(BaseModel):
    """Master configuration for RAGuard."""

    risk_threshold: float = Field(default=0.7, ge=0.0, le=1.0)
    warning_threshold: float = Field(default=0.4, ge=0.0, le=1.0)
    embedding_model: str = "all-MiniLM-L6-v2"
    enabled_detectors: list[str] = Field(
        default_factory=lambda: ["consensus_clustering", "semantic_anomaly", "source_reputation"]
    )

    consensus: ConsensusConfig = Field(default_factory=ConsensusConfig)
    anomaly: AnomalyConfig = Field(default_factory=AnomalyConfig)
    reputation: ReputationConfig = Field(default_factory=ReputationConfig)


DEFAULT_CONFIG = RAGuardConfig()
