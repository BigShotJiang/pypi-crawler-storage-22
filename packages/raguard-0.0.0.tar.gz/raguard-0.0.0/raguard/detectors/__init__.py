"""Detection engines for identifying adversarial documents in RAG pipelines."""

from raguard.detectors.anomaly import SemanticAnomalyDetector
from raguard.detectors.base import BaseDetector
from raguard.detectors.consensus import ConsensusClusteringDetector
from raguard.detectors.reputation import SourceReputationDetector

DETECTOR_REGISTRY: dict[str, type[BaseDetector]] = {
    "consensus_clustering": ConsensusClusteringDetector,
    "semantic_anomaly": SemanticAnomalyDetector,
    "source_reputation": SourceReputationDetector,
}

__all__ = [
    "BaseDetector",
    "ConsensusClusteringDetector",
    "SemanticAnomalyDetector",
    "SourceReputationDetector",
    "DETECTOR_REGISTRY",
]
