"""Semantic Anomaly Detector — detects documents that deviate from baselines or contradict each other.

Catches poisoned documents by identifying:
1. Statistical outliers in embedding space (isolation forest)
2. Documents with low query relevance but high inter-similarity (coordinated off-topic injection)
3. Contradiction signals between documents
"""

from __future__ import annotations

import re

import numpy as np
from sklearn.ensemble import IsolationForest

from raguard.detectors.base import BaseDetector
from raguard.models import DetectorResult, Document
from raguard.utils.embeddings import cosine_similarity_matrix, encode_texts

# Patterns that indicate contradictions
NEGATION_PATTERNS = [
    r"\bhowever\b", r"\bbut\b", r"\bon the contrary\b",
    r"\bactually\b.*\bnot\b", r"\bfalse\b", r"\bincorrect\b",
    r"\bcontradicts?\b", r"\bdespite\b.*\bclaims?\b",
    r"\bis not\b", r"\bare not\b", r"\bwas not\b",
    r"\bnever\b", r"\bno evidence\b",
]


class SemanticAnomalyDetector(BaseDetector):
    """Detects documents whose semantic content is anomalous compared to
    the majority or a known-good baseline."""

    name = "semantic_anomaly"

    def __init__(
        self,
        contamination: float = 0.1,
        min_relevance_score: float = 0.3,
        embedding_model: str = "all-MiniLM-L6-v2",
    ):
        self.contamination = contamination
        self.min_relevance_score = min_relevance_score
        self.embedding_model = embedding_model

    def detect(
        self,
        documents: list[Document],
        query: str | None = None,
        embeddings: np.ndarray | None = None,
        query_embedding: np.ndarray | None = None,
        **kwargs: object,
    ) -> DetectorResult:
        if len(documents) < 3:
            return DetectorResult(
                detector_name=self.name,
                risk_score=0.0,
                details={"reason": "too_few_documents_for_anomaly_detection"},
            )

        # 1. Embed documents
        if embeddings is None:
            embeddings = encode_texts(
                [d.content for d in documents], self.embedding_model
            )

        # 2. Isolation forest outlier detection
        outlier_scores = self._isolation_forest_scores(embeddings)

        # 3. Query relevance check
        relevance_scores = None
        low_relevance_flags: list[int] = []
        if query is not None:
            if query_embedding is None:
                query_embedding = encode_texts([query], self.embedding_model)
            relevance_scores = np.dot(embeddings, query_embedding.T).flatten()
            low_relevance_flags = [
                i
                for i, score in enumerate(relevance_scores)
                if score < self.min_relevance_score
            ]

        # 4. Contradiction detection
        contradiction_scores = self._detect_contradictions(documents)

        # 5. Coordinated injection check: low relevance + high inter-similarity
        coordinated_flags = self._check_coordinated_injection(
            embeddings, relevance_scores
        )

        # Combine signals
        flagged: set[int] = set()
        doc_risks = np.zeros(len(documents))

        # Outlier contribution
        for i, score in enumerate(outlier_scores):
            if score < 0:  # Isolation forest: negative = outlier
                anomaly_strength = abs(score)
                doc_risks[i] += anomaly_strength * 0.4
                if anomaly_strength > 0.3:
                    flagged.add(i)

        # Contradiction contribution
        for i, score in enumerate(contradiction_scores):
            doc_risks[i] += score * 0.3

        # Low relevance contribution
        for i in low_relevance_flags:
            doc_risks[i] += 0.15
            flagged.add(i)

        # Coordinated injection
        for i in coordinated_flags:
            doc_risks[i] += 0.25
            flagged.add(i)

        # Normalize
        doc_risks = np.clip(doc_risks, 0, 1)
        overall_risk = float(np.max(doc_risks)) if len(doc_risks) > 0 else 0.0

        return DetectorResult(
            detector_name=self.name,
            risk_score=min(overall_risk, 1.0),
            flagged_indices=sorted(flagged),
            details={
                "outlier_scores": [round(float(s), 4) for s in outlier_scores],
                "contradiction_scores": [round(float(s), 4) for s in contradiction_scores],
                "relevance_scores": (
                    [round(float(s), 4) for s in relevance_scores]
                    if relevance_scores is not None
                    else None
                ),
                "coordinated_injection_indices": coordinated_flags,
                "per_document_risk": [round(float(r), 4) for r in doc_risks],
            },
        )

    def _isolation_forest_scores(self, embeddings: np.ndarray) -> np.ndarray:
        """Run isolation forest and return decision scores."""
        n_samples = len(embeddings)
        contamination = min(self.contamination, (n_samples - 1) / n_samples)
        clf = IsolationForest(
            contamination=contamination,
            random_state=42,
            n_estimators=100,
        )
        clf.fit(embeddings)
        return clf.decision_function(embeddings)

    @staticmethod
    def _detect_contradictions(documents: list[Document]) -> list[float]:
        """Heuristic contradiction detection based on negation patterns."""
        scores = []
        for doc in documents:
            text = doc.content.lower()
            contradiction_count = sum(
                1 for pattern in NEGATION_PATTERNS if re.search(pattern, text)
            )
            word_count = max(len(text.split()), 1)
            # Normalize by document length
            density = contradiction_count / (word_count / 100)
            scores.append(min(density * 0.2, 1.0))
        return scores

    @staticmethod
    def _check_coordinated_injection(
        embeddings: np.ndarray,
        relevance_scores: np.ndarray | None,
    ) -> list[int]:
        """Find docs with low query relevance but high similarity to each other."""
        if relevance_scores is None:
            return []

        low_relevance = [i for i, s in enumerate(relevance_scores) if s < 0.4]
        if len(low_relevance) < 2:
            return []

        # Check if low-relevance docs are suspiciously similar to each other
        sub_embeddings = embeddings[low_relevance]
        sim_matrix = cosine_similarity_matrix(sub_embeddings)
        np.fill_diagonal(sim_matrix, 0)

        flagged = []
        for i, idx in enumerate(low_relevance):
            max_sim = float(np.max(sim_matrix[i]))
            if max_sim > 0.8:
                flagged.append(idx)

        return flagged
