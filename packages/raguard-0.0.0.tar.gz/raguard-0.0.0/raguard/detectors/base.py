"""Abstract base class for all RAGuard detectors."""

from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np

from raguard.models import DetectorResult, Document


class BaseDetector(ABC):
    """Base class for document threat detectors."""

    name: str = "base"

    @abstractmethod
    def detect(
        self,
        documents: list[Document],
        query: str | None = None,
        embeddings: np.ndarray | None = None,
        query_embedding: np.ndarray | None = None,
        **kwargs: object,
    ) -> DetectorResult:
        """Run detection on a list of documents.

        Args:
            documents: Retrieved documents to scan.
            query: Original query text (optional).
            embeddings: Pre-computed document embeddings (optional, avoids re-encoding).
            query_embedding: Pre-computed query embedding (optional).

        Returns:
            DetectorResult with risk_score, flagged_indices, and details.
        """
        ...
