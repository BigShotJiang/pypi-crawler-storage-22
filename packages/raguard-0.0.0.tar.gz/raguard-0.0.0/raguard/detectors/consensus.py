"""Consensus Clustering Detector — detects Hallucination Propagation Chains (HPCs).

The core differentiator of RAGuard. When attackers plant multiple fake documents that
all "agree" with each other, this detector catches them by finding suspiciously tight
clusters of semantically similar documents from diverse sources.
"""

from __future__ import annotations

from collections import Counter
from datetime import datetime

import numpy as np
from sklearn.cluster import AgglomerativeClustering

from raguard.detectors.base import BaseDetector
from raguard.models import DetectorResult, Document
from raguard.utils.embeddings import cosine_similarity_matrix, encode_texts
from raguard.utils.hashing import extract_domain, ngram_overlap


class ConsensusClusteringDetector(BaseDetector):
    """Detects Hallucination Propagation Chains by finding suspiciously similar
    document clusters among retrieved results.

    A high risk score means: documents are unnaturally similar, come from few
    unique sources, appeared around the same time, and share unusual n-grams.
    """

    name = "consensus_clustering"

    def __init__(
        self,
        similarity_threshold: float = 0.75,
        min_cluster_size: int = 2,
        embedding_model: str = "all-MiniLM-L6-v2",
        weight_similarity: float = 0.4,
        weight_source_diversity: float = 0.3,
        weight_temporal: float = 0.2,
        weight_lexical: float = 0.1,
    ):
        self.similarity_threshold = similarity_threshold
        self.min_cluster_size = min_cluster_size
        self.embedding_model = embedding_model
        self.w_sim = weight_similarity
        self.w_src = weight_source_diversity
        self.w_temp = weight_temporal
        self.w_lex = weight_lexical

    def detect(
        self,
        documents: list[Document],
        query: str | None = None,
        embeddings: np.ndarray | None = None,
        query_embedding: np.ndarray | None = None,
        **kwargs: object,
    ) -> DetectorResult:
        if len(documents) < self.min_cluster_size:
            return DetectorResult(
                detector_name=self.name,
                risk_score=0.0,
                details={"reason": "too_few_documents"},
            )

        # 1. Embed all documents
        if embeddings is None:
            embeddings = encode_texts(
                [d.content for d in documents], self.embedding_model
            )

        # 2. Compute pairwise cosine similarity
        sim_matrix = cosine_similarity_matrix(embeddings)

        # 3. Agglomerative clustering
        distance_matrix = np.clip(1 - sim_matrix, 0, 2)
        np.fill_diagonal(distance_matrix, 0)

        clustering = AgglomerativeClustering(
            n_clusters=None,
            distance_threshold=1 - self.similarity_threshold,
            metric="precomputed",
            linkage="average",
        )
        labels = clustering.fit_predict(distance_matrix)

        # 4. Identify suspicious clusters
        cluster_counts = Counter(labels)
        suspicious_clusters = {
            k: v for k, v in cluster_counts.items() if v >= self.min_cluster_size
        }

        if not suspicious_clusters:
            return DetectorResult(
                detector_name=self.name,
                risk_score=0.0,
                details={"clusters_found": 0},
            )

        # 5. Score each suspicious cluster
        cluster_scores = []
        all_flagged: list[int] = []

        for cluster_id, size in suspicious_clusters.items():
            members = [i for i, label in enumerate(labels) if label == cluster_id]
            all_flagged.extend(members)

            # Intra-cluster similarity uniformity
            sim_uniformity = self._intra_cluster_similarity(sim_matrix, members)

            # Source diversity (low diversity = more suspicious)
            source_diversity = self._source_diversity(documents, members)

            # Temporal clustering
            temporal_score = self._temporal_clustering(documents, members)

            # Lexical overlap
            lexical_score = self._lexical_overlap(documents, members)

            cluster_risk = (
                self.w_sim * sim_uniformity
                + self.w_src * (1 - source_diversity)
                + self.w_temp * temporal_score
                + self.w_lex * lexical_score
            )

            cluster_scores.append(
                {
                    "cluster_id": int(cluster_id),
                    "size": size,
                    "members": members,
                    "risk_score": round(float(cluster_risk), 4),
                    "similarity_uniformity": round(float(sim_uniformity), 4),
                    "source_diversity": round(float(source_diversity), 4),
                    "temporal_clustering": round(float(temporal_score), 4),
                    "lexical_overlap": round(float(lexical_score), 4),
                }
            )

        # Overall risk = max cluster risk (worst case)
        overall_risk = max(cs["risk_score"] for cs in cluster_scores)

        return DetectorResult(
            detector_name=self.name,
            risk_score=min(float(overall_risk), 1.0),
            flagged_indices=sorted(set(all_flagged)),
            details={
                "clusters_found": len(suspicious_clusters),
                "clusters": cluster_scores,
            },
        )

    @staticmethod
    def _intra_cluster_similarity(sim_matrix: np.ndarray, members: list[int]) -> float:
        """Average pairwise similarity within a cluster. Higher = more suspicious."""
        if len(members) < 2:
            return 0.0
        sims = []
        for i, m1 in enumerate(members):
            for m2 in members[i + 1 :]:
                sims.append(sim_matrix[m1, m2])
        return float(np.mean(sims)) if sims else 0.0

    @staticmethod
    def _source_diversity(documents: list[Document], members: list[int]) -> float:
        """Ratio of unique known sources to cluster size. Low diversity = suspicious.

        Documents without source metadata count as having the SAME unknown source,
        which correctly signals low diversity (suspicious).
        """
        sources = set()
        unknown_count = 0
        for idx in members:
            source = documents[idx].metadata.get("source", "")
            if source:
                sources.add(extract_domain(source))
            else:
                unknown_count += 1
        # All unknowns are treated as one source (low diversity)
        if unknown_count > 0:
            sources.add("__unknown__")
        return len(sources) / len(members) if members else 1.0

    @staticmethod
    def _temporal_clustering(documents: list[Document], members: list[int]) -> float:
        """Detect if documents were published within a suspiciously narrow time window."""
        dates: list[datetime] = []
        for idx in members:
            date_str = documents[idx].metadata.get("date") or documents[idx].metadata.get(
                "published_date"
            )
            if date_str:
                try:
                    if isinstance(date_str, str):
                        dates.append(datetime.fromisoformat(date_str.replace("Z", "+00:00")))
                    elif isinstance(date_str, datetime):
                        dates.append(date_str)
                except (ValueError, TypeError):
                    continue

        if len(dates) < 2:
            return 0.0

        dates.sort()
        span_days = (dates[-1] - dates[0]).total_seconds() / 86400
        # If all docs published within 7 days -> high score
        if span_days <= 1:
            return 1.0
        elif span_days <= 7:
            return 0.7
        elif span_days <= 30:
            return 0.3
        return 0.0

    @staticmethod
    def _lexical_overlap(documents: list[Document], members: list[int]) -> float:
        """Average pairwise n-gram overlap within cluster. High overlap = suspicious."""
        if len(members) < 2:
            return 0.0
        overlaps = []
        for i, m1 in enumerate(members):
            for m2 in members[i + 1 :]:
                overlap = ngram_overlap(
                    documents[m1].content, documents[m2].content
                )
                overlaps.append(overlap)
        return float(np.mean(overlaps)) if overlaps else 0.0
