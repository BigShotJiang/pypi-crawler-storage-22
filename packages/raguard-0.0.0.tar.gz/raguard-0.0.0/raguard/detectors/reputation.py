"""Source Reputation Detector — scores document trustworthiness based on provenance.

Heuristic-based for MVP. Checks:
1. Source domain against known-good/known-bad lists
2. Metadata completeness (well-sourced docs have dates, authors, titles)
3. Content quality signals (promotional language, Unicode anomalies, repetition)
"""

from __future__ import annotations

import numpy as np

from raguard.detectors.base import BaseDetector
from raguard.models import DetectorResult, Document
from raguard.utils.hashing import detect_suspicious_patterns, extract_domain

# Curated high-trust domains (expandable by users)
TRUSTED_DOMAINS: dict[str, float] = {
    # Security vendors
    "crowdstrike.com": 0.95, "mandiant.com": 0.95, "paloaltonetworks.com": 0.9,
    "fortinet.com": 0.9, "sentinelone.com": 0.9, "trendmicro.com": 0.9,
    "kaspersky.com": 0.85, "sophos.com": 0.9, "elastic.co": 0.85,
    # Government / standards
    "nist.gov": 0.95, "cisa.gov": 0.95, "nvd.nist.gov": 0.95,
    "mitre.org": 0.95, "us-cert.gov": 0.95,
    # Major tech
    "microsoft.com": 0.9, "google.com": 0.9, "aws.amazon.com": 0.9,
    "cloud.google.com": 0.9, "docs.github.com": 0.85,
    # Academic / research
    "arxiv.org": 0.85, "ieee.org": 0.9, "acm.org": 0.9,
    "usenix.org": 0.9, "springer.com": 0.85,
    # AI / ML specific
    "openai.com": 0.85, "anthropic.com": 0.85, "huggingface.co": 0.8,
    "langchain.com": 0.8, "llamaindex.ai": 0.8,
    # Known documentation
    "docs.python.org": 0.9, "stackoverflow.com": 0.75,
    "wikipedia.org": 0.7,
}

# Known-bad or low-trust patterns
LOW_TRUST_PATTERNS = [
    "blogspot.com", "wordpress.com", "medium.com", "substack.com",
    "pastebin.com", "hastebin.com",
]

EXPECTED_METADATA_FIELDS = ["source", "author", "date", "title"]


class SourceReputationDetector(BaseDetector):
    """Scores each document's source reliability. Low reputation = higher risk."""

    name = "source_reputation"

    def __init__(
        self,
        unknown_domain_score: float = 0.4,
        metadata_weight: float = 0.2,
        content_quality_weight: float = 0.15,
        custom_trusted_domains: dict[str, float] | None = None,
    ):
        self.unknown_domain_score = unknown_domain_score
        self.metadata_weight = metadata_weight
        self.content_quality_weight = content_quality_weight
        self.trusted_domains = {**TRUSTED_DOMAINS}
        if custom_trusted_domains:
            self.trusted_domains.update(custom_trusted_domains)

    def detect(
        self,
        documents: list[Document],
        query: str | None = None,
        embeddings: np.ndarray | None = None,
        query_embedding: np.ndarray | None = None,
        **kwargs: object,
    ) -> DetectorResult:
        if not documents:
            return DetectorResult(
                detector_name=self.name,
                risk_score=0.0,
                details={"reason": "no_documents"},
            )

        doc_reputations = []
        flagged: list[int] = []

        for i, doc in enumerate(documents):
            rep = self._score_document(doc)
            doc_reputations.append(rep)
            if rep["reputation_score"] < 0.4:
                flagged.append(i)

        # Overall risk = inverse of lowest reputation
        min_rep = min(r["reputation_score"] for r in doc_reputations)
        overall_risk = 1.0 - min_rep

        return DetectorResult(
            detector_name=self.name,
            risk_score=min(float(overall_risk), 1.0),
            flagged_indices=flagged,
            details={
                "per_document_reputation": doc_reputations,
            },
        )

    def _score_document(self, doc: Document) -> dict:
        """Compute a trust score for a single document."""
        # 1. Domain reputation
        domain_score = self._domain_score(doc)

        # 2. Metadata completeness
        metadata_score = self._metadata_completeness(doc)

        # 3. Content quality
        quality_score = self._content_quality(doc)

        # Weighted combination
        domain_weight = 1.0 - self.metadata_weight - self.content_quality_weight
        final_score = (
            domain_weight * domain_score
            + self.metadata_weight * metadata_score
            + self.content_quality_weight * quality_score
        )

        return {
            "reputation_score": round(float(final_score), 4),
            "domain_score": round(float(domain_score), 4),
            "metadata_score": round(float(metadata_score), 4),
            "quality_score": round(float(quality_score), 4),
            "domain": self._get_domain(doc),
        }

    def _domain_score(self, doc: Document) -> float:
        """Score based on source domain."""
        domain = self._get_domain(doc)
        if not domain:
            return self.unknown_domain_score

        # Check exact match
        if domain in self.trusted_domains:
            return self.trusted_domains[domain]

        # Check parent domain (e.g., "blog.google.com" -> "google.com")
        parts = domain.split(".")
        if len(parts) > 2:
            parent = ".".join(parts[-2:])
            if parent in self.trusted_domains:
                return self.trusted_domains[parent] * 0.9  # Slight discount for subdomain

        # Check low-trust patterns
        for pattern in LOW_TRUST_PATTERNS:
            if pattern in domain:
                return 0.3

        return self.unknown_domain_score

    @staticmethod
    def _get_domain(doc: Document) -> str:
        """Extract domain from document metadata."""
        source = doc.metadata.get("source", "") or doc.metadata.get("url", "")
        if source:
            return extract_domain(source)
        return ""

    @staticmethod
    def _metadata_completeness(doc: Document) -> float:
        """Score based on how many expected metadata fields are present."""
        present = sum(
            1 for field in EXPECTED_METADATA_FIELDS if doc.metadata.get(field)
        )
        return present / len(EXPECTED_METADATA_FIELDS)

    @staticmethod
    def _content_quality(doc: Document) -> float:
        """Score based on content quality heuristics. Higher = better quality."""
        if not doc.content.strip():
            return 0.0

        patterns = detect_suspicious_patterns(doc.content)
        # Invert suspicious scores: high suspicious = low quality
        penalty = (
            patterns.get("promotional_density", 0) * 0.4
            + patterns.get("repetition", 0) * 0.3
            + patterns.get("unicode_anomaly", 0) * 0.3
        )
        return max(1.0 - penalty, 0.0)
