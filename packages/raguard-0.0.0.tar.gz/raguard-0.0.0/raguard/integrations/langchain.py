"""LangChain integration — drop RAGuard into any LCEL chain.

Usage (1 line added to your existing chain):

    from raguard.integrations.langchain import RAGuardTransformer

    guard = RAGuardTransformer(api_key="rg_live_xxxxx")
    chain = retriever | guard | prompt | llm | output_parser

Or with local mode (no API key):

    guard = RAGuardTransformer()
    chain = retriever | guard | prompt | llm
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from raguard.models import Document as RGDocument
from raguard.sdk import RAGuard

try:
    from langchain_core.documents import BaseDocumentTransformer
    from langchain_core.documents import Document as LCDocument
except ImportError as exc:
    raise ImportError(
        "LangChain is required for this integration. "
        "Install it with: pip install raguard[langchain]"
    ) from exc


class RAGuardTransformer(BaseDocumentTransformer):
    """LangChain document transformer that filters unsafe documents via RAGuard.

    Drops into any LCEL chain as a pipe stage between retriever and prompt.
    Documents flagged as adversarial are removed before reaching the LLM.

    Args:
        api_key: RAGuard API key. If None, runs in local mode.
        risk_threshold: Override the risk threshold for filtering.
        detectors: List of detector names to enable.
        config: Additional RAGuard configuration.
    """

    def __init__(
        self,
        api_key: str | None = None,
        risk_threshold: float | None = None,
        detectors: list[str] | None = None,
        config: dict | None = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        guard_config = config or {}
        if risk_threshold is not None:
            guard_config["risk_threshold"] = risk_threshold

        self._guard = RAGuard(
            api_key=api_key,
            config=guard_config if guard_config else None,
            detectors=detectors,
        )

    def transform_documents(
        self,
        documents: Sequence[LCDocument],
        **kwargs: Any,
    ) -> Sequence[LCDocument]:
        """Filter out adversarial documents from the retrieved set."""
        if not documents:
            return documents

        # Convert LangChain docs to RAGuard docs
        rg_docs = [
            RGDocument(
                content=doc.page_content,
                metadata=doc.metadata,
            )
            for doc in documents
        ]

        # Extract query if passed through kwargs
        query = kwargs.get("query")

        # Scan
        result = self._guard.scan(rg_docs, query=query)

        # Return only safe documents
        return [
            doc for i, doc in enumerate(documents)
            if i not in result.flagged_documents
        ]

    async def atransform_documents(
        self,
        documents: Sequence[LCDocument],
        **kwargs: Any,
    ) -> Sequence[LCDocument]:
        """Async version — delegates to sync for now."""
        return self.transform_documents(documents, **kwargs)
