"""LlamaIndex integration — RAGuard as a node postprocessor.

Usage (1 line added to your existing query engine):

    from raguard.integrations.llamaindex import RAGuardPostProcessor

    query_engine = index.as_query_engine(
        node_postprocessors=[RAGuardPostProcessor(api_key="rg_live_xxxxx")]
    )

Or with local mode:

    query_engine = index.as_query_engine(
        node_postprocessors=[RAGuardPostProcessor()]
    )
"""

from __future__ import annotations

from typing import Any

from raguard.models import Document as RGDocument
from raguard.sdk import RAGuard

try:
    from llama_index.core.postprocessor.types import BaseNodePostprocessor
    from llama_index.core.schema import NodeWithScore, QueryBundle
except ImportError as exc:
    raise ImportError(
        "LlamaIndex is required for this integration. "
        "Install it with: pip install raguard[llamaindex]"
    ) from exc


class RAGuardPostProcessor(BaseNodePostprocessor):
    """LlamaIndex node postprocessor that filters adversarial nodes via RAGuard.

    Sits in the query pipeline after retrieval, removing poisoned documents
    before they reach the response synthesizer.

    Args:
        api_key: RAGuard API key. If None, runs in local mode.
        risk_threshold: Override the risk threshold for filtering.
        detectors: List of detector names to enable.
    """

    _guard: Any = None

    def __init__(
        self,
        api_key: str | None = None,
        risk_threshold: float | None = None,
        detectors: list[str] | None = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        config = {}
        if risk_threshold is not None:
            config["risk_threshold"] = risk_threshold
        self._guard = RAGuard(
            api_key=api_key,
            config=config if config else None,
            detectors=detectors,
        )

    @classmethod
    def class_name(cls) -> str:
        return "RAGuardPostProcessor"

    def _postprocess_nodes(
        self,
        nodes: list[NodeWithScore],
        query_bundle: QueryBundle | None = None,
    ) -> list[NodeWithScore]:
        """Filter out adversarial nodes."""
        if not nodes:
            return nodes

        # Convert LlamaIndex nodes to RAGuard documents
        rg_docs = [
            RGDocument(
                content=node.node.get_content(),
                metadata=node.node.metadata,
                doc_id=node.node.node_id,
            )
            for node in nodes
        ]

        query_text = query_bundle.query_str if query_bundle else None
        result = self._guard.scan(rg_docs, query=query_text)

        # Return only safe nodes
        return [
            node for i, node in enumerate(nodes)
            if i not in result.flagged_documents
        ]
