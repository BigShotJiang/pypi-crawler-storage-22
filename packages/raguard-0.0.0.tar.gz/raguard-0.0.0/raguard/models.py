"""Core data models — the shared API contract between SDK, server, and integrations."""

from __future__ import annotations

import uuid
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class Recommendation(str, Enum):
    """Action recommendation based on scan results."""

    PROCEED = "proceed"
    CITE_WITH_WARNING = "cite_with_warning"
    BLOCK = "block"


class Document(BaseModel):
    """A retrieved document to be scanned."""

    content: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    doc_id: str | None = None

    def model_post_init(self, __context: Any) -> None:
        if self.doc_id is None:
            self.doc_id = uuid.uuid4().hex[:12]


class DetectorResult(BaseModel):
    """Result from a single detector."""

    detector_name: str
    risk_score: float = Field(ge=0.0, le=1.0)
    flagged_indices: list[int] = Field(default_factory=list)
    details: dict[str, Any] = Field(default_factory=dict)


class ScanRequest(BaseModel):
    """Request payload for scanning documents."""

    documents: list[Document]
    query: str | None = None
    detectors: list[str] | None = None  # None = run all enabled
    config: dict[str, Any] | None = None
    baseline_docs: list[Document] | None = None


class ScanResult(BaseModel):
    """Complete scan result with verdicts from all detectors."""

    safe: bool
    overall_risk_score: float = Field(ge=0.0, le=1.0)
    recommendation: Recommendation
    flagged_documents: list[int] = Field(default_factory=list)
    detectors: dict[str, DetectorResult] = Field(default_factory=dict)
    scan_id: str = Field(default_factory=lambda: uuid.uuid4().hex)
    latency_ms: float = 0.0
    documents_scanned: int = 0
    prompt_addendum: str | None = None  # Cite-or-Silent enforcement prompt
