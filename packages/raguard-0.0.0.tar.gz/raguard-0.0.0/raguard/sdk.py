"""RAGuard SDK — the main entry point for scanning RAG documents.

Usage:
    # Local mode (open-source, no API key needed)
    guard = RAGuard()
    result = guard.scan(documents, query="What is CVE-2024-1234?")
    safe_docs = guard.filter(documents, query="What is CVE-2024-1234?")

    # Hosted API mode (requires API key)
    guard = RAGuard(api_key="rg_live_xxxxx")
    result = guard.scan(documents)
"""

from __future__ import annotations

import time

import numpy as np

from raguard.config import DEFAULT_CONFIG, RAGuardConfig
from raguard.detectors import DETECTOR_REGISTRY
from raguard.detectors.base import BaseDetector
from raguard.models import (
    DetectorResult,
    Document,
    Recommendation,
    ScanResult,
)


class RAGuard:
    """Main RAGuard class — scan and filter documents for adversarial threats.

    Args:
        api_key: If provided, uses the hosted RAGuard API. Otherwise runs locally.
        config: Configuration overrides for detectors and thresholds.
        detectors: List of detector names to enable. None = all enabled.
        api_url: Custom API URL (for self-hosted deployments).
    """

    def __init__(
        self,
        api_key: str | None = None,
        config: RAGuardConfig | dict | None = None,
        detectors: list[str] | None = None,
        api_url: str | None = None,
    ):
        self._api_key = api_key
        self._api_client = None

        # Parse config (always copy to avoid mutating shared defaults)
        if isinstance(config, dict):
            self._config = RAGuardConfig(**config)
        elif config is not None:
            self._config = config.model_copy(deep=True)
        else:
            self._config = DEFAULT_CONFIG.model_copy(deep=True)

        # Override enabled detectors
        if detectors is not None:
            self._config.enabled_detectors = detectors

        # Initialize mode
        if api_key:
            raise ValueError(
                "RAGuard API mode is coming soon! For now, use local mode (no API key needed):\n\n"
                "  guard = RAGuard()  # local mode\n"
                '  result = guard.scan(docs, query="...")\n\n'
                "Follow https://www.raguard.deepseal.ai for API launch updates."
            )
        else:
            self._detectors = self._init_detectors()

    def _init_detectors(self) -> list[BaseDetector]:
        """Initialize enabled detectors for local mode."""
        instances: list[BaseDetector] = []
        for name in self._config.enabled_detectors:
            if name not in DETECTOR_REGISTRY:
                raise ValueError(
                    f"Unknown detector: {name}. Available: {list(DETECTOR_REGISTRY.keys())}"
                )
            detector_cls = DETECTOR_REGISTRY[name]

            # Pass relevant config to each detector
            kwargs: dict = {"embedding_model": self._config.embedding_model}
            if name == "consensus_clustering":
                kwargs.update({
                    "similarity_threshold": self._config.consensus.similarity_threshold,
                    "min_cluster_size": self._config.consensus.min_cluster_size,
                    "weight_similarity": self._config.consensus.weight_similarity,
                    "weight_source_diversity": self._config.consensus.weight_source_diversity,
                    "weight_temporal": self._config.consensus.weight_temporal,
                    "weight_lexical": self._config.consensus.weight_lexical,
                })
            elif name == "semantic_anomaly":
                kwargs.update({
                    "contamination": self._config.anomaly.contamination,
                    "min_relevance_score": self._config.anomaly.min_relevance_score,
                })
            elif name == "source_reputation":
                kwargs = {
                    "unknown_domain_score": self._config.reputation.unknown_domain_score,
                    "metadata_weight": self._config.reputation.metadata_weight,
                    "content_quality_weight": self._config.reputation.content_quality_weight,
                }

            instances.append(detector_cls(**kwargs))
        return instances

    def scan(
        self,
        documents: list[Document | dict | str],
        query: str | None = None,
        **kwargs: object,
    ) -> ScanResult:
        """Scan documents for adversarial threats.

        Args:
            documents: List of documents (Document objects, dicts, or plain strings).
            query: Original query text for relevance checking.

        Returns:
            ScanResult with risk scores, flagged documents, and recommendation.
        """
        start = time.perf_counter()
        normalized = self._normalize_documents(documents)

        # API mode
        if self._api_client is not None:
            result = self._api_client.scan(
                documents=normalized,
                query=query,
            )
            result.latency_ms = (time.perf_counter() - start) * 1000
            return result

        # Local mode
        return self._scan_local(normalized, query, start)

    def filter(
        self,
        documents: list[Document | dict | str],
        query: str | None = None,
        **kwargs: object,
    ) -> list[Document]:
        """Convenience method: scan and return only safe documents.

        Args:
            documents: List of documents to scan.
            query: Original query text.

        Returns:
            List of documents that passed all safety checks.
        """
        normalized = self._normalize_documents(documents)
        result = self.scan(normalized, query, **kwargs)
        return [
            doc for i, doc in enumerate(normalized)
            if i not in result.flagged_documents
        ]

    def _scan_local(
        self,
        documents: list[Document],
        query: str | None,
        start_time: float,
    ) -> ScanResult:
        """Run all local detectors and aggregate results."""
        from raguard.utils.embeddings import encode_texts

        # Pre-compute embeddings once (shared across detectors)
        embeddings = encode_texts(
            [d.content for d in documents],
            self._config.embedding_model,
        )
        query_embedding: np.ndarray | None = None
        if query:
            query_embedding = encode_texts([query], self._config.embedding_model)

        # Run all detectors
        detector_results: dict[str, DetectorResult] = {}
        all_flagged: set[int] = set()

        for detector in self._detectors:
            result = detector.detect(
                documents=documents,
                query=query,
                embeddings=embeddings,
                query_embedding=query_embedding,
            )
            detector_results[detector.name] = result
            all_flagged.update(result.flagged_indices)

        # Aggregate risk score (weighted max across detectors)
        risk_scores = [r.risk_score for r in detector_results.values()]
        overall_risk = max(risk_scores) if risk_scores else 0.0

        # Determine recommendation
        if overall_risk >= self._config.risk_threshold:
            recommendation = Recommendation.BLOCK
        elif overall_risk >= self._config.warning_threshold:
            recommendation = Recommendation.CITE_WITH_WARNING
        else:
            recommendation = Recommendation.PROCEED

        latency_ms = (time.perf_counter() - start_time) * 1000

        return ScanResult(
            safe=overall_risk < self._config.warning_threshold,
            overall_risk_score=round(overall_risk, 4),
            recommendation=recommendation,
            flagged_documents=sorted(all_flagged),
            detectors=detector_results,
            latency_ms=round(latency_ms, 2),
            documents_scanned=len(documents),
        )

    @staticmethod
    def _normalize_documents(
        documents: list[Document | dict | str],
    ) -> list[Document]:
        """Normalize various input formats into Document objects."""
        normalized: list[Document] = []
        for doc in documents:
            if isinstance(doc, Document):
                normalized.append(doc)
            elif isinstance(doc, dict):
                if "content" in doc:
                    normalized.append(Document(**doc))
                elif "page_content" in doc:
                    # LangChain Document format
                    normalized.append(
                        Document(
                            content=doc["page_content"],
                            metadata=doc.get("metadata", {}),
                        )
                    )
                else:
                    raise ValueError(f"Dict must have 'content' or 'page_content' key: {doc}")
            elif isinstance(doc, str):
                normalized.append(Document(content=doc))
            else:
                raise TypeError(f"Unsupported document type: {type(doc)}")
        return normalized
