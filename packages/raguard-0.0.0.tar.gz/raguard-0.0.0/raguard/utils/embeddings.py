"""Embedding utilities — lazy-loaded sentence-transformers."""

from __future__ import annotations

import numpy as np

_model_cache: dict[str, object] = {}


def get_model(model_name: str = "all-MiniLM-L6-v2") -> object:
    """Lazy-load and cache a SentenceTransformer model."""
    if model_name not in _model_cache:
        from sentence_transformers import SentenceTransformer

        _model_cache[model_name] = SentenceTransformer(model_name)
    return _model_cache[model_name]


def encode_texts(texts: list[str], model_name: str = "all-MiniLM-L6-v2") -> np.ndarray:
    """Encode a list of texts into embeddings."""
    model = get_model(model_name)
    return model.encode(texts, normalize_embeddings=True, show_progress_bar=False)  # type: ignore[union-attr]


def cosine_similarity_matrix(embeddings: np.ndarray) -> np.ndarray:
    """Compute pairwise cosine similarity matrix. Assumes normalized embeddings."""
    return np.dot(embeddings, embeddings.T)


def cosine_similarity_vectors(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Compute cosine similarity between each vector in a against each in b."""
    a_norm = a / (np.linalg.norm(a, axis=1, keepdims=True) + 1e-10)
    b_norm = b / (np.linalg.norm(b, axis=1, keepdims=True) + 1e-10)
    return np.dot(a_norm, b_norm.T)
