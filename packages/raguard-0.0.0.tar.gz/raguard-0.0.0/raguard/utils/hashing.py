"""Content fingerprinting utilities."""

from __future__ import annotations

import hashlib
import re
from collections import Counter


def content_hash(text: str) -> str:
    """SHA-256 hash of normalized text content."""
    normalized = re.sub(r"\s+", " ", text.strip().lower())
    return hashlib.sha256(normalized.encode()).hexdigest()[:16]


def extract_ngrams(text: str, n: int = 3) -> list[str]:
    """Extract character n-grams from text."""
    text = re.sub(r"\s+", " ", text.strip().lower())
    words = text.split()
    if len(words) < n:
        return [" ".join(words)]
    return [" ".join(words[i : i + n]) for i in range(len(words) - n + 1)]


def ngram_overlap(text_a: str, text_b: str, n: int = 3) -> float:
    """Compute n-gram overlap ratio between two texts."""
    ngrams_a = set(extract_ngrams(text_a, n))
    ngrams_b = set(extract_ngrams(text_b, n))
    if not ngrams_a or not ngrams_b:
        return 0.0
    intersection = ngrams_a & ngrams_b
    union = ngrams_a | ngrams_b
    return len(intersection) / len(union)


def extract_domain(url: str) -> str:
    """Extract domain from a URL string."""
    url = url.lower().strip()
    # Strip protocol
    for prefix in ("https://", "http://", "www."):
        if url.startswith(prefix):
            url = url[len(prefix) :]
    # Take just the domain
    return url.split("/")[0].split("?")[0]


def detect_suspicious_patterns(text: str) -> dict[str, float]:
    """Detect suspicious content patterns that might indicate adversarial documents."""
    scores: dict[str, float] = {}

    # Promotional language density
    promo_words = [
        "guaranteed", "amazing", "incredible", "revolutionary", "breakthrough",
        "exclusive", "limited time", "act now", "don't miss", "free",
    ]
    word_count = len(text.split())
    if word_count > 0:
        promo_count = sum(1 for w in promo_words if w in text.lower())
        scores["promotional_density"] = min(promo_count / max(word_count / 100, 1), 1.0)

    # Repetition score (unusual repetition of phrases)
    sentences = re.split(r"[.!?]+", text)
    if len(sentences) > 2:
        counter = Counter(s.strip().lower() for s in sentences if s.strip())
        max_repeat = max(counter.values()) if counter else 1
        scores["repetition"] = min((max_repeat - 1) / len(sentences), 1.0)

    # Unicode anomalies (homoglyphs, invisible chars)
    non_ascii = sum(1 for c in text if ord(c) > 127)
    scores["unicode_anomaly"] = min(non_ascii / max(len(text), 1) * 10, 1.0)

    return scores
