/**
 * RAGuard API Client — for hosted API mode.
 *
 * NOTE: API mode is coming soon. This client is included for forward compatibility.
 * Passing an API key will throw an informative error until the API is live.
 */

export class RAGuardAPIClient {
  constructor(
    _apiKey: string,
    _baseUrl: string = "https://api.raguard.deepseal.ai"
  ) {
    throw new Error(
      "RAGuard API mode is coming soon! For now, use local mode (no API key needed):\n\n" +
        '  const guard = new RAGuard();  // local mode\n' +
        '  const result = await guard.scan(docs, { query: "..." });\n\n' +
        "Follow https://www.raguard.deepseal.ai for API launch updates."
    );
  }
}
