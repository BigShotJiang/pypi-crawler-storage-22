/**
 * Configuration and thresholds for RAGuard.
 */

export interface ConsensusConfig {
  similarityThreshold: number;
  minClusterSize: number;
  weightSimilarity: number;
  weightSourceDiversity: number;
  weightTemporal: number;
  weightLexical: number;
}

export interface AnomalyConfig {
  contamination: number;
  minRelevanceScore: number;
}

export interface ReputationConfig {
  unknownDomainScore: number;
  metadataWeight: number;
  contentQualityWeight: number;
}

export interface RAGuardConfig {
  riskThreshold: number;
  warningThreshold: number;
  enabledDetectors: string[];
  consensus: ConsensusConfig;
  anomaly: AnomalyConfig;
  reputation: ReputationConfig;
}

export const DEFAULT_CONFIG: RAGuardConfig = {
  riskThreshold: 0.7,
  warningThreshold: 0.4,
  enabledDetectors: [
    "consensus_clustering",
    "semantic_anomaly",
    "source_reputation",
  ],
  consensus: {
    similarityThreshold: 0.75,
    minClusterSize: 2,
    weightSimilarity: 0.4,
    weightSourceDiversity: 0.3,
    weightTemporal: 0.2,
    weightLexical: 0.1,
  },
  anomaly: {
    contamination: 0.1,
    minRelevanceScore: 0.3,
  },
  reputation: {
    unknownDomainScore: 0.4,
    metadataWeight: 0.2,
    contentQualityWeight: 0.15,
  },
};

export function mergeConfig(
  overrides: Partial<RAGuardConfig> | undefined
): RAGuardConfig {
  if (!overrides) return { ...DEFAULT_CONFIG };

  return {
    riskThreshold: overrides.riskThreshold ?? DEFAULT_CONFIG.riskThreshold,
    warningThreshold:
      overrides.warningThreshold ?? DEFAULT_CONFIG.warningThreshold,
    enabledDetectors:
      overrides.enabledDetectors ?? [...DEFAULT_CONFIG.enabledDetectors],
    consensus: { ...DEFAULT_CONFIG.consensus, ...overrides.consensus },
    anomaly: { ...DEFAULT_CONFIG.anomaly, ...overrides.anomaly },
    reputation: { ...DEFAULT_CONFIG.reputation, ...overrides.reputation },
  };
}
