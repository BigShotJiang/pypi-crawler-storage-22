/**
 * Semantic Anomaly Detector — detects documents that deviate from baselines.
 *
 * Catches poisoned documents by identifying:
 * 1. Statistical outliers via distance-based anomaly detection
 * 2. Documents with low query relevance but high inter-similarity (coordinated injection)
 * 3. Contradiction signals between documents
 */

import type { DetectorResult, Document } from "../models";
import type { AnomalyConfig } from "../config";
import {
  cosineSimilarity,
  cosineSimilarityMatrix,
  mean,
  std,
  clamp,
} from "../utils/math";
import { encodeTexts } from "../utils/embeddings";
import { BaseDetector, type DetectOptions } from "./base";

/** Patterns that indicate contradictions. */
const NEGATION_PATTERNS = [
  /\bhowever\b/i,
  /\bbut\b/i,
  /\bon the contrary\b/i,
  /\bactually\b.*\bnot\b/i,
  /\bfalse\b/i,
  /\bincorrect\b/i,
  /\bcontradicts?\b/i,
  /\bdespite\b.*\bclaims?\b/i,
  /\bis not\b/i,
  /\bare not\b/i,
  /\bwas not\b/i,
  /\bnever\b/i,
  /\bno evidence\b/i,
];

/**
 * Distance-based outlier detection.
 *
 * For each point, computes its average distance to all other points.
 * Points that are much further from others (z-score based) are flagged as outliers.
 * Returns scores where negative = outlier, positive = inlier (matching sklearn convention).
 */
function distanceBasedOutlierScores(
  embeddings: number[][],
  contamination: number
): number[] {
  const n = embeddings.length;
  const simMatrix = cosineSimilarityMatrix(embeddings);

  // Average distance from each point to all others
  const avgDistances: number[] = [];
  for (let i = 0; i < n; i++) {
    let totalDist = 0;
    for (let j = 0; j < n; j++) {
      if (i !== j) totalDist += 1 - simMatrix[i][j];
    }
    avgDistances.push(totalDist / (n - 1));
  }

  const m = mean(avgDistances);
  const s = std(avgDistances);

  if (s === 0) {
    return new Array(n).fill(0.1);
  }

  // Z-score based: higher distance = more anomalous = more negative score
  const scores = avgDistances.map((d) => -(d - m) / s);

  // Adjust so that approximately `contamination` fraction is negative
  const sorted = [...scores].sort((a, b) => a - b);
  const cutoffIdx = Math.max(0, Math.floor(n * contamination) - 1);
  const cutoff = sorted[cutoffIdx];

  return scores.map((s) => s - cutoff);
}

export class SemanticAnomalyDetector extends BaseDetector {
  readonly name = "semantic_anomaly";

  private contamination: number;
  private minRelevanceScore: number;

  constructor(config: AnomalyConfig) {
    super();
    this.contamination = config.contamination;
    this.minRelevanceScore = config.minRelevanceScore;
  }

  detect(documents: Document[], options?: DetectOptions): DetectorResult {
    if (documents.length < 3) {
      return {
        detectorName: this.name,
        riskScore: 0,
        flaggedIndices: [],
        details: { reason: "too_few_documents_for_anomaly_detection" },
      };
    }

    // 1. Embed documents
    const embeddings =
      options?.embeddings ?? encodeTexts(documents.map((d) => d.content));

    // 2. Outlier detection
    const outlierScores = distanceBasedOutlierScores(
      embeddings,
      Math.min(this.contamination, (documents.length - 1) / documents.length)
    );

    // 3. Query relevance check
    let relevanceScores: number[] | null = null;
    const lowRelevanceFlags: number[] = [];

    if (options?.query) {
      const queryEmb =
        options.queryEmbedding?.[0] ??
        encodeTexts([options.query])[0];

      relevanceScores = embeddings.map((emb) => cosineSimilarity(emb, queryEmb));

      for (let i = 0; i < relevanceScores.length; i++) {
        if (relevanceScores[i] < this.minRelevanceScore) {
          lowRelevanceFlags.push(i);
        }
      }
    }

    // 4. Contradiction detection
    const contradictionScores = this.detectContradictions(documents);

    // 5. Coordinated injection check
    const coordinatedFlags = this.checkCoordinatedInjection(
      embeddings,
      relevanceScores
    );

    // Combine signals
    const flagged = new Set<number>();
    const docRisks = new Array(documents.length).fill(0);

    // Outlier contribution
    for (let i = 0; i < outlierScores.length; i++) {
      if (outlierScores[i] < 0) {
        const anomalyStrength = Math.abs(outlierScores[i]);
        docRisks[i] += anomalyStrength * 0.4;
        if (anomalyStrength > 0.3) flagged.add(i);
      }
    }

    // Contradiction contribution
    for (let i = 0; i < contradictionScores.length; i++) {
      docRisks[i] += contradictionScores[i] * 0.3;
    }

    // Low relevance contribution
    for (const i of lowRelevanceFlags) {
      docRisks[i] += 0.15;
      flagged.add(i);
    }

    // Coordinated injection
    for (const i of coordinatedFlags) {
      docRisks[i] += 0.25;
      flagged.add(i);
    }

    // Normalize
    for (let i = 0; i < docRisks.length; i++) {
      docRisks[i] = clamp(docRisks[i], 0, 1);
    }

    const overallRisk = Math.max(...docRisks);

    return {
      detectorName: this.name,
      riskScore: Math.min(overallRisk, 1.0),
      flaggedIndices: Array.from(flagged).sort((a, b) => a - b),
      details: {
        outlier_scores: outlierScores.map((s) => Math.round(s * 10000) / 10000),
        contradiction_scores: contradictionScores.map(
          (s) => Math.round(s * 10000) / 10000
        ),
        relevance_scores: relevanceScores?.map(
          (s) => Math.round(s * 10000) / 10000
        ) ?? null,
        coordinated_injection_indices: coordinatedFlags,
        per_document_risk: docRisks.map(
          (r: number) => Math.round(r * 10000) / 10000
        ),
      },
    };
  }

  private detectContradictions(documents: Document[]): number[] {
    return documents.map((doc) => {
      const text = doc.content.toLowerCase();
      const contradictionCount = NEGATION_PATTERNS.filter((p) =>
        p.test(text)
      ).length;
      const wordCount = Math.max(text.split(/\s+/).length, 1);
      const density = contradictionCount / (wordCount / 100);
      return Math.min(density * 0.2, 1.0);
    });
  }

  private checkCoordinatedInjection(
    embeddings: number[][],
    relevanceScores: number[] | null
  ): number[] {
    if (!relevanceScores) return [];

    const lowRelevance = relevanceScores
      .map((s, i) => (s < 0.4 ? i : -1))
      .filter((i) => i >= 0);

    if (lowRelevance.length < 2) return [];

    const subEmbeddings = lowRelevance.map((i) => embeddings[i]);
    const simMatrix = cosineSimilarityMatrix(subEmbeddings);

    const flagged: number[] = [];
    for (let i = 0; i < lowRelevance.length; i++) {
      let maxSim = 0;
      for (let j = 0; j < lowRelevance.length; j++) {
        if (i !== j) maxSim = Math.max(maxSim, simMatrix[i][j]);
      }
      if (maxSim > 0.8) flagged.push(lowRelevance[i]);
    }

    return flagged;
  }
}
