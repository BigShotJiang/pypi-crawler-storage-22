/**
 * Abstract base class for all RAGuard detectors.
 */

import type { DetectorResult, Document } from "../models";

export interface DetectOptions {
  query?: string;
  embeddings?: number[][];
  queryEmbedding?: number[][];
}

export abstract class BaseDetector {
  abstract readonly name: string;

  abstract detect(
    documents: Document[],
    options?: DetectOptions
  ): DetectorResult;
}
