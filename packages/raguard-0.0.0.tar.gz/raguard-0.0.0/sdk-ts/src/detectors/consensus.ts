/**
 * Consensus Clustering Detector — detects Hallucination Propagation Chains (HPCs).
 *
 * Catches attackers who plant multiple fake documents that all "agree" with each other
 * by finding suspiciously tight clusters of semantically similar documents.
 */

import type { DetectorResult, Document } from "../models";
import type { ConsensusConfig } from "../config";
import { cosineSimilarityMatrix, mean } from "../utils/math";
import { extractDomain, ngramOverlap } from "../utils/hashing";
import { encodeTexts } from "../utils/embeddings";
import { BaseDetector, type DetectOptions } from "./base";

/**
 * Simple agglomerative clustering with average linkage.
 * Returns an array of cluster labels (one per document).
 */
function agglomerativeClustering(
  distanceMatrix: number[][],
  distanceThreshold: number
): number[] {
  const n = distanceMatrix.length;

  // Each point starts as its own cluster
  const clusterOf = Array.from({ length: n }, (_, i) => i);
  const clusters = new Map<number, number[]>();
  for (let i = 0; i < n; i++) {
    clusters.set(i, [i]);
  }

  // Average linkage: merge closest clusters until threshold exceeded
  while (clusters.size > 1) {
    let minDist = Infinity;
    let mergeA = -1;
    let mergeB = -1;

    const keys = Array.from(clusters.keys());
    for (let i = 0; i < keys.length; i++) {
      for (let j = i + 1; j < keys.length; j++) {
        const membersA = clusters.get(keys[i])!;
        const membersB = clusters.get(keys[j])!;

        // Average linkage distance
        let totalDist = 0;
        let count = 0;
        for (const a of membersA) {
          for (const b of membersB) {
            totalDist += distanceMatrix[a][b];
            count++;
          }
        }
        const avgDist = totalDist / count;

        if (avgDist < minDist) {
          minDist = avgDist;
          mergeA = keys[i];
          mergeB = keys[j];
        }
      }
    }

    if (minDist > distanceThreshold || mergeA === -1) break;

    // Merge B into A
    const membersB = clusters.get(mergeB)!;
    const membersA = clusters.get(mergeA)!;
    for (const idx of membersB) {
      membersA.push(idx);
      clusterOf[idx] = mergeA;
    }
    clusters.delete(mergeB);
  }

  // Normalize labels to 0..K-1
  const labelMap = new Map<number, number>();
  let nextLabel = 0;
  const labels = new Array(n);
  for (let i = 0; i < n; i++) {
    const cluster = clusterOf[i];
    // Walk up to find the root cluster
    let root = cluster;
    while (!clusters.has(root)) {
      // Find which cluster absorbed this one
      for (const [key, members] of clusters) {
        if (members.includes(i)) {
          root = key;
          break;
        }
      }
      break;
    }
    if (!labelMap.has(root)) {
      labelMap.set(root, nextLabel++);
    }
    labels[i] = labelMap.get(root)!;
  }

  return labels;
}

export class ConsensusClusteringDetector extends BaseDetector {
  readonly name = "consensus_clustering";

  private similarityThreshold: number;
  private minClusterSize: number;
  private wSim: number;
  private wSrc: number;
  private wTemp: number;
  private wLex: number;

  constructor(config: ConsensusConfig) {
    super();
    this.similarityThreshold = config.similarityThreshold;
    this.minClusterSize = config.minClusterSize;
    this.wSim = config.weightSimilarity;
    this.wSrc = config.weightSourceDiversity;
    this.wTemp = config.weightTemporal;
    this.wLex = config.weightLexical;
  }

  detect(documents: Document[], options?: DetectOptions): DetectorResult {
    if (documents.length < this.minClusterSize) {
      return {
        detectorName: this.name,
        riskScore: 0,
        flaggedIndices: [],
        details: { reason: "too_few_documents" },
      };
    }

    // 1. Embed all documents
    const embeddings =
      options?.embeddings ?? encodeTexts(documents.map((d) => d.content));

    // 2. Compute pairwise cosine similarity
    const simMatrix = cosineSimilarityMatrix(embeddings);

    // 3. Build distance matrix
    const n = documents.length;
    const distMatrix: number[][] = Array.from({ length: n }, () =>
      new Array(n).fill(0)
    );
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        distMatrix[i][j] = i === j ? 0 : Math.max(0, Math.min(2, 1 - simMatrix[i][j]));
      }
    }

    // 4. Agglomerative clustering
    const labels = agglomerativeClustering(
      distMatrix,
      1 - this.similarityThreshold
    );

    // 5. Find suspicious clusters (size >= minClusterSize)
    const clusterCounts = new Map<number, number>();
    for (const label of labels) {
      clusterCounts.set(label, (clusterCounts.get(label) ?? 0) + 1);
    }

    const suspiciousClusters = new Map<number, number>();
    for (const [clusterId, count] of clusterCounts) {
      if (count >= this.minClusterSize) {
        suspiciousClusters.set(clusterId, count);
      }
    }

    if (suspiciousClusters.size === 0) {
      return {
        detectorName: this.name,
        riskScore: 0,
        flaggedIndices: [],
        details: { clusters_found: 0 },
      };
    }

    // 6. Score each suspicious cluster
    const clusterScores: Record<string, unknown>[] = [];
    const allFlagged: Set<number> = new Set();

    for (const [clusterId, size] of suspiciousClusters) {
      const members = labels
        .map((label, idx) => (label === clusterId ? idx : -1))
        .filter((idx) => idx >= 0);

      for (const m of members) allFlagged.add(m);

      const simUniformity = this.intraClusterSimilarity(simMatrix, members);
      const sourceDiversity = this.sourceDiversity(documents, members);
      const temporalScore = this.temporalClustering(documents, members);
      const lexicalScore = this.lexicalOverlap(documents, members);

      const clusterRisk =
        this.wSim * simUniformity +
        this.wSrc * (1 - sourceDiversity) +
        this.wTemp * temporalScore +
        this.wLex * lexicalScore;

      clusterScores.push({
        cluster_id: clusterId,
        size,
        members,
        risk_score: Math.round(clusterRisk * 10000) / 10000,
        similarity_uniformity: Math.round(simUniformity * 10000) / 10000,
        source_diversity: Math.round(sourceDiversity * 10000) / 10000,
        temporal_clustering: Math.round(temporalScore * 10000) / 10000,
        lexical_overlap: Math.round(lexicalScore * 10000) / 10000,
      });
    }

    const overallRisk = Math.max(
      ...clusterScores.map((cs) => cs.risk_score as number)
    );

    return {
      detectorName: this.name,
      riskScore: Math.min(overallRisk, 1.0),
      flaggedIndices: Array.from(allFlagged).sort((a, b) => a - b),
      details: {
        clusters_found: suspiciousClusters.size,
        clusters: clusterScores,
      },
    };
  }

  private intraClusterSimilarity(
    simMatrix: number[][],
    members: number[]
  ): number {
    if (members.length < 2) return 0;
    const sims: number[] = [];
    for (let i = 0; i < members.length; i++) {
      for (let j = i + 1; j < members.length; j++) {
        sims.push(simMatrix[members[i]][members[j]]);
      }
    }
    return sims.length > 0 ? mean(sims) : 0;
  }

  private sourceDiversity(documents: Document[], members: number[]): number {
    if (members.length === 0) return 1;
    const sources = new Set<string>();
    let unknownCount = 0;

    for (const idx of members) {
      const source = documents[idx].metadata.source as string | undefined;
      if (source) {
        const domain = extractDomain(source);
        sources.add(domain ?? "__unknown__");
      } else {
        unknownCount++;
      }
    }

    if (unknownCount > 0) sources.add("__unknown__");
    return sources.size / members.length;
  }

  private temporalClustering(documents: Document[], members: number[]): number {
    const dates: Date[] = [];

    for (const idx of members) {
      const dateStr =
        (documents[idx].metadata.date as string) ??
        (documents[idx].metadata.published_date as string);
      if (dateStr) {
        try {
          const d = new Date(dateStr);
          if (!isNaN(d.getTime())) dates.push(d);
        } catch {
          continue;
        }
      }
    }

    if (dates.length < 2) return 0;

    dates.sort((a, b) => a.getTime() - b.getTime());
    const spanDays =
      (dates[dates.length - 1].getTime() - dates[0].getTime()) / 86400000;

    if (spanDays <= 1) return 1.0;
    if (spanDays <= 7) return 0.7;
    if (spanDays <= 30) return 0.3;
    return 0;
  }

  private lexicalOverlap(documents: Document[], members: number[]): number {
    if (members.length < 2) return 0;
    const overlaps: number[] = [];
    for (let i = 0; i < members.length; i++) {
      for (let j = i + 1; j < members.length; j++) {
        overlaps.push(
          ngramOverlap(documents[members[i]].content, documents[members[j]].content)
        );
      }
    }
    return overlaps.length > 0 ? mean(overlaps) : 0;
  }
}
