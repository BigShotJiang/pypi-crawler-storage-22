/**
 * Detection engines for identifying adversarial documents in RAG pipelines.
 */

export { BaseDetector } from "./base";
export type { DetectOptions } from "./base";
export { ConsensusClusteringDetector } from "./consensus";
export { SemanticAnomalyDetector } from "./anomaly";
export { SourceReputationDetector } from "./reputation";

import type { BaseDetector } from "./base";
import type { RAGuardConfig } from "../config";
import { ConsensusClusteringDetector } from "./consensus";
import { SemanticAnomalyDetector } from "./anomaly";
import { SourceReputationDetector } from "./reputation";

type DetectorFactory = (config: RAGuardConfig) => BaseDetector;

export const DETECTOR_REGISTRY: Record<string, DetectorFactory> = {
  consensus_clustering: (config) =>
    new ConsensusClusteringDetector(config.consensus),
  semantic_anomaly: (config) =>
    new SemanticAnomalyDetector(config.anomaly),
  source_reputation: (config) =>
    new SourceReputationDetector(config.reputation),
};
