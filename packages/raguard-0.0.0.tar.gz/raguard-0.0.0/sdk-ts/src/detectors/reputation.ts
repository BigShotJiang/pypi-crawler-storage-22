/**
 * Source Reputation Detector — scores document trustworthiness based on provenance.
 *
 * Checks:
 * 1. Source domain against known-good/known-bad lists
 * 2. Metadata completeness (well-sourced docs have dates, authors, titles)
 * 3. Content quality signals (promotional language, Unicode anomalies, repetition)
 */

import type { DetectorResult, Document } from "../models";
import type { ReputationConfig } from "../config";
import { extractDomain, detectSuspiciousPatterns } from "../utils/hashing";
import { BaseDetector, type DetectOptions } from "./base";

/** Curated high-trust domains. */
const TRUSTED_DOMAINS: Record<string, number> = {
  // Security vendors
  "crowdstrike.com": 0.95, "mandiant.com": 0.95, "paloaltonetworks.com": 0.9,
  "fortinet.com": 0.9, "sentinelone.com": 0.9, "trendmicro.com": 0.9,
  "kaspersky.com": 0.85, "sophos.com": 0.9, "elastic.co": 0.85,
  // Government / standards
  "nist.gov": 0.95, "cisa.gov": 0.95, "nvd.nist.gov": 0.95,
  "mitre.org": 0.95, "us-cert.gov": 0.95,
  // Major tech
  "microsoft.com": 0.9, "google.com": 0.9, "aws.amazon.com": 0.9,
  "cloud.google.com": 0.9, "docs.github.com": 0.85,
  // Academic / research
  "arxiv.org": 0.85, "ieee.org": 0.9, "acm.org": 0.9,
  "usenix.org": 0.9, "springer.com": 0.85,
  // AI / ML specific
  "openai.com": 0.85, "anthropic.com": 0.85, "huggingface.co": 0.8,
  "langchain.com": 0.8, "llamaindex.ai": 0.8,
  // Known documentation
  "docs.python.org": 0.9, "stackoverflow.com": 0.75,
  "wikipedia.org": 0.7,
};

const LOW_TRUST_PATTERNS = [
  "blogspot.com", "wordpress.com", "medium.com", "substack.com",
  "pastebin.com", "hastebin.com",
];

const EXPECTED_METADATA_FIELDS = ["source", "author", "date", "title"];

export class SourceReputationDetector extends BaseDetector {
  readonly name = "source_reputation";

  private unknownDomainScore: number;
  private metadataWeight: number;
  private contentQualityWeight: number;
  private trustedDomains: Record<string, number>;

  constructor(
    config: ReputationConfig,
    customTrustedDomains?: Record<string, number>
  ) {
    super();
    this.unknownDomainScore = config.unknownDomainScore;
    this.metadataWeight = config.metadataWeight;
    this.contentQualityWeight = config.contentQualityWeight;
    this.trustedDomains = { ...TRUSTED_DOMAINS, ...customTrustedDomains };
  }

  detect(documents: Document[], _options?: DetectOptions): DetectorResult {
    if (documents.length === 0) {
      return {
        detectorName: this.name,
        riskScore: 0,
        flaggedIndices: [],
        details: { reason: "no_documents" },
      };
    }

    const docReputations: Record<string, unknown>[] = [];
    const flagged: number[] = [];

    for (let i = 0; i < documents.length; i++) {
      const rep = this.scoreDocument(documents[i]);
      docReputations.push(rep);
      if ((rep.reputation_score as number) < 0.4) {
        flagged.push(i);
      }
    }

    const minRep = Math.min(
      ...docReputations.map((r) => r.reputation_score as number)
    );
    const overallRisk = 1.0 - minRep;

    return {
      detectorName: this.name,
      riskScore: Math.min(overallRisk, 1.0),
      flaggedIndices: flagged,
      details: {
        per_document_reputation: docReputations,
      },
    };
  }

  private scoreDocument(doc: Document): Record<string, unknown> {
    const domainScore = this.domainScore(doc);
    const metadataScore = this.metadataCompleteness(doc);
    const qualityScore = this.contentQuality(doc);

    const domainWeight = 1.0 - this.metadataWeight - this.contentQualityWeight;
    const finalScore =
      domainWeight * domainScore +
      this.metadataWeight * metadataScore +
      this.contentQualityWeight * qualityScore;

    return {
      reputation_score: Math.round(finalScore * 10000) / 10000,
      domain_score: Math.round(domainScore * 10000) / 10000,
      metadata_score: Math.round(metadataScore * 10000) / 10000,
      quality_score: Math.round(qualityScore * 10000) / 10000,
      domain: this.getDomain(doc),
    };
  }

  private domainScore(doc: Document): number {
    const domain = this.getDomain(doc);
    if (!domain) return this.unknownDomainScore;

    // Exact match
    if (domain in this.trustedDomains) {
      return this.trustedDomains[domain];
    }

    // Parent domain (e.g., "blog.google.com" -> "google.com")
    const parts = domain.split(".");
    if (parts.length > 2) {
      const parent = parts.slice(-2).join(".");
      if (parent in this.trustedDomains) {
        return this.trustedDomains[parent] * 0.9;
      }
    }

    // Low-trust patterns
    for (const pattern of LOW_TRUST_PATTERNS) {
      if (domain.includes(pattern)) return 0.3;
    }

    return this.unknownDomainScore;
  }

  private getDomain(doc: Document): string | null {
    const source =
      (doc.metadata.source as string) ?? (doc.metadata.url as string) ?? "";
    return source ? extractDomain(source) : null;
  }

  private metadataCompleteness(doc: Document): number {
    const present = EXPECTED_METADATA_FIELDS.filter(
      (field) => doc.metadata[field]
    ).length;
    return present / EXPECTED_METADATA_FIELDS.length;
  }

  private contentQuality(doc: Document): number {
    if (!doc.content.trim()) return 0;

    const patterns = detectSuspiciousPatterns(doc.content);
    const penalty =
      (patterns.promotional ? 0.4 : 0) +
      (patterns.repetitive ? 0.3 : 0) +
      (patterns.unicodeAnomalies ? 0.3 : 0);

    return Math.max(1.0 - penalty, 0);
  }
}
