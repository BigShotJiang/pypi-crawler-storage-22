/**
 * RAGuard — Security middleware for RAG pipelines.
 */

export { RAGuard } from "./raguard";
export type { RAGuardOptions } from "./raguard";

export {
  Document,
  Recommendation,
  type DocumentInput,
  type DetectorResult,
  type ScanResult,
  type ScanOptions,
} from "./models";

export {
  type RAGuardConfig,
  type ConsensusConfig,
  type AnomalyConfig,
  type ReputationConfig,
  DEFAULT_CONFIG,
} from "./config";

export const VERSION = "0.0.0";
