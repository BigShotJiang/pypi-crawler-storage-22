/**
 * Core data models — the shared contract between SDK, server, and integrations.
 */

import { randomId } from "./utils/hashing";

export enum Recommendation {
  PROCEED = "proceed",
  CITE_WITH_WARNING = "cite_with_warning",
  BLOCK = "block",
}

export interface DocumentInput {
  content: string;
  metadata?: Record<string, unknown>;
  doc_id?: string;
}

export class Document {
  content: string;
  metadata: Record<string, unknown>;
  doc_id: string;

  constructor(input: DocumentInput | string) {
    if (typeof input === "string") {
      this.content = input;
      this.metadata = {};
      this.doc_id = randomId();
    } else {
      this.content = input.content;
      this.metadata = input.metadata ?? {};
      this.doc_id = input.doc_id ?? randomId();
    }
  }
}

export interface DetectorResult {
  detectorName: string;
  riskScore: number;
  flaggedIndices: number[];
  details: Record<string, unknown>;
}

export interface ScanResult {
  safe: boolean;
  overallRiskScore: number;
  recommendation: Recommendation;
  flaggedDocuments: number[];
  detectors: Record<string, DetectorResult>;
  scanId: string;
  latencyMs: number;
  documentsScanned: number;
}

export interface ScanOptions {
  query?: string;
}
