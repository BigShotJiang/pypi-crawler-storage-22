/**
 * RAGuard SDK — the main entry point for scanning RAG documents.
 *
 * Usage:
 *   // Local mode (open-source, no API key needed)
 *   const guard = new RAGuard();
 *   const result = await guard.scan(docs, { query: "What is CVE-2024-1234?" });
 *   const safeDocs = await guard.filter(docs, { query: "What is CVE-2024-1234?" });
 *
 *   // Hosted API mode (coming soon)
 *   const guard = new RAGuard({ apiKey: "rg_live_xxxxx" });
 */

import {
  Document,
  Recommendation,
  type DocumentInput,
  type ScanResult,
  type ScanOptions,
  type DetectorResult,
} from "./models";
import { type RAGuardConfig, mergeConfig } from "./config";
import { DETECTOR_REGISTRY, type BaseDetector } from "./detectors";
import { encodeTexts } from "./utils/embeddings";
import { randomId } from "./utils/hashing";

export interface RAGuardOptions {
  apiKey?: string;
  config?: Partial<RAGuardConfig>;
  detectors?: string[];
  apiUrl?: string;
}

export class RAGuard {
  private config: RAGuardConfig;
  private detectors: BaseDetector[];

  constructor(options?: RAGuardOptions) {
    // API mode — coming soon
    if (options?.apiKey) {
      throw new Error(
        "RAGuard API mode is coming soon! For now, use local mode (no API key needed):\n\n" +
          "  const guard = new RAGuard();  // local mode\n" +
          '  const result = await guard.scan(docs, { query: "..." });\n\n' +
          "Follow https://www.raguard.deepseal.ai for API launch updates."
      );
    }

    this.config = mergeConfig(options?.config);

    // Override enabled detectors if specified
    if (options?.detectors) {
      this.config.enabledDetectors = options.detectors;
    }

    this.detectors = this.initDetectors();
  }

  private initDetectors(): BaseDetector[] {
    const instances: BaseDetector[] = [];
    for (const name of this.config.enabledDetectors) {
      const factory = DETECTOR_REGISTRY[name];
      if (!factory) {
        throw new Error(
          `Unknown detector: ${name}. Available: ${Object.keys(DETECTOR_REGISTRY).join(", ")}`
        );
      }
      instances.push(factory(this.config));
    }
    return instances;
  }

  /**
   * Scan documents for adversarial threats.
   *
   * @param documents - Array of documents (Document objects, plain objects, or strings).
   * @param options - Scan options including the original query.
   * @returns ScanResult with risk scores, flagged documents, and recommendation.
   */
  async scan(
    documents: (Document | DocumentInput | string)[],
    options?: ScanOptions
  ): Promise<ScanResult> {
    const start = performance.now();
    const normalized = RAGuard.normalizeDocuments(documents);
    return this.scanLocal(normalized, options?.query, start);
  }

  /**
   * Convenience method: scan and return only safe documents.
   *
   * @param documents - Array of documents to scan.
   * @param options - Scan options including the original query.
   * @returns Array of documents that passed all safety checks.
   */
  async filter(
    documents: (Document | DocumentInput | string)[],
    options?: ScanOptions
  ): Promise<Document[]> {
    const normalized = RAGuard.normalizeDocuments(documents);
    const result = await this.scan(normalized, options);
    const flaggedSet = new Set(result.flaggedDocuments);
    return normalized.filter((_, i) => !flaggedSet.has(i));
  }

  private scanLocal(
    documents: Document[],
    query: string | undefined,
    startTime: number
  ): ScanResult {
    // Pre-compute embeddings once (shared across detectors)
    const embeddings = encodeTexts(documents.map((d) => d.content));
    const queryEmbedding = query ? encodeTexts([query]) : undefined;

    // Run all detectors
    const detectorResults: Record<string, DetectorResult> = {};
    const allFlagged = new Set<number>();

    for (const detector of this.detectors) {
      const result = detector.detect(documents, {
        query,
        embeddings,
        queryEmbedding,
      });
      detectorResults[detector.name] = result;
      for (const idx of result.flaggedIndices) {
        allFlagged.add(idx);
      }
    }

    // Aggregate risk score (max across detectors)
    const riskScores = Object.values(detectorResults).map((r) => r.riskScore);
    const overallRisk = riskScores.length > 0 ? Math.max(...riskScores) : 0;

    // Determine recommendation
    let recommendation: Recommendation;
    if (overallRisk >= this.config.riskThreshold) {
      recommendation = Recommendation.BLOCK;
    } else if (overallRisk >= this.config.warningThreshold) {
      recommendation = Recommendation.CITE_WITH_WARNING;
    } else {
      recommendation = Recommendation.PROCEED;
    }

    const latencyMs = performance.now() - startTime;

    return {
      safe: overallRisk < this.config.warningThreshold,
      overallRiskScore: Math.round(overallRisk * 10000) / 10000,
      recommendation,
      flaggedDocuments: Array.from(allFlagged).sort((a, b) => a - b),
      detectors: detectorResults,
      scanId: randomId() + randomId(),
      latencyMs: Math.round(latencyMs * 100) / 100,
      documentsScanned: documents.length,
    };
  }

  /**
   * Normalize various input formats into Document objects.
   */
  static normalizeDocuments(
    documents: (Document | DocumentInput | string)[]
  ): Document[] {
    return documents.map((doc) => {
      if (doc instanceof Document) return doc;
      if (typeof doc === "string") return new Document(doc);
      if (typeof doc === "object" && doc !== null) {
        if ("content" in doc) {
          return new Document(doc as DocumentInput);
        }
        if ("page_content" in doc) {
          // LangChain Document format
          return new Document({
            content: (doc as Record<string, unknown>).page_content as string,
            metadata: (doc as Record<string, unknown>).metadata as Record<string, unknown> | undefined,
          });
        }
        throw new Error(
          `Object must have 'content' or 'page_content' key: ${JSON.stringify(doc)}`
        );
      }
      throw new TypeError(`Unsupported document type: ${typeof doc}`);
    });
  }
}
