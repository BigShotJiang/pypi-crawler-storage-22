/**
 * TF-IDF based text vectorization.
 *
 * Provides lightweight document embeddings without requiring ML model downloads.
 * Uses TF-IDF (Term Frequency-Inverse Document Frequency) to create vector
 * representations of text for similarity comparison.
 */

/** Tokenize text into normalized words. */
function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 1);
}

/** Compute term frequency for a list of tokens. */
function termFrequency(tokens: string[]): Map<string, number> {
  const tf = new Map<string, number>();
  for (const token of tokens) {
    tf.set(token, (tf.get(token) ?? 0) + 1);
  }
  // Normalize by total tokens
  const total = tokens.length;
  if (total > 0) {
    for (const [key, val] of tf) {
      tf.set(key, val / total);
    }
  }
  return tf;
}

/** Build vocabulary and IDF values from a corpus. */
function buildIdf(
  tokenizedDocs: string[][]
): { vocab: string[]; idf: Map<string, number> } {
  const docFreq = new Map<string, number>();
  const n = tokenizedDocs.length;

  for (const tokens of tokenizedDocs) {
    const unique = new Set(tokens);
    for (const token of unique) {
      docFreq.set(token, (docFreq.get(token) ?? 0) + 1);
    }
  }

  const idf = new Map<string, number>();
  const vocab: string[] = [];

  for (const [term, df] of docFreq) {
    // Skip terms that appear in all docs (no discriminating power)
    // or appear only once (noise)
    if (df < n && df > 0) {
      idf.set(term, Math.log((n + 1) / (df + 1)) + 1);
      vocab.push(term);
    }
  }

  // Sort vocab for consistent ordering
  vocab.sort();

  return { vocab, idf };
}

/**
 * Encode texts into TF-IDF vectors.
 *
 * Returns normalized vectors suitable for cosine similarity computation.
 */
export function encodeTexts(texts: string[]): number[][] {
  const tokenizedDocs = texts.map(tokenize);
  const { vocab, idf } = buildIdf(tokenizedDocs);

  if (vocab.length === 0) {
    // Fallback: return zero vectors
    return texts.map(() => new Array(1).fill(0));
  }

  const vectors: number[][] = [];

  for (const tokens of tokenizedDocs) {
    const tf = termFrequency(tokens);
    const vec = new Array(vocab.length).fill(0);

    for (let i = 0; i < vocab.length; i++) {
      const term = vocab[i];
      const tfVal = tf.get(term) ?? 0;
      const idfVal = idf.get(term) ?? 0;
      vec[i] = tfVal * idfVal;
    }

    // L2 normalize
    let normVal = 0;
    for (const v of vec) normVal += v * v;
    normVal = Math.sqrt(normVal);

    if (normVal > 0) {
      for (let i = 0; i < vec.length; i++) {
        vec[i] /= normVal;
      }
    }

    vectors.push(vec);
  }

  return vectors;
}
