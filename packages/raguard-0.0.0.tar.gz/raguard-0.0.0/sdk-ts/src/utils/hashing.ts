/**
 * Content fingerprinting and text analysis utilities.
 */

import { createHash } from "crypto";

/** Generate a random 12-char hex ID. */
export function randomId(): string {
  const bytes = new Uint8Array(6);
  // Use crypto.getRandomValues in Node 18+
  if (typeof globalThis.crypto !== "undefined" && globalThis.crypto.getRandomValues) {
    globalThis.crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < bytes.length; i++) {
      bytes[i] = Math.floor(Math.random() * 256);
    }
  }
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** SHA-256 hash of normalized text. */
export function contentHash(text: string): string {
  const normalized = text.toLowerCase().replace(/\s+/g, " ").trim();
  return createHash("sha256").update(normalized).digest("hex");
}

/** Extract n-grams from text. */
export function extractNgrams(text: string, n: number = 3): Set<string> {
  const words = text.toLowerCase().replace(/[^\w\s]/g, "").split(/\s+/);
  const ngrams = new Set<string>();
  for (let i = 0; i <= words.length - n; i++) {
    ngrams.add(words.slice(i, i + n).join(" "));
  }
  return ngrams;
}

/** Jaccard similarity between two sets of n-grams. */
export function ngramOverlap(text1: string, text2: string, n: number = 3): number {
  const ngrams1 = extractNgrams(text1, n);
  const ngrams2 = extractNgrams(text2, n);
  if (ngrams1.size === 0 && ngrams2.size === 0) return 0;

  let intersection = 0;
  for (const ng of ngrams1) {
    if (ngrams2.has(ng)) intersection++;
  }

  const union = ngrams1.size + ngrams2.size - intersection;
  return union === 0 ? 0 : intersection / union;
}

/** Extract domain from URL string. */
export function extractDomain(url: string): string | null {
  try {
    const match = url.match(/https?:\/\/(?:www\.)?([^/]+)/i);
    return match ? match[1].toLowerCase() : null;
  } catch {
    return null;
  }
}

/** Suspicious content patterns. */
const PROMOTIONAL_PATTERNS = [
  /\bbest\s+ever\b/i,
  /\b100%\s+(?:safe|secure|guaranteed)\b/i,
  /\bact\s+now\b/i,
  /\blimited\s+time\b/i,
  /\bfree\s+(?:download|trial|offer)\b/i,
  /\bclick\s+here\b/i,
];

const REPETITION_THRESHOLD = 3;

export interface SuspiciousPatterns {
  promotional: boolean;
  repetitive: boolean;
  unicodeAnomalies: boolean;
  score: number;
}

/** Detect suspicious patterns in text. */
export function detectSuspiciousPatterns(text: string): SuspiciousPatterns {
  // Promotional language
  const promotional = PROMOTIONAL_PATTERNS.some((p) => p.test(text));

  // Repetition detection (same sentence repeated)
  const sentences = text.split(/[.!?]+/).filter((s) => s.trim().length > 10);
  const sentenceSet = new Set(sentences.map((s) => s.trim().toLowerCase()));
  const repetitive =
    sentences.length > 0 &&
    sentences.length - sentenceSet.size >= REPETITION_THRESHOLD;

  // Unicode anomalies (homoglyphs, RTL marks, zero-width chars)
  const unicodeAnomalies = /[\u200B-\u200F\u2028-\u202F\uFEFF]/.test(text);

  let score = 0;
  if (promotional) score += 0.3;
  if (repetitive) score += 0.4;
  if (unicodeAnomalies) score += 0.3;

  return { promotional, repetitive, unicodeAnomalies, score: Math.min(score, 1) };
}
