"""RAGuard API Server — FastAPI application entry point.

Run with:
    uvicorn server.main:app --reload --port 8000
"""

from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from server.middleware.auth import validate_api_key
from server.middleware.rate_limiter import rate_limit
from server.routers import health, scan, usage


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Pre-load ML models on startup to avoid cold-start latency."""
    from raguard.utils.embeddings import get_model

    get_model("all-MiniLM-L6-v2")
    yield


app = FastAPI(
    title="RAGuard API",
    description="Security middleware for RAG pipelines. Detects adversarial hallucination attacks.",
    version="0.0.0",
    docs_url="/docs",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Public routes
app.include_router(health.router)

# Authenticated routes
app.include_router(
    scan.router,
    prefix="/v1",
    dependencies=[Depends(validate_api_key), Depends(rate_limit)],
)
app.include_router(
    usage.router,
    prefix="/v1",
    dependencies=[Depends(validate_api_key)],
)
