"""API key authentication middleware.

Week 1: Accepts any Bearer token and passes through (for development).
Week 2: Validates against Supabase API keys table.
"""

from __future__ import annotations

from fastapi import HTTPException, Request


async def validate_api_key(request: Request) -> None:
    """Validate the API key from the Authorization header.

    For Week 1 MVP, this is permissive. Full Supabase validation
    will be added in Week 2 when the auth system is built.
    """
    # Health endpoint is always public
    if request.url.path == "/health":
        return

    auth_header = request.headers.get("Authorization")
    if not auth_header:
        raise HTTPException(
            status_code=401,
            detail="Missing Authorization header. Use: Authorization: Bearer rg_live_xxxxx",
        )

    if not auth_header.startswith("Bearer "):
        raise HTTPException(
            status_code=401,
            detail="Invalid Authorization format. Use: Bearer <api_key>",
        )

    api_key = auth_header.removeprefix("Bearer ").strip()
    if not api_key.startswith("rg_"):
        raise HTTPException(
            status_code=401,
            detail="Invalid API key format. Keys start with 'rg_'.",
        )

    # TODO (Week 2): Validate against Supabase api_keys table
    # For now, set a stub user on request state
    request.state.user = {"id": "dev-user", "tier": "free"}
