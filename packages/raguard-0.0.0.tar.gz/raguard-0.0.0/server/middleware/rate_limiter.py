"""Rate limiting middleware.

Week 1: In-memory rate limiting for development.
Week 2: Upstash Redis sliding window for production.
"""

from __future__ import annotations

import time
from collections import defaultdict

from fastapi import HTTPException, Request

# Tier limits
TIER_LIMITS: dict[str, dict[str, int]] = {
    "free": {"monthly": 1000, "per_minute": 10},
    "pro": {"monthly": 10000, "per_minute": 100},
    "enterprise": {"monthly": 100000, "per_minute": 1000},
}

# In-memory counters (replaced by Upstash Redis in Week 2)
_minute_counters: dict[str, list[float]] = defaultdict(list)


async def rate_limit(request: Request) -> None:
    """Check rate limits for the current request.

    Week 1: Simple in-memory sliding window.
    Week 2: Upstash Redis for distributed rate limiting.
    """
    if request.url.path == "/health":
        return

    user = getattr(request.state, "user", None)
    if not user:
        return

    user_id = user.get("id", "anonymous")
    tier = user.get("tier", "free")
    limits = TIER_LIMITS.get(tier, TIER_LIMITS["free"])

    # Per-minute sliding window
    now = time.time()
    window = _minute_counters[user_id]

    # Remove entries older than 60 seconds
    _minute_counters[user_id] = [t for t in window if now - t < 60]
    window = _minute_counters[user_id]

    if len(window) >= limits["per_minute"]:
        raise HTTPException(
            status_code=429,
            detail=f"Rate limit exceeded. {tier} tier allows {limits['per_minute']} requests/minute.",
        )

    _minute_counters[user_id].append(now)
