"""Scan endpoint — the core API for document scanning."""

from fastapi import APIRouter, Request

from raguard.models import ScanRequest, ScanResult
from server.services.scan_service import ScanService

router = APIRouter(tags=["scan"])

_scan_service = ScanService()


@router.post("/scan", response_model=ScanResult)
async def scan_documents(request: ScanRequest, raw_request: Request) -> ScanResult:
    """Scan retrieved documents for adversarial threats.

    Runs all enabled detectors against the provided documents and returns
    a verdict with risk scores and flagged document indices.
    """
    # Get user from middleware (attached by auth middleware)
    user = getattr(raw_request.state, "user", None)

    result = _scan_service.scan(request)

    # Log usage if user is authenticated
    if user:
        # Usage tracking will be added in Week 2 (billing_service)
        pass

    return result
