"""Usage tracking endpoint."""

from fastapi import APIRouter, Request

router = APIRouter(tags=["usage"])


@router.get("/usage")
async def get_usage(request: Request) -> dict:
    """Get current usage stats for the authenticated user.

    Full implementation in Week 2 with Supabase integration.
    """
    return {
        "tier": "free",
        "queries_used": 0,
        "queries_limit": 1000,
        "period": "monthly",
    }
