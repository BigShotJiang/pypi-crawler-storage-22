"""Scan service — orchestrates detectors for the hosted API."""

from __future__ import annotations

from raguard.models import ScanRequest, ScanResult
from raguard.sdk import RAGuard


class ScanService:
    """Server-side scan orchestration. Uses RAGuard SDK in local mode."""

    def __init__(self) -> None:
        # Initialize RAGuard in local mode for the server
        self._guard = RAGuard()

    def scan(self, request: ScanRequest) -> ScanResult:
        """Process a scan request."""
        return self._guard.scan(
            documents=request.documents,
            query=request.query,
        )
