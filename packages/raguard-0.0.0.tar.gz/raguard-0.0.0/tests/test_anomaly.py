"""Tests for the Semantic Anomaly Detector."""

import pytest

from raguard.detectors.anomaly import SemanticAnomalyDetector
from raguard.models import Document


@pytest.fixture
def detector() -> SemanticAnomalyDetector:
    return SemanticAnomalyDetector()


class TestSemanticAnomalyDetector:
    def test_clean_docs_low_risk(self, detector, clean_documents):
        """Diverse but legitimate documents should have moderate/low risk."""
        result = detector.detect(clean_documents)
        assert result.detector_name == "semantic_anomaly"
        # Clean docs are diverse, so isolation forest may flag some as outliers
        # but overall risk should be moderate
        assert result.risk_score <= 0.8

    def test_poisoned_with_query_context(self, detector, poisoned_documents):
        """Poisoned docs with irrelevant query should flag low relevance."""
        result = detector.detect(
            poisoned_documents,
            query="How do I configure Kubernetes network policies?",
        )
        assert result.details.get("relevance_scores") is not None

    def test_too_few_documents(self, detector):
        """Less than 3 docs can't run isolation forest."""
        docs = [
            Document(content="First doc"),
            Document(content="Second doc"),
        ]
        result = detector.detect(docs)
        assert result.risk_score == 0.0

    def test_contradiction_detection(self, detector):
        """Documents with heavy negation/contradiction patterns should score higher."""
        docs = [
            Document(content="The system is secure and fully patched."),
            Document(content="The system is secure and properly configured."),
            Document(
                content=(
                    "However, this is actually not true. The system is not secure. "
                    "On the contrary, there is no evidence of proper patching. "
                    "The previous claims are incorrect and false."
                )
            ),
            Document(content="Regular monitoring shows normal operations."),
        ]
        result = detector.detect(docs)
        assert result.details.get("contradiction_scores") is not None
        # The contradicting doc (index 2) should have highest contradiction score
        scores = result.details["contradiction_scores"]
        assert scores[2] > scores[0]

    def test_coordinated_injection(self, detector):
        """Low-relevance but mutually similar docs should be flagged."""
        # Off-topic cluster about cooking
        docs = [
            Document(content="SQL injection prevention requires parameterized queries."),
            Document(content="Use prepared statements to prevent SQL injection attacks."),
            Document(content="XSS can be prevented by output encoding and CSP headers."),
            Document(content="The best recipe for chocolate cake requires cocoa powder."),
            Document(content="Making chocolate cake at home needs cocoa and sugar."),
        ]
        result = detector.detect(
            docs,
            query="How to prevent SQL injection?",
        )
        flagged = set(result.flagged_indices)
        # The cooking docs (3, 4) should be flagged
        assert 3 in flagged or 4 in flagged
