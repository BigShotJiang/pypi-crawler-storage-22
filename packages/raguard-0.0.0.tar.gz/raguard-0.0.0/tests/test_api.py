"""Tests for the FastAPI server."""

import pytest
from fastapi.testclient import TestClient

from server.main import app


@pytest.fixture
def client():
    return TestClient(app)


@pytest.fixture
def auth_headers():
    return {"Authorization": "Bearer rg_test_key_12345"}


class TestHealthEndpoint:
    def test_health_check(self, client):
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert data["service"] == "raguard-api"


class TestScanEndpoint:
    def test_scan_requires_auth(self, client):
        """Requests without auth should be rejected."""
        response = client.post("/v1/scan", json={
            "documents": [{"content": "test"}],
        })
        assert response.status_code == 401

    def test_scan_invalid_key_format(self, client):
        """Keys not starting with rg_ should be rejected."""
        response = client.post(
            "/v1/scan",
            json={"documents": [{"content": "test"}]},
            headers={"Authorization": "Bearer invalid_key"},
        )
        assert response.status_code == 401

    def test_scan_basic(self, client, auth_headers):
        """Basic scan should work with valid auth."""
        response = client.post(
            "/v1/scan",
            json={
                "documents": [
                    {"content": "SQL injection is a common vulnerability."},
                    {"content": "XSS attacks exploit browser trust."},
                    {"content": "CSRF tokens prevent cross-site request forgery."},
                ],
            },
            headers=auth_headers,
        )
        assert response.status_code == 200
        data = response.json()
        assert "safe" in data
        assert "overall_risk_score" in data
        assert "recommendation" in data
        assert "detectors" in data
        assert "scan_id" in data

    def test_scan_with_query(self, client, auth_headers):
        """Scan with query parameter should work."""
        response = client.post(
            "/v1/scan",
            json={
                "documents": [
                    {"content": "Use parameterized queries to prevent SQL injection."},
                    {"content": "Input validation helps prevent injection attacks."},
                    {"content": "WAF rules can detect SQL injection attempts."},
                ],
                "query": "How to prevent SQL injection?",
            },
            headers=auth_headers,
        )
        assert response.status_code == 200

    def test_scan_empty_documents(self, client, auth_headers):
        """Empty document list should be handled."""
        response = client.post(
            "/v1/scan",
            json={"documents": []},
            headers=auth_headers,
        )
        assert response.status_code == 200


class TestUsageEndpoint:
    def test_usage_requires_auth(self, client):
        response = client.get("/v1/usage")
        assert response.status_code == 401

    def test_usage_returns_data(self, client, auth_headers):
        response = client.get("/v1/usage", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert "tier" in data
        assert "queries_used" in data
