"""Tests for the Consensus Clustering Detector."""

import pytest

from raguard.detectors.consensus import ConsensusClusteringDetector
from raguard.models import Document


@pytest.fixture
def detector() -> ConsensusClusteringDetector:
    return ConsensusClusteringDetector(
        similarity_threshold=0.75,
        min_cluster_size=2,
    )


class TestConsensusClusteringDetector:
    def test_clean_docs_low_risk(self, detector, clean_documents):
        """Clean diverse documents should have low consensus risk."""
        result = detector.detect(clean_documents)
        assert result.risk_score < 0.5
        assert result.detector_name == "consensus_clustering"

    def test_poisoned_docs_high_risk(self, detector, poisoned_documents):
        """Poisoned documents all saying the same lie should be flagged."""
        result = detector.detect(poisoned_documents)
        assert result.risk_score > 0.5
        assert len(result.flagged_indices) >= 2
        assert result.details["clusters_found"] >= 1

    def test_mixed_docs_flags_poisoned(self, detector, mixed_documents):
        """In a mixed set, the poisoned cluster should be detected."""
        result = detector.detect(mixed_documents)
        # The poisoned docs (indices 3, 4, 5) should be in flagged
        flagged = set(result.flagged_indices)
        poisoned_indices = {3, 4, 5}
        assert len(flagged & poisoned_indices) >= 2, (
            f"Expected poisoned docs flagged, got {flagged}"
        )

    def test_too_few_documents(self, detector):
        """Less than min_cluster_size docs should return zero risk."""
        result = detector.detect([Document(content="single document")])
        assert result.risk_score == 0.0
        assert result.details.get("reason") == "too_few_documents"

    def test_empty_documents(self, detector):
        """Empty list should return zero risk."""
        result = detector.detect([])
        assert result.risk_score == 0.0

    def test_identical_documents_highest_risk(self, detector):
        """Completely identical documents should produce very high risk."""
        identical = [
            Document(content="This is exactly the same content repeated verbatim.")
            for _ in range(5)
        ]
        result = detector.detect(identical)
        assert result.risk_score > 0.7

    def test_custom_thresholds(self):
        """Custom thresholds should be respected."""
        strict = ConsensusClusteringDetector(similarity_threshold=0.95)
        lenient = ConsensusClusteringDetector(similarity_threshold=0.50)

        docs = [
            Document(content="The system is vulnerable to XSS attacks."),
            Document(content="The system has XSS vulnerability issues."),
            Document(content="Kubernetes networking uses CNI plugins."),
        ]

        strict_result = strict.detect(docs)
        lenient_result = lenient.detect(docs)

        # Lenient threshold should find more clusters
        assert lenient_result.risk_score >= strict_result.risk_score
