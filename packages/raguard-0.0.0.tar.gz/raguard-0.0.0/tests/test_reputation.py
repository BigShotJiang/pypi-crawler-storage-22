"""Tests for the Source Reputation Detector."""

import pytest

from raguard.detectors.reputation import SourceReputationDetector
from raguard.models import Document


@pytest.fixture
def detector() -> SourceReputationDetector:
    return SourceReputationDetector()


class TestSourceReputationDetector:
    def test_trusted_sources_high_reputation(self, detector, clean_documents):
        """Documents from NIST, OWASP, CISA should have high reputation."""
        result = detector.detect(clean_documents)
        assert result.risk_score < 0.5
        # No docs should be flagged from trusted sources
        assert len(result.flagged_indices) == 0

    def test_unknown_sources_flagged(self, detector, poisoned_documents):
        """Documents from unknown .example.com domains should have elevated risk."""
        result = detector.detect(poisoned_documents)
        assert result.risk_score > 0.3
        # Unknown domains get low domain scores, elevating overall risk
        for rep in result.details["per_document_reputation"]:
            assert rep["domain_score"] <= 0.5

    def test_no_source_metadata(self, detector):
        """Documents without source metadata should get neutral scores."""
        docs = [
            Document(content="Some content without any metadata."),
        ]
        result = detector.detect(docs)
        details = result.details["per_document_reputation"]
        assert details[0]["domain_score"] == 0.4  # unknown default

    def test_metadata_completeness(self, detector):
        """Complete metadata should boost reputation score."""
        complete = Document(
            content="Well-documented content.",
            metadata={
                "source": "https://www.nist.gov/doc",
                "author": "NIST",
                "date": "2024-01-01",
                "title": "Official Document",
            },
        )
        incomplete = Document(
            content="Poorly documented content.",
            metadata={},
        )
        result = detector.detect([complete, incomplete])
        reps = result.details["per_document_reputation"]
        assert reps[0]["metadata_score"] > reps[1]["metadata_score"]

    def test_promotional_content_penalized(self, detector):
        """Documents with promotional language should have lower quality scores."""
        promotional = Document(
            content=(
                "This amazing guaranteed revolutionary breakthrough product is incredible! "
                "Don't miss this exclusive limited time offer! Act now for free access!"
            ),
            metadata={"source": "https://www.nist.gov/promo"},
        )
        normal = Document(
            content=(
                "This document describes the standard procedure for vulnerability "
                "assessment following the CVSS scoring methodology."
            ),
            metadata={"source": "https://www.nist.gov/cvss"},
        )
        result = detector.detect([promotional, normal])
        reps = result.details["per_document_reputation"]
        assert reps[0]["quality_score"] < reps[1]["quality_score"]

    def test_custom_trusted_domains(self):
        """Users should be able to add their own trusted domains."""
        detector = SourceReputationDetector(
            custom_trusted_domains={"internal.company.com": 0.95},
        )
        doc = Document(
            content="Internal security policy document.",
            metadata={"source": "https://internal.company.com/policy"},
        )
        result = detector.detect([doc])
        rep = result.details["per_document_reputation"][0]
        assert rep["domain_score"] == 0.95

    def test_empty_documents(self, detector):
        """Empty list should return zero risk."""
        result = detector.detect([])
        assert result.risk_score == 0.0
