"""Tests for the RAGuard SDK orchestrator."""

import pytest

from raguard import RAGuard, Recommendation, ScanResult


class TestRAGuardSDK:
    def test_basic_scan(self, clean_documents):
        """Basic scan should return a valid ScanResult."""
        guard = RAGuard()
        result = guard.scan(clean_documents)
        assert isinstance(result, ScanResult)
        assert result.documents_scanned == len(clean_documents)
        assert result.latency_ms > 0
        assert result.scan_id

    def test_scan_with_query(self, clean_documents):
        """Scan with a query should work."""
        guard = RAGuard()
        result = guard.scan(
            clean_documents,
            query="What is CVE-2024-1234?",
        )
        assert isinstance(result, ScanResult)

    def test_clean_docs_are_safe(self, clean_documents):
        """Clean documents should be marked safe."""
        guard = RAGuard()
        result = guard.scan(clean_documents)
        assert result.recommendation != Recommendation.BLOCK

    def test_poisoned_docs_detected(self, poisoned_documents):
        """Poisoned documents should be detected."""
        guard = RAGuard()
        result = guard.scan(poisoned_documents)
        assert result.overall_risk_score > 0.3
        assert len(result.flagged_documents) > 0

    def test_filter_removes_poisoned(self, mixed_documents):
        """Filter should remove flagged documents."""
        guard = RAGuard()
        safe = guard.filter(mixed_documents)
        assert len(safe) <= len(mixed_documents)

    def test_string_input_normalization(self):
        """Plain strings should be normalized to Document objects."""
        guard = RAGuard()
        result = guard.scan([
            "First document content",
            "Second document content",
            "Third document content",
        ])
        assert isinstance(result, ScanResult)
        assert result.documents_scanned == 3

    def test_dict_input_normalization(self):
        """Dicts should be normalized to Document objects."""
        guard = RAGuard()
        result = guard.scan([
            {"content": "First document", "metadata": {"source": "test.com"}},
            {"content": "Second document"},
            {"content": "Third document"},
        ])
        assert isinstance(result, ScanResult)

    def test_langchain_dict_format(self):
        """LangChain-style dicts with page_content should work."""
        guard = RAGuard()
        result = guard.scan([
            {"page_content": "First document", "metadata": {}},
            {"page_content": "Second document", "metadata": {}},
            {"page_content": "Third document", "metadata": {}},
        ])
        assert isinstance(result, ScanResult)

    def test_custom_detectors(self, clean_documents):
        """Should be able to enable only specific detectors."""
        guard = RAGuard(detectors=["source_reputation"])
        result = guard.scan(clean_documents)
        assert "source_reputation" in result.detectors
        assert "consensus_clustering" not in result.detectors

    def test_invalid_detector_raises(self):
        """Unknown detector name should raise ValueError."""
        with pytest.raises(ValueError, match="Unknown detector"):
            RAGuard(detectors=["nonexistent_detector"])

    def test_recommendation_levels(self):
        """Verify recommendation thresholds work correctly."""
        assert Recommendation.PROCEED == "proceed"
        assert Recommendation.CITE_WITH_WARNING == "cite_with_warning"
        assert Recommendation.BLOCK == "block"

    def test_all_detectors_return_results(self, clean_documents):
        """All enabled detectors should produce results."""
        guard = RAGuard()
        result = guard.scan(clean_documents)
        for name in guard._config.enabled_detectors:
            assert name in result.detectors
            assert result.detectors[name].risk_score >= 0.0
            assert result.detectors[name].risk_score <= 1.0
