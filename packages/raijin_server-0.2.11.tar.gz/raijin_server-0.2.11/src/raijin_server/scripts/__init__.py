"""Shell helpers empacotados com o raijin-server."""
