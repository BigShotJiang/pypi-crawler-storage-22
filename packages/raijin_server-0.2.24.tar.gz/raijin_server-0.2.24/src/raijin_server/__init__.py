"""Pacote principal do CLI Raijin Server."""

__version__ = "0.2.24"

__all__ = ["__version__"]