"""Pacote principal do CLI Raijin Server."""

__version__ = "0.2.26"

__all__ = ["__version__"]