"""Pacote principal do CLI Raijin Server."""

__version__ = "0.2.41"

__all__ = ["__version__"]