"""Pacote principal do CLI Raijin Server."""

__version__ = "0.3.2"

__all__ = ["__version__"]