"""CLI commands for Railway Framework."""

from railway.cli import main

__all__ = ["main"]
