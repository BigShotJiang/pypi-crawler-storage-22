"""Tests for Railway decorators."""
