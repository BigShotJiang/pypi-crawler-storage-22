from typing import *

__all__ = ["raisefunction"]

DEFAULT = object()


@overload
def raisefunction(exc: BaseException) -> None: ...
@overload
def raisefunction(exc: BaseException, cause: Optional[BaseException]) -> None: ...


def raisefunction(
    exc: BaseException,
    cause: Optional[BaseException] | object = DEFAULT,
) -> Never:
    "This function raises the given exception."
    if cause is DEFAULT:
        raise exc
    else:
        raise exc from cause
