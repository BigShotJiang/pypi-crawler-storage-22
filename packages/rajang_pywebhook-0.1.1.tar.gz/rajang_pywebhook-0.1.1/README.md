# Py Lib Template

A Python library template with modern packaging setup for PyPI publishing.

Create your own libraries in the lib folder, using the py_lib_template example, you can create your own library by changing the name of the folder and update the folder name in the pyproject.toml file. Follow the steps below for more details

## Installation

```bash
pip install py-lib-template
```

## Usage

### Microsoft Teams Webhook

Send adaptive card messages to Microsoft Teams channels via incoming webhooks.

#### Basic Usage - Single Webhook URL

```python
from py_lib_template import TeamsWebhook

# Initialize with a single webhook URL
webhook = TeamsWebhook(
    webhook_url="https://teams.webhook.office.com/webhookb2/...",
    environment="production",
    responsible_party="DevOps Team"
)

# Send a message
webhook.send(
    title="Deployment Successful",
    message={"version": "1.2.3", "deployed_at": "2024-01-15 10:30:00"},
    data_source="My Application",
    status="Success"
)
```

#### Separate Webhooks for Success and Errors

```python
from py_lib_template import TeamsWebhook

# Initialize with separate webhooks
webhook = TeamsWebhook(
    success_webhook_url="https://teams.webhook.office.com/webhookb2/success...",
    error_webhook_url="https://teams.webhook.office.com/webhookb2/alerts...",
    environment="production",
    responsible_party="DevOps Team"
)

# Success message goes to success webhook
webhook.send(
    title="Build Passed",
    message="All tests passed successfully",
    data_source="CI/CD Pipeline",
    status="Success"
)

# Error message goes to error webhook
webhook.send(
    title="Build Failed",
    message={"error": "Unit tests failed", "failed_tests": 5},
    data_source="CI/CD Pipeline",
    status="Error"
)
```

#### Convenience Methods

```python
# Send success message
webhook.send_success(
    title="Operation Complete",
    message={"records_processed": 1000},
    data_source="Data Pipeline"
)

# Send error message
webhook.send_error(
    title="Processing Failed",
    message={"error": "Database connection lost"},
    data_source="Data Pipeline"
)

# Send warning message
webhook.send_warning(
    title="Disk Space Low",
    message={"disk_usage": "85%", "free_space": "2GB"},
    data_source="Server Monitor"
)

# Send info message
webhook.send_info(
    title="Scheduled Maintenance",
    message="System will be down for maintenance at 2:00 AM",
    data_source="System Admin"
)
```

#### Custom Adaptive Card Payload

```python
# Define your own adaptive card payload
custom_payload = {
    "type": "message",
    "attachments": [
        {
            "contentType": "application/vnd.microsoft.card.adaptive",
            "content": {
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "type": "AdaptiveCard",
                "version": "1.2",
                "body": [
                    {
                        "type": "TextBlock",
                        "text": "**Custom Alert**",
                        "style": "heading"
                    },
                    {
                        "type": "TextBlock",
                        "text": "This is a custom adaptive card"
                    }
                ]
            }
        }
    ]
}

# Send with custom payload
webhook.send(
    title="Custom Alert",
    message="Message content",
    data_source="Custom App",
    status="Info",
    payload=custom_payload  # Custom payload will be used instead of default
)
```

#### Additional Custom Fields

```python
# Add custom fields to the message
webhook.send(
    title="Build Status",
    message={"build_id": "12345"},
    data_source="CI/CD Pipeline",
    status="Success",
    custom_fields={
        "Branch": "main",
        "Commit": "abc123",
        "Duration": "5m 30s"
    }
)
```

### Math Utilities

#### Basic Addition

```python
from py_lib_template import add

# Add two numbers
result = add(1, 2)
print(result)  # 3

# Works with floats too
result = add(1.5, 2.5)
print(result)  # 4.0
```

#### Adding Multiple Numbers

```python
from py_lib_template import add_many

# Add multiple numbers
result = add_many(1, 2, 3, 4, 5)
print(result.value)     # 15
print(result.operands)  # [1, 2, 3, 4, 5]
```

## Development

### Setup

```bash
# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (Unix/Mac)
source venv/bin/activate

# Install in development mode
pip install -e ".[dev]"
```

### Pre-Build

- In pyproject.toml. Update the version and name of the library that you wish to publish.

### Build

```bash
# Build the package
python build_lib.py

# Or manually
python -m build --outdir pypi_publish
```

### Test

```bash
pytest
```

### Lint & Format

```bash
# Format code
black lib tests

# Lint
ruff lib tests

# Type check
mypy lib
```

### Publish

```bash
# Build first
python build_lib.py

# Publish to PyPI (requires credentials)
cd pypi_publish
python -m twine upload *
```

## Project Structure

```
lib/
├── py_lib_template/       # Library source code
│   ├── __init__.py        # Package entry point
│   ├── math_utils.py      # Math utilities module
│   └── teams_webhook.py   # Teams webhook module
├── pypi_publish/          # Build artifacts (wheel, sdist)
├── tests/                 # Test files
├── pyproject.toml         # Package configuration
└── README.md
```

## License

MIT
