"""
Example usage of the Teams Webhook library.
"""

from lib.rajang_pywebhook import TeamsWebhook

# Example 1: Single webhook URL for all messages
webhook = TeamsWebhook(
    webhook_url="https://rajangmalaysia.webhook.office.com/webhookb2/0c58ee4d-9719-44bf-b551-09b7f2eaa286@01e3abbf-efcb-429e-98e5-49c85071b8bc/IncomingWebhook/d73e4d40522a4b42881363877f64afc0/57fb60a9-a8e3-43a8-84b6-266c89a78efb/V2Icb58rQ72cQu6n2WMdrgLcD1OwFVAYk5k56Peqwz7g81",
    environment="production",
    responsible_party="DevOps Team"
)

# Send a success message
webhook.send(
    title="Deployment Successful",
    message={"version": "1.2.3", "deployed_at": "2024-01-15 10:30:00"},
    data_source="My Application",
    status="Success"
)

# Send an error message (goes to same webhook since only one is configured)
webhook.send(
    title="Database Connection Failed",
    message={"error": "Connection timeout", "retry_count": 3},
    data_source="My Application",
    status="Error"
)


# Example 2: Separate webhooks for success and error messages
webhook_separate = TeamsWebhook(
    success_webhook_url="https://rajangmalaysia.webhook.office.com/webhookb2/0c58ee4d-9719-44bf-b551-09b7f2eaa286@01e3abbf-efcb-429e-98e5-49c85071b8bc/IncomingWebhook/d73e4d40522a4b42881363877f64afc0/57fb60a9-a8e3-43a8-84b6-266c89a78efb/V2Icb58rQ72cQu6n2WMdrgLcD1OwFVAYk5k56Peqwz7g81",
    error_webhook_url="https://rajangmalaysia.webhook.office.com/webhookb2/0c58ee4d-9719-44bf-b551-09b7f2eaa286@01e3abbf-efcb-429e-98e5-49c85071b8bc/IncomingWebhook/d73e4d40522a4b42881363877f64afc0/57fb60a9-a8e3-43a8-84b6-266c89a78efb/V2Icb58rQ72cQu6n2WMdrgLcD1OwFVAYk5k56Peqwz7g81",
    environment="staging",
    responsible_party="Backend Team"
)

# This goes to the success webhook
webhook_separate.send_success(
    title="API Response Time OK",
    message={"avg_response_time": "150ms", "requests": 1000},
    data_source="API Gateway"
)

# This goes to the error webhook
webhook_separate.send_error(
    title="High Error Rate Detected",
    message={"error_rate": "15%", "threshold": "5%"},
    data_source="API Gateway"
)


# Example 3: Using convenience methods
webhook.send_warning(
    title="Disk Space Low",
    message={"disk_usage": "85%", "free_space": "2GB"},
    data_source="Server Monitor"
)

webhook.send_info(
    title="Scheduled Maintenance",
    message="System will be down for maintenance at 2:00 AM",
    data_source="System Admin"
)


# Example 4: Custom payload
custom_payload = {
    "type": "message",
    "attachments": [
        {
            "contentType": "application/vnd.microsoft.card.adaptive",
            "content": {
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "type": "AdaptiveCard",
                "version": "1.2",
                "body": [
                    {
                        "type": "TextBlock",
                        "text": "**Custom Alert**",
                        "style": "heading"
                    },
                    {
                        "type": "TextBlock",
                        "text": "This is a custom adaptive card payload"
                    }
                ]
            }
        }
    ]
}

webhook.send(
    title="Custom Alert",
    message="This won't be used when custom payload is provided",
    data_source="Custom App",
    status="Info",
    payload=custom_payload
)


# Example 5: Custom fields
webhook.send(
    title="Build Status",
    message={"build_id": "12345"},
    data_source="CI/CD Pipeline",
    status="Success",
    custom_fields={
        "Branch": "main",
        "Commit": "abc123",
        "Duration": "5m 30s"
    }
)
