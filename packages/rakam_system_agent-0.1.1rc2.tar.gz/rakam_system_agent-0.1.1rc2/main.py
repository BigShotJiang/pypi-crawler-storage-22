def main():
    print("Hello from rakam-system-agent!")


if __name__ == "__main__":
    main()
