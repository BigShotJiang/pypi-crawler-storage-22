def main():
    print("Hello from rakam-system-vectorstore!")


if __name__ == "__main__":
    main()
