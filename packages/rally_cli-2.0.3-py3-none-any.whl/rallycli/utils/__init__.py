from rallycli.utils.timer import Timer
