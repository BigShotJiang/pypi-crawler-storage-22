"""Ralph iteration skill."""
