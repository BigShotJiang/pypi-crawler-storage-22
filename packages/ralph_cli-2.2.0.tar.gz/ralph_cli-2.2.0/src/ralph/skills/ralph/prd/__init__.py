"""Ralph PRD skill."""
