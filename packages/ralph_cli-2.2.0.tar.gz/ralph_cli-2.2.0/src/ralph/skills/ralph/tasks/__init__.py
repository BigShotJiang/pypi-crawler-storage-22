"""Ralph tasks skill."""
