"""Code simplifier skill."""
