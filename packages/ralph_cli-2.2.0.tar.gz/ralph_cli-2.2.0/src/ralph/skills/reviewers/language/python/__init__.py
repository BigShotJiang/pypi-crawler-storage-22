"""Python code reviewer skill."""
