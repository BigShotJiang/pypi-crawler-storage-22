"""Repository structure reviewer skill."""
