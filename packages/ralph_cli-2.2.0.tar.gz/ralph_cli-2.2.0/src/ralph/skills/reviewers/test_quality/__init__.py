"""Test quality reviewer skill."""
