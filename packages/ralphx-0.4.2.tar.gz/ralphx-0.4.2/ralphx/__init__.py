"""RalphX - Generic agent loop orchestration system."""

__version__ = "0.4.2"
__author__ = "Jack"

# Package metadata
__all__ = ["__version__", "__author__"]
