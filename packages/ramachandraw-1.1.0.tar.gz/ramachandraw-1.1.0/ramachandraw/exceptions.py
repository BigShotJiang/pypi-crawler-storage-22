class NoPdbIdProvided(Exception):
    pass
