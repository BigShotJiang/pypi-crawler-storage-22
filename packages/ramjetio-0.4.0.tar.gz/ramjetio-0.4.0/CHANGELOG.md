# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2025-10-22

### Added
- Initial release of RAMJET distributed cache
- Consistent hashing implementation for key distribution
- HTTP-based cache server with disk storage
- Distributed cache client with retry logic
- PyTorch integration utilities:
  - `CachedDataset` for caching dataset items
  - `CacheCheckpoint` for model checkpoint management
  - Forward hooks for activation caching
- Command-line interfaces:
  - `ramjet-server` for starting cache servers
  - `ramjet-client` for command-line cache operations
- Comprehensive test suite
- Example scripts demonstrating usage
- Documentation and README

### Features
- Scalable to N servers with M TB each
- Automatic node addition/removal with minimal redistribution
- Optional data compression
- Configurable replication factor
- TTL support for cache entries
- PyTorch tensor serialization
- Statistics and monitoring endpoints

[Unreleased]: https://github.com/ramjetinc/ramjet/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/ramjetinc/ramjet/releases/tag/v0.1.0
