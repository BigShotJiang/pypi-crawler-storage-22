"""
RAMJET - Distributed Data Cache for PyTorch Training

Accelerate distributed training by caching preprocessed data across your cluster.
Works with any DDP setup — torchrun, DeepSpeed, Accelerate, or custom launchers.

Quick Start:
    import ramjetio
    from torch.utils.data import DataLoader
    
    ramjetio.init()  # Connects to dashboard, starts cache server
    
    dataset = ramjetio.CachedDataset(your_dataset)
    loader = DataLoader(dataset, batch_size=32)

Run with:
    export RAMJET_API_KEY="your_key"
    torchrun --nproc_per_node=2 train.py

See https://docs.ramjet.io for full documentation.
"""

__version__ = "0.4.0"
__author__ = "RAMJET"
__email__ = "support@ramjet.io"

import os
import logging
import threading
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)

# Core cache functionality
from ramjetio.cache import DistributedCache
from ramjetio.consistent_hash import ConsistentHash
from ramjetio.pytorch import CachedDataset

# Universal dataset for S3/MinIO, HTTP, Local sources
from ramjetio.datasets import UniversalDataset, yolo_collate_fn

# Configuration (backend URL is hardcoded, user only needs API key)
from ramjetio.config import (
    RAMJET_BACKEND_URL,
    RAMJET_BACKEND_HOST,
    RAMJET_BACKEND_PORT,
    DEFAULT_CACHE_PORT,
    DEFAULT_CACHE_CAPACITY,
    DEFAULT_STORAGE_PATH,
    get_api_key,
    is_configured,
)

# Backend client for data source configuration
from ramjetio.backend_client import (
    BackendClient,
    get_data_source_config,
    get_cluster_nodes,
    get_backend_client,
    init_backend,
    DATA_SOURCE_TYPE_NONE,
    DATA_SOURCE_TYPE_S3,
    DATA_SOURCE_TYPE_LOCAL,
    DATA_SOURCE_TYPE_HTTP,
)


# =============================================================================
# Global State
# =============================================================================

_initialized = False
_global_cache: Optional[DistributedCache] = None
_server_process = None
_backend_client: Optional[BackendClient] = None

# Training status (updated via set_training_status())
_training_status: Dict[str, Any] = {
    'is_training': False,
    'phase': 'idle',  # 'caching', 'training', 'validating', 'idle'
    'current_epoch': 0,
    'total_epochs': 0,
    'current_step': 0,
    'total_steps': 0,
    'epoch_progress': 0.0,
    'loss': 0.0,
    'task': '',
    'started_at': 0,
    'samples_per_second': 0.0,
}
_training_lock = threading.Lock()


# =============================================================================
# DDP Utilities
# =============================================================================

def _get_distributed_info() -> tuple:
    """
    Get distributed training info from environment.
    
    Supports all major distributed training launchers:
    - torchrun / torch.distributed.launch
    - DeepSpeed
    - HuggingFace Accelerate  
    - PyTorch Lightning
    - SLURM (srun)
    - OpenMPI (mpirun)
    - Horovod
    - Manual setup
    
    Returns:
        (local_rank, global_rank, world_size, is_main_local, is_main_global)
    """
    # Try different environment variable sources in priority order
    
    # 1. Standard PyTorch distributed (torchrun, DeepSpeed, Accelerate, Lightning)
    local_rank = os.environ.get("LOCAL_RANK")
    global_rank = os.environ.get("RANK")
    world_size = os.environ.get("WORLD_SIZE")
    
    # 2. SLURM
    if local_rank is None:
        local_rank = os.environ.get("SLURM_LOCALID")
    if global_rank is None:
        global_rank = os.environ.get("SLURM_PROCID")
    if world_size is None:
        world_size = os.environ.get("SLURM_NTASKS")
    
    # 3. OpenMPI (mpirun)
    if local_rank is None:
        local_rank = os.environ.get("OMPI_COMM_WORLD_LOCAL_RANK")
    if global_rank is None:
        global_rank = os.environ.get("OMPI_COMM_WORLD_RANK")
    if world_size is None:
        world_size = os.environ.get("OMPI_COMM_WORLD_SIZE")
    
    # 4. MPICH
    if local_rank is None:
        local_rank = os.environ.get("MPI_LOCALRANKID")
    if global_rank is None:
        global_rank = os.environ.get("PMI_RANK")
    if world_size is None:
        world_size = os.environ.get("PMI_SIZE")
    
    # 5. Horovod
    if local_rank is None:
        local_rank = os.environ.get("HOROVOD_LOCAL_RANK")
    if global_rank is None:
        global_rank = os.environ.get("HOROVOD_RANK")
    if world_size is None:
        world_size = os.environ.get("HOROVOD_SIZE")
    
    # 6. AWS SageMaker
    if local_rank is None:
        local_rank = os.environ.get("SM_CURRENT_INSTANCE_LOCAL_RANK", os.environ.get("SMDATAPARALLEL_LOCAL_RANK"))
    
    # Convert to int with defaults
    local_rank = int(local_rank) if local_rank is not None else 0
    global_rank = int(global_rank) if global_rank is not None else 0
    world_size = int(world_size) if world_size is not None else 1
    
    # Check if this is the main process on this machine
    # LOCAL_RANK=0 is the main process per machine
    is_main_local = (local_rank == 0)
    
    # Global main (for logging)
    is_main_global = (global_rank == 0)
    
    return local_rank, global_rank, world_size, is_main_local, is_main_global


# =============================================================================
# Main API: ramjetio.init()
# =============================================================================

def init(
    api_key: Optional[str] = None,
    cache_path: Optional[str] = None,
    cache_size: Optional[str] = None,
    port: Optional[int] = None,
    auto_start_server: bool = True,
) -> bool:
    """
    Initialize RAMJET distributed cache.
    
    This is the recommended way to start using RAMJET. It:
    1. Connects to the RAMJET dashboard
    2. Registers this node
    3. Starts a local cache server (optional)
    4. Starts heartbeat/metrics reporting
    
    DDP-Aware Behavior:
    - When using torchrun/DDP with multiple processes per machine,
      only LOCAL_RANK=0 will start the cache server and register with backend.
    - All ranks share the same cache server on that machine.
    - This prevents port conflicts and duplicate registrations.
    
    Args:
        api_key: API key (default: from RAMJET_API_KEY env var)
        cache_path: Cache directory (default: /tmp/ramjet_cache or RAMJET_CACHE_PATH)
        cache_size: Max cache size e.g. "100GB" (default: from RAMJET_CACHE_SIZE)
        port: Cache server port (default: 9000 or RAMJET_PORT)
        auto_start_server: Start local cache server automatically
        
    Returns:
        True if initialized successfully, False otherwise
        
    Example:
        # Works seamlessly with torchrun:
        # torchrun --nproc_per_node=4 train.py
        
        import ramjetio
        ramjetio.init()  # Only LOCAL_RANK=0 starts server
        
        # All ranks can use the cache
        dataset = ramjetio.CachedDataset(your_dataset)
    """
    global _initialized, _global_cache, _server_process, _backend_client
    
    if _initialized:
        logger.warning("RAMJET already initialized")
        return True
    
    # Get DDP info
    local_rank, global_rank, world_size, is_main_local, is_main_global = _get_distributed_info()
    
    if world_size > 1:
        logger.info(f"DDP detected: rank={global_rank}/{world_size}, local_rank={local_rank}")
    
    # Read config from env vars if not provided
    api_key = api_key or get_api_key()
    cache_path = cache_path or os.environ.get("RAMJET_CACHE_PATH", DEFAULT_STORAGE_PATH)
    cache_size = cache_size or os.environ.get("RAMJET_CACHE_SIZE", DEFAULT_CACHE_CAPACITY)
    port = port or int(os.environ.get("RAMJET_PORT", DEFAULT_CACHE_PORT))
    
    if not api_key and is_main_global:
        logger.warning(
            "RAMJET_API_KEY not set. Running in local mode without dashboard connection. "
            "Get your API key from https://app.ramjet.io"
        )
    
    # Step 1: Start local cache server (only on LOCAL_RANK=0)
    # This ensures one cache server per machine, shared by all local ranks
    if auto_start_server and is_main_local:
        _server_process = _start_cache_server(
            port=port,
            cache_path=cache_path,
            cache_size=cache_size,
        )
    elif auto_start_server and not is_main_local:
        # Wait for main process to start server
        logger.debug(f"Rank {local_rank}: Waiting for LOCAL_RANK=0 to start cache server...")
        _wait_for_server(port, timeout=30)
    
    # Step 2: Connect to backend (only on LOCAL_RANK=0 to avoid duplicate registrations)
    if api_key and is_main_local:
        try:
            _backend_client = BackendClient(node_port=port, api_key=api_key)
            if _backend_client.connect():
                if is_main_global:
                    logger.info(f"✓ Connected to RAMJET dashboard")
                
                # Start heartbeat in background
                _backend_client.start_heartbeat(
                    get_metrics_fn=_get_cache_metrics,
                    auto_reconnect=True,
                )
            else:
                if is_main_global:
                    logger.warning("Could not connect to dashboard. Running in offline mode.")
        except Exception as e:
            if is_main_global:
                logger.warning(f"Backend connection failed: {e}. Running in offline mode.")
    
    # Step 3: Create global cache client (all ranks do this)
    nodes = _discover_nodes()
    if nodes:
        _global_cache = DistributedCache(nodes=nodes)
        if is_main_global:
            logger.info(f"✓ Cache ready with {len(nodes)} node(s): {nodes}")
    else:
        # Fallback to local only
        _global_cache = DistributedCache(nodes=[f"localhost:{port}"])
        if is_main_global:
            logger.info(f"✓ Cache ready (local mode on port {port})")
    
    _initialized = True
    if is_main_global:
        logger.info("✓ RAMJET initialized successfully")
    return True


def _wait_for_server(port: int, timeout: int = 30) -> bool:
    """Wait for cache server to become available."""
    import socket
    import time
    
    start = time.time()
    while time.time() - start < timeout:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            result = sock.connect_ex(('127.0.0.1', port))
            sock.close()
            if result == 0:
                return True
        except:
            pass
        time.sleep(0.5)
    
    logger.warning(f"Timeout waiting for cache server on port {port}")
    return False


def _start_cache_server(port: int, cache_path: str, cache_size: str):
    """Start local cache server in a subprocess."""
    import subprocess
    import os
    
    # Check if server is already running on this port
    try:
        import socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex(('127.0.0.1', port))
        sock.close()
        if result == 0:
            logger.info(f"Cache server already running on port {port}")
            return None
    except:
        pass
    
    # Ensure cache directory exists
    os.makedirs(cache_path, exist_ok=True)
    
    # Start server - try ramjet-server first, fallback to python -m
    logger.info(f"Starting cache server on port {port}...")
    try:
        import shutil
        import sys
        
        # Check if ramjet-server is available in PATH
        ramjet_server_path = shutil.which("ramjet-server")
        
        if ramjet_server_path:
            cmd = [
                ramjet_server_path,
                "--host", "0.0.0.0",
                "--port", str(port),
                "--storage-path", cache_path,
                "--capacity", cache_size,
            ]
        else:
            # Fallback to python -m
            cmd = [
                sys.executable, "-m", "ramjet.cli.server",
                "--host", "0.0.0.0",
                "--port", str(port),
                "--storage-path", cache_path,
                "--capacity", cache_size,
            ]
        
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        
        # Wait for server to start
        import time
        for _ in range(10):
            time.sleep(0.5)
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                result = sock.connect_ex(('127.0.0.1', port))
                sock.close()
                if result == 0:
                    logger.info(f"✓ Cache server started on port {port}")
                    return proc
            except:
                pass
        
        logger.warning(f"Cache server may not have started properly")
        return proc
        
    except FileNotFoundError:
        logger.warning("ramjetio-server command not found. Install with: pip install ramjetio")
        return None
    except Exception as e:
        logger.warning(f"Could not start cache server: {e}")
        return None


def _discover_nodes():
    """Discover cache nodes from backend or environment."""
    # Try to get from backend
    if _backend_client and _backend_client.is_connected:
        try:
            nodes = get_cluster_nodes(online_only=True)
            if nodes:
                return [f"{n['hostname']}:{n['port']}" for n in nodes]
        except Exception as e:
            logger.debug(f"Could not get nodes from backend: {e}")
    
    # Fallback to environment variable
    nodes_env = os.environ.get("RAMJET_NODES", "")
    if nodes_env:
        nodes = []
        for node in nodes_env.split(","):
            node = node.strip()
            if ":" in node:
                nodes.append(node)
            else:
                nodes.append(f"{node}:{DEFAULT_CACHE_PORT}")
        return nodes
    
    return None


def _get_cache_metrics() -> Dict[str, Any]:
    """Get current cache metrics for heartbeat."""
    metrics = {}
    
    # Cache stats
    if _global_cache:
        try:
            stats = _global_cache.stats()
            # Aggregate stats from all nodes
            total_hits = sum(s.get('hits', 0) for s in stats.values() if isinstance(s, dict))
            total_misses = sum(s.get('misses', 0) for s in stats.values() if isinstance(s, dict))
            total_size = sum(s.get('cache_size', 0) for s in stats.values() if isinstance(s, dict))
            total_items = sum(s.get('items', 0) for s in stats.values() if isinstance(s, dict))
            
            hit_ratio = total_hits / (total_hits + total_misses) if (total_hits + total_misses) > 0 else 0.0
            
            metrics.update({
                'hits': total_hits,
                'misses': total_misses,
                'cache_size_bytes': total_size,
                'cache_items': total_items,
                'hit_ratio': hit_ratio,
            })
        except:
            pass
    
    # System metrics (RAM, Disk)
    try:
        import psutil
        
        # RAM
        mem = psutil.virtual_memory()
        metrics['ram_total'] = mem.total
        metrics['ram_used'] = mem.used
        metrics['ram_free'] = mem.available
        
        # Disk (use cache path or root)
        cache_path = os.environ.get("RAMJET_CACHE_PATH", DEFAULT_STORAGE_PATH)
        try:
            disk = psutil.disk_usage(cache_path)
        except:
            disk = psutil.disk_usage("/")
        metrics['disk_total'] = disk.total
        metrics['disk_used'] = disk.used
        metrics['disk_free'] = disk.free
        
    except ImportError:
        pass
    except Exception as e:
        logger.debug(f"Failed to get system metrics: {e}")
    
    # GPU metrics
    try:
        import torch
        if torch.cuda.is_available():
            gpu_count = torch.cuda.device_count()
            metrics['gpu_count'] = gpu_count
            
            if gpu_count > 0:
                # Get info from first GPU (or aggregate)
                metrics['gpu_name'] = torch.cuda.get_device_name(0)
                
                # Memory for all GPUs
                total_mem = 0
                used_mem = 0
                for i in range(gpu_count):
                    props = torch.cuda.get_device_properties(i)
                    total_mem += props.total_memory
                    # Get current usage
                    try:
                        used_mem += torch.cuda.memory_allocated(i)
                    except:
                        pass
                
                metrics['gpu_memory_total'] = total_mem
                metrics['gpu_memory_used'] = used_mem
                metrics['gpu_memory_free'] = total_mem - used_mem
    except ImportError:
        pass
    except Exception as e:
        logger.debug(f"Failed to get GPU metrics: {e}")
    
    # Training status
    training = _get_training_status()
    metrics['is_training'] = training.get('is_training', False)
    metrics['training_phase'] = training.get('phase', 'idle')
    metrics['current_epoch'] = training.get('current_epoch', 0)
    metrics['total_epochs'] = training.get('total_epochs', 0)
    metrics['current_step'] = training.get('current_step', 0)
    metrics['total_steps'] = training.get('total_steps', 0)
    metrics['epoch_progress'] = training.get('epoch_progress', 0.0)
    metrics['training_loss'] = training.get('loss', 0.0)
    metrics['training_task'] = training.get('task', '')
    metrics['training_started_at'] = training.get('started_at', 0)
    metrics['samples_per_second'] = training.get('samples_per_second', 0.0)
    
    return metrics


def get_cache() -> Optional[DistributedCache]:
    """Get the global cache instance."""
    if not _initialized:
        logger.warning("RAMJET not initialized. Call ramjetio.init() first.")
    return _global_cache


def get_data_source() -> Optional[Dict[str, Any]]:
    """
    Get data source configuration from dashboard.
    
    Returns:
        Dict with data source config (type, endpoint, credentials, etc.)
        or None if not configured.
    """
    return get_data_source_config()


# =============================================================================
# Training Status API
# =============================================================================

def set_training_status(
    is_training: bool = True,
    phase: str = 'training',
    current_epoch: int = 0,
    total_epochs: int = 0,
    current_step: int = 0,
    total_steps: int = 0,
    loss: Optional[float] = None,
    task: str = '',
    samples_per_second: float = 0.0,
) -> None:
    """
    Update training status reported to dashboard.
    
    Call this from your training loop to show progress in the dashboard.
    
    Args:
        is_training: True if training is active
        phase: 'caching', 'training', 'validating', or 'idle'
        current_epoch: Current epoch number (1-based)
        total_epochs: Total number of epochs
        current_step: Current step within epoch
        total_steps: Total steps per epoch (0 if unknown)
        loss: Current training loss
        task: Task description (e.g., "YOLO Training")
        samples_per_second: Training throughput
        
    Example:
        # At start of training
        ramjetio.set_training_status(
            is_training=True,
            phase='training',
            task='YOLO Object Detection',
            total_epochs=100
        )
        
        # In training loop
        for epoch in range(100):
            for step, batch in enumerate(dataloader):
                loss = train_step(batch)
                ramjetio.set_training_status(
                    current_epoch=epoch + 1,
                    current_step=step + 1,
                    total_steps=len(dataloader),
                    loss=loss.item()
                )
        
        # After training
        ramjetio.set_training_status(is_training=False, phase='idle')
    """
    global _training_status
    import time
    
    with _training_lock:
        # If starting training, record start time
        if is_training and not _training_status['is_training']:
            _training_status['started_at'] = int(time.time())
        elif not is_training:
            _training_status['started_at'] = 0
        
        _training_status['is_training'] = is_training
        _training_status['phase'] = phase
        
        if current_epoch > 0:
            _training_status['current_epoch'] = current_epoch
        if total_epochs > 0:
            _training_status['total_epochs'] = total_epochs
        if current_step >= 0:
            _training_status['current_step'] = current_step
        if total_steps >= 0:
            _training_status['total_steps'] = total_steps
        if loss is not None:
            _training_status['loss'] = loss
        if task:
            _training_status['task'] = task
        if samples_per_second > 0:
            _training_status['samples_per_second'] = samples_per_second
        
        # Calculate epoch progress
        if _training_status['total_steps'] > 0:
            _training_status['epoch_progress'] = (
                _training_status['current_step'] / _training_status['total_steps']
            )
        elif _training_status['current_step'] > 0:
            _training_status['epoch_progress'] = 0.5  # Unknown, show 50%


def start_training(task: str = '', total_epochs: int = 0) -> None:
    """
    Mark training as started. Shorthand for set_training_status().
    
    Args:
        task: Task description (e.g., "ResNet Training")
        total_epochs: Total number of epochs planned
    """
    set_training_status(
        is_training=True,
        phase='training',
        task=task,
        total_epochs=total_epochs,
        current_epoch=1,
        current_step=0,
    )


def end_training() -> None:
    """Mark training as completed."""
    set_training_status(is_training=False, phase='idle')


def set_caching_phase(current: int = 0, total: int = 0) -> None:
    """
    Mark that we're in caching/data loading phase.
    
    Args:
        current: Number of samples cached so far
        total: Total samples to cache
    """
    set_training_status(
        is_training=True,
        phase='caching',
        current_step=current,
        total_steps=total,
    )


def update_step(
    epoch: int,
    step: int,
    total_steps: int = 0,
    loss: Optional[float] = None,
    samples_per_second: float = 0.0,
) -> None:
    """
    Update training progress. Call this each training step.
    
    Args:
        epoch: Current epoch (1-based)
        step: Current step in epoch (1-based)
        total_steps: Total steps per epoch
        loss: Current loss value
        samples_per_second: Training throughput
    """
    set_training_status(
        is_training=True,
        phase='training',
        current_epoch=epoch,
        current_step=step,
        total_steps=total_steps,
        loss=loss,
        samples_per_second=samples_per_second,
    )


def _get_training_status() -> Dict[str, Any]:
    """Get current training status (thread-safe)."""
    with _training_lock:
        return _training_status.copy()


def log_metrics(
    loss: Optional[float] = None,
    epoch: Optional[int] = None,
    step: Optional[int] = None,
    learning_rate: Optional[float] = None,
    throughput: Optional[float] = None,
    **kwargs
) -> None:
    """
    Log training metrics to dashboard.
    
    Args:
        loss: Training loss
        epoch: Current epoch
        step: Current step/batch
        learning_rate: Current learning rate
        throughput: Samples per second
        **kwargs: Additional metrics
    """
    # TODO: Implement metrics push to backend
    pass


def shutdown() -> None:
    """Shutdown RAMJET and cleanup resources."""
    global _initialized, _global_cache, _server_process, _backend_client
    
    if _backend_client:
        _backend_client.stop()
        _backend_client = None
    
    if _server_process:
        _server_process.terminate()
        _server_process = None
    
    _global_cache = None
    _initialized = False
    logger.info("RAMJET shutdown complete")


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Main API
    "init",
    "shutdown",
    "get_cache",
    "get_data_source",
    "log_metrics",
    # Training status
    "set_training_status",
    "start_training",
    "end_training",
    "set_caching_phase",
    "update_step",
    # Core
    "DistributedCache",
    "ConsistentHash", 
    "CachedDataset",
    # Config
    "RAMJET_BACKEND_URL",
    "get_api_key",
    "is_configured",
    # Backend client
    "BackendClient",
    "get_data_source_config",
    "get_cluster_nodes",
    "get_backend_client",
    "init_backend",
    # Data source types
    "DATA_SOURCE_TYPE_NONE",
    "DATA_SOURCE_TYPE_S3",
    "DATA_SOURCE_TYPE_LOCAL",
    "DATA_SOURCE_TYPE_HTTP",
]


# Training helpers (optional - requires torch)
try:
    from ramjetio.helpers import (
        load_config,
        start_cache_servers,
        setup_distributed,
        create_distributed_cache,
        create_cached_dataloader,
        cleanup_distributed,
    )
    __all__.extend([
        "load_config",
        "start_cache_servers",
        "setup_distributed",
        "create_distributed_cache",
        "create_cached_dataloader",
        "cleanup_distributed",
    ])
except ImportError:
    pass
