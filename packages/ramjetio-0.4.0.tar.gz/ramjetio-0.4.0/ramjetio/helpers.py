"""
RAMJET Training Helpers
Simplified API for distributed training with RAMJET cache
"""

import os
import yaml
import subprocess
import time
from typing import Dict, Any, Optional, Tuple

import torch
import torch.distributed as dist
from torch.utils.data import DataLoader, DistributedSampler

from ramjetio.cache import DistributedCache
from ramjetio.pytorch import CachedDataset


def load_config(config_path: str = 'configs/server_config.yaml') -> Dict[str, Any]:
    """
    Load YAML configuration file.
    
    Args:
        config_path: Path to YAML config file
        
    Returns:
        Configuration dictionary
    """
    with open(config_path) as f:
        return yaml.safe_load(f)


def start_cache_servers(config: Optional[Dict] = None, config_path: str = 'configs/server_config.yaml', detached: bool = False) -> list:
    """
    Start RAMJET cache servers based on configuration.
    
    Args:
        config: Configuration dict (if None, loads from config_path)
        config_path: Path to YAML config file
        detached: If True, run in background (don't wait for processes)
        
    Returns:
        List of subprocess.Popen objects
    """
    if config is None:
        config = load_config(config_path)
    
    cache_servers = config.get('cache_servers', [])
    processes = []
    
    print("🚀 Starting RAMJET cache servers...")
    
    for idx, server in enumerate(cache_servers):
        host = server.get('host', '127.0.0.1')  # Use IPv4 by default
        port = server.get('port', 8000 + idx)
        cache_size_gb = server.get('cache_size_gb', 100)
        
        # Cache directory
        cache_path = f'data/cache/server_{port}'
        os.makedirs(cache_path, exist_ok=True)
        
        # Log file
        log_dir = 'logs'
        os.makedirs(log_dir, exist_ok=True)
        log_file = f'{log_dir}/cache_{port}.log'
        
        print(f"📦 Starting cache server on {host}:{port} ({cache_size_gb}GB)...")
        
        # Start server process
        stdout_log = open(log_file, 'w') if detached else subprocess.PIPE
        stderr_log = subprocess.STDOUT if detached else subprocess.PIPE
        
        proc = subprocess.Popen(
            [
                'ramjet-server',
                '--host', host,
                '--port', str(port),
                '--storage-path', cache_path,
                '--capacity', f'{cache_size_gb}GB',
                '--log-level', 'INFO'
            ],
            stdout=stdout_log,
            stderr=stderr_log
        )
        
        processes.append(proc)
        print(f"   PID: {proc.pid}, Log: {log_file}")
    
    # Wait for servers to start
    print("⏳ Waiting for servers to initialize...")
    time.sleep(3)
    
    # Verify all servers are healthy
    try:
        import requests
        all_healthy = True
        
        for idx, server in enumerate(cache_servers):
            port = server.get('port', 8000 + idx)
            try:
                response = requests.get(f'http://localhost:{port}/health', timeout=2)
                if response.status_code == 200:
                    print(f"✅ Cache server on port {port} is healthy!")
                else:
                    print(f"❌ Cache server on port {port} failed health check")
                    all_healthy = False
            except Exception as e:
                print(f"⚠️  Cache server on port {port} not responding: {e}")
                all_healthy = False
        
        if not all_healthy:
            print(f"⚠️  Some cache servers may not be ready yet")
    except ImportError:
        print(f"⚠️  requests not installed, skipping health check")
    
    print(f"✅ Started {len(processes)} cache server(s)")
    return processes



def setup_distributed(backend: str = 'nccl') -> Tuple[int, int, int, torch.device]:
    """
    Setup PyTorch DDP (Distributed Data Parallel).
    
    Args:
        backend: DDP backend ('nccl' for GPU, 'gloo' for CPU)
        
    Returns:
        Tuple of (rank, world_size, local_rank, device)
    """
    dist.init_process_group(backend=backend)
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    local_rank = int(os.environ.get('LOCAL_RANK', 0))
    
    if torch.cuda.is_available():
        torch.cuda.set_device(local_rank)
        device = torch.device(f'cuda:{local_rank}')
    else:
        device = torch.device('cpu')
    
    return rank, world_size, local_rank, device


def create_distributed_cache(config: Optional[Dict] = None, config_path: str = 'configs/server_config.yaml') -> DistributedCache:
    """
    Create DistributedCache client from configuration.
    
    Args:
        config: Configuration dict (if None, loads from config_path)
        config_path: Path to YAML config file
        
    Returns:
        DistributedCache instance
    """
    if config is None:
        config = load_config(config_path)
    
    # Build node list
    nodes = []
    cache_servers = config.get('cache_servers', [])
    for server in cache_servers:
        host = server.get('host', '127.0.0.1')  # Use IPv4 by default
        port = server.get('port', 8000)
        node = f"{host}:{port}"
        nodes.append(node)
    
    ramjet_config = config.get('ramjet', {})
    
    cache = DistributedCache(
        nodes=nodes,
        timeout=ramjet_config.get('timeout', 30),
        retry_attempts=ramjet_config.get('retry_attempts', 5),
        replication_factor=ramjet_config.get('replication_factor', 2)
    )
    
    return cache


def create_cached_dataloader(
    dataset,
    cache: DistributedCache,
    batch_size: int,
    num_workers: int = 4,
    rank: int = 0,
    world_size: int = 1,
    shuffle: bool = True,
    key_prefix: str = 'data',
    collate_fn=None,
    pin_memory: bool = True
) -> DataLoader:
    """
    Create DataLoader with RAMJET cache and DDP sampler.
    
    Args:
        dataset: PyTorch Dataset
        cache: DistributedCache instance
        batch_size: Batch size per GPU
        num_workers: Number of data loading workers
        rank: DDP rank
        world_size: DDP world size
        shuffle: Whether to shuffle data
        key_prefix: Prefix for cache keys
        collate_fn: Custom collate function
        pin_memory: Whether to pin memory
        
    Returns:
        DataLoader with distributed sampler and caching
    """
    # Wrap dataset with cache
    cached_dataset = CachedDataset(
        dataset=dataset,
        cache=cache,
        key_fn=lambda idx: f"{key_prefix}_{idx}",
        cache_on_miss=True
    )
    
    # Create distributed sampler
    sampler = DistributedSampler(
        cached_dataset,
        num_replicas=world_size,
        rank=rank,
        shuffle=shuffle
    )
    
    # Create dataloader
    loader = DataLoader(
        cached_dataset,
        batch_size=batch_size,
        sampler=sampler,
        num_workers=num_workers,
        pin_memory=pin_memory,
        collate_fn=collate_fn,
        persistent_workers=(num_workers > 0)
    )
    
    return loader


def cleanup_distributed():
    """Cleanup DDP process group."""
    if dist.is_initialized():
        dist.destroy_process_group()
