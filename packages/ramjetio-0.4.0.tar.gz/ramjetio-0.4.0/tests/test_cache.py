"""
Tests for distributed cache client.
"""

import pytest
import torch
from unittest.mock import Mock, patch, MagicMock

from ramjetio.cache import DistributedCache


class TestDistributedCache:
    """Test cases for DistributedCache class."""
    
    def test_initialization(self):
        """Test cache initialization."""
        nodes = ["node1:9000", "node2:9000"]
        cache = DistributedCache(nodes=nodes)
        
        assert len(cache.nodes) == 2
        assert cache.timeout == 30
        assert cache.retry_attempts == 3
    
    def test_initialization_no_nodes(self):
        """Test that initialization fails with no nodes."""
        with pytest.raises(ValueError):
            DistributedCache(nodes=[])
    
    @patch('ramjet.cache.requests.post')
    def test_set_success(self, mock_post):
        """Test setting a value in cache."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_post.return_value = mock_response
        
        cache = DistributedCache(nodes=["node1:9000"])
        success = cache.set("test_key", "test_value")
        
        assert success
        assert mock_post.called
    
    @patch('ramjet.cache.requests.get')
    def test_get_success(self, mock_get):
        """Test getting a value from cache."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.content = b"test_value"
        mock_get.return_value = mock_response
        
        cache = DistributedCache(nodes=["node1:9000"])
        
        # Mock the deserialization
        with patch('ramjet.cache.deserialize_tensor', side_effect=Exception()), \
             patch('pickle.loads', return_value="test_value"):
            value = cache.get("test_key")
        
        assert value == "test_value"
        assert mock_get.called
    
    @patch('ramjet.cache.requests.get')
    def test_get_not_found(self, mock_get):
        """Test getting a non-existent key."""
        mock_response = Mock()
        mock_response.status_code = 404
        mock_get.return_value = mock_response
        
        cache = DistributedCache(nodes=["node1:9000"])
        value = cache.get("nonexistent_key")
        
        assert value is None
    
    @patch('ramjet.cache.requests.delete')
    def test_delete_success(self, mock_delete):
        """Test deleting a value from cache."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_delete.return_value = mock_response
        
        cache = DistributedCache(nodes=["node1:9000"])
        success = cache.delete("test_key")
        
        assert success
        assert mock_delete.called
    
    def test_add_node(self):
        """Test adding a node to the cache cluster."""
        cache = DistributedCache(nodes=["node1:9000"])
        cache.add_node("node2:9000")
        
        assert len(cache.nodes) == 2
        assert "node2:9000" in cache.nodes
    
    def test_remove_node(self):
        """Test removing a node from the cache cluster."""
        cache = DistributedCache(nodes=["node1:9000", "node2:9000"])
        cache.remove_node("node1:9000")
        
        assert len(cache.nodes) == 1
        assert "node1:9000" not in cache.nodes
