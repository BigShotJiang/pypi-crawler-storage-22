# randstadenterprise_edao_libraries/domo_users.py
from typing import List, Dict, Any, Optional, Callable

# Define the type for the log function
LogFunc = Callable[[str], None] 

# =======================================================================
# RETRIEVES ALL USERS, ENRICHES DATA, AND MAPS BY USER ID
#     Retrieves all instance users, enriches the data with readable fields, 
#     and returns a map of the full domo_objects.User object by User ID.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.

#     :returns: Dictionary mapping User ID (str) to the domo_objects.User object.
# =======================================================================

def get_instance_users (inst_url: str, inst_dev_token: str, log_func: LogFunc) -> List[Any]:
    
    log_func(f"____ get_instance_users: {inst_url}")
    
    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects
    from . import domo_roles

    # 1. Get Role Map for lookup using the roles function
    roles_map = domo_roles.get_instance_roles(inst_url, inst_dev_token, log_func)
    
    # 2. Get raw user data using the private search helper
    inst_users = _get_instance_users_search(inst_url, inst_dev_token, log_func)
    
    users: List[objects.User] = _load_user_objects(log_func, inst_users)

    log_func(f"____ END get_instance_users: {inst_url}")
 
    return users
# END def get_instance_users

# =======================================================================
# RETRIEVES A SINGLE USER BY ID
#     Stubs out functionality to retrieve a single user by their ID.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param user_id: The string ID of the user.
#     :param log_func: Pre-bound logging function.
#     :returns: The domo_objects.User object, or None if not found.
# =======================================================================
def get_user_by_id (inst_url: str, inst_dev_token: str, log_func: LogFunc, user_id: str) -> Any:
       
    log_func(f"____ get_user_by_id: {inst_url}")
    
     # ADD IMPORT HERE (Lazy Import)
    from . import edao_http
    from . import domo_attributes
    
    api_url = f'https://{inst_url}.domo.com/api/identity/v1/users/search?explain=true'
    
    sync_attrs = domo_attributes.get_instance_attributes (inst_url, inst_dev_token, log_func)
    
    # 1. Loop and filter: Add keys that do not start with "domo.policy"
    search_attributes = [
        attr_key for attr_key, attr_val in sync_attrs.items() 
        if not attr_key.startswith("domo.policy")
    ]   
    
    body = {
      "ids": [
        user_id
      ],
      "showCount": False,
      "includeDeleted": True,
      "onlyDeleted": False,
      "includeSupport": True,
      "limit": 1,
      "offset": 0,
      "parts": [
        "DETAILED",
        "GROUPS",
        "ROLE"
      ],
      "attributes": search_attributes
    }

    resp = edao_http.post(api_url, inst_dev_token, log_func, body)    
    user_json = {}
    if "users" in resp:
        user_list = resp.get("users", [])
        if len(user_list) > 0:
            user_json = user_list[0] 
        # END if len(user_list) > 0:
    # END if "users" in user_json:
    
    user_result = _load_user_object(log_func, user_json)

    log_func(f"____ END get_user_by_id: {inst_url}")
    
    return user_result
    
# END def get_user_by_id

# =======================================================================
# RETRIEVES A SINGLE USER BY EMAIL ADDRESS
#     Stubs out functionality to retrieve a single user by their email address.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param user_email: The email address of the user.
#     :param log_func: Pre-bound logging function.
#     :returns: The domo_objects.User object, or None if not found.
# =======================================================================
def get_user_by_email (inst_url: str, inst_dev_token: str, log_func: LogFunc, user_email: str) -> Any:
       
    log_func(f"____ get_user_by_email: {inst_url}")
    
    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http
    from . import domo_attributes
    
    api_url = f'https://{inst_url}.domo.com/api/identity/v1/users/search?explain=true'
    
    sync_attrs = domo_attributes.get_instance_attributes (inst_url, inst_dev_token, log_func)
    
    # 1. Loop and filter: Add keys that do not start with "domo.policy"
    search_attributes = [
        attr_key for attr_key, attr_val in sync_attrs.items() 
        if not attr_key.startswith("domo.policy")
    ]   
    
    body = {
        "filters": [
            {
              "field": "emailAddress",
              "operator": "EQ",
              "filterType": "value",
              "values": [
                user_email
              ]
            }
          ],
        "showCount": False,
        "includeDeleted": True,
        "onlyDeleted": False,
        "includeSupport": True,
        "limit": 1,
        "offset": 0,
        "parts": [
            "DETAILED",
            "GROUPS",
            "ROLE"
        ],
        "attributes": search_attributes
    }

    resp = edao_http.post(api_url, inst_dev_token, log_func, body)
    user_json = {}
    if "users" in resp:
        user_list = resp.get("users", [])
        if len(user_list) > 0:
            user_json = user_list[0] 
        # END if len(user_list) > 0:
    # END if "users" in user_json:
    
    user_result = _load_user_object(log_func, user_json)
    
    log_func(f"____ get_user_by_email: {inst_url}")

    return user_result
    
# END def get_user_by_email

# =======================================================================
# USER MODIFICATION FUNCTIONS
# =======================================================================

# =======================================================================
# CREATES A USER
#    Functionality to create a user.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param user_obj: The domo_objects.User object (dataclass instance) to be saved.
#     :returns: The user object of the created user.
# =======================================================================
def create_user (inst_url: str, inst_dev_token: str, log_func: LogFunc, user_obj: Any) -> Any:

    log_func(f"____ create_user: {inst_url}")
    
    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http
    from . import domo_roles
    from . import domo_attributes
    
    role_id = user_obj.role_id
    if role_id is None:
        cp_role = domo_roles.get_role_by_name (inst_url, inst_dev_token, log_func, "Corporate Participant")
        role_id = cp_role.role_id
    # END if role_id is None:
    
    body = {
                 # "invitorUserId": dest_invitor_user_id, # Commented out as in your original
                 "displayName": user_obj.name,
                 "roleId": role_id,
                 "detail": {
                     "email": user_obj.email_address
                 }
               }

    api_url = 'https://' + inst_url + '.domo.com' + '/api/content/v3/users/'

    resp = edao_http.post(api_url, inst_dev_token, body)

    user_obj = _load_user_object(log_func, resp)
    
    log_func(f"____ END create_user: {inst_url}")
    
    return user_obj
# END def create_user

# =======================================================================
# SAVES A USER
#     functionality to update a user.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param user_obj: The domo_objects.User object (dataclass instance) to be saved.
#     :param log_func: Pre-bound logging function.
#     :returns: The string ID of the saved user, or None on failure.
# =======================================================================
def update_user (inst_url: str, inst_dev_token: str, log_func: LogFunc, user_obj: Any) -> Optional[str]:
    print(f"STUB: Saving user {user_obj.email_address} to {inst_url}")
    return user_obj.id
# END def save_user


# =======================================================================
# DELETES A USER BY ID
#     Stubs out functionality to delete a user.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param user_id: The string ID of the user to delete.
#     :param log_func: Pre-bound logging function.
#     :returns: True on success, False on failure.
# =======================================================================
# def delete_user (inst_url: str, inst_dev_token: str, user_id: str, log_func: LogFunc) -> bool:
#     print(f"STUB: Deleting user {user_id} from {inst_url}")
#     return True
# # END def delete_user


# =======================================================================
# PRIVATE API RETRIEVAL FUNCTIONS
# =======================================================================

# =======================================================================
# PRIVATE: RETRIEVES ALL USERS VIA PAGINATED SEARCH API
#     (PRIVATE) Searches and retrieves all users from an instance, including custom attributes 
#     from the provided SYNC_ATTRS map.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.

#     :returns: A list of raw user dictionaries.
# =======================================================================
def _get_instance_users_search (inst_url: str, inst_dev_token: str, log_func: LogFunc) -> List[Dict[str, Any]]:

    log_func(f'_______ _get_instance_users_search({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http
    from . import domo_attributes

    sync_attrs = domo_attributes.get_instance_attributes (inst_url, inst_dev_token, log_func)
    
    # 1. Loop and filter: Add keys that do not start with "domo.policy"
    search_attributes = [
        attr_key for attr_key, attr_val in sync_attrs.items() 
        if not attr_key.startswith("domo.policy")
    ]   

    # --- Step 2: Paginate through users ---
                        
    api_url = f'https://{inst_url}.domo.com/api/identity/v1/users/search'    
    
    inst_user = []
    total = 100000
    offset = 0
    limit = 100
    
    while offset < total:

        body = {
            "showCount": False,
            "includeDeleted": True,
            "onlyDeleted": False,
            "includeSupport": True,
            "limit": limit,
            "offset": offset,
            "sort": {
                "field": "displayName",
                "order": "ASC"
            },
            "parts": [
                "DETAILED",
                "GROUPS",
                "ROLE"
            ],
            "attributes": search_attributes
        }
        
        resp = edao_http.post(api_url, inst_dev_token, log_func, body)
    
        # Update total count based on API response
        count = resp.get("count", 0)
        total = count
        page_users = resp.get("users", [])

        # Append users and increment offset
        inst_user.extend(page_users)
        offset = offset + limit
            
    # END while offset < total
    
    log_func(f'_______ END _get_instance_users_search({inst_url})')

    return inst_user
# END def _get_instance_users_search


# =======================================================================
# PRIVATE: LOAD USER OBJECTS
#     (PRIVATE) Converts a json list to a List of User objects
# =======================================================================
def _load_user_objects(log_func: LogFunc, json_array: Any) -> List[Any]:
    """
    Parses a list of raw JSON objects into a list of domo_objects.User instances.
    Skips individual objects that fail to load.
    """
    
    loaded_objects = [] 
    
    # 1. Validate the input array
    if json_array is None:
        log_func("WARN: Input json_array is None. Returning empty list.")
        return []
        
    if not isinstance(json_array, list):
        msg = f"CRITICAL: Input json_array must be a list, got {type(json_array).__name__}."
        log_func(msg)
        raise TypeError(msg)

    # 2. Iterate through the array
    for i, json_item in enumerate(json_array):
        try:
            # 3. Load individual object
            # FIX: Changed from _load_role_object to _load_user_object
            obj = _load_user_object(log_func, json_item)
            
            loaded_objects.append(obj)
            
        except (ValueError, RuntimeError) as e:
            log_func(f"ERROR: Failed to load object at index {i}. Skipping. Details: {e}")
            continue
            
        except Exception as e:
            log_func(f"CRITICAL: Unexpected error loading object at index {i}: {e}")
            continue

    return loaded_objects
# END def _load_user_objects()

# =======================================================================
# PRIVATE: LOAD USER OBJECT
#     (PRIVATE) Converts a json obj to a User object
# =======================================================================
def _load_user_object(log_func: LogFunc, json: Any) -> Any:
    """
    Parses raw JSON into an domo_objects.User instance. 
    Raises an error if JSON is missing or if object creation fails.
    """
    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects

    # 1. Check if JSON is None or empty
    if not json:
        msg = "CRITICAL: Input JSON for _load_user_object is None or empty."
        log_func(msg)
        raise ValueError(msg)

    try:
        # --- FIX: LOGIC MOVED HERE FROM MAIN FUNCTION ---
        
        # Process Custom attributes into Dict[str, List[str]] format
        u_attrs_map: Dict[str, List[str]] = {}
        if "attributes" in json:
            u_attrs = json['attributes']            
            for a in u_attrs:
                key = a.get("key")
                values = a.get("values", [])
                if key: u_attrs_map[key] = values

        # Process Groups
        groups_list: List[str] = []
        if "groups" in json:
            for g in json['groups']:
                if g.get("name"): groups_list.append(g["name"])
        
        # 2. Attempt to create the User object
        return domo_objects.User(
            id=str(json.get('id', '')),
            name=json.get('emailAddress', ''),
            type='USER',
            
            email_address=json.get('emailAddress', ''),
            display_name=json.get('displayName'), 
            user_name=json.get('userName'),
            role_id=str(json.get('roleId')),
            last_activity=json.get('lastActivity'),
            groups=groups_list,      # Now defined
            attributes=u_attrs_map   # Now defined
        )    
    
    except Exception as e:
        msg = f"CRITICAL: Failed to instantiate domo_objects.User. Error: {e}"
        log_func(msg)
        raise RuntimeError(msg) from e
        
# END def _load_user_object()