import polars as pl
import pandas as pd
from datetime import datetime
 
start=datetime.now()
 
fp = r"C:\Users\Akshat.Sethi\Downloads\python\\"
fl = 'pheonix_v1'
df = pl.read_excel(fp + fl + '.xlsx', infer_schema_length=0)
# df = pl.read_csv(fp + fl + '.csv', infer_schema_length=0)
df = df.unique()
 
aa = []
bb = []
cc = []
dd = []
ee = []
 
for col in df.columns:
    df = df.with_columns(pl.col(col).str.to_uppercase().alias(col))
    df = df.with_columns(pl.col(col).str.replace_all('  ',' ').alias(col))
    df = df.with_columns(pl.col(col).str.strip_chars().alias(col))
    df = df.with_columns(pl.when(pl.col(col)=='').then(pl.lit(None)).otherwise(pl.col(col)).alias(col))
    df1 = df.select(col)
    df1 = df1.filter(pl.col(col).is_not_null())
    if df1.filter(pl.col(col).str.contains(';')).height>=1:
        df1 = df1.with_columns(pl.col(col).str.split(';').alias(col)).explode(col)
        df1 = df1.with_columns(pl.col(col).str.replace_all('  ',' ').alias(col))
        df1 = df1.with_columns(pl.col(col).str.strip_chars().alias(col))
        df1 = df1.with_columns(pl.when(pl.col(col)=='').then(pl.lit(None)).otherwise(pl.col(col)).alias(col))
        aa.append(col)
    df2 = df1.unique()
    print(f"{col} | {df2.height} | {df1.height}")
    if df1.height==0:
        bb.append(col)
    if df1.height!=0 & df2.height==df1.height:
        cc.append(col)
    if df1.height!=0 & df2.height!=df1.height & df2.height<=5:
        dd.append(col)
    if df1.height!=0 & df2.height!=df1.height & df2.height>5:
        ee.append(col)
 
print(aa)
print(bb)
print(cc)
print(dd)
print(ee)
 
ff = ['FirstName',
 'MiddleName',
 'LastName',
 'Suffix']
 
gg = ['InternationalAddress',
 'PERSONALPHONENUMBER',
 'PERSONALEMAILADDRESS',
 'WORKEMAIL',
 'NHS(NationalHealthServiceNumber)',
 'TAXIDENTIFICATIONNUMBER',
 'DATEOFBIRTH',
 "Driver'sLicenseNumber",
 'OTHERGOVERNMENTID',
 'PassportNumber',
 'Credit/DebitCardNumber',
 'FULLBANKACCOUNTNUMNER',
 'nino']
 
 
hh = ['InternationalAddress',
 'PERSONALPHONENUMBER',
 'PERSONALEMAILADDRESS',
 'WORKEMAIL',
 'NHS(NationalHealthServiceNumber)',
 'TAXIDENTIFICATIONNUMBER',
 "Driver'sLicenseNumber",
 'OTHERGOVERNMENTID',
 'PassportNumber',
 'Credit/DebitCardNumber',
 'FULLBANKACCOUNTNUMNER',
 'nino']
 
df = df.with_columns(pl.concat_str(ff, separator=' ', ignore_nulls=True).alias('fn'))
df = df.with_columns(pl.col('fn').str.replace_all('-',' ').alias('fn'))
df = df.with_columns(pl.col('fn').str.replace_all("\'",' ').alias('fn'))
df = df.with_columns(pl.col('fn').str.replace_all('  ',' ').alias('fn'))
df = df.with_columns(pl.col('fn').str.strip_chars().alias('fn'))
df = df.with_columns(pl.when(pl.col('fn')=='').then(pl.lit(None)).otherwise(pl.col('fn')).alias('fn'))
df1 = df.select('fn').unique()
df1 = df1.with_columns(pl.col('fn').str.split(' ').alias('fn2')).explode('fn2')
df1 = df1.filter(pl.col('fn2').is_not_null()).sort('fn2', 'fn')
df1 = df1.group_by('fn').agg(pl.col('fn2').str.concat(' ').alias('fn2'))
df = df.join(df1, on='fn', how='left')
 
ii = ['fn2']
for col in gg:
    df = df.with_columns(pl.col(col).str.replace(r"^0+", "").alias(col+"_1"))
    ii.append(col+"_1")
 
df = df.with_columns(pl.concat_str(ii, separator='', ignore_nulls=True).alias('ds'))
 
jj = []
for col in hh:
    df = df.with_columns(pl.col(col).str.replace(r"^0+", "").alias(col+"_2"))
    jj.append(col+"_2")
 
df = df.with_columns(pl.concat_str(jj, separator=';', ignore_nulls=True).alias('de'))
 
df = df.with_columns(pl.col('ds').rank(method='ordinal').alias('record_id'))
df = df.with_columns(pl.col('ds').rank(method='dense').alias('dense_id')).drop('ds')
 
df = df.with_columns(pl.col('de').str.split(';').alias('de')).explode('de')
df1 = df.select('de')
df1 = df1.fill_null('')
df1 = df1.filter(pl.col('de')!='').unique()
df1 = df1.with_columns(pl.col('de').rank(method='ordinal').alias('element_id'))
df = df.join(df1, on='de', how='left').drop('de')
df = df.unique()
 
parent = {}
 
def find(x):
    parent.setdefault(x, x)
    if parent[x] != x:
        parent[x] = find(parent[x])
    return parent[x]
 
def union(x, y):
    px, py = find(x), find(y)
    if px != py:
        parent[py] = px
 
for _, g in df.group_by("dense_id"):
    ids = g["record_id"].to_list()
    for i in range(1, len(ids)):
        union(ids[0], ids[i])
 
for _, g in df.filter(pl.col("element_id").is_not_null()).group_by("element_id"):
    ids = g["record_id"].to_list()
    for i in range(1, len(ids)):
        union(ids[0], ids[i])
 
roots = {rid: find(rid) for rid in df["record_id"]}
root_to_common = {r: i + 1 for i, r in enumerate(sorted(set(roots.values())))}
 
df = df.with_columns(
    pl.col("record_id")
      .map_elements(lambda x: root_to_common[roots[x]])
      .alias("common_id"))
 
df.write_parquet(fp + fl +'_v1.parquet')
 
ff.append('fn2')
ff.append('common_id')
df1 = df.select(ff).unique().filter(pl.col('common_id').is_not_null())
df1 = df1.join(df1.group_by('common_id').count().filter(pl.col('count')>1), on='common_id', how='left').sort('count','common_id')
df1 = df1.filter(pl.col('count').is_not_null())
 
df1.to_pandas().to_excel(fp + fl +'_v1_Demerge_Names.xlsx', index=False)
 
print(df.select('common_id').unique().shape)
print(df1.shape)
 
end=datetime.now()
dur = end - start
hours, remainder = divmod(dur.total_seconds(), 3600)
minutes, seconds = divmod(remainder, 60)
print(f"{int(hours):02}:{int(minutes):02}:{int(seconds):02}")



import re
import polars as pl
import pandas as pd
file = "export_20260127-045253.csv"
df = pl.read_csv(file, infer_schema_length=0)
df = df.with_columns([pl.col(c).cast(pl.Utf8) for c in df.columns])
df = df.select([
    pl.col(col)
    .str.strip_chars()
    .str.replace(r'\s+', ' ', literal=False)
    .str.replace(r' ;', ';', literal=False)
    .str.replace(r'; ', ';', literal=False)
    .str.to_lowercase()
    .str.strip_chars()
    .alias(col)
    for col in df.columns
])
print(df.columns)

df1 = df
df1 = df1.fill_null("")
df = df.select('name_id').unique()
cols = ['First Name', 'Middle Name', 'Last Name', 'Suffix', 'Address', 'City', 'State', 'Zip', 'Country', 'DOB', 'SSN', 'TIN', 'DATA OWNER', 'PASSPORT ISSUING COUNTRY', 'PASSPORT EXPIRATION DATE', "DRIVER'S LICENSE STATE", 'OTHER GOVERNMENT ISSUED ID TYPE', 'OTHER GOVERNMENT ID ISSUING COUNTRY', 'FINANCIAL INSTITUTION NAME', 'LOGIN PLATFORM', 'MEDICAL RECORD NUMBER', 'PATIENT ACCOUNT NUMBER', 'DATE OF DEATH', 'PASSPORT NUMBER', "DRIVER'S LICENSE NUMBER", 'STATE IDENTIFICATION CARD NUMBER', 'ALIEN REGISTRATION NUMBER', 'MILITARY ID NUMBER', 'STUDENT ID NUMBER', 'TRIBAL IDENTIFICATION NUMBER', 'OTHER GOVERNMENT ISSUED ID NUMBER', 'PAYMENT CARD NUMBER', 'PAYMENT CARD EXPIRATION DATE', 'FINANCIAL ACCOUNT NUMBER', 'HEALTH INSURANCE POLICY-RELATED NUMBER', 'MEDICAID / MEDICARE NUMBER']
for col in cols:
    df3 = df1.select(['name_id', col]).filter(pl.col(col) != '')
    df3 = df3.with_columns(pl.col(col).str.split(';')).explode(col)
    df3 = df3.unique()
    df3 = df3.group_by('name_id').agg(
         pl.col(col).unique().str.join(';').alias(col)
    )
    df = df.join(df3, on='name_id', how='left')