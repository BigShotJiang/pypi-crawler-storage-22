from .main import OpenVINOInferSession
