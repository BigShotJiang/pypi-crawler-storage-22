# -*- coding: utf-8 -*-
"""Protobuf generated modules for Rapida clients."""
