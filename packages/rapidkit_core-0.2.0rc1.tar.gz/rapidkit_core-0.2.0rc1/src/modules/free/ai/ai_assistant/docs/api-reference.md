# Ai Assistant API Reference

## Runtime Surface

Detail public classes, functions, and dataclasses exported from the runtime templates.

## Configuration Schema

Enumerate configuration keys, types, defaults, and validation semantics.

## CLI Entrypoints

Describe generator commands, arguments, and expected outputs for each framework.
