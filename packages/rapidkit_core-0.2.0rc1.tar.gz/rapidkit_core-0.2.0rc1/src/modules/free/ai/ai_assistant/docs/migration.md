# Ai Assistant Migration Guide

Track version upgrades, breaking changes, and operator checklists required when rolling out new
releases. Each entry should explain the impact, upgrade steps, and fallback plan.
