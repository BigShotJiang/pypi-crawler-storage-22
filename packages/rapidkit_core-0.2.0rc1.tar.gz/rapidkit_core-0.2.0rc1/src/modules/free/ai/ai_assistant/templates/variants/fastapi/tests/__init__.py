"""FastAPI AI Assistant E2E tests shipped to users."""
