"""Test templates package for the Passwordless module."""
