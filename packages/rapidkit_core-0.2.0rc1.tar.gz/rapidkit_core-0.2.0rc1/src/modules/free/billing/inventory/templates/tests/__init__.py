"""Pytest scaffolding templates for the Inventory module."""
