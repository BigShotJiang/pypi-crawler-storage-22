"""Test templates package for the storage module."""
