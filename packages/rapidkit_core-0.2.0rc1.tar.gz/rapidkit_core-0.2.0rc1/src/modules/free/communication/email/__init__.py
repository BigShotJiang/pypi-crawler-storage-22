"""Runtime package for the Email module."""

__all__ = ["Email"]
