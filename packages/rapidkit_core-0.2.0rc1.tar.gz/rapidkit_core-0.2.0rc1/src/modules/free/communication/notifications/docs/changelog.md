# Changelog — free/communication/notifications

## 0.1.17 — Automated patch release triggered by content hash change (2026-01-04)

- chore: Automated patch release triggered by content hash change

## 0.1.16 — Automated patch release triggered by content hash change (2026-01-03)

- chore: Automated patch release triggered by content hash change

## 0.1.15 — Automated patch release triggered by content hash change (2025-12-28)

- chore: Automated patch release triggered by content hash change

## 0.1.14 — Automated patch release triggered by content hash change (2025-12-25)

- chore: Automated patch release triggered by content hash change

## 0.1.13 — Automated patch release triggered by content hash change (2025-12-24)

- chore: Automated patch release triggered by content hash change

## 0.1.12 — Automated patch release triggered by content hash change (2025-12-14)

- chore: Automated patch release triggered by content hash change

## 0.1.11 — Automated patch release triggered by content hash change (2025-12-14)

- chore: Automated patch release triggered by content hash change

## 0.1.10 — Automated patch release triggered by content hash change (2025-12-14)

- chore: Automated patch release triggered by content hash change

## 0.1.9 — Automated patch release triggered by content hash change (2025-12-12)

- chore: Automated patch release triggered by content hash change

## 0.1.8 — Automated patch release triggered by content hash change (2025-12-12)

- chore: Automated patch release triggered by content hash change

## 0.1.7 — Automated patch release triggered by content hash change (2025-12-12)

- chore: Automated patch release triggered by content hash change

## 0.1.6 — Automated patch release triggered by content hash change (2025-12-09)

- chore: Automated patch release triggered by content hash change

## 0.1.5 — Automated patch release triggered by content hash change (2025-12-09)

- chore: Automated patch release triggered by content hash change

## 0.1.4 — Automated patch release triggered by content hash change (2025-12-07)

- chore: Automated patch release triggered by content hash change

## 0.1.3 — Automated patch release triggered by content hash change (2025-12-06)

- chore: Automated patch release triggered by content hash change

## 0.1.2 — Metadata + manifest alignment (2025-12-06)

- Updated `module.yaml` to list the real unit + integration test paths so validation tooling
  observes the FastAPI stack correctly.

## 0.1.1 — Automated patch release (2025-12-04)

- Content hash refresh to capture the initial scaffolding tweaks.

## 0.1.0 — Initial baseline (2025-12-04)

- Initial public baseline.
