# Changelog — free/auth/passwordless

## 0.1.0 — Initial baseline (2025-12-04)

- Initial public baseline.
