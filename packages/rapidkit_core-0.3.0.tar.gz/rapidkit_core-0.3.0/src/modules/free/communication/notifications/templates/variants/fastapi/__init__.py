"""FastAPI variant templates."""
