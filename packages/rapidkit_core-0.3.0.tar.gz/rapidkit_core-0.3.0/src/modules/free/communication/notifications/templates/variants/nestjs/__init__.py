"""NestJS variant templates."""
