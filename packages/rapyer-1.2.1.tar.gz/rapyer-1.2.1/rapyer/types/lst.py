import json
import logging
from typing import TypeVar, TYPE_CHECKING

from pydantic_core import core_schema
from pydantic_core.core_schema import ValidationInfo, SerializationInfo
from typing_extensions import TypeAlias

from rapyer.scripts import run_sha, REMOVE_RANGE_SCRIPT_NAME
from rapyer.types.base import (
    GenericRedisType,
    RedisType,
    REDIS_DUMP_FLAG_NAME,
    SKIP_SENTINEL,
)

logger = logging.getLogger("rapyer")

T = TypeVar("T")


class RedisList(list, GenericRedisType[T]):
    original_type = list

    def __init__(self, *args, **kwargs):
        list.__init__(self, *args, **kwargs)
        GenericRedisType.__init__(self, *args, **kwargs)

    def create_new_values(self, keys, values):
        new_values = self._adapter.validate_python(values)
        for key, value in zip(keys, new_values):
            self.init_redis_field(f"[{key}]", value)
        return new_values

    def create_new_value(self, key, value):
        new_val = self.create_new_values([key], [value])[0]
        return new_val

    def sub_field_path(self, key: str):
        return f"{self.field_path}[{key}]"

    def __setitem__(self, key, value):
        if self.pipeline:
            serialized = self._adapter.dump_python(
                [value], mode="json", context={REDIS_DUMP_FLAG_NAME: True}
            )
            self.pipeline.json().set(self.key, self.json_field_path(key), serialized[0])
        new_val = self.create_new_value(key, value)
        return super().__setitem__(key, new_val)

    def __iadd__(self, other):
        self.extend(other)
        return self

    def append(self, __object):
        if self.pipeline:
            serialized_object = self._adapter.dump_python(
                [__object], mode="json", context={REDIS_DUMP_FLAG_NAME: True}
            )
            self.pipeline.json().arrappend(
                self.key, self.json_path, serialized_object[0]
            )
        key = len(self)
        new_val = self.create_new_value(key, __object)
        return super().append(new_val)

    def extend(self, new_lst):
        if self.pipeline and new_lst:
            serialized = self._adapter.dump_python(
                list(new_lst), mode="json", context={REDIS_DUMP_FLAG_NAME: True}
            )
            self.pipeline.json().arrappend(self.key, self.json_path, *serialized)
        new_keys = range(len(self), len(self) + len(new_lst))
        new_vals = self.create_new_values(list(new_keys), new_lst)
        return super().extend(new_vals)

    def insert(self, index, __object):
        if self.pipeline:
            serialized = self._adapter.dump_python(
                [__object], mode="json", context={REDIS_DUMP_FLAG_NAME: True}
            )
            self.pipeline.json().arrinsert(
                self.key, self.json_path, index, serialized[0]
            )
        new_val = self.create_new_value(index, __object)
        return super().insert(index, new_val)

    def clear(self):
        if self.pipeline:
            self.pipeline.json().set(self.key, self.json_path, [])
        return super().clear()

    def remove_range(self, start: int, end: int):
        if self.pipeline:
            run_sha(
                self.pipeline,
                REMOVE_RANGE_SCRIPT_NAME,
                1,
                self.key,
                self.json_path,
                start,
                end,
            )
            del self[start:end]
        else:
            logger.warning(
                "remove_range() called without a pipeline context. "
                "No changes were made. Use 'async with model.apipeline():' to execute."
            )

    async def aappend(self, __object):
        self.append(__object)

        # Serialize the object for Redis storage using a type adapter
        if not self.pipeline:
            serialized_object = self._adapter.dump_python(
                [__object], mode="json", context={REDIS_DUMP_FLAG_NAME: True}
            )
            await self.redis.json().arrappend(
                self.key, self.json_path, *serialized_object
            )
            await self.refresh_ttl_if_needed()

    async def aextend(self, __iterable):
        items = list(__iterable)
        self.extend(items)

        # Convert iterable to list and serialize items using type adapter
        if items and not self.pipeline:
            # normalized_items = self._adapter.validate_python(items)
            serialized_items = self._adapter.dump_python(
                items, mode="json", context={REDIS_DUMP_FLAG_NAME: True}
            )
            await self.redis.json().arrappend(
                self.key,
                self.json_path,
                *serialized_items,
            )
            await self.refresh_ttl_if_needed()

    async def apop(self, index=-1):
        if self:
            self.pop(index)
        arrpop = await self.redis.json().arrpop(self.key, self.json_path, index)
        await self.refresh_ttl_if_needed()

        # Handle case where arrpop returns [None] for an empty list
        if arrpop[0] is None:
            return None
        arrpop = [json.loads(val) for val in arrpop]
        return self._adapter.validate_python(
            arrpop, context={REDIS_DUMP_FLAG_NAME: True}
        )[0]

    async def ainsert(self, index, __object):
        self.insert(index, __object)

        if not self.pipeline:
            # Serialize the object for Redis storage using a type adapter
            serialized_object = self._adapter.dump_python(
                [__object], mode="json", context={REDIS_DUMP_FLAG_NAME: True}
            )
            await self.redis.json().arrinsert(
                self.key, self.json_path, index, *serialized_object
            )
            await self.refresh_ttl_if_needed()

    async def aclear(self):
        # Clear local list
        self.clear()

        # Clear Redis list
        if not self.pipeline:
            await self.client.json().set(self.key, self.json_path, [])
            await self.refresh_ttl_if_needed()

    def clone(self):
        return [v.clone() if isinstance(v, RedisType) else v for v in self]

    def iterate_items(self):
        keys = [f"[{i}]" for i in range(len(self))]
        return zip(keys, self)

    @classmethod
    def full_serializer(cls, value, info: SerializationInfo):
        ctx = info.context or {}
        is_redis_data = ctx.get(REDIS_DUMP_FLAG_NAME)
        return [
            cls.serialize_unknown(item) if is_redis_data else item for item in value
        ]

    @classmethod
    def full_deserializer(cls, value: list, info: ValidationInfo):
        ctx = info.context or {}
        is_redis_data = ctx.get(REDIS_DUMP_FLAG_NAME)

        if not is_redis_data:
            return value

        return [
            deserialized
            for idx, item in enumerate(value)
            if (deserialized := cls.try_deserialize_item(item, f"index {idx}"))
            is not SKIP_SENTINEL
        ]

    @classmethod
    def schema_for_unknown(cls):
        core_schema.list_schema(core_schema.str_schema())


if TYPE_CHECKING:
    RedisList: TypeAlias = RedisList[T] | list[T]  # pragma: no cover
