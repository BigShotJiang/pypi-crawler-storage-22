# Copyright 2025 Rapyuta Robotics
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import click
from click_help_colors import HelpColorsCommand

from riocli.config import get_config_from_context
from riocli.constants import Colors
from riocli.usergroup.util import UserGroupNotFound
from riocli.utils import inspect_with_format


@click.command(
    "inspect",
    cls=HelpColorsCommand,
    help_headers_color=Colors.YELLOW,
    help_options_color=Colors.GREEN,
)
@click.option(
    "--format",
    "-f",
    "format_type",
    default="yaml",
    type=click.Choice(["json", "yaml"], case_sensitive=False),
)
@click.argument("group-name")
@click.pass_context
def inspect_usergroup(
    ctx: click.Context,
    format_type: str,
    group_name: str,
) -> None:
    """Print the details of a usergroup

    You choose the format of the output using the ``--format`` flag.
    The supported formats are ``json`` and ``yaml``. Default is ``yaml``.
    """
    try:
        config = get_config_from_context(ctx)
        client = config.new_v2_client(with_project=False)
        usergroup_list = client.list_user_groups(name=group_name)
        if len(usergroup_list.items) == 0:
            raise UserGroupNotFound

        usergroup = client.get_user_group(
            group_name=usergroup_list.items[0].metadata.name,
            group_guid=usergroup_list.items[0].metadata.guid,
        )
        inspect_with_format(
            usergroup.model_dump(exclude_none=True, by_alias=True), format_type
        )
    except Exception as e:
        click.secho(str(e), fg=Colors.RED)
        raise SystemExit(1)
