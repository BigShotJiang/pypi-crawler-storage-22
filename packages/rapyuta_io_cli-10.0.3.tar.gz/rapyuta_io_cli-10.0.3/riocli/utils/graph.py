# Copyright 2024 Rapyuta Robotics
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import base64
import tempfile
from abc import ABC, abstractmethod

import click
from graphviz import Digraph
from typing_extensions import override


class GraphVisualizer(ABC):
    @abstractmethod
    def node(self, key: str, label: str | None = None) -> None:
        pass

    @abstractmethod
    def edge(self, from_node: str, to_node: str) -> None:
        pass

    @abstractmethod
    def visualize(self, print_only: bool = False) -> None:
        pass


class Mermaid(GraphVisualizer):
    def __init__(self, format: str = "svg", direction: str = "LR") -> None:
        self._diagram = [f"flowchart {direction}"]
        self._format = format

    @override
    def node(self, key: str, label: str | None = None) -> None:
        if label is None:
            label = key

        self._diagram.append(f"\t{self._mermaid_safe(key)}[{label}]")

    @override
    def edge(self, from_node: str, to_node: str) -> None:
        self._diagram.append(
            f"\t{self._mermaid_safe(from_node)} --> {self._mermaid_safe(to_node)}"
        )

    @override
    def visualize(self, print_only: bool = False) -> None:
        print("\n".join(self._diagram))
        if not print_only:
            _ = click.launch(self._mermaid_link())

    def _mermaid_link(self):
        diagram = "\n".join(self._diagram).encode("ascii")
        data = base64.b64encode(diagram).decode("ascii")
        return f"https://mermaid.ink/{self._format}/{data}"

    def _mermaid_safe(self, s: str) -> str:
        return s.replace(" ", "_")


class Graphviz(GraphVisualizer):
    def __init__(
        self,
        name: str | None = None,
        format: str = "svg",
        direction: str = "TB",
        shape: str = "box",
    ) -> None:
        self._graph = Digraph(name=name)
        self._graph.format = format
        self._graph.attr("graph", overlap="False", rankdir=direction)
        self._graph.attr("node", shape=shape)

    @override
    def node(self, key: str, label: str | None = None) -> None:
        self._graph.node(self._graphviz_safe(key), label=label)

    @override
    def edge(self, from_node: str, to_node: str) -> None:
        self._graph.edge(self._graphviz_safe(from_node), self._graphviz_safe(to_node))

    @override
    def visualize(self, print_only: bool = False) -> None:
        with tempfile.NamedTemporaryFile() as f:
            _ = self._graph.render(filename=f.name, view=not print_only, cleanup=False)
            if print_only:
                print(f.read().decode())

    def _graphviz_safe(self, s: str) -> str:
        return s.replace(":", "/")
