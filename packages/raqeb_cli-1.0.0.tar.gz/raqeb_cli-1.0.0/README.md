# Raqeb CLI

Command-line tool for **Raqeb Privileged Access Management (PAM)** platform.

## Features

- 🔐 **Database PAM**: Get temporary database credentials
- 🔑 **Secrets Management**: Securely retrieve secrets
- 🚀 **Service Accounts**: Programmatic API access
- 📊 **Audit Logs**: Track all access activities
- 🔒 **Zero Trust**: Dynamic credentials with auto-expiration

## Installation

```bash
pip install raqeb-cli
```

**Requirements:** Node.js 14+ (automatically installed via npm)

## Quick Start

```bash
# Login to Raqeb
raqeb login

# Get temporary database credentials
raqeb db connect <database-id> --ttl 2

# Retrieve a secret
raqeb secrets get <secret-name>

# View audit logs
raqeb audit list
```

## Documentation

Full documentation: https://docs.raqeb.cloud

## Support

- Website: https://raqeb.cloud
- Email: support@tzamun.sa
- GitHub: https://github.com/Tzamun-Arabia-IT-Co/raqeb-cli

## License

MIT License - Copyright (c) 2026 Tzamun Arabia IT Co
