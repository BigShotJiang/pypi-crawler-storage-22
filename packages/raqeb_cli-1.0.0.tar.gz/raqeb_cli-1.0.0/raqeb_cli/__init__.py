"""Raqeb CLI - Command-line tool for Database PAM and Developer Secrets Management."""

__version__ = "1.0.0"
__author__ = "Tzamun Arabia IT Co"
__email__ = "support@tzamun.sa"
