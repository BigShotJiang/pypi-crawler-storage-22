#!/usr/bin/env python3
"""
Raqeb CLI - Python wrapper for the Node.js CLI
This wrapper ensures Node.js CLI is installed and delegates all commands to it.
"""

import subprocess
import sys
import os
import shutil

def check_nodejs():
    """Check if Node.js is installed."""
    if not shutil.which('node'):
        print("Error: Node.js is required but not installed.")
        print("Please install Node.js from https://nodejs.org/")
        sys.exit(1)

def check_npm():
    """Check if npm is installed."""
    if not shutil.which('npm'):
        print("Error: npm is required but not installed.")
        print("Please install Node.js (includes npm) from https://nodejs.org/")
        sys.exit(1)

def install_raqeb_cli():
    """Install the actual raqeb-cli via npm if not already installed."""
    try:
        # Check if raqeb command exists
        result = subprocess.run(['which', 'raqeb'], capture_output=True)
        if result.returncode != 0:
            print("Installing raqeb-cli via npm...")
            subprocess.run(['npm', 'install', '-g', 'raqeb-cli'], check=True)
            print("✓ raqeb-cli installed successfully!")
    except subprocess.CalledProcessError as e:
        print(f"Error installing raqeb-cli: {e}")
        sys.exit(1)

def main():
    """Main entry point - delegates to Node.js CLI."""
    # Check prerequisites
    check_nodejs()
    check_npm()
    install_raqeb_cli()
    
    # Delegate to the actual raqeb CLI
    try:
        # Pass all arguments to the Node.js CLI
        result = subprocess.run(['raqeb'] + sys.argv[1:])
        sys.exit(result.returncode)
    except KeyboardInterrupt:
        print("\nInterrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"Error running raqeb: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
