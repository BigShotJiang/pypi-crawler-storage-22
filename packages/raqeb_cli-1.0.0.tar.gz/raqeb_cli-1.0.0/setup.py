from setuptools import setup, find_packages
import os

# Read README
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="raqeb-cli",
    version="1.0.0",
    author="Tzamun Arabia IT Co",
    author_email="support@tzamun.sa",
    description="Raqeb CLI - Command-line tool for Database PAM and Developer Secrets Management",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Tzamun-Arabia-IT-Co/raqeb-cli",
    project_urls={
        "Bug Tracker": "https://github.com/Tzamun-Arabia-IT-Co/raqeb-cli/issues",
        "Documentation": "https://docs.raqeb.cloud",
        "Homepage": "https://raqeb.cloud",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "Topic :: Security",
        "Topic :: System :: Systems Administration",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.28.0",
    ],
    entry_points={
        "console_scripts": [
            "raqeb=raqeb_cli.cli:main",
        ],
    },
    keywords="pam security secrets database credentials cli",
)
