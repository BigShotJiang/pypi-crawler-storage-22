import time
from typing import Tuple

from rate_limiter.core.algorithms.base import RateLimitAlgorithm
from rate_limiter.core.rules import RateLimitRule, Scope
from rate_limiter.core.storage.backend import StorageBackend


class TokenBucketAlgorithm:
    """Token bucket rate limiting algorithm."""

    async def allow(
        self,
        storage: StorageBackend,
        identity: str,
        rule: RateLimitRule,
        endpoint: str = "",
    ) -> Tuple[bool, int, int]:
        """
        Check if request should be allowed using token bucket.

        Args:
            storage: Storage backend
            identity: Request identity
            rule: Rate limit rule
            endpoint: Endpoint identifier

        Returns:
            Tuple of (allowed, remaining, retry_after)
        """
        # Create key based on scope
        # Include limit and window in key to ensure each rule has its own counter
        rule_id = f"{rule.limit}:{rule.window}"
        if rule.scope == Scope.GLOBAL:
            key = f"{rule.key}:{identity}:global:{rule_id}"
        elif rule.scope == Scope.ROUTER:
            key = f"{rule.key}:{identity}:router:{endpoint}:{rule_id}"
        else:  # endpoint
            key = f"{rule.key}:{identity}:endpoint:{endpoint}:{rule_id}"

        current_time = int(time.time())

        # Token bucket parameters
        # Capacity = limit (burst size)
        # Refill rate = limit / window (tokens per second)
        capacity = rule.limit
        refill_rate = rule.limit / rule.window

        # Use Lua script for atomic token bucket operations
        script = """
        local key = KEYS[1]
        local current_time = tonumber(ARGV[1])
        local capacity = tonumber(ARGV[2])
        local refill_rate = tonumber(ARGV[3])
        local ttl = tonumber(ARGV[4])

        local bucket = redis.call('HMGET', key, 'tokens', 'last_refill')
        local tokens = tonumber(bucket[1]) or capacity
        local last_refill = tonumber(bucket[2]) or current_time

        -- Refill tokens based on time elapsed
        local time_elapsed = current_time - last_refill
        local tokens_to_add = math.floor(time_elapsed * refill_rate)
        tokens = math.min(capacity, tokens + tokens_to_add)
        last_refill = current_time

        -- Check if we have tokens
        if tokens >= 1 then
            tokens = tokens - 1
            redis.call('HMSET', key, 'tokens', tokens, 'last_refill', last_refill)
            redis.call('EXPIRE', key, ttl)
            local retry_after = 0
            if tokens < 1 then
                retry_after = math.ceil((1 - tokens) / refill_rate)
            end
            return {1, math.floor(tokens), retry_after}
        else
            -- Calculate retry_after
            local retry_after = math.ceil((1 - tokens) / refill_rate)
            redis.call('HMSET', key, 'tokens', tokens, 'last_refill', last_refill)
            redis.call('EXPIRE', key, ttl)
            return {0, 0, retry_after}
        end
        """

        try:
            result = await storage.execute_script(
                script,
                keys=[key],
                args=[current_time, capacity, refill_rate, rule.window],
            )

            if isinstance(result, list) and len(result) >= 3:
                allowed = bool(result[0])
                remaining = int(result[1])
                retry_after = max(0, int(result[2]))
            else:
                # Fallback to simple counter
                return await self._fallback_allow(storage, key, rule, current_time)
        except Exception:
            # Fallback to simple counter
            return await self._fallback_allow(storage, key, rule, current_time)

        return allowed, remaining, retry_after

    async def _fallback_allow(
        self,
        storage: StorageBackend,
        key: str,
        rule: RateLimitRule,
        current_time: int,
    ) -> Tuple[bool, int, int]:
        """Fallback to simple counter-based approach."""
        window_key = f"{key}:window:{current_time // rule.window}"
        count = await storage.incr(window_key, rule.window)
        allowed = count <= rule.limit
        remaining = max(0, rule.limit - count)
        retry_after = rule.window - (current_time % rule.window)
        return allowed, remaining, retry_after
