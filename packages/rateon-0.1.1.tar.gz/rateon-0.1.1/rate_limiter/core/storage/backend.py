from typing import Any, Protocol


class StorageBackend(Protocol):
    """Protocol for storage backends."""

    async def incr(self, key: str, ttl: int) -> int:
        """
        Increment counter and return new value.

        Args:
            key: Storage key
            ttl: Time to live in seconds

        Returns:
            New counter value
        """
        ...

    async def get(self, key: str) -> int:
        """
        Get current counter value.

        Args:
            key: Storage key

        Returns:
            Current counter value (0 if key doesn't exist)
        """
        ...

    async def set(self, key: str, value: int, ttl: int) -> None:
        """
        Set counter value.

        Args:
            key: Storage key
            value: Counter value
            ttl: Time to live in seconds
        """
        ...

    async def delete(self, key: str) -> None:
        """
        Delete a key.

        Args:
            key: Storage key
        """
        ...

    async def exists(self, key: str) -> bool:
        """
        Check if key exists.

        Args:
            key: Storage key

        Returns:
            True if key exists, False otherwise
        """
        ...

    async def ttl(self, key: str) -> int:
        """
        Get remaining TTL for a key.

        Args:
            key: Storage key

        Returns:
            Remaining TTL in seconds (-1 if key doesn't exist, -2 if no expiry)
        """
        ...

    async def close(self) -> None:
        """Close backend connection."""
        ...

    async def execute_script(
        self, script: str, keys: list[str], args: list[Any]
    ) -> Any:
        """
        Execute Lua script (for Redis).

        Args:
            script: Lua script content
            keys: List of keys
            args: List of arguments

        Returns:
            Script execution result
        """
        ...
