from typing import Optional


class RateLimitExceeded(Exception):
    """Raised when a rate limit is exceeded."""

    def __init__(
        self,
        retry_after: int,
        limit: int,
        window: int,
        message: Optional[str] = None,
    ):
        """
        Initialize rate limit exceeded exception.

        Args:
            retry_after: Seconds until the rate limit resets
            limit: The rate limit that was exceeded
            window: The time window in seconds
            message: Optional custom error message
        """
        self.retry_after = retry_after
        self.limit = limit
        self.window = window
        self.message = message or f"Rate limit exceeded: {limit} requests per {window} seconds"
        super().__init__(self.message)

    def __repr__(self) -> str:
        return (
            f"RateLimitExceeded(retry_after={self.retry_after}, "
            f"limit={self.limit}, window={self.window})"
        )


class RateLimiterError(Exception):
    """Base exception for rate limiter errors."""

    pass


class StorageBackendError(RateLimiterError):
    """Raised when storage backend operations fail."""

    pass


class ConfigurationError(RateLimiterError):
    """Raised when configuration is invalid."""

    pass
