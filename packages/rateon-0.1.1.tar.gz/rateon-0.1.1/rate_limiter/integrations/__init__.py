"""Framework integrations."""
