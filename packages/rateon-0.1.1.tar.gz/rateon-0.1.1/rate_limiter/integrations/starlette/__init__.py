"""Starlette integrations."""

from rate_limiter.integrations.starlette.middleware import RateLimiterMiddleware

__all__ = ["RateLimiterMiddleware"]
