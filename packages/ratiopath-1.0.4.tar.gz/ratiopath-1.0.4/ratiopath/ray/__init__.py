from ratiopath.ray.read_slides import read_slides


__all__ = ["read_slides"]
