from __future__ import annotations
from typing import Optional
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def abline(
model=None,
a: Optional[float] = None,
b: Optional[float] = None,
color: str = "black",
linetype: str = "-",
linewidth: float = 1.5,
label: Optional[str] = None,
ax: Optional[plt.Axes] = None,
**kwargs,
):
    """
    Add a regression line to an existing plot (R-style layering).

    This function overlays a fitted regression line onto the current axes,
    enabling layered plot construction similar to base R's abline().

    Parameters
    ----------
    model : fitted model object, optional
        Ravix model with predict() method
    a : float, optional
        Intercept (used when b is also provided, overrides model)
    b : float, optional
        Slope (used when a is also provided, overrides model)
    color : str, default="black"
        Line color
    linetype : str, default="-"
        Matplotlib linestyle ("-", "--", "-.", ":")
    linewidth : float, default=1.5
        Line width
    label : Optional[str], default=None
        Legend label for this line
    ax : Optional[plt.Axes], default=None
        Target axes; if None, uses plt.gca()
    **kwargs
        Additional matplotlib line styling options

    Returns
    -------
    matplotlib.lines.Line2D
        The plotted line object (for legend assembly)

    Notes
    -----
    - Designed for layering on top of ravix plot()
    - Does NOT control rendering
    - Figure display handled by plot() or user (plt.show())
    """

    # ======================================================================
    # Get target axes
    # ======================================================================
    if ax is None:
        ax = plt.gca()

    # ======================================================================
    # CASE 1: Direct a, b specification (y = a + b*x)
    # ======================================================================
    if a is not None and b is not None:
        intercept = float(a)
        slope = float(b)

        x_vals = np.array(ax.get_xlim())
        y_vals = intercept + slope * x_vals

        line = ax.plot(
            x_vals,
            y_vals,
            color=color,
            linestyle=linetype,
            linewidth=linewidth,
            label=label,
            **kwargs
        )[0]

        return line

    # ======================================================================
    # CASE 2: Ravix model → use predict()
    # ======================================================================
    if model is not None:
        # Try to get x variable name from axes metadata or model formula
        if hasattr(ax, "_ravix_x_var"):
            x_var_name = ax._ravix_x_var
        elif hasattr(model, 'formula'):
            # Extract x variable from formula (e.g., "y ~ x" -> "x")
            formula = str(model.formula)
            if '~' in formula:
                x_var_name = formula.split('~')[1].strip()
            else:
                raise ValueError(
                    "Cannot determine X variable name from model formula. "
                    f"Model formula: {formula}"
                )
        else:
            raise ValueError(
                "Cannot determine X variable name. "
                "Make sure you plotted with ravix plot() before calling abline(), "
                "or ensure your model has a 'formula' attribute."
            )

        # Try to get x range from model data first, fall back to axes limits
        x_min, x_max = None, None
        
        # Try to extract from model's training data
        if hasattr(model, 'model') and hasattr(model.model, 'data'):
            try:
                if hasattr(model.model.data, 'frame'):
                    # statsmodels-style
                    frame = model.model.data.frame
                    if x_var_name in frame.columns:
                        x_vals_model = frame[x_var_name]
                        x_min, x_max = float(x_vals_model.min()), float(x_vals_model.max())
            except:
                pass
        
        # Try direct data attribute
        if x_min is None and hasattr(model, 'data'):
            try:
                if isinstance(model.data, pd.DataFrame) and x_var_name in model.data.columns:
                    x_vals_model = model.data[x_var_name]
                    x_min, x_max = float(x_vals_model.min()), float(x_vals_model.max())
            except:
                pass
        
        # Fall back to extracting from axes scatter data
        if x_min is None:
            x_data = _extract_scatter_x_data(ax)
            if x_data:
                x_min, x_max = min(x_data), max(x_data)
        
        # Final fallback: use axes limits
        if x_min is None:
            x_min, x_max = ax.get_xlim()
        x_vals = np.linspace(x_min, x_max, 200)

        X_pred = pd.DataFrame({x_var_name: x_vals})

        try:
            from ravix.modeling.predict import predict
            Y_pred = predict(model, X_pred)
        except Exception as e:
            raise ValueError(
                f"Could not generate predictions from model: {e}\n"
                f"Model formula: {getattr(model, 'formula', 'unknown')}"
            )

        line = ax.plot(
            x_vals,
            np.asarray(Y_pred).ravel(),
            color=color,
            linestyle=linetype,
            linewidth=linewidth,
            label=label,
            **kwargs
        )[0]

        return line

    # ======================================================================
    # CASE 3: No arguments → fit OLS to scatter data
    # ======================================================================
        x_data, y_data = _extract_scatter_data(ax)

    if not x_data:
        raise ValueError(
            "Cannot fit regression line: no scatter data found in current axes.\n"
            "Make sure you called plot() with show=False before calling abline():\n"
            "  fig, ax = plot('Y ~ X', data=df, show=False)\n"
            "  abline()  # auto-fits to scatter data\n"
            "  plt.show()"
        )

    x_arr = np.array(x_data)
    y_arr = np.array(y_data)

    slope, intercept = np.polyfit(x_arr, y_arr, 1)

    x_min, x_max = min(x_data), max(x_data)
    x_vals = np.linspace(x_min, x_max, 200)
    y_vals = intercept + slope * x_vals

    line = ax.plot(
        x_vals,
        y_vals,
        color=color,
        linestyle=linetype,
        linewidth=linewidth,
        label=label,
        **kwargs
    )[0]

    return line


# ======================================================================
# Helper functions
# ======================================================================

def _extract_scatter_x_data(ax: plt.Axes) -> list:
    """Extract x-coordinates from scatter plot collections and line objects."""
    x_data = []
    
    # Try scatter collections first
    for coll in ax.collections:
        offsets = coll.get_offsets()
        if len(offsets) > 0:
            x_data.extend(offsets[:, 0])
    
    # If no scatter data, try line objects
    if not x_data:
        for line in ax.get_lines():
            xdata = line.get_xdata()
            if len(xdata) > 0:
                x_data.extend(xdata)
    
    return x_data


def _extract_scatter_data(ax: plt.Axes) -> tuple[list, list]:
    """Extract x and y coordinates from scatter plot collections and line objects."""
    x_data, y_data = [], []
    
    # Try scatter collections first
    for coll in ax.collections:
        offsets = coll.get_offsets()
        if len(offsets) > 0:
            x_data.extend(offsets[:, 0])
            y_data.extend(offsets[:, 1])
    
    # If no scatter data, try line objects
    if not x_data:
        for line in ax.get_lines():
            xdata = line.get_xdata()
            ydata = line.get_ydata()
            if len(xdata) > 0:
                x_data.extend(xdata)
                y_data.extend(ydata)
    
    return x_data, y_data
