import { Bench } from 'tinybench'

import { plus100 } from '../index.js'

function add(a: number) {
  return a + 100
}

const b = new Bench()

b.add('Native a + 100', () => {
  plus100(10)
})

b.add('JavaScript a + 100', () => {
  add(10)
})

await b.run()

console.table(b.table())
