#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from packaging import version
import platform
import tempfile
from typing import Any, Dict, List, NoReturn, Optional, Union

import tensorflow as tf
import tensorflow.keras as keras
from tensorflow.keras.callbacks import Callback

import ray
from ray.air import session
from ray.air.config import ScalingConfig, RunConfig, FailureConfig
from ray.train import Checkpoint
from ray.train.tensorflow import TensorflowCheckpoint, TensorflowTrainer
from ray.data.dataset import Dataset
from ray.data.preprocessors import Concatenator

from raydp.estimator import EstimatorInterface
from raydp.spark import get_raydp_master_owner, spark_dataframe_to_ray_dataset
from raydp.spark.dataset import read_spark_parquet
from raydp.spark.interfaces import SparkEstimatorInterface, DF, OPTIONAL_DF
from raydp import stop_spark

class TFEstimator(EstimatorInterface, SparkEstimatorInterface):
    def __init__(self,
                 num_workers: int = 1,
                 resources_per_worker: Optional[Dict[str, float]] = None,
                 model: keras.Model = None,
                 optimizer: Union[keras.optimizers.Optimizer, str] = None,
                 loss: Union[keras.losses.Loss, str] = None,
                 metrics: Union[List[keras.metrics.Metric], List[str]] = None,
                 feature_columns: Union[str, List[str]] = None,
                 label_columns: Union[str, List[str]] = None,
                 merge_feature_columns: bool = False,
                 batch_size: int = 128,
                 drop_last: bool = False,
                 num_epochs: int = 1,
                 shuffle: bool = True,
                 callbacks: Optional[List[Callback]] = None,
                 **extra_config):
        """A scikit-learn like API to distributed training Tensorflow Keras model.

        In the backend it leverage the ray.train.tensorflow.TensorflowTrainer.
        :param num_workers: the number of workers for distributed model training
        :param resources_per_worker: the resources defined in this Dict will be reserved for
               each worker. The ``CPU`` and ``GPU`` keys (case-sensitive) can be defined to
               override the number of CPU/GPUs used by each worker.
        :param model: the model, it should be instance of tensorflow.keras.Model. We do not support
                      multiple output models.
        :param optimizer: the optimizer, it should be keras.optimizers.Optimizer instance or str.
                          We do not support multiple optimizers currently.
        :param loss: the loss, it should be keras.losses.Loss instance or str. We do not support
                     multiple losses.
        :param metrics: the metrics list. It could be None, a list of keras.metrics.Metric instance
                        or a list of str.
        :param feature_columns: the feature columns name.
               The inputs of the model will be match the feature columns.
               .. code-block:: python
                   feature_columns = ["x", "y", "z"]
                   # the input to the model will be (x_batch_tensor, y_batch_tensor, z_batch_tensor)
        :param feature_types: the type for each feature input. It must match the length of the
                              feature_columns if provided. It will be tf.float32 by default.
        :param feature_shapes: the shape for each feature input. It must match the length of the
                               feature_columns
        :param label_column: the label column name.
        :param label_type: the label type, it will be tf.float32 by default.
        :param label_shape: the label shape.
        :param batch_size: the batch size
        :param num_epochs: the number of epochs
        :param shuffle: whether input dataset should be shuffle, True by default.
        :param callbacks: which will be executed during training.
        :param extra_config: extra config will fit into Trainer.
        """
        self._num_workers: int = num_workers
        self._resources_per_worker = resources_per_worker
        # model
        assert model is not None, "model must be not be None"
        if isinstance(model, keras.Model):
            self._serialized_model = model.to_json()
        else:
            raise Exception("Unsupported parameter, we only support tensorflow.keras.Model")

        # optimizer
        # TODO: we should support multiple optimizers for multiple outputs model
        assert optimizer is not None, "optimizer must not be None"
        if isinstance(optimizer, str):
            # it is a str represents the optimizer
            _optimizer = optimizer
        elif isinstance(optimizer, keras.optimizers.Optimizer):
            # On Apple Silicon (arm64) Macs, Keras may fall back to legacy optimizers for
            # performance reasons. Ensure we serialize a legacy optimizer config up-front so
            # deserialization doesn't trip over newer fields like "weight_decay".
            if platform.system() == "Darwin" and platform.processor() == "arm":
                from keras.src.optimizers import convert_to_legacy_optimizer  # pylint: disable=import-outside-toplevel

                legacy_optimizer = convert_to_legacy_optimizer(optimizer)
                _optimizer = keras.optimizers.serialize(legacy_optimizer)
            else:
                _optimizer = keras.optimizers.serialize(optimizer)
        else:
            raise Exception(
                "Unsupported parameter, we only support keras.optimizers.Optimizer subclass "
                "instance or a str to represent the optimizer")
        self._serialized_optimizer = _optimizer

        # loss
        # TODO: we should support multiple losses for multiple outputs model
        assert loss is not None, "loss must not be None"
        if isinstance(loss, str):
            _loss = loss
        elif isinstance(loss, keras.losses.Loss):
            _loss = keras.losses.serialize(loss)
        else:
            raise Exception(
                "Unsupported parameter, we only support keras.losses.Loss subclass "
                "instance or a str to represents the loss")
        self._serialized_loss = _loss

        # metrics
        if metrics is None:
            _metrics = None
        else:
            assert isinstance(metrics, list), "metrics must be a list"
            if isinstance(metrics[0], str):
                _metrics = metrics
            elif isinstance(metrics[0], keras.metrics.Metric):
                _metrics = [keras.metrics.serialize(m) for m in metrics]
            else:
                raise Exception(
                    "Unsupported parameter, we only support list of keras.metrics.Metrics "
                    "instances or list of str to represents the metrics")
        self._serialized_metrics = _metrics

        self._feature_columns = feature_columns
        self._label_columns = label_columns
        self._merge_feature_columns = merge_feature_columns
        self._batch_size = batch_size
        self._drop_last = drop_last
        self._num_epochs = num_epochs
        self._shuffle = shuffle
        self._callbacks = callbacks
        self._extra_config = extra_config
        self._trainer: TensorflowTrainer = None

    @staticmethod
    def build_and_compile_model(config):
        model: keras.Model = keras.models.model_from_json(config["model"])
        optimizer = keras.optimizers.get(config["optimizer"])
        loss = keras.losses.get(config["loss"])
        metrics = [keras.metrics.get(m) for m in config["metrics"]]
        model.compile(optimizer=optimizer, loss=loss, metrics=metrics)
        return model

    @staticmethod
    def train_func(config):
        strategy = tf.distribute.MultiWorkerMirroredStrategy()
        with strategy.scope():
            # Model building/compiling need to be within `strategy.scope()`.
            multi_worker_model = TFEstimator.build_and_compile_model(config)

        train_dataset = session.get_dataset_shard("train")
        train_tf_dataset = train_dataset.to_tf(
            feature_columns=config["feature_columns"],
            label_columns=config["label_columns"],
            batch_size=config["batch_size"],
            drop_last=config["drop_last"]
        )
        if config["evaluate"]:
            eval_dataset = session.get_dataset_shard("evaluate")
            eval_tf_dataset = eval_dataset.to_tf(
                feature_columns=config["feature_columns"],
                label_columns=config["label_columns"],
                batch_size=config["batch_size"],
                drop_last=config["drop_last"]
            )
        results = []
        callbacks = config["callbacks"]
        for _ in range(config["num_epochs"]):
            train_history = multi_worker_model.fit(train_tf_dataset, callbacks=callbacks)
            results.append(train_history.history)
            if config["evaluate"]:
                test_history = multi_worker_model.evaluate(eval_tf_dataset, callbacks=callbacks)
                results.append(test_history)

        # Only save checkpoint from the chief worker to avoid race conditions.
        # However, we need to call save on all workers to avoid deadlock.
        with tempfile.TemporaryDirectory() as temp_checkpoint_dir:
            multi_worker_model.save(temp_checkpoint_dir, save_format="tf")
            checkpoint = None
            if session.get_world_rank() == 0:
                checkpoint = Checkpoint.from_directory(temp_checkpoint_dir)

            session.report({}, checkpoint=checkpoint)

    def fit(self,
            train_ds: Dataset,
            evaluate_ds: Optional[Dataset] = None,
            max_retries=0) -> NoReturn:
        # super().fit(train_ds, evaluate_ds)
        train_loop_config = {
            "model": self._serialized_model,
            "optimizer": self._serialized_optimizer,
            "loss": self._serialized_loss,
            "feature_columns": self._feature_columns,
            "label_columns": self._label_columns,
            "batch_size": self._batch_size,
            "drop_last": self._drop_last,
            "num_epochs": self._num_epochs,
            "evaluate": False,
            "metrics": self._serialized_metrics,
            "callbacks": self._callbacks
        }
        scaling_config = ScalingConfig(num_workers=self._num_workers,
                                       resources_per_worker=self._resources_per_worker)
        run_config = RunConfig(failure_config=FailureConfig(max_failures=max_retries))
        if self._shuffle:
            train_ds = train_ds.random_shuffle()
            if evaluate_ds:
                evaluate_ds = evaluate_ds.random_shuffle()
        preprocessor = None
        if self._merge_feature_columns:
            if isinstance(self._feature_columns, list):
                if len(self._feature_columns) > 1:
                    label_cols = self._label_columns
                    if not isinstance(label_cols, list):
                        label_cols = [label_cols]
                    # pylint: disable=E1123,E1120
                    if version.parse(ray.__version__) >= version.parse("2.39.0"):
                        preprocessor = Concatenator(
                            columns=[col for col in self._feature_columns if col not in label_cols],
                            output_column_name="features",
                        )
                    else:
                        preprocessor = Concatenator(
                            exclude=label_cols,
                            output_column_name="features",
                        )
                    train_loop_config["feature_columns"] = "features"
                    train_ds = preprocessor.transform(train_ds)
                    if evaluate_ds is not None:
                        evaluate_ds = preprocessor.transform(evaluate_ds)
                else:
                    train_loop_config["feature_columns"] = self._feature_columns[0]
        datasets = {"train": train_ds}
        if evaluate_ds is not None:
            train_loop_config["evaluate"] = True
            datasets["evaluate"] = evaluate_ds
        self._trainer = TensorflowTrainer(TFEstimator.train_func,
                                          train_loop_config=train_loop_config,
                                          scaling_config=scaling_config,
                                          run_config=run_config,
                                          datasets=datasets)
        self._results = self._trainer.fit()

    def fit_on_spark(self,
                     train_df: DF,
                     evaluate_df: OPTIONAL_DF = None,
                     fs_directory: Optional[str] = None,
                     compression: Optional[str] = None,
                     max_retries=3,
                     stop_spark_after_conversion=False) -> NoReturn:
        super().fit_on_spark(train_df, evaluate_df)
        train_df = self._check_and_convert(train_df)
        evaluate_ds = None
        if fs_directory is not None:
            app_id = train_df.sql_ctx.sparkSession.sparkContext.applicationId
            path = fs_directory.rstrip("/") + f"/{app_id}"
            train_df.write.parquet(path+"/train", compression=compression)
            train_ds = read_spark_parquet(path+"/train")
            if evaluate_df is not None:
                evaluate_df = self._check_and_convert(evaluate_df)
                evaluate_df.write.parquet(path+"/test", compression=compression)
                evaluate_ds = read_spark_parquet(path+"/test")
        else:
            owner = None
            if stop_spark_after_conversion:
                owner = get_raydp_master_owner(train_df.sql_ctx.sparkSession)
            train_ds = spark_dataframe_to_ray_dataset(train_df,
                                                    owner=owner)
            if evaluate_df is not None:
                evaluate_df = self._check_and_convert(evaluate_df)
                evaluate_ds = spark_dataframe_to_ray_dataset(evaluate_df,
                                                         owner=owner)
        if stop_spark_after_conversion:
            stop_spark(cleanup_data=False)
        return self.fit(
            train_ds, evaluate_ds, max_retries)

    def get_model(self) -> Any:
        assert self._trainer, "Trainer has not been created"
        return TensorflowCheckpoint.from_saved_model(
                self._results.checkpoint.to_directory()
            ).get_model()
