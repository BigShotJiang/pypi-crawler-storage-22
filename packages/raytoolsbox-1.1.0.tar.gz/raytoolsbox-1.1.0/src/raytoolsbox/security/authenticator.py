import time,json,os,stat,keyring,pyotp,qrcode
class Authenticator:
    """
    基于 RFC 6238 的 TOTP 验证器。
    功能：
    - 生成及验证 TOTP（基于时间的一次性验证码）
    - 使用系统安全存储（keyring）保存密钥，文件存储作为兜底
    - 支持首次绑定流程（先生成 secret，验证成功后再保存）
    - 支持终端展示绑定二维码（ASCII）
    
    说明：
    TOTP 本质上需要一个“secret 秘钥”来生成验证码。
    此类负责安全地保存 secret，并提供验证与绑定机制。
    """

    def __init__(self, service_name: str="", account: str = ""):
        """
        初始化 Authenticator 对象。
        - service_name：你的应用名称，如 "testApp"
        - account：区分不同账户的标识（多个账号时很重要）
        """
        self.service_name = service_name
        self.account = account
        self._key = f"totp_secret:{account}"

        # 文件存储路径，例如 ~/.raypassapp_user1_totp
        self._file_path = os.path.expanduser(
            f"~/.{service_name.lower()}_{account}_totp"
        )

        # 临时 secret（仅在 get_secret → verify_and_bind 期间使用）
        self._pending_secret = None


        try:
            self._load_secret()
            self._if_bind = True
            print("✅ 已存在绑定的 Authenticator。")

        except RuntimeError:
            self._if_bind = False
            print("🔐 未绑定，请使用 .get_secret()初始化...")

    def exist(self):
        return self._if_bind
    # ============================================================
    #                     绑定 / 初始化（不立即保存）
    # ============================================================
    def get_secret(self):
        """
        生成新的 TOTP secret，但不立即永久保存。

        功能：
        - 账户尚未绑定时，调用此方法会生成一个新的临时密钥（secret）。
          需配合 verify() 输入首次验证码验证成功后永久保存。

        返回：
        - dict: 包含以下键值：
            - "uri"：TOTP 绑定用的 otpauth URI，可用于生成二维码。
            - "secret"：此次生成的临时密钥。
          如果当前账户已绑定，则返回错误说明字符串。
        """
        if not self._if_bind:
            # 随机生成 TOTP 的 Base32 秘钥
            self._pending_secret = pyotp.random_base32()

            print("🔐 正在生成 Authenticator 绑定信息...")

            # 根据 secret 生成 provisioning URI（用于二维码扫描）
            totp = pyotp.TOTP(self._pending_secret)
            uri = totp.provisioning_uri(
                name=self.account,         # 在 Authenticator 中显示的账户名
                issuer_name=self.service_name,  # 在 Authenticator 中显示的服务名
            )

            # 生成二维码（控制二维码大小）
            qr = qrcode.QRCode(
                version=2,       # 固定中等大小，避免过大
                error_correction=qrcode.constants.ERROR_CORRECT_Q,
                box_size=1,
                border=0
            )
            qr.add_data(uri)
            qr.make(fit=True)

            print("\n📱 请使用 Authenticator 扫描下面二维码：\n")
            qr.print_ascii(invert=True)   # 终端 ASCII QR 显示
            print()
            print("📌 请扫描二维码后，输入首次验证码完成绑定。")

            return {"uri": uri, "secret": self._pending_secret}
        else:
            msg="已存在对应账户和应用的Authenticator,请先删除"
            print(msg)
            return msg
        
    # ============================================================
    #                     删除现有绑定（解绑）
    # ============================================================

    def delete(self) -> bool:
        """
        删除当前账户的 TOTP 绑定。

        返回：
        - True：至少有一个存储被删除
        - False：两个地方都没有数据（或删除失败）
        """
        removed = False
        try:
            stored = keyring.get_password(self.service_name, self._key)
            if stored is not None:
                keyring.delete_password(self.service_name, self._key)
                removed = True
        except Exception:
            pass
        # 尝试删除文件存储
        if os.path.exists(self._file_path):
            try:
                os.remove(self._file_path)
                removed = True
            except Exception:
                pass
        self._if_bind = False
        return removed
    
    # ============================================================
    #                     验证验证码
    # ============================================================

    def verify(self, code: str, window: int = 1) -> bool:
        """
        验证已绑定账户的 TOTP 验证码。
        
        参数：
        - code: 用户输入的 6 位数字字符串
        - window: 时间容差（默认 1）
            window=0：只接受当前30秒（最严格）
            window=1：接受前/当前/后 共 90 秒（推荐，防手机时间误差）

        返回：
        - True  验证成功
        - False 验证失败
        """
        
        if self._if_bind:
            totp = pyotp.TOTP(self._load_secret())          # 根据存储密钥，创建 TOTP 验证器
            return totp.verify(code, valid_window=window)   # 验证输入的验证码
        else:
            if not self._pending_secret:
                raise RuntimeError("当前没有待绑定的 secret，请先执行 get_secret()")

            totp = pyotp.TOTP(self._pending_secret)

            # 验证用户输入的验证码
            if totp.verify(code, valid_window=window):
                # 构建保存的数据
                data = {
                    "secret": self._pending_secret,
                    "created": int(time.time()),
                }

                # 优先写入系统安全存储
                if not self._save_keyring(data):
                    # keyring 不可用则回退到文件存储
                    self._save_file(data)
                self._if_bind = True
                print("🎉 首次验证成功，Authenticator 绑定完成。")

                # 清空临时 secret
                self._pending_secret = None
                return True
            else:
                print("❌ 验证失败请重试。")
                return False
    

    # ============================================================
    #                     存储层
    # ============================================================

    def _save_keyring(self, data: dict) -> bool:
        """
        尝试将 secret 保存到系统安全存储（keyring）
        写入失败返回 False。
        """
        try:
            keyring.set_password(self.service_name, self._key, json.dumps(data))
            return True
        except Exception:
            return False

    def _load_secret(self) -> str:
        """
        加载已绑定的 secret。
        优先从 keyring 获取。
        如果 keyring 不可用，则回退读取文件。
        如果都不存在 → 表示尚未绑定。
        """
        # 尝试从 keyring 获取
        try:
            stored = keyring.get_password(self.service_name, self._key)
            if stored:
                return json.loads(stored)["secret"]
        except Exception:
            pass

        # 回退：文件存储
        if os.path.exists(self._file_path):
            with open(self._file_path, "r") as f:
                return json.load(f)["secret"]

        raise RuntimeError("Authenticator 尚未绑定")

    def _save_file(self, data: dict):
        """
        将 secret 写入文件（兜底方案）。
        写入后将文件权限设置为 600（仅当前用户可读写）。
        """
        with open(self._file_path, "w") as f:
            json.dump(data, f)

        try:
            os.chmod(self._file_path, stat.S_IRUSR | stat.S_IWUSR)
        except Exception:
            pass


if __name__ == "__main__":
         
    SERVICE = "RayPassApp"
    ACCOUNT = "user1"

    auth = Authenticator(SERVICE, ACCOUNT)
    # auth.delete()
    if not auth.exist():
        auth.get_secret()
    print("=== Authenticator Demo ===")
    # 测试绑定成功
    user_input = input("请输入验证码：").strip()
    print("✅ 验证成功" if auth.verify(user_input) else "❌ 验证失败")