"""
===============================================
📦 raytoolsbox.utils.common_tools
常用辅助函数模块
-----------------------------------------------
功能包含：
- 获取资源路径（兼容 PyInstaller）
- Tk 窗口居中显示
- 简易性能计时器 make_timer()
- 获取指定 GitHub 用户的仓库列表
===============================================
"""

import os,sys,time,requests
from pathlib import Path
# ============================================================
#                  计时器工具
# ============================================================
def make_timer():
    """
    创建一个简单的性能计时函数。

    功能：
    - 返回一个内部函数，可多次调用自动计算时间间隔。
    - 输出调用次数与耗时（毫秒）。

    返回：
    - callable: 内部计时函数 tt(msg)。
      调用格式：
        tt("说明文字") → 打印上次调用到当前的耗时。
    """
    last_time = None
    count = -1

    def tt(msg: str = "") -> str:
        nonlocal last_time, count
        now = time.time()
        count += 1
        if last_time is None:
            msg_time = f"第{count}次调用（{msg}）：首次调用，无上次时间参考。"
            print(msg_time)
        else:
            elapsed = (now - last_time) * 1000  # 毫秒
            msg_time = (
                f"第{count}次调用（{msg}）：用时 {elapsed:.2f} ms"
                if msg
                else f"第{count}次调用：用时 {elapsed:.2f} ms"
            )
            print(msg_time)
        last_time = now
        return msg_time

    return tt


# ============================================================
#                  路径工具函数
# ============================================================
def get_resource_path(relpath: str) -> str:
    """
    修正资源路径（兼容 PyInstaller 打包运行环境）。

    功能：
    - 判断程序是否由 PyInstaller 打包。
    - 自动切换资源访问路径：打包环境使用 sys._MEIPASS。

    参数：
    - relpath (str): 相对路径字符串。

    返回：
    - str: 绝对资源路径。
    """
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, relpath)
    return os.path.join(os.path.dirname(__file__), relpath)


# ============================================================
#                  Tk 窗口居中
# ============================================================
def center_window(win, width: int | None = None, height: int | None = None):
    """
    将 Tkinter 窗口居中显示。

    参数：
    - win: Tkinter 窗口或 Toplevel 对象。
    - width: 目标宽度（可选，默认当前窗口宽度）。
    - height: 目标高度（可选，默认当前窗口高度）。

    返回：
    - None（直接更新窗口位置）
    """
    win.update_idletasks()
    w = width or win.winfo_width()
    h = height or win.winfo_height()
    sw = win.winfo_screenwidth()
    sh = win.winfo_screenheight()
    x = (sw - w) // 2
    y = (sh - h) // 3
    win.geometry(f"{w}x{h}+{x}+{y}")



# ============================================================
#                  GitHub API 工具
# ============================================================
def list_github_repos(username: str, token: str | None = None, print_result: bool = True):
    """
    获取指定 GitHub 用户的仓库列表。

    功能：
    - 支持传入个人访问 Token（可访问私有仓库）。
    - 支持分页抓取所有仓库（最大 100 每页）。

    参数：
    - username: GitHub 用户名。
    - token: 个人访问令牌（str 或 None）。
      如果 token 不为空且用户名为自己，则访问 /user/repos。
    - print_result: 是否打印获取结果（默认 True）。

    返回：
    - list[dict]: 仓库列表，每个元素结构：
        {
            "name": 仓库名称,
            "size_mb": 仓库大小（MB),
            "private": 是否私有仓库 (bool)
        }
      如果 Token 无效返回 None。
    """
    # 选择 API URL
    if token and username:
        api_url = "https://api.github.com/user/repos"
    else:
        api_url = f"https://api.github.com/users/{username}/repos"

    headers = {"Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"token {token}"

    repos = []
    page = 1

    while True:
        resp = requests.get(api_url, headers=headers, params={"page": page, "per_page": 100})

        # Token 错误处理
        if resp.status_code == 401:
            print("❌ GitHub Token 无效（Bad credentials），请检查：")
            print("   1. Token 是否拼写正确")
            print("   2. Token 是否过期")
            print("   3. 若只访问公开仓库，请不要传入 Token")
            return None

        if resp.status_code != 200:
            raise RuntimeError(f"GitHub API 请求失败：{resp.status_code}\n{resp.text}")

        batch = resp.json()
        if not batch:
            break

        for r in batch:
            repos.append({
                "name": r["name"],
                "size_mb": r["size"] / 1024,
                "private": r["private"],
            })

        page += 1

    if print_result:
        for r in repos:
            print(f"{r['name']:25} {r['size_mb']:7.2f} MB  {'private' if r['private'] else 'public'}")

    return repos


# ========================== 测试入口 ===========================
if __name__ == "__main__":
    tt = make_timer()
    tt("计时器初始化")
    user = "2dust"
    tt("开始抓取 GitHub 仓库")
    data = list_github_repos(user)
    tt("任务完成")
    print(f"共获取到 {len(data)} 个仓库。")