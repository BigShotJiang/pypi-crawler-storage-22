import os,base64,hashlib,keyring  # 操作系统安全存储
import json

class PinManager:
    """
    PIN 管理器
    
    功能：
    - 生成和验证 PIN 码
    - 使用操作系统安全存储 (keyring) 保存哈希
    - 支持修改 PIN 码
    """

    def __init__(self, service_name):
        """
        初始化 PIN 管理器
        
        参数：
            service_name: 服务名称，用于区分不同的应用程序
        """
        self.service_name = service_name

    # ============================================================
    #                     PIN 生成 / 保存
    # ============================================================
    def set_pin(self, pin: str, iterations: int = 200_000):
        """
        生成新的 PIN 哈希并保存到系统安全存储
        
        参数：
            pin: 要设置的 PIN 码
            iterations: PBKDF2 迭代次数，默认 200,000
        
        返回：
            dict: 包含 salt、hash 和 iterations 的数据字典
        """
        salt = os.urandom(16)
        hash_bytes = hashlib.pbkdf2_hmac(
            "sha256", pin.encode("utf-8"), salt, iterations
        )
        data = {
            "salt": base64.b64encode(salt).decode(),
            "hash": base64.b64encode(hash_bytes).decode(),
            "iterations": iterations,
        }

        # 以字符串方式保存到系统安全存储
        keyring.set_password(self.service_name, "pin_data", json.dumps(data))
        print("PIN 已保存到系统安全存储。")
        return data

    # ============================================================
    #                     PIN 验证
    # ============================================================
    def verify_pin(self, pin: str) -> str:
        """
        从系统安全存储读取哈希验证输入的 PIN
        
        参数：
            pin: 要验证的 PIN 码
        
        返回：
            str: "OK" 表示验证成功，"FAIL" 表示验证失败，"not_set" 表示未设置 PIN
        """
        stored_json = keyring.get_password(self.service_name, "pin_data")
        if not stored_json:
            print("没有检测到保存的 PIN，已经使用默认 PIN。")
            self.set_pin("TIMLES")
            return "not_set"

        stored = json.loads(stored_json)
        salt = base64.b64decode(stored["salt"])
        iterations = stored["iterations"]
        stored_hash = base64.b64decode(stored["hash"])

        test_hash = hashlib.pbkdf2_hmac(
            "sha256", pin.encode("utf-8"), salt, iterations
        )
        return "OK" if test_hash == stored_hash else "FAIL"

    # ============================================================
    #                     修改 PIN
    # ============================================================
    def change_pin(self, old_pin: str, new_pin: str):
        """
        验证旧 PIN 并更新新的 PIN
        
        参数：
            old_pin: 旧的 PIN 码
            new_pin: 新的 PIN 码
        
        返回：
            dict: 新 PIN 的数据字典，如果旧 PIN 验证失败则返回 None
        """
        if self.verify_pin(old_pin) == "OK":
            return self.set_pin(new_pin)


if __name__ == "__main__":

    from raytoolsbox.utils import useful_func
    tt=useful_func.make_timer()



    tt('测试PIN')
    pm = PinManager("RayPassApp")
    # 设置 PIN
    pm.set_pin("TIMLES")
    # 验证 PIN
    tt('设置')
    print("验证正确 PIN：", pm.verify_pin("TIMLES"))
    print("验证错误 PIN：", pm.verify_pin("TIMLEs"))
    tt('验证')
