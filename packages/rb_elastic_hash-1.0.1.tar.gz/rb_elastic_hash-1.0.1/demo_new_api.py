"""
Demonstrates the new user-friendly API for ElasticTable
"""
import rb_elastic_hash

print("=== New User-Friendly API ===\n")

# Example 1: Simple usage - just specify how many items you want to store
print("1. Creating table for 100,000 items (default 90% load factor):")
table1 = rb_elastic_hash.ElasticTable.for_items(100_000)
print("   ✓ Table created automatically!\n")

# Example 2: High space efficiency
print("2. Creating table for 1,000,000 items at 95% load factor:")
table2 = rb_elastic_hash.ElasticTable.for_items(1_000_000, load_factor=0.95)
print("   ✓ Will use ~1,052,632 slots for 1M items\n")

# Example 3: Insert and retrieve
print("3. Inserting and retrieving values:")
probes1 = table2.insert(42, "Meaning of life")
probes2 = table2.insert(1337, "Elite")
probes3 = table2.insert(9999, {"nested": "data"})
print(f"   Inserted 42 in {probes1} probes")
print(f"   Inserted 1337 in {probes2} probes")
print(f"   Inserted 9999 in {probes3} probes")

print(f"   Retrieved: table.get(42) = {table2.get(42)}")
print(f"   Retrieved: table.get(1337) = {table2.get(1337)}")
print(f"   Retrieved: table.get(9999) = {table2.get(9999)}\n")

# Example 4: Advanced usage - explicit capacity and delta
print("4. Advanced: Using explicit capacity and delta parameter:")
table3 = rb_elastic_hash.ElasticTable(50_000, delta=0.10)  # 90% load factor
print("   ✓ Created with 50,000 slots and delta=0.10\n")

# Example 5: Default delta parameter
print("5. Using default delta (0.05 = 95% load factor):")
table4 = rb_elastic_hash.ElasticTable(100_000)  # delta=0.05 by default
print("   ✓ Created with 100,000 slots using default delta\n")

print("=== Summary ===")
print("Before: ElasticTable(1_000_000, 0.05)  # Confusing!")
print("After:  ElasticTable.for_items(1_000_000)  # Clear and simple!")
