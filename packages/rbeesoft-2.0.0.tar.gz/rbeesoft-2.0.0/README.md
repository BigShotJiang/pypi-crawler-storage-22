# rbeesoft
Python package with base classes for developing apps and webapps