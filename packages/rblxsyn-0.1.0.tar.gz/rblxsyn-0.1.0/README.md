# RblxPY

Roblox python sync project

-

Usage:
```shell
rblxpy init
rblxpy build
rblxpy rohost
```