def hello():
    return "hello"