"""Storage connectors for Azure Blob Storage."""

from rclco.connectors.storage.azure_blob import AzureBlobConnector

__all__ = ["AzureBlobConnector"]
