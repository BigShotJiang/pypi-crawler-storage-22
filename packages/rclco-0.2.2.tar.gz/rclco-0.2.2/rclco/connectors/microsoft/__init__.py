"""Microsoft connectors for SharePoint and other Microsoft services."""

from rclco.connectors.microsoft.sharepoint import SharePointConnector

__all__ = ["SharePointConnector"]
