from reach_commons.reach_aws.db_config import get_secret

__all__ = ["get_secret"]
