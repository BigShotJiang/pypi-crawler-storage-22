from dataclasses import dataclass, field
import threading
from typing import TYPE_CHECKING, Any, Callable, Optional

import numpy as np

from reactor_runtime.profiling.profiler import NoOpProfiler, Profiler
from reactor_runtime.profiling.backends.file import FileProfilerBackend
from reactor_runtime.profiling.backends.otlp import OTLPProfilerBackend
from reactor_runtime.utils.log import get_logger

if TYPE_CHECKING:
    from reactor_runtime.profiling.profiler import ProfilerType

logger = get_logger(__name__)


@dataclass
class ReactorContext:
    """
    Session-scoped context passed to the model.
    """

    _send_fn: Callable[[dict], None]
    _emit_block_fn: Callable[[Optional[np.ndarray]], None]
    _enable_monitoring_fn: Callable[[], None]
    _disable_monitoring_fn: Callable[[], None]
    _stop_evt: Optional[threading.Event] = None

    # Profiling configuration (used to build profiler in __post_init__)
    _enable_file_profiling: bool = False
    _profiling_output_dir: str = "./profiling"

    # Profiler instance (built in __post_init__, NoOpProfiler if profiling is disabled)
    _profiler: Any = field(default=None, init=False)

    def __post_init__(self) -> None:
        """Build the session profiler based on configuration."""
        self._profiler = self._build_profiler()

    def _build_profiler(self) -> Any:
        """
        Build a new profiler instance for this session.

        Backend selection priority:
        1. OTLP backend if ReactorMachineMetrics is available and enabled
        2. File backend if _enable_file_profiling is True
        3. NoOpProfiler (profiling disabled)

        Returns:
            Profiler instance or NoOpProfiler if profiling is disabled.
        """
        # Try OTLP backend first (production environment)
        try:
            from reactor_runtime.runtimes._redis.reactor_machine_metrics import (
                ReactorMachineMetrics,
            )

            if ReactorMachineMetrics.is_enabled():
                logger.info("Session profiler initialized with OTLP backend")
                return Profiler(OTLPProfilerBackend())
        except Exception as e:
            logger.debug("OTLP backend unavailable", error=e)

        # Fall back to file backend if enabled
        if self._enable_file_profiling:
            try:
                logger.info(
                    "Session profiler initialized with file backend",
                    output_dir=self._profiling_output_dir,
                )
                return Profiler(FileProfilerBackend(self._profiling_output_dir))
            except Exception as e:
                logger.warning("File profiler backend initialization failed", error=e)

        # Profiling disabled or all backends failed
        return NoOpProfiler()

    def should_stop(self) -> bool:
        """
        Check if the session has been signaled to stop.
        Returns True if the stop event is set, False otherwise.
        """
        if self._stop_evt is None:
            return False
        return self._stop_evt.is_set()

    def send(self, data: dict) -> None:
        """
        Send a payload from the model to the frontend.
        Runtime wraps this into an ApplicationMessage envelope before sending.
        """
        self._send_fn(data)

    def emit_block(self, frames: Optional[np.ndarray]) -> None:
        """
        Emits a frame or list of frames to the videostream, displaying them on the client feed.
        Frames should be a NumPy ndarray (H, W, 3) in RGB, or a stack of frames with the stack on the first dimension (N, H, W, 3).
        If None, the frame buffer will put the None through in the frame, allowing the video streamer to send a black frame.
        """
        self._emit_block_fn(frames)

    def enable_monitoring(self) -> None:
        """
        Enable frame monitoring mode for performance tracking.
        """
        self._enable_monitoring_fn()

    def disable_monitoring(self) -> None:
        """
        Disable frame monitoring mode for performance tracking.
        """
        self._disable_monitoring_fn()

    def profiler(self) -> "ProfilerType":
        """
        Get the profiler for measuring code section durations.

        Returns a profiler instance that can be used to measure timing of code sections:

            with get_ctx().profiler().section("inference"):
                with get_ctx().profiler().section("preprocess"):
                    ...

        If profiling is not enabled, returns a no-op profiler that adds no overhead.

        Returns:
            Profiler instance or NoOpProfiler if profiling is disabled.
        """
        return self._profiler


ctx: Optional[ReactorContext] = None


def get_ctx() -> ReactorContext:
    """Get the current global context. Raises if not set."""
    if ctx is None:
        raise RuntimeError(
            "Global context not set. This should only be called during an active session."
        )
    return ctx


def _set_global_ctx(context: ReactorContext):
    global ctx
    ctx = context
