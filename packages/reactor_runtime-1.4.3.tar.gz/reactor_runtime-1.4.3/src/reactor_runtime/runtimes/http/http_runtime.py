"""
HTTP Runtime for Reactor

An HTTP-based runtime that exposes REST endpoints for session management
and WebRTC for real-time video/audio/data streaming.

Endpoints:
    POST /start_session  - Start the model session
    POST /stop_session   - Stop the model session
    POST /sdp_params     - Exchange SDP offer/answer for WebRTC connection
"""

import asyncio
from typing import Optional
import numpy as np
from fastapi import FastAPI, Request, HTTPException

from omegaconf import DictConfig
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from reactor_runtime.model_state import ModelEvent, ModelState
import uvicorn

from reactor_runtime.runtime_api import Runtime
from reactor_runtime.utils.log import get_logger
from reactor_runtime.utils.messages import ApplicationMessage, RuntimeMessage
from reactor_runtime.transports import (
    WebRTCTransport,
    WebRTCNoVideoError,
    WebRTCSupersededError,
    EventType,
    MessageEvent,
    DisconnectedEvent,
    VideoFrameEvent,
    PingTimeoutEvent,
)
from reactor_runtime.transports.types import (
    IceTransportPolicy,
    TransportConfig,
    TransportType,
)
from reactor_runtime.runtimes.http.config import HttpRuntimeConfig

logger = get_logger(__name__)


# TODO(REA-162) Move these types to protobuf
class SDPRequest(BaseModel):
    """SDP offer request body."""

    sdp: str
    type: str = "offer"


class SDPResponse(BaseModel):
    """SDP answer response body."""

    sdp: str
    type: str


class HttpRuntime(Runtime):
    """
    An HTTP runtime that exposes REST endpoints for session control
    and uses WebRTC for real-time media streaming.

    Endpoints:
        POST /start_session  - Start the model session
        POST /stop_session   - Stop the model session
        POST /sdp_params     - Exchange SDP offer/answer for WebRTC
    """

    config: HttpRuntimeConfig

    def __init__(self, config: HttpRuntimeConfig):
        """
        Initialize the HTTP runtime.

        Args:
            config: HttpRuntimeConfig containing model and runtime-specific settings.
        """
        # WebRTC transport - single connection at a time
        # Protected by _client_lock for thread-safe access
        self._webrtc_client: Optional[WebRTCTransport] = None
        self._client_lock = asyncio.Lock()

        # FastAPI app
        self.app = FastAPI(title="Reactor HTTP Runtime")

        # Configure CORS to allow any origin
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        self._setup_routes()

        # Call parent constructor (loads model)
        super().__init__(config)

    def _setup_routes(self) -> None:
        """Setup FastAPI routes."""

        @self.app.post("/start_session")
        async def start_session(request: Request):
            """Start the model session."""
            success = self.send(ModelEvent.START_SESSION)
            if not success:
                return JSONResponse(
                    status_code=400,
                    content={
                        "error": "Cannot start session",
                        "state": self.current_state.value,
                    },
                )
            return JSONResponse(
                status_code=202, content={"state": self.current_state.value}
            )

        @self.app.post("/stop_session")
        async def stop_session(request: Request):
            """Stop the model session."""
            success = self.send(ModelEvent.STOP_SESSION)
            if not success:
                return JSONResponse(
                    status_code=400,
                    content={
                        "error": "Cannot stop session",
                        "state": self.current_state.value,
                    },
                )

            return JSONResponse(content={"state": self.current_state.value})

        @self.app.post("/sdp_params", response_model=SDPResponse)
        async def sdp_params(sdp_request: SDPRequest):
            """
            Handle SDP offer and return SDP answer.
            Sets up WebRTC connection with video track and data channel.

            If a previous connection exists, it is stopped cooperatively
            before creating the new one. If the new connection is superseded
            by another request during setup, returns 409 Conflict.
            """
            if self.current_state not in (
                ModelState.WAITING,
                ModelState.STREAMING,
                ModelState.ORPHANED,
            ):
                raise HTTPException(status_code=400, detail="No session running")
            try:
                answer = await self._handle_sdp_offer(sdp_request.sdp, sdp_request.type)
                return SDPResponse(sdp=answer.sdp, type=answer.type)
            except WebRTCSupersededError:
                raise HTTPException(
                    status_code=409, detail="Connection superseded by newer request"
                )
            except WebRTCNoVideoError:
                raise HTTPException(
                    status_code=400,
                    detail="SDP offer does not include video support",
                )
            except HTTPException:
                raise
            except Exception as e:
                logger.exception("Error handling SDP offer", error=e)
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.get("/health")
        async def health():
            """Health check endpoint."""
            return {
                "status": "healthy",
                "model": self.config.model_name,
                "state": self.current_state.value,
            }

        @self.app.get("/ice_servers")
        async def ice_servers():
            """
            Return ICE server configuration for WebRTC peer connection.

            Returns the configured STUN/TURN servers in the format expected by
            RTCPeerConnection's iceServers configuration.
            """
            return {"ice_servers": self.config.ice_servers_json}

    # ===============================
    # WebRTC Connection Management
    # ===============================

    async def _handle_sdp_offer(self, sdp: str, sdp_type: str):
        """
        Handle an SDP offer and create an answer.

        Simple flow:
        1. If existing client exists, stop it cooperatively
        2. Create new client
        3. Send client connected event
        4. If client was superseded during creation, raise WebRTCSupersededError

        Args:
            sdp: The SDP offer string.
            sdp_type: The type of SDP (usually "offer").

        Returns:
            The SDP answer.

        Raises:
            WebRTCSupersededError: If this connection was superseded.
            RuntimeError: If connection setup fails.
        """
        # Stop existing client if any (cooperative, fast)
        async with self._client_lock:
            if self._webrtc_client is not None:
                logger.info("Stopping existing WebRTC client")
                # Stop is cooperative - signals the client to exit quickly
                self._webrtc_client.stop()
                self._webrtc_client = None
                self.send(ModelEvent.CLIENT_DISCONNECTED)

        # Create new WebRTC transport
        # Uses async polling internally, yielding to event loop during setup
        logger.info("Creating new WebRTC connection")
        transport, answer = await WebRTCTransport.create(
            TransportType.AIORTC,
            sdp_offer=sdp,
            sdp_type=sdp_type,
            config=TransportConfig(
                ice_servers=self.config.ice_servers,
                port_range=self.config.webrtc_port_range,
                transport_policy=self.config.ice_transport_policy,
            ),
        )

        # Install the new transport
        async with self._client_lock:
            # Check if another client was installed while we were creating
            if self._webrtc_client is not None:
                # Another request beat us, stop our transport
                transport.stop()
                raise WebRTCSupersededError(
                    "Connection superseded by concurrent request"
                )
            success = self.send(ModelEvent.CLIENT_CONNECTED, client=transport)
            if not success:
                transport.stop()
                raise RuntimeError(
                    "Session expired while waiting for client connection"
                )

        return answer

    def _setup_webrtc_handlers(self, client: WebRTCTransport) -> None:
        """Setup event handlers for a WebRTC client."""

        def on_message(event: MessageEvent):
            """Handle incoming data channel message."""
            if not self.loop.is_closed():
                asyncio.run_coroutine_threadsafe(
                    self._on_data_channel_message(event.data), self.loop
                )

        def on_disconnect(event: DisconnectedEvent):
            """Handle WebRTC disconnection."""
            if not self.loop.is_closed():
                logger.info("WebRTC disconnected", reason=event.reason)
                self.loop.call_soon_threadsafe(
                    self.send, ModelEvent.CLIENT_DISCONNECTED
                )

        def on_video_frame(event: VideoFrameEvent):
            """Handle incoming video frame."""
            if not self.loop.is_closed():
                asyncio.run_coroutine_threadsafe(
                    self._on_incoming_video_frame(event.frame), self.loop
                )

        def on_ping_timeout(event: PingTimeoutEvent):
            """Handle client ping timeout – treat as disconnection."""
            if not self.loop.is_closed():
                logger.warning(
                    "Client ping timeout, treating as client disconnection",
                    elapsed=f"{event.elapsed:.1f}s",
                )
                self.loop.call_soon_threadsafe(
                    self.send, ModelEvent.CLIENT_DISCONNECTED
                )

        client.on(EventType.MESSAGE, on_message)
        client.on(EventType.DISCONNECTED, on_disconnect)
        client.on(EventType.VIDEO_FRAME, on_video_frame)
        client.on(EventType.PING_TIMEOUT, on_ping_timeout)

    async def _stop_webrtc_client(self) -> None:
        """Stop and clear the current WebRTC client."""
        async with self._client_lock:
            if self._webrtc_client is not None:
                self._webrtc_client.stop()
                self._webrtc_client = None
                logger.info("WebRTC client stopped")

    async def _on_data_channel_message(self, message: str) -> None:
        """
        Handle incoming data channel message.
        Delegates to the common handler in the abstract Runtime class.
        """
        await self._handle_incoming_data_channel_message(message)

    def _on_ping_received(self) -> None:
        """Forward client ping to the WebRTC client's watchdog."""
        if self._webrtc_client:
            self._webrtc_client.notify_ping()

    async def _on_incoming_video_frame(self, frame: np.ndarray) -> None:
        """
        Handle incoming video frame from WebRTC.
        Currently logs the frame dimensions - override for custom handling.

        Args:
            frame: NumPy array in RGB format with shape (H, W, 3).
        """
        if self.model:
            self.model.on_frame(frame)

    # ===============================
    # Runtime API implementation - MODEL -> CLIENT (WebRTC)
    # ===============================

    async def send_out_app_message(self, data: ApplicationMessage) -> None:
        """
        Send an application message via the WebRTC data channel.
        """
        # Don't use lock here - send_message is thread-safe and we don't want to block
        client = self._webrtc_client
        if client is not None:
            if client.send_message(data):
                logger.debug("Sent app message via data channel")
            else:
                logger.debug("Data channel not available, message not sent")
        else:
            logger.debug("No WebRTC client, message not sent")

    async def send_out_runtime_message(self, data: RuntimeMessage) -> None:
        """
        Send a runtime message via the WebRTC data channel.
        """
        client = self._webrtc_client

        if not client:
            logger.warning("No WebRTC client, runtime message not sent")
            return

        if not client.send_message(data):
            logger.warning("Failed to send runtime message via data channel")
            return

    async def send_out_app_frame(self, frame: np.ndarray, duplicate: bool) -> None:
        """
        Send an output frame via the WebRTC video track.
        This is called periodically by the frame buffer.

        Silently skips if no WebRTC connection is active - the model
        session continues and frames will be sent once a client connects.

        Args:
            frame: NumPy array in RGB format with shape (H, W, 3).
            duplicate: True if this is a re-emission of the last frame. When True,
                       the WebRTC client can skip expensive numpy-to-video conversion.
        """
        # Don't use lock here - send_frame is thread-safe and we don't want to block
        client = self._webrtc_client
        if client is not None:
            client.send_frame(frame, duplicate)

    # ===============================
    # Runtime API implementation - Model Lifecycle Handlers
    # ===============================

    def on_before_cleanup_complete(self, **kwargs) -> None:
        """
        Called AFTER internal cleanup when the model thread exits.
        """
        error = kwargs.get("error", None)
        if error:
            logger.warning("Model exited with error", error=error)
        else:
            logger.info("Model session ended")

    def on_before_stop_session(self, **kwargs) -> None:
        if self._webrtc_client is not None:
            self._webrtc_client.stop_ping_watchdog()
        asyncio.run_coroutine_threadsafe(self._stop_webrtc_client(), self.loop)

    def on_before_client_connected(self, **kwargs) -> None:
        """
        Handler called before the client connected event is sent.
        Installs the client setting up event handlers
        """
        client = kwargs.get("client")
        assert client is not None, "Client must be provided"
        self._setup_webrtc_handlers(client)
        self._webrtc_client = client
        client.start_ping_watchdog()
        logger.info("WebRTC connection established")

    def on_before_client_disconnected(self, **kwargs) -> None:
        """
        Cleanup called after the WebRTC client is disconnected. This frees the resource used by the WebRTC client thread.
        """
        if self._webrtc_client is not None:
            self._webrtc_client.stop_ping_watchdog()
        asyncio.run_coroutine_threadsafe(self._stop_webrtc_client(), self.loop)

    async def run(self) -> None:
        """
        Main entry point to run the HTTP runtime.
        Starts the FastAPI server with uvicorn.
        """
        logger.info(
            "Starting HTTP runtime", host=self.config.host, port=self.config.port
        )

        uvicorn_config = uvicorn.Config(
            app=self.app, host=self.config.host, port=self.config.port, log_level="info"
        )
        server = uvicorn.Server(uvicorn_config)

        try:
            await server.serve()
        except KeyboardInterrupt:
            logger.info("HTTP runtime interrupted")
        finally:
            await self._stop_webrtc_client()
            await self.shutdown()


async def serve(
    model_spec: str, model_name: str, model_config: DictConfig, **kwargs
) -> None:
    """
    Entry point for running the HTTP runtime from a CLI.

    Args:
        model_spec: Python import path to the VideoModel class (module:Class)
        model_name: Name of the model
        model_config: DictConfig of kwargs to pass to the model constructor
        **kwargs: Runtime-specific arguments from HttpRuntimeConfig.parser()
            - host: Host to bind to (default: "0.0.0.0")
            - port: Port to bind to (default: 8080)
            - orphan_timeout: Seconds to wait before stopping orphaned session (default: 30.0)
            - max_session_duration: Maximum session duration in seconds (default: None, disabled)
            - webrtc_port_range: WebRTC ICE UDP port range as tuple (min, max) (default: None)
            - stun_servers: List of STUN server URLs (default: None, uses Google STUN)
            - turn_servers: List of TURN servers in format "username;credential;url" (default: None)
    """

    config = HttpRuntimeConfig(
        model_name=model_name,
        model_args=model_config,
        model_spec=model_spec,
        host=kwargs.get("host", "0.0.0.0"),
        port=kwargs.get("port", 8080),
        orphan_timeout=kwargs.get("orphan_timeout", 30.0),
        max_session_duration=kwargs.get("max_session_duration"),
        webrtc_port_range=kwargs.get("webrtc_port_range"),
        stun_servers=kwargs.get("stun_servers"),
        turn_servers=kwargs.get("turn_servers"),
        ice_transport_policy=kwargs.get("ice_transport_policy", IceTransportPolicy.ALL),
        # Profiling configuration
        enable_profiling=kwargs.get("enable_profiling", False),
        profiling_output_dir=kwargs.get("profiling_output_dir", "./profiling"),
    )

    runtime = HttpRuntime(config)
    asyncio.create_task(runtime.load())
    await runtime.run()
