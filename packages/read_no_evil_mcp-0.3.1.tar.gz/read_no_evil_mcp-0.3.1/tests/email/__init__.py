"""Tests for email subpackage."""
