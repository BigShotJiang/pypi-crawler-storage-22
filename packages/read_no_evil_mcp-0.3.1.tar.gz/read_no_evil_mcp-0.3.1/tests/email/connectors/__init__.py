"""Tests for email connectors."""
