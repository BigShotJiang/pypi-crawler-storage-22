"""Tests for filtering module."""
