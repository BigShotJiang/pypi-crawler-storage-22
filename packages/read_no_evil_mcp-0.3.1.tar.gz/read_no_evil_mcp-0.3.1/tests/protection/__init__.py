"""Tests for protection layer."""
