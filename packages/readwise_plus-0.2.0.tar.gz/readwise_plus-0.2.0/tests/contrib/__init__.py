"""Tests for contrib interfaces."""
