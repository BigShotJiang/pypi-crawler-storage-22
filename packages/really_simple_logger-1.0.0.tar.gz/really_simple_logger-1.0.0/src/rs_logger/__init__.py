__version__='1.0.0'

from .logger import Logger, WARN, ERROR, INFO, DEBUG
