"""
RealTimeX Services API Modules

Domain-based modules containing API endpoints, business logic, and schemas
organized by feature/domain for better maintainability and growth.
"""
