# Reaper Abliteration

Automatic censorship removal for language models via directional ablation.

Reaper Abliteration removes safety alignment from transformer-based language models without expensive post-training. It combines an advanced implementation of directional ablation ([Arditi et al. 2024](https://arxiv.org/abs/2406.11717)) with TPE-based parameter optimization powered by [Optuna](https://optuna.org/).

Works **completely automatically** - finds high-quality abliteration parameters by co-minimizing refusals and KL divergence from the original model. No deep understanding of transformer internals required.

## Features

- **Automatic parameter optimization** - TPE sampler finds optimal ablation weights
- **Multi-GPU support** - Automatic distribution across available GPUs with memory balancing
- **Live dashboard** - Rich terminal UI with Pareto front tracking and GPU memory monitoring
- **Progressive evaluation** - KL-threshold skip + subset refusal check for 2-4x faster trials
- **4-bit quantization** - Process large models with reduced VRAM (enabled by default)
- **Model type support** - Handles both standard instruct models and reasoning models (o1, R1, QwQ)
- **Seed parameters** - Automatically saves and reuses Pareto-optimal trials for warm starts
- **Gradient checkpointing** - Reduce VRAM usage by 60-80% when needed
- **MoE model support** - Works with mixture-of-experts architectures
- **PCA directions** - Optional multi-dimensional refusal direction extraction
- **Per-head ablation** - Target specific attention heads for finer control

### Advanced Ablation (all opt-in)

- **Norm-preserving ablation** - Rescale weight rows to original norms after ablation for better capability retention
- **Projected direction** - Orthogonalize refusal direction against harmless direction for cleaner ablation
- **Partial projection** - Optuna tunes removal strength (0.1-1.0) instead of full removal
- **Adaptive layer selection** - Automatically skip layers with low refusal separability
- **Multi-direction combination** - Weighted sum of mean + PCA directions to capture the full refusal cone
- **Concept atoms (SRA)** - Clean refusal direction via capability-probing orthogonalization (math, code, reasoning)
- **Rank-k SVD ablation** - Remove a k-dimensional refusal subspace instead of a single direction
- **Weight-SVD stability guard** - Protect capability-critical weight subspaces from ablation damage
- **Sparse ablation filtering** - Zero low-magnitude ablation entries for targeted, minimal modification
- **Multi-token KL divergence** - Measure capability preservation over multiple autoregressive tokens

## Installation

Requires Python 3.10+ and PyTorch 2.2+ installed for your hardware.

```bash
pip install -U reaper-abliteration
```

For research features (residual plots, geometry analysis):

```bash
pip install -U reaper-abliteration[research]
```

## Quick Start

```bash
abliterate Qwen/Qwen3-4B-Instruct-2507
```

The process is fully automatic:
1. Auto-detects optimal batch size for your hardware
2. Computes refusal directions from good/bad prompt datasets
3. Runs optimization trials (default: 200) with live dashboard
4. Presents Pareto-optimal results for selection
5. Offers to save locally, upload to HuggingFace, or chat test

On an RTX 3090 with defaults, decensoring Llama-3.1-8B takes ~45 minutes.

## CLI Reference

### Basic Usage

```bash
abliterate <model_id>
abliterate --model <model_id>
```

### Common Options

```bash
# Model configuration
--model-type {instruct|reasoning}  # Model type (default: instruct)
--quantization {none|bnb_4bit}     # Quantization method (default: none)
--batch-size N                     # Batch size (0 = auto, default: 0)
--trust-remote-code                # Trust remote code (default: true)

# Optimization
--n-trials N                       # Number of trials (default: 200)
--n-startup-trials N               # Random exploration trials (default: 60)
--use-seed-params                  # Load prior good trials (default: true)

# GPU/Memory
--multi-gpu                        # Enable multi-GPU support
--gpu-devices [0,1,...]            # Specific GPUs to use
--use-gradient-checkpointing       # Reduce VRAM by 60-80%
--max-memory '{"0":"20GB"}'        # Per-device memory limits

# Display
--dashboard / --no-dashboard       # Live dashboard (default: true)
--print-responses                  # Print prompt/response pairs

# Direction refinement
--use-pca-directions               # Multi-dimensional refusal directions
--projected-direction              # Orthogonalize against harmless direction
--combine-directions               # Weighted mean+PCA combination (requires --use-pca-directions)
--concept-atoms                    # SRA: capability-probing orthogonalization
--concept-atom-ridge F             # Ridge regularization for SRA (default: 0.1)

# Ablation control
--norm-preserve                    # Preserve weight row norms after ablation
--partial-projection               # Optuna tunes removal strength 0.1-1.0
--adaptive-layer-selection         # Skip low-separability layers
--per-head-ablation                # Target specific attention heads
--ablation-rank N                  # LoRA rank for multi-direction ablation (default: 1)
--weight-svd-guard                 # Protect capability-critical weight subspaces
--svd-guard-rank N                 # Number of singular vectors to protect (default: 3)
--sparsity-threshold F             # Zero low-magnitude ablation entries (0.0 = disabled)
--kl-tokens N                      # Multi-token KL divergence (default: 1)
--semantic-refusal-detection       # Embedding-based refusal detection
```

See `abliterate --help` for all options.

## Configuration

### Config File

Create `config.toml` in your working directory:

```toml
model = "Qwen/Qwen3-4B-Instruct-2507"
n_trials = 300
batch_size = 32
dashboard = true

# Multi-GPU
multi_gpu = true
gpu_devices = [0, 1]
max_memory = {"0" = "20GB", "1" = "20GB"}

# Performance
use_gradient_checkpointing = true
quantization = "bnb_4bit"

# Direction refinement
use_pca_directions = true
num_pca_directions = 3
projected_direction = true

# Advanced ablation
norm_preserve = true
partial_projection = true
adaptive_layer_selection = true
```

### Environment Variables

All settings can be set via `REAPER_` prefix:

```bash
export REAPER_MODEL="meta-llama/Llama-3.1-8B-Instruct"
export REAPER_N_TRIALS=300
export REAPER_BATCH_SIZE=32
export REAPER_MULTI_GPU=true
```

## Model Type Support

### Instruct Models (Default)

Standard chat models with fast refusal detection via early-exit optimization:

```bash
abliterate --model-type instruct Qwen/Qwen3-4B-Instruct-2507
```

Generation stops as soon as a refusal marker is detected, significantly speeding up trials.

### Reasoning Models

Models that generate `<think>...</think>` blocks (o1, R1, QwQ, DeepSeek-R1):

```bash
abliterate --model-type reasoning deepseek-ai/DeepSeek-R1-Distill-Qwen-7B
```

- Uses longer generation length (512 tokens by default)
- Extracts response after thinking block for refusal detection
- Configurable thinking tokens via `--thinking-start-token` / `--thinking-end-token`

## Multi-GPU Support

Automatically uses multiple GPUs when available.

**Benefits:**
- Load models exceeding single GPU memory
- Larger batch sizes for faster processing
- Automatic memory balancing

**Configuration** (optional, usually auto-detected):

```bash
abliterate --multi-gpu --gpu-devices 0,1 <model>
```

Or in `config.toml`:

```toml
multi_gpu = true
gpu_devices = [0, 1]
max_memory = {"0" = "20GB", "1" = "20GB"}  # Optional limits
```

**Monitoring:**

The dashboard displays per-GPU memory usage:

```
GPU MEMORY:
  GPU0: ████████░░░░ 12.5/24.0GB (52%)
  GPU1: ██████░░░░░░  8.3/24.0GB (35%)
```

Batch size scales automatically based on total GPU memory.

## Performance Options

### VRAM Reduction

```toml
# Enable gradient checkpointing (reduces VRAM 60-80%)
use_gradient_checkpointing = true

# Use 4-bit quantization (default: disabled)
quantization = "bnb_4bit"

# Reduce batch size
batch_size = 16
```

### Speed Optimization

```toml
# Cache dequantized weights for 4-bit models (trades memory for speed)
cache_dequantized_weights = true

# Use instruct model type for early-exit optimization
model_type = "instruct"

# Enable multi-GPU for data parallelism
multi_gpu = true
```

### Prompt Caching

Enabled by default - tokenized prompts are cached across trials (5-10% speedup).

## Advanced Ablation Features

All advanced features are opt-in and disabled by default. They can be combined freely.

### Norm-Preserving Ablation

Rescales weight rows to their original L2 norms after ablation. This prevents the magnitude shifts that can degrade model capabilities even when the direction removal is correct.

```bash
abliterate --norm-preserve <model>
```

Implemented as an approximate correction via the rank-1 LoRA constraint. Recommended for most runs.

### Projected Direction

Orthogonalizes the refusal direction against the harmless activation direction using Gram-Schmidt. This produces a cleaner ablation axis that targets refusal behavior without disturbing harmless representations.

```bash
abliterate --projected-direction <model>
```

Based on [projected abliteration (Jim Lai)](https://huggingface.co/blog/grimjim/projected-abliteration).

### Partial Projection

Instead of fully removing the refusal direction, lets Optuna tune the removal strength between 0.1 and 1.0. Useful when full removal causes too much capability loss.

```bash
abliterate --partial-projection <model>
```

### Adaptive Layer Selection

Computes per-layer refusal separability (`||mean_bad - mean_good||_2`) and lets Optuna skip layers with low scores. Focuses ablation effort on layers that actually encode refusal behavior.

```bash
abliterate --adaptive-layer-selection <model>
```

### Multi-Direction Combination

When PCA directions are enabled, allows the optimizer to find a weighted combination of mean + PCA directions rather than picking a single one. Captures more of the refusal "concept cone."

```bash
abliterate --use-pca-directions --combine-directions <model>
```

### Concept Atoms (SRA)

Surgical Refusal Ablation - cleans the refusal direction by orthogonalizing it against capability-probing activation directions. Runs math, code, and reasoning prompts through the model to extract capability directions, then removes their components from the refusal direction via ridge-regularized regression.

```bash
abliterate --concept-atoms <model>
abliterate --concept-atoms --concept-atom-ridge 0.05 <model>  # less regularization
```

Based on [Surgical Refusal Ablation (Pres et al. 2025)](https://arxiv.org/abs/2601.08489).

### Rank-k SVD Ablation

Instead of removing a single refusal direction (rank-1), extract the top-k directions from the refusal subspace via SVD. Captures more of the refusal "manifold" for more complete removal.

```bash
abliterate --ablation-rank 3 <model>
```

The LoRA rank is set to match, so `delta_W = -lambda * V^T (V @ W)` removes a k-dimensional subspace. Optuna can tune the rank between 1 and 8.

### Weight-SVD Stability Guard

Before ablating each weight matrix, compute its truncated SVD and project refusal directions away from the top singular vectors. Protects the most capability-critical dimensions from collateral damage.

```bash
abliterate --weight-svd-guard <model>
abliterate --weight-svd-guard --svd-guard-rank 5 <model>  # protect more dimensions
```

SVD results are cached per module across trials for efficiency. Uses `torch.svd_lowrank` for fast truncated decomposition.

### Sparse Ablation Filtering

After computing the ablation LoRA, zero out entries with magnitude below a threshold (fraction of max). Makes the ablation sparser, modifying fewer input dimensions and reducing capability damage.

```bash
abliterate --sparsity-threshold 0.1 <model>
```

When enabled, Optuna tunes the exact threshold between 0.01 and 0.5 per trial.

### Multi-Token KL Divergence

Measure KL divergence over multiple autoregressive tokens instead of just the first. Uses teacher-forcing for valid comparison: the base model generates continuation tokens, then both models run forward passes on the shared sequence.

```bash
abliterate --kl-tokens 3 <model>
```

Higher values (3-5) catch subtle capability damage that single-token KL misses, at the cost of slower trials.

### Recommended Combinations

For maximum quality:
```bash
abliterate --norm-preserve --projected-direction --partial-projection --adaptive-layer-selection <model>
```

For maximum quality with rank-k and guards:
```bash
abliterate --ablation-rank 3 --weight-svd-guard --sparsity-threshold 0.1 \
  --norm-preserve --partial-projection --kl-tokens 3 <model>
```

For maximum quality with PCA:
```bash
abliterate --norm-preserve --projected-direction --partial-projection \
  --adaptive-layer-selection --use-pca-directions --combine-directions \
  --concept-atoms <model>
```

## Other Advanced Usage

### Seed Parameters

Best trials are auto-saved to `seed_params/<model>.json` and loaded on next run for warm starts:

```bash
# Disable seed loading
abliterate --no-use-seed-params <model>
```

Seed files contain Pareto-optimal parameter sets with refusal counts and KL divergence. All advanced feature parameters (projection strength, direction weights, separability thresholds) are persisted and replayed.

### Custom Prompts

Specify custom datasets for direction calculation and evaluation:

```toml
[good_prompts]
dataset = "your/harmless-dataset"
split = "train[:500]"
column = "text"

[bad_prompts]
dataset = "your/harmful-dataset"
split = "train[:500]"
column = "text"
```

### PCA Directions

Extract multiple refusal directions via PCA/SVD:

```bash
abliterate --use-pca-directions --num-pca-directions 5 <model>
```

Allows optimizer to explore richer direction space beyond mean difference.

### Per-Head Ablation

Target specific attention heads instead of all heads:

```bash
abliterate --per-head-ablation --head-ablation-fraction 0.5 <model>
```

Optimizer samples around the specified fraction to find optimal head selection.

### Semantic Refusal Detection

Use embedding-based similarity instead of keyword matching:

```bash
abliterate --semantic-refusal-detection --semantic-refusal-threshold 0.75 <model>
```

More accurate but slower than keyword matching.

## Research Features

Install with `pip install -U reaper-abliteration[research]` for:

### Residual Plots

Generate PaCMAP 2D projections of residual vectors by layer:

```bash
abliterate --plot-residuals <model>
```

Creates PNG images per layer plus animated GIF showing transformations across layers.

### Residual Geometry

Print detailed metrics about refusal direction geometry:

```bash
abliterate --print-residual-geometry <model>
```

Outputs quantitative analysis of how "harmful" and "harmless" prompt residuals relate.

## How It Works

Reaper Abliteration implements parametrized directional ablation:

1. **Compute refusal directions** - Per-layer difference-of-means between residuals from "harmful" and "harmless" prompts
2. **Refine directions** (optional) - Project out harmless components, orthogonalize against capability atoms, combine PCA directions
3. **Orthogonalize weight matrices** - For each transformer component (attention out-proj, MLP down-proj), orthogonalize with respect to refusal direction using LoRA adapters
4. **Preserve norms** (optional) - Rescale modified weight rows to match original L2 norms
5. **Optimize parameters** - TPE sampler explores ablation weight kernels, layer selection thresholds, and projection strengths to minimize refusals and KL divergence
6. **Progressive evaluation** - Quick KL check + subset refusal scan to prune bad trials early (2-4x speedup)

**Key innovations:**
- Flexible ablation weight kernels (more granular than fixed weights)
- Float direction indices (linear interpolation between nearest directions)
- Per-component parameters (MLP vs attention treated separately)
- Multi-objective optimization (refusals + KL divergence)
- Norm-preserving ablation via rank-1 LoRA approximation
- Surgical direction refinement (projected, partial, SRA)
- Adaptive layer selection based on refusal separability

## Tips

- **Start with defaults** - Auto-configuration works well for most models
- **KL divergence > 1.0** indicates significant capability damage
- **Enable `--norm-preserve`** for better capability retention with minimal overhead
- **Enable gradient checkpointing** for large models if OOM
- **Use seed params** - Subsequent runs are much faster with warm starts
- **Multi-GPU helps** - Both for fitting large models and faster trials
- **Reasoning models need `--model-type reasoning`** - Otherwise thinking blocks break refusal detection
- **Stack advanced features** - `--norm-preserve --projected-direction --partial-projection` is a solid default

## Prior Art

- [AutoAbliteration](https://huggingface.co/posts/mlabonne/714992455492422)
- [abliterator.py](https://github.com/FailSpy/abliterator)
- [wassname's Abliterator](https://github.com/wassname/abliterator)
- [ErisForge](https://github.com/Tsadoq/ErisForge)
- [Removing refusals with HF Transformers](https://github.com/Sumandora/remove-refusals-with-transformers)
- [deccp](https://github.com/AUGMXNT/deccp)

## Acknowledgments

Development informed by:
- [The original abliteration paper (Arditi et al. 2024)](https://arxiv.org/abs/2406.11717)
- [Maxime Labonne's article on abliteration](https://huggingface.co/blog/mlabonne/abliteration)
- [Jim Lai's article on projected abliteration](https://huggingface.co/blog/grimjim/projected-abliteration)
- [Surgical Refusal Ablation (Pres et al. 2025)](https://arxiv.org/abs/2601.08489)
- [Gabliteration: norm-preserving biprojected abliteration (Ibrahim 2025)](https://arxiv.org/abs/2512.18901)

## License

Copyright 2025 HauhauCS (hauhaut901@gmail.com)

This program is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

**By contributing to this project, you agree to release your contributions under the same license.**
