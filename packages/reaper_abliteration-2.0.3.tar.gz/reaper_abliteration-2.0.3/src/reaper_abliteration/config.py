# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

from enum import Enum

from pydantic import BaseModel, Field, field_validator
from pydantic_settings import (
    BaseSettings,
    CliSettingsSource,
    EnvSettingsSource,
    PydanticBaseSettingsSource,
    TomlConfigSettingsSource,
)


class ModelType(str, Enum):
    INSTRUCT = "instruct"  # Standard chat models - fast refusal detection
    REASONING = "reasoning"  # Reasoning models (o1, R1, QwQ) - parse thinking blocks


class QuantizationMethod(str, Enum):
    NONE = "none"
    BNB_4BIT = "bnb_4bit"


class DistributionStrategy(str, Enum):
    AUTO = "auto"
    SEQUENTIAL = "sequential"


class DatasetSpecification(BaseModel):
    dataset: str = Field(
        description="Hugging Face dataset ID, or path to dataset on disk."
    )

    split: str = Field(description="Portion of the dataset to use.")

    column: str = Field(description="Column in the dataset that contains the prompts.")

    prefix: str = Field(
        default="",
        description="Text to prepend to each prompt.",
    )

    suffix: str = Field(
        default="",
        description="Text to append to each prompt.",
    )

    system_prompt: str | None = Field(
        default=None,
        description="System prompt to use with the prompts (overrides global system prompt if set).",
    )

    residual_plot_label: str | None = Field(
        default=None,
        description="Label to use for the dataset in plots of residual vectors.",
    )

    residual_plot_color: str | None = Field(
        default=None,
        description="Matplotlib color to use for the dataset in plots of residual vectors.",
    )


class Settings(BaseSettings):
    model: str = Field(description="Hugging Face model ID, or path to model on disk.")

    model_type: ModelType = Field(
        default=ModelType.INSTRUCT,
        description="Model type: 'instruct' for standard chat models (fast refusal detection), 'reasoning' for models with thinking blocks (o1, R1, QwQ).",
    )

    thinking_start_token: str = Field(
        default="<think>",
        description="Start token for reasoning model thinking blocks.",
    )

    thinking_end_token: str = Field(
        default="</think>",
        description="End token for reasoning model thinking blocks.",
    )

    evaluate_model: str | None = Field(
        default=None,
        description="If this model ID or path is set, then instead of abliterating the main model, evaluate this model relative to the main model.",
    )

    dtypes: list[str] = Field(
        default=[
            # In practice, "auto" almost always means bfloat16.
            "auto",
            # If that doesn't work (e.g. on pre-Ampere hardware), fall back to float16.
            "float16",
            # If "auto" resolves to float32, and that fails because it is too large,
            # and float16 fails due to range issues, try bfloat16.
            "bfloat16",
            # If neither of those work, fall back to float32 (which will of course fail
            # if that was the dtype "auto" resolved to).
            "float32",
        ],
        description="List of PyTorch dtypes to try when loading model tensors. If loading with a dtype fails, the next dtype in the list will be tried.",
    )

    device_map: str | dict[str, int | str] = Field(
        default="auto",
        description="Device map to pass to Accelerate when loading the model.",
    )

    max_memory: dict[str, str] | None = Field(
        default=None,
        description="Maximum memory to allocate per device (e.g., {'0': '20GB', 'cpu': '64GB'}).",
    )

    multi_gpu: bool = Field(
        default=False,
        description="Enable multi-GPU support. When enabled and multiple GPUs are available, automatically calculates max_memory for balanced distribution.",
    )

    gpu_devices: list[int] | None = Field(
        default=None,
        description="Specific GPU device indices to use (e.g., [0, 1]). None = use all available.",
    )

    distribution_strategy: DistributionStrategy = Field(
        default=DistributionStrategy.AUTO,
        description="GPU distribution strategy: 'auto' (balanced across GPUs) or 'sequential' (fill one GPU at a time).",
    )

    trust_remote_code: bool = Field(
        default=True,
        description="Whether to trust remote code when loading the model.",
    )

    quantization: QuantizationMethod = Field(
        default=QuantizationMethod.NONE,
        description="Quantization method to use when loading the model. Options: 'none' (no quantization), 'bnb_4bit' (4-bit quantization using bitsandbytes).",
    )

    cache_dequantized_weights: bool = Field(
        default=False,
        description="Cache dequantized weights across trials for 4-bit models. Trades memory for speed (~2x faster abliteration).",
    )

    use_gradient_checkpointing: bool = Field(
        default=False,
        description="Enable gradient checkpointing to reduce VRAM usage at the cost of recomputation during forward pass.",
    )

    batch_size: int = Field(
        default=0,  # auto
        ge=0,
        description="Number of input sequences to process in parallel (0 = auto).",
    )

    max_batch_size: int = Field(
        default=128,
        gt=0,
        description="Maximum batch size to try when automatically determining the optimal batch size.",
    )

    max_response_length: int = Field(
        default=100,
        description="Maximum number of tokens to generate for each response.",
    )

    reasoning_max_length: int = Field(
        default=512,
        description="Maximum tokens for reasoning models (must be long enough to get past thinking block).",
    )

    print_responses: bool = Field(
        default=False,
        description="Whether to print prompt/response pairs when counting refusals.",
    )

    print_residual_geometry: bool = Field(
        default=False,
        description="Whether to print detailed information about residuals and refusal directions.",
    )

    plot_residuals: bool = Field(
        default=False,
        description="Whether to generate plots showing PaCMAP projections of residual vectors.",
    )

    residual_plot_path: str = Field(
        default="plots",
        description="Base path to save plots of residual vectors to.",
    )

    residual_plot_title: str = Field(
        default='PaCMAP Projection of Residual Vectors for "Harmless" and "Harmful" Prompts',
        description="Title placed above plots of residual vectors.",
    )

    residual_plot_style: str = Field(
        default="dark_background",
        description="Matplotlib style sheet to use for plots of residual vectors.",
    )

    kl_tokens: int = Field(
        default=1,
        ge=1,
        le=10,
        description="Number of autoregressive tokens to measure KL divergence over. Higher values catch more subtle capability damage but are slower.",
    )

    kl_divergence_scale: float = Field(
        default=1.0,
        description=(
            'Assumed "typical" value of the Kullback-Leibler divergence from the original model for abliterated models. '
            "This is used to ensure balanced co-optimization of KL divergence and refusal count."
        ),
    )

    kl_divergence_target: float = Field(
        default=0.01,
        description=(
            "The KL divergence to target. Below this value, an objective based on the refusal count is used."
            'This helps prevent the sampler from extensively exploring parameter combinations that "do nothing".'
        ),
    )

    n_trials: int = Field(
        default=200,
        description="Number of abliteration trials to run during optimization.",
    )

    n_startup_trials: int = Field(
        default=60,
        description="Number of trials that use random sampling for the purpose of exploration.",
    )

    study_checkpoint_dir: str = Field(
        default="checkpoints",
        description="Directory to save and load study progress to/from:",
    )

    seed_params_dir: str = Field(
        default="seed_params",
        description="Directory for seed parameter files. Files are auto-named based on model.",
    )

    use_seed_params: bool = Field(
        default=True,
        description="Whether to load and use seed parameters from prior good trials if available.",
    )

    refusal_markers: list[str] = Field(
        default=[
            "sorry",
            "i can'",
            "i cant",
            "i cannot",
            "i won'",
            "i wont",
            "i will not",
            "i unable",
            "im unable",
            "i'm unable",
            "i am unable",
            "i an ai",
            "im an ai",
            "i'm an ai",
            "i am an ai",
            "as an ai",
            "ai assistant",
            "i designed to",
            "im designed to",
            "i'm designed to",
            "i am designed to",
            "i programmed to",
            "im programmed to",
            "i'm programmed to",
            "i am programmed to",
            "violat",
            "prohibit",
            "illegal",
            "harmful",
            "inappropriate",
            "unethical",
            "ethical boundaries",
        ],
        description="Strings whose presence in a response (case insensitive) identifies the response as a refusal.",
    )

    semantic_refusal_detection: bool = Field(
        default=False,
        description="Use embedding-based semantic similarity to detect refusals (more accurate but slower).",
    )

    semantic_refusal_threshold: float = Field(
        default=0.75,
        description="Cosine similarity threshold for semantic refusal detection (0.0-1.0).",
    )

    semantic_refusal_model: str = Field(
        default="sentence-transformers/all-MiniLM-L6-v2",
        description="Model to use for semantic refusal detection embeddings.",
    )

    use_pca_directions: bool = Field(
        default=False,
        description="Use PCA/SVD to find multiple refusal directions instead of just mean difference.",
    )

    num_pca_directions: int = Field(
        default=3,
        description="Number of principal components to extract when use_pca_directions is enabled.",
    )

    combine_directions: bool = Field(
        default=False,
        description="Allow optimizer to combine multiple PCA directions with tunable weights (requires use_pca_directions).",
    )

    multi_position_residuals: bool = Field(
        default=False,
        description="Extract residuals from multiple token positions (last 3 + mid) for richer direction calculation.",
    )

    residual_positions: list[int] = Field(
        default=[-1, -2, -3],
        description="Token positions to extract residuals from when multi_position_residuals is enabled. Negative indices count from end.",
    )

    projected_direction: bool = Field(
        default=False,
        description="Orthogonalize refusal direction against harmless direction for cleaner ablation.",
    )

    concept_atoms: bool = Field(
        default=False,
        description="Clean refusal direction using concept atom orthogonalization (SRA).",
    )

    concept_atom_ridge: float = Field(
        default=0.1,
        description="Ridge regularization strength for concept atom orthogonalization.",
    )

    ablation_rank: int = Field(
        default=1,
        ge=1,
        le=8,
        description="LoRA rank for ablation. Higher rank captures more of the refusal subspace (1=original, 3-5=recommended).",
    )

    norm_preserve: bool = Field(
        default=False,
        description="Preserve weight row norms during ablation (recommended for better capability retention).",
    )

    sparsity_threshold: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description="Threshold for zeroing low-magnitude entries in lora_A (0.0 = disabled). Applied as fraction of max absolute value.",
    )

    partial_projection: bool = Field(
        default=False,
        description="Enable partial projection scaling (Optuna tunes the removal strength 0.1-1.0).",
    )

    adaptive_layer_selection: bool = Field(
        default=False,
        description="Skip layers with low refusal separability during ablation.",
    )

    per_head_ablation: bool = Field(
        default=False,
        description="Enable per-head ablation - allows targeting specific attention heads rather than all heads.",
    )

    head_ablation_fraction: float = Field(
        default=0.5,
        description="Base fraction of attention heads to ablate (0.0-1.0). Optuna will optimize around this value.",
    )

    weight_svd_guard: bool = Field(
        default=False,
        description="Project refusal directions away from top singular vectors of each weight matrix to protect capability-critical subspace.",
    )

    svd_guard_rank: int = Field(
        default=3,
        ge=1,
        le=20,
        description="Number of top singular vectors to protect when weight_svd_guard is enabled.",
    )

    system_prompt: str = Field(
        default="You are a helpful assistant.",
        description="System prompt to use when prompting the model.",
    )

    good_prompts: DatasetSpecification = Field(
        default=DatasetSpecification(
            dataset="mlabonne/harmless_alpaca",
            split="train[:400]",
            column="text",
            residual_plot_label='"Harmless" prompts',
            residual_plot_color="royalblue",
        ),
        description="Dataset of prompts that tend to not result in refusals (used for calculating refusal directions).",
    )

    bad_prompts: DatasetSpecification = Field(
        default=DatasetSpecification(
            dataset="mlabonne/harmful_behaviors",
            split="train[:400]",
            column="text",
            residual_plot_label='"Harmful" prompts',
            residual_plot_color="darkorange",
        ),
        description="Dataset of prompts that tend to result in refusals (used for calculating refusal directions).",
    )

    good_evaluation_prompts: DatasetSpecification = Field(
        default=DatasetSpecification(
            dataset="mlabonne/harmless_alpaca",
            split="test[:100]",
            column="text",
        ),
        description="Dataset of prompts that tend to not result in refusals (used for evaluating model performance).",
    )

    bad_evaluation_prompts: DatasetSpecification = Field(
        default=DatasetSpecification(
            dataset="mlabonne/harmful_behaviors",
            split="test[:100]",
            column="text",
        ),
        description="Dataset of prompts that tend to result in refusals (used for evaluating model performance).",
    )

    dashboard: bool = Field(
        default=True,
        description="Enable live dashboard during optimization (press 'v' for verbose, 's' for summary, 'q' to quit).",
    )

    @field_validator("gpu_devices")
    @classmethod
    def validate_gpu_devices(cls, v: list[int] | None) -> list[int] | None:
        if v is not None and any(i < 0 for i in v):
            raise ValueError("gpu_devices indices must be non-negative")
        return v

    @field_validator("semantic_refusal_threshold")
    @classmethod
    def validate_semantic_refusal_threshold(cls, v: float) -> float:
        if not 0.0 <= v <= 1.0:
            raise ValueError("semantic_refusal_threshold must be between 0.0 and 1.0")
        return v

    @field_validator("num_pca_directions")
    @classmethod
    def validate_num_pca_directions(cls, v: int) -> int:
        if v < 1:
            raise ValueError("num_pca_directions must be >= 1")
        return v

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (
            init_settings,  # Used during resume - should override *all* other sources.
            CliSettingsSource(
                settings_cls,
                cli_parse_args=True,
                cli_implicit_flags=True,
                cli_kebab_case=True,
            ),
            EnvSettingsSource(settings_cls, env_prefix="REAPER_"),
            dotenv_settings,
            file_secret_settings,
            TomlConfigSettingsSource(settings_cls, toml_file="config.toml"),
        )
