# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

import os
import signal
import sys
import threading
import time
from importlib.metadata import PackageNotFoundError, version

from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.columns import Columns

from .seed_management import get_pareto_optimal
from .utils import format_duration, get_gpu_info


class Dashboard:
    """Live dashboard for Reaper Abliteration optimization loop."""

    def __init__(self, n_trials: int, n_bad_prompts: int):
        self.n_trials = n_trials
        self.n_bad_prompts = n_bad_prompts
        self.current_trial = 0
        self.start_time = time.time()
        self.pareto_front: list[dict] = []
        self.current_status = "Initializing..."
        self.verbose = False
        self.verbose_lines: list[str] = []
        self._live: Live | None = None
        self._input_thread: threading.Thread | None = None
        self._stop_input = threading.Event()
        self._console = Console(force_terminal=True)
        # Additional tracking
        self.trial_times: list[float] = []
        self.first_kl: float | None = None
        self.first_refusals: int | None = None

    def _input_loop(self) -> None:
        """Read keyboard input in a background thread."""
        import select
        import termios
        import tty

        old_settings = termios.tcgetattr(sys.stdin)
        try:
            tty.setcbreak(sys.stdin.fileno())
            while not self._stop_input.is_set():
                if select.select([sys.stdin], [], [], 0.1)[0]:
                    ch = sys.stdin.read(1)
                    if ch == "v":
                        self.verbose = True
                        self.refresh()
                    elif ch == "s":
                        self.verbose = False
                        self.refresh()
                    elif ch == "q":
                        os.kill(os.getpid(), signal.SIGINT)
        except Exception:
            pass
        finally:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)

    def __enter__(self) -> "Dashboard":
        self.start_time = time.time()
        self._live = Live(
            self._render(),
            console=self._console,
            refresh_per_second=4,
            screen=True,
        )
        self._live.__enter__()
        self._stop_input.clear()
        self._input_thread = threading.Thread(target=self._input_loop, daemon=True)
        self._input_thread.start()
        return self

    def __exit__(self, *args) -> None:
        self._stop_input.set()
        if self._input_thread:
            self._input_thread.join(timeout=1)
        if self._live:
            self._live.__exit__(*args)

    def _eta(self) -> str:
        if self.current_trial == 0:
            return "calculating..."
        elapsed = time.time() - self.start_time
        rate = elapsed / self.current_trial
        remaining = rate * (self.n_trials - self.current_trial)
        return format_duration(remaining)

    def _elapsed(self) -> str:
        return format_duration(time.time() - self.start_time)

    def _avg_trial_time(self) -> str:
        if not self.trial_times:
            return "-"
        avg = sum(self.trial_times[-20:]) / len(self.trial_times[-20:])
        return f"{avg:.1f}s"

    def _render(self) -> Panel:
        try:
            ver = version('reaper-abliteration')
        except PackageNotFoundError:
            ver = "?.?.?"
        title = f"REAPER v{ver} - Live Dashboard"

        if self.verbose:
            lines = self.verbose_lines[-20:] if self.verbose_lines else ["No output yet"]
            content = Text("\n".join(lines))
        else:
            # LEFT COLUMN: Progress + Pareto
            pct = (self.current_trial / self.n_trials * 100) if self.n_trials > 0 else 0
            bar_width = 30
            filled = int(bar_width * self.current_trial / self.n_trials) if self.n_trials > 0 else 0
            bar = "█" * filled + "░" * (bar_width - filled)

            left_lines = [
                Text(f"Progress: {bar} {self.current_trial}/{self.n_trials} ({pct:.1f}%)"),
                Text(f"Elapsed: {self._elapsed()}  |  ETA: {self._eta()}"),
                Text(""),
                Text("PARETO FRONT (Top 5):", style="bold cyan"),
            ]

            table = Table(box=None, padding=(0, 1), expand=False, show_header=True)
            table.add_column("Trial", style="cyan", width=7)
            table.add_column("KL", justify="right", width=8)
            table.add_column("Ref", justify="right", width=8)
            table.add_column("Direction", width=16)

            if self.pareto_front:
                for i, entry in enumerate(self.pareto_front[:5]):
                    marker = "★" if i == 0 else " "
                    trial_str = f"{marker}{entry['trial']:>3}"
                    kl_str = f"{entry['kl']:.4f}"
                    ref_str = f"{entry['refusals']}/{self.n_bad_prompts}"
                    params = entry.get('params', {})
                    dir_mode = params.get('direction_mode', 'mean')[:4]
                    dir_idx = params.get('direction_index')
                    if dir_idx is None:
                        dir_str = f"{dir_mode}/layer"
                    elif isinstance(dir_idx, float) and dir_idx == int(dir_idx):
                        dir_str = f"{dir_mode}@{int(dir_idx)}"
                    else:
                        dir_str = f"{dir_mode}@{dir_idx}"
                    table.add_row(trial_str, kl_str, ref_str, dir_str)
            else:
                table.add_row("-", "-", "-", "waiting...")

            left_content = Group(*left_lines, table)

            # RIGHT COLUMN: Stats + Current Trial
            right_lines = [
                Text("STATISTICS:", style="bold cyan"),
                Text(f"  Avg trial time: {self._avg_trial_time()}"),
                Text(f"  Trials/hour: {self._trials_per_hour():.0f}" if self.current_trial > 0 else "  Trials/hour: -"),
                Text(""),
                Text("BEST RESULT:", style="bold green"),
            ]

            if self.pareto_front:
                best = self.pareto_front[0]
                right_lines.append(Text(f"  Trial #{best['trial']}"))
                right_lines.append(Text(f"  KL Divergence: {best['kl']:.4f}"))
                right_lines.append(Text(f"  Refusals: {best['refusals']}/{self.n_bad_prompts}"))
                if self.first_kl and self.first_refusals is not None:
                    kl_improve = ((self.first_kl - best['kl']) / self.first_kl * 100) if self.first_kl > 0 else 0
                    ref_improve = self.first_refusals - best['refusals']
                    right_lines.append(Text(""))
                    right_lines.append(Text("IMPROVEMENT:", style="bold yellow"))
                    right_lines.append(Text(f"  KL: {kl_improve:+.1f}%"))
                    right_lines.append(Text(f"  Refusals: {ref_improve:+d}"))
            else:
                right_lines.append(Text("  (waiting for data)"))

            right_lines.extend([
                Text(""),
                Text("CURRENT:", style="bold"),
                Text(f"  {self.current_status}", style="dim"),
            ])

            # GPU memory section
            gpu_info = get_gpu_info()
            if gpu_info:
                right_lines.append(Text(""))
                right_lines.append(Text("GPU MEMORY:", style="bold magenta"))
                for gpu in gpu_info:
                    bar_w = 12
                    filled = int(bar_w * gpu["pct"] / 100)
                    bar = "█" * filled + "░" * (bar_w - filled)
                    # Color based on usage: green < 70%, yellow 70-90%, red > 90%
                    if gpu["pct"] >= 90:
                        style = "red"
                    elif gpu["pct"] >= 70:
                        style = "yellow"
                    else:
                        style = "green"
                    right_lines.append(Text(
                        f"  GPU{gpu['index']}: {bar} {gpu['used_gb']:.1f}/{gpu['total_gb']:.0f}GB ({gpu['pct']}%)",
                        style=style
                    ))

            right_content = Group(*right_lines)

            # Combine columns
            content = Columns([left_content, right_content], expand=True, padding=(0, 2))

        footer = Text("  v: verbose | s: summary | q: quit | Ctrl+C: stop", style="dim")

        return Panel(
            Group(content, Text(""), footer),
            title=title,
            border_style="cyan",
        )

    def _trials_per_hour(self) -> float:
        if self.current_trial == 0:
            return 0
        elapsed = time.time() - self.start_time
        return (self.current_trial / elapsed) * 3600

    def refresh(self) -> None:
        if self._live:
            self._live.update(self._render())

    def update_trial(self, trial_num: int, status: str) -> None:
        self.current_trial = trial_num
        self.current_status = status
        self.refresh()

    def record_trial_time(self, duration: float) -> None:
        self.trial_times.append(duration)

    def add_verbose_line(self, line: str) -> None:
        try:
            clean_line = Text.from_markup(line).plain
        except Exception:
            clean_line = line
        self.verbose_lines.append(clean_line.strip())
        if len(self.verbose_lines) > 200:
            self.verbose_lines = self.verbose_lines[-200:]

    def update_pareto(self, trials: list[dict]) -> None:
        if not trials:
            return
        # Map dashboard keys to seed_management keys for get_pareto_optimal
        mapped = [{"kl_divergence": t["kl"], "refusals": t["refusals"], "_orig": t} for t in trials]
        pareto = get_pareto_optimal(mapped, max_count=len(trials))
        self.pareto_front = [p["_orig"] for p in pareto]

        # Track first and best for improvement calc
        if self.pareto_front:
            if self.first_kl is None:
                self.first_kl = self.pareto_front[-1]['kl']
                self.first_refusals = self.pareto_front[-1]['refusals']
        self.refresh()

