# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

from __future__ import annotations

import warnings
from pathlib import Path
from typing import TYPE_CHECKING

import huggingface_hub
import torch
from huggingface_hub import ModelCard, ModelCardData
from questionary import Choice

from .config import QuantizationMethod, Settings
from .model import Model, get_model_class
from .utils import (
    Prompt,
    empty_cache,
    get_readme_intro,
    print,
    prompt_password,
    prompt_select,
    prompt_text,
)

if TYPE_CHECKING:
    from .parallel_model import ParallelModel


def obtain_merge_strategy(settings: Settings) -> str | None:
    """
    Prompts the user for how to proceed with saving the model.
    Provides info to the user if the model is quantized on memory use.
    Returns "merge", "adapter", or None (if cancelled/invalid).
    """

    # Prompt for all PEFT models to ensure user is aware of merge implications
    if settings.quantization == QuantizationMethod.BNB_4BIT:
        # Quantized models need special handling - we must reload the base model
        # in full precision to merge the LoRA adapters
        print()
        print(
            "[yellow]Model was loaded with quantization. Merging requires reloading the base model.[/]"
        )
        print(
            "[red](!) WARNING: CPU Merging requires dequantizing the entire model to System RAM.[/]"
        )
        print("[red]    This can lead to SYSTEM FREEZES if you run out of memory.[/]")
        print(
            "[yellow]    Rule of thumb: You need approx. 3x the parameter count in GB.[/]"
        )

        try:
            # Estimate memory requirements by loading the model structure on the "meta" device.
            # This doesn't consume actual RAM but allows us to inspect the parameter count/dtype.
            #
            # Suppress warnings during meta device loading (e.g., "Some weights were not initialized").
            # These are expected and harmless since we're only inspecting model structure, not running inference.
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                meta_model = get_model_class(settings.model).from_pretrained(
                    settings.model,
                    device_map="meta",
                    torch_dtype=torch.bfloat16,
                    trust_remote_code=settings.trust_remote_code,
                )
                footprint_bytes = meta_model.get_memory_footprint()
                footprint_gb = footprint_bytes / (1024**3)
                print(
                    f"[yellow]    Estimated net RAM required for model weights (excluding overhead): [bold]~{footprint_gb:.1f} GB[/][/]"
                )
        except Exception as e:
            # Fallback if meta loading fails (e.g. owing to custom model code
            # or `bitsandbytes` quantization config issues on the meta device)
            print(
                f"[yellow]    Could not estimate memory ({type(e).__name__}). "
                "Example: A 27B model requires ~80GB RAM. A 70B model requires ~200GB RAM.[/]"
            )
        print()

    merge_choice = prompt_select(
        "How do you want to proceed?",
        choices=[
            Choice(
                title="Merge full model"
                + (
                    ""
                    if settings.quantization == QuantizationMethod.NONE
                    else " (reload base model on CPU - requires high RAM)"
                ),
                value="merge",
            ),
            Choice(
                title="Save LoRA adapter only (can be merged later with llama.cpp or more RAM)",
                value="adapter",
            ),
        ],
    )
    return merge_choice


def save_model(
    model: Model | ParallelModel,
    save_directory: str,
    settings: Settings,
    strategy: str | None = None,
) -> None:
    print("Saving model...")
    if strategy is None:
        strategy = obtain_merge_strategy(settings)
        if strategy is None:
            print("[yellow]Action cancelled.[/]")
            return

    if strategy == "adapter":
        assert model.model is not None
        model.model.save_pretrained(save_directory)
    else:
        merged_model = model.get_merged_model()
        merged_model.save_pretrained(save_directory)
        del merged_model
        empty_cache()

    model.tokenizer.save_pretrained(save_directory)

    print(f"Model saved to [bold]{save_directory}[/].")


def upload_model(
    model: Model | ParallelModel,
    settings: Settings,
    trial,
    base_refusals: int,
    bad_prompts: list[Prompt],
) -> None:
    # We don't use huggingface_hub.login() because that stores the token on disk,
    # and since this program will often be run on rented or shared GPU servers,
    # it's better to not persist credentials.
    token = huggingface_hub.get_token()
    if not token:
        token = prompt_password("Hugging Face access token:")
    if not token:
        return

    user = huggingface_hub.whoami(token)
    fullname = user.get(
        "fullname",
        user.get("name", "unknown user"),
    )
    email = user.get("email", "no email found")
    print(f"Logged in as [bold]{fullname} ({email})[/]")

    repo_id = prompt_text(
        "Name of repository:",
        default=f"{user['name']}/{Path(settings.model).name}-abliterated",
    )
    if not repo_id:
        return

    visibility = prompt_select(
        "Should the repository be public or private?",
        [
            "Public",
            "Private",
        ],
    )
    if not visibility:
        return
    private = visibility == "Private"

    strategy = obtain_merge_strategy(settings)
    if strategy is None:
        print("[yellow]Action cancelled.[/]")
        return

    if strategy == "adapter":
        print("Uploading LoRA adapter...")
        assert model.model is not None
        model.model.push_to_hub(
            repo_id,
            private=private,
            token=token,
        )
    else:
        print("Uploading merged model...")
        merged_model = model.get_merged_model()
        merged_model.push_to_hub(
            repo_id,
            private=private,
            token=token,
        )
        del merged_model
        empty_cache()

    model.tokenizer.push_to_hub(
        repo_id,
        private=private,
        token=token,
    )

    # If the model path doesn't exist locally, it can be assumed
    # to be a model hosted on the Hugging Face Hub, in which case
    # we can retrieve the model card.
    if not Path(settings.model).exists():
        card = ModelCard.load(settings.model)
        if card.data is None:
            card.data = ModelCardData()
        if card.data.tags is None:
            card.data.tags = []
        card.data.tags.append("reaper-abliteration")
        card.data.tags.append("uncensored")
        card.data.tags.append("decensored")
        card.data.tags.append("abliterated")
        card.text = (
            get_readme_intro(
                settings,
                trial,
                base_refusals,
                bad_prompts,
            )
            + card.text
        )
        card.push_to_hub(repo_id, token=token)

    print(f"Model uploaded to [bold]{repo_id}[/].")
