# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

import math
import os
import sys
import time
import warnings
from importlib.metadata import version
from os.path import commonprefix

import optuna
import torch
import torch.nn.functional as F
import transformers
from accelerate.utils import (
    is_mlu_available,
    is_musa_available,
    is_npu_available,
    is_sdaa_available,
    is_xpu_available,
)
from optuna.exceptions import ExperimentalWarning
from optuna.samplers import TPESampler
from optuna.storages import JournalStorage
from optuna.storages.journal import JournalFileBackend, JournalFileOpenLock
from optuna.study import StudyDirection
from optuna.trial import TrialState
from pydantic import ValidationError
from questionary import Choice
from rich.traceback import install

from .analyzer import Analyzer
from .config import Settings
from .seed_management import get_pareto_optimal
from .evaluator import Evaluator
from .export import save_model, upload_model
from .model import AbliterationParameters, Model
from .optimization import run_optimization_loop
from .parallel_model import ParallelModel, can_use_parallel_model
from .utils import (
    Prompt,
    empty_cache,
    get_gpu_info,
    get_trial_parameters,
    load_prompts,
    log_gpu_utilization,
    print,
    prompt_path,
    prompt_select,
    prompt_text,
)


# Known model prefixes - bypass detection for models with known CoT patterns.
# This avoids issues with pipeline parallelism where numerical divergence
# causes commonprefix() to fail even though all responses use the same format.
KNOWN_MODEL_PREFIXES = {
    "gpt-oss": "<|channel|>analysis<|message|><|end|><|start|>assistant<|channel|>final<|message|>",
}

# Capability probing prompts for Surgical Refusal Ablation (SRA).
# Used to extract concept atom directions that protect capability circuits
# during refusal direction orthogonalization.
CAPABILITY_PROBES = {
    "math": [
        "Solve: What is the derivative of x^3 + 2x?",
        "Calculate the integral of sin(x) from 0 to pi.",
        "If f(x) = e^(2x), find f'(x).",
        "What is 247 * 83?",
        "Simplify: (x^2 - 9) / (x - 3)",
    ],
    "code": [
        "Write a Python function to check if a number is prime.",
        "Implement binary search in Python.",
        "Write a function to reverse a linked list.",
        "How do you sort a dictionary by values in Python?",
        "Write a recursive fibonacci function.",
    ],
    "reasoning": [
        "Explain the trolley problem and its ethical implications.",
        "What are the main differences between TCP and UDP?",
        "Describe how a hash table works and its time complexity.",
        "What is the difference between correlation and causation?",
        "Explain the concept of supply and demand.",
    ],
}


def run():
    # Enable expandable segments to reduce memory fragmentation on multi-GPU setups.
    if (
        "PYTORCH_ALLOC_CONF" not in os.environ
        and "PYTORCH_CUDA_ALLOC_CONF" not in os.environ
    ):
        os.environ["PYTORCH_ALLOC_CONF"] = "expandable_segments:True"

    # ASCII art banner
    print(f"[cyan]█▀▄░█▀▀░█▀█░█▀█░█▀▀░█▀▄[/]  v{version('reaper-abliteration')}")
    print("[cyan]█▀▄░█▀▀░█▀█░█▀▀░█▀▀░█▀▄[/]")
    print(
        "[cyan]▀░▀░▀▀▀░▀░▀░▀░░░▀▀▀░▀░▀[/]  [blue underline]https://github.com/hauhaut/reaper-abliteration[/]"
    )
    print()

    if "--version" in sys.argv or "-V" in sys.argv:
        print(f"reaper-abliteration {version('reaper-abliteration')}")
        return

    if (
        # There is at least one argument (argv[0] is the program name).
        len(sys.argv) > 1
        # No model has been explicitly provided.
        and "--model" not in sys.argv
        # The last argument is a parameter value rather than a flag (such as "--help").
        and not sys.argv[-1].startswith("-")
    ):
        # Assume the last argument is the model.
        sys.argv.insert(-1, "--model")

    try:
        # The required argument "model" must be provided by the user,
        # either on the command line or in the configuration file.
        settings = Settings()  # ty:ignore[missing-argument]
    except ValidationError as error:
        print(f"[red]Configuration contains [bold]{error.error_count()}[/] errors:[/]")

        for error in error.errors():
            print(f"[bold]{error['loc'][0]}[/]: [yellow]{error['msg']}[/]")

        print()
        print(
            "Run [bold]abliterate --help[/] or see [bold]config.toml[/] for details about configuration parameters."
        )
        return

    # Adapted from https://github.com/huggingface/accelerate/blob/main/src/accelerate/commands/env.py
    # Track total GPU memory for batch size scaling
    total_gpu_memory_gb = 0.0
    gpu_count = 0

    if torch.cuda.is_available():
        gpus = get_gpu_info()
        gpu_count = len(gpus)
        print(f"Detected [bold]{gpu_count}[/] CUDA device(s):")
        for gpu in gpus:
            print(f"* GPU {gpu['index']}: [bold]{gpu['name']}[/] ({gpu['memory_gb']:.1f} GB)")
        total_gpu_memory_gb = sum(g["memory_gb"] for g in gpus)
        if gpu_count > 1:
            print(f"Total GPU memory: [bold]{total_gpu_memory_gb:.1f} GB[/] (from {gpu_count} devices)")
    elif is_xpu_available():
        count = torch.xpu.device_count()
        gpu_count = count
        print(f"Detected [bold]{count}[/] XPU device(s):")
        for i in range(count):
            print(f"* XPU {i}: [bold]{torch.xpu.get_device_name(i)}[/]")
    elif is_mlu_available():
        count = torch.mlu.device_count()  # ty:ignore[unresolved-attribute]
        gpu_count = count
        print(f"Detected [bold]{count}[/] MLU device(s):")
        for i in range(count):
            print(f"* MLU {i}: [bold]{torch.mlu.get_device_name(i)}[/]")  # ty:ignore[unresolved-attribute]
    elif is_sdaa_available():
        count = torch.sdaa.device_count()  # ty:ignore[unresolved-attribute]
        gpu_count = count
        print(f"Detected [bold]{count}[/] SDAA device(s):")
        for i in range(count):
            print(f"* SDAA {i}: [bold]{torch.sdaa.get_device_name(i)}[/]")  # ty:ignore[unresolved-attribute]
    elif is_musa_available():
        count = torch.musa.device_count()  # ty:ignore[unresolved-attribute]
        gpu_count = count
        print(f"Detected [bold]{count}[/] MUSA device(s):")
        for i in range(count):
            print(f"* MUSA {i}: [bold]{torch.musa.get_device_name(i)}[/]")  # ty:ignore[unresolved-attribute]
    elif is_npu_available():
        gpu_count = 1
        print(f"NPU detected (CANN version: [bold]{torch.version.cann}[/])")  # ty:ignore[unresolved-attribute]
    elif torch.backends.mps.is_available():
        gpu_count = 1
        print("Detected [bold]1[/] MPS device (Apple Metal)")
    else:
        print(
            "[bold yellow]No GPU or other accelerator detected. Operations will be slow.[/]"
        )

    # We don't need gradients as we only do inference.
    torch.set_grad_enabled(False)

    # While determining the optimal batch size, we will try many different batch sizes,
    # resulting in many computation graphs being compiled. Raising the limit (default = 8)
    # avoids errors from TorchDynamo assuming that something is wrong because we
    # recompile too often.
    torch._dynamo.config.cache_size_limit = 64

    # Silence warning spam from Transformers.
    # In my entire career I've never seen a useful warning from that library.
    transformers.logging.set_verbosity_error()

    # We do our own trial logging, so we don't need the INFO messages
    # about parameters and results.
    optuna.logging.set_verbosity(optuna.logging.WARNING)

    # Silence the warning about multivariate TPE being experimental.
    warnings.filterwarnings("ignore", category=ExperimentalWarning)

    # Generate model-specific filename base
    model_filename_base = "".join(
        [(c if (c.isalnum() or c in ["_", "-"]) else "--") for c in settings.model]
    )

    study_checkpoint_file = os.path.join(
        settings.study_checkpoint_dir,
        model_filename_base + ".jsonl",
    )

    seed_params_file = os.path.join(
        settings.seed_params_dir,
        model_filename_base + ".json",
    )

    os.makedirs(settings.study_checkpoint_dir, exist_ok=True)
    os.makedirs(settings.seed_params_dir, exist_ok=True)
    lock_obj = JournalFileOpenLock(study_checkpoint_file)
    backend = JournalFileBackend(study_checkpoint_file, lock_obj=lock_obj)
    storage = JournalStorage(backend)

    try:
        existing_study = storage.get_all_studies()[0]
        study_name = existing_study.study_name
    except IndexError:
        existing_study = None
        study_name = None

    is_restart = False
    if existing_study is not None:
        # A study is in here. Check if it's finished.
        choices = []
        if existing_study.user_attrs.get("finished", False):
            print(
                "[green]You have already processed this model. How would you like to proceed?[/]"
            )
            choices.append(
                Choice(
                    title="Show the results from the previous run, allowing you to export models, or to run additional trials.",
                    value="continue",
                )
            )
        else:
            print(
                "[yellow]You have already processed this model, but the run was interrupted. How would you like to proceed?[/]",
            )
            choices.append(
                Choice(
                    title="Continue the previous run from where it stopped (will override all specified settings).",
                    value="continue",
                )
            )
        choices.append(
            Choice(
                title="Ignore the previous run and start from scratch. This will delete the checkpoint file and all results from the previous run.",
                value="restart",
            )
        )
        choice = prompt_select("", choices)

        if choice == "continue":
            settings = Settings.model_validate_json(
                existing_study.user_attrs["settings"]
            )
        elif choice == "restart":
            is_restart = True
            try:
                os.unlink(study_checkpoint_file)
            except OSError as e:
                print(f"[yellow]Warning: could not delete checkpoint: {e}[/]")
            lock_obj = JournalFileOpenLock(study_checkpoint_file)
            backend = JournalFileBackend(study_checkpoint_file, lock_obj=lock_obj)
            storage = JournalStorage(backend)
        else:
            print("Cancelled; exiting.")
            return

    # Use ParallelModel for true data parallelism if conditions are met
    use_parallel = can_use_parallel_model(settings)
    if use_parallel:
        print()
        print("[bold cyan]Using ParallelModel for true multi-GPU data parallelism[/]")
        model = ParallelModel(settings, settings.gpu_devices)
    else:
        model = Model(settings)

    print()
    print(f"Loading good prompts from [bold]{settings.good_prompts.dataset}[/]...")
    good_prompts = load_prompts(settings, settings.good_prompts)
    if not good_prompts:
        raise ValueError(f"No prompts loaded from {settings.good_prompts.dataset} (split: {settings.good_prompts.split})")
    print(f"* [bold]{len(good_prompts)}[/] prompts loaded")

    print()
    print(f"Loading bad prompts from [bold]{settings.bad_prompts.dataset}[/]...")
    bad_prompts = load_prompts(settings, settings.bad_prompts)
    if not bad_prompts:
        raise ValueError(f"No prompts loaded from {settings.bad_prompts.dataset} (split: {settings.bad_prompts.split})")
    print(f"* [bold]{len(bad_prompts)}[/] prompts loaded")

    if settings.batch_size == 0:
        print()
        print("Determining optimal batch size...")

        # Scale max batch size based on total GPU memory (24GB ~= 64 batch size baseline)
        if total_gpu_memory_gb > 0:
            scaled_max = max(1, int(total_gpu_memory_gb / 24 * 64))
            effective_max = min(settings.max_batch_size, scaled_max)
            if effective_max != settings.max_batch_size:
                print(f"* Scaling max batch size to [bold]{effective_max}[/] based on {total_gpu_memory_gb:.1f} GB total GPU memory")
        else:
            effective_max = settings.max_batch_size

        batch_size = 1
        best_batch_size = -1
        best_performance = -1

        while batch_size <= effective_max:
            print(f"* Trying batch size [bold]{batch_size}[/]... ", end="")

            prompts = good_prompts * math.ceil(batch_size / len(good_prompts))
            prompts = prompts[:batch_size]

            try:
                # Warmup run to build the computation graph so that part isn't benchmarked.
                model.get_responses(prompts)
                if gpu_count > 1:
                    log_gpu_utilization()

                start_time = time.perf_counter()
                responses = model.get_responses(prompts)
                end_time = time.perf_counter()
            except Exception as error:
                if batch_size == 1:
                    # Even a batch size of 1 already fails.
                    # We cannot recover from this.
                    raise

                print(f"[red]Failed[/] ({error})")
                break

            response_lengths = [
                len(model.tokenizer.encode(response)) for response in responses
            ]
            performance = sum(response_lengths) / (end_time - start_time)

            print(f"[green]Ok[/] ([bold]{performance:.0f}[/] tokens/s)")

            if performance > best_performance:
                best_batch_size = batch_size
                best_performance = performance

            batch_size *= 2

        if best_batch_size < 1:
            raise RuntimeError(
                f"Batch size auto-detection failed: effective_max={effective_max}. "
                "Set --batch-size manually."
            )

        settings.batch_size = best_batch_size
        # Sync batch size to ParallelModel replicas if using parallel mode
        if isinstance(model, ParallelModel):
            model.set_batch_size(best_batch_size)
        print(f"* Chosen batch size: [bold]{settings.batch_size}[/]")

    print()
    print("Checking for common response prefix...")

    model_lower = settings.model.lower()
    known_prefix = None
    for model_pattern, prefix in KNOWN_MODEL_PREFIXES.items():
        if model_pattern in model_lower:
            known_prefix = prefix
            break

    if known_prefix:
        model.response_prefix = known_prefix
        print(f"* Prefix set for known model: [bold]{model.response_prefix!r}[/]")
    else:
        responses = model.get_responses_batched(good_prompts[:100] + bad_prompts[:100])

        # Despite being located in os.path, commonprefix actually performs
        # a naive string operation without any path-specific logic,
        # which is exactly what we need here. Trailing spaces are removed
        # to avoid issues where multiple different tokens that all start
        # with a space character lead to the common prefix ending with
        # a space, which would result in an uncommon tokenization.
        model.response_prefix = commonprefix(responses).rstrip(" ")

        # Suppress CoT output.
        if model.response_prefix.startswith("<think>"):
            # Most thinking models.
            model.response_prefix = "<think></think>"
        elif model.response_prefix.startswith("<|channel|>analysis<|message|>"):
            # gpt-oss (fallback if not caught above).
            model.response_prefix = "<|channel|>analysis<|message|><|end|><|start|>assistant<|channel|>final<|message|>"
        elif model.response_prefix.startswith("<thought>"):
            # Unknown, suggested by user.
            model.response_prefix = "<thought></thought>"
        elif model.response_prefix.startswith("[THINK]"):
            # Unknown, suggested by user.
            model.response_prefix = "[THINK][/THINK]"

        if model.response_prefix:
            print(f"* Prefix found: [bold]{model.response_prefix!r}[/]")
        else:
            print("* None found")

    evaluator = Evaluator(settings, model)

    if settings.evaluate_model is not None:
        print()
        print(f"Loading model [bold]{settings.evaluate_model}[/]...")
        settings.model = settings.evaluate_model
        model.reset_model()
        print("* Evaluating...")
        evaluator.get_score(quick_eval=False)
        return

    print()
    print("Calculating per-layer refusal directions...")

    # Determine positions to extract residuals from
    positions = [-1]  # Default: last position only

    if settings.multi_position_residuals:
        positions = settings.residual_positions
        print(f"* Using multi-position residuals: positions {positions}")

    print("* Obtaining residuals for good prompts...")
    good_residuals = model.get_residuals_batched(good_prompts, positions)
    print("* Obtaining residuals for bad prompts...")
    bad_residuals = model.get_residuals_batched(bad_prompts, positions)

    # Handle multi-position residuals
    if len(positions) > 1:
        # Shape: (prompt, position, layer, component)
        # For mean direction, average across positions with equal weights
        # Trial can adjust weights via position_weights parameter
        good_residuals_combined = good_residuals.mean(dim=1)  # (prompt, layer, component)
        bad_residuals_combined = bad_residuals.mean(dim=1)
        # Store original for weighted combinations in trials
        good_residuals_multipos = good_residuals
        bad_residuals_multipos = bad_residuals
        good_residuals = good_residuals_combined
        bad_residuals = bad_residuals_combined
    else:
        good_residuals_multipos = None
        bad_residuals_multipos = None

    # Mean direction (original approach)
    mean_direction = F.normalize(
        bad_residuals.mean(dim=0) - good_residuals.mean(dim=0),
        p=2,
        dim=1,
    )

    if settings.projected_direction:
        harmless_dir = F.normalize(good_residuals.mean(dim=0), p=2, dim=1)
        dot = (mean_direction * harmless_dir).sum(dim=1, keepdim=True)
        mean_direction = F.normalize(mean_direction - dot * harmless_dir, p=2, dim=1)
        print("  * Applied projected direction (orthogonalized against harmless)")

    # Surgical Refusal Ablation: orthogonalize refusal direction against capability atoms
    if settings.concept_atoms:
        print("* Computing concept atom directions for SRA...")
        concept_directions = []
        for domain, prompts in CAPABILITY_PROBES.items():
            print(f"  * Probing {domain} capability ({len(prompts)} prompts)...")
            formatted = [Prompt(system=settings.system_prompt, user=p) for p in prompts]
            cap_residuals = model.get_residuals_batched(formatted, positions=[-1])
            if len(cap_residuals.shape) == 4:  # multi-position: (prompt, position, layer, hidden)
                cap_residuals = cap_residuals.mean(dim=1)
            # Mean activation direction per domain: (layer, hidden_dim)
            cap_direction = F.normalize(cap_residuals.mean(dim=0), p=2, dim=1)
            concept_directions.append(cap_direction)
            print(f"    {domain}: direction shape {cap_direction.shape}")

        # Ridge-regularized orthogonalization per layer
        ridge = settings.concept_atom_ridge
        print(f"  * Orthogonalizing against {len(concept_directions)} concept atoms (ridge={ridge})...")
        for layer_idx in range(mean_direction.shape[0]):
            refusal_vec = mean_direction[layer_idx]  # (hidden_dim,)
            R = torch.stack([cd[layer_idx] for cd in concept_directions])  # (n_atoms, hidden_dim)
            RRt = R @ R.T  # (n_atoms, n_atoms)
            RRt_reg = RRt + ridge * torch.eye(RRt.shape[0], device=RRt.device, dtype=RRt.dtype)
            coeffs = torch.linalg.solve(RRt_reg, R @ refusal_vec)  # (n_atoms,)
            mean_direction[layer_idx] = F.normalize(refusal_vec - R.T @ coeffs, p=2, dim=0)

        print("  * SRA orthogonalization complete")
        del concept_directions
        empty_cache()

    # Compute rank-k SVD directions when ablation_rank > 1
    svd_directions = None
    if settings.ablation_rank > 1:
        k = settings.ablation_rank
        print(f"* Computing rank-{k} SVD refusal directions...")
        diffs = bad_residuals - good_residuals  # (n_samples, num_layers+1, hidden_dim)
        svd_per_layer = []
        for layer_idx in range(diffs.shape[1]):
            layer_diffs = diffs[:, layer_idx, :]
            layer_diffs = layer_diffs - layer_diffs.mean(dim=0)
            try:
                _, _, Vh = torch.linalg.svd(layer_diffs, full_matrices=False)
                k_actual = min(k, Vh.shape[0])
                dirs = F.normalize(Vh[:k_actual], p=2, dim=1)  # (k_actual, hidden_dim)
                if k_actual < k:
                    warnings.warn(f"SVD layer {layer_idx}: rank {k_actual} < requested {k}, padding with mean direction", stacklevel=2)
                    pad = mean_direction[layer_idx].unsqueeze(0).repeat(k - k_actual, 1)
                    dirs = torch.cat([dirs, pad], dim=0)
                svd_per_layer.append(dirs)
            except RuntimeError:
                svd_per_layer.append(mean_direction[layer_idx].unsqueeze(0).repeat(k, 1))
        svd_directions = torch.stack(svd_per_layer)  # (num_layers+1, k, hidden_dim)

        # Apply projected_direction to each SVD direction
        if settings.projected_direction:
            harmless_dir = F.normalize(good_residuals.mean(dim=0), p=2, dim=1)  # (num_layers+1, hidden_dim)
            for i in range(k):
                dot = (svd_directions[:, i, :] * harmless_dir).sum(dim=1, keepdim=True)
                svd_directions[:, i, :] = F.normalize(svd_directions[:, i, :] - dot * harmless_dir, p=2, dim=1)

        # Apply concept atom orthogonalization to each SVD direction
        if settings.concept_atoms:
            ridge = settings.concept_atom_ridge
            concept_directions_cached = []
            for domain, prompts_list in CAPABILITY_PROBES.items():
                formatted = [Prompt(system=settings.system_prompt, user=p) for p in prompts_list]
                cap_residuals = model.get_residuals_batched(formatted, positions=[-1])
                if cap_residuals.ndim == 4:
                    cap_residuals = cap_residuals.mean(dim=1)
                concept_directions_cached.append(F.normalize(cap_residuals.mean(dim=0), p=2, dim=1))
            for layer_idx in range(svd_directions.shape[0]):
                R = torch.stack([cd[layer_idx] for cd in concept_directions_cached])
                RRt_reg = R @ R.T + ridge * torch.eye(R.shape[0], device=R.device, dtype=R.dtype)
                for i in range(k):
                    rv = svd_directions[layer_idx, i]
                    coeffs = torch.linalg.solve(RRt_reg, R @ rv)
                    svd_directions[layer_idx, i] = F.normalize(rv - R.T @ coeffs, p=2, dim=0)
            del concept_directions_cached

        print(f"  * SVD directions shape: {svd_directions.shape}")
        del diffs

    # Compute per-layer separability scores for adaptive layer selection
    layer_separability = None
    if settings.adaptive_layer_selection:
        # Separability = L2 norm of (bad_mean - good_mean) per layer
        layer_separability = (bad_residuals.mean(dim=0) - good_residuals.mean(dim=0)).norm(dim=1)
        # Normalize to [0, 1] range
        layer_separability = layer_separability / layer_separability[1:].max().clamp(min=1e-8)
        print(f"  * Layer separability range: {layer_separability.min():.3f} - {layer_separability.max():.3f}")

    # Compute PCA directions if enabled
    pca_directions = None
    direction_modes = ["mean"]

    if settings.use_pca_directions:
        print("* Computing PCA refusal directions...")
        # Compute per-sample differences: [num_samples, num_layers, hidden_dim]
        diffs = bad_residuals - good_residuals

        # For each layer, compute SVD to find principal directions
        num_layers = diffs.shape[1]
        num_pca = settings.num_pca_directions
        pca_directions = []

        for layer_idx in range(num_layers):
            layer_diffs = diffs[:, layer_idx, :]  # [num_samples, hidden_dim]
            # Center the data
            layer_diffs = layer_diffs - layer_diffs.mean(dim=0, keepdim=True)
            # SVD: U @ diag(S) @ Vh = layer_diffs
            # Vh rows are principal components
            try:
                _, _, Vh = torch.linalg.svd(layer_diffs, full_matrices=False)
                # Take top-k components, normalize
                top_k = min(num_pca, Vh.shape[0])
                layer_pca = F.normalize(Vh[:top_k], p=2, dim=1)  # [k, hidden_dim]
                pca_directions.append(layer_pca)
            except RuntimeError:
                # Fallback to mean if SVD fails
                pca_directions.append(mean_direction[layer_idx].unsqueeze(0).expand(num_pca, -1))

        # Stack: [num_pca, num_layers, hidden_dim]
        pca_directions = torch.stack([
            torch.stack([pca_directions[layer_idx][k] for layer_idx in range(num_layers)])
            for k in range(num_pca)
        ])

        direction_modes.extend([f"pca_{i+1}" for i in range(num_pca)])
        print(f"  * Extracted {num_pca} PCA directions per layer")

    analyzer = Analyzer(settings, model, good_residuals, bad_residuals)

    if settings.print_residual_geometry:
        analyzer.print_residual_geometry()

    if settings.plot_residuals:
        analyzer.plot_residuals()

    # We don't need the single-position residuals after computing refusal directions.
    # Keep multipos residuals for weighted combinations during trials if enabled.
    del good_residuals, bad_residuals, analyzer
    empty_cache()

    study = optuna.create_study(
        study_name=study_name,
        sampler=TPESampler(
            n_startup_trials=settings.n_startup_trials,
            n_ei_candidates=128,
            multivariate=True,
        ),
        storage=storage,
        directions=[StudyDirection.MINIMIZE, StudyDirection.MINIMIZE],
        load_if_exists=not is_restart,
    )

    study.set_user_attr("settings", settings.model_dump_json())
    study.set_user_attr("finished", False)

    _, run_more = run_optimization_loop(
        model=model,
        evaluator=evaluator,
        settings=settings,
        study=study,
        mean_direction=mean_direction,
        pca_directions=pca_directions,
        direction_modes=direction_modes,
        positions=positions,
        good_residuals_multipos=good_residuals_multipos,
        bad_residuals_multipos=bad_residuals_multipos,
        seed_params_file=seed_params_file,
        layer_separability=layer_separability,
        svd_directions=svd_directions,
    )

    while True:
        # If no trials at all have been evaluated, the study must have been stopped
        # by pressing Ctrl+C while the first trial was running. In this case, we just
        # re-raise the interrupt to invoke the standard handler defined below.
        completed_trials = [t for t in study.trials if t.state == TrialState.COMPLETE]
        if not completed_trials:
            raise KeyboardInterrupt

        # Get Pareto front via get_pareto_optimal (reuse the seed selection logic)
        trial_seeds = [
            {"trial": t, "refusals": t.user_attrs["refusals"], "kl_divergence": t.user_attrs["kl_divergence"]}
            for t in completed_trials
        ]
        best_trials = [s["trial"] for s in get_pareto_optimal(trial_seeds)]

        choices = [
            Choice(
                title=(
                    f"[Trial {trial.user_attrs['index']:>3}] "
                    f"Refusals: {trial.user_attrs['refusals']:>2}/{len(evaluator.bad_prompts)}, "
                    f"KL divergence: {trial.user_attrs['kl_divergence']:.4f}"
                ),
                value=trial,
            )
            for trial in best_trials
        ]

        choices.append(
            Choice(
                title="Continue optimization (run more trials)",
                value="continue",
            )
        )

        choices.append(
            Choice(
                title="None (exit program)",
                value="",
            )
        )

        print()
        print("[bold green]Optimization finished![/]")
        print()
        print(
            (
                "The following trials resulted in Pareto optimal combinations of refusals and KL divergence. "
                "After selecting a trial, you will be able to save the model, upload it to Hugging Face, "
                "or chat with it to test how well it works. You can return to this menu later to select a different trial. "
                "[yellow]Note that KL divergence values above 1 usually indicate significant damage to the original model's capabilities.[/]"
            )
        )

        while True:
            print()
            trial = prompt_select("Which trial do you want to use?", choices)

            if trial == "continue":
                n_more_trials = None
                while True:
                    try:
                        user_input = prompt_text("How many more trials do you want to run?")
                        if user_input is None:
                            break
                        n_more_trials = int(user_input)
                        if n_more_trials > 0:
                            break
                        print("[red]Please enter a number greater than 0.[/]")
                    except ValueError:
                        print("[red]Invalid input. Please enter a number.[/]")

                if n_more_trials is None:
                    continue
                settings.n_trials += n_more_trials
                study.set_user_attr("settings", settings.model_dump_json())
                study.set_user_attr("finished", False)
                run_more()
                break

            elif trial is None or trial == "":
                return

            print()
            print(f"Restoring model from trial [bold]{trial.user_attrs['index']}[/]...")
            print("* Parameters:")
            for name, value in get_trial_parameters(trial).items():
                print(f"  * {name} = [bold]{value}[/]")

            # Select appropriate directions based on trial's direction_mode
            if svd_directions is not None:
                # Rank-k: SVD directions are used directly
                restore_directions = svd_directions
            else:
                trial_direction_mode = trial.user_attrs.get("direction_mode", "mean")
                if trial_direction_mode == "combined":
                    dir_weights = trial.user_attrs.get("direction_weights", {})
                    restore_directions = float(dir_weights.get("mean", 0.0)) * mean_direction
                    if pca_directions is not None:
                        for i in range(pca_directions.shape[0]):
                            w = float(dir_weights.get(f"pca_{i+1}", 0.0))
                            restore_directions = restore_directions + w * pca_directions[i]
                    restore_directions = F.normalize(restore_directions, p=2, dim=1)
                elif trial_direction_mode == "mean" or pca_directions is None:
                    restore_directions = mean_direction
                else:
                    pca_idx = int(trial_direction_mode.split("_")[1]) - 1
                    restore_directions = pca_directions[pca_idx]

            # Restore head mask if it was used
            restore_head_mask = None
            if "head_mask" in trial.user_attrs:
                restore_head_mask = torch.tensor(trial.user_attrs["head_mask"], dtype=torch.float32)

            restore_projection_strength = trial.user_attrs.get("projection_strength", 1.0)
            restore_separability_threshold = trial.user_attrs.get("separability_threshold", 0.0)
            # Restore trial-specific sparsity threshold
            if "sparsity_threshold" in trial.user_attrs:
                model.settings.sparsity_threshold = trial.user_attrs["sparsity_threshold"]

            try:
                print("* Resetting model...")
                model.reset_model()
                print("* Abliterating...")
                model.abliterate(
                    restore_directions,
                    trial.user_attrs["direction_index"],
                    {
                        k: AbliterationParameters(**v)
                        for k, v in trial.user_attrs["parameters"].items()
                    },
                    restore_head_mask,
                    restore_projection_strength,
                    layer_separability,
                    restore_separability_threshold,
                )
            except Exception as error:
                print(f"[red]Error restoring model: {error}[/]")
                continue

            while True:
                print()
                action = prompt_select(
                    "What do you want to do with the decensored model?",
                    [
                        "Save the model to a local folder",
                        "Upload the model to Hugging Face",
                        "Chat with the model",
                        "Nothing (return to trial selection menu)",
                    ],
                )

                if (
                    action is None
                    or action == "Nothing (return to trial selection menu)"
                ):
                    break

                # All actions are wrapped in a try/except block so that if an error occurs,
                # another action can be tried, instead of the program crashing and losing
                # the optimized model.
                try:
                    match action:
                        case "Save the model to a local folder":
                            save_directory = prompt_path("Path to the folder:")
                            if not save_directory:
                                continue

                            save_model(
                                model,
                                save_directory,
                                settings,
                            )

                        case "Upload the model to Hugging Face":
                            upload_model(
                                model,
                                settings,
                                trial,
                                evaluator.base_refusals,
                                evaluator.bad_prompts,
                            )

                        case "Chat with the model":
                            print()
                            print(
                                "[cyan]Press Ctrl+C at any time to return to the menu.[/]"
                            )

                            chat = [
                                {"role": "system", "content": settings.system_prompt},
                            ]

                            while True:
                                try:
                                    message = prompt_text(
                                        "User:",
                                        qmark=">",
                                        unsafe=True,
                                    )
                                    if not message:
                                        break
                                    chat.append({"role": "user", "content": message})

                                    print("[bold]Assistant:[/] ", end="")
                                    response = model.stream_chat_response(chat)
                                    chat.append(
                                        {"role": "assistant", "content": response}
                                    )
                                except (KeyboardInterrupt, EOFError):
                                    # Ctrl+C/Ctrl+D
                                    break

                except Exception as error:
                    print(f"[red]Error: {error}[/]")


def main():
    # Install Rich traceback handler.
    install()

    try:
        run()
    except BaseException as error:
        # Transformers appears to handle KeyboardInterrupt (or BaseException)
        # internally in some places, which can re-raise a different error in the handler,
        # masking the root cause. We therefore check both the error itself and its context.
        if isinstance(error, KeyboardInterrupt) or isinstance(
            error.__context__, KeyboardInterrupt
        ):
            print()
            print("[red]Shutting down...[/]")
        else:
            raise
