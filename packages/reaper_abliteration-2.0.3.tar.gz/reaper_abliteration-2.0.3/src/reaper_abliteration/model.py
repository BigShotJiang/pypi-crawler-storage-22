# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

import math
from contextlib import suppress
from dataclasses import dataclass
from typing import Any, Type, cast

import bitsandbytes as bnb
import torch
import torch.nn.functional as F
from peft import LoraConfig, PeftModel, get_peft_model
from peft.tuners.lora.layer import Linear
from torch import FloatTensor, LongTensor, Tensor
from torch.nn import Module, ModuleList
from transformers import (
    AutoModelForCausalLM,
    AutoModelForImageTextToText,
    AutoTokenizer,
    BatchEncoding,
    BitsAndBytesConfig,
    PretrainedConfig,
    PreTrainedModel,
    PreTrainedTokenizerBase,
    TextStreamer,
)
from transformers.generation import (
    GenerateDecoderOnlyOutput,  # ty:ignore[possibly-missing-import]
    StoppingCriteria,
    StoppingCriteriaList,
)

from .config import QuantizationMethod, Settings
from .utils import Prompt, batchify, empty_cache, get_gpu_info, calculate_device_map, print, track


def get_model_class(
    model: str,
) -> Type[AutoModelForImageTextToText] | Type[AutoModelForCausalLM]:
    configs = PretrainedConfig.get_config_dict(model)

    if any("vision_config" in x for x in configs):
        return AutoModelForImageTextToText
    else:
        return AutoModelForCausalLM


@dataclass
class AbliterationParameters:
    max_weight: float
    max_weight_position: float
    min_weight: float
    min_weight_distance: float


def _compute_ablation_weight(layer_index: int, params: AbliterationParameters) -> float | None:
    """Compute ablation weight for a layer. Returns None if layer should be skipped."""
    distance = float(abs(layer_index - params.max_weight_position))
    if params.min_weight_distance == 0:
        return params.max_weight
    if distance > params.min_weight_distance:
        return None
    return params.max_weight + (distance / params.min_weight_distance) * (
        params.min_weight - params.max_weight
    )


class RefusalStoppingCriteria(StoppingCriteria):
    """Stop generation early when refusal markers are detected in output."""

    def __init__(
        self,
        tokenizer: PreTrainedTokenizerBase,
        markers: list[str],
        input_length: int,
        check_every_n_tokens: int = 4,
    ):
        self.tokenizer = tokenizer
        self.markers = [m.lower() for m in markers]
        self.input_length = input_length
        self.check_every_n_tokens = check_every_n_tokens
        self._call_count = 0

    def __call__(self, input_ids: LongTensor, scores: FloatTensor, **kwargs: Any) -> Tensor:
        self._call_count += 1
        is_done = torch.zeros(input_ids.shape[0], dtype=torch.bool, device=input_ids.device)
        # Only check periodically to reduce decode overhead
        if self._call_count % self.check_every_n_tokens != 0:
            return is_done

        # Check each sequence individually
        for seq_idx in range(input_ids.shape[0]):
            new_tokens = input_ids[seq_idx, self.input_length:]
            if len(new_tokens) < 3:
                continue
            text = self.tokenizer.decode(new_tokens, skip_special_tokens=True).lower()
            if any(marker in text for marker in self.markers):
                is_done[seq_idx] = True
        return is_done


class Model:
    model: PreTrainedModel | PeftModel | None
    tokenizer: PreTrainedTokenizerBase

    def __init__(self, settings: Settings):
        self.settings = settings
        self.response_prefix = ""
        self.needs_reload = False
        # Storage for fused expert Parameters (gpt-oss style MoE)
        self._fused_expert_params: dict[int, dict[str, Tensor]] = {}
        self._original_fused_params: dict[int, dict[str, Tensor]] = {}
        # Cache for dequantized weights (4-bit models only)
        self._dequant_cache: dict[str, Tensor] = {}
        # Cache for truncated SVD of weight matrices (weight-SVD stability guard)
        self._svd_guard_cache: dict[str, Tensor] = {}
        # Cache for layer module lookups (avoids repeated dict creation)
        self._layer_modules_cache: dict[int, dict[str, list[Module]]] = {}

        print()
        print(f"Loading model [bold]{settings.model}[/]...")

        # Initialize device_map and max_memory
        self.device_map = settings.device_map
        self.max_memory = (
            {int(k) if k.isdigit() else k: v for k, v in settings.max_memory.items()}
            if settings.max_memory
            else None
        )

        # Multi-GPU setup: detect GPUs and auto-calculate memory distribution
        if settings.multi_gpu:
            gpus = get_gpu_info()
            if gpus:
                gpu_info = ", ".join(f"{g['name']} ({g['memory_gb']:.1f}GB)" for g in gpus)
                print(f"* GPUs detected: {gpu_info}")
                if len(gpus) > 1:
                    if self.max_memory is None:
                        device_map, max_memory = calculate_device_map(
                            gpus, settings.gpu_devices, settings.distribution_strategy
                        )
                        self.device_map = device_map
                        if max_memory:
                            self.max_memory = max_memory
                        else:
                            # Fallback: reserve 90% of free memory per GPU
                            self.max_memory = {
                                gpu["index"]: f'{int(gpu["memory_free_gb"] * 0.9)}GB' for gpu in gpus
                            }
                            self.max_memory["cpu"] = "64GB"
                    print(f"* Multi-GPU enabled: distributing across {len(gpus)} GPUs")
                else:
                    print("* multi_gpu enabled but only 1 GPU found, using default")

        self.tokenizer = AutoTokenizer.from_pretrained(
            settings.model,
            trust_remote_code=settings.trust_remote_code,
        )

        # Fallback for tokenizers that don't declare a special pad token.
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        # CRITICAL: Always use left-padding for decoder-only models during generation.
        #           Right-padding causes empty outputs because the model sees PAD tokens
        #           after the prompt and thinks the sequence is complete.
        self.tokenizer.padding_side = "left"

        self.model = None
        self.trusted_models = {settings.model: settings.trust_remote_code}

        if self.settings.evaluate_model is not None:
            self.trusted_models[settings.evaluate_model] = settings.trust_remote_code

        model_class = get_model_class(settings.model)
        for dtype in settings.dtypes:
            print(f"* Trying dtype [bold]{dtype}[/]... ", end="")

            try:
                quantization_config = self._get_quantization_config(dtype)

                # Build kwargs, only include quantization_config if it's not None
                # (some models like gpt-oss have issues with explicit None)
                extra_kwargs = {}
                if quantization_config is not None:
                    extra_kwargs["quantization_config"] = quantization_config

                self.model = model_class.from_pretrained(
                    settings.model,
                    dtype=dtype,
                    device_map=self.device_map,
                    max_memory=self.max_memory,
                    trust_remote_code=self.trusted_models.get(settings.model),
                    **extra_kwargs,
                )

                # If we reach this point and the model requires trust_remote_code,
                # either the user accepted, or settings.trust_remote_code is True.
                if self.trusted_models.get(settings.model) is None:
                    self.trusted_models[settings.model] = True

                # A test run can reveal dtype-related problems such as the infamous
                # "RuntimeError: probability tensor contains either `inf`, `nan` or element < 0"
                # (https://github.com/meta-llama/llama/issues/380).
                self.generate(
                    [
                        Prompt(
                            system=settings.system_prompt,
                            user="What is 1+1?",
                        )
                    ],
                    max_new_tokens=1,
                )
            except Exception as error:
                self.model = None
                empty_cache()
                print(f"[red]Failed[/] ({error})")
                continue

            print("[green]Ok[/]")
            if settings.quantization == QuantizationMethod.BNB_4BIT:
                print("[bold green]Model loaded in 4-bit precision.[/]")
            break

        if self.model is None:
            tried = ", ".join(settings.dtypes)
            raise Exception(
                f"Failed to load model with dtypes [{tried}]. "
                "Try --quantization=bnb_4bit to reduce memory usage."
            )

        # Enable gradient checkpointing to reduce VRAM (trades compute for memory)
        if settings.use_gradient_checkpointing:
            if hasattr(self.model, "gradient_checkpointing_enable"):
                self.model.gradient_checkpointing_enable()
                print("[green]Gradient checkpointing enabled[/]")
            else:
                print("[yellow]Warning: Model does not support gradient checkpointing[/]")

        self._apply_lora()

        # LoRA B matrices are initialized to zero by default in PEFT,
        # so we don't need to do anything manually.

        print(f"* Transformer model with [bold]{len(self.get_layers())}[/] layers")
        print("* Abliterable components:")
        for component, modules in self.get_layer_modules(0).items():
            print(
                f"  * [bold]{component}[/]: [bold]{len(modules)}[/] modules per layer"
            )

        # Initialize fused expert Parameters (gpt-oss style MoE)
        self._init_fused_expert_params()

    def _apply_lora(self):
        # Guard against calling this method at the wrong time.
        assert isinstance(self.model, PreTrainedModel)

        # Always use LoRA adapters for abliteration (faster reload, no weight modification)
        # We use the leaf names (e.g. "o_proj") as target modules.
        # This may cause LoRA adapters to be attached to unrelated modules (e.g. "conv.o_proj"),
        # but this is harmless as we only abliterate the modules we target in `abliterate()`,
        # leaving the others at their default (identity) state.
        target_modules = [
            comp.split(".")[-1] for comp in self.get_abliterable_components()
        ]

        # Qwen3Next uses out_proj (not o_proj) for linear attention layers.
        # Add it to ensure LoRA wraps those modules too.
        if "o_proj" in target_modules and "out_proj" not in target_modules:
            target_modules.append("out_proj")

        rank = self.settings.ablation_rank
        peft_config = LoraConfig(
            r=rank,
            target_modules=target_modules,
            lora_alpha=rank,  # Keep effective scaling at 1.0 (alpha/r = 1)
            lora_dropout=0,
            bias="none",
            # Even if we're using AutoModelForImageTextToText, this is still correct, as it is (post-vision)
            # the same kind of model.
            # https://github.com/huggingface/peft/blob/622c2821cb0d7897bee53aad7914d42b5fecbf61/src/peft/auto.py#L45
            task_type="CAUSAL_LM",
        )

        # peft_config is a LoraConfig object rather than a dictionary,
        # so the result is a PeftModel rather than a PeftMixedModel.
        self.model = cast(PeftModel, get_peft_model(self.model, peft_config))

        print(
            f"[green]LoRA adapters initialized (targets: {', '.join(target_modules)})[/]"
        )

    def _init_fused_expert_params(self):
        """
        Detect and store references to fused expert Parameters (gpt-oss style MoE).
        These models use nn.Parameter instead of nn.Linear for their expert weights,
        which can't have LoRA adapters. We handle them via direct modification.
        """
        self._fused_expert_params = {}
        self._original_fused_params = {}

        for layer_idx, layer in enumerate(self.get_layers()):
            params = {}

            # gpt-oss style: layer.mlp.experts.down_proj is an nn.Parameter
            # Shape: (num_experts, expert_dim, hidden_size)
            with suppress(AttributeError):
                experts = layer.mlp.experts  # ty:ignore[possibly-missing-attribute]
                if hasattr(experts, 'down_proj') and isinstance(experts.down_proj, Tensor):
                    params["mlp.down_proj"] = experts.down_proj

            if params:
                self._fused_expert_params[layer_idx] = params
                # Store original values for reset
                self._original_fused_params[layer_idx] = {
                    k: v.data.clone() for k, v in params.items()
                }

        if self._fused_expert_params:
            # Count unique component types
            components = set()
            for params in self._fused_expert_params.values():
                components.update(params.keys())
            print(f"  * [bold]Fused expert Parameters detected[/]: {', '.join(components)}")

    def _get_quantization_config(self, dtype: str) -> BitsAndBytesConfig | None:
        """
        Creates quantization config based on settings.

        Args:
            dtype: The dtype string (e.g., "auto", "bfloat16")

        Returns:
            BitsAndBytesConfig or None
        """
        if self.settings.quantization == QuantizationMethod.BNB_4BIT:
            # BitsAndBytesConfig expects a torch.dtype, not a string.
            if dtype == "auto":
                compute_dtype = torch.bfloat16
            else:
                compute_dtype = getattr(torch, dtype)

            return BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=compute_dtype,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_use_double_quant=True,
            )
        return None

    def get_merged_model(self) -> PreTrainedModel:
        # Guard against calling this method at the wrong time.
        assert isinstance(self.model, PeftModel)

        # Check if we need special handling for quantized models
        if self.settings.quantization == QuantizationMethod.BNB_4BIT:
            # Quantized models need special handling - we must reload the base model
            # in full precision to merge the LoRA adapters

            # Get the adapter state dict before we do anything
            adapter_state = {}
            for name, param in self.model.named_parameters():
                if "lora_" in name:
                    adapter_state[name] = param.data.clone().cpu()

            # Load base model in full precision on CPU to avoid VRAM issues
            print("* Loading base model on CPU (this may take a while)...")
            base_model = get_model_class(self.settings.model).from_pretrained(
                self.settings.model,
                torch_dtype=self.model.dtype,
                device_map="cpu",
                trust_remote_code=self.trusted_models.get(self.settings.model),
            )

            # Apply LoRA adapters to the CPU model

            print("* Applying LoRA adapters...")
            target_modules = self.get_abliterable_components()
            rank = self.settings.ablation_rank
            peft_config = LoraConfig(
                r=rank,
                target_modules=target_modules,
                lora_alpha=rank,
                lora_dropout=0,
                bias="none",
                task_type="CAUSAL_LM",
            )
            peft_model = get_peft_model(base_model, peft_config)

            # Copy the trained adapter weights
            for name, param in peft_model.named_parameters():
                if name in adapter_state:
                    param.data = adapter_state[name].to(param.device)

            # Merge and unload
            print("* Merging LoRA adapters into base model...")
            merged_model = peft_model.merge_and_unload()

            # Apply fused expert Parameter modifications (gpt-oss style MoE)
            if self._fused_expert_params:
                print("* Applying fused expert Parameter modifications...")
                for layer_idx, params in self._fused_expert_params.items():
                    for comp, modified_param in params.items():
                        # Get the corresponding parameter in the merged model
                        merged_layer = merged_model.model.layers[layer_idx]
                        with suppress(AttributeError):
                            target = merged_layer.mlp.experts.down_proj
                            target.data.copy_(modified_param.data.to(target.device))

            return merged_model
        else:
            # Non-quantized model - can merge directly
            print("* Merging LoRA adapters into base model...")
            merged_model = self.model.merge_and_unload()
            # merge_and_unload() modifies self.model in-place, destroying LoRA adapters.
            # Mark for full reload if user switches trials later.
            self.needs_reload = True
            self._layer_modules_cache.clear()
            # Fused expert Parameters are already modified in-place on self.model,
            # so they're preserved in merged_model.
            return merged_model

    def reset_model(self):
        """
        Resets the model to a clean state for the next trial or evaluation.

        Behavior:
        - Fast path: If the same model is loaded and doesn't need full reload,
          resets LoRA adapter weights to zero (identity transformation).
        - Slow path: If switching models or after merge_and_unload(),
          performs full model reload with quantization config.
        """
        assert self.model is not None
        current_model = getattr(self.model.config, "name_or_path", None)
        if current_model == self.settings.model and not self.needs_reload:
            # Reset LoRA adapters to zero (identity transformation)
            for name, module in self.model.named_modules():
                if "lora_B" in name and hasattr(module, "weight"):
                    torch.nn.init.zeros_(module.weight)

            # Reset fused expert Parameters to original values (gpt-oss style MoE)
            for layer_idx, params in self._original_fused_params.items():
                for comp, original in params.items():
                    self._fused_expert_params[layer_idx][comp].data.copy_(original)

            return

        dtype = self.model.dtype

        # Purge existing model object from memory to make space.
        self.model = None
        empty_cache()

        quantization_config = self._get_quantization_config(str(dtype).split(".")[-1])

        # Build kwargs, only include quantization_config if it's not None
        extra_kwargs = {}
        if quantization_config is not None:
            extra_kwargs["quantization_config"] = quantization_config

        self.model = get_model_class(self.settings.model).from_pretrained(
            self.settings.model,
            dtype=dtype,
            device_map=self.device_map,
            max_memory=self.max_memory,
            trust_remote_code=self.trusted_models.get(self.settings.model),
            **extra_kwargs,
        )

        # Re-enable gradient checkpointing after reload
        if self.settings.use_gradient_checkpointing and hasattr(self.model, "gradient_checkpointing_enable"):
            self.model.gradient_checkpointing_enable()

        self._apply_lora()
        self._init_fused_expert_params()

        self._layer_modules_cache.clear()
        self._dequant_cache.clear()
        self._svd_guard_cache.clear()
        self.needs_reload = False

    def get_layers(self) -> ModuleList:
        model = self.model
        assert model is not None

        # Unwrap PeftModel (always true after _apply_lora)
        if isinstance(model, PeftModel):
            model = model.base_model.model

        # Most multimodal models.
        with suppress(AttributeError):
            return model.model.language_model.layers

        # Text-only models.
        return model.model.layers

    def get_attention_head_info(self) -> tuple[int, int]:
        """
        Get attention head configuration from model.

        Returns:
            (num_heads, head_dim) tuple
        """
        model = self.model
        assert model is not None
        if isinstance(model, PeftModel):
            model = model.base_model.model

        config = model.config

        # Try various config attribute names
        num_heads = getattr(config, "num_attention_heads", None)
        if num_heads is None:
            num_heads = getattr(config, "n_head", None)
        if num_heads is None:
            num_heads = getattr(config, "num_heads", 32)  # fallback default

        hidden_size = getattr(config, "hidden_size", None)
        if hidden_size is None:
            hidden_size = getattr(config, "n_embd", 4096)  # fallback default

        head_dim = hidden_size // num_heads
        return num_heads, head_dim

    def get_layer_modules(self, layer_index: int) -> dict[str, list[Module]]:
        if layer_index in self._layer_modules_cache:
            return self._layer_modules_cache[layer_index]

        layer = self.get_layers()[layer_index]

        modules = {}

        def try_add(component: str, module: Any):
            # Only add if it's a proper nn.Module (PEFT can wrap these with LoRA)
            if isinstance(module, Module):
                if component not in modules:
                    modules[component] = []
                modules[component].append(module)
            else:
                # Assert for unexpected types (catches architecture changes)
                assert not isinstance(module, Tensor), (
                    f"Unexpected Tensor in {component} - expected nn.Module"
                )

        # Standard transformers attention (Llama, Mistral, Qwen2, etc.)
        # Also handles Qwen3Next full_attention layers.
        with suppress(AttributeError):
            try_add("attn.o_proj", layer.self_attn.o_proj)  # ty:ignore[possibly-missing-attribute]

        # Qwen3Next linear_attention layers (GatedDeltaNet).
        with suppress(AttributeError):
            try_add("attn.o_proj", layer.linear_attn.out_proj)  # ty:ignore[possibly-missing-attribute]

        # Most dense models.
        with suppress(AttributeError):
            try_add("mlp.down_proj", layer.mlp.down_proj)  # ty:ignore[possibly-missing-attribute]

        # Some MoE models (e.g. Qwen3).
        with suppress(AttributeError, TypeError):
            for expert in layer.mlp.experts:  # ty:ignore[possibly-missing-attribute, not-iterable]
                try_add("mlp.down_proj", expert.down_proj)  # ty:ignore[possibly-missing-attribute]

        # Phi-3.5-MoE (and possibly others).
        with suppress(AttributeError, TypeError):
            for expert in layer.block_sparse_moe.experts:  # ty:ignore[possibly-missing-attribute, not-iterable]
                try_add("mlp.down_proj", expert.w2)  # ty:ignore[possibly-missing-attribute]

        # Granite MoE Hybrid - attention layers with shared_mlp.
        with suppress(AttributeError):
            try_add("mlp.down_proj", layer.shared_mlp.output_linear)  # ty:ignore[possibly-missing-attribute]

        # Granite MoE Hybrid - MoE layers with experts.
        with suppress(AttributeError, TypeError):
            for expert in layer.moe.experts:  # ty:ignore[possibly-missing-attribute, not-iterable]
                try_add("mlp.down_proj", expert.output_linear)  # ty:ignore[possibly-missing-attribute]

        # We need at least one module across all components for abliteration to work.
        total_modules = sum(len(mods) for mods in modules.values())
        assert total_modules > 0, "No abliterable modules found in layer"

        self._layer_modules_cache[layer_index] = modules
        return modules

    def get_abliterable_components(self) -> list[str]:
        components = list(self.get_layer_modules(0).keys())
        # Add fused expert Parameter components (gpt-oss style MoE)
        if 0 in self._fused_expert_params:
            for comp in self._fused_expert_params[0].keys():
                if comp not in components:
                    components.append(comp)
        return components

    def abliterate(
        self,
        refusal_directions: Tensor,
        direction_index: float | None,
        parameters: dict[str, AbliterationParameters],
        head_mask: Tensor | None = None,
        projection_strength: float = 1.0,
        layer_separability: Tensor | None = None,
        separability_threshold: float = 0.0,
    ):
        """
        Apply abliteration to model weights.

        Args:
            refusal_directions: Per-layer refusal directions.
                Rank-1: shape (num_layers+1, hidden_dim)
                Rank-k: shape (num_layers+1, k, hidden_dim)
            direction_index: Which layer's direction to use (None = per-layer)
            parameters: Abliteration parameters per component
            head_mask: Optional boolean mask of shape (num_heads,) for per-head ablation.
                       True = ablate this head, False = skip this head.
            layer_separability: Optional per-layer separability scores (index 0 = embedding).
            separability_threshold: Layers with separability below this are skipped.
        """
        with torch.no_grad():
            # Detect rank from directions shape: 2D = rank-1, 3D = rank-k
            rank_k = refusal_directions.ndim == 3

            if direction_index is None:
                refusal_direction = None
            else:
                # Clamp direction_index to prevent out-of-bounds access in lerp
                max_safe_index = len(refusal_directions) - 2.001
                direction_index = max(0.0, min(direction_index, max_safe_index))
                # The index must be shifted by 1 because the first element
                # of refusal_directions is the direction for the embeddings.
                interp_weight, index = math.modf(direction_index + 1)
                refusal_direction = F.normalize(
                    refusal_directions[int(index)].lerp(
                        refusal_directions[int(index) + 1],
                        interp_weight,
                    ),
                    p=2,
                    dim=-1,  # Works for both (hidden_dim,) and (k, hidden_dim)
                )

            # Get head info for per-head ablation
            num_heads, head_dim = self.get_attention_head_info() if head_mask is not None else (0, 0)

            for layer_index in track(range(len(self.get_layers())), description="Abliterating layers..."):
                # Skip layers with low separability
                if layer_separability is not None:
                    sep_score = layer_separability[layer_index + 1].item()
                    if sep_score < separability_threshold:
                        continue

                for component, modules in self.get_layer_modules(layer_index).items():
                    params = parameters[component]

                    ablation_weight = _compute_ablation_weight(layer_index, params)
                    if ablation_weight is None:
                        continue
                    ablation_weight *= projection_strength

                    if refusal_direction is None:
                        layer_refusal_direction = refusal_directions[layer_index + 1]
                    else:
                        layer_refusal_direction = refusal_direction

                    layer_device = cast(Linear, modules[0]).weight.device
                    v_layer = layer_refusal_direction.to(layer_device)

                    for module in modules:
                        module = cast(Linear, module)

                        # Skip non-LoRA modules (MoE experts with non-standard names)
                        if not hasattr(module, 'base_layer') or not hasattr(module, 'lora_A'):
                            continue

                        v = v_layer

                        # Apply per-head mask if enabled (only for attention components)
                        if head_mask is not None and "attn" in component:
                            if rank_k:
                                # v is (k, hidden_size), mask each direction
                                v_heads = v.view(v.shape[0], num_heads, head_dim)
                                mask = head_mask.to(v.device).view(1, -1, 1)
                                v = (v_heads * mask).view(v.shape[0], -1)
                            else:
                                v_heads = v.view(num_heads, head_dim)
                                mask = head_mask.to(v.device).view(-1, 1)
                                v = (v_heads * mask).view(-1)

                        # Get W (dequantize if necessary).
                        base_weight = cast(Tensor, module.base_layer.weight)
                        quant_state = getattr(base_weight, "quant_state", None)

                        if quant_state is None:
                            W = base_weight if base_weight.dtype == torch.float32 else base_weight.to(torch.float32)
                        else:
                            cache_key = f"{layer_index}_{component}_{id(module)}"
                            if self.settings.cache_dequantized_weights and cache_key in self._dequant_cache:
                                W = self._dequant_cache[cache_key]
                            else:
                                W = cast(
                                    Tensor,
                                    bnb.functional.dequantize_4bit(  # ty:ignore[possibly-missing-attribute]
                                        base_weight.data,
                                        quant_state,
                                    ).to(torch.float32),
                                )
                                if self.settings.cache_dequantized_weights:
                                    self._dequant_cache[cache_key] = W

                        # Weight-SVD stability guard: project refusal direction(s)
                        # away from top left singular vectors of W to protect capability subspace
                        if self.settings.weight_svd_guard:
                            k_guard = self.settings.svd_guard_rank
                            svd_key = f"{layer_index}_{component}_{id(module)}"
                            if svd_key in self._svd_guard_cache:
                                U_k = self._svd_guard_cache[svd_key]
                            else:
                                U_k, _, _ = torch.svd_lowrank(W, q=k_guard, niter=2)
                                # U_k: (d_out, k_guard) with orthonormal columns
                                self._svd_guard_cache[svd_key] = U_k

                            if rank_k:
                                # v is (k, d_out) - remove components along top left singular vectors
                                v = v - (v @ U_k) @ U_k.T
                                # Drop directions that collapsed (norm < 1e-4 of original)
                                norms = v.norm(dim=1)
                                keep = norms > 1e-4
                                if not keep.any():
                                    continue  # all directions in protected subspace, skip module
                                v = v[keep] / norms[keep, None]
                            else:
                                # v is (d_out,) - remove components along top left singular vectors
                                v = v - U_k @ (U_k.T @ v)
                                norm = v.norm()
                                if norm < 1e-4:
                                    continue  # direction in protected subspace, skip module
                                v = v / norm

                        if rank_k:
                            # Re-orthogonalize after head_mask/projection may have broken orthonormality
                            if v.shape[0] > 1:
                                Q, _ = torch.linalg.qr(v.T)  # (d, k)
                                v = Q[:, :v.shape[0]].T       # (k, d), rows orthonormal

                            # Rank-k LoRA: v is (k, d_out), W is (d_out, d_in)
                            # lora_A = V @ W -> (k, d_in), lora_B = -lambda * V^T -> (d_out, k)
                            lora_A = v @ W
                            lora_B = -ablation_weight * v.T

                            # Sparse ablation: zero out low-magnitude entries in lora_A
                            if self.settings.sparsity_threshold > 0:
                                threshold = self.settings.sparsity_threshold * lora_A.abs().max()
                                lora_A = lora_A * (lora_A.abs() >= threshold)

                            if self.settings.norm_preserve:
                                W_eff = W + lora_B @ lora_A
                                orig_norms = W.norm(dim=1, keepdim=True)
                                new_norms = W_eff.norm(dim=1, keepdim=True).clamp(min=1e-8)
                                delta = (W_eff * (orig_norms / new_norms)) - W
                                # k x k solve: lora_B = delta @ A^T @ (A @ A^T)^{-1}
                                AAt = lora_A @ lora_A.T  # (k, k)
                                if AAt.det().abs() > 1e-12:
                                    lora_B = (delta @ lora_A.T) @ torch.linalg.inv(AAt)
                        else:
                            # Rank-1 LoRA: original path
                            lora_A = (v @ W).view(1, -1)
                            lora_B = (-ablation_weight * v).view(-1, 1)

                            # Sparse ablation: zero out low-magnitude entries in lora_A
                            if self.settings.sparsity_threshold > 0:
                                threshold = self.settings.sparsity_threshold * lora_A.abs().max()
                                lora_A = lora_A * (lora_A.abs() >= threshold)

                            if self.settings.norm_preserve:
                                W_eff = W + lora_B @ lora_A
                                orig_norms = W.norm(dim=1, keepdim=True)
                                new_norms = W_eff.norm(dim=1, keepdim=True).clamp(min=1e-8)
                                delta = (W_eff * (orig_norms / new_norms)) - W
                                lora_A_sq = (lora_A @ lora_A.T).item()
                                if lora_A_sq > 1e-12:
                                    lora_B = (delta @ lora_A.T) / lora_A_sq

                        weight_A = cast(Tensor, module.lora_A["default"].weight)
                        weight_B = cast(Tensor, module.lora_B["default"].weight)
                        weight_A.data = lora_A.to(weight_A.dtype)
                        weight_B.data = lora_B.to(weight_B.dtype)

                # Handle fused expert Parameters (gpt-oss style MoE)
                if layer_index in self._fused_expert_params:
                    for component, param in self._fused_expert_params[layer_index].items():
                        if component not in parameters:
                            continue

                        params = parameters[component]
                        ablation_weight = _compute_ablation_weight(layer_index, params)
                        if ablation_weight is None:
                            continue
                        ablation_weight *= projection_strength

                        if refusal_direction is None:
                            layer_refusal_direction = refusal_directions[layer_index + 1]
                        else:
                            layer_refusal_direction = refusal_direction

                        v = layer_refusal_direction.to(param.device)
                        W_all = param.data if param.dtype == torch.float32 else param.data.to(torch.float32)

                        if rank_k:
                            # v is (k, hidden_size). Sum k rank-1 projections.
                            hidden_size = v.shape[-1]
                            if W_all.shape[2] == hidden_size:
                                W_new = W_all.clone()
                                for vi in v:
                                    proj = torch.matmul(W_all, vi)
                                    W_new -= ablation_weight * torch.einsum('ne,h->neh', proj, vi)
                            elif W_all.shape[1] == hidden_size:
                                W_new = W_all.clone()
                                for vi in v:
                                    proj = torch.matmul(vi, W_all)
                                    W_new -= ablation_weight * torch.einsum('h,ne->nhe', vi, proj)
                            else:
                                continue
                        else:
                            hidden_size = v.shape[0]
                            if W_all.shape[2] == hidden_size:
                                proj = torch.matmul(W_all, v)
                                W_new = W_all - ablation_weight * torch.einsum('ne,h->neh', proj, v)
                            elif W_all.shape[1] == hidden_size:
                                proj = torch.matmul(v, W_all)
                                W_new = W_all - ablation_weight * torch.einsum('h,ne->nhe', v, proj)
                            else:
                                continue

                        if self.settings.norm_preserve:
                            orig_norms = W_all.norm(dim=-1, keepdim=True)
                            new_norms = W_new.norm(dim=-1, keepdim=True).clamp(min=1e-8)
                            W_new = W_new * (orig_norms / new_norms)
                        param.data = W_new.to(param.dtype)

    def tokenize_prompts(self, prompts: list[Prompt]) -> BatchEncoding:
        """Pre-tokenize prompts for caching. Returns BatchEncoding on CPU."""
        chats = [
            [
                {"role": "system", "content": prompt.system},
                {"role": "user", "content": prompt.user},
            ]
            for prompt in prompts
        ]

        chat_prompts = cast(
            list[str],
            self.tokenizer.apply_chat_template(
                chats,
                add_generation_prompt=True,
                tokenize=False,
            ),
        )

        if self.response_prefix:
            chat_prompts = [p + self.response_prefix for p in chat_prompts]

        return self.tokenizer(
            chat_prompts,
            return_tensors="pt",
            padding=True,
            return_token_type_ids=False,
        )

    def generate(
        self,
        prompts: list[Prompt] | None = None,
        tokenized_inputs: BatchEncoding | None = None,
        early_exit_markers: list[str] | None = None,
        **kwargs: Any,
    ) -> tuple[BatchEncoding, GenerateDecoderOnlyOutput | LongTensor]:
        assert self.model is not None
        if tokenized_inputs is not None:
            inputs = tokenized_inputs.to(self.model.device)
        elif prompts is not None:
            inputs = self.tokenize_prompts(prompts).to(self.model.device)
        else:
            raise ValueError("Must provide either prompts or tokenized_inputs")

        # Add early-exit stopping criteria if markers provided
        if early_exit_markers:
            input_length = cast(Tensor, inputs["input_ids"]).shape[1]
            stopping_criteria = StoppingCriteriaList([
                RefusalStoppingCriteria(self.tokenizer, early_exit_markers, input_length)
            ])
            kwargs["stopping_criteria"] = stopping_criteria

        outputs = self.model.generate(
            **inputs,
            **kwargs,
            pad_token_id=self.tokenizer.pad_token_id,
            do_sample=False,
        )  # ty:ignore[call-non-callable]

        return inputs, outputs

    def get_responses(
        self,
        prompts: list[Prompt] | None = None,
        skip_special_tokens: bool = False,
        tokenized_inputs: BatchEncoding | None = None,
        early_exit_markers: list[str] | None = None,
        max_new_tokens: int | None = None,
    ) -> list[str]:
        inputs, outputs = self.generate(
            prompts=prompts,
            tokenized_inputs=tokenized_inputs,
            early_exit_markers=early_exit_markers,
            max_new_tokens=max_new_tokens or self.settings.max_response_length,
        )

        return self.tokenizer.batch_decode(
            outputs[:, cast(Tensor, inputs["input_ids"]).shape[1] :],
            skip_special_tokens=skip_special_tokens,
        )

    def get_responses_batched(
        self,
        prompts: list[Prompt] | None = None,
        skip_special_tokens: bool = False,
        tokenized_inputs: BatchEncoding | None = None,
        early_exit_markers: list[str] | None = None,
        max_new_tokens: int | None = None,
    ) -> list[str]:
        responses = []

        if tokenized_inputs is not None:
            # Batch over pre-tokenized inputs
            n = cast(Tensor, tokenized_inputs["input_ids"]).shape[0]
            batch_starts = list(range(0, n, self.settings.batch_size))
            for start in track(batch_starts, description="Generating responses..."):
                end = min(start + self.settings.batch_size, n)
                batch_inputs = BatchEncoding({
                    k: v[start:end] for k, v in tokenized_inputs.items()
                })
                responses.extend(self.get_responses(
                    tokenized_inputs=batch_inputs,
                    skip_special_tokens=skip_special_tokens,
                    early_exit_markers=early_exit_markers,
                    max_new_tokens=max_new_tokens,
                ))
        else:
            batches = list(batchify(prompts or [], self.settings.batch_size))
            for batch in track(batches, description="Generating responses..."):
                responses.extend(self.get_responses(
                    prompts=batch,
                    skip_special_tokens=skip_special_tokens,
                    early_exit_markers=early_exit_markers,
                    max_new_tokens=max_new_tokens,
                ))

        return responses

    def get_residuals(self, prompts: list[Prompt], positions: list[int] | None = None) -> Tensor:
        """
        Extract residual vectors from hidden states.

        Args:
            prompts: List of prompts to process
            positions: Token positions to extract from (negative = from end). Default [-1].

        Returns:
            If single position: shape (prompt, layer, component)
            If multiple positions: shape (prompt, position, layer, component)
        """
        if positions is None:
            positions = [-1]

        # We only generate one token, and we return the residual vectors
        # at that token position, for each prompt and layer.
        _, outputs = self.generate(
            prompts,
            max_new_tokens=1,
            output_hidden_states=True,
            return_dict_in_generate=True,
        )

        # This cast is valid because GenerateDecoderOnlyOutput is the return type
        # of model.generate with return_dict_in_generate=True.
        outputs = cast(GenerateDecoderOnlyOutput, outputs)

        # Hidden states for the first (only) generated token.
        # This cast is valid because we passed output_hidden_states=True above.
        hidden_states = cast(tuple[tuple[FloatTensor]], outputs.hidden_states)[0]

        if len(positions) == 1:
            # Single position: return shape (prompt, layer, component)
            pos = positions[0]
            residuals = torch.stack(
                [layer_hidden_states[:, pos, :] for layer_hidden_states in hidden_states],
                dim=1,
            )
        else:
            # Multiple positions: return shape (prompt, position, layer, component)
            position_residuals = []
            for pos in positions:
                pos_residuals = torch.stack(
                    [layer_hidden_states[:, pos, :] for layer_hidden_states in hidden_states],
                    dim=1,
                )
                position_residuals.append(pos_residuals)
            residuals = torch.stack(position_residuals, dim=1)

        # Upcast the data type to avoid precision (bfloat16) or range (float16)
        # problems during calculations involving residual vectors.
        return residuals.to(torch.float32)

    def get_residuals_batched(self, prompts: list[Prompt], positions: list[int] | None = None) -> Tensor:
        residuals = []
        batches = list(batchify(prompts, self.settings.batch_size))

        for batch in track(batches, description="Extracting residuals..."):
            residuals.append(self.get_residuals(batch, positions))

        return torch.cat(residuals, dim=0)

    # We work with logprobs rather than probabilities for numerical stability
    # when computing the KL divergence.
    def get_logprobs(
        self,
        prompts: list[Prompt] | None = None,
        tokenized_inputs: BatchEncoding | None = None,
        n_tokens: int = 1,
    ) -> Tensor:
        """Return log-probability distributions over the vocabulary.

        When n_tokens=1: shape (batch, vocab) — single next-token prediction.
        When n_tokens>1: shape (batch, n_tokens, vocab) — autoregressive multi-token.
        """
        _, outputs = self.generate(
            prompts=prompts,
            tokenized_inputs=tokenized_inputs,
            max_new_tokens=n_tokens,
            output_scores=True,
            return_dict_in_generate=True,
        )

        outputs = cast(GenerateDecoderOnlyOutput, outputs)
        scores = list(cast(tuple[FloatTensor], outputs.scores))

        # Early EOS can produce fewer scores than requested; pad to n_tokens
        if len(scores) < n_tokens:
            last = scores[-1]
            scores = scores + [last] * (n_tokens - len(scores))
        elif len(scores) > n_tokens:
            scores = scores[:n_tokens]

        if n_tokens == 1:
            return F.log_softmax(scores[0], dim=-1)

        # Stack per-token logits → (batch, n_tokens, vocab), then log_softmax
        return F.log_softmax(torch.stack([cast(Tensor, s) for s in scores], dim=1), dim=-1)

    def get_continuation_tokens(
        self,
        tokenized_inputs: BatchEncoding,
        n_tokens: int,
    ) -> Tensor:
        """Greedy-generate n continuation tokens. Returns (batch, n_tokens) token IDs."""
        assert self.model is not None
        inputs = tokenized_inputs.to(self.model.device)
        seq_len = cast(Tensor, inputs["input_ids"]).shape[1]
        output_ids = self.model.generate(
            **inputs,
            max_new_tokens=n_tokens,
            do_sample=False,
            pad_token_id=self.tokenizer.pad_token_id,
        )  # ty:ignore[call-non-callable]
        # output_ids: (batch, seq_len + generated). Pad if EOS cut it short.
        generated = output_ids[:, seq_len:]
        if generated.shape[1] < n_tokens:
            pad = generated[:, -1:].expand(-1, n_tokens - generated.shape[1])
            generated = torch.cat([generated, pad], dim=1)
        return generated[:, :n_tokens]

    def get_logprobs_teacher_forced(
        self,
        tokenized_inputs: BatchEncoding,
        continuation_ids: Tensor,
    ) -> Tensor:
        """Forward pass on prompt+continuation, return logprobs at continuation positions.

        Returns (batch, n_tokens, vocab) log-probabilities.
        """
        assert self.model is not None
        inputs = tokenized_inputs.to(self.model.device)
        input_ids = cast(Tensor, inputs["input_ids"])
        seq_len = input_ids.shape[1]
        n_tokens = continuation_ids.shape[1]

        # Concatenate prompt + continuation
        full_ids = torch.cat([input_ids, continuation_ids.to(input_ids.device)], dim=1)
        # Extend attention mask if present
        attn_mask = inputs.get("attention_mask")
        if attn_mask is not None:
            ones = torch.ones(attn_mask.shape[0], n_tokens, device=attn_mask.device, dtype=attn_mask.dtype)
            full_mask = torch.cat([attn_mask, ones], dim=1)
        else:
            full_mask = None

        with torch.no_grad():
            logits = self.model(input_ids=full_ids, attention_mask=full_mask).logits

        # Logits at position i predict token i+1. For continuation positions:
        # positions seq_len-1 .. seq_len+n_tokens-2 predict tokens seq_len .. seq_len+n_tokens-1
        continuation_logits = logits[:, seq_len - 1 : seq_len + n_tokens - 1, :]
        return F.log_softmax(continuation_logits, dim=-1)

    def get_logprobs_batched(
        self,
        prompts: list[Prompt] | None = None,
        tokenized_inputs: BatchEncoding | None = None,
        n_tokens: int = 1,
    ) -> Tensor:
        logprobs = []

        if tokenized_inputs is not None:
            n = cast(Tensor, tokenized_inputs["input_ids"]).shape[0]
            batch_starts = list(range(0, n, self.settings.batch_size))
            for start in track(batch_starts, description="Computing logprobs..."):
                end = min(start + self.settings.batch_size, n)
                batch_inputs = BatchEncoding({
                    k: v[start:end] for k, v in tokenized_inputs.items()
                })
                logprobs.append(self.get_logprobs(tokenized_inputs=batch_inputs, n_tokens=n_tokens))
        else:
            batches = list(batchify(prompts or [], self.settings.batch_size))
            for batch in track(batches, description="Computing logprobs..."):
                logprobs.append(self.get_logprobs(prompts=batch, n_tokens=n_tokens))

        return torch.cat(logprobs, dim=0)

    def get_continuation_tokens_batched(
        self,
        tokenized_inputs: BatchEncoding,
        n_tokens: int,
    ) -> Tensor:
        """Batched greedy continuation. Returns (total_samples, n_tokens) token IDs."""
        n = cast(Tensor, tokenized_inputs["input_ids"]).shape[0]
        parts = []
        for start in range(0, n, self.settings.batch_size):
            end = min(start + self.settings.batch_size, n)
            batch = BatchEncoding({k: v[start:end] for k, v in tokenized_inputs.items()})
            parts.append(self.get_continuation_tokens(batch, n_tokens))
        return torch.cat(parts, dim=0)

    def get_logprobs_teacher_forced_batched(
        self,
        tokenized_inputs: BatchEncoding,
        continuation_ids: Tensor,
    ) -> Tensor:
        """Batched teacher-forced logprobs. Returns (total_samples, n_tokens, vocab)."""
        n = cast(Tensor, tokenized_inputs["input_ids"]).shape[0]
        parts = []
        for start in range(0, n, self.settings.batch_size):
            end = min(start + self.settings.batch_size, n)
            batch = BatchEncoding({k: v[start:end] for k, v in tokenized_inputs.items()})
            parts.append(self.get_logprobs_teacher_forced(batch, continuation_ids[start:end]))
        return torch.cat(parts, dim=0)

    def stream_chat_response(self, chat: list[dict[str, str]]) -> str:
        assert self.model is not None
        # This cast is valid because str is the return type
        # for single-chat operation with tokenize=False.
        chat_prompt = cast(
            str,
            self.tokenizer.apply_chat_template(
                chat,
                add_generation_prompt=True,
                tokenize=False,
            ),
        )

        inputs = self.tokenizer(
            chat_prompt,
            return_tensors="pt",
            return_token_type_ids=False,
        ).to(self.model.device)

        streamer = TextStreamer(
            # The TextStreamer constructor annotates this parameter with the AutoTokenizer
            # type, which makes no sense because AutoTokenizer is a factory class,
            # not a base class that tokenizers inherit from.
            self.tokenizer,  # ty:ignore[invalid-argument-type]
            skip_prompt=True,
            skip_special_tokens=True,
        )

        # NOTE: Type checker disabled due to HuggingFace's complex generate() overloads
        # and PEFT's dynamic model wrapping. Runtime behavior is correct.
        outputs = self.model.generate(
            **inputs,
            streamer=streamer,
            max_new_tokens=4096,
        )  # ty:ignore[call-non-callable]

        return self.tokenizer.decode(
            outputs[0, inputs["input_ids"].shape[1] :],
            skip_special_tokens=True,
        )
