# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

import sys
import time
from dataclasses import asdict

import torch
import torch.nn.functional as F
from optuna import Trial, TrialPruned
from optuna.trial import TrialState

from .dashboard import Dashboard
from .model import AbliterationParameters
from .seed_management import load_seed_params, update_best_seeds
from .utils import (
    empty_cache,
    format_duration,
    get_trial_parameters,
    print,
    set_dashboard_active,
)


def run_optimization_loop(
    model,
    evaluator,
    settings,
    study,
    mean_direction,
    pca_directions,
    direction_modes,
    positions,
    good_residuals_multipos,
    bad_residuals_multipos,
    seed_params_file,
    layer_separability=None,
    svd_directions=None,
):
    """Run the Optuna optimization loop. Returns (completed_count, run_more)."""
    trial_index = 0
    start_index = 0
    start_time = time.perf_counter()
    dashboard: Dashboard | None = None

    def objective(trial: Trial) -> tuple[float, float]:
        nonlocal trial_index, dashboard
        trial_start = time.perf_counter()
        trial_index += 1
        trial.set_user_attr("index", trial_index)

        # Handle multi-position weighting if enabled
        if good_residuals_multipos is not None:
            # Sample position weights (will be normalized to sum to 1)
            raw_weights = []
            for i, pos in enumerate(positions):
                w = trial.suggest_float(f"position_weight_{pos}", 0.1, 1.0)
                raw_weights.append(w)
            # Normalize weights
            total = sum(raw_weights)
            pos_weights = torch.tensor([w / total for w in raw_weights], device=good_residuals_multipos.device)
            trial.set_user_attr("position_weights", {str(p): w for p, w in zip(positions, raw_weights)})

            # Compute weighted residuals: (prompt, layer, component)
            weighted_good = torch.einsum('p,npld->nld', pos_weights, good_residuals_multipos)
            weighted_bad = torch.einsum('p,npld->nld', pos_weights, bad_residuals_multipos)

            # Compute weighted mean direction
            weighted_direction = F.normalize(
                weighted_bad.mean(dim=0) - weighted_good.mean(dim=0),
                p=2,
                dim=1,
            )
        else:
            weighted_direction = None

        # Select appropriate refusal directions based on mode
        if svd_directions is not None:
            # Rank-k: use precomputed SVD directions (num_layers+1, k, hidden_dim)
            trial_directions = svd_directions
            trial.set_user_attr("direction_mode", "svd")
        else:
            active_modes = list(direction_modes)
            if settings.combine_directions and pca_directions is not None and "combined" not in active_modes:
                active_modes.append("combined")
            direction_mode = trial.suggest_categorical("direction_mode", active_modes)
            trial.set_user_attr("direction_mode", direction_mode)

            if direction_mode == "combined" and pca_directions is not None:
                w_mean = trial.suggest_float("dir_weight_mean", 0.0, 1.0)
                dir_weights = {}
                trial_directions = w_mean * (weighted_direction if weighted_direction is not None else mean_direction)
                dir_weights["mean"] = w_mean
                for i in range(pca_directions.shape[0]):
                    w = trial.suggest_float(f"dir_weight_pca_{i+1}", 0.0, 1.0)
                    trial_directions = trial_directions + w * pca_directions[i]
                    dir_weights[f"pca_{i+1}"] = w
                trial_directions = F.normalize(trial_directions, p=2, dim=1)
                trial.set_user_attr("direction_weights", dir_weights)
            elif weighted_direction is not None and direction_mode == "mean":
                trial_directions = weighted_direction
            elif direction_mode == "mean":
                trial_directions = mean_direction
            else:
                if pca_directions is None:
                    trial_directions = mean_direction
                else:
                    pca_idx = int(direction_mode.split("_")[1]) - 1
                    trial_directions = pca_directions[pca_idx]

        direction_scope = trial.suggest_categorical(
            "direction_scope",
            [
                "global",
                "per layer",
            ],
        )

        last_layer_index = len(model.get_layers()) - 1

        # Discrimination between "harmful" and "harmless" inputs is usually strongest
        # in layers slightly past the midpoint of the layer stack. See the original
        # abliteration paper (https://arxiv.org/abs/2406.11717) for a deeper analysis.
        #
        # Note that we always sample this parameter even though we only need it for
        # the "global" direction scope. The reason is that multivariate TPE doesn't
        # work with conditional or variable-range parameters.
        direction_index = trial.suggest_float(
            "direction_index",
            0.4 * last_layer_index,
            0.9 * last_layer_index,
        )

        if direction_scope == "per layer":
            direction_index = None

        parameters = {}

        for component in model.get_abliterable_components():
            # The parameter ranges are based on experiments with various models
            # and much wider ranges. They are not set in stone and might have to be
            # adjusted for future models.
            max_weight = trial.suggest_float(
                f"{component}.max_weight",
                0.8,
                1.5,
            )
            max_weight_position = trial.suggest_float(
                f"{component}.max_weight_position",
                0.6 * last_layer_index,
                1.0 * last_layer_index,
            )
            # For sampling purposes, min_weight is expressed as a fraction of max_weight,
            # again because multivariate TPE doesn't support variable-range parameters.
            # The value is transformed into the actual min_weight value below.
            min_weight = trial.suggest_float(
                f"{component}.min_weight",
                0.0,
                1.5,
            )
            min_weight_distance = trial.suggest_float(
                f"{component}.min_weight_distance",
                1.0,
                max(1.01, 0.6 * last_layer_index),
            )

            parameters[component] = AbliterationParameters(
                max_weight=max_weight,
                max_weight_position=max_weight_position,
                min_weight=(min_weight * max_weight),
                min_weight_distance=min_weight_distance,
            )

        trial.set_user_attr("direction_index", direction_index)
        trial.set_user_attr("parameters", {k: asdict(v) for k, v in parameters.items()})

        # Generate head mask for per-head ablation if enabled
        head_mask = None
        if settings.per_head_ablation:
            num_heads, _ = model.get_attention_head_info()
            # Sample fraction of heads to ablate
            head_fraction = trial.suggest_float(
                "head_ablation_fraction",
                max(0.1, settings.head_ablation_fraction - 0.3),
                min(1.0, settings.head_ablation_fraction + 0.3),
            )
            # Generate random mask based on fraction
            num_ablate = max(1, int(num_heads * head_fraction))
            # Use trial number as seed for reproducibility (local generator to avoid global RNG pollution)
            rng = torch.Generator().manual_seed(trial_index * 1001 + int(head_fraction * 1000))
            indices = torch.randperm(num_heads, generator=rng)[:num_ablate]
            head_mask = torch.zeros(num_heads, dtype=torch.float32)
            head_mask[indices] = 1.0
            trial.set_user_attr("head_mask", head_mask.tolist())
            trial.set_user_attr("head_ablation_fraction", head_fraction)

        # Partial projection scaling
        projection_strength = 1.0
        if settings.partial_projection:
            projection_strength = trial.suggest_float("projection_strength", 0.1, 1.0)
            trial.set_user_attr("projection_strength", projection_strength)

        # Adaptive layer selection threshold
        separability_threshold = 0.0
        if layer_separability is not None:
            separability_threshold = trial.suggest_float("separability_threshold", 0.0, 0.5)
            trial.set_user_attr("separability_threshold", separability_threshold)

        # Sparse ablation threshold
        if settings.sparsity_threshold > 0:
            sparsity = trial.suggest_float("sparsity_threshold", 0.01, 0.5)
            trial.set_user_attr("sparsity_threshold", sparsity)
            model.settings.sparsity_threshold = sparsity

        if dashboard:
            dashboard.update_trial(trial_index, f"Trial {trial_index}/{settings.n_trials}")
            dashboard.add_verbose_line(f"Running trial {trial_index} of {settings.n_trials}...")
            for name, value in get_trial_parameters(trial).items():
                dashboard.add_verbose_line(f"  * {name} = {value}")
        else:
            print()
            print(f"Running trial [bold]{trial_index}[/] of [bold]{settings.n_trials}[/]...")
            print("* Parameters:")
            for name, value in get_trial_parameters(trial).items():
                print(f"  * {name} = [bold]{value}[/]")

        if dashboard:
            dashboard.update_trial(trial_index, "Resetting model...")
        else:
            print("* Resetting model...")
        model.reset_model()

        if dashboard:
            dashboard.update_trial(trial_index, "Abliterating...")
        else:
            print("* Abliterating...")
        model.abliterate(trial_directions, direction_index, parameters, head_mask, projection_strength, layer_separability, separability_threshold)

        if dashboard:
            dashboard.update_trial(trial_index, "Evaluating...")
        else:
            print("* Evaluating...")
        score, kl_divergence, refusals = evaluator.get_score()

        elapsed_time = time.perf_counter() - start_time
        remaining_time = (elapsed_time / (trial_index - start_index)) * (
            settings.n_trials - trial_index
        )

        if not dashboard:
            print()
            print(f"[grey50]Elapsed time: [bold]{format_duration(elapsed_time)}[/][/]")
            if trial_index < settings.n_trials:
                print(
                    f"[grey50]Estimated remaining time: [bold]{format_duration(remaining_time)}[/][/]"
                )

        trial.set_user_attr("kl_divergence", kl_divergence)
        trial.set_user_attr("refusals", refusals)

        # Record trial duration for stats
        if dashboard:
            dashboard.record_trial_time(time.perf_counter() - trial_start)

        # Update dashboard with new Pareto front
        if dashboard:
            completed = [t for t in trial.study.trials if t.state == TrialState.COMPLETE]
            pareto_data = [{
                'trial': t.user_attrs.get('index', 0),
                'kl': t.user_attrs.get('kl_divergence', 0),
                'refusals': t.user_attrs.get('refusals', 0),
                'params': {
                    'direction_mode': t.user_attrs.get('direction_mode', 'mean'),
                    'direction_index': t.user_attrs.get('direction_index'),
                }
            } for t in completed]
            dashboard.update_pareto(pareto_data)

        return score

    def objective_wrapper(trial: Trial) -> tuple[float, float]:
        try:
            return objective(trial)
        except KeyboardInterrupt:
            trial.study.stop()
            raise TrialPruned()
        except torch.cuda.OutOfMemoryError:
            empty_cache()
            print(f"[red]Trial {trial.number} ran out of GPU memory, skipping.[/]")
            raise TrialPruned()

    def count_completed_trials() -> int:
        return sum(1 for t in study.trials if t.state == TrialState.COMPLETE)

    start_index = trial_index = count_completed_trials()
    if start_index > 0:
        print("Resuming existing study.")

    # Load and enqueue seed parameters if available
    if settings.use_seed_params and start_index == 0:
        seed_params = load_seed_params(seed_params_file)
        if seed_params:
            print()
            print(f"[cyan]Loading {len(seed_params)} seed parameter(s) from [bold]{seed_params_file}[/][/]")
            for i, sp in enumerate(seed_params):
                # Convert seed params to Optuna trial params format
                enqueue_params = {
                    "direction_mode": sp.get("direction_mode", "mean"),
                    "direction_scope": sp.get("direction_scope", "global" if sp.get("direction_index") is not None else "per layer"),
                    "direction_index": sp.get("direction_index", 0.6 * (len(model.get_layers()) - 1)),
                }
                # Add component-specific parameters
                for component, comp_params in sp.get("parameters", {}).items():
                    for param_name, param_value in comp_params.items():
                        enqueue_params[f"{component}.{param_name}"] = param_value
                # Add top-level params (projection_strength, dir_weight_*, etc.)
                for key, value in sp.get("top_level", {}).items():
                    enqueue_params[key] = value

                study.enqueue_trial(enqueue_params)
                ref = sp.get("refusals", sp.get("_refusals", "?"))
                kl = sp.get("kl_divergence", sp.get("_kl_divergence", "?"))
                if isinstance(kl, float):
                    kl = f"{kl:.4f}"
                print(f"  * Seed {i+1}: {ref} refusals, KL {kl}")

    def run_optimization():
        nonlocal dashboard
        n_remaining = settings.n_trials - count_completed_trials()
        if n_remaining <= 0:
            return

        if settings.dashboard and sys.stdin.isatty():
            with Dashboard(settings.n_trials, len(evaluator.bad_prompts)) as d:
                dashboard = d
                set_dashboard_active(True)
                d.current_trial = count_completed_trials()
                study.optimize(objective_wrapper, n_trials=n_remaining, show_progress_bar=False)
                set_dashboard_active(False)
                dashboard = None
        else:
            study.optimize(objective_wrapper, n_trials=n_remaining, show_progress_bar=False)

    try:
        run_optimization()
    except KeyboardInterrupt:
        # This additional handler takes care of the small chance that KeyboardInterrupt
        # is raised just between trials, which wouldn't be caught by the handler
        # defined in objective_wrapper above.
        pass

    if count_completed_trials() == settings.n_trials:
        study.set_user_attr("finished", True)

    # Auto-save best trials to seed file
    completed_trials = [t for t in study.trials if t.state == TrialState.COMPLETE]
    if completed_trials:
        new_seeds = update_best_seeds(seed_params_file, completed_trials)
        if new_seeds > 0:
            print()
            print(f"[green]Updated seed file with {new_seeds} new best trial(s) → [bold]{seed_params_file}[/][/]")

    def run_more():
        """Run more optimization trials. Called from the continue option in main."""
        nonlocal start_index, trial_index
        start_index = trial_index = count_completed_trials()
        try:
            run_optimization()
        except KeyboardInterrupt:
            pass
        if count_completed_trials() == settings.n_trials:
            study.set_user_attr("finished", True)
        # Save seeds after additional trials
        completed = [t for t in study.trials if t.state == TrialState.COMPLETE]
        if completed:
            new_seeds = update_best_seeds(seed_params_file, completed)
            if new_seeds > 0:
                print()
                print(f"[green]Updated seed file with {new_seeds} new best trial(s) → [bold]{seed_params_file}[/][/]")

    return count_completed_trials, run_more
