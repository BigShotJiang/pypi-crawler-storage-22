# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>
# Parallel multi-GPU model wrapper for true data parallelism

import traceback
from concurrent.futures import ThreadPoolExecutor

import torch
from torch import Tensor
from transformers import BatchEncoding

from .config import Settings
from .model import AbliterationParameters, Model
from .utils import Prompt, get_gpu_info, print


class ParallelModel:
    """
    Wrapper that loads separate model copies on multiple GPUs for true data parallelism.

    Unlike pipeline parallelism (device_map="auto"), this approach:
    - Loads a complete model copy on each GPU
    - Processes different batches on each GPU simultaneously
    - Achieves near-linear speedup for inference

    Requirements:
    - Model must fit on a single GPU
    - Multiple CUDA GPUs available
    """

    def __init__(self, settings: Settings, gpu_indices: list[int] | None = None):
        self.settings = settings

        # Detect available GPUs
        gpus = get_gpu_info()
        if len(gpus) < 2:
            raise RuntimeError(
                f"ParallelModel requires at least 2 GPUs (found {len(gpus)}). "
                "Use --multi-gpu=false for single GPU mode."
            )

        # Filter to requested GPUs if specified
        if gpu_indices is not None:
            gpus = [g for g in gpus if g["index"] in gpu_indices]

        if len(gpus) < 2:
            raise RuntimeError(f"Not enough GPUs available from requested indices: {gpu_indices}")

        self.gpu_indices = [g["index"] for g in gpus]
        self.num_gpus = len(self.gpu_indices)

        print(f"[bold green]Initializing ParallelModel with {self.num_gpus} GPUs[/]")
        for g in gpus:
            print(f"  * GPU {g['index']}: {g['name']} ({g['memory_gb']:.1f} GB)")

        # Create model instances - one per GPU
        self.models: list[Model] = []
        self.executor = ThreadPoolExecutor(max_workers=self.num_gpus)

        for i, gpu_idx in enumerate(self.gpu_indices):
            print(f"\n[bold]Loading model replica {i+1}/{self.num_gpus} on GPU {gpu_idx}...[/]")

            # Create settings copy pinned to this specific GPU
            gpu_settings = settings.model_copy(deep=True)
            gpu_settings.multi_gpu = False  # Disable multi-GPU in child - we handle it here
            gpu_settings.device_map = {"": gpu_idx}  # Pin entire model to this GPU
            gpu_settings.max_memory = None  # Not needed for single GPU

            model = Model(gpu_settings)
            self.models.append(model)

        # Forward attributes from first model
        self.tokenizer = self.models[0].tokenizer
        self._response_prefix = self.models[0].response_prefix
        self.needs_reload = False

        print(f"\n[bold green]ParallelModel ready - {self.num_gpus}x parallel inference[/]")

    @property
    def model(self):
        """For compatibility - returns first model's underlying model."""
        return self.models[0].model

    @property
    def response_prefix(self) -> str:
        """Get response prefix."""
        return self._response_prefix

    @response_prefix.setter
    def response_prefix(self, value: str):
        """Set response prefix on all model replicas."""
        self._response_prefix = value
        for model in self.models:
            model.response_prefix = value

    def set_batch_size(self, batch_size: int):
        """Set batch size on all model replicas (called after auto-detection)."""
        self.settings.batch_size = batch_size
        for model in self.models:
            model.settings.batch_size = batch_size

    def _split_prompts(self, prompts: list[Prompt]) -> list[list[Prompt]]:
        """Split prompts evenly across GPUs."""
        n = len(prompts)
        if n == 0:
            return []
        chunk_size = (n + self.num_gpus - 1) // self.num_gpus
        return [prompts[i:i + chunk_size] for i in range(0, n, chunk_size)]

    def _split_tokenized(self, inputs: BatchEncoding) -> list[BatchEncoding]:
        """Split tokenized inputs evenly across GPUs."""
        input_ids = inputs["input_ids"]
        assert isinstance(input_ids, Tensor)
        n = input_ids.shape[0]
        if n == 0:
            return []
        chunk_size = (n + self.num_gpus - 1) // self.num_gpus
        return [
            BatchEncoding({k: v[i:i + chunk_size] for k, v in inputs.items()})
            for i in range(0, n, chunk_size)
        ]

    def tokenize_prompts(self, prompts: list[Prompt]) -> BatchEncoding:
        """Pre-tokenize prompts using first model's tokenizer."""
        return self.models[0].tokenize_prompts(prompts)

    def reset_model(self):
        """Reset all model replicas."""
        print("* Resetting model replicas...")
        futures = [(self.gpu_indices[i], self.executor.submit(m.reset_model)) for i, m in enumerate(self.models)]
        errors = []
        for gpu_idx, f in futures:
            try:
                f.result()
            except Exception as e:
                errors.append(f"GPU {gpu_idx}: {e}\n{traceback.format_exc()}")
        if errors:
            self.needs_reload = True
            raise RuntimeError(f"reset_model failed on {len(errors)} GPU(s):\n" + "\n".join(errors))
        self.needs_reload = False

    def abliterate(
        self,
        refusal_directions: Tensor,
        direction_index: float | None,
        parameters: dict[str, AbliterationParameters],
        head_mask: Tensor | None = None,
        projection_strength: float = 1.0,
        layer_separability: Tensor | None = None,
        separability_threshold: float = 0.0,
    ):
        """Apply abliteration to all model replicas with same parameters."""
        futures = [
            (self.gpu_indices[i], self.executor.submit(
                m.abliterate, refusal_directions, direction_index, parameters,
                head_mask, projection_strength, layer_separability, separability_threshold,
            ))
            for i, m in enumerate(self.models)
        ]
        errors = []
        for gpu_idx, f in futures:
            try:
                f.result()
            except Exception as e:
                errors.append(f"GPU {gpu_idx}: {e}\n{traceback.format_exc()}")
        if errors:
            for m in self.models:
                m.needs_reload = True
            self.needs_reload = True
            raise RuntimeError(f"abliterate failed on {len(errors)} GPU(s) - model state may be inconsistent:\n" + "\n".join(errors))

    def get_residuals_batched(self, prompts: list[Prompt], positions: list[int] | None = None) -> Tensor:
        """Get residuals in parallel across GPUs."""
        if not prompts:
            return torch.empty(0)
        splits = self._split_prompts(prompts)

        # Submit work to each GPU
        futures = []
        for model, split in zip(self.models, splits):
            if split:  # Skip empty splits
                futures.append(self.executor.submit(model.get_residuals_batched, split, positions))

        # Gather results
        results = [f.result().cpu() for f in futures]
        return torch.cat(results, dim=0)

    def get_logprobs_batched(
        self,
        prompts: list[Prompt] | None = None,
        tokenized_inputs: BatchEncoding | None = None,
        n_tokens: int = 1,
    ) -> Tensor:
        """Get logprobs in parallel across GPUs."""
        if tokenized_inputs is None and not prompts:
            return torch.empty(0)
        if tokenized_inputs is not None:
            splits = self._split_tokenized(tokenized_inputs)
            futures = [
                self.executor.submit(model.get_logprobs_batched, None, split, n_tokens)
                for model, split in zip(self.models, splits)
                if split["input_ids"].shape[0] > 0
            ]
        else:
            splits = self._split_prompts(prompts or [])
            futures = [
                self.executor.submit(model.get_logprobs_batched, split, None, n_tokens)
                for model, split in zip(self.models, splits)
                if split
            ]

        results = [f.result().cpu() for f in futures]
        return torch.cat(results, dim=0)

    def get_continuation_tokens_batched(
        self,
        tokenized_inputs: BatchEncoding,
        n_tokens: int,
    ) -> Tensor:
        """Get greedy continuation tokens in parallel across GPUs."""
        splits = self._split_tokenized(tokenized_inputs)
        futures = [
            self.executor.submit(model.get_continuation_tokens_batched, split, n_tokens)
            for model, split in zip(self.models, splits)
            if split["input_ids"].shape[0] > 0
        ]
        return torch.cat([f.result().cpu() for f in futures], dim=0)

    def get_logprobs_teacher_forced_batched(
        self,
        tokenized_inputs: BatchEncoding,
        continuation_ids: Tensor,
    ) -> Tensor:
        """Get teacher-forced logprobs in parallel across GPUs."""
        splits = self._split_tokenized(tokenized_inputs)
        # Split continuation_ids to match
        sizes = [split["input_ids"].shape[0] for split in splits]  # ty:ignore[possibly-missing-attribute]
        cont_splits = continuation_ids.split(sizes)
        futures = [
            self.executor.submit(model.get_logprobs_teacher_forced_batched, split, cont)
            for model, split, cont in zip(self.models, splits, cont_splits)
            if split["input_ids"].shape[0] > 0
        ]
        return torch.cat([f.result().cpu() for f in futures], dim=0)

    def get_responses_batched(
        self,
        prompts: list[Prompt] | None = None,
        skip_special_tokens: bool = False,
        tokenized_inputs: BatchEncoding | None = None,
        early_exit_markers: list[str] | None = None,
        max_new_tokens: int | None = None,
    ) -> list[str]:
        """Get responses in parallel across GPUs."""
        if tokenized_inputs is not None:
            splits = self._split_tokenized(tokenized_inputs)
            futures = [
                self.executor.submit(
                    model.get_responses_batched, None, skip_special_tokens, split,
                    early_exit_markers, max_new_tokens
                )
                for model, split in zip(self.models, splits)
                if split["input_ids"].shape[0] > 0
            ]
        else:
            splits = self._split_prompts(prompts or [])
            futures = [
                self.executor.submit(
                    model.get_responses_batched, split, skip_special_tokens, None,
                    early_exit_markers, max_new_tokens
                )
                for model, split in zip(self.models, splits)
                if split
            ]

        results = []
        for f in futures:
            results.extend(f.result())
        return results

    def get_layers(self):
        """Forward to first model."""
        return self.models[0].get_layers()

    def get_layer_modules(self, layer_index: int):
        """Forward to first model."""
        return self.models[0].get_layer_modules(layer_index)

    def get_abliterable_components(self):
        """Forward to first model."""
        return self.models[0].get_abliterable_components()

    def get_attention_head_info(self):
        """Forward to first model."""
        return self.models[0].get_attention_head_info()

    def get_merged_model(self):
        """Get merged model from first replica (for saving)."""
        return self.models[0].get_merged_model()

    def get_responses(self, prompts: list[Prompt], skip_special_tokens: bool = False) -> list[str]:
        """Forward to first model (for single-batch operations)."""
        return self.models[0].get_responses(prompts, skip_special_tokens)

    def stream_chat_response(self, chat: list[dict[str, str]]) -> str:
        """Forward to first model (interactive chat)."""
        return self.models[0].stream_chat_response(chat)


def can_use_parallel_model(settings: Settings) -> bool:
    """
    Check if ParallelModel can be used for this configuration.

    Requirements:
    - multi_gpu enabled
    - At least 2 GPUs available
    - Estimated model size fits on single GPU with headroom
    """
    if not settings.multi_gpu:
        return False

    gpus = get_gpu_info()
    if len(gpus) < 2:
        return False

    # Filter to requested GPUs
    if settings.gpu_devices is not None:
        gpus = [g for g in gpus if g["index"] in settings.gpu_devices]

    if len(gpus) < 2:
        return False

    # Check if smallest GPU has enough memory
    # Conservative estimate: need at least 40GB for a typical abliteration workload
    min_memory = min(g["memory_gb"] for g in gpus)
    if min_memory < 40:
        print(f"[yellow]ParallelModel disabled: smallest GPU has {min_memory:.1f}GB (need 40GB+)[/]")
        return False

    return True
