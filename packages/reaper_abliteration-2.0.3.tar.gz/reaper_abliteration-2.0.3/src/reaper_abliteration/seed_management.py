# SPDX-License-Identifier: AGPL-3.0-or-later
import json
import os
import tempfile

from optuna import Trial


def trial_to_seed_params(trial: Trial) -> dict:
    """Convert an Optuna trial to seed params format.

    Uses trial.params (raw sampled values) so they can be enqueued directly.
    """
    # Extract component parameters from trial.params
    # Format: "attn.o_proj.max_weight" -> {"attn.o_proj": {"max_weight": value}}
    parameters = {}
    top_level_keys = {"direction_mode", "direction_scope", "direction_index"}
    top_level = {}
    for key, value in trial.params.items():
        if "." in key and key not in top_level_keys:
            parts = key.rsplit(".", 1)
            if len(parts) == 2:
                component, param_name = parts
                if component not in parameters:
                    parameters[component] = {}
                parameters[component][param_name] = value
        elif key not in top_level_keys:
            # Top-level params (projection_strength, separability_threshold,
            # head_ablation_fraction, dir_weight_*, position_weight_*, etc.)
            top_level[key] = value

    return {
        "direction_index": trial.params.get("direction_index"),
        "direction_scope": trial.params.get("direction_scope"),
        "parameters": parameters,
        "direction_mode": trial.params.get("direction_mode", "mean"),
        "top_level": top_level,
        "refusals": trial.user_attrs.get("refusals"),
        "kl_divergence": trial.user_attrs.get("kl_divergence"),
    }


def get_pareto_optimal(seeds: list[dict], max_count: int = 10) -> list[dict]:
    """Get Pareto-optimal seeds (minimizing both refusals and KL divergence)."""
    if not seeds:
        return []

    # Sort by refusals first, then KL divergence
    sorted_seeds = sorted(
        seeds,
        key=lambda s: (
            float("inf") if s.get("refusals") is None else s["refusals"],
            float("inf") if s.get("kl_divergence") is None else s["kl_divergence"],
        ),
    )

    # Find Pareto front
    pareto = []
    min_kl = float("inf")
    for seed in sorted_seeds:
        kl = float("inf") if seed.get("kl_divergence") is None else seed["kl_divergence"]
        if kl < min_kl:
            min_kl = kl
            pareto.append(seed)

    # Return up to max_count
    return pareto[:max_count]


def update_best_seeds(seed_params_file: str, new_trials: list[Trial], max_seeds: int = 10) -> int:
    """Update seed file with best Pareto-optimal trials. Returns number of new seeds added."""
    # Load existing seeds
    existing = []
    if os.path.exists(seed_params_file):
        try:
            with open(seed_params_file, "r") as f:
                existing = json.load(f)
        except json.JSONDecodeError:
            existing = []

    existing_count = len(existing)

    # Convert new trials to seed format
    new_seeds = [trial_to_seed_params(t) for t in new_trials]

    # Combine all seeds
    all_seeds = existing + new_seeds

    # Remove duplicates (same direction_index and parameters)
    unique_seeds = []
    seen = set()
    for seed in all_seeds:
        # Create a hashable key from the essential parameters
        key = (
            seed.get("direction_index"),
            json.dumps(seed.get("parameters", {}), sort_keys=True),
        )
        if key not in seen:
            seen.add(key)
            unique_seeds.append(seed)

    # Get Pareto optimal, limited to max_seeds
    best_seeds = get_pareto_optimal(unique_seeds, max_seeds)

    # Atomic write via tempfile+rename to prevent concurrent corruption
    dir_name = os.path.dirname(seed_params_file) or "."
    fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(best_seeds, f, indent=2)
        os.replace(tmp_path, seed_params_file)
    except BaseException:
        os.unlink(tmp_path)
        raise

    # Count how many are new (not in original existing)
    new_count = 0
    for seed in best_seeds:
        is_new = True
        for ex in existing[:existing_count]:
            if (seed.get("direction_index") == ex.get("direction_index") and
                seed.get("parameters") == ex.get("parameters")):
                is_new = False
                break
        if is_new:
            new_count += 1

    return new_count


def load_seed_params(seed_params_file: str) -> list[dict]:
    """Load seed parameters from file if it exists."""
    if not os.path.exists(seed_params_file):
        return []
    try:
        with open(seed_params_file, "r") as f:
            return json.load(f)
    except json.JSONDecodeError:
        print(f"[yellow]Warning: corrupt seed file {seed_params_file}, ignoring[/]")
        return []
