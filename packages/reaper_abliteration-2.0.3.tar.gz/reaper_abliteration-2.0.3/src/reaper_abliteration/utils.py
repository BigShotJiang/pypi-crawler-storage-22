# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

import gc
import getpass
import os
from dataclasses import dataclass
from importlib.metadata import version
from pathlib import Path
from typing import Any, TypeVar

import questionary
import torch
from accelerate.utils import (
    is_mlu_available,
    is_musa_available,
    is_sdaa_available,
    is_xpu_available,
)
from datasets import DatasetDict, ReadInstruction, load_dataset, load_from_disk
from datasets.config import DATASET_STATE_JSON_FILENAME
from datasets.download.download_manager import DownloadMode
from datasets.utils.info_utils import VerificationMode
from optuna import Trial
from questionary import Choice, Style
from rich.console import Console
from rich.progress import track as rich_track

from .config import DatasetSpecification, Settings

_console = Console(highlight=False)

# Global flag to suppress progress bars and prints when dashboard is active
_dashboard_active = False


def set_dashboard_active(active: bool) -> None:
    """Set whether dashboard is active (suppresses progress bars and prints)."""
    global _dashboard_active
    _dashboard_active = active


def print(*args, **kwargs) -> None:
    """Wrapper for rich console print that suppresses output when dashboard is active."""
    if not _dashboard_active:
        _console.print(*args, **kwargs)


def track(iterable, description: str = "", **kwargs):
    """Wrapper for rich.progress.track that suppresses output when dashboard is active."""
    if _dashboard_active:
        return iterable
    return rich_track(iterable, description=description, **kwargs)


def is_notebook() -> bool:
    # Check for specific environment variables (Colab, Kaggle).
    # This is necessary because when running as a subprocess (e.g. !abliterate),
    # get_ipython() might not be available or might not reflect the notebook environment.
    if os.getenv("COLAB_GPU") or os.getenv("KAGGLE_KERNEL_RUN_TYPE"):
        return True

    # Check IPython shell type (for library usage).
    try:
        from IPython import get_ipython  # ty:ignore[unresolved-import]

        shell = get_ipython()
        if shell is None:
            return False

        shell_name = shell.__class__.__name__
        if shell_name in ["ZMQInteractiveShell", "Shell"]:
            return True

        if "google.colab" in str(shell.__class__):
            return True

        return False
    except (ImportError, NameError, AttributeError):
        return False


def prompt_select(message: str, choices: list[Any]) -> Any:
    if is_notebook():
        print()
        print(message)
        real_choices = []

        for i, choice in enumerate(choices, 1):
            if isinstance(choice, Choice):
                print(f"[{i}] {choice.title}")
                real_choices.append(choice.value)
            else:
                print(f"[{i}] {choice}")
                real_choices.append(choice)

        while True:
            try:
                selection = input("Enter number: ")
                index = int(selection) - 1
                if 0 <= index < len(real_choices):
                    return real_choices[index]
                print(
                    f"[red]Please enter a number between 1 and {len(real_choices)}[/]"
                )
            except ValueError:
                print("[red]Invalid input. Please enter a number.[/]")
    else:
        return questionary.select(
            message,
            choices=choices,
            style=Style([("highlighted", "reverse")]),
        ).ask()


def prompt_text(
    message: str,
    default: str = "",
    qmark: str = "?",
    unsafe: bool = False,
) -> str:
    if is_notebook():
        print()
        result = input(f"{message} [{default}]: " if default else f"{message}: ")
        return result if result else default
    else:
        question = questionary.text(message, default=default, qmark=qmark)
        if unsafe:
            return question.unsafe_ask()
        else:
            return question.ask()


def prompt_path(message: str) -> str:
    if is_notebook():
        return prompt_text(message)
    else:
        return questionary.path(message, only_directories=True).ask()


def prompt_password(message: str) -> str:
    if is_notebook():
        print()
        return getpass.getpass(message)
    else:
        return questionary.password(message).ask()


def format_duration(seconds: float) -> str:
    seconds = round(seconds)
    hours, seconds = divmod(seconds, 3600)
    minutes, seconds = divmod(seconds, 60)

    if hours > 0:
        return f"{hours}h {minutes}m"
    elif minutes > 0:
        return f"{minutes}m {seconds}s"
    else:
        return f"{seconds}s"


@dataclass
class Prompt:
    system: str
    user: str


def load_prompts(
    settings: Settings,
    specification: DatasetSpecification,
) -> list[Prompt]:
    path = specification.dataset
    split_str = specification.split

    if os.path.isdir(path):
        if Path(path, DATASET_STATE_JSON_FILENAME).exists():
            # Dataset saved with datasets.save_to_disk; needs special handling.
            # Path should be the subdirectory for a particular split.
            dataset = load_from_disk(path)
            assert not isinstance(dataset, DatasetDict), (
                "Loading dataset dicts is not supported"
            )
            # Parse the split instructions.
            instruction = ReadInstruction.from_spec(split_str)
            # Associate the split with its number of examples (lines).
            # When dataset.split is None (save_to_disk loses metadata), parse from split_str.
            # Use string parsing (public API) instead of internal _relative_instructions.
            split_name = str(dataset.split) if dataset.split else split_str.split('+')[0].split('[')[0].strip()
            name2len = {split_name: len(dataset)}
            # Convert the instructions to absolute indices and select the first one.
            abs_instruction = instruction.to_absolute(name2len)[0]
            # Get the dataset by applying the indices.
            dataset = dataset.select(range(abs_instruction.from_, abs_instruction.to))
        else:
            # Path is a local directory.
            dataset = load_dataset(
                path,
                split=split_str,
                # Don't require the number of examples (lines) per split to be pre-defined.
                verification_mode=VerificationMode.NO_CHECKS,
                # But also don't use cached data, as the dataset may have changed on disk.
                download_mode=DownloadMode.FORCE_REDOWNLOAD,
            )
    else:
        # Probably a repository path; let load_dataset figure it out.
        dataset = load_dataset(path, split=split_str)

    assert dataset.column_names is not None
    if specification.column not in dataset.column_names:
        raise ValueError(f"Column '{specification.column}' not found. Available: {dataset.column_names}")
    prompts = list(dataset[specification.column])

    if specification.prefix:
        prompts = [f"{specification.prefix} {prompt}" for prompt in prompts]

    if specification.suffix:
        prompts = [f"{prompt} {specification.suffix}" for prompt in prompts]

    system_prompt = (
        settings.system_prompt
        if specification.system_prompt is None
        else specification.system_prompt
    )

    return [
        Prompt(
            system=system_prompt,
            user=prompt,
        )
        for prompt in prompts
    ]


T = TypeVar("T")


def batchify(items: list[T], batch_size: int) -> list[list[T]]:
    return [items[i : i + batch_size] for i in range(0, len(items), batch_size)]


def empty_cache():
    # Collecting garbage is not an idempotent operation, and to avoid OOM errors,
    # gc.collect() has to be called both before and after emptying the backend cache.
    # See https://github.com/p-e-w/heretic/pull/17 for details.
    gc.collect()

    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    elif is_xpu_available():
        torch.xpu.empty_cache()
    elif is_mlu_available():
        torch.mlu.empty_cache()  # ty:ignore[unresolved-attribute]
    elif is_sdaa_available():
        torch.sdaa.empty_cache()  # ty:ignore[unresolved-attribute]
    elif is_musa_available():
        torch.musa.empty_cache()  # ty:ignore[unresolved-attribute]
    elif torch.backends.mps.is_available():
        torch.mps.empty_cache()

    gc.collect()


def get_gpu_info() -> list[dict]:
    """Get info and memory usage for all CUDA GPUs.

    Returns list of dicts with keys: index, name, memory_gb, memory_free_gb,
    used_gb, total_gb, pct. Empty list if no CUDA GPUs.
    """
    if not torch.cuda.is_available():
        return []
    gpus = []
    for i in range(torch.cuda.device_count()):
        props = torch.cuda.get_device_properties(i)
        free, total = torch.cuda.mem_get_info(i)
        allocated = torch.cuda.memory_allocated(i)
        gpus.append({
            "index": i,
            "name": props.name,
            "memory_gb": round(total / (1024**3), 2),
            "memory_free_gb": round(free / (1024**3), 2),
            "used_gb": allocated / (1024**3),
            "total_gb": total / (1024**3),
            "pct": int(100 * allocated / total) if total > 0 else 0,
        })
    return gpus


# Backwards compat aliases
get_available_gpus = get_gpu_info
get_gpu_memory_info = get_gpu_info


def log_gpu_utilization():
    """Log current GPU memory usage."""
    for gpu in get_gpu_info():
        print(f"GPU {gpu['index']} ({gpu['name']}): {gpu['used_gb']:.1f} / {gpu['total_gb']:.1f} GB ({gpu['pct']}%)")


def get_trial_parameters(trial: Trial) -> dict[str, str]:
    params = {}

    # Show direction_mode if available (PCA feature)
    direction_mode = trial.user_attrs.get("direction_mode", "mean")
    if direction_mode != "mean":
        params["direction_mode"] = direction_mode

    # Show position weights if available (multi-position feature)
    position_weights = trial.user_attrs.get("position_weights")
    if position_weights:
        weights_str = ", ".join(f"{k}:{v:.2f}" for k, v in position_weights.items())
        params["position_weights"] = weights_str

    # Show head ablation fraction if available (per-head feature)
    head_fraction = trial.user_attrs.get("head_ablation_fraction")
    if head_fraction is not None:
        head_mask = trial.user_attrs.get("head_mask", [])
        num_ablated = sum(1 for h in head_mask if h > 0.5)
        params["head_ablation"] = f"{num_ablated}/{len(head_mask)} heads ({head_fraction:.1%})"

    direction_index = trial.user_attrs.get("direction_index")
    params["direction_index"] = (
        "per layer" if (direction_index is None) else f"{direction_index:.2f}"
    )

    for component, parameters in trial.user_attrs.get("parameters", {}).items():
        for name, value in parameters.items():
            params[f"{component}.{name}"] = f"{value:.2f}"

    return params


def get_readme_intro(
    settings: Settings,
    trial: Trial,
    base_refusals: int,
    bad_prompts: list[Prompt],
) -> str:
    model_link = f"[{settings.model}](https://huggingface.co/{settings.model})"

    return f"""# This is a decensored version of {
        model_link
    }, made using [Reaper Abliteration](https://github.com/hauhaut/reaper-abliteration) v{version("reaper-abliteration")}

## Abliteration parameters

| Parameter | Value |
| :-------- | :---: |
{
        chr(10).join(
            [
                f"| **{name}** | {value} |"
                for name, value in get_trial_parameters(trial).items()
            ]
        )
    }

## Performance

| Metric | This model | Original model ({model_link}) |
| :----- | :--------: | :---------------------------: |
| **KL divergence** | {trial.user_attrs["kl_divergence"]:.4f} | 0 *(by definition)* |
| **Refusals** | {trial.user_attrs["refusals"]}/{len(bad_prompts)} | {base_refusals}/{
        len(bad_prompts)
    } |

-----

"""


def calculate_device_map(
    gpus: list[dict],
    gpu_devices: list[int] | None = None,
    strategy: str = "auto",
) -> tuple[str | dict, dict[str, str] | None]:
    """
    Calculate device_map and max_memory for multi-GPU distribution.

    Returns:
        (device_map, max_memory) tuple
    """
    if not gpus:
        return "auto", None

    # Filter GPUs if specific devices requested
    if gpu_devices is not None:
        gpus = [g for g in gpus if g["index"] in gpu_devices]
        if not gpus:
            return "auto", None

    # Single GPU or sequential: let accelerate handle it
    if len(gpus) == 1 or strategy == "sequential":
        return "auto", None

    # Multi-GPU: build max_memory dict to help accelerate distribute
    # Reserve 2GB per GPU for overhead
    max_memory = {
        str(g["index"]): f"{max(1, int(g['memory_gb'] - 2))}GB"
        for g in gpus
    }
    return "auto", max_memory
