"""Responsible for parsing configuration file and converting them to sync tasks."""
