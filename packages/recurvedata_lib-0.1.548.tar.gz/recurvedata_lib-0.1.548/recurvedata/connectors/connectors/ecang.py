import hashlib
import time
import uuid
from collections import OrderedDict

import requests

from recurvedata.connectors._register import register_connector_class
from recurvedata.connectors.base import RecurveConnectorBase
from recurvedata.connectors.proxy import HTTP_PROXY_CONFIG_SCHEMA, HttpProxyMixin
from recurvedata.consts import ConnectorGroup
from recurvedata.core.translation import _l

CONNECTION_TYPE = "ecang"
UI_CONNECTION_TYPE = "Ecang"


@register_connector_class([CONNECTION_TYPE, UI_CONNECTION_TYPE])
class Ecang(HttpProxyMixin, RecurveConnectorBase):
    """
    Ecang (易仓) WMS System Connector

    Ecang is a warehouse management system that provides APIs for order management,
    inventory tracking, and logistics operations.
    """

    connection_type = CONNECTION_TYPE
    ui_connection_type = UI_CONNECTION_TYPE
    group = [ConnectorGroup.DESTINATION]
    enabled = True

    config_schema = {
        "type": "object",
        "properties": {
            "base_url": {
                "type": "string",
                "title": _l("API Base URL"),
                "description": _l("Ecang API endpoint URL"),
                "default": "http://openapi-web.eccang.com/openApi/api/unity",
            },
            "app_key": {
                "type": "string",
                "title": _l("App Key"),
                "description": _l("Ecang application key"),
            },
            "secret": {
                "type": "string",
                "title": _l("Secret Key"),
                "description": _l("Ecang application secret key"),
            },
            "service_id": {
                "type": "string",
                "title": _l("Service ID"),
                "description": _l("Ecang service identifier"),
            },
            "version": {
                "type": "string",
                "title": _l("API Version"),
                "description": _l("Ecang API version"),
                "default": "1.0",
            },
            "proxies": HTTP_PROXY_CONFIG_SCHEMA["proxies"],
        },
        "order": ["base_url", "app_key", "secret", "service_id", "version", "proxies"],
        "required": ["app_key", "secret", "service_id"],
        "secret": ["secret"],
    }

    def _generate_signature(self, params: dict) -> str:
        """
        Generate MD5 signature for Ecang API authentication

        :param params: Request parameters
        :return: MD5 signature string
        """
        # Sort parameters using TreeMap (OrderedDict in Python)
        sorted_params = OrderedDict(sorted(params.items()))

        # Build signature string
        sign_str = ""
        for key, value in sorted_params.items():
            if value is not None and value != "":
                sign_str += f"{key}{value}"

        # Add secret key
        sign_str += self.secret

        # Generate MD5 hash
        md5_hash = hashlib.md5(sign_str.encode("utf-8")).hexdigest()
        return md5_hash.upper()

    def _make_request(self, service_name: str, params: dict = None) -> dict:
        """
        Make API request to Ecang

        :param service_name: Service name to call
        :param params: Additional parameters
        :return: Response data
        """
        if params is None:
            params = {}

        # Build request parameters
        request_params = {
            "app_key": self.app_key,
            "service_id": service_name,
            "timestamp": str(int(time.time() * 1000)),
            "nonce_str": str(uuid.uuid4()).replace("-", ""),
            "version": self.version or "1.0",
        }

        # Add custom parameters
        request_params.update(params)

        # Generate signature
        request_params["sign"] = self._generate_signature(request_params)

        # Get base URL
        base_url = self.base_url or "http://openapi-web.eccang.com/openApi/api/unity"

        # Make request with proxy support
        with self._init_proxy_manager():
            response = requests.post(
                base_url,
                json=request_params,
                timeout=30,
            )
            response.raise_for_status()

        data = response.json()

        # Check response status
        if data.get("code") != 0:
            raise ValueError(f"Ecang API error: {data.get('message', 'Unknown error')}")

        return data

    def test_connection(self):
        """
        Test connection by calling getCurrencyList API
        This is a lightweight API that returns currency information
        """
        try:
            # Call getCurrencyList service to test connection
            result = self._make_request("getCurrencyList")

            # Verify response structure
            if "data" not in result:
                raise ValueError("Invalid response structure from Ecang API")

            return True
        except Exception as e:
            raise ValueError(f"Failed to connect to Ecang: {str(e)}")
