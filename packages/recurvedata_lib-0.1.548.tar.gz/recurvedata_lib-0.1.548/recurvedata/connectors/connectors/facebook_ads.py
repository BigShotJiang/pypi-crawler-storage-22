import json
import time
from pathlib import Path

import requests

from recurvedata.config import EXECUTOR_RECURVE_HOME
from recurvedata.connectors._register import register_connector_class
from recurvedata.connectors.base import RecurveConnectorBase
from recurvedata.connectors.proxy import HTTP_PROXY_CONFIG_SCHEMA, HttpProxyMixin
from recurvedata.consts import ConnectorGroup
from recurvedata.core.translation import _l

CONNECTION_TYPE = "facebook_ads"
UI_CONNECTION_TYPE = "Facebook Ads"

# Default token file directory
TOKEN_FILE_DIR = EXECUTOR_RECURVE_HOME / "tokens" / "facebook_ads"

# Auto-refresh when token expires within 7 days
TOKEN_REFRESH_THRESHOLD = 7 * 24 * 60 * 60


@register_connector_class([CONNECTION_TYPE, UI_CONNECTION_TYPE])
class FacebookAds(HttpProxyMixin, RecurveConnectorBase):
    """
    Facebook Ads API Connector

    Provides access to Facebook Ads data including campaigns, ad sets, ads,
    and performance metrics through the Facebook Marketing API.

    Token Management:
        - Requires a long-lived access token (60-day validity)
        - Token is automatically refreshed when expiring within 7 days
        - Refreshed tokens are saved to local file for persistence
    """

    connection_type = CONNECTION_TYPE
    ui_connection_type = UI_CONNECTION_TYPE
    group = [ConnectorGroup.DESTINATION]
    enabled = True

    config_schema = {
        "type": "object",
        "properties": {
            "app_id": {
                "type": "string",
                "title": _l("App ID"),
                "description": _l("Facebook App ID"),
            },
            "app_secret": {
                "type": "string",
                "title": _l("App Secret"),
                "description": _l("Facebook App Secret"),
            },
            "access_token": {
                "type": "string",
                "title": _l("Access Token"),
                "description": _l("Facebook long-lived access token (valid for 60 days)"),
            },
            "api_version": {
                "type": "string",
                "title": _l("API Version"),
                "description": _l("Facebook Graph API version (e.g., v18.0)"),
                "default": "v18.0",
            },
            "proxies": HTTP_PROXY_CONFIG_SCHEMA["proxies"],
        },
        "order": ["app_id", "app_secret", "access_token", "api_version", "proxies"],
        "required": ["app_id", "app_secret", "access_token"],
        "secret": ["app_secret", "access_token"],
    }

    @property
    def _api_version(self) -> str:
        """Get API version with default fallback"""
        return self.api_version or "v18.0"

    def _get_api_base_url(self) -> str:
        """Get Facebook Graph API base URL"""
        return f"https://graph.facebook.com/{self._api_version}"

    def _get_token_file_path(self) -> Path:
        """
        Get the token file path for this connector instance.

        Token file is stored at: {EXECUTOR_RECURVE_HOME}/tokens/facebook_ads/{app_id}.json

        :return: Path to the token file
        """
        return TOKEN_FILE_DIR / f"{self.app_id}.json"

    def ensure_access_token(self) -> str:
        """
        Get the current access token, auto-refreshing if expired or expiring soon.

        Priority:
        1. Token from file (auto-refresh if expiring within 7 days)
        2. Config token (auto-refresh on first use)

        :return: Access token string
        """
        token_info = self._load_token_info_from_file()

        if token_info and token_info.get("access_token"):
            # Check if token needs refresh
            if not self._is_token_expiring(token_info):
                return token_info["access_token"]
            # Try to refresh
            try:
                return self._do_refresh(token_info["access_token"])["access_token"]
            except Exception:
                return token_info["access_token"]  # Fallback to old token

        # No file, refresh config token on first use
        try:
            return self._do_refresh(self.access_token)["access_token"]
        except Exception:
            return self.access_token

    def _is_token_expiring(self, token_info: dict) -> bool:
        """Check if token is expired or expiring within threshold."""
        created_at = token_info.get("created_at")
        expires_in = token_info.get("expires_in")
        if not created_at or not expires_in:
            return True
        remaining = created_at + expires_in - int(time.time())
        return remaining <= TOKEN_REFRESH_THRESHOLD

    def _load_token_info_from_file(self) -> dict | None:
        """
        Load token information from local file.

        :return: Token info dictionary or None if file doesn't exist or is invalid
        """
        token_file_path = self._get_token_file_path()

        if not token_file_path.exists():
            return None

        try:
            with open(token_file_path, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return None

    def _save_token_to_file(self, token_info: dict) -> None:
        """
        Save token information to local file.

        :param token_info: Token information dictionary containing access_token, expires_in, etc.
        """
        token_file_path = self._get_token_file_path()

        # Add created_at timestamp for expiration tracking
        token_info["created_at"] = int(time.time())

        # Ensure directory exists
        token_file_path.parent.mkdir(parents=True, exist_ok=True)

        with open(token_file_path, "w") as f:
            json.dump(token_info, f, indent=2)

    def _make_request(self, endpoint: str, params: dict = None) -> dict:
        """
        Make API request to Facebook Graph API

        :param endpoint: API endpoint (e.g., '/me', '/act_123/campaigns')
        :param params: Query parameters
        :return: Response data
        """
        if params is None:
            params = {}

        # Add access token to parameters (use current token from file or config)
        params["access_token"] = self.ensure_access_token()

        # Build full URL
        base_url = self._get_api_base_url()
        url = f"{base_url}{endpoint}"

        # Make request with proxy support
        with self._init_proxy_manager():
            response = requests.get(
                url,
                params=params,
                timeout=30,
            )
            response.raise_for_status()

        data = response.json()

        # Check for API errors
        if "error" in data:
            error = data["error"]
            raise ValueError(
                f"Facebook API error: {error.get('message', 'Unknown error')} " f"(code: {error.get('code', 'N/A')})"
            )

        return data

    def get_user_info(self) -> dict:
        """
        Get current user information

        :return: User information dictionary
        """
        return self._make_request("/me", {"fields": "id,name,email"})

    def get_ad_accounts(self) -> list:
        """
        Get list of ad accounts accessible by the current user

        :return: List of ad account dictionaries
        """
        result = self._make_request("/me/adaccounts", {"fields": "id,name,account_status"})
        return result.get("data", [])

    def _do_refresh(self, current_token: str) -> dict:
        """
        Internal method to refresh access token.

        :param current_token: The token to exchange
        :return: Token info dictionary
        :raises ValueError: If refresh fails
        """
        url = f"https://graph.facebook.com/{self._api_version}/oauth/access_token"

        params = {
            "grant_type": "fb_exchange_token",
            "client_id": self.app_id,
            "client_secret": self.app_secret,
            "fb_exchange_token": current_token,
        }

        with self._init_proxy_manager():
            response = requests.get(url, params=params, timeout=30)
        response.raise_for_status()

        data = response.json()

        if "error" in data:
            error = data["error"]
            raise ValueError(
                f"Failed to refresh access token: {error.get('message', 'Unknown error')} "
                f"(code: {error.get('code', 'N/A')})"
            )

        if "access_token" not in data:
            raise ValueError("Failed to refresh access token: No access_token in response")

        token_info = {
            "access_token": data["access_token"],
            "token_type": data.get("token_type", "bearer"),
            "expires_in": data.get("expires_in"),
        }

        self._save_token_to_file(token_info)
        return token_info

    def test_connection(self) -> bool:
        """
        Test connection by retrieving user information
        """
        try:
            # Get user info to verify access token
            user_info = self.get_user_info()

            if "id" not in user_info:
                raise ValueError("Invalid response from Facebook API")

            # Optionally verify ad account access
            ad_accounts = self.get_ad_accounts()

            if not isinstance(ad_accounts, list):
                raise ValueError("Failed to retrieve ad accounts")

            return True
        except Exception as e:
            raise ValueError(f"Failed to connect to Facebook Ads: {str(e)}") from e
