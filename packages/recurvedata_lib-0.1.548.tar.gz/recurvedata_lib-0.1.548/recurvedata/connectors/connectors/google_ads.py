import requests
from requests.exceptions import ConnectionError, Timeout

from recurvedata.connectors._register import register_connector_class
from recurvedata.connectors.base import RecurveConnectorBase
from recurvedata.connectors.proxy import HTTP_PROXY_CONFIG_SCHEMA, HttpProxyMixin
from recurvedata.consts import ConnectorGroup
from recurvedata.core.translation import _l
from recurvedata.utils.cache import cached

CONNECTION_TYPE = "google_ads"
UI_CONNECTION_TYPE = "Google Ads"


class GoogleAdsAuthError(Exception):
    """
    Raised when Google OAuth authentication fails.

    This typically indicates that the refresh_token has expired or been revoked,
    and the user needs to re-authorize the application.
    """

    pass


class GoogleAdsNetworkError(Exception):
    """
    Raised when a network error occurs while communicating with Google APIs.

    This is typically a transient error that may be resolved by retrying.
    """

    pass


@register_connector_class([CONNECTION_TYPE, UI_CONNECTION_TYPE])
class GoogleAds(HttpProxyMixin, RecurveConnectorBase):
    """
    Google Ads API Connector

    Provides access to Google Ads data including campaigns, ad groups, ads,
    and performance metrics through the Google Ads API.
    """

    connection_type = CONNECTION_TYPE
    ui_connection_type = UI_CONNECTION_TYPE
    group = [ConnectorGroup.DESTINATION]
    enabled = True

    config_schema = {
        "type": "object",
        "properties": {
            "developer_token": {
                "type": "string",
                "title": _l("Developer Token"),
                "description": _l("Google Ads API developer token"),
            },
            "client_id": {
                "type": "string",
                "title": _l("OAuth Client ID"),
                "description": _l("OAuth 2.0 client ID"),
            },
            "client_secret": {
                "type": "string",
                "title": _l("OAuth Client Secret"),
                "description": _l("OAuth 2.0 client secret"),
            },
            "refresh_token": {
                "type": "string",
                "title": _l("Refresh Token"),
                "description": _l("OAuth 2.0 refresh token for long-lived access"),
            },
            "login_customer_id": {
                "type": "string",
                "title": _l("Login Customer ID"),
                "description": _l("Manager account customer ID (without hyphens)"),
            },
            "api_version": {
                "type": "string",
                "title": _l("API Version"),
                "description": _l("Google Ads API version (e.g., v16)"),
                "default": "v16",
            },
            "proxies": HTTP_PROXY_CONFIG_SCHEMA["proxies"],
        },
        "order": [
            "developer_token",
            "client_id",
            "client_secret",
            "refresh_token",
            "login_customer_id",
            "api_version",
            "proxies",
        ],
        "required": ["developer_token", "client_id", "client_secret", "refresh_token"],
        "secret": ["developer_token", "client_secret", "refresh_token"],
    }

    @cached(ttl=600)
    def _get_access_token(self) -> str:
        """
        Get access token using refresh token.

        The access token is cached for 10 minutes (600 seconds).
        Google access tokens are typically valid for 1 hour.

        :return: Access token string
        :raises GoogleAdsAuthError: If refresh_token is invalid or expired
        :raises GoogleAdsNetworkError: If network error occurs
        """
        token_url = "https://oauth2.googleapis.com/token"

        data = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "refresh_token": self.refresh_token,
            "grant_type": "refresh_token",
        }

        try:
            with self._init_proxy_manager():
                response = requests.post(token_url, data=data, timeout=30)

                # Parse response regardless of status code to check for OAuth errors
                token_data = response.json()

                # Check for OAuth error response
                if "error" in token_data:
                    error = token_data.get("error")
                    error_description = token_data.get("error_description", "")

                    if error == "invalid_grant":
                        raise GoogleAdsAuthError(
                            f"Refresh token is invalid or expired: {error_description}. "
                            "Please re-authorize the application to obtain a new refresh token. "
                            "Common causes: 1) Token was revoked by user, 2) Token expired due to "
                            "Google Cloud project being in 'Testing' mode (7-day expiry), "
                            "3) Token unused for 6+ months, 4) User changed password."
                        )
                    elif error == "invalid_client":
                        raise GoogleAdsAuthError(
                            f"Invalid OAuth client credentials: {error_description}. "
                            "Please verify your client_id and client_secret are correct."
                        )
                    else:
                        raise GoogleAdsAuthError(f"OAuth error ({error}): {error_description}")

                response.raise_for_status()

                if "access_token" not in token_data:
                    raise ValueError("Failed to obtain access token from Google: No access_token in response")

                return token_data["access_token"]

        except GoogleAdsAuthError:
            raise
        except (ConnectionError, Timeout) as e:
            raise GoogleAdsNetworkError(
                f"Network error while refreshing access token: {str(e)}. "
                "Please check your network connection and proxy settings."
            )
        except requests.exceptions.HTTPError as e:
            raise GoogleAdsNetworkError(f"HTTP error while refreshing access token: {str(e)}")

    def _get_user_info(self, access_token: str) -> dict:
        """
        Get user information using access token

        :param access_token: OAuth access token
        :return: User information dictionary
        """
        user_info_url = "https://www.googleapis.com/oauth2/v1/userinfo"

        headers = {"Authorization": f"Bearer {access_token}"}

        with self._init_proxy_manager():
            response = requests.get(user_info_url, headers=headers, timeout=30)
            response.raise_for_status()

            return response.json()

    def _make_api_request(self, customer_id: str, query: str) -> dict:
        """
        Make Google Ads API request using GAQL (Google Ads Query Language)

        :param customer_id: Customer ID (without hyphens)
        :param query: GAQL query string
        :return: Response data
        """
        access_token = self._get_access_token()

        api_version = self.api_version or "v16"
        url = f"https://googleads.googleapis.com/{api_version}/customers/{customer_id}/googleAds:search"

        headers = {
            "Authorization": f"Bearer {access_token}",
            "developer-token": self.developer_token,
            "Content-Type": "application/json",
        }

        # Add login customer ID if provided
        if self.login_customer_id:
            headers["login-customer-id"] = self.login_customer_id

        data = {"query": query}

        with self._init_proxy_manager():
            response = requests.post(url, json=data, headers=headers, timeout=30)
            response.raise_for_status()

            return response.json()

    def test_connection(self):
        """
        Test connection by verifying OAuth credentials and API access
        """
        try:
            # Step 1: Get access token using refresh token
            access_token = self._get_access_token()

            if not access_token:
                raise ValueError("Failed to obtain access token")

            # Step 2: Get user info to verify OAuth credentials
            user_info = self._get_user_info(access_token)

            if "email" not in user_info:
                raise ValueError("Invalid user information from Google")

            # Step 3: If login_customer_id is provided, test API access
            if self.login_customer_id:
                # Simple query to test API access
                query = "SELECT customer.id, customer.descriptive_name FROM customer LIMIT 1"
                result = self._make_api_request(self.login_customer_id, query)

                if "results" not in result and "fieldMask" not in result:
                    raise ValueError("Invalid response from Google Ads API")

            return True
        except GoogleAdsAuthError as e:
            raise ValueError(f"Authentication failed: {str(e)}")
        except GoogleAdsNetworkError as e:
            raise ValueError(f"Network error: {str(e)}")
        except Exception as e:
            raise ValueError(f"Failed to connect to Google Ads: {str(e)}")
