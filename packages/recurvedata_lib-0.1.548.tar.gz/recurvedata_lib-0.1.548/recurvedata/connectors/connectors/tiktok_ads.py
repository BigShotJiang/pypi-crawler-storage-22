import requests

from recurvedata.connectors._register import register_connector_class
from recurvedata.connectors.base import RecurveConnectorBase
from recurvedata.connectors.proxy import HTTP_PROXY_CONFIG_SCHEMA, HttpProxyMixin
from recurvedata.consts import ConnectorGroup
from recurvedata.core.translation import _l
from recurvedata.utils.cache import cached

CONNECTION_TYPE = "tiktok_ads"
UI_CONNECTION_TYPE = "TikTok Ads"


@register_connector_class([CONNECTION_TYPE, UI_CONNECTION_TYPE])
class TikTokAds(HttpProxyMixin, RecurveConnectorBase):
    """
    TikTok Ads API Connector

    Provides access to TikTok Ads data including campaigns, ad groups, ads,
    and performance metrics through the TikTok Marketing API.

    Token Management:
        - Uses refresh_token (valid for 365 days) to obtain access_token
        - access_token is automatically refreshed and cached (valid for 24 hours)
        - No manual token refresh needed during normal operation

    Example:
        >>> connector = TikTokAds(config)
        >>> # Access token is automatically obtained using refresh_token
        >>> advertiser_info = connector.get_advertiser_info(['advertiser_id'])
    """

    connection_type = CONNECTION_TYPE
    ui_connection_type = UI_CONNECTION_TYPE
    group = [ConnectorGroup.DESTINATION]
    enabled = True

    config_schema = {
        "type": "object",
        "properties": {
            "app_id": {
                "type": "string",
                "title": _l("App ID"),
                "description": _l("TikTok for Business App ID"),
            },
            "app_secret": {
                "type": "string",
                "title": _l("App Secret"),
                "description": _l("TikTok for Business App Secret"),
            },
            "refresh_token": {
                "type": "string",
                "title": _l("Refresh Token"),
                "description": _l(
                    "TikTok OAuth refresh token (valid for 365 days). " "Used to automatically obtain access tokens."
                ),
            },
            "api_version": {
                "type": "string",
                "title": _l("API Version"),
                "description": _l("TikTok Marketing API version"),
                "default": "v1.3",
            },
            "proxies": HTTP_PROXY_CONFIG_SCHEMA["proxies"],
        },
        "order": ["app_id", "app_secret", "refresh_token", "api_version", "proxies"],
        "required": ["app_id", "app_secret", "refresh_token"],
        "secret": ["app_secret", "refresh_token"],
    }

    def _get_api_base_url(self) -> str:
        """Get TikTok Marketing API base URL"""
        return "https://business-api.tiktok.com/open_api"

    @cached(ttl=3600)
    def _get_access_token(self) -> str:
        """
        Get access token using refresh token.

        The access token is cached for 1 hour (3600 seconds) to reduce API calls.
        TikTok access tokens are valid for 24 hours.

        :return: Access token string
        :raises ValueError: If token refresh fails
        """
        api_version = self.api_version or "v1.3"
        url = f"{self._get_api_base_url()}/{api_version}/oauth2/refresh_token/"

        data = {
            "app_id": self.app_id,
            "secret": self.app_secret,
            "refresh_token": self.refresh_token,
            "grant_type": "refresh_token",
        }

        with self._init_proxy_manager():
            response = requests.post(url, json=data, timeout=30)
            response.raise_for_status()

        result = response.json()

        if result.get("code") != 0:
            raise ValueError(
                f"Failed to refresh access token: {result.get('message', 'Unknown error')} "
                f"(code: {result.get('code', 'N/A')})"
            )

        token_data = result.get("data", {})
        access_token = token_data.get("access_token")

        if not access_token:
            raise ValueError("Failed to obtain access token: No access_token in response")

        return access_token

    def _make_request(self, endpoint: str, params: dict = None, method: str = "GET") -> dict:
        """
        Make API request to TikTok Marketing API

        :param endpoint: API endpoint (e.g., '/v1.3/advertiser/info/')
        :param params: Query parameters or request body
        :param method: HTTP method (GET or POST)
        :return: Response data
        """
        if params is None:
            params = {}

        # Build full URL
        base_url = self._get_api_base_url()
        api_version = self.api_version or "v1.3"

        # Ensure endpoint starts with version if not already included
        if not endpoint.startswith("/v"):
            endpoint = f"/{api_version}{endpoint}"

        url = f"{base_url}{endpoint}"

        # Get access token dynamically
        access_token = self._get_access_token()

        # Add access token to headers
        headers = {
            "Access-Token": access_token,
            "Content-Type": "application/json",
        }

        # Make request with proxy support
        with self._init_proxy_manager():
            if method.upper() == "GET":
                response = requests.get(url, params=params, headers=headers, timeout=30)
            else:
                response = requests.post(url, json=params, headers=headers, timeout=30)

            response.raise_for_status()

        data = response.json()

        # Check for API errors
        if data.get("code") != 0:
            raise ValueError(
                f"TikTok API error: {data.get('message', 'Unknown error')} " f"(code: {data.get('code', 'N/A')})"
            )

        return data

    def get_advertiser_info(self, advertiser_ids: list = None) -> dict:
        """
        Get advertiser account information

        :param advertiser_ids: List of advertiser IDs (optional)
        :return: Advertiser information
        """
        endpoint = "/v1.3/advertiser/info/"
        params = {}

        if advertiser_ids:
            params["advertiser_ids"] = advertiser_ids

        return self._make_request(endpoint, params, method="GET")

    def get_oauth_info(self) -> dict:
        """
        Get OAuth token information including expiration and scope

        :return: OAuth information
        """
        endpoint = "/v1.3/oauth2/advertiser/get/"

        # Get access token dynamically
        access_token = self._get_access_token()

        params = {
            "app_id": self.app_id,
            "secret": self.app_secret,
            "access_token": access_token,
        }

        return self._make_request(endpoint, params, method="GET")

    def test_connection(self):
        """
        Test connection by retrieving OAuth information
        """
        try:
            # First verify we can get an access token
            access_token = self._get_access_token()

            if not access_token:
                raise ValueError("Failed to obtain access token")

            # Get OAuth info to verify access token
            oauth_info = self.get_oauth_info()

            if "data" not in oauth_info:
                raise ValueError("Invalid response from TikTok API")

            # Verify we have advertiser access
            data = oauth_info.get("data", {})
            advertiser_ids = data.get("list", [])

            if not isinstance(advertiser_ids, list):
                raise ValueError("Failed to retrieve advertiser list")

            # If we have advertiser IDs, test getting advertiser info
            if advertiser_ids:
                # Get first advertiser's info
                first_advertiser_id = (
                    advertiser_ids[0] if isinstance(advertiser_ids[0], str) else advertiser_ids[0].get("advertiser_id")
                )
                if first_advertiser_id:
                    advertiser_info = self.get_advertiser_info([first_advertiser_id])
                    if "data" not in advertiser_info:
                        raise ValueError("Failed to retrieve advertiser information")

            return True
        except Exception as e:
            raise ValueError(f"Failed to connect to TikTok Ads: {str(e)}")
