"""Serialization helpers for Reddit objects."""

from datetime import UTC, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from praw.models import Comment, Message, Redditor, Submission, Subreddit


def serialize_submission(submission: "Submission") -> dict:
    """Serialize a PRAW Submission to a dictionary.

    Args:
        submission: PRAW Submission object.

    Returns:
        Dictionary with submission data.
    """
    return {
        "id": submission.id,
        "title": submission.title,
        "selftext": submission.selftext,
        "url": submission.url,
        "permalink": f"https://reddit.com{submission.permalink}",
        "author": str(submission.author) if submission.author else "[deleted]",
        "subreddit": str(submission.subreddit),
        "score": submission.score,
        "upvote_ratio": submission.upvote_ratio,
        "num_comments": submission.num_comments,
        "created_utc": submission.created_utc,
        "created_datetime": datetime.fromtimestamp(
            submission.created_utc, tz=UTC
        ).isoformat(),
        "is_self": submission.is_self,
        "is_video": submission.is_video,
        "over_18": submission.over_18,
        "spoiler": submission.spoiler,
        "stickied": submission.stickied,
        "locked": submission.locked,
        "distinguished": submission.distinguished,
        "link_flair_text": submission.link_flair_text,
        "link_flair_template_id": getattr(submission, "link_flair_template_id", None),
    }


def serialize_comment(comment: "Comment") -> dict:
    """Serialize a PRAW Comment to a dictionary.

    Args:
        comment: PRAW Comment object.

    Returns:
        Dictionary with comment data.
    """
    return {
        "id": comment.id,
        "body": comment.body,
        "body_html": getattr(comment, "body_html", None),
        "author": str(comment.author) if comment.author else "[deleted]",
        "subreddit": str(comment.subreddit),
        "score": comment.score,
        "created_utc": comment.created_utc,
        "created_datetime": datetime.fromtimestamp(
            comment.created_utc, tz=UTC
        ).isoformat(),
        "permalink": f"https://reddit.com{comment.permalink}",
        "parent_id": comment.parent_id,
        "link_id": comment.link_id,
        "is_submitter": comment.is_submitter,
        "stickied": comment.stickied,
        "distinguished": comment.distinguished,
        "edited": comment.edited
        if isinstance(comment.edited, bool)
        else datetime.fromtimestamp(comment.edited, tz=UTC).isoformat()
        if comment.edited
        else False,
    }


def serialize_subreddit(subreddit: "Subreddit") -> dict:
    """Serialize a PRAW Subreddit to a dictionary.

    Args:
        subreddit: PRAW Subreddit object.

    Returns:
        Dictionary with subreddit data.
    """
    return {
        "id": subreddit.id,
        "name": subreddit.display_name,
        "display_name": subreddit.display_name,
        "title": subreddit.title,
        "description": subreddit.public_description,
        "subscribers": subreddit.subscribers,
        "created_utc": subreddit.created_utc,
        "over18": subreddit.over18,
        "url": f"https://reddit.com{subreddit.url}",
        "subreddit_type": subreddit.subreddit_type,
    }


def serialize_redditor(redditor: "Redditor") -> dict:
    """Serialize a PRAW Redditor to a dictionary.

    Args:
        redditor: PRAW Redditor object.

    Returns:
        Dictionary with redditor data.
    """
    return {
        "id": redditor.id,
        "name": redditor.name,
        "link_karma": redditor.link_karma,
        "comment_karma": redditor.comment_karma,
        "created_utc": redditor.created_utc,
        "created_datetime": datetime.fromtimestamp(
            redditor.created_utc, tz=UTC
        ).isoformat(),
        "is_gold": getattr(redditor, "is_gold", False),
        "is_mod": getattr(redditor, "is_mod", False),
        "has_verified_email": getattr(redditor, "has_verified_email", False),
        "icon_img": getattr(redditor, "icon_img", None),
    }


def serialize_message(message: "Message") -> dict:
    """Serialize a PRAW Message to a dictionary.

    Args:
        message: PRAW Message object.

    Returns:
        Dictionary with message data.
    """
    return {
        "id": message.id,
        "subject": message.subject,
        "body": message.body,
        "author": str(message.author) if message.author else "[deleted]",
        "dest": str(message.dest) if hasattr(message, "dest") else None,
        "created_utc": message.created_utc,
        "created_datetime": datetime.fromtimestamp(
            message.created_utc, tz=UTC
        ).isoformat(),
        "new": message.new,
        "was_comment": message.was_comment,
        "parent_id": getattr(message, "parent_id", None),
    }
