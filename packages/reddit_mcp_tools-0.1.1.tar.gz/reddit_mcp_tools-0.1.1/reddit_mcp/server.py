"""Reddit MCP Server - Main server entry point."""

from mcp.server.fastmcp import FastMCP

from reddit_mcp.tools.comments import register_comment_tools
from reddit_mcp.tools.interactions import register_interaction_tools
from reddit_mcp.tools.moderation import register_moderation_tools
from reddit_mcp.tools.reading import register_reading_tools
from reddit_mcp.tools.search import register_search_tools
from reddit_mcp.tools.submissions import register_submission_tools
from reddit_mcp.tools.user import register_user_tools

# Create the MCP server
mcp = FastMCP(
    "reddit-mcp",
    instructions=(
        "MCP server for Reddit API - read posts, comments, "
        "submit content, moderate subreddits, and more via PRAW"
    ),
)

# Register all tool modules
register_reading_tools(mcp)
register_submission_tools(mcp)
register_comment_tools(mcp)
register_interaction_tools(mcp)
register_search_tools(mcp)
register_user_tools(mcp)
register_moderation_tools(mcp)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
