"""Reddit interaction tools - voting, saving, reporting, and awarding."""

from mcp.server.fastmcp import FastMCP

from reddit_mcp.tools.interactions.actions import register_action_tools
from reddit_mcp.tools.interactions.saved import register_saved_tools
from reddit_mcp.tools.interactions.voting import register_voting_tools


def register_interaction_tools(mcp: FastMCP) -> None:
    """Register all interaction tools."""
    register_voting_tools(mcp)
    register_action_tools(mcp)
    register_saved_tools(mcp)
