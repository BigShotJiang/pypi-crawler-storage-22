"""Reddit interaction action tools - save, hide, report, award."""

from mcp.server.fastmcp import FastMCP
from praw.models import Comment, Submission

from reddit_mcp.reddit_client import get_reddit
from reddit_mcp.tools.interactions.helpers import perform_item_action


def save_item(item_id: str) -> dict:
    """Save a submission or comment to the user's account.

    Use this tool when the user wants to bookmark content for later reference.
    Saved items can be retrieved using get_saved_items.
    Supports both posts and comments.

    Args:
        item_id: Full Reddit ID with prefix
            (e.g., 't3_abc123' for post, 't1_xyz789' for comment)

    Returns:
        Success confirmation with item_id and action performed

    Examples:
        - save_item("t3_1a2b3c") - Save a post
        - save_item("t1_4d5e6f") - Save a comment
    """

    def do_save(item: Submission | Comment) -> None:
        item.save()

    return perform_item_action(item_id, "saved", do_save)


def unsave_item(item_id: str) -> dict:
    """Remove a submission or comment from the user's saved items.

    Use this tool when the user wants to remove a previously saved item from their
    saved collection. Supports both posts and comments.

    Args:
        item_id: Full Reddit ID with prefix
            (e.g., 't3_abc123' for post, 't1_xyz789' for comment)

    Returns:
        Success confirmation with item_id and action performed

    Examples:
        - unsave_item("t3_1a2b3c") - Unsave a post
        - unsave_item("t1_4d5e6f") - Unsave a comment
    """

    def do_unsave(item: Submission | Comment) -> None:
        item.unsave()

    return perform_item_action(item_id, "unsaved", do_unsave)


def hide_post(submission_id: str) -> dict:
    """Hide a submission from the user's feed.

    Use this tool when the user wants to hide a post they don't want to
    see anymore. Hidden posts won't appear in their feed but can be
    unhidden later. Only works with posts.

    Args:
        submission_id: Submission ID without prefix (e.g., '1a2b3c')
            or with t3_ prefix

    Returns:
        Success confirmation with submission_id and action performed

    Examples:
        - hide_post("1a2b3c") - Hide a post
        - hide_post("t3_1a2b3c") - Hide a post (with prefix)
    """
    reddit = get_reddit()
    submission_id = submission_id.removeprefix("t3_")

    submission = reddit.submission(id=submission_id)
    submission.hide()
    return {
        "success": True,
        "submission_id": f"t3_{submission_id}",
        "action": "hidden",
    }


def unhide_post(submission_id: str) -> dict:
    """Unhide a previously hidden submission.

    Use this tool when the user wants to restore a hidden post to their feed.
    Only works with posts that were previously hidden.

    Args:
        submission_id: Submission ID without prefix (e.g., '1a2b3c')
            or with t3_ prefix

    Returns:
        Success confirmation with submission_id and action performed

    Examples:
        - unhide_post("1a2b3c") - Unhide a post
        - unhide_post("t3_1a2b3c") - Unhide a post (with prefix)
    """
    reddit = get_reddit()
    submission_id = submission_id.removeprefix("t3_")

    submission = reddit.submission(id=submission_id)
    submission.unhide()
    return {
        "success": True,
        "submission_id": f"t3_{submission_id}",
        "action": "unhidden",
    }


def report_item(item_id: str, reason: str) -> dict:
    """Report a submission or comment to moderators.

    Use this tool when the user wants to report content that violates subreddit
    or Reddit rules. The report will be sent to the subreddit moderators.
    Supports both posts and comments.

    Args:
        item_id: Full Reddit ID with prefix
            (e.g., 't3_abc123' for post, 't1_xyz789' for comment)
        reason: Reason for reporting (e.g., "Spam", "Harassment", "Misinformation")

    Returns:
        Success confirmation with item_id, reason, and action performed

    Examples:
        - report_item("t3_1a2b3c", "Spam") - Report a post as spam
        - report_item("t1_4d5e6f", "Harassment") - Report a comment for harassment
    """

    def do_report(item: Submission | Comment) -> None:
        item.report(reason)

    return perform_item_action(item_id, "reported", do_report, {"reason": reason})


def give_award(item_id: str, gild_type: str = "gild_2") -> dict:
    """Give an award to a submission or comment.

    Use this tool when the user wants to award content they find exceptional.
    Awards cost Reddit Coins. Supports both posts and comments.

    Args:
        item_id: Full Reddit ID with prefix
            (e.g., 't3_abc123' for post, 't1_xyz789' for comment)
        gild_type: Type of award to give (default: "gild_2" for Gold)
                  Options: "gild_1" (Silver), "gild_2" (Gold), "gild_3" (Platinum)

    Returns:
        Success confirmation with item_id, award type, and action performed

    Examples:
        - give_award("t3_1a2b3c") - Give Gold award to a post
        - give_award("t1_4d5e6f", "gild_3") - Give Platinum award
            to a comment

    Note: Requires Reddit Coins in the user's account.
        May fail if insufficient coins.
    """

    def do_award(item: Submission | Comment) -> None:
        item.award(gild_type=gild_type)

    return perform_item_action(item_id, "awarded", do_award, {"award_type": gild_type})


def register_action_tools(mcp: FastMCP) -> None:
    """Register interaction action tools."""
    mcp.tool()(save_item)
    mcp.tool()(unsave_item)
    mcp.tool()(hide_post)
    mcp.tool()(unhide_post)
    mcp.tool()(report_item)
    mcp.tool()(give_award)
