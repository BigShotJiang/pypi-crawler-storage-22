"""User moderation tools for Reddit."""

from mcp.server.fastmcp import FastMCP

from reddit_mcp.reddit_client import get_reddit


def register_user_moderation_tools(mcp: FastMCP) -> None:
    """Register user moderation tools."""

    @mcp.tool()
    def ban_user(
        subreddit: str,
        username: str,
        reason: str = "",
        duration: int | None = None,
        note: str = "",
    ) -> dict:
        """Ban a user from a subreddit.

        Use this to prevent a user from posting/commenting. Can be temporary
        or permanent. The user will receive a ban message.

        Args:
            subreddit: Subreddit name (without r/)
            username: Username to ban (without u/)
            reason: Public ban reason (shown to user in ban message)
            duration: Ban duration in days (None = permanent)
            note: Private mod note (only visible to moderators)

        Returns:
            Success status and ban details
        """
        reddit = get_reddit()
        sub = reddit.subreddit(subreddit)
        sub.banned.add(username, ban_reason=reason, duration=duration, note=note)
        return {
            "success": True,
            "subreddit": subreddit,
            "username": username,
            "action": "banned",
            "duration": duration or "permanent",
            "reason": reason,
        }

    @mcp.tool()
    def unban_user(subreddit: str, username: str) -> dict:
        """Remove a ban from a user.

        Use this to lift a ban and allow the user to participate again.

        Args:
            subreddit: Subreddit name (without r/)
            username: Username to unban (without u/)

        Returns:
            Success status and action details
        """
        reddit = get_reddit()
        sub = reddit.subreddit(subreddit)
        sub.banned.remove(username)
        return {
            "success": True,
            "subreddit": subreddit,
            "username": username,
            "action": "unbanned",
        }

    @mcp.tool()
    def mute_user(subreddit: str, username: str, note: str = "") -> dict:
        """Mute a user from modmail for 72 hours.

        Use this to temporarily prevent a user from sending modmail. Useful
        for users who spam or harass moderators.

        Args:
            subreddit: Subreddit name (without r/)
            username: Username to mute (without u/)
            note: Private mod note (only visible to moderators)

        Returns:
            Success status and action details
        """
        reddit = get_reddit()
        sub = reddit.subreddit(subreddit)
        sub.muted.add(username, note=note)
        return {
            "success": True,
            "subreddit": subreddit,
            "username": username,
            "action": "muted",
            "duration": "72 hours",
        }

    @mcp.tool()
    def unmute_user(subreddit: str, username: str) -> dict:
        """Remove a modmail mute from a user.

        Use this to allow a muted user to send modmail again.

        Args:
            subreddit: Subreddit name (without r/)
            username: Username to unmute (without u/)

        Returns:
            Success status and action details
        """
        reddit = get_reddit()
        sub = reddit.subreddit(subreddit)
        sub.muted.remove(username)
        return {
            "success": True,
            "subreddit": subreddit,
            "username": username,
            "action": "unmuted",
        }

    @mcp.tool()
    def add_contributor(subreddit: str, username: str) -> dict:
        """Add a user as an approved submitter.

        Use this to allow a user to post in restricted subreddits or bypass
        rate limits and spam filters.

        Args:
            subreddit: Subreddit name (without r/)
            username: Username to add (without u/)

        Returns:
            Success status and action details
        """
        reddit = get_reddit()
        sub = reddit.subreddit(subreddit)
        sub.contributor.add(username)
        return {
            "success": True,
            "subreddit": subreddit,
            "username": username,
            "action": "added_as_contributor",
        }

    @mcp.tool()
    def remove_contributor(subreddit: str, username: str) -> dict:
        """Remove a user from approved submitters.

        Use this to revoke approved submitter status.

        Args:
            subreddit: Subreddit name (without r/)
            username: Username to remove (without u/)

        Returns:
            Success status and action details
        """
        reddit = get_reddit()
        sub = reddit.subreddit(subreddit)
        sub.contributor.remove(username)
        return {
            "success": True,
            "subreddit": subreddit,
            "username": username,
            "action": "removed_as_contributor",
        }

    @mcp.tool()
    def get_banned(subreddit: str, limit: int = 100) -> dict:
        """Get list of banned users in a subreddit.

        Use this to view all banned users, their ban reasons, and durations.

        Args:
            subreddit: Subreddit name (without r/)
            limit: Maximum number of banned users to return (default 100)

        Returns:
            List of banned users with ban details
        """
        reddit = get_reddit()
        sub = reddit.subreddit(subreddit)
        banned_users = [
            {
                "username": ban.name,
                "note": ban.note,
                "date": ban.date,
                "days_left": ban.days_left,
            }
            for ban in sub.banned(limit=limit)
        ]

        return {
            "success": True,
            "subreddit": subreddit,
            "count": len(banned_users),
            "banned_users": banned_users,
        }

    @mcp.tool()
    def get_contributors(subreddit: str, limit: int = 100) -> dict:
        """Get list of approved submitters in a subreddit.

        Use this to view all users with approved submitter status.

        Args:
            subreddit: Subreddit name (without r/)
            limit: Maximum number of contributors to return (default 100)

        Returns:
            List of approved submitters
        """
        reddit = get_reddit()
        sub = reddit.subreddit(subreddit)
        contributors = [
            {"username": contributor.name, "id": contributor.id}
            for contributor in sub.contributor(limit=limit)
        ]

        return {
            "success": True,
            "subreddit": subreddit,
            "count": len(contributors),
            "contributors": contributors,
        }
