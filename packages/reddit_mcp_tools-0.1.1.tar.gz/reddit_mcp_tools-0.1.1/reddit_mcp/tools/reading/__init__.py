"""Reading tools for Reddit content."""

from mcp.server.fastmcp import FastMCP

from reddit_mcp.tools.reading.posts import register_post_tools
from reddit_mcp.tools.reading.subreddits import register_subreddit_tools
from reddit_mcp.tools.reading.users import register_user_content_tools


def register_reading_tools(mcp: FastMCP) -> None:
    """Register all reading tools with the MCP server."""
    register_subreddit_tools(mcp)
    register_post_tools(mcp)
    register_user_content_tools(mcp)
