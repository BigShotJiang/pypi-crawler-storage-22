"""Post and comment reading tools for Reddit content."""

from mcp.server.fastmcp import FastMCP

from reddit_mcp.reddit_client import get_reddit
from reddit_mcp.serializers import serialize_comment, serialize_submission


def register_post_tools(mcp: FastMCP) -> None:
    """Register post and comment reading tools with the MCP server."""

    @mcp.tool()
    def get_post_details(post_id: str) -> dict:
        """
        Get full details of a specific post by its ID.

        Use this tool when you have a post ID and need complete information about
        that post, including its content, metadata, and statistics.

        Args:
            post_id: The Reddit post ID (e.g., "abc123", without the "t3_" prefix)

        Returns:
            Dictionary with complete post details including title, content, score,
            author, timestamps, and metadata.
        """
        reddit = get_reddit()
        submission = reddit.submission(id=post_id)
        return serialize_submission(submission)

    @mcp.tool()
    def get_post_comments(
        post_id: str,
        sort: str = "best",
        limit: int | None = None,
    ) -> list[dict]:
        """
        Get comments for a specific post.

        Use this tool to retrieve all comments (or a limited number) from a post.
        Comments are returned in a flat list, not a tree structure.

        Args:
            post_id: The Reddit post ID (e.g., "abc123", without the "t3_" prefix)
            sort: Sort method - "best", "top", "new", "controversial", "old", or "qa"
            limit: Maximum number of comments to return
                (None for all, max 100 if specified)

        Returns:
            List of comment dictionaries with body, author, score, timestamps, etc.
        """
        reddit = get_reddit()
        submission = reddit.submission(id=post_id)
        submission.comment_sort = sort

        if limit is None:
            submission.comments.replace_more(limit=0)
            comments = submission.comments.list()
        else:
            limit = min(limit, 100)
            submission.comments.replace_more(limit=0)
            comments = submission.comments.list()[:limit]

        return [serialize_comment(c) for c in comments]

    @mcp.tool()
    def get_comment_details(comment_id: str) -> dict:
        """
        Get details of a specific comment by its ID.

        Use this tool when you have a comment ID and need complete information
        about that comment.

        Args:
            comment_id: The Reddit comment ID (e.g., "def456", without the "t1_" prefix)

        Returns:
            Dictionary with comment details including body, author, score, timestamps,
            parent/link IDs, and metadata.
        """
        reddit = get_reddit()
        comment = reddit.comment(id=comment_id)
        return serialize_comment(comment)

    @mcp.tool()
    def get_comment_replies(
        comment_id: str,
        limit: int | None = None,
    ) -> list[dict]:
        """
        Get replies to a specific comment.

        Use this tool to retrieve all direct replies to a comment. This returns
        only immediate children, not the entire reply tree.

        Args:
            comment_id: The Reddit comment ID (e.g., "def456", without the "t1_" prefix)
            limit: Maximum number of replies to return
                (None for all, max 100 if specified)

        Returns:
            List of reply comment dictionaries.
        """
        reddit = get_reddit()
        comment = reddit.comment(id=comment_id)
        comment.refresh()

        replies = list(comment.replies)
        if limit is not None:
            limit = min(limit, 100)
            replies = replies[:limit]

        return [serialize_comment(r) for r in replies]
