"""Submission creation tools for Reddit posts."""

from mcp.server.fastmcp import FastMCP

from reddit_mcp.reddit_client import get_reddit
from reddit_mcp.serializers import serialize_submission


def submit_text_post(
    subreddit: str,
    title: str,
    body: str,
    flair_id: str | None = None,
    nsfw: bool = False,
    spoiler: bool = False,
    send_replies: bool = True,
) -> dict:
    """
    Submit a text/self post to a subreddit.

    Creates a new text-based post with optional markdown formatting. Use this
    for discussion posts, questions, stories, or any content that doesn't
    require external links or media.

    Args:
        subreddit: Target subreddit name (without r/ prefix, e.g., "AskReddit")
        title: Post title (max 300 characters)
        body: Post body/content (markdown formatting supported)
        flair_id: Optional flair template ID for the post
            (get from subreddit settings)
        nsfw: Mark post as NSFW (Not Safe For Work)
        spoiler: Mark post as spoiler (hides content until clicked)
        send_replies: Receive inbox notifications for replies (default: True)

    Returns:
        Dictionary with created post details including:
        - id: Post ID
        - url: Full URL to the post
        - permalink: Relative URL path
        - title: Post title
        - selftext: Post body content
        - score: Initial score (usually 1)
        - created_utc: Creation timestamp

    Example:
        submit_text_post(
            subreddit="test",
            title="My First Post",
            body="This is the content of my post with **markdown**.",
            nsfw=False
        )
    """
    reddit = get_reddit()
    sub = reddit.subreddit(subreddit)
    submission = sub.submit(
        title=title,
        selftext=body,
        flair_id=flair_id,
        nsfw=nsfw,
        spoiler=spoiler,
        send_replies=send_replies,
    )
    return serialize_submission(submission)


def submit_link_post(
    subreddit: str,
    title: str,
    url: str,
    resubmit: bool = True,
    flair_id: str | None = None,
    nsfw: bool = False,
    spoiler: bool = False,
    send_replies: bool = True,
) -> dict:
    """
    Submit a link post to a subreddit.

    Creates a new post linking to an external URL. Use this for sharing
    articles, websites, or any external content. Reddit will fetch a
    preview/thumbnail automatically.

    Args:
        subreddit: Target subreddit name (without r/ prefix)
        title: Post title (max 300 characters)
        url: Full URL to link to (must include http:// or https://)
        resubmit: Allow resubmitting URLs that were previously posted
            (default: True)
        flair_id: Optional flair template ID
        nsfw: Mark post as NSFW
        spoiler: Mark post as spoiler
        send_replies: Receive inbox notifications for replies

    Returns:
        Dictionary with created post details including URL and metadata

    Example:
        submit_link_post(
            subreddit="technology",
            title="Interesting Article About AI",
            url="https://example.com/article",
            resubmit=False
        )
    """
    reddit = get_reddit()
    sub = reddit.subreddit(subreddit)
    submission = sub.submit(
        title=title,
        url=url,
        resubmit=resubmit,
        flair_id=flair_id,
        nsfw=nsfw,
        spoiler=spoiler,
        send_replies=send_replies,
    )
    return serialize_submission(submission)


def register_create_tools(mcp: FastMCP) -> None:
    """Register submission creation tools with the MCP server."""
    mcp.tool()(submit_text_post)
    mcp.tool()(submit_link_post)
