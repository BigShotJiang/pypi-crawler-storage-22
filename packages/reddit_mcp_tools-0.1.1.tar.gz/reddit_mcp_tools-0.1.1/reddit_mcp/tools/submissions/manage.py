"""Post management tools for Reddit submissions."""

from typing import Any

from mcp.server.fastmcp import FastMCP

from reddit_mcp.reddit_client import get_reddit
from reddit_mcp.serializers import serialize_submission


def register_manage_tools(mcp: FastMCP) -> None:
    """Register post management tools with the MCP server."""

    @mcp.tool()
    def edit_post(submission_id: str, body: str) -> dict:
        """
        Edit the body content of your own text post.

        Updates the selftext/body of a text post you created. Only works for
        text posts (not link, image, video, or poll posts). The edit will be
        marked with an asterisk (*) on Reddit.

        Args:
            submission_id: The ID of the submission to edit (without "t3_" prefix)
            body: New body content (markdown supported, empty string to clear)

        Returns:
            Dictionary with updated post details including the new body content

        Example:
            edit_post(
                submission_id="abc123",
                body="Updated content with **new information**."
            )

        Note:
            You can only edit posts you created. Link posts cannot have their
            URL changed. Title cannot be edited after posting. Edit history is
            not publicly visible but moderators can see it.
        """
        reddit = get_reddit()
        submission = reddit.submission(id=submission_id)
        submission.edit(body=body)
        return serialize_submission(submission)

    @mcp.tool()
    def delete_post(submission_id: str) -> dict[str, Any]:
        """
        Delete your own post.

        Permanently removes a post you created. The post will show as [deleted]
        but comments may remain visible. This action cannot be undone.

        Args:
            submission_id: The ID of the submission to delete (without "t3_" prefix)

        Returns:
            Dictionary confirming deletion with:
            - success: True if deleted successfully
            - submission_id: ID of the deleted post
            - message: Confirmation message

        Example:
            delete_post(submission_id="abc123")

        Note:
            You can only delete posts you created. Deleted posts cannot be
            recovered. The post URL will still exist but show [deleted] content.
            Comments on the post may remain visible unless also deleted.
        """
        reddit = get_reddit()
        submission = reddit.submission(id=submission_id)
        submission.delete()
        return {
            "success": True,
            "submission_id": submission_id,
            "message": f"Post {submission_id} has been deleted successfully",
        }

    @mcp.tool()
    def crosspost(
        submission_id: str,
        subreddit: str,
        title: str | None = None,
        flair_id: str | None = None,
        nsfw: bool = False,
        spoiler: bool = False,
        send_replies: bool = True,
    ) -> dict:
        """
        Crosspost an existing post to another subreddit.

        Creates a new post in a different subreddit that links back to the
        original post. Crossposts show the original post's content and give
        credit to the original poster.

        Args:
            submission_id: ID of the post to crosspost (without "t3_" prefix)
            subreddit: Target subreddit name to crosspost to (without r/ prefix)
            title: Optional custom title (defaults to original post's title)
            flair_id: Optional flair template ID for the crosspost
            nsfw: Mark crosspost as NSFW
            spoiler: Mark crosspost as spoiler
            send_replies: Receive inbox notifications for replies on the crosspost

        Returns:
            Dictionary with created crosspost details including link to original

        Example:
            crosspost(
                submission_id="abc123",
                subreddit="another_sub",
                title="Thought you all might enjoy this",
                nsfw=False
            )

        Note:
            Some subreddits disable crossposting. The original post must still
            exist and be accessible. Crossposting gives credit to the original
            poster automatically.
        """
        reddit = get_reddit()
        submission = reddit.submission(id=submission_id)
        target_sub = reddit.subreddit(subreddit)

        crosspost_submission = submission.crosspost(
            subreddit=target_sub,
            title=title,
            flair_id=flair_id,
            nsfw=nsfw,
            spoiler=spoiler,
            send_replies=send_replies,
        )
        return serialize_submission(crosspost_submission)
