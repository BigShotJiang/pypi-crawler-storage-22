"""Reddit user social interaction tools."""

from mcp.server.fastmcp import FastMCP

from reddit_mcp.reddit_client import get_reddit


def register_social_tools(mcp: FastMCP) -> None:
    """Register user social tools."""

    @mcp.tool()
    def get_friends() -> list[dict]:
        """Get the authenticated user's friends list.

        Retrieves the list of users marked as friends. Friends' posts may be
        highlighted in some Reddit interfaces.

        Returns:
            list[dict]: List of friend usernames and metadata
        """
        reddit = get_reddit()
        friends = reddit.user.friends()
        return [
            {
                "username": friend.name,
                "id": friend.id,
                "date_added": friend.date if hasattr(friend, "date") else None,
            }
            for friend in friends
        ]

    @mcp.tool()
    def add_friend(username: str, note: str = "") -> dict:
        """Add a user as a friend.

        Marks a user as a friend. This may highlight their posts in your feed
        depending on Reddit settings.

        Args:
            username: Reddit username to add as friend (without u/ prefix)
            note: Optional note about this friend

        Returns:
            dict: Confirmation with username and note
        """
        reddit = get_reddit()
        user = reddit.redditor(username)
        user.friend(note=note)
        return {"success": True, "username": username, "note": note}

    @mcp.tool()
    def remove_friend(username: str) -> dict:
        """Remove a user from friends list."""
        reddit = get_reddit()
        user = reddit.redditor(username)
        user.unfriend()
        return {"success": True, "username": username}

    @mcp.tool()
    def get_blocked() -> list[dict]:
        """Get the authenticated user's blocked users list."""
        reddit = get_reddit()
        blocked = reddit.user.blocked()
        return [
            {
                "username": user.name,
                "id": user.id,
                "date_blocked": user.date if hasattr(user, "date") else None,
            }
            for user in blocked
        ]

    @mcp.tool()
    def block_user(username: str) -> dict:
        """Block a user.

        Prevents a user from sending you messages or interacting with your content.
        You will not see their posts or comments in most contexts.

        Args:
            username: Reddit username to block (without u/ prefix)

        Returns:
            dict: Confirmation with username
        """
        reddit = get_reddit()
        user = reddit.redditor(username)
        user.block()
        return {"success": True, "username": username, "action": "blocked"}

    @mcp.tool()
    def unblock_user(username: str) -> dict:
        """Unblock a previously blocked user.

        Removes block status from a user, allowing them to interact with your
        content and send messages again.

        Args:
            username: Reddit username to unblock (without u/ prefix)

        Returns:
            dict: Confirmation with username
        """
        reddit = get_reddit()
        user = reddit.redditor(username)
        user.unblock()
        return {"success": True, "username": username, "action": "unblocked"}
