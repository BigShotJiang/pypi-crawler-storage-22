# Reddit MCP Server - Test Results

**Date:** 2026-01-28  
**Total Tools:** 85

---

## Reading Tools (13)

| # | Tool | Status | Notes |
|---|------|--------|-------|
| 1 | get_subreddit_posts | ✅ PASS | Returns list of posts |
| 2 | get_front_page | ✅ PASS | Returns subscribed feed |
| 3 | get_post_details | ✅ PASS | Returns single post |
| 4 | get_post_comments | ✅ PASS | Returns comments on post |
| 5 | get_comment_details | ✅ PASS | Returns single comment |
| 6 | get_comment_replies | ✅ PASS | Returns replies to comment |
| 7 | get_subreddit_info | ✅ PASS | Returns subreddit metadata |
| 8 | get_subreddit_rules | ✅ PASS | Returns subreddit rules |
| 9 | get_subreddit_wiki_page | ✅ PASS | Returns wiki content |
| 10 | get_user_info | ✅ PASS | Returns user profile |
| 11 | get_user_posts | ✅ PASS | Returns user's post history |
| 12 | get_user_comments | ✅ PASS | Returns user's comment history |
| 13 | get_multireddit | ⚠️ N/A | 404 - No multireddit exists (expected) |

---

## Submission Tools (9)

| # | Tool | Status | Notes |
|---|------|--------|-------|
| 14 | submit_text_post | ✅ PASS | Tested on r/test |
| 15 | submit_link_post | ✅ PASS | Tested on r/test |
| 16 | submit_image_post | ✅ PASS | Tested on r/test |
| 17 | submit_video_post | ✅ PASS | Tested on r/test (websocket warning, post created) |
| 18 | submit_gallery_post | ✅ PASS | Tested on r/test |
| 19 | submit_poll_post | ✅ PASS | Tested on r/test |
| 20 | edit_post | ✅ PASS | Tested on r/test |
| 21 | delete_post | ✅ PASS | Tested on r/test |
| 22 | crosspost | ✅ PASS | Tested on r/test |

---

## Comment Tools (5)

| # | Tool | Status | Notes |
|---|------|--------|-------|
| 23 | reply_to_post | ✅ PASS | Tested on r/test |
| 24 | reply_to_comment | ✅ PASS | Tested on r/test |
| 25 | edit_comment | ✅ PASS | Tested on r/test |
| 26 | delete_comment | ✅ PASS | Tested on r/test |
| 27 | get_more_comments | ✅ PASS | Expands collapsed threads |

---

## Interaction Tools (10)

| # | Tool | Status | Notes |
|---|------|--------|-------|
| 28 | upvote | ✅ PASS | Tested vote cycle |
| 29 | downvote | ✅ PASS | Tested vote cycle |
| 30 | clear_vote | ✅ PASS | Tested vote cycle |
| 31 | save_item | ✅ PASS | Tested save/unsave cycle |
| 32 | unsave_item | ✅ PASS | Tested save/unsave cycle |
| 33 | hide_post | ✅ PASS | Tested hide/unhide cycle |
| 34 | unhide_post | ✅ PASS | Tested hide/unhide cycle |
| 35 | report_item | 🚫 SKIP | Risk: False reports can flag account |
| 36 | give_award | 🚫 SKIP | Costs money, irreversible |
| 37 | get_saved_items | ✅ PASS | Returns saved content |

---

## Search Tools (4)

| # | Tool | Status | Notes |
|---|------|--------|-------|
| 38 | search_all | ✅ PASS | Returns posts across Reddit |
| 39 | search_subreddit | ✅ PASS | Returns posts within subreddit |
| 40 | search_comments | ✅ PASS | Workaround implementation |
| 41 | search_users | ✅ PASS | Returns matching users |

---

## User Tools (16)

| # | Tool | Status | Notes |
|---|------|--------|-------|
| 42 | get_me | ✅ PASS | Returns authenticated user info |
| 43 | get_user | ✅ PASS | Returns any user's profile |
| 44 | get_user_submissions | ✅ PASS | Returns user's post history |
| 45 | get_karma_breakdown | ✅ PASS | Returns karma by subreddit (FIXED) |
| 46 | get_trophies | ✅ PASS | Returns user trophies |
| 47 | get_friends | ✅ PASS | Returns friends list |
| 48 | add_friend | ✅ PASS | Tested with AutoModerator |
| 49 | remove_friend | ✅ PASS | Tested with AutoModerator |
| 50 | get_blocked | ✅ PASS | Returns blocked users |
| 51 | block_user | 🚫 SKIP | Affects real users |
| 52 | unblock_user | 🚫 SKIP | Requires blocked user |
| 53 | get_preferences | ✅ PASS | Returns account settings |
| 54 | update_preferences | ✅ PASS | Tested toggle + revert |
| 55 | get_multireddits | ✅ PASS | Returns multireddits list |
| 56 | create_multireddit | ✅ PASS | Tested create + delete |
| 57 | is_username_available | ✅ PASS | Validates format (FIXED) |

---

## Moderation Tools (28) - Requires Mod Permissions

| # | Tool | Status | Notes |
|---|------|--------|-------|
| 58 | approve_item | ⚠️ N/A | 403 - Requires mod |
| 59 | remove_item | ⚠️ N/A | 403 - Requires mod |
| 60 | spam_item | ⚠️ N/A | 403 - Requires mod |
| 61 | distinguish_comment | ⚠️ N/A | 403 - Requires mod |
| 62 | undistinguish_comment | ⚠️ N/A | 403 - Requires mod |
| 63 | sticky_post | ⚠️ N/A | 403 - Requires mod |
| 64 | unsticky_post | ⚠️ N/A | 403 - Requires mod |
| 65 | set_suggested_sort | ⚠️ N/A | 403 - Requires mod |
| 66 | ban_user | ⚠️ N/A | 403 - Requires mod |
| 67 | unban_user | ⚠️ N/A | 403 - Requires mod |
| 68 | mute_user | ⚠️ N/A | 403 - Requires mod |
| 69 | unmute_user | ⚠️ N/A | 403 - Requires mod |
| 70 | add_contributor | ⚠️ N/A | 403 - Requires mod |
| 71 | remove_contributor | ⚠️ N/A | 403 - Requires mod |
| 72 | get_banned | ⚠️ N/A | 403 - Requires mod |
| 73 | get_contributors | ⚠️ N/A | 403 - Requires mod |
| 74 | set_user_flair | ⚠️ N/A | 403 - Requires mod |
| 75 | delete_user_flair | ⚠️ N/A | 403 - Requires mod |
| 76 | set_post_flair | ⚠️ N/A | 403 - Requires mod |
| 77 | get_flair_templates | ✅ PASS | Returns flair templates |
| 78 | create_flair_template | ⚠️ N/A | 403 - Requires mod |
| 79 | delete_flair_template | ⚠️ N/A | 403 - Requires mod |
| 80 | get_modqueue | ⚠️ N/A | 403 - Requires mod |
| 81 | get_reports | ⚠️ N/A | 403 - Requires mod |
| 82 | get_spam | ⚠️ N/A | 403 - Requires mod |
| 83 | get_edited | ⚠️ N/A | 403 - Requires mod |
| 84 | get_unmoderated | ⚠️ N/A | 403 - Requires mod |
| 85 | get_mod_log | ⚠️ N/A | 403 - Requires mod |

---

## Summary Statistics

| Category | Count |
|----------|-------|
| ✅ PASS | 53 |
| 🚫 SKIP (Risky) | 4 |
| ⚠️ N/A (Requires Mod) | 27 |
| ⚠️ N/A (Expected) | 1 |
| **Total** | **85** |

---

## Test Results by Category

| Category | Passed | Total | Rate |
|----------|--------|-------|------|
| Reading | 12 | 13 | 92% |
| Submission | 9 | 9 | 100% |
| Comment | 5 | 5 | 100% |
| Interaction | 8 | 10 | 80% |
| Search | 4 | 4 | 100% |
| User | 14 | 16 | 88% |
| Moderation | 1 | 28 | 4% (mod required) |

---

## Skipped Tools (Risk)

| Tool | Reason |
|------|--------|
| report_item | False reports can flag/ban account |
| give_award | Costs Reddit coins, irreversible |
| block_user | Affects real users |
| unblock_user | Requires blocked user first |

---

## Fixed Issues (Verified)

### 1. get_karma_breakdown
**Error:** `'Subreddit' object has no attribute 'subreddit'`  
**Fix:** Changed to `for subreddit, karma_data in karma_dict.items()`  
**Status:** ✅ VERIFIED

### 2. is_username_available
**Error:** `BAD_USERNAME: 'invalid user name'`  
**Fix:** Added regex validation + BadRequest handling  
**Status:** ✅ VERIFIED

---

## Test Environment
- MCP Server: reddit-mcp v1.0.0
- Python: 3.12+
- PRAW: Latest
- Date: 2026-01-28
