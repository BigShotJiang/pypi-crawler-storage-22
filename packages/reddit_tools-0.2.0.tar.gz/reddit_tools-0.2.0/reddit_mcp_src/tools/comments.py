"""Comment tools for Reddit interactions."""

from mcp.server.fastmcp import FastMCP

from reddit_mcp.reddit_client import get_reddit
from reddit_mcp.serializers import serialize_comment, serialize_submission


def register_comment_tools(mcp: FastMCP) -> None:
    """Register all comment tools with the MCP server."""

    @mcp.tool()
    def reply_to_post(post_id: str, body: str) -> dict:
        """
        Reply to a post with a new comment.

        Args:
            post_id: The post ID to reply to (e.g., 'abc123')
            body: Comment text (markdown supported)

        Returns:
            Dictionary with created comment details including ID and URL
        """
        reddit = get_reddit()
        submission = reddit.submission(id=post_id)
        comment = submission.reply(body)
        return serialize_comment(comment)

    @mcp.tool()
    def reply_to_comment(comment_id: str, body: str) -> dict:
        """
        Reply to an existing comment.

        Args:
            comment_id: The comment ID to reply to (e.g., 'xyz789')
            body: Reply text (markdown supported)

        Returns:
            Dictionary with created reply details
        """
        reddit = get_reddit()
        comment = reddit.comment(id=comment_id)
        reply = comment.reply(body)
        return serialize_comment(reply)

    @mcp.tool()
    def edit_comment(comment_id: str, body: str) -> dict:
        """
        Edit an existing comment you authored.

        Args:
            comment_id: The comment ID to edit
            body: New comment text (markdown supported)

        Returns:
            Dictionary with updated comment details
        """
        reddit = get_reddit()
        comment = reddit.comment(id=comment_id)
        comment.edit(body)
        return serialize_comment(comment)

    @mcp.tool()
    def delete_comment(comment_id: str) -> dict:
        """
        Delete a comment you authored.

        Args:
            comment_id: The comment ID to delete

        Returns:
            Confirmation of deletion
        """
        reddit = get_reddit()
        comment = reddit.comment(id=comment_id)
        comment.delete()
        return {"success": True, "comment_id": comment_id, "action": "deleted"}

    @mcp.tool()
    def get_more_comments(post_id: str, limit: int = 32) -> dict:
        """
        Expand collapsed comment threads on a post.

        This replaces "MoreComments" objects with actual comment data.
        Use this when you need to see all comments on a post with many replies.

        Args:
            post_id: The post ID to expand comments for
            limit: Maximum number of MoreComments to expand (0 for all)

        Returns:
            Dictionary with expanded submission and all comments
        """
        reddit = get_reddit()
        submission = reddit.submission(id=post_id)
        submission.comments.replace_more(limit=limit)
        comments = submission.comments.list()
        return {
            "post": serialize_submission(submission),
            "comments": [serialize_comment(c) for c in comments],
            "total_comments": len(comments)
        }
