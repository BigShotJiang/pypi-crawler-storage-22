"""Reddit voting tools - upvote, downvote, and clear vote."""

from mcp.server.fastmcp import FastMCP
from praw.models import Comment, Submission

from reddit_mcp.tools.interactions.helpers import perform_item_action


def upvote(item_id: str) -> dict:
    """Upvote a submission or comment.

    Use this tool when the user wants to upvote content they like or agree with.
    Supports both posts (submissions) and comments.

    Args:
        item_id: Full Reddit ID with prefix
            (e.g., 't3_abc123' for post, 't1_xyz789' for comment)

    Returns:
        Success confirmation with item_id and action performed

    Examples:
        - upvote("t3_1a2b3c") - Upvote a post
        - upvote("t1_4d5e6f") - Upvote a comment
    """

    def do_upvote(item: Submission | Comment) -> None:
        item.upvote()

    return perform_item_action(item_id, "upvoted", do_upvote)


def downvote(item_id: str) -> dict:
    """Downvote a submission or comment.

    Use this tool when the user wants to downvote content that doesn't
    contribute to the discussion or violates community guidelines.
    Supports both posts and comments.

    Args:
        item_id: Full Reddit ID with prefix
            (e.g., 't3_abc123' for post, 't1_xyz789' for comment)

    Returns:
        Success confirmation with item_id and action performed

    Examples:
        - downvote("t3_1a2b3c") - Downvote a post
        - downvote("t1_4d5e6f") - Downvote a comment
    """

    def do_downvote(item: Submission | Comment) -> None:
        item.downvote()

    return perform_item_action(item_id, "downvoted", do_downvote)


def clear_vote(item_id: str) -> dict:
    """Remove vote from a submission or comment.

    Use this tool when the user wants to undo their upvote or downvote and return
    the item to a neutral state. Supports both posts and comments.

    Args:
        item_id: Full Reddit ID with prefix
            (e.g., 't3_abc123' for post, 't1_xyz789' for comment)

    Returns:
        Success confirmation with item_id and action performed

    Examples:
        - clear_vote("t3_1a2b3c") - Remove vote from a post
        - clear_vote("t1_4d5e6f") - Remove vote from a comment
    """

    def do_clear_vote(item: Submission | Comment) -> None:
        item.clear_vote()

    return perform_item_action(item_id, "vote_cleared", do_clear_vote)


def register_voting_tools(mcp: FastMCP) -> None:
    """Register voting tools."""
    mcp.tool()(upvote)
    mcp.tool()(downvote)
    mcp.tool()(clear_vote)
