"""Reddit moderation tools for subreddit moderators."""

from mcp.server.fastmcp import FastMCP

from reddit_mcp.tools.moderation.content import register_content_moderation_tools
from reddit_mcp.tools.moderation.flair import register_flair_moderation_tools
from reddit_mcp.tools.moderation.queue import register_queue_moderation_tools
from reddit_mcp.tools.moderation.users import register_user_moderation_tools


def register_moderation_tools(mcp: FastMCP) -> None:
    """Register all moderation tools."""
    register_content_moderation_tools(mcp)
    register_user_moderation_tools(mcp)
    register_flair_moderation_tools(mcp)
    register_queue_moderation_tools(mcp)
