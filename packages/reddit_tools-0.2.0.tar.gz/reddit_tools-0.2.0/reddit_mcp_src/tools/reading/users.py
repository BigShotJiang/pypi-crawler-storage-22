"""User content reading tools for Reddit."""

from mcp.server.fastmcp import FastMCP

from reddit_mcp.reddit_client import get_reddit
from reddit_mcp.serializers import (
    serialize_comment,
    serialize_redditor,
    serialize_submission,
)


def get_user_info(username: str) -> dict:
    """
    Get profile information about a Reddit user.

    Use this tool to retrieve public profile information about any Reddit user,
    including karma, account age, and other metadata.

    Args:
        username: Reddit username (without u/ prefix, e.g., "spez")

    Returns:
        Dictionary with user information including name, karma scores, account
        creation date, and status flags.
    """
    reddit = get_reddit()
    redditor = reddit.redditor(username)
    return serialize_redditor(redditor)


def get_user_posts(
    username: str,
    sort: str = "new",
    time_filter: str = "all",
    limit: int = 25,
) -> list[dict]:
    """
    Get posts submitted by a specific user.

    Use this tool to browse a user's post history. Useful for understanding
    their interests, activity patterns, or finding specific content they've shared.

    Args:
        username: Reddit username (without u/ prefix, e.g., "spez")
        sort: Sort method - "hot", "new", "top", or "controversial"
        time_filter: Time filter for top/controversial - "hour", "day",
            "week", "month", "year", or "all"
        limit: Number of posts to return (max 100, default 25)

    Returns:
        List of post dictionaries submitted by the user.
    """
    reddit = get_reddit()
    redditor = reddit.redditor(username)
    limit = min(limit, 100)

    sort_methods = {
        "hot": lambda: redditor.submissions.hot(limit=limit),
        "new": lambda: redditor.submissions.new(limit=limit),
        "top": lambda: redditor.submissions.top(time_filter=time_filter, limit=limit),
        "controversial": lambda: redditor.submissions.controversial(
            time_filter=time_filter, limit=limit
        ),
    }
    posts = sort_methods.get(sort, sort_methods["new"])()

    return [serialize_submission(p) for p in posts]


def get_user_comments(
    username: str,
    sort: str = "new",
    time_filter: str = "all",
    limit: int = 25,
) -> list[dict]:
    """
    Get comments posted by a specific user.

    Use this tool to browse a user's comment history. Useful for understanding
    their perspectives, finding specific discussions, or analyzing activity.

    Args:
        username: Reddit username (without u/ prefix, e.g., "spez")
        sort: Sort method - "hot", "new", "top", or "controversial"
        time_filter: Time filter for top/controversial - "hour", "day",
            "week", "month", "year", or "all"
        limit: Number of comments to return (max 100, default 25)

    Returns:
        List of comment dictionaries posted by the user.
    """
    reddit = get_reddit()
    redditor = reddit.redditor(username)
    limit = min(limit, 100)

    sort_methods = {
        "hot": lambda: redditor.comments.hot(limit=limit),
        "new": lambda: redditor.comments.new(limit=limit),
        "top": lambda: redditor.comments.top(time_filter=time_filter, limit=limit),
        "controversial": lambda: redditor.comments.controversial(
            time_filter=time_filter, limit=limit
        ),
    }
    comments = sort_methods.get(sort, sort_methods["new"])()

    return [serialize_comment(c) for c in comments]


def get_multireddit(
    username: str,
    multireddit_name: str,
    sort: str = "hot",
    time_filter: str = "all",
    limit: int = 25,
) -> list[dict]:
    """
    Get posts from a multireddit (custom feed of multiple subreddits).

    Use this tool to browse posts from a user's multireddit, which is a curated
    collection of multiple subreddits combined into one feed.

    Args:
        username: Reddit username who owns the multireddit (without u/ prefix)
        multireddit_name: Name of the multireddit
        sort: Sort method - "hot", "new", "top", "rising", or "controversial"
        time_filter: Time filter for top/controversial - "hour", "day",
            "week", "month", "year", or "all"
        limit: Number of posts to return (max 100, default 25)

    Returns:
        List of post dictionaries from the multireddit's combined subreddits.
    """
    reddit = get_reddit()
    multireddit = reddit.multireddit(redditor=username, name=multireddit_name)
    limit = min(limit, 100)

    sort_methods = {
        "hot": lambda: multireddit.hot(limit=limit),
        "new": lambda: multireddit.new(limit=limit),
        "top": lambda: multireddit.top(time_filter=time_filter, limit=limit),
        "rising": lambda: multireddit.rising(limit=limit),
        "controversial": lambda: multireddit.controversial(
            time_filter=time_filter, limit=limit
        ),
    }
    posts = sort_methods.get(sort, sort_methods["hot"])()

    return [serialize_submission(p) for p in posts]


def register_user_content_tools(mcp: FastMCP) -> None:
    """Register user content reading tools with the MCP server."""
    mcp.tool()(get_user_info)
    mcp.tool()(get_user_posts)
    mcp.tool()(get_user_comments)
    mcp.tool()(get_multireddit)
