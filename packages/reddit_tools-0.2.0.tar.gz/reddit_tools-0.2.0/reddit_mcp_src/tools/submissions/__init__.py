"""Submission tools for creating and managing Reddit posts."""

from mcp.server.fastmcp import FastMCP

from reddit_mcp.tools.submissions.create import register_create_tools
from reddit_mcp.tools.submissions.manage import register_manage_tools
from reddit_mcp.tools.submissions.media import register_media_tools


def register_submission_tools(mcp: FastMCP) -> None:
    """Register all submission tools with the MCP server."""
    register_create_tools(mcp)
    register_manage_tools(mcp)
    register_media_tools(mcp)
