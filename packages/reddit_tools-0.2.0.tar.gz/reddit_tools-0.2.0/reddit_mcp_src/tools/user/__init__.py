"""Reddit user and account tools."""

from mcp.server.fastmcp import FastMCP

from reddit_mcp.tools.user.profile import register_profile_tools
from reddit_mcp.tools.user.settings import register_settings_tools
from reddit_mcp.tools.user.social import register_social_tools


def register_user_tools(mcp: FastMCP) -> None:
    """Register all user tools."""
    register_profile_tools(mcp)
    register_social_tools(mcp)
    register_settings_tools(mcp)
