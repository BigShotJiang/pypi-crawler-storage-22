"""Reddit user profile tools."""

from mcp.server.fastmcp import FastMCP

from reddit_mcp.reddit_client import get_reddit
from reddit_mcp.serializers import serialize_redditor, serialize_submission


def register_profile_tools(mcp: FastMCP) -> None:
    """Register user profile tools."""

    @mcp.tool()
    def get_me() -> dict:
        """Get the authenticated user's profile information.

        Returns complete profile data including karma, account age, premium status,
        and other account details for the currently authenticated user.

        Returns:
            dict: Serialized user profile with all available fields
        """
        reddit = get_reddit()
        me = reddit.user.me()
        return serialize_redditor(me)

    @mcp.tool()
    def get_user(username: str) -> dict:
        """Get a Reddit user's public profile information.

        Retrieves public profile data for any Reddit user including karma scores,
        account creation date, trophy case, and other publicly visible information.

        Args:
            username: Reddit username (without u/ prefix)

        Returns:
            dict: Serialized user profile with publicly available fields
        """
        reddit = get_reddit()
        user = reddit.redditor(username)
        # Force fetch to validate user exists
        _ = user.id
        return serialize_redditor(user)

    @mcp.tool()
    def get_user_submissions(
        username: str, limit: int = 25, time_filter: str = "all"
    ) -> list[dict]:
        """Get a user's submission (post) history.

        Retrieves posts submitted by a user, sorted by newest first. Useful for
        analyzing user activity, finding their popular posts, or reviewing content.

        Args:
            username: Reddit username (without u/ prefix)
            limit: Maximum number of submissions to retrieve (1-100, default 25)
            time_filter: Time period filter - "all", "day", "week", "month", "year"

        Returns:
            list[dict]: List of serialized submissions
        """
        reddit = get_reddit()
        user = reddit.redditor(username)
        submissions = user.submissions.top(time_filter=time_filter, limit=limit)
        return [serialize_submission(sub) for sub in submissions]

    @mcp.tool()
    def get_karma_breakdown() -> list[dict]:
        """Get karma breakdown by subreddit for the authenticated user.

        Shows how much link karma and comment karma the authenticated user has
        earned in each subreddit they've participated in. Useful for understanding
        where a user is most active and successful.

        Returns:
            list[dict]: List of karma entries with subreddit, link_karma,
                and comment_karma
        """
        reddit = get_reddit()
        karma_dict = reddit.user.karma()
        return [
            {
                "subreddit": str(subreddit),
                "link_karma": karma_data.get("link_karma", 0),
                "comment_karma": karma_data.get("comment_karma", 0),
            }
            for subreddit, karma_data in karma_dict.items()
        ]

    @mcp.tool()
    def get_trophies(username: str) -> list[dict]:
        """Get a user's trophies and awards.

        Retrieves special achievements, awards, and trophies earned by a user
        such as Verified Email, Reddit Premium, or participation awards.

        Args:
            username: Reddit username (without u/ prefix)

        Returns:
            list[dict]: List of trophies with name, description, and icon URL
        """
        reddit = get_reddit()
        user = reddit.redditor(username)
        trophies = user.trophies()
        return [
            {
                "name": trophy.name,
                "description": trophy.description
                if hasattr(trophy, "description")
                else None,
                "icon_70": trophy.icon_70 if hasattr(trophy, "icon_70") else None,
                "icon_40": trophy.icon_40 if hasattr(trophy, "icon_40") else None,
            }
            for trophy in trophies
        ]
