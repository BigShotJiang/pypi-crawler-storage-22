# RedNote-MCP-Plus

<p align="center"><img src= "docs/img/logo.png" width="600"/></p>

[![English](https://img.shields.io/badge/English-Click-yellow)](docs/README.en.md)
[![简体中文](https://img.shields.io/badge/简体中文-点击查看-orange)](README.md)
[![License](https://img.shields.io/badge/license-MIT-blue)](LICENSE)
[![PyPI version](https://badge.fury.io/py/rednote_mcp_plus.svg)](https://badge.fury.io/py/rednote_mcp_plus)

⚙️ 配备更全面工具集的小红书 MCP 服务器。

## 主要特性
- 简单易上手：只需要几行简单的命令即可体验工具能力，无需额外配置
- 自动化互动工具：包含发布、点赞、收藏、评论、关注等工具，助力自动化账号运营
- 自动化爬虫工具：包含搜索、笔记内容爬取、用户数据爬取等工具，助力内容搜索

## 工具清单
- ✅登录：使用其他工具前必须使用该工具登录小红书，保存登录态
- ❤️点赞：点赞任意笔记
- 📥收藏：收藏任意笔记
- 💬评论：评论任意笔记
- 👤关注：关注任意用户
- 🖼️发布笔记：发布任意图文笔记
- 🔍搜索笔记：关键词搜索笔记
- 📖笔记内容爬取：以MarkDown形式保存任意笔记
- 📊用户数据爬取：获取用户昵称、简介、标签、互动信息

## 快速开始

如果你想快速体验工具能力，按照以下步骤即可：

### 配置环境
1. 安装uv：
```
brew install uv
```

2. 安装playwright：
```
pip install playwright
playwright install
```

3. 安装node：
```
brew install node
```

4. 安装小红书MCP
```
uv tool install rednote_mcp_plus
```

### 快速试用

**一行命令启动MCP服务调试!**
```
npx @modelcontextprotocol/inspector uvx rednote_mcp_plus
```

如果一切顺利的话，现在你就可以看到如图所示列出的所有工具了，接下来你可以随意试用感兴趣的MCP工具了！

![MCP工具列表](docs/img/mcp_tools.png "MCP工具列表")

> ⚠️ **注意：** 请务必先使用manualLogin工具登录小红书后再体验其他工具！

### 效果展示

图中展示了获取笔记内容的结果，包含了标题、作者、图文/视频、正文、标签、互动数据、发布时间、发布地点等数据。

![小红书笔记](docs/img/note.png "小红书笔记")

## MCP服务器配置

以Cline配置为例：

```
{
  "mcpServers": {
    "RedNote_MCP_Plus": {
      "command": "uvx",
      "args": [
        "rednote_mcp_plus"
      ]
    }
  }
}
```