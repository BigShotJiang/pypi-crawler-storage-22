# History

## 0.1.0 (2026-02-03)

* First release on PyPI.
