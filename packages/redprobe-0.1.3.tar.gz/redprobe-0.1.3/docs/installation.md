# Installation

## Stable release

To install RedProbe, run this command in your terminal:

```sh
uv add redprobe
```

Or if you prefer to use `pip`:

```sh
pip install redprobe
```

## From source

The source files for RedProbe can be downloaded from the [Github repo](https://github.com/audreyfeldroy/redprobe).

You can either clone the public repository:

```sh
git clone git://github.com/audreyfeldroy/redprobe
```

Or download the [tarball](https://github.com/audreyfeldroy/redprobe/tarball/master):

```sh
curl -OJL https://github.com/audreyfeldroy/redprobe/tarball/master
```

Once you have a copy of the source, you can install it with:

```sh
cd redprobe
uv pip install .
```
