# Usage

To use RedProbe in a project:

```python
import redprobe
```
