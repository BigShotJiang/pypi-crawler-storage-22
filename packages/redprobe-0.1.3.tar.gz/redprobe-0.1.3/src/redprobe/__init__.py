"""Top-level package for redprobe."""

__author__ = """Audrey M. Roy Greenfeld"""
__email__ = 'audrey@feldroy.com'
