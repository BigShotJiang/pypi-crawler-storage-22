"""OpenAI-compatible API client."""

from dataclasses import dataclass

import httpx


@dataclass
class APIConfig:
    """Configuration for the API client."""

    base_url: str = "https://api.openai.com/v1"
    api_key: str = ""
    model: str = "gpt-4o-mini"
    timeout: float = 120.0


@dataclass
class Response:
    """Response from the API."""

    content: str
    model: str
    usage: dict


class Client:
    """Client for OpenAI-compatible APIs."""

    def __init__(self, config: APIConfig):
        self.config = config
        self._client = httpx.Client(timeout=config.timeout)

    def chat(self, prompt: str, system: str | None = None) -> Response:
        """Send a chat completion request."""
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        response = self._client.post(
            f"{self.config.base_url}/chat/completions",
            headers={
                "Authorization": f"Bearer {self.config.api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": self.config.model,
                "messages": messages,
            },
        )
        response.raise_for_status()
        data = response.json()

        return Response(
            content=data["choices"][0]["message"]["content"],
            model=data["model"],
            usage=data.get("usage", {}),
        )

    def close(self):
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
