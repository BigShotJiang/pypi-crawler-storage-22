"""First-run consent mechanism for redprobe."""

import json
from datetime import datetime, timezone
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm

CONFIG_DIR = Path.home() / ".config" / "redprobe"
CONSENT_FILE = CONFIG_DIR / "consent.json"

# Version of the consent terms - bump this to require re-acknowledgment
CONSENT_VERSION = "1.1"

TERMS_TEXT = """\
[bold]RedProbe[/bold] is a defensive security tool for hardening AI systems.

[bold yellow]You may only use this tool for:[/bold yellow]
  • Systems you own or operate
  • Systems you have written permission to test
  • Research/educational contexts with appropriate oversight

[bold yellow]You may NOT use this tool to:[/bold yellow]
  • Test systems without authorization
  • Extract private data from systems you don't own
  • Generate harmful content for distribution

By proceeding, you accept responsibility for your use of this tool.
"""


def has_acknowledged() -> bool:
    """Check if the user has acknowledged the terms."""
    if not CONSENT_FILE.exists():
        return False

    try:
        data = json.loads(CONSENT_FILE.read_text())
        return data.get("version") == CONSENT_VERSION
    except (json.JSONDecodeError, OSError):
        return False


def record_acknowledgment() -> None:
    """Record that the user has acknowledged the terms."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    data = {
        "version": CONSENT_VERSION,
        "acknowledged_at": datetime.now(timezone.utc).isoformat(),
    }
    CONSENT_FILE.write_text(json.dumps(data, indent=2))


def check_consent(console: Console, accept_terms: bool = False) -> bool:
    """
    Check for consent, prompting if necessary.

    Args:
        console: Rich console for output
        accept_terms: If True, accept terms without prompting (for CI/automation)

    Returns:
        True if consent was given, False if declined
    """
    if has_acknowledged():
        return True

    if accept_terms:
        record_acknowledgment()
        return True

    console.print()
    console.print(Panel(TERMS_TEXT, title="Responsible Use", border_style="yellow"))
    console.print()

    accepted = Confirm.ask("Do you acknowledge these terms?", default=False)

    if accepted:
        record_acknowledgment()
        return True

    console.print("[red]You must acknowledge the terms to use redprobe run.[/red]")
    return False
