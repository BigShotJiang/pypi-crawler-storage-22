"""Probe definitions and loading."""

from dataclasses import dataclass, field
from pathlib import Path

import yaml


@dataclass
class Probe:
    """A single red team probe."""

    id: str
    name: str
    category: str
    prompt: str
    detect_patterns: list[str] = field(default_factory=list)
    description: str = ""
    severity: str = "medium"


@dataclass
class ProbeSuite:
    """A collection of probes."""

    name: str
    description: str
    probes: list[Probe]


def load_probe_file(path: Path) -> ProbeSuite:
    """Load probes from a YAML file."""
    with open(path) as f:
        data = yaml.safe_load(f)

    probes = [
        Probe(
            id=case["id"],
            name=case["name"],
            category=case.get("category", "general"),
            prompt=case["prompt"],
            detect_patterns=case.get("detect_patterns", []),
            description=case.get("description", ""),
            severity=case.get("severity", "medium"),
        )
        for case in data.get("cases", [])
    ]

    return ProbeSuite(
        name=data.get("name", path.stem),
        description=data.get("description", ""),
        probes=probes,
    )


def load_probes(path: Path) -> list[ProbeSuite]:
    """Load all probe suites from a directory or single file."""
    if path.is_file():
        return [load_probe_file(path)]

    suites = []
    for yaml_file in sorted(path.glob("*.yaml")):
        suites.append(load_probe_file(yaml_file))
    for yml_file in sorted(path.glob("*.yml")):
        suites.append(load_probe_file(yml_file))

    return suites
