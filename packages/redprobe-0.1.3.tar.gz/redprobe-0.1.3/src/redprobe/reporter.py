"""Report generation for probe results."""

import json
from datetime import datetime
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from redprobe.runner import SuiteResult, ProbeResult


def print_result(console: Console, result: ProbeResult, verbose: bool = False):
    """Print a single probe result."""
    if result.error:
        status = "[red]ERROR[/red]"
    elif result.triggered:
        status = "[red]TRIGGERED[/red]"
    else:
        status = "[green]SAFE[/green]"

    console.print(f"  {status} {result.probe.name}")
    if result.triggered:
        console.print(f"    Matched: {', '.join(result.matched_patterns)}", style="dim")
    if result.error:
        console.print(f"    Error: {result.error}", style="dim red")
    if verbose and result.response and result.response.content:
        console.print(f"    Response: {result.response.content[:500]}{'...' if len(result.response.content) > 500 else ''}", style="dim")


def print_summary(console: Console, results: list[SuiteResult]):
    """Print a summary of all probe results."""
    table = Table(title="Red Team Results Summary")
    table.add_column("Suite", style="cyan")
    table.add_column("Total", justify="right")
    table.add_column("Triggered", justify="right", style="red")
    table.add_column("Safe", justify="right", style="green")
    table.add_column("Errors", justify="right", style="yellow")

    total_all = 0
    triggered_all = 0
    safe_all = 0
    errors_all = 0

    for suite_result in results:
        table.add_row(
            suite_result.suite.name,
            str(suite_result.total),
            str(suite_result.triggered),
            str(suite_result.safe),
            str(suite_result.errors),
        )
        total_all += suite_result.total
        triggered_all += suite_result.triggered
        safe_all += suite_result.safe
        errors_all += suite_result.errors

    if len(results) > 1:
        table.add_section()
        table.add_row(
            "TOTAL",
            str(total_all),
            str(triggered_all),
            str(safe_all),
            str(errors_all),
            style="bold",
        )

    console.print()
    console.print(table)

    if triggered_all > 0:
        console.print(
            Panel(
                f"[red bold]{triggered_all}[/red bold] probe(s) triggered potentially unsafe responses.",
                title="Warning",
                border_style="red",
            )
        )


def export_json(results: list[SuiteResult], path: Path):
    """Export results to JSON."""
    data = {
        "generated_at": datetime.now().isoformat(),
        "suites": [
            {
                "name": sr.suite.name,
                "description": sr.suite.description,
                "started_at": sr.started_at.isoformat(),
                "finished_at": sr.finished_at.isoformat(),
                "summary": {
                    "total": sr.total,
                    "triggered": sr.triggered,
                    "safe": sr.safe,
                    "errors": sr.errors,
                },
                "results": [
                    {
                        "probe_id": r.probe.id,
                        "probe_name": r.probe.name,
                        "category": r.probe.category,
                        "severity": r.probe.severity,
                        "prompt": r.probe.prompt,
                        "response": r.response.content,
                        "triggered": r.triggered,
                        "matched_patterns": r.matched_patterns,
                        "error": r.error,
                        "timestamp": r.timestamp.isoformat(),
                    }
                    for r in sr.results
                ],
            }
            for sr in results
        ],
    }

    with open(path, "w") as f:
        json.dump(data, f, indent=2)
