"""Runner for red team probes."""

import re
from dataclasses import dataclass, field
from datetime import datetime

import httpx

from redprobe.client import Client, Response
from redprobe.probes import Probe, ProbeSuite


@dataclass
class ProbeResult:
    """Result of running a single probe."""

    probe: Probe
    response: Response
    triggered: bool
    matched_patterns: list[str]
    timestamp: datetime = field(default_factory=datetime.now)
    error: str | None = None


@dataclass
class SuiteResult:
    """Result of running a probe suite."""

    suite: ProbeSuite
    results: list[ProbeResult]
    started_at: datetime
    finished_at: datetime

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def triggered(self) -> int:
        return sum(1 for r in self.results if r.triggered)

    @property
    def safe(self) -> int:
        return sum(1 for r in self.results if not r.triggered and not r.error)

    @property
    def errors(self) -> int:
        return sum(1 for r in self.results if r.error)


def check_patterns(content: str, patterns: list[str]) -> list[str]:
    """Check which patterns match in the content."""
    matched = []
    content_lower = content.lower()
    for pattern in patterns:
        if pattern.startswith("regex:"):
            regex = pattern[6:]
            if re.search(regex, content, re.IGNORECASE):
                matched.append(pattern)
        elif pattern.lower() in content_lower:
            matched.append(pattern)
    return matched


def run_probe(client: Client, probe: Probe) -> ProbeResult:
    """Run a single probe against the API."""
    try:
        response = client.chat(probe.prompt)
        matched = check_patterns(response.content, probe.detect_patterns)
        return ProbeResult(
            probe=probe,
            response=response,
            triggered=len(matched) > 0,
            matched_patterns=matched,
        )
    except httpx.TimeoutException:
        return ProbeResult(
            probe=probe,
            response=Response(content="", model="", usage={}),
            triggered=False,
            matched_patterns=[],
            error=f"timed out after {client.config.timeout:.0f}s",
        )
    except Exception as e:
        return ProbeResult(
            probe=probe,
            response=Response(content="", model="", usage={}),
            triggered=False,
            matched_patterns=[],
            error=str(e),
        )


def run_suite(client: Client, suite: ProbeSuite, callback=None) -> SuiteResult:
    """Run all probes in a suite."""
    started_at = datetime.now()
    results = []

    for probe in suite.probes:
        result = run_probe(client, probe)
        results.append(result)
        if callback:
            callback(result)

    return SuiteResult(
        suite=suite,
        results=results,
        started_at=started_at,
        finished_at=datetime.now(),
    )
