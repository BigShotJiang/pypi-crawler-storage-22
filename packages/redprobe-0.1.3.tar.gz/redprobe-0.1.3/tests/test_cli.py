"""Tests for the redprobe CLI.

These are smoke tests to verify the CLI actually works:
- Commands load without crashing
- The init command creates expected files
- The list-probes command parses YAML correctly
- The consent mechanism works correctly
"""

import json
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from redprobe import consent
from redprobe import cli
from redprobe.cli import app


@pytest.fixture
def runner():
    """Typer's CLI test runner with terminal colors disabled."""
    return CliRunner(env={"TERM": "dumb"})


class TestCLIHelp:
    """Verify the CLI loads and displays help correctly."""

    @pytest.fixture(autouse=True)
    def mock_consent(self, monkeypatch):
        """Mock consent as already acknowledged for help tests."""
        monkeypatch.setattr(cli, "check_consent", lambda *args, **kwargs: True)

    def test_main_help_shows_commands(self, runner):
        """The main --help should list all available commands."""
        result = runner.invoke(app, ["--help"])

        assert result.exit_code == 0
        assert "run" in result.output
        assert "list-probes" in result.output
        assert "init" in result.output

    def test_run_help(self, runner):
        """The run command should show its options."""
        result = runner.invoke(app, ["run", "--help"])

        assert result.exit_code == 0
        assert "--base-url" in result.output
        assert "--api-key" in result.output
        assert "--model" in result.output
        assert "--output" in result.output

    def test_init_help(self, runner):
        """The init command should show its options."""
        result = runner.invoke(app, ["init", "--help"])
        
        assert result.exit_code == 0
        assert "Create sample probe files" in result.output

    def test_list_probes_help(self, runner):
        """The list-probes command should show its options."""
        result = runner.invoke(app, ["list-probes", "--help"])
        
        assert result.exit_code == 0
        assert "List available probes" in result.output


class TestInitCommand:
    """Verify the init command creates the expected files."""

    def test_init_creates_default_directory(self, runner, tmp_path):
        """init should create probes/ with sample YAML files."""
        # Run init in a temp directory
        result = runner.invoke(app, ["init", str(tmp_path / "probes")])
        
        assert result.exit_code == 0
        assert "Created sample probes" in result.output
        
        # Check the files were created
        probes_dir = tmp_path / "probes"
        assert probes_dir.exists()
        assert (probes_dir / "jailbreaks.yaml").exists()
        assert (probes_dir / "bias.yaml").exists()
        assert (probes_dir / "harmful.yaml").exists()

    def test_init_creates_valid_yaml(self, runner, tmp_path):
        """The generated YAML files should be valid and parseable."""
        import yaml
        
        result = runner.invoke(app, ["init", str(tmp_path / "probes")])
        assert result.exit_code == 0
        
        # Each file should parse as valid YAML with expected structure
        for filename in ["jailbreaks.yaml", "bias.yaml", "harmful.yaml"]:
            yaml_path = tmp_path / "probes" / filename
            with open(yaml_path) as f:
                data = yaml.safe_load(f)
            
            assert "name" in data
            assert "cases" in data
            assert len(data["cases"]) > 0
            
            # Each case should have required fields
            for case in data["cases"]:
                assert "id" in case
                assert "name" in case
                assert "prompt" in case

    def test_init_creates_correct_number_of_probes(self, runner, tmp_path):
        """init should report creating 9 probes total (3 files x 3 probes each)."""
        result = runner.invoke(app, ["init", str(tmp_path / "probes")])
        
        assert result.exit_code == 0
        # Check the output mentions the probe counts
        assert "3 probes" in result.output


class TestListProbesCommand:
    """Verify list-probes parses and displays probes correctly."""

    @pytest.fixture
    def probes_dir(self, runner, tmp_path):
        """Create a probes directory with sample files."""
        runner.invoke(app, ["init", str(tmp_path / "probes")])
        return tmp_path / "probes"

    def test_list_probes_shows_suite_names(self, runner, probes_dir):
        """list-probes should display suite names from YAML files."""
        result = runner.invoke(app, ["list-probes", str(probes_dir)])
        
        assert result.exit_code == 0
        assert "Jailbreak Attempts" in result.output
        assert "Bias Detection" in result.output
        assert "Harmful Content" in result.output

    def test_list_probes_shows_probe_ids(self, runner, probes_dir):
        """list-probes should display probe IDs."""
        result = runner.invoke(app, ["list-probes", str(probes_dir)])
        
        assert result.exit_code == 0
        assert "jailbreak-001" in result.output
        assert "bias-001" in result.output
        assert "harmful-001" in result.output

    def test_list_probes_shows_severity(self, runner, probes_dir):
        """list-probes should display severity levels."""
        result = runner.invoke(app, ["list-probes", str(probes_dir)])
        
        assert result.exit_code == 0
        assert "HIGH" in result.output
        assert "MEDIUM" in result.output

    def test_list_probes_single_file(self, runner, probes_dir):
        """list-probes should work with a single YAML file."""
        result = runner.invoke(app, ["list-probes", str(probes_dir / "jailbreaks.yaml")])
        
        assert result.exit_code == 0
        assert "Jailbreak Attempts" in result.output
        assert "jailbreak-001" in result.output
        # Should NOT show other suites
        assert "Bias Detection" not in result.output

    def test_list_probes_nonexistent_path_fails(self, runner, tmp_path):
        """list-probes should fail gracefully for nonexistent paths."""
        result = runner.invoke(app, ["list-probes", str(tmp_path / "nonexistent")])
        
        # Typer validates exists=True, so this should fail
        assert result.exit_code != 0


class TestRunCommandValidation:
    """Test run command argument validation (without hitting an API)."""

    @pytest.fixture(autouse=True)
    def mock_consent(self, monkeypatch):
        """Mock consent as already acknowledged for validation tests."""
        monkeypatch.setattr(cli, "check_consent", lambda *args, **kwargs: True)

    def test_run_requires_probes_argument(self, runner):
        """run should require a probes path."""
        result = runner.invoke(app, ["run"])

        assert result.exit_code != 0
        assert "Missing argument" in result.output

    def test_run_nonexistent_path_fails(self, runner, tmp_path):
        """run should fail for nonexistent probes path."""
        result = runner.invoke(app, ["run", str(tmp_path / "nonexistent")])

        assert result.exit_code != 0


class TestConsentMechanism:
    """Verify the consent mechanism works correctly."""

    @pytest.fixture
    def mock_config_dir(self, tmp_path, monkeypatch):
        """Redirect consent file to a temp directory."""
        config_dir = tmp_path / ".config" / "redprobe"
        consent_file = config_dir / "consent.json"
        monkeypatch.setattr(consent, "CONFIG_DIR", config_dir)
        monkeypatch.setattr(consent, "CONSENT_FILE", consent_file)
        return config_dir

    @pytest.fixture
    def probes_dir(self, runner, tmp_path):
        """Create a probes directory with sample files."""
        runner.invoke(app, ["init", str(tmp_path / "probes")])
        return tmp_path / "probes"

    def test_accept_terms_flag_creates_consent_file(self, runner, mock_config_dir, probes_dir):
        """--accept-terms should create the consent file without prompting."""
        consent_file = mock_config_dir / "consent.json"
        assert not consent_file.exists()

        # This will fail to connect to API but should pass consent check
        result = runner.invoke(app, ["run", str(probes_dir), "--accept-terms"])

        # Consent file should be created regardless of API errors
        assert consent_file.exists()

        data = json.loads(consent_file.read_text())
        assert data["version"] == consent.CONSENT_VERSION
        assert "acknowledged_at" in data

    def test_subsequent_runs_skip_consent_prompt(self, runner, mock_config_dir, probes_dir):
        """After accepting terms, subsequent runs should not prompt."""
        # First run with --accept-terms
        runner.invoke(app, ["run", str(probes_dir), "--accept-terms"])

        # Second run without the flag should not prompt (would fail if it did since no input)
        result = runner.invoke(app, ["run", str(probes_dir)])

        # Should get past consent check (will fail on API call, but that's expected)
        assert "Loaded" in result.output or "Error" in result.output

    def test_declined_consent_exits_with_error(self, runner, mock_config_dir, probes_dir):
        """Declining consent should exit with code 1."""
        # Simulate declining by providing 'n' as input
        result = runner.invoke(app, ["run", str(probes_dir)], input="n\n")

        assert result.exit_code == 1
        assert "must acknowledge" in result.output.lower()

    def test_list_probes_does_not_require_consent(self, runner, mock_config_dir, probes_dir):
        """list-probes should work without consent (no API calls)."""
        consent_file = mock_config_dir / "consent.json"
        assert not consent_file.exists()

        result = runner.invoke(app, ["list-probes", str(probes_dir)])

        assert result.exit_code == 0
        assert "Jailbreak Attempts" in result.output
        # Consent file should NOT be created
        assert not consent_file.exists()

    def test_init_does_not_require_consent(self, runner, mock_config_dir, tmp_path):
        """init should work without consent (no API calls)."""
        consent_file = mock_config_dir / "consent.json"
        assert not consent_file.exists()

        result = runner.invoke(app, ["init", str(tmp_path / "new-probes")])

        assert result.exit_code == 0
        assert "Created sample probes" in result.output
        # Consent file should NOT be created
        assert not consent_file.exists()

    def test_consent_version_change_requires_reacknowledgment(self, runner, mock_config_dir, probes_dir):
        """Changing the consent version should require re-acknowledgment."""
        # Accept terms initially
        runner.invoke(app, ["run", str(probes_dir), "--accept-terms"])

        # Manually change the version in the consent file to simulate an old version
        consent_file = mock_config_dir / "consent.json"
        data = json.loads(consent_file.read_text())
        data["version"] = "0.0"  # Old version
        consent_file.write_text(json.dumps(data))

        # Next run should require consent again (decline it)
        result = runner.invoke(app, ["run", str(probes_dir)], input="n\n")

        assert result.exit_code == 1
        assert "must acknowledge" in result.output.lower()
