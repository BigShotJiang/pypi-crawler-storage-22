"""Tests for the probes module.

The probes module handles YAML parsing and validation.
These tests verify the parsing logic works correctly.
"""

import pytest
from pathlib import Path

from redprobe.probes import Probe, ProbeSuite, load_probe_file, load_probes


class TestProbeDataclass:
    """Verify the Probe dataclass works correctly."""

    def test_probe_required_fields(self):
        """Probe should require id, name, category, prompt."""
        probe = Probe(
            id="test-001",
            name="Test probe",
            category="general",
            prompt="Say hello",
        )
        
        assert probe.id == "test-001"
        assert probe.name == "Test probe"
        assert probe.category == "general"
        assert probe.prompt == "Say hello"

    def test_probe_default_values(self):
        """Probe should have sensible defaults for optional fields."""
        probe = Probe(
            id="test-001",
            name="Test probe",
            category="general",
            prompt="Say hello",
        )
        
        assert probe.detect_patterns == []
        assert probe.description == ""
        assert probe.severity == "medium"

    def test_probe_with_all_fields(self):
        """Probe should accept all optional fields."""
        probe = Probe(
            id="test-001",
            name="Test probe",
            category="jailbreak",
            prompt="Say hello",
            detect_patterns=["hello", "hi"],
            description="A test description",
            severity="high",
        )
        
        assert probe.detect_patterns == ["hello", "hi"]
        assert probe.description == "A test description"
        assert probe.severity == "high"


class TestProbeSuiteDataclass:
    """Verify the ProbeSuite dataclass works correctly."""

    def test_probesuite_fields(self):
        """ProbeSuite should hold name, description, and probes."""
        probe = Probe(id="test-001", name="Test", category="general", prompt="Hello")
        suite = ProbeSuite(
            name="My Suite",
            description="Suite description",
            probes=[probe],
        )
        
        assert suite.name == "My Suite"
        assert suite.description == "Suite description"
        assert len(suite.probes) == 1
        assert suite.probes[0].id == "test-001"


class TestLoadProbeFile:
    """Verify YAML file loading works correctly."""

    def test_load_minimal_yaml(self, tmp_path):
        """Should load a YAML file with minimal required fields."""
        yaml_content = """
name: Minimal Suite
cases:
  - id: test-001
    name: Test One
    prompt: Hello world
"""
        yaml_file = tmp_path / "minimal.yaml"
        yaml_file.write_text(yaml_content)
        
        suite = load_probe_file(yaml_file)
        
        assert suite.name == "Minimal Suite"
        assert suite.description == ""
        assert len(suite.probes) == 1
        assert suite.probes[0].id == "test-001"
        assert suite.probes[0].category == "general"  # default

    def test_load_full_yaml(self, tmp_path):
        """Should load a YAML file with all fields."""
        yaml_content = """
name: Full Suite
description: A complete test suite

cases:
  - id: test-001
    name: Test One
    category: jailbreak
    severity: high
    description: This is test one
    prompt: |
      Multi-line prompt
      goes here
    detect_patterns:
      - pattern1
      - pattern2
      - "regex:\\bword\\b"
"""
        yaml_file = tmp_path / "full.yaml"
        yaml_file.write_text(yaml_content)
        
        suite = load_probe_file(yaml_file)
        
        assert suite.name == "Full Suite"
        assert suite.description == "A complete test suite"
        assert len(suite.probes) == 1
        
        probe = suite.probes[0]
        assert probe.id == "test-001"
        assert probe.category == "jailbreak"
        assert probe.severity == "high"
        assert probe.description == "This is test one"
        assert "Multi-line prompt" in probe.prompt
        assert len(probe.detect_patterns) == 3

    def test_load_multiple_probes(self, tmp_path):
        """Should load multiple probes from one file."""
        yaml_content = """
name: Multi Probe Suite
cases:
  - id: test-001
    name: First
    prompt: Hello
  - id: test-002
    name: Second
    prompt: World
  - id: test-003
    name: Third
    prompt: Foo
"""
        yaml_file = tmp_path / "multi.yaml"
        yaml_file.write_text(yaml_content)
        
        suite = load_probe_file(yaml_file)
        
        assert len(suite.probes) == 3
        assert suite.probes[0].id == "test-001"
        assert suite.probes[1].id == "test-002"
        assert suite.probes[2].id == "test-003"

    def test_uses_filename_as_fallback_name(self, tmp_path):
        """Should use filename as suite name if name field is missing."""
        yaml_content = """
cases:
  - id: test-001
    name: Test
    prompt: Hello
"""
        yaml_file = tmp_path / "my_suite.yaml"
        yaml_file.write_text(yaml_content)
        
        suite = load_probe_file(yaml_file)
        
        assert suite.name == "my_suite"  # stem of filename


class TestLoadProbes:
    """Verify loading from directories and single files."""

    @pytest.fixture
    def probes_dir(self, tmp_path):
        """Create a directory with multiple YAML files."""
        suite1 = """
name: Suite One
cases:
  - id: s1-001
    name: Test 1
    prompt: Hello
"""
        suite2 = """
name: Suite Two
cases:
  - id: s2-001
    name: Test 2
    prompt: World
"""
        suite3 = """
name: Suite Three
cases:
  - id: s3-001
    name: Test 3
    prompt: Foo
"""
        (tmp_path / "suite1.yaml").write_text(suite1)
        (tmp_path / "suite2.yml").write_text(suite2)  # .yml extension
        (tmp_path / "suite3.yaml").write_text(suite3)
        return tmp_path

    def test_load_single_file(self, probes_dir):
        """Should load a single file when path is a file."""
        suites = load_probes(probes_dir / "suite1.yaml")
        
        assert len(suites) == 1
        assert suites[0].name == "Suite One"

    def test_load_directory(self, probes_dir):
        """Should load all YAML files from a directory."""
        suites = load_probes(probes_dir)
        
        assert len(suites) == 3
        suite_names = [s.name for s in suites]
        assert "Suite One" in suite_names
        assert "Suite Two" in suite_names
        assert "Suite Three" in suite_names

    def test_load_directory_both_extensions(self, probes_dir):
        """Should load both .yaml and .yml files."""
        suites = load_probes(probes_dir)
        
        # suite2.yml should be loaded
        suite_names = [s.name for s in suites]
        assert "Suite Two" in suite_names

    def test_load_empty_directory(self, tmp_path):
        """Should return empty list for directory with no YAML files."""
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()
        
        suites = load_probes(empty_dir)
        
        assert suites == []

    def test_ignores_non_yaml_files(self, tmp_path):
        """Should ignore non-YAML files in directory."""
        yaml_content = """
name: Real Suite
cases:
  - id: test-001
    name: Test
    prompt: Hello
"""
        (tmp_path / "suite.yaml").write_text(yaml_content)
        (tmp_path / "readme.txt").write_text("This is not YAML")
        (tmp_path / "data.json").write_text('{"not": "yaml"}')
        
        suites = load_probes(tmp_path)
        
        assert len(suites) == 1
        assert suites[0].name == "Real Suite"
