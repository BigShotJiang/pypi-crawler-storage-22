"""Tests for the runner module.

The runner module contains the pattern matching logic for detecting
problematic responses. These tests verify that logic works correctly.
"""

import pytest

from redprobe.runner import check_patterns


class TestCheckPatterns:
    """Verify the pattern matching logic works correctly."""

    def test_no_patterns_returns_empty(self):
        """Should return empty list when no patterns provided."""
        result = check_patterns("some content", [])
        assert result == []

    def test_simple_match(self):
        """Should detect simple string matches."""
        content = "The quick brown fox jumps over the lazy dog"
        patterns = ["quick", "fox"]
        
        result = check_patterns(content, patterns)
        
        assert "quick" in result
        assert "fox" in result

    def test_case_insensitive_match(self):
        """Should match regardless of case."""
        content = "Hello World"
        patterns = ["HELLO", "world"]
        
        result = check_patterns(content, patterns)
        
        assert "HELLO" in result
        assert "world" in result

    def test_no_match_returns_empty(self):
        """Should return empty list when no patterns match."""
        content = "The quick brown fox"
        patterns = ["cat", "dog"]
        
        result = check_patterns(content, patterns)
        
        assert result == []

    def test_partial_word_match(self):
        """Simple patterns match substrings (not just whole words)."""
        content = "I can do anything now"
        patterns = ["anything"]
        
        result = check_patterns(content, patterns)
        
        assert "anything" in result

    def test_regex_pattern(self):
        """Should support regex: prefix for regex matching."""
        content = "She walked into the room"
        patterns = ["regex:\\bshe\\b"]  # Word boundary match
        
        result = check_patterns(content, patterns)
        
        assert "regex:\\bshe\\b" in result

    def test_regex_case_insensitive(self):
        """Regex patterns should be case insensitive."""
        content = "HER name is Alice"
        patterns = ["regex:\\bher\\b"]
        
        result = check_patterns(content, patterns)
        
        assert "regex:\\bher\\b" in result

    def test_regex_no_match(self):
        """Regex patterns should not match when pattern doesn't fit."""
        content = "There is no match here"
        patterns = ["regex:\\bshe\\b"]
        
        result = check_patterns(content, patterns)
        
        assert result == []

    def test_mixed_patterns(self):
        """Should handle both simple and regex patterns together."""
        content = "She said hello to her friend"
        patterns = [
            "hello",
            "regex:\\bshe\\b",
            "goodbye",  # won't match
            "regex:\\bhim\\b",  # won't match
        ]
        
        result = check_patterns(content, patterns)
        
        assert "hello" in result
        assert "regex:\\bshe\\b" in result
        assert "goodbye" not in result
        assert "regex:\\bhim\\b" not in result

    def test_multiline_content(self):
        """Should work with multiline content."""
        content = """This is line one.
This is line two with a keyword.
This is line three."""
        patterns = ["keyword"]
        
        result = check_patterns(content, patterns)
        
        assert "keyword" in result

    def test_regex_multiline(self):
        """Regex should work across multiple lines."""
        content = """First line
Second line with target word
Third line"""
        patterns = ["regex:target.*word"]
        
        result = check_patterns(content, patterns)
        
        assert "regex:target.*word" in result
