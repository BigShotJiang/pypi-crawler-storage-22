# Contributing

Contributions are welcome, and they are greatly appreciated! Every little bit helps, and credit will always be given.

You can contribute in many ways:

## Types of Contributions

### Report Bugs

Report bugs at https://github.com/audreyfeldroy/redprobe/issues.

If you are reporting a bug, please include:

- Your operating system name and version.
- Any details about your local setup that might be helpful in troubleshooting.
- Detailed steps to reproduce the bug.

### Fix Bugs

Look through the GitHub issues for bugs. Anything tagged with "bug" and "help wanted" is open to whoever wants to implement it.

### Implement Features

Look through the GitHub issues for features. Anything tagged with "enhancement" and "help wanted" is open to whoever wants to implement it.

### Write Documentation

RedProbe could always use more documentation, whether as part of the official docs, in docstrings, or even on the web in blog posts, articles, and such.

### Submit Feedback

The best way to send feedback is to file an issue at https://github.com/audreyfeldroy/redprobe/issues.

If you are proposing a feature:

- Explain in detail how it would work.
- Keep the scope as narrow as possible, to make it easier to implement.
- Remember that this is a volunteer-driven project, and that contributions are welcome :)

## Contributing Probes

Probes are the core of RedProbe. We welcome contributions of new probes that help the community test AI systems more effectively.

### What Makes a Good Probe

A good probe contribution should have:

- **Clear objective**: The probe tests for a specific, well-defined vulnerability or behavior
- **Realistic scenario**: The prompt reflects something a real attacker might try or a real user might accidentally trigger
- **Good detection patterns**: Patterns that catch genuine failures without excessive false positives
- **Appropriate severity**: Severity rating that matches the actual risk if the probe triggers
- **Defensive purpose**: The probe exists to help people find and fix issues, not to provide a ready-to-use attack

### What to Avoid

We will not accept probes that:

- **Exist only to cause harm**: Probes should test for vulnerabilities, not just generate harmful content
- **Contain harmful content in the probe itself**: The prompt should test whether a model will generate harmful content, but shouldn't contain detailed harmful instructions that could be extracted and misused
- **Are overly specific**: Probes that only work against one specific model version or provider aren't broadly useful
- **Depend on external resources**: Probes should be self-contained and not require fetching URLs, calling APIs, or accessing files

### Severity Ratings

Use these guidelines when assigning severity:

| Severity | When to Use | Examples |
|----------|-------------|----------|
| **Low** | Minor issues, low potential for harm | Model reveals it's an AI when asked to roleplay, inconsistent persona |
| **Medium** | Moderate risk, could cause harm in some contexts | Gender bias in occupation descriptions, age-based assumptions |
| **High** | Significant risk, could cause real harm | Generating violence instructions, bypassing safety filters for dangerous content, leaking PII |

When in doubt, start with a higher severity and let reviewers suggest lowering it.

### Review Process

All probe contributions go through code review:

- **Low and medium severity probes**: Standard review process, same as other contributions
- **High severity probes**: Additional scrutiny to ensure the probe serves a defensive purpose and doesn't provide more detail than necessary for testing

Reviewers will assess:
1. Does this probe test for a real vulnerability?
2. Are the detection patterns appropriate?
3. Is the severity rating accurate?
4. Could this probe be misused if shared publicly?

### Probes We Won't Accept

Some categories of probes are out of scope regardless of how they're implemented:

- **CSAM generation**: We will not accept probes that test for generation of child sexual abuse material
- **Targeting real individuals**: Probes that attempt to generate harmful content about specific real people
- **Detailed weapons/explosives instructions**: Probes testing for this exist, but we won't host detailed examples
- **Probes requiring external dependencies**: Anything that needs to fetch URLs, call APIs, or access the filesystem

If you're unsure whether your probe is appropriate, open an issue to discuss it before submitting.

## Get Started!

Ready to contribute? Here's how to set up `redprobe` for local development.

1. Fork the `redprobe` repo on GitHub.
2. Clone your fork locally:

   ```sh
   git clone git@github.com:your_name_here/redprobe.git
   ```

3. Install your local copy into a virtualenv. Assuming you have virtualenvwrapper installed, this is how you set up your fork for local development:

   ```sh
   mkvirtualenv redprobe
   cd redprobe/
   python setup.py develop
   ```

4. Create a branch for local development:

   ```sh
   git checkout -b name-of-your-bugfix-or-feature
   ```

   Now you can make your changes locally.

5. When you're done making changes, check that your changes pass flake8 and the tests, including testing other Python versions with tox:

   ```sh
   make lint
   make test
   # Or
   make test-all
   ```

   To get flake8 and tox, just pip install them into your virtualenv.

6. Commit your changes and push your branch to GitHub:

   ```sh
   git add .
   git commit -m "Your detailed description of your changes."
   git push origin name-of-your-bugfix-or-feature
   ```

7. Submit a pull request through the GitHub website.

## Pull Request Guidelines

Before you submit a pull request, check that it meets these guidelines:

1. The pull request should include tests.
2. If the pull request adds functionality, the docs should be updated. Put your new functionality into a function with a docstring, and add the feature to the list in README.md.
3. The pull request should work for Python 3.12 and 3.13. Tests run in GitHub Actions on every pull request to the main branch, make sure that the tests pass for all supported Python versions.

## Tips

To run a subset of tests:

```sh
pytest tests.test_redprobe
```

## Releasing to PyPI

### First-Time Setup (One-Time)

Before you can publish, set up PyPI trusted publishing:

1. Create a PyPI account at [pypi.org](https://pypi.org) if you don't have one
2. Go to your PyPI account > Publishing > Add a new pending publisher
3. Fill in the form:
   - **PyPI Project Name:** `redprobe`
   - **Owner:** Your GitHub username or organization
   - **Repository name:** `redprobe`
   - **Workflow name:** `publish.yml`
   - **Environment name:** Leave blank
4. Push your first tag to trigger the publish

### Every Release

Releases are automated via GitHub Actions. When you push a tag, the workflow builds and publishes to PyPI using trusted publishing.

1. Make sure all changes are committed and pushed
2. Bump the version:

   ```sh
   uv version --bump patch  # or: minor, major
   ```

3. Commit the version bump:

   ```sh
   git add pyproject.toml uv.lock
   git commit -m "Release X.Y.Z"
   git push
   ```

4. Tag and push (triggers the publish):

   ```sh
   just tag
   ```

   Or manually:

   ```sh
   git tag -a vX.Y.Z -m "Release vX.Y.Z"
   git push origin vX.Y.Z
   ```

5. GitHub Actions publishes to PyPI automatically. Check the Actions tab to verify.

## Code of Conduct

Please note that this project is released with a [Contributor Code of Conduct](CODE_OF_CONDUCT.md). By participating in this project you agree to abide by its terms.
