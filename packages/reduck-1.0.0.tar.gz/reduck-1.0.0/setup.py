from setuptools import setup, find_packages

setup(
    name="reduck",           # PyPI adı
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "colorama",
        "scapy"
    ],
    author="Sh3d0w",
    description="Reduck network lab toolkit",
)
