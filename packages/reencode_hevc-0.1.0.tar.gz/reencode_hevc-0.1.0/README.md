# reencode-hevc

Usage:
```
reencode-hevc.py [pattern]
```

This will re-encode all files that match `*pattern*` to HEVC and .mkv
