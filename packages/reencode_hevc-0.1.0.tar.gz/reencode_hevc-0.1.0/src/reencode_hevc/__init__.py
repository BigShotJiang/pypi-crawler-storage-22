#! /usr/bin/python3

# ffmpeg -i in.mp4 \
#       -c:v hevc_nvenc \
#       -preset medium \
#       -rc vbr \
#       -cq 22 \
#       -b:v 0 \
#       -pix_fmt p010le \
#       -c:a copy \
#       -c:s copy \
#       -c:t copy \
#       -map 0 \
#       out.mkv
import sys
import subprocess
import os


def main():
    if len(sys.argv) != 2:
        print("You need to specify extension")
        sys.exit()

    pattern = sys.argv[1]

    files = [
        f
        for f in os.listdir(os.getcwd())
        if os.path.isfile(os.path.join(os.getcwd(), f)) and pattern.lower() in f.lower()
    ]

    subprocess.run(["mkdir", "-p", "old"])

    for f in files:
        newname = f[:-4] + ".mkv"
        oldname = "old-" + f

        subprocess.run(["mv", f, oldname])

        cmd = [
            "ffmpeg",
            "-i",
            f"file:{oldname}",
            "-c:v",
            "hevc_nvenc",
            "-preset",
            "medium",
            "-rc",
            "vbr",
            "-cq",
            "22",
            "-b:v",
            "0",
            "-pix_fmt",
            "p010le",
            "-c:a",
            "copy",
            "-c:s",
            "copy",
            "-c:t",
            "copy",
            "-map",
            "0",
            f"file:{newname}",
        ]
        subprocess.run(cmd, check=True)
        subprocess.run(["mv", oldname, "./old/"], check=True)


if __name__ == "__main__":
    main()
