"""Analyzers for detecting code issues and patterns."""
