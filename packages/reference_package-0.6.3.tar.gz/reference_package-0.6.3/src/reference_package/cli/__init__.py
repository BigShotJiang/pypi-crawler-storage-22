"""CLI init. See :doc:`CLI`."""
