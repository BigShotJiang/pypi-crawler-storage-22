"""E2E tests for the Refineo CLI."""

import subprocess
import sys


def run_cli(args: list[str]) -> tuple[str, str, int]:
    """Run the CLI and return stdout, stderr, exit code."""
    result = subprocess.run(
        [sys.executable, "-m", "refineo_cli.cli", *args],
        capture_output=True,
        text=True,
    )
    return result.stdout, result.stderr, result.returncode


class TestVerboseFlag:
    """Test --verbose flag for debug output."""

    def test_shows_debug_output_with_verbose_flag(self) -> None:
        """Verify --verbose flag enables debug output."""
        stdout, stderr, exit_code = run_cli(["humanize", "short text", "--verbose"])

        output = stdout + stderr
        assert "[refineo-debug]" in output
        assert "Request URL" in output

    def test_shows_debug_output_with_v_shorthand(self) -> None:
        """Verify -v shorthand enables debug output."""
        stdout, stderr, exit_code = run_cli(["humanize", "short text", "-v"])

        output = stdout + stderr
        assert "[refineo-debug]" in output

    def test_no_debug_output_without_flag(self) -> None:
        """Verify debug output is hidden without flag."""
        stdout, stderr, exit_code = run_cli(["humanize", "short text"])

        output = stdout + stderr
        assert "[refineo-debug]" not in output


class TestHumanizeValidation:
    """Test humanize command validation error messages."""

    def test_shows_detailed_error_when_text_too_short(self) -> None:
        """Verify detailed validation message is shown, not generic 'Invalid request data'."""
        stdout, stderr, exit_code = run_cli(["humanize", "short text"])

        assert exit_code == 1
        # Check combined output since error could be in either stream
        output = stdout + stderr
        assert "Text must be at least 100 characters" in output
        assert "Invalid request data" not in output

    def test_succeeds_with_long_text(self) -> None:
        """Verify text >= 100 characters doesn't trigger validation error."""
        long_text = "A" * 100 + " This is additional text to meet the minimum."
        stdout, stderr, exit_code = run_cli(["humanize", long_text])

        # Should either succeed or fail with a different error (not validation)
        if exit_code != 0:
            output = stdout + stderr
            assert "Text must be at least 100 characters" not in output


class TestHelpCommand:
    """Test help command."""

    def test_shows_help_text(self) -> None:
        """Verify help command shows usage information."""
        stdout, stderr, exit_code = run_cli(["help"])

        assert exit_code == 0
        assert "humanize" in stdout
