/// <reference path="../src/typings.d.ts" />
import { IRenderMime } from '@jupyterlab/rendermime-interfaces';
import 'molstar/build/viewer/molstar.css';
import '../style/index.css';
declare const extension: IRenderMime.IExtension;
export default extension;
