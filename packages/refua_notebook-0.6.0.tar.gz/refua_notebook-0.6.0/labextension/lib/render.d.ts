export declare function initRefuaWidgets(root: HTMLElement): void;
