"""
Performance metrics collection with OpenTelemetry integration.

Provides standardized metrics collection compatible with Prometheus and Grafana.
Supports both OpenTelemetry and standalone operation for flexibility.

Example:
    >>> from regscale.core.observability import metrics
    >>>
    >>> # Track operation duration
    >>> with metrics.timer("bulk_upload_duration_seconds"):
    ...     process_bulk_upload()
    >>>
    >>> # Increment counter
    >>> metrics.increment("items_processed_total", 1000)
    >>>
    >>> # Set gauge value
    >>> metrics.gauge("connection_pool_utilization", 0.75)
"""

import logging
import time
from contextlib import contextmanager
from typing import Any, Dict, Optional

logger = logging.getLogger("regscale")

# Try to import OpenTelemetry (optional dependency)
try:
    from opentelemetry import metrics as otel_metrics
    from opentelemetry.exporter.prometheus import PrometheusMetricReader
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.resources import Resource
    from prometheus_client import start_http_server

    OTEL_AVAILABLE = True
except ImportError:
    OTEL_AVAILABLE = False
    otel_metrics = None


class MetricsCollector:
    """
    Centralized metrics collection with OpenTelemetry integration.

    Collects performance, resilience, and API metrics for monitoring and
    troubleshooting. Optionally exports to Prometheus for Grafana visualization.

    Example:
        >>> metrics = MetricsCollector()
        >>> metrics.increment("api_requests_total", 1, {"endpoint": "/issues"})
        >>> with metrics.timer("operation_duration_seconds"):
        ...     expensive_operation()
    """

    def __init__(
        self, service_name: str = "regscale-cli", enable_prometheus: bool = False, prometheus_port: int = 9090
    ):
        """
        Initialize metrics collector.

        Args:
            service_name: Service name for metrics labeling
            enable_prometheus: Whether to expose Prometheus endpoint
            prometheus_port: Port for Prometheus metrics endpoint
        """
        self.service_name = service_name
        self.enable_prometheus = enable_prometheus
        self.prometheus_port = prometheus_port

        # Internal metrics storage (fallback when OpenTelemetry unavailable)
        self._counters: Dict[str, float] = {}
        self._gauges: Dict[str, float] = {}
        self._histograms: Dict[str, list] = {}

        # OpenTelemetry instruments
        self._meter = None
        self._otel_counters: Dict[str, Any] = {}
        self._otel_gauges: Dict[str, Any] = {}
        self._otel_histograms: Dict[str, Any] = {}

        # Initialize OpenTelemetry if available
        if OTEL_AVAILABLE:
            self._initialize_opentelemetry()
        else:
            logger.debug("OpenTelemetry not available, using internal metrics storage")

    def _initialize_opentelemetry(self) -> None:
        """Initialize OpenTelemetry metrics provider."""
        try:
            resource = Resource.create({"service.name": self.service_name})

            # Setup Prometheus exporter if enabled
            if self.enable_prometheus:
                reader = PrometheusMetricReader()
                provider = MeterProvider(resource=resource, metric_readers=[reader])

                # Start Prometheus HTTP server
                start_http_server(port=self.prometheus_port, addr="0.0.0.0")
                logger.info(f"Prometheus metrics endpoint started on port {self.prometheus_port}")
            else:
                provider = MeterProvider(resource=resource)

            otel_metrics.set_meter_provider(provider)
            self._meter = otel_metrics.get_meter(__name__)

            logger.info("OpenTelemetry metrics initialized successfully")
        except Exception as e:
            logger.warning(f"Failed to initialize OpenTelemetry metrics: {e}")
            self._meter = None

    def increment(self, name: str, value: float = 1.0, attributes: Optional[Dict[str, Any]] = None) -> None:
        """
        Increment a counter metric.

        Args:
            name: Metric name (e.g., "items_processed_total")
            value: Amount to increment by (default: 1.0)
            attributes: Optional attributes/labels for the metric

        Example:
            >>> metrics.increment("api_requests_total", 1, {"endpoint": "/issues", "status": "200"})
        """
        if self._meter:
            # Use OpenTelemetry counter
            if name not in self._otel_counters:
                self._otel_counters[name] = self._meter.create_counter(
                    name=name, description=f"Counter: {name}", unit="1"
                )

            self._otel_counters[name].add(value, attributes=attributes or {})
        else:
            # Fallback to internal storage
            key = self._make_key(name, attributes)
            self._counters[key] = self._counters.get(key, 0.0) + value

    def gauge(self, name: str, value: float, attributes: Optional[Dict[str, Any]] = None) -> None:
        """
        Set a gauge metric.

        Args:
            name: Metric name (e.g., "memory_usage_mb")
            value: Current value
            attributes: Optional attributes/labels for the metric

        Example:
            >>> metrics.gauge("connection_pool_utilization", 0.75)
            >>> metrics.gauge("memory_usage_mb", 2048.5)
        """
        if self._meter:
            # Use OpenTelemetry gauge (observable gauge)
            if name not in self._otel_gauges:

                def gauge_callback(options):
                    """Callback to provide current gauge value."""
                    return [(value, attributes or {})]

                self._otel_gauges[name] = self._meter.create_observable_gauge(
                    name=name, callbacks=[gauge_callback], description=f"Gauge: {name}", unit="1"
                )
        else:
            # Fallback to internal storage
            key = self._make_key(name, attributes)
            self._gauges[key] = value

    def histogram(self, name: str, value: float, attributes: Optional[Dict[str, Any]] = None) -> None:
        """
        Record a histogram metric.

        Args:
            name: Metric name (e.g., "operation_duration_seconds")
            value: Value to record
            attributes: Optional attributes/labels for the metric

        Example:
            >>> metrics.histogram("api_request_duration_seconds", 0.234, {"endpoint": "/issues"})
        """
        if self._meter:
            # Use OpenTelemetry histogram
            if name not in self._otel_histograms:
                self._otel_histograms[name] = self._meter.create_histogram(
                    name=name, description=f"Histogram: {name}", unit="1"
                )

            self._otel_histograms[name].record(value, attributes=attributes or {})
        else:
            # Fallback to internal storage
            key = self._make_key(name, attributes)
            if key not in self._histograms:
                self._histograms[key] = []
            self._histograms[key].append(value)

    @contextmanager
    def timer(self, name: str, attributes: Optional[Dict[str, Any]] = None):
        """
        Context manager for timing operations.

        Args:
            name: Metric name (e.g., "bulk_upload_duration_seconds")
            attributes: Optional attributes/labels for the metric

        Example:
            >>> with metrics.timer("data_processing_duration_seconds", {"batch_size": "1000"}):
            ...     process_data()
        """
        start_time = time.time()
        try:
            yield
        finally:
            duration = time.time() - start_time
            self.histogram(name, duration, attributes)

    def get_metrics(self) -> Dict[str, Any]:
        """
        Get all collected metrics (internal storage only).

        Returns:
            Dictionary with counters, gauges, and histograms

        Note:
            This only returns internal metrics. For OpenTelemetry metrics,
            query the Prometheus endpoint directly.

        Example:
            >>> metrics_data = metrics.get_metrics()
            >>> print(f"Items processed: {metrics_data['counters']['items_processed_total']}")
        """
        return {"counters": self._counters.copy(), "gauges": self._gauges.copy(), "histograms": self._histograms.copy()}

    def reset(self) -> None:
        """
        Reset all internal metrics.

        Note:
            This only resets internal storage. OpenTelemetry metrics
            are managed by the provider and cannot be reset.
        """
        self._counters.clear()
        self._gauges.clear()
        self._histograms.clear()

    def _make_key(self, name: str, attributes: Optional[Dict[str, Any]]) -> str:
        """Create storage key from metric name and attributes."""
        if not attributes:
            return name

        # Sort attributes for consistent keys
        attr_str = ",".join(f"{k}={v}" for k, v in sorted(attributes.items()))
        return f"{name}{{{attr_str}}}"


# Singleton metrics instance
metrics = MetricsCollector()


# Pre-defined metric helpers for common operations
def track_api_request(endpoint: str, status_code: int, duration: float) -> None:
    """
    Track API request metrics.

    Args:
        endpoint: API endpoint path
        status_code: HTTP status code
        duration: Request duration in seconds

    Example:
        >>> track_api_request("/api/issues", 200, 0.234)
    """
    metrics.increment("api_requests_total", 1, {"endpoint": endpoint, "status": str(status_code)})
    metrics.histogram("api_request_duration_seconds", duration, {"endpoint": endpoint})

    if status_code >= 400:
        metrics.increment("api_errors_total", 1, {"endpoint": endpoint, "status": str(status_code)})


def track_bulk_operation(
    operation_name: str, items_total: int, success_count: int, failure_count: int, duration: float
) -> None:
    """
    Track bulk operation metrics.

    Args:
        operation_name: Name of the operation (e.g., "bulk_upload")
        items_total: Total number of items processed
        success_count: Number of successful items
        failure_count: Number of failed items
        duration: Operation duration in seconds

    Example:
        >>> track_bulk_operation("wiz_import", 50000, 49500, 500, 45.2)
    """
    attrs = {"operation": operation_name}

    metrics.increment("items_processed_total", items_total, attrs)
    metrics.increment("items_success_total", success_count, attrs)
    metrics.increment("items_failed_total", failure_count, attrs)
    metrics.histogram("operation_duration_seconds", duration, attrs)

    # Calculate and track throughput
    if duration > 0:
        throughput = items_total / duration
        metrics.gauge("throughput_items_per_second", throughput, attrs)


def track_circuit_breaker_state(name: str, state: str) -> None:
    """
    Track circuit breaker state changes.

    Args:
        name: Circuit breaker name
        state: New state (CLOSED, OPEN, HALF_OPEN)

    Example:
        >>> track_circuit_breaker_state("api_breaker", "OPEN")
    """
    metrics.increment("circuit_breaker_state_transitions", 1, {"breaker": name, "state": state})
    metrics.gauge("circuit_breaker_state", 1 if state == "OPEN" else 0, {"breaker": name})


def track_retry_attempt(operation: str, attempt: int, success: bool) -> None:
    """
    Track retry attempts.

    Args:
        operation: Operation name
        attempt: Attempt number
        success: Whether the attempt succeeded

    Example:
        >>> track_retry_attempt("api_call", 2, False)
        >>> track_retry_attempt("api_call", 3, True)
    """
    metrics.increment("retry_attempts_total", 1, {"operation": operation, "success": str(success)})

    if not success and attempt > 1:
        metrics.increment("retry_failures_total", 1, {"operation": operation})


def track_checkpoint_save(operation_id: str, items_processed: int, duration: float) -> None:
    """
    Track checkpoint save operations.

    Args:
        operation_id: Checkpoint operation ID
        items_processed: Number of items processed
        duration: Time taken to save checkpoint

    Example:
        >>> track_checkpoint_save("bulk_import_20251116", 10000, 0.045)
    """
    attrs = {"operation_id": operation_id}

    metrics.increment("checkpoint_saves_total", 1, attrs)
    metrics.gauge("checkpoint_items_processed", items_processed, attrs)
    metrics.histogram("checkpoint_save_duration_seconds", duration, attrs)


def track_health_check(check_name: str, status: str, duration: float) -> None:
    """
    Track health check results.

    Args:
        check_name: Name of the health check
        status: Check status (healthy, degraded, unhealthy)
        duration: Check duration in seconds

    Example:
        >>> track_health_check("api_connectivity", "healthy", 0.123)
    """
    attrs = {"check": check_name, "status": status}

    metrics.increment("health_check_runs_total", 1, attrs)
    metrics.histogram("health_check_duration_seconds", duration, {"check": check_name})

    if status == "unhealthy":
        metrics.increment("health_check_failures_total", 1, {"check": check_name})
