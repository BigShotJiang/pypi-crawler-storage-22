"""
Health check framework for early failure detection.

Provides a framework to validate system health before starting operations,
including API connectivity, rate limit status, and configuration validation.

Example:
    >>> from regscale.core.resilience import HealthCheck, HealthStatus
    >>> health = HealthCheck()
    >>>
    >>> # Add health checks
    >>> health.add_check("api_connectivity", check_api_connectivity)
    >>> health.add_check("rate_limits", check_rate_limits)
    >>>
    >>> # Run all checks
    >>> results = health.run_all()
    >>> if results["status"] != HealthStatus.HEALTHY:
    ...     print("System unhealthy, aborting operation")
"""

import logging
import time
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("regscale")


class HealthStatus(Enum):
    """Health check status."""

    HEALTHY = "healthy"  # All checks passed
    DEGRADED = "degraded"  # Some checks failed but operation may proceed
    UNHEALTHY = "unhealthy"  # Critical checks failed, should not proceed


class HealthCheckResult:
    """Result from a single health check."""

    def __init__(
        self,
        name: str,
        status: HealthStatus,
        message: str = "",
        details: Optional[Dict[str, Any]] = None,
        duration_seconds: float = 0.0,
    ):
        self.name = name
        self.status = status
        self.message = message
        self.details = details or {}
        self.duration_seconds = duration_seconds
        self.timestamp = time.time()

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "name": self.name,
            "status": self.status.value,
            "message": self.message,
            "details": self.details,
            "duration_seconds": self.duration_seconds,
            "timestamp": self.timestamp,
        }

    def __repr__(self) -> str:
        return f"HealthCheckResult(name={self.name}, status={self.status.value}, message={self.message})"


class HealthCheck:
    """
    Health check framework for validating system health.

    Manages a collection of health checks and provides methods to run them
    individually or all at once.

    Example:
        >>> health = HealthCheck()
        >>> health.add_check("api", lambda: check_api())
        >>> health.add_check("config", lambda: check_config(), critical=True)
        >>> results = health.run_all()
    """

    def __init__(self):
        self.checks: Dict[str, Dict[str, Any]] = {}
        self.last_results: Dict[str, HealthCheckResult] = {}

        logger.debug("HealthCheck framework initialized")

    def add_check(
        self,
        name: str,
        check_func: Callable[[], HealthCheckResult],
        critical: bool = False,
        description: str = "",
    ):
        """
        Register a health check.

        Args:
            name: Unique name for this check
            check_func: Function that returns HealthCheckResult
            critical: Whether failure should mark system as UNHEALTHY
            description: Human-readable description

        Example:
            >>> def check_api():
            ...     try:
            ...         response = requests.get("https://api.example.com/health")
            ...         if response.status_code == 200:
            ...             return HealthCheckResult("api", HealthStatus.HEALTHY, "API is responsive")
            ...         else:
            ...             return HealthCheckResult("api", HealthStatus.UNHEALTHY, f"API returned {response.status_code}")
            ...     except Exception as e:
            ...         return HealthCheckResult("api", HealthStatus.UNHEALTHY, str(e))
            >>>
            >>> health.add_check("api_connectivity", check_api, critical=True)
        """
        self.checks[name] = {
            "func": check_func,
            "critical": critical,
            "description": description,
        }

        logger.debug(
            "Health check registered: name=%s, critical=%s, description=%s",
            name,
            critical,
            description,
        )

    def run_check(self, name: str) -> HealthCheckResult:
        """
        Run a single health check.

        Args:
            name: Name of the check to run

        Returns:
            HealthCheckResult from the check

        Raises:
            KeyError: If check name not found

        Example:
            >>> result = health.run_check("api_connectivity")
            >>> print(f"Status: {result.status}")
        """
        if name not in self.checks:
            raise KeyError(f"Health check '{name}' not found")

        check = self.checks[name]
        start_time = time.time()

        try:
            logger.debug("Running health check: %s", name)
            result = check["func"]()

            # Ensure result is HealthCheckResult
            if not isinstance(result, HealthCheckResult):
                result = HealthCheckResult(
                    name=name,
                    status=HealthStatus.UNHEALTHY,
                    message=f"Check returned invalid type: {type(result)}",
                )

            # Add duration
            result.duration_seconds = time.time() - start_time

            # Store result
            self.last_results[name] = result

            logger.info(
                "Health check completed: name=%s, status=%s, duration=%.2fs",
                name,
                result.status.value,
                result.duration_seconds,
            )

            return result

        except Exception as e:
            duration = time.time() - start_time

            logger.error(
                "Health check failed with exception: name=%s, error=%s",
                name,
                str(e),
                exc_info=True,
            )

            result = HealthCheckResult(
                name=name,
                status=HealthStatus.UNHEALTHY,
                message=f"Check failed with exception: {str(e)}",
                details={"exception_type": type(e).__name__},
                duration_seconds=duration,
            )

            self.last_results[name] = result
            return result

    def run_all(self, stop_on_critical_failure: bool = True) -> Dict[str, Any]:
        """
        Run all registered health checks.

        Args:
            stop_on_critical_failure: Stop running checks if critical check fails

        Returns:
            Dictionary with overall status and individual check results

        Example:
            >>> results = health.run_all()
            >>> print(f"Overall status: {results['status']}")
            >>> for check_result in results['checks']:
            ...     print(f"{check_result['name']}: {check_result['status']}")
        """
        logger.info("Running all health checks (%d checks)", len(self.checks))
        start_time = time.time()

        results: List[HealthCheckResult] = []
        overall_status = HealthStatus.HEALTHY
        critical_failure = False

        for name, check_info in self.checks.items():
            # Skip if already hit critical failure
            if critical_failure and stop_on_critical_failure:
                logger.warning("Skipping check '%s' due to previous critical failure", name)
                continue

            result = self.run_check(name)
            results.append(result)

            # Update overall status
            if result.status == HealthStatus.UNHEALTHY:
                if check_info["critical"]:
                    overall_status = HealthStatus.UNHEALTHY
                    critical_failure = True
                    logger.error("Critical health check failed: %s - %s", name, result.message)
                elif overall_status == HealthStatus.HEALTHY:
                    overall_status = HealthStatus.DEGRADED

            elif result.status == HealthStatus.DEGRADED and overall_status == HealthStatus.HEALTHY:
                overall_status = HealthStatus.DEGRADED

        total_duration = time.time() - start_time

        summary = {
            "status": overall_status.value,
            "total_checks": len(self.checks),
            "checks_run": len(results),
            "healthy_count": sum(1 for r in results if r.status == HealthStatus.HEALTHY),
            "degraded_count": sum(1 for r in results if r.status == HealthStatus.DEGRADED),
            "unhealthy_count": sum(1 for r in results if r.status == HealthStatus.UNHEALTHY),
            "duration_seconds": total_duration,
            "timestamp": time.time(),
            "checks": [r.to_dict() for r in results],
        }

        logger.info(
            "Health check summary: status=%s, healthy=%d, degraded=%d, unhealthy=%d, duration=%.2fs",
            overall_status.value,
            summary["healthy_count"],
            summary["degraded_count"],
            summary["unhealthy_count"],
            total_duration,
        )

        return summary

    def get_last_results(self) -> Dict[str, HealthCheckResult]:
        """
        Get results from the last health check run.

        Returns:
            Dictionary mapping check names to their last results

        Example:
            >>> last_results = health.get_last_results()
            >>> api_result = last_results.get("api_connectivity")
        """
        return self.last_results.copy()

    def clear_results(self):
        """Clear stored health check results."""
        self.last_results.clear()
        logger.debug("Health check results cleared")

    def remove_check(self, name: str) -> bool:
        """
        Remove a health check.

        Args:
            name: Name of check to remove

        Returns:
            True if removed, False if not found

        Example:
            >>> health.remove_check("old_check")
        """
        if name in self.checks:
            del self.checks[name]
            self.last_results.pop(name, None)
            logger.debug("Health check removed: %s", name)
            return True

        return False

    def get_registered_checks(self) -> List[str]:
        """
        Get list of registered check names.

        Returns:
            List of check names

        Example:
            >>> checks = health.get_registered_checks()
            >>> print(f"Registered checks: {', '.join(checks)}")
        """
        return list(self.checks.keys())


# Pre-built health check helpers


def create_api_connectivity_check(
    api_url: str,
    timeout: int = 10,
    expected_status: int = 200,
    use_legacy_requests: Optional[bool] = None,
) -> Callable[[], HealthCheckResult]:
    """
    Create a health check for API connectivity.

    Supports both legacy requests and modern httpx clients.

    Args:
        api_url: URL to check
        timeout: Request timeout in seconds
        expected_status: Expected HTTP status code
        use_legacy_requests: Force use of legacy requests client.
            If None, reads from REGSCALE_USE_LEGACY_REQUESTS env var.

    Returns:
        Function that performs the health check

    Example:
        >>> check = create_api_connectivity_check("https://api.example.com/health")
        >>> health.add_check("api", check, critical=True)
    """
    import os

    # Determine which HTTP client to use
    if use_legacy_requests is None:
        use_legacy_requests = os.getenv("REGSCALE_USE_LEGACY_REQUESTS", "false").lower() == "true"

    def check() -> HealthCheckResult:
        try:
            if use_legacy_requests:
                import requests

                response = requests.get(api_url, timeout=timeout)
                status_code = response.status_code
            else:
                import httpx

                with httpx.Client(timeout=timeout) as client:
                    response = client.get(api_url)
                    status_code = response.status_code

            if status_code == expected_status:
                return HealthCheckResult(
                    name="api_connectivity",
                    status=HealthStatus.HEALTHY,
                    message=f"API responding with status {status_code}",
                    details={"url": api_url, "status_code": status_code},
                )
            else:
                return HealthCheckResult(
                    name="api_connectivity",
                    status=HealthStatus.DEGRADED,
                    message=f"API returned unexpected status {status_code}",
                    details={"url": api_url, "status_code": status_code, "expected": expected_status},
                )

        except Exception as e:
            return HealthCheckResult(
                name="api_connectivity",
                status=HealthStatus.UNHEALTHY,
                message=f"Failed to connect to API: {str(e)}",
                details={"url": api_url, "error": str(e)},
            )

    return check


def create_config_validation_check(
    config: Dict[str, Any],
    required_keys: List[str],
) -> Callable[[], HealthCheckResult]:
    """
    Create a health check for configuration validation.

    Args:
        config: Configuration dictionary to validate
        required_keys: List of required configuration keys

    Returns:
        Function that performs the health check

    Example:
        >>> check = create_config_validation_check(
        ...     config=app.config,
        ...     required_keys=["domain", "token", "maxThreads"]
        ... )
        >>> health.add_check("config", check, critical=True)
    """

    def check() -> HealthCheckResult:
        missing_keys = [key for key in required_keys if key not in config]

        if not missing_keys:
            return HealthCheckResult(
                name="config_validation",
                status=HealthStatus.HEALTHY,
                message="All required configuration keys present",
                details={"required_keys": required_keys},
            )
        else:
            return HealthCheckResult(
                name="config_validation",
                status=HealthStatus.UNHEALTHY,
                message=f"Missing required configuration keys: {', '.join(missing_keys)}",
                details={"missing_keys": missing_keys, "required_keys": required_keys},
            )

    return check
