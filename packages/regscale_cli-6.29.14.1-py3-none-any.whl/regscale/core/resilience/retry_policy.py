"""
Retry policy with exponential backoff and jitter.

Provides standardized retry logic to handle transient failures gracefully.
Uses exponential backoff with randomized jitter to prevent thundering herd problems.

Example:
    >>> from regscale.core.resilience import RetryPolicy
    >>> retry_policy = RetryPolicy(max_attempts=3, base_delay=1.0)
    >>>
    >>> @retry_policy
    ... def unstable_api_call():
    ...     return requests.get("https://api.example.com/data")
    >>>
    >>> result = unstable_api_call()  # Will retry up to 3 times
"""

import logging
import random
import threading
import time
from functools import wraps
from typing import Any, Callable, Optional, Tuple

logger = logging.getLogger("regscale")


class RetryExhaustedError(Exception):
    """Raised when all retry attempts have been exhausted."""

    def __init__(self, attempts: int, last_exception: Exception):
        self.attempts = attempts
        self.last_exception = last_exception
        super().__init__(f"Retry exhausted after {attempts} attempts. Last error: {last_exception}")


class RetryPolicy:
    """
    Retry policy with exponential backoff and jitter.

    Implements a standardized retry strategy with:
    - Exponential backoff: Delay doubles with each retry
    - Jitter: Random delay added to prevent thundering herd
    - Configurable max attempts and delays
    - Support for specific retryable exceptions

    Args:
        max_attempts: Maximum number of attempts (default: 3)
        base_delay: Initial delay in seconds (default: 1.0)
        max_delay: Maximum delay in seconds (default: 30.0)
        exponential_base: Base for exponential backoff (default: 2)
        jitter: Whether to add random jitter (default: True)
        retryable_exceptions: Tuple of exceptions to retry (default: Exception)
        name: Optional name for logging (default: "unnamed")

    Example:
        >>> retry = RetryPolicy(max_attempts=5, base_delay=2.0)
        >>> result = retry.execute(lambda: api.get("/data"))
    """

    def __init__(
        self,
        max_attempts: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 30.0,
        exponential_base: float = 2.0,
        jitter: bool = True,
        retryable_exceptions: Tuple[type, ...] = (Exception,),
        name: Optional[str] = None,
    ):
        self.max_attempts = max_attempts
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base
        self.jitter = jitter
        self.retryable_exceptions = retryable_exceptions
        self.name = name or "unnamed"

        # Thread safety lock for statistics
        self._stats_lock = threading.Lock()

        # Statistics (protected by _stats_lock)
        self.total_attempts = 0
        self.total_retries = 0
        self.total_successes = 0
        self.total_failures = 0

        logger.debug(
            "RetryPolicy initialized: name=%s, max_attempts=%d, base_delay=%.1fs, max_delay=%.1fs",
            self.name,
            max_attempts,
            base_delay,
            max_delay,
        )

    def execute(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute a function with retry logic.

        Args:
            func: Function to execute
            *args: Positional arguments for func
            **kwargs: Keyword arguments for func

        Returns:
            Result from func

        Raises:
            RetryExhaustedError: If all retry attempts fail
            Exception: Any non-retryable exception

        Example:
            >>> result = retry.execute(api.get, "/endpoint")
        """
        last_exception = None

        for attempt in range(1, self.max_attempts + 1):
            with self._stats_lock:
                self.total_attempts += 1

            try:
                # Execute the function
                result = func(*args, **kwargs)

                # Success (thread-safe increment)
                with self._stats_lock:
                    self.total_successes += 1

                if attempt > 1:
                    logger.info(
                        "RetryPolicy '%s' succeeded on attempt %d/%d",
                        self.name,
                        attempt,
                        self.max_attempts,
                    )

                return result

            except self.retryable_exceptions as e:
                last_exception = e

                # Check if we should retry
                if attempt < self.max_attempts:
                    with self._stats_lock:
                        self.total_retries += 1  # Only count actual retries
                    delay = self._calculate_delay(attempt)

                    logger.warning(
                        "RetryPolicy '%s' attempt %d/%d failed: %s. Retrying in %.2fs...",
                        self.name,
                        attempt,
                        self.max_attempts,
                        str(e),
                        delay,
                    )

                    time.sleep(delay)
                else:
                    # No more retries left
                    logger.error(
                        "RetryPolicy '%s' exhausted after %d attempts. Last error: %s",
                        self.name,
                        self.max_attempts,
                        str(e),
                    )

            except Exception as e:
                # Non-retryable exception
                logger.error(
                    "RetryPolicy '%s' encountered non-retryable exception: %s",
                    self.name,
                    str(e),
                    exc_info=True,
                )
                raise

        # All retries exhausted (thread-safe increment)
        with self._stats_lock:
            self.total_failures += 1
        raise RetryExhaustedError(self.max_attempts, last_exception)

    def __call__(self, func: Callable) -> Callable:
        """
        Decorator to wrap a function with retry logic.

        Example:
            >>> @RetryPolicy(max_attempts=3)
            ... def unstable_function():
            ...     return api.call()
        """

        @wraps(func)
        def wrapper(*args, **kwargs):
            return self.execute(func, *args, **kwargs)

        return wrapper

    def _calculate_delay(self, attempt: int) -> float:
        """
        Calculate delay for the given attempt using exponential backoff with jitter.

        Formula: delay = min(base_delay * (exponential_base ^ attempt), max_delay)
        If jitter enabled: delay = delay * random(0.5, 1.5)

        Args:
            attempt: Current attempt number (1-indexed)

        Returns:
            Delay in seconds
        """
        # Exponential backoff
        delay = self.base_delay * (self.exponential_base ** (attempt - 1))

        # Cap at max_delay
        delay = min(delay, self.max_delay)

        # Add jitter (±50% randomization)
        if self.jitter:
            jitter_factor = random.uniform(0.5, 1.5)
            delay = delay * jitter_factor

        return delay

    def get_statistics(self) -> dict:
        """
        Get retry statistics (thread-safe).

        Returns:
            Dictionary with total_attempts, total_retries, total_successes, etc.

        Example:
            >>> stats = retry.get_statistics()
            >>> print(f"Success rate: {stats['success_rate']:.1%}")
        """
        with self._stats_lock:
            success_rate = self.total_successes / self.total_attempts if self.total_attempts > 0 else 0.0

            return {
                "name": self.name,
                "total_attempts": self.total_attempts,
                "total_retries": self.total_retries,
                "total_successes": self.total_successes,
                "total_failures": self.total_failures,
                "success_rate": success_rate,
                "config": {
                    "max_attempts": self.max_attempts,
                    "base_delay": self.base_delay,
                    "max_delay": self.max_delay,
                    "exponential_base": self.exponential_base,
                    "jitter": self.jitter,
                },
            }

    def reset_statistics(self):
        """Reset all statistics counters (thread-safe)."""
        with self._stats_lock:
            self.total_attempts = 0
            self.total_retries = 0
            self.total_successes = 0
            self.total_failures = 0
        logger.debug("RetryPolicy '%s' statistics reset", self.name)
