"""Cleanup module for SSP data management in RegScale CLI."""
