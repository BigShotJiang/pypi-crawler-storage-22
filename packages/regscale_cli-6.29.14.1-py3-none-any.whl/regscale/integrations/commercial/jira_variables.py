#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Jira integration configuration variables."""

from regscale.core.app.utils.variables import RsVariablesMeta, RsVariableType


class JiraVariables(metaclass=RsVariablesMeta):
    """
    Jira Variables class to define configuration attributes with type annotations.

    These variables are loaded from init.yaml and can be overridden by environment variables.
    """

    # Required Jira connection settings
    jiraUrl: RsVariableType(str, "https://your-company.atlassian.net", required=True)  # type: ignore
    jiraApiToken: RsVariableType(str, "", sensitive=True, required=True)  # type: ignore
    jiraUserName: RsVariableType(str, "", required=True)  # type: ignore

    # Optional settings
    jiraDefaultIssueType: RsVariableType(str, "Task", required=False)  # type: ignore
    jiraDefaultPriority: RsVariableType(str, "Medium", required=False)  # type: ignore
