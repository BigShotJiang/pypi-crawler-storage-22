#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pipeline Compliance CLI Commands

CLI interface for the pipeline compliance integration.
"""

import logging
import os
from pathlib import Path
from typing import Optional

import click

from regscale.core.app.utils.app_utils import (
    check_license,
    create_progress_object,
    error_and_exit,
)
from regscale.models import regscale_id

logger = logging.getLogger("regscale")


def resolve_control_id(control_id_or_identifier: str) -> int:
    """
    Resolve a control identifier (like 'RA-5') or numeric ID to a control ID.

    :param str control_id_or_identifier: Control identifier string or numeric ID
    :return: Resolved numeric control ID
    :rtype: int
    :raises click.ClickException: If control cannot be found or multiple matches found
    """
    from regscale.core.app.api import Api

    # If it's already a numeric ID, return it
    try:
        return int(control_id_or_identifier)
    except ValueError:
        pass

    # It's a control identifier (like "RA-5"), look it up via GraphQL
    api = Api()

    # Query for controls matching this identifier
    query = f"""
    query {{
        securityControls(
            where: {{controlId: {{eq: "{control_id_or_identifier}"}}}}
        ) {{
            items {{
                id
                title
                controlId
            }}
        }}
    }}
    """

    response = api.graph(query=query)
    if not response:
        error_and_exit(f"Failed to query for control identifier: {control_id_or_identifier}")

    controls = response.get("securityControls", {}).get("items", [])

    if not controls:
        error_and_exit(
            f"Control identifier '{control_id_or_identifier}' not found in RegScale. "
            "Please verify the control exists in your security plan."
        )

    if len(controls) == 1:
        control_id = controls[0].get("id")
        control_title = controls[0].get("title", "")
        logger.info(f"Resolved '{control_id_or_identifier}' to control ID {control_id}: {control_title}")
        return control_id

    # Multiple controls found - list them and ask user to specify numeric ID
    click.echo(f"\nWARNING: Multiple controls found for identifier '{control_id_or_identifier}':")
    click.echo("")
    for ctrl in controls:
        click.echo(f"  - ID {ctrl.get('id')}: {ctrl.get('title', 'N/A')}")
    click.echo("")
    error_and_exit(f"Please specify the numeric control ID instead of '{control_id_or_identifier}' to avoid ambiguity.")


def _detect_provider(provider: str) -> str:
    """Auto-detect CI/CD provider from environment variables."""
    if provider != "auto":
        return provider

    if os.environ.get("CI_PROJECT_ID"):
        return "gitlab"
    elif os.environ.get("GITHUB_REPOSITORY"):
        return "github"
    else:
        error_and_exit("Could not auto-detect CI/CD provider. Please specify --provider gitlab or --provider github")


def _get_provider_kwargs(provider: str, token: Optional[str]) -> dict:
    """Get provider-specific keyword arguments."""
    if provider == "gitlab":
        return {
            "gitlab_url": os.environ.get("CI_SERVER_URL", "https://gitlab.com"),
            "token": token or os.environ.get("GITLAB_API_TOKEN", ""),
        }
    elif provider == "github":
        return {"token": token or os.environ.get("GITHUB_TOKEN", "")}
    return {}


def _enrich_context(
    context,
    project_id: Optional[str],
    project_name: Optional[str],
    pipeline_provider,
    token: Optional[str],
):
    """Enrich pipeline context with CLI options and API data."""
    if project_id:
        context.project_id = project_id
    if project_name:
        context.project_name = project_name

    if not context.project_id:
        error_and_exit("Project ID is required. Use --project-id or set CI environment variables.")

    if not context.project_name:
        if token or pipeline_provider.token:
            project_info = pipeline_provider.get_project_info(context.project_id)
            context.project_name = project_info.get("name") or project_info.get("full_name", context.project_id)
        else:
            context.project_name = context.project_id

    return context


def _parse_scan_result(
    scan_file: Optional[Path],
    scan_type: str,
    scan_passed: Optional[bool],
    scan_failed: Optional[bool],
    pipeline_provider_class,
    scan_result_class,
):
    """Parse scan results from file or manual specification."""
    if scan_file:
        return pipeline_provider_class.parse_scan_file(scan_file, scan_type)

    if scan_passed is None and scan_failed is None:
        error_and_exit("Either --scan-file or --scan-passed/--scan-failed must be specified")

    passed = scan_passed if scan_passed is not None else not scan_failed
    return scan_result_class(passed=passed, scan_type=scan_type, findings_count=0, scan_tool="Manual")


def _apply_manual_overrides(scan_result, scan_passed: Optional[bool], scan_failed: Optional[bool]):
    """Apply manual scan result overrides."""
    if scan_passed is not None:
        scan_result.passed = True
    elif scan_failed is not None:
        scan_result.passed = False
    return scan_result


def _print_scan_results(provider: str, context, result: dict, scan_result):
    """Print scan results to console."""
    click.echo("\n" + "=" * 60)
    click.echo("Pipeline Compliance Report Complete")
    click.echo("=" * 60)
    click.echo(f"Provider:           {provider.upper()}")
    click.echo(f"Repository:         {context.project_name}")
    click.echo(f"Branch:             {context.branch or 'N/A'}")
    click.echo(f"Commit:             {context.commit_sha[:8] if context.commit_sha else 'N/A'}")
    click.echo("-" * 60)
    click.echo(f"Component ID:       {result['component_id']}")
    click.echo(f"Control Impl ID:    {result['control_impl_id']}")
    click.echo(f"Assessment ID:      {result['assessment_id']}")
    click.echo(f"Control Status:     {result['control_status']}")
    click.echo(f"Issues Created:     {result['issues_created']}")
    click.echo("-" * 60)
    status_emoji = "PASS" if scan_result.passed else "FAIL"
    click.echo(f"Scan Result:        {status_emoji}")
    click.echo(f"Scan Type:          {scan_result.scan_type}")
    click.echo(f"Findings:           {scan_result.findings_count}")
    click.echo(f"  Critical:         {scan_result.critical_count}")
    click.echo(f"  High:             {scan_result.high_count}")
    click.echo(f"  Medium:           {scan_result.medium_count}")
    click.echo(f"  Low:              {scan_result.low_count}")
    click.echo("=" * 60)


@click.group(name="pipeline")
def pipeline():
    """
    CI/CD Pipeline Compliance Integration.

    Track component-level compliance from GitLab and GitHub pipelines.
    Solves the "Last-In-Wins" problem when multiple repos update a single SSP.
    """
    pass


@pipeline.command(name="report_scan")
@regscale_id()
@click.option(
    "--provider",
    "-p",
    type=click.Choice(["gitlab", "github", "auto"]),
    default="auto",
    help="CI/CD provider (auto-detects from environment)",
)
@click.option(
    "--project-id",
    "-pid",
    type=str,
    default=None,
    help="Project/repository ID (auto-detects from environment)",
)
@click.option(
    "--project-name",
    "-pn",
    type=str,
    default=None,
    help="Project/repository name (auto-detects from environment)",
)
@click.option(
    "--control-id",
    "-cid",
    type=str,
    required=True,
    help="Security control ID or identifier (e.g., 'RA-5' or numeric ID 315)",
)
@click.option(
    "--scan-file",
    "-f",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Path to scan results file (JSON: SARIF, GitLab SAST, Trivy)",
)
@click.option(
    "--scan-type",
    "-t",
    type=click.Choice(["container", "sast", "dast", "dependency", "infrastructure", "secret"]),
    default="container",
    help="Type of security scan",
)
@click.option(
    "--scan-passed",
    "-sp",
    is_flag=True,
    default=None,
    help="Manually indicate scan passed (overrides file parsing)",
)
@click.option(
    "--scan-failed",
    "-sf",
    is_flag=True,
    default=None,
    help="Manually indicate scan failed (overrides file parsing)",
)
@click.option(
    "--create-issues/--no-create-issues",
    default=True,
    help="Create issues from findings (default: yes)",
)
@click.option(
    "--compliance-settings-id",
    "-csid",
    type=int,
    default=1,
    help="Compliance settings ID (default: 1)",
)
@click.option(
    "--token",
    "-tk",
    type=str,
    default=None,
    help="API token for provider (defaults to environment variable)",
)
def report_scan(
    regscale_id: int,
    provider: str,
    project_id: Optional[str],
    project_name: Optional[str],
    control_id: str,
    scan_file: Optional[Path],
    scan_type: str,
    scan_passed: Optional[bool],
    scan_failed: Optional[bool],
    create_issues: bool,
    compliance_settings_id: int,
    token: Optional[str],
):
    """
    Report a pipeline scan result to RegScale.

    Creates/updates a component for the repository, creates an assessment,
    and updates the control implementation status at the component level.

    Example:
        regscale pipeline report_scan --regscale_id 123 --control-id RA-5 -f scan-results.json
        regscale pipeline report_scan --regscale_id 123 --control-id 315 -f scan-results.json

    Environment variables (auto-detected):
        GitLab: CI_PROJECT_ID, CI_PROJECT_NAME, CI_COMMIT_SHA, etc.
        GitHub: GITHUB_REPOSITORY, GITHUB_SHA, GITHUB_RUN_ID, etc.
    """
    from regscale.integrations.commercial.pipeline_compliance.providers import (
        PipelineProvider,
        get_provider,
    )
    from regscale.integrations.commercial.pipeline_compliance.service import (
        PipelineComplianceService,
        ScanResult,
    )

    check_license()

    # Resolve control ID (supports both "RA-5" and numeric IDs like "315")
    resolved_control_id = resolve_control_id(control_id)

    # Auto-detect and setup provider
    provider = _detect_provider(provider)
    provider_kwargs = _get_provider_kwargs(provider, token)
    pipeline_provider = get_provider(provider, **provider_kwargs)

    # Get and enrich context
    context = pipeline_provider.get_context()
    context = _enrich_context(context, project_id, project_name, pipeline_provider, token)

    # Parse scan results
    scan_result = _parse_scan_result(scan_file, scan_type, scan_passed, scan_failed, PipelineProvider, ScanResult)
    scan_result = _apply_manual_overrides(scan_result, scan_passed, scan_failed)

    # Create service and report scan
    service = PipelineComplianceService(
        ssp_id=regscale_id,
        compliance_settings_id=compliance_settings_id,
    )

    with create_progress_object() as progress:
        task = progress.add_task("[#f8b737]Reporting scan to RegScale...", total=5)

        result = service.report_scan(
            pipeline_context=context,
            scan_result=scan_result,
            control_id=resolved_control_id,
            create_issues=create_issues,
        )

        progress.update(task, completed=5)

    # Output results
    _print_scan_results(provider, context, result, scan_result)


@pipeline.command(name="setup_component")
@regscale_id()
@click.option(
    "--project-id",
    "-pid",
    type=str,
    required=True,
    help="Project/repository ID",
)
@click.option(
    "--project-name",
    "-pn",
    type=str,
    required=True,
    help="Project/repository name",
)
@click.option(
    "--description",
    "-d",
    type=str,
    default=None,
    help="Component description",
)
@click.option(
    "--component-type",
    "-ct",
    type=click.Choice(["Software", "Hardware", "Service", "Policy", "Process", "Procedure"]),
    default="Software",
    help="Component type",
)
@click.option(
    "--compliance-settings-id",
    "-csid",
    type=int,
    default=1,
    help="Compliance settings ID",
)
def setup_component(
    regscale_id: int,
    project_id: str,
    project_name: str,
    description: Optional[str],
    component_type: str,
    compliance_settings_id: int,
):
    """
    Create or get a component for a repository.

    Use this command to pre-create components before running pipelines,
    or to verify component setup.

    Example:
        regscale pipeline setup_component --regscale_id 123 --project-id 456 --project-name my-repo
    """
    from regscale.integrations.commercial.pipeline_compliance.service import (
        PipelineComplianceService,
    )

    check_license()

    service = PipelineComplianceService(
        ssp_id=regscale_id,
        compliance_settings_id=compliance_settings_id,
    )

    component = service.get_or_create_component(
        project_id=project_id,
        project_name=project_name,
        description=description,
        component_type=component_type,
    )

    click.echo("\n" + "=" * 60)
    click.echo("Component Setup Complete")
    click.echo("=" * 60)
    click.echo(f"Component ID:       {component.id}")
    click.echo(f"Title:              {component.title}")
    click.echo(f"External ID:        {component.externalId}")
    click.echo(f"Type:               {component.componentType}")
    click.echo(f"Status:             {component.status}")
    click.echo(f"SSP ID:             {component.securityPlansId}")
    click.echo("=" * 60)


@pipeline.command(name="list_components")
@regscale_id()
def list_components(regscale_id: int):
    """
    List all components for an SSP.

    Example:
        regscale pipeline list_components --regscale_id 123
    """
    from regscale.core.app.application import Application
    from regscale.models.regscale_models.component import Component

    check_license()
    app = Application()

    components = Component.get_components_from_ssp(app, regscale_id)

    click.echo("\n" + "=" * 80)
    click.echo(f"Components for SSP {regscale_id}")
    click.echo("=" * 80)
    click.echo(f"{'ID':<8} {'Title':<30} {'External ID':<20} {'Status':<15}")
    click.echo("-" * 80)

    for comp in components:
        click.echo(
            f"{comp.get('id', ''):<8} "
            f"{comp.get('title', '')[:28]:<30} "
            f"{(comp.get('externalId') or '')[:18]:<20} "
            f"{comp.get('status', ''):<15}"
        )

    click.echo("-" * 80)
    click.echo(f"Total: {len(components)} components")
    click.echo("=" * 80)


@pipeline.command(name="get_assessments")
@regscale_id()
@click.option(
    "--project-id",
    "-pid",
    type=str,
    default=None,
    help="Filter by project/repository ID (automationId)",
)
@click.option(
    "--limit",
    "-l",
    type=int,
    default=10,
    help="Maximum number of assessments to return",
)
def get_assessments(regscale_id: int, project_id: Optional[str], limit: int):
    """
    Get assessments for an SSP, optionally filtered by repository.

    Example:
        regscale pipeline get_assessments --regscale_id 123 --project-id gitlab-456
    """
    from regscale.core.app.api import Api

    check_license()
    api = Api()

    # Build GraphQL query
    filters = [f"securityPlanId: {{eq: {regscale_id}}}"]
    if project_id:
        filters.append(f'automationId: {{eq: "{project_id}"}}')

    query = f"""
    query {{
        assessments(
            skip: 0,
            take: {limit},
            where: {{{", ".join(filters)}}},
            order: {{dateCreated: DESC}}
        ) {{
            items {{
                id
                title
                status
                assessmentResult
                automationId
                componentId
                dateCreated
            }}
            totalCount
        }}
    }}
    """

    response = api.graph(query=query)
    if not response:
        error_and_exit("Failed to fetch assessments")

    # api.graph returns a dict directly
    assessments = response.get("assessments", {}).get("items", [])
    total = response.get("assessments", {}).get("totalCount", 0)

    click.echo("\n" + "=" * 100)
    click.echo(f"Assessments for SSP {regscale_id}" + (f" (Project: {project_id})" if project_id else ""))
    click.echo("=" * 100)
    click.echo(f"{'ID':<8} {'Title':<35} {'Result':<12} {'Project ID':<15} {'Created':<20}")
    click.echo("-" * 100)

    for assess in assessments:
        click.echo(
            f"{assess.get('id', ''):<8} "
            f"{assess.get('title', '')[:33]:<35} "
            f"{assess.get('assessmentResult', 'N/A'):<12} "
            f"{(assess.get('automationId') or 'N/A')[:13]:<15} "
            f"{assess.get('dateCreated', '')[:19]:<20}"
        )

    click.echo("-" * 100)
    click.echo(f"Showing {len(assessments)} of {total} assessments")
    click.echo("=" * 100)
