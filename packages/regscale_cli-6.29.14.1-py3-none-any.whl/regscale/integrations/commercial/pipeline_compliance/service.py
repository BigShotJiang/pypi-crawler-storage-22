#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pipeline Compliance Service

Core business logic for component-level compliance tracking in CI/CD pipelines.
"""

import json
import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from regscale.core.app.api import Api
from regscale.core.app.application import Application
from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.models.regscale_models.assessment import Assessment
from regscale.models.regscale_models.component import (
    Component,
    ComponentStatus,
)
from regscale.models.regscale_models.control_implementation import ControlImplementation
from regscale.models.regscale_models.issue import Issue

logger = logging.getLogger("regscale")

# Control implementation status constants
STATUS_NOT_IMPLEMENTED = "Not Implemented"
STATUS_IN_REMEDIATION = "In Remediation"
STATUS_PARTIALLY_IMPLEMENTED = "Partially Implemented"
STATUS_IMPLEMENTED = "Implemented"


@dataclass
class ScanResult:
    """Represents the result of a security scan from a CI/CD pipeline."""

    passed: bool
    scan_type: str  # e.g., "container", "sast", "dast", "dependency"
    findings_count: int = 0
    critical_count: int = 0
    high_count: int = 0
    medium_count: int = 0
    low_count: int = 0
    scan_tool: str = "Unknown"
    raw_output: Optional[str] = None
    findings: Optional[List[Dict[str, Any]]] = None

    def to_metadata(self) -> Dict[str, Any]:
        """Convert scan result to metadata dictionary."""
        return {
            "passed": self.passed,
            "scan_type": self.scan_type,
            "findings_count": self.findings_count,
            "critical_count": self.critical_count,
            "high_count": self.high_count,
            "medium_count": self.medium_count,
            "low_count": self.low_count,
            "scan_tool": self.scan_tool,
        }


@dataclass
class PipelineContext:
    """Context information from the CI/CD pipeline."""

    provider: str  # "gitlab" or "github"
    project_id: str
    project_name: str
    repository_url: Optional[str] = None
    branch: Optional[str] = None
    commit_sha: Optional[str] = None
    pipeline_id: Optional[str] = None
    pipeline_url: Optional[str] = None
    triggered_by: Optional[str] = None

    def to_metadata(self) -> Dict[str, Any]:
        """Convert pipeline context to metadata dictionary."""
        return {
            "provider": self.provider,
            "project_id": self.project_id,
            "project_name": self.project_name,
            "repository_url": self.repository_url,
            "branch": self.branch,
            "commit_sha": self.commit_sha,
            "pipeline_id": self.pipeline_id,
            "pipeline_url": self.pipeline_url,
            "triggered_by": self.triggered_by,
        }


class PipelineComplianceService:
    """
    Service for managing component-level compliance from CI/CD pipelines.

    This service solves the "Last-In-Wins" problem by:
    1. Creating a Component for each repository
    2. Tracking control implementation status at the component level
    3. Creating assessments for each pipeline scan
    4. Tagging assessments with repository information for filtering
    """

    def __init__(self, ssp_id: int, compliance_settings_id: int = 1):
        """
        Initialize the service.

        :param int ssp_id: The Security Plan (SSP) ID
        :param int compliance_settings_id: The compliance settings ID, defaults to 1
        """
        self.app = Application()
        self.api = Api()
        self.ssp_id = ssp_id
        self.compliance_settings_id = compliance_settings_id
        self._component_cache: Dict[str, Component] = {}

    def get_or_create_component(
        self,
        project_id: str,
        project_name: str,
        description: Optional[str] = None,
        component_type: str = "Software",
    ) -> Component:
        """
        Get existing component for repository or create a new one.

        :param str project_id: Unique project identifier (e.g., GitLab project ID)
        :param str project_name: Human-readable project name
        :param Optional[str] description: Component description
        :param str component_type: Type of component, defaults to "Software"
        :return: The Component object
        :rtype: Component
        """
        # Check cache first
        cache_key = f"{self.ssp_id}:{project_id}"
        if cache_key in self._component_cache:
            logger.debug("Component found in cache: %s", project_name)
            return self._component_cache[cache_key]

        # Try to find existing component by external ID
        existing = self._find_component_by_external_id(project_id)
        if existing:
            self._component_cache[cache_key] = existing
            logger.info("Found existing component: %s (ID: %d)", existing.title, existing.id)
            return existing

        # Try to find by title within SSP
        existing = self._find_component_by_title(project_name)
        if existing:
            # Update external ID if not set
            if not existing.externalId:
                existing.externalId = project_id
                existing.save()
            self._component_cache[cache_key] = existing
            logger.info(
                "Found existing component by title: %s (ID: %d)",
                existing.title,
                existing.id,
            )
            return existing

        # Create new component
        component = Component(
            title=project_name,
            description=description or f"Repository component for {project_name}",
            componentType=component_type,
            status=ComponentStatus.Active.value,
            securityPlansId=self.ssp_id,
            complianceSettingsId=self.compliance_settings_id,
            externalId=project_id,
            isPublic=True,
        )

        created = component.create()
        if created:
            self._component_cache[cache_key] = created
            logger.info("Created new component: %s (ID: %d)", created.title, created.id)
            return created
        else:
            logger.error("Failed to create component: %s", project_name)
            raise RuntimeError(f"Failed to create component for {project_name}")

    def _find_component_by_external_id(self, external_id: str) -> Optional[Component]:
        """Find a component by its external ID."""
        try:
            url = f"{self.app.config['domain']}/api/components/findByExternalId/{external_id}"
            response = self.api.get(url=url)
            if response and response.ok:
                data = response.json()
                if data and data.get("id"):
                    return Component(**data)
        except Exception as ex:
            logger.debug("Error finding component by external ID: %s", ex)
        return None

    def _find_component_by_title(self, title: str) -> Optional[Component]:
        """Find a component by title within the SSP."""
        try:
            components = Component.get_components_from_ssp(self.app, self.ssp_id)
            for comp_data in components:
                if comp_data.get("title") == title:
                    return Component(**comp_data)
        except Exception as ex:
            logger.debug("Error finding component by title: %s", ex)
        return None

    def get_or_create_control_implementation(
        self,
        component_id: int,
        control_id: int,
        initial_status: str = STATUS_NOT_IMPLEMENTED,
    ) -> ControlImplementation:
        """
        Get or create a control implementation for a component.

        :param int component_id: The component ID
        :param int control_id: The security control ID
        :param str initial_status: Initial status if creating, defaults to "Not Implemented"
        :return: The ControlImplementation object
        :rtype: ControlImplementation
        """
        # Try to find existing
        existing = self._find_control_implementation(component_id, control_id)
        if existing:
            logger.debug("Found existing control implementation: %d", existing.id)
            return existing

        # Create new
        control_impl = ControlImplementation(
            controlID=control_id,
            parentId=component_id,
            parentModule="components",
            status=initial_status,
            implementation="Tracked via CI/CD pipeline compliance integration",
        )

        created = control_impl.create()
        if created:
            logger.info(
                "Created control implementation for component %d, control %d",
                component_id,
                control_id,
            )
            return created
        else:
            raise RuntimeError(f"Failed to create control implementation for component {component_id}")

    def _find_control_implementation(self, component_id: int, control_id: int) -> Optional[ControlImplementation]:
        """Find existing control implementation for component."""
        try:
            url = f"{self.app.config['domain']}/api/controlImplementation/getAllByComponent/{component_id}"
            response = self.api.get(url=url)
            if response and response.ok:
                implementations = response.json()
                for impl in implementations:
                    if impl.get("controlID") == control_id:
                        return ControlImplementation(**impl)
        except Exception as ex:
            logger.debug("Error finding control implementation: %s", ex)
        return None

    def create_assessment(
        self,
        component: Component,
        control_impl: ControlImplementation,
        pipeline_context: PipelineContext,
        scan_result: ScanResult,
    ) -> Assessment:
        """
        Create a Lightning Assessment for a pipeline scan.

        :param Component component: The component being assessed
        :param ControlImplementation control_impl: The control implementation
        :param PipelineContext pipeline_context: Pipeline context information
        :param ScanResult scan_result: The scan result
        :return: The created Assessment
        :rtype: Assessment
        """
        # Determine assessment result
        if scan_result.passed:
            assessment_result = "Pass"
        elif scan_result.critical_count > 0 or scan_result.high_count > 0:
            assessment_result = "Fail"
        else:
            assessment_result = "Partial Pass"

        # Build metadata
        metadata = {
            **pipeline_context.to_metadata(),
            **scan_result.to_metadata(),
            "assessed_at": get_current_datetime(),
        }

        # Create assessment - build kwargs dynamically to use default factory for leadAssessorId if needed
        assessment_kwargs: Dict[str, Any] = {
            "title": f"{scan_result.scan_type.title()} Scan - {component.title}",
            "componentId": component.id,
            "securityPlanId": self.ssp_id,
            "parentId": control_impl.id,
            "parentModule": "controls",
            "status": "Complete",
            "assessmentResult": assessment_result,
            "assessmentType": "QA Surveillance",
            "automationId": pipeline_context.project_id,  # For filtering by repo
            "plannedStart": get_current_datetime(),
            "plannedFinish": get_current_datetime(),
            "actualFinish": get_current_datetime(),
            "assessmentReport": self._build_assessment_report(pipeline_context, scan_result),
            "metadata": json.dumps(metadata),
        }

        user_id = self.app.config.get("userId")
        if user_id:
            assessment_kwargs["leadAssessorId"] = str(user_id)

        assessment = Assessment(**assessment_kwargs)

        created = assessment.create()
        if created:
            logger.info(
                "Created assessment for %s: %s (Result: %s)",
                component.title,
                scan_result.scan_type,
                assessment_result,
            )
            return created
        else:
            raise RuntimeError(f"Failed to create assessment for {component.title}")

    def _build_assessment_report(self, context: PipelineContext, result: ScanResult) -> str:
        """Build HTML assessment report."""
        status_color = "green" if result.passed else "red"
        status_text = "PASSED" if result.passed else "FAILED"

        report = f"""
        <h2>Pipeline Compliance Assessment</h2>
        <table border="1" style="border-collapse: collapse; width: 100%;">
            <tr>
                <th style="padding: 8px; text-align: left;">Field</th>
                <th style="padding: 8px; text-align: left;">Value</th>
            </tr>
            <tr>
                <td style="padding: 8px;">Status</td>
                <td style="padding: 8px; color: {status_color}; font-weight: bold;">{status_text}</td>
            </tr>
            <tr>
                <td style="padding: 8px;">Scan Type</td>
                <td style="padding: 8px;">{result.scan_type}</td>
            </tr>
            <tr>
                <td style="padding: 8px;">Scan Tool</td>
                <td style="padding: 8px;">{result.scan_tool}</td>
            </tr>
            <tr>
                <td style="padding: 8px;">Repository</td>
                <td style="padding: 8px;">{context.project_name}</td>
            </tr>
            <tr>
                <td style="padding: 8px;">Branch</td>
                <td style="padding: 8px;">{context.branch or "N/A"}</td>
            </tr>
            <tr>
                <td style="padding: 8px;">Commit</td>
                <td style="padding: 8px;">{context.commit_sha or "N/A"}</td>
            </tr>
            <tr>
                <td style="padding: 8px;">Pipeline</td>
                <td style="padding: 8px;">{context.pipeline_id or "N/A"}</td>
            </tr>
        </table>
        <h3>Findings Summary</h3>
        <table border="1" style="border-collapse: collapse; width: 50%;">
            <tr>
                <th style="padding: 8px;">Severity</th>
                <th style="padding: 8px;">Count</th>
            </tr>
            <tr>
                <td style="padding: 8px; color: darkred;">Critical</td>
                <td style="padding: 8px;">{result.critical_count}</td>
            </tr>
            <tr>
                <td style="padding: 8px; color: red;">High</td>
                <td style="padding: 8px;">{result.high_count}</td>
            </tr>
            <tr>
                <td style="padding: 8px; color: orange;">Medium</td>
                <td style="padding: 8px;">{result.medium_count}</td>
            </tr>
            <tr>
                <td style="padding: 8px; color: gold;">Low</td>
                <td style="padding: 8px;">{result.low_count}</td>
            </tr>
            <tr>
                <td style="padding: 8px; font-weight: bold;">Total</td>
                <td style="padding: 8px; font-weight: bold;">{result.findings_count}</td>
            </tr>
        </table>
        """
        return report

    def update_control_status(
        self,
        control_impl: ControlImplementation,
        scan_result: ScanResult,
    ) -> ControlImplementation:
        """
        Update control implementation status based on scan result.

        :param ControlImplementation control_impl: The control implementation to update
        :param ScanResult scan_result: The scan result
        :return: Updated ControlImplementation
        :rtype: ControlImplementation
        """
        # Determine new status
        if scan_result.passed:
            new_status = STATUS_IMPLEMENTED
            assessment_result = "Pass"
        elif scan_result.critical_count > 0 or scan_result.high_count > 0:
            new_status = STATUS_IN_REMEDIATION
            assessment_result = "Fail"
        else:
            new_status = STATUS_PARTIALLY_IMPLEMENTED
            assessment_result = "Partial Pass"

        # Update the control implementation
        control_impl.status = new_status
        control_impl.dateLastAssessed = get_current_datetime()
        control_impl.lastAssessmentResult = assessment_result

        updated = control_impl.save()
        if updated:
            logger.info("Updated control status to: %s", new_status)
        else:
            logger.error("Failed to update control status")

        return control_impl

    def update_ssp_control_status(self, control_id: int) -> None:
        """
        Update SSP-level control status by aggregating component-level statuses.

        Uses "worst case wins" logic:
        - If any component is "In Remediation", SSP status is "In Remediation"
        - If any component is "Partially Implemented" (and none are "In Remediation"), SSP is "Partially Implemented"
        - Only if ALL components are "Implemented" is SSP status "Implemented"

        :param int control_id: The control ID to update at SSP level
        """
        # Get all component-level control implementations for this control
        component_statuses = self._get_component_control_statuses(control_id)

        if not component_statuses:
            logger.debug(
                "No component statuses found for control %d, skipping SSP update",
                control_id,
            )
            return

        # Aggregate using "worst case wins"
        aggregated_status = self._aggregate_control_statuses(component_statuses)

        # Get or create SSP-level control implementation
        ssp_control_impl = self._get_or_create_ssp_control_implementation(control_id)

        # Update SSP-level status
        ssp_control_impl.status = aggregated_status
        ssp_control_impl.dateLastAssessed = get_current_datetime()

        updated = ssp_control_impl.save()
        if updated:
            logger.info(
                "Updated SSP-level control %d status to: %s (aggregated from %d components)",
                control_id,
                aggregated_status,
                len(component_statuses),
            )
        else:
            logger.error("Failed to update SSP-level control status")

    def _get_component_control_statuses(self, control_id: int) -> List[str]:
        """Get all component-level control statuses for a given control using GraphQL."""
        try:
            # Use GraphQL to query component-level control implementations
            # Note: We can't filter by securityPlanId in GraphQL, so we'll filter by parentModule
            # and then verify components belong to this SSP
            query = f"""
            query {{
                controlImplementations(
                    where: {{
                        controlID: {{eq: {control_id}}},
                        parentModule: {{eq: "components"}}
                    }}
                ) {{
                    items {{
                        id
                        status
                        parentId
                    }}
                }}
            }}
            """

            response = self.api.graph(query=query)
            if not response:
                logger.warning("No response from GraphQL query for component control statuses")
                return []

            implementations = response.get("controlImplementations", {}).get("items", [])

            # Get component IDs for this SSP
            components = Component.get_components_from_ssp(self.app, self.ssp_id)
            ssp_component_ids = {comp.get("id") for comp in components if comp.get("id")}

            # Filter implementations to only include those from components in this SSP
            statuses = [
                impl.get("status")
                for impl in implementations
                if impl.get("status") and impl.get("parentId") in ssp_component_ids
            ]

            logger.debug(
                "Found %d component-level control implementations for control %d in SSP %d",
                len(statuses),
                control_id,
                self.ssp_id,
            )
            return statuses

        except Exception as ex:
            logger.error("Error getting component control statuses: %s", ex)
            return []

    def _aggregate_control_statuses(self, statuses: List[str]) -> str:
        """
        Aggregate control statuses using "worst case wins" logic.

        Priority (worst to best):
        1. In Remediation
        2. Partially Implemented
        3. Implemented
        """
        if not statuses:
            return STATUS_NOT_IMPLEMENTED

        # Worst case wins
        if STATUS_IN_REMEDIATION in statuses:
            return STATUS_IN_REMEDIATION
        elif STATUS_PARTIALLY_IMPLEMENTED in statuses:
            return STATUS_PARTIALLY_IMPLEMENTED
        elif all(s == STATUS_IMPLEMENTED for s in statuses):
            return STATUS_IMPLEMENTED
        else:
            # Mixed statuses or unknown - default to partially implemented
            return STATUS_PARTIALLY_IMPLEMENTED

    def _get_or_create_ssp_control_implementation(self, control_id: int) -> ControlImplementation:
        """Get or create SSP-level control implementation using GraphQL."""
        # Try to find existing SSP-level control implementation
        try:
            query = f"""
            query {{
                controlImplementations(
                    where: {{
                        controlID: {{eq: {control_id}}},
                        parentModule: {{eq: "securityplans"}},
                        parentId: {{eq: {self.ssp_id}}}
                    }},
                    take: 1
                ) {{
                    items {{
                        id
                        controlID
                        parentId
                        parentModule
                        status
                        implementation
                        dateLastAssessed
                    }}
                }}
            }}
            """

            response = self.api.graph(query=query)
            if response:
                implementations = response.get("controlImplementations", {}).get("items", [])
                if implementations and len(implementations) > 0:
                    logger.debug("Found existing SSP-level control implementation")
                    return ControlImplementation(**implementations[0])
        except Exception as ex:
            logger.debug("Error finding SSP-level control implementation: %s", ex)

        # Create new SSP-level control implementation
        logger.info("Creating new SSP-level control implementation for control %d", control_id)
        control_impl = ControlImplementation(
            controlID=control_id,
            parentId=self.ssp_id,
            parentModule="securityplans",
            status="Not Implemented",
            implementation="Aggregated from component-level pipeline compliance",
            securityPlanId=self.ssp_id,
        )

        created = control_impl.create()
        if created:
            logger.info("Created SSP-level control implementation: %d", created.id)
            return created
        else:
            raise RuntimeError(f"Failed to create SSP-level control implementation for control {control_id}")

    def create_issues_from_findings(
        self,
        component: Component,
        assessment: Assessment,
        scan_result: ScanResult,
    ) -> List[Issue]:
        """
        Create issues from scan findings.

        :param Component component: The component
        :param Assessment assessment: The parent assessment
        :param ScanResult scan_result: Scan result with findings
        :return: List of created issues
        :rtype: List[Issue]
        """
        created_issues: List[Issue] = []

        if not scan_result.findings:
            return created_issues

        for finding in scan_result.findings:
            severity = finding.get("severity", "Medium")
            issue = Issue(
                title=finding.get("title", f"{scan_result.scan_type} Finding"),
                description=finding.get("description", ""),
                severityLevel=Issue.assign_severity(severity),
                status="Open",
                identification=f"{scan_result.scan_type} scan",
                parentId=assessment.id,
                parentModule="assessments",
                assessmentId=assessment.id,
                componentId=component.id,
                securityPlanId=self.ssp_id,
                sourceReport=scan_result.scan_tool,
                otherIdentifier=finding.get("id", ""),
            )

            if issue.create_or_update(bulk_create=True, bulk_update=True):
                created_issues.append(issue)

        Issue.bulk_save()
        logger.info("Created %d issues from findings", len(created_issues))
        return created_issues

    def report_scan(
        self,
        pipeline_context: PipelineContext,
        scan_result: ScanResult,
        control_id: int,
        create_issues: bool = True,
    ) -> Dict[str, Any]:
        """
        Report a pipeline scan result to RegScale.

        This is the main entry point for pipeline integrations.

        :param PipelineContext pipeline_context: Pipeline context information
        :param ScanResult scan_result: The scan result
        :param int control_id: The security control ID to update
        :param bool create_issues: Whether to create issues from findings
        :return: Summary of actions taken
        :rtype: Dict[str, Any]
        """
        result: Dict[str, Any] = {
            "component_id": None,
            "control_impl_id": None,
            "assessment_id": None,
            "control_status": None,
            "issues_created": 0,
        }

        # Step 1: Get or create component
        component = self.get_or_create_component(
            project_id=pipeline_context.project_id,
            project_name=pipeline_context.project_name,
            description=f"Repository: {pipeline_context.repository_url or pipeline_context.project_name}",
        )
        result["component_id"] = component.id

        # Step 2: Get or create control implementation
        control_impl = self.get_or_create_control_implementation(
            component_id=component.id,
            control_id=control_id,
        )
        result["control_impl_id"] = control_impl.id

        # Step 3: Create assessment
        assessment = self.create_assessment(
            component=component,
            control_impl=control_impl,
            pipeline_context=pipeline_context,
            scan_result=scan_result,
        )
        result["assessment_id"] = assessment.id

        # Step 4: Update control status
        control_impl = self.update_control_status(
            control_impl=control_impl,
            scan_result=scan_result,
        )
        result["control_status"] = control_impl.status

        # Step 4.5: Update SSP-level control status (aggregate from components)
        self.update_ssp_control_status(control_id=control_id)

        # Step 5: Create issues from findings (optional)
        if create_issues and scan_result.findings:
            issues = self.create_issues_from_findings(
                component=component,
                assessment=assessment,
                scan_result=scan_result,
            )
            result["issues_created"] = len(issues)

        return result
