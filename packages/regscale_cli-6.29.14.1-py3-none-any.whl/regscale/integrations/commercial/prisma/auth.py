#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prisma Cloud Authentication and Session Management

This module provides authentication and session token management for Prisma Cloud Compute API.
Session tokens are cached locally with 24-hour TTL to reduce authentication overhead.
"""

import hashlib
import json
import logging
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Optional

import requests

logger = logging.getLogger("regscale")


class PrismaSessionManager:
    """Manages Prisma Cloud authentication tokens with local caching and automatic expiration."""

    def __init__(self, cache_dir: Optional[str] = None):
        """
        Initialize the Prisma session manager.

        :param Optional[str] cache_dir: Directory to store cached session tokens.
                                       Defaults to ~/.regscale/prisma_sessions/
        """
        if cache_dir:
            self.cache_dir = Path(cache_dir)
        else:
            self.cache_dir = Path.home() / ".regscale" / "prisma_sessions"

        # Create cache directory if it doesn't exist
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        # Set restrictive permissions on the cache directory (owner read/write only)
        if os.name != "nt":  # Unix-like systems
            os.chmod(self.cache_dir, 0o700)

    def _get_cache_key(self, console_url: str, username: str) -> str:
        """
        Generate cache key from console URL and username.

        :param str console_url: Prisma Cloud Console URL
        :param str username: Username for authentication
        :return: Hash-based cache key
        :rtype: str
        """
        key_string = f"{console_url}|{username}"
        return hashlib.sha256(key_string.encode()).hexdigest()[:16]

    def get_session(self, console_url: str, username: str) -> Optional[Dict[str, str]]:
        """
        Retrieve cached session token if it exists and is not expired.

        :param str console_url: Prisma Cloud Console URL
        :param str username: Username for authentication
        :return: Session data dictionary or None if not found/expired
        :rtype: Optional[Dict[str, str]]
        """
        cache_key = self._get_cache_key(console_url, username)
        cache_file = self.cache_dir / f"{cache_key}_session.json"

        if not cache_file.exists():
            logger.debug(f"No cached session found for {username}@{console_url}")
            return None

        try:
            with open(cache_file, "r", encoding="utf-8") as f:
                cache_data = json.load(f)

            expiration = datetime.fromisoformat(cache_data["expiration"])

            # Check if session is expired (with 30 minute buffer for safety)
            # Prisma tokens have 24-hour TTL
            if expiration - timedelta(minutes=30) < datetime.now():
                logger.warning(f"Cached session expired for {username}@{console_url}")
                # Clean up expired cache file
                cache_file.unlink()
                return None

            logger.info(f"Using cached session for {username}@{console_url}")
            logger.info(f"Session expires at: {cache_data['expiration']}")
            return cache_data

        except Exception as e:
            logger.error(f"Failed to read cached session: {e}")
            return None

    def save_session(
        self,
        console_url: str,
        username: str,
        token: str,
        expiration_hours: int = 24,
    ) -> None:
        """
        Cache session token to local file.

        :param str console_url: Prisma Cloud Console URL
        :param str username: Username for authentication
        :param str token: Bearer token from authentication
        :param int expiration_hours: Token expiration time in hours (default 24)
        """
        cache_key = self._get_cache_key(console_url, username)
        cache_file = self.cache_dir / f"{cache_key}_session.json"

        expiration_time = datetime.now() + timedelta(hours=expiration_hours)

        cache_data = {
            "console_url": console_url,
            "username": username,
            "token": token,
            "expiration": expiration_time.isoformat(),
            "cached_at": datetime.now().isoformat(),
        }

        with open(cache_file, "w", encoding="utf-8") as f:
            json.dump(cache_data, f, indent=2)

        # Set restrictive permissions on the cache file (owner read/write only)
        if os.name != "nt":  # Unix-like systems
            os.chmod(cache_file, 0o600)

        logger.info(f"Cached session for {username}@{console_url}")
        logger.info(f"Session expires at: {expiration_time.isoformat()}")

    def is_valid(self, console_url: str, username: str) -> bool:
        """
        Check if a valid cached session exists.

        :param str console_url: Prisma Cloud Console URL
        :param str username: Username for authentication
        :return: True if valid session exists, False otherwise
        :rtype: bool
        """
        session = self.get_session(console_url, username)
        return session is not None

    def clear_session(self, console_url: str, username: str) -> bool:
        """
        Clear a cached session.

        :param str console_url: Prisma Cloud Console URL
        :param str username: Username for authentication
        :return: True if session was cleared, False if not found
        :rtype: bool
        """
        cache_key = self._get_cache_key(console_url, username)
        cache_file = self.cache_dir / f"{cache_key}_session.json"

        if cache_file.exists():
            cache_file.unlink()
            logger.info(f"Cleared cached session for {username}@{console_url}")
            return True
        else:
            logger.warning(f"No cached session found for {username}@{console_url}")
            return False

    def clear_all_sessions(self) -> int:
        """
        Clear all cached sessions.

        :return: Number of sessions cleared
        :rtype: int
        """
        count = 0
        for cache_file in self.cache_dir.glob("*_session.json"):
            cache_file.unlink()
            count += 1

        logger.info(f"Cleared {count} cached Prisma session(s)")
        return count


def prisma_authenticate(
    console_url: str,
    username: str,
    password: str,
    verify_ssl: bool = True,
    timeout: int = 30,
) -> str:
    """
    Authenticate to Prisma Cloud Compute and return bearer token.

    This function calls the Prisma Cloud authentication endpoint and returns
    a bearer token with 24-hour TTL. The token should be cached for subsequent
    API calls.

    API Documentation: https://pan.dev/compute/api/authenticate/

    :param str console_url: Prisma Cloud Console URL (including port, e.g., https://console.example.com:8083)
    :param str username: Username for authentication
    :param str password: Password for authentication
    :param bool verify_ssl: Verify SSL certificates (default True)
    :param int timeout: Request timeout in seconds (default 30)
    :return: Bearer token string
    :rtype: str
    :raises requests.HTTPError: If authentication fails
    :raises requests.RequestException: If connection fails

    Example:
        >>> token = prisma_authenticate(
        ...     "https://console.example.com:8083",
        ...     "admin",
        ...     "password123"
        ... )
        >>> print(f"Token: {token[:20]}...")
        Token: eyJhbGciOiJIUzI1NiIs...
    """
    # Normalize console URL
    console_url = console_url.rstrip("/")

    # Build authentication endpoint
    auth_url = f"{console_url}/api/v1/authenticate"

    logger.info(f"Authenticating to Prisma Cloud: {console_url}")
    logger.debug(f"Authentication URL: {auth_url}")

    # Prepare authentication payload
    payload = {"username": username, "password": password}

    try:
        response = requests.post(
            auth_url,
            json=payload,
            verify=verify_ssl,
            timeout=timeout,
            headers={"Content-Type": "application/json"},
        )

        # Raise exception for HTTP errors
        response.raise_for_status()

        # Extract token from response
        response_data = response.json()

        # Prisma API returns token directly as JSON string or in "token" field
        if isinstance(response_data, str):
            token = response_data
        elif isinstance(response_data, dict) and "token" in response_data:
            token = response_data["token"]
        else:
            # If response format is unexpected, log it and try to extract token
            logger.warning(f"Unexpected authentication response format: {type(response_data)}")
            token = str(response_data)

        logger.info("Successfully authenticated to Prisma Cloud")
        logger.debug(f"Token length: {len(token)} characters")

        return token

    except requests.HTTPError as e:
        logger.error(f"Authentication failed with HTTP {e.response.status_code}: {e.response.text}")
        raise
    except requests.RequestException as e:
        logger.error(f"Connection to Prisma Cloud failed: {e}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error during authentication: {e}")
        raise


def authenticate_with_cache(
    console_url: str,
    username: str,
    password: str,
    verify_ssl: bool = True,
    timeout: int = 30,
    force_refresh: bool = False,
) -> str:
    """
    Authenticate to Prisma Cloud with automatic token caching.

    This is a convenience function that combines authentication with session caching.
    It checks for a valid cached token first, and only authenticates if needed.

    :param str console_url: Prisma Cloud Console URL
    :param str username: Username for authentication
    :param str password: Password for authentication
    :param bool verify_ssl: Verify SSL certificates (default True)
    :param int timeout: Request timeout in seconds (default 30)
    :param bool force_refresh: Force re-authentication even if cached token exists (default False)
    :return: Bearer token string
    :rtype: str

    Example:
        >>> token = authenticate_with_cache(
        ...     "https://console.example.com:8083",
        ...     "admin",
        ...     "password123"
        ... )
        >>> # Subsequent calls will use cached token
        >>> token2 = authenticate_with_cache(
        ...     "https://console.example.com:8083",
        ...     "admin",
        ...     "password123"
        ... )
    """
    session_manager = PrismaSessionManager()

    # Check for cached session unless force refresh
    if not force_refresh:
        cached_session = session_manager.get_session(console_url, username)
        if cached_session:
            return cached_session["token"]

    # Authenticate and cache token
    token = prisma_authenticate(console_url, username, password, verify_ssl, timeout)
    session_manager.save_session(console_url, username, token)

    return token
