#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prisma Cloud Scanner Integration

This module provides the main scanner integration class for Prisma Cloud Compute,
implementing the ScannerIntegration framework for standardized asset and finding
processing.
"""

import logging
from datetime import datetime
from typing import Dict, Iterator, List, Optional

from regscale.integrations.commercial.prisma.auth import authenticate_with_cache
from regscale.integrations.commercial.prisma.client import PrismaCloudClient
from regscale.integrations.commercial.prisma.deduplicator import PrismaDeduplicator
from regscale.integrations.commercial.prisma.variables import PrismaVariables
from regscale.integrations.commercial.prisma_modules import (
    extract_fqdn,
    parse_operating_system,
    truncate_description,
    validate_cvss_score,
)
from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
    validate_cve,
)
from regscale.models import regscale_models

logger = logging.getLogger("regscale")

# Constants
PRISMA_CLOUD_NAME = "Prisma Cloud"


class PrismaCloudScanner(ScannerIntegration):
    """
    Scanner integration for Prisma Cloud Compute.

    Supports three scan types:
    - hosts: VM/host vulnerability scanning
    - images: Container image vulnerability scanning
    - sbom: Software Bill of Materials processing
    """

    title = PRISMA_CLOUD_NAME
    asset_identifier_field = "identifier"
    issue_identifier_field = "cve"

    # Map Prisma severity strings to RegScale IssueSeverity enum
    finding_severity_map = {
        "critical": regscale_models.IssueSeverity.Critical,
        "high": regscale_models.IssueSeverity.High,
        "medium": regscale_models.IssueSeverity.Moderate,
        "moderate": regscale_models.IssueSeverity.Moderate,
        "low": regscale_models.IssueSeverity.Low,
        "info": regscale_models.IssueSeverity.Low,
        "informational": regscale_models.IssueSeverity.Low,
        "unknown": regscale_models.IssueSeverity.NotAssigned,
        "unassigned": regscale_models.IssueSeverity.NotAssigned,
    }

    def __init__(self, plan_id: int, scan_type: str = "hosts", use_csv: bool = False, **kwargs):
        """
        Initialize Prisma Cloud Scanner.

        :param int plan_id: RegScale Security Plan ID
        :param str scan_type: Type of scan ("hosts", "images", or "sbom")
        :param bool use_csv: Use CSV download endpoints for bulk data retrieval (default False)
        :param kwargs: Additional keyword arguments (e.g., console_url, username, password) passed to fetch methods
        """
        super().__init__(plan_id)
        self.scan_type = scan_type
        self.use_csv = use_csv
        self.client: Optional[PrismaCloudClient] = None
        self.deduplicator = PrismaDeduplicator()

        # Validate scan type
        if scan_type not in ["hosts", "images", "sbom"]:
            raise ValueError(f"Invalid scan_type: {scan_type}. Must be 'hosts', 'images', or 'sbom'")

        mode = "CSV" if use_csv else "JSON API"
        logger.info(f"Initialized Prisma Cloud Scanner for scan type: {scan_type} (mode: {mode})")

    def authenticate(
        self,
        console_url: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        force_refresh: bool = False,
    ) -> None:
        """
        Authenticate to Prisma Cloud Compute and initialize API client.

        :param Optional[str] console_url: Console URL (uses PrismaVariables if not provided)
        :param Optional[str] username: Username (uses PrismaVariables if not provided)
        :param Optional[str] password: Password (uses PrismaVariables if not provided)
        :param bool force_refresh: Force re-authentication even if cached token exists
        """
        # Use variables from init.yaml if not provided
        console_url = console_url or str(PrismaVariables.prismaConsoleUrl)  # type: ignore
        username = username or str(PrismaVariables.prismaUsername)  # type: ignore
        password = password or str(PrismaVariables.prismaPassword)  # type: ignore

        logger.info(f"Authenticating to Prisma Cloud: {console_url}")

        # Safe type conversions for variables (handle empty strings)
        api_timeout = PrismaVariables.prismaApiTimeout or 30
        api_retries = PrismaVariables.prismaApiRetries or 3
        verify_ssl = PrismaVariables.prismaVerifySsl if PrismaVariables.prismaVerifySsl is not None else True

        # Authenticate with caching
        token = authenticate_with_cache(
            console_url=console_url,
            username=username,
            password=password,
            verify_ssl=bool(verify_ssl),
            timeout=int(api_timeout) if api_timeout else 30,
            force_refresh=force_refresh,
        )

        self.client = PrismaCloudClient(
            console_url=console_url,
            token=token,
            verify_ssl=bool(verify_ssl),
            timeout=int(api_timeout) if api_timeout else 30,
            max_retries=int(api_retries) if api_retries else 3,
        )

        logger.info("Successfully authenticated and initialized Prisma Cloud API client")

    def fetch_assets(self, **kwargs) -> Iterator[IntegrationAsset]:
        """
        Fetch assets from Prisma Cloud based on scan_type.

        Routes to CSV or JSON API methods based on use_csv flag.
        Authenticates automatically if credentials are provided in kwargs.

        :yields: IntegrationAsset objects
        :rtype: Iterator[IntegrationAsset]
        :raises RuntimeError: If not authenticated and no credentials provided
        """
        # Authenticate if not already authenticated (following Wiz pattern)
        if self.client is None:
            self.authenticate(
                console_url=kwargs.get("console_url"),
                username=kwargs.get("username"),
                password=kwargs.get("password"),
            )

        # Route to CSV or JSON API methods
        if self.use_csv:
            yield from self._fetch_assets_from_csv(**kwargs)
            return

        if self.scan_type == "hosts":
            yield from self._fetch_host_assets(**kwargs)
        elif self.scan_type == "images":
            yield from self._fetch_image_assets(**kwargs)
        elif self.scan_type == "sbom":
            logger.warning("SBOM scan type does not fetch assets directly. Use sync_sbom command instead.")

    def _apply_deduplication(self, findings: List[Dict]) -> List[Dict]:
        """
        Apply deduplication to findings based on configuration.

        :param List[Dict] findings: Raw finding dictionaries
        :return: Deduplicated findings
        :rtype: List[Dict]
        """
        # Safe boolean conversion (handle empty strings)
        deduplicate = PrismaVariables.prismaDeduplicateFindings
        if deduplicate is None or str(deduplicate).lower() in ["", "false", "0", "no"]:
            return findings

        dedup_mode = str(PrismaVariables.prismaDeduplicationMode).lower()  # type: ignore
        logger.info("Deduplicating %d findings using mode: %s", len(findings), dedup_mode)

        if dedup_mode == "by_cve":
            deduplicated = self.deduplicator.deduplicate_by_cve(findings)
        else:
            deduplicated = self.deduplicator.deduplicate_findings(findings)

        stats = self.deduplicator.get_stats()
        logger.info(
            "Deduplication complete: %d -> %d findings (%s%% reduction)",
            stats["original_count"],
            stats["deduplicated_count"],
            stats["reduction_percentage"],
        )
        return deduplicated

    def fetch_findings(self, **kwargs) -> Iterator[IntegrationFinding]:
        """
        Fetch findings from Prisma Cloud based on scan_type.

        Routes to CSV or JSON API methods based on use_csv flag.
        Applies client-side deduplication if enabled.
        Authenticates automatically if credentials are provided in kwargs.

        :yields: IntegrationFinding objects
        :rtype: Iterator[IntegrationFinding]
        :raises RuntimeError: If not authenticated and no credentials provided
        """
        # Authenticate if not already authenticated (following Wiz pattern)
        if self.client is None:
            self.authenticate(
                console_url=kwargs.get("console_url"),
                username=kwargs.get("username"),
                password=kwargs.get("password"),
            )

        # Collect all findings first for deduplication
        all_findings = []

        # Route to CSV or JSON API methods
        if self.use_csv:
            for finding_dict in self._fetch_findings_from_csv(**kwargs):
                all_findings.append(finding_dict)
        elif self.scan_type == "hosts":
            for finding_dict in self._fetch_host_findings(**kwargs):
                all_findings.append(finding_dict)
        elif self.scan_type == "images":
            for finding_dict in self._fetch_image_findings(**kwargs):
                all_findings.append(finding_dict)
        elif self.scan_type == "sbom":
            logger.warning("SBOM scan type does not fetch findings directly. Use sync_sbom command instead.")
            return

        # Apply deduplication
        all_findings = self._apply_deduplication(all_findings)

        # Convert dictionaries to IntegrationFinding objects and yield
        for finding_dict in all_findings:
            try:
                yield self._dict_to_integration_finding(finding_dict)
            except Exception as e:
                logger.error(f"Error converting finding to IntegrationFinding: {type(e).__name__}: {e}")
                logger.debug(
                    f"Finding data: CVE={finding_dict.get('cve')}, Asset={finding_dict.get('asset_identifier')}"
                )
                import traceback

                logger.debug(traceback.format_exc())
                continue  # Skip this finding and continue with others

    def _fetch_host_assets(self, **kwargs) -> Iterator[IntegrationAsset]:
        """Fetch host assets from Prisma Cloud."""
        logger.info("Fetching host assets from Prisma Cloud...")

        filters = kwargs.get("filters")
        # Safe int conversion (handle empty strings)
        page_size = int(PrismaVariables.prismaPageSize or 50)

        for host_data in self.client.get_hosts(filters=filters, page_size=page_size):
            asset = self._parse_host_asset(host_data)
            if asset:
                yield asset

    def _fetch_image_assets(self, **kwargs) -> Iterator[IntegrationAsset]:
        """Fetch container image assets from Prisma Cloud."""
        logger.info("Fetching image assets from Prisma Cloud...")

        filters = kwargs.get("filters")
        # Safe int conversion (handle empty strings)
        page_size = int(PrismaVariables.prismaPageSize or 50)

        for image_data in self.client.get_images(filters=filters, page_size=page_size):
            asset = self._parse_image_asset(image_data)
            if asset:
                yield asset

    def _fetch_host_findings(self, **kwargs) -> Iterator[Dict]:
        """Fetch host vulnerability findings from Prisma Cloud."""
        logger.info("Fetching host findings from Prisma Cloud...")

        filters = kwargs.get("filters")
        # Safe int conversion (handle empty strings)
        page_size = int(PrismaVariables.prismaPageSize or 50)

        for host_data in self.client.get_hosts(filters=filters, page_size=page_size):
            hostname = host_data.get("hostname", "unknown")
            vulnerabilities = host_data.get("vulnerabilities", [])

            for vuln in vulnerabilities:
                finding_dict = self._parse_vulnerability(vuln, hostname, asset_type="host")
                if finding_dict:
                    yield finding_dict

    def _fetch_image_findings(self, **kwargs) -> Iterator[Dict]:
        """Fetch container image vulnerability findings from Prisma Cloud."""
        logger.info("Fetching image findings from Prisma Cloud...")

        filters = kwargs.get("filters")
        # Safe int conversion (handle empty strings)
        page_size = int(PrismaVariables.prismaPageSize or 50)

        for image_data in self.client.get_images(filters=filters, page_size=page_size):
            image_name = image_data.get("imageName", image_data.get("_id", "unknown"))
            vulnerabilities = image_data.get("vulnerabilities", [])

            for vuln in vulnerabilities:
                finding_dict = self._parse_vulnerability(vuln, image_name, asset_type="image")
                if finding_dict:
                    yield finding_dict

    def _parse_host_asset(self, host_data: Dict) -> Optional[IntegrationAsset]:
        """
        Parse Prisma host JSON to IntegrationAsset.

        :param Dict host_data: Raw host data from Prisma API
        :return: IntegrationAsset or None if parsing fails
        :rtype: Optional[IntegrationAsset]
        """
        try:
            hostname = host_data.get("hostname", "")
            if not hostname:
                logger.warning("Host data missing hostname, skipping")
                return None

            # Extract OS information
            distro = host_data.get("distro", "")
            os_distro = host_data.get("osDistro", "")
            os_version = host_data.get("osDistroVersion", "")
            os_release = host_data.get("osDistroRelease", "")

            # Parse operating system
            os_string = distro or f"{os_distro} {os_version} {os_release}".strip()
            operating_system = parse_operating_system(os_string) if os_string else None

            # Extract FQDN
            fqdn = extract_fqdn(hostname)

            # Build asset properties
            return IntegrationAsset(
                name=hostname,
                identifier=hostname,
                asset_type="Virtual Machine (VM)",
                asset_category="Server",
                asset_owner_id=self.assessor_id,
                parent_id=self.plan_id,
                parent_module=regscale_models.SecurityPlan.get_module_slug(),
                operating_system=operating_system,
                fqdn=fqdn,
                status="Active (On Network)",
                date_last_updated=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                component_names=["Prisma Cloud Host"],
            )

        except Exception as e:
            logger.error(f"Error parsing host asset: {e}")
            return None

    def _parse_image_asset(self, image_data: Dict) -> Optional[IntegrationAsset]:
        """
        Parse Prisma container image JSON to IntegrationAsset.

        :param Dict image_data: Raw image data from Prisma API
        :return: IntegrationAsset or None if parsing fails
        :rtype: Optional[IntegrationAsset]
        """
        try:
            image_name = image_data.get("imageName", "")
            image_id = image_data.get("_id", "")

            if not image_name and not image_id:
                logger.warning("Image data missing name and ID, skipping")
                return None

            asset_name = image_name or image_id

            return IntegrationAsset(
                name=asset_name,
                identifier=image_id or image_name,
                asset_type="Container Image",
                asset_category="Software",
                asset_owner_id=self.assessor_id,
                parent_id=self.plan_id,
                parent_module=regscale_models.SecurityPlan.get_module_slug(),
                other_tracking_number=image_id,
                status="Active (On Network)",
                date_last_updated=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                component_names=["Prisma Cloud Image"],
            )

        except Exception as e:
            logger.error(f"Error parsing image asset: {e}")
            return None

    def _extract_and_validate_cve(self, vuln_data: Dict) -> Optional[str]:
        """Extract and validate CVE from vulnerability data."""
        cve = vuln_data.get("cve", "")
        if not cve:
            logger.debug("Vulnerability missing identifier, skipping")
            return None

        # Validate CVE format - accept CVE or other vulnerability identifiers (GHSA, PRISMA, GO, etc.)
        validated_cve = validate_cve(cve)
        if validated_cve:
            return validated_cve

        # Non-CVE identifier (GHSA, PRISMA, GO, etc.) - keep as-is but strip whitespace
        cve = cve.strip()
        logger.debug(f"Non-CVE vulnerability identifier accepted: {cve}")
        return cve

    def _extract_severity(self, vuln_data: Dict) -> str:
        """Extract and map severity from vulnerability data."""
        severity_str = str(vuln_data.get("severity", "unknown")).lower()
        return severity_str

    def _extract_fixed_version(self, status: str) -> str:
        """Extract fixed version from status string."""
        if status and "fixed in" in str(status).lower():
            parts = str(status).split("fixed in")
            if len(parts) > 1:
                return parts[1].strip()
        return ""

    def _convert_timestamp_to_date(self, timestamp) -> Optional[str]:
        """Convert timestamp to date string."""
        if isinstance(timestamp, int):
            return datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d")
        return timestamp

    def _extract_risk_factors(self, vuln_data: Dict) -> str:
        """Extract risk factors as comma-separated string."""
        risk_factors = vuln_data.get("riskFactors", {})
        risk_factor_list = list(risk_factors.keys()) if risk_factors else []
        return ", ".join(risk_factor_list)

    def _build_recommendation(self, fixed_version: str, package_name: str, status: str) -> str:
        """Build recommendation string from fix information."""
        if fixed_version:
            return f"Update {package_name} to version {fixed_version}"
        if status:
            return status
        return ""

    def _parse_vulnerability(self, vuln_data: Dict, asset_identifier: str, asset_type: str) -> Optional[Dict]:
        """
        Parse Prisma vulnerability to finding dictionary (for deduplication).

        Returns a dictionary instead of IntegrationFinding to allow deduplication.

        :param Dict vuln_data: Raw vulnerability data from Prisma API
        :param str asset_identifier: Host or image identifier
        :param str asset_type: Type of asset ("host" or "image")
        :return: Finding dictionary or None if parsing fails
        :rtype: Optional[Dict]
        """
        try:
            # Extract and validate CVE
            cve = self._extract_and_validate_cve(vuln_data)
            if not cve:
                return None

            # Extract CVSS score
            cvss_score = validate_cvss_score(vuln_data.get("cvss"))

            # Extract severity
            severity_str = self._extract_severity(vuln_data)

            # Extract package information
            package_name = vuln_data.get("packageName", "")
            package_version = vuln_data.get("packageVersion", "")
            package_type = vuln_data.get("packageType", "")

            # Extract fix information
            status = str(vuln_data.get("status") or "")
            fixed_version = self._extract_fixed_version(status)

            # Extract and convert dates
            discovered_date = vuln_data.get("discovered", "")
            published_date = self._convert_timestamp_to_date(vuln_data.get("published"))
            fix_date = self._convert_timestamp_to_date(vuln_data.get("fixDate"))

            # Extract risk factors
            risk_factors_str = self._extract_risk_factors(vuln_data)

            # Build description
            description = vuln_data.get("description", "")
            description = truncate_description(description, max_length=5000)

            # Build title
            title = vuln_data.get("title") or f"{cve} - {package_name or 'Unknown Package'}"

            # Build recommendation
            recommendation = self._build_recommendation(fixed_version, package_name, status)

            # Return finding dictionary for deduplication
            return {
                "cve": cve,
                "asset_identifier": asset_identifier,
                "asset_id": asset_identifier,
                "asset_type": asset_type,
                "severity": severity_str,
                "cvss_score": cvss_score,
                "cvss_v3_score": cvss_score,
                "title": title,
                "description": description,
                "package_name": package_name,
                "package_version": package_version,
                "package_type": package_type,
                "fixed_version": fixed_version,
                "discovered_date": discovered_date,
                "published_date": published_date,
                "fix_date": fix_date,
                "risk_factors": risk_factors_str,
                "status": status,
                "recommendation_for_mitigation": recommendation,
                "link": vuln_data.get("link", ""),
                "vec_str": vuln_data.get("vecStr", ""),
            }

        except Exception as e:
            logger.error(f"Error parsing vulnerability: {type(e).__name__}: {e}")
            logger.debug(
                f"Asset: {asset_identifier}, CVE: {vuln_data.get('cve', 'N/A')}, Severity: {vuln_data.get('severity', 'N/A')}"
            )
            import traceback

            logger.debug(traceback.format_exc())
            return None

    def _dict_to_integration_finding(self, finding_dict: Dict) -> IntegrationFinding:
        """
        Convert finding dictionary to IntegrationFinding object.

        :param Dict finding_dict: Finding dictionary from _parse_vulnerability or deduplicator
        :return: IntegrationFinding object
        :rtype: IntegrationFinding
        """
        # Map severity string to enum with better error handling
        severity_str = str(finding_dict.get("severity", "unknown")).lower().strip()
        severity = self.finding_severity_map.get(severity_str)

        if not severity:
            logger.warning(f"Unknown severity value: {finding_dict.get('severity')}, defaulting to NotAssigned")
            severity = regscale_models.IssueSeverity.NotAssigned

        # Build affected_packages string from package info
        package_name = finding_dict.get("package_name", "")
        package_version = finding_dict.get("package_version", "")
        affected_packages = f"{package_name} {package_version}".strip() if package_name or package_version else None

        # Ensure title always has a value (never empty string)
        title = finding_dict.get("title", "")
        if not title or not title.strip():
            cve = finding_dict.get("cve", "")
            if cve:
                title = f"{cve}" + (f" - {package_name}" if package_name else "")
            else:
                title = "Prisma Cloud Vulnerability"

        return IntegrationFinding(
            control_labels=[],  # Required field
            title=title,
            category="Vulnerability",  # Required field
            plugin_name=package_name or PRISMA_CLOUD_NAME,  # Required field
            description=finding_dict.get("description", ""),
            severity=severity,
            cve=finding_dict.get("cve", ""),
            cvss_v3_score=finding_dict.get("cvss_v3_score"),
            asset_identifier=finding_dict.get("asset_identifier", ""),
            affected_packages=affected_packages,
            installed_versions=package_version if package_version else None,
            fixed_versions=finding_dict.get("fixed_version", "") if finding_dict.get("fixed_version") else None,
            recommendation_for_mitigation=finding_dict.get("recommendation_for_mitigation", ""),
            external_id=finding_dict.get("link", ""),
            source_report=PRISMA_CLOUD_NAME,
            identification="Prisma Cloud Vulnerability Scan",
            status="FAIL",  # String value instead of enum to avoid mapping warnings
        )

    def _fetch_assets_from_csv(self, **kwargs) -> Iterator[IntegrationAsset]:
        """
        Fetch assets using CSV download endpoints.

        Alternative to fetch_assets() for bulk CSV imports. Uses Platform One (P1)
        customer's proven workflow with CSV download endpoints.

        :yields: IntegrationAsset objects
        :rtype: Iterator[IntegrationAsset]
        """
        from regscale.integrations.commercial.prisma.csv_parser import (
            csv_to_integration_assets,
            expand_host_lists,
            parse_prisma_csv,
        )

        logger.info(f"Fetching assets from CSV download endpoint (scan_type: {self.scan_type})...")

        # Download CSV data
        if self.scan_type == "hosts":
            csv_data = self.client.get_hosts_csv()
        elif self.scan_type == "images":
            csv_data = self.client.get_images_csv()
        else:
            logger.error(f"CSV mode not supported for scan_type: {self.scan_type}")
            return

        # Parse CSV
        rows = parse_prisma_csv(csv_data)
        logger.info(f"Parsed {len(rows)} rows from CSV data")

        # Expand host lists if present
        expanded_rows = list(expand_host_lists(rows))
        logger.info(f"Expanded to {len(expanded_rows)} rows (host list expansion)")

        # Convert to assets
        assets = csv_to_integration_assets(expanded_rows, self.scan_type)
        logger.info(f"Converted to {len(assets)} unique assets")

        # Convert to IntegrationAsset objects and yield
        for asset_dict in assets:
            yield self._dict_to_integration_asset_from_csv(asset_dict)

    def _fetch_findings_from_csv(self, **kwargs) -> Iterator[Dict]:
        """
        Fetch findings using CSV download endpoints.

        Alternative to fetch_findings() for bulk CSV imports. Uses Platform One (P1)
        customer's proven workflow with CSV download endpoints.

        :yields: Finding dictionaries
        :rtype: Iterator[Dict]
        """
        from regscale.integrations.commercial.prisma.csv_parser import (
            csv_to_integration_findings,
            expand_host_lists,
            parse_prisma_csv,
        )

        logger.info(f"Fetching findings from CSV download endpoint (scan_type: {self.scan_type})...")

        # Download CSV data
        if self.scan_type == "hosts":
            csv_data = self.client.get_hosts_csv()
        elif self.scan_type == "images":
            csv_data = self.client.get_images_csv()
        else:
            logger.error(f"CSV mode not supported for scan_type: {self.scan_type}")
            return

        # Parse and expand
        rows = parse_prisma_csv(csv_data)
        expanded_rows = list(expand_host_lists(rows))
        logger.info(f"Expanded {len(rows)} CSV rows to {len(expanded_rows)} rows (host list expansion)")

        # Convert to findings
        findings = csv_to_integration_findings(expanded_rows)
        logger.info(f"Converted to {len(findings)} findings from CSV data")

        # Yield findings
        for finding in findings:
            yield finding

    def _dict_to_integration_asset_from_csv(self, asset_dict: Dict) -> IntegrationAsset:
        """
        Convert CSV asset dictionary to IntegrationAsset object.

        :param Dict asset_dict: Asset dictionary from csv_parser
        :return: IntegrationAsset object
        :rtype: IntegrationAsset
        """
        return IntegrationAsset(
            identifier=asset_dict.get("identifier", ""),
            name=asset_dict.get("name", ""),
            description=f"{asset_dict.get('type', 'asset')} - {asset_dict.get('distro', 'Unknown')}",
            asset_type=asset_dict.get("type", ""),
        )
