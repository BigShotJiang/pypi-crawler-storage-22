#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prisma Cloud Integration Variables

Configuration variables for Prisma Cloud Compute API integration.
These variables can be set in init.yaml or as environment variables.
"""

from regscale.core.app.utils.variables import RsVariablesMeta, RsVariableType


class PrismaVariables(metaclass=RsVariablesMeta):
    """
    Prisma Cloud Variables class to define configuration with type annotations.

    All variables follow the RegScale variables pattern and can be configured via:
    - init.yaml configuration file
    - Environment variables
    - AWS Secrets Manager
    - Command-line parameters
    """

    # ============================================================================
    # Authentication Configuration
    # ============================================================================
    # prismaConsoleUrl: Prisma Cloud Compute Console URL (including port 8083)
    prismaConsoleUrl: RsVariableType(str, "https://console.example.com:8083")  # type: ignore

    # prismaUsername: Prisma Cloud Compute API username
    prismaUsername: RsVariableType(str, "", sensitive=True)  # type: ignore

    # prismaPassword: Prisma Cloud Compute API password
    prismaPassword: RsVariableType(str, "", sensitive=True)  # type: ignore

    # prismaAccessToken: Cached Prisma Cloud access token (24-hour TTL)
    prismaAccessToken: RsVariableType(str, "", sensitive=True, required=False)  # type: ignore

    # prismaVerifySsl: Verify SSL certificates for Prisma Cloud API calls
    prismaVerifySsl: RsVariableType(bool, True, required=False)  # type: ignore

    # ============================================================================
    # API Configuration
    # ============================================================================
    # prismaApiTimeout: API request timeout in seconds
    prismaApiTimeout: RsVariableType(int, 30, required=False)  # type: ignore

    # prismaApiRetries: Number of API request retries on failure
    prismaApiRetries: RsVariableType(int, 3, required=False)  # type: ignore

    # prismaPageSize: Number of records to fetch per API page (pagination)
    prismaPageSize: RsVariableType(int, 50, required=False)  # type: ignore

    # ============================================================================
    # Integration Configuration
    # ============================================================================
    # prismaEnableSoftwareInventory: Enable software inventory creation from SBOM data
    prismaEnableSoftwareInventory: RsVariableType(bool, False, required=False)  # type: ignore

    # prismaDeduplicateFindings: Enable client-side deduplication of findings before submission
    prismaDeduplicateFindings: RsVariableType(bool, True, required=False)  # type: ignore

    # prismaDeduplicationMode: Deduplication strategy - "by_asset" (per asset) or "by_cve" (across assets)
    # "by_asset": Deduplicate CVEs per individual asset (default)
    # "by_cve": Deduplicate CVEs across ALL assets (creates single finding per CVE with multiple assets)
    prismaDeduplicationMode: RsVariableType(str, "by_asset", required=False)  # type: ignore

    # prismaDefaultFilters: Default JSON filters for API queries
    prismaDefaultFilters: RsVariableType(str, '{"collections": []}', required=False)  # type: ignore
