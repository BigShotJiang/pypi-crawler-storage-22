"""QRadar SIEM integration for RegScale."""

from regscale.integrations.commercial.qradar.qradar_integration import qradar

__all__ = ["qradar"]
