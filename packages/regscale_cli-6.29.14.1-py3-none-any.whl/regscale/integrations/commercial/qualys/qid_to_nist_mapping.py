#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Qualys Policy Control QID to NIST 800-53 Rev 5 mapping table.

Based on:
- CIS Benchmark to NIST 800-53 crosswalk
- Qualys Policy Compliance documentation
- Manual analysis of QID checks from actual reports

This mapping is optional. If not used, the CIS compliance processor
will fall back to heuristic keyword matching.
"""

from typing import Dict, List

# QID to NIST 800-53 Rev 5 Control Mapping
QID_TO_NIST_R5: Dict[str, List[str]] = {
    # ====================
    # Time Synchronization (CIS 2.1.x -> AU-8)
    # ====================
    "7457": ["AU-8"],  # NTP configuration in /etc/sysconfig/ntpd
    "10848": ["AU-8"],  # NTP service ExecStart settings
    "1202": ["AU-8"],  # NTP daemon configuration
    # ====================
    # Minimize Installed Services (CIS 2.2.x -> CM-7)
    # ====================
    "9317": ["CM-7"],  # X Windows
    "9333": ["CM-7"],  # avahi-daemon
    "1260": ["CM-7"],  # CUPS (Common Unix Printing System)
    "10005": ["CM-7"],  # DHCP daemon
    "9891": ["CM-7"],  # LDAP (slapd)
    "9892": ["CM-7"],  # DNS (named)
    "9884": ["CM-7"],  # FTP (vsftpd)
    "9881": ["CM-7"],  # HTTP (httpd)
    "9348": ["CM-7"],  # rsync service
    "1771": ["CM-7"],  # SNMP daemon
    "1768": ["CM-7"],  # NFS service
    "1778": ["CM-7"],  # RPC services
    # ====================
    # Mail Transfer Agent (CIS 2.2.15 -> AC-17, SC-8)
    # ====================
    "9380": ["AC-17", "SC-8"],  # MTA local-only mode
    # ====================
    # File Permissions and Ownership (CIS 6.1.x -> AC-3, AC-6)
    # ====================
    "7943": ["AC-3", "AC-6"],  # /etc/passwd permissions
    "5961": ["AC-3", "AC-6"],  # /etc/shadow permissions
    "10491": ["AC-3", "AC-6"],  # /etc/group permissions
    # ====================
    # Account Management (CIS 5.x -> IA-5, AC-2)
    # ====================
    "12757": ["IA-5"],  # Password policy settings
    "12789": ["IA-5"],  # Password expiration
    "14395": ["IA-5"],  # Password complexity
    # ====================
    # Add more mappings as you encounter them in reports
    # ====================
    # Uncomment and add QIDs from your actual reports:
    # "XXXXX": ["CONTROL-ID"],  # Description
}


def get_controls_for_qid(qid: str) -> List[str]:
    """
    Get NIST control IDs for a Qualys QID.

    :param str qid: Qualys Policy Control ID (QID)
    :return: List of NIST control IDs (e.g., ["CM-7", "AC-6"])
    :rtype: List[str]
    """
    return QID_TO_NIST_R5.get(qid, [])


def add_mapping(qid: str, control_ids: List[str]) -> None:
    """
    Add a new QID to NIST control mapping.

    Useful for dynamically building mappings during testing.

    :param str qid: Qualys Policy Control ID
    :param List[str] control_ids: List of NIST control IDs
    """
    QID_TO_NIST_R5[qid] = control_ids


def get_all_mapped_qids() -> List[str]:
    """
    Get list of all QIDs that have mappings.

    :return: List of mapped QIDs
    :rtype: List[str]
    """
    return list(QID_TO_NIST_R5.keys())


def get_mapping_coverage(qids_in_report: List[str]) -> Dict[str, any]:
    """
    Calculate mapping coverage for a list of QIDs from a report.

    :param List[str] qids_in_report: List of QIDs found in report
    :return: Dict with coverage statistics
    :rtype: Dict[str, any]
    """
    total_qids = len(qids_in_report)
    mapped_qids = [qid for qid in qids_in_report if qid in QID_TO_NIST_R5]
    unmapped_qids = [qid for qid in qids_in_report if qid not in QID_TO_NIST_R5]

    coverage_pct = (len(mapped_qids) / total_qids * 100) if total_qids > 0 else 0

    return {
        "total_qids": total_qids,
        "mapped_qids": len(mapped_qids),
        "unmapped_qids": len(unmapped_qids),
        "coverage_percentage": coverage_pct,
        "unmapped_qid_list": unmapped_qids[:10],  # First 10 for review
    }
