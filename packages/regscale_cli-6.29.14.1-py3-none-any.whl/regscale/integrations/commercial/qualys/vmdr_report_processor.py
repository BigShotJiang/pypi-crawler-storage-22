"""
VMDR Report Processor - Transform Qualys VMDR scan reports to RegScale entities

This module provides data transformation from Qualys VMDR scan report format
to RegScale assets, issues, and vulnerabilities.
"""

import logging
from datetime import datetime
from typing import Dict, List, Optional

from regscale.core.app.utils.due_date_handler import DueDateHandler
from regscale.models.integration_models.integration_asset import IntegrationAsset
from regscale.models.integration_models.integration_finding import IntegrationFinding
from regscale.models.regscale_models.issues import Issue
from regscale.models.regscale_models.vulnerabilities import Vulnerability

logger = logging.getLogger(__name__)

# Constants for duplicated string literals
MSG_NO_HOSTS_FOUND = "No hosts found in report data"
SOURCE_QUALYS_VMDR = "Qualys VMDR Scan Report"
HTML_BREAK = "</br>"
DEFAULT_DESCRIPTION = "No description available"


class VMDRReportProcessor:
    """
    Process VMDR scan report data and convert to RegScale entities.

    This class handles transformation of parsed VMDR report data into RegScale
    assets, issues, and vulnerabilities following existing Qualys integration patterns.
    """

    def __init__(self, config: Dict):
        """
        Initialize VMDR report processor.

        :param Dict config: RegScale configuration dictionary with keys:
            - userId: RegScale user ID for ownership
            - issues.qualys.status: Default issue status (e.g., "Open")
            - parentModule: Parent module (default: "securityplans")
            - issues.qualys.requireDeviationRationale: Enable deviationRationale field (default: True)
            - issues.qualys.requireRecommendedActions: Enable recommendedActions field (default: True)
        """
        self.config = config
        self.user_id = config.get("userId")
        self.default_status = config.get("issues", {}).get("qualys", {}).get("status", "Open")
        self.parent_module = config.get("parentModule", "securityplans")

        # Config-based field requirements (may not exist on all RegScale tenants)
        # NOTE: The following fields may be DISABLED on some RegScale servers (especially on-prem):
        # - pluginId, recommendedActions, sourceReport, securityChecks
        # Default to False to avoid "Field 'X' must be enabled to enter a value" errors.
        qualys_config = config.get("issues", {}).get("qualys", {})
        self.require_deviation_rationale = qualys_config.get("requireDeviationRationale", True)
        self.require_recommended_actions = qualys_config.get("requireRecommendedActions", False)  # May be disabled
        self.include_plugin_id = qualys_config.get("includePluginId", False)  # May be disabled

        logger.info("Initialized VMDRReportProcessor")
        logger.debug(
            "Field requirements: deviationRationale=%s, recommendedActions=%s, pluginId=%s",
            self.require_deviation_rationale,
            self.require_recommended_actions,
            self.include_plugin_id,
        )

    def convert_report_to_assets(self, report_data: Dict) -> List[IntegrationAsset]:
        """
        Convert VMDR report hosts to IntegrationAsset objects.

        :param Dict report_data: Parsed report data from parse_vmdr_scan_report()
        :return: List of IntegrationAsset objects
        :rtype: List[IntegrationAsset]
        """
        logger.info("Converting report hosts to IntegrationAsset objects")

        if not report_data or "hosts" not in report_data:
            logger.warning(MSG_NO_HOSTS_FOUND)
            return []

        assets = []
        hosts = report_data["hosts"]

        for host_data in hosts:
            # Extract asset identifiers
            ip_address = host_data.get("IP", "")
            hostname = host_data.get("HOSTNAME", "")
            os_info = host_data.get("OS", "")

            # Create asset identifier (prefer hostname, fallback to IP)
            asset_id = hostname if hostname else ip_address
            if not asset_id:
                logger.warning("Skipping host with no IP or hostname")
                continue

            # Build asset tags
            tags = []
            if host_data.get("TRACKING_METHOD"):
                tags.append(f"tracking:{host_data['TRACKING_METHOD']}")

            # Create IntegrationAsset
            asset = IntegrationAsset(
                id=asset_id,
                name=hostname if hostname else f"Host {ip_address}",
                ipAddress=ip_address,
                hostName=hostname,
                os=os_info,
                tags=tags,
                source=SOURCE_QUALYS_VMDR,
            )

            assets.append(asset)

        logger.info("Converted %s hosts to IntegrationAsset objects", len(assets))
        return assets

    def convert_report_to_findings(self, report_data: Dict) -> List[IntegrationFinding]:
        """
        Convert VMDR report vulnerabilities to IntegrationFinding objects.

        :param Dict report_data: Parsed report data from parse_vmdr_scan_report()
        :return: List of IntegrationFinding objects
        :rtype: List[IntegrationFinding]
        """
        logger.info("Converting report vulnerabilities to IntegrationFinding objects")

        if not report_data or "hosts" not in report_data:
            logger.warning(MSG_NO_HOSTS_FOUND)
            return []

        findings = []
        hosts = report_data["hosts"]
        glossary = report_data.get("glossary", {})

        for host_data in hosts:
            asset_id = host_data.get("HOSTNAME") or host_data.get("IP")
            vulnerabilities = host_data.get("VULNERABILITIES", [])

            for vuln in vulnerabilities:
                qid = vuln.get("QID", "")
                if not qid:
                    continue

                # Get enriched details from glossary
                vuln_details = glossary.get(qid, {})

                # Map severity (Qualys 1-5 scale to RegScale)
                severity_level = vuln.get("SEVERITY", "3")
                severity_map = {"5": "Critical", "4": "High", "3": "Medium", "2": "Low", "1": "Informational"}
                severity = severity_map.get(str(severity_level), "Medium")

                # Build title
                title = vuln_details.get("TITLE", f"Vulnerability QID {qid}")

                # Build description
                consequence = vuln_details.get("CONSEQUENCE", "")
                diagnosis = vuln_details.get("DIAGNOSIS", "")
                description_parts = [part for part in [consequence, diagnosis] if part]
                description = HTML_BREAK.join(description_parts) if description_parts else DEFAULT_DESCRIPTION

                # Get solution
                solution = vuln_details.get("SOLUTION", "")

                # Create IntegrationFinding
                finding = IntegrationFinding(
                    id=f"{asset_id}_{qid}",
                    title=title,
                    description=description,
                    severity=severity,
                    solution=solution,
                    cveIds=vuln.get("CVE_ID_LIST", []),
                    pluginId=qid,
                    assetId=asset_id,
                    firstSeen=self._parse_datetime(vuln.get("FIRST_FOUND_DATETIME")),
                    lastSeen=self._parse_datetime(vuln.get("LAST_FOUND_DATETIME")),
                    status=vuln.get("STATUS", "Active"),
                    port=vuln.get("PORT"),
                    protocol=vuln.get("PROTOCOL"),
                    source=SOURCE_QUALYS_VMDR,
                )

                findings.append(finding)

        logger.info("Converted %s vulnerabilities to IntegrationFinding objects", len(findings))
        return findings

    def _group_vulnerabilities_by_qid(self, hosts: List[Dict], glossary: Dict) -> Dict:
        """
        Group vulnerabilities by QID to deduplicate across assets.

        :param List[Dict] hosts: List of host data dictionaries
        :param Dict glossary: Vulnerability details glossary
        :return: Dictionary mapping QID to vuln data, affected assets, and details
        :rtype: Dict
        """
        vuln_groups = {}
        for host_data in hosts:
            asset_id = host_data.get("HOSTNAME") or host_data.get("IP")
            vulnerabilities = host_data.get("VULNERABILITIES", [])

            for vuln in vulnerabilities:
                qid = vuln.get("QID", "")
                if not qid:
                    continue

                if qid not in vuln_groups:
                    vuln_groups[qid] = {"vuln_data": vuln, "affected_assets": [], "details": glossary.get(qid, {})}

                vuln_groups[qid]["affected_assets"].append(asset_id)

        return vuln_groups

    def _build_issue_description(self, details: Dict, affected_assets: List[str]) -> str:
        """
        Build issue description with consequence, diagnosis, and affected assets.

        :param Dict details: Vulnerability details from glossary
        :param List[str] affected_assets: List of affected asset identifiers
        :return: Formatted description string
        :rtype: str
        """
        consequence = details.get("CONSEQUENCE", "")
        diagnosis = details.get("DIAGNOSIS", "")
        description_parts = [part for part in [consequence, diagnosis] if part]
        description = HTML_BREAK.join(description_parts) if description_parts else DEFAULT_DESCRIPTION

        # Add affected assets to description
        description += (
            f"{HTML_BREAK}{HTML_BREAK}Affected Assets ({len(affected_assets)}): {', '.join(affected_assets[:10])}"
        )
        if len(affected_assets) > 10:
            description += f" and {len(affected_assets) - 10} more"

        return description

    def _map_severity(self, severity_level: str) -> str:
        """
        Map Qualys severity level to RegScale severity.

        :param str severity_level: Qualys severity level (1-5)
        :return: RegScale severity string
        :rtype: str
        """
        severity_map = {"5": "Critical", "4": "High", "3": "Moderate", "2": "Low", "1": "Low"}
        return severity_map.get(str(severity_level), "Moderate")

    def _create_issue_from_vuln_group(
        self, qid: str, group_data: Dict, regscale_ssp_id: int, due_date_handler: "DueDateHandler"
    ) -> Issue:
        """
        Create an Issue object from a vulnerability group.

        :param str qid: Qualys ID for the vulnerability
        :param Dict group_data: Grouped vulnerability data
        :param int regscale_ssp_id: RegScale Security Plan ID
        :param DueDateHandler due_date_handler: Handler for due date calculation
        :return: Issue object
        :rtype: Issue
        """
        vuln = group_data["vuln_data"]
        details = group_data["details"]
        affected_assets = group_data["affected_assets"]

        severity = self._map_severity(vuln.get("SEVERITY", "3"))
        title = details.get("TITLE", f"Vulnerability QID {qid}")
        description = self._build_issue_description(details, affected_assets)
        due_date = due_date_handler.calculate_due_date(severity)

        # Build Issue kwargs with required fields
        issue_kwargs = {
            "title": title,
            "description": description,
            "issueOwnerId": self.user_id,
            "status": self.default_status,
            "severityLevel": severity,
            "qualysId": qid,
            "dueDate": due_date.strftime("%Y-%m-%d") if due_date else None,
            "identification": "Vulnerability Assessment",
            "parentId": regscale_ssp_id,
            "parentModule": self.parent_module,
        }

        # Add conditional fields
        if self.parent_module == "securityplans":
            issue_kwargs["securityPlanId"] = regscale_ssp_id
        if self.include_plugin_id:
            issue_kwargs["pluginId"] = qid
        if self.require_deviation_rationale:
            issue_kwargs["deviationRationale"] = (
                f"Vulnerability QID {qid} identified by Qualys VMDR scan report. "
                f"Affects {len(affected_assets)} asset(s). "
                f"Requires assessment and remediation according to severity level ({severity})."
            )
        solution = details.get("SOLUTION")
        if self.require_recommended_actions and solution:
            issue_kwargs["recommendedActions"] = solution

        # Create Issue and set assetIdentifier after (batch API limitation)
        issue = Issue(**issue_kwargs)
        asset_identifier = affected_assets[0] if affected_assets else ""
        if asset_identifier:
            issue.assetIdentifier = asset_identifier

        return issue

    def convert_report_to_issues(self, report_data: Dict, regscale_ssp_id: int) -> List[Issue]:
        """
        Convert VMDR report vulnerabilities to RegScale Issue objects.

        Groups vulnerabilities by QID to deduplicate across assets. Ensures
        required fields (deviationRationale) and conditional fields (recommendedActions).

        :param Dict report_data: Parsed report data from parse_vmdr_scan_report()
        :param int regscale_ssp_id: RegScale Security Plan ID
        :return: List of Issue objects ready for batch creation
        :rtype: List[Issue]
        """
        logger.info("Converting report vulnerabilities to RegScale Issue objects")

        if not report_data or "hosts" not in report_data:
            logger.warning(MSG_NO_HOSTS_FOUND)
            return []

        # Group vulnerabilities by QID (deduplicate)
        hosts = report_data["hosts"]
        glossary = report_data.get("glossary", {})
        vuln_groups = self._group_vulnerabilities_by_qid(hosts, glossary)

        logger.info(
            "Grouped %s unique vulnerabilities from %s total detections",
            len(vuln_groups),
            sum(len(h.get("VULNERABILITIES", [])) for h in hosts),
        )

        # Create Issue objects
        due_date_handler = DueDateHandler()
        issues = [
            self._create_issue_from_vuln_group(qid, group_data, regscale_ssp_id, due_date_handler)
            for qid, group_data in vuln_groups.items()
        ]

        logger.info("Created %s Issue objects from grouped vulnerabilities", len(issues))
        return issues

    def _build_vulnerability_description(self, details: Dict) -> str:
        """
        Build vulnerability description from consequence and diagnosis.

        :param Dict details: Vulnerability details from glossary
        :return: Formatted description string
        :rtype: str
        """
        consequence = details.get("CONSEQUENCE", "")
        diagnosis = details.get("DIAGNOSIS", "")
        description_parts = [part for part in [consequence, diagnosis] if part]
        return HTML_BREAK.join(description_parts) if description_parts else DEFAULT_DESCRIPTION

    def _get_cvss_scores(self, details: Dict) -> tuple:
        """
        Extract CVSS base and temporal scores from vulnerability details.

        :param Dict details: Vulnerability details from glossary
        :return: Tuple of (cvss_base, cvss_temporal) or (None, None)
        :rtype: tuple
        """
        cvss_base = details.get("CVSS_BASE") or details.get("CVSS3_BASE")
        cvss_temporal = details.get("CVSS_TEMPORAL") or details.get("CVSS3_TEMPORAL")
        return cvss_base, cvss_temporal

    def _create_vulnerability_from_detection(
        self, vuln: Dict, details: Dict, asset_id: str, regscale_ssp_id: int
    ) -> Vulnerability:
        """
        Create a Vulnerability object from detection and glossary details.

        :param Dict vuln: Vulnerability detection data
        :param Dict details: Vulnerability details from glossary
        :param str asset_id: Asset identifier (hostname or IP)
        :param int regscale_ssp_id: RegScale Security Plan ID
        :return: Vulnerability object
        :rtype: Vulnerability
        """
        qid = vuln.get("QID", "")
        severity = self._map_severity(vuln.get("SEVERITY", "3"))
        cvss_base, cvss_temporal = self._get_cvss_scores(details)
        title = details.get("TITLE", f"Vulnerability QID {qid}")
        description = self._build_vulnerability_description(details)
        cve_ids = vuln.get("CVE_ID_LIST", [])
        cve_id = cve_ids[0] if cve_ids else None

        return Vulnerability(
            name=title,
            description=description,
            severity=severity,
            cveId=cve_id,
            cvssScore=float(cvss_base) if cvss_base else None,
            cvssTemporalScore=float(cvss_temporal) if cvss_temporal else None,
            pluginId=qid,
            assetIdentifier=asset_id,
            firstDetected=self._parse_datetime(vuln.get("FIRST_FOUND_DATETIME")),
            lastDetected=self._parse_datetime(vuln.get("LAST_FOUND_DATETIME")),
            status=vuln.get("STATUS", "Active"),
            port=vuln.get("PORT"),
            protocol=vuln.get("PROTOCOL"),
            source=SOURCE_QUALYS_VMDR,
            parentId=regscale_ssp_id,
            parentModule=self.parent_module,
        )

    def convert_report_to_vulnerabilities(self, report_data: Dict, regscale_ssp_id: int) -> List[Vulnerability]:
        """
        Convert VMDR report vulnerabilities to RegScale Vulnerability objects.

        :param Dict report_data: Parsed report data from parse_vmdr_scan_report()
        :param int regscale_ssp_id: RegScale Security Plan ID
        :return: List of Vulnerability objects for batch creation
        :rtype: List[Vulnerability]
        """
        logger.info("Converting report vulnerabilities to RegScale Vulnerability objects")

        if not report_data or "hosts" not in report_data:
            logger.warning(MSG_NO_HOSTS_FOUND)
            return []

        vulnerabilities = []
        hosts = report_data["hosts"]
        glossary = report_data.get("glossary", {})

        for host_data in hosts:
            asset_id = host_data.get("HOSTNAME") or host_data.get("IP")
            vulns = host_data.get("VULNERABILITIES", [])

            for vuln in vulns:
                qid = vuln.get("QID", "")
                if not qid:
                    continue

                # Get enriched details from glossary
                details = glossary.get(qid, {})

                # Create Vulnerability object using helper method
                vulnerability = self._create_vulnerability_from_detection(vuln, details, asset_id, regscale_ssp_id)
                vulnerabilities.append(vulnerability)

        logger.info("Created %s Vulnerability objects", len(vulnerabilities))
        return vulnerabilities

    def _parse_datetime(self, datetime_str: Optional[str]) -> Optional[datetime]:
        """
        Parse Qualys datetime string to Python datetime object.

        :param Optional[str] datetime_str: Datetime string from Qualys (ISO format)
        :return: Parsed datetime or None
        :rtype: Optional[datetime]
        """
        if not datetime_str:
            return None

        try:
            # Qualys uses ISO 8601 format: 2026-01-14T08:00:00Z
            return datetime.fromisoformat(datetime_str.replace("Z", "+00:00"))
        except (ValueError, AttributeError) as e:
            logger.warning("Failed to parse datetime '%s': %s", datetime_str, e)
            return None

    def get_summary_statistics(self, report_data: Dict) -> Dict:
        """
        Generate summary statistics from report data.

        :param Dict report_data: Parsed report data
        :return: Dictionary with summary statistics
        :rtype: Dict
        """
        if not report_data:
            return {"total_hosts": 0, "total_vulnerabilities": 0, "vulnerabilities_by_severity": {}}

        vuln_summary = report_data.get("vulnerability_summary", {})
        total_hosts = vuln_summary.get("total_hosts", 0)
        total_vulns = vuln_summary.get("total_vulnerabilities", 0)

        # Count vulnerabilities by severity
        severity_counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Informational": 0}

        glossary = report_data.get("glossary", {})
        for qid, details in glossary.items():
            severity_level = details.get("SEVERITY_LEVEL", "3")
            severity_map = {"5": "Critical", "4": "High", "3": "Medium", "2": "Low", "1": "Informational"}
            severity = severity_map.get(str(severity_level), "Medium")
            severity_counts[severity] = severity_counts.get(severity, 0) + 1

        return {
            "total_hosts": total_hosts,
            "total_vulnerabilities": total_vulns,
            "vulnerabilities_by_severity": severity_counts,
            "scan_metadata": report_data.get("scan_metadata", {}),
        }
