#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SARIF Converter integration for RegScale CLI"""

import datetime
import logging
from pathlib import Path
from typing import Optional

import click

from regscale.core.app.utils.app_utils import get_current_datetime

logger = logging.getLogger("regscale")

# Supported frameworks for SARIF compliance
SARIF_SUPPORTED_FRAMEWORKS = ["OWASP", "NIST800-53R5"]


@click.group()
def sarif() -> None:
    """SARIF integration - import vulnerabilities or sync compliance data from static analysis tools."""


@sarif.command(name="import")
@click.option(
    "--file_path",
    "-f",
    type=click.Path(exists=True, file_okay=True, dir_okay=True, path_type=Path),
    help="Path to the SARIF file or a directory of files to convert",
    prompt="Enter the path",
    required=True,
)
@click.option(
    "--asset_id",
    "-id",
    type=click.INT,
    help="The RegScale Asset ID # to import the findings to.",
    prompt="RegScale Asset ID",
    required=True,
)
@click.option(
    "--scan_date",
    "-sd",
    type=click.DateTime(formats=["%Y-%m-%d"]),
    help="The scan date of the file.",
    required=False,
    default=get_current_datetime("%Y-%m-%d"),
)
def import_sarif(file_path: Path, asset_id: int, scan_date: Optional[datetime.datetime] = None) -> None:
    """Convert a SARIF file(s) to OCSF format using an API converter."""
    process_sarif_files(file_path, asset_id, scan_date)


def process_sarif_files(file_path: Path, asset_id: int, scan_date: Optional[datetime.datetime]) -> None:
    """
    Process SARIF files for import.

    :param Path file_path: Path to the SARIF file or directory of files
    :param int asset_id: The RegScale Asset ID to import the findings to
    :param Optional[datetime.datetime] scan_date: The scan date of the file
    :return: None
    """
    from regscale.integrations.commercial.sarif.sarif_importer import SarifImporter

    if not scan_date:
        scan_date = get_current_datetime()
    SarifImporter(file_path, asset_id, scan_date=scan_date)


# =============================================================================
# Compliance Sync Commands
# =============================================================================


@sarif.command(name="sync_compliance")
@click.option(
    "--file_path",
    "-f",
    type=click.Path(exists=True, file_okay=True, dir_okay=True, path_type=Path),
    help="Path to the SARIF file or directory of files to analyze for compliance",
    prompt="Enter the path to SARIF file(s)",
    required=True,
)
@click.option(
    "--regscale_ssp_id",
    type=click.INT,
    help="The ID number from RegScale of the System Security Plan",
    prompt="Enter RegScale System Security Plan ID",
    required=True,
)
@click.option(
    "--framework",
    type=click.Choice(SARIF_SUPPORTED_FRAMEWORKS, case_sensitive=False),
    default="OWASP",
    help="Compliance framework to sync. Default: OWASP (OWASP Top 10 2021)",
)
@click.option(
    "--create-issues/--no-create-issues",
    default=True,
    help="Create issues for failed compliance controls. Default: True",
)
@click.option(
    "--update-control-status/--no-update-control-status",
    default=True,
    help="Update control implementation status based on compliance results. Default: True",
)
@click.option(
    "--create-poams",
    "-cp",
    is_flag=True,
    default=False,
    help="Mark created issues as POAMs. Default: False",
)
@click.option(
    "--asset_id",
    "-a",
    type=click.INT,
    help="Optional RegScale Asset ID to associate findings with.",
    required=False,
    default=None,
)
def sync_compliance(
    file_path: Path,
    regscale_ssp_id: int,
    framework: str,
    create_issues: bool,
    update_control_status: bool,
    create_poams: bool,
    asset_id: Optional[int],
) -> None:
    """
    Sync SARIF static analysis compliance data to RegScale.

    This command parses SARIF files from static analysis tools and:
    - Maps findings to security controls (OWASP Top 10 or NIST 800-53)
    - Creates control assessments in RegScale based on SARIF findings
    - Creates issues for failed compliance controls (optional)
    - Updates control implementation status (optional):
      - "Planned" when no findings found (PASS)
      - "In Remediation" when findings occur (FAIL)

    Supported Frameworks:
    - OWASP: OWASP Top 10 2021 (default)
    - NIST800-53R5: NIST 800-53 Rev 5

    The integration maps SARIF findings via CWE IDs to the specified framework's
    controls, allowing for automated compliance assessment updates in RegScale.

    Example:
        regscale sarif sync_compliance -f ./scan-results.sarif --regscale_ssp_id 123

    SARIF files may include CWE references that automatically map to security controls.
    Tools like CodeQL, Semgrep, and other SAST tools produce SARIF-formatted output.
    """
    from regscale.integrations.commercial.sarif.sarif_compliance import SARIFComplianceIntegration

    try:
        logger.info("Starting SARIF compliance sync...")
        logger.info("File path: %s", file_path)
        logger.info("RegScale SSP ID: %d", regscale_ssp_id)
        logger.info("Framework: %s", framework)

        # Create the compliance integration
        integration = SARIFComplianceIntegration(
            plan_id=regscale_ssp_id,
            file_path=file_path,
            framework=framework,
            create_issues=create_issues,
            update_control_status=update_control_status,
            create_poams=create_poams,
            asset_id=asset_id,
        )

        # Run the compliance sync
        integration.sync_compliance()

        logger.info("SARIF compliance sync completed successfully.")

    except Exception as e:
        logger.error("Error during SARIF compliance sync: %s", e, exc_info=True)
        raise click.ClickException(str(e)) from e
