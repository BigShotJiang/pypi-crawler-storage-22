#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SentinelOne CLI commands for RegScale.

This module provides Click commands for syncing SentinelOne data to RegScale.
"""

import logging
import sys

import click

from regscale.models import regscale_id

logger = logging.getLogger("regscale")

# Log message constants
LOG_TARGET_REGSCALE_ID = "Target RegScale ID: %s"
LOG_ERROR_SYNCING_ASSETS = "Error syncing assets: %s"
LOG_ERROR_SYNCING_FINDINGS = "Error syncing findings: %s"
LOG_ERROR_DURING_SYNC = "Error during sync: %s"


@click.group()
def sentinelone():
    """
    SentinelOne Integration.

    Commands for syncing agents (assets), threats, and vulnerabilities
    from SentinelOne to RegScale.

    Configuration in init.yaml:
        sentinelone:
            url: "https://usea1-partners.sentinelone.net"
            token: "your-api-token"
            verify_ssl: true
            timeout: 30
            site_id: ""  # Optional
            account_id: ""  # Optional

    Security Note: For production environments, consider storing the API token
    in environment variables or a secrets manager rather than in init.yaml.
    The CLI supports environment variable overrides for sensitive configuration.
    """
    pass


@sentinelone.command(name="test_connection")
def test_connection():
    """
    Test connection to SentinelOne API.

    Verifies that the configured SentinelOne credentials are valid
    and the API is accessible.
    """
    try:
        from regscale.integrations.commercial.sentinelone.sentinelone_api_client import (
            SentinelOneAPIClient,
            SentinelOneAPIException,
        )
        from regscale.integrations.commercial.sentinelone.variables import (
            SentinelOneConfigurationError,
            SentinelOneVariables,
        )

        logger.info("Testing connection to SentinelOne...")

        # Validate configuration before attempting connection
        try:
            SentinelOneVariables.validate()
        except SentinelOneConfigurationError as e:
            click.echo("Configuration error: %s" % str(e), err=True)
            sys.exit(1)

        client = SentinelOneAPIClient(
            base_url=SentinelOneVariables.sentineloneUrl,
            api_token=SentinelOneVariables.sentineloneToken,
            verify_ssl=SentinelOneVariables.sentineloneVerifySsl,
            timeout=SentinelOneVariables.sentineloneTimeout,
        )

        if client.test_connection():
            system_info = client.get_system_info()
            build = system_info.get("build", "Unknown")
            logger.info("Successfully connected to SentinelOne")
            click.echo("Successfully connected to SentinelOne (build: %s)" % build)
        else:
            logger.error("Failed to connect to SentinelOne")
            click.echo("Failed to connect to SentinelOne", err=True)
            sys.exit(1)

    except SentinelOneAPIException as e:
        logger.error("SentinelOne API error: %s", str(e))
        click.echo("Error connecting to SentinelOne: %s" % str(e), err=True)
        sys.exit(1)
    except Exception as e:
        logger.error("Unexpected error testing SentinelOne connection: %s", str(e))
        click.echo("Error: %s" % str(e), err=True)
        sys.exit(1)


@sentinelone.command(name="sync_assets")
@regscale_id(help="RegScale will create and update assets as children of this record.")
def sync_assets(regscale_id: int):
    """
    Sync SentinelOne agents to RegScale assets.

    Fetches all agents from SentinelOne and synchronizes them as assets
    into the specified RegScale record.
    """
    try:
        from regscale.integrations.commercial.sentinelone.scanner import (
            SentinelOneScanner,
        )
        from regscale.integrations.commercial.sentinelone.sentinelone_api_client import (
            SentinelOneAPIException,
        )

        logger.info("Starting SentinelOne asset synchronization...")
        logger.info(LOG_TARGET_REGSCALE_ID, regscale_id)

        SentinelOneScanner.sync_assets(plan_id=regscale_id)

        logger.info("SentinelOne asset synchronization complete.")
        click.echo("SentinelOne asset synchronization complete.")

    except SentinelOneAPIException as e:
        logger.error("SentinelOne API error during asset sync: %s", str(e))
        click.echo(LOG_ERROR_SYNCING_ASSETS % str(e), err=True)
        sys.exit(1)
    except Exception as e:
        logger.error(LOG_ERROR_SYNCING_ASSETS, str(e), exc_info=True)
        click.echo(LOG_ERROR_SYNCING_ASSETS % str(e), err=True)
        sys.exit(1)


@sentinelone.command(name="sync_findings")
@regscale_id(help="RegScale will create and update findings as children of this record.")
@click.option(
    "--include-threats/--no-include-threats",
    default=True,
    help="Include threat detections (default: True).",
)
@click.option(
    "--include-vulnerabilities/--no-include-vulnerabilities",
    default=True,
    help="Include CVE vulnerabilities from Ranger (default: True).",
)
def sync_findings(regscale_id: int, include_threats: bool, include_vulnerabilities: bool):
    """
    Sync SentinelOne threats and vulnerabilities to RegScale.

    Fetches threats and optionally vulnerabilities from SentinelOne,
    then synchronizes them as findings into the specified RegScale record.
    """
    try:
        from regscale.integrations.commercial.sentinelone.scanner import (
            SentinelOneScanner,
        )
        from regscale.integrations.commercial.sentinelone.sentinelone_api_client import (
            SentinelOneAPIException,
        )

        logger.info("Starting SentinelOne findings synchronization...")
        logger.info(LOG_TARGET_REGSCALE_ID, regscale_id)
        logger.info("Include threats: %s", include_threats)
        logger.info("Include vulnerabilities: %s", include_vulnerabilities)

        SentinelOneScanner.sync_findings(
            plan_id=regscale_id,
            include_threats=include_threats,
            include_vulnerabilities=include_vulnerabilities,
        )

        logger.info("SentinelOne findings synchronization complete.")
        click.echo("SentinelOne findings synchronization complete.")

    except SentinelOneAPIException as e:
        logger.error("SentinelOne API error during findings sync: %s", str(e))
        click.echo(LOG_ERROR_SYNCING_FINDINGS % str(e), err=True)
        sys.exit(1)
    except Exception as e:
        logger.error(LOG_ERROR_SYNCING_FINDINGS, str(e), exc_info=True)
        click.echo(LOG_ERROR_SYNCING_FINDINGS % str(e), err=True)
        sys.exit(1)


@sentinelone.command(name="sync_threats")
@regscale_id(help="RegScale will create and update threats as children of this record.")
@click.option(
    "--resolved/--no-resolved",
    default=None,
    help="Filter by resolved status (default: all threats).",
)
def sync_threats(regscale_id: int, resolved):
    """
    Sync only threat detections from SentinelOne.

    Fetches threat detections from SentinelOne and synchronizes them
    as findings into the specified RegScale record.
    """
    try:
        from regscale.integrations.commercial.sentinelone.scanner import (
            SentinelOneScanner,
        )
        from regscale.integrations.commercial.sentinelone.sentinelone_api_client import (
            SentinelOneAPIException,
        )

        logger.info("Starting SentinelOne threat synchronization...")
        logger.info(LOG_TARGET_REGSCALE_ID, regscale_id)

        SentinelOneScanner.sync_findings(
            plan_id=regscale_id,
            include_threats=True,
            include_vulnerabilities=False,
            resolved=resolved,
        )

        logger.info("SentinelOne threat synchronization complete.")
        click.echo("SentinelOne threat synchronization complete.")

    except SentinelOneAPIException as e:
        logger.error("SentinelOne API error during threat sync: %s", str(e))
        click.echo(LOG_ERROR_SYNCING_FINDINGS % str(e), err=True)
        sys.exit(1)
    except Exception as e:
        logger.error(LOG_ERROR_SYNCING_FINDINGS, str(e), exc_info=True)
        click.echo(LOG_ERROR_SYNCING_FINDINGS % str(e), err=True)
        sys.exit(1)


@sentinelone.command(name="sync_vulnerabilities")
@regscale_id(help="RegScale will create and update vulnerabilities as children of this record.")
def sync_vulnerabilities(regscale_id: int):
    """
    Sync only CVE vulnerabilities from SentinelOne Ranger.

    Fetches vulnerabilities from SentinelOne Ranger module and synchronizes
    them as findings into the specified RegScale record.
    """
    try:
        from regscale.integrations.commercial.sentinelone.scanner import (
            SentinelOneScanner,
        )
        from regscale.integrations.commercial.sentinelone.sentinelone_api_client import (
            SentinelOneAPIException,
        )

        logger.info("Starting SentinelOne vulnerability synchronization...")
        logger.info(LOG_TARGET_REGSCALE_ID, regscale_id)

        SentinelOneScanner.sync_findings(
            plan_id=regscale_id,
            include_threats=False,
            include_vulnerabilities=True,
        )

        logger.info("SentinelOne vulnerability synchronization complete.")
        click.echo("SentinelOne vulnerability synchronization complete.")

    except SentinelOneAPIException as e:
        logger.error("SentinelOne API error during vulnerability sync: %s", str(e))
        click.echo(LOG_ERROR_SYNCING_FINDINGS % str(e), err=True)
        sys.exit(1)
    except Exception as e:
        logger.error(LOG_ERROR_SYNCING_FINDINGS, str(e), exc_info=True)
        click.echo(LOG_ERROR_SYNCING_FINDINGS % str(e), err=True)
        sys.exit(1)


@sentinelone.command(name="sync_all")
@regscale_id(help="RegScale will create and update assets and findings as children of this record.")
@click.option(
    "--include-vulnerabilities/--no-include-vulnerabilities",
    default=True,
    help="Include CVE vulnerabilities from Ranger (default: True).",
)
def sync_all(regscale_id: int, include_vulnerabilities: bool):
    """
    Sync all SentinelOne data to RegScale.

    Synchronizes both assets (agents) and findings (threats and
    vulnerabilities) from SentinelOne to the specified RegScale record.
    """
    try:
        from regscale.integrations.commercial.sentinelone.scanner import (
            SentinelOneScanner,
        )
        from regscale.integrations.commercial.sentinelone.sentinelone_api_client import (
            SentinelOneAPIException,
        )

        logger.info("Starting full SentinelOne synchronization...")
        logger.info(LOG_TARGET_REGSCALE_ID, regscale_id)

        # Sync assets first
        logger.info("Syncing agents (assets)...")
        SentinelOneScanner.sync_assets(plan_id=regscale_id)

        # Then sync findings
        logger.info("Syncing findings (threats and vulnerabilities)...")
        SentinelOneScanner.sync_findings(
            plan_id=regscale_id,
            include_threats=True,
            include_vulnerabilities=include_vulnerabilities,
        )

        logger.info("Full SentinelOne synchronization complete.")
        click.echo("Full SentinelOne synchronization complete.")

    except SentinelOneAPIException as e:
        logger.error("SentinelOne API error during sync: %s", str(e))
        click.echo(LOG_ERROR_DURING_SYNC % str(e), err=True)
        sys.exit(1)
    except Exception as e:
        logger.error(LOG_ERROR_DURING_SYNC, str(e), exc_info=True)
        click.echo(LOG_ERROR_DURING_SYNC % str(e), err=True)
        sys.exit(1)
