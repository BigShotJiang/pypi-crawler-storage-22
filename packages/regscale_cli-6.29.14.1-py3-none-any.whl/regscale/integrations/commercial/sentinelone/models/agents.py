#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SentinelOne Agent model for RegScale integration.

This module defines the SentinelOneAgent dataclass for representing
endpoint agents from SentinelOne and converting them to IntegrationAsset.
"""

import dataclasses
import logging
from typing import Any, Dict, List, Optional

from regscale.models import regscale_models

logger = logging.getLogger("regscale")


@dataclasses.dataclass
class SentinelOneAgent:
    """
    Represents a SentinelOne agent/endpoint.

    Maps SentinelOne agent data to IntegrationAsset format.
    """

    # Core identification
    agent_id: str
    computer_name: str
    uuid: str

    # Network information
    external_ip: Optional[str] = None
    last_ip_to_mgmt: Optional[str] = None
    network_interfaces: Optional[List[Dict[str, Any]]] = None

    # System information
    os_name: Optional[str] = None
    os_type: Optional[str] = None
    os_version: Optional[str] = None
    os_arch: Optional[str] = None
    machine_type: Optional[str] = None
    model_name: Optional[str] = None

    # Agent information
    agent_version: Optional[str] = None
    is_active: bool = True
    is_infected: bool = False
    is_up_to_date: bool = True
    is_pending_uninstall: bool = False

    # Status
    network_status: Optional[str] = None
    scan_status: Optional[str] = None
    threat_reboot_required: bool = False
    ranger_status: Optional[str] = None

    # Location/Organization
    site_id: Optional[str] = None
    site_name: Optional[str] = None
    group_id: Optional[str] = None
    group_name: Optional[str] = None
    account_id: Optional[str] = None
    account_name: Optional[str] = None
    domain: Optional[str] = None

    # Timestamps
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    last_active_date: Optional[str] = None
    registered_at: Optional[str] = None

    # Hardware
    cpu_count: Optional[int] = None
    cpu_id: Optional[str] = None
    core_count: Optional[int] = None
    total_memory: Optional[int] = None
    memory_mb: Optional[int] = None

    # Cloud identifiers
    cloud_providers: Optional[Dict[str, Any]] = None

    # Raw data for reference
    raw_data: Optional[Dict[str, Any]] = None

    @classmethod
    def from_sentinelone_data(cls, data: Dict[str, Any]) -> "SentinelOneAgent":
        """
        Create SentinelOneAgent from SentinelOne API response data.

        Args:
            data: Agent data from SentinelOne API

        Returns:
            SentinelOneAgent instance
        """
        return cls(
            agent_id=data.get("id", ""),
            computer_name=data.get("computerName", "Unknown"),
            uuid=data.get("uuid", ""),
            external_ip=data.get("externalIp"),
            last_ip_to_mgmt=data.get("lastIpToMgmt"),
            network_interfaces=data.get("networkInterfaces", []),
            os_name=data.get("osName"),
            os_type=data.get("osType"),
            os_version=data.get("osRevision"),
            os_arch=data.get("osArch"),
            machine_type=data.get("machineType"),
            model_name=data.get("modelName"),
            agent_version=data.get("agentVersion"),
            is_active=data.get("isActive", True),
            is_infected=data.get("infected", False),
            is_up_to_date=data.get("isUpToDate", True),
            is_pending_uninstall=data.get("isPendingUninstall", False),
            network_status=data.get("networkStatus"),
            scan_status=data.get("scanStatus"),
            threat_reboot_required=data.get("threatRebootRequired", False),
            ranger_status=data.get("rangerStatus"),
            site_id=data.get("siteId"),
            site_name=data.get("siteName"),
            group_id=data.get("groupId"),
            group_name=data.get("groupName"),
            account_id=data.get("accountId"),
            account_name=data.get("accountName"),
            domain=data.get("domain"),
            created_at=data.get("createdAt"),
            updated_at=data.get("updatedAt"),
            last_active_date=data.get("lastActiveDate"),
            registered_at=data.get("registeredAt"),
            cpu_count=data.get("cpuCount"),
            cpu_id=data.get("cpuId"),
            core_count=data.get("coreCount"),
            total_memory=data.get("totalMemory"),
            memory_mb=data.get("memorySize"),
            cloud_providers=data.get("cloudProviders"),
            raw_data=data,
        )

    def get_unique_identifier(self) -> str:
        """
        Get unique identifier for the agent.

        Returns:
            Unique identifier string
        """
        return "s1-%s-%s" % (self.agent_id, self.uuid[:8] if self.uuid else "unknown")

    def get_primary_ip(self) -> Optional[str]:
        """
        Get primary IP address for the agent.

        Returns:
            IP address string or None
        """
        # Prefer external IP, then last IP to management
        if self.external_ip:
            return self.external_ip
        if self.last_ip_to_mgmt:
            return self.last_ip_to_mgmt

        return self._get_ip_from_interfaces()

    def _get_ip_from_interfaces(self) -> Optional[str]:
        """
        Extract first IP from network interfaces.

        Returns:
            IP address string or None if no interfaces available
        """
        if not self.network_interfaces:
            return None

        for iface in self.network_interfaces:
            ip_addr = self._extract_ip_from_interface(iface)
            if ip_addr:
                return ip_addr
        return None

    def _extract_ip_from_interface(self, iface: Dict[str, Any]) -> Optional[str]:
        """
        Extract IP address from a single interface.

        Args:
            iface: Network interface dictionary from SentinelOne API

        Returns:
            IP address string or None if no address found
        """
        inet = iface.get("inet", [])
        if inet:
            return inet[0]
        inet6 = iface.get("inet6", [])
        if inet6:
            return inet6[0]
        return None

    def get_primary_mac(self) -> Optional[str]:
        """
        Get primary MAC address for the agent.

        Returns:
            MAC address string or None
        """
        if self.network_interfaces:
            for iface in self.network_interfaces:
                physical = iface.get("physical")
                if physical:
                    return physical
        return None

    def get_fqdn(self) -> Optional[str]:
        """
        Build FQDN from computer name and domain.

        Returns:
            FQDN string or None
        """
        if self.domain and self.computer_name:
            return "%s.%s" % (self.computer_name, self.domain)
        return self.computer_name

    def get_asset_type(self) -> str:
        """
        Determine asset type based on machine type.

        Returns:
            Asset type string
        """
        machine_type_map = {
            "desktop": "Desktop",
            "laptop": "Laptop",
            "server": "Physical Server",
            "virtual machine": "Virtual Machine (VM)",
            "kubernetes node": "Virtual Machine (VM)",
        }

        if self.machine_type:
            machine_lower = self.machine_type.lower()
            for key, value in machine_type_map.items():
                if key in machine_lower:
                    return value

        return "Other"

    def get_operating_system(self) -> Optional[regscale_models.AssetOperatingSystem]:
        """
        Map OS type to RegScale AssetOperatingSystem.

        Returns:
            AssetOperatingSystem enum value
        """
        if not self.os_type:
            return None

        os_type_lower = self.os_type.lower()

        if "windows" in os_type_lower:
            return self._get_windows_os_type()
        if "linux" in os_type_lower:
            return regscale_models.AssetOperatingSystem.Linux
        if "macos" in os_type_lower or "osx" in os_type_lower:
            return regscale_models.AssetOperatingSystem.MacOSX

        return None

    def _get_windows_os_type(self) -> regscale_models.AssetOperatingSystem:
        """
        Determine if Windows is server or desktop.

        Returns:
            WindowsServer or WindowsDesktop based on machine type/OS name
        """
        is_server = self._is_windows_server()
        if is_server:
            return regscale_models.AssetOperatingSystem.WindowsServer
        return regscale_models.AssetOperatingSystem.WindowsDesktop

    def _is_windows_server(self) -> bool:
        """
        Check if this is a Windows Server based on machine type or OS name.

        Returns:
            True if machine type or OS name indicates server, False otherwise
        """
        if self.machine_type and "server" in self.machine_type.lower():
            return True
        if self.os_name and "server" in self.os_name.lower():
            return True
        return False

    def get_status(self) -> regscale_models.AssetStatus:
        """
        Determine asset status based on agent state.

        Returns:
            AssetStatus enum value
        """
        if self.is_pending_uninstall:
            return regscale_models.AssetStatus.Decommissioned
        if not self.is_active:
            return regscale_models.AssetStatus.Inactive
        if self.network_status == "disconnected":
            return regscale_models.AssetStatus.Inactive

        return regscale_models.AssetStatus.Active

    def get_description(self) -> str:
        """
        Build description for the asset.

        Returns:
            Description string
        """
        parts = []

        if self.os_name:
            parts.append("OS: %s" % self.os_name)
        if self.agent_version:
            parts.append("Agent: %s" % self.agent_version)
        if self.site_name:
            parts.append("Site: %s" % self.site_name)
        if self.group_name:
            parts.append("Group: %s" % self.group_name)
        if self.is_infected:
            parts.append("STATUS: INFECTED")

        return " | ".join(parts) if parts else "SentinelOne Managed Endpoint"

    def get_ram_mb(self) -> Optional[int]:
        """
        Get RAM in megabytes.

        Returns:
            RAM in MB or None
        """
        if self.total_memory:
            # total_memory is in bytes
            return self.total_memory // (1024 * 1024)
        if self.memory_mb:
            return self.memory_mb
        return None

    def get_cloud_identifier(self, provider: str) -> Optional[str]:
        """
        Get cloud provider identifier.

        Args:
            provider: Cloud provider name (aws, azure, gcp)

        Returns:
            Cloud identifier or None
        """
        if not self.cloud_providers:
            return None

        provider_data = self.cloud_providers.get(provider, {})
        return provider_data.get("instanceId") or provider_data.get("vmId")
