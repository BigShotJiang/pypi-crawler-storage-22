#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SentinelOne Vulnerability model for RegScale integration.

This module defines the SentinelOneVulnerability dataclass for representing
CVE vulnerabilities from SentinelOne Ranger and converting them to IntegrationFinding.
"""

import dataclasses
import logging
from typing import Any, Dict, List, Optional

from regscale.models import regscale_models

logger = logging.getLogger("regscale")


@dataclasses.dataclass
class SentinelOneVulnerability:
    """
    Represents a SentinelOne vulnerability (from Ranger CVE).

    Maps SentinelOne vulnerability data to IntegrationFinding format.
    """

    # Core identification
    cve_id: str
    vuln_id: Optional[str] = None

    # Severity
    severity: Optional[str] = None
    cvss_score: Optional[float] = None
    cvss_vector: Optional[str] = None

    # Application information
    application_name: Optional[str] = None
    application_vendor: Optional[str] = None
    application_version: Optional[str] = None
    application_type: Optional[str] = None

    # Affected agents
    affected_agents_count: int = 0
    affected_agent_ids: Optional[List[str]] = None

    # Remediation
    remediation_status: Optional[str] = None
    remediation_type: Optional[str] = None
    patch_available: bool = False
    fixed_version: Optional[str] = None

    # Details
    description: Optional[str] = None
    references: Optional[List[str]] = None
    published_date: Optional[str] = None

    # Detection
    first_detected: Optional[str] = None
    last_detected: Optional[str] = None

    # Location
    site_id: Optional[str] = None
    site_name: Optional[str] = None
    account_id: Optional[str] = None
    account_name: Optional[str] = None

    # Raw data
    raw_data: Optional[Dict[str, Any]] = None

    @classmethod
    def from_sentinelone_data(cls, data: Dict[str, Any]) -> "SentinelOneVulnerability":
        """
        Create SentinelOneVulnerability from SentinelOne API response data.

        Args:
            data: Vulnerability data from SentinelOne API

        Returns:
            SentinelOneVulnerability instance
        """
        return cls(
            cve_id=data.get("cveId", ""),
            vuln_id=data.get("id"),
            severity=data.get("severity"),
            cvss_score=data.get("cvssScore"),
            cvss_vector=data.get("cvssVector"),
            application_name=data.get("applicationName"),
            application_vendor=data.get("applicationVendor"),
            application_version=data.get("applicationVersion"),
            application_type=data.get("applicationType"),
            affected_agents_count=data.get("affectedAgentsCount", 0),
            affected_agent_ids=data.get("affectedAgentIds", []),
            remediation_status=data.get("remediationStatus"),
            remediation_type=data.get("remediationType"),
            patch_available=data.get("patchAvailable", False),
            fixed_version=data.get("fixedVersion"),
            description=data.get("description"),
            references=data.get("references", []),
            published_date=data.get("publishedDate"),
            first_detected=data.get("firstDetected") or data.get("createdAt"),
            last_detected=data.get("lastDetected") or data.get("updatedAt"),
            site_id=data.get("siteId"),
            site_name=data.get("siteName"),
            account_id=data.get("accountId"),
            account_name=data.get("accountName"),
            raw_data=data,
        )

    def get_severity(self) -> regscale_models.IssueSeverity:
        """
        Map vulnerability severity to RegScale severity.

        Uses CVSS score if available, otherwise maps severity string.

        Returns:
            IssueSeverity enum value
        """
        severity = self._get_severity_from_cvss()
        if severity:
            return severity

        severity = self._get_severity_from_string()
        if severity:
            return severity

        return regscale_models.IssueSeverity.Moderate

    def _get_severity_from_cvss(self) -> Optional[regscale_models.IssueSeverity]:
        """
        Map CVSS score to severity.

        Uses standard CVSS v3 severity thresholds:
        - Critical: 9.0+
        - High: 7.0-8.9
        - Medium: 4.0-6.9
        - Low: 0.0-3.9

        Returns:
            IssueSeverity based on CVSS score, or None if no score available
        """
        if self.cvss_score is None:
            return None

        if self.cvss_score >= 9.0:
            return regscale_models.IssueSeverity.Critical
        if self.cvss_score >= 7.0:
            return regscale_models.IssueSeverity.High
        if self.cvss_score >= 4.0:
            return regscale_models.IssueSeverity.Moderate
        return regscale_models.IssueSeverity.Low

    def _get_severity_from_string(self) -> Optional[regscale_models.IssueSeverity]:
        """
        Map severity string to RegScale severity.

        Returns:
            IssueSeverity based on severity string, or None if no severity set
        """
        if not self.severity:
            return None

        severity_map = {
            "critical": regscale_models.IssueSeverity.Critical,
            "high": regscale_models.IssueSeverity.High,
            "medium": regscale_models.IssueSeverity.Moderate,
            "low": regscale_models.IssueSeverity.Low,
            "informational": regscale_models.IssueSeverity.Low,
        }

        severity_lower = self.severity.lower()
        for key, value in severity_map.items():
            if key in severity_lower:
                return value
        return None

    def get_status(self) -> regscale_models.IssueStatus:
        """
        Map remediation status to RegScale issue status.

        Returns:
            IssueStatus enum value
        """
        closed_statuses = {"remediated", "fixed", "patched", "resolved"}

        if self.remediation_status:
            if self.remediation_status.lower() in closed_statuses:
                return regscale_models.IssueStatus.Closed

        return regscale_models.IssueStatus.Open

    def get_external_id(self) -> str:
        """
        Get unique external ID for deduplication.

        Returns:
            External ID string
        """
        # Include application info for better deduplication
        app_part = self.application_name[:20] if self.application_name else "unknown"
        return "s1-vuln-%s-%s" % (self.cve_id, app_part.replace(" ", "_").lower())

    def get_title(self) -> str:
        """
        Build title for the finding.

        Returns:
            Title string
        """
        parts = [self.cve_id]

        if self.application_name:
            parts.append("in %s" % self.application_name)
            if self.application_version:
                parts.append("(%s)" % self.application_version)

        return " ".join(parts)

    def get_description(self) -> str:
        """
        Build description for the finding.

        Returns:
            Description string
        """
        lines = []

        lines.append("SentinelOne Vulnerability Detection")
        lines.append("")

        if self.description:
            lines.append(self.description)
            lines.append("")

        if self.cvss_score is not None:
            lines.append("CVSS Score: %.1f" % self.cvss_score)
        if self.cvss_vector:
            lines.append("CVSS Vector: %s" % self.cvss_vector)
        if self.severity:
            lines.append("Severity: %s" % self.severity)

        lines.append("")

        if self.application_name:
            lines.append("Application: %s" % self.application_name)
        if self.application_vendor:
            lines.append("Vendor: %s" % self.application_vendor)
        if self.application_version:
            lines.append("Version: %s" % self.application_version)

        if self.affected_agents_count > 0:
            lines.append("")
            lines.append("Affected Endpoints: %d" % self.affected_agents_count)

        if self.references:
            lines.append("")
            lines.append("References:")
            for ref in self.references[:5]:  # Limit to 5
                lines.append("  - %s" % ref)

        return "\n".join(lines)

    def get_remediation(self) -> str:
        """
        Build remediation guidance.

        Returns:
            Remediation string
        """
        lines = []

        if self.patch_available:
            lines.append("Patch Available: Yes")
            if self.fixed_version:
                lines.append("Fixed Version: %s" % self.fixed_version)
        else:
            lines.append("Patch Available: No")

        if self.remediation_type:
            lines.append("Remediation Type: %s" % self.remediation_type)

        if self.remediation_status:
            lines.append("Current Status: %s" % self.remediation_status)

        if not lines:
            lines.append(
                "Update %s to the latest version to remediate this vulnerability."
                % (self.application_name or "the affected application")
            )

        return "\n".join(lines)

    def get_affected_asset_identifiers(self) -> List[str]:
        """
        Get list of affected asset identifiers.

        Returns:
            List of asset identifier strings
        """
        identifiers = []
        if self.affected_agent_ids:
            for agent_id in self.affected_agent_ids:
                identifiers.append("s1-%s-unknown" % agent_id)
        return identifiers
