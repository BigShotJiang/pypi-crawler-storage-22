#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SentinelOne Scanner Integration for RegScale.

This module provides the SentinelOneScanner class that fetches agents,
threats, and vulnerabilities from SentinelOne and syncs them to RegScale.
"""

import logging
from typing import Dict, Generator, Optional

from regscale.core.app.application import Application  # noqa: F401
from regscale.integrations.commercial.sentinelone.models.agents import SentinelOneAgent
from regscale.integrations.commercial.sentinelone.models.threats import SentinelOneThreat
from regscale.integrations.commercial.sentinelone.models.vulnerabilities import (
    SentinelOneVulnerability,
)
from regscale.integrations.commercial.sentinelone.sentinelone_api_client import (
    SentinelOneAPIClient,
    SentinelOneAPIException,
)
from regscale.integrations.commercial.sentinelone.variables import SentinelOneVariables
from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
    ScannerIntegrationType,
)

logger = logging.getLogger("regscale")


def agent_to_integration_asset(agent: SentinelOneAgent) -> IntegrationAsset:
    """
    Convert SentinelOneAgent to IntegrationAsset.

    Args:
        agent: SentinelOneAgent instance

    Returns:
        IntegrationAsset for use with ScannerIntegration
    """
    return IntegrationAsset(
        name=agent.computer_name,
        identifier=agent.get_unique_identifier(),
        asset_type=agent.get_asset_type(),
        asset_category="Hardware",
        ip_address=agent.get_primary_ip() or "",
        mac_address=agent.get_primary_mac() or "",
        fqdn=agent.get_fqdn(),
        operating_system=agent.get_operating_system(),
        os_version=agent.os_version,
        status=agent.get_status(),
        description=agent.get_description(),
        is_virtual=agent.machine_type == "virtual machine" if agent.machine_type else False,
        ram=agent.get_ram_mb(),
        cpu=agent.core_count or agent.cpu_count,
        model=agent.model_name,
        software_version=agent.agent_version,
        software_name="SentinelOne Agent",
        software_vendor="SentinelOne",
        location=agent.site_name,
        other_tracking_number=agent.get_unique_identifier(),
        aws_identifier=agent.get_cloud_identifier("aws"),
        azure_identifier=agent.get_cloud_identifier("azure"),
        google_identifier=agent.get_cloud_identifier("gcp"),
        external_id=agent.agent_id,
        scanning_tool="SentinelOne",
    )


def threat_to_integration_finding(threat: SentinelOneThreat) -> IntegrationFinding:
    """
    Convert SentinelOneThreat to IntegrationFinding.

    Args:
        threat: SentinelOneThreat instance

    Returns:
        IntegrationFinding for use with ScannerIntegration
    """
    return IntegrationFinding(
        control_labels=[],
        title=threat.get_title(),
        category="Threat",
        plugin_name="SentinelOne",
        plugin_id=threat.threat_id,
        severity=threat.get_severity(),
        description=threat.get_description(),
        status=threat.get_status(),
        asset_identifier=threat.get_asset_identifier(),
        external_id=threat.get_external_id(),
        first_seen=threat.identified_at or threat.created_at,
        last_seen=threat.updated_at,
        remediation=threat.get_remediation(),
        source_report="SentinelOne Threat Detection",
    )


def vulnerability_to_integration_finding(
    vuln: SentinelOneVulnerability,
    asset_identifier: str = "",
) -> IntegrationFinding:
    """
    Convert SentinelOneVulnerability to IntegrationFinding.

    Args:
        vuln: SentinelOneVulnerability instance
        asset_identifier: Optional asset identifier to link

    Returns:
        IntegrationFinding for use with ScannerIntegration
    """
    return IntegrationFinding(
        control_labels=[],
        title=vuln.get_title(),
        category="Vulnerability",
        plugin_name="SentinelOne Ranger",
        plugin_id=vuln.vuln_id or vuln.cve_id,
        severity=vuln.get_severity(),
        description=vuln.get_description(),
        status=vuln.get_status(),
        cve=vuln.cve_id if vuln.cve_id.startswith("CVE-") else None,
        cvss_v3_score=vuln.cvss_score,
        cvss_v3_vector=vuln.cvss_vector,
        asset_identifier=asset_identifier,
        external_id=vuln.get_external_id(),
        first_seen=vuln.first_detected,
        last_seen=vuln.last_detected,
        remediation=vuln.get_remediation(),
        source_report="SentinelOne Ranger Vulnerability",
        installed_versions=vuln.application_version,
        fixed_versions=vuln.fixed_version,
    )


class SentinelOneScanner(ScannerIntegration):
    """
    SentinelOne Scanner Integration for RegScale.

    Fetches agents (assets), threats, and vulnerabilities from SentinelOne
    and syncs them to RegScale.
    """

    title = "SentinelOne"
    type = ScannerIntegrationType.VULNERABILITY

    def __init__(self, *args, **kwargs):
        """
        Initialize the SentinelOne Scanner Integration.

        Args:
            *args: Arguments to pass to parent class
            **kwargs: Keyword arguments to pass to parent class
        """
        super().__init__(*args, **kwargs)

        self.app = Application()

        # Initialize API client
        self.api_client = SentinelOneAPIClient(
            base_url=SentinelOneVariables.sentineloneUrl,
            api_token=SentinelOneVariables.sentineloneToken,
            verify_ssl=SentinelOneVariables.sentineloneVerifySsl,
            timeout=SentinelOneVariables.sentineloneTimeout,
            site_id=SentinelOneVariables.sentineloneSiteId or None,
            account_id=SentinelOneVariables.sentineloneAccountId or None,
        )

        # Cache for agent data
        self._agent_cache: Dict[str, SentinelOneAgent] = {}

        # Configuration
        self.page_size = SentinelOneVariables.sentinelonePageSize

    def fetch_assets(self, **kwargs) -> Generator[IntegrationAsset, None, None]:
        """
        Fetch assets (agents) from SentinelOne.

        Yields:
            IntegrationAsset objects for each SentinelOne agent
        """
        logger.info("Fetching agents from SentinelOne...")

        try:
            agent_count = 0

            for agent_data in self.api_client.iter_agents(page_size=self.page_size):
                try:
                    agent = SentinelOneAgent.from_sentinelone_data(agent_data)
                    # Cache agent for threat/vulnerability correlation
                    self._agent_cache[agent.agent_id] = agent
                    agent_count += 1
                    yield agent_to_integration_asset(agent)
                except (KeyError, TypeError, ValueError) as e:
                    computer_name = agent_data.get("computerName", "Unknown")
                    logger.warning("Failed to process agent %s: %s", computer_name, str(e))

            self.num_assets_to_process = agent_count
            logger.info("Processed %s agents from SentinelOne", agent_count)

        except SentinelOneAPIException as e:
            logger.error("Failed to fetch agents from SentinelOne: %s", str(e))

    def fetch_findings(self, **kwargs) -> Generator[IntegrationFinding, None, None]:
        """
        Fetch findings from SentinelOne.

        Yields threats and optionally vulnerabilities.

        Kwargs:
            include_threats: Whether to include threat detections (default: True)
            include_vulnerabilities: Whether to include CVE vulnerabilities (default: True)
            resolved: Filter for resolved threats (default: None - all threats)

        Yields:
            IntegrationFinding objects for each finding
        """
        logger.info("Fetching findings from SentinelOne...")

        include_threats = kwargs.get("include_threats", True)
        include_vulnerabilities = kwargs.get("include_vulnerabilities", True)
        resolved = kwargs.get("resolved")

        findings_count = 0

        if include_threats:
            for finding in self._fetch_threats(resolved=resolved):
                findings_count += 1
                yield finding

        if include_vulnerabilities:
            for finding in self._fetch_vulnerabilities():
                findings_count += 1
                yield finding

        self.num_findings_to_process = findings_count
        logger.info("Processed %s total findings from SentinelOne", findings_count)

    def _fetch_threats(
        self,
        resolved: Optional[bool] = None,
    ) -> Generator[IntegrationFinding, None, None]:
        """
        Fetch threats from SentinelOne.

        Args:
            resolved: Filter for resolved status (None = all, True = resolved, False = unresolved)

        Yields:
            IntegrationFinding objects for each threat
        """
        logger.info("Fetching threats from SentinelOne...")

        try:
            filters = {}
            if resolved is not None:
                filters["resolved"] = resolved

            for threat_data in self.api_client.iter_threats(page_size=self.page_size, **filters):
                try:
                    threat = SentinelOneThreat.from_sentinelone_data(threat_data)
                    yield threat_to_integration_finding(threat)
                except (KeyError, TypeError, ValueError) as e:
                    threat_id = threat_data.get("id", "Unknown")
                    logger.warning("Failed to process threat %s: %s", threat_id, str(e))

        except SentinelOneAPIException as e:
            logger.error("Failed to fetch threats from SentinelOne: %s", str(e))

    def _fetch_vulnerabilities(self) -> Generator[IntegrationFinding, None, None]:
        """
        Fetch vulnerabilities from SentinelOne Ranger.

        Yields:
            IntegrationFinding objects for each vulnerability
        """
        logger.info("Fetching vulnerabilities from SentinelOne Ranger...")

        try:
            for vuln_data in self.api_client.iter_vulnerabilities(page_size=self.page_size):
                try:
                    vuln = SentinelOneVulnerability.from_sentinelone_data(vuln_data)

                    # If vulnerability affects specific agents, create a finding per agent
                    affected_identifiers = vuln.get_affected_asset_identifiers()

                    if affected_identifiers:
                        for asset_id in affected_identifiers:
                            yield vulnerability_to_integration_finding(vuln, asset_id)
                    else:
                        # Create a single finding if no specific agents listed
                        yield vulnerability_to_integration_finding(vuln)

                except (KeyError, TypeError, ValueError) as e:
                    cve_id = vuln_data.get("cveId", "Unknown")
                    logger.warning("Failed to process vulnerability %s: %s", cve_id, str(e))

        except SentinelOneAPIException as e:
            logger.error("Failed to fetch vulnerabilities from SentinelOne: %s", str(e))
