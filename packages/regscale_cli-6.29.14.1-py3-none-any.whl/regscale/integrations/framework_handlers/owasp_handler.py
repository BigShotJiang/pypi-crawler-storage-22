#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OWASP ASVS Framework Handler for control ID parsing and CWE-based matching."""

import re
from typing import Optional, Set

from regscale.integrations.framework_handlers.base import FrameworkHandler


class OWASPHandler(FrameworkHandler):
    """
    Handler for OWASP ASVS (Application Security Verification Standard) control IDs.

    Formats supported:
    - Basic: V1.1.1, V5.3.3, V14.4.7
    - With prefix variations: 1.1.1, ASVS-1.1.1
    - Uppercase/lowercase: v1.1.1, V1.1.1

    The OWASP ASVS 4.0.3 standard uses the format:
    V{chapter}.{section}.{requirement}

    Where:
    - Chapter: 1-14 (V1 = Architecture, V5 = Validation, etc.)
    - Section: 1-N (sub-grouping within chapter)
    - Requirement: 1-N (specific requirement number)
    """

    framework_name = "OWASP"
    detection_pattern = r"^V?\d{1,2}\.\d+\.\d+"
    detection_priority = 8  # Higher priority than NIST (10) since OWASP is more specific

    def parse(self, control_string: str) -> Optional[str]:
        """
        Parse OWASP ASVS control ID from string.

        :param str control_string: Raw control string
        :return: Parsed and normalized control ID or None
        :rtype: Optional[str]
        """
        if not control_string:
            return None

        control_string = control_string.strip().upper()

        # Handle OCSF format with framework prefix (e.g., "OWASP:V1.1.1", "ASVS:1.2.3")
        if ":" in control_string:
            parts = control_string.split(":", 1)
            if len(parts) == 2:
                control_string = parts[1].strip()

        # Handle ASVS- prefix
        if control_string.startswith("ASVS-"):
            control_string = control_string[5:]

        # Pattern to match OWASP ASVS control IDs
        # V1.2.3 or 1.2.3 format
        pattern = r"V?(\d{1,2})\.(\d+)\.(\d+)"

        match = re.match(pattern, control_string)
        if not match:
            return None

        chapter = match.group(1)
        section = match.group(2)
        requirement = match.group(3)

        return self.normalize(f"V{chapter}.{section}.{requirement}")

    def normalize(self, control_id: str) -> str:
        """
        Normalize OWASP ASVS control ID.

        Ensures V prefix and consistent formatting.
        1.2.3 -> V1.2.3
        v1.2.3 -> V1.2.3

        :param str control_id: Control ID to normalize
        :return: Normalized control ID
        :rtype: str
        """
        control_id = control_id.strip().upper()

        # Ensure V prefix
        if not control_id.startswith("V"):
            control_id = f"V{control_id}"

        # Parse and reconstruct to ensure consistent format
        pattern = r"V(\d{1,2})\.(\d+)\.(\d+)"
        match = re.match(pattern, control_id)

        if match:
            chapter = int(match.group(1))
            section = int(match.group(2))
            requirement = int(match.group(3))
            return f"V{chapter}.{section}.{requirement}"

        return control_id

    def get_variations(self, control_id: str) -> Set[str]:
        """
        Generate all OWASP ASVS control ID variations.

        :param str control_id: Control ID to generate variations for
        :return: Set of all valid variations
        :rtype: Set[str]
        """
        parsed = self.parse(control_id)
        if not parsed:
            return set()

        # Extract components
        pattern = r"V(\d+)\.(\d+)\.(\d+)"
        match = re.match(pattern, parsed)
        if not match:
            return {parsed}

        chapter = match.group(1)
        section = match.group(2)
        requirement = match.group(3)

        # Generate variations
        variations = set()

        # With V prefix
        variations.add(f"V{chapter}.{section}.{requirement}")
        variations.add(f"v{chapter}.{section}.{requirement}")

        # Without V prefix
        variations.add(f"{chapter}.{section}.{requirement}")

        # With ASVS prefix
        variations.add(f"ASVS-{chapter}.{section}.{requirement}")
        variations.add(f"ASVS-V{chapter}.{section}.{requirement}")

        # Uppercase versions
        variations.update({v.upper() for v in variations})

        return variations

    def matches(self, control_id: str) -> bool:
        """
        Check if control ID matches OWASP ASVS pattern.

        OWASP ASVS controls require either:
        - V prefix (V1.1.1, V14.4.7)
        - ASVS prefix (ASVS-1.1.1, ASVS:V1.1.1)
        - OWASP prefix (OWASP:V1.1.1)

        Bare numeric patterns like 6.1.1 are NOT matched to avoid
        conflicts with CIS controls which use similar patterns.

        :param str control_id: Control ID to check
        :return: True if matches OWASP ASVS pattern
        :rtype: bool
        """
        if not control_id:
            return False

        original_id = control_id.strip().upper()
        control_id = original_id

        # Handle OCSF/explicit framework prefixes
        has_owasp_prefix = False
        if ":" in control_id:
            prefix, control_id = control_id.split(":", 1)
            if prefix in ["OWASP", "ASVS"]:
                has_owasp_prefix = True
                control_id = control_id.strip()
            else:
                return False

        # Handle ASVS- prefix
        if control_id.startswith("ASVS-"):
            has_owasp_prefix = True
            control_id = control_id[5:]

        # Check for V prefix
        has_v_prefix = control_id.startswith("V")

        # Only match if there's explicit OWASP/ASVS context or V prefix
        if not has_owasp_prefix and not has_v_prefix:
            return False

        # Match OWASP ASVS pattern: V{chapter}.{section}.{requirement}
        # Chapters are 1-14 in ASVS 4.0.3
        return bool(re.match(r"^V?\d{1,2}\.\d+\.\d+$", control_id))

    @staticmethod
    def parse_cwe_from_mappings(mappings: str) -> Set[int]:
        """
        Parse CWE IDs from a control's mappings field.

        :param str mappings: The mappings string (e.g., "CWE-79, CWE-89")
        :return: Set of CWE IDs as integers
        :rtype: Set[int]
        """
        if not mappings:
            return set()

        cwes = set()
        # Match CWE-NNN or just NNN patterns
        pattern = r"CWE-?(\d+)"
        for match in re.finditer(pattern, mappings, re.IGNORECASE):
            cwes.add(int(match.group(1)))

        return cwes

    @staticmethod
    def format_cwe_mappings(cwe_ids: Set[int]) -> str:
        """
        Format CWE IDs into the standard mappings string format.

        :param Set[int] cwe_ids: Set of CWE IDs
        :return: Formatted mappings string (e.g., "CWE-79, CWE-89")
        :rtype: str
        """
        if not cwe_ids:
            return ""
        return ", ".join(f"CWE-{cwe}" for cwe in sorted(cwe_ids))
