#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Integrates CSAM into RegScale"""

# standard python imports
import logging
import os
import re
from pathlib import Path

from rich.progress import track

from regscale.core.app.api import Api
from regscale.core.app.application import Application
from regscale.core.app.config import get_configured_values
from regscale.core.app.utils.app_utils import error_and_exit, filter_list
from regscale.integrations.public.csam.csam_common import (
    CSAM_FIELD_NAME,
    SSP_BASIC_TAB,
    retrieve_from_csam,
    retrieve_ssps_custom_form_map,
    trim_ssp_list,
)
from regscale.models.regscale_models.file import File
from regscale.models.regscale_models.form_field_value import FormFieldValue

logger = logging.getLogger("regscale")

SECURITY_PLAN = "securityplans"


def import_csam_artifacts():
    """
    Import Artifact Files from CSAM
    Into RegScale
    """

    # Grab the data from CSAM
    app = Application()
    # Get only configured (non-placeholder) filter values
    csam_filter = get_configured_values(app.config.get("csamFilter"))

    logger.info("Retrieving systems from CSAM...")
    results = retrieve_from_csam(
        csam_endpoint="/CSAM/api/v1/systems",
    )

    if not results:
        error_and_exit("Failure to retrieve plans from CSAM")
    else:
        logger.info("Retrieved plans from CSAM, parsing results...")

    results = filter_list(results, csam_filter)
    if not results:
        error_and_exit(
            "No results match filter in CSAM. \
                       Please check your CSAM configuration."
        )

    # Get existing ssps by CSAM Id
    custom_fields_basic_map = FormFieldValue.check_custom_fields([CSAM_FIELD_NAME], SECURITY_PLAN, SSP_BASIC_TAB)

    # Get a map of existing custom forms
    ssp_map = retrieve_ssps_custom_form_map(
        tab_name=SSP_BASIC_TAB, field_form_id=custom_fields_basic_map[CSAM_FIELD_NAME]
    )

    # Trim the ssp_map to just the CSAM ids in results
    ssp_map = trim_ssp_list(results=results, ssp_map=ssp_map)

    plans = list(ssp_map.keys())

    # Get the list of artifact Types to import
    artifact_types = app.config.get("csamArtifactTypes", None)
    if not artifact_types or len(artifact_types) == 0:
        error_and_exit("No artifacts types configured to be imported")

    # Get the list of existing ssp files
    ssp_file_map = get_existing_files_map(ssps=plans)

    # Get tags
    tags = File.get_existing_tags_dict()

    all_artifacts = []
    for index in track(
        range(len(plans)),
        description=f"Importing {len(plans)} SSP artifacts...",
    ):
        artifacts = []
        ssp = plans[index]
        system_id = ssp_map.get(ssp)

        # For each plan, build a list of artifactIds
        # Start with appendices
        results = retrieve_from_csam(csam_endpoint=f"/CSAM/api/v1/systems/{system_id}/artifacts")

        artifacts = process_artifacts(results=results, ssp=ssp, types=artifact_types)
        all_artifacts.extend(artifacts)

    # Download the artifacts
    for index in track(
        range(len(all_artifacts)),
        description=f"Downloading {len(all_artifacts)} files locally...",
    ):
        artifact = all_artifacts[index]

        # Check if it exists
        existing_files = ssp_file_map.get(artifact.get("regscale_id"))
        if artifact.get("file_name") in existing_files:
            continue

        artifact["local_file"] = retrieve_artifacts(artifact=artifact)

    # Upload the artifacts
    api = Api()
    for index in track(
        range(len(all_artifacts)),
        description=f"Uploading {len(all_artifacts)} files to RegScale...",
    ):
        item = all_artifacts[index]

        # Check if it exists
        existing_files = ssp_file_map.get(item.get("regscale_id"))
        if item.get("file_name") in existing_files:
            continue

        # Upload
        upload_files(item=item, tags=tags, api=api)


def process_artifacts(results: list, ssp: int, types: list) -> list:
    """
    Parse the list of artifacts and return a list of
    artifact ids matching the artifact types
    selected

    :param results: list of artifacts from CSAM
    :param ssp: RegScale SSP Id
    :param types: list of artifact types to import
    :return: list of artifactIds
    """
    artifacts = []
    # Check if the artifact type is in the list
    # Check if the artifactId set
    for result in results:
        if result.get("artifactType") in types and result.get("artifactId"):
            file_name = result.get("filename")
            file_name = file_name.replace(" ", "_")
            artifacts.append(
                {
                    "regscale_id": ssp,
                    "artifact_description": result.get("artifactDescription"),
                    "artifact_id": result.get("artifactId"),
                    "file_name": file_name,
                }
            )

    return artifacts


def retrieve_artifacts(artifact: dict) -> Path:
    """
    Retrieve file from CSAM

    :param artifact: dict with the filename, artifact id, and securityplan Id
    :return: file Path
    """

    file_data = retrieve_from_csam(csam_endpoint=f"/CSAM/api/v1/artifacts/{artifact.get('artifact_id')}")

    if file_data is None:
        logger.warning(f"No data received for {artifact.get('artifact_id')}")
        return Path(None)

    # Prevent folder transversal
    file_name = sanitize_filename(artifact.get("file_name"))

    file_path = f"artifacts{os.sep}{artifact.get('regscale_id')}{os.sep}{file_name}"
    Path(os.path.dirname(file_path)).mkdir(parents=True, exist_ok=True)
    with open(file_path, mode="wb") as f:
        f.write(file_data)

    return Path(file_path)


def get_existing_files_map(ssps: list) -> dict:
    """
    Builds a map of SSP id to list of existing files

    :param ssps: list of ssp ids
    :return: diction map of ssp ids: existing files in RegScale
    """
    ssp_file_map = {}
    for ssp in ssps:
        files = []
        files_list = File.get_file_list(parent_id=ssp, parent_module=SECURITY_PLAN)
        if len(files_list) > 0:
            for file in files_list:
                files.append(file.get("trustedDisplayName"))
        ssp_file_map[ssp] = files
    return ssp_file_map


def upload_files(
    item: dict,
    tags: list,
    api: Api,
):
    """
    Upload the files to RegScale

    :param item: object to be uploaded
    :param tags: dictionary of tags
    :param api: RegScale API
    :return: None
    """
    # Find the tag:
    tag = item.get("artifact_description")
    tag = tag.lower()
    tag = tag.replace(" ", "-")
    if tag not in tags:
        logger.warning(
            f"For filename: {item.get('file_name')}, tag: {tag} not in RegScale.  Add tag and then add tag to file upload."
        )
        tag = ""

    file_path = item.get("local_file")

    # Validate file exists and is readable
    if not file_path:
        logger.warning(f"No local file path for artifact {item.get('artifact_description')}")
        return

    file_path = Path(file_path).resolve()  # Resolve to absolute path

    if not file_path.exists():
        logger.error(f"File not found: {file_path}")
        return

    if not file_path.is_file():
        logger.error(f"Path is not a file: {file_path}")
        return

    success = File.upload_file_to_regscale(
        file_name=file_path,
        parent_id=item.get("regscale_id"),
        parent_module=SECURITY_PLAN,
        api=api,
        file_data=None,
        tags=tag,
    )

    if not success:
        logger.warning(
            f"Failed to upload CSAM artifact id: {item.get('artifact_id')} to RegScale plan {item.get('regscale_id')}"
        )


def sanitize_filename(filename: str) -> str:
    """Remove path traversal and dangerous characters from filename."""
    # Remove path separators and traversal
    filename = Path(filename).name
    # Remove any remaining dangerous characters
    filename = re.sub(r"[^\w\s\-.]", "_", filename)
    # Ensure no leading dots (hidden files)
    filename = filename.lstrip(".")
    return filename
