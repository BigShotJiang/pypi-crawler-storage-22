#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CVE Data Cleanup Tool.

CLI tool to identify and remediate Issue records that contain multiple
comma-delimited CVEs, which violates the 200 character limit and
single-CVE-per-field constraint.

Also provides functionality to sync vulnerabilities and issues from
custom field values containing CVE data.
"""

import csv
import logging
from typing import Any, Dict, List, Optional, Set, Tuple

import click
from rich.console import Console
from rich.table import Table

from regscale.core.app.api import Api
from regscale.core.app.application import Application
from regscale.core.app.internal.login import is_valid
from regscale.core.app.utils.app_utils import error_and_exit
from regscale.models.regscale_models.asset import Asset
from regscale.models.regscale_models.custom_field import CustomFieldsData
from regscale.models.regscale_models.issue import Issue, IssueStatus
from regscale.models.regscale_models.vulnerability import Vulnerability
from regscale.utils.cve_utils import validate_single_cve

logger = logging.getLogger("regscale")
console = Console()

# Constants
INVALID_TOKEN_ERROR = "Invalid or expired token. Please run 'regscale login' first."


def get_issues_with_multi_cve(parent_id: Optional[int] = None, parent_module: Optional[str] = None) -> List[Issue]:
    """
    Query for Issues that have multiple CVEs (comma or newline delimited).

    :param Optional[int] parent_id: Filter by parent ID (e.g., security plan ID)
    :param Optional[str] parent_module: Filter by parent module
    :return: List of Issues with multiple CVEs
    :rtype: List[Issue]
    """
    # Build filter conditions
    where_clauses = []
    if parent_id:
        where_clauses.append(f"parentId: {{eq: {parent_id}}}")
    if parent_module:
        where_clauses.append(f'parentModule: {{eq: "{parent_module}"}}')

    where_filter = ", ".join(where_clauses) if where_clauses else ""
    where_clause = f"where: {{{where_filter}}}" if where_filter else ""

    query = f"""
        query {{
            issues(take: 1000, skip: 0{", " + where_clause if where_clause else ""})
            {{
            items {{
                {Issue.build_graphql_fields()}
            }}
            pageInfo {{
                hasNextPage
            }}
            ,totalCount}}
        }}
    """

    try:
        api = Api()
        result = api.graph(query=query)
        all_issues = [Issue(**issue) for issue in result["issues"]["items"]]
    except Exception as e:
        logger.error("Error querying issues: %s", str(e))
        return []

    # Filter to only issues with multiple CVEs
    multi_cve_issues = []
    for issue in all_issues:
        if issue.cve and ("," in issue.cve or "\n" in issue.cve):
            multi_cve_issues.append(issue)

    return multi_cve_issues


def parse_cves_from_field(cve_field: str) -> List[str]:
    """
    Parse CVEs from a comma or newline delimited field.

    :param str cve_field: The CVE field value
    :return: List of individual CVEs
    :rtype: List[str]
    """
    if not cve_field:
        return []

    # Split by comma or newline
    cves = []
    for delimiter in [",", "\n"]:
        if delimiter in cve_field:
            parts = cve_field.split(delimiter)
            for part in parts:
                stripped = part.strip()
                if stripped:
                    cves.append(stripped)
            return cves

    return [cve_field.strip()] if cve_field.strip() else []


def get_unique_cves(cve_field: str) -> Set[str]:
    """
    Get unique CVEs from a field, validating each one.

    :param str cve_field: The CVE field value
    :return: Set of unique valid CVEs
    :rtype: Set[str]
    """
    cves = parse_cves_from_field(cve_field)
    unique_cves = set()
    for cve in cves:
        validated = validate_single_cve(cve)
        if validated:
            unique_cves.add(validated)
    return unique_cves


def analyze_issue(issue: Issue) -> Dict[str, Any]:
    """
    Analyze an issue with multiple CVEs.

    :param Issue issue: The issue to analyze
    :return: Analysis result dictionary
    :rtype: Dict[str, Any]
    """
    cves = parse_cves_from_field(issue.cve or "")
    unique_cves = get_unique_cves(issue.cve or "")

    return {
        "issue_id": issue.id,
        "title": (issue.title[:50] + "...") if issue.title and len(issue.title) > 50 else issue.title,
        "current_cve": issue.cve,
        "cve_count": len(cves),
        "unique_cve_count": len(unique_cves),
        "unique_cves": list(unique_cves),
        "all_same": len(unique_cves) <= 1,
        "action": "deduplicate" if len(unique_cves) <= 1 else "split",
        "parent_id": issue.parentId,
        "parent_module": issue.parentModule,
    }


def process_issue_cleanup(issue: Issue, dry_run: bool) -> Dict[str, int]:
    """
    Process a single issue for CVE cleanup.

    :param Issue issue: The issue to process
    :param bool dry_run: Whether this is a dry run
    :return: Dictionary with counts of updated, created, and errors
    :rtype: Dict[str, int]
    """
    result = {"updated": 0, "created": 0, "errors": 0}
    analysis = analyze_issue(issue)
    unique_cves = analysis["unique_cves"]

    if not unique_cves:
        console.print(f"  [yellow]Skipping Issue {issue.id}: No valid CVEs found[/yellow]")
        return result

    first_cve = unique_cves[0]
    additional_cves = unique_cves[1:] if len(unique_cves) > 1 else []

    try:
        if analysis["action"] == "deduplicate":
            result["updated"] = _handle_deduplicate(issue, first_cve, dry_run)
        else:
            updated, created, errors = _handle_split(issue, first_cve, additional_cves, dry_run)
            result["updated"] = updated
            result["created"] = created
            result["errors"] = errors
    except Exception as e:
        console.print(f"  [red]Error processing Issue {issue.id}: {str(e)}[/red]")
        result["errors"] = 1

    return result


def _handle_deduplicate(issue: Issue, first_cve: str, dry_run: bool) -> int:
    """Handle deduplication of an issue with repeated CVEs."""
    if dry_run:
        console.print(f"  [cyan]Would update Issue {issue.id}: CVE → {first_cve}[/cyan]")
    else:
        issue.cve = first_cve
        issue.save()
        console.print(f"  [green]Updated Issue {issue.id}: CVE → {first_cve}[/green]")
    return 1


def _handle_split(issue: Issue, first_cve: str, additional_cves: List[str], dry_run: bool) -> tuple:
    """Handle splitting an issue with different CVEs into multiple issues."""
    updated = 0
    created = 0
    errors = 0

    if dry_run:
        console.print(f"  [cyan]Would update Issue {issue.id}: CVE → {first_cve}[/cyan]")
        for cve in additional_cves:
            console.print(f"  [cyan]Would create new Issue for CVE: {cve}[/cyan]")
        return 1, len(additional_cves), 0

    # Update original issue with first CVE
    issue.cve = first_cve
    issue.save()
    console.print(f"  [green]Updated Issue {issue.id}: CVE → {first_cve}[/green]")
    updated = 1

    # Create new Issues for additional CVEs
    for cve in additional_cves:
        new_issue = create_issue_copy(issue, cve)
        if new_issue:
            console.print(f"  [green]Created Issue {new_issue.id} for CVE: {cve}[/green]")
            created += 1
        else:
            console.print(f"  [red]Failed to create Issue for CVE: {cve}[/red]")
            errors += 1

    return updated, created, errors


@click.group()
def cve_cleanup():
    """CVE Data Cleanup Tool - Find and fix multi-CVE issue records."""
    pass


@cve_cleanup.command(name="discover")
@click.option(
    "--parent-id",
    type=click.INT,
    help="Filter by parent ID (e.g., security plan ID)",
    required=False,
)
@click.option(
    "--parent-module",
    type=click.STRING,
    help="Filter by parent module (e.g., 'securityplans')",
    required=False,
)
@click.option(
    "--output",
    type=click.Path(),
    help="Export results to CSV file",
    required=False,
)
def discover(parent_id: Optional[int], parent_module: Optional[str], output: Optional[str]):
    """
    Discover Issues with multiple CVEs in the CVE field.

    Scans for Issues where the CVE field contains comma or newline
    delimited values, which need to be cleaned up.
    """
    app = Application()
    if not is_valid(app=app):
        error_and_exit(INVALID_TOKEN_ERROR)

    console.print("[bold blue]Scanning for Issues with multiple CVEs...[/bold blue]")

    issues = get_issues_with_multi_cve(parent_id, parent_module)

    if not issues:
        console.print("[green]No Issues found with multiple CVEs.[/green]")
        return

    # Analyze each issue
    analyses = [analyze_issue(issue) for issue in issues]

    # Summary statistics
    total_issues = len(analyses)
    dedupe_count = sum(1 for a in analyses if a["action"] == "deduplicate")
    split_count = sum(1 for a in analyses if a["action"] == "split")
    total_new_issues = sum(a["unique_cve_count"] - 1 for a in analyses if a["action"] == "split")

    # Display summary
    console.print(f"\n[bold]Found {total_issues} Issues with multiple CVEs:[/bold]")
    console.print(f"  - {dedupe_count} can be deduplicated (same CVE repeated)")
    console.print(f"  - {split_count} need to be split into separate Issues")
    console.print(f"  - {total_new_issues} new Issues will be created from splits")

    # Display table
    table = Table(title="Issues with Multiple CVEs")
    table.add_column("Issue ID", style="cyan")
    table.add_column("Title", style="white")
    table.add_column("CVE Count", style="yellow")
    table.add_column("Unique CVEs", style="green")
    table.add_column("Action", style="magenta")

    for analysis in analyses[:20]:  # Show first 20
        table.add_row(
            str(analysis["issue_id"]),
            analysis["title"] or "N/A",
            str(analysis["cve_count"]),
            str(analysis["unique_cve_count"]),
            analysis["action"],
        )

    if len(analyses) > 20:
        table.add_row("...", f"({len(analyses) - 20} more)", "...", "...", "...")

    console.print(table)

    # Export to CSV if requested
    if output:
        with open(output, "w", newline="", encoding="utf-8") as csvfile:
            fieldnames = [
                "issue_id",
                "title",
                "current_cve",
                "cve_count",
                "unique_cve_count",
                "unique_cves",
                "action",
                "parent_id",
                "parent_module",
            ]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for analysis in analyses:
                row = analysis.copy()
                row["unique_cves"] = ", ".join(row["unique_cves"])
                writer.writerow(row)
        console.print(f"\n[green]Results exported to: {output}[/green]")

    console.print("\n[bold]To fix these issues, run:[/bold]")
    console.print(f"  regscale cve-cleanup fix --parent-id {parent_id or '<ID>'} --dry-run")


@cve_cleanup.command(name="fix")
@click.option(
    "--parent-id",
    type=click.INT,
    help="Filter by parent ID (e.g., security plan ID)",
    required=False,
)
@click.option(
    "--parent-module",
    type=click.STRING,
    help="Filter by parent module (e.g., 'securityplans')",
    required=False,
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=True,
    help="Show what would be changed without making changes (default: True)",
)
@click.option(
    "--confirm",
    is_flag=True,
    default=False,
    help="Actually perform the cleanup (disables dry-run)",
)
def fix(parent_id: Optional[int], parent_module: Optional[str], dry_run: bool, confirm: bool):
    """
    Fix Issues with multiple CVEs.

    For Issues with duplicate CVEs: Updates to keep only the first CVE.
    For Issues with different CVEs: Creates new Issues for each additional CVE.

    By default runs in dry-run mode. Use --confirm to actually make changes.
    """
    app = Application()
    if not is_valid(app=app):
        error_and_exit(INVALID_TOKEN_ERROR)

    # If confirm is set, disable dry_run
    if confirm:
        dry_run = False

    mode = "[yellow]DRY RUN[/yellow]" if dry_run else "[red]LIVE[/red]"
    console.print(f"[bold blue]CVE Cleanup Tool - {mode}[/bold blue]")

    if not dry_run:
        console.print("[bold red]WARNING: This will modify data in RegScale![/bold red]")
        if not click.confirm("Are you sure you want to proceed?"):
            console.print("Aborted.")
            return

    issues = get_issues_with_multi_cve(parent_id, parent_module)

    if not issues:
        console.print("[green]No Issues found with multiple CVEs.[/green]")
        return

    console.print(f"Found {len(issues)} Issues to process...")

    updated_count = 0
    created_count = 0
    error_count = 0

    for issue in issues:
        result = process_issue_cleanup(issue, dry_run)
        updated_count += result["updated"]
        created_count += result["created"]
        error_count += result["errors"]

    # Summary
    console.print("\n[bold]Summary:[/bold]")
    console.print(f"  - Issues updated: {updated_count}")
    console.print(f"  - Issues created: {created_count}")
    console.print(f"  - Errors: {error_count}")

    if dry_run:
        console.print("\n[yellow]This was a dry run. No changes were made.[/yellow]")
        console.print("To apply changes, run with --confirm flag.")


def create_issue_copy(original: Issue, new_cve: str) -> Optional[Issue]:
    """
    Create a copy of an Issue with a different CVE.

    :param Issue original: The original Issue to copy
    :param str new_cve: The new CVE for the copy
    :return: The created Issue or None if failed
    :rtype: Optional[Issue]
    """
    try:
        # Create a new issue based on the original
        new_issue = Issue(
            title=original.title.replace(original.cve or "", new_cve) if original.title else "Issue: %s" % new_cve,
            description=original.description,
            severityLevel=original.severityLevel,
            status=original.status,
            parentId=original.parentId,
            parentModule=original.parentModule,
            cve=new_cve,
            dateCreated=original.dateCreated,
            dueDate=original.dueDate,
            identification=original.identification,
            recommendedActions=original.recommendedActions,
            assetIdentifier=original.assetIdentifier,
            pluginId=original.pluginId,
            integrationFindingId=(
                "%s_%s" % (original.integrationFindingId, new_cve) if original.integrationFindingId else None
            ),
            # Copy other relevant fields
            originalRiskRating=original.originalRiskRating,
            securityImpact=original.securityImpact,
        )

        # Create the issue via API
        created = new_issue.create()
        return created

    except Exception as e:
        logger.error("Error creating issue copy: %s", str(e))
        return None


# ============================================================================
# Sync from Custom Field functionality
# ============================================================================

# Module ID for Issues in RegScale
ISSUE_MODULE_ID = 15


def _is_matching_cve_field(custom_field: CustomFieldsData, field_name: str) -> bool:
    """Check if the custom field matches the target field name and has a value."""
    return bool(
        custom_field.fieldName and custom_field.fieldName.lower() == field_name.lower() and custom_field.fieldValue
    )


def _extract_cve_record(issue: Issue, custom_field: CustomFieldsData) -> Optional[Dict[str, Any]]:
    """Extract CVE record data from a custom field if it contains valid CVEs."""
    cves = parse_cves_from_field(custom_field.fieldValue)
    if not cves:
        return None
    return {
        "record_type": "issue",
        "record_id": issue.id,
        "record": issue,
        "custom_field_value": custom_field.fieldValue,
        "cves": cves,
        "asset_identifier": issue.assetIdentifier,
    }


def _process_issue_custom_fields(issue: Issue, field_name: str) -> List[Dict[str, Any]]:
    """Process custom fields for a single issue and return matching CVE records."""
    results = []
    try:
        custom_fields = CustomFieldsData.get_by_module_id(parent_id=issue.id, module_id=ISSUE_MODULE_ID)
        if not custom_fields:
            return results
        for cf in custom_fields:
            if _is_matching_cve_field(cf, field_name):
                record = _extract_cve_record(issue, cf)
                if record:
                    results.append(record)
    except Exception as e:
        logger.debug("Error getting custom fields for issue %d: %s", issue.id, str(e))
    return results


def get_custom_field_data_by_parent(
    parent_id: int,
    parent_module: str,
    field_name: str,
) -> List[Dict[str, Any]]:
    """
    Get custom field data for records under a parent, filtering by field name.

    :param int parent_id: The parent ID (e.g., security plan ID)
    :param str parent_module: The parent module (e.g., 'securityplans')
    :param str field_name: The custom field name to look for CVE data
    :return: List of dictionaries with record info and CVE values
    :rtype: List[Dict[str, Any]]
    """
    results = []
    issues = Issue.get_all_by_parent(parent_id=parent_id, parent_module=parent_module)
    logger.info("Found %d issues under parent %d", len(issues), parent_id)

    for issue in issues:
        results.extend(_process_issue_custom_fields(issue, field_name))

    return results


def get_existing_vulnerabilities(
    parent_id: int,
    parent_module: str,
) -> Dict[str, Vulnerability]:
    """
    Get existing vulnerabilities indexed by CVE.

    :param int parent_id: The parent ID
    :param str parent_module: The parent module
    :return: Dictionary of CVE -> Vulnerability
    :rtype: Dict[str, Vulnerability]
    """
    vulns = Vulnerability.get_all_by_parent(parent_id=parent_id, parent_module=parent_module)
    vuln_map: Dict[str, Vulnerability] = {}
    for vuln in vulns:
        if vuln.cve:
            vuln_map[vuln.cve.upper()] = vuln
    return vuln_map


def get_existing_issues_by_cve(
    parent_id: int,
    parent_module: str,
) -> Dict[str, List[Issue]]:
    """
    Get existing issues indexed by CVE.

    :param int parent_id: The parent ID
    :param str parent_module: The parent module
    :return: Dictionary of CVE -> List of Issues
    :rtype: Dict[str, List[Issue]]
    """
    issues = Issue.get_all_by_parent(parent_id=parent_id, parent_module=parent_module)
    issue_map: Dict[str, List[Issue]] = {}
    for issue in issues:
        if issue.cve:
            cve_upper = issue.cve.upper()
            if cve_upper not in issue_map:
                issue_map[cve_upper] = []
            issue_map[cve_upper].append(issue)
    return issue_map


def get_asset_map(parent_id: int, parent_module: str) -> Dict[str, Asset]:
    """
    Get assets indexed by various identifiers.

    :param int parent_id: The parent ID
    :param str parent_module: The parent module
    :return: Dictionary of identifier -> Asset
    :rtype: Dict[str, Asset]
    """
    assets = Asset.get_all_by_parent(parent_id=parent_id, parent_module=parent_module)
    asset_map: Dict[str, Asset] = {}
    for asset in assets:
        # Index by multiple identifiers
        if asset.name:
            asset_map[asset.name.lower()] = asset
        if asset.fqdn:
            asset_map[asset.fqdn.lower()] = asset
        if asset.ipAddress:
            asset_map[asset.ipAddress] = asset
        if asset.otherTrackingNumber:
            asset_map[asset.otherTrackingNumber.lower()] = asset
    return asset_map


def find_asset_for_identifier(
    identifier: Optional[str],
    asset_map: Dict[str, Asset],
) -> Optional[Asset]:
    """
    Find an asset matching the given identifier.

    :param Optional[str] identifier: The asset identifier to look up
    :param Dict[str, Asset] asset_map: Map of identifiers to assets
    :return: Matching asset or None
    :rtype: Optional[Asset]
    """
    if not identifier:
        return None

    # Try direct lookup
    if identifier.lower() in asset_map:
        return asset_map[identifier.lower()]

    # Try splitting by newline (multiple assets)
    if "\n" in identifier:
        for part in identifier.split("\n"):
            part = part.strip()
            if part.lower() in asset_map:
                return asset_map[part.lower()]

    return None


def create_vulnerability_from_cve(
    cve: str,
    parent_id: int,
    parent_module: str,
    asset: Optional[Asset] = None,
    source_issue: Optional[Issue] = None,
) -> Optional[Vulnerability]:
    """
    Create a new vulnerability for a CVE.

    :param str cve: The CVE identifier
    :param int parent_id: The parent ID
    :param str parent_module: The parent module
    :param Optional[Asset] asset: The asset to associate with
    :param Optional[Issue] source_issue: Source issue for additional context
    :return: Created vulnerability or None
    :rtype: Optional[Vulnerability]
    """
    try:
        vuln = Vulnerability(
            cve=cve,
            title="Vulnerability: %s" % cve,
            plugInName=cve,
            plugInId=cve,
            parentId=parent_id,
            parentModule=parent_module,
            severity="Medium",  # Default severity, can be enriched later
            ipAddress=asset.ipAddress if asset else None,
            dns=asset.fqdn if asset else None,
            description=(
                "Vulnerability identified from custom field data. Source Issue ID: %d" % source_issue.id
                if source_issue
                else "Vulnerability identified from custom field data."
            ),
        )
        created = vuln.create()
        return created
    except Exception as e:
        logger.error("Error creating vulnerability for CVE %s: %s", cve, str(e))
        return None


def create_issue_from_cve(
    cve: str,
    parent_id: int,
    parent_module: str,
    asset: Optional[Asset] = None,
    vulnerability: Optional[Vulnerability] = None,
    source_issue: Optional[Issue] = None,
) -> Optional[Issue]:
    """
    Create a new issue for a CVE.

    :param str cve: The CVE identifier
    :param int parent_id: The parent ID
    :param str parent_module: The parent module
    :param Optional[Asset] asset: The asset to associate with
    :param Optional[Vulnerability] vulnerability: The linked vulnerability
    :param Optional[Issue] source_issue: Source issue for copying attributes
    :return: Created issue or None
    :rtype: Optional[Issue]
    """
    try:
        # Build integration finding ID for deduplication
        integration_id = "cve_sync_%s" % cve
        if asset:
            integration_id = "cve_sync_%s_%s" % (cve, asset.id)

        # Check if issue already exists with this integration finding ID
        existing = Issue.find_by_integration_finding_id(integration_id)
        if existing:
            logger.debug("Issue already exists for %s", integration_id)
            return None

        # Determine asset identifier - prefer otherTrackingNumber per scanner convention
        asset_identifier = asset.otherTrackingNumber if asset else None
        if not asset_identifier and source_issue:
            asset_identifier = source_issue.assetIdentifier

        issue = Issue(
            title="Vulnerability: %s" % cve,
            cve=cve,
            parentId=parent_id,
            parentModule=parent_module,
            status=IssueStatus.Open,
            severityLevel=source_issue.severityLevel if source_issue else "Medium",
            description=(
                source_issue.description if source_issue else "Issue created from CVE custom field data for %s" % cve
            ),
            assetIdentifier=asset_identifier,
            vulnerabilityId=vulnerability.id if vulnerability else None,
            integrationFindingId=integration_id,
            identification="Vulnerability Assessment",
            recommendedActions=source_issue.recommendedActions if source_issue else None,
        )
        created = issue.create()
        return created
    except Exception as e:
        logger.error("Error creating issue for CVE %s: %s", cve, str(e))
        return None


def _collect_unique_cves(custom_field_records: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """Collect unique CVEs and their associated data from custom field records."""
    cve_data: Dict[str, Dict[str, Any]] = {}
    for record in custom_field_records:
        for cve_raw in record["cves"]:
            cve = validate_single_cve(cve_raw)
            if not cve:
                continue
            if cve not in cve_data:
                cve_data[cve] = {"source_records": [], "asset_identifiers": set()}
            cve_data[cve]["source_records"].append(record)
            if record.get("asset_identifier"):
                cve_data[cve]["asset_identifiers"].add(record["asset_identifier"])
    return cve_data


def _find_asset_from_identifiers(identifiers: Set[str], asset_map: Dict[str, Asset]) -> Optional[Asset]:
    """Find the first matching asset from a set of identifiers."""
    for identifier in identifiers:
        asset = find_asset_for_identifier(identifier, asset_map)
        if asset:
            return asset
    return None


def _get_source_issue_from_records(source_records: List[Dict[str, Any]]) -> Optional[Issue]:
    """Get the first source issue from a list of records."""
    for record in source_records:
        if record["record_type"] == "issue":
            return record["record"]
    return None


def _sync_vulnerability(
    cve: str,
    existing_vuln: Optional[Vulnerability],
    parent_id: int,
    parent_module: str,
    asset: Optional[Asset],
    source_issue: Optional[Issue],
    dry_run: bool,
) -> Tuple[Optional[Vulnerability], int, int, int]:
    """Sync a single vulnerability for a CVE. Returns (vuln, created, skipped, errors)."""
    if existing_vuln:
        console.print("  [yellow]Vulnerability already exists for CVE: %s (ID: %d)[/yellow]" % (cve, existing_vuln.id))
        return existing_vuln, 0, 1, 0

    if dry_run:
        console.print("  [cyan]Would create vulnerability for CVE: %s[/cyan]" % cve)
        return None, 1, 0, 0

    vuln = create_vulnerability_from_cve(cve, parent_id, parent_module, asset, source_issue)
    if vuln:
        console.print("  [green]Created vulnerability %d for CVE: %s[/green]" % (vuln.id, cve))
        return vuln, 1, 0, 0
    return None, 0, 0, 1


def _sync_issue(
    cve: str,
    existing_issues: List[Issue],
    parent_id: int,
    parent_module: str,
    asset: Optional[Asset],
    vuln: Optional[Vulnerability],
    source_issue: Optional[Issue],
    dry_run: bool,
) -> Tuple[int, int, int]:
    """Sync a single issue for a CVE. Returns (created, skipped, errors)."""
    if existing_issues:
        console.print("  [yellow]Issue already exists for CVE: %s (ID: %d)[/yellow]" % (cve, existing_issues[0].id))
        return 0, 1, 0

    if dry_run:
        console.print("  [cyan]Would create issue for CVE: %s[/cyan]" % cve)
        return 1, 0, 0

    issue = create_issue_from_cve(cve, parent_id, parent_module, asset, vuln, source_issue)
    if issue:
        console.print("  [green]Created issue %d for CVE: %s[/green]" % (issue.id, cve))
        return 1, 0, 0

    # Check if issue was skipped due to dedup
    existing_check = Issue.find_by_integration_finding_id("cve_sync_%s" % cve)
    if existing_check:
        return 0, 1, 0
    return 0, 0, 1


def _fetch_existing_data(
    parent_id: int, parent_module: str
) -> Tuple[Dict[str, Vulnerability], Dict[str, List[Issue]], Dict[str, Asset]]:
    """Fetch existing vulnerabilities, issues, and assets for deduplication."""
    console.print("[cyan]Fetching existing vulnerabilities...[/cyan]")
    existing_vulns = get_existing_vulnerabilities(parent_id, parent_module)
    console.print("[cyan]Fetching existing issues...[/cyan]")
    existing_issues = get_existing_issues_by_cve(parent_id, parent_module)
    console.print("[cyan]Fetching assets...[/cyan]")
    asset_map = get_asset_map(parent_id, parent_module)
    return existing_vulns, existing_issues, asset_map


def _process_single_cve(
    cve: str,
    data: Dict[str, Any],
    parent_id: int,
    parent_module: str,
    existing_vulns: Dict[str, Vulnerability],
    existing_issues: Dict[str, List[Issue]],
    asset_map: Dict[str, Asset],
    create_vulns: bool,
    create_issues: bool,
    dry_run: bool,
) -> Tuple[int, int, int, int]:
    """Process a single CVE for vulnerability and issue sync. Returns (vulns, issues, skipped, errors)."""
    vulns_created = issues_created = skipped = errors = 0
    cve_upper = cve.upper()

    asset = _find_asset_from_identifiers(data["asset_identifiers"], asset_map)
    source_issue = _get_source_issue_from_records(data["source_records"])

    vuln = existing_vulns.get(cve_upper)
    if create_vulns:
        vuln, v_created, v_skipped, v_errors = _sync_vulnerability(
            cve, vuln, parent_id, parent_module, asset, source_issue, dry_run
        )
        vulns_created += v_created
        skipped += v_skipped
        errors += v_errors
        if vuln and cve_upper not in existing_vulns:
            existing_vulns[cve_upper] = vuln

    if create_issues:
        i_created, i_skipped, i_errors = _sync_issue(
            cve, existing_issues.get(cve_upper, []), parent_id, parent_module, asset, vuln, source_issue, dry_run
        )
        issues_created += i_created
        skipped += i_skipped
        errors += i_errors

    return vulns_created, issues_created, skipped, errors


def process_custom_field_sync(
    parent_id: int,
    parent_module: str,
    field_name: str,
    create_vulns: bool,
    create_issues: bool,
    dry_run: bool,
) -> Tuple[int, int, int, int]:
    """
    Process custom field CVE data to create missing vulnerabilities and issues.

    :param int parent_id: The parent ID
    :param str parent_module: The parent module
    :param str field_name: The custom field name containing CVE data
    :param bool create_vulns: Whether to create vulnerabilities
    :param bool create_issues: Whether to create issues
    :param bool dry_run: Whether this is a dry run
    :return: Tuple of (vulns_created, issues_created, skipped, errors)
    :rtype: Tuple[int, int, int, int]
    """
    existing_vulns, existing_issues, asset_map = _fetch_existing_data(parent_id, parent_module)

    console.print("[cyan]Scanning custom field '%s' for CVE data...[/cyan]" % field_name)
    custom_field_records = get_custom_field_data_by_parent(parent_id, parent_module, field_name)

    if not custom_field_records:
        console.print("[yellow]No records found with CVE data in custom field '%s'[/yellow]" % field_name)
        return 0, 0, 0, 0

    console.print("Found %d records with CVE data in custom field" % len(custom_field_records))
    cve_data = _collect_unique_cves(custom_field_records)
    console.print("Found %d unique CVEs to process" % len(cve_data))

    vulns_created = issues_created = skipped = errors = 0
    for cve, data in cve_data.items():
        v, i, s, e = _process_single_cve(
            cve,
            data,
            parent_id,
            parent_module,
            existing_vulns,
            existing_issues,
            asset_map,
            create_vulns,
            create_issues,
            dry_run,
        )
        vulns_created += v
        issues_created += i
        skipped += s
        errors += e

    return vulns_created, issues_created, skipped, errors


@cve_cleanup.command(name="sync-from-custom-field")
@click.option(
    "--parent-id",
    type=click.INT,
    required=True,
    help="Parent ID (e.g., security plan ID)",
)
@click.option(
    "--parent-module",
    type=click.STRING,
    default="securityplans",
    help="Parent module (default: 'securityplans')",
)
@click.option(
    "--custom-field-name",
    type=click.STRING,
    required=True,
    help="Name of the custom field containing CVE data",
)
@click.option(
    "--create-vulnerabilities/--no-vulnerabilities",
    default=True,
    help="Create missing vulnerabilities (default: True)",
)
@click.option(
    "--create-issues/--no-issues",
    default=True,
    help="Create missing issues (default: True)",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=True,
    help="Show what would be created without making changes (default: True)",
)
@click.option(
    "--confirm",
    is_flag=True,
    default=False,
    help="Actually perform the sync (disables dry-run)",
)
def sync_from_custom_field(
    parent_id: int,
    parent_module: str,
    custom_field_name: str,
    create_vulnerabilities: bool,
    create_issues: bool,
    dry_run: bool,
    confirm: bool,
):
    """
    Sync vulnerabilities and issues from custom field CVE data.

    Reads CVE values from a specified custom field on Issues and creates
    corresponding Vulnerability and Issue records without duplicates.

    Records are mapped to assets based on the assetIdentifier field.

    Example:
        regscale cve-cleanup sync-from-custom-field --parent-id 123 --custom-field-name "CVE List" --dry-run
    """
    app = Application()
    if not is_valid(app=app):
        error_and_exit(INVALID_TOKEN_ERROR)

    if confirm:
        dry_run = False

    mode = "[yellow]DRY RUN[/yellow]" if dry_run else "[red]LIVE[/red]"
    console.print("[bold blue]CVE Sync from Custom Field - %s[/bold blue]" % mode)

    if not dry_run:
        console.print("[bold red]WARNING: This will create new records in RegScale![/bold red]")
        if not click.confirm("Are you sure you want to proceed?"):
            console.print("Aborted.")
            return

    console.print("Parent: %s #%d" % (parent_module, parent_id))
    console.print("Custom field: %s" % custom_field_name)
    console.print("Create vulnerabilities: %s" % create_vulnerabilities)
    console.print("Create issues: %s" % create_issues)
    console.print("")

    vulns_created, issues_created, skipped, errors = process_custom_field_sync(
        parent_id=parent_id,
        parent_module=parent_module,
        field_name=custom_field_name,
        create_vulns=create_vulnerabilities,
        create_issues=create_issues,
        dry_run=dry_run,
    )

    # Summary
    console.print("\n[bold]Summary:[/bold]")
    console.print("  - Vulnerabilities created: %d" % vulns_created)
    console.print("  - Issues created: %d" % issues_created)
    console.print("  - Skipped (already exist): %d" % skipped)
    console.print("  - Errors: %d" % errors)

    if dry_run:
        console.print("\n[yellow]This was a dry run. No changes were made.[/yellow]")
        console.print("To apply changes, run with --confirm flag.")
