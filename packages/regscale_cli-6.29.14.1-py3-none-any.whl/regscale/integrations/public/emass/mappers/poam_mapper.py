"""
eMASS POA&M Mapper.

This module provides bidirectional mapping functions between eMASS POA&Ms and RegScale Issues.
It leverages the existing field_mapping.py from emass_client for field-level conversions.
"""

import logging
from typing import Any, Dict, List, Optional

from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.integrations.public.emass_client import field_mapping
from regscale.integrations.scanner.models import IntegrationFinding
from regscale.models import regscale_models

logger = logging.getLogger("regscale")


def map_emass_poam_to_finding(
    poam: Dict[str, Any],
    asset_identifier: Optional[str] = None,
) -> IntegrationFinding:
    """
    Map eMASS POA&M to IntegrationFinding.

    This function converts an eMASS POA&M to the IntegrationFinding format
    so it can be processed by the IssueHandler.

    :param Dict[str, Any] poam: Raw POA&M data from eMASS API
    :param Optional[str] asset_identifier: Asset identifier if available
    :return: IntegrationFinding object
    :rtype: IntegrationFinding
    """
    poam_id = str(poam.get("poamId", ""))
    control_labels = _extract_poam_control_labels(poam)
    weakness_description = poam.get("weaknessDescription", "")

    # Build basic information
    title = poam.get("weaknessName", "") or f"POA&M {poam_id}"
    description = _build_poam_description(poam)
    severity = _map_rar_to_severity(poam.get("rawSeverity") or poam.get("residualRisk", ""))

    # Extract dates
    dates = _extract_poam_dates(poam)

    # Extract mitigation and risk information
    recommendation = _build_recommendation(poam)
    risk_info = _extract_risk_adjustment_info(poam)
    point_of_contact = _extract_point_of_contact(poam)

    return IntegrationFinding(
        control_labels=control_labels,
        title=title,
        description=description,
        category="POA&M",
        severity=severity,
        status=regscale_models.ControlTestResultStatus.Open,
        priority=_map_severity_to_priority(severity),
        issue_type="POA&M",
        date_created=dates["created"],
        due_date=dates["due"],
        date_last_updated=dates["updated"],
        external_id=poam_id,
        asset_identifier=asset_identifier or "",
        identified_risk=weakness_description,
        recommendation_for_mitigation=recommendation,
        comments=_build_poam_comments(poam),
        source_report="eMASS POA&M",
        milestone_changes=_extract_milestone_info(poam),
        adjusted_risk_rating=risk_info["adjusted_rating"],
        risk_adjustment=risk_info["risk_adjustment"],
        basis_for_adjustment=risk_info["basis"],
        deviation_rationale=risk_info["deviation"],
        point_of_contact=point_of_contact,
        poam_comments=_build_poam_comments(poam),
        poam_id=poam_id,
        observations=_extract_detection_sources(poam),
    )


def _extract_poam_dates(poam: Dict[str, Any]) -> Dict[str, str]:
    """Extract all dates from POA&M."""
    return {
        "created": _parse_poam_date(poam.get("identifiedDate") or poam.get("createdDate")),
        "due": _parse_poam_date(poam.get("scheduledCompletionDate")),
        "updated": _parse_poam_date(poam.get("lastUpdated")) or get_current_datetime(),
    }


def _build_recommendation(poam: Dict[str, Any]) -> str:
    """Build recommendation text from POA&M mitigation data."""
    recommendation = poam.get("mitigation", "")
    if poam.get("recommendations"):
        recommendation = f"{recommendation}\n\nRecommendations: {poam['recommendations']}"
    return recommendation


def _extract_risk_adjustment_info(poam: Dict[str, Any]) -> Dict[str, Optional[str]]:
    """Extract risk adjustment information from POA&M."""
    risk_adjustment = "Yes" if (poam.get("isRiskAccepted") or poam.get("riskAccepted")) else "No"
    return {
        "risk_adjustment": risk_adjustment,
        "adjusted_rating": poam.get("adjustedRiskRating") or poam.get("residualRisk"),
        "basis": poam.get("basisForAdjustment", ""),
        "deviation": poam.get("deviationRationale", ""),
    }


def _extract_point_of_contact(poam: Dict[str, Any]) -> Optional[str]:
    """Extract point of contact from POA&M."""
    poc = poam.get("pointOfContact", {})
    if isinstance(poc, dict):
        return f"{poc.get('name', '')} - {poc.get('email', '')}"
    return str(poc) if poc else None


def map_regscale_issue_to_emass_poam(
    issue: regscale_models.Issue,
    emass_system_id: str,
) -> Dict[str, Any]:
    """
    Map RegScale Issue to eMASS POA&M format.

    This function converts a RegScale Issue to the eMASS POA&M format
    for pushing to the eMASS API. It leverages the existing field_mapping
    module from emass_client.

    :param regscale_models.Issue issue: RegScale Issue object
    :param str emass_system_id: eMASS system ID
    :return: POA&M data in eMASS format
    :rtype: Dict[str, Any]
    """
    # Use existing field mapping from emass_client
    poam_data = field_mapping.map_regscale_to_emass(issue, emass_system_id)

    # Add additional mappings specific to our integration
    if issue.control and issue.control.controlId:
        if "controlAcronym" not in poam_data or not poam_data["controlAcronym"]:
            poam_data["controlAcronym"] = issue.control.controlId

    # Map severity to RAR
    if issue.severity:
        poam_data["rawSeverity"] = _map_severity_to_rar(issue.severity)

    # Map issue type
    if issue.issueType:
        poam_data["weaknessSource"] = issue.issueType

    return poam_data


def _extract_poam_control_labels(poam: Dict[str, Any]) -> List[str]:
    """
    Extract control labels from POA&M for CCI mapping.

    :param Dict[str, Any] poam: POA&M data
    :return: List of control labels
    :rtype: List[str]
    """
    control_labels = []

    # Extract control acronym
    if "controlAcronym" in poam and poam["controlAcronym"]:
        control_labels.append(poam["controlAcronym"])

    # Extract CCIs
    if "cci" in poam:
        control_labels.extend(_extract_cci_labels(poam["cci"]))

    # Extract AP acronym
    if "apAcronym" in poam and poam["apAcronym"]:
        control_labels.append(poam["apAcronym"])

    return control_labels


def _extract_cci_labels(cci_data: Any) -> List[str]:
    """Extract CCI labels from various formats."""
    if isinstance(cci_data, list):
        return _extract_cci_from_list(cci_data)
    elif isinstance(cci_data, str):
        return [_format_cci_number(cci_data)]
    return []


def _extract_cci_from_list(cci_list: List[Any]) -> List[str]:
    """Extract CCI numbers from a list."""
    cci_labels = []
    for cci in cci_list:
        cci_number = cci.get("cciNumber") if isinstance(cci, dict) else cci
        if cci_number:
            cci_labels.append(_format_cci_number(str(cci_number)))
    return cci_labels


def _format_cci_number(cci_number: str) -> str:
    """Ensure CCI number has proper CCI- prefix."""
    return cci_number if cci_number.upper().startswith("CCI-") else f"CCI-{cci_number}"


def _map_rar_to_severity(rar: str) -> regscale_models.IssueSeverity:
    """
    Map eMASS Risk Assessment Rating (RAR) to RegScale severity.

    :param str rar: eMASS RAR value
    :return: RegScale IssueSeverity enum
    :rtype: regscale_models.IssueSeverity
    """
    rar_lower = rar.lower() if rar else ""

    severity_mapping = {
        "very high": regscale_models.IssueSeverity.Critical,
        "critical": regscale_models.IssueSeverity.Critical,
        "high": regscale_models.IssueSeverity.High,
        "moderate": regscale_models.IssueSeverity.Moderate,
        "medium": regscale_models.IssueSeverity.Moderate,
        "low": regscale_models.IssueSeverity.Low,
        "very low": regscale_models.IssueSeverity.Low,
    }

    return severity_mapping.get(rar_lower, regscale_models.IssueSeverity.Moderate)


def _map_severity_to_rar(severity: regscale_models.IssueSeverity) -> str:
    """
    Map RegScale severity to eMASS RAR.

    :param regscale_models.IssueSeverity severity: RegScale severity
    :return: eMASS RAR string
    :rtype: str
    """
    rar_mapping = {
        regscale_models.IssueSeverity.Critical: "Very High",
        regscale_models.IssueSeverity.High: "High",
        regscale_models.IssueSeverity.Moderate: "Moderate",
        regscale_models.IssueSeverity.Low: "Low",
        regscale_models.IssueSeverity.Informational: "Very Low",
    }

    return rar_mapping.get(severity, "Moderate")


def _map_poam_status(status: str) -> regscale_models.ControlTestResultStatus:
    """
    Map eMASS POA&M status to RegScale status.

    :param str status: eMASS POA&M status
    :return: RegScale ControlTestResultStatus
    :rtype: regscale_models.ControlTestResultStatus
    """
    status_lower = status.lower() if status else ""

    status_mapping = {
        "ongoing": regscale_models.ControlTestResultStatus.Open,
        "risk accepted": regscale_models.ControlTestResultStatus.Accepted,
        "completed": regscale_models.ControlTestResultStatus.Pass,
        "closed": regscale_models.ControlTestResultStatus.Pass,
        "false positive": regscale_models.ControlTestResultStatus.FalsePositive,
        "not applicable": regscale_models.ControlTestResultStatus.NotApplicable,
    }

    return status_mapping.get(status_lower, regscale_models.ControlTestResultStatus.Open)


def _map_severity_to_priority(severity: regscale_models.IssueSeverity) -> str:
    """
    Map severity to priority string.

    :param regscale_models.IssueSeverity severity: Issue severity
    :return: Priority string
    :rtype: str
    """
    priority_mapping = {
        regscale_models.IssueSeverity.Critical: "Critical",
        regscale_models.IssueSeverity.High: "High",
        regscale_models.IssueSeverity.Moderate: "Medium",
        regscale_models.IssueSeverity.Low: "Low",
        regscale_models.IssueSeverity.Informational: "Low",
    }

    return priority_mapping.get(severity, "Medium")


def _parse_poam_date(date_value: Optional[Any]) -> str:
    """
    Parse POA&M date from eMASS format.

    :param Optional[Any] date_value: Date value from eMASS
    :return: Formatted date string
    :rtype: str
    """
    # Reuse the date parsing logic from asset_mapper
    from regscale.integrations.public.emass.mappers.asset_mapper import _parse_emass_date

    return _parse_emass_date(date_value)


def _build_poam_description(poam: Dict[str, Any]) -> str:
    """
    Build comprehensive description from POA&M data.

    :param Dict[str, Any] poam: POA&M data
    :return: Formatted description
    :rtype: str
    """
    description_parts = []

    # Add weakness name and description
    if "weaknessName" in poam:
        description_parts.append(f"Weakness: {poam['weaknessName']}")

    if "weaknessDescription" in poam and poam["weaknessDescription"]:
        description_parts.append(f"\nDescription: {poam['weaknessDescription']}")

    # Add control information
    if "controlAcronym" in poam:
        description_parts.append(f"\nControl: {poam['controlAcronym']}")

    # Add severity
    if "rawSeverity" in poam:
        description_parts.append(f"Severity: {poam['rawSeverity']}")

    # Add detection method
    if "detectionMethod" in poam:
        description_parts.append(f"Detection Method: {poam['detectionMethod']}")

    return "\n".join(description_parts) if description_parts else "eMASS POA&M"


def _extract_detection_sources(poam: Dict[str, Any]) -> str:
    """
    Extract weakness detection sources from POA&M.

    :param Dict[str, Any] poam: POA&M data
    :return: Formatted detection sources
    :rtype: str
    """
    sources = []

    if "weaknessDetectionSource" in poam:
        source_data = poam["weaknessDetectionSource"]
        if isinstance(source_data, list):
            for source in source_data:
                if isinstance(source, dict):
                    sources.append(source.get("detectionSource", str(source)))
                else:
                    sources.append(str(source))
        elif isinstance(source_data, str):
            sources.append(source_data)

    if "sourceIdentVuln" in poam and poam["sourceIdentVuln"]:
        sources.append(f"Source: {poam['sourceIdentVuln']}")

    return "\n".join(sources) if sources else ""


def _extract_milestone_info(poam: Dict[str, Any]) -> Optional[str]:
    """
    Extract milestone information from POA&M.

    :param Dict[str, Any] poam: POA&M data
    :return: Formatted milestone information or None
    :rtype: Optional[str]
    """
    if "milestones" not in poam:
        return None

    milestones = poam["milestones"]
    if not milestones or not isinstance(milestones, list):
        return None

    milestone_parts = []
    for milestone in milestones:
        if isinstance(milestone, dict):
            milestone_desc = milestone.get("description", "")
            milestone_date = milestone.get("scheduledCompletionDate", "")
            milestone_status = milestone.get("status", "")

            milestone_parts.append(f"- {milestone_desc} (Due: {milestone_date}, Status: {milestone_status})")

    return "\n".join(milestone_parts) if milestone_parts else None


def _build_poam_comments(poam: Dict[str, Any]) -> Optional[str]:
    """
    Build comments from POA&M data.

    :param Dict[str, Any] poam: POA&M data
    :return: Formatted comments or None
    :rtype: Optional[str]
    """
    comments = []

    if "comments" in poam and poam["comments"]:
        comments.append(poam["comments"])

    if "mitigationJustification" in poam and poam["mitigationJustification"]:
        comments.append(f"Mitigation Justification: {poam['mitigationJustification']}")

    if "residualRiskLevel" in poam and poam["residualRiskLevel"]:
        comments.append(f"Residual Risk Level: {poam['residualRiskLevel']}")

    return "\n\n".join(comments) if comments else None
