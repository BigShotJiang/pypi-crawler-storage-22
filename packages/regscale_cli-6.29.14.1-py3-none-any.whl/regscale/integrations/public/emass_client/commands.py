"""
CLI commands for eMASS integration.

This module implements Click commands for the eMASS API integration,
providing CLI interface for POA&M sync, Control Implementation sync,
and connection testing for the eMASS integration.
"""

import logging
from typing import Any, Dict, List, Optional

import click

from regscale.core.app.api import Api
from regscale.integrations.public.emass_client import variables
from regscale.integrations.public.emass_client.integration import (
    EmassClient,
    EmassControlsIntegration,
    EmassPoamIntegration,
    EmassSystemsIntegration,
)

logger = logging.getLogger("regscale")


# ===========================
# Helper Functions for RegScale API
# ===========================


def fetch_case_by_id(api: Api, case_id: int) -> Dict[str, Any]:
    """
    Fetch a RegScale Case by ID.

    Args:
        api: RegScale API client
        case_id: Case ID

    Returns:
        Case data dictionary

    Raises:
        ValueError: If case not found
    """
    from regscale.models.regscale_models.issue import Issue

    try:
        issue = Issue.get_object(case_id)
        if issue:
            return issue.model_dump()
        raise ValueError("Case %d not found" % case_id)
    except Exception as e:
        logger.error("Error fetching case %s: %s", case_id, e)
        raise


def fetch_cases_by_ssp(api: Api, ssp_id: int) -> List[Dict[str, Any]]:
    """
    Fetch all Cases linked to an SSP.

    Args:
        api: RegScale API client
        ssp_id: SSP ID

    Returns:
        List of Case data dictionaries
    """
    from regscale.models.regscale_models.issue import Issue
    from regscale.models.regscale_models.security_plan import SecurityPlan

    try:
        issues = Issue.get_all_by_parent(parent_id=ssp_id, parent_module=SecurityPlan.get_module_string())
        return [issue.model_dump() for issue in issues]
    except Exception as e:
        logger.error("Error fetching cases for SSP %s: %s", ssp_id, e)
        return []


def fetch_control_by_id(api: Api, control_impl_id: int) -> Dict[str, Any]:
    """
    Fetch a RegScale Control Implementation by ID.

    Args:
        api: RegScale API client
        control_impl_id: Control Implementation ID

    Returns:
        Control Implementation data dictionary

    Raises:
        ValueError: If control not found
    """
    from regscale.models.regscale_models.control_implementation import ControlImplementation

    try:
        control = ControlImplementation.get_object(control_impl_id)
        if control:
            return control.model_dump()
        raise ValueError("Control Implementation %d not found" % control_impl_id)
    except Exception as e:
        logger.error("Error fetching control %s: %s", control_impl_id, e)
        raise


def fetch_controls_by_ssp(api: Api, ssp_id: int, control_family: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Fetch all Control Implementations for an SSP.

    Args:
        api: RegScale API client
        ssp_id: SSP ID
        control_family: Optional control family filter (e.g., 'AC', 'AU')

    Returns:
        List of Control Implementation data dictionaries
    """
    from regscale.models.regscale_models.control_implementation import ControlImplementation
    from regscale.models.regscale_models.security_plan import SecurityPlan

    try:
        controls = ControlImplementation.get_all_by_parent(
            parent_id=ssp_id, parent_module=SecurityPlan.get_module_string()
        )
        if control_family:
            controls = [c for c in controls if c.control and str(c.control.controlId).startswith(control_family + "-")]
        return [control.model_dump() for control in controls]
    except Exception as e:
        logger.error("Error fetching controls for SSP %s: %s", ssp_id, e)
        return []


# ===========================
# Connection and Authentication
# ===========================


@click.command()
@click.option("--base-url", help="eMASS API base URL", default=None)
@click.option("--api-key", help="eMASS API key", default=None)
def test_connection(base_url: Optional[str], api_key: Optional[str]):
    """
    Test connection to eMASS API.

    Validates credentials and verifies API accessibility.
    """
    try:
        client = EmassClient(base_url=base_url, api_key=api_key)
        if client.test_connection():
            click.echo("[OK] eMASS connection successful")
            config = variables.get_config_summary()
            click.echo("\nConfiguration:")
            for key, value in config.items():
                click.echo(f"  {key}: {value}")
        else:
            click.echo("[ERROR] eMASS connection failed", err=True)
            raise click.Abort()
    except Exception as e:
        logger.error("Connection test failed: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


@click.command()
@click.option("--api-key", help="eMASS API key to configure", required=True)
@click.option("--base-url", help="eMASS API base URL", required=True)
@click.option("--user-uid", help="User UID for eMASS operations", default=None)
def authenticate(api_key: str, base_url: str, user_uid: Optional[str]):
    """
    Configure eMASS authentication credentials.

    Sets environment variables for eMASS API access.
    """
    import os

    os.environ["EMASS_API_KEY"] = api_key
    os.environ["EMASS_BASE_URL"] = base_url
    if user_uid:
        os.environ["EMASS_USER_UID"] = user_uid

    click.echo("[OK] eMASS credentials configured")
    click.echo(f"  Base URL: {base_url}")
    click.echo(f"  User UID: {user_uid or 'Not set'}")

    # Test connection
    try:
        client = EmassClient(base_url=base_url, api_key=api_key)
        if client.test_connection():
            click.echo("[OK] Authentication verified")
        else:
            click.echo("[WARNING] Authentication configured but connection test failed", err=True)
    except Exception as e:
        click.echo(f"[WARNING] {e}", err=True)


# ===========================
# POA&M Sync Commands
# ===========================


@click.command()
@click.option("--case-id", help="RegScale Case ID to push", type=int, required=True)
@click.option("--system-id", help="eMASS system ID", type=int, required=True)
@click.option("--no-validate", is_flag=True, help="Skip business rule validation")
def push_poam(case_id: int, system_id: int, no_validate: bool):
    """
    Push RegScale Case to eMASS as POA&M.

    Creates new POA&M or updates existing (idempotent operation).
    """
    click.echo(f"Pushing Case {case_id} to eMASS system {system_id}")

    try:
        # Initialize API clients
        regscale_api = Api()
        emass_client = EmassClient()
        integration = EmassPoamIntegration(emass_client)

        # Fetch Case data from RegScale
        click.echo(f"Fetching Case {case_id} from RegScale...")
        case_data = fetch_case_by_id(regscale_api, case_id)

        # Push to eMASS
        validate = not no_validate
        click.echo(f"Pushing to eMASS (validation: {validate})...")
        response = integration.push_poam(case_data, system_id, validate=validate)

        # Display results
        response_data = response.get("data", [{}])[0]
        click.echo("\n[OK] POA&M pushed successfully")
        click.echo(f"  POA&M ID: {response_data.get('poamId')}")
        click.echo(f"  Display POA&M ID: {response_data.get('displayPoamId')}")
        click.echo(f"  External UID: {response_data.get('externalUid')}")

    except Exception as e:
        logger.error("Error pushing POA&M: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


@click.command()
@click.option("--system-id", help="eMASS system ID", type=int, required=True)
@click.option("--control-acronyms", help="Comma-separated control acronyms to filter (e.g., 'AC-1,AC-2')", default=None)
@click.option("--output", help="Output file for pulled POA&Ms (JSON)", type=click.Path())
def pull_poams(system_id: int, control_acronyms: Optional[str], output: Optional[str]):
    """
    Pull POA&Ms from eMASS to RegScale format.

    Retrieves POA&Ms and converts to RegScale Case format.
    """
    import json

    click.echo(f"Pulling POA&Ms from eMASS system {system_id}")

    try:
        client = EmassClient()
        integration = EmassPoamIntegration(client)

        # Parse control acronyms
        acronyms = control_acronyms.split(",") if control_acronyms else None

        cases = integration.pull_poams(system_id, control_acronyms=acronyms)

        click.echo(f"[OK] Pulled {len(cases)} POA&Ms")

        # Output to file or stdout
        if output:
            with open(output, "w", encoding="utf-8") as f:
                json.dump(cases, f, indent=2)
            click.echo(f"  Saved to: {output}")
        else:
            for case in cases:
                click.echo(f"  - {case.get('title')} (Control: {case.get('controlAcronym')})")

    except Exception as e:
        logger.error("Error pulling POA&Ms: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


@click.command()
@click.option("--system-id", help="eMASS system ID", type=int, required=True)
@click.option("--ssp-id", help="RegScale SSP ID to sync cases from", type=int, default=None)
@click.option("--direction", type=click.Choice(["push", "pull", "bidirectional"]), default="bidirectional")
def sync_poams(system_id: int, ssp_id: Optional[int], direction: str):
    """
    Bidirectional POA&M sync between RegScale and eMASS.

    Pushes RegScale Cases and pulls eMASS POA&Ms.
    """
    click.echo(f"Syncing POA&Ms ({direction}) for eMASS system {system_id}")

    try:
        # Initialize API clients
        regscale_api = Api()
        emass_client = EmassClient()
        integration = EmassPoamIntegration(emass_client)

        # Fetch cases from RegScale if pushing
        regscale_cases = []
        if direction in ["push", "bidirectional"] and ssp_id:
            click.echo(f"Fetching Cases from SSP {ssp_id}...")
            regscale_cases = fetch_cases_by_ssp(regscale_api, ssp_id)
            click.echo(f"Found {len(regscale_cases)} Cases")

        if direction in ["push", "bidirectional"]:
            if not regscale_cases:
                click.echo("[WARNING] No Cases to push (specify --ssp-id)")
            else:
                click.echo(f"Pushing {len(regscale_cases)} Cases to eMASS...")
                for case in regscale_cases:
                    try:
                        integration.push_poam(case, system_id)
                        click.echo(f"  [OK] Pushed Case {case.get('id')}: {case.get('title')}")
                    except Exception as push_error:
                        click.echo(f"  [ERROR] Error pushing Case {case.get('id')}: {push_error}", err=True)

        if direction in ["pull", "bidirectional"]:
            click.echo("Pulling POA&Ms from eMASS...")
            cases = integration.pull_poams(system_id)
            click.echo(f"[OK] Pulled {len(cases)} POA&Ms")
            for case in cases[:10]:  # Show first 10
                click.echo(f"  - {case.get('title')} (Control: {case.get('controlAcronym')})")
            if len(cases) > 10:
                click.echo(f"  ... and {len(cases) - 10} more")

        if direction == "bidirectional" and regscale_cases:
            click.echo("\n" + "=" * 50)
            results = integration.sync_poams_bidirectional(system_id, regscale_cases)
            click.echo("\n[OK] Bidirectional sync complete:")
            click.echo(f"  Pushed: {results['pushed']}")
            click.echo(f"  Pulled: {results['pulled']}")
            click.echo(f"  Errors: {len(results['errors'])}")

    except Exception as e:
        logger.error("Error syncing POA&Ms: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


# ===========================
# Control Implementation Sync Commands
# ===========================


@click.command()
@click.option("--control-impl-id", help="RegScale Control Implementation ID", type=int, required=True)
@click.option("--system-id", help="eMASS system ID", type=int, required=True)
def push_control(control_impl_id: int, system_id: int):
    """
    Push RegScale Control Implementation to eMASS as Test Result.

    Maps Control Implementation fields to eMASS Test Result format.
    """
    click.echo(f"Pushing Control Implementation {control_impl_id} to eMASS system {system_id}")

    try:
        # Initialize API clients
        regscale_api = Api()
        emass_client = EmassClient()
        integration = EmassControlsIntegration(emass_client)

        # Fetch control data from RegScale
        click.echo(f"Fetching Control Implementation {control_impl_id} from RegScale...")
        control_data = fetch_control_by_id(regscale_api, control_impl_id)

        # Push to eMASS as Test Result
        click.echo("Pushing to eMASS as Test Result...")
        response = integration.push_control_to_test_result(control_data, system_id)

        # Display results
        response_data = response.get("data", [{}])[0]
        click.echo("\n[OK] Test Result created successfully")
        click.echo(f"  Control: {control_data.get('controlId')}")
        click.echo(f"  Test Result ID: {response_data.get('testResultId')}")

    except Exception as e:
        logger.error("Error pushing control: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


@click.command()
@click.option("--ssp-id", help="RegScale SSP ID to sync controls from", type=int, required=True)
@click.option("--system-id", help="eMASS system ID", type=int, required=True)
@click.option("--control-family", help="Filter by control family (e.g., 'AC', 'AU')", default=None)
def sync_controls(ssp_id: int, system_id: int, control_family: Optional[str]):
    """
    Sync Control Implementations from RegScale SSP to eMASS Test Results.

    Pushes all controls in SSP to eMASS as Test Results.
    """
    click.echo(f"Syncing controls from SSP {ssp_id} to eMASS system {system_id}")
    if control_family:
        click.echo(f"  Filtering by family: {control_family}")

    try:
        # Initialize API clients
        regscale_api = Api()
        emass_client = EmassClient()
        integration = EmassControlsIntegration(emass_client)

        # Fetch controls from RegScale SSP
        click.echo(f"Fetching controls from SSP {ssp_id}...")
        controls = fetch_controls_by_ssp(regscale_api, ssp_id, control_family)

        if not controls:
            click.echo("[WARNING] No controls found to sync")
            return

        click.echo(f"Found {len(controls)} controls to sync")
        click.echo("Syncing controls to eMASS...")

        # Sync controls
        stats = integration.sync_controls(system_id, controls)

        click.echo("\n[OK] Control sync complete:")
        click.echo(f"  Synced: {stats['synced']}")
        click.echo(f"  Errors: {stats['errors']}")

    except Exception as e:
        logger.error("Error syncing controls: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


# ===========================
# System Management Commands
# ===========================


@click.command()
@click.option("--output-format", type=click.Choice(["table", "json"]), default="table")
def list_systems(output_format: str):
    """
    List all eMASS systems accessible to the user.

    Displays system ID, name, and authorization status.
    """
    import json

    try:
        client = EmassClient()
        integration = EmassSystemsIntegration(client)

        systems = integration.get_systems()

        if output_format == "json":
            click.echo(json.dumps(systems, indent=2))
        else:
            click.echo(f"\nFound {len(systems)} eMASS systems:\n")
            click.echo(f"{'System ID':<12} {'System Name':<40} {'Authorization Status':<25}")
            click.echo("-" * 80)
            for system in systems:
                sys_id = system.get("systemId", "N/A")
                sys_name = (system.get("name") or "Unknown")[:38]
                status = (system.get("authorizationStatus") or "Unknown")[:23]
                click.echo(f"{sys_id:<12} {sys_name:<40} {status:<25}")

    except Exception as e:
        logger.error("Error listing systems: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


@click.command()
@click.option("--system-id", help="eMASS system ID", type=int, required=True)
def get_system_info(system_id: int):
    """
    Get detailed information about an eMASS system.

    Shows system metadata, authorization status, and contact information.
    """
    try:
        client = EmassClient()
        integration = EmassSystemsIntegration(client)

        system = integration.get_system(system_id)

        click.echo("\nSystem Information:")
        click.echo(f"  System ID: {system.get('systemId', 'N/A')}")
        click.echo(f"  System Name: {system.get('name', 'Unknown')}")
        click.echo(f"  Acronym: {system.get('acronym', 'N/A')}")
        click.echo(f"  Authorization Status: {system.get('authorizationStatus', 'Unknown')}")
        click.echo(f"  Impact Level: {system.get('impact', 'Unknown')}")
        click.echo(f"  Policy: {system.get('policy', 'N/A')}")
        click.echo(f"  System Type: {system.get('systemType', 'N/A')}")
        click.echo(f"  Registration Type: {system.get('registrationType', 'N/A')}")
        click.echo(f"  Owning Organization: {system.get('owningOrganization', 'N/A')}")
        click.echo(f"  Description: {system.get('description', 'N/A')[:100]}")  # Truncate long descriptions

    except Exception as e:
        logger.error("Error getting system info: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


# ===========================
# Artifact Management Commands
# ===========================


@click.command()
@click.option("--system-id", help="eMASS system ID", type=int, required=True)
@click.option("--output-format", type=click.Choice(["table", "json"]), default="table")
def list_artifacts(system_id: int, output_format: str):
    """
    List all artifacts for an eMASS system.

    Displays artifact ID, filename, type, and associated control.
    """
    import json

    try:
        from regscale.integrations.public.emass_client.integration import EmassArtifactsIntegration

        client = EmassClient()
        integration = EmassArtifactsIntegration(client)

        artifacts = integration.get_artifacts(system_id)

        if output_format == "json":
            click.echo(json.dumps(artifacts, indent=2))
        else:
            click.echo(f"\nFound {len(artifacts)} artifacts for system {system_id}:\n")
            click.echo(f"{'Artifact ID':<15} {'Filename':<40} {'Type':<20} {'Control':<15}")
            click.echo("-" * 90)
            for artifact in artifacts:
                art_id = str(artifact.get("artifactId", "N/A"))
                filename = artifact.get("filename", "Unknown")[:38]
                art_type = artifact.get("type", "Unknown")[:18]
                control = artifact.get("controlAcronym", "N/A")
                click.echo(f"{art_id:<15} {filename:<40} {art_type:<20} {control:<15}")

    except Exception as e:
        logger.error("Error listing artifacts: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


@click.command()
@click.option("--system-id", help="eMASS system ID", type=int, required=True)
@click.option("--file-path", help="Path to file to upload", type=click.Path(exists=True), required=True)
@click.option("--artifact-type", help="Type of artifact (e.g., 'Test Results', 'Evidence')", required=True)
@click.option("--control-acronym", help="Control acronym to associate with (e.g., 'AC-1')", default=None)
def upload_artifact(system_id: int, file_path: str, artifact_type: str, control_acronym: Optional[str]):
    """
    Upload single artifact/evidence file to eMASS system.

    Associates artifact with specified system and optionally with a control.
    """
    try:
        import os

        from regscale.integrations.public.emass_client.integration import EmassArtifactsIntegration

        client = EmassClient()
        integration = EmassArtifactsIntegration(client)

        file_name = os.path.basename(file_path)
        file_size = os.path.getsize(file_path)

        click.echo(f"Uploading artifact: {file_name} ({file_size} bytes)")
        click.echo(f"  System ID: {system_id}")
        click.echo(f"  Type: {artifact_type}")
        if control_acronym:
            click.echo(f"  Control: {control_acronym}")

        response = integration.upload_artifact(system_id, file_path, artifact_type, control_acronym)

        response_data = response.get("data", [{}])[0]
        click.echo("\n[OK] Artifact uploaded successfully")
        click.echo(f"  Artifact ID: {response_data.get('artifactId')}")
        click.echo(f"  Filename: {response_data.get('filename')}")

    except Exception as e:
        logger.error("Error uploading artifact: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


@click.command()
@click.option("--system-id", help="eMASS system ID", type=int, required=True)
@click.option("--directory", help="Directory containing files to upload", type=click.Path(exists=True), required=True)
@click.option("--artifact-type", help="Type of artifacts", required=True)
@click.option("--pattern", help="File pattern to match (e.g., '*.pdf')", default="*")
def upload_artifacts_bulk(system_id: int, directory: str, artifact_type: str, pattern: str):
    """
    Upload multiple artifacts from directory to eMASS system.

    Processes all files matching the pattern in the specified directory.
    Uses automatic retry logic and chunking for large batches.
    """
    try:
        import glob
        import os

        from regscale.integrations.public.emass_client.integration import EmassArtifactsIntegration

        client = EmassClient()
        integration = EmassArtifactsIntegration(client)

        # Find all matching files
        search_pattern = os.path.join(directory, pattern)
        file_paths = glob.glob(search_pattern)

        if not file_paths:
            click.echo(f"[WARNING] No files found matching pattern: {pattern}")
            return

        click.echo(f"Found {len(file_paths)} files to upload")
        click.echo(f"  System ID: {system_id}")
        click.echo(f"  Artifact Type: {artifact_type}")
        click.echo(f"  Directory: {directory}")
        click.echo(f"  Pattern: {pattern}\n")

        if not click.confirm(f"Upload {len(file_paths)} files?", default=True):
            click.echo("Upload cancelled")
            return

        # Upload files
        results = integration.upload_artifacts_bulk(system_id, file_paths, artifact_type)

        click.echo("\n[OK] Bulk upload complete:")
        click.echo(f"  Total: {results['total']}")
        click.echo(f"  Successful: {results['successful']}")
        click.echo(f"  Failed: {results['failed']}")

        if results["errors"]:
            click.echo("\nErrors:")
            for error in results["errors"][:10]:  # Show first 10 errors
                click.echo(f"  - {error['file']}: {error['error']}", err=True)
            if len(results["errors"]) > 10:
                click.echo(f"  ... and {len(results['errors']) - 10} more errors")

    except Exception as e:
        logger.error("Error in bulk upload: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


# ===========================
# Milestone Management Commands
# ===========================


@click.command()
@click.option("--system-id", help="eMASS system ID", type=int, required=True)
@click.option("--poam-id", help="eMASS POA&M ID", type=int, required=True)
@click.option("--output-format", type=click.Choice(["table", "json"]), default="table")
def list_milestones(system_id: int, poam_id: int, output_format: str):
    """
    List all milestones for a POA&M.

    Displays milestone ID, description, scheduled completion date, and review status.
    """
    import json
    from datetime import datetime

    try:
        from regscale.integrations.public.emass_client.integration import EmassPoamIntegration

        client = EmassClient()
        integration = EmassPoamIntegration(client)

        milestones = integration.get_milestones(system_id, poam_id)

        if output_format == "json":
            click.echo(json.dumps(milestones, indent=2))
        else:
            click.echo(f"\nFound {len(milestones)} milestones for POA&M {poam_id}:\n")
            click.echo(f"{'ID':<8} {'Description':<40} {'Due Date':<12} {'Status':<15}")
            click.echo("-" * 75)

            for milestone in milestones:
                mid = str(milestone.get("milestoneId", "N/A"))
                description = (milestone.get("description") or "Unknown")[:38]
                scheduled_date = milestone.get("scheduledCompletionDate")
                due_date = (
                    datetime.fromtimestamp(scheduled_date / 1000).strftime("%Y-%m-%d") if scheduled_date else "N/A"
                )
                status = (milestone.get("reviewStatus") or "N/A")[:13]

                click.echo(f"{mid:<8} {description:<40} {due_date:<12} {status:<15}")

            click.echo()

    except Exception as e:
        logger.error("Error listing milestones: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


@click.command()
@click.option("--system-id", help="eMASS system ID", type=int, required=True)
@click.option("--poam-id", help="eMASS POA&M ID", type=int, required=True)
@click.option("--description", help="Milestone description", required=True)
@click.option("--due-date", help="Due date (YYYY-MM-DD format)", required=True)
def add_milestone(system_id: int, poam_id: int, description: str, due_date: str):
    """
    Add a single milestone to a POA&M.

    Due date should be in YYYY-MM-DD format (e.g., 2025-03-15).
    """
    from datetime import datetime

    try:
        from regscale.integrations.public.emass_client.integration import EmassPoamIntegration

        # Parse due date to Unix timestamp (milliseconds)
        try:
            date_obj = datetime.strptime(due_date, "%Y-%m-%d")
            timestamp = int(date_obj.timestamp() * 1000)
        except ValueError as e:
            click.echo(f"[ERROR] Invalid date format: {due_date}. Use YYYY-MM-DD format.", err=True)
            raise click.Abort() from e

        click.echo(f"\nAdding milestone to POA&M {poam_id}:")
        click.echo(f"  Description: {description}")
        click.echo(f"  Due Date: {due_date}")

        client = EmassClient()
        integration = EmassPoamIntegration(client)

        response = integration.add_milestone(system_id, poam_id, description, timestamp)

        click.echo("\n[OK] Milestone added successfully")
        click.echo(f"Response: {response}")

    except Exception as e:
        logger.error("Error adding milestone: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


@click.command()
@click.option("--system-id", help="eMASS system ID", type=int, required=True)
@click.option("--poam-id", help="eMASS POA&M ID", type=int, required=True)
@click.option(
    "--milestones-json", help="JSON string with milestone array (description, scheduledCompletionDate)", required=True
)
def add_milestones_bulk(system_id: int, poam_id: int, milestones_json: str):
    """
    Add multiple milestones to a POA&M from JSON input.

    JSON format: [{"description": "...", "scheduledCompletionDate": 1234567890000}, ...]
    scheduledCompletionDate should be Unix timestamp in milliseconds.
    """
    import json

    try:
        from regscale.integrations.public.emass_client.integration import EmassPoamIntegration

        # Parse JSON input
        try:
            milestones = json.loads(milestones_json)
            if not isinstance(milestones, list):
                raise ValueError("Milestones JSON must be an array")
        except json.JSONDecodeError as e:
            click.echo(f"[ERROR] Invalid JSON format: {e}", err=True)
            raise click.Abort() from e

        click.echo(f"\nAdding {len(milestones)} milestones to POA&M {poam_id}...")

        if not click.confirm(f"\nDo you want to proceed with adding {len(milestones)} milestones?", default=True):
            click.echo("Operation cancelled")
            raise click.Abort()

        client = EmassClient()
        integration = EmassPoamIntegration(client)

        results = integration.add_milestones_bulk(system_id, poam_id, milestones)

        click.echo("\n[OK] Bulk milestone addition complete:")
        click.echo(f"  Total: {results['total']}")
        click.echo(f"  Successful: {results['successful']}")
        click.echo(f"  Failed: {results['failed']}")

        if results["errors"]:
            click.echo("\nErrors:")
            for error in results["errors"][:5]:
                click.echo(f"  - {error['milestone']}: {error['error']}")
            if len(results["errors"]) > 5:
                click.echo(f"  ... and {len(results['errors']) - 5} more errors")

    except Exception as e:
        logger.error("Error in bulk milestone addition: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


@click.command()
@click.option("--system-id", help="eMASS system ID", type=int, required=True)
@click.option("--poam-id", help="eMASS POA&M ID", type=int, required=True)
@click.option("--milestone-id", help="Milestone ID to update", type=int, required=True)
@click.option("--description", help="Updated milestone description", required=True)
@click.option("--due-date", help="Updated due date (YYYY-MM-DD format)", required=True)
def update_milestone(system_id: int, poam_id: int, milestone_id: int, description: str, due_date: str):
    """
    Update an existing milestone.

    Due date should be in YYYY-MM-DD format (e.g., 2025-03-15).
    """
    from datetime import datetime

    try:
        from regscale.integrations.public.emass_client.integration import EmassPoamIntegration

        # Parse due date to Unix timestamp (milliseconds)
        try:
            date_obj = datetime.strptime(due_date, "%Y-%m-%d")
            timestamp = int(date_obj.timestamp() * 1000)
        except ValueError as e:
            click.echo(f"[ERROR] Invalid date format: {due_date}. Use YYYY-MM-DD format.", err=True)
            raise click.Abort() from e

        click.echo(f"\nUpdating milestone {milestone_id} in POA&M {poam_id}:")
        click.echo(f"  Description: {description}")
        click.echo(f"  Due Date: {due_date}")

        client = EmassClient()
        integration = EmassPoamIntegration(client)

        response = integration.update_milestone(system_id, poam_id, milestone_id, description, timestamp)

        click.echo("\n[OK] Milestone updated successfully")
        click.echo(f"Response: {response}")

    except Exception as e:
        logger.error("Error updating milestone: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


@click.command()
@click.option("--system-id", help="eMASS system ID", type=int, required=True)
@click.option("--poam-id", help="eMASS POA&M ID", type=int, required=True)
@click.option("--milestone-ids", help="Comma-separated milestone IDs to delete", required=True)
def delete_milestones(system_id: int, poam_id: int, milestone_ids: str):
    """
    Delete one or more milestones from a POA&M.

    Milestone IDs should be comma-separated (e.g., "123,456,789").
    """
    try:
        from regscale.integrations.public.emass_client.integration import EmassPoamIntegration

        # Parse milestone IDs
        ids = [int(mid.strip()) for mid in milestone_ids.split(",")]

        click.echo(f"\nDeleting {len(ids)} milestone(s) from POA&M {poam_id}")
        click.echo(f"Milestone IDs: {ids}")

        if not click.confirm("\nThis action cannot be undone. Do you want to proceed?", default=False):
            click.echo("Operation cancelled")
            raise click.Abort()

        client = EmassClient()
        integration = EmassPoamIntegration(client)

        response = integration.delete_milestone(system_id, poam_id, ids)

        click.echo("\n[OK] Milestones deleted successfully")
        click.echo(f"Response: {response}")

    except ValueError as e:
        click.echo(f"[ERROR] Invalid milestone IDs format: {e}", err=True)
        raise click.Abort() from e
    except Exception as e:
        logger.error("Error deleting milestones: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()


# ===========================
# Configuration Commands
# ===========================


@click.command()
def show_config():
    """
    Display current eMASS integration configuration.

    Shows all configuration variables and their current values.
    """
    config = variables.get_config_summary()

    click.echo("\neMASS Integration Configuration:\n")
    for key, value in config.items():
        click.echo(f"  {key}: {value}")

    # Validate configuration
    is_valid, missing = variables.validate_required_config()
    if is_valid:
        click.echo("\n[OK] Configuration is valid")
    else:
        click.echo(f"\n[ERROR] Missing required configuration: {', '.join(missing)}", err=True)


@click.command()
def show_field_mappings():
    """
    Display summary of field mappings between RegScale and eMASS.

    Shows count of mapped fields per category.
    """
    from regscale.integrations.public.emass_client.field_mapping import get_field_mapping_summary

    summary = get_field_mapping_summary()

    click.echo("\neMASS Field Mapping Summary:\n")
    click.echo(f"Total Control Implementation Fields: {summary['total_control_implementation_fields']}")
    click.echo("\nField Breakdown:")
    for category, count in summary["control_field_breakdown"].items():
        click.echo(f"  {category.replace('_', ' ').title()}: {count} fields")

    click.echo("\nCase to POA&M Mappings:")
    for category, fields in summary["case_to_poam_mappings"].items():
        click.echo(f"  {category.replace('_', ' ').title()}: {', '.join(fields[:5])}...")

    click.echo(f"\nMilestone Fields: {', '.join(summary['milestone_mappings'])}")
    click.echo(f"Artifact Fields: {', '.join(summary['artifact_mappings'])}")
    click.echo(f"Idempotency Fields: {', '.join(summary['idempotency_fields'])}")


# ===========================
# XML Import Commands
# ===========================


def _display_dry_run_results(parser, create_custom_fields: bool, separator: str):
    """Display dry run validation results."""
    click.echo("DRY RUN: Validating data without creating records...\n")

    # Check for unmapped fields
    unmapped = parser.get_unmapped_fields()
    if unmapped:
        click.echo(f"[WARNING] Found {len(unmapped)} unmapped XML fields:")
        for field in unmapped[:10]:
            click.echo(f"  - {field}")
        if len(unmapped) > 10:
            click.echo(f"  ... and {len(unmapped) - 10} more")

        if create_custom_fields:
            click.echo(
                f"\n[OK] Would create {len(unmapped)} custom fields in RegScale (use --create-custom-fields flag)"
            )
    else:
        click.echo("[OK] All XML fields have mappings")

    click.echo(f"\n{separator}")
    click.echo("DRY RUN COMPLETE - No changes made to RegScale")
    click.echo(f"{separator}\n")


def _display_import_summary(summary: dict, output_format: str):
    """Display import summary based on output format."""
    import json

    if output_format == "json":
        click.echo(json.dumps(summary, indent=2))
    elif output_format == "detailed":
        click.echo(f"Systems Created: {summary['systems_created']}")
        click.echo(f"Controls Created: {summary['controls_created']}")
        click.echo(f"POA&Ms Created: {summary['poams_created']}")
        click.echo(f"Artifacts Created: {summary['artifacts_created']}")
        click.echo(f"Milestones Created: {summary['milestones_created']}")
        if summary.get("errors"):
            click.echo(f"\n[WARNING] Errors: {len(summary['errors'])}")
            for error in summary["errors"][:5]:
                click.echo(f"  - {error}")
    else:
        click.echo("Summary:")
        click.echo(f"  [OK] {summary['systems_created']} system(s) created")
        click.echo(f"  [OK] {summary['controls_created']} control(s) created")
        click.echo(f"  [OK] {summary['poams_created']} POA&M(s) created")
        if summary.get("errors"):
            click.echo(f"  [WARNING] {len(summary['errors'])} error(s) encountered")


def _perform_live_import(parser, system_data: dict, controls: list, poams: list, separator: str, output_format: str):
    """Perform live import of XML data to RegScale."""
    from regscale.core.app.api import Api
    from regscale.integrations.public.emass_client.xml_import import EmassXmlImporter

    api = Api()
    importer = EmassXmlImporter(parser, api)

    click.echo("Importing data to RegScale...\n")

    # Import system
    ssp_id = importer.import_system(system_data, dry_run=False)
    if ssp_id:
        click.echo(f"[OK] Created SSP (ID: {ssp_id})")

        # Import controls
        if controls:
            importer.import_controls(ssp_id, controls, dry_run=False)
            click.echo(f"[OK] Imported {len(controls)} controls")

        # Import POA&Ms
        if poams:
            importer.import_poams(ssp_id, poams, dry_run=False)
            click.echo(f"[OK] Imported {len(poams)} POA&Ms")

        # Generate summary
        summary = parser.generate_import_summary()

        click.echo(f"\n{separator}")
        click.echo("IMPORT COMPLETE")
        click.echo(f"{separator}\n")

        _display_import_summary(summary, output_format)
    else:
        click.echo("[ERROR] Failed to create SSP - import aborted", err=True)


@click.command()
@click.option("--xml-file", help="Path to eMASS XML export file", type=click.Path(exists=True), required=True)
@click.option("--dry-run", is_flag=True, help="Validate XML without creating records")
@click.option("--create-custom-fields", is_flag=True, help="Create custom fields for unmapped XML elements")
@click.option("--output-format", type=click.Choice(["summary", "detailed", "json"]), default="summary")
def import_xml(xml_file: str, dry_run: bool, create_custom_fields: bool, output_format: str):
    """
    Import an eMASS XML export file into RegScale.

    This command implements AC7 and AC8:
    - Parses valid eMASS XML exports
    - Maps XML fields to RegScale models
    - Creates SSP, controls, POA&Ms, artifacts, and milestones
    - Generates comprehensive import summary

    Example:
        regscale emass_api import_xml --xml-file system_export.xml --dry-run
    """
    try:
        from regscale.integrations.public.emass_client.xml_import import EmassXmlParser

        separator = "=" * 60
        click.echo(f"\n{separator}")
        click.echo(f"eMASS XML Import - {'DRY RUN MODE' if dry_run else 'LIVE MODE'}")
        click.echo(f"{separator}\n")

        # Initialize parser and parse data
        click.echo(f"Parsing XML file: {xml_file}")
        parser = EmassXmlParser(xml_file)

        system_data = parser.parse_system_metadata()
        controls = parser.parse_controls()
        poams = parser.parse_poams()
        artifacts = parser.parse_artifacts()

        click.echo("[OK] XML parsed successfully")
        click.echo(f"  - System: {system_data.get('systemName', 'Unknown')}")
        click.echo(f"  - Controls: {len(controls)}")
        click.echo(f"  - POA&Ms: {len(poams)}")
        click.echo(f"  - Artifacts: {len(artifacts)}\n")

        if dry_run:
            _display_dry_run_results(parser, create_custom_fields, separator)
        else:
            _perform_live_import(parser, system_data, controls, poams, separator, output_format)

    except FileNotFoundError as e:
        logger.error("XML file not found: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()
    except Exception as e:
        logger.error("Error importing XML: %s", e)
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise click.Abort()
