"""
Guardrails module for safe eMASS operations.

This module implements AC6 requirements:
- Automatic chunking for bulk requests exceeding batch cap
- Retry logic for transient errors with exponential backoff
- Explicit warning for PUT operations that would null unspecified fields
- Audit record of user confirmations
"""

import logging
import time
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, TypeVar

import click

from regscale.integrations.public.emass_client.exceptions import ApiException

logger = logging.getLogger("regscale")

T = TypeVar("T")

# Default batch size limit per AC6
DEFAULT_BATCH_CAP = 100

# Transient HTTP error codes that should trigger retry
TRANSIENT_ERROR_CODES = [408, 429, 500, 502, 503, 504]


class GuardrailManager:
    """
    Implements AC6 guardrails for safe eMASS operations.

    Provides automatic chunking, retry logic, and destructive operation warnings.
    """

    def __init__(self, batch_cap: int = DEFAULT_BATCH_CAP, max_retries: int = 3, backoff_factor: float = 2.0):
        """
        Initialize GuardrailManager.

        Args:
            batch_cap: Maximum batch size for chunking operations
            max_retries: Maximum retry attempts for transient errors
            backoff_factor: Exponential backoff multiplier
        """
        self.batch_cap = batch_cap
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor

    def chunk_requests(self, items: List[T], batch_size: Optional[int] = None) -> List[List[T]]:
        """
        Automatically chunk large requests into batches.

        Args:
            items: List of items to chunk
            batch_size: Optional batch size override (default: self.batch_cap)

        Returns:
            List of batched item lists
        """
        size = batch_size or self.batch_cap
        if len(items) <= size:
            return [items]

        chunks = [items[i : i + size] for i in range(0, len(items), size)]
        logger.info("Chunked %d items into %d batches of size %d", len(items), len(chunks), size)
        return chunks

    def retry_with_backoff(
        self, func: Callable[[], T], operation_name: str = "operation", max_retries: Optional[int] = None
    ) -> T:
        """
        Retry operation on transient errors with exponential backoff.

        Args:
            func: Function to execute with retry logic
            operation_name: Name of operation for logging
            max_retries: Optional retry limit override

        Returns:
            Result from successful function execution

        Raises:
            Exception: If all retry attempts fail
        """
        retries = max_retries or self.max_retries

        for attempt in range(retries):
            try:
                return func()
            except ApiException as e:
                # Check if error is transient
                if hasattr(e, "status") and e.status in TRANSIENT_ERROR_CODES:
                    if attempt == retries - 1:
                        logger.error("Final retry attempt failed for %s: %s", operation_name, e)
                        raise

                    wait_time = self.backoff_factor**attempt
                    logger.warning(
                        "Transient error (HTTP %s) for %s, retrying in %ss (attempt %d/%d): %s",
                        e.status if hasattr(e, "status") else "unknown",
                        operation_name,
                        wait_time,
                        attempt + 1,
                        retries,
                        e,
                    )
                    time.sleep(wait_time)
                else:
                    # Non-transient error, fail immediately
                    logger.error("Non-transient error for %s: %s", operation_name, e)
                    raise
            except Exception as e:
                # Other exceptions fail immediately
                logger.error("Unexpected error for %s: %s", operation_name, e)
                raise

        # Should never reach here, but for type safety
        raise RuntimeError(f"Retry logic failed for {operation_name}")

    def warn_on_destructive_put(
        self, all_fields: List[str], specified_fields: List[str], require_confirmation: bool = True
    ) -> bool:
        """
        Warn user before PUT operation that would null unspecified fields.

        Args:
            all_fields: List of all fields in the target entity
            specified_fields: List of fields being set in the PUT request
            require_confirmation: If True, require user confirmation to proceed

        Returns:
            True if user confirmed or no warning needed, False if user declined
        """
        unspecified_fields = [field for field in all_fields if field not in specified_fields]

        if not unspecified_fields:
            return True

        warning = f"WARNING: The following {len(unspecified_fields)} fields will be nulled by this PUT operation:"
        click.echo(click.style("\n" + warning, fg="yellow", bold=True))

        # Show first 10 fields, summarize rest
        display_fields = unspecified_fields[:10]
        for field in display_fields:
            click.echo(click.style(f"  - {field}", fg="yellow"))

        if len(unspecified_fields) > 10:
            click.echo(click.style(f"  ... and {len(unspecified_fields) - 10} more fields", fg="yellow"))

        click.echo(click.style("\nThis is a destructive operation and cannot be undone.", fg="red", bold=True))

        # Create audit record per AC6
        audit_log = {
            "timestamp": datetime.now().isoformat(),
            "operation": "destructive_put_warning",
            "unspecified_fields_count": len(unspecified_fields),
            "unspecified_fields": unspecified_fields,
            "user_confirmed": None,
        }

        if require_confirmation:
            confirmed = click.confirm("\nDo you want to proceed?", default=False)
            audit_log["user_confirmed"] = confirmed

            logger.info("Guardrail audit: %s", audit_log)

            if not confirmed:
                click.echo(click.style("Operation cancelled by user.", fg="green"))

            return confirmed

        # No confirmation required, just log warning
        audit_log["user_confirmed"] = "not_required"
        logger.info("Guardrail audit (no confirmation required): %s", audit_log)
        return True

    def batch_process_with_retry(
        self, items: List[T], process_func: Callable[[T], Any], operation_name: str = "batch operation"
    ) -> Dict[str, Any]:
        """
        Process items in batches with chunking and retry logic.

        Args:
            items: List of items to process
            process_func: Function to process each item
            operation_name: Name of operation for logging

        Returns:
            Dictionary with processing statistics
        """
        results = {"total": len(items), "successful": 0, "failed": 0, "errors": []}

        # Chunk items
        batches = self.chunk_requests(items)

        for batch_num, batch in enumerate(batches, 1):
            logger.info("Processing batch %d/%d (%d items)", batch_num, len(batches), len(batch))

            for item in batch:
                try:
                    # Wrap processing in retry logic
                    self.retry_with_backoff(lambda: process_func(item), operation_name=f"{operation_name} (item)")
                    results["successful"] += 1
                except Exception as e:
                    results["failed"] += 1
                    results["errors"].append({"item": str(item)[:100], "error": str(e)})
                    logger.error("Failed to process item: %s", e)

        return results


def create_audit_record(operation: str, details: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create standardized audit record for guardrail operations.

    Args:
        operation: Operation name
        details: Operation-specific details

    Returns:
        Audit record dictionary
    """
    audit = {
        "timestamp": datetime.now().isoformat(),
        "operation": operation,
        "details": details,
    }

    logger.info("Guardrail audit: %s", audit)
    return audit
