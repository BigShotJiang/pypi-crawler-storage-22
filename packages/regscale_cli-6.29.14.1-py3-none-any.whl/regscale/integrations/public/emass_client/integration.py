"""
eMASS API integration wrapper.

This module provides high-level wrapper classes around the auto-generated eMASS API client,
implementing business logic, error handling, and RegScale-specific functionality for
bidirectional POA&M and Control Implementation synchronization.
"""

import logging
from typing import Any, Dict, List, Optional

from regscale.integrations.public.emass_client import business_rules, field_mapping, idempotency, variables
from regscale.integrations.public.emass_client.api.artifacts_api import ArtifactsApi
from regscale.integrations.public.emass_client.api.controls_api import ControlsApi
from regscale.integrations.public.emass_client.api.milestones_api import MilestonesApi
from regscale.integrations.public.emass_client.api.poam_api import POAMApi
from regscale.integrations.public.emass_client.api.systems_api import SystemsApi
from regscale.integrations.public.emass_client.api.test_api import TestApi
from regscale.integrations.public.emass_client.api.test_results_api import TestResultsApi
from regscale.integrations.public.emass_client.api_client import ApiClient
from regscale.integrations.public.emass_client.configuration import Configuration
from regscale.integrations.public.emass_client.exceptions import ApiException

logger = logging.getLogger("regscale")


# ===========================
# Base eMASS Client
# ===========================


class EmassClient:
    """
    Base eMASS API client wrapper.

    Provides authentication, configuration, and low-level API access
    with error handling and retry logic.
    """

    def __init__(self, base_url: Optional[str] = None, api_key: Optional[str] = None, timeout: Optional[int] = None):
        """
        Initialize eMASS client.

        Args:
            base_url: eMASS API base URL (default: from environment)
            api_key: eMASS API key (default: from environment)
            timeout: API timeout in seconds (default: from environment)
        """
        # Use provided values or fall back to environment
        self.base_url = base_url or variables.EMASS_BASE_URL
        self.api_key = api_key or variables.EMASS_API_KEY
        self.timeout = timeout or variables.EMASS_API_TIMEOUT

        # Validate required configuration
        is_valid, missing = variables.validate_required_config()
        if not is_valid and not (base_url and api_key):
            raise ValueError(
                f"Missing required eMASS configuration: {', '.join(missing)}. "
                f"Set environment variables or provide explicitly."
            )

        # Initialize eMASS API client
        self.configuration = Configuration(host=self.base_url)

        # Set API key header (required for all eMASS endpoints)
        # OpenAPI spec uses "apiKey" identifier which maps to "api-key" HTTP header
        self.configuration.api_key["apiKey"] = self.api_key

        # Set user-uid header (required for PUT, POST, DELETE operations)
        # OpenAPI spec uses "userId" identifier which maps to "user-uid" HTTP header
        user_uid = variables.EMASS_USER_UID
        if user_uid:
            self.configuration.api_key["userId"] = user_uid

        # Add Prefer header for mock server support (Stoplight Prism)
        # OpenAPI spec uses "mockType" identifier which maps to "Prefer" HTTP header
        # Mock server requires this header with specific values:
        # - "code=200" for static responses
        # - "dynamic=true" for randomly generated realistic responses
        # For real eMASS API, this header is not used
        if "stoplight.io" in self.base_url:
            # Use "dynamic=true" to get realistic mock data that validates properly
            self.configuration.api_key["mockType"] = "dynamic=true"

        self.api_client = ApiClient(self.configuration)

        # Initialize API instances
        self.poam_api = POAMApi(self.api_client)
        self.test_results_api = TestResultsApi(self.api_client)
        self.controls_api = ControlsApi(self.api_client)
        self.milestones_api = MilestonesApi(self.api_client)
        self.artifacts_api = ArtifactsApi(self.api_client)
        self.systems_api = SystemsApi(self.api_client)
        self.test_api = TestApi(self.api_client)

        logger.info(f"Initialized eMASS client for {self.base_url}")

    def test_connection(self) -> bool:
        """
        Test connection to eMASS API.

        Returns:
            True if connection successful, False otherwise
        """
        try:
            # Use Test API to verify connection
            _ = self.test_api.test_connection()
            logger.info("eMASS connection test successful")
            return True
        except ApiException as e:
            logger.error(f"eMASS connection test failed: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error testing eMASS connection: {e}")
            return False

    def get_system_poams(self, system_id: int) -> List[Dict[str, Any]]:
        """
        Get all POA&Ms for a system.

        Args:
            system_id: eMASS system ID

        Returns:
            List of POA&M dictionaries
        """
        try:
            response = self.poam_api.get_system_poams(system_id)
            # Convert Pydantic model to dict if needed
            if hasattr(response, "to_dict"):
                response = response.to_dict()
            elif hasattr(response, "model_dump"):
                response = response.model_dump()
            return response.get("data", [])
        except ApiException as e:
            logger.error(f"Error fetching POA&Ms for system {system_id}: {e}")
            raise

    def get_system_poam(self, system_id: int, poam_id: str) -> Dict[str, Any]:
        """
        Get specific POA&M by ID.

        Args:
            system_id: eMASS system ID
            poam_id: POA&M ID

        Returns:
            POA&M dictionary
        """
        try:
            response = self.poam_api.get_system_poams_by_poam_id(system_id, poam_id)
            # Convert Pydantic model to dict if needed
            if hasattr(response, "to_dict"):
                response = response.to_dict()
            elif hasattr(response, "model_dump"):
                response = response.model_dump()
            data = response.get("data", [])
            return data[0] if data else {}
        except ApiException as e:
            logger.error(f"Error fetching POA&M {poam_id} for system {system_id}: {e}")
            raise

    def get_system_control_test_results(self, system_id: int, control_acronym: str) -> List[Dict[str, Any]]:
        """
        Get test results for a control.

        Args:
            system_id: eMASS system ID
            control_acronym: Control acronym (e.g., 'AC-1')

        Returns:
            List of Test Result dictionaries
        """
        try:
            response = self.test_results_api.get_system_test_results(system_id, control_acronyms=control_acronym)
            return response.get("data", [])
        except ApiException as e:
            logger.error(f"Error fetching test results for {control_acronym} in system {system_id}: {e}")
            raise


# ===========================
# POA&M Integration
# ===========================


class EmassPoamIntegration:
    """
    High-level POA&M integration with RegScale.

    Implements bidirectional sync, business rule validation, and idempotency
    for the eMASS integration requirements.
    """

    def __init__(self, emass_client: EmassClient):
        """
        Initialize POA&M integration.

        Args:
            emass_client: eMASS client instance
        """
        self.client = emass_client
        self.idempotency_manager = idempotency.IdempotencyManager(emass_client)
        self.mapper = field_mapping.CaseToPoamMapper()
        self.validator = business_rules.EmassBusinessRuleValidator()

    def push_poam(self, case_data: Dict[str, Any], system_id: int, validate: bool = True) -> Dict[str, Any]:
        """
        Push RegScale Case to eMASS as POA&M (create or update).

        Args:
            case_data: RegScale Case dictionary
            system_id: eMASS system ID
            validate: Validate business rules before push (default: True)

        Returns:
            eMASS POA&M response dictionary

        Raises:
            ValueError: If validation fails
            ApiException: If eMASS API call fails
        """
        # Map RegScale Case to eMASS POA&M format
        poam_data = self.mapper.map_to_emass(case_data, system_id)

        # Check if POA&M already exists (idempotency)
        existing_poam = self.idempotency_manager.find_existing_poam(case_data, system_id)

        is_update = existing_poam is not None

        # Validate before push
        if validate and variables.EMASS_VALIDATE_BEFORE_PUSH:
            validation_result = business_rules.validate_before_push(poam_data, is_update)
            if not validation_result.is_valid:
                error_msg = f"POA&M validation failed:\n{validation_result.get_message()}"
                logger.error(error_msg)
                raise ValueError(error_msg)

            if validation_result.warnings:
                logger.warning(f"POA&M validation warnings:\n{validation_result.get_message()}")

        # Create or update POA&M
        try:
            if is_update:
                poam_id = existing_poam["poamId"]
                logger.info(f"Updating existing POA&M {poam_id} in system {system_id}")
                response = self.client.poam_api.update_poam(system_id, poam_id, [poam_data])
            else:
                logger.info(f"Creating new POA&M in system {system_id}")
                # eMASS API expects an array of POA&Ms
                response = self.client.poam_api.add_poam_by_system_id(system_id, [poam_data])

            # Convert Pydantic model to dict if needed
            if hasattr(response, "to_dict"):
                response = response.to_dict()
            elif hasattr(response, "model_dump"):
                response = response.model_dump()

            # Store correlation metadata
            response_data = response.get("data", [{}])[0]
            if response_data:
                correlation = self.idempotency_manager.store_poam_correlation(
                    case_id=case_data.get("id"),
                    poam_id=response_data.get("poamId"),
                    display_poam_id=response_data.get("displayPoamId"),
                    external_uid=poam_data.get("externalUid"),
                    system_id=system_id,
                )
                logger.info(f"Stored correlation: {correlation}")

            return response

        except ApiException as e:
            # Translate eMASS error to user-friendly message
            translated_error = self.validator.translate_emass_error(str(e))
            logger.error(f"eMASS API error: {translated_error}")
            raise ValueError(translated_error) from e

    def pull_poams(self, system_id: int, control_acronyms: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """
        Pull POA&Ms from eMASS to RegScale format.

        Args:
            system_id: eMASS system ID
            control_acronyms: Optional list of control acronyms to filter by

        Returns:
            List of RegScale Case dictionaries
        """
        # Get POA&Ms from eMASS
        try:
            emass_poams = self.client.get_system_poams(system_id)
        except ApiException as e:
            logger.error(f"Error fetching POA&Ms from eMASS: {e}")
            raise

        # Filter by control acronyms if specified
        if control_acronyms:
            emass_poams = [poam for poam in emass_poams if poam.get("controlAcronym") in control_acronyms]

        # Map to RegScale format
        regscale_cases = []
        for poam in emass_poams:
            try:
                case = self.mapper.map_from_emass(poam)
                regscale_cases.append(case)
            except Exception as e:
                logger.warning(f"Error mapping POA&M {poam.get('poamId')}: {e}")
                continue

        logger.info(f"Pulled {len(regscale_cases)} POA&Ms from eMASS system {system_id}")
        return regscale_cases

    def sync_poams_bidirectional(self, system_id: int, regscale_cases: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Bidirectional POA&M sync (push RegScale, pull eMASS).

        Args:
            system_id: eMASS system ID
            regscale_cases: List of RegScale Cases to push

        Returns:
            Sync results dictionary with counts and errors
        """
        results = {"pushed": 0, "updated": 0, "pulled": 0, "errors": []}

        # Push RegScale Cases to eMASS
        for case in regscale_cases:
            try:
                response = self.push_poam(case, system_id)
                if response:
                    results["pushed"] += 1
            except Exception as e:
                logger.error(f"Error pushing Case {case.get('id')}: {e}")
                results["errors"].append({"case_id": case.get("id"), "error": str(e)})

        # Pull POA&Ms from eMASS
        try:
            pulled_cases = self.pull_poams(system_id)
            results["pulled"] = len(pulled_cases)
        except Exception as e:
            logger.error(f"Error pulling POA&Ms: {e}")
            results["errors"].append({"operation": "pull", "error": str(e)})

        logger.info(
            f"Bidirectional sync complete: "
            f"pushed={results['pushed']}, pulled={results['pulled']}, "
            f"errors={len(results['errors'])}"
        )

        return results

    def get_milestones(self, system_id: int, poam_id: int) -> List[Dict[str, Any]]:
        """
        Get all milestones for a POA&M.

        Args:
            system_id: eMASS system ID
            poam_id: eMASS POA&M ID

        Returns:
            List of milestone dictionaries
        """
        try:
            response = self.client.milestones_api.get_system_milestones_by_poam_id(system_id, poam_id)
            # Convert Pydantic model to dict if needed
            if hasattr(response, "to_dict"):
                response = response.to_dict()
            elif hasattr(response, "model_dump"):
                response = response.model_dump()
            milestones = response.get("data", [])
            logger.info(f"Retrieved {len(milestones)} milestones for POA&M {poam_id}")
            return milestones
        except ApiException as e:
            logger.error(f"Error fetching milestones for POA&M {poam_id}: {e}")
            raise

    def add_milestone(
        self, system_id: int, poam_id: int, description: str, scheduled_completion_date: int
    ) -> Dict[str, Any]:
        """
        Add a single milestone to a POA&M.

        Args:
            system_id: eMASS system ID
            poam_id: eMASS POA&M ID
            description: Milestone description
            scheduled_completion_date: Unix timestamp for completion date

        Returns:
            Created milestone response
        """
        milestone_data = [{"description": description, "scheduledCompletionDate": scheduled_completion_date}]

        try:
            logger.info(f"Adding milestone to POA&M {poam_id}: {description}")
            response = self.client.milestones_api.add_milestone_by_system_id_and_poam_id(
                system_id, poam_id, milestone_data
            )
            logger.info(f"Milestone added successfully to POA&M {poam_id}")
            return response
        except ApiException as e:
            logger.error(f"Error adding milestone to POA&M {poam_id}: {e}")
            raise

    def add_milestones_bulk(self, system_id: int, poam_id: int, milestones: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Add multiple milestones to a POA&M with retry logic.

        Args:
            system_id: eMASS system ID
            poam_id: eMASS POA&M ID
            milestones: List of milestone dictionaries with 'description' and 'scheduledCompletionDate'

        Returns:
            Results dictionary with success/failure counts
        """
        from regscale.integrations.public.emass_client.guardrails import GuardrailManager

        guardrails = GuardrailManager()
        results = {"total": len(milestones), "successful": 0, "failed": 0, "errors": []}

        logger.info(f"Adding {len(milestones)} milestones to POA&M {poam_id}")

        for milestone in milestones:
            try:
                description = milestone.get("description")
                scheduled_date = milestone.get("scheduledCompletionDate")

                if not description or not scheduled_date:
                    raise ValueError("Milestone missing required fields: description or scheduledCompletionDate")

                guardrails.retry_with_backoff(
                    lambda: self.add_milestone(system_id, poam_id, description, scheduled_date),
                    operation_name=f"add milestone '{description}'",
                )
                results["successful"] += 1
            except Exception as e:
                results["failed"] += 1
                results["errors"].append({"milestone": str(milestone)[:100], "error": str(e)})
                logger.error(f"Failed to add milestone: {e}")

        logger.info(f"Bulk milestone addition complete: {results['successful']}/{results['total']} successful")
        return results

    def update_milestone(
        self, system_id: int, poam_id: int, milestone_id: int, description: str, scheduled_completion_date: int
    ) -> Dict[str, Any]:
        """
        Update an existing milestone.

        Args:
            system_id: eMASS system ID
            poam_id: eMASS POA&M ID
            milestone_id: Milestone ID to update
            description: Updated milestone description
            scheduled_completion_date: Updated Unix timestamp for completion date

        Returns:
            Updated milestone response
        """
        milestone_data = [
            {
                "milestoneId": milestone_id,
                "description": description,
                "scheduledCompletionDate": scheduled_completion_date,
            }
        ]

        try:
            logger.info(f"Updating milestone {milestone_id} in POA&M {poam_id}")
            response = self.client.milestones_api.update_milestone_by_system_id_and_poam_id(
                system_id, poam_id, milestone_data
            )
            logger.info(f"Milestone {milestone_id} updated successfully")
            return response
        except ApiException as e:
            logger.error(f"Error updating milestone {milestone_id}: {e}")
            raise

    def delete_milestone(self, system_id: int, poam_id: int, milestone_ids: List[int]) -> Dict[str, Any]:
        """
        Delete one or more milestones from a POA&M.

        Args:
            system_id: eMASS system ID
            poam_id: eMASS POA&M ID
            milestone_ids: List of milestone IDs to delete

        Returns:
            Delete response
        """
        milestone_data = [{"milestoneId": mid} for mid in milestone_ids]

        try:
            logger.info(f"Deleting {len(milestone_ids)} milestones from POA&M {poam_id}")
            response = self.client.milestones_api.delete_milestone(system_id, poam_id, milestone_data)
            logger.info(f"Milestones deleted successfully from POA&M {poam_id}")
            return response
        except ApiException as e:
            logger.error(f"Error deleting milestones from POA&M {poam_id}: {e}")
            raise


# ===========================
# Control Implementation Integration
# ===========================


class EmassControlsIntegration:
    """
    High-level Control Implementation integration with eMASS Test Results.

    Implements Control → Test Result mapping for the eMASS integration AC3.
    """

    def __init__(self, emass_client: EmassClient):
        """
        Initialize Controls integration.

        Args:
            emass_client: eMASS client instance
        """
        self.client = emass_client
        self.idempotency_manager = idempotency.IdempotencyManager(emass_client)
        self.mapper = field_mapping.ControlToTestResultMapper()

    def push_control_to_test_result(self, control_data: Dict[str, Any], system_id: int) -> Dict[str, Any]:
        """
        Push RegScale Control Implementation to eMASS as Test Result.

        Args:
            control_data: RegScale Control Implementation dictionary
            system_id: eMASS system ID

        Returns:
            eMASS Test Result response dictionary
        """
        # Map to eMASS Test Result format
        test_result_data = self.mapper.map_to_emass(control_data, system_id)

        control_acronym = test_result_data.get("controlAcronym")
        if not control_acronym:
            raise ValueError("Control acronym is required for Test Result")

        # Check for existing Test Result (idempotency)
        existing_result = self.idempotency_manager.find_existing_test_result(control_data, system_id, control_acronym)

        is_update = existing_result is not None

        # Create or update Test Result
        try:
            if is_update:
                logger.info(f"Updating Test Result for {control_acronym} in system {system_id}")
                response = self.client.test_results_api.add_test_results_by_system_id(system_id, test_result_data)
            else:
                logger.info(f"Creating Test Result for {control_acronym} in system {system_id}")
                response = self.client.test_results_api.add_test_results_by_system_id(system_id, test_result_data)

            # Store correlation
            response_data = response.get("data", [{}])[0]
            if response_data:
                correlation = self.idempotency_manager.store_control_correlation(
                    control_id=control_data.get("id"),
                    test_result_id=response_data.get("testResultId", ""),
                    external_uid=test_result_data.get("externalUid"),
                    system_id=system_id,
                    control_acronym=control_acronym,
                )
                logger.info(f"Stored control correlation: {correlation}")

            return response

        except ApiException as e:
            logger.error(f"Error pushing Control to Test Result: {e}")
            raise

    def sync_controls(self, system_id: int, controls: List[Dict[str, Any]]) -> Dict[str, int]:
        """
        Sync multiple Control Implementations to eMASS Test Results.

        Args:
            system_id: eMASS system ID
            controls: List of RegScale Control Implementation dictionaries

        Returns:
            Dictionary with sync statistics
        """
        stats = {"synced": 0, "errors": 0}

        for control in controls:
            try:
                self.push_control_to_test_result(control, system_id)
                stats["synced"] += 1
            except Exception as e:
                logger.error(f"Error syncing control {control.get('controlId')}: {e}")
                stats["errors"] += 1

        logger.info(f"Control sync complete: {stats}")
        return stats


# ===========================
# Systems Integration
# ===========================


class EmassSystemsIntegration:
    """eMASS Systems API integration."""

    def __init__(self, emass_client: EmassClient):
        """
        Initialize Systems integration.

        Args:
            emass_client: eMASS client instance
        """
        self.client = emass_client

    def get_systems(self) -> List[Dict[str, Any]]:
        """
        Get all eMASS systems accessible to the user.

        Returns:
            List of system dictionaries
        """
        try:
            response = self.client.systems_api.get_systems()
            # Convert Pydantic model to dict if needed
            if hasattr(response, "to_dict"):
                response = response.to_dict()
            elif hasattr(response, "model_dump"):
                response = response.model_dump()

            # Extract data array from response
            if isinstance(response, dict):
                data = response.get("data", [])
            elif hasattr(response, "data"):
                data = response.data
            else:
                data = []

            # Convert each system to dict if needed
            systems = []
            for system in data:
                if system is None:
                    continue
                if isinstance(system, dict):
                    systems.append(system)
                elif hasattr(system, "to_dict"):
                    systems.append(system.to_dict())
                elif hasattr(system, "model_dump"):
                    systems.append(system.model_dump())
            return systems
        except ApiException as e:
            logger.error(f"Error fetching eMASS systems: {e}")
            raise

    def get_system(self, system_id: int, policy: str = "rmf") -> Dict[str, Any]:
        """
        Get specific eMASS system details.

        Args:
            system_id: eMASS system ID
            policy: System policy filter (default: "rmf")

        Returns:
            System dictionary
        """
        try:
            # Use get_system() method with system_id and policy parameters
            response = self.client.systems_api.get_system(system_id=system_id, policy=policy)

            # Convert Pydantic model to dict if needed
            if hasattr(response, "to_dict"):
                response = response.to_dict()
            elif hasattr(response, "model_dump"):
                response = response.model_dump()

            # Extract data from response
            if isinstance(response, dict):
                data = response.get("data")
            elif hasattr(response, "data"):
                data = response.data
            else:
                return {}

            # Convert system data to dict if needed
            if data is None:
                return {}
            elif isinstance(data, dict):
                return data
            elif hasattr(data, "to_dict"):
                return data.to_dict()
            elif hasattr(data, "model_dump"):
                return data.model_dump()
            return {}
        except ApiException as e:
            logger.error(f"Error fetching eMASS system {system_id}: {e}")
            raise


# ===========================
# Artifacts Integration
# ===========================


class EmassArtifactsIntegration:
    """
    Artifacts and evidence management integration.

    Implements artifact upload, download, and listing per AC4.
    """

    def __init__(self, emass_client: EmassClient):
        """
        Initialize Artifacts integration.

        Args:
            emass_client: eMASS client instance
        """
        self.client = emass_client

    def get_artifacts(self, system_id: int) -> List[Dict[str, Any]]:
        """
        Get all artifacts for a system.

        Args:
            system_id: eMASS system ID

        Returns:
            List of artifact dictionaries
        """
        try:
            response = self.client.artifacts_api.get_system_artifacts(system_id)
            # Convert Pydantic model to dict if needed
            if hasattr(response, "to_dict"):
                response = response.to_dict()
            elif hasattr(response, "model_dump"):
                response = response.model_dump()
            return response.get("data", [])
        except ApiException as e:
            logger.error(f"Error fetching artifacts for system {system_id}: {e}")
            raise

    def upload_artifact(
        self, system_id: int, file_path: str, artifact_type: str, control_acronym: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Upload single artifact to eMASS system.

        Args:
            system_id: eMASS system ID
            file_path: Path to file to upload
            artifact_type: Type of artifact (e.g., 'Test Results', 'Evidence')
            control_acronym: Optional control acronym to associate with

        Returns:
            Upload response dictionary
        """
        import os

        try:
            if not os.path.exists(file_path):
                raise ValueError(f"File not found: {file_path}")

            file_name = os.path.basename(file_path)
            file_size = os.path.getsize(file_path)

            logger.info(f"Uploading artifact: {file_name} ({file_size} bytes) to system {system_id}")

            # Upload file using the correct API signature
            # The API expects: system_id, filename (file tuple), is_bulk, is_template, type, category
            with open(file_path, "rb") as f:
                response = self.client.artifacts_api.add_artifacts_by_system_id(
                    system_id=system_id, filename=(file_name, f), is_template=False, type=artifact_type
                )

            # Convert Pydantic model to dict if needed
            if hasattr(response, "to_dict"):
                response = response.to_dict()
            elif hasattr(response, "model_dump"):
                response = response.model_dump()

            logger.info(f"Artifact uploaded successfully: {file_name}")
            return response

        except ApiException as e:
            logger.error(f"Error uploading artifact {file_path}: {e}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error uploading artifact {file_path}: {e}")
            raise

    def upload_artifacts_bulk(self, system_id: int, file_paths: List[str], artifact_type: str) -> Dict[str, Any]:
        """
        Upload multiple artifacts to eMASS system.

        Args:
            system_id: eMASS system ID
            file_paths: List of file paths to upload
            artifact_type: Type of artifacts

        Returns:
            Dictionary with upload statistics
        """
        from regscale.integrations.public.emass_client.guardrails import GuardrailManager

        guardrails = GuardrailManager()

        results = {"total": len(file_paths), "successful": 0, "failed": 0, "errors": []}

        logger.info(f"Starting bulk upload of {len(file_paths)} artifacts to system {system_id}")

        for file_path in file_paths:
            try:
                # Use retry logic for each upload
                guardrails.retry_with_backoff(
                    lambda: self.upload_artifact(system_id, file_path, artifact_type),
                    operation_name=f"upload {file_path}",
                )
                results["successful"] += 1
            except Exception as e:
                results["failed"] += 1
                results["errors"].append({"file": file_path, "error": str(e)})
                logger.error(f"Failed to upload {file_path}: {e}")

        logger.info(
            f"Bulk upload complete: {results['successful']}/{results['total']} successful, {results['failed']} failed"
        )

        return results
