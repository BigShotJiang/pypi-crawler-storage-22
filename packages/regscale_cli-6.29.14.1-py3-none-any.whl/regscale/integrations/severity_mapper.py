"""
Centralized severity mapping for all integrations.

This module provides a unified approach to mapping external severity values from various
security scanning tools to RegScale's IssueSeverity enum. It supports multiple input formats
including text-based (uppercase, lowercase, mixed case), numeric (strings and integers),
and specialized formats (Roman numerals).

Usage:
    from regscale.integrations.severity_mapper import SeverityMapper

    # Map a text-based severity
    severity = SeverityMapper.map_severity("critical")  # Returns IssueSeverity.Critical

    # Map a numeric severity
    severity = SeverityMapper.map_severity("5", mapping_type="cvss_numeric")

    # Get a pre-configured mapping dictionary
    mapper = SeverityMapper.get_mapping("aws")

Design Principles:
    1. **Defensive**: Handles invalid inputs gracefully with proper logging
    2. **Flexible**: Supports multiple input formats and mapping types
    3. **Consistent**: Provides standardized mappings across all integrations
    4. **Extensible**: Easy to add new mapping types for new integrations
    5. **Type-safe**: Proper type hints and validation

Author: RegScale Development Team
Date: 2025-11-15
Version: 1.0.0
"""

import logging
from enum import Enum
from typing import Any, Dict, Union

from regscale.models import IssueSeverity

logger = logging.getLogger("regscale")


class MappingType(str, Enum):
    """
    Enumeration of supported severity mapping types.

    This enum defines the various mapping strategies supported by the SeverityMapper.
    Each type corresponds to a specific format used by different security scanning tools.

    Attributes:
        STANDARD_TEXT: Standard text-based severity (Critical, High, Medium, Low)
        UPPERCASE_TEXT: Uppercase text severity (CRITICAL, HIGH, MEDIUM, LOW)
        LOWERCASE_TEXT: Lowercase text severity (critical, high, medium, low)
        CVSS_NUMERIC: CVSS-style numeric severity (0-5 as strings)
        NUMERIC_INT: Integer-based severity (0-5 as integers)
        TENABLE_NUMERIC: Tenable-specific numeric mapping (1-4)
        NESSUS_MIXED: Nessus mixed numeric and text mapping
        ROMAN_NUMERAL: Roman numeral severity (I-IV, used by Axonius)
        AWS: AWS-specific severity mapping
        AZURE: Azure-specific severity mapping
        GCP: GCP-specific integer-based mapping
        QUALYS: Qualys-specific severity mapping
    """

    STANDARD_TEXT = "standard_text"
    UPPERCASE_TEXT = "uppercase_text"
    LOWERCASE_TEXT = "lowercase_text"
    CVSS_NUMERIC = "cvss_numeric"
    NUMERIC_INT = "numeric_int"
    TENABLE_NUMERIC = "tenable_numeric"
    NESSUS_MIXED = "nessus_mixed"
    ROMAN_NUMERAL = "roman_numeral"
    AWS = "aws"
    AZURE = "azure"
    GCP = "gcp"
    QUALYS = "qualys"


class SeverityMapper:
    """
    Centralized severity mapping utility for all RegScale integrations.

    This class provides static methods for mapping external severity values to RegScale's
    IssueSeverity enum. It supports multiple input formats and provides pre-configured
    mappings for common security scanning tools.

    Key Features:
        - Handles text-based severities (uppercase, lowercase, mixed case)
        - Supports numeric severities (strings and integers)
        - Provides integration-specific mappings (AWS, Azure, GCP, etc.)
        - Defensive programming with comprehensive error handling
        - Extensive logging for troubleshooting
        - Case-insensitive matching for text values
        - Type conversion for numeric values

    Thread Safety:
        All methods are static and thread-safe. No instance state is maintained.

    Examples:
        >>> # Simple text mapping
        >>> SeverityMapper.map_severity("high")
        <IssueSeverity.High: 4>

        >>> # Numeric mapping
        >>> SeverityMapper.map_severity("5", mapping_type="cvss_numeric")
        <IssueSeverity.Critical: 5>

        >>> # Get pre-configured mapping for integration
        >>> aws_map = SeverityMapper.get_mapping("aws")
        >>> severity = aws_map.get("CRITICAL")
        <IssueSeverity.High: 4>
    """

    # =========================================================================
    # STANDARD MAPPINGS
    # =========================================================================

    STANDARD_TEXT_MAP: Dict[str, IssueSeverity] = {
        "critical": IssueSeverity.Critical,
        "high": IssueSeverity.High,
        "medium": IssueSeverity.Moderate,
        "moderate": IssueSeverity.Moderate,
        "low": IssueSeverity.Low,
        "info": IssueSeverity.NotAssigned,
        "informational": IssueSeverity.NotAssigned,
        "none": IssueSeverity.NotAssigned,
        "unknown": IssueSeverity.High,  # Conservative: treat unknown as high
        "negligible": IssueSeverity.Low,
    }

    CVSS_NUMERIC_MAP: Dict[str, IssueSeverity] = {
        "5": IssueSeverity.Critical,  # Critical
        "4": IssueSeverity.High,  # High
        "3": IssueSeverity.Moderate,  # Medium
        "2": IssueSeverity.Low,  # Low
        "1": IssueSeverity.Low,  # Info/Low
        "0": IssueSeverity.NotAssigned,  # None/Info
    }

    NUMERIC_INT_MAP: Dict[int, IssueSeverity] = {
        5: IssueSeverity.Critical,
        4: IssueSeverity.High,
        3: IssueSeverity.Moderate,
        2: IssueSeverity.Low,
        1: IssueSeverity.Low,
        0: IssueSeverity.NotAssigned,
    }

    ROMAN_NUMERAL_MAP: Dict[str, IssueSeverity] = {
        "i": IssueSeverity.Critical,  # Highest priority
        "ii": IssueSeverity.High,
        "iii": IssueSeverity.Moderate,
        "iv": IssueSeverity.Low,
    }

    # =========================================================================
    # INTEGRATION-SPECIFIC MAPPINGS
    # =========================================================================

    AWS_MAP: Dict[str, IssueSeverity] = {
        "CRITICAL": IssueSeverity.High,
        "HIGH": IssueSeverity.High,
        "MEDIUM": IssueSeverity.Moderate,
        "LOW": IssueSeverity.Low,
        "INFORMATIONAL": IssueSeverity.NotAssigned,
    }

    AZURE_MAP: Dict[str, IssueSeverity] = {
        "critical": IssueSeverity.Critical,
        "high": IssueSeverity.High,
        "medium": IssueSeverity.Moderate,
        "low": IssueSeverity.Low,
    }

    GCP_MAP: Dict[int, IssueSeverity] = {
        0: IssueSeverity.Low,
        1: IssueSeverity.Critical,
        2: IssueSeverity.High,
        3: IssueSeverity.Moderate,
        4: IssueSeverity.Low,
    }

    QUALYS_MAP: Dict[str, IssueSeverity] = {
        "0": IssueSeverity.NotAssigned,
        "1": IssueSeverity.Low,
        "2": IssueSeverity.Moderate,
        "3": IssueSeverity.Moderate,
        "4": IssueSeverity.High,
        "5": IssueSeverity.Critical,
    }

    TENABLE_SC_MAP: Dict[str, IssueSeverity] = {
        "5": IssueSeverity.Critical,  # Critical
        "4": IssueSeverity.High,  # High
        "3": IssueSeverity.Moderate,  # Medium
        "2": IssueSeverity.Low,  # Low
        "1": IssueSeverity.Low,  # Info
        "0": IssueSeverity.Low,  # None
        "Info": IssueSeverity.NotAssigned,
        "Low": IssueSeverity.Low,
        "Medium": IssueSeverity.Moderate,
        "High": IssueSeverity.High,
        "Critical": IssueSeverity.Critical,
    }

    NESSUS_MAP: Dict[str, IssueSeverity] = {
        "4": IssueSeverity.Critical,
        "3": IssueSeverity.High,
        "2": IssueSeverity.Moderate,
        "1": IssueSeverity.Low,
        "critical": IssueSeverity.Critical,
        "high": IssueSeverity.High,
        "medium": IssueSeverity.Moderate,
        "low": IssueSeverity.Low,
    }

    GRYPE_MAP: Dict[str, IssueSeverity] = {
        "CRITICAL": IssueSeverity.Critical,
        "HIGH": IssueSeverity.High,
        "MEDIUM": IssueSeverity.Moderate,
        "LOW": IssueSeverity.Low,
        "UNKNOWN": IssueSeverity.High,
        "NEGLIGIBLE": IssueSeverity.Low,
    }

    TRIVY_MAP: Dict[str, IssueSeverity] = {
        "CRITICAL": IssueSeverity.Critical,
        "HIGH": IssueSeverity.High,
        "MEDIUM": IssueSeverity.Moderate,
        "LOW": IssueSeverity.Low,
        "UNKNOWN": IssueSeverity.High,
        "NEGLIGIBLE": IssueSeverity.Low,
    }

    AXONIUS_MAP: Dict[str, IssueSeverity] = {
        "I": IssueSeverity.Critical,
        "II": IssueSeverity.High,
        "III": IssueSeverity.Moderate,
        "IV": IssueSeverity.Low,
    }

    WIZ_MAP: Dict[str, IssueSeverity] = {
        "Critical": IssueSeverity.Critical,
        "High": IssueSeverity.High,
        "Medium": IssueSeverity.Moderate,
        "Low": IssueSeverity.Low,
        "INFORMATIONAL": IssueSeverity.NotAssigned,
        "INFO": IssueSeverity.NotAssigned,
        "None": IssueSeverity.NotAssigned,
    }

    SICURA_MAP: Dict[str, IssueSeverity] = {
        "high": IssueSeverity.High,
        "medium": IssueSeverity.Moderate,
        "low": IssueSeverity.Low,
    }

    OPENTEXT_MAP: Dict[int, IssueSeverity] = {
        4: IssueSeverity.Critical,
        3: IssueSeverity.High,
        2: IssueSeverity.Moderate,
        1: IssueSeverity.Low,
        0: IssueSeverity.NotAssigned,
    }

    DEFENDER_MAP: Dict[str, IssueSeverity] = {
        "Critical": IssueSeverity.Critical,
        "High": IssueSeverity.High,
        "Medium": IssueSeverity.Moderate,
        "Low": IssueSeverity.Low,
    }

    STIG_MAP: Dict[str, IssueSeverity] = {
        "critical": IssueSeverity.Critical,
        "high": IssueSeverity.High,
        "medium": IssueSeverity.Moderate,
        "low": IssueSeverity.Low,
    }

    QRADAR_MAP: Dict[str, IssueSeverity] = {
        "10": IssueSeverity.Critical,  # QRadar severity 10 (Critical)
        "9": IssueSeverity.Critical,  # QRadar severity 9 (Critical)
        "8": IssueSeverity.High,  # QRadar severity 8 (High)
        "7": IssueSeverity.High,  # QRadar severity 7 (High)
        "6": IssueSeverity.Moderate,  # QRadar severity 6 (Medium)
        "5": IssueSeverity.Moderate,  # QRadar severity 5 (Medium)
        "4": IssueSeverity.Low,  # QRadar severity 4 (Low)
        "3": IssueSeverity.Low,  # QRadar severity 3 (Low)
        "2": IssueSeverity.Low,  # QRadar severity 2 (Info)
        "1": IssueSeverity.Low,  # QRadar severity 1 (Info)
        "0": IssueSeverity.NotAssigned,  # QRadar severity 0 (Unknown)
    }

    SYNQLY_MAP: Dict[str, IssueSeverity] = {
        "Critical": IssueSeverity.Critical,
        "High": IssueSeverity.High,
        "Medium": IssueSeverity.Moderate,
        "Low": IssueSeverity.Low,
    }

    # =========================================================================
    # MAPPING REGISTRY
    # =========================================================================

    _MAPPING_REGISTRY: Dict[str, Dict[Any, IssueSeverity]] = {
        MappingType.STANDARD_TEXT: STANDARD_TEXT_MAP,
        MappingType.UPPERCASE_TEXT: STANDARD_TEXT_MAP,  # Case-insensitive
        MappingType.LOWERCASE_TEXT: STANDARD_TEXT_MAP,  # Case-insensitive
        MappingType.CVSS_NUMERIC: CVSS_NUMERIC_MAP,
        MappingType.NUMERIC_INT: NUMERIC_INT_MAP,
        MappingType.ROMAN_NUMERAL: ROMAN_NUMERAL_MAP,
        MappingType.AWS: AWS_MAP,
        MappingType.AZURE: AZURE_MAP,
        MappingType.GCP: GCP_MAP,
        MappingType.QUALYS: QUALYS_MAP,
        MappingType.TENABLE_NUMERIC: TENABLE_SC_MAP,
        MappingType.NESSUS_MIXED: NESSUS_MAP,
        # Additional mappings by name for direct lookup
        "AWS": AWS_MAP,
        "AZURE": AZURE_MAP,
        "GCP": GCP_MAP,
        "QUALYS": QUALYS_MAP,
        "TENABLE_SC": TENABLE_SC_MAP,
        "NESSUS": NESSUS_MAP,
        "GRYPE": GRYPE_MAP,
        "TRIVY": TRIVY_MAP,
        "AXONIUS": AXONIUS_MAP,
        "WIZ": WIZ_MAP,
        "SICURA": SICURA_MAP,
        "OPENTEXT": OPENTEXT_MAP,
        "DEFENDER": DEFENDER_MAP,
        "STIG": STIG_MAP,
        "QRADAR": QRADAR_MAP,
        "SYNQLY": SYNQLY_MAP,
    }

    # Integration name to mapping type lookup
    _INTEGRATION_MAPPING_LOOKUP: Dict[str, str] = {
        "aws": "AWS",
        "azure": "AZURE",
        "gcp": "GCP",
        "qualys": "QUALYS",
        "tenable": "TENABLE_SC",
        "tenable_sc": "TENABLE_SC",
        "tenable_cis": "TENABLE_SC",  # CIS uses same mapping as regular Tenable
        "nessus": "NESSUS",
        "grype": "GRYPE",
        "trivy": "TRIVY",
        "axonius": "AXONIUS",
        "wiz": "WIZ",
        "sicura": "SICURA",
        "opentext": "OPENTEXT",
        "defender": "DEFENDER",
        "stig": "STIG",
        "qradar": "QRADAR",
        "synqly": "SYNQLY",
    }

    @staticmethod
    def _is_null_like_value(value: Any) -> bool:
        """Check if value is None or a null-like string."""
        if value is None:
            return True
        if isinstance(value, str):
            normalized = value.strip().lower()
            return normalized in ("", "none", "null", "n/a", "na", "undefined")
        return False

    @staticmethod
    def _resolve_mapping_type(mapping_type: Union[str, MappingType]) -> MappingType:
        """Convert string mapping_type to MappingType enum."""
        if isinstance(mapping_type, MappingType):
            return mapping_type
        try:
            return MappingType(mapping_type)
        except ValueError:
            logger.warning(
                "Invalid mapping_type '%s', using STANDARD_TEXT. Valid types: %s",
                mapping_type,
                [t.value for t in MappingType],
            )
            return MappingType.STANDARD_TEXT

    @staticmethod
    def _find_string_match(
        value: str, mapping_dict: Dict[Any, IssueSeverity], mapping_type: MappingType
    ) -> tuple[bool, IssueSeverity]:
        """Find a match for string value in mapping dict. Returns (found, result)."""
        # Try exact match first
        if value in mapping_dict:
            return True, mapping_dict[value]

        # Try case-insensitive matches
        value_lower = value.lower().strip()
        value_upper = value.upper().strip()
        for key, severity in mapping_dict.items():
            if not isinstance(key, str):
                continue
            if key.lower() == value_lower or key.upper() == value_upper:
                return True, severity

        return False, IssueSeverity.NotAssigned

    @staticmethod
    def _find_int_match(
        value: int, mapping_dict: Dict[Any, IssueSeverity], mapping_type: MappingType
    ) -> tuple[bool, IssueSeverity]:
        """Find a match for integer value in mapping dict. Returns (found, result)."""
        if value in mapping_dict:
            return True, mapping_dict[value]
        # Try string conversion as fallback
        str_value = str(value)
        if str_value in mapping_dict:
            return True, mapping_dict[str_value]
        return False, IssueSeverity.NotAssigned

    @staticmethod
    def map_severity(
        value: Any,
        mapping_type: Union[str, MappingType] = MappingType.STANDARD_TEXT,
        default: IssueSeverity = IssueSeverity.NotAssigned,
        log_unmapped: bool = True,
    ) -> IssueSeverity:
        """
        Map an external severity value to RegScale IssueSeverity enum.

        This method provides intelligent mapping with automatic type detection and
        fallback handling. It performs case-insensitive matching for text values
        and type conversion for numeric values.

        Args:
            value: The severity value to map. Can be str, int, or any type.
            mapping_type: The type of mapping to use. Can be a MappingType enum or string.
                         Defaults to STANDARD_TEXT.
            default: The default IssueSeverity to return if mapping fails.
                    Defaults to IssueSeverity.NotAssigned.
            log_unmapped: Whether to log warnings for unmapped values. Defaults to True.

        Returns:
            IssueSeverity: The mapped severity value, or the default if mapping fails.

        Raises:
            No exceptions are raised. Invalid inputs are handled gracefully with logging.

        Examples:
            >>> # Text-based mapping (case-insensitive)
            >>> SeverityMapper.map_severity("Critical")
            <IssueSeverity.Critical: 5>

            >>> # Numeric string mapping
            >>> SeverityMapper.map_severity("5", mapping_type="cvss_numeric")
            <IssueSeverity.Critical: 5>

            >>> # Integer mapping
            >>> SeverityMapper.map_severity(4, mapping_type="numeric_int")
            <IssueSeverity.High: 4>

            >>> # Unmapped value with custom default
            >>> SeverityMapper.map_severity("invalid", default=IssueSeverity.High)
            <IssueSeverity.High: 4>

        Logging:
            - DEBUG: Logs successful mappings with details
            - WARNING: Logs unmapped values (if log_unmapped=True)
            - ERROR: Logs unexpected errors during mapping
        """
        # Handle None and null-like values
        if SeverityMapper._is_null_like_value(value):
            logger.debug("Received null-like value for severity mapping, returning default: %s", default.name)
            return default

        resolved_mapping_type = SeverityMapper._resolve_mapping_type(mapping_type)

        try:
            mapping_dict = SeverityMapper._MAPPING_REGISTRY.get(resolved_mapping_type, SeverityMapper.STANDARD_TEXT_MAP)

            found, result = False, default
            if isinstance(value, str):
                found, result = SeverityMapper._find_string_match(value, mapping_dict, resolved_mapping_type)
            elif isinstance(value, int):
                found, result = SeverityMapper._find_int_match(value, mapping_dict, resolved_mapping_type)
            else:
                # Handle other types by attempting string conversion
                str_value = str(value)
                if str_value in mapping_dict:
                    found, result = True, mapping_dict[str_value]

            if found:
                logger.debug("Mapped severity '%s' to %s using %s mapping", value, result.name, resolved_mapping_type)
                return result

            # No mapping found
            if log_unmapped:
                logger.warning(
                    "Unable to map severity value '%s' (type: %s) using %s mapping. "
                    "Returning default: %s. Available keys: %s",
                    value,
                    type(value).__name__,
                    resolved_mapping_type,
                    default.name,
                    list(mapping_dict.keys())[:10],
                )
            return default

        except Exception as e:
            logger.error(
                "Unexpected error mapping severity value '%s' using %s mapping: %s. Returning default: %s",
                value,
                resolved_mapping_type,
                str(e),
                default.name,
                exc_info=True,
            )
            return default

    @staticmethod
    def get_mapping(
        integration_name: str,
        return_value_enum: bool = False,
    ) -> Dict[Any, Union[IssueSeverity, int]]:
        """
        Get a pre-configured severity mapping dictionary for a specific integration.

        This method returns a complete mapping dictionary suitable for use as a
        class attribute in integration classes. It supports both IssueSeverity enum
        values and integer values (for backward compatibility).

        Args:
            integration_name: Name of the integration (e.g., "aws", "azure", "qualys").
                             Case-insensitive.
            return_value_enum: If True, return IssueSeverity enum values.
                              If False, return integer severity values (.value).
                              Defaults to False for backward compatibility.

        Returns:
            Dict: A mapping dictionary appropriate for the specified integration.
                 Keys are the external severity values, values are IssueSeverity
                 enums (or their integer values if return_value_enum=False).

        Raises:
            ValueError: If integration_name is not recognized.

        Examples:
            >>> # Get AWS mapping with enum values
            >>> aws_map = SeverityMapper.get_mapping("aws", return_value_enum=True)
            >>> aws_map["CRITICAL"]
            <IssueSeverity.High: 4>

            >>> # Get Qualys mapping with integer values (backward compatible)
            >>> qualys_map = SeverityMapper.get_mapping("qualys")
            >>> qualys_map["5"]
            5  # Integer value of IssueSeverity.Critical

            >>> # Invalid integration name
            >>> SeverityMapper.get_mapping("unknown")
            ValueError: Unknown integration 'unknown'. Supported: aws, azure, gcp, ...

        Logging:
            - INFO: Logs the integration name and mapping type being returned
            - ERROR: Logs errors for unknown integration names
        """
        # Normalize integration name
        integration_key = integration_name.lower().strip()

        # Lookup mapping type
        if integration_key not in SeverityMapper._INTEGRATION_MAPPING_LOOKUP:
            supported = ", ".join(sorted(SeverityMapper._INTEGRATION_MAPPING_LOOKUP.keys()))
            error_msg = (
                f"Unknown integration '{integration_name}'. "
                f"Supported integrations: {supported}. "
                f"Use MappingType enum or STANDARD_TEXT_MAP for custom mappings."
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

        mapping_type = SeverityMapper._INTEGRATION_MAPPING_LOOKUP[integration_key]
        base_mapping = SeverityMapper._MAPPING_REGISTRY[mapping_type]

        # Return appropriate format
        if return_value_enum:
            logger.debug(
                "Returning severity mapping for integration '%s' using %s (enum values)", integration_name, mapping_type
            )
            return base_mapping.copy()
        else:
            # Convert to integer values for backward compatibility
            logger.debug(
                "Returning severity mapping for integration '%s' using %s (integer values)",
                integration_name,
                mapping_type,
            )
            return {key: severity.value for key, severity in base_mapping.items()}

    @staticmethod
    def get_supported_integrations() -> list[str]:
        """
        Get a list of all supported integration names.

        Returns:
            list: Sorted list of supported integration names.

        Examples:
            >>> SeverityMapper.get_supported_integrations()
            ['aws', 'axonius', 'azure', 'gcp', 'grype', 'nessus', 'qualys', ...]
        """
        return sorted(SeverityMapper._INTEGRATION_MAPPING_LOOKUP.keys())

    @staticmethod
    def get_supported_mapping_types() -> list[str]:
        """
        Get a list of all supported mapping types.

        Returns:
            list: List of all MappingType enum values.

        Examples:
            >>> SeverityMapper.get_supported_mapping_types()
            ['standard_text', 'uppercase_text', 'cvss_numeric', ...]
        """
        return [t.value for t in MappingType]

    @staticmethod
    def validate_mapping(
        mapping_dict: Dict[Any, Any],
        expected_type: type = IssueSeverity,
    ) -> bool:
        """
        Validate that a mapping dictionary contains valid IssueSeverity values.

        This utility method checks whether a mapping dictionary is properly configured
        with valid severity values. Useful for testing and validation.

        Args:
            mapping_dict: The mapping dictionary to validate.
            expected_type: Expected type for values (default: IssueSeverity).

        Returns:
            bool: True if all values are valid, False otherwise.

        Examples:
            >>> valid_map = {"high": IssueSeverity.High, "low": IssueSeverity.Low}
            >>> SeverityMapper.validate_mapping(valid_map)
            True

            >>> invalid_map = {"high": "invalid"}
            >>> SeverityMapper.validate_mapping(invalid_map)
            False

        Logging:
            - DEBUG: Logs validation progress
            - WARNING: Logs invalid values found
        """
        if not isinstance(mapping_dict, dict):
            logger.warning("validate_mapping: Input is not a dictionary (type: %s)", type(mapping_dict).__name__)
            return False

        if not mapping_dict:
            logger.warning("validate_mapping: Mapping dictionary is empty")
            return False

        invalid_values = []
        # Get all valid IssueSeverity enum values (string values)
        valid_severity_values = {sev.value for sev in IssueSeverity}

        for key, value in mapping_dict.items():
            # Check if value is IssueSeverity enum
            if isinstance(value, expected_type):
                continue
            # Check if value is the string value of IssueSeverity (e.g., "I - High - Significant Deficiency")
            if isinstance(value, str) and value in valid_severity_values:
                continue
            # Check if value is an integer (though IssueSeverity values are strings)
            if isinstance(value, int) and any(value == sev.value for sev in IssueSeverity):
                continue
            invalid_values.append((key, value, type(value).__name__))

        if invalid_values:
            logger.warning(
                "validate_mapping: Found %d invalid values: %s",
                len(invalid_values),
                invalid_values[:5],  # Show first 5
            )
            return False

        logger.debug("validate_mapping: All %d values are valid %s", len(mapping_dict), expected_type.__name__)
        return True
