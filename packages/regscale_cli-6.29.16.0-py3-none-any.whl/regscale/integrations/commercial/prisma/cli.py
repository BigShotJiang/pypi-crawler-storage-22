#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prisma Cloud CLI Commands

This module provides Click commands for Prisma Cloud Compute integration:
- authenticate: Authenticate and cache session token
- sync_hosts: Sync host assets and vulnerabilities
- sync_images: Sync container image assets and vulnerabilities
- sync_sbom: Sync SBOM data as software inventory

For legacy CSV import functionality, see regscale.integrations.commercial.prisma.legacy
"""

import json
import logging
from typing import Optional

import click

from regscale.core.app.api import Api
from regscale.integrations.commercial.prisma.auth import (
    authenticate_with_cache,
)
from regscale.integrations.commercial.prisma.sbom_processor import (
    attach_sbom_as_evidence,
    create_software_inventory_from_sbom,
    extract_sbom_archive,
    get_sbom_summary,
)
from regscale.integrations.commercial.prisma.scanner import PrismaCloudScanner
from regscale.integrations.commercial.prisma.variables import PrismaVariables
from regscale.models.app_models.click import regscale_ssp_id

logger = logging.getLogger("regscale")


# =============================================================================
# Authentication Commands
# =============================================================================


@click.command(name="authenticate")
@click.option(
    "--console-url",
    type=str,
    required=False,
    help="Prisma Cloud Console URL (e.g., https://console.example.com:8083). "
    "Defaults to prismaConsoleUrl from init.yaml.",
)
@click.option(
    "--username",
    type=str,
    required=False,
    help="Prisma Cloud username. Defaults to prismaUsername from init.yaml.",
)
@click.option(
    "--password",
    type=str,
    required=False,
    hide_input=True,
    prompt=False,
    help="Prisma Cloud password. Defaults to prismaPassword from init.yaml. If not provided, will prompt.",
)
@click.option(
    "--force-refresh",
    is_flag=True,
    default=False,
    help="Force re-authentication even if cached token exists.",
)
def authenticate(
    console_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
    force_refresh: bool,
):
    """
    Authenticate to Prisma Cloud Compute and cache session token.

    This command authenticates to Prisma Cloud and caches the bearer token
    locally for 24 hours. The token will be used automatically by other commands.

    Examples:
        # Authenticate using init.yaml settings
        regscale prisma authenticate

        # Authenticate with explicit credentials
        regscale prisma authenticate --console-url https://console.example.com:8083 \\
            --username admin --password mypassword

        # Force refresh of cached token
        regscale prisma authenticate --force-refresh
    """
    try:
        # Use variables from init.yaml if not provided
        console_url = console_url or str(PrismaVariables.prismaConsoleUrl)  # type: ignore
        username = username or str(PrismaVariables.prismaUsername)  # type: ignore

        # Prompt for password if not provided
        if not password:
            password = str(PrismaVariables.prismaPassword) or click.prompt(  # type: ignore
                "Prisma Cloud Password", hide_input=True
            )

        logger.info("Authenticating to Prisma Cloud: %s", console_url)

        # Safe type conversions for variables (handle empty strings)
        api_timeout = PrismaVariables.prismaApiTimeout or 30
        verify_ssl = PrismaVariables.prismaVerifySsl if PrismaVariables.prismaVerifySsl is not None else True

        # Authenticate with caching
        token = authenticate_with_cache(
            console_url=console_url,
            username=username,
            password=password,
            verify_ssl=bool(verify_ssl),
            timeout=int(api_timeout) if api_timeout else 30,
            force_refresh=force_refresh,
        )

        logger.info("Authentication successful! Token cached for 24 hours (length: %d characters)", len(token))
        logger.info("Token will be used automatically by sync commands")

    except Exception as e:
        logger.error("Authentication failed: %s", e)
        raise click.Abort()


# =============================================================================
# Asset and Finding Sync Commands
# =============================================================================


@click.command(name="sync_hosts")
@regscale_ssp_id()
@click.option(
    "--filters",
    type=str,
    required=False,
    help='JSON filter string for Prisma API query (e.g., \'{"collections": ["prod"]}\')',
)
@click.option(
    "--enable-software-inventory",
    is_flag=True,
    default=False,
    help="Create software inventory records from SBOM data for each host.",
)
@click.option(
    "--console-url",
    type=str,
    required=False,
    help="Override Prisma Console URL from init.yaml.",
)
@click.option(
    "--username",
    type=str,
    required=False,
    help="Override Prisma username from init.yaml.",
)
@click.option(
    "--password",
    type=str,
    required=False,
    hide_input=True,
    help="Override Prisma password from init.yaml.",
)
@click.option(
    "--use-csv",
    is_flag=True,
    default=False,
    help="Use CSV download endpoint for bulk data retrieval (faster for large datasets).",
)
def sync_hosts(
    regscale_ssp_id: int,
    filters: Optional[str],
    enable_software_inventory: bool,
    console_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
    use_csv: bool,
):
    """
    Sync host assets and vulnerabilities from Prisma Cloud.

    This command:
    1. Authenticates to Prisma Cloud (uses cached token if available)
    2. Fetches host scan results from Prisma API
    3. Creates/updates assets in RegScale
    4. Creates/updates vulnerabilities and findings in RegScale
    5. Optionally creates software inventory from SBOM data

    Examples:
        # Basic sync with defaults from init.yaml
        regscale prisma sync_hosts --regscale_ssp_id 123

        # Sync with filters
        regscale prisma sync_hosts --regscale_ssp_id 123 \\
            --filters '{"collections": ["production"]}'

        # Sync with software inventory
        regscale prisma sync_hosts --regscale_ssp_id 123 --enable-software-inventory
    """
    try:
        logger.info("Prisma Cloud Host Sync")

        # Parse filters if provided
        filter_dict = None
        if filters:
            try:
                filter_dict = json.loads(filters)
                logger.info("Using filters: %s", json.dumps(filter_dict, indent=2))
            except json.JSONDecodeError as e:
                logger.error("Invalid JSON in filters: %s", e)
                raise click.Abort()

        # Sync assets using standard ScannerIntegration pattern
        mode_desc = "CSV mode" if use_csv else "JSON API mode"
        logger.info("Using %s for data retrieval", mode_desc)

        logger.info("Syncing hosts to RegScale SSP %d...", regscale_ssp_id)
        PrismaCloudScanner.sync_assets(
            plan_id=regscale_ssp_id,
            scan_type="hosts",
            use_csv=use_csv,
            console_url=console_url,
            username=username,
            password=password,
            filters=filter_dict,
        )

        logger.info("Syncing host vulnerabilities to RegScale...")
        PrismaCloudScanner.sync_findings(
            plan_id=regscale_ssp_id,
            scan_type="hosts",
            use_csv=use_csv,
            console_url=console_url,
            username=username,
            password=password,
            filters=filter_dict,
        )

        # Software inventory
        if enable_software_inventory:
            logger.info("Software Inventory Creation (SBOM)")
            logger.info("Note: SBOM processing for hosts requires separate sync_sbom command per host.")
            logger.info("Use: regscale prisma sync_sbom --resource-type host --resource-id <hostname>")

        logger.info("Host sync completed successfully!")

    except Exception as e:
        logger.error("Host sync failed: %s", e)
        raise click.Abort()


@click.command(name="sync_images")
@regscale_ssp_id()
@click.option(
    "--filters",
    type=str,
    required=False,
    help='JSON filter string for Prisma API query (e.g., \'{"collections": ["prod"]}\')',
)
@click.option(
    "--enable-software-inventory",
    is_flag=True,
    default=False,
    help="Create software inventory records from SBOM data for each image.",
)
@click.option(
    "--console-url",
    type=str,
    required=False,
    help="Override Prisma Console URL from init.yaml.",
)
@click.option(
    "--username",
    type=str,
    required=False,
    help="Override Prisma username from init.yaml.",
)
@click.option(
    "--password",
    type=str,
    required=False,
    hide_input=True,
    help="Override Prisma password from init.yaml.",
)
@click.option(
    "--use-csv",
    is_flag=True,
    default=False,
    help="Use CSV download endpoint for bulk data retrieval (faster for large datasets).",
)
def sync_images(
    regscale_ssp_id: int,
    filters: Optional[str],
    enable_software_inventory: bool,
    console_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
    use_csv: bool,
):
    """
    Sync container image assets and vulnerabilities from Prisma Cloud.

    This command:
    1. Authenticates to Prisma Cloud (uses cached token if available)
    2. Fetches container image scan results from Prisma API
    3. Creates/updates container image assets in RegScale
    4. Creates/updates vulnerabilities and findings in RegScale
    5. Optionally creates software inventory from SBOM data

    Examples:
        # Basic sync with defaults from init.yaml
        regscale prisma sync_images --regscale_ssp_id 123

        # Sync with filters
        regscale prisma sync_images --regscale_ssp_id 123 \\
            --filters '{"collections": ["production"]}'

        # Sync with software inventory
        regscale prisma sync_images --regscale_ssp_id 123 --enable-software-inventory
    """
    try:
        logger.info("Prisma Cloud Container Image Sync")

        # Parse filters if provided
        filter_dict = None
        if filters:
            try:
                filter_dict = json.loads(filters)
                logger.info("Using filters: %s", json.dumps(filter_dict, indent=2))
            except json.JSONDecodeError as e:
                logger.error("Invalid JSON in filters: %s", e)
                raise click.Abort()

        # Sync assets using standard ScannerIntegration pattern
        mode_desc = "CSV mode" if use_csv else "JSON API mode"
        logger.info("Using %s for data retrieval", mode_desc)

        logger.info("Syncing images to RegScale SSP %d...", regscale_ssp_id)
        PrismaCloudScanner.sync_assets(
            plan_id=regscale_ssp_id,
            scan_type="images",
            use_csv=use_csv,
            console_url=console_url,
            username=username,
            password=password,
            filters=filter_dict,
        )

        logger.info("Syncing image vulnerabilities to RegScale...")
        PrismaCloudScanner.sync_findings(
            plan_id=regscale_ssp_id,
            scan_type="images",
            use_csv=use_csv,
            console_url=console_url,
            username=username,
            password=password,
            filters=filter_dict,
        )

        # Software inventory
        if enable_software_inventory:
            logger.info("Software Inventory Creation (SBOM)")
            logger.info("Note: SBOM processing for images requires separate sync_sbom command per image.")
            logger.info("Use: regscale prisma sync_sbom --resource-type image --resource-id <image_id>")

        logger.info("Image sync completed successfully!")

    except Exception as e:
        logger.error("Image sync failed: %s", e)
        raise click.Abort()


# =============================================================================
# SBOM Sync Command
# =============================================================================


@click.command(name="sync_sbom")
@regscale_ssp_id()
@click.option(
    "--resource-type",
    type=click.Choice(["host", "image", "all"], case_sensitive=False),
    default="all",
    help="Resource type to sync SBOMs for: host, image, or all (default: all).",
)
@click.option(
    "--resource-id",
    type=str,
    required=False,
    help="Specific resource identifier (optional for bulk download). Required when --no-bulk-download is used.",
)
@click.option(
    "--bulk-download",
    is_flag=True,
    default=True,
    help="Use bulk download endpoints for all SBOMs (recommended, default: True). "
    "Based on P1 customer feedback, this resolves HTTP 404 errors.",
)
@click.option(
    "--asset-id",
    type=int,
    required=False,
    help="RegScale Asset ID to associate software inventory with. If not provided, will search for asset by identifier.",
)
@click.option(
    "--enable-software-inventory",
    is_flag=True,
    default=False,
    help="Create software inventory records from SBOM data.",
)
@click.option(
    "--attach-evidence",
    is_flag=True,
    default=False,
    help="Attach SBOM JSON as evidence to the asset (requires --enable-software-inventory).",
)
@click.option(
    "--console-url",
    type=str,
    required=False,
    help="Override Prisma Console URL from init.yaml.",
)
@click.option(
    "--username",
    type=str,
    required=False,
    help="Override Prisma username from init.yaml.",
)
@click.option(
    "--password",
    type=str,
    required=False,
    hide_input=True,
    help="Override Prisma password from init.yaml.",
)
def sync_sbom(
    regscale_ssp_id: int,
    resource_type: str,
    resource_id: Optional[str],
    bulk_download: bool,
    asset_id: Optional[int],
    enable_software_inventory: bool,
    attach_evidence: bool,
    console_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
):
    """
    Sync SBOM (Software Bill of Materials) data from Prisma Cloud.

    Two modes:
    1. Bulk download (default): Downloads all SBOMs at once using bulk endpoints
    2. Individual: Downloads SBOM for specific resource (requires --resource-id and --no-bulk-download)

    Based on Platform One (P1) customer feedback, bulk download mode is recommended
    as it resolves HTTP 404 errors encountered with individual SBOM endpoints.

    Examples:
        # Bulk download all host SBOMs (recommended)
        regscale prisma sync_sbom --regscale_ssp_id 123 --resource-type host

        # Bulk download all image SBOMs with software inventory creation
        regscale prisma sync_sbom --regscale_ssp_id 123 --resource-type image \\
            --enable-software-inventory

        # Download all SBOMs (hosts + images)
        regscale prisma sync_sbom --regscale_ssp_id 123 --resource-type all

        # Individual SBOM download (legacy mode, may return 404)
        regscale prisma sync_sbom --regscale_ssp_id 123 --resource-type host \\
            --resource-id "web-server-01.example.com" --no-bulk-download --asset-id 456
    """
    try:
        logger.info("Prisma Cloud SBOM Sync (%s)", resource_type.upper())

        # Initialize scanner
        scanner = PrismaCloudScanner(plan_id=regscale_ssp_id, scan_type="sbom")

        # Authenticate
        logger.info("Authenticating to Prisma Cloud...")
        scanner.authenticate(console_url=console_url, username=username, password=password)

        if bulk_download:
            # === BULK DOWNLOAD MODE (Recommended) ===
            _sync_sbom_bulk_mode(
                scanner=scanner,
                resource_type=resource_type,
                enable_software_inventory=enable_software_inventory,
            )
        else:
            # === INDIVIDUAL MODE (Legacy) ===
            if not resource_id:
                logger.error("--resource-id is required when --no-bulk-download is used.")
                raise click.Abort()

            _sync_sbom_individual_mode(
                scanner=scanner,
                resource_type=resource_type,
                resource_id=resource_id,
                asset_id=asset_id,
                enable_software_inventory=enable_software_inventory,
                attach_evidence=attach_evidence,
            )

        logger.info("SBOM sync completed successfully!")

    except Exception as e:
        logger.error("SBOM sync failed: %s", e)
        raise click.Abort()


def _sync_sbom_bulk_mode(
    scanner: PrismaCloudScanner,
    resource_type: str,
    enable_software_inventory: bool,
):
    """
    Handle bulk SBOM download mode.

    :param PrismaCloudScanner scanner: Initialized scanner with authenticated client
    :param str resource_type: "host", "image", or "all"
    :param bool enable_software_inventory: Create software inventory records
    """
    total_sboms = 0
    total_packages = 0

    # Download host SBOMs
    if resource_type in ["host", "all"]:
        host_stats = _download_and_process_sboms(
            scanner=scanner,
            resource_category="hosts",
            enable_software_inventory=enable_software_inventory,
        )
        total_sboms += host_stats["sbom_count"]
        total_packages += host_stats["package_count"]

    # Download image SBOMs
    if resource_type in ["image", "all"]:
        image_stats = _download_and_process_sboms(
            scanner=scanner,
            resource_category="images",
            enable_software_inventory=enable_software_inventory,
        )
        total_sboms += image_stats["sbom_count"]
        total_packages += image_stats["package_count"]

    # Summary
    logger.info("Total SBOMs processed: %d", total_sboms)
    logger.info("Total software components: %d", total_packages)


def _download_and_process_sboms(
    scanner: PrismaCloudScanner,
    resource_category: str,
    enable_software_inventory: bool,
) -> dict:
    """
    Download and process SBOMs for a resource category.

    :param PrismaCloudScanner scanner: Initialized scanner
    :param str resource_category: "hosts" or "images"
    :param bool enable_software_inventory: Whether to create inventory
    :return: Dictionary with sbom_count and package_count
    :rtype: dict
    """
    stats = {"sbom_count": 0, "package_count": 0}

    # Ensure client is authenticated
    if scanner.client is None:
        logger.error("Scanner client not authenticated")
        return stats

    logger.info("Downloading bulk SBOM data for %s...", resource_category)
    try:
        # Download tar.gz archive
        if resource_category == "hosts":
            tar_gz_data = scanner.client.get_sbom_download_hosts()
        else:
            tar_gz_data = scanner.client.get_sbom_download_images()

        logger.info("Downloaded: %d bytes", len(tar_gz_data))

        # Extract SBOMs
        logger.info("Extracting SBOM archive...")
        sbom_map = extract_sbom_archive(tar_gz_data)
        logger.info("Extracted %d %s SBOMs", len(sbom_map), resource_category)

        # Process each SBOM
        for resource_id, sbom_data in sbom_map.items():
            summary = get_sbom_summary(sbom_data)
            logger.info(
                "%s: %s - Components: %d", resource_category[:-1].capitalize(), resource_id, summary["total_components"]
            )

            if enable_software_inventory:
                logger.warning("Software inventory creation requires --asset-id. Skipping.")

            stats["sbom_count"] += 1
            stats["package_count"] += summary["total_components"]

    except Exception as e:
        logger.error("Failed to download %s SBOMs: %s", resource_category, e)

    return stats


def _sync_sbom_individual_mode(
    scanner: PrismaCloudScanner,
    resource_type: str,
    resource_id: str,
    asset_id: Optional[int],
    enable_software_inventory: bool,
    attach_evidence: bool,
):
    """
    Handle individual SBOM download mode (legacy).

    :param PrismaCloudScanner scanner: Initialized scanner with authenticated client
    :param str resource_type: "host" or "image"
    :param str resource_id: Resource identifier
    :param Optional[int] asset_id: RegScale Asset ID
    :param bool enable_software_inventory: Create software inventory records
    :param bool attach_evidence: Attach SBOM as evidence
    """
    api = Api()
    logger.info("Resource: %s", resource_id)

    # Ensure client is authenticated
    if scanner.client is None:
        logger.error("Scanner client not authenticated")
        return

    # Fetch SBOM
    logger.info("Fetching SBOM for %s: %s...", resource_type, resource_id)
    logger.warning("Individual SBOM endpoint may return HTTP 404. Use bulk download mode (default).")

    sbom_data = scanner.client.get_sbom(resource_type, resource_id)

    # Display SBOM summary
    summary = get_sbom_summary(sbom_data)
    logger.info("SBOM Summary:")
    logger.info("  Format: %s %s", summary["bom_format"], summary["spec_version"])
    logger.info("  Total Components: %d", summary["total_components"])
    logger.info("  Target: %s %s", summary["target_name"], summary["target_version"])

    # Create software inventory if enabled
    if enable_software_inventory:
        if not asset_id:
            logger.warning("Asset ID not provided. Please provide --asset-id for software inventory creation.")
        else:
            logger.info("Creating software inventory for asset %d...", asset_id)
            count = create_software_inventory_from_sbom(
                api=api,
                asset_id=asset_id,
                sbom_data=sbom_data,
                deduplicate=True,
            )
            logger.info("Created %d software inventory records", count)

            # Attach evidence if requested
            if attach_evidence:
                logger.info("Attaching SBOM as evidence...")
                success = attach_sbom_as_evidence(
                    api=api,
                    asset_id=asset_id,
                    sbom_data=sbom_data,
                    file_name=f"prisma_sbom_{resource_type}_{resource_id.replace('/', '_')}.json",
                )
                if success:
                    logger.info("SBOM attached as evidence")
                else:
                    logger.warning("Failed to attach SBOM as evidence")


# Export all commands for registration
__all__ = [
    "authenticate",
    "sync_hosts",
    "sync_images",
    "sync_sbom",
]
