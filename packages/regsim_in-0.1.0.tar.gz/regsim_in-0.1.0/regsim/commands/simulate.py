# regsim/commands/simulate.py

from regsim.core.simulation import run_simulation

__all__ = ["run_simulation"]
