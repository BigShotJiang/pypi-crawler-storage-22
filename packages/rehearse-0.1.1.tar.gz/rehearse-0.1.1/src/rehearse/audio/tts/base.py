"""
Base TTS interface.
"""

from abc import ABC, abstractmethod


class BaseTTS(ABC):
    """Abstract base class for TTS providers."""

    @abstractmethod
    def synthesize(self, text: str) -> bytes:
        """
        Convert text to audio.

        Args:
            text: Text to convert to speech

        Returns:
            PCM16 audio bytes at 24kHz
        """
        pass

    async def synthesize_async(self, text: str) -> bytes:
        """Async wrapper for synthesize."""
        return self.synthesize(text)
