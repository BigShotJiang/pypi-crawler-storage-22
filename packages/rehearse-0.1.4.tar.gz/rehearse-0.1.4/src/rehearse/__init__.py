"""
Rehearse: Voice AI Testing Framework

A pytest-style testing framework for voice AI agents.

Usage:
    from rehearse import TwilioCall, expect
    from rehearse.audio.tts import ElevenLabsTTS
    from rehearse.audio.stt import ElevenLabsSTT

    tts = ElevenLabsTTS(api_key="...")
    stt = ElevenLabsSTT(api_key="...")

    async def test_greeting():
        async with TwilioCall(
            to="+15551234567",
            account_sid="ACxxxxx",
            auth_token="xxxxx",
            from_number="+15559876543",
            ngrok_url="abc123.ngrok-free.app",
            tts=tts,
            stt=stt,
        ) as call:
            greeting = await call.listen()
            expect(greeting).to_contain("hello")
"""

import logging

__version__ = "0.1.0"


def setup_logging(level: str = "INFO") -> None:
    """
    Configure logging for rehearse.

    Args:
        level: Log level - "DEBUG", "INFO", "WARNING", "ERROR"

    Usage:
        from rehearse import setup_logging
        setup_logging("DEBUG")  # Enable verbose logging
    """
    log_level = getattr(logging, level.upper(), logging.INFO)
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    logging.getLogger("rehearse").setLevel(log_level)

    # Suppress noisy third-party loggers
    logging.getLogger("twilio.http_client").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)


# Core API
from .conversation import Conversation, Response
from .assertions import expect, Expectation, LLMJudge, JudgmentResult

# Call Classes (primary interface)
from .connectors import TwilioCall

# Connectors (internal/advanced use)
from .connectors import BaseConnector, TwilioConnector, TwilioServer

# Audio
from .audio.tts import BaseTTS, ElevenLabsTTS
from .audio.stt import BaseSTT, ElevenLabsSTT
from .audio.formats import save_audio

# Exceptions
from .exceptions import (
    RehearsalError,
    ConnectionError,
    TimeoutError,
    ConfigurationError,
    AssertionError,
    AudioError,
)

__all__ = [
    # Version
    "__version__",
    # Primary API - Call Classes
    "TwilioCall",
    # Core
    "Conversation",
    "Response",
    "expect",
    "Expectation",
    "LLMJudge",
    "JudgmentResult",
    # Connectors (internal/advanced use)
    "BaseConnector",
    "TwilioConnector",
    "TwilioServer",
    # Audio
    "BaseTTS",
    "ElevenLabsTTS",
    "BaseSTT",
    "ElevenLabsSTT",
    "save_audio",
    "setup_logging",
    # Exceptions
    "RehearsalError",
    "ConnectionError",
    "TimeoutError",
    "ConfigurationError",
    "AssertionError",
    "AudioError",
]
