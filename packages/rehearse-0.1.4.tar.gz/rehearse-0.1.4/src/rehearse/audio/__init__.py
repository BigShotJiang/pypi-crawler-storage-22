"""
Audio processing utilities for Rehearse.

Includes TTS, STT, and audio format conversion.
"""

from .formats import (
    mulaw_8k_to_pcm16_24k,
    pcm16_24k_to_mulaw_8k,
    mulaw_8k_to_pcm16_8k,
    pcm16_to_mulaw,
    save_audio,
)

__all__ = [
    "mulaw_8k_to_pcm16_24k",
    "pcm16_24k_to_mulaw_8k",
    "mulaw_8k_to_pcm16_8k",
    "pcm16_to_mulaw",
    "save_audio",
]
