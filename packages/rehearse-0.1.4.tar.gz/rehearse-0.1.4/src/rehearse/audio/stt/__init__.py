"""
Speech-to-Text providers.
"""

from .base import BaseSTT
from .elevenlabs import ElevenLabsSTT

__all__ = ["BaseSTT", "ElevenLabsSTT"]
