"""
Base STT interface.
"""

from abc import ABC, abstractmethod


class BaseSTT(ABC):
    """Abstract base class for STT providers."""

    @abstractmethod
    def transcribe(self, audio: bytes, sample_rate: int = 24000) -> str:
        """
        Transcribe audio to text.

        Args:
            audio: PCM16 audio bytes
            sample_rate: Sample rate of the audio

        Returns:
            Transcribed text
        """
        pass

    async def transcribe_async(self, audio: bytes, sample_rate: int = 24000) -> str:
        """Async wrapper for transcribe."""
        return self.transcribe(audio, sample_rate)
