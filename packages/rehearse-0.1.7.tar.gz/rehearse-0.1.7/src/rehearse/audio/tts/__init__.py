"""
Text-to-Speech providers.
"""

from .base import BaseTTS
from .elevenlabs import ElevenLabsTTS

__all__ = ["BaseTTS", "ElevenLabsTTS"]
