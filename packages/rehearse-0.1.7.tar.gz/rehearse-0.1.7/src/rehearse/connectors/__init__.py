"""
Connectors for different voice platforms.

Each connector provides a way to connect to a voice agent and
exchange audio bidirectionally.

Primary API:
    TwilioCall - Make phone calls via Twilio (recommended)

Internal classes (for advanced use):
    TwilioConnector - Low-level Twilio connector
    TwilioServer - WebSocket server for Twilio Media Streams
    BaseConnector - Abstract base class for connectors
"""

from .base import BaseConnector
from .twilio import TwilioCall, TwilioConnector, TwilioServer

__all__ = ["TwilioCall", "BaseConnector", "TwilioConnector", "TwilioServer"]
