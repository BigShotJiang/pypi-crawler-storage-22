"""
Custom exceptions for the Rehearse framework.
"""


class RehearsalError(Exception):
    """Base exception for all Rehearse errors."""

    pass


class ConnectionError(RehearsalError):
    """Failed to connect to voice agent."""

    pass


class TimeoutError(RehearsalError):
    """Operation timed out."""

    pass


class ConfigurationError(RehearsalError):
    """Invalid or missing configuration."""

    pass


class AssertionError(RehearsalError):
    """Test assertion failed."""

    pass


class AudioError(RehearsalError):
    """Audio processing error."""

    pass
