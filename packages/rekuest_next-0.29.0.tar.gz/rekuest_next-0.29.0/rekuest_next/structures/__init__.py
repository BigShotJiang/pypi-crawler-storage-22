"""Structures alllow to wrap arbitary input types"""
