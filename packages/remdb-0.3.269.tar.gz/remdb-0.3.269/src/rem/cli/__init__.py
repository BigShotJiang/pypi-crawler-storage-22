"""
REM CLI - Command-line interface for REM operations.

Commands:
- schema: Database schema generation and management
- migrate: Run database migrations
- dev: Development utilities
"""
