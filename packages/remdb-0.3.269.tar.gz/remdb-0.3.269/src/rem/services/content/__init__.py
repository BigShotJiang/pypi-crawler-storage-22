"""Content processing service for file ingestion."""

from .service import ContentService

__all__ = ["ContentService"]
