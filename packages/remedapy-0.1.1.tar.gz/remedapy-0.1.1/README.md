# TODO

## Array

- [ ] allPass
- [ ] anyPass
- [ ] chunk
- [ ] concat
- [ ] countBy
- [ ] difference
- [ ] differenceWith
- [ ] drop
- [ ] dropFirstBy
- [ ] dropLast
- [ ] dropLastWhile
- [ ] dropWhile
- [ ] filter
- [ ] find
- [ ] findIndex
- [ ] findLast
- [ ] findLastIndex
- [ ] first
- [ ] firstBy
- [ ] flat
- [ ] flatMap
- [ ] forEach
- [ ] groupBy
- [ ] groupByProp
- [ ] hasAtLeast
- [ ] indexBy
- [ ] intersection
- [ ] intersectionWith
- [ ] join
- [ ] last
- [ ] length
- [x] map
- [ ] mapToObj
- [ ] mapWithFeedback
- [ ] meanBy
- [ ] mergeAll
- [ ] nthBy
- [ ] only
- [ ] partition
- [ ] range
- [ ] rankBy
- [ ] reduce
- [ ] reverse
- [ ] sample
- [ ] shuffle
- [ ] sort
- [ ] sortBy
- [ ] sortedIndex
- [ ] sortedIndexBy
- [ ] sortedIndexWith
- [ ] sortedLastIndex
- [ ] sortedLastIndexBy
- [ ] splice
- [ ] splitAt
- [ ] splitWhen
- [ ] sumBy
- [ ] swapIndices
- [ ] take
- [ ] takeFirstBy
- [ ] takeLast
- [ ] takeLastWhile
- [ ] takeWhile
- [ ] times
- [ ] unique
- [ ] uniqueBy
- [ ] uniqueWith
- [ ] zip
- [ ] zipWith

## Function

- [ ] conditional
- [ ] constant
- [ ] debounce
- [ ] doNothing
- [ ] funnel
- [ ] identity
- [ ] once
- [ ] partialBind
- [ ] partialLastBind
- [ ] pipe
- [ ] piped
- [ ] purry
- [ ] when

## Guard

- [ ] hasSubObject
- [ ] isArray
- [ ] isBigInt
- [ ] isBoolean
- [ ] isDate
- [ ] isDeepEqual
- [ ] isDefined
- [ ] isEmpty
- [ ] isEmptyish
- [ ] isError
- [ ] isFunction
- [ ] isIncludedIn
- [ ] isNonNull
- [ ] isNonNullish
- [ ] isNot
- [ ] isNullish
- [ ] isNumber
- [ ] isObjectType
- [ ] isPlainObject
- [ ] isPromise
- [ ] isShallowEqual
- [ ] isStrictEqual
- [ ] isString
- [ ] isSymbol
- [ ] isTruthy

## Number

- [x] add
- [ ] ceil
- [ ] clamp
- [ ] divide
- [ ] floor
- [ ] mean
- [ ] median
- [ ] multiply
- [ ] product
- [ ] randomBigInt
- [ ] randomInteger
- [ ] round
- [ ] subtract
- [ ] sum

## Object

- [ ] addProp
- [ ] clone
- [ ] entries
- [ ] evolve
- [ ] forEachObj
- [ ] fromEntries
- [ ] fromKeys
- [ ] invert
- [ ] keys
- [ ] mapKeys
- [ ] mapValues
- [ ] merge
- [ ] mergeDeep
- [ ] objOf
- [ ] omit
- [ ] omitBy
- [ ] pathOr
- [ ] pick
- [ ] pickBy
- [ ] prop
- [ ] pullObject
- [ ] set
- [ ] setPath
- [ ] swapProps
- [ ] values

## Other

- [ ] defaultTo
- [ ] tap

## String

- [ ] capitalize
- [ ] endsWith
- [ ] randomString
- [ ] sliceString
- [ ] split
- [ ] startsWith
- [ ] toCamelCase
- [ ] toKebabCase
- [ ] toLowerCase
- [ ] toSnakeCase
- [ ] toTitleCase
- [ ] toUpperCase
- [ ] truncate
- [ ] uncapitalize

## Utility

- [ ] stringToPath"
