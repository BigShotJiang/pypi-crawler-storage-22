import remedapy as R


class TestAdd:
    def test_data_first(self):
        # R.add(value, addend);
        assert R.add(10, 5) == 15
        assert R.add(10, -5) == 5

    def test_data_last(self):
        # R.add(addend)(value);
        assert R.add(5)(10) == 15
        assert R.add(-5)(10) == 5
        assert R.map([1, 2, 3, 4], R.add(1)) == [2, 3, 4, 5]
