"""Remind: AI-powered CLI reminder and notification engine."""

__version__ = "1.3.3"
__all__ = []
