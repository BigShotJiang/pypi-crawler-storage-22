"""Add command - create a new reminder."""

from datetime import datetime
from typing import Optional

import typer

from remind_shared import PriorityLevel, ValidationError
from remind_database import DatabaseConfig, DatabaseSession
from remind_cli.services.reminder_service import ReminderService
from remind_cli.services.ai_service import AIService
from remind_cli import output


def add(
    text: str = typer.Argument(..., help="Reminder text"),
    due: Optional[str] = typer.Option(None, "--due", "-d", help="Due date/time (e.g., 'tomorrow 5pm')"),
    priority: str = typer.Option("medium", "--priority", "-p", help="Priority: high, medium, low"),
    project: Optional[str] = typer.Option(None, "--project", "-P", help="Project context"),
    allow_past_due: bool = typer.Option(False, "--allow-past-due", hidden=True, help="Allow past due dates (testing only)"),
) -> None:
    """Add a new reminder.

    Examples:
      remind add 'Buy groceries'
      remind add 'Call mom' --due 'tomorrow 5pm' --priority high
      remind add 'Review PR' --project work
    """
    try:
        from dateparser import parse as dateparser_parse

        user_set_due = due is not None
        user_set_priority = priority != "medium"

        # Parse explicit --due flag
        if due:
            due_dt = dateparser_parse(due)
            if not due_dt:
                output.error(f"Could not parse due date: {due}")
                raise typer.Exit(1)
        else:
            due_dt = None

        # Validate priority
        try:
            priority_level = PriorityLevel(priority.lower())
        except ValueError:
            output.error(f"Invalid priority: {priority}. Use: high, medium, low")
            raise typer.Exit(1)

        # Initialize services
        db_config = DatabaseConfig()
        db_session = DatabaseSession(db_config)

        # Get AI suggestion
        ai_text = None
        ai_service = AIService()
        try:
            with output.spinner("Getting AI suggestion"):
                ai_response = ai_service.suggest_reminder(text)

            if ai_response.quota_exhausted:
                output.warning("AI quota exhausted — saving reminder without AI")
            else:
                ai_text = ai_response.suggested_text
                output.ai_suggestion(ai_text)

                # Use AI's due time if user didn't explicitly set --due
                if not user_set_due and ai_response.due_time_suggestion:
                    parsed = dateparser_parse(ai_response.due_time_suggestion)
                    if parsed:
                        due_dt = parsed

                # Use AI's priority if user didn't explicitly set --priority
                if not user_set_priority and ai_response.priority:
                    priority_level = ai_response.priority

        except Exception as e:
            output.warning(f"AI suggestion failed: {e}")

        # Fall back: try to parse date from the text itself
        if due_dt is None:
            parsed = dateparser_parse(text, settings={"PREFER_DATES_FROM": "future"})
            if parsed:
                due_dt = parsed
            else:
                due_dt = datetime.now()

        # Create reminder with context manager
        with db_session.get_session() as session:
            reminder_service = ReminderService(session)
            reminder = reminder_service.create_reminder(
                text=text,
                due_at=due_dt,
                priority=priority_level,
                project_context=project,
                ai_suggested_text=ai_text,
                allow_past_due=allow_past_due,
            )

        # Dispatch plugin hook if text is not agent-generated
        if not text.startswith("[AGENT:"):
            from remind_plugin_base import Reminder as PluginReminder
            from remind_cli.plugins import PluginManager

            plugin_reminder = PluginReminder(
                id=reminder.id,
                text=reminder.text,
                due_date=reminder.due_at.isoformat() if reminder.due_at else None,
                is_done=False,
            )
            PluginManager().dispatch_created(plugin_reminder)

        output.blank()
        output.success(f"Reminder saved (#{reminder.id})")
        output.label_value("Text", reminder.text)
        output.label_value("Due", str(reminder.due_at))
        output.label_value("Priority", priority_level.value.upper())
        output.blank()

    except ValidationError as e:
        output.error(str(e))
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        output.error(str(e))
        raise typer.Exit(1)
