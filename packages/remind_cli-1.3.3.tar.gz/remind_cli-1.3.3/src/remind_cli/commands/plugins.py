"""Plugin management commands."""

import subprocess
import sys

import typer
from rich.table import Table

from remind_cli import output
from remind_cli.plugins import PluginManager

plugins_app = typer.Typer(help="Manage Remind plugins")


@plugins_app.command()
def list() -> None:
    """List all discovered plugins and their configuration status."""
    pm = PluginManager()
    discovered = pm.discover()

    if not discovered:
        output.label_value("Plugins", "[dim]No plugins installed[/dim]")
        return

    table = Table(title="Installed Plugins")
    table.add_column("Name", style="cyan")
    table.add_column("Version", style="magenta")
    table.add_column("Status", style="green")

    for plugin in discovered:
        config_dir = pm.config_dir_for(plugin.name)
        is_configured = plugin.is_configured(config_dir)
        status_mark = "[success]✓[/success]" if is_configured else "[warning]○[/warning]"
        status_text = f"{status_mark} {plugin.status(config_dir)}"
        table.add_row(plugin.display_name, plugin.version, status_text)

    output.blank()
    output.console.print(table)
    output.blank()


@plugins_app.command()
def add(plugin_name: str) -> None:
    """Install and configure a plugin.

    Examples:
      remind plugins add google-tasks
      remind plugins add slack
    """
    # Try to load the plugin if already installed
    pm = PluginManager()

    # Install the plugin package if not already installed
    package_name = f"remind-plugin-{plugin_name}"
    _install_plugin_package(package_name)

    # Re-discover plugins after installation
    pm = PluginManager()
    pm._plugins = None  # Clear cache to force re-discovery

    discovered = pm.discover()
    plugin = None
    for p in discovered:
        if p.name == plugin_name:
            plugin = p
            break

    if plugin is None:
        output.error(
            f"Plugin '{plugin_name}' not found after installation. "
            f"Ensure the package exports a plugin with name='{plugin_name}'."
        )
        raise typer.Exit(1)

    config_dir = pm.config_dir_for(plugin.name)

    output.blank()
    output.label_value("Setting up", plugin.display_name)
    output.blank()

    try:
        plugin.setup(config_dir)
        output.blank()
        output.success(f"{plugin.display_name} configured successfully!")
        output.blank()
        output.label_value("Config directory", str(config_dir))
        output.blank()
    except Exception as e:
        output.error(f"Setup failed: {e}")
        raise typer.Exit(1)


@plugins_app.command()
def remove(plugin_name: str) -> None:
    """Uninstall and remove a plugin.

    Examples:
      remind plugins remove google-tasks
    """
    pm = PluginManager()
    discovered = pm.discover()

    plugin = None
    for p in discovered:
        if p.name == plugin_name:
            plugin = p
            break

    if plugin is None:
        output.error(f"Plugin '{plugin_name}' not found.")
        raise typer.Exit(1)

    config_dir = pm.config_dir_for(plugin.name)

    output.blank()
    output.label_value("Removing", plugin.display_name)
    output.blank()

    try:
        plugin.teardown(config_dir)
        output.blank()
        output.success(f"{plugin.display_name} removed successfully!")
        output.blank()

        # Optionally uninstall the package
        if typer.confirm("Uninstall the plugin package as well?"):
            package_name = f"remind-plugin-{plugin_name}"
            _uninstall_plugin_package(package_name)
            output.success(f"Package {package_name} uninstalled.")

        output.blank()
    except Exception as e:
        output.error(f"Removal failed: {e}")
        raise typer.Exit(1)


def _install_plugin_package(package_name: str) -> None:
    """Install a plugin package via uv or pip.

    Args:
        package_name: The package name (e.g., 'remind-plugin-google-tasks').
    """
    try:
        # Try uv first (if available)
        result = subprocess.run(
            ["uv", "pip", "install", package_name],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            # Fall back to pip
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", package_name],
                capture_output=True,
                text=True,
                check=True,
            )
    except subprocess.CalledProcessError as e:
        raise Exception(f"Failed to install {package_name}: {e.stderr}") from e


def _uninstall_plugin_package(package_name: str) -> None:
    """Uninstall a plugin package via uv or pip.

    Args:
        package_name: The package name (e.g., 'remind-plugin-google-tasks').
    """
    try:
        result = subprocess.run(
            ["uv", "pip", "uninstall", "-y", package_name],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            subprocess.run(
                [sys.executable, "-m", "pip", "uninstall", "-y", package_name],
                capture_output=True,
                text=True,
                check=True,
            )
    except subprocess.CalledProcessError as e:
        raise Exception(f"Failed to uninstall {package_name}: {e.stderr}") from e
