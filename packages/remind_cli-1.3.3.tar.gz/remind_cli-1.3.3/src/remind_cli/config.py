"""Configuration management for Remind."""

from pathlib import Path

from pydantic import ValidationError
from pydantic_settings import BaseSettings, SettingsConfigDict

from remind_shared import Config as ConfigModel
from remind_cli.platform_utils import (
    get_config_path as _get_config_path,
)
from remind_cli.platform_utils import (
    get_db_path as _get_db_path,
)
from remind_cli.platform_utils import (
    get_license_path as _get_license_path,
)


class Settings(BaseSettings):
    """Application settings loaded from environment and config file."""

    timezone: str = "UTC"
    scheduler_interval_minutes: int = 1
    notifications_enabled: bool = True
    notification_sound_enabled: bool = True
    ai_rephrasing_enabled: bool = True
    ai_backend_url: str | None = "https://remind-production-0871.up.railway.app"
    openai_api_key: str | None = None
    nudge_intervals_minutes: str = "5,15,60"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="REMIND_",
        extra="ignore",
    )


def get_db_path() -> Path:
    """Get the database path (platform-specific)."""
    return _get_db_path()


def get_license_path() -> Path:
    """Get the license token file path (platform-specific)."""
    return _get_license_path()


def get_config_path() -> Path:
    """Get the config file path (platform-specific)."""
    return _get_config_path()


def load_config() -> ConfigModel:
    """Load user configuration from config file and environment."""
    settings = Settings()

    # Try to load from TOML config file
    config_path = get_config_path()
    if config_path.exists():
        try:
            import tomllib
        except ModuleNotFoundError:
            import tomli as tomllib  # type: ignore

        try:
            with open(config_path, "rb") as f:
                data = tomllib.load(f)
                config_data = data.get("remind", {})
        except Exception as e:
            print(f"Warning: Could not load config file: {e}")
            config_data = {}
    else:
        config_data = {}

    # Override with environment variables
    if settings.timezone != "UTC":
        config_data["timezone"] = settings.timezone
    if settings.scheduler_interval_minutes != 1:
        config_data["scheduler_interval_minutes"] = settings.scheduler_interval_minutes
    if not settings.notifications_enabled:
        config_data["notifications_enabled"] = False
    if not settings.notification_sound_enabled:
        config_data["notification_sound_enabled"] = False
    if not settings.ai_rephrasing_enabled:
        config_data["ai_rephrasing_enabled"] = False
    if settings.ai_backend_url:
        config_data["ai_backend_url"] = settings.ai_backend_url
    if settings.openai_api_key:
        config_data["openai_api_key"] = settings.openai_api_key

    # Parse nudge intervals
    if "nudge_intervals_minutes" not in config_data:
        nudge_str = settings.nudge_intervals_minutes
        config_data["nudge_intervals_minutes"] = [int(x.strip()) for x in nudge_str.split(",")]

    try:
        return ConfigModel(**config_data)
    except ValidationError as e:
        print(f"Warning: Invalid config, using defaults: {e}")
        return ConfigModel()


def save_config(config: ConfigModel) -> None:
    """Save configuration to TOML file."""
    config_path = get_config_path()
    try:
        import tomllib

        import toml  # type: ignore
    except ModuleNotFoundError:
        try:
            import tomli as tomllib  # type: ignore  # noqa: F401
            import tomli_w as toml  # type: ignore
        except ModuleNotFoundError:
            print("Warning: toml libraries not available, skipping config save")
            return

    data = {"remind": config.model_dump()}
    config_path.parent.mkdir(parents=True, exist_ok=True)
    with open(config_path, "w") as f:
        toml.dump(data, f)
