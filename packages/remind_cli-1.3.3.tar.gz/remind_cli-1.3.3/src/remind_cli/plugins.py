"""Plugin system for Remind."""

from __future__ import annotations

from importlib.metadata import entry_points
from pathlib import Path

from remind_plugin_base import BasePlugin, Reminder


class PluginManager:
    """Manages plugin discovery, lifecycle, and hook execution."""

    PLUGINS_ENTRY_GROUP = "remind.plugins"
    PLUGINS_DIR = Path.home() / ".remind" / "plugins"

    def __init__(self) -> None:
        """Initialize plugin manager."""
        self._plugins: dict[str, BasePlugin] | None = None

    def discover(self) -> list[BasePlugin]:
        """Discover and load all installed plugins via entry_points.

        Plugins are discovered from the "remind.plugins" entry point group.
        Each plugin package declares:

            [project.entry-points."remind.plugins"]
            my-plugin = "my_package:MyPluginClass"

        Returns:
            List of loaded plugin instances.

        Raises:
            Exception: If a plugin fails to load.
        """
        if self._plugins is not None:
            return list(self._plugins.values())

        self._plugins = {}
        eps = entry_points()

        # Try to select plugins from the entry group
        selected = eps.select(group=self.PLUGINS_ENTRY_GROUP)
        if not selected:
            return []

        for ep in selected:
            try:
                plugin_class = ep.load()
                plugin = plugin_class()
                self._plugins[plugin.name] = plugin
            except Exception as e:
                raise Exception(f"Failed to load plugin '{ep.name}': {e}") from e

        return list(self._plugins.values())

    def config_dir_for(self, plugin_name: str) -> Path:
        """Get the config directory for a plugin.

        Args:
            plugin_name: The plugin's name (e.g., 'google-tasks').

        Returns:
            Path to ~/.remind/plugins/<plugin-name>/
        """
        config_dir = self.PLUGINS_DIR / plugin_name
        config_dir.mkdir(parents=True, exist_ok=True)
        return config_dir

    def dispatch_created(self, reminder: Reminder) -> None:
        """Call on_reminder_created hooks for all configured plugins.

        Args:
            reminder: The newly created reminder.
        """
        plugins = self.discover()
        for plugin in plugins:
            if not plugin.is_configured(self.config_dir_for(plugin.name)):
                continue
            try:
                plugin.on_reminder_created(reminder, self.config_dir_for(plugin.name))
            except Exception as e:
                print(f"Error in plugin {plugin.name} (on_reminder_created): {e}")

    def dispatch_due(self, reminder: Reminder) -> None:
        """Call on_reminder_due hooks for all configured plugins.

        Args:
            reminder: The reminder that is due.
        """
        plugins = self.discover()
        for plugin in plugins:
            if not plugin.is_configured(self.config_dir_for(plugin.name)):
                continue
            try:
                plugin.on_reminder_due(reminder, self.config_dir_for(plugin.name))
            except Exception as e:
                print(f"Error in plugin {plugin.name} (on_reminder_due): {e}")

    def dispatch_done(self, reminder: Reminder) -> None:
        """Call on_reminder_done hooks for all configured plugins.

        Args:
            reminder: The reminder that was completed.
        """
        plugins = self.discover()
        for plugin in plugins:
            if not plugin.is_configured(self.config_dir_for(plugin.name)):
                continue
            try:
                plugin.on_reminder_done(reminder, self.config_dir_for(plugin.name))
            except Exception as e:
                print(f"Error in plugin {plugin.name} (on_reminder_done): {e}")
