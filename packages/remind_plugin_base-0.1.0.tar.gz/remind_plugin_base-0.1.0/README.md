# remind-plugin-base

Base package for Remind plugins.

Plugin authors depend on this to create Remind integrations. Provides the `BasePlugin` ABC and `Reminder` model.

## Usage

```python
from pathlib import Path
from remind_plugin_base import BasePlugin, Reminder


class MyPlugin(BasePlugin):
    name = "my-plugin"
    display_name = "My Plugin"
    version = "0.1.0"

    def setup(self, config_dir: Path) -> None:
        # Interactive setup wizard
        pass

    def teardown(self, config_dir: Path) -> None:
        # Cleanup
        pass

    def is_configured(self, config_dir: Path) -> bool:
        # Check if configured
        return (config_dir / "config.json").exists()

    def status(self, config_dir: Path) -> str:
        # Status for `remind doctor`
        return "✓ Configured" if self.is_configured(config_dir) else "Not configured"

    def on_reminder_due(self, reminder: Reminder, config_dir: Path) -> None:
        # Called when a reminder is due
        print(f"Reminder due: {reminder.text}")
```

Declare your plugin in your package's `pyproject.toml`:

```toml
[project.entry-points."remind.plugins"]
my-plugin = "my_plugin_package:MyPlugin"
```

## License

MIT
