"""Remind plugin base package."""

from pathlib import Path
from abc import ABC, abstractmethod
from pydantic import BaseModel

__version__ = "0.1.0"


class Reminder(BaseModel):
    """Reminder data passed to plugin hooks."""

    id: int
    text: str
    due_date: str | None = None
    is_done: bool = False


class BasePlugin(ABC):
    """Base class for Remind plugins.

    Plugin authors subclass this to integrate with Remind.
    Entry point in plugin's pyproject.toml:

        [project.entry-points."remind.plugins"]
        my-plugin = "my_plugin_package:MyPlugin"
    """

    name: str
    """Plugin identifier (e.g., 'google-tasks'). Used for config storage."""

    display_name: str
    """User-friendly name (e.g., 'Google Tasks')."""

    version: str
    """Plugin version (e.g., '0.1.0')."""

    @abstractmethod
    def setup(self, config_dir: Path) -> None:
        """Interactive setup wizard.

        Called when user runs: remind plugins add <plugin-name>

        Should:
        - Prompt for user credentials/configuration
        - Open browser for OAuth flows if needed
        - Save config to config_dir (e.g., config.json, credentials.json)
        - Raise Exception if setup fails

        Args:
            config_dir: Path to ~/.remind/plugins/<plugin-name>/
                        Create this if it doesn't exist.
        """

    @abstractmethod
    def teardown(self, config_dir: Path) -> None:
        """Cleanup when user removes plugin.

        Called when user runs: remind plugins remove <plugin-name>

        Should:
        - Revoke API tokens if applicable
        - Delete credentials
        - Clean up external resources
        - Raise Exception if teardown fails

        Args:
            config_dir: Path to ~/.remind/plugins/<plugin-name>/
        """

    @abstractmethod
    def is_configured(self, config_dir: Path) -> bool:
        """Check if plugin is properly configured.

        Used by doctor command and hook execution.
        If False, lifecycle hooks will NOT be called.

        Args:
            config_dir: Path to ~/.remind/plugins/<plugin-name>/

        Returns:
            True if plugin has valid config/credentials, False otherwise.
        """

    @abstractmethod
    def status(self, config_dir: Path) -> str:
        """One-line status message for doctor command.

        Examples:
        - "✓ Authenticated, 3 task lists"
        - "⚠ Missing credentials"
        - "Not configured"

        Args:
            config_dir: Path to ~/.remind/plugins/<plugin-name>/

        Returns:
            Status string to display.
        """

    def on_reminder_created(self, _reminder: Reminder, _config_dir: Path) -> None:
        """Optional: called when a reminder is created.

        Default: no-op.

        Args:
            _reminder: The newly created reminder.
            _config_dir: Path to ~/.remind/plugins/<plugin-name>/
        """

    def on_reminder_due(self, _reminder: Reminder, _config_dir: Path) -> None:
        """Optional: called when a reminder is due.

        Default: no-op.

        Args:
            _reminder: The reminder that is due.
            _config_dir: Path to ~/.remind/plugins/<plugin-name>/
        """

    def on_reminder_done(self, _reminder: Reminder, _config_dir: Path) -> None:
        """Optional: called when a reminder is marked done.

        Default: no-op.

        Args:
            _reminder: The reminder that was completed.
            _config_dir: Path to ~/.remind/plugins/<plugin-name>/
        """


__all__ = ["BasePlugin", "Reminder", "__version__"]
