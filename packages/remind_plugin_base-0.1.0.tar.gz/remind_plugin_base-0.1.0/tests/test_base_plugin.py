"""Tests for BasePlugin ABC."""

from pathlib import Path

from remind_plugin_base import BasePlugin, Reminder


class SimplePlugin(BasePlugin):
    """Simple test implementation of BasePlugin."""

    name = "test-plugin"
    display_name = "Test Plugin"
    version = "0.1.0"

    def setup(self, config_dir: Path) -> None:
        """Setup test plugin."""
        (config_dir / "test_config").touch()

    def teardown(self, _config_dir: Path) -> None:
        """Teardown test plugin."""
        pass

    def is_configured(self, config_dir: Path) -> bool:
        """Check if configured."""
        return (config_dir / "test_config").exists()

    def status(self, config_dir: Path) -> str:
        """Get status."""
        if self.is_configured(config_dir):
            return "✓ Configured"
        return "Not configured"


def test_base_plugin_can_be_subclassed():
    """Test that BasePlugin can be subclassed."""
    plugin = SimplePlugin()
    assert plugin.name == "test-plugin"
    assert plugin.display_name == "Test Plugin"
    assert plugin.version == "0.1.0"


def test_plugin_lifecycle(tmp_path):
    """Test plugin setup/teardown lifecycle."""
    plugin = SimplePlugin()

    # Initially not configured
    assert not plugin.is_configured(tmp_path)
    assert plugin.status(tmp_path) == "Not configured"

    # After setup, should be configured
    plugin.setup(tmp_path)
    assert plugin.is_configured(tmp_path)
    assert plugin.status(tmp_path) == "✓ Configured"


def test_reminder_model():
    """Test Reminder data model."""
    reminder = Reminder(
        id=1,
        text="Buy groceries",
        due_date="2025-02-18T17:00:00",
        is_done=False,
    )
    assert reminder.id == 1
    assert reminder.text == "Buy groceries"
    assert reminder.due_date == "2025-02-18T17:00:00"
    assert reminder.is_done is False


def test_plugin_hooks_are_optional(tmp_path):
    """Test that plugin hooks have default implementations."""
    plugin = SimplePlugin()
    reminder = Reminder(id=1, text="Test", is_done=False)

    # These should not raise
    plugin.on_reminder_created(reminder, tmp_path)
    plugin.on_reminder_due(reminder, tmp_path)
    plugin.on_reminder_done(reminder, tmp_path)
