# remind-plugin-google-tasks

Sync reminders from Remind CLI with Google Tasks.

When you create a reminder in Remind, it automatically appears in your Google Task list. Keep your tasks organized in one place.

## Installation

```bash
# Install the plugin
pip install remind-plugin-google-tasks

# Or with uv
uv pip install remind-plugin-google-tasks
```

## Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com) and create a new project
2. Enable **Google Tasks API** for your project
3. Create an **OAuth 2.0 credential** (Desktop app type)
4. Download the `client_secrets.json` file
5. Set the path:

```bash
export REMIND_GOOGLE_CLIENT_SECRETS_PATH=~/Downloads/client_secrets.json
```

6. Configure the plugin:

```bash
remind plugins add google-tasks
```

This will open your browser for OAuth authorization and let you select which Google Task list to sync with.

## Usage

Simply use Remind as normal:

```bash
remind add 'Buy groceries' --due 'tomorrow 5pm'
```

The reminder is instantly synced to your Google Task list.

## Status

Check plugin status anytime:

```bash
remind plugins
remind doctor
```

## Uninstall

```bash
remind plugins remove google-tasks
```

## License

MIT
