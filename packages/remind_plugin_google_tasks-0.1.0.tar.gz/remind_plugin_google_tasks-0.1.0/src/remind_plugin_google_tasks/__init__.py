"""Google Tasks plugin for Remind."""

from remind_plugin_google_tasks.plugin import GoogleTasksPlugin

__version__ = "0.1.0"

__all__ = ["GoogleTasksPlugin", "__version__"]
