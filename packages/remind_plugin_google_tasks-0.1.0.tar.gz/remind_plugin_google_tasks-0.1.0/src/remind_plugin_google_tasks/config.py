"""Configuration models for Google Tasks plugin."""

from pydantic import BaseModel


class GoogleTasksConfig(BaseModel):
    """Google Tasks plugin configuration."""

    task_list_id: str
    """The ID of the Google Task list to sync with."""

    task_list_name: str
    """The human-readable name of the task list (e.g., 'Remind')."""

    class Config:
        """Pydantic config."""
        json_file = "config.json"
