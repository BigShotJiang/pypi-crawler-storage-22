"""Google OAuth 2.0 flow for Google Tasks."""

import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from threading import Thread
from typing import Optional
from urllib.parse import parse_qs, urlparse

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow


class LocalhostServer:
    """Simple HTTP server to capture OAuth callback on localhost:8080."""

    def __init__(self, port: int = 8080) -> None:
        """Initialize server.

        Args:
            port: Port to listen on (default 8080).
        """
        self.port = port
        self.auth_code: Optional[str] = None
        self.server: Optional[HTTPServer] = None

    def start(self) -> None:
        """Start the server in a background thread."""
        self.server = HTTPServer(("localhost", self.port), self._make_handler())

        thread = Thread(target=self.server.handle_request, daemon=True)
        thread.start()

    def _make_handler(self):
        """Create a request handler that captures the auth code."""
        server = self

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                """Handle GET request (OAuth callback)."""
                parsed = urlparse(self.path)
                params = parse_qs(parsed.query)

                if "code" in params:
                    server.auth_code = params["code"][0]
                    self.send_response(200)
                    self.send_header("Content-type", "text/html")
                    self.end_headers()
                    html = """
                    <html>
                    <head><title>Authorized</title></head>
                    <body>
                    <h1>Authorization Successful</h1>
                    <p>You can close this window and return to your terminal.</p>
                    </body>
                    </html>
                    """
                    self.wfile.write(html.encode())
                else:
                    self.send_response(400)
                    self.end_headers()

            def log_message(self, _format, *_args):
                """Suppress server logs."""
                pass

        return Handler

    def stop(self) -> None:
        """Stop the server."""
        if self.server:
            self.server.server_close()


def get_google_credentials(
    config_dir: Path, client_secrets_path: Optional[Path | str] = None
) -> Credentials:
    """Authenticate with Google and return credentials.

    First tries to load existing credentials from config_dir.
    If not found or expired, runs OAuth flow.

    Args:
        config_dir: Directory to store credentials (e.g., ~/.remind/plugins/google-tasks/).
        client_secrets_path: Path to client_secrets.json from Google Cloud Console.
                             If None, looks for REMIND_GOOGLE_CLIENT_SECRETS_PATH env var.

    Returns:
        Valid Google OAuth credentials.

    Raises:
        Exception: If OAuth flow fails or credentials not found.
    """
    import os

    credentials_file = config_dir / "credentials.json"

    # Try to load existing credentials
    if credentials_file.exists():
        creds = Credentials.from_authorized_user_file(str(credentials_file))
        if creds.valid:
            return creds
        if creds.expired and creds.refresh_token:
            creds.refresh(Request())
            _save_credentials(creds, credentials_file)
            return creds

    # No valid credentials, run OAuth flow
    if client_secrets_path is None:
        env_path = os.environ.get("REMIND_GOOGLE_CLIENT_SECRETS_PATH")
        if not env_path:
            raise Exception(
                "Google OAuth client secrets not found. "
                "Set REMIND_GOOGLE_CLIENT_SECRETS_PATH or provide path to client_secrets.json from Google Cloud Console."
            )
        client_secrets_path = Path(env_path).expanduser()
    else:
        client_secrets_path = Path(client_secrets_path).expanduser()

    if not client_secrets_path.exists():
        raise Exception(f"Client secrets file not found: {client_secrets_path}")

    # Run OAuth flow
    scopes = ["https://www.googleapis.com/auth/tasks"]
    flow = InstalledAppFlow.from_client_secrets_file(str(client_secrets_path), scopes)

    # Run local server to capture callback
    server = LocalhostServer()
    server.start()

    # Open browser for user to authorize
    auth_url, _ = flow.authorization_url()
    webbrowser.open(auth_url)

    # Wait for callback (max 10 minutes)
    import time

    for _ in range(600):  # 10 minutes
        if server.auth_code:
            break
        time.sleep(1)
    else:
        raise Exception("OAuth callback not received (timed out)")

    server.stop()

    # Exchange auth code for credentials
    flow.fetch_token(code=server.auth_code)
    creds = flow.credentials

    # Save credentials
    _save_credentials(creds, credentials_file)

    return creds


def _save_credentials(creds: Credentials, path: Path) -> None:
    """Save credentials to a JSON file.

    Args:
        creds: Google OAuth credentials.
        path: Path to save credentials to.
    """
    path.write_text(creds.to_json())
