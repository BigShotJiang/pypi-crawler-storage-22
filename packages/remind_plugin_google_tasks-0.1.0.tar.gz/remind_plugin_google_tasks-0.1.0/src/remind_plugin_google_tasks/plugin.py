"""Google Tasks plugin for Remind."""

import json
from pathlib import Path

import typer
from remind_plugin_base import BasePlugin, Reminder

from remind_plugin_google_tasks.config import GoogleTasksConfig
from remind_plugin_google_tasks.tasks_client import GoogleTasksClient


class GoogleTasksPlugin(BasePlugin):
    """Sync Remind reminders with Google Tasks."""

    name = "google-tasks"
    display_name = "Google Tasks"
    version = "0.1.0"

    def setup(self, config_dir: Path) -> None:
        """Interactive setup wizard for Google Tasks.

        Prompts user for Google OAuth credentials and task list selection.

        Args:
            config_dir: Path to ~/.remind/plugins/google-tasks/

        Raises:
            Exception: If setup fails.
        """
        typer.echo("\n[bold cyan]Google Tasks Setup[/bold cyan]\n")

        try:
            # Get OAuth credentials
            typer.echo("1. Authenticating with Google...")
            client = GoogleTasksClient(config_dir)

            # List task lists and let user pick one
            typer.echo("2. Fetching your Google Task lists...")
            task_lists = client.list_task_lists()

            if not task_lists:
                typer.echo(
                    "No task lists found. Creating a new one called 'Remind'...\n"
                )
                task_list_id = client.create_task_list("Remind")
                task_list_name = "Remind"
            else:
                typer.echo("\nAvailable task lists:")
                for i, tl in enumerate(task_lists, 1):
                    typer.echo(f"  {i}. {tl['title']}")

                choice = typer.prompt(
                    "\nSelect a task list (number) or enter a name to create a new one",
                    type=str,
                )

                if choice.isdigit() and 1 <= int(choice) <= len(task_lists):
                    selected = task_lists[int(choice) - 1]
                    task_list_id = selected["id"]
                    task_list_name = selected["title"]
                else:
                    # Create new task list
                    task_list_name = choice
                    typer.echo(f"\nCreating new task list '{task_list_name}'...")
                    task_list_id = client.create_task_list(task_list_name)

            # Save config
            config = GoogleTasksConfig(
                task_list_id=task_list_id, task_list_name=task_list_name
            )
            config_file = config_dir / "config.json"
            config_file.write_text(config.model_dump_json(indent=2))

            # Create test task
            typer.echo(f"\nCreating test task in '{task_list_name}'...")
            client.insert_task(
                task_list_id,
                "✓ Remind CLI is connected to Google Tasks!",
                "This task was created by the Remind CLI integration.",
            )

            typer.echo("\n[bold green]✓ Setup complete![/bold green]\n")

        except Exception as e:
            typer.echo(f"\n[bold red]✗ Setup failed: {e}[/bold red]\n")
            raise

    def teardown(self, config_dir: Path) -> None:
        """Remove plugin credentials and configuration.

        Args:
            config_dir: Path to ~/.remind/plugins/google-tasks/

        Raises:
            Exception: If teardown fails.
        """
        try:
            # Delete credentials file
            credentials_file = config_dir / "credentials.json"
            if credentials_file.exists():
                credentials_file.unlink()

            # Delete config file
            config_file = config_dir / "config.json"
            if config_file.exists():
                config_file.unlink()

            # Remove the plugin directory
            if config_dir.exists():
                config_dir.rmdir()

        except Exception as e:
            raise Exception(f"Failed to remove plugin configuration: {e}") from e

    def is_configured(self, config_dir: Path) -> bool:
        """Check if plugin is properly configured.

        Args:
            config_dir: Path to ~/.remind/plugins/google-tasks/

        Returns:
            True if both credentials and config exist.
        """
        credentials_file = config_dir / "credentials.json"
        config_file = config_dir / "config.json"
        return credentials_file.exists() and config_file.exists()

    def status(self, config_dir: Path) -> str:
        """Get status for doctor command.

        Args:
            config_dir: Path to ~/.remind/plugins/google-tasks/

        Returns:
            Status string.
        """
        if not self.is_configured(config_dir):
            return "Not configured"

        try:
            config_file = config_dir / "config.json"
            config_data = json.loads(config_file.read_text())
            task_list_name = config_data.get("task_list_name", "Unknown")
            return f"Authenticated, syncing to '{task_list_name}'"
        except Exception:
            return "Configured but error reading status"

    def on_reminder_created(self, reminder: Reminder, config_dir: Path) -> None:
        """Create a task in Google Tasks when a reminder is created.

        Args:
            reminder: The newly created reminder.
            config_dir: Path to ~/.remind/plugins/google-tasks/
        """
        try:
            config_file = config_dir / "config.json"
            config_data = json.loads(config_file.read_text())
            task_list_id = config_data["task_list_id"]

            # Format task note with due date
            notes = None
            if reminder.due_date:
                notes = f"Due: {reminder.due_date}"

            client = GoogleTasksClient(config_dir)
            client.insert_task(task_list_id, reminder.text, notes)

        except Exception as e:
            print(f"Error syncing reminder to Google Tasks: {e}")

    def on_reminder_due(self, _reminder: Reminder, _config_dir: Path) -> None:
        """Optionally send a notification when a reminder is due.

        Args:
            _reminder: The reminder that is due.
            _config_dir: Path to ~/.remind/plugins/google-tasks/
        """
        # For now, just a no-op. Could integrate with Google Calendar or send emails.
        pass

    def on_reminder_done(self, _reminder: Reminder, _config_dir: Path) -> None:
        """Mark task as done in Google Tasks when marked done in Remind.

        Args:
            _reminder: The reminder that was completed.
            _config_dir: Path to ~/.remind/plugins/google-tasks/
        """
        # This would require tracking which Remind reminder ID maps to which Google Task ID.
        # For now, this is a placeholder. Full implementation would store a mapping file.
        pass
