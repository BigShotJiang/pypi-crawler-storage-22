"""Google Tasks API client."""

from pathlib import Path
from typing import Optional

from googleapiclient.discovery import build

from remind_plugin_google_tasks.oauth import get_google_credentials


class GoogleTasksClient:
    """Client for interacting with Google Tasks API."""

    def __init__(self, config_dir: Path, client_secrets_path: Optional[Path] = None) -> None:
        """Initialize client.

        Args:
            config_dir: Directory with credentials (e.g., ~/.remind/plugins/google-tasks/).
            client_secrets_path: Path to client_secrets.json from Google Cloud Console.
        """
        self.config_dir = config_dir
        self.client_secrets_path = client_secrets_path
        self._service = None

    def _get_service(self):
        """Lazily initialize the Google Tasks service."""
        if self._service is None:
            creds = get_google_credentials(self.config_dir, self.client_secrets_path)
            self._service = build("tasks", "v1", credentials=creds)
        return self._service

    def list_task_lists(self) -> list[dict]:
        """Get all task lists.

        Returns:
            List of task list dicts with 'id', 'title' keys.
        """
        service = self._get_service()
        results = service.tasklists().list(maxResults=10).execute()
        return results.get("items", [])

    def create_task_list(self, title: str) -> str:
        """Create a new task list.

        Args:
            title: Name of the task list.

        Returns:
            ID of the created task list.
        """
        service = self._get_service()
        task_list = {"title": title}
        result = service.tasklists().insert(body=task_list).execute()
        return result["id"]

    def insert_task(self, task_list_id: str, title: str, notes: Optional[str] = None) -> str:
        """Insert a new task.

        Args:
            task_list_id: ID of the task list.
            title: Task title.
            notes: Optional task notes/description.

        Returns:
            ID of the created task.
        """
        service = self._get_service()
        task = {"title": title}
        if notes:
            task["notes"] = notes

        result = service.tasks().insert(tasklist=task_list_id, body=task).execute()
        return result["id"]

    def update_task(
        self, task_list_id: str, task_id: str, completed: bool = False
    ) -> None:
        """Update a task's status.

        Args:
            task_list_id: ID of the task list.
            task_id: ID of the task to update.
            completed: Whether the task is completed.
        """
        service = self._get_service()
        task = {"id": task_id, "status": "completed" if completed else "needsAction"}
        service.tasks().update(tasklist=task_list_id, task=task_id, body=task).execute()

    def delete_task(self, task_list_id: str, task_id: str) -> None:
        """Delete a task.

        Args:
            task_list_id: ID of the task list.
            task_id: ID of the task to delete.
        """
        service = self._get_service()
        service.tasks().delete(tasklist=task_list_id, task=task_id).execute()
