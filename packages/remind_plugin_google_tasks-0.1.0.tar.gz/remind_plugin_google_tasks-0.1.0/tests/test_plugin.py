"""Tests for Google Tasks plugin."""

import json
from unittest.mock import MagicMock, patch

import pytest

from remind_plugin_google_tasks import GoogleTasksPlugin
from remind_plugin_base import Reminder


@pytest.fixture
def plugin():
    """Provide a plugin instance."""
    return GoogleTasksPlugin()


@pytest.fixture
def config_dir(tmp_path):
    """Provide a temporary config directory."""
    return tmp_path


def test_plugin_metadata():
    """Test plugin metadata."""
    plugin = GoogleTasksPlugin()
    assert plugin.name == "google-tasks"
    assert plugin.display_name == "Google Tasks"
    assert plugin.version == "0.1.0"


def test_is_configured_false_when_no_files(plugin, config_dir):
    """Test is_configured returns False when credentials don't exist."""
    assert not plugin.is_configured(config_dir)


def test_is_configured_true_when_files_exist(plugin, config_dir):
    """Test is_configured returns True when credentials and config exist."""
    (config_dir / "credentials.json").write_text("{}")
    (config_dir / "config.json").write_text("{}")
    assert plugin.is_configured(config_dir)


def test_status_not_configured(plugin, config_dir):
    """Test status when not configured."""
    status = plugin.status(config_dir)
    assert status == "Not configured"


def test_status_configured(plugin, config_dir):
    """Test status when configured."""
    (config_dir / "credentials.json").write_text("{}")
    config = {"task_list_id": "test-list", "task_list_name": "My Tasks"}
    (config_dir / "config.json").write_text(json.dumps(config))

    status = plugin.status(config_dir)
    assert "My Tasks" in status
    assert "Authenticated" in status


def test_teardown_removes_files(plugin, config_dir):
    """Test teardown removes config files."""
    (config_dir / "credentials.json").write_text("{}")
    (config_dir / "config.json").write_text("{}")

    plugin.teardown(config_dir)

    assert not (config_dir / "credentials.json").exists()
    assert not (config_dir / "config.json").exists()


def test_on_reminder_created_creates_task(plugin, config_dir):
    """Test on_reminder_created syncs to Google Tasks."""
    config = {"task_list_id": "test-list", "task_list_name": "My Tasks"}
    (config_dir / "config.json").write_text(json.dumps(config))
    (config_dir / "credentials.json").write_text("{}")

    reminder = Reminder(
        id=1,
        text="Buy groceries",
        due_date="2025-02-18T17:00:00",
        is_done=False,
    )

    with patch("remind_plugin_google_tasks.plugin.GoogleTasksClient") as mock_client:
        mock_instance = MagicMock()
        mock_client.return_value = mock_instance

        plugin.on_reminder_created(reminder, config_dir)

        mock_instance.insert_task.assert_called_once()
        call_args = mock_instance.insert_task.call_args
        assert call_args[0][0] == "test-list"
        assert call_args[0][1] == "Buy groceries"
        assert "2025-02-18T17:00:00" in call_args[0][2]


def test_on_reminder_hooks_dont_error(plugin, config_dir):
    """Test reminder hooks don't raise errors."""
    reminder = Reminder(id=1, text="Test", is_done=False)

    # Should not raise
    plugin.on_reminder_due(reminder, config_dir)
    plugin.on_reminder_done(reminder, config_dir)
