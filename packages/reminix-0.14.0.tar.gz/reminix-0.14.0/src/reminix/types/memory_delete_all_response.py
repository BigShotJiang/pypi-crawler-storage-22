# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["MemoryDeleteAllResponse"]


class MemoryDeleteAllResponse(BaseModel):
    deleted: float
    """Number of memories deleted"""
