"""Pytest configuration and fixtures."""


# Add shared fixtures here as needed
