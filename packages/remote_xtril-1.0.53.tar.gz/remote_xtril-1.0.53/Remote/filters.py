from pyrogram.filters import Filter
from pyrogram import filters
from .config import config
admin_filter: Filter = filters.create(
    lambda _, __, m: bool(getattr(m, "from_user", None)) and int(m.from_user.id) in config["admin"]
)
owner_filter = filters.create(
    lambda _, __, m: bool(getattr(m, "from_user", None)) and int(m.from_user.id) in config["owner"]
)
admin_or_owner_filter = filters.create(
    lambda _, __, m: bool(getattr(m, "from_user", None)) and 
    (int(m.from_user.id) in config["admin"] or int(m.from_user.id) in config["owner"])
)
