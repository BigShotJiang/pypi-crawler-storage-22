import uuid
import os
import logging
import time
import random
import asyncio
from ..systems.session_manger import SessionManager
from ..inline_buttons.account import get_back_to_account_menu_inline_keyboard
from ..systems.state_manger import StateManager
from ..systems.operation_manager import OperationManager
from ..systems.floodwait_manger import FloodWaitManager
from ..systems.spam_manger import SpamManager
from ..config import config
from pyrogram import errors, Client

# Initialize managers
operation_manager = OperationManager()
state_handler = StateManager() 
session_manager = SessionManager()
flood_manager = FloodWaitManager()
spam_manager = SpamManager()

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/func.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def get_app_info():
    """برمی‌گرداند: [api_hash, api_id]"""
    try:
        apis = {
            1: ['debac98afc137d3a82df5454f345bf02', 23523087],
            2: ['b86bbf4b700b4e922fff2c05b3b8985f', 17221354],
            3: ['2345124333c84e4f72441606a08e882c', 21831682],
            4: ['1ebc2808ef58a95bc796590151c3e0d5', 14742007],
            5: ['b8eff20a7e8adcdaa3daa3bc789a5b41', 12176206]
        }
        return apis[random.randint(1, 5)]
    except Exception as e:
        logger.error(f'Error reading app info: {e}')
        return []

def generate_operation_id():
    return str(uuid.uuid4())[:8]

def get_texts():
    try:
        lines = random.choice([config["texts"]])
        if config["caption"]:
            lines += f"\n{config['caption']}"
        return lines
    except Exception as e:
        logger.error(f"Error reading texts: {e}")
        return []

def get_accounts():
    return session_manager.get_all_sessions()

# Core client operations
async def safe_client_operation(account, operation, *args, operation_type="unknown"):
    """Perform client operations safely with flood control"""
    api_hash, api_id = get_app_info()
    session_string = session_manager.load_session(account)
    if not session_string:
        logger.error(f"No session string for {account}")
        return None
    
    try:
        async with Client(f"sessions/{account}", session_string=session_string,
                        api_id=int(api_id), api_hash=api_hash,workers=8) as client:
            return await flood_manager.safe_operation(
                client, operation, *args, operation_type=operation_type
            )
    except Exception as e:
        logger.error(f"Error in client operation for {account}: {e}")
        return None

# Account management functions
async def show_accounts(callback_query):
    accounts = get_accounts()
    if not accounts:
        await callback_query.message.edit_text(
            "❌ No Account available",
            reply_markup=get_back_to_account_menu_inline_keyboard(),
            reply_to_message_id=callback_query.message.id
            
        )
        return
    
    accounts_text = "**Account List:**\n\n"
    for i, account in enumerate(accounts, 1):
        accounts_text += f"**{i}.** `{account}`\n"
    
    await callback_query.message.edit_text(
        accounts_text,
        reply_markup=get_back_to_account_menu_inline_keyboard(),
        reply_to_message_id=callback_query.message.id
    )

async def add_account_phone(message, phone_number):
    user_id = message.from_user.id
    
    if not phone_number.startswith('+'):
        await message.reply_text("❌ Phone number must start with +!", 
                                reply_to_message_id=message.id)
        return
    
    if phone_number in get_accounts():
        await message.reply_text("❌ This number is already added!", 
                                reply_to_message_id=message.id)
        return
    
    api_hash, api_id = get_app_info()
    
    try:
        # Create session name (without .session extension in client name)
        session_name = phone_number.replace('+', '').strip()
        
        # Store login data BEFORE creating client
        login_data = {
            'phone_number': phone_number,
            'api_id': api_id,
            'api_hash': api_hash,
            'client_name': session_name,
            'start_time': time.time()  # Track when code was sent
        }
        
        # Create client WITHOUT connecting yet
        client = Client(
            name=f"sessions/{session_name}",
            api_id=int(api_id), 
            api_hash=api_hash,
            workers=8
        )
        
        # Connect and send code
        await client.connect()
        sent_code = await client.send_code(phone_number)
        
        # Update login data with code hash
        login_data.update({
            'phone_code_hash': sent_code.phone_code_hash,
            'client_instance': client  # Keep client alive!
        })
        
        # Save login session
        state_handler.set_login_session(user_id, login_data)
        
        logger.info(f"Code sent to {phone_number} at {time.time()}")
        
        await message.reply_text(
            "✅ Verification code sent! Please send the code within 2 minutes:",
            reply_to_message_id=message.id
        )
        state_handler.set_state(user_id, 'waiting_code')
        
    except errors.PhoneNumberInvalid:
        await message.reply_text("❌ Invalid phone number!",
                                reply_to_message_id=message.id)
    except errors.PhoneNumberFlood:
        await message.reply_text("❌ This number is in Flood state!",
                                reply_to_message_id=message.id)
    except Exception as e:
        logger.error(f"Error sending code to {phone_number}: {e}")
        await message.reply_text(f"❌ Error sending code: {str(e)}",
                                reply_to_message_id=message.id)
        # Clean up if client was created
        if 'client' in locals():
            await client.disconnect()

async def verify_code(message, code):
    user_id = message.from_user.id
    session_data = state_handler.get_login_session(user_id)
    
    if not session_data:
        await message.reply_text("❌ Login session not found!",
                                reply_to_message_id=message.id)
        return
    
    # Check if code is expired (more than 120 seconds)
    if time.time() - session_data.get('start_time', 0) > 120:
        await message.reply_text("❌ Verification code expired! Please restart the process.",
                                reply_to_message_id=message.id)
        # Clean up
        if 'client_instance' in session_data:
            await session_data['client_instance'].disconnect()
        state_handler.clear_login_session(user_id)
        return
    
    client = session_data.get('client_instance')
    if not client:
        await message.reply_text("❌ Client connection lost! Please restart.",
                                reply_to_message_id=message.id)
        state_handler.clear_login_session(user_id)
        return
    
    try:
        # Sign in with the SAME client instance
        await client.sign_in(
            session_data['phone_number'],
            session_data['phone_code_hash'],
            code
        )
        
        # Get session string
        session_string = await client.export_session_string()
        
        # Save session
        if session_manager.save_session(session_data['phone_number'], session_string):
            await message.reply_text("✅ Account added successfully!",
                                    reply_to_message_id=message.id)
        else:
            await message.reply_text("❌ Error saving session!",
                                    reply_to_message_id=message.id)
        
        # Disconnect and clean up
        await client.disconnect()
        state_handler.clear_login_session(user_id)
        
    except errors.SessionPasswordNeeded: 
        # Store client for password verification
        state_handler.set_state(user_id, 'waiting_password')
        
        await message.reply_text(
            "🔐 This account has 2FA password! Please send the password:",
            reply_to_message_id=message.id
        )
        # Don't disconnect client yet - keep it for password check
        
    except errors.PhoneCodeInvalid:
        await message.reply_text("❌ Invalid verification code!",
                                reply_to_message_id=message.id)
        await client.disconnect()
        state_handler.clear_login_session(user_id)
    
    except errors.PhoneCodeExpired:
        await message.reply_text("❌ Verification code expired! Please restart.",
                                reply_to_message_id=message.id)
        await client.disconnect()
        state_handler.clear_login_session(user_id)
    
    except Exception as e:
        logger.error(f"Error verifying code: {e}")
        await message.reply_text(f"❌ Error verifying code: {str(e)}",
                                reply_to_message_id=message.id)
        # Clean up
        if client:
            await client.disconnect()
        state_handler.clear_login_session(user_id)

async def verify_password(message, password):
    user_id = message.from_user.id
    session_data = state_handler.get_login_session(user_id)
    
    if not session_data:
        await message.reply_text("❌ Login session not found!",
                                reply_to_message_id=message.id)
        return
    
    client = session_data.get('client_instance')
    if not client:
        await message.reply_text("❌ Client connection lost! Please restart.",
                                reply_to_message_id=message.id)
        state_handler.clear_login_session(user_id)
        return
    
    try:
        # Check 2FA password
        await client.check_password(password)
        
        # Get session string
        session_string = await client.export_session_string()
        
        # Save session
        if session_manager.save_session(session_data['phone_number'], session_string):
            await message.reply_text("✅ Account added successfully!",
                                    reply_to_message_id=message.id)
        else:
            await message.reply_text("❌ Error saving session!",
                                    reply_to_message_id=message.id)
        
        # Disconnect and clean up
        await client.disconnect()
        state_handler.clear_login_session(user_id)
        
    except errors.PasswordHashInvalid:
        await message.reply_text("❌ Invalid 2FA password! Try again:",
                                reply_to_message_id=message.id)
        # Keep client alive for retry
    
    except Exception as e:
        logger.error(f"Error verifying password: {e}")
        await message.reply_text(f"❌ Error verifying password: {str(e)}",
                                reply_to_message_id=message.id)
        # Clean up
        if client:
            await client.disconnect()
        state_handler.clear_login_session(user_id)
        
        
async def delete_account(message, phone_number):
    if session_manager.delete_session(phone_number):
        await message.reply_text("✅ Account deleted successfully!",
                                reply_to_message_id=message.id)
    else:
        await message.reply_text("❌ This number is not in the account list!",
                                reply_to_message_id=message.id)

# Profile management functions
async def change_first_name(message, first_name):
    accounts = get_accounts()
    if not accounts:
        await message.reply_text(
            "❌ No accounts available to change name!",
            reply_to_message_id=message.id
        )
        return
    
    operation_id = generate_operation_id()
    operation_manager.start_operation(operation_id, "Change Name", len(accounts))
    
    success_count = 0
    total = len(accounts)
    
    progress_msg = await message.reply_text(
        f"✏️ **Changing Profile Names**\n\n"
        f"📊 Progress: 0/{total} accounts\n"
        f"✅ Success: 0 | ❌ Failed: 0",
        reply_to_message_id=message.id
    )
    
    for i, account in enumerate(accounts):
        try:
            # راه حل: مستقیم کار را انجام دهیم بدون safe_client_operation
            api_hash, api_id = get_app_info()
            session_string = session_manager.load_session(account)
            
            if not session_string:
                logger.error(f"No session string for {account}")
                operation_manager.add_error(operation_id, f"❌ {account}: No session")
                continue
            
            async with Client(f"sessions/{account}", 
                            session_string=session_string,
                            api_id=int(api_id), 
                            api_hash=api_hash,
                            workers=8) as client:
                
                # به صورت مستقیم تغییر نام بده
                try:
                    await client.update_profile(first_name=first_name)
                    success_count += 1
                    operation_manager.update_progress(
                        operation_id, i + 1, f"✅ {account}: Name changed"
                    )
                    logger.info(f"Changed name for {account}")
                except Exception as e:
                    operation_manager.add_error(
                        operation_id, f"❌ {account}: {str(e)[:100]}"
                    )
                    logger.error(f"Error changing name for {account}: {e}")
        
        except Exception as e:
            logger.error(f"General error for {account}: {e}")
            operation_manager.add_error(
                operation_id, f"❌ {account}: Connection error"
            )
        
        # Update progress
        if i % 5 == 0 or i == total - 1:
            await progress_msg.edit_text(
                f"✏️ **Changing Profile Names**\n\n"
                f"📊 Progress: {i+1}/{total} accounts\n"
                f"✅ Success: {success_count} | ❌ Failed: {i + 1 - success_count}\n\n"
                f"⏳ Current: `{account}`"
            )
        
        await asyncio.sleep(1)
    
    operation_manager.complete_operation(
        operation_id, 
        f"✅ Name changed for {success_count} out of {total} accounts!"
    )
    
    await progress_msg.edit_text(
        f"✨ **Operation Complete**\n\n"
        f"✏️ Profile names updated for {success_count}/{total} accounts\n"
        f"📅 {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        f"📈 **Success Rate:** {success_count/total*100:.1f}%"
    )
        


async def set_profile_photo(message):
    try:
        # Check if message has photo
        if not message.reply_to_message or not message.reply_to_message.photo:
            await message.reply_text(
                "❌ Please reply to a photo message!",
                reply_to_message_id=message.id
            )
            return
        
        # Create temp directory if it doesn't exist
        os.makedirs('temp', exist_ok=True)
        
        # Create unique filename
        unique_name = f"temp/profile_photo_{message.from_user.id}_{int(time.time())}.jpg"
        photo_path = await message.reply_to_message.download(file_name=unique_name)
        
        accounts = get_accounts()
        if not accounts:
            await message.reply_text(
                "❌ No accounts available to change photo!",
                reply_to_message_id=message.id
            )
            # Clean up temporary file
            try:
                os.remove(photo_path)
            except:
                pass
            return
        
        operation_id = generate_operation_id()
        operation_manager.start_operation(operation_id, "Change Profile Photo", len(accounts))
        
        success_count = 0
        total = len(accounts)
        
        progress_msg = await message.reply_text(
            f"🖼️ **Changing Profile Photos**\n\n"
            f"📊 Progress: 0/{total} accounts\n"
            f"✅ Success: 0 | ❌ Failed: 0",
            reply_to_message_id=message.id
        )
        
        for i, account in enumerate(accounts):
            try:
                # راه حل مستقیم: بدون safe_client_operation
                api_hash, api_id = get_app_info()
                session_string = session_manager.load_session(account)
                
                if not session_string:
                    logger.error(f"No session string for {account}")
                    operation_manager.add_error(operation_id, f"❌ {account}: No session")
                    continue
                
                async with Client(f"sessions/{account}", 
                                session_string=session_string,
                                api_id=int(api_id), 
                                api_hash=api_hash,
                                workers=8) as client:
                    
                    try:
                        # مستقیماً عکس را تغییر بده
                        await client.set_profile_photo(photo=photo_path)
                        success_count += 1
                        operation_manager.update_progress(
                            operation_id, i + 1, f"✅ {account}: Photo changed"
                        )
                        logger.info(f"Changed profile photo for {account}")
                    except Exception as e:
                        operation_manager.add_error(
                            operation_id, f"❌ {account}: {str(e)[:100]}"
                        )
                        logger.error(f"Error changing photo for {account}: {e}")
            
            except Exception as e:
                logger.error(f"General error for {account}: {e}")
                operation_manager.add_error(
                    operation_id, f"❌ {account}: Connection error"
                )
            
            # Update progress every 3 accounts or at the end
            if i % 3 == 0 or i == total - 1:
                await progress_msg.edit_text(
                    f"🖼️ **Changing Profile Photos**\n\n"
                    f"📊 Progress: {i+1}/{total} accounts\n"
                    f"✅ Success: {success_count} | ❌ Failed: {i + 1 - success_count}\n\n"
                    f"⏳ Current: `{account}`"
                )
            
            # Delay between operations to avoid rate limits
            await asyncio.sleep(3)
        
        # Clean up temporary file after all operations
        try:
            if os.path.exists(photo_path):
                os.remove(photo_path)
                logger.info(f"Deleted temporary file: {photo_path}")
        except Exception as e:
            logger.warning(f"Could not delete temp file {photo_path}: {e}")
        
        # Try to clean up temp directory if empty
        try:
            if os.path.exists('temp') and not os.listdir('temp'):
                os.rmdir('temp')
        except:
            pass
        
        # Final operation completion
        operation_manager.complete_operation(
            operation_id, 
            f"✅ Photo changed for {success_count} out of {total} accounts!"
        )
        
        await progress_msg.edit_text(
            f"✨ **Operation Complete**\n\n"
            f"🖼️ Profile photos updated for {success_count}/{total} accounts\n"
            f"📅 {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            f"🎯 **Success Rate:** {success_count/total*100:.1f}%"
        )
        
    except Exception as e:
        logger.error(f"Error in set_profile_photo: {e}")
        await message.reply_text(
            f"❌ **Error Changing Photo**\n\n`{str(e)[:150]}`",
            reply_to_message_id=message.id
        )
        
        # Clean up temporary file in case of error
        try:
            if 'photo_path' in locals() and 'photo_path' in locals() and os.path.exists(photo_path):
                os.remove(photo_path)
                logger.info(f"Cleaned up temp file after error: {photo_path}")
        except:
            pass

async def join_chat(message, chat_link):
    """
    Join a group/channel with all accounts
    """
    from pyrogram import errors
    
    try:
        accounts = get_accounts()
        if not accounts:
            await message.reply_text(
                "❌ No accounts available to join group!",
                reply_to_message_id=message.id
            )
            return
        
        operation_id = generate_operation_id()
        operation_manager.start_operation(operation_id, "Join Group", len(accounts))
        
        success_count = 0
        total = len(accounts)
        
        progress_msg = await message.reply_text(
            f"🔗 **Joining Group**\n\n"
            f"📊 Progress: 0/{total} accounts\n"
            f"✅ Success: 0 | ❌ Failed: 0\n\n"
            f"🎯 Target: `{chat_link}`",
            reply_to_message_id=message.id
        )
        
        api_hash, api_id = get_app_info()
        
        for i, account in enumerate(accounts):
            try:
                session_string = session_manager.load_session(account)
                
                if not session_string:
                    operation_manager.add_error(operation_id, f"❌ {account}: No session")
                    continue
                
                async with Client(
                    f"sessions/{account}",
                    session_string=session_string,
                    api_id=int(api_id),
                    api_hash=api_hash,
                    workers=8
                ) as client:
                    
                    try:
                        await client.join_chat(chat_link)
                        success_count += 1
                        operation_manager.update_progress(
                            operation_id, i + 1, f"✅ {account}: Joined successfully"
                        )
                        logger.info(f"{account}: Joined {chat_link}")
                        
                    except errors.UserAlreadyParticipant:
                        success_count += 1
                        operation_manager.update_progress(
                            operation_id, i + 1, f"✅ {account}: Already a member"
                        )
                        logger.info(f"{account}: Already in group {chat_link}")
                        
                    except errors.InviteRequestSent:
                        success_count += 1
                        operation_manager.update_progress(
                            operation_id, i + 1, f"✅ {account}: Request sent"
                        )
                        logger.info(f"{account}: Join request sent to {chat_link}")
                        
                    except errors.FloodWait as e:
                        error_msg = f"❌ {account}: Flood wait {e.value} seconds"
                        operation_manager.add_error(operation_id, error_msg)
                        logger.warning(f"{account}: Flood wait for {chat_link}: {e.value}s")
                        
                    except errors.ChannelInvalid:
                        error_msg = f"❌ {account}: Invalid channel/link"
                        operation_manager.add_error(operation_id, error_msg)
                        logger.error(f"{account}: Invalid chat link: {chat_link}")
                        
                    except errors.UsernameNotOccupied:
                        error_msg = f"❌ {account}: Username not found"
                        operation_manager.add_error(operation_id, error_msg)
                        logger.error(f"{account}: Username not found: {chat_link}")
                        
                    except Exception as e:
                        error_msg = f"❌ {account}: {str(e)[:80]}"
                        operation_manager.add_error(operation_id, error_msg)
                        logger.error(f"Error joining {account} to {chat_link}: {e}")
            
            except Exception as e:
                error_msg = f"❌ {account}: Connection error - {str(e)[:80]}"
                operation_manager.add_error(operation_id, error_msg)
                logger.error(f"Connection error for {account}: {e}")
            
            # Update progress
            if i % 3 == 0 or i == total - 1:
                await progress_msg.edit_text(
                    f"🔗 **Joining Group**\n\n"
                    f"📊 Progress: {i+1}/{total} accounts\n"
                    f"✅ Success: {success_count} | ❌ Failed: {i + 1 - success_count}\n\n"
                    f"🎯 Target: `{chat_link}`\n"
                    f"⏳ Current: `{account}`"
                )
            
            # Delay between accounts
            await asyncio.sleep(10)
        
        # Final report
        operation_manager.complete_operation(
            operation_id,
            f"✅ {success_count} out of {total} accounts joined {chat_link}!"
        )
        
        await progress_msg.edit_text(
            f"✨ **Group Join Complete**\n\n"
            f"🔗 Target: `{chat_link}`\n"
            f"👥 Accounts: {success_count}/{total} joined\n"
            f"📅 {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            f"📈 **Success Rate:** {success_count/total*100:.1f}%\n\n"
            f"🔸 Already members: {success_count - (total - len(accounts))}"
        )
        
    except Exception as e:
        logger.error(f"Error in join_chat: {e}")
        await message.reply_text(
            f"❌ **Error joining group**\n\n`{str(e)[:150]}`",
            reply_to_message_id=message.id
        )
        
async def leave_chat(message, chat_input):
    """
    Leave a group/channel with all accounts
    """
    from pyrogram import errors
    
    try:
        accounts = get_accounts()
        if not accounts:
            await message.reply_text(
                "❌ No accounts available to leave group!",
                reply_to_message_id=message.id
            )
            return
        
        # Clean and validate chat input
        chat_input = chat_input.strip()
        
        # Try to extract chat ID from various formats
        chat_id = None
        
        # Check if it's a direct chat ID
        try:
            # Remove @ if present
            if chat_input.startswith('@'):
                chat_id = chat_input[1:]  # Remove @ for username
            elif chat_input.startswith('-100'):
                chat_id = int(chat_input)
            else:
                # Try to convert to int
                chat_id = int(chat_input)
        except ValueError:
            # If not a number, treat as username/link
            chat_id = chat_input
        
        operation_id = generate_operation_id()
        operation_manager.start_operation(operation_id, "Leave Group", len(accounts))
        
        success_count = 0
        total = len(accounts)
        
        progress_msg = await message.reply_text(
            f"🚪 **Leaving Chat**\n\n"
            f"📊 Progress: 0/{total} accounts\n"
            f"✅ Success: 0 | ❌ Failed: 0\n\n"
            f"🎯 Target: `{chat_id}`",
            reply_to_message_id=message.id
        )
        
        api_hash, api_id = get_app_info()
        
        for i, account in enumerate(accounts):
            try:
                session_string = session_manager.load_session(account)
                
                if not session_string:
                    operation_manager.add_error(operation_id, f"❌ {account}: No session")
                    continue
                
                async with Client(
                    f"sessions/{account}",
                    session_string=session_string,
                    api_id=int(api_id),
                    api_hash=api_hash,
                    workers=8
                ) as client:
                    
                    try:
                        await client.leave_chat(chat_id)
                        success_count += 1
                        operation_manager.update_progress(
                            operation_id, i + 1, f"✅ {account}: Left successfully"
                        )
                        logger.info(f"{account}: Left chat {chat_id}")
                        
                    except errors.UserNotParticipant:
                        success_count += 1
                        operation_manager.update_progress(
                            operation_id, i + 1, f"✅ {account}: Not a member"
                        )
                        logger.info(f"{account}: Not in chat {chat_id}")
                        
                    except errors.ChannelInvalid:
                        error_msg = f"❌ {account}: Invalid chat/channel"
                        operation_manager.add_error(operation_id, error_msg)
                        logger.error(f"{account}: Invalid chat: {chat_id}")
                        
                    except errors.ChatAdminRequired:
                        error_msg = f"❌ {account}: Admin required to leave"
                        operation_manager.add_error(operation_id, error_msg)
                        logger.warning(f"{account}: Admin required for {chat_id}")
                        
                    except errors.FloodWait as e:
                        error_msg = f"❌ {account}: Flood wait {e.value} seconds"
                        operation_manager.add_error(operation_id, error_msg)
                        logger.warning(f"{account}: Flood wait for {chat_id}: {e.value}s")
                        
                    except Exception as e:
                        error_msg = f"❌ {account}: {str(e)[:80]}"
                        operation_manager.add_error(operation_id, error_msg)
                        logger.error(f"Error leaving {account} from {chat_id}: {e}")
            
            except Exception as e:
                error_msg = f"❌ {account}: Connection error - {str(e)[:80]}"
                operation_manager.add_error(operation_id, error_msg)
                logger.error(f"Connection error for {account}: {e}")
            
            # Update progress
            if i % 3 == 0 or i == total - 1:
                await progress_msg.edit_text(
                    f"🚪 **Leaving Chat**\n\n"
                    f"📊 Progress: {i+1}/{total} accounts\n"
                    f"✅ Success: {success_count} | ❌ Failed: {i + 1 - success_count}\n\n"
                    f"🎯 Target: `{chat_id}`\n"
                    f"⏳ Current: `{account}`"
                )
            
            # Delay between accounts
            await asyncio.sleep(10)
        
        # Final report
        operation_manager.complete_operation(
            operation_id,
            f"✅ {success_count} out of {total} accounts left chat {chat_id}!"
        )
        
        await progress_msg.edit_text(
            f"✨ **Leave Chat Complete**\n\n"
            f"🚪 Target: `{chat_id}`\n"
            f"👥 Accounts: {success_count}/{total} processed\n"
            f"📅 {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            f"📈 **Success Rate:** {success_count/total*100:.1f}%\n\n"
            f"🔸 *Includes accounts that were not members*"
        )
        
    except Exception as e:
        logger.error(f"Error in leave_chat: {e}")
        await message.reply_text(
            f"❌ **Error leaving chat**\n\n`{str(e)[:150]}`",
            reply_to_message_id=message.id
        )
# Spam operations
# async def start_spam(message):
#     accounts = get_accounts()
#     if not accounts:
#         await message.reply_text("❌ No accounts available for spam!",
#                                 reply_to_message_id=message.id)
#         return
    
#     texts = get_texts()
#     if not texts:
#         await message.reply_text("❌ No texts available for spam!",
#                                 reply_to_message_id=message.id)
#         return
    
#     try:
#         chat_id_int = config["chat"]
#     except ValueError:
#         await message.reply_text("❌ Chat ID must be a number!",
#                                 reply_to_message_id=message.id)
#         return
    
#     operation_data = {
#         'chat_id': chat_id_int,
#         'accounts': accounts,
#         'texts': texts,
#         'delay': config['speed']
#     }
    
#     spam_manager.start_spam_operation(message.chat.id, operation_data)
#     await message.reply_text("✅ Spammer started working!",
#                             reply_to_message_id=message.id)
#     asyncio.create_task(run_spam_operation(message.chat.id))

async def start_spam(message):
    accounts = get_accounts()
    if not accounts:
        await message.reply_text("❌ No accounts available for spam!",
                                reply_to_message_id=message.id)
        return
    
    texts = get_texts()
    if not texts:
        await message.reply_text("❌ No texts available for spam!",
                                reply_to_message_id=message.id)
        return
    
    try:
        chat_id_int = int(config["chat"])  # Convert chat ID to integer
    except (ValueError, KeyError):
        await message.reply_text("❌ Chat ID must be a valid number!",
                                reply_to_message_id=message.id)
        return
    
    operation_data = {
        'chat_id': chat_id_int,
        'accounts': accounts,
        'texts': texts,
        'delay': config.get('speed', 3)  # Default speed 3 if not provided
    }
    
    spam_manager.start_spam_operation(message.chat.id, operation_data)
    await message.reply_text("✅ Spammer started working!",
                            reply_to_message_id=message.id)
    asyncio.create_task(run_spam_operation(message.chat.id))

async def run_spam_operation(chat_id):
    while spam_manager.is_spam_active(chat_id):
        operation = spam_manager.get_spam_operation(chat_id)
        if not operation or not operation['accounts'] or not operation['texts']:
            break
        
        account_index = spam_manager.get_next_account_index(chat_id)
        account = operation['accounts'][account_index]
        text = random.choice(operation['texts'])
        
        await safe_client_operation(
            account,
            lambda client, cid, txt: client.send_message(cid, txt),
            operation['chat_id'], text,
            operation_type="send_message"
        )
        
        await time.sleep(operation['delay'])
        
async def stop_spam_handler(message, cmd):
    if cmd.lower() == "yes":
        spam_manager.stop_spam_operation(message.chat.id)
        await message.reply_text("✅ Spam stopped successfully!",
                                reply_to_message_id=message.id)
    else:
        await message.reply_text("❌ Current operation cancelled.",
                                reply_to_message_id=message.id)

async def changed_time_sleep(message, speed):
    try: 
        if int(speed) >= 1:
            config["speed"] = speed
            await message.reply(f"✅ Spam speed set to {speed}.",
                              reply_to_message_id=message.id) 
        else:
            await message.reply("Minimum speed: 1",
                              reply_to_message_id=message.id)
    except ValueError:
        await message.reply("⚠️ Please enter a number.",
                          reply_to_message_id=message.id)
    return True

async def handle_add_text(message, text): 
    config["texts"].append(text)
    await message.reply("✅ Text saved.",
                       reply_to_message_id=message.id) 
    return True

async def handle_delete_text(message, cmd): 
    if cmd.lower() == "yes":
        config["texts"].clear()
        await message.reply("✅ Text list has been cleared.",
                          reply_to_message_id=message.id)  
    else:
        await message.reply("❌ Current operation cancelled.",
                          reply_to_message_id=message.id)  
    return True

async def handle_add_caption(message, caption):
    config["caption"] = caption
    await message.reply("✅ Caption saved.",
                       reply_to_message_id=message.id)
    return True

async def handle_delete_caption(message, cmd): 
    if cmd.lower() == "yes":
        config["caption"] = ""
        await message.reply("✅ Caption deleted.",
                          reply_to_message_id=message.id)
    else:
        await message.reply("❌ Current operation cancelled.",
                          reply_to_message_id=message.id)        
    return True

async def handle_add_target(message, link): 
    if not get_accounts():
        await message.reply("No accounts available!",
                          reply_to_message_id=message.id)
        return
    
    accounts = get_accounts()
    account = random.choice(accounts)
    
    try:
        api_hash, api_id = get_app_info()
        session_string = session_manager.load_session(account)
        
        if not session_string:
            await message.reply("❌ Session not found for selected account.",
                              reply_to_message_id=message.id)
            return
        
        async with Client(f"sessions/{account}", session_string=session_string,
                         api_id=int(api_id), api_hash=api_hash, workers=8) as client:
            chat = await client.get_chat(link)
            config["chat"].append(chat.id)
            await message.reply(f"✅ Target added successfully: {chat.id}",
                              reply_to_message_id=message.id)
    except Exception as e:
        await message.reply(f"❌ Error adding target: {str(e)}",
                          reply_to_message_id=message.id)
        logger.error(f"Error adding target: {e}")
    
    return True

async def handle_remove_target(message, chat_id):
    try: 
        # Convert chat_id to integer if it's a string
        try:
            chat_id_int = int(chat_id)
            if chat_id_int in config["chat"]:
                config["chat"].remove(chat_id_int)
                await message.reply("✅ Target removed successfully.",
                                  reply_to_message_id=message.id)
            else:
                await message.reply("❌ Target not found in list.",
                                  reply_to_message_id=message.id)
        except ValueError:
            # If chat_id is already an integer in the list
            if chat_id in config["chat"]:
                config["chat"].remove(chat_id)
                await message.reply("✅ Target removed successfully.",
                                  reply_to_message_id=message.id)
            else:
                await message.reply("❌ Target not found in list.",
                                  reply_to_message_id=message.id)
    except Exception as e:
        await message.reply(f"❌ Error removing target: {str(e)}",
                          reply_to_message_id=message.id)
        logger.error(f"Error removing target: {e}")
    
    return True