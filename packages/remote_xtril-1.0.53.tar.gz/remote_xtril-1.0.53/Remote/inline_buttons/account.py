from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message

def get_account_menu_inline_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [ 
            InlineKeyboardButton("📱 Add Account", callback_data="add_account_data"),
            InlineKeyboardButton("🗑 Delete Account", callback_data="delete_account_data"), 
        ],
        [
            InlineKeyboardButton("📋 Account List", callback_data="list_account_data")
        ],
        [
            InlineKeyboardButton("🖼 Profile Photo", callback_data="profile_photo_data"),
        ],
        [
            InlineKeyboardButton("✏️ Profile Name", callback_data="profile_name_data")
        ],
        [
            InlineKeyboardButton("➕ Join Group", callback_data="join_group_data"),
            InlineKeyboardButton("➡️ Leave Group", callback_data="leave_group_data")
        ],
        [ 
            InlineKeyboardButton("🔙 Back to Main", callback_data="back_main_data")
        ], 
    ])

def get_set_code_pass_menu_inline_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [ 
            InlineKeyboardButton("🔢 Send Verification Code", callback_data="set_code_account_data"),
            InlineKeyboardButton("🔐 Send 2FA Password", callback_data="set_pass_account_data")
        ],
        [ 
            InlineKeyboardButton("↩️ Back", callback_data="back_account_data")
        ], 
    ])

def get_back_to_set_code_pass_menu_inline_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [ 
            InlineKeyboardButton("◀️ Back", callback_data="back_set_code_pass_data")
        ], 
    ])
    
def get_back_to_account_menu_inline_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [ 
            InlineKeyboardButton("📂 Back to Account Menu", callback_data="back_account_data")
        ], 
    ])