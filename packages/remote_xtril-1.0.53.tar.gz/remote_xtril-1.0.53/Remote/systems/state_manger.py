import threading , logging , asyncio , time
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/StateManager.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)
class StateManager:
    def __init__(self):
        self.operation_states = {}
        self.login_sessions = {}
        self.lock = threading.Lock()
        self.cleanup_task = None
    
    def set_state(self, user_id, state, data=None):
        with self.lock:
            self.operation_states[user_id] = {
                'state': state,
                'data': data or {},
                'timestamp': time.time()
            }
    
    def get_state(self, user_id):
        with self.lock:
            state_data = self.operation_states.get(user_id)
            if state_data:
                # آپدیت timestamp برای جلوگیری از timeout زودهنگام
                state_data['timestamp'] = time.time()
                return state_data
            return None
    
    def clear_state(self, user_id):
        with self.lock:
            self.operation_states.pop(user_id, None)
    
    def set_login_session(self, user_id, session_data):
        with self.lock:
            self.login_sessions[user_id] = {
                'data': session_data,
                'timestamp': time.time()
            }
    
    def get_login_session(self, user_id):
        with self.lock:
            session_data = self.login_sessions.get(user_id)
            if session_data:
                # آپدیت timestamp
                session_data['timestamp'] = time.time()
                return session_data['data']
            return None
    
    def clear_login_session(self, user_id):
        with self.lock:
            self.login_sessions.pop(user_id, None)
    
    async def start_cleanup(self):
        """شروع تمیزکاری خودکار stateهای منقضی شده"""
        if self.cleanup_task:
            return
        
        async def cleanup_loop():
            while True:
                try:
                    current_time = time.time()
                    with self.lock:
                        # حذف operation_states منقضی شده (10 دقیقه)
                        expired_users = [
                            user_id for user_id, state_data in self.operation_states.items()
                            if current_time - state_data['timestamp'] > 600
                        ]
                        for user_id in expired_users:
                            del self.operation_states[user_id]
                            logger.info(f"Cleaned up expired state for user {user_id}")
                        
                        # حذف login_sessions منقضی شده (15 دقیقه)
                        expired_logins = [
                            user_id for user_id, session_data in self.login_sessions.items()
                            if current_time - session_data['timestamp'] > 900
                        ]
                        for user_id in expired_logins:
                            del self.login_sessions[user_id]
                            logger.info(f"Cleaned up expired login session for user {user_id}")
                    
                    await asyncio.sleep(60)  # بررسی هر 1 دقیقه
                except Exception as e:
                    logger.error(f"Error in state cleanup: {e}")
                    await asyncio.sleep(60)
        
        self.cleanup_task = asyncio.create_task(cleanup_loop())

