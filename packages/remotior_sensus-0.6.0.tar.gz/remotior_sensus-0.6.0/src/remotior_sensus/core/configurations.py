# Remotior Sensus , software to process remote sensing and GIS data.
# Copyright (C) 2022-2026 Luca Congedo.
# Author: Luca Congedo
# Email: ing.congedoluca@gmail.com
#
# This file is part of Remotior Sensus.
# Remotior Sensus is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License,
# or (at your option) any later version.
# Remotior Sensus is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with Remotior Sensus. If not, see <https://www.gnu.org/licenses/>.

"""Configuration module.
Module containing shared variables and parameters across tools.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from remotior_sensus.core.multiprocess_manager import Multiprocess

root_name = 'remotior_sensus'
version = None
# type hint for Multiprocess
multiprocess: Multiprocess
# shared classes
logger = messages = band_calc = band_classification = band_combination = None
band_dilation = band_erosion = band_neighbor_pixels = band_pca = None
band_sieve = None
log_level = None
# shared Temporary class
temp = None
# variable to stop processes
action = True
# variables used in Progress class
progress = None
process = root_name
message = 'starting'
refresh_time = 1.0
# operating system information
sys_64bit = None
file_sys_encoding = None
sys_name = None
# default bandset catalog for applications
default_catalog = None
default_signature_catalog = None
# notification options
sound_notification = None
smtp_notification = None
smtp_server = ''
smtp_user = ''
smtp_password = ''
smtp_recipients = ''
# optional GDAL path
gdal_path = None
# variables used in BandSet class
band_name_suf = '#b'
date_auto = 'auto'
# memory units used in Multiprocess class for calculating block size
memory_unit_array_24 = 0.000024
memory_unit_array_12 = 0.000016
memory_unit_array_8 = 0.000010
memory_unit_array_4 = 0.000006
# number of parallel processes. used for Multiprocess calculations
n_processes = 2
# available RAM that should be used by processes
available_ram = 2048
# parameters for raster files
raster_data_type = 'Float32'
raster_compression = True
raster_compression_format = 'LZW'
# nodata values for data types
nodata_val = -32768
nodata_val_UInt16 = 2 ** 16 - 1
nodata_val_Int32 = 2 ** 32 // 2 - 1
nodata_val_Int64 = -2 ** 64 // 2
nodata_val_Float32 = -340282346638528859811704183484516925440
nodata_val_UInt32 = 2 ** 32 - 1
nodata_val_UInt64 = 2 ** 64 - 1
nodata_val_Byte = 255
# predefined suffixes
csv_suffix = '.csv'
dbf_suffix = '.dbf'
tif_suffix = '.tif'
vrt_suffix = '.vrt'
shp_suffix = '.shp'
gpkg_suffix = '.gpkg'
txt_suffix = '.txt'
xml_suffix = '.xml'
rsmo_suffix = '.rsmo'
scpx_suffix = '.scpx'
# text delimiters
comma_delimiter = ','
tab_delimiter = '\t'
new_line = '\n'
# product variables used for download and preprocessing
# Copernicus Sentinel-2
sentinel2 = 'Sentinel-2'
# NASA CMR Search
# https://cmr.earthdata.nasa.gov/search/site/search_api_docs.html
landsat_hls = 'Landsat_HLS'
landsat_hls_collection = 'C2021957657-CLOUD'
sentinel2_hls = 'Sentinel-2_HLS'
sentinel2_hls_collection = 'C2021957295-LPCLOUD'
landsat = 'Landsat'
sensor_oli = 'oli_tirs'
sensor_etm = 'etm'
sensor_tm = 'tm'
sensor_mss = 'mss'
# Collections from Microsoft Planetary Computer
landsat_mpc = 'Landsat_MPC'
landsat_mpc_collection = 'landsat-c2-l2'
sentinel2_mpc = 'Sentinel-2_MPC'
sentinel2_mpc_collection = 'sentinel-2-l2a'
modis_09q1_mpc = 'MODIS_09Q1_MPC'
modis_09q1_mpc_collection = 'modis-09Q1-061'
modis_11a2_mpc = 'MODIS_11A2_MPC'
modis_11a2_mpc_collection = 'modis-11A2-061'
aster_l1t_mpc = 'ASTER_MPC'
aster_l1t_mpc_collection = 'aster-l1t'
cop_dem_glo_30_mpc = 'Copernicus_DEM_30_MPC'
cop_dem_glo_30_mpc_collection = 'cop-dem-glo-30'
product_description = {
    sentinel2: 'Copernicus Sentinel-2 '
               'https://dataspace.copernicus.eu/explore-data/data-collections/sentinel-data/sentinel-2',  # noqa: E501
    landsat_mpc: 'Landsat Collection from Microsoft Planetary Computer '
                 'https://planetarycomputer.microsoft.com/dataset/group/landsat',  # noqa: E501
    sentinel2_mpc: 'Sentinel-2 Level-2A from Microsoft Planetary Computer '
                   'https://planetarycomputer.microsoft.com/dataset/sentinel-2-l2a',  # noqa: E501
    landsat_hls: 'Landsat from Harmonized Landsat and Sentinel-2 by NASA '
                 'https://hls.gsfc.nasa.gov',
    sentinel2_hls: 'Sentinel-2 from Harmonized Landsat and Sentinel-2 by NASA '
                   'https://hls.gsfc.nasa.gov',
    modis_09q1_mpc: 'MODIS Surface Reflectance 8-Day (250m) from Microsoft '
                    'Planetary Computer https://planetarycomputer.microsoft.com/dataset/modis-09Q1-061',  # noqa: E501
    modis_11a2_mpc: 'MODIS Land Surface Temperature 8-Day from Microsoft '
                    'Planetary Computer https://planetarycomputer.microsoft.com/dataset/modis-11A2-061',  # noqa: E501
    aster_l1t_mpc: 'ASTER L1T from Microsoft Planetary Computer '
                   'https://planetarycomputer.microsoft.com/dataset/aster-l1t',
    cop_dem_glo_30_mpc: 'Copernicus DEM GLO-30 from Microsoft Planetary '
                        'Computer https://planetarycomputer.microsoft.com/dataset/cop-dem-glo-30'  # noqa: E501
}
# satellites bands for center wavelength definition
no_satellite = 'Band order'
satGeoEye1 = 'GeoEye-1 [bands 1, 2, 3, 4]'
satGOES = 'GOES [bands 1, 2, 3, 4, 5, 6]'
satLandsat89 = 'Landsat 8/9 raw [bands 1, 2, 3, 4, 5, 6, 7, 8, 9 , 10, 11]'
satLandsat9 = 'Landsat 9 OLI [bands 1, 2, 3, 4, 5, 6, 7]'
satLandsat8 = 'Landsat 8 OLI [bands 1, 2, 3, 4, 5, 6, 7]'
satLandsat7 = 'Landsat 7 ETM+ [bands 1, 2, 3, 4, 5, 7]'
satLandsat45 = 'Landsat 4-5 TM [bands 1, 2, 3, 4, 5, 7]'
satLandsat13 = 'Landsat 1-3 MSS [bands 4, 5, 6, 7]'
satRapidEye = 'RapidEye [bands 1, 2, 3, 4, 5]'
satSentinel1 = 'Sentinel-1 [bands VV, VH]'
satSentinel2 = 'Sentinel-2 [bands 1, 2, 3, 4, 5, 6, 7, 8, 8A, 9, 10, 11, 12]'
satSentinel3 = (
    'Sentinel-3 [bands 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, '
    '16, 17, 18, 19, 20, 21]'
)
satASTER = 'ASTER [bands 1, 2, 3N, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]'
satMODIS = 'MODIS [bands 3, 4, 1, 2, 5, 6, 7]'
satMODIS2 = 'MODIS [bands 1, 2]'
satSPOT4 = 'SPOT 4 [bands 1, 2, 3, 4]'
satSPOT5 = 'SPOT 5 [bands 1, 2, 3, 4]'
satSPOT6 = 'SPOT 6 [bands 1, 2, 3, 4]'
satPleiades = 'Pleiades [bands 1, 2, 3, 4]'
satQuickBird = 'QuickBird [bands 1, 2, 3, 4]'
satWorldView23 = 'WorldView-2 -3 Multispectral [bands 1, 2, 3, 4, 5, 6, 7, 8]'
# satellite list used in BandSet class
sat_band_list = [
    no_satellite, satASTER, satGeoEye1, satGOES, satLandsat89,
    satLandsat9, satLandsat8,
    satLandsat7, satLandsat45, satLandsat13, satMODIS, satMODIS2, satPleiades,
    satQuickBird, satRapidEye, satSentinel2, satSentinel3, satSPOT4, satSPOT5,
    satSPOT6, satWorldView23
]
# units used for center wavelength
no_unit = 'band number'
wl_micro = 'µm (1 E-6m)'
wl_nano = 'nm (1 E-9m)'
# list of units
unit_list = [no_unit, wl_micro, wl_nano]
unit_nano = 'E-9m'
unit_micro = 'E-6m'
# wavelength center and thresholds in micrometers used in BandSet class
blue_center = 0.475
blue_threshold = 0.2
green_center = 0.56
green_threshold = 0.03
red_center = 0.65
red_threshold = 0.04
nir_center = 0.85
nir_threshold = 0.15
swir_1_center = 1.61
swir_1_threshold = 0.2
swir_2_center = 2.2
swir_2_threshold = 0.2
# dictionary of satellite bands center wavelengths
satellites = {
    # ASTER center wavelength calculated from USGS, 2015.
    # Advanced Spaceborne Thermal Emission and Reflection
    # Radiometer (ASTER) Level 1 Precision Terrain Corrected Registered
    # At-Sensor Radiance Product (AST_L1T)
    satASTER: [
        [0.560, 0.660, 0.810, 1.650, 2.165, 2.205, 2.260, 2.330, 2.395,
         8.300, 8.650, 9.100, 10.600, 11.300],
        wl_micro,
        ['01', '02', '3N', '04', '05', '06', '07', '08', '09', '10',
         '11', '12', '13', '14']],
    # Landsat center wavelength calculated from
    # https://www.usgs.gov/faqs/what-are-band-designations-landsat-satellites
    satLandsat89: [[0.44, 0.48, 0.56, 0.59, 0.655, 0.865, 1.37, 1.61, 2.2,
                    10.895, 12.005],
                  wl_micro, ['1', '2', '3', '8', '4', '5', '9', '6', '7', '10',
                             '11']],
    satLandsat9: [[0.44, 0.48, 0.56, 0.655, 0.865, 1.61, 2.2],
                  wl_micro, ['1', '2', '3', '4', '5', '6', '7']],
    satLandsat8: [[0.44, 0.48, 0.56, 0.655, 0.865, 1.61, 2.2],
                  wl_micro, ['1', '2', '3', '4', '5', '6', '7']],
    satLandsat7: [[0.485, 0.56, 0.66, 0.835, 1.65, 2.22],
                  wl_micro, ['1', '2', '3', '4', '5', '7']],
    satLandsat45: [[0.485, 0.56, 0.66, 0.83, 1.65, 2.215],
                   wl_micro, ['1', '2', '3', '4', '5', '7']],
    satLandsat13: [[0.55, 0.65, 0.75, 0.95], wl_micro, ['4', '5', '6', '7']],
    # MODIS center wavelength calculated from
    # https://lpdaac.usgs.gov/dataset_discovery/modis
    satMODIS: [[0.469, 0.555, 0.645, 0.858, 1.24, 1.64, 2.13],
               wl_micro, ['03', '04', '01', '02', '05', '06', '07']],
    satMODIS2: [[0.645, 0.858], wl_micro, ['01', '02']],
    # RapidEye center wavelength calculated from
    # http://www.blackbridge.com/rapideye/products/ortho.htm
    satRapidEye: [[0.475, 0.555, 0.6575, 0.71, 0.805],
                  wl_micro, ['01', '02', '03', '04', '05']],
    # SPOT center wavelength calculated from
    # http://www.astrium-geo.com/en/194-resolution-and-spectral-bands
    satSPOT4: [[0.545, 0.645, 0.835, 1.665], wl_micro,
               ['01', '02', '03', '04']],
    satSPOT5: [[0.545, 0.645, 0.835, 1.665], wl_micro,
               ['01', '02', '03', '04']],
    satSPOT6: [[0.485, 0.56, 0.66, 0.825], wl_micro, ['01', '02', '03', '04']],
    # Pleiades center wavelength calculated from
    # http://www.astrium-geo.com/en/3027-pleiades-50-cm-resolution-products
    satPleiades: [[0.49, 0.56, 0.65, 0.84], wl_micro,
                  ['01', '02', '03', '04']],
    # QuickBird center wavelength calculated from
    # http://www.digitalglobe.com/resources/satellite-information
    satQuickBird: [[0.4875, 0.543, 0.65, 0.8165], wl_micro,
                   ['01', '02', '03', '04']],
    # WorldView-2 center wavelength calculated from
    # http://www.digitalglobe.com/resources/satellite-information
    satWorldView23: [
        [0.425, 0.48, 0.545, 0.605, 0.66, 0.725, 0.8325, 0.95],
        wl_micro, ['01', '02', '03', '04', '05', '06', '07', '08']],
    # GeoEye-1 center wavelength calculated from
    # http://www.digitalglobe.com/resources/satellite-information
    satGeoEye1: [[0.48, 0.545, 0.6725, 0.85], wl_micro,
                 ['01', '02', '03', '04']],
    # Sentinel-1
    satSentinel1: [[1, 2], no_unit, ['1', '2']],
    # Sentinel-2 center wavelength from
    # https://sentinel.esa.int/documents/247904/685211/Sentinel-2A
    # +MSI+Spectral+Responses
    satSentinel2: [
        [0.443, 0.490, 0.560, 0.665, 0.705, 0.740, 0.783, 0.842, 0.865,
         0.945, 1.375, 1.610, 2.190], wl_micro,
        ['01', '02', '03', '04', '05', '06', '07', '08', '8A', '09',
         '10', '11', '12']],
    # Sentinel-3 center wavelength from Sentinel-3 xfdumanifest.xml
    satSentinel3: [
        [0.400, 0.4125, 0.4425, 0.490, 0.510, 0.560, 0.620, 0.665,
         0.67375, 0.68125, 0.70875, 0.75375, 0.76125,
         0.764375, 0.7675, 0.77875, 0.865, 0.885, 0.900, 0.940, 1.020],
        wl_micro,
        ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10',
         '11', '12', '13', '14', '15', '16', '17', '18', '19', '20',
         '21']],
    # GOES center wavelength from GOES-R, 2017.PRODUCT DEFINITION
    # AND USER’S GUIDE (PUG) VOLUME 3: LEVEL 1B PRODUCTS
    satGOES: [[0.47, 0.64, 0.87, 1.38, 1.61, 2.25], wl_micro,
              ['01', '02', '03', '04', '05', '06']]
}
# variable used for array name placeholder in expressions for calculations
array_function_placeholder = '_array_function_placeholder'
# reclassification name variables
old_value = 'old_value'
new_value = 'new_value'
variable_raster_name = 'raster'
variable_vector_name = 'vector'
# calculation band name alias
variable_bandset_name = 'bandset'
variable_band_name = 'b'
variable_band_quotes = '"'
variable_band = '#BAND#'
variable_current_bandset = '#'
variable_output_separator = '@'
variable_bandset_number_separator = '%'
variable_all = '*'
variable_blue_name = '#BLUE#'
variable_green_name = '#GREEN#'
variable_red_name = '#RED#'
variable_nir_name = '#NIR#'
variable_swir1_name = '#SWIR1#'
variable_swir2_name = '#SWIR2#'
variable_ndvi_name = '#NDVI#'
variable_ndvi_expression = '("#NIR#" - "#RED#") / ("#NIR#" + "#RED#")'
variable_evi_name = '#NDVI#'
variable_evi_expression = (
    '2.5 * ("#NIR#" - "#RED#") / ("#NIR#" + 6 * "#RED#" - 7.5 * "#BLUE#" + 1)'
)
expression_alias = [[variable_ndvi_name, variable_ndvi_expression],
                    [variable_evi_name, variable_evi_expression]]
variable_output_name_bandset = '#BANDSET#'
variable_output_name_date = '#DATE#'
variable_output_temporary = 'temp'
forbandsinbandset = 'forbandsinbandset'
forbandsets = 'forbandsets'
calc_function_name = '!function!'
calc_date_format = '%Y-%m-%d'
default_output_name = 'output'
stat_percentile = '@stat_percentile@'
statistics_list = [
    ['Count', 'np.count_nonzero(~np.isnan(array))'],
    ['Max', 'np.nanmax(array)'], ['Mean', 'np.nanmean(array)'],
    ['Median', 'np.nanmedian(array)'], ['Min', 'np.nanmin(array)'],
    ['Percentile', 'np.nanpercentile(array, %s)' % stat_percentile],
    ['StandardDeviation', 'np.nanstd(array)'], ['Sum', 'np.nansum(array)']
]
# calculation data types used in calculations
float64_dt = 'Float64'
float32_dt = 'Float32'
int64_dt = 'Int64'
uint64_dt = 'UInt64'
int32_dt = 'Int32'
uint32_dt = 'UInt32'
int16_dt = 'Int16'
uint16_dt = 'UInt16'
byte_dt = 'Byte'
datatype_list = [float64_dt, float32_dt, int64_dt, uint64_dt, int32_dt,
                 uint32_dt, int16_dt, uint16_dt, byte_dt]
# spectral catalog table dtype
spectral_dtype_list = [('signature_id', 'U64'), ('macroclass_id', 'int16'),
                       ('class_id', 'int16'), ('class_name', 'U512'),
                       ('selected', 'byte'), ('min_dist_thr', 'float64'),
                       ('max_like_thr', 'float64'),
                       ('spec_angle_thr', 'float64'),
                       ('geometry', 'byte'), ('signature', 'byte'),
                       ('color', 'U64'), ('pixel_count', 'int16'),
                       ('unit', 'U64')]
# spectral signature dtype
signature_dtype_list = [('value', 'float64'), ('wavelength', 'float64'),
                        ('standard_deviation', 'float64')]
# product table dtype
product_dtype_list = [
    ('product', 'U512'), ('image', 'U1024'), ('product_id', 'U512'),
    ('acquisition_date', 'datetime64[D]'), ('cloud_cover', 'int8'),
    ('zone_path', 'U8'), ('row', 'U8'), ('min_lat', 'float64'),
    ('min_lon', 'float64'), ('max_lat', 'float64'), ('max_lon', 'float64'),
    ('collection', 'U1024'), ('size', 'U512'), ('preview', 'U1024'),
    ('uid', 'U1024'), ('ref_url', 'U1024')
]
# variables used in spectral signatures
uid_field_name = 'roi_id'
macroclass_field_name = 'macroclass_id'
class_field_name = 'class_id'
macroclass_default = 'macroclass'
class_default = 'class'

# clustering options
random_pixel = 'random pixel'
band_mean = 'band mean'
# name used in raster conversion to vector for area field
area_field_name = 'area'
not_available = 'n/a'

# input normalization for classification
z_score = 'z score'
linear_scaling = 'linear scaling'
spectral_signatures_framework = 'spectral_signatures'
model_classifier_framework = 'model_classifier'
normalization_values_framework = 'normalization_values'
covariance_matrices_framework = 'covariance_matrices'
algorithm_name_framework = 'algorithm_name'
additional_algorithm_framework = 'additional_algorithm'
model_path_framework = 'model_path'
model_reclass_framework = 'model_reclass'
n_processes_framework = 'n_processes'
num_classes_framework = 'num_classes'
input_normalization_framework = 'input_normalization'
# classification algorithm names
minimum_distance = 'minimum distance'
minimum_distance_a = 'md'
maximum_likelihood = 'maximum likelihood'
maximum_likelihood_a = 'ml'
spectral_angle_mapping = 'spectral angle mapping'
spectral_angle_mapping_a = 'sam'
random_forest = 'random forest'
random_forest_a = 'rf'
random_forest_ovr = 'random forest ovr'
random_forest_ovr_a = 'rf_ovr'
support_vector_machine = 'support vector machine'
support_vector_machine_a = 'svm'
multi_layer_perceptron = 'multi-layer perceptron'
multi_layer_perceptron_a = 'mlp'
pytorch_multi_layer_perceptron = 'pytorch multi-layer perceptron'
pytorch_multi_layer_perceptron_a = 'pytorch_mlp'
pytorch_pretrained_s2_swin_v2_base = 'pytorch sentinel-2 swin v2 base'
pytorch_pretrained_s2_swin_v2_base_a = 'pytorch_s2_swin2b'
pytorch_pretrained_s2_swin_v2_tiny = 'pytorch sentinel-2 swin v2 tiny'
pytorch_pretrained_s2_swin_v2_tiny_a = 'pytorch_s2_swin2t'
pytorch_pretrained_l89_swin_v2_base = 'pytorch Landsat8-9 swin v2 base'
pytorch_pretrained_l89_swin_v2_base_a = 'pytorch_l89_swin2b'
pytorch_pretrained_s2_swin_v2_base_seg = 'pytorch sentinel-2 swin v2 base seg'
pytorch_pretrained_s2_swin_v2_base_seg_a = 'pytorch_s2_swin2b_seg'
pytorch_pretrained_s2_swin_v2_base_rgb_seg = 'pytorch sentinel-2 swin v2 base rgb seg'
pytorch_pretrained_s2_swin_v2_base_rgb_seg_a = 'pytorch_s2_swin2b_rgb_seg'

# classification frameworks
classification_framework = 'classification_framework'
core_framework = 'core'
scikit_framework = 'scikit'
pytorch_framework = 'pytorch'
pretrained_framework = 'pretrained'
segmentation_framework = 'segmentation'
# classification framework dict
class_framework_dict = {
    core_framework: [minimum_distance, minimum_distance_a,
                     spectral_angle_mapping, spectral_angle_mapping_a,
                     maximum_likelihood, maximum_likelihood_a],
    scikit_framework: [random_forest, random_forest_a,
                       random_forest_ovr, random_forest_ovr_a,
                       support_vector_machine, support_vector_machine_a,
                       multi_layer_perceptron, multi_layer_perceptron_a],
    pytorch_framework: [pytorch_multi_layer_perceptron,
                        pytorch_multi_layer_perceptron_a],
    pretrained_framework: [pytorch_pretrained_s2_swin_v2_base,
                           pytorch_pretrained_s2_swin_v2_base_a,
                           pytorch_pretrained_s2_swin_v2_tiny,
                           pytorch_pretrained_s2_swin_v2_tiny_a,
                           pytorch_pretrained_l89_swin_v2_base,
                           pytorch_pretrained_l89_swin_v2_base_a],
    segmentation_framework: [pytorch_pretrained_s2_swin_v2_base_seg,
                             pytorch_pretrained_s2_swin_v2_base_seg_a,
                             pytorch_pretrained_s2_swin_v2_base_rgb_seg,
                             pytorch_pretrained_s2_swin_v2_base_rgb_seg_a],
}
classification_algorithms = [alg for alg_list in class_framework_dict.values()
                             for alg in alg_list]

# pretrained variants
variant_base = 'base'
variant_tiny = 'tiny'
variant_base_seg = 'base_seg'
# pretrained models
pretrained_model_dict = {
    ' ': '',
    # Sentinel-2 bands B04, B03, B02, B05, B06, B07, B08, B11, B12 from https://github.com/allenai/satlas/blob/main/Normalization.md
    pytorch_pretrained_s2_swin_v2_base:
        f'Swin-v2-Base model for Sentinel-2 single image.\n'
        f'Requirements: Sentinel-2 bandset '
        f'(TCI RGB (B04, B03, B02), TOA bands B05, B06, B07, B08, B11, B12).\n'
        f'Normalization: TCI RGB bands divided by 255; B05, B06, B07, B08, '
        f'B11, B12 divided by 8160 and clipped to 0-1.\n'
        f'Framework: PyTorch.\n'
        f'Source: Sentinel2_SwinB_SI_MS, '
        f'pretrained by the Allen Institute for Artificial Intelligence '
        f'(SatlasPretrain: https://satlas-pretrain.allen.ai).\n'
        f'The model weights are released under the Open Data Commons '
        f'Attribution License (ODC-BY). '
        f'The repository code is licensed under the Apache License 2.0 '
        f'(https://huggingface.co/allenai/satlas-pretrain).\n'
        f'This tool downloads the official SatlasPretrain weights '
        f'(Bastani et al., "SatlasPretrain: A Large-Scale Dataset for Remote '
        f'Sensing Image Understanding", ICCV 2023, arXiv:2211.15660, '
        f'https://doi.org/10.48550/arXiv.2211.15660).\n'
        f'All model weights remain the property of their respective authors.',
    pytorch_pretrained_s2_swin_v2_tiny:
        f'Swin-v2-Tiny model for Sentinel-2 single image.\n'
        f'Requirements: Sentinel-2 bandset '
        f'(TCI RGB (B04, B03, B02), TOA bands B05, B06, B07, B08, B11, B12).\n'
        f'Normalization: TCI RGB bands divided by 255; B05, B06, B07, B08, '
        f'B11, B12 divided by 8160 and clipped to 0-1.\n'
        f'Framework: PyTorch.\n'
        f'Source: Sentinel2_SwinT_SI_MS, '
        f'pretrained by the Allen Institute for Artificial Intelligence '
        f'(SatlasPretrain: https://satlas-pretrain.allen.ai).\n'
        f'The model weights are released under the Open Data Commons '
        f'Attribution License (ODC-BY). '
        f'The repository code is licensed under the Apache License 2.0 '
        f'(https://huggingface.co/allenai/satlas-pretrain).\n'
        f'This tool downloads the official SatlasPretrain weights '
        f'(Bastani et al., "SatlasPretrain: A Large-Scale Dataset for Remote '
        f'Sensing Image Understanding", ICCV 2023, arXiv:2211.15660, '
        f'https://doi.org/10.48550/arXiv.2211.15660).\n'
        f'All model weights remain the property of their respective authors.',
    # Landsat bands B1-B11 in order from https://github.com/allenai/satlas/blob/main/Normalization.md
    pytorch_pretrained_l89_swin_v2_base:
        f'Swin-v2-Base model for Landsat 8 or Landsat 9 single image.\n'
        f'Requirements: Landsat 8 or Landsat 9 bandset (Collection 2 Level-1 '
        f'bands B01, B02, B03, B04, B05, B06, B07, B08, B09, B10, B11).\n'
        f'Normalization: (band - 4000)/16320 and clipped to 0-1.\n'
        f'Framework: PyTorch.\n'
        f'Source: Landsat_SwinB_SI, '
        f'pretrained by the Allen Institute for Artificial Intelligence '
        f'(SatlasPretrain: https://satlas-pretrain.allen.ai).\n'
        f'The model weights are released under the Open Data Commons '
        f'Attribution License (ODC-BY). '
        f'The repository code is licensed under the Apache License 2.0 '
        f'(https://huggingface.co/allenai/satlas-pretrain).\n'
        f'This tool downloads the official SatlasPretrain weights '
        f'(Bastani et al., "SatlasPretrain: A Large-Scale Dataset for Remote '
        f'Sensing Image Understanding", ICCV 2023, arXiv:2211.15660, '
        f'https://doi.org/10.48550/arXiv.2211.15660).\n'
        f'All model weights remain the property of their respective authors.',
}

segmentation_model_dict = {
    ' ': '',
    # Sentinel-2 bands B04, B03, B02, B08
    pytorch_pretrained_s2_swin_v2_base_seg:
        f'Swin-v2-Base segmentation for Sentinel-2 single image (4 bands).\n'
        f'Requirements: Sentinel-2 bandset '
        f'(TCI RGB (B04, B03, B02), TOA bands B08).\n'
        f'Normalization: TCI RGB bands divided by 255; B08 '
        f'divided by 8160 and clipped to 0-1.\n'
        f'Framework: PyTorch.\n'
        f'Output classes: background, water, developed, tree, shrub, grass, '
        f'crop, bare, snow, wetland, mangroves, moss.\n'
        f'Source: Satlas_MS_tci-b08_epoch150, '
        f'pretrained by DPR Team as part of the DPR Zoo Segmentation Hub '
        f'framework (https://github.com/DPR25/dpr-zoo-segmentation-hub) '
        f'based on SatlasPretrain models. '
        f'The repository code is licensed under the MIT License '
        f'(https://huggingface.co/martinkorelic/dpr-zoo-models). '
        f'This tool downloads the model weights (DPR Team, 2025. Made as part '
        f'of Arnes Hackathon 2025).'
        f'All model weights remain the property of their respective authors. ',
    # Sentinel-2 bands B04, B03, B02
    pytorch_pretrained_s2_swin_v2_base_rgb_seg:
        f'Swin-v2-Base segmentation for Sentinel-2 single image (3 bands).\n'
        f'Requirements: Sentinel-2 bandset '
        f'(TCI RGB (B04, B03, B02)).\n'
        f'Normalization: TCI RGB bands divided by 255.\n'
        f'Framework: PyTorch.\n'
        f'Output classes: background, water, developed, tree, shrub, grass, '
        f'crop, bare, snow, wetland, mangroves, moss.\n'
        f'Source: Satlas_RGB1_epoch70, '
        f'pretrained by DPR Team as part of the DPR Zoo Segmentation Hub '
        f'framework (https://github.com/DPR25/dpr-zoo-segmentation-hub) '
        f'based on SatlasPretrain models. '
        f'The repository code is licensed under the MIT License '
        f'(https://huggingface.co/martinkorelic/dpr-zoo-models). '
        f'This tool downloads the model weights (DPR Team, 2025. Made as part '
        f'of Arnes Hackathon 2025).'
        f'All model weights remain the property of their respective authors. ',
}

segmentation_model_class_dict = {
    ' ': '',
    # Sentinel-2 bands B04, B03, B02, B08
    pytorch_pretrained_s2_swin_v2_base_seg:
        ['background', 'water', 'developed', 'tree', 'shrub', 'grass', 'crop',
         'bare', 'snow', 'wetland', 'mangroves', 'moss'],
    # Sentinel-2 bands B04, B03, B02
    pytorch_pretrained_s2_swin_v2_base_rgb_seg:
        ['background', 'water', 'developed', 'tree', 'shrub', 'grass', 'crop',
         'bare', 'snow', 'wetland', 'mangroves', 'moss'],
}

segmentation_model_color_dict = {
    ' ': '',
    # Sentinel-2 bands B04, B03, B02, B08
    pytorch_pretrained_s2_swin_v2_base_seg:
        ['#000000', '#0000ff', '#ff0000', '#225500', '#338000', '#b3ff80',
         '#ffccaa', '#a05a2c', '#00ffe3', '#d3d0ff', '#a69200', '#b6ffd3'],
    # Sentinel-2 bands B04, B03, B02
    pytorch_pretrained_s2_swin_v2_base_rgb_seg:
        ['#000000', '#0000ff', '#ff0000', '#225500', '#338000', '#b3ff80',
         '#ffccaa', '#a05a2c', '#00ffe3', '#d3d0ff', '#a69200', '#b6ffd3'],
}

pretrained_model_url_dict = {
    # Models pretrained by the Allen Institute for Artificial Intelligence
    # (SatlasPretrain: https://satlas-pretrain.allen.ai).
    # The model weights are released under the Open Data Commons 'Attribution
    # License (ODC-BY). The repository code is licensed under the Apache License 2.0
    # (https://huggingface.co/allenai/satlas-pretrain). This tool downloads the
    # official SatlasPretrain weights (Bastani et al., "SatlasPretrain: A
    # Large-Scale Dataset for Remote Sensing Image Understanding", ICCV 2023,
    # arXiv:2211.15660, https://doi.org/10.48550/arXiv.2211.15660). All model
    # weights remain the property of their respective authors.
    pytorch_pretrained_s2_swin_v2_base:
        'https://huggingface.co/allenai/satlas-pretrain/resolve/main/sentinel2_swinb_si_ms.pth?download=true',  # noqa: E501
    pytorch_pretrained_s2_swin_v2_tiny:
        'https://huggingface.co/allenai/satlas-pretrain/resolve/main/sentinel2_swint_si_ms.pth?download=true',  # noqa: E501
    pytorch_pretrained_l89_swin_v2_base:
        'https://huggingface.co/allenai/satlas-pretrain/resolve/main/landsat_swinb_si.pth?download=true',  # noqa: E501
    # Models for Sentinel-2 developed as part of the DPR Zoo Segmentation Hub
    # framework (https://github.com/DPR25/dpr-zoo-segmentation-hub) based on
    # SatlasPretrain models.
    # The repository code is licensed under the MIT License
    # (https://huggingface.co/martinkorelic/dpr-zoo-models).
    # All model weights remain the property of their respective authors.
    pytorch_pretrained_s2_swin_v2_base_seg:
        'https://huggingface.co/martinkorelic/dpr-zoo-models/resolve/main/Satlas_MS_tci-b08_epoch150.pth?download=true',  # noqa: E501
    pytorch_pretrained_s2_swin_v2_base_rgb_seg:
        'https://huggingface.co/martinkorelic/dpr-zoo-models/resolve/main/Satlas_RGB1_epoch70.pth?download=true',  # noqa: E501
}

pretrained_model_replace_dict = {
    pytorch_pretrained_s2_swin_v2_base_seg:
        ['backbone.backbone.', 'swin.swin.'],
    pytorch_pretrained_s2_swin_v2_base_rgb_seg:
        ['backbone.backbone.', 'swin.swin.'],
}

