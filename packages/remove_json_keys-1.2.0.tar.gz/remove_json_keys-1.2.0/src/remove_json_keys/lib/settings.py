import argparse
from os import path
from types import SimpleNamespace as sn
from . import data

controls = sn(
    json_dir=sn(
        args=['-d', '--json-dir', '--json-folder'],
        type=str, default_val='_locales', help='Name of the folder containing JSON files (default: "_locales")'
    ),
    keys=sn(
        args=['-k', '--keys', '--key', '--remove-keys', '--remove-key', '--delete-keys', '--delete-key'],
        type=str, parser='csv', help='Keys to remove (e.g. "appName,author")'
    ),
    init=sn(
        args=['-i', '--init'],
        action='store_true', help='Create .remove-json.config.json5 file to store default options'
    ),
    force=sn(
        args=['-f', '--force', '--overwrite'],
        action='store_true', help='Force overwrite existing config file when using --init'
    ),
    no_wizard=sn(
        args=['-W', '--no-wizard', '--skip-wizard'],
        action='store_true', default=None, help='Skip interactive prompts during start-up'
    ),
    help=sn(
        args=['-h', '--help'],
        action='help', help='Show help screen'
    )
)

def load(cli, caller_file):

    # Load from config file
    cli.config = sn()
    cli.project_root = path.join(path.dirname(caller_file),
        f"../../{ '' if 'src' in path.dirname(caller_file) else '../../' }")
    possible_config_filenames = [
        f'{prefix}{name}.config.json{suffix}'
            for prefix in ['.', ''] for name in [cli.short_name, cli.name] for suffix in ['5', '', 'c']
    ]
    for filename in possible_config_filenames:
        cli.config_filepath = path.join(cli.project_root, filename)
        if path.exists(cli.config_filepath):
            cli.config = data.sns.from_dict(data.json.read(cli.config_filepath))
            cli.config_filename = filename
            break

    # Parse CLI args
    argp = argparse.ArgumentParser(description=cli.description, add_help=False)
    for attr_name in vars(controls):
        kwargs = getattr(controls, attr_name).__dict__.copy()
        args = kwargs.pop('args') # separate positional flags
        for forbidden in ('default_val', 'parser'): # remove custom attrs
            kwargs.pop(forbidden, None)
        argp.add_argument(*args, **kwargs)
    for key, val in vars(argp.parse_args()).items():
        if getattr(cli.config, key, None) is None:
            setattr(cli.config, key, val)

    # Init cli.config vals
    for name, ctrl in vars(controls).items():
        val = getattr(cli.config, name, None)
        if getattr(ctrl, 'parser', None) == 'csv':
            val = data.csv.parse(val)
        if val is None and hasattr(ctrl, 'default_val'):
            val = ctrl.default_val
        setattr(cli.config, name, val)
