"""remux: Multiplexed remote execution daemon."""

__version__ = "0.0.1"
