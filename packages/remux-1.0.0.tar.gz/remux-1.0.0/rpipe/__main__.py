"""Make rpipe package runnable as a module: python -m rpipe"""

import sys
from rpipe.cli import main

if __name__ == "__main__":
    sys.exit(main())
