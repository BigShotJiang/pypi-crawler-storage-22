"""Setup configuration for remux package."""

from setuptools import setup, find_packages
from pathlib import Path

setup(
    name="remux",
    version="1.0.0",
    description="Secure remote command execution with capability-based access control",
    long_description=Path("README.md").read_text() if Path("README.md").exists() else "",
    long_description_content_type="text/markdown",
    author="Anthropic",
    author_email="support@anthropic.com",
    url="https://github.com/anthropics/remux",
    license="MIT",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "asyncssh>=2.10.0",
        "pyyaml>=6.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-asyncio>=0.20.0",
            "pytest-cov>=4.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "remux=rpipe.cli:main",
            "remux-daemon=rpipe.daemon:main",
            "remux-client=rpipe.client:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: System :: Monitoring",
        "Topic :: System :: Shells",
        "Topic :: System :: Systems Administration",
    ],
    keywords="remote execution ssh daemon security policy",
    project_urls={
        "Bug Tracker": "https://github.com/anthropics/remux/issues",
        "Documentation": "https://github.com/anthropics/remux#readme",
        "Source Code": "https://github.com/anthropics/remux",
    },
)
