# File Renamer

rename file in directory in one time