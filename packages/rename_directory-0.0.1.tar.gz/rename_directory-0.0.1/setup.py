from setuptools import setup, find_packages

setup(
   name='rename_directory',
   version="0.0.1",
   description='rename file in directory in one time',
   author='Sicheng Zhong',
   author_email='zhong_sicheng@outlook.com',
   package_dir={"": "src"},
   packages=find_packages(where="src"),
   install_requires=[], #external packages as dependencies
)