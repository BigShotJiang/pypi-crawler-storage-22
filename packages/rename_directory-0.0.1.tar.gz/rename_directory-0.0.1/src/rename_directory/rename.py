import os

def rename(directory: str = '.'):
    '''
    Rename files in specific directory, default current directory
    [param] str dir: the specific directory where for renaming file in it
    '''
    if directory.startswith('../') or directory.startswith('./'):
        print("Do not use ../ or ./")
        return 

    # if the path is abosulute or relative
    # then set absPath according to situation
    absPath = directory if os.path.isabs(directory) else (os.path.join(os.getcwd(), directory) if directory != '.' else os.getcwd())
    
    files = os.listdir(directory)

    idx = 0  # count for index of new file name
    for file in files:
        absFilePath = os.path.join(absPath, file)
        f, e = os.path.splitext(file)
        
        if os.path.isdir(absFilePath):
            continue
        elif os.path.basename(__file__) == file:
            continue

        # rename file with new name
        os.rename(absFilePath, f'{absPath}/{idx}{e}')
        print(f'{absPath}/{idx}{e}')
        idx += 1  # inclement the index
    
    if idx <= 0:
        print("No file found in the directory!")
    else:
        print(f'Rename {idx + 1} files in total')