import contextlib
import sys
import pandas
from pandas.core.frame import DataFrame
from rich.table import Table
from rich import box
from rich.errors import NotRenderableError
from pathlib import Path
from src.renameseq.console import console

def check_map(plate_map:Path, sep:str) -> tuple[DataFrame, Table]:
    """
    Opens and reads plate map, returning it and
    presenting it to user on the terminal.
    """

    try:
        with open(file=plate_map, mode="rt") as file:
            df: DataFrame = pandas.read_csv(
                filepath_or_buffer=file,
                sep=sep,
                header=None,
                names=["Well", "New Name"]
                ).astype(dtype=str)

        table: Table = Table(
            title="Renaming Map",
            box=box.MINIMAL
            )
        for col in df.columns:
            table.add_column(header=col)
        for row in df.values:
            with contextlib.suppress(NotRenderableError):
                table.add_row(*row)  # pyright: ignore[reportAny]
        if not df["New Name"].is_unique:
            console.print(
                "[bold red]There are repeated new names[/bold red]",
                "[bold red]in your map, please make[/bold red]",
                "[bold red]new names unique.[/bold red]",
            )
            sys.exit(1)
        return df, table
    except FileNotFoundError:
        console.print(
            "[bold red]Map file not found.[/bold red]",
            "[bold red]Check filename and path.[/bold red]"
        )
        sys.exit(1)
    except PermissionError:
        console.print(
            "[bold red]Error accessing the map file.[/bold red]",
            "[bold red]Check file permissions.[/bold red]"
        )
        sys.exit(1)
