import sys
import shutil
from pathlib import Path
from pandas import DataFrame
from src.renameseq.console import console

def rename_files(df:DataFrame, working_dir:Path) -> None:
    """
    Create a copy of original files
    with new names defined by the user in
    plate map.
    """

    for _, row in df.iterrows():
        try:
            _ = shutil.copy2(
                f"{working_dir.joinpath(row['Well'] + '.ab1')}",  # pyright: ignore[reportAny]
                f"{working_dir.joinpath('renamed', row['New Name'] + '.ab1')}"  # pyright: ignore[reportAny]
            )
        except FileNotFoundError:
            console.print(
                f"[bold red]'{row['Well']}.ab1' file not found.[/bold red]"
            )
            sys.exit(1)
        except PermissionError:
            console.print(
                f"[bold red]Could not access destination path.[/bold red]"
            )
            sys.exit(1)
        except Exception as e:
            console.print(
                f"[bold red]{e}[/bold red]"
            )
            sys.exit(1)
