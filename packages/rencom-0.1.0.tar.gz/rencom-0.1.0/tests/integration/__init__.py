"""Integration tests (require API access)."""
