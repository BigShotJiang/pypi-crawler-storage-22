"""Unit tests (fast, no external dependencies)."""
