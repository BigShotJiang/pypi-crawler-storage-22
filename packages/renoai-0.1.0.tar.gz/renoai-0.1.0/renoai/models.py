"""
Response models for Reno API.
"""

from typing import Dict, List, Any, Optional


class Usage:
    """Token usage information."""
    
    def __init__(self, data: Dict[str, Any]):
        self.prompt_tokens: int = data.get("prompt_tokens", 0)
        self.completion_tokens: int = data.get("completion_tokens", 0)
        self.total_tokens: int = data.get("total_tokens", 0)

    def __repr__(self) -> str:
        return (
            f"Usage(prompt_tokens={self.prompt_tokens}, "
            f"completion_tokens={self.completion_tokens}, "
            f"total_tokens={self.total_tokens})"
        )


class Choice:
    """A single completion choice."""
    
    def __init__(self, data: Dict[str, Any]):
        self.index: int = data.get("index", 0)
        self.message: Dict[str, str] = data.get("message", {})
        self.finish_reason: str = data.get("finish_reason", "stop")

    @property
    def content(self) -> str:
        """Get the message content."""
        return self.message.get("content", "")

    @property
    def role(self) -> str:
        """Get the message role."""
        return self.message.get("role", "assistant")

    def __repr__(self) -> str:
        content_preview = self.content[:50] + "..." if len(self.content) > 50 else self.content
        return f"Choice(index={self.index}, content='{content_preview}')"


class Completion:
    """Complete API response."""
    
    def __init__(self, data: Dict[str, Any]):
        self.id: str = data.get("id", "")
        self.created: int = data.get("created", 0)
        self.model: str = data.get("model", "")
        self.choices: List[Choice] = [Choice(c) for c in data.get("choices", [])]
        self.usage: Usage = Usage(data.get("usage", {}))
        self._raw_data: Dict[str, Any] = data

    @property
    def text(self) -> str:
        """Get the text content of the first choice."""
        return self.choices[0].content if self.choices else ""

    @property
    def content(self) -> str:
        """Alias for text property."""
        return self.text

    def __repr__(self) -> str:
        return f"Completion(id='{self.id}', model='{self.model}', choices={len(self.choices)})"

    def to_dict(self) -> Dict[str, Any]:
        """Return the raw response data."""
        return self._raw_data


class StreamChunk:
    """A streaming response chunk."""
    
    def __init__(self, data: Dict[str, Any]):
        self.id: str = data.get("id", "")
        self.created: int = data.get("created", 0)
        self.model: str = data.get("model", "")
        self.choices: List[Dict[str, Any]] = data.get("choices", [])
        self._raw_data: Dict[str, Any] = data

    @property
    def delta(self) -> Optional[str]:
        """Get the content delta from the first choice."""
        if self.choices:
            delta = self.choices[0].get("delta", {})
            return delta.get("content")
        return None

    @property
    def finish_reason(self) -> Optional[str]:
        """Get the finish reason if present."""
        if self.choices:
            return self.choices[0].get("finish_reason")
        return None

    def __repr__(self) -> str:
        return f"StreamChunk(id='{self.id}', delta='{self.delta}')"

    def to_dict(self) -> Dict[str, Any]:
        """Return the raw chunk data."""
        return self._raw_data
