# renomee-ai-pyp

AI-powered file renaming tool for batch processing, smart recognition and natural language naming.

`renomee-ai-pyp` is a Python package that provides utilities for intelligent file renaming. It supports batch processing, AI-based content recognition, and natural language naming rules.

## Use Cases

- Batch rename travel photos with meaningful names based on content
- Organize document files using AI-powered smart recognition
- Apply natural language naming rules without complex regex patterns
- Automate file management workflows for better productivity

## Installation

```bash
python -m pip install renomee-ai-pyp
```

## Basic Usage

```python
import renomee_ai_pyp

print(renomee_ai_pyp.__version__)
```

## Why This Tool Exists

Managing files manually is tedious and error-prone. Traditional renaming tools require learning complex regex patterns. Renomee AI uses natural language understanding to make file renaming intuitive and efficient.

## Related Resources

- Website: https://renomeeai.com/
- Source: https://github.com/hetianhe2024/renomee-ai-pyp

## Publishing to PyPI (Trusted Publishing)

This repository includes workflow: `.github/workflows/publish.yml`.

In PyPI's "Trusted Publisher" form:
- **Owner**: `hetianhe2024`
- **Repository name**: `renomee-ai-pyp`
- **Workflow name**: `publish.yml`
- **Environment name**: Leave empty (this workflow does not use GitHub Environments)

Trigger methods:
- Publish a GitHub Release (`release: published` will trigger publishing)
- Or run manually from the Actions page (`workflow_dispatch`)
