"""
renomee-ai-pyp: AI-powered file renaming tool for batch processing.
"""

__version__ = "0.0.2"
