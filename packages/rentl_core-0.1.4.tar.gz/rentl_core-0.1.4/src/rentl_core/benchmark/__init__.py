"""Benchmark evaluation harness."""
