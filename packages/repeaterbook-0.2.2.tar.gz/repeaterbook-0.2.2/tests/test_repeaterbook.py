"""Testing for repeaterbook."""


def test_dummy() -> None:
    """Dummy test."""
