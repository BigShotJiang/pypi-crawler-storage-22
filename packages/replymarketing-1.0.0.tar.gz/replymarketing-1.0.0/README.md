# ReplyMarketing CLI

💸 AI-powered marketing assistant for Reply Cash - Create content, remix viral posts, run SEO audits, and manage your entire marketing workflow.

## Features

- 🤖 **Multi-Provider Support** - Kimi CLI, OpenAI, Anthropic, Gemini, Ollama, and more
- 🎯 **Auto Skill Detection** - Automatically selects the right skill for your request
- 🔄 **Workflow Support** - Chain multiple skills: "Write blog → Check SEO → Create tweets"
- 📝 **Content Creation** - Blogs, social posts, email sequences, and more
- 📥 **Content Import & Remix** - Import from Twitter, blogs, news sites and remix for Reply Cash
- ✅ **Brand Validation** - Automatically check content against brand guidelines
- 📋 **Approval Workflow** - Submit drafts for human review before publishing
- 🔍 **SEO & Analytics** - Technical audits, keyword research, tracking setup
- 🌐 **Web Scraping** - Research competitors, curate content, extract structured data
- 🔑 **Flexible Auth** - Auto-detect from CLI tools, env vars, or manual API key input

## Installation

### Using uv (recommended)

```bash
# Install uv if you don't have it
pip install uv

# Install the package
uv pip install -e .

# Or install from PyPI (when published)
uv pip install replymarketing
```

### Using pip

```bash
pip install -e .
```

## Quick Start

```bash
# Start the CLI
replymarketing

# Or use the short alias
rmkt
```

On first run, you'll be guided through:
1. **Provider Setup** - Choose from multiple AI providers
2. **Agent Registration** - Register your marketing agent with Reply Cash

## Supported Providers

### CLI Tools (Auto-detected)
| Provider | Detection | Setup |
|----------|-----------|-------|
| **Kimi Code CLI** | `kimi-cli` in PATH | `pip install kimi-cli` |
| **Claude CLI** | `claude` in PATH | `npm install -g @anthropic-ai/claude-code` |
| **OpenAI Codex CLI** | `codex` in PATH | `npm install -g @openai/codex` |

### Cloud APIs (Env vars or manual input)
| Provider | Environment Variable | Notes |
|----------|---------------------|-------|
| **OpenAI** | `OPENAI_API_KEY` | GPT-4, GPT-3.5 |
| **Anthropic** | `ANTHROPIC_API_KEY` | Claude 3 Opus, Sonnet, Haiku |
| **Gemini** | `GEMINI_API_KEY` | Google's Gemini models |

### Local / Self-hosted
| Provider | Default URL | Setup |
|----------|-------------|-------|
| **Ollama** | `http://localhost:11434` | [ollama.com](https://ollama.com) |

## Usage

### Interactive Mode

Just type your request naturally:

```
❯ Write a blog post about stablecoin remittances in Africa

Assistant: I'll help you create a blog post about stablecoin remittances. 
[Using skill: copywriting]

Here's a draft blog post:

Title: "The Future of Remittances: How Stablecoins Are Revolutionizing 
Cross-Border Payments in Africa"
...

What would you like to do next? (type /help for commands)
```

### Natural Language Workflows

The CLI automatically detects complex workflows from natural language:

```
❯ I want to remix this tweet https://x.com/elonmusk/status/123 for reply.cash and submit a draft

I'll perform the following workflow:

1. 📥  content_import
   Import content from https://x.com/elonmusk/status/123

2. 🔄  content_remix  
   Remix imported content with appropriate angle for reply.cash

3. ✅  brand_consistency_check
   Check remixed content against brand guidelines

4. 📋  draft_submission
   Create and submit draft for approval

Estimated time: 3-4 minutes
```

### Content Import & Remix Examples

```
❯ Copy this tweet and remix it for reply.cash: https://x.com/a16zcrypto/status/1884378114314494045

❯ Import this article and create a blog draft: https://example.com/crypto-adoption-2024

❯ Remix content from https://x.com/user/status/456 using the Africa Focus angle

❯ Scrape https://competitor.com/blog and write better content for our blog
```

### Slash Commands

| Command | Description |
|---------|-------------|
| `/help` | Show available commands |
| `/skills` | List all marketing skills |
| `/skills [name]` | Show details for a skill |
| `/clear` | Clear the screen |
| `/exit` | Exit the CLI |

#### Content & Validation Commands

| Command | Description | Example |
|---------|-------------|---------|
| `/brand-check <text>` | Check content against brand guidelines | `/brand-check Your content here` |
| `/import <url>` | Import content from URL for remixing | `/import https://x.com/...` |
| `/angles` | Show available remix angles | `/angles` |
| `/remix <angle> [text]` | Remix content using angle template | `/remix cross-border-hero` |

#### Web Scraping Commands

| Command | Description | Example |
|---------|-------------|---------|
| `/scrape <url>` | Scrape content from URL | `/scrape https://example.com/blog` |
| `/search <query>` | Search web and scrape results | `/search stablecoin remittances Africa` |

#### Draft & Publishing Commands

| Command | Description | Example |
|---------|-------------|---------|
| `/draft "Title \| Body"` | Create a draft for approval | `/draft "My Title \| Content..."` |
| `/submit <draft_id>` | Submit draft for approval | `/submit draft_abc123` |
| `/status <draft_id>` | Check draft approval status | `/status draft_abc123` |

## Available Skills

### Content & Copywriting
- **copywriting** - Website copy, landing pages
- **social-content** - Twitter, LinkedIn posts
- **email-sequence** - Email campaigns
- **blog-generate-with-images** - Blog posts with images
- **changelog-to-marketing** - Convert changelogs to content

### Content Remix & Import
- **content-import** - Import from Twitter, blogs, news sites
- **content-remix** - Remix with preset angles:
  - **Crypto Simplified** - For beginners, simple analogies
  - **Cross-Border Hero** - Focus on remittance savings vs Western Union
  - **Stablecoin Education** - Build trust, explain USDC safety
  - **Controversial Take** - Bold opinions, viral potential
  - **Africa Focus** - Local context for African markets
  - **Founder Story** - Personal, authentic, community building
- **brand-consistency-check** - Validate against brand guidelines

### SEO & Growth
- **seo-audit** - Technical SEO review
- **programmatic-seo** - Scale with templates
- **schema-markup** - Structured data

### Web Scraping & Research
- **web-scrape** - Scrape any website for content, HTML, markdown
- **web-extract** - Extract structured data using LLM
- **web-crawl** - Crawl entire websites
- **web-search** - Search and scrape results

### Strategy
- **marketing-ideas** - Campaign brainstorming
- **launch-strategy** - Product launches
- **referral-program** - Viral loops

## Configuration

Configuration is stored in `~/.replycash/`:

```
~/.replycash/
├── config.json          # Provider settings
├── credentials.json     # Agent credentials (keep secure!)
├── skills/              # Downloaded skill files
├── prompts/             # Marketing prompts
└── debug.log            # Debug logs
```

### Switching Providers

```bash
# Run setup again to change provider
replymarketing --setup
```

## Development

```bash
# Clone repository
git clone https://github.com/yourorg/replymarketing-cli.git
cd replymarketing-cli

# Install with uv
uv pip install -e ".[dev]"

# Run linter
ruff check .

# Run type checker
mypy src/replymarketing
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `OPENAI_API_KEY` | OpenAI API key |
| `ANTHROPIC_API_KEY` | Anthropic API key |
| `GEMINI_API_KEY` | Google Gemini API key |

## API Integration

The CLI integrates with Reply Cash Marketing Hub API:

- **API Base:** `https://reply-marketing-api.vercel.app/api/v1`
- **Frontend:** `https://reply-marketingz.vercel.app`
- **Skills:** `https://reply-marketingz.vercel.app/skills/`

### Workflow

1. **Create Content** - Generate with AI or import from URL
2. **Brand Check** - Validate against guidelines
3. **Submit Draft** - Send for human approval
4. **Review** - Approver reviews via frontend URL
5. **Publish** - Auto-publish after approval

## License

MIT © Reply Cash
