"""Core module for ReplyMarketing CLI."""

from .api_client import ApiClient
from .auth_manager import AuthManager
from .brand_checker import BrandChecker, BrandCheckResult
from .content_remixer import ContentRemixer, ExtractedContent, RemixResult
from .draft_manager import DraftContent, DraftManager, DraftResult, DraftStatus
from .intent_analyzer import IntentAnalyzer, WorkflowAnalysis, WorkflowStep
from .skill_registry import SkillRegistry
from .web_scraper import WebScraper, ScrapeResult, SearchResult
from .workflow_engine import WorkflowEngine, WorkflowResult

__all__ = [
    # API
    "ApiClient",
    # Auth
    "AuthManager",
    # Brand
    "BrandChecker",
    "BrandCheckResult",
    # Content
    "ContentRemixer",
    "ExtractedContent",
    "RemixResult",
    # Drafts
    "DraftContent",
    "DraftManager",
    "DraftResult",
    "DraftStatus",
    # Intent
    "IntentAnalyzer",
    "WorkflowAnalysis",
    "WorkflowStep",
    # Skills
    "SkillRegistry",
    # Web
    "WebScraper",
    "ScrapeResult",
    "SearchResult",
    # Workflow
    "WorkflowEngine",
    "WorkflowResult",
]
