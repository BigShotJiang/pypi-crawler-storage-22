# Changelog

All notable changes to the ReplyMarketing CLI project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.3] - 2026-02-16

### Fixed

- **Core**: Fixed skill registry initialization error on Windows by using `PurePosixPath` for cross-platform path handling

## [1.0.2] - 2026-02-10

### Fixed

- **Packaging**: Bundle skills with package for proper installation

## [1.0.1] - 2026-02-10

### Fixed

- **CI/CD**: Removed GitHub Actions workflows, added manual publish script (`scripts/publish.sh`)
- **Code Quality**: Resolved mypy type errors in providers

## [1.0.0] - 2026-02-08

### Added

- **Core**: Initial release of ReplyMarketing CLI
- **Multi-Provider Support**: Kimi CLI, OpenAI, Anthropic, Gemini, Ollama, and more
- **Auto Skill Detection**: Automatically selects the right skill for your request
- **Workflow Support**: Chain multiple skills together
- **Content Creation**: Blogs, social posts, email sequences
- **Content Import & Remix**: Import from Twitter, blogs, news sites
- **Brand Validation**: Check content against brand guidelines
- **Approval Workflow**: Submit drafts for human review
- **SEO & Analytics**: Technical audits, keyword research, tracking setup
- **Web Scraping**: Research competitors, curate content, extract structured data
- **34+ Marketing Skills**: Complete skill suite for Reply Cash marketing

[Unreleased]: https://github.com/louisdevzz/replymarketing-cli/compare/v1.0.3...HEAD
[1.0.3]: https://github.com/louisdevzz/replymarketing-cli/compare/v1.0.2...v1.0.3
[1.0.2]: https://github.com/louisdevzz/replymarketing-cli/compare/v1.0.1...v1.0.2
[1.0.1]: https://github.com/louisdevzz/replymarketing-cli/compare/v1.0.0...v1.0.1
[1.0.0]: https://github.com/louisdevzz/replymarketing-cli/releases/tag/v1.0.0
