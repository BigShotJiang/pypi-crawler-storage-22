"""ReplyMarketing CLI - AI-powered marketing assistant for Reply Cash."""

__version__ = "1.0.3"
__author__ = "Reply Cash Team"

from .core.api_client import ApiClient
from .core.auth_manager import AuthManager
from .core.intent_analyzer import IntentAnalyzer, WorkflowAnalysis, WorkflowStep
from .core.skill_registry import SkillRegistry
from .core.workflow_engine import WorkflowContext, WorkflowEngine, WorkflowResult
from .providers.base_provider import BaseProvider
from .providers.provider_manager import ProviderManager

__all__ = [
    "ApiClient",
    "AuthManager",
    "IntentAnalyzer",
    "SkillRegistry",
    "WorkflowEngine",
    "WorkflowAnalysis",
    "WorkflowStep",
    "WorkflowContext",
    "WorkflowResult",
    "BaseProvider",
    "ProviderManager",
]
