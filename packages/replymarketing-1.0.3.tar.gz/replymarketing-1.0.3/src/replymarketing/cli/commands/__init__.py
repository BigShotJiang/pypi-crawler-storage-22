"""CLI commands package."""

from .version import version_cmd

__all__ = ["version_cmd"]
