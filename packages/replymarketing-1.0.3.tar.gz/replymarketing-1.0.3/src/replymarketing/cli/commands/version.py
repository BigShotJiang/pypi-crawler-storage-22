"""Version command - check and display version info."""

from __future__ import annotations

import click

from ...ui import console
from ...utils.version import check_for_update, get_update_command


@click.command(name="version")
@click.option("--check", "-c", is_flag=True, help="Check for updates")
def version_cmd(check: bool) -> None:
    """Show version information."""
    from ... import __version__

    console.print(f"[bold cyan]ReplyMarketing CLI[/bold cyan] v[green]{__version__}[/green]")

    if check:
        console.print("\n[dim]Checking for updates...[/dim]")
        update_available, current, latest = check_for_update()

        if update_available:
            console.print("\n[yellow]⚠️  Update available![/yellow]")
            console.print(f"   Current:  [red]{current}[/red]")
            console.print(f"   Latest:   [green]{latest}[/green]")
            console.print("\n[bold]To update, run:[/bold]")
            console.print(f"   [cyan]{get_update_command()}[/cyan]")
        else:
            console.print(f"\n[green]✅ You're up to date![/green] (v{current})")
