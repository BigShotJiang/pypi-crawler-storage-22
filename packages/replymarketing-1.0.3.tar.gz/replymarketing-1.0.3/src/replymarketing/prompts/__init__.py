"""Prompts for ReplyMarketing CLI."""

from __future__ import annotations

from pathlib import Path

SYSTEM = (Path(__file__).parent / "system.md").read_text(encoding="utf-8")
CONTENT = (Path(__file__).parent / "content.md").read_text(encoding="utf-8")
SEO = (Path(__file__).parent / "seo.md").read_text(encoding="utf-8")
SOCIAL = (Path(__file__).parent / "social.md").read_text(encoding="utf-8")

__all__ = ["SYSTEM", "CONTENT", "SEO", "SOCIAL"]
