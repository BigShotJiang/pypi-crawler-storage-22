"""AI providers for ReplyMarketing CLI."""

from .base_provider import BaseProvider
from .kimi_provider import KimiProvider
from .ollama_provider import OllamaProvider
from .provider_manager import ProviderManager

__all__ = [
    "BaseProvider",
    "KimiProvider",
    "OllamaProvider",
    "ProviderManager",
]

# Optional providers - import with try/except
try:
    from .openai_provider import OpenAIProvider  # noqa: F401

    __all__.append("OpenAIProvider")
except ImportError:
    pass

try:
    from .anthropic_provider import AnthropicProvider  # noqa: F401

    __all__.append("AnthropicProvider")
except ImportError:
    pass

try:
    from .gemini_provider import GeminiProvider  # noqa: F401

    __all__.append("GeminiProvider")
except ImportError:
    pass
