"""Base provider interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class BaseProvider(ABC):
    """Abstract base class for AI providers."""

    name: str
    type: str  # 'cli' or 'api'

    @abstractmethod
    def test_connection(self) -> bool:
        """Test if provider is available."""
        pass

    @abstractmethod
    def execute(self, skill_content: str, user_input: str, context: dict[str, Any]) -> str:
        """Execute a task with the provider."""
        pass

    @abstractmethod
    def get_model(self) -> str:
        """Get current model name."""
        pass
