# Reply Cash Marketing Skills

Available skills for the Reply Cash Marketing Agent.

---

## Core Skills

| Skill | Description | Endpoint | Status |
|-------|-------------|----------|--------|
| [content_refine](./content_refine.md) | Refine drafts based on feedback | `POST /skills/content/refine` | ✅ Implemented |
| [changelog_to_marketing](./changelog_to_marketing.md) | Convert changelog to marketing content | `POST /skills/changelog/to-marketing` | ✅ Implemented |
| [auto_distribution_plan](./auto_distribution_plan.md) | Propose distribution strategy | `POST /skills/distribution/plan` | ✅ Implemented |
| [brand_consistency_check](./brand_consistency_check.md) | Validate brand guidelines | `POST /skills/brand/check` | ✅ Implemented |

**Legend:**
- ✅ Implemented - Backend endpoint exists

---

## API Base URL

```
https://reply-marketingz.vercel.app/api/v1
```

All skills require authentication:
```
Authorization: Bearer <agent_api_key>
```

---

## Skill Workflow

```
┌─────────────────┐
│ 1. Generate     │ ← changelog_to_marketing
│    Content      │
└────────┬────────┘
         ↓
┌─────────────────┐
│ 2. Brand Check  │ ← brand_consistency_check
│    (Guardian)   │
└────────┬────────┘
         ↓
┌─────────────────┐
│ 3. Submit Draft │ ← POST /drafts
│    for Approval │
└────────┬────────┘
         ↓
┌─────────────────┐
│ 4. Human Review │ ← Approval UI
│    & Feedback   │
└────────┬────────┘
         ↓
┌─────────────────┐     ┌─────────────────┐
│ 5a. Approve     │────→│ 6. Distribution │ ← auto_distribution_plan
│     & Publish   │     │     Plan        │
└─────────────────┘     └─────────────────┘
         ↓
┌─────────────────┐
│ 5b. Reject      │────→ content_refine ──→ (back to step 2)
│    & Refine     │
└─────────────────┘
```

---

## Implementing New Skills

To implement a documented skill:

1. Create endpoint in `backend/src/routes/skills.ts`
2. Add validation schema using Zod
3. Implement business logic in `backend/src/services/`
4. Update this README status to ✅

See [content_refine](./content_refine.md) as reference implementation.
