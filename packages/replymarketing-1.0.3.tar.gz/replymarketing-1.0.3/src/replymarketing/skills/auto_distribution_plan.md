---
skill: auto_distribution_plan
version: 1.0.0
description: Propose distribution strategy for approved content. Recommend channels and timing.
api: https://reply-marketingz.vercel.app/api/v1/skills/distribution/plan
---

# Skill: Auto Distribution Plan

You are a marketing distribution planning agent.

Your job is to analyze approved content drafts and propose:
- Which channels to publish on
- What format to use per channel
- Suggested timing windows

You do NOT publish content.
You do NOT schedule automatically.
All plans require human approval.

---

## When to Use This Skill

Use this skill after:
- Blog and social drafts are generated
- Brand consistency check has passed
- Content is ready for distribution planning

---

## API Endpoint

```http
POST /api/v1/skills/distribution/plan
Authorization: Bearer <agent_api_key>
Content-Type: application/json
```

---

## Request Payload

```json
{
  "content": {
    "blog": {
      "title": "What's New in Reply Cash v1.2.0",
      "summary": "Release highlights and improvements",
      "length": 1200
    },
    "social": {
      "twitterCount": 3,
      "telegram": true,
      "linkedin": true
    }
  },
  "audience": "users",
  "productStage": "growth",
  "urgency": "medium",
  "timezone": "UTC+7"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `content` | object | Yes | Content details (blog, social) |
| `content.blog` | object | No | Blog post details |
| `content.social` | object | No | Social content summary |
| `audience` | string | No | Target: users, developers, founders |
| `productStage` | string | No | Stage: early, growth, mature |
| `urgency` | string | No | Urgency: low, medium, high |
| `timezone` | string | No | Target timezone (e.g., UTC+7) |

---

## Response

```json
{
  "success": true,
  "data": {
    "channels": [
      {
        "name": "blog",
        "action": "publish",
        "priority": "high",
        "reason": "Primary source of truth for release details"
      },
      {
        "name": "twitter",
        "action": "thread",
        "priority": "high",
        "reason": "Fast announcement and reach"
      },
      {
        "name": "telegram",
        "action": "post",
        "priority": "medium",
        "reason": "Existing engaged community"
      },
      {
        "name": "linkedin",
        "action": "post",
        "priority": "low",
        "reason": "Relevant for founders and partners"
      }
    ],
    "timing": {
      "suggestedWindow": "09:00–11:00",
      "days": ["Tuesday", "Thursday"],
      "notes": "Avoid weekends for release announcements"
    },
    "warnings": [
      "Do not publish all channels simultaneously",
      "Blog should go live before social posts"
    ]
  }
}
```

---

## Planning Logic

### Channel Priorities

| Channel | Priority | Rationale |
|---------|----------|-----------|
| Blog | High | Canonical source, SEO, permanent |
| Twitter | High | Fast reach, viral potential |
| Telegram | Medium | Engaged community |
| LinkedIn | Low | Professional audience |
| Email | Medium | Direct user communication |

### Timing Recommendations

| Day | Time Window | Best For |
|-----|-------------|----------|
| Tuesday | 09:00–11:00 | Major announcements |
| Thursday | 14:00–16:00 | Follow-up content |
| Wednesday | 10:00–12:00 | Technical updates |
| Avoid | Weekends | B2B content |
| Avoid | Late night | Low engagement |

---

## Rules

- ✅ Blog is the canonical source
- ✅ Social content amplifies, never replaces the blog
- ✅ Timing is suggested, not enforced
- ✅ Audience and product stage influence channel priority
- ✅ Provide reasons for every recommendation
- ❌ Do NOT auto-publish
- ❌ Do NOT auto-schedule
- ❌ Do NOT override human decisions

---

## Workflow

```
Content Approved
        ↓
POST /skills/distribution/plan
        ↓
Distribution Plan
        ↓
Human Reviews Plan
        ↓
Human Approves/Edits
        ↓
Execute Publishing
```

---

## Example Usage

### Step 1: Get Distribution Plan

```bash
curl -X POST https://reply-marketingz.vercel.app/api/v1/skills/distribution/plan \
  -H "Authorization: Bearer $REPLY_CASH_AGENT_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "content": {
      "blog": {
        "title": "What'\''s New in Reply Cash v1.2.0",
        "summary": "Agent approval flow and improved reliability",
        "length": 1500
      },
      "social": {
        "twitterCount": 3,
        "telegram": true,
        "linkedin": false
      }
    },
    "audience": "users",
    "productStage": "growth",
    "urgency": "medium",
    "timezone": "UTC+7"
  }'
```

### Step 2: Review Plan & Execute

Human reviews the plan and decides:
- Which channels to use
- Final timing
- Any adjustments needed

---

## Error Handling

```json
{
  "success": false,
  "error": {
    "code": "INVALID_CONTENT",
    "message": "Content details are required"
  }
}
```

| Error Code | Meaning |
|------------|---------|
| `INVALID_CONTENT` | Missing content information |
| `PLANNING_FAILED` | Unable to generate distribution plan |
| `UNSUPPORTED_CHANNEL` | Requested channel not supported |

---

## One-Liner Summary

> **`auto_distribution_plan` là "chiến lược gia", không phải "executor".**

Giúp team marketing:
- Đỡ phải suy nghĩ lại từ đầu mỗi lần release
- Làm việc **có lý do**, không bắn content bừa bãi
- Giữ quyền quyết định cuối cùng cho con ngườii

---

## Related Skills

- [changelog_to_marketing](./changelog_to_marketing.md) - Generate content from changelog
- [brand_consistency_check](./brand_consistency_check.md) - Validate brand guidelines
