# Blog Generate with Images Skill

Generate blog content with automatically extracted images from a source URL. This skill scrapes the source page, extracts all images (hero images, inline images, OG images), and creates a blog draft with images properly embedded in the markdown content.

---

## Endpoint

```
POST /skills/blog/generate-with-images
```

## Authentication

Requires valid agent API key in Authorization header:
```
Authorization: Bearer <agent_api_key>
```

## Request Body

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `sourceUrl` | string | Yes | - | URL to scrape for content and images |
| `title` | string | No | Auto | Blog post title (auto-generated from source if not provided) |
| `category` | string | No | `"General"` | Blog category |
| `tags` | array | No | `["blog"]` | Array of tags |
| `tone` | string | No | `"professional"` | Content tone: `professional`, `friendly`, `technical`, `casual` |
| `maxImages` | number | No | `5` | Maximum images to extract (1-20) |
| `includeScreenshots` | boolean | No | `false` | Include page screenshots as images |
| `channel` | string | No | `"blog"` | Content channel: `blog`, `social`, `email` |

## Example Request

### Basic Usage

```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/skills/blog/generate-with-images \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "sourceUrl": "https://example.com/source-article",
    "title": "My Blog Post Title",
    "category": "Crypto Payments",
    "tags": ["stablecoins", "remittances"],
    "maxImages": 5
  }'
```

### Advanced Usage

```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/skills/blog/generate-with-images \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "sourceUrl": "https://industry-report.com/crypto-trends",
    "title": "Crypto Payment Trends in Africa: 2024 Analysis",
    "category": "Industry Analysis",
    "tags": ["crypto", "africa", "trends", "2024"],
    "tone": "professional",
    "maxImages": 8,
    "includeScreenshots": true,
    "channel": "blog"
  }'
```

## Example Response

```json
{
  "success": true,
  "data": {
    "draftId": "draft_abc123xyz",
    "title": "Crypto Payment Trends in Africa: 2024 Analysis",
    "category": "Industry Analysis",
    "tags": ["crypto", "africa", "trends", "2024"],
    "imageCount": 5,
    "heroImage": "https://industry-report.com/images/hero.jpg",
    "seo": {
      "metaTitle": "Crypto Payment Trends in Africa: 2024 Analysis",
      "metaDescription": "Analysis of crypto payment trends in Africa for 2024",
      "keywords": ["crypto", "africa", "trends", "2024", "payments"]
    },
    "source": {
      "url": "https://industry-report.com/crypto-trends",
      "title": "Original Report Title",
      "scrapedAt": "2024-01-15T10:30:00Z"
    },
    "status": "draft"
  }
}
```

## How It Works

1. **Scrape Source URL** - Fetches content, HTML, and metadata from the source URL
2. **Extract Images** - Parses HTML to find all images:
   - OG (Open Graph) images from meta tags
   - Hero images (large images >800px)
   - Inline content images
   - Screenshots (if `includeScreenshots: true`)
3. **Categorize Images** - Identifies hero image and inline images for optimal placement
4. **Generate Content** - Creates markdown with images embedded at appropriate positions
5. **Create Draft** - Stores as a draft ready for approval workflow

## Image Types

### Hero Image
- First OG image or largest image (>800px width)
- Placed at the top of the blog post
- Used as featured image

### Inline Images
- Content images extracted from the page
- Distributed throughout the article
- Inserted after every 2-3 paragraphs

### Screenshots
- Full page screenshot (if requested)
- Added as additional visual reference
- Base64 encoded in markdown

## Use Cases

### Content Curation
Repurpose industry reports, news articles, or research into blog posts with visuals:

```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/skills/blog/generate-with-images \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "sourceUrl": "https://research-firm.com/crypto-report-2024",
    "title": "Key Insights from 2024 Crypto Report",
    "category": "Research",
    "maxImages": 6
  }'
```

### Competitor Content Analysis
Analyze competitor blog posts with their visuals:

```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/skills/blog/generate-with-images \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "sourceUrl": "https://competitor.com/blog/featured-post",
    "title": "Analysis: Competitor Approach to Crypto Payments",
    "category": "Competitive Analysis",
    "maxImages": 3
  }'
```

### News Commentary
Create blog posts about industry news with original images:

```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/skills/blog/generate-with-images \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "sourceUrl": "https://news-site.com/crypto-announcement",
    "title": "What the Latest Crypto Announcement Means for Africa",
    "category": "News",
    "tone": "friendly",
    "maxImages": 4
  }'
```

## Workflow Integration

### Complete Workflow Example

```bash
REPLY_CASH_AGENT_KEY=$(jq -r '.agentApiKey' ~/.config/replycash/credentials.json)

# 1. Generate blog with images
BLOG_RESULT=$(curl -s -X POST https://reply-marketing-api.vercel.app/api/v1/skills/blog/generate-with-images \
  -H "Authorization: Bearer $REPLY_CASH_AGENT_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "sourceUrl": "https://source-article.com",
    "title": "My Analysis",
    "category": "Analysis",
    "maxImages": 5
  }')

DRAFT_ID=$(echo $BLOG_RESULT | jq -r '.data.draftId')

# 2. Check brand consistency
curl -X POST https://reply-marketing-api.vercel.app/api/v1/skills/brand/check \
  -H "Authorization: Bearer $REPLY_CASH_AGENT_KEY" \
  -H "Content-Type: application/json" \
  -d "{
    \"content\": {
      \"type\": \"blog\",
      \"text\": $(echo $BLOG_RESULT | jq -r '.data.title')
    }
  }"

# 3. Submit for approval
curl -X POST https://reply-marketing-api.vercel.app/api/v1/drafts/$DRAFT_ID/submit-approval \
  -H "Authorization: Bearer $REPLY_CASH_AGENT_KEY"
```

## Tips for Best Results

### Source Selection
- Choose sources with high-quality images
- News sites, research reports, and industry blogs work well
- Ensure source allows content reuse or use for inspiration only

### Image Optimization
- Use `maxImages` to control visual density (3-5 recommended)
- Enable `includeScreenshots` for technical documentation
- Hero images should be relevant and high-quality

### Content Tone
- `professional` - Business, industry analysis, reports
- `friendly` - Customer stories, announcements, casual topics
- `technical` - API docs, technical guides, deep dives
- `casual` - Social content, light topics, personal stories

## Error Responses

```json
{
  "success": false,
  "error": {
    "code": "BLOG_GENERATION_FAILED",
    "message": "Failed to scrape source URL: 404 Not Found"
  }
}
```

## Rate Limits

- Default: 20 requests per minute per agent
- Image extraction may add processing time
- Large pages with many images may take longer

## Notes

- Images are embedded as markdown: `![alt text](image_url)`
- External image URLs are preserved (not downloaded)
- OG images are prioritized for hero image selection
- Draft requires approval before publishing
- Always review and edit generated content before approval
