---
skill: brand_consistency_check
version: 1.0.0
description: Brand Guardian - Validate content against brand guidelines, tone, and compliance rules.
api: https://reply-marketingz.vercel.app/api/v1/skills/brand/check
---

# Skill: Brand Consistency Check

You are the **Brand Guardian** for Reply Cash Marketing Hub.

Your job is not to create, but to inspect — check — catch issues:
- Is the tone aligned with brand voice?
- Are keywords used correctly for positioning?
- Any compliance / internal policy violations?
- Does content sound like Reply Cash or generic AI content?

This skill does NOT edit content, only evaluates + suggests.
Editing rights belong to `content_refine` or the approval UI.

---

## When to Use This Skill

Use this skill before:
- Submitting drafts for approval
- Publishing approved content
- Any content that represents the brand publicly

**Ideal workflow:**
```
Content Generated
      ↓
brand_consistency_check
      ↓
[pass] → Submit for approval
[warning] → Review & decide
[fail] → content_refine → re-check
```

---

## API Endpoint

```http
POST /api/v1/skills/brand/check
Authorization: Bearer <agent_api_key>
Content-Type: application/json
```

---

## Request Payload

```json
{
  "content": {
    "type": "blog",
    "text": "Full content text to validate..."
  },
  "brandProfile": {
    "tone": ["builder-first", "technical", "optimistic", "credible"],
    "keywords": ["agent", "launchpad", "onchain", "automation", "AI"],
    "bannedPhrases": ["guaranteed profit", "risk-free"],
    "complianceRules": [
      "no financial advice",
      "no price prediction",
      "no misleading claims"
    ]
  }
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `content` | object | Yes | Content to validate |
| `content.type` | string | Yes | Content type: blog, twitter, telegram, changelog_summary |
| `content.text` | string | Yes | Full content text |
| `brandProfile` | object | No | Brand guidelines (uses default if not provided) |
| `brandProfile.tone` | string[] | No | Brand tone descriptors |
| `brandProfile.keywords` | string[] | No | Required/important keywords |
| `brandProfile.bannedPhrases` | string[] | No | Phrases to avoid |
| `brandProfile.complianceRules` | string[] | No | Compliance constraints |

---

## Response

```json
{
  "success": true,
  "data": {
    "status": "pass",
    "score": {
      "toneAlignment": 0.85,
      "keywordAlignment": 0.92,
      "compliance": 1.0,
      "overall": 0.92
    },
    "issues": [
      {
        "type": "tone",
        "severity": "medium",
        "description": "Tone is slightly too promotional",
        "excerpt": "The best platform ever for..."
      }
    ],
    "suggestions": [
      "Replace 'best ever' with specific benefits",
      "Add keyword 'automation' in intro"
    ],
    "summary": "Content is mostly on-brand with minor tone adjustments needed"
  }
}
```

---

## Validation Dimensions

### 1. Tone Alignment

Check against brand profile:
- Too marketing-speak?
- Lacking technical depth?
- Too "AI hype"?

**Reply Cash Tone:**
- Builder-first
- Technical but accessible
- Optimistic but grounded
- Credible, not hype

### 2. Keyword Alignment

- Using core keywords correctly?
- Any keywords used out of context?
- Missing important keywords for SEO/positioning?

### 3. Compliance & Risk

- Sensitive claims?
- Accidental financial advice?
- Misleading wording?

**Banned Claims:**
- "Guaranteed returns"
- "Risk-free investment"
- "Get rich quick"
- Price predictions

---

## Decision Logic

| Status | Meaning | Action |
|--------|---------|--------|
| `pass` | Content ready to publish | Proceed to distribution |
| `warning` | Minor issues, human can override | Submit for approval with notes |
| `fail` | Significant issues | Block, run content_refine |

### Scoring

| Dimension | Weight | Threshold |
|-----------|--------|-----------|
| toneAlignment | 35% | ≥0.7 pass |
| keywordAlignment | 35% | ≥0.7 pass |
| compliance | 30% | =1.0 required |
| **overall** | 100% | ≥0.8 pass |

**Note:** This skill does NOT auto-fix to prevent "AI arbitrarily changing brand".

---

## Example Usage

### Step 1: Check Blog Content

```bash
curl -X POST https://reply-marketingz.vercel.app/api/v1/skills/brand/check \
  -H "Authorization: Bearer $REPLY_CASH_AGENT_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "content": {
      "type": "blog",
      "text": "Reply Cash v1.2.0 brings powerful new features..."
    },
    "brandProfile": {
      "tone": ["builder-first", "technical", "optimistic"],
      "keywords": ["agent", "automation", "approval"],
      "bannedPhrases": ["guaranteed", "risk-free"],
      "complianceRules": ["no financial advice"]
    }
  }'
```

### Step 2: Review Results

If `status: "pass"` → Submit for approval

If `status: "warning"` → Review issues, decide to proceed or refine

If `status: "fail"` → Run content_refine with suggestions

---

## Error Handling

```json
{
  "success": false,
  "error": {
    "code": "CONTENT_TOO_SHORT",
    "message": "Content must be at least 50 characters"
  }
}
```

| Error Code | Meaning |
|------------|---------|
| `CONTENT_TOO_SHORT` | Content below minimum length |
| `INVALID_CONTENT_TYPE` | Unsupported content type |
| `CHECK_FAILED` | Unable to complete validation |

---

## Philosophy

This skill transforms brand from "dead PDF guidelines" into:

> **Executable brand logic**

Brand no longer lives only in the marketing lead's head,
but becomes an agent that can audit, score, block, or approve.

This is the difference between:
- AI writing content
- **Agent operating a marketing system**

---

## One-Liner Summary

> **`brand_consistency_check` là "Brand Guardian" - soi, kiểm, bắt lỗi, không sửa.**

Biến brand guidelines từ PDF chết thành:
- Logic thực thi được
- Có thể audit tự động
- Giữ consistency ở scale

---

## Related Skills

- [content_refine](./content_refine.md) - Fix issues found by brand check
- [changelog_to_marketing](./changelog_to_marketing.md) - Generate content
- [auto_distribution_plan](./auto_distribution_plan.md) - Plan distribution
