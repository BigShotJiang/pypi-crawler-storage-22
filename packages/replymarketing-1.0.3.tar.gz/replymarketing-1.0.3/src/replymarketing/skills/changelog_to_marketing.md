---
skill: changelog_to_marketing
version: 1.0.0
description: Convert technical changelogs into marketing-ready content (blog + social).
api: https://reply-marketingz.vercel.app/api/v1/skills/changelog/to-marketing
---

# Skill: Changelog to Marketing

You are a marketing translation agent.

Your job is to convert a technical changelog into:
- One long-form blog draft
- Multiple short-form social drafts

You must translate *features* into *user value*.
You must not invent features or claims not present in the changelog.

This skill prepares content only.
Publishing always requires human approval.

---

## When to Use This Skill

Use this skill when:
- A new product version is released
- A feature set is merged
- Internal changelogs need to be communicated externally

---

## API Endpoint

```http
POST /api/v1/skills/changelog/to-marketing
Authorization: Bearer <agent_api_key>
Content-Type: application/json
```

---

## Request Payload

```json
{
  "productName": "Reply Cash",
  "version": "v1.2.0",
  "changelog": [
    "Added marketing agent approval flow",
    "Improved content publishing reliability",
    "Refactored backend services",
    "Minor bug fixes"
  ],
  "audience": "users",
  "language": "en",
  "tone": "professional"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `productName` | string | Yes | Product name |
| `version` | string | Yes | Version number (e.g., v1.2.0) |
| `changelog` | string[] | Yes | Array of technical changelog items |
| `audience` | string | No | Target audience: users, developers, partners |
| `language` | string | No | Language code: en, vi. Default: en |
| `tone` | string | No | Tone: professional, friendly, technical |

---

## Response

```json
{
  "success": true,
  "data": {
    "blog": {
      "title": "What's New in Reply Cash v1.2.0",
      "summary": "A short overview of the release highlights",
      "content": "Full blog article content"
    },
    "social": {
      "twitter": [
        "🚀 Reply Cash v1.2.0 is live!",
        "Marketing agents now have an approval workflow.",
        "More reliable publishing, smoother experience."
      ],
      "telegram": "Reply Cash v1.2.0 is out with improved agent workflows and stability."
    }
  }
}
```

---

## Content Guidelines

### Blog

- Explain why the update matters
- Group related changelog items
- Avoid raw bullet-point release notes
- No hype, no exaggerated claims

### Social

- Short, scannable
- One key message per post
- Emojis allowed but restrained

---

## Rules

- ✅ Translate features into user value
- ✅ Focus on benefits, not implementation
- ✅ Group related changes logically
- ❌ Do NOT fabricate features
- ❌ Do NOT promise future functionality
- ❌ Do NOT publish automatically
- ❌ All outputs must be submitted for approval

---

## Workflow

```
Changelog Released
        ↓
POST /skills/changelog/to-marketing
        ↓
Blog + Social Drafts
        ↓
brand_consistency_check (optional)
        ↓
Submit for Approval
        ↓
Human Review
        ↓
Approve → Publish
```

---

## Example Usage

### Step 1: Generate Marketing Content

```bash
curl -X POST https://reply-marketingz.vercel.app/api/v1/skills/changelog/to-marketing \
  -H "Authorization: Bearer $REPLY_CASH_AGENT_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "productName": "Reply Cash",
    "version": "v1.2.0",
    "changelog": [
      "Added marketing agent approval flow",
      "Improved content publishing reliability",
      "Refactored backend services",
      "Minor bug fixes"
    ],
    "audience": "users",
    "language": "en",
    "tone": "professional"
  }'
```

### Step 2: Submit Blog Draft

```bash
curl -X POST https://reply-marketingz.vercel.app/api/v1/skills/marketing/submit-draft \
  -H "Authorization: Bearer $REPLY_CASH_AGENT_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "channel": "blog",
    "content": {
      "title": "What'\''s New in Reply Cash v1.2.0",
      "body": "Generated blog content...",
      "seo": {
        "metaDescription": "Discover what'\''s new in Reply Cash v1.2.0",
        "keywords": ["release notes", "changelog"]
      },
      "tags": ["release", "v1.2.0"]
    }
  }'
```

### Step 3: Submit Social Drafts

```bash
curl -X POST https://reply-marketingz.vercel.app/api/v1/skills/marketing/submit-draft \
  -H "Authorization: Bearer $REPLY_CASH_AGENT_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "channel": "social",
    "content": {
      "title": "Reply Cash v1.2.0 Release",
      "body": "🚀 Reply Cash v1.2.0 is live! Marketing agents now have approval workflows."
    }
  }'
```

---

## Error Handling

```json
{
  "success": false,
  "error": {
    "code": "INVALID_CHANGELOG",
    "message": "Changelog items cannot be empty"
  }
}
```

| Error Code | Meaning |
|------------|---------|
| `INVALID_CHANGELOG` | Changelog array is empty or invalid |
| `MISSING_VERSION` | Version string is required |
| `GENERATION_FAILED` | Unable to generate marketing content |

---

## One-Liner Summary

> **`changelog_to_marketing`** biến log kỹ thuật thành nội dung marketing sẵn sàng để duyệt, không tự ý publish.

---

## Related Skills

- [content_refine](./content_refine.md) - Refine drafts based on feedback
- [brand_consistency_check](./brand_consistency_check.md) - Validate brand guidelines
