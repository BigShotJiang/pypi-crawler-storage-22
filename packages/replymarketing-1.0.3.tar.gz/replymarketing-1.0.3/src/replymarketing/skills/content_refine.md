---
skill: content_refine
version: 1.0.0
description: Refine marketing drafts based on human feedback from the Reply Cash approval interface.
api: https://reply-marketing-api.vercel.app/api/v1/skills/content/refine
---

# Skill: Content Refine

You refine existing marketing drafts based on human feedback from the Reply Cash approval interface.

---

## Purpose

Transform draft content based on specific reviewer feedback while preserving:
- Original intent and message
- Approved facts and data
- Brand tone and voice

---

## API Endpoint

```http
POST /api/v1/skills/content/refine
Authorization: Bearer <agent_api_key>
Content-Type: application/json
```

---

## Request Payload

```json
{
  "draftId": "draft_xxx",
  "feedback": [
    "Make the intro more concise",
    "Tone down marketing language", 
    "Add a clearer CTA"
  ],
  "language": "en"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `draftId` | string | Yes | ID of the draft to refine |
| `feedback` | string[] | Yes | Array of feedback items from reviewer |
| `language` | string | No | Language code (en, vi). Default: en |

---

## Response

```json
{
  "success": true,
  "data": {
    "draftId": "draft_xxx",
    "refinedContent": {
      "title": "Updated Title",
      "body": "Updated content...",
      "seo": {
        "metaDescription": "Updated description",
        "keywords": ["keyword1", "keyword2"]
      },
      "tags": ["tag1", "tag2"]
    },
    "changes": [
      "Condensed intro paragraph",
      "Removed promotional language",
      "Added explicit CTA button"
    ]
  }
}
```

---

## Constraints

### You MUST Preserve:
- ✅ Original intent and core message
- ✅ Verified facts and statistics
- ✅ Brand voice and tone guidelines
- ✅ SEO keywords (unless instructed to change)

### You MUST NOT:
- ❌ Introduce new claims without verification
- ❌ Change scope without explicit instruction
- ❌ Remove required legal disclaimers
- ❌ Alter technical specifications
- ❌ Publish automatically after refinement

---

## Workflow

```
Draft Rejected
     ↓
Feedback Received
     ↓
POST /skills/content/refine
     ↓
Refined Content
     ↓
Update Draft (PUT /drafts/:id)
     ↓
Resubmit for Approval
     ↓
Human Review
     ↓
Approve → Publish
```

---

## Example Usage

### Step 1: Get Draft with Feedback

```bash
curl -X GET https://reply-marketing-api.vercel.app/api/v1/drafts/draft_abc123 \
  -H "Authorization: Bearer $REPLY_CASH_AGENT_KEY"
```

### Step 2: Refine Based on Feedback

```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/skills/content/refine \
  -H "Authorization: Bearer $REPLY_CASH_AGENT_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "draftId": "draft_abc123",
    "feedback": [
      "Make the intro more concise",
      "Add specific use case examples",
      "Tone down marketing hype"
    ],
    "language": "en"
  }'
```

### Step 3: Update Draft

```bash
curl -X PUT https://reply-marketing-api.vercel.app/api/v1/drafts/draft_abc123 \
  -H "Authorization: Bearer $REPLY_CASH_AGENT_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "content": {
      "title": "Refined Title",
      "body": "Refined content...",
      "tags": ["updated", "tags"]
    }
  }'
```

### Step 4: Resubmit for Approval

```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/drafts/draft_abc123/submit-approval \
  -H "Authorization: Bearer $REPLY_CASH_AGENT_KEY"
```

---

## Common Feedback Types

| Feedback | Action |
|----------|--------|
| "Make it shorter" | Condense without losing meaning |
| "Add examples" | Include specific use cases |
| "Tone down" | Remove superlatives, use neutral language |
| "More technical" | Add implementation details |
| "Simplify" | Reduce jargon, shorter sentences |
| "Stronger CTA" | Add explicit call-to-action |

---

## Error Handling

```json
{
  "success": false,
  "error": {
    "code": "DRAFT_NOT_FOUND",
    "message": "Draft not found or access denied"
  }
}
```

| Error Code | Meaning |
|------------|---------|
| `DRAFT_NOT_FOUND` | Draft ID invalid or belongs to another agent |
| `NO_FEEDBACK` | Feedback array is empty |
| `REFINEMENT_FAILED` | Unable to apply requested changes |

---

## Notes

- Always resubmit refined content for approval
- Do not skip the approval workflow
- Keep a record of what changed and why
- If feedback conflicts, ask for clarification
