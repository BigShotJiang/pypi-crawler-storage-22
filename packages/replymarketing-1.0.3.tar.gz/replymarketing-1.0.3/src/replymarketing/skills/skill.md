---
name: reply-cash
version: 1.3.0
description: Marketing hub API for Reply Cash. Provides 35+ marketing skills for content creation, CRO, SEO, web scraping, Twitter remix, blog with images, analytics, and strategy.
homepage: https://reply-marketingz.vercel.app
docs: https://reply-marketingz.vercel.app/
metadata:
  {
    "agent":
      {
        "emoji": "💸",
        "category": "marketing",
        "api_base": "https://reply-marketing-api.vercel.app/api/v1",
        "skills_base": "https://reply-marketingz.vercel.app",
        "total_skills": 35
      },
  }
---

# Reply Cash Marketing Hub

**A marketing infrastructure API for content creation, validation, and publishing.**

This API provides 35+ specialized marketing capabilities across content, CRO, SEO, web scraping, Twitter remix, blog with images, analytics, and strategy - all integrated through a unified approval workflow.

---

## Authentication

Every agent needs an API key to use the service. **CRITICAL:** Always check for existing credentials before registering - do NOT create duplicate agents!

### Step 1: Check for Existing Credentials

**⚠️ IMPORTANT: Check local credentials FIRST before doing anything else!**

Before registering, check if credentials already exist locally:

```bash
# PRIORITY 1: Check if credentials exist locally
if [ -f ~/.config/replycash/credentials.json ]; then
  echo "✅ Credentials found! Using existing agent."
  cat ~/.config/replycash/credentials.json | jq
  
  # Verify credentials are still valid
  REPLY_CASH_AGENT_KEY=$(jq -r '.agentApiKey' ~/.config/replycash/credentials.json)
  HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" https://reply-marketing-api.vercel.app/api/v1/agents/me \
    -H "Authorization: Bearer $REPLY_CASH_AGENT_KEY")
  
  if [ "$HTTP_CODE" = "200" ]; then
    echo "✅ Credentials are valid. Skip registration and use these credentials."
    exit 0
  else
    echo "⚠️ Credentials found but invalid. Proceed to re-register."
  fi
else
  echo "❌ No credentials found. Proceed to registration."
fi
```

### Step 2: Register (Only if no credentials exist)

If no credentials exist, register a new agent:

```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/agents/register \
  -H "Content-Type: application/json" \
  -d '{"agentName": "YourAgentName", "metadata": {"purpose": "marketing"}}'
```

**Response:**
```json
{
  "success": true,
  "data": {
    "agentId": "agent_xxx",
    "agentApiKey": "rc_agent_key_xxx"
  }
}
```

⚠️ **Save your `agentApiKey` immediately!** You need it for all subsequent requests.

### Step 3: Store Credentials

Save credentials to `~/.config/replycash/credentials.json`:

```bash
mkdir -p ~/.config/replycash
cat > ~/.config/replycash/credentials.json << 'EOF'
{
  "agentId": "agent_xxx",
  "agentApiKey": "rc_agent_key_xxx",
  "agentName": "YourAgentName"
}
EOF
chmod 600 ~/.config/replycash/credentials.json
```

### Step 4: Verify

Test your API key:

```bash
REPLY_CASH_AGENT_KEY=$(jq -r '.agentApiKey' ~/.config/replycash/credentials.json)
curl -s https://reply-marketing-api.vercel.app/api/v1/agents/me \
  -H "Authorization: Bearer $REPLY_CASH_AGENT_KEY" | jq
```

---

## Overview

Reply Cash Marketing Hub is a backend service that provides:

- **Content Generation**: Convert changelogs, write copy, plan strategy
- **Brand Validation**: Check content against brand guidelines
- **Approval Workflow**: Human-in-the-loop review before publishing
- **Publishing**: Distribute approved content to blog and social channels

**API Base URL:** `https://reply-marketing-api.vercel.app/api/v1`  
**Skills Base URL:** `https://reply-marketingz.vercel.app`

---

## Quick Start

### For AI Agents

**👉 Read the Agent Guide:** `https://reply-marketingz.vercel.app/AGENT.md`

This guide provides:
- Step-by-step setup instructions
- Your role and responsibilities as an agent
- Complete workflow examples
- Common task patterns

### For Human Users

**👉 Read the Setup Instructions:** `https://reply-marketingz.vercel.app/INSTRUCTIONS.md`

This guide provides:
- Detailed curl examples
- Directory setup
- Complete workflow walkthrough

---

## Skill Files

| File | URL | Purpose |
|------|-----|---------|
| **SKILL.md** (this file) | `https://reply-marketingz.vercel.app/skill.md` | API overview |
| **AGENT.md** | `https://reply-marketingz.vercel.app/AGENT.md` | For AI Agents: Setup and workflow |
| **INSTRUCTIONS.md** | `https://reply-marketingz.vercel.app/INSTRUCTIONS.md` | For humans: Detailed setup |
| **skill.json** | `https://reply-marketingz.vercel.app/skill.json` | API metadata |
| **skills/** | `https://reply-marketingz.vercel.app/skills/` | Marketing skill library |

---

## API Capabilities

### Core API Skills (4)

| Endpoint | Purpose | Documentation |
|----------|---------|---------------|
| `POST /skills/changelog/to-marketing` | Convert changelogs to marketing content | [Read](./skills/changelog_to_marketing.md) |
| `POST /skills/brand/check` | Validate content against brand guidelines | [Read](./skills/brand_consistency_check.md) |
| `POST /skills/content/refine` | Refine drafts based on feedback | [Read](./skills/content_refine.md) |
| `POST /skills/distribution/plan` | Plan content distribution strategy | [Read](./skills/auto_distribution_plan.md) |

### Content Remix Skills (1)

| Endpoint | Purpose | Documentation |
|----------|---------|---------------|
| `POST /twitter/extract` | Extract tweet content for remixing | [Read](./skills/twitter-remix/SKILL.md) |

### Web Scraping Skills (5)

| Endpoint | Purpose | Documentation |
|----------|---------|---------------|
| `POST /skills/web/scrape` | Scrape any URL for content, HTML, markdown | [Read](./skills/web_scrape.md) |
| `POST /skills/web/extract` | Extract structured data using LLM | [Read](./skills/web_extract.md) |
| `POST /skills/web/crawl` | Crawl entire websites | [Read](./skills/web_crawl.md) |
| `GET /skills/web/crawl/{crawlId}` | Check crawl status | [Read](./skills/web_crawl.md) |
| `POST /skills/web/search` | Search web and scrape results | [Read](./skills/web_search.md) |
| `POST /skills/blog/generate-with-images` | Generate blog with images from scraped source | [Read](./skills/blog_generate_with_images.md) |

### Marketing Skills (24)

Available at: `https://reply-marketingz.vercel.app/skills/{skill-name}/SKILL.md`

- **Content:** copywriting, copy-editing, content-strategy, social-content, email-sequence
- **SEO:** seo-audit, programmatic-seo, schema-markup, competitor-alternatives
- **CRO:** page-cro, form-cro, signup-flow-cro, onboarding-cro, popup-cro
- **Strategy:** marketing-ideas, launch-strategy, referral-program, paid-ads
- **Analytics:** analytics-tracking, product-marketing-context

---

## Authentication

All API requests require an agent API key in the Authorization header:

```
Authorization: Bearer <agent_api_key>
```

Obtain an API key by registering at `POST /agents/register` (see Register First section above).

⚠️ **Security:**
- Only send API keys to `https://reply-marketing-api.vercel.app`
- Never share credentials with third parties

---

## Workflow

```
1. Register → Obtain API key
      ↓
2. Generate Content → Use marketing skills
      ↓
3. Validate → POST /skills/brand/check
      ↓
4. Submit Draft → POST /skills/marketing/submit-draft
      ↓
5. Human Review → Wait for approval/rejection
      ↓
6a. [Approved] → Publish
6b. [Rejected] → Refine and resubmit
```

**Key Principle:** All content requires human approval before publishing.

---

## Frontend URLs

When creating drafts, agents can share these frontend URLs with users:

| Page | URL Pattern | Description |
|------|-------------|-------------|
| **Draft List** | `https://reply-marketingz.vercel.app/approval/drafts/{agentId}` | View all drafts for an agent |
| **Draft Detail** | `https://reply-marketingz.vercel.app/approval/draft/{draftId}?token={approvalToken}` | Review and approve a specific draft |

**Example:**
- Draft list: `https://reply-marketingz.vercel.app/approval/drafts/agent_abc123`
- Draft detail: `https://reply-marketingz.vercel.app/approval/draft/draft_xyz789?token=xyz123...`

---

## Example API Calls

### Check Agent Info
```bash
curl https://reply-marketing-api.vercel.app/api/v1/agents/me \
  -H "Authorization: Bearer YOUR_API_KEY"
```

### Submit Draft
```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/skills/marketing/submit-draft \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "channel": "blog",
    "content": {
      "title": "Example Post",
      "body": "Content here with \\n\\n for paragraphs...",
      "category": "Artificial Intelligence",
      "tags": ["ai", "machine-learning", "technology"]
    }
  }'
```

**⚠️ Important Notes:**
- The `body` field must contain escaped newlines (`\n`) instead of actual line breaks
- **Always provide a meaningful `category`** (e.g., "Artificial Intelligence", "Mobile Money", "Remittances") - don't just use "blog"
- The `category` will be displayed on the blog listing page
- If no category is provided, the first tag will be used as category

### Check Brand Consistency
```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/skills/brand/check \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"content": {"type": "blog", "text": "Your content..."}}'
```

### Twitter - Extract Tweet for Remixing
```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/twitter/extract \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://x.com/username/status/1234567890"
  }'
```

**Response:**
```json
{
  "success": true,
  "data": {
    "tweet": {
      "id": "1234567890",
      "text": "Original tweet content...",
      "createdAt": "2024-01-15T10:30:00Z",
      "author": {
        "username": "username",
        "name": "User Name"
      },
      "metrics": {
        "likes": 1000,
        "replies": 100,
        "retweets": 500
      }
    },
    "extractedContent": "@username (User Name):\nOriginal tweet...\n\n[❤️ 1000 | 🔄 500 | 💬 100]",
    "quotedTweet": {
      "id": "0987654321",
      "text": "Quoted tweet..."
    }
  }
}
```

**Next Steps:** Your agent analyzes this content, selects an angle (Crypto Simplified, Cross-Border Hero, etc.), generates remixed content using AI, validates, and submits. See [twitter-remix skill](./skills/twitter-remix/SKILL.md) for full workflow.

### Web Scraping - Scrape a Blog Post
```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/skills/web/scrape \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://example.com/blog-post",
    "formats": ["markdown", "html", "links"],
    "onlyMainContent": true
  }'
```

**Response:**
```json
{
  "success": true,
  "data": {
    "markdown": "# Article Title\n\nArticle content in markdown...",
    "html": "<html>...</html>",
    "links": {
      "internal": ["/about", "/contact"],
      "external": ["https://other-site.com"]
    },
    "metadata": {
      "title": "Article Title",
      "description": "Article description",
      "ogImage": "https://example.com/image.jpg"
    }
  }
}
```

### Web Scraping - Extract Structured Data
```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/skills/web/extract \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://example.com/blog-post",
    "schema": {
      "title": { "type": "string" },
      "author": { "type": "string" },
      "publishDate": { "type": "string" },
      "mainContent": { "type": "string" },
      "keyPoints": { "type": "array", "items": { "type": "string" } }
    },
    "prompt": "Extract the key information from this blog post"
  }'
```

### Web Scraping - Crawl a Website
```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/skills/web/crawl \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://example.com",
    "maxDepth": 2,
    "limit": 10,
    "scrapeOptions": {
      "formats": ["markdown"],
      "onlyMainContent": true
    }
  }'
```

### Web Scraping - Search and Scrape
```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/skills/web/search \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "crypto payments Africa 2024",
    "limit": 5
  }'
```

### Blog Content with Images
Generate blog posts with automatically extracted images from source URLs:

```bash
curl -X POST https://reply-marketing-api.vercel.app/api/v1/skills/blog/generate-with-images \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "sourceUrl": "https://example.com/source-article",
    "title": "My Blog Post Title",
    "category": "Crypto Payments",
    "tags": ["stablecoins", "remittances", "africa"],
    "tone": "professional",
    "maxImages": 5,
    "includeScreenshots": false,
    "channel": "blog"
  }'
```

**Response:**
```json
{
  "success": true,
  "data": {
    "draftId": "draft_xxx",
    "title": "My Blog Post Title",
    "category": "Crypto Payments",
    "tags": ["stablecoins", "remittances", "africa"],
    "imageCount": 5,
    "heroImage": "https://example.com/hero.jpg",
    "seo": {
      "metaTitle": "My Blog Post Title",
      "metaDescription": "Description...",
      "keywords": ["stablecoins", "remittances"]
    },
    "source": {
      "url": "https://example.com/source-article",
      "title": "Original Article",
      "scrapedAt": "2024-01-15T10:30:00Z"
    }
  }
}
```

---

## Resources

- **API Base:** `https://reply-marketing-api.vercel.app/api/v1`
- **Health:** `https://reply-marketing-api.vercel.app/health`
- **Skills:** `https://reply-marketingz.vercel.app/skills/`
- **Frontend Base:** `https://reply-marketingz.vercel.app`

**Check for updates:** Re-fetch skill.md to see new features.
