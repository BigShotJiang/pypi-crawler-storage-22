"""Type definitions for ReplyMarketing CLI."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Literal, Optional


class MessageRole(Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    ERROR = "error"


@dataclass
class Message:
    role: MessageRole
    content: str
    timestamp: float
    skill_used: Optional[str] = None


@dataclass
class SkillMetadata:
    name: str
    description: str
    file: str
    url: str
    version: Optional[str] = None
    endpoint: Optional[str] = None


@dataclass
class Skill:
    id: str
    name: str
    description: str
    category: str
    keywords: list[str]
    file_path: str
    metadata: SkillMetadata
    capabilities: list[str]


@dataclass
class Credentials:
    agent_id: str
    agent_api_key: str
    agent_name: str


@dataclass
class AgentInfo:
    agent_id: str
    agent_name: str
    status: str
    metadata: Optional[dict[str, Any]] = None


@dataclass
class ProviderInfo:
    name: str
    type: Literal["cli", "api"]
    available: bool
    path: Optional[str] = None
    version: Optional[str] = None
    model: Optional[str] = None
    api_key_source: Optional[str] = None


@dataclass
class ProviderConfig:
    name: str
    type: Literal["cli", "api"]
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    model: Optional[str] = None


@dataclass
class ExecutionContext:
    skill: Optional[str] = None
    credentials: Optional[Credentials] = None
    context: list[Message] = field(default_factory=list)


@dataclass
class ExecutionResult:
    content: str
    metadata: Optional[dict[str, Any]] = None


@dataclass
class ConversationContext:
    current_skill: Optional[str] = None
    messages: list[Message] = field(default_factory=list)


@dataclass
class WorkflowStep:
    order: int
    skill: str
    task: str
    purpose: str
    depends_on: Optional[int] = None


@dataclass
class WorkflowAnalysis:
    is_workflow: bool
    primary_intent: str
    steps: list[WorkflowStep]
    estimated_time: str
    can_parallelize: bool


@dataclass
class WorkflowResult:
    step: WorkflowStep
    output: str
    duration: float
    success: bool
    error: Optional[str] = None


@dataclass
class WorkflowContext:
    original_input: str
    steps: list[WorkflowResult]
    shared_data: dict[str, Any] = field(default_factory=dict)


@dataclass
class ApiResponse:
    success: bool
    data: Optional[Any] = None
    error: Optional[str] = None


@dataclass
class CommandItem:
    command: str
    description: str
    aliases: list[str] = field(default_factory=list)
