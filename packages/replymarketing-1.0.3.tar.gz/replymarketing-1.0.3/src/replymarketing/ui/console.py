"""Console configuration for ReplyMarketing CLI UI."""

from __future__ import annotations

from rich.console import Console
from rich.theme import Theme

_NEUTRAL_THEME = Theme(
    {
        "info": "dim cyan",
        "warning": "yellow",
        "error": "bold red",
        "success": "bold green",
        "prompt": "bold green",
        "muted": "dim",
    },
    inherit=True,
)

console = Console(highlight=False, theme=_NEUTRAL_THEME)
