"""Logging utility for ReplyMarketing CLI."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Optional

from .config import CONFIG_DIR

LOG_FILE = CONFIG_DIR / "debug.log"


class Logger:
    """Simple async-capable logger."""

    @staticmethod
    def _write(level: str, message: str, data: Optional[Any] = None) -> None:
        """Write log entry to file."""
        timestamp = datetime.now().isoformat()
        log_entry = f"[{timestamp}] [{level}] {message}"

        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            with open(LOG_FILE, "a") as f:
                f.write(log_entry + "\n")
                if data is not None:
                    f.write(json.dumps(data, indent=2, default=str) + "\n")
        except Exception:
            # Silent fail for logging
            pass

    @classmethod
    def debug(cls, message: str, data: Optional[Any] = None) -> None:
        """Log debug message."""
        cls._write("DEBUG", message, data)

    @classmethod
    def info(cls, message: str, data: Optional[Any] = None) -> None:
        """Log info message."""
        cls._write("INFO", message, data)

    @classmethod
    def error(cls, message: str, error: Optional[Any] = None) -> None:
        """Log error message."""
        cls._write("ERROR", message, error)

    @classmethod
    def warn(cls, message: str, data: Optional[Any] = None) -> None:
        """Log warning message."""
        cls._write("WARN", message, data)
