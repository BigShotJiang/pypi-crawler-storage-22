"""Tests for ReplyMarketing CLI."""
