"""Test version module."""


from replymarketing import __version__
from replymarketing.utils.version import get_current_version, get_update_command


def test_version():
    """Test version is defined and follows semver format."""
    assert isinstance(__version__, str)
    # Check version follows semver format (e.g., 1.0.2)
    parts = __version__.split(".")
    assert len(parts) == 3
    assert all(p.isdigit() for p in parts)


def test_get_current_version():
    """Test get_current_version returns the version."""
    assert get_current_version() == __version__


def test_get_update_command():
    """Test get_update_command returns a string."""
    cmd = get_update_command()
    assert isinstance(cmd, str)
    assert "replymarketing" in cmd
