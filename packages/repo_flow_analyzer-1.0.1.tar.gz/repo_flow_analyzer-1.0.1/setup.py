from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="repo-flow-analyzer",
    version="1.0.1",
    author="Platform Team",
    author_email="platform-team@company.com",
    description="A universal tool to analyze and visualize code flow in any repository",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourorg/repo-flow-analyzer",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Documentation",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.7",
    install_requires=[
        "click>=8.0.0",
        "pyyaml>=5.4.0",
        "jinja2>=3.0.0",
        "colorama>=0.4.4",
    ],
    entry_points={
        "console_scripts": [
            "flow-analyzer=flow_analyzer.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "flow_analyzer": ["templates/*.j2", "config/*.yaml"],
    },
)