# Reportify API CLI

通过命令行访问 [Reportify SDK](https://github.com/reportify-ai/reportify-doc/tree/main/sdks) 的所有功能。

## 特性

- 🚀 **完整功能** - 支持 Reportify SDK 的所有 8 个模块、44+ 个方法
- 📊 **多种输出格式** - JSON、Table、CSV、Markdown
- 🎯 **简单易用** - 统一的 JSON 输入格式，清晰的帮助文档
- 🤖 **AI 友好** - 专为 AI Agent 设计，提供详细的参数说明

## 安装

```bash
# 安装依赖并安装 CLI
make install

# 或使用 uv 直接安装
uv pip install -e .
```

## 配置

设置 API Key（必需）：

```bash
# 方式 1: 环境变量
export REPORTIFY_API_KEY='your-api-key'

# 方式 2: .env 文件
echo "REPORTIFY_API_KEY=your-api-key" > .env
```

## 快速开始

```bash
# 查看帮助
reportify-cli --help
reportify-cli -h

# 查看模块帮助
reportify-cli docs --help

# 查看命令帮助
reportify-cli docs get --help

# 获取文档详情（JSON 格式）
reportify-cli docs get --input '{"doc_id": "1214713494948155392"}'

# 获取股票行情（Table 格式）
reportify-cli stock quote --input '{"symbol": "600519"}' --format table

# 获取财务数据（Markdown 格式）
reportify-cli stock income_statement \
  --input '{"symbol": "600519", "period": "annual"}' \
  --format markdown
```

## 可用模块

| 模块 | 说明 | 命令数 |
|------|------|--------|
| `search` | 文档搜索功能 | 9 |
| `docs` | 文档内容功能 | 4 |
| `stock` | 股票数据功能 | 14 |
| `timeline` | 时间线功能 | 5 |
| `kb` | 知识库功能 | 1 |
| `user` | 用户数据功能 | 1 |
| `quant` | 量化分析功能 | 8 |
| `concepts` | 概念动态功能 | 2 |

## 输出格式

支持 4 种输出格式：

- `--format json` - JSON 格式（默认）
- `--format table` - 表格格式
- `--format csv` - CSV 格式
- `--format markdown` 或 `--format md` - Markdown 表格

## 开发

```bash
# 查看所有可用命令
make help

# 运行测试
make test

# 运行单元测试
make test-unit

# 运行集成测试（需要 API Key）
make test-integration

# 代码格式化
make format

# 代码检查
make lint

# 清理缓存
make clean

# 重新安装
make reinstall
```

## 项目结构

```
reportify-cli/
├── src/                    # 源代码
│   ├── main.py            # CLI 入口
│   ├── commands/          # 命令模块
│   ├── client.py          # SDK 客户端
│   ├── output.py          # 输出格式化
│   ├── params.py          # 参数定义
│   ├── settings.py        # 配置管理
│   └── utils.py           # 工具函数
├── tests/                 # 测试
│   ├── test_commands/     # 单元测试
│   └── integration/       # 集成测试
├── Makefile              # 开发命令
├── pyproject.toml        # 项目配置
└── README.md             # 项目文档
```

## 示例

### 搜索文档

```bash
reportify-cli search query \
  --input '{"query": "茅台", "limit": 10}'
```

### 获取股票数据

```bash
# 公司概览
reportify-cli stock overview --input '{"symbol": "600519"}'

# 财务报表
reportify-cli stock income_statement \
  --input '{"symbol": "600519", "period": "annual"}'

# 股价数据
reportify-cli stock prices \
  --input '{"symbol": "600519", "start_date": "2024-01-01", "end_date": "2024-12-31"}'
```

### 量化分析

```bash
# 计算技术指标
reportify-cli quant indicators_compute \
  --input '{"symbols": ["600519"], "formula": "RSI(14)"}' \
  --format table
```

