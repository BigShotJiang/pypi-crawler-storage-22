# Reportify API CLI Commands Reference

## Search Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `query` | Search all document types | `query` |
| `news` | Search news articles | `query` |
| `reports` | Search research reports | `query` |
| `filings` | Search company filings | `query`, `symbols` |
| `conference_calls` | Search for earnings-related conference call transcripts and presentation slides (query optional) | `symbols` |
| `earnings_pack` | Search for earnings-related documents submitted to exchanges (query optional) | `symbols` |
| `minutes` | Search conference calls and IR meetings | `query` |
| `socials` | Search social media posts | `query` |
| `webpages` | Search web pages | `query` |

## Docs Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `get` | Get document content | `doc_id` |
| `summary` | Get document summary | `doc_id` |
| `list_by_symbol` | List documents by stock | `symbol` |
| `list_by_label` | List documents by label | `label` |

## Stock Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `overview` | Company overview | `symbols` or `names` |
| `shareholders` | Shareholder information | `symbol` |
| `income_statement` | Income statement | `symbol` |
| `balance_sheet` | Balance sheet | `symbol` |
| `cashflow_statement` | Cash flow statement | `symbol` |
| `revenue_breakdown` | Revenue breakdown | `symbol` |
| `prices` | Historical prices | `symbol` |
| `quote` | Real-time quote | `symbol` |
| `index_constituents` | Index constituents | `symbol` |
| `index_tracking_funds` | Index tracking funds | `symbol` |
| `industry_constituents` | Industry constituents | `market`, `name` |
| `screener` | Stock screener | (optional filters) |
| `earnings_calendar` | Earnings calendar | `market` |
| `ipo_calendar_hk` | HK IPO calendar | (optional) |

## Timeline Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `companies` | Company timeline | (optional) |
| `topics` | Topic timeline | (optional) |
| `institutes` | Institute timeline | (optional) |
| `public_media` | Public media timeline | (optional) |
| `social_media` | Social media timeline | (optional) |

## KB Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `search` | Search knowledge base | `query` |

## User Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `followed_companies` | Get followed companies | (none) |

## Quant Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `indicators` | List available indicators | (none) |
| `indicators_compute` | Compute technical indicators | `symbols`, `formula` |
| `factors` | List available factors | (none) |
| `factors_compute` | Compute factors | `symbols`, `formula` |
| `factors_screen` | Stock screening | `formula` |
| `ohlcv` | Get OHLCV data | `symbol` |
| `ohlcv_batch` | Batch OHLCV data | `symbols` |
| `backtest` | Run backtest | `symbol`, `start_date`, `end_date`, `entry_formula` |

## Concepts Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `latest` | Latest concept dynamics | (optional) |
| `today` | Today's concepts | (none) |

