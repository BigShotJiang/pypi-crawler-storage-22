"""Channels module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(help="频道管理功能", rich_markup_mode="rich")


@app.command(
    epilog=generate_epilog(
        params.CHANNELS_SEARCH_PARAMS,
        [
            'reportify-cli channels search --input \'{"query": "Goldman Sachs"}\'',
            'reportify-cli channels search --input \'{"query": "财经", "page_size": 20}\'',
        ],
    )
)
def search(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """搜索频道"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.channels.search(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.CHANNELS_FOLLOWINGS_PARAMS,
        [
            "reportify-cli channels followings",
            'reportify-cli channels followings --input \'{"page_size": 20}\'',
        ],
    )
)
def followings(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取关注的频道列表"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.channels.followings(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.CHANNELS_FOLLOW_PARAMS,
        [
            'reportify-cli channels follow --input \'{"channel_id": "channel_123"}\'',
        ],
    )
)
def follow(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """关注频道"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        channel_id = params_dict.get("channel_id")
        if not channel_id:
            raise ValueError("channel_id is required")
        result = client.channels.follow(channel_id)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.CHANNELS_UNFOLLOW_PARAMS,
        [
            'reportify-cli channels unfollow --input \'{"channel_id": "channel_123"}\'',
        ],
    )
)
def unfollow(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """取消关注频道"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        channel_id = params_dict.get("channel_id")
        if not channel_id:
            raise ValueError("channel_id is required")
        result = client.channels.unfollow(channel_id)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="get_docs",
    epilog=generate_epilog(
        params.CHANNELS_GET_DOCS_PARAMS,
        [
            "reportify-cli channels get_docs",
            'reportify-cli channels get_docs --input \'{"channel_ids": "channel_1,channel_2", "page_size": 20}\'',
        ],
    ),
)
def get_docs(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取关注频道的文档"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.channels.get_docs(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
