"""Concepts module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(help="概念动态功能", rich_markup_mode="rich")


@app.command(
    epilog=generate_epilog(
        params.CONCEPTS_LATEST_PARAMS,
        [
            "reportify-cli concepts latest",
            "reportify-cli concepts latest --input '{\"include_docs\": false}'",
        ],
    )
)
def latest(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取最新概念列表"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.concepts.latest(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(params.CONCEPTS_TODAY_PARAMS, ["reportify-cli concepts today"])
)
def today(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取今日概念动态"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.concepts.today(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
