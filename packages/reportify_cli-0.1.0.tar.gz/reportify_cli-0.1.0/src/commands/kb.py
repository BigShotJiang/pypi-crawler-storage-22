"""KB (Knowledge Base) module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(help="知识库功能 - 搜索用户上传的私有文档", rich_markup_mode="rich")


@app.command(
    epilog=generate_epilog(
        params.KB_SEARCH_PARAMS,
        [
            'reportify-cli kb search --input \'{"query": "投资策略", "num": 10}\'',
            'reportify-cli kb search --input \'{"query": "季度报告", "folder_ids": ["folder_abc123"]}\'',
        ],
    )
)
def search(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """在知识库中搜索文档"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.kb.search(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
