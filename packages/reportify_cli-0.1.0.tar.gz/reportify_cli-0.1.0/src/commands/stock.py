"""Stock module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(help="股票数据功能", rich_markup_mode="rich")


@app.command(
    epilog=generate_epilog(
        params.STOCK_OVERVIEW_PARAMS,
        [
            'reportify-cli stock overview --input \'{"symbols": "AAPL,00700"}\'',
            'reportify-cli stock overview --input \'{"names": "腾讯,苹果"}\'',
        ],
    )
)
def overview(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取公司概览信息：公司名称、所属行业、主营业务等"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.stock.overview(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.STOCK_SHAREHOLDERS_PARAMS,
        ['reportify-cli stock shareholders --input \'{"symbol": "AAPL"}\''],
    )
)
def shareholders(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取主要股东列表"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.stock.shareholders(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="income_statement",
    epilog=generate_epilog(
        params.STOCK_INCOME_STATEMENT_PARAMS,
        [
            'reportify-cli stock income_statement --input \'{"symbol": "AAPL", "period": "quarterly"}\'',
        ],
    ),
)
def income_statement(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取利润表数据"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.stock.income_statement(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="balance_sheet",
    epilog=generate_epilog(
        params.STOCK_BALANCE_SHEET_PARAMS,
        [
            'reportify-cli stock balance_sheet --input \'{"symbol": "AAPL", "period": "annual"}\''
        ],
    ),
)
def balance_sheet(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取资产负债表数据"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.stock.balance_sheet(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="cashflow_statement",
    epilog=generate_epilog(
        params.STOCK_CASHFLOW_STATEMENT_PARAMS,
        ['reportify-cli stock cashflow_statement --input \'{"symbol": "AAPL"}\''],
    ),
)
def cashflow_statement(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取现金流量表数据"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.stock.cashflow_statement(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="revenue_breakdown",
    epilog=generate_epilog(
        params.STOCK_REVENUE_BREAKDOWN_PARAMS,
        ['reportify-cli stock revenue_breakdown --input \'{"symbol": "AAPL", "limit": 6}\''],
    ),
)
def revenue_breakdown(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取营收分解数据"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.stock.revenue_breakdown(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.STOCK_QUOTE_PARAMS,
        [
            'reportify-cli stock quote --input \'{"symbol": "AAPL", "start_date": "2024-01-01"}\''
        ],
    )
)
def quote(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取股票行情数据：价格、成交量、市净率、市销率、股息率等"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.stock.quote(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="index_constituents",
    epilog=generate_epilog(
        params.STOCK_INDEX_CONSTITUENTS_PARAMS,
        ['reportify-cli stock index_constituents --input \'{"symbol": "000300"}\''],
    ),
)
def index_constituents(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取指数成分股列表"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.stock.index_constituents(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="index_tracking_funds",
    epilog=generate_epilog(
        params.STOCK_INDEX_TRACKING_FUNDS_PARAMS,
        ['reportify-cli stock index_tracking_funds --input \'{"symbol": "000300"}\''],
    ),
)
def index_tracking_funds(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取指数跟踪基金列表"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.stock.index_tracking_funds(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="industry_constituents",
    epilog=generate_epilog(
        params.STOCK_INDUSTRY_CONSTITUENTS_PARAMS,
        [
            'reportify-cli stock industry_constituents --input \'{"market": "cn", "name": "军工"}\''
        ],
    ),
)
def industry_constituents(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取行业成分股列表"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.stock.industry_constituents(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="earnings_calendar",
    epilog=generate_epilog(
        params.STOCK_EARNINGS_CALENDAR_PARAMS,
        [
            'reportify-cli stock earnings_calendar --input \'{"market": "us", "start_date": "2024-01-01"}\'',
        ],
    ),
)
def earnings_calendar(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取财报日历"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.stock.earnings_calendar(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="ipo_calendar_hk",
    epilog=generate_epilog(
        params.STOCK_IPO_CALENDAR_HK_PARAMS,
        [
            "reportify-cli stock ipo_calendar_hk",
            'reportify-cli stock ipo_calendar_hk --input \'{"status": "Priced"}\'',
        ],
    ),
)
def ipo_calendar_hk(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取香港 IPO 日历"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.stock.ipo_calendar_hk(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="index_quote",
    epilog=generate_epilog(
        params.STOCK_INDEX_QUOTE_PARAMS,
        [
            'reportify-cli stock index_quote --input \'{"symbol": "000300"}\'',
            'reportify-cli stock index_quote --input \'{"symbol": "HSI", "start_date": "2024-01-01"}\'',
        ],
    ),
)
def index_quote(
    input: Annotated[str, typer.Option(help="JSON 格式的输入参数")] = "{}",
    format: Annotated[str, typer.Option(help="输出格式: json, table, csv")] = "json",
):
    """获取指数行情数据"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.stock.index_quote(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
