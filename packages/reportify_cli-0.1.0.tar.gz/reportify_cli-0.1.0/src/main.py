"""Main entry point for Reportify API CLI."""

import typer
from typer.core import TyperGroup

from src.commands import channels, concepts, docs, kb, quant, search, stock, timeline, user


class AliasGroup(TyperGroup):
    """Custom TyperGroup that supports -h as alias for --help."""

    def parse_args(self, ctx, args):
        # Replace -h with --help
        args = ["--help" if arg == "-h" else arg for arg in args]
        return super().parse_args(ctx, args)


app = typer.Typer(
    help="Reportify API CLI - 通过命令行访问 Reportify SDK 的所有功能",
    rich_markup_mode="rich",
    no_args_is_help=True,
    cls=AliasGroup,
)

# Add all command modules as sub-apps
app.add_typer(search.app, name="search", help="文档搜索功能")
app.add_typer(docs.app, name="docs", help="文档内容功能")
app.add_typer(kb.app, name="kb", help="知识库功能")
app.add_typer(stock.app, name="stock", help="股票数据功能")
app.add_typer(quant.app, name="quant", help="量化分析功能")
app.add_typer(timeline.app, name="timeline", help="时间线功能")
app.add_typer(channels.app, name="channels", help="频道管理功能")
app.add_typer(concepts.app, name="concepts", help="概念动态功能")
app.add_typer(user.app, name="user", help="用户数据功能")


def main():
    """Main entry point."""
    app()


if __name__ == "__main__":
    main()
