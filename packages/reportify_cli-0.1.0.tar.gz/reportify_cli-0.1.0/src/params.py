"""Parameter metadata definitions for all SDK methods."""

from dataclasses import dataclass
from typing import Any


@dataclass
class ParamDef:
    """Parameter definition."""

    name: str
    type: str
    description: str
    required: bool = False
    default: Any | None = None


# Search module parameters
SEARCH_ALL_PARAMS = [
    ParamDef("query", "string", "搜索关键词", required=True),
    ParamDef("num", "int", "返回结果数量，最大 100", default=10),
    ParamDef(
        "categories", "list[str]", "文档类别过滤: news, reports, filings, transcripts, socials"
    ),
    ParamDef("symbols", "list[str]", "股票代码过滤，格式: market:ticker，如 ['US:AAPL', 'HK:00700', 'SH:600519', 'SZ:000001']"),
    ParamDef("industries", "list[str]", "行业过滤"),
    ParamDef("channel_ids", "list[str]", "渠道 ID 过滤"),
    ParamDef("start_datetime", "str", "开始时间，格式: YYYY-MM-DD 或 YYYY-MM-DD HH:MM:SS"),
    ParamDef("end_datetime", "str", "结束时间，格式: YYYY-MM-DD 或 YYYY-MM-DD HH:MM:SS"),
]

SEARCH_NEWS_PARAMS = [
    ParamDef("query", "string", "搜索关键词", required=True),
    ParamDef("num", "int", "返回结果数量", default=10),
    ParamDef("symbols", "list[str]", "股票代码过滤，格式: market:ticker，如 US:AAPL, HK:00700"),
    ParamDef("channel_ids", "list[str]", "渠道 ID 过滤"),
    ParamDef("start_datetime", "str", "开始时间"),
    ParamDef("end_datetime", "str", "结束时间"),
]

SEARCH_REPORTS_PARAMS = [
    ParamDef("query", "string", "搜索关键词", required=True),
    ParamDef("num", "int", "返回结果数量", default=10),
    ParamDef("symbols", "list[str]", "股票代码过滤，格式: market:ticker，如 US:AAPL, HK:00700"),
    ParamDef("industries", "list[str]", "行业过滤"),
    ParamDef("channel_ids", "list[str]", "渠道 ID 过滤"),
    ParamDef("start_datetime", "str", "开始时间"),
    ParamDef("end_datetime", "str", "结束时间"),
]

SEARCH_FILINGS_PARAMS = [
    ParamDef("query", "string", "搜索关键词", required=True),
    ParamDef("symbols", "list[str]", "股票代码列表，格式: market:ticker，如 US:AAPL, HK:00700（必填）", required=True),
    ParamDef("num", "int", "返回结果数量", default=10),
    ParamDef("start_datetime", "str", "开始时间"),
    ParamDef("end_datetime", "str", "结束时间"),
]

SEARCH_CONFERENCE_CALLS_PARAMS = [
    ParamDef("query", "string", "Search query (optional). If not provided, returns documents sorted by date desc; if provided, sorts by relevance"),
    ParamDef("symbols", "list[str]", "Stock symbols in market:ticker format, e.g. US:AAPL, HK:00700 (required)", required=True),
    ParamDef("num", "int", "Number of results to return", default=10),
    ParamDef("start_datetime", "str", "Start datetime filter"),
    ParamDef("end_datetime", "str", "End datetime filter"),
    ParamDef("fiscal_year", "str", "Fiscal year filter, e.g. '2025'"),
    ParamDef("fiscal_quarter", "str", "Fiscal quarter filter, e.g. 'Q1', 'Q2', 'Q3', 'Q4'"),
    ParamDef("sort_by", "str", "Sort order: 'date_desc' (default when no query), 'relevance' (recommended when query provided), 'date_asc'", default="date_desc"),
]

SEARCH_EARNINGS_PACK_PARAMS = [
    ParamDef("query", "string", "Search query (optional). If not provided, returns documents sorted by date desc; if provided, sorts by relevance"),
    ParamDef("symbols", "list[str]", "Stock symbols in market:ticker format, e.g. US:AAPL, HK:00700 (required)", required=True),
    ParamDef("num", "int", "Number of results to return", default=10),
    ParamDef("start_datetime", "str", "Start datetime filter"),
    ParamDef("end_datetime", "str", "End datetime filter"),
    ParamDef("fiscal_year", "str", "Fiscal year filter"),
    ParamDef("fiscal_quarter", "str", "Fiscal quarter filter"),
    ParamDef("sort_by", "str", "Sort order: 'date_desc' (default when no query), 'relevance' (recommended when query provided), 'date_asc'", default="date_desc"),
]

SEARCH_MINUTES_PARAMS = [
    ParamDef("query", "string", "搜索关键词", required=True),
    ParamDef("num", "int", "返回结果数量", default=10),
    ParamDef("symbols", "list[str]", "股票代码过滤，格式: market:ticker，如 US:AAPL, HK:00700"),
    ParamDef("start_datetime", "str", "开始时间"),
    ParamDef("end_datetime", "str", "结束时间"),
]

SEARCH_SOCIALS_PARAMS = [
    ParamDef("query", "string", "搜索关键词", required=True),
    ParamDef("num", "int", "返回结果数量", default=10),
    ParamDef("symbols", "list[str]", "股票代码过滤，格式: market:ticker，如 US:AAPL, HK:00700"),
    ParamDef("channel_ids", "list[str]", "渠道 ID 过滤"),
    ParamDef("start_datetime", "str", "开始时间"),
    ParamDef("end_datetime", "str", "结束时间"),
]

SEARCH_WEBPAGES_PARAMS = [
    ParamDef("query", "string", "搜索关键词", required=True),
    ParamDef("num", "int", "返回结果数量", default=10),
    ParamDef("start_datetime", "str", "开始时间"),
    ParamDef("end_datetime", "str", "结束时间"),
]

# Docs module parameters
DOCS_GET_PARAMS = [
    ParamDef("doc_id", "string", "文档 ID", required=True),
]

DOCS_SUMMARY_PARAMS = [
    ParamDef("doc_id", "string", "文档 ID", required=True),
]

DOCS_LIST_BY_SYMBOL_PARAMS = [
    ParamDef("symbol", "string", "股票代码，格式: 市场:代码", required=True),
    ParamDef("categories", "list[str]", "文档类别筛选"),
    ParamDef("num", "int", "返回数量", default=10),
    ParamDef("start_date", "str", "开始日期"),
    ParamDef("end_date", "str", "结束日期"),
]

DOCS_LIST_BY_LABEL_PARAMS = [
    ParamDef("label", "string", "文档标签", required=True),
    ParamDef("num", "int", "返回数量", default=10),
    ParamDef("start_date", "str", "开始日期"),
    ParamDef("end_date", "str", "结束日期"),
]

DOCS_RAW_CONTENT_PARAMS = [
    ParamDef("doc_id", "string", "文档 ID", required=True),
]

DOCS_LIST_PARAMS = [
    ParamDef("symbols", "list[str]", "股票代码列表，格式: market:ticker，如 US:AAPL, HK:00700"),
    ParamDef("categories", "list[str]", "文档类别过滤: financials, transcripts, reports, news, files, filings, socials"),
    ParamDef("markets", "list[str]", "市场过滤: cn, hk, us"),
    ParamDef("institutions", "list[str]", "机构过滤"),
    ParamDef("tags", "dict", "标签过滤（字典格式）"),
    ParamDef("folder_ids", "list[str]", "文件夹 ID 过滤"),
    ParamDef("start_date", "str", "开始日期，格式: YYYY-MM-DD"),
    ParamDef("end_date", "str", "结束日期，格式: YYYY-MM-DD"),
    ParamDef("min_score", "float", "最小相关性分数"),
    ParamDef("extended_filters", "list[dict]", "扩展过滤条件"),
    ParamDef("page_num", "int", "页码", default=1),
    ParamDef("page_size", "int", "每页数量", default=10),
]

DOCS_SEARCH_PARAMS = [
    ParamDef("query", "string", "搜索关键词"),
    ParamDef("symbols", "list[str]", "股票代码列表"),
    ParamDef("categories", "list[str]", "文档类别过滤"),
    ParamDef("markets", "list[str]", "市场过滤"),
    ParamDef("institutions", "list[str]", "机构过滤"),
    ParamDef("tags", "dict", "标签过滤"),
    ParamDef("folder_ids", "list[str]", "文件夹 ID 过滤"),
    ParamDef("start_date", "str", "开始日期"),
    ParamDef("end_date", "str", "结束日期"),
    ParamDef("min_score", "float", "最小相关性分数"),
    ParamDef("extended_filters", "list[dict]", "扩展过滤条件"),
    ParamDef("num", "int", "返回结果数量", default=10),
]

DOCS_SEARCH_CHUNKS_PARAMS = [
    ParamDef("query", "string", "搜索关键词", required=True),
    ParamDef("symbols", "list[str]", "股票代码列表"),
    ParamDef("categories", "list[str]", "文档类别过滤"),
    ParamDef("markets", "list[str]", "市场过滤"),
    ParamDef("institutions", "list[str]", "机构过滤"),
    ParamDef("tags", "dict", "标签过滤"),
    ParamDef("folder_ids", "list[str]", "文件夹 ID 过滤"),
    ParamDef("doc_ids", "list[str]", "文档 ID 过滤"),
    ParamDef("start_date", "str", "开始日期"),
    ParamDef("end_date", "str", "结束日期"),
    ParamDef("min_score", "float", "最小相关性分数"),
    ParamDef("extended_filters", "list[dict]", "扩展过滤条件"),
    ParamDef("num", "int", "返回结果数量", default=10),
    ParamDef("include_doc_extra_details", "bool", "包含额外文档详情", default=False),
    ParamDef("refine_question", "bool", "优化搜索问题", default=False),
    ParamDef("date_range", "str", "日期范围: h, d, w, m, y"),
]

DOCS_CREATE_FOLDER_PARAMS = [
    ParamDef("name", "string", "文件夹名称", required=True),
]

DOCS_DELETE_FOLDER_PARAMS = [
    ParamDef("folder_id", "string", "文件夹 ID", required=True),
]

DOCS_UPLOAD_PARAMS = [
    ParamDef("docs", "list[dict]", "文档列表，每个文档包含 url, name 等字段", required=True),
    ParamDef("folder_id", "str", "文件夹 ID（可选）"),
    ParamDef("pdf_parsing_mode", "int", "PDF 解析模式: 1=按页, 3=按逻辑", default=1),
]

DOCS_UPLOAD_ASYNC_PARAMS = [
    ParamDef("docs", "list[dict]", "文档列表，每个文档包含 url, name 等字段", required=True),
    ParamDef("folder_id", "str", "文件夹 ID（可选）"),
    ParamDef("pdf_parsing_mode", "int", "PDF 解析模式: 1=按页, 3=按逻辑", default=1),
]

DOCS_GET_UPLOAD_STATUS_PARAMS = [
    ParamDef("doc_id", "string", "文档 ID", required=True),
]

DOCS_DELETE_PARAMS = [
    ParamDef("doc_ids", "list[str]", "要删除的文档 ID 列表", required=True),
]

# Stock module parameters
STOCK_OVERVIEW_PARAMS = [
    ParamDef("symbols", "string", "股票代码，支持多个用逗号分隔，如 'AAPL,00700'"),
    ParamDef("names", "string", "股票名称，支持多个用逗号分隔，如 '腾讯,苹果'"),
]

STOCK_SHAREHOLDERS_PARAMS = [
    ParamDef("symbol", "string", "股票代码", required=True),
]

STOCK_INCOME_STATEMENT_PARAMS = [
    ParamDef("symbol", "string", "股票代码", required=True),
    ParamDef("period", "string", "报告期间: annual（年报）或 quarterly（季报）", default="annual"),
    ParamDef("limit", "int", "返回期数", default=8),
    ParamDef("start_date", "str", "开始日期，格式: YYYY-MM-DD"),
    ParamDef("end_date", "str", "结束日期，格式: YYYY-MM-DD"),
    ParamDef("calendar", "str", "日历类型: calendar（公历）或 fiscal（财年）", default="fiscal"),
    ParamDef("fiscal_year", "str", "指定财年，如 '2023'"),
    ParamDef("fiscal_quarter", "str", "指定财季: Q1, Q2, Q3, Q4, FY, H1"),
]

STOCK_BALANCE_SHEET_PARAMS = [
    ParamDef("symbol", "string", "股票代码", required=True),
    ParamDef("period", "string", "报告期间: annual 或 quarterly", default="annual"),
    ParamDef("limit", "int", "返回期数", default=8),
    ParamDef("start_date", "str", "开始日期"),
    ParamDef("end_date", "str", "结束日期"),
    ParamDef("calendar", "str", "日历类型: calendar 或 fiscal", default="fiscal"),
    ParamDef("fiscal_year", "str", "指定财年"),
    ParamDef("fiscal_quarter", "str", "指定财季"),
]

STOCK_CASHFLOW_STATEMENT_PARAMS = [
    ParamDef("symbol", "string", "股票代码", required=True),
    ParamDef(
        "period", "string", "报告期间: annual, quarterly 或 cumulative quarterly", default="annual"
    ),
    ParamDef("limit", "int", "返回期数", default=8),
    ParamDef("start_date", "str", "开始日期"),
    ParamDef("end_date", "str", "结束日期"),
    ParamDef("calendar", "str", "日历类型: calendar 或 fiscal", default="fiscal"),
    ParamDef("fiscal_year", "str", "指定财年"),
    ParamDef("fiscal_quarter", "str", "指定财季"),
]

STOCK_REVENUE_BREAKDOWN_PARAMS = [
    ParamDef("symbol", "string", "股票代码", required=True),
    ParamDef("period", "str", "报告周期，如 'FY', 'Q2'"),
    ParamDef("limit", "int", "返回记录数", default=6),
    ParamDef("start_date", "str", "开始日期"),
    ParamDef("end_date", "str", "结束日期"),
    ParamDef("fiscal_year", "str", "指定财年"),
]

STOCK_QUOTE_PARAMS = [
    ParamDef("symbol", "string", "股票代码，如 'AAPL', '688001', '00700'", required=True),
    ParamDef("start_date", "str", "开始日期，格式: YYYY-MM-DD"),
    ParamDef("end_date", "str", "结束日期，格式: YYYY-MM-DD"),
]

STOCK_INDEX_CONSTITUENTS_PARAMS = [
    ParamDef(
        "symbol", "string", "指数代码，如 '000300'（沪深300）, '399006'（创业板指）", required=True
    ),
]

STOCK_INDEX_TRACKING_FUNDS_PARAMS = [
    ParamDef("symbol", "string", "指数代码，如 '000300', '000905'", required=True),
]

STOCK_INDUSTRY_CONSTITUENTS_PARAMS = [
    ParamDef("market", "string", "股票市场: cn, hk, us", required=True),
    ParamDef("name", "string", "行业名称，如 '军工', 'Technology'", required=True),
    ParamDef("type", "string", "行业分类类型: sw（申万）, wind, hs（恒生）, GICS"),
]

STOCK_EARNINGS_CALENDAR_PARAMS = [
    ParamDef("market", "string", "股票市场: cn, hk, us", required=True),
    ParamDef("start_date", "str", "开始日期"),
    ParamDef("end_date", "str", "结束日期"),
    ParamDef("symbol", "str", "指定股票代码"),
]

STOCK_IPO_CALENDAR_HK_PARAMS = [
    ParamDef(
        "status",
        "string",
        "IPO 状态: Filing（申报）, Hearing（聆讯）, Priced（定价）",
        default="Filing",
    ),
]

STOCK_INDEX_QUOTE_PARAMS = [
    ParamDef("symbol", "string", "指数代码，如 '000300', 'HSI', 'SPX'", required=True),
    ParamDef("start_date", "str", "开始日期，格式: YYYY-MM-DD"),
    ParamDef("end_date", "str", "结束日期，格式: YYYY-MM-DD"),
]

# Timeline module parameters
TIMELINE_COMPANIES_PARAMS = [
    ParamDef("num", "int", "返回结果数量，范围 1-100", default=10),
]

TIMELINE_TOPICS_PARAMS = [
    ParamDef("num", "int", "返回结果数量，范围 1-100", default=10),
]

TIMELINE_INSTITUTES_PARAMS = [
    ParamDef("num", "int", "返回结果数量，范围 1-100", default=10),
]

TIMELINE_PUBLIC_MEDIA_PARAMS = [
    ParamDef("num", "int", "返回结果数量，范围 1-100", default=10),
]

TIMELINE_SOCIAL_MEDIA_PARAMS = [
    ParamDef("num", "int", "返回结果数量，范围 1-100", default=10),
]

# KB module parameters
KB_SEARCH_PARAMS = [
    ParamDef("query", "string", "搜索关键词", required=True),
    ParamDef("folder_ids", "list[str]", "文件夹 ID 列表，不传则搜索全部文件夹"),
    ParamDef("doc_ids", "list[str]", "文档 ID 列表，限定搜索范围"),
    ParamDef("start_date", "str", "开始日期过滤（YYYY-MM-DD）"),
    ParamDef("end_date", "str", "结束日期过滤（YYYY-MM-DD）"),
    ParamDef("num", "int", "返回结果数量", default=10),
]

# User module parameters
USER_FOLLOWED_COMPANIES_PARAMS = []

# Quant module parameters
QUANT_LIST_INDICATORS_PARAMS = []

QUANT_COMPUTE_INDICATORS_PARAMS = [
    ParamDef("symbols", "list[str]", "股票代码列表", required=True),
    ParamDef("formula", "str", "指标公式，逻辑运算符(&/|/AND/OR)两侧表达式必须用()括起来", required=True),
    ParamDef("market", "str", "市场（cn/hk/us）", default="cn"),
    ParamDef("start_date", "str", "开始日期，默认 3 个月前"),
    ParamDef("end_date", "str", "结束日期，默认今天"),
]

QUANT_LIST_FACTORS_PARAMS = []

QUANT_COMPUTE_FACTORS_PARAMS = [
    ParamDef("symbols", "list[str]", "股票代码列表", required=True),
    ParamDef("formula", "str", "因子公式，逻辑运算符(&/|/AND/OR)两侧表达式必须用()括起来", required=True),
    ParamDef("market", "str", "市场", default="cn"),
    ParamDef("start_date", "str", "开始日期"),
    ParamDef("end_date", "str", "结束日期"),
]

QUANT_SCREEN_PARAMS = [
    ParamDef("formula", "str", "选股公式，逻辑运算符(&/|/AND/OR)两侧表达式必须用()括起来", required=True),
    ParamDef("market", "str", "市场", default="cn"),
    ParamDef("check_date", "str", "检查日期，默认最新交易日"),
    ParamDef("symbols", "list[str]", "股票池，None 表示全市场"),
]

QUANT_OHLCV_PARAMS = [
    ParamDef("symbol", "str", "股票代码", required=True),
    ParamDef("market", "str", "市场", default="cn"),
    ParamDef("start_date", "str", "开始日期，默认 1 个月前"),
    ParamDef("end_date", "str", "结束日期，默认今天"),
]

QUANT_OHLCV_BATCH_PARAMS = [
    ParamDef("symbols", "list[str]", "股票代码列表", required=True),
    ParamDef("market", "str", "市场", default="cn"),
    ParamDef("start_date", "str", "开始日期"),
    ParamDef("end_date", "str", "结束日期"),
]

QUANT_BACKTEST_PARAMS = [
    ParamDef("start_date", "str", "回测开始日期（YYYY-MM-DD）", required=True),
    ParamDef("end_date", "str", "回测结束日期（YYYY-MM-DD）", required=True),
    ParamDef("symbol", "str", "股票代码", required=True),
    ParamDef("market", "str", "市场（cn/hk/us）", default="cn"),
    ParamDef("entry_formula", "str", "买入/开仓公式（结果 > 0 触发买入），逻辑运算符两侧需()括起来", required=True),
    ParamDef("exit_formula", "str", "卖出/平仓公式（结果 > 0 触发卖出），逻辑运算符两侧需()括起来"),
    ParamDef("initial_cash", "float", "初始资金", default=100000),
    ParamDef("commission", "float", "佣金费率", default=0),
    ParamDef("stop_loss", "float", "止损比例（0 表示不设置）", default=0),
    ParamDef("sizer_percent", "int", "仓位百分比", default=99),
    ParamDef("auto_close", "bool", "是否自动平仓", default=True),
    ParamDef("labels", "dict[str, str]", "标签字典，返回额外指标值"),
]

# Concepts module parameters
CONCEPTS_LATEST_PARAMS = [
    ParamDef("include_docs", "bool", "是否包含相关文档", default=True),
]

CONCEPTS_TODAY_PARAMS = []

# Channels module parameters
CHANNELS_SEARCH_PARAMS = [
    ParamDef("query", "string", "搜索关键词或 URL", required=True),
    ParamDef("page_num", "int", "页码", default=1),
    ParamDef("page_size", "int", "每页数量", default=10),
]

CHANNELS_FOLLOWINGS_PARAMS = [
    ParamDef("page_num", "int", "页码", default=1),
    ParamDef("page_size", "int", "每页数量", default=10),
]

CHANNELS_FOLLOW_PARAMS = [
    ParamDef("channel_id", "string", "频道 ID", required=True),
]

CHANNELS_UNFOLLOW_PARAMS = [
    ParamDef("channel_id", "string", "频道 ID", required=True),
]

CHANNELS_GET_DOCS_PARAMS = [
    ParamDef("channel_ids", "string", "频道 ID 列表（逗号分隔）"),
    ParamDef("page_num", "int", "页码", default=1),
    ParamDef("page_size", "int", "每页数量", default=10),
]
