---
name: reportify-ai
description: Access Reportify financial data API via command line. Search documents, get stock data, financial statements, market quotes, quantitative analysis, and more. Use when the user needs to query financial information, stock data, company reports, or perform quantitative analysis on China A-shares, Hong Kong, or US markets.
metadata:
  author: reportify-ai
  version: "1.0"
---

# Reportify AI

A command-line tool for accessing Reportify SDK's financial data capabilities.

## When to use this skill

Use this skill when the user needs to:
- Search financial documents (news, reports, filings, transcripts)
- Get stock market data (quotes, prices, financial statements)
- Query company information and shareholder data
- Perform quantitative analysis (indicators, factors, backtesting)
- Access knowledge base search
- Get market timelines and concept dynamics

## Command Structure

```bash
reportify-cli <module> <command> --input '<json_params>' [--format <output_format>]
```

### Output Formats
- `json` (default) - JSON format
- `table` - Table format
- `csv` - CSV format
- `markdown` or `md` - Markdown table

## Best Practice: Save Large Results to File

When fetching data with potentially large results (e.g., historical prices, batch data, screening results), **always redirect output to a file first**, then read a small portion to verify:

```bash
# Save large dataset to file
reportify-cli stock prices --input '{"symbol": "AAPL", "start_date": "2025-01-01", "end_date": "2025-12-31"}' --format json > AAPL_prices_2025.json

# Then read first few lines to verify
head -50 AAPL_prices_2025.json

# Or for CSV format
reportify-cli quant ohlcv_batch --input '{"symbols": ["600519", "000858", "002304"]}' --format csv > cn_stocks_ohlcv.csv
head -20 cn_stocks_ohlcv.csv
```

This approach:
- Prevents terminal overflow with large datasets
- Preserves complete data for further analysis
- Allows incremental inspection of results

## Available Modules

| Module | Description | Commands |
|--------|-------------|----------|
| `search` | Document search | 9 commands |
| `docs` | Document management | 13 commands |
| `stock` | Stock data | 13 commands |
| `timeline` | Market timelines | 5 commands |
| `channels` | Channel management | 5 commands |
| `kb` | Knowledge base | 1 command |
| `user` | User data | 1 command |
| `quant` | Quantitative analysis | 8 commands |
| `concepts` | Concept dynamics | 2 commands |

## Common Usage Examples

### Search Documents
```bash
# Search all document types
reportify-cli search query --input '{"query": "Tesla", "num": 10}'

# Search news only
reportify-cli search news --input '{"query": "AI chip", "num": 5}'

# Search reports with filters
reportify-cli search reports --input '{"query": "liquor", "symbols": ["SH:600519"]}'
```

### Get Stock Data
```bash
# Get company overview
reportify-cli stock overview --input '{"symbols": "AAPL,00700"}'

# Get real-time quote
reportify-cli stock quote --input '{"symbol": "600519"}' --format table

# Get index quote
reportify-cli stock index_quote --input '{"symbol": "000300"}'
```

### Financial Statements
```bash
# Income statement
reportify-cli stock income_statement --input '{"symbol": "600519", "period": "annual"}'

# Balance sheet
reportify-cli stock balance_sheet --input '{"symbol": "00700", "period": "quarterly"}'

# Cash flow statement
reportify-cli stock cashflow_statement --input '{"symbol": "AAPL"}'
```

### Quantitative Analysis
```bash
# Compute technical indicators
reportify-cli quant indicators_compute --input '{"symbols": ["600519"], "formula": "RSI(14)"}'

# Stock screening
reportify-cli quant factors_screen --input '{"formula": "(PE_TTM() < 20) & (ROE() > 15)", "market": "cn"}'

# Backtesting
reportify-cli quant backtest --input '{"symbol": "600519", "start_date": "2025-01-01", "end_date": "2025-12-31", "entry_formula": "CROSS(MA(CLOSE, 5), MA(CLOSE, 20))"}'
```

## Getting Help

```bash
# List all modules
reportify-cli --help

# List commands in a module
reportify-cli stock --help

# Get command details with parameters
reportify-cli stock income_statement --help
```

## Symbol Format

- **China A-shares**: `SH:600519` or `600519`
- **Hong Kong**: `HK:00700` or `00700`
- **US stocks**: `US:AAPL` or `AAPL`

## Reference Documentation

For detailed parameter information, see:
- [API Reference](references/API_REFERENCE.md) - Complete API documentation
- [Module Commands](references/COMMANDS.md) - All available commands and parameters
