"""Reportify SDK client wrapper."""

from reportify_sdk import Reportify

from src.settings import get_api_key

_client = None


def get_client() -> Reportify:
    """Get or create Reportify SDK client instance.

    Returns:
        Reportify: SDK client instance
    """
    global _client
    if _client is None:
        api_key = get_api_key()
        _client = Reportify(api_key=api_key)
    return _client
