"""Channels module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(help="Channel management", rich_markup_mode="rich")


@app.command(
    epilog=generate_epilog(
        params.CHANNELS_SEARCH_PARAMS,
        [
            'reportify-cli channels search --input \'{"query": "Goldman Sachs"}\'',
            'reportify-cli channels search --input \'{"query": "finance", "page_size": 20}\'',
        ],
    )
)
def search(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Search channels"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.channels.search(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.CHANNELS_FOLLOWINGS_PARAMS,
        [
            "reportify-cli channels followings",
            "reportify-cli channels followings --input '{\"page_size\": 20}'",
        ],
    )
)
def followings(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """List followed channels"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.channels.followings(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.CHANNELS_FOLLOW_PARAMS,
        [
            'reportify-cli channels follow --input \'{"channel_id": "channel_123"}\'',
        ],
    )
)
def follow(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Follow a channel"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        channel_id = params_dict.get("channel_id")
        if not channel_id:
            raise ValueError("channel_id is required")
        result = client.channels.follow(channel_id)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.CHANNELS_UNFOLLOW_PARAMS,
        [
            'reportify-cli channels unfollow --input \'{"channel_id": "channel_123"}\'',
        ],
    )
)
def unfollow(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Unfollow a channel"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        channel_id = params_dict.get("channel_id")
        if not channel_id:
            raise ValueError("channel_id is required")
        result = client.channels.unfollow(channel_id)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="get_docs",
    epilog=generate_epilog(
        params.CHANNELS_GET_DOCS_PARAMS,
        [
            "reportify-cli channels get_docs",
            'reportify-cli channels get_docs --input \'{"channel_ids": "channel_1,channel_2", "page_size": 20}\'',
        ],
    ),
)
def get_docs(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get documents from followed channels"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.channels.get_docs(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
