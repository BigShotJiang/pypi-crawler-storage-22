"""Integration tests for docs commands.

This file contains integration tests that make real API calls.
You need to set REPORTIFY_API_KEY environment variable before running these tests.

Usage:
    # Set API key
    export REPORTIFY_API_KEY='your-api-key'

    # Run the integration test
    python -m pytest tests/integration/test_docs_integration.py -v

    # Or run directly
    python tests/integration/test_docs_integration.py
"""

import os
import sys

from typer.testing import CliRunner

from src.commands.docs import app

runner = CliRunner()


def test_docs_get_json_format():
    """Test docs get command with JSON format (real API call)."""
    print("\n" + "=" * 70)
    print("Testing: docs get with JSON format")
    print("=" * 70)

    result = runner.invoke(app, ["get", "--input", '{"doc_id": "1214713494948155392"}'])

    print(f"\nExit code: {result.exit_code}")
    print(f"\nOutput:\n{result.stdout}")

    if result.stderr:
        print(f"\nErrors:\n{result.stderr}")

    assert result.exit_code == 0, f"Command failed with exit code {result.exit_code}"
    assert "1214713494948155392" in result.stdout or "doc_id" in result.stdout

    print("\n✅ Test passed: JSON format works correctly")


def test_docs_get_table_format():
    """Test docs get command with table format (real API call)."""
    print("\n" + "=" * 70)
    print("Testing: docs get with table format")
    print("=" * 70)

    result = runner.invoke(
        app, ["get", "--input", '{"doc_id": "1214713494948155392"}', "--format", "table"]
    )

    print(f"\nExit code: {result.exit_code}")
    print(f"\nOutput:\n{result.stdout}")

    if result.stderr:
        print(f"\nErrors:\n{result.stderr}")

    assert result.exit_code == 0, f"Command failed with exit code {result.exit_code}"

    print("\n✅ Test passed: Table format works correctly")


def test_docs_get_csv_format():
    """Test docs get command with CSV format (real API call)."""
    print("\n" + "=" * 70)
    print("Testing: docs get with CSV format")
    print("=" * 70)

    result = runner.invoke(
        app, ["get", "--input", '{"doc_id": "1214713494948155392"}', "--format", "csv"]
    )

    print(f"\nExit code: {result.exit_code}")
    print(f"\nOutput:\n{result.stdout}")

    if result.stderr:
        print(f"\nErrors:\n{result.stderr}")

    assert result.exit_code == 0, f"Command failed with exit code {result.exit_code}"

    print("\n✅ Test passed: CSV format works correctly")


def main():
    """Run all integration tests manually."""
    # Check if API key is set
    if not os.getenv("REPORTIFY_API_KEY"):
        print("❌ Error: REPORTIFY_API_KEY environment variable is not set")
        print("Please set it with: export REPORTIFY_API_KEY='your-api-key'")
        sys.exit(1)

    print("\n" + "=" * 70)
    print("Running Integration Tests for docs get command")
    print("=" * 70)

    try:
        test_docs_get_json_format()
        test_docs_get_table_format()
        test_docs_get_csv_format()

        print("\n" + "=" * 70)
        print("✅ All integration tests passed!")
        print("=" * 70)

    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
