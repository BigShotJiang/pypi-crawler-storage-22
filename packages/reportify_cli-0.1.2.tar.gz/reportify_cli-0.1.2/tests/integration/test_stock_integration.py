"""Integration tests for stock commands.

This file contains integration tests that make real API calls.
You need to set REPORTIFY_API_KEY environment variable before running these tests.

Usage:
    # Set API key
    export REPORTIFY_API_KEY='your-api-key'

    # Run the integration test
    python -m pytest tests/integration/test_stock_integration.py -v

    # Or run directly
    python tests/integration/test_stock_integration.py
"""

import os
import sys

from typer.testing import CliRunner

from src.commands.stock import app

runner = CliRunner()


def test_stock_overview():
    """Test stock overview command (real API call)."""
    print("\n" + "=" * 70)
    print("Testing: stock overview")
    print("=" * 70)

    result = runner.invoke(app, ["overview", "--input", '{"symbols": "600519"}'])

    print(f"\nExit code: {result.exit_code}")
    print(f"\nOutput:\n{result.stdout[:500]}...")  # Show first 500 chars

    if result.stderr:
        print(f"\nErrors:\n{result.stderr}")

    assert result.exit_code == 0, f"Command failed with exit code {result.exit_code}"
    assert "600519" in result.stdout or "贵州茅台" in result.stdout

    print("\n✅ Test passed: overview works correctly")


def test_stock_income_statement():
    """Test stock income_statement command (real API call)."""
    print("\n" + "=" * 70)
    print("Testing: stock income_statement")
    print("=" * 70)

    result = runner.invoke(app, ["income_statement", "--input", '{"symbol": "600519", "limit": 3}'])

    print(f"\nExit code: {result.exit_code}")
    print(f"\nOutput:\n{result.stdout[:500]}...")

    if result.stderr:
        print(f"\nErrors:\n{result.stderr}")

    assert result.exit_code == 0, f"Command failed with exit code {result.exit_code}"

    print("\n✅ Test passed: income_statement works correctly")


def test_stock_balance_sheet():
    """Test stock balance_sheet command (real API call)."""
    print("\n" + "=" * 70)
    print("Testing: stock balance_sheet")
    print("=" * 70)

    result = runner.invoke(app, ["balance_sheet", "--input", '{"symbol": "600519", "limit": 3}'])

    print(f"\nExit code: {result.exit_code}")
    print(f"\nOutput:\n{result.stdout[:500]}...")

    if result.stderr:
        print(f"\nErrors:\n{result.stderr}")

    assert result.exit_code == 0, f"Command failed with exit code {result.exit_code}"

    print("\n✅ Test passed: balance_sheet works correctly")


def test_stock_cashflow_statement():
    """Test stock cashflow_statement command (real API call)."""
    print("\n" + "=" * 70)
    print("Testing: stock cashflow_statement")
    print("=" * 70)

    result = runner.invoke(
        app, ["cashflow_statement", "--input", '{"symbol": "600519", "limit": 3}']
    )

    print(f"\nExit code: {result.exit_code}")
    print(f"\nOutput:\n{result.stdout[:500]}...")

    if result.stderr:
        print(f"\nErrors:\n{result.stderr}")

    assert result.exit_code == 0, f"Command failed with exit code {result.exit_code}"

    print("\n✅ Test passed: cashflow_statement works correctly")


def test_stock_prices():
    """Test stock prices command (real API call)."""
    print("\n" + "=" * 70)
    print("Testing: stock prices")
    print("=" * 70)

    result = runner.invoke(
        app,
        [
            "prices",
            "--input",
            '{"symbol": "600519", "start_date": "2024-01-01", "end_date": "2024-01-31"}',
        ],
    )

    print(f"\nExit code: {result.exit_code}")
    print(f"\nOutput:\n{result.stdout[:500]}...")

    if result.stderr:
        print(f"\nErrors:\n{result.stderr}")

    assert result.exit_code == 0, f"Command failed with exit code {result.exit_code}"

    print("\n✅ Test passed: prices works correctly")


def test_stock_quote():
    """Test stock quote command (real API call)."""
    print("\n" + "=" * 70)
    print("Testing: stock quote")
    print("=" * 70)

    result = runner.invoke(app, ["quote", "--input", '{"symbol": "600519"}'])

    print(f"\nExit code: {result.exit_code}")
    print(f"\nOutput:\n{result.stdout[:500]}...")

    if result.stderr:
        print(f"\nErrors:\n{result.stderr}")

    assert result.exit_code == 0, f"Command failed with exit code {result.exit_code}"

    print("\n✅ Test passed: quote works correctly")


def main():
    """Run all integration tests manually."""
    # Check if API key is set
    if not os.getenv("REPORTIFY_API_KEY"):
        print("❌ Error: REPORTIFY_API_KEY environment variable is not set")
        print("Please set it with: export REPORTIFY_API_KEY='your-api-key'")
        sys.exit(1)

    print("\n" + "=" * 70)
    print("Running Integration Tests for stock commands (symbol=600519)")
    print("=" * 70)

    try:
        test_stock_overview()
        test_stock_income_statement()
        test_stock_balance_sheet()
        test_stock_cashflow_statement()
        test_stock_prices()
        test_stock_quote()

        print("\n" + "=" * 70)
        print("✅ All integration tests passed!")
        print("=" * 70)

    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
