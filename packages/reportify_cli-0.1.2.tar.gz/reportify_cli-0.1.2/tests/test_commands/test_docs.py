"""Tests for docs commands."""

from unittest.mock import Mock, patch

import pytest
from typer.testing import CliRunner

from src.commands.docs import app

runner = CliRunner()


@pytest.fixture
def mock_client():
    """Mock Reportify SDK client."""
    with patch("src.commands.docs.get_client") as mock_get_client:
        client = Mock()
        mock_get_client.return_value = client
        yield client


class TestDocsGet:
    """Tests for docs get command."""

    def test_get_with_valid_doc_id(self, mock_client):
        """Test getting document with valid doc_id."""
        # Mock the response
        mock_doc = {
            "doc_id": "1214713494948155392",
            "title": "Test Document",
            "content": "This is test content",
            "category": "news",
            "published_at": 1704067200000,
            "channel_name": "Test Channel",
            "url": "https://example.com/doc",
            "word_count": 100,
        }
        mock_client.docs.get.return_value = mock_doc

        # Run the command
        result = runner.invoke(app, ["get", "--input", '{"doc_id": "1214713494948155392"}'])

        # Assertions
        assert result.exit_code == 0
        mock_client.docs.get.assert_called_once_with("1214713494948155392")
        assert "1214713494948155392" in result.stdout
        assert "Test Document" in result.stdout

    def test_get_without_doc_id(self, mock_client):
        """Test getting document without doc_id should fail."""
        result = runner.invoke(app, ["get", "--input", "{}"])

        # Should fail with error
        assert result.exit_code == 1
        # Error message is in stdout (from typer.echo)
        error_output = result.stdout + result.stderr
        assert "doc_id is required" in error_output

    def test_get_with_table_format(self, mock_client):
        """Test getting document with table format."""
        mock_doc = {
            "doc_id": "1214713494948155392",
            "title": "Test Document",
            "content": "This is test content",
        }
        mock_client.docs.get.return_value = mock_doc

        result = runner.invoke(
            app, ["get", "--input", '{"doc_id": "1214713494948155392"}', "--format", "table"]
        )

        assert result.exit_code == 0
        mock_client.docs.get.assert_called_once_with("1214713494948155392")


class TestDocsSummary:
    """Tests for docs summary command."""

    def test_summary_with_valid_doc_id(self, mock_client):
        """Test getting document summary with valid doc_id."""
        mock_summary = {
            "doc_id": "1214713494948155392",
            "summary": "This is a test summary",
            "key_points": ["Point 1", "Point 2"],
            "sentiment": "positive",
        }
        mock_client.docs.summary.return_value = mock_summary

        result = runner.invoke(app, ["summary", "--input", '{"doc_id": "1214713494948155392"}'])

        assert result.exit_code == 0
        mock_client.docs.summary.assert_called_once_with("1214713494948155392")
        assert "test summary" in result.stdout


class TestDocsListBySymbol:
    """Tests for docs list_by_symbols command."""

    def test_list_by_symbols_with_valid_params(self, mock_client):
        """Test listing documents by symbol."""
        mock_docs = [{"doc_id": "doc1", "title": "Doc 1"}, {"doc_id": "doc2", "title": "Doc 2"}]
        mock_client.docs.list_by_symbols.return_value = mock_docs

        result = runner.invoke(
            app, ["list_by_symbols", "--input", '{"symbol": "US:AAPL", "num": 20}']
        )

        assert result.exit_code == 0
        mock_client.docs.list_by_symbols.assert_called_once()
        call_kwargs = mock_client.docs.list_by_symbols.call_args[1]
        assert call_kwargs["symbol"] == "US:AAPL"
        assert call_kwargs["num"] == 20
