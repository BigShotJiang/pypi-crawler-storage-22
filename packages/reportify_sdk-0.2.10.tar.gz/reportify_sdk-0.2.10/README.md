# Reportify SDK for Python

Python SDK for Reportify API - Financial data and document search.

## Installation

```bash
pip install reportify-sdk
```

## Quick Start

```python
from reportify_sdk import Reportify

# Initialize client
client = Reportify(api_key="your-api-key")

# Search documents
docs = client.search("Tesla earnings", num=10)
for doc in docs:
    print(doc["title"])
```

## Features

### Document Search

```python
# General search across all categories
docs = client.search("revenue growth", num=10)

# Search specific document types
news = client.search_news("Apple iPhone", num=10)
reports = client.search_reports("semiconductor analysis", num=10)
filings = client.search_filings("10-K annual report", symbols=["US:AAPL"])
transcripts = client.search_transcripts("guidance", symbols=["US:TSLA"])
```

### Stock Data (returns pandas DataFrame)

```python
# Financial statements
income = client.stock.income_statement("US:AAPL", period="quarterly")
balance = client.stock.balance_sheet("US:AAPL")
cashflow = client.stock.cashflow_statement("US:AAPL")

# Price data
prices = client.stock.prices("US:AAPL", limit=30)
kline = client.stock.kline("US:TSLA", interval="1d", limit=100)

# Real-time quotes
quotes = client.stock.quote(["US:AAPL", "US:MSFT"])

# Company info
overview = client.stock.overview("US:AAPL")
shareholders = client.stock.shareholders("US:AAPL")

# Screening and calendar
stocks = client.stock.screener(market="US", min_market_cap=1e10)
earnings = client.stock.earnings_calendar(area="us", start_date="2024-01-01")
```

### Timeline

```python
# Get timeline for followed entities
companies = client.timeline.companies(num=20)
topics = client.timeline.topics(num=20)
institutes = client.timeline.institutes(num=20)
public_media = client.timeline.public_media(num=20)
social_media = client.timeline.social_media(num=20)
```

### Knowledge Base

```python
# Search user's uploaded documents
chunks = client.kb.search("quarterly revenue", folder_ids=["folder_id"])
```

### Documents

```python
# Get document content
doc = client.docs.get("doc_id")
summary = client.docs.summary("doc_id")

# List and search documents
docs = client.docs.list(symbols=["US:AAPL"], page_size=10)
chunks = client.docs.search_chunks("revenue breakdown", num=5)
```

## Error Handling

```python
from reportify_sdk import (
    Reportify,
    AuthenticationError,
    RateLimitError,
    NotFoundError,
    APIError,
)

try:
    docs = client.search("Tesla")
except AuthenticationError:
    print("Invalid API key")
except RateLimitError:
    print("Rate limit exceeded, please wait")
except NotFoundError:
    print("Resource not found")
except APIError as e:
    print(f"API error: {e.message}")
```

## Configuration

```python
client = Reportify(
    api_key="your-api-key",
    base_url="https://api.reportify.cn",  # Optional: custom API URL
    timeout=30.0,  # Optional: request timeout in seconds
)
```

## Context Manager

```python
with Reportify(api_key="your-api-key") as client:
    docs = client.search("Tesla")
    # Client will be closed automatically
```

## License

MIT License - see [LICENSE](LICENSE) for details.
