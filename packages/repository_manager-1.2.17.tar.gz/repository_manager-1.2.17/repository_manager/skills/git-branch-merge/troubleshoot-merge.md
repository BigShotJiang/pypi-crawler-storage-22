Workflow: Resolve merge conflict
1. `git_action` "git merge <branch>" (may fail).
2. "git status" for conflicted files.
3. Edit files (manual or code_execution).
4. "git add <files>".
5. "git merge --continue".
