---
name: git-pull
description: Bulk pulls multiple repositories at once
---

### Overview
Tagging via `pull_projects`.

### Key Tools
- `pull_projects`: "repositories_directory", "threads".

### Usage Instructions
1. Create: "Pull the projects in parallel using this tool".
