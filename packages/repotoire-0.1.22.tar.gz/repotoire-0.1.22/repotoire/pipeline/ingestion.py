"""Main ingestion pipeline for processing codebases."""

import functools
import hashlib
import os
import re
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Callable, Tuple


@dataclass
class IngestionResult:
    """Result of an ingestion run, including changed files for incremental analysis."""

    files_processed: int = 0
    files_failed: int = 0
    files_skipped: int = 0
    # Relative paths of files that were new, changed, or dependents (for hybrid detectors)
    changed_files: List[str] = field(default_factory=list)
    # Whether this was an incremental run
    incremental: bool = False
    # Breakdown for incremental runs
    files_new: int = 0
    files_changed: int = 0
    files_unchanged: int = 0
    # Path expression cache for O(1) reachability queries (REPO-416)
    # Contains precomputed transitive closure for CALLS, IMPORTS, INHERITS relationships
    path_cache: Optional["PyPathCache"] = None


# Try to import Rust string operations for performance
try:
    from repotoire_fast import strip_line_numbers as _rust_strip_line_numbers
    _HAS_RUST_STRING_OPS = True
except ImportError:
    _HAS_RUST_STRING_OPS = False

# Try to import Rust path cache for O(1) reachability queries (REPO-416)
try:
    from repotoire_fast import PyPathCache
    _HAS_PATH_CACHE = True
except ImportError:
    _HAS_PATH_CACHE = False
    PyPathCache = None  # type: ignore

# Memoized helper functions for string parsing - avoid repeated splits
@functools.lru_cache(maxsize=50000)
def _parse_qualified_name(qn: str) -> Tuple[str, str, str]:
    """Parse qualified name into (file_path, entity_part, line).

    Format: /path/to/file.py::Class.method:line
    Returns: (file_path, entity_part_without_line_numbers, "")
    """
    if "::" not in qn:
        return (qn, "", "")
    file_part, rest = qn.split("::", 1)
    # Entity part is like "ClassName:140.method_name:177" - strip line number at end
    entity_part = rest.rsplit(":", 1)[0] if ":" in rest else rest
    # Remove line numbers embedded in class names (e.g., "ClassName:140.method" -> "ClassName.method")
    # Use Rust implementation when available for 2x+ speedup
    if _HAS_RUST_STRING_OPS:
        entity_part = _rust_strip_line_numbers(entity_part)
    else:
        entity_part = re.sub(r":(\d+)", "", entity_part)
    return (file_part, entity_part, "")


@functools.lru_cache(maxsize=50000)
def _get_module_prefix(qn: str) -> str:
    """Extract module prefix (everything except last component).

    e.g., "repotoire.mcp.models.Class" -> "repotoire.mcp.models"
    """
    if "." in qn:
        return ".".join(qn.split(".")[:-1])
    return ""


@functools.lru_cache(maxsize=50000)
def _split_path_components(path: str, sep: str = os.sep) -> Tuple[str, ...]:
    """Split path into components (cached for repeated use)."""
    return tuple(path.split(sep))

# Try to import Rust file scanning and hashing (10-100x faster)
try:
    from repotoire_fast import scan_files as rust_scan_files
    from repotoire_fast import batch_hash_files as rust_batch_hash_files
    _HAS_RUST_SCAN = True
except ImportError:
    _HAS_RUST_SCAN = False

    def rust_scan_files(path: str, patterns: List[str], exclude_dirs: List[str]) -> List[str]:
        """Pure Python fallback for file scanning."""
        import glob
        results = []
        base_path = Path(path)
        exclude_set = set(exclude_dirs)

        for pattern in patterns:
            for file_path in base_path.rglob(pattern.lstrip("*")):
                # Check if any parent directory is excluded
                skip = False
                for parent in file_path.relative_to(base_path).parents:
                    if parent.name in exclude_set:
                        skip = True
                        break
                if not skip:
                    results.append(str(file_path))
        return results

    def rust_batch_hash_files(paths: List[str]) -> List[Tuple[str, str]]:
        """Pure Python fallback for batch file hashing."""
        results = []
        for path in paths:
            try:
                with open(path, "rb") as f:
                    content = f.read()
                file_hash = hashlib.md5(content).hexdigest()
                results.append((path, file_hash))
            except (OSError, IOError):
                continue
        return results

from repotoire.graph import FalkorDBClient, GraphSchema
from repotoire.graph.base import DatabaseClient
from repotoire.parsers import CodeParser, PythonParser
from repotoire.parsers import GenericFallbackParser, EXTENSION_TO_LANGUAGE
from repotoire.models import Entity, Relationship, SecretsPolicy, RelationshipType

# Optional TypeScript/JavaScript parsers
try:
    from repotoire.parsers import TreeSitterTypeScriptParser, TreeSitterJavaScriptParser
    _HAS_TYPESCRIPT_PARSER = True
except ImportError:
    _HAS_TYPESCRIPT_PARSER = False

# Optional Java parser
try:
    from repotoire.parsers import TreeSitterJavaParser
    _HAS_JAVA_PARSER = True
except ImportError:
    _HAS_JAVA_PARSER = False

# Optional Go parser
try:
    from repotoire.parsers import TreeSitterGoParser
    _HAS_GO_PARSER = True
except ImportError:
    _HAS_GO_PARSER = False
from repotoire.logging_config import get_logger, LogContext, log_operation
from repotoire.ai.vector_store import (
    VectorStore,
    VectorStoreConfig,
    create_vector_store,
)

logger = get_logger(__name__)


class SecurityError(Exception):
    """Raised when a security violation is detected."""
    pass


class IngestionPipeline:
    """Pipeline for ingesting code into the knowledge graph."""

    # Security limits
    MAX_FILE_SIZE_MB = 10  # Maximum file size to process
    DEFAULT_FOLLOW_SYMLINKS = False  # Don't follow symlinks by default
    DEFAULT_BATCH_SIZE = 100  # Default batch size for loading entities (increased since BGSAVE disabled)

    def __init__(
        self,
        repo_path: str,
        graph_client: DatabaseClient,
        follow_symlinks: bool = DEFAULT_FOLLOW_SYMLINKS,
        max_file_size_mb: float = MAX_FILE_SIZE_MB,
        batch_size: int = DEFAULT_BATCH_SIZE,
        secrets_policy: SecretsPolicy = SecretsPolicy.REDACT,
        generate_clues: bool = False,
        generate_embeddings: bool = False,
        embedding_backend: str = "openai",
        embedding_model: Optional[str] = None,
        generate_contexts: bool = False,
        context_model: str = "claude-haiku-3-5-20241022",
        max_context_cost: Optional[float] = None,
        repo_id: Optional[str] = None,
        repo_slug: Optional[str] = None,
        compress_embeddings: bool = True,
        embedding_target_dims: int = 1024,
        vector_store_config: Optional[VectorStoreConfig] = None,
    ):
        """Initialize ingestion pipeline with security validation.

        Args:
            repo_path: Path to repository root
            graph_client: Database client (Neo4j or FalkorDB)
            follow_symlinks: Whether to follow symbolic links (default: False for security)
            max_file_size_mb: Maximum file size in MB to process (default: 10MB)
            batch_size: Number of entities to batch before loading to graph (default: 100)
            secrets_policy: Policy for handling detected secrets (default: REDACT)
            generate_clues: Whether to generate AI semantic clues (default: False)
            generate_embeddings: Whether to generate vector embeddings for RAG (default: False)
            embedding_backend: Backend for embeddings: 'openai' or 'local' (default: openai)
            embedding_model: Model name override for embeddings (default: uses backend default)
            generate_contexts: Whether to generate semantic contexts using Claude (default: False)
            context_model: Claude model for context generation (default: claude-haiku-3-5-20241022)
            max_context_cost: Maximum USD to spend on context generation (default: unlimited)
            repo_id: Optional repository UUID for multi-tenant isolation. When set, all
                entities created during ingestion will have this repo_id attached.
            repo_slug: Optional repository slug (e.g., "owner/repo-name") for human-readable
                identification. Used with repo_id for multi-tenant setups.
            compress_embeddings: Whether to compress embeddings with PCA (default: True).
                Reduces 4096-dim embeddings to target_dims for memory savings.
            embedding_target_dims: Target dimensions after PCA compression (default: 1024).
                Only used if compress_embeddings is True.
            vector_store_config: Optional external vector store config (LanceDB).
                When configured, embeddings are stored disk-backed instead of in-memory.
                This significantly reduces RAM usage for large codebases.

        Raises:
            ValueError: If repository path is invalid
            SecurityError: If path violates security constraints
        """
        # Check if path is a symlink BEFORE resolving (security)
        repo_path_obj = Path(repo_path)
        if repo_path_obj.is_symlink():
            raise SecurityError(
                f"Repository path cannot be a symbolic link: {repo_path}\n"
                f"Symlinks in the repository root are not allowed for security reasons."
            )

        # Resolve to absolute canonical path
        self.repo_path = repo_path_obj.resolve()

        # Validate repository path
        self._validate_repo_path()

        self.db = graph_client
        # Detect if we're using FalkorDB
        self.is_falkordb = type(graph_client).__name__ == "FalkorDBClient"
        self.parsers: Dict[str, CodeParser] = {}
        self.follow_symlinks = follow_symlinks
        self.max_file_size_mb = max_file_size_mb
        self.batch_size = batch_size
        self.secrets_policy = secrets_policy
        self.generate_clues = generate_clues
        self.generate_embeddings = generate_embeddings
        self.embedding_backend = embedding_backend
        self.embedding_model = embedding_model
        self.compress_embeddings = compress_embeddings
        self.embedding_target_dims = embedding_target_dims
        self.generate_contexts = generate_contexts
        self.context_model = context_model
        self.max_context_cost = max_context_cost
        self.repo_id = repo_id
        self.repo_slug = repo_slug

        # Track skipped files for reporting
        self.skipped_files: List[Dict[str, str]] = []
        # REPO-500: Lock for thread-safe skipped files access
        self._skipped_lock = threading.Lock()

        # Cache for file content, hash, and last_modified to avoid redundant reads
        # REPO-500: Now includes last_modified to fix TOCTOU race condition
        # Key: Path, Value: (content_bytes, md5_hash, last_modified)
        self._file_cache: Dict[Path, Tuple[bytes, str, datetime]] = {}

        # Hash-only cache populated by Rust batch hashing (used during incremental analysis)
        # Key: str (path), Value: str (md5_hash)
        self._hash_cache: Dict[str, str] = {}

        # Lock for thread-safe cache access
        self._cache_lock = threading.Lock()

        # Lock for thread-safe PCA model fitting
        self._pca_fit_lock = threading.Lock()

        # Callbacks to run after ingestion completes (e.g., cache invalidation)
        self._on_ingest_complete_callbacks: List[Callable[[], None]] = []
        # REPO-500: Lock for thread-safe callbacks access
        self._callbacks_lock = threading.Lock()

        # Optional RAG retriever for automatic cache invalidation
        self._rag_retriever = None

        # Initialize clue generator if needed
        self.clue_generator = None
        if self.generate_clues:
            try:
                from repotoire.ai import SpacyClueGenerator
                self.clue_generator = SpacyClueGenerator()
                logger.info("Clue generation enabled (using spaCy)")
            except Exception as e:
                logger.warning(f"Could not initialize clue generator: {e}")
                logger.warning("Continuing without clue generation")
                self.generate_clues = False

        # Initialize embedder if needed
        self.embedder = None
        if self.generate_embeddings:
            try:
                from repotoire.ai import CodeEmbedder
                self.embedder = CodeEmbedder(
                    backend=self.embedding_backend,
                    model=self.embedding_model,
                )
                logger.info(
                    f"Embedding generation enabled (backend={self.embedding_backend}, "
                    f"model={self.embedder.config.effective_model}, "
                    f"dimensions={self.embedder.dimensions})"
                )
            except ImportError as e:
                logger.warning(f"Could not initialize embedder: {e}")
                if self.embedding_backend == "local":
                    logger.warning("Install with: pip install repotoire[local-embeddings]")
                logger.warning("Continuing without embedding generation")
                self.generate_embeddings = False
            except Exception as e:
                logger.warning(f"Could not initialize embedder: {e}")
                logger.warning("Continuing without embedding generation")
                self.generate_embeddings = False

        # Initialize embedding compressor if needed
        self.embedding_compressor = None
        if self.generate_embeddings and self.compress_embeddings and self.embedder:
            # Only compress if source dims > target dims
            if self.embedder.dimensions > self.embedding_target_dims:
                try:
                    from repotoire.ai import EmbeddingCompressor

                    # Load or create compressor with org-specific model path
                    model_dir = Path.home() / ".repotoire" / "compression_models"
                    model_path = model_dir / f"{repo_slug or 'default'}_pca.pkl"

                    self.embedding_compressor = EmbeddingCompressor(
                        target_dims=self.embedding_target_dims,
                        model_path=model_path,
                    )

                    if self.embedding_compressor.is_fitted:
                        logger.info(
                            f"Embedding compression enabled (loaded PCA model: "
                            f"{self.embedder.dimensions} → {self.embedding_target_dims} dims)"
                        )
                    else:
                        logger.info(
                            f"Embedding compression enabled (will fit PCA on first batch: "
                            f"{self.embedder.dimensions} → {self.embedding_target_dims} dims)"
                        )
                except Exception as e:
                    logger.warning(f"Could not initialize embedding compressor: {e}")
                    logger.warning("Continuing without compression")
                    self.embedding_compressor = None

        # Initialize context generator if needed (REPO-242)
        self.context_generator = None
        if self.generate_contexts:
            try:
                from repotoire.ai import ContextGenerator, ContextualRetrievalConfig
                config = ContextualRetrievalConfig(
                    enabled=True,
                    model=self.context_model,
                    max_cost_usd=self.max_context_cost,
                )
                self.context_generator = ContextGenerator(config)
                logger.info(
                    f"Context generation enabled (model={self.context_model}, "
                    f"max_cost=${self.max_context_cost or 'unlimited'})"
                )
            except ImportError as e:
                logger.warning(f"Could not initialize context generator: {e}")
                logger.warning("Install with: pip install anthropic")
                logger.warning("Continuing without context generation")
                self.generate_contexts = False
            except ValueError as e:
                logger.warning(f"Could not initialize context generator: {e}")
                logger.warning("Continuing without context generation")
                self.generate_contexts = False

        # Initialize external vector store for memory-optimized embedding storage
        # Auto-enable LanceDB when generating embeddings (moves vectors to disk)
        self.vector_store: Optional[VectorStore] = None
        if self.generate_embeddings:
            # Use provided config or auto-create LanceDB config
            if vector_store_config is not None:
                self.vector_store_config = vector_store_config
            else:
                # Auto-enable LanceDB for disk-backed storage (0 RAM for vectors)
                # Use env var for persistent storage (Fly volume), fallback to repo-local
                vector_path = os.environ.get(
                    "REPOTOIRE_VECTOR_STORE_PATH",
                    str(Path(repo_path) / ".repotoire" / "vectors")
                )
                self.vector_store_config = VectorStoreConfig(
                    backend="lancedb",
                    path=vector_path,
                )

            try:
                self.vector_store = create_vector_store(config=self.vector_store_config)
                logger.info(
                    f"External vector store auto-enabled: {self.vector_store_config.backend} "
                    f"(path={self.vector_store_config.path})"
                )
            except ImportError as e:
                logger.debug(f"LanceDB not available, using graph-native storage: {e}")
                self.vector_store = None
                self.vector_store_config = None
        else:
            self.vector_store_config = vector_store_config

        # Register default parsers with secrets policy
        self.register_parser("python", PythonParser(secrets_policy=secrets_policy))

        # Register TypeScript/JavaScript parsers if available
        if _HAS_TYPESCRIPT_PARSER:
            try:
                self.register_parser("typescript", TreeSitterTypeScriptParser())
                self.register_parser("javascript", TreeSitterJavaScriptParser())
                logger.info("TypeScript and JavaScript parsers registered")
            except ImportError as e:
                logger.debug(f"TypeScript/JavaScript parsers not available: {e}")

        # Register Java parser if available
        if _HAS_JAVA_PARSER:
            try:
                self.register_parser("java", TreeSitterJavaParser())
                logger.info("Java parser registered")
            except ImportError as e:
                logger.debug(f"Java parser not available: {e}")

        # Register Go parser if available
        if _HAS_GO_PARSER:
            try:
                self.register_parser("go", TreeSitterGoParser())
                logger.info("Go parser registered")
            except ImportError as e:
                logger.debug(f"Go parser not available: {e}")

        # Register generic fallback parser for all other languages
        # This ensures every file gets tracked in the knowledge graph
        fallback_parser = GenericFallbackParser()
        fallback_languages = set(GenericFallbackParser.supported_languages())
        # Don't register fallback for languages that have dedicated parsers
        already_registered = {"python", "typescript", "javascript", "java", "go"}
        for lang in fallback_languages - already_registered:
            self.register_parser(lang, fallback_parser)
        logger.info(
            f"Generic fallback parser registered for {len(fallback_languages - already_registered)} languages: "
            f"{', '.join(sorted(fallback_languages - already_registered)[:10])}..."
        )

        # Initialize Rust parallel parser if available (Phase 2 performance)
        self.rust_parser = None
        try:
            from repotoire.parsers.rust_parser import RustParallelParser, is_rust_parser_available
            if is_rust_parser_available():
                self.rust_parser = RustParallelParser(str(self.repo_path))
                logger.info(
                    f"Rust parallel parser enabled "
                    f"(supported languages: {', '.join(self.rust_parser._supported_languages)})"
                )
        except Exception as e:
            logger.debug(f"Rust parallel parser not available: {e}")

    def _validate_repo_path(self) -> None:
        """Validate repository path for security.

        Raises:
            ValueError: If path doesn't exist or isn't a directory
        """
        if not self.repo_path.exists():
            raise ValueError(f"Repository does not exist: {self.repo_path}")

        if not self.repo_path.is_dir():
            raise ValueError(f"Repository must be a directory: {self.repo_path}")

        logger.info(f"Repository path validated: {self.repo_path}")

    def _get_file_content_and_hash(self, file_path: Path) -> Tuple[bytes, str, datetime]:
        """Read file once, cache content, hash, and last_modified.

        REPO-500: Fixed TOCTOU race condition. Now captures st_mtime atomically
        with file read to ensure hash matches the modification time. Previously,
        stat() was called separately in the parser, which could see a different
        modification time if the file was modified between read and stat.

        Reads the file in binary mode, computes MD5 hash, captures mtime, and caches all.
        Subsequent calls for the same path return cached values.

        If hash was pre-computed by Rust batch hashing, reuses that hash.

        Args:
            file_path: Path to the file to read

        Returns:
            Tuple of (content_bytes, md5_hash, last_modified)

        Raises:
            OSError: If file cannot be read
        """
        # Normalize path for consistent cache keys
        normalized_path = file_path.resolve()

        # Thread-safe cache lookup
        with self._cache_lock:
            if normalized_path in self._file_cache:
                return self._file_cache[normalized_path]

        # REPO-500: Capture stat BEFORE reading to get consistent mtime
        # Even if file changes during read, we'll have the pre-read mtime
        # which will trigger re-analysis on next run
        stat_result = normalized_path.stat()
        last_modified = datetime.fromtimestamp(stat_result.st_mtime)

        with open(normalized_path, "rb") as f:
            content = f.read()

        # Check if hash was pre-computed by Rust batch hashing (thread-safe)
        path_str = str(normalized_path)
        with self._cache_lock:
            if path_str in self._hash_cache:
                file_hash = self._hash_cache[path_str]
            else:
                file_hash = hashlib.md5(content).hexdigest()

            result = (content, file_hash, last_modified)
            self._file_cache[normalized_path] = result
        return result

    def _clear_file_cache(self) -> None:
        """Clear the file content cache to free memory.

        Thread-safe cache clearing.
        Should be called after ingestion batch completes to prevent memory bloat.
        """
        with self._cache_lock:
            cache_size = len(self._file_cache)
            hash_cache_size = len(self._hash_cache)
            self._file_cache.clear()
            self._hash_cache.clear()
        if cache_size > 0 or hash_cache_size > 0:
            logger.debug(f"Cleared file cache ({cache_size} entries) and hash cache ({hash_cache_size} entries)")

    def _batch_compute_hashes(self, file_paths: List[Path]) -> Dict[str, str]:
        """Compute MD5 hashes for multiple files in parallel using Rust.

        Uses Rust's Rayon parallel iterator for ~10x speedup over Python sequential hashing.
        Results are cached in _hash_cache for subsequent lookups.

        Args:
            file_paths: List of file paths to hash

        Returns:
            Dictionary mapping file path (str) to MD5 hash
        """
        if not file_paths:
            return {}

        # Convert paths to strings for Rust FFI
        path_strings = [str(p.resolve()) for p in file_paths]

        # Call Rust batch_hash_files (uses Rayon for parallel processing)
        import time
        start = time.perf_counter()
        results = rust_batch_hash_files(path_strings)
        elapsed = time.perf_counter() - start

        # Convert to dictionary and cache (thread-safe)
        hash_dict = {}
        for path_str, file_hash in results:
            hash_dict[path_str] = file_hash

        with self._cache_lock:
            self._hash_cache.update(hash_dict)

        logger.debug(f"Rust batch hashed {len(results)} files in {elapsed:.3f}s ({len(results)/elapsed:.0f} files/sec)")
        return hash_dict

    def register_parser(self, language: str, parser: CodeParser) -> None:
        """Register a language parser.

        Args:
            language: Language identifier (e.g., 'python', 'typescript')
            parser: Parser instance
        """
        self.parsers[language] = parser
        logger.info(f"Registered parser for {language}")

    def register_on_ingest_complete(self, callback: Callable[[], None]) -> None:
        """Register a callback to run after ingestion completes.

        Use this to register cache invalidation or other cleanup functions.
        Thread-safe: uses lock to protect callback list.

        Args:
            callback: Zero-argument callable to execute after ingestion

        Example:
            >>> pipeline.register_on_ingest_complete(retriever.invalidate_cache)
        """
        with self._callbacks_lock:
            self._on_ingest_complete_callbacks.append(callback)
        logger.debug(f"Registered on_ingest_complete callback: {callback.__name__}")

    def set_rag_retriever(self, retriever) -> None:
        """Set the RAG retriever for automatic cache invalidation.

        When a retriever is set, its cache will be automatically invalidated
        after each ingestion completes.

        Args:
            retriever: GraphRAGRetriever instance with invalidate_cache method
        """
        self._rag_retriever = retriever
        logger.info("RAG retriever registered for automatic cache invalidation")

    def _run_on_ingest_complete_callbacks(self) -> None:
        """Execute all registered on_ingest_complete callbacks.

        Thread-safe: takes snapshot of callbacks under lock before iteration.
        """
        # Invalidate RAG cache if retriever is set
        if self._rag_retriever is not None:
            try:
                self._rag_retriever.invalidate_cache()
            except Exception as e:
                logger.warning(f"Failed to invalidate RAG cache: {e}")

        # Take snapshot of callbacks under lock
        with self._callbacks_lock:
            callbacks = list(self._on_ingest_complete_callbacks)

        # Run callbacks outside lock to avoid blocking registrations
        for callback in callbacks:
            try:
                callback()
            except Exception as e:
                logger.warning(f"On-ingest-complete callback failed: {e}")

    def _validate_file_path(self, file_path: Path) -> None:
        """Validate file path is within repository boundary.

        Args:
            file_path: Path to validate

        Raises:
            SecurityError: If file is outside repository or violates security constraints
        """
        # Resolve to absolute path
        resolved_file = file_path.resolve()

        # Check if file is within repository boundary
        try:
            resolved_file.relative_to(self.repo_path)
        except ValueError:
            raise SecurityError(
                f"Security violation: File is outside repository boundary\n"
                f"File: {file_path}\n"
                f"Repository: {self.repo_path}\n"
                f"This could be a path traversal attack."
            )

    def _record_skipped_file(self, file_path: str, reason: str) -> None:
        """Record a skipped file with thread-safe access.

        Args:
            file_path: Path to the skipped file
            reason: Reason for skipping
        """
        with self._skipped_lock:
            self.skipped_files.append({"file": file_path, "reason": reason})

    def _validate_file_size(self, file_path: Path) -> bool:
        """Validate file size is within limits.

        Args:
            file_path: Path to check

        Returns:
            True if file is within size limit, False otherwise
        """
        try:
            size_mb = file_path.stat().st_size / (1024 * 1024)
            if size_mb > self.max_file_size_mb:
                logger.warning(
                    f"Skipping file {file_path}: size {size_mb:.1f}MB exceeds limit of {self.max_file_size_mb}MB"
                )
                self._record_skipped_file(
                    str(file_path),
                    f"File too large: {size_mb:.1f}MB > {self.max_file_size_mb}MB"
                )
                return False
            return True
        except Exception as e:
            logger.warning(f"Could not check file size for {file_path}: {e}")
            return True  # Allow file if size check fails

    def _should_skip_file(self, file_path: Path) -> bool:
        """Check if file should be skipped for security or other reasons.

        Args:
            file_path: Path to check

        Returns:
            True if file should be skipped
        """
        # Skip symlinks by default (security)
        if file_path.is_symlink() and not self.follow_symlinks:
            logger.warning(f"Skipping symlink: {file_path} (use --follow-symlinks to include)")
            self._record_skipped_file(str(file_path), "Symbolic link (security)")
            return True

        # Validate file size
        if not self._validate_file_size(file_path):
            return True

        # Validate path boundary
        try:
            self._validate_file_path(file_path)
        except SecurityError as e:
            logger.error(f"Security check failed for {file_path}: {e}")
            self._record_skipped_file(str(file_path), "Outside repository boundary")
            return True

        return False

    def scan(
        self,
        patterns: Optional[List[str]] = None,
        exclude_patterns: Optional[List[str]] = None,
        exclude_dirs: Optional[List[str]] = None,
    ) -> List[Path]:
        """Scan repository for source files with security validation.

        Uses Rust parallel scanner for 3-10x speedup over Python glob.

        Args:
            patterns: List of glob patterns to match (default: includes all supported languages)
            exclude_patterns: List of glob patterns to exclude (e.g., "**/test_*.py", "**/tests/**")
            exclude_dirs: List of directory names to ignore (e.g., [".git", "node_modules"])

        Returns:
            List of validated file paths
        """
        import fnmatch

        if patterns is None:
            # Default patterns include all supported languages
            patterns = ["**/*.py"]
            if _HAS_TYPESCRIPT_PARSER:
                patterns.extend(["**/*.ts", "**/*.tsx", "**/*.js", "**/*.jsx"])
            # Add Java, Go, and Rust when Rust tree-sitter parser is available
            if self.rust_parser is not None:
                patterns.extend(["**/*.java", "**/*.go", "**/*.rs"])

        # Default ignored directories
        if exclude_dirs is None:
            exclude_dirs = [".git", "__pycache__", "node_modules", ".venv", "venv", "build", "dist"]

        # Default exclude patterns (empty - rely on config)
        if exclude_patterns is None:
            exclude_patterns = []

        # Load additional patterns from .repotoireignore file
        from repotoire.config import load_ignore_patterns
        ignore_file_patterns = load_ignore_patterns(start_dir=self.repo_path)
        if ignore_file_patterns:
            exclude_patterns = list(exclude_patterns) + ignore_file_patterns
            logger.debug(f"Added {len(ignore_file_patterns)} patterns from .repotoireignore")

        file_paths = rust_scan_files(str(self.repo_path), patterns, exclude_dirs)

        # Apply exclude patterns
        files = []
        excluded_count = 0
        for p in file_paths:
            path = Path(p)
            if self._should_skip_file(path):
                continue

            # Check against exclude patterns
            rel_path = str(path.relative_to(self.repo_path))
            excluded = False
            for pattern in exclude_patterns:
                if fnmatch.fnmatch(rel_path, pattern):
                    excluded = True
                    excluded_count += 1
                    self._record_skipped_file(str(path), f"Matched exclude pattern: {pattern}")
                    break
            if not excluded:
                files.append(path)

        logger.info(
            f"Found {len(files)} source files "
            f"(skipped {len(self.skipped_files)} files, {excluded_count} by exclude patterns)"
        )
        return files

    def _get_relative_path(self, file_path: Path) -> str:
        """Get relative path from repository root.

        Stores relative paths instead of absolute paths for security
        (avoids exposing full system paths in database).

        Args:
            file_path: Absolute file path

        Returns:
            Relative path string from repository root
        """
        try:
            return str(file_path.relative_to(self.repo_path))
        except ValueError:
            # Should not happen due to validation, but handle gracefully
            logger.warning(f"Could not make path relative: {file_path}")
            return str(file_path)

    def _get_current_tenant_id(self) -> Optional[str]:
        """Get current tenant ID from TenantContext.

        REPO-600: Multi-tenant data isolation.

        Returns:
            Tenant ID string or None if no tenant context
        """
        try:
            from repotoire.tenant.context import get_current_org_id_str
            return get_current_org_id_str()
        except Exception as e:
            logger.debug(f"Could not get tenant context: {e}")
            return None

    def parse_and_extract(self, file_path: Path) -> tuple[List[Entity], List[Relationship]]:
        """Parse a file and extract entities/relationships with security validation.

        Args:
            file_path: Path to source file (must be within repository)

        Returns:
            Tuple of (entities, relationships)

        Note:
            All file paths stored in entities will be relative to repository root
            for security (avoids exposing system structure).
        """
        # Security validation
        try:
            self._validate_file_path(file_path)
        except SecurityError as e:
            logger.error(f"Security validation failed: {e}")
            self._record_skipped_file(str(file_path), "Security validation failed")
            return [], []

        # Determine language from extension
        language = self._detect_language(file_path)

        if language not in self.parsers:
            logger.warning(f"No parser for {language}, skipping {file_path}")
            return [], []

        parser = self.parsers[language]

        try:
            # Populate file cache if not already cached (for new files)
            # This ensures each file is read at most once during ingestion
            # REPO-500: Now returns last_modified to fix TOCTOU race condition
            content, file_hash, last_modified = self._get_file_content_and_hash(file_path)

            # Inject cached content into parser to avoid redundant reads
            # REPO-500: Also pass last_modified to avoid separate stat() call
            if hasattr(parser, 'set_cached_content'):
                parser.set_cached_content(str(file_path), content, file_hash, last_modified)

            entities, relationships = parser.process_file(str(file_path))

            # Convert all entity file paths to relative paths for security
            # CRITICAL: Also update qualified_name to use relative path to prevent duplicates
            # when same repo is analyzed from different absolute paths (local vs worker clone)
            for entity in entities:
                if hasattr(entity, 'file_path') and entity.file_path:
                    old_file_path = entity.file_path
                    # Store relative path instead of absolute
                    new_file_path = self._get_relative_path(Path(entity.file_path))
                    entity.file_path = new_file_path

                    # Update qualified_name to use relative path
                    # Format: /abs/path/file.py::ClassName:line -> rel/path/file.py::ClassName:line
                    if hasattr(entity, 'qualified_name') and entity.qualified_name:
                        if old_file_path in entity.qualified_name:
                            entity.qualified_name = entity.qualified_name.replace(
                                old_file_path, new_file_path, 1
                            )

            logger.debug(
                f"Extracted {len(entities)} entities and {len(relationships)} relationships from {file_path}"
            )
            return entities, relationships
        except Exception as e:
            logger.error(f"Failed to parse {file_path}: {e}")
            self._record_skipped_file(str(file_path), f"Parse error: {str(e)}")
            return [], []

    def _generate_clues_for_entities(
        self, entities: List[Entity]
    ) -> tuple[List[Entity], List[Relationship]]:
        """Generate semantic clues for entities.

        Args:
            entities: List of entities to generate clues for

        Returns:
            Tuple of (clue_entities, describes_relationships)
        """
        if not self.generate_clues or not self.clue_generator:
            return [], []

        clue_entities = []
        describes_relationships = []

        for entity in entities:
            try:
                # Generate clues for this entity
                clues = self.clue_generator.generate_clues(entity)

                for clue in clues:
                    clue_entities.append(clue)

                    # Create DESCRIBES relationship from clue to target entity
                    describes_rel = Relationship(
                        from_node=clue.qualified_name,
                        to_node=entity.qualified_name,
                        rel_type=RelationshipType.DESCRIBES,
                        properties={
                            "clue_type": clue.clue_type,
                            "confidence": clue.confidence,
                            "generated_by": clue.generated_by
                        }
                    )
                    describes_relationships.append(describes_rel)

            except Exception as e:
                logger.warning(f"Failed to generate clues for {entity.qualified_name}: {e}")

        logger.debug(f"Generated {len(clue_entities)} clues for {len(entities)} entities")
        return clue_entities, describes_relationships

    def _generate_embeddings_for_all_entities(self) -> int:
        """Generate vector embeddings for all entities in the graph.

        Queries Neo4j for Function, Class, and File nodes without embeddings,
        generates embeddings in batches, and updates the nodes.

        Uses paginated queries to avoid loading all entities into memory at once.
        This prevents OOM on large repositories with 50K+ entities.

        Returns:
            Number of entities that received embeddings
        """
        if not self.embedder:
            return 0

        from repotoire.models import FunctionEntity, ClassEntity, FileEntity

        entities_embedded = 0
        embedding_batch_size = 500  # Batch size for embedding generation AND DB fetch

        # FalkorDB uses id() while Neo4j uses elementId()
        id_func = "id" if self.is_falkordb else "elementId"

        # Process each entity type
        for entity_type, entity_class in [
            ("Function", FunctionEntity),
            ("Class", ClassEntity),
            ("File", FileEntity)
        ]:
            logger.info(f"Generating embeddings for {entity_type} entities...")

            # First, count how many entities need embeddings
            count_query = f"""
            MATCH (e:{entity_type})
            WHERE e.embedding IS NULL
            RETURN count(e) as total
            """
            count_result = self.db.execute_query(count_query)
            total_count = count_result[0]["total"] if count_result else 0

            if total_count == 0:
                logger.debug(f"No {entity_type} entities need embeddings")
                continue

            logger.info(f"Found {total_count} {entity_type} entities to embed (processing in batches of {embedding_batch_size})")

            # Process in paginated batches to avoid loading all entities into memory
            offset = 0
            while offset < total_count:
                # Paginated query - only fetch one batch at a time
                query = f"""
                MATCH (e:{entity_type})
                WHERE e.embedding IS NULL
                RETURN
                    {id_func}(e) as id,
                    e.name as name,
                    e.qualifiedName as qualified_name,
                    e.docstring as docstring,
                    e.filePath as file_path,
                    e.lineStart as line_start,
                    e.lineEnd as line_end,
                    e.semantic_context as semantic_context
                SKIP {offset}
                LIMIT {embedding_batch_size}
                """

                batch = self.db.execute_query(query)

                if not batch:
                    # No more entities (might have been embedded by concurrent worker)
                    break

                offset += len(batch)

                # Convert to entity objects for embedder
                entity_objects = []
                semantic_contexts = []  # Track contexts for contextualized embedding
                for e in batch:
                    if entity_type == "Function":
                        entity_obj = FunctionEntity(
                            name=e["name"],
                            qualified_name=e["qualified_name"],
                            file_path=e["file_path"],
                            line_start=e["line_start"],
                            line_end=e["line_end"],
                            docstring=e.get("docstring"),
                            parameters=[],  # Not needed for embedding
                        )
                    elif entity_type == "Class":
                        entity_obj = ClassEntity(
                            name=e["name"],
                            qualified_name=e["qualified_name"],
                            file_path=e["file_path"],
                            line_start=e["line_start"],
                            line_end=e["line_end"],
                            docstring=e.get("docstring")
                        )
                    else:  # File
                        entity_obj = FileEntity(
                            name=e["name"],
                            qualified_name=e["qualified_name"],
                            file_path=e["file_path"],
                            line_start=e["line_start"],
                            line_end=e["line_end"],
                            language="python"  # Default, actual value not needed for embedding
                        )

                    entity_objects.append(entity_obj)
                    semantic_contexts.append(e.get("semantic_context"))

                try:
                    # Generate embeddings - use contextualized text if semantic_context available
                    texts = []
                    for entity_obj, context in zip(entity_objects, semantic_contexts):
                        if context and self.context_generator:
                            # Use contextualized text for better retrieval
                            text = self.context_generator.contextualize_text(entity_obj, context)
                        else:
                            # Fall back to standard entity text
                            text = self.embedder._entity_to_text(entity_obj)
                        texts.append(text)

                    embeddings = self.embedder.embed_batch(texts)

                    # Apply PCA compression if configured (thread-safe fitting)
                    if self.embedding_compressor:
                        # Thread-safe PCA fitting with double-checked locking
                        if not self.embedding_compressor.is_fitted:
                            with self._pca_fit_lock:
                                if not self.embedding_compressor.is_fitted:
                                    # Fit on first batch (need enough samples)
                                    logger.info("Fitting PCA compressor on embedding batch...")
                                    self.embedding_compressor.fit(embeddings, save=True)
                        embeddings = self.embedding_compressor.get_reduced_embeddings_batch(embeddings)
                        embedding_dims = self.embedding_target_dims
                    else:
                        embedding_dims = self.embedder.dimensions

                    # Store embeddings in LanceDB only (not on graph nodes)
                    # This keeps vectors on disk, not in FalkorDB RAM
                    is_compressed = self.embedding_compressor is not None
                    if self.vector_store is not None:
                        try:
                            entity_ids = [e["qualified_name"] for e in batch]
                            entity_types_list = [entity_type] * len(batch)
                            metadata = [
                                {
                                    "file_path": e.get("file_path", ""),
                                    "line_start": e.get("line_start", 0),
                                    "name": e.get("name", ""),
                                }
                                for e in batch
                            ]
                            indexed = self.vector_store.bulk_index(
                                entity_ids=entity_ids,
                                embeddings=embeddings,
                                entity_types=entity_types_list,
                                metadata=metadata,
                            )
                            logger.debug(
                                f"Indexed {indexed} embeddings to external vector store"
                            )
                        except Exception as vs_error:
                            logger.warning(
                                f"Failed to index to vector store (continuing with graph storage): {vs_error}"
                            )

                    entities_embedded += len(batch)
                    logger.debug(f"Embedded batch of {len(batch)} {entity_type} entities ({entities_embedded}/{total_count})")

                except Exception as e:
                    logger.error(f"Failed to generate embeddings for batch: {e}")
                    continue

        return entities_embedded

    async def _generate_contexts_for_all_entities(self) -> int:
        """Generate semantic contexts for all entities in the graph using Claude.

        Queries Neo4j for Function, Class, and File nodes without contexts,
        generates contexts using Claude, and updates the nodes.

        Uses paginated queries to avoid loading all entities into memory at once.
        This prevents OOM on large repositories with many entities.

        Returns:
            Number of entities that received contexts
        """
        if not self.context_generator:
            return 0

        from repotoire.models import FunctionEntity, ClassEntity, FileEntity, NodeType
        from repotoire.ai import CostLimitExceeded

        entities_contextualized = 0
        context_batch_size = 100  # Batch size for context generation AND DB fetch

        # FalkorDB uses id() while Neo4j uses elementId()
        id_func = "id" if self.is_falkordb else "elementId"

        # First, count how many entities need contexts
        total_count = self.db.count_entities_without_context()

        if total_count == 0:
            logger.info("No entities need context generation")
            return 0

        logger.info(f"Found {total_count} entities to generate contexts for (processing in batches of {context_batch_size})")

        # Process in paginated batches to avoid loading all entities into memory
        batch_num = 0
        cost_limit_reached = False

        while not cost_limit_reached:
            # Fetch one batch at a time (offset-based pagination)
            # Note: As we update entities with contexts, they won't appear in subsequent queries
            entity_records = self.db.get_entities_without_context(limit=context_batch_size)

            if not entity_records:
                # No more entities need context
                break

            batch_num += 1

            # Convert records to Entity objects for the context generator
            entities = []
            for record in entity_records:
                entity_type = record.get("entity_type", "Function")

                # Create appropriate entity type
                if entity_type == "Function":
                    entity = FunctionEntity(
                        name=record["name"],
                        qualified_name=record["qualified_name"],
                        file_path=record.get("file_path", ""),
                        line_start=record.get("line_start", 0),
                        line_end=record.get("line_end", 0),
                        docstring=record.get("docstring"),
                        parameters=[],
                    )
                elif entity_type == "Class":
                    entity = ClassEntity(
                        name=record["name"],
                        qualified_name=record["qualified_name"],
                        file_path=record.get("file_path", ""),
                        line_start=record.get("line_start", 0),
                        line_end=record.get("line_end", 0),
                        docstring=record.get("docstring"),
                    )
                else:  # File
                    entity = FileEntity(
                        name=record["name"],
                        qualified_name=record["qualified_name"],
                        file_path=record.get("file_path", ""),
                        line_start=record.get("line_start", 0),
                        line_end=record.get("line_end", 0),
                        language="python",
                    )

                entities.append(entity)

            try:
                # Progress callback for logging
                def on_progress(qn: str, count: int):
                    if count % 10 == 0:
                        logger.debug(f"Generated context for {count}/{len(entities)} entities in batch")

                # Generate contexts for batch
                contexts = await self.context_generator.generate_contexts_batch(
                    entities,
                    on_progress=on_progress,
                )

                # Store contexts in database
                if contexts:
                    updated = self.db.batch_set_contexts(contexts)
                    entities_contextualized += updated
                    logger.debug(f"Stored {updated} contexts (batch {batch_num}, total: {entities_contextualized}/{total_count})")

            except CostLimitExceeded as e:
                logger.warning(f"Context generation stopped due to cost limit: {e}")
                cost_limit_reached = True
            except Exception as e:
                logger.error(f"Failed to generate contexts for batch: {e}")
                continue

        return entities_contextualized

    def load_to_graph(
        self, entities: List[Entity], relationships: List[Relationship]
    ) -> None:
        """Load entities and relationships into FalkorDB.

        Args:
            entities: List of entities to create
            relationships: List of relationships to create
        """
        if not entities:
            return

        # Set repo_id and repo_slug on all entities for multi-tenant isolation
        if self.repo_id:
            for entity in entities:
                entity.repo_id = self.repo_id
                entity.repo_slug = self.repo_slug

        # REPO-600: Set tenant_id on all entities for organization-level isolation
        tenant_id = self._get_current_tenant_id()
        if tenant_id:
            for entity in entities:
                entity.tenant_id = tenant_id

        # Batch create nodes
        try:
            id_mapping = self.db.batch_create_nodes(entities)
            logger.info(f"Created {len(id_mapping)} nodes")

            # Minimal delay - BGSAVE disabled so no fork crashes
            time.sleep(0.05)

            # Batch create all relationships
            # Note: batch_create_relationships now accepts qualified names directly
            if relationships:
                self.db.batch_create_relationships(relationships)
                logger.info(f"Created {len(relationships)} relationships")
            else:
                logger.warning("No relationships to create")

            # Minimal delay after relationships
            time.sleep(0.05)

        except Exception as e:
            logger.error(f"Failed to load data to graph: {e}")

    def _find_dependent_files(self, changed_files: List[str], max_depth: int = 3) -> List[str]:
        """Find files that depend on changed files via import relationships.

        REPO-600: Filters by tenant_id for multi-tenant data isolation.

        This enables dependency-aware incremental analysis: when a file changes,
        we also need to re-analyze files that import it.

        Args:
            changed_files: List of file paths that changed
            max_depth: Maximum depth to traverse import relationships (default: 3)

        Returns:
            List of file paths that transitively depend on changed files
        """
        if not changed_files:
            return []

        logger.debug(f"Finding files dependent on {len(changed_files)} changed files")

        # REPO-600: Get tenant_id for filtering
        tenant_id = self._get_current_tenant_id()

        # Query to find files that import the changed files (bidirectional)
        # Split into two queries to avoid Cypher aggregation issues
        # REPO-600: Add tenant filtering to ensure isolation
        if tenant_id:
            query = """
            // Find files that import changed files (downstream impact)
            MATCH (f1:File)
            WHERE f1.filePath IN $changed_files AND f1.tenantId = $tenant_id
            OPTIONAL MATCH (f2:File)-[:IMPORTS*1..3]->(f1)
            WHERE f2.filePath IS NOT NULL AND f2.tenantId = $tenant_id

            RETURN DISTINCT f2.filePath as filePath

            UNION

            // Find files that changed files import (upstream dependencies)
            MATCH (f1:File)
            WHERE f1.filePath IN $changed_files AND f1.tenantId = $tenant_id
            OPTIONAL MATCH (f1)-[:IMPORTS*1..3]->(f3:File)
            WHERE f3.filePath IS NOT NULL AND f3.tenantId = $tenant_id

            RETURN DISTINCT f3.filePath as filePath
            """
            params = {
                "changed_files": changed_files,
                "tenant_id": tenant_id,
            }
        else:
            # No tenant context - use original query (single-tenant/dev mode)
            query = """
            // Find files that import changed files (downstream impact)
            MATCH (f1:File)
            WHERE f1.filePath IN $changed_files
            OPTIONAL MATCH (f2:File)-[:IMPORTS*1..3]->(f1)
            WHERE f2.filePath IS NOT NULL

            RETURN DISTINCT f2.filePath as filePath

            UNION

            // Find files that changed files import (upstream dependencies)
            MATCH (f1:File)
            WHERE f1.filePath IN $changed_files
            OPTIONAL MATCH (f1)-[:IMPORTS*1..3]->(f3:File)
            WHERE f3.filePath IS NOT NULL

            RETURN DISTINCT f3.filePath as filePath
            """
            params = {"changed_files": changed_files}

        try:
            result = self.db.execute_query(query, params)

            dependent_files = [record["filePath"] for record in result]
            logger.info(f"Found {len(dependent_files)} dependent files for {len(changed_files)} changed files")
            return dependent_files

        except Exception as e:
            logger.warning(f"Could not find dependent files (graph may be empty): {e}")
            return []

    @log_operation("ingest")
    def ingest(
        self,
        incremental: bool = False,
        patterns: Optional[List[str]] = None,
        progress_callback: Optional[Callable[[int, int, str], None]] = None
    ) -> IngestionResult:
        """Run the complete ingestion pipeline with security validation.

        Args:
            incremental: If True, only process changed files
            patterns: File patterns to match
            progress_callback: Optional callback function(current, total, filename) for progress tracking

        Returns:
            IngestionResult with files_processed count and changed_files list
        """
        start_time = time.time()

        # REPO-600: Log tenant context for audit trail
        from repotoire.tenant import get_tenant_context, log_tenant_operation
        tenant_ctx = get_tenant_context()
        if tenant_ctx:
            logger.info(
                "Starting ingestion pipeline",
                extra={
                    "tenant_id": tenant_ctx.org_id_str,
                    "tenant_slug": tenant_ctx.org_slug,
                    "repo_path": str(self.repo_path),
                    "incremental": incremental,
                },
            )
        else:
            logger.debug("Starting ingestion pipeline (no tenant context - single-tenant mode)")

        # Reset skipped files tracking
        self.skipped_files = []

        # Initialize schema
        with LogContext(operation="init_schema"):
            schema = GraphSchema(self.db)
            # Pass vector dimensions when embeddings are enabled
            if self.generate_embeddings and self.embedder:
                schema.initialize(
                    enable_vector_search=True,
                    vector_dimensions=self.embedder.dimensions,
                )
            else:
                schema.initialize()
            logger.debug("Schema initialized")

        # Scan for files
        with LogContext(operation="scan_files"):
            files = self.scan(patterns)
            default_patterns = ["**/*.py"]
            if _HAS_TYPESCRIPT_PARSER:
                default_patterns.extend(["**/*.ts", "**/*.tsx", "**/*.js", "**/*.jsx"])
            if self.rust_parser is not None:
                default_patterns.extend(["**/*.java", "**/*.go", "**/*.rs"])
            logger.info(f"Scanned repository", extra={
                "files_found": len(files),
                "patterns": patterns or default_patterns
            })

        if not files:
            logger.warning("No files found to process")
            self._clear_file_cache()  # Clear cache on early return
            if self.skipped_files:
                self._report_skipped_files()
            return

        # Incremental ingestion: filter files based on hash comparison
        files_to_process = []
        files_unchanged = 0
        files_changed = 0
        files_new = 0

        if incremental:
            logger.info("Running incremental ingestion (comparing file hashes)")

            # PERFORMANCE: Batch fetch all file metadata in a single query
            # instead of N queries (one per file)
            all_rel_paths = [self._get_relative_path(f) for f in files]
            file_path_map = {self._get_relative_path(f): f for f in files}

            # Batch fetch metadata for all files
            existing_metadata = self.db.batch_get_file_metadata(all_rel_paths)
            logger.debug(f"Fetched metadata for {len(existing_metadata)} existing files in single query")

            # PERFORMANCE: Identify files that need hash comparison (exist in DB)
            # Then batch compute hashes using Rust (parallel, ~10x faster than Python)
            files_needing_hash = [
                file_path_map[rel_path] for rel_path in file_path_map
                if existing_metadata.get(rel_path) is not None
            ]

            if files_needing_hash:
                # Compute all hashes in parallel using Rust
                hash_results = self._batch_compute_hashes(files_needing_hash)
            else:
                hash_results = {}

            # Track files that need deletion (changed files)
            files_to_delete = []

            for rel_path, file_path in file_path_map.items():
                metadata = existing_metadata.get(rel_path)

                if metadata is None:
                    # New file, need to ingest
                    files_to_process.append(file_path)
                    files_new += 1
                else:
                    # File exists in database, compare hashes
                    # Use hash from Rust batch computation (fast path)
                    resolved_path = str(file_path.resolve())
                    current_hash = hash_results.get(resolved_path)

                    if current_hash is None:
                        # Fallback to Python if Rust hash not available
                        _, current_hash, _ = self._get_file_content_and_hash(file_path)

                    if current_hash == metadata["hash"]:
                        # File unchanged, skip
                        logger.debug(f"Skipping unchanged file: {rel_path}")
                        files_unchanged += 1
                    else:
                        # File changed, need to re-ingest
                        logger.debug(f"File changed (hash mismatch): {rel_path}")
                        files_to_delete.append(rel_path)
                        files_to_process.append(file_path)
                        files_changed += 1

            # PERFORMANCE: Batch delete changed files in a single query
            if files_to_delete:
                self.db.batch_delete_file_entities(files_to_delete)
                logger.debug(f"Batch deleted {len(files_to_delete)} changed files")

            logger.info(f"Incremental scan: {files_new} new, {files_changed} changed, {files_unchanged} unchanged")

            # Find dependent files (files that import changed/new files)
            changed_and_new_paths = [self._get_relative_path(f) for f in files_to_process]
            dependent_paths = self._find_dependent_files(changed_and_new_paths)

            # Add dependent files to processing list
            if dependent_paths:
                dependent_files = []
                dependent_to_delete = []

                for dep_path in dependent_paths:
                    # Skip if already in processing list
                    if dep_path in changed_and_new_paths:
                        continue

                    # Get Path object for dependent file
                    if dep_path in file_path_map:
                        dep_file = file_path_map[dep_path]
                        dependent_to_delete.append(dep_path)
                        dependent_files.append(dep_file)

                # PERFORMANCE: Batch delete dependent files in a single query
                if dependent_to_delete:
                    self.db.batch_delete_file_entities(dependent_to_delete)
                    logger.debug(f"Batch deleted {len(dependent_to_delete)} dependent files")

                if dependent_files:
                    logger.info(f"Found {len(dependent_files)} dependent files that need re-analysis")
                    files_to_process.extend(dependent_files)

            # Clean up deleted files (files in DB but not on filesystem)
            all_scanned_paths = {self._get_relative_path(f) for f in files}
            all_db_paths = set(self.db.get_all_file_paths())
            deleted_paths = all_db_paths - all_scanned_paths

            # PERFORMANCE: Batch delete removed files in a single query
            if deleted_paths:
                logger.info(f"Cleaning up {len(deleted_paths)} deleted files from graph")
                self.db.batch_delete_file_entities(list(deleted_paths))
        else:
            # Full ingestion: process all files
            files_to_process = files
            # For full ingestion, all files are "changed" from detector perspective
            changed_and_new_paths = [self._get_relative_path(f) for f in files]

        if not files_to_process:
            logger.info("No files to process (all files unchanged)")
            self._clear_file_cache()  # Clear cache on early return
            return IngestionResult(
                files_processed=0,
                files_failed=0,
                files_skipped=len(self.skipped_files),
                changed_files=[],  # No changes
                incremental=incremental,
                files_new=files_new if incremental else 0,
                files_changed=files_changed if incremental else 0,
                files_unchanged=files_unchanged if incremental else 0,
            )

        # Process each file
        all_entities = []
        all_relationships = []
        files_processed = 0
        files_failed = 0

        # PHASE 2 OPTIMIZATION: Use Rust parallel parser when available
        rust_parsed_files = set()
        if self.rust_parser:
            rust_files, fallback_files = self._separate_rust_parseable_files(files_to_process)

            if rust_files:
                parse_start = time.time()
                logger.info(f"Batch parsing {len(rust_files)} files with Rust parallel parser...")

                # Read and parse all Rust-supported files in parallel
                parsed_results = self._batch_parse_with_rust(rust_files)
                parse_duration = time.time() - parse_start

                logger.info(
                    f"Rust parallel parsing complete: {len(parsed_results)} files in {parse_duration:.2f}s "
                    f"({len(parsed_results)/parse_duration:.0f} files/sec)"
                )

                # Process results
                for file_path, (entities, relationships) in parsed_results.items():
                    rust_parsed_files.add(Path(file_path))
                    if entities:
                        files_processed += 1
                        all_entities.extend(entities)
                        all_relationships.extend(relationships)

                        # Generate semantic clues if enabled
                        if self.generate_clues:
                            clue_entities, clue_relationships = self._generate_clues_for_entities(entities)
                            all_entities.extend(clue_entities)
                            all_relationships.extend(clue_relationships)

                        # Batch load entities for better performance
                        if len(all_entities) >= self.batch_size:
                            batch_start = time.time()
                            self.load_to_graph(all_entities, all_relationships)
                            batch_duration = time.time() - batch_start

                            logger.debug("Loaded batch", extra={
                                "entities": len(all_entities),
                                "relationships": len(all_relationships),
                                "duration_seconds": round(batch_duration, 3)
                            })

                            all_entities = []
                            all_relationships = []
                    else:
                        files_failed += 1

        # Process remaining files with Python parser (sequential fallback)
        remaining_files = [f for f in files_to_process if f not in rust_parsed_files]
        if remaining_files:
            logger.debug(f"Processing {len(remaining_files)} files with Python parser")

        for i, file_path in enumerate(remaining_files, 1):
            with LogContext(operation="parse_file", file=str(file_path), progress=f"{i}/{len(remaining_files)}"):
                logger.debug(f"Processing file {i}/{len(remaining_files)}: {file_path}")

                # Call progress callback if provided
                if progress_callback:
                    total = len(files_to_process)
                    current = len(rust_parsed_files) + i
                    progress_callback(current, total, str(file_path))

                entities, relationships = self.parse_and_extract(file_path)

                if entities:
                    files_processed += 1
                    all_entities.extend(entities)
                    all_relationships.extend(relationships)

                    # Generate semantic clues if enabled
                    if self.generate_clues:
                        clue_entities, clue_relationships = self._generate_clues_for_entities(entities)
                        all_entities.extend(clue_entities)
                        all_relationships.extend(clue_relationships)
                else:
                    files_failed += 1

                # Batch load entities for better performance
                if len(all_entities) >= self.batch_size:
                    batch_start = time.time()
                    self.load_to_graph(all_entities, all_relationships)
                    batch_duration = time.time() - batch_start

                    logger.debug("Loaded batch", extra={
                        "entities": len(all_entities),
                        "relationships": len(all_relationships),
                        "duration_seconds": round(batch_duration, 3)
                    })

                    all_entities = []
                    all_relationships = []

        # Load remaining entities
        if all_entities:
            self.load_to_graph(all_entities, all_relationships)
            logger.debug("Loaded final batch", extra={
                "entities": len(all_entities),
                "relationships": len(all_relationships)
            })

        # Show stats
        stats = self.db.get_stats()
        total_duration = time.time() - start_time

        log_extra = {
            "stats": stats,
            "files_total": len(files),
            "files_processed": files_processed,
            "files_failed": files_failed,
            "files_skipped": len(self.skipped_files),
            "duration_seconds": round(total_duration, 2),
            "files_per_second": round(len(files_to_process) / total_duration, 2) if total_duration > 0 else 0
        }

        # Add incremental stats if applicable
        if incremental:
            log_extra["incremental"] = {
                "new": files_new,
                "changed": files_changed,
                "unchanged": files_unchanged,
            }

        # Generate semantic contexts using Claude if enabled (REPO-242)
        if self.generate_contexts and self.context_generator:
            import asyncio
            logger.info("Generating semantic contexts for entities...")
            context_start = time.time()
            contexts_generated = asyncio.run(self._generate_contexts_for_all_entities())
            context_duration = time.time() - context_start
            logger.info(f"Contexts generated for {contexts_generated} entities in {context_duration:.2f}s")

            # Log cost summary if tracking enabled
            if self.context_generator.cost_tracker:
                cost_summary = self.context_generator.cost_tracker.summary()
                logger.info(f"Context generation cost: ${cost_summary['total_cost_usd']:.4f}")
                log_extra["context_cost"] = cost_summary

        # Generate embeddings for all entities if enabled
        if self.generate_embeddings and self.embedder:
            logger.info("Generating embeddings for all entities...")
            embedding_start = time.time()
            entities_embedded = self._generate_embeddings_for_all_entities()
            embedding_duration = time.time() - embedding_start
            logger.info(f"Embeddings generated for {entities_embedded} entities in {embedding_duration:.2f}s")

        # Resolve internal calls (link CALLS relationships to internal functions)
        logger.info("Resolving internal function calls...")
        resolve_start = time.time()
        calls_resolved = self._resolve_internal_calls()
        resolve_duration = time.time() - resolve_start
        logger.info(f"Resolved {calls_resolved} internal calls in {resolve_duration:.2f}s")

        # Validate resolved calls using graph-based community detection
        logger.info("Validating call resolutions with graph structure...")
        validation_start = time.time()
        validation_stats = self._validate_calls_with_graph()
        validation_duration = time.time() - validation_start
        if validation_stats["high_confidence"] > 0:
            total_validated = sum(validation_stats.values())
            high_pct = validation_stats["high_confidence"] / total_validated * 100 if total_validated > 0 else 0
            logger.info(
                f"Call validation complete in {validation_duration:.2f}s: "
                f"{validation_stats['high_confidence']} high ({high_pct:.1f}%), "
                f"{validation_stats['medium_confidence']} medium, "
                f"{validation_stats['low_confidence']} low confidence"
            )

        # Build path expression cache for O(1) reachability queries (REPO-416)
        # This enables 100-1000x speedup in detectors like TrulyUnusedImports, DeadCode, etc.
        logger.info("Building path expression cache for fast reachability queries...")
        path_cache = self._build_path_cache()

        logger.info("Ingestion complete", extra=log_extra)

        # Clear file content cache to free memory
        self._clear_file_cache()

        # Report skipped files if any
        if self.skipped_files:
            self._report_skipped_files()

        # Run post-ingestion callbacks (e.g., RAG cache invalidation)
        self._run_on_ingest_complete_callbacks()

        # Build final list of changed files (includes dependents for incremental)
        # For hybrid detectors to filter their analysis scope
        final_changed_files = []
        if incremental:
            # changed_and_new_paths + dependent files that were processed
            final_changed_files = [self._get_relative_path(f) for f in files_to_process]
        else:
            # Full ingestion: all files
            final_changed_files = changed_and_new_paths

        return IngestionResult(
            files_processed=files_processed,
            files_failed=files_failed,
            files_skipped=len(self.skipped_files),
            changed_files=final_changed_files,
            incremental=incremental,
            files_new=files_new if incremental else 0,
            files_changed=files_changed if incremental else 0,
            files_unchanged=files_unchanged if incremental else 0,
            path_cache=path_cache,
        )

    def _run_type_inference(self) -> Dict[str, Dict[str, str]]:
        """Run Rust-based type inference to build accurate call graph.

        Returns:
            Dict mapping caller_qn -> {target_simple_name -> resolved_callee_qn}
            This allows us to resolve "self.method()" to the actual method qualified name.
        """
        type_inferred_calls: Dict[str, Dict[str, str]] = defaultdict(dict)

        try:
            import repotoire_fast as rf
        except ImportError:
            logger.debug("repotoire_fast not available, skipping type inference")
            return dict(type_inferred_calls)  # Return regular dict

        try:
            # Step 1: Get all source files with their paths
            files_query = """
            MATCH (f:File)
            WHERE f.filePath IS NOT NULL AND f.filePath ENDS WITH '.py'
            RETURN f.filePath as path
            """
            files_result = self.db.execute_query(files_query)

            # Read source files
            files_to_process = []
            for f in files_result:
                file_path = f["path"]
                # Convert relative path to absolute
                abs_path = str(self.repo_path / file_path) if not file_path.startswith("/") else file_path
                try:
                    with open(abs_path, "r", encoding="utf-8", errors="replace") as fp:
                        source = fp.read()
                    files_to_process.append((abs_path, source))
                except Exception as e:
                    logger.debug(f"Could not read {abs_path} for type inference: {e}")

            if not files_to_process:
                return type_inferred_calls

            # Step 2: Run type inference
            logger.debug(f"Running type inference on {len(files_to_process)} files...")
            ti_result = rf.infer_types(files_to_process, 10)
            logger.debug(
                f"Type inference complete: {ti_result['num_definitions']} definitions, "
                f"{ti_result['num_classes']} classes, {ti_result['num_calls']} calls"
            )

            # Step 3: Build mapping from type inference namespace to graph qualified names
            # Type inference uses: module.Class.method
            # Graph uses: /path/to/file.py::Class.method:123

            # Get all Functions with their qualified names and simple names
            # Note: All internal Function nodes have '::' in qualifiedName (file.py::func:line)
            funcs_query = """
            MATCH (f:Function)
            WHERE f.qualifiedName IS NOT NULL
            RETURN f.qualifiedName as qn, f.name as name
            """
            funcs = self.db.execute_query(funcs_query)

            # Pre-compute package directories from files_result (which has relative paths)
            # This matches how Rust detects packages
            package_dirs: set[str] = set()
            for f in files_result:
                fp = f["path"]
                # Normalize path for cross-platform compatibility
                fp_norm = os.path.normpath(fp)
                basename = os.path.basename(fp_norm)
                if basename == "__init__.py":
                    # Get the directory containing __init__.py
                    dir_path = os.path.dirname(fp_norm)
                    if dir_path:
                        package_dirs.add(dir_path)

            logger.debug(f"Detected {len(package_dirs)} package directories")

            # Pre-compute file lookup table for O(1) path matching - O(m) construction
            # Index by all suffix paths so we can match absolute paths against relative paths
            file_lookup: Dict[str, dict] = {}
            for f in files_result:
                fp = f["path"]
                fp_norm = os.path.normpath(fp)
                # Store normalized path on the dict for later use
                f["_normalized_path"] = fp_norm

                # Index by all suffixes: full path, then progressively shorter
                # e.g., "repotoire/models.py" → keys: "repotoire/models.py", "models.py"
                parts = fp_norm.split(os.sep)
                for i in range(len(parts)):
                    suffix = os.sep.join(parts[i:])
                    if suffix not in file_lookup:  # First match wins (matches original behavior)
                        file_lookup[suffix] = f

            logger.debug(f"Built file lookup table with {len(file_lookup)} suffix entries for {len(files_result)} files")

            # Build mapping: (file_module, entity_path) -> graph_qn
            # e.g., ("repotoire.models", "Finding.__init__") -> "/path/repotoire/models.py::Finding.__init__:45"
            ti_ns_to_graph_qn: Dict[str, str] = {}
            graph_qn_to_ti_ns: Dict[str, str] = {}

            for func in funcs:
                qn = func["qn"]
                # Use cached parsing for qualified names (significant speedup for large codebases)
                file_part, entity_part, _ = _parse_qualified_name(qn)
                if not entity_part:  # Parsing failed or no :: separator
                    continue

                # Convert file path to module path for matching
                # Must match Rust file_to_module_ns: uses package detection from __init__.py
                module_path = None

                # Find the relative path from files_result that matches this absolute path
                # Graph QN has absolute path, files_result has relative paths
                # Use pre-computed lookup table for O(1) matching instead of O(m) inner loop
                file_part_norm = os.path.normpath(file_part)

                # Try suffixes of file_part_norm until we find a match
                # e.g., "/home/user/project/repotoire/models.py" tries:
                #   "home/user/project/repotoire/models.py", "user/project/repotoire/models.py", ...
                #   until it matches "repotoire/models.py" in the lookup table
                relative_file_path = None
                parts = _split_path_components(file_part_norm)  # Cached split
                for i in range(len(parts)):
                    suffix = os.sep.join(parts[i:])
                    matched_file = file_lookup.get(suffix)
                    if matched_file:
                        relative_file_path = matched_file["_normalized_path"]
                        break

                if relative_file_path:
                    # Remove .py extension using os.path
                    path_without_ext, _ = os.path.splitext(relative_file_path)

                    # Get file directory
                    file_dir = os.path.dirname(path_without_ext)

                    # Find the topmost package that is an ancestor of this file
                    package_root = None
                    for pkg_dir in package_dirs:
                        pkg_dir_norm = os.path.normpath(pkg_dir)
                        # Check if pkg_dir is an ancestor of file_dir
                        if file_dir == pkg_dir_norm or file_dir.startswith(pkg_dir_norm + os.sep):
                            # Find topmost (shortest path)
                            if package_root is None or len(pkg_dir_norm) < len(package_root):
                                package_root = pkg_dir_norm

                    if package_root:
                        # Match Rust logic: strip parent of package root, then use relative path
                        # e.g., package_root = "repotoire", parent = "", result = whole path
                        # e.g., package_root = "tests/unit", parent = "tests", result = strip "tests/"
                        parent = os.path.dirname(package_root)
                        if not parent:
                            # Package is at the root level (e.g., "repotoire")
                            module_path = path_without_ext.replace(os.sep, ".")
                        elif path_without_ext.startswith(parent + os.sep):
                            # Strip the parent directory
                            rel_path = path_without_ext[len(parent) + 1:]  # +1 for separator
                            module_path = rel_path.replace(os.sep, ".")
                        else:
                            module_path = path_without_ext.replace(os.sep, ".")
                    else:
                        # Fallback: use whole relative path
                        module_path = path_without_ext.replace(os.sep, ".")
                else:
                    # Fallback for paths not in files_result: use last 4 components
                    path_without_ext, _ = os.path.splitext(file_part)
                    # Split by both forward and back slashes for cross-platform
                    parts = [p for p in path_without_ext.replace("\\", "/").split("/") if p]
                    if len(parts) > 4:
                        parts = parts[-4:]
                    module_path = ".".join(parts)

                if module_path:
                    # Build type inference namespace: module.Entity
                    ti_ns = f"{module_path}.{entity_part}"
                    ti_ns_to_graph_qn[ti_ns] = qn
                    graph_qn_to_ti_ns[qn] = ti_ns

            logger.debug(f"Built {len(ti_ns_to_graph_qn)} type inference -> graph mappings")

            # Step 4: Convert type inference call graph to graph-based resolution map
            call_graph = ti_result.get("call_graph", {})
            for caller_ti_ns, callees in call_graph.items():
                # Find the graph qualified name for this caller
                caller_qn = ti_ns_to_graph_qn.get(caller_ti_ns)
                if not caller_qn:
                    continue

                # For each callee, try to find its graph qualified name
                for callee_ti_ns in callees:
                    callee_qn = ti_ns_to_graph_qn.get(callee_ti_ns)
                    if callee_qn:
                        # Extract simple name from callee
                        simple_name = callee_ti_ns.split(".")[-1]
                        type_inferred_calls[caller_qn][simple_name] = callee_qn

            logger.info(
                f"Type inference resolved {sum(len(v) for v in type_inferred_calls.values())} "
                f"calls across {len(type_inferred_calls)} callers"
            )
            # Debug: log sample of type_inferred_calls keys
            if type_inferred_calls:
                sample_keys = list(type_inferred_calls.keys())[:3]
                logger.debug(f"Type inference sample callers: {sample_keys}")

        except Exception as e:
            logger.debug(f"Type inference failed (will use fallback resolution): {e}")

        return type_inferred_calls

    def _resolve_internal_calls(self) -> int:
        """Resolve CALLS relationships to internal functions/classes.

        During parsing, cross-file calls are created with simple names (e.g., "some_func")
        that don't match the full qualified names of internal Function nodes. This method
        finds those unresolved calls and links them to the actual internal entities.

        Resolution priority (uses multiple strategies for accuracy):
        0. Type inference: Rust-based PyCG-style analysis (highest accuracy)
        1. Same file: Entity defined in the same file as caller
        2. Imported: Entity from a file that the caller's file imports
        3. Class method: Entity that's a method on a class the caller uses
        4. Community-guided: Use Leiden community membership
        5. Fallback: First matching entity (rare)

        This enables graph analysis features like:
        - Function-to-function call graphs
        - PageRank/betweenness centrality on internal code
        - Circular dependency detection

        Returns:
            Number of calls resolved to internal entities
        """
        calls_resolved = 0
        type_inferred_count = 0
        import time as time_module
        step_start = time_module.time()

        # Run type inference first (highest accuracy)
        type_inferred_calls = self._run_type_inference()
        logger.info(f"[TIMING] Type inference completed in {time_module.time() - step_start:.1f}s")

        # Pre-compute community memberships for graph-aware fallback selection
        # Use File-level IMPORTS relationships (which exist before call resolution)
        # to compute communities, then propagate to all functions in each file
        qn_to_community: Dict[str, int] = {}
        step_start = time_module.time()
        try:
            import repotoire_fast as rf

            # Get all Files with their paths
            file_query = """
            MATCH (f:File)
            WHERE f.filePath IS NOT NULL
            RETURN f.filePath as path
            ORDER BY f.filePath
            """
            files = self.db.execute_query(file_query)
            if files:
                file_paths = [f["path"] for f in files]
                file_to_idx = {path: i for i, path in enumerate(file_paths)}

                # Get import relationships between files (via External* nodes)
                # File A imports module X, File B defines module X -> A imports B
                # Use Rust for fast O(n) matching instead of slow O(n²) Cypher queries
                import_edges = []
                try:
                    logger.info(f"[TIMING] Running import edge matching (Rust)...")
                    query_start = time_module.time()

                    # Get imports: (src_file, imported_name)
                    imports_query = """
                    MATCH (f:File)-[:IMPORTS]->(ext)
                    WHERE (ext:ExternalClass OR ext:ExternalFunction)
                      AND ext.qualifiedName IS NOT NULL
                    RETURN f.filePath as src, split(ext.qualifiedName, '.')[-1] as name
                    """
                    imports_data = self.db.execute_query(imports_query)
                    imports = [(r["src"], r["name"]) for r in imports_data if r["src"] and r["name"]]
                    logger.info(f"[TIMING] Fetched {len(imports)} imports in {time_module.time() - query_start:.1f}s")

                    # Get entities: (dst_file, entity_name)
                    # Note: Don't filter by '::' - Python uses '.' separators
                    # Note: FalkorDB uses labels() function for label checks instead of inline syntax
                    entities_query = """
                    MATCH (f:File)-[:CONTAINS]->(e)
                    WHERE ('Function' IN labels(e) OR 'Class' IN labels(e))
                      AND e.qualifiedName IS NOT NULL
                      AND e.name IS NOT NULL
                    RETURN f.filePath as dst, e.name as name
                    """
                    entity_start = time_module.time()
                    entities_data = self.db.execute_query(entities_query)
                    entities = [(r["dst"], r["name"]) for r in entities_data if r["dst"] and r["name"]]
                    logger.info(f"[TIMING] Fetched {len(entities)} entities in {time_module.time() - entity_start:.1f}s")

                    # Match in Rust (O(n) with HashMap vs O(n²) in Cypher)
                    match_start = time_module.time()
                    matched_edges = rf.match_import_edges_parallel(imports, entities)
                    import_edges = [{"src": src, "dst": dst} for src, dst in matched_edges]
                    logger.info(f"[TIMING] Rust matching: {len(import_edges)} edges in {time_module.time() - match_start:.3f}s")
                    logger.info(f"[TIMING] Total import_edges: {time_module.time() - query_start:.1f}s")
                except Exception as e:
                    logger.warning(f"Import edges matching failed (non-critical): {e}")
                edges = []
                for e in import_edges:
                    if e["src"] in file_to_idx and e["dst"] in file_to_idx:
                        edges.append((file_to_idx[e["src"]], file_to_idx[e["dst"]]))

                if edges:
                    file_communities = rf.graph_leiden_parallel(
                        edges, len(file_paths), resolution=1.0, max_iterations=10, parallel=True
                    )
                    file_to_community = {path: comm for path, comm in zip(file_paths, file_communities)}

                    # Now map functions to their file's community
                    # Use multi-hop to include class methods (File->Class->Method)
                    func_file_query = """
                    MATCH (f:File)-[:CONTAINS*1..2]->(func:Function)
                    WHERE func.qualifiedName IS NOT NULL
                    RETURN func.qualifiedName as qn, f.filePath as file_path
                    """
                    func_files = self.db.execute_query(func_file_query)
                    for ff in func_files:
                        if ff["file_path"] in file_to_community:
                            qn_to_community[ff["qn"]] = file_to_community[ff["file_path"]]

                    logger.debug(
                        f"Pre-computed {len(set(file_communities))} file communities, "
                        f"mapped to {len(qn_to_community)} functions"
                    )
        except ImportError:
            pass  # repotoire_fast not available
        except Exception as e:
            logger.debug(f"Community pre-computation failed (will use random fallback): {e}")
        logger.info(f"[TIMING] Community pre-computation completed in {time_module.time() - step_start:.1f}s")

        step_start = time_module.time()
        try:
            # Step 1: Build a map of simple names to internal qualified names
            # Query all internal Functions and Classes
            # Note: Use UNION instead of WHERE label checks for FalkorDB compatibility
            internal_entities_query = """
            MATCH (e:Function)
            WHERE e.qualifiedName IS NOT NULL
            RETURN e.name as name, e.qualifiedName as qualified_name, 'Function' as label
            UNION
            MATCH (e:Class)
            WHERE e.qualifiedName IS NOT NULL
            RETURN e.name as name, e.qualifiedName as qualified_name, 'Class' as label
            """
            internal_entities = self.db.execute_query(internal_entities_query)
            logger.info(f"[TIMING] internal_entities_query: {len(internal_entities)} entities in {time_module.time() - step_start:.1f}s")

            # Build name -> list of qualified names (multiple entities can have same name)
            name_to_qualified: Dict[str, List[Dict]] = defaultdict(list)
            for entity in internal_entities:
                name = entity["name"]
                name_to_qualified[name].append({
                    "qualified_name": entity["qualified_name"],
                    "label": entity["label"]
                })

            logger.debug(f"Built internal entity map with {len(name_to_qualified)} unique names")

            # Step 1b: Build import map using IMPORTS relationships in the graph
            # IMPORTS go from File -> External* nodes with module paths like "repotoire.mcp.models.Class"
            # We need to convert these to file paths and map to internal entities
            # Note: Use UNION instead of WHERE label checks for FalkorDB compatibility
            imports_query = """
            MATCH (f:File)-[:IMPORTS]->(imported:ExternalClass)
            RETURN f.filePath as importer_path, imported.qualifiedName as imported_qn
            UNION
            MATCH (f:File)-[:IMPORTS]->(imported:ExternalFunction)
            RETURN f.filePath as importer_path, imported.qualifiedName as imported_qn
            """
            query_start = time_module.time()
            imports_result = self.db.execute_query(imports_query)
            logger.info(f"[TIMING] imports_query: {len(imports_result)} imports in {time_module.time() - query_start:.1f}s")

            # Map: file_path -> set of imported module prefixes (e.g., "repotoire.mcp.models")
            file_import_modules: Dict[str, set] = defaultdict(set)
            for imp in imports_result:
                importer = imp["importer_path"]
                imported_qn = imp["imported_qn"]
                if not importer or not imported_qn:
                    continue
                # Store the full imported qualified name and its module prefix
                file_import_modules[importer].add(imported_qn)
                # Also store module prefix (e.g., "repotoire.mcp.models" from "repotoire.mcp.models.Class")
                module_prefix = _get_module_prefix(imported_qn)  # Cached
                if module_prefix:
                    file_import_modules[importer].add(module_prefix)

            # Build mapping from module path to file path for internal files
            # e.g., "repotoire.mcp.models" -> "repotoire/mcp/models.py"
            module_to_file: Dict[str, str] = {}
            for entity in internal_entities:
                qn = entity["qualified_name"]
                if "::" in qn:
                    # Extract file path from qualified name: /full/path/file.py::Entity:line
                    file_path = qn.split("::")[0]
                    # Convert absolute path to module-like path
                    # /home/user/project/repotoire/mcp/models.py -> repotoire.mcp.models
                    try:
                        rel_path = str(Path(file_path).relative_to(self.repo_path))
                        if rel_path.endswith(".py"):
                            rel_path = rel_path[:-3]  # Remove .py
                        # rel_path is now like "repotoire/mcp/models" - convert to module path
                        module_path = rel_path.replace("/", ".")
                        module_to_file[module_path] = file_path
                    except ValueError:
                        # Path is not within repo_path, skip this entity
                        pass

            logger.debug(f"Built import map for {len(file_import_modules)} files, {len(module_to_file)} module mappings")

            # Step 2: Find CALLS relationships where target is External*
            # Note: Use UNION instead of WHERE label checks for FalkorDB compatibility
            external_calls_query = """
            MATCH (caller:Function)-[r:CALLS]->(target:ExternalFunction)
            WHERE target.name IS NOT NULL
            RETURN
                caller.qualifiedName as caller_qn,
                target.name as target_name,
                target.qualifiedName as target_qn,
                'ExternalFunction' as target_label,
                r.line as line,
                r.call_name as call_name,
                r.is_self_call as is_self_call
            UNION
            MATCH (caller:Function)-[r:CALLS]->(target:ExternalClass)
            WHERE target.name IS NOT NULL
            RETURN
                caller.qualifiedName as caller_qn,
                target.name as target_name,
                target.qualifiedName as target_qn,
                'ExternalClass' as target_label,
                r.line as line,
                r.call_name as call_name,
                r.is_self_call as is_self_call
            UNION
            MATCH (caller:Function)-[r:CALLS]->(target:BuiltinFunction)
            WHERE target.name IS NOT NULL
            RETURN
                caller.qualifiedName as caller_qn,
                target.name as target_name,
                target.qualifiedName as target_qn,
                'BuiltinFunction' as target_label,
                r.line as line,
                r.call_name as call_name,
                r.is_self_call as is_self_call
            """
            query_start = time_module.time()
            external_calls = self.db.execute_query(external_calls_query)
            logger.info(f"[TIMING] external_calls_query: {len(external_calls)} calls in {time_module.time() - query_start:.1f}s")

            # Step 3: For each external call, try to resolve to internal entity
            # Collect all resolutions for batch processing (performance optimization)
            loop_start = time_module.time()
            resolutions = []  # List of dicts with resolution data
            fallback_count = 0
            community_guided_fallback = 0
            for call in external_calls:
                target_name = call["target_name"]
                caller_qn = call["caller_qn"]

                if target_name not in name_to_qualified:
                    continue  # No internal entity with this name

                # Find the best matching internal entity
                candidates = name_to_qualified[target_name]
                best_match = None

                # Extract caller's file path for context (both absolute and relative)
                caller_file_abs = caller_qn.split("::")[0] if "::" in caller_qn else None
                caller_file_rel = None
                if caller_file_abs:
                    # Convert absolute path to relative path (relative to repo root)
                    # File.filePath uses relative paths like "tests/unit/file.py" or "repotoire/models.py"
                    try:
                        caller_file_rel = str(Path(caller_file_abs).relative_to(self.repo_path))
                    except ValueError:
                        # Path is not within repo_path, leave as None
                        pass

                # Priority 0: Type inference resolution (highest accuracy)
                if caller_qn in type_inferred_calls:
                    if target_name in type_inferred_calls[caller_qn]:
                        resolved_qn = type_inferred_calls[caller_qn][target_name]
                        # Find the matching candidate
                        for candidate in candidates:
                            if candidate["qualified_name"] == resolved_qn:
                                best_match = candidate
                                type_inferred_count += 1
                                break
                    elif type_inferred_count < 3:  # Debug first few misses
                        logger.debug(f"Type inference miss: caller has {list(type_inferred_calls[caller_qn].keys())}, looking for '{target_name}'")
                elif type_inferred_count < 3 and target_name in name_to_qualified:  # Debug first few
                    logger.debug(f"Type inference miss: caller_qn={caller_qn[:80]} not in type_inferred_calls")

                # Priority 1: Same file match
                if not best_match:
                    for candidate in candidates:
                        cand_qn = candidate["qualified_name"]
                        cand_file = cand_qn.split("::")[0] if "::" in cand_qn else None
                        if caller_file_abs and cand_file == caller_file_abs:
                            best_match = candidate
                            break

                # Priority 2: Imported module match (use graph IMPORTS relationships)
                # Check if the candidate's module is imported by the caller's file
                # Debug: log first few mismatches to understand path format
                if not best_match and caller_file_rel and caller_file_rel not in file_import_modules:
                    if fallback_count < 3:  # Only log first 3
                        logger.debug(f"Import map miss: caller_file_rel={caller_file_rel}, available keys sample: {list(file_import_modules.keys())[:5]}")
                if not best_match and caller_file_rel and caller_file_rel in file_import_modules:
                    imported_modules = file_import_modules[caller_file_rel]
                    for candidate in candidates:
                        cand_qn = candidate["qualified_name"]
                        if "::" in cand_qn:
                            cand_file_abs = cand_qn.split("::")[0]
                            # Convert candidate's file to module path
                            # /home/user/project/repotoire/mcp/models.py -> repotoire.mcp.models
                            try:
                                cand_rel = str(Path(cand_file_abs).relative_to(self.repo_path))
                                if cand_rel.endswith(".py"):
                                    cand_rel = cand_rel[:-3]
                                # cand_rel is like "repotoire/mcp/models" - convert directly
                                cand_module = cand_rel.replace("/", ".")
                                # Check if this module (or entity) is imported
                                entity_name = candidate["qualified_name"].split("::")[-1].split(":")[0]
                                entity_full = cand_module + "." + entity_name
                                if cand_module in imported_modules or entity_full in imported_modules:
                                    best_match = candidate
                                    break
                            except ValueError:
                                # Path is not within repo_path, skip this candidate
                                continue

                # Priority 3: Check if it's a method call on a class we use (via USES relationship)
                # This handles cases like: obj = SomeClass(); obj.method()
                is_self_call_val = call.get("is_self_call", False)
                is_self_call_check = (is_self_call_val if isinstance(is_self_call_val, bool)
                                      else str(is_self_call_val).lower() == "true")
                if not best_match and is_self_call_check:
                    # For self calls, prefer methods from classes in same file
                    for candidate in candidates:
                        if candidate["label"] == "Function":
                            cand_qn = candidate["qualified_name"]
                            # Check if this is a method (has class in path)
                            if "::" in cand_qn and "." in cand_qn.split("::")[-1]:
                                best_match = candidate
                                break

                # Fallback: Use community-aware selection if available
                if not best_match and candidates:
                    if len(candidates) == 1:
                        best_match = candidates[0]
                    elif qn_to_community and caller_qn in qn_to_community:
                        # Use community membership to pick best candidate
                        caller_comm = qn_to_community[caller_qn]
                        scored_candidates = []
                        for candidate in candidates:
                            cand_qn = candidate["qualified_name"]
                            if cand_qn in qn_to_community:
                                cand_comm = qn_to_community[cand_qn]
                                # Score: 2 for same community, 1 for any community, 0 for no community
                                score = 2 if cand_comm == caller_comm else 1
                            else:
                                score = 0
                            scored_candidates.append((score, candidate))
                        # Pick highest scored candidate
                        scored_candidates.sort(key=lambda x: x[0], reverse=True)
                        best_match = scored_candidates[0][1]
                        community_guided_fallback += 1
                    else:
                        # No community info, use first candidate
                        best_match = candidates[0]
                    fallback_count += 1

                if best_match:
                    # Collect resolution data for batch processing
                    # Ensure is_self_call is a proper boolean (FalkorDB may return it as string)
                    is_self_call_raw = call.get("is_self_call", False)
                    is_self_call = bool(is_self_call_raw) if not isinstance(is_self_call_raw, str) else is_self_call_raw.lower() == "true"
                    resolutions.append({
                        "caller_qn": caller_qn,
                        "old_target_qn": call["target_qn"],
                        "new_target_qn": best_match["qualified_name"],
                        "line": call.get("line"),
                        "call_name": call.get("call_name"),
                        "is_self_call": is_self_call,
                    })

            logger.info(f"[TIMING] Resolution matching loop: {len(resolutions)} resolutions in {time_module.time() - loop_start:.1f}s")

            # Step 4: Execute batch resolution query
            # Using UNWIND for efficient bulk processing instead of per-call queries
            batch_start = time_module.time()
            if resolutions:
                BATCH_SIZE = 10000  # Chunk to avoid memory issues with huge batches
                resolve_query = """
                UNWIND $resolutions AS res
                MATCH (caller:Function {qualifiedName: res.caller_qn})-[r:CALLS]->(old_target {qualifiedName: res.old_target_qn})
                MATCH (new_target {qualifiedName: res.new_target_qn})
                DELETE r
                MERGE (caller)-[r2:CALLS]->(new_target)
                ON CREATE SET r2.line = res.line, r2.call_name = res.call_name, r2.is_self_call = res.is_self_call, r2.resolved = true
                RETURN count(r2) as created
                """
                try:
                    for i in range(0, len(resolutions), BATCH_SIZE):
                        chunk = resolutions[i:i + BATCH_SIZE]
                        if len(resolutions) > BATCH_SIZE:
                            logger.debug(f"Processing resolution batch {i // BATCH_SIZE + 1}: {len(chunk)} calls")
                        result = self.db.execute_query(resolve_query, {"resolutions": chunk})
                        if result and result[0]["created"] > 0:
                            calls_resolved += result[0]["created"]
                    logger.info(f"Batch resolved {calls_resolved} calls to internal entities")
                except Exception as e:
                    logger.warning(f"Batch call resolution failed: {e}")
                    # Fall back to individual queries for debugging
                    logger.debug("Attempting individual call resolution for debugging...")
                    for res in resolutions[:10]:  # Try first 10 to diagnose
                        try:
                            single_query = """
                            MATCH (caller:Function {qualifiedName: $caller_qn})-[r:CALLS]->(old_target {qualifiedName: $old_target_qn})
                            MATCH (new_target {qualifiedName: $new_target_qn})
                            DELETE r
                            MERGE (caller)-[r2:CALLS]->(new_target)
                            ON CREATE SET r2.line = $line, r2.call_name = $call_name, r2.is_self_call = $is_self_call, r2.resolved = true
                            RETURN count(r2) as created
                            """
                            single_result = self.db.execute_query(single_query, res)
                            if single_result and single_result[0]["created"] > 0:
                                calls_resolved += 1
                        except Exception as inner_e:
                            logger.debug(f"Individual resolution failed for {res['caller_qn']}: {inner_e}")
            logger.info(f"[TIMING] Batch resolution: {calls_resolved} resolved in {time_module.time() - batch_start:.1f}s")

            # Log resolution quality metrics
            if calls_resolved > 0:
                # Type inference is highest quality, then imports/same-file
                import_same_file_count = calls_resolved - fallback_count - type_inferred_count
                high_quality = type_inferred_count + import_same_file_count
                quality_pct = (high_quality / calls_resolved) * 100 if calls_resolved > 0 else 0
                random_fallback = fallback_count - community_guided_fallback
                logger.info(
                    f"Call resolution quality: {type_inferred_count} type-inferred, "
                    f"{import_same_file_count} via imports/same-file "
                    f"({quality_pct:.1f}% high-quality), "
                    f"{community_guided_fallback} community-guided, "
                    f"{random_fallback} random fallback"
                )

            # Step 5: Clean up orphaned external nodes (no incoming or outgoing relationships)
            # Note: Run separate queries for each label for FalkorDB compatibility
            total_deleted = 0
            for label in ["ExternalFunction", "ExternalClass"]:
                cleanup_query = f"""
                MATCH (n:{label})
                WHERE NOT (n)-[]-()
                DELETE n
                RETURN count(n) as deleted
                """
                try:
                    cleanup_result = self.db.execute_query(cleanup_query)
                    if cleanup_result and cleanup_result[0]["deleted"] > 0:
                        total_deleted += cleanup_result[0]["deleted"]
                except Exception as e:
                    logger.debug(f"Cleanup query for {label} failed (non-critical): {e}")
            if total_deleted > 0:
                logger.debug(f"Cleaned up {total_deleted} orphaned external nodes")

        except Exception as e:
            logger.warning(f"Failed to resolve internal calls: {e}")

        return calls_resolved

    def _validate_calls_with_graph(self) -> Dict[str, int]:
        """Validate resolved calls using graph-based community detection.

        Uses Rust-powered Leiden community detection and graph algorithms
        to score call resolutions by structural similarity.

        Returns:
            Dict with validation statistics:
            - high_confidence: Calls within same community
            - medium_confidence: Calls between adjacent communities
            - low_confidence: Calls between distant communities
        """
        stats = {"high_confidence": 0, "medium_confidence": 0, "low_confidence": 0}

        try:
            import repotoire_fast as rf
        except ImportError:
            logger.debug("repotoire_fast not available, skipping graph validation")
            return stats

        try:
            # Step 1: Get all internal Function nodes with indices
            # Note: All internal Function nodes have '::' in qualifiedName
            nodes_query = """
            MATCH (f:Function)
            WHERE f.qualifiedName IS NOT NULL
            RETURN f.qualifiedName as qn
            ORDER BY f.qualifiedName
            """
            nodes_result = self.db.execute_query(nodes_query)
            if not nodes_result:
                return stats

            # Build qualified name -> index mapping
            qn_to_idx: Dict[str, int] = {}
            for idx, row in enumerate(nodes_result):
                qn_to_idx[row["qn"]] = idx

            num_nodes = len(qn_to_idx)
            if num_nodes < 2:
                return stats

            # Step 2: Get all CALLS edges between internal Functions
            edges_query = """
            MATCH (caller:Function)-[:CALLS]->(callee:Function)
            WHERE caller.qualifiedName IS NOT NULL
              AND callee.qualifiedName IS NOT NULL
            RETURN caller.qualifiedName as caller_qn, callee.qualifiedName as callee_qn
            """
            edges_result = self.db.execute_query(edges_query)

            # Convert to (src_idx, dst_idx) tuples
            edges: List[tuple] = []
            calls: List[tuple] = []  # For validation
            for row in edges_result:
                src_idx = qn_to_idx.get(row["caller_qn"])
                dst_idx = qn_to_idx.get(row["callee_qn"])
                if src_idx is not None and dst_idx is not None:
                    edges.append((src_idx, dst_idx))
                    calls.append((src_idx, dst_idx))

            if not edges:
                return stats

            # Step 3: Run Leiden community detection
            logger.debug(f"Running Leiden community detection on {num_nodes} nodes, {len(edges)} edges")
            communities = rf.graph_leiden_parallel(edges, num_nodes, resolution=1.0, max_iterations=10, parallel=True)

            # Step 4: Validate calls by community membership
            confidences = rf.graph_validate_calls(calls, communities, edges, num_nodes)

            # Step 5: Count confidence levels
            for conf in confidences:
                if conf >= 0.9:
                    stats["high_confidence"] += 1
                elif conf >= 0.4:
                    stats["medium_confidence"] += 1
                else:
                    stats["low_confidence"] += 1

            # Log summary
            total = sum(stats.values())
            if total > 0:
                high_pct = 100 * stats["high_confidence"] / total
                med_pct = 100 * stats["medium_confidence"] / total
                low_pct = 100 * stats["low_confidence"] / total
                logger.info(
                    f"Graph-based call validation: {stats['high_confidence']} high ({high_pct:.1f}%), "
                    f"{stats['medium_confidence']} medium ({med_pct:.1f}%), "
                    f"{stats['low_confidence']} low ({low_pct:.1f}%)"
                )

                # Determine number of communities detected
                num_communities = len(set(communities))
                logger.debug(f"Detected {num_communities} code communities via Leiden algorithm")

        except Exception as e:
            logger.debug(f"Graph validation failed (non-critical): {e}")

        return stats

    def _build_path_cache(self) -> Optional["PyPathCache"]:
        """Build transitive closure cache for O(1) reachability queries (REPO-416).

        Precomputes reachability for CALLS, IMPORTS, and INHERITS relationships
        for 100-1000x speedup in detectors that need path queries.

        The cache is built once after ingestion and shared across all detectors.
        Memory usage is approximately O(V * avg_reachable) per relationship type.

        Returns:
            PyPathCache instance, or None if Rust extension not available
        """
        if not _HAS_PATH_CACHE:
            logger.debug("repotoire_fast path cache not available, skipping cache build")
            return None

        try:
            cache_start = time.time()
            cache = PyPathCache()

            # Step 1: Get all nodes with their IDs and qualified names
            nodes_query = """
            MATCH (n)
            WHERE n.qualifiedName IS NOT NULL
              AND (n:File OR n:Class OR n:Function OR n:Module)
            RETURN id(n) AS id, n.qualifiedName AS qn
            """
            nodes_result = self.db.execute_query(nodes_query)

            if not nodes_result:
                logger.debug("No nodes found for path cache")
                return cache

            # Register all nodes with the cache
            nodes = [(int(row["id"]), row["qn"]) for row in nodes_result]
            cache.register_nodes(nodes)

            # Build ID lookup for edge queries
            num_nodes = max(row["id"] for row in nodes_result) + 1

            # Step 2: Build cache for CALLS relationships
            calls_query = """
            MATCH (caller)-[:CALLS]->(callee)
            WHERE caller.qualifiedName IS NOT NULL AND callee.qualifiedName IS NOT NULL
            RETURN id(caller) AS src, id(callee) AS dst
            """
            calls_result = self.db.execute_query(calls_query)
            calls_edges = [(int(row["src"]), int(row["dst"])) for row in calls_result]

            if calls_edges:
                cache.build_cache("CALLS", calls_edges, num_nodes)
                stats = cache.stats("CALLS")
                if stats:
                    logger.debug(
                        f"Built CALLS cache: {stats.num_nodes} nodes, {stats.num_edges} edges, "
                        f"{stats.num_reachable_pairs} reachable pairs, {stats.memory_bytes / 1024:.1f} KB"
                    )

            # Step 3: Build cache for IMPORTS relationships
            imports_query = """
            MATCH (importer)-[:IMPORTS]->(imported)
            WHERE importer.qualifiedName IS NOT NULL AND imported.qualifiedName IS NOT NULL
            RETURN id(importer) AS src, id(imported) AS dst
            """
            imports_result = self.db.execute_query(imports_query)
            imports_edges = [(int(row["src"]), int(row["dst"])) for row in imports_result]

            if imports_edges:
                cache.build_cache("IMPORTS", imports_edges, num_nodes)
                stats = cache.stats("IMPORTS")
                if stats:
                    logger.debug(
                        f"Built IMPORTS cache: {stats.num_nodes} nodes, {stats.num_edges} edges, "
                        f"{stats.num_reachable_pairs} reachable pairs, {stats.memory_bytes / 1024:.1f} KB"
                    )

            # Step 4: Build cache for INHERITS relationships
            inherits_query = """
            MATCH (child)-[:INHERITS]->(parent)
            WHERE child.qualifiedName IS NOT NULL AND parent.qualifiedName IS NOT NULL
            RETURN id(child) AS src, id(parent) AS dst
            """
            inherits_result = self.db.execute_query(inherits_query)
            inherits_edges = [(int(row["src"]), int(row["dst"])) for row in inherits_result]

            if inherits_edges:
                cache.build_cache("INHERITS", inherits_edges, num_nodes)
                stats = cache.stats("INHERITS")
                if stats:
                    logger.debug(
                        f"Built INHERITS cache: {stats.num_nodes} nodes, {stats.num_edges} edges, "
                        f"{stats.num_reachable_pairs} reachable pairs, {stats.memory_bytes / 1024:.1f} KB"
                    )

            cache_duration = time.time() - cache_start
            total_edges = len(calls_edges) + len(imports_edges) + len(inherits_edges)
            logger.info(
                f"Built path expression cache in {cache_duration:.2f}s: "
                f"{len(nodes)} nodes, {total_edges} edges (CALLS+IMPORTS+INHERITS)"
            )

            return cache

        except Exception as e:
            logger.warning(f"Failed to build path cache (non-critical): {e}")
            return None

    def _report_skipped_files(self) -> None:
        """Report skipped files summary."""
        if not self.skipped_files:
            return

        logger.warning(f"\n{'='*60}")
        logger.warning(f"SKIPPED FILES SUMMARY: {len(self.skipped_files)} files were skipped")
        logger.warning(f"{'='*60}")

        # Group by reason
        reasons: Dict[str, List[str]] = defaultdict(list)
        for item in self.skipped_files:
            reason = item["reason"]
            reasons[reason].append(item["file"])

        for reason, files in reasons.items():
            logger.warning(f"\n{reason}: {len(files)} files")
            for file in files[:5]:  # Show first 5
                logger.warning(f"  - {file}")
            if len(files) > 5:
                logger.warning(f"  ... and {len(files) - 5} more")

        logger.warning(f"\n{'='*60}\n")

    def _detect_language(self, file_path: Path) -> str:
        """Detect programming language from file extension.

        Uses EXTENSION_TO_LANGUAGE from generic_fallback_parser for comprehensive
        language support. Dedicated parsers (Python, TypeScript, Java, Go) have
        priority over the fallback parser.

        Args:
            file_path: Path to file

        Returns:
            Language identifier
        """
        # Primary extension map for languages with dedicated parsers
        primary_map = {
            ".py": "python",
            ".js": "javascript",
            ".jsx": "javascript",
            ".ts": "typescript",
            ".tsx": "typescript",
            ".java": "java",
            ".go": "go",
        }

        suffix = file_path.suffix.lower()

        # Check primary parsers first
        if suffix in primary_map:
            return primary_map[suffix]

        # Fall back to EXTENSION_TO_LANGUAGE for all other extensions
        return EXTENSION_TO_LANGUAGE.get(suffix, "unknown")

    def _separate_rust_parseable_files(
        self, files: List[Path]
    ) -> Tuple[List[Path], List[Path]]:
        """Separate files into those parseable by Rust and fallback files.

        Args:
            files: List of file paths to process

        Returns:
            Tuple of (rust_parseable_files, fallback_files)
        """
        if not self.rust_parser:
            return [], files

        rust_files = []
        fallback_files = []

        for file_path in files:
            ext = file_path.suffix.lower()
            if self.rust_parser.supports_language(ext):
                rust_files.append(file_path)
            else:
                fallback_files.append(file_path)

        return rust_files, fallback_files

    def _batch_parse_with_rust(
        self, files: List[Path]
    ) -> Dict[str, Tuple[List[Entity], List[Relationship]]]:
        """Parse multiple files in parallel using Rust tree-sitter.

        Args:
            files: List of file paths to parse

        Returns:
            Dict mapping file_path -> (entities, relationships)
        """
        if not self.rust_parser:
            return {}

        # Read file contents (using cache if available)
        files_with_content = []
        for file_path in files:
            try:
                # Use cached content if available
                content, _, _ = self._get_file_content_and_hash(file_path)
                # Decode bytes to string for parser
                text = content.decode("utf-8", errors="replace")
                files_with_content.append((str(file_path), text))
            except (IOError, OSError) as e:
                logger.debug(f"Failed to read {file_path}: {e}")
                continue

        if not files_with_content:
            return {}

        # Parse all files in parallel
        return self.rust_parser.parse_batch(files_with_content)
