"""Core auto-fix engine for generating code fixes."""

import asyncio
import difflib
import hashlib
import os
import re
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from repotoire.ai.embeddings import CodeEmbedder
from repotoire.ai.llm import LLMBackend, LLMClient, LLMConfig
from repotoire.ai.retrieval import GraphRAGRetriever, RetrieverConfig
from repotoire.ai.vector_store import VectorStoreConfig
from repotoire.autofix.languages import LanguageHandler, get_handler
from repotoire.autofix.learning import AdaptiveConfidence, DecisionStore
from repotoire.autofix.models import (
    CodeChange,
    Evidence,
    FixConfidence,
    FixContext,
    FixProposal,
    FixType,
)
from repotoire.autofix.style import StyleAnalyzer, StyleEnforcer, StyleProfile
from repotoire.autofix.templates import (
    TemplateMatch,
    get_registry,
)
from repotoire.graph import FalkorDBClient
from repotoire.logging_config import get_logger
from repotoire.models import Finding, Severity
from repotoire.sandbox.code_validator import (
    CodeValidator,
    ValidationConfig,
    ValidationResult,
)

logger = get_logger(__name__)

# Cache for style profiles (keyed by repository path)
_style_profile_cache: Dict[str, StyleProfile] = {}
# REPO-500: Lock for thread-safe style profile cache access
_style_cache_lock = threading.Lock()

# Patterns that could be used for prompt injection attacks
_PROMPT_INJECTION_PATTERNS = [
    re.compile(r"ignore\s+(all\s+)?previous\s+instructions?", re.IGNORECASE),
    re.compile(r"disregard\s+(all\s+)?previous", re.IGNORECASE),
    re.compile(r"forget\s+(all\s+)?previous", re.IGNORECASE),
    re.compile(r"system\s*:\s*", re.IGNORECASE),
    re.compile(r"<\s*system\s*>", re.IGNORECASE),
    re.compile(r"assistant\s*:\s*", re.IGNORECASE),
    re.compile(r"human\s*:\s*", re.IGNORECASE),
    re.compile(r"output\s+(your\s+)?(api\s*key|secret|password|credential)", re.IGNORECASE),
    re.compile(r"reveal\s+(your\s+)?(api\s*key|secret|password|credential)", re.IGNORECASE),
]


def _normalize_code_for_matching(code: str) -> str:
    """Normalize code for fuzzy matching.

    Strips leading/trailing whitespace from each line, removes blank lines,
    and normalizes multiple spaces to single spaces. This helps match code
    even when there are minor whitespace differences.

    Args:
        code: Source code to normalize

    Returns:
        Normalized code string
    """
    lines = [line.strip() for line in code.strip().split("\n")]
    lines = [line for line in lines if line]  # Remove empty lines
    return "\n".join(lines)


def _fuzzy_code_match(original_code: str, file_content: str, threshold: float = 0.85) -> bool:
    """Check if original code approximately matches somewhere in file content.

    Uses both exact matching (with normalization) and fuzzy matching via
    difflib to handle minor whitespace and formatting differences.

    Args:
        original_code: The code snippet to find
        file_content: The full file content to search in
        threshold: Minimum similarity ratio for fuzzy match (0.0-1.0)

    Returns:
        True if a match is found, False otherwise
    """
    # First try exact match with normalization
    norm_original = _normalize_code_for_matching(original_code)
    norm_content = _normalize_code_for_matching(file_content)

    if norm_original in norm_content:
        return True

    # Try line-by-line fuzzy matching - find the best matching window
    original_lines = norm_original.split("\n")
    content_lines = norm_content.split("\n")
    window_size = len(original_lines)

    if window_size == 0:
        return False

    # Slide window across content
    best_ratio = 0.0
    for i in range(max(1, len(content_lines) - window_size + 1)):
        window = "\n".join(content_lines[i : i + window_size])
        ratio = difflib.SequenceMatcher(None, norm_original, window).ratio()
        best_ratio = max(best_ratio, ratio)
        if ratio >= threshold:
            return True

    logger.debug(f"Best fuzzy match ratio: {best_ratio:.2f} (threshold: {threshold})")
    return False


def _sanitize_code_for_prompt(code: str, language: str = "python") -> str:
    """Remove comments from code to prevent prompt injection attacks.

    Code comments are a primary vector for prompt injection because they
    appear as natural text that the LLM reads as instructions.

    Args:
        code: Source code that may contain malicious comments
        language: Programming language (for language-specific comment syntax)

    Returns:
        Code with comments removed or sanitized
    """
    if not code:
        return code

    lines = code.split("\n")
    sanitized_lines = []

    in_multiline_comment = False

    for line in lines:
        original_line = line

        if language.lower() == "python":
            # Handle Python multiline strings used as comments (docstrings at module level)
            # Keep docstrings that are part of function/class definitions
            if '"""' in line or "'''" in line:
                # Count quotes to track multiline
                triple_double = line.count('"""')
                triple_single = line.count("'''")

                if triple_double % 2 == 1 or triple_single % 2 == 1:
                    in_multiline_comment = not in_multiline_comment

            # Remove single-line comments (but preserve the code before #)
            if "#" in line and not in_multiline_comment:
                # Find the # that starts a comment (not inside a string)
                in_string = False
                string_char = None
                comment_start = -1

                for i, char in enumerate(line):
                    if char in ('"', "'") and (i == 0 or line[i - 1] != "\\"):
                        if not in_string:
                            in_string = True
                            string_char = char
                        elif char == string_char:
                            in_string = False
                            string_char = None
                    elif char == "#" and not in_string:
                        comment_start = i
                        break

                if comment_start >= 0:
                    # Check if comment contains injection patterns
                    comment_text = line[comment_start:]
                    has_injection = any(
                        pattern.search(comment_text)
                        for pattern in _PROMPT_INJECTION_PATTERNS
                    )

                    if has_injection:
                        # Remove the entire comment
                        line = line[:comment_start].rstrip()
                        logger.warning(
                            f"Removed potentially malicious comment: {comment_text[:50]}..."
                        )
                    else:
                        # Keep benign comments but truncate very long ones
                        if len(comment_text) > 200:
                            line = line[:comment_start] + "# [comment truncated]"

        # For other languages, apply basic sanitization
        else:
            # Check for injection patterns in the entire line
            for pattern in _PROMPT_INJECTION_PATTERNS:
                if pattern.search(line):
                    line = "// [potentially unsafe comment removed]"
                    logger.warning(
                        f"Sanitized line with injection pattern: {original_line[:50]}..."
                    )
                    break

        sanitized_lines.append(line)

    return "\n".join(sanitized_lines)


def _sanitize_finding_text(text: str) -> str:
    """Sanitize finding title/description to prevent prompt injection.

    Args:
        text: Finding title or description that may contain malicious content

    Returns:
        Sanitized text safe for inclusion in LLM prompts
    """
    if not text:
        return text

    # Check for injection patterns
    for pattern in _PROMPT_INJECTION_PATTERNS:
        if pattern.search(text):
            # Remove the matched pattern
            text = pattern.sub("[REDACTED]", text)
            logger.warning("Sanitized finding text containing injection pattern")

    # Truncate very long text that could be used for injection
    max_length = 1000
    if len(text) > max_length:
        text = text[:max_length] + "... [truncated]"

    return text


class AutoFixEngine:
    """Generate and validate automatic code fixes."""

    def __init__(
        self,
        graph_client: Optional[FalkorDBClient] = None,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        llm_backend: LLMBackend = "anthropic",
        decision_store: Optional[DecisionStore] = None,
        validation_config: Optional[ValidationConfig] = None,
        skip_runtime_validation: bool = False,
        # Legacy parameter for backwards compatibility
        openai_api_key: Optional[str] = None,
    ):
        """Initialize auto-fix engine.

        Args:
            graph_client: FalkorDB client for RAG context (optional for BYOK mode)
            api_key: API key for LLM backend (or use env var)
            model: Model to use for fix generation (uses backend default if not specified)
            llm_backend: LLM backend to use ("anthropic" or "openai")
            decision_store: Store for learning from user decisions
            validation_config: Configuration for runtime validation
            skip_runtime_validation: Skip sandbox-based validation (faster)
            openai_api_key: (Deprecated) Use api_key instead
        """
        self.graph_client = graph_client
        self.skip_runtime_validation = skip_runtime_validation

        # Handle legacy parameter
        effective_api_key = api_key or openai_api_key

        # Initialize LLM client with backend abstraction
        llm_config = LLMConfig(
            backend=llm_backend,
            model=model,
            temperature=0.2,  # Lower temperature for consistent code generation
        )
        self.llm_client = LLMClient(config=llm_config, api_key=effective_api_key)
        self.model = self.llm_client.model

        # Initialize RAG retriever for context gathering (only when graph_client provided)
        # BYOK mode works without graph context - file content is sufficient
        if graph_client:
            # Use same embedding backend as ingestion (local Qwen by default) for dimension compatibility
            embeddings_backend = os.getenv("REPOTOIRE_EMBEDDINGS_BACKEND", "local")
            embedder = CodeEmbedder(backend=embeddings_backend)

            # Configure vector store for retrieval (LanceDB for disk-backed vectors)
            # Embeddings are stored in LanceDB, not on FalkorDB graph nodes (saves RAM)
            vector_store_path = os.getenv("REPOTOIRE_VECTOR_STORE_PATH", "/data/vectors")
            vector_store_config = VectorStoreConfig(
                backend="lancedb",
                path=vector_store_path,
                table_name="code_embeddings",
            )
            retriever_config = RetrieverConfig(vector_store=vector_store_config)
            self.rag_retriever = GraphRAGRetriever(graph_client, embedder, config=retriever_config)
        else:
            self.rag_retriever = None

        # Initialize template registry for fast, deterministic fixes
        self.template_registry = get_registry()

        # Style enforcer (lazily initialized per repository)
        self._style_enforcer: Optional[StyleEnforcer] = None
        self._style_repo_path: Optional[Path] = None
        # REPO-500: Lock for thread-safe style enforcer lazy initialization
        self._style_enforcer_lock = threading.Lock()

        # Learning feedback system
        self.decision_store = decision_store or DecisionStore()
        self.adaptive_confidence = AdaptiveConfidence(self.decision_store)

        # Validation configuration (default: import check only)
        self.validation_config = validation_config or ValidationConfig(
            run_import_check=True,
            run_type_check=False,
            run_smoke_test=False,
        )

        # Code validator (lazily initialized)
        self._code_validator: Optional[CodeValidator] = None
        # REPO-500: Async lock with threading.Lock protection for validator initialization
        self._validator_sync_lock = threading.Lock()
        self._validator_async_lock: Optional[asyncio.Lock] = None

        logger.info(
            f"AutoFixEngine initialized with backend={llm_backend}, model={self.model}, "
            f"skip_runtime_validation={skip_runtime_validation}"
        )

    def get_style_profile(
        self, repository_path: Path, force_refresh: bool = False
    ) -> StyleProfile:
        """Get or analyze style profile for a repository.

        Results are cached per repository path.
        Thread-safe via double-checked locking pattern.

        Args:
            repository_path: Path to repository
            force_refresh: Force re-analysis even if cached

        Returns:
            StyleProfile for the repository
        """
        repo_key = str(repository_path.resolve())

        # First check without lock (fast path)
        if not force_refresh:
            with _style_cache_lock:
                if repo_key in _style_profile_cache:
                    logger.debug(f"Using cached style profile for {repository_path}")
                    return _style_profile_cache[repo_key]

        # Analyze outside lock (slow operation)
        logger.info(f"Analyzing style conventions for {repository_path}")
        analyzer = StyleAnalyzer(repository_path)
        profile = analyzer.analyze()

        # Store result under lock
        with _style_cache_lock:
            _style_profile_cache[repo_key] = profile

        return profile

    def _get_style_instructions(self, repository_path: Path) -> str:
        """Get style instructions for a repository.

        Thread-safe: Uses lock for style enforcer lazy initialization.

        Args:
            repository_path: Path to repository

        Returns:
            Markdown formatted style instructions
        """
        # Fast path: check without lock if enforcer already initialized for this repo
        if (
            self._style_enforcer is not None
            and self._style_repo_path == repository_path
        ):
            return self._style_enforcer.get_style_instructions()

        # Slow path: need to initialize or update enforcer
        with self._style_enforcer_lock:
            # Double-check after acquiring lock
            if (
                self._style_enforcer is None
                or self._style_repo_path != repository_path
            ):
                profile = self.get_style_profile(repository_path)
                self._style_enforcer = StyleEnforcer(profile)
                self._style_repo_path = repository_path

            return self._style_enforcer.get_style_instructions()

    async def generate_fix(
        self,
        finding: Finding,
        repository_path: Path,
        context_size: int = 5,
        skip_runtime_validation: Optional[bool] = None,
    ) -> Optional[FixProposal]:
        """Generate a fix proposal for a finding.

        Args:
            finding: The code smell or issue to fix
            repository_path: Path to the repository
            context_size: Number of related code snippets to gather
            skip_runtime_validation: Override instance setting for this call

        Returns:
            FixProposal if fix can be generated, None otherwise
        """
        skip_validation = (
            skip_runtime_validation
            if skip_runtime_validation is not None
            else self.skip_runtime_validation
        )

        try:
            # Step 0: Try template-based fix first (fast, deterministic)
            template_fix = await self._try_template_fix(finding, repository_path)
            if template_fix is not None:
                logger.info(f"Applied template fix: {template_fix.title}")
                return template_fix

            # Step 1: Gather context using RAG
            logger.info(f"Gathering context for finding: {finding.title}")
            context = await self._gather_context(finding, repository_path, context_size)

            # Step 2: Determine fix type from finding
            fix_type = self._determine_fix_type(finding)

            # Step 3: Generate fix using GPT-4 (with retry on validation failure)
            max_retries = 2
            last_errors: List[str] = []

            for attempt in range(max_retries + 1):
                if attempt == 0:
                    logger.info(f"Generating {fix_type.value} fix using {self.model}")
                else:
                    logger.info(f"Retry {attempt}/{max_retries}: Regenerating fix with error feedback")

                fix_proposal = await self._generate_fix_with_llm(
                    finding, context, fix_type, repository_path,
                    previous_errors=last_errors if attempt > 0 else None
                )

                # Step 4: Validate the fix (multi-level)
                logger.info("Validating generated fix")
                validation_result = await self._validate_fix_multilevel(
                    fix_proposal, repository_path, skip_validation
                )

                # Check if we should retry
                if validation_result.is_valid or attempt >= max_retries:
                    break

                # Collect errors for retry feedback
                last_errors = [
                    f"{err.error_type}: {err.message}"
                    for err in validation_result.errors
                ]
                logger.info(f"Validation failed with {len(last_errors)} errors, will retry")

            # Log validation errors for debugging
            if validation_result.errors:
                for err in validation_result.errors:
                    logger.warning(f"Validation error: {err.level} - {err.error_type}: {err.message}")

            # Populate validation fields
            fix_proposal.syntax_valid = validation_result.syntax_valid
            fix_proposal.import_valid = validation_result.import_valid
            fix_proposal.type_valid = validation_result.type_valid
            fix_proposal.validation_errors = [
                e.to_dict() for e in validation_result.errors
            ]
            fix_proposal.validation_warnings = [
                w.to_dict() for w in validation_result.warnings
            ]

            is_valid = validation_result.is_valid

            # Step 5: Apply adaptive confidence based on historical feedback
            original_confidence = fix_proposal.confidence
            adjusted_confidence = self.adaptive_confidence.adjust_confidence(
                base=original_confidence,
                fix_type=fix_type.value,
                repository=str(repository_path),
            )

            # Further reduce confidence if validation failed
            if not is_valid and adjusted_confidence != FixConfidence.LOW:
                logger.info(
                    "Reducing confidence to LOW due to validation errors"
                )
                adjusted_confidence = FixConfidence.LOW

            if adjusted_confidence != original_confidence:
                logger.info(
                    f"Adjusted confidence {original_confidence.value} → {adjusted_confidence.value} "
                    f"based on validation and historical feedback"
                )
                fix_proposal.confidence = adjusted_confidence

            # Step 6: Optionally generate tests
            if is_valid and fix_type in [FixType.REFACTOR, FixType.EXTRACT]:
                logger.info("Generating tests for fix")
                test_code = await self._generate_tests(fix_proposal, context)
                if test_code:
                    fix_proposal.test_code = test_code
                    fix_proposal.tests_generated = True

            logger.info(
                f"Fix generated: valid={is_valid}, confidence={fix_proposal.confidence.value}, "
                f"errors={len(fix_proposal.validation_errors)}, "
                f"warnings={len(fix_proposal.validation_warnings)}"
            )
            return fix_proposal

        except Exception as e:
            logger.error(f"Failed to generate fix for finding: {e}", exc_info=True)
            return None

    async def _gather_context(
        self,
        finding: Finding,
        repository_path: Path,
        context_size: int,
    ) -> FixContext:
        """Gather context for fix generation using RAG.

        Args:
            finding: The finding to fix
            repository_path: Path to repository
            context_size: Number of related snippets

        Returns:
            FixContext with related code
        """
        context = FixContext(finding=finding)

        try:
            # Use RAG to find related code (if graph client available)
            if finding.affected_files and self.rag_retriever:
                file_path = finding.affected_files[0]  # Use first affected file
                query = f"code related to {finding.title} in {file_path}"
                search_results = self.rag_retriever.retrieve(
                    query=query,
                    top_k=context_size,
                )

                # Extract code snippets from search results
                if search_results:
                    context.related_code = [
                        result.code
                        for result in search_results[:context_size]
                        if result.code
                    ]

            # Read the actual file content
            if finding.affected_files:
                file_path = repository_path / finding.affected_files[0]
                if file_path.exists():
                    with open(file_path, "r", encoding="utf-8") as f:
                        context.file_content = f.read()

            # Extract imports from file using language-specific handler
            if context.file_content and finding.affected_files:
                handler = get_handler(finding.affected_files[0])
                context.imports = handler.extract_imports(context.file_content)

        except Exception as e:
            logger.warning(f"Failed to gather full context: {e}")

        return context

    async def _try_template_fix(
        self,
        finding: Finding,
        repository_path: Path,
    ) -> Optional[FixProposal]:
        """Try to apply a template-based fix.

        Args:
            finding: The finding to fix
            repository_path: Path to repository

        Returns:
            FixProposal if a template matches, None otherwise
        """
        if not finding.affected_files:
            return None

        file_path = finding.affected_files[0]
        full_path = repository_path / file_path

        if not full_path.exists():
            return None

        try:
            # Read the file content
            with open(full_path, "r", encoding="utf-8") as f:
                content = f.read()

            # Determine language from file extension
            handler = get_handler(file_path)
            language = handler.language_name.lower()

            # Try to match a template
            match = self.template_registry.match(
                code=content,
                file_path=file_path,
                language=language,
            )

            if match is None:
                logger.debug(f"No template match for finding: {finding.title}")
                return None

            # Create fix proposal from template match
            return self._create_fix_from_template(
                finding=finding,
                match=match,
                file_path=file_path,
                repository_path=repository_path,
            )

        except Exception as e:
            logger.warning(f"Template fix attempt failed: {e}")
            return None

    def _create_fix_from_template(
        self,
        finding: Finding,
        match: TemplateMatch,
        file_path: str,
        repository_path: Path,
    ) -> FixProposal:
        """Create a FixProposal from a template match.

        Args:
            finding: The original finding
            match: The template match result
            file_path: Path to the affected file
            repository_path: Path to repository

        Returns:
            FixProposal with the template-based fix
        """
        template = match.template

        # Map template fix_type to FixType enum
        fix_type_map = {
            "refactor": FixType.REFACTOR,
            "simplify": FixType.SIMPLIFY,
            "extract": FixType.EXTRACT,
            "rename": FixType.RENAME,
            "remove": FixType.REMOVE,
            "security": FixType.SECURITY,
            "type_hint": FixType.TYPE_HINT,
            "documentation": FixType.DOCUMENTATION,
        }
        fix_type = fix_type_map.get(template.fix_type.lower(), FixType.REFACTOR)

        # Map confidence string to enum
        confidence_map = {
            "HIGH": FixConfidence.HIGH,
            "MEDIUM": FixConfidence.MEDIUM,
            "LOW": FixConfidence.LOW,
        }
        confidence = confidence_map.get(template.confidence, FixConfidence.MEDIUM)

        # Generate fix ID
        fix_id = hashlib.md5(
            f"{file_path}:{match.match_start}:{template.name}".encode()
        ).hexdigest()[:12]

        # Create code change
        change = CodeChange(
            file_path=Path(file_path),
            original_code=match.original_code,
            fixed_code=match.fixed_code,
            start_line=0,  # Will be calculated if needed
            end_line=0,
            description=template.description or f"Apply {template.name}",
        )

        # Create evidence from template
        evidence = Evidence(
            documentation_refs=template.evidence.documentation_refs,
            best_practices=template.evidence.best_practices,
            similar_patterns=[f"Template: {template.name}"],
        )

        # Create the fix proposal
        fix_proposal = FixProposal(
            id=fix_id,
            finding=finding,
            fix_type=fix_type,
            confidence=confidence,
            changes=[change],
            title=f"Template fix: {template.name}",
            description=template.description or f"Applied template '{template.name}'",
            rationale="; ".join(template.evidence.best_practices)
            if template.evidence.best_practices
            else "Template-based fix",
            evidence=evidence,
            branch_name=f"autofix/template/{fix_id}",
            commit_message=f"fix: {template.name}\n\n{template.description or 'Template-based fix'}",
            syntax_valid=True,  # Templates produce deterministic, valid code
        )

        return fix_proposal

    def _determine_fix_type(self, finding: Finding) -> FixType:
        """Determine the type of fix needed based on finding.

        Args:
            finding: The finding to analyze

        Returns:
            Appropriate FixType
        """
        title_lower = finding.title.lower()
        description_lower = finding.description.lower() if finding.description else ""

        # Security issues
        if finding.severity == Severity.CRITICAL or "security" in title_lower:
            return FixType.SECURITY

        # Complexity issues
        if "complex" in title_lower or "cyclomatic" in description_lower:
            return FixType.SIMPLIFY

        # Dead code
        if "unused" in title_lower or "dead code" in title_lower:
            return FixType.REMOVE

        # Documentation
        if "docstring" in title_lower or "documentation" in title_lower:
            return FixType.DOCUMENTATION

        # Type hints
        if "type" in title_lower and "hint" in description_lower:
            return FixType.TYPE_HINT

        # Long methods/functions
        if "long" in title_lower or "too many" in title_lower:
            return FixType.EXTRACT

        # Default to refactor
        return FixType.REFACTOR

    async def _generate_fix_with_llm(
        self,
        finding: Finding,
        context: FixContext,
        fix_type: FixType,
        repository_path: Path,
        previous_errors: Optional[List[str]] = None,
    ) -> FixProposal:
        """Generate fix using LLM.

        Args:
            finding: The finding to fix
            context: Context for fix generation
            fix_type: Type of fix to generate
            repository_path: Path to repository (for style instructions)
            previous_errors: Errors from previous attempt (for retry feedback)

        Returns:
            FixProposal with generated changes
        """
        # Get language-specific handler
        file_path = finding.affected_files[0] if finding.affected_files else "unknown.py"
        handler = get_handler(file_path)

        # Build prompt with language-specific guidance and style instructions
        prompt = self._build_fix_prompt(
            finding, context, fix_type, handler, repository_path
        )

        # Add error feedback for retries
        if previous_errors:
            error_feedback = "\n".join(f"- {err}" for err in previous_errors)
            prompt += f"""

## PREVIOUS ATTEMPT FAILED
Your previous fix attempt had these validation errors:
{error_feedback}

Please fix these issues:
- If "SyntaxError: expected an indented block": You only provided the function signature. Include the COMPLETE function body.
- If "MatchError: Original code not found": Copy the `original_code` exactly from the Current Code section above, preserving whitespace.

Generate a corrected fix that passes validation."""

        # Call LLM with language-specific system prompt
        response_text = self.llm_client.generate(
            messages=[{"role": "user", "content": prompt}],
            system=handler.get_system_prompt(),
        )

        # Parse response
        fix_data = self._parse_llm_response(response_text)

        # Add RAG context to evidence
        evidence = fix_data.get("evidence", Evidence())
        if isinstance(evidence, dict):
            evidence = Evidence(**evidence)

        # Add RAG context snippets as additional evidence
        evidence.rag_context = context.related_code[:3]

        # Create fix proposal
        file_path = finding.affected_files[0] if finding.affected_files else "unknown"
        line_num = finding.line_start or 0
        fix_id = hashlib.md5(
            f"{file_path}:{line_num}:{datetime.utcnow().isoformat()}".encode()
        ).hexdigest()[:12]

        fix_proposal = FixProposal(
            id=fix_id,
            finding=finding,
            fix_type=fix_type,
            confidence=self._calculate_confidence(fix_data, context),
            changes=fix_data["changes"],
            title=fix_data.get("title", f"Fix: {finding.title}"),
            description=fix_data.get("description", ""),
            rationale=fix_data.get("rationale", ""),
            evidence=evidence,
            branch_name=f"autofix/{fix_type.value}/{fix_id}",
            commit_message=f"fix: {fix_data.get('title', finding.title)}\n\n{fix_data.get('description', '')}",
        )

        return fix_proposal

    def _build_fix_prompt(
        self,
        finding: Finding,
        context: FixContext,
        fix_type: FixType,
        handler: LanguageHandler,
        repository_path: Path,
    ) -> str:
        """Build prompt for LLM fix generation.

        Security: Sanitizes all user-controlled content to prevent prompt injection.
        Code comments and finding text are sanitized before inclusion in the prompt.

        Args:
            finding: The finding to fix
            context: Context for fix
            fix_type: Type of fix
            handler: Language-specific handler
            repository_path: Path to repository (for style instructions)

        Returns:
            Formatted prompt string
        """
        # Extract relevant code section
        code_section = ""
        if context.file_content and finding.line_start:
            lines = context.file_content.split("\n")
            start = max(0, finding.line_start - 10)
            end = min(len(lines), finding.line_start + 20)
            code_section = "\n".join(lines[start:end])

        file_path = finding.affected_files[0] if finding.affected_files else "unknown"
        language_name = handler.language_name
        code_marker = handler.get_code_block_marker()
        fix_guidance = handler.get_fix_template(fix_type.value)

        # SECURITY: Sanitize code to remove potentially malicious comments
        code_section = _sanitize_code_for_prompt(code_section, language_name)

        # SECURITY: Sanitize related code context
        sanitized_related_code = [
            _sanitize_code_for_prompt(code, language_name)
            for code in context.related_code[:3]
        ]

        # SECURITY: Sanitize finding title and description
        sanitized_title = _sanitize_finding_text(finding.title)
        sanitized_description = _sanitize_finding_text(finding.description or "No description")

        # Get style instructions for the repository (only for Python)
        style_section = ""
        if language_name == "Python":
            try:
                style_instructions = self._get_style_instructions(repository_path)
                style_section = f"\n{style_instructions}\n"
            except Exception as e:
                logger.debug(f"Could not get style instructions: {e}")

        # Get historical feedback adjustments
        historical_section = ""
        try:
            prompt_adjustments = self.adaptive_confidence.get_prompt_adjustments(
                repository=str(repository_path)
            )
            if prompt_adjustments:
                historical_section = f"\n{prompt_adjustments}\n"
        except Exception as e:
            logger.debug(f"Could not get prompt adjustments: {e}")

        prompt = f"""# Code Fix Task

## Issue Details
- **Title**: {sanitized_title}
- **Severity**: {finding.severity.value}
- **Description**: {sanitized_description}
- **File**: {file_path}
- **Language**: {language_name}
- **Line**: {finding.line_start or 'unknown'}

## Fix Type Required
{fix_type.value}

## Fix Guidelines
{fix_guidance}
{style_section}{historical_section}

## Current Code
```{code_marker}
{code_section}
```

## Related Code Context
{chr(10).join(f"```{code_marker}{chr(10)}{code}{chr(10)}```" for code in sanitized_related_code)}

## Task
Generate a fix for this issue. Provide your response in the following JSON format:

{{
    "title": "Short fix title (max 100 chars)",
    "description": "Detailed explanation of the fix",
    "rationale": "Why this fix addresses the issue",
    "evidence": {{
        "similar_patterns": ["Example 1 from codebase showing this pattern works", "Example 2..."],
        "documentation_refs": ["Relevant style guide or documentation reference", "..."],
        "best_practices": ["Why this approach is recommended", "Industry standard for..."]
    }},
    "changes": [
        {{
            "file_path": "{file_path}",
            "original_code": "exact original code to replace (copy from Current Code above)",
            "fixed_code": "new code (must be complete and syntactically valid)",
            "start_line": line_number,
            "end_line": line_number,
            "description": "what this change does"
        }}
    ]
}}

**CRITICAL REQUIREMENTS**:
1. `original_code` MUST be copied exactly from the "Current Code" section above - match whitespace and indentation
2. `fixed_code` MUST be syntactically valid {language_name} that can be parsed without errors
3. For function fixes, include the ENTIRE function definition with its body:
   - WRONG: `def foo() -> int:` (incomplete - missing body)
   - CORRECT: `def foo() -> int:\\n    return 42` (complete with body)
4. Both `original_code` and `fixed_code` must have matching indentation levels
5. Only fix the specific issue - preserve all existing functionality
6. Keep changes minimal and focused"""

        return prompt

    def _parse_llm_response(self, response_text: str) -> Dict[str, Any]:
        """Parse LLM response into structured data.

        Args:
            response_text: Raw LLM response

        Returns:
            Parsed fix data
        """
        import json
        import re

        # Extract JSON from response (may be wrapped in markdown)
        json_match = re.search(
            r"```json\s*(\{.*?\})\s*```", response_text, re.DOTALL
        )
        if json_match:
            response_text = json_match.group(1)

        try:
            data = json.loads(response_text)
        except json.JSONDecodeError:
            # Fallback: extract what we can
            logger.warning("Failed to parse JSON response, using fallback")
            data = {
                "title": "Auto-generated fix",
                "description": response_text[:500],
                "rationale": "Fix suggested by AI",
                "evidence": {},
                "changes": [],
            }

        # Convert changes to CodeChange objects
        changes = []
        for change in data.get("changes", []):
            changes.append(
                CodeChange(
                    file_path=Path(change["file_path"]),
                    original_code=change["original_code"],
                    fixed_code=change["fixed_code"],
                    start_line=change.get("start_line", 0),
                    end_line=change.get("end_line", 0),
                    description=change.get("description", ""),
                )
            )

        data["changes"] = changes

        # Parse evidence
        evidence_data = data.get("evidence", {})
        data["evidence"] = Evidence(
            similar_patterns=evidence_data.get("similar_patterns", []),
            documentation_refs=evidence_data.get("documentation_refs", []),
            best_practices=evidence_data.get("best_practices", []),
        )

        return data

    def _calculate_confidence(
        self, fix_data: Dict[str, Any], context: FixContext
    ) -> FixConfidence:
        """Calculate confidence level for generated fix.

        Args:
            fix_data: Parsed fix data
            context: Fix context

        Returns:
            FixConfidence level
        """
        score = 0.5  # Start at 50%

        # Boost confidence if we have good context
        if len(context.related_code) >= 3:
            score += 0.15

        # Boost if we have file content
        if context.file_content:
            score += 0.1

        # Boost if changes are small (less risky)
        if len(fix_data.get("changes", [])) == 1:
            score += 0.1

        # Boost if rationale is detailed
        if len(fix_data.get("rationale", "")) > 100:
            score += 0.1

        # Reduce if finding is critical (needs careful review)
        if context.finding.severity == Severity.CRITICAL:
            score -= 0.2

        # Classify
        if score >= 0.9:
            return FixConfidence.HIGH
        elif score >= 0.7:
            return FixConfidence.MEDIUM
        else:
            return FixConfidence.LOW

    def _validate_fix(
        self, fix_proposal: FixProposal, repository_path: Path
    ) -> bool:
        """Validate that generated fix is syntactically correct.

        DEPRECATED: Use _validate_fix_multilevel for multi-level validation.

        Args:
            fix_proposal: The fix to validate
            repository_path: Path to repository

        Returns:
            True if fix is valid, False otherwise
        """
        try:
            for change in fix_proposal.changes:
                # Get language-specific handler for syntax validation
                handler = get_handler(str(change.file_path))

                # Check syntax of fixed code
                if not handler.validate_syntax(change.fixed_code):
                    logger.warning(
                        f"Syntax error in fix for {change.file_path}"
                    )
                    return False

                # Verify original code exists in file
                file_path = repository_path / change.file_path
                if file_path.exists():
                    with open(file_path, "r", encoding="utf-8") as f:
                        content = f.read()

                    if change.original_code.strip() not in content:
                        logger.warning(
                            f"Original code not found in {change.file_path}"
                        )
                        return False

            return True

        except Exception as e:
            logger.error(f"Validation error: {e}")
            return False

    async def _validate_fix_multilevel(
        self,
        fix_proposal: FixProposal,
        repository_path: Path,
        skip_runtime: bool = False,
    ) -> ValidationResult:
        """Validate fix using multi-level validation.

        Validation levels:
        - Level 1 (Syntax): Local ast.parse() - always run
        - Level 2 (Import): Sandbox import test - unless skip_runtime=True
        - Level 3 (Type): Mypy in sandbox - if validation_config.run_type_check
        - Level 4 (Smoke): Function calls - if validation_config.run_smoke_test

        Args:
            fix_proposal: The fix to validate
            repository_path: Path to repository
            skip_runtime: Skip sandbox-based validation levels

        Returns:
            ValidationResult with details about all validation levels
        """
        from repotoire.sandbox.code_validator import (
            ValidationError as ValError,
        )
        from repotoire.sandbox.code_validator import (
            ValidationLevel,
            validate_syntax_only,
        )

        # If no changes, return valid
        if not fix_proposal.changes:
            return ValidationResult(
                is_valid=True,
                syntax_valid=True,
            )

        # For skip_runtime mode, just do syntax validation locally
        if skip_runtime:
            all_valid = True
            all_errors: List[ValError] = []

            for change in fix_proposal.changes:
                result = validate_syntax_only(change.fixed_code)
                if not result.syntax_valid:
                    all_valid = False
                    all_errors.extend(result.errors)

                # Also verify original code exists (using fuzzy matching)
                file_path = repository_path / change.file_path
                if file_path.exists():
                    with open(file_path, "r", encoding="utf-8") as f:
                        content = f.read()

                    if not _fuzzy_code_match(change.original_code, content):
                        all_errors.append(
                            ValError(
                                level=ValidationLevel.SYNTAX.value,
                                error_type="MatchError",
                                message=f"Original code not found in {change.file_path}",
                                suggestion="The file may have been modified since analysis",
                            )
                        )
                        all_valid = False

            return ValidationResult(
                is_valid=all_valid,
                syntax_valid=all_valid,
                errors=all_errors,
            )

        # Full validation with sandbox
        try:
            # Get or create validator (REPO-500: async + sync lock pattern)
            if self._code_validator is None:
                # Ensure async lock exists (protected by sync lock)
                with self._validator_sync_lock:
                    if self._validator_async_lock is None:
                        self._validator_async_lock = asyncio.Lock()

                # Acquire async lock for actual initialization
                async with self._validator_async_lock:
                    # Double-check after acquiring async lock
                    if self._code_validator is None:
                        self._code_validator = CodeValidator(self.validation_config)
                        await self._code_validator.__aenter__()

            # Validate each change
            combined_result = ValidationResult(
                is_valid=True,
                syntax_valid=True,
            )

            for change in fix_proposal.changes:
                # Collect related project files for import context
                project_files = self._get_related_files(
                    change.file_path, repository_path
                )

                result = await self._code_validator.validate(
                    fixed_code=change.fixed_code,
                    file_path=str(change.file_path),
                    original_code=change.original_code,
                    project_files=project_files,
                    project_root=repository_path,
                )

                # Merge results
                combined_result.is_valid = combined_result.is_valid and result.is_valid
                combined_result.syntax_valid = (
                    combined_result.syntax_valid and result.syntax_valid
                )

                if result.import_valid is not None:
                    if combined_result.import_valid is None:
                        combined_result.import_valid = result.import_valid
                    else:
                        combined_result.import_valid = (
                            combined_result.import_valid and result.import_valid
                        )

                if result.type_valid is not None:
                    if combined_result.type_valid is None:
                        combined_result.type_valid = result.type_valid
                    else:
                        combined_result.type_valid = (
                            combined_result.type_valid and result.type_valid
                        )

                combined_result.errors.extend(result.errors)
                combined_result.warnings.extend(result.warnings)
                combined_result.duration_ms += result.duration_ms

                # Also verify original code exists in file
                file_path = repository_path / change.file_path
                if file_path.exists():
                    with open(file_path, "r", encoding="utf-8") as f:
                        content = f.read()

                    if change.original_code.strip() not in content:
                        combined_result.errors.append(
                            ValError(
                                level=ValidationLevel.SYNTAX.value,
                                error_type="MatchError",
                                message=f"Original code not found in {change.file_path}",
                                suggestion="The file may have been modified since analysis",
                            )
                        )
                        combined_result.is_valid = False

            return combined_result

        except Exception as e:
            logger.warning(f"Multi-level validation failed, falling back: {e}")
            # Fall back to syntax-only validation
            return await self._validate_fix_multilevel(
                fix_proposal, repository_path, skip_runtime=True
            )

    def _get_related_files(
        self, file_path: Path, repository_path: Path
    ) -> List[Path]:
        """Get files that the target file depends on.

        Args:
            file_path: Path to the target file
            repository_path: Root of the repository

        Returns:
            List of paths to related files (up to 10)
        """
        related: List[Path] = []

        # Read the file and extract imports
        full_path = repository_path / file_path
        if not full_path.exists():
            return related

        try:
            with open(full_path, "r", encoding="utf-8") as f:
                content = f.read()

            handler = get_handler(str(file_path))
            imports = handler.extract_imports(content)

            # Try to find local imports in the repository
            for imp in imports[:10]:  # Limit to 10 imports
                # Parse import statement to get module path
                # e.g., "from src.utils import helper" -> "src/utils.py"
                if imp.startswith("from "):
                    parts = imp.split()
                    if len(parts) >= 2:
                        module = parts[1].replace(".", "/") + ".py"
                        candidate = repository_path / module
                        if candidate.exists() and candidate not in related:
                            related.append(candidate)
                elif imp.startswith("import "):
                    parts = imp.split()
                    if len(parts) >= 2:
                        module = parts[1].replace(".", "/") + ".py"
                        candidate = repository_path / module
                        if candidate.exists() and candidate not in related:
                            related.append(candidate)

        except Exception as e:
            logger.debug(f"Error finding related files: {e}")

        return related[:10]  # Limit total files

    async def _generate_tests(
        self,
        fix_proposal: FixProposal,
        context: FixContext,
    ) -> Optional[str]:
        """Generate tests for the fix.

        Args:
            fix_proposal: The fix to test
            context: Fix context

        Returns:
            Test code string if successful, None otherwise
        """
        try:
            # Build test generation prompt
            prompt = f"""Generate pytest test cases for this code fix:

## Fix Description
{fix_proposal.description}

## Changes
{chr(10).join(f"File: {c.file_path}{chr(10)}Fixed Code:{chr(10)}{c.fixed_code}" for c in fix_proposal.changes)}

## Requirements
- Use pytest framework
- Test both original behavior and fixed behavior
- Include edge cases
- Use clear test names

Provide only the test code, no explanations."""

            test_code = self.llm_client.generate(
                messages=[{"role": "user", "content": prompt}],
                system="You are an expert at writing comprehensive pytest test cases.",
                temperature=0.3,
            )

            # Extract code from markdown if needed
            import re

            code_match = re.search(r"```python\s*(.*?)\s*```", test_code, re.DOTALL)
            if code_match:
                test_code = code_match.group(1)

            # Validate test syntax using Python handler (tests are always Python)
            handler = get_handler("test.py")
            if handler.validate_syntax(test_code):
                return test_code
            else:
                logger.warning("Generated test code has syntax errors")
                return None

        except Exception as e:
            logger.error(f"Failed to generate tests: {e}")
            return None
