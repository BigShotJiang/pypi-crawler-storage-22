"""Circular dependency detector using graph algorithms (REPO-170, REPO-200).

Uses Rust-based Strongly Connected Components (Tarjan's SCC) for O(V+E) cycle
detection - 10-100x faster than pairwise path queries. No GDS plugin required.

REPO-200: Updated to use Rust algorithms directly (no GDS dependency).
REPO-416: Added path cache support for O(1) cycle detection in fallback path.
"""

import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Dict, List, Optional, Set

from repotoire.detectors.base import CodeSmellDetector
from repotoire.detectors.graph_algorithms import GraphAlgorithms
from repotoire.graph.enricher import GraphEnricher
from repotoire.logging_config import get_logger
from repotoire.models import CollaborationMetadata, Finding, Severity

# Check if path cache is available (REPO-416)
try:
    from repotoire_fast import PyPathCache
    _HAS_PATH_CACHE = True
except ImportError:
    _HAS_PATH_CACHE = False

if TYPE_CHECKING:
    from repotoire_fast import PyPathCache

logger = get_logger(__name__)


class CircularDependencyDetector(CodeSmellDetector):
    """Detects circular dependencies in import graph using Tarjan's algorithm.

    Uses GDS SCC (Strongly Connected Components) algorithm when available,
    which is O(V+E) - much faster than pairwise path queries O(V²).
    """

    def __init__(
        self,
        graph_client,
        detector_config: Optional[dict] = None,
        enricher: Optional[GraphEnricher] = None
    ):
        """Initialize circular dependency detector.

        Args:
            graph_client: FalkorDB database client
            detector_config: Optional detector configuration. May include:
                - repo_id: Repository UUID for filtering queries (multi-tenant isolation)
                - path_cache: Prebuilt path cache for O(1) cycle detection (REPO-416)
            enricher: Optional GraphEnricher for cross-detector collaboration
        """
        super().__init__(graph_client, detector_config)
        self.enricher = enricher
        # FalkorDB uses id() while Neo4j uses elementId()
        self.is_falkordb = getattr(graph_client, "is_falkordb", False) or type(graph_client).__name__ == "FalkorDBClient"
        self.id_func = "id" if self.is_falkordb else "elementId"
        # Path cache for O(1) cycle detection (REPO-416)
        self.path_cache: Optional["PyPathCache"] = (detector_config or {}).get("path_cache")

    def detect(self) -> List[Finding]:
        """Find circular dependencies in the codebase.

        Uses Rust SCC algorithm (Tarjan's) for O(V+E) cycle detection.
        No GDS plugin required - runs entirely with Rust algorithms.

        Returns:
            List of findings, one per circular dependency cycle
        """
        # Fast path: use QueryCache if available
        if self.query_cache is not None:
            logger.debug("Using QueryCache for circular dependency detection")
            return self._detect_cached()

        # Pass repo_id for multi-tenant filtering
        graph_algo = GraphAlgorithms(self.db, repo_id=self.repo_id)

        # Use Rust-based SCC detection (no GDS required)
        logger.info("Using Rust SCC algorithm for circular dependency detection")
        findings = self._detect_with_scc(graph_algo)
        if findings is not None:
            return findings

        # Fall back to traditional path-based detection only if Rust fails
        logger.warning("Rust SCC detection failed, falling back to path queries")
        return self._detect_with_path_queries()

    def _detect_cached(self) -> List[Finding]:
        """Detect circular dependencies using QueryCache.

        Uses import relationships from QueryCache to detect cycles.
        Falls back to graph queries if import data not available.

        Returns:
            List of findings for circular dependency cycles
        """
        findings: List[Finding] = []
        
        # Check if QueryCache has import data
        if not hasattr(self.query_cache, 'get_imports') and not hasattr(self.query_cache, 'imports'):
            logger.debug("QueryCache does not have import data, falling back to graph detection")
            # Fall back to standard detection without the fast path check
            graph_algo = GraphAlgorithms(self.db, repo_id=self.repo_id)
            result = self._detect_with_scc(graph_algo)
            if result is not None:
                return result
            return self._detect_with_path_queries()
        
        # Build import graph from cache
        # imports: dict of file_path -> list of imported file paths
        imports_map: Dict[str, List[str]] = {}
        
        if hasattr(self.query_cache, 'imports'):
            imports_map = self.query_cache.imports
        elif hasattr(self.query_cache, 'get_imports'):
            # Build from files in cache
            for file_path in getattr(self.query_cache, 'files', {}):
                imported = self.query_cache.get_imports(file_path)
                if imported:
                    imports_map[file_path] = imported
        
        if not imports_map:
            logger.debug("No import data in cache, falling back to graph detection")
            graph_algo = GraphAlgorithms(self.db, repo_id=self.repo_id)
            result = self._detect_with_scc(graph_algo)
            if result is not None:
                return result
            return self._detect_with_path_queries()
        
        # Find cycles using DFS with Tarjan's algorithm (simplified)
        # Track visited and recursion stack for cycle detection
        all_files = set(imports_map.keys())
        for imported_list in imports_map.values():
            all_files.update(imported_list)
        
        visited: Set[str] = set()
        rec_stack: Set[str] = set()
        seen_cycles: Set[tuple] = set()
        
        def find_cycles(node: str, path: List[str]) -> None:
            """DFS to find cycles starting from node."""
            if node in rec_stack:
                # Found a cycle - extract it
                cycle_start = path.index(node)
                cycle = path[cycle_start:]
                
                # Normalize and deduplicate
                normalized = self._normalize_cycle(cycle)
                if normalized not in seen_cycles and len(normalized) >= 2:
                    seen_cycles.add(normalized)
                return
            
            if node in visited:
                return
            
            visited.add(node)
            rec_stack.add(node)
            path.append(node)
            
            for imported in imports_map.get(node, []):
                find_cycles(imported, path.copy())
            
            rec_stack.remove(node)
        
        # Run DFS from each file
        for file_path in all_files:
            if file_path not in visited:
                find_cycles(file_path, [])
        
        # Create findings for detected cycles
        for cycle in seen_cycles:
            cycle_list = list(cycle)
            finding = self._create_finding(
                cycle_files=cycle_list,
                cycle_length=len(cycle_list),
                detection_method="query_cache"
            )
            findings.append(finding)
        
        logger.info(f"CircularDependencyDetector (cached) found {len(findings)} circular dependencies")
        return findings

    def _detect_with_scc(self, graph_algo: GraphAlgorithms) -> Optional[List[Finding]]:
        """Detect circular dependencies using Rust SCC algorithm.

        SCC (Strongly Connected Components) finds all cycles in O(V+E) time.
        Components with size > 1 represent circular dependencies.

        Uses Rust Tarjan's algorithm - no GDS projection required.

        Args:
            graph_algo: GraphAlgorithms instance

        Returns:
            List of findings, or None if SCC detection failed
        """
        findings: List[Finding] = []

        try:
            # Calculate SCC using Rust algorithm (no projection needed)
            result = graph_algo.calculate_scc()
            if not result:
                logger.warning("Failed to calculate SCC")
                return None

            component_count = result.get("componentCount", 0)
            logger.info(f"SCC found {component_count} components")

            # Get cycles (components with size > 1)
            cycles = graph_algo.get_scc_cycles(min_cycle_size=2)

            for cycle_data in cycles:
                cycle_size = cycle_data.get("cycle_size", 0)
                file_paths = cycle_data.get("file_paths", [])
                file_names = cycle_data.get("file_names", [])
                edges = cycle_data.get("edges", [])
                component_id = cycle_data.get("component_id")

                if not file_paths or cycle_size < 2:
                    continue

                finding = self._create_finding(
                    cycle_files=file_paths,
                    cycle_length=cycle_size,
                    cycle_names=file_names,
                    edges=edges,
                    detection_method="SCC"
                )
                findings.append(finding)

            logger.info(f"SCC detection found {len(findings)} circular dependencies")
            return findings

        except Exception as e:
            logger.error(f"Error in SCC detection: {e}", exc_info=True)
            return None

    def _detect_with_path_queries(self) -> List[Finding]:
        """Detect circular dependencies using traditional path queries.

        This is the fallback method when GDS is not available.
        Uses path cache for O(1) cycle detection (REPO-416) when available,
        otherwise falls back to bounded shortestPath queries.

        Returns:
            List of findings
        """
        findings: List[Finding] = []

        # REPO-416: Try path cache first (100-1000x faster)
        if self.path_cache is not None and _HAS_PATH_CACHE:
            try:
                # PyPathCache.find_cycles(rel_type) returns list of cycles (as node ID lists)
                cached_cycles = self.path_cache.find_cycles("IMPORTS")
                seen_cycles: Set[tuple] = set()

                for cycle_ids in cached_cycles:
                    if len(cycle_ids) < 2:
                        continue

                    # Convert node IDs to qualified names
                    cycle_names = [self.path_cache.get_name(node_id) for node_id in cycle_ids]
                    cycle_names = [n for n in cycle_names if n is not None]

                    if not cycle_names:
                        continue

                    # Normalize to canonical form
                    normalized = self._normalize_cycle(cycle_names)
                    if normalized in seen_cycles:
                        continue
                    seen_cycles.add(normalized)

                    finding = self._create_finding(
                        cycle_files=cycle_names,
                        cycle_length=len(cycle_names),
                        detection_method="path_cache"
                    )
                    findings.append(finding)

                logger.info(f"Path cache found {len(findings)} circular dependencies")
                return findings

            except Exception as e:
                logger.warning(f"Path cache cycle detection failed: {e}, using Cypher fallback")

        # Fallback: Original optimized query using bounded path traversal
        # REPO-600: Filter by tenant_id AND repo_id for defense-in-depth isolation
        repo_filter = self._get_isolation_filter("f1")
        query = f"""
        MATCH (f1:File)
        WHERE true {repo_filter}
        MATCH (f2:File)
        WHERE {self.id_func}(f1) < {self.id_func}(f2) AND f1 <> f2
        MATCH path = shortestPath((f1)-[:IMPORTS*1..15]->(f2))
        MATCH cyclePath = shortestPath((f2)-[:IMPORTS*1..15]->(f1))
        WITH DISTINCT [node IN nodes(path) + nodes(cyclePath) WHERE 'File' IN labels(node) | node.filePath] AS cycle
        WHERE size(cycle) > 1
        RETURN cycle, size(cycle) AS cycle_length
        ORDER BY cycle_length DESC
        """

        results = self.db.execute_query(query, self._get_query_params())

        # Deduplicate cycles
        seen_cycles: Set[tuple] = set()

        for record in results:
            cycle = record["cycle"]
            cycle_length = record["cycle_length"]

            # Normalize to canonical form
            normalized = self._normalize_cycle(cycle)
            if normalized in seen_cycles:
                continue
            seen_cycles.add(normalized)

            finding = self._create_finding(
                cycle_files=cycle,
                cycle_length=cycle_length,
                detection_method="path_query"
            )
            findings.append(finding)

        return findings

    def _create_finding(
        self,
        cycle_files: List[str],
        cycle_length: int,
        cycle_names: Optional[List[str]] = None,
        edges: Optional[List[dict]] = None,
        detection_method: str = "unknown"
    ) -> Finding:
        """Create a finding for a circular dependency.

        Args:
            cycle_files: List of file paths in the cycle
            cycle_length: Number of files in the cycle
            cycle_names: Optional list of qualified names
            edges: Optional list of edge relationships
            detection_method: How the cycle was detected

        Returns:
            Finding object
        """
        finding_id = str(uuid.uuid4())

        # Format cycle for description
        display_files = [f.split("/")[-1] for f in cycle_files[:5]]
        cycle_display = " -> ".join(display_files)
        if cycle_length > 5:
            cycle_display += f" ... ({cycle_length} files total)"

        severity = self._calculate_severity(cycle_length)

        # Build edge description if available
        edge_description = ""
        if edges:
            edge_lines = []
            for edge in edges[:10]:
                from_file = edge.get("from", "").split(".")[-1]
                to_file = edge.get("to", "").split(".")[-1]
                if from_file and to_file:
                    edge_lines.append(f"  {from_file} imports {to_file}")
            if edge_lines:
                edge_description = "\n\n**Import chain:**\n" + "\n".join(edge_lines)
                if len(edges) > 10:
                    edge_description += f"\n  ... and {len(edges) - 10} more imports"

        description = (
            f"Found circular import chain: {cycle_display}"
            f"{edge_description}"
        )

        finding = Finding(
            id=finding_id,
            detector="CircularDependencyDetector",
            severity=severity,
            title=f"Circular dependency involving {cycle_length} files",
            description=description,
            affected_nodes=cycle_names or cycle_files,
            affected_files=cycle_files,
            graph_context={
                "cycle_length": cycle_length,
                "cycle_files": cycle_files,
                "detection_method": detection_method,
                "edges": edges or [],
            },
            suggested_fix=self._suggest_fix(cycle_length),
            estimated_effort=self._estimate_effort(cycle_length),
            created_at=datetime.now(),
        )

        # Add collaboration metadata
        confidence = 0.95  # High confidence - direct graph query
        finding.add_collaboration_metadata(CollaborationMetadata(
            detector="CircularDependencyDetector",
            confidence=confidence,
            evidence=["circular_import", f"cycle_length_{cycle_length}", detection_method],
            tags=["circular_dependency", "architecture", "imports"]
        ))

        # Flag entities for cross-detector collaboration
        if self.enricher:
            for file_path in cycle_files:
                try:
                    self.enricher.flag_entity(
                        entity_qualified_name=file_path,
                        detector="CircularDependencyDetector",
                        severity=severity.value,
                        issues=["circular_dependency"],
                        confidence=confidence,
                        metadata={
                            "cycle_length": cycle_length,
                            "detection_method": detection_method
                        }
                    )
                except Exception:
                    pass  # Don't fail detection if enrichment fails

        return finding

    def severity(self, finding: Finding) -> Severity:
        """Calculate severity based on cycle length.

        Args:
            finding: Finding to assess

        Returns:
            Severity level
        """
        cycle_length = finding.graph_context.get("cycle_length", 0)
        return self._calculate_severity(cycle_length)

    def _calculate_severity(self, cycle_length: int) -> Severity:
        """Calculate severity based on cycle characteristics.

        Args:
            cycle_length: Number of files in the cycle

        Returns:
            Severity level
        """
        if cycle_length >= 10:
            return Severity.CRITICAL
        elif cycle_length >= 5:
            return Severity.HIGH
        elif cycle_length >= 3:
            return Severity.MEDIUM
        else:
            return Severity.LOW

    def _suggest_fix(self, cycle_length: int) -> str:
        """Suggest how to fix the circular dependency.

        Args:
            cycle_length: Number of files in the cycle

        Returns:
            Fix suggestion
        """
        if cycle_length >= 5:
            return (
                "Large circular dependency detected. Consider:\n"
                "1. Extract shared interfaces/types into a separate module\n"
                "2. Use dependency injection to break tight coupling\n"
                "3. Refactor into layers with clear dependency direction\n"
                "4. Apply the Dependency Inversion Principle"
            )
        else:
            return (
                "Small circular dependency. Consider:\n"
                "1. Merge the circular modules if they're tightly coupled\n"
                "2. Extract common dependencies to a third module\n"
                "3. Use forward references (TYPE_CHECKING) for type hints"
            )

    def _estimate_effort(self, cycle_length: int) -> str:
        """Estimate effort to fix based on cycle size.

        Args:
            cycle_length: Number of files in the cycle

        Returns:
            Effort estimate
        """
        if cycle_length >= 10:
            return "Large (2-4 days)"
        elif cycle_length >= 5:
            return "Medium (1-2 days)"
        else:
            return "Small (2-4 hours)"

    def _normalize_cycle(self, cycle: List[str]) -> tuple:
        """Normalize cycle to canonical form by rotating to start with minimum element.

        This preserves the directionality of the cycle while ensuring the same
        cycle is always represented the same way.

        Args:
            cycle: List of file paths in the cycle

        Returns:
            Normalized tuple representation
        """
        if not cycle:
            return tuple()

        # Find the index of the minimum element
        min_idx = cycle.index(min(cycle))

        # Rotate the cycle to start with the minimum element
        rotated = cycle[min_idx:] + cycle[:min_idx]

        return tuple(rotated)
