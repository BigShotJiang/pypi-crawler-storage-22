"""
Story storage management for ~/.repr/stories/

Stories are stored as pairs:
  - <ULID>.md: Story content in Markdown
  - <ULID>.json: Metadata (commits, timestamps, repo, etc.)
"""

import json
import os
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

# ULID generation (simple implementation)
import random
import time

# Base32 alphabet for ULID
ULID_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"


def generate_ulid() -> str:
    """Generate a ULID (Universally Unique Lexicographically Sortable Identifier)."""
    # Timestamp component (48 bits = 10 chars)
    timestamp_ms = int(time.time() * 1000)
    timestamp_chars = []
    for _ in range(10):
        timestamp_chars.append(ULID_ALPHABET[timestamp_ms & 31])
        timestamp_ms >>= 5
    timestamp_part = "".join(reversed(timestamp_chars))
    
    # Random component (80 bits = 16 chars)
    random_chars = [random.choice(ULID_ALPHABET) for _ in range(16)]
    random_part = "".join(random_chars)
    
    return timestamp_part + random_part


# Storage paths
REPR_HOME = Path(os.getenv("REPR_HOME", Path.home() / ".repr"))
STORIES_DIR = REPR_HOME / "stories"


def ensure_directories() -> None:
    """Ensure storage directories exist."""
    REPR_HOME.mkdir(exist_ok=True)
    STORIES_DIR.mkdir(exist_ok=True)


def _atomic_write(path: Path, content: str) -> None:
    """Write content atomically using temp file + rename."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as f:
            f.write(content)
        os.replace(tmp_path, path)
    except Exception:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)
        raise


def save_story(
    content: str,
    metadata: dict[str, Any],
    story_id: str | None = None,
) -> str:
    """
    Save a story to ~/.repr/stories/
    
    Args:
        content: Markdown content of the story
        metadata: Story metadata (commits, repo, timestamps, etc.)
        story_id: Optional ULID (generates new one if not provided)
    
    Returns:
        Story ID (ULID)
    """
    ensure_directories()
    
    if story_id is None:
        story_id = generate_ulid()
    
    # Add timestamps to metadata
    now = datetime.now().isoformat()
    if "created_at" not in metadata:
        metadata["created_at"] = now
    metadata["updated_at"] = now
    metadata["id"] = story_id
    
    # Write markdown file
    md_path = STORIES_DIR / f"{story_id}.md"
    _atomic_write(md_path, content)
    
    # Write metadata file
    meta_path = STORIES_DIR / f"{story_id}.json"
    _atomic_write(meta_path, json.dumps(metadata, indent=2, default=str))
    
    return story_id


def load_story(story_id: str) -> tuple[str, dict[str, Any]] | None:
    """
    Load a story by ID.
    
    Args:
        story_id: Story ULID
    
    Returns:
        Tuple of (content, metadata) or None if not found
    """
    md_path = STORIES_DIR / f"{story_id}.md"
    meta_path = STORIES_DIR / f"{story_id}.json"
    
    if not md_path.exists():
        return None
    
    content = md_path.read_text()
    
    metadata = {}
    if meta_path.exists():
        try:
            metadata = json.loads(meta_path.read_text())
        except json.JSONDecodeError:
            pass
    
    return content, metadata


def delete_story(story_id: str) -> bool:
    """
    Delete a story by ID.
    
    Args:
        story_id: Story ULID
    
    Returns:
        True if deleted, False if not found
    """
    md_path = STORIES_DIR / f"{story_id}.md"
    meta_path = STORIES_DIR / f"{story_id}.json"
    
    deleted = False
    
    if md_path.exists():
        md_path.unlink()
        deleted = True
    
    if meta_path.exists():
        meta_path.unlink()
        deleted = True
    
    return deleted


def list_stories(
    repo_name: str | None = None,
    since: datetime | None = None,
    needs_review: bool = False,
    limit: int | None = None,
) -> list[dict[str, Any]]:
    """
    List all stories with metadata.
    
    Args:
        repo_name: Filter by repository name
        since: Filter by creation date
        needs_review: Only show stories needing review
        limit: Maximum stories to return
    
    Returns:
        List of story metadata dicts (sorted by creation date, newest first)
    """
    ensure_directories()
    
    stories = []
    
    for meta_path in STORIES_DIR.glob("*.json"):
        try:
            metadata = json.loads(meta_path.read_text())
            
            # Apply filters
            if repo_name and metadata.get("repo_name") != repo_name:
                continue
            
            if since:
                created_at = metadata.get("created_at")
                if created_at:
                    created = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
                    if created < since:
                        continue
            
            if needs_review and not metadata.get("needs_review", False):
                continue
            
            # Check if content file exists
            story_id = meta_path.stem
            md_path = STORIES_DIR / f"{story_id}.md"
            if md_path.exists():
                metadata["_has_content"] = True
                metadata["_content_size"] = md_path.stat().st_size
            
            stories.append(metadata)
            
        except (json.JSONDecodeError, IOError):
            continue
    
    # Sort by creation date (newest first)
    stories.sort(
        key=lambda s: s.get("created_at", ""),
        reverse=True,
    )
    
    if limit:
        stories = stories[:limit]
    
    return stories


def update_story_metadata(story_id: str, updates: dict[str, Any]) -> bool:
    """
    Update metadata for a story.
    
    Args:
        story_id: Story ULID
        updates: Dict of fields to update
    
    Returns:
        True if updated, False if not found
    """
    meta_path = STORIES_DIR / f"{story_id}.json"
    
    if not meta_path.exists():
        return False
    
    try:
        metadata = json.loads(meta_path.read_text())
        metadata.update(updates)
        metadata["updated_at"] = datetime.now().isoformat()
        _atomic_write(meta_path, json.dumps(metadata, indent=2, default=str))
        return True
    except (json.JSONDecodeError, IOError):
        return False


def get_processed_commit_shas(repo_name: str | None = None) -> set[str]:
    """
    Get all commit SHAs that have already been processed into stories.
    
    Args:
        repo_name: Optional filter by repository name
    
    Returns:
        Set of commit SHAs that have been processed
    """
    ensure_directories()
    
    processed_shas = set()
    
    for meta_path in STORIES_DIR.glob("*.json"):
        try:
            metadata = json.loads(meta_path.read_text())
            
            # Filter by repo if specified
            if repo_name and metadata.get("repo_name") != repo_name:
                continue
            
            # Collect commit SHAs from this story
            commit_shas = metadata.get("commit_shas", [])
            processed_shas.update(commit_shas)
            
        except (json.JSONDecodeError, IOError):
            continue
    
    return processed_shas


def get_unpushed_stories() -> list[dict[str, Any]]:
    """Get stories that haven't been pushed to cloud."""
    stories = list_stories()
    return [s for s in stories if not s.get("pushed_at")]


def mark_story_pushed(story_id: str) -> bool:
    """Mark a story as pushed to cloud."""
    return update_story_metadata(story_id, {"pushed_at": datetime.now().isoformat()})


def get_stories_needing_review() -> list[dict[str, Any]]:
    """Get stories that need review."""
    return list_stories(needs_review=True)


def get_story_count() -> int:
    """Get total number of stories."""
    ensure_directories()
    return len(list(STORIES_DIR.glob("*.md")))


# ============================================================================
# Backup & Restore
# ============================================================================

def backup_all_data() -> dict[str, Any]:
    """
    Create a full backup of all repr data.
    
    Returns:
        Dict containing all data (can be serialized to JSON)
    """
    from .config import load_config, PROFILES_DIR, CACHE_DIR
    from .privacy import load_audit_log
    
    ensure_directories()
    
    # Backup stories
    stories_backup = []
    for md_path in STORIES_DIR.glob("*.md"):
        story_id = md_path.stem
        meta_path = STORIES_DIR / f"{story_id}.json"
        
        content = md_path.read_text()
        metadata = {}
        if meta_path.exists():
            try:
                metadata = json.loads(meta_path.read_text())
            except json.JSONDecodeError:
                pass
        
        stories_backup.append({
            "id": story_id,
            "content": content,
            "metadata": metadata,
        })
    
    # Backup profiles
    profiles_backup = []
    for profile_path in PROFILES_DIR.glob("*.md"):
        content = profile_path.read_text()
        meta_path = profile_path.with_suffix(".meta.json")
        metadata = {}
        if meta_path.exists():
            try:
                metadata = json.loads(meta_path.read_text())
            except json.JSONDecodeError:
                pass
        
        profiles_backup.append({
            "name": profile_path.stem,
            "content": content,
            "metadata": metadata,
        })
    
    # Get config (without sensitive data)
    config = load_config()
    config_backup = {k: v for k, v in config.items() if k != "auth"}
    
    # Get audit log
    audit_log = load_audit_log()
    
    return {
        "version": "1.0",
        "exported_at": datetime.now().isoformat(),
        "stories": stories_backup,
        "profiles": profiles_backup,
        "config": config_backup,
        "audit_log": audit_log,
    }


def restore_from_backup(backup_data: dict[str, Any], merge: bool = True) -> dict[str, int]:
    """
    Restore data from a backup.
    
    Args:
        backup_data: Backup dict (from backup_all_data or JSON file)
        merge: If True, merge with existing data. If False, replace.
    
    Returns:
        Dict with counts of restored items
    """
    from .config import save_config, load_config, PROFILES_DIR
    
    ensure_directories()
    
    restored = {
        "stories": 0,
        "profiles": 0,
        "config_keys": 0,
    }
    
    # Restore stories
    for story in backup_data.get("stories", []):
        story_id = story.get("id")
        if not story_id:
            continue
        
        # Check if exists
        md_path = STORIES_DIR / f"{story_id}.md"
        if md_path.exists() and merge:
            continue  # Skip existing in merge mode
        
        # Write story
        _atomic_write(md_path, story.get("content", ""))
        meta_path = STORIES_DIR / f"{story_id}.json"
        _atomic_write(meta_path, json.dumps(story.get("metadata", {}), indent=2))
        restored["stories"] += 1
    
    # Restore profiles
    for profile in backup_data.get("profiles", []):
        name = profile.get("name")
        if not name:
            continue
        
        profile_path = PROFILES_DIR / f"{name}.md"
        if profile_path.exists() and merge:
            continue
        
        profile_path.write_text(profile.get("content", ""))
        if profile.get("metadata"):
            meta_path = profile_path.with_suffix(".meta.json")
            _atomic_write(meta_path, json.dumps(profile.get("metadata"), indent=2))
        restored["profiles"] += 1
    
    # Restore config (merge non-sensitive keys)
    if backup_data.get("config"):
        current_config = load_config()
        backup_config = backup_data["config"]
        
        # Only restore safe keys
        safe_keys = ["settings", "llm", "generation", "publish", "privacy", "tracked_repos", "profile"]
        for key in safe_keys:
            if key in backup_config:
                if merge and key in current_config:
                    # Deep merge for dicts
                    if isinstance(current_config.get(key), dict) and isinstance(backup_config[key], dict):
                        current_config[key] = {**backup_config[key], **current_config[key]}
                    else:
                        current_config[key] = backup_config[key]
                else:
                    current_config[key] = backup_config[key]
                restored["config_keys"] += 1
        
        save_config(current_config)
    
    return restored


def export_stories_json() -> str:
    """
    Export all stories as JSON.
    
    Returns:
        JSON string of all stories
    """
    stories = []
    for md_path in STORIES_DIR.glob("*.md"):
        story_id = md_path.stem
        result = load_story(story_id)
        if result:
            content, metadata = result
            stories.append({
                "id": story_id,
                "content": content,
                "metadata": metadata,
            })
    
    return json.dumps(stories, indent=2, default=str)


def import_stories_json(json_data: str, merge: bool = True) -> int:
    """
    Import stories from JSON.
    
    Args:
        json_data: JSON string of stories
        merge: If True, skip existing stories
    
    Returns:
        Number of stories imported
    """
    try:
        stories = json.loads(json_data)
    except json.JSONDecodeError:
        return 0
    
    imported = 0
    for story in stories:
        story_id = story.get("id")
        
        # Generate new ID if not provided or if exists and not merging
        md_path = STORIES_DIR / f"{story_id}.md" if story_id else None
        if not story_id or (md_path and md_path.exists() and not merge):
            story_id = generate_ulid()
        elif md_path and md_path.exists() and merge:
            continue  # Skip existing
        
        # Save story
        content = story.get("content", "")
        metadata = story.get("metadata", {})
        save_story(content, metadata, story_id)
        imported += 1
    
    return imported


def get_storage_stats() -> dict[str, Any]:
    """
    Get storage statistics.
    
    Returns:
        Dict with storage stats
    """
    from .config import PROFILES_DIR, CACHE_DIR, CONFIG_FILE
    
    ensure_directories()
    
    def dir_size(path: Path) -> int:
        total = 0
        if path.exists():
            for f in path.rglob("*"):
                if f.is_file():
                    total += f.stat().st_size
        return total
    
    def file_count(path: Path, pattern: str = "*") -> int:
        if path.exists():
            return len(list(path.glob(pattern)))
        return 0
    
    stories_size = dir_size(STORIES_DIR)
    profiles_size = dir_size(PROFILES_DIR)
    cache_size = dir_size(CACHE_DIR)
    config_size = CONFIG_FILE.stat().st_size if CONFIG_FILE.exists() else 0
    
    return {
        "stories": {
            "count": file_count(STORIES_DIR, "*.md"),
            "size_bytes": stories_size,
            "path": str(STORIES_DIR),
        },
        "profiles": {
            "count": file_count(PROFILES_DIR, "*.md"),
            "size_bytes": profiles_size,
            "path": str(PROFILES_DIR),
        },
        "cache": {
            "size_bytes": cache_size,
            "path": str(CACHE_DIR),
        },
        "config": {
            "size_bytes": config_size,
            "path": str(CONFIG_FILE),
        },
        "total_size_bytes": stories_size + profiles_size + cache_size + config_size,
    }


# ============================================================================
# ReprStore - Project-level storage for .repr/ directory
# ============================================================================

REPR_DIR_NAME = ".repr"
STORE_FILE = "store.json"


def get_repr_store_path(project_path: Path) -> Path:
    """Get the .repr/store.json path for a project."""
    return project_path / REPR_DIR_NAME / STORE_FILE


def save_repr_store(store: "ReprStore", project_path: Path) -> Path:
    """
    Save ReprStore to SQLite.

    Note: This function now writes to SQLite only. The .repr/store.json
    format is deprecated. Use `repr data migrate-db` to import old stores.

    Args:
        store: ReprStore to save
        project_path: Project root path

    Returns:
        Path to the .repr directory
    """
    repr_dir = project_path / REPR_DIR_NAME
    repr_dir.mkdir(parents=True, exist_ok=True)

    # Write to SQLite
    if store.stories:
        save_stories_to_db(store.stories, project_path)

    return repr_dir


def load_repr_store(project_path: Path) -> "ReprStore | None":
    """
    Load ReprStore from .repr/store.json.
    
    Args:
        project_path: Project root path
    
    Returns:
        ReprStore or None if not found
    """
    from .models import ReprStore as ReprStoreModel
    
    store_path = get_repr_store_path(project_path)
    
    if not store_path.exists():
        return None
    
    try:
        store_json = store_path.read_text()
        return ReprStoreModel.model_validate_json(store_json)
    except Exception:
        return None


def create_repr_store(project_path: Path) -> "ReprStore":
    """
    Create a new empty ReprStore for a project.
    
    Args:
        project_path: Project root path
    
    Returns:
        New ReprStore instance
    """
    from datetime import datetime, timezone
    from .models import ReprStore as ReprStoreModel, ContentIndex
    
    return ReprStoreModel(
        project_path=str(project_path),
        initialized_at=datetime.now(timezone.utc),
        last_updated=datetime.now(timezone.utc),
        commits=[],
        sessions=[],
        stories=[],
        index=ContentIndex(),
    )


def update_repr_store_index(store: "ReprStore") -> None:
    """
    Rebuild the ContentIndex from stories in the store.
    
    Args:
        store: ReprStore to update (mutates in place)
    """
    from datetime import datetime, timezone
    from .models import ContentIndex, StoryDigest
    
    index = ContentIndex(
        last_updated=datetime.now(timezone.utc),
        story_count=len(store.stories),
    )
    
    for story in store.stories:
        # File → story mapping
        for f in story.files:
            if f not in index.files_to_stories:
                index.files_to_stories[f] = []
            index.files_to_stories[f].append(story.id)
        
        # Keyword extraction and mapping
        import re
        text = f"{story.title} {story.problem}".lower()
        words = re.findall(r'\b[a-z]+\b', text)
        stopwords = {'the', 'a', 'an', 'is', 'are', 'was', 'were', 'for', 'to', 'in', 'on', 'of', 'and', 'or', 'with', 'from'}
        keywords = [w for w in words if len(w) > 2 and w not in stopwords]
        
        for kw in set(keywords):
            if kw not in index.keywords_to_stories:
                index.keywords_to_stories[kw] = []
            index.keywords_to_stories[kw].append(story.id)
        
        # Weekly index
        if story.started_at:
            week = story.started_at.strftime("%Y-W%W")
            if week not in index.by_week:
                index.by_week[week] = []
            index.by_week[week].append(story.id)
        
        # Story digest
        index.story_digests.append(StoryDigest(
            story_id=story.id,
            title=story.title,
            problem_keywords=list(set(keywords))[:10],
            files=story.files[:5],
            tech_stack=_detect_tech_stack(story.files),
            category=story.category,
            timestamp=story.started_at or story.created_at,
        ))
    
    store.index = index


def _detect_tech_stack(files: list[str]) -> list[str]:
    """Detect technologies from file extensions."""
    tech = set()

    ext_map = {
        '.py': 'Python', '.ts': 'TypeScript', '.tsx': 'React',
        '.js': 'JavaScript', '.jsx': 'React', '.go': 'Go',
        '.rs': 'Rust', '.vue': 'Vue', '.sql': 'SQL',
    }

    for f in files:
        for ext, name in ext_map.items():
            if f.endswith(ext):
                tech.add(name)

    return sorted(tech)


# ============================================================================
# SQLite Storage Functions
# ============================================================================

def save_stories_to_db(stories: list, project_path: Path) -> int:
    """
    Save stories to central SQLite database.

    Args:
        stories: List of Story objects
        project_path: Path to the project

    Returns:
        Number of stories saved
    """
    from .db import get_db

    db = get_db()
    project = db.get_project_by_path(project_path)

    if not project:
        project_id = db.register_project(project_path, project_path.name)
    else:
        project_id = project["id"]

    for story in stories:
        db.save_story(story, project_id)

    return len(stories)


def load_stories_from_db(
    project_path: Path | None = None,
    category: str | None = None,
    since: "datetime | None" = None,
    limit: int = 100,
) -> list:
    """
    Load stories from central SQLite database.

    Args:
        project_path: Optional project path filter
        category: Optional category filter
        since: Optional date filter
        limit: Maximum stories to return

    Returns:
        List of Story objects
    """
    from .db import get_db

    db = get_db()

    project_id = None
    if project_path:
        project = db.get_project_by_path(project_path)
        if project:
            project_id = project["id"]

    return db.list_stories(
        project_id=project_id,
        category=category,
        since=since,
        limit=limit,
    )


def search_stories_in_db(
    query: str,
    files: list[str] | None = None,
    limit: int = 20,
) -> list:
    """
    Search stories using FTS5.

    Args:
        query: Search query
        files: Optional file paths to filter by
        limit: Maximum results

    Returns:
        List of Story objects
    """
    from .db import get_db

    db = get_db()
    return db.search_stories(query, files=files, limit=limit)


def get_story_from_db(story_id: str):
    """
    Get a story by ID from SQLite.

    Args:
        story_id: Story UUID

    Returns:
        Story object or None
    """
    from .db import get_db

    db = get_db()
    return db.get_story(story_id)


def migrate_stores_to_db(
    project_paths: list[Path] | None = None,
    dry_run: bool = False,
) -> dict:
    """
    Migrate existing store.json files to SQLite.

    Args:
        project_paths: List of project paths to migrate (None = all tracked)
        dry_run: If True, don't actually write to DB

    Returns:
        Migration statistics
    """
    from .db import get_db
    from .config import get_tracked_repos

    db = get_db()

    if project_paths is None:
        # Get all tracked repos
        tracked = get_tracked_repos()
        project_paths = [Path(r["path"]) for r in tracked if Path(r["path"]).exists()]

    stats = {
        "projects_scanned": 0,
        "projects_migrated": 0,
        "stories_imported": 0,
        "errors": [],
    }

    for project_path in project_paths:
        stats["projects_scanned"] += 1

        store = load_repr_store(project_path)
        if not store:
            continue

        if not store.stories:
            continue

        if dry_run:
            stats["projects_migrated"] += 1
            stats["stories_imported"] += len(store.stories)
            continue

        try:
            imported = db.import_from_store(store, project_path)
            stats["projects_migrated"] += 1
            stats["stories_imported"] += imported
        except Exception as e:
            stats["errors"].append(f"{project_path.name}: {str(e)}")

    return stats


def get_db_stats() -> dict:
    """Get SQLite database statistics."""
    from .db import get_db

    db = get_db()
    return db.get_stats()

