"""Test package for republic."""
