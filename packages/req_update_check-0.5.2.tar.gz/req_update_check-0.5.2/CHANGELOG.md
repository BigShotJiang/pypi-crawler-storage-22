# Changelog

## [0.5.2](https://github.com/ontherivt/req-update-check/compare/v0.5.1...v0.5.2) (2026-01-28)


### Bug Fixes

* inline PyPI publish steps to fix trusted publishing ([#43](https://github.com/ontherivt/req-update-check/issues/43)) ([d351a2e](https://github.com/ontherivt/req-update-check/commit/d351a2e06197aad9e3a833df16b9b6c0763dccc9))

## [0.5.1](https://github.com/ontherivt/req-update-check/compare/v0.5.0...v0.5.1) (2026-01-28)


### Bug Fixes

* add id-token permission for PyPI trusted publishing ([#41](https://github.com/ontherivt/req-update-check/issues/41)) ([eec02e0](https://github.com/ontherivt/req-update-check/commit/eec02e0ed1068bdf68fe46a8effab599a02ed4fc))
* trigger PyPI publish from release-please workflow ([#40](https://github.com/ontherivt/req-update-check/issues/40)) ([f57dfc1](https://github.com/ontherivt/req-update-check/commit/f57dfc1b1b11bd53d8461757426b7b20b96bafb0))

## [0.5.0](https://github.com/ontherivt/req-update-check/compare/v0.4.2...v0.5.0) (2026-01-28)


### Features

* add --output json flag for structured JSON output ([#37](https://github.com/ontherivt/req-update-check/issues/37)) ([b1075bc](https://github.com/ontherivt/req-update-check/commit/b1075bcaf529d6a055e1229672d8c18ee6028f36))


### Bug Fixes

* normalize package names to lowercase for case-insensitive lookup ([#39](https://github.com/ontherivt/req-update-check/issues/39)) ([51ee5fd](https://github.com/ontherivt/req-update-check/commit/51ee5fd3a18f99b7e6c37ce89792a389a9242148))

## [0.4.2](https://github.com/ontherivt/req-update-check/compare/v0.4.1...v0.4.2) (2025-11-12)


### Bug Fixes

* --ai-check will only show the selected package ([d514683](https://github.com/ontherivt/req-update-check/commit/d5146837dc9aa9971504e4661ba43f13c84b06a7))

## [0.4.1](https://github.com/ontherivt/req-update-check/compare/v0.4.0...v0.4.1) (2025-10-23)


### Bug Fixes

* check release notes ([f14df54](https://github.com/ontherivt/req-update-check/commit/f14df543b746ba011322e42682a6826152abc7ae))

## [0.4.0](https://github.com/ontherivt/req-update-check/compare/v0.3.0...v0.4.0) (2025-10-23)


### Features

* Handle project_urls=None in pypi response ([664aeef](https://github.com/ontherivt/req-update-check/commit/664aeef2e75ad19c3bd7a89bbffa81fcfaaa9cbb))

## [0.3.0](https://github.com/ontherivt/req-update-check/compare/v0.2.2...v0.3.0) (2025-10-22)


### Features

* AI analysis of upgrading package ([067599d](https://github.com/ontherivt/req-update-check/commit/067599d565b3e35913b5e786933539a670fbcc56))


### Bug Fixes

* Better output display ([59c07d8](https://github.com/ontherivt/req-update-check/commit/59c07d808f9622ce8df17e150f1ce53996e9e489))
* fix import errors ([f7f8cd0](https://github.com/ontherivt/req-update-check/commit/f7f8cd0a41626b5714eed967b048bb912f72e886))
