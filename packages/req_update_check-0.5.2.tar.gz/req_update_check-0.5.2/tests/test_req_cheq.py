import importlib
import json
import sys
import unittest
from unittest.mock import Mock
from unittest.mock import mock_open
from unittest.mock import patch

import requests

from src.req_update_check import core
from src.req_update_check.cache import FileCache
from src.req_update_check.cli import main
from src.req_update_check.core import Requirements


class TestFileCache(unittest.TestCase):
    def setUp(self):
        self.cache = FileCache(cache_dir=".test-cache")
        self.test_key = "test-key"
        self.test_value = {"data": "test"}

    def tearDown(self):
        self.cache.clear()

    def test_set_and_get(self):
        self.cache.set(self.test_key, self.test_value)
        result = self.cache.get(self.test_key)
        self.assertEqual(result, self.test_value)

    def test_expired_cache(self):
        with patch("time.time", return_value=100):
            self.cache.set(self.test_key, self.test_value)

        with patch("time.time", return_value=5000):
            result = self.cache.get(self.test_key)
            self.assertIsNone(result)

    def test_invalid_cache(self):
        cache_file = self.cache.cache_dir / f"{self.test_key}.json"
        cache_file.write_text("invalid json")
        result = self.cache.get(self.test_key)
        self.assertIsNone(result)


class TestRequirements(unittest.TestCase):
    def setUp(self):
        self.req_content = """
requests==2.26.0
flask==2.0.1
# comment line
pytest==6.2.4  # inline comment
"""
        self.toml_content = """
[project]
dependencies = [
    "requests==2.26.0",
    "flask==2.0.1",
]

[dependency-groups]
group1 = ["pytest==6.2.4"]
group2 = ["numpy==1.21.0"]

"""

        self.mock_index = {
            "projects": [
                {"name": "requests"},
                {"name": "flask"},
                {"name": "pytest"},
            ],
        }
        self.mock_versions = {
            "versions": ["2.26.0", "2.27.0", "2.28.0"],
        }

        self.requirements = Requirements("requirements.txt", allow_cache=False)

    @patch.object(Requirements, "get_index")
    @patch("builtins.open", new_callable=mock_open)
    def test_get_packages(self, mock_file, mock_get_index):
        mock_file.return_value.readlines.return_value = self.req_content.split("\n")
        req = Requirements("requirements.txt", allow_cache=False)
        req.check_packages()
        expected = [
            ["requests", "2.26.0"],
            ["flask", "2.0.1"],
            ["pytest", "6.2.4"],
        ]
        self.assertEqual(req.packages, expected)

    @unittest.skipIf(sys.version_info < (3, 11), "Test requires Python 3.11 or newer")
    @patch.object(Requirements, "get_index")
    @patch("builtins.open", new_callable=mock_open)
    def test_get_packages__toml(self, mock_file, mock_get_index):
        mock_file.return_value.read.return_value = self.toml_content.encode("utf-8")
        req = Requirements("pyproject.toml", allow_cache=False)
        req.check_packages()
        expected = [
            ["requests", "2.26.0"],
            ["flask", "2.0.1"],
            ["pytest", "6.2.4"],
            ["numpy", "1.21.0"],
        ]
        self.assertEqual(req.packages, expected)

    def test_get_packages__toml__before_python_311(self):
        # Make tomllib "unavailable" and reload so TOMLLIB is recomputed.
        with patch.dict(sys.modules, {"tomllib": None}):
            importlib.reload(core)
            self.assertFalse(core.TOMLLIB, "Expected TOMLLIB to be False after reload")

            # Patch *after* reload, and patch the class on the reloaded module.
            with (
                patch.object(core.Requirements, "get_index"),
                patch("builtins.open", new_callable=mock_open) as mock_file,
            ):
                with self.assertRaises(SystemExit) as cm:
                    # IMPORTANT: call the reloaded class
                    req = core.Requirements("pyproject.toml", allow_cache=False)
                    req.check_packages()

                self.assertEqual(cm.exception.code, 1)
                mock_file.assert_not_called()

    @patch("requests.get")
    def test_get_index(self, mock_get):
        mock_get.return_value.json.side_effect = [self.mock_index] + [self.mock_versions] * 3
        with patch("builtins.open", new_callable=mock_open) as mock_file:
            mock_file.return_value.readlines.return_value = self.req_content.split("\n")
            req = Requirements("requirements.txt", allow_cache=False)
            req.check_packages()
            self.assertEqual(req.package_index, {"requests", "flask", "pytest"})

    @patch.object(Requirements, "get_index")
    @patch("requests.get")
    def test_get_latest_version(self, mock_get, mock_get_index):
        mock_get.return_value.json.return_value = self.mock_versions
        with patch("builtins.open", new_callable=mock_open) as mock_file:
            mock_file.return_value.readlines.return_value = self.req_content.split("\n")
            req = Requirements("requirements.txt", allow_cache=False)
            latest = req.get_latest_version("requests")
            self.assertEqual(latest, "2.28.0")

    @patch.object(Requirements, "get_index")
    def test_check_major_minor(self, mock_get_index):
        with patch("builtins.open", new_callable=mock_open) as mock_file:
            mock_file.return_value.readlines.return_value = self.req_content.split("\n")
            req = Requirements("requirements.txt", allow_cache=False)

            self.assertEqual(req.check_major_minor("1.0.0", "2.0.0"), "major")
            self.assertEqual(req.check_major_minor("1.0.0", "1.1.0"), "minor")
            self.assertEqual(req.check_major_minor("1.0.0", "1.0.1"), "patch")

    def test_optional_dependencies(self):
        package = ["psycopg2[binary]", "2.9.1"]
        with self.assertLogs("req_update_check", level="INFO") as cm:
            self.requirements.check_package(package)
        self.assertIn("Skipping optional packages 'binary' from psycopg2", cm.output[0])

        package = ["psycopg2", "2.9.1"]
        with self.assertLogs("req_update_check", level="INFO") as cm:
            self.requirements.check_package(package)

        self.assertNotIn("Skipping optional packages", cm.output[0])

    @patch("requests.get")
    def test_get_package_info(self, mock_get):
        mock_response = mock_get.return_value
        mock_response.json.return_value = {
            "info": {
                "home_page": "https://example.com",
                "project_urls": {
                    "Homepage": "https://example.com",
                    "Changelog": "https://example.com/changelog",
                },
            },
        }
        mock_response.raise_for_status.return_value = None

        req = Requirements("requirements.txt", allow_cache=False)
        info = req.get_package_info("test-package")

        self.assertEqual(info["homepage"], "https://example.com")
        self.assertEqual(info["changelog"], "https://example.com/changelog")
        mock_get.assert_called_once_with("https://pypi.org/pypi/test-package/json", timeout=10)

    @patch("requests.get")
    def test_get_package_info_no_homepage(self, mock_get):
        mock_response = mock_get.return_value
        mock_response.json.return_value = {
            "info": {
                "project_urls": {
                    "Source": "https://github.com/example/test",
                },
            },
        }
        mock_response.raise_for_status.return_value = None

        req = Requirements("requirements.txt", allow_cache=False)
        info = req.get_package_info("app-store-server-library")

        self.assertNotIn("homepage", info)
        self.assertNotIn("changelog", info)

    @patch("requests.get")
    def test_get_package_info_none(self, mock_get):
        mock_response = mock_get.return_value
        mock_response.json.return_value = {
            "info": {
                "project_urls": None,
                "project_url": "https://pypi.org/project/app-store-server-library/",
            },
        }
        req = Requirements("requirements.txt", allow_cache=False)
        info = req.get_package_info("app-store-server-library")

        self.assertNotIn("homepage", info)
        self.assertNotIn("changelog", info)

    @patch("requests.get")
    def test_get_package_info_api_failure(self, mock_get):
        mock_get.side_effect = requests.RequestException("API Error")

        req = Requirements("requirements.txt", allow_cache=False)
        info = req.get_package_info("test-package")

        self.assertEqual(info, {})


class TestCLI(unittest.TestCase):
    def setUp(self):
        self.req_content = "requests==2.26.0\nflask==2.0.1\n"
        self.requirements_file = "requirements.txt"

    @patch("sys.argv", ["req-check", "requirements.txt"])
    @patch("builtins.print")
    @patch("src.req_update_check.cli.Requirements")
    def test_main_default_args(self, mock_requirements, mock_print):
        mock_instance = mock_requirements.return_value
        main()
        mock_requirements.assert_called_with(
            "requirements.txt",
            allow_cache=True,
            cache_dir=None,
            ai_provider=None,
        )
        mock_instance.check_packages.assert_called_once()
        mock_instance.report.assert_called_once_with(ai_check_packages=None, output_format="text")

    @patch("sys.argv", ["req-check", "requirements.txt", "--no-cache"])
    @patch("builtins.print")
    @patch("src.req_update_check.cli.Requirements")
    def test_main_no_cache(self, mock_requirements, mock_print):
        main()
        mock_requirements.assert_called_with(
            "requirements.txt",
            allow_cache=False,
            cache_dir=None,
            ai_provider=None,
        )

    @patch(
        "sys.argv",
        ["req-check", "requirements.txt", "--cache-dir", "/custom/cache"],
    )
    @patch("builtins.print")
    @patch("src.req_update_check.cli.Requirements")
    def test_main_custom_cache_dir(self, mock_requirements, mock_print):
        main()
        mock_requirements.assert_called_with(
            "requirements.txt",
            allow_cache=True,
            cache_dir="/custom/cache",
            ai_provider=None,
        )

    @patch("sys.argv", ["req-check", "requirements.txt", "--output", "json"])
    @patch("builtins.print")
    @patch("src.req_update_check.cli.Requirements")
    def test_main_json_output(self, mock_requirements, mock_print):
        mock_instance = mock_requirements.return_value
        expected_result = {"packages": [], "metadata": {}}
        mock_instance.report.return_value = expected_result
        main()
        mock_instance.report.assert_called_once_with(ai_check_packages=None, output_format="json")
        mock_print.assert_called_once_with(json.dumps(expected_result, indent=2))

    @patch("sys.argv", ["req-check", "requirements.txt", "--output", "json", "--ai-check", "requests"])
    @patch("builtins.print")
    @patch("src.req_update_check.cli.Requirements")
    @patch("src.req_update_check.cli.AIProviderFactory")
    def test_main_json_output_with_ai_check(self, mock_factory, mock_requirements, mock_print):
        """Test JSON output combined with AI analysis"""
        mock_provider = Mock()
        mock_provider.get_model_name.return_value = "claude-3-5-sonnet"
        mock_factory.create.return_value = mock_provider

        mock_instance = mock_requirements.return_value
        expected_result = {"packages": [{"name": "requests", "safety": "safe"}], "metadata": {}}
        mock_instance.report.return_value = expected_result
        main()
        mock_instance.report.assert_called_once_with(ai_check_packages=["requests"], output_format="json")
        mock_print.assert_called_once_with(json.dumps(expected_result, indent=2))


class TestRequirementsWithAI(unittest.TestCase):
    """Tests for Requirements with AI analyzer integration"""

    def test_report_filters_by_ai_check_package(self):
        """Test that report filters packages when ai_check_packages is specified"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.updates = [
            ("requests", "1.0.0", "2.0.0", "major"),
            ("flask", "1.0.0", "1.5.0", "minor"),
            ("pytest", "5.0.0", "6.0.0", "major"),
        ]

        # Test filtering to single package
        with self.assertLogs("req_update_check", level="INFO") as cm:
            req.report(ai_check_packages=["requests"])

        output = "\n".join(cm.output)
        # Should contain requests
        self.assertIn("requests", output)
        # Should NOT contain flask or pytest
        self.assertNotIn("flask", output)
        self.assertNotIn("pytest", output)

    def test_report_filters_multiple_packages(self):
        """Test that report filters to multiple specified packages"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.updates = [
            ("requests", "1.0.0", "2.0.0", "major"),
            ("flask", "1.0.0", "1.5.0", "minor"),
            ("pytest", "5.0.0", "6.0.0", "major"),
        ]

        # Test filtering to multiple packages
        with self.assertLogs("req_update_check", level="INFO") as cm:
            req.report(ai_check_packages=["requests", "pytest"])

        output = "\n".join(cm.output)
        # Should contain requests and pytest
        self.assertIn("requests", output)
        self.assertIn("pytest", output)
        # Should NOT contain flask
        self.assertNotIn("flask", output)

    def test_report_shows_all_with_asterisk(self):
        """Test that report shows all packages when ai_check_packages is ['*']"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.updates = [
            ("requests", "1.0.0", "2.0.0", "major"),
            ("flask", "1.0.0", "1.5.0", "minor"),
            ("pytest", "5.0.0", "6.0.0", "major"),
        ]

        # Test showing all packages with "*"
        with self.assertLogs("req_update_check", level="INFO") as cm:
            req.report(ai_check_packages=["*"])

        output = "\n".join(cm.output)
        # Should contain all packages
        self.assertIn("requests", output)
        self.assertIn("flask", output)
        self.assertIn("pytest", output)

    def test_report_shows_all_when_no_filter(self):
        """Test that report shows all packages when ai_check_packages is None"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.updates = [
            ("requests", "1.0.0", "2.0.0", "major"),
            ("flask", "1.0.0", "1.5.0", "minor"),
        ]

        # Test showing all packages when None
        with self.assertLogs("req_update_check", level="INFO") as cm:
            req.report(ai_check_packages=None)

        output = "\n".join(cm.output)
        # Should contain all packages
        self.assertIn("requests", output)
        self.assertIn("flask", output)

    def test_report_handles_no_matching_packages(self):
        """Test that report handles case when no packages match the filter"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.updates = [
            ("requests", "1.0.0", "2.0.0", "major"),
            ("flask", "1.0.0", "1.5.0", "minor"),
        ]

        # Test filtering to non-existent package
        with self.assertLogs("req_update_check", level="INFO") as cm:
            req.report(ai_check_packages=["nonexistent"])

        output = "\n".join(cm.output)
        # Should show message about no updates found
        self.assertIn("No updates found for the specified package(s): nonexistent", output)
        # Should NOT contain requests or flask
        self.assertNotIn("requests: 1.0.0 -> 2.0.0", output)
        self.assertNotIn("flask: 1.0.0 -> 1.5.0", output)

    @patch("requests.get")
    def test_analyze_update_with_ai_success(self, mock_get):
        """Test AI analysis of package update"""
        # Mock provider
        mock_provider = Mock()
        mock_result = Mock()
        mock_result.safety = "safe"
        mock_result.summary = "Safe to update"
        mock_provider.analyze.return_value = mock_result

        req = Requirements("requirements.txt", allow_cache=False, ai_provider=mock_provider)

        # Mock the private method
        result = req._analyze_update_with_ai(
            package_name="requests",
            current_version="1.0.0",
            latest_version="2.0.0",
            update_level="major",
            package_info={"changelog": "https://example.com/changelog"},
        )

        self.assertIsNotNone(result)
        self.assertEqual(result.safety, "safe")

    @patch("requests.get")
    def test_analyze_update_with_ai_failure(self, mock_get):
        """Test AI analysis handles errors gracefully"""
        # Mock provider that raises exception
        mock_provider = Mock()
        mock_provider.analyze.side_effect = Exception("AI Error")

        req = Requirements("requirements.txt", allow_cache=False, ai_provider=mock_provider)

        # Should return None on error, not raise
        result = req._analyze_update_with_ai(
            package_name="requests",
            current_version="1.0.0",
            latest_version="2.0.0",
            update_level="major",
            package_info={},
        )

        self.assertIsNone(result)

    def test_requirements_initializes_ai_analyzer(self):
        """Test that Requirements initializes AI analyzer when provider given"""
        mock_provider = Mock()
        req = Requirements("requirements.txt", allow_cache=False, ai_provider=mock_provider)

        self.assertIsNotNone(req.ai_analyzer)
        self.assertEqual(req.ai_analyzer.provider, mock_provider)

    def test_requirements_no_ai_analyzer_without_provider(self):
        """Test that Requirements doesn't create AI analyzer without provider"""
        req = Requirements("requirements.txt", allow_cache=False, ai_provider=None)

        self.assertIsNone(req.ai_analyzer)


class TestJSONOutput(unittest.TestCase):
    """Tests for JSON output format"""

    def test_report_json_output_format(self):
        """Test that report returns structured JSON data when output_format is json"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.packages = [["requests", "1.0.0"], ["flask", "1.0.0"]]
        req.updates = [
            ("requests", "1.0.0", "2.0.0", "major"),
            ("flask", "1.0.0", "1.5.0", "minor"),
        ]

        result = req.report(output_format="json")

        self.assertIsInstance(result, dict)
        self.assertIn("packages", result)
        self.assertIn("metadata", result)
        self.assertEqual(len(result["packages"]), 2)

    def test_report_json_package_structure(self):
        """Test that JSON output has correct package structure"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.packages = [["requests", "1.0.0"]]
        req.updates = [
            ("requests", "1.0.0", "2.0.0", "major"),
        ]

        result = req.report(output_format="json")
        pkg = result["packages"][0]

        self.assertEqual(pkg["name"], "requests")
        self.assertEqual(pkg["current_version"], "1.0.0")
        self.assertEqual(pkg["latest_version"], "2.0.0")
        self.assertTrue(pkg["has_update"])
        self.assertEqual(pkg["version_change"], "major")

    def test_report_json_metadata_structure(self):
        """Test that JSON output has correct metadata structure"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.packages = [["requests", "1.0.0"], ["flask", "1.0.0"]]
        req.updates = [
            ("requests", "1.0.0", "2.0.0", "major"),
        ]

        result = req.report(output_format="json")
        metadata = result["metadata"]

        self.assertEqual(metadata["requirements_file"], "requirements.txt")
        self.assertEqual(metadata["total_packages"], 2)
        self.assertEqual(metadata["packages_with_updates"], 1)

    def test_report_json_filters_by_package(self):
        """Test that JSON output respects ai_check_packages filter"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.packages = [["requests", "1.0.0"], ["flask", "1.0.0"]]
        req.updates = [
            ("requests", "1.0.0", "2.0.0", "major"),
            ("flask", "1.0.0", "1.5.0", "minor"),
        ]

        result = req.report(ai_check_packages=["requests"], output_format="json")

        self.assertEqual(len(result["packages"]), 1)
        self.assertEqual(result["packages"][0]["name"], "requests")
        # packages_with_updates should reflect the filtered count
        self.assertEqual(result["metadata"]["packages_with_updates"], 1)

    def test_report_json_empty_updates(self):
        """Test that JSON output handles no updates correctly"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.packages = [["requests", "2.0.0"]]
        req.updates = []

        result = req.report(output_format="json")

        self.assertEqual(len(result["packages"]), 0)
        self.assertEqual(result["metadata"]["packages_with_updates"], 0)

    def test_report_json_with_ai_provider_metadata(self):
        """Test that JSON output includes AI provider info when available"""
        mock_provider = Mock()
        mock_provider.get_model_name.return_value = "claude-3-5-sonnet-20241022"

        req = Requirements("requirements.txt", allow_cache=False, ai_provider=mock_provider)
        req.packages = [["requests", "1.0.0"]]
        req.updates = []

        result = req.report(output_format="json")

        self.assertIn("ai_provider", result["metadata"])
        self.assertIn("ai_model", result["metadata"])
        # Mock class name is "Mock", so ai_provider should be "mock"
        self.assertEqual(result["metadata"]["ai_provider"], "mock")
        self.assertEqual(result["metadata"]["ai_model"], "claude-3-5-sonnet-20241022")

    @patch("requests.get")
    def test_report_json_with_ai_analysis(self, mock_get):
        """Test that JSON output includes AI analysis results"""
        mock_provider = Mock()
        mock_result = Mock()
        mock_result.safety = "safe"
        mock_result.confidence = "high"
        mock_result.recommendations = ["Upgrade safely"]
        mock_result.breaking_changes = []
        mock_result.deprecations = []
        mock_result.new_features = ["New feature"]
        mock_result.summary = "Safe to upgrade"
        mock_result.input_tokens = 100
        mock_result.output_tokens = 50
        mock_result.total_tokens = 150
        mock_provider.analyze.return_value = mock_result
        mock_provider.get_model_name.return_value = "claude-3-5-sonnet-20241022"

        req = Requirements("requirements.txt", allow_cache=False, ai_provider=mock_provider)
        req.packages = [["requests", "1.0.0"]]
        req.updates = [("requests", "1.0.0", "2.0.0", "major")]

        result = req.report(ai_check_packages=["requests"], output_format="json")

        pkg = result["packages"][0]
        self.assertEqual(pkg["safety"], "safe")
        self.assertEqual(pkg["confidence"], "high")
        self.assertEqual(pkg["recommendations"], ["Upgrade safely"])
        self.assertEqual(pkg["breaking_changes"], [])
        self.assertEqual(pkg["deprecations"], [])
        self.assertEqual(pkg["new_features"], ["New feature"])
        self.assertEqual(pkg["summary"], "Safe to upgrade")
        # Verify token usage fields are included
        self.assertIn("input_tokens", pkg)
        self.assertIn("output_tokens", pkg)
        self.assertIn("total_tokens", pkg)

    def test_report_json_filter_excludes_all_packages(self):
        """Test JSON output when filter matches no packages (but updates exist)"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.packages = [["requests", "1.0.0"], ["flask", "1.0.0"]]
        req.updates = [
            ("requests", "1.0.0", "2.0.0", "major"),
            ("flask", "1.0.0", "1.5.0", "minor"),
        ]

        result = req.report(ai_check_packages=["nonexistent"], output_format="json")

        # Should return empty packages array with zero count
        self.assertEqual(len(result["packages"]), 0)
        self.assertEqual(result["metadata"]["packages_with_updates"], 0)
        # total_packages should still reflect actual count
        self.assertEqual(result["metadata"]["total_packages"], 2)

    def test_report_json_includes_pypi_url(self):
        """Test that JSON output includes PyPI URL for each package"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.packages = [["requests", "1.0.0"]]
        req.updates = [("requests", "1.0.0", "2.0.0", "major")]

        result = req.report(output_format="json")

        pkg = result["packages"][0]
        self.assertIn("pypi_url", pkg)
        self.assertIn("requests", pkg["pypi_url"])

    def test_report_invalid_output_format_raises_error(self):
        """Test that invalid output_format raises ValueError"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.packages = [["requests", "1.0.0"]]
        req.updates = []

        with self.assertRaises(ValueError) as cm:
            req.report(output_format="xml")

        self.assertIn("Invalid output_format", str(cm.exception))
        self.assertIn("xml", str(cm.exception))


class TestCaseSensitivity(unittest.TestCase):
    """Tests for case-insensitive package name handling (PEP 503)"""

    def test_get_index_stores_lowercase_names(self):
        """Test that package names are stored as lowercase in the index"""
        mock_response = Mock()
        mock_response.json.return_value = {
            "projects": [
                {"name": "Django"},
                {"name": "Flask"},
                {"name": "Requests"},
            ],
        }

        with patch("requests.get", return_value=mock_response):
            req = Requirements("requirements.txt", allow_cache=False)
            req.get_index()

        # All names should be stored as lowercase
        self.assertIn("django", req.package_index)
        self.assertIn("flask", req.package_index)
        self.assertIn("requests", req.package_index)
        # Uppercase versions should not be in the index
        self.assertNotIn("Django", req.package_index)
        self.assertNotIn("Flask", req.package_index)
        self.assertNotIn("Requests", req.package_index)

    def test_check_package_finds_lowercase_in_uppercase_index(self):
        """Test that lowercase package names match uppercase index entries"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.package_index = {"django", "flask"}  # lowercase stored

        with patch.object(req, "get_latest_version", return_value="4.2.0"):
            req.check_package(["django", "4.0.0"])

        # Should find the package and add to updates
        self.assertEqual(len(req.updates), 1)
        self.assertEqual(req.updates[0][0], "django")

    def test_check_package_finds_uppercase_in_lowercase_index(self):
        """Test that uppercase package names match lowercase index entries"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.package_index = {"django", "flask"}  # lowercase stored

        with patch.object(req, "get_latest_version", return_value="4.2.0"):
            req.check_package(["Django", "4.0.0"])

        # Should find the package and add to updates
        self.assertEqual(len(req.updates), 1)
        self.assertEqual(req.updates[0][0], "Django")

    def test_check_package_mixed_case_variations(self):
        """Test that mixed case package names work correctly"""
        req = Requirements("requirements.txt", allow_cache=False)
        req.package_index = {"django", "flask", "numpy"}

        test_cases = [
            ["DJANGO", "4.0.0"],
            ["DjAnGo", "4.0.0"],
            ["dJaNgO", "4.0.0"],
        ]

        with patch.object(req, "get_latest_version", return_value="4.2.0"):
            for package in test_cases:
                req.updates = []  # Reset for each test
                req.check_package(package)
                self.assertEqual(len(req.updates), 1, f"Failed for case: {package[0]}")

    @patch("requests.get")
    def test_get_latest_version_uses_lowercase_url(self, mock_get):
        """Test that get_latest_version uses lowercase in API URL"""
        mock_response = Mock()
        mock_response.json.return_value = {"versions": ["4.2.0"]}
        mock_get.return_value = mock_response

        req = Requirements("requirements.txt", allow_cache=False)
        req.get_latest_version("Django")

        # Verify the API was called with lowercase package name
        call_url = mock_get.call_args[0][0]
        self.assertIn("django", call_url.lower())
        self.assertNotIn("Django", call_url)

    @patch("requests.get")
    def test_get_package_info_uses_lowercase_url(self, mock_get):
        """Test that get_package_info uses lowercase in API URL"""
        mock_response = Mock()
        mock_response.json.return_value = {
            "info": {"home_page": "https://example.com", "project_urls": {}},
        }
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response

        req = Requirements("requirements.txt", allow_cache=False)
        req.get_package_info("Django")

        # Verify the API was called with lowercase package name
        call_url = mock_get.call_args[0][0]
        self.assertIn("django", call_url.lower())
        self.assertNotIn("Django", call_url)


if __name__ == "__main__":
    unittest.main()
