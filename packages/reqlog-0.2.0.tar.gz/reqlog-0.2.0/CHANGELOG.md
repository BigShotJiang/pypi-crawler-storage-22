# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-02-15

### Added

- **MCP server** with 5 tools (`get_recent_requests`, `get_request_detail`, `get_error_summary`, `search_requests`, `get_endpoint_stats`) and 2 resources (`reqlog://status`, `reqlog://recent-errors`)
- **Django middleware** with sync/async auto-detection and zero-latency background logging via ThreadPoolExecutor
- **FileBackend** with rotating log file support (json/text/ai formats)
- **CLI tool** with `tail`, `stats`, `export`, `mcp`, and `demo` commands
- **Panel formatter** (v2) — Claude Code-inspired two-column request/response layout
- **AI formatter** — token-efficient plain-text format, auto-detected in Claude Code/Cursor/Aider
- **Configuration validation** for sample_rate, max_body_size, and sqlite_max_queue_size
- **MCP parameter validation** to prevent resource exhaustion (query limits, time windows, search length)
- **Error sanitization** in MCP responses to prevent leaking internal paths and stack traces
- **Graceful shutdown** for SQLiteBackend via non-daemon writer thread and atexit handler
- **ASGI lifespan support** for clean backend shutdown
- `--redact-bodies` flag for MCP server to strip all bodies from responses
- `REQLOG_SQLITE_MAX_QUEUE_SIZE` environment variable override
- Request ID generation and `X-Request-ID` header support

### Changed

- SQLite write queue is now bounded (default 10,000) to prevent memory exhaustion under load

## [0.1.0] - 2026-01-15

### Added

- **ASGI middleware** — pure `receive`/`send` wrapping (no `BaseHTTPMiddleware`)
- **ConsoleBackend** with Rich-powered terminal output
- **SQLiteBackend** with batched background writer thread and WAL mode
- **MemoryBackend** for testing and debugging
- **Compact formatter** — Morgan-style one-liner with color-coded status/method
- **Verbose formatter** — vertical stacked panels with syntax-highlighted bodies
- **JSON formatter** — JSON-Lines output for non-TTY environments
- **Pipeline** with filter (paths/methods/status/sampling), sanitize (redact), and dispatch stages
- **Header and body sanitization** with glob matching and recursive JSON walks
- Configurable via `ReqlogConfig` dataclass with `REQLOG_*` environment variable overrides
- Auto-format detection based on environment (AI tools, TTY, fallback)
