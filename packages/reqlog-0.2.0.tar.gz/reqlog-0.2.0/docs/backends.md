# Backends Guide

Backends are the output layer of reqlog. Each backend receives sanitized `Transaction` objects from the pipeline and writes them to a destination -- the terminal, a file, a database, or an in-memory buffer.

## The Backend Protocol

Any object that implements an `async write()` method is a valid backend:

```python
from reqlog.core.models import Transaction

class MyBackend:
    async def write(self, transaction: Transaction) -> None:
        ...
```

The protocol is formally defined as a `runtime_checkable` Protocol in `reqlog.backends.protocols`:

```python
@runtime_checkable
class Backend(Protocol):
    async def write(self, transaction: Transaction) -> None: ...
```

Backends that hold resources (file handles, database connections, threads) should also implement the `Closeable` protocol:

```python
@runtime_checkable
class Closeable(Protocol):
    async def close(self) -> None: ...
```


## ConsoleBackend

Writes formatted output to a Rich Console (stderr by default). This is the default backend when no backends are explicitly configured.

```python
from reqlog import ReqlogMiddleware, ConsoleBackend

app.add_middleware(
    ReqlogMiddleware,
    backends=[ConsoleBackend(format="panel")],
)
```

**Constructor parameters:**

| Parameter          | Type             | Default     | Description                                      |
|--------------------|------------------|-------------|--------------------------------------------------|
| `format`           | `str`            | `"compact"` | Output format: `compact`, `verbose`, `panel`, `ai`, `json`. |
| `max_body_display` | `int`            | `2000`      | Maximum bytes of body content to render.         |
| `console`          | `Console | None` | `None`      | Custom Rich Console instance. Creates `Console(stderr=True)` if not provided. |

**Format dispatch:**

The backend uses a match statement to select the appropriate formatter:

- `"compact"` -- Morgan-style one-liner with color-coded status and method (see [Formatters](formatters.md))
- `"verbose"` -- Vertical stacked panels with syntax-highlighted bodies
- `"panel"` -- Two-column Request/Response layout with aligned rows
- `"ai"` -- Token-efficient plain text for LLM tool contexts
- `"json"` -- JSON-Lines output, one object per request

See [Formatters](formatters.md) for detailed descriptions of each format.


## SQLiteBackend

Persistent storage backend using SQLite. Designed for production use with non-blocking writes and automatic pruning.

```python
from reqlog import ReqlogMiddleware, SQLiteBackend, ConsoleBackend

sqlite = SQLiteBackend(db_path="reqlog.db", max_rows=50_000)

app.add_middleware(
    ReqlogMiddleware,
    capture_body=True,
    backends=[ConsoleBackend(format="compact"), sqlite],
)
```

**Constructor parameters:**

| Parameter    | Type   | Default      | Description                                          |
|--------------|--------|--------------|------------------------------------------------------|
| `db_path`    | `str`  | `"reqlog.db"` | Path to the SQLite database file.                    |
| `table_name` | `str`  | `"requests"` | Name of the database table.                          |
| `max_rows`   | `int`  | `100_000`    | Maximum number of rows before auto-pruning.          |
| `wal_mode`   | `bool` | `True`       | Enable WAL journal mode for concurrent read/write.   |

**How the writer thread works:**

`SQLiteBackend` uses a background daemon thread (`_WriterThread`) for writes:

1. `write()` enqueues the transaction onto a thread-safe `queue.Queue`.
2. The writer thread drains up to 50 items (configurable `batch_size`) per cycle.
3. Rows are inserted via `executemany()` for efficiency.
4. The thread flushes every 100ms (configurable `flush_interval`).
5. Every 1000 inserts, the writer checks the row count and deletes the oldest rows if `max_rows` is exceeded.

This design means `write()` never blocks the async event loop.

**Querying stored data:**

The backend exposes a read interface via `SQLiteReader`:

```python
# Get the 20 most recent requests
rows = sqlite.get_recent(limit=20)

# Filter by status code
rows = sqlite.get_recent(status_filter=500, limit=10)

# Filter by path substring
rows = sqlite.get_recent(path_filter="/api/users")

# Filter by method
rows = sqlite.get_recent(method_filter="POST")

# Filter by minimum duration
rows = sqlite.get_recent(min_duration=200.0)

# Get requests since a Unix timestamp
rows = sqlite.get_since(timestamp=1707900000.0)

# Look up a single request by ID
row = sqlite.get_by_id("a1b2c3d4e5f6")

# Get aggregated statistics for the last 60 minutes
stats = sqlite.get_stats(minutes=60)
# stats.total_requests, stats.p95_duration_ms, stats.slowest_endpoints, etc.

# Full-text search across path, bodies, and headers
rows = sqlite.search_requests(query="user not found", status_class="4xx", limit=20)

# Get aggregated error summary for the last 5 minutes
summary = sqlite.get_error_summary(minutes=5)
# summary["total_errors"], summary["error_rate"], summary["by_status"]

# Get per-endpoint performance stats
endpoints = sqlite.get_endpoint_stats(path_pattern="/api/users", minutes=60)
# Each entry: path, count, avg/p50/p95/p99 durations, status breakdown

# Total row count
count = sqlite.count()
```

**Using with the CLI:**

The `reqlog tail`, `reqlog stats`, `reqlog export`, and `reqlog mcp` commands all read from the SQLite database file. Point them at the same `db_path` your application writes to. The MCP server uses `SQLiteReader` to serve query results to AI coding agents. See [CLI Reference](cli.md) for usage details.

**Shutdown:**

Call `close()` to flush pending writes and stop the writer thread:

```python
await sqlite.close()
```


## FileBackend

Writes request logs to a file with optional log rotation. Useful for shipping logs to external systems or archival.

```python
from reqlog import ReqlogMiddleware
from reqlog.backends.file import FileBackend

file_backend = FileBackend(
    path="requests.jsonl",
    format="json",
    max_size_mb=50,
    max_files=10,
)

app.add_middleware(ReqlogMiddleware, backends=[file_backend])
```

**Constructor parameters:**

| Parameter     | Type   | Default          | Description                                          |
|---------------|--------|------------------|------------------------------------------------------|
| `path`        | `str`  | `"reqlog.jsonl"` | Output file path.                                    |
| `format`      | `str`  | `"json"`         | Output format: `json`, `text`, or `ai`.              |
| `rotate`      | `bool` | `True`           | Enable log rotation via `RotatingFileHandler`.       |
| `max_size_mb` | `int`  | `100`            | Maximum file size in MB before rotation.             |
| `max_files`   | `int`  | `5`              | Number of backup files to keep.                      |

**Output formats:**

- `"json"` -- JSON-Lines format, one JSON object per line. Ideal for machine parsing.
- `"text"` -- Plain text one-liner: `2026-02-14T14:23:46 POST /api/users 201 145ms`
- `"ai"` -- Token-efficient format matching the AI formatter output.

**Rotation:**

When `rotate=True` (default), `FileBackend` uses Python's `RotatingFileHandler`. When the log file exceeds `max_size_mb`, it is renamed with a numeric suffix (`.1`, `.2`, etc.) and a new file is created. The `max_files` parameter controls how many old files are kept.

**Shutdown:**

Call `close()` to flush and release the file handle:

```python
await file_backend.close()
```


## MemoryBackend

An in-memory ring buffer backend. Primarily useful for testing and debugging -- it stores transactions in memory and provides a simple query interface.

```python
from reqlog import MemoryBackend

memory = MemoryBackend(max_size=500)
```

**Constructor parameters:**

| Parameter  | Type  | Default | Description                                      |
|------------|-------|---------|--------------------------------------------------|
| `max_size` | `int` | `1000`  | Maximum number of transactions to retain.        |

**API:**

```python
# Access all stored transactions
all_txns = memory.transactions

# Get the N most recent transactions
recent = memory.get_recent(10)

# Clear the buffer
memory.clear()

# Check the current count
count = len(memory)
```

The underlying `BoundedRingBuffer` is thread-safe and automatically evicts the oldest entries when `max_size` is exceeded.

**Testing example:**

```python
import pytest
from reqlog import ReqlogMiddleware, ReqlogConfig, MemoryBackend

@pytest.fixture
def memory_backend():
    return MemoryBackend(max_size=100)

@pytest.fixture
def app(memory_backend):
    config = ReqlogConfig(capture_body=True, capture_headers=True)
    return ReqlogMiddleware(your_app, config=config, backends=[memory_backend])

async def test_login_endpoint(app, memory_backend):
    # ... make request to app ...
    assert len(memory_backend) == 1
    txn = memory_backend.transactions[0]
    assert txn.response.status_code == 200
```


## Custom Backends

Implementing a custom backend requires only an `async write()` method:

```python
from reqlog.core.models import Transaction

class WebhookBackend:
    def __init__(self, url: str):
        self.url = url

    async def write(self, transaction: Transaction) -> None:
        import httpx
        async with httpx.AsyncClient() as client:
            await client.post(self.url, json={
                "method": transaction.request.method,
                "path": transaction.request.path,
                "status": transaction.response.status_code,
                "duration_ms": transaction.duration_ms,
            })
```

Register it like any other backend:

```python
from reqlog import ReqlogMiddleware

webhook = WebhookBackend(url="https://hooks.example.com/reqlog")

app.add_middleware(ReqlogMiddleware, backends=[webhook])
```

Backend errors are automatically isolated by the pipeline -- if your `write()` raises an exception, it is logged but does not affect other backends or the HTTP response.


## Multiple Backends

The pipeline fans out to all configured backends concurrently using `asyncio.gather()`. This means you can write to multiple destinations simultaneously:

```python
from reqlog import ReqlogMiddleware, ConsoleBackend, SQLiteBackend
from reqlog.backends.file import FileBackend

app.add_middleware(
    ReqlogMiddleware,
    capture_body=True,
    backends=[
        ConsoleBackend(format="compact"),
        SQLiteBackend(db_path="reqlog.db"),
        FileBackend(path="requests.jsonl", format="json"),
    ],
)
```

Each backend receives the same sanitized `Transaction` object. If one backend fails, the others continue unaffected -- errors are caught by the pipeline's `_safe_write()` wrapper and logged via Python's standard `logging` module.
