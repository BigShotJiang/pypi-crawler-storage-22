# Configuration Reference

reqlog is configured through the `ReqlogConfig` dataclass. Configuration can be set programmatically, via environment variables, or through Django's `settings.REQLOG` dictionary.

## ReqlogConfig Fields

### Capture Settings

| Field                   | Type         | Default                                                                 | Description                                                        |
|-------------------------|--------------|-------------------------------------------------------------------------|--------------------------------------------------------------------|
| `capture_body`          | `bool`       | `False`                                                                 | Capture request and response bodies. Off by default for performance.|
| `capture_headers`       | `bool`       | `False`                                                                 | Capture request and response headers.                              |
| `max_body_size`         | `int`        | `64000`                                                                 | Maximum body size in bytes to capture. Larger bodies are truncated. |
| `capture_content_types` | `list[str]`  | `["application/json", "application/xml", "text/*", "application/x-www-form-urlencoded"]` | Content types eligible for body capture (glob patterns supported).  |

### Output Settings

| Field      | Type             | Default | Description                                                                                                   |
|------------|------------------|---------|---------------------------------------------------------------------------------------------------------------|
| `format`   | `str \| None`    | `None`  | Output format: `compact`, `verbose`, `panel`, `ai`, `json`. `None` triggers auto-detection (see [Formatters](formatters.md)). |
| `backends` | `list[Any]`      | `[]`    | List of backend instances. Empty list triggers default `ConsoleBackend` creation.                              |

### Filtering

| Field                  | Type              | Default                                                              | Description                                                    |
|------------------------|-------------------|----------------------------------------------------------------------|----------------------------------------------------------------|
| `exclude_paths`        | `list[str]`       | `["/health", "/healthz", "/ready", "/readyz", "/metrics", "/favicon.ico"]` | Paths to exclude from logging. Supports glob patterns via `fnmatch`. |
| `exclude_methods`      | `list[str]`       | `["OPTIONS"]`                                                        | HTTP methods to exclude.                                       |
| `exclude_status_codes` | `list[int]`       | `[]`                                                                 | Status codes to exclude (exact match).                         |
| `include_paths`        | `list[str] \| None` | `None`                                                             | If set, only these paths are logged (allowlist mode). Supports glob patterns. |

When `include_paths` is set, it takes precedence -- only matching paths are logged, regardless of `exclude_paths`.

### Sampling

| Field         | Type    | Default | Description                                                      |
|---------------|---------|---------|------------------------------------------------------------------|
| `sample_rate` | `float` | `1.0`   | Fraction of requests to log (0.0 to 1.0). `0.5` logs ~50% of requests. |

### Security

| Field                  | Type        | Default                                                                                               | Description                                                  |
|------------------------|-------------|-------------------------------------------------------------------------------------------------------|--------------------------------------------------------------|
| `sanitize_headers`     | `list[str]` | `["Authorization", "Cookie", "Set-Cookie", "X-API-Key", "X-Auth-Token"]`                              | Header names to redact. Supports glob patterns (case-insensitive). |
| `sanitize_body_fields` | `list[str]` | `["password", "passwd", "secret", "token", "access_token", "refresh_token", "ssn", "credit_card", "card_number"]` | JSON body field names to redact. Uses substring matching.    |

**Header redaction** uses case-insensitive glob matching via `fnmatch`. For example, `"X-*-Token"` would match `X-Auth-Token`, `X-CSRF-Token`, etc. Matched header values are replaced with `[REDACTED]`.

**Body field redaction** uses case-insensitive substring matching and walks JSON structures recursively. The pattern `"password"` matches field names like `password`, `user_password`, `passwordHash`, and `old_password`. Nested objects and arrays are traversed automatically.

### Performance

| Field            | Type   | Default | Description                                |
|------------------|--------|---------|--------------------------------------------|
| `async_dispatch` | `bool` | `True`  | Use async dispatch to backends.            |

### Request ID

| Field                | Type   | Default          | Description                                               |
|----------------------|--------|------------------|-----------------------------------------------------------|
| `generate_request_id`| `bool` | `True`           | Auto-generate a request ID if none is present in headers. |
| `request_id_header`  | `str`  | `"X-Request-ID"` | Header name to read/write the request ID.                 |

When `generate_request_id` is `True` and no matching header is found on the incoming request, a 12-character hex ID is generated from `uuid.uuid4()`.


## Environment Variable Overrides

All primary configuration fields can be overridden via environment variables with the `REQLOG_` prefix. Environment variables are read during `ReqlogConfig.__post_init__()` and take precedence over constructor arguments.

| Environment Variable        | Config Field         | Type Coercion                                    |
|-----------------------------|----------------------|--------------------------------------------------|
| `REQLOG_CAPTURE_BODY`       | `capture_body`       | `"true"`, `"1"`, `"yes"` are truthy             |
| `REQLOG_CAPTURE_HEADERS`    | `capture_headers`    | `"true"`, `"1"`, `"yes"` are truthy             |
| `REQLOG_FORMAT`             | `format`             | String value used directly                       |
| `REQLOG_SAMPLE_RATE`        | `sample_rate`        | Parsed as `float`                                |
| `REQLOG_MAX_BODY_SIZE`      | `max_body_size`      | Parsed as `int`                                  |
| `REQLOG_EXCLUDE_PATHS`      | `exclude_paths`      | Comma-separated list (e.g., `"/health,/ready"`)  |
| `REQLOG_EXCLUDE_METHODS`    | `exclude_methods`    | Comma-separated list (e.g., `"OPTIONS,HEAD"`)    |
| `REQLOG_REQUEST_ID_HEADER`  | `request_id_header`  | String value used directly                       |

**Example:**

```bash
REQLOG_CAPTURE_BODY=true REQLOG_FORMAT=verbose uvicorn myapp:app
```


## Django Settings

For Django projects, configuration is read from the `REQLOG` dictionary in `settings.py`. Keys are uppercase versions of the config field names:

```python
# settings.py

MIDDLEWARE = [
    "reqlog.middleware.django.ReqlogMiddleware",
    # ... other middleware ...
]

REQLOG = {
    "CAPTURE_BODY": True,
    "CAPTURE_HEADERS": True,
    "FORMAT": "compact",
    "EXCLUDE_PATHS": ["/health", "/static/*"],
    "EXCLUDE_METHODS": ["OPTIONS", "HEAD"],
    "SAMPLE_RATE": 0.5,
    "SANITIZE_HEADERS": ["Authorization", "Cookie"],
    "SANITIZE_BODY_FIELDS": ["password", "token"],
    "MAX_BODY_SIZE": 32_000,
}
```

**Supported Django settings keys:**

| Django Key             | Maps to Config Field     |
|------------------------|--------------------------|
| `CAPTURE_BODY`         | `capture_body`           |
| `CAPTURE_HEADERS`      | `capture_headers`        |
| `FORMAT`               | `format`                 |
| `EXCLUDE_PATHS`        | `exclude_paths`          |
| `EXCLUDE_METHODS`      | `exclude_methods`        |
| `SAMPLE_RATE`          | `sample_rate`            |
| `SANITIZE_HEADERS`     | `sanitize_headers`       |
| `SANITIZE_BODY_FIELDS` | `sanitize_body_fields`   |
| `MAX_BODY_SIZE`        | `max_body_size`          |

Environment variable overrides still apply on top of Django settings.


## Common Configuration Examples

**Minimal setup (defaults):**

```python
from reqlog import ReqlogMiddleware

app = ReqlogMiddleware(app)
# Logs all requests in auto-detected format, no body capture
```

**Development with full capture:**

```python
from reqlog import ReqlogMiddleware

app = ReqlogMiddleware(
    app,
    capture_body=True,
    capture_headers=True,
    format="verbose",
)
```

**Production with SQLite persistence and sampling:**

```python
from reqlog import ReqlogMiddleware, ReqlogConfig, ConsoleBackend, SQLiteBackend

config = ReqlogConfig(
    capture_body=True,
    sample_rate=0.1,             # Log 10% of requests
    exclude_paths=["/health", "/metrics", "/static/*"],
    max_body_size=32_000,        # Limit body capture to 32KB
)

app = ReqlogMiddleware(
    app,
    config=config,
    backends=[
        ConsoleBackend(format="compact"),
        SQLiteBackend(db_path="/var/log/app/reqlog.db", max_rows=500_000),
    ],
)
```

**API-only logging with strict allowlist:**

```python
from reqlog import ReqlogMiddleware, ReqlogConfig

config = ReqlogConfig(
    include_paths=["/api/*"],     # Only log API routes
    exclude_methods=["OPTIONS", "HEAD"],
    exclude_status_codes=[304],   # Skip Not Modified responses
)

app = ReqlogMiddleware(app, config=config)
```

**Custom sanitization:**

```python
from reqlog import ReqlogMiddleware, ReqlogConfig

config = ReqlogConfig(
    capture_body=True,
    capture_headers=True,
    sanitize_headers=["Authorization", "Cookie", "X-*-Token", "X-*-Key"],
    sanitize_body_fields=["password", "secret", "ssn", "credit_card", "cvv", "pin"],
)

app = ReqlogMiddleware(app, config=config)
```
