# Output Formats Guide

reqlog provides five output formats, each designed for a different use case. Formats are selected via the `format` parameter on `ConsoleBackend`, the `ReqlogConfig.format` field, or through automatic detection.

## Format Overview

| Format    | Best for                           | Output style                                |
|-----------|------------------------------------|---------------------------------------------|
| `compact` | Development, live tailing          | Color-coded one-liner per request           |
| `verbose` | Debugging with full body content   | Vertical stacked panels, syntax-highlighted |
| `panel`   | Side-by-side request/response view | Two-column layout with aligned rows         |
| `ai`      | LLM tool contexts, piping to AI    | Token-efficient plain text                  |
| `json`    | Machine parsing, log aggregation   | JSON-Lines, one object per line             |


## compact

A Morgan-style one-liner that fits one HTTP transaction per terminal line. This is the default format when stderr is a TTY.

```
  * GET     /api/users                                     200    12ms   14:23:46
  * POST    /api/users                                     201    45ms   14:23:47
  * GET     /api/missing                                   404     3ms   14:23:48
  x POST    /api/crash                                     500   312ms   14:23:49
```

**Color coding:**

Methods use a GitHub Dark / VS Code-inspired palette:

| Method    | Color   |
|-----------|---------|
| GET       | #58a6ff (blue)    |
| POST      | #3fb950 (green)   |
| PUT/PATCH | #d29922 (yellow)  |
| DELETE    | #f85149 (red)     |
| OPTIONS   | #8b949e (gray)    |
| HEAD      | #8b949e (gray)    |

Status codes are grouped by class:

| Class | Color   | Glyph |
|-------|---------|-------|
| 2xx   | #3fb950 (green)  | filled circle    |
| 3xx   | #58a6ff (blue)   | filled circle    |
| 4xx   | #d29922 (yellow) | filled circle    |
| 5xx   | #f85149 (red)    | x mark |

Timing colors indicate performance at a glance:

| Duration   | Color  |
|------------|--------|
| < 100ms    | green  |
| 100-500ms  | yellow |
| > 500ms    | red    |

**Path truncation:** Paths longer than 45 characters are truncated with a trailing ellipsis to keep lines aligned.


## verbose

A vertical panel layout that shows the full request and response details in stacked sections. Best used with `capture_body=True` and `capture_headers=True`.

The outer panel title shows the HTTP method and path. Inside:

1. **Status bar** -- Status code with text description on the left, duration and timestamp on the right.
2. **Request section** -- Horizontal rule labeled "Request", followed by a headers table and a body sub-panel with syntax highlighting.
3. **Response section** -- Same layout as the request section.
4. **Metadata footer** -- Client IP, truncated User-Agent, and request ID in dim text.

Body content is syntax-highlighted based on Content-Type (JSON, XML, or plain text). JSON bodies are pretty-printed with `indent=2`. Bodies exceeding `max_body_display` bytes (default 2000) are truncated with an ellipsis.

The outer panel border color matches the status class (green for 2xx, red for 5xx, etc.).

```python
from reqlog import ReqlogMiddleware, ConsoleBackend

app = ReqlogMiddleware(
    app,
    capture_body=True,
    capture_headers=True,
    backends=[ConsoleBackend(format="verbose", max_body_display=4000)],
)
```


## panel

A Claude Code-inspired two-column layout that shows request and response side by side. This is the most visually rich format and works best in wide terminals.

**Layout structure:**

```
+-- POST /api/users -----------------------------------------------+
| * 201 Created                                       45ms  14:23  |
|                                                                   |
|  Request              |  Response                                 |
|  content-type  app..  |  content-type  app..                      |
|  accept        app..  |  x-request-id  a1b2..                     |
| ---------------------+--------------------------------------------+
|  +-- json * 77 B --+  |  +-- json * 142 B --+                    |
|  | { "name": ... } |  |  | { "id": 42, .. } |                    |
|  +-----------------+  |  +-------------------+                    |
|                                                                   |
|  127.0.0.1 * curl/8.0 * a1b2c3d4e5f6                             |
+------------------------------------------------------------------+
```

**Key features:**

- **Aligned rows**: Headers appear at the same vertical level on both sides; bodies appear at the same level below.
- **Custom Box definitions**: `PANEL_GRID` renders both vertical dividers between columns and horizontal rules between rows. `COLUMN_DIVIDER` renders only vertical dividers when there is a single content row.
- **Adaptive JSON rendering**: The body renderer tries `indent=2` first. If the result exceeds `max_body_lines` (default 20), it falls back to `indent=1`. If still too tall, it truncates and shows a subtitle like "...5 lines json * 1.2 KB".
- **Height matching**: The shorter body panel is padded with empty lines to match the taller one, keeping the layout balanced.

```python
from reqlog import ReqlogMiddleware, ConsoleBackend

app = ReqlogMiddleware(
    app,
    capture_body=True,
    capture_headers=True,
    backends=[ConsoleBackend(format="panel")],
)
```


## ai

A token-efficient plain-text format designed for consumption by large language models. Automatically selected when `CLAUDE_CODE`, `CURSOR_SESSION`, or `AIDER` environment variables are detected.

```
[14:23:46] POST /api/users -> 201 (45ms)
  Req: {"name":"Alice","email":"alice@example.com"}
  Res: {"id":42,"name":"Alice","created_at":"2026-02-14T14:23:46Z"}
---
```

**Characteristics:**

- No color codes or Rich markup -- pure text.
- JSON bodies are re-serialized with compact separators (`separators=(",", ":")`) to minimize token usage.
- Bodies exceeding `max_body_length` (default 1000 characters) are truncated with an ellipsis.
- Binary bodies are represented as `<binary N bytes>`.
- Each entry ends with a `---` separator.

This format is used by both `ConsoleBackend(format="ai")` and `FileBackend(format="ai")`.

The AI formatter and the MCP server's output formatters share common plain-text primitives from `formatters/text_format.py` (`format_duration`, `truncate_path`, `compact_body`, `format_compact_line`, `format_detail_body`).


## json

JSON-Lines output where each transaction is a single JSON object on one line. Suitable for log aggregation pipelines, structured logging, and machine parsing.

```json
{"timestamp": "2026-02-14T14:23:46.123456+00:00", "request_id": "a1b2c3d4e5f6", "method": "POST", "path": "/api/users", "query_string": null, "status_code": 201, "duration_ms": 45.67, "client_ip": "127.0.0.1", "user_agent": "curl/8.0"}
```

**Fields always included:**

`timestamp`, `request_id`, `method`, `path`, `query_string`, `status_code`, `duration_ms`, `client_ip`, `user_agent`

**Fields included when captured:**

`request_headers`, `request_body`, `response_headers`, `response_body`

Binary bodies that cannot be decoded as UTF-8 are represented as `<binary N bytes>`.


## Auto-Detection

When no format is explicitly configured, `ReqlogConfig.resolve_format()` selects one automatically using this priority:

1. **Explicit config**: `ReqlogConfig(format="panel")` or `ReqlogMiddleware(app, format="panel")`
2. **Environment variable**: `REQLOG_FORMAT=verbose`
3. **AI tool detection**: If `CLAUDE_CODE`, `CURSOR_SESSION`, or `AIDER` environment variables are set, returns `"ai"`
4. **TTY check**: If `sys.stderr.isatty()` is true, returns `"compact"`
5. **Fallback**: Returns `"json"` (non-interactive environments, CI, pipes)

This means reqlog does the right thing out of the box -- colored output in terminals, structured JSON in pipelines, and token-efficient text in AI coding tools.
