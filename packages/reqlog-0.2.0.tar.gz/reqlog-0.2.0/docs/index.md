# reqlog

**HTTP logging middleware for Python — with an MCP server that gives your AI coding agent a Network Tab.**

[![PyPI version](https://img.shields.io/pypi/v/reqlog)](https://pypi.org/project/reqlog/)
[![Python 3.10+](https://img.shields.io/pypi/pyversions/reqlog)](https://pypi.org/project/reqlog/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

Drop-in middleware for **FastAPI**, **Django**, and any ASGI framework.
Captures requests and responses, formats them with [Rich](https://github.com/Textualize/rich), persists to SQLite, and exposes an [MCP server](https://modelcontextprotocol.io/) so AI agents can query your traffic.

## Quick Start

```bash
pip install reqlog
```

### FastAPI

```python
from fastapi import FastAPI
from reqlog import ReqlogMiddleware

app = FastAPI()
app.add_middleware(ReqlogMiddleware)
```

### Django

```python
# settings.py
MIDDLEWARE = [
    "reqlog.middleware.django.ReqlogMiddleware",
    # ...
]

REQLOG = {
    "CAPTURE_BODY": True,
    "FORMAT": "compact",
}
```

That's it — requests are logged to stderr with color-coded output:

```
  ● GET     /api/users                                     200     8ms   14:23:46
  ● POST    /api/users                                     201   145ms   14:23:47
  ✗ GET     /api/crash                                     500    89ms   14:23:49
```

## Give Your AI Agent a Network Tab

Persist requests to SQLite and point the MCP server at it — your AI agent can query traffic directly instead of parsing terminal noise.

```python
from reqlog import ReqlogMiddleware, ConsoleBackend, SQLiteBackend

app.add_middleware(
    ReqlogMiddleware,
    capture_body=True,
    backends=[ConsoleBackend(), SQLiteBackend("reqlog.db")],
)
```

Then add to your editor's MCP config (`.mcp.json`):

```json
{
  "mcpServers": {
    "reqlog": {
      "command": "uvx",
      "args": ["reqlog", "mcp", "--db", "reqlog.db"]
    }
  }
}
```

See [Backends](backends.md) for all storage options and [CLI](cli.md) for querying logs from the terminal.

## Features

- **5 output formats** — compact, verbose, panel, ai, json ([details](formatters.md))
- **Auto-format detection** — picks the right format for your environment
- **Multiple backends** — Console, SQLite, File, Memory ([details](backends.md))
- **MCP server** — 5 query tools for AI agents
- **Built-in sanitization** — redacts Authorization headers, passwords, tokens
- **CLI** — tail, stats, export commands ([details](cli.md))
- **Zero-config defaults** — works out of the box, customize as needed ([details](configuration.md))

## Installation

```bash
pip install reqlog          # Core (FastAPI/ASGI + Django)
pip install reqlog[mcp]     # With MCP server support
```
