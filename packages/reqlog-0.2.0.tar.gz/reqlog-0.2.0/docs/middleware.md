# Middleware Integration

reqlog provides middleware for two Python web framework ecosystems: ASGI (FastAPI, Starlette) and Django. Both middleware implementations build `Transaction` objects from the framework's request/response lifecycle and dispatch them through the pipeline.

## FastAPI / Starlette (ASGI)

### Setup

The simplest way to add reqlog to a FastAPI application is with `app.add_middleware()`:

```python
from fastapi import FastAPI
from reqlog import ReqlogMiddleware

app = FastAPI()
app.add_middleware(ReqlogMiddleware)
```

All constructor parameters can be passed as keyword arguments to `add_middleware()`. FastAPI passes them through to the `ReqlogMiddleware` constructor, with `app` injected automatically.

### Convenience keyword arguments

For common setups, pass options directly without creating a config object:

```python
app.add_middleware(
    ReqlogMiddleware,
    capture_body=True,
    capture_headers=True,
    format="panel",
    exclude_paths=["/health", "/metrics"],
)
```

### Multiple backends

Pass a `backends=` list to log to multiple destinations simultaneously:

```python
from reqlog import ReqlogMiddleware, ConsoleBackend, SQLiteBackend
from reqlog.backends.file import FileBackend

app.add_middleware(
    ReqlogMiddleware,
    capture_body=True,
    backends=[
        ConsoleBackend(format="compact"),
        SQLiteBackend(db_path="reqlog.db"),
        FileBackend(path="requests.jsonl", format="json"),
    ],
)
```

When `backends=` is not provided, reqlog creates a single `ConsoleBackend` using the auto-detected format.

### Full configuration object

For complex setups, create a `ReqlogConfig` and pass it via `config=`:

```python
from reqlog import ReqlogMiddleware, ReqlogConfig, ConsoleBackend, SQLiteBackend

config = ReqlogConfig(
    capture_body=True,
    capture_headers=True,
    exclude_paths=["/health", "/metrics"],
    sanitize_headers=["Authorization", "Cookie"],
    sample_rate=0.5,
)

app.add_middleware(
    ReqlogMiddleware,
    config=config,
    backends=[
        ConsoleBackend(format="compact"),
        SQLiteBackend(db_path="reqlog.db"),
    ],
)
```

### Raw ASGI wrapping

You can also use the middleware as a direct ASGI wrapper. This works with any ASGI framework, not just FastAPI:

```python
app = ReqlogMiddleware(app, capture_body=True, format="panel")
```

### Constructor Parameters

| Parameter         | Type                  | Default | Description                                      |
|-------------------|-----------------------|---------|--------------------------------------------------|
| `app`             | ASGI callable         | (required) | The ASGI application to wrap. Injected automatically by `add_middleware()`. |
| `config`          | `ReqlogConfig \| None` | `None`  | Full configuration object. Creates a default if not provided. |
| `capture_body`    | `bool \| None`        | `None`  | Override `config.capture_body`.                  |
| `capture_headers` | `bool \| None`        | `None`  | Override `config.capture_headers`.               |
| `format`          | `str \| None`         | `None`  | Override `config.format`.                        |
| `exclude_paths`   | `list[str] \| None`   | `None`  | Override `config.exclude_paths`.                 |
| `backends`        | `list[Any] \| None`   | `None`  | Override `config.backends`. See [Backends](backends.md). |

Keyword arguments take precedence over the `config` object, which in turn is overridden by environment variables. See [Configuration](configuration.md) for the full reference.

### Why Pure ASGI Wrapping

The ASGI middleware does **not** use Starlette's `BaseHTTPMiddleware`. Instead, it wraps the raw `receive` and `send` callables directly:

```python
async def __call__(self, scope, receive, send):
    if scope["type"] != "http":
        await self.app(scope, receive, send)
        return

    # Wrap receive/send to intercept bodies
    await self.app(scope, receive_wrapper, send_wrapper)
```

This approach avoids known issues with `BaseHTTPMiddleware`:

- **Streaming compatibility**: `BaseHTTPMiddleware` buffers the entire response body before sending it, breaking streaming responses (SSE, large file downloads). Pure ASGI wrapping passes each chunk through immediately.
- **Performance**: No unnecessary buffering or copying of response data when body capture is disabled.
- **Body capture is lazy**: The middleware only intercepts body data when `capture_body=True`. Otherwise, the `receive` and `send` callables pass through unmodified.

### Body Capture

When `capture_body=True`, the middleware intercepts `http.request` messages (for request bodies) and `http.response.body` messages (for response bodies). Body chunks are accumulated up to `max_body_size` bytes. Chunks arriving after the limit are silently dropped.

Non-HTTP scope types (WebSocket, lifespan) are passed through without any wrapping.

### Request ID

The middleware reads the `X-Request-ID` header (configurable via `request_id_header`) from the incoming request. If no header is found and `generate_request_id=True`, a 12-character hex ID is generated from `uuid.uuid4()`.


## Django

### Setup

Add the middleware to your Django `MIDDLEWARE` list in `settings.py`:

```python
# settings.py

MIDDLEWARE = [
    "reqlog.middleware.django.ReqlogMiddleware",
    "django.middleware.security.SecurityMiddleware",
    # ... other middleware ...
]

REQLOG = {
    "CAPTURE_BODY": True,
    "CAPTURE_HEADERS": True,
    "FORMAT": "compact",
    "EXCLUDE_PATHS": ["/admin/jsi18n/", "/static/*"],
}
```

Place reqlog first (or near the top) in the middleware list so it wraps the entire request lifecycle.

### Sync/Async Auto-Detection

The Django middleware automatically detects whether `get_response` is a coroutine function:

```python
import asyncio

self._is_async = asyncio.iscoroutinefunction(get_response)
```

- **Async mode** (Django 4.1+ with ASGI): Calls `await get_response(request)` and `await pipeline.process(transaction)` directly.
- **Sync mode** (traditional WSGI): Calls `get_response(request)` synchronously. Pipeline processing is dispatched via `asyncio.run()` or `loop.create_task()` if an event loop is already running.

This means reqlog works transparently with both WSGI and ASGI Django deployments.

### Configuration via settings.REQLOG

The Django middleware reads configuration from `settings.REQLOG`, a dictionary in your Django settings module. See [Configuration](configuration.md) for the full mapping of keys to `ReqlogConfig` fields.

### Body Capture

The Django middleware reads `request.body` (which Django buffers internally) and `response.content`. Both are truncated to `max_body_size` if they exceed the limit. Header extraction reads from `request.META` (prefixed with `HTTP_`) and `response.headers`.


## Pipeline Flow

Both middleware implementations build a `Transaction` object and pass it to the same pipeline. The pipeline processes each transaction through three stages:

### 1. Filter

`Pipeline.should_log(transaction)` checks whether the request should be logged at all:

- **Sampling**: If `sample_rate < 1.0`, a random check determines whether to proceed.
- **Method exclusion**: Requests with methods in `exclude_methods` are dropped.
- **Path exclusion**: Requests with paths matching any pattern in `exclude_paths` (via `fnmatch`) are dropped.
- **Path inclusion**: If `include_paths` is set, only requests matching those patterns are kept.
- **Status code exclusion**: Responses with status codes in `exclude_status_codes` are dropped.

### 2. Sanitize

`Pipeline.sanitize(transaction)` returns a new `Transaction` with sensitive data redacted:

- **Header redaction**: Headers matching `sanitize_headers` patterns (case-insensitive glob) have their values replaced with `[REDACTED]`.
- **Body field redaction**: JSON body fields matching `sanitize_body_fields` patterns (case-insensitive substring match) are recursively replaced with `[REDACTED]`. Non-JSON bodies pass through unchanged.

Sanitization always runs, even when the header and field lists are empty (it becomes a no-op pass-through).

### 3. Dispatch

`Pipeline._dispatch(transaction)` fans out the sanitized transaction to all configured backends concurrently using `asyncio.gather()`. Each backend call is wrapped in `_safe_write()`, which catches and logs any exceptions without propagating them to the middleware or the HTTP response.

```
Middleware
    |
    v
Pipeline.process(transaction)
    |-- should_log()?  --no--> return (skip)
    |-- yes
    |-- sanitize()  --> new Transaction with redacted data
    |-- _dispatch() --> asyncio.gather(backend1.write(), backend2.write(), ...)
```

### The Transaction Model

Both middleware implementations construct the same `Transaction` dataclass:

```python
@dataclass(frozen=True, slots=True)
class Transaction:
    request: Request       # method, path, query_string, headers, body, client_ip, user_agent
    response: Response     # status_code, headers, body, content_type
    duration_ms: float     # Wall-clock time for the request
    timestamp: datetime    # UTC timestamp
    request_id: str        # From header or auto-generated
```

`Transaction`, `Request`, and `Response` are frozen (immutable) dataclasses with `slots=True` for memory efficiency. The `status_class` property on `Transaction` returns the status bucket (`"2xx"`, `"3xx"`, `"4xx"`, `"5xx"`) used by formatters for color selection.
