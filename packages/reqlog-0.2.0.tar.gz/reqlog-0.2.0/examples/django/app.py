"""Django demo with reqlog middleware — no external files needed.

Setup:  cd examples/django && uv sync
Run:    uv run python app.py
        uv run python app.py --sqlite   # also persist to SQLite
Then:   curl localhost:8000/users
        curl -X POST localhost:8000/users -H "Content-Type: application/json" -d '{"name":"Charlie","password":"secret"}'
        curl localhost:8000/users/999
        curl -X DELETE localhost:8000/users/42/delete
        curl localhost:8000/crash

With --sqlite, logs are persisted to .reqlog/reqlog.db so you can use:
      uv run reqlog tail
      uv run reqlog stats
      uv run reqlog export --format json
"""

import json
import sys

import django
from django.conf import settings

# ── Parse --sqlite flag before Django setup ──────────────────────────────

use_sqlite = "--sqlite" in sys.argv
if use_sqlite:
    sys.argv.remove("--sqlite")

# ── Build backend list ───────────────────────────────────────────────────

from reqlog.backends.console import ConsoleBackend  # noqa: E402

backends = [ConsoleBackend(format="panel")]

if use_sqlite:
    from reqlog.backends.sqlite import SQLiteBackend  # noqa: E402
    backends.append(SQLiteBackend())

# ── Django configuration ─────────────────────────────────────────────────

if not settings.configured:
    settings.configure(
        DEBUG=True,
        ROOT_URLCONF=__name__,
        MIDDLEWARE=["reqlog.middleware.django.ReqlogMiddleware"],
        REQLOG={
            "CAPTURE_BODY": True,
            "CAPTURE_HEADERS": True,
            "FORMAT": "panel",
            "BACKENDS": backends,
        },
        SECRET_KEY="demo-secret-key",
        ALLOWED_HOSTS=["*"],
    )
    django.setup()

from django.http import JsonResponse  # noqa: E402
from django.urls import path  # noqa: E402
from django.views.decorators.http import require_GET, require_POST, require_http_methods  # noqa: E402

# ── In-memory data ───────────────────────────────────────────────────────

USERS: dict[int, dict] = {
    1: {"id": 1, "name": "Alice", "email": "alice@example.com"},
    42: {"id": 42, "name": "Bob", "email": "bob@example.com"},
}

# ── Views ────────────────────────────────────────────────────────────────


@require_http_methods(["GET", "POST"])
def users(request):
    if request.method == "GET":
        return JsonResponse(list(USERS.values()), safe=False)
    body = json.loads(request.body)
    new_id = max(USERS) + 1
    user = {"id": new_id, **body}
    USERS[new_id] = user
    return JsonResponse(user, status=201)


@require_GET
def get_user(request, user_id: int):
    if user_id not in USERS:
        return JsonResponse({"detail": "Not found"}, status=404)
    return JsonResponse(USERS[user_id])


@require_http_methods(["DELETE"])
def delete_user(request, user_id: int):
    USERS.pop(user_id, None)
    return JsonResponse({}, status=204)


@require_GET
def crash(request):
    raise ZeroDivisionError("boom")


# ── URLs ─────────────────────────────────────────────────────────────────

urlpatterns = [
    path("users", users),
    path("users/<int:user_id>", get_user),
    path("users/<int:user_id>/delete", delete_user),
    path("crash", crash),
]

# ── Run with Django's built-in server ────────────────────────────────────

if __name__ == "__main__":
    if use_sqlite:
        from reqlog.backends.sqlite import default_db_path
        print(f"SQLite backend enabled — logging to {default_db_path()}")

    from django.core.management import execute_from_command_line

    execute_from_command_line(["demo_django", "runserver", "8000", "--noreload", *sys.argv[1:]])
