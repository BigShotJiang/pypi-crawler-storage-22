"""FastAPI demo with reqlog middleware.

Setup:  cd examples/fastapi && uv sync
Run:    uv run uvicorn app:app --reload
Then:   curl localhost:8000/users
      curl -X POST localhost:8000/users -H "Content-Type: application/json" -d '{"name":"Alice","password":"secret"}'
      curl localhost:8000/users/42
      curl localhost:8000/users/999
      curl localhost:8000/crash
"""

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from reqlog import ConsoleBackend, ReqlogMiddleware, SQLiteBackend

app = FastAPI(title="reqlog demo")

# --- Compact mode (one-liner per request, like morgan 'dev') ---
# app.add_middleware(ReqlogMiddleware)

# --- Panel mode (Rich columnar layout with syntax-highlighted bodies) ---
app.add_middleware(
    ReqlogMiddleware,
    capture_body=True,
    capture_headers=True,
    backends=[
        ConsoleBackend(format="panel"),
        SQLiteBackend(),
    ],
)

USERS = {
    1: {"id": 1, "name": "Alice", "email": "alice@example.com"},
    42: {"id": 42, "name": "Bob", "email": "bob@example.com"},
}


@app.get("/users")
async def list_users():
    return list(USERS.values())


@app.post("/users")
async def create_user(request: Request):
    body = await request.json()
    new_id = max(USERS) + 1
    user = {"id": new_id, **body}
    USERS[new_id] = user
    return user


@app.get("/users/{user_id}")
async def get_user(user_id: int):
    if user_id not in USERS:
        return JSONResponse({"detail": "Not found"}, status_code=404)
    return USERS[user_id]


@app.get("/crash")
async def crash():
    raise ZeroDivisionError("boom")
