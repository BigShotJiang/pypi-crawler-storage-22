"""reqlog MCP Server Demo — experience the Network Tab for AI agents.

Populates a SQLite database with realistic sample traffic, then starts
the reqlog MCP server on SSE transport so you can connect from Claude Code
or any other MCP-compatible client.

Setup:  cd examples/mcp && uv sync
Run:    uv run python demo.py
"""

from __future__ import annotations

import asyncio
import json
import os
import random
from datetime import datetime, timedelta, timezone

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from reqlog.backends.sqlite import SQLiteBackend
from reqlog.core.models import Request, Response, Transaction
from reqlog.mcp.server import create_server

DB_PATH = os.path.join(".reqlog", "demo_mcp.db")
MCP_PORT = 8100

# ── Sample data ──────────────────────────────────────────────────────────

# (method, path, query_string, status, base_duration_ms,
#  request_body, response_body, extra_request_headers)

_USER_LIST_BODY = json.dumps([
    {"id": 1, "name": "Alice Chen", "email": "alice@example.com", "role": "admin"},
    {"id": 2, "name": "Bob Martinez", "email": "bob@example.com", "role": "editor"},
    {"id": 3, "name": "Carol Nguyen", "email": "carol@example.com", "role": "viewer"},
]).encode()

_USER_1_BODY = json.dumps(
    {"id": 1, "name": "Alice Chen", "email": "alice@example.com", "role": "admin",
     "created_at": "2025-11-03T09:15:00Z", "last_login": "2026-02-14T08:22:00Z"}
).encode()

_USER_2_BODY = json.dumps(
    {"id": 2, "name": "Bob Martinez", "email": "bob@example.com", "role": "editor",
     "created_at": "2025-12-19T14:30:00Z", "last_login": "2026-02-13T16:45:00Z"}
).encode()

_POST_LIST_BODY = json.dumps([
    {"id": 1, "title": "Getting Started with reqlog", "author_id": 1, "status": "published"},
    {"id": 2, "title": "Monitoring API Performance", "author_id": 2, "status": "published"},
    {"id": 3, "title": "Draft: Advanced Filtering", "author_id": 1, "status": "draft"},
]).encode()

_POST_DETAIL_BODY = json.dumps(
    {"id": 1, "title": "Getting Started with reqlog", "author_id": 1,
     "body": "reqlog gives your AI coding agent a network tab...",
     "status": "published", "views": 342, "created_at": "2026-02-10T11:00:00Z"}
).encode()

_LOGIN_SUCCESS_BODY = json.dumps(
    {"token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZXhwIjoxNzM5NjEwMDAwfQ.[REDACTED]",
     "expires_in": 3600, "user": {"id": 1, "name": "Alice Chen"}}
).encode()

_SEARCH_RESULTS_BODY = json.dumps(
    {"results": [
        {"id": 1, "type": "user", "name": "Alice Chen", "score": 0.95},
        {"id": 1, "type": "post", "title": "Getting Started with reqlog", "score": 0.82},
    ], "total": 2, "took_ms": 12}
).encode()

_PAYMENT_SUCCESS_BODY = json.dumps(
    {"payment_id": "pay_1N2x3Y4z", "amount": 49.99, "currency": "USD",
     "status": "completed", "card_last4": "4242"}
).encode()

_PAYMENT_CREATE_BODY = json.dumps(
    {"amount": 49.99, "currency": "USD",
     "card_token": "tok_[REDACTED]", "description": "Pro plan — monthly"}
).encode()

_HEALTH_BODY = json.dumps(
    {"status": "healthy", "version": "0.4.0", "uptime_seconds": 86142}
).encode()

_DASHBOARD_BODY = json.dumps(
    {"active_users": 142, "requests_today": 8431, "error_rate": 0.023,
     "avg_latency_ms": 45.2, "top_endpoint": "/api/users"}
).encode()

# Each entry: (method, path, query_string, status, base_duration,
#              request_body, response_body)
SCENARIOS: list[tuple[str, str, str, int, float, bytes | None, bytes | None]] = [
    # ── User CRUD ────────────────────────────────────────────────────
    ("GET", "/api/users", "", 200, 12.0,
     None, _USER_LIST_BODY),
    ("GET", "/api/users", "", 200, 14.5,
     None, _USER_LIST_BODY),
    ("GET", "/api/users/1", "", 200, 6.2,
     None, _USER_1_BODY),
    ("GET", "/api/users/2", "", 200, 7.8,
     None, _USER_2_BODY),
    ("GET", "/api/users/999", "", 404, 5.1,
     None, b'{"error":"User not found","detail":"No user with id=999"}'),
    ("GET", "/api/users/888", "", 404, 4.9,
     None, b'{"error":"User not found","detail":"No user with id=888"}'),
    ("GET", "/api/users/777", "", 404, 5.3,
     None, b'{"error":"User not found","detail":"No user with id=777"}'),
    ("POST", "/api/users", "", 201, 89.4,
     b'{"name":"Dave Park","email":"dave@example.com","password":"[REDACTED]"}',
     b'{"id":4,"name":"Dave Park","email":"dave@example.com","role":"viewer","created_at":"2026-02-14T14:05:00Z"}'),
    ("POST", "/api/users", "", 422, 8.2,
     b'{"name":"","email":"not-an-email"}',
     b'{"error":"Validation failed","details":[{"field":"name","message":"Name is required"},{"field":"email","message":"Invalid email format"}]}'),
    ("PUT", "/api/users/2", "", 200, 55.7,
     b'{"role":"admin"}',
     b'{"id":2,"name":"Bob Martinez","email":"bob@example.com","role":"admin","updated_at":"2026-02-14T14:06:30Z"}'),
    ("DELETE", "/api/users/3", "", 204, 32.1,
     None, None),

    # ── Posts ─────────────────────────────────────────────────────────
    ("GET", "/api/posts", "", 200, 28.3,
     None, _POST_LIST_BODY),
    ("GET", "/api/posts/1", "", 200, 11.7,
     None, _POST_DETAIL_BODY),
    ("POST", "/api/posts", "", 201, 134.6,
     b'{"title":"Debugging with MCP","body":"The MCP protocol lets AI agents inspect HTTP traffic...","author_id":1}',
     b'{"id":4,"title":"Debugging with MCP","author_id":1,"status":"draft","created_at":"2026-02-14T14:08:00Z"}'),
    ("PUT", "/api/posts/3", "", 200, 48.2,
     b'{"status":"published"}',
     b'{"id":3,"title":"Draft: Advanced Filtering","status":"published","published_at":"2026-02-14T14:09:00Z"}'),

    # ── Authentication ───────────────────────────────────────────────
    ("POST", "/api/auth/login", "", 200, 215.3,
     b'{"username":"alice","password":"[REDACTED]"}',
     _LOGIN_SUCCESS_BODY),
    ("POST", "/api/auth/login", "", 200, 198.7,
     b'{"username":"bob","password":"[REDACTED]"}',
     _LOGIN_SUCCESS_BODY),
    ("POST", "/api/auth/login", "", 401, 12.4,
     b'{"username":"alice","password":"[REDACTED]"}',
     b'{"error":"Invalid credentials","message":"Incorrect password. 2 attempts remaining."}'),
    ("POST", "/api/auth/login", "", 401, 11.8,
     b'{"username":"nobody","password":"[REDACTED]"}',
     b'{"error":"Invalid credentials","message":"User not found."}'),

    # ── Search ───────────────────────────────────────────────────────
    ("GET", "/api/search", "q=alice", 200, 45.6,
     None, _SEARCH_RESULTS_BODY),
    ("GET", "/api/search", "q=nonexistent&page=1", 200, 38.2,
     None, b'{"results":[],"total":0,"took_ms":8}'),

    # ── Payments (slower endpoints) ──────────────────────────────────
    ("POST", "/api/payments", "", 201, 387.4,
     _PAYMENT_CREATE_BODY, _PAYMENT_SUCCESS_BODY),
    ("POST", "/api/payments", "", 201, 412.8,
     json.dumps({"amount": 99.00, "currency": "USD", "card_token": "tok_[REDACTED]", "description": "Pro plan \u2014 annual"}).encode(),
     b'{"payment_id":"pay_5A6b7C8d","amount":99.00,"currency":"USD","status":"completed","card_last4":"1234"}'),
    ("POST", "/api/payments", "", 500, 502.1,
     b'{"amount":149.99,"currency":"EUR","card_token":"tok_[REDACTED]","description":"Enterprise upgrade"}',
     b'{"error":"Payment gateway timeout","message":"Upstream provider did not respond within 5000ms. Please retry."}'),
    ("GET", "/api/payments/pay_1N2x3Y4z", "", 200, 22.8,
     None, _PAYMENT_SUCCESS_BODY),

    # ── Health / Infrastructure ──────────────────────────────────────
    ("GET", "/health", "", 200, 1.4,
     None, _HEALTH_BODY),
    ("GET", "/health", "", 200, 1.1,
     None, _HEALTH_BODY),
    ("GET", "/health", "", 200, 1.6,
     None, _HEALTH_BODY),

    # ── Dashboard ────────────────────────────────────────────────────
    ("GET", "/api/dashboard", "", 200, 156.3,
     None, _DASHBOARD_BODY),

    # ── Server error burst ───────────────────────────────────────────
    ("GET", "/api/users/1", "", 500, 89.7,
     None, b'{"error":"Internal server error","message":"Connection pool exhausted","trace_id":"abc123"}'),
    ("GET", "/api/posts", "", 500, 92.4,
     None, b'{"error":"Internal server error","message":"Connection pool exhausted","trace_id":"def456"}'),

    # ── Miscellaneous ────────────────────────────────────────────────
    ("GET", "/api/users/2/avatar", "", 200, 18.3,
     None, b'<binary image data>'),
    ("PATCH", "/api/users/1", "", 200, 41.5,
     b'{"last_login":"2026-02-14T14:12:00Z"}',
     b'{"id":1,"name":"Alice Chen","last_login":"2026-02-14T14:12:00Z"}'),
    ("GET", "/api/users", "role=admin&sort=name", 200, 16.8,
     None, b'[{"id":1,"name":"Alice Chen","role":"admin"},{"id":2,"name":"Bob Martinez","role":"admin"}]'),
    ("POST", "/api/posts/1/comments", "", 201, 67.9,
     b'{"body":"Great article! Really helped me set up reqlog.","author_id":2}',
     b'{"id":1,"post_id":1,"body":"Great article! Really helped me set up reqlog.","author_id":2,"created_at":"2026-02-14T14:13:00Z"}'),
]

CLIENT_IPS = ["127.0.0.1", "192.168.1.42", "10.0.0.15", "172.16.0.8", "192.168.1.100"]
USER_AGENTS = [
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
    "httpx/0.28.1",
    "PostmanRuntime/7.36.1",
    "curl/8.4.0",
    "python-requests/2.31.0",
]


def generate_sample_transactions() -> list[Transaction]:
    """Generate realistic HTTP transactions spread over the last 5 minutes."""
    now = datetime.now(timezone.utc)
    txns: list[Transaction] = []

    for i, scenario in enumerate(SCENARIOS):
        method, path, qs, status, base_dur, req_body, res_body = scenario

        # Spread timestamps across the last 5 minutes, roughly in order
        # but with some jitter
        offset_seconds = 300 - (i / len(SCENARIOS)) * 295 + random.uniform(-5, 5)
        offset_seconds = max(2.0, offset_seconds)  # ensure all are in the past
        ts = now - timedelta(seconds=offset_seconds)

        # Add realistic duration jitter (+/- 30%)
        duration = base_dur * random.uniform(0.7, 1.3)

        # Build request headers
        req_headers: dict[str, str] = {
            "host": "localhost:8000",
            "accept": "application/json",
        }
        if req_body:
            req_headers["content-type"] = "application/json"
        # Add authorization to most non-health endpoints
        if path != "/health" and random.random() > 0.3:
            req_headers["authorization"] = "Bearer eyJ...[REDACTED]"

        # Build response headers
        res_headers: dict[str, str] = {}
        if res_body and not res_body.startswith(b"<"):
            res_headers["content-type"] = "application/json"
        elif res_body:
            res_headers["content-type"] = "image/png"
        if status == 201:
            res_headers["location"] = f"{path}/{random.randint(1, 100)}"

        req_content_type = req_headers.get("content-type", "")
        res_content_type = res_headers.get("content-type", "")

        txns.append(
            Transaction(
                request=Request(
                    method=method,
                    path=path,
                    query_string=qs,
                    body=req_body,
                    client_ip=random.choice(CLIENT_IPS),
                    user_agent=random.choice(USER_AGENTS),
                    content_type=req_content_type,
                    headers=req_headers,
                ),
                response=Response(
                    status_code=status,
                    body=res_body,
                    content_type=res_content_type,
                    headers=res_headers,
                ),
                duration_ms=round(duration, 1),
                timestamp=ts,
            )
        )

    # Sort chronologically
    txns.sort(key=lambda t: t.timestamp)
    return txns


async def populate_database(db_path: str) -> int:
    """Write sample transactions to SQLite and return the count."""
    # Remove old demo database if it exists
    if os.path.exists(db_path):
        os.remove(db_path)

    txns = generate_sample_transactions()
    backend = SQLiteBackend(db_path=db_path)

    for txn in txns:
        await backend.write(txn)

    # Give the writer thread time to flush
    await asyncio.sleep(0.5)
    await backend.close()

    return len(txns)


def print_instructions(console: Console, count: int, db_path: str) -> None:
    """Print the startup banner with connection instructions."""
    abs_db_path = os.path.abspath(db_path)

    body = Text.from_markup(
        f"[bold]reqlog MCP Server Demo[/bold]\n"
        f"\n"
        f"Populated demo database with [bold cyan]{count}[/bold cyan] transactions\n"
        f"Database: [dim]{abs_db_path}[/dim]\n"
        f"\n"
        f"MCP server running on [bold green]http://127.0.0.1:{MCP_PORT}/sse[/bold green]\n"
        f"\n"
        f"[bold]── Connect from Claude Code ──────────────────────[/bold]\n"
        f"\n"
        f"Add to [bold].mcp.json[/bold]:\n"
        f'[dim]{json.dumps({"mcpServers": {"reqlog": {"type": "sse", "url": f"http://127.0.0.1:{MCP_PORT}/sse"}}}, indent=2)}[/dim]\n'
        f"\n"
        f"Or use stdio transport:\n"
        f"[dim]{json.dumps({"mcpServers": {"reqlog": {"command": "uv", "args": ["run", "reqlog", "mcp", "--db", abs_db_path]}}}, indent=2)}[/dim]\n"
        f"\n"
        f"[bold]── Try asking your AI agent ──────────────────────[/bold]\n"
        f"\n"
        f'  [italic]"What requests have been made recently?"[/italic]\n'
        f'  [italic]"Are there any errors?"[/italic]\n'
        f'  [italic]"Show me the details of the last 500 error"[/italic]\n'
        f'  [italic]"Which endpoints are slowest?"[/italic]\n'
        f'  [italic]"Search for requests involving payments"[/italic]\n'
        f"\n"
        f"Press [bold]Ctrl+C[/bold] to stop"
    )

    panel = Panel(
        body,
        border_style="cyan",
        padding=(1, 2),
    )
    console.print()
    console.print(panel)
    console.print()


def main() -> None:
    console = Console(stderr=True)

    # Ensure directory exists
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

    # Populate the database
    count = asyncio.run(populate_database(DB_PATH))

    # Print connection instructions
    print_instructions(console, count, DB_PATH)

    # Create and start the MCP server
    server = create_server(db_path=os.path.abspath(DB_PATH))
    server.settings.host = "127.0.0.1"
    server.settings.port = MCP_PORT
    try:
        server.run(transport="sse")
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
