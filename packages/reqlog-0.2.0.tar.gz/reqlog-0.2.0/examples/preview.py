"""Visual preview of reqlog formatters — no server needed.

Run:  uv run python examples/preview.py
"""

from datetime import datetime, timezone

from rich.console import Console

from reqlog.core.models import Request, Response, Transaction
from reqlog.formatters.compact_formatter import CompactLine
from reqlog.formatters.panel_formatter import ColumnarPanel
from reqlog.formatters.rich_formatter import VerbosePanel

console = Console(stderr=True)

# ── Sample transactions ──────────────────────────────────────────────────

txns = [
    Transaction(
        request=Request(
            method="GET",
            path="/api/users",
            headers={"accept": "application/json", "user-agent": "httpx/0.28.1"},
            client_ip="127.0.0.1",
            user_agent="httpx/0.28.1",
        ),
        response=Response(
            status_code=200,
            headers={"content-type": "application/json"},
            body=b'[{"id": 1, "name": "Alice", "email": "alice@example.com"}, {"id": 42, "name": "Bob", "email": "bob@example.com"}]',
            content_type="application/json",
        ),
        duration_ms=12.4,
        timestamp=datetime(2026, 2, 14, 14, 23, 45, tzinfo=timezone.utc),
        request_id="a1b2c3d4e5f6",
    ),
    Transaction(
        request=Request(
            method="POST",
            path="/api/users",
            headers={
                "content-type": "application/json",
                "authorization": "[REDACTED]",
                "x-request-id": "req_a1b2c3d4",
            },
            body=b'{"email": "charlie@example.com", "name": "Charlie", "password": "[REDACTED]"}',
            client_ip="127.0.0.1",
            user_agent="httpx/0.28.1",
            content_type="application/json",
        ),
        response=Response(
            status_code=201,
            headers={"content-type": "application/json"},
            body=b'{"id": 43, "email": "charlie@example.com", "name": "Charlie", "created_at": "2026-02-14T14:23:46Z"}',
            content_type="application/json",
        ),
        duration_ms=145.2,
        timestamp=datetime(2026, 2, 14, 14, 23, 46, tzinfo=timezone.utc),
        request_id="f7e8d9c0b1a2",
    ),
    Transaction(
        request=Request(
            method="GET",
            path="/api/users/999",
            client_ip="127.0.0.1",
            user_agent="httpx/0.28.1",
        ),
        response=Response(
            status_code=404,
            headers={"content-type": "application/json"},
            body=b'{"detail": "Not found"}',
            content_type="application/json",
        ),
        duration_ms=15.1,
        timestamp=datetime(2026, 2, 14, 14, 23, 49, tzinfo=timezone.utc),
        request_id="c3d4e5f6a7b8",
    ),
    Transaction(
        request=Request(
            method="DELETE",
            path="/api/users/42",
            headers={"authorization": "[REDACTED]"},
            client_ip="127.0.0.1",
            user_agent="httpx/0.28.1",
        ),
        response=Response(status_code=204),
        duration_ms=34.7,
        timestamp=datetime(2026, 2, 14, 14, 23, 50, tzinfo=timezone.utc),
        request_id="d4e5f6a7b8c9",
    ),
    Transaction(
        request=Request(
            method="GET",
            path="/api/crash",
            client_ip="127.0.0.1",
            user_agent="httpx/0.28.1",
        ),
        response=Response(
            status_code=500,
            headers={"content-type": "application/json"},
            body=b'{"detail": "Internal Server Error"}',
            content_type="application/json",
        ),
        duration_ms=89.3,
        timestamp=datetime(2026, 2, 14, 14, 23, 51, tzinfo=timezone.utc),
        request_id="e5f6a7b8c9d0",
    ),
]

# ── Compact mode ─────────────────────────────────────────────────────────

console.print()
console.rule("[bold]Compact Mode[/bold]", style="#30363d")
console.print()
for txn in txns:
    console.print(CompactLine(txn))
console.print()

# ── Verbose mode (v1) ────────────────────────────────────────────────────

console.rule("[bold]Verbose Mode (v1)[/bold]", style="#30363d")
console.print()
for txn in txns:
    console.print(VerbosePanel(txn))
    console.print()

# ── Panel mode (v2 — Claude Code-inspired) ───────────────────────────────

console.rule("[bold]Panel Mode (v2 — columnar)[/bold]", style="#30363d")
console.print()
for txn in txns:
    console.print(ColumnarPanel(txn))
    console.print()
