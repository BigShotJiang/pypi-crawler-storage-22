"""Demo of reqlog CLI commands — no server needed.

Populates a temporary SQLite database with realistic sample traffic,
then showcases each CLI feature so you can see the output.

Run:  uv run python examples/preview_cli.py
"""

from __future__ import annotations

import asyncio
import json
import random
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

from rich.console import Console
from rich.table import Table
from rich.text import Text

from reqlog.backends.file import FileBackend
from reqlog.backends.sqlite import SQLiteBackend, SQLiteReader
from reqlog.core.models import Request, Response, Transaction
from reqlog.formatters.ai_formatter import format_ai_line
from reqlog.formatters.compact_formatter import (
    METHOD_COLORS,
    STATUS_COLORS,
    STATUS_GLYPHS,
    _format_duration,
    _timing_style,
)

console = Console(stderr=True)

# ── Sample data generators ───────────────────────────────────────────────

ENDPOINTS = [
    ("GET", "/api/users", 200, 8.2),
    ("GET", "/api/users", 200, 11.5),
    ("POST", "/api/users", 201, 145.2),
    ("GET", "/api/users/1", 200, 5.7),
    ("GET", "/api/users/999", 404, 14.8),
    ("PUT", "/api/users/1", 200, 62.3),
    ("DELETE", "/api/users/42", 204, 33.1),
    ("GET", "/api/posts", 200, 22.4),
    ("POST", "/api/posts", 201, 187.6),
    ("GET", "/api/posts/1", 200, 9.1),
    ("GET", "/api/posts/1/comments", 200, 45.9),
    ("POST", "/api/posts/1/comments", 201, 112.0),
    ("GET", "/api/search?q=hello", 200, 340.5),
    ("GET", "/api/crash", 500, 89.3),
    ("PATCH", "/api/users/1", 200, 55.0),
    ("GET", "/api/health", 200, 1.2),
    ("POST", "/api/auth/login", 200, 230.4),
    ("POST", "/api/auth/login", 401, 15.0),
    ("GET", "/api/dashboard", 200, 520.1),
    ("GET", "/api/reports/monthly", 200, 1250.0),
]

RESPONSE_BODIES: dict[str, bytes] = {
    "GET /api/users": b'[{"id":1,"name":"Alice","email":"alice@example.com"},{"id":42,"name":"Bob","email":"bob@example.com"}]',
    "POST /api/users": b'{"id":43,"email":"charlie@example.com","name":"Charlie","created_at":"2026-02-14T14:23:46Z"}',
    "GET /api/users/1": b'{"id":1,"name":"Alice","email":"alice@example.com"}',
    "GET /api/users/999": b'{"detail":"Not found"}',
    "GET /api/posts": b'[{"id":1,"title":"Hello World","author_id":1},{"id":2,"title":"reqlog v0.2","author_id":42}]',
    "POST /api/posts": b'{"id":3,"title":"New post","author_id":1,"created_at":"2026-02-14T14:30:00Z"}',
    "GET /api/crash": b'{"detail":"Internal Server Error"}',
    "POST /api/auth/login": b'{"token":"eyJhbGciOiJIUzI1NiIs...","expires_in":3600}',
    "GET /api/dashboard": b'{"active_users":142,"requests_today":8431,"error_rate":0.02}',
}

REQUEST_BODIES: dict[str, bytes] = {
    "POST /api/users": b'{"email":"charlie@example.com","name":"Charlie","password":"[REDACTED]"}',
    "POST /api/posts": b'{"title":"New post","body":"This is the content of the post."}',
    "POST /api/auth/login": b'{"username":"alice","password":"[REDACTED]"}',
}


def _generate_transactions(count: int = 30) -> list[Transaction]:
    """Generate a realistic set of transactions spread over the last ~5 minutes."""
    now = datetime.now(timezone.utc)
    txns = []
    for i in range(count):
        method, path_raw, status, base_dur = random.choice(ENDPOINTS)

        if "?" in path_raw:
            path, qs = path_raw.split("?", 1)
        else:
            path, qs = path_raw, ""

        duration = base_dur * random.uniform(0.7, 1.5)
        ts = now - timedelta(seconds=random.uniform(0, 300))

        key = f"{method} {path_raw.split('?')[0]}"
        res_body = RESPONSE_BODIES.get(key)
        req_body = REQUEST_BODIES.get(key)

        if key == "POST /api/auth/login" and status == 401:
            res_body = b'{"detail":"Invalid credentials"}'

        txns.append(
            Transaction(
                request=Request(
                    method=method,
                    path=path,
                    query_string=qs,
                    body=req_body,
                    client_ip=random.choice(["127.0.0.1", "192.168.1.50", "10.0.0.12"]),
                    user_agent="httpx/0.28.1",
                    content_type="application/json" if req_body else "",
                    headers={"content-type": "application/json"} if req_body else {},
                ),
                response=Response(
                    status_code=status,
                    body=res_body,
                    content_type="application/json" if res_body else "",
                    headers={"content-type": "application/json"} if res_body else {},
                ),
                duration_ms=round(duration, 1),
                timestamp=ts,
            )
        )

    txns.sort(key=lambda t: t.timestamp)
    return txns


def _print_compact_row(row: dict) -> None:
    """Print a single DB row in compact colored format (same as `reqlog tail`)."""
    sc = f"{row['status_code'] // 100}xx"
    method_color = METHOD_COLORS.get(row["method"], "#c9d1d9")
    status_color = STATUS_COLORS.get(sc, "#c9d1d9")
    glyph = STATUS_GLYPHS.get(sc, "●")
    timing_color = _timing_style(row["duration_ms"])
    duration = _format_duration(row["duration_ms"])

    req_path = row["path"]
    if row.get("query_string"):
        req_path = f"{req_path}?{row['query_string']}"
    if len(req_path) > 45:
        req_path = req_path[:44] + "\u2026"

    line = Text()
    line.append(f"  {glyph} ", style=status_color)
    line.append(f"{row['method']:<7}", style=f"bold {method_color}")
    line.append(f" {req_path:<45}", style="#c9d1d9")
    line.append(f" {row['status_code']:>3}", style=f"bold {status_color}")
    line.append(f"  {duration:>6}", style=timing_color)
    ts_str = row.get("timestamp", "")[:19].split("T")[-1] if row.get("timestamp") else ""
    line.append(f"   {ts_str}", style="#484f58")
    console.print(line)


def _print_stats(reader: SQLiteReader) -> None:
    """Render stats tables (same output as `reqlog stats`)."""
    s = reader.get_stats(minutes=60)

    console.print(f"\n  [bold]Request Stats[/bold] (last 60 min)\n")
    console.print(f"    Total requests: [bold]{s.total_requests}[/bold]")
    console.print(f"    Avg duration:   [bold]{s.avg_duration_ms:.1f}ms[/bold]")
    console.print(f"    P50:            {s.p50_duration_ms:.1f}ms")
    console.print(f"    P95:            {s.p95_duration_ms:.1f}ms")
    console.print(f"    P99:            {s.p99_duration_ms:.1f}ms")

    if s.status_counts:
        console.print()
        t = Table(title="Status Codes", show_header=True, padding=(0, 2))
        t.add_column("Class", style="bold")
        t.add_column("Count", justify="right")
        for cls, cnt in sorted(s.status_counts.items()):
            t.add_row(cls, str(cnt))
        console.print(t)

    if s.method_counts:
        console.print()
        t = Table(title="HTTP Methods", show_header=True, padding=(0, 2))
        t.add_column("Method", style="bold")
        t.add_column("Count", justify="right")
        for meth, cnt in sorted(s.method_counts.items()):
            t.add_row(meth, str(cnt))
        console.print(t)

    if s.slowest_endpoints:
        console.print()
        t = Table(title="Top 10 Slowest Endpoints", show_header=True, padding=(0, 2))
        t.add_column("Method", style="bold")
        t.add_column("Path")
        t.add_column("Count", justify="right")
        t.add_column("Avg (ms)", justify="right")
        t.add_column("Max (ms)", justify="right")
        for ep in s.slowest_endpoints:
            t.add_row(ep["method"], ep["path"], str(ep["count"]), str(ep["avg_ms"]), str(ep["max_ms"]))
        console.print(t)


# ── Main demo ────────────────────────────────────────────────────────────

async def main() -> None:
    tmpdir = Path(tempfile.mkdtemp(prefix="reqlog_demo_"))
    db_path = str(tmpdir / "demo.db")
    file_path = str(tmpdir / "demo.jsonl")
    ai_file_path = str(tmpdir / "demo_ai.log")

    console.print()
    console.rule("[bold]reqlog CLI Demo[/bold]", style="#58a6ff")
    console.print()
    console.print(f"  [dim]Temp directory:[/dim] {tmpdir}")
    console.print()

    # Generate and store transactions
    txns = _generate_transactions(30)

    console.print("  [dim]Populating SQLite + File backends with 30 sample transactions...[/dim]")
    console.print()

    sqlite_backend = SQLiteBackend(db_path=db_path)
    file_backend = FileBackend(path=file_path, format="json")
    ai_file_backend = FileBackend(path=ai_file_path, format="ai")

    for txn in txns:
        await sqlite_backend.write(txn)
        await file_backend.write(txn)
        await ai_file_backend.write(txn)

    await sqlite_backend.close()
    await file_backend.close()
    await ai_file_backend.close()

    reader = SQLiteReader(db_path=db_path)

    # ── 1. AI Formatter ──────────────────────────────────────────────────

    console.rule("[bold]AI Formatter[/bold]  format=\"ai\"", style="#30363d")
    console.print()
    console.print("  [dim]Token-efficient plain-text format for LLM tool output:[/dim]")
    console.print()
    for txn in txns[:5]:
        for line in format_ai_line(txn).split("\n"):
            console.print(f"    {line}", highlight=False)
    console.print()

    # ── 2. reqlog tail ───────────────────────────────────────────────────

    console.rule("[bold]reqlog tail[/bold]  --db demo.db --limit 10", style="#30363d")
    console.print()
    console.print("  [dim]Live-tail output (showing last 10 requests):[/dim]")
    console.print()
    rows = reader.get_recent(limit=10)
    for row in reversed(rows):
        _print_compact_row(row)
    console.print()

    # ── 3. reqlog tail with filters ──────────────────────────────────────

    console.rule("[bold]reqlog tail[/bold]  --db demo.db --slow 100", style="#30363d")
    console.print()
    console.print("  [dim]Slow requests only (>100ms):[/dim]")
    console.print()
    slow_rows = reader.get_recent(limit=20, min_duration=100.0)
    for row in reversed(slow_rows):
        _print_compact_row(row)
    console.print()

    # ── 4. reqlog stats ──────────────────────────────────────────────────

    console.rule("[bold]reqlog stats[/bold]  --db demo.db --minutes 60", style="#30363d")
    _print_stats(reader)
    console.print()

    # ── 5. reqlog export --format json ───────────────────────────────────

    console.rule("[bold]reqlog export[/bold]  --db demo.db --format json --limit 3", style="#30363d")
    console.print()
    console.print("  [dim]JSON-Lines export (first 3 entries, pretty-printed):[/dim]")
    console.print()
    export_rows = reader.get_recent(limit=3)
    for row in reversed(export_rows):
        pretty = json.dumps(row, indent=2, default=str)
        for pline in pretty.split("\n"):
            console.print(f"    [#c9d1d9]{pline}[/]")
        console.print()

    # ── 6. reqlog export --format csv ────────────────────────────────────

    console.rule("[bold]reqlog export[/bold]  --db demo.db --format csv --limit 5", style="#30363d")
    console.print()
    console.print("  [dim]CSV export (first 5 entries):[/dim]")
    console.print()
    csv_rows = reader.get_recent(limit=5)
    csv_rows = list(reversed(csv_rows))
    header = "id,timestamp,method,path,status_code,duration_ms,client_ip"
    console.print(f"    [bold #58a6ff]{header}[/]")
    for row in csv_rows:
        vals = [str(row.get(f, "")) for f in header.split(",")]
        console.print(f"    [#c9d1d9]{','.join(vals)}[/]")
    console.print()

    # ── 7. reqlog export with filters ────────────────────────────────────

    console.rule(
        '[bold]reqlog export[/bold]  --since "5 min ago" --method POST --limit 3',
        style="#30363d",
    )
    console.print()
    console.print("  [dim]Filtered export (POST requests from last 5 minutes):[/dim]")
    console.print()
    import time
    since = time.time() - 300
    filtered = reader.get_since(since, method_filter="POST")[:3]
    for row in filtered:
        compact = json.dumps(row, default=str)
        if len(compact) > 120:
            compact = compact[:119] + "\u2026"
        console.print(f"    [#c9d1d9]{compact}[/]")
    console.print()

    # ── 8. File backend samples ──────────────────────────────────────────

    console.rule("[bold]File Backend Samples[/bold]", style="#30363d")
    console.print()

    console.print("  [dim]JSON-Lines file (first 3 lines):[/dim]")
    console.print()
    with open(file_path) as f:
        for i, line in enumerate(f):
            if i >= 3:
                break
            try:
                obj = json.loads(line.strip())
                compact = json.dumps(obj, default=str)
                if len(compact) > 120:
                    compact = compact[:119] + "\u2026"
                console.print(f"    [#c9d1d9]{compact}[/]")
            except json.JSONDecodeError:
                console.print(f"    {line.strip()}", highlight=False)
    console.print()

    console.print("  [dim]AI-format file (first 2 entries):[/dim]")
    console.print()
    with open(ai_file_path) as f:
        printed = 0
        for line in f:
            console.print(f"    {line.rstrip()}", highlight=False)
            if line.strip() == "---":
                printed += 1
                if printed >= 2:
                    break
    console.print()

    # ── Quick reference ──────────────────────────────────────────────────

    console.rule("[bold]CLI Quick Reference[/bold]", style="#58a6ff")
    console.print()
    commands = [
        ("reqlog tail --db reqlog.db", "Live-tail with colored output (Ctrl+C to stop)"),
        ("reqlog tail --slow 100", "Show only slow requests (>100ms)"),
        ("reqlog tail --status 500", "Filter by status code"),
        ("reqlog tail --method POST --path /api/users", "Combined filters"),
        ("reqlog stats --db reqlog.db", "Aggregated stats with percentiles"),
        ("reqlog stats --minutes 5", "Stats for last 5 minutes"),
        ("reqlog export --format json", "Export as JSON-Lines to stdout"),
        ("reqlog export --format csv", "Export as CSV to stdout"),
        ('reqlog export --since "1 hour ago"', "Time-filtered export"),
        ("cd examples/fastapi && uv run uvicorn app:app", "Run the FastAPI demo"),
        ("cd examples/django && uv run python app.py", "Run the Django demo"),
    ]
    max_cmd = max(len(c[0]) for c in commands)
    for cmd, desc in commands:
        line = Text()
        line.append(f"  {cmd:<{max_cmd + 2}}", style="bold #3fb950")
        line.append(f"  {desc}", style="dim")
        console.print(line)

    console.print()
    console.print(f"  [dim]Demo files saved in {tmpdir}[/dim]")
    console.print(f"  [dim]Try interactively: uv run reqlog stats --db {db_path}[/dim]")
    console.print()


if __name__ == "__main__":
    asyncio.run(main())
