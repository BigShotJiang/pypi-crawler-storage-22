from __future__ import annotations

from rich.console import Console

from reqlog.core.models import Transaction
from reqlog.formatters.ai_formatter import format_ai_line
from reqlog.formatters.compact_formatter import CompactLine
from reqlog.formatters.json_formatter import format_json_line
from reqlog.formatters.panel_formatter import ColumnarPanel
from reqlog.formatters.rich_formatter import VerbosePanel


class ConsoleBackend:
    """Console backend that dispatches to formatters based on format setting."""

    def __init__(
        self,
        format: str = "compact",
        max_body_display: int = 2000,
        console: Console | None = None,
    ) -> None:
        self._format = format
        self._max_body_display = max_body_display
        self._console = console or Console(stderr=True)

    async def write(self, transaction: Transaction) -> None:
        match self._format:
            case "compact":
                self._console.print(CompactLine(transaction))
            case "verbose":
                self._console.print(VerbosePanel(transaction, self._max_body_display))
            case "panel":
                self._console.print(ColumnarPanel(transaction, self._max_body_display))
            case "json":
                self._console.print(format_json_line(transaction), highlight=False)
            case "ai":
                self._console.print(format_ai_line(transaction), highlight=False)
            case _:
                self._console.print(CompactLine(transaction))
