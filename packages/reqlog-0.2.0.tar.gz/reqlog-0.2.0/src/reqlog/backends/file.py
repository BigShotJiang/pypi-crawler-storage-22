from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler

from reqlog.core.models import Transaction
from reqlog.formatters.ai_formatter import format_ai_line
from reqlog.formatters.json_formatter import format_json_line


class FileBackend:
    """File-based backend with optional rotation.

    Supports three output formats: json (JSON-Lines), text (plain one-liner), ai (token-efficient).
    """

    def __init__(
        self,
        path: str = "reqlog.jsonl",
        format: str = "json",
        rotate: bool = True,
        max_size_mb: int = 100,
        max_files: int = 5,
    ) -> None:
        self._format = format
        self._logger = logging.getLogger(f"reqlog.file.{id(self)}")
        self._logger.setLevel(logging.INFO)
        self._logger.propagate = False

        if rotate:
            handler = RotatingFileHandler(
                path,
                maxBytes=max_size_mb * 1024 * 1024,
                backupCount=max_files,
                encoding="utf-8",
            )
        else:
            handler = logging.FileHandler(path, encoding="utf-8")  # type: ignore[assignment]

        handler.setFormatter(logging.Formatter("%(message)s"))
        self._logger.addHandler(handler)
        self._handler = handler

    async def write(self, transaction: Transaction) -> None:
        match self._format:
            case "json":
                self._logger.info(format_json_line(transaction))
            case "text":
                self._logger.info(_format_text_line(transaction))
            case "ai":
                self._logger.info(format_ai_line(transaction))
            case _:
                self._logger.info(format_json_line(transaction))

    async def close(self) -> None:
        self._handler.flush()
        self._handler.close()
        self._logger.removeHandler(self._handler)


def _format_text_line(transaction: Transaction) -> str:
    """Plain-text one-liner: 2026-02-14T14:23:46 POST /api/users 201 145ms"""
    txn = transaction
    ts = txn.timestamp.strftime("%Y-%m-%dT%H:%M:%S")
    duration = f"{txn.duration_ms:.0f}ms" if txn.duration_ms < 1000 else f"{txn.duration_ms / 1000:.1f}s"
    path = txn.request.path
    if txn.request.query_string:
        path = f"{path}?{txn.request.query_string}"
    return f"{ts} {txn.request.method} {path} {txn.response.status_code} {duration}"
