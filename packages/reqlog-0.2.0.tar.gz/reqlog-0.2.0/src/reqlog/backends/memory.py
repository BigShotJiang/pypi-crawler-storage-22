from __future__ import annotations

from reqlog.core.buffer import BoundedRingBuffer
from reqlog.core.models import Transaction


class MemoryBackend:
    """In-memory backend wrapping a BoundedRingBuffer."""

    def __init__(self, max_size: int = 1000) -> None:
        self._buffer = BoundedRingBuffer(max_size=max_size)

    async def write(self, transaction: Transaction) -> None:
        self._buffer.append(transaction)

    @property
    def transactions(self) -> list[Transaction]:
        return self._buffer.get_all()

    def get_recent(self, n: int) -> list[Transaction]:
        return self._buffer.get_recent(n)

    def clear(self) -> None:
        self._buffer.clear()

    def __len__(self) -> int:
        return len(self._buffer)
