from __future__ import annotations

from typing import Protocol, runtime_checkable

from reqlog.core.models import Transaction


@runtime_checkable
class Backend(Protocol):
    """Any object with an async write() method is a valid backend."""

    async def write(self, transaction: Transaction) -> None: ...


@runtime_checkable
class Closeable(Protocol):
    """Optional: cleanup on shutdown."""

    async def close(self) -> None: ...
