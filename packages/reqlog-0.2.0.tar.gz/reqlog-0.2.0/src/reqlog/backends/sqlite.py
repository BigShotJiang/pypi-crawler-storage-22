"""SQLite-backed persistent storage for HTTP transactions.

Provides SQLiteBackend (async write interface with background writer thread) and
SQLiteReader (read-only query interface). The writer uses queue-based batching with
executemany, auto-pruning at max_rows, and WAL mode for concurrent read/write.
Non-daemon writer thread ensures graceful shutdown and queue flushing via atexit.
"""

from __future__ import annotations

import atexit
import json
import logging
import os
import queue
import sqlite3
import threading
from dataclasses import dataclass, field
from typing import Any

from reqlog.core.models import Transaction

logger = logging.getLogger(__name__)


def default_db_path() -> str:
    """Return the default database path, creating the directory if needed."""
    db_dir = os.path.join(os.getcwd(), ".reqlog")
    os.makedirs(db_dir, exist_ok=True)
    return os.path.join(db_dir, "reqlog.db")

_SENTINEL = object()

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS {table} (
    id TEXT PRIMARY KEY,
    timestamp TEXT NOT NULL,
    timestamp_unix REAL NOT NULL,
    method TEXT NOT NULL,
    path TEXT NOT NULL,
    query_string TEXT,
    status_code INTEGER NOT NULL,
    duration_ms REAL NOT NULL,
    client_ip TEXT,
    user_agent TEXT,
    request_headers TEXT,
    request_body BLOB,
    response_headers TEXT,
    response_body BLOB,
    request_content_type TEXT,
    response_content_type TEXT
)
"""

_CREATE_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_{table}_timestamp ON {table}(timestamp_unix)",
    "CREATE INDEX IF NOT EXISTS idx_{table}_status ON {table}(status_code)",
    "CREATE INDEX IF NOT EXISTS idx_{table}_path ON {table}(path)",
]

_INSERT = """
INSERT OR REPLACE INTO {table} (
    id, timestamp, timestamp_unix, method, path, query_string,
    status_code, duration_ms, client_ip, user_agent,
    request_headers, request_body, response_headers, response_body,
    request_content_type, response_content_type
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
"""


@dataclass(frozen=True, slots=True)
class RequestStats:
    total_requests: int = 0
    status_counts: dict[str, int] = field(default_factory=dict)
    method_counts: dict[str, int] = field(default_factory=dict)
    avg_duration_ms: float = 0.0
    p50_duration_ms: float = 0.0
    p95_duration_ms: float = 0.0
    p99_duration_ms: float = 0.0
    slowest_endpoints: list[dict[str, Any]] = field(default_factory=list)


def _txn_to_row(txn: Transaction, table: str) -> tuple:  # type: ignore[type-arg]
    """Convert a Transaction to a row tuple for INSERT."""
    return (
        txn.request_id,
        txn.timestamp.isoformat(),
        txn.timestamp.timestamp(),
        txn.request.method,
        txn.request.path,
        txn.request.query_string or None,
        txn.response.status_code,
        round(txn.duration_ms, 2),
        txn.request.client_ip or None,
        txn.request.user_agent or None,
        json.dumps(txn.request.headers) if txn.request.headers else None,
        txn.request.body,
        json.dumps(txn.response.headers) if txn.response.headers else None,
        txn.response.body,
        txn.request.content_type or None,
        txn.response.content_type or None,
    )


def _row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    """Convert a sqlite3.Row to a plain dict with parsed JSON fields."""
    d = dict(row)
    for key in ("request_headers", "response_headers"):
        if d.get(key):
            try:
                d[key] = json.loads(d[key])
            except (json.JSONDecodeError, TypeError):
                pass
    for key in ("request_body", "response_body"):
        if isinstance(d.get(key), bytes):
            try:
                d[key] = d[key].decode("utf-8")
            except UnicodeDecodeError:
                d[key] = f"<binary {len(d[key])} bytes>"
    return d


class SQLiteReader:
    """Read-only query interface for the reqlog SQLite database.

    Used by SQLiteBackend for delegated reads, by the CLI for querying logs,
    and by the MCP server for AI-agent access to HTTP traffic.
    """

    def __init__(self, db_path: str, table_name: str = "requests") -> None:
        self._db_path = db_path
        self._table = table_name

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _build_filters(
        self,
        conditions: list[str],
        params: list[Any],
        *,
        status_filter: int | None = None,
        status_class: str | None = None,
        path_filter: str | None = None,
        method_filter: str | None = None,
        min_duration: float | None = None,
    ) -> None:
        """Append WHERE-clause conditions and params for common filters."""
        if status_filter is not None:
            conditions.append("status_code = ?")
            params.append(status_filter)
        if status_class is not None:
            if status_class == "error":
                conditions.append("status_code >= 400")
            elif status_class.endswith("xx"):
                base = int(status_class[0]) * 100
                conditions.append("status_code >= ? AND status_code < ?")
                params.extend([base, base + 100])
        if path_filter is not None:
            conditions.append("path LIKE ?")
            params.append(f"%{path_filter}%")
        if method_filter is not None:
            conditions.append("method = ?")
            params.append(method_filter.upper())
        if min_duration is not None:
            conditions.append("duration_ms >= ?")
            params.append(min_duration)

    def get_recent(
        self,
        limit: int = 50,
        status_filter: int | None = None,
        status_class: str | None = None,
        path_filter: str | None = None,
        method_filter: str | None = None,
        min_duration: float | None = None,
    ) -> list[dict[str, Any]]:
        """Fetch the most recent transactions, optionally filtered.

        Args:
            limit: Maximum number of rows to return.
            status_filter: Exact status code match (e.g. 404).
            status_class: Status class filter ("2xx", "4xx", "error").
            path_filter: Substring match against request path.
            method_filter: Exact HTTP method match (case-insensitive).
            min_duration: Minimum duration in milliseconds.

        Returns:
            List of transaction dicts ordered by timestamp descending.
        """
        conditions: list[str] = []
        params: list[Any] = []
        self._build_filters(
            conditions, params,
            status_filter=status_filter, status_class=status_class,
            path_filter=path_filter, method_filter=method_filter,
            min_duration=min_duration,
        )

        where = f" WHERE {' AND '.join(conditions)}" if conditions else ""
        sql = f"SELECT * FROM {self._table}{where} ORDER BY timestamp_unix DESC LIMIT ?"
        params.append(limit)

        conn = self._connect()
        try:
            rows = conn.execute(sql, params).fetchall()
            return [_row_to_dict(r) for r in rows]
        finally:
            conn.close()

    def get_since(
        self,
        timestamp: float,
        **filters: Any,
    ) -> list[dict[str, Any]]:
        """Fetch all transactions after a given Unix timestamp.

        Args:
            timestamp: Unix timestamp (seconds since epoch). Only transactions
                recorded after this time are returned.
            **filters: Optional keyword filters passed to _build_filters
                (status_filter, status_class, path_filter, method_filter, min_duration).

        Returns:
            List of transaction dicts ordered by timestamp ascending.
        """
        conditions = ["timestamp_unix > ?"]
        params: list[Any] = [timestamp]
        self._build_filters(
            conditions, params,
            status_filter=filters.get("status_filter"),
            status_class=filters.get("status_class"),
            path_filter=filters.get("path_filter"),
            method_filter=filters.get("method_filter"),
            min_duration=filters.get("min_duration"),
        )

        where = f" WHERE {' AND '.join(conditions)}"
        sql = f"SELECT * FROM {self._table}{where} ORDER BY timestamp_unix ASC"

        conn = self._connect()
        try:
            rows = conn.execute(sql, params).fetchall()
            return [_row_to_dict(r) for r in rows]
        finally:
            conn.close()

    def get_by_id(self, request_id: str) -> dict[str, Any] | None:
        """Fetch a single transaction by its request ID.

        Returns:
            Transaction dict with parsed JSON headers and decoded bodies,
            or None if no matching request exists.
        """
        conn = self._connect()
        try:
            row = conn.execute(
                f"SELECT * FROM {self._table} WHERE id = ?", (request_id,)
            ).fetchone()
            return _row_to_dict(row) if row else None
        finally:
            conn.close()

    def get_stats(self, minutes: int = 60) -> RequestStats:
        """Compute aggregate statistics for the given time window.

        Args:
            minutes: Look-back window in minutes from now.

        Returns:
            RequestStats with total counts, status/method breakdowns,
            duration percentiles (p50/p95/p99), and top 10 slowest endpoints.
        """
        import time

        since = time.time() - (minutes * 60)
        conn = self._connect()
        try:
            # Total count
            total = conn.execute(
                f"SELECT COUNT(*) FROM {self._table} WHERE timestamp_unix > ?",
                (since,),
            ).fetchone()[0]

            if total == 0:
                return RequestStats()

            # Status counts
            status_rows = conn.execute(
                f"""SELECT status_code / 100 AS cls, COUNT(*) AS cnt
                    FROM {self._table} WHERE timestamp_unix > ?
                    GROUP BY cls""",
                (since,),
            ).fetchall()
            status_counts = {f"{r['cls']}xx": r["cnt"] for r in status_rows}

            # Method counts
            method_rows = conn.execute(
                f"""SELECT method, COUNT(*) AS cnt
                    FROM {self._table} WHERE timestamp_unix > ?
                    GROUP BY method""",
                (since,),
            ).fetchall()
            method_counts = {r["method"]: r["cnt"] for r in method_rows}

            # Duration percentiles via sorted list
            dur_rows = conn.execute(
                f"""SELECT duration_ms FROM {self._table}
                    WHERE timestamp_unix > ?
                    ORDER BY duration_ms""",
                (since,),
            ).fetchall()
            durations = [r["duration_ms"] for r in dur_rows]
            avg_dur = sum(durations) / len(durations)

            def percentile(sorted_vals: list[float], pct: float) -> float:
                idx = int(len(sorted_vals) * pct / 100)
                idx = min(idx, len(sorted_vals) - 1)
                return sorted_vals[idx]

            # Slowest endpoints (top 10 by avg duration)
            slow_rows = conn.execute(
                f"""SELECT path, method,
                           COUNT(*) AS cnt,
                           AVG(duration_ms) AS avg_ms,
                           MAX(duration_ms) AS max_ms
                    FROM {self._table} WHERE timestamp_unix > ?
                    GROUP BY path, method
                    ORDER BY avg_ms DESC LIMIT 10""",
                (since,),
            ).fetchall()
            slowest = [
                {
                    "path": r["path"],
                    "method": r["method"],
                    "count": r["cnt"],
                    "avg_ms": round(r["avg_ms"], 1),
                    "max_ms": round(r["max_ms"], 1),
                }
                for r in slow_rows
            ]

            return RequestStats(
                total_requests=total,
                status_counts=status_counts,
                method_counts=method_counts,
                avg_duration_ms=round(avg_dur, 1),
                p50_duration_ms=round(percentile(durations, 50), 1),
                p95_duration_ms=round(percentile(durations, 95), 1),
                p99_duration_ms=round(percentile(durations, 99), 1),
                slowest_endpoints=slowest,
            )
        finally:
            conn.close()

    def search_requests(
        self,
        query: str,
        status_class: str | None = None,
        since: float | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Search requests by matching query against path, bodies, and headers."""
        conditions: list[str] = []
        params: list[Any] = []

        # Text search across multiple columns
        # CAST blob columns to TEXT so LIKE can match body content
        search_exprs = [
            "path",
            "CAST(request_body AS TEXT)",
            "CAST(response_body AS TEXT)",
            "request_headers",
            "response_headers",
        ]
        like_clause = " OR ".join(f"{expr} LIKE ?" for expr in search_exprs)
        conditions.append(f"({like_clause})")
        params.extend([f"%{query}%"] * len(search_exprs))

        if since is not None:
            conditions.append("timestamp_unix > ?")
            params.append(since)

        self._build_filters(conditions, params, status_class=status_class)

        where = f" WHERE {' AND '.join(conditions)}"
        sql = f"SELECT * FROM {self._table}{where} ORDER BY timestamp_unix DESC LIMIT ?"
        params.append(limit)

        conn = self._connect()
        try:
            rows = conn.execute(sql, params).fetchall()
            return [_row_to_dict(r) for r in rows]
        finally:
            conn.close()

    def get_error_summary(self, minutes: int = 5) -> dict[str, Any]:
        """Get summary of errors (4xx/5xx) in the given time window."""
        import time as _time

        since = _time.time() - (minutes * 60)
        conn = self._connect()
        try:
            total = conn.execute(
                f"SELECT COUNT(*) FROM {self._table} WHERE timestamp_unix > ?",
                (since,),
            ).fetchone()[0]

            error_rows = conn.execute(
                f"SELECT * FROM {self._table} WHERE timestamp_unix > ? AND status_code >= 400 "
                f"ORDER BY timestamp_unix DESC",
                (since,),
            ).fetchall()

            total_errors = len(error_rows)
            error_rate = (total_errors / total * 100) if total > 0 else 0.0

            # Group by status code
            by_status: dict[int, list[dict[str, Any]]] = {}
            for row in error_rows:
                d = _row_to_dict(row)
                code = d["status_code"]
                by_status.setdefault(code, []).append(d)

            status_groups = [
                {"status_code": code, "count": len(reqs), "requests": reqs}
                for code, reqs in sorted(by_status.items())
            ]

            return {
                "total_errors": total_errors,
                "total_requests": total,
                "error_rate": round(error_rate, 1),
                "by_status": status_groups,
            }
        finally:
            conn.close()

    def get_endpoint_stats(
        self,
        path_pattern: str | None = None,
        minutes: int = 60,
    ) -> list[dict[str, Any]]:
        """Get per-endpoint stats with percentiles."""
        import time as _time

        since = _time.time() - (minutes * 60)
        conditions = ["timestamp_unix > ?"]
        params: list[Any] = [since]

        if path_pattern is not None:
            conditions.append("path LIKE ?")
            params.append(f"%{path_pattern}%")

        where = f" WHERE {' AND '.join(conditions)}"
        sql = (
            f"SELECT path, method, status_code, duration_ms "
            f"FROM {self._table}{where} ORDER BY path, method"
        )

        conn = self._connect()
        try:
            rows = conn.execute(sql, params).fetchall()

            # Group by (path, method) in Python for percentile calculation
            groups: dict[tuple[str, str], list[dict[str, Any]]] = {}
            for row in rows:
                key = (row["path"], row["method"])
                groups.setdefault(key, []).append(dict(row))

            def _percentile(sorted_vals: list[float], pct: float) -> float:
                if not sorted_vals:
                    return 0.0
                idx = int(len(sorted_vals) * pct / 100)
                idx = min(idx, len(sorted_vals) - 1)
                return sorted_vals[idx]

            results: list[dict[str, Any]] = []
            for (path, method), reqs in sorted(groups.items()):
                durations = sorted(r["duration_ms"] for r in reqs)
                status_counts = {"2xx": 0, "4xx": 0, "5xx": 0}
                for r in reqs:
                    sc = r["status_code"] // 100
                    if sc == 2:
                        status_counts["2xx"] += 1
                    elif sc == 4:
                        status_counts["4xx"] += 1
                    elif sc == 5:
                        status_counts["5xx"] += 1

                results.append({
                    "path": path,
                    "method": method,
                    "request_count": len(reqs),
                    "avg_ms": round(sum(durations) / len(durations), 1),
                    "p50_ms": round(_percentile(durations, 50), 1),
                    "p95_ms": round(_percentile(durations, 95), 1),
                    "p99_ms": round(_percentile(durations, 99), 1),
                    "status_2xx": status_counts["2xx"],
                    "status_4xx": status_counts["4xx"],
                    "status_5xx": status_counts["5xx"],
                })

            return results
        finally:
            conn.close()

    def count(self) -> int:
        conn = self._connect()
        try:
            return conn.execute(f"SELECT COUNT(*) FROM {self._table}").fetchone()[0]  # type: ignore[no-any-return]
        finally:
            conn.close()


class _WriterThread:
    """Background thread for batched SQLite INSERTs.

    Non-daemon so the interpreter waits for queue flush on exit.
    An atexit handler sends the stop sentinel to ensure the thread
    terminates rather than blocking indefinitely.
    """

    def __init__(
        self,
        db_path: str,
        table_name: str,
        max_rows: int,
        wal_mode: bool = True,
        batch_size: int = 50,
        flush_interval: float = 0.1,
        max_queue_size: int = 10_000,
    ) -> None:
        self._db_path = db_path
        self._table = table_name
        self._max_rows = max_rows
        self._wal_mode = wal_mode
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._max_queue_size = max_queue_size
        self._queue: queue.Queue[Transaction | object] = queue.Queue(maxsize=max_queue_size)
        self._stop_event = threading.Event()
        self._insert_count = 0
        self._thread = threading.Thread(target=self._loop, daemon=False)
        self._ensure_schema()
        self._thread.start()
        # Register graceful shutdown handler
        atexit.register(self._shutdown_handler)

    def _ensure_schema(self) -> None:
        conn = sqlite3.connect(self._db_path)
        try:
            if self._wal_mode:
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute(_CREATE_TABLE.format(table=self._table))
            for idx_sql in _CREATE_INDEXES:
                conn.execute(idx_sql.format(table=self._table))
            conn.commit()
        finally:
            conn.close()

    def enqueue(self, transaction: Transaction) -> None:
        """Enqueue a transaction for writing. Drops transaction if queue is full."""
        try:
            self._queue.put_nowait(transaction)
        except queue.Full:
            logger.warning(
                "SQLite write queue full (%d items), dropping transaction %s",
                self._max_queue_size,
                transaction.request_id,
            )

    def _shutdown_handler(self) -> None:
        """Ensure queue flush on process exit."""
        if not self._stop_event.is_set():
            self.close_sync()

    def close_sync(self) -> None:
        """Synchronous close for atexit handlers."""
        self.stop()

    def _loop(self) -> None:
        conn = sqlite3.connect(self._db_path)
        try:
            if self._wal_mode:
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("PRAGMA synchronous=NORMAL")

            insert_sql = _INSERT.format(table=self._table)

            while True:
                batch: list[tuple] = []  # type: ignore[type-arg]
                try:
                    item = self._queue.get(timeout=self._flush_interval)
                    if item is _SENTINEL:
                        break
                    batch.append(_txn_to_row(item, self._table))  # type: ignore[arg-type]
                except queue.Empty:
                    continue
                except Exception as e:
                    logger.error("Failed to process queue item: %s", e)
                    continue

                # Drain up to batch_size
                while len(batch) < self._batch_size:
                    try:
                        item = self._queue.get_nowait()
                        if item is _SENTINEL:
                            if batch:
                                try:
                                    conn.executemany(insert_sql, batch)
                                    conn.commit()
                                    self._insert_count += len(batch)
                                except sqlite3.Error as e:
                                    logger.error("SQLite insert failed during sentinel: %s", e)
                            try:
                                self._maybe_prune(conn)
                            except sqlite3.Error as e:
                                logger.error("SQLite pruning failed during sentinel: %s", e)
                            return
                        batch.append(_txn_to_row(item, self._table))  # type: ignore[arg-type]
                    except queue.Empty:
                        break
                    except Exception as e:
                        logger.error("Failed to drain queue item: %s", e)
                        break

                if batch:
                    try:
                        conn.executemany(insert_sql, batch)
                        conn.commit()
                        self._insert_count += len(batch)
                    except sqlite3.Error as e:
                        logger.error("SQLite insert failed: %s", e)
                        # Continue processing, don't crash thread

                if self._insert_count % 1000 < self._batch_size:
                    try:
                        self._maybe_prune(conn)
                    except sqlite3.Error as e:
                        logger.error("SQLite pruning failed: %s", e)
        except Exception as e:
            logger.exception("SQLite writer thread crashed: %s", e)
        finally:
            try:
                conn.close()
            except Exception:
                pass

    def _maybe_prune(self, conn: sqlite3.Connection) -> None:
        count = conn.execute(
            f"SELECT COUNT(*) FROM {self._table}"
        ).fetchone()[0]
        if count > self._max_rows:
            excess = count - self._max_rows
            conn.execute(
                f"""DELETE FROM {self._table} WHERE id IN (
                    SELECT id FROM {self._table}
                    ORDER BY timestamp_unix ASC LIMIT ?
                )""",
                (excess,),
            )
            conn.commit()

    def stop(self) -> None:
        self._stop_event.set()
        self._queue.put(_SENTINEL)
        self._thread.join(timeout=5.0)


class SQLiteBackend:
    """SQLite-backed persistent storage for HTTP transactions.

    Uses a background writer thread for non-blocking inserts and
    a separate reader for queries.
    """

    def __init__(
        self,
        db_path: str | None = None,
        table_name: str = "requests",
        max_rows: int = 100_000,
        wal_mode: bool = True,
        max_queue_size: int = 10_000,
    ) -> None:
        if db_path is None:
            db_path = default_db_path()
        self._db_path = db_path
        self._table = table_name
        self._writer = _WriterThread(
            db_path=db_path,
            table_name=table_name,
            max_rows=max_rows,
            wal_mode=wal_mode,
            max_queue_size=max_queue_size,
        )
        self._reader = SQLiteReader(db_path=db_path, table_name=table_name)

    async def write(self, transaction: Transaction) -> None:
        self._writer.enqueue(transaction)

    async def close(self) -> None:
        self._writer.stop()

    # Reader delegations
    def get_recent(self, **kwargs: Any) -> list[dict[str, Any]]:
        return self._reader.get_recent(**kwargs)

    def get_since(self, timestamp: float, **kwargs: Any) -> list[dict[str, Any]]:
        return self._reader.get_since(timestamp, **kwargs)

    def get_by_id(self, request_id: str) -> dict[str, Any] | None:
        return self._reader.get_by_id(request_id)

    def get_stats(self, minutes: int = 60) -> RequestStats:
        return self._reader.get_stats(minutes)

    def search_requests(self, query: str, **kwargs: Any) -> list[dict[str, Any]]:
        return self._reader.search_requests(query, **kwargs)

    def get_error_summary(self, minutes: int = 5) -> dict[str, Any]:
        return self._reader.get_error_summary(minutes)

    def get_endpoint_stats(self, **kwargs: Any) -> list[dict[str, Any]]:
        return self._reader.get_endpoint_stats(**kwargs)

    def count(self) -> int:
        return self._reader.count()
