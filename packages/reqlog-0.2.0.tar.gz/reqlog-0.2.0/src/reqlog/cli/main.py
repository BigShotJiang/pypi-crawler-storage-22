from __future__ import annotations

import csv
import json
import re
import sys
import time
from datetime import datetime, timezone
from typing import Any

import click

from reqlog.backends.sqlite import SQLiteReader, default_db_path


def _parse_since(value: str) -> float:
    """Parse a 'since' value into a Unix timestamp.

    Supports ISO format (2026-02-14T12:00:00) or relative format
    (e.g., "1 hour ago", "30 minutes ago", "2 days ago").
    """
    # Try ISO format first
    try:
        dt = datetime.fromisoformat(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.timestamp()
    except ValueError:
        pass

    # Try relative format: "N hours/minutes/days ago"
    match = re.match(r"(\d+)\s+(hour|minute|day|min)s?\s+ago", value, re.IGNORECASE)
    if match:
        amount = int(match.group(1))
        unit = match.group(2).lower()
        seconds_map = {"hour": 3600, "minute": 60, "min": 60, "day": 86400}
        return time.time() - (amount * seconds_map[unit])

    raise click.BadParameter(f"Cannot parse time: {value!r}. Use ISO format or 'N hours/minutes/days ago'.")


@click.group()
@click.version_option(package_name="reqlog")
def cli() -> None:
    """reqlog — Query and visualize HTTP request logs."""


@cli.command()
@click.option("--db", default=None, help="Path to SQLite database (default: .reqlog/reqlog.db).")
@click.option("--status", type=int, default=None, help="Filter by status code.")
@click.option("--path", default=None, help="Filter by path (substring match).")
@click.option("--method", default=None, help="Filter by HTTP method.")
@click.option("--slow", type=float, default=None, help="Show only requests slower than N ms.")
@click.option("--limit", type=int, default=50, help="Number of recent entries to show initially.")
def tail(db: str | None, status: int | None, path: str | None, method: str | None, slow: float | None, limit: int) -> None:
    """Live-tail HTTP request logs from SQLite database."""
    if db is None:
        db = default_db_path()
    try:
        from rich.console import Console
    except ImportError:
        click.echo("Rich is required for the tail command.", err=True)
        sys.exit(1)

    console = Console(stderr=True)
    reader = SQLiteReader(db_path=db)

    filters: dict[str, Any] = {}
    if status is not None:
        filters["status_filter"] = status
    if path is not None:
        filters["path_filter"] = path
    if method is not None:
        filters["method_filter"] = method
    if slow is not None:
        filters["min_duration"] = slow

    # Show recent entries first
    recent = reader.get_recent(limit=limit, **filters)
    for row in reversed(recent):  # oldest first
        _print_row(console, row)

    last_ts = recent[0]["timestamp_unix"] if recent else time.time()
    total = len(recent)

    console.print(f"\n[dim]Tailing {db} (Ctrl+C to stop)...[/dim]\n", highlight=False)

    try:
        while True:
            time.sleep(0.5)
            new_rows = reader.get_since(last_ts, **filters)
            for row in new_rows:
                _print_row(console, row)
                total += 1
                last_ts = max(last_ts, row["timestamp_unix"])
    except KeyboardInterrupt:
        console.print(f"\n[dim]Total: {total} requests shown.[/dim]", highlight=False)


def _print_row(console: Any, row: dict[str, Any]) -> None:
    """Print a single row in compact colored format."""
    from rich.text import Text

    from reqlog.formatters.compact_formatter import (
        METHOD_COLORS,
        STATUS_COLORS,
        STATUS_GLYPHS,
        _format_duration,
        _timing_style,
    )

    sc = f"{row['status_code'] // 100}xx"
    method_color = METHOD_COLORS.get(row["method"], "#c9d1d9")
    status_color = STATUS_COLORS.get(sc, "#c9d1d9")
    glyph = STATUS_GLYPHS.get(sc, "●")
    timing_color = _timing_style(row["duration_ms"])
    duration = _format_duration(row["duration_ms"])

    req_path = row["path"]
    if row.get("query_string"):
        req_path = f"{req_path}?{row['query_string']}"
    if len(req_path) > 45:
        req_path = req_path[:44] + "\u2026"

    line = Text()
    line.append(f"  {glyph} ", style=status_color)
    line.append(f"{row['method']:<7}", style=f"bold {method_color}")
    line.append(f" {req_path:<45}", style="#c9d1d9")
    line.append(f" {row['status_code']:>3}", style=f"bold {status_color}")
    line.append(f"  {duration:>6}", style=timing_color)
    ts_str = row.get("timestamp", "")[:19].split("T")[-1] if row.get("timestamp") else ""
    line.append(f"   {ts_str}", style="#484f58")
    console.print(line)


@cli.command()
@click.option("--db", default=None, help="Path to SQLite database (default: .reqlog/reqlog.db).")
@click.option("--format", "fmt", type=click.Choice(["json", "csv"]), default="json", help="Output format.")
@click.option("--since", default=None, help="Filter entries since (ISO format or 'N hours/minutes/days ago').")
@click.option("--status", type=int, default=None, help="Filter by status code.")
@click.option("--path", default=None, help="Filter by path (substring match).")
@click.option("--method", default=None, help="Filter by HTTP method.")
@click.option("--limit", type=int, default=1000, help="Maximum number of entries.")
def export(db: str | None, fmt: str, since: str | None, status: int | None, path: str | None, method: str | None, limit: int) -> None:
    """Export HTTP request logs to JSON or CSV."""
    if db is None:
        db = default_db_path()
    reader = SQLiteReader(db_path=db)

    filters: dict[str, Any] = {}
    if status is not None:
        filters["status_filter"] = status
    if path is not None:
        filters["path_filter"] = path
    if method is not None:
        filters["method_filter"] = method

    if since:
        ts = _parse_since(since)
        rows = reader.get_since(ts, **filters)
        rows = rows[:limit]
    else:
        rows = reader.get_recent(limit=limit, **filters)
        rows = list(reversed(rows))  # chronological order

    if fmt == "json":
        for row in rows:
            click.echo(json.dumps(row, default=str))
    elif fmt == "csv":
        if not rows:
            return
        fields = ["id", "timestamp", "method", "path", "status_code", "duration_ms", "client_ip"]
        writer = csv.DictWriter(sys.stdout, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


@cli.command()
@click.option("--db", default=None, help="Path to SQLite database (default: .reqlog/reqlog.db).")
@click.option("--minutes", type=int, default=60, help="Time window in minutes.")
def stats(db: str | None, minutes: int) -> None:
    """Show aggregated statistics from the request log."""
    if db is None:
        db = default_db_path()
    try:
        from rich.console import Console
        from rich.table import Table
    except ImportError:
        click.echo("Rich is required for the stats command.", err=True)
        sys.exit(1)

    console = Console(stderr=True)
    reader = SQLiteReader(db_path=db)
    s = reader.get_stats(minutes=minutes)

    if s.total_requests == 0:
        console.print(f"[dim]No requests found in the last {minutes} minutes.[/dim]")
        return

    # Summary
    console.print(f"\n[bold]Request Stats[/bold] (last {minutes} min)\n")
    console.print(f"  Total requests: [bold]{s.total_requests}[/bold]")
    console.print(f"  Avg duration:   [bold]{s.avg_duration_ms:.1f}ms[/bold]")
    console.print(f"  P50:            {s.p50_duration_ms:.1f}ms")
    console.print(f"  P95:            {s.p95_duration_ms:.1f}ms")
    console.print(f"  P99:            {s.p99_duration_ms:.1f}ms")

    # Status breakdown
    if s.status_counts:
        console.print()
        t = Table(title="Status Codes", show_header=True)
        t.add_column("Class", style="bold")
        t.add_column("Count", justify="right")
        for cls, cnt in sorted(s.status_counts.items()):
            t.add_row(cls, str(cnt))
        console.print(t)

    # Method breakdown
    if s.method_counts:
        console.print()
        t = Table(title="HTTP Methods", show_header=True)
        t.add_column("Method", style="bold")
        t.add_column("Count", justify="right")
        for meth, cnt in sorted(s.method_counts.items()):
            t.add_row(meth, str(cnt))
        console.print(t)

    # Slowest endpoints
    if s.slowest_endpoints:
        console.print()
        t = Table(title="Top 10 Slowest Endpoints", show_header=True)
        t.add_column("Method", style="bold")
        t.add_column("Path")
        t.add_column("Count", justify="right")
        t.add_column("Avg (ms)", justify="right")
        t.add_column("Max (ms)", justify="right")
        for ep in s.slowest_endpoints:
            t.add_row(ep["method"], ep["path"], str(ep["count"]), str(ep["avg_ms"]), str(ep["max_ms"]))
        console.print(t)


@cli.command()
@click.option("--db", default=None, help="Path to SQLite database (default: .reqlog/reqlog.db).")
@click.option("--redact-bodies", is_flag=True, default=False, help="Strip request/response bodies from MCP responses.")
def mcp(db: str | None, redact_bodies: bool) -> None:
    """Start the reqlog MCP server (stdio transport)."""
    import os

    if db is None:
        db = default_db_path()
    if not os.path.exists(db):
        click.echo(f"Error: Database file not found: {db}", err=True)
        click.echo("Make sure your application is configured with SQLiteBackend and has recorded some requests.", err=True)
        sys.exit(1)

    try:
        from reqlog.mcp import check_mcp_available

        check_mcp_available()
    except ImportError as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    from reqlog.mcp.server import create_server

    server = create_server(db_path=db, redact_bodies=redact_bodies)
    try:
        server.run(transport="stdio")
    except KeyboardInterrupt:
        pass


