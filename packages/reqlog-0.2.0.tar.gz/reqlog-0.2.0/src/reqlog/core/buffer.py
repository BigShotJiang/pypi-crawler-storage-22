from __future__ import annotations

import threading
from collections import deque
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from reqlog.core.models import Transaction


class BoundedRingBuffer:
    """Thread-safe bounded ring buffer backed by collections.deque."""

    def __init__(self, max_size: int = 1000) -> None:
        self._buffer: deque[Transaction] = deque(maxlen=max_size)
        self._lock = threading.Lock()

    def append(self, item: Transaction) -> None:
        with self._lock:
            self._buffer.append(item)

    def get_all(self) -> list[Transaction]:
        with self._lock:
            return list(self._buffer)

    def get_recent(self, n: int) -> list[Transaction]:
        with self._lock:
            items = list(self._buffer)
            return items[-n:] if n < len(items) else items

    def clear(self) -> None:
        with self._lock:
            self._buffer.clear()

    def __len__(self) -> int:
        with self._lock:
            return len(self._buffer)
