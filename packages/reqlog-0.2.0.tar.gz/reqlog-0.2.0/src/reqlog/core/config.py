"""Configuration system for reqlog.

Provides ReqlogConfig, a dataclass with sensible defaults for all reqlog settings.
Supports environment variable overrides via REQLOG_* prefix and validates
values on initialization. Format auto-detection selects the best output format
based on the runtime environment (AI tool, TTY, or headless).
"""

from __future__ import annotations

import logging
import os
import sys
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


def _default_exclude_paths() -> list[str]:
    return ["/health", "/healthz", "/ready", "/readyz", "/metrics", "/favicon.ico"]


def _default_exclude_methods() -> list[str]:
    return ["OPTIONS"]


def _default_sanitize_headers() -> list[str]:
    return ["Authorization", "Cookie", "Set-Cookie", "X-API-Key", "X-Auth-Token"]


def _default_sanitize_body_fields() -> list[str]:
    return [
        "password", "passwd", "secret", "token",
        "access_token", "refresh_token",
        "ssn", "credit_card", "card_number",
    ]


@dataclass
class ReqlogConfig:
    """Configuration for reqlog middleware and backends.

    All fields support environment variable overrides via ``REQLOG_*`` prefix
    (e.g. ``REQLOG_CAPTURE_BODY=true``). Validated on initialization.
    """

    # Capture
    capture_body: bool = False  # Log request/response bodies (opt-in for performance)
    capture_headers: bool = False  # Log request/response headers
    max_body_size: int = 64_000  # Truncate bodies larger than this (bytes); max 100MB
    capture_content_types: list[str] = field(  # Content-Types eligible for body capture
        default_factory=lambda: [
            "application/json",
            "application/xml",
            "text/*",
            "application/x-www-form-urlencoded",
        ]
    )

    # Output
    format: str | None = None  # "compact" | "verbose" | "panel" | "ai" | "json" | None (auto-detect)
    backends: list[Any] = field(default_factory=list)  # Backend instances; empty = auto ConsoleBackend

    # Filtering
    exclude_paths: list[str] = field(default_factory=_default_exclude_paths)  # Glob patterns to skip
    exclude_methods: list[str] = field(default_factory=_default_exclude_methods)  # HTTP methods to skip
    exclude_status_codes: list[int] = field(default_factory=list)  # Exact status codes to skip
    include_paths: list[str] | None = None  # If set, only log requests matching these patterns

    # Sampling
    sample_rate: float = 1.0  # 1.0 = log all, 0.1 = 10% random sampling; must be 0.0–1.0

    # Security
    sanitize_headers: list[str] = field(default_factory=_default_sanitize_headers)  # Glob patterns for header redaction
    sanitize_body_fields: list[str] = field(default_factory=_default_sanitize_body_fields)  # Field names for recursive JSON redaction

    # SQLite Backend
    sqlite_max_queue_size: int = 10_000  # Max queued writes before dropping; prevents OOM under load

    # Request ID
    generate_request_id: bool = True  # Auto-generate request IDs when not present in headers
    request_id_header: str = "X-Request-ID"  # Header to extract/propagate request IDs

    def __post_init__(self) -> None:
        self._apply_env_overrides()
        self._validate()

    def _apply_env_overrides(self) -> None:
        env_map: dict[str, tuple[str, type]] = {
            "REQLOG_CAPTURE_BODY": ("capture_body", bool),
            "REQLOG_CAPTURE_HEADERS": ("capture_headers", bool),
            "REQLOG_FORMAT": ("format", str),
            "REQLOG_SAMPLE_RATE": ("sample_rate", float),
            "REQLOG_MAX_BODY_SIZE": ("max_body_size", int),
            "REQLOG_EXCLUDE_PATHS": ("exclude_paths", list),
            "REQLOG_EXCLUDE_METHODS": ("exclude_methods", list),
            "REQLOG_REQUEST_ID_HEADER": ("request_id_header", str),
            "REQLOG_SQLITE_MAX_QUEUE_SIZE": ("sqlite_max_queue_size", int),
        }
        for env_key, (attr, typ) in env_map.items():
            val = os.environ.get(env_key)
            if val is None:
                continue
            match typ:
                case t if t is bool:
                    object.__setattr__(self, attr, val.lower() in ("true", "1", "yes"))
                case t if t is float:
                    object.__setattr__(self, attr, float(val))
                case t if t is int:
                    object.__setattr__(self, attr, int(val))
                case t if t is list:
                    object.__setattr__(self, attr, [s.strip() for s in val.split(",")])
                case _:
                    object.__setattr__(self, attr, val)

    def _validate(self) -> None:
        """Validate configuration values."""
        if not (0.0 <= self.sample_rate <= 1.0):
            raise ValueError(
                f"sample_rate must be between 0.0 and 1.0, got {self.sample_rate}"
            )

        if self.max_body_size < 0:
            raise ValueError(
                f"max_body_size must be positive, got {self.max_body_size}"
            )

        if self.max_body_size > 100_000_000:  # 100MB
            logger.warning(
                "max_body_size is very large (%d bytes), may cause memory issues",
                self.max_body_size
            )

        if self.sqlite_max_queue_size < 1:
            raise ValueError(
                f"sqlite_max_queue_size must be positive, got {self.sqlite_max_queue_size}"
            )

    def resolve_format(self) -> str:
        if self.format is not None:
            return self.format

        if env_fmt := os.environ.get("REQLOG_FORMAT"):
            return env_fmt

        if os.environ.get("CLAUDE_CODE"):
            return "ai"
        if os.environ.get("CURSOR_SESSION"):
            return "ai"
        if os.environ.get("AIDER"):
            return "ai"

        if sys.stderr.isatty():
            return "compact"

        return "json"
