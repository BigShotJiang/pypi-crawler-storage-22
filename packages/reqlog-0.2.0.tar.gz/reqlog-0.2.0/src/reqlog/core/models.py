"""Core data models for HTTP transaction logging.

Defines the immutable dataclasses that flow through the entire reqlog pipeline:
Request, Response, and Transaction. All use frozen=True and slots=True for
immutability and memory efficiency.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass(frozen=True, slots=True)
class Request:
    """Captured HTTP request data.

    Attributes:
        method: HTTP method (GET, POST, etc.).
        path: URL path without query string.
        query_string: Raw query string (without leading '?').
        headers: Request headers (populated when capture_headers=True).
        body: Raw request body bytes (populated when capture_body=True).
        client_ip: Client IP address from ASGI scope or Django META.
        user_agent: User-Agent header value.
        content_type: Content-Type header value.
    """

    method: str
    path: str
    query_string: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    body: bytes | None = None
    client_ip: str = ""
    user_agent: str = ""
    content_type: str = ""


@dataclass(frozen=True, slots=True)
class Response:
    """Captured HTTP response data.

    Attributes:
        status_code: HTTP status code (e.g. 200, 404, 500).
        headers: Response headers (populated when capture_headers=True).
        body: Raw response body bytes (populated when capture_body=True).
        content_type: Content-Type header value.
    """

    status_code: int
    headers: dict[str, str] = field(default_factory=dict)
    body: bytes | None = None
    content_type: str = ""


@dataclass(frozen=True, slots=True)
class Transaction:
    """A complete HTTP request-response pair with timing metadata.

    This is the central data type that flows through Pipeline → Backends → Formatters.
    Created by middleware after the response is sent, then passed through the pipeline
    for filtering, sanitization, and dispatch to backends.

    Attributes:
        request: The captured HTTP request.
        response: The captured HTTP response.
        duration_ms: Time from request start to response completion in milliseconds.
        timestamp: UTC timestamp when the transaction was recorded.
        request_id: Unique identifier — extracted from X-Request-ID header or auto-generated.
    """

    request: Request
    response: Response
    duration_ms: float
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    request_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])

    @property
    def status_class(self) -> str:
        match self.response.status_code // 100:
            case 2:
                return "2xx"
            case 3:
                return "3xx"
            case 4:
                return "4xx"
            case 5:
                return "5xx"
            case _:
                return "other"
