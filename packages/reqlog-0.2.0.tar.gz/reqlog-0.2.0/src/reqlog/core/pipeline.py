"""Request processing pipeline: Filter → Sanitize → Dispatch.

The Pipeline is the core processing engine that sits between middleware and backends.
It decides whether to log a transaction (filtering), redacts sensitive data
(sanitization), and fans out to all configured backends concurrently with error
isolation.
"""

from __future__ import annotations

import asyncio
import logging
import random
from fnmatch import fnmatch
from typing import Any

from reqlog.core.config import ReqlogConfig
from reqlog.core.models import Transaction
from reqlog.sanitize.redact import sanitize_transaction

logger = logging.getLogger("reqlog")


class Pipeline:
    """Filter -> Sanitize -> Dispatch pipeline for transactions."""

    def __init__(self, config: ReqlogConfig, backends: list[Any] | None = None) -> None:
        self.config = config
        self.backends: list[Any] = backends if backends is not None else config.backends

    def should_log(self, transaction: Transaction) -> bool:
        req = transaction.request

        # Sampling
        if self.config.sample_rate < 1.0 and random.random() > self.config.sample_rate:
            return False

        # Method exclusion
        if req.method in self.config.exclude_methods:
            return False

        # Path exclusion
        for pattern in self.config.exclude_paths:
            if fnmatch(req.path, pattern) or req.path == pattern:
                return False

        # Include paths (if set, only log these)
        if self.config.include_paths is not None:
            matched = any(
                fnmatch(req.path, pattern) or req.path == pattern
                for pattern in self.config.include_paths
            )
            if not matched:
                return False

        # Status code exclusion
        if transaction.response.status_code in self.config.exclude_status_codes:
            return False

        return True

    def sanitize(self, transaction: Transaction) -> Transaction:
        return sanitize_transaction(
            transaction,
            self.config.sanitize_headers,
            self.config.sanitize_body_fields,
        )

    async def process(self, transaction: Transaction) -> None:
        """Filter -> sanitize -> dispatch to all backends."""
        if not self.should_log(transaction):
            return

        sanitized = self.sanitize(transaction)
        await self._dispatch(sanitized)

    async def _dispatch(self, transaction: Transaction) -> None:
        """Fan out to all backends concurrently with error isolation."""
        tasks = [self._safe_write(backend, transaction) for backend in self.backends]
        if tasks:
            await asyncio.gather(*tasks)

    @staticmethod
    async def _safe_write(backend: Any, transaction: Transaction) -> None:
        try:
            await backend.write(transaction)
        except Exception:
            logger.exception("Backend %s failed to write transaction", type(backend).__name__)

    async def close_backends(self) -> None:
        """Close all backends that implement the close() method."""
        for backend in self.backends:
            if hasattr(backend, 'close'):
                try:
                    await backend.close()
                except Exception:
                    logger.exception("Failed to close backend %s", type(backend).__name__)
