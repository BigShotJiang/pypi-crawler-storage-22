from __future__ import annotations

import json

from reqlog.core.models import Transaction
from reqlog.formatters.text_format import format_duration as _shared_format_duration


def format_ai_line(transaction: Transaction, max_body_length: int = 1000) -> str:
    """Format a Transaction as a token-efficient plain-text string for AI consumption."""
    txn = transaction
    time_str = txn.timestamp.strftime("%H:%M:%S")
    duration = _format_duration(txn.duration_ms)

    path = txn.request.path
    if txn.request.query_string:
        path = f"{path}?{txn.request.query_string}"

    line = f"[{time_str}] {txn.request.method} {path} \u2192 {txn.response.status_code} ({duration})"

    req_body = _decode_body_compact(txn.request.body, max_body_length)
    if req_body is not None:
        line += f"\n  Req: {req_body}"

    res_body = _decode_body_compact(txn.response.body, max_body_length)
    if res_body is not None:
        line += f"\n  Res: {res_body}"

    line += "\n---"
    return line


def _format_duration(duration_ms: float) -> str:
    return _shared_format_duration(duration_ms)


def _decode_body_compact(body: bytes | None, max_length: int = 1000) -> str | None:
    if body is None:
        return None

    try:
        text = body.decode("utf-8")
    except UnicodeDecodeError:
        return f"<binary {len(body)} bytes>"

    # Try to re-serialize JSON compactly
    try:
        parsed = json.loads(text)
        compact = json.dumps(parsed, separators=(",", ":"), default=str)
    except (json.JSONDecodeError, TypeError, ValueError):
        compact = text

    if len(compact) > max_length:
        return compact[: max_length - 1] + "\u2026"
    return compact
