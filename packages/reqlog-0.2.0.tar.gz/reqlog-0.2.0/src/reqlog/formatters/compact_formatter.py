from __future__ import annotations

from rich.text import Text

from reqlog.core.models import Transaction

# ── Refined palette — GitHub Dark / VS Code inspired ──────────────────────

METHOD_COLORS: dict[str, str] = {
    "GET": "#58a6ff",
    "POST": "#3fb950",
    "PUT": "#d29922",
    "PATCH": "#d29922",
    "DELETE": "#f85149",
    "OPTIONS": "#8b949e",
    "HEAD": "#8b949e",
}

STATUS_COLORS: dict[str, str] = {
    "2xx": "#3fb950",
    "3xx": "#58a6ff",
    "4xx": "#d29922",
    "5xx": "#f85149",
}

STATUS_GLYPHS: dict[str, str] = {
    "2xx": "●",
    "3xx": "●",
    "4xx": "●",
    "5xx": "✗",
}


def _timing_style(duration_ms: float) -> str:
    if duration_ms < 100:
        return "#3fb950"
    if duration_ms < 500:
        return "#d29922"
    return "#f85149"


def _format_duration(duration_ms: float) -> str:
    if duration_ms >= 1000:
        return f"{duration_ms / 1000:.1f}s"
    return f"{duration_ms:.0f}ms"


class CompactLine:
    """Morgan-like one-liner Rich renderable with status glyphs and refined palette."""

    def __init__(self, transaction: Transaction) -> None:
        self.txn = transaction

    def __rich__(self) -> Text:
        txn = self.txn
        sc = txn.status_class
        method_color = METHOD_COLORS.get(txn.request.method, "#c9d1d9")
        status_color = STATUS_COLORS.get(sc, "#c9d1d9")
        glyph = STATUS_GLYPHS.get(sc, "●")
        timing_color = _timing_style(txn.duration_ms)

        path = txn.request.path
        if txn.request.query_string:
            path = f"{path}?{txn.request.query_string}"
        if len(path) > 45:
            path = path[:44] + "\u2026"

        duration = _format_duration(txn.duration_ms)

        line = Text()
        line.append(f"  {glyph} ", style=status_color)
        line.append(f"{txn.request.method:<7}", style=f"bold {method_color}")
        line.append(f" {path:<45}", style="#c9d1d9")
        line.append(f" {txn.response.status_code:>3}", style=f"bold {status_color}")
        line.append(f"  {duration:>6}", style=timing_color)
        line.append(f"   {txn.timestamp.strftime('%H:%M:%S')}", style="#484f58")
        return line
