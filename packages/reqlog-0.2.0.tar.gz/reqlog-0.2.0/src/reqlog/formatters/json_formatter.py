from __future__ import annotations

import json
from typing import Any

from reqlog.core.models import Transaction


def format_json_line(transaction: Transaction) -> str:
    """Format a Transaction as a single JSON-Lines string."""
    data: dict[str, Any] = {
        "timestamp": transaction.timestamp.isoformat(),
        "request_id": transaction.request_id,
        "method": transaction.request.method,
        "path": transaction.request.path,
        "query_string": transaction.request.query_string or None,
        "status_code": transaction.response.status_code,
        "duration_ms": round(transaction.duration_ms, 2),
        "client_ip": transaction.request.client_ip or None,
        "user_agent": transaction.request.user_agent or None,
    }

    if transaction.request.headers:
        data["request_headers"] = transaction.request.headers
    if transaction.request.body is not None:
        data["request_body"] = _decode_body(transaction.request.body)
    if transaction.response.headers:
        data["response_headers"] = transaction.response.headers
    if transaction.response.body is not None:
        data["response_body"] = _decode_body(transaction.response.body)

    return json.dumps(data, default=str)


def _decode_body(body: bytes) -> str | None:
    try:
        return body.decode("utf-8")
    except UnicodeDecodeError:
        return f"<binary {len(body)} bytes>"
