"""v2 verbose formatter — Claude Code-inspired columnar panel.

Two-column layout: Request | Response, separated by a vertical bar.
Aligned rows: headers at the same level, bodies at the same level.
Body content wrapped in sub-panels with size subtitles.
Adaptive JSON rendering: progressive indent reduction + line truncation.
Use with format="panel".
"""

from __future__ import annotations

import json

from rich.box import ROUNDED, Box
from rich.console import Group
from rich.padding import Padding
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

from reqlog.core.models import Transaction
from reqlog.formatters.compact_formatter import (
    METHOD_COLORS,
    STATUS_COLORS,
    _format_duration,
    _timing_style,
)

# ── Design tokens ────────────────────────────────────────────────────────

ACCENT = "#8bb8a8"  # Muted teal — section labels (Claude Code-inspired)
DIM = "#6e7681"  # Dim gray — header keys, secondary info
TEXT = "#c9d1d9"  # Normal body text
MUTED = "#484f58"  # Very dim — timestamps, tertiary metadata
RULE_STYLE = "#30363d"  # Structural gray — rules, column divider

DEFAULT_MAX_BODY_LINES = 20  # Lines shown per body before truncation

# ── Grid box ─────────────────────────────────────────────────────────────
# Custom Rich Box: vertical │ between columns, horizontal ─ between rows.
# Format: 8 lines × 4 chars — (left, horizontal, column-join, right)

PANEL_GRID = Box(
    "    \n"  # top
    "  │ \n"  # head
    " ─┼─\n"  # head_row
    "  │ \n"  # mid
    " ─┼─\n"  # row  ← show_lines=True uses this between data rows
    " ─┼─\n"  # foot_row
    "  │ \n"  # foot
    "    \n"  # bottom
)

# Simpler divider for when we only need the vertical bar (no horizontal rules)
COLUMN_DIVIDER = Box(
    "    \n"  # top
    "  │ \n"  # head
    "  │ \n"  # head_row
    "  │ \n"  # mid
    "  │ \n"  # row
    "  │ \n"  # foot_row
    "  │ \n"  # foot
    "    \n"  # bottom
)

# ── Status text ──────────────────────────────────────────────────────────

HTTP_STATUS_TEXT: dict[int, str] = {
    200: "OK",
    201: "Created",
    202: "Accepted",
    204: "No Content",
    301: "Moved Permanently",
    302: "Found",
    304: "Not Modified",
    307: "Temporary Redirect",
    400: "Bad Request",
    401: "Unauthorized",
    403: "Forbidden",
    404: "Not Found",
    405: "Method Not Allowed",
    409: "Conflict",
    422: "Unprocessable Entity",
    429: "Too Many Requests",
    500: "Internal Server Error",
    502: "Bad Gateway",
    503: "Service Unavailable",
    504: "Gateway Timeout",
}

_STATUS_GLYPH: dict[str, str] = {
    "2xx": "●",
    "3xx": "●",
    "4xx": "●",
    "5xx": "✗",
}

# ── Helpers ──────────────────────────────────────────────────────────────


def _format_size(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f} KB"
    return f"{n / (1024 * 1024):.1f} MB"


def _syntax_lexer(content_type: str) -> str:
    ct = content_type.lower()
    if "json" in ct:
        return "json"
    if "xml" in ct or "html" in ct:
        return "xml"
    return "text"


def _render_body(
    body: bytes | None,
    content_type: str,
    max_lines: int = DEFAULT_MAX_BODY_LINES,
    max_bytes: int = 64_000,
) -> tuple[Syntax | Text | None, int, int]:
    """Render body with adaptive indentation and line truncation.

    Returns (renderable, byte_size, hidden_line_count).
    """
    if body is None:
        return None, 0, 0

    size = len(body)
    if size > max_bytes:
        body = body[:max_bytes]

    try:
        text = body.decode("utf-8")
    except UnicodeDecodeError:
        return Text(f"<binary {_format_size(size)}>", style=DIM), size, 0

    lexer = _syntax_lexer(content_type)
    hidden = 0

    if lexer == "json":
        try:
            parsed = json.loads(body)
        except (json.JSONDecodeError, ValueError):
            # Not valid JSON despite content-type — render as text
            lines = text.split("\n")
            if len(lines) > max_lines:
                hidden = len(lines) - max_lines
                text = "\n".join(lines[:max_lines])
            return Syntax(text, "text", theme="monokai", word_wrap=True, padding=0), size, hidden

        # Adaptive indentation: try indent=2, fall back to indent=1
        for indent in (2, 1):
            formatted = json.dumps(parsed, indent=indent, ensure_ascii=False)
            lines = formatted.split("\n")
            if len(lines) <= max_lines:
                return (
                    Syntax(formatted, "json", theme="monokai", word_wrap=True, padding=0),
                    size,
                    0,
                )

        # Still too tall — truncate at indent=1
        formatted = json.dumps(parsed, indent=1, ensure_ascii=False)
        lines = formatted.split("\n")
        hidden = len(lines) - max_lines
        text = "\n".join(lines[:max_lines])
    else:
        lines = text.split("\n")
        if len(lines) > max_lines:
            hidden = len(lines) - max_lines
            text = "\n".join(lines[:max_lines])

    return Syntax(text, lexer, theme="monokai", word_wrap=True, padding=0), size, hidden


# ── Main renderable ─────────────────────────────────────────────────────


class ColumnarPanel:
    """Claude Code-inspired two-column panel with vertical divider."""

    def __init__(
        self,
        transaction: Transaction,
        max_body_display: int = 2000,
        max_body_lines: int = DEFAULT_MAX_BODY_LINES,
    ) -> None:
        self.txn = transaction
        self.max_body_display = max_body_display
        self.max_body_lines = max_body_lines

    # ── Title (embedded in panel border) ─────────────────────────────

    def _title(self) -> Text:
        txn = self.txn
        mc = METHOD_COLORS.get(txn.request.method, TEXT)
        title = Text()
        title.append(f" {txn.request.method} ", style=f"bold {mc}")
        path = txn.request.path
        if txn.request.query_string:
            path = f"{path}?{txn.request.query_string}"
        title.append(path, style=f"bold {TEXT}")
        title.append(" ")
        return title

    # ── Status bar (full-width top row) ──────────────────────────────

    def _status_bar(self) -> Table:
        txn = self.txn
        sc = txn.status_class
        color = STATUS_COLORS.get(sc, TEXT)
        glyph = _STATUS_GLYPH.get(sc, "●")
        status_text = HTTP_STATUS_TEXT.get(txn.response.status_code, "")

        left = Text()
        left.append(f"{glyph} ", style=color)
        left.append(f"{txn.response.status_code}", style=f"bold {color}")
        left.append(f" {status_text}", style=color)

        duration = _format_duration(txn.duration_ms)
        tc = _timing_style(txn.duration_ms)
        right = Text()
        right.append(duration, style=f"bold {tc}")
        right.append(f"  {txn.timestamp.strftime('%H:%M:%S')}", style=MUTED)

        bar = Table(show_header=False, box=None, expand=True, padding=0)
        bar.add_column(ratio=1)
        bar.add_column(justify="right")
        bar.add_row(left, right)
        return bar

    # ── Row builders (for aligned layout) ────────────────────────────

    def _build_headers_group(
        self, label: str, headers: dict[str, str]
    ) -> Group:
        """Build section label + headers as a single aligned renderable."""
        parts: list[object] = [Text(label, style=f"bold {ACCENT}")]
        if headers:
            parts.append(Text(" "))  # spacer
            for name, value in headers.items():
                line = Text()
                line.append(f"{name}  ", style=DIM)
                line.append(value, style=TEXT)
                parts.append(line)
        return Group(*parts)  # type: ignore[arg-type]

    def _build_body_panels(
        self,
        req_body: bytes | None,
        req_ct: str,
        resp_body: bytes | None,
        resp_ct: str,
    ) -> tuple[Panel | Text, Panel | Text]:
        """Build both body panels with matched vertical height."""
        req_rendered, req_size, req_hidden = _render_body(
            req_body, req_ct, max_lines=self.max_body_lines
        )
        resp_rendered, resp_size, resp_hidden = _render_body(
            resp_body, resp_ct, max_lines=self.max_body_lines
        )

        # Count content lines for each side
        def _line_count(rendered: Syntax | Text | None) -> int:
            if rendered is None:
                return 0
            if isinstance(rendered, Syntax):
                return rendered.code.count("\n") + 1
            return rendered.plain.count("\n") + 1

        req_lines = _line_count(req_rendered)
        resp_lines = _line_count(resp_rendered)
        target = max(req_lines, resp_lines)

        def _pad_and_wrap(
            rendered: Syntax | Text | None,
            size: int,
            hidden: int,
            content_type: str,
            line_count: int,
        ) -> Panel | Text:
            if rendered is None:
                return Text("")

            # Pad shorter body with empty lines to match the taller one
            if line_count < target:
                pad = "\n" * (target - line_count)
                if isinstance(rendered, Syntax):
                    rendered = Syntax(
                        rendered.code + pad,
                        rendered.lexer,
                        theme="monokai",
                        word_wrap=True,
                        padding=0,
                    )
                else:
                    rendered = Text(rendered.plain + pad)

            # Subtitle: lexer type + size + optional truncation
            lexer = _syntax_lexer(content_type)
            subtitle = Text()
            if hidden > 0:
                subtitle.append(f"\u2026{hidden} lines ", style=DIM)
            if lexer != "text":
                subtitle.append(f"{lexer} ", style=DIM)
            subtitle.append(f"\u00b7 {_format_size(size)} ", style=MUTED)

            return Panel(
                rendered,
                box=ROUNDED,
                border_style=RULE_STYLE,
                subtitle=subtitle,
                subtitle_align="right",
                padding=(0, 1),
            )

        return (
            _pad_and_wrap(req_rendered, req_size, req_hidden, req_ct, req_lines),
            _pad_and_wrap(resp_rendered, resp_size, resp_hidden, resp_ct, resp_lines),
        )

    # ── Metadata footer ──────────────────────────────────────────────

    def _metadata_footer(self) -> Text | None:
        txn = self.txn
        fragments: list[str] = []
        if txn.request.client_ip:
            fragments.append(txn.request.client_ip)
        if txn.request.user_agent:
            ua = txn.request.user_agent
            if len(ua) > 40:
                ua = ua[:39] + "\u2026"
            fragments.append(ua)
        if txn.request_id:
            fragments.append(txn.request_id)
        if not fragments:
            return None
        return Text(" \u00b7 ".join(fragments), style=MUTED)

    # ── Assemble ─────────────────────────────────────────────────────

    def __rich__(self) -> Panel:
        txn = self.txn
        sc = txn.status_class
        border_color = STATUS_COLORS.get(sc, TEXT)

        parts: list[object] = []

        # 1 ── Status bar (full width)
        parts.append(self._status_bar())

        # 2 ── Columnar content with aligned rows
        has_req_headers = bool(txn.request.headers)
        has_resp_headers = bool(txn.response.headers)
        has_req_body = txn.request.body is not None
        has_resp_body = txn.response.body is not None
        has_any = has_req_headers or has_resp_headers or has_req_body or has_resp_body

        if has_any:
            # Use PANEL_GRID (with horizontal rules between rows) when we
            # have both headers and body; COLUMN_DIVIDER (vertical only)
            # when we only have one row.
            has_headers_row = has_req_headers or has_resp_headers
            has_body_row = has_req_body or has_resp_body
            use_grid = has_headers_row and has_body_row

            layout = Table(
                show_header=False,
                box=PANEL_GRID if use_grid else COLUMN_DIVIDER,
                show_edge=False,
                show_lines=use_grid,
                border_style=RULE_STYLE,
                expand=True,
                padding=(1, 1),
                pad_edge=False,
            )
            layout.add_column(ratio=1)
            layout.add_column(ratio=1)

            # Row 1: Section labels + headers (aligned)
            if has_headers_row:
                req_hdr = self._build_headers_group("Request", txn.request.headers)
                resp_hdr = self._build_headers_group("Response", txn.response.headers)
                layout.add_row(req_hdr, resp_hdr)

            # Row 2: Body panels (aligned, wrapped in ROUNDED sub-panels)
            if has_body_row:
                if not has_headers_row:
                    # No headers row — add labels above body panels
                    layout.add_row(
                        Text("Request", style=f"bold {ACCENT}"),
                        Text("Response", style=f"bold {ACCENT}"),
                    )
                req_body, resp_body = self._build_body_panels(
                    txn.request.body, txn.request.content_type,
                    txn.response.body, txn.response.content_type,
                )
                layout.add_row(req_body, resp_body)

            parts.append(Padding(layout, (1, 0, 0, 0)))
        else:
            hint = Text(
                "capture_body=True for request/response details",
                style=f"italic {MUTED}",
            )
            parts.append(Padding(hint, (1, 0, 0, 0)))

        # 3 ── Metadata footer (full width)
        footer = self._metadata_footer()
        if footer:
            parts.append(Padding(footer, (1, 0, 0, 0)))

        return Panel(
            Group(*parts),  # type: ignore[arg-type]
            title=self._title(),
            title_align="left",
            box=ROUNDED,
            border_style=border_color,
            padding=(1, 2),
            expand=True,
        )
