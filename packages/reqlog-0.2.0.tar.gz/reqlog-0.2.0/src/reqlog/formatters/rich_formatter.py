from __future__ import annotations

import json

from rich.box import ROUNDED
from rich.console import Group
from rich.padding import Padding
from rich.panel import Panel
from rich.rule import Rule
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

from reqlog.core.models import Transaction
from reqlog.formatters.compact_formatter import (
    METHOD_COLORS,
    STATUS_COLORS,
    _format_duration,
    _timing_style,
)

# ── Status text lookup ────────────────────────────────────────────────────

HTTP_STATUS_TEXT: dict[int, str] = {
    200: "OK",
    201: "Created",
    202: "Accepted",
    204: "No Content",
    301: "Moved Permanently",
    302: "Found",
    304: "Not Modified",
    307: "Temporary Redirect",
    308: "Permanent Redirect",
    400: "Bad Request",
    401: "Unauthorized",
    403: "Forbidden",
    404: "Not Found",
    405: "Method Not Allowed",
    409: "Conflict",
    422: "Unprocessable Entity",
    429: "Too Many Requests",
    500: "Internal Server Error",
    502: "Bad Gateway",
    503: "Service Unavailable",
    504: "Gateway Timeout",
}

# ── Semantic glyphs ──────────────────────────────────────────────────────

_STATUS_GLYPH: dict[str, str] = {
    "2xx": "●",
    "3xx": "●",
    "4xx": "●",
    "5xx": "✗",
}

# ── Helpers ──────────────────────────────────────────────────────────────


def _format_size(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f} KB"
    return f"{n / (1024 * 1024):.1f} MB"


def _syntax_lexer(content_type: str) -> str:
    ct = content_type.lower()
    if "json" in ct:
        return "json"
    if "xml" in ct or "html" in ct:
        return "xml"
    return "text"


def _format_body(
    body: bytes | None, content_type: str = "", max_display: int = 2000
) -> tuple[Syntax | Text | None, int]:
    """Return (renderable, byte_length). Prettifies JSON."""
    if body is None:
        return None, 0

    size = len(body)
    try:
        text = body.decode("utf-8")
    except UnicodeDecodeError:
        return Text(f"<binary {_format_size(size)}>", style="#8b949e"), size

    truncated = len(text) > max_display
    if truncated:
        text = text[:max_display]

    lexer = _syntax_lexer(content_type)

    if lexer == "json":
        try:
            parsed = json.loads(body)
            text = json.dumps(parsed, indent=2, ensure_ascii=False)
            if truncated:
                text += "\n\u2026"
        except (json.JSONDecodeError, ValueError):
            if truncated:
                text += "\n\u2026"
    elif truncated:
        text += "\n\u2026"

    return (
        Syntax(
            text,
            lexer,
            theme="monokai",
            word_wrap=True,
            padding=0,
        ),
        size,
    )


# ── Main renderable ─────────────────────────────────────────────────────


class VerbosePanel:
    """God-tier Rich renderable: status bar, section rules, syntax bodies."""

    def __init__(self, transaction: Transaction, max_body_display: int = 2000) -> None:
        self.txn = transaction
        self.max_body_display = max_body_display

    # ── Title ────────────────────────────────────────────────────────

    def _build_title(self) -> Text:
        txn = self.txn
        method_color = METHOD_COLORS.get(txn.request.method, "#c9d1d9")
        title = Text()
        title.append(f" {txn.request.method} ", style=f"bold {method_color}")
        path = txn.request.path
        if txn.request.query_string:
            path = f"{path}?{txn.request.query_string}"
        title.append(path, style="bold #c9d1d9")
        title.append(" ", style="")
        return title

    # ── Status bar ───────────────────────────────────────────────────

    def _status_bar(self) -> Table:
        txn = self.txn
        sc = txn.status_class
        status_color = STATUS_COLORS.get(sc, "#c9d1d9")
        glyph = _STATUS_GLYPH.get(sc, "●")
        status_text = HTTP_STATUS_TEXT.get(txn.response.status_code, "")

        left = Text()
        left.append(f"{glyph} ", style=status_color)
        left.append(f"{txn.response.status_code}", style=f"bold {status_color}")
        left.append(f" {status_text}", style=status_color)

        duration = _format_duration(txn.duration_ms)
        timing_color = _timing_style(txn.duration_ms)
        right = Text()
        right.append(duration, style=f"bold {timing_color}")
        right.append(f"  {txn.timestamp.strftime('%H:%M:%S')}", style="#484f58")

        bar = Table(show_header=False, box=None, expand=True, padding=0)
        bar.add_column(ratio=1)
        bar.add_column(justify="right")
        bar.add_row(left, right)
        return bar

    # ── Headers ──────────────────────────────────────────────────────

    def _headers_table(self, headers: dict[str, str]) -> Table:
        tbl = Table(
            show_header=False,
            box=None,
            padding=(0, 2),
            pad_edge=False,
        )
        tbl.add_column(style="#8b949e", min_width=18, no_wrap=True)
        tbl.add_column(style="#c9d1d9")
        for name, value in headers.items():
            tbl.add_row(name, value)
        return tbl

    # ── Body panel ───────────────────────────────────────────────────

    def _body_panel(self, body: bytes | None, content_type: str) -> Panel | Text | None:
        renderable, size = _format_body(body, content_type, self.max_body_display)
        if renderable is None:
            return None

        # Subtitle: content type + size
        lexer = _syntax_lexer(content_type)
        subtitle = Text()
        if lexer != "text":
            subtitle.append(f"{lexer} ", style="#8b949e")
        subtitle.append(f"· {_format_size(size)} ", style="#484f58")

        return Panel(
            renderable,
            box=ROUNDED,
            border_style="#30363d",
            subtitle=subtitle,
            subtitle_align="right",
            padding=(0, 1),
        )

    # ── Metadata footer ─────────────────────────────────────────────

    def _metadata_footer(self) -> Text:
        txn = self.txn
        parts: list[str] = []
        if txn.request.client_ip:
            parts.append(txn.request.client_ip)
        if txn.request.user_agent:
            ua = txn.request.user_agent
            if len(ua) > 50:
                ua = ua[:49] + "\u2026"
            parts.append(ua)
        if txn.request_id:
            parts.append(txn.request_id)

        if not parts:
            return Text("")

        return Text("  ".join(parts), style="#484f58")

    # ── Assemble ─────────────────────────────────────────────────────

    def __rich__(self) -> Panel:
        txn = self.txn
        sc = txn.status_class
        status_color = STATUS_COLORS.get(sc, "#c9d1d9")

        parts: list[object] = []

        # 1. Status bar
        parts.append(self._status_bar())

        # 2. Request section
        has_req_headers = bool(txn.request.headers)
        has_req_body = txn.request.body is not None
        if has_req_headers or has_req_body:
            parts.append(
                Padding(Rule("Request", style="#30363d", align="left"), (1, 0, 0, 0))
            )
            if has_req_headers:
                parts.append(Padding(self._headers_table(txn.request.headers), (1, 0, 0, 0)))
            if has_req_body:
                body_panel = self._body_panel(txn.request.body, txn.request.content_type)
                if body_panel is not None:
                    parts.append(Padding(body_panel, (1, 0, 0, 0)))

        # 3. Response section
        has_resp_headers = bool(txn.response.headers)
        has_resp_body = txn.response.body is not None
        if has_resp_headers or has_resp_body:
            parts.append(
                Padding(Rule("Response", style="#30363d", align="left"), (1, 0, 0, 0))
            )
            if has_resp_headers:
                parts.append(Padding(self._headers_table(txn.response.headers), (1, 0, 0, 0)))
            if has_resp_body:
                body_panel = self._body_panel(txn.response.body, txn.response.content_type)
                if body_panel is not None:
                    parts.append(Padding(body_panel, (1, 0, 0, 0)))

        # 4. Metadata footer
        footer = self._metadata_footer()
        if footer.plain.strip():
            parts.append(Padding(footer, (1, 0, 0, 0)))

        # If nothing beyond the status bar, show a subtle hint
        if len(parts) == 1:
            hint = Text("  capture_body=True for request/response details", style="#484f58 italic")
            parts.append(Padding(hint, (1, 0, 0, 0)))

        return Panel(
            Group(*parts),  # type: ignore[arg-type]
            title=self._build_title(),
            title_align="left",
            box=ROUNDED,
            border_style=status_color,
            padding=(1, 2),
            expand=True,
        )
