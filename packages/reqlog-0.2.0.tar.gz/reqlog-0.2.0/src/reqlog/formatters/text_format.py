"""Shared plain-text formatting primitives.

Type-agnostic helpers that accept plain values (not Transaction or dict).
Used by ai_formatter.py and mcp/formatting.py.
"""

from __future__ import annotations

import json


def format_duration(duration_ms: float) -> str:
    """Format milliseconds as human-readable duration."""
    if duration_ms >= 1000:
        return f"{duration_ms / 1000:.1f}s"
    return f"{duration_ms:.0f}ms"


def truncate_path(path: str, query: str = "", max_length: int = 45) -> str:
    """Truncate a URL path (with optional query string) to fit max_length."""
    full = f"{path}?{query}" if query else path
    if len(full) > max_length:
        return full[: max_length - 1] + "\u2026"
    return full


def compact_body(body_text: str | None, max_length: int = 1000) -> str | None:
    """Compact a body string (try JSON re-serialization, then truncate)."""
    if body_text is None:
        return None

    # Try to re-serialize JSON compactly
    try:
        parsed = json.loads(body_text)
        compact = json.dumps(parsed, separators=(",", ":"), default=str)
    except (json.JSONDecodeError, TypeError, ValueError):
        compact = body_text

    if len(compact) > max_length:
        return compact[: max_length - 1] + "\u2026"
    return compact


def format_compact_line(
    method: str,
    path: str,
    query: str,
    status_code: int,
    duration_ms: float,
    timestamp_str: str,
    request_id: str = "",
) -> str:
    """Format a single compact summary line."""
    full_path = f"{path}?{query}" if query else path
    duration = format_duration(duration_ms)
    line = f"[{timestamp_str}] {method} {full_path} -> {status_code} ({duration})"
    if request_id:
        line += f" id={request_id}"
    return line


def format_detail_body(
    body: str | None,
    content_type: str | None = None,
    redact: bool = False,
    max_length: int = 500,
) -> str | None:
    """Format a body for detail view with optional redaction and truncation."""
    if body is None:
        return None

    if redact:
        size = len(body.encode("utf-8")) if isinstance(body, str) else len(body)
        return f"[REDACTED] ({size} B)"

    # Try pretty-printing JSON
    if content_type and "json" in content_type:
        try:
            parsed = json.loads(body)
            pretty = json.dumps(parsed, indent=2, default=str)
            if len(pretty) > max_length:
                return pretty[: max_length - 1] + "\u2026"
            return pretty
        except (json.JSONDecodeError, TypeError, ValueError):
            pass

    if len(body) > max_length:
        return body[: max_length - 1] + "\u2026"
    return body
