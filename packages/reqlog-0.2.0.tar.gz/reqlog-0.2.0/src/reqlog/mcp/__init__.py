"""reqlog MCP server package."""

from __future__ import annotations


def check_mcp_available() -> None:
    """Raise ImportError with install instructions if mcp SDK is missing."""
    try:
        import mcp  # noqa: F401
    except ImportError:
        raise ImportError(
            "MCP server requires the 'mcp' package. "
            "Install with: pip install reqlog[mcp]"
        ) from None
