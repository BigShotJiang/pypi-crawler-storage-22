"""MCP-specific formatters.

Thin adapters that extract values from SQLiteReader row dicts
and delegate to shared text_format primitives.
"""

from __future__ import annotations

from typing import Any

from reqlog.formatters.text_format import (
    compact_body,
    format_compact_line,
    format_detail_body,
    format_duration,
)


def format_compact_row(row: dict[str, Any]) -> str:
    """Format a SQLiteReader row dict as a compact one-liner."""
    ts = row.get("timestamp", "")[:19].split("T")[-1] if row.get("timestamp") else ""
    return format_compact_line(
        method=row["method"],
        path=row["path"],
        query=row.get("query_string") or "",
        status_code=row["status_code"],
        duration_ms=row["duration_ms"],
        timestamp_str=ts,
        request_id=row.get("id", ""),
    )


def format_request_detail(row: dict[str, Any], redact_bodies: bool = False) -> str:
    """Format a SQLiteReader row dict as a full detail view."""
    ts = row.get("timestamp", "")[:19].split("T")[-1] if row.get("timestamp") else ""
    lines: list[str] = []

    # Header line
    query = row.get("query_string") or ""
    full_path = f"{row['path']}?{query}" if query else row["path"]
    duration = format_duration(row["duration_ms"])
    lines.append(f"[{ts}] {row['method']} {full_path} -> {row['status_code']} ({duration})")
    lines.append(f"ID: {row.get('id', 'unknown')}")

    if row.get("client_ip"):
        lines.append(f"Client: {row['client_ip']}")
    if row.get("user_agent"):
        lines.append(f"User-Agent: {row['user_agent']}")

    # Request headers
    req_headers = row.get("request_headers")
    if req_headers:
        lines.append("")
        lines.append("--- Request Headers ---")
        if isinstance(req_headers, dict):
            for k, v in req_headers.items():
                lines.append(f"  {k}: {v}")
        elif isinstance(req_headers, str):
            lines.append(f"  {req_headers}")

    # Request body
    req_body = row.get("request_body")
    if req_body is not None:
        lines.append("")
        lines.append("--- Request Body ---")
        formatted = format_detail_body(
            req_body,
            content_type=row.get("request_content_type"),
            redact=redact_bodies,
            max_length=500,
        )
        if formatted:
            lines.append(formatted)

    # Response headers
    res_headers = row.get("response_headers")
    if res_headers:
        lines.append("")
        lines.append("--- Response Headers ---")
        if isinstance(res_headers, dict):
            for k, v in res_headers.items():
                lines.append(f"  {k}: {v}")
        elif isinstance(res_headers, str):
            lines.append(f"  {res_headers}")

    # Response body
    res_body = row.get("response_body")
    if res_body is not None:
        lines.append("")
        lines.append("--- Response Body ---")
        formatted = format_detail_body(
            res_body,
            content_type=row.get("response_content_type"),
            redact=redact_bodies,
            max_length=500,
        )
        if formatted:
            lines.append(formatted)

    return "\n".join(lines)


def format_error_summary(data: dict[str, Any]) -> str:
    """Format an error summary dict from SQLiteReader.get_error_summary()."""
    lines: list[str] = []
    lines.append(
        f"Errors: {data['total_errors']}/{data['total_requests']} requests "
        f"({data['error_rate']}% error rate)"
    )

    if not data["by_status"]:
        lines.append("No errors found.")
        return "\n".join(lines)

    lines.append("")
    for group in data["by_status"]:
        lines.append(f"HTTP {group['status_code']} ({group['count']} occurrences):")
        for req in group["requests"][:5]:  # limit to 5 per status
            ts = req.get("timestamp", "")[:19].split("T")[-1] if req.get("timestamp") else ""
            path = req.get("path", "")
            duration = format_duration(req.get("duration_ms", 0))
            rid = req.get("id", "")
            lines.append(f"  [{ts}] {req.get('method', '')} {path} ({duration}) id={rid}")
            # Show compact response body if present
            body = compact_body(req.get("response_body"), max_length=200)
            if body:
                lines.append(f"    -> {body}")
        if group["count"] > 5:
            lines.append(f"  ... and {group['count'] - 5} more")
        lines.append("")

    return "\n".join(lines).rstrip()


def format_endpoint_stats(endpoints: list[dict[str, Any]]) -> str:
    """Format endpoint stats list from SQLiteReader.get_endpoint_stats()."""
    if not endpoints:
        return "No endpoint data found."

    lines: list[str] = []
    lines.append(f"{'Method':<7} {'Path':<35} {'Count':>5} {'Avg':>7} {'P50':>7} {'P95':>7} {'P99':>7}  Status")
    lines.append("-" * 100)

    for ep in endpoints:
        status_parts = []
        if ep.get("status_2xx"):
            status_parts.append(f"2xx:{ep['status_2xx']}")
        if ep.get("status_4xx"):
            status_parts.append(f"4xx:{ep['status_4xx']}")
        if ep.get("status_5xx"):
            status_parts.append(f"5xx:{ep['status_5xx']}")
        status_str = " ".join(status_parts) if status_parts else "-"

        path = ep["path"]
        if len(path) > 35:
            path = path[:34] + "\u2026"

        lines.append(
            f"{ep['method']:<7} {path:<35} {ep['request_count']:>5} "
            f"{ep['avg_ms']:>6.0f}ms {ep['p50_ms']:>6.0f}ms "
            f"{ep['p95_ms']:>6.0f}ms {ep['p99_ms']:>6.0f}ms  {status_str}"
        )

    return "\n".join(lines)


def format_status_summary(
    stats: dict[str, Any],
    last_error_row: dict[str, Any] | None = None,
) -> str:
    """Format the reqlog://status resource content."""
    lines: list[str] = []
    lines.append(f"Total requests: {stats.get('total_requests', 0)}")

    status_counts = stats.get("status_counts", {})
    if status_counts:
        parts = [f"{k}:{v}" for k, v in sorted(status_counts.items())]
        lines.append(f"Status breakdown: {' '.join(parts)}")

    err_count = sum(v for k, v in status_counts.items() if k in ("4xx", "5xx"))
    total = stats.get("total_requests", 0)
    rate = (err_count / total * 100) if total > 0 else 0.0
    lines.append(f"Error rate: {rate:.1f}%")

    lines.append(f"Avg duration: {stats.get('avg_duration_ms', 0):.0f}ms")
    lines.append(f"P95 duration: {stats.get('p95_duration_ms', 0):.0f}ms")

    if last_error_row:
        ts = last_error_row.get("timestamp", "")[:19].split("T")[-1] if last_error_row.get("timestamp") else ""
        lines.append(
            f"Last error: [{ts}] {last_error_row.get('method', '')} "
            f"{last_error_row.get('path', '')} -> {last_error_row.get('status_code', '')}"
        )
    else:
        lines.append("Last error: none")

    return "\n".join(lines)
