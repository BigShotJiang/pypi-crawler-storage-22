"""reqlog MCP server — exposes HTTP logs to AI coding agents."""

from __future__ import annotations

import logging
import re
import time

from mcp.server.fastmcp import FastMCP

from reqlog.backends.sqlite import SQLiteReader
from reqlog.mcp.formatting import (
    format_compact_row,
    format_endpoint_stats,
    format_error_summary,
    format_request_detail,
    format_status_summary,
)

# Validation constants to prevent DoS attacks
MAX_QUERY_LIMIT = 1000
MAX_TIME_WINDOW_MINUTES = 1440  # 24 hours
MAX_SEARCH_QUERY_LENGTH = 500

logger = logging.getLogger(__name__)


def _parse_relative_time(value: str) -> float:
    """Parse relative time string like '30s', '5m', '1h', '2d' into a Unix timestamp."""
    match = re.fullmatch(r"(\d+)\s*([smhd])", value.strip())
    if not match:
        raise ValueError(f"Invalid time format: {value!r}. Use '30s', '5m', '1h', or '2d'.")
    amount = int(match.group(1))
    unit = match.group(2)
    multiplier = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    return time.time() - (amount * multiplier[unit])


def create_server(db_path: str, redact_bodies: bool = False) -> FastMCP:
    """Create and configure the reqlog MCP server."""
    mcp = FastMCP("reqlog")
    reader = SQLiteReader(db_path=db_path)

    # --- Tools ---

    @mcp.tool()
    def get_recent_requests(
        limit: int = 20,
        status: str | None = None,
        path: str | None = None,
        method: str | None = None,
        min_duration_ms: float | None = None,
        since: str | None = None,
    ) -> str:
        """Get recent HTTP requests logged by reqlog.

        Args:
            limit: Maximum number of requests to return (default 20).
            status: Filter by status class: '2xx', '3xx', '4xx', '5xx', or 'error' (4xx+5xx).
            path: Filter by path substring match.
            method: Filter by HTTP method (GET, POST, etc).
            min_duration_ms: Only show requests slower than this (milliseconds).
            since: Only show requests after this time. Supports '30s', '5m', '1h', '2d'.
        """
        # Validate limit parameter
        if limit < 1 or limit > MAX_QUERY_LIMIT:
            return f"Error: limit must be between 1 and {MAX_QUERY_LIMIT}"

        try:
            if since:
                ts = _parse_relative_time(since)
                rows = reader.get_since(
                    ts,
                    status_class=status,
                    path_filter=path,
                    method_filter=method,
                    min_duration=min_duration_ms,
                )
                rows = rows[-limit:]  # get_since returns ASC, take last N
            else:
                rows = reader.get_recent(
                    limit=limit,
                    status_class=status,
                    path_filter=path,
                    method_filter=method,
                    min_duration=min_duration_ms,
                )

            if not rows:
                return "No requests found matching the filters."

            lines = [format_compact_row(r) for r in rows]
            lines.append(f"\n({len(rows)} requests)")
            return "\n".join(lines)
        except Exception as e:
            logger.exception("MCP get_recent_requests error: %s", e)
            return "An error occurred processing your request. Check server logs."

    @mcp.tool()
    def get_request_detail(request_id: str) -> str:
        """Get full details of a specific HTTP request by ID.

        Args:
            request_id: The request ID (shown as id=... in compact output).
        """
        try:
            row = reader.get_by_id(request_id)
            if not row:
                return f"Request not found: {request_id}"
            return format_request_detail(row, redact_bodies=redact_bodies)
        except Exception as e:
            logger.exception("MCP get_request_detail error: %s", e)
            return "An error occurred processing your request. Check server logs."

    @mcp.tool()
    def get_error_summary(minutes: int = 5) -> str:
        """Get a summary of recent HTTP errors (4xx and 5xx responses).

        Args:
            minutes: Time window to analyze (default 5 minutes).
        """
        # Validate minutes parameter
        if minutes < 1 or minutes > MAX_TIME_WINDOW_MINUTES:
            return f"Error: minutes must be between 1 and {MAX_TIME_WINDOW_MINUTES}"

        try:
            data = reader.get_error_summary(minutes=minutes)
            return format_error_summary(data)
        except Exception as e:
            logger.exception("MCP get_error_summary error: %s", e)
            return "An error occurred processing your request. Check server logs."

    @mcp.tool()
    def search_requests(
        query: str,
        status: str | None = None,
        since: str | None = None,
        limit: int = 20,
    ) -> str:
        """Search HTTP request logs by keyword.

        Searches across path, request body, response body, and headers.

        Args:
            query: Search term to match (substring match).
            status: Filter by status class: '2xx', '3xx', '4xx', '5xx', or 'error'.
            since: Only search after this time. Supports '30s', '5m', '1h', '2d'.
            limit: Maximum number of results (default 20).
        """
        # Validate parameters
        if len(query) > MAX_SEARCH_QUERY_LENGTH:
            return f"Error: query too long (max {MAX_SEARCH_QUERY_LENGTH} chars)"
        if limit < 1 or limit > MAX_QUERY_LIMIT:
            return f"Error: limit must be between 1 and {MAX_QUERY_LIMIT}"

        try:
            since_ts = _parse_relative_time(since) if since else None
            rows = reader.search_requests(
                query=query,
                status_class=status,
                since=since_ts,
                limit=limit,
            )

            if not rows:
                return f"No requests found matching '{query}'."

            lines = [format_compact_row(r) for r in rows]
            lines.append(f"\n({len(rows)} results)")
            return "\n".join(lines)
        except Exception as e:
            logger.exception("MCP search_requests error: %s", e)
            return "An error occurred processing your request. Check server logs."

    @mcp.tool()
    def get_endpoint_stats(
        path: str | None = None,
        minutes: int = 60,
    ) -> str:
        """Get per-endpoint performance statistics.

        Args:
            path: Filter by path substring (optional).
            minutes: Time window to analyze (default 60 minutes).
        """
        # Validate minutes parameter
        if minutes < 1 or minutes > MAX_TIME_WINDOW_MINUTES:
            return f"Error: minutes must be between 1 and {MAX_TIME_WINDOW_MINUTES}"

        try:
            endpoints = reader.get_endpoint_stats(
                path_pattern=path,
                minutes=minutes,
            )
            return format_endpoint_stats(endpoints)
        except Exception as e:
            logger.exception("MCP get_endpoint_stats error: %s", e)
            return "An error occurred processing your request. Check server logs."

    # --- Resources ---

    @mcp.resource("reqlog://status")
    def status_resource() -> str:
        """Current reqlog session summary: total requests, error rate, last error."""
        try:
            stats_obj = reader.get_stats(minutes=60)
            stats_dict = {
                "total_requests": stats_obj.total_requests,
                "status_counts": stats_obj.status_counts,
                "avg_duration_ms": stats_obj.avg_duration_ms,
                "p95_duration_ms": stats_obj.p95_duration_ms,
            }

            # Get last error
            error_rows = reader.get_recent(limit=1, status_class="error")
            last_error = error_rows[0] if error_rows else None

            return format_status_summary(stats_dict, last_error)
        except Exception as e:
            logger.exception("MCP status_resource error: %s", e)
            return "An error occurred processing your request. Check server logs."

    @mcp.resource("reqlog://recent-errors")
    def recent_errors_resource() -> str:
        """Last 5 HTTP errors in compact format."""
        try:
            rows = reader.get_recent(limit=5, status_class="error")
            if not rows:
                return "No recent errors."
            return "\n".join(format_compact_row(r) for r in rows)
        except Exception as e:
            logger.exception("MCP recent_errors_resource error: %s", e)
            return "An error occurred processing your request. Check server logs."

    return mcp
