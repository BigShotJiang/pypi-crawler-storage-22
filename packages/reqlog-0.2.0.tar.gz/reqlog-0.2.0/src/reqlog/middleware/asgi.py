"""Pure ASGI middleware for HTTP request/response logging.

Wraps the ASGI receive/send callables to intercept request and response data
without using Starlette's BaseHTTPMiddleware, preserving streaming compatibility.
Supports body capture, header capture, and ASGI lifespan events for graceful
backend shutdown.
"""

from __future__ import annotations

import time
import uuid
from typing import Any, Callable

from reqlog.backends.console import ConsoleBackend
from reqlog.core.config import ReqlogConfig
from reqlog.core.models import Request, Response, Transaction
from reqlog.core.pipeline import Pipeline

Scope = dict[str, Any]
Receive = Callable[..., Any]
Send = Callable[..., Any]
ASGIApp = Callable[..., Any]


class ReqlogMiddleware:
    """Pure ASGI middleware — wraps receive/send without BaseHTTPMiddleware."""

    def __init__(
        self,
        app: ASGIApp,
        config: ReqlogConfig | None = None,
        *,
        capture_body: bool | None = None,
        capture_headers: bool | None = None,
        format: str | None = None,
        exclude_paths: list[str] | None = None,
        backends: list[Any] | None = None,
    ) -> None:
        self.app = app
        self.config = config or ReqlogConfig()

        # Convenience overrides
        if capture_body is not None:
            self.config.capture_body = capture_body
        if capture_headers is not None:
            self.config.capture_headers = capture_headers
        if format is not None:
            self.config.format = format
        if exclude_paths is not None:
            self.config.exclude_paths = exclude_paths

        # Resolve backends
        if backends is not None:
            resolved_backends = backends
        elif self.config.backends:
            resolved_backends = self.config.backends
        else:
            resolved_fmt = self.config.resolve_format()
            resolved_backends = [ConsoleBackend(format=resolved_fmt)]

        self.pipeline = Pipeline(self.config, backends=resolved_backends)

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "lifespan":
            await self._handle_lifespan(scope, receive, send)
            return

        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        start_time = time.perf_counter()
        request_body_chunks: list[bytes] = []
        response_body_chunks: list[bytes] = []
        response_meta: dict[str, Any] = {}
        request_body_size = 0
        response_body_size = 0

        async def receive_wrapper() -> dict[str, Any]:
            nonlocal request_body_size
            message = await receive()
            if message["type"] == "http.request" and self.config.capture_body:
                chunk = message.get("body", b"")
                chunk_len = len(chunk)
                if request_body_size + chunk_len <= self.config.max_body_size:
                    request_body_chunks.append(chunk)
                    request_body_size += chunk_len
            return message  # type: ignore[no-any-return]

        async def send_wrapper(message: dict[str, Any]) -> None:
            nonlocal response_body_size
            if message["type"] == "http.response.start":
                response_meta["status"] = message["status"]
                response_meta["headers"] = message.get("headers", [])
            elif message["type"] == "http.response.body" and self.config.capture_body:
                chunk = message.get("body", b"")
                chunk_len = len(chunk)
                if response_body_size + chunk_len <= self.config.max_body_size:
                    response_body_chunks.append(chunk)
                    response_body_size += chunk_len
            await send(message)

        await self.app(scope, receive_wrapper, send_wrapper)

        duration_ms = (time.perf_counter() - start_time) * 1000
        transaction = self._build_transaction(
            scope, request_body_chunks, response_meta, response_body_chunks, duration_ms
        )

        await self.pipeline.process(transaction)

    def _build_transaction(
        self,
        scope: Scope,
        request_body_chunks: list[bytes],
        response_meta: dict[str, Any],
        response_body_chunks: list[bytes],
        duration_ms: float,
    ) -> Transaction:
        # Extract request info from scope
        path = scope.get("path", "/")
        query_string = (scope.get("query_string") or b"").decode("latin-1")
        method = scope.get("method", "GET")

        # Extract client info
        client = scope.get("client")
        client_ip = client[0] if client else ""

        # Single-pass request header parsing
        req_headers: dict[str, str] = {}
        user_agent = ""
        content_type = ""
        request_id = ""
        request_id_header = self.config.request_id_header.lower()

        for raw_name, raw_value in scope.get("headers", []):
            name = raw_name.decode("latin-1")
            value = raw_value.decode("latin-1")
            name_lower = name.lower()

            if self.config.capture_headers:
                req_headers[name] = value

            # Extract special headers in same pass
            if name_lower == "user-agent":
                user_agent = value
            elif name_lower == "content-type":
                content_type = value
            elif name_lower == request_id_header:
                request_id = value

        if not request_id and self.config.generate_request_id:
            request_id = uuid.uuid4().hex[:12]

        request_body = b"".join(request_body_chunks) if request_body_chunks else None

        # Parse response headers
        resp_headers: dict[str, str] = {}
        resp_content_type = ""
        for raw_name, raw_value in response_meta.get("headers", []):
            name = raw_name.decode("latin-1") if isinstance(raw_name, bytes) else raw_name
            value = raw_value.decode("latin-1") if isinstance(raw_value, bytes) else raw_value
            if self.config.capture_headers:
                resp_headers[name] = value
            if name.lower() == "content-type":
                resp_content_type = value

        response_body = b"".join(response_body_chunks) if response_body_chunks else None

        return Transaction(
            request=Request(
                method=method,
                path=path,
                query_string=query_string,
                headers=req_headers,
                body=request_body,
                client_ip=client_ip,
                user_agent=user_agent,
                content_type=content_type,
            ),
            response=Response(
                status_code=response_meta.get("status", 0),
                headers=resp_headers,
                body=response_body,
                content_type=resp_content_type,
            ),
            duration_ms=duration_ms,
            request_id=request_id,
        )

    async def _handle_lifespan(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Wrap the inner app's lifespan to clean up backends on shutdown.

        We must forward lifespan events to the inner app so its startup/shutdown
        hooks (database pools, caches, background tasks) still execute.  We only
        intercept the shutdown *response* to flush our own backends first.
        """

        async def send_wrapper(message: dict[str, Any]) -> None:
            if message["type"] == "lifespan.shutdown.complete":
                # Inner app has finished its own shutdown — now flush ours.
                await self.pipeline.close_backends()
            await send(message)

        await self.app(scope, receive, send_wrapper)
