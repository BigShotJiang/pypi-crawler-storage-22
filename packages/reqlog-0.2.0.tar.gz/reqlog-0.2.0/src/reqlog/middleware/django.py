"""Django-native middleware for HTTP request/response logging.

Auto-detects sync (WSGI) vs async (ASGI) mode via asyncio.iscoroutinefunction.
In WSGI mode, logging runs in a single-worker ThreadPoolExecutor for zero-latency
impact on the request cycle. Reads configuration from Django's settings.REQLOG dict.
"""

from __future__ import annotations

import asyncio
import atexit
import logging
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from reqlog.backends.console import ConsoleBackend
from reqlog.core.config import ReqlogConfig
from reqlog.core.models import Request, Response, Transaction
from reqlog.core.pipeline import Pipeline

logger = logging.getLogger(__name__)

# Global thread pool for non-blocking sync logging.
# Using 1 worker is sufficient — logging is I/O-bound and ordering doesn't matter.
_thread_pool: ThreadPoolExecutor | None = None
_thread_pool_lock = threading.Lock()


def _get_thread_pool() -> ThreadPoolExecutor:
    """Get or create the global thread pool for async logging in sync contexts."""
    global _thread_pool
    # Double-checked locking: fast path avoids the lock entirely.
    if _thread_pool is not None:
        return _thread_pool
    with _thread_pool_lock:
        if _thread_pool is None:
            _thread_pool = ThreadPoolExecutor(
                max_workers=1,
                thread_name_prefix="reqlog-django-",
            )
            atexit.register(_shutdown_thread_pool)
    return _thread_pool


def _shutdown_thread_pool() -> None:
    """Shutdown the thread pool on process exit."""
    global _thread_pool
    if _thread_pool is not None:
        _thread_pool.shutdown(wait=True, cancel_futures=False)
        _thread_pool = None


def _get_django_config() -> dict[str, Any]:
    """Load REQLOG settings from Django settings.py if available."""
    try:
        from django.conf import settings  # type: ignore[import-untyped]
        return getattr(settings, "REQLOG", {})
    except Exception:
        return {}


def _config_from_django_settings(django_config: dict[str, Any]) -> ReqlogConfig:
    """Map Django REQLOG dict keys to ReqlogConfig fields."""
    field_map = {
        "CAPTURE_BODY": "capture_body",
        "CAPTURE_HEADERS": "capture_headers",
        "FORMAT": "format",
        "EXCLUDE_PATHS": "exclude_paths",
        "EXCLUDE_METHODS": "exclude_methods",
        "SAMPLE_RATE": "sample_rate",
        "SANITIZE_HEADERS": "sanitize_headers",
        "SANITIZE_BODY_FIELDS": "sanitize_body_fields",
        "MAX_BODY_SIZE": "max_body_size",
    }
    kwargs: dict[str, Any] = {}
    for django_key, config_key in field_map.items():
        if django_key in django_config:
            kwargs[config_key] = django_config[django_key]
    # BACKENDS is passed through directly (list of backend instances)
    if "BACKENDS" in django_config:
        kwargs["backends"] = django_config["BACKENDS"]
    return ReqlogConfig(**kwargs)


class ReqlogMiddleware:
    """Django-native middleware supporting both sync (WSGI) and async (ASGI) modes."""

    def __init__(self, get_response: Any) -> None:
        self.get_response = get_response
        django_config = _get_django_config()
        self.config = _config_from_django_settings(django_config)

        if self.config.backends:
            backends = self.config.backends
        else:
            resolved_fmt = self.config.resolve_format()
            backends = [ConsoleBackend(format=resolved_fmt)]

        self.pipeline = Pipeline(self.config, backends=backends)

        # Auto-detect async mode
        self._is_async = asyncio.iscoroutinefunction(get_response)

    def __call__(self, request: Any) -> Any:
        if self._is_async:
            return self._async_call(request)
        return self._sync_call(request)

    def _sync_call(self, request: Any) -> Any:
        start_time = time.perf_counter()
        response = self.get_response(request)
        duration_ms = (time.perf_counter() - start_time) * 1000

        transaction = self._build_transaction(request, response, duration_ms)

        # Run pipeline in background thread to avoid blocking the request
        pool = _get_thread_pool()
        future = pool.submit(self._run_pipeline_sync, transaction)
        future.add_done_callback(self._log_future_exception)

        return response

    def _run_pipeline_sync(self, transaction: Transaction) -> None:
        """Run pipeline in a thread (for sync contexts without event loop)."""
        asyncio.run(self.pipeline.process(transaction))

    def flush(self, timeout: float = 5.0) -> None:
        """Wait for all pending background logging to complete.

        Useful in tests and graceful shutdown scenarios.  Calling this after
        a request guarantees the transaction has been dispatched to all backends.
        """
        pool = _get_thread_pool()
        # Submit a no-op and wait for it — because the pool has a single worker,
        # this blocks until every previously-submitted task has finished.
        pool.submit(lambda: None).result(timeout=timeout)

    def _log_future_exception(self, future: Any) -> None:
        """Log exceptions from thread pool futures (sync contexts)."""
        try:
            future.result()
        except Exception:
            logger.exception("Django middleware background thread failed")

    async def _async_call(self, request: Any) -> Any:
        start_time = time.perf_counter()
        response = await self.get_response(request)
        duration_ms = (time.perf_counter() - start_time) * 1000

        transaction = self._build_transaction(request, response, duration_ms)
        await self.pipeline.process(transaction)

        return response

    def _build_transaction(
        self, request: Any, response: Any, duration_ms: float
    ) -> Transaction:
        # Extract headers
        req_headers: dict[str, str] = {}
        if self.config.capture_headers:
            for key, value in request.META.items():
                if key.startswith("HTTP_"):
                    header_name = key[5:].replace("_", "-").title()
                    req_headers[header_name] = value
                elif key in ("CONTENT_TYPE", "CONTENT_LENGTH"):
                    header_name = key.replace("_", "-").title()
                    req_headers[header_name] = value

        # Request body
        request_body: bytes | None = None
        content_type = request.META.get("CONTENT_TYPE", "")
        if self.config.capture_body:
            try:
                request_body = request.body
                if len(request_body) > self.config.max_body_size:
                    request_body = request_body[: self.config.max_body_size]
            except (AttributeError, IOError) as e:
                logger.debug("Failed to capture request body: %s", e)
                request_body = None
            except Exception as e:
                logger.warning("Unexpected error capturing request body: %s", e)
                request_body = None

        # Response headers
        resp_headers: dict[str, str] = {}
        resp_content_type = ""
        if hasattr(response, "headers"):
            if self.config.capture_headers:
                resp_headers = dict(response.headers)
            resp_content_type = response.headers.get("Content-Type", "")
        elif hasattr(response, "_headers"):
            if self.config.capture_headers:
                resp_headers = {k: v for k, v in response._headers.values()}
            resp_content_type = getattr(response, "content_type", "")

        # Response body
        response_body: bytes | None = None
        if self.config.capture_body and hasattr(response, "content"):
            response_body = response.content
            if len(response_body) > self.config.max_body_size:
                response_body = response_body[: self.config.max_body_size]

        # Request ID
        request_id = request.META.get(
            f"HTTP_{self.config.request_id_header.upper().replace('-', '_')}", ""
        )
        if not request_id and self.config.generate_request_id:
            request_id = uuid.uuid4().hex[:12]

        return Transaction(
            request=Request(
                method=request.method,
                path=request.path,
                query_string=request.META.get("QUERY_STRING", ""),
                headers=req_headers,
                body=request_body,
                client_ip=request.META.get("REMOTE_ADDR", ""),
                user_agent=request.META.get("HTTP_USER_AGENT", ""),
                content_type=content_type,
            ),
            response=Response(
                status_code=response.status_code,
                headers=resp_headers,
                body=response_body,
                content_type=resp_content_type,
            ),
            duration_ms=duration_ms,
            request_id=request_id,
        )
