"""Header and body field redaction for sensitive data.

Provides glob-based header redaction and recursive JSON body field redaction.
Depth-limited to 100 levels to prevent stack overflow attacks. Early-exit
optimizations skip processing when no sensitive patterns are configured.
"""

from __future__ import annotations

import json
import logging
from fnmatch import fnmatch
from typing import Any

from reqlog.core.models import Request, Response, Transaction

REDACTED = "[REDACTED]"

logger = logging.getLogger(__name__)


def redact_headers(
    headers: dict[str, str],
    sensitive_patterns: list[str],
) -> dict[str, str]:
    """Redact header values matching sensitive patterns (case-insensitive, glob support)."""
    # Early exit optimization: no patterns means no redaction needed
    if not sensitive_patterns:
        return headers

    redacted: dict[str, str] = {}
    for name, value in headers.items():
        if _header_matches(name, sensitive_patterns):
            redacted[name] = REDACTED
        else:
            redacted[name] = value
    return redacted


def _header_matches(name: str, patterns: list[str]) -> bool:
    name_lower = name.lower()
    for pattern in patterns:
        if fnmatch(name_lower, pattern.lower()):
            return True
    return False


def redact_body_fields(
    body: bytes | None,
    sensitive_fields: list[str],
    content_type: str = "",
) -> bytes | None:
    """Redact sensitive fields from JSON body content."""
    # Early exit optimizations
    if body is None or not sensitive_fields:
        return body

    if "json" not in content_type.lower():
        return body

    try:
        data = json.loads(body)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return body

    redacted = _redact_recursive(data, sensitive_fields, depth=0)
    return json.dumps(redacted).encode()


def _redact_recursive(
    data: Any,
    sensitive_fields: list[str],
    depth: int = 0,
    max_depth: int = 100,
) -> Any:
    """Recursively redact sensitive fields with depth limiting to prevent stack overflow."""
    if depth > max_depth:
        logger.warning("Max redaction depth %d exceeded, stopping recursion", max_depth)
        return data

    match data:
        case dict():
            return {
                k: REDACTED if _field_matches(k, sensitive_fields)
                   else _redact_recursive(v, sensitive_fields, depth + 1, max_depth)
                for k, v in data.items()
            }
        case list():
            return [_redact_recursive(item, sensitive_fields, depth + 1, max_depth) for item in data]
        case _:
            return data


def _field_matches(field_name: str, sensitive_fields: list[str]) -> bool:
    """Case-insensitive partial match: 'password' matches 'user_password', 'passwordHash'."""
    field_lower = field_name.lower()
    return any(pattern.lower() in field_lower for pattern in sensitive_fields)


def sanitize_transaction(
    transaction: Transaction,
    sanitize_headers_list: list[str],
    sanitize_body_fields_list: list[str],
) -> Transaction:
    """Return a new Transaction with sensitive data redacted."""
    req = transaction.request
    resp = transaction.response

    sanitized_req = Request(
        method=req.method,
        path=req.path,
        query_string=req.query_string,
        headers=redact_headers(req.headers, sanitize_headers_list) if req.headers else {},
        body=redact_body_fields(req.body, sanitize_body_fields_list, req.content_type),
        client_ip=req.client_ip,
        user_agent=req.user_agent,
        content_type=req.content_type,
    )

    sanitized_resp = Response(
        status_code=resp.status_code,
        headers=redact_headers(resp.headers, sanitize_headers_list) if resp.headers else {},
        body=redact_body_fields(resp.body, sanitize_body_fields_list, resp.content_type),
        content_type=resp.content_type,
    )

    return Transaction(
        request=sanitized_req,
        response=sanitized_resp,
        duration_ms=transaction.duration_ms,
        timestamp=transaction.timestamp,
        request_id=transaction.request_id,
    )
