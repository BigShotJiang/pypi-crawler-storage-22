import django
from django.conf import settings

# Configure Django settings before any Django imports
if not settings.configured:
    settings.configure(
        DEBUG=True,
        DATABASES={"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}},
        ROOT_URLCONF="tests.integration.test_django",
        MIDDLEWARE=[
            "reqlog.middleware.django.ReqlogMiddleware",
        ],
        REQLOG={
            "CAPTURE_BODY": False,
            "EXCLUDE_PATHS": [],
            "EXCLUDE_METHODS": [],
        },
        SECRET_KEY="test-secret-key",
        ALLOWED_HOSTS=["*"],
    )
    django.setup()

from django.http import JsonResponse
from django.test import RequestFactory
from django.urls import path

from reqlog.backends.memory import MemoryBackend
from reqlog.middleware.django import ReqlogMiddleware


def index_view(request):
    return JsonResponse({"message": "hello"})


def user_view(request):
    return JsonResponse({"users": []})


urlpatterns = [
    path("", index_view),
    path("users/", user_view),
]


class TestDjangoMiddleware:
    def test_basic_request(self):
        backend = MemoryBackend()
        factory = RequestFactory()
        request = factory.get("/")

        middleware = ReqlogMiddleware(lambda req: JsonResponse({"ok": True}))
        middleware.pipeline.backends = [backend]

        response = middleware(request)
        middleware.flush()

        assert response.status_code == 200
        assert len(backend) == 1
        txn = backend.transactions[0]
        assert txn.request.method == "GET"
        assert txn.request.path == "/"
        assert txn.response.status_code == 200

    def test_post_request(self):
        backend = MemoryBackend()
        factory = RequestFactory()
        request = factory.post("/users/", data={"name": "Alice"}, content_type="application/json")

        middleware = ReqlogMiddleware(lambda req: JsonResponse({"id": 1}, status=201))
        middleware.pipeline.backends = [backend]

        response = middleware(request)
        middleware.flush()

        assert response.status_code == 201
        assert len(backend) == 1
        txn = backend.transactions[0]
        assert txn.request.method == "POST"

    def test_request_id_generated(self):
        backend = MemoryBackend()
        factory = RequestFactory()
        request = factory.get("/")

        middleware = ReqlogMiddleware(lambda req: JsonResponse({"ok": True}))
        middleware.pipeline.backends = [backend]
        middleware(request)
        middleware.flush()

        txn = backend.transactions[0]
        assert len(txn.request_id) > 0
