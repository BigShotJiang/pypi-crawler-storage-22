import pytest
import httpx
from fastapi import FastAPI

from reqlog import ReqlogMiddleware
from reqlog.backends.memory import MemoryBackend
from reqlog.core.config import ReqlogConfig


@pytest.fixture
def memory_backend():
    return MemoryBackend()


@pytest.fixture
def app(memory_backend):
    app = FastAPI()
    app.add_middleware(ReqlogMiddleware, backends=[memory_backend])

    @app.get("/users")
    async def get_users():
        return [{"name": "Alice"}, {"name": "Bob"}]

    @app.post("/users")
    async def create_user():
        return {"id": 1, "name": "Alice"}

    @app.get("/error")
    async def error():
        raise ValueError("boom")

    return app


class TestFastAPIIntegration:
    @pytest.mark.asyncio
    async def test_get_request_logged(self, app, memory_backend):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.get("/users")

        assert response.status_code == 200
        assert len(memory_backend) == 1
        txn = memory_backend.transactions[0]
        assert txn.request.method == "GET"
        assert txn.request.path == "/users"
        assert txn.response.status_code == 200
        assert txn.duration_ms > 0

    @pytest.mark.asyncio
    async def test_post_request_logged(self, app, memory_backend):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.post("/users")

        assert response.status_code == 200
        txn = memory_backend.transactions[0]
        assert txn.request.method == "POST"

    @pytest.mark.asyncio
    async def test_multiple_requests(self, app, memory_backend):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            await client.get("/users")
            await client.post("/users")
            await client.get("/users")

        assert len(memory_backend) == 3

    @pytest.mark.asyncio
    async def test_excluded_path_not_logged(self, memory_backend):
        app = FastAPI()
        app.add_middleware(
            ReqlogMiddleware,
            backends=[memory_backend],
            exclude_paths=["/health"],
        )

        @app.get("/health")
        async def health():
            return {"status": "ok"}

        @app.get("/api")
        async def api():
            return {"data": "yes"}

        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            await client.get("/health")
            await client.get("/api")

        assert len(memory_backend) == 1
        assert memory_backend.transactions[0].request.path == "/api"

    @pytest.mark.asyncio
    async def test_body_capture(self, memory_backend):
        app = FastAPI()
        app.add_middleware(
            ReqlogMiddleware,
            backends=[memory_backend],
            capture_body=True,
        )

        from fastapi import Request as FastAPIRequest

        @app.post("/echo")
        async def echo(request: FastAPIRequest):
            await request.body()
            return {"echoed": True}

        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            await client.post("/echo", json={"hello": "world"})

        txn = memory_backend.transactions[0]
        assert txn.request.body is not None
        assert txn.response.body is not None

    @pytest.mark.asyncio
    async def test_request_id_generated(self, app, memory_backend):
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            await client.get("/users")

        txn = memory_backend.transactions[0]
        assert len(txn.request_id) > 0


class TestFastAPIWithConfig:
    @pytest.mark.asyncio
    async def test_full_config(self, memory_backend):
        config = ReqlogConfig(
            capture_body=True,
            capture_headers=True,
            exclude_paths=["/ignored"],
            exclude_methods=["OPTIONS"],
            sanitize_headers=["Authorization"],
            sanitize_body_fields=["password"],
            backends=[memory_backend],
        )

        app = FastAPI()
        app.add_middleware(ReqlogMiddleware, config=config)

        @app.post("/login")
        async def login():
            return {"token": "abc"}

        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://test"
        ) as client:
            await client.post(
                "/login",
                json={"password": "secret"},
                headers={"Authorization": "Bearer token123"},
            )

        assert len(memory_backend) == 1
        txn = memory_backend.transactions[0]
        assert txn.request.path == "/login"
        # Headers should be captured and sanitized
        assert txn.request.headers.get("authorization") == "[REDACTED]"
