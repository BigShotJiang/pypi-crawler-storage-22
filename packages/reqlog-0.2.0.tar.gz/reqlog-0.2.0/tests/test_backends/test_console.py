import pytest
from rich.console import Console

from reqlog.backends.console import ConsoleBackend
from reqlog.core.models import Request, Response, Transaction


def _make_txn(
    method: str = "GET",
    path: str = "/test",
    status: int = 200,
    body: bytes | None = None,
    content_type: str = "",
    headers: dict | None = None,
) -> Transaction:
    return Transaction(
        request=Request(
            method=method, path=path, body=body, content_type=content_type, headers=headers or {}
        ),
        response=Response(
            status_code=status, body=body, content_type=content_type, headers=headers or {}
        ),
        duration_ms=42.0,
    )


class TestConsoleBackend:
    @pytest.mark.asyncio
    async def test_compact_format(self, capsys):
        console = Console(stderr=True, force_terminal=True)
        backend = ConsoleBackend(format="compact", console=console)
        await backend.write(_make_txn())
        # Should not raise

    @pytest.mark.asyncio
    async def test_verbose_format(self, capsys):
        console = Console(stderr=True, force_terminal=True)
        backend = ConsoleBackend(format="verbose", console=console)
        txn = _make_txn(
            body=b'{"key": "value"}',
            content_type="application/json",
            headers={"Content-Type": "application/json"},
        )
        await backend.write(txn)

    @pytest.mark.asyncio
    async def test_panel_format(self, capsys):
        console = Console(stderr=True, force_terminal=True)
        backend = ConsoleBackend(format="panel", console=console)
        txn = _make_txn(
            method="POST",
            body=b'{"key": "value"}',
            content_type="application/json",
            headers={"Content-Type": "application/json"},
        )
        await backend.write(txn)

    @pytest.mark.asyncio
    async def test_panel_format_no_body(self, capsys):
        console = Console(stderr=True, force_terminal=True)
        backend = ConsoleBackend(format="panel", console=console)
        await backend.write(_make_txn())

    @pytest.mark.asyncio
    async def test_json_format(self, capsys):
        console = Console(stderr=True, force_terminal=True)
        backend = ConsoleBackend(format="json", console=console)
        await backend.write(_make_txn())

    @pytest.mark.asyncio
    async def test_ai_format(self, capsys):
        console = Console(stderr=True, force_terminal=True)
        backend = ConsoleBackend(format="ai", console=console)
        await backend.write(_make_txn())
