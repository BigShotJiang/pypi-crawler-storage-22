import json
from datetime import datetime, timezone

import pytest

from reqlog.backends.file import FileBackend
from reqlog.core.models import Request, Response, Transaction


def _make_txn(
    method: str = "POST",
    path: str = "/api/users",
    status: int = 201,
    duration_ms: float = 145.0,
    req_body: bytes | None = b'{"name":"Alice"}',
    res_body: bytes | None = b'{"id":1}',
) -> Transaction:
    return Transaction(
        request=Request(method=method, path=path, body=req_body),
        response=Response(status_code=status, body=res_body),
        duration_ms=duration_ms,
        timestamp=datetime(2026, 2, 14, 14, 23, 46, tzinfo=timezone.utc),
    )


class TestFileBackendJSON:
    @pytest.mark.asyncio
    async def test_json_write(self, tmp_path):
        path = str(tmp_path / "test.jsonl")
        backend = FileBackend(path=path, format="json")
        await backend.write(_make_txn())
        await backend.close()

        with open(path) as f:
            line = f.readline().strip()
        data = json.loads(line)
        assert data["method"] == "POST"
        assert data["path"] == "/api/users"
        assert data["status_code"] == 201

    @pytest.mark.asyncio
    async def test_json_multiple_writes(self, tmp_path):
        path = str(tmp_path / "test.jsonl")
        backend = FileBackend(path=path, format="json")
        for i in range(5):
            await backend.write(_make_txn(path=f"/api/{i}"))
        await backend.close()

        with open(path) as f:
            lines = [line.strip() for line in f if line.strip()]
        assert len(lines) == 5


class TestFileBackendText:
    @pytest.mark.asyncio
    async def test_text_write(self, tmp_path):
        path = str(tmp_path / "test.log")
        backend = FileBackend(path=path, format="text")
        await backend.write(_make_txn())
        await backend.close()

        with open(path) as f:
            line = f.readline().strip()
        assert "POST" in line
        assert "/api/users" in line
        assert "201" in line
        assert "145ms" in line

    @pytest.mark.asyncio
    async def test_text_seconds_duration(self, tmp_path):
        path = str(tmp_path / "test.log")
        backend = FileBackend(path=path, format="text")
        await backend.write(_make_txn(duration_ms=2500.0))
        await backend.close()

        with open(path) as f:
            line = f.readline().strip()
        assert "2.5s" in line


class TestFileBackendAI:
    @pytest.mark.asyncio
    async def test_ai_write(self, tmp_path):
        path = str(tmp_path / "test.log")
        backend = FileBackend(path=path, format="ai")
        await backend.write(_make_txn())
        await backend.close()

        with open(path) as f:
            content = f.read()
        assert "POST /api/users" in content
        assert "\u2192 201" in content
        assert "---" in content


class TestFileBackendRotation:
    @pytest.mark.asyncio
    async def test_rotation_trigger(self, tmp_path):
        from logging.handlers import RotatingFileHandler

        path = str(tmp_path / "test.jsonl")
        # Use raw RotatingFileHandler with tiny maxBytes to guarantee rotation
        backend = FileBackend(path=path, format="json", rotate=False)
        # Replace the handler with one that has a tiny limit
        backend._logger.removeHandler(backend._handler)
        handler = RotatingFileHandler(path, maxBytes=100, backupCount=3, encoding="utf-8")
        import logging
        handler.setFormatter(logging.Formatter("%(message)s"))
        backend._logger.addHandler(handler)
        backend._handler = handler

        for i in range(10):
            await backend.write(_make_txn(path=f"/api/{i}"))
        await backend.close()

        import glob
        rotated = glob.glob(str(tmp_path / "test.jsonl*"))
        assert len(rotated) >= 2


class TestFileBackendClose:
    @pytest.mark.asyncio
    async def test_close_flushes(self, tmp_path):
        path = str(tmp_path / "test.jsonl")
        backend = FileBackend(path=path, format="json")
        await backend.write(_make_txn())
        await backend.close()

        with open(path) as f:
            assert f.read().strip()
