import pytest

from reqlog.backends.memory import MemoryBackend
from reqlog.core.models import Request, Response, Transaction


def _make_txn(path: str = "/test") -> Transaction:
    return Transaction(
        request=Request(method="GET", path=path),
        response=Response(status_code=200),
        duration_ms=10.0,
    )


class TestMemoryBackend:
    @pytest.mark.asyncio
    async def test_write_and_read(self):
        backend = MemoryBackend()
        txn = _make_txn()
        await backend.write(txn)
        assert len(backend) == 1
        assert backend.transactions[0].request.path == "/test"

    @pytest.mark.asyncio
    async def test_max_size(self):
        backend = MemoryBackend(max_size=2)
        for i in range(5):
            await backend.write(_make_txn(f"/{i}"))
        assert len(backend) == 2
        assert backend.transactions[0].request.path == "/3"

    @pytest.mark.asyncio
    async def test_get_recent(self):
        backend = MemoryBackend()
        for i in range(5):
            await backend.write(_make_txn(f"/{i}"))
        recent = backend.get_recent(2)
        assert len(recent) == 2
        assert recent[0].request.path == "/3"

    @pytest.mark.asyncio
    async def test_clear(self):
        backend = MemoryBackend()
        await backend.write(_make_txn())
        backend.clear()
        assert len(backend) == 0
