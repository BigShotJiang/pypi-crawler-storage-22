import time

import pytest

from reqlog.backends.sqlite import RequestStats, SQLiteBackend, SQLiteReader
from reqlog.core.models import Request, Response, Transaction


def _make_txn(
    method: str = "GET",
    path: str = "/api/test",
    status: int = 200,
    duration_ms: float = 42.0,
    req_body: bytes | None = None,
    res_body: bytes | None = None,
    headers: dict | None = None,
    request_id: str | None = None,
) -> Transaction:
    kwargs: dict = {}
    if request_id is not None:
        kwargs["request_id"] = request_id
    return Transaction(
        request=Request(
            method=method, path=path, body=req_body, headers=headers or {},
        ),
        response=Response(status_code=status, body=res_body, headers=headers or {}),
        duration_ms=duration_ms,
        **kwargs,
    )


class TestSQLiteBackendRoundTrip:
    @pytest.mark.asyncio
    async def test_write_and_read(self, tmp_path):
        db = str(tmp_path / "test.db")
        backend = SQLiteBackend(db_path=db)
        txn = _make_txn(request_id="abc123")
        await backend.write(txn)
        await backend.close()

        rows = backend.get_recent(limit=10)
        assert len(rows) == 1
        assert rows[0]["id"] == "abc123"
        assert rows[0]["method"] == "GET"
        assert rows[0]["path"] == "/api/test"
        assert rows[0]["status_code"] == 200

    @pytest.mark.asyncio
    async def test_write_with_body(self, tmp_path):
        db = str(tmp_path / "test.db")
        backend = SQLiteBackend(db_path=db)
        txn = _make_txn(
            req_body=b'{"key":"value"}',
            res_body=b'{"id":1}',
            headers={"Content-Type": "application/json"},
        )
        await backend.write(txn)
        await backend.close()

        rows = backend.get_recent()
        assert len(rows) == 1
        assert rows[0]["request_body"] == '{"key":"value"}'
        assert rows[0]["response_body"] == '{"id":1}'
        assert rows[0]["request_headers"] == {"Content-Type": "application/json"}

    @pytest.mark.asyncio
    async def test_multiple_writes(self, tmp_path):
        db = str(tmp_path / "test.db")
        backend = SQLiteBackend(db_path=db)
        for i in range(10):
            await backend.write(_make_txn(path=f"/api/{i}", request_id=f"id-{i}"))
        await backend.close()

        assert backend.count() == 10
        rows = backend.get_recent(limit=5)
        assert len(rows) == 5


class TestSQLiteBackendPrune:
    @pytest.mark.asyncio
    async def test_auto_prune(self, tmp_path):
        db = str(tmp_path / "test.db")
        backend = SQLiteBackend(db_path=db, max_rows=10)
        for i in range(15):
            await backend.write(_make_txn(request_id=f"id-{i:03d}"))
        await backend.close()

        count = backend.count()
        assert count <= 10


class TestSQLiteBackendFilters:
    @pytest.mark.asyncio
    async def test_status_filter(self, tmp_path):
        db = str(tmp_path / "test.db")
        backend = SQLiteBackend(db_path=db)
        await backend.write(_make_txn(status=200, request_id="ok"))
        await backend.write(_make_txn(status=404, request_id="notfound"))
        await backend.close()

        rows = backend.get_recent(status_filter=404)
        assert len(rows) == 1
        assert rows[0]["status_code"] == 404

    @pytest.mark.asyncio
    async def test_path_filter(self, tmp_path):
        db = str(tmp_path / "test.db")
        backend = SQLiteBackend(db_path=db)
        await backend.write(_make_txn(path="/api/users", request_id="u"))
        await backend.write(_make_txn(path="/api/posts", request_id="p"))
        await backend.close()

        rows = backend.get_recent(path_filter="users")
        assert len(rows) == 1
        assert rows[0]["path"] == "/api/users"

    @pytest.mark.asyncio
    async def test_method_filter(self, tmp_path):
        db = str(tmp_path / "test.db")
        backend = SQLiteBackend(db_path=db)
        await backend.write(_make_txn(method="GET", request_id="g"))
        await backend.write(_make_txn(method="POST", request_id="p"))
        await backend.close()

        rows = backend.get_recent(method_filter="POST")
        assert len(rows) == 1
        assert rows[0]["method"] == "POST"

    @pytest.mark.asyncio
    async def test_min_duration_filter(self, tmp_path):
        db = str(tmp_path / "test.db")
        backend = SQLiteBackend(db_path=db)
        await backend.write(_make_txn(duration_ms=10.0, request_id="fast"))
        await backend.write(_make_txn(duration_ms=500.0, request_id="slow"))
        await backend.close()

        rows = backend.get_recent(min_duration=100.0)
        assert len(rows) == 1
        assert rows[0]["duration_ms"] == 500.0


class TestSQLiteBackendGetById:
    @pytest.mark.asyncio
    async def test_get_by_id(self, tmp_path):
        db = str(tmp_path / "test.db")
        backend = SQLiteBackend(db_path=db)
        await backend.write(_make_txn(request_id="find-me"))
        await backend.close()

        row = backend.get_by_id("find-me")
        assert row is not None
        assert row["id"] == "find-me"

    @pytest.mark.asyncio
    async def test_get_by_id_not_found(self, tmp_path):
        db = str(tmp_path / "test.db")
        backend = SQLiteBackend(db_path=db)
        await backend.close()

        assert backend.get_by_id("nope") is None


class TestSQLiteBackendStats:
    @pytest.mark.asyncio
    async def test_get_stats(self, tmp_path):
        db = str(tmp_path / "test.db")
        backend = SQLiteBackend(db_path=db)
        await backend.write(_make_txn(method="GET", status=200, duration_ms=10.0, request_id="a"))
        await backend.write(_make_txn(method="GET", status=200, duration_ms=50.0, request_id="b"))
        await backend.write(_make_txn(method="POST", status=201, duration_ms=100.0, request_id="c"))
        await backend.write(_make_txn(method="GET", status=404, duration_ms=5.0, request_id="d"))
        await backend.close()

        stats = backend.get_stats(minutes=60)
        assert isinstance(stats, RequestStats)
        assert stats.total_requests == 4
        assert "2xx" in stats.status_counts
        assert "GET" in stats.method_counts
        assert stats.avg_duration_ms > 0
        assert len(stats.slowest_endpoints) > 0

    @pytest.mark.asyncio
    async def test_get_stats_empty(self, tmp_path):
        db = str(tmp_path / "test.db")
        backend = SQLiteBackend(db_path=db)
        await backend.close()

        stats = backend.get_stats(minutes=60)
        assert stats.total_requests == 0


class TestSQLiteWALMode:
    @pytest.mark.asyncio
    async def test_wal_enabled(self, tmp_path):
        import sqlite3

        db = str(tmp_path / "test.db")
        backend = SQLiteBackend(db_path=db, wal_mode=True)
        await backend.write(_make_txn(request_id="wal-test"))
        await backend.close()

        conn = sqlite3.connect(db)
        mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
        conn.close()
        assert mode == "wal"


class TestSQLiteReader:
    def test_get_since(self, tmp_path):
        import sqlite3

        db = str(tmp_path / "test.db")
        conn = sqlite3.connect(db)
        conn.execute(_create_table_sql())
        now = time.time()
        conn.execute(
            "INSERT INTO requests VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            ("id1", "2026-01-01T00:00:00", now - 100, "GET", "/old", None,
             200, 10.0, None, None, None, None, None, None, None, None),
        )
        conn.execute(
            "INSERT INTO requests VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            ("id2", "2026-01-01T00:01:00", now + 100, "GET", "/new", None,
             200, 20.0, None, None, None, None, None, None, None, None),
        )
        conn.commit()
        conn.close()

        reader = SQLiteReader(db_path=db)
        rows = reader.get_since(now)
        assert len(rows) == 1
        assert rows[0]["id"] == "id2"


def _populate_db(db_path: str, rows: list[tuple]) -> None:
    """Insert raw rows into a test database."""
    import sqlite3

    conn = sqlite3.connect(db_path)
    conn.execute(_create_table_sql())
    for row in rows:
        conn.execute(
            "INSERT INTO requests VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            row,
        )
    conn.commit()
    conn.close()


class TestSQLiteReaderStatusClass:
    def test_filter_2xx(self, tmp_path):
        db = str(tmp_path / "test.db")
        now = time.time()
        _populate_db(db, [
            ("r1", "2026-01-01T00:00:00", now, "GET", "/a", None, 200, 10.0,
             None, None, None, None, None, None, None, None),
            ("r2", "2026-01-01T00:00:01", now + 1, "GET", "/b", None, 404, 20.0,
             None, None, None, None, None, None, None, None),
            ("r3", "2026-01-01T00:00:02", now + 2, "POST", "/c", None, 500, 30.0,
             None, None, None, None, None, None, None, None),
        ])
        reader = SQLiteReader(db_path=db)
        rows = reader.get_recent(status_class="2xx")
        assert len(rows) == 1
        assert rows[0]["status_code"] == 200

    def test_filter_error(self, tmp_path):
        db = str(tmp_path / "test.db")
        now = time.time()
        _populate_db(db, [
            ("r1", "2026-01-01T00:00:00", now, "GET", "/a", None, 200, 10.0,
             None, None, None, None, None, None, None, None),
            ("r2", "2026-01-01T00:00:01", now + 1, "GET", "/b", None, 404, 20.0,
             None, None, None, None, None, None, None, None),
            ("r3", "2026-01-01T00:00:02", now + 2, "POST", "/c", None, 500, 30.0,
             None, None, None, None, None, None, None, None),
        ])
        reader = SQLiteReader(db_path=db)
        rows = reader.get_recent(status_class="error")
        assert len(rows) == 2
        codes = {r["status_code"] for r in rows}
        assert codes == {404, 500}


class TestSQLiteReaderSearch:
    def test_search_by_path(self, tmp_path):
        db = str(tmp_path / "test.db")
        now = time.time()
        _populate_db(db, [
            ("r1", "2026-01-01T00:00:00", now, "GET", "/api/users", None, 200, 10.0,
             None, None, None, None, None, None, None, None),
            ("r2", "2026-01-01T00:00:01", now + 1, "GET", "/api/posts", None, 200, 20.0,
             None, None, None, None, None, None, None, None),
        ])
        reader = SQLiteReader(db_path=db)
        rows = reader.search_requests("users")
        assert len(rows) == 1
        assert rows[0]["path"] == "/api/users"

    def test_search_by_body(self, tmp_path):
        db = str(tmp_path / "test.db")
        now = time.time()
        _populate_db(db, [
            ("r1", "2026-01-01T00:00:00", now, "POST", "/api/users", None, 201, 10.0,
             None, None, None, b'{"email":"alice@test.com"}', None, None, None, None),
            ("r2", "2026-01-01T00:00:01", now + 1, "POST", "/api/users", None, 201, 20.0,
             None, None, None, b'{"email":"bob@test.com"}', None, None, None, None),
        ])
        reader = SQLiteReader(db_path=db)
        rows = reader.search_requests("alice")
        assert len(rows) == 1
        assert rows[0]["id"] == "r1"

    def test_search_with_status_class(self, tmp_path):
        db = str(tmp_path / "test.db")
        now = time.time()
        _populate_db(db, [
            ("r1", "2026-01-01T00:00:00", now, "GET", "/api/users", None, 200, 10.0,
             None, None, None, None, None, None, None, None),
            ("r2", "2026-01-01T00:00:01", now + 1, "GET", "/api/users/99", None, 404, 20.0,
             None, None, None, None, None, None, None, None),
        ])
        reader = SQLiteReader(db_path=db)
        rows = reader.search_requests("users", status_class="4xx")
        assert len(rows) == 1
        assert rows[0]["status_code"] == 404

    def test_search_no_results(self, tmp_path):
        db = str(tmp_path / "test.db")
        now = time.time()
        _populate_db(db, [
            ("r1", "2026-01-01T00:00:00", now, "GET", "/api/users", None, 200, 10.0,
             None, None, None, None, None, None, None, None),
        ])
        reader = SQLiteReader(db_path=db)
        rows = reader.search_requests("nonexistent")
        assert len(rows) == 0


class TestSQLiteReaderErrorSummary:
    def test_error_summary(self, tmp_path):
        db = str(tmp_path / "test.db")
        now = time.time()
        _populate_db(db, [
            ("r1", "2026-01-01T00:00:00", now, "GET", "/a", None, 200, 10.0,
             None, None, None, None, None, None, None, None),
            ("r2", "2026-01-01T00:00:01", now, "GET", "/b", None, 200, 10.0,
             None, None, None, None, None, None, None, None),
            ("r3", "2026-01-01T00:00:02", now, "GET", "/c", None, 404, 20.0,
             None, None, None, None, None, None, None, None),
            ("r4", "2026-01-01T00:00:03", now, "POST", "/d", None, 500, 30.0,
             None, None, None, None, None, None, None, None),
        ])
        reader = SQLiteReader(db_path=db)
        summary = reader.get_error_summary(minutes=60)
        assert summary["total_errors"] == 2
        assert summary["total_requests"] == 4
        assert summary["error_rate"] == 50.0
        assert len(summary["by_status"]) == 2
        codes = [g["status_code"] for g in summary["by_status"]]
        assert 404 in codes
        assert 500 in codes

    def test_error_summary_no_errors(self, tmp_path):
        db = str(tmp_path / "test.db")
        now = time.time()
        _populate_db(db, [
            ("r1", "2026-01-01T00:00:00", now, "GET", "/a", None, 200, 10.0,
             None, None, None, None, None, None, None, None),
        ])
        reader = SQLiteReader(db_path=db)
        summary = reader.get_error_summary(minutes=60)
        assert summary["total_errors"] == 0
        assert summary["error_rate"] == 0.0
        assert summary["by_status"] == []

    def test_error_summary_empty_db(self, tmp_path):
        db = str(tmp_path / "test.db")
        _populate_db(db, [])
        reader = SQLiteReader(db_path=db)
        summary = reader.get_error_summary(minutes=60)
        assert summary["total_errors"] == 0
        assert summary["total_requests"] == 0


class TestSQLiteReaderEndpointStats:
    def test_endpoint_stats(self, tmp_path):
        db = str(tmp_path / "test.db")
        now = time.time()
        _populate_db(db, [
            ("r1", "2026-01-01T00:00:00", now, "GET", "/api/users", None, 200, 10.0,
             None, None, None, None, None, None, None, None),
            ("r2", "2026-01-01T00:00:01", now, "GET", "/api/users", None, 200, 30.0,
             None, None, None, None, None, None, None, None),
            ("r3", "2026-01-01T00:00:02", now, "GET", "/api/users", None, 500, 50.0,
             None, None, None, None, None, None, None, None),
            ("r4", "2026-01-01T00:00:03", now, "POST", "/api/users", None, 201, 100.0,
             None, None, None, None, None, None, None, None),
        ])
        reader = SQLiteReader(db_path=db)
        stats = reader.get_endpoint_stats(minutes=60)
        assert len(stats) == 2  # GET /api/users and POST /api/users

        get_stats = next(s for s in stats if s["method"] == "GET")
        assert get_stats["request_count"] == 3
        assert get_stats["status_2xx"] == 2
        assert get_stats["status_5xx"] == 1
        assert get_stats["avg_ms"] == 30.0

        post_stats = next(s for s in stats if s["method"] == "POST")
        assert post_stats["request_count"] == 1

    def test_endpoint_stats_with_path_pattern(self, tmp_path):
        db = str(tmp_path / "test.db")
        now = time.time()
        _populate_db(db, [
            ("r1", "2026-01-01T00:00:00", now, "GET", "/api/users", None, 200, 10.0,
             None, None, None, None, None, None, None, None),
            ("r2", "2026-01-01T00:00:01", now, "GET", "/api/posts", None, 200, 20.0,
             None, None, None, None, None, None, None, None),
        ])
        reader = SQLiteReader(db_path=db)
        stats = reader.get_endpoint_stats(path_pattern="users", minutes=60)
        assert len(stats) == 1
        assert stats[0]["path"] == "/api/users"

    def test_endpoint_stats_empty(self, tmp_path):
        db = str(tmp_path / "test.db")
        _populate_db(db, [])
        reader = SQLiteReader(db_path=db)
        stats = reader.get_endpoint_stats(minutes=60)
        assert stats == []


def _create_table_sql() -> str:
    return """
    CREATE TABLE IF NOT EXISTS requests (
        id TEXT PRIMARY KEY,
        timestamp TEXT NOT NULL,
        timestamp_unix REAL NOT NULL,
        method TEXT NOT NULL,
        path TEXT NOT NULL,
        query_string TEXT,
        status_code INTEGER NOT NULL,
        duration_ms REAL NOT NULL,
        client_ip TEXT,
        user_agent TEXT,
        request_headers TEXT,
        request_body BLOB,
        response_headers TEXT,
        response_body BLOB,
        request_content_type TEXT,
        response_content_type TEXT
    )
    """
