"""Production-readiness tests for SQLite backend."""

from __future__ import annotations

import asyncio
import tempfile
import time
from pathlib import Path

import pytest

from reqlog.backends.sqlite import SQLiteBackend
from reqlog.core.models import Request, Response, Transaction


@pytest.fixture
def temp_db() -> str:
    """Create a temporary database file."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        return f.name


class TestGracefulShutdown:
    """Test that graceful shutdown flushes all queued transactions."""

    @pytest.mark.asyncio
    async def test_close_flushes_queue(self, temp_db: str) -> None:
        """Verify all queued transactions are written on close()."""
        backend = SQLiteBackend(db_path=temp_db, max_queue_size=100)

        # Enqueue multiple transactions
        transactions = []
        for i in range(50):
            txn = Transaction(
                request=Request(method="GET", path=f"/test/{i}"),
                response=Response(status_code=200),
                duration_ms=10.0,
                request_id=f"test-{i}",
            )
            await backend.write(txn)
            transactions.append(txn)

        # Close should flush all queued items
        await backend.close()

        # Verify all transactions were written
        # Create new backend to read
        reader_backend = SQLiteBackend(db_path=temp_db)
        count = reader_backend.count()
        assert count == 50, f"Expected 50 transactions, got {count}"

        # Cleanup
        await reader_backend.close()
        Path(temp_db).unlink()

    @pytest.mark.asyncio
    async def test_close_with_timeout(self, temp_db: str) -> None:
        """Verify close() completes within reasonable time."""
        backend = SQLiteBackend(db_path=temp_db)

        # Enqueue many transactions
        for i in range(200):
            txn = Transaction(
                request=Request(method="GET", path=f"/test/{i}"),
                response=Response(status_code=200),
                duration_ms=10.0,
                request_id=f"test-{i}",
            )
            await backend.write(txn)

        # Close should complete within 10 seconds
        start = time.time()
        await backend.close()
        duration = time.time() - start

        assert duration < 10.0, f"Close took {duration}s, expected < 10s"

        # Cleanup
        Path(temp_db).unlink()


class TestQueueOverflow:
    """Test graceful degradation when queue fills."""

    @pytest.mark.asyncio
    async def test_queue_full_drops_gracefully(self, temp_db: str) -> None:
        """Verify graceful handling when queue fills (no crashes)."""
        # Small queue for testing
        backend = SQLiteBackend(db_path=temp_db, max_queue_size=10)

        # Try to enqueue more than max
        for i in range(50):
            txn = Transaction(
                request=Request(method="GET", path=f"/test/{i}"),
                response=Response(status_code=200),
                duration_ms=10.0,
                request_id=f"test-{i}",
            )
            await backend.write(txn)

        # Give writer thread time to process
        await asyncio.sleep(0.5)

        # Should not crash - some transactions may be dropped
        # This is expected behavior for queue overflow
        await backend.close()

        # Verify database is still functional
        count = backend.count()
        assert count > 0, "Database should have at least some transactions"
        assert count <= 50, "Should not exceed total enqueued"

        # Cleanup
        Path(temp_db).unlink()

    @pytest.mark.asyncio
    async def test_queue_respects_max_size(self, temp_db: str) -> None:
        """Verify queue size is bounded."""
        backend = SQLiteBackend(db_path=temp_db, max_queue_size=5)

        # The queue should never grow beyond max_size
        # Since we're using put_nowait, excess items are dropped
        for i in range(20):
            txn = Transaction(
                request=Request(method="GET", path=f"/test/{i}"),
                response=Response(status_code=200),
                duration_ms=10.0,
                request_id=f"test-{i}",
            )
            await backend.write(txn)

        # Queue should be bounded at max_queue_size
        # (some items may have been processed already)
        queue_size = backend._writer._queue.qsize()
        assert queue_size <= 5, f"Queue size {queue_size} exceeds max 5"

        await backend.close()
        Path(temp_db).unlink()


class TestWriterThreadErrorRecovery:
    """Test that writer thread continues after errors."""

    @pytest.mark.asyncio
    async def test_continues_after_processing_error(self, temp_db: str) -> None:
        """Verify thread continues processing after individual item errors."""
        backend = SQLiteBackend(db_path=temp_db)

        # Write valid transactions
        for i in range(10):
            txn = Transaction(
                request=Request(method="GET", path=f"/test/{i}"),
                response=Response(status_code=200),
                duration_ms=10.0,
                request_id=f"test-{i}",
            )
            await backend.write(txn)

        # Give thread time to process
        await asyncio.sleep(0.2)

        # Close and verify data was written
        await backend.close()

        count = backend.count()
        assert count == 10, f"Expected 10 transactions, got {count}"

        # Cleanup
        Path(temp_db).unlink()


class TestNonDaemonThread:
    """Test that writer thread is non-daemon for graceful shutdown."""

    def test_thread_is_not_daemon(self, temp_db: str) -> None:
        """Verify writer thread is not marked as daemon."""
        backend = SQLiteBackend(db_path=temp_db)

        # Check that the thread is not a daemon
        assert not backend._writer._thread.daemon, (
            "Writer thread should not be daemon to ensure graceful shutdown"
        )

        # Cleanup
        import asyncio
        asyncio.run(backend.close())
        Path(temp_db).unlink()
