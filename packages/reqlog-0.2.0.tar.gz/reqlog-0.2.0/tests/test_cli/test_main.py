import json
import sqlite3
import time

from click.testing import CliRunner

from reqlog.cli.main import cli


def _populate_db(db_path: str, count: int = 5) -> None:
    """Populate a SQLite database with test data."""
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS requests (
            id TEXT PRIMARY KEY,
            timestamp TEXT NOT NULL,
            timestamp_unix REAL NOT NULL,
            method TEXT NOT NULL,
            path TEXT NOT NULL,
            query_string TEXT,
            status_code INTEGER NOT NULL,
            duration_ms REAL NOT NULL,
            client_ip TEXT,
            user_agent TEXT,
            request_headers TEXT,
            request_body BLOB,
            response_headers TEXT,
            response_body BLOB,
            request_content_type TEXT,
            response_content_type TEXT
        )
    """)
    now = time.time()
    methods = ["GET", "POST", "GET", "PUT", "DELETE"]
    statuses = [200, 201, 404, 200, 204]
    durations = [10.0, 50.0, 5.0, 200.0, 15.0]
    for i in range(count):
        conn.execute(
            """INSERT INTO requests VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                f"id-{i}",
                f"2026-02-14T14:{i:02d}:00",
                now - (count - i),
                methods[i % len(methods)],
                f"/api/resource/{i}",
                None,
                statuses[i % len(statuses)],
                durations[i % len(durations)],
                "127.0.0.1",
                "test-agent",
                None,
                None,
                None,
                None,
                None,
                None,
            ),
        )
    conn.commit()
    conn.close()


class TestStatsCommand:
    def test_stats_with_data(self, tmp_path):
        db = str(tmp_path / "test.db")
        _populate_db(db)
        runner = CliRunner()
        result = runner.invoke(cli, ["stats", "--db", db, "--minutes", "60"])
        assert result.exit_code == 0
        assert "Request Stats" in result.output
        assert "Total requests" in result.output

    def test_stats_empty_db(self, tmp_path):
        db = str(tmp_path / "empty.db")
        _populate_db(db, count=0)
        runner = CliRunner()
        result = runner.invoke(cli, ["stats", "--db", db])
        assert result.exit_code == 0
        assert "No requests found" in result.output


class TestExportCommand:
    def test_export_json(self, tmp_path):
        db = str(tmp_path / "test.db")
        _populate_db(db)
        runner = CliRunner()
        result = runner.invoke(cli, ["export", "--db", db, "--format", "json", "--limit", "3"])
        assert result.exit_code == 0
        lines = [line for line in result.output.strip().split("\n") if line.strip()]
        assert len(lines) == 3
        data = json.loads(lines[0])
        assert "method" in data
        assert "path" in data

    def test_export_csv(self, tmp_path):
        db = str(tmp_path / "test.db")
        _populate_db(db)
        runner = CliRunner()
        result = runner.invoke(cli, ["export", "--db", db, "--format", "csv", "--limit", "3"])
        assert result.exit_code == 0
        lines = [line for line in result.output.strip().split("\n") if line.strip()]
        assert len(lines) == 4  # header + 3 rows
        assert "id,timestamp,method,path,status_code,duration_ms,client_ip" in lines[0]

    def test_export_with_since(self, tmp_path):
        db = str(tmp_path / "test.db")
        _populate_db(db)
        runner = CliRunner()
        result = runner.invoke(cli, ["export", "--db", db, "--since", "1 hour ago"])
        assert result.exit_code == 0


class TestCliCommands:
    def test_no_demo_command(self):
        """Demo commands should not exist in the CLI — examples/ is for that."""
        runner = CliRunner()
        result = runner.invoke(cli, ["demo", "--help"])
        assert result.exit_code != 0
