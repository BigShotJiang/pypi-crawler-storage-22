from reqlog.core.buffer import BoundedRingBuffer
from reqlog.core.models import Request, Response, Transaction


def _make_txn(path: str = "/test") -> Transaction:
    return Transaction(
        request=Request(method="GET", path=path),
        response=Response(status_code=200),
        duration_ms=10.0,
    )


class TestBoundedRingBuffer:
    def test_append_and_len(self):
        buf = BoundedRingBuffer(max_size=10)
        assert len(buf) == 0
        buf.append(_make_txn())
        assert len(buf) == 1

    def test_max_size_eviction(self):
        buf = BoundedRingBuffer(max_size=3)
        for i in range(5):
            buf.append(_make_txn(f"/{i}"))
        assert len(buf) == 3
        items = buf.get_all()
        assert items[0].request.path == "/2"
        assert items[-1].request.path == "/4"

    def test_get_recent(self):
        buf = BoundedRingBuffer(max_size=10)
        for i in range(5):
            buf.append(_make_txn(f"/{i}"))
        recent = buf.get_recent(2)
        assert len(recent) == 2
        assert recent[0].request.path == "/3"
        assert recent[1].request.path == "/4"

    def test_get_recent_more_than_size(self):
        buf = BoundedRingBuffer(max_size=10)
        buf.append(_make_txn())
        recent = buf.get_recent(100)
        assert len(recent) == 1

    def test_clear(self):
        buf = BoundedRingBuffer(max_size=10)
        buf.append(_make_txn())
        buf.clear()
        assert len(buf) == 0
