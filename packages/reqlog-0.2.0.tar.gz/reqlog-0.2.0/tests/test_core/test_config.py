from reqlog.core.config import ReqlogConfig


class TestReqlogConfig:
    def test_defaults(self):
        config = ReqlogConfig()
        assert config.capture_body is False
        assert config.capture_headers is False
        assert config.max_body_size == 64_000
        assert config.sample_rate == 1.0
        assert "OPTIONS" in config.exclude_methods
        assert "/health" in config.exclude_paths

    def test_env_override_bool(self, monkeypatch):
        monkeypatch.setenv("REQLOG_CAPTURE_BODY", "true")
        config = ReqlogConfig()
        assert config.capture_body is True

    def test_env_override_float(self, monkeypatch):
        monkeypatch.setenv("REQLOG_SAMPLE_RATE", "0.5")
        config = ReqlogConfig()
        assert config.sample_rate == 0.5

    def test_env_override_int(self, monkeypatch):
        monkeypatch.setenv("REQLOG_MAX_BODY_SIZE", "1000")
        config = ReqlogConfig()
        assert config.max_body_size == 1000

    def test_env_override_list(self, monkeypatch):
        monkeypatch.setenv("REQLOG_EXCLUDE_PATHS", "/a, /b, /c")
        config = ReqlogConfig()
        assert config.exclude_paths == ["/a", "/b", "/c"]

    def test_env_override_format(self, monkeypatch):
        monkeypatch.setenv("REQLOG_FORMAT", "json")
        config = ReqlogConfig()
        assert config.format == "json"

    def test_resolve_format_explicit(self):
        config = ReqlogConfig(format="verbose")
        assert config.resolve_format() == "verbose"

    def test_resolve_format_env(self, monkeypatch):
        monkeypatch.setenv("REQLOG_FORMAT", "json")
        config = ReqlogConfig()
        # format field is set by env override in __post_init__
        assert config.resolve_format() == "json"

    def test_resolve_format_claude_code(self, monkeypatch):
        monkeypatch.setenv("CLAUDE_CODE", "1")
        # Need fresh config without REQLOG_FORMAT
        monkeypatch.delenv("REQLOG_FORMAT", raising=False)
        config = ReqlogConfig()
        assert config.resolve_format() == "ai"

    def test_resolve_format_aider(self, monkeypatch):
        monkeypatch.setenv("AIDER", "1")
        monkeypatch.delenv("REQLOG_FORMAT", raising=False)
        monkeypatch.delenv("CLAUDE_CODE", raising=False)
        monkeypatch.delenv("CURSOR_SESSION", raising=False)
        config = ReqlogConfig()
        assert config.resolve_format() == "ai"
