"""Tests for config validation."""

from __future__ import annotations

import pytest

from reqlog.core.config import ReqlogConfig


class TestConfigValidation:
    """Test configuration validation."""

    def test_valid_sample_rate(self) -> None:
        """Valid sample rates should not raise."""
        config = ReqlogConfig(sample_rate=0.5)
        assert config.sample_rate == 0.5

        config2 = ReqlogConfig(sample_rate=0.0)
        assert config2.sample_rate == 0.0

        config3 = ReqlogConfig(sample_rate=1.0)
        assert config3.sample_rate == 1.0

    def test_invalid_sample_rate_too_low(self) -> None:
        """Sample rate below 0.0 should raise ValueError."""
        with pytest.raises(ValueError, match="sample_rate must be between"):
            ReqlogConfig(sample_rate=-0.1)

    def test_invalid_sample_rate_too_high(self) -> None:
        """Sample rate above 1.0 should raise ValueError."""
        with pytest.raises(ValueError, match="sample_rate must be between"):
            ReqlogConfig(sample_rate=1.5)

    def test_invalid_max_body_size_negative(self) -> None:
        """Negative max_body_size should raise ValueError."""
        with pytest.raises(ValueError, match="max_body_size must be positive"):
            ReqlogConfig(max_body_size=-1)

    def test_valid_max_body_size(self) -> None:
        """Valid max_body_size should not raise."""
        config = ReqlogConfig(max_body_size=100_000)
        assert config.max_body_size == 100_000

    def test_invalid_sqlite_queue_size(self) -> None:
        """Invalid sqlite_max_queue_size should raise ValueError."""
        with pytest.raises(ValueError, match="sqlite_max_queue_size must be positive"):
            ReqlogConfig(sqlite_max_queue_size=0)

        with pytest.raises(ValueError, match="sqlite_max_queue_size must be positive"):
            ReqlogConfig(sqlite_max_queue_size=-10)

    def test_valid_sqlite_queue_size(self) -> None:
        """Valid sqlite_max_queue_size should not raise."""
        config = ReqlogConfig(sqlite_max_queue_size=5000)
        assert config.sqlite_max_queue_size == 5000

    def test_large_max_body_size_warning(self, caplog: pytest.LogCaptureFixture) -> None:
        """Very large max_body_size should log warning."""
        # This should not raise but should warn
        config = ReqlogConfig(max_body_size=150_000_000)
        assert config.max_body_size == 150_000_000

        # Check that a warning was logged
        assert any("very large" in record.message.lower() for record in caplog.records)
