from datetime import datetime, timezone

from reqlog.core.models import Request, Response, Transaction


class TestRequest:
    def test_defaults(self):
        req = Request(method="GET", path="/test")
        assert req.method == "GET"
        assert req.path == "/test"
        assert req.query_string == ""
        assert req.headers == {}
        assert req.body is None
        assert req.client_ip == ""

    def test_frozen(self):
        req = Request(method="GET", path="/test")
        try:
            req.method = "POST"  # type: ignore[misc]
            assert False, "Should raise"
        except AttributeError:
            pass


class TestResponse:
    def test_defaults(self):
        resp = Response(status_code=200)
        assert resp.status_code == 200
        assert resp.headers == {}
        assert resp.body is None

    def test_with_body(self):
        resp = Response(status_code=200, body=b'{"ok": true}', content_type="application/json")
        assert resp.body == b'{"ok": true}'


class TestTransaction:
    def test_status_class(self):
        cases = [(200, "2xx"), (301, "3xx"), (404, "4xx"), (500, "5xx")]
        for status, expected in cases:
            txn = Transaction(
                request=Request(method="GET", path="/"),
                response=Response(status_code=status),
                duration_ms=10.0,
            )
            assert txn.status_class == expected

    def test_auto_request_id(self):
        txn = Transaction(
            request=Request(method="GET", path="/"),
            response=Response(status_code=200),
            duration_ms=5.0,
        )
        assert len(txn.request_id) == 12

    def test_auto_timestamp(self):
        txn = Transaction(
            request=Request(method="GET", path="/"),
            response=Response(status_code=200),
            duration_ms=5.0,
        )
        assert isinstance(txn.timestamp, datetime)
        assert txn.timestamp.tzinfo == timezone.utc
