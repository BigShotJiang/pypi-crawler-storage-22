import pytest

from reqlog.backends.memory import MemoryBackend
from reqlog.core.config import ReqlogConfig
from reqlog.core.models import Request, Response, Transaction
from reqlog.core.pipeline import Pipeline


def _make_txn(
    method: str = "GET",
    path: str = "/test",
    status: int = 200,
    req_headers: dict | None = None,
    req_body: bytes | None = None,
    content_type: str = "",
) -> Transaction:
    return Transaction(
        request=Request(
            method=method,
            path=path,
            headers=req_headers or {},
            body=req_body,
            content_type=content_type,
        ),
        response=Response(status_code=status),
        duration_ms=10.0,
    )


class TestPipelineFiltering:
    def test_exclude_path(self):
        config = ReqlogConfig(exclude_paths=["/health"])
        pipeline = Pipeline(config, backends=[])
        txn = _make_txn(path="/health")
        assert pipeline.should_log(txn) is False

    def test_exclude_path_glob(self):
        config = ReqlogConfig(exclude_paths=["/api/internal/*"])
        pipeline = Pipeline(config, backends=[])
        assert pipeline.should_log(_make_txn(path="/api/internal/status")) is False
        assert pipeline.should_log(_make_txn(path="/api/users")) is True

    def test_exclude_method(self):
        config = ReqlogConfig(exclude_methods=["OPTIONS"])
        pipeline = Pipeline(config, backends=[])
        assert pipeline.should_log(_make_txn(method="OPTIONS")) is False
        assert pipeline.should_log(_make_txn(method="GET")) is True

    def test_include_paths(self):
        config = ReqlogConfig(include_paths=["/api/*"], exclude_paths=[])
        pipeline = Pipeline(config, backends=[])
        assert pipeline.should_log(_make_txn(path="/api/users")) is True
        assert pipeline.should_log(_make_txn(path="/other")) is False

    def test_exclude_status_codes(self):
        config = ReqlogConfig(exclude_status_codes=[204])
        pipeline = Pipeline(config, backends=[])
        assert pipeline.should_log(_make_txn(status=204)) is False
        assert pipeline.should_log(_make_txn(status=200)) is True

    def test_sampling_zero(self):
        config = ReqlogConfig(sample_rate=0.0)
        pipeline = Pipeline(config, backends=[])
        # With rate 0.0, nothing should pass
        results = [pipeline.should_log(_make_txn()) for _ in range(100)]
        assert not any(results)


class TestPipelineDispatch:
    @pytest.mark.asyncio
    async def test_dispatch_to_backend(self):
        backend = MemoryBackend()
        config = ReqlogConfig(exclude_paths=[], exclude_methods=[])
        pipeline = Pipeline(config, backends=[backend])
        await pipeline.process(_make_txn())
        assert len(backend) == 1

    @pytest.mark.asyncio
    async def test_dispatch_to_multiple_backends(self):
        b1 = MemoryBackend()
        b2 = MemoryBackend()
        config = ReqlogConfig(exclude_paths=[], exclude_methods=[])
        pipeline = Pipeline(config, backends=[b1, b2])
        await pipeline.process(_make_txn())
        assert len(b1) == 1
        assert len(b2) == 1

    @pytest.mark.asyncio
    async def test_backend_error_isolation(self):
        class FailingBackend:
            async def write(self, transaction):
                raise RuntimeError("boom")

        good = MemoryBackend()
        config = ReqlogConfig(exclude_paths=[], exclude_methods=[])
        pipeline = Pipeline(config, backends=[FailingBackend(), good])
        await pipeline.process(_make_txn())
        # Good backend still receives the transaction
        assert len(good) == 1

    @pytest.mark.asyncio
    async def test_sanitization_applied(self):
        backend = MemoryBackend()
        config = ReqlogConfig(
            exclude_paths=[],
            exclude_methods=[],
            sanitize_headers=["Authorization"],
        )
        pipeline = Pipeline(config, backends=[backend])
        txn = _make_txn(req_headers={"Authorization": "Bearer secret123"})
        await pipeline.process(txn)
        assert backend.transactions[0].request.headers["Authorization"] == "[REDACTED]"
