import json

from reqlog.core.models import Request, Response, Transaction
from reqlog.sanitize.redact import (
    redact_body_fields,
    redact_headers,
    sanitize_transaction,
)


class TestRedactHeaders:
    def test_redacts_matching_headers(self):
        headers = {"Authorization": "Bearer token", "Content-Type": "application/json"}
        result = redact_headers(headers, ["Authorization"])
        assert result["Authorization"] == "[REDACTED]"
        assert result["Content-Type"] == "application/json"

    def test_case_insensitive(self):
        headers = {"authorization": "Bearer token"}
        result = redact_headers(headers, ["Authorization"])
        assert result["authorization"] == "[REDACTED]"

    def test_glob_pattern(self):
        headers = {"X-Secret-Key": "abc", "X-Secret-Token": "def", "X-Normal": "ok"}
        result = redact_headers(headers, ["X-Secret-*"])
        assert result["X-Secret-Key"] == "[REDACTED]"
        assert result["X-Secret-Token"] == "[REDACTED]"
        assert result["X-Normal"] == "ok"

    def test_empty_headers(self):
        assert redact_headers({}, ["Authorization"]) == {}


class TestRedactBodyFields:
    def test_redacts_json_fields(self):
        body = json.dumps({"password": "hunter2", "email": "a@b.com"}).encode()
        result = redact_body_fields(body, ["password"], content_type="application/json")
        data = json.loads(result)
        assert data["password"] == "[REDACTED]"
        assert data["email"] == "a@b.com"

    def test_nested_fields(self):
        body = json.dumps({"user": {"password": "secret", "name": "Alice"}}).encode()
        result = redact_body_fields(body, ["password"], content_type="application/json")
        data = json.loads(result)
        assert data["user"]["password"] == "[REDACTED]"
        assert data["user"]["name"] == "Alice"

    def test_partial_match(self):
        body = json.dumps({"passwordHash": "abc123"}).encode()
        result = redact_body_fields(body, ["password"], content_type="application/json")
        data = json.loads(result)
        assert data["passwordHash"] == "[REDACTED]"

    def test_non_json_passthrough(self):
        body = b"plain text body"
        result = redact_body_fields(body, ["password"], content_type="text/plain")
        assert result == body

    def test_none_body(self):
        assert redact_body_fields(None, ["password"]) is None

    def test_invalid_json(self):
        body = b"not json {{"
        result = redact_body_fields(body, ["password"], content_type="application/json")
        assert result == body

    def test_list_body(self):
        body = json.dumps([{"password": "secret"}, {"name": "Bob"}]).encode()
        result = redact_body_fields(body, ["password"], content_type="application/json")
        data = json.loads(result)
        assert data[0]["password"] == "[REDACTED]"
        assert data[1]["name"] == "Bob"


class TestSanitizeTransaction:
    def test_full_sanitization(self):
        txn = Transaction(
            request=Request(
                method="POST",
                path="/login",
                headers={"Authorization": "Bearer token", "Content-Type": "application/json"},
                body=json.dumps({"password": "secret"}).encode(),
                content_type="application/json",
            ),
            response=Response(
                status_code=200,
                headers={"Set-Cookie": "session=abc"},
                body=json.dumps({"token": "jwt_abc"}).encode(),
                content_type="application/json",
            ),
            duration_ms=50.0,
        )

        result = sanitize_transaction(
            txn,
            sanitize_headers_list=["Authorization", "Set-Cookie"],
            sanitize_body_fields_list=["password", "token"],
        )

        assert result.request.headers["Authorization"] == "[REDACTED]"
        assert result.response.headers["Set-Cookie"] == "[REDACTED]"
        req_body = json.loads(result.request.body)
        assert req_body["password"] == "[REDACTED]"
        resp_body = json.loads(result.response.body)
        assert resp_body["token"] == "[REDACTED]"
        # Preserved fields
        assert result.request.method == "POST"
        assert result.duration_ms == 50.0
