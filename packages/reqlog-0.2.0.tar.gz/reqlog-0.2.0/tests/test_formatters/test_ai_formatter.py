import json
from datetime import datetime, timezone

from reqlog.core.models import Request, Response, Transaction
from reqlog.formatters.ai_formatter import (
    _decode_body_compact,
    _format_duration,
    format_ai_line,
)


def _make_txn(
    method: str = "POST",
    path: str = "/api/users",
    query_string: str = "",
    status: int = 201,
    duration_ms: float = 145.0,
    req_body: bytes | None = b'{"email":"alice@example.com","name":"Alice"}',
    res_body: bytes | None = b'{"id":43,"created_at":"2026-02-14T14:23:46Z"}',
    timestamp: datetime | None = None,
) -> Transaction:
    ts = timestamp or datetime(2026, 2, 14, 14, 23, 46, tzinfo=timezone.utc)
    return Transaction(
        request=Request(method=method, path=path, query_string=query_string, body=req_body),
        response=Response(status_code=status, body=res_body),
        duration_ms=duration_ms,
        timestamp=ts,
    )


class TestFormatAiLine:
    def test_basic_format(self):
        line = format_ai_line(_make_txn())
        assert "[14:23:46]" in line
        assert "POST /api/users" in line
        assert "\u2192 201" in line
        assert "(145ms)" in line
        assert "Req:" in line
        assert "Res:" in line
        assert line.endswith("---")

    def test_no_bodies(self):
        line = format_ai_line(_make_txn(req_body=None, res_body=None))
        assert "Req:" not in line
        assert "Res:" not in line
        assert "\n---" in line

    def test_query_string(self):
        line = format_ai_line(_make_txn(path="/search", query_string="q=hello"))
        assert "/search?q=hello" in line

    def test_duration_seconds(self):
        line = format_ai_line(_make_txn(duration_ms=2500.0))
        assert "(2.5s)" in line

    def test_separator_at_end(self):
        line = format_ai_line(_make_txn())
        assert line.strip().endswith("---")


class TestDecodeBodyCompact:
    def test_json_compacted(self):
        body = b'{"key":  "value",  "num": 42}'
        result = _decode_body_compact(body)
        assert result == '{"key":"value","num":42}'

    def test_truncation(self):
        body = json.dumps({"data": "x" * 2000}).encode()
        result = _decode_body_compact(body, max_length=50)
        assert len(result) == 50
        assert result.endswith("\u2026")

    def test_binary_fallback(self):
        body = b"\x80\x81\x82\xff"
        result = _decode_body_compact(body)
        assert result == "<binary 4 bytes>"

    def test_none_body(self):
        assert _decode_body_compact(None) is None

    def test_plain_text(self):
        body = b"just plain text"
        result = _decode_body_compact(body)
        assert result == "just plain text"

    def test_empty_body(self):
        result = _decode_body_compact(b"")
        assert result == ""


class TestFormatDuration:
    def test_milliseconds(self):
        assert _format_duration(42.0) == "42ms"

    def test_seconds(self):
        assert _format_duration(1500.0) == "1.5s"

    def test_sub_millisecond(self):
        assert _format_duration(0.5) == "0ms"
