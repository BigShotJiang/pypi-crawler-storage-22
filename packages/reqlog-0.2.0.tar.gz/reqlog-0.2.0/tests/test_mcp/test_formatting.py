"""Tests for MCP formatting functions."""

import json

from reqlog.mcp.formatting import (
    format_compact_row,
    format_endpoint_stats,
    format_error_summary,
    format_request_detail,
    format_status_summary,
)


def _make_row(
    *,
    id: str = "abc123",
    method: str = "GET",
    path: str = "/api/users",
    query_string: str | None = None,
    status_code: int = 200,
    duration_ms: float = 42.0,
    timestamp: str = "2026-02-14T14:23:46",
    client_ip: str | None = None,
    user_agent: str | None = None,
    request_headers: dict | None = None,
    request_body: str | None = None,
    response_headers: dict | None = None,
    response_body: str | None = None,
    request_content_type: str | None = None,
    response_content_type: str | None = None,
) -> dict:
    return {
        "id": id,
        "method": method,
        "path": path,
        "query_string": query_string,
        "status_code": status_code,
        "duration_ms": duration_ms,
        "timestamp": timestamp,
        "timestamp_unix": 1739542026.0,
        "client_ip": client_ip,
        "user_agent": user_agent,
        "request_headers": request_headers,
        "request_body": request_body,
        "response_headers": response_headers,
        "response_body": response_body,
        "request_content_type": request_content_type,
        "response_content_type": response_content_type,
    }


class TestFormatCompactRow:
    def test_basic(self):
        line = format_compact_row(_make_row())
        assert "GET" in line
        assert "/api/users" in line
        assert "200" in line
        assert "42ms" in line
        assert "id=abc123" in line

    def test_with_query_string(self):
        line = format_compact_row(_make_row(query_string="page=2"))
        assert "/api/users?page=2" in line

    def test_timestamp_extraction(self):
        line = format_compact_row(_make_row(timestamp="2026-02-14T14:23:46"))
        assert "14:23:46" in line

    def test_no_timestamp(self):
        line = format_compact_row(_make_row(timestamp=""))
        assert "GET" in line  # Should still work


class TestFormatRequestDetail:
    def test_basic_detail(self):
        detail = format_request_detail(_make_row())
        assert "GET /api/users" in detail
        assert "200" in detail
        assert "ID: abc123" in detail

    def test_with_headers(self):
        detail = format_request_detail(_make_row(
            request_headers={"Content-Type": "application/json"},
            response_headers={"X-Request-Id": "req-456"},
        ))
        assert "Content-Type: application/json" in detail
        assert "X-Request-Id: req-456" in detail

    def test_with_bodies(self):
        detail = format_request_detail(_make_row(
            request_body='{"name":"Alice"}',
            response_body='{"id":1}',
        ))
        assert "Request Body" in detail
        assert "Response Body" in detail
        assert "Alice" in detail

    def test_redact_bodies(self):
        detail = format_request_detail(
            _make_row(
                request_body='{"secret":"password123"}',
                response_body='{"token":"supersecrettoken"}',
            ),
            redact_bodies=True,
        )
        assert "[REDACTED]" in detail
        assert "password123" not in detail
        assert "supersecrettoken" not in detail

    def test_with_client_info(self):
        detail = format_request_detail(_make_row(
            client_ip="192.168.1.1",
            user_agent="Mozilla/5.0",
        ))
        assert "192.168.1.1" in detail
        assert "Mozilla/5.0" in detail

    def test_json_pretty_printing(self):
        body = json.dumps({"key": "value", "nested": {"a": 1}})
        detail = format_request_detail(_make_row(
            response_body=body,
            response_content_type="application/json",
        ))
        assert "Response Body" in detail


class TestFormatErrorSummary:
    def test_with_errors(self):
        data = {
            "total_errors": 3,
            "total_requests": 10,
            "error_rate": 30.0,
            "by_status": [
                {
                    "status_code": 404,
                    "count": 2,
                    "requests": [
                        _make_row(id="e1", status_code=404, path="/missing"),
                        _make_row(id="e2", status_code=404, path="/gone"),
                    ],
                },
                {
                    "status_code": 500,
                    "count": 1,
                    "requests": [
                        _make_row(id="e3", status_code=500, path="/crash",
                                  response_body='{"error":"internal"}'),
                    ],
                },
            ],
        }
        output = format_error_summary(data)
        assert "3/10" in output
        assert "30.0%" in output
        assert "HTTP 404" in output
        assert "HTTP 500" in output
        assert "/missing" in output
        assert "id=e3" in output

    def test_no_errors(self):
        data = {
            "total_errors": 0,
            "total_requests": 5,
            "error_rate": 0.0,
            "by_status": [],
        }
        output = format_error_summary(data)
        assert "0/5" in output
        assert "No errors found" in output

    def test_many_errors_truncated(self):
        """Errors beyond 5 per status should show '... and N more'."""
        requests = [_make_row(id=f"e{i}", status_code=500) for i in range(8)]
        data = {
            "total_errors": 8,
            "total_requests": 10,
            "error_rate": 80.0,
            "by_status": [{"status_code": 500, "count": 8, "requests": requests}],
        }
        output = format_error_summary(data)
        assert "... and 3 more" in output


class TestFormatEndpointStats:
    def test_basic_stats(self):
        endpoints = [
            {
                "path": "/api/users",
                "method": "GET",
                "request_count": 100,
                "avg_ms": 42.5,
                "p50_ms": 35.0,
                "p95_ms": 120.0,
                "p99_ms": 250.0,
                "status_2xx": 95,
                "status_4xx": 3,
                "status_5xx": 2,
            },
        ]
        output = format_endpoint_stats(endpoints)
        assert "GET" in output
        assert "/api/users" in output
        assert "100" in output
        assert "2xx:95" in output

    def test_empty(self):
        output = format_endpoint_stats([])
        assert "No endpoint data" in output


class TestFormatStatusSummary:
    def test_basic_summary(self):
        stats = {
            "total_requests": 100,
            "status_counts": {"2xx": 90, "4xx": 8, "5xx": 2},
            "avg_duration_ms": 45.0,
            "p95_duration_ms": 120.0,
        }
        output = format_status_summary(stats)
        assert "Total requests: 100" in output
        assert "Error rate: 10.0%" in output
        assert "Avg duration: 45ms" in output
        assert "Last error: none" in output

    def test_with_last_error(self):
        stats = {
            "total_requests": 50,
            "status_counts": {"2xx": 49, "5xx": 1},
            "avg_duration_ms": 30.0,
            "p95_duration_ms": 80.0,
        }
        error = _make_row(status_code=500, path="/crash", method="POST")
        output = format_status_summary(stats, last_error_row=error)
        assert "POST /crash -> 500" in output

    def test_no_requests(self):
        stats = {
            "total_requests": 0,
            "status_counts": {},
            "avg_duration_ms": 0,
            "p95_duration_ms": 0,
        }
        output = format_status_summary(stats)
        assert "Total requests: 0" in output
        assert "Error rate: 0.0%" in output
