"""Integration tests for MCP server tools and resources."""

import sqlite3
import time

import pytest

mcp_mod = pytest.importorskip("mcp")

from reqlog.mcp.server import create_server, _parse_relative_time  # noqa: E402


def _create_db(db_path: str, rows: list[tuple]) -> None:
    """Create a test database with the given rows."""
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS requests (
            id TEXT PRIMARY KEY,
            timestamp TEXT NOT NULL,
            timestamp_unix REAL NOT NULL,
            method TEXT NOT NULL,
            path TEXT NOT NULL,
            query_string TEXT,
            status_code INTEGER NOT NULL,
            duration_ms REAL NOT NULL,
            client_ip TEXT,
            user_agent TEXT,
            request_headers TEXT,
            request_body BLOB,
            response_headers TEXT,
            response_body BLOB,
            request_content_type TEXT,
            response_content_type TEXT
        )
    """)
    for idx in [
        "CREATE INDEX IF NOT EXISTS idx_requests_timestamp ON requests(timestamp_unix)",
        "CREATE INDEX IF NOT EXISTS idx_requests_status ON requests(status_code)",
        "CREATE INDEX IF NOT EXISTS idx_requests_path ON requests(path)",
    ]:
        conn.execute(idx)
    for row in rows:
        conn.execute(
            "INSERT INTO requests VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            row,
        )
    conn.commit()
    conn.close()


def _sample_rows() -> list[tuple]:
    now = time.time()
    return [
        ("r1", "2026-02-14T14:00:00", now, "GET", "/api/users", None, 200, 42.0,
         "127.0.0.1", "TestAgent", '{"Accept":"application/json"}',
         None, '{"Content-Type":"application/json"}',
         b'{"users":[{"id":1}]}', None, "application/json"),
        ("r2", "2026-02-14T14:00:01", now + 1, "POST", "/api/users", None, 201, 120.0,
         "127.0.0.1", None, None,
         b'{"name":"Alice"}', None, b'{"id":2}', "application/json", "application/json"),
        ("r3", "2026-02-14T14:00:02", now + 2, "GET", "/api/users/99", None, 404, 15.0,
         None, None, None, None, None, b'{"error":"not found"}', None, "application/json"),
        ("r4", "2026-02-14T14:00:03", now + 3, "POST", "/api/payments", None, 500, 250.0,
         None, None, None, b'{"amount":100}', None,
         b'{"error":"internal server error"}', "application/json", "application/json"),
        ("r5", "2026-02-14T14:00:04", now + 4, "GET", "/health", None, 200, 2.0,
         None, None, None, None, None, b'{"status":"ok"}', None, "application/json"),
    ]


def _get_tool_fn(server, name: str):
    """Extract a tool function from the FastMCP server by name."""
    # FastMCP stores tools internally; access via _tool_manager
    tool_manager = server._tool_manager
    tool = tool_manager._tools.get(name)
    if tool is None:
        raise KeyError(f"Tool {name!r} not found. Available: {list(tool_manager._tools.keys())}")
    return tool.fn


def _get_resource_fn(server, uri: str):
    """Extract a resource function from the FastMCP server by URI."""
    resource_manager = server._resource_manager
    resource = resource_manager._resources.get(uri)
    if resource is None:
        raise KeyError(f"Resource {uri!r} not found. Available: {list(resource_manager._resources.keys())}")
    return resource.fn


class TestParseRelativeTime:
    def test_seconds(self):
        ts = _parse_relative_time("30s")
        assert abs(ts - (time.time() - 30)) < 1

    def test_minutes(self):
        ts = _parse_relative_time("5m")
        assert abs(ts - (time.time() - 300)) < 1

    def test_hours(self):
        ts = _parse_relative_time("1h")
        assert abs(ts - (time.time() - 3600)) < 1

    def test_days(self):
        ts = _parse_relative_time("2d")
        assert abs(ts - (time.time() - 172800)) < 1

    def test_invalid_format(self):
        with pytest.raises(ValueError, match="Invalid time format"):
            _parse_relative_time("abc")


class TestGetRecentRequests:
    def test_basic(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, _sample_rows())
        server = create_server(db)
        fn = _get_tool_fn(server, "get_recent_requests")

        result = fn(limit=10)
        assert "5 requests" in result
        assert "GET" in result
        assert "/api/users" in result

    def test_status_filter(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, _sample_rows())
        server = create_server(db)
        fn = _get_tool_fn(server, "get_recent_requests")

        result = fn(status="error")
        assert "2 requests" in result
        assert "404" in result or "500" in result

    def test_method_filter(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, _sample_rows())
        server = create_server(db)
        fn = _get_tool_fn(server, "get_recent_requests")

        result = fn(method="POST")
        assert "2 requests" in result

    def test_empty_database(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, [])
        server = create_server(db)
        fn = _get_tool_fn(server, "get_recent_requests")

        result = fn()
        assert "No requests found" in result


class TestGetRequestDetail:
    def test_found(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, _sample_rows())
        server = create_server(db)
        fn = _get_tool_fn(server, "get_request_detail")

        result = fn(request_id="r1")
        assert "GET /api/users" in result
        assert "ID: r1" in result

    def test_not_found(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, _sample_rows())
        server = create_server(db)
        fn = _get_tool_fn(server, "get_request_detail")

        result = fn(request_id="nonexistent")
        assert "not found" in result.lower()

    def test_redact_bodies(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, _sample_rows())
        server = create_server(db, redact_bodies=True)
        fn = _get_tool_fn(server, "get_request_detail")

        result = fn(request_id="r2")
        assert "[REDACTED]" in result
        assert "Alice" not in result


class TestGetErrorSummary:
    def test_with_errors(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, _sample_rows())
        server = create_server(db)
        fn = _get_tool_fn(server, "get_error_summary")

        result = fn(minutes=60)
        assert "2/" in result  # 2 errors out of total
        assert "404" in result or "500" in result

    def test_empty_database(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, [])
        server = create_server(db)
        fn = _get_tool_fn(server, "get_error_summary")

        result = fn(minutes=60)
        assert "0/0" in result


class TestSearchRequests:
    def test_search_by_path(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, _sample_rows())
        server = create_server(db)
        fn = _get_tool_fn(server, "search_requests")

        result = fn(query="payments")
        assert "1 results" in result
        assert "/api/payments" in result

    def test_search_by_body(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, _sample_rows())
        server = create_server(db)
        fn = _get_tool_fn(server, "search_requests")

        result = fn(query="Alice")
        assert "1 results" in result

    def test_no_results(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, _sample_rows())
        server = create_server(db)
        fn = _get_tool_fn(server, "search_requests")

        result = fn(query="zzzznonexistent")
        assert "No requests found" in result


class TestGetEndpointStats:
    def test_basic(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, _sample_rows())
        server = create_server(db)
        fn = _get_tool_fn(server, "get_endpoint_stats")

        result = fn(minutes=60)
        assert "/api/users" in result
        assert "GET" in result

    def test_with_path_filter(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, _sample_rows())
        server = create_server(db)
        fn = _get_tool_fn(server, "get_endpoint_stats")

        result = fn(path="health", minutes=60)
        assert "/health" in result
        # Should not include /api/users
        assert "/api/users" not in result

    def test_empty_database(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, [])
        server = create_server(db)
        fn = _get_tool_fn(server, "get_endpoint_stats")

        result = fn(minutes=60)
        assert "No endpoint data" in result


class TestResources:
    def test_status_resource(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, _sample_rows())
        server = create_server(db)
        fn = _get_resource_fn(server, "reqlog://status")

        result = fn()
        assert "Total requests:" in result
        assert "Error rate:" in result

    def test_recent_errors_resource(self, tmp_path):
        db = str(tmp_path / "test.db")
        _create_db(db, _sample_rows())
        server = create_server(db)
        fn = _get_resource_fn(server, "reqlog://recent-errors")

        result = fn()
        assert "404" in result or "500" in result

    def test_recent_errors_empty(self, tmp_path):
        db = str(tmp_path / "test.db")
        # Only 200s
        now = time.time()
        _create_db(db, [
            ("r1", "2026-02-14T14:00:00", now, "GET", "/ok", None, 200, 10.0,
             None, None, None, None, None, None, None, None),
        ])
        server = create_server(db)
        fn = _get_resource_fn(server, "reqlog://recent-errors")

        result = fn()
        assert "No recent errors" in result
