"""Tests for MCP server parameter validation."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

mcp_mod = pytest.importorskip("mcp")

from reqlog.backends.sqlite import SQLiteBackend  # noqa: E402
from reqlog.core.models import Request, Response, Transaction  # noqa: E402
from reqlog.mcp.server import create_server, MAX_QUERY_LIMIT, MAX_TIME_WINDOW_MINUTES, MAX_SEARCH_QUERY_LENGTH  # noqa: E402


def _get_tool_fn(server, name: str):
    """Extract a tool function from the FastMCP server by name."""
    tool_manager = server._tool_manager
    tool = tool_manager._tools.get(name)
    if tool is None:
        raise KeyError(f"Tool {name!r} not found. Available: {list(tool_manager._tools.keys())}")
    return tool.fn


@pytest.fixture
def db_with_data() -> str:
    """Create a temporary database with test data."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name

    # Populate with test data
    import asyncio
    backend = SQLiteBackend(db_path=db_path)

    async def populate():
        for i in range(10):
            txn = Transaction(
                request=Request(method="GET", path=f"/test/{i}"),
                response=Response(status_code=200 if i % 2 == 0 else 500),
                duration_ms=10.0 + i,
                request_id=f"test-{i}",
            )
            await backend.write(txn)
        await backend.close()

    asyncio.run(populate())
    yield db_path

    # Cleanup
    Path(db_path).unlink()


class TestGetRecentRequestsValidation:
    """Test parameter validation for get_recent_requests."""

    def test_limit_too_low(self, db_with_data: str) -> None:
        """Limit below 1 should return error."""
        server = create_server(db_with_data)
        fn = _get_tool_fn(server, "get_recent_requests")

        result = fn(limit=0)
        assert "Error:" in result
        assert "limit must be between" in result

    def test_limit_too_high(self, db_with_data: str) -> None:
        """Limit above MAX_QUERY_LIMIT should return error."""
        server = create_server(db_with_data)
        fn = _get_tool_fn(server, "get_recent_requests")

        result = fn(limit=MAX_QUERY_LIMIT + 1)
        assert "Error:" in result
        assert f"{MAX_QUERY_LIMIT}" in result

    def test_valid_limit(self, db_with_data: str) -> None:
        """Valid limit should work."""
        server = create_server(db_with_data)
        fn = _get_tool_fn(server, "get_recent_requests")

        result = fn(limit=5)
        assert "Error:" not in result or "not found" in result.lower()


class TestGetErrorSummaryValidation:
    """Test parameter validation for get_error_summary."""

    def test_minutes_too_low(self, db_with_data: str) -> None:
        """Minutes below 1 should return error."""
        server = create_server(db_with_data)
        fn = _get_tool_fn(server, "get_error_summary")

        result = fn(minutes=0)
        assert "Error:" in result
        assert "minutes must be between" in result

    def test_minutes_too_high(self, db_with_data: str) -> None:
        """Minutes above MAX_TIME_WINDOW_MINUTES should return error."""
        server = create_server(db_with_data)
        fn = _get_tool_fn(server, "get_error_summary")

        result = fn(minutes=MAX_TIME_WINDOW_MINUTES + 1)
        assert "Error:" in result
        assert f"{MAX_TIME_WINDOW_MINUTES}" in result

    def test_valid_minutes(self, db_with_data: str) -> None:
        """Valid minutes should work."""
        server = create_server(db_with_data)
        fn = _get_tool_fn(server, "get_error_summary")

        result = fn(minutes=5)
        # Should not contain validation error
        assert "minutes must be between" not in result


class TestSearchRequestsValidation:
    """Test parameter validation for search_requests."""

    def test_query_too_long(self, db_with_data: str) -> None:
        """Query exceeding MAX_SEARCH_QUERY_LENGTH should return error."""
        server = create_server(db_with_data)
        fn = _get_tool_fn(server, "search_requests")

        long_query = "x" * (MAX_SEARCH_QUERY_LENGTH + 1)
        result = fn(query=long_query)
        assert "Error:" in result
        assert "query too long" in result

    def test_limit_validation(self, db_with_data: str) -> None:
        """Limit parameter should be validated."""
        server = create_server(db_with_data)
        fn = _get_tool_fn(server, "search_requests")

        result = fn(query="test", limit=MAX_QUERY_LIMIT + 1)
        assert "Error:" in result
        assert "limit must be between" in result

    def test_valid_query(self, db_with_data: str) -> None:
        """Valid query should work."""
        server = create_server(db_with_data)
        fn = _get_tool_fn(server, "search_requests")

        result = fn(query="test", limit=10)
        # Should not contain validation error
        assert "query too long" not in result
        assert "limit must be between" not in result


class TestGetEndpointStatsValidation:
    """Test parameter validation for get_endpoint_stats."""

    def test_minutes_validation(self, db_with_data: str) -> None:
        """Minutes parameter should be validated."""
        server = create_server(db_with_data)
        fn = _get_tool_fn(server, "get_endpoint_stats")

        result = fn(minutes=MAX_TIME_WINDOW_MINUTES + 1)
        assert "Error:" in result
        assert "minutes must be between" in result

    def test_valid_minutes(self, db_with_data: str) -> None:
        """Valid minutes should work."""
        server = create_server(db_with_data)
        fn = _get_tool_fn(server, "get_endpoint_stats")

        result = fn(minutes=60)
        # Should not contain validation error
        assert "minutes must be between" not in result


class TestErrorMessageSanitization:
    """Test that error messages don't leak internal details."""

    def test_no_stack_traces_in_errors(self, db_with_data: str) -> None:
        """Errors should not include stack traces or internal paths."""
        server = create_server(db_with_data)
        fn = _get_tool_fn(server, "get_request_detail")

        # Try to get detail for non-existent request
        # This should return a safe error message
        result = fn(request_id="nonexistent")

        # Should have friendly message, not exception details
        assert "Request not found" in result or "error occurred" in result.lower()
        # Should NOT contain internal paths or stack traces
        assert "/Users/" not in result
        assert "Traceback" not in result
        assert ".py" not in result
