# This is a sample Python script.

# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press ⌘F8 to toggle the breakpoint.



class RZDRequest:
    def __init__(self, client: AsyncClient):
        self.client = client
        self.headers = {
       
        }
    
    @request_logging()
    @validate_response(
        model=Response,
        body_type="json",
        validator=ResponseValidator()
        .status_code().whitelist([200])
        
    )
    async def login(self):
        url = f""
        headers = self.headers.copy()
        body = {}
        
        response = await self.client.get(url, headers=headers)
        return response


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
