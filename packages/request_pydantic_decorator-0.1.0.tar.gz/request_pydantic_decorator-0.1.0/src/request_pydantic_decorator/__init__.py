# -*- coding: utf-8 -*-
"""
request_pydantic_decorator — валидация HTTP-ответов, декораторы и иерархия исключений API.

Импорт исключений через объект Exceptions (группы Auth, Register, Validation):

    from request_pydantic_decorator import Exceptions
    raise Exceptions.Auth.Captcha()
    raise Exceptions.Auth.AccountBanned()
    raise Exceptions.Register.EmailExists()
    raise Exceptions.Register.PasswordRequirements("Минимум 8 символов")
    raise Exceptions.Validation.StatusCode("Получен 500")
"""
from . import exceptions
from . import types
from . import validators
from . import decorators

from .exceptions import (
    Exceptions,
    ApiError,
    AuthError,
    ErrorCaptcha,
    ErrorCreds,
    TokenExpired,
    Invalid2FACode,
    AccountBanned,
    SuspiciousActivity,
    RateLimit,
    SessionExpired,
    AccountLocked,
    AccountDisabled,
    MustChangePassword,
    RegisterError,
    UserExists,
    EmailExists,
    LoginRequirements,
    PasswordRequirements,
    ConfirmEmailRequired,
    InviteCodeInvalid,
    UsernameTaken,
    PhoneExists,
    TermsNotAccepted,
    RegisterRateLimit,
    NotFoundError,
    ResponseValidationError,
    StatusCodeError,
    RedirectError,
    HeaderError,
)
from .types import HttpResponse, ValidateResponse, T, R, P
from .validators import (
    ResponseValidator,
    ResponseCondition,
    CompositeRule,
    status_code_in,
    status_code_is,
    redirect_url_contains,
    header_equals,
    header_contains,
    header_missing,
)
from .decorators import validate_response, request_logging

__all__ = [
    # Exceptions
    "Exceptions",
    "ApiError",
    "AuthError",
    "ErrorCaptcha",
    "ErrorCreds",
    "TokenExpired",
    "Invalid2FACode",
    "AccountBanned",
    "SuspiciousActivity",
    "RateLimit",
    "SessionExpired",
    "AccountLocked",
    "AccountDisabled",
    "MustChangePassword",
    "RegisterError",
    "UserExists",
    "EmailExists",
    "LoginRequirements",
    "PasswordRequirements",
    "ConfirmEmailRequired",
    "InviteCodeInvalid",
    "UsernameTaken",
    "PhoneExists",
    "TermsNotAccepted",
    "RegisterRateLimit",
    "NotFoundError",
    "ResponseValidationError",
    "StatusCodeError",
    "RedirectError",
    "HeaderError",
    # Types
    "HttpResponse",
    "ValidateResponse",
    "T",
    "R",
    "P",
    # Validators
    "ResponseValidator",
    "ResponseCondition",
    "CompositeRule",
    "status_code_in",
    "status_code_is",
    "redirect_url_contains",
    "header_equals",
    "header_contains",
    "header_missing",
    # Decorators
    "validate_response",
    "request_logging",
]

__version__ = "0.1.0"
