# -*- coding: utf-8 -*-
"""Типы и протоколы: HttpResponse, ValidateResponse, TypeVar для декораторов и валидаторов."""
from dataclasses import dataclass
from typing import TypeVar, ParamSpec, Generic, Any, List, Protocol, runtime_checkable

from pydantic import BaseModel


T = TypeVar("T", bound=BaseModel)
R = TypeVar("R")
P = ParamSpec("P")


@runtime_checkable
class HttpResponse(Protocol):
    """Протокол ответа HTTP (requests.Response, httpx.Response и т.п.)."""

    def json(self, **kwargs: Any) -> Any: ...

    @property
    def text(self) -> str: ...

    @property
    def headers(self) -> Any: ...

    @property
    def status_code(self) -> int: ...

    @property
    def history(self) -> List[Any]: ...

    @property
    def cookies(self) -> Any: ...

    @property
    def url(self) -> Any: ...


@dataclass
class ValidateResponse(Generic[T, R]):
    """Класс для хранения оригинального ответа и валидированных данных."""

    response: R
    validate: T | None
    error: Exception | None = None
