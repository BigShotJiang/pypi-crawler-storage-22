# -*- coding: utf-8 -*-
"""Фикстуры: fake HTTP response, реализующий HttpResponse protocol."""
from __future__ import annotations

from typing import Any, List, Dict


class FakeResponse:
    """Имитация requests.Response / httpx.Response для тестов."""

    __slots__ = (
        "_status_code", "_headers", "_url", "_history", "_text", "_json_obj",
        "_cookies", "_request",
    )

    def __init__(
        self,
        status_code: int = 200,
        headers: Dict[str, str] | None = None,
        url: str = "https://example.com/",
        history: List[Any] | None = None,
        text: str = "",
        json_obj: Any = None,
        cookies: Any = None,
        request: Any = None,
    ):
        self._status_code = status_code
        self._headers = dict(headers or {})
        self._url = url
        self._history = list(history or [])
        self._text = text
        self._json_obj = json_obj
        self._cookies = cookies or {}
        self._request = request

    @property
    def status_code(self) -> int:
        return self._status_code

    @property
    def headers(self) -> Dict[str, str]:
        return self._headers

    @property
    def url(self) -> str:
        return self._url

    @property
    def history(self) -> List[Any]:
        return self._history

    @property
    def text(self) -> str:
        return self._text

    def json(self, **kwargs: Any) -> Any:
        if self._json_obj is None:
            raise ValueError("Response is not JSON")
        return self._json_obj

    @property
    def cookies(self) -> Any:
        return self._cookies

    @property
    def request(self) -> Any:
        return self._request


def make_response(
    status_code: int = 200,
    headers: Dict[str, str] | None = None,
    url: str = "https://example.com/",
    history: List[Any] | None = None,
    text: str = "",
    json_body: Any = None,
) -> FakeResponse:
    """Создать FakeResponse с опциональным JSON-телом."""
    return FakeResponse(
        status_code=status_code,
        headers=headers or {},
        url=url,
        history=history or [],
        text=text,
        json_obj=json_body,
    )
