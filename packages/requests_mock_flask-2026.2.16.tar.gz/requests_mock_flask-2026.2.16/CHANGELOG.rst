Changelog
=========

Next
----

2026.02.16
----------


* Add support for ``respx``.

2026.01.12
----------


* Fix a bug where routes with multiple variables (e.g. ``/users/<org>/<user>/posts``) would incorrectly match URLs with extra path segments.

2025.01.13
----------

* Add requirements for ``httpretty``, ``requests-mock`` and ``responses``.
* Add more type safety for the passed in mock object.

2024.08.30.1
------------

2024.08.30
------------

2023.05.14
------------

2023.03.05.1
------------

2023.03.05
------------

2022.04.03
------------

2021.12.28.1
------------

Add support for ``httpretty``.

2021.12.28
------------

Remove ``Flask``, ``requests`` and ``requests_mock`` as dependencies.

2021.12.13
------------

2021.07.10.0
------------

Support Flask 2 and greater.
Drop support for Flask < 2.
Please use an older version of this package if you wish to use an older version of Flask.

2020.09.25.0
------------

2020.09.18.0
------------

2020.09.16.0
------------

2020.09.14.1
------------

2020.09.14.0
------------

2020.01.20.2
------------

2020.01.20.1
------------

2020.01.20.0
------------
