#ifndef OPM_ERT_FORTIO_KW
#define OPM_ERT_FORTIO_KW

#include <fstream>
#include <string>
#include <memory>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#include <ert/util/util.hpp>
#include <ert/util/type_macros.hpp>
#include <resdata/FortIO.hpp>
#include <resdata/rd_endian_flip.hpp>
#include <ert/util/ert_unique_ptr.hpp>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    FORTIO_NOENTRY = 0, /* File does not exists at all - application error. */
    FORTIO_EOF = 1,     /* The file / record is empty */
    FORTIO_OK =
        2, /* The file / record is OK with: [32 bit header | data | 32 bit footer] */
    FORTIO_MISSING_DATA = 3,
    FORTIO_MISSING_TAIL = 4,
    FORTIO_HEADER_MISMATCH = 5
} fortio_status_type;

typedef struct fortio_struct fortio_type;

bool fortio_looks_like_fortran_file(const char *, bool);
fortio_type *fortio_open_reader(const char *, bool fmt_file,
                                bool endian_flip_header);
fortio_type *fortio_open_writer(const char *, bool fmt_file,
                                bool endian_flip_header);
fortio_type *fortio_open_readwrite(const char *, bool fmt_file,
                                   bool endian_flip_header);
fortio_type *fortio_open_append(const char *filename, bool fmt_file,
                                bool endian_flip_header);
fortio_type *fortio_alloc_FILE_wrapper(const char *, bool, bool, bool, FILE *);
void fortio_free_FILE_wrapper(fortio_type *);
void fortio_fclose(fortio_type *);
int fortio_init_read(fortio_type *);
bool fortio_complete_read(fortio_type *, int record_size);
void fortio_init_write(fortio_type *, int);
void fortio_complete_write(fortio_type *, int record_size);
int fortio_fskip_record(fortio_type *);
bool fortio_fread_buffer(fortio_type *, char *buffer, int buffer_size);
void fortio_fwrite_record(fortio_type *, const char *buffer, int buffer_size);
FILE *fortio_get_FILE(const fortio_type *);
void fortio_fflush(fortio_type *);
void fortio_rewind(const fortio_type *fortio);
const char *fortio_filename_ref(const fortio_type *);
bool fortio_fmt_file(const fortio_type *);
offset_type fortio_ftell(const fortio_type *fortio);
bool fortio_fseek(fortio_type *fortio, offset_type offset, int whence);
bool fortio_data_fskip(fortio_type *fortio, const int element_size,
                       const int element_count, const int block_count);
void fortio_data_fseek(fortio_type *fortio, offset_type data_offset,
                       size_t data_element, const int element_size,
                       const int element_count, const int block_size);
bool fortio_ftruncate(fortio_type *fortio, offset_type size);
int fortio_fclean(fortio_type *fortio);

bool fortio_fclose_stream(fortio_type *fortio);
bool fortio_fopen_stream(fortio_type *fortio);
bool fortio_stream_is_open(const fortio_type *fortio);
bool fortio_assert_stream_open(fortio_type *fortio);
bool fortio_read_at_eof(fortio_type *fortio);
void fortio_fwrite_error(fortio_type *fortio);

UTIL_IS_INSTANCE_HEADER(fortio);
UTIL_SAFE_CAST_HEADER(fortio);

#ifdef __cplusplus
}
#endif

namespace ERT {
class FortIO {
public:
    FortIO();
    FortIO(const std::string &filename, std::ios_base::openmode mode,
           bool fmt_file = false, bool endian_flip_header = RD_ENDIAN_FLIP);
    void open(const std::string &filename, std::ios_base::openmode mode,
              bool fmt_file = false, bool endian_flip_header = RD_ENDIAN_FLIP);
    void fflush() const;
    bool ftruncate(offset_type new_size);

    fortio_type *get() const;
    void close();

private:
    ert_unique_ptr<fortio_type, fortio_fclose> m_fortio;
};
} // namespace ERT

#endif
