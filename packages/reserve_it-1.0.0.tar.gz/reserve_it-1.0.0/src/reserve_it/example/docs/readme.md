# NOTE

The `docs` directory must be in your project root for Mkdocs to build the site. You
can also add arbitrary extra static webpages if you'd like, just add some markdown
files. Like this one!
