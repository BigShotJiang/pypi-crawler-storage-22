from respan.constants.dataset_constants import *
from respan.constants.prompt_constants import *

KEYWORDS_AI_DEFAULT_BASE_URL = "https://api.respan.ai"

BASE_URL_SUFFIX = "/api"