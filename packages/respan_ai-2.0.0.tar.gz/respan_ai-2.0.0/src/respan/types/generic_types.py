from respan_sdk.respan_types.generic_types import PaginatedResponseType

__all__ = [
    "PaginatedResponseType",
]