# Context keys for Respan tracing
WORKFLOW_NAME_KEY = "respan_workflow_name"
ENTITY_PATH_KEY = "respan_entity_path" 
TRACE_GROUP_ID_KEY = "respan_trace_group_identifier"
PARAMS_KEY = "respan_params"
ENABLE_CONTENT_TRACING_KEY = "respan_enable_content_tracing"
