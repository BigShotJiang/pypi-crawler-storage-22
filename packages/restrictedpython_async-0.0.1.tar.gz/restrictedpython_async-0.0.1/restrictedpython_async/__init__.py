"""Patches RestrictedPython to support async/await."""

__version__ = "0.0.1"

from RestrictedPython import RestrictingNodeTransformer, compile_restricted
from RestrictedPython.compile import (
    _compile_restricted_mode, CompileResult, IS_CPYTHON,
    NOT_CPYTHON_WARNING, syntax_error_template
)
import ast, RestrictedPython.compile as _rpc

async_builtins = {'aiter': aiter, 'anext': anext}

# Patch async AST nodes to be allowed
def _allow(self, node): return self.node_contents_visit(node)
for _m in ('visit_Await', 'visit_AsyncFor', 'visit_AsyncWith', 'visit_AsyncFunctionDef'): setattr(RestrictingNodeTransformer, _m, _allow)

# Patch _compile_restricted_mode to pass flags through to compile()
def _compile_restricted_mode_patched(
        source, filename='<string>', mode="exec", flags=0,
        dont_inherit=False, policy=RestrictingNodeTransformer):
    flags |= ast.PyCF_ALLOW_TOP_LEVEL_AWAIT
    code,errs,warns,used = None,[],[],{}
    if policy is None:
        code = compile(source, filename, mode=mode, flags=flags, dont_inherit=dont_inherit)
    elif issubclass(policy, RestrictingNodeTransformer):
        if not isinstance(source, (str, ast.Module)):
            raise TypeError(f'Not allowed source type: "{type(source).__name__}".')
        try: tree = source if isinstance(source, ast.Module) else ast.parse(source, filename, mode)
        except (TypeError, ValueError) as e: errs.append(str(e))
        except SyntaxError as v:
            errs.append(syntax_error_template.format(
                lineno=v.lineno, type=v.__class__.__name__,
                msg=v.msg, statement=v.text.strip() if v.text else None))
        else:
            pol = policy(errs, warns, used)
            pol.visit(tree)
            if not errs: code = compile(tree, filename, mode=mode, flags=flags, dont_inherit=dont_inherit)
    else: raise TypeError('Unallowed policy provided for RestrictedPython')
    return CompileResult(code, tuple(errs), warns, used)

_rpc._compile_restricted_mode = _compile_restricted_mode_patched