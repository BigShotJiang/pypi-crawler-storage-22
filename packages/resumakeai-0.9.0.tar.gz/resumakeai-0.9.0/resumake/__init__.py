"""resumake — Build styled CV documents from a single YAML source."""

from importlib.metadata import version as _get_version
from typing import Annotated, Optional

import typer


def _version_callback(value: bool):
    if value:
        print(f"resumake {_get_version('resumakeai')}")
        raise typer.Exit()


app = typer.Typer(
    name="resumake",
    help="Build styled CV documents from a single YAML source.",
    invoke_without_command=True,
    no_args_is_help=False,
)


@app.callback(invoke_without_command=True)
def default(
    ctx: typer.Context,
    version: Annotated[
        Optional[bool],
        typer.Option("--version", "-V", help="Show version and exit.", callback=_version_callback, is_eager=True),
    ] = None,
):
    """Default: run the build command if no subcommand is given."""
    if ctx.invoked_subcommand is None:
        from .build import build

        build()


# Register commands
from .build import build

app.command()(build)

from .tailor import tailor

app.command()(tailor)

from .bio import bio

app.command()(bio)

from .validate_cmd import validate

app.command()(validate)

from .init_cmd import init

app.command()(init)

from .themes_cmd import themes

app.command()(themes)

from .export_cmd import export

app.command()(export)

from .preview_cmd import preview

app.command()(preview)

from .diff_cmd import diff

app.command()(diff)

from .cover_letter import cover_letter

app.command(name="cover")(cover_letter)

from .import_cmd import import_

app.command(name="import")(import_)

from .suggest_cmd import suggest

app.command()(suggest)

from .ats_cmd import ats

app.command()(ats)

from .web_cmd import web

app.command()(web)
