"""
Test suite for ReSynth
"""
