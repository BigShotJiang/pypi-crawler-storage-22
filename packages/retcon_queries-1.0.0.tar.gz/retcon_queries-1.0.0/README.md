# Retcon Queries

Shared GraphQL queries for the Retcon platform. Published as both npm (`@retcon/queries`) and PyPI (`retcon-queries`) packages.

## Installation

### TypeScript / JavaScript

```bash
npm install @retcon/queries
```

### Python

```bash
pip install retcon-queries
```

Or for local development:

```bash
pip install -e ../retcon-queries
```

## Usage

### TypeScript

```typescript
import { GET_FEEDS, GET_FEED_BY_URL } from '@retcon/queries';

// Use with any GraphQL client
const result = await client.query({
  query: GET_FEEDS,
  variables: { limit: 100 }
});
```

### Python

```python
from retcon_queries import GET_FEEDS, GET_FEED_BY_URL

# Use with any GraphQL client (httpx, gql, etc.)
response = await client.post(
    graphql_url,
    json={"query": GET_FEEDS, "variables": {"limit": 100}}
)
```

## Available Queries

### Registry Queries

| Query | Description | Variables |
|-------|-------------|-----------|
| `GET_FEEDS` | Get all Feed-Registry entries | `cursor`, `limit` |
| `GET_FEED_BY_URL` | Get feed by canonical URL | `feedUrl` |
| `GET_FEEDS_BY_CATEGORY` | Filter feeds by category | `category`, `cursor`, `limit` |
| `GET_FEEDS_BY_CONTRIBUTOR` | Filter by contributor wallet | `contributor`, `cursor`, `limit` |
| `CHECK_FEED_EXISTS` | Check if feed URL exists | `feedUrl` |

### Archive Queries

| Query | Description | Variables |
|-------|-------------|-----------|
| `GET_ARTICLES` | Get all Article-Archive entries | `cursor`, `limit` |
| `GET_ARTICLES_BY_FEED` | Get articles from a feed | `feedUrl`, `cursor`, `limit` |
| `GET_ARTICLE_BY_URL` | Get article by URL | `articleUrl` |
| `GET_ARTICLE_BY_HASH` | Get article by content hash | `contentHash` |

## Arweave GraphQL Endpoints

- **Primary**: `https://arweave-search.goldsky.com/graphql` (Goldsky - optimized)
- **Fallback**: `https://arweave.net/graphql` (Official gateway)

## Development

```bash
# TypeScript
npm install
npm run build

# Python
pip install -e ".[dev]"
pytest
```

## Package Structure

```
retcon-queries/
├── package.json          # npm package config
├── pyproject.toml        # PyPI package config
├── tsconfig.json
├── src/                  # TypeScript source
│   ├── index.ts
│   ├── registry.ts
│   └── archive.ts
├── python/               # Python source
│   └── retcon_queries/
│       ├── __init__.py
│       ├── registry.py
│       └── archive.py
└── graphql/              # Raw .graphql files (reference)
    ├── registry/
    └── archive/
```
