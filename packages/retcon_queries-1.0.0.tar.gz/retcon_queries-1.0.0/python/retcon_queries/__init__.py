"""
retcon-queries - Shared GraphQL queries for the Retcon platform

This package provides canonical GraphQL queries that can be used by
any Retcon client (TypeScript, Python, etc.)

Usage:
    from retcon_queries import registry, archive
    
    # Use in your GraphQL client
    query = registry.GET_FEEDS
    variables = {"limit": 100}
"""

from retcon_queries.registry import (
    GET_FEEDS,
    GET_FEED_BY_URL,
    GET_FEEDS_BY_CATEGORY,
    GET_FEEDS_BY_CONTRIBUTOR,
    CHECK_FEED_EXISTS,
)
from retcon_queries.archive import (
    GET_ARTICLES,
    GET_ARTICLES_BY_FEED,
    GET_ARTICLE_BY_URL,
    GET_ARTICLE_BY_HASH,
)

__version__ = "1.0.0"

__all__ = [
    # Registry queries
    "GET_FEEDS",
    "GET_FEED_BY_URL",
    "GET_FEEDS_BY_CATEGORY",
    "GET_FEEDS_BY_CONTRIBUTOR",
    "CHECK_FEED_EXISTS",
    # Archive queries
    "GET_ARTICLES",
    "GET_ARTICLES_BY_FEED",
    "GET_ARTICLE_BY_URL",
    "GET_ARTICLE_BY_HASH",
]
