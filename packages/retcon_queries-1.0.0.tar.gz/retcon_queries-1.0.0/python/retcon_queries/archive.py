"""Article Archive GraphQL queries."""

# Get all Article-Archive entries with pagination
GET_ARTICLES = """
query GetArticles($cursor: String, $limit: Int = 100) {
  transactions(
    tags: [
      { name: "App-Name", values: ["Retcon"] }
      { name: "Entity-Type", values: ["Article-Archive"] }
    ]
    first: $limit
    after: $cursor
    sort: HEIGHT_DESC
  ) {
    edges {
      cursor
      node {
        id
        tags {
          name
          value
        }
      }
    }
    pageInfo {
      hasNextPage
    }
  }
}
"""

# Get Article-Archive entries by feed URL
GET_ARTICLES_BY_FEED = """
query GetArticlesByFeed($feedUrl: String!, $cursor: String, $limit: Int = 50) {
  transactions(
    tags: [
      { name: "App-Name", values: ["Retcon"] }
      { name: "Entity-Type", values: ["Article-Archive"] }
      { name: "Feed-URL", values: [$feedUrl] }
    ]
    first: $limit
    after: $cursor
    sort: HEIGHT_DESC
  ) {
    edges {
      cursor
      node {
        id
        tags {
          name
          value
        }
      }
    }
    pageInfo {
      hasNextPage
    }
  }
}
"""

# Get Article-Archive entry by article URL
GET_ARTICLE_BY_URL = """
query GetArticleByUrl($articleUrl: String!) {
  transactions(
    tags: [
      { name: "App-Name", values: ["Retcon"] }
      { name: "Entity-Type", values: ["Article-Archive"] }
      { name: "Article-URL", values: [$articleUrl] }
    ]
    first: 1
    sort: HEIGHT_DESC
  ) {
    edges {
      node {
        id
        tags {
          name
          value
        }
      }
    }
  }
}
"""

# Get Article-Archive entry by content hash
GET_ARTICLE_BY_HASH = """
query GetArticleByHash($contentHash: String!) {
  transactions(
    tags: [
      { name: "App-Name", values: ["Retcon"] }
      { name: "Entity-Type", values: ["Article-Archive"] }
      { name: "Content-Hash", values: [$contentHash] }
    ]
    first: 1
  ) {
    edges {
      node {
        id
        tags {
          name
          value
        }
      }
    }
  }
}
"""
