"""Feed Registry GraphQL queries."""

# Get all Feed-Registry entries with pagination
GET_FEEDS = """
query GetFeeds($cursor: String, $limit: Int = 100) {
  transactions(
    tags: [
      { name: "App-Name", values: ["Retcon"] }
      { name: "Entity-Type", values: ["Feed-Registry"] }
    ]
    first: $limit
    after: $cursor
    sort: HEIGHT_DESC
  ) {
    edges {
      cursor
      node {
        id
        tags {
          name
          value
        }
      }
    }
    pageInfo {
      hasNextPage
    }
  }
}
"""

# Get Feed-Registry entry by canonical feed URL
GET_FEED_BY_URL = """
query GetFeedByUrl($feedUrl: String!) {
  transactions(
    tags: [
      { name: "App-Name", values: ["Retcon"] }
      { name: "Entity-Type", values: ["Feed-Registry"] }
      { name: "Canonical-For", values: [$feedUrl] }
    ]
    first: 1
    sort: HEIGHT_DESC
  ) {
    edges {
      node {
        id
        tags {
          name
          value
        }
      }
    }
  }
}
"""

# Get Feed-Registry entries by category
GET_FEEDS_BY_CATEGORY = """
query GetFeedsByCategory($category: String!, $cursor: String, $limit: Int = 50) {
  transactions(
    tags: [
      { name: "App-Name", values: ["Retcon"] }
      { name: "Entity-Type", values: ["Feed-Registry"] }
      { name: "Category", values: [$category] }
    ]
    first: $limit
    after: $cursor
    sort: HEIGHT_DESC
  ) {
    edges {
      cursor
      node {
        id
        tags {
          name
          value
        }
      }
    }
    pageInfo {
      hasNextPage
    }
  }
}
"""

# Get Feed-Registry entries by contributor
GET_FEEDS_BY_CONTRIBUTOR = """
query GetFeedsByContributor($contributor: String!, $cursor: String, $limit: Int = 50) {
  transactions(
    tags: [
      { name: "App-Name", values: ["Retcon"] }
      { name: "Entity-Type", values: ["Feed-Registry"] }
      { name: "Contributor", values: [$contributor] }
    ]
    first: $limit
    after: $cursor
    sort: HEIGHT_DESC
  ) {
    edges {
      cursor
      node {
        id
        tags {
          name
          value
        }
      }
    }
    pageInfo {
      hasNextPage
    }
  }
}
"""

# Check if a feed URL exists in the registry
CHECK_FEED_EXISTS = """
query CheckFeedExists($feedUrl: String!) {
  transactions(
    tags: [
      { name: "App-Name", values: ["Retcon"] }
      { name: "Entity-Type", values: ["Feed-Registry"] }
      { name: "Canonical-For", values: [$feedUrl] }
    ]
    first: 1
  ) {
    edges {
      node {
        id
      }
    }
  }
}
"""
