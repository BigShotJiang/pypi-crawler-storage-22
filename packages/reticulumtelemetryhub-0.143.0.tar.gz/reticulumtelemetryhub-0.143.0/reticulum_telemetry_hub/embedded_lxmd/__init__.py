"""Utilities for running the LXMF daemon in-process."""

from .embedded import EmbeddedLxmd

__all__ = ["EmbeddedLxmd"]
