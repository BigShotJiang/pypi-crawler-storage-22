from reticulum_telemetry_hub.lxmf_telemetry.model.persistance.telemeter import Telemeter


class FieldTelemetryStream:

    telemeters: list[Telemeter]
