"""
Agent-based mutation extraction service.

This is the primary entry point for v0.3.0 mutation extraction.
It creates an LLM-backed agent with kernel function tools and orchestrates
the extraction process using OpenAI function calling.
"""

import asyncio
import json
import logging
import time
from pathlib import Path
from typing import Optional, TYPE_CHECKING

from rettxmutation.config import RettxConfig, validate_config_fields
from rettxmutation.models.extraction_models import ExtractionResult, ExtractionError
from rettxmutation.models.gene_models import GeneMutation
from rettxmutation.utils.phi_redactor import PhiRedactor

if TYPE_CHECKING:
    from rettxmutation.services.services_factory import RettxServices

logger = logging.getLogger(__name__)

# Prompt template path (relative to this package)
PROMPT_TEMPLATE_PATH = Path(__file__).parent.parent / "prompts" / "extraction_agent.md"


def _summarize_args(args: dict, max_len: int = 120) -> str:
    """Summarize tool arguments for logging (truncate long values)."""
    parts = []
    for k, v in args.items():
        s = str(v)
        if len(s) > max_len:
            s = s[:max_len] + "…"
        parts.append(f"{k}={s!r}")
    return ", ".join(parts)


class AgentExtractionService:
    """
    LLM agent-based mutation extraction service.

    Uses OpenAI function calling to orchestrate tool calls for mutation
    extraction from genetic report text.  The agent decides which tools
    to invoke based on the input content.
    """

    def __init__(self, config: RettxConfig, services: "RettxServices"):
        """
        Initialize the agent extraction service.

        Args:
            config: Configuration with Azure OpenAI agent settings.
            services: RettxServices instance for accessing existing services.
        """
        required_fields = [
            "RETTX_OPENAI_KEY",
            "RETTX_OPENAI_ENDPOINT",
            "RETTX_OPENAI_AGENT_DEPLOYMENT",
        ]
        validate_config_fields(config, required_fields, "AgentExtractionService")

        self._config = config
        self._services = services
        self._llm_client = None  # Lazy-initialized
        self._tool_functions: dict = {}
        self._system_prompt: Optional[str] = None

        logger.debug("AgentExtractionService initialized")

    # ── prompt rendering ────────────────────────────────────────────

    def _load_and_render_prompt(self) -> str:
        """Load prompt template and render with current gene registry data."""
        if self._system_prompt is not None:
            return self._system_prompt

        from rettxmutation.models.gene_registry import GENES

        template = PROMPT_TEMPLATE_PATH.read_text(encoding="utf-8")

        # Render gene registry block
        gene_lines = []
        for gene in GENES:
            line = (
                f"- **{gene.symbol}** ({gene.name}) — "
                f"Chr{gene.chromosome} {gene.band}, "
                f"primary transcript: {gene.primary_transcript.mrna}"
            )
            if gene.secondary_transcript:
                line += f", secondary: {gene.secondary_transcript.mrna}"
            gene_lines.append(line)
        gene_registry_text = "\n".join(gene_lines)

        # Render tool descriptions block
        tool_descriptions = (
            "- **regex_extract(text)** — Pattern-match HGVS strings from text using regex. Returns variant candidates.\n"
            "- **text_analytics_extract(text)** — Azure Health NLP entity extraction. Returns medical/genetic entities.\n"
            "- **ai_search_enrich(query)** — Search known variants in AI Search index. Returns enrichment data.\n"
            "- **validate_variant(hgvs_string, gene_symbol)** — Full HGVS validation via VariantValidator API. **hgvs_string MUST include transcript prefix**, e.g. 'NM_004992.4:c.916C>T'. Returns validated GeneMutation.\n"
            "- **validate_complex(assembly_build, assembly_refseq, variant_description, gene_symbol?)** — Validate a genomic-level variant through VariantValidator. Use for large del/dup/ins OR when the report uses Ensembl transcripts (ENST*). Pass the genomic coordinate instead of the c. position. When gene_symbol is provided, also returns transcript annotations on the correct RefSeq transcripts.\n"
            "- **lookup_gene_registry(gene_symbol)** — Check if a gene is supported and get its primary transcript ID. Returns gene info including transcript references.\n"
            "- **parse_hgvs(hgvs_string)** — (Optional) Parse HGVS notation format. Requires full string with transcript prefix, e.g. 'NM_004992.4:c.916C>T'. NOT bare notation like 'c.916C>T'."
        )

        self._system_prompt = template.replace(
            "{gene_registry}", gene_registry_text
        ).replace(
            "{tool_descriptions}", tool_descriptions
        )

        return self._system_prompt

    # ── lazy agent init ─────────────────────────────────────────────

    async def _ensure_agent(self):
        """Lazy-initialize the LLM client and tool dispatch table."""
        if self._llm_client is not None:
            return

        from rettxmutation.services.agent_tools import AgentTools

        self._tools = AgentTools(self._services)

        # Load system prompt (also validates template file exists)
        self._load_and_render_prompt()

        try:
            from openai import AsyncAzureOpenAI

            self._llm_client = AsyncAzureOpenAI(
                api_key=self._config.RETTX_OPENAI_KEY,
                api_version=getattr(
                    self._config, "RETTX_OPENAI_AGENT_MODEL_VERSION", "2024-11-20"
                ),
                azure_endpoint=self._config.RETTX_OPENAI_ENDPOINT,
            )
        except ImportError as exc:
            raise ExtractionError(
                "openai package not installed. Install with: pip install openai"
            ) from exc

        # Register tool dispatch table
        self._tool_functions = {
            "regex_extract": self._tools.regex_extract,
            "text_analytics_extract": self._tools.text_analytics_extract,
            "ai_search_enrich": self._tools.ai_search_enrich,
            "validate_variant": self._tools.validate_variant,
            "validate_complex": self._tools.validate_complex,
            "lookup_gene_registry": self._tools.lookup_gene_registry,
            "parse_hgvs": self._tools.parse_hgvs,
        }

        logger.debug("Agent initialized with %d tools", len(self._tool_functions))

    # ── public API ──────────────────────────────────────────────────

    async def extract_mutations(self, text: str) -> ExtractionResult:
        """
        Extract mutations from genetic report text using the LLM agent.

        Args:
            text: Plain text from a genetic report (any language).

        Returns:
            ExtractionResult with validated mutations and extraction log.

        Raises:
            ExtractionError: If the agent fails (LLM unavailable, timeout, etc.).
        """
        start_time = time.monotonic()
        extraction_log: list[str] = []

        try:
            # Step 1: PHI redaction
            text_pair = PhiRedactor.redact(text)
            extraction_log.append("PHI redaction applied to input text")

            # Step 2: Ensure agent is initialised
            await self._ensure_agent()

            # Step 3: Run the agent loop
            result = await self._run_agent_loop(
                redacted_text=text_pair.redacted,
                original_text=text_pair.original,
                extraction_log=extraction_log,
            )

            elapsed_ms = int((time.monotonic() - start_time) * 1000)
            extraction_log.append(f"Extraction completed in {elapsed_ms}ms")
            result.extraction_log = extraction_log
            return result

        except ExtractionError:
            raise
        except Exception as exc:
            elapsed_ms = int((time.monotonic() - start_time) * 1000)
            extraction_log.append(f"Extraction failed after {elapsed_ms}ms: {exc}")
            raise ExtractionError(
                f"Mutation extraction failed: {exc}",
                extraction_log=extraction_log,
            ) from exc

    # ── agent loop ──────────────────────────────────────────────────

    async def _run_agent_loop(
        self,
        redacted_text: str,
        original_text: str,
        extraction_log: list[str],
    ) -> ExtractionResult:
        """
        Run the LLM's tool-calling loop.

        The LLM sees *redacted_text*; local tools (regex, text_analytics) get
        *original_text* injected at dispatch time.
        """
        mutations: dict[str, GeneMutation] = {}
        genes_detected: list[str] = []
        tool_calls_count = 0

        tool_definitions = self._build_tool_definitions()

        messages = [
            {"role": "system", "content": self._system_prompt},
            {
                "role": "user",
                "content": (
                    "Please analyze the following genetic report text and "
                    "extract all mutations:\n\n" + redacted_text
                ),
            },
        ]

        max_iterations = 10  # safety cap
        for _ in range(max_iterations):
            try:
                response = await asyncio.wait_for(
                    self._llm_client.chat.completions.create(
                        model=self._config.RETTX_OPENAI_AGENT_DEPLOYMENT,
                        messages=messages,
                        tools=tool_definitions,
                        tool_choice="auto",
                    ),
                    timeout=30.0,
                )
            except asyncio.TimeoutError:
                raise ExtractionError(
                    "Azure OpenAI request timed out after 30 seconds",
                    extraction_log,
                )
            except Exception as exc:
                raise ExtractionError(
                    f"Azure OpenAI API error: {exc}",
                    extraction_log,
                ) from exc

            choice = response.choices[0]

            if choice.finish_reason == "tool_calls" and choice.message.tool_calls:
                messages.append(choice.message)

                for tc in choice.message.tool_calls:
                    tool_name = tc.function.name
                    tool_calls_count += 1

                    try:
                        tool_args = json.loads(tc.function.arguments)
                    except json.JSONDecodeError:
                        tool_args = {}

                    extraction_log.append(
                        f"tool_call: {tool_name}({_summarize_args(tool_args)})"
                    )

                    tool_result = await self._dispatch_tool(
                        tool_name, tool_args, original_text
                    )

                    self._collect_mutations(
                        tool_name, tool_result, mutations, genes_detected
                    )

                    extraction_log.append(
                        f"tool_result: {tool_name} → success={tool_result.success}"
                        + (f", error={tool_result.error}" if tool_result.error else "")
                    )

                    messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": tc.id,
                            "content": tool_result.model_dump_json(),
                        }
                    )
            else:
                # finish_reason == "stop" — agent is done
                if choice.message.content:
                    extraction_log.append(
                        f"reasoning: {choice.message.content[:500]}"
                    )
                break

        return ExtractionResult(
            mutations=mutations,
            genes_detected=genes_detected,
            tool_calls_count=tool_calls_count,
        )

    # ── tool dispatch ───────────────────────────────────────────────

    async def _dispatch_tool(
        self, tool_name: str, args: dict, original_text: str
    ):
        """Dispatch a single tool call to the appropriate handler."""
        from rettxmutation.models.tool_outputs import BaseToolOutput

        handler = self._tool_functions.get(tool_name)
        if not handler:
            return BaseToolOutput(success=False, error=f"Unknown tool: {tool_name}")

        # Inject original (un-redacted) text for local-only tools
        if tool_name in ("regex_extract", "text_analytics_extract"):
            args["text"] = original_text

        return await handler(**args)

    # ── mutation collection ─────────────────────────────────────────

    @staticmethod
    def _collect_mutations(
        tool_name: str,
        tool_result,
        mutations: dict[str, GeneMutation],
        genes_detected: list[str],
    ):
        """Extract validated mutations and gene info from tool results."""
        if (
            tool_name in ("validate_variant", "validate_complex")
            and tool_result.success
            and tool_result.mutation
        ):
            key = AgentExtractionService._mutation_key(tool_result.mutation)
            if key:
                mutations[key] = tool_result.mutation
            # Also detect gene from validated mutations
            if tool_result.mutation.primary_transcript:
                gene_id = tool_result.mutation.primary_transcript.gene_id
                if gene_id and gene_id not in genes_detected:
                    genes_detected.append(gene_id)

        elif (
            tool_name == "lookup_gene_registry"
            and tool_result.success
            and tool_result.gene
        ):
            if tool_result.gene.symbol not in genes_detected:
                genes_detected.append(tool_result.gene.symbol)

    @staticmethod
    def _mutation_key(mutation: GeneMutation) -> Optional[str]:
        """Get the genomic coordinate key for a GeneMutation."""
        if mutation.genomic_coordinates:
            for key in ("grch38", "GRCh38"):
                coord = mutation.genomic_coordinates.get(key)
                if coord:
                    return coord.hgvs
        if mutation.genomic_coordinate:
            return mutation.genomic_coordinate
        return None

    # ── OpenAI tool definitions ─────────────────────────────────────

    @staticmethod
    def _build_tool_definitions() -> list[dict]:
        """Build OpenAI-format function definitions for the LLM."""
        return [
            {
                "type": "function",
                "function": {
                    "name": "regex_extract",
                    "description": (
                        "Pattern-match HGVS variant strings from text using regex. "
                        "Returns variant candidates including c. variants, p. variants, "
                        "gene names, and reference sequences."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "text": {
                                "type": "string",
                                "description": "The text to search for HGVS patterns",
                            }
                        },
                        "required": ["text"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "text_analytics_extract",
                    "description": (
                        "Extract medical and genetic entities from text using "
                        "Azure Health NLP. Returns genes, variants, and other "
                        "healthcare entities."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "text": {
                                "type": "string",
                                "description": "The text to analyze for healthcare entities",
                            }
                        },
                        "required": ["text"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "ai_search_enrich",
                    "description": (
                        "Search known variants in the AI Search index. "
                        "Use to find enrichment data for a specific variant."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "string",
                                "description": "The variant or mutation string to search for",
                            }
                        },
                        "required": ["query"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "validate_variant",
                    "description": (
                        "Validate a transcript-level HGVS variant through the "
                        "VariantValidator API. Returns a fully validated GeneMutation "
                        "with genomic coordinates. Use for standard point mutations "
                        "and small variants."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "hgvs_string": {
                                "type": "string",
                                "description": (
                                    "HGVS variant on transcript, "
                                    "e.g. 'NM_004992.4:c.916C>T'"
                                ),
                            },
                            "gene_symbol": {
                                "type": "string",
                                "description": "Gene symbol, e.g. 'MECP2'",
                            },
                        },
                        "required": ["hgvs_string", "gene_symbol"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "validate_complex",
                    "description": (
                        "Validate a complex variant (large deletion, duplication, "
                        "or insertion) OR any genomic-level variant through the "
                        "VariantValidator API. Also use this when the report contains "
                        "Ensembl transcripts (ENST*) — pass the genomic coordinate "
                        "instead. When gene_symbol is provided, transcript annotations "
                        "are automatically resolved on the correct RefSeq transcripts."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "assembly_build": {
                                "type": "string",
                                "description": "Genome build, e.g. 'GRCh38' or 'GRCh37'",
                            },
                            "assembly_refseq": {
                                "type": "string",
                                "description": "Reference sequence, e.g. 'NC_000023.11' (GRCh38) or 'NC_000023.10' (GRCh37)",
                            },
                            "variant_description": {
                                "type": "string",
                                "description": "Genomic HGVS variant description, e.g. 'NC_000023.10:g.153296399G>A'",
                            },
                            "gene_symbol": {
                                "type": "string",
                                "description": "Optional gene symbol (e.g. 'MECP2'). When provided, transcript-level annotations are resolved on the correct RefSeq transcripts.",
                            },
                        },
                        "required": [
                            "assembly_build",
                            "assembly_refseq",
                            "variant_description",
                        ],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "lookup_gene_registry",
                    "description": (
                        "Check if a gene symbol is known in the registry. Returns "
                        "gene info including transcripts, chromosome, and band. "
                        "If gene not found, returns list of all known genes."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "gene_symbol": {
                                "type": "string",
                                "description": "Gene symbol to look up, e.g. 'MECP2'",
                            }
                        },
                        "required": ["gene_symbol"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "parse_hgvs",
                    "description": (
                        "Parse an HGVS notation string to extract its components "
                        "(transcript, variant type, positions). Use to validate "
                        "HGVS format before calling validate_variant."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "hgvs_string": {
                                "type": "string",
                                "description": (
                                    "HGVS string to parse, "
                                    "e.g. 'NC_000023.11:g.154031326G>A'"
                                ),
                            }
                        },
                        "required": ["hgvs_string"],
                    },
                },
            },
        ]
