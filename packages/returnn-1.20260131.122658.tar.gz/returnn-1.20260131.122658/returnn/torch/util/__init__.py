"""
PyTorch functions
"""
