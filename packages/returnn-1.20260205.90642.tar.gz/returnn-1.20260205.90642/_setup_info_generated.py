version = '1.20260205.090642'
long_version = '1.20260205.090642+git.99e715d'
