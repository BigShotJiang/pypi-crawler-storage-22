# revengelibrary

Revenge Library

## Установка

```bash
python3 -m venv venv
source venv/bin/activate
```

```bash
pip install revengelibrary
```

## Запуск из терминала

После установки доступна команда:

```bash
revengelibrary
```
