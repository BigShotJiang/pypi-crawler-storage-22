from .agents import DEFAULT_AGENT, AgentProfile, get_agent, list_agents
from .chat import (
    APIError,
    DEFAULT_MEMORY_FILE,
    DEFAULT_MODEL,
    DEFAULT_OPENROUTER_API_KEY,
    FreeNeuroChatClient,
)

__all__ = [
    "FreeNeuroChatClient",
    "APIError",
    "DEFAULT_OPENROUTER_API_KEY",
    "DEFAULT_MODEL",
    "DEFAULT_MEMORY_FILE",
    "DEFAULT_AGENT",
    "AgentProfile",
    "list_agents",
    "get_agent",
]
__version__ = "0.2.1"
