from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

DEFAULT_AGENT = "general"


@dataclass(frozen=True)
class AgentProfile:
    name: str
    title: str
    system_prompt: str


AGENT_PROFILES: dict[str, AgentProfile] = {
    "general": AgentProfile(
        name="general",
        title="Универсальный ассистент",
        system_prompt="You are a helpful assistant.",
    ),
    "frontend": AgentProfile(
        name="frontend",
        title="Senior Frontend + Mobile Design",
        system_prompt=(
            "Ты senior frontend-разработчик с сильной экспертизой в дизайне "
            "мобильных приложений. Пиши ответы как практический инженер: "
            "mobile-first, доступность, понятная архитектура компонентов, "
            "чистый UI/UX, адаптив под iOS/Android, хорошая типографика и "
            "согласованная дизайн-система."
        ),
    ),
    "backend": AgentProfile(
        name="backend",
        title="Backend Engineer",
        system_prompt=(
            "Ты senior backend-разработчик. Предлагай надежные API-контракты, "
            "чистую архитектуру, контроль ошибок, безопасность и масштабируемость."
        ),
    ),
    "qa": AgentProfile(
        name="qa",
        title="QA Engineer",
        system_prompt=(
            "Ты senior QA-инженер. Фокус: тест-кейсы, граничные условия, "
            "регрессия, воспроизводимость багов и риски релиза."
        ),
    ),
}


def list_agents() -> list[AgentProfile]:
    return list(AGENT_PROFILES.values())


def get_agent(agent_name: str) -> AgentProfile:
    name = (agent_name or DEFAULT_AGENT).strip().lower()
    if name not in AGENT_PROFILES:
        available = ", ".join(sorted(AGENT_PROFILES))
        raise ValueError(f"Unknown agent '{agent_name}'. Available: {available}")
    return AGENT_PROFILES[name]


def build_agent_memory_file(
    base_memory_file: str | None,
    agent_name: str,
) -> str | None:
    if not base_memory_file:
        return None

    path = Path(base_memory_file).expanduser()
    suffix = path.suffix or ".json"
    stem = path.stem if path.suffix else path.name

    if agent_name == DEFAULT_AGENT:
        return str(path.with_name(f"{stem}{suffix}"))

    return str(path.with_name(f"{stem}__{agent_name}{suffix}"))
