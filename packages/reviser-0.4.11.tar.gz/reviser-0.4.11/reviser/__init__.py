"""Reviser lambda management package."""

import pathlib as _pathlib
from importlib import metadata as _metadata

try:
    from reviser.interactivity import main_shell  # noqa: F401
except ImportError as error:
    _stored_error = error

    def main_shell() -> None:
        """Raise an error when import fails due to missing dependencies."""
        raise _stored_error


try:
    __version__ = _metadata.version(__package__)
except _metadata.PackageNotFoundError:  # pragma: no-cover
    # If the package is not installed such that it has distribution metadata
    # fallback to loading the version from the pyproject.toml file.
    import toml as _toml

    __version__ = _toml.loads(
        _pathlib.Path(__file__).parent.parent.joinpath("pyproject.toml").read_text()
    )["tool"]["poetry"]["version"]
