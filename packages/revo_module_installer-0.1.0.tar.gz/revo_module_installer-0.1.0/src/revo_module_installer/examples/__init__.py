"""Bundled example resources for offline testing."""
