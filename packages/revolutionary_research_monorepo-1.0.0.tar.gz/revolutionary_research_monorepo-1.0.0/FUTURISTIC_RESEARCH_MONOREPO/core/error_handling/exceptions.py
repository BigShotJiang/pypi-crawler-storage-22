from typing import Optional, Dict, Any

class BaseResearchError(Exception):
    """Base class for all research monorepo exceptions."""
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "error_type": self.__class__.__name__,
            "message": self.message,
            "details": self.details
        }

class ConfigurationError(BaseResearchError):
    """Raised when configuration issues occur."""
    pass

class SimulationError(BaseResearchError):
    """Raised when a simulation fails to converge or runs out of resources."""
    pass

class SecurityViolationError(BaseResearchError):
    """Raised when a security constraint is violated."""
    pass
