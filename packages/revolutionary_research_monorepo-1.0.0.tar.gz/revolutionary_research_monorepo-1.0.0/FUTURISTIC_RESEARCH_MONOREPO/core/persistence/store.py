"""
Production Persistence Layer.

Provides a robust SQLite-backed key-value store for system state.
Ensures atomic commits and ACID compliance for mission-critical research state.
"""

import sqlite3
import json
import os
from typing import Any, Optional, Dict
from core.logging.logger import setup_logger

logger = setup_logger(__name__)

class StateStore:
    def __init__(self, db_path: str = "system_state.db"):
        self.db_path = db_path
        self._initialize_db()

    def _initialize_db(self) -> None:
        """Sets up the database schema."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS state (
                    key TEXT PRIMARY KEY,
                    value TEXT,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
        logger.info(f"Persistence layer initialized at {self.db_path}")

    def save(self, key: str, value: Any) -> None:
        """Saves an object to the store, serialized as JSON."""
        serialized = json.dumps(value)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT OR REPLACE INTO state (key, value) VALUES (?, ?)",
                (key, serialized)
            )
        logger.debug(f"Saved state for key: {key}")

    def load(self, key: str) -> Optional[Any]:
        """Loads and deserializes an object from the store."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT value FROM state WHERE key = ?", (key,))
            row = cursor.fetchone()
            if row:
                return json.loads(row[0])
        return None

    def delete(self, key: str) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM state WHERE key = ?", (key,))
        logger.debug(f"Deleted state for key: {key}")
