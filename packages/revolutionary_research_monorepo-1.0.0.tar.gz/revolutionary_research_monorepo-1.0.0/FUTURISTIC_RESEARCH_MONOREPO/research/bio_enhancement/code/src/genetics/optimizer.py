"""
Genetic Algorithm Optimizer.

Simulates gene selection and optimization processes.
"""

import random
from typing import List, Callable, TypeVar, Generic
from dataclasses import dataclass
from core.logging.logger import setup_logger

logger = setup_logger(__name__)

T = TypeVar('T')

@dataclass
class Individual(Generic[T]):
    dna: T
    fitness: float = 0.0

class GeneticOptimizer(Generic[T]):
    def __init__(
        self,
        population_size: int,
        mutation_rate: float,
        fitness_fn: Callable[[T], float],
        crossover_fn: Callable[[T, T], T],
        mutate_fn: Callable[[T], T],
        gene_factory: Callable[[], T]
    ):
        self.pop_size = population_size
        self.mutation_rate = mutation_rate
        self.fitness_fn = fitness_fn
        self.crossover_fn = crossover_fn
        self.mutate_fn = mutate_fn
        
        self.population: List[Individual[T]] = [
            Individual(gene_factory()) for _ in range(population_size)
        ]
        self.generation = 0
        logger.info(f"Genetic Optimizer initialized with population {population_size}")

    def evolve(self, generations: int) -> None:
        for _ in range(generations):
            self._evaluate_fitness()
            self._create_next_generation()
            self.generation += 1
            best = self.get_best()
            logger.debug(f"Gen {self.generation}: Best Fitness = {best.fitness:.4f}")

    def _evaluate_fitness(self) -> None:
        for ind in self.population:
            ind.fitness = self.fitness_fn(ind.dna)

    def _create_next_generation(self) -> None:
        new_pop = []
        
        # Elitism: Keep top 2
        sorted_pop = sorted(self.population, key=lambda x: x.fitness, reverse=True)
        new_pop.extend(sorted_pop[:2])
        
        while len(new_pop) < self.pop_size:
            parent1 = self._select_tournament()
            parent2 = self._select_tournament()
            
            child_dna = self.crossover_fn(parent1.dna, parent2.dna)
            
            if random.random() < self.mutation_rate:
                child_dna = self.mutate_fn(child_dna)
                
            new_pop.append(Individual(child_dna))
            
        self.population = new_pop

    def _select_tournament(self) -> Individual[T]:
        size = 3
        participants = random.sample(self.population, size)
        return max(participants, key=lambda x: x.fitness)

    def get_best(self) -> Individual[T]:
        return max(self.population, key=lambda x: x.fitness)
