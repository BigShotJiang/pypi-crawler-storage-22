import pytest
from research.bio_enhancement.code.src.genetics.optimizer import GeneticOptimizer

def test_genetic_algorithm_convergence():
    # Simple problem: Find string of 1s [1, 1, 1, 1, 1]
    target_len = 5
    
    def fitness(dna):
        return sum(dna)
        
    def crossover(p1, p2):
        mid = len(p1) // 2
        return p1[:mid] + p2[mid:]
        
    def mutate(dna):
        new_dna = list(dna)
        idx = 0 # Deterministic mutation for test stability would be better, but this simple logic mimics random bit flip
        new_dna[idx] = 1 if new_dna[idx] == 0 else 0
        return new_dna
        
    def factory():
        return [0] * target_len
        
    optimizer = GeneticOptimizer(
        population_size=10,
        mutation_rate=0.1,
        fitness_fn=fitness,
        crossover_fn=crossover,
        mutate_fn=mutate,
        gene_factory=factory
    )
    
    # Run 10 generations should improve fitness
    initial_best = optimizer.get_best().fitness
    optimizer.evolve(10)
    final_best = optimizer.get_best().fitness
    
    # Even if it doesn't solve it perfectly, it shouldn't degrade or crash
    assert final_best >= initial_best
