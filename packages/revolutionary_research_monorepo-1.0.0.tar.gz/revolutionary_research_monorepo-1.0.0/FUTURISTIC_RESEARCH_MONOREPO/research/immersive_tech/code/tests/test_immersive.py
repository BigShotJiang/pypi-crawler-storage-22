import pytest
import math
from research.immersive_tech.code.src.photonics.engine import PhotonicEmitter, WavefrontEngine

def test_emitter_phase_shift():
    emitter = PhotonicEmitter(wavelength_nm=532.0, intensity=1.0)
    # At wavelength distance, phase shift should be 0 (mod 2pi)
    shift = emitter.get_phase_shift(532.0 * 1e-9)
    assert math.isclose(shift, 0.0, abs_tol=1e-7)

def test_wavefront_lens_application():
    engine = WavefrontEngine(resolution=(100, 100))
    engine.apply_lens_function(focal_length_m=0.1)
    
    # Center should have 0 phase shift (r=0)
    assert engine.phase_map[50][50] == 0.0
    # Outer pixels should have non-zero phase shift
    assert engine.phase_map[0][0] > 0.0
