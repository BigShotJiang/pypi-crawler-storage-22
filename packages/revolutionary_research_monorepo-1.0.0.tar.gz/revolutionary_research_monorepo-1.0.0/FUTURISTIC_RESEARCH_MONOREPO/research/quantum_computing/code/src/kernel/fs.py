"""
Kernel File System.

In-memory hierarchical file system simulation.
"""

import time
from dataclasses import dataclass, field
from typing import Dict, Optional, Any, List, Tuple
from core.logging.logger import setup_logger

logger = setup_logger(__name__)

@dataclass
class INode:
    name: str
    is_dir: bool
    content: str = ""
    children: Dict[str, 'INode'] = field(default_factory=dict)
    created: float = field(default_factory=time.time)
    
    @property
    def size(self) -> int:
        return len(self.content)

class FileSystem:
    """In-memory VFS."""
    
    def __init__(self):
        self.root = INode("/", is_dir=True)
        self.current_dir = self.root
        self.current_path = "/"

    def _resolve_path(self, path: str) -> Optional[INode]:
        if path == "/":
            return self.root
        
        parts = [p for p in path.strip("/").split("/") if p]
        node = self.root if path.startswith("/") else self.current_dir
        
        for part in parts:
            if part in node.children:
                node = node.children[part]
            else:
                return None
        return node

    def mkdir(self, path: str) -> bool:
        parent_path = "/".join(path.split("/")[:-1])
        if not parent_path and not path.startswith("/"):
            parent = self.current_dir
        else:
            parent = self._resolve_path(parent_path or "/")
            
        dir_name = path.split("/")[-1]
        
        if parent and parent.is_dir and dir_name not in parent.children:
            parent.children[dir_name] = INode(dir_name, is_dir=True)
            return True
        return False

    def write_file(self, path: str, content: str) -> bool:
        """Writes content to a file, creating it if it doesn't exist."""
        # Simple implementation: resolve parent, create/update child
        if "/" in path:
            parent_path, file_name = path.rsplit("/", 1)
            parent_path = parent_path or "/"
        else:
            parent_path = "."  # Use CWD logic
            file_name = path
            
        parent = self.current_dir if parent_path == "." else self._resolve_path(parent_path)
            
        if parent and parent.is_dir:
            file_node = parent.children.get(file_name)
            if file_node:
                if file_node.is_dir:
                    return False
                file_node.content = content
            else:
                parent.children[file_name] = INode(file_name, is_dir=False, content=content)
            return True
        return False
    
    def read_file(self, path: str) -> Optional[str]:
        node = self._resolve_path(path)
        return node.content if node and not node.is_dir else None

    def ls(self, path: Optional[str] = None) -> List[Tuple[str, str, int]]:
        node = self._resolve_path(path) if path else self.current_dir
        if node and node.is_dir:
            return [(name, "DIR" if child.is_dir else "FILE", child.size) 
                    for name, child in node.children.items()]
        return []
