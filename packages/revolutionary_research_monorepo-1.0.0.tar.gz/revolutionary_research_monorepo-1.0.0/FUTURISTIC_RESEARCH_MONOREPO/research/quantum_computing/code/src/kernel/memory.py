"""
Kernel Memory Management.

Implements a simple First-Fit memory allocator with coalescing.
"""

from typing import List, Dict, Optional, Any
from core.logging.logger import setup_logger

logger = setup_logger(__name__)

class MemoryBlock:
    def __init__(self, start: int, size: int, allocated: bool = False):
        self.start = start
        self.size = size
        self.allocated = allocated
        self.process_id: Optional[int] = None

class MemoryManager:
    """Virtual memory manager simulation."""
    
    def __init__(self, total_size: int = 1024 * 1024):  # 1MB
        self.total_size = total_size
        self.blocks: List[MemoryBlock] = [MemoryBlock(0, total_size)]
        self.allocations: Dict[int, List[MemoryBlock]] = {}
        logger.info(f"Memory Manager initialized with {total_size} bytes.")

    def allocate(self, process_id: int, size: int) -> Optional[int]:
        """Allocates a memory block using First-Fit strategy."""
        for block in self.blocks:
            if not block.allocated and block.size >= size:
                # Split block logic
                if block.size > size:
                    new_block = MemoryBlock(block.start + size, block.size - size)
                    # Insert after current block
                    idx = self.blocks.index(block)
                    self.blocks.insert(idx + 1, new_block)
                
                block.size = size
                block.allocated = True
                block.process_id = process_id
                
                if process_id not in self.allocations:
                    self.allocations[process_id] = []
                self.allocations[process_id].append(block)
                
                logger.debug(f"Allocated {size} bytes to PID {process_id} at {block.start}")
                return block.start
        
        logger.warning(f"Memory allocation failed: {size} bytes requested for PID {process_id}")
        return None

    def deallocate(self, process_id: int) -> None:
        """Frees all memory owned by a process."""
        if process_id in self.allocations:
            for block in self.allocations[process_id]:
                block.allocated = False
                block.process_id = None
            del self.allocations[process_id]
            self._coalesce()
            logger.debug(f"Deallocated memory for PID {process_id}")

    def _coalesce(self) -> None:
        """Merges adjacent free blocks to reduce fragmentation."""
        i = 0
        while i < len(self.blocks) - 1:
            current = self.blocks[i]
            next_block = self.blocks[i+1]
            if not current.allocated and not next_block.allocated:
                current.size += next_block.size
                self.blocks.pop(i+1)
            else:
                i += 1

    def get_stats(self) -> Dict[str, Any]:
        used = sum(b.size for b in self.blocks if b.allocated)
        return {
            "total": self.total_size,
            "used": used,
            "free": self.total_size - used,
            "usage_percent": (used / self.total_size) * 100
        }
