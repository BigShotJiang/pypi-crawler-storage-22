"""
Kernel Process Management.

Handles process scheduling using a prioritized round-robin algorithm.
"""

import threading
import queue
import time
from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, Callable
from core.logging.logger import setup_logger

logger = setup_logger(__name__)

class ProcessState(Enum):
    NEW = "new"
    READY = "ready"
    RUNNING = "running"
    WAITING = "waiting"
    TERMINATED = "terminated"

@dataclass
class Process:
    """Represents a single process control block (PCB)."""
    pid: int
    name: str
    code: Callable[[Dict[str, Any]], Any]
    state: ProcessState = ProcessState.NEW
    priority: int = 5
    memory: Dict[str, Any] = field(default_factory=dict)
    thread: Optional[threading.Thread] = None
    result: Any = None
    
    def execute(self) -> None:
        """Executes the process payload safely."""
        try:
            self.state = ProcessState.RUNNING
            logger.info(f"Process {self.pid} ({self.name}) started.")
            self.result = self.code(self.memory)
            self.state = ProcessState.TERMINATED
            logger.info(f"Process {self.pid} ({self.name}) terminated successfully.")
        except Exception as e:
            logger.error(f"Process {self.pid} crashed: {e}")
            self.result = f"Error: {str(e)}"
            self.state = ProcessState.TERMINATED

class Scheduler:
    """Preemptive priority scheduler."""
    
    def __init__(self):
        self.processes: Dict[int, Process] = {}
        # PriorityQueue stores tuples of (priority, pid). Lower number = higher priority? 
        # Standard Python PriorityQueue pops lowest item first. Use negative for high priority.
        self.ready_queue = queue.PriorityQueue() 
        self.next_pid = 1
        self.running_process: Optional[Process] = None

    def create_process(self, name: str, code: Callable[[Dict[str, Any]], Any], priority: int = 5) -> int:
        """Spawn a new process."""
        pid = self.next_pid
        self.next_pid += 1
        
        proc = Process(pid, name, code, priority=priority)
        self.processes[pid] = proc
        
        # In Python PriorityQueue, lowest val is first. So priority 1 is highest.
        self.ready_queue.put((priority, pid))
        logger.debug(f"Created process {pid}: {name}")
        return pid

    def schedule(self) -> Optional[Process]:
        """Dispatches the next process from the queue."""
        if not self.ready_queue.empty():
            priority, pid = self.ready_queue.get()
            proc = self.processes[pid]
            
            proc.state = ProcessState.RUNNING
            self.running_process = proc
            
            # Use threading to simulate execution
            proc.thread = threading.Thread(target=proc.execute)
            proc.thread.start()
            return proc
        return None

    def list_processes(self) -> List[Dict[str, Any]]:
        return [
            {"pid": p.pid, "name": p.name, "state": p.state.value, "priority": p.priority}
            for p in self.processes.values()
        ]
