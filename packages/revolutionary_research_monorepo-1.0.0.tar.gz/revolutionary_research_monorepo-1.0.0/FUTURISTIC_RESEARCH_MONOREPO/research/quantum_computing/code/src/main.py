"""
QuantumOS Main Entry Point.
"""

from core.logging.logger import setup_logger
from research.quantum_computing.code.src.kernel.process import Scheduler
from research.quantum_computing.code.src.kernel.memory import MemoryManager
from research.quantum_computing.code.src.kernel.fs import FileSystem
from research.quantum_computing.code.src.simulation.qubits import QuantumProcessor

logger = setup_logger(__name__)

class QuantumOSKernel:
    def __init__(self):
        self.scheduler = Scheduler()
        self.memory = MemoryManager()
        self.filesystem = FileSystem()
        self.qpu = QuantumProcessor(8)  # 8 Qubits
        self.running = True
        
        self._boot()

    def _boot(self):
        logger.info("QuantumOS Booting...")
        self.filesystem.mkdir("/home")
        self.filesystem.mkdir("/bin")
        logger.info("System Ready.")

    def run_repl(self):
        print("QuantumOS v2.0 (Verified)")
        while self.running:
            try:
                cmd = input("QOS> ").strip()
                self._handle_command(cmd)
            except KeyboardInterrupt:
                self.running = False
    
    def _handle_command(self, cmd: str):
        if cmd == "exit":
            self.running = False
        elif cmd == "ps":
            print(self.scheduler.list_processes())
        elif cmd.startswith("qrun"):
            # Example: qrun H 0
            parts = cmd.split()
            if len(parts) >= 3:
                gate, qubit = parts[1], int(parts[2])
                try:
                    self.qpu.apply_gate(gate, qubit)
                    print("Gate applied.")
                except Exception as e:
                    print(f"Error: {e}")
            else:
                print("Measure result:", self.qpu.measure_all())
        else:
            print("Unknown command.")

if __name__ == "__main__":
    kernel = QuantumOSKernel()
    kernel.run_repl()
