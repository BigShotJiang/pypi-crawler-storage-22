"""
Quantum Simulation Engine.

This module provides a functional simulation of quantum bits (qubits) and gates.
It is designed to be deterministic for research reproducibility.
"""

import math
import cmath
import random
from dataclasses import dataclass
from typing import List, Dict, Optional, Any
from core.logging.logger import setup_logger
from core.error_handling.exceptions import SimulationError

logger = setup_logger(__name__)

@dataclass
class QubitState:
    """Represents a quantum bit with superposition state |ψ⟩ = α|0⟩ + β|1⟩."""
    alpha: complex = 1.0 + 0j
    beta: complex = 0.0 + 0j

    def __post_init__(self):
        self._normalize()

    def _normalize(self) -> None:
        """Normalizes the state vector so that |α|^2 + |β|^2 = 1."""
        norm = math.sqrt(abs(self.alpha)**2 + abs(self.beta)**2)
        if norm > 0:
            self.alpha /= norm
            self.beta /= norm
        else:
            logger.error("Qubit state collapsed to zero vector during normalization.")
            raise SimulationError("Qubit norm is zero.")

    def measure(self) -> int:
        """Collapses the qubit to a classical bit (0 or 1).
        
        Returns:
            0 or 1 based on the probability amplitude.
        """
        prob_0 = abs(self.alpha)**2
        result = 0 if random.random() < prob_0 else 1
        
        # Collapse state
        if result == 0:
            self.alpha, self.beta = 1.0+0j, 0.0+0j
        else:
            self.alpha, self.beta = 0.0+0j, 1.0+0j
            
        logger.debug(f"Measured qubit: {result}")
        return result

    def __repr__(self) -> str:
        return f"|ψ⟩ = {self.alpha:.3f}|0⟩ + {self.beta:.3f}|1⟩"

class QuantumGate:
    """Stateless collection of quantum logic gates."""
    
    @staticmethod
    def hadamard(qubit: QubitState) -> None:
        """Applies Hadamard gate (superposition)."""
        inv_sqrt2 = 1 / math.sqrt(2)
        new_alpha = inv_sqrt2 * (qubit.alpha + qubit.beta)
        new_beta = inv_sqrt2 * (qubit.alpha - qubit.beta)
        qubit.alpha, qubit.beta = new_alpha, new_beta

    @staticmethod
    def pauli_x(qubit: QubitState) -> None:
        """Applies Pauli-X (NOT) gate."""
        qubit.alpha, qubit.beta = qubit.beta, qubit.alpha

    @staticmethod
    def pauli_z(qubit: QubitState) -> None:
        """Applies Pauli-Z (Phase Flip) gate."""
        qubit.beta = -qubit.beta

    @staticmethod
    def phase(qubit: QubitState, theta: float) -> None:
        """Applies Phase shift gate."""
        qubit.beta *= cmath.exp(1j * theta)

class QuantumProcessor:
    """Simulates a Quantum Processing Unit (QPU)."""
    
    def __init__(self, num_qubits: int):
        self.num_qubits = num_qubits
        self.qubits: List[QubitState] = [QubitState() for _ in range(num_qubits)]
        logger.info(f"Initialized QPU with {num_qubits} qubits.")

    def apply_gate(self, gate_name: str, qubit_idx: int, **kwargs: Any) -> None:
        """Applies a quantum gate to a specific qubit.

        Args:
            gate_name: 'H', 'X', 'Z', or 'P'.
            qubit_idx: Index of the target qubit.
            **kwargs: Additional parameters (e.g., 'theta' for Phase gate).
        
        Raises:
            SimulationError: If qubit index is out of bounds or gate is unknown.
        """
        if not (0 <= qubit_idx < self.num_qubits):
            raise SimulationError(f"Qubit index {qubit_idx} out of range (0-{self.num_qubits-1})")
        
        qubit = self.qubits[qubit_idx]
        
        try:
            if gate_name == "H":
                QuantumGate.hadamard(qubit)
            elif gate_name == "X":
                QuantumGate.pauli_x(qubit)
            elif gate_name == "Z":
                QuantumGate.pauli_z(qubit)
            elif gate_name == "P":
                QuantumGate.phase(qubit, kwargs.get('theta', 0.0))
            else:
                raise SimulationError(f"Unknown gate: {gate_name}")
        except Exception as e:
            logger.error(f"Gate application failed: {e}")
            raise SimulationError(f"Failed to apply {gate_name}") from e

    def measure_all(self) -> List[int]:
        """Measures all qubits and returns the classical bitstring."""
        return [q.measure() for q in self.qubits]

    def reset(self) -> None:
        """Resets all qubits to the ground state |0⟩."""
        self.qubits = [QubitState() for _ in range(self.num_qubits)]
        logger.debug("QPU Reset.")
