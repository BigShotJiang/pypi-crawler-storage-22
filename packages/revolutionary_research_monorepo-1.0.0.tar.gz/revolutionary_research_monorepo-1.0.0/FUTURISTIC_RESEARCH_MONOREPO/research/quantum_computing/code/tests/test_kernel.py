import pytest
import time
from research.quantum_computing.code.src.kernel.process import Scheduler, ProcessState
from research.quantum_computing.code.src.kernel.memory import MemoryManager

def test_scheduler_process_execution():
    scheduler = Scheduler()
    result_container = {}
    
    def dummy_process(mem):
        return "success"
        
    pid = scheduler.create_process("test_proc", dummy_process)
    assert pid == 1
    
    proc = scheduler.schedule()
    # Wait for thread to finish
    if proc.thread:
        proc.thread.join(timeout=1.0)
        
    assert proc.state == ProcessState.TERMINATED
    assert proc.result == "success"

def test_memory_allocation():
    mem = MemoryManager(1024)
    addr1 = mem.allocate(pid=1, size=100)
    assert addr1 == 0
    
    addr2 = mem.allocate(pid=1, size=200)
    assert addr2 == 100
    
    stats = mem.get_stats()
    assert stats['used'] == 300
    assert stats['free'] == 724

def test_memory_coalescing():
    mem = MemoryManager(1000)
    p1 = mem.allocate(1, 100)
    p2 = mem.allocate(2, 100)
    p3 = mem.allocate(3, 100)
    
    mem.deallocate(1) # Free first
    mem.deallocate(3) # Free last
    
    # Middle is still occupied, so no full coalesce yet
    assert len(mem.blocks) >= 3 
    
    mem.deallocate(2) # Free middle
    # Should coalesce into one big block
    assert len(mem.blocks) == 1
    assert mem.blocks[0].size == 1000
    assert not mem.blocks[0].allocated
