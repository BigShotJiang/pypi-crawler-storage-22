import pytest
import math
from research.quantum_computing.code.src.simulation.qubits import QubitState, QuantumProcessor, QuantumGate

def test_qubit_initialization():
    q = QubitState()
    assert q.alpha == 1.0 + 0j
    assert q.beta == 0.0 + 0j

def test_hadamard_gate():
    q = QubitState()
    QuantumGate.hadamard(q)
    # 1/sqrt(2) approx 0.707
    assert math.isclose(abs(q.alpha), 0.707106, rel_tol=1e-5)
    assert math.isclose(abs(q.beta), 0.707106, rel_tol=1e-5)

def test_pauli_x_gate():
    q = QubitState() # |0>
    QuantumGate.pauli_x(q)
    assert q.alpha == 0.0
    assert q.beta == 1.0

def test_qpu_entanglement_simulation():
    # Note: This simple simulator doesn't support multi-qubit entanglement yet (CNOT)
    # This test verifies the processing pipeline works for single qubits
    qpu = QuantumProcessor(2)
    qpu.apply_gate("H", 0)
    qpu.apply_gate("X", 1)
    
    measurements = qpu.measure_all()
    assert len(measurements) == 2
    assert measurements[1] == 1  # X on |0> -> |1> -> measure 1
