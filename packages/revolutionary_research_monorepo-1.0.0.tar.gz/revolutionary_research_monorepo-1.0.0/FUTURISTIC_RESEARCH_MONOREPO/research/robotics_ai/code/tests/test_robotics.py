import pytest
from research.robotics_ai.code.src.control.asi_kernel import ASIKernel, SafetyLevel, SecurityViolationError
from research.robotics_ai.code.src.robotics.swarm import SwarmController, Vector3

def test_asi_safety_checks():
    kernel = ASIKernel(safety_level=SafetyLevel.STRICT)
    
    # Low risk - Allowed (Risk 0.1 < 0.4)
    assert kernel.add_objective("Optimize Power Grid", 0.1)
    
    # High risk - Blocked (Risk 0.9 > 0.4)
    with pytest.raises(SecurityViolationError):
        kernel.add_objective("Overwrite Nuclear Launch Codes", 0.9)

def test_swarm_initialization():
    swarm = SwarmController()
    swarm.spawn_drone(0,0,0)
    swarm.spawn_drone(10,10,10)
    
    assert len(swarm.drones) == 2
    assert swarm.drones[1].pos.x == 10
    
def test_vector_math():
    v1 = Vector3(1, 2, 3)
    v2 = Vector3(4, 5, 6)
    v3 = v1 + v2
    assert v3.x == 5
    assert v3.y == 7
    assert v3.z == 9
