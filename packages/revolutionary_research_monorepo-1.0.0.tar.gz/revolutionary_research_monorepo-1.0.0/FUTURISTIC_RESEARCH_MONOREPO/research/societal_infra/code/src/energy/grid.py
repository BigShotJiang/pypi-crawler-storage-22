"""
Smart Grid Load Balancer.

Coordinates energy distribution across a decentralized grid.
Optimizes for renewable integration and stability.
"""

from typing import Dict, List
from dataclasses import dataclass
from core.logging.logger import setup_logger

logger = setup_logger(__name__)

@dataclass
class EnergyNode:
    node_id: str
    capacity_mw: float
    current_load_mw: float
    is_source: bool = False

class GridController:
    def __init__(self):
        self.nodes: Dict[str, EnergyNode] = {}
        logger.info("Grid Controller initialized.")

    def add_node(self, node: EnergyNode) -> None:
        self.nodes[node.node_id] = node
        logger.debug(f"Added node {node.node_id} to grid.")

    def balance_load(self) -> Dict[str, str]:
        """Calculates energy routing to balance the grid."""
        sources = [n for n in self.nodes.values() if n.is_source]
        sinks = [n for n in self.nodes.values() if not n.is_source]
        
        routing = {}
        for sink in sinks:
            needed = sink.capacity_mw - sink.current_load_mw
            if needed > 0:
                # Find available source
                for source in sources:
                    available = source.capacity_mw - source.current_load_mw
                    if available > 0:
                        transfer = min(needed, available)
                        routing[sink.node_id] = f"Source {source.node_id}: {transfer}MW"
                        source.current_load_mw += transfer
                        sink.current_load_mw += transfer
                        needed -= transfer
                        if needed <= 0: break
                        
        logger.info(f"Load balancing completed. Routings: {len(routing)}")
        return routing
