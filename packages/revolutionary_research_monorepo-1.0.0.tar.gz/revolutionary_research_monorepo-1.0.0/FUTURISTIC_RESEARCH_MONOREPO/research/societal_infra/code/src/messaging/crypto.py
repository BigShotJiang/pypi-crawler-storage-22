"""
Production Cryptography Layer.

Implements AES-GCM for authenticated encryption.
Designed for quantum-resistant agility.
"""

import os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from core.logging.logger import setup_logger
from core.error_handling.exceptions import BaseResearchError

logger = setup_logger(__name__)

class CryptoEngine:
    def __init__(self, key: Optional[bytes] = None):
        self.key = key or AESGCM.generate_key(bit_length=256)
        self.aesgcm = AESGCM(self.key)
        logger.info("Crypto Engine initialized with 256-bit key.")

    def encrypt_data(self, data: str, associated_data: bytes = b"") -> bytes:
        """Encrypts data with a unique nonce and returns (nonce + ciphertext)."""
        nonce = os.urandom(12)
        ciphertext = self.aesgcm.encrypt(nonce, data.encode(), associated_data)
        return nonce + ciphertext

    def decrypt_data(self, blob: bytes, associated_data: bytes = b"") -> str:
        """Decrypts a (nonce + ciphertext) blob."""
        nonce = blob[:12]
        ciphertext = blob[12:]
        try:
            decrypted = self.aesgcm.decrypt(nonce, ciphertext, associated_data)
            return decrypted.decode()
        except Exception as e:
            logger.error("Decryption failed: Integrity check failed or invalid key.")
            raise BaseResearchError("CRYPTO_FAILURE") from e
