import pytest
from research.societal_infra.code.src.energy.grid import GridController, EnergyNode
from research.societal_infra.code.src.messaging.router import MessageRouter, SecureMessage

def test_grid_load_balancing():
    ctrl = GridController()
    ctrl.add_node(EnergyNode("WindFarm_01", 100, 0, is_source=True))
    ctrl.add_node(EnergyNode("DataCenter_01", 50, 10, is_source=False))
    
    routing = ctrl.balance_load()
    assert "DataCenter_01" in routing
    assert ctrl.nodes["DataCenter_01"].current_load_mw == 50

def test_message_routing_safety():
    router = MessageRouter()
    msg = SecureMessage("Alice", "Bob", "Hello World")
    
    assert router.send_secure(msg)
    assert msg.encrypted
