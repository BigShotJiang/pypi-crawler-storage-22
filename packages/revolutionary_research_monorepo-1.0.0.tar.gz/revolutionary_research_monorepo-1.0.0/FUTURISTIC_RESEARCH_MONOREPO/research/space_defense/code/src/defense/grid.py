"""
Planetary Defense Grid.

Simulates threat tracking and interception logic.
"""

from typing import List, Dict
from enum import Enum
from core.logging.logger import setup_logger
from research.space_defense.code.src.space.satellite import ConstellationManager

logger = setup_logger(__name__)

class ThreatLevel(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class ThreatObj:
    def __init__(self, threat_id: str, velocity_km_s: float, size_m: float):
        self.id = threat_id
        self.velocity = velocity_km_s
        self.size = size_m
        self.intercepted = False

    @property
    def danger_score(self) -> float:
        return self.velocity * self.size

class DefenseGrid:
    def __init__(self):
        self.constellation = ConstellationManager()
        self.active_threats: Dict[str, ThreatObj] = {}
        self.constellation.launch_batch(50, 500.0) # Initial deployment

    def register_threat(self, threat_id: str, velocity: float, size: float) -> None:
        threat = ThreatObj(threat_id, velocity, size)
        self.active_threats[threat_id] = threat
        logger.warning(f"Threat detected: {threat_id} (Score: {threat.danger_score:.1f})")

    def evaluate_response(self) -> None:
        """Decides on interception response."""
        for t_id, threat in self.active_threats.items():
            if threat.intercepted:
                continue
                
            if threat.danger_score > 1000.0:
                self._authorize_interception(threat)

    def _authorize_interception(self, threat: ThreatObj) -> None:
        logger.critical(f"AUTHORIZING INTERCEPTION FOR {threat.id}")
        # Simulation logic for interception
        threat.intercepted = True
        logger.info(f"Threat {threat.id} neutralized.")

    def status_report(self) -> Dict[str, int]:
        return {
            "satellites": len(self.constellation.satellites),
            "active_threats": len([t for t in self.active_threats.values() if not t.intercepted]),
            "intercepted": len([t for t in self.active_threats.values() if t.intercepted])
        }
