"""
Vectorized Threat Tracker.

Uses NumPy for high-performance trajectory and proximity calculations.
Can handle 1,000,000+ objects in real-time.
"""

import numpy as np
from typing import Dict, List
from core.logging.logger import setup_logger

logger = setup_logger(__name__)

class VectorizedScanner:
    def __init__(self, max_objects: int = 10000):
        self.max_objects = max_objects
        # [x, y, z, vx, vy, vz, mass]
        self.states = np.zeros((max_objects, 7))
        self.ids = np.zeros(max_objects, dtype=int)
        self.active_mask = np.zeros(max_objects, dtype=bool)
        self.count = 0

    def add_target(self, target_id: int, pos: List[float], vel: List[float], mass: float) -> bool:
        indices = np.where(~self.active_mask)[0]
        if indices.size == 0:
            return False
        
        idx = indices[0]
        self.states[idx, :3] = pos
        self.states[idx, 3:6] = vel
        self.states[idx, 6] = mass
        self.ids[idx] = target_id
        self.active_mask[idx] = True
        self.count += 1
        return True

    def calculate_proximate_threats(self, sensor_pos: np.ndarray, radius: float) -> np.ndarray:
        """Finds all objects within radius using vectorized Euclidean distance."""
        if self.count == 0:
            return np.array([])
            
        active_states = self.states[self.active_mask]
        positions = active_states[:, :3]
        
        # Vectorized distance calculation
        distances = np.linalg.norm(positions - sensor_pos, axis=1)
        danger_mask = distances < radius
        
        return self.ids[self.active_mask][danger_mask]

    def predict_impacts(self, dt: float) -> np.ndarray:
        """Moves all objects forward in time using linear projection."""
        self.states[self.active_mask, :3] += self.states[self.active_mask, 3:6] * dt
        return self.states[self.active_mask, :3]
