import pytest
from research.space_defense.code.src.defense.grid import DefenseGrid
from research.space_defense.code.src.space.satellite import Satellite

def test_satellite_maneuver():
    sat = Satellite("TEST-01", 500.0)
    initial_fuel = sat.fuel_level
    
    success = sat.maneuver(10.0, 10.0)
    assert success
    assert sat.fuel_level < initial_fuel
    assert sat.position.lat == 10.0

def test_defense_grid_interception():
    grid = DefenseGrid()
    
    # Low threat
    grid.register_threat("T-01", 10.0, 5.0) # Score 50
    grid.evaluate_response()
    assert not grid.active_threats["T-01"].intercepted
    
    # Critical threat
    grid.register_threat("T-02", 100.0, 20.0) # Score 2000
    grid.evaluate_response()
    assert grid.active_threats["T-02"].intercepted
