"""Configuration module"""

from pathlib import Path
from functools import cached_property

from pydantic import BaseModel, field_validator
from matplotlib import pyplot as plt
from matplotlib.colors import to_hex
from gaps.config import load_config

from reVReports.exceptions import reVReportsValueError


DEFAULT_COLORS = [to_hex(rgb) for rgb in plt.colormaps["tab10"].colors]
VALID_TECHS = ["wind", "osw", "pv", "geo"]
VALID_MAP_LAYOUTS = ["horizontal", "vertical"]


class BaseModelStrict(BaseModel):
    """Raise a ValidationError for extra parameters"""

    model_config = {"extra": "forbid"}
    """Pydantic model config to error on extra parameters"""


class SupplyCurveScenario(BaseModelStrict):
    """Inputs for an individual supply curve scenario"""

    source: Path
    """Path to source file for this scenario"""
    name: str
    """Name of this scenario (used for labeling in plots)"""
    color: str = None
    """Color to use for this scenario in plots"""

    @field_validator("source")
    def expand_user(cls, value):  # noqa: N805
        """
        Expand user directory of input source paths

        Parameters
        ----------
        value : pathlib.Path
            Input source path

        Returns
        -------
        pathlib.Path
            Source path with user directory expanded, if applicable
        """
        return value.expanduser()


class Plots(BaseModelStrict):
    """Container for settings related to specific plots"""

    site_lcoe_max: float = 70
    """Maximum value for site LCOE plot axes (in USD/MWh)"""
    total_lcoe_max: float = 100
    """Maximum value for total LCOE plot axes (in USD/MWh)"""


class MapVar(BaseModelStrict):
    """Container for settings related to mapping variables"""

    column: str
    """Column name being mapped"""
    breaks: list[float]
    """List of break points for mapping variable"""
    cmap: str
    """Colormap to use for mapping variable"""
    legend_title: str
    """Title to use for legend of mapping variable"""


class Config(BaseModelStrict):
    """Configuration settings for creating plots"""

    tech: str
    """Technology type (e.g. 'wind', 'osw', 'pv', 'geo')"""
    scenarios: list[SupplyCurveScenario] = []
    """List of supply curve scenarios to include in plots"""
    plots: Plots = Plots()
    """Plot settings (see :class:`Plots`)"""
    map_vars: list[MapVar] = []
    """List of mapping variable settings (see :class:`MapVar`)"""
    exclude_maps: list[str] = []
    """List of mapping variables to exclude from mapping"""
    map_layout: str = "horizontal"
    """Map layout for scenario grids (``horizontal`` or ``vertical``)"""
    lcoe_site_col: str = "lcoe_site_usd_per_mwh"
    """Column name for site LCOE values (in USD/MWh)"""
    lcoe_all_in_col: str = "lcoe_all_in_usd_per_mwh"
    """Column name for total LCOE values (in USD/MWh)"""
    cf_col: str = None
    """Column name for capacity factor values (if applicable)"""
    prefix_outputs: bool = False
    """Optional prefix to add to output filenames (e.g. ``'map_'``)"""

    @field_validator("scenarios")
    def default_scenario_colors(cls, value):  # noqa: N805
        """Set default colors for scenarios

        If input scenarios do not have a color set, this function sets
        them to values from the tab10 colormap. This is handled at the
        Config level rather than the SupplyCurveScenario level so that
        the colormap can be incremented for each scenario.

        Parameters
        ----------
        value : list
            List of SupplyCurveScenario models.

        Returns
        -------
        list
            List of SupplyCurveScenarios with default colors set,
            if needed.
        """
        for i, scenario in enumerate(value):
            if scenario.color is None:
                scenario.color = DEFAULT_COLORS[i]

        return value

    @field_validator("tech")
    def valid_tech(cls, value):  # noqa: N805
        """Check that the input value for tech is valid

        Parameters
        ----------
        value : str
            Input value for 'tech'

        Returns
        -------
        str
            Returns the input value (as long as it is one of the valid
            options)

        Raises
        ------
        reVReportsValueError
            A reVReportsValueError will be raised if the input value is
            not a valid option.
        """
        if value not in VALID_TECHS:
            msg = (
                f"Input tech '{value}' is invalid. Valid options are: "
                f"{VALID_TECHS}"
            )
            raise reVReportsValueError(msg)

        return value

    @field_validator("map_layout")
    def valid_map_layout(cls, value):  # noqa: N805
        """Check that the input value for map_layout is valid

        Parameters
        ----------
        value : str
            Input value for 'map_layout'

        Returns
        -------
        str
            Returns the input value (as long as it is one of the valid
            options)

        Raises
        ------
        reVReportsValueError
            A reVReportsValueError will be raised if the input value is
            not a valid option.
        """
        value_cf = value.casefold()
        if value_cf not in VALID_MAP_LAYOUTS:
            msg = (
                f"Input map_layout '{value}' is invalid. Valid options "
                f"are: {VALID_MAP_LAYOUTS}"
            )
            raise reVReportsValueError(msg)

        return value_cf

    @classmethod
    def from_json(cls, json_path):
        """
        Load configuration from a JSON file.

        Parameters
        ----------
        json_path : path-like
            Path to JSON file containing input settings.

        Returns
        -------
        Config
            Configuration settings.
        """
        return cls(**load_config(json_path, resolve_paths=True))

    @cached_property
    def scenario_palette(self):
        """
        Get a dictionary mapping scenario names to colors.

        Returns
        -------
        dict
            Dictionary mapping scenario names to colors.
        """
        return {scenario.name: scenario.color for scenario in self.scenarios}
