"""reVReports utilities"""  # noqa
