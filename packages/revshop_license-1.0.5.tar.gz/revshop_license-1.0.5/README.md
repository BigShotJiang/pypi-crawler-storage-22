# REVSHOP License Manager - Python Client

[![PyPI version](https://badge.fury.io/py/revshop-license.svg)](https://badge.fury.io/py/revshop-license)
[![Python versions](https://img.shields.io/pypi/pyversions/revshop-license.svg)](https://pypi.org/project/revshop-license/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A secure Python client for REVSHOP license protection system. Protect your Python applications with hardware-bound license keys, real-time monitoring, and secure configuration storage.

## Features

- 🔐 **Hardware ID Binding** - Binds to CPU, motherboard, or machine ID
- 🔄 **Real-time Monitoring** - Automatic heartbeat and status checks
- 📴 **Offline Support** - Grace period when offline (configurable)
- 🔒 **Secure Storage** - Encrypted local configuration
- ✅ **Signature Verification** - HMAC-SHA256 response validation
- 🎯 **Simple API** - Easy integration with callbacks

## Installation

```bash
pip install revshop-license
```

## Quick Start

### Basic Usage

```python
from revshop_license import LicenseManager

# Initialize
lm = LicenseManager(
    base_url="https://your-shop.com",
    product_id="your_product_id",
    product_secret="your_product_secret"
)

# Validate license
result = lm.validate("REV-XXXX-XXXX-XXXX-XXXX")

if result["valid"]:
    print("✅ License valid!")
    # Your application logic here
else:
    print(f"❌ {result['message']}")
```

### With Callbacks

```python
def on_revoked(data):
    print("License revoked! Exiting...")
    sys.exit(1)

def on_suspended(data):
    print("License suspended!")
    sys.exit(1)

def on_expired(data):
    print("License expired!")
    sys.exit(1)

lm.set_callbacks(
    on_revoked=on_revoked,
    on_suspended=on_suspended,
    on_expired=on_expired
)

result = lm.validate("REV-XXXX-XXXX-XXXX-XXXX")
```

### Auto Lookup Mode

If you don't know the `product_id`, you can use the auto-lookup feature:

```python
lm, lookup_result = LicenseManager.from_license_key(
    base_url="https://your-shop.com",
    license_key="REV-XXXX-XXXX-XXXX-XXXX",
    product_secret="your_product_secret"
)

if lookup_result["found"]:
    result = lm.validate()
    print(f"Product: {lookup_result['product_name']}")
```

### Complete Example

```python
import sys
from revshop_license import LicenseManager

def main():
    # Initialize license manager
    lm = LicenseManager(
        base_url="https://your-shop.com",
        product_id="prod_xxxxxxxx",
        product_secret="sk_live_xxxxxxxx"
    )
    
    # Set up callbacks
    def on_license_revoked(data):
        print("\n🚫 License has been revoked!")
        sys.exit(1)
    
    def on_license_suspended(data):
        print("\n⏸️ License has been suspended!")
        sys.exit(1)
    
    lm.set_callbacks(
        on_revoked=on_license_revoked,
        on_suspended=on_license_suspended
    )
    
    # Validate (will use cached license if available)
    result = lm.validate()
    
    if not result["valid"]:
        # No saved license, ask user
        license_key = input("Enter license key: ").strip()
        result = lm.validate(license_key)
    
    if result["valid"]:
        print(f"✅ {result['message']}")
        
        # Show license info
        info = result.get("license_info", {})
        print(f"Product: {info.get('product', {}).get('name')}")
        
        # Your app runs here
        try:
            while True:
                # Main application loop
                pass
        except KeyboardInterrupt:
            lm.stop_monitoring()
    else:
        print(f"❌ {result['message']}")
        sys.exit(1)

if __name__ == "__main__":
    main()
```

## API Reference

### LicenseManager

#### Constructor

```python
LicenseManager(
    base_url: str,        # License server URL
    product_id: str,      # Product ID from REVSHOP
    product_secret: str   # Product Secret from REVSHOP Admin
)
```

#### Methods

| Method | Description |
|--------|-------------|
| `validate(license_key=None, force_online=False)` | Validate license key |
| `validate_force_online(license_key=None)` | Force online validation |
| `check_status_now()` | Check status immediately |
| `get_saved_license()` | Get saved license key |
| `save_license(key)` | Save license key |
| `clear_license()` | Clear saved license |
| `deactivate(reason)` | Deactivate on this device |
| `get_status()` | Get current status |
| `stop_monitoring()` | Stop monitoring threads |
| `set_callbacks(...)` | Set event callbacks |

#### Callbacks

- `on_revoked` - Called when license is revoked
- `on_suspended` - Called when license is suspended  
- `on_expired` - Called when license expires
- `on_device_removed` - Called when device is removed
- `on_failed` - Called on validation failure
- `on_status_changed` - Called on status change

#### Validation Result

```python
{
    "valid": bool,           # Is license valid
    "message": str,          # Status message
    "offline": bool,         # Using offline cache
    "grace_period": bool,    # In grace period
    "license_info": dict,    # License details
    "error_code": str,       # Error code (if invalid)
    "requires_activation": bool  # Needs first activation
}
```

## Configuration

The client stores configuration in:
- Windows: `%USERPROFILE%\.revshop_license\.config.dat`
- Linux/Mac: `~/.revshop_license/.config.dat`

Configuration is encrypted with hardware-based key.

## Requirements

- Python 3.8+
- `requests` library (installed automatically)

## License

MIT License - see LICENSE file for details.

## Support

For support, contact: support@revshop.com
