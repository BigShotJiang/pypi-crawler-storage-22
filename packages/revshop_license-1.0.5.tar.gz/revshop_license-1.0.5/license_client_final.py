"""
REVSHOP License Manager - Final Version
Complete version with auto-exit on violations

Usage:
1. Install requests: pip install requests
2. Run: python license_client_final.py
3. Enter Product ID and Product Secret (from Admin page)
4. Enter License Key
5. System will validate and start monitoring automatically

Integration example:
```python
from license_client_final import LicenseManager

lm = LicenseManager(
    base_url="https://your-shop.com",
    product_id="your_product_id",
    product_secret="your_product_secret"
)

result = lm.validate("REV-XXXX-XXXX-XXXX-XXXX")
if result["valid"]:
    print("License valid!")
    # Start your program
else:
    print(f"Error: {result['message']}")
```
"""

# Check for required dependencies
try:
    import requests
except ImportError:
    print("Error: 'requests' library is required:")
    print("   pip install requests")
    print("   or: pip3 install requests")
    import sys
    sys.exit(1)
import hashlib
import hmac
import json
import os
import platform
import threading
import time
import sys
import traceback
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Callable
from enum import Enum


class LicenseAction(Enum):
    """Action to take when license has issues"""
    NONE = "none"
    STOP_IMMEDIATELY = "stop_immediately"
    REVALIDATE_REQUIRED = "revalidate_required"


def log(msg, level="INFO"):
    """Log with timestamp"""
    # Check silent mode
    import os
    if os.environ.get('LICENSE_SILENT') == '1':
        return
    
    timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    icons = {"INFO": "ℹ️", "OK": "✅", "ERROR": "❌", "WARN": "⚠️", "DEBUG": "🔍"}
    print(f"[{timestamp}] {icons.get(level, '•')} {msg}", flush=True)


class LicenseManager:
    """Complete license manager with Product Secret validation"""
    
    # Settings
    CONFIG_FILE = Path.home() / ".myapp" / ".config.dat"
    CACHE_HOURS = 6
    HEARTBEAT_INTERVAL = 300     # 5 minutes
    STATUS_CHECK_INTERVAL = 5    # 5 seconds
    MAX_FAILED_CHECKS = 3
    
    def __init__(self, base_url: str = "http://localhost:3000", product_id: str = None, product_secret: str = None):
        """
        Initialize LicenseManager
        
        Args:
            base_url: License Server URL
            product_id: Product ID (from REVSHOP)
            product_secret: Product Secret Key (from Admin -> Product Details)
        """
        log(f"Initializing LicenseManager with URL: {base_url}", "DEBUG")
        
        if not product_id:
            raise ValueError("product_id is required")
        if not product_secret:
            raise ValueError("product_secret is required")
            
        self.PRODUCT_ID = product_id
        self.PRODUCT_SECRET = product_secret
        self.PRODUCT_SECRET_HASH = hashlib.sha256(product_secret.encode()).hexdigest()
        
        self.BASE_URL = base_url.rstrip('/')
        self.VALIDATE_URL = f"{self.BASE_URL}/api/license/validate"
        self.STATUS_URL = f"{self.BASE_URL}/api/license/status"
        self.HEARTBEAT_URL = f"{self.BASE_URL}/api/license/heartbeat"
        self.DEACTIVATE_URL = f"{self.BASE_URL}/api/license/deactivate"
        self.LOOKUP_URL = f"{self.BASE_URL}/api/license/lookup"
        
        # Create directory
        self.CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        
        self._config = self._load_config()
        self._session_id = self._generate_session_id()
        log(f"Session ID: {self._session_id}", "DEBUG")
        
        # Threads
        self._heartbeat_thread: Optional[threading.Thread] = None
        self._status_thread: Optional[threading.Thread] = None
        self._stop_threads = threading.Event()
        self._pause_status_check = threading.Event()
        
        # State
        self._is_running = False
        self._last_known_status = None
        
        # Callbacks (default: exit program on license issues)
        self._on_license_revoked: Optional[Callable] = self._default_exit_callback
        self._on_license_suspended: Optional[Callable] = self._default_exit_callback
        self._on_license_expired: Optional[Callable] = self._default_exit_callback
        self._on_device_removed: Optional[Callable] = self._default_exit_callback
        self._on_validation_failed: Optional[Callable] = None
        self._on_status_changed: Optional[Callable] = None
        
    def _generate_session_id(self) -> str:
        """Generate unique session ID"""
        data = f"{self._get_hardware_id()}-{time.time()}-{os.urandom(16).hex()}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]
    
    def _get_hardware_id(self) -> str:
        """Generate Hardware ID"""
        system = platform.system()
        components = []
        
        try:
            if system == "Windows":
                import subprocess
                import re
                try:
                    cpu = subprocess.check_output("wmic cpu get ProcessorId /value", shell=True).decode()
                    cpu_id = re.search(r'ProcessorId=(\w+)', cpu)
                    if cpu_id:
                        components.append(cpu_id.group(1))
                except:
                    pass
                
                try:
                    board = subprocess.check_output("wmic baseboard get SerialNumber /value", shell=True).decode()
                    board_id = re.search(r'SerialNumber=(\w+)', board)
                    if board_id:
                        components.append(board_id.group(1))
                except:
                    pass
                    
            elif system == "Darwin":
                import subprocess
                try:
                    result = subprocess.check_output(["system_profiler", "SPHardwareDataType"]).decode()
                    for line in result.split("\n"):
                        if "Hardware UUID" in line or "Serial Number" in line:
                            components.append(line.split(":")[1].strip())
                except:
                    pass
                    
            else:  # Linux
                files = ["/etc/machine-id", "/var/lib/dbus/machine-id"]
                for f in files:
                    try:
                        with open(f) as file:
                            components.append(file.read().strip())
                            break
                    except:
                        pass
        except Exception as e:
            log(f"Error getting HWID: {e}", "ERROR")
        
        if not components:
            components = [platform.node(), platform.machine(), os.getenv('USER', 'unknown')]
        
        combined = "|".join(components)
        hwid = hashlib.sha256(combined.encode()).hexdigest()[:32]
        log(f"Hardware ID: {hwid[:16]}...", "DEBUG")
        return hwid
    
    def _load_config(self) -> Dict:
        """Load settings"""
        if not self.CONFIG_FILE.exists():
            log("No existing config found", "DEBUG")
            return {}
        
        try:
            data = self.CONFIG_FILE.read_bytes()
            key = self._get_obfuscation_key()
            decrypted = bytes([b ^ key[i % len(key)] for i, b in enumerate(data)])
            config = json.loads(decrypted.decode())
            
            stored_hash = config.pop('_hash', '')
            if self._compute_config_hash(config) != stored_hash:
                log("Config integrity check failed", "WARN")
                return {}
            
            log(f"Config loaded: {config.get('license_key', 'none')[:20]}...", "DEBUG")
            return config
        except Exception as e:
            log(f"Error loading config: {e}", "ERROR")
            return {}
    
    def _save_config(self):
        """Save settings"""
        try:
            config_copy = self._config.copy()
            config_copy['_hash'] = self._compute_config_hash(self._config)
            data = json.dumps(config_copy).encode()
            key = self._get_obfuscation_key()
            encrypted = bytes([b ^ key[i % len(key)] for i, b in enumerate(data)])
            self.CONFIG_FILE.write_bytes(encrypted)
            log("Config saved", "DEBUG")
        except Exception as e:
            log(f"Error saving config: {e}", "ERROR")
    
    def _get_obfuscation_key(self) -> bytes:
        hw = self._get_hardware_id()
        return hashlib.sha256(f"revshop-{hw}".encode()).digest()
    
    def _compute_config_hash(self, config: Dict) -> str:
        data = json.dumps(config, sort_keys=True)
        return hashlib.sha256(f"{data}-secret-salt".encode()).hexdigest()[:16]
    
    def _verify_response_signature(self, data: Dict) -> bool:
        """
        Verify that response is from real server using HMAC-SHA256
        
        Args:
            data: Response data from server (must have signature and timestamp)
            
        Returns:
            True if signature is valid
        """
        try:
            signature = data.get("signature")
            timestamp = data.get("timestamp")
            license_key = self.get_saved_license()
            hardware_id = self._get_hardware_id()
            
            if not signature or not timestamp or not license_key:
                log("Missing signature data", "WARN")
                return False
            
            # Create HMAC-SHA256 to match Server (Node.js crypto.createHmac)
            # message format: licenseKey:hardwareId:productId:timestamp
            message = f"{license_key}:{hardware_id}:{self.PRODUCT_ID}:{timestamp}"
            
            # Python's hmac matches Node.js crypto.createHmac
            import hmac
            expected_signature = hmac.new(
                self.PRODUCT_SECRET.encode('utf-8'),
                message.encode('utf-8'),
                hashlib.sha256
            ).hexdigest()
            
            # Use constant-time comparison to prevent timing attack
            return hmac.compare_digest(signature, expected_signature)
        except Exception as e:
            log(f"Error verifying signature: {e}", "ERROR")
            return False
    
    # === Public API ===
    
    def get_saved_license(self) -> Optional[str]:
        return self._config.get("license_key")
    
    def save_license(self, license_key: str):
        old_key = self._config.get("license_key")
        if old_key and old_key != license_key:
            log(f"License key changed! Clearing old cache...", "INFO")
            # Clear old validation data when key changes
            self._config = {"license_key": license_key}
        else:
            self._config["license_key"] = license_key
        self._save_config()
    
    def clear_license(self):
        self._config = {}
        self._save_config()
    
    def validate_force_online(self, license_key: Optional[str] = None) -> Dict[str, Any]:
        """Validate license forcing online connection (no cache)"""
        return self.validate(license_key=license_key, force_online=True)
    
    @classmethod
    def from_license_key(cls, base_url: str, license_key: str, product_secret: str) -> tuple:
        """
        Create LicenseManager from License Key automatically (fetch product_id from server)
        
        Args:
            base_url: License Server URL
            license_key: License Key entered by user
            product_secret: Product Secret Key (hardcoded in code)
            
        Returns:
            tuple: (LicenseManager instance, lookup_result)
            
        Example:
            lm, result = LicenseManager.from_license_key(
                "https://revshop.com", 
                "REV-XXXX-...", 
                "sk_live_..."
            )
            if result["found"]:
                validation = lm.validate()
        """
        log(f"Looking up license key: {license_key[:20]}...", "INFO")
        
        lookup_url = f"{base_url.rstrip('/')}/api/license/lookup"
        
        try:
            response = requests.post(
                lookup_url,
                json={"license_key": license_key},
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            data = response.json()
            
            if not data.get("found"):
                error_msg = data.get("message", "License key not found")
                log(f"Lookup failed: {error_msg}", "ERROR")
                return None, {"error": data.get("error"), "message": error_msg}
            
            product_id = data["license"]["product"]["id"]
            product_name = data["license"]["product"]["name"]
            
            log(f"Found product: {product_name} (ID: {product_id[:20]}...)", "OK")
            
            # Create LicenseManager with fetched data
            manager = cls(
                base_url=base_url,
                product_id=product_id,
                product_secret=product_secret
            )
            
            # Save license key immediately
            manager.save_license(license_key)
            
            return manager, {
                "found": True,
                "license": data["license"],
                "product_name": product_name
            }
            
        except requests.RequestException as e:
            log(f"Network error during lookup: {e}", "ERROR")
            return None, {"error": "NETWORK_ERROR", "message": f"Cannot connect to server: {e}"}
        except Exception as e:
            log(f"Error during lookup: {e}", "ERROR")
            return None, {"error": "UNKNOWN", "message": str(e)}
    
    def _default_exit_callback(self, data: Dict):
        """Default callback: display message and exit program immediately"""
        error = data.get("error", "UNKNOWN")
        message = data.get("message", "License violation detected")
        
        print("\n" + "="*60, file=sys.stderr)
        print("🚫 LICENSE VIOLATION DETECTED", file=sys.stderr)
        print("="*60, file=sys.stderr)
        print(f"Reason: {message}", file=sys.stderr)
        print(f"Error Code: {error}", file=sys.stderr)
        print("\nThis program will now terminate in 2 seconds...", file=sys.stderr)
        print("="*60, file=sys.stderr)
        
        # Wait for message to display then exit
        time.sleep(2)
        os._exit(1)  # Force terminate without cleanup
    
    def set_callbacks(self, 
                      on_revoked: Callable = None,
                      on_suspended: Callable = None,
                      on_expired: Callable = None,
                      on_device_removed: Callable = None,
                      on_failed: Callable = None,
                      on_status_changed: Callable = None):
        """Set callbacks - if not set, will use default (exit program)"""
        log("Setting callbacks...", "DEBUG")
        self._on_license_revoked = on_revoked or self._default_exit_callback
        self._on_license_suspended = on_suspended or self._default_exit_callback
        self._on_license_expired = on_expired or self._default_exit_callback
        self._on_device_removed = on_device_removed or self._default_exit_callback
        self._on_validation_failed = on_failed
        self._on_status_changed = on_status_changed
        log("Callbacks set", "OK")
    
    def validate(self, license_key: Optional[str] = None, force_online: bool = False) -> Dict[str, Any]:
        """Validate License"""
        key = license_key or self.get_saved_license()
        if not key:
            log("No license key provided", "ERROR")
            return {"valid": False, "message": "Please enter License Key", "offline": False}
        
        log(f"Validating license: {key[:20]}...", "INFO")
        hardware_id = self._get_hardware_id()
        
        # Use cache if not forcing online and cache matches the key being validated
        cached_key = self._config.get("license_key")
        if not force_online and self._is_cache_valid() and cached_key == key:
            # Check if license still exists on server
            log("Cache valid, verifying with server...", "DEBUG")
            try:
                check_response = requests.post(
                    self.STATUS_URL,
                    json={"license_key": key, "hardware_id": hardware_id},
                    timeout=5
                )
                check_data = check_response.json()
                
                if not check_data.get("valid"):
                    error = check_data.get("error")
                    if error == "LICENSE_NOT_FOUND":
                        log("License not found on server! Clearing cache...", "WARN")
                        self.clear_license()
                        return {"valid": False, "message": "License no longer exists in system", "offline": False}
                    
                    # If Device was deleted or has no permission -> clear cache and revalidate
                    if error in ["DEVICE_NOT_AUTHORIZED", "DEVICE_NOT_FOUND", "DEVICE_LIMIT_EXCEEDED"]:
                        log(f"Device problem detected ({error}), clearing cache and revalidating...", "WARN")
                        self.clear_license()
                        # Don't return here, do online validation below
                        return self.validate(license_key=key, force_online=True)
                
                # License and Device still exist, can use cache
                log("Using cached validation", "OK")
                self._start_monitoring(key)
                return {
                    "valid": True,
                    "message": "Using cache",
                    "offline": True,
                    "grace_period": False,
                    "license_info": self._config.get("license_info")
                }
            except requests.RequestException:
                # No internet, can use cache
                log("Offline mode - using cache", "WARN")
                return {
                    "valid": True,
                    "message": "Using cache (offline)",
                    "offline": True,
                    "grace_period": False,
                    "license_info": self._config.get("license_info")
                }
        
        # Online validation
        try:
            timestamp = int(time.time() * 1000)  # timestamp in milliseconds
            log("Sending validate request...", "DEBUG")
            
            response = requests.post(
                self.VALIDATE_URL,
                json={
                    "license_key": key,
                    "hardware_id": hardware_id,
                    "product_id": self.PRODUCT_ID,
                    "product_secret_hash": self.PRODUCT_SECRET_HASH,
                    "device_name": platform.node(),
                    "timestamp": timestamp
                },
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            log(f"Response status: {response.status_code}", "DEBUG")
            data = response.json()
            log(f"Response: {json.dumps(data, indent=2)}", "DEBUG")
            
            if data.get("valid"):
                # Verify signature that response is from real server
                if not self._verify_response_signature(data):
                    log("Invalid response signature! Possible MITM attack.", "ERROR")
                    return {
                        "valid": False,
                        "message": "Server response invalid (signature mismatch)",
                        "offline": False
                    }
                
                log("Validation successful! Signature verified.", "OK")
                
                # Check if this is first activation
                is_first_activation = data.get("first_activation", False)
                license_info = data.get("license", {})
                expires_at = license_info.get("expires_at")
                activated_at = license_info.get("activated_at") or datetime.now().isoformat()
                
                # Save additional data
                if is_first_activation or not self._config.get("activated_at"):
                    self._config["activated_at"] = activated_at
                
                # Display license activation and expiration dates
                self._print_license_info(activated_at, expires_at, is_first_activation)
                
                self._config.update({
                    "license_key": key,
                    "last_validated": datetime.now().isoformat(),
                    "license_info": license_info,
                    "hardware_id": hardware_id,
                    "failed_checks": 0,
                    "session_start": time.time(),
                    "server_signature": data.get("signature"),
                    "server_timestamp": data.get("timestamp"),
                    "first_activation": is_first_activation,
                    "expires_at": expires_at
                })
                self._save_config()
                
                self._start_monitoring(key)
                
                return {
                    "valid": True,
                    "message": "License valid" + (" (first activation)" if is_first_activation else ""),
                    "offline": False,
                    "grace_period": False,
                    "first_activation": is_first_activation,
                    "license_info": license_info
                }
            else:
                log(f"Validation failed: {data.get('message')}", "ERROR")
                return self._handle_validation_error(data)
                
        except requests.RequestException as e:
            log(f"Network error: {e}", "ERROR")
            return self._handle_offline_validation(key, hardware_id)
    
    def check_status_now(self) -> Dict[str, Any]:
        """Check status immediately (Real-time)"""
        key = self.get_saved_license()
        if not key:
            return {"valid": False, "message": "No License Key"}
        
        hardware_id = self._get_hardware_id()
        
        try:
            response = requests.post(
                self.STATUS_URL,
                json={
                    "license_key": key,
                    "hardware_id": hardware_id
                },
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            data = response.json()
            
            if self._on_status_changed:
                try:
                    self._on_status_changed(data)
                except Exception as e:
                    log(f"Error in status_changed callback: {e}", "ERROR")
            
            if not data.get("valid"):
                action = data.get("action", "STOP_IMMEDIATELY")
                error = data.get("error", "UNKNOWN")
                
                log(f"License problem detected: {error}", "ERROR")
                log(f"Action required: {action}", "WARN")
                
                if action == "STOP_IMMEDIATELY":
                    log("Calling appropriate callback...", "DEBUG")
                    
                    if error == "LICENSE_REVOKED" and self._on_license_revoked:
                        try:
                            log("Calling on_license_revoked", "DEBUG")
                            self._on_license_revoked(data)
                        except Exception as e:
                            log(f"Error in revoked callback: {e}", "ERROR")
                            traceback.print_exc()
                            self._default_exit_callback(data)  # Fallback to default
                            
                    elif error == "LICENSE_SUSPENDED" and self._on_license_suspended:
                        try:
                            log("Calling on_license_suspended", "DEBUG")
                            self._on_license_suspended(data)
                        except Exception as e:
                            log(f"Error in suspended callback: {e}", "ERROR")
                            traceback.print_exc()
                            self._default_exit_callback(data)  # Fallback to default
                            
                    elif error == "LICENSE_EXPIRED" and self._on_license_expired:
                        try:
                            log("Calling on_license_expired", "DEBUG")
                            self._on_license_expired(data)
                        except Exception as e:
                            log(f"Error in expired callback: {e}", "ERROR")
                            traceback.print_exc()
                            self._default_exit_callback(data)  # Fallback to default
                            
                    elif error == "NOT_ACTIVATED":
                        log("License not activated yet", "WARN")
                        # Not activated - exit anyway
                        self._default_exit_callback(data)
                        
                    elif error == "DEVICE_NOT_AUTHORIZED" and self._on_device_removed:
                        try:
                            log("Calling on_device_removed", "DEBUG")
                            self._on_device_removed(data)
                        except Exception as e:
                            log(f"Error in device_removed callback: {e}", "ERROR")
                            traceback.print_exc()
                            self._default_exit_callback(data)  # Fallback to default
                    else:
                        # Unknown error but still invalid - exit anyway
                        self._default_exit_callback(data)
                
                return {
                    "valid": False,
                    "message": data.get("message", "License invalid"),
                    "action": action,
                    "error_code": error
                }
            
            self._last_known_status = data.get("status")
            return {
                "valid": True,
                "message": data.get("message", "License valid"),
                "status": data.get("status"),
                "license_info": data.get("license")
            }
            
        except requests.RequestException as e:
            log(f"Status check network error: {e}", "WARN")
            return {
                "valid": True,
                "message": "Cannot check online, continuing in offline mode",
                "offline": True
            }
    
    def deactivate(self, reason: str = "User requested") -> bool:
        """Deactivate license on this device"""
        key = self.get_saved_license()
        if not key:
            return False
        
        try:
            response = requests.post(
                self.DEACTIVATE_URL,
                json={
                    "license_key": key,
                    "hardware_id": self._get_hardware_id(),
                    "reason": reason
                },
                timeout=10
            )
            
            if response.status_code == 200:
                self._config = {}
                self._save_config()
                self.stop_monitoring()
                return True
                
        except Exception as e:
            log(f"Deactivation error: {e}", "ERROR")
        
        return False
    
    def stop_monitoring(self):
        """Stop all monitoring"""
        log("Stopping monitoring...", "INFO")
        self._is_running = False
        self._stop_threads.set()
        
        if self._heartbeat_thread and self._heartbeat_thread.is_alive():
            self._heartbeat_thread.join(timeout=5)
        if self._status_thread and self._status_thread.is_alive():
            self._status_thread.join(timeout=5)
        log("Monitoring stopped", "OK")
    
    def get_status(self) -> Dict[str, Any]:
        """View current License status"""
        return {
            "license_key": self.get_saved_license(),
            "hardware_id": self._get_hardware_id()[:16] + "...",
            "last_validated": self._config.get("last_validated"),
            "failed_checks": self._config.get("failed_checks", 0),
            "cache_valid": self._is_cache_valid(),
            "monitoring_active": self._is_running,
        }
    
    # === Private methods ===
    
    def _start_monitoring(self, license_key: str):
        """Start Real-time monitoring system"""
        if self._is_running:
            log("Monitoring already running", "WARN")
            return
        
        log("Starting real-time monitoring...", "INFO")
        self._is_running = True
        self._stop_threads.clear()
        
        self._heartbeat_thread = threading.Thread(
            target=self._heartbeat_loop,
            args=(license_key,),
            daemon=True,
            name="LicenseHeartbeat"
        )
        self._heartbeat_thread.start()
        log("Heartbeat thread started", "OK")
        
        self._status_thread = threading.Thread(
            target=self._status_check_loop,
            args=(license_key,),
            daemon=True,
            name="LicenseStatusCheck"
        )
        self._status_thread.start()
        log(f"Status check thread started (interval: {self.STATUS_CHECK_INTERVAL}s)", "OK")
    
    def _heartbeat_loop(self, license_key: str):
        """Send periodic heartbeat"""
        log("Heartbeat loop started", "DEBUG")
        while self._is_running and not self._stop_threads.is_set():
            try:
                response = requests.post(
                    self.HEARTBEAT_URL,
                    json={
                        "license_key": license_key,
                        "hardware_id": self._get_hardware_id(),
                        "session_id": self._session_id
                    },
                    timeout=10
                )
                
                if response.status_code != 200:
                    data = response.json()
                    if not data.get("valid"):
                        log(f"Heartbeat rejected: {data.get('error')}", "ERROR")
                        self._handle_server_rejection(data)
                        break
                        
            except requests.RequestException:
                pass
            
            self._stop_threads.wait(self.HEARTBEAT_INTERVAL)
        log("Heartbeat loop stopped", "DEBUG")
    
    def _status_check_loop(self, license_key: str):
        """Check status every 5 seconds"""
        log("Status check loop started", "DEBUG")
        check_count = 0
        
        while self._is_running and not self._stop_threads.is_set():
            while self._pause_status_check.is_set() and not self._stop_threads.is_set():
                time.sleep(1)
            
            if not self._is_running:
                break
            
            check_count += 1
            log(f"Status check #{check_count}", "DEBUG")
            
            try:
                result = self.check_status_now()
                
                if not result.get("valid"):
                    action = result.get("action", "STOP_IMMEDIATELY")
                    error_code = result.get("error_code", "UNKNOWN")
                    log(f"Status check failed, action: {action}, error: {error_code}", "ERROR")
                    
                    # Stop immediately if:
                    # 1. Action is STOP_IMMEDIATELY
                    # 2. Device was deleted (DEVICE_NOT_AUTHORIZED)
                    if action == "STOP_IMMEDIATELY" or error_code == "DEVICE_NOT_AUTHORIZED":
                        log("Stopping status check loop due to license problem", "ERROR")
                        break
                        
                    # If REVALIDATE_REQUIRED, try to revalidate
                    if action == "REVALIDATE_REQUIRED":
                        log("Attempting to revalidate license...", "WARN")
                        revalidate_result = self.validate(force_online=True)
                        if not revalidate_result.get("valid"):
                            log("Revalidation failed, stopping...", "ERROR")
                            break
                        else:
                            log("Revalidation successful, continuing...", "OK")
                            
            except Exception as e:
                log(f"Error in status check: {e}", "ERROR")
                traceback.print_exc()
            
            self._stop_threads.wait(self.STATUS_CHECK_INTERVAL)
        
        log("Status check loop stopped", "DEBUG")
    
    def _handle_server_rejection(self, data: Dict):
        """Handle server rejection - exit immediately"""
        error = data.get("error", "UNKNOWN")
        log(f"Server rejection: {error}", "ERROR")
        
        # If LICENSE_NOT_FOUND, license was deleted -> clear cache
        if error == "LICENSE_NOT_FOUND":
            log("License not found on server! Clearing local cache...", "WARN")
            self.clear_license()
        
        # Call appropriate callback or use default (exit program)
        try:
            if error == "LICENSE_REVOKED" and self._on_license_revoked:
                self._on_license_revoked(data)
            elif error == "LICENSE_SUSPENDED" and self._on_license_suspended:
                self._on_license_suspended(data)
            elif error == "LICENSE_EXPIRED" and self._on_license_expired:
                self._on_license_expired(data)
            elif error == "DEVICE_NOT_AUTHORIZED" and self._on_device_removed:
                self._on_device_removed(data)
            elif error == "LICENSE_NOT_FOUND":
                self._default_exit_callback(data)  # Always exit if license not found
            elif self._on_validation_failed:
                self._on_validation_failed(data)
            else:
                self._default_exit_callback(data)  # Exit for any other error
        except Exception as e:
            log(f"Error in rejection handler: {e}", "ERROR")
            traceback.print_exc()
            self._default_exit_callback(data)  # Fallback to default exit
    
    def _handle_validation_error(self, data: Dict) -> Dict[str, Any]:
        """Handle error from validation"""
        error = data.get("error", "")
        
        # Case not yet activated (first time must have internet)
        if error == "NOT_ACTIVATED":
            log("License not yet activated. Please connect to internet for first activation.", "ERROR")
            return {
                "valid": False,
                "message": "License not activated. Internet connection required for first activation.",
                "offline": False,
                "error_code": error,
                "requires_activation": True
            }
        
        if self._on_validation_failed:
            try:
                self._on_validation_failed(data)
            except Exception as e:
                log(f"Error in validation_failed callback: {e}", "ERROR")
        
        return {
            "valid": False,
            "message": data.get("message", "License invalid"),
            "offline": False,
            "error_code": error
        }
    
    def _handle_offline_validation(self, key: str, hardware_id: str) -> Dict:
        """Handle when no internet - no Grace Period"""
        cached_key = self._config.get("license_key")
        cached_hw = self._config.get("hardware_id")
        
        if cached_key == key and cached_hw == hardware_id:
            failed = self._config.get("failed_checks", 0) + 1
            self._config["failed_checks"] = failed
            self._save_config()
            
            if failed < self.MAX_FAILED_CHECKS:
                return {
                    "valid": True,
                    "message": f"Offline mode ({failed}/{self.MAX_FAILED_CHECKS})",
                    "offline": True,
                    "failed_checks": failed,
                }
        
        return {
            "valid": False,
            "message": "Internet connection required",
            "offline": False
        }
    
    def _is_in_grace_period(self) -> bool:
        """Grace period is disabled"""
        return False
    
    def _print_license_info(self, activated_at: str, expires_at: str, is_first_activation: bool):
        """Display license activation and expiration dates"""
        try:
            print("\n" + "="*60)
            print("📋 License Information")
            print("="*60)
            
            if activated_at:
                activated_dt = datetime.fromisoformat(activated_at.replace("Z", "+00:00"))
                print(f"📅 Activated: {activated_dt.strftime('%Y-%m-%d %H:%M:%S')}")
            
            if expires_at:
                expires_dt = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
                print(f"📅 Expires:     {expires_dt.strftime('%Y-%m-%d %H:%M:%S')}")
                
                # Calculate days remaining
                days_left = (expires_dt - datetime.now(expires_dt.tzinfo)).days
                if days_left > 0:
                    print(f"⏳ Remaining: {days_left} days")
                elif days_left == 0:
                    print("⚠️  Expires today!")
                else:
                    print("❌ Already expired!")
            else:
                print("♾️  Type: Lifetime (no expiration)")
            
            if is_first_activation:
                print("🎉 First activation - countdown starts now!")
            
            print("="*60 + "\n")
        except Exception:
            pass  # Silent fail for print operations
    
    def get_license_dates(self) -> Dict[str, Any]:
        """Get license activation and expiration dates"""
        activated_at = self._config.get("activated_at")
        expires_at = self._config.get("expires_at")
        
        result = {
            "activated_at": activated_at,
            "expires_at": expires_at,
            "days_remaining": None,
            "is_lifetime": expires_at is None
        }
        
        if expires_at:
            try:
                expires_dt = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
                days_left = (expires_dt - datetime.now(expires_dt.tzinfo)).days
                result["days_remaining"] = days_left
                result["expired"] = days_left < 0
            except:
                pass
        
        return result
    
    def _is_cache_valid(self) -> bool:
        """Check if cache is still valid"""
        last_check = self._config.get("last_validated")
        if not last_check:
            return False
        
        last = datetime.fromisoformat(last_check)
        return datetime.now() - last < timedelta(hours=self.CACHE_HOURS)


# ============ Usage Examples ============

def main_simple(base_url: str = "http://localhost:3000", 
                product_secret: str = None,
                default_product_id: str = None):
    """
    Easy mode - user enters only License Key
    
    Args:
        base_url: License Server URL
        product_secret: Product Secret Key (hardcoded in code)
        default_product_id: Product ID (optional, if not provided will lookup from server)
    
    Example usage in your program:
        from license_client_final import main_simple
        
        # Option 1: Have Product Secret but don't know Product ID
        main_simple(
            base_url="https://revshop.com",
            product_secret="sk_live_1234567890abcdef"
        )
        
        # Option 2: Know both Product ID and Secret (faster, no lookup needed)
        main_simple(
            base_url="https://revshop.com",
            product_id="cml9i71df0006vluxfz5fpmt0",
            product_secret="sk_live_1234567890abcdef"
        )
    """
    print("=" * 60)
    print("🚀 License Client - Simple Mode (Enter License Key Only)")
    print("=" * 60)
    
    # If have default_product_id, use it directly without lookup
    if default_product_id and product_secret:
        try:
            lm = LicenseManager(
                base_url=base_url,
                product_id=default_product_id,
                product_secret=product_secret
            )
        except ValueError as e:
            print(f"❌ Error: {e}")
            return
    elif not product_secret:
        print("❌ Must specify product_secret in code first (see documentation)")
        return
    
    # Get License Key
    license_key = input("\n🔑 License Key: ").strip()
    if not license_key:
        print("❌ No License Key entered")
        return
    
    # If don't have LicenseManager yet (need to lookup first)
    if 'lm' not in locals():
        print("\n⏳ Looking up product information...")
        lm, lookup_result = LicenseManager.from_license_key(
            base_url=base_url,
            license_key=license_key,
            product_secret=product_secret
        )
        
        if not lm:
            print(f"\n❌ {lookup_result['message']}")
            return
        
        print(f"✅ Found product: {lookup_result['product_name']}")
        # Force online validation for first time (no cache) to check if device still exists
        print("\n⏳ Checking online permissions...")
        validate_result = lm.validate(force_online=True)
        if not validate_result.get("valid"):
            print(f"\n❌ Validation failed: {validate_result.get('message')}")
            if validate_result.get("error_code") == "DEVICE_LIMIT_EXCEEDED":
                print("\n💡 Device limit reached")
                print("   Go to http://localhost:3000/licenses to remove old devices")
            lm.clear_license()
            return
        print("✅ Permission check successful")
    else:
        lm.save_license(license_key)
    
    # Validate License
    print("\n⏳ Validating License...")
    result = lm.validate()
    
    print(f"\n{'✅' if result['valid'] else '❌'} Result: {result['message']}")
    
    if result["valid"]:
        info = result.get('license_info', {})
        print(f"\n📋 Info:")
        print(f"   Product: {info.get('product', {}).get('name', 'N/A')}")
        print(f"   Status: {info.get('status', 'N/A')}")
        
        if result.get('first_activation'):
            expires_at = info.get('expires_at')
            if expires_at:
                expiry = datetime.fromisoformat(expires_at.replace('Z', '+00:00'))
                print(f"   Expires: {expiry.strftime('%Y-%m-%d %H:%M')}")
        
        print("\n" + "=" * 60)
        print("🎮 Program running... (Press Ctrl+C to close)")
        print("=" * 60)
        
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n\n👋 Closing...")
            lm.stop_monitoring()
    else:
        print(f"\n❌ Cannot use: {result['message']}")
        if result.get('error_code') == 'NOT_ACTIVATED':
            print("💡 Internet connection required for first activation")
        lm.clear_license()


def main():
    print("=" * 60)
    print("🚀 License Client - Final Version")
    print("=" * 60)
    
    # Select mode
    print("\n📋 Select mode:")
    print("   [1] Enter License Key only (Easy) - For customers")
    print("   [2] Enter Product ID + Secret (Full) - For dev/test")
    
    mode = input("\nSelect [1/2]: ").strip()
    
    if mode == "1":
        # Easy mode - must have product_secret hardcoded
        # In this example, ask temporarily but in production should hardcode
        print("\n⚠️  In production, hardcode product_secret in code")
        product_secret = input("🔐 Product Secret (will be hardcoded in real code): ").strip()
        if not product_secret:
            print("❌ Must specify Product Secret")
            return
        main_simple(product_secret=product_secret)
        return
    
    # Full mode (original)
    print("\n📋 Enter product information (from Admin -> Product Details)")
    
    product_id = input("🆔 Product ID: ").strip()
    if not product_id:
        print("❌ Must specify Product ID")
        return
    
    product_secret = input("🔐 Product Secret: ").strip()
    if not product_secret:
        print("❌ Must specify Product Secret")
        return
    
    # Create LicenseManager
    try:
        lm = LicenseManager(
            base_url="http://localhost:3000",
            product_id=product_id,
            product_secret=product_secret
        )
    except ValueError as e:
        print(f"❌ Error: {e}")
        return
    
    # If no License yet
    license_key = lm.get_saved_license()
    if not license_key:
        license_key = input("\n🔑 Enter License Key: ").strip()
        if not license_key:
            print("❌ No License Key entered")
            return
        lm.save_license(license_key)
    else:
        # Show cache status
        status = lm.get_status()
        print(f"\n💾 Found cached license: {status['license_key'][:25]}...")
        print(f"   Last checked: {status['last_validated'] or 'None'}")
        print(f"   Cache valid: {'Yes' if status['cache_valid'] else 'No'}")
        
        # Ask whether to use old or new license
        choice = input("\n[Enter] Use existing | [N] Enter new | [C] Clear Cache: ").strip().lower()
        if choice == 'n':
            license_key = input("🔑 Enter new License Key: ").strip()
            if license_key:
                lm.save_license(license_key)
        elif choice == 'c':
            lm.clear_license()
            print("✅ Cache cleared")
            license_key = input("🔑 Enter License Key: ").strip()
            if license_key:
                lm.save_license(license_key)
    
    # Ask whether to force online
    force_online = False
    if lm.get_saved_license():
        choice = input("\n🔄 Force online validation? [y/N]: ").strip().lower()
        if choice == 'y':
            force_online = True
    
    # Validate
    print("\n⏳ Validating License..." + (" (force online)" if force_online else ""))
    result = lm.validate(force_online=force_online)
    
    print(f"\n{'✅' if result['valid'] else '❌'} Result: {result['message']}")
    
    if result["valid"]:
        info = result.get("license_info", {})
        print(f"\n📋 Info:")
        print(f"   Product: {info.get('product', {}).get('name', 'N/A')}")
        print(f"   Status: {info.get('status', 'N/A')}")
        
        if result.get('first_activation'):
            expires_at = info.get('expires_at')
            if expires_at:
                from datetime import datetime
                expiry = datetime.fromisoformat(expires_at.replace('Z', '+00:00'))
                print(f"   Expires: {expiry.strftime('%Y-%m-%d %H:%M')}")
        
        print("\n" + "=" * 60)
        print("🎮 Program running... (Press Ctrl+C to close)")
        print("💡 Go to Admin and click 'Revoke' to test!")
        print("=" * 60)
        
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n\n👋 Closing...")
            lm.stop_monitoring()
    else:
        print(f"\n❌ Cannot use: {result['message']}")
        if result.get('error_code') == 'NOT_ACTIVATED':
            print("💡 Internet connection required for first activation")
        lm.clear_license()

if __name__ == "__main__":
    main()
