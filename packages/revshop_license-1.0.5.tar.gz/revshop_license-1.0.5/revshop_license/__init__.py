"""
REVSHOP License Manager - Python Client

A secure license validation client for REVSHOP license protection system.

Features:
- Hardware ID binding
- Real-time license monitoring
- Offline grace period support
- Automatic heartbeat
- Secure config encryption

Quick Start:
    from revshop_license import LicenseManager
    
    lm = LicenseManager(
        base_url="https://your-shop.com",
        product_id="your_product_id",
        product_secret="your_product_secret"
    )
    
    result = lm.validate("REV-XXXX-XXXX-XXXX-XXXX")
    if result["valid"]:
        print("License valid!")

For more examples, visit: https://github.com/revshop/license-client
"""

__version__ = "1.0.5"
__author__ = "REVSHOP"
__license__ = "MIT"

from .client import LicenseManager

__all__ = ["LicenseManager"]
