"""
REVSHOP License Manager - Python Client
A secure license validation client for REVSHOP license protection system.

Usage:
    from revshop_license import LicenseManager
    
    lm = LicenseManager(
        base_url="https://your-shop.com",
        product_id="your_product_id",
        product_secret="your_product_secret"
    )
    
    result = lm.validate("REV-XXXX-XXXX-XXXX-XXXX")
    if result["valid"]:
        print("License valid!")
        # Your app logic here
"""

import hashlib
import hmac
import json
import os
import platform
import threading
import time
import sys
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Callable

# Check for required dependencies
try:
    import requests
except ImportError:
    print("Error: 'requests' library is required. Install with: pip install requests")
    sys.exit(1)


class LicenseManager:
    """Secure license manager with hardware ID binding and real-time monitoring."""
    
    # Configuration
    CONFIG_FILE = Path.home() / ".revshop_license" / ".config.dat"
    CACHE_HOURS = 6
    HEARTBEAT_INTERVAL = 300     # 5 minutes
    STATUS_CHECK_INTERVAL = 30   # 30 seconds
    MAX_FAILED_CHECKS = 3
    
    def __init__(self, base_url: str, product_id: str, product_secret: str):
        """
        Initialize LicenseManager.
        
        Args:
            base_url: License server URL
            product_id: Product ID from REVSHOP
            product_secret: Product Secret from REVSHOP Admin
        """
        if not product_id:
            raise ValueError("product_id is required")
        if not product_secret:
            raise ValueError("product_secret is required")
            
        self.PRODUCT_ID = product_id
        self.PRODUCT_SECRET = product_secret
        self.PRODUCT_SECRET_HASH = hashlib.sha256(product_secret.encode()).hexdigest()
        
        self.BASE_URL = base_url.rstrip('/')
        self.VALIDATE_URL = f"{self.BASE_URL}/api/license/validate"
        self.STATUS_URL = f"{self.BASE_URL}/api/license/status"
        self.HEARTBEAT_URL = f"{self.BASE_URL}/api/license/heartbeat"
        self.DEACTIVATE_URL = f"{self.BASE_URL}/api/license/deactivate"
        self.LOOKUP_URL = f"{self.BASE_URL}/api/license/lookup"
        
        # Create config directory
        self.CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        
        self._config = self._load_config()
        self._session_id = self._generate_session_id()
        
        # Threads
        self._heartbeat_thread: Optional[threading.Thread] = None
        self._status_thread: Optional[threading.Thread] = None
        self._stop_threads = threading.Event()
        self._pause_status_check = threading.Event()
        
        # State
        self._is_running = False
        self._last_known_status = None
        
        # Callbacks (default: exit program on license issues)
        self._on_license_revoked: Optional[Callable] = self._default_exit_callback
        self._on_license_suspended: Optional[Callable] = self._default_exit_callback
        self._on_license_expired: Optional[Callable] = self._default_exit_callback
        self._on_device_removed: Optional[Callable] = self._default_exit_callback
        self._on_validation_failed: Optional[Callable] = None
        self._on_status_changed: Optional[Callable] = None
        self._exit_on_violation = True  # Force exit on license violations
    
    def _generate_session_id(self) -> str:
        """Generate unique session ID."""
        data = f"{self._get_hardware_id()}-{time.time()}-{os.urandom(16).hex()}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]
    
    def _get_hardware_id(self) -> str:
        """Generate hardware ID based on system components."""
        system = platform.system()
        components = []
        
        try:
            if system == "Windows":
                import subprocess
                import re
                try:
                    cpu = subprocess.check_output("wmic cpu get ProcessorId /value", shell=True).decode()
                    cpu_id = re.search(r'ProcessorId=(\w+)', cpu)
                    if cpu_id:
                        components.append(cpu_id.group(1))
                except:
                    pass
                
                try:
                    board = subprocess.check_output("wmic baseboard get SerialNumber /value", shell=True).decode()
                    board_id = re.search(r'SerialNumber=(\w+)', board)
                    if board_id:
                        components.append(board_id.group(1))
                except:
                    pass
                    
            elif system == "Darwin":
                import subprocess
                try:
                    result = subprocess.check_output(["system_profiler", "SPHardwareDataType"]).decode()
                    for line in result.split("\n"):
                        if "Hardware UUID" in line or "Serial Number" in line:
                            components.append(line.split(":")[1].strip())
                except:
                    pass
                    
            else:  # Linux
                files = ["/etc/machine-id", "/var/lib/dbus/machine-id"]
                for f in files:
                    try:
                        with open(f) as file:
                            components.append(file.read().strip())
                            break
                    except:
                        pass
        except:
            pass
        
        if not components:
            components = [platform.node(), platform.machine(), os.getenv('USER', 'unknown')]
        
        combined = "|".join(components)
        return hashlib.sha256(combined.encode()).hexdigest()[:32]
    
    def _load_config(self) -> Dict:
        """Load configuration from encrypted file."""
        if not self.CONFIG_FILE.exists():
            return {}
        
        try:
            data = self.CONFIG_FILE.read_bytes()
            key = self._get_obfuscation_key()
            decrypted = bytes([b ^ key[i % len(key)] for i, b in enumerate(data)])
            config = json.loads(decrypted.decode())
            
            stored_hash = config.pop('_hash', '')
            if self._compute_config_hash(config) != stored_hash:
                return {}
            
            return config
        except:
            return {}
    
    def _save_config(self):
        """Save configuration to encrypted file."""
        try:
            config_copy = self._config.copy()
            config_copy['_hash'] = self._compute_config_hash(self._config)
            data = json.dumps(config_copy).encode()
            key = self._get_obfuscation_key()
            encrypted = bytes([b ^ key[i % len(key)] for i, b in enumerate(data)])
            self.CONFIG_FILE.write_bytes(encrypted)
        except:
            pass
    
    def _get_obfuscation_key(self) -> bytes:
        hw = self._get_hardware_id()
        return hashlib.sha256(f"revshop-{hw}".encode()).digest()
    
    def _compute_config_hash(self, config: Dict) -> str:
        data = json.dumps(config, sort_keys=True)
        return hashlib.sha256(f"{data}-secret-salt".encode()).hexdigest()[:16]
    
    def _verify_response_signature(self, data: Dict) -> bool:
        """Verify HMAC-SHA256 signature from server response."""
        try:
            signature = data.get("signature")
            timestamp = data.get("timestamp")
            license_key = self.get_saved_license()
            hardware_id = self._get_hardware_id()
            
            if not signature or not timestamp or not license_key:
                return False
            
            message = f"{license_key}:{hardware_id}:{self.PRODUCT_ID}:{timestamp}"
            
            expected_signature = hmac.new(
                self.PRODUCT_SECRET.encode('utf-8'),
                message.encode('utf-8'),
                hashlib.sha256
            ).hexdigest()
            
            return hmac.compare_digest(signature, expected_signature)
        except:
            return False
    
    # === Public API ===
    
    def get_saved_license(self) -> Optional[str]:
        """Get saved license key."""
        return self._config.get("license_key")
    
    def save_license(self, license_key: str):
        """Save license key."""
        old_key = self._config.get("license_key")
        if old_key and old_key != license_key:
            self._config = {"license_key": license_key}
        else:
            self._config["license_key"] = license_key
        self._save_config()
    
    def clear_license(self):
        """Clear saved license."""
        self._config = {}
        self._save_config()
    
    def validate_force_online(self, license_key: Optional[str] = None) -> Dict[str, Any]:
        """Validate license forcing online check (no cache)."""
        return self.validate(license_key=license_key, force_online=True)
    
    @classmethod
    def from_license_key(cls, base_url: str, license_key: str, product_secret: str) -> tuple:
        """
        Create LicenseManager from license key (auto-lookup product_id).
        
        Returns:
            tuple: (LicenseManager instance, lookup_result)
        """
        lookup_url = f"{base_url.rstrip('/')}/api/license/lookup"
        
        try:
            response = requests.post(
                lookup_url,
                json={"license_key": license_key},
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            data = response.json()
            
            if not data.get("found"):
                return None, {
                    "error": data.get("error"),
                    "message": data.get("message", "License key not found")
                }
            
            product_id = data["license"]["product"]["id"]
            product_name = data["license"]["product"]["name"]
            
            manager = cls(
                base_url=base_url,
                product_id=product_id,
                product_secret=product_secret
            )
            
            manager.save_license(license_key)
            
            return manager, {
                "found": True,
                "license": data["license"],
                "product_name": product_name
            }
            
        except requests.RequestException as e:
            return None, {"error": "NETWORK_ERROR", "message": f"Cannot connect to server: {e}"}
        except Exception as e:
            return None, {"error": "UNKNOWN", "message": str(e)}
    
    def _default_exit_callback(self, data: Dict):
        """Default callback: exit program immediately on license violation."""
        # Exit without printing anything - let the main program handle the display
        time.sleep(1)
        os._exit(1)  # Use os._exit to force terminate without cleanup
    
    def set_callbacks(self, 
                      on_revoked: Callable = None,
                      on_suspended: Callable = None,
                      on_expired: Callable = None,
                      on_device_removed: Callable = None,
                      on_failed: Callable = None,
                      on_status_changed: Callable = None):
        """Set callbacks for license events. Pass None to use default (exit program)."""
        self._on_license_revoked = on_revoked or self._default_exit_callback
        self._on_license_suspended = on_suspended or self._default_exit_callback
        self._on_license_expired = on_expired or self._default_exit_callback
        self._on_device_removed = on_device_removed or self._default_exit_callback
        self._on_validation_failed = on_failed
        self._on_status_changed = on_status_changed
    
    def validate(self, license_key: Optional[str] = None, force_online: bool = False) -> Dict[str, Any]:
        """
        Validate license key.
        
        Returns:
            Dict with keys: valid (bool), message (str), offline (bool), 
            activated_at (str), expires_at (str), license_info (dict), etc.
        """
        key = license_key or self.get_saved_license()
        if not key:
            return {"valid": False, "message": "License key required", "offline": False}
        
        hardware_id = self._get_hardware_id()
        
        # Use cache if valid and not forcing online
        cached_key = self._config.get("license_key")
        if not force_online and self._is_cache_valid() and cached_key == key:
            try:
                check_response = requests.post(
                    self.STATUS_URL,
                    json={"license_key": key, "hardware_id": hardware_id},
                    timeout=5
                )
                check_data = check_response.json()
                
                if not check_data.get("valid"):
                    error = check_data.get("error")
                    if error == "LICENSE_NOT_FOUND":
                        self.clear_license()
                        return {"valid": False, "message": "License not found", "offline": False}
                    
                    if error in ["DEVICE_NOT_AUTHORIZED", "DEVICE_NOT_FOUND", "DEVICE_LIMIT_EXCEEDED"]:
                        self.clear_license()
                        return self.validate(license_key=key, force_online=True)
                
                self._start_monitoring(key)
                return {
                    "valid": True,
                    "message": "License valid (cached)",
                    "offline": True,
                    "activated_at": self._config.get("activated_at"),
                    "expires_at": self._config.get("expires_at"),
                    "license_info": self._config.get("license_info")
                }
            except requests.RequestException:
                # Offline - use cache
                return {
                    "valid": True,
                    "message": "License valid (offline mode)",
                    "offline": True,
                    "activated_at": self._config.get("activated_at"),
                    "expires_at": self._config.get("expires_at"),
                    "license_info": self._config.get("license_info")
                }
        
        # Online validation
        try:
            timestamp = int(time.time() * 1000)
            
            response = requests.post(
                self.VALIDATE_URL,
                json={
                    "license_key": key,
                    "hardware_id": hardware_id,
                    "product_id": self.PRODUCT_ID,
                    "product_secret_hash": self.PRODUCT_SECRET_HASH,
                    "device_name": platform.node(),
                    "timestamp": timestamp
                },
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            data = response.json()
            
            if data.get("valid"):
                # Verify signature
                if not self._verify_response_signature(data):
                    return {
                        "valid": False,
                        "message": "Invalid server response signature",
                        "offline": False
                    }
                
                is_first_activation = data.get("first_activation", False)
                license_info = data.get("license", {})
                expires_at = license_info.get("expires_at")
                activated_at = license_info.get("activated_at") or datetime.now().isoformat()
                
                # Save additional data
                if is_first_activation or not self._config.get("activated_at"):
                    self._config["activated_at"] = activated_at
                
                self._config.update({
                    "license_key": key,
                    "last_validated": datetime.now().isoformat(),
                    "license_info": license_info,
                    "hardware_id": hardware_id,
                    "failed_checks": 0,
                    "session_start": time.time(),
                    "server_signature": data.get("signature"),
                    "server_timestamp": data.get("timestamp"),
                    "first_activation": is_first_activation,
                    "expires_at": expires_at
                })
                self._save_config()
                
                self._start_monitoring(key)
                
                return {
                    "valid": True,
                    "message": "License valid" + (" (first activation)" if is_first_activation else ""),
                    "offline": False,
                    "first_activation": is_first_activation,
                    "activated_at": activated_at,
                    "expires_at": expires_at,
                    "license_info": license_info
                }
            else:
                return self._handle_validation_error(data)
                
        except requests.RequestException:
            return self._handle_offline_validation(key, hardware_id)
    
    def check_status_now(self) -> Dict[str, Any]:
        """Check license status immediately (real-time)."""
        key = self.get_saved_license()
        if not key:
            return {"valid": False, "message": "No license key"}
        
        hardware_id = self._get_hardware_id()
        
        try:
            response = requests.post(
                self.STATUS_URL,
                json={
                    "license_key": key,
                    "hardware_id": hardware_id
                },
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            data = response.json()
            
            if self._on_status_changed:
                try:
                    self._on_status_changed(data)
                except:
                    pass
            
            if not data.get("valid"):
                action = data.get("action", "STOP_IMMEDIATELY")
                error = data.get("error", "UNKNOWN")
                
                if action == "STOP_IMMEDIATELY":
                    if error == "LICENSE_REVOKED" and self._on_license_revoked:
                        try:
                            self._on_license_revoked(data)
                        except:
                            self._default_exit_callback(data)
                    elif error == "LICENSE_SUSPENDED" and self._on_license_suspended:
                        try:
                            self._on_license_suspended(data)
                        except:
                            self._default_exit_callback(data)
                    elif error == "LICENSE_EXPIRED" and self._on_license_expired:
                        try:
                            self._on_license_expired(data)
                        except:
                            self._default_exit_callback(data)
                    elif error == "DEVICE_NOT_AUTHORIZED" and self._on_device_removed:
                        try:
                            self._on_device_removed(data)
                        except:
                            self._default_exit_callback(data)
                    else:
                        # Unknown error but still invalid - exit anyway
                        self._default_exit_callback(data)
                
                return {
                    "valid": False,
                    "message": data.get("message", "License invalid"),
                    "action": action,
                    "error_code": error
                }
            
            self._last_known_status = data.get("status")
            return {
                "valid": True,
                "message": data.get("message", "License valid"),
                "status": data.get("status"),
                "license_info": data.get("license")
            }
            
        except requests.RequestException:
            return {
                "valid": True,
                "message": "Offline mode - continuing",
                "offline": True
            }
    
    def deactivate(self, reason: str = "User requested") -> bool:
        """Deactivate license on this device."""
        key = self.get_saved_license()
        if not key:
            return False
        
        try:
            response = requests.post(
                self.DEACTIVATE_URL,
                json={
                    "license_key": key,
                    "hardware_id": self._get_hardware_id(),
                    "reason": reason
                },
                timeout=10
            )
            
            if response.status_code == 200:
                self._config = {}
                self._save_config()
                self.stop_monitoring()
                return True
                
        except:
            pass
        
        return False
    
    def stop_monitoring(self):
        """Stop all monitoring threads."""
        self._is_running = False
        self._stop_threads.set()
        
        if self._heartbeat_thread and self._heartbeat_thread.is_alive():
            self._heartbeat_thread.join(timeout=5)
        if self._status_thread and self._status_thread.is_alive():
            self._status_thread.join(timeout=5)
    
    def get_status(self) -> Dict[str, Any]:
        """Get current license status."""
        return {
            "license_key": self.get_saved_license(),
            "hardware_id": self._get_hardware_id()[:16] + "...",
            "last_validated": self._config.get("last_validated"),
            "failed_checks": self._config.get("failed_checks", 0),
            "cache_valid": self._is_cache_valid(),
            "monitoring_active": self._is_running,
        }
    
    # === Private methods ===
    
    def _start_monitoring(self, license_key: str):
        """Start real-time monitoring threads."""
        if self._is_running:
            return
        
        self._is_running = True
        self._stop_threads.clear()
        
        self._heartbeat_thread = threading.Thread(
            target=self._heartbeat_loop,
            args=(license_key,),
            daemon=True,
            name="LicenseHeartbeat"
        )
        self._heartbeat_thread.start()
        
        self._status_thread = threading.Thread(
            target=self._status_check_loop,
            args=(license_key,),
            daemon=True,
            name="LicenseStatusCheck"
        )
        self._status_thread.start()
    
    def _heartbeat_loop(self, license_key: str):
        """Send periodic heartbeat to server."""
        while self._is_running and not self._stop_threads.is_set():
            try:
                response = requests.post(
                    self.HEARTBEAT_URL,
                    json={
                        "license_key": license_key,
                        "hardware_id": self._get_hardware_id(),
                        "session_id": self._session_id
                    },
                    timeout=10
                )
                
                if response.status_code != 200:
                    data = response.json()
                    if not data.get("valid"):
                        self._handle_server_rejection(data)
                        break
                        
            except requests.RequestException:
                pass
            
            self._stop_threads.wait(self.HEARTBEAT_INTERVAL)
    
    def _status_check_loop(self, license_key: str):
        """Check license status periodically."""
        while self._is_running and not self._stop_threads.is_set():
            while self._pause_status_check.is_set() and not self._stop_threads.is_set():
                time.sleep(1)
            
            if not self._is_running:
                break
            
            try:
                result = self.check_status_now()
                
                if not result.get("valid"):
                    action = result.get("action", "STOP_IMMEDIATELY")
                    error_code = result.get("error_code", "UNKNOWN")
                    
                    if action == "STOP_IMMEDIATELY" or error_code == "DEVICE_NOT_AUTHORIZED":
                        break
                    
                    if action == "REVALIDATE_REQUIRED":
                        revalidate_result = self.validate(force_online=True)
                        if not revalidate_result.get("valid"):
                            break
                            
            except:
                pass
            
            self._stop_threads.wait(self.STATUS_CHECK_INTERVAL)
    
    def _handle_server_rejection(self, data: Dict):
        """Handle server rejection - always exit on violations."""
        error = data.get("error", "UNKNOWN")
        
        if error == "LICENSE_NOT_FOUND":
            self.clear_license()
        
        # Always call appropriate callback, default will exit
        try:
            if error == "LICENSE_REVOKED" and self._on_license_revoked:
                self._on_license_revoked(data)
            elif error == "LICENSE_SUSPENDED" and self._on_license_suspended:
                self._on_license_suspended(data)
            elif error == "LICENSE_EXPIRED" and self._on_license_expired:
                self._on_license_expired(data)
            elif error == "DEVICE_NOT_AUTHORIZED" and self._on_device_removed:
                self._on_device_removed(data)
            elif error == "LICENSE_NOT_FOUND":
                self._default_exit_callback(data)
            elif self._on_validation_failed:
                self._on_validation_failed(data)
            else:
                self._default_exit_callback(data)
        except:
            # If custom callback fails, use default exit
            self._default_exit_callback(data)
    
    def _handle_validation_error(self, data: Dict) -> Dict[str, Any]:
        """Handle validation error."""
        error = data.get("error", "")
        
        if error == "NOT_ACTIVATED":
            return {
                "valid": False,
                "message": "License not activated. Internet connection required for first activation.",
                "offline": False,
                "error_code": error,
                "requires_activation": True
            }
        
        if self._on_validation_failed:
            try:
                self._on_validation_failed(data)
            except:
                pass
        
        return {
            "valid": False,
            "message": data.get("message", "License invalid"),
            "offline": False,
            "error_code": error
        }
    
    def _handle_offline_validation(self, key: str, hardware_id: str) -> Dict:
        """Handle offline validation - always requires internet after cache expires."""
        cached_key = self._config.get("license_key")
        cached_hw = self._config.get("hardware_id")
        
        if cached_key == key and cached_hw == hardware_id:
            failed = self._config.get("failed_checks", 0) + 1
            self._config["failed_checks"] = failed
            self._save_config()
            
            if failed < self.MAX_FAILED_CHECKS:
                return {
                    "valid": True,
                    "message": f"Offline mode ({failed}/{self.MAX_FAILED_CHECKS})",
                    "offline": True,
                    "failed_checks": failed,
                }
        
        return {
            "valid": False,
            "message": "Internet connection required",
            "offline": False
        }
    
    def _is_in_grace_period(self) -> bool:
        """Grace period is disabled - always returns False."""
        return False
    
    def get_license_dates(self) -> Dict[str, Any]:
        """Get license activation and expiration dates."""
        activated_at = self._config.get("activated_at")
        expires_at = self._config.get("expires_at")
        
        result = {
            "activated_at": activated_at,
            "expires_at": expires_at,
            "days_remaining": None,
            "is_lifetime": expires_at is None
        }
        
        if expires_at:
            try:
                expires_dt = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
                days_left = (expires_dt - datetime.now(expires_dt.tzinfo)).days
                result["days_remaining"] = days_left
                result["expired"] = days_left < 0
            except:
                pass
        
        return result
    
    def _is_cache_valid(self) -> bool:
        """Check if cache is valid."""
        last_check = self._config.get("last_validated")
        if not last_check:
            return False
        
        last = datetime.fromisoformat(last_check)
        return datetime.now() - last < timedelta(hours=self.CACHE_HOURS)
