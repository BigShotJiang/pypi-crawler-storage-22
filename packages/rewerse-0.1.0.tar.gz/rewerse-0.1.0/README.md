# rewerse

Python bindings for the REWE mobile API.

## Notes

- FFI wrapper around compiled Go library ([Github](https://github.com/ByteSizedMarius/rewerse-engineering/)), not native Python
- ~9 MB package size (includes .so and .dll)
- Linux x86_64 and Windows x86_64 only
- Response types are untyped dicts; see [Go structs](https://pkg.go.dev/github.com/ByteSizedMarius/rewerse-engineering/pkg) for field definitions

## Requirements

- Python 3.10+
- mTLS certificates from REWE APK ([extraction instructions](https://github.com/ByteSizedMarius/rewerse-engineering/tree/main/docs))

## Installation

```bash
pip install rewerse
```

## Usage

```python
from rewerse import Rewerse

client = Rewerse(cert="certificate.pem", key="private.key")

markets = client.market_search("Berlin")
market_id = markets[0]["wwIdent"]

response = client.get_products(market_id, "Milch")
discounts = client.get_discounts(market_id)
recipes = client.recipe_search(search_term="Pasta")
```

## License

MIT
