"""Tests for the rewerse Python bridge."""

import os
from pathlib import Path

import pytest

from rewerse import Rewerse, RewerseError


def _find_certs() -> tuple[str, str]:
    """Find certificate files from env vars or default location."""
    cert = os.environ.get("REWERSE_CERT")
    key = os.environ.get("REWERSE_KEY")

    if cert and key:
        return cert, key

    # Default location relative to repo root
    repo_root = Path(__file__).parent.parent.parent
    cert_path = repo_root / "stuff" / "mtls_prod_cert.pem"
    key_path = repo_root / "stuff" / "mtls_prod_key.pem"

    if not cert_path.exists() or not key_path.exists():
        pytest.skip("Certificates not found. Set REWERSE_CERT and REWERSE_KEY env vars.")

    return str(cert_path), str(key_path)


@pytest.fixture(scope="module")
def client() -> Rewerse:
    """Create a Rewerse client with valid certificates."""
    cert, key = _find_certs()
    return Rewerse(cert=cert, key=key)


@pytest.fixture(scope="module")
def market_id(client: Rewerse) -> str:
    """Get a valid market ID for testing."""
    markets = client.market_search("Hamburg")
    return markets[0]["wwIdent"]


class TestInit:
    def test_init_with_valid_certs(self):
        """Client initializes successfully with valid certificates."""
        cert, key = _find_certs()
        client = Rewerse(cert=cert, key=key)
        assert client is not None

    def test_init_with_invalid_certs(self):
        """Client raises RewerseError with invalid certificate paths."""
        with pytest.raises(RewerseError, match="error loading certificates"):
            Rewerse(cert="nonexistent.pem", key="nonexistent.key")


class TestMarkets:
    def test_market_search(self, client: Rewerse):
        """Market search returns a list of markets."""
        markets = client.market_search("Berlin")

        assert isinstance(markets, list)
        assert len(markets) > 0
        assert "wwIdent" in markets[0]
        assert "name" in markets[0]
        assert "city" in markets[0]

    def test_market_search_empty_query(self, client: Rewerse):
        """Market search with empty query raises error."""
        with pytest.raises(RewerseError):
            client.market_search("")

    def test_get_market_details(self, client: Rewerse, market_id: str):
        """Get market details returns market info."""
        details = client.get_market_details(market_id)

        assert isinstance(details, dict)
        assert "Market" in details or "market" in details.get("Market", details)


class TestProducts:
    def test_get_products(self, client: Rewerse, market_id: str):
        """Product search returns results."""
        results = client.get_products(market_id, "Milch")

        assert isinstance(results, dict)

    def test_get_product_suggestions(self, client: Rewerse):
        """Product suggestions returns list."""
        suggestions = client.get_product_suggestions("Brot")

        assert isinstance(suggestions, list)


class TestDiscounts:
    def test_get_discounts(self, client: Rewerse, market_id: str):
        """Get discounts returns categories."""
        discounts = client.get_discounts(market_id)

        assert isinstance(discounts, dict)
        assert "Categories" in discounts
        assert isinstance(discounts["Categories"], list)


class TestRecipes:
    def test_recipe_search(self, client: Rewerse):
        """Recipe search returns results with totalCount."""
        results = client.recipe_search(search_term="Pasta")

        assert isinstance(results, dict)
        assert "totalCount" in results
        assert results["totalCount"] > 0
        assert "recipes" in results

    def test_recipe_search_with_filters(self, client: Rewerse):
        """Recipe search with difficulty filter works."""
        results = client.recipe_search(
            search_term="Salat",
            difficulty="Gering",
            objects_per_page=5,
        )

        assert isinstance(results, dict)
        assert "recipes" in results

    def test_get_recipe_popular_terms(self, client: Rewerse):
        """Get popular terms returns list."""
        terms = client.get_recipe_popular_terms()

        assert isinstance(terms, list)
        assert len(terms) > 0


class TestMisc:
    def test_get_recalls(self, client: Rewerse):
        """Get recalls returns list (may be empty)."""
        recalls = client.get_recalls()

        assert isinstance(recalls, list)

    def test_get_recipe_hub(self, client: Rewerse):
        """Get recipe hub returns hub data."""
        hub = client.get_recipe_hub()

        assert isinstance(hub, dict)

    def test_get_service_portfolio(self, client: Rewerse):
        """Get service portfolio for zip code."""
        portfolio = client.get_service_portfolio("20095")

        assert isinstance(portfolio, dict)
        assert "customerZipCode" in portfolio
        assert portfolio["customerZipCode"] == "20095"


class TestBasket:
    @pytest.fixture
    def pickup_market(self, client: Rewerse) -> tuple[str, str]:
        """Get a market with pickup service."""
        portfolio = client.get_service_portfolio("67065")
        if not portfolio.get("pickupMarkets"):
            pytest.skip("No pickup markets for zip 67065")
        market = portfolio["pickupMarkets"][0]
        return market["wwIdent"], "67065"

    def test_create_basket(self, client: Rewerse, pickup_market: tuple[str, str]):
        """Create basket returns session info."""
        market_id, zip_code = pickup_market
        session = client.create_basket(market_id, zip_code, "PICKUP")

        assert isinstance(session, dict)
        assert "basketId" in session
        assert "deviceId" in session
        assert "version" in session
        assert session["basketId"] != ""
        assert session["deviceId"] != ""

    def test_basket_full_flow(self, client: Rewerse, pickup_market: tuple[str, str]):
        """Full basket flow: create, add, update, remove."""
        market_id, zip_code = pickup_market

        # Create basket
        session = client.create_basket(market_id, zip_code, "PICKUP")
        basket_id = session["basketId"]
        version = session["version"]

        # Get a product listing ID
        products = client.get_products(market_id, "Milch")
        product_list = products.get("Data", {}).get("Products", {}).get("Products", [])
        if not product_list:
            pytest.skip("No products found")

        listing_id = product_list[0].get("Listing", {}).get("ListingID", "")
        if not listing_id:
            pytest.skip("Product has no listing ID")

        # Add item
        basket = client.set_basket_item(
            basket_id, market_id, zip_code, "PICKUP",
            listing_id, quantity=2, version=version
        )
        assert len(basket.get("lineItems", [])) > 0
        assert basket["lineItems"][0]["quantity"] == 2
        version = basket["version"]

        # Update quantity
        basket = client.set_basket_item(
            basket_id, market_id, zip_code, "PICKUP",
            listing_id, quantity=1, version=version
        )
        assert basket["lineItems"][0]["quantity"] == 1

        # Remove item
        basket = client.remove_basket_item(
            basket_id, market_id, zip_code, "PICKUP", listing_id
        )
        assert len(basket.get("lineItems", [])) == 0


class TestDelivery:
    @pytest.fixture
    def delivery_market(self, client: Rewerse) -> tuple[str, str]:
        """Get a market with delivery service."""
        portfolio = client.get_service_portfolio("50667")
        if not portfolio.get("deliveryMarket"):
            pytest.skip("No delivery market for zip 50667")
        market = portfolio["deliveryMarket"]
        return market["wwIdent"], "50667"

    def test_get_bulky_goods_config(self, client: Rewerse, delivery_market: tuple[str, str]):
        """Get bulky goods config returns beverage limits."""
        market_id, _ = delivery_market
        config = client.get_bulky_goods_config(market_id, "DELIVERY")

        assert isinstance(config, dict)
        assert "hasBeverageSurcharge" in config

    def test_shop_overview_delivery(self, client: Rewerse, delivery_market: tuple[str, str]):
        """Shop overview with DELIVERY mode works."""
        market_id, zip_code = delivery_market
        overview = client.get_shop_overview(
            market_id, service_type="DELIVERY", zip_code=zip_code
        )

        assert isinstance(overview, dict)
