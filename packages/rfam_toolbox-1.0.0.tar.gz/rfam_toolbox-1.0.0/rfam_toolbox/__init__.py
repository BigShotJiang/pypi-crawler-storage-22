"""
RFAM Toolbox - Tools for Radio Frequency Additive Manufacturing Analysis

This package provides two complementary analysis workflows:
1. Dimensional Accuracy Analysis - Evaluate printed pattern precision
2. Ink Concentration Analysis - Characterize ink deposition properties

For usage, run: python -m rfam_toolbox.launcher
"""

__version__ = "1.0.0"
__author__ = "Matthew L. McCoy"
