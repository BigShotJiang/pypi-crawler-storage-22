"""Allow running the package directly: python -m rfam_toolbox"""

from rfam_toolbox.launcher import main

if __name__ == "__main__":
    main()
