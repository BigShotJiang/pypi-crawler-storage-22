This is a package I made to allow for a intermediate RFDETR model, one that uses memory efficent xformers package to train and requires significantly less memory. It is called, RFDETRSegIntermediate.

IF YOUR ON WINDOWS PLEASE RUN THE FOLLOWING COMMAND IN YOUR CMD PROMPT (preferably BEFORE downloading the package):
```
pip install https://huggingface.co/madbuda/triton-windows-builds/resolve/main/triton-3.0.0-cp312-cp312-win_amd64.whl 
```
otherwise, install triton by:
```
pip3 install triton
```

install all packages EXACTLY as the pyproject.toml wants it to be.