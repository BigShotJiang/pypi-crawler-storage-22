"""
RFF Code - это библиотека с полезными функциями для работы с веб-страницами.
"""

from .rffcode import a

__all__ = ['a']
__version__ = '0.1.0'
__author__ = 'yourRoff'