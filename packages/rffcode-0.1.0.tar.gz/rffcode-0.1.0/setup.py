from setuptools import setup, find_packages


def readme():
  with open('README.md', 'r', encoding='utf-8') as f:
    return f.read()


setup(
  name='rffcode',
  version='0.1.0',
  author='yourRoff',
  author_email='cryshenka1311@gmail.com',
  description='Fan code for me',
  long_description=readme(),
  long_description_content_type='text/markdown',
  url='https://github.com/yourRoff/rffcode',
  packages=find_packages(),
  install_requires=['requests', 'beautifulsoup4', 'lxml'],
  classifiers=[
    'Programming Language :: Python :: 3.11',
    'License :: OSI Approved :: MIT License',
    'Operating System :: OS Independent',
  ],
  keywords='rff roff web scraping',
  python_requires='>=3.6',
)