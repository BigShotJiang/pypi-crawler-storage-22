Rgrow is a tile assembly model simulator, primarily built as a fast
implementation of kinetic models, inspired by Xgrow; this is the
Python interface for rgrow.

