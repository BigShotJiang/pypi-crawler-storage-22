.. Rgrow documentation master file, created by
   sphinx-quickstart on Wed Apr 26 21:06:08 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Rgrow Python interface documentation
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   reference/tileset
   reference/simulation
   reference/ffs

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
