from .base import ReportingMethod

__all__ = ["ReportingMethod"]
