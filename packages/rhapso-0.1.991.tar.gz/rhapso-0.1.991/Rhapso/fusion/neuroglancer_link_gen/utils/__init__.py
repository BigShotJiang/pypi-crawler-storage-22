"""
Init file of utility functions
"""
__version__ = "0.0.1"
