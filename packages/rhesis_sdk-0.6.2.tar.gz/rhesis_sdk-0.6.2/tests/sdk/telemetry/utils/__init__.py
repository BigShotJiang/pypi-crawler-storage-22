"""Tests for telemetry utilities."""
