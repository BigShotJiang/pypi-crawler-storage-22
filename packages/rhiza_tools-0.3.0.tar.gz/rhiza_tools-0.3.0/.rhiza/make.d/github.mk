## github.mk - github repo maintenance and helpers
# This file is included by the main Makefile

# Declare phony targets
.PHONY: gh-install view-prs view-issues failed-workflows whoami print-logo

##@ GitHub Helpers
gh-install: ## check for gh cli existence and install extensions
	@if ! command -v gh >/dev/null 2>&1; then \
		printf "${YELLOW}[WARN] gh cli not found.${RESET}\n"; \
		printf "${BLUE}[INFO] Please install it from: https://github.com/cli/cli?tab=readme-ov-file#installation${RESET}\n"; \
	else \
		printf "${GREEN}[INFO] gh cli is installed.${RESET}\n"; \
	fi

view-prs: gh-install ## list open pull requests
	@printf "${BLUE}[INFO] Open Pull Requests:${RESET}\n"
	@gh pr list --json number,title,author,headRefName,updatedAt --template \
		'{{tablerow (printf "NUM" | color "bold") (printf "TITLE" | color "bold") (printf "AUTHOR" | color "bold") (printf "BRANCH" | color "bold") (printf "UPDATED" | color "bold")}}{{range .}}{{tablerow (printf "#%v" .number | color "green") .title (.author.login | color "cyan") (.headRefName | color "yellow") (timeago .updatedAt | color "white")}}{{end}}'

view-issues: gh-install ## list open issues
	@printf "${BLUE}[INFO] Open Issues:${RESET}\n"
	@gh issue list --json number,title,author,labels,updatedAt --template \
		'{{tablerow (printf "NUM" | color "bold") (printf "TITLE" | color "bold") (printf "AUTHOR" | color "bold") (printf "LABELS" | color "bold") (printf "UPDATED" | color "bold")}}{{range .}}{{tablerow (printf "#%v" .number | color "green") .title (.author.login | color "cyan") (pluck "name" .labels | join ", " | color "yellow") (timeago .updatedAt | color "white")}}{{end}}'

failed-workflows: gh-install ## list recent failing workflow runs
	@printf "${BLUE}[INFO] Recent Failing Workflow Runs:${RESET}\n"
	@gh run list --limit 10 --status failure --json conclusion,name,headBranch,event,createdAt --template \
		'{{tablerow (printf "STATUS" | color "bold") (printf "NAME" | color "bold") (printf "BRANCH" | color "bold") (printf "EVENT" | color "bold") (printf "TIME" | color "bold")}}{{range .}}{{tablerow (printf "%s" .conclusion | color "red") .name (.headBranch | color "cyan") (.event | color "yellow") (timeago .createdAt | color "white")}}{{end}}'

whoami: gh-install ## check github auth status
	@printf "${BLUE}[INFO] GitHub Authentication Status:${RESET}\n"
	@gh auth status --hostname github.com --json hosts --template \
		'{{range $$host, $$accounts := .hosts}}{{range $$accounts}}{{if .active}}  {{printf "✓" | color "green"}} Logged in to {{$$host}} account {{.login | color "bold"}} ({{.tokenSource}}){{"\n"}}  Active account: {{printf "true" | color "green"}}{{"\n"}}  Git operations protocol: {{.gitProtocol | color "yellow"}}{{"\n"}}  Token scopes: {{.scopes | color "yellow"}}{{"\n"}}{{end}}{{end}}{{end}}' 
