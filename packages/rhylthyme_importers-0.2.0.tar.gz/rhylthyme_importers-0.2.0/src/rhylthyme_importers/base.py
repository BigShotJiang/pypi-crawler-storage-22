"""
Base importer class and registry for Rhylthyme importers.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime
import re


@dataclass
class ImportResult:
    """Result of an import operation."""
    success: bool
    program: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    source_url: Optional[str] = None
    source_type: str = "unknown"


class BaseImporter(ABC):
    """Base class for all Rhylthyme importers."""

    # Subclasses should override these
    name: str = "base"
    description: str = "Base importer"
    supported_domains: List[str] = []

    @abstractmethod
    def can_import(self, url_or_query: str) -> bool:
        """Check if this importer can handle the given URL or query."""
        pass

    @abstractmethod
    def import_from_url(self, url: str) -> ImportResult:
        """Import a program from a URL."""
        pass

    @abstractmethod
    def search(self, query: str) -> List[Dict[str, Any]]:
        """Search for importable items. Returns list of {name, url, description}."""
        pass

    def generate_program_id(self, name: str) -> str:
        """Generate a safe program ID from a name."""
        return re.sub(r'[^a-zA-Z0-9_-]', '_', name.lower())[:50]

    def create_base_program(
        self,
        name: str,
        description: str,
        environment_type: str,
        source_url: str,
        source_type: str
    ) -> Dict[str, Any]:
        """Create a base program structure."""
        return {
            "programId": self.generate_program_id(name),
            "name": name,
            "description": description,
            "version": "1.0.0",
            "environmentType": environment_type,
            "startTrigger": {"type": "manual"},
            "tracks": [],
            "resourceConstraints": [],
            "metadata": {
                "source": {
                    "type": source_type,
                    "url": source_url,
                    "imported_at": datetime.now().isoformat(),
                    "importer": self.name
                }
            }
        }


class ImporterRegistry:
    """Registry for available importers."""

    _importers: Dict[str, BaseImporter] = {}

    @classmethod
    def register(cls, importer: BaseImporter) -> None:
        """Register an importer."""
        cls._importers[importer.name] = importer

    @classmethod
    def get(cls, name: str) -> Optional[BaseImporter]:
        """Get an importer by name."""
        return cls._importers.get(name)

    @classmethod
    def get_all(cls) -> Dict[str, BaseImporter]:
        """Get all registered importers."""
        return cls._importers.copy()

    @classmethod
    def find_for_url(cls, url: str) -> Optional[BaseImporter]:
        """Find an importer that can handle the given URL."""
        for importer in cls._importers.values():
            if importer.can_import(url):
                return importer
        return None

    @classmethod
    def list_importers(cls) -> List[Dict[str, Any]]:
        """List all available importers with their info."""
        return [
            {
                "name": imp.name,
                "description": imp.description,
                "supported_domains": imp.supported_domains
            }
            for imp in cls._importers.values()
        ]
