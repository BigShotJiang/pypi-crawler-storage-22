"""Metagene profile related functions"""

# Part of ribotricer software
#
# Copyright (C) 2020-2026 Saket Choudhary, Wenzheng Li, and Andrew D Smith
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

from __future__ import annotations

import sys
from collections import Counter, OrderedDict
from collections.abc import Iterator
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd
from tqdm.autonotebook import tqdm

from .const import CUTOFF, TYPICAL_OFFSET
from .interval import Interval
from .statistics import phasescore

if TYPE_CHECKING:
    from .orf import ORF

tqdm.pandas()

# Type aliases
AlignmentDict = dict[int, dict[str, Counter[tuple[str, int]]]]
MetageneDict = dict[int, tuple[pd.Series, pd.Series, float, int, float, int]]


def next_genome_pos(
    ivs: list[Interval],
    max_positions: int,
    leader: int,
    trailer: int,
    reverse: bool = False,
) -> Iterator[int]:
    """Generate genome positions from intervals.

    Parameters
    ----------
    ivs : list[Interval]
        List of intervals.
    max_positions : int
        Maximum number of positions to yield.
    leader : int
        Number of positions to include upstream.
    trailer : int
        Number of positions to include downstream.
    reverse : bool, optional
        Whether to iterate in reverse, by default False.

    Yields
    ------
    int
        Genome position.
    """
    if len(ivs) == 0:
        return iter([])
    cnt = 0
    leader_iv = Interval(
        ivs[0].chrom, ivs[0].start - leader, ivs[0].start - 1, ivs[0].strand
    )
    trailer_iv = Interval(
        ivs[-1].chrom, ivs[-1].end + 1, ivs[-1].end + trailer, ivs[-1].strand
    )
    combined_ivs = [leader_iv] + ivs + [trailer_iv]

    cnt = 0
    if not reverse:
        for interval in combined_ivs:
            for pos in range(interval.start, interval.end + 1):
                cnt += 1
                if cnt <= max_positions:
                    yield pos
    else:
        for interval in reversed(combined_ivs):
            for pos in range(interval.end, interval.start - 1, -1):
                cnt += 1
                if cnt <= max_positions:
                    yield pos


def orf_coverage_length(
    orf: ORF,
    alignments: AlignmentDict,
    length: int,
    max_positions: int,
    offset_5p: int = 20,
    offset_3p: int = 0,
) -> tuple[pd.Series, pd.Series]:
    """Calculate ORF coverage for a specific read length.

    Parameters
    ----------
    orf : ORF
        Instance of ORF.
    alignments : AlignmentDict
        Alignments summarized from bam.
    length : int
        The target length.
    max_positions : int
        The number of nts to include.
    offset_5p : int, optional
        The number of nts to include from 5'prime, by default 20.
    offset_3p : int, optional
        The number of nts to include from 3'prime, by default 0.

    Returns
    -------
    tuple[pd.Series, pd.Series]
        - from_start: Coverage for ORF for specific length aligned at start codon.
        - from_stop: Coverage for ORF for specific length aligned at stop codon.
    """
    coverage: list[int] = []
    chrom = orf.chrom
    strand = orf.strand
    if strand == "-":
        offset_5p, offset_3p = offset_3p, offset_5p

    for pos in next_genome_pos(
        orf.intervals, max_positions, offset_5p, offset_3p, strand == "-"
    ):
        try:
            coverage.append(alignments[length][strand][(chrom, pos)])
        except KeyError:
            coverage.append(0)

    if strand == "-":
        from_start = pd.Series(
            np.array(coverage), index=np.arange(-offset_3p, len(coverage) - offset_3p)
        )
        from_stop = pd.Series(
            np.array(coverage),
            index=np.arange(offset_5p - len(coverage) + 1, offset_5p + 1),
        )
    else:
        from_start = pd.Series(
            np.array(coverage), index=np.arange(-offset_5p, len(coverage) - offset_5p)
        )
        from_stop = pd.Series(
            np.array(coverage),
            index=np.arange(offset_3p - len(coverage) + 1, offset_3p + 1),
        )

    return (from_start, from_stop)


def metagene_coverage(
    cds: list[ORF],
    alignments: AlignmentDict,
    read_lengths: dict[int, int],
    prefix: str,
    max_positions: int = 600,
    offset_5p: int = 20,
    offset_3p: int = 0,
    meta_min_reads: int = 100000,
) -> MetageneDict:
    """Calculate metagene coverage profiles.

    Parameters
    ----------
    cds : list[ORF]
        List of CDS ORFs.
    alignments : AlignmentDict
        Alignments summarized from bam.
    read_lengths : dict[int, int]
        Dictionary where key is the length, value is the number reads.
    prefix : str
        Prefix for the output file.
    max_positions : int, optional
        The number of nts to include, by default 600.
    offset_5p : int, optional
        The number of nts to include from the 5'prime, by default 20.
    offset_3p : int, optional
        The number of nts to include from the 3'prime, by default 0.
    meta_min_reads : int, optional
        Minimum number of reads for a read length to be considered, by default 100000.

    Returns
    -------
    MetageneDict
        Dictionary where key is the length, value is tuple of
        (from_start, from_stop, phasescore_5p, valid_5p, phasescore_3p, valid_3p).
    """
    metagenes: MetageneDict = {}

    # remove read length whose read number is small
    for length, reads in list(read_lengths.items()):
        if reads < meta_min_reads:
            del read_lengths[length]

    for length in tqdm(read_lengths, unit="read-length", leave=False):
        metagene_coverage_start: pd.Series = pd.Series(dtype=float)
        position_counter_start: Counter[int] = Counter()
        metagene_coverage_stop: pd.Series = pd.Series(dtype=float)
        position_counter_stop: Counter[int] = Counter()

        for orf in tqdm(cds, position=1, unit="ORFs", leave=False):
            from_start, from_stop = orf_coverage_length(
                orf, alignments, length, max_positions, offset_5p, offset_3p
            )
            cov_mean = from_start.mean()
            if cov_mean > 0:
                from_start = from_start / cov_mean
                from_start = from_start.fillna(0)
                metagene_coverage_start = metagene_coverage_start.add(
                    from_start, fill_value=0
                )
                position_counter_start += Counter(from_start.index.tolist())

                from_stop = from_stop / cov_mean
                from_stop = from_stop.fillna(0)
                metagene_coverage_stop = metagene_coverage_stop.add(
                    from_stop, fill_value=0
                )
                position_counter_stop += Counter(from_stop.index.tolist())

        if len(position_counter_start) != len(metagene_coverage_start) or len(
            position_counter_stop
        ) != len(metagene_coverage_stop):
            raise RuntimeError("Metagene coverage and counter mismatch")
        position_counter_start_series = pd.Series(position_counter_start)
        metagene_coverage_start = metagene_coverage_start.div(
            position_counter_start_series
        )
        position_counter_stop_series = pd.Series(position_counter_stop)
        metagene_coverage_stop = metagene_coverage_stop.div(
            position_counter_stop_series
        )

        phasescore_5p, valid_5p = phasescore(metagene_coverage_start.tolist())
        phasescore_3p, valid_3p = phasescore(metagene_coverage_stop.tolist())
        metagenes[length] = (
            metagene_coverage_start,
            metagene_coverage_stop,
            phasescore_5p,
            valid_5p,
            phasescore_3p,
            valid_3p,
        )

    to_write_5p = "fragment_length\toffset_5p\tprofile\tphase_score\tvalid_codons\n"
    to_write_3p = "fragment_length\toffset_3p\tprofile\tphase_score\tvalid_codons\n"
    for length in sorted(metagenes):
        to_write_5p += f"{length}\t{offset_5p}\t{metagenes[length][0].tolist()}\t{metagenes[length][2]}\t{metagenes[length][3]}\n"
        to_write_3p += f"{length}\t{offset_3p}\t{metagenes[length][1].tolist()}\t{metagenes[length][4]}\t{metagenes[length][5]}\n"

    with open(f"{prefix}_metagene_profiles_5p.tsv", "w") as output:
        output.write(to_write_5p)
    with open(f"{prefix}_metagene_profiles_3p.tsv", "w") as output:
        output.write(to_write_3p)

    return metagenes


def align_metagenes(
    metagenes: MetageneDict,
    read_lengths: dict[int, int],
    prefix: str,
    phase_score_cutoff: float = CUTOFF,
    remove_nonperiodic: bool = False,
) -> OrderedDict[int, int]:
    """Align metagene coverages to determine the lag of the psites.

    The non-periodic read length will be discarded in this step.

    Parameters
    ----------
    metagenes : MetageneDict
        Dictionary where key is the length, value is the metagene coverage.
    read_lengths : dict[int, int]
        Dictionary where key is the length, value is the number of reads.
    prefix : str
        Prefix for output files.
    phase_score_cutoff : float, optional
        Phase score cutoff, by default CUTOFF.
    remove_nonperiodic : bool, optional
        Whether remove non-periodic read lengths, by default False.

    Returns
    -------
    OrderedDict[int, int]
        Dictionary where key is the length, value is the offset.
    """
    # discard non-periodic read lengths
    if remove_nonperiodic:
        for length, (_, _, coh, _, _, _) in list(metagenes.items()):
            if coh < phase_score_cutoff:
                del read_lengths[length]
                del metagenes[length]

    if len(read_lengths) == 0:
        sys.exit(
            f"WARNING: no periodic read length found... using cutoff {phase_score_cutoff}"
        )

    psite_offsets: OrderedDict[int, int] = OrderedDict()
    base = n_reads = 0
    for length, reads in list(read_lengths.items()):
        if reads > n_reads:
            base = length
            n_reads = reads
    reference = metagenes[base][0].values
    to_write = f"relative lag to base: {base}\n"
    for length, (meta, _, _, _, _, _) in list(metagenes.items()):
        cov = meta.values
        xcorr = np.correlate(reference, cov, "full")
        origin = len(xcorr) // 2
        bound = min(base, length)
        xcorr = xcorr[(origin - bound) : (origin + bound)]
        lag = int(np.argmax(xcorr) - len(xcorr) // 2)
        psite_offsets[length] = lag + TYPICAL_OFFSET
        to_write += f"\tlag of {length}: {lag}\n"
    with open(f"{prefix}_psite_offsets.txt", "w") as output:
        output.write(to_write)
    return psite_offsets
