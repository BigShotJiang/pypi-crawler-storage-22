"""
运行 python -m richit 时展示终端富文本功能演示。
"""

if __name__ == "__main__":
    import runpy
    runpy.run_module("rich", run_name="__main__")
