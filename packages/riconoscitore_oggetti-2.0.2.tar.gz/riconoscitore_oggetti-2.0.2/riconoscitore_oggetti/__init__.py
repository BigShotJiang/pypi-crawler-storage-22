"""
Riconoscitore Oggetti — Teachable Machine + Sintesi Vocale Italiana.

Uso rapido::

    from riconoscitore_oggetti import avvia
    avvia()                              # file dialog interattivo
    avvia("modello.tflite", "labels.txt")  # percorsi espliciti

Da terminale::

    riconoscitore

Prof. G. Aleci — ITIS Q. Sella, Biella — A.S. 2025/2026
"""

__version__ = "2.0.0"
__author__ = "Giuseppe Aleci"

from .app import avvia
from .classificatore import Classificatore
from .vocale import MotoreVocale

__all__ = ["avvia", "Classificatore", "MotoreVocale", "__version__"]
