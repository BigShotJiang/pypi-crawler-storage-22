"""Permette di lanciare il pacchetto con: python -m riconoscitore_oggetti"""

from .app import avvia

if __name__ == "__main__":
    avvia()
