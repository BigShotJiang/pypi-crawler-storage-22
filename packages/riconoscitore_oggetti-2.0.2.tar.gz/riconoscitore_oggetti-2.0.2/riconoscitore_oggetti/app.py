"""
Loop principale dell'applicazione Riconoscitore Oggetti.
"""

import time
from collections import deque

import cv2

from . import config as cfg
from .classificatore import Classificatore
from .overlay import disegna_overlay, scegli_file
from .vocale import MotoreVocale


def _carica_etichette(path: str) -> list[str]:
    """Carica le etichette da un file .txt (supporta formato Teachable Machine)."""
    labels: list[str] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split(maxsplit=1)
            if not parts:
                continue
            if len(parts) == 2 and parts[0].isdigit():
                labels.append(parts[1])
            else:
                labels.append(parts[0])
    return labels


def avvia(
    model_path: str | None = None,
    labels_path: str | None = None,
    camera_index: int = 0,
    config: dict | None = None,
) -> None:
    """
    Avvia il riconoscitore di oggetti.

    Parametri
    ---------
    model_path : str, opzionale
        Percorso al modello ``.tflite``. Se ``None`` apre un file dialog.
    labels_path : str, opzionale
        Percorso al file etichette ``.txt``. Se ``None`` apre un file dialog.
    camera_index : int
        Indice della webcam (default 0).
    config : dict, opzionale
        Dizionario per sovrascrivere le costanti di ``config.py``.
        Esempio: ``{"SOGLIA_CONFIDENZA": 0.85, "VELOCITA_VOCE": 180}``
    """

    # --- Applica configurazione custom ---
    if config:
        for chiave, valore in config.items():
            if hasattr(cfg, chiave):
                setattr(cfg, chiave, valore)

    # --- Inizializza il motore vocale ---
    voce = MotoreVocale(velocita=cfg.VELOCITA_VOCE, volume=cfg.VOLUME_VOCE)

    # --- Selezione file (se non forniti) ---
    if model_path is None:
        print("Seleziona il modello TensorFlow Lite")
        voce.parla("Seleziona il modello TensorFlow Lite")
        model_path = scegli_file(
            "Seleziona il modello TFLite (.tflite)",
            [("Modelli TFLite", "*.tflite"), ("Tutti i file", "*.*")],
        )
        if not model_path:
            print("Nessun modello selezionato. Uscita.")
            return

    if labels_path is None:
        print("Seleziona il file delle etichette")
        voce.parla("Seleziona il file delle etichette")
        labels_path = scegli_file(
            "Seleziona le etichette (.txt)",
            [("File di testo", "*.txt"), ("Tutti i file", "*.*")],
        )
        if not labels_path:
            print("Nessun file etichette selezionato. Uscita.")
            return

    # --- Carica etichette e modello ---
    labels = _carica_etichette(labels_path)
    print(f"Etichette caricate: {labels}")

    classificatore = Classificatore(model_path, labels, buffer_size=cfg.BUFFER_FRAME)
    print(f"Modello caricato. Input shape: {classificatore.input_shape}")

    # --- Apri webcam ---
    cap = cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        print("Errore: impossibile aprire la webcam!")
        voce.parla("Errore. Impossibile aprire la webcam.")
        return

    voce.parla("Riconoscitore avviato. Premi Q per uscire.")

    # --- Variabili di stato ---
    pausa = False
    ultima_etichetta_annunciata = ""
    log_messaggi: deque = deque(maxlen=8)
    fps = 0.0
    frame_count = 0
    fps_timer = time.time()
    frame_display = None

    print("\n--- COMANDI ---")
    print("Q = Esci | M = Muto/Unmuto | S = Screenshot | P = Pausa")
    print("---------------\n")

    while True:
        if not pausa:
            ret, frame = cap.read()
            if not ret:
                print("Errore lettura frame.")
                break

            # --- Calcolo FPS ---
            frame_count += 1
            elapsed = time.time() - fps_timer
            if elapsed >= 1.0:
                fps = frame_count / elapsed
                frame_count = 0
                fps_timer = time.time()

            # --- Predizione ---
            classificatore.predici(frame)
            etichetta_stabile, confidenza_stabile = classificatore.predizione_stabile()

            # --- Annuncio vocale ---
            if (
                etichetta_stabile
                and cfg.ETICHETTA_NEUTRA not in etichetta_stabile.lower()
                and confidenza_stabile >= cfg.SOGLIA_CONFIDENZA
                and etichetta_stabile != ultima_etichetta_annunciata
            ):
                ultima_etichetta_annunciata = etichetta_stabile
                voce.parla(etichetta_stabile, cooldown=cfg.COOLDOWN_VOCE_SEC)

                ora = time.strftime("%H:%M:%S")
                log_messaggi.appendleft((ora, etichetta_stabile, confidenza_stabile * 100))
                print(f"[{ora}] Riconosciuto: {etichetta_stabile} ({confidenza_stabile * 100:.0f}%)")

            # Reset se torna a standard
            if etichetta_stabile and cfg.ETICHETTA_NEUTRA in etichetta_stabile.lower():
                ultima_etichetta_annunciata = ""

            # --- Ridimensiona per visualizzazione ---
            h_orig, w_orig = frame.shape[:2]
            scala = cfg.LARGHEZZA_FINESTRA / w_orig
            frame_display = cv2.resize(frame, (cfg.LARGHEZZA_FINESTRA, int(h_orig * scala)))

            # --- Overlay ---
            frame_display = disegna_overlay(
                frame_display, etichetta_stabile, confidenza_stabile,
                fps, voce.is_muto, pausa, list(log_messaggi),
            )
        else:
            # In pausa
            if frame_display is not None:
                cv2.putText(
                    frame_display, "PAUSA",
                    (frame_display.shape[1] // 2 - 80, frame_display.shape[0] // 2),
                    cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 255), 3,
                )

        if frame_display is not None:
            cv2.imshow("Riconoscitore Oggetti - Teachable Machine", frame_display)

        # --- Gestione tasti ---
        key = cv2.waitKey(1) & 0xFF
        if key in (ord("q"), ord("Q")):
            break
        elif key in (ord("m"), ord("M")):
            stato = voce.toggle_muto()
            print(f"Audio: {'MUTO' if stato else 'ATTIVO'}")
        elif key in (ord("s"), ord("S")):
            filename = f"screenshot_{time.strftime('%Y%m%d_%H%M%S')}.png"
            cv2.imwrite(filename, frame)
            print(f"Screenshot salvato: {filename}")
            voce.parla("Screenshot salvato")
        elif key in (ord("p"), ord("P")):
            pausa = not pausa
            print(f"{'PAUSA' if pausa else 'RIPRESO'}")

    # --- Cleanup ---
    cap.release()
    cv2.destroyAllWindows()
    print("Applicazione chiusa.")
