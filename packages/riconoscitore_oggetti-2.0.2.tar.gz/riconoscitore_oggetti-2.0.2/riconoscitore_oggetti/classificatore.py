"""
Classificatore TFLite con smoothing a buffer circolare.

Usa il voto di maggioranza su N frame per stabilizzare le predizioni
ed eliminare il flickering.
"""

from collections import deque

import cv2
import numpy as np
import tensorflow as tf


class Classificatore:
    """
    Wrapper per modelli TensorFlow Lite esportati da Teachable Machine.

    Parametri
    ---------
    model_path : str
        Percorso al file ``.tflite``.
    labels : list[str]
        Lista ordinata delle etichette di classe.
    buffer_size : int
        Numero di frame per il buffer di smoothing (dispari consigliato).
    """

    def __init__(self, model_path: str, labels: list[str], buffer_size: int = 7):
        self.interpreter = tf.lite.Interpreter(model_path=model_path)
        self.interpreter.allocate_tensors()
        self.input_details = self.interpreter.get_input_details()
        self.output_details = self.interpreter.get_output_details()
        self.input_shape = self.input_details[0]["shape"][1:3]  # [H, W]
        self.labels = labels
        self._buffer: deque = deque(maxlen=buffer_size)
        self._confidenze_buffer: deque = deque(maxlen=buffer_size)

    # ------------------------------------------------------------------
    def predici(self, frame: np.ndarray) -> tuple[str, float, np.ndarray]:
        """Esegue la predizione su un singolo frame BGR di OpenCV."""
        resized = cv2.resize(frame, (self.input_shape[1], self.input_shape[0]))
        rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
        input_data = np.expand_dims(rgb, axis=0).astype(np.float32) / 255.0

        self.interpreter.set_tensor(self.input_details[0]["index"], input_data)
        self.interpreter.invoke()
        output = self.interpreter.get_tensor(self.output_details[0]["index"])[0]

        idx = int(np.argmax(output))
        confidenza = float(output[idx])
        etichetta = self.labels[idx]

        self._buffer.append(idx)
        self._confidenze_buffer.append(confidenza)

        return etichetta, confidenza, output

    # ------------------------------------------------------------------
    def predizione_stabile(self) -> tuple[str | None, float]:
        """
        Restituisce la classe più frequente nel buffer (voto di maggioranza)
        e la confidenza media pesata per frequenza.
        """
        if not self._buffer:
            return None, 0.0

        conteggi: dict[int, int] = {}
        for idx in self._buffer:
            conteggi[idx] = conteggi.get(idx, 0) + 1

        idx_stabile = max(conteggi, key=conteggi.get)  # type: ignore[arg-type]
        frequenza = conteggi[idx_stabile] / len(self._buffer)

        confidenze = [
            c for i, c in zip(self._buffer, self._confidenze_buffer) if i == idx_stabile
        ]
        conf_media = sum(confidenze) / len(confidenze) if confidenze else 0.0

        return self.labels[idx_stabile], conf_media * frequenza
