"""
Configurazione globale del Riconoscitore Oggetti.

Modifica questi valori per personalizzare il comportamento dell'applicazione.
Oppure passa un dizionario a ``avvia(config={...})`` per sovrascriverli a runtime.
"""

# --- Predizione ---
SOGLIA_CONFIDENZA = 0.70        # Ignora predizioni sotto il 70%
BUFFER_FRAME = 7                # Frame per lo smoothing (dispari è meglio)

# --- Sintesi vocale ---
COOLDOWN_VOCE_SEC = 2.5         # Secondi minimi tra due annunci vocali
VELOCITA_VOCE = 150             # Parole al minuto per il TTS
VOLUME_VOCE = 0.9               # Volume TTS (0.0 – 1.0)

# --- Visualizzazione ---
ETICHETTA_NEUTRA = "standard"   # Etichetta da non annunciare
COLORE_TESTO = (0, 255, 0)     # Verde per il testo overlay
COLORE_BARRA = (0, 200, 255)   # Arancione per la barra confidenza
LARGHEZZA_FINESTRA = 800        # Larghezza finestra di visualizzazione
