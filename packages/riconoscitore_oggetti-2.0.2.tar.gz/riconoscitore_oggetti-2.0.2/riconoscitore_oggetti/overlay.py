"""
Funzioni per disegnare l'overlay informativo sul frame video.
"""

import cv2

from . import config as cfg


def scegli_file(titolo: str, tipi_file: list) -> str:
    """Apre un dialogo Tkinter per selezionare un file."""
    import tkinter as tk
    from tkinter import filedialog

    root = tk.Tk()
    root.withdraw()
    path = filedialog.askopenfilename(title=titolo, filetypes=tipi_file)
    root.destroy()
    return path


def disegna_overlay(
    frame,
    etichetta: str | None,
    confidenza: float,
    fps: float,
    is_muto: bool,
    is_pausa: bool,
    log_messaggi: list,
):
    """
    Disegna l'overlay informativo sul frame:
    barra di confidenza, etichetta, FPS, stato muto/pausa, log.
    """
    h, w = frame.shape[:2]

    # --- Sfondo semitrasparente in alto ---
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (w, 90), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)

    # --- Etichetta principale ---
    if etichetta and cfg.ETICHETTA_NEUTRA not in etichetta.lower():
        colore = cfg.COLORE_TESTO if confidenza >= cfg.SOGLIA_CONFIDENZA else (0, 165, 255)
        testo = f"{etichetta} ({confidenza * 100:.0f}%)"
        cv2.putText(frame, testo, (15, 35), cv2.FONT_HERSHEY_SIMPLEX, 1.0, colore, 2)

        # Barra di confidenza (colore da rosso a verde)
        barra_w = int((w - 30) * confidenza)
        r = int(255 * (1 - confidenza))
        g = int(255 * confidenza)
        cv2.rectangle(frame, (15, 50), (15 + barra_w, 70), (0, g, r), -1)
        cv2.rectangle(frame, (15, 50), (w - 15, 70), (100, 100, 100), 1)
    else:
        cv2.putText(
            frame, "In attesa...", (15, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (150, 150, 150), 2
        )

    # --- Riga info in basso ---
    info_y = h - 15
    cv2.putText(frame, f"FPS: {fps:.0f}", (15, info_y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)

    stato = []
    if is_muto:
        stato.append("MUTO")
    if is_pausa:
        stato.append("PAUSA")
    if stato:
        testo_stato = " | ".join(stato)
        cv2.putText(frame, testo_stato, (w - 200, info_y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

    # --- Comandi ---
    cv2.putText(
        frame, "Q:esci  M:muto  S:screenshot  P:pausa", (15, 85),
        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (150, 150, 150), 1,
    )

    # --- Log ultimi riconoscimenti (colonna destra) ---
    if log_messaggi:
        log_x = w - 280
        log_y = 120
        cv2.putText(
            frame, "Ultimi riconoscimenti:", (log_x, log_y - 10),
            cv2.FONT_HERSHEY_SIMPLEX, 0.4, (180, 180, 180), 1,
        )
        for i, (tempo, msg, conf) in enumerate(log_messaggi):
            y = log_y + i * 22
            if y > h - 40:
                break
            txt = f"{tempo} - {msg} ({conf:.0f}%)"
            cv2.putText(frame, txt, (log_x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200, 200, 200), 1)

    return frame
