"""
Motore di sintesi vocale thread-safe.

Gestisce la pronuncia in un thread separato per non bloccare il loop video.
"""

import threading
import time
from collections import deque

import pyttsx3


class MotoreVocale:
    """
    Sintesi vocale in thread separato.

    Il motore pyttsx3 viene inizializzato all'interno del worker thread
    (requisito tecnico di pyttsx3 su alcune piattaforme).

    Parametri
    ---------
    velocita : int
        Parole al minuto.
    volume : float
        Volume da 0.0 a 1.0.
    """

    def __init__(self, velocita: int = 150, volume: float = 0.9):
        self._coda: deque = deque(maxlen=3)
        self._thread: threading.Thread | None = None
        self._velocita = velocita
        self._volume = volume
        self._muto = False
        self._ultimo_annuncio: float = 0
        self._ultimo_testo: str = ""

    # ------------------------------------------------------------------
    def parla(self, testo: str, cooldown: float = 2.5) -> None:
        """Accoda un testo da pronunciare, con cooldown anti-ripetizione."""
        if self._muto:
            return
        now = time.time()
        if testo == self._ultimo_testo and (now - self._ultimo_annuncio) < cooldown:
            return
        self._ultimo_testo = testo
        self._ultimo_annuncio = now
        self._coda.append(testo)
        if self._thread is None or not self._thread.is_alive():
            self._thread = threading.Thread(target=self._worker, daemon=True)
            self._thread.start()

    # ------------------------------------------------------------------
    def _worker(self) -> None:
        """Thread worker: processa la coda vocale."""
        motore = pyttsx3.init()
        motore.setProperty("rate", self._velocita)
        motore.setProperty("volume", self._volume)
        # Cerca una voce italiana se disponibile
        for voce in motore.getProperty("voices"):
            if "italian" in voce.name.lower() or "it" in voce.id.lower():
                motore.setProperty("voice", voce.id)
                break
        while self._coda:
            testo = self._coda.popleft()
            motore.say(testo)
            motore.runAndWait()
        motore.stop()

    # ------------------------------------------------------------------
    def toggle_muto(self) -> bool:
        """Attiva/disattiva il muto. Restituisce il nuovo stato."""
        self._muto = not self._muto
        return self._muto

    @property
    def is_muto(self) -> bool:
        return self._muto
