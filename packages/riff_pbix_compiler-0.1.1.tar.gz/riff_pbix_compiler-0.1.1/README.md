 # riff-pbix-compiler
 
 Compile a PBIX file into a **compact manifest** optimized for AI agents:
 - minimal duplication
 - deduped query signatures
 - clear mapping from data → transforms → visuals
 
 ## Install
 
 ```bash
 pip install riff-pbix-compiler
 ```
 
 ## Quick start
 
 ```bash
 riff-pbix-compiler compile "path/to/report.pbix" --out manifest.json
 ```
 
 ## Output
 
 The manifest includes:
 - `dataset` (tables/columns/measures)
 - `power_query` (sources + transformation steps)
 - `queries` (deduped query signatures)
 - `visuals` (each visual references a query)
 - `pages` (page → visuals)
 
 ## Notes
 
 - PBIX parsing uses `pbixray` for back-end model extraction.
 - Visual layout and query metadata are extracted from `Report/Layout`.
