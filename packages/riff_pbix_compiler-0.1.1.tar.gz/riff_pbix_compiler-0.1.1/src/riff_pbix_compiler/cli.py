import argparse
import json
from pathlib import Path

from .compiler import compile_manifest, build_brief


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="riff-pbix-compiler",
        description="Compile a PBIX file into a compact manifest.",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    compile_cmd = sub.add_parser("compile", help="Compile a PBIX to manifest")
    compile_cmd.add_argument("pbix", help="Path to PBIX file")
    compile_cmd.add_argument("--out", "-o", help="Output JSON path")
    compile_cmd.add_argument("--include-raw", action="store_true", help="Include raw M script (verbose only)")
    compile_cmd.add_argument("--compact", action="store_true", help="Write compact manifest (default)")
    compile_cmd.add_argument("--verbose", action="store_true", help="Write verbose manifest")
    compile_cmd.add_argument("--brief", action="store_true", help="Write brief.md summary")
    compile_cmd.add_argument("--pretty", action="store_true", help="Pretty-print JSON")

    args = parser.parse_args(argv)

    if args.cmd == "compile":
        compact = True
        if args.verbose:
            compact = False
        manifest = compile_manifest(args.pbix, include_raw=args.include_raw, compact=compact)
        out_path = Path(args.out) if args.out else Path("pbix_manifest.json")
        if args.pretty:
            payload = json.dumps(manifest, indent=2)
        else:
            payload = json.dumps(manifest)
        out_path.write_text(payload, encoding="utf-8")
        print(f"Wrote manifest: {out_path.resolve()}")
        if args.brief:
            brief_path = out_path.with_suffix(".brief.md")
            brief_path.write_text(build_brief(manifest), encoding="utf-8")
            print(f"Wrote brief: {brief_path.resolve()}")
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
