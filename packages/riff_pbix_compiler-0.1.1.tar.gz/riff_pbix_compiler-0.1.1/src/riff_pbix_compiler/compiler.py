import hashlib
import json
import re
import zipfile
from pathlib import Path

from .pbix_parser import parse_report_layout, parse_mashup, parse_connections


def _hash_query(signature: str) -> str:
    return hashlib.sha1(signature.encode("utf-8")).hexdigest()[:12]


def _dedupe_query(visual):
    meta = visual.get("query_metadata", {})
    selects = meta.get("Select", [])

    groupby = []
    measures = []
    for col in selects:
        col_type = col.get("type")
        name = col.get("name")
        if not name:
            continue
        if col_type in ["measure", "column_agg"]:
            measures.append(name)
        else:
            groupby.append(name)

    groupby = sorted(set(groupby))
    measures = sorted(set(measures))
    from_tables = sorted(set(meta.get("From", [])))
    filters = visual.get("filters") or []

    signature = json.dumps(
        {
            "from": from_tables,
            "groupby": groupby,
            "measures": measures,
            "filters_count": len(filters),
        },
        sort_keys=True,
    )
    query_id = f"q_{_hash_query(signature)}"

    return query_id, {
        "from": from_tables,
        "groupby": groupby,
        "measures": measures,
        "filters_count": len(filters),
    }


def _pbixray_extract(model):
    def to_records(value):
        if hasattr(value, "to_dict"):
            try:
                return value.to_dict(orient="records")
            except Exception:
                return value.to_dict()
        return value

    return {
        "tables": getattr(model, "tables", []),
        "metadata": getattr(model, "metadata", None),
        "power_query": to_records(getattr(model, "power_query", None)),
        "m_parameters": to_records(getattr(model, "m_parameters", None)),
        "size": getattr(model, "size", None),
        "dax_tables": to_records(getattr(model, "dax_tables", None)),
        "dax_measures": to_records(getattr(model, "dax_measures", None)),
        "dax_columns": to_records(getattr(model, "dax_columns", None)),
        "schema": to_records(getattr(model, "schema", None)),
        "relationships": to_records(getattr(model, "relationships", None)),
        "rls": to_records(getattr(model, "rls", None)),
        "statistics": to_records(getattr(model, "statistics", None)),
    }


def _to_jsonable(value):
    try:
        import pandas as pd  # optional at runtime, included in deps
    except Exception:
        pd = None

    if pd is not None:
        if isinstance(value, pd.DataFrame):
            return value.to_dict(orient="records")
        if isinstance(value, pd.Series):
            return value.to_list()
        if isinstance(value, pd.Timestamp):
            return value.isoformat()

    if hasattr(value, "tolist"):
        try:
            return value.tolist()
        except Exception:
            pass

    if hasattr(value, "isoformat"):
        try:
            return value.isoformat()
        except Exception:
            pass

    if isinstance(value, dict):
        return {k: _to_jsonable(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_to_jsonable(v) for v in value]
    if isinstance(value, tuple):
        return [_to_jsonable(v) for v in value]

    return value


def _safe_len(value):
    if value is None:
        return 0


def _extract_dax_dependencies(expression: str | None):
    if not expression:
        return []
    deps = set()
    table_col_pattern = r"'([^']+)'\[([^\]]+)\]"
    for match in re.finditer(table_col_pattern, expression):
        deps.add(f"{match.group(1)}.{match.group(2)}")
    return sorted(deps)


def _infer_source_info(power_query):
    if not power_query:
        return {"source_type": None, "source_uri": None, "type_casts": {}}

    expr = power_query[0].get("Expression") if isinstance(power_query, list) else None
    if not expr:
        return {"source_type": None, "source_uri": None, "type_casts": {}}

    source_uri = None
    source_type = None

    web_match = re.search(r'Web\.Contents\("([^"]+)"\)', expr)
    if web_match:
        source_uri = web_match.group(1)
        source_type = "http_csv"

    type_casts = {}
    for col, dtype in re.findall(r'\{"([^"]+)",\s*type\s+([a-zA-Z0-9_]+)\}', expr):
        type_casts[col] = dtype

    for col, dtype in re.findall(r'\{"([^"]+)",\s*([A-Za-z0-9_]+)\.Type\}', expr):
        type_casts[col] = dtype

    return {"source_type": source_type, "source_uri": source_uri, "type_casts": type_casts}


def _build_csv_contract(schema, queries, power_query):
    main_table = None
    if isinstance(power_query, list) and power_query:
        main_table = power_query[0].get("TableName")
    if not main_table:
        main_table = "data"

    table_columns = [c for c in (schema or []) if c.get("TableName") == main_table]
    expected_headers = [c.get("ColumnName") for c in table_columns if c.get("ColumnName")]
    type_map = {c.get("ColumnName"): c.get("PandasDataType") for c in table_columns if c.get("ColumnName")}

    required = set()
    required_measures = set()
    for q in queries.values():
        for name in q.get("groupby", []):
            if name in type_map:
                required.add(name)
        for name in q.get("measures", []):
            if name in type_map:
                required.add(name)
            else:
                required_measures.add(name)

    optional = [h for h in expected_headers if h not in required]

    return {
        "main_table": main_table,
        "expected_headers": expected_headers,
        "required_headers": sorted(required),
        "optional_headers": optional,
        "type_map": type_map,
        "required_measures": sorted(required_measures),
    }
    try:
        return len(value)
    except Exception:
        return 0


def compile_manifest(pbix_path: str, include_raw: bool = False, compact: bool = True) -> dict:
    pbix_path = str(Path(pbix_path).resolve())

    with zipfile.ZipFile(pbix_path) as z:
        layout = parse_report_layout(z)
        mashup = parse_mashup(z)
        connections = parse_connections(z)

    try:
        from pbixray import PBIXRay
    except Exception as exc:
        raise RuntimeError(
            "pbixray is required. Install: pip install pbixray apsw kaitaistruct pandas"
        ) from exc

    model = PBIXRay(pbix_path)
    pbixray_data = _pbixray_extract(model)

    pages = {}
    visuals = {}
    queries = {}
    query_roles = {}

    for page in layout.get("pages", []):
        page_id = page.get("id")
        page_width = page.get("width") or 0
        page_height = page.get("height") or 0
        pages[page_id] = {
            "name": page.get("name"),
            "width": page_width,
            "height": page_height,
            "visuals": [v.get("id") for v in page.get("visuals", []) if v.get("id")],
        }

        for visual in page.get("visuals", []):
            v_id = visual.get("id")
            query_id, query_obj = _dedupe_query(visual)
            if query_id not in queries:
                queries[query_id] = query_obj

            role = "slicer" if visual.get("type") == "slicer" else "visual"
            query_roles.setdefault(query_id, set()).add(role)

            layout_info = visual.get("layout") or {}
            bbox = None
            if page_width and page_height and layout_info:
                x = layout_info.get("x", 0)
                y = layout_info.get("y", 0)
                w = layout_info.get("width", 0)
                h = layout_info.get("height", 0)
                try:
                    bbox = [
                        round((x / page_width) * 100, 2),
                        round((y / page_height) * 100, 2),
                        round((w / page_width) * 100, 2),
                        round((h / page_height) * 100, 2),
                    ]
                except Exception:
                    bbox = None

            visuals[v_id] = {
                "title": visual.get("title"),
                "type": visual.get("type"),
                "page_id": page_id,
                "query_id": query_id,
                "bbox": bbox,
            }

    for q_id, roles in query_roles.items():
        queries[q_id]["roles"] = sorted(roles)

    source_info = _infer_source_info(pbixray_data.get("power_query"))
    csv_contract = _build_csv_contract(pbixray_data.get("schema"), queries, pbixray_data.get("power_query"))

    if compact:
        csv_contract = _build_csv_contract(pbixray_data.get("schema"), queries, pbixray_data.get("power_query"))
        main_table = csv_contract.get("main_table")

        # Remove non-data visuals (images/shapes/textboxes with empty queries)
        skip_types = {"image", "shape", "textbox"}
        filtered_visuals = {}
        for v_id, visual in visuals.items():
            q = queries.get(visual.get("query_id"), {})
            if (
                visual.get("type") in skip_types
                and not q.get("groupby")
                and not q.get("measures")
                and not q.get("filters_count")
            ):
                continue
            filtered_visuals[v_id] = visual

        visuals = filtered_visuals
        for page_id, page in pages.items():
            page["visuals"] = [v for v in page.get("visuals", []) if v in visuals]

        referenced_queries = {visual.get("query_id") for visual in visuals.values()}
        queries = {qid: q for qid, q in queries.items() if qid in referenced_queries}

        measures_used = set()
        for q in queries.values():
            measures_used.update(q.get("measures", []))

        measures = [
            {
                "name": m.get("Name"),
                "depends_on": _extract_dax_dependencies(m.get("Expression")),
            }
            for m in (pbixray_data.get("dax_measures") or [])
            if m.get("Name") in measures_used
        ]

        calculated_columns = [
            {
                "name": c.get("ColumnName"),
                "table": c.get("TableName"),
                "depends_on": _extract_dax_dependencies(c.get("Expression")),
            }
            for c in (pbixray_data.get("dax_columns") or [])
            if c.get("TableName") == main_table
        ]

        relationships = [
            rel
            for rel in (pbixray_data.get("relationships") or [])
            if rel.get("ToTableName") and (
                rel.get("FromTableName") == main_table or rel.get("ToTableName") == main_table
            )
        ]

        manifest = {
            "summary": {
                "pages": len(pages),
                "visuals": len(visuals),
                "tables": _safe_len(pbixray_data.get("tables")),
            },
            "csv_contract": csv_contract,
            "dataset": {
                "tables": [main_table] if main_table else [],
                "schema": [
                    {"name": name, "type": dtype, "required": name in set(csv_contract.get("required_headers", []))}
                    for name, dtype in (csv_contract.get("type_map") or {}).items()
                ],
                "relationships": relationships,
                "measures": measures,
                "calculated_columns": calculated_columns,
            },
            "power_query": {
                "source_type": source_info.get("source_type"),
                "source_uri": source_info.get("source_uri"),
                "type_casts": source_info.get("type_casts"),
                "m_parameters": pbixray_data.get("m_parameters"),
            },
            "connections": connections,
            "queries": queries,
            "visuals": visuals,
            "pages": pages,
        }
    else:
        manifest = {
            "summary": {
                "pages": len(pages),
                "visuals": len(visuals),
                "tables": _safe_len(pbixray_data.get("tables")),
            },
            "csv_contract": csv_contract,
            "dataset": {
                "tables": pbixray_data.get("tables"),
                "schema": pbixray_data.get("schema"),
                "relationships": pbixray_data.get("relationships"),
                "measures": pbixray_data.get("dax_measures"),
                "calculated_columns": pbixray_data.get("dax_columns"),
                "calculated_tables": pbixray_data.get("dax_tables"),
                "rls": pbixray_data.get("rls"),
                "statistics": pbixray_data.get("statistics"),
            },
            "power_query": {
                "power_query": pbixray_data.get("power_query"),
                "m_parameters": pbixray_data.get("m_parameters"),
                "m_script": mashup.get("m_script") if include_raw else None,
            },
            "connections": connections,
            "queries": queries,
            "visuals": visuals,
            "pages": pages,
            "metadata": pbixray_data.get("metadata"),
            "model_size": pbixray_data.get("size"),
        }

    return _to_jsonable(manifest)


def build_brief(manifest: dict) -> str:
    lines = []
    summary = manifest.get("summary", {})
    lines.append("## Core Instructions")
    lines.append("- Use reusable React/TypeScript components; avoid per-visual bespoke code.")
    lines.append("- Keep code DRY; abstract shared chart/axis/legend logic.")
    lines.append("- Respect reported layout using bbox hints; preserve relative order and grouping.")
    lines.append("- Do not invent fields; use only the provided dataset/queries.")
    lines.append("- Use consistent sizing rules for filters and KPI cards; avoid uneven widths.")
    lines.append("- Align components to a simple grid; keep spacing uniform.")
    lines.append("")
    lines.append("## Filter Panel Rules")
    lines.append("- Group all slicers into one filter panel; keep a single label per filter.")
    lines.append("- Use consistent control height and width across filters.")
    lines.append("- If title is missing, label with the field name.")
    lines.append("")
    lines.append("## KPI Card Rules")
    lines.append("- Use a single reusable KPI card component.")
    lines.append("- Keep KPI card sizes consistent within a row.")
    lines.append("- If there are many KPIs, wrap to new rows rather than shrinking.")
    lines.append("")
    lines.append("## Summary")
    lines.append(
        f"pages={summary.get('pages')} visuals={summary.get('visuals')} tables={summary.get('tables')}"
    )

    csv_contract = manifest.get("csv_contract", {})
    required_headers = csv_contract.get("required_headers") or []
    lines.append("")
    lines.append("## CSV Contract")
    lines.append(f"required_headers({len(required_headers)}): {', '.join(required_headers)}")

    pages = manifest.get("pages", {})
    visuals = manifest.get("visuals", {})
    queries = manifest.get("queries", {})

    lines.append("")
    lines.append("## Pages")
    for page_id, page in pages.items():
        size = ""
        if page.get("width") and page.get("height"):
            size = f" {int(page.get('width'))}x{int(page.get('height'))}"
        lines.append(f"page: {page.get('name')} ({page_id}){size}")
        for v_id in page.get("visuals", []):
            visual = visuals.get(v_id, {})
            query = queries.get(visual.get("query_id"), {})
            fields = []
            if query.get("groupby"):
                fields.append(f"groupby={query.get('groupby')}")
            if query.get("measures"):
                fields.append(f"measures={query.get('measures')}")
            field_text = " ".join(fields)
            bbox = visual.get("bbox")
            bbox_text = f" bbox%={bbox}" if bbox else ""
            lines.append(f"- {visual.get('title')} [{visual.get('type')}] {field_text}{bbox_text}".strip())

    return "\n".join(lines)
