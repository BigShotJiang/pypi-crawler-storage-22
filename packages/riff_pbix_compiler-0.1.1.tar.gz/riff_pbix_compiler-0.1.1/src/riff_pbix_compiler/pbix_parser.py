import json
import zipfile
import logging
import io
import re

logger = logging.getLogger(__name__)


def apply_color_percent(hex_color, percent):
    try:
        hex_color = hex_color.lstrip("#")
        if len(hex_color) == 6:
            r, g, b = tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
        else:
            return f"#{hex_color}" if not hex_color.startswith("#") else hex_color

        if percent == 0:
            return f"#{hex_color}"

        if percent > 0:
            r = int(r + (255 - r) * percent)
            g = int(g + (255 - g) * percent)
            b = int(b + (255 - b) * percent)
        else:
            factor = 1 + percent
            r = int(r * factor)
            g = int(g * factor)
            b = int(b * factor)

        return f"#{r:02X}{g:02X}{b:02X}"
    except Exception:
        return f"#{hex_color}" if not hex_color.startswith("#") else hex_color


def resolve_color(expr, theme=None):
    if not expr:
        return None

    if "Literal" in expr:
        value = expr["Literal"].get("Value", "")
        if value.startswith("'") and value.endswith("'"):
            value = value[1:-1]
        return {"hex": value, "source": "Literal", "raw": expr}

    if "ThemeDataColor" in expr:
        tdc = expr["ThemeDataColor"]
        color_id = tdc.get("ColorId", 0)
        percent = tdc.get("Percent", 0)

        default_colors = theme.get("dataColors", []) if theme and "dataColors" in theme else [
            "#118DFF", "#12239E", "#E66C37", "#6B007B", "#E64483",
            "#7044E6", "#00A1C0", "#006E00", "#D3B700", "#C43628",
            "#F0F0F0", "#5F6B6D",
        ]

        if 0 <= color_id < len(default_colors):
            base_hex = default_colors[color_id]
        else:
            base_hex = "#000000"

        final_hex = apply_color_percent(base_hex, percent)
        return {"hex": final_hex, "source": "ThemeDataColor", "raw": expr}

    return {"hex": None, "source": "Unknown", "raw": expr}


def parse_transparency(expr, default=0):
    if not expr or "Literal" not in expr:
        return default

    val = expr["Literal"].get("Value", default)
    if isinstance(val, str):
        val = val.replace("D", "").replace("'", "")

    try:
        return float(val)
    except Exception:
        return default


def walk_find(obj, *keys):
    current = obj
    for key in keys:
        if isinstance(current, dict):
            current = current.get(key)
        elif isinstance(current, list) and isinstance(key, int):
            if 0 <= key < len(current):
                current = current[key]
            else:
                return None
        else:
            return None

        if current is None:
            return None

    return current


def get_visual_id(page_name, visual_name):
    return f"v:{page_name}::{visual_name}"


def extract_query_metadata(prototype_query):
    metadata = {
        "From": [],
        "Select": [],
        "Where": [],
        "OrderBy": [],
        "Raw": prototype_query,
    }

    if not prototype_query:
        return metadata

    def traverse(obj):
        if isinstance(obj, dict):
            if "Entity" in obj and isinstance(obj["Entity"], str):
                metadata["From"].append(obj["Entity"])

            if "From" in obj and isinstance(obj["From"], list):
                for item in obj["From"]:
                    if "Entity" in item:
                        metadata["From"].append(item["Entity"])

            if "Select" in obj and isinstance(obj["Select"], list):
                for item in obj["Select"]:
                    col_info = {}

                    if "Column" in item:
                        col_expr = item["Column"]
                        if "Property" in col_expr:
                            col_info["name"] = col_expr["Property"]
                            col_info["type"] = "column"

                    elif "Measure" in item:
                        meas_expr = item["Measure"]
                        if "Property" in meas_expr:
                            col_info["name"] = meas_expr["Property"]
                            col_info["type"] = "measure"

                    elif "Aggregation" in item:
                        agg = item["Aggregation"]
                        if "Expression" in agg and "Column" in agg["Expression"]:
                            col_info["name"] = agg["Expression"]["Column"].get("Property")
                            col_info["type"] = "column_agg"
                            col_info["func"] = agg.get("Function")

                    elif "HierarchyLevel" in item:
                        hl = item["HierarchyLevel"]
                        if "Expression" in hl and "Hierarchy" in hl["Expression"]:
                            h_expr = hl["Expression"]["Hierarchy"]
                            if "Expression" in h_expr and "PropertyVariationSource" in h_expr["Expression"]:
                                pvs = h_expr["Expression"]["PropertyVariationSource"]
                                col_info["name"] = pvs.get("Property")
                                col_info["type"] = "column_hierarchy"
                                col_info["inferred_type"] = "dateTime"

                    if col_info:
                        metadata["Select"].append(col_info)

            for key, value in obj.items():
                traverse(value)

        elif isinstance(obj, list):
            for item in obj:
                traverse(item)

    traverse(prototype_query)
    metadata["From"] = list(set(metadata["From"]))
    return metadata


def parse_report_layout(zip_file: zipfile.ZipFile):
    try:
        with zip_file.open("Report/Layout") as f:
            content = f.read()
            try:
                layout_json = json.loads(content.decode("utf-16-le"))
            except UnicodeDecodeError:
                layout_json = json.loads(content.decode("utf-8"))

            pages = []
            all_visuals_flat = []

            for section in layout_json.get("sections", []):
                page_name = section.get("displayName", section.get("name", "Unnamed Page"))
                page_id = section.get("name")

                page_width = section.get("width", 1280)
                page_height = section.get("height", 720)

                visuals = []

                for container in section.get("visualContainers", []):
                    try:
                        layout_info = {
                            "x": container.get("x", 0),
                            "y": container.get("y", 0),
                            "width": container.get("width", 0),
                            "height": container.get("height", 0),
                            "z": container.get("z", 0),
                            "tabOrder": container.get("tabOrder"),
                        }

                        config_str = container.get("config")
                        if config_str:
                            config = json.loads(config_str)
                            single_visual = config.get("singleVisual", {})
                            visual_type = single_visual.get("visualType", "unknown")
                            visual_name = config.get("name", "Unnamed Visual")
                            visual_id_stable = get_visual_id(page_id, visual_name)

                            title = "Untitled"
                            try:
                                vc_objects = single_visual.get("vcObjects", {})
                                title_obj = vc_objects.get("title", [])
                                if title_obj:
                                    title = (
                                        title_obj[0]
                                        .get("properties", {})
                                        .get("text", {})
                                        .get("expr", {})
                                        .get("Literal", {})
                                        .get("Value")
                                    )
                            except Exception:
                                pass

                            if not title or title == "Untitled":
                                try:
                                    objects = single_visual.get("objects", {})
                                    title_obj = objects.get("title", [])
                                    if title_obj:
                                        title = (
                                            title_obj[0]
                                            .get("properties", {})
                                            .get("text", {})
                                            .get("expr", {})
                                            .get("Literal", {})
                                            .get("Value")
                                        )
                                except Exception:
                                    pass

                            if not title:
                                title = "Untitled"

                            query_meta = {}
                            prototype_query = single_visual.get("prototypeQuery")
                            if prototype_query:
                                query_meta = extract_query_metadata(prototype_query)

                            filters = []
                            filter_json = config.get("filter")
                            if filter_json:
                                filters = filter_json

                            visual_obj = {
                                "id": visual_id_stable,
                                "name": visual_name,
                                "type": visual_type,
                                "title": title,
                                "query_metadata": query_meta,
                                "filters": filters,
                                "layout": layout_info,
                            }
                            visuals.append(visual_obj)
                            all_visuals_flat.append(visual_obj)

                    except Exception as e:
                        logger.warning(f"Failed to parse visual config: {e}")
                        continue

                pages.append({
                    "id": page_id,
                    "name": page_name,
                    "width": page_width,
                    "height": page_height,
                    "visuals": visuals,
                })

            return {
                "pages": pages,
                "all_visuals_flat": all_visuals_flat,
                "raw_summary": {
                    "page_count": len(pages),
                    "visual_count": len(all_visuals_flat),
                },
            }

    except KeyError:
        return {"error": "Report/Layout file not found in archive"}
    except json.JSONDecodeError:
        return {"error": "Failed to decode Report/Layout JSON"}
    except Exception as e:
        logger.error(f"Error parsing Report/Layout: {e}")
        return {"error": str(e)}


def parse_mashup(zip_file: zipfile.ZipFile):
    try:
        if "DataMashup" not in zip_file.namelist():
            return {"error": "DataMashup not found"}

        with zip_file.open("DataMashup") as f:
            mashup_bytes = f.read()

        zip_signature = b"\x50\x4B\x03\x04"
        zip_offset = mashup_bytes.find(zip_signature)

        if zip_offset == -1:
            return {"error": "Inner ZIP not found in DataMashup"}

        inner_zip_bytes = mashup_bytes[zip_offset:]

        try:
            with zipfile.ZipFile(io.BytesIO(inner_zip_bytes)) as inner_zip:
                m_script = None
                for name in inner_zip.namelist():
                    if name.endswith("Section1.m"):
                        with inner_zip.open(name) as m_file:
                            m_script = m_file.read().decode("utf-8")
                        break

                if m_script:
                    return {"m_script": m_script}
                return {"error": "Section1.m not found in DataMashup"}

        except zipfile.BadZipFile:
            return {"error": "Failed to open inner ZIP in DataMashup"}

    except Exception as e:
        logger.error(f"Error parsing DataMashup: {e}")
        return {"error": str(e)}


def parse_connections(zip_file: zipfile.ZipFile):
    try:
        if "Connections" not in zip_file.namelist():
            return None

        with zip_file.open("Connections") as f:
            content = f.read()
            try:
                connections_json = json.loads(content.decode("utf-8-sig"))
                return connections_json
            except json.JSONDecodeError:
                return {"error": "Failed to decode Connections JSON"}

    except Exception as e:
        logger.error(f"Error parsing Connections: {e}")
        return {"error": str(e)}
