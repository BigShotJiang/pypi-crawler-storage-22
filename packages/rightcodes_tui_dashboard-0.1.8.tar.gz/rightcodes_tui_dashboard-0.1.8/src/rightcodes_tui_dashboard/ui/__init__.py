"""Textual TUI（MVP）。"""

