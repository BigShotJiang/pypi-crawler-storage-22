"""
Rilerary - A Python library for Riley persona management
"""

from .loader import PersonaLoader, load_persona, get_available_personas, get_persona_info
from .utils import format_response, build_system_prompt
from .chat import Rile

__version__ = "0.2.3"
__author__ = "Namai Chandra"
__all__ = [
    "Rile",
    "PersonaLoader",
    "load_persona",
    "get_available_personas",
    "get_persona_info",
    "format_response",
    "build_system_prompt"
]
