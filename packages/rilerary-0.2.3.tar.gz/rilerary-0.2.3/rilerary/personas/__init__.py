"""
Built-in Riley personas
"""

# This file makes the personas directory a Python package
