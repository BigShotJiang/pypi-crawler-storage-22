"""
Utility functions for working with personas
"""

from typing import Dict, List


def format_response(response: str, persona_emoji: str = "") -> str:
    """
    Format a response with persona styling
    
    Args:
        response: The response text
        persona_emoji: Optional emoji to prepend
        
    Returns:
        Formatted response string
    """
    if persona_emoji:
        return f"{persona_emoji} {response}"
    return response


def get_prompt_template(persona_data: Dict) -> str:
    """
    Extract the prompt template from persona data
    
    Args:
        persona_data: Dictionary containing persona information
        
    Returns:
        Prompt template string
    """
    return persona_data.get("prompt_template", "")


def get_specialties(persona_data: Dict) -> List[str]:
    """
    Get list of persona specialties
    
    Args:
        persona_data: Dictionary containing persona information
        
    Returns:
        List of specialty strings
    """
    return persona_data.get("specialties", [])


def get_response_style(persona_data: Dict) -> str:
    """
    Get the response style guidelines
    
    Args:
        persona_data: Dictionary containing persona information
        
    Returns:
        Response style string
    """
    return persona_data.get("response_style", "")


def build_system_prompt(persona_data: Dict, additional_context: str = "") -> str:
    """
    Build a complete system prompt from persona data
    
    Args:
        persona_data: Dictionary containing persona information
        additional_context: Optional additional context to append
        
    Returns:
        Complete system prompt string
    """
    prompt_parts = []
    
    # Add prompt template
    if "prompt_template" in persona_data:
        prompt_parts.append(persona_data["prompt_template"])
    
    # Add response style
    if "response_style" in persona_data:
        prompt_parts.append(f"\n\nResponse Style: {persona_data['response_style']}")
    
    # Add specialties
    if "specialties" in persona_data:
        specialties = "\n".join(f"- {s}" for s in persona_data["specialties"])
        prompt_parts.append(f"\n\nSpecialties:\n{specialties}")
    
    # Add additional context
    if additional_context:
        prompt_parts.append(f"\n\n{additional_context}")
    
    return "\n".join(prompt_parts)


def validate_persona(persona_data: Dict) -> tuple[bool, List[str]]:
    """
    Validate that a persona has required fields
    
    Args:
        persona_data: Dictionary containing persona information
        
    Returns:
        Tuple of (is_valid, list_of_errors)
    """
    required_fields = ["persona_name", "description", "prompt_template"]
    errors = []
    
    for field in required_fields:
        if field not in persona_data:
            errors.append(f"Missing required field: {field}")
    
    return len(errors) == 0, errors
