from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
readme_file = Path(__file__).parent / "README.md"
long_description = ""
if readme_file.exists():
    long_description = readme_file.read_text(encoding="utf-8")

setup(
    name="rilerary",
    version="0.2.3",
    author="Namai Chandra",
    author_email="namaimailm@hmail.com",
    description="A Python library for managing Rile AI personas with a focus on SDG goals oriented for sustainable living",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/NamaiBest/rilerary",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        # No external dependencies for basic persona loading
    ],
    extras_require={
        "gemini": ["google-generativeai>=0.3.0"],
    },
    include_package_data=True,
    package_data={
        "rilerary": ["personas/*.json"],
    },
    keywords="ai persona chatbot riley assistant",
    project_urls={
        "Bug Reports": "https://github.com/NamaiBest/rilerary/issues",
        "Source": "https://github.com/NamaiBest/rilerary",
    },
)
