# This copy of Barion is bundled with RionID.
# Original Repository @Github: https://github.com/xaratustrah/barion
# License: GPL-3.0

  