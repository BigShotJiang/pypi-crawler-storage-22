# This copy of lisereader is bundled with RionID.
# Original Repository @Github: https://github.com/gwgwhc/lisereader
# License: GPL-3.0