# riopy/keyboards.py
from typing import List
from .models import Button, ButtonBehavior, Keyboard, KeyboardRow

def create_simple_button(button_id: str, text: str) -> Button:
    return Button(id=button_id, type=ButtonBehavior.SIMPLE, button_text=text)

def create_keyboard(rows: List[List[Button]], resize=True, one_time=False) -> Keyboard:
    keyboard_rows = [KeyboardRow(buttons=row) for row in rows]
    return Keyboard(rows=keyboard_rows, resize_keyboard=resize, one_time_keyboard=one_time)