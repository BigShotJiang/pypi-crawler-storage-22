# README.md
# Riopy

Python library for Rubika bot API.

## Installation
```bash
pip install riopy