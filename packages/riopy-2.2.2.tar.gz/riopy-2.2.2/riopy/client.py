import requests
from typing import List, Optional, Union
from .enums import *
from .models import *
from .keyboards import *

class RiopyClient:
    BASE_URL = "https://botapi.rubika.ir/v3/{token}/{method}"

    def __init__(self, token: str):
        self.token = token
        self.session = requests.Session()

    def _request(self, method: str, data: dict = None) -> dict:
        url = self.BASE_URL.format(token=self.token, method=method)
        headers = {'Content-Type': 'application/json'}
        response = self.session.post(url, headers=headers, json=data)
        response.raise_for_status()
        result = response.json()
        if result.get("status") == "OK":
            return result.get("data", {})
        return result

    def get_bot_info(self) -> BotInfo:
        result = self._request("getMe")
        return self._parse_bot(result['bot'])

    def send_message(
        self,
        chat_id: str,
        text: str,
        chat_keyboard: Optional[Keyboard] = None,
        inline_keyboard: Optional[Keyboard] = None,
        disable_notification: bool = False,
        reply_to_message_id: Optional[str] = None,
        chat_keyboard_action: ChatKeypadAction = ChatKeypadAction.NONE,
    ) -> str:
        data = {
            "chat_id": chat_id,
            "text": text,
            "disable_notification": disable_notification,
        }
        if reply_to_message_id:
            data["reply_to_message_id"] = reply_to_message_id
        if chat_keyboard:
            data["chat_keypad"] = self._keyboard_to_dict(chat_keyboard)
            data["chat_keypad_type"] = chat_keyboard_action.value
        if inline_keyboard:
            data["inline_keypad"] = self._keyboard_to_dict(inline_keyboard)
        result = self._request("sendMessage", data)
        return result['message_id']

    def send_poll(
        self,
        chat_id: str,
        question: str,
        options: List[str],
        chat_keyboard: Optional[Keyboard] = None,
        inline_keyboard: Optional[Keyboard] = None,
        disable_notification: bool = False,
        reply_to_message_id: Optional[str] = None,
        chat_keyboard_action: ChatKeypadAction = ChatKeypadAction.NONE,
    ) -> str:
        data = {
            "chat_id": chat_id,
            "question": question,
            "options": options,
            "disable_notification": disable_notification,
        }
        if reply_to_message_id:
            data["reply_to_message_id"] = reply_to_message_id
        if chat_keyboard:
            data["chat_keypad"] = self._keyboard_to_dict(chat_keyboard)
            data["chat_keypad_type"] = chat_keyboard_action.value
        if inline_keyboard:
            data["inline_keypad"] = self._keyboard_to_dict(inline_keyboard)
        result = self._request("sendPoll", data)
        return result['message_id']

    def send_location(
        self,
        chat_id: str,
        latitude: str,
        longitude: str,
        chat_keyboard: Optional[Keyboard] = None,
        inline_keyboard: Optional[Keyboard] = None,
        disable_notification: bool = False,
        reply_to_message_id: Optional[str] = None,
        chat_keyboard_action: ChatKeypadAction = ChatKeypadAction.NONE,
    ) -> str:
        data = {
            "chat_id": chat_id,
            "latitude": latitude,
            "longitude": longitude,
            "disable_notification": disable_notification,
        }
        if reply_to_message_id:
            data["reply_to_message_id"] = reply_to_message_id
        if chat_keyboard:
            data["chat_keypad"] = self._keyboard_to_dict(chat_keyboard)
            data["chat_keypad_type"] = chat_keyboard_action.value
        if inline_keyboard:
            data["inline_keypad"] = self._keyboard_to_dict(inline_keyboard)
        result = self._request("sendLocation", data)
        return result['message_id']

    def send_contact(
        self,
        chat_id: str,
        first_name: str,
        phone_number: str,
        last_name: Optional[str] = None,
        chat_keyboard: Optional[Keyboard] = None,
        inline_keyboard: Optional[Keyboard] = None,
        disable_notification: bool = False,
        reply_to_message_id: Optional[str] = None,
        chat_keyboard_action: ChatKeypadAction = ChatKeypadAction.NONE,
    ) -> str:
        data = {
            "chat_id": chat_id,
            "first_name": first_name,
            "phone_number": phone_number,
            "disable_notification": disable_notification,
        }
        if last_name:
            data["last_name"] = last_name
        if reply_to_message_id:
            data["reply_to_message_id"] = reply_to_message_id
        if chat_keyboard:
            data["chat_keypad"] = self._keyboard_to_dict(chat_keyboard)
            data["chat_keypad_type"] = chat_keyboard_action.value
        if inline_keyboard:
            data["inline_keypad"] = self._keyboard_to_dict(inline_keyboard)
        result = self._request("sendContact", data)
        return result['message_id']

    def get_chat(self, chat_id: str) -> Chat:
        data = {"chat_id": chat_id}
        result = self._request("getChat", data)
        return self._parse_chat(result['chat'])

    def get_updates(self, offset_id: Optional[str] = None, limit: int = 100) -> List[UpdateEvent]:
        data = {"limit": limit}
        if offset_id:
            data["offset_id"] = offset_id
        result = self._request("getUpdates", data)
        updates = []
        for upd in result.get('updates', []):
            updates.append(self._parse_update(upd))
        return updates

    def forward_message(
        self,
        from_chat_id: str,
        message_id: str,
        to_chat_id: str,
        disable_notification: bool = False,
    ) -> str:
        data = {
            "from_chat_id": from_chat_id,
            "message_id": message_id,
            "to_chat_id": to_chat_id,
            "disable_notification": disable_notification,
        }
        result = self._request("forwardMessage", data)
        return result['new_message_id']

    def edit_message_text(
        self,
        chat_id: str,
        message_id: str,
        text: str,
    ) -> None:
        data = {
            "chat_id": chat_id,
            "message_id": message_id,
            "text": text,
        }
        self._request("editMessageText", data)

    def edit_inline_keyboard(
        self,
        chat_id: str,
        message_id: str,
        inline_keyboard: Keyboard,
    ) -> None:
        data = {
            "chat_id": chat_id,
            "message_id": message_id,
            "inline_keypad": self._keyboard_to_dict(inline_keyboard),
        }
        self._request("editMessageKeypad", data)

    def delete_message(self, chat_id: str, message_id: str) -> None:
        data = {
            "chat_id": chat_id,
            "message_id": message_id,
        }
        self._request("deleteMessage", data)

    def set_commands(self, commands: List[BotCommand]) -> None:
        data = {
            "bot_commands": [
                {"command": cmd.command, "description": cmd.description}
                for cmd in commands
            ]
        }
        self._request("setCommands", data)

    def set_webhook(
        self,
        url: str,
        webhook_type: WebhookType = WebhookType.RECEIVE_UPDATE,
    ) -> None:
        data = {
            "url": url,
            "type": webhook_type.value,
        }
        self._request("updateBotEndpoints", data)

    def edit_chat_keyboard(
        self,
        chat_id: str,
        keyboard: Optional[Keyboard] = None,
        action: ChatKeypadAction = ChatKeypadAction.NEW,
    ) -> None:
        data = {
            "chat_id": chat_id,
            "chat_keypad_type": action.value,
        }
        if keyboard and action == ChatKeypadAction.NEW:
            data["chat_keypad"] = self._keyboard_to_dict(keyboard)
        self._request("editChatKeypad", data)

    def get_file(self, file_id: str) -> str:
        data = {"file_id": file_id}
        result = self._request("getFile", data)
        return result['download_url']

    def send_file(
        self,
        chat_id: str,
        file_id: str,
        text: Optional[str] = None,
        chat_keyboard: Optional[Keyboard] = None,
        inline_keyboard: Optional[Keyboard] = None,
        disable_notification: bool = False,
        reply_to_message_id: Optional[str] = None,
        chat_keyboard_action: ChatKeypadAction = ChatKeypadAction.NONE,
    ) -> str:
        data = {
            "chat_id": chat_id,
            "file_id": file_id,
            "disable_notification": disable_notification,
        }
        if text:
            data["text"] = text
        if reply_to_message_id:
            data["reply_to_message_id"] = reply_to_message_id
        if chat_keyboard:
            data["chat_keypad"] = self._keyboard_to_dict(chat_keyboard)
            data["chat_keypad_type"] = chat_keyboard_action.value
        if inline_keyboard:
            data["inline_keypad"] = self._keyboard_to_dict(inline_keyboard)
        result = self._request("sendFile", data)
        return result['message_id']

    def request_upload(self, file_type: FileKind) -> str:
        data = {"type": file_type.value}
        result = self._request("requestSendFile", data)
        return result['upload_url']

    def upload_file(self, upload_url: str, file_path: str) -> str:
        with open(file_path, 'rb') as f:
            files = {'file': f}
            response = requests.post(upload_url, files=files)
        response.raise_for_status()
        return response.json()['file_id']

    def ban_member(self, chat_id: str, user_id: str) -> None:
        data = {
            "chat_id": chat_id,
            "user_id": user_id,
        }
        self._request("banChatMember", data)

    def unban_member(self, chat_id: str, user_id: str) -> None:
        data = {
            "chat_id": chat_id,
            "user_id": user_id,
        }
        self._request("unbanChatMember", data)

    def _keyboard_to_dict(self, keyboard: Keyboard) -> dict:
        rows = []
        for row in keyboard.rows:
            buttons = []
            for btn in row.buttons:
                btn_dict = {
                    "id": btn.id,
                    "type": btn.type.value,
                    "button_text": btn.button_text,
                }
                if btn.button_selection:
                    sel = btn.button_selection
                    btn_dict["button_selection"] = {
                        "selection_id": sel.selection_id,
                        "search_type": sel.search_type.value,
                        "get_type": sel.get_type.value,
                        "items": [
                            {
                                "text": item.text,
                                "image_url": item.image_url,
                                "type": item.type.value,
                            }
                            for item in sel.items
                        ],
                        "is_multi_selection": sel.is_multi_selection,
                        "columns_count": sel.columns_count,
                    }
                    if sel.title:
                        btn_dict["button_selection"]["title"] = sel.title
                if btn.button_calendar:
                    cal = btn.button_calendar
                    btn_dict["button_calendar"] = {
                        "type": cal.type.value,
                    }
                    if cal.default_value:
                        btn_dict["button_calendar"]["default_value"] = cal.default_value
                    if cal.min_year:
                        btn_dict["button_calendar"]["min_year"] = cal.min_year
                    if cal.max_year:
                        btn_dict["button_calendar"]["max_year"] = cal.max_year
                    if cal.title:
                        btn_dict["button_calendar"]["title"] = cal.title
                if btn.button_number_picker:
                    np = btn.button_number_picker
                    btn_dict["button_number_picker"] = {
                        "min_value": np.min_value,
                        "max_value": np.max_value,
                    }
                    if np.default_value:
                        btn_dict["button_number_picker"]["default_value"] = np.default_value
                    if np.title:
                        btn_dict["button_number_picker"]["title"] = np.title
                if btn.button_string_picker:
                    sp = btn.button_string_picker
                    btn_dict["button_string_picker"] = {
                        "items": sp.items,
                    }
                    if sp.default_value:
                        btn_dict["button_string_picker"]["default_value"] = sp.default_value
                    if sp.title:
                        btn_dict["button_string_picker"]["title"] = sp.title
                if btn.button_location:
                    loc = btn.button_location
                    btn_dict["button_location"] = {
                        "type": loc.type.value,
                    }
                    if loc.default_pointer_location:
                        btn_dict["button_location"]["default_pointer_location"] = {
                            "latitude": loc.default_pointer_location.latitude,
                            "longitude": loc.default_pointer_location.longitude,
                        }
                    if loc.default_map_location:
                        btn_dict["button_location"]["default_map_location"] = {
                            "latitude": loc.default_map_location.latitude,
                            "longitude": loc.default_map_location.longitude,
                        }
                    if loc.title:
                        btn_dict["button_location"]["title"] = loc.title
                if btn.button_textbox:
                    tb = btn.button_textbox
                    btn_dict["button_textbox"] = {
                        "type_line": tb.type_line.value,
                        "type_keypad": tb.type_keypad.value,
                    }
                    if tb.place_holder:
                        btn_dict["button_textbox"]["place_holder"] = tb.place_holder
                    if tb.title:
                        btn_dict["button_textbox"]["title"] = tb.title
                    if tb.default_value:
                        btn_dict["button_textbox"]["default_value"] = tb.default_value
                buttons.append(btn_dict)
            rows.append({"buttons": buttons})
        result = {
            "rows": rows,
            "resize_keyboard": keyboard.resize_keyboard,
            "one_time_keyboard": keyboard.one_time_keyboard,
        }
        return result

    def _parse_bot(self, data: dict) -> BotInfo:
        return BotInfo(
            bot_id=data['bot_id'],
            bot_title=data['bot_title'],
            avatar=File(**data['avatar']) if 'avatar' in data else None,
            description=data.get('description'),
            username=data.get('username'),
            start_message=data.get('start_message'),
            share_url=data.get('share_url'),
        )

    def _parse_chat(self, data: dict) -> Chat:
        return Chat(
            chat_id=data['chat_id'],
            chat_type=ChatKind(data['chat_type']),
            user_id=data.get('user_id'),
            first_name=data.get('first_name'),
            last_name=data.get('last_name'),
            title=data.get('title'),
            username=data.get('username'),
        )

    def _parse_update(self, data: dict) -> UpdateEvent:
        upd = UpdateEvent(
            type=UpdateKind(data['type']),
            chat_id=data['chat_id'],
        )
        if 'new_message' in data:
            upd.new_message = self._parse_message(data['new_message'])
        if 'updated_message' in data:
            upd.updated_message = self._parse_message(data['updated_message'])
        if 'removed_message_id' in data:
            upd.removed_message_id = data['removed_message_id']
        return upd

    def _parse_message(self, data: dict) -> Message:
        msg = Message(
            message_id=data['message_id'],
            text=data.get('text'),
            time=data.get('time'),
            is_edited=data.get('is_edited', False),
            sender_type=MessageSender(data['sender_type']) if 'sender_type' in data else None,
            sender_id=data.get('sender_id'),
            reply_to_message_id=data.get('reply_to_message_id'),
            forwarded_no_link=data.get('forwarded_no_link'),
        )
        if 'aux_data' in data:
            msg.aux_data = AuxData(
                start_id=data['aux_data'].get('start_id'),
                button_id=data['aux_data'].get('button_id'),
            )
        if 'file' in data:
            msg.file = File(**data['file'])
        if 'forwarded_from' in data:
            f = data['forwarded_from']
            msg.forwarded_from = ForwardInfo(
                type_from=ForwardKind(f['type_from']),
                message_id=f['message_id'],
                from_chat_id=f['from_chat_id'],
                from_sender_id=f['from_sender_id'],
            )
        if 'location' in data:
            msg.location = Location(
                latitude=data['location']['latitude'],
                longitude=data['location']['longitude'],
            )
        if 'sticker' in data:
            s = data['sticker']
            msg.sticker = Sticker(
                sticker_id=s['sticker_id'],
                file=File(**s['file']),
                emoji_character=s['emoji_character'],
            )
        if 'contact_message' in data:
            c = data['contact_message']
            msg.contact_message = ContactMessage(
                phone_number=c['phone_number'],
                first_name=c['first_name'],
                last_name=c.get('last_name'),
            )
        if 'poll' in data:
            p = data['poll']
            ps = p['poll_status']
            msg.poll = Poll(
                question=p['question'],
                options=p['options'],
                poll_status=PollStatus(
                    state=PollState(ps['state']),
                    selection_index=ps.get('selection_index', -1),
                    percent_vote_options=ps.get('percent_vote_options', []),
                    total_vote=ps.get('total_vote', 0),
                    show_total_votes=ps.get('show_total_votes', False),
                )
            )
        return msg

    @staticmethod
    def parse_webhook_update(body: dict) -> Union[UpdateEvent, InlineCallback, None]:
        if 'update' in body:
            upd_data = body['update']
            update = UpdateEvent(
                type=UpdateKind(upd_data['type']),
                chat_id=upd_data['chat_id'],
            )
            if 'new_message' in upd_data:
                d = upd_data['new_message']
                update.new_message = Message(
                    message_id=d['message_id'],
                    text=d.get('text'),
                    time=d.get('time'),
                    is_edited=d.get('is_edited', False),
                    sender_type=MessageSender(d['sender_type']) if 'sender_type' in d else None,
                    sender_id=d.get('sender_id'),
                    aux_data=AuxData(
                        start_id=d.get('aux_data', {}).get('start_id'),
                        button_id=d.get('aux_data', {}).get('button_id'),
                    ) if 'aux_data' in d else None,
                )
            return update
        elif 'inline_message' in body:
            inline = body['inline_message']
            callback = InlineCallback(
                sender_id=inline['sender_id'],
                text=inline.get('text'),
                message_id=inline['message_id'],
                chat_id=inline['chat_id'],
                aux_data=AuxData(
                    start_id=inline.get('aux_data', {}).get('start_id'),
                    button_id=inline.get('aux_data', {}).get('button_id'),
                ) if 'aux_data' in inline else None,
            )
            if 'file' in inline:
                callback.file = File(**inline['file'])
            if 'location' in inline:
                callback.location = Location(
                    latitude=inline['location']['latitude'],
                    longitude=inline['location']['longitude'],
                )
            return callback
        return None