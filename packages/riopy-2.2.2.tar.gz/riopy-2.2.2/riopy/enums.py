from enum import Enum

class ChatKind(Enum):
    USER = "User"
    BOT = "Bot"
    GROUP = "Group"
    CHANNEL = "Channel"

class FileKind(Enum):
    FILE = "File"
    IMAGE = "Image"
    VOICE = "Voice"
    VIDEO = "Video"
    MUSIC = "Music"
    GIF = "Gif"

class ForwardKind(Enum):
    USER = "User"
    CHANNEL = "Channel"
    BOT = "Bot"

class PollState(Enum):
    OPEN = "Open"
    CLOSED = "Closed"

class ButtonDisplay(Enum):
    TEXT_ONLY = "TextOnly"
    TEXT_IMG_THUMB = "TextImgThu"
    TEXT_IMG_BIG = "TextImgBig"

class SelectionSearch(Enum):
    NONE = "None"
    LOCAL = "Local"
    API = "Api"

class SelectionFetch(Enum):
    LOCAL = "Local"
    API = "Api"

class CalendarType(Enum):
    PERSIAN = "DatePersian"
    GREGORIAN = "DateGregorian"

class TextboxKeypad(Enum):
    STRING = "String"
    NUMBER = "Number"

class TextboxLines(Enum):
    SINGLE = "SingleLine"
    MULTI = "MultiLine"

class LocationInteraction(Enum):
    PICKER = "Picker"
    VIEW = "View"

class MessageSender(Enum):
    USER = "User"
    BOT = "Bot"

class UpdateKind(Enum):
    MESSAGE_EDITED = "UpdatedMessage"
    NEW_MESSAGE = "NewMessage"
    MESSAGE_DELETED = "RemovedMessage"
    BOT_STARTED = "StartedBot"
    BOT_STOPPED = "StoppedBot"

class ChatKeypadAction(Enum):
    NONE = "None"
    NEW = "New"
    REMOVE = "Remove"

class WebhookType(Enum):
    RECEIVE_UPDATE = "ReceiveUpdate"
    RECEIVE_INLINE = "ReceiveInlineMessage"
    RECEIVE_QUERY = "ReceiveQuery"
    GET_SELECTION = "GetSelectionItem"
    SEARCH_SELECTIONS = "SearchSelectionItems"

class ButtonBehavior(Enum):
    SIMPLE = "Simple"
    SELECTION = "Selection"
    CALENDAR = "Calendar"
    NUMBER_PICKER = "NumberPicker"
    STRING_PICKER = "StringPicker"
    LOCATION = "Location"
    CAMERA_IMAGE = "CameraImage"
    CAMERA_VIDEO = "CameraVideo"
    GALLERY_IMAGE = "GalleryImage"
    GALLERY_VIDEO = "GalleryVideo"
    FILE = "File"
    AUDIO = "Audio"
    RECORD_AUDIO = "RecordAudio"
    TEXTBOX = "Textbox"
    LINK = "Link"
    ASK_PHONE = "AskMyPhoneNumber"
    ASK_LOCATION = "AskMyLocation"
    BARCODE = "Barcode"