from dataclasses import dataclass, field
from typing import List, Optional
from .enums import *

@dataclass
class File:
    file_id: str
    file_name: str
    size: str

@dataclass
class Location:
    latitude: str
    longitude: str

@dataclass
class ForwardInfo:
    type_from: ForwardKind
    message_id: str
    from_chat_id: str
    from_sender_id: str

@dataclass
class ContactMessage:
    phone_number: str
    first_name: str
    last_name: Optional[str] = None

@dataclass
class PollStatus:
    state: PollState
    selection_index: int = -1
    percent_vote_options: List[int] = field(default_factory=list)
    total_vote: int = 0
    show_total_votes: bool = False

@dataclass
class Poll:
    question: str
    options: List[str]
    poll_status: PollStatus

@dataclass
class Sticker:
    sticker_id: str
    file: File
    emoji_character: str

@dataclass
class AuxData:
    start_id: Optional[str] = None
    button_id: Optional[str] = None

@dataclass
class ButtonSelectionItem:
    text: str
    image_url: Optional[str] = None
    type: ButtonDisplay = ButtonDisplay.TEXT_ONLY

@dataclass
class ButtonSelection:
    selection_id: str
    search_type: SelectionSearch = SelectionSearch.NONE
    get_type: SelectionFetch = SelectionFetch.LOCAL
    items: List[ButtonSelectionItem] = field(default_factory=list)
    is_multi_selection: bool = False
    columns_count: str = "1"
    title: Optional[str] = None

@dataclass
class ButtonCalendar:
    default_value: Optional[str] = None
    type: CalendarType = CalendarType.PERSIAN
    min_year: Optional[str] = None
    max_year: Optional[str] = None
    title: Optional[str] = None

@dataclass
class ButtonNumberPicker:
    min_value: str
    max_value: str
    default_value: Optional[str] = None
    title: Optional[str] = None

@dataclass
class ButtonStringPicker:
    items: List[str]
    default_value: Optional[str] = None
    title: Optional[str] = None

@dataclass
class ButtonTextbox:
    type_line: TextboxLines = TextboxLines.SINGLE
    type_keypad: TextboxKeypad = TextboxKeypad.STRING
    place_holder: Optional[str] = None
    title: Optional[str] = None
    default_value: Optional[str] = None

@dataclass
class ButtonLocation:
    default_pointer_location: Optional[Location] = None
    default_map_location: Optional[Location] = None
    type: LocationInteraction = LocationInteraction.PICKER
    title: Optional[str] = None

@dataclass
class Button:
    id: str
    type: ButtonBehavior
    button_text: str
    button_selection: Optional[ButtonSelection] = None
    button_calendar: Optional[ButtonCalendar] = None
    button_number_picker: Optional[ButtonNumberPicker] = None
    button_string_picker: Optional[ButtonStringPicker] = None
    button_location: Optional[ButtonLocation] = None
    button_textbox: Optional[ButtonTextbox] = None

@dataclass
class KeyboardRow:
    buttons: List[Button]

@dataclass
class Keyboard:
    rows: List[KeyboardRow]
    resize_keyboard: bool = True
    one_time_keyboard: bool = False

@dataclass
class Message:
    message_id: str
    text: Optional[str] = None
    time: Optional[int] = None
    is_edited: bool = False
    sender_type: Optional[MessageSender] = None
    sender_id: Optional[str] = None
    aux_data: Optional[AuxData] = None
    file: Optional[File] = None
    reply_to_message_id: Optional[str] = None
    forwarded_from: Optional[ForwardInfo] = None
    forwarded_no_link: Optional[str] = None
    location: Optional[Location] = None
    sticker: Optional[Sticker] = None
    contact_message: Optional[ContactMessage] = None
    poll: Optional[Poll] = None

@dataclass
class UpdateEvent:
    type: UpdateKind
    chat_id: str
    new_message: Optional[Message] = None
    updated_message: Optional[Message] = None
    removed_message_id: Optional[str] = None

@dataclass
class InlineCallback:
    sender_id: str
    text: Optional[str] = None
    file: Optional[File] = None
    location: Optional[Location] = None
    aux_data: Optional[AuxData] = None
    message_id: str = None
    chat_id: str = None

@dataclass
class Chat:
    chat_id: str
    chat_type: ChatKind
    user_id: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    title: Optional[str] = None
    username: Optional[str] = None

@dataclass
class BotInfo:
    bot_id: str
    bot_title: str
    avatar: Optional[File] = None
    description: Optional[str] = None
    username: Optional[str] = None
    start_message: Optional[str] = None
    share_url: Optional[str] = None

@dataclass
class BotCommand:
    command: str
    description: str

@dataclass
class MessageTextChange:
    message_id: str
    text: str

@dataclass
class MessageKeypadChange:
    message_id: str
    inline_keypad: Keyboard