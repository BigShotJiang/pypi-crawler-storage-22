from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="riopy",
    version="3.2.0",
    author="محمد لطیفی پور",
    author_email="your-email@example.com",  # ایمیل خود را وارد کنید
    description="کتابخانه Python برای ساخت بات در پیام‌رسان روبیکا",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/riopy",  # آدرس مخزن GitHub
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.25.0",
    ],
)