import requests
from typing import Optional, List, Dict, Any, Callable, Tuple, Union
from .types import (
    Update, Bot as BotInfo, Chat, Message,
    BotCommand, UpdateEndpointTypeEnum, ChatKeypadTypeEnum,
    FileTypeEnum, InlineMessage, Keyboard, File,
    _str_to_enum, UpdateTypeEnum, MessageSenderEnum,
    ForwardedFromEnum, PollStatusEnum, Location, ContactMessage,
    Poll, AuxData
)
from .exceptions import APIError, InvalidTokenError
from .polling import Polling
from .keyboard import build_keyboard  # تابع کمکی برای ساخت کیپد (اختیاری)


class Bot:
    def __init__(self, token: str):
        self.token = token
        self.base_url = f"https://botapi.rubika.ir/v3/{token}"
        self._session = requests.Session()
        self._handlers = []          # برای پیام‌های جدید (پولینگ)
        self._inline_handlers = []    # برای کلیک روی دکمه‌های اینلاین (وب‌هوک)

    def _request(self, method: str, data: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.base_url}/{method}"
        response = self._session.post(url, json=data)
        if response.status_code != 200:
            raise APIError(response.status_code, response.text)
        result = response.json()
        if result.get("status") != "OK":
            raise APIError(response.status_code, result.get("status_det", "Unknown error"))
        return result.get("data", {})

    # ==================== Core Methods ====================
    def get_me(self) -> BotInfo:
        """Get bot information."""
        data = self._request("getMe", {})
        return BotInfo.from_dict(data.get("bot", {}))

    def send_message(
        self,
        chat_id: str,
        text: str,
        disable_notification: bool = False,
        reply_to_message_id: Optional[str] = None,
        chat_keyboard: Optional[Union[Dict, Keyboard]] = None,
        chat_keypad_type: Optional[ChatKeypadTypeEnum] = None,
        inline_keyboard: Optional[Union[Dict, Keyboard]] = None,
    ) -> str:
        """Send a text message."""
        payload = {
            "chat_id": chat_id,
            "text": text,
            "disable_notification": disable_notification,
        }
        if reply_to_message_id:
            payload["reply_to_message_id"] = reply_to_message_id
        if chat_keyboard:
            # اگر از کلاس Keyboard استفاده شده، به دیکشنری تبدیل کن
            if hasattr(chat_keyboard, 'to_dict'):
                payload["chat_keypad"] = chat_keyboard.to_dict()
            else:
                payload["chat_keypad"] = chat_keyboard
        if chat_keypad_type:
            payload["chat_keypad_type"] = chat_keypad_type.value
        if inline_keyboard:
            if hasattr(inline_keyboard, 'to_dict'):
                payload["inline_keypad"] = inline_keyboard.to_dict()
            else:
                payload["inline_keypad"] = inline_keyboard
        data = self._request("sendMessage", payload)
        return data.get("message_id")

    def send_poll(
        self,
        chat_id: str,
        question: str,
        options: List[str],
        disable_notification: bool = False,
        reply_to_message_id: Optional[str] = None,
    ) -> str:
        """Send a poll."""
        payload = {
            "chat_id": chat_id,
            "question": question,
            "options": options,
            "disable_notification": disable_notification,
        }
        if reply_to_message_id:
            payload["reply_to_message_id"] = reply_to_message_id
        data = self._request("sendPoll", payload)
        return data.get("message_id")

    def send_location(
        self,
        chat_id: str,
        latitude: str,
        longitude: str,
        disable_notification: bool = False,
        reply_to_message_id: Optional[str] = None,
    ) -> str:
        """Send a location."""
        payload = {
            "chat_id": chat_id,
            "latitude": latitude,
            "longitude": longitude,
            "disable_notification": disable_notification,
        }
        if reply_to_message_id:
            payload["reply_to_message_id"] = reply_to_message_id
        data = self._request("sendLocation", payload)
        return data.get("message_id")

    def send_contact(
        self,
        chat_id: str,
        first_name: str,
        phone_number: str,
        last_name: Optional[str] = None,
        disable_notification: bool = False,
        reply_to_message_id: Optional[str] = None,
    ) -> str:
        """Send a contact."""
        payload = {
            "chat_id": chat_id,
            "first_name": first_name,
            "phone_number": phone_number,
            "disable_notification": disable_notification,
        }
        if last_name:
            payload["last_name"] = last_name
        if reply_to_message_id:
            payload["reply_to_message_id"] = reply_to_message_id
        data = self._request("sendContact", payload)
        return data.get("message_id")

    def get_chat(self, chat_id: str) -> Chat:
        """Get chat information."""
        data = self._request("getChat", {"chat_id": chat_id})
        return Chat.from_dict(data.get("chat", {}))

    def forward_message(
        self,
        from_chat_id: str,
        message_id: str,
        to_chat_id: str,
        disable_notification: bool = False,
    ) -> str:
        """Forward a message to another chat."""
        payload = {
            "from_chat_id": from_chat_id,
            "message_id": message_id,
            "to_chat_id": to_chat_id,
            "disable_notification": disable_notification,
        }
        data = self._request("forwardMessage", payload)
        return data.get("new_message_id")

    def edit_message_text(
        self,
        chat_id: str,
        message_id: str,
        text: str,
    ) -> None:
        """Edit a message text."""
        payload = {
            "chat_id": chat_id,
            "message_id": message_id,
            "text": text,
        }
        self._request("editMessageText", payload)

    def edit_message_keypad(
        self,
        chat_id: str,
        message_id: str,
        inline_keyboard: Union[Dict, Keyboard],
    ) -> None:
        """Edit inline keypad of a message."""
        payload = {
            "chat_id": chat_id,
            "message_id": message_id,
        }
        if hasattr(inline_keyboard, 'to_dict'):
            payload["inline_keypad"] = inline_keyboard.to_dict()
        else:
            payload["inline_keypad"] = inline_keyboard
        self._request("editMessageKeypad", payload)

    def delete_message(self, chat_id: str, message_id: str) -> None:
        """Delete a message."""
        payload = {
            "chat_id": chat_id,
            "message_id": message_id,
        }
        self._request("deleteMessage", payload)

    def set_commands(self, commands: List[BotCommand]) -> None:
        """Set bot commands."""
        payload = {
            "bot_commands": [{"command": c.command, "description": c.description} for c in commands]
        }
        self._request("setCommands", payload)

    def update_bot_endpoints(self, url: str, type: UpdateEndpointTypeEnum = UpdateEndpointTypeEnum.ReceiveUpdate) -> None:
        """Update webhook endpoint."""
        payload = {
            "url": url,
            "type": type.value,
        }
        self._request("updateBotEndpoints", payload)

    def ban_chat_member(self, chat_id: str, user_id: str) -> None:
        """Ban a user from a group or channel."""
        payload = {
            "chat_id": chat_id,
            "user_id": user_id,
        }
        self._request("banChatMember", payload)

    def unban_chat_member(self, chat_id: str, user_id: str) -> None:
        """Unban a user from a group or channel."""
        payload = {
            "chat_id": chat_id,
            "user_id": user_id,
        }
        self._request("unbanChatMember", payload)

    # ==================== File Methods ====================
    def request_upload(self, file_type: FileTypeEnum) -> str:
        """Request an upload URL for a file."""
        payload = {"type": file_type.value}
        data = self._request("requestSendFile", payload)
        return data.get("upload_url")

    def upload_file(self, upload_url: str, file_path: str) -> str:
        """Upload a file to the provided URL and return file_id."""
        with open(file_path, 'rb') as f:
            files = {'file': f}
            response = self._session.post(upload_url, files=files)
        if response.status_code != 200:
            raise APIError(response.status_code, response.text)
        result = response.json()
        return result.get("file_id")

    def send_file(
        self,
        chat_id: str,
        file_id: str,
        text: Optional[str] = None,
        disable_notification: bool = False,
        reply_to_message_id: Optional[str] = None,
        chat_keyboard: Optional[Union[Dict, Keyboard]] = None,
        chat_keypad_type: Optional[ChatKeypadTypeEnum] = None,
        inline_keyboard: Optional[Union[Dict, Keyboard]] = None,
    ) -> str:
        """Send a file using its file_id."""
        payload = {
            "chat_id": chat_id,
            "file_id": file_id,
            "disable_notification": disable_notification,
        }
        if text:
            payload["text"] = text
        if reply_to_message_id:
            payload["reply_to_message_id"] = reply_to_message_id
        if chat_keyboard:
            if hasattr(chat_keyboard, 'to_dict'):
                payload["chat_keypad"] = chat_keyboard.to_dict()
            else:
                payload["chat_keypad"] = chat_keyboard
        if chat_keypad_type:
            payload["chat_keypad_type"] = chat_keypad_type.value
        if inline_keyboard:
            if hasattr(inline_keyboard, 'to_dict'):
                payload["inline_keypad"] = inline_keyboard.to_dict()
            else:
                payload["inline_keypad"] = inline_keyboard
        data = self._request("sendFile", payload)
        return data.get("message_id")

    def get_file(self, file_id: str) -> str:
        """Get download URL of a file."""
        data = self._request("getFile", {"file_id": file_id})
        return data.get("download_url")

    # ==================== Chat Keypad Methods ====================
    def edit_chat_keypad(
        self,
        chat_id: str,
        chat_keypad: Optional[Union[Dict, Keyboard]] = None,
        action: ChatKeypadTypeEnum = ChatKeypadTypeEnum.New,
    ) -> None:
        """Edit or remove chat keypad."""
        payload = {
            "chat_id": chat_id,
            "chat_keypad_type": action.value,
        }
        if chat_keypad and action == ChatKeypadTypeEnum.New:
            if hasattr(chat_keypad, 'to_dict'):
                payload["chat_keypad"] = chat_keypad.to_dict()
            else:
                payload["chat_keypad"] = chat_keypad
        self._request("editChatKeypad", payload)

    # ==================== Updates (Polling) ====================
    def get_updates(self, offset_id: Optional[str] = None, limit: int = 100) -> Tuple[List[Update], Optional[str]]:
        """Get updates (messages, events)."""
        payload = {"limit": limit}
        if offset_id:
            payload["offset_id"] = offset_id
        data = self._request("getUpdates", payload)
        updates = []
        for upd in data.get("updates", []):
            update_obj = Update.from_dict(upd)
            updates.append(update_obj)
        return updates, data.get("next_offset_id")

    def on_message(self):
        """Decorator for handling new messages in polling mode."""
        def decorator(func: Callable):
            self._handlers.append(func)
            return func
        return decorator

    def polling(self, interval: float = 2.0):
        """Start long polling loop."""
        Polling(self).start(interval, self._handlers)

    # ==================== Webhook Handling ====================
    @staticmethod
    def parse_webhook(body: Dict[str, Any]) -> Union[Update, InlineMessage, None]:
        """Parse incoming webhook POST data."""
        if "update" in body:
            return Update.from_dict(body["update"])
        elif "inline_message" in body:
            return InlineMessage.from_dict(body["inline_message"])
        return None

    def on_inline(self):
        """Decorator for handling inline button clicks (webhook mode)."""
        def decorator(func: Callable):
            self._inline_handlers.append(func)
            return func
        return decorator