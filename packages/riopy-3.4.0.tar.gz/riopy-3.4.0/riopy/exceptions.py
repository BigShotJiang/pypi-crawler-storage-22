class RiopyError(Exception):
    """Base exception for riopy library."""
    pass


class APIError(RiopyError):
    """Raised when the API returns an error."""
    def __init__(self, status_code: int, response_text: str):
        self.status_code = status_code
        self.response_text = response_text
        super().__init__(f"API error {status_code}: {response_text}")


class InvalidTokenError(RiopyError):
    """Raised when the provided token is invalid."""
    pass