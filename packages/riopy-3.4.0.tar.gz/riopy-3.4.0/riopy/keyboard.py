from typing import List, Optional
from .types import (
    Button, ButtonBehaviorEnum, Keyboard, KeyboardRow,
    ButtonSelection, ButtonSelectionItem, ButtonSelectionTypeEnum,
    ButtonSelectionSearchEnum, ButtonSelectionGetEnum,
    ButtonCalendar, ButtonCalendarTypeEnum,
    ButtonNumberPicker, ButtonStringPicker,
    ButtonTextbox, ButtonTextboxTypeLineEnum, ButtonTextboxTypeKeypadEnum,
    ButtonLocation, ButtonLocationTypeEnum, Location
)


def create_simple_button(button_id: str, text: str) -> Button:
    """Create a simple button."""
    return Button(
        id=button_id,
        type=ButtonBehaviorEnum.Simple,
        button_text=text
    )


def create_selection_button(
    button_id: str,
    text: str,
    selection_id: str,
    items: List[ButtonSelectionItem],
    search_type: ButtonSelectionSearchEnum = ButtonSelectionSearchEnum.None_,
    get_type: ButtonSelectionGetEnum = ButtonSelectionGetEnum.Local,
    is_multi_selection: bool = False,
    columns_count: str = "1",
    title: Optional[str] = None,
) -> Button:
    """Create a selection button."""
    selection = ButtonSelection(
        selection_id=selection_id,
        search_type=search_type,
        get_type=get_type,
        items=items,
        is_multi_selection=is_multi_selection,
        columns_count=columns_count,
        title=title
    )
    return Button(
        id=button_id,
        type=ButtonBehaviorEnum.Selection,
        button_text=text,
        button_selection=selection
    )


def create_calendar_button(
    button_id: str,
    text: str,
    calendar_type: ButtonCalendarTypeEnum = ButtonCalendarTypeEnum.DatePersian,
    default_value: Optional[str] = None,
    min_year: Optional[str] = None,
    max_year: Optional[str] = None,
    title: Optional[str] = None,
) -> Button:
    """Create a calendar button."""
    calendar = ButtonCalendar(
        type=calendar_type,
        default_value=default_value,
        min_year=min_year,
        max_year=max_year,
        title=title
    )
    return Button(
        id=button_id,
        type=ButtonBehaviorEnum.Calendar,
        button_text=text,
        button_calendar=calendar
    )


def create_number_picker_button(
    button_id: str,
    text: str,
    min_value: str,
    max_value: str,
    default_value: Optional[str] = None,
    title: Optional[str] = None,
) -> Button:
    """Create a number picker button."""
    picker = ButtonNumberPicker(
        min_value=min_value,
        max_value=max_value,
        default_value=default_value,
        title=title
    )
    return Button(
        id=button_id,
        type=ButtonBehaviorEnum.NumberPicker,
        button_text=text,
        button_number_picker=picker
    )


def create_string_picker_button(
    button_id: str,
    text: str,
    items: List[str],
    default_value: Optional[str] = None,
    title: Optional[str] = None,
) -> Button:
    """Create a string picker button."""
    picker = ButtonStringPicker(
        items=items,
        default_value=default_value,
        title=title
    )
    return Button(
        id=button_id,
        type=ButtonBehaviorEnum.StringPicker,
        button_text=text,
        button_string_picker=picker
    )


def create_textbox_button(
    button_id: str,
    text: str,
    type_line: ButtonTextboxTypeLineEnum = ButtonTextboxTypeLineEnum.SingleLine,
    type_keypad: ButtonTextboxTypeKeypadEnum = ButtonTextboxTypeKeypadEnum.String,
    place_holder: Optional[str] = None,
    title: Optional[str] = None,
    default_value: Optional[str] = None,
) -> Button:
    """Create a textbox button."""
    textbox = ButtonTextbox(
        type_line=type_line,
        type_keypad=type_keypad,
        place_holder=place_holder,
        title=title,
        default_value=default_value
    )
    return Button(
        id=button_id,
        type=ButtonBehaviorEnum.Textbox,
        button_text=text,
        button_textbox=textbox
    )


def create_location_button(
    button_id: str,
    text: str,
    location_type: ButtonLocationTypeEnum = ButtonLocationTypeEnum.Picker,
    default_pointer_location: Optional[Location] = None,
    default_map_location: Optional[Location] = None,
    title: Optional[str] = None,
) -> Button:
    """Create a location button."""
    loc = ButtonLocation(
        type=location_type,
        default_pointer_location=default_pointer_location,
        default_map_location=default_map_location,
        title=title
    )
    return Button(
        id=button_id,
        type=ButtonBehaviorEnum.Location,
        button_text=text,
        button_location=loc
    )


def create_keyboard(rows: List[List[Button]], resize: bool = True, one_time: bool = False) -> Keyboard:
    """Create a keyboard from a list of button rows."""
    keyboard_rows = [KeyboardRow(buttons=row) for row in rows]
    return Keyboard(rows=keyboard_rows, resize_keyboard=resize, one_time_keyboard=one_time)


# Add to_dict method to Keyboard for easy conversion
def keyboard_to_dict(self: Keyboard) -> dict:
    rows = []
    for row in self.rows:
        buttons = []
        for btn in row.buttons:
            btn_dict = {
                "id": btn.id,
                "type": btn.type.value,
                "button_text": btn.button_text,
            }
            if btn.button_selection:
                sel = btn.button_selection
                btn_dict["button_selection"] = {
                    "selection_id": sel.selection_id,
                    "search_type": sel.search_type.value,
                    "get_type": sel.get_type.value,
                    "items": [
                        {
                            "text": item.text,
                            "image_url": item.image_url,
                            "type": item.type.value,
                        }
                        for item in sel.items
                    ],
                    "is_multi_selection": sel.is_multi_selection,
                    "columns_count": sel.columns_count,
                }
                if sel.title:
                    btn_dict["button_selection"]["title"] = sel.title
            if btn.button_calendar:
                cal = btn.button_calendar
                btn_dict["button_calendar"] = {"type": cal.type.value}
                if cal.default_value:
                    btn_dict["button_calendar"]["default_value"] = cal.default_value
                if cal.min_year:
                    btn_dict["button_calendar"]["min_year"] = cal.min_year
                if cal.max_year:
                    btn_dict["button_calendar"]["max_year"] = cal.max_year
                if cal.title:
                    btn_dict["button_calendar"]["title"] = cal.title
            if btn.button_number_picker:
                np = btn.button_number_picker
                btn_dict["button_number_picker"] = {
                    "min_value": np.min_value,
                    "max_value": np.max_value,
                }
                if np.default_value:
                    btn_dict["button_number_picker"]["default_value"] = np.default_value
                if np.title:
                    btn_dict["button_number_picker"]["title"] = np.title
            if btn.button_string_picker:
                sp = btn.button_string_picker
                btn_dict["button_string_picker"] = {"items": sp.items}
                if sp.default_value:
                    btn_dict["button_string_picker"]["default_value"] = sp.default_value
                if sp.title:
                    btn_dict["button_string_picker"]["title"] = sp.title
            if btn.button_location:
                loc = btn.button_location
                btn_dict["button_location"] = {"type": loc.type.value}
                if loc.default_pointer_location:
                    btn_dict["button_location"]["default_pointer_location"] = {
                        "latitude": loc.default_pointer_location.latitude,
                        "longitude": loc.default_pointer_location.longitude,
                    }
                if loc.default_map_location:
                    btn_dict["button_location"]["default_map_location"] = {
                        "latitude": loc.default_map_location.latitude,
                        "longitude": loc.default_map_location.longitude,
                    }
                if loc.title:
                    btn_dict["button_location"]["title"] = loc.title
            if btn.button_textbox:
                tb = btn.button_textbox
                btn_dict["button_textbox"] = {
                    "type_line": tb.type_line.value,
                    "type_keypad": tb.type_keypad.value,
                }
                if tb.place_holder:
                    btn_dict["button_textbox"]["place_holder"] = tb.place_holder
                if tb.title:
                    btn_dict["button_textbox"]["title"] = tb.title
                if tb.default_value:
                    btn_dict["button_textbox"]["default_value"] = tb.default_value
            buttons.append(btn_dict)
        rows.append({"buttons": buttons})
    return {
        "rows": rows,
        "resize_keyboard": self.resize_keyboard,
        "one_time_keyboard": self.one_time_keyboard,
    }


# Attach to_dict method to Keyboard class
Keyboard.to_dict = keyboard_to_dict