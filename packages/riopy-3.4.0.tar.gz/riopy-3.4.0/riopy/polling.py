import time
import logging
from typing import List, Callable
from .types import Update, UpdateTypeEnum

logger = logging.getLogger(__name__)


class Polling:
    def __init__(self, bot):
        self.bot = bot
        self.last_offset_id = None
        self.running = False

    def start(self, interval: float, handlers: List[Callable]):
        self.running = True
        logger.info("Polling started.")
        while self.running:
            try:
                updates, next_offset = self.bot.get_updates(offset_id=self.last_offset_id)
                if updates:
                    for update in updates:
                        if update.type == UpdateTypeEnum.NewMessage and update.new_message:
                            for handler in handlers:
                                try:
                                    handler(update)
                                except Exception as e:
                                    logger.exception(f"Handler error: {e}")
                    # Update offset to avoid reprocessing
                    if next_offset:
                        self.last_offset_id = next_offset
            except Exception as e:
                logger.exception(f"Polling error: {e}")
            time.sleep(interval)

    def stop(self):
        self.running = False
        logger.info("Polling stopped.")