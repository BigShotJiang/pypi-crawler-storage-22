from dataclasses import dataclass, field
from typing import Optional, List, Any, Dict
from enum import Enum
import json


# Enums
class ChatTypeEnum(str, Enum):
    User = "User"
    Bot = "Bot"
    Group = "Group"
    Channel = "Channel"


class UpdateTypeEnum(str, Enum):
    NewMessage = "NewMessage"
    UpdatedMessage = "UpdatedMessage"
    RemovedMessage = "RemovedMessage"
    StartedBot = "StartedBot"
    StoppedBot = "StoppedBot"


class MessageSenderEnum(str, Enum):
    User = "User"
    Bot = "Bot"


class ForwardedFromEnum(str, Enum):
    User = "User"
    Channel = "Channel"
    Bot = "Bot"


class PollStatusEnum(str, Enum):
    Open = "Open"
    Closed = "Closed"


class ChatKeypadTypeEnum(str, Enum):
    None_ = "None"
    New = "New"
    Remove = "Remove"


class UpdateEndpointTypeEnum(str, Enum):
    ReceiveUpdate = "ReceiveUpdate"
    ReceiveInlineMessage = "ReceiveInlineMessage"
    ReceiveQuery = "ReceiveQuery"
    GetSelectionItem = "GetSelectionItem"
    SearchSelectionItems = "SearchSelectionItems"


# ========== Enumهای جدید ==========
class FileTypeEnum(str, Enum):
    File = "File"
    Image = "Image"
    Voice = "Voice"
    Video = "Video"
    Music = "Music"
    Gif = "Gif"


class ButtonBehaviorEnum(str, Enum):
    Simple = "Simple"
    Selection = "Selection"
    Calendar = "Calendar"
    NumberPicker = "NumberPicker"
    StringPicker = "StringPicker"
    Location = "Location"
    CameraImage = "CameraImage"
    CameraVideo = "CameraVideo"
    GalleryImage = "GalleryImage"
    GalleryVideo = "GalleryVideo"
    File = "File"
    Audio = "Audio"
    RecordAudio = "RecordAudio"
    Textbox = "Textbox"
    Link = "Link"
    AskMyPhoneNumber = "AskMyPhoneNumber"
    AskMyLocation = "AskMyLocation"
    Barcode = "Barcode"


class ButtonSelectionTypeEnum(str, Enum):
    TextOnly = "TextOnly"
    TextImgThu = "TextImgThu"
    TextImgBig = "TextImgBig"


class ButtonSelectionSearchEnum(str, Enum):
    None_ = "None"
    Local = "Local"
    Api = "Api"


class ButtonSelectionGetEnum(str, Enum):
    Local = "Local"
    Api = "Api"


class ButtonCalendarTypeEnum(str, Enum):
    DatePersian = "DatePersian"
    DateGregorian = "DateGregorian"


class ButtonTextboxTypeKeypadEnum(str, Enum):
    String = "String"
    Number = "Number"


class ButtonTextboxTypeLineEnum(str, Enum):
    SingleLine = "SingleLine"
    MultiLine = "MultiLine"


class ButtonLocationTypeEnum(str, Enum):
    Picker = "Picker"
    View = "View"


# Helper to convert string to enum
def _str_to_enum(value, enum_class):
    if value is None:
        return None
    try:
        return enum_class(value)
    except ValueError:
        return value


# Models
@dataclass
class File:
    file_id: str
    file_name: Optional[str] = None
    size: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Optional['File']:
        if not data:
            return None
        return cls(
            file_id=data.get("file_id"),
            file_name=data.get("file_name"),
            size=data.get("size")
        )


@dataclass
class ForwardedFrom:
    type_from: ForwardedFromEnum
    message_id: str
    from_chat_id: str
    from_sender_id: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Optional['ForwardedFrom']:
        if not data:
            return None
        return cls(
            type_from=_str_to_enum(data.get("type_from"), ForwardedFromEnum),
            message_id=data.get("message_id"),
            from_chat_id=data.get("from_chat_id"),
            from_sender_id=data.get("from_sender_id")
        )


@dataclass
class Location:
    latitude: str
    longitude: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Optional['Location']:
        if not data:
            return None
        return cls(
            latitude=data.get("latitude"),
            longitude=data.get("longitude")
        )


@dataclass
class ContactMessage:
    phone_number: str
    first_name: str
    last_name: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Optional['ContactMessage']:
        if not data:
            return None
        return cls(
            phone_number=data.get("phone_number"),
            first_name=data.get("first_name"),
            last_name=data.get("last_name")
        )


@dataclass
class PollStatus:
    state: PollStatusEnum
    selection_index: int = -1
    percent_vote_options: Optional[List[int]] = None
    total_vote: Optional[int] = None
    show_total_votes: Optional[bool] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Optional['PollStatus']:
        if not data:
            return None
        return cls(
            state=_str_to_enum(data.get("state"), PollStatusEnum),
            selection_index=data.get("selection_index", -1),
            percent_vote_options=data.get("percent_vote_options"),
            total_vote=data.get("total_vote"),
            show_total_votes=data.get("show_total_votes")
        )


@dataclass
class Poll:
    question: str
    options: List[str]
    poll_status: Optional[PollStatus] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Optional['Poll']:
        if not data:
            return None
        return cls(
            question=data.get("question"),
            options=data.get("options", []),
            poll_status=PollStatus.from_dict(data.get("poll_status"))
        )


@dataclass
class AuxData:
    start_id: Optional[str] = None
    button_id: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Optional['AuxData']:
        if not data:
            return None
        return cls(
            start_id=data.get("start_id"),
            button_id=data.get("button_id")
        )


@dataclass
class Message:
    message_id: str
    time: int
    is_edited: bool
    sender_type: MessageSenderEnum
    sender_id: str
    text: Optional[str] = None
    aux_data: Optional[AuxData] = None
    file: Optional[File] = None
    reply_to_message_id: Optional[str] = None
    forwarded_from: Optional[ForwardedFrom] = None
    forwarded_no_link: Optional[str] = None
    location: Optional[Location] = None
    contact_message: Optional[ContactMessage] = None
    poll: Optional[Poll] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Optional['Message']:
        if not data:
            return None
        return cls(
            message_id=data.get("message_id"),
            time=data.get("time"),
            is_edited=data.get("is_edited", False),
            sender_type=_str_to_enum(data.get("sender_type"), MessageSenderEnum),
            sender_id=data.get("sender_id"),
            text=data.get("text"),
            aux_data=AuxData.from_dict(data.get("aux_data")),
            file=File.from_dict(data.get("file")),
            reply_to_message_id=data.get("reply_to_message_id"),
            forwarded_from=ForwardedFrom.from_dict(data.get("forwarded_from")),
            forwarded_no_link=data.get("forwarded_no_link"),
            location=Location.from_dict(data.get("location")),
            contact_message=ContactMessage.from_dict(data.get("contact_message")),
            poll=Poll.from_dict(data.get("poll"))
        )


@dataclass
class Update:
    type: UpdateTypeEnum
    chat_id: str
    new_message: Optional[Message] = None
    updated_message: Optional[Message] = None
    removed_message_id: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Update':
        return cls(
            type=_str_to_enum(data.get("type"), UpdateTypeEnum),
            chat_id=data.get("chat_id"),
            new_message=Message.from_dict(data.get("new_message")),
            updated_message=Message.from_dict(data.get("updated_message")),
            removed_message_id=data.get("removed_message_id")
        )


@dataclass
class InlineMessage:
    sender_id: str
    message_id: str
    chat_id: str
    text: Optional[str] = None
    file: Optional[File] = None
    location: Optional[Location] = None
    aux_data: Optional[AuxData] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Optional['InlineMessage']:
        if not data:
            return None
        return cls(
            sender_id=data.get("sender_id"),
            text=data.get("text"),
            file=File.from_dict(data.get("file")),
            location=Location.from_dict(data.get("location")),
            aux_data=AuxData.from_dict(data.get("aux_data")),
            message_id=data.get("message_id"),
            chat_id=data.get("chat_id")
        )


@dataclass
class Chat:
    chat_id: str
    chat_type: ChatTypeEnum
    user_id: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    title: Optional[str] = None
    username: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Chat':
        return cls(
            chat_id=data.get("chat_id"),
            chat_type=_str_to_enum(data.get("chat_type"), ChatTypeEnum),
            user_id=data.get("user_id"),
            first_name=data.get("first_name"),
            last_name=data.get("last_name"),
            title=data.get("title"),
            username=data.get("username")
        )


@dataclass
class Bot:
    bot_id: str
    bot_title: str
    username: str
    description: Optional[str] = None
    start_message: Optional[str] = None
    share_url: Optional[str] = None
    avatar: Optional[File] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Bot':
        return cls(
            bot_id=data.get("bot_id"),
            bot_title=data.get("bot_title"),
            username=data.get("username"),
            description=data.get("description"),
            start_message=data.get("start_message"),
            share_url=data.get("share_url"),
            avatar=File.from_dict(data.get("avatar"))
        )


@dataclass
class BotCommand:
    command: str
    description: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BotCommand':
        return cls(
            command=data.get("command"),
            description=data.get("description")
        )


# ========== مدل‌های جدید برای کیپد ==========
@dataclass
class ButtonSelectionItem:
    text: str
    image_url: Optional[str] = None
    type: ButtonSelectionTypeEnum = ButtonSelectionTypeEnum.TextOnly


@dataclass
class ButtonSelection:
    selection_id: str
    search_type: ButtonSelectionSearchEnum = ButtonSelectionSearchEnum.None_
    get_type: ButtonSelectionGetEnum = ButtonSelectionGetEnum.Local
    items: List[ButtonSelectionItem] = field(default_factory=list)
    is_multi_selection: bool = False
    columns_count: str = "1"
    title: Optional[str] = None


@dataclass
class ButtonCalendar:
    default_value: Optional[str] = None
    type: ButtonCalendarTypeEnum = ButtonCalendarTypeEnum.DatePersian
    min_year: Optional[str] = None
    max_year: Optional[str] = None
    title: Optional[str] = None


@dataclass
class ButtonNumberPicker:
    min_value: str
    max_value: str
    default_value: Optional[str] = None
    title: Optional[str] = None


@dataclass
class ButtonStringPicker:
    items: List[str]
    default_value: Optional[str] = None
    title: Optional[str] = None


@dataclass
class ButtonTextbox:
    type_line: ButtonTextboxTypeLineEnum = ButtonTextboxTypeLineEnum.SingleLine
    type_keypad: ButtonTextboxTypeKeypadEnum = ButtonTextboxTypeKeypadEnum.String
    place_holder: Optional[str] = None
    title: Optional[str] = None
    default_value: Optional[str] = None


@dataclass
class ButtonLocation:
    default_pointer_location: Optional[Location] = None
    default_map_location: Optional[Location] = None
    type: ButtonLocationTypeEnum = ButtonLocationTypeEnum.Picker
    title: Optional[str] = None


@dataclass
class Button:
    id: str
    type: ButtonBehaviorEnum
    button_text: str
    button_selection: Optional[ButtonSelection] = None
    button_calendar: Optional[ButtonCalendar] = None
    button_number_picker: Optional[ButtonNumberPicker] = None
    button_string_picker: Optional[ButtonStringPicker] = None
    button_location: Optional[ButtonLocation] = None
    button_textbox: Optional[ButtonTextbox] = None


@dataclass
class KeyboardRow:
    buttons: List[Button]


@dataclass
class Keyboard:
    rows: List[KeyboardRow]
    resize_keyboard: bool = True
    one_time_keyboard: bool = False