# Utility functions (currently empty, can be expanded later)
pass