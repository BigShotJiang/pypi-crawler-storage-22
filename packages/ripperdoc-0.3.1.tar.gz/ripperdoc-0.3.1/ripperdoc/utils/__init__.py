"""Utility modules for Ripperdoc."""
