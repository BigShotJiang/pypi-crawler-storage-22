class __catalogue(type):
    __class = None
    
    class Item:
        def __init__(self, id, parent):
            self.__id = id
            self.__parent = parent
            
        def __getattribute__(self, name):
            match name:
                case "ID":
                    return self.__id
                case "PARENT":
                    return self.__parent
                case "NAME":
                    return self.__parent.names[self.ID]
                case "VALUE":
                    return self.__parent.values[self.ID]
                case _:
                    return super().__getattribute__(name)
        
        def __repr__(self):
            match self.VALUE:
                case None:
                    value = ""
                case anything_else:
                    value = f" -> {anything_else}"                    
            return f"|{self.__parent.__name__}.{self.NAME}/{self.__id}{value}|"
        
        def __eq__(self, other):
            return (self.__id == other.ID)
        def __ne__(self, other):
            return not self.__eq__(other)
        
        def __gt__(self, other):
            return self.__id > other.ID
        def __lt__(self, other):
            return self.__id < other.ID
        
        def __le__(self, other):
            return self.__lt__(other) or self.__eq__(other)
        def __ge__(self, other):
            return self.__gt__(other) or self.__eq__(other)
        
    def __new__(meta, name, bases, namespace, **keywords):
        if meta.__class is None:
            meta.__class = super().__new__(meta, name, bases, namespace, **keywords)
            return meta.__class
        else:
            cls = super().__new__(meta, name, bases, {"next_id" : 0,"instances":{}, "values":{}, "names":{}, "ids":{}, "step":1}, **keywords)
            for name, value in namespace.items():
                if (not name.startswith('__') and not name.endswith('__')) and name.isupper():
                    if isinstance(value, tuple):
                        item, id = value

                        if not isinstance(id, int):
                            id = None
                    else:
                        item, id = value, None
                    meta.__call__(cls, name, item, id)
            return cls
    
    def __call__(cls, name, item, id=None):
        
        if cls is cls.__class__.__class:
            raise SyntaxError("Cannot use Catalogue class as a catalogue")
        if id is None:
            id = cls.next_id
        cls.next_id = id + cls.step
        
        if id in cls.instances:
            instance = cls.instances[id]
        else:
            instance = cls.__class__.Item(id, cls)
            cls.instances[id] = instance
        cls.values[id] = item
        cls.names[id] = name
        cls.ids[name] = id
        return instance

    def __getattr__(cls, name):
        if name in cls.ids:
            return cls.instances[cls.ids[name]]
        else:
            return super().__getattr__(name)


class Catalogue(metaclass = __catalogue):
    def __init_subclass__(cls, step=1):
        cls.step = step

        
if __name__ == "__main__":
    class cat_a(Catalogue, step=2):
        TILEMAP = "catalogue"
        TEST = "catalogue"

    class cat_b(Catalogue):
        TILEMAP = "catalogue"
        TEST = "catalogue"

    print(cat_a.TILEMAP.NAME, cat_a.TEST.ID)
    print(cat_b.TILEMAP.VALUE, cat_b.TEST.PARENT)