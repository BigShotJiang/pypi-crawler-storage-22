from setuptools import setup, find_packages
setup(
    name="rising-registry",
    version="1.0",
    packages=find_packages(),
    install_requires=[]
)
