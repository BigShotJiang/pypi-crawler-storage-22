#!/usr/bin/env python3
"""
Risk Mirror CLI - API-Based Safety Scanner
===========================================
Scan prompts and files for PII, secrets, and injection risks.
All scans go through the Risk Mirror API for unified usage tracking.

Usage:
    risk-mirror scan "Your prompt text here"
    risk-mirror scan -f prompt.txt
    risk-mirror scan -f prompt.txt --json
    risk-mirror safe-share "sensitive string"
    risk-mirror safe-share -f secrets.txt --mode full
    risk-mirror login --email you@example.com
    risk-mirror auth --token <token-from-email-link>
    risk-mirror activate-license --license-key <key>
    risk-mirror --version
"""

import argparse
import json
import os
import sys
from typing import Optional, List, Dict, Any
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from urllib.parse import quote

from .client import RiskMirror, RiskMirrorError

CLI_VERSION = "1.0.3"
DEFAULT_BASE_URL = "https://risk-mirror-auth.anonymous617461746174.workers.dev"

# Exit codes
EXIT_SAFE = 0
EXIT_RISK = 1
EXIT_ERROR = 2


def get_base_url() -> str:
    return (os.environ.get("RISK_MIRROR_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")


def get_session_token(args: argparse.Namespace) -> Optional[str]:
    return args.session_token or os.environ.get("RISK_MIRROR_SESSION_TOKEN")


def create_parser() -> argparse.ArgumentParser:
    """Create argument parser."""
    parser = argparse.ArgumentParser(
        prog="risk-mirror",
        description="Risk Mirror CLI - Deterministic AI Safety Scanner",
        epilog="Examples:\n"
               "  risk-mirror scan \"Check this prompt\"\n"
               "  risk-mirror scan -f prompt.txt --json\n"
               "  RISK_MIRROR_API_KEY=rm_xxx risk-mirror scan \"text\"\n"
               "  risk-mirror login --email you@example.com\n"
               "  risk-mirror auth --token <token-from-email-link>\n",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    parser.add_argument(
        "--version", "-V",
        action="version",
        version=f"risk-mirror CLI {CLI_VERSION}"
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # Scan command
    scan_parser = subparsers.add_parser(
        "scan",
        help="Scan text or file for safety issues",
        description="Scan text or file for PII, secrets, and prompt injection"
    )

    scan_parser.add_argument(
        "text",
        nargs="?",
        help="Text to scan (use -f for file input)"
    )

    scan_parser.add_argument(
        "-f", "--file",
        help="File to scan"
    )

    scan_parser.add_argument(
        "--api-key", "-k",
        help="API key (or set RISK_MIRROR_API_KEY env var)"
    )

    scan_parser.add_argument(
        "--session-token",
        help="Session token (or set RISK_MIRROR_SESSION_TOKEN env var)"
    )

    scan_parser.add_argument(
        "--json", "-j",
        action="store_true",
        help="Output as JSON"
    )

    scan_parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="Only output verdict (for CI/CD)"
    )

    # Safe Share command
    safe_parser = subparsers.add_parser(
        "safe-share",
        help="Generate Safe Share burner text",
        description="Create non-reversible, format-preserving safe share text"
    )

    safe_parser.add_argument(
        "text",
        nargs="?",
        help="Text to transform (use -f for file input)"
    )

    safe_parser.add_argument(
        "-f", "--file",
        help="File to transform"
    )

    safe_parser.add_argument(
        "--mode",
        choices=["full", "selective"],
        default="selective",
        help="Replacement mode (default: selective)"
    )

    safe_parser.add_argument(
        "--no-secrets",
        action="store_true",
        help="Disable secrets replacement in selective mode"
    )

    safe_parser.add_argument(
        "--allow-valid",
        action="store_true",
        help="Allow valid-looking values (disables strict invalid generation)"
    )

    safe_parser.add_argument(
        "--api-key", "-k",
        help="API key (or set RISK_MIRROR_API_KEY env var)"
    )

    safe_parser.add_argument(
        "--session-token",
        help="Session token (or set RISK_MIRROR_SESSION_TOKEN env var)"
    )

    safe_parser.add_argument(
        "--json", "-j",
        action="store_true",
        help="Output as JSON"
    )

    safe_parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="Only output the safe share text"
    )

    # Activate license (bind email to license)
    activate_parser = subparsers.add_parser(
        "activate-license",
        help="Activate a license key for your signed-in email",
        description="Bind your license key to the authenticated email for cross-device sync"
    )
    activate_parser.add_argument(
        "--license-key",
        required=True,
        help="License key from your purchase email"
    )
    activate_parser.add_argument(
        "--session-token",
        help="Session token (or set RISK_MIRROR_SESSION_TOKEN env var)"
    )
    activate_parser.add_argument(
        "--json", "-j",
        action="store_true",
        help="Output as JSON"
    )

    # Login (magic link)
    login_parser = subparsers.add_parser(
        "login",
        help="Request a magic link for email login",
        description="Send a magic link to your email for session-based auth"
    )
    login_parser.add_argument(
        "--email",
        required=True,
        help="Email address used for purchase or login"
    )

    # Auth (verify token)
    auth_parser = subparsers.add_parser(
        "auth",
        help="Exchange magic-link token for a session token",
        description="Paste the token from the magic link URL"
    )
    auth_parser.add_argument(
        "--token",
        required=True,
        help="Token from the magic link URL"
    )
    auth_parser.add_argument(
        "--json", "-j",
        action="store_true",
        help="Output as JSON"
    )

    return parser


def format_result(result, as_json: bool = False) -> str:
    """Format scan result for display."""
    if as_json:
        return json.dumps({
            "verdict": result.verdict.value if hasattr(result.verdict, 'value') else str(result.verdict),
            "safe_output": result.safe_output,
            "findings_count": len(result.findings) if result.findings else 0,
        }, indent=2)

    verdict = result.verdict.value if hasattr(result.verdict, 'value') else str(result.verdict)
    emoji = {"SAFE": "✅", "REVIEW": "⚠️", "BLOCK": "🚨"}.get(verdict, "❓")

    lines = [f"\n{emoji} Verdict: {verdict}"]

    if result.findings:
        lines.append(f"\n📋 Findings ({len(result.findings)}):")
        for f in result.findings:
            lines.append(f"   • {f.get('category', 'unknown')}: {f.get('count', 1)} occurrence(s)")

    if result.safe_output:
        lines.append(f"\n🔒 Safe Output:\n{result.safe_output[:500]}{'...' if len(result.safe_output) > 500 else ''}")

    lines.append("\n🔐 Privacy: Stateless scan, no content stored")

    return "\n".join(lines)


def main(args: Optional[List[str]] = None) -> int:
    """Main CLI entry point."""
    parser = create_parser()
    parsed = parser.parse_args(args)

    if not parsed.command:
        parser.print_help()
        return EXIT_ERROR

    if parsed.command == "scan":
        return handle_scan(parsed)
    if parsed.command == "safe-share":
        return handle_safe_share(parsed)
    if parsed.command == "activate-license":
        return handle_activate_license(parsed)
    if parsed.command == "login":
        return handle_login(parsed)
    if parsed.command == "auth":
        return handle_auth(parsed)

    return EXIT_ERROR


def handle_scan(args: argparse.Namespace) -> int:
    """Handle scan command."""
    api_key = args.api_key or os.environ.get("RISK_MIRROR_API_KEY")
    session_token = get_session_token(args)

    if args.file:
        try:
            with open(args.file, "r", encoding="utf-8") as f:
                text = f.read()
        except FileNotFoundError:
            print(f"Error: File not found: {args.file}", file=sys.stderr)
            return EXIT_ERROR
        except Exception as e:
            print(f"Error reading file: {e}", file=sys.stderr)
            return EXIT_ERROR
    elif args.text:
        text = args.text
    else:
        if sys.stdin.isatty():
            print("Error: No input provided. Use -f FILE or provide text.", file=sys.stderr)
            return EXIT_ERROR
        text = sys.stdin.read()

    if not text.strip():
        print("Error: Empty input", file=sys.stderr)
        return EXIT_ERROR

    try:
        client = RiskMirror(api_key=api_key, session_token=session_token, base_url=get_base_url())
        result = client.scan(text)

        if args.quiet:
            verdict = result.verdict.value if hasattr(result.verdict, 'value') else str(result.verdict)
            print(verdict)
        else:
            print(format_result(result, as_json=args.json))

        verdict = result.verdict.value if hasattr(result.verdict, 'value') else str(result.verdict)
        return EXIT_SAFE if verdict == "SAFE" else EXIT_RISK

    except RiskMirrorError as e:
        print(f"API Error: {e.message}", file=sys.stderr)
        if e.status_code == 401:
            print("Hint: Set RISK_MIRROR_API_KEY or use --api-key", file=sys.stderr)
        return EXIT_ERROR
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return EXIT_ERROR


def handle_safe_share(args: argparse.Namespace) -> int:
    """Handle safe-share command."""
    api_key = args.api_key or os.environ.get("RISK_MIRROR_API_KEY")
    session_token = get_session_token(args)

    if args.file:
        try:
            with open(args.file, "r", encoding="utf-8") as f:
                text = f.read()
        except FileNotFoundError:
            print(f"Error: File not found: {args.file}", file=sys.stderr)
            return EXIT_ERROR
        except Exception as e:
            print(f"Error reading file: {e}", file=sys.stderr)
            return EXIT_ERROR
    elif args.text:
        text = args.text
    else:
        if sys.stdin.isatty():
            print("Error: No input provided. Use -f FILE or provide text.", file=sys.stderr)
            return EXIT_ERROR
        text = sys.stdin.read()

    if not text.strip():
        print("Error: Empty input", file=sys.stderr)
        return EXIT_ERROR

    try:
        client = RiskMirror(api_key=api_key, session_token=session_token, base_url=get_base_url())
        result = client.safe_share(
            text,
            mode=args.mode,
            include_secrets=not args.no_secrets,
            strict_invalid=not args.allow_valid,
        )

        if args.quiet:
            print(result.safe_share_text)
            return EXIT_SAFE

        if args.json:
            print(json.dumps({
                "safe_share_text": result.safe_share_text,
                "mode": result.mode,
                "audit_summary": result.audit_summary,
            }, indent=2))
        else:
            print(result.safe_share_text)
            if result.audit_summary:
                print(f"\n🔐 Replaced spans: {result.audit_summary.get('spans_replaced', 0)}")
                print(f"🧩 Replaced chars: {result.audit_summary.get('chars_replaced', 0)}")
            print("\n🔐 Privacy: Stateless, no content stored")

        return EXIT_SAFE
    except RiskMirrorError as e:
        print(f"API Error: {e.message}", file=sys.stderr)
        if e.status_code == 401:
            print("Hint: Set RISK_MIRROR_API_KEY or use --api-key", file=sys.stderr)
        return EXIT_ERROR
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return EXIT_ERROR


def handle_login(args: argparse.Namespace) -> int:
    """Request a magic link via email."""
    email = args.email.strip()
    if not email:
        print("Error: Email is required", file=sys.stderr)
        return EXIT_ERROR

    url = f"{get_base_url()}/auth/magic-link"
    payload = json.dumps({"email": email}).encode("utf-8")
    req = Request(url, data=payload, headers={"Content-Type": "application/json"}, method="POST")

    try:
        with urlopen(req, timeout=20) as response:
            data = json.loads(response.read().decode("utf-8"))
            if not data.get("success"):
                print("Error: Failed to send login link", file=sys.stderr)
                return EXIT_ERROR
            print("Magic link sent. Check your email.")
            print("Next: run `risk-mirror auth --token <token-from-email-link>`")
            return EXIT_SAFE
    except HTTPError as e:
        try:
            body = e.read().decode("utf-8")
        except Exception:
            body = ""
        print(f"Error: {e.code} {body}", file=sys.stderr)
        return EXIT_ERROR
    except URLError as e:
        print(f"Network error: {e.reason}", file=sys.stderr)
        return EXIT_ERROR


def handle_auth(args: argparse.Namespace) -> int:
    """Exchange magic-link token for a session token."""
    token = args.token.strip()
    if not token:
        print("Error: Token is required", file=sys.stderr)
        return EXIT_ERROR

    url = f"{get_base_url()}/auth/verify?token={quote(token)}"
    req = Request(url, method="GET")

    try:
        with urlopen(req, timeout=20) as response:
            data = json.loads(response.read().decode("utf-8"))
            if not data.get("success") or not data.get("sessionToken"):
                print("Error: Invalid or expired token", file=sys.stderr)
                return EXIT_ERROR

            if args.json:
                print(json.dumps({
                    "email": data.get("email"),
                    "tier": data.get("tier"),
                    "sessionToken": data.get("sessionToken"),
                    "expiresAt": data.get("expiresAt"),
                }, indent=2))
            else:
                print("Login verified.")
                print(f"Email: {data.get('email')}")
                print(f"Tier: {data.get('tier')}")
                print("\nSet your session token for CLI/SDK usage:")
                print(f"  export RISK_MIRROR_SESSION_TOKEN='{data.get('sessionToken')}'")

            return EXIT_SAFE
    except HTTPError as e:
        try:
            body = e.read().decode("utf-8")
        except Exception:
            body = ""
        print(f"Error: {e.code} {body}", file=sys.stderr)
        return EXIT_ERROR
    except URLError as e:
        print(f"Network error: {e.reason}", file=sys.stderr)
        return EXIT_ERROR


def handle_activate_license(args: argparse.Namespace) -> int:
    """Bind a license key to the authenticated email."""
    session_token = get_session_token(args)
    if not session_token:
        print("Error: Session token required. Run `risk-mirror login` then `risk-mirror auth`, or set RISK_MIRROR_SESSION_TOKEN.", file=sys.stderr)
        return EXIT_ERROR

    license_key = args.license_key.strip()
    if not license_key:
        print("Error: License key is required", file=sys.stderr)
        return EXIT_ERROR

    url = f"{get_base_url()}/auth/validate-license"
    payload = json.dumps({"license_key": license_key}).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {session_token}",
    }
    req = Request(url, data=payload, headers=headers, method="POST")

    try:
        with urlopen(req, timeout=20) as response:
            data = json.loads(response.read().decode("utf-8"))
            if not data.get("valid"):
                print(f"Error: {data.get('error', 'Invalid or expired license key')}", file=sys.stderr)
                return EXIT_ERROR

            if args.json:
                print(json.dumps({
                    "valid": True,
                    "tier": data.get("tier"),
                    "email": data.get("email"),
                    "expiresAt": data.get("expiresAt"),
                    "usageReset": data.get("usageReset"),
                }, indent=2))
            else:
                print("License activated successfully.")
                print(f"Tier: {data.get('tier')}")
                if data.get("email"):
                    print(f"Email: {data.get('email')}")
                if data.get("usageReset"):
                    print("Usage counter reset for today.")

            return EXIT_SAFE
    except HTTPError as e:
        try:
            body = e.read().decode("utf-8")
        except Exception:
            body = ""
        print(f"Error: {e.code} {body}", file=sys.stderr)
        return EXIT_ERROR
    except URLError as e:
        print(f"Network error: {e.reason}", file=sys.stderr)
        return EXIT_ERROR


if __name__ == "__main__":
    sys.exit(main())
