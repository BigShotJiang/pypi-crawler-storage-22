## RisKit

### Documentation

To build the documentation, you need to install some custom Typst packages locally. You can do that by running:

```bash
typi --project-directory=documents
```

`typi` is available after you've set up the project environment with `uv sync`. Don't forget to activate the virtual environment first.
