from .basic import NumPyGaussian as NumPyGaussian, NumPyUniform as NumPyUniform
from .accelerated import JaxGaussian as JaxGaussian, JaxUniform as JaxUniform
from .factory import distribution as distribution
