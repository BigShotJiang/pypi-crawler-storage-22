# RiyadhAI Python SDK

Enterprise-grade Python SDK for RiyadhAI real-time agents, RTC, and plugin integrations.

## Attribution

This SDK is derived from upstream LiveKit open-source software and rebranded by RiyadhAI, LLC. LiveKit names are preserved only for factual attribution where required by Apache-2.0 notice obligations.

## License

Apache License 2.0. See `LICENSE` and `NOTICE`.

## Install

```bash
pip install riyadhai
```

For production/native features, install from published platform wheels. Source distributions are intentionally lightweight and do not bundle large native runtime assets.

Optional plugin dependency bundles:

```bash
pip install "riyadhai[all]"
pip install "riyadhai[openai,deepgram,cartesia,silero,turn-detector]"
```

## Project Layout

- `src/riyadhai/` package source
- `examples/` runnable example agents
- `docs/` release and support documentation
- `pyproject.toml` hatchling build configuration

## Compatibility Policy

This rebranding baseline changes branding and namespace only; business logic and runtime contracts are preserved.

## Migration Guide

This baseline is intentionally breaking and does not include legacy compatibility shims.

- `from livekit import ...` -> `from riyadhai import ...`
- package names rebranded to `riyadhai*`

## Examples

```bash
python examples/pipeline_agent.py download-files
python examples/realtime_agent.py download-files
```

## Console Log Modes

Set `RIYADHAI_LOG_MODE` to tune console verbosity without code changes:

- `transcript_only` (default): keep DEBUG focused on user transcription
- `full_debug`: show full DEBUG stream
- `info_only`: hide DEBUG and show INFO+
