# Release Guide

## Versioning

- Update `version` in `pyproject.toml`.
- Keep release notes in your VCS release/tag description.

## Build

```bash
python -m pip install --upgrade build twine
python -m build --sdist --no-isolation
python -m twine check dist/*
```

Local `python -m build` output is for development smoke checks only. Do not publish local wheels from `dist/`.
The sdist is intentionally lightweight and excludes heavy native runtime assets; production installs should use CI-built platform wheels.

## Platform Wheel Build (Enterprise)

Platform-tagged wheels are built in CI with `cibuildwheel` using `.github/workflows/wheels.yml`.

- macOS Intel and Apple Silicon
- CPython 3.10, 3.11, 3.12
- wheel repair with `delocate` for native runtime assets

Manual local invocation (macOS):

```bash
python -m pip install --upgrade cibuildwheel twine
python -m cibuildwheel --output-dir wheelhouse
python -m twine check wheelhouse/*
```

## Signed Tag + Approval Gate

Production publishing is gated in `.github/workflows/wheels.yml`:

- requires a signed annotated tag (`v*`) verified by GitHub
- builds wheel artifacts (macOS Intel and Apple Silicon, cp310/cp311/cp312) and sdist
- requires manual approval through GitHub Environment `pypi-release`
- publishes only after approval and final `twine check`

Create a signed annotated tag:

```bash
git tag -s v1.4.2 -m "Release v1.4.2"
git push origin v1.4.2
```

## Local Wheel Smoke Test

```bash
python -m venv .venv-release-test
source .venv-release-test/bin/activate
python -m pip install --upgrade pip
python -m pip install dist/*.whl
python -c "import riyadhai; print('riyadhai import ok')"
python examples/pipeline_agent.py download-files
python examples/realtime_agent.py download-files
```

## Publish

Publishing is performed only by `.github/workflows/wheels.yml` after:

- signed annotated tag verification
- platform wheel artifact checks (rejects `py3-none-any`)
- environment approval gate (`pypi-release`)

## Rollback

- Do not overwrite an existing PyPI version.
- Publish a new patch version that supersedes the bad release.
