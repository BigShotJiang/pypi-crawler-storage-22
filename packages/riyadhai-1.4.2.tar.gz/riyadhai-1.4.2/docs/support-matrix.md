# Support Matrix

## Python

- 3.10
- 3.11
- 3.12

## Platform Wheels

- macOS x86_64 and arm64 (production CI builds via `cibuildwheel`)
- Python 3.10, 3.11, 3.12 wheel variants
- Tagged platform wheels (not `py3-none-any`) for production releases
- Linux/Windows production wheels are not published in the current baseline.

## Runtime Notes

- Native assets are required for RTC, blingfire tokenization, and noise cancellation features.
- For full plugin coverage, install extras such as `riyadhai[all]` or selected plugin extras.
