# Copyright 2023 LiveKit, Inc.
# Copyright 2026 RiyadhAI, LLC.
#
# Modifications by RiyadhAI, LLC:
# - Replaced the upstream file header with RiyadhAI attribution for this derivative file.
# - Renamed LiveKit identifiers to RiyadhAI where applicable in this file.
# - Renamed LiveKit identifiers and namespace references to RiyadhAI in this file.
# - Updated branding-related imports, labels, or log text to RiyadhAI where applicable.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0

ATTR_SPEECH_ID = "rai.speech_id"
ATTR_AGENT_LABEL = "rai.agent_label"
ATTR_START_TIME = "rai.start_time"
ATTR_END_TIME = "rai.end_time"
ATTR_RETRY_COUNT = "rai.retry_count"


ATTR_PARTICIPANT_ID = "rai.participant_id"
ATTR_PARTICIPANT_IDENTITY = "rai.participant_identity"
ATTR_PARTICIPANT_KIND = "rai.participant_kind"

# session start
ATTR_JOB_ID = "rai.job_id"
ATTR_AGENT_NAME = "rai.agent_name"
ATTR_ROOM_NAME = "rai.room_name"
ATTR_SESSION_OPTIONS = "rai.session_options"

# agent turn
ATTR_AGENT_TURN_ID = "rai.generation_id"
ATTR_AGENT_PARENT_TURN_ID = "rai.parent_generation_id"
ATTR_USER_INPUT = "rai.user_input"
ATTR_INSTRUCTIONS = "rai.instructions"
ATTR_SPEECH_INTERRUPTED = "rai.interrupted"

# llm node
ATTR_CHAT_CTX = "rai.chat_ctx"
ATTR_FUNCTION_TOOLS = "rai.function_tools"
ATTR_PROVIDER_TOOLS = "rai.provider_tools"
ATTR_TOOL_SETS = "rai.tool_sets"
ATTR_RESPONSE_TEXT = "rai.response.text"
ATTR_RESPONSE_FUNCTION_CALLS = "rai.response.function_calls"

# function tool
ATTR_FUNCTION_TOOL_ID = "rai.function_tool.id"
ATTR_FUNCTION_TOOL_NAME = "rai.function_tool.name"
ATTR_FUNCTION_TOOL_ARGS = "rai.function_tool.arguments"
ATTR_FUNCTION_TOOL_IS_ERROR = "rai.function_tool.is_error"
ATTR_FUNCTION_TOOL_OUTPUT = "rai.function_tool.output"

# tts node
ATTR_TTS_INPUT_TEXT = "rai.input_text"
ATTR_TTS_STREAMING = "rai.tts.streaming"
ATTR_TTS_LABEL = "rai.tts.label"

# eou detection
ATTR_EOU_PROBABILITY = "rai.eou.probability"
ATTR_EOU_UNLIKELY_THRESHOLD = "rai.eou.unlikely_threshold"
ATTR_EOU_DELAY = "rai.eou.endpointing_delay"
ATTR_EOU_LANGUAGE = "rai.eou.language"
ATTR_USER_TRANSCRIPT = "rai.user_transcript"
ATTR_TRANSCRIPT_CONFIDENCE = "rai.transcript_confidence"
ATTR_TRANSCRIPTION_DELAY = "rai.transcription_delay"
ATTR_END_OF_TURN_DELAY = "rai.end_of_turn_delay"

# metrics
ATTR_LLM_METRICS = "rai.llm_metrics"
ATTR_TTS_METRICS = "rai.tts_metrics"
ATTR_REALTIME_MODEL_METRICS = "rai.realtime_model_metrics"

# OpenTelemetry GenAI attributes
# OpenTelemetry specification: https://opentelemetry.io/docs/specs/semconv/registry/attributes/gen-ai/
ATTR_GEN_AI_OPERATION_NAME = "gen_ai.operation.name"
ATTR_GEN_AI_REQUEST_MODEL = "gen_ai.request.model"
ATTR_GEN_AI_USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
ATTR_GEN_AI_USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"

# Unofficial OpenTelemetry GenAI attributes, these are namespaces recognised by LangFuse
# https://langfuse.com/integrations/native/opentelemetry#usage
# but not yet in the official OpenTelemetry specification.
ATTR_GEN_AI_USAGE_INPUT_TEXT_TOKENS = "gen_ai.usage.input_text_tokens"
ATTR_GEN_AI_USAGE_INPUT_AUDIO_TOKENS = "gen_ai.usage.input_audio_tokens"
ATTR_GEN_AI_USAGE_INPUT_CACHED_TOKENS = "gen_ai.usage.input_cached_tokens"
ATTR_GEN_AI_USAGE_OUTPUT_TEXT_TOKENS = "gen_ai.usage.output_text_tokens"
ATTR_GEN_AI_USAGE_OUTPUT_AUDIO_TOKENS = "gen_ai.usage.output_audio_tokens"

# OpenTelemetry GenAI event names (for structured logging)
EVENT_GEN_AI_SYSTEM_MESSAGE = "gen_ai.system.message"
EVENT_GEN_AI_USER_MESSAGE = "gen_ai.user.message"
EVENT_GEN_AI_ASSISTANT_MESSAGE = "gen_ai.assistant.message"
EVENT_GEN_AI_TOOL_MESSAGE = "gen_ai.tool.message"
EVENT_GEN_AI_CHOICE = "gen_ai.choice"

# Exception attributes
ATTR_EXCEPTION_TRACE = "exception.stacktrace"
ATTR_EXCEPTION_TYPE = "exception.type"
ATTR_EXCEPTION_MESSAGE = "exception.message"

# Platform-specific attributes
ATTR_LANGFUSE_COMPLETION_START_TIME = "langfuse.observation.completion_start_time"
