# Copyright 2023 LiveKit, Inc.
# Copyright 2026 RiyadhAI, LLC.
#
# Modifications by RiyadhAI, LLC:
# - Replaced the upstream file header with RiyadhAI attribution for this derivative file.
# - Renamed LiveKit identifiers to RiyadhAI where applicable in this file.
# - Renamed LiveKit identifiers and namespace references to RiyadhAI in this file.
# - Updated branding-related imports, labels, or log text to RiyadhAI where applicable.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0

from __future__ import annotations

from opentelemetry.trace import Span

from riyadhai import rtc

from ..telemetry import trace_types


def _set_participant_attributes(span: Span, participant: rtc.Participant) -> None:
    span.set_attributes(
        {
            trace_types.ATTR_PARTICIPANT_ID: participant.sid,
            trace_types.ATTR_PARTICIPANT_IDENTITY: participant.identity,
            trace_types.ATTR_PARTICIPANT_KIND: rtc.ParticipantKind.Name(participant.kind),
        }
    )
