# Copyright 2023 LiveKit, Inc.
# Copyright 2026 RiyadhAI, LLC.
#
# Modifications by RiyadhAI, LLC:
# - Replaced the upstream file header with RiyadhAI attribution for this derivative file.
# - Renamed LiveKit identifiers to RiyadhAI where applicable in this file.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0

"""RiyadhAI Server APIs for Python

`pip install riyadhai-api`

Manage rooms, participants, egress, ingress, SIP, and Agent dispatch.

Primary entry point is `RiyadhAIAPI`.

See https://docs.riyadhai.io/reference/server/server-apis for more information.
"""

# flake8: noqa
# re-export packages from protocol
from riyadhai.protocol.agent_dispatch import *
from riyadhai.protocol.agent import *
from riyadhai.protocol.egress import *
from riyadhai.protocol.ingress import *
from riyadhai.protocol.models import *
from riyadhai.protocol.room import *
from riyadhai.protocol.webhook import *
from riyadhai.protocol.sip import *
from riyadhai.protocol.connector_whatsapp import *
from riyadhai.protocol.connector_twilio import *

from .twirp_client import TwirpError, TwirpErrorCode
from .riyadhai_api import RiyadhAIAPI
from .access_token import (
    InferenceGrants,
    ObservabilityGrants,
    VideoGrants,
    SIPGrants,
    AccessToken,
    TokenVerifier,
)
from .webhook import WebhookReceiver
from .version import __version__

__all__ = [
    "RiyadhAIAPI",
    "room_service",
    "egress_service",
    "ingress_service",
    "sip_service",
    "agent_dispatch_service",
    "connector_service",
    "InferenceGrants",
    "ObservabilityGrants",
    "VideoGrants",
    "SIPGrants",
    "AccessToken",
    "TokenVerifier",
    "WebhookReceiver",
    "TwirpError",
    "TwirpErrorCode",
]
