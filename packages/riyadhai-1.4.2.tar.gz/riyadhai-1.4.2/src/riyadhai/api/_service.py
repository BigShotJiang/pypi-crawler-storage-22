# Copyright 2023 LiveKit, Inc.
# Copyright 2026 RiyadhAI, LLC.
#
# Modifications by RiyadhAI, LLC:
# - Replaced the upstream file header with RiyadhAI attribution for this derivative file.
# - Renamed LiveKit identifiers to RiyadhAI where applicable in this file.
# - Renamed LiveKit identifiers and namespace references to RiyadhAI in this file.
# - Updated branding-related imports, labels, or log text to RiyadhAI where applicable.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0

from __future__ import annotations

import aiohttp
from abc import ABC
from .twirp_client import TwirpClient
from .access_token import AccessToken, VideoGrants, SIPGrants

AUTHORIZATION = "authorization"


class Service(ABC):
    def __init__(self, session: aiohttp.ClientSession, host: str, api_key: str, api_secret: str):
        self._client = TwirpClient(session, host, "riyadhai")
        self.api_key = api_key
        self.api_secret = api_secret

    def _auth_header(
        self, grants: VideoGrants | None, sip: SIPGrants | None = None
    ) -> dict[str, str]:
        tok = AccessToken(self.api_key, self.api_secret)
        if grants:
            tok.with_grants(grants)
        if sip is not None:
            tok.with_sip_grants(sip)

        token = tok.to_jwt()

        headers = {}
        headers[AUTHORIZATION] = "Bearer {}".format(token)
        return headers
