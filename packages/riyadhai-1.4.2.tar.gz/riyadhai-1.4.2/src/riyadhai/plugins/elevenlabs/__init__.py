# Copyright 2023 LiveKit, Inc.
# Copyright 2026 RiyadhAI, LLC.
#
# Modifications by RiyadhAI, LLC:
# - Replaced the upstream file header with RiyadhAI attribution for this derivative file.
# - Renamed LiveKit identifiers to RiyadhAI where applicable in this file.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0

"""ElevenLabs plugin for RiyadhAI Agents

See https://docs.riyadhai.io/agents/integrations/tts/elevenlabs/ for more information.
"""

from .models import STTRealtimeSampleRates, TTSEncoding, TTSModels
from .stt import STT, SpeechStream
from .tts import DEFAULT_VOICE_ID, TTS, PronunciationDictionaryLocator, Voice, VoiceSettings
from .version import __version__

__all__ = [
    "STT",
    "SpeechStream",
    "TTS",
    "Voice",
    "VoiceSettings",
    "TTSEncoding",
    "TTSModels",
    "STTRealtimeSampleRates",
    "DEFAULT_VOICE_ID",
    "PronunciationDictionaryLocator",
    "__version__",
]

from riyadhai.agents import Plugin

from .log import logger


class ElevenLabsPlugin(Plugin):
    def __init__(self) -> None:
        super().__init__(__name__, __version__, __package__, logger)


Plugin.register_plugin(ElevenLabsPlugin())

# Cleanup docs of unexported modules
_module = dir()
NOT_IN_ALL = [m for m in _module if m not in __all__]

__pdoc__ = {}

for n in NOT_IN_ALL:
    __pdoc__[n] = False
