# Copyright 2023 LiveKit, Inc.
# Copyright 2026 RiyadhAI, LLC.
#
# Modifications by RiyadhAI, LLC:
# - Replaced the upstream file header with RiyadhAI attribution for this derivative file.
# - Renamed LiveKit identifiers to RiyadhAI where applicable in this file.
# - Renamed LiveKit identifiers and namespace references to RiyadhAI in this file.
# - Updated branding-related imports, labels, or log text to RiyadhAI where applicable.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0

import sys
import os

from .plugin import plugin_path, dependencies_path, NC, BVC, BVCTelephony


__all__ = [
    "NC",
    "BVC",
    "BVCTelephony",
]

_loaded = False

def load():
    global _loaded
    if not _loaded:
        _loaded = True

        if "RAI_OVERRIDE_OPENBLAS_NUM_THREADS" not in os.environ:
            os.environ["OPENBLAS_NUM_THREADS"] = "1"

        from riyadhai import rtc

        module = sys.modules[__name__]
        module_id = str(id(module))

        plugin = rtc.AudioFilter(module_id, plugin_path(), dependencies_path())

load()
