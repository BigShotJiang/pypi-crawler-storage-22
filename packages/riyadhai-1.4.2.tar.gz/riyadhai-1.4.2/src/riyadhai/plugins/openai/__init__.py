# Copyright 2023 LiveKit, Inc.
# Copyright 2026 RiyadhAI, LLC.
#
# Modifications by RiyadhAI, LLC:
# - Replaced the upstream file header with RiyadhAI attribution for this derivative file.
# - Renamed LiveKit identifiers to RiyadhAI where applicable in this file.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0

"""OpenAI plugin for RiyadhAI Agents

Support for OpenAI Realtime API, LLM, TTS, and STT APIs.

Also includes support for a large number of OpenAI-compatible APIs including Azure OpenAI, Cerebras,
Fireworks, Perplexity, Telnyx, xAI, Ollama, DeepSeek, OpenRouter, and OVHcloud AI Endpoints.

See https://docs.riyadhai.io/agents/integrations/openai/ and
https://docs.riyadhai.io/agents/integrations/llm/ for more information.
"""

from . import realtime, responses, tools
from .embeddings import EmbeddingData, create_embeddings
from .llm import LLM, LLMStream
from .models import (
    OpenRouterProviderPreferences,
    OpenRouterWebPlugin,
    STTModels,
    TTSModels,
    TTSVoices,
)
from .stt import STT
from .tts import TTS
from .version import __version__

__all__ = [
    "STT",
    "TTS",
    "LLM",
    "LLMStream",
    "OpenRouterProviderPreferences",
    "OpenRouterWebPlugin",
    "STTModels",
    "TTSModels",
    "TTSVoices",
    "create_embeddings",
    "EmbeddingData",
    "realtime",
    "tools",
    "responses",
    "__version__",
]

from riyadhai.agents import Plugin

from .log import logger


class OpenAIPlugin(Plugin):
    def __init__(self) -> None:
        super().__init__(__name__, __version__, __package__, logger)


Plugin.register_plugin(OpenAIPlugin())

# Cleanup docs of unexported modules
_module = dir()
NOT_IN_ALL = [m for m in _module if m not in __all__]

__pdoc__ = {}

for n in NOT_IN_ALL:
    __pdoc__[n] = False
