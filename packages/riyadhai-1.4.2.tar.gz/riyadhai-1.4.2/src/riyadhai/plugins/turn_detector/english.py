# Copyright 2023 LiveKit, Inc.
# Copyright 2026 RiyadhAI, LLC.
#
# Modifications by RiyadhAI, LLC:
# - Replaced the upstream file header with RiyadhAI attribution for this derivative file.
# - Renamed LiveKit identifiers to RiyadhAI where applicable in this file.
# - Renamed LiveKit identifiers and namespace references to RiyadhAI in this file.
# - Updated branding-related imports, labels, or log text to RiyadhAI where applicable.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0

from __future__ import annotations

from riyadhai.agents import Plugin
from riyadhai.agents.inference_runner import _InferenceRunner

from .base import EOUModelBase, EOUPlugin, _EUORunnerBase
from .models import EOUModelType


class _EUORunnerEn(_EUORunnerBase):
    INFERENCE_METHOD = "rai_end_of_utterance_en"

    @classmethod
    def model_type(cls) -> EOUModelType:
        return "en"

    def _normalize_text(self, text: str) -> str:
        """
        The english model is trained on the original chat context without normalization.
        """
        if not text:
            return ""

        return text


class EnglishModel(EOUModelBase):
    def __init__(self, *, unlikely_threshold: float | None = None):
        super().__init__(model_type="en", unlikely_threshold=unlikely_threshold)

    def _inference_method(self) -> str:
        return _EUORunnerEn.INFERENCE_METHOD


_InferenceRunner.register_runner(_EUORunnerEn)
Plugin.register_plugin(EOUPlugin(_EUORunnerEn))
