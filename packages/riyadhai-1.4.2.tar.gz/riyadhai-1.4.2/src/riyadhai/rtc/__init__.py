# Copyright 2023 LiveKit, Inc.
# Copyright 2026 RiyadhAI, LLC.
#
# Modifications by RiyadhAI, LLC:
# - Replaced the upstream file header with RiyadhAI attribution for this derivative file.
# - Renamed LiveKit identifiers to RiyadhAI where applicable in this file.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0

"""RiyadhAI SDK for Python
`pip install riyadhai`

See https://docs.riyadhai.io/home/client/connect/#installing-the-riyadhai-sdk for more information.
"""

from ._proto import stats_pb2 as stats
from ._proto.e2ee_pb2 import EncryptionState, EncryptionType
from ._proto.participant_pb2 import ParticipantKind, DisconnectReason
from ._proto.room_pb2 import (
    ConnectionQuality,
    ConnectionState,
    ContinualGatheringPolicy,
    DataPacketKind,
    IceServer,
    IceTransportType,
    TrackPublishOptions,
    VideoEncoding,
)
from ._proto.track_pb2 import (
    StreamState,
    TrackKind,
    TrackSource,
    ParticipantTrackPermission,
)
from ._proto.video_frame_pb2 import VideoBufferType, VideoCodec, VideoRotation
from .audio_frame import AudioFrame
from .audio_source import AudioSource
from .audio_stream import AudioFrameEvent, AudioStream, NoiseCancellationOptions
from .audio_filter import AudioFilter
from .e2ee import (
    E2EEManager,
    E2EEOptions,
    FrameCryptor,
    KeyProvider,
    KeyProviderOptions,
)
from .participant import (
    LocalParticipant,
    Participant,
    RemoteParticipant,
)
from .room import (
    ConnectError,
    DataPacket,
    Room,
    RoomOptions,
    RtcConfiguration,
    SipDTMF,
    RtcStats,
)
from .track import (
    AudioTrack,
    LocalAudioTrack,
    LocalTrack,
    LocalVideoTrack,
    RemoteAudioTrack,
    RemoteTrack,
    RemoteVideoTrack,
    Track,
    VideoTrack,
)
from .event_emitter import EventEmitter
from .track_publication import (
    LocalTrackPublication,
    RemoteTrackPublication,
    TrackPublication,
)
from .transcription import Transcription, TranscriptionSegment
from .version import __version__
from .video_frame import (
    VideoFrame,
)
from .video_source import VideoSource
from .video_stream import VideoFrameEvent, VideoStream
from .audio_resampler import AudioResampler, AudioResamplerQuality
from .audio_mixer import AudioMixer
from .apm import AudioProcessingModule

try:
    from .media_devices import MediaDevices as MediaDevices

    _HAS_MEDIA_DEVICES = True
except Exception:  # pragma: no cover - optional dependency (sounddevice)
    _HAS_MEDIA_DEVICES = False
from .utils import combine_audio_frames
from .rpc import RpcError, RpcInvocationData
from .synchronizer import AVSynchronizer
from .data_stream import (
    TextStreamInfo,
    ByteStreamInfo,
    TextStreamReader,
    TextStreamWriter,
    ByteStreamWriter,
    ByteStreamReader,
)
from .frame_processor import FrameProcessor

__all__ = [
    "ConnectionQuality",
    "ConnectionState",
    "DataPacketKind",
    "TrackPublishOptions",
    "IceTransportType",
    "ContinualGatheringPolicy",
    "IceServer",
    "EncryptionType",
    "EncryptionState",
    "StreamState",
    "TrackKind",
    "TrackSource",
    "ParticipantTrackPermission",
    "VideoBufferType",
    "VideoRotation",
    "stats",
    "AudioFrame",
    "AudioSource",
    "AudioStream",
    "NoiseCancellationOptions",
    "AudioFilter",
    "AudioFrameEvent",
    "LocalParticipant",
    "Participant",
    "ParticipantKind",
    "DisconnectReason",
    "RemoteParticipant",
    "ConnectError",
    "Room",
    "RoomOptions",
    "RtcConfiguration",
    "SipDTMF",
    "RtcStats",
    "DataPacket",
    "LocalAudioTrack",
    "LocalVideoTrack",
    "RemoteAudioTrack",
    "RemoteVideoTrack",
    "Track",
    "LocalTrack",
    "RemoteTrack",
    "AudioTrack",
    "VideoTrack",
    "E2EEManager",
    "E2EEOptions",
    "KeyProviderOptions",
    "KeyProvider",
    "FrameCryptor",
    "LocalTrackPublication",
    "RemoteTrackPublication",
    "TrackPublication",
    "Transcription",
    "TranscriptionSegment",
    "VideoCodec",
    "VideoEncoding",
    "VideoFrame",
    "VideoFrameEvent",
    "VideoSource",
    "VideoStream",
    "AudioMixer",
    "AudioResampler",
    "AudioResamplerQuality",
    "RpcError",
    "RpcInvocationData",
    "EventEmitter",
    "combine_audio_frames",
    "AVSynchronizer",
    "TextStreamInfo",
    "ByteStreamInfo",
    "TextStreamReader",
    "TextStreamWriter",
    "ByteStreamReader",
    "ByteStreamWriter",
    "AudioProcessingModule",
    "FrameProcessor",
    "__version__",
]

# add MediaDevices if available
if _HAS_MEDIA_DEVICES:
    __all__.append("MediaDevices")
