import os

# যে folder‑গুলোতে __init__.py লাগবে
folders = ["APIS", "Pb2"]

for folder in folders:
    folder_path = os.path.join(os.getcwd(), folder)
    if os.path.exists(folder_path):
        init_file = os.path.join(folder_path, "__init__.py")
        if not os.path.exists(init_file):
            with open(init_file, "w") as f:
                f.write("# Auto __init__.py created\n")
            print(f"Created {init_file}")
        else:
            print(f"{init_file} already exists")
    else:
        print(f"Folder {folder} does not exist")
