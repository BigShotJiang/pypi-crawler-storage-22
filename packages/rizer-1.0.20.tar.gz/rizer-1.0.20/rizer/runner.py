import sys
import os
import signal

def main():
    # Ctrl+C safe exit
    def exit_handler(sig, frame):
        print("\n❌ RIZER stopped by user")
        sys.exit(0)

    signal.signal(signal.SIGINT, exit_handler)

    print("🚀 RIZER Launcher Started\n")

    uid = input("Enter UID: ").strip()
    pw  = input("Enter Password: ").strip()

    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    MAIN_FILE = os.path.join(BASE_DIR, "main.py")

    if not os.path.exists(MAIN_FILE):
        print("❌ main.py not found!")
        return

    # ensure imports work
    sys.path.insert(0, BASE_DIR)
    os.chdir(BASE_DIR)

    try:
        with open(MAIN_FILE, "r", encoding="utf-8") as f:
            source = f.read()
    except Exception as e:
        print("❌ main.py read failed:", e)
        return

    # TEXT replace for UID & PW
    old = "Uid , Pw = 'uiddd','passwordd'"
    new = f"Uid , Pw = '{uid}','{pw}'"
    if old in source:
        source = source.replace(old, new, 1)

    # run main.py code exactly as written
    try:
        exec(compile(source, MAIN_FILE, "exec"), {"__name__": "__main__", "__file__": MAIN_FILE})
    except Exception as e:
        print("❌ Runtime error:", e)