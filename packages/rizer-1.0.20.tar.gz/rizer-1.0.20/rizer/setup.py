from setuptools import setup, find_packages

setup(
    name="RIZER",
    version="1.0.20",
    packages=find_packages(),
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "RIZER=rizer.runner:main"
        ]
    },
)