# RIZER

Free Fire Automation Tool with Terminal Launcher

## 📁 Package Structure

```
RIZER/
├── RIZER/
│   ├── __init__.py
│   ├── rizer_runner.py      # Main launcher
│   ├── main.py              # Your main.py (untouched except UID/PW line)
│   ├── xC4.py
│   ├── xHeaders.py
│   ├── xKEYs.py
│   ├── accounts.json
│   ├── APIS/                # API modules
│   └── Pb2/                 # Protobuf modules
├── setup.py                 # PyPI build config
├── MANIFEST.in              # Package manifest
├── requirements.txt         # Dependencies
└── README.md                # This file
```

## 🚀 Features

- ✅ **main.py untouched** - Only UID/Password line modified (~line 6272)
- ✅ **Password visible** during input (no masking)
- ✅ **ASCII + Color** logo at startup
- ✅ **Clean terminal** - Old text cleared, only logo + prompts visible
- ✅ **Logs preserved** - main.py logs unchanged
- ✅ **Ctrl+C safe exit** - Clean shutdown message
- ✅ **Relative imports fixed** - APIS/ and Pb2/ auto-load
- ✅ **Multi-user support** - Each input isolated
- ✅ **PyPI ready** - Easy install and upgrade

## 📦 Build & Install

### 1. Prepare Your Files

Replace the placeholder files with your actual files:

```bash
# Copy your actual main.py (must contain: Uid , Pw = 'uiddd','passwordd')
cp /path/to/your/main.py RIZER/RIZER/main.py

# Copy other required files
cp /path/to/your/xC4.py RIZER/RIZER/
cp /path/to/your/xHeaders.py RIZER/RIZER/
cp /path/to/your/xKEYs.py RIZER/RIZER/
cp /path/to/your/accounts.json RIZER/RIZER/

# Copy directories
cp -r /path/to/your/APIS/* RIZER/RIZER/APIS/
cp -r /path/to/your/Pb2/* RIZER/RIZER/Pb2/
```

### 2. Build Package

```bash
cd RIZER

# Install build tools
pip install setuptools wheel twine

# Build package
python setup.py sdist bdist_wheel
```

### 3. Upload to PyPI

```bash
# Upload to PyPI (requires account)
twine upload dist/*

# Or upload to Test PyPI first
twine upload --repository testpypi dist/*
```

### 4. Install & Use

```bash
# Install from PyPI
pip install RIZER

# Or upgrade
pip install --upgrade RIZER

# Run
RIZER
```

## 🖥️ Usage

After installation, simply type in terminal:

```bash
RIZER
```

You will see:

```
██████╗░██╗███████╗███████╗██████╗░
██╔══██╗██║╚════██║██╔════╝██╔══██╗
██████╔╝██║░░███╔═╝█████╗░░██████╔╝
██╔══██╗██║██╔══╝░░██╔══╝░░██╔══██╗
██║░░██║██║███████╗███████╗██║░░██║
╚═╝░░╚═╝╚═╝╚══════╝╚══════╝╚═╝░░╚═╝
              RIZER v1.4.0
        Free Fire Automation Tool

╔════════════════════════════════════╗
║     Account Configuration          ║
╚════════════════════════════════════╝

Enter UID: 12345678
Enter Password: yourpassword

⚙️  Updating credentials...
✅ Credentials updated successfully!

🚀 Launching main.py...

[main.py output appears here...]
```

## ⚙️ How It Works

1. **Clear Screen** - Terminal cleared for clean look
2. **ASCII Logo** - Colorful RIZER logo displayed
3. **Input Prompts** - UID and Password entered (visible)
4. **Pattern Match** - Finds line: `Uid , Pw = 'uiddd','passwordd'`
5. **Replace** - Updates with user input, preserves formatting
6. **Execute** - Runs main.py with new credentials
7. **Reset** - Restores default values after execution

## 🛡️ Safety Features

- **No permanent changes** - main.py reset after each run
- **Keyboard interrupt handling** - Safe Ctrl+C exit
- **Missing file warnings** - Continues even if files missing
- **Error handling** - Graceful failures with messages

## 📝 Notes

- main.py must contain the exact pattern: `Uid , Pw = 'uiddd','passwordd'`
- Single quotes preferred but double quotes also supported
- All other lines in main.py remain untouched
- Each user runs with their own credentials
- Logs from main.py displayed in real-time

## 🔧 Troubleshooting

**Import errors?**
- rizer_runner.py automatically fixes Python path
- APIS/ and Pb2/ added to sys.path

**main.py not found?**
- Ensure main.py is in the same directory as rizer_runner.py
- Check file permissions

**Pattern not found?**
- Verify main.py contains: `Uid , Pw = 'uiddd','passwordd'`
- Check for extra spaces or different quote types

## 📄 License

MIT License - See LICENSE file

## 🤝 Support

For support, contact: support@rizer.tool
