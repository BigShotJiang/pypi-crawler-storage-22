#!/usr/bin/env python3
"""
RIZER Launcher - Terminal Entry Point
Handles UID/Password injection and main.py execution
"""

import os
import sys
import re
import subprocess
import shutil
from pathlib import Path

# Color codes for terminal
class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'

def clear_screen():
    """Clear terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_logo():
    """Display colorful ASCII logo"""
    logo = f"""
{Colors.CYAN}{Colors.BOLD}
██████╗░██╗███████╗███████╗██████╗░
██╔══██╗██║╚════██║██╔════╝██╔══██╗
██████╔╝██║░░███╔═╝█████╗░░██████╔╝
██╔══██╗██║██╔══╝░░██╔══╝░░██╔══██╗
██║░░██║██║███████╗███████╗██║░░██║
╚═╝░░╚═╝╚═╝╚══════╝╚══════╝╚═╝░░╚═╝
{Colors.END}
{Colors.GREEN}{Colors.BOLD}              RIZER v1.0.0{Colors.END}
{Colors.YELLOW}        Free Fire Automation Tool{Colors.END}
"""
    print(logo)

def get_package_dir():
    """Get the directory where package is installed"""
    return Path(__file__).parent.absolute()

def check_files():
    """Check for required files and warn if missing"""
    pkg_dir = get_package_dir()
    required = {
        'main.py': pkg_dir / 'main.py',
        'APIS/': pkg_dir / 'APIS',
        'Pb2/': pkg_dir / 'Pb2',
        'accounts.json': pkg_dir / 'accounts.json'
    }

    missing = []
    for name, path in required.items():
        if not path.exists():
            missing.append(name)

    if missing:
        print(f"{Colors.YELLOW}⚠️  Warning: Missing files: {', '.join(missing)}{Colors.END}")
        print(f"{Colors.YELLOW}   Some features may not work correctly.{Colors.END}\n")
        return False
    return True

def update_main_py(uid, password):
    """Update UID and Password in main.py"""
    pkg_dir = get_package_dir()
    main_py = pkg_dir / 'main.py'

    if not main_py.exists():
        print(f"{Colors.RED}❌ Error: main.py not found!{Colors.END}")
        return False

    try:
        # Read content
        with open(main_py, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        # Pattern to match: Uid , Pw = 'uiddd','passwordd'
        # Handle both single and double quotes
        patterns = [
            r"Uid\s*,\s*Pw\s*=\s*'uiddd','passwordd'",
            r'Uid\s*,\s*Pw\s*=\s*"uiddd","passwordd"',
            r"Uid\s*,\s*Pw\s*=\s*'[^']*','[^']*'",
            r'Uid\s*,\s*Pw\s*=\s*"[^"]*","[^"]*"'
        ]

        replacement = f"Uid , Pw = '{uid}','{password}'"

        new_content = None
        for pattern in patterns:
            if re.search(pattern, content):
                new_content = re.sub(pattern, replacement, content)
                break

        if new_content is None:
            # Try line-by-line replacement
            lines = content.split('\n')
            new_lines = []
            found = False
            for line in lines:
                if 'uiddd' in line and 'passwordd' in line:
                    line = re.sub(r"'uiddd'", f"'{uid}'", line)
                    line = re.sub(r'"uiddd"', f'"{uid}"', line)
                    line = re.sub(r"'passwordd'", f"'{password}'", line)
                    line = re.sub(r'"passwordd"', f'"{password}"', line)
                    found = True
                new_lines.append(line)

            if found:
                new_content = '\n'.join(new_lines)

        if new_content is None:
            print(f"{Colors.RED}❌ Error: Could not find UID/Password pattern in main.py{Colors.END}")
            return False

        # Write back
        with open(main_py, 'w', encoding='utf-8') as f:
            f.write(new_content)

        return True

    except Exception as e:
        print(f"{Colors.RED}❌ Error updating main.py: {e}{Colors.END}")
        return False

def reset_main_py():
    """Reset main.py to default values"""
    pkg_dir = get_package_dir()
    main_py = pkg_dir / 'main.py'

    if not main_py.exists():
        return

    try:
        with open(main_py, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        # Reset to defaults
        content = re.sub(r"Uid\s*,\s*Pw\s*=\s*'[^']*','[^']*'", "Uid , Pw = 'uiddd','passwordd'", content)
        content = re.sub(r'Uid\s*,\s*Pw\s*=\s*"[^"]*","[^"]*"', 'Uid , Pw = "uiddd","passwordd"', content)

        with open(main_py, 'w', encoding='utf-8') as f:
            f.write(content)
    except:
        pass

def fix_imports():
    """Fix relative import issues by adding package to path"""
    pkg_dir = get_package_dir()
    if str(pkg_dir) not in sys.path:
        sys.path.insert(0, str(pkg_dir))

    # Also add APIS and Pb2 to path
    apis_dir = pkg_dir / 'APIS'
    pb2_dir = pkg_dir / 'Pb2'

    if apis_dir.exists() and str(apis_dir) not in sys.path:
        sys.path.insert(0, str(apis_dir))
    if pb2_dir.exists() and str(pb2_dir) not in sys.path:
        sys.path.insert(0, str(pb2_dir))

def run_main_py():
    """Execute main.py as raw script"""
    pkg_dir = get_package_dir()
    main_py = pkg_dir / 'main.py'

    if not main_py.exists():
        print(f"{Colors.RED}❌ Error: main.py not found!{Colors.END}")
        return 1

    try:
        # Fix imports before running
        fix_imports()

        # Change to package directory so relative imports work
        original_dir = os.getcwd()
        os.chdir(pkg_dir)

        # Execute main.py
        print(f"{Colors.GREEN}🚀 Launching main.py...{Colors.END}\n")

        # Use subprocess to run in isolated environment but show logs
        env = os.environ.copy()
        env['PYTHONPATH'] = str(pkg_dir)

        result = subprocess.run(
            [sys.executable, str(main_py)],
            cwd=str(pkg_dir),
            env=env
        )

        os.chdir(original_dir)
        return result.returncode

    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}⚠️  Interrupted by user{Colors.END}")
        return 0
    except Exception as e:
        print(f"{Colors.RED}❌ Error running main.py: {e}{Colors.END}")
        return 1

def main():
    """Main entry point"""
    try:
        clear_screen()
        print_logo()

        # Check files (warn but don't crash)
        check_files()

        # Get user input
        print(f"{Colors.CYAN}{Colors.BOLD}╔════════════════════════════════════╗{Colors.END}")
        print(f"{Colors.CYAN}{Colors.BOLD}║     Account Configuration          ║{Colors.END}")
        print(f"{Colors.CYAN}{Colors.BOLD}╚════════════════════════════════════╝{Colors.END}\n")

        uid = input(f"{Colors.GREEN}Enter UID: {Colors.END}").strip()

        if not uid:
            print(f"{Colors.RED}❌ UID cannot be empty!{Colors.END}")
            return 1

        # Password visible during input (as requested)
        password = input(f"{Colors.GREEN}Enter Password: {Colors.END}").strip()

        if not password:
            print(f"{Colors.RED}❌ Password cannot be empty!{Colors.END}")
            return 1

        print(f"\n{Colors.YELLOW}⚙️  Updating credentials...{Colors.END}")

        # Update main.py
        if not update_main_py(uid, password):
            return 1

        print(f"{Colors.GREEN}✅ Credentials updated successfully!{Colors.END}\n")

        # Run main.py
        exit_code = run_main_py()

        # Reset credentials after execution
        reset_main_py()

        return exit_code

    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}\n⚠️  Exiting safely...{Colors.END}")
        reset_main_py()
        return 0
    except Exception as e:
        print(f"{Colors.RED}❌ Unexpected error: {e}{Colors.END}")
        reset_main_py()
        return 1

if __name__ == '__main__':
    sys.exit(main())
