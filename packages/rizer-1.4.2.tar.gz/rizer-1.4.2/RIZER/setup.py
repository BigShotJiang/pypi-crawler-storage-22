#!/usr/bin/env python3
"""
RIZER - Free Fire Automation Tool
Setup configuration for PyPI distribution
"""

from setuptools import setup, find_packages
from pathlib import Path
import os

# Read requirements
def read_requirements():
    req_file = Path(__file__).parent / 'requirements.txt'
    if req_file.exists():
        with open(req_file, encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip() and not line.startswith('#')]
    return []

# Read long description
def read_readme():
    readme_file = Path(__file__).parent / 'README.md'
    if readme_file.exists():
        with open(readme_file, encoding='utf-8') as f:
            return f.read()
    return "RIZER - Free Fire Automation Tool"

setup(
    name='RIZER',
    version='1.4.2',
    author='RIZER Team',
    author_email='support@rizer.tool',
    description='Free Fire Automation Tool with Terminal Launcher',
    long_description=read_readme(),
    long_description_content_type='text/markdown',
    url='https://github.com/rizer/tool',
    packages=find_packages(),

    # Include package data files
    include_package_data=True,

    # Explicitly specify package data for better control
    package_data={
        'RIZER': [
            'main.py',
            'xC4.py',
            'xHeaders.py',
            'xKEYs.py',
            'accounts.json',
            'requirements.txt',
            'APIS/*',
            'APIS/**/*',
            'Pb2/*',
            'Pb2/**/*',
        ],
    },

    # Alternative: use MANIFEST.in for more complex patterns
    # include_package_data=True will respect MANIFEST.in

    install_requires=read_requirements(),

    entry_points={
        'console_scripts': [
            'RIZER=RIZER.rizer_runner:main',
        ],
    },

    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: End Users/Desktop',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Operating System :: OS Independent',
        'Environment :: Console',
        'Topic :: Utilities',
    ],

    python_requires='>=3.7',
    zip_safe=False,

    # Additional metadata
    keywords='free fire, automation, gaming, tool, cli',
    project_urls={
        'Bug Reports': 'https://github.com/rizer/tool/issues',
        'Source': 'https://github.com/rizer/tool',
    },
)
