#!/usr/bin/env python3
"""
RIZER Test Suite
Tests for rizer_runner functionality
"""

import unittest
import sys
import os
import tempfile
import shutil
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from RIZER.rizer_runner import Colors

class TestRIZERRunner(unittest.TestCase):

    def setUp(self):
        """Create temporary directory for tests"""
        self.test_dir = tempfile.mkdtemp()
        self.test_main = Path(self.test_dir) / 'main.py'

        # Create test main.py with pattern
        test_content = """
# Test main.py
Uid , Pw = 'uiddd','passwordd'

def main():
    print(f"UID: {Uid}")
    print(f"PW: {Pw}")
"""
        self.test_main.write_text(test_content)

    def tearDown(self):
        """Clean up temporary directory"""
        shutil.rmtree(self.test_dir)

    def test_update_main_py_pattern(self):
        """Test UID/Password pattern exists"""
        content = self.test_main.read_text()
        self.assertIn("'uiddd'", content)
        self.assertIn("'passwordd'", content)

    def test_colors_exist(self):
        """Test color codes are defined"""
        self.assertTrue(hasattr(Colors, 'RED'))
        self.assertTrue(hasattr(Colors, 'GREEN'))
        self.assertTrue(hasattr(Colors, 'CYAN'))
        self.assertTrue(hasattr(Colors, 'END'))

class TestPackageStructure(unittest.TestCase):

    def test_package_files_exist(self):
        """Test that all required files exist"""
        package_dir = Path(__file__).parent.parent / 'RIZER'

        required_files = [
            '__init__.py',
            'rizer_runner.py',
            'main.py',
        ]

        for file in required_files:
            path = package_dir / file
            self.assertTrue(path.exists(), f"Missing required file: {file}")

    def test_entry_point(self):
        """Test that entry point function exists"""
        from RIZER.rizer_runner import main
        self.assertTrue(callable(main))

def run_tests():
    """Run the test suite"""
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    suite.addTests(loader.loadTestsFromTestCase(TestRIZERRunner))
    suite.addTests(loader.loadTestsFromTestCase(TestPackageStructure))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    return result.wasSuccessful()

if __name__ == '__main__':
    success = run_tests()
    sys.exit(0 if success else 1)
