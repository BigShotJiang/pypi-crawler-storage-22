GET_STATUS_SWITCH = "get_status_v2_enabled"
