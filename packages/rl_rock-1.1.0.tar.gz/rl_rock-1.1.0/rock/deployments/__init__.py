from rock.deployments.config import get_deployment

__all__ = ["get_deployment"]
