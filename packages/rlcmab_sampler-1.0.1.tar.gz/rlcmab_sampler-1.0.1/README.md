# rlcmab-sampler

A reward sampler for Contextual Bandit news recommendation systems.

## Installation

```bash
pip install rlcmab-sampler
```

## Quick Start

```python
from sampler import sampler

# Initialize with your roll number (i)
reward_sampler = sampler(i=42)

# Get a reward from arm j
reward = reward_sampler.sample(j=5)
print(reward)

# Sample a few arms
for j in range(3):
    print(j, reward_sampler.sample(j))
```

## API Reference

### `sampler(i, n_arms=12)`

Initialize a new sampler instance.

**Parameters:**

- `i` (int): Student ID used to seed the random number generator
- `n_arms` (int, optional): Number of arms/articles. Default: 12

**Attributes:**

- `means`: List of mean values for each Gaussian distribution
- `stds`: List of standard deviations for each Gaussian distribution
- `distributions`: List of scipy.stats.norm distribution objects

### `sample(j)`

Sample a reward from the specified arm.

**Parameters:**

- `j` (int): Arm index (must be between 0 and 11)

**Returns:**

- `float`: Reward value sampled from the arm's Gaussian distribution

**Raises:**

- `ValueError`: If `j` is not in the valid range [0, 11]

## Reproducibility

For the same student ID `i`, the generated arm distributions remain the same
across runs. Different student IDs map to different distributions.

## License

[MIT License](LICENSE)
