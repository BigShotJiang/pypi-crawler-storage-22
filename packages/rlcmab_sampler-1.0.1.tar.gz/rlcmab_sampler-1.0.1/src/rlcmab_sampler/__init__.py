import numpy as np
import scipy.stats as stats


class sampler:
    """
    Gaussian reward sampler for Contextual Bandit news recommendation.

    Properties:
    - Same i → same hidden distributions
    - Strong separation across students
    - 12 Gaussian arms
    - Continuous rewards (old behavior preserved)
    """

    def __init__(self, i, n_arms=12):
        self.i = int(i)
        self.n_arms = n_arms

        seed = self._derive_seed(self.i)
        self.rng = np.random.default_rng(seed)

        self.means, self.stds = self._generate_gaussian_parameters()

        self.distributions = [
            stats.norm(m, s) for m, s in zip(self.means, self.stds)
        ]

    def _derive_seed(self, i):
        return (i * 2654435761) % (2**32)

    def _generate_gaussian_parameters(self):
        base_means = np.linspace(-8.0, 8.0, self.n_arms)
        noise = self.rng.normal(0.0, 2.0, size=self.n_arms)

        means = base_means + noise
        self.rng.shuffle(means)

        stds = self.rng.uniform(0.8, 1.4, size=self.n_arms)
        return means.tolist(), stds.tolist()

    def sample(self, j):
        if not (0 <= j < self.n_arms):
            raise ValueError("Index j must be between 0 and 11.")
        return self.distributions[j].rvs()


# Explicit public API
__all__ = ["sampler"]
__author__ = "Saswata Sarkar"