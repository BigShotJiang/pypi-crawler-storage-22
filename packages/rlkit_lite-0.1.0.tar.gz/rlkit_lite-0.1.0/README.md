# RLKit

一个轻量级的强化学习练手项目，包含：

- Tabular：Q-Learning
- Value-based：DQN / Double DQN（MLP 与 Atari CNN）
- Policy-based：REINFORCE、PPO

## 环境准备

推荐使用 `uv`：

```bash
uv sync
```

如果你只想补装 Atari 依赖：

```bash
uv pip install ale-py
```

## 目录结构（当前实现）

```text
rlkit/
├── pyproject.toml
├── README.md
├── main.py
└── rlkit/
	├── algo/
	│   ├── dqn/dqn.py
	│   ├── tabular/q_learning.py
	│   └── pg/
	│       ├── reinforce.py
	│       └── ppo.py
	├── core/
	│   ├── agent.py
	│   ├── buffer.py
	│   └── trainer.py
	├── envs/
	│   ├── __init__.py
	│   └── atari.py
	├── models/
	│   ├── mlp.py
	│   └── cnn.py
	├── utils/
	│   ├── logger.py
	│   ├── replay.py
	│   └── seed.py
	└── experiments/
		├── run_q_learning.py
		├── run_dqn_classic.py
		├── run_dqn_atari.py
		├── run_dqn_atari_eval.py
		├── run_reinforce.py
		└── run_ppo.py
```

## 快速运行

在项目根目录执行（`/home/user/projects/rlkit`）：

```bash
uv run python rlkit/experiments/run_q_learning.py
uv run python rlkit/experiments/run_dqn_classic.py
uv run python rlkit/experiments/run_dqn_atari.py
uv run python rlkit/experiments/run_reinforce.py
uv run python rlkit/experiments/run_ppo.py
```

如果你在包目录执行（`/home/dj/projects/rlkit/rlkit`），对应命令为：

```bash
uv run python ./experiments/run_q_learning.py
uv run python ./experiments/run_dqn_classic.py
uv run python ./experiments/run_dqn_atari.py
uv run python ./experiments/run_reinforce.py
uv run python ./experiments/run_ppo.py
```

## 产物说明

- 训练日志会打印每轮 reward 与滑动平均
- 训练曲线默认保存到 `./log/*.png`
- 模型参数默认保存到 `./checkpoints/*.pt`

## 常见问题

### 1) Atari 训练提前结束，退出码是 137

通常是内存不足（OOM）导致进程被系统 kill。优先降低：

- `--buffer_size`（例如先试 `20000`）
- `--batch_size`

### 2) PPO 日志里 reward 看起来异常大

PPO 目前按 rollout 采样训练，日志中还会包含 rollout 统计字段。建议结合：

- `reward`（更接近真实 episode 回报）
- `rollout_reward`
- `completed_episodes`

## 更多实验参数

完整实验脚本参数说明见：`rlkit/experiments/README.md`