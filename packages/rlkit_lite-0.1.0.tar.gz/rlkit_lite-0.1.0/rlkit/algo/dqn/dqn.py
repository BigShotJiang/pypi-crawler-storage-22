import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from typing import Any

from rlkit.core.agent import Agent
from rlkit.core.buffer import ReplayBuffer
from rlkit.models.cnn import CNNQNetwork
from rlkit.models.mlp import MLP


class DQNAgent(Agent):
    def __init__(
        self,
        obs_dim,
        act_dim,
        lr=1e-3,
        gamma=0.99,
        epsilon=0.1,
        epsilon_min=0.05,
        epsilon_decay=0.995,
        buffer_size=100000,
        batch_size=64,
        target_update_freq=100,
        use_double_dqn=True,
        net_type="mlp",
        device="cuda" if torch.cuda.is_available() else "cpu",
    ):
        if isinstance(obs_dim, int):
            obs_shape = (obs_dim,)
        else:
            obs_shape = tuple(obs_dim)

        self.obs_shape = obs_shape
        self.net_type = net_type.lower()
        self.act_dim = act_dim
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.epsilon_decay = epsilon_decay
        self.batch_size = batch_size
        self.target_update_freq = target_update_freq
        self.use_double_dqn = use_double_dqn
        self.device = device

        if self.net_type not in {"mlp", "cnn"}:
            raise ValueError("net_type must be one of: 'mlp', 'cnn'")

        if self.net_type == "mlp":
            in_dim = int(np.prod(self.obs_shape))
            self.q_net = MLP(in_dim, act_dim).to(device)
            self.target_net = MLP(in_dim, act_dim).to(device)
        else:
            if len(self.obs_shape) != 3:
                raise ValueError("CNN requires obs shape with 3 dims, got: %s" % (self.obs_shape,))

            c, h, w = self._infer_chw_shape(self.obs_shape)
            self.cnn_obs_shape = (c, h, w)
            self.q_net = CNNQNetwork(self.cnn_obs_shape, act_dim).to(device)
            self.target_net = CNNQNetwork(self.cnn_obs_shape, act_dim).to(device)

        self.target_net.load_state_dict(self.q_net.state_dict())

        self.optimizer = optim.Adam(self.q_net.parameters(), lr=lr)
        self.loss_fn = nn.MSELoss()

        self.buffer = ReplayBuffer(buffer_size, self.obs_shape, act_dim)

        self.step_count = 0

    def act(self, obs, explore=True):
        if explore and np.random.rand() < self.epsilon:
            return np.random.randint(self.act_dim)

        obs_tensor = self._obs_to_tensor(obs, add_batch_dim=True)
        with torch.no_grad():
            q_values = self.q_net(obs_tensor)
        return q_values.argmax(dim=1).item()

    def observe(self, transition: Any):
        """Accept either a transition dict (preferred) or a tuple/list.

        Expected dict keys: `obs`, `action`, `reward`, `next_obs`, `done`.
        """
        if isinstance(transition, dict):
            obs = transition["obs"]
            act = transition["action"]
            reward = transition["reward"]
            next_obs = transition["next_obs"]
            done = transition["done"]
        else:
            obs, act, reward, next_obs, done = tuple(transition)

        self.buffer.add(obs, act, reward, next_obs, done)

    def update(self):
        if len(self.buffer) < self.batch_size:
            return

        batch = self.buffer.sample(self.batch_size)

        obs = self._obs_to_tensor(batch["obs"], add_batch_dim=False)
        act = torch.tensor(batch["action"], dtype=torch.long).to(self.device)
        reward = torch.tensor(batch["reward"], dtype=torch.float32).to(self.device)
        next_obs = self._obs_to_tensor(batch["next_obs"], add_batch_dim=False)
        done = torch.tensor(batch["done"], dtype=torch.float32).to(self.device)

        # 当前 Q
        q_values = self.q_net(obs)
        q_value = q_values.gather(1, act.unsqueeze(1)).squeeze(1)

        # 目标 Q
        with torch.no_grad():
            if self.use_double_dqn:
                next_actions = self.q_net(next_obs).argmax(dim=1, keepdim=True)
                next_q = self.target_net(next_obs).gather(1, next_actions).squeeze(1)
            else:
                next_q = self.target_net(next_obs).max(dim=1)[0]
            target = reward + self.gamma * next_q * (1 - done)

        loss = self.loss_fn(q_value, target)

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        # Target network 更新
        if self.step_count % self.target_update_freq == 0:
            self.target_net.load_state_dict(self.q_net.state_dict())

        self.step_count += 1

    def decay_epsilon(self):
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)

    @staticmethod
    def _infer_chw_shape(obs_shape):
        if len(obs_shape) != 3:
            raise ValueError("Expected 3D observation shape for CNN")

        if obs_shape[0] in (1, 3, 4):
            return obs_shape[0], obs_shape[1], obs_shape[2]

        if obs_shape[2] in (1, 3, 4):
            return obs_shape[2], obs_shape[0], obs_shape[1]

        raise ValueError(
            "Cannot infer channel dimension automatically. Use 3D obs shape with channel size 1/3/4."
        )

    def _obs_to_tensor(self, obs, add_batch_dim: bool):
        obs_np = np.asarray(obs, dtype=np.float32)

        if self.net_type == "mlp":
            if add_batch_dim:
                obs_np = obs_np.reshape(1, -1)
            else:
                obs_np = obs_np.reshape(obs_np.shape[0], -1)
            return torch.tensor(obs_np, dtype=torch.float32, device=self.device)

        if add_batch_dim:
            if obs_np.ndim == 3:
                obs_np = np.expand_dims(obs_np, axis=0)
            elif obs_np.ndim != 4:
                raise ValueError("CNN expects obs ndim 3 or 4")
        else:
            if obs_np.ndim != 4:
                raise ValueError("CNN batch expects obs ndim 4")

        if obs_np.shape[1] != self.cnn_obs_shape[0] and obs_np.shape[-1] == self.cnn_obs_shape[0]:
            obs_np = np.transpose(obs_np, (0, 3, 1, 2))

        if obs_np.max() > 1.0:
            obs_np = obs_np / 255.0

        return torch.tensor(obs_np, dtype=torch.float32, device=self.device)
