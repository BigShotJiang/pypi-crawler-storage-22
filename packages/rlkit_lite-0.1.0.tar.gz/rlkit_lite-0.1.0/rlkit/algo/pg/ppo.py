import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

from rlkit.core.agent import Agent
from rlkit.models.mlp import MLP
from rlkit.core.buffer import TrajectoryBuffer


class PPOAgent(Agent):
    def __init__(
        self,
        obs_dim,
        act_dim,
        lr=3e-4,
        gamma=0.99,
        lam=0.95,
        clip_ratio=0.2,
        train_iters=10,
        buffer_size=4000,
        device="cpu",
    ):
        self.gamma = gamma
        self.clip_ratio = clip_ratio
        self.train_iters = train_iters
        self.device = device

        self.policy_net = MLP(obs_dim, act_dim).to(self.device)
        self.value_net = MLP(obs_dim, 1).to(self.device)

        self.optimizer = optim.Adam(
            list(self.policy_net.parameters()) +
            list(self.value_net.parameters()),
            lr=lr
        )

        self.buffer = TrajectoryBuffer(obs_dim, buffer_size, gamma, lam)

    def act(self, obs, explore=True):
        obs = torch.tensor(obs, dtype=torch.float32, device=self.device)
        logits = self.policy_net(obs)
        dist = torch.distributions.Categorical(logits=logits)
        action = dist.sample()
        value = self.value_net(obs)

        return action.item(), value.item(), dist.log_prob(action).item()

    def observe(self, data):
        obs, act, rew, val, logp = data
        self.buffer.add(obs, act, rew, val, logp)

    def finish_path(self, last_val=0.0):
        self.buffer.finish_path(last_val)

    def update(self):
        data = self.buffer.get()

        obs = torch.tensor(data["obs"], dtype=torch.float32, device=self.device)
        act = torch.tensor(data["act"], device=self.device)
        adv = torch.tensor(data["adv"], dtype=torch.float32, device=self.device)
        ret = torch.tensor(data["ret"], dtype=torch.float32, device=self.device)
        old_logp = torch.tensor(data["logp"], dtype=torch.float32, device=self.device)

        for _ in range(self.train_iters):
            logits = self.policy_net(obs)
            dist = torch.distributions.Categorical(logits=logits)
            logp = dist.log_prob(act)

            ratio = torch.exp(logp - old_logp)
            clipped = torch.clamp(ratio, 1 - self.clip_ratio, 1 + self.clip_ratio)

            policy_loss = -(torch.min(ratio * adv, clipped * adv)).mean()

            value = self.value_net(obs).squeeze()
            value_loss = ((value - ret) ** 2).mean()

            loss = policy_loss + 0.5 * value_loss

            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()