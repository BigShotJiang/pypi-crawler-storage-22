import torch 
import torch.nn as nn
import torch.optim as optim
import numpy as np

from rlkit.core.agent import Agent
from rlkit.models.mlp import MLP

class REINFORCEAgent(Agent):
    def __init__(self, obs_dim, act_dim, hidden_sizes=(64, 64), lr=1e-3, gamma=0.99, device="cpu"):
        super().__init__()
        self.gamma = gamma
        self.device = device

        self.policy_net = MLP(obs_dim, act_dim, hidden_sizes).to(device)
        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=lr)

        self.obs_buf = []
        self.act_buf = []
        self.rew_buf = []

    def act(self, obs):
        obs = torch.tensor(obs, dtype=torch.float32)
        logits = self.policy_net(obs)
        dist = torch.distributions.Categorical(logits=logits)
        action = dist.sample()
        return action.item()

    def observe(self, transition):
        """ 
            Observe a transition (obs, act, rew, next_obs, done) and store it in the buffer. If done is True, update the policy.
            Args:
            transition: A tuple (obs, act, rew, next_obs, done) representing a single step in the environment.
        """
        obs, act, rew, _, done = transition
        self.obs_buf.append(obs)
        self.act_buf.append(act)
        self.rew_buf.append(rew)

        if done:
            self.update()

    def update(self):
        returns = []
        G = 0
        for r in reversed(self.rew_buf):
            G = r + self.gamma * G
            returns.insert(0, G)

        returns = torch.tensor(returns, dtype=torch.float32)
        obs = torch.tensor(self.obs_buf, dtype=torch.float32)
        act = torch.tensor(self.act_buf)

        logits = self.policy_net(obs)
        dist = torch.distributions.Categorical(logits=logits)
        log_probs = dist.log_prob(act)

        loss = -(log_probs * returns).mean()

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        self.obs_buf, self.act_buf, self.rew_buf = [], [], []
