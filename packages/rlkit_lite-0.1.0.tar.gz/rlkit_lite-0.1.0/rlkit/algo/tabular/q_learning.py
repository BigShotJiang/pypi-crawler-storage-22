import numpy as np
import gymnasium as gym 
from typing import Any

from rlkit.core.agent import Agent

class QLearningAgent(Agent):
    """
    Implements a simple tabular Q-learning agent.
    """

    def __init__(
        self,
        action_space: gym.spaces.Space,
        learning_rate=0.1,
        gamma=0.99,
        epsilon=0.1,
        epsilon_min=0.05,
        epsilon_decay=0.995,
    ):
        # accept a generic Space for better compatibility with callers
        # but ensure at runtime it's Discrete since Q-learning requires discrete actions
        if not isinstance(action_space, gym.spaces.Discrete):
            raise TypeError("QLearningAgent requires a Discrete action_space")
        self.action_space: gym.spaces.Discrete = action_space
        self.learning_rate = learning_rate
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.epsilon_decay = epsilon_decay
        self.q_table = {}

    def act(self, observation: Any, explore=True):
        if explore and np.random.rand() < self.epsilon:  # epsilon-greedy exploration
            return self.action_space.sample()
        
        state_key = self._state_key(observation)
        if state_key not in self.q_table:
            self.q_table[state_key] = np.zeros(self.action_space.n)
        
        return np.argmax(self.q_table[state_key])

    def observe(self, transition: dict):
        obs = transition["obs"]
        action = transition["action"]
        reward = transition["reward"]
        next_obs = transition["next_obs"]
        done = transition["done"]

        state_key = self._state_key(obs)
        next_state_key = self._state_key(next_obs)

        if state_key not in self.q_table:
            self.q_table[state_key] = np.zeros(self.action_space.n)
        
        if next_state_key not in self.q_table:
            self.q_table[next_state_key] = np.zeros(self.action_space.n)

        best_next_q = np.max(self.q_table[next_state_key])
        td_target = reward + (0 if done else self.gamma * best_next_q)
        td_error = td_target - self.q_table[state_key][action]
        
        self.q_table[state_key][action] += self.learning_rate * td_error

    def update(self):
        pass

    def reset(self):
        pass

    def decay_epsilon(self) -> None:
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)

    def _state_key(self, observation: Any):
        """
        Convert an observation to a hashable key for the Q-table.
        - If observation is array-like (np.ndarray, list, tuple), convert to tuple
        - Otherwise (e.g., discrete int) convert to a single-element tuple containing int
        """
        if isinstance(observation, np.ndarray):
            return tuple(observation.tolist())

        if isinstance(observation, (list, tuple)):
            return tuple(observation)

        # Fallback: treat as scalar (e.g., Discrete observation returned as int)
        try:
            return (int(observation),)
        except Exception:
            # As a last resort, use the object itself if it's hashable
            return observation