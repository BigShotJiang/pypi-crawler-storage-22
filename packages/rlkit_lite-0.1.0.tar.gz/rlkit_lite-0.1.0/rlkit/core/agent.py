from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
import numpy as np


class Agent(ABC):    
    """
    Agent 抽象基类

    职责：
    - 接收环境观测
    - 输出动作
    - 管理 episode 内部状态（如 RNN hidden state）
    """

    # ======== 核心接口 =========

    @abstractmethod
    def act(self, observation: np.ndarray, explore=True) -> Any:
        """
        根据 observation 输出一个动作
        参数：
        - observation: 来自环境的观测
        返回：
        - action: agent 选择的动作
        """
        raise NotImplementedError
    
    def observe(self, transition: Dict[str, np.ndarray]) -> None:
        """
        接收环境产生的数据
        参数：
        - transition: 包含 obs, action, reward, next_obs, done 的字典
        """
        pass

    def update(self) -> None:
        """ 更新策略 """
        raise NotImplementedError

    def reset(self) -> None:
        """
        重置 agent 的内部状态（如 RNN hidden state）。
        在每个 episode 开始时调用。

        默认实现什么也不做；有需要的子类可以覆盖此方法来清除
        episode 级别的内部状态（例如 RNN hidden states 或计数器）。
        """
        pass

    def decay_epsilon(self) -> None:
        """
        可选：在每个 episode 结束后调用，用于衰减探索率。
        默认不做任何操作。
        """
        pass
