import numpy as np


class ReplayBuffer:
    def __init__(self, capacity, obs_shape, action_dim):
        self.capacity = capacity
        if isinstance(obs_shape, int):
            obs_shape = (obs_shape,)
        self.obs_shape = tuple(obs_shape)

        self.obs_buf = np.zeros((capacity, *self.obs_shape), dtype=np.float32)
        self.next_obs_buf = np.zeros((capacity, *self.obs_shape), dtype=np.float32)
        self.action_buf = np.zeros(capacity, dtype=np.int64)
        self.reward_buf = np.zeros(capacity, dtype=np.float32)
        self.done_buf = np.zeros(capacity, dtype=np.float32)

        self.ptr = 0
        self.size = 0

    def add(self, obs, action, reward, next_obs, done):
        self.obs_buf[self.ptr] = obs
        self.next_obs_buf[self.ptr] = next_obs
        self.action_buf[self.ptr] = action
        self.reward_buf[self.ptr] = reward
        self.done_buf[self.ptr] = done

        self.ptr = (self.ptr + 1) % self.capacity
        self.size = min(self.size, self.capacity - 1) + 1
    
    def sample(self, batch_size):
        idx = np.random.randint(0, self.size, size=batch_size)
        return dict(
            obs=self.obs_buf[idx],
            action=self.action_buf[idx],
            reward=self.reward_buf[idx],
            next_obs=self.next_obs_buf[idx],
            done=self.done_buf[idx],
        )
    
    def __len__(self):
        return self.size
    

class TrajectoryBuffer:
    def __init__(self, obs_dim, size, gamma=0.99, lam=0.95):
        self.obs_buf = np.zeros((size, obs_dim), dtype=np.float32)
        self.act_buf = np.zeros(size, dtype=np.int64)
        self.rew_buf = np.zeros(size, dtype=np.float32)
        self.val_buf = np.zeros(size, dtype=np.float32)
        self.logp_buf = np.zeros(size, dtype=np.float32)

        self.adv_buf = np.zeros(size, dtype=np.float32)
        self.ret_buf = np.zeros(size, dtype=np.float32)

        self.gamma = gamma
        self.lam = lam

        self.ptr = 0
        self.path_start_idx = 0
        self.max_size = size

    def add(self, obs, act, rew, val, logp):
        """
        Add a trajectory segment to the buffer.
        Args:
            obs: Observation at the current timestep
            act: Action taken at the current timestep
            rew: Reward received after taking the action
            val: Estimated value of the current state
            logp: Log probability of the action under the current policy
        """
        assert self.ptr < self.max_size
        self.obs_buf[self.ptr] = obs
        self.act_buf[self.ptr] = act
        self.rew_buf[self.ptr] = rew
        self.val_buf[self.ptr] = val
        self.logp_buf[self.ptr] = logp 
        self.ptr += 1

    def finish_path(self, last_val=0):
        """
        Compute advantage estimates and returns for the trajectory segment.
        Args:
            last_val: The value estimate for the final state (0 if trajectory ended)
        """
        path_slice = slice(self.path_start_idx, self.ptr)
        rews = np.append(self.rew_buf[path_slice], last_val)
        vals = np.append(self.val_buf[path_slice], last_val)

        # GAE-Lambda
        deltas = rews[:-1] + self.gamma * vals[1:] - vals[:-1]
        adv = self.discount_cumsum(deltas, self.gamma * self.lam)
        ret = self.discount_cumsum(rews, self.gamma)[:-1]

        self.adv_buf[path_slice] = adv
        self.ret_buf[path_slice] = ret

        self.path_start_idx = self.ptr

    def get(self):
        """
        Retrieve all data from the buffer and reset pointers.
        Returns:
            A dictionary containing observations, actions, advantages, returns, log probabilities, and values.
        """
        assert self.ptr == self.max_size  # Buffer must be full before getting data
        self.ptr = 0
        self.path_start_idx = 0

        # Normalize advantages
        adv_mean = np.mean(self.adv_buf)
        adv_std = np.std(self.adv_buf) + 1e-8
        self.adv_buf = (self.adv_buf - adv_mean) / adv_std

        return dict(
            obs=self.obs_buf,
            act=self.act_buf,
            adv=self.adv_buf,
            ret=self.ret_buf,
            logp=self.logp_buf,
        )

    @staticmethod
    def discount_cumsum(x, discount):
        result = np.zeros_like(x)
        running = 0
        for t in reversed(range(len(x))):
            running = x[t] + discount * running
            result[t] = running
        return result