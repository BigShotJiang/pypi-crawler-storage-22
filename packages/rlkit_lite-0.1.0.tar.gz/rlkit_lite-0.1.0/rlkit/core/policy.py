import torch

class Policy:
    def act(self, obs: torch.Tensor) -> torch.Tensor:
        """
        Given an observation, return an action.
        Args:
            obs: A tensor representing the current observation from the environment.
            Returns: A tensor representing the action to take in response to the observation.
        """
        raise NotImplementedError
    
    def evaluate(self, obs: torch.Tensor, act: torch.Tensor) -> torch.Tensor:
        """
        Given an observation, return the action probabilities or Q-values for evaluation.
        Args:
            obs: A tensor representing the current observation from the environment.
            act: A tensor representing the action to evaluate.
            Returns: log_prob or Q-value tensor for the given observation and action.
        """
        raise NotImplementedError