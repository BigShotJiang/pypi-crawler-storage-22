from rlkit.utils.logger import Logger
from rlkit.utils.replay import save_ansi_frames_to_gif, save_ansi_frames_to_txt
from typing import Optional, Any
import gymnasium as gym
from rlkit.core.agent import Agent



class Trainer:
    def __init__(self, env: gym.Env, agent: Agent, logger: Optional[Logger] = None) -> None:
        self.env: gym.Env = env
        self.agent: Agent = agent
        self.logger: Optional[Logger] = logger

    def train(self, num_episodes: int, max_steps_per_episode: int) -> None:
        rewards = []

        for episode in range(num_episodes):
            obs, _ = self.env.reset()
            self.agent.reset()
            episode_reward: float = 0.0

            for step in range(max_steps_per_episode):
                action = self.agent.act(obs)
                next_obs, reward, terminated, truncated, _ = self.env.step(action)
                done = terminated or truncated

                transition = { "obs": obs, 
                              "action": action, 
                              "reward": reward, 
                              "next_obs": next_obs, 
                              "done": done }
                
                self.agent.observe(transition)

                self.agent.update()

                obs = next_obs
                episode_reward = episode_reward + float(reward)
                if done:
                    break
            rewards.append(episode_reward)
            if self.logger:
                window_size = min(100, len(rewards))
                avg_reward_100 = sum(rewards[-window_size:]) / window_size
                self.logger.log(
                    {
                        "episode": episode,
                        "reward": episode_reward,
                        "avg_reward_100": avg_reward_100,
                    }
                )
            self.agent.decay_epsilon()

    def evaluate(
        self,
        num_episodes: int,
        max_steps_per_episode: int,
        replay_txt_path: Optional[str] = None,
        replay_gif_path: Optional[str] = None,
    ) -> float:
        rewards = 0.0
        replay_frames = []
        capture_replay = replay_txt_path is not None or replay_gif_path is not None

        for _ in range(num_episodes):
            obs, _ = self.env.reset()
            self.agent.reset()
            episode_reward: float = 0.0
            frames = []

            for _ in range(max_steps_per_episode):
                if capture_replay:
                    frames.append(self.env.render())
                action = self.agent.act(obs, explore=False)
                next_obs, reward, terminated, truncated, _ = self.env.step(action)
                done = terminated or truncated

                obs = next_obs
                episode_reward += float(reward)
                if done:
                    rewards += episode_reward
                    if capture_replay and not replay_frames:
                        replay_frames = frames
                    break

        if capture_replay and replay_frames:
            if replay_txt_path:
                save_ansi_frames_to_txt(replay_frames, replay_txt_path)
            if replay_gif_path:
                save_ansi_frames_to_gif(replay_frames, replay_gif_path)

        return rewards / num_episodes