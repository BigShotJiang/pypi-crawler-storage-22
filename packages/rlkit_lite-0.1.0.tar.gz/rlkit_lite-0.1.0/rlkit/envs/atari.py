import gymnasium as gym
from gymnasium.wrappers import AtariPreprocessing


def _ensure_ale_registered() -> None:
    try:
        import ale_py
    except ImportError as exc:
        raise ImportError(
            "Atari support requires `ale-py`. Install deps with `uv sync` or `uv pip install ale-py`."
        ) from exc

    gym.register_envs(ale_py)


def _wrap_frame_stack(env: gym.Env, num_stack: int) -> gym.Env:
    frame_stack_cls = getattr(gym.wrappers, "FrameStack", None)
    if frame_stack_cls is not None:
        return frame_stack_cls(env, num_stack=num_stack)

    frame_stack_obs_cls = getattr(gym.wrappers, "FrameStackObservation", None)
    if frame_stack_obs_cls is not None:
        return frame_stack_obs_cls(env, stack_size=num_stack)

    raise RuntimeError("No FrameStack wrapper found in current gymnasium version")


def build_atari_env(env_id: str, frame_stack: int, screen_size: int, render_mode: str | None = None) -> gym.Env:
    """
    Build an Atari environment with standard preprocessing (grayscale + resize) and frame stacking.
    Args:
        env_id: The Atari environment ID (e.g. "ALE/Pong-v5")
        frame_stack: Number of frames to stack for the observation
        screen_size: The size to which the Atari frames will be resized (e.g. 84)
        render_mode: Optional render mode for the environment (e.g. "rgb_array" for evaluation)
    Returns:
        A Gym environment with the specified preprocessing and frame stacking applied.
    """
    _ensure_ale_registered()
    env = gym.make(env_id, frameskip=1, repeat_action_probability=0.0, render_mode=render_mode)
    env = AtariPreprocessing(
        env,
        frame_skip=4,
        terminal_on_life_loss=False,
        screen_size=screen_size,
        grayscale_obs=True,
        grayscale_newaxis=False,
        scale_obs=False,
    )
    env = _wrap_frame_stack(env, num_stack=frame_stack)
    return env