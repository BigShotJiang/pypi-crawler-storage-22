from rlkit.utils.logger import Logger
from rlkit.utils.seed import set_global_seed
import gymnasium as gym
from gymnasium.spaces import Discrete
from rlkit.algo.dqn.dqn import DQNAgent
from rlkit.core.trainer import Trainer


def main():
    set_global_seed(42, deterministic_torch=True)
    env = gym.make("CartPole-v1")

    if env.observation_space.shape is None:
        raise TypeError("DQNAgent requires a Box observation space with fixed shape")
    obs_shape = env.observation_space.shape
    if not isinstance(env.action_space, Discrete):
        raise TypeError("DQNAgent currently requires a Discrete action space")
    act_dim = env.action_space.n

    agent = DQNAgent(
        obs_shape,
        act_dim,
        lr=1e-3,
        epsilon=0.95,
        gamma=0.99,
        device="cuda",
        target_update_freq=100,
        use_double_dqn=True,
        net_type="mlp",
    )

    logger = Logger()
    trainer = Trainer(env, agent, logger=logger)
    trainer.train(num_episodes=500, max_steps_per_episode=500)
    logger.plot_reward_curve(save_path="./log/dqn_training_curve.png", window_size=20, show=False)
    env.close()


if __name__ == "__main__":
    main()
