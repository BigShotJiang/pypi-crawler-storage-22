import argparse
import os
import sys
from pathlib import Path

if __package__ is None or __package__ == "":
    project_root = Path(__file__).resolve().parents[2]
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))

import gymnasium as gym
import torch

from rlkit.algo.dqn.dqn import DQNAgent
from rlkit.core.trainer import Trainer
from rlkit.envs.atari import build_atari_env
from rlkit.utils.logger import Logger
from rlkit.utils.seed import set_global_seed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run DQN/Double-DQN with CNN on Atari (auto grayscale + resize + FrameStack)")
    parser.add_argument("--env", type=str, default="ALE/Pong-v5")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num_episodes", type=int, default=500)
    parser.add_argument("--max_steps_per_episode", type=int, default=10000)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--gamma", type=float, default=0.99)
    parser.add_argument("--epsilon", type=float, default=1.0)
    parser.add_argument("--epsilon_min", type=float, default=0.05)
    parser.add_argument("--epsilon_decay", type=float, default=0.995)
    parser.add_argument("--buffer_size", type=int, default=20000)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--target_update_freq", type=int, default=1000)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--frame_stack", type=int, default=4)
    parser.add_argument("--screen_size", type=int, default=84)
    parser.add_argument("--use_double_dqn", action="store_true")
    parser.add_argument("--window_size", type=int, default=100)
    parser.add_argument("--plot_path", type=str, default="./log/atari_dqn_training_curve.png")
    parser.add_argument("--save_model_path", type=str, default="./checkpoints/atari_dqn.pt")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    set_global_seed(args.seed, deterministic_torch=True)

    env = build_atari_env(args.env, frame_stack=args.frame_stack, screen_size=args.screen_size)
    try:
        if not isinstance(env.action_space, gym.spaces.Discrete):
            raise TypeError("Atari DQN requires a Discrete action space")
        if not isinstance(env.observation_space, gym.spaces.Box) or env.observation_space.shape is None:
            raise TypeError("Atari DQN requires Box observation with known shape")

        obs_shape = env.observation_space.shape
        act_dim = env.action_space.n

        agent = DQNAgent(
            obs_dim=obs_shape,
            act_dim=act_dim,
            lr=args.lr,
            gamma=args.gamma,
            epsilon=args.epsilon,
            epsilon_min=args.epsilon_min,
            epsilon_decay=args.epsilon_decay,
            buffer_size=args.buffer_size,
            batch_size=args.batch_size,
            target_update_freq=args.target_update_freq,
            use_double_dqn=args.use_double_dqn,
            net_type="cnn",
            device=args.device,
        )

        logger = Logger()
        trainer = Trainer(env, agent, logger=logger)
        trainer.train(
            num_episodes=args.num_episodes,
            max_steps_per_episode=args.max_steps_per_episode,
        )

        plot_dir = os.path.dirname(args.plot_path)
        if plot_dir:
            os.makedirs(plot_dir, exist_ok=True)
        logger.plot_reward_curve(save_path=args.plot_path, window_size=args.window_size, show=False)

        model_dir = os.path.dirname(args.save_model_path)
        if model_dir:
            os.makedirs(model_dir, exist_ok=True)
        torch.save(agent.q_net.state_dict(), args.save_model_path)

        print(f"Saved model checkpoint to {args.save_model_path}")
        print(f"Saved training curve to {args.plot_path}")
    finally:
        env.close()


if __name__ == "__main__":
    main()
