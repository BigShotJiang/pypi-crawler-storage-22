import argparse
import os
import sys
from pathlib import Path

if __package__ is None or __package__ == "":
    project_root = Path(__file__).resolve().parents[2]
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))

import gymnasium as gym
import torch

from rlkit.algo.dqn.dqn import DQNAgent
from rlkit.core.trainer import Trainer
from rlkit.experiments.run_dqn_atari import build_atari_env
from rlkit.utils.seed import set_global_seed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate Atari DQN policy (explore=False) and export replay")
    parser.add_argument("--env", type=str, default="ALE/Pong-v5")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--checkpoint_path", type=str, default="./checkpoints/atari_dqn.pt")
    parser.add_argument("--num_episodes", type=int, default=10)
    parser.add_argument("--max_steps_per_episode", type=int, default=10000)
    parser.add_argument("--gamma", type=float, default=0.99)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--target_update_freq", type=int, default=1000)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--frame_stack", type=int, default=4)
    parser.add_argument("--screen_size", type=int, default=84)
    parser.add_argument("--use_double_dqn", action="store_true")
    parser.add_argument("--replay_txt", type=str, default="")
    parser.add_argument("--replay_gif", type=str, default="./log/atari_eval_replay.gif")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    set_global_seed(args.seed, deterministic_torch=True)

    if not os.path.exists(args.checkpoint_path):
        raise FileNotFoundError(f"Checkpoint not found: {args.checkpoint_path}")

    env = build_atari_env(
        args.env,
        frame_stack=args.frame_stack,
        screen_size=args.screen_size,
        render_mode="rgb_array",
    )

    try:
        if not isinstance(env.action_space, gym.spaces.Discrete):
            raise TypeError("Atari DQN evaluation requires a Discrete action space")
        if not isinstance(env.observation_space, gym.spaces.Box) or env.observation_space.shape is None:
            raise TypeError("Atari DQN evaluation requires Box observation with known shape")

        obs_shape = env.observation_space.shape
        act_dim = env.action_space.n

        agent = DQNAgent(
            obs_dim=obs_shape,
            act_dim=act_dim,
            gamma=args.gamma,
            batch_size=args.batch_size,
            target_update_freq=args.target_update_freq,
            use_double_dqn=args.use_double_dqn,
            net_type="cnn",
            device=args.device,
        )

        state_dict = torch.load(args.checkpoint_path, map_location=args.device)
        agent.q_net.load_state_dict(state_dict)
        agent.target_net.load_state_dict(state_dict)
        agent.epsilon = 0.0

        trainer = Trainer(env, agent)

        replay_txt_path = args.replay_txt if args.replay_txt else None
        replay_gif_path = args.replay_gif if args.replay_gif else None

        for replay_path in (replay_txt_path, replay_gif_path):
            if replay_path:
                replay_dir = os.path.dirname(replay_path)
                if replay_dir:
                    os.makedirs(replay_dir, exist_ok=True)

        avg_reward = trainer.evaluate(
            num_episodes=args.num_episodes,
            max_steps_per_episode=args.max_steps_per_episode,
            replay_txt_path=replay_txt_path,
            replay_gif_path=replay_gif_path,
        )

        print({"avg_reward": float(avg_reward), "episodes": args.num_episodes})
        if replay_txt_path:
            print(f"Saved replay txt to {replay_txt_path}")
        if replay_gif_path:
            print(f"Saved replay gif to {replay_gif_path}")
    finally:
        env.close()


if __name__ == "__main__":
    main()
