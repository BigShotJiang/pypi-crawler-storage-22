import argparse
import os

import gymnasium as gym
from gymnasium.spaces import Box, Discrete

from rlkit.algo.dqn.dqn import DQNAgent
from rlkit.core.trainer import Trainer
from rlkit.utils.logger import Logger
from rlkit.utils.seed import set_global_seed


CLASSIC_DQN_ENVS = [
    "CartPole-v1",
    "MountainCar-v0",
    "Acrobot-v1",
    "LunarLander-v3",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run DQN/Double-DQN on classic Gymnasium control environments.")
    parser.add_argument("--env", type=str, default="CartPole-v1", choices=CLASSIC_DQN_ENVS)
    parser.add_argument("--net_type", type=str, default="mlp", choices=["mlp", "cnn"])
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num_episodes", type=int, default=1000)
    parser.add_argument("--max_steps_per_episode", type=int, default=500)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--gamma", type=float, default=0.99)
    parser.add_argument("--epsilon", type=float, default=0.9)
    parser.add_argument("--epsilon_min", type=float, default=0.05)
    parser.add_argument("--epsilon_decay", type=float, default=0.995)
    parser.add_argument("--buffer_size", type=int, default=100000)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--target_update_freq", type=int, default=100)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--use_double_dqn", action="store_true", help="Enable Double DQN target computation")
    parser.add_argument("--window_size", type=int, default=100, help="Rolling window for reward plot")
    parser.add_argument("--plot_path", type=str, default="./log/dqn_classic_training_curve.png")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    set_global_seed(args.seed, deterministic_torch=True)

    env = gym.make(args.env)
    try:
        if not isinstance(env.action_space, Discrete):
            raise TypeError("DQNAgent currently requires a Discrete action space")
        if not isinstance(env.observation_space, Box) or env.observation_space.shape is None:
            raise TypeError("DQNAgent currently requires a Box observation space with fixed shape")

        obs_shape = env.observation_space.shape
        act_dim = env.action_space.n

        agent = DQNAgent(
            obs_dim=obs_shape,
            act_dim=act_dim,
            lr=args.lr,
            gamma=args.gamma,
            epsilon=args.epsilon,
            epsilon_min=args.epsilon_min,
            epsilon_decay=args.epsilon_decay,
            buffer_size=args.buffer_size,
            batch_size=args.batch_size,
            target_update_freq=args.target_update_freq,
            use_double_dqn=args.use_double_dqn,
            net_type=args.net_type,
            device=args.device,
        )

        logger = Logger()
        trainer = Trainer(env, agent, logger=logger)
        trainer.train(
            num_episodes=args.num_episodes,
            max_steps_per_episode=args.max_steps_per_episode,
        )

        plot_dir = os.path.dirname(args.plot_path)
        if plot_dir:
            os.makedirs(plot_dir, exist_ok=True)
        logger.plot_reward_curve(save_path=args.plot_path, window_size=args.window_size, show=False)
        print(f"Saved training curve to {args.plot_path}")
    finally:
        env.close()


if __name__ == "__main__":
    main()
