import argparse
import os
import sys
from pathlib import Path

if __package__ is None or __package__ == "":
    project_root = Path(__file__).resolve().parents[2]
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))

import gymnasium as gym
import numpy as np
import torch
from gymnasium.spaces import Box, Discrete

from rlkit.algo.pg.ppo import PPOAgent
from rlkit.utils.logger import Logger
from rlkit.utils.seed import set_global_seed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run PPO on classic control environments")
    parser.add_argument("--env", type=str, default="CartPole-v1")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num_episodes", type=int, default=1000)
    parser.add_argument("--max_steps_per_episode", type=int, default=4000)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--gamma", type=float, default=0.99)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--window_size", type=int, default=100)
    parser.add_argument("--plot_path", type=str, default="./log/ppo_training_curve.png")
    parser.add_argument("--save_model_path", type=str, default="./checkpoints/ppo_policy.pt")
    return parser.parse_args()


def _flatten_obs(obs: np.ndarray) -> np.ndarray:
    return np.asarray(obs, dtype=np.float32).reshape(-1)


def main() -> None:
    args = parse_args()
    set_global_seed(args.seed, deterministic_torch=True)

    env = gym.make(args.env)
    logger = Logger()

    try:
        if not isinstance(env.observation_space, Box) or env.observation_space.shape is None:
            raise TypeError("PPO requires a Box observation space with fixed shape")
        if not isinstance(env.action_space, Discrete):
            raise TypeError("PPO currently requires a Discrete action space")

        obs_dim = int(np.prod(env.observation_space.shape))
        act_dim = env.action_space.n

        agent = PPOAgent(
            obs_dim=obs_dim,
            act_dim=act_dim,
            lr=args.lr,
            gamma=args.gamma,
            buffer_size=args.max_steps_per_episode,
            device=args.device,
        )

        rewards: list[float] = []
        obs, _ = env.reset()
        ongoing_episode_reward = 0.0

        for episode in range(args.num_episodes):
            rollout_reward = 0.0
            completed_episode_rewards: list[float] = []

            for step in range(args.max_steps_per_episode):
                obs_flat = _flatten_obs(obs)
                action, value, logp = agent.act(obs_flat)
                next_obs, reward, terminated, truncated, _ = env.step(action)
                done = terminated or truncated

                agent.observe((obs_flat, action, float(reward), value, logp))
                rollout_reward += float(reward)
                ongoing_episode_reward += float(reward)
                obs = next_obs

                if done:
                    agent.finish_path(last_val=0.0)
                    completed_episode_rewards.append(ongoing_episode_reward)
                    ongoing_episode_reward = 0.0
                    obs, _ = env.reset()
                elif step == args.max_steps_per_episode - 1:
                    with torch.no_grad():
                        bootstrap_obs = torch.tensor(_flatten_obs(obs), dtype=torch.float32, device=agent.device)
                        last_val = agent.value_net(bootstrap_obs).item()
                    agent.finish_path(last_val=last_val)

            agent.update()

            if completed_episode_rewards:
                logged_reward = float(np.mean(completed_episode_rewards))
            else:
                logged_reward = ongoing_episode_reward

            rewards.append(logged_reward)
            window_size = min(args.window_size, len(rewards))
            avg_reward = sum(rewards[-window_size:]) / window_size
            logger.log(
                {
                    "episode": episode,
                    "reward": logged_reward,
                    "rollout_reward": rollout_reward,
                    "completed_episodes": len(completed_episode_rewards),
                    "avg_reward_100": avg_reward,
                }
            )

        plot_dir = os.path.dirname(args.plot_path)
        if plot_dir:
            os.makedirs(plot_dir, exist_ok=True)
        logger.plot_reward_curve(save_path=args.plot_path, window_size=args.window_size, show=False)

        model_dir = os.path.dirname(args.save_model_path)
        if model_dir:
            os.makedirs(model_dir, exist_ok=True)
        torch.save(
            {
                "policy": agent.policy_net.state_dict(),
                "value": agent.value_net.state_dict(),
            },
            args.save_model_path,
        )

        print(f"Saved PPO checkpoint to {args.save_model_path}")
        print(f"Saved training curve to {args.plot_path}")
    finally:
        env.close()


if __name__ == "__main__":
    main()