import argparse 
import gymnasium as gym
from rlkit.algo.tabular.q_learning import QLearningAgent
from rlkit.core.trainer import Trainer
from rlkit.utils.logger import Logger

def main(args):
    env_kwargs = {}
    if args.render_mode:
        env_kwargs["render_mode"] = args.render_mode
    if args.env.startswith("FrozenLake"):
        env_kwargs["is_slippery"] = args.is_slippery

    env = gym.make(args.env, **env_kwargs)
    agent = QLearningAgent(
        env.action_space,
        learning_rate=args.learning_rate,
        gamma=args.gamma,
        epsilon=args.epsilon,
        epsilon_min=args.epsilon_min,
        epsilon_decay=args.epsilon_decay,
    )
    logger = Logger()
    trainer = Trainer(env, agent, logger)

    num_episodes = args.num_episodes
    max_steps_per_episode = args.max_steps_per_episode

    trainer.train(num_episodes, max_steps_per_episode)

    logs = logger.get_logs()
    for log in logs:
        print(f"Episode {log['episode']}: Reward = {log['reward']}")

    eval_episodes = args.eval_episodes
    avg_reward = trainer.evaluate(
        eval_episodes,
        max_steps_per_episode,
        replay_txt_path=args.replay_txt,
        replay_gif_path=args.replay_gif,
    )
    print(f"Evaluation avg reward: {avg_reward:.2f} ({eval_episodes} episodes)")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", type=str, default="FrozenLake-v1", help="Gymnasium environment name")
    parser.add_argument("--is_slippery", action="store_true", help="Enable slippery dynamics")
    parser.add_argument("--render_mode", type=str, default="ansi", help="Env render_mode (e.g., ansi, rgb_array)")
    parser.add_argument("--num_episodes", type=int, default=1000)
    parser.add_argument("--max_steps_per_episode", type=int, default=100)
    parser.add_argument("--learning_rate", type=float, default=0.1)
    parser.add_argument("--gamma", type=float, default=0.99)
    parser.add_argument("--epsilon", type=float, default=1)
    parser.add_argument("--epsilon_min", type=float, default=0.005)
    parser.add_argument("--epsilon_decay", type=float, default=0.995)
    parser.add_argument("--eval_episodes", type=int, default=200)
    parser.add_argument("--replay_txt", type=str, default=None, help="Path to save ANSI replay txt")
    parser.add_argument("--replay_gif", type=str, default=None, help="Path to save ANSI replay gif")
    args = parser.parse_args()
    main(args)