import argparse
import os
import sys
from pathlib import Path

if __package__ is None or __package__ == "":
    project_root = Path(__file__).resolve().parents[2]
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))

import gymnasium as gym
import numpy as np
import torch
from gymnasium.spaces import Box, Discrete

from rlkit.algo.pg.reinforce import REINFORCEAgent
from rlkit.utils.logger import Logger
from rlkit.utils.seed import set_global_seed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run REINFORCE on classic control environments")
    parser.add_argument("--env", type=str, default="CartPole-v1")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num_episodes", type=int, default=1000)
    parser.add_argument("--max_steps_per_episode", type=int, default=500)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--gamma", type=float, default=0.99)
    parser.add_argument("--device", type=str, default="cpu")
    parser.add_argument("--window_size", type=int, default=100)
    parser.add_argument("--plot_path", type=str, default="./log/reinforce_training_curve.png")
    parser.add_argument("--save_model_path", type=str, default="./checkpoints/reinforce_policy.pt")
    return parser.parse_args()


def _flatten_obs(obs: np.ndarray) -> np.ndarray:
    return np.asarray(obs, dtype=np.float32).reshape(-1)


def main() -> None:
    args = parse_args()
    set_global_seed(args.seed, deterministic_torch=True)

    env = gym.make(args.env)
    logger = Logger()

    try:
        if not isinstance(env.observation_space, Box) or env.observation_space.shape is None:
            raise TypeError("REINFORCE requires a Box observation space with fixed shape")
        if not isinstance(env.action_space, Discrete):
            raise TypeError("REINFORCE currently requires a Discrete action space")

        obs_dim = int(np.prod(env.observation_space.shape))
        act_dim = env.action_space.n

        agent = REINFORCEAgent(
            obs_dim=obs_dim,
            act_dim=act_dim,
            lr=args.lr,
            gamma=args.gamma,
            device=args.device,
        )

        rewards: list[float] = []
        for episode in range(args.num_episodes):
            obs, _ = env.reset()
            episode_reward = 0.0

            for _ in range(args.max_steps_per_episode):
                obs_flat = _flatten_obs(obs)
                action = agent.act(obs_flat)
                next_obs, reward, terminated, truncated, _ = env.step(action)
                done = terminated or truncated

                agent.observe((obs_flat, action, float(reward), None, done))
                episode_reward += float(reward)
                obs = next_obs

                if done:
                    break

            rewards.append(episode_reward)
            window_size = min(args.window_size, len(rewards))
            avg_reward = sum(rewards[-window_size:]) / window_size
            logger.log(
                {
                    "episode": episode,
                    "reward": episode_reward,
                    "avg_reward_100": avg_reward,
                }
            )

        plot_dir = os.path.dirname(args.plot_path)
        if plot_dir:
            os.makedirs(plot_dir, exist_ok=True)
        logger.plot_reward_curve(save_path=args.plot_path, window_size=args.window_size, show=False)

        model_dir = os.path.dirname(args.save_model_path)
        if model_dir:
            os.makedirs(model_dir, exist_ok=True)
        torch.save(agent.policy_net.state_dict(), args.save_model_path)

        print(f"Saved policy checkpoint to {args.save_model_path}")
        print(f"Saved training curve to {args.plot_path}")
    finally:
        env.close()


if __name__ == "__main__":
    main()
