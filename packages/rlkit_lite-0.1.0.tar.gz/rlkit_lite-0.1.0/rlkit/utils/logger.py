from typing import Dict, List, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np


class Logger:
    """简单日志打印与训练曲线绘制。"""

    def __init__(self) -> None:
        self.logs: List[Dict] = []

    def log(self, data: dict) -> None:
        self.logs.append(data)
        print(data)

    def get_logs(self) -> list:
        return self.logs

    def _rolling_stats(self, values: Sequence[float], window_size: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        means = []
        stds = []
        variances = []

        for index in range(len(values)):
            start = max(0, index - window_size + 1)
            window = np.asarray(values[start : index + 1], dtype=np.float32)
            means.append(float(np.mean(window)))
            stds.append(float(np.std(window)))
            variances.append(float(np.var(window)))

        return np.asarray(means), np.asarray(stds), np.asarray(variances)

    def plot_reward_curve(
        self,
        save_path: str = "./log/dqn_training_curve.png",
        window_size: int = 100,
        show: bool = False,
    ) -> None:
        episodes = [item.get("episode") for item in self.logs if "episode" in item and "reward" in item]
        rewards = [float(item["reward"]) for item in self.logs if "episode" in item and "reward" in item]

        if not episodes or not rewards:
            raise ValueError("No episode/reward logs found. Run training before plotting.")

        reward_mean, reward_std, reward_var = self._rolling_stats(rewards, window_size)
        x = np.asarray(episodes)

        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(11, 8), sharex=True)

        ax1.plot(x, rewards, color="#7f8c8d", alpha=0.45, linewidth=1.0, label="Reward")
        ax1.plot(x, reward_mean, color="#2e86de", linewidth=2.0, label=f"Rolling Mean ({window_size})")
        ax1.fill_between(
            x,
            reward_mean - reward_std,
            reward_mean + reward_std,
            color="#2e86de",
            alpha=0.2,
            label="Mean ± Std",
        )
        ax1.set_ylabel("Reward")
        ax1.set_title("Episode Reward and Rolling Statistics")
        ax1.grid(True, linestyle="--", alpha=0.3)
        ax1.legend(loc="best")

        ax2.plot(x, reward_std, color="#27ae60", linewidth=2.0, label="Rolling Std")
        ax2.plot(x, reward_var, color="#8e44ad", linewidth=2.0, label="Rolling Variance")
        ax2.set_xlabel("Episode")
        ax2.set_ylabel("Value")
        ax2.set_title("Rolling Standard Deviation and Variance")
        ax2.grid(True, linestyle="--", alpha=0.3)
        ax2.legend(loc="best")

        fig.tight_layout()
        fig.savefig(save_path, dpi=150)
        if show:
            plt.show()
        plt.close(fig)