from __future__ import annotations

from typing import Iterable, List, Optional
import re

import numpy as np



_ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-9;]*m")


def _strip_ansi(text: str) -> str:
    return _ANSI_ESCAPE_RE.sub("", text)


def save_ansi_frames_to_txt(frames: Iterable[object], path: str, separator: str = "\n\n") -> None:
    cleaned = [_strip_ansi(str(frame)) for frame in frames]
    with open(path, "w", encoding="utf-8") as f:
        f.write(separator.join(cleaned))


def _ansi_frame_to_image(frame_text: str, font: Optional[object] = None):
    from PIL import Image, ImageDraw, ImageFont

    text = _strip_ansi(frame_text)
    font = font or ImageFont.load_default()

    lines = text.splitlines() or [""]
    max_line_len = max(len(line) for line in lines)

    # Approximate character size using a representative character
    bbox = font.getbbox("M")
    char_width = bbox[2] - bbox[0]
    char_height = bbox[3] - bbox[1]

    width = max_line_len * char_width + 10
    height = len(lines) * char_height + 10

    image = Image.new("RGB", (width, height), color=(255, 255, 255))
    draw = ImageDraw.Draw(image)
    y = 5
    for line in lines:
        draw.text((5, y), line, font=font, fill=(0, 0, 0))
        y += char_height

    return image


def save_ansi_frames_to_gif(
    frames: Iterable[object],
    path: str,
    duration_ms: int = 200,
) -> None:
    from PIL import Image, ImageFont

    font = ImageFont.load_default()
    images: List[object] = []

    def _frame_to_image(frame: object):
        if isinstance(frame, np.ndarray):
            arr = frame
            if arr.dtype != np.uint8:
                arr = np.clip(arr, 0, 255).astype(np.uint8)

            if arr.ndim == 2:
                return Image.fromarray(arr, mode="L").convert("RGB")

            if arr.ndim == 3 and arr.shape[-1] in (1, 3, 4):
                if arr.shape[-1] == 1:
                    return Image.fromarray(arr.squeeze(-1), mode="L").convert("RGB")
                if arr.shape[-1] == 3:
                    return Image.fromarray(arr, mode="RGB")
                return Image.fromarray(arr, mode="RGBA").convert("RGB")

        return _ansi_frame_to_image(str(frame), font=font)

    for frame in frames:
        images.append(_frame_to_image(frame))

    if not images:
        return

    images[0].save(
        path,
        save_all=True,
        append_images=images[1:],
        duration=duration_ms,
        loop=0,
    )
