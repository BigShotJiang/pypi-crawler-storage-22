import os
import random

import numpy as np
import torch


def set_global_seed(seed: int, deterministic_torch: bool = False) -> None:
    """Set global random seed for reproducible experiments.

    Args:
        seed: Random seed value.
        deterministic_torch: Whether to force deterministic torch backend.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)

    if deterministic_torch:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
