"""Recursive Language Models for AI."""

__version__ = "0.0.1"
