"""CLI module for RLM-REPL."""

from rlm_repl.cli.main import main, create_parser

__all__ = ["main", "create_parser"]
