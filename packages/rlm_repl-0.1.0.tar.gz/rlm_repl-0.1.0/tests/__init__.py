"""Tests for RLM-REPL."""
