# RMath

RMath is a Python Library for
- All basic math calculations
- Geometry formulas of Circle, Square, Rectangle, Triangle

## Installation

pip install RMath

### Example

'''python
from RMath import isadd, circle_area
print(add(5, 3))