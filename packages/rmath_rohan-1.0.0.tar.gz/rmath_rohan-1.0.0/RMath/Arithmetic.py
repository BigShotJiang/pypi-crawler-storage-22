def isAdd(a, b):
    return a + b

def isSub(a, b):
    return a - b

def isMul(a, b):
    return a * b

def isDiv(a, b):
    if b == 0:
        return "Division is not possible"
    return a / b

def isFloorDiv(a, b):
    return a // b

def isMod(a, b):
    return a % b

def isExpo(a, b):
    return a ** b