import math

pi = math.pi
sqrt = math.sqrt
sin = math.sin
radians = math.radians

# Circle
def circle_area(r):
    return pi * r * r

def circle_perimeter(r):
    return 2 * pi * r

def circle_diameter(r):
    return 2 * r

# Square
def square_area(a):
    return a * a

def square_perimeter(a):
    return 4 * a

def square_diagonal(a):
    return a * sqrt(2)

# Rectangle
def rectangle_area(l, b):
    return l * b

def rectangle_perimeter(l, b):
    return 2 * (l + b)

def rectangle_diagonal(l, w):
    return sqrt((w*w)+(l*l))

# Triangle
def triangle_area(b, h):
    return 0.5 * b * h

def triangle_perimeter(a, b, c):
    return a + b + c

def triangle_base(a, h):
    return (2 * a) / h

def triangle_height(a, b):
    return (2 * a) / b

def triangle_areaGamma(a, b):
    gamma = float(input("Enter the value of gamma: "))
    return 0.5 * a * b * sin(radians(gamma))

def triangle_heightGamma(b):
    gamma = float(input("Enter the value of gamma: "))
    return b * sin(radians(gamma))