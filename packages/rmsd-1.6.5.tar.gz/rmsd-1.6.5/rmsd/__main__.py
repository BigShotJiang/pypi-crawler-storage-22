from rmsd.calculate_rmsd import main

if __name__ == "__main__":
    result = main()
    print(result)
