#!/bin/sh

JIRA_KEY_REGEX="^(RDFT|SUG|RD)-[0-9]+"

commit_msg_file=$1
commit_msg=$(head -n1 "$commit_msg_file")

if ! echo "$commit_msg" | grep -qE "$JIRA_KEY_REGEX"; then
  echo "❌ The commit message must start with a Jira key, for example: SUG-123: fix bug"
  exit 1
fi

if ! echo "$commit_msg" | grep -qE "\[\+\]$"; then
  new_msg="${commit_msg} [+]"
  echo "$new_msg" > "$commit_msg_file"
fi
