# road24-artifacthub

Shared logging and metrics SDK for Road24 microservices. Provides structured JSON logging, Prometheus metrics, and framework-specific integrations following a Sentry SDK-like pattern.

## Installation

```bash
# Core library
pip install road24-artifacthub

# With all integrations
pip install road24-artifacthub[all]

# Development (includes test tools)
pip install road24-artifacthub[dev]
```

## Quick Start

```python
import road24_sdk
from fastapi import FastAPI
from httpx import AsyncClient, Timeout
from road24_sdk.integrations.fastapi import FastApiLoggingIntegration
from road24_sdk.integrations.httpx import HttpxLoggingIntegration
from road24_sdk.integrations.redis import RedisLoggingIntegration
from road24_sdk.integrations.sqlalchemy import SqlalchemyLoggingIntegration

def setup_road24_sdk():
    road24_sdk.init(
        service_name="my-service",
        log_level="INFO",
        integrations=[
            HttpxLoggingIntegration(),
            SqlalchemyLoggingIntegration(),
            RedisLoggingIntegration(),
        ],
    )

# FastAPI requires .setup(app) since it needs the app instance
app = FastAPI()
setup_road24_sdk()
FastApiLoggingIntegration().setup(app)
```

## Available Integrations

| Integration | Extra | Description |
|---|---|---|
| `FastApiLoggingIntegration` | `fastapi` | Inbound HTTP request/response logging and metrics |
| `HttpxLoggingIntegration` | `httpx` | Outbound HTTP request/response logging and metrics |
| `SqlalchemyLoggingIntegration` | `sqlalchemy` | Database query logging and metrics |
| `RedisLoggingIntegration` | `redis` | Redis command logging and metrics |

## Manual Testing

Standalone scripts to inspect structured JSON logs and metrics (no server needed):

```bash
make test-logs-http-input    # Inbound HTTP request log
make test-logs-http-output   # Outbound HTTPX request log
make test-metrics-http       # Prometheus metrics after HTTP calls
make test-logs-redis         # Redis command logs (SET, GET, HSET, etc.)
make test-logs-db            # DB query logs (SELECT, INSERT, UPDATE, DELETE)
```

## Development

```bash
make install    # Install all dependencies (requires uv)
make test       # Run tests with coverage
make lint       # Lint with ruff
make format     # Format with ruff
make check      # Lint + test
```
