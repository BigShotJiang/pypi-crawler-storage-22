"""Exercise DB query logging directly (no real database needed).

Shows structured JSON logs for SELECT, INSERT, UPDATE, DELETE operations.
"""

import road24_sdk
from road24_sdk.integrations.sqlalchemy import DbLogger


def main() -> None:
    road24_sdk.init(service_name="manual-test", log_level="DEBUG", debug=True)

    db_logger = DbLogger()

    db_logger.log_query(
        operation=road24_sdk.DbOperation.SELECT,
        table="users",
        duration_seconds=0.023,
        statement="SELECT id, name, email FROM users WHERE id = $1",
    )

    db_logger.log_query(
        operation=road24_sdk.DbOperation.INSERT,
        table="orders",
        duration_seconds=0.045,
        statement="INSERT INTO orders (user_id, total) VALUES ($1, $2)",
    )

    db_logger.log_query(
        operation=road24_sdk.DbOperation.UPDATE,
        table="orders",
        duration_seconds=0.012,
        statement="UPDATE orders SET status = $1 WHERE id = $2",
    )

    db_logger.log_query(
        operation=road24_sdk.DbOperation.DELETE,
        table="sessions",
        duration_seconds=0.008,
        statement="DELETE FROM sessions WHERE expired_at < NOW()",
    )


main()
