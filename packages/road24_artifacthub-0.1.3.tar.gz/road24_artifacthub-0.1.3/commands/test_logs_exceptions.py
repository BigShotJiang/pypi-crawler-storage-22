"""Exercise ExceptionLogger for all three exception types.

Shows structured JSON logs for HTTP errors, validation errors, and general errors.
"""

import road24_sdk
from road24_sdk._formatter import ExceptionLogger


def main() -> None:
    road24_sdk.init(service_name="manual-test", log_level="DEBUG", debug=True)

    exc_logger = ExceptionLogger()

    # 1. HTTP error — e.g. upstream returned 404
    try:
        raise ConnectionError("Connection refused by upstream service")
    except ConnectionError as exc:
        exc_logger.log_http_error(
            method="GET",
            url="https://api.partner.com/v1/users/999",
            path="/v1/users/999",
            status_code=404,
            detail="User not found on partner API",
            exc=exc,
        )

    # 2. Validation error — e.g. bad request payload
    exc_logger.log_validation_error(
        method="POST",
        url="https://example.com/api/v1/orders",
        path="/api/v1/orders",
        errors=[
            {
                "loc": ["body", "email"],
                "msg": "value is not a valid email address",
                "type": "value_error.email",
            },
            {
                "loc": ["body", "amount"],
                "msg": "ensure this value is greater than 0",
                "type": "value_error.number.not_gt",
            },
        ],
    )

    # 3. General error — e.g. unhandled exception in a handler
    try:
        raise RuntimeError("Unexpected null pointer in payment processing")
    except RuntimeError as exc:
        exc_logger.log_general_error(
            method="POST",
            url="https://example.com/api/v1/payments",
            path="/api/v1/payments",
            exc=exc,
        )


main()
