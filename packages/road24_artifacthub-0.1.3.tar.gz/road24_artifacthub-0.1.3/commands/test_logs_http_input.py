"""Exercise FastAPI inbound request logging via ASGI middleware.

Shows structured JSON logs with sensitive fields redacted by the sanitizer.
No server needed — drives the middleware directly.
"""

import asyncio
import json

import road24_sdk
from road24_sdk.integrations.fastapi import FastApiLoggingIntegration

REQUEST_BODY = json.dumps({
    "username": "alice",
    "password": "super-secret-123",
    "api_key": "sk-proj-abc123xyz",
    "token": "eyJhbGciOiJIUzI1NiJ9.payload.signature",
    "profile": {
        "email": "alice@example.com",
        "private_key": "-----BEGIN RSA PRIVATE KEY-----",
        "session_id": "sess_9f8a7b6c5d4e",
    },
    "payment": {
        "card_number": "4111111111111111",
        "cvv": "123",
        "amount": 99.99,
    },
}).encode()

RESPONSE_BODY = json.dumps({
    "user_id": 42,
    "access_key": "AKIA1234567890",
    "bearer": "eyJhbGciOiJIUzI1NiJ9.new.token",
    "credential": "some-oauth-credential",
    "name": "Alice",
}).encode()


async def mock_app(scope: dict, receive: object, send: object) -> None:
    await receive()
    await send({"type": "http.response.start", "status": 200, "headers": []})
    await send({"type": "http.response.body", "body": RESPONSE_BODY})


async def mock_app_with_exception(scope: dict, receive: object, send: object) -> None:
    from road24_sdk.integrations.fastapi import _request_exception

    await receive()
    exc = RuntimeError("Database connection pool exhausted")
    _request_exception.set(exc)
    await send({"type": "http.response.start", "status": 500, "headers": []})
    await send({
        "type": "http.response.body",
        "body": json.dumps({"detail": "Internal server error"}).encode(),
    })


SCOPE = {
    "type": "http",
    "method": "POST",
    "path": "/api/v1/auth/login",
    "scheme": "https",
    "headers": [
        (b"host", b"example.com"),
        (b"x-trace-id", b"abc123trace"),
    ],
}


def make_receive(body: bytes):
    body_sent = False

    async def receive() -> dict:
        nonlocal body_sent
        if not body_sent:
            body_sent = True
            return {"type": "http.request", "body": body}
        return {"type": "http.disconnect"}

    return receive


async def main() -> None:
    road24_sdk.init(service_name="manual-test", log_level="DEBUG", debug=True)

    responses: list[dict] = []

    async def send(message: dict) -> None:
        responses.append(message)

    print("=== 200 OK (normal request) ===")
    app = FastApiLoggingIntegration().setup(mock_app)
    await app(SCOPE, make_receive(REQUEST_BODY), send)

    print("\n=== 500 Internal Server Error (with exception) ===")
    app = FastApiLoggingIntegration().setup(mock_app_with_exception)
    await app(SCOPE, make_receive(REQUEST_BODY), send)

    print("\n=== /metrics endpoint (no logs expected) ===")
    metrics_scope = {**SCOPE, "path": "/metrics", "method": "GET"}
    app = FastApiLoggingIntegration().setup(mock_app)
    await app(metrics_scope, make_receive(b""), send)
    print("/metrics path — skipped, no logs produced")


asyncio.run(main())
