"""Exercise HTTPX outbound request logging with sensitive data.

POSTs a body with secrets to httpbin.org/post — the response echoes it back.
Both request_body and response_body go through the sanitizer.
"""

import asyncio
import json

import road24_sdk
from road24_sdk.integrations.httpx import HttpxLoggingIntegration

PAYLOAD = {
    "username": "alice",
    "password": "super-secret-123",
    "api_key": "sk-proj-abc123xyz",
    "token": "eyJhbGciOiJIUzI1NiJ9.payload.signature",
    "settings": {
        "secret": "my-app-secret",
        "cookie": "session=abc123",
        "pin": "9876",
        "theme": "dark",
    },
}


async def main() -> None:
    road24_sdk.init(service_name="manual-test", log_level="DEBUG", debug=True)

    integration = HttpxLoggingIntegration()
    async with integration.create_client() as client:
        await client.post("https://httpbin.org/post", json=PAYLOAD)


asyncio.run(main())
