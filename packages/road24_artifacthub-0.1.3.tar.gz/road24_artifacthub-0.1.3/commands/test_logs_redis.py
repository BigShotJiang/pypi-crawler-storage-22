"""Exercise Redis logging with a mock client (no real Redis needed).

Shows structured JSON logs for SET, GET, DELETE, HSET, LPUSH operations.
"""

import asyncio
from unittest.mock import AsyncMock

import road24_sdk
from road24_sdk.integrations.redis import RedisLoggingIntegration


async def main() -> None:
    road24_sdk.init(service_name="manual-test", log_level="DEBUG", debug=True)

    mock_redis = AsyncMock()
    mock_redis.set.return_value = True
    mock_redis.get.return_value = b"cached_value"
    mock_redis.delete.return_value = 1
    mock_redis.hset.return_value = 1
    mock_redis.lpush.return_value = 3
    mock_redis.expire.return_value = True

    logged = RedisLoggingIntegration().instrument(mock_redis)

    await logged.set("user:123", "Alice", ex=300)
    await logged.get("user:123")
    await logged.hset("session:abc", "token", "xyz789")
    await logged.lpush("queue:tasks", "job1", "job2")
    await logged.expire("user:123", 600)
    await logged.delete("user:123")


asyncio.run(main())
