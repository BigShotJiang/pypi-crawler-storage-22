"""Exercise HTTP metrics and dump Prometheus output.

Simulates inbound + outbound requests, then prints all registered metrics.
"""

import asyncio

from prometheus_client import generate_latest

import road24_sdk
from road24_sdk.integrations.fastapi import FastApiLoggingIntegration
from road24_sdk.integrations.httpx import HttpxLoggingIntegration


async def mock_app(scope: dict, receive: object, send: object) -> None:
    await send({"type": "http.response.start", "status": 200, "headers": []})
    await send({"type": "http.response.body", "body": b"ok"})


async def main() -> None:
    road24_sdk.init(service_name="manual-test", log_level="WARNING", debug=True)

    app = FastApiLoggingIntegration().setup(mock_app)
    scope = {
        "type": "http",
        "method": "POST",
        "path": "/api/v1/orders",
        "scheme": "https",
        "headers": [(b"host", b"example.com")],
    }

    body_sent = False

    async def receive() -> dict:
        nonlocal body_sent
        if not body_sent:
            body_sent = True
            return {"type": "http.request", "body": b"{}"}
        return {"type": "http.disconnect"}

    async def send(message: dict) -> None:
        pass

    await app(scope, receive, send)

    integration = HttpxLoggingIntegration()
    async with integration.create_client() as client:
        await client.get("https://httpbin.org/get")

    print("\n=== Prometheus Metrics ===\n")
    print(generate_latest().decode())


asyncio.run(main())
