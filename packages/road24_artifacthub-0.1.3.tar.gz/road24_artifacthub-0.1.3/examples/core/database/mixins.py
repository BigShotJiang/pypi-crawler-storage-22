from datetime import datetime

from sqlalchemy import Boolean, DateTime, text, func, String
from sqlalchemy.orm import Mapped, mapped_column
from examples.core.utils import tashkent_datetime_now


class TimeStampMixin:
    __abstract__ = True
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=tashkent_datetime_now,
        server_default=func.now(),
    )
    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        onupdate=tashkent_datetime_now,
        server_onupdate=func.now(),
    )


class ActiveMixin:
    __abstract__ = True
    is_active: Mapped[bool] = mapped_column(
        Boolean, default=True, server_default=text("true")
    )


class IdMixin:
    __abstract__ = True
    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        server_default=text("gen_random_uuid()"),
    )
