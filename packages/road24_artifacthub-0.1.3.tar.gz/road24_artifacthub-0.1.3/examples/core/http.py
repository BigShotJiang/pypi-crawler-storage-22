import asyncio
import logging

from httpx import AsyncClient, Limits, Timeout

logger = logging.getLogger(__name__)


class HttpConnection:
    _instance: "HttpConnection | None" = None
    _client: AsyncClient | None = None
    _lock: asyncio.Lock | None = None

    def __new__(cls) -> "HttpConnection":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    async def get_client(self) -> AsyncClient:
        if self._client is not None:
            return self._client

        async with self._get_lock():
            if self._client is None:
                self._client = AsyncClient(
                    limits=Limits(max_connections=50, max_keepalive_connections=10),
                    timeout=Timeout(25.0),
                )
            return self._client

    async def close(self) -> None:
        async with self._get_lock():
            if self._client is not None:
                await self._client.aclose()
                self._client = None

    def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock


http_connection = HttpConnection()


async def init_http_client() -> None:
    await http_connection.get_client()
    logger.info("HTTP client initialized")


async def close_http_client() -> None:
    await http_connection.close()
    logger.info("HTTP client closed")
