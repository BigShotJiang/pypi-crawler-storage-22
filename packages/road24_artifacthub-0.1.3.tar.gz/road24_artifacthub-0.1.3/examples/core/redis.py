import asyncio
import logging

from redis.asyncio import Redis, from_url

from examples.core.settings import settings

logger = logging.getLogger(__name__)


class RedisConnection:
    _instance: "RedisConnection | None" = None
    _client: Redis | None = None
    _lock: asyncio.Lock | None = None

    def __new__(cls) -> "RedisConnection":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    async def get_client(self) -> Redis:
        if self._client is not None:
            return self._client

        async with self._get_lock():
            if self._client is None:
                self._client = await self._create_client()
            return self._client

    async def close(self) -> None:
        async with self._get_lock():
            if self._client is not None:
                await self._client.aclose()
                self._client = None

    async def ping(self) -> bool:
        try:
            client = await self.get_client()
            return await client.ping()
        except Exception as e:
            logger.error(f"Redis connection broke: {e}")
            return False

    def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    @staticmethod
    async def _create_client() -> Redis:
        return from_url(
            settings.REDIS_URL,
            encoding="utf-8",
            decode_responses=True,
            max_connections=20,
            retry_on_timeout=True,
            socket_keepalive=True,
            health_check_interval=30,
            socket_connect_timeout=5,
            socket_timeout=5,
        )


redis_connection = RedisConnection()


async def check_redis_connection() -> None:
    try:
        is_connected = await redis_connection.ping()
        if is_connected:
            logger.info("Redis connected successfully")
        else:
            logger.warning("Redis connection check failed")
    except Exception as e:
        logger.error(f"Failed to connect to Redis: {e}")


async def close_redis_connection() -> None:
    await redis_connection.close()
    logger.info("Redis connection closed")
