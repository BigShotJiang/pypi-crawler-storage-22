from typing import TYPE_CHECKING

import road24_sdk
from examples.core.settings import settings
from road24_sdk.integrations.fastapi import FastApiLoggingIntegration
from road24_sdk.integrations.httpx import HttpxLoggingIntegration
from road24_sdk.integrations.redis import RedisLoggingIntegration
from road24_sdk.integrations.sqlalchemy import SqlalchemyLoggingIntegration

if TYPE_CHECKING:
    from fastapi import FastAPI


def road24_setup(app: "FastAPI") -> None:
    road24_sdk.init(
        service_name=settings.SERVICE_NAME,
        log_level=settings.LOG_LEVEL.value,
        debug=settings.DEBUG,
        log_format=settings.LOG_FORMAT,
        integrations=[
            HttpxLoggingIntegration(),
            SqlalchemyLoggingIntegration(),
            RedisLoggingIntegration(),
        ],
    )
    FastApiLoggingIntegration().setup(app)
