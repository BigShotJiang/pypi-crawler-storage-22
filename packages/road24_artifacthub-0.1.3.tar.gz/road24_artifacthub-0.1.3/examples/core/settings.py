from enum import Enum
from functools import lru_cache
from pathlib import Path

from pydantic import computed_field
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent


class LogLevelEnum(str, Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class Settings(BaseSettings):
    LOG_LEVEL: LogLevelEnum = LogLevelEnum.INFO
    LOG_FORMAT: str = "json"
    SERVICE_NAME: str = "road24-insurance"
    TIME_ZONE: str = "Asia/Tashkent"

    DEBUG: bool = False

    DB_URL: str = "postgresql+asyncpg://postgres:postgres@db:5432/postgres"
    REDIS_URL: str = "redis://redis:6379"
    RABBITMQ_URL: str = "amqp://guest:guest@rabbitmq:5672"

    AUTH_TOKEN: str = "0c9x9KoGTl3TND9sCV56u"

    SENTRY_DSN: str | None = None
    SENTRY_TRACES_SAMPLE_RATE: float = 1.0
    SENTRY_PROFILES_SAMPLE_RATE: float = 1.0

    @computed_field
    @property
    def dsn_async_db(self) -> str:
        return self.DB_URL

    @computed_field
    @property
    def dsn_db(self) -> str:
        return self.DB_URL.replace("asyncpg", "psycopg2")

    model_config = SettingsConfigDict(
        env_file=".env",
        case_sensitive=False,
        extra="ignore",
    )

@lru_cache
def get_settings() -> Settings:
    return Settings()

settings = get_settings()
