from datetime import datetime
from zoneinfo import ZoneInfo

from examples.core.settings import settings


def tashkent_datetime_now() -> datetime:
    return datetime.now(ZoneInfo(settings.TIME_ZONE))
