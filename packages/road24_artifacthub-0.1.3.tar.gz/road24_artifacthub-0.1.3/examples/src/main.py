import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI

from examples.core.database.config import (
    check_database_connection,
    close_database_connection,
)
from examples.core.http import close_http_client, init_http_client
from examples.core.redis import check_redis_connection, close_redis_connection
from examples.core.road24 import road24_setup

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:  # noqa: ARG001
    await check_database_connection()
    await check_redis_connection()
    await init_http_client()
    logger.info("Application initialized.")

    yield

    await close_http_client()
    await close_database_connection()
    await close_redis_connection()


app = FastAPI(lifespan=lifespan)
road24_setup(app)
