def main():
    print("Hello from road24-artifacthub!")


if __name__ == "__main__":
    main()
