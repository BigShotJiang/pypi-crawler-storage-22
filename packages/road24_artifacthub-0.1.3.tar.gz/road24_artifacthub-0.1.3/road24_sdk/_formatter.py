import json
import logging
import sys
from contextvars import ContextVar, Token
from datetime import UTC, datetime
from typing import Any

from road24_sdk._schemas import ExceptionAttributes, LogRecord
from road24_sdk._types import ExceptionType, LogType

STANDARD_RECORD_ATTRS = {
    "name",
    "msg",
    "args",
    "created",
    "filename",
    "funcName",
    "levelname",
    "levelno",
    "lineno",
    "module",
    "msecs",
    "pathname",
    "process",
    "processName",
    "relativeCreated",
    "stack_info",
    "exc_info",
    "exc_text",
    "thread",
    "threadName",
    "taskName",
    "message",
}

ZERO_TRACE_ID = "0" * 32

_trace_id: ContextVar[str] = ContextVar("trace_id", default="")

_service_name: str = "unknown"

SILENT_LOGGERS_DEBUG = [
    "uvicorn.access",
    "asyncio",
]

SILENT_LOGGERS_PROD = [
    "uvicorn",
    "uvicorn.access",
    "uvicorn.error",
    "uvicorn.asgi",
    "sqlalchemy",
    "sqlalchemy.engine",
    "sqlalchemy.pool",
    "httpx",
    "httpcore",
    "asyncio",
]


class LogFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        log_record = LogRecord(
            timestamp=datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
            trace_id=_trace_id.get() or ZERO_TRACE_ID,
            log_level=record.levelname,
            type=record.getMessage(),
            service_name=_service_name,
            attributes=self._build_attributes(record),
        )
        return json.dumps(log_record.as_dict(), ensure_ascii=False, default=str)

    def _build_attributes(self, record: logging.LogRecord) -> dict[str, Any]:
        attrs: dict[str, Any] = {
            "logger_name": record.name,
            "code_module": record.module,
            "code_function": record.funcName,
            "code_lineno": record.lineno,
        }

        attrs.update(
            {
                k: v
                for k, v in record.__dict__.items()
                if k not in STANDARD_RECORD_ATTRS and not k.startswith("_")
            }
        )

        if record.exc_info and (exc_type := record.exc_info[0]):
            attrs.update(
                {
                    "exception_type": exc_type.__name__,
                    "exception_message": str(record.exc_info[1]),
                    "exception_stacktrace": self.formatException(record.exc_info),
                }
            )

        return attrs


def set_trace_context(trace_id: str) -> Token[str]:
    return _trace_id.set(trace_id)


def clear_trace_context(token: Token[str] | None = None) -> None:
    if token is not None:
        _trace_id.reset(token)
    else:
        _trace_id.set("")


def get_trace_id() -> str:
    return _trace_id.get() or ZERO_TRACE_ID


def setup_logging(
    level: str = "INFO",
    service_name: str = "unknown",
    debug: bool = False,
) -> None:
    global _service_name
    _service_name = service_name

    log_level = getattr(logging, level.upper(), logging.INFO)

    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    root_logger.handlers.clear()

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(LogFormatter())
    handler.setLevel(log_level)
    root_logger.addHandler(handler)

    _silence_libraries(debug, level)


def _silence_libraries(debug: bool, level: str) -> None:
    is_debug = debug or level.upper() == "DEBUG"

    if is_debug:
        loggers = SILENT_LOGGERS_DEBUG
        silence_level = logging.WARNING
    else:
        loggers = SILENT_LOGGERS_PROD
        silence_level = logging.CRITICAL

    for name in loggers:
        lib_logger = logging.getLogger(name)
        lib_logger.setLevel(silence_level)
        lib_logger.propagate = False


class ExceptionLogger:
    def log_http_error(
        self,
        method: str,
        url: str,
        path: str,
        status_code: int,
        detail: str,
        exc: Exception,
    ) -> None:
        attrs = ExceptionAttributes(
            exception_type=ExceptionType.HTTP,
            error_class=type(exc).__name__,
            error_message=detail,
            status_code=status_code,
            method=method,
            url=url,
            path=path,
        )
        logger = logging.getLogger(__name__)
        logger.error(LogType.EXCEPTION, exc_info=exc, extra=attrs.as_dict())

    def log_validation_error(
        self,
        method: str,
        url: str,
        path: str,
        errors: list[Any],
    ) -> None:
        attrs = ExceptionAttributes(
            exception_type=ExceptionType.VALIDATION,
            error_class="RequestValidationError",
            error_message=f"Validation error: {len(errors)} error(s)",
            status_code=422,
            method=method,
            url=url,
            path=path,
            details=errors,
        )
        logger = logging.getLogger(__name__)
        logger.warning(LogType.EXCEPTION, extra=attrs.as_dict())

    def log_general_error(
        self,
        method: str,
        url: str,
        path: str,
        exc: Exception,
    ) -> None:
        attrs = ExceptionAttributes(
            exception_type=ExceptionType.GENERAL,
            error_class=type(exc).__name__,
            error_message=str(exc),
            status_code=500,
            method=method,
            url=url,
            path=path,
        )
        logger = logging.getLogger(__name__)
        logger.error(LogType.EXCEPTION, exc_info=exc, extra=attrs.as_dict())
