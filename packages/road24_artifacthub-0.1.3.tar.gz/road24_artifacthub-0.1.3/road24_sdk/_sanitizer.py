import json
import re
from typing import Any

SENSITIVE_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"password", re.IGNORECASE),
    re.compile(r"token", re.IGNORECASE),
    re.compile(r"secret", re.IGNORECASE),
    re.compile(r"api[_-]?key", re.IGNORECASE),
    re.compile(r"auth", re.IGNORECASE),
    re.compile(r"credential", re.IGNORECASE),
    re.compile(r"private[_-]?key", re.IGNORECASE),
    re.compile(r"access[_-]?key", re.IGNORECASE),
    re.compile(r"session[_-]?id", re.IGNORECASE),
    re.compile(r"cookie", re.IGNORECASE),
    re.compile(r"bearer", re.IGNORECASE),
    re.compile(r"pin", re.IGNORECASE),
    re.compile(r"cvv", re.IGNORECASE),
    re.compile(r"card[_-]?number", re.IGNORECASE),
)

MASK = "***REDACTED***"


def is_sensitive_key(key: str) -> bool:
    return any(pattern.search(key) for pattern in SENSITIVE_PATTERNS)


def sanitize_dict(data: dict[str, Any]) -> dict[str, Any]:
    result = {}
    for key, value in data.items():
        if is_sensitive_key(key):
            result[key] = MASK
        elif isinstance(value, dict):
            result[key] = sanitize_dict(value)
        elif isinstance(value, list):
            result[key] = [
                sanitize_dict(item) if isinstance(item, dict) else item for item in value
            ]
        else:
            result[key] = value
    return result


def sanitize_body(body: str) -> str:
    if not body or not body.strip():
        return body

    try:
        data = json.loads(body)
        if isinstance(data, dict):
            sanitized = sanitize_dict(data)
            return json.dumps(sanitized, ensure_ascii=False)
        if isinstance(data, list):
            sanitized_list = [
                sanitize_dict(item) if isinstance(item, dict) else item for item in data
            ]
            return json.dumps(sanitized_list, ensure_ascii=False)
        return body
    except (json.JSONDecodeError, TypeError):
        return body
