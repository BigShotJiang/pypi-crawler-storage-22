from dataclasses import dataclass, field
from typing import Any

from road24_sdk._types import (
    DbOperation,
    ExceptionType,
    HttpDirection,
    RedisOperation,
)


@dataclass(slots=True)
class LogRecord:
    timestamp: str
    trace_id: str
    log_level: str
    type: str
    service_name: str
    attributes: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "trace_id": self.trace_id,
            "log_level": self.log_level,
            "type": self.type,
            "service_name": self.service_name,
            "attributes": self.attributes,
        }


@dataclass(slots=True)
class HttpAttributes:
    direction: HttpDirection
    method: str
    url: str
    target: str
    status_code: int
    duration_seconds: float
    request_body: str = ""
    response_body: str = ""
    error_class: str = ""
    error_message: str = ""

    def as_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "direction": self.direction.value,
            "method": self.method,
            "url": self.url,
            "target": self.target,
            "status_code": self.status_code,
            "duration_seconds": self.duration_seconds,
            "request_body": self.request_body,
            "response_body": self.response_body,
        }
        if self.error_class:
            result["error_class"] = self.error_class
            result["error_message"] = self.error_message
        return result


@dataclass(slots=True)
class DbAttributes:
    operation: DbOperation
    table: str
    duration_seconds: float
    statement: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "operation": self.operation.value,
            "table": self.table,
            "duration_seconds": self.duration_seconds,
            "statement": self.statement,
        }


@dataclass(slots=True)
class RedisAttributes:
    operation: RedisOperation
    key: str
    duration_seconds: float
    command_args: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "operation": self.operation.value,
            "key": self.key,
            "duration_seconds": self.duration_seconds,
            "command_args": self.command_args,
        }


@dataclass(slots=True)
class ExceptionAttributes:
    exception_type: ExceptionType
    error_class: str
    error_message: str
    status_code: int
    method: str
    url: str
    path: str
    details: Any = None

    def as_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "exception_type": self.exception_type.value,
            "error_class": self.error_class,
            "error_message": self.error_message,
            "status_code": self.status_code,
            "method": self.method,
            "url": self.url,
            "path": self.path,
        }
        if self.details is not None:
            result["details"] = self.details
        return result
