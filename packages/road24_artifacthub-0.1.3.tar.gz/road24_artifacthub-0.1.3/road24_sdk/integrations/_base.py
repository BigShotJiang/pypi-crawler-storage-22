from abc import ABC, abstractmethod


class Integration(ABC):
    @abstractmethod
    def setup_once(self) -> None: ...

    @classmethod
    def _mark_setup_once(cls) -> bool:
        flag = f"_setup_once_called_{cls.__name__}"
        if getattr(cls, flag, False):
            return True
        setattr(cls, flag, True)
        return False

    @classmethod
    def _reset_setup_once(cls) -> None:
        flag = f"_setup_once_called_{cls.__name__}"
        setattr(cls, flag, False)
