import json
import logging
import secrets
import time
from contextvars import ContextVar
from http import HTTPStatus
from typing import TYPE_CHECKING, Any

from road24_sdk._formatter import clear_trace_context, get_trace_id, set_trace_context
from road24_sdk._sanitizer import sanitize_body
from road24_sdk._schemas import HttpAttributes
from road24_sdk._types import HttpDirection, LogType
from road24_sdk.integrations._base import Integration

if TYPE_CHECKING:
    from starlette.types import ASGIApp, Message, Receive, Scope, Send

logger = logging.getLogger(__name__)

_request_exception: ContextVar[Exception | None] = ContextVar("request_exception", default=None)


class HttpInputLogger:
    _BINARY_CONTENT_TYPES = (
        "multipart/form-data",
        "application/octet-stream",
        "image/",
        "audio/",
        "video/",
        "application/pdf",
        "application/zip",
        "application/gzip",
    )

    def log(
        self,
        scope: "Scope",
        status_code: int,
        duration_seconds: float,
        request_body: bytes = b"",
        response_body: bytes = b"",
        record_metrics: bool = True,
        exc: Exception | None = None,
    ) -> None:
        method = scope.get("method", "")
        path = scope.get("path", "")
        scheme = scope.get("scheme", "http")
        headers = dict(scope.get("headers", []))
        host = headers.get(b"host", b"").decode() or ""
        url = f"{scheme}://{host}{path}" if host else path
        content_type = headers.get(b"content-type", b"").decode() or ""

        if record_metrics:
            from road24_sdk.metrics.http import record_http_request

            record_http_request(
                method=method,
                url=url,
                status_code=status_code,
                duration_seconds=duration_seconds,
                direction=HttpDirection.INPUT,
            )

        http_attrs = HttpAttributes(
            direction=HttpDirection.INPUT,
            method=method,
            url=url,
            target=path,
            status_code=status_code,
            duration_seconds=duration_seconds,
            request_body=self._decode_body(request_body, content_type),
            response_body=self._decode_body(response_body, None),
            error_class=type(exc).__name__ if exc else "",
            error_message=str(exc) if exc else "",
        )

        log_level = self._get_log_level(status_code)
        getattr(logger, log_level)(
            LogType.HTTP_REQUEST, exc_info=exc if exc else None, extra=http_attrs.as_dict()
        )

    def generate_trace_id(self, scope: "Scope") -> str:
        headers = dict(scope.get("headers", []))
        return headers.get(b"x-trace-id", b"").decode() or secrets.token_hex(16)

    def _decode_body(self, body: bytes, content_type: str | None) -> str:
        if not body:
            return ""
        if self._is_binary_content(content_type):
            return f"<binary data: {len(body)} bytes>"
        try:
            decoded = body.decode("utf-8")
            return sanitize_body(decoded)
        except UnicodeDecodeError:
            return f"<binary data: {len(body)} bytes>"

    def _is_binary_content(self, content_type: str | None) -> bool:
        if not content_type or not isinstance(content_type, str):
            return False
        return any(bt in content_type.lower() for bt in self._BINARY_CONTENT_TYPES)

    def _get_log_level(self, status_code: int) -> str:
        if status_code < HTTPStatus.BAD_REQUEST:
            return "info"
        if status_code < HTTPStatus.INTERNAL_SERVER_ERROR:
            return "warning"
        return "error"


class FastApiLoggingIntegration(Integration):
    def __init__(
        self,
        *,
        enable_logging: bool = True,
        enable_metrics: bool = True,
        enable_exception_handlers: bool = True,
    ) -> None:
        self._enable_logging = enable_logging
        self._enable_metrics = enable_metrics
        self._enable_exception_handlers = enable_exception_handlers

    def setup_once(self) -> None:
        pass

    def setup(self, app: "ASGIApp") -> None:
        if self._enable_exception_handlers and self._is_fastapi_app(app):
            self._register_exception_handlers(app)

        app.add_middleware(
            _LogMiddleware,
            enable_logging=self._enable_logging,
            enable_metrics=self._enable_metrics,
        )

    @staticmethod
    def _is_fastapi_app(app: Any) -> bool:
        try:
            from starlette.applications import Starlette
        except ImportError:
            return False
        return isinstance(app, Starlette)

    def _register_exception_handlers(self, app: Any) -> None:
        from fastapi import HTTPException
        from fastapi.exceptions import RequestValidationError

        app.add_exception_handler(HTTPException, _http_exception_handler)
        app.add_exception_handler(RequestValidationError, _validation_exception_handler)
        app.add_exception_handler(Exception, _general_exception_handler)


def _get_trace_id_for_response() -> str | None:
    trace_id = get_trace_id()
    return trace_id if trace_id != "0" * 32 else None


async def _http_exception_handler(request: Any, exc: Any) -> Any:
    from fastapi.responses import JSONResponse

    if exc.status_code >= HTTPStatus.INTERNAL_SERVER_ERROR:
        _request_exception.set(exc)

    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail, "trace_id": _get_trace_id_for_response()},
        headers=getattr(exc, "headers", None),
    )


async def _validation_exception_handler(request: Any, exc: Any) -> Any:
    from fastapi.responses import JSONResponse

    _request_exception.set(exc)

    return JSONResponse(
        status_code=HTTPStatus.UNPROCESSABLE_ENTITY.value,
        content={"detail": exc.errors(), "trace_id": _get_trace_id_for_response()},
    )


async def _general_exception_handler(request: Any, exc: Exception) -> Any:
    from fastapi.responses import JSONResponse

    _request_exception.set(exc)

    return JSONResponse(
        status_code=HTTPStatus.INTERNAL_SERVER_ERROR.value,
        content={
            "detail": "Internal server error",
            "trace_id": _get_trace_id_for_response(),
            "error_type": type(exc).__name__,
        },
    )


class _LogMiddleware:
    def __init__(
        self,
        app: "ASGIApp",
        *,
        enable_logging: bool = True,
        enable_metrics: bool = True,
    ) -> None:
        self.app = app
        self._http_logger = HttpInputLogger()
        self._enable_logging = enable_logging
        self._enable_metrics = enable_metrics

    async def __call__(
        self,
        scope: "Scope",
        receive: "Receive",
        send: "Send",
    ) -> None:
        if scope["type"] != "http" or scope.get("path") == "/metrics":
            await self.app(scope, receive, send)
            return

        trace_id = self._http_logger.generate_trace_id(scope)
        trace_token = set_trace_context(trace_id)

        request_body = b""
        response_body = b""
        status_code = 500
        start_time = time.perf_counter()

        async def receive_wrapper() -> "Message":
            nonlocal request_body
            message = await receive()
            if message["type"] == "http.request":
                request_body += message.get("body", b"")
            return message

        async def send_wrapper(message: "Message") -> None:
            nonlocal response_body, status_code
            if message["type"] == "http.response.start":
                status_code = message["status"]
                headers = [
                    *message.get("headers", []),
                    (b"x-trace-id", trace_id.encode()),
                ]
                message = {**message, "headers": headers}
            elif message["type"] == "http.response.body":
                response_body += message.get("body", b"")
            await send(message)

        try:
            await self.app(scope, receive_wrapper, send_wrapper)
        except Exception as e:
            _request_exception.set(e)
            status_code = HTTPStatus.INTERNAL_SERVER_ERROR
            error_body = json.dumps({
                "detail": "Internal server error",
                "trace_id": trace_id,
                "error_type": type(e).__name__,
            }).encode()
            await send({"type": "http.response.start", "status": status_code, "headers": [
                (b"content-type", b"application/json"),
                (b"x-trace-id", trace_id.encode()),
            ]})
            await send({"type": "http.response.body", "body": error_body})
            response_body = error_body
        finally:
            exc = _request_exception.get()
            _request_exception.set(None)
            duration_seconds = time.perf_counter() - start_time
            if self._enable_logging:
                self._http_logger.log(
                    scope=scope,
                    status_code=status_code,
                    duration_seconds=duration_seconds,
                    request_body=request_body,
                    response_body=response_body,
                    record_metrics=self._enable_metrics,
                    exc=exc,
                )
            clear_trace_context(trace_token)
