import logging
import time
from http import HTTPStatus
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

from road24_sdk._sanitizer import sanitize_body
from road24_sdk._schemas import HttpAttributes
from road24_sdk._types import HttpDirection, LogType
from road24_sdk.integrations._base import Integration

if TYPE_CHECKING:
    from httpx import AsyncClient, Request, RequestNotRead, Response

logger = logging.getLogger(__name__)


class HttpOutputLogger:
    async def log_request_hook(self, request: "Request") -> None:
        request.extensions["start_time"] = time.perf_counter()

    async def log_response_hook(self, response: "Response") -> None:
        await response.aread()
        start_time = response.request.extensions.get("start_time")
        duration_seconds = time.perf_counter() - start_time if start_time else 0.0
        self.log(response.request, response, duration_seconds)

    def log(
        self,
        request: "Request",
        response: "Response",
        duration_seconds: float,
        record_metrics: bool = True,
    ) -> None:
        parsed = urlparse(str(request.url))
        url = str(request.url)

        if record_metrics:
            from road24_sdk.metrics.http import record_http_request

            record_http_request(
                method=request.method,
                url=url,
                status_code=response.status_code,
                duration_seconds=duration_seconds,
                direction=HttpDirection.OUTPUT,
            )

        request_body = self._get_request_body(request)
        response_body = self._decode_body(response.content, response.headers.get("content-type"))

        http_attrs = HttpAttributes(
            direction=HttpDirection.OUTPUT,
            method=request.method,
            url=url,
            target=parsed.path,
            status_code=response.status_code,
            duration_seconds=duration_seconds,
            request_body=sanitize_body(request_body),
            response_body=sanitize_body(response_body),
        )

        log_level = self._get_log_level(response.status_code)
        getattr(logger, log_level)(LogType.HTTP_REQUEST, extra=http_attrs.as_dict())

    def _get_request_body(self, request: "Request") -> str:
        from httpx import RequestNotRead

        content_type = request.headers.get("content-type")
        try:
            return self._decode_body(request.content, content_type)
        except RequestNotRead:
            return "<streaming request>"

    def _decode_body(self, content: bytes, content_type: str | None) -> str:
        if not content:
            return ""
        if self._is_binary_content(content_type):
            return f"<binary data: {len(content)} bytes>"
        try:
            return content.decode("utf-8")
        except UnicodeDecodeError:
            return f"<binary data: {len(content)} bytes>"

    def _is_binary_content(self, content_type: str | None) -> bool:
        if not content_type or not isinstance(content_type, str):
            return False
        binary_types = (
            "multipart/form-data",
            "application/octet-stream",
            "image/",
            "audio/",
            "video/",
            "application/pdf",
            "application/zip",
            "application/gzip",
        )
        return any(bt in content_type.lower() for bt in binary_types)

    def _get_log_level(self, status_code: int) -> str:
        if status_code < HTTPStatus.BAD_REQUEST:
            return "info"
        if status_code < HTTPStatus.INTERNAL_SERVER_ERROR:
            return "warning"
        return "error"


class HttpxLoggingIntegration(Integration):
    def __init__(
        self,
        *,
        enable_logging: bool = True,
        enable_metrics: bool = True,
    ) -> None:
        self._enable_logging = enable_logging
        self._enable_metrics = enable_metrics
        self._output_logger = HttpOutputLogger()

    def setup_once(self) -> None:
        if self._mark_setup_once():
            return
        from httpx import AsyncClient

        original_init = AsyncClient.__init__
        output_logger = self._output_logger
        enable_logging = self._enable_logging

        def _patched_init(self_client: "AsyncClient", *args: Any, **kwargs: Any) -> None:
            original_init(self_client, *args, **kwargs)
            if enable_logging:
                hooks = self_client.event_hooks
                hooks["request"].append(output_logger.log_request_hook)
                hooks["response"].append(output_logger.log_response_hook)

        AsyncClient.__init__ = _patched_init  # type: ignore[method-assign]

    def setup(self, client: "AsyncClient") -> None:
        if self._enable_logging:
            hooks = client.event_hooks
            hooks["request"].append(self._output_logger.log_request_hook)
            hooks["response"].append(self._output_logger.log_response_hook)

    def create_client(self, **kwargs: Any) -> "AsyncClient":
        from httpx import AsyncClient

        event_hooks: dict[str, list[Any]] = kwargs.pop(
            "event_hooks", {"request": [], "response": []}
        )

        if self._enable_logging:
            event_hooks["request"].append(self._output_logger.log_request_hook)
            event_hooks["response"].append(self._output_logger.log_response_hook)

        return AsyncClient(event_hooks=event_hooks, **kwargs)
