import logging
import time
from typing import TYPE_CHECKING, Any

from road24_sdk._schemas import RedisAttributes
from road24_sdk._types import LogType, RedisOperation
from road24_sdk.integrations._base import Integration

if TYPE_CHECKING:
    from redis.asyncio import Redis

logger = logging.getLogger(__name__)

OPERATION_MAP: dict[str, RedisOperation] = {
    "get": RedisOperation.GET,
    "set": RedisOperation.SET,
    "delete": RedisOperation.DELETE,
    "del": RedisOperation.DELETE,
    "expire": RedisOperation.EXPIRE,
    "hget": RedisOperation.HGET,
    "hset": RedisOperation.HSET,
    "lpush": RedisOperation.LPUSH,
    "rpush": RedisOperation.RPUSH,
    "lpop": RedisOperation.LPOP,
    "rpop": RedisOperation.RPOP,
    "publish": RedisOperation.PUBLISH,
    "subscribe": RedisOperation.SUBSCRIBE,
}


class RedisLogger:
    def __init__(self, *, record_metrics: bool = True) -> None:
        self._record_metrics = record_metrics

    def log(
        self,
        operation: RedisOperation,
        key: str,
        duration_seconds: float,
        args: str = "",
    ) -> None:
        if self._record_metrics:
            from road24_sdk.metrics.redis import record_redis_command

            record_redis_command(
                operation=operation,
                key=key,
                duration_seconds=duration_seconds,
            )

        redis_attrs = RedisAttributes(
            operation=operation,
            key=key,
            duration_seconds=duration_seconds,
            command_args=args,
        )

        logger.info(LogType.REDIS_COMMAND, extra=redis_attrs.as_dict())


class LoggedRedis:
    def __init__(
        self,
        client: "Redis",
        *,
        record_metrics: bool = True,
    ) -> None:
        self._client = client
        self._logger = RedisLogger(record_metrics=record_metrics)

    async def get(self, key: str) -> Any:
        return await self._execute("get", key)

    async def set(
        self,
        key: str,
        value: Any,
        ex: int | None = None,
        px: int | None = None,
        nx: bool = False,
        xx: bool = False,
    ) -> Any:
        kwargs: dict[str, Any] = {}
        if ex is not None:
            kwargs["ex"] = ex
        if px is not None:
            kwargs["px"] = px
        if nx:
            kwargs["nx"] = nx
        if xx:
            kwargs["xx"] = xx

        args_str = f"value={value}"
        if kwargs:
            args_str += ", " + ", ".join(f"{k}={v}" for k, v in kwargs.items())

        return await self._execute("set", key, value, args_str=args_str, **kwargs)

    async def delete(self, *keys: str) -> int:
        key = keys[0] if keys else "unknown"
        return await self._execute("delete", key, *keys)

    async def expire(self, key: str, seconds: int) -> bool:
        return await self._execute("expire", key, seconds, args_str=f"seconds={seconds}")

    async def hget(self, name: str, key: str) -> Any:
        return await self._execute("hget", name, key, args_str=f"field={key}")

    async def hset(
        self,
        name: str,
        key: str | None = None,
        value: Any = None,
        mapping: dict[str, Any] | None = None,
    ) -> int:
        args_str = f"field={key}" if key else f"mapping={len(mapping or {})} fields"
        return await self._execute(
            "hset",
            name,
            key,
            value,
            mapping=mapping,
            args_str=args_str,
        )

    async def lpush(self, key: str, *values: Any) -> int:
        return await self._execute("lpush", key, *values, args_str=f"count={len(values)}")

    async def rpush(self, key: str, *values: Any) -> int:
        return await self._execute("rpush", key, *values, args_str=f"count={len(values)}")

    async def lpop(self, key: str, count: int | None = None) -> Any:
        return await self._execute("lpop", key, count=count)

    async def rpop(self, key: str, count: int | None = None) -> Any:
        return await self._execute("rpop", key, count=count)

    async def ping(self) -> bool:
        return await self._client.ping()

    async def aclose(self) -> None:
        await self._client.aclose()

    async def _execute(
        self,
        command: str,
        key: str,
        *args: Any,
        args_str: str = "",
        **kwargs: Any,
    ) -> Any:
        operation = OPERATION_MAP.get(command, RedisOperation.OTHER)
        start_time = time.perf_counter()
        try:
            method = getattr(self._client, command)
            return await method(key, *args, **kwargs)
        finally:
            duration = time.perf_counter() - start_time
            self._logger.log(
                operation=operation,
                key=key,
                duration_seconds=duration,
                args=args_str,
            )


class RedisLoggingIntegration(Integration):
    def __init__(
        self,
        *,
        enable_logging: bool = True,
        enable_metrics: bool = True,
    ) -> None:
        self._enable_logging = enable_logging
        self._enable_metrics = enable_metrics

    def setup_once(self) -> None:
        if self._mark_setup_once():
            return
        from redis.asyncio import Redis

        original_execute = Redis.execute_command
        redis_logger = RedisLogger(record_metrics=self._enable_metrics)
        enable_logging = self._enable_logging

        async def _patched_execute(
            self_client: "Redis", *args: Any, **kwargs: Any,
        ) -> Any:
            command = str(args[0]).lower() if args else "unknown"
            key = str(args[1]) if len(args) > 1 else ""
            operation = OPERATION_MAP.get(command, RedisOperation.OTHER)
            start_time = time.perf_counter()
            try:
                return await original_execute(self_client, *args, **kwargs)
            finally:
                duration = time.perf_counter() - start_time
                if enable_logging:
                    redis_logger.log(
                        operation=operation,
                        key=key,
                        duration_seconds=duration,
                    )

        Redis.execute_command = _patched_execute  # type: ignore[method-assign]

    def setup(self, client: "Redis") -> None:
        original_execute = client.execute_command
        redis_logger = RedisLogger(record_metrics=self._enable_metrics)
        enable_logging = self._enable_logging

        async def _patched_execute(*args: Any, **kwargs: Any) -> Any:
            command = str(args[0]).lower() if args else "unknown"
            key = str(args[1]) if len(args) > 1 else ""
            operation = OPERATION_MAP.get(command, RedisOperation.OTHER)
            start_time = time.perf_counter()
            try:
                return await original_execute(*args, **kwargs)
            finally:
                duration = time.perf_counter() - start_time
                if enable_logging:
                    redis_logger.log(
                        operation=operation,
                        key=key,
                        duration_seconds=duration,
                    )

        client.execute_command = _patched_execute  # type: ignore[method-assign]

    def instrument(self, client: "Redis") -> LoggedRedis:
        return LoggedRedis(
            client,
            record_metrics=self._enable_metrics,
        )
