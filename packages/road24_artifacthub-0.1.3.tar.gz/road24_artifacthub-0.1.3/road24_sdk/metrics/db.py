from prometheus_client import Counter, Histogram

from road24_sdk._types import DbOperation

DB_QUERY_DURATION = Histogram(
    name="db_query_duration_seconds",
    documentation="Database query duration in seconds",
    labelnames=["operation", "table"],
    buckets=(0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5),
)

DB_QUERY_TOTAL = Counter(
    name="db_queries_total",
    documentation="Total number of database queries",
    labelnames=["operation", "table"],
)


def record_db_query(
    operation: DbOperation,
    table: str,
    duration_seconds: float,
) -> None:
    labels = {
        "operation": operation.value,
        "table": table,
    }
    DB_QUERY_TOTAL.labels(**labels).inc()
    DB_QUERY_DURATION.labels(**labels).observe(duration_seconds)
