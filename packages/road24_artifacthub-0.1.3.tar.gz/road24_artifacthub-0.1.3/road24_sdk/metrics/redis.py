from prometheus_client import Counter, Histogram

from road24_sdk._types import RedisOperation

REDIS_COMMAND_DURATION = Histogram(
    name="redis_command_duration_seconds",
    documentation="Redis command duration in seconds",
    labelnames=["operation", "key"],
    buckets=(0.0005, 0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5),
)

REDIS_COMMAND_TOTAL = Counter(
    name="redis_commands_total",
    documentation="Total number of Redis commands",
    labelnames=["operation", "key"],
)


def record_redis_command(
    operation: RedisOperation,
    key: str,
    duration_seconds: float,
) -> None:
    labels = {
        "operation": operation.value,
        "key": key,
    }
    REDIS_COMMAND_TOTAL.labels(**labels).inc()
    REDIS_COMMAND_DURATION.labels(**labels).observe(duration_seconds)
