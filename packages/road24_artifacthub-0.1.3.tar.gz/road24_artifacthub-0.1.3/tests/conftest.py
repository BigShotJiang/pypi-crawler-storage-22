from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, Mock

import pytest
from faker import Faker

from road24_sdk._types import (
    DbOperation,
    ExceptionType,
    HttpDirection,
    RedisOperation,
)


@pytest.fixture(autouse=True)
def reset_prometheus_registry() -> Any:
    yield


@pytest.fixture
def faker() -> Faker:
    return Faker()


@pytest.fixture
def sample_http_log_data(faker: Faker) -> dict[str, Any]:
    return {
        "method": faker.random_element(["GET", "POST", "PUT", "DELETE", "PATCH"]),
        "url": faker.url(),
        "status_code": faker.random_element([200, 201, 400, 404, 500]),
        "duration_ms": faker.pyfloat(min_value=0.1, max_value=5000.0),
        "direction": HttpDirection.INPUT,
    }


@pytest.fixture
def sample_redis_log_data(faker: Faker) -> dict[str, Any]:
    return {
        "operation": RedisOperation.GET,
        "key": faker.pystr(min_chars=5, max_chars=20),
        "duration_ms": faker.pyfloat(min_value=0.01, max_value=100.0),
    }


@pytest.fixture
def sample_duration_ms(faker: Faker) -> float:
    return faker.pyfloat(min_value=0.1, max_value=5000.0)


@pytest.fixture
def sample_request_id(faker: Faker) -> str:
    return faker.uuid4()


@pytest.fixture
def sample_log_record_data(faker: Faker) -> dict[str, Any]:
    return {
        "timestamp": "2025-01-01T00:00:00.000Z",
        "trace_id": faker.hexify("????????????????????????????????"),
        "log_level": "INFO",
        "type": "http_request",
        "service_name": faker.pystr(min_chars=5, max_chars=15),
        "attributes": {},
    }


@pytest.fixture
def sample_http_attributes(faker: Faker) -> dict[str, Any]:
    return {
        "direction": HttpDirection.INPUT,
        "method": faker.random_element(["GET", "POST", "PUT", "DELETE"]),
        "url": faker.url(),
        "target": f"/api/v1/{faker.pystr(min_chars=3, max_chars=10)}",
        "status_code": faker.random_element([200, 201, 400, 404, 500]),
        "duration_seconds": faker.pyfloat(min_value=0.001, max_value=5.0),
        "request_body": "",
        "response_body": "",
    }


@pytest.fixture
def sample_db_attributes(faker: Faker) -> dict[str, Any]:
    table_name = faker.pystr(min_chars=3, max_chars=15)
    return {
        "operation": DbOperation.SELECT,
        "table": table_name,
        "duration_seconds": faker.pyfloat(min_value=0.001, max_value=2.0),
        "statement": f"SELECT * FROM {table_name}",
    }


@pytest.fixture
def sample_redis_attributes(faker: Faker) -> dict[str, Any]:
    return {
        "operation": RedisOperation.GET,
        "key": faker.pystr(min_chars=5, max_chars=20),
        "duration_seconds": faker.pyfloat(min_value=0.001, max_value=1.0),
        "command_args": "",
    }


@pytest.fixture
def sample_exception_attributes(faker: Faker) -> dict[str, Any]:
    return {
        "exception_type": ExceptionType.HTTP,
        "error_class": "ValueError",
        "error_message": faker.sentence(),
        "status_code": 500,
        "method": "GET",
        "url": faker.url(),
        "path": f"/api/v1/{faker.pystr(min_chars=3, max_chars=10)}",
    }


@pytest.fixture
def mock_redis_client() -> AsyncMock:
    client = AsyncMock()
    client.get = AsyncMock(return_value=b"value")
    client.set = AsyncMock(return_value=True)
    client.delete = AsyncMock(return_value=1)
    client.expire = AsyncMock(return_value=True)
    client.hget = AsyncMock(return_value=b"value")
    client.hset = AsyncMock(return_value=1)
    client.lpush = AsyncMock(return_value=1)
    client.rpush = AsyncMock(return_value=1)
    client.lpop = AsyncMock(return_value=b"value")
    client.rpop = AsyncMock(return_value=b"value")
    client.ping = AsyncMock(return_value=True)
    client.aclose = AsyncMock()
    return client


@pytest.fixture
def mock_scope() -> dict[str, Any]:
    return {
        "type": "http",
        "method": "GET",
        "path": "/api/v1/test",
        "scheme": "https",
        "headers": [
            (b"host", b"example.com"),
            (b"x-trace-id", b"abc123def456"),
        ],
    }


@pytest.fixture
def mock_httpx_request() -> Mock:
    request = Mock()
    request.method = "POST"
    request.url = "https://api.example.com/v1/data"
    request.content = b'{"key": "value"}'
    request.extensions = {}
    return request


@pytest.fixture
def mock_httpx_response() -> Mock:
    response = Mock()
    response.status_code = 200
    response.text = '{"result": "ok"}'
    response.request = Mock()
    response.request.method = "POST"
    response.request.url = "https://api.example.com/v1/data"
    response.request.content = b'{"key": "value"}'
    response.request.extensions = {"start_time": 1000.0}
    response.aread = AsyncMock()
    return response
