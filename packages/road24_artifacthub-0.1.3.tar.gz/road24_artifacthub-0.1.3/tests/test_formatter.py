from __future__ import annotations

import json
import logging
from typing import Any
from unittest.mock import Mock, patch

import pytest

from road24_sdk._formatter import (
    SILENT_LOGGERS_DEBUG,
    SILENT_LOGGERS_PROD,
    ZERO_TRACE_ID,
    ExceptionLogger,
    LogFormatter,
    clear_trace_context,
    get_trace_id,
    set_trace_context,
    setup_logging,
)
from road24_sdk._types import LogType


class TestTraceContext:
    async def test_set_and_get_trace_id(self, faker: Any) -> None:
        # Arrange
        trace_id = faker.hexify("????????????????????????????????")

        # Act
        token = set_trace_context(trace_id)

        # Assert
        assert get_trace_id() == trace_id, "Trace ID should match the set value"

        # Cleanup
        clear_trace_context(token)

    async def test_get_trace_id_returns_zero_when_not_set(self) -> None:
        # Arrange
        clear_trace_context()

        # Act
        result = get_trace_id()

        # Assert
        assert result == ZERO_TRACE_ID, (
            "Trace ID should return zero trace ID when not set"
        )

    async def test_clear_trace_context_with_token(self, faker: Any) -> None:
        # Arrange
        trace_id = faker.hexify("????????????????????????????????")
        token = set_trace_context(trace_id)

        # Act
        clear_trace_context(token)

        # Assert
        assert get_trace_id() == ZERO_TRACE_ID, (
            "Trace ID should be zero after clearing with token"
        )

    async def test_clear_trace_context_without_token(self, faker: Any) -> None:
        # Arrange
        trace_id = faker.hexify("????????????????????????????????")
        set_trace_context(trace_id)

        # Act
        clear_trace_context()

        # Assert
        assert get_trace_id() == ZERO_TRACE_ID, (
            "Trace ID should be zero after clearing without token"
        )

    async def test_zero_trace_id_is_32_zeros(self) -> None:
        # Assert
        assert ZERO_TRACE_ID == "0" * 32, "ZERO_TRACE_ID should be 32 zeros"
        assert len(ZERO_TRACE_ID) == 32, "ZERO_TRACE_ID should be 32 characters"


class TestLogFormatter:
    async def test_format_produces_valid_json(self) -> None:
        # Arrange
        formatter = LogFormatter()
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=10,
            msg="test message",
            args=None,
            exc_info=None,
        )

        # Act
        result = formatter.format(record)

        # Assert
        parsed = json.loads(result)
        assert isinstance(parsed, dict), "Format output should be valid JSON"

    async def test_format_contains_expected_fields(self) -> None:
        # Arrange
        formatter = LogFormatter()
        record = logging.LogRecord(
            name="test.logger",
            level=logging.WARNING,
            pathname="test.py",
            lineno=42,
            msg="warning message",
            args=None,
            exc_info=None,
        )

        # Act
        result = formatter.format(record)
        parsed = json.loads(result)

        # Assert
        assert "timestamp" in parsed, "Should contain timestamp"
        assert "trace_id" in parsed, "Should contain trace_id"
        assert parsed["log_level"] == "WARNING", "Log level should be WARNING"
        assert parsed["type"] == "warning message", "Type should be the message"

    async def test_format_uses_current_trace_id(self, faker: Any) -> None:
        # Arrange
        trace_id = faker.hexify("????????????????????????????????")
        token = set_trace_context(trace_id)
        formatter = LogFormatter()
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="msg",
            args=None,
            exc_info=None,
        )

        try:
            # Act
            result = formatter.format(record)
            parsed = json.loads(result)

            # Assert
            assert parsed["trace_id"] == trace_id, "Should use current trace context"
        finally:
            clear_trace_context(token)

    async def test_format_uses_zero_trace_id_when_not_set(self) -> None:
        # Arrange
        clear_trace_context()
        formatter = LogFormatter()
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="msg",
            args=None,
            exc_info=None,
        )

        # Act
        result = formatter.format(record)
        parsed = json.loads(result)

        # Assert
        assert parsed["trace_id"] == ZERO_TRACE_ID, (
            "Should use zero trace ID when not set"
        )

    async def test_build_attributes_includes_standard_info(self) -> None:
        # Arrange
        formatter = LogFormatter()
        record = logging.LogRecord(
            name="my.logger",
            level=logging.INFO,
            pathname="mymodule.py",
            lineno=99,
            msg="msg",
            args=None,
            exc_info=None,
        )

        # Act
        attrs = formatter._build_attributes(record)

        # Assert
        assert attrs["logger_name"] == "my.logger", "Should include logger name"
        assert attrs["code_lineno"] == 99, "Should include line number"
        assert "code_function" in attrs, "Should include function name key"

    async def test_build_attributes_includes_extra_fields(self) -> None:
        # Arrange
        formatter = LogFormatter()
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="msg",
            args=None,
            exc_info=None,
        )
        record.custom_field = "custom_value"

        # Act
        attrs = formatter._build_attributes(record)

        # Assert
        assert attrs["custom_field"] == "custom_value", (
            "Should include extra fields from log record"
        )

    async def test_build_attributes_includes_exception_info(self) -> None:
        # Arrange
        formatter = LogFormatter()
        try:
            raise ValueError("test error")
        except ValueError:
            import sys

            exc_info = sys.exc_info()

        record = logging.LogRecord(
            name="test",
            level=logging.ERROR,
            pathname="test.py",
            lineno=1,
            msg="error",
            args=None,
            exc_info=exc_info,
        )

        # Act
        attrs = formatter._build_attributes(record)

        # Assert
        assert attrs["exception_type"] == "ValueError", "Should include exception type"
        assert attrs["exception_message"] == "test error", (
            "Should include exception message"
        )
        assert "exception_stacktrace" in attrs, "Should include exception stacktrace"

    async def test_format_timestamp_format(self) -> None:
        # Arrange
        formatter = LogFormatter()
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="msg",
            args=None,
            exc_info=None,
        )

        # Act
        result = formatter.format(record)
        parsed = json.loads(result)

        # Assert
        ts = parsed["timestamp"]
        assert ts.endswith("Z"), "Timestamp should end with Z"
        assert "T" in ts, "Timestamp should contain T separator"


class TestSetupLogging:
    async def test_setup_logging_sets_service_name(self) -> None:
        # Arrange & Act
        setup_logging(level="INFO", service_name="test-service")

        # Assert
        from road24_sdk import _formatter as formatter_mod

        assert formatter_mod._service_name == "test-service", "Service name should be set"

    async def test_setup_logging_sets_root_handler(self) -> None:
        # Arrange & Act
        setup_logging(level="INFO", service_name="test-service")

        # Assert
        root_logger = logging.getLogger()
        assert len(root_logger.handlers) == 1, "Should have exactly one handler"
        assert isinstance(root_logger.handlers[0].formatter, LogFormatter), (
            "Handler should use LogFormatter"
        )

    @pytest.mark.parametrize(
        "level,expected_level",
        [
            ("DEBUG", logging.DEBUG),
            ("INFO", logging.INFO),
            ("WARNING", logging.WARNING),
            ("ERROR", logging.ERROR),
        ],
        ids=["debug", "info", "warning", "error"],
    )
    async def test_setup_logging_sets_level(
        self, level: str, expected_level: int
    ) -> None:
        # Arrange & Act
        setup_logging(level=level, service_name="test")

        # Assert
        root_logger = logging.getLogger()
        assert root_logger.level == expected_level, f"Root logger level should be {level}"

    async def test_setup_logging_debug_silences_fewer_loggers(self) -> None:
        # Arrange & Act
        setup_logging(level="DEBUG", service_name="test", debug=True)

        # Assert
        for name in SILENT_LOGGERS_DEBUG:
            lib_logger = logging.getLogger(name)
            assert lib_logger.level == logging.WARNING, (
                f"Logger '{name}' should be silenced to WARNING in debug mode"
            )

    async def test_setup_logging_prod_silences_more_loggers(self) -> None:
        # Arrange & Act
        setup_logging(level="INFO", service_name="test", debug=False)

        # Assert
        for name in SILENT_LOGGERS_PROD:
            lib_logger = logging.getLogger(name)
            assert lib_logger.level == logging.CRITICAL, (
                f"Logger '{name}' should be silenced to CRITICAL in prod mode"
            )

    async def test_setup_logging_clears_existing_handlers(self) -> None:
        # Arrange
        root_logger = logging.getLogger()
        root_logger.addHandler(logging.StreamHandler())
        root_logger.addHandler(logging.StreamHandler())

        # Act
        setup_logging(level="INFO", service_name="test")

        # Assert
        assert len(root_logger.handlers) == 1, (
            "Should clear existing handlers and add one"
        )


class TestExceptionLogger:
    async def test_log_http_error(self, faker: Any) -> None:
        # Arrange
        exc_logger = ExceptionLogger()
        exc = ValueError("something went wrong")
        method = "POST"
        url = faker.url()
        path = "/api/v1/resource"

        with patch("road24_sdk._formatter.logging.getLogger") as mock_get_logger:
            mock_logger = Mock()
            mock_get_logger.return_value = mock_logger

            # Act
            exc_logger.log_http_error(
                method=method,
                url=url,
                path=path,
                status_code=500,
                detail="something went wrong",
                exc=exc,
            )

            # Assert
            mock_logger.error.assert_called_once()
            call_args = mock_logger.error.call_args
            assert call_args[0][0] == LogType.EXCEPTION, "Should log with EXCEPTION type"
            assert call_args[1]["exc_info"] is exc, "Should pass exception info"
            extra = call_args[1]["extra"]
            assert extra["exception_type"] == "http", "Exception type should be http"
            assert extra["error_class"] == "ValueError", (
                "Error class should be ValueError"
            )

    async def test_log_validation_error(self, faker: Any) -> None:
        # Arrange
        exc_logger = ExceptionLogger()
        errors = [
            {"field": "name", "msg": "required"},
            {"field": "email", "msg": "invalid"},
        ]

        with patch("road24_sdk._formatter.logging.getLogger") as mock_get_logger:
            mock_logger = Mock()
            mock_get_logger.return_value = mock_logger

            # Act
            exc_logger.log_validation_error(
                method="POST",
                url=faker.url(),
                path="/api/v1/users",
                errors=errors,
            )

            # Assert
            mock_logger.warning.assert_called_once()
            call_args = mock_logger.warning.call_args
            assert call_args[0][0] == LogType.EXCEPTION, "Should log with EXCEPTION type"
            extra = call_args[1]["extra"]
            assert extra["exception_type"] == "validation", (
                "Exception type should be validation"
            )
            assert extra["error_class"] == "RequestValidationError", (
                "Error class should be RequestValidationError"
            )
            assert extra["status_code"] == 422, "Status code should be 422"
            assert extra["details"] == errors, "Details should match errors"

    async def test_log_general_error(self, faker: Any) -> None:
        # Arrange
        exc_logger = ExceptionLogger()
        exc = RuntimeError("unexpected failure")

        with patch("road24_sdk._formatter.logging.getLogger") as mock_get_logger:
            mock_logger = Mock()
            mock_get_logger.return_value = mock_logger

            # Act
            exc_logger.log_general_error(
                method="GET",
                url=faker.url(),
                path="/api/v1/data",
                exc=exc,
            )

            # Assert
            mock_logger.error.assert_called_once()
            call_args = mock_logger.error.call_args
            extra = call_args[1]["extra"]
            assert extra["exception_type"] == "general", (
                "Exception type should be general"
            )
            assert extra["error_class"] == "RuntimeError", (
                "Error class should be RuntimeError"
            )
            assert extra["error_message"] == "unexpected failure", (
                "Error message should match"
            )
            assert extra["status_code"] == 500, "Status code should be 500"
