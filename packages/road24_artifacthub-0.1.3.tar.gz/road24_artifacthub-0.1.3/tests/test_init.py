from __future__ import annotations

from unittest.mock import patch

import road24_sdk
from road24_sdk._types import ArtifactHubConfig
from road24_sdk.integrations._base import Integration


class _StubIntegration(Integration):
    def setup_once(self) -> None:
        pass


class _FailingIntegration(Integration):
    def setup_once(self) -> None:
        raise RuntimeError("boom")


async def test_init_stores_config() -> None:
    with patch("road24_sdk.setup_logging"):
        road24_sdk.init(
            service_name="test-svc",
            log_level="DEBUG",
            debug=True,
            log_format="text",
        )

    cfg = road24_sdk.configure()
    assert cfg.service_name == "test-svc"
    assert cfg.log_level == "DEBUG"
    assert cfg.debug is True
    assert cfg.log_format == "text"


async def test_init_calls_setup_logging() -> None:
    with patch("road24_sdk.setup_logging") as mock_setup:
        road24_sdk.init(service_name="svc", log_level="WARNING", debug=True)

    mock_setup.assert_called_once_with(level="WARNING", service_name="svc", debug=True)


async def test_configure_returns_defaults_when_not_initialized() -> None:
    road24_sdk._config = None
    cfg = road24_sdk.configure()
    assert cfg == ArtifactHubConfig()


async def test_init_calls_setup_once_on_integrations() -> None:
    integration = _StubIntegration()
    with (
        patch("road24_sdk.setup_logging"),
        patch.object(integration, "setup_once") as mock_setup_once,
    ):
        road24_sdk.init(service_name="svc", integrations=[integration])
    mock_setup_once.assert_called_once()


async def test_init_continues_when_integration_fails() -> None:
    failing = _FailingIntegration()
    good = _StubIntegration()
    with (
        patch("road24_sdk.setup_logging"),
        patch.object(good, "setup_once") as mock_good,
    ):
        road24_sdk.init(service_name="svc", integrations=[failing, good])
    mock_good.assert_called_once()


async def test_init_stores_integrations_in_config() -> None:
    integration = _StubIntegration()
    with (
        patch("road24_sdk.setup_logging"),
        patch.object(integration, "setup_once"),
    ):
        road24_sdk.init(service_name="svc", integrations=[integration])
    cfg = road24_sdk.configure()
    assert cfg.integrations == [integration]


async def test_init_works_without_integrations() -> None:
    with patch("road24_sdk.setup_logging"):
        road24_sdk.init(service_name="svc")
    cfg = road24_sdk.configure()
    assert cfg.integrations == []
