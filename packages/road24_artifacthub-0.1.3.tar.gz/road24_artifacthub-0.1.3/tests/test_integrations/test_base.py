from __future__ import annotations

import pytest

from road24_sdk.integrations._base import Integration


class ConcreteA(Integration):
    def setup_once(self) -> None:
        pass


class ConcreteB(Integration):
    def setup_once(self) -> None:
        pass


@pytest.fixture(autouse=True)
def _reset_flags() -> None:
    ConcreteA._reset_setup_once()
    ConcreteB._reset_setup_once()


async def test_integration_abc_not_instantiable() -> None:
    with pytest.raises(TypeError):
        Integration()  # type: ignore[abstract]


async def test_mark_setup_once_returns_false_first_call() -> None:
    result = ConcreteA._mark_setup_once()
    assert result is False


async def test_mark_setup_once_returns_true_second_call() -> None:
    ConcreteA._mark_setup_once()
    result = ConcreteA._mark_setup_once()
    assert result is True


async def test_reset_setup_once_resets_flag() -> None:
    ConcreteA._mark_setup_once()
    ConcreteA._reset_setup_once()
    result = ConcreteA._mark_setup_once()
    assert result is False


async def test_subclasses_have_independent_flags() -> None:
    ConcreteA._mark_setup_once()
    result = ConcreteB._mark_setup_once()
    assert result is False
