from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from unittest.mock import AsyncMock, Mock, patch

import pytest

from road24_sdk._types import HttpDirection, LogType
from road24_sdk.integrations.fastapi import (
    FastApiLoggingIntegration,
    HttpInputLogger,
    _LogMiddleware,
    _request_exception,
)
from tests.test_data_classes import HttpLogLevelTestCase

LOG_LEVEL_CASES = [
    HttpLogLevelTestCase(test_id="info_200", status_code=200, expected_level="info"),
    HttpLogLevelTestCase(test_id="info_201", status_code=201, expected_level="info"),
    HttpLogLevelTestCase(test_id="info_301", status_code=301, expected_level="info"),
    HttpLogLevelTestCase(
        test_id="warning_400", status_code=400, expected_level="warning"
    ),
    HttpLogLevelTestCase(
        test_id="warning_404", status_code=404, expected_level="warning"
    ),
    HttpLogLevelTestCase(
        test_id="warning_422", status_code=422, expected_level="warning"
    ),
    HttpLogLevelTestCase(test_id="error_500", status_code=500, expected_level="error"),
    HttpLogLevelTestCase(test_id="error_503", status_code=503, expected_level="error"),
]


class TestHttpInputLogger:
    async def test_log_records_metrics(self, mock_scope: dict[str, Any]) -> None:
        # Arrange
        input_logger = HttpInputLogger()

        with (
            patch("road24_sdk.integrations.fastapi.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request") as mock_record,
        ):
            # Act
            input_logger.log(
                scope=mock_scope,
                status_code=200,
                duration_seconds=0.1,
            )

            # Assert
            mock_record.assert_called_once_with(
                method="GET",
                url="https://example.com/api/v1/test",
                status_code=200,
                duration_seconds=0.1,
                direction=HttpDirection.INPUT,
            )

    async def test_log_skips_metrics_when_disabled(
        self, mock_scope: dict[str, Any]
    ) -> None:
        # Arrange
        input_logger = HttpInputLogger()

        with (
            patch("road24_sdk.integrations.fastapi.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request") as mock_record,
        ):
            # Act
            input_logger.log(
                scope=mock_scope,
                status_code=200,
                duration_seconds=0.1,
                record_metrics=False,
            )

            # Assert
            mock_record.assert_not_called()

    async def test_log_server_error_without_exception(
        self, mock_scope: dict[str, Any]
    ) -> None:
        # Arrange
        input_logger = HttpInputLogger()

        with (
            patch("road24_sdk.integrations.fastapi.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            # Act
            input_logger.log(
                scope=mock_scope,
                status_code=500,
                duration_seconds=0.1,
            )

            # Assert
            mock_logger.error.assert_called_once()
            call_args = mock_logger.error.call_args
            assert call_args[0][0] == LogType.HTTP_REQUEST
            extra = call_args[1]["extra"]
            assert extra["status_code"] == 500
            assert "error_class" not in extra
            assert "error_message" not in extra

    async def test_log_server_error_with_exception(
        self, mock_scope: dict[str, Any]
    ) -> None:
        # Arrange
        input_logger = HttpInputLogger()
        exc = ValueError("something broke")

        with (
            patch("road24_sdk.integrations.fastapi.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            # Act
            input_logger.log(
                scope=mock_scope,
                status_code=500,
                duration_seconds=0.1,
                exc=exc,
            )

            # Assert
            mock_logger.error.assert_called_once()
            call_args = mock_logger.error.call_args
            assert call_args[0][0] == LogType.HTTP_REQUEST
            assert call_args[1]["exc_info"] is exc
            extra = call_args[1]["extra"]
            assert extra["status_code"] == 500
            assert extra["error_class"] == "ValueError"
            assert extra["error_message"] == "something broke"

    async def test_log_success_does_not_include_error_fields(
        self, mock_scope: dict[str, Any]
    ) -> None:
        # Arrange
        input_logger = HttpInputLogger()

        with (
            patch("road24_sdk.integrations.fastapi.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            # Act
            input_logger.log(
                scope=mock_scope,
                status_code=200,
                duration_seconds=0.1,
            )

            # Assert
            extra = mock_logger.info.call_args[1]["extra"]
            assert "error_class" not in extra
            assert "error_message" not in extra

    async def test_log_success_logs_info(self, mock_scope: dict[str, Any]) -> None:
        # Arrange
        input_logger = HttpInputLogger()

        with (
            patch("road24_sdk.integrations.fastapi.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            # Act
            input_logger.log(
                scope=mock_scope,
                status_code=200,
                duration_seconds=0.1,
            )

            # Assert
            mock_logger.info.assert_called_once()
            call_args = mock_logger.info.call_args
            assert call_args[0][0] == LogType.HTTP_REQUEST, (
                "Should log with HTTP_REQUEST type"
            )

    async def test_log_client_error_logs_warning(
        self, mock_scope: dict[str, Any]
    ) -> None:
        # Arrange
        input_logger = HttpInputLogger()

        with (
            patch("road24_sdk.integrations.fastapi.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            # Act
            input_logger.log(
                scope=mock_scope,
                status_code=404,
                duration_seconds=0.1,
            )

            # Assert
            mock_logger.warning.assert_called_once()

    async def test_log_constructs_url_from_scope(self) -> None:
        # Arrange
        input_logger = HttpInputLogger()
        scope = {
            "method": "POST",
            "path": "/api/v1/items",
            "scheme": "http",
            "headers": [(b"host", b"localhost:8000")],
        }

        with (
            patch("road24_sdk.integrations.fastapi.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            # Act
            input_logger.log(
                scope=scope,
                status_code=201,
                duration_seconds=0.05,
            )

            # Assert
            call_args = mock_logger.info.call_args
            extra = call_args[1]["extra"]
            assert extra["url"] == "http://localhost:8000/api/v1/items", (
                "URL should be constructed from scope"
            )

    async def test_log_url_fallback_to_path_when_no_host(self) -> None:
        # Arrange
        input_logger = HttpInputLogger()
        scope = {
            "method": "GET",
            "path": "/health",
            "scheme": "http",
            "headers": [],
        }

        with (
            patch("road24_sdk.integrations.fastapi.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            # Act
            input_logger.log(
                scope=scope,
                status_code=200,
                duration_seconds=0.01,
            )

            # Assert
            call_args = mock_logger.info.call_args
            extra = call_args[1]["extra"]
            assert extra["url"] == "/health", "URL should fallback to path when no host"

    async def test_log_decodes_request_and_response_body(
        self, mock_scope: dict[str, Any]
    ) -> None:
        # Arrange
        input_logger = HttpInputLogger()

        with (
            patch("road24_sdk.integrations.fastapi.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            # Act
            input_logger.log(
                scope=mock_scope,
                status_code=200,
                duration_seconds=0.1,
                request_body=b'{"name": "test"}',
                response_body=b'{"id": 1}',
            )

            # Assert
            call_args = mock_logger.info.call_args
            extra = call_args[1]["extra"]
            assert extra["request_body"] != "", "Request body should be decoded"
            assert extra["response_body"] != "", "Response body should be decoded"

    async def test_decode_body_empty(self) -> None:
        # Arrange
        input_logger = HttpInputLogger()

        # Act
        result = input_logger._decode_body(b"", None)

        # Assert
        assert result == "", "Empty bytes should return empty string"

    async def test_decode_body_binary_data(self) -> None:
        # Arrange
        input_logger = HttpInputLogger()

        # Act
        result = input_logger._decode_body(b"\x80\x81\x82", None)

        # Assert
        assert "<binary data:" in result, "Non-UTF8 data should return binary data marker"

    async def test_decode_body_multipart_form_data(self) -> None:
        # Arrange
        input_logger = HttpInputLogger()

        # Act
        result = input_logger._decode_body(b"file content", "multipart/form-data; boundary=xxx")

        # Assert
        assert "<binary data:" in result, "Multipart form data should return binary marker"

    async def test_decode_body_image_content(self) -> None:
        # Arrange
        input_logger = HttpInputLogger()

        # Act
        result = input_logger._decode_body(b"\x89PNG\r\n", "image/png")

        # Assert
        assert "<binary data:" in result, "Image content should return binary marker"

    async def test_generate_trace_id_from_header(
        self, mock_scope: dict[str, Any]
    ) -> None:
        # Arrange
        input_logger = HttpInputLogger()

        # Act
        trace_id = input_logger.generate_trace_id(mock_scope)

        # Assert
        assert trace_id == "abc123def456", "Should use trace ID from x-trace-id header"

    async def test_generate_trace_id_generates_when_missing(self) -> None:
        # Arrange
        input_logger = HttpInputLogger()
        scope = {
            "headers": [],
        }

        # Act
        trace_id = input_logger.generate_trace_id(scope)

        # Assert
        assert len(trace_id) == 32, "Generated trace ID should be 32 hex chars"

    @pytest.mark.parametrize(
        "test_case",
        LOG_LEVEL_CASES,
        ids=lambda tc: tc.test_id,
    )
    async def test_get_log_level(self, test_case: HttpLogLevelTestCase) -> None:
        # Arrange
        input_logger = HttpInputLogger()

        # Act
        result = input_logger._get_log_level(test_case.status_code)

        # Assert
        assert result == test_case.expected_level, (
            f"Status {test_case.status_code} should map to level '{test_case.expected_level}'"
        )


@dataclass
class MiddlewareTestCase:
    test_id: str
    scope_type: str
    status_code: int
    expect_logging: bool
    enable_logging: bool
    enable_metrics: bool


MIDDLEWARE_CASES = [
    MiddlewareTestCase(
        test_id="http_200_logging_enabled",
        scope_type="http",
        status_code=200,
        expect_logging=True,
        enable_logging=True,
        enable_metrics=True,
    ),
    MiddlewareTestCase(
        test_id="http_500_logging_enabled",
        scope_type="http",
        status_code=500,
        expect_logging=True,
        enable_logging=True,
        enable_metrics=True,
    ),
    MiddlewareTestCase(
        test_id="http_200_logging_disabled",
        scope_type="http",
        status_code=200,
        expect_logging=False,
        enable_logging=False,
        enable_metrics=False,
    ),
    MiddlewareTestCase(
        test_id="http_200_metrics_disabled",
        scope_type="http",
        status_code=200,
        expect_logging=True,
        enable_logging=True,
        enable_metrics=False,
    ),
]


def _make_http_scope() -> dict:
    """Create a minimal HTTP ASGI scope."""
    return {
        "type": "http",
        "method": "GET",
        "path": "/api/v1/test",
        "scheme": "http",
        "headers": [
            (b"host", b"localhost"),
        ],
    }


def _make_ws_scope() -> dict:
    """Create a minimal WebSocket ASGI scope."""
    return {
        "type": "websocket",
        "path": "/ws",
        "scheme": "ws",
        "headers": [],
    }


async def test_setup_adds_middleware_to_app() -> None:
    """Test that setup() calls app.add_middleware with _LogMiddleware."""
    # Arrange
    mock_app = Mock()
    mock_app.add_middleware = Mock()
    integration = FastApiLoggingIntegration()

    # Act
    result = integration.setup(mock_app)

    # Assert
    assert result is None, "setup() should return None"
    mock_app.add_middleware.assert_called_once_with(
        _LogMiddleware,
        enable_logging=True,
        enable_metrics=True,
    )


async def test_setup_passes_flags_to_middleware() -> None:
    """Test that setup() passes enable_logging and enable_metrics flags."""
    # Arrange
    mock_app = Mock()
    mock_app.add_middleware = Mock()
    integration = FastApiLoggingIntegration(enable_logging=False, enable_metrics=False)

    # Act
    integration.setup(mock_app)

    # Assert
    mock_app.add_middleware.assert_called_once_with(
        _LogMiddleware,
        enable_logging=False,
        enable_metrics=False,
    )


async def test_setup_default_flags() -> None:
    """Test that setup() uses defaults (both enabled)."""
    # Arrange
    mock_app = Mock()
    mock_app.add_middleware = Mock()
    integration = FastApiLoggingIntegration()

    # Act
    integration.setup(mock_app)

    # Assert
    mock_app.add_middleware.assert_called_once_with(
        _LogMiddleware,
        enable_logging=True,
        enable_metrics=True,
    )


async def test_middleware_non_http_scope_passes_through() -> None:
    """Test that non-HTTP scopes are passed directly to the app."""
    # Arrange
    mock_app = AsyncMock()
    middleware = _LogMiddleware(mock_app)
    scope = _make_ws_scope()
    receive = AsyncMock()
    send = AsyncMock()

    # Act
    await middleware(scope, receive, send)

    # Assert
    (
        mock_app.assert_awaited_once_with(scope, receive, send),
        ("Non-HTTP scope should be passed directly to the app"),
    )


async def test_middleware_skips_metrics_endpoint() -> None:
    """Test that /metrics endpoint bypasses logging middleware."""
    # Arrange
    mock_app = AsyncMock()
    middleware = _LogMiddleware(mock_app)
    scope = {**_make_http_scope(), "path": "/metrics"}
    receive = AsyncMock()
    send = AsyncMock()

    # Act
    await middleware(scope, receive, send)

    # Assert
    mock_app.assert_awaited_once_with(scope, receive, send)


@pytest.mark.parametrize(
    "test_case",
    MIDDLEWARE_CASES,
    ids=lambda tc: tc.test_id,
)
async def test_middleware_http_request_flow(
    test_case: MiddlewareTestCase,
) -> None:
    """Test the full middleware flow for HTTP requests."""
    # Arrange
    scope = _make_http_scope()

    async def mock_app(
        scope: dict,
        receive: AsyncMock,
        send: AsyncMock,
    ) -> None:
        await send(
            {
                "type": "http.response.start",
                "status": test_case.status_code,
                "headers": [],
            }
        )
        await send(
            {
                "type": "http.response.body",
                "body": b'{"ok": true}',
            }
        )

    send = AsyncMock()
    receive = AsyncMock(return_value={"type": "http.request", "body": b""})

    with (
        patch("road24_sdk.integrations.fastapi.HttpInputLogger") as mock_logger_cls,
        patch("road24_sdk.integrations.fastapi.set_trace_context") as mock_set_trace,
        patch("road24_sdk.integrations.fastapi.clear_trace_context") as mock_clear_trace,
    ):
        mock_logger = Mock()
        mock_logger.generate_trace_id.return_value = "abc123"
        mock_logger.log = Mock()
        mock_logger_cls.return_value = mock_logger
        mock_set_trace.return_value = "token"

        middleware = _LogMiddleware(
            mock_app,
            enable_logging=test_case.enable_logging,
            enable_metrics=test_case.enable_metrics,
        )

        # Act
        await middleware(scope, receive, send)

    # Assert
    (
        mock_logger.generate_trace_id.assert_called_once_with(scope),
        ("Should generate trace ID from scope"),
    )
    (
        mock_set_trace.assert_called_once_with("abc123"),
        ("Should set trace context with generated ID"),
    )
    (
        mock_clear_trace.assert_called_once_with("token"),
        ("Should clear trace context with the token"),
    )

    if test_case.expect_logging:
        (
            mock_logger.log.assert_called_once(),
            ("Logger.log should be called when logging is enabled"),
        )
        call_kwargs = mock_logger.log.call_args.kwargs
        assert call_kwargs["scope"] == scope, "Logger should receive the scope"
        assert call_kwargs["status_code"] == test_case.status_code, (
            "Logger should receive the status code"
        )
        assert call_kwargs["record_metrics"] == test_case.enable_metrics, (
            "Logger should receive the metrics flag"
        )
        assert call_kwargs["exc"] is None, (
            "exc should be None when no exception was stored"
        )
    else:
        (
            mock_logger.log.assert_not_called(),
            ("Logger.log should not be called when logging is disabled"),
        )


async def test_middleware_captures_request_body() -> None:
    """Test that middleware captures request body from receive messages."""
    # Arrange
    scope = _make_http_scope()
    request_body = b'{"name": "test"}'

    async def mock_app(scope: dict, receive: object, send: object) -> None:
        msg = await receive()
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b"ok"})

    receive = AsyncMock(return_value={"type": "http.request", "body": request_body})
    send = AsyncMock()

    with (
        patch("road24_sdk.integrations.fastapi.HttpInputLogger") as mock_logger_cls,
        patch(
            "road24_sdk.integrations.fastapi.set_trace_context",
            return_value="token",
        ),
        patch("road24_sdk.integrations.fastapi.clear_trace_context"),
    ):
        mock_logger = Mock()
        mock_logger.generate_trace_id.return_value = "trace123"
        mock_logger.log = Mock()
        mock_logger_cls.return_value = mock_logger

        middleware = _LogMiddleware(mock_app)

        # Act
        await middleware(scope, receive, send)

    # Assert
    call_kwargs = mock_logger.log.call_args.kwargs
    assert call_kwargs["request_body"] == request_body, (
        "Middleware should capture request body"
    )


async def test_middleware_captures_response_body() -> None:
    """Test that middleware captures response body from send messages."""
    # Arrange
    scope = _make_http_scope()
    response_body = b'{"result": "success"}'

    async def mock_app(scope: dict, receive: object, send: object) -> None:
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": response_body})

    receive = AsyncMock(return_value={"type": "http.request", "body": b""})
    send = AsyncMock()

    with (
        patch("road24_sdk.integrations.fastapi.HttpInputLogger") as mock_logger_cls,
        patch(
            "road24_sdk.integrations.fastapi.set_trace_context",
            return_value="token",
        ),
        patch("road24_sdk.integrations.fastapi.clear_trace_context"),
    ):
        mock_logger = Mock()
        mock_logger.generate_trace_id.return_value = "trace123"
        mock_logger.log = Mock()
        mock_logger_cls.return_value = mock_logger

        middleware = _LogMiddleware(mock_app)

        # Act
        await middleware(scope, receive, send)

    # Assert
    call_kwargs = mock_logger.log.call_args.kwargs
    assert call_kwargs["response_body"] == response_body, (
        "Middleware should capture response body"
    )


async def test_middleware_adds_trace_id_header() -> None:
    """Test that middleware injects x-trace-id into response headers."""
    # Arrange
    scope = _make_http_scope()
    sent_messages: list[dict] = []

    async def mock_app(scope: dict, receive: object, send: object) -> None:
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b"ok"})

    async def capture_send(message: dict) -> None:
        sent_messages.append(message)

    receive = AsyncMock(return_value={"type": "http.request", "body": b""})

    with (
        patch("road24_sdk.integrations.fastapi.HttpInputLogger") as mock_logger_cls,
        patch(
            "road24_sdk.integrations.fastapi.set_trace_context",
            return_value="token",
        ),
        patch("road24_sdk.integrations.fastapi.clear_trace_context"),
    ):
        mock_logger = Mock()
        mock_logger.generate_trace_id.return_value = "my-trace-id"
        mock_logger.log = Mock()
        mock_logger_cls.return_value = mock_logger

        middleware = _LogMiddleware(mock_app)

        # Act
        await middleware(scope, receive, capture_send)

    # Assert
    response_start = sent_messages[0]
    headers = dict(response_start["headers"])
    assert b"x-trace-id" in headers, "Response should contain x-trace-id header"
    assert headers[b"x-trace-id"] == b"my-trace-id", (
        "x-trace-id header should match the generated trace ID"
    )


async def test_middleware_returns_json_on_unhandled_exception() -> None:
    """Test that unhandled exceptions produce a JSON 500 response."""
    # Arrange
    scope = _make_http_scope()
    sent_messages: list[dict] = []

    async def failing_app(scope: dict, receive: object, send: object) -> None:
        raise RuntimeError("App failure")

    async def capture_send(message: dict) -> None:
        sent_messages.append(message)

    receive = AsyncMock(return_value={"type": "http.request", "body": b""})

    with (
        patch("road24_sdk.integrations.fastapi.HttpInputLogger") as mock_logger_cls,
        patch(
            "road24_sdk.integrations.fastapi.set_trace_context",
            return_value="token",
        ),
        patch("road24_sdk.integrations.fastapi.clear_trace_context") as mock_clear,
    ):
        mock_logger = Mock()
        mock_logger.generate_trace_id.return_value = "trace-err"
        mock_logger.log = Mock()
        mock_logger_cls.return_value = mock_logger

        middleware = _LogMiddleware(failing_app)

        # Act
        await middleware(scope, receive, capture_send)

    # Assert
    mock_clear.assert_called_once_with("token")

    response_start = sent_messages[0]
    assert response_start["status"] == 500
    headers = dict(response_start["headers"])
    assert headers[b"content-type"] == b"application/json"
    assert b"x-trace-id" in headers

    import json

    body = json.loads(sent_messages[1]["body"])
    assert body["detail"] == "Internal server error"
    assert body["error_type"] == "RuntimeError"
    assert "trace_id" in body

    call_kwargs = mock_logger.log.call_args.kwargs
    assert isinstance(call_kwargs["exc"], RuntimeError)


async def test_middleware_passes_exception_from_contextvar() -> None:
    """Test that middleware reads exception from _request_exception contextvar and passes to log."""
    # Arrange
    scope = _make_http_scope()
    test_exc = ValueError("handler error")

    async def mock_app(scope: dict, receive: object, send: object) -> None:
        _request_exception.set(test_exc)
        await send({"type": "http.response.start", "status": 500, "headers": []})
        await send({"type": "http.response.body", "body": b'{"detail": "error"}'})

    receive = AsyncMock(return_value={"type": "http.request", "body": b""})
    send = AsyncMock()

    with (
        patch("road24_sdk.integrations.fastapi.HttpInputLogger") as mock_logger_cls,
        patch(
            "road24_sdk.integrations.fastapi.set_trace_context",
            return_value="token",
        ),
        patch("road24_sdk.integrations.fastapi.clear_trace_context"),
    ):
        mock_logger = Mock()
        mock_logger.generate_trace_id.return_value = "trace123"
        mock_logger.log = Mock()
        mock_logger_cls.return_value = mock_logger

        middleware = _LogMiddleware(mock_app)

        # Act
        await middleware(scope, receive, send)

    # Assert
    call_kwargs = mock_logger.log.call_args.kwargs
    assert call_kwargs["exc"] is test_exc, (
        "Middleware should pass exception from contextvar to log"
    )
    assert _request_exception.get() is None, (
        "Middleware should reset _request_exception after reading"
    )
