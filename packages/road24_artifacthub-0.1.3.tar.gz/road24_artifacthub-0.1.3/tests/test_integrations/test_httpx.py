from __future__ import annotations

from unittest.mock import Mock, patch

import pytest

from road24_sdk._types import HttpDirection, LogType
from road24_sdk.integrations.httpx import HttpOutputLogger, HttpxLoggingIntegration
from tests.test_data_classes import HttpLogLevelTestCase

LOG_LEVEL_CASES = [
    HttpLogLevelTestCase(test_id="info_200", status_code=200, expected_level="info"),
    HttpLogLevelTestCase(test_id="info_201", status_code=201, expected_level="info"),
    HttpLogLevelTestCase(test_id="info_301", status_code=301, expected_level="info"),
    HttpLogLevelTestCase(
        test_id="warning_400", status_code=400, expected_level="warning"
    ),
    HttpLogLevelTestCase(
        test_id="warning_404", status_code=404, expected_level="warning"
    ),
    HttpLogLevelTestCase(
        test_id="warning_422", status_code=422, expected_level="warning"
    ),
    HttpLogLevelTestCase(test_id="error_500", status_code=500, expected_level="error"),
    HttpLogLevelTestCase(test_id="error_503", status_code=503, expected_level="error"),
]


class TestHttpOutputLogger:
    async def test_log_request_hook_sets_start_time(
        self, mock_httpx_request: Mock
    ) -> None:
        # Arrange
        output_logger = HttpOutputLogger()

        # Act
        await output_logger.log_request_hook(mock_httpx_request)

        # Assert
        assert "start_time" in mock_httpx_request.extensions, (
            "Request hook should set start_time in extensions"
        )
        assert isinstance(mock_httpx_request.extensions["start_time"], float), (
            "start_time should be a float"
        )

    async def test_log_response_hook_reads_and_logs(
        self, mock_httpx_response: Mock
    ) -> None:
        # Arrange
        output_logger = HttpOutputLogger()

        with (
            patch.object(output_logger, "log") as mock_log,
            patch("time.perf_counter", return_value=1000.5),
        ):
            # Act
            await output_logger.log_response_hook(mock_httpx_response)

            # Assert
            mock_httpx_response.aread.assert_awaited_once()
            mock_log.assert_called_once()

    async def test_log_response_hook_calculates_duration(
        self, mock_httpx_response: Mock
    ) -> None:
        # Arrange
        output_logger = HttpOutputLogger()
        mock_httpx_response.request.extensions = {"start_time": 100.0}

        with (
            patch.object(output_logger, "log") as mock_log,
            patch("time.perf_counter", return_value=100.5),
        ):
            # Act
            await output_logger.log_response_hook(mock_httpx_response)

            # Assert
            call_args = mock_log.call_args
            duration = call_args[0][2]
            assert abs(duration - 0.5) < 0.01, (
                "Duration should be calculated from start_time"
            )

    async def test_log_records_metrics(
        self, mock_httpx_request: Mock, mock_httpx_response: Mock
    ) -> None:
        # Arrange
        output_logger = HttpOutputLogger()

        with (
            patch("road24_sdk.integrations.httpx.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request") as mock_record,
        ):
            # Act
            output_logger.log(
                request=mock_httpx_request,
                response=mock_httpx_response,
                duration_seconds=0.2,
            )

            # Assert
            mock_record.assert_called_once_with(
                method="POST",
                url="https://api.example.com/v1/data",
                status_code=200,
                duration_seconds=0.2,
                direction=HttpDirection.OUTPUT,
            )

    async def test_log_skips_metrics_when_disabled(
        self, mock_httpx_request: Mock, mock_httpx_response: Mock
    ) -> None:
        # Arrange
        output_logger = HttpOutputLogger()

        with (
            patch("road24_sdk.integrations.httpx.logger"),
            patch("road24_sdk.metrics.http.record_http_request") as mock_record,
        ):
            # Act
            output_logger.log(
                request=mock_httpx_request,
                response=mock_httpx_response,
                duration_seconds=0.2,
                record_metrics=False,
            )

            # Assert
            mock_record.assert_not_called()

    async def test_log_success_logs_info(
        self, mock_httpx_request: Mock, mock_httpx_response: Mock
    ) -> None:
        # Arrange
        output_logger = HttpOutputLogger()
        mock_httpx_response.status_code = 200

        with (
            patch("road24_sdk.integrations.httpx.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            # Act
            output_logger.log(
                request=mock_httpx_request,
                response=mock_httpx_response,
                duration_seconds=0.1,
            )

            # Assert
            mock_logger.info.assert_called_once()

    async def test_log_client_error_logs_warning(
        self, mock_httpx_request: Mock, mock_httpx_response: Mock
    ) -> None:
        # Arrange
        output_logger = HttpOutputLogger()
        mock_httpx_response.status_code = 404

        with (
            patch("road24_sdk.integrations.httpx.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            # Act
            output_logger.log(
                request=mock_httpx_request,
                response=mock_httpx_response,
                duration_seconds=0.1,
            )

            # Assert
            mock_logger.warning.assert_called_once()

    async def test_log_server_error_logs_error(
        self, mock_httpx_request: Mock, mock_httpx_response: Mock
    ) -> None:
        # Arrange
        output_logger = HttpOutputLogger()
        mock_httpx_response.status_code = 500

        with (
            patch("road24_sdk.integrations.httpx.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            # Act
            output_logger.log(
                request=mock_httpx_request,
                response=mock_httpx_response,
                duration_seconds=0.1,
            )

            # Assert
            mock_logger.error.assert_called_once()

    async def test_log_includes_http_attributes(
        self, mock_httpx_request: Mock, mock_httpx_response: Mock
    ) -> None:
        # Arrange
        output_logger = HttpOutputLogger()

        with (
            patch("road24_sdk.integrations.httpx.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            # Act
            output_logger.log(
                request=mock_httpx_request,
                response=mock_httpx_response,
                duration_seconds=0.3,
            )

            # Assert
            call_args = mock_logger.info.call_args
            assert call_args[0][0] == LogType.HTTP_REQUEST, (
                "Should log with HTTP_REQUEST type"
            )
            extra = call_args[1]["extra"]
            assert extra["direction"] == "output", "Direction should be output"
            assert extra["method"] == "POST", "Method should match"

    async def test_log_handles_empty_request_body(
        self, mock_httpx_response: Mock
    ) -> None:
        # Arrange
        output_logger = HttpOutputLogger()
        request = Mock()
        request.method = "GET"
        request.url = "https://api.example.com/v1/items"
        request.content = b""

        with (
            patch("road24_sdk.integrations.httpx.logger") as mock_logger,
            patch("road24_sdk.metrics.http.record_http_request"),
        ):
            # Act
            output_logger.log(
                request=request,
                response=mock_httpx_response,
                duration_seconds=0.1,
            )

            # Assert
            call_args = mock_logger.info.call_args
            extra = call_args[1]["extra"]
            assert extra["request_body"] == "", (
                "Empty content should result in empty request body"
            )

    @pytest.mark.parametrize(
        "test_case",
        LOG_LEVEL_CASES,
        ids=lambda tc: tc.test_id,
    )
    async def test_get_log_level(self, test_case: HttpLogLevelTestCase) -> None:
        # Arrange
        output_logger = HttpOutputLogger()

        # Act
        result = output_logger._get_log_level(test_case.status_code)

        # Assert
        assert result == test_case.expected_level, (
            f"Status {test_case.status_code} should map to '{test_case.expected_level}'"
        )

    async def test_log_response_hook_zero_duration_when_no_start_time(
        self, mock_httpx_response: Mock
    ) -> None:
        # Arrange
        output_logger = HttpOutputLogger()
        mock_httpx_response.request.extensions = {}

        with patch.object(output_logger, "log") as mock_log:
            # Act
            await output_logger.log_response_hook(mock_httpx_response)

            # Assert
            call_args = mock_log.call_args
            duration = call_args[0][2]
            assert duration == 0.0, "Duration should be 0.0 when no start_time"


async def test_setup_appends_hooks_when_logging_enabled() -> None:
    """Test that setup() appends request/response hooks to client."""
    # Arrange
    integration = HttpxLoggingIntegration(enable_logging=True)
    mock_client = Mock()
    mock_client.event_hooks = {"request": [], "response": []}

    # Act
    integration.setup(mock_client)

    # Assert
    assert len(mock_client.event_hooks["request"]) == 1, "Should append one request hook"
    assert len(mock_client.event_hooks["response"]) == 1, (
        "Should append one response hook"
    )


async def test_setup_does_not_append_hooks_when_logging_disabled() -> None:
    """Test that setup() does not append hooks when logging is disabled."""
    # Arrange
    integration = HttpxLoggingIntegration(enable_logging=False)
    mock_client = Mock()
    mock_client.event_hooks = {"request": [], "response": []}

    # Act
    integration.setup(mock_client)

    # Assert
    assert len(mock_client.event_hooks["request"]) == 0, (
        "Should not append request hook when logging disabled"
    )
    assert len(mock_client.event_hooks["response"]) == 0, (
        "Should not append response hook when logging disabled"
    )


async def test_setup_preserves_existing_hooks() -> None:
    """Test that setup() preserves existing event hooks on the client."""
    # Arrange
    existing_request_hook = Mock()
    existing_response_hook = Mock()
    integration = HttpxLoggingIntegration(enable_logging=True)
    mock_client = Mock()
    mock_client.event_hooks = {
        "request": [existing_request_hook],
        "response": [existing_response_hook],
    }

    # Act
    integration.setup(mock_client)

    # Assert
    assert existing_request_hook in mock_client.event_hooks["request"], (
        "Should preserve existing request hooks"
    )
    assert existing_response_hook in mock_client.event_hooks["response"], (
        "Should preserve existing response hooks"
    )
    assert len(mock_client.event_hooks["request"]) == 2, (
        "Should have original + new request hook"
    )
    assert len(mock_client.event_hooks["response"]) == 2, (
        "Should have original + new response hook"
    )


async def test_create_client_returns_async_client() -> None:
    """Test that create_client() returns an AsyncClient instance."""
    # Arrange
    integration = HttpxLoggingIntegration(enable_logging=True)

    with patch("httpx.AsyncClient") as mock_async_client_cls:
        mock_instance = Mock()
        mock_async_client_cls.return_value = mock_instance

        # Act
        result = integration.create_client()

    # Assert
    assert result is mock_instance, "create_client should return the AsyncClient instance"
    (
        mock_async_client_cls.assert_called_once(),
        ("AsyncClient should be instantiated once"),
    )


async def test_create_client_includes_hooks_when_logging_enabled() -> None:
    """Test that create_client() includes logging hooks in event_hooks."""
    # Arrange
    integration = HttpxLoggingIntegration(enable_logging=True)

    with patch("httpx.AsyncClient") as mock_async_client_cls:
        mock_async_client_cls.return_value = Mock()

        # Act
        integration.create_client()

    # Assert
    call_kwargs = mock_async_client_cls.call_args.kwargs
    event_hooks = call_kwargs["event_hooks"]
    assert len(event_hooks["request"]) == 1, "Should include one request hook"
    assert len(event_hooks["response"]) == 1, "Should include one response hook"


async def test_create_client_no_hooks_when_logging_disabled() -> None:
    """Test that create_client() has no hooks when logging is disabled."""
    # Arrange
    integration = HttpxLoggingIntegration(enable_logging=False)

    with patch("httpx.AsyncClient") as mock_async_client_cls:
        mock_async_client_cls.return_value = Mock()

        # Act
        integration.create_client()

    # Assert
    call_kwargs = mock_async_client_cls.call_args.kwargs
    event_hooks = call_kwargs["event_hooks"]
    assert len(event_hooks["request"]) == 0, (
        "Should not include request hook when logging disabled"
    )
    assert len(event_hooks["response"]) == 0, (
        "Should not include response hook when logging disabled"
    )


async def test_create_client_merges_user_event_hooks() -> None:
    """Test that create_client() merges user-provided event hooks."""
    # Arrange
    user_request_hook = Mock()
    user_response_hook = Mock()
    integration = HttpxLoggingIntegration(enable_logging=True)

    with patch("httpx.AsyncClient") as mock_async_client_cls:
        mock_async_client_cls.return_value = Mock()

        # Act
        integration.create_client(
            event_hooks={
                "request": [user_request_hook],
                "response": [user_response_hook],
            }
        )

    # Assert
    call_kwargs = mock_async_client_cls.call_args.kwargs
    event_hooks = call_kwargs["event_hooks"]
    assert user_request_hook in event_hooks["request"], (
        "Should preserve user request hook"
    )
    assert user_response_hook in event_hooks["response"], (
        "Should preserve user response hook"
    )
    assert len(event_hooks["request"]) == 2, "Should have user + logging request hooks"
    assert len(event_hooks["response"]) == 2, "Should have user + logging response hooks"


async def test_create_client_passes_extra_kwargs() -> None:
    """Test that create_client() forwards extra kwargs to AsyncClient."""
    # Arrange
    integration = HttpxLoggingIntegration(enable_logging=True)

    with patch("httpx.AsyncClient") as mock_async_client_cls:
        mock_async_client_cls.return_value = Mock()

        # Act
        integration.create_client(base_url="https://api.example.com")

    # Assert
    call_kwargs = mock_async_client_cls.call_args.kwargs
    assert call_kwargs["base_url"] == "https://api.example.com", (
        "Extra kwargs should be passed to AsyncClient"
    )


@pytest.mark.parametrize(
    "enable_logging,expected_hook_count",
    [
        (True, 1),
        (False, 0),
    ],
    ids=["logging_enabled", "logging_disabled"],
)
async def test_create_client_hook_count(
    enable_logging: bool,
    expected_hook_count: int,
) -> None:
    """Test create_client hook count based on logging flag."""
    # Arrange
    integration = HttpxLoggingIntegration(enable_logging=enable_logging)

    with patch("httpx.AsyncClient") as mock_async_client_cls:
        mock_async_client_cls.return_value = Mock()

        # Act
        integration.create_client()

    # Assert
    call_kwargs = mock_async_client_cls.call_args.kwargs
    event_hooks = call_kwargs["event_hooks"]
    assert len(event_hooks["request"]) == expected_hook_count, (
        f"Should have {expected_hook_count} request hook(s)"
    )
    assert len(event_hooks["response"]) == expected_hook_count, (
        f"Should have {expected_hook_count} response hook(s)"
    )


async def test_hooks_reference_output_logger_methods() -> None:
    """Test that hooks point to the HttpOutputLogger methods."""
    # Arrange
    integration = HttpxLoggingIntegration(enable_logging=True)

    with patch("httpx.AsyncClient") as mock_async_client_cls:
        mock_async_client_cls.return_value = Mock()

        # Act
        integration.create_client()

    # Assert
    call_kwargs = mock_async_client_cls.call_args.kwargs
    event_hooks = call_kwargs["event_hooks"]
    request_hook = event_hooks["request"][0]
    response_hook = event_hooks["response"][0]
    assert request_hook == integration._output_logger.log_request_hook, (
        "Request hook should be the output logger's log_request_hook"
    )
    assert response_hook == integration._output_logger.log_response_hook, (
        "Response hook should be the output logger's log_response_hook"
    )
