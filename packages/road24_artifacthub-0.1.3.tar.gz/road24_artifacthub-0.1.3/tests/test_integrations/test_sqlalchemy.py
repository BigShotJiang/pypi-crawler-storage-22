from __future__ import annotations

from unittest.mock import Mock, patch

import pytest

from road24_sdk._types import DbOperation, LogType
from road24_sdk.integrations.sqlalchemy import DbLogger, SqlalchemyLoggingIntegration
from tests.test_data_classes import DbOperationTestCase, DbTableTestCase

OPERATION_CASES = [
    DbOperationTestCase(
        test_id="select", statement="SELECT * FROM users", expected_operation="select"
    ),
    DbOperationTestCase(
        test_id="insert",
        statement="INSERT INTO users (name) VALUES ('test')",
        expected_operation="insert",
    ),
    DbOperationTestCase(
        test_id="update",
        statement="UPDATE users SET name='test'",
        expected_operation="update",
    ),
    DbOperationTestCase(
        test_id="delete",
        statement="DELETE FROM users WHERE id=1",
        expected_operation="delete",
    ),
    DbOperationTestCase(
        test_id="other_create",
        statement="CREATE TABLE users (id INT)",
        expected_operation="other",
    ),
    DbOperationTestCase(
        test_id="select_lowercase",
        statement="select * from users",
        expected_operation="select",
    ),
    DbOperationTestCase(
        test_id="select_with_whitespace",
        statement="  SELECT * FROM users",
        expected_operation="select",
    ),
]

TABLE_CASES = [
    DbTableTestCase(
        test_id="select_from",
        statement="SELECT * FROM users WHERE id=1",
        expected_table="users",
    ),
    DbTableTestCase(
        test_id="insert_into",
        statement="INSERT INTO orders (user_id) VALUES (1)",
        expected_table="orders",
    ),
    DbTableTestCase(
        test_id="update_table",
        statement="UPDATE products SET price=10",
        expected_table="products",
    ),
    DbTableTestCase(
        test_id="delete_from",
        statement="DELETE FROM sessions WHERE expired=true",
        expected_table="sessions",
    ),
    DbTableTestCase(
        test_id="schema_qualified",
        statement="SELECT * FROM public.users",
        expected_table="users",
    ),
    DbTableTestCase(
        test_id="quoted_table", statement='SELECT * FROM "Users"', expected_table="users"
    ),
    DbTableTestCase(
        test_id="unknown_table",
        statement="CREATE INDEX idx ON users (name)",
        expected_table="unknown",
    ),
]


class TestDbLoggerExtractOperation:
    @pytest.mark.parametrize("test_case", OPERATION_CASES, ids=lambda tc: tc.test_id)
    async def test_extract_operation(self, test_case: DbOperationTestCase) -> None:
        db_logger = DbLogger()
        result = db_logger.extract_operation(test_case.statement)
        assert result.value == test_case.expected_operation


class TestDbLoggerExtractTable:
    @pytest.mark.parametrize("test_case", TABLE_CASES, ids=lambda tc: tc.test_id)
    async def test_extract_table(self, test_case: DbTableTestCase) -> None:
        db_logger = DbLogger()
        result = db_logger.extract_table(test_case.statement)
        assert result == test_case.expected_table


class TestDbLoggerLogQuery:
    async def test_log_query_records_metrics(self) -> None:
        db_logger = DbLogger()
        with (
            patch("road24_sdk.integrations.sqlalchemy.logger") as mock_logger,
            patch("road24_sdk.metrics.db.record_db_query") as mock_record,
        ):
            db_logger.log_query(
                operation=DbOperation.SELECT,
                table="users",
                duration_seconds=0.05,
                statement="SELECT * FROM users",
            )
            mock_record.assert_called_once_with(
                operation=DbOperation.SELECT, table="users", duration_seconds=0.05
            )

    async def test_log_query_skips_metrics_when_disabled(self) -> None:
        db_logger = DbLogger()
        with (
            patch("road24_sdk.integrations.sqlalchemy.logger"),
            patch("road24_sdk.metrics.db.record_db_query") as mock_record,
        ):
            db_logger.log_query(
                operation=DbOperation.SELECT,
                table="users",
                duration_seconds=0.05,
                record_metrics=False,
            )
            mock_record.assert_not_called()

    async def test_log_query_logs_info(self) -> None:
        db_logger = DbLogger()
        with (
            patch("road24_sdk.integrations.sqlalchemy.logger") as mock_logger,
            patch("road24_sdk.metrics.db.record_db_query"),
        ):
            db_logger.log_query(
                operation=DbOperation.INSERT,
                table="orders",
                duration_seconds=0.1,
                statement="INSERT INTO orders (id) VALUES (1)",
            )
            mock_logger.info.assert_called_once()
            call_args = mock_logger.info.call_args
            assert call_args[0][0] == LogType.DB_QUERY

    async def test_log_query_includes_attributes(self) -> None:
        db_logger = DbLogger()
        with (
            patch("road24_sdk.integrations.sqlalchemy.logger") as mock_logger,
            patch("road24_sdk.metrics.db.record_db_query"),
        ):
            db_logger.log_query(
                operation=DbOperation.UPDATE,
                table="products",
                duration_seconds=0.2,
                statement="UPDATE products SET price=10",
            )
            extra = mock_logger.info.call_args[1]["extra"]
            assert extra["operation"] == "update"
            assert extra["table"] == "products"
            assert extra["duration_seconds"] == 0.2

    async def test_log_query_truncates_long_statements(self) -> None:
        db_logger = DbLogger()
        long_statement = "SELECT " + "x" * 600
        with (
            patch("road24_sdk.integrations.sqlalchemy.logger") as mock_logger,
            patch("road24_sdk.metrics.db.record_db_query"),
        ):
            db_logger.log_query(
                operation=DbOperation.SELECT,
                table="users",
                duration_seconds=0.01,
                statement=long_statement,
            )
            extra = mock_logger.info.call_args[1]["extra"]
            assert len(extra["statement"]) <= DbLogger.MAX_STATEMENT_LENGTH


class TestDbLoggerBeforeExecute:
    async def test_before_execute_stores_start_time(self) -> None:
        db_logger = DbLogger()
        conn = Mock()
        conn.info = {}
        db_logger.before_execute(
            conn=conn,
            cursor=Mock(),
            statement="SELECT 1",
            parameters=None,
            context=None,
            executemany=False,
        )
        assert "_query_start_time" in conn.info
        assert isinstance(conn.info["_query_start_time"], float)


class TestDbLoggerAfterExecute:
    async def test_after_execute_calls_log_query(self) -> None:
        db_logger = DbLogger()
        conn = Mock()
        conn.info = {"_query_start_time": 100.0}
        with (
            patch.object(db_logger, "log_query") as mock_log_query,
            patch("time.perf_counter", return_value=100.5),
        ):
            db_logger.after_execute(
                conn=conn,
                cursor=Mock(),
                statement="SELECT * FROM users",
                parameters=None,
                context=None,
                executemany=False,
            )
            mock_log_query.assert_called_once()
            call_kwargs = mock_log_query.call_args[1]
            assert call_kwargs["operation"] == DbOperation.SELECT
            assert call_kwargs["table"] == "users"
            assert abs(call_kwargs["duration_seconds"] - 0.5) < 0.01

    async def test_after_execute_zero_duration_when_no_start_time(self) -> None:
        db_logger = DbLogger()
        conn = Mock()
        conn.info = {}
        with patch.object(db_logger, "log_query") as mock_log_query:
            db_logger.after_execute(
                conn=conn,
                cursor=Mock(),
                statement="SELECT 1",
                parameters=None,
                context=None,
                executemany=False,
            )
            call_kwargs = mock_log_query.call_args[1]
            assert call_kwargs["duration_seconds"] == 0.0

    async def test_after_execute_removes_start_time_from_conn(self) -> None:
        db_logger = DbLogger()
        conn = Mock()
        conn.info = {"_query_start_time": 100.0}
        with patch.object(db_logger, "log_query"):
            db_logger.after_execute(
                conn=conn,
                cursor=Mock(),
                statement="SELECT 1",
                parameters=None,
                context=None,
                executemany=False,
            )
            assert "_query_start_time" not in conn.info

    async def test_after_execute_passes_record_metrics(self) -> None:
        db_logger = DbLogger()
        conn = Mock()
        conn.info = {}
        with patch.object(db_logger, "log_query") as mock_log_query:
            db_logger.after_execute(
                conn=conn,
                cursor=Mock(),
                statement="SELECT 1",
                parameters=None,
                context=None,
                executemany=False,
                record_metrics=False,
            )
            call_kwargs = mock_log_query.call_args[1]
            assert call_kwargs["record_metrics"] is False


async def test_setup_registers_before_cursor_execute_listener() -> None:
    mock_engine = Mock()
    mock_engine.sync_engine = Mock()
    integration = SqlalchemyLoggingIntegration()
    with patch("sqlalchemy.event") as mock_event:
        integration.setup(mock_engine)
    listen_calls = mock_event.listen.call_args_list
    before_calls = [c for c in listen_calls if c.args[1] == "before_cursor_execute"]
    assert len(before_calls) == 1
    assert before_calls[0].args[0] is mock_engine.sync_engine


async def test_setup_registers_after_cursor_execute_listener() -> None:
    mock_engine = Mock()
    mock_engine.sync_engine = Mock()
    integration = SqlalchemyLoggingIntegration(enable_logging=True)
    with patch("sqlalchemy.event") as mock_event:
        integration.setup(mock_engine)
    listen_calls = mock_event.listen.call_args_list
    after_calls = [c for c in listen_calls if c.args[1] == "after_cursor_execute"]
    assert len(after_calls) == 1
    assert after_calls[0].args[0] is mock_engine.sync_engine


async def test_setup_no_after_listener_when_logging_disabled() -> None:
    mock_engine = Mock()
    mock_engine.sync_engine = Mock()
    integration = SqlalchemyLoggingIntegration(enable_logging=False)
    with patch("sqlalchemy.event") as mock_event:
        integration.setup(mock_engine)
    listen_calls = mock_event.listen.call_args_list
    after_calls = [c for c in listen_calls if c.args[1] == "after_cursor_execute"]
    assert len(after_calls) == 0
    before_calls = [c for c in listen_calls if c.args[1] == "before_cursor_execute"]
    assert len(before_calls) == 1


async def test_setup_uses_sync_engine_attribute() -> None:
    mock_sync_engine = Mock()
    mock_engine = Mock()
    mock_engine.sync_engine = mock_sync_engine
    integration = SqlalchemyLoggingIntegration()
    with patch("sqlalchemy.event") as mock_event:
        integration.setup(mock_engine)
    for c in mock_event.listen.call_args_list:
        assert c.args[0] is mock_sync_engine


async def test_setup_falls_back_to_engine_without_sync_engine() -> None:
    mock_engine = Mock(spec=[])
    integration = SqlalchemyLoggingIntegration()
    with patch("sqlalchemy.event") as mock_event:
        integration.setup(mock_engine)
    for c in mock_event.listen.call_args_list:
        assert c.args[0] is mock_engine


async def test_setup_before_listener_is_db_logger_before_execute() -> None:
    mock_engine = Mock()
    mock_engine.sync_engine = Mock()
    integration = SqlalchemyLoggingIntegration()
    with patch("sqlalchemy.event") as mock_event:
        integration.setup(mock_engine)
    listen_calls = mock_event.listen.call_args_list
    before_call = [c for c in listen_calls if c.args[1] == "before_cursor_execute"][0]
    assert before_call.args[2] == integration._db_logger.before_execute


@pytest.mark.parametrize(
    "enable_logging,enable_metrics,expected_listener_count",
    [(True, True, 2), (True, False, 2), (False, True, 1), (False, False, 1)],
    ids=[
        "logging_and_metrics_enabled",
        "logging_enabled_metrics_disabled",
        "logging_disabled_metrics_enabled",
        "both_disabled",
    ],
)
async def test_setup_listener_count(
    enable_logging: bool, enable_metrics: bool, expected_listener_count: int
) -> None:
    mock_engine = Mock()
    mock_engine.sync_engine = Mock()
    integration = SqlalchemyLoggingIntegration(
        enable_logging=enable_logging, enable_metrics=enable_metrics
    )
    with patch("sqlalchemy.event") as mock_event:
        integration.setup(mock_engine)
    assert mock_event.listen.call_count == expected_listener_count


async def test_setup_after_listener_wraps_with_metrics_flag() -> None:
    mock_engine = Mock()
    mock_engine.sync_engine = Mock()
    integration = SqlalchemyLoggingIntegration(enable_logging=True, enable_metrics=False)
    with patch("sqlalchemy.event") as mock_event:
        integration.setup(mock_engine)
    listen_calls = mock_event.listen.call_args_list
    after_call = [c for c in listen_calls if c.args[1] == "after_cursor_execute"][0]
    after_handler = after_call.args[2]
    with patch.object(integration._db_logger, "after_execute") as mock_after:
        after_handler("conn", "cursor", "SELECT 1", None, None, False)
    mock_after.assert_called_once_with(
        "conn", "cursor", "SELECT 1", None, None, False, record_metrics=False
    )
