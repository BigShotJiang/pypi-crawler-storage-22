from __future__ import annotations

from dataclasses import dataclass
from unittest.mock import Mock, patch

import pytest

from road24_sdk._types import DbOperation
from road24_sdk.metrics.db import record_db_query


@dataclass
class DbMetricTestCase:
    test_id: str
    operation: DbOperation
    table: str
    duration_seconds: float


DB_METRIC_CASES = [
    DbMetricTestCase(
        test_id="select_users",
        operation=DbOperation.SELECT,
        table="users",
        duration_seconds=0.01,
    ),
    DbMetricTestCase(
        test_id="insert_orders",
        operation=DbOperation.INSERT,
        table="orders",
        duration_seconds=0.05,
    ),
    DbMetricTestCase(
        test_id="update_products",
        operation=DbOperation.UPDATE,
        table="products",
        duration_seconds=0.03,
    ),
    DbMetricTestCase(
        test_id="delete_sessions",
        operation=DbOperation.DELETE,
        table="sessions",
        duration_seconds=0.002,
    ),
    DbMetricTestCase(
        test_id="other_operation",
        operation=DbOperation.OTHER,
        table="unknown",
        duration_seconds=0.1,
    ),
]


@pytest.mark.parametrize(
    "test_case",
    DB_METRIC_CASES,
    ids=lambda tc: tc.test_id,
)
async def test_record_db_query_updates_counter(
    test_case: DbMetricTestCase,
) -> None:
    """Test that record_db_query increments the counter metric."""
    # Arrange
    mock_counter = Mock()
    mock_counter.labels.return_value.inc = Mock()

    # Act
    with patch("road24_sdk.metrics.db.DB_QUERY_TOTAL", mock_counter):
        record_db_query(
            operation=test_case.operation,
            table=test_case.table,
            duration_seconds=test_case.duration_seconds,
        )

    # Assert
    expected_labels = {
        "operation": test_case.operation.value,
        "table": test_case.table,
    }
    (
        mock_counter.labels.assert_called_once_with(**expected_labels),
        "Counter should be called with correct labels",
    )
    (
        mock_counter.labels.return_value.inc.assert_called_once(),
        ("Counter inc() should be called exactly once"),
    )


@pytest.mark.parametrize(
    "test_case",
    DB_METRIC_CASES,
    ids=lambda tc: tc.test_id,
)
async def test_record_db_query_updates_histogram(
    test_case: DbMetricTestCase,
) -> None:
    """Test that record_db_query observes the histogram metric."""
    # Arrange
    mock_histogram = Mock()
    mock_histogram.labels.return_value.observe = Mock()

    # Act
    with patch("road24_sdk.metrics.db.DB_QUERY_DURATION", mock_histogram):
        record_db_query(
            operation=test_case.operation,
            table=test_case.table,
            duration_seconds=test_case.duration_seconds,
        )

    # Assert
    expected_labels = {
        "operation": test_case.operation.value,
        "table": test_case.table,
    }
    (
        mock_histogram.labels.assert_called_once_with(**expected_labels),
        "Histogram should be called with correct labels",
    )
    (
        mock_histogram.labels.return_value.observe.assert_called_once_with(
            test_case.duration_seconds
        ),
        "Histogram observe() should be called with duration",
    )


async def test_record_db_query_operation_uses_enum_value() -> None:
    """Test that operation label uses the enum .value string."""
    # Arrange
    mock_counter = Mock()
    mock_counter.labels.return_value.inc = Mock()
    mock_histogram = Mock()
    mock_histogram.labels.return_value.observe = Mock()

    # Act
    with (
        patch("road24_sdk.metrics.db.DB_QUERY_TOTAL", mock_counter),
        patch("road24_sdk.metrics.db.DB_QUERY_DURATION", mock_histogram),
    ):
        record_db_query(
            operation=DbOperation.SELECT,
            table="users",
            duration_seconds=0.01,
        )

    # Assert
    counter_call_kwargs = mock_counter.labels.call_args.kwargs
    assert counter_call_kwargs["operation"] == "select", (
        "Operation label should use enum value string"
    )


async def test_record_db_query_both_metrics_called() -> None:
    """Test that both counter and histogram are updated in a single call."""
    # Arrange
    mock_counter = Mock()
    mock_counter.labels.return_value.inc = Mock()
    mock_histogram = Mock()
    mock_histogram.labels.return_value.observe = Mock()

    # Act
    with (
        patch("road24_sdk.metrics.db.DB_QUERY_TOTAL", mock_counter),
        patch("road24_sdk.metrics.db.DB_QUERY_DURATION", mock_histogram),
    ):
        record_db_query(
            operation=DbOperation.INSERT,
            table="orders",
            duration_seconds=0.05,
        )

    # Assert
    mock_counter.labels.assert_called_once(), ("Counter labels should be called once")
    (
        mock_counter.labels.return_value.inc.assert_called_once(),
        ("Counter inc() should be called once"),
    )
    mock_histogram.labels.assert_called_once(), ("Histogram labels should be called once")
    (
        mock_histogram.labels.return_value.observe.assert_called_once(),
        ("Histogram observe() should be called once"),
    )
