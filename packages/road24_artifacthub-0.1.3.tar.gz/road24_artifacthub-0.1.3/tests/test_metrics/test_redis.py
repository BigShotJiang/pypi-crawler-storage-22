from __future__ import annotations

from dataclasses import dataclass
from unittest.mock import Mock, patch

import pytest

from road24_sdk._types import RedisOperation
from road24_sdk.metrics.redis import record_redis_command


@dataclass
class RedisMetricTestCase:
    test_id: str
    operation: RedisOperation
    key: str
    duration_seconds: float


REDIS_METRIC_CASES = [
    RedisMetricTestCase(
        test_id="get_session",
        operation=RedisOperation.GET,
        key="session:abc123",
        duration_seconds=0.001,
    ),
    RedisMetricTestCase(
        test_id="set_cache",
        operation=RedisOperation.SET,
        key="cache:users:42",
        duration_seconds=0.002,
    ),
    RedisMetricTestCase(
        test_id="delete_token",
        operation=RedisOperation.DELETE,
        key="token:xyz",
        duration_seconds=0.0005,
    ),
    RedisMetricTestCase(
        test_id="hget_profile",
        operation=RedisOperation.HGET,
        key="profile:100",
        duration_seconds=0.003,
    ),
    RedisMetricTestCase(
        test_id="lpush_queue",
        operation=RedisOperation.LPUSH,
        key="queue:tasks",
        duration_seconds=0.004,
    ),
    RedisMetricTestCase(
        test_id="publish_event",
        operation=RedisOperation.PUBLISH,
        key="events:user_created",
        duration_seconds=0.01,
    ),
    RedisMetricTestCase(
        test_id="other_operation",
        operation=RedisOperation.OTHER,
        key="misc:data",
        duration_seconds=0.05,
    ),
]


@pytest.mark.parametrize(
    "test_case",
    REDIS_METRIC_CASES,
    ids=lambda tc: tc.test_id,
)
async def test_record_redis_command_updates_counter(
    test_case: RedisMetricTestCase,
) -> None:
    """Test that record_redis_command increments the counter metric."""
    # Arrange
    mock_counter = Mock()
    mock_counter.labels.return_value.inc = Mock()

    # Act
    with patch("road24_sdk.metrics.redis.REDIS_COMMAND_TOTAL", mock_counter):
        record_redis_command(
            operation=test_case.operation,
            key=test_case.key,
            duration_seconds=test_case.duration_seconds,
        )

    # Assert
    expected_labels = {
        "operation": test_case.operation.value,
        "key": test_case.key,
    }
    (
        mock_counter.labels.assert_called_once_with(**expected_labels),
        "Counter should be called with correct labels",
    )
    (
        mock_counter.labels.return_value.inc.assert_called_once(),
        ("Counter inc() should be called exactly once"),
    )


@pytest.mark.parametrize(
    "test_case",
    REDIS_METRIC_CASES,
    ids=lambda tc: tc.test_id,
)
async def test_record_redis_command_updates_histogram(
    test_case: RedisMetricTestCase,
) -> None:
    """Test that record_redis_command observes the histogram metric."""
    # Arrange
    mock_histogram = Mock()
    mock_histogram.labels.return_value.observe = Mock()

    # Act
    with patch("road24_sdk.metrics.redis.REDIS_COMMAND_DURATION", mock_histogram):
        record_redis_command(
            operation=test_case.operation,
            key=test_case.key,
            duration_seconds=test_case.duration_seconds,
        )

    # Assert
    expected_labels = {
        "operation": test_case.operation.value,
        "key": test_case.key,
    }
    (
        mock_histogram.labels.assert_called_once_with(**expected_labels),
        "Histogram should be called with correct labels",
    )
    (
        mock_histogram.labels.return_value.observe.assert_called_once_with(
            test_case.duration_seconds
        ),
        "Histogram observe() should be called with duration",
    )


async def test_record_redis_command_operation_uses_enum_value() -> None:
    """Test that operation label uses the enum .value string."""
    # Arrange
    mock_counter = Mock()
    mock_counter.labels.return_value.inc = Mock()
    mock_histogram = Mock()
    mock_histogram.labels.return_value.observe = Mock()

    # Act
    with (
        patch("road24_sdk.metrics.redis.REDIS_COMMAND_TOTAL", mock_counter),
        patch(
            "road24_sdk.metrics.redis.REDIS_COMMAND_DURATION",
            mock_histogram,
        ),
    ):
        record_redis_command(
            operation=RedisOperation.GET,
            key="test:key",
            duration_seconds=0.001,
        )

    # Assert
    counter_call_kwargs = mock_counter.labels.call_args.kwargs
    assert counter_call_kwargs["operation"] == "get", (
        "Operation label should use enum value string"
    )


async def test_record_redis_command_both_metrics_called() -> None:
    """Test that both counter and histogram are updated in a single call."""
    # Arrange
    mock_counter = Mock()
    mock_counter.labels.return_value.inc = Mock()
    mock_histogram = Mock()
    mock_histogram.labels.return_value.observe = Mock()

    # Act
    with (
        patch("road24_sdk.metrics.redis.REDIS_COMMAND_TOTAL", mock_counter),
        patch(
            "road24_sdk.metrics.redis.REDIS_COMMAND_DURATION",
            mock_histogram,
        ),
    ):
        record_redis_command(
            operation=RedisOperation.SET,
            key="cache:item",
            duration_seconds=0.002,
        )

    # Assert
    mock_counter.labels.assert_called_once(), ("Counter labels should be called once")
    (
        mock_counter.labels.return_value.inc.assert_called_once(),
        ("Counter inc() should be called once"),
    )
    mock_histogram.labels.assert_called_once(), ("Histogram labels should be called once")
    (
        mock_histogram.labels.return_value.observe.assert_called_once_with(0.002),
        "Histogram observe() should be called with correct duration",
    )
