from __future__ import annotations

import json

import pytest

from road24_sdk._sanitizer import (
    MASK,
    is_sensitive_key,
    sanitize_body,
    sanitize_dict,
)
from tests.test_data_classes import (
    SanitizeBodyTestCase,
    SanitizeDictTestCase,
    SensitiveKeyTestCase,
)

SENSITIVE_KEY_CASES = [
    SensitiveKeyTestCase(test_id="password", key="password", expected_sensitive=True),
    SensitiveKeyTestCase(
        test_id="Password_upper", key="Password", expected_sensitive=True
    ),
    SensitiveKeyTestCase(
        test_id="user_password", key="user_password", expected_sensitive=True
    ),
    SensitiveKeyTestCase(test_id="token", key="token", expected_sensitive=True),
    SensitiveKeyTestCase(
        test_id="access_token", key="access_token", expected_sensitive=True
    ),
    SensitiveKeyTestCase(test_id="TOKEN_upper", key="TOKEN", expected_sensitive=True),
    SensitiveKeyTestCase(test_id="secret", key="secret", expected_sensitive=True),
    SensitiveKeyTestCase(
        test_id="client_secret", key="client_secret", expected_sensitive=True
    ),
    SensitiveKeyTestCase(test_id="api_key", key="api_key", expected_sensitive=True),
    SensitiveKeyTestCase(test_id="apikey", key="apikey", expected_sensitive=True),
    SensitiveKeyTestCase(test_id="api-key", key="api-key", expected_sensitive=True),
    SensitiveKeyTestCase(test_id="auth", key="auth", expected_sensitive=True),
    SensitiveKeyTestCase(
        test_id="authorization", key="authorization", expected_sensitive=True
    ),
    SensitiveKeyTestCase(test_id="credential", key="credential", expected_sensitive=True),
    SensitiveKeyTestCase(
        test_id="private_key", key="private_key", expected_sensitive=True
    ),
    SensitiveKeyTestCase(test_id="privatekey", key="privatekey", expected_sensitive=True),
    SensitiveKeyTestCase(
        test_id="private-key", key="private-key", expected_sensitive=True
    ),
    SensitiveKeyTestCase(test_id="access_key", key="access_key", expected_sensitive=True),
    SensitiveKeyTestCase(test_id="accesskey", key="accesskey", expected_sensitive=True),
    SensitiveKeyTestCase(test_id="session_id", key="session_id", expected_sensitive=True),
    SensitiveKeyTestCase(test_id="sessionid", key="sessionid", expected_sensitive=True),
    SensitiveKeyTestCase(test_id="session-id", key="session-id", expected_sensitive=True),
    SensitiveKeyTestCase(test_id="cookie", key="cookie", expected_sensitive=True),
    SensitiveKeyTestCase(test_id="bearer", key="bearer", expected_sensitive=True),
    SensitiveKeyTestCase(test_id="pin", key="pin", expected_sensitive=True),
    SensitiveKeyTestCase(test_id="cvv", key="cvv", expected_sensitive=True),
    SensitiveKeyTestCase(
        test_id="card_number", key="card_number", expected_sensitive=True
    ),
    SensitiveKeyTestCase(test_id="cardnumber", key="cardnumber", expected_sensitive=True),
    SensitiveKeyTestCase(
        test_id="card-number", key="card-number", expected_sensitive=True
    ),
    # Non-sensitive keys
    SensitiveKeyTestCase(test_id="name", key="name", expected_sensitive=False),
    SensitiveKeyTestCase(test_id="email", key="email", expected_sensitive=False),
    SensitiveKeyTestCase(test_id="status", key="status", expected_sensitive=False),
    SensitiveKeyTestCase(test_id="id", key="id", expected_sensitive=False),
    SensitiveKeyTestCase(test_id="url", key="url", expected_sensitive=False),
    SensitiveKeyTestCase(test_id="method", key="method", expected_sensitive=False),
    SensitiveKeyTestCase(test_id="count", key="count", expected_sensitive=False),
    SensitiveKeyTestCase(test_id="data", key="data", expected_sensitive=False),
]


SANITIZE_DICT_CASES = [
    SanitizeDictTestCase(
        test_id="no_sensitive_keys",
        description="Dict with no sensitive keys passes through",
        input_data={"name": "John", "age": 30},
        expected_output={"name": "John", "age": 30},
    ),
    SanitizeDictTestCase(
        test_id="password_redacted",
        description="Password field is redacted",
        input_data={"username": "john", "password": "secret123"},
        expected_output={"username": "john", "password": MASK},
    ),
    SanitizeDictTestCase(
        test_id="multiple_sensitive",
        description="Multiple sensitive fields are redacted",
        input_data={"token": "abc123", "secret": "xyz", "name": "test"},
        expected_output={"token": MASK, "secret": MASK, "name": "test"},
    ),
    SanitizeDictTestCase(
        test_id="nested_dict",
        description="Nested dict with sensitive keys",
        input_data={
            "user": {"name": "John", "password": "secret"},
            "status": "active",
        },
        expected_output={
            "user": {"name": "John", "password": MASK},
            "status": "active",
        },
    ),
    SanitizeDictTestCase(
        test_id="list_of_dicts",
        description="List containing dicts with sensitive keys",
        input_data={
            "users": [
                {"name": "Alice", "token": "abc"},
                {"name": "Bob", "token": "xyz"},
            ],
        },
        expected_output={
            "users": [
                {"name": "Alice", "token": MASK},
                {"name": "Bob", "token": MASK},
            ],
        },
    ),
    SanitizeDictTestCase(
        test_id="list_of_non_dicts",
        description="List with non-dict items passes through",
        input_data={"tags": ["web", "api", "v2"]},
        expected_output={"tags": ["web", "api", "v2"]},
    ),
    SanitizeDictTestCase(
        test_id="empty_dict",
        description="Empty dict passes through",
        input_data={},
        expected_output={},
    ),
    SanitizeDictTestCase(
        test_id="deeply_nested",
        description="Deeply nested sensitive keys are redacted",
        input_data={
            "level1": {
                "level2": {
                    "api_key": "deep-secret",
                    "value": 42,
                },
            },
        },
        expected_output={
            "level1": {
                "level2": {
                    "api_key": MASK,
                    "value": 42,
                },
            },
        },
    ),
]


SANITIZE_BODY_CASES = [
    SanitizeBodyTestCase(
        test_id="json_object_with_sensitive",
        description="JSON object with sensitive fields",
        input_body='{"username": "john", "password": "secret"}',
        expected_output=json.dumps(
            {"username": "john", "password": MASK}, ensure_ascii=False
        ),
    ),
    SanitizeBodyTestCase(
        test_id="json_array_with_sensitive",
        description="JSON array with sensitive fields in dicts",
        input_body='[{"name": "Alice", "token": "abc"}, {"name": "Bob", "token": "xyz"}]',
        expected_output=json.dumps(
            [{"name": "Alice", "token": MASK}, {"name": "Bob", "token": MASK}],
            ensure_ascii=False,
        ),
    ),
    SanitizeBodyTestCase(
        test_id="non_json_body",
        description="Non-JSON body returned as-is",
        input_body="plain text body",
        expected_output="plain text body",
    ),
    SanitizeBodyTestCase(
        test_id="empty_string",
        description="Empty string returned as-is",
        input_body="",
        expected_output="",
    ),
    SanitizeBodyTestCase(
        test_id="whitespace_only",
        description="Whitespace-only string returned as-is",
        input_body="   ",
        expected_output="   ",
    ),
    SanitizeBodyTestCase(
        test_id="json_primitive_string",
        description="JSON primitive string returned as-is",
        input_body='"just a string"',
        expected_output='"just a string"',
    ),
    SanitizeBodyTestCase(
        test_id="json_primitive_number",
        description="JSON primitive number returned as-is",
        input_body="42",
        expected_output="42",
    ),
    SanitizeBodyTestCase(
        test_id="json_array_non_dicts",
        description="JSON array of non-dicts returned as-is",
        input_body="[1, 2, 3]",
        expected_output=json.dumps([1, 2, 3], ensure_ascii=False),
    ),
    SanitizeBodyTestCase(
        test_id="invalid_json",
        description="Invalid JSON body returned as-is",
        input_body="{invalid json}",
        expected_output="{invalid json}",
    ),
]


@pytest.mark.parametrize(
    "test_case",
    SENSITIVE_KEY_CASES,
    ids=lambda tc: tc.test_id,
)
async def test_is_sensitive_key(
    test_case: SensitiveKeyTestCase,
) -> None:
    """Test is_sensitive_key detects sensitive and non-sensitive keys."""
    # Act
    result = is_sensitive_key(test_case.key)

    # Assert
    assert result == test_case.expected_sensitive, (
        f"Key '{test_case.key}' should be "
        f"{'sensitive' if test_case.expected_sensitive else 'non-sensitive'}"
    )


@pytest.mark.parametrize(
    "test_case",
    SANITIZE_DICT_CASES,
    ids=lambda tc: tc.test_id,
)
async def test_sanitize_dict(
    test_case: SanitizeDictTestCase,
) -> None:
    """Test sanitize_dict redacts sensitive keys in dictionaries."""
    # Act
    result = sanitize_dict(test_case.input_data)

    # Assert
    assert result == test_case.expected_output, (
        f"sanitize_dict failed: {test_case.description}"
    )


@pytest.mark.parametrize(
    "test_case",
    SANITIZE_BODY_CASES,
    ids=lambda tc: tc.test_id,
)
async def test_sanitize_body(
    test_case: SanitizeBodyTestCase,
) -> None:
    """Test sanitize_body sanitizes JSON string bodies."""
    # Act
    result = sanitize_body(test_case.input_body)

    # Assert
    assert result == test_case.expected_output, (
        f"sanitize_body failed: {test_case.description}"
    )


async def test_sanitize_dict_does_not_mutate_original() -> None:
    """Test that sanitize_dict does not mutate the original dictionary."""
    # Arrange
    original = {"password": "secret", "name": "test"}
    original_copy = original.copy()

    # Act
    sanitize_dict(original)

    # Assert
    assert original == original_copy, (
        "sanitize_dict should not mutate the original dictionary"
    )


async def test_sanitize_dict_mixed_list() -> None:
    """Test sanitize_dict with a list containing both dicts and non-dicts."""
    # Arrange
    data = {
        "items": [
            {"password": "secret"},
            "plain_string",
            42,
            {"name": "safe"},
        ],
    }

    # Act
    result = sanitize_dict(data)

    # Assert
    assert result["items"][0] == {"password": MASK}, (
        "Dict items in list should be sanitized"
    )
    assert result["items"][1] == "plain_string", (
        "String items in list should pass through"
    )
    assert result["items"][2] == 42, "Integer items in list should pass through"
    assert result["items"][3] == {"name": "safe"}, (
        "Non-sensitive dict items in list should pass through"
    )


async def test_mask_constant_value() -> None:
    """Test that the MASK constant has the expected value."""
    # Assert
    assert MASK == "***REDACTED***", "MASK constant should be '***REDACTED***'"
