from __future__ import annotations

from typing import Any

import pytest

from road24_sdk._schemas import (
    DbAttributes,
    ExceptionAttributes,
    HttpAttributes,
    LogRecord,
    RedisAttributes,
)
from road24_sdk._types import (
    DbOperation,
    ExceptionType,
    HttpDirection,
    RedisOperation,
)


class TestLogRecord:
    async def test_creation_with_defaults(
        self, sample_log_record_data: dict[str, Any]
    ) -> None:
        # Arrange
        data = {**sample_log_record_data}

        # Act
        record = LogRecord(**data)

        # Assert
        assert record.timestamp == data["timestamp"], "Timestamp should match"
        assert record.trace_id == data["trace_id"], "Trace ID should match"
        assert record.log_level == data["log_level"], "Log level should match"
        assert record.type == data["type"], "Type should match"
        assert record.service_name == data["service_name"], "Service name should match"
        assert record.attributes == {}, "Attributes should default to empty dict"

    async def test_creation_with_attributes(
        self, sample_log_record_data: dict[str, Any]
    ) -> None:
        # Arrange
        attrs = {"key": "value", "count": 42}
        data = {**sample_log_record_data, "attributes": attrs}

        # Act
        record = LogRecord(**data)

        # Assert
        assert record.attributes == attrs, "Attributes should match provided data"

    async def test_as_dict(self, sample_log_record_data: dict[str, Any]) -> None:
        # Arrange
        record = LogRecord(**sample_log_record_data)

        # Act
        result = record.as_dict()

        # Assert
        assert isinstance(result, dict), "as_dict should return a dict"
        assert result["timestamp"] == sample_log_record_data["timestamp"], (
            "Dict should contain timestamp"
        )
        assert result["trace_id"] == sample_log_record_data["trace_id"], (
            "Dict should contain trace_id"
        )
        assert result["log_level"] == sample_log_record_data["log_level"], (
            "Dict should contain log_level"
        )
        assert result["type"] == sample_log_record_data["type"], (
            "Dict should contain type"
        )
        assert result["service_name"] == sample_log_record_data["service_name"], (
            "Dict should contain service_name"
        )
        assert result["attributes"] == sample_log_record_data["attributes"], (
            "Dict should contain attributes"
        )

    async def test_as_dict_keys(self, sample_log_record_data: dict[str, Any]) -> None:
        # Arrange
        record = LogRecord(**sample_log_record_data)

        # Act
        result = record.as_dict()

        # Assert
        expected_keys = {
            "timestamp",
            "trace_id",
            "log_level",
            "type",
            "service_name",
            "attributes",
        }
        assert set(result.keys()) == expected_keys, (
            "as_dict should contain exactly the expected keys"
        )


class TestHttpAttributes:
    async def test_creation(self, sample_http_attributes: dict[str, Any]) -> None:
        # Arrange & Act
        attrs = HttpAttributes(**sample_http_attributes)

        # Assert
        assert attrs.direction == sample_http_attributes["direction"], (
            "Direction should match"
        )
        assert attrs.method == sample_http_attributes["method"], "Method should match"
        assert attrs.status_code == sample_http_attributes["status_code"], (
            "Status code should match"
        )

    async def test_default_bodies(self) -> None:
        # Arrange & Act
        attrs = HttpAttributes(
            direction=HttpDirection.INPUT,
            method="GET",
            url="http://test.com",
            target="/test",
            status_code=200,
            duration_seconds=0.1,
        )

        # Assert
        assert attrs.request_body == "", "Request body should default to empty"
        assert attrs.response_body == "", "Response body should default to empty"

    async def test_as_dict(self, sample_http_attributes: dict[str, Any]) -> None:
        # Arrange
        attrs = HttpAttributes(**sample_http_attributes)

        # Act
        result = attrs.as_dict()

        # Assert
        assert result["direction"] == sample_http_attributes["direction"].value, (
            "Direction should be enum value string"
        )
        assert result["method"] == sample_http_attributes["method"], "Method should match"
        assert result["url"] == sample_http_attributes["url"], "URL should match"
        assert result["status_code"] == sample_http_attributes["status_code"], (
            "Status code should match"
        )

    async def test_as_dict_direction_is_string(self) -> None:
        # Arrange
        attrs = HttpAttributes(
            direction=HttpDirection.OUTPUT,
            method="POST",
            url="http://test.com",
            target="/test",
            status_code=201,
            duration_seconds=0.5,
        )

        # Act
        result = attrs.as_dict()

        # Assert
        assert result["direction"] == "output", "Direction in dict should be string value"


class TestDbAttributes:
    async def test_creation(self, sample_db_attributes: dict[str, Any]) -> None:
        # Arrange & Act
        attrs = DbAttributes(**sample_db_attributes)

        # Assert
        assert attrs.operation == sample_db_attributes["operation"], (
            "Operation should match"
        )
        assert attrs.table == sample_db_attributes["table"], "Table should match"

    async def test_default_statement(self) -> None:
        # Arrange & Act
        attrs = DbAttributes(
            operation=DbOperation.SELECT,
            table="users",
            duration_seconds=0.05,
        )

        # Assert
        assert attrs.statement == "", "Statement should default to empty"

    async def test_as_dict(self, sample_db_attributes: dict[str, Any]) -> None:
        # Arrange
        attrs = DbAttributes(**sample_db_attributes)

        # Act
        result = attrs.as_dict()

        # Assert
        assert result["operation"] == sample_db_attributes["operation"].value, (
            "Operation should be enum value string"
        )
        assert result["table"] == sample_db_attributes["table"], "Table should match"
        assert result["duration_seconds"] == sample_db_attributes["duration_seconds"], (
            "Duration should match"
        )

    @pytest.mark.parametrize(
        "operation,expected_value",
        [
            (DbOperation.SELECT, "select"),
            (DbOperation.INSERT, "insert"),
            (DbOperation.UPDATE, "update"),
            (DbOperation.DELETE, "delete"),
            (DbOperation.OTHER, "other"),
        ],
        ids=["select", "insert", "update", "delete", "other"],
    )
    async def test_as_dict_operation_values(
        self, operation: DbOperation, expected_value: str
    ) -> None:
        # Arrange
        attrs = DbAttributes(operation=operation, table="t", duration_seconds=0.01)

        # Act
        result = attrs.as_dict()

        # Assert
        assert result["operation"] == expected_value, (
            f"Operation value should be '{expected_value}'"
        )


class TestRedisAttributes:
    async def test_creation(self, sample_redis_attributes: dict[str, Any]) -> None:
        # Arrange & Act
        attrs = RedisAttributes(**sample_redis_attributes)

        # Assert
        assert attrs.operation == sample_redis_attributes["operation"], (
            "Operation should match"
        )
        assert attrs.key == sample_redis_attributes["key"], "Key should match"

    async def test_default_command_args(self) -> None:
        # Arrange & Act
        attrs = RedisAttributes(
            operation=RedisOperation.GET,
            key="test:key",
            duration_seconds=0.01,
        )

        # Assert
        assert attrs.command_args == "", "Command args should default to empty"

    async def test_as_dict(self, sample_redis_attributes: dict[str, Any]) -> None:
        # Arrange
        attrs = RedisAttributes(**sample_redis_attributes)

        # Act
        result = attrs.as_dict()

        # Assert
        assert result["operation"] == sample_redis_attributes["operation"].value, (
            "Operation should be enum value string"
        )
        assert result["key"] == sample_redis_attributes["key"], "Key should match"
        assert result["command_args"] == "", "Command args should be empty"

    async def test_as_dict_with_command_args(self) -> None:
        # Arrange
        attrs = RedisAttributes(
            operation=RedisOperation.SET,
            key="test:key",
            duration_seconds=0.01,
            command_args="value=hello, ex=300",
        )

        # Act
        result = attrs.as_dict()

        # Assert
        assert result["command_args"] == "value=hello, ex=300", (
            "Command args should be preserved"
        )


class TestExceptionAttributes:
    async def test_creation(self, sample_exception_attributes: dict[str, Any]) -> None:
        # Arrange & Act
        attrs = ExceptionAttributes(**sample_exception_attributes)

        # Assert
        assert attrs.exception_type == sample_exception_attributes["exception_type"], (
            "Exception type should match"
        )
        assert attrs.error_class == sample_exception_attributes["error_class"], (
            "Error class should match"
        )

    async def test_default_details_is_none(
        self, sample_exception_attributes: dict[str, Any]
    ) -> None:
        # Arrange & Act
        attrs = ExceptionAttributes(**sample_exception_attributes)

        # Assert
        assert attrs.details is None, "Details should default to None"

    async def test_as_dict_without_details(
        self, sample_exception_attributes: dict[str, Any]
    ) -> None:
        # Arrange
        attrs = ExceptionAttributes(**sample_exception_attributes)

        # Act
        result = attrs.as_dict()

        # Assert
        assert "details" not in result, "Details should not be in dict when None"
        assert (
            result["exception_type"]
            == sample_exception_attributes["exception_type"].value
        ), "Exception type should be enum value string"

    async def test_as_dict_with_details(
        self, sample_exception_attributes: dict[str, Any]
    ) -> None:
        # Arrange
        details = [{"field": "name", "error": "required"}]
        attrs = ExceptionAttributes(**sample_exception_attributes, details=details)

        # Act
        result = attrs.as_dict()

        # Assert
        assert "details" in result, "Details should be in dict when not None"
        assert result["details"] == details, "Details should match provided data"

    @pytest.mark.parametrize(
        "exc_type,expected_value",
        [
            (ExceptionType.HTTP, "http"),
            (ExceptionType.VALIDATION, "validation"),
            (ExceptionType.GENERAL, "general"),
        ],
        ids=["http", "validation", "general"],
    )
    async def test_as_dict_exception_type_values(
        self,
        exc_type: ExceptionType,
        expected_value: str,
        sample_exception_attributes: dict[str, Any],
    ) -> None:
        # Arrange
        attrs = ExceptionAttributes(
            **{**sample_exception_attributes, "exception_type": exc_type}
        )

        # Act
        result = attrs.as_dict()

        # Assert
        assert result["exception_type"] == expected_value, (
            f"Exception type value should be '{expected_value}'"
        )

    async def test_as_dict_keys_without_details(
        self, sample_exception_attributes: dict[str, Any]
    ) -> None:
        # Arrange
        attrs = ExceptionAttributes(**sample_exception_attributes)

        # Act
        result = attrs.as_dict()

        # Assert
        expected_keys = {
            "exception_type",
            "error_class",
            "error_message",
            "status_code",
            "method",
            "url",
            "path",
        }
        assert set(result.keys()) == expected_keys, (
            "as_dict should contain exactly the expected keys when details is None"
        )
