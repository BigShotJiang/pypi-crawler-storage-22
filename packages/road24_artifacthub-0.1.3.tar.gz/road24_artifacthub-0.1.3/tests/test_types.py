from __future__ import annotations

from enum import StrEnum

import pytest

from road24_sdk._types import (
    ArtifactHubConfig,
    DbOperation,
    ExceptionType,
    HttpDirection,
    LogType,
    RedisOperation,
)
from tests.test_data_classes import ConfigTestCase, EnumMemberTestCase, EnumTestCase

CONFIG_TEST_CASES = [
    ConfigTestCase(
        test_id="all_defaults",
        description="Config with all default values",
        kwargs={},
        expected_service_name="unknown",
        expected_log_level="INFO",
        expected_debug=False,
        expected_log_format="json",
    ),
    ConfigTestCase(
        test_id="custom_service_name",
        description="Config with custom service name",
        kwargs={"service_name": "payment-service"},
        expected_service_name="payment-service",
        expected_log_level="INFO",
        expected_debug=False,
        expected_log_format="json",
    ),
    ConfigTestCase(
        test_id="debug_enabled",
        description="Config with debug enabled",
        kwargs={"debug": True, "log_level": "DEBUG"},
        expected_service_name="unknown",
        expected_log_level="DEBUG",
        expected_debug=True,
        expected_log_format="json",
    ),
    ConfigTestCase(
        test_id="all_custom",
        description="Config with all custom values",
        kwargs={
            "service_name": "user-service",
            "log_level": "WARNING",
            "debug": True,
            "log_format": "text",
        },
        expected_service_name="user-service",
        expected_log_level="WARNING",
        expected_debug=True,
        expected_log_format="text",
    ),
    ConfigTestCase(
        test_id="custom_log_format",
        description="Config with custom log format",
        kwargs={"log_format": "text"},
        expected_service_name="unknown",
        expected_log_level="INFO",
        expected_debug=False,
        expected_log_format="text",
    ),
]


@pytest.mark.parametrize(
    "test_case",
    CONFIG_TEST_CASES,
    ids=lambda tc: tc.test_id,
)
async def test_artifact_hub_config_creation(
    test_case: ConfigTestCase,
) -> None:
    """Test ArtifactHubConfig creation with various parameters."""
    # Arrange
    kwargs = test_case.kwargs

    # Act
    config = ArtifactHubConfig(**kwargs)

    # Assert
    assert config.service_name == test_case.expected_service_name, (
        f"service_name mismatch: {test_case.description}"
    )
    assert config.log_level == test_case.expected_log_level, (
        f"log_level mismatch: {test_case.description}"
    )
    assert config.debug == test_case.expected_debug, (
        f"debug mismatch: {test_case.description}"
    )
    assert config.log_format == test_case.expected_log_format, (
        f"log_format mismatch: {test_case.description}"
    )


async def test_artifact_hub_config_uses_slots() -> None:
    """Test that ArtifactHubConfig uses __slots__ for memory efficiency."""
    # Arrange & Act
    config = ArtifactHubConfig()

    # Assert
    assert hasattr(config, "__slots__"), "ArtifactHubConfig should use slots=True"


async def test_artifact_hub_config_is_dataclass() -> None:
    """Test that ArtifactHubConfig is a dataclass."""
    # Arrange
    import dataclasses

    # Act & Assert
    assert dataclasses.is_dataclass(ArtifactHubConfig), (
        "ArtifactHubConfig should be a dataclass"
    )


async def test_artifact_hub_config_fields() -> None:
    """Test that ArtifactHubConfig has exactly the expected fields."""
    # Arrange
    import dataclasses

    expected_fields = {"service_name", "log_level", "debug", "log_format", "integrations"}

    # Act
    actual_fields = {f.name for f in dataclasses.fields(ArtifactHubConfig)}

    # Assert
    assert actual_fields == expected_fields, (
        f"Fields mismatch: expected {expected_fields}, got {actual_fields}"
    )


async def test_artifact_hub_config_equality() -> None:
    """Test that two configs with same values are equal."""
    # Arrange
    config_a = ArtifactHubConfig(service_name="test", log_level="DEBUG")
    config_b = ArtifactHubConfig(service_name="test", log_level="DEBUG")

    # Act & Assert
    assert config_a == config_b, "Configs with same values should be equal"


async def test_artifact_hub_config_inequality() -> None:
    """Test that two configs with different values are not equal."""
    # Arrange
    config_a = ArtifactHubConfig(service_name="service-a")
    config_b = ArtifactHubConfig(service_name="service-b")

    # Act & Assert
    assert config_a != config_b, "Configs with different values should not be equal"


ENUM_COMPLETENESS_CASES = [
    EnumTestCase(
        test_id="log_type",
        enum_class=LogType,
        expected_values={"http_request", "db_query", "redis_command", "exception"},
    ),
    EnumTestCase(
        test_id="exception_type",
        enum_class=ExceptionType,
        expected_values={"http", "validation", "general"},
    ),
    EnumTestCase(
        test_id="http_direction",
        enum_class=HttpDirection,
        expected_values={"input", "output"},
    ),
    EnumTestCase(
        test_id="db_operation",
        enum_class=DbOperation,
        expected_values={"select", "insert", "update", "delete", "other"},
    ),
    EnumTestCase(
        test_id="redis_operation",
        enum_class=RedisOperation,
        expected_values={
            "get",
            "set",
            "delete",
            "expire",
            "hget",
            "hset",
            "lpush",
            "rpush",
            "lpop",
            "rpop",
            "publish",
            "subscribe",
            "other",
        },
    ),
]

ENUM_MEMBER_CASES = [
    EnumMemberTestCase(
        test_id="log_type_http_request",
        enum_class=LogType,
        member_name="HTTP_REQUEST",
        expected_value="http_request",
    ),
    EnumMemberTestCase(
        test_id="log_type_db_query",
        enum_class=LogType,
        member_name="DB_QUERY",
        expected_value="db_query",
    ),
    EnumMemberTestCase(
        test_id="log_type_redis_command",
        enum_class=LogType,
        member_name="REDIS_COMMAND",
        expected_value="redis_command",
    ),
    EnumMemberTestCase(
        test_id="log_type_exception",
        enum_class=LogType,
        member_name="EXCEPTION",
        expected_value="exception",
    ),
    EnumMemberTestCase(
        test_id="exception_type_http",
        enum_class=ExceptionType,
        member_name="HTTP",
        expected_value="http",
    ),
    EnumMemberTestCase(
        test_id="exception_type_validation",
        enum_class=ExceptionType,
        member_name="VALIDATION",
        expected_value="validation",
    ),
    EnumMemberTestCase(
        test_id="exception_type_general",
        enum_class=ExceptionType,
        member_name="GENERAL",
        expected_value="general",
    ),
    EnumMemberTestCase(
        test_id="http_direction_input",
        enum_class=HttpDirection,
        member_name="INPUT",
        expected_value="input",
    ),
    EnumMemberTestCase(
        test_id="http_direction_output",
        enum_class=HttpDirection,
        member_name="OUTPUT",
        expected_value="output",
    ),
    EnumMemberTestCase(
        test_id="db_operation_select",
        enum_class=DbOperation,
        member_name="SELECT",
        expected_value="select",
    ),
    EnumMemberTestCase(
        test_id="db_operation_insert",
        enum_class=DbOperation,
        member_name="INSERT",
        expected_value="insert",
    ),
    EnumMemberTestCase(
        test_id="db_operation_other",
        enum_class=DbOperation,
        member_name="OTHER",
        expected_value="other",
    ),
    EnumMemberTestCase(
        test_id="redis_operation_get",
        enum_class=RedisOperation,
        member_name="GET",
        expected_value="get",
    ),
    EnumMemberTestCase(
        test_id="redis_operation_set",
        enum_class=RedisOperation,
        member_name="SET",
        expected_value="set",
    ),
    EnumMemberTestCase(
        test_id="redis_operation_publish",
        enum_class=RedisOperation,
        member_name="PUBLISH",
        expected_value="publish",
    ),
    EnumMemberTestCase(
        test_id="redis_operation_subscribe",
        enum_class=RedisOperation,
        member_name="SUBSCRIBE",
        expected_value="subscribe",
    ),
]


@pytest.mark.parametrize(
    "test_case",
    ENUM_COMPLETENESS_CASES,
    ids=lambda tc: tc.test_id,
)
async def test_enum_has_all_expected_values(
    test_case: EnumTestCase,
) -> None:
    """Test that each enum contains all expected values."""
    # Arrange
    enum_class = test_case.enum_class

    # Act
    actual_values = {member.value for member in enum_class}

    # Assert
    assert actual_values == test_case.expected_values, (
        f"{enum_class.__name__} values mismatch: "
        f"expected {test_case.expected_values}, got {actual_values}"
    )


@pytest.mark.parametrize(
    "test_case",
    ENUM_MEMBER_CASES,
    ids=lambda tc: tc.test_id,
)
async def test_enum_member_value(
    test_case: EnumMemberTestCase,
) -> None:
    """Test that each enum member has the expected string value."""
    # Arrange
    member = test_case.enum_class[test_case.member_name]

    # Act
    actual_value = member.value

    # Assert
    assert actual_value == test_case.expected_value, (
        f"{test_case.enum_class.__name__}.{test_case.member_name} "
        f"should be '{test_case.expected_value}', got '{actual_value}'"
    )


@pytest.mark.parametrize(
    "enum_class",
    [LogType, ExceptionType, HttpDirection, DbOperation, RedisOperation],
    ids=["LogType", "ExceptionType", "HttpDirection", "DbOperation", "RedisOperation"],
)
async def test_enum_inherits_str_enum(
    enum_class: type[StrEnum],
) -> None:
    """Test that all enums inherit from StrEnum."""
    # Assert
    assert issubclass(enum_class, StrEnum), (
        f"{enum_class.__name__} should inherit from StrEnum"
    )


@pytest.mark.parametrize(
    "enum_class",
    [LogType, ExceptionType, HttpDirection, DbOperation, RedisOperation],
    ids=["LogType", "ExceptionType", "HttpDirection", "DbOperation", "RedisOperation"],
)
async def test_enum_members_are_strings(
    enum_class: type[StrEnum],
) -> None:
    """Test that all enum member values are usable as strings."""
    # Act & Assert
    for member in enum_class:
        assert isinstance(member.value, str), (
            f"{enum_class.__name__}.{member.name} value should be a string"
        )
        assert str(member) == member.value, (
            f"str({enum_class.__name__}.{member.name}) should equal its value"
        )


async def test_enum_member_count() -> None:
    """Test that each enum has the expected number of members."""
    # Assert
    assert len(LogType) == 4, "LogType should have 4 members"
    assert len(ExceptionType) == 3, "ExceptionType should have 3 members"
    assert len(HttpDirection) == 2, "HttpDirection should have 2 members"
    assert len(DbOperation) == 5, "DbOperation should have 5 members"
    assert len(RedisOperation) == 13, "RedisOperation should have 13 members"


async def test_enum_lookup_by_value() -> None:
    """Test that enums can be looked up by value."""
    # Act & Assert
    assert LogType("http_request") is LogType.HTTP_REQUEST, (
        "Should look up LogType by value"
    )
    assert HttpDirection("input") is HttpDirection.INPUT, (
        "Should look up HttpDirection by value"
    )
    assert RedisOperation("get") is RedisOperation.GET, (
        "Should look up RedisOperation by value"
    )


async def test_enum_invalid_value_raises() -> None:
    """Test that invalid enum values raise ValueError."""
    # Act & Assert
    with pytest.raises(ValueError):
        LogType("nonexistent")

    with pytest.raises(ValueError):
        HttpDirection("sideways")

    with pytest.raises(ValueError):
        RedisOperation("nonexistent_op")
