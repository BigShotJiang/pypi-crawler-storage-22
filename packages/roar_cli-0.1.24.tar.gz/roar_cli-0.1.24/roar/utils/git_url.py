"""
Git URL utilities for SSH to HTTPS conversion.

Supports converting SSH URLs to HTTPS equivalents for fallback cloning.
"""

import re


def is_ssh_url(url: str) -> bool:
    """
    Check if URL is SSH format.

    Supports:
    - SCP-like: git@github.com:user/repo.git
    - SSH scheme: ssh://git@github.com/user/repo.git

    Args:
        url: Git repository URL

    Returns:
        True if URL is SSH format, False otherwise
    """
    return bool(re.match(r"^(?:ssh://)?git@([^:/]+)[:/]", url))


def ssh_to_https(ssh_url: str) -> str | None:
    """
    Convert SSH URL to HTTPS equivalent.

    Converts:
    - git@github.com:user/repo.git -> https://github.com/user/repo.git
    - ssh://git@github.com/user/repo.git -> https://github.com/user/repo.git

    Args:
        ssh_url: SSH git URL

    Returns:
        HTTPS URL if conversion successful, None if not an SSH URL
    """
    # SCP format: git@host:path
    scp_match = re.match(r"^git@([^:/]+):(.+)$", ssh_url)
    if scp_match:
        return f"https://{scp_match.group(1)}/{scp_match.group(2)}"

    # SSH scheme: ssh://git@host/path
    ssh_match = re.match(r"^ssh://git@([^/]+)/(.+)$", ssh_url)
    if ssh_match:
        return f"https://{ssh_match.group(1)}/{ssh_match.group(2)}"

    return None
