# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from roark_analytics import Roark, AsyncRoark
from roark_analytics.types import (
    SimulationGetRunPlanJobResponse,
    SimulationListScenariosResponse,
    SimulationListRunPlanJobsResponse,
    SimulationStartRunPlanJobResponse,
    SimulationGetSimulationJobByIDResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSimulation:
    # Do not test lookup_job - prism doesn't like camel case params
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_get_run_plan_job(self, client: Roark) -> None:
        simulation = client.simulation.get_run_plan_job(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        )
        assert_matches_type(SimulationGetRunPlanJobResponse, simulation, path=["response"])

    @parametrize
    def test_raw_response_get_run_plan_job(self, client: Roark) -> None:
        response = client.simulation.with_raw_response.get_run_plan_job(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        simulation = response.parse()
        assert_matches_type(SimulationGetRunPlanJobResponse, simulation, path=["response"])

    @parametrize
    def test_streaming_response_get_run_plan_job(self, client: Roark) -> None:
        with client.simulation.with_streaming_response.get_run_plan_job(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            simulation = response.parse()
            assert_matches_type(SimulationGetRunPlanJobResponse, simulation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_get_simulation_job_by_id(self, client: Roark) -> None:
        simulation = client.simulation.get_simulation_job_by_id(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        )
        assert_matches_type(SimulationGetSimulationJobByIDResponse, simulation, path=["response"])

    @parametrize
    def test_raw_response_get_simulation_job_by_id(self, client: Roark) -> None:
        response = client.simulation.with_raw_response.get_simulation_job_by_id(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        simulation = response.parse()
        assert_matches_type(SimulationGetSimulationJobByIDResponse, simulation, path=["response"])

    @parametrize
    def test_streaming_response_get_simulation_job_by_id(self, client: Roark) -> None:
        with client.simulation.with_streaming_response.get_simulation_job_by_id(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            simulation = response.parse()
            assert_matches_type(SimulationGetSimulationJobByIDResponse, simulation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_list_run_plan_jobs(self, client: Roark) -> None:
        simulation = client.simulation.list_run_plan_jobs()
        assert_matches_type(SimulationListRunPlanJobsResponse, simulation, path=["response"])

    @parametrize
    def test_method_list_run_plan_jobs_with_all_params(self, client: Roark) -> None:
        simulation = client.simulation.list_run_plan_jobs(
            after="550e8400-e29b-41d4-a716-446655440000",
            label_id="550e8400-e29b-41d4-a716-446655440000",
            label_name="production-ready",
            limit=20,
            simulation_run_plan_id="550e8400-e29b-41d4-a716-446655440000",
            status="COMPLETED",
        )
        assert_matches_type(SimulationListRunPlanJobsResponse, simulation, path=["response"])

    @parametrize
    def test_raw_response_list_run_plan_jobs(self, client: Roark) -> None:
        response = client.simulation.with_raw_response.list_run_plan_jobs()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        simulation = response.parse()
        assert_matches_type(SimulationListRunPlanJobsResponse, simulation, path=["response"])

    @parametrize
    def test_streaming_response_list_run_plan_jobs(self, client: Roark) -> None:
        with client.simulation.with_streaming_response.list_run_plan_jobs() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            simulation = response.parse()
            assert_matches_type(SimulationListRunPlanJobsResponse, simulation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_list_scenarios(self, client: Roark) -> None:
        simulation = client.simulation.list_scenarios()
        assert_matches_type(SimulationListScenariosResponse, simulation, path=["response"])

    @parametrize
    def test_method_list_scenarios_with_all_params(self, client: Roark) -> None:
        simulation = client.simulation.list_scenarios(
            after="after",
            limit=1,
        )
        assert_matches_type(SimulationListScenariosResponse, simulation, path=["response"])

    @parametrize
    def test_raw_response_list_scenarios(self, client: Roark) -> None:
        response = client.simulation.with_raw_response.list_scenarios()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        simulation = response.parse()
        assert_matches_type(SimulationListScenariosResponse, simulation, path=["response"])

    @parametrize
    def test_streaming_response_list_scenarios(self, client: Roark) -> None:
        with client.simulation.with_streaming_response.list_scenarios() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            simulation = response.parse()
            assert_matches_type(SimulationListScenariosResponse, simulation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_start_run_plan_job(self, client: Roark) -> None:
        simulation = client.simulation.start_run_plan_job(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        )
        assert_matches_type(SimulationStartRunPlanJobResponse, simulation, path=["response"])

    @parametrize
    def test_raw_response_start_run_plan_job(self, client: Roark) -> None:
        response = client.simulation.with_raw_response.start_run_plan_job(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        simulation = response.parse()
        assert_matches_type(SimulationStartRunPlanJobResponse, simulation, path=["response"])

    @parametrize
    def test_streaming_response_start_run_plan_job(self, client: Roark) -> None:
        with client.simulation.with_streaming_response.start_run_plan_job(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            simulation = response.parse()
            assert_matches_type(SimulationStartRunPlanJobResponse, simulation, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncSimulation:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_get_run_plan_job(self, async_client: AsyncRoark) -> None:
        simulation = await async_client.simulation.get_run_plan_job(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        )
        assert_matches_type(SimulationGetRunPlanJobResponse, simulation, path=["response"])

    @parametrize
    async def test_raw_response_get_run_plan_job(self, async_client: AsyncRoark) -> None:
        response = await async_client.simulation.with_raw_response.get_run_plan_job(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        simulation = await response.parse()
        assert_matches_type(SimulationGetRunPlanJobResponse, simulation, path=["response"])

    @parametrize
    async def test_streaming_response_get_run_plan_job(self, async_client: AsyncRoark) -> None:
        async with async_client.simulation.with_streaming_response.get_run_plan_job(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            simulation = await response.parse()
            assert_matches_type(SimulationGetRunPlanJobResponse, simulation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_get_simulation_job_by_id(self, async_client: AsyncRoark) -> None:
        simulation = await async_client.simulation.get_simulation_job_by_id(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        )
        assert_matches_type(SimulationGetSimulationJobByIDResponse, simulation, path=["response"])

    @parametrize
    async def test_raw_response_get_simulation_job_by_id(self, async_client: AsyncRoark) -> None:
        response = await async_client.simulation.with_raw_response.get_simulation_job_by_id(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        simulation = await response.parse()
        assert_matches_type(SimulationGetSimulationJobByIDResponse, simulation, path=["response"])

    @parametrize
    async def test_streaming_response_get_simulation_job_by_id(self, async_client: AsyncRoark) -> None:
        async with async_client.simulation.with_streaming_response.get_simulation_job_by_id(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            simulation = await response.parse()
            assert_matches_type(SimulationGetSimulationJobByIDResponse, simulation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_list_run_plan_jobs(self, async_client: AsyncRoark) -> None:
        simulation = await async_client.simulation.list_run_plan_jobs()
        assert_matches_type(SimulationListRunPlanJobsResponse, simulation, path=["response"])

    @parametrize
    async def test_method_list_run_plan_jobs_with_all_params(self, async_client: AsyncRoark) -> None:
        simulation = await async_client.simulation.list_run_plan_jobs(
            after="550e8400-e29b-41d4-a716-446655440000",
            label_id="550e8400-e29b-41d4-a716-446655440000",
            label_name="production-ready",
            limit=20,
            simulation_run_plan_id="550e8400-e29b-41d4-a716-446655440000",
            status="COMPLETED",
        )
        assert_matches_type(SimulationListRunPlanJobsResponse, simulation, path=["response"])

    @parametrize
    async def test_raw_response_list_run_plan_jobs(self, async_client: AsyncRoark) -> None:
        response = await async_client.simulation.with_raw_response.list_run_plan_jobs()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        simulation = await response.parse()
        assert_matches_type(SimulationListRunPlanJobsResponse, simulation, path=["response"])

    @parametrize
    async def test_streaming_response_list_run_plan_jobs(self, async_client: AsyncRoark) -> None:
        async with async_client.simulation.with_streaming_response.list_run_plan_jobs() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            simulation = await response.parse()
            assert_matches_type(SimulationListRunPlanJobsResponse, simulation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_list_scenarios(self, async_client: AsyncRoark) -> None:
        simulation = await async_client.simulation.list_scenarios()
        assert_matches_type(SimulationListScenariosResponse, simulation, path=["response"])

    @parametrize
    async def test_method_list_scenarios_with_all_params(self, async_client: AsyncRoark) -> None:
        simulation = await async_client.simulation.list_scenarios(
            after="after",
            limit=1,
        )
        assert_matches_type(SimulationListScenariosResponse, simulation, path=["response"])

    @parametrize
    async def test_raw_response_list_scenarios(self, async_client: AsyncRoark) -> None:
        response = await async_client.simulation.with_raw_response.list_scenarios()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        simulation = await response.parse()
        assert_matches_type(SimulationListScenariosResponse, simulation, path=["response"])

    @parametrize
    async def test_streaming_response_list_scenarios(self, async_client: AsyncRoark) -> None:
        async with async_client.simulation.with_streaming_response.list_scenarios() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            simulation = await response.parse()
            assert_matches_type(SimulationListScenariosResponse, simulation, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_start_run_plan_job(self, async_client: AsyncRoark) -> None:
        simulation = await async_client.simulation.start_run_plan_job(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        )
        assert_matches_type(SimulationStartRunPlanJobResponse, simulation, path=["response"])

    @parametrize
    async def test_raw_response_start_run_plan_job(self, async_client: AsyncRoark) -> None:
        response = await async_client.simulation.with_raw_response.start_run_plan_job(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        simulation = await response.parse()
        assert_matches_type(SimulationStartRunPlanJobResponse, simulation, path=["response"])

    @parametrize
    async def test_streaming_response_start_run_plan_job(self, async_client: AsyncRoark) -> None:
        async with async_client.simulation.with_streaming_response.start_run_plan_job(
            "7f3e4d2c-8a91-4b5c-9e6f-1a2b3c4d5e6f",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            simulation = await response.parse()
            assert_matches_type(SimulationStartRunPlanJobResponse, simulation, path=["response"])

        assert cast(Any, response.is_closed) is True
