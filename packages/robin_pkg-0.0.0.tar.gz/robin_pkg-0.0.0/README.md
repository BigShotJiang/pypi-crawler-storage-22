# robin

A bare bones Python package.

## Install

```bash
pip install -e .
```
