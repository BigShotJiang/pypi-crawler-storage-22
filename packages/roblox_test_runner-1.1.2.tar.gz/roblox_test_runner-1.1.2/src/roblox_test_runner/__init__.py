"""
Roblox Test Runner
Execute Luau tests on Roblox Cloud
"""

__version__ = "1.0.0"
__author__ = "WildLink Team"

from .cli import main

__all__ = ["main"]
