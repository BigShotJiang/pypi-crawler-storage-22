"""
Entry point for python -m roblox_test_runner
"""
from .cli import main

if __name__ == "__main__":
    main()
