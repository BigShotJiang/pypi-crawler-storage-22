# robo-automation-test-kit

Complete automation testing starter kit with pytest plugin, HTML reports, charts, and parallel execution support.

## Installation

### Install from PyPI (once published)
```bash
pip install robo-automation-test-kit
```

### Install from source for development
```bash
# Clone the repository
git clone https://github.com/dinilmithra/robo_automation_test_kit.git
cd robo_automation_test_kit

# Install Poetry (if not already installed)
pip install poetry

# Install dependencies and package in editable mode
poetry install

# Or use pip
pip install -e .
```

## Building and Publishing with Poetry

### 1. Install Poetry
```bash
pip install poetry
```

### 2. Build the package
```bash
poetry build
```

This creates distribution files in the `dist/` directory.

### 3. Configure PyPI token (for publishing)
```bash
poetry config pypi-token.pypi <your-pypi-token>
```

### 4. Publish to PyPI
```bash
# Publish to Test PyPI (recommended first time)
poetry config repositories.testpypi https://test.pypi.org/legacy/
poetry publish -r testpypi

# Publish to production PyPI
poetry publish
```

For detailed publishing instructions, see [PUBLISHING.md](PUBLISHING.md).

## Usage

This package provides a pytest plugin that automatically generates HTML reports with charts and visualizations.

### Basic usage
```bash
pytest
```

### With custom options
```bash
pytest --robo-report=custom_report.html --robo-report-title="Smoke Tests"
```

### Run specific test file
```bash
pytest tests/test_Template.py
```

## Dynamic Pytest Log Level Control

You can control the pytest log level dynamically using an environment variable when running tests from the command line.

### Windows PowerShell
```powershell
$env:LOG_LEVEL="WARNING"
pytest --log-cli-level=$env:LOG_LEVEL
```

### Windows Command Prompt
```cmd
set LOG_LEVEL=WARNING
pytest --log-cli-level=%LOG_LEVEL%
```

### Linux/macOS
```bash
export LOG_LEVEL=WARNING
pytest --log-cli-level=$LOG_LEVEL
```

Replace `WARNING` with any valid log level (e.g., `INFO`, `ERROR`, `DEBUG`).