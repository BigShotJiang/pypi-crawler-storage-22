# This contains the module information ;)
version = '4.2.7'
author = 'Noah Broyles'
email = 'noah@x3nzpouwu.com'
