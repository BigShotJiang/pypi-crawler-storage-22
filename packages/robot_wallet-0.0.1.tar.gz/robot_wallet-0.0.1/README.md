# robot-wallet (placeholder)

This directory contains a **placeholder Python package** for `robot-wallet`.

## Install (editable)

```bash
python -m pip install -e .
```

## Run

```bash
robot-wallet
python -m robot_wallet
```

