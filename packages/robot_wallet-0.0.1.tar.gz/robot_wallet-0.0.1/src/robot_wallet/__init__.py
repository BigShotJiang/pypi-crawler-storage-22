"""
robot_wallet

Placeholder package for the robot-wallet project.
"""

__all__ = ["__version__"]

__version__ = "0.0.0"

