# # backend/memory_reader.py
# from ..memory_store import event_store
# from .event_reader import EventReader

# class MemoryEventReader(EventReader):
#     def get_events(self):
#         return event_store
    
#     def clear_events(self):
#         event_store.clear()
