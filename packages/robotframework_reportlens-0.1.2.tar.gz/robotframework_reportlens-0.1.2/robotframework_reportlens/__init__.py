"""robotframework-reportlens: modern HTML report from Robot Framework output.xml."""

__version__ = "0.1.2"
