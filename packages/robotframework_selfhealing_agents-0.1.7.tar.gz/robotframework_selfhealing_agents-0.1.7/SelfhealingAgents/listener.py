import os
from pathlib import Path
from dotenv import load_dotenv, find_dotenv

from robot import result, running
from robot.api import logger as rf_logger
from robot.api.interfaces import ListenerV3

from SelfhealingAgents.utils.cfg import Cfg
from SelfhealingAgents.self_healing_system.self_healing_engine import SelfHealingEngine
from SelfhealingAgents.self_healing_system.reports.report_generator import ReportGenerator
from SelfhealingAgents.self_healing_system.schemas.internal_state.listener_state import ListenerState
from SelfhealingAgents.self_healing_system.reports.report_info_persistence import (
    save_report_info,
    load_report_info,
    REPORT_INFO_FILE,
    deduplicate_report_info,
    sort_report_info
)


class SelfhealingAgents(ListenerV3):
    """Robot Framework listener that provides self-healing capabilities.

    This listener integrates with Robot Framework to enable self-healing test execution.
    It manages the internal state, coordinates the self-healing engine, and generates reports
    based on test execution outcomes.

    Attributes:
        ROBOT_LIBRARY_SCOPE (str): The scope of the Robot Framework library ('GLOBAL').
        ROBOT_LISTENER_API_VERSION (int): The Robot Framework listener API version (3).
        ROBOT_LIBRARY_LISTENER (SelfHealing-Agents): Reference to the listener instance (set to self).
        _state (ListenerState): The internal state object shared with the self-healing engine.
        _self_healing_engine (SelfHealingEngine): The self-healing engine instance.
        _report_generator (ReportGenerator): The report generator instance.
        _closed (bool): Whether the listener has been closed.
    """
    ROBOT_LIBRARY_SCOPE = "GLOBAL"
    ROBOT_LISTENER_API_VERSION = 3

    def __init__(self) -> None:
        """Initializes the SelfhealingAgents listener and its components.

        The "_state" attribute of type ListenerState is shared and manipulated
        in the self_healing_engine module.
        """
        self._robust_env_load()
        self._cfg: Cfg = Cfg()
        self.ROBOT_LIBRARY_LISTENER: SelfhealingAgents = self
        self._state: ListenerState = ListenerState(cfg=self._cfg)  # type: ignore
        self._self_healing_engine: SelfHealingEngine = SelfHealingEngine(self._state)
        self._report_generator: ReportGenerator = ReportGenerator(base_dir=self._cfg.report_directory)
        self._closed: bool = False
        rf_logger.info(
            f"SelfhealingAgents initialized; healing="
            f"{'enabled' if self._state.cfg.enable_self_healing else 'disabled'}"
        )

    def _robust_env_load(self) -> None:
        """Handles environment variables loading. First, it tries to find "DOTENV_PATH", then
           "envfile" in cwd, if not available, it searches directories for .env. If neither of those
           work, it tries to load the process environment variables.
        """
        loaded_from: str | None = None

        explicit_path: str | None = os.environ.get("DOTENV_PATH")
        if explicit_path and Path(explicit_path).is_file():
            load_dotenv(dotenv_path=explicit_path, override=False)
            loaded_from = explicit_path

        if loaded_from is None:
            envfile_path = Path(os.getcwd()) / "envfile"
            if envfile_path.is_file():
                load_dotenv(dotenv_path=str(envfile_path), override=False)
                loaded_from = str(envfile_path)

        if loaded_from is None:
            candidates = [
                Path(os.getcwd()) / ".env",
                Path(__file__).resolve().parent / ".env",
                ]
            for p in candidates:
                if p.is_file():
                    load_dotenv(dotenv_path=str(p), override=False)
                    loaded_from = str(p)
                    break

        if loaded_from is None:
            try:
                found = find_dotenv(usecwd=True)
            except TypeError:
                found = find_dotenv()
            if found:
                load_dotenv(dotenv_path=found, override=False)
                loaded_from = found

        if loaded_from is None:
            load_dotenv(override=False)

        if loaded_from:
            rf_logger.info(f"environment variables loaded from: {loaded_from}")
        else:
            rf_logger.info("no env file found; relying on existing process environment variables")

    def start_test(
            self, data: running.TestCase, result_: result.TestCase
    ) -> None:
        """Handles the start of a test case.

        Invoked by Robot Framework when a test case starts. Delegates to the self-healing engine.

        Args:
            data: The running test case data.
            result_: The result object for the test case.
        """
        self._self_healing_engine.start_test(data, result_)

    def end_keyword(
            self, data: running.Keyword, result_: result.Keyword
    ) -> None:
        """Handles the end of a keyword execution.

        Invoked by Robot Framework when a keyword finishes execution. Delegates to the self-healing engine.

        Args:
            data: The running keyword data.
            result_: The result object for the keyword.
        """
        self._self_healing_engine.end_keyword(data, result_)

    def end_test(
            self, data: running.TestCase, result_: result.TestCase
    ) -> None:
        """Handles the end of a test case.

        Invoked by Robot Framework when a test case ends. Delegates to the self-healing engine.

        Args:
            data: The running test case data.
            result_: The result object for the test case.
        """
        self._self_healing_engine.end_test(data, result_)

    def close(self) -> None:
        """Handles the closure of the test suite or all suites when scope is 'GLOBAL'.
        When rerun is activated (cfg.is_rerun_activated is True), report_info is persisted
        as JSON in the current working directory (report_info.json).
        - On the first run (no JSON exists yet), we create the JSON from the current report_info.
        - On the rerun (JSON exists), we load previous report_info, append the current run's
          entries, and use the combined list for report generation.
        """
        if self._closed:
            return
        self._closed = True

        # case 1: No rerun activated
        if not self._state.cfg.is_rerun_activated:
            if self._state.report_info:
                try:
                    self._report_generator.generate_reports(self._state.report_info)
                except Exception as e:
                    rf_logger.warn(f"Report generation failed: {e}")
            return

        # case 2: Rerun activated -> json of report_info is created in cwd -> Rerun loads json of first run -> merge
        json_path = Path.cwd() / REPORT_INFO_FILE.name
        try:
            if not json_path.exists():
                if self._state.report_info:
                    save_report_info(self._state.report_info, json_path)
                    rf_logger.info(
                        f"Initial run with rerun activated: persisted "
                        f"{len(self._state.report_info)} report entries to {json_path}"
                    )
                else:
                    rf_logger.info(
                        "Initial run with rerun activated: no report_info to persist"
                    )
                if self._state.report_info:
                    try:
                        self._report_generator.generate_reports(self._state.report_info)
                    except Exception as e:
                        rf_logger.warn(f"Report generation failed on initial run: {e}")
            else:
                previous = load_report_info(json_path)
                current = list(self._state.report_info)
                combined = previous + current
                deduped = deduplicate_report_info(combined)
                ordered = sort_report_info(deduped)

                rf_logger.info(
                    "Rerun with rerun activated: loaded "
                    f"{len(previous)} previous, {len(current)} current; "
                    f"{len(combined)} total before dedup, {len(deduped)} after dedup; "
                    f"sorted by file and lineno"
                )
                save_report_info(ordered, json_path)
                if ordered:
                    try:
                        self._report_generator.generate_reports(ordered)
                    except Exception as e:
                        rf_logger.warn(f"Report generation failed on rerun: {e}")
                try:
                    json_path.unlink(missing_ok=True)
                    rf_logger.info(f"Removed temporary report_info file: {json_path}")
                except Exception as e:
                    rf_logger.warn(f"Failed to remove temporary report_info file {json_path}: {e}")
        except Exception as e:
            rf_logger.warn(f"Error handling report_info persistence: {e}")