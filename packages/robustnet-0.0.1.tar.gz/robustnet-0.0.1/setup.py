#!/usr/bin/env python


from sys import version_info
from warnings import warn
from setuptools import setup


if version_info[:2] <= (3, 7):
    warn('RobustNet is not tested in early versions of Python.')

setup()
