"""Robyn DDD demo application inspired by src 2 design."""
