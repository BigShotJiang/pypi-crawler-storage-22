## 0.13.0

Update iconscript version to 0.3.

Add icons:
  - `bicycle___plug`,
  - `double_folded_paper`,
  - `power_pole_flag_armless`,
  - `power_tower_barrel_1_level`,
  - `power_tower_donau_1_level`,
  - `power_tower_guyed_v_frame`,
  - `power_tower_h_frame_3_level`,
  - `power_tower_monopolar`,
  - `toilet_bowl`.

Redraw icons:
  - `bicycle`,
  - `bicycle___x_4`,
  - `bicycle___key`,
  - `bicycle___wrench`,
  - `bicycle___p_small`,
  - `cocktail_glass`.

Move `triangle_small` icon.

Add `grid` command for icon grid drawing.

## 0.12.0

Update iconscript version from 0.1 to 0.2 and replace many icons with iconscript
code, instead of SVG files.

Code:
  - Fix `cairosvg` import and encoding error on Windows.

Redraw icons:
  - `envelope`,
  - `i_in_square`,
  - `i`,
  - `pyramid`,
  - `table`,
  - `watches`.

Make icons smoother and make corners round:
  - `table_and_two_chairs___pergola`,
  - `train`.

Fix icons:
  - `greek_cross_in_box`.

Adjust icon size:
  - `survey_point`.

## 0.11.0

Python package:
  - Migrate minimum Python version from 3.9 to 3.10
    ([#8](https://github.com/enzet/Roentgen/issues/8)).
  - Fix `cairosvg` import error on Windows.

Redraw icons:
  - `amusement_ride`,
  - `bicycle_parking_rack`,
  - `bicycle_parking_stand`,
  - `bicycle_parking_wall_loops`,
  - `cctv`,
  - `food_court`,
  - `kiosk`,
  - `marketplace`,
  - `p_small___bicycle_parking_rack`,
  - `p_small___bicycle_parking_stand`,
  - `p_small___bicycle_parking_wall_loops`,
  - `shop_convenience`,
  - `vending_excrement_bag`.

Flip icons:
  - `buffer_stop`,
  - `fountain_roman_wolf`,
  - `supermarket_cart`.

## 0.10.0

Add API for Python package roentgen-icons
([#6](https://github.com/enzet/Roentgen/issues/6)).

## 0.9.0

Add support for iconscript 0.1 files, use iconscript for all `power_tower_*` and
`power_pole_*` icons except for `power_tower_donau`.

Redraw icons:
  - `bed`,
  - `bed_and_roof`,
  - `bed_with_floor_and_ceiling`,
  - `bicycle___wrench`,
  - `car___bed`,
  - `car___wrench`,
  - `coffee_cup`,
  - `fuel_station`,
  - `orbiter`,
  - `peach`,
  - `two_beds`.

Adjust icon size:
  - `cave`,
  - `prison`.

Make icons smoother and make corners round:
  - `charging_station`,
  - `torch`.

Change direction of icons:
  - `wrench`.

Fix icons:
  - `film`,
  - `vending_excrement_bag`.


## 0.8.0

Redraw icons:
  - `bed_and_roof`,
  - `bed_with_floor_and_ceiling`,
  - `bed`,
  - `bollard`,
  - `booster_landing`,
  - `car___bed`,
  - `ear_botany`,
  - `elevator`,
  - `leaf_maple`,
  - `no_wheelchair`,
  - `oat_2`,
  - `oat`,
  - `pillar`,
  - `pole_dancer`,
  - `rocket_flying`,
  - `rocket_on_launch_pad`,
  - `shoe`,
  - `t_shirt`,
  - `torch`,
  - `two_beds`,
  - `tyre`,
  - `wheelchair`,
  - `wood`,
  - `wretch_and_hammer`.

Adjust icon size:
  - `horizontal_ladder`.

Make icons smoother and make corners round:
  - `atm`,
  - `japan_elementary_school`,
  - `shower`.

Fix icon:
  - `microphone`.


## 0.7.0

Redraw icons:
  - `bbq`,
  - `betula___bottom_right_horizontal_line`,
  - `betula___urban_tree_pot`,
  - `betula`,
  - `bicycle___wrench`,
  - `building`,
  - `bush`,
  - `car___wrench`,
  - `coffee_cup`,
  - `diamond`,
  - `drinking_water`,
  - `ear_botany_2`,
  - `fire_pit`,
  - `fireplace`,
  - `fountain_bubbler`,
  - `golf_club_and_ball`,
  - `microphone`,
  - `monument`,
  - `third_stage`,
  - `tooth`,
  - `vending_angle`,
  - `vending_candles`,
  - `vending_drop`,
  - `vending_machine`,
  - `wrench`.

Adjust icon size:
  - `card_and_dice`,
  - `crane_gantry`.

Make icons smoother and make corners round:
  - `bbq`,
  - `beer_mug`,
  - `betula___bottom_right_horizontal_line`,
  - `betula___urban_tree_pot`,
  - `bottle_and_wine_glass`,
  - `bottle`,
  - `city_gate`,
  - `ice_cream`,
  - `ice_cream_2`,
  - `needleleaved_tree___bottom_right_horizontal_line`,
  - `needleleaved_tree___urban_tree_pot`,
  - `obelisk`,
  - `pagoda`,
  - `palm___bottom_right_horizontal_line`,
  - `palm___urban_tree_pot`,
  - `sunflower`,
  - `t_shirt_and_scissors`,
  - `table_and_two_chairs___roof_and_walls`,
  - `tomb`,
  - `tree___bottom_right_horizontal_line`,
  - `tree___urban_tree_pot`,
  - `tree_with_leaf___bottom_right_horizontal_line`,
  - `tree_with_leaf___urban_tree_pot`,
  - `tv`,
  - `vending_bottle`,
  - `vending_chemist`,
  - `woman_and_man`.


## 0.6.0

Reorganize paths of the majority of shapes: delete redundant nodes, simplify
curves. This may change the shape in not detectable way.

Redraw icons:
  - `bag`,
  - `beer_mug`,
  - `books`,
  - `cannon`,
  - `car___car`,
  - `cocktail_glass`,
  - `cocktail_glass_with_straw`,
  - `czech_hedgehog`,
  - `fork_and_knife`,
  - `garage_door`,
  - `government`,
  - `hi_fi`,
  - `rectangle_vertical_rounded_crossed`,
  - `side_mirror`,
  - `slide`,
  - `tyre`.

Make icons smoother and make corners round:
  - `baptist`,
  - `book`,
  - `cactus`,
  - `fort`,
  - `human`,
  - `no_traffic_signals`,
  - `power_generator`,
  - `statue`,
  - `statue_exhibit`,
  - `stop`,
  - `townhall`.

Adjust icon size:
  - `binoculars_on_pole`,
  - `entrance`,
  - `gazette`,
  - `star_of_david`,
  - `stop`,
  - `supermarket_cart`.

Create separate `car___car` icon instead of combination of two `car` icons.


## 0.5.0

Redraw icons:
  - `apple`,
  - `comb_and_scissors`,
  - `digital_clock`,
  - `glasses`,
  - `pear`.

Make icons smoother and make corners round:
  - `at_in_square`,
  - `clockwise`,
  - `counterclockwise`,
  - `cupcake`,
  - `defibrillator`,
  - `fireplace`,
  - `golf_tee`,
  - `japan_castle`,
  - `japan_court`,
  - `japan_fire_station`,
  - `japan_forest_service`,
  - `japan_koban`,
  - `japan_post`,
  - `japan_public_health_center`,
  - `japan_shinto_shrine`,
  - `japan_tv_tower`,
  - `japan_weather_station`,
  - `japan_well`,
  - `money`.

Adjust icon size:
  - `bowling_ball`,
  - `gavel`,
  - `knives`,
  - `watches`.

Flip icons horizontally to make all directed icons be directed to the right.
This changes
  - `bicycle`,
  - `bicycle___key`,
  - `bicycle___p_small`,
  - `bicycle___wrench`,
  - `bicycle___x_4`,
  - `car___key`,
  - `car___wrench`,
  - `dog`,
  - `dog_and_cross`,
  - `massage`,
  - `probe`,
  - `sauna`,
  - `toy_horse`,
  - `wrench`.


## 0.4.0

Redraw icons:
  - `car_on_ferry`,
  - `car`,
  - `caravan`,
  - `ford`,
  - `garages`,
  - `milestone`,
  - `shower_head`,
  - `slide_and_water`.

Redrawing car also changes `car___bed`, `car___car`, `car___key`,
`car___sharing`, `car___shower_head`, and `car___wrench` combinations.

Make icons smoother and make corners round:
  - `cocktail_glass`,
  - `ear_botany`,
  - `golf_pin`,
  - `guidepost`,
  - `memorial`,
  - `survey_point`,
  - `umbrella`.

Making smoother changes `table_and_two_chairs___umbrella` combination.

Enhance script for more popular OpenStreetMap tags.


## 0.3.0

8 June 2025. 514 icons.

Break changes: icons in `icons` directory now have no `roentgen_` prefix.

Redraw icons:
  - `cave`,
  - `knives`,
  - `pole_lamp`,
  - `staircase`.

Make icons smoother and make corners round:
  - `cliff`,
  - `cooling_tower`,
  - `crescent`,
  - `flag`,
  - `gate`,
  - `key`,
  - `plane`,
  - `star_of_david`,
  - `stone`.

Move `bottom_right_horizontal_line` to better fit `tree` and `tree_with_leaf`,
move `building_construction` and slightly change `diving_4_platform`.

Add script for extracting more popular OpenStreetMap tags from Taginfo and
create mapping between OpenStreetMap tags and Röntgen icons.


## 0.2.0

4 June 2025. 514 icons.

Redraw icons:
  - `car_on_ferry`,
  - `gift`,
  - `human_on_ferry`,
  - `seasaw`,
  - `tree_with_leaf`,
  - `tree`.

Make icons smoother and make corners round:
  - `aseptic_carton`,
  - `card_and_dice`,
  - `defensive_tower`,
  - `drawer`,
  - `lock_unlocked`,
  - `medicine_bottle`,
  - `needleleaved_tree`,
  - `palm`,
  - `sheets`,
  - `solar_panel`,
  - `supermarket_cart`,
  - `taxi`,
  - `waterfall`.

Changes on trees also influence their combinations with
`bottom_right_horizontal_line` and `urban_tree_pot`.

Unify style for water in different icons:
  - `car_on_ferry`,
  - `crane_travel_lift`,
  - `human_on_ferry`,
  - `waterfall`.


## 0.1.0

29 August 2023. This is the first version after migrating the Röntgen project
from the Map Machine repository to its own repository. This version contains 514
icons, including icon combinations.

This is the first version used in the iD editor. The icons were copied to the
[`svg/roentgen`](https://github.com/openstreetmap/iD/tree/develop/svg/roentgen)
directory by
[this commit](https://github.com/openstreetmap/iD/commit/98e9a11a511179b24c8c0aa6f520a9ed372b1c55).
