from setuptools import setup, find_packages

setup(
    name="rogueflow",
    version="0.0.1",
    author="a22999",
    author_email="1315042@qq.com",
    description="RogueFlow: Go Rogue. Flow Unbound.",
    long_description="RogueFlow is coming soon. A high-performance flow engine.",
    long_description_content_type="text/markdown",
    url="https://github.com/a22999/RogueFlow",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)