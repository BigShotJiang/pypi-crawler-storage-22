# Generated from Ron.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,19,152,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        1,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,43,8,
        1,1,2,1,2,1,2,1,2,1,2,1,2,3,2,51,8,2,1,3,3,3,54,8,3,1,3,1,3,1,3,
        1,3,1,4,1,4,1,5,1,5,1,5,3,5,65,8,5,1,5,3,5,68,8,5,1,6,1,6,3,6,72,
        8,6,1,7,1,7,1,7,5,7,77,8,7,10,7,12,7,80,9,7,1,7,3,7,83,8,7,1,8,1,
        8,1,8,1,8,1,9,1,9,1,9,5,9,92,8,9,10,9,12,9,95,9,9,1,9,3,9,98,8,9,
        1,10,1,10,1,10,1,10,5,10,104,8,10,10,10,12,10,107,9,10,1,10,3,10,
        110,8,10,3,10,112,8,10,1,10,1,10,1,11,1,11,1,11,1,11,1,12,1,12,1,
        12,1,12,5,12,124,8,12,10,12,12,12,127,9,12,1,12,3,12,130,8,12,3,
        12,132,8,12,1,12,1,12,1,13,1,13,1,13,1,13,5,13,140,8,13,10,13,12,
        13,143,9,13,1,13,3,13,146,8,13,3,13,148,8,13,1,13,1,13,1,13,0,0,
        14,0,2,4,6,8,10,12,14,16,18,20,22,24,26,0,0,165,0,28,1,0,0,0,2,42,
        1,0,0,0,4,50,1,0,0,0,6,53,1,0,0,0,8,59,1,0,0,0,10,61,1,0,0,0,12,
        71,1,0,0,0,14,73,1,0,0,0,16,84,1,0,0,0,18,88,1,0,0,0,20,99,1,0,0,
        0,22,115,1,0,0,0,24,119,1,0,0,0,26,135,1,0,0,0,28,29,3,2,1,0,29,
        30,5,0,0,1,30,1,1,0,0,0,31,43,3,4,2,0,32,43,3,10,5,0,33,43,3,6,3,
        0,34,43,3,20,10,0,35,43,3,24,12,0,36,43,3,26,13,0,37,43,5,16,0,0,
        38,43,5,15,0,0,39,43,5,13,0,0,40,43,5,14,0,0,41,43,5,11,0,0,42,31,
        1,0,0,0,42,32,1,0,0,0,42,33,1,0,0,0,42,34,1,0,0,0,42,35,1,0,0,0,
        42,36,1,0,0,0,42,37,1,0,0,0,42,38,1,0,0,0,42,39,1,0,0,0,42,40,1,
        0,0,0,42,41,1,0,0,0,43,3,1,0,0,0,44,45,5,9,0,0,45,46,5,1,0,0,46,
        47,3,2,1,0,47,48,5,2,0,0,48,51,1,0,0,0,49,51,5,10,0,0,50,44,1,0,
        0,0,50,49,1,0,0,0,51,5,1,0,0,0,52,54,5,12,0,0,53,52,1,0,0,0,53,54,
        1,0,0,0,54,55,1,0,0,0,55,56,5,1,0,0,56,57,3,8,4,0,57,58,5,2,0,0,
        58,7,1,0,0,0,59,60,3,14,7,0,60,9,1,0,0,0,61,67,5,12,0,0,62,64,5,
        1,0,0,63,65,3,12,6,0,64,63,1,0,0,0,64,65,1,0,0,0,65,66,1,0,0,0,66,
        68,5,2,0,0,67,62,1,0,0,0,67,68,1,0,0,0,68,11,1,0,0,0,69,72,3,14,
        7,0,70,72,3,18,9,0,71,69,1,0,0,0,71,70,1,0,0,0,72,13,1,0,0,0,73,
        78,3,16,8,0,74,75,5,3,0,0,75,77,3,16,8,0,76,74,1,0,0,0,77,80,1,0,
        0,0,78,76,1,0,0,0,78,79,1,0,0,0,79,82,1,0,0,0,80,78,1,0,0,0,81,83,
        5,3,0,0,82,81,1,0,0,0,82,83,1,0,0,0,83,15,1,0,0,0,84,85,5,12,0,0,
        85,86,5,4,0,0,86,87,3,2,1,0,87,17,1,0,0,0,88,93,3,2,1,0,89,90,5,
        3,0,0,90,92,3,2,1,0,91,89,1,0,0,0,92,95,1,0,0,0,93,91,1,0,0,0,93,
        94,1,0,0,0,94,97,1,0,0,0,95,93,1,0,0,0,96,98,5,3,0,0,97,96,1,0,0,
        0,97,98,1,0,0,0,98,19,1,0,0,0,99,111,5,5,0,0,100,105,3,22,11,0,101,
        102,5,3,0,0,102,104,3,22,11,0,103,101,1,0,0,0,104,107,1,0,0,0,105,
        103,1,0,0,0,105,106,1,0,0,0,106,109,1,0,0,0,107,105,1,0,0,0,108,
        110,5,3,0,0,109,108,1,0,0,0,109,110,1,0,0,0,110,112,1,0,0,0,111,
        100,1,0,0,0,111,112,1,0,0,0,112,113,1,0,0,0,113,114,5,6,0,0,114,
        21,1,0,0,0,115,116,3,2,1,0,116,117,5,4,0,0,117,118,3,2,1,0,118,23,
        1,0,0,0,119,131,5,1,0,0,120,125,3,2,1,0,121,122,5,3,0,0,122,124,
        3,2,1,0,123,121,1,0,0,0,124,127,1,0,0,0,125,123,1,0,0,0,125,126,
        1,0,0,0,126,129,1,0,0,0,127,125,1,0,0,0,128,130,5,3,0,0,129,128,
        1,0,0,0,129,130,1,0,0,0,130,132,1,0,0,0,131,120,1,0,0,0,131,132,
        1,0,0,0,132,133,1,0,0,0,133,134,5,2,0,0,134,25,1,0,0,0,135,147,5,
        7,0,0,136,141,3,2,1,0,137,138,5,3,0,0,138,140,3,2,1,0,139,137,1,
        0,0,0,140,143,1,0,0,0,141,139,1,0,0,0,141,142,1,0,0,0,142,145,1,
        0,0,0,143,141,1,0,0,0,144,146,5,3,0,0,145,144,1,0,0,0,145,146,1,
        0,0,0,146,148,1,0,0,0,147,136,1,0,0,0,147,148,1,0,0,0,148,149,1,
        0,0,0,149,150,5,8,0,0,150,27,1,0,0,0,19,42,50,53,64,67,71,78,82,
        93,97,105,109,111,125,129,131,141,145,147
    ]

class RonParser ( Parser ):

    grammarFileName = "Ron.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'('", "')'", "','", "':'", "'{'", "'}'", 
                     "'['", "']'", "'Some'", "'None'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "SOME", "NONE", "BOOLEAN", "IDENTIFIER", 
                      "FLOAT", "INTEGER", "STRING", "CHAR", "WS", "COMMENT", 
                      "BLOCK_COMMENT" ]

    RULE_root = 0
    RULE_value = 1
    RULE_option = 2
    RULE_ron_anon_struct = 3
    RULE_strict_struct_body = 4
    RULE_ron_struct = 5
    RULE_struct_body = 6
    RULE_named_fields = 7
    RULE_named_field = 8
    RULE_unnamed_fields = 9
    RULE_ron_map = 10
    RULE_map_entry = 11
    RULE_ron_tuple = 12
    RULE_ron_list = 13

    ruleNames =  [ "root", "value", "option", "ron_anon_struct", "strict_struct_body", 
                   "ron_struct", "struct_body", "named_fields", "named_field", 
                   "unnamed_fields", "ron_map", "map_entry", "ron_tuple", 
                   "ron_list" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    SOME=9
    NONE=10
    BOOLEAN=11
    IDENTIFIER=12
    FLOAT=13
    INTEGER=14
    STRING=15
    CHAR=16
    WS=17
    COMMENT=18
    BLOCK_COMMENT=19

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class RootContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def value(self):
            return self.getTypedRuleContext(RonParser.ValueContext,0)


        def EOF(self):
            return self.getToken(RonParser.EOF, 0)

        def getRuleIndex(self):
            return RonParser.RULE_root

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRoot" ):
                return visitor.visitRoot(self)
            else:
                return visitor.visitChildren(self)




    def root(self):

        localctx = RonParser.RootContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_root)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 28
            self.value()
            self.state = 29
            self.match(RonParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return RonParser.RULE_value

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ListValueContext(ValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a RonParser.ValueContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ron_list(self):
            return self.getTypedRuleContext(RonParser.Ron_listContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListValue" ):
                return visitor.visitListValue(self)
            else:
                return visitor.visitChildren(self)


    class OptionValueContext(ValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a RonParser.ValueContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def option(self):
            return self.getTypedRuleContext(RonParser.OptionContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOptionValue" ):
                return visitor.visitOptionValue(self)
            else:
                return visitor.visitChildren(self)


    class StructValueContext(ValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a RonParser.ValueContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ron_struct(self):
            return self.getTypedRuleContext(RonParser.Ron_structContext,0)

        def ron_anon_struct(self):
            return self.getTypedRuleContext(RonParser.Ron_anon_structContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStructValue" ):
                return visitor.visitStructValue(self)
            else:
                return visitor.visitChildren(self)


    class BoolValueContext(ValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a RonParser.ValueContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def BOOLEAN(self):
            return self.getToken(RonParser.BOOLEAN, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBoolValue" ):
                return visitor.visitBoolValue(self)
            else:
                return visitor.visitChildren(self)


    class MapValueContext(ValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a RonParser.ValueContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ron_map(self):
            return self.getTypedRuleContext(RonParser.Ron_mapContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMapValue" ):
                return visitor.visitMapValue(self)
            else:
                return visitor.visitChildren(self)


    class CharValueContext(ValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a RonParser.ValueContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CHAR(self):
            return self.getToken(RonParser.CHAR, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCharValue" ):
                return visitor.visitCharValue(self)
            else:
                return visitor.visitChildren(self)


    class FloatValueContext(ValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a RonParser.ValueContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def FLOAT(self):
            return self.getToken(RonParser.FLOAT, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFloatValue" ):
                return visitor.visitFloatValue(self)
            else:
                return visitor.visitChildren(self)


    class StringValueContext(ValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a RonParser.ValueContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(RonParser.STRING, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStringValue" ):
                return visitor.visitStringValue(self)
            else:
                return visitor.visitChildren(self)


    class IntValueContext(ValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a RonParser.ValueContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INTEGER(self):
            return self.getToken(RonParser.INTEGER, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntValue" ):
                return visitor.visitIntValue(self)
            else:
                return visitor.visitChildren(self)


    class TupleValueContext(ValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a RonParser.ValueContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ron_tuple(self):
            return self.getTypedRuleContext(RonParser.Ron_tupleContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTupleValue" ):
                return visitor.visitTupleValue(self)
            else:
                return visitor.visitChildren(self)



    def value(self):

        localctx = RonParser.ValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_value)
        try:
            self.state = 42
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
            if la_ == 1:
                localctx = RonParser.OptionValueContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 31
                self.option()
                pass

            elif la_ == 2:
                localctx = RonParser.StructValueContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 32
                self.ron_struct()
                pass

            elif la_ == 3:
                localctx = RonParser.StructValueContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 33
                self.ron_anon_struct()
                pass

            elif la_ == 4:
                localctx = RonParser.MapValueContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 34
                self.ron_map()
                pass

            elif la_ == 5:
                localctx = RonParser.TupleValueContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 35
                self.ron_tuple()
                pass

            elif la_ == 6:
                localctx = RonParser.ListValueContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 36
                self.ron_list()
                pass

            elif la_ == 7:
                localctx = RonParser.CharValueContext(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 37
                self.match(RonParser.CHAR)
                pass

            elif la_ == 8:
                localctx = RonParser.StringValueContext(self, localctx)
                self.enterOuterAlt(localctx, 8)
                self.state = 38
                self.match(RonParser.STRING)
                pass

            elif la_ == 9:
                localctx = RonParser.FloatValueContext(self, localctx)
                self.enterOuterAlt(localctx, 9)
                self.state = 39
                self.match(RonParser.FLOAT)
                pass

            elif la_ == 10:
                localctx = RonParser.IntValueContext(self, localctx)
                self.enterOuterAlt(localctx, 10)
                self.state = 40
                self.match(RonParser.INTEGER)
                pass

            elif la_ == 11:
                localctx = RonParser.BoolValueContext(self, localctx)
                self.enterOuterAlt(localctx, 11)
                self.state = 41
                self.match(RonParser.BOOLEAN)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OptionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SOME(self):
            return self.getToken(RonParser.SOME, 0)

        def value(self):
            return self.getTypedRuleContext(RonParser.ValueContext,0)


        def NONE(self):
            return self.getToken(RonParser.NONE, 0)

        def getRuleIndex(self):
            return RonParser.RULE_option

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOption" ):
                return visitor.visitOption(self)
            else:
                return visitor.visitChildren(self)




    def option(self):

        localctx = RonParser.OptionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_option)
        try:
            self.state = 50
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [9]:
                self.enterOuterAlt(localctx, 1)
                self.state = 44
                self.match(RonParser.SOME)
                self.state = 45
                self.match(RonParser.T__0)
                self.state = 46
                self.value()
                self.state = 47
                self.match(RonParser.T__1)
                pass
            elif token in [10]:
                self.enterOuterAlt(localctx, 2)
                self.state = 49
                self.match(RonParser.NONE)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ron_anon_structContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def strict_struct_body(self):
            return self.getTypedRuleContext(RonParser.Strict_struct_bodyContext,0)


        def IDENTIFIER(self):
            return self.getToken(RonParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return RonParser.RULE_ron_anon_struct

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRon_anon_struct" ):
                return visitor.visitRon_anon_struct(self)
            else:
                return visitor.visitChildren(self)




    def ron_anon_struct(self):

        localctx = RonParser.Ron_anon_structContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_ron_anon_struct)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 53
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==12:
                self.state = 52
                self.match(RonParser.IDENTIFIER)


            self.state = 55
            self.match(RonParser.T__0)
            self.state = 56
            self.strict_struct_body()
            self.state = 57
            self.match(RonParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Strict_struct_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def named_fields(self):
            return self.getTypedRuleContext(RonParser.Named_fieldsContext,0)


        def getRuleIndex(self):
            return RonParser.RULE_strict_struct_body

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStrict_struct_body" ):
                return visitor.visitStrict_struct_body(self)
            else:
                return visitor.visitChildren(self)




    def strict_struct_body(self):

        localctx = RonParser.Strict_struct_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_strict_struct_body)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 59
            self.named_fields()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ron_structContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(RonParser.IDENTIFIER, 0)

        def struct_body(self):
            return self.getTypedRuleContext(RonParser.Struct_bodyContext,0)


        def getRuleIndex(self):
            return RonParser.RULE_ron_struct

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRon_struct" ):
                return visitor.visitRon_struct(self)
            else:
                return visitor.visitChildren(self)




    def ron_struct(self):

        localctx = RonParser.Ron_structContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_ron_struct)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 61
            self.match(RonParser.IDENTIFIER)
            self.state = 67
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==1:
                self.state = 62
                self.match(RonParser.T__0)
                self.state = 64
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 130722) != 0):
                    self.state = 63
                    self.struct_body()


                self.state = 66
                self.match(RonParser.T__1)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Struct_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def named_fields(self):
            return self.getTypedRuleContext(RonParser.Named_fieldsContext,0)


        def unnamed_fields(self):
            return self.getTypedRuleContext(RonParser.Unnamed_fieldsContext,0)


        def getRuleIndex(self):
            return RonParser.RULE_struct_body

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStruct_body" ):
                return visitor.visitStruct_body(self)
            else:
                return visitor.visitChildren(self)




    def struct_body(self):

        localctx = RonParser.Struct_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_struct_body)
        try:
            self.state = 71
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 69
                self.named_fields()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 70
                self.unnamed_fields()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Named_fieldsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def named_field(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RonParser.Named_fieldContext)
            else:
                return self.getTypedRuleContext(RonParser.Named_fieldContext,i)


        def getRuleIndex(self):
            return RonParser.RULE_named_fields

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNamed_fields" ):
                return visitor.visitNamed_fields(self)
            else:
                return visitor.visitChildren(self)




    def named_fields(self):

        localctx = RonParser.Named_fieldsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_named_fields)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 73
            self.named_field()
            self.state = 78
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,6,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 74
                    self.match(RonParser.T__2)
                    self.state = 75
                    self.named_field() 
                self.state = 80
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,6,self._ctx)

            self.state = 82
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==3:
                self.state = 81
                self.match(RonParser.T__2)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Named_fieldContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(RonParser.IDENTIFIER, 0)

        def value(self):
            return self.getTypedRuleContext(RonParser.ValueContext,0)


        def getRuleIndex(self):
            return RonParser.RULE_named_field

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNamed_field" ):
                return visitor.visitNamed_field(self)
            else:
                return visitor.visitChildren(self)




    def named_field(self):

        localctx = RonParser.Named_fieldContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_named_field)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 84
            self.match(RonParser.IDENTIFIER)
            self.state = 85
            self.match(RonParser.T__3)
            self.state = 86
            self.value()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Unnamed_fieldsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RonParser.ValueContext)
            else:
                return self.getTypedRuleContext(RonParser.ValueContext,i)


        def getRuleIndex(self):
            return RonParser.RULE_unnamed_fields

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnnamed_fields" ):
                return visitor.visitUnnamed_fields(self)
            else:
                return visitor.visitChildren(self)




    def unnamed_fields(self):

        localctx = RonParser.Unnamed_fieldsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_unnamed_fields)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 88
            self.value()
            self.state = 93
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,8,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 89
                    self.match(RonParser.T__2)
                    self.state = 90
                    self.value() 
                self.state = 95
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,8,self._ctx)

            self.state = 97
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==3:
                self.state = 96
                self.match(RonParser.T__2)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ron_mapContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def map_entry(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RonParser.Map_entryContext)
            else:
                return self.getTypedRuleContext(RonParser.Map_entryContext,i)


        def getRuleIndex(self):
            return RonParser.RULE_ron_map

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRon_map" ):
                return visitor.visitRon_map(self)
            else:
                return visitor.visitChildren(self)




    def ron_map(self):

        localctx = RonParser.Ron_mapContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_ron_map)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 99
            self.match(RonParser.T__4)
            self.state = 111
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 130722) != 0):
                self.state = 100
                self.map_entry()
                self.state = 105
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,10,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 101
                        self.match(RonParser.T__2)
                        self.state = 102
                        self.map_entry() 
                    self.state = 107
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,10,self._ctx)

                self.state = 109
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==3:
                    self.state = 108
                    self.match(RonParser.T__2)




            self.state = 113
            self.match(RonParser.T__5)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Map_entryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RonParser.ValueContext)
            else:
                return self.getTypedRuleContext(RonParser.ValueContext,i)


        def getRuleIndex(self):
            return RonParser.RULE_map_entry

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMap_entry" ):
                return visitor.visitMap_entry(self)
            else:
                return visitor.visitChildren(self)




    def map_entry(self):

        localctx = RonParser.Map_entryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_map_entry)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 115
            self.value()
            self.state = 116
            self.match(RonParser.T__3)
            self.state = 117
            self.value()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ron_tupleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RonParser.ValueContext)
            else:
                return self.getTypedRuleContext(RonParser.ValueContext,i)


        def getRuleIndex(self):
            return RonParser.RULE_ron_tuple

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRon_tuple" ):
                return visitor.visitRon_tuple(self)
            else:
                return visitor.visitChildren(self)




    def ron_tuple(self):

        localctx = RonParser.Ron_tupleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_ron_tuple)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 119
            self.match(RonParser.T__0)
            self.state = 131
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 130722) != 0):
                self.state = 120
                self.value()
                self.state = 125
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,13,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 121
                        self.match(RonParser.T__2)
                        self.state = 122
                        self.value() 
                    self.state = 127
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,13,self._ctx)

                self.state = 129
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==3:
                    self.state = 128
                    self.match(RonParser.T__2)




            self.state = 133
            self.match(RonParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ron_listContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RonParser.ValueContext)
            else:
                return self.getTypedRuleContext(RonParser.ValueContext,i)


        def getRuleIndex(self):
            return RonParser.RULE_ron_list

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRon_list" ):
                return visitor.visitRon_list(self)
            else:
                return visitor.visitChildren(self)




    def ron_list(self):

        localctx = RonParser.Ron_listContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_ron_list)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 135
            self.match(RonParser.T__6)
            self.state = 147
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 130722) != 0):
                self.state = 136
                self.value()
                self.state = 141
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,16,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 137
                        self.match(RonParser.T__2)
                        self.state = 138
                        self.value() 
                    self.state = 143
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,16,self._ctx)

                self.state = 145
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==3:
                    self.state = 144
                    self.match(RonParser.T__2)




            self.state = 149
            self.match(RonParser.T__7)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





