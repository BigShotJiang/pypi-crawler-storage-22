"""
Ronin Casino Python SDK
A Python client for interacting with the Ronin Casino on ICP
"""

from .client import RoninCasino, CasinoError
from .coinflip import CoinFlipGame, CoinFlipError
from .poker import PokerClient, PokerError
from .types import (
    CoinSide,
    GameStatus,
    TableInfo,
    HealthStatus,
    LedgerStats,
    DepositInfo,
    TransferResult,
    RegisterResult,
    CommitResult,
    RevealResult,
    icp_to_e8s,
    e8s_to_icp,
)

__version__ = "0.2.0"
__all__ = [
    "RoninCasino",
    "CasinoError",
    "CoinFlipGame",
    "CoinFlipError",
    "PokerClient",
    "PokerError",
    "CoinSide",
    "GameStatus",
    "TableInfo",
    "HealthStatus",
    "LedgerStats",
    "DepositInfo",
    "TransferResult",
    "RegisterResult",
    "CommitResult",
    "RevealResult",
    "icp_to_e8s",
    "e8s_to_icp",
]
