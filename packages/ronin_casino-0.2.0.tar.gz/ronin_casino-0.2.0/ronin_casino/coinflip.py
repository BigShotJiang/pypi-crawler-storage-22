"""
Coin Flip game implementation with commit-reveal protocol via Candid calls.
"""

import hashlib
import os
import time
from typing import Optional, Tuple

from ic.candid import encode, Types

from .types import (
    CoinSide, CommitResult, RevealResult,
    decode_record, unwrap_variant, icp_to_e8s,
)


class CoinFlipGame:
    """
    Coin flip game client implementing the commit-reveal protocol.

    The commit-reveal protocol ensures provably fair gameplay:
    1. Player commits: hash(choice + nonce) + bet amount
    2. Wait for VRF block
    3. Player reveals: choice + nonce
    4. Casino verifies and determines outcome using VRF

    Example:
        casino = RoninCasino(identity_path="~/.ronin/agent.pem")
        game = casino.coinflip()
        result = game.play(CoinSide.HEADS, bet_icp=0.1)
        print(f"Won: {result.won}, Payout: {result.payout}")
    """

    def __init__(self, client):
        """Initialize with a RoninCasino client."""
        self.client = client

    @staticmethod
    def _generate_nonce() -> bytes:
        """Generate a cryptographically secure 32-byte nonce."""
        return os.urandom(32)

    @staticmethod
    def _create_commitment(choice: CoinSide, nonce: bytes) -> bytes:
        """
        Create a commitment hash for the choice.
        Format: SHA-256(choice_byte || nonce) where choice_byte is 0x00=heads, 0x01=tails.
        """
        choice_byte = b"\x00" if choice == CoinSide.HEADS else b"\x01"
        return hashlib.sha256(choice_byte + nonce).digest()

    def commit(
        self,
        choice: CoinSide,
        bet_e8s: int,
        nonce: Optional[bytes] = None,
    ) -> Tuple[CommitResult, bytes]:
        """
        Commit to a coin flip choice.

        Args:
            choice: The side to bet on (HEADS or TAILS)
            bet_e8s: Bet amount in e8s
            nonce: Optional nonce (generated if not provided)

        Returns:
            Tuple of (CommitResult, nonce)
        """
        if nonce is None:
            nonce = self._generate_nonce()

        choice_hash = self._create_commitment(choice, nonce)

        result = self.client._update("main", "coinflip_commit", [
            {"type": Types.Nat, "value": bet_e8s},
            {"type": Types.Vec(Types.Nat8), "value": list(choice_hash)},
        ])

        variant_label, variant_value = unwrap_variant(result[0]["value"])
        if variant_label == "ok":
            rec = variant_value if isinstance(variant_value, dict) else decode_record(variant_value)
            commit_result = CommitResult(
                commit_id=rec["commitId"],
                commit_block=rec["commitBlock"],
                reveal_after_block=rec["revealAfterBlock"],
                reveal_deadline=rec["revealDeadline"],
            )
            return commit_result, nonce
        else:
            raise CoinFlipError(f"Commit failed: {variant_value}")

    def reveal(
        self,
        commit_id: int,
        choice: CoinSide,
        nonce: bytes,
    ) -> RevealResult:
        """
        Reveal the committed choice and get the result.

        Args:
            commit_id: The commit ID from the commit step
            choice: The original choice
            nonce: The nonce used in commitment

        Returns:
            RevealResult with outcome
        """
        # Encode CoinSide as a Candid variant
        choice_variant = {"heads": None} if choice == CoinSide.HEADS else {"tails": None}

        result = self.client._update("main", "coinflip_reveal", [
            {"type": Types.Nat, "value": commit_id},
            {"type": Types.Variant({"heads": Types.Null, "tails": Types.Null}), "value": choice_variant},
            {"type": Types.Vec(Types.Nat8), "value": list(nonce)},
        ])

        variant_label, variant_value = unwrap_variant(result[0]["value"])
        if variant_label == "ok":
            rec = variant_value if isinstance(variant_value, dict) else decode_record(variant_value)
            # Parse the result coin side
            result_side_raw = rec.get("result", {})
            if isinstance(result_side_raw, dict):
                result_side = CoinSide.HEADS if "heads" in result_side_raw else CoinSide.TAILS
            else:
                result_side = CoinSide(result_side_raw) if isinstance(result_side_raw, str) else CoinSide.HEADS

            vrf = rec.get("vrfProof", b"")
            if isinstance(vrf, list):
                vrf = bytes(vrf)

            return RevealResult(
                game_id=rec["gameId"],
                result=result_side,
                won=rec["won"],
                payout=rec["payout"],
                vrf_proof=vrf,
            )
        else:
            raise CoinFlipError(f"Reveal failed: {variant_value}")

    def play(
        self,
        choice: CoinSide,
        bet_e8s: Optional[int] = None,
        bet_icp: Optional[float] = None,
        wait_seconds: float = 4.0,
    ) -> RevealResult:
        """
        Play a complete coin flip game (commit, wait, reveal).

        Args:
            choice: The side to bet on (HEADS or TAILS)
            bet_e8s: Bet amount in e8s (use this OR bet_icp)
            bet_icp: Bet amount in ICP (use this OR bet_e8s)
            wait_seconds: Seconds to wait before reveal (default 4 — ~2 ICP blocks)

        Returns:
            RevealResult with outcome

        Example:
            result = game.play(CoinSide.HEADS, bet_icp=0.1)
            if result.won:
                print(f"Won {result.payout / 1e8} ICP!")
        """
        if bet_e8s is None and bet_icp is None:
            raise ValueError("Must specify bet_e8s or bet_icp")

        if bet_icp is not None:
            bet_e8s = icp_to_e8s(bet_icp)

        # Step 1: Commit
        commit_result, nonce = self.commit(choice, bet_e8s)

        # Step 2: Wait for VRF block
        time.sleep(wait_seconds)

        # Step 3: Reveal
        return self.reveal(commit_result.commit_id, choice, nonce)

    # ------------------------------------------------------------------
    # Read-only queries (HTTP — fast)
    # ------------------------------------------------------------------

    def get_game(self, game_id: int) -> dict:
        """Get details of a specific game via Candid query."""
        result = self.client._query("main", "get_game", [
            {"type": Types.Nat, "value": game_id}
        ])
        if result and result[0]["value"]:
            return decode_record(result[0]["value"][0])
        return {}

    def get_history(self, limit: int = 10, offset: int = 0) -> list:
        """Get recent game history for the current agent."""
        result = self.client._query("main", "get_game_history", [
            {"type": Types.Principal, "value": self.client.principal.bytes},
            {"type": Types.Nat, "value": limit},
            {"type": Types.Nat, "value": offset},
        ])
        if result and result[0]["value"]:
            return [decode_record(g) for g in result[0]["value"]]
        return []

    def health(self) -> dict:
        """Quick health check via HTTP."""
        return self.client._http_get(self.client.HTTP_MAIN, "/api/health")


class CoinFlipError(Exception):
    """Exception raised for coin flip game errors."""
    pass
