#!/usr/bin/env python3
"""
Example: LangChain Tool for Ronin Casino

This script shows how to integrate Ronin Casino with LangChain
for building AI agents that can play casino games.
"""

from typing import Optional, Type
from pydantic import BaseModel, Field

# Note: Requires langchain to be installed
# pip install langchain langchain-openai

try:
    from langchain.tools import BaseTool
    from langchain.callbacks.manager import CallbackManagerForToolRun
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False
    print("LangChain not installed. Run: pip install langchain")

from ronin_casino import RoninCasino, CoinSide
from ronin_casino.types import e8s_to_icp


class CoinFlipInput(BaseModel):
    """Input schema for coin flip tool."""
    choice: str = Field(description="The side to bet on: 'heads' or 'tails'")
    bet_icp: float = Field(description="Amount to bet in ICP (e.g., 0.01)")


if LANGCHAIN_AVAILABLE:
    class RoninCoinFlipTool(BaseTool):
        """LangChain tool for playing coin flip on Ronin Casino."""

        name: str = "ronin_coinflip"
        description: str = """Play a provably fair coin flip game on Ronin Casino.
        Choose 'heads' or 'tails' and specify a bet amount in ICP.
        Returns whether you won and your payout."""
        args_schema: Type[BaseModel] = CoinFlipInput

        api_key: str = ""
        casino: Optional[RoninCasino] = None

        def __init__(self, api_key: str):
            super().__init__()
            self.api_key = api_key
            self.casino = RoninCasino(api_key=api_key)

        def _run(
            self,
            choice: str,
            bet_icp: float,
            run_manager: Optional[CallbackManagerForToolRun] = None
        ) -> str:
            """Execute the coin flip."""
            try:
                # Parse choice
                if choice.lower() == "heads":
                    side = CoinSide.HEADS
                elif choice.lower() == "tails":
                    side = CoinSide.TAILS
                else:
                    return f"Invalid choice '{choice}'. Must be 'heads' or 'tails'."

                # Check balance
                balance = self.casino.balance()
                bet_e8s = int(bet_icp * 100_000_000)

                if balance < bet_e8s:
                    return f"Insufficient balance. You have {e8s_to_icp(balance):.4f} ICP."

                # Play the game
                game = self.casino.coinflip()
                result = game.play(choice=side, bet_icp=bet_icp)

                if result.won:
                    return (f"You won! The coin landed on {result.result.value}. "
                           f"Payout: {e8s_to_icp(result.payout):.4f} ICP")
                else:
                    return (f"You lost. The coin landed on {result.result.value}. "
                           f"Better luck next time!")

            except Exception as e:
                return f"Error playing coin flip: {str(e)}"

        async def _arun(
            self,
            choice: str,
            bet_icp: float,
            run_manager: Optional[CallbackManagerForToolRun] = None
        ) -> str:
            """Async version - just calls sync for now."""
            return self._run(choice, bet_icp, run_manager)


    class RoninBalanceTool(BaseTool):
        """LangChain tool for checking Ronin Casino balance."""

        name: str = "ronin_balance"
        description: str = "Check your current balance on Ronin Casino. Returns balance in ICP."

        api_key: str = ""
        casino: Optional[RoninCasino] = None

        def __init__(self, api_key: str):
            super().__init__()
            self.api_key = api_key
            self.casino = RoninCasino(api_key=api_key)

        def _run(
            self,
            run_manager: Optional[CallbackManagerForToolRun] = None
        ) -> str:
            """Check balance."""
            try:
                balance = self.casino.balance()
                return f"Your balance is {e8s_to_icp(balance):.4f} ICP"
            except Exception as e:
                return f"Error checking balance: {str(e)}"

        async def _arun(
            self,
            run_manager: Optional[CallbackManagerForToolRun] = None
        ) -> str:
            return self._run(run_manager)


def create_casino_agent(api_key: str, openai_api_key: str):
    """
    Create a LangChain agent with Ronin Casino tools.

    Args:
        api_key: Ronin Casino API key
        openai_api_key: OpenAI API key for the LLM

    Returns:
        LangChain agent executor
    """
    if not LANGCHAIN_AVAILABLE:
        raise ImportError("LangChain not installed")

    from langchain_openai import ChatOpenAI
    from langchain.agents import AgentExecutor, create_openai_tools_agent
    from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder

    # Create tools
    tools = [
        RoninCoinFlipTool(api_key=api_key),
        RoninBalanceTool(api_key=api_key),
    ]

    # Create LLM
    llm = ChatOpenAI(
        model="gpt-4",
        temperature=0,
        openai_api_key=openai_api_key
    )

    # Create prompt
    prompt = ChatPromptTemplate.from_messages([
        ("system", """You are a gambling AI agent that can play games on Ronin Casino.
        You can check your balance and play coin flip games.
        Be responsible and don't bet more than you can afford to lose.
        Always check your balance before betting."""),
        ("human", "{input}"),
        MessagesPlaceholder(variable_name="agent_scratchpad"),
    ])

    # Create agent
    agent = create_openai_tools_agent(llm, tools, prompt)
    return AgentExecutor(agent=agent, tools=tools, verbose=True)


# Example usage
if __name__ == "__main__":
    if not LANGCHAIN_AVAILABLE:
        print("Install LangChain to run this example:")
        print("  pip install langchain langchain-openai")
        exit(1)

    # Replace with your actual keys
    RONIN_API_KEY = "YOUR_RONIN_API_KEY"
    OPENAI_API_KEY = "YOUR_OPENAI_API_KEY"

    agent = create_casino_agent(RONIN_API_KEY, OPENAI_API_KEY)

    # Run the agent
    result = agent.invoke({
        "input": "Check my balance and then play a small coin flip betting on heads"
    })
    print(result)
