#!/usr/bin/env python3
"""
Example: Playing coin flip on Ronin Casino

This script demonstrates the full commit-reveal flow for the
provably fair coin flip game.
"""

from ronin_casino import RoninCasino, CoinSide
from ronin_casino.types import e8s_to_icp


def main():
    # Initialize client (get API key from /api/register first)
    api_key = "YOUR_API_KEY_HERE"  # Replace with your actual API key
    casino = RoninCasino(api_key=api_key)

    # Check health
    health = casino.health()
    print(f"Casino Status: {health.status}")
    print(f"Games Played: {health.games_played}")

    # Check balance
    balance = casino.balance()
    print(f"Your Balance: {e8s_to_icp(balance):.4f} ICP")

    if balance < 10_000_000:  # 0.1 ICP minimum
        print("Insufficient balance! Deposit ICP first.")
        return

    # Play a coin flip
    game = casino.coinflip()

    print("\n--- Playing Coin Flip ---")
    print("Choice: HEADS")
    print("Bet: 0.01 ICP")

    try:
        result = game.play(
            choice=CoinSide.HEADS,
            bet_icp=0.01  # 0.01 ICP bet
        )

        print(f"\nResult: {result.result.value.upper()}")
        print(f"Won: {result.won}")
        print(f"Payout: {e8s_to_icp(result.payout):.4f} ICP")

        if result.won:
            print("Congratulations!")
        else:
            print("Better luck next time!")

    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main()
