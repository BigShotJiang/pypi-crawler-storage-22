"""
Poker client for Ronin Casino — Candid calls for transactions, HTTP for reads.
"""

from typing import Optional, List, Dict, Any

from ic.candid import encode, Types

from .types import (
    TableInfo, Stakes, Seat, TableStatus, SeatStatus,
    decode_record, unwrap_variant, icp_to_e8s,
)


class PokerClient:
    """
    Client for poker operations on Ronin Casino.

    Example:
        casino = RoninCasino(identity_path="~/.ronin/agent.pem")
        poker = casino.poker()
        tables = poker.get_tables()
        for t in tables:
            print(f"{t.name}: {t.stakes.name}")
    """

    def __init__(self, client):
        """Initialize with a RoninCasino client."""
        self.client = client

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _parse_table_http(self, data: Dict) -> TableInfo:
        """Parse table data from HTTP response into TableInfo."""
        stakes_data = data.get("stakes", {})
        stakes = Stakes(
            small_blind=stakes_data.get("smallBlind", 0),
            big_blind=stakes_data.get("bigBlind", 0),
            min_buy_in=stakes_data.get("minBuyIn", 0),
            max_buy_in=stakes_data.get("maxBuyIn", 0),
            name=stakes_data.get("name", "unknown"),
        )

        seats = []
        for seat_data in data.get("seats", []):
            seat = Seat(
                position=seat_data.get("position", 0),
                player=seat_data.get("player"),
                stack=seat_data.get("stack", 0),
                status=SeatStatus(seat_data.get("status", "empty")),
                current_bet=seat_data.get("currentBet", 0),
                is_all_in=seat_data.get("isAllIn", False),
            )
            seats.append(seat)

        status_str = data.get("status", "waiting")
        try:
            status = TableStatus(status_str)
        except ValueError:
            status = TableStatus.WAITING

        return TableInfo(
            id=data.get("id", 0),
            name=data.get("name", ""),
            stakes=stakes,
            max_players=data.get("maxPlayers", 6),
            seats=seats,
            status=status,
            dealer_button=data.get("dealerButton", 0),
            current_hand_id=data.get("currentHandId"),
            hands_played=data.get("handsPlayed", 0),
        )

    # ------------------------------------------------------------------
    # Read-only queries (HTTP — fast)
    # ------------------------------------------------------------------

    def get_tables(self) -> List[TableInfo]:
        """Get list of available poker tables via HTTP."""
        data = self.client._http_get(self.client.HTTP_POKER, "/api/tables")
        table_list = data if isinstance(data, list) else data.get("tables", [])
        return [self._parse_table_http(t) for t in table_list]

    def get_table(self, table_id: int) -> TableInfo:
        """Get details of a specific table via HTTP."""
        data = self.client._http_get(self.client.HTTP_POKER, f"/api/tables/{table_id}")
        return self._parse_table_http(data)

    def get_hand(self, table_id: int) -> Dict[str, Any]:
        """Get current hand state (uses Candid shared query for private cards)."""
        result = self.client._query("poker", "get_hand_state", [
            {"type": Types.Nat, "value": table_id},
        ])
        if result and result[0]["value"]:
            return decode_record(result[0]["value"][0])
        return {}

    # ------------------------------------------------------------------
    # Transactional calls (Candid — update calls)
    # ------------------------------------------------------------------

    def sit(
        self,
        table_id: int,
        seat_position: int,
        buy_in_e8s: Optional[int] = None,
        buy_in_icp: Optional[float] = None,
    ) -> None:
        """
        Sit at a poker table.

        Args:
            table_id: The table to join
            seat_position: Seat number (0-indexed)
            buy_in_e8s: Buy-in amount in e8s
            buy_in_icp: Buy-in amount in ICP

        Raises:
            PokerError: If sitting fails.
        """
        if buy_in_e8s is None and buy_in_icp is None:
            raise ValueError("Must specify buy_in_e8s or buy_in_icp")

        if buy_in_icp is not None:
            buy_in_e8s = icp_to_e8s(buy_in_icp)

        result = self.client._update("poker", "sit", [
            {"type": Types.Nat, "value": table_id},
            {"type": Types.Nat, "value": seat_position},
            {"type": Types.Nat, "value": buy_in_e8s},
        ])

        variant_label, variant_value = unwrap_variant(result[0]["value"])
        if variant_label == "err":
            raise PokerError(f"Sit failed: {variant_value}")

    def leave(self, table_id: int) -> int:
        """
        Leave a poker table.

        Args:
            table_id: The table to leave

        Returns:
            Returned stack in e8s.

        Raises:
            PokerError: If leaving fails.
        """
        result = self.client._update("poker", "leave", [
            {"type": Types.Nat, "value": table_id},
        ])

        variant_label, variant_value = unwrap_variant(result[0]["value"])
        if variant_label == "ok":
            return variant_value  # returned stack e8s
        else:
            raise PokerError(f"Leave failed: {variant_value}")

    def rebuy(self, table_id: int, amount_e8s: int) -> int:
        """
        Rebuy at a poker table.

        Returns:
            New stack in e8s.
        """
        result = self.client._update("poker", "rebuy", [
            {"type": Types.Nat, "value": table_id},
            {"type": Types.Nat, "value": amount_e8s},
        ])

        variant_label, variant_value = unwrap_variant(result[0]["value"])
        if variant_label == "ok":
            return variant_value
        else:
            raise PokerError(f"Rebuy failed: {variant_value}")

    def _action(self, table_id: int, player_action: dict) -> None:
        """Send a player action to the poker canister."""
        result = self.client._update("poker", "action", [
            {"type": Types.Nat, "value": table_id},
            {"type": Types.Variant({
                "fold": Types.Null,
                "check": Types.Null,
                "call": Types.Null,
                "bet": Types.Nat,
                "raise": Types.Nat,
                "allIn": Types.Null,
            }), "value": player_action},
        ])

        variant_label, variant_value = unwrap_variant(result[0]["value"])
        if variant_label == "err":
            raise PokerError(f"Action failed: {variant_value}")

    def fold(self, table_id: int) -> None:
        """Fold current hand."""
        self._action(table_id, {"fold": None})

    def check(self, table_id: int) -> None:
        """Check (if no bet to call)."""
        self._action(table_id, {"check": None})

    def call(self, table_id: int) -> None:
        """Call the current bet."""
        self._action(table_id, {"call": None})

    def bet(self, table_id: int, amount_e8s: int) -> None:
        """Place a bet."""
        self._action(table_id, {"bet": amount_e8s})

    def raise_bet(self, table_id: int, amount_e8s: int) -> None:
        """Raise the current bet."""
        self._action(table_id, {"raise": amount_e8s})

    def all_in(self, table_id: int) -> None:
        """Go all-in."""
        self._action(table_id, {"allIn": None})

    def join_waitlist(self, stakes_level: str) -> int:
        """Join the waitlist for a stakes level. Returns position."""
        result = self.client._update("poker", "join_waitlist", [
            {"type": Types.Text, "value": stakes_level},
        ])
        variant_label, variant_value = unwrap_variant(result[0]["value"])
        if variant_label == "ok":
            return variant_value
        else:
            raise PokerError(f"Join waitlist failed: {variant_value}")

    def leave_waitlist(self, stakes_level: str) -> None:
        """Leave the waitlist for a stakes level."""
        self.client._update("poker", "leave_waitlist", [
            {"type": Types.Text, "value": stakes_level},
        ])


class PokerError(Exception):
    """Exception raised for poker errors."""
    pass
