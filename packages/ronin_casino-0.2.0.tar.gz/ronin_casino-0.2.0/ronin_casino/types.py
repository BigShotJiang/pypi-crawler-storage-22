"""
Type definitions for Ronin Casino SDK
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional, List


# ---------------------------------------------------------------------------
# Candid field-name hash helper
# ic-py returns record fields as "_<hash>" keys. This mapping lets us convert
# them back to human-readable names.
# ---------------------------------------------------------------------------

def _candid_hash(name: str) -> int:
    """Compute the Candid IDL hash for a record field name."""
    h = 0
    for c in name:
        h = (h * 223 + ord(c)) & 0xFFFFFFFF
    return h


# Pre-computed mapping of hash -> field name for all fields we care about
_FIELD_NAMES = [
    "status", "gamesPlayed", "openChallenges",
    "houseBalance", "totalDeposited", "totalWithdrawn", "activeAgents",
    "commitId", "commitBlock", "revealAfterBlock", "revealDeadline",
    "gameId", "result", "won", "payout", "vrfProof",
    "ok", "err", "blockIndex",
    "owner", "subaccount", "subaccountHex",
    "apiKey", "expiresAt", "agentId", "scope",
    "fee", "feeIcp", "totalCollected", "ledgerConfigured",
    "amount", "player", "choiceHash", "choice", "id",
    "insufficientBalance", "belowMinimum", "invalidAddress",
    "transferFailed", "unauthorized",
    "name", "maxPlayers", "seats", "dealerButton", "currentHandId",
    "handsPlayed", "smallBlind", "bigBlind", "minBuyIn", "maxBuyIn",
    "stakesLevel", "playerCount", "tableId",
    "handId", "street", "yourCards", "board", "pot", "currentBet",
    "toAct", "validActions", "players",
    "position", "stack", "hasFolded", "isAllIn", "seatPosition",
    "retryAfter", "allowed", "remaining", "resetIn",
]

CANDID_FIELD_MAP = {f"_{_candid_hash(n)}": n for n in _FIELD_NAMES}


def decode_record(raw: dict) -> dict:
    """Convert an ic-py record with hashed field names to readable names."""
    out = {}
    for k, v in raw.items():
        readable = CANDID_FIELD_MAP.get(k, k)
        if isinstance(v, dict):
            v = decode_record(v)
        out[readable] = v
    return out


def unwrap_variant(raw: dict) -> tuple:
    """
    Unwrap a Candid variant from ic-py decoded result.
    Returns (variant_label, value).
    e.g. {'_24860': {...}} -> ('ok', {...})
    """
    for k, v in raw.items():
        label = CANDID_FIELD_MAP.get(k, k)
        if isinstance(v, dict):
            v = decode_record(v)
        return label, v
    return None, None


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class CoinSide(Enum):
    HEADS = "heads"
    TAILS = "tails"


class GameStatus(Enum):
    COMMITTED = "committed"
    REVEALED = "revealed"
    COMPLETED = "completed"
    EXPIRED = "expired"
    CANCELLED = "cancelled"


class TableStatus(Enum):
    WAITING = "waiting"
    STARTING = "starting"
    PLAYING = "playing"
    PAUSED = "paused"


class SeatStatus(Enum):
    EMPTY = "empty"
    ACTIVE = "active"
    SITTING_OUT = "sittingOut"
    LEAVING = "leaving"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class Stakes:
    small_blind: int
    big_blind: int
    min_buy_in: int
    max_buy_in: int
    name: str


@dataclass
class Seat:
    position: int
    player: Optional[str]
    stack: int
    status: SeatStatus
    current_bet: int
    is_all_in: bool


@dataclass
class TableInfo:
    id: int
    name: str
    stakes: Stakes
    max_players: int
    seats: List[Seat]
    status: TableStatus
    dealer_button: int
    current_hand_id: Optional[int]
    hands_played: int


@dataclass
class CommitResult:
    commit_id: int
    commit_block: int
    reveal_after_block: int
    reveal_deadline: int


@dataclass
class RevealResult:
    game_id: int
    result: CoinSide
    won: bool
    payout: int
    vrf_proof: bytes


@dataclass
class HealthStatus:
    status: str
    games_played: int
    open_challenges: int


@dataclass
class LedgerStats:
    house_balance: int
    total_deposited: int
    total_withdrawn: int
    active_agents: int


@dataclass
class DepositInfo:
    owner: str
    subaccount: bytes
    subaccount_hex: str


@dataclass
class TransferResult:
    success: bool
    block_index: Optional[int] = None
    error: Optional[str] = None


@dataclass
class RegisterResult:
    api_key: str
    expires_at: int


# ---------------------------------------------------------------------------
# E8s conversion helpers
# ---------------------------------------------------------------------------

E8S_PER_ICP = 100_000_000


def icp_to_e8s(icp: float) -> int:
    """Convert ICP to e8s"""
    return int(icp * E8S_PER_ICP)


def e8s_to_icp(e8s: int) -> float:
    """Convert e8s to ICP"""
    return e8s / E8S_PER_ICP
