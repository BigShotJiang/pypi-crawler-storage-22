"""
Main Ronin Casino client — uses ic-py for on-chain transactions,
HTTP for fast read-only queries.
"""

import os
import requests
from typing import Optional, Dict, Any

from ic.agent import Agent
from ic.identity import Identity
from ic.client import Client
from ic.candid import encode, Types
from ic.principal import Principal

from .types import (
    HealthStatus, LedgerStats, DepositInfo, TransferResult, RegisterResult,
    decode_record, unwrap_variant, e8s_to_icp,
)


class RoninCasino:
    """
    Main client for interacting with Ronin Casino on ICP.

    Uses ic-py (Candid calls) for transactions and HTTP for read-only queries.

    Example:
        casino = RoninCasino(identity_path="~/.ronin/agent.pem")
        print(f"Principal: {casino.principal}")
        print(f"Health: {casino.health()}")
    """

    # Mainnet canister IDs
    CANISTER_IDS = {
        "main": "xt3gy-gqaaa-aaaab-aegga-cai",
        "poker": "xu2am-liaaa-aaaab-aeggq-cai",
        "ledger": "xg4xv-hyaaa-aaaab-aegfq-cai",
        "rng": "x5zlq-5aaaa-aaaab-aegha-cai",
        "auth": "xi625-4iaaa-aaaab-aegeq-cai",
        "frontend": "xb5rb-kaaaa-aaaab-aegfa-cai",
    }

    # Raw HTTP URLs (for fast read-only queries)
    HTTP_MAIN = "https://xt3gy-gqaaa-aaaab-aegga-cai.raw.icp0.io"
    HTTP_POKER = "https://xu2am-liaaa-aaaab-aeggq-cai.raw.icp0.io"

    def __init__(
        self,
        identity_path: Optional[str] = None,
        ic_url: str = "https://ic0.app",
        timeout: int = 30,
    ):
        """
        Initialize the Ronin Casino client.

        Args:
            identity_path: Path to PEM file for agent identity.
                           If None, a new random identity is created (not persisted).
                           If the file doesn't exist, a new identity is created and saved.
            ic_url: IC network URL (default: mainnet).
            timeout: HTTP request timeout in seconds.
        """
        self.timeout = timeout

        # --- Identity ---
        identity_path = os.path.expanduser(identity_path) if identity_path else None

        if identity_path and os.path.exists(identity_path):
            with open(identity_path, "rb") as f:
                self.identity = Identity.from_pem(f.read())
        else:
            self.identity = Identity()
            if identity_path:
                os.makedirs(os.path.dirname(identity_path) or ".", exist_ok=True)
                pem_data = self.identity.to_pem()
                mode = "wb" if isinstance(pem_data, bytes) else "w"
                with open(identity_path, mode) as f:
                    f.write(pem_data)
                os.chmod(identity_path, 0o600)

        # --- ic-py Agent ---
        self._ic_client = Client(url=ic_url)
        self._agent = Agent(self.identity, self._ic_client)
        self.principal = self.identity.sender()

        # --- HTTP session (for read-only queries) ---
        self._http = requests.Session()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _query(self, canister: str, method: str, args=None) -> list:
        """Execute a query call and return decoded results."""
        raw = self._agent.query_raw(
            self.CANISTER_IDS[canister],
            method,
            encode(args or []),
        )
        return raw

    def _update(self, canister: str, method: str, args=None) -> list:
        """Execute an update call and return decoded results."""
        raw = self._agent.update_raw(
            self.CANISTER_IDS[canister],
            method,
            encode(args or []),
        )
        return raw

    def _http_get(self, base_url: str, endpoint: str) -> Dict[str, Any]:
        """Fast HTTP GET for read-only data."""
        url = f"{base_url}{endpoint}"
        try:
            response = self._http.get(url, timeout=self.timeout)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            raise CasinoError(f"HTTP request failed: {e}")

    # ------------------------------------------------------------------
    # Read-only queries (HTTP — fast)
    # ------------------------------------------------------------------

    def health(self) -> HealthStatus:
        """Check casino health status via HTTP."""
        data = self._http_get(self.HTTP_MAIN, "/api/health")
        return HealthStatus(
            status=data.get("status", "unknown"),
            games_played=data.get("gamesPlayed", 0),
            open_challenges=data.get("openChallenges", 0),
        )

    def get_stats(self) -> LedgerStats:
        """Get casino statistics via Candid query."""
        result = self._query("ledger", "get_stats")
        rec = decode_record(result[0]["value"])
        return LedgerStats(
            house_balance=rec["houseBalance"],
            total_deposited=rec["totalDeposited"],
            total_withdrawn=rec["totalWithdrawn"],
            active_agents=rec["activeAgents"],
        )

    # ------------------------------------------------------------------
    # Balance queries (Candid — uses your principal)
    # ------------------------------------------------------------------

    def balance(self) -> int:
        """
        Get the current agent's balance in e8s.

        Returns:
            Balance in e8s (1 ICP = 100_000_000 e8s)
        """
        result = self._query("ledger", "balance_of", [
            {"type": Types.Principal, "value": self.principal.bytes}
        ])
        return result[0]["value"]

    def balance_icp(self) -> float:
        """Get the current agent's balance in ICP."""
        return e8s_to_icp(self.balance())

    def house_balance(self) -> int:
        """Get the house balance in e8s."""
        result = self._query("ledger", "house_balance")
        return result[0]["value"]

    def house_balance_icp(self) -> float:
        """Get the house balance in ICP."""
        return e8s_to_icp(self.house_balance())

    # ------------------------------------------------------------------
    # Registration & deposit (Candid update calls)
    # ------------------------------------------------------------------

    def get_deposit_address(self) -> DepositInfo:
        """
        Get the deposit address for this agent.
        Send ICP to this address before calling process_deposit().

        Returns:
            DepositInfo with owner principal and subaccount.
        """
        result = self._update("ledger", "deposit")
        rec = decode_record(result[0]["value"])
        return DepositInfo(
            owner=str(rec.get("owner", "")),
            subaccount=rec.get("subaccount", b""),
            subaccount_hex=rec.get("subaccountHex", ""),
        )

    def process_deposit(self) -> TransferResult:
        """
        Check for and process any pending ICP deposits.

        Returns:
            TransferResult with block_index on success.
        """
        result = self._update("ledger", "process_deposit")
        variant_label, variant_value = unwrap_variant(result[0]["value"])
        if variant_label == "ok":
            return TransferResult(
                success=True,
                block_index=variant_value.get("blockIndex") if isinstance(variant_value, dict) else variant_value,
            )
        else:
            return TransferResult(success=False, error=str(variant_value))

    _SCOPE_VARIANT = Types.Variant({
        "betOnly": Types.Null,
        "fullAccess": Types.Null,
        "readOnly": Types.Null,
    })

    def register(self, name: str, scope: str = "fullAccess") -> RegisterResult:
        """
        Register as an agent (costs 0.25 ICP — must deposit first).

        Args:
            name: Display name for the agent.
            scope: Permission scope — "fullAccess", "betOnly", or "readOnly".

        Returns:
            RegisterResult with api_key and expires_at.

        Raises:
            CasinoError: If registration fails.
        """
        valid_scopes = ("betOnly", "fullAccess", "readOnly")
        if scope not in valid_scopes:
            raise ValueError(f"scope must be one of {valid_scopes}, got {scope!r}")

        result = self._update("auth", "request_api_key", [
            {"type": Types.Text, "value": name},
            {"type": self._SCOPE_VARIANT, "value": {scope: None}},
        ])
        variant_label, variant_value = unwrap_variant(result[0]["value"])
        if variant_label == "ok":
            return RegisterResult(
                api_key=variant_value.get("apiKey", ""),
                expires_at=variant_value.get("expiresAt", 0),
            )
        else:
            raise CasinoError(f"Registration failed: {variant_value}")

    def withdraw(self, amount_e8s: int, to_principal: Optional[str] = None) -> TransferResult:
        """
        Withdraw ICP from your casino balance.

        Args:
            amount_e8s: Amount to withdraw in e8s.
            to_principal: Destination principal (default: self).

        Returns:
            TransferResult with block_index on success.
        """
        args = [{"type": Types.Nat, "value": amount_e8s}]
        if to_principal:
            p = Principal.from_str(to_principal)
            args.append({"type": Types.Opt, "value": [{"type": Types.Principal, "value": p.bytes}]})
        else:
            args.append({"type": Types.Opt, "value": []})

        result = self._update("ledger", "withdraw", args)
        variant_label, variant_value = unwrap_variant(result[0]["value"])
        if variant_label == "ok":
            return TransferResult(
                success=True,
                block_index=variant_value.get("blockIndex") if isinstance(variant_value, dict) else variant_value,
            )
        else:
            return TransferResult(success=False, error=str(variant_value))

    # ------------------------------------------------------------------
    # Game sub-clients
    # ------------------------------------------------------------------

    def coinflip(self):
        """Get a CoinFlipGame client for playing coin flip."""
        from .coinflip import CoinFlipGame
        return CoinFlipGame(self)

    def poker(self):
        """Get a PokerClient for poker operations."""
        from .poker import PokerClient
        return PokerClient(self)


class CasinoError(Exception):
    """Exception raised for casino errors."""
    pass
