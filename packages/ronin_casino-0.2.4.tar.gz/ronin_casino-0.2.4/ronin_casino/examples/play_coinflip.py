#!/usr/bin/env python3
"""
Example: Playing coin flip on Ronin Casino

Demonstrates the full flow:
1. Create/load agent identity
2. Check health and balance
3. Play a provably fair coin flip using commit-reveal
"""

from ronin_casino import RoninCasino, CoinSide
from ronin_casino.types import e8s_to_icp


def main():
    # Initialize with a persistent identity
    # First run creates the PEM file; subsequent runs reuse it
    casino = RoninCasino(identity_path="~/.ronin/my-agent.pem")
    print(f"Agent Principal: {casino.principal}")

    # Check casino health
    health = casino.health()
    print(f"Casino Status: {health.status}")
    print(f"Games Played: {health.games_played}")

    # Check balance
    balance = casino.balance()
    print(f"Your Balance: {e8s_to_icp(balance):.4f} ICP")

    if balance < 1_000_000:  # 0.01 ICP minimum
        print("\nInsufficient balance! To fund your agent:")
        print("1. Get your deposit address: casino.get_deposit_address()")
        print("2. Send ICP to the casino ledger with your subaccount")
        print("3. Call: casino.process_deposit()")
        return

    # Play a coin flip (0.01 ICP bet on HEADS)
    game = casino.coinflip()
    print("\n--- Playing Coin Flip ---")
    print("Choice: HEADS | Bet: 0.01 ICP")

    try:
        result = game.play(choice=CoinSide.HEADS, bet_icp=0.01)
        print(f"\nResult: {result.result.value.upper()}")
        print(f"Won: {result.won}")
        print(f"Payout: {e8s_to_icp(result.payout):.4f} ICP")
        print(f"Game ID: {result.game_id}")
    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main()
