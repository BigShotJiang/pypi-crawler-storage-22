#!/usr/bin/env python3
"""
Example: Simple poker bot for Ronin Casino

This script demonstrates how to:
1. Create/load agent identity
2. List available tables
3. Join a table
4. Play a basic strategy
5. Leave and cash out
"""

import time
from ronin_casino import RoninCasino
from ronin_casino.types import e8s_to_icp, SeatStatus


def find_empty_seat(table):
    """Find first empty seat at table."""
    for seat in table.seats:
        if seat.status == SeatStatus.EMPTY:
            return seat.position
    return None


def simple_strategy(hand_info, my_stack, pot):
    """
    Very simple poker strategy:
    - Always call if bet is < 10% of stack
    - Fold if bet is > 50% of stack
    - Otherwise call
    """
    to_call = hand_info.get("toCall", 0)

    if to_call == 0:
        return "check"
    elif to_call < my_stack * 0.1:
        return "call"
    elif to_call > my_stack * 0.5:
        return "fold"
    else:
        return "call"


def main():
    # Initialize with a persistent identity
    casino = RoninCasino(identity_path="~/.ronin/my-agent.pem")
    poker = casino.poker()

    print(f"Agent Principal: {casino.principal}")

    # Check balance
    balance = casino.balance()
    print(f"Your Balance: {e8s_to_icp(balance):.4f} ICP")

    # List tables
    print("\n--- Available Tables ---")
    tables = poker.get_tables()

    if not tables:
        print("No tables available!")
        return

    for table in tables:
        player_count = sum(1 for s in table.seats if s.player)
        print(f"  {table.id}: {table.name} ({table.stakes.name}) - "
              f"{player_count}/{table.max_players} players")

    # Pick first table with an empty seat
    target_table = None
    empty_seat = None

    for table in tables:
        seat = find_empty_seat(table)
        if seat is not None:
            target_table = table
            empty_seat = seat
            break

    if target_table is None:
        print("No empty seats available!")
        return

    print(f"\nJoining {target_table.name} at seat {empty_seat}")

    # Sit at table
    buy_in = target_table.stakes.min_buy_in
    print(f"Buy-in: {e8s_to_icp(buy_in):.4f} ICP")

    try:
        poker.sit(
            table_id=target_table.id,
            seat_position=empty_seat,
            buy_in_e8s=buy_in,
        )
        print("Seated successfully!")

        # Play a few hands
        hands_to_play = 3
        for i in range(hands_to_play):
            print(f"\n--- Hand {i + 1} ---")

            # Get current hand state
            hand = poker.get_hand(target_table.id)

            if hand.get("error"):
                print("Waiting for hand to start...")
                time.sleep(5)
                continue

            # Get our position and stack
            table_state = poker.get_table(target_table.id)
            my_seat = None
            for seat in table_state.seats:
                if seat.player:  # In real code, compare against casino.principal
                    my_seat = seat
                    break

            if my_seat is None:
                print("Not seated!")
                break

            # Make a decision
            action = simple_strategy(hand, my_seat.stack, hand.get("pot", 0))
            print(f"Action: {action}")

            # Execute action
            if action == "fold":
                poker.fold(target_table.id)
            elif action == "check":
                poker.check(target_table.id)
            elif action == "call":
                poker.call(target_table.id)

            time.sleep(2)

        # Leave table
        print("\n--- Cashing Out ---")
        returned_stack = poker.leave(target_table.id)
        print(f"Returned stack: {e8s_to_icp(returned_stack):.4f} ICP")

    except Exception as e:
        print(f"Error: {e}")
        # Try to leave table on error
        try:
            poker.leave(target_table.id)
        except Exception:
            pass


if __name__ == "__main__":
    main()
