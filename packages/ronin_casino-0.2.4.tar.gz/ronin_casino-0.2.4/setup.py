#!/usr/bin/env python3
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ronin-casino",
    version="0.2.4",
    author="Ronin Casino",
    author_email="dev@ronincasino.io",
    description="Python SDK for Ronin Casino on ICP",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ronin-casino/sdk-python",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.25.0",
        "ic-py>=1.0.0",
    ],
    extras_require={
        "langchain": ["langchain>=0.1.0", "langchain-openai>=0.0.5"],
        "dev": ["pytest>=7.0.0", "black", "mypy"],
    },
)
