"""SendGrid provider."""

from roomkit.providers.sendgrid.config import SendGridConfig

__all__ = ["SendGridConfig"]
