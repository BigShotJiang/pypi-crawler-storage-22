"""SendGrid provider configuration."""

from __future__ import annotations

from pydantic import BaseModel, SecretStr


class SendGridConfig(BaseModel):
    """SendGrid email provider configuration."""

    api_key: SecretStr
    from_email: str
    from_name: str | None = None
