"""Event-driven message sources for RoomKit."""

from typing import Any

from roomkit.sources.base import (
    BaseSourceProvider,
    EmitCallback,
    SourceHealth,
    SourceProvider,
    SourceStatus,
)

__all__ = [
    "BaseSourceProvider",
    "EmitCallback",
    "SourceHealth",
    "SourceProvider",
    "SourceStatus",
    # Lazy imports for optional sources
    "WebSocketSource",
    "default_json_parser",
]


def __getattr__(name: str) -> Any:
    """Lazy import for optional source providers."""
    if name == "WebSocketSource":
        from roomkit.sources.websocket import WebSocketSource

        return WebSocketSource
    if name == "default_json_parser":
        from roomkit.sources.websocket import default_json_parser

        return default_json_parser
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
