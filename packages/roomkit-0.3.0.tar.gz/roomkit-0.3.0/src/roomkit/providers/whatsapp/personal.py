"""WhatsApp Personal provider backed by a neonize source.

Does not import neonize directly — accesses the client through the shared
``WhatsAppPersonalSourceProvider`` instance, so importing this module never
requires the optional dependency.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any
from uuid import uuid4

from roomkit.models.delivery import ProviderResult
from roomkit.models.event import (
    AudioContent,
    LocationContent,
    MediaContent,
    RoomEvent,
    TextContent,
    VideoContent,
)
from roomkit.providers.whatsapp.base import WhatsAppProvider
from roomkit.sources.base import SourceStatus

if TYPE_CHECKING:
    from roomkit.sources.neonize import WhatsAppPersonalSourceProvider

logger = logging.getLogger("roomkit.providers.whatsapp.personal")


def _build_jid(phone: str) -> str:
    """Convert a phone number to a WhatsApp JID.

    Strips a leading ``+`` and appends ``@s.whatsapp.net`` when no domain
    is present.
    """
    phone = phone.lstrip("+")
    if "@" not in phone:
        return f"{phone}@s.whatsapp.net"
    return phone


class WhatsAppPersonalProvider(WhatsAppProvider):
    """Outbound WhatsApp delivery via a shared neonize source.

    The provider delegates all sends to the neonize client owned by the
    paired ``WhatsAppPersonalSourceProvider``.  It does **not** manage
    client lifecycle — that responsibility stays with the source.
    """

    def __init__(self, source: WhatsAppPersonalSourceProvider) -> None:
        self._source = source

    @property
    def name(self) -> str:
        return "whatsapp-personal"

    async def send(self, event: RoomEvent, to: str) -> ProviderResult:
        """Send a message through the neonize client.

        Maps ``RoomEvent.content`` types to the appropriate neonize send
        method.
        """
        client = self._source.client
        if client is None or self._source.status != SourceStatus.CONNECTED:
            return ProviderResult(success=False, error="WhatsApp personal source not connected")

        jid = _build_jid(to)
        content = event.content

        try:
            if isinstance(content, TextContent):
                await client.send_message(jid, content.body)
            elif isinstance(content, MediaContent):
                mime = content.mime_type.lower()
                if mime.startswith("image/"):
                    await client.send_image(jid, content.url, caption=content.caption or "")
                else:
                    await client.send_document(
                        jid,
                        content.url,
                        filename=content.filename or "file",
                    )
            elif isinstance(content, AudioContent):
                ptt = content.mime_type == "audio/ogg"
                await client.send_audio(jid, content.url, ptt=ptt)
            elif isinstance(content, VideoContent):
                await client.send_video(jid, content.url)
            elif isinstance(content, LocationContent):
                await client.send_location(
                    jid,
                    content.latitude,
                    content.longitude,
                    name=content.label or "",
                )
            else:
                return ProviderResult(
                    success=False,
                    error=f"Unsupported content type: {type(content).__name__}",
                )

            return ProviderResult(success=True, provider_message_id=uuid4().hex)

        except Exception as exc:
            logger.error("Failed to send WhatsApp personal message: %s", exc)
            return ProviderResult(success=False, error=str(exc))

    async def send_typing(self, to: str, *, is_typing: bool = True, media: str = "text") -> None:
        """Send a typing indicator to a WhatsApp chat.

        Args:
            to: Phone number or full JID.
            is_typing: ``True`` for composing, ``False`` for paused.
            media: ``"text"`` for typing or ``"audio"`` for recording.
        """
        jid = _build_jid(to)
        if is_typing:
            await self._source.send_composing(jid, media=media)
        else:
            await self._source.send_paused(jid)

    async def mark_read(
        self,
        message_ids: list[str],
        chat: str,
        sender: str,
    ) -> None:
        """Send read receipts (blue ticks) for messages.

        Args:
            message_ids: List of message IDs to mark as read.
            chat: Phone number or full JID of the chat.
            sender: Phone number or full JID of the sender.
        """
        await self._source.mark_read(
            message_ids,
            chat=_build_jid(chat),
            sender=_build_jid(sender),
        )

    async def close(self) -> None:  # noqa: B027
        """No-op — the source owns the client lifecycle."""
