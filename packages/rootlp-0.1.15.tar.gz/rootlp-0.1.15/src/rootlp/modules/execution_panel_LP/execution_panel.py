#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Date          : 2026-01-25
# Author        : Lancelot PINCET
# GitHub        : https://github.com/LancelotPincet
# Library       : rootLP
# Module        : execution_panel

"""
This module creates the executio panel of a main script.
"""



# %% Libraries
import marimo as mo
from rootlp import user_inputs



# %% Function
def execution_panel(name, *, do_import:bool=True, do_export:bool=True, do_new:bool=True, do_overnight:bool=True) :
    '''
    This module creates the executio panel of a main script.
    
    Parameters
    ----------
    name : str
        Name of script.
    do_import : bool
        True to implemant import_path.
    do_export : bool
        True to implemant export_path.
    do_new : bool
        True to implemant new boolean.
    do_overnight : bool
        True to implemant overnight boolean.

    Returns
    -------
    launch : mo.ui.button
        Launch button.
    parameters : dict
        Dictionnary with execution parameters.
    md_execution : mo.md
        Execution panel markdown.

    Examples
    --------
    >>> from rootlp import execution_panel
    ...
    >>> execution_panel(name)
    '''

    # Title
    title = name[0].upper() + name[1:].replace('_', ' ')

    launch = mo.ui.run_button(label=f"**--->>> {name} <<<---**")
    launch.center()

    user_inputs(True)
    if do_import :
        import_path = mo.ui.text(placeholder="copy-paste import path", full_width=True)
    if do_export :
        export_path = mo.ui.text(placeholder="copy-paste export path", full_width=True)
    if do_new :
        new = mo.ui.switch(value=True, label="**New**: check to create new processing folder each time [default: True]")
    if do_overnight :
        overnight = mo.ui.switch(value=False, label="**Overnight**: check to ignore bulk processing errors [default: False]")
    parameters_execution = user_inputs()

    #Strings
    if do_import and do_export :
        import_string = f'\n**Import path** : Folder with data to process [default: will open a browse window]\n{import_path}\n'
        export_string = f'\n**Export path** : Folder where to save [default: import path **parent**]\n{export_path}\n'
    elif do_import :
        import_string = f'\n**Import path** : Folder with data to process [default: will open a browse window]\n{import_path}\n'
        export_string = ''
    elif do_export :
        import_string = ''
        export_string = f'\n**Export path** : Folder where to save [default: will open a browse window]\n{export_path}\n'
    else :
        import_string, export_string = '', ''
    if do_new and do_overnight :
        bool_string = f'\n{mo.hstack([new, overnight])}\n'
    elif do_new :
        bool_string = f'\n{new}\n'
    elif do_overnight :
        bool_string = f'\n{overnight}\n'
    else :
        bool_string = ''

    # Markdown output
    md_execution = f"""
# **{title} launch script**

---

## **Script execution inputs**

### Launch script button

{launch}

Execution logs will appear on the right panel -->

(Check user inputs parameters before launching)

### Execution parameters
{import_string}
{export_string}
{bool_string}
"""

    return launch, parameters_execution, mo.md(md_execution)



# %% Test function run
if __name__ == "__main__":
    from corelp import test
    test(__file__)