#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Date          : 2026-01-18
# Author        : Lancelot PINCET
# GitHub        : https://github.com/LancelotPincet
# Library       : rootLP
# Module        : menu

"""
This module creates a menu on the side of the marimo window.
"""



# %% Libraries
from pathlib import Path
import marimo as mo



# %% Function
def menu(project) :
    '''
    This module creates a menu on the side of the marimo window.
    
    Parameters
    ----------
    project : module
        project module described by menu.

    Examples
    --------
    >>> from rootlp import menu
    >>> import myproject
    ...
    >>> menu(myproject)
    '''

    # Mode
    if project is None :
        return
    if mo.app_meta().mode == "edit" :
        return

    # Folder
    project_folder = Path(project.__file__).parent # project / __init__.py
    name = project_folder.name

    # Analyse sources
    menus = {folder.name: {} for folder in project_folder.iterdir() if folder.is_dir() and not folder.name.startswith('_')}
    for source in project.sources.values() :
        split = source.split(".") # project.folder.module_LP.module
        if split[0] != name : raise SyntaxError('Project name is not consistent in sources')
        if len(split) != 4 : continue
        icon = get_icon(project_folder, split)
        menus[split[1]][f'/{name}/{split[3]}'] = f'{icon}{name2title(split[3])}'
    
    # Navigation menu
    nav_menu = menus['pages']
    for menu_key, menu_value in menus.items() :
        if menu_key == 'pages' : continue
        pipeline_file = project_folder / f'{menu_key}/__pipeline__.txt'
        if pipeline_file.exists() :
            string = pipeline_file.read_text()
            pipeline = string.split(',')
            pipeline = [string.replace(' ', '') for string in pipeline]
            pipeline = [string for string in pipeline if len(string)>0]
            pipeline = [f'/{name}/{string}' for string in pipeline]
            if len(pipeline) != len(menu_value) :
                raise SyntaxError(f'Pipeline of {menu_key} is not correct.')
        else :
            pipeline = list(menu_value.keys())
        nav_menu[name2title(menu_key)] = {}
        for key in pipeline :
            nav_menu[key] = menu_value[key]

    # Sidebar
    sidebar = mo.sidebar(
    [
        mo.md(f"# {name2title(name)}"),
        mo.nav_menu(nav_menu, orientation="vertical"),
    ]
)

    return sidebar



def name2title(name) :
    capital = name[0].upper()
    name = name[1:].lower()
    name = name.replace('_', ' ')
    name = name.replace('2', ' to ')
    return f'{capital}{name}'



def get_icon(folder, split) :
    icon_file = folder / f'{split[1]}/{split[2]}/__icon__.txt'
    if not icon_file.exists() :
        return mo.icon('lucide:file-play')
    return mo.icon(f'lucide:{icon_file.read_text()}')



# %% Test function run
if __name__ == "__main__":
    from corelp import test
    test(__file__)