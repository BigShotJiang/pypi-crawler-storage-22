#!/usr/bin/env python3
# This software is distributed under the terms of the MIT License.
# Copyright (c) 2026 Dmitry Ponomarev.
# Author: Dmitry Ponomarev <ponomarevda96@gmail.com>
"""
Tests for ros2-cyphal-bridge
"""

import asyncio
import contextlib
import random
random.seed(42)

import string
import textwrap
from pathlib import Path

import pytest

import pycyphal
import pycyphal.application
import rclpy
import uavcan

from sensor_msgs.msg import FluidPressure, Temperature

from ros2_cyphal_bridge.cli import BridgeNode, bridge_loop, load_config

CYPHAL_PROTOCOL_VERSION = uavcan.node.Version_1_0(major=1, minor=0)
CYPHAL_NODE_NAME = "com.manufacturer.project.product"
CYPHAL_GET_INFO_RESPONSE = uavcan.node.GetInfo_1_0.Response(
    protocol_version=CYPHAL_PROTOCOL_VERSION,
    name=CYPHAL_NODE_NAME,
)

def random_topic(prefix: str = "/topic_") -> str:
    suffix = "".join(random.choice(string.ascii_letters) for _ in range(8))
    return f"{prefix}{suffix}"

@pytest.mark.tryfirst
@pytest.mark.dependency(name="slcan0")
def test_slcan0_exists() -> None:
    assert Path("/sys/class/net/slcan0").exists()

def test_load_config_cyphal_settings(tmp_path: Path) -> None:
    config_path = tmp_path / "bridge.yaml"
    config_path.write_text(textwrap.dedent(
        """\
        version: 1
        cyphal:
          node_id: 123
          node_name: com.example.test
          can_iface: socketcan:can0
          can_mtu: 64
          udp_iface: 127.0.0.1
        cyphal_to_ros2:
          - rule: "uavcan.node.Heartbeat.1.0@42 -> /nodes/id_42/uptime:std_msgs/msg/UInt32"
            transform: "data=int(msg.uptime)"
        """
    ))
    config = load_config(config_path)

    assert config.node_id == 123
    assert config.node_name == "com.example.test"
    assert config.can_iface == "socketcan:can0"
    assert config.can_mtu == 64
    assert config.udp_iface == "127.0.0.1"

@pytest.mark.dependency(depends=["slcan0"])
def test_ros2_to_cyphal_bridge(tmp_path: Path) -> None:
    temperature_c = random.uniform(-20.0, 80.0)
    temperature_k = temperature_c + 273.15
    subject_id = random.randint(2000, 3000)
    ros2_topic = random_topic("/robot/sensors/temperature_")
    config_path = tmp_path / "bridge.yaml"
    config_path.write_text(textwrap.dedent(
        f"""\
        version: 1
        ros2_to_cyphal:
          - rule: "{ros2_topic}:sensor_msgs/msg/Temperature -> {subject_id}:uavcan.si.unit.temperature.Scalar.1.0"
            transform: "kelvin=float(msg.temperature + 273.15)"
        """
    ))
    config = load_config(config_path)

    async def run_test() -> float:
        bridge_node = BridgeNode()
        node_id = config.node_id
        node_name = config.node_name or "com.manufacturer.project.ros2_bridge"
        bridge_task = asyncio.create_task(bridge_loop(bridge_node, config, node_id, node_name))

        cyphal_node = pycyphal.application.make_node(CYPHAL_GET_INFO_RESPONSE)
        cyphal_node.heartbeat_publisher.mode = uavcan.node.Mode_1_0.OPERATIONAL
        cyphal_node.start()

        subscriber = cyphal_node.make_subscriber(
            uavcan.si.unit.temperature.Scalar_1_0, subject_id
        )

        pub = bridge_node.create_publisher(Temperature, ros2_topic, 10)
        await asyncio.sleep(0.1)
        pub.publish(Temperature(temperature=temperature_c))

        try:
            msg, _ = await asyncio.wait_for(subscriber.__anext__(), timeout=2.0)
            return float(msg.kelvin)
        finally:
            cyphal_node.close()
            bridge_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await bridge_task
            bridge_node.destroy_node()

    rclpy.init()
    try:
        received = asyncio.run(run_test())
    finally:
        rclpy.shutdown()

    assert received == pytest.approx(temperature_k)


@pytest.mark.dependency(depends=["slcan0"])
def test_cyphal_to_ros2_bridge(tmp_path: Path) -> None:
    value = random.random()
    subject_id = random.randint(2000, 3000)
    ros2_topic = random_topic("/robot/sensors/pressure_")
    config_path = tmp_path / "bridge.yaml"
    config_path.write_text(textwrap.dedent(
        f"""\
        version: 1
        cyphal_to_ros2:
          - rule: "{subject_id}:uavcan.si.unit.pressure.Scalar.1.0 -> {ros2_topic}:sensor_msgs/msg/FluidPressure"
            transform: "fluid_pressure=float(msg.pascal);variance=0.0"
        """
    ))
    config = load_config(config_path)

    async def run_test() -> float:
        bridge_node = BridgeNode()
        node_id = config.node_id
        node_name = config.node_name or "com.manufacturer.project.ros2_bridge"
        bridge_task = asyncio.create_task(bridge_loop(bridge_node, config, node_id, node_name))

        received_future: asyncio.Future[float] = asyncio.get_running_loop().create_future()

        def callback(msg: FluidPressure) -> None:
            if not received_future.done():
                received_future.set_result(float(msg.fluid_pressure))

        bridge_node.create_subscription(FluidPressure, ros2_topic, callback, 10)

        cyphal_node = pycyphal.application.make_node(CYPHAL_GET_INFO_RESPONSE)
        cyphal_node.heartbeat_publisher.mode = uavcan.node.Mode_1_0.OPERATIONAL
        cyphal_node.start()

        publisher = cyphal_node.make_publisher(uavcan.si.unit.pressure.Scalar_1_0, subject_id)

        try:
            await asyncio.sleep(0.1)
            await publisher.publish(uavcan.si.unit.pressure.Scalar_1_0(value))
            return await asyncio.wait_for(received_future, timeout=2.0)
        finally:
            cyphal_node.close()
            bridge_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await bridge_task
            bridge_node.destroy_node()

    rclpy.init()
    try:
        received = asyncio.run(run_test())
    finally:
        rclpy.shutdown()

    assert received == pytest.approx(value)
