from pathlib import Path

from ros2_cyphal_bridge.cli import load_config


def main() -> None:
    load_config(Path("/home/user/ros2_cyphal_bridge/tools/docker/example_bridge.yaml"))


if __name__ == "__main__":
    main()
