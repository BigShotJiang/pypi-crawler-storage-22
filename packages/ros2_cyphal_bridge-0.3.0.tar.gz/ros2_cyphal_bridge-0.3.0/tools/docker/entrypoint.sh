#!/usr/bin/env bash
set -e

source /home/user/tools/docker/ros2_cyphal_env.sh
source /home/user/.venv/bin/activate

if [ $# -eq 0 ]; then
  exec /bin/bash
fi

case "$1" in
  --*|-*)
    # Convenience: if the user mounted /tmp/bridge.yaml, use it by default.
    if [ -f /tmp/bridge.yaml ]; then
      for arg in "$@"; do
        case "$arg" in
          --config|--config=*|-c)
            exec ros2-cyphal-bridge "$@"
            ;;
        esac
      done
      exec ros2-cyphal-bridge "$@" --config /tmp/bridge.yaml
    fi
    exec ros2-cyphal-bridge "$@"
    ;;
  ros2-cyphal-bridge)
    shift
    if [ -f /tmp/bridge.yaml ]; then
      for arg in "$@"; do
        case "$arg" in
          --config|--config=*|-c)
            exec ros2-cyphal-bridge "$@"
            ;;
        esac
      done
      exec ros2-cyphal-bridge "$@" --config /tmp/bridge.yaml
    fi
    exec ros2-cyphal-bridge "$@"
    ;;
  *)
    exec "$@"
    ;;
esac
