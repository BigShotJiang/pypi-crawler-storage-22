#!/usr/bin/env python3
"""Example ROS 2 node that matches example_bridge.yaml."""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import FluidPressure, Temperature
from std_msgs.msg import Bool, Float32, UInt32


class ExampleNode(Node):
    """Publishes ROS 2 topics consumed by the bridge and logs bridged outputs."""

    def __init__(self) -> None:
        super().__init__("example_ros2_node")
        self.setpoint_pub = self.create_publisher(Float32, "/setpoint", 10)
        self.gt_pressure_pub = self.create_publisher(
            FluidPressure, "/robot/gt/pressure", 10
        )
        self.create_subscription(
            FluidPressure, "/robot/sensors/pressure", self.on_pressure, 10
        )
        self.create_subscription(
            Temperature, "/robot/sensors/temperature", self.on_temperature, 10
        )
        self.create_subscription(
            Bool, "/robot/sensors/limit_switch", self.on_limit_switch, 10
        )
        self.create_subscription(
            UInt32, "/nodes/id_42/uptime", self.on_uptime, 10
        )
        self.timer = self.create_timer(1.0, self.publish_messages)
        self.value = 0.0
        self.get_logger().info("Example ROS2 node started")

    def publish_messages(self) -> None:
        self.value += 1.0
        setpoint = Float32()
        setpoint.data = self.value
        self.setpoint_pub.publish(setpoint)

        pressure = FluidPressure()
        pressure.fluid_pressure = 101_325.0 + self.value
        pressure.variance = 0.0
        self.gt_pressure_pub.publish(pressure)

        self.get_logger().info(
            f"Publishing setpoint={setpoint.data:.2f} gt_pressure={pressure.fluid_pressure:.2f}"
        )

    def on_pressure(self, msg: FluidPressure) -> None:
        self.get_logger().info(f"RX pressure: {msg.fluid_pressure:.2f}")

    def on_temperature(self, msg: Temperature) -> None:
        self.get_logger().info(f"RX temperature: {msg.temperature:.2f}")

    def on_limit_switch(self, msg: Bool) -> None:
        self.get_logger().info(f"RX limit_switch: {msg.data}")

    def on_uptime(self, msg: UInt32) -> None:
        self.get_logger().info(f"RX uptime: {msg.data}")


def main(args=None) -> None:
    rclpy.init(args=args)
    node = ExampleNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        print("Interrupted by a user")

if __name__ == "__main__":
    main()
