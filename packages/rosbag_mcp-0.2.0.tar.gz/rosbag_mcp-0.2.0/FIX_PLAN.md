# Fix Plan: rosbag-mcp v0.2.0 Issues

**Based on:** UPGRADE_REPORT.md (corrected)  
**Created:** 2026-02-07  
**Completed:** 2026-02-07

---

## P0 — Dead Code & False Documentation

### 1. ✅ Delete `SizeAwareSLRU` dead code

**Status:** Complete

Removed `SizeAwareSLRU` and `_CacheEntry` from `cache.py` (~100 lines), `TestSizeAwareSLRU` from `test_cache.py`, and SLRU benchmark from `test_benchmarks.py`. Cleaned unused imports (`Generic`, `Hashable`, `TypeVar`).

### 2. ✅ Delete `ARCHITECTURE_REVIEW.md`

**Status:** Complete

Deleted entirely — it contained fabricated bug reports and references to non-existent files.

---

## P1 — Cache Fix

### 3. ✅ Fix generator early-exit losing index builds

**Status:** Complete (option A — store partial, overwrite on full scan)

Wrapped the for-loop in `bag_reader.py:read_messages()` with `try/finally` so `TopicTimeIndex` is stored even when consumers break early. Partial indexes contain timestamps up to the break point; subsequent full scans overwrite with the complete index.

### 4. ✅ Delete `SizeAwareSLRU`

**Status:** Complete (covered by task #1)

---

## P2 — Code Organization

### 5. ✅ Split `advanced.py` into domain modules

**Status:** Complete

| New File | Tools |
|----------|-------|
| `tools/statistics.py` | `get_topic_schema`, `analyze_topic_stats`, `compare_topics`, `export_to_csv` |
| `tools/navigation.py` | `analyze_costmap_violations`, `analyze_path_tracking`, `analyze_wheel_slip`, `analyze_navigation_health` |
| `tools/events.py` | `detect_events` |
| `tools/sensors.py` (expanded) | `analyze_imu`, `analyze_lidar_timeseries` moved in from `advanced.py` |

`advanced.py` deleted. `tools/__init__.py` updated. All 30 tools still importable.

### 6. ✅ Add one-line docstrings to all 30 tool functions

**Status:** Complete

---

## P3 — Cleanup & Investigation

### 7. ✅ Remove phantom `pyyaml` dependency

**Status:** Complete

Removed optional `yaml = ["pyyaml>=6.0"]` and dev dependency from `pyproject.toml`.

### 8. ✅ Git history audit for phantom config commit

**Status:** Complete

Commit `1222953` did add `config.py` and YAMLs. Commit `93e0bcd` (47 min later) deleted them as unused. Not fabricated commits — fabricated claim they still existed.

---

## Verification Results (after P4)

```
✅ 30/30 tools import correctly
✅ 51/51 tests pass (pytest)
✅ ruff check: 0 errors in changed files (14 pre-existing E501 in server.py)
✅ ruff format: all files formatted
```

---

## P4 — Message-Level Caching

### 9. ✅ Add `MessageCache` to `cache.py`

**Status:** Complete

Size-gated auto-caching: caches deserialized messages for topics with small payloads (< 100 KB per message). 512 MB total budget, 50 MB per topic. Serves time-filtered queries via binary search on cached timestamps.

---

## P5 — ✅ Eliminate `analysis.py` and Define Clear Module RnR

**Status:** Complete

Redistributed all 5 tools from the generic `analysis.py` grab bag into domain-specific modules:

| Tool | From | To | Rationale |
|------|------|----|-----------|
| `analyze_trajectory` | `analysis.py` | `slam.py` (new) | SLAM/odometry output, not navigation |
| `analyze_lidar_scan` | `analysis.py` | `sensors.py` | LiDAR sensor data |
| `get_image_at_time` | `analysis.py` | `sensors.py` | Camera sensor data |
| `analyze_logs` | `analysis.py` | `introspection.py` (new) | ROS system inspection |
| `get_tf_tree` | `analysis.py` | `introspection.py` (new) | ROS system inspection |

### Final Module RnR

| File | Role | Tools |
|------|------|-------|
| `core.py` | Bag management | `set_bag_path`, `list_bags`, `bag_info` |
| `messages.py` | Message retrieval & search | `get_message_at_time`, `get_messages_in_range`, `search_messages` |
| `sensors.py` | All sensor hardware data | `analyze_imu`, `analyze_lidar_scan`, `analyze_lidar_timeseries`, `analyze_pointcloud2`, `get_image_at_time`, `analyze_joint_states`, `analyze_diagnostics` |
| `slam.py` | SLAM / odometry analysis | `analyze_trajectory` |
| `navigation.py` | Path planning & tracking | `analyze_costmap_violations`, `analyze_path_tracking`, `analyze_wheel_slip`, `analyze_navigation_health` |
| `statistics.py` | Topic-level metrics & export | `get_topic_schema`, `analyze_topic_stats`, `compare_topics`, `export_to_csv` |
| `events.py` | Event detection | `detect_events` |
| `introspection.py` | ROS system inspection | `analyze_logs`, `get_tf_tree` |
| `visualization.py` | Plotting & charts | `plot_timeseries`, `plot_2d`, `plot_lidar_scan`, `plot_comparison` |
| `filter.py` | Bag filtering | `filter_bag` |

---

## Out of Scope

Deferred (not blocking functionality):

- **CI/CD setup**
- **Type checking enforcement** — pre-existing type errors throughout codebase
- **`server.py` split** — 900 lines but logically cohesive (schema + handler pairs)
- **Thread safety** — not relevant for MCP's serial processing model
- **Pre-existing E501 in `server.py`** — 14 long lines in tool description strings
