# Message-Level Caching — Design Document

## The Problem

Every `read_messages()` call opens a fresh `AnyReader` and re-reads from disk. If a user asks "analyze IMU", then "plot IMU", then "compare IMU to odom" — the `/imu` topic gets read 3 times. The current cache only covers metadata (bag_info, schema) and timestamp indexes, not the messages themselves.

## How Users Actually Use This

```
User: "Set bag to /data/nav_test.bag"           → set_bag_path (instant)
User: "What's in this bag?"                       → bag_info (cached after 1st call)
User: "Analyze the trajectory"                    → reads /odom (full scan)
User: "Plot the trajectory"                       → reads /odom AGAIN
User: "Compare /odom velocity to /cmd_vel"        → reads /odom AGAIN + /cmd_vel
User: "Check for costmap violations"              → reads /costmap + /amcl_pose
User: "How's the path tracking?"                  → reads /plan + /amcl_pose AGAIN
User: "What happened between t=10 and t=20?"      → reads topic in range
User: "Plot that same time range"                 → reads same range AGAIN
```

Same topics re-read 2-4x per conversation. The OS page cache handles disk I/O, but we still pay **CPU cost** for AnyReader creation + binary deserialization (~50-200ms per full scan).

## Memory Reality

| Topic Type | Per-Message | 60s Cache | 10min Cache | Cache? |
|------------|-------------|-----------|-------------|--------|
| Odometry (60 Hz) | ~0.8 KB | 2.9 MB | 29 MB | ✅ |
| IMU (100 Hz) | ~0.5 KB | 3.2 MB | 32 MB | ✅ |
| cmd_vel (20 Hz) | ~0.2 KB | 0.2 MB | 2 MB | ✅ |
| LaserScan (10 Hz) | ~6 KB | 3.4 MB | 34 MB | ✅ |
| TF (100 Hz) | ~2 KB | 12 MB | 120 MB | ✅ |
| CompressedImage (30 Hz) | ~20-80 KB | 1-2.4 MB | 10-24 MB | ✅ |
| Raw Image (30 Hz) | ~900 KB+ | 27 MB+ | 270 MB+ | ❌ |
| PointCloud2 (10 Hz) | ~1.5 MB | 915 MB | 9 GB | ❌ |

---

## Chosen Approach: Option C — Size-Gated Auto-Caching

Cache full topic on first complete scan. Serve subsequent reads (including time-filtered) from memory. Skip topics with large messages.

### Parameters

| Parameter | Value |
|-----------|-------|
| Max total cache | **512 MB** |
| Per-topic budget | **50 MB** |
| Per-message size gate | skip if raw payload > **100 KB** |
| Cache lifetime | until `set_bag_path` changes or `BagHandle` evicted |
| Cache population | only on **full single-topic scans, fully consumed** |
| Time-filtered serving | yes — binary search cached list, yield slice |

---

## Architecture

### New Class: `MessageCache` (in `cache.py`)

Owned by `BagHandle`. Manages per-topic message storage with size tracking.

```
BagHandle
├── meta: dict                    # bag_info, schemas (existing)
├── topic_indexes: dict           # TopicTimeIndex (existing)
└── message_cache: MessageCache   # NEW
    ├── _topics: dict[str, list[BagMessage]]
    ├── _total_bytes: int
    ├── max_bytes: int (512 MB)
    ├── max_per_topic: int (50 MB)
    └── methods:
        ├── can_cache(raw_size, msg_count) → bool
        ├── note_bytes(n) → bool  # returns False if budget exceeded
        ├── commit(topic, messages, bytes_used)
        ├── get(topic) → list[BagMessage] | None
        ├── get_range(topic, start_ns, end_ns) → list[BagMessage] | None
        └── clear()
```

### Modified: `read_messages()` (in `bag_reader.py`)

Two new code paths:

**Path 1 — Cache hit (fast path):**
```python
def read_messages(topics, start_time, end_time, bag_path):
    handle = _cache.get_handle(path)

    # Fast path: single cached topic
    if len(topics) == 1 and handle.message_cache.get(topics[0]):
        if start_time or end_time:
            yield from handle.message_cache.get_range(topics[0], start_ns, end_ns)
        else:
            yield from handle.message_cache.get(topics[0])
        return

    # Slow path: disk read (existing code, with cache collection)
    ...
```

**Path 2 — Cache miss (existing path + collection):**
```python
    # Decide if we should try caching this scan
    should_collect = (
        single_topic
        and no_time_filter
        and not already_cached
        and handle.message_cache.can_cache(estimated_raw_size, msg_count)
    )
    collected = [] if should_collect else None
    collected_bytes = 0
    completed = False

    with handle.reader_ctx() as reader:
        try:
            for conn, timestamp, rawdata in reader.messages(...):
                # Size gate: check first message raw payload
                if collected is not None and collected_bytes == 0:
                    if len(rawdata) > 100_000:  # >100 KB per message
                        collected = None  # abort caching

                msg = BagMessage(...)
                if collected is not None:
                    collected.append(msg)
                    collected_bytes += len(rawdata) + 200  # raw + dict overhead
                    if not handle.message_cache.note_bytes(0):
                        collected = None  # budget exceeded mid-scan
                yield msg
            completed = True  # loop finished normally (no break/GeneratorExit)
        finally:
            # Only cache if fully consumed
            if completed and collected is not None:
                handle.message_cache.commit(topic, collected, collected_bytes)
            # Existing: store TopicTimeIndex
            ...
```

### Key Design Decisions (Oracle-reviewed)

| Decision | Rationale |
|----------|-----------|
| **`completed` flag, not GeneratorExit** | GeneratorExit/GC timing is unreliable. `completed = True` after the for-loop is deterministic. |
| **Incremental `len(rawdata)` accounting** | Cheap and predictable. Deep `sys.getsizeof` recursion is expensive and still inaccurate. |
| **Yield-then-cache (not cache-then-yield)** | Preserves streaming first-message latency. Tools get data immediately; cache commits on completion. |
| **Abort caching mid-scan if budget exceeded** | Drop `collected = None` mid-stream. Frees memory pressure without breaking the yield. |
| **Multi-topic → always fall back to disk** | Mixing cached + uncached topics requires k-way timestamp merge. Not worth the complexity. Only `get_tf_tree` uses multi-topic. |
| **No mutation protection (for now)** | Risk: if a tool modifies `msg.data`, it corrupts the cache. No tools currently mutate. Document as read-only contract; add `MappingProxyType` later if needed. |

### Cache Invalidation

| Event | Action |
|-------|--------|
| `set_bag_path()` called | `BagHandle` may change → cache cleared via handle eviction |
| `BagHandle` evicted (LRU/idle) | `message_cache.clear()` called in `_close_handle()` |
| Bag file modified on disk | `BagKey(mtime_ns, size)` mismatch → new handle, old evicted |

---

## What a Typical Session Looks Like

```
User: "Set bag to nav_test.bag"
  → set_bag_path (no cache change)

User: "Analyze the trajectory"
  → read_messages("/odom", full scan) → MISS → read from disk, cache /odom (2.9 MB)

User: "Plot the trajectory"
  → read_messages("/odom", full scan) → HIT → yield from memory (instant)

User: "Analyze IMU data"
  → read_messages("/imu", full scan) → MISS → read from disk, cache /imu (3.2 MB)

User: "Compare /odom velocity to /cmd_vel"
  → read_messages("/odom") → HIT (instant)
  → read_messages("/cmd_vel") → MISS → read, cache /cmd_vel (0.2 MB)

User: "What happened on /odom between t=10 and t=20?"
  → read_messages("/odom", t=10, t=20) → HIT → binary search, yield slice (instant)

User: "Analyze pointcloud"
  → read_messages("/points") → first msg 1.5 MB > 100 KB gate → SKIP → read from disk

Cache state: /odom (2.9 MB) + /imu (3.2 MB) + /cmd_vel (0.2 MB) = 6.3 MB of 512 MB
```

---

## Files Changed

| File | Change |
|------|--------|
| `cache.py` | Add `MessageCache` class. Add `message_cache` field to `BagHandle`. Call `clear()` on handle close. |
| `bag_reader.py` | Add cache-hit fast path in `read_messages()`. Add collection logic in cache-miss path. |
| `test_cache.py` | Add `TestMessageCache` (can_cache, commit, get, get_range, budget enforcement, clear). |

No tool files changed. No API changes. Transparent to all 30 tools.

---

## Risks

| Risk | Likelihood | Mitigation |
|------|-----------|------------|
| Memory spike from many cached topics | Low | 512 MB hard cap + per-topic 50 MB + abort mid-scan |
| Tool mutates `msg.data`, corrupts cache | Low | Document read-only contract. Add `MappingProxyType` later if needed. |
| Budget estimate inaccurate | Medium | `len(rawdata)` is lower bound; Python dicts are larger. Treat 512 MB as soft limit. |
| Cache stale after bag modification | None | `BagKey` uses `mtime_ns + size` fingerprint |

## Not Doing

- **Multi-topic cache merging** — too complex for one use case (get_tf_tree)
- **Mutation protection (MappingProxyType)** — no current need
- **Configurable budgets via env vars** — hardcode for now
- **Cache warming on `set_bag_path`** — would slow down initial setup
