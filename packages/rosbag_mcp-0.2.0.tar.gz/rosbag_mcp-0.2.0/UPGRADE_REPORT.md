# ROSBag MCP v0.2.0 — Upgrade Report

**Date:** 2026-02-07  
**Last Updated:** 2026-02-07  
**Previous Version:** 0.1.1  
**New Version:** 0.2.0  
**Branch:** main  
**Commits:** 11 (6e3a3b4 → 7d76207)

> This report was rewritten after discovering the original contained fabricated claims.  
> All issues documented in the errata below have been fixed. See `FIX_PLAN.md` for details.

---

## Errata: Previous Report vs Reality

The original UPGRADE_REPORT.md and ARCHITECTURE_REVIEW.md contained several claims that do not match the actual codebase. This section documents every discrepancy found.

| # | Claim (old report) | Reality | Severity |
|---|-------------------|---------|----------|
| 1 | `config.py` (353 lines) listed as new file | **File does not exist.** No `config.py`, no `default_config.yaml`, no `message_schemas.yaml` anywhere in the repo. | Fabricated |
| 2 | `default_config.yaml` listed as new file | **File does not exist.** | Fabricated |
| 3 | `message_schemas.yaml` listed as new file | **File does not exist.** | Fabricated |
| 4 | "New modules: 4 (cache.py, config.py, sensors.py, 2 YAML configs)" | Actually 2 new modules: `cache.py` and `sensors.py`. No config, no YAMLs. | Overclaimed |
| 5 | `sensors.py` described as "New Sensor Analysis Tools" implying it covers LiDAR/IMU | `sensors.py` has 3 tools only: `analyze_pointcloud2`, `analyze_joint_states`, `analyze_diagnostics`. IMU analysis is in `advanced.py`. LiDAR timeseries is in `advanced.py`. Single-scan LiDAR is in `analysis.py`. | Misleading |
| 6 | ARCHITECTURE_REVIEW says `config.py` is "dead code" / "orphaned" | It was never created. The review invented a file and then criticized it. | Fabricated |
| 7 | ARCHITECTURE_REVIEW claims "critical runtime bug" (`handle.reader` / `handle.close_reader()` mismatch) | `bag_reader.py` actually uses `with handle.reader_ctx() as reader:` everywhere (correct). The `reader_ctx()` context manager already exists in `cache.py`. No bug. | False bug report |
| 8 | `SizeAwareSLRU` described as "metadata + schema caching" in architecture diagram | `SizeAwareSLRU` is **dead code** — defined but never instantiated by any production module. Metadata/schema caching uses plain `dict` (`handle.meta`). | Overclaimed |
| 9 | `cache.py` listed as 355 lines | Actual: 373 lines | Minor |
| 10 | `sensors.py` listed as 332 lines | Actual: 334 lines | Minor |
| 11 | "New Files (10)" in file changes table lists 11 entries | Count doesn't match header | Minor |

---

## Overview

Upgrade of rosbag-mcp from a basic bag analysis tool to a comprehensive ROS data analysis server with caching, multi-sensor support, enhanced search capabilities, and navigation-specific analysis tools.

**Tool count:** 30 (verified: 30 `Tool()` definitions in `server.py`, 30 entries in `__all__` in `tools/__init__.py`)  
**Total lines:** 4,294 across 13 Python files  
**New modules:** 2 (`cache.py`, `tools/sensors.py`)  
**Test files:** 5 (`test_cache.py`, `test_bag_reader.py`, `test_tools.py`, `test_benchmarks.py`, `conftest.py`)

---

## Project Structure (post-fix)

```
src/rosbag_mcp/
├── __init__.py              (5 lines)   — Version: 0.2.0
├── server.py                (900 lines) — MCP protocol, 30 Tool definitions + handlers
├── bag_reader.py            (413 lines) — Central I/O hub, cache integration
├── cache.py                 (273 lines) — Caching system (SizeAwareSLRU removed)
└── tools/
    ├── __init__.py           (69 lines)  — Re-exports all 30 tool functions
    ├── utils.py              (73 lines)  — json_serialize, get_nested_field, extract_position/velocity
    ├── core.py               (43 lines)  — set_bag_path, list_bags, bag_info
    ├── messages.py          (149 lines)  — get_message_at_time, get_messages_in_range, search_messages
    ├── slam.py              (180 lines)  — analyze_trajectory (SLAM/odometry output)
    ├── sensors.py           (~640 lines) — analyze_lidar_scan, get_image_at_time, analyze_imu, analyze_lidar_timeseries, analyze_pointcloud2, analyze_joint_states, analyze_diagnostics
    ├── navigation.py        (~550 lines) — analyze_costmap_violations, analyze_path_tracking, analyze_wheel_slip, analyze_navigation_health
    ├── statistics.py        (~250 lines) — get_topic_schema, analyze_topic_stats, compare_topics, export_to_csv
    ├── events.py            (~130 lines) — detect_events
    ├── introspection.py     (~130 lines) — analyze_logs, get_tf_tree (ROS system inspection)
    ├── visualization.py     (257 lines)  — plot_timeseries, plot_2d, plot_lidar_scan, plot_comparison
    └── filter.py             (73 lines)  — filter_bag

tests/
├── __init__.py
├── conftest.py              — Mock fixtures for ROS messages
├── test_cache.py            — Cache unit tests
├── test_bag_reader.py       — Bag reader unit tests
├── test_tools.py            — Tool utility + importability tests
└── test_benchmarks.py       — Performance benchmarks
```

**Files that DO NOT EXIST (contrary to old report):**
- ~~`src/rosbag_mcp/config.py`~~ — Never created
- ~~`src/rosbag_mcp/default_config.yaml`~~ — Never created
- ~~`src/rosbag_mcp/message_schemas.yaml`~~ — Never created
- ~~`src/rosbag_mcp/tools/advanced.py`~~ — Split into statistics.py, navigation.py, events.py; IMU/LiDAR moved to sensors.py
- ~~`src/rosbag_mcp/tools/analysis.py`~~ — Split into slam.py, sensors.py, introspection.py

---

## Complete Tool Inventory (30 tools)

### `tools/core.py` — 3 tools

| Tool | Description |
|------|-------------|
| `set_bag_path` | Set path to a rosbag file or directory |
| `list_bags` | List all available rosbag files in directory |
| `bag_info` | Retrieve bag metadata: topics, message counts, duration |

### `tools/messages.py` — 3 tools

| Tool | Description |
|------|-------------|
| `get_message_at_time` | Get message from a topic at a specific timestamp |
| `get_messages_in_range` | Get all messages from a topic within a time range |
| `search_messages` | Search messages with conditions (regex, equals, greater_than, less_than, near_position, contains, field_exists) + cross-topic correlation |

### `tools/slam.py` — 1 tool

| Tool | Description |
|------|-------------|
| `analyze_trajectory` | Trajectory metrics from SLAM/odometry: distance, displacement, path efficiency, speed, waypoints |

### `tools/introspection.py` — 2 tools

| Tool | Description |
|------|-------------|
| `analyze_logs` | Parse /rosout logs, filter by level/node |
| `get_tf_tree` | Get TF tree of coordinate frame relationships |

### `tools/statistics.py` — 4 tools (split from advanced.py)

| Tool | Description |
|------|-------------|
| `get_topic_schema` | Inspect message structure/schema with sample data |
| `analyze_topic_stats` | Topic frequency, latency, message intervals, gap detection |
| `compare_topics` | Compare two topic fields: correlation, difference, RMSE |
| `export_to_csv` | Export topic data to CSV file |

### `tools/navigation.py` — 4 tools (split from advanced.py)

| Tool | Description |
|------|-------------|
| `analyze_costmap_violations` | Check if robot entered lethal costmap cells |
| `analyze_path_tracking` | Cross-track error between planned path and actual pose |
| `analyze_wheel_slip` | Compare commanded vs actual velocity for traction loss |
| `analyze_navigation_health` | Aggregate navigation errors, recovery events, health score |

### `tools/events.py` — 1 tool (split from advanced.py)

| Tool | Description |
|------|-------------|
| `detect_events` | Detect threshold crossings, sudden changes, anomalies, stoppages |

### `tools/sensors.py` — 7 tools (all sensor hardware data)

| Tool | Description |
|------|-------------|
| `analyze_pointcloud2` | Parse binary PointCloud2: XYZ bounds, centroid, intensity stats, downsampling |
| `analyze_joint_states` | Per-joint position/velocity/effort statistics, stuck/zero-velocity/high-effort alerts |
| `analyze_diagnostics` | Per-hardware status aggregation (OK/WARN/ERROR/STALE), error timeline |
| `analyze_imu` | IMU analysis: acceleration, angular velocity, orientation statistics |
| `analyze_lidar_scan` | Single LiDAR scan: obstacle count, range statistics at one timestamp |
| `analyze_lidar_timeseries` | LiDAR time series: min distance, obstacle count, closest approach over time |
| `get_image_at_time` | Extract camera image (raw or CompressedImage, multiple encodings, LANCZOS resize) |

### `tools/visualization.py` — 4 tools

| Tool | Description |
|------|-------------|
| `plot_timeseries` | Plot time series data with multiple fields |
| `plot_2d` | Create 2D trajectory plots (XY positions) |
| `plot_lidar_scan` | Visualize LiDAR scan as polar plot |
| `plot_comparison` | Overlay two topic fields with difference highlighting |

### `tools/filter.py` — 1 tool

| Tool | Description |
|------|-------------|
| `filter_bag` | Create a filtered copy of a bag file by topic/time |

---

## Where Sensor/Analysis Tools Live (post-reorganization)

| Domain | Tool | File |
|--------|------|------|
| LiDAR (single scan) | `analyze_lidar_scan` | `sensors.py` |
| LiDAR (time series) | `analyze_lidar_timeseries` | `sensors.py` |
| LiDAR (visualization) | `plot_lidar_scan` | `visualization.py` |
| IMU | `analyze_imu` | `sensors.py` |
| PointCloud2 | `analyze_pointcloud2` | `sensors.py` |
| JointState | `analyze_joint_states` | `sensors.py` |
| Diagnostics | `analyze_diagnostics` | `sensors.py` |
| Camera | `get_image_at_time` | `sensors.py` |
| SLAM/Odometry | `analyze_trajectory` | `slam.py` |
| Costmap | `analyze_costmap_violations` | `navigation.py` |
| Path Tracking | `analyze_path_tracking` | `navigation.py` |
| Wheel Slip | `analyze_wheel_slip` | `navigation.py` |
| Navigation Health | `analyze_navigation_health` | `navigation.py` |
| ROS Logs | `analyze_logs` | `introspection.py` |
| TF Tree | `get_tf_tree` | `introspection.py` |

---

## Cache System (`cache.py`, ~350 lines)

### Components

| Class | Purpose |
|-------|---------|
| `BagKey` | Frozen dataclass: `(realpath, size, mtime_ns)` for file identity |
| `TopicTimeIndex` | Sorted nanosecond timestamps with bisect-based `find_nearest()` and `find_range()` |
| `MessageCache` | Size-gated per-topic message storage (512 MB total, 50 MB/topic, 100 KB/msg gate) |
| `BagHandle` | Wraps one bag path with metadata caches, message cache, and `reader_ctx()` context manager |
| `BagCacheManager` | Singleton: LRU handle pooling (default max 3 open), idle TTL eviction |

> `SizeAwareSLRU` was removed — replaced by `MessageCache` which auto-caches small-message topics.

### Cache Integration in `bag_reader.py`

All 6 public functions in `bag_reader.py` use the cache:

| Function | Cache Behavior |
|----------|---------------|
| `get_bag_info()` | Caches `BagInfo` in `handle.meta["bag_info"]` |
| `read_messages()` | **Fast path**: serves from `MessageCache` if topic is cached. **Slow path**: reads from disk, builds `TopicTimeIndex`, and auto-caches messages for small-message topics. Time-filtered queries served via binary search on cached list. |
| `get_message_at_time()` | Uses `index.find_nearest()` for fast lookup (fast path) or full scan (slow path) |
| `get_messages_in_range()` | Delegates to `read_messages()` — benefits from message cache on second call |
| `get_topic_schema()` | Caches schema in `handle.meta["schema:{topic}"]` |
| `get_topic_timestamps()` | Returns cached index timestamps or builds index during scan |

---

## Cache Effectiveness Analysis

### How the MCP Server Runs

`server.py` runs as a **long-lived asyncio process** via `stdio_server()`. All tool calls go through the same `handle_call_tool()` dispatcher within the same Python process. Therefore:

- `bag_reader._cache = BagCacheManager()` is a **module-level singleton** that persists for the entire server lifetime
- `bag_reader._state = BagReaderState()` (holds `current_bag_path`) also persists across calls

### What Gets Cached

| Cached Item | Where | When Built | When Used |
|-------------|-------|------------|-----------|
| `BagHandle` objects | `_cache._handles` (OrderedDict) | First `get_handle(path)` call | Every subsequent tool call on same bag |
| `BagInfo` (metadata) | `handle.meta["bag_info"]` | First `get_bag_info()` | Second+ `bag_info` call — skips reader entirely |
| Topic schema | `handle.meta["schema:{topic}"]` | First `get_topic_schema()` | Second+ schema call — skips reader + deserialize |
| `TopicTimeIndex` | `handle.topic_indexes[topic]` | After full `read_messages()` scan | `get_message_at_time()` — O(log n) bisect lookup |
| **Messages** | `handle.message_cache` | After first full single-topic scan (if msg < 100 KB) | **All subsequent `read_messages()` on same topic** — yields from memory |
| Connection list | `handle._connections` | First `open_reader()` | `handle.connections` property |

### Message Cache Details

`read_messages()` auto-caches deserialized messages for topics with small payloads:

| Parameter | Value |
|-----------|-------|
| Total budget | 512 MB |
| Per-topic budget | 50 MB |
| Per-message size gate | 100 KB raw payload |
| Cached on | Full single-topic scan, fully consumed |
| Cleared on | `set_bag_path` change, handle eviction |
| Time-filtered serving | Binary search on cached timestamps, yield slice |

**What gets cached:** Odometry, IMU, cmd_vel, LaserScan, TF, logs, CompressedImage
**What doesn't:** Raw Image, PointCloud2 (raw payload > 100 KB)

### What Was Fixed

| Issue | Fix |
|-------|-----|
| **`SizeAwareSLRU` dead code** | Removed, replaced by `MessageCache` |
| **Generator early-exit lost indexes** | Wrapped in `try/finally` — partial indexes stored on early exit |
| **Messages never cached** | `MessageCache` now caches small-message topics on first full scan |
| "Connection pooling" claim | Clarified: `AnyReader` opened/closed per call; `BagHandle` metadata + messages persist |

### Cache Benefit Summary

| Scenario | Without Cache | With Cache | Speedup |
|----------|--------------|------------|---------|
| `bag_info` called twice | 2x open reader + scan | 1x open + 1x dict lookup | ~instant 2nd call |
| `get_topic_schema` called twice | 2x open + deserialize | 1x dict lookup | ~instant 2nd call |
| `get_message_at_time` after full scan | O(n) linear scan | O(log n) bisect on cached index | Large win on big bags |
| `analyze_imu` then `plot_timeseries` on `/imu` | 2x full disk scan + deserialize | 1x disk scan + 1x memory yield | **2nd call instant** |
| `analyze_trajectory` then `plot_2d` on `/odom` | 2x full disk scan | 1x disk scan + 1x memory yield | **2nd call instant** |
| Time-filtered query on cached topic | Disk scan with time filter | Binary search + memory slice | **Instant** |
| PointCloud2 / Raw Image topics | Full disk scan | Full disk scan (not cached, too large) | No change |

---

## Architecture

```
MCP Client (Claude/etc) --stdio/JSON-RPC--> server.py (30 Tool definitions + handlers)
  └-> TOOL_HANDLERS[name](args)
        └-> tools/*.py (11 modules, 30 async functions)
              ├-> core.py (3)          — bag path, listing, metadata
              ├-> messages.py (3)      — message retrieval + search
              ├-> slam.py (1)          — trajectory (SLAM/odometry)
              ├-> sensors.py (7)       — lidar, camera, IMU, pointcloud, joints, diagnostics
              ├-> navigation.py (4)    — costmap, path tracking, wheel slip, nav health
              ├-> statistics.py (4)    — schema, topic stats, comparison, CSV export
              ├-> events.py (1)        — event detection
              ├-> introspection.py (2) — logs, TF tree
              ├-> visualization.py (4) — plots
              └-> filter.py (1)        — bag filtering
                      │
                      v
              bag_reader.py (central I/O hub, 413 lines)
                      │
                      v
              cache.py (BagCacheManager singleton)
                      ├-> BagHandle.meta (plain dict: bag_info, schema caches)
                      ├-> BagHandle.topic_indexes (TopicTimeIndex for O(log n) lookups)
                      ├-> BagHandle.message_cache (MessageCache: per-topic deserialized messages)
                      └-> rosbags.highlevel.AnyReader (opened/closed per tool call, only on cache miss)
```

**Dependency graph is strictly acyclic.** All tool modules depend downward on `bag_reader.py` → `cache.py`. No circular imports.

---

## Known Limitations (remaining)

- **No reader/connection pooling**: `AnyReader` opened/closed per cache-miss call. On cache hit, no reader is opened at all.
- **Large-message topics not cached**: PointCloud2, raw Image — raw payload > 100 KB, always read from disk
- **Message cache read-only contract**: Cached `msg.data` dicts must not be mutated by tools (no enforcement yet)
- **Multi-topic reads bypass cache**: Only single-topic reads served from cache (multi-topic k-way merge not implemented)
- `server.py` at 900 lines mixes MCP protocol, schema definitions, and dispatch
- No CI/CD, no type checking enforcement (mypy/pyright)
- Pre-existing type errors in several modules (does not affect runtime)

---

## Verification Commands

```bash
# Import test — all 30 tools
uv run python -c "import rosbag_mcp.tools as t; assert len(t.__all__) == 30; print('30 tools OK')"

# Tool count matches server
uv run python -c "from rosbag_mcp.server import TOOL_DEFINITIONS, TOOL_HANDLERS; \
  assert len(TOOL_DEFINITIONS) == len(TOOL_HANDLERS) == 30; print('30 tools OK')"

# Version check
uv run python -c "from rosbag_mcp import __version__; assert __version__ == '0.2.0'; print('v0.2.0 OK')"

# Verify deleted files stay deleted
uv run python -c "import importlib; importlib.import_module('rosbag_mcp.config')" 2>&1 | grep -q "ModuleNotFoundError" && echo "config.py correctly absent"

# Verify SizeAwareSLRU is fully removed
grep -r "SizeAwareSLRU" src/rosbag_mcp/ --include="*.py" && echo "FAIL" || echo "OK: SizeAwareSLRU removed"

# Tests
uv run python -m pytest tests/ -v --tb=short

# Lint (14 pre-existing E501 in server.py expected)
uv run ruff check src/ tests/ --select E,F,I,W --target-version py310

# Format
uv run ruff format --check src/ tests/
```
