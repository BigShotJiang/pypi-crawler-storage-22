#!/usr/bin/env python3
"""
rosbag_slam_lint.py

A small CLI to lint rosbag2 metadata for LiDAR/IMU SLAM workflows.
"""

from __future__ import annotations

import argparse
import copy
import fnmatch
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

try:
    import yaml  # type: ignore
except Exception:  # pragma: no cover - handled in main for user-facing message
    yaml = None


@dataclass
class TopicStat:
    name: str
    msg_type: str
    message_count: int
    qos_profiles: str


@dataclass
class BagSummary:
    source: str
    duration_s: float
    message_count: int
    topics: list[TopicStat]


@dataclass
class Issue:
    level: str  # error | warn | info
    code: str
    message: str
    suggestion: str


PROFILE_RULES = {
    "lio": {
        "required_groups": [
            {
                "name": "lidar_points",
                "patterns": [
                    "/points_raw",
                    "/velodyne_points",
                    "/ouster/points",
                    "/livox/lidar",
                    "*/points*",
                ],
                "min_hz": 5.0,
                "min_hz_message": "LiDAR topic average rate looks low (< 5Hz).",
            },
            {
                "name": "imu",
                "patterns": [
                    "/imu",
                    "/imu/data",
                    "/livox/imu",
                    "*/imu*",
                ],
                "min_hz": 50.0,
                "min_hz_message": "IMU topic average rate looks low (< 50Hz).",
            },
        ],
        "recommended_groups": [
            {
                "name": "tf",
                "patterns": ["/tf"],
            },
            {
                "name": "tf_static",
                "patterns": ["/tf_static"],
            },
            {
                "name": "odom",
                "patterns": ["/odom", "*/odom*"],
            },
        ],
    }
}

# Stricter profile for higher-rate LiDAR/IMU datasets.
PROFILE_RULES["lio_glim"] = {
    "required_groups": [
        {
            "name": "lidar_points",
            "patterns": [
                "/points_raw",
                "/velodyne_points",
                "/ouster/points",
                "/livox/lidar",
                "*/points*",
            ],
            "min_hz": 8.0,
            "min_hz_message": "LiDAR topic average rate looks low (< 8Hz).",
        },
        {
            "name": "imu",
            "patterns": [
                "/imu",
                "/imu/data",
                "/livox/imu",
                "*/imu*",
            ],
            "min_hz": 88.0,
            "min_hz_message": "IMU topic average rate looks low (< 88Hz).",
        },
    ],
    "recommended_groups": [
        {
            "name": "tf",
            "patterns": ["/tf"],
        },
        {
            "name": "tf_static",
            "patterns": ["/tf_static"],
        },
        {
            "name": "odom",
            "patterns": ["/odom", "*/odom*"],
        },
    ],
}

PROFILE_RULES["ekf"] = {
    "required_groups": [
        {
            "name": "imu",
            "patterns": [
                "/imu",
                "/imu/data",
                "/livox/imu",
                "*/imu*",
            ],
            "min_hz": 50.0,
            "min_hz_message": "IMU topic average rate looks low (< 50Hz).",
        },
        {
            "name": "wheel_odom",
            "patterns": [
                "/odom",
                "/wheel/odometry",
                "/wheel_odom",
                "*/odom*",
            ],
            "min_hz": 10.0,
            "min_hz_message": "Wheel/Odometry topic average rate looks low (< 10Hz).",
        },
    ],
    "recommended_groups": [
        {
            "name": "tf",
            "patterns": ["/tf"],
        },
        {
            "name": "tf_static",
            "patterns": ["/tf_static"],
        },
    ],
}

PROFILE_RULES["vio"] = {
    "required_groups": [
        {
            "name": "imu",
            "patterns": [
                "/imu",
                "/imu/data",
                "/livox/imu",
                "*/imu*",
            ],
            "min_hz": 100.0,
            "min_hz_message": "IMU topic average rate looks low (< 100Hz).",
        },
        {
            "name": "camera_image",
            "patterns": [
                "/camera/image_raw",
                "/camera/*/image_raw",
                "*/image_raw",
                "*/image_rect*",
            ],
            "min_hz": 10.0,
            "min_hz_message": "Camera topic average rate looks low (< 10Hz).",
        },
    ],
    "recommended_groups": [
        {
            "name": "tf",
            "patterns": ["/tf"],
        },
        {
            "name": "tf_static",
            "patterns": ["/tf_static"],
        },
    ],
}

PROFILE_RULES["wheel_lio"] = {
    "required_groups": [
        {
            "name": "lidar_points",
            "patterns": [
                "/points_raw",
                "/velodyne_points",
                "/ouster/points",
                "/livox/lidar",
                "*/points*",
            ],
            "min_hz": 5.0,
            "min_hz_message": "LiDAR topic average rate looks low (< 5Hz).",
        },
        {
            "name": "imu",
            "patterns": [
                "/imu",
                "/imu/data",
                "/livox/imu",
                "*/imu*",
            ],
            "min_hz": 50.0,
            "min_hz_message": "IMU topic average rate looks low (< 50Hz).",
        },
        {
            "name": "wheel_odom",
            "patterns": [
                "/odom",
                "/wheel/odometry",
                "/wheel_odom",
                "*/odom*",
            ],
            "min_hz": 10.0,
            "min_hz_message": "Wheel/Odometry topic average rate looks low (< 10Hz).",
        },
    ],
    "recommended_groups": [
        {
            "name": "tf",
            "patterns": ["/tf"],
        },
        {
            "name": "tf_static",
            "patterns": ["/tf_static"],
        },
    ],
}

DEFAULT_CHECKS = {
    "short_recording_s": 60.0,
    "low_message_count": 1000,
}


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _topic_matches(name: str, patterns: list[str]) -> bool:
    return any(fnmatch.fnmatch(name, pattern) for pattern in patterns)


def load_bag_summary(path: str) -> BagSummary:
    input_path = Path(path)
    if input_path.is_dir():
        metadata_path = input_path / "metadata.yaml"
    else:
        metadata_path = input_path

    if not metadata_path.exists():
        raise FileNotFoundError(f"metadata file not found: {metadata_path}")

    if yaml is None:
        raise RuntimeError(
            "PyYAML is required. Install with: python3 -m pip install pyyaml"
        )

    parsed = yaml.safe_load(metadata_path.read_text(encoding="utf-8")) or {}
    root = parsed.get("rosbag2_bagfile_information", {})

    duration_ns = _safe_int(root.get("duration", {}).get("nanoseconds", 0))
    duration_s = duration_ns / 1_000_000_000 if duration_ns > 0 else 0.0
    message_count = _safe_int(root.get("message_count", 0))

    topics: list[TopicStat] = []
    for entry in root.get("topics_with_message_count", []) or []:
        topic_meta = entry.get("topic_metadata", {}) or {}
        name = str(topic_meta.get("name", ""))
        msg_type = str(topic_meta.get("type", ""))
        count = _safe_int(entry.get("message_count", 0))
        qos_profiles = str(topic_meta.get("offered_qos_profiles", ""))
        topics.append(
            TopicStat(
                name=name,
                msg_type=msg_type,
                message_count=count,
                qos_profiles=qos_profiles,
            )
        )

    return BagSummary(
        source=str(metadata_path),
        duration_s=duration_s,
        message_count=message_count,
        topics=topics,
    )


def _resolve_rules_and_checks(
    profile: str,
    config_path: str,
) -> tuple[dict[str, Any], dict[str, float | int]]:
    if yaml is None:
        raise RuntimeError(
            "PyYAML is required. Install with: python3 -m pip install pyyaml"
        )

    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"config file not found: {path}")

    parsed = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(parsed, dict):
        raise ValueError("config root must be a mapping")

    rules = copy.deepcopy(PROFILE_RULES)
    checks: dict[str, float | int] = dict(DEFAULT_CHECKS)

    checks_cfg = parsed.get("checks", {}) or {}
    if not isinstance(checks_cfg, dict):
        raise ValueError("config.checks must be a mapping")

    for key in checks_cfg.keys():
        if key not in DEFAULT_CHECKS:
            raise ValueError(f"unsupported checks key: {key}")

    if "short_recording_s" in checks_cfg:
        short_s = _safe_float(checks_cfg["short_recording_s"], -1.0)
        if short_s <= 0.0:
            raise ValueError("checks.short_recording_s must be > 0")
        checks["short_recording_s"] = short_s

    if "low_message_count" in checks_cfg:
        low_count = _safe_int(checks_cfg["low_message_count"], -1)
        if low_count < 0:
            raise ValueError("checks.low_message_count must be >= 0")
        checks["low_message_count"] = low_count

    profiles_cfg = parsed.get("profiles", {}) or {}
    if not isinstance(profiles_cfg, dict):
        raise ValueError("config.profiles must be a mapping")

    profile_cfg = profiles_cfg.get(profile, {}) or {}
    if not isinstance(profile_cfg, dict):
        raise ValueError(f"config.profiles.{profile} must be a mapping")

    required_groups_cfg = profile_cfg.get("required_groups", {}) or {}
    if not isinstance(required_groups_cfg, dict):
        raise ValueError(f"config.profiles.{profile}.required_groups must be a mapping")

    group_map = {
        str(group.get("name", "")): group
        for group in rules[profile].get("required_groups", [])
    }

    for group_name, overrides in required_groups_cfg.items():
        if group_name not in group_map:
            raise ValueError(
                f"unknown required group for profile '{profile}': {group_name}"
            )
        if not isinstance(overrides, dict):
            raise ValueError(
                f"config.profiles.{profile}.required_groups.{group_name} must be a mapping"
            )

        for key in overrides.keys():
            if key != "min_hz":
                raise ValueError(
                    f"unsupported key in required group override '{group_name}': {key}"
                )

        if "min_hz" in overrides:
            min_hz = _safe_float(overrides["min_hz"], -1.0)
            if min_hz <= 0.0:
                raise ValueError(
                    f"config.profiles.{profile}.required_groups.{group_name}.min_hz must be > 0"
                )
            group_map[group_name]["min_hz"] = min_hz

    return rules, checks


def analyze(
    summary: BagSummary,
    profile: str,
    profile_rules: dict[str, Any] | None = None,
    checks: dict[str, float | int] | None = None,
) -> list[Issue]:
    issues: list[Issue] = []
    effective_rules = profile_rules if profile_rules is not None else PROFILE_RULES
    effective_checks: dict[str, float | int] = dict(DEFAULT_CHECKS)
    if checks:
        effective_checks.update(checks)

    short_recording_s = _safe_float(
        effective_checks.get("short_recording_s", DEFAULT_CHECKS["short_recording_s"]),
        DEFAULT_CHECKS["short_recording_s"],
    )
    low_message_count = _safe_int(
        effective_checks.get("low_message_count", DEFAULT_CHECKS["low_message_count"]),
        DEFAULT_CHECKS["low_message_count"],
    )

    if summary.duration_s <= 0:
        issues.append(
            Issue(
                level="error",
                code="ZERO_DURATION",
                message="Bag duration is zero or missing.",
                suggestion="Re-record data and ensure rosbag is closed cleanly.",
            )
        )
        return issues

    if summary.duration_s < short_recording_s:
        issues.append(
            Issue(
                level="warn",
                code="SHORT_RECORDING",
                message=(
                    f"Recording duration is short ({summary.duration_s:.1f}s). "
                    f"Expected >= {short_recording_s:.1f}s."
                ),
                suggestion="Capture at least 2-5 minutes including turns/loops.",
            )
        )

    if summary.message_count < low_message_count:
        issues.append(
            Issue(
                level="warn",
                code="LOW_MESSAGE_COUNT",
                message=(
                    f"Total message count is low ({summary.message_count}). "
                    f"Expected >= {low_message_count}."
                ),
                suggestion="Check topic QoS and sensor drivers during recording.",
            )
        )

    rules = effective_rules.get(profile)
    if not rules:
        return issues

    for group in rules["required_groups"]:
        matches = [
            topic
            for topic in summary.topics
            if _topic_matches(topic.name, group["patterns"])
        ]
        if not matches:
            issues.append(
                Issue(
                    level="error",
                    code="MISSING_REQUIRED_TOPICS",
                    message=(
                        f"Missing required topic group '{group['name']}' "
                        f"(patterns={group['patterns']})."
                    ),
                    suggestion=(
                        "Update launch/config and verify remapping before recording."
                    ),
                )
            )
            continue

        total_group_msgs = sum(topic.message_count for topic in matches)
        group_hz = total_group_msgs / summary.duration_s
        min_hz = float(group.get("min_hz", 0.0))
        if min_hz > 0 and group_hz < min_hz:
            issues.append(
                Issue(
                    level="warn",
                    code="LOW_TOPIC_RATE",
                    message=(
                        f"{group['name']} average rate is {group_hz:.2f}Hz; "
                        f"recommended >= {min_hz:.1f}Hz. {group['min_hz_message']}"
                    ),
                    suggestion=(
                        "Check sensor frame rate, network bandwidth, and QoS reliability."
                    ),
                )
            )

    for group in rules["recommended_groups"]:
        matches = [
            topic
            for topic in summary.topics
            if _topic_matches(topic.name, group["patterns"])
        ]
        if not matches:
            issues.append(
                Issue(
                    level="info",
                    code="MISSING_RECOMMENDED_TOPICS",
                    message=(
                        f"Recommended topic group '{group['name']}' not found "
                        f"(patterns={group['patterns']})."
                    ),
                    suggestion=(
                        "This is optional, but useful for downstream debug/visualization."
                    ),
                )
            )

    return issues


def summarize_topics(summary: BagSummary) -> list[dict[str, Any]]:
    rows = []
    for topic in summary.topics:
        hz = topic.message_count / summary.duration_s if summary.duration_s > 0 else 0.0
        rows.append(
            {
                "name": topic.name,
                "type": topic.msg_type,
                "message_count": topic.message_count,
                "avg_hz": round(hz, 3),
            }
        )
    rows.sort(key=lambda row: row["message_count"], reverse=True)
    return rows


def should_fail(issues: list[Issue], fail_on: str) -> bool:
    if fail_on == "none":
        return False
    if fail_on == "error":
        return any(issue.level == "error" for issue in issues)
    if fail_on == "warn":
        return any(issue.level in {"error", "warn"} for issue in issues)
    return False


def print_human(summary: BagSummary, issues: list[Issue]) -> None:
    print("== rosbag_slam_lint ==")
    print(f"source: {summary.source}")
    print(f"duration_s: {summary.duration_s:.3f}")
    print(f"message_count: {summary.message_count}")
    print(f"topic_count: {len(summary.topics)}")
    print("")

    print("topics:")
    for row in summarize_topics(summary):
        print(
            f"  - {row['name']} ({row['type']}): "
            f"{row['message_count']} msgs, {row['avg_hz']:.3f} Hz"
        )
    print("")

    if not issues:
        print("diagnostics: OK (no issues)")
        return

    print("diagnostics:")
    for issue in issues:
        print(f"  [{issue.level.upper()}] {issue.code}: {issue.message}")
        print(f"    suggestion: {issue.suggestion}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Lint rosbag2 metadata for LiDAR/IMU SLAM use cases."
    )
    parser.add_argument(
        "input_path",
        help="Path to metadata.yaml or bag directory containing metadata.yaml",
    )
    parser.add_argument(
        "--profile",
        default="lio",
        choices=sorted(PROFILE_RULES.keys()),
        help="Validation profile to use (default: lio)",
    )
    parser.add_argument(
        "--config",
        help=(
            "Optional YAML config for threshold overrides. "
            "Supports checks.{short_recording_s,low_message_count} and "
            "profiles.<profile>.required_groups.<group>.min_hz"
        ),
    )
    parser.add_argument(
        "--fail-on",
        default="error",
        choices=["none", "error", "warn"],
        help="Exit non-zero when diagnostics reach this severity (default: error)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output diagnostics as JSON",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    rules: dict[str, Any] = PROFILE_RULES
    checks: dict[str, float | int] = dict(DEFAULT_CHECKS)

    if args.config:
        try:
            rules, checks = _resolve_rules_and_checks(args.profile, args.config)
        except Exception as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2

    try:
        summary = load_bag_summary(args.input_path)
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    issues = analyze(summary, profile=args.profile, profile_rules=rules, checks=checks)

    if args.json:
        required_group_min_hz = {
            group["name"]: float(group.get("min_hz", 0.0))
            for group in rules[args.profile].get("required_groups", [])
        }
        payload = {
            "summary": {
                "source": summary.source,
                "duration_s": summary.duration_s,
                "message_count": summary.message_count,
                "topic_count": len(summary.topics),
                "topics": summarize_topics(summary),
            },
            "effective_thresholds": {
                "short_recording_s": _safe_float(
                    checks.get("short_recording_s", DEFAULT_CHECKS["short_recording_s"])
                ),
                "low_message_count": _safe_int(
                    checks.get(
                        "low_message_count", DEFAULT_CHECKS["low_message_count"]
                    )
                ),
                "required_group_min_hz": required_group_min_hz,
            },
            "issues": [asdict(issue) for issue in issues],
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print_human(summary, issues)

    return 1 if should_fail(issues, args.fail_on) else 0


if __name__ == "__main__":
    raise SystemExit(main())
