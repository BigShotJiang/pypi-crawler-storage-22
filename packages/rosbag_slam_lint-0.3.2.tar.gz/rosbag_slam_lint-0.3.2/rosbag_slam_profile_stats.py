#!/usr/bin/env python3
"""
rosbag_slam_profile_stats.py

Batch helper to inspect rosbag2 metadata statistics and tune profile thresholds.
"""

from __future__ import annotations

import argparse
import fnmatch
import json
import math
import statistics
import sys
from pathlib import Path
from typing import Any

from rosbag_slam_lint import PROFILE_RULES, BagSummary, load_bag_summary


def _percentile(values: list[float], percentile: float) -> float | None:
    if not values:
        return None
    if len(values) == 1:
        return values[0]

    ordered = sorted(values)
    k = (len(ordered) - 1) * (percentile / 100.0)
    floor_index = int(math.floor(k))
    ceil_index = int(math.ceil(k))
    if floor_index == ceil_index:
        return ordered[floor_index]
    ratio = k - floor_index
    return ordered[floor_index] * (1.0 - ratio) + ordered[ceil_index] * ratio


def _stats(values: list[float]) -> dict[str, float | int | None]:
    if not values:
        return {
            "count": 0,
            "min": None,
            "p10": None,
            "p25": None,
            "p50": None,
            "p75": None,
            "p90": None,
            "max": None,
            "mean": None,
        }
    return {
        "count": len(values),
        "min": round(min(values), 3),
        "p10": round(_percentile(values, 10.0) or 0.0, 3),
        "p25": round(_percentile(values, 25.0) or 0.0, 3),
        "p50": round(_percentile(values, 50.0) or 0.0, 3),
        "p75": round(_percentile(values, 75.0) or 0.0, 3),
        "p90": round(_percentile(values, 90.0) or 0.0, 3),
        "max": round(max(values), 3),
        "mean": round(statistics.mean(values), 3),
    }


def _topic_matches(name: str, patterns: list[str]) -> bool:
    return any(fnmatch.fnmatch(name, pattern) for pattern in patterns)


def _group_rate(summary: BagSummary, patterns: list[str]) -> float | None:
    if summary.duration_s <= 0:
        return None
    matched = [topic for topic in summary.topics if _topic_matches(topic.name, patterns)]
    if not matched:
        return None
    total_messages = sum(topic.message_count for topic in matched)
    return total_messages / summary.duration_s


def _discover_metadata_paths(inputs: list[str], pattern: str) -> list[Path]:
    found: list[Path] = []
    seen: set[Path] = set()
    for raw in inputs:
        path = Path(raw)
        if not path.exists():
            raise FileNotFoundError(f"path not found: {path}")
        if path.is_file():
            resolved = path.resolve()
            if resolved not in seen:
                found.append(path)
                seen.add(resolved)
            continue
        for candidate in sorted(path.rglob(pattern)):
            if candidate.is_file():
                resolved = candidate.resolve()
                if resolved not in seen:
                    found.append(candidate)
                    seen.add(resolved)
    return found


def build_report(
    summaries: list[BagSummary],
    profile: str,
    suggest_percentile: float,
    suggest_scale: float,
) -> dict[str, Any]:
    rules = PROFILE_RULES[profile]
    durations = [summary.duration_s for summary in summaries]
    message_counts = [float(summary.message_count) for summary in summaries]

    required_groups: list[dict[str, Any]] = []
    for group in rules["required_groups"]:
        rates: list[float] = []
        missing_count = 0
        for summary in summaries:
            rate = _group_rate(summary, group["patterns"])
            if rate is None:
                missing_count += 1
            else:
                rates.append(rate)

        observed_stats = _stats(rates)
        percentile_value = _percentile(rates, suggest_percentile)
        if percentile_value is None:
            suggested_min = None
        else:
            suggested_min = round(max(0.1, percentile_value * suggest_scale), 1)

        required_groups.append(
            {
                "name": group["name"],
                "current_min_hz": float(group.get("min_hz", 0.0)),
                "missing_count": missing_count,
                "available_count": len(rates),
                "observed_hz_stats": observed_stats,
                "suggested_min_hz": suggested_min,
                "suggestion_formula": (
                    f"p{suggest_percentile:g} * {suggest_scale:g}"
                    if suggested_min is not None
                    else None
                ),
            }
        )

    return {
        "profile": profile,
        "bags_scanned": len(summaries),
        "duration_s_stats": _stats(durations),
        "message_count_stats": _stats(message_counts),
        "required_groups": required_groups,
    }


def _format_stat(value: float | int | None) -> str:
    if value is None:
        return "n/a"
    if isinstance(value, int):
        return str(value)
    return f"{value:.3f}"


def print_human(report: dict[str, Any]) -> None:
    print("== rosbag_slam_profile_stats ==")
    print(f"profile: {report['profile']}")
    print(f"bags_scanned: {report['bags_scanned']}")
    print("")

    duration = report["duration_s_stats"]
    print(
        "duration_s:"
        f" min={_format_stat(duration['min'])}"
        f" p10={_format_stat(duration['p10'])}"
        f" p50={_format_stat(duration['p50'])}"
        f" p90={_format_stat(duration['p90'])}"
        f" max={_format_stat(duration['max'])}"
    )
    message_count = report["message_count_stats"]
    print(
        "message_count:"
        f" min={_format_stat(message_count['min'])}"
        f" p10={_format_stat(message_count['p10'])}"
        f" p50={_format_stat(message_count['p50'])}"
        f" p90={_format_stat(message_count['p90'])}"
        f" max={_format_stat(message_count['max'])}"
    )
    print("")

    print("required_groups:")
    for group in report["required_groups"]:
        observed = group["observed_hz_stats"]
        print(
            f"  - {group['name']}: "
            f"missing={group['missing_count']} "
            f"available={group['available_count']} "
            f"current_min_hz={group['current_min_hz']:.1f}"
        )
        print(
            "    observed_hz:"
            f" p10={_format_stat(observed['p10'])}"
            f" p50={_format_stat(observed['p50'])}"
            f" p90={_format_stat(observed['p90'])}"
            f" max={_format_stat(observed['max'])}"
        )
        if group["suggested_min_hz"] is not None:
            print(
                "    suggested_min_hz:"
                f" {group['suggested_min_hz']:.1f}"
                f" ({group['suggestion_formula']})"
            )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compute profile statistics from multiple rosbag2 metadata files."
    )
    parser.add_argument(
        "inputs",
        nargs="+",
        help=(
            "metadata.yaml files or directories. "
            "Directories are searched recursively."
        ),
    )
    parser.add_argument(
        "--pattern",
        default="metadata.yaml",
        help="Filename pattern for recursive directory search (default: metadata.yaml)",
    )
    parser.add_argument(
        "--profile",
        default="lio",
        choices=sorted(PROFILE_RULES.keys()),
        help="Profile to inspect (default: lio)",
    )
    parser.add_argument(
        "--suggest-percentile",
        type=float,
        default=10.0,
        help="Percentile used for suggested min_hz (default: 10)",
    )
    parser.add_argument(
        "--suggest-scale",
        type=float,
        default=0.8,
        help="Multiplier used for suggested min_hz (default: 0.8)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output JSON report",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not (0.0 <= args.suggest_percentile <= 100.0):
        print("error: --suggest-percentile must be in [0, 100]", file=sys.stderr)
        return 2
    if args.suggest_scale <= 0.0:
        print("error: --suggest-scale must be > 0", file=sys.stderr)
        return 2

    try:
        metadata_paths = _discover_metadata_paths(args.inputs, args.pattern)
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    if not metadata_paths:
        print("error: no metadata files found", file=sys.stderr)
        return 2

    summaries: list[BagSummary] = []
    for path in metadata_paths:
        try:
            summaries.append(load_bag_summary(str(path)))
        except Exception as exc:
            print(f"error: failed to load {path}: {exc}", file=sys.stderr)
            return 2

    report = build_report(
        summaries,
        profile=args.profile,
        suggest_percentile=args.suggest_percentile,
        suggest_scale=args.suggest_scale,
    )

    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_human(report)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
