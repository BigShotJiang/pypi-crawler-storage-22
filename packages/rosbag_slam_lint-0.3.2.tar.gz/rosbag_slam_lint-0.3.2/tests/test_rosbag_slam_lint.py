from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "tests" / "fixtures"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import rosbag_slam_lint as lint


def _fixture(name: str) -> Path:
    return FIXTURES / name


def _run_cli(script: str, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, script, *args],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )


def test_analyze_good_has_no_issues() -> None:
    summary = lint.load_bag_summary(str(_fixture("good_lio_metadata.yaml")))
    issues = lint.analyze(summary, "lio")
    assert issues == []


def test_analyze_missing_imu_has_error() -> None:
    summary = lint.load_bag_summary(str(_fixture("missing_imu_metadata.yaml")))
    issues = lint.analyze(summary, "lio")
    assert any(issue.code == "MISSING_REQUIRED_TOPICS" for issue in issues)


def test_zero_duration_returns_single_error() -> None:
    summary = lint.load_bag_summary(str(_fixture("zero_duration_metadata.yaml")))
    issues = lint.analyze(summary, "lio")
    assert len(issues) == 1
    assert issues[0].code == "ZERO_DURATION"
    assert issues[0].level == "error"


def test_cli_json_output() -> None:
    result = _run_cli("rosbag_slam_lint.py", str(_fixture("good_lio_metadata.yaml")), "--json")
    assert result.returncode == 0
    payload = json.loads(result.stdout)
    assert payload["summary"]["topic_count"] == 5
    assert payload["issues"] == []


def test_cli_fail_on_warn_returns_nonzero() -> None:
    result = _run_cli(
        "rosbag_slam_lint.py",
        str(_fixture("low_rate_metadata.yaml")),
        "--fail-on",
        "warn",
    )
    assert result.returncode == 1
    assert "LOW_TOPIC_RATE" in result.stdout


def test_profile_stats_cli_json() -> None:
    result = _run_cli(
        "rosbag_slam_profile_stats.py",
        str(_fixture("good_lio_metadata.yaml")),
        str(_fixture("missing_imu_metadata.yaml")),
        str(_fixture("low_rate_metadata.yaml")),
        "--json",
    )
    assert result.returncode == 0
    payload = json.loads(result.stdout)
    assert payload["bags_scanned"] == 3
    assert payload["profile"] == "lio"
    group_names = {group["name"] for group in payload["required_groups"]}
    assert {"lidar_points", "imu"}.issubset(group_names)


def test_lio_glim_profile_passes_good_fixture() -> None:
    result = _run_cli(
        "rosbag_slam_lint.py",
        str(_fixture("good_lio_metadata.yaml")),
        "--profile",
        "lio_glim",
        "--fail-on",
        "warn",
    )
    assert result.returncode == 0


def test_cli_config_override_profile_thresholds() -> None:
    result = _run_cli(
        "rosbag_slam_lint.py",
        str(_fixture("good_lio_metadata.yaml")),
        "--profile",
        "lio_glim",
        "--config",
        str(_fixture("config_override_glim_strict.yaml")),
        "--fail-on",
        "warn",
    )
    assert result.returncode == 1
    assert "LOW_TOPIC_RATE" in result.stdout
    assert "recommended >= 120.0Hz" in result.stdout


def test_cli_config_override_checks() -> None:
    result = _run_cli(
        "rosbag_slam_lint.py",
        str(_fixture("good_lio_metadata.yaml")),
        "--config",
        str(_fixture("config_override_checks.yaml")),
        "--fail-on",
        "warn",
    )
    assert result.returncode == 1
    assert "SHORT_RECORDING" in result.stdout


def test_cli_invalid_config_returns_error() -> None:
    result = _run_cli(
        "rosbag_slam_lint.py",
        str(_fixture("good_lio_metadata.yaml")),
        "--config",
        str(_fixture("config_invalid_unknown_group.yaml")),
    )
    assert result.returncode == 2
    assert "unknown required group" in result.stderr


def test_ekf_profile_passes_good_fixture() -> None:
    result = _run_cli(
        "rosbag_slam_lint.py",
        str(_fixture("good_lio_metadata.yaml")),
        "--profile",
        "ekf",
        "--fail-on",
        "warn",
    )
    assert result.returncode == 0


def test_wheel_lio_profile_passes_good_fixture() -> None:
    result = _run_cli(
        "rosbag_slam_lint.py",
        str(_fixture("good_lio_metadata.yaml")),
        "--profile",
        "wheel_lio",
        "--fail-on",
        "warn",
    )
    assert result.returncode == 0


def test_vio_profile_requires_camera_on_good_lio_fixture() -> None:
    result = _run_cli(
        "rosbag_slam_lint.py",
        str(_fixture("good_lio_metadata.yaml")),
        "--profile",
        "vio",
        "--fail-on",
        "error",
    )
    assert result.returncode == 1
    assert "MISSING_REQUIRED_TOPICS" in result.stdout


def test_vio_profile_passes_vio_fixture() -> None:
    result = _run_cli(
        "rosbag_slam_lint.py",
        str(_fixture("vio_good_metadata.yaml")),
        "--profile",
        "vio",
        "--fail-on",
        "warn",
    )
    assert result.returncode == 0
