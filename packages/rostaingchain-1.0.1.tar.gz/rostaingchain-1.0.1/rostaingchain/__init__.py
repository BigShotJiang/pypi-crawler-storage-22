from .core import RostaingBrain

__version__ = "1.0.1"
__author__ = "Davila Rostaing"
__all__ = ["RostaingBrain"]