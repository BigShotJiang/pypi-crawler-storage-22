"""
Rotalabs - Trust Intelligence Research

https://rotalabs.ai
"""

__version__ = "0.0.1"
__author__ = "Rotalabs"
__email__ = "research@rotalabs.ai"
