"""Version information for rotalabs-accel."""

__version__ = "0.2.0"
