"""Version information for rotalabs-audit."""

__version__ = "0.1.0"
