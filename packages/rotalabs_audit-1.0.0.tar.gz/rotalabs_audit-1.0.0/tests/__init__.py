"""Tests for rotalabs-audit package."""
