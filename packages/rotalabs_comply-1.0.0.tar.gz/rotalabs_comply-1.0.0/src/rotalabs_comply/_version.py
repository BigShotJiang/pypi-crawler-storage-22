"""Version information for rotalabs-comply."""

__version__ = "0.2.0"
