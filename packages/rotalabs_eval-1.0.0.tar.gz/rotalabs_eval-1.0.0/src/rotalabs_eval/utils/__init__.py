"""Utility functions."""
from __future__ import annotations

__all__: list = []
