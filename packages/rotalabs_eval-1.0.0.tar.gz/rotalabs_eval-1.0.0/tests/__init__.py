"""Test suite for rotalabs-eval package."""
