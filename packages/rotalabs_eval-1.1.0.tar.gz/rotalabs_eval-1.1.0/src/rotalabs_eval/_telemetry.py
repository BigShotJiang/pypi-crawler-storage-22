"""Telemetry integration for rotalabs-eval.

This module provides a safe wrapper around the rotalabs telemetry system.
Telemetry is opt-in only and will gracefully degrade if not configured.
"""

from __future__ import annotations

from typing import Any

# Try to import from rotalabs telemetry, fall back to no-ops if not available
try:
    from rotalabs._telemetry import is_enabled, report_event
except ImportError:
    def report_event(*args: Any, **kwargs: Any) -> None:
        """No-op when rotalabs telemetry is not installed."""
        pass

    def is_enabled() -> bool:
        """Return False when rotalabs telemetry is not installed."""
        return False


def report_metric_computed(
    metric_name: str,
    n_samples: int,
    value: float,
    has_per_example_scores: bool = False,
) -> None:
    """Report when a metric is computed.

    Args:
        metric_name: Name of the metric.
        n_samples: Number of samples evaluated.
        value: The computed metric value.
        has_per_example_scores: Whether per-example scores are available.
    """
    if not is_enabled():
        return

    report_event(
        "eval.metric.computed",
        {
            "metric_name": metric_name,
            "n_samples": n_samples,
            "value": value,
            "has_per_example_scores": has_per_example_scores,
        },
    )


def report_evaluation_run(
    task_name: str | None,
    n_samples: int,
    n_metrics: int,
    duration_seconds: float | None = None,
) -> None:
    """Report when a full evaluation run completes.

    Args:
        task_name: Name of the evaluation task.
        n_samples: Number of samples evaluated.
        n_metrics: Number of metrics computed.
        duration_seconds: Optional duration of the run.
    """
    if not is_enabled():
        return

    report_event(
        "eval.run.completed",
        {
            "task_name": task_name,
            "n_samples": n_samples,
            "n_metrics": n_metrics,
            "duration_seconds": duration_seconds,
        },
    )


def report_dataset_loaded(
    dataset_name: str,
    n_samples: int,
    source: str | None = None,
) -> None:
    """Report when a dataset is loaded.

    Args:
        dataset_name: Name of the dataset.
        n_samples: Number of samples in the dataset.
        source: Optional source of the dataset (e.g., 'file', 'huggingface').
    """
    if not is_enabled():
        return

    report_event(
        "eval.dataset.loaded",
        {
            "dataset_name": dataset_name,
            "n_samples": n_samples,
            "source": source,
        },
    )


def report_inference_completed(
    provider: str,
    model: str,
    n_samples: int,
    total_tokens: int | None = None,
    duration_seconds: float | None = None,
) -> None:
    """Report when batch inference completes.

    Args:
        provider: Name of the inference provider (e.g., 'openai', 'ollama').
        model: Name of the model used.
        n_samples: Number of samples processed.
        total_tokens: Optional total tokens used.
        duration_seconds: Optional duration of inference.
    """
    if not is_enabled():
        return

    report_event(
        "eval.inference.completed",
        {
            "provider": provider,
            "model": model,
            "n_samples": n_samples,
            "total_tokens": total_tokens,
            "duration_seconds": duration_seconds,
        },
    )


def report_llm_judge_evaluation(
    judge_model: str,
    n_samples: int,
    criteria: str | None = None,
    mean_score: float | None = None,
) -> None:
    """Report when LLM-as-judge evaluation is performed.

    Args:
        judge_model: Name of the judge model.
        n_samples: Number of samples evaluated.
        criteria: Optional evaluation criteria used.
        mean_score: Optional mean score from the evaluation.
    """
    if not is_enabled():
        return

    report_event(
        "eval.llm_judge.completed",
        {
            "judge_model": judge_model,
            "n_samples": n_samples,
            "criteria": criteria,
            "mean_score": mean_score,
        },
    )
