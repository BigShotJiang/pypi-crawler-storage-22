# Agents

FTCS agents with field-theoretic memory capabilities.

## AgentConfig

::: rotalabs_ftms.agents.ftcs_agent.AgentConfig

## MemoryEntry

::: rotalabs_ftms.agents.ftcs_agent.MemoryEntry

## FTCSAgent

::: rotalabs_ftms.agents.ftcs_agent.FTCSAgent
