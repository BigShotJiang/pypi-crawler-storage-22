"""Version information for rotalabs-fieldmem."""

__version__ = "0.1.0"
