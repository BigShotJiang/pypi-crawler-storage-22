"""Tests for rotalabs-ftms package."""
