# Fields

Memory field implementations based on PDE solvers.

## FieldConfig

::: rotalabs_ftms.fields.memory_field.FieldConfig

## MemoryField

::: rotalabs_ftms.fields.memory_field.MemoryField
