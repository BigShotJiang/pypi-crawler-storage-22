"""Version information for rotalabs-ftms."""

__version__ = "0.1.1"
