"""FTMS-enabled agents.

Provides agents with field-theoretic memory capabilities.
"""

from rotalabs_ftms.agents.ftcs_agent import (
    FTCSAgent,
    AgentConfig,
    MemoryEntry,
)
from rotalabs_ftms.agents.coordinator import (
    MultiAgentCoordinator,
    CouplingConfig as CoordinatorCouplingConfig,
    AgentGroup,
)
from rotalabs_ftms.agents.coupling import (
    FieldCoupler,
    CouplingConfig,
    CouplingTopology,
)
from rotalabs_ftms.agents.collective import (
    CollectiveMemory,
    CollectiveMemoryPool,
)
from rotalabs_ftms.agents.multi_agent import (
    MultiAgentSystem,
    MultiAgentConfig,
)

__all__ = [
    # Core agent
    "FTCSAgent",
    "AgentConfig",
    "MemoryEntry",
    # Coordination
    "MultiAgentCoordinator",
    "CoordinatorCouplingConfig",
    "AgentGroup",
    # Coupling
    "FieldCoupler",
    "CouplingConfig",
    "CouplingTopology",
    # Collective memory
    "CollectiveMemory",
    "CollectiveMemoryPool",
    # Multi-agent system
    "MultiAgentSystem",
    "MultiAgentConfig",
]
