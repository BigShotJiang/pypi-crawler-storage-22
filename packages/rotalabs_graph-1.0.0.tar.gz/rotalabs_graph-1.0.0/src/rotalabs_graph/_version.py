"""Version information for rotalabs-graph."""

__version__ = "0.1.0"
