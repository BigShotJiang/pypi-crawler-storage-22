"""Tests for rotalabs-graph package."""
