# Observer Effect Monitor

Monitor for behavioral changes when AI systems are observed.

## ObserverEffectMonitor

::: rotalabs_probe.detectors.observer_effect.ObserverEffectMonitor

## Alert

::: rotalabs_probe.Alert

## AlertSeverity

::: rotalabs_probe.AlertSeverity

## AlertHandler

::: rotalabs_probe.AlertHandler

## ConsoleAlertHandler

::: rotalabs_probe.ConsoleAlertHandler
