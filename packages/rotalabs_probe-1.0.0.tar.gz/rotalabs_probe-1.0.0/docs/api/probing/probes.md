# Probes

Linear probes and steering vectors for activation analysis.

## LinearProbe

::: rotalabs_probe.probing.probes.LinearProbe

## SteeringVector

::: rotalabs_probe.probing.vectors.SteeringVector

## extract_caa_vector

::: rotalabs_probe.probing.extraction.extract_caa_vector
