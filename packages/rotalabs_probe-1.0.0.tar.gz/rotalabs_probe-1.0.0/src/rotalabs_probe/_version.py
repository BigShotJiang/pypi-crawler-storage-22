"""Version information for rotalabs-probe."""

__version__ = "0.1.0"
