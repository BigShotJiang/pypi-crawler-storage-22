"""Telemetry integration for rotalabs-probe.

This module provides a safe wrapper around the rotalabs telemetry system.
Telemetry is opt-in only and will gracefully degrade if not configured.
"""

from __future__ import annotations

from typing import Any

# Try to import from rotalabs telemetry, fall back to no-ops if not available
try:
    from rotalabs._telemetry import is_enabled, report_event
except ImportError:
    def report_event(*args: Any, **kwargs: Any) -> None:
        """No-op when rotalabs telemetry is not installed."""
        pass

    def is_enabled() -> bool:
        """Return False when rotalabs telemetry is not installed."""
        return False


def report_detector_initialized(
    detector_name: str,
    config: dict[str, Any] | None = None,
) -> None:
    """Report when a detector is initialized.

    Args:
        detector_name: Name of the detector class.
        config: Optional configuration parameters.
    """
    if not is_enabled():
        return

    report_event(
        "probe.detector.initialized",
        {
            "detector_name": detector_name,
            "config": config or {},
        },
    )


def report_detector_fit(
    detector_name: str,
    n_samples: int,
) -> None:
    """Report when a detector is fitted with baseline data.

    Args:
        detector_name: Name of the detector class.
        n_samples: Number of samples used for fitting.
    """
    if not is_enabled():
        return

    report_event(
        "probe.detector.fitted",
        {
            "detector_name": detector_name,
            "n_samples": n_samples,
        },
    )


def report_detection_run(
    detector_name: str,
    detected: bool,
    confidence: float,
    detection_method: str | None = None,
) -> None:
    """Report when a detection is performed.

    Args:
        detector_name: Name of the detector class.
        detected: Whether the pattern was detected.
        confidence: Confidence score of the detection.
        detection_method: Optional method that triggered detection.
    """
    if not is_enabled():
        return

    report_event(
        "probe.detection.run",
        {
            "detector_name": detector_name,
            "detected": detected,
            "confidence": confidence,
            "detection_method": detection_method,
        },
    )


def report_sandbagging_detection(
    detected: bool,
    confidence: float,
    context_sensitivity: float,
    difficulty_correlation: float,
    imitation_score: float,
    detection_method: str | None = None,
) -> None:
    """Report a sandbagging detection result.

    Args:
        detected: Whether sandbagging was detected.
        confidence: Overall confidence score.
        context_sensitivity: Score from context analysis.
        difficulty_correlation: Score from difficulty analysis.
        imitation_score: Score from imitation detection.
        detection_method: Which method triggered the detection.
    """
    if not is_enabled():
        return

    report_event(
        "probe.sandbagging.detected",
        {
            "detected": detected,
            "confidence": confidence,
            "context_sensitivity": context_sensitivity,
            "difficulty_correlation": difficulty_correlation,
            "imitation_score": imitation_score,
            "detection_method": detection_method,
        },
    )


def report_awareness_detection(
    awareness_probability: float,
    kl_divergence: float,
) -> None:
    """Report a situational awareness detection result.

    Args:
        awareness_probability: Probability of situational awareness.
        kl_divergence: KL divergence from baseline.
    """
    if not is_enabled():
        return

    report_event(
        "probe.awareness.detected",
        {
            "awareness_probability": awareness_probability,
            "kl_divergence": kl_divergence,
        },
    )


def report_observer_effect_alert(
    feature: str,
    severity: str,
    z_score: float,
    production_value: float,
    baseline_value: float,
) -> None:
    """Report an observer effect alert.

    Args:
        feature: The feature that diverged.
        severity: Alert severity level.
        z_score: Z-score that triggered the alert.
        production_value: Current production value.
        baseline_value: Baseline value from evaluation.
    """
    if not is_enabled():
        return

    report_event(
        "probe.observer_effect.alert",
        {
            "feature": feature,
            "severity": severity,
            "z_score": z_score,
            "production_value": production_value,
            "baseline_value": baseline_value,
        },
    )
