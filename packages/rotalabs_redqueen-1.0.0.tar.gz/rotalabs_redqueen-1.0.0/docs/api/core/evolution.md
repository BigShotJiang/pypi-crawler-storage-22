# Evolution

The main evolution engine.

## evolve

::: rotalabs_redqueen.evolve

## Evolution

::: rotalabs_redqueen.core.evolution.Evolution

## EvolutionConfig

::: rotalabs_redqueen.EvolutionConfig

## EvolutionResult

::: rotalabs_redqueen.EvolutionResult
