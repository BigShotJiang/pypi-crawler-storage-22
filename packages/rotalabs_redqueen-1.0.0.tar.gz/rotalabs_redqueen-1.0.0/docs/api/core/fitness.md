# Fitness

Fitness evaluation framework.

## Fitness

::: rotalabs_redqueen.core.fitness.Fitness

## SyncFitness

::: rotalabs_redqueen.core.fitness.SyncFitness

## FitnessValue

::: rotalabs_redqueen.FitnessValue

## FitnessResult

::: rotalabs_redqueen.FitnessResult

## EvaluationMetadata

::: rotalabs_redqueen.EvaluationMetadata
