# Genome

Base genome class and behavior descriptors.

## Genome

::: rotalabs_redqueen.core.genome.Genome

## BehaviorDescriptor

::: rotalabs_redqueen.BehaviorDescriptor
