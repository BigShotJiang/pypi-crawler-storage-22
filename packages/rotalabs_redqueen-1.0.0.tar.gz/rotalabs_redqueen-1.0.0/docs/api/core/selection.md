# Selection

Selection operators for evolutionary algorithms.

## Selection

::: rotalabs_redqueen.core.selection.Selection

## TournamentSelection

::: rotalabs_redqueen.TournamentSelection

## NoveltySelection

::: rotalabs_redqueen.NoveltySelection

## NoveltyFitnessSelection

::: rotalabs_redqueen.NoveltyFitnessSelection

## NoveltyArchive

::: rotalabs_redqueen.NoveltyArchive
