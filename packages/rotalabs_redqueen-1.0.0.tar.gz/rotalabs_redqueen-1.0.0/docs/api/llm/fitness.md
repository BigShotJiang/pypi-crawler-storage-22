# Fitness

Jailbreak fitness functions.

## JailbreakFitness

::: rotalabs_redqueen.llm.fitness.JailbreakFitness

## MultiTargetFitness

::: rotalabs_redqueen.MultiTargetFitness

## JailbreakMetrics

::: rotalabs_redqueen.JailbreakMetrics
