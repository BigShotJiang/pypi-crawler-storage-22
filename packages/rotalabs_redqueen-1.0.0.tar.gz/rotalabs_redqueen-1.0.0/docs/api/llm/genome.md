# Attack Genome

LLM attack genome with strategies, personas, and encodings.

## LLMAttackGenome

::: rotalabs_redqueen.llm.genome.LLMAttackGenome

## AttackStrategy

::: rotalabs_redqueen.AttackStrategy

## Persona

::: rotalabs_redqueen.Persona

## Encoding

::: rotalabs_redqueen.Encoding

## HarmCategory

::: rotalabs_redqueen.HarmCategory
