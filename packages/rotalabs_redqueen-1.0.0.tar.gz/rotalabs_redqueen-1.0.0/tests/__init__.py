"""Tests for rotalabs-redqueen."""
