"""Tests for integrations module."""
