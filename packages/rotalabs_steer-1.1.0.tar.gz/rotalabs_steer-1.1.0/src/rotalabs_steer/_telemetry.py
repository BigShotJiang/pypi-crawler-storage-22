"""Telemetry integration for rotalabs-steer.

This module provides a safe wrapper around the rotalabs telemetry system.
Telemetry is opt-in only and will gracefully degrade if not configured.
"""

from __future__ import annotations

from typing import Any

# Try to import from rotalabs telemetry, fall back to no-ops if not available
try:
    from rotalabs._telemetry import is_enabled, report_event
except ImportError:
    def report_event(*args: Any, **kwargs: Any) -> None:
        """No-op when rotalabs telemetry is not installed."""
        pass

    def is_enabled() -> bool:
        """Return False when rotalabs telemetry is not installed."""
        return False


def report_vector_load(
    behavior: str,
    model_name: str,
    layer_index: int,
    extraction_method: str,
) -> None:
    """Report a steering vector load event.

    Args:
        behavior: The behavior the vector represents.
        model_name: Name of the model the vector was trained for.
        layer_index: The layer index for the vector.
        extraction_method: Method used to extract the vector (e.g., 'caa').
    """
    if not is_enabled():
        return

    report_event(
        "steer.vector.loaded",
        {
            "behavior": behavior,
            "model_name": model_name,
            "layer_index": layer_index,
            "extraction_method": extraction_method,
        },
    )


def report_vector_save(
    behavior: str,
    model_name: str,
    layer_index: int,
    extraction_method: str,
) -> None:
    """Report a steering vector save event.

    Args:
        behavior: The behavior the vector represents.
        model_name: Name of the model the vector was trained for.
        layer_index: The layer index for the vector.
        extraction_method: Method used to extract the vector (e.g., 'caa').
    """
    if not is_enabled():
        return

    report_event(
        "steer.vector.saved",
        {
            "behavior": behavior,
            "model_name": model_name,
            "layer_index": layer_index,
            "extraction_method": extraction_method,
        },
    )


def report_injection_attached(
    model_type: str,
    n_vectors: int,
    strength: float,
    injection_mode: str,
) -> None:
    """Report when an activation injector is attached.

    Args:
        model_type: Type name of the model being steered.
        n_vectors: Number of vectors being applied.
        strength: The injection strength.
        injection_mode: Mode of injection ('all', 'last', 'first').
    """
    if not is_enabled():
        return

    report_event(
        "steer.injection.attached",
        {
            "model_type": model_type,
            "n_vectors": n_vectors,
            "strength": strength,
            "injection_mode": injection_mode,
        },
    )


def report_injection_detached(
    model_type: str,
    n_vectors: int,
) -> None:
    """Report when an activation injector is detached.

    Args:
        model_type: Type name of the model being steered.
        n_vectors: Number of vectors that were applied.
    """
    if not is_enabled():
        return

    report_event(
        "steer.injection.detached",
        {
            "model_type": model_type,
            "n_vectors": n_vectors,
        },
    )


def report_vector_set_load(
    behavior: str,
    model_name: str | None,
    n_layers: int,
) -> None:
    """Report when a vector set is loaded.

    Args:
        behavior: The behavior the vector set represents.
        model_name: Name of the model (if available).
        n_layers: Number of layers in the set.
    """
    if not is_enabled():
        return

    report_event(
        "steer.vector_set.loaded",
        {
            "behavior": behavior,
            "model_name": model_name,
            "n_layers": n_layers,
        },
    )
