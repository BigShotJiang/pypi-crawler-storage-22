# CE2P Feedback

Counterexample-to-Program feedback generation.

## generate_feedback

::: rotalabs_verity.ce2p.feedback.generate_feedback
