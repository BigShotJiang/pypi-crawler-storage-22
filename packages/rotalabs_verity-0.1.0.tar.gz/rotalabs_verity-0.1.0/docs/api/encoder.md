# Encoder

Convert Python code to Z3 symbolic constraints.

## encode_method

::: rotalabs_verity.encoder.z3_encoder.encode_method

## encode_with_bounds

::: rotalabs_verity.encoder.z3_encoder.encode_with_bounds

## EncodingResult

::: rotalabs_verity.encoder.z3_encoder.EncodingResult

## ParseError

::: rotalabs_verity.encoder.parser.ParseError

## EncodingError

::: rotalabs_verity.encoder.symbolic.EncodingError
