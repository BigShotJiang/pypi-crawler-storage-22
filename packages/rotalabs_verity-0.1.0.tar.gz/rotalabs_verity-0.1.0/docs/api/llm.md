# LLM Clients

LLM client integrations for code synthesis.

## Client Interface

::: rotalabs_verity.llm.client

## Prompts

::: rotalabs_verity.llm.prompts
