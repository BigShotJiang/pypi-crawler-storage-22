# Verifier

Verify code against formal specifications using Z3.

## verify

::: rotalabs_verity.verifier.verifier.verify

## verify_with_trace

::: rotalabs_verity.verifier.verifier.verify_with_trace
