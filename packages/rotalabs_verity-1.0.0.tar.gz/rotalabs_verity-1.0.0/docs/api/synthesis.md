# Synthesis

CEGIS-based code synthesis with LLM integration.

## synthesize

::: rotalabs_verity.synthesis.cegis.synthesize

## CEGISSynthesizer

::: rotalabs_verity.synthesis.cegis.CEGISSynthesizer

## CEGISConfig

::: rotalabs_verity.synthesis.cegis.CEGISConfig

## CEGISState

::: rotalabs_verity.synthesis.cegis.CEGISState
