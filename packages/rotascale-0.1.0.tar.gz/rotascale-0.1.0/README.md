# Rotascale Python SDK

Python client SDK for the Rotascale Trust Intelligence Platform.

## Installation

```bash
pip install rotascale
```

## Usage

```python
from rotascale import RotascaleClient

client = RotascaleClient(api_key="your-api-key")

# Scan an LLM output
result = client.guardian.scan(
    prompt="What is 2+2?",
    response="The answer is 4.",
    model="gpt-4"
)

print(result.passed)  # True
```

## Documentation

See the [Rotascale Documentation](https://docs.rotascale.com) for full API reference.
