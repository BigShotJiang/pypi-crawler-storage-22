"""HTTP transport layer for the Rotascale SDK."""

from __future__ import annotations

import os
import random
import time
from typing import Any

import httpx

from rotascale.exceptions import (
    RotascaleAPIError,
    RotascaleAuthError,
    RotascaleNotFoundError,
    RotascaleRateLimitError,
    RotascaleValidationError,
)

_ERROR_MAP = {
    401: RotascaleAuthError,
    403: RotascaleAuthError,
    404: RotascaleNotFoundError,
    422: RotascaleValidationError,
    429: RotascaleRateLimitError,
}

_DEFAULT_TIMEOUT = 30.0
_DEFAULT_MAX_RETRIES = 3
_DEFAULT_RETRY_DELAY = 1.0
_RETRYABLE_STATUS_CODES = {408, 429, 500, 502, 503, 504}


def _get_base_url() -> str:
    """Get base URL from environment or default."""
    return os.environ.get("ROTASCALE_BASE_URL", "https://api.rotascale.com")


def _get_api_key() -> str | None:
    """Get API key from environment."""
    return os.environ.get("ROTASCALE_API_KEY")


def _raise_for_status(response: httpx.Response) -> None:
    if response.is_success:
        return
    detail = None
    try:
        body = response.json()
        detail = body.get("detail", body)
    except Exception:
        detail = response.text

    exc_cls = _ERROR_MAP.get(response.status_code, RotascaleAPIError)
    exc = exc_cls(
        message=f"API error {response.status_code}: {detail}",
        status_code=response.status_code,
        detail=detail,
    )
    # Add retry_after for rate limit errors
    if response.status_code == 429:
        retry_after = response.headers.get("Retry-After")
        if retry_after:
            exc.retry_after = int(retry_after)
    raise exc


def _calculate_backoff(attempt: int, base_delay: float = _DEFAULT_RETRY_DELAY) -> float:
    """Calculate exponential backoff with jitter."""
    delay = base_delay * (2 ** attempt)
    jitter = random.uniform(0, delay * 0.1)
    return delay + jitter


class AsyncHTTPClient:
    """Async HTTP client wrapper around httpx with retry support."""

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
    ) -> None:
        self._base_url = base_url or _get_base_url()
        self._api_key = api_key or _get_api_key()
        self._max_retries = max_retries

        if not self._api_key:
            raise ValueError(
                "API key required. Pass api_key or set ROTASCALE_API_KEY environment variable."
            )

        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "User-Agent": "rotascale-python/0.1.0",
            },
            timeout=timeout,
        )

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        params: dict[str, Any] | None = None,
        retry: bool = True,
    ) -> Any:
        last_exception = None

        for attempt in range(self._max_retries + 1):
            try:
                response = await self._client.request(
                    method, path, json=json, params=params
                )

                # Check if we should retry
                if retry and response.status_code in _RETRYABLE_STATUS_CODES:
                    if attempt < self._max_retries:
                        delay = _calculate_backoff(attempt)
                        # For 429, use Retry-After header if available
                        if response.status_code == 429:
                            retry_after = response.headers.get("Retry-After")
                            if retry_after:
                                delay = float(retry_after)
                        await self._async_sleep(delay)
                        continue

                _raise_for_status(response)
                if response.status_code == 204:
                    return None
                return response.json()

            except (httpx.ConnectError, httpx.ReadTimeout, httpx.WriteTimeout) as e:
                last_exception = e
                if attempt < self._max_retries and retry:
                    delay = _calculate_backoff(attempt)
                    await self._async_sleep(delay)
                    continue
                raise RotascaleAPIError(
                    message=f"Connection error: {e}",
                    status_code=0,
                    detail=str(e),
                ) from e

        if last_exception:
            raise last_exception

    async def _async_sleep(self, seconds: float) -> None:
        """Async sleep helper."""
        import asyncio
        await asyncio.sleep(seconds)

    async def get(self, path: str, **kwargs: Any) -> Any:
        return await self.request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> Any:
        return await self.request("POST", path, **kwargs)

    async def patch(self, path: str, **kwargs: Any) -> Any:
        return await self.request("PATCH", path, **kwargs)

    async def delete(self, path: str, **kwargs: Any) -> Any:
        return await self.request("DELETE", path, **kwargs)

    async def close(self) -> None:
        await self._client.aclose()


class SyncHTTPClient:
    """Sync HTTP client wrapper around httpx with retry support."""

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
    ) -> None:
        self._base_url = base_url or _get_base_url()
        self._api_key = api_key or _get_api_key()
        self._max_retries = max_retries

        if not self._api_key:
            raise ValueError(
                "API key required. Pass api_key or set ROTASCALE_API_KEY environment variable."
            )

        self._client = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "User-Agent": "rotascale-python/0.1.0",
            },
            timeout=timeout,
        )

    def request(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        params: dict[str, Any] | None = None,
        retry: bool = True,
    ) -> Any:
        last_exception = None

        for attempt in range(self._max_retries + 1):
            try:
                response = self._client.request(
                    method, path, json=json, params=params
                )

                # Check if we should retry
                if retry and response.status_code in _RETRYABLE_STATUS_CODES:
                    if attempt < self._max_retries:
                        delay = _calculate_backoff(attempt)
                        if response.status_code == 429:
                            retry_after = response.headers.get("Retry-After")
                            if retry_after:
                                delay = float(retry_after)
                        time.sleep(delay)
                        continue

                _raise_for_status(response)
                if response.status_code == 204:
                    return None
                return response.json()

            except (httpx.ConnectError, httpx.ReadTimeout, httpx.WriteTimeout) as e:
                last_exception = e
                if attempt < self._max_retries and retry:
                    delay = _calculate_backoff(attempt)
                    time.sleep(delay)
                    continue
                raise RotascaleAPIError(
                    message=f"Connection error: {e}",
                    status_code=0,
                    detail=str(e),
                ) from e

        if last_exception:
            raise last_exception

    def get(self, path: str, **kwargs: Any) -> Any:
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> Any:
        return self.request("POST", path, **kwargs)

    def patch(self, path: str, **kwargs: Any) -> Any:
        return self.request("PATCH", path, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> Any:
        return self.request("DELETE", path, **kwargs)

    def close(self) -> None:
        self._client.close()
