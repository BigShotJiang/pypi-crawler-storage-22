"""Accelerate sub-client - inference profiling, benchmarks, cost modeling."""

from __future__ import annotations

from typing import Any


class AsyncAccelerateClient:
    def __init__(self, http: Any) -> None:
        self._http = http

    # ── Profiles ────────────────────────────────────────

    async def list_profiles(self) -> list[dict]:
        return await self._http.get("/v1/accelerate/profiles")

    async def create_profile(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/accelerate/profiles", json=kwargs)

    async def get_profile(self, profile_id: str) -> dict:
        return await self._http.get(f"/v1/accelerate/profiles/{profile_id}")

    async def delete_profile(self, profile_id: str) -> None:
        await self._http.delete(f"/v1/accelerate/profiles/{profile_id}")

    async def generate_recommendations(self, profile_id: str) -> list[dict]:
        return await self._http.post(f"/v1/accelerate/profiles/{profile_id}/recommendations")

    async def list_recommendations(self, profile_id: str) -> list[dict]:
        return await self._http.get(f"/v1/accelerate/profiles/{profile_id}/recommendations")

    # ── Benchmarks ──────────────────────────────────────

    async def list_benchmarks(self) -> list[dict]:
        return await self._http.get("/v1/accelerate/benchmarks")

    async def create_benchmark(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/accelerate/benchmarks", json=kwargs)

    async def get_benchmark(self, benchmark_id: str) -> dict:
        return await self._http.get(f"/v1/accelerate/benchmarks/{benchmark_id}")

    async def delete_benchmark(self, benchmark_id: str) -> None:
        await self._http.delete(f"/v1/accelerate/benchmarks/{benchmark_id}")

    # ── Cost Models ─────────────────────────────────────

    async def list_cost_models(self) -> list[dict]:
        return await self._http.get("/v1/accelerate/costs")

    async def create_cost_model(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/accelerate/costs", json=kwargs)

    async def get_cost_model(self, cost_model_id: str) -> dict:
        return await self._http.get(f"/v1/accelerate/costs/{cost_model_id}")

    async def delete_cost_model(self, cost_model_id: str) -> None:
        await self._http.delete(f"/v1/accelerate/costs/{cost_model_id}")

    async def estimate_cost(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/accelerate/costs/estimate", json=kwargs)


class AccelerateClient:
    def __init__(self, http: Any) -> None:
        self._http = http

    def list_profiles(self) -> list[dict]:
        return self._http.get("/v1/accelerate/profiles")

    def create_profile(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/accelerate/profiles", json=kwargs)

    def get_profile(self, profile_id: str) -> dict:
        return self._http.get(f"/v1/accelerate/profiles/{profile_id}")

    def delete_profile(self, profile_id: str) -> None:
        self._http.delete(f"/v1/accelerate/profiles/{profile_id}")

    def generate_recommendations(self, profile_id: str) -> list[dict]:
        return self._http.post(f"/v1/accelerate/profiles/{profile_id}/recommendations")

    def list_recommendations(self, profile_id: str) -> list[dict]:
        return self._http.get(f"/v1/accelerate/profiles/{profile_id}/recommendations")

    def list_benchmarks(self) -> list[dict]:
        return self._http.get("/v1/accelerate/benchmarks")

    def create_benchmark(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/accelerate/benchmarks", json=kwargs)

    def get_benchmark(self, benchmark_id: str) -> dict:
        return self._http.get(f"/v1/accelerate/benchmarks/{benchmark_id}")

    def delete_benchmark(self, benchmark_id: str) -> None:
        self._http.delete(f"/v1/accelerate/benchmarks/{benchmark_id}")

    def list_cost_models(self) -> list[dict]:
        return self._http.get("/v1/accelerate/costs")

    def create_cost_model(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/accelerate/costs", json=kwargs)

    def get_cost_model(self, cost_model_id: str) -> dict:
        return self._http.get(f"/v1/accelerate/costs/{cost_model_id}")

    def delete_cost_model(self, cost_model_id: str) -> None:
        self._http.delete(f"/v1/accelerate/costs/{cost_model_id}")

    def estimate_cost(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/accelerate/costs/estimate", json=kwargs)
