"""AgentOps sub-client - agent governance, audit, compliance, reasoning."""

from __future__ import annotations

from typing import Any


class AsyncAgentOpsClient:
    def __init__(self, http: Any) -> None:
        self._http = http

    # ── Agents ──────────────────────────────────────────

    async def list_agents(self) -> list[dict]:
        return await self._http.get("/v1/agentops/agents")

    async def create_agent(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/agentops/agents", json=kwargs)

    async def get_agent(self, agent_id: str) -> dict:
        return await self._http.get(f"/v1/agentops/agents/{agent_id}")

    async def update_agent(self, agent_id: str, **kwargs: Any) -> dict:
        return await self._http.patch(f"/v1/agentops/agents/{agent_id}", json=kwargs)

    async def delete_agent(self, agent_id: str) -> None:
        await self._http.delete(f"/v1/agentops/agents/{agent_id}")

    async def activate_agent(self, agent_id: str) -> dict:
        return await self._http.post(f"/v1/agentops/agents/{agent_id}/activate")

    async def suspend_agent(self, agent_id: str) -> dict:
        return await self._http.post(f"/v1/agentops/agents/{agent_id}/suspend")

    # ── Audit ───────────────────────────────────────────

    async def create_audit_entry(self, agent_id: str, **kwargs: Any) -> dict:
        return await self._http.post(f"/v1/agentops/agents/{agent_id}/audit", json=kwargs)

    async def list_audit_entries(self, agent_id: str) -> list[dict]:
        return await self._http.get(f"/v1/agentops/agents/{agent_id}/audit")

    async def get_audit_entry(self, agent_id: str, entry_id: str) -> dict:
        return await self._http.get(f"/v1/agentops/agents/{agent_id}/audit/{entry_id}")

    # ── Compliance ──────────────────────────────────────

    async def run_compliance_check(self, agent_id: str, **kwargs: Any) -> dict:
        return await self._http.post(f"/v1/agentops/agents/{agent_id}/compliance", json=kwargs)

    async def list_compliance_checks(self, agent_id: str) -> list[dict]:
        return await self._http.get(f"/v1/agentops/agents/{agent_id}/compliance")

    async def get_compliance_check(self, agent_id: str, check_id: str) -> dict:
        return await self._http.get(f"/v1/agentops/agents/{agent_id}/compliance/{check_id}")

    # ── Reasoning ───────────────────────────────────────

    async def analyze_reasoning(self, agent_id: str, **kwargs: Any) -> dict:
        return await self._http.post(f"/v1/agentops/agents/{agent_id}/reasoning", json=kwargs)

    async def list_reasoning_analyses(self, agent_id: str) -> list[dict]:
        return await self._http.get(f"/v1/agentops/agents/{agent_id}/reasoning")

    async def get_reasoning_analysis(self, agent_id: str, analysis_id: str) -> dict:
        return await self._http.get(f"/v1/agentops/agents/{agent_id}/reasoning/{analysis_id}")


class AgentOpsClient:
    def __init__(self, http: Any) -> None:
        self._http = http

    def list_agents(self) -> list[dict]:
        return self._http.get("/v1/agentops/agents")

    def create_agent(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/agentops/agents", json=kwargs)

    def get_agent(self, agent_id: str) -> dict:
        return self._http.get(f"/v1/agentops/agents/{agent_id}")

    def update_agent(self, agent_id: str, **kwargs: Any) -> dict:
        return self._http.patch(f"/v1/agentops/agents/{agent_id}", json=kwargs)

    def delete_agent(self, agent_id: str) -> None:
        self._http.delete(f"/v1/agentops/agents/{agent_id}")

    def activate_agent(self, agent_id: str) -> dict:
        return self._http.post(f"/v1/agentops/agents/{agent_id}/activate")

    def suspend_agent(self, agent_id: str) -> dict:
        return self._http.post(f"/v1/agentops/agents/{agent_id}/suspend")

    def create_audit_entry(self, agent_id: str, **kwargs: Any) -> dict:
        return self._http.post(f"/v1/agentops/agents/{agent_id}/audit", json=kwargs)

    def list_audit_entries(self, agent_id: str) -> list[dict]:
        return self._http.get(f"/v1/agentops/agents/{agent_id}/audit")

    def get_audit_entry(self, agent_id: str, entry_id: str) -> dict:
        return self._http.get(f"/v1/agentops/agents/{agent_id}/audit/{entry_id}")

    def run_compliance_check(self, agent_id: str, **kwargs: Any) -> dict:
        return self._http.post(f"/v1/agentops/agents/{agent_id}/compliance", json=kwargs)

    def list_compliance_checks(self, agent_id: str) -> list[dict]:
        return self._http.get(f"/v1/agentops/agents/{agent_id}/compliance")

    def get_compliance_check(self, agent_id: str, check_id: str) -> dict:
        return self._http.get(f"/v1/agentops/agents/{agent_id}/compliance/{check_id}")

    def analyze_reasoning(self, agent_id: str, **kwargs: Any) -> dict:
        return self._http.post(f"/v1/agentops/agents/{agent_id}/reasoning", json=kwargs)

    def list_reasoning_analyses(self, agent_id: str) -> list[dict]:
        return self._http.get(f"/v1/agentops/agents/{agent_id}/reasoning")

    def get_reasoning_analysis(self, agent_id: str, analysis_id: str) -> dict:
        return self._http.get(f"/v1/agentops/agents/{agent_id}/reasoning/{analysis_id}")
