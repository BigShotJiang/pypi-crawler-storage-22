"""Rotascale CLI - Command-line interface for the Rotascale platform.

Usage:
    rotascale configure --api-key rsk_live_...
    rotascale guardian scan --prompt "Hello" --response "Hi"
    rotascale steer list-configs
    rotascale eval list-suites
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

try:
    import typer
    from rich.console import Console
    from rich.table import Table
    from rich import print as rprint
except ImportError as e:
    print(
        "CLI dependencies not installed. Install with: pip install rotascale[cli]",
        file=sys.stderr,
    )
    sys.exit(1)

from rotascale.client import RotascaleClient
from rotascale.exceptions import RotascaleError

# Initialize Typer app
app = typer.Typer(
    name="rotascale",
    help="Rotascale Trust Intelligence Platform CLI",
    add_completion=False,
)

console = Console()

# Config file location
CONFIG_DIR = Path.home() / ".rotascale"
CONFIG_FILE = CONFIG_DIR / "config.json"


def get_config() -> dict[str, Any]:
    """Load configuration from file."""
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}


def save_config(config: dict[str, Any]) -> None:
    """Save configuration to file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2))


def get_client() -> RotascaleClient:
    """Get a configured Rotascale client."""
    api_key = os.environ.get("ROTASCALE_API_KEY")
    base_url = os.environ.get("ROTASCALE_BASE_URL")

    if not api_key:
        config = get_config()
        api_key = config.get("api_key")
        base_url = base_url or config.get("base_url")

    if not api_key:
        console.print(
            "[red]Error:[/red] No API key configured. "
            "Run 'rotascale configure' or set ROTASCALE_API_KEY environment variable."
        )
        raise typer.Exit(1)

    return RotascaleClient(
        api_key=api_key,
        base_url=base_url or "https://api.rotascale.com",
    )


# ─────────────────────────────────────────────────────────────────────────────
# Configure Command
# ─────────────────────────────────────────────────────────────────────────────


@app.command()
def configure(
    api_key: str = typer.Option(
        None, "--api-key", "-k", help="Rotascale API key (rsk_live_...)"
    ),
    base_url: str = typer.Option(
        None, "--base-url", "-u", help="API base URL (default: https://api.rotascale.com)"
    ),
) -> None:
    """Configure the Rotascale CLI with your API credentials."""
    config = get_config()

    if api_key:
        config["api_key"] = api_key
    else:
        api_key = typer.prompt("Enter your Rotascale API key")
        config["api_key"] = api_key

    if base_url:
        config["base_url"] = base_url

    save_config(config)
    console.print("[green]✓[/green] Configuration saved to ~/.rotascale/config.json")

    # Verify the API key works
    try:
        client = RotascaleClient(
            api_key=config["api_key"],
            base_url=config.get("base_url", "https://api.rotascale.com"),
        )
        # Try a simple request to verify
        console.print("[green]✓[/green] API key verified successfully")
    except Exception as e:
        console.print(f"[yellow]Warning:[/yellow] Could not verify API key: {e}")


@app.command()
def whoami() -> None:
    """Show current configuration and API key info."""
    config = get_config()

    if not config.get("api_key"):
        console.print("[yellow]Not configured.[/yellow] Run 'rotascale configure' first.")
        raise typer.Exit(1)

    table = Table(title="Rotascale Configuration")
    table.add_column("Setting", style="cyan")
    table.add_column("Value", style="green")

    # Mask API key
    api_key = config.get("api_key", "")
    masked_key = api_key[:12] + "..." + api_key[-4:] if len(api_key) > 16 else "***"

    table.add_row("API Key", masked_key)
    table.add_row("Base URL", config.get("base_url", "https://api.rotascale.com"))
    table.add_row("Config File", str(CONFIG_FILE))

    console.print(table)


# ─────────────────────────────────────────────────────────────────────────────
# Guardian Commands
# ─────────────────────────────────────────────────────────────────────────────

guardian_app = typer.Typer(help="Guardian safety scanning commands")
app.add_typer(guardian_app, name="guardian")


@guardian_app.command("scan")
def guardian_scan(
    prompt: str = typer.Option(..., "--prompt", "-p", help="Input prompt to scan"),
    response: str = typer.Option(..., "--response", "-r", help="Response to scan"),
    model: str = typer.Option("unknown", "--model", "-m", help="Model name"),
    monitor_id: str = typer.Option(None, "--monitor", help="Monitor ID"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Scan a prompt/response pair for safety issues."""
    client = get_client()

    try:
        if monitor_id:
            result = client.guardian.run_detection(
                monitor_id=monitor_id,
                prompt=prompt,
                response=response,
                model=model,
            )
        else:
            # Use direct scan endpoint
            result = client.guardian._http.post(
                "/v1/guardian/scan",
                json={"prompt": prompt, "response": response, "model": model},
            )

        if output_json:
            console.print_json(json.dumps(result))
        else:
            safe = result.get("safe", result.get("passed", True))
            risk_score = result.get("risk_score", 0.0)

            if safe:
                console.print("[green]✓ SAFE[/green]")
            else:
                console.print("[red]✗ UNSAFE[/red]")

            console.print(f"Risk Score: {risk_score:.2%}")

            flags = result.get("flags", [])
            if flags:
                console.print(f"Flags: {', '.join(flags)}")

            categories = result.get("categories", {})
            if categories:
                table = Table(title="Category Scores")
                table.add_column("Category", style="cyan")
                table.add_column("Score", style="yellow")
                for cat, score in categories.items():
                    table.add_row(cat, f"{score:.2%}")
                console.print(table)

    except RotascaleError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@guardian_app.command("list-monitors")
def guardian_list_monitors(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List all Guardian monitors."""
    client = get_client()

    try:
        monitors = client.guardian.list_monitors()

        if output_json:
            console.print_json(json.dumps(monitors))
        else:
            if not monitors:
                console.print("[yellow]No monitors found.[/yellow]")
                return

            table = Table(title="Guardian Monitors")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("Status", style="yellow")
            table.add_column("Created", style="dim")

            for m in monitors:
                table.add_row(
                    m.get("id", ""),
                    m.get("name", ""),
                    m.get("status", ""),
                    m.get("created_at", "")[:10] if m.get("created_at") else "",
                )
            console.print(table)

    except RotascaleError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@guardian_app.command("list-alerts")
def guardian_list_alerts(
    limit: int = typer.Option(20, "--limit", "-n", help="Number of alerts to show"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List recent Guardian alerts."""
    client = get_client()

    try:
        alerts = client.guardian.list_alerts(limit=limit)

        if output_json:
            console.print_json(json.dumps(alerts))
        else:
            if not alerts:
                console.print("[green]No alerts.[/green]")
                return

            table = Table(title="Guardian Alerts")
            table.add_column("ID", style="cyan")
            table.add_column("Severity", style="red")
            table.add_column("Type", style="yellow")
            table.add_column("Message", style="white")
            table.add_column("Created", style="dim")

            for a in alerts:
                table.add_row(
                    a.get("id", "")[:8],
                    a.get("severity", ""),
                    a.get("type", ""),
                    (a.get("message", "")[:50] + "...") if len(a.get("message", "")) > 50 else a.get("message", ""),
                    a.get("created_at", "")[:10] if a.get("created_at") else "",
                )
            console.print(table)

    except RotascaleError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# Steer Commands
# ─────────────────────────────────────────────────────────────────────────────

steer_app = typer.Typer(help="Steer behavior control commands")
app.add_typer(steer_app, name="steer")


@steer_app.command("list-configs")
def steer_list_configs(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List all Steer behavior configurations."""
    client = get_client()

    try:
        configs = client.steer.list_configs()

        if output_json:
            console.print_json(json.dumps(configs))
        else:
            if not configs:
                console.print("[yellow]No configurations found.[/yellow]")
                return

            table = Table(title="Steer Configurations")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("Behaviors", style="yellow")
            table.add_column("Status", style="white")

            for c in configs:
                behaviors = c.get("behaviors", [])
                behavior_str = ", ".join(b.get("name", "") for b in behaviors[:3])
                if len(behaviors) > 3:
                    behavior_str += f" (+{len(behaviors) - 3})"

                table.add_row(
                    c.get("id", "")[:8],
                    c.get("name", ""),
                    behavior_str,
                    c.get("status", "active"),
                )
            console.print(table)

    except RotascaleError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@steer_app.command("list-vectors")
def steer_list_vectors(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List all vector libraries."""
    client = get_client()

    try:
        vectors = client.steer.list_vectors()

        if output_json:
            console.print_json(json.dumps(vectors))
        else:
            if not vectors:
                console.print("[yellow]No vector libraries found.[/yellow]")
                return

            table = Table(title="Vector Libraries")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("Model", style="yellow")
            table.add_column("Vectors", style="white")

            for v in vectors:
                table.add_row(
                    v.get("id", "")[:8],
                    v.get("name", ""),
                    v.get("model", ""),
                    str(v.get("vector_count", 0)),
                )
            console.print(table)

    except RotascaleError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@steer_app.command("list-catalog")
def steer_list_catalog(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List available behaviors in the catalog."""
    client = get_client()

    try:
        catalog = client.steer.list_catalog()

        if output_json:
            console.print_json(json.dumps(catalog))
        else:
            if not catalog:
                console.print("[yellow]No behaviors in catalog.[/yellow]")
                return

            table = Table(title="Behavior Catalog")
            table.add_column("Name", style="cyan")
            table.add_column("Category", style="green")
            table.add_column("Description", style="white")

            for b in catalog:
                table.add_row(
                    b.get("name", ""),
                    b.get("category", ""),
                    (b.get("description", "")[:60] + "...") if len(b.get("description", "")) > 60 else b.get("description", ""),
                )
            console.print(table)

    except RotascaleError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# Eval Commands
# ─────────────────────────────────────────────────────────────────────────────

eval_app = typer.Typer(help="Eval evaluation suite commands")
app.add_typer(eval_app, name="eval")


@eval_app.command("list-suites")
def eval_list_suites(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List all evaluation suites."""
    client = get_client()

    try:
        suites = client.eval.list_suites()

        if output_json:
            console.print_json(json.dumps(suites))
        else:
            if not suites:
                console.print("[yellow]No evaluation suites found.[/yellow]")
                return

            table = Table(title="Evaluation Suites")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("Tests", style="yellow")
            table.add_column("Last Run", style="dim")

            for s in suites:
                table.add_row(
                    s.get("id", "")[:8],
                    s.get("name", ""),
                    str(s.get("test_count", 0)),
                    s.get("last_run_at", "Never")[:10] if s.get("last_run_at") else "Never",
                )
            console.print(table)

    except RotascaleError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@eval_app.command("run")
def eval_run(
    suite_id: str = typer.Argument(..., help="Suite ID to run"),
    input_file: Path = typer.Option(None, "--input", "-i", help="Input JSONL file"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Run an evaluation suite."""
    client = get_client()

    try:
        run_params: dict[str, Any] = {}

        if input_file:
            if not input_file.exists():
                console.print(f"[red]Error:[/red] File not found: {input_file}")
                raise typer.Exit(1)

            # Read JSONL input
            inputs = []
            with input_file.open() as f:
                for line in f:
                    if line.strip():
                        inputs.append(json.loads(line))
            run_params["inputs"] = inputs

        result = client.eval.run_suite(suite_id, **run_params)

        if output_json:
            console.print_json(json.dumps(result))
        else:
            console.print(f"[green]✓[/green] Evaluation run started")
            console.print(f"Run ID: {result.get('run_id', 'N/A')}")
            console.print(f"Status: {result.get('status', 'pending')}")

    except RotascaleError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@eval_app.command("results")
def eval_results(
    run_id: str = typer.Argument(..., help="Run ID to get results for"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Get results for an evaluation run."""
    client = get_client()

    try:
        result = client.eval.get_run(run_id)

        if output_json:
            console.print_json(json.dumps(result))
        else:
            status = result.get("status", "unknown")
            status_color = "green" if status == "completed" else "yellow"

            console.print(f"Run ID: {run_id}")
            console.print(f"Status: [{status_color}]{status}[/{status_color}]")

            if result.get("metrics"):
                table = Table(title="Metrics")
                table.add_column("Metric", style="cyan")
                table.add_column("Value", style="green")

                for name, value in result["metrics"].items():
                    if isinstance(value, float):
                        table.add_row(name, f"{value:.4f}")
                    else:
                        table.add_row(name, str(value))
                console.print(table)

    except RotascaleError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# Version Command
# ─────────────────────────────────────────────────────────────────────────────


@app.command()
def version() -> None:
    """Show the Rotascale CLI version."""
    from rotascale import __version__

    console.print(f"rotascale {__version__}")


# ─────────────────────────────────────────────────────────────────────────────
# Main Entry Point
# ─────────────────────────────────────────────────────────────────────────────


def main() -> None:
    """Main entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()
