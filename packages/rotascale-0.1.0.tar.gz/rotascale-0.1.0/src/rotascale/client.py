"""Main Rotascale client classes."""

from __future__ import annotations

from rotascale._http import AsyncHTTPClient, SyncHTTPClient
from rotascale.accelerate import AccelerateClient, AsyncAccelerateClient
from rotascale.agentops import AgentOpsClient, AsyncAgentOpsClient
from rotascale.context_engine import AsyncContextEngineClient, ContextEngineClient
from rotascale.eval import AsyncEvalClient, EvalClient
from rotascale.guardian import AsyncGuardianClient, GuardianClient
from rotascale.orchestrate import AsyncOrchestrateClient, OrchestrateClient
from rotascale.steer import AsyncSteerClient, SteerClient

_DEFAULT_BASE_URL = "http://localhost:8000"


class AsyncRotascaleClient:
    """Async client for the Rotascale API.

    Usage::

        async with AsyncRotascaleClient(api_key="rsk_live_...") as client:
            monitors = await client.guardian.list_monitors()
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> None:
        self._http = AsyncHTTPClient(base_url, api_key, timeout)
        self.guardian = AsyncGuardianClient(self._http)
        self.steer = AsyncSteerClient(self._http)
        self.eval = AsyncEvalClient(self._http)
        self.orchestrate = AsyncOrchestrateClient(self._http)
        self.agentops = AsyncAgentOpsClient(self._http)
        self.accelerate = AsyncAccelerateClient(self._http)
        self.context_engine = AsyncContextEngineClient(self._http)

    async def __aenter__(self) -> AsyncRotascaleClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()

    async def close(self) -> None:
        await self._http.close()


class RotascaleClient:
    """Sync client for the Rotascale API.

    Usage::

        client = RotascaleClient(api_key="rsk_live_...")
        monitors = client.guardian.list_monitors()
        client.close()
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> None:
        self._http = SyncHTTPClient(base_url, api_key, timeout)
        self.guardian = GuardianClient(self._http)
        self.steer = SteerClient(self._http)
        self.eval = EvalClient(self._http)
        self.orchestrate = OrchestrateClient(self._http)
        self.agentops = AgentOpsClient(self._http)
        self.accelerate = AccelerateClient(self._http)
        self.context_engine = ContextEngineClient(self._http)

    def __enter__(self) -> RotascaleClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def close(self) -> None:
        self._http.close()
