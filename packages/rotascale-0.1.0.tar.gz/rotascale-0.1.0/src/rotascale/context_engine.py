"""Context Engine sub-client - ETL-C pipelines, connectors, context store."""

from __future__ import annotations

from typing import Any


class AsyncContextEngineClient:
    def __init__(self, http: Any) -> None:
        self._http = http

    # ── Connectors ──────────────────────────────────────

    async def list_connectors(self) -> list[dict]:
        return await self._http.get("/v1/context-engine/connectors")

    async def create_connector(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/context-engine/connectors", json=kwargs)

    async def get_connector(self, connector_id: str) -> dict:
        return await self._http.get(f"/v1/context-engine/connectors/{connector_id}")

    async def update_connector(self, connector_id: str, **kwargs: Any) -> dict:
        return await self._http.patch(f"/v1/context-engine/connectors/{connector_id}", json=kwargs)

    async def delete_connector(self, connector_id: str) -> None:
        await self._http.delete(f"/v1/context-engine/connectors/{connector_id}")

    async def test_connector(self, connector_id: str) -> dict:
        return await self._http.post(f"/v1/context-engine/connectors/{connector_id}/test")

    # ── Pipelines ───────────────────────────────────────

    async def list_pipelines(self) -> list[dict]:
        return await self._http.get("/v1/context-engine/pipelines")

    async def create_pipeline(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/context-engine/pipelines", json=kwargs)

    async def get_pipeline(self, pipeline_id: str) -> dict:
        return await self._http.get(f"/v1/context-engine/pipelines/{pipeline_id}")

    async def update_pipeline(self, pipeline_id: str, **kwargs: Any) -> dict:
        return await self._http.patch(f"/v1/context-engine/pipelines/{pipeline_id}", json=kwargs)

    async def delete_pipeline(self, pipeline_id: str) -> None:
        await self._http.delete(f"/v1/context-engine/pipelines/{pipeline_id}")

    async def activate_pipeline(self, pipeline_id: str) -> dict:
        return await self._http.post(f"/v1/context-engine/pipelines/{pipeline_id}/activate")

    async def pause_pipeline(self, pipeline_id: str) -> dict:
        return await self._http.post(f"/v1/context-engine/pipelines/{pipeline_id}/pause")

    async def execute_pipeline(self, pipeline_id: str) -> dict:
        return await self._http.post(f"/v1/context-engine/pipelines/{pipeline_id}/execute")

    async def list_pipeline_jobs(self, pipeline_id: str) -> list[dict]:
        return await self._http.get(f"/v1/context-engine/pipelines/{pipeline_id}/jobs")

    # ── Context Store ───────────────────────────────────

    async def list_contexts(
        self,
        source: str | None = None,
        content_type: str | None = None,
        limit: int = 50,
    ) -> list[dict]:
        params: dict[str, Any] = {"limit": limit}
        if source:
            params["source"] = source
        if content_type:
            params["content_type"] = content_type
        return await self._http.get("/v1/context-engine/contexts", params=params)

    async def create_context(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/context-engine/contexts", json=kwargs)

    async def get_context(self, entry_id: str) -> dict:
        return await self._http.get(f"/v1/context-engine/contexts/{entry_id}")

    async def delete_context(self, entry_id: str) -> None:
        await self._http.delete(f"/v1/context-engine/contexts/{entry_id}")

    async def query_contexts(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/context-engine/contexts/query", json=kwargs)


class ContextEngineClient:
    def __init__(self, http: Any) -> None:
        self._http = http

    def list_connectors(self) -> list[dict]:
        return self._http.get("/v1/context-engine/connectors")

    def create_connector(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/context-engine/connectors", json=kwargs)

    def get_connector(self, connector_id: str) -> dict:
        return self._http.get(f"/v1/context-engine/connectors/{connector_id}")

    def update_connector(self, connector_id: str, **kwargs: Any) -> dict:
        return self._http.patch(f"/v1/context-engine/connectors/{connector_id}", json=kwargs)

    def delete_connector(self, connector_id: str) -> None:
        self._http.delete(f"/v1/context-engine/connectors/{connector_id}")

    def test_connector(self, connector_id: str) -> dict:
        return self._http.post(f"/v1/context-engine/connectors/{connector_id}/test")

    def list_pipelines(self) -> list[dict]:
        return self._http.get("/v1/context-engine/pipelines")

    def create_pipeline(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/context-engine/pipelines", json=kwargs)

    def get_pipeline(self, pipeline_id: str) -> dict:
        return self._http.get(f"/v1/context-engine/pipelines/{pipeline_id}")

    def update_pipeline(self, pipeline_id: str, **kwargs: Any) -> dict:
        return self._http.patch(f"/v1/context-engine/pipelines/{pipeline_id}", json=kwargs)

    def delete_pipeline(self, pipeline_id: str) -> None:
        self._http.delete(f"/v1/context-engine/pipelines/{pipeline_id}")

    def activate_pipeline(self, pipeline_id: str) -> dict:
        return self._http.post(f"/v1/context-engine/pipelines/{pipeline_id}/activate")

    def pause_pipeline(self, pipeline_id: str) -> dict:
        return self._http.post(f"/v1/context-engine/pipelines/{pipeline_id}/pause")

    def execute_pipeline(self, pipeline_id: str) -> dict:
        return self._http.post(f"/v1/context-engine/pipelines/{pipeline_id}/execute")

    def list_pipeline_jobs(self, pipeline_id: str) -> list[dict]:
        return self._http.get(f"/v1/context-engine/pipelines/{pipeline_id}/jobs")

    def list_contexts(
        self,
        source: str | None = None,
        content_type: str | None = None,
        limit: int = 50,
    ) -> list[dict]:
        params: dict[str, Any] = {"limit": limit}
        if source:
            params["source"] = source
        if content_type:
            params["content_type"] = content_type
        return self._http.get("/v1/context-engine/contexts", params=params)

    def create_context(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/context-engine/contexts", json=kwargs)

    def get_context(self, entry_id: str) -> dict:
        return self._http.get(f"/v1/context-engine/contexts/{entry_id}")

    def delete_context(self, entry_id: str) -> None:
        self._http.delete(f"/v1/context-engine/contexts/{entry_id}")

    def query_contexts(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/context-engine/contexts/query", json=kwargs)
