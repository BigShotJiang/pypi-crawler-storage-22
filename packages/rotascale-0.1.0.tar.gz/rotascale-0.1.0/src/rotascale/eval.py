"""Eval sub-client - LLM evaluation, datasets, runs, metrics."""

from __future__ import annotations

from typing import Any


class AsyncEvalClient:
    def __init__(self, http: Any) -> None:
        self._http = http

    # ── Datasets ────────────────────────────────────────

    async def list_datasets(self) -> list[dict]:
        return await self._http.get("/v1/eval/datasets")

    async def create_dataset(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/eval/datasets", json=kwargs)

    async def get_dataset(self, dataset_id: str) -> dict:
        return await self._http.get(f"/v1/eval/datasets/{dataset_id}")

    async def delete_dataset(self, dataset_id: str) -> None:
        await self._http.delete(f"/v1/eval/datasets/{dataset_id}")

    # ── Runs ────────────────────────────────────────────

    async def list_runs(self) -> list[dict]:
        return await self._http.get("/v1/eval/runs")

    async def create_run(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/eval/runs", json=kwargs)

    async def get_run(self, run_id: str) -> dict:
        return await self._http.get(f"/v1/eval/runs/{run_id}")

    async def delete_run(self, run_id: str) -> None:
        await self._http.delete(f"/v1/eval/runs/{run_id}")

    async def compare_runs(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/eval/runs/compare", json=kwargs)

    # ── Metrics ─────────────────────────────────────────

    async def list_metrics(self) -> list[dict]:
        return await self._http.get("/v1/eval/metrics")


class EvalClient:
    def __init__(self, http: Any) -> None:
        self._http = http

    def list_datasets(self) -> list[dict]:
        return self._http.get("/v1/eval/datasets")

    def create_dataset(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/eval/datasets", json=kwargs)

    def get_dataset(self, dataset_id: str) -> dict:
        return self._http.get(f"/v1/eval/datasets/{dataset_id}")

    def delete_dataset(self, dataset_id: str) -> None:
        self._http.delete(f"/v1/eval/datasets/{dataset_id}")

    def list_runs(self) -> list[dict]:
        return self._http.get("/v1/eval/runs")

    def create_run(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/eval/runs", json=kwargs)

    def get_run(self, run_id: str) -> dict:
        return self._http.get(f"/v1/eval/runs/{run_id}")

    def delete_run(self, run_id: str) -> None:
        self._http.delete(f"/v1/eval/runs/{run_id}")

    def compare_runs(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/eval/runs/compare", json=kwargs)

    def list_metrics(self) -> list[dict]:
        return self._http.get("/v1/eval/metrics")
