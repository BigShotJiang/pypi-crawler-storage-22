"""Rotascale SDK exceptions."""

from __future__ import annotations

from typing import Any


class RotascaleError(Exception):
    """Base exception for the Rotascale SDK."""


class RotascaleAPIError(RotascaleError):
    """Raised when the API returns an error response."""

    def __init__(
        self,
        message: str,
        status_code: int,
        detail: Any = None,
    ) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(message)


class RotascaleAuthError(RotascaleAPIError):
    """Raised on 401/403 responses."""


class RotascaleNotFoundError(RotascaleAPIError):
    """Raised on 404 responses."""


class RotascaleValidationError(RotascaleAPIError):
    """Raised on 422 responses."""


class RotascaleRateLimitError(RotascaleAPIError):
    """Raised on 429 responses."""
