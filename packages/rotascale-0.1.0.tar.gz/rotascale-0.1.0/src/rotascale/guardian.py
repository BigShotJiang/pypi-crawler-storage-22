"""Guardian sub-client - AI safety scanning, monitoring, and alerts."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class ScanResult:
    """Result from a Guardian safety scan."""

    id: str
    passed: bool
    score: float
    checks: list[dict[str, Any]]
    prompt_tokens: int
    response_tokens: int
    latency_ms: float
    metadata: dict[str, Any] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ScanResult":
        return cls(
            id=data["id"],
            passed=data["passed"],
            score=data.get("score", 1.0 if data["passed"] else 0.0),
            checks=data.get("checks", []),
            prompt_tokens=data.get("prompt_tokens", 0),
            response_tokens=data.get("response_tokens", 0),
            latency_ms=data.get("latency_ms", 0),
            metadata=data.get("metadata"),
        )


class AsyncGuardianClient:
    """Async client for Guardian safety scanning API."""

    def __init__(self, http: Any) -> None:
        self._http = http

    # ── Scans ─────────────────────────────────────────────

    async def create_scan(
        self,
        prompt: str,
        response: str,
        model: str,
        *,
        checks: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ScanResult:
        """Create a new safety scan for an LLM interaction.

        Args:
            prompt: The user prompt sent to the LLM.
            response: The LLM's response.
            model: The model name (e.g., "gpt-4", "claude-3-opus").
            checks: Optional list of specific checks to run.
                    Defaults to all configured checks.
            metadata: Optional metadata to attach to the scan.

        Returns:
            ScanResult with pass/fail status and detailed check results.
        """
        payload = {
            "prompt": prompt,
            "response": response,
            "model": model,
        }
        if checks:
            payload["checks"] = checks
        if metadata:
            payload["metadata"] = metadata

        data = await self._http.post("/v1/guardian/scans", json=payload)
        return ScanResult.from_dict(data)

    async def get_scan(self, scan_id: str) -> ScanResult:
        """Get a scan by ID."""
        data = await self._http.get(f"/v1/guardian/scans/{scan_id}")
        return ScanResult.from_dict(data)

    async def list_scans(
        self,
        *,
        limit: int = 100,
        offset: int = 0,
        model: str | None = None,
        passed: bool | None = None,
    ) -> list[ScanResult]:
        """List recent scans with optional filtering."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if model:
            params["model"] = model
        if passed is not None:
            params["passed"] = passed

        data = await self._http.get("/v1/guardian/scans", params=params)
        items = data if isinstance(data, list) else data.get("items", [])
        return [ScanResult.from_dict(item) for item in items]

    # ── Monitors ────────────────────────────────────────────

    async def list_monitors(self) -> list[dict]:
        """List all monitors."""
        return await self._http.get("/v1/guardian/monitors")

    async def create_monitor(self, **kwargs: Any) -> dict:
        """Create a new monitor."""
        return await self._http.post("/v1/guardian/monitors", json=kwargs)

    async def get_monitor(self, monitor_id: str) -> dict:
        """Get a monitor by ID."""
        return await self._http.get(f"/v1/guardian/monitors/{monitor_id}")

    async def update_monitor(self, monitor_id: str, **kwargs: Any) -> dict:
        """Update a monitor."""
        return await self._http.patch(f"/v1/guardian/monitors/{monitor_id}", json=kwargs)

    async def delete_monitor(self, monitor_id: str) -> None:
        """Delete a monitor."""
        await self._http.delete(f"/v1/guardian/monitors/{monitor_id}")

    # ── Policies ───────────────────────────────────────────

    async def list_policies(self) -> list[dict]:
        """List all policies."""
        return await self._http.get("/v1/guardian/policies")

    async def create_policy(self, **kwargs: Any) -> dict:
        """Create a new policy."""
        return await self._http.post("/v1/guardian/policies", json=kwargs)

    async def get_policy(self, policy_id: str) -> dict:
        """Get a policy by ID."""
        return await self._http.get(f"/v1/guardian/policies/{policy_id}")

    async def update_policy(self, policy_id: str, **kwargs: Any) -> dict:
        """Update a policy."""
        return await self._http.patch(f"/v1/guardian/policies/{policy_id}", json=kwargs)

    async def delete_policy(self, policy_id: str) -> None:
        """Delete a policy."""
        await self._http.delete(f"/v1/guardian/policies/{policy_id}")

    # ── Alerts ──────────────────────────────────────────────

    async def list_alerts(
        self,
        *,
        limit: int = 100,
        status: str | None = None,
    ) -> list[dict]:
        """List alerts with optional filtering."""
        params: dict[str, Any] = {"limit": limit}
        if status:
            params["status"] = status
        return await self._http.get("/v1/guardian/alerts", params=params)

    async def get_alert(self, alert_id: str) -> dict:
        """Get an alert by ID."""
        return await self._http.get(f"/v1/guardian/alerts/{alert_id}")

    async def acknowledge_alert(self, alert_id: str) -> dict:
        """Acknowledge an alert."""
        return await self._http.post(f"/v1/guardian/alerts/{alert_id}/acknowledge")

    async def resolve_alert(self, alert_id: str, **kwargs: Any) -> dict:
        """Resolve an alert."""
        return await self._http.post(f"/v1/guardian/alerts/{alert_id}/resolve", json=kwargs)


class GuardianClient:
    """Sync client for Guardian safety scanning API."""

    def __init__(self, http: Any) -> None:
        self._http = http

    # ── Scans ─────────────────────────────────────────────

    def create_scan(
        self,
        prompt: str,
        response: str,
        model: str,
        *,
        checks: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ScanResult:
        """Create a new safety scan for an LLM interaction."""
        payload = {
            "prompt": prompt,
            "response": response,
            "model": model,
        }
        if checks:
            payload["checks"] = checks
        if metadata:
            payload["metadata"] = metadata

        data = self._http.post("/v1/guardian/scans", json=payload)
        return ScanResult.from_dict(data)

    def get_scan(self, scan_id: str) -> ScanResult:
        """Get a scan by ID."""
        data = self._http.get(f"/v1/guardian/scans/{scan_id}")
        return ScanResult.from_dict(data)

    def list_scans(
        self,
        *,
        limit: int = 100,
        offset: int = 0,
        model: str | None = None,
        passed: bool | None = None,
    ) -> list[ScanResult]:
        """List recent scans with optional filtering."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if model:
            params["model"] = model
        if passed is not None:
            params["passed"] = passed

        data = self._http.get("/v1/guardian/scans", params=params)
        items = data if isinstance(data, list) else data.get("items", [])
        return [ScanResult.from_dict(item) for item in items]

    # ── Monitors ────────────────────────────────────────────

    def list_monitors(self) -> list[dict]:
        return self._http.get("/v1/guardian/monitors")

    def create_monitor(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/guardian/monitors", json=kwargs)

    def get_monitor(self, monitor_id: str) -> dict:
        return self._http.get(f"/v1/guardian/monitors/{monitor_id}")

    def update_monitor(self, monitor_id: str, **kwargs: Any) -> dict:
        return self._http.patch(f"/v1/guardian/monitors/{monitor_id}", json=kwargs)

    def delete_monitor(self, monitor_id: str) -> None:
        self._http.delete(f"/v1/guardian/monitors/{monitor_id}")

    # ── Policies ───────────────────────────────────────────

    def list_policies(self) -> list[dict]:
        return self._http.get("/v1/guardian/policies")

    def create_policy(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/guardian/policies", json=kwargs)

    def get_policy(self, policy_id: str) -> dict:
        return self._http.get(f"/v1/guardian/policies/{policy_id}")

    def update_policy(self, policy_id: str, **kwargs: Any) -> dict:
        return self._http.patch(f"/v1/guardian/policies/{policy_id}", json=kwargs)

    def delete_policy(self, policy_id: str) -> None:
        self._http.delete(f"/v1/guardian/policies/{policy_id}")

    # ── Alerts ──────────────────────────────────────────────

    def list_alerts(
        self,
        *,
        limit: int = 100,
        status: str | None = None,
    ) -> list[dict]:
        params: dict[str, Any] = {"limit": limit}
        if status:
            params["status"] = status
        return self._http.get("/v1/guardian/alerts", params=params)

    def get_alert(self, alert_id: str) -> dict:
        return self._http.get(f"/v1/guardian/alerts/{alert_id}")

    def acknowledge_alert(self, alert_id: str) -> dict:
        return self._http.post(f"/v1/guardian/alerts/{alert_id}/acknowledge")

    def resolve_alert(self, alert_id: str, **kwargs: Any) -> dict:
        return self._http.post(f"/v1/guardian/alerts/{alert_id}/resolve", json=kwargs)
