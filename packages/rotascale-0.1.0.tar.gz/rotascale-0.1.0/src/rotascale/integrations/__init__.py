"""Rotascale integrations with third-party LLM providers.

This module provides integrations with popular LLM frameworks:

- **OpenAI**: Wrapped clients for automatic Guardian scanning
- **Anthropic**: Wrapped clients for automatic Guardian scanning
- **LangChain**: Callback handlers for automatic Guardian safety scanning
- **LlamaIndex**: Callback handlers for automatic Guardian safety scanning

Note: These integrations require additional dependencies. Install them as needed:

    pip install rotascale[openai]      # For OpenAI integration
    pip install rotascale[anthropic]   # For Anthropic integration
    pip install rotascale[langchain]   # For LangChain integration
    pip install rotascale[llamaindex]  # For LlamaIndex integration
    pip install rotascale[all]         # For all integrations
"""

from __future__ import annotations

from typing import TYPE_CHECKING

__all__: list[str] = [
    # OpenAI
    "RotascaleOpenAI",
    "AsyncRotascaleOpenAI",
    # Anthropic
    "RotascaleAnthropic",
    "AsyncRotascaleAnthropic",
    # LangChain
    "RotascaleCallback",
    "RotascaleRetrieverCallback",
    # LlamaIndex
    "RotascaleCallbackHandler",
]


# Lazy imports for optional dependencies
def __getattr__(name: str):
    # OpenAI integrations
    if name == "RotascaleOpenAI":
        from rotascale.integrations.openai import RotascaleOpenAI
        return RotascaleOpenAI
    if name == "AsyncRotascaleOpenAI":
        from rotascale.integrations.openai import AsyncRotascaleOpenAI
        return AsyncRotascaleOpenAI

    # Anthropic integrations
    if name == "RotascaleAnthropic":
        from rotascale.integrations.anthropic import RotascaleAnthropic
        return RotascaleAnthropic
    if name == "AsyncRotascaleAnthropic":
        from rotascale.integrations.anthropic import AsyncRotascaleAnthropic
        return AsyncRotascaleAnthropic

    # LangChain integrations
    if name == "RotascaleCallback":
        from rotascale.integrations.langchain import RotascaleCallback
        return RotascaleCallback
    if name == "RotascaleRetrieverCallback":
        from rotascale.integrations.langchain import RotascaleRetrieverCallback
        return RotascaleRetrieverCallback

    # LlamaIndex integrations
    if name == "RotascaleCallbackHandler":
        from rotascale.integrations.llamaindex import RotascaleCallbackHandler
        return RotascaleCallbackHandler

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


if TYPE_CHECKING:
    from rotascale.integrations.anthropic import (
        AsyncRotascaleAnthropic,
        RotascaleAnthropic,
    )
    from rotascale.integrations.langchain import (
        RotascaleCallback,
        RotascaleRetrieverCallback,
    )
    from rotascale.integrations.llamaindex import RotascaleCallbackHandler
    from rotascale.integrations.openai import (
        AsyncRotascaleOpenAI,
        RotascaleOpenAI,
    )
