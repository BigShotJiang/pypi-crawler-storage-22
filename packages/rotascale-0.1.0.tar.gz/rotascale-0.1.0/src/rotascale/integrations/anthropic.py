"""Anthropic SDK wrapper with Rotascale Guardian integration.

This module provides wrapped Anthropic clients that automatically scan
responses with Rotascale Guardian for safety and compliance.

Example usage::

    from rotascale.integrations.anthropic import RotascaleAnthropic

    client = RotascaleAnthropic(
        api_key="sk-ant-...",  # Anthropic key
        rotascale_api_key="rsk_live_...",
        block_unsafe=True,  # Block responses that fail Guardian scan
    )

    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[{"role": "user", "content": "Hello!"}]
    )
    # response._rotascale_scan contains scan results

Async usage::

    from rotascale.integrations.anthropic import AsyncRotascaleAnthropic

    client = AsyncRotascaleAnthropic(
        api_key="sk-ant-...",
        rotascale_api_key="rsk_live_...",
        block_unsafe=True,
    )

    response = await client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[{"role": "user", "content": "Hello!"}]
    )
    # response._rotascale_scan contains scan results
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Iterator, AsyncIterator

try:
    from anthropic import Anthropic, AsyncAnthropic
    from anthropic.types import Message, ContentBlock, TextBlock
    from anthropic._streaming import Stream, AsyncStream

    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False
    Anthropic = object  # type: ignore[misc, assignment]
    AsyncAnthropic = object  # type: ignore[misc, assignment]

from rotascale._http import AsyncHTTPClient, SyncHTTPClient
from rotascale.exceptions import RotascaleError

if TYPE_CHECKING:
    from anthropic import Anthropic as AnthropicType, AsyncAnthropic as AsyncAnthropicType
    from anthropic.types import Message as MessageType


_DEFAULT_ROTASCALE_BASE_URL = "http://localhost:8000"


class RotascaleUnsafeResponseError(RotascaleError):
    """Raised when a response fails Guardian safety scan and block_unsafe is True."""

    def __init__(self, message: str, scan_result: "GuardianScanResult") -> None:
        self.scan_result = scan_result
        super().__init__(message)


@dataclass
class GuardianScanResult:
    """Result of a Guardian safety scan on an LLM response."""

    safe: bool
    """Whether the response passed all safety checks."""

    risk_score: float
    """Risk score from 0.0 (safe) to 1.0 (high risk)."""

    categories: dict[str, float] = field(default_factory=dict)
    """Risk scores by category (e.g., toxicity, pii, jailbreak)."""

    flags: list[str] = field(default_factory=list)
    """List of triggered safety flags."""

    scan_id: str | None = None
    """Unique identifier for this scan."""

    latency_ms: float | None = None
    """Time taken for the scan in milliseconds."""

    metadata: dict[str, Any] = field(default_factory=dict)
    """Additional scan metadata."""

    @classmethod
    def from_api_response(cls, data: dict[str, Any]) -> "GuardianScanResult":
        """Create a GuardianScanResult from an API response."""
        return cls(
            safe=data.get("safe", True),
            risk_score=data.get("risk_score", 0.0),
            categories=data.get("categories", {}),
            flags=data.get("flags", []),
            scan_id=data.get("scan_id"),
            latency_ms=data.get("latency_ms"),
            metadata=data.get("metadata", {}),
        )


def _check_anthropic_installed() -> None:
    """Raise ImportError if anthropic is not installed."""
    if not HAS_ANTHROPIC:
        raise ImportError(
            "The anthropic package is required for this integration. "
            "Install it with: pip install anthropic"
        )


def _extract_message_content(message: Any) -> str:
    """Extract text content from an Anthropic message."""
    if not hasattr(message, "content"):
        return str(message)

    content_parts = []
    for block in message.content:
        if hasattr(block, "text"):
            content_parts.append(block.text)
        elif isinstance(block, dict) and "text" in block:
            content_parts.append(block["text"])

    return "\n".join(content_parts)


def _extract_prompt_from_messages(messages: list[dict[str, Any]]) -> str:
    """Extract prompt text from message list."""
    prompt_parts = []
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            prompt_parts.append(content)
        elif isinstance(content, list):
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    prompt_parts.append(block.get("text", ""))
                elif isinstance(block, str):
                    prompt_parts.append(block)
    return "\n".join(prompt_parts)


class RotascaleMessagesWrapper:
    """Wrapper around Anthropic's messages API that adds Guardian scanning."""

    def __init__(
        self,
        messages_api: Any,
        rotascale_http: SyncHTTPClient,
        block_unsafe: bool = False,
        scan_prompts: bool = False,
        monitor_id: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self._messages = messages_api
        self._http = rotascale_http
        self._block_unsafe = block_unsafe
        self._scan_prompts = scan_prompts
        self._monitor_id = monitor_id
        self._tags = tags or []
        self._metadata = metadata or {}

    def create(
        self,
        *,
        model: str,
        max_tokens: int,
        messages: list[dict[str, Any]],
        stream: bool = False,
        **kwargs: Any,
    ) -> Any:
        """Create a message with automatic Guardian scanning."""
        start_time = time.perf_counter()

        # Extract prompt for scanning
        prompt = _extract_prompt_from_messages(messages)
        system = kwargs.get("system", "")
        if system:
            prompt = f"{system}\n\n{prompt}"

        if stream:
            # Return wrapped stream
            raw_stream = self._messages.create(
                model=model,
                max_tokens=max_tokens,
                messages=messages,
                stream=True,
                **kwargs,
            )
            return RotascaleStream(
                raw_stream,
                self._http,
                prompt=prompt,
                model=model,
                block_unsafe=self._block_unsafe,
                monitor_id=self._monitor_id,
                tags=self._tags,
                metadata=self._metadata,
            )

        # Non-streaming request
        response = self._messages.create(
            model=model,
            max_tokens=max_tokens,
            messages=messages,
            stream=False,
            **kwargs,
        )

        latency_ms = (time.perf_counter() - start_time) * 1000

        # Extract response content
        response_text = _extract_message_content(response)

        # Scan with Guardian
        scan_result = self._scan_response(
            prompt=prompt,
            response=response_text,
            model=model,
            latency_ms=latency_ms,
            input_tokens=getattr(response.usage, "input_tokens", 0),
            output_tokens=getattr(response.usage, "output_tokens", 0),
        )

        # Attach scan result to response
        response._rotascale_scan = scan_result

        # Block if unsafe
        if self._block_unsafe and not scan_result.safe:
            raise RotascaleUnsafeResponseError(
                f"Response blocked by Guardian: {scan_result.flags}",
                scan_result,
            )

        return response

    def _scan_response(
        self,
        prompt: str,
        response: str,
        model: str,
        latency_ms: float,
        input_tokens: int = 0,
        output_tokens: int = 0,
    ) -> GuardianScanResult:
        """Send response to Guardian for scanning."""
        try:
            scan_start = time.perf_counter()

            scan_payload = {
                "prompt": prompt,
                "response": response,
                "model": model,
                "source": "anthropic",
                "tags": self._tags,
                "metadata": {
                    **self._metadata,
                    "llm_latency_ms": latency_ms,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                },
            }

            if self._monitor_id:
                result = self._http.post(
                    f"/v1/guardian/monitors/{self._monitor_id}/detections",
                    json=scan_payload,
                )
            else:
                result = self._http.post("/v1/guardian/scan", json=scan_payload)

            scan_latency = (time.perf_counter() - scan_start) * 1000

            scan_result = GuardianScanResult.from_api_response(result)
            scan_result.latency_ms = scan_latency
            return scan_result

        except Exception as e:
            # Return safe result on scan failure
            return GuardianScanResult(
                safe=True,
                risk_score=0.0,
                metadata={"error": str(e), "scan_failed": True},
            )

    def __getattr__(self, name: str) -> Any:
        """Forward other attributes to the underlying messages API."""
        return getattr(self._messages, name)


class AsyncRotascaleMessagesWrapper:
    """Async wrapper around Anthropic's messages API that adds Guardian scanning."""

    def __init__(
        self,
        messages_api: Any,
        rotascale_http: AsyncHTTPClient,
        block_unsafe: bool = False,
        scan_prompts: bool = False,
        monitor_id: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self._messages = messages_api
        self._http = rotascale_http
        self._block_unsafe = block_unsafe
        self._scan_prompts = scan_prompts
        self._monitor_id = monitor_id
        self._tags = tags or []
        self._metadata = metadata or {}

    async def create(
        self,
        *,
        model: str,
        max_tokens: int,
        messages: list[dict[str, Any]],
        stream: bool = False,
        **kwargs: Any,
    ) -> Any:
        """Create a message with automatic Guardian scanning."""
        start_time = time.perf_counter()

        # Extract prompt for scanning
        prompt = _extract_prompt_from_messages(messages)
        system = kwargs.get("system", "")
        if system:
            prompt = f"{system}\n\n{prompt}"

        if stream:
            # Return wrapped stream
            raw_stream = await self._messages.create(
                model=model,
                max_tokens=max_tokens,
                messages=messages,
                stream=True,
                **kwargs,
            )
            return AsyncRotascaleStream(
                raw_stream,
                self._http,
                prompt=prompt,
                model=model,
                block_unsafe=self._block_unsafe,
                monitor_id=self._monitor_id,
                tags=self._tags,
                metadata=self._metadata,
            )

        # Non-streaming request
        response = await self._messages.create(
            model=model,
            max_tokens=max_tokens,
            messages=messages,
            stream=False,
            **kwargs,
        )

        latency_ms = (time.perf_counter() - start_time) * 1000

        # Extract response content
        response_text = _extract_message_content(response)

        # Scan with Guardian
        scan_result = await self._scan_response(
            prompt=prompt,
            response=response_text,
            model=model,
            latency_ms=latency_ms,
            input_tokens=getattr(response.usage, "input_tokens", 0),
            output_tokens=getattr(response.usage, "output_tokens", 0),
        )

        # Attach scan result to response
        response._rotascale_scan = scan_result

        # Block if unsafe
        if self._block_unsafe and not scan_result.safe:
            raise RotascaleUnsafeResponseError(
                f"Response blocked by Guardian: {scan_result.flags}",
                scan_result,
            )

        return response

    async def _scan_response(
        self,
        prompt: str,
        response: str,
        model: str,
        latency_ms: float,
        input_tokens: int = 0,
        output_tokens: int = 0,
    ) -> GuardianScanResult:
        """Send response to Guardian for scanning."""
        try:
            scan_start = time.perf_counter()

            scan_payload = {
                "prompt": prompt,
                "response": response,
                "model": model,
                "source": "anthropic",
                "tags": self._tags,
                "metadata": {
                    **self._metadata,
                    "llm_latency_ms": latency_ms,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                },
            }

            if self._monitor_id:
                result = await self._http.post(
                    f"/v1/guardian/monitors/{self._monitor_id}/detections",
                    json=scan_payload,
                )
            else:
                result = await self._http.post("/v1/guardian/scan", json=scan_payload)

            scan_latency = (time.perf_counter() - scan_start) * 1000

            scan_result = GuardianScanResult.from_api_response(result)
            scan_result.latency_ms = scan_latency
            return scan_result

        except Exception as e:
            # Return safe result on scan failure
            return GuardianScanResult(
                safe=True,
                risk_score=0.0,
                metadata={"error": str(e), "scan_failed": True},
            )

    def __getattr__(self, name: str) -> Any:
        """Forward other attributes to the underlying messages API."""
        return getattr(self._messages, name)


class RotascaleStream:
    """Wrapper around Anthropic's streaming response that scans at completion."""

    def __init__(
        self,
        stream: Any,
        rotascale_http: SyncHTTPClient,
        prompt: str,
        model: str,
        block_unsafe: bool = False,
        monitor_id: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self._stream = stream
        self._http = rotascale_http
        self._prompt = prompt
        self._model = model
        self._block_unsafe = block_unsafe
        self._monitor_id = monitor_id
        self._tags = tags or []
        self._metadata = metadata or {}
        self._collected_content: list[str] = []
        self._start_time = time.perf_counter()
        self._input_tokens = 0
        self._output_tokens = 0

    def __iter__(self) -> Iterator[Any]:
        return self

    def __next__(self) -> Any:
        try:
            event = next(self._stream)

            # Collect text content
            if hasattr(event, "type"):
                if event.type == "content_block_delta":
                    if hasattr(event.delta, "text"):
                        self._collected_content.append(event.delta.text)
                elif event.type == "message_delta":
                    if hasattr(event, "usage"):
                        self._output_tokens = getattr(event.usage, "output_tokens", 0)
                elif event.type == "message_start":
                    if hasattr(event, "message") and hasattr(event.message, "usage"):
                        self._input_tokens = getattr(
                            event.message.usage, "input_tokens", 0
                        )

            return event
        except StopIteration:
            # Stream complete - scan the full response
            self._scan_collected_content()
            raise

    def _scan_collected_content(self) -> None:
        """Scan the collected response content."""
        if not self._collected_content:
            return

        response_text = "".join(self._collected_content)
        latency_ms = (time.perf_counter() - self._start_time) * 1000

        try:
            scan_payload = {
                "prompt": self._prompt,
                "response": response_text,
                "model": self._model,
                "source": "anthropic",
                "tags": self._tags,
                "metadata": {
                    **self._metadata,
                    "llm_latency_ms": latency_ms,
                    "input_tokens": self._input_tokens,
                    "output_tokens": self._output_tokens,
                    "streaming": True,
                },
            }

            if self._monitor_id:
                self._http.post(
                    f"/v1/guardian/monitors/{self._monitor_id}/detections",
                    json=scan_payload,
                )
            else:
                self._http.post("/v1/guardian/scan", json=scan_payload)
        except Exception:
            pass  # Fail silently for streaming

    def __enter__(self) -> "RotascaleStream":
        return self

    def __exit__(self, *args: Any) -> None:
        pass


class AsyncRotascaleStream:
    """Async wrapper around Anthropic's streaming response that scans at completion."""

    def __init__(
        self,
        stream: Any,
        rotascale_http: AsyncHTTPClient,
        prompt: str,
        model: str,
        block_unsafe: bool = False,
        monitor_id: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self._stream = stream
        self._http = rotascale_http
        self._prompt = prompt
        self._model = model
        self._block_unsafe = block_unsafe
        self._monitor_id = monitor_id
        self._tags = tags or []
        self._metadata = metadata or {}
        self._collected_content: list[str] = []
        self._start_time = time.perf_counter()
        self._input_tokens = 0
        self._output_tokens = 0

    def __aiter__(self) -> AsyncIterator[Any]:
        return self

    async def __anext__(self) -> Any:
        try:
            event = await self._stream.__anext__()

            # Collect text content
            if hasattr(event, "type"):
                if event.type == "content_block_delta":
                    if hasattr(event.delta, "text"):
                        self._collected_content.append(event.delta.text)
                elif event.type == "message_delta":
                    if hasattr(event, "usage"):
                        self._output_tokens = getattr(event.usage, "output_tokens", 0)
                elif event.type == "message_start":
                    if hasattr(event, "message") and hasattr(event.message, "usage"):
                        self._input_tokens = getattr(
                            event.message.usage, "input_tokens", 0
                        )

            return event
        except StopAsyncIteration:
            # Stream complete - scan the full response
            await self._scan_collected_content()
            raise

    async def _scan_collected_content(self) -> None:
        """Scan the collected response content."""
        if not self._collected_content:
            return

        response_text = "".join(self._collected_content)
        latency_ms = (time.perf_counter() - self._start_time) * 1000

        try:
            scan_payload = {
                "prompt": self._prompt,
                "response": response_text,
                "model": self._model,
                "source": "anthropic",
                "tags": self._tags,
                "metadata": {
                    **self._metadata,
                    "llm_latency_ms": latency_ms,
                    "input_tokens": self._input_tokens,
                    "output_tokens": self._output_tokens,
                    "streaming": True,
                },
            }

            if self._monitor_id:
                await self._http.post(
                    f"/v1/guardian/monitors/{self._monitor_id}/detections",
                    json=scan_payload,
                )
            else:
                await self._http.post("/v1/guardian/scan", json=scan_payload)
        except Exception:
            pass  # Fail silently for streaming

    async def __aenter__(self) -> "AsyncRotascaleStream":
        return self

    async def __aexit__(self, *args: Any) -> None:
        pass


class RotascaleAnthropic:
    """Wrapped Anthropic client with automatic Rotascale Guardian scanning.

    This client wraps the standard Anthropic client and automatically scans
    all message responses with Rotascale Guardian for safety compliance.

    Args:
        api_key: Anthropic API key. If not provided, uses ANTHROPIC_API_KEY env var.
        rotascale_api_key: Rotascale API key. If not provided, uses ROTASCALE_API_KEY env var.
        rotascale_base_url: Rotascale API base URL (default: http://localhost:8000).
        block_unsafe: If True, raise RotascaleUnsafeResponseError for unsafe responses.
        scan_prompts: If True, also scan input prompts (default: False).
        monitor_id: Guardian monitor ID for scanning.
        tags: Optional tags to attach to scans.
        metadata: Optional metadata to attach to scans.
        **kwargs: Additional arguments passed to Anthropic client.

    Example::

        from rotascale.integrations.anthropic import RotascaleAnthropic

        client = RotascaleAnthropic(
            api_key="sk-ant-...",
            rotascale_api_key="rsk_live_...",
            block_unsafe=True,
        )

        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello!"}]
        )
        print(response._rotascale_scan.safe)  # True/False
    """

    def __init__(
        self,
        api_key: str | None = None,
        rotascale_api_key: str | None = None,
        rotascale_base_url: str = _DEFAULT_ROTASCALE_BASE_URL,
        block_unsafe: bool = False,
        scan_prompts: bool = False,
        monitor_id: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        _check_anthropic_installed()

        # Get API keys from environment if not provided
        anthropic_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        rotascale_key = rotascale_api_key or os.environ.get("ROTASCALE_API_KEY")

        if not anthropic_key:
            raise ValueError(
                "Anthropic API key is required. "
                "Pass api_key or set ANTHROPIC_API_KEY environment variable."
            )
        if not rotascale_key:
            raise ValueError(
                "Rotascale API key is required. "
                "Pass rotascale_api_key or set ROTASCALE_API_KEY environment variable."
            )

        self._client = Anthropic(api_key=anthropic_key, **kwargs)
        self._rotascale_http = SyncHTTPClient(
            base_url=rotascale_base_url.rstrip("/"),
            api_key=rotascale_key,
        )
        self._block_unsafe = block_unsafe
        self._scan_prompts = scan_prompts
        self._monitor_id = monitor_id
        self._tags = tags or []
        self._metadata = metadata or {}

        # Wrap messages API
        self.messages = RotascaleMessagesWrapper(
            self._client.messages,
            self._rotascale_http,
            block_unsafe=block_unsafe,
            scan_prompts=scan_prompts,
            monitor_id=monitor_id,
            tags=tags,
            metadata=metadata,
        )

    def close(self) -> None:
        """Close the client and release resources."""
        self._client.close()
        self._rotascale_http.close()

    def __enter__(self) -> "RotascaleAnthropic":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def __getattr__(self, name: str) -> Any:
        """Forward other attributes to the underlying Anthropic client."""
        return getattr(self._client, name)


class AsyncRotascaleAnthropic:
    """Async wrapped Anthropic client with automatic Rotascale Guardian scanning.

    This client wraps the standard async Anthropic client and automatically scans
    all message responses with Rotascale Guardian for safety compliance.

    Args:
        api_key: Anthropic API key. If not provided, uses ANTHROPIC_API_KEY env var.
        rotascale_api_key: Rotascale API key. If not provided, uses ROTASCALE_API_KEY env var.
        rotascale_base_url: Rotascale API base URL (default: http://localhost:8000).
        block_unsafe: If True, raise RotascaleUnsafeResponseError for unsafe responses.
        scan_prompts: If True, also scan input prompts (default: False).
        monitor_id: Guardian monitor ID for scanning.
        tags: Optional tags to attach to scans.
        metadata: Optional metadata to attach to scans.
        **kwargs: Additional arguments passed to AsyncAnthropic client.

    Example::

        from rotascale.integrations.anthropic import AsyncRotascaleAnthropic

        async with AsyncRotascaleAnthropic(
            api_key="sk-ant-...",
            rotascale_api_key="rsk_live_...",
        ) as client:
            response = await client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=1024,
                messages=[{"role": "user", "content": "Hello!"}]
            )
            print(response._rotascale_scan.safe)
    """

    def __init__(
        self,
        api_key: str | None = None,
        rotascale_api_key: str | None = None,
        rotascale_base_url: str = _DEFAULT_ROTASCALE_BASE_URL,
        block_unsafe: bool = False,
        scan_prompts: bool = False,
        monitor_id: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        _check_anthropic_installed()

        # Get API keys from environment if not provided
        anthropic_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        rotascale_key = rotascale_api_key or os.environ.get("ROTASCALE_API_KEY")

        if not anthropic_key:
            raise ValueError(
                "Anthropic API key is required. "
                "Pass api_key or set ANTHROPIC_API_KEY environment variable."
            )
        if not rotascale_key:
            raise ValueError(
                "Rotascale API key is required. "
                "Pass rotascale_api_key or set ROTASCALE_API_KEY environment variable."
            )

        self._client = AsyncAnthropic(api_key=anthropic_key, **kwargs)
        self._rotascale_http = AsyncHTTPClient(
            base_url=rotascale_base_url.rstrip("/"),
            api_key=rotascale_key,
        )
        self._block_unsafe = block_unsafe
        self._scan_prompts = scan_prompts
        self._monitor_id = monitor_id
        self._tags = tags or []
        self._metadata = metadata or {}

        # Wrap messages API
        self.messages = AsyncRotascaleMessagesWrapper(
            self._client.messages,
            self._rotascale_http,
            block_unsafe=block_unsafe,
            scan_prompts=scan_prompts,
            monitor_id=monitor_id,
            tags=tags,
            metadata=metadata,
        )

    async def close(self) -> None:
        """Close the client and release resources."""
        await self._client.close()
        await self._rotascale_http.close()

    async def __aenter__(self) -> "AsyncRotascaleAnthropic":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    def __getattr__(self, name: str) -> Any:
        """Forward other attributes to the underlying Anthropic client."""
        return getattr(self._client, name)
