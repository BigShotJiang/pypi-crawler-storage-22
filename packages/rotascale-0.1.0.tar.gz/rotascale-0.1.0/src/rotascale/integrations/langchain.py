"""LangChain integration for Rotascale Guardian safety scanning.

This module provides callback handlers for automatically sending LLM outputs
to Rotascale Guardian for safety scanning and monitoring.

Example usage::

    from langchain_openai import ChatOpenAI
    from rotascale.integrations.langchain import RotascaleCallback

    callback = RotascaleCallback(
        api_key="rsk_live_...",
        scan_responses=True,  # Enable Guardian scanning
    )

    llm = ChatOpenAI(callbacks=[callback])
    response = llm.invoke("Hello!")  # Auto-scanned by Guardian

For RAG applications, you can also track retriever context::

    from langchain.retrievers import VectorStoreRetriever
    from rotascale.integrations.langchain import RotascaleRetrieverCallback

    retriever_callback = RotascaleRetrieverCallback(
        api_key="rsk_live_...",
    )

    retriever = VectorStoreRetriever(callbacks=[retriever_callback])
"""

from __future__ import annotations

import logging
import time
from typing import Any, Sequence
from uuid import UUID

try:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.documents import Document
    from langchain_core.messages import BaseMessage
    from langchain_core.outputs import LLMResult
except ImportError as e:
    raise ImportError(
        "LangChain is required for this integration. "
        "Install it with: pip install langchain-core"
    ) from e

from rotascale._http import SyncHTTPClient
from rotascale.exceptions import RotascaleError

logger = logging.getLogger(__name__)

_DEFAULT_BASE_URL = "http://localhost:8000"


class RotascaleCallback(BaseCallbackHandler):
    """LangChain callback handler for Rotascale Guardian integration.

    This callback handler automatically sends LLM prompts and responses to
    Rotascale Guardian for safety scanning and monitoring.

    Args:
        api_key: Rotascale API key (e.g., "rsk_live_...")
        base_url: Rotascale API base URL (default: http://localhost:8000)
        monitor_id: Guardian monitor ID for scanning (required for scanning)
        model_name: Model name to record (auto-detected from LLM if not set)
        scan_responses: Enable Guardian safety scanning (default: True)
        scan_prompts: Also scan input prompts (default: False)
        tags: Optional tags to attach to interactions
        metadata: Optional metadata to attach to interactions
        fail_silently: If True, errors are logged but not raised (default: True)
        timeout: HTTP request timeout in seconds (default: 30.0)

    Example::

        from langchain_openai import ChatOpenAI
        from rotascale.integrations.langchain import RotascaleCallback

        callback = RotascaleCallback(
            api_key="rsk_live_...",
            monitor_id="mon_123",
            scan_responses=True,
        )

        llm = ChatOpenAI(callbacks=[callback])
        response = llm.invoke("Hello!")  # Auto-scanned by Guardian
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        monitor_id: str | None = None,
        model_name: str | None = None,
        scan_responses: bool = True,
        scan_prompts: bool = False,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        fail_silently: bool = True,
        timeout: float = 30.0,
    ) -> None:
        super().__init__()
        self.api_key = api_key
        self.base_url = base_url
        self.monitor_id = monitor_id
        self.model_name = model_name
        self.scan_responses = scan_responses
        self.scan_prompts = scan_prompts
        self.tags = tags or []
        self.metadata = metadata or {}
        self.fail_silently = fail_silently
        self.timeout = timeout

        self._http = SyncHTTPClient(base_url, api_key, timeout)

        # Track state across callback invocations
        self._run_states: dict[UUID, _RunState] = {}

    def close(self) -> None:
        """Close the HTTP client."""
        self._http.close()

    def __enter__(self) -> RotascaleCallback:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    # ── LLM Callbacks ──────────────────────────────────────────────────────

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when LLM starts running."""
        # Extract model name from serialized config
        model_name = self.model_name
        if not model_name:
            model_name = serialized.get("kwargs", {}).get("model_name")
            if not model_name:
                model_name = serialized.get("kwargs", {}).get("model")
            if not model_name:
                model_name = serialized.get("name", "unknown")

        # Store run state
        self._run_states[run_id] = _RunState(
            prompts=prompts,
            model_name=model_name,
            start_time=time.perf_counter(),
            tags=(tags or []) + self.tags,
            metadata={**(metadata or {}), **self.metadata},
        )

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when LLM ends running. Sends response to Guardian for scanning."""
        run_state = self._run_states.pop(run_id, None)
        if run_state is None:
            logger.warning("on_llm_end called without matching on_llm_start for run_id=%s", run_id)
            return

        # Calculate latency
        latency_ms = (time.perf_counter() - run_state.start_time) * 1000

        # Extract token usage
        token_usage = response.llm_output or {}
        if isinstance(token_usage, dict):
            token_usage = token_usage.get("token_usage", token_usage)

        prompt_tokens = token_usage.get("prompt_tokens", 0) if isinstance(token_usage, dict) else 0
        completion_tokens = token_usage.get("completion_tokens", 0) if isinstance(token_usage, dict) else 0
        total_tokens = token_usage.get("total_tokens", prompt_tokens + completion_tokens) if isinstance(token_usage, dict) else 0

        # Process each generation
        for gen_idx, generations in enumerate(response.generations):
            for gen in generations:
                prompt = run_state.prompts[gen_idx] if gen_idx < len(run_state.prompts) else ""
                response_text = gen.text

                # Build metadata for this interaction
                interaction_metadata = {
                    **run_state.metadata,
                    "model_name": run_state.model_name,
                    "latency_ms": latency_ms,
                    "prompt_tokens": prompt_tokens,
                    "completion_tokens": completion_tokens,
                    "total_tokens": total_tokens,
                    "tags": run_state.tags,
                    "source": "langchain",
                }

                # Send to Guardian for scanning
                if self.scan_responses and self.monitor_id:
                    self._send_to_guardian(
                        prompt=prompt,
                        response=response_text,
                        metadata=interaction_metadata,
                    )

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when LLM errors."""
        # Clean up run state
        self._run_states.pop(run_id, None)

    # ── Chat Model Callbacks ───────────────────────────────────────────────

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[BaseMessage]],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when chat model starts running."""
        # Extract model name
        model_name = self.model_name
        if not model_name:
            model_name = serialized.get("kwargs", {}).get("model_name")
            if not model_name:
                model_name = serialized.get("kwargs", {}).get("model")
            if not model_name:
                model_name = serialized.get("name", "unknown")

        # Convert messages to prompt strings
        prompts = []
        for message_list in messages:
            prompt_parts = []
            for msg in message_list:
                role = getattr(msg, "type", "unknown")
                content = msg.content if isinstance(msg.content, str) else str(msg.content)
                prompt_parts.append(f"{role}: {content}")
            prompts.append("\n".join(prompt_parts))

        # Store run state
        self._run_states[run_id] = _RunState(
            prompts=prompts,
            model_name=model_name,
            start_time=time.perf_counter(),
            tags=(tags or []) + self.tags,
            metadata={**(metadata or {}), **self.metadata},
        )

    # ── Helper Methods ─────────────────────────────────────────────────────

    def _send_to_guardian(
        self,
        prompt: str,
        response: str,
        metadata: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Send an interaction to Guardian for scanning."""
        if not self.monitor_id:
            logger.warning("Cannot send to Guardian: monitor_id not set")
            return None

        try:
            # Use the run_detection endpoint for scanning
            result = self._http.post(
                f"/v1/guardian/monitors/{self.monitor_id}/detections",
                json={
                    "samples": [
                        {
                            "prompt": prompt,
                            "response": response,
                            "metadata": metadata,
                        }
                    ],
                    "detection_type": "sandbagging",
                },
            )
            return result
        except RotascaleError as e:
            if self.fail_silently:
                logger.warning("Failed to send to Guardian: %s", e)
                return None
            raise


class _RunState:
    """Internal state tracking for a single LLM run."""

    __slots__ = ("prompts", "model_name", "start_time", "tags", "metadata")

    def __init__(
        self,
        prompts: list[str],
        model_name: str,
        start_time: float,
        tags: list[str],
        metadata: dict[str, Any],
    ) -> None:
        self.prompts = prompts
        self.model_name = model_name
        self.start_time = start_time
        self.tags = tags
        self.metadata = metadata


class RotascaleRetrieverCallback(BaseCallbackHandler):
    """LangChain callback handler for tracking RAG retriever context.

    This callback handler tracks documents retrieved during RAG operations
    and sends context information to Rotascale for monitoring.

    Args:
        api_key: Rotascale API key (e.g., "rsk_live_...")
        base_url: Rotascale API base URL (default: http://localhost:8000)
        monitor_id: Guardian monitor ID for tracking
        tags: Optional tags to attach to context records
        metadata: Optional metadata to attach to context records
        fail_silently: If True, errors are logged but not raised (default: True)
        timeout: HTTP request timeout in seconds (default: 30.0)

    Example::

        from langchain.retrievers import VectorStoreRetriever
        from rotascale.integrations.langchain import RotascaleRetrieverCallback

        retriever_callback = RotascaleRetrieverCallback(
            api_key="rsk_live_...",
            monitor_id="mon_123",
        )

        retriever = VectorStoreRetriever(callbacks=[retriever_callback])
        docs = retriever.invoke("What is the capital of France?")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        monitor_id: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        fail_silently: bool = True,
        timeout: float = 30.0,
    ) -> None:
        super().__init__()
        self.api_key = api_key
        self.base_url = base_url
        self.monitor_id = monitor_id
        self.tags = tags or []
        self.metadata = metadata or {}
        self.fail_silently = fail_silently
        self.timeout = timeout

        self._http = SyncHTTPClient(base_url, api_key, timeout)

        # Track retrieval state
        self._run_states: dict[UUID, _RetrieverRunState] = {}

    def close(self) -> None:
        """Close the HTTP client."""
        self._http.close()

    def __enter__(self) -> RotascaleRetrieverCallback:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    # ── Retriever Callbacks ────────────────────────────────────────────────

    def on_retriever_start(
        self,
        serialized: dict[str, Any],
        query: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when retriever starts running."""
        self._run_states[run_id] = _RetrieverRunState(
            query=query,
            start_time=time.perf_counter(),
            tags=(tags or []) + self.tags,
            metadata={**(metadata or {}), **self.metadata},
            parent_run_id=parent_run_id,
        )

    def on_retriever_end(
        self,
        documents: Sequence[Document],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when retriever ends. Records context to Rotascale."""
        run_state = self._run_states.pop(run_id, None)
        if run_state is None:
            logger.warning("on_retriever_end called without matching on_retriever_start for run_id=%s", run_id)
            return

        # Calculate latency
        latency_ms = (time.perf_counter() - run_state.start_time) * 1000

        # Extract document information
        doc_info = []
        for doc in documents:
            doc_info.append({
                "content": doc.page_content[:1000],  # Truncate for safety
                "metadata": doc.metadata,
            })

        # Build context metadata
        context_metadata = {
            **run_state.metadata,
            "query": run_state.query,
            "document_count": len(documents),
            "latency_ms": latency_ms,
            "tags": run_state.tags,
            "source": "langchain_retriever",
            "documents": doc_info,
        }

        # Record the retrieval context
        if self.monitor_id:
            self._record_context(context_metadata)

    def on_retriever_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when retriever errors."""
        self._run_states.pop(run_id, None)

    # ── Helper Methods ─────────────────────────────────────────────────────

    def _record_context(self, metadata: dict[str, Any]) -> dict[str, Any] | None:
        """Record retrieval context to Rotascale."""
        if not self.monitor_id:
            logger.warning("Cannot record context: monitor_id not set")
            return None

        try:
            # Use the observer endpoint to record the interaction
            result = self._http.post(
                f"/v1/guardian/monitors/{self.monitor_id}/observer/interactions",
                json={
                    "response": metadata.get("query", ""),
                    "metadata": metadata,
                },
            )
            return result
        except RotascaleError as e:
            if self.fail_silently:
                logger.warning("Failed to record context: %s", e)
                return None
            raise


class _RetrieverRunState:
    """Internal state tracking for a single retriever run."""

    __slots__ = ("query", "start_time", "tags", "metadata", "parent_run_id")

    def __init__(
        self,
        query: str,
        start_time: float,
        tags: list[str],
        metadata: dict[str, Any],
        parent_run_id: UUID | None,
    ) -> None:
        self.query = query
        self.start_time = start_time
        self.tags = tags
        self.metadata = metadata
        self.parent_run_id = parent_run_id
