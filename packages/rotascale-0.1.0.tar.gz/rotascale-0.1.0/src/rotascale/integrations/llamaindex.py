"""LlamaIndex integration for Rotascale Guardian safety scanning.

This module provides callback handlers for automatically sending LLM outputs
to Rotascale Guardian for safety scanning and monitoring.

Example usage::

    from llama_index.core import VectorStoreIndex
    from llama_index.core.callbacks import CallbackManager
    from rotascale.integrations.llamaindex import RotascaleCallbackHandler

    callback_handler = RotascaleCallbackHandler(
        api_key="rsk_live_...",
        monitor_id="mon_123",
    )
    callback_manager = CallbackManager([callback_handler])

    index = VectorStoreIndex.from_documents(
        documents,
        callback_manager=callback_manager,
    )

    query_engine = index.as_query_engine()
    response = query_engine.query("What is the meaning of life?")
    # Response is automatically scanned by Guardian

For Settings-based configuration::

    from llama_index.core import Settings
    from rotascale.integrations.llamaindex import RotascaleCallbackHandler

    handler = RotascaleCallbackHandler(api_key="rsk_live_...")
    Settings.callback_manager = CallbackManager([handler])
"""

from __future__ import annotations

import logging
import time
from typing import Any

try:
    from llama_index.core.callbacks import CBEventType, EventPayload
    from llama_index.core.callbacks.base_handler import BaseCallbackHandler
except ImportError as e:
    raise ImportError(
        "LlamaIndex is required for this integration. "
        "Install it with: pip install llama-index-core"
    ) from e

from rotascale._http import SyncHTTPClient
from rotascale.exceptions import RotascaleError

logger = logging.getLogger(__name__)

_DEFAULT_BASE_URL = "http://localhost:8000"


class RotascaleCallbackHandler(BaseCallbackHandler):
    """LlamaIndex callback handler for Rotascale Guardian integration.

    This callback handler automatically sends LLM prompts and responses to
    Rotascale Guardian for safety scanning and monitoring.

    Args:
        api_key: Rotascale API key (e.g., "rsk_live_...")
        base_url: Rotascale API base URL (default: http://localhost:8000)
        monitor_id: Guardian monitor ID for scanning (required for scanning)
        scan_responses: Enable Guardian safety scanning (default: True)
        scan_queries: Also scan input queries (default: False)
        track_retrieval: Track retrieval events for context (default: True)
        tags: Optional tags to attach to interactions
        metadata: Optional metadata to attach to interactions
        fail_silently: If True, errors are logged but not raised (default: True)
        timeout: HTTP request timeout in seconds (default: 30.0)

    Example::

        from llama_index.core.callbacks import CallbackManager
        from rotascale.integrations.llamaindex import RotascaleCallbackHandler

        handler = RotascaleCallbackHandler(
            api_key="rsk_live_...",
            monitor_id="mon_123",
        )
        callback_manager = CallbackManager([handler])
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        monitor_id: str | None = None,
        scan_responses: bool = True,
        scan_queries: bool = False,
        track_retrieval: bool = True,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        fail_silently: bool = True,
        timeout: float = 30.0,
    ) -> None:
        super().__init__(
            event_starts_to_ignore=[],
            event_ends_to_ignore=[],
        )
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.monitor_id = monitor_id
        self.scan_responses = scan_responses
        self.scan_queries = scan_queries
        self.track_retrieval = track_retrieval
        self.tags = tags or []
        self.metadata = metadata or {}
        self.fail_silently = fail_silently
        self.timeout = timeout

        self._http = SyncHTTPClient(
            base_url=self.base_url,
            api_key=self.api_key,
            timeout=self.timeout,
        )

        # Track event timing and context
        self._event_starts: dict[str, float] = {}
        self._event_prompts: dict[str, str] = {}
        self._retrieval_context: dict[str, list[str]] = {}

    def on_event_start(
        self,
        event_type: CBEventType,
        payload: dict[str, Any] | None = None,
        event_id: str = "",
        parent_id: str = "",
        **kwargs: Any,
    ) -> str:
        """Handle event start - capture timing and prompts."""
        self._event_starts[event_id] = time.perf_counter()

        if payload is None:
            return event_id

        # Capture LLM prompts
        if event_type == CBEventType.LLM:
            messages = payload.get(EventPayload.MESSAGES)
            if messages:
                # Extract text from messages
                prompt_parts = []
                for msg in messages:
                    if hasattr(msg, "content"):
                        prompt_parts.append(str(msg.content))
                    elif isinstance(msg, str):
                        prompt_parts.append(msg)
                self._event_prompts[event_id] = "\n".join(prompt_parts)

            # Also check for prompt template
            prompt = payload.get(EventPayload.PROMPT)
            if prompt and event_id not in self._event_prompts:
                self._event_prompts[event_id] = str(prompt)

        # Capture query for query events
        elif event_type == CBEventType.QUERY:
            query_str = payload.get(EventPayload.QUERY_STR)
            if query_str:
                self._event_prompts[event_id] = str(query_str)

        # Track retrieval context
        elif event_type == CBEventType.RETRIEVE and self.track_retrieval:
            query_str = payload.get(EventPayload.QUERY_STR)
            if query_str:
                self._event_prompts[event_id] = str(query_str)

        return event_id

    def on_event_end(
        self,
        event_type: CBEventType,
        payload: dict[str, Any] | None = None,
        event_id: str = "",
        **kwargs: Any,
    ) -> None:
        """Handle event end - scan responses and track metrics."""
        if payload is None:
            return

        # Calculate latency
        start_time = self._event_starts.pop(event_id, None)
        latency_ms = (
            (time.perf_counter() - start_time) * 1000 if start_time else None
        )

        # Handle LLM completion
        if event_type == CBEventType.LLM:
            self._handle_llm_end(event_id, payload, latency_ms)

        # Handle retrieval completion
        elif event_type == CBEventType.RETRIEVE and self.track_retrieval:
            self._handle_retrieval_end(event_id, payload)

        # Clean up
        self._event_prompts.pop(event_id, None)

    def _handle_llm_end(
        self,
        event_id: str,
        payload: dict[str, Any],
        latency_ms: float | None,
    ) -> None:
        """Process LLM completion event."""
        response = payload.get(EventPayload.RESPONSE)
        completion = payload.get(EventPayload.COMPLETION)

        # Extract response text
        response_text = None
        if response is not None:
            if hasattr(response, "text"):
                response_text = response.text
            elif hasattr(response, "message"):
                response_text = str(response.message.content)
            else:
                response_text = str(response)
        elif completion is not None:
            if hasattr(completion, "text"):
                response_text = completion.text
            else:
                response_text = str(completion)

        if not response_text:
            return

        prompt = self._event_prompts.get(event_id, "")

        # Extract token counts if available
        token_counts = {}
        raw_response = payload.get("raw", {})
        if hasattr(raw_response, "usage"):
            usage = raw_response.usage
            token_counts = {
                "prompt_tokens": getattr(usage, "prompt_tokens", 0),
                "completion_tokens": getattr(usage, "completion_tokens", 0),
                "total_tokens": getattr(usage, "total_tokens", 0),
            }

        # Send to Guardian for scanning
        if self.scan_responses and self.monitor_id:
            self._scan_content(
                prompt=prompt,
                response=response_text,
                latency_ms=latency_ms,
                token_counts=token_counts,
            )

    def _handle_retrieval_end(
        self,
        event_id: str,
        payload: dict[str, Any],
    ) -> None:
        """Process retrieval completion event."""
        nodes = payload.get(EventPayload.NODES, [])

        # Extract retrieved text
        retrieved_texts = []
        for node in nodes:
            if hasattr(node, "text"):
                retrieved_texts.append(node.text)
            elif hasattr(node, "get_content"):
                retrieved_texts.append(node.get_content())

        if not retrieved_texts:
            return

        # Store for potential later use
        self._retrieval_context[event_id] = retrieved_texts

        # Send to Observer for tracking
        try:
            query = self._event_prompts.get(event_id, "")
            self._http.post(
                "/v1/guardian/observer/context",
                json={
                    "query": query,
                    "retrieved_documents": [
                        {"content": text, "index": i}
                        for i, text in enumerate(retrieved_texts)
                    ],
                    "source": "llamaindex",
                    "tags": self.tags,
                    "metadata": self.metadata,
                },
            )
        except Exception as e:
            if self.fail_silently:
                logger.warning("Failed to track retrieval context: %s", e)
            else:
                raise RotascaleError(f"Failed to track retrieval context: {e}") from e

    def _scan_content(
        self,
        prompt: str,
        response: str,
        latency_ms: float | None = None,
        token_counts: dict[str, int] | None = None,
    ) -> None:
        """Send content to Guardian for safety scanning."""
        try:
            scan_payload = {
                "prompt": prompt,
                "response": response,
                "source": "llamaindex",
                "tags": self.tags,
                "metadata": {
                    **self.metadata,
                    "latency_ms": latency_ms,
                    **(token_counts or {}),
                },
            }

            self._http.post(
                f"/v1/guardian/monitors/{self.monitor_id}/detections",
                json=scan_payload,
            )
        except Exception as e:
            if self.fail_silently:
                logger.warning("Failed to scan LLM response: %s", e)
            else:
                raise RotascaleError(f"Failed to scan LLM response: {e}") from e

    def start_trace(self, trace_id: str | None = None) -> None:
        """Start a new trace."""
        pass

    def end_trace(
        self,
        trace_id: str | None = None,
        trace_map: dict[str, list[str]] | None = None,
    ) -> None:
        """End current trace."""
        # Clean up any remaining state
        self._event_starts.clear()
        self._event_prompts.clear()
        self._retrieval_context.clear()

    def close(self) -> None:
        """Clean up resources."""
        self._http.close()

    def __enter__(self) -> "RotascaleCallbackHandler":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
