"""OpenAI SDK wrapper with Rotascale Guardian integration.

This module provides wrapped OpenAI clients that automatically scan
responses with Rotascale Guardian for safety and compliance.

Example usage::

    from rotascale.integrations.openai import RotascaleOpenAI

    client = RotascaleOpenAI(
        api_key="sk-...",  # OpenAI key
        rotascale_api_key="rsk_live_...",
        block_unsafe=True,  # Block responses that fail Guardian scan
    )

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello!"}]
    )
    # response._rotascale_scan contains scan results

Async usage::

    from rotascale.integrations.openai import AsyncRotascaleOpenAI

    client = AsyncRotascaleOpenAI(
        api_key="sk-...",
        rotascale_api_key="rsk_live_...",
        block_unsafe=True,
    )

    response = await client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello!"}]
    )
    # response._rotascale_scan contains scan results
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Iterator, AsyncIterator

try:
    from openai import OpenAI, AsyncOpenAI
    from openai.types.chat import ChatCompletion, ChatCompletionChunk
    from openai._streaming import Stream, AsyncStream
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False
    OpenAI = object  # type: ignore[misc, assignment]
    AsyncOpenAI = object  # type: ignore[misc, assignment]

from rotascale._http import AsyncHTTPClient, SyncHTTPClient
from rotascale.exceptions import RotascaleError

if TYPE_CHECKING:
    from openai import OpenAI as OpenAIType, AsyncOpenAI as AsyncOpenAIType
    from openai.types.chat import ChatCompletion as ChatCompletionType


_DEFAULT_ROTASCALE_BASE_URL = "http://localhost:8000"


class RotascaleUnsafeResponseError(RotascaleError):
    """Raised when a response fails Guardian safety scan and block_unsafe is True."""

    def __init__(self, message: str, scan_result: "GuardianScanResult") -> None:
        self.scan_result = scan_result
        super().__init__(message)


@dataclass
class GuardianScanResult:
    """Result of a Guardian safety scan on an LLM response."""

    safe: bool
    """Whether the response passed all safety checks."""

    risk_score: float
    """Risk score from 0.0 (safe) to 1.0 (high risk)."""

    categories: dict[str, float] = field(default_factory=dict)
    """Risk scores by category (e.g., toxicity, pii, jailbreak)."""

    flags: list[str] = field(default_factory=list)
    """List of triggered safety flags."""

    scan_id: str | None = None
    """Unique identifier for this scan."""

    latency_ms: float | None = None
    """Time taken for the scan in milliseconds."""

    metadata: dict[str, Any] = field(default_factory=dict)
    """Additional scan metadata."""

    @classmethod
    def from_api_response(cls, data: dict[str, Any]) -> "GuardianScanResult":
        """Create a GuardianScanResult from an API response."""
        return cls(
            safe=data.get("safe", True),
            risk_score=data.get("risk_score", 0.0),
            categories=data.get("categories", {}),
            flags=data.get("flags", []),
            scan_id=data.get("scan_id"),
            latency_ms=data.get("latency_ms"),
            metadata=data.get("metadata", {}),
        )


def _ensure_openai_installed() -> None:
    """Raise an error if the openai package is not installed."""
    if not HAS_OPENAI:
        raise ImportError(
            "The 'openai' package is required to use RotascaleOpenAI. "
            "Install it with: pip install openai"
        )


def _extract_response_content(response: Any) -> str:
    """Extract the text content from an OpenAI ChatCompletion response."""
    if hasattr(response, "choices") and response.choices:
        choice = response.choices[0]
        if hasattr(choice, "message") and choice.message:
            return choice.message.content or ""
    return ""


def _extract_messages_content(messages: list[dict[str, Any]]) -> str:
    """Extract the user message content for context."""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
            # Handle content blocks (for vision, etc.)
            if isinstance(content, list):
                text_parts = [
                    p.get("text", "") for p in content
                    if isinstance(p, dict) and p.get("type") == "text"
                ]
                return " ".join(text_parts)
    return ""


class WrappedChatCompletions:
    """Wrapped chat.completions namespace with Guardian scanning."""

    def __init__(
        self,
        original_completions: Any,
        http: SyncHTTPClient,
        monitor_id: str | None,
        block_unsafe: bool,
        risk_threshold: float,
    ) -> None:
        self._original = original_completions
        self._http = http
        self._monitor_id = monitor_id
        self._block_unsafe = block_unsafe
        self._risk_threshold = risk_threshold

    def create(self, **kwargs: Any) -> Any:
        """Create a chat completion and scan it with Guardian.

        All arguments are passed through to the OpenAI API.
        The response will have a `_rotascale_scan` attribute with scan results.
        """
        # Check for streaming - we handle it differently
        if kwargs.get("stream", False):
            return self._create_streaming(**kwargs)

        # Get the original response
        response = self._original.create(**kwargs)

        # Scan the response
        scan_result = self._scan_response(
            response_content=_extract_response_content(response),
            prompt_content=_extract_messages_content(kwargs.get("messages", [])),
            model=kwargs.get("model", "unknown"),
        )

        # Attach scan result to response
        object.__setattr__(response, "_rotascale_scan", scan_result)

        # Block if unsafe and blocking is enabled
        if self._block_unsafe and not scan_result.safe:
            raise RotascaleUnsafeResponseError(
                f"Response blocked by Guardian: risk_score={scan_result.risk_score}, "
                f"flags={scan_result.flags}",
                scan_result=scan_result,
            )

        return response

    def _create_streaming(self, **kwargs: Any) -> "RotascaleStream":
        """Handle streaming responses with post-completion scanning."""
        stream = self._original.create(**kwargs)
        return RotascaleStream(
            stream=stream,
            http=self._http,
            monitor_id=self._monitor_id,
            block_unsafe=self._block_unsafe,
            risk_threshold=self._risk_threshold,
            prompt_content=_extract_messages_content(kwargs.get("messages", [])),
            model=kwargs.get("model", "unknown"),
        )

    def _scan_response(
        self,
        response_content: str,
        prompt_content: str,
        model: str,
    ) -> GuardianScanResult:
        """Send a response to Guardian for scanning."""
        try:
            endpoint = "/v1/guardian/scan"
            payload = {
                "content": response_content,
                "prompt": prompt_content,
                "model": model,
                "source": "openai_integration",
            }
            if self._monitor_id:
                payload["monitor_id"] = self._monitor_id

            result = self._http.post(endpoint, json=payload)
            return GuardianScanResult.from_api_response(result)
        except Exception as e:
            # On scan failure, return a default "safe" result but log the error
            return GuardianScanResult(
                safe=True,
                risk_score=0.0,
                metadata={"scan_error": str(e)},
            )

    def __getattr__(self, name: str) -> Any:
        """Forward all other attributes to the original completions object."""
        return getattr(self._original, name)


class RotascaleStream:
    """Wrapper around OpenAI Stream that scans complete response."""

    def __init__(
        self,
        stream: Any,
        http: SyncHTTPClient,
        monitor_id: str | None,
        block_unsafe: bool,
        risk_threshold: float,
        prompt_content: str,
        model: str,
    ) -> None:
        self._stream = stream
        self._http = http
        self._monitor_id = monitor_id
        self._block_unsafe = block_unsafe
        self._risk_threshold = risk_threshold
        self._prompt_content = prompt_content
        self._model = model
        self._collected_content: list[str] = []
        self._scan_result: GuardianScanResult | None = None

    def __iter__(self) -> Iterator[Any]:
        return self

    def __next__(self) -> Any:
        try:
            chunk = next(self._stream)
            # Collect content from delta
            if hasattr(chunk, "choices") and chunk.choices:
                delta = chunk.choices[0].delta
                if hasattr(delta, "content") and delta.content:
                    self._collected_content.append(delta.content)
            return chunk
        except StopIteration:
            # Stream complete - scan the full response
            self._perform_scan()
            raise

    def _perform_scan(self) -> None:
        """Scan the complete streamed response."""
        full_content = "".join(self._collected_content)
        try:
            endpoint = "/v1/guardian/scan"
            payload = {
                "content": full_content,
                "prompt": self._prompt_content,
                "model": self._model,
                "source": "openai_integration_stream",
            }
            if self._monitor_id:
                payload["monitor_id"] = self._monitor_id

            result = self._http.post(endpoint, json=payload)
            self._scan_result = GuardianScanResult.from_api_response(result)
        except Exception as e:
            self._scan_result = GuardianScanResult(
                safe=True,
                risk_score=0.0,
                metadata={"scan_error": str(e)},
            )

        # Note: For streaming, we can't block mid-stream, but we record the result
        # Users should check get_scan_result() after iteration

    def get_scan_result(self) -> GuardianScanResult | None:
        """Get the scan result after streaming is complete."""
        return self._scan_result

    def __enter__(self) -> "RotascaleStream":
        return self

    def __exit__(self, *args: Any) -> None:
        self._stream.close()

    def close(self) -> None:
        """Close the underlying stream."""
        self._stream.close()


class WrappedChat:
    """Wrapped chat namespace."""

    def __init__(
        self,
        original_chat: Any,
        http: SyncHTTPClient,
        monitor_id: str | None,
        block_unsafe: bool,
        risk_threshold: float,
    ) -> None:
        self._original = original_chat
        self.completions = WrappedChatCompletions(
            original_chat.completions,
            http,
            monitor_id,
            block_unsafe,
            risk_threshold,
        )

    def __getattr__(self, name: str) -> Any:
        """Forward all other attributes to the original chat object."""
        return getattr(self._original, name)


class RotascaleOpenAI:
    """Wrapped OpenAI client with Rotascale Guardian integration.

    This client wraps the standard OpenAI client to automatically scan
    responses with Rotascale Guardian for safety and compliance.

    Args:
        api_key: OpenAI API key.
        rotascale_api_key: Rotascale API key for Guardian access.
        rotascale_base_url: Base URL for Rotascale API.
        monitor_id: Optional Guardian monitor ID for categorized scanning.
        block_unsafe: If True, raise an exception for unsafe responses.
        risk_threshold: Risk score threshold for blocking (0.0-1.0).
        **kwargs: Additional arguments passed to the OpenAI client.

    Example::

        from rotascale.integrations.openai import RotascaleOpenAI

        client = RotascaleOpenAI(
            api_key="sk-...",
            rotascale_api_key="rsk_live_...",
            block_unsafe=True,
        )

        response = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello!"}]
        )
        # response._rotascale_scan contains scan results
    """

    def __init__(
        self,
        api_key: str | None = None,
        rotascale_api_key: str | None = None,
        rotascale_base_url: str = _DEFAULT_ROTASCALE_BASE_URL,
        monitor_id: str | None = None,
        block_unsafe: bool = False,
        risk_threshold: float = 0.7,
        **kwargs: Any,
    ) -> None:
        _ensure_openai_installed()

        # Initialize OpenAI client
        from openai import OpenAI as _OpenAI
        self._openai = _OpenAI(api_key=api_key, **kwargs)

        # Initialize Rotascale HTTP client
        if rotascale_api_key is None:
            import os
            rotascale_api_key = os.environ.get("ROTASCALE_API_KEY", "")

        self._rotascale_http = SyncHTTPClient(
            base_url=rotascale_base_url,
            api_key=rotascale_api_key,
        )
        self._monitor_id = monitor_id
        self._block_unsafe = block_unsafe
        self._risk_threshold = risk_threshold

        # Wrap the chat namespace
        self.chat = WrappedChat(
            self._openai.chat,
            self._rotascale_http,
            self._monitor_id,
            self._block_unsafe,
            self._risk_threshold,
        )

    def __getattr__(self, name: str) -> Any:
        """Forward all other attributes to the original OpenAI client."""
        return getattr(self._openai, name)

    def close(self) -> None:
        """Close both the OpenAI and Rotascale HTTP clients."""
        self._openai.close()
        self._rotascale_http.close()

    def __enter__(self) -> "RotascaleOpenAI":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


# ── Async Implementation ──────────────────────────────────────────────────────


class AsyncWrappedChatCompletions:
    """Async wrapped chat.completions namespace with Guardian scanning."""

    def __init__(
        self,
        original_completions: Any,
        http: AsyncHTTPClient,
        monitor_id: str | None,
        block_unsafe: bool,
        risk_threshold: float,
    ) -> None:
        self._original = original_completions
        self._http = http
        self._monitor_id = monitor_id
        self._block_unsafe = block_unsafe
        self._risk_threshold = risk_threshold

    async def create(self, **kwargs: Any) -> Any:
        """Create a chat completion and scan it with Guardian.

        All arguments are passed through to the OpenAI API.
        The response will have a `_rotascale_scan` attribute with scan results.
        """
        # Check for streaming - we handle it differently
        if kwargs.get("stream", False):
            return await self._create_streaming(**kwargs)

        # Get the original response
        response = await self._original.create(**kwargs)

        # Scan the response
        scan_result = await self._scan_response(
            response_content=_extract_response_content(response),
            prompt_content=_extract_messages_content(kwargs.get("messages", [])),
            model=kwargs.get("model", "unknown"),
        )

        # Attach scan result to response
        object.__setattr__(response, "_rotascale_scan", scan_result)

        # Block if unsafe and blocking is enabled
        if self._block_unsafe and not scan_result.safe:
            raise RotascaleUnsafeResponseError(
                f"Response blocked by Guardian: risk_score={scan_result.risk_score}, "
                f"flags={scan_result.flags}",
                scan_result=scan_result,
            )

        return response

    async def _create_streaming(self, **kwargs: Any) -> "AsyncRotascaleStream":
        """Handle streaming responses with post-completion scanning."""
        stream = await self._original.create(**kwargs)
        return AsyncRotascaleStream(
            stream=stream,
            http=self._http,
            monitor_id=self._monitor_id,
            block_unsafe=self._block_unsafe,
            risk_threshold=self._risk_threshold,
            prompt_content=_extract_messages_content(kwargs.get("messages", [])),
            model=kwargs.get("model", "unknown"),
        )

    async def _scan_response(
        self,
        response_content: str,
        prompt_content: str,
        model: str,
    ) -> GuardianScanResult:
        """Send a response to Guardian for scanning."""
        try:
            endpoint = "/v1/guardian/scan"
            payload = {
                "content": response_content,
                "prompt": prompt_content,
                "model": model,
                "source": "openai_integration",
            }
            if self._monitor_id:
                payload["monitor_id"] = self._monitor_id

            result = await self._http.post(endpoint, json=payload)
            return GuardianScanResult.from_api_response(result)
        except Exception as e:
            # On scan failure, return a default "safe" result but log the error
            return GuardianScanResult(
                safe=True,
                risk_score=0.0,
                metadata={"scan_error": str(e)},
            )

    def __getattr__(self, name: str) -> Any:
        """Forward all other attributes to the original completions object."""
        return getattr(self._original, name)


class AsyncRotascaleStream:
    """Async wrapper around OpenAI AsyncStream that scans complete response."""

    def __init__(
        self,
        stream: Any,
        http: AsyncHTTPClient,
        monitor_id: str | None,
        block_unsafe: bool,
        risk_threshold: float,
        prompt_content: str,
        model: str,
    ) -> None:
        self._stream = stream
        self._http = http
        self._monitor_id = monitor_id
        self._block_unsafe = block_unsafe
        self._risk_threshold = risk_threshold
        self._prompt_content = prompt_content
        self._model = model
        self._collected_content: list[str] = []
        self._scan_result: GuardianScanResult | None = None

    def __aiter__(self) -> AsyncIterator[Any]:
        return self

    async def __anext__(self) -> Any:
        try:
            chunk = await self._stream.__anext__()
            # Collect content from delta
            if hasattr(chunk, "choices") and chunk.choices:
                delta = chunk.choices[0].delta
                if hasattr(delta, "content") and delta.content:
                    self._collected_content.append(delta.content)
            return chunk
        except StopAsyncIteration:
            # Stream complete - scan the full response
            await self._perform_scan()
            raise

    async def _perform_scan(self) -> None:
        """Scan the complete streamed response."""
        full_content = "".join(self._collected_content)
        try:
            endpoint = "/v1/guardian/scan"
            payload = {
                "content": full_content,
                "prompt": self._prompt_content,
                "model": self._model,
                "source": "openai_integration_stream",
            }
            if self._monitor_id:
                payload["monitor_id"] = self._monitor_id

            result = await self._http.post(endpoint, json=payload)
            self._scan_result = GuardianScanResult.from_api_response(result)
        except Exception as e:
            self._scan_result = GuardianScanResult(
                safe=True,
                risk_score=0.0,
                metadata={"scan_error": str(e)},
            )

    def get_scan_result(self) -> GuardianScanResult | None:
        """Get the scan result after streaming is complete."""
        return self._scan_result

    async def __aenter__(self) -> "AsyncRotascaleStream":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self._stream.close()

    async def close(self) -> None:
        """Close the underlying stream."""
        await self._stream.close()


class AsyncWrappedChat:
    """Async wrapped chat namespace."""

    def __init__(
        self,
        original_chat: Any,
        http: AsyncHTTPClient,
        monitor_id: str | None,
        block_unsafe: bool,
        risk_threshold: float,
    ) -> None:
        self._original = original_chat
        self.completions = AsyncWrappedChatCompletions(
            original_chat.completions,
            http,
            monitor_id,
            block_unsafe,
            risk_threshold,
        )

    def __getattr__(self, name: str) -> Any:
        """Forward all other attributes to the original chat object."""
        return getattr(self._original, name)


class AsyncRotascaleOpenAI:
    """Async wrapped OpenAI client with Rotascale Guardian integration.

    This client wraps the standard async OpenAI client to automatically scan
    responses with Rotascale Guardian for safety and compliance.

    Args:
        api_key: OpenAI API key.
        rotascale_api_key: Rotascale API key for Guardian access.
        rotascale_base_url: Base URL for Rotascale API.
        monitor_id: Optional Guardian monitor ID for categorized scanning.
        block_unsafe: If True, raise an exception for unsafe responses.
        risk_threshold: Risk score threshold for blocking (0.0-1.0).
        **kwargs: Additional arguments passed to the AsyncOpenAI client.

    Example::

        from rotascale.integrations.openai import AsyncRotascaleOpenAI

        async with AsyncRotascaleOpenAI(
            api_key="sk-...",
            rotascale_api_key="rsk_live_...",
            block_unsafe=True,
        ) as client:
            response = await client.chat.completions.create(
                model="gpt-4",
                messages=[{"role": "user", "content": "Hello!"}]
            )
            # response._rotascale_scan contains scan results
    """

    def __init__(
        self,
        api_key: str | None = None,
        rotascale_api_key: str | None = None,
        rotascale_base_url: str = _DEFAULT_ROTASCALE_BASE_URL,
        monitor_id: str | None = None,
        block_unsafe: bool = False,
        risk_threshold: float = 0.7,
        **kwargs: Any,
    ) -> None:
        _ensure_openai_installed()

        # Initialize AsyncOpenAI client
        from openai import AsyncOpenAI as _AsyncOpenAI
        self._openai = _AsyncOpenAI(api_key=api_key, **kwargs)

        # Initialize Rotascale HTTP client
        if rotascale_api_key is None:
            import os
            rotascale_api_key = os.environ.get("ROTASCALE_API_KEY", "")

        self._rotascale_http = AsyncHTTPClient(
            base_url=rotascale_base_url,
            api_key=rotascale_api_key,
        )
        self._monitor_id = monitor_id
        self._block_unsafe = block_unsafe
        self._risk_threshold = risk_threshold

        # Wrap the chat namespace
        self.chat = AsyncWrappedChat(
            self._openai.chat,
            self._rotascale_http,
            self._monitor_id,
            self._block_unsafe,
            self._risk_threshold,
        )

    def __getattr__(self, name: str) -> Any:
        """Forward all other attributes to the original AsyncOpenAI client."""
        return getattr(self._openai, name)

    async def close(self) -> None:
        """Close both the OpenAI and Rotascale HTTP clients."""
        await self._openai.close()
        await self._rotascale_http.close()

    async def __aenter__(self) -> "AsyncRotascaleOpenAI":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()


__all__ = [
    "RotascaleOpenAI",
    "AsyncRotascaleOpenAI",
    "GuardianScanResult",
    "RotascaleUnsafeResponseError",
    "RotascaleStream",
    "AsyncRotascaleStream",
]
