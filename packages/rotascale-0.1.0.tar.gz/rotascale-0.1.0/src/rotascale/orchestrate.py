"""Orchestrate sub-client - multi-agent workflows, topologies, rules."""

from __future__ import annotations

from typing import Any


class AsyncOrchestrateClient:
    def __init__(self, http: Any) -> None:
        self._http = http

    # ── Workflows ───────────────────────────────────────

    async def list_workflows(self) -> list[dict]:
        return await self._http.get("/v1/orchestrate/workflows")

    async def create_workflow(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/orchestrate/workflows", json=kwargs)

    async def get_workflow(self, workflow_id: str) -> dict:
        return await self._http.get(f"/v1/orchestrate/workflows/{workflow_id}")

    async def update_workflow(self, workflow_id: str, **kwargs: Any) -> dict:
        return await self._http.patch(f"/v1/orchestrate/workflows/{workflow_id}", json=kwargs)

    async def delete_workflow(self, workflow_id: str) -> None:
        await self._http.delete(f"/v1/orchestrate/workflows/{workflow_id}")

    async def execute_workflow(self, workflow_id: str, **kwargs: Any) -> dict:
        return await self._http.post(f"/v1/orchestrate/workflows/{workflow_id}/execute", json=kwargs)

    async def list_executions(self, workflow_id: str) -> list[dict]:
        return await self._http.get(f"/v1/orchestrate/workflows/{workflow_id}/executions")

    async def get_execution(self, workflow_id: str, execution_id: str) -> dict:
        return await self._http.get(f"/v1/orchestrate/workflows/{workflow_id}/executions/{execution_id}")

    async def plan_workflow(self, workflow_id: str, **kwargs: Any) -> dict:
        return await self._http.post(f"/v1/orchestrate/workflows/{workflow_id}/plan", json=kwargs)

    # ── Topologies ──────────────────────────────────────

    async def list_topologies(self) -> list[dict]:
        return await self._http.get("/v1/orchestrate/topologies")

    async def create_topology(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/orchestrate/topologies", json=kwargs)

    async def get_topology(self, topology_id: str) -> dict:
        return await self._http.get(f"/v1/orchestrate/topologies/{topology_id}")

    async def update_topology(self, topology_id: str, **kwargs: Any) -> dict:
        return await self._http.patch(f"/v1/orchestrate/topologies/{topology_id}", json=kwargs)

    async def delete_topology(self, topology_id: str) -> None:
        await self._http.delete(f"/v1/orchestrate/topologies/{topology_id}")

    async def list_nodes(self, topology_id: str) -> list[dict]:
        return await self._http.get(f"/v1/orchestrate/topologies/{topology_id}/nodes")

    async def add_node(self, topology_id: str, **kwargs: Any) -> dict:
        return await self._http.post(f"/v1/orchestrate/topologies/{topology_id}/nodes", json=kwargs)

    async def remove_node(self, topology_id: str, node_id: str) -> None:
        await self._http.delete(f"/v1/orchestrate/topologies/{topology_id}/nodes/{node_id}")

    async def collective_query(self, topology_id: str, **kwargs: Any) -> dict:
        return await self._http.post(f"/v1/orchestrate/topologies/{topology_id}/query", json=kwargs)

    async def get_topology_statistics(self, topology_id: str) -> dict:
        return await self._http.get(f"/v1/orchestrate/topologies/{topology_id}/statistics")

    # ── Rules ───────────────────────────────────────────

    async def list_rules(self, **kwargs: Any) -> list[dict]:
        return await self._http.get("/v1/orchestrate/rules", params=kwargs or None)

    async def get_rule(self, proposal_id: str) -> dict:
        return await self._http.get(f"/v1/orchestrate/rules/{proposal_id}")

    async def review_rule(self, proposal_id: str, **kwargs: Any) -> dict:
        return await self._http.post(f"/v1/orchestrate/rules/{proposal_id}/review", json=kwargs)

    async def delete_rule(self, proposal_id: str) -> None:
        await self._http.delete(f"/v1/orchestrate/rules/{proposal_id}")


class OrchestrateClient:
    def __init__(self, http: Any) -> None:
        self._http = http

    def list_workflows(self) -> list[dict]:
        return self._http.get("/v1/orchestrate/workflows")

    def create_workflow(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/orchestrate/workflows", json=kwargs)

    def get_workflow(self, workflow_id: str) -> dict:
        return self._http.get(f"/v1/orchestrate/workflows/{workflow_id}")

    def update_workflow(self, workflow_id: str, **kwargs: Any) -> dict:
        return self._http.patch(f"/v1/orchestrate/workflows/{workflow_id}", json=kwargs)

    def delete_workflow(self, workflow_id: str) -> None:
        self._http.delete(f"/v1/orchestrate/workflows/{workflow_id}")

    def execute_workflow(self, workflow_id: str, **kwargs: Any) -> dict:
        return self._http.post(f"/v1/orchestrate/workflows/{workflow_id}/execute", json=kwargs)

    def list_executions(self, workflow_id: str) -> list[dict]:
        return self._http.get(f"/v1/orchestrate/workflows/{workflow_id}/executions")

    def get_execution(self, workflow_id: str, execution_id: str) -> dict:
        return self._http.get(f"/v1/orchestrate/workflows/{workflow_id}/executions/{execution_id}")

    def plan_workflow(self, workflow_id: str, **kwargs: Any) -> dict:
        return self._http.post(f"/v1/orchestrate/workflows/{workflow_id}/plan", json=kwargs)

    def list_topologies(self) -> list[dict]:
        return self._http.get("/v1/orchestrate/topologies")

    def create_topology(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/orchestrate/topologies", json=kwargs)

    def get_topology(self, topology_id: str) -> dict:
        return self._http.get(f"/v1/orchestrate/topologies/{topology_id}")

    def update_topology(self, topology_id: str, **kwargs: Any) -> dict:
        return self._http.patch(f"/v1/orchestrate/topologies/{topology_id}", json=kwargs)

    def delete_topology(self, topology_id: str) -> None:
        self._http.delete(f"/v1/orchestrate/topologies/{topology_id}")

    def list_nodes(self, topology_id: str) -> list[dict]:
        return self._http.get(f"/v1/orchestrate/topologies/{topology_id}/nodes")

    def add_node(self, topology_id: str, **kwargs: Any) -> dict:
        return self._http.post(f"/v1/orchestrate/topologies/{topology_id}/nodes", json=kwargs)

    def remove_node(self, topology_id: str, node_id: str) -> None:
        self._http.delete(f"/v1/orchestrate/topologies/{topology_id}/nodes/{node_id}")

    def collective_query(self, topology_id: str, **kwargs: Any) -> dict:
        return self._http.post(f"/v1/orchestrate/topologies/{topology_id}/query", json=kwargs)

    def get_topology_statistics(self, topology_id: str) -> dict:
        return self._http.get(f"/v1/orchestrate/topologies/{topology_id}/statistics")

    def list_rules(self, **kwargs: Any) -> list[dict]:
        return self._http.get("/v1/orchestrate/rules", params=kwargs or None)

    def get_rule(self, proposal_id: str) -> dict:
        return self._http.get(f"/v1/orchestrate/rules/{proposal_id}")

    def review_rule(self, proposal_id: str, **kwargs: Any) -> dict:
        return self._http.post(f"/v1/orchestrate/rules/{proposal_id}/review", json=kwargs)

    def delete_rule(self, proposal_id: str) -> None:
        self._http.delete(f"/v1/orchestrate/rules/{proposal_id}")
