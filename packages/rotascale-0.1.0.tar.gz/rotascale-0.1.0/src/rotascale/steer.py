"""Steer sub-client - behavior control, vectors, configs, experiments, catalog."""

from __future__ import annotations

from typing import Any


class AsyncSteerClient:
    def __init__(self, http: Any) -> None:
        self._http = http

    # ── Vector Libraries ────────────────────────────────

    async def list_vectors(self) -> list[dict]:
        return await self._http.get("/v1/steer/vectors")

    async def create_vector_library(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/steer/vectors", json=kwargs)

    async def get_vector_library(self, library_id: str) -> dict:
        return await self._http.get(f"/v1/steer/vectors/{library_id}")

    async def update_vector_library(self, library_id: str, **kwargs: Any) -> dict:
        return await self._http.patch(f"/v1/steer/vectors/{library_id}", json=kwargs)

    async def delete_vector_library(self, library_id: str) -> None:
        await self._http.delete(f"/v1/steer/vectors/{library_id}")

    async def import_vectors(self, library_id: str, **kwargs: Any) -> dict:
        return await self._http.post(f"/v1/steer/vectors/{library_id}/import", json=kwargs)

    # ── Behavior Configs ────────────────────────────────

    async def list_configs(self) -> list[dict]:
        return await self._http.get("/v1/steer/configs")

    async def create_config(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/steer/configs", json=kwargs)

    async def get_config(self, config_id: str) -> dict:
        return await self._http.get(f"/v1/steer/configs/{config_id}")

    async def update_config(self, config_id: str, **kwargs: Any) -> dict:
        return await self._http.patch(f"/v1/steer/configs/{config_id}", json=kwargs)

    async def delete_config(self, config_id: str) -> None:
        await self._http.delete(f"/v1/steer/configs/{config_id}")

    # ── Experiments ─────────────────────────────────────

    async def list_experiments(self) -> list[dict]:
        return await self._http.get("/v1/steer/experiments")

    async def create_experiment(self, **kwargs: Any) -> dict:
        return await self._http.post("/v1/steer/experiments", json=kwargs)

    async def get_experiment(self, experiment_id: str) -> dict:
        return await self._http.get(f"/v1/steer/experiments/{experiment_id}")

    async def delete_experiment(self, experiment_id: str) -> None:
        await self._http.delete(f"/v1/steer/experiments/{experiment_id}")

    async def update_experiment_status(self, experiment_id: str, **kwargs: Any) -> dict:
        return await self._http.post(f"/v1/steer/experiments/{experiment_id}/status", json=kwargs)

    # ── Catalog ─────────────────────────────────────────

    async def list_catalog(self) -> list[dict]:
        return await self._http.get("/v1/steer/catalog")

    async def list_categories(self) -> list[str]:
        return await self._http.get("/v1/steer/catalog/categories")

    async def get_behavior(self, behavior_name: str) -> dict:
        return await self._http.get(f"/v1/steer/catalog/{behavior_name}")


class SteerClient:
    def __init__(self, http: Any) -> None:
        self._http = http

    def list_vectors(self) -> list[dict]:
        return self._http.get("/v1/steer/vectors")

    def create_vector_library(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/steer/vectors", json=kwargs)

    def get_vector_library(self, library_id: str) -> dict:
        return self._http.get(f"/v1/steer/vectors/{library_id}")

    def update_vector_library(self, library_id: str, **kwargs: Any) -> dict:
        return self._http.patch(f"/v1/steer/vectors/{library_id}", json=kwargs)

    def delete_vector_library(self, library_id: str) -> None:
        self._http.delete(f"/v1/steer/vectors/{library_id}")

    def import_vectors(self, library_id: str, **kwargs: Any) -> dict:
        return self._http.post(f"/v1/steer/vectors/{library_id}/import", json=kwargs)

    def list_configs(self) -> list[dict]:
        return self._http.get("/v1/steer/configs")

    def create_config(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/steer/configs", json=kwargs)

    def get_config(self, config_id: str) -> dict:
        return self._http.get(f"/v1/steer/configs/{config_id}")

    def update_config(self, config_id: str, **kwargs: Any) -> dict:
        return self._http.patch(f"/v1/steer/configs/{config_id}", json=kwargs)

    def delete_config(self, config_id: str) -> None:
        self._http.delete(f"/v1/steer/configs/{config_id}")

    def list_experiments(self) -> list[dict]:
        return self._http.get("/v1/steer/experiments")

    def create_experiment(self, **kwargs: Any) -> dict:
        return self._http.post("/v1/steer/experiments", json=kwargs)

    def get_experiment(self, experiment_id: str) -> dict:
        return self._http.get(f"/v1/steer/experiments/{experiment_id}")

    def delete_experiment(self, experiment_id: str) -> None:
        self._http.delete(f"/v1/steer/experiments/{experiment_id}")

    def update_experiment_status(self, experiment_id: str, **kwargs: Any) -> dict:
        return self._http.post(f"/v1/steer/experiments/{experiment_id}/status", json=kwargs)

    def list_catalog(self) -> list[dict]:
        return self._http.get("/v1/steer/catalog")

    def list_categories(self) -> list[str]:
        return self._http.get("/v1/steer/catalog/categories")

    def get_behavior(self, behavior_name: str) -> dict:
        return self._http.get(f"/v1/steer/catalog/{behavior_name}")
