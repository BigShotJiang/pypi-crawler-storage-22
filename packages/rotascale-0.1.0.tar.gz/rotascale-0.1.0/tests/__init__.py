"""Rotascale SDK test suite."""
