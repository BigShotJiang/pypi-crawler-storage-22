"""Shared fixtures for Rotascale SDK tests."""

from __future__ import annotations

import pytest
import respx

from rotascale.client import AsyncRotascaleClient, RotascaleClient

BASE_URL = "http://localhost:8000"
API_KEY = "rsk_test_abc123"


@pytest.fixture
def mock_api() -> respx.MockRouter:
    """Create a respx mock router for sync tests."""
    with respx.mock(base_url=BASE_URL, assert_all_called=False) as router:
        yield router


@pytest.fixture
def async_mock_api() -> respx.MockRouter:
    """Create a respx mock router for async tests."""
    with respx.mock(base_url=BASE_URL, assert_all_called=False) as router:
        yield router


@pytest.fixture
def sync_client(mock_api: respx.MockRouter) -> RotascaleClient:
    """Create a sync client for testing."""
    return RotascaleClient(api_key=API_KEY, base_url=BASE_URL)


@pytest.fixture
async def async_client(async_mock_api: respx.MockRouter) -> AsyncRotascaleClient:
    """Create an async client for testing."""
    client = AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL)
    yield client
    await client.close()
