"""Tests for main Rotascale client."""

from __future__ import annotations

import httpx
import pytest
import respx

from rotascale.client import AsyncRotascaleClient, RotascaleClient
from rotascale.guardian import AsyncGuardianClient, GuardianClient
from rotascale.steer import AsyncSteerClient, SteerClient

BASE_URL = "http://localhost:8000"
API_KEY = "rsk_test_abc123"


class TestRotascaleClient:
    """Tests for sync RotascaleClient."""

    def test_client_instantiation(self) -> None:
        """Test client can be instantiated with required args."""
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        assert client._http is not None
        client.close()

    def test_client_has_guardian(self) -> None:
        """Test client has guardian sub-client."""
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        assert hasattr(client, "guardian")
        assert isinstance(client.guardian, GuardianClient)
        client.close()

    def test_client_has_steer(self) -> None:
        """Test client has steer sub-client."""
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        assert hasattr(client, "steer")
        assert isinstance(client.steer, SteerClient)
        client.close()

    def test_client_context_manager(self, mock_api: respx.MockRouter) -> None:
        """Test client works as context manager."""
        mock_api.get("/v1/guardian/monitors").mock(
            return_value=httpx.Response(200, json=[])
        )
        with RotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = client.guardian.list_monitors()
            assert result == []

    def test_client_default_base_url(self) -> None:
        """Test client uses default base URL."""
        client = RotascaleClient(api_key=API_KEY)
        # Default is http://localhost:8000
        assert "localhost:8000" in str(client._http._client.base_url)
        client.close()

    def test_client_custom_timeout(self) -> None:
        """Test client accepts custom timeout."""
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL, timeout=60.0)
        assert client._http._client.timeout.connect == 60.0
        client.close()


class TestAsyncRotascaleClient:
    """Tests for async AsyncRotascaleClient."""

    @pytest.mark.asyncio
    async def test_client_instantiation(self) -> None:
        """Test async client can be instantiated."""
        client = AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        assert client._http is not None
        await client.close()

    @pytest.mark.asyncio
    async def test_client_has_guardian(self) -> None:
        """Test async client has guardian sub-client."""
        client = AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        assert hasattr(client, "guardian")
        assert isinstance(client.guardian, AsyncGuardianClient)
        await client.close()

    @pytest.mark.asyncio
    async def test_client_has_steer(self) -> None:
        """Test async client has steer sub-client."""
        client = AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        assert hasattr(client, "steer")
        assert isinstance(client.steer, AsyncSteerClient)
        await client.close()

    @pytest.mark.asyncio
    async def test_client_async_context_manager(
        self, async_mock_api: respx.MockRouter
    ) -> None:
        """Test async client works as async context manager."""
        async_mock_api.get("/v1/guardian/monitors").mock(
            return_value=httpx.Response(200, json=[])
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.guardian.list_monitors()
            assert result == []

    @pytest.mark.asyncio
    async def test_client_has_all_sub_clients(self) -> None:
        """Test async client has all expected sub-clients."""
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            assert hasattr(client, "guardian")
            assert hasattr(client, "steer")
            assert hasattr(client, "eval")
            assert hasattr(client, "orchestrate")
            assert hasattr(client, "agentops")
            assert hasattr(client, "accelerate")
            assert hasattr(client, "context_engine")
