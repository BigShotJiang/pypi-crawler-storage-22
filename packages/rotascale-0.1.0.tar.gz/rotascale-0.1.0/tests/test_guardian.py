"""Tests for Guardian client."""

from __future__ import annotations

import httpx
import pytest
import respx

from rotascale.client import AsyncRotascaleClient, RotascaleClient
from rotascale.exceptions import RotascaleNotFoundError, RotascaleValidationError

BASE_URL = "http://localhost:8000"
API_KEY = "rsk_test_abc123"


class TestGuardianClientSync:
    """Tests for sync GuardianClient."""

    def test_list_monitors(self, mock_api: respx.MockRouter) -> None:
        """Test listing monitors."""
        monitors = [
            {"id": "mon_1", "name": "Monitor 1", "status": "active"},
            {"id": "mon_2", "name": "Monitor 2", "status": "paused"},
        ]
        mock_api.get("/v1/guardian/monitors").mock(
            return_value=httpx.Response(200, json=monitors)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.guardian.list_monitors()
        assert result == monitors
        assert len(result) == 2
        client.close()

    def test_create_monitor(self, mock_api: respx.MockRouter) -> None:
        """Test creating a monitor."""
        created = {"id": "mon_new", "name": "New Monitor", "status": "active"}
        mock_api.post("/v1/guardian/monitors").mock(
            return_value=httpx.Response(201, json=created)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.guardian.create_monitor(name="New Monitor")
        assert result["id"] == "mon_new"
        client.close()

    def test_get_monitor(self, mock_api: respx.MockRouter) -> None:
        """Test getting a single monitor."""
        monitor = {"id": "mon_1", "name": "Monitor 1", "status": "active"}
        mock_api.get("/v1/guardian/monitors/mon_1").mock(
            return_value=httpx.Response(200, json=monitor)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.guardian.get_monitor("mon_1")
        assert result["id"] == "mon_1"
        client.close()

    def test_get_monitor_not_found(self, mock_api: respx.MockRouter) -> None:
        """Test getting a non-existent monitor."""
        mock_api.get("/v1/guardian/monitors/invalid").mock(
            return_value=httpx.Response(404, json={"detail": "Monitor not found"})
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        with pytest.raises(RotascaleNotFoundError):
            client.guardian.get_monitor("invalid")
        client.close()

    def test_update_monitor(self, mock_api: respx.MockRouter) -> None:
        """Test updating a monitor."""
        updated = {"id": "mon_1", "name": "Updated", "status": "active"}
        mock_api.patch("/v1/guardian/monitors/mon_1").mock(
            return_value=httpx.Response(200, json=updated)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.guardian.update_monitor("mon_1", name="Updated")
        assert result["name"] == "Updated"
        client.close()

    def test_delete_monitor(self, mock_api: respx.MockRouter) -> None:
        """Test deleting a monitor."""
        mock_api.delete("/v1/guardian/monitors/mon_1").mock(
            return_value=httpx.Response(204)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.guardian.delete_monitor("mon_1")
        assert result is None
        client.close()

    def test_run_detection(self, mock_api: respx.MockRouter) -> None:
        """Test running a detection."""
        detection = {"id": "det_1", "monitor_id": "mon_1", "score": 0.95}
        mock_api.post("/v1/guardian/monitors/mon_1/detections").mock(
            return_value=httpx.Response(200, json=detection)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.guardian.run_detection("mon_1", input="test data")
        assert result["score"] == 0.95
        client.close()

    def test_list_detections(self, mock_api: respx.MockRouter) -> None:
        """Test listing detections for a monitor."""
        detections = [{"id": "det_1"}, {"id": "det_2"}]
        mock_api.get("/v1/guardian/monitors/mon_1/detections").mock(
            return_value=httpx.Response(200, json=detections)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.guardian.list_detections("mon_1")
        assert len(result) == 2
        client.close()

    def test_list_alerts(self, mock_api: respx.MockRouter) -> None:
        """Test listing alerts."""
        alerts = [{"id": "alert_1", "severity": "high"}]
        mock_api.get("/v1/guardian/alerts").mock(
            return_value=httpx.Response(200, json=alerts)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.guardian.list_alerts()
        assert len(result) == 1
        assert result[0]["severity"] == "high"
        client.close()

    def test_create_monitor_validation_error(
        self, mock_api: respx.MockRouter
    ) -> None:
        """Test validation error when creating monitor."""
        mock_api.post("/v1/guardian/monitors").mock(
            return_value=httpx.Response(
                422, json={"detail": [{"loc": ["body", "name"], "msg": "required"}]}
            )
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        with pytest.raises(RotascaleValidationError):
            client.guardian.create_monitor()
        client.close()


class TestGuardianClientAsync:
    """Tests for async AsyncGuardianClient."""

    @pytest.mark.asyncio
    async def test_list_monitors(self, async_mock_api: respx.MockRouter) -> None:
        """Test async listing monitors."""
        monitors = [{"id": "mon_1", "name": "Monitor 1"}]
        async_mock_api.get("/v1/guardian/monitors").mock(
            return_value=httpx.Response(200, json=monitors)
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.guardian.list_monitors()
            assert result == monitors

    @pytest.mark.asyncio
    async def test_create_monitor(self, async_mock_api: respx.MockRouter) -> None:
        """Test async creating a monitor."""
        created = {"id": "mon_new", "name": "New Monitor"}
        async_mock_api.post("/v1/guardian/monitors").mock(
            return_value=httpx.Response(201, json=created)
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.guardian.create_monitor(name="New Monitor")
            assert result["id"] == "mon_new"

    @pytest.mark.asyncio
    async def test_get_monitor_not_found(
        self, async_mock_api: respx.MockRouter
    ) -> None:
        """Test async getting a non-existent monitor."""
        async_mock_api.get("/v1/guardian/monitors/invalid").mock(
            return_value=httpx.Response(404, json={"detail": "Not found"})
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            with pytest.raises(RotascaleNotFoundError):
                await client.guardian.get_monitor("invalid")

    @pytest.mark.asyncio
    async def test_delete_monitor(self, async_mock_api: respx.MockRouter) -> None:
        """Test async deleting a monitor."""
        async_mock_api.delete("/v1/guardian/monitors/mon_1").mock(
            return_value=httpx.Response(204)
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.guardian.delete_monitor("mon_1")
            assert result is None

    @pytest.mark.asyncio
    async def test_set_baseline(self, async_mock_api: respx.MockRouter) -> None:
        """Test async setting baseline."""
        baseline = {"monitor_id": "mon_1", "samples": 100}
        async_mock_api.post("/v1/guardian/monitors/mon_1/baseline").mock(
            return_value=httpx.Response(200, json=baseline)
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.guardian.set_baseline("mon_1", samples=100)
            assert result["samples"] == 100

    @pytest.mark.asyncio
    async def test_get_divergence(self, async_mock_api: respx.MockRouter) -> None:
        """Test async getting divergence."""
        divergence = {"monitor_id": "mon_1", "score": 0.15}
        async_mock_api.get("/v1/guardian/monitors/mon_1/observer/divergence").mock(
            return_value=httpx.Response(200, json=divergence)
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.guardian.get_divergence("mon_1")
            assert result["score"] == 0.15
