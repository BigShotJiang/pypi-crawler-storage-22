"""Tests for HTTP transport layer."""

from __future__ import annotations

import httpx
import pytest
import respx

from rotascale._http import AsyncHTTPClient, SyncHTTPClient
from rotascale.exceptions import (
    RotascaleAPIError,
    RotascaleAuthError,
    RotascaleNotFoundError,
    RotascaleRateLimitError,
    RotascaleValidationError,
)

BASE_URL = "http://localhost:8000"
API_KEY = "rsk_test_abc123"


class TestSyncHTTPClient:
    """Tests for SyncHTTPClient."""

    def test_get_success(self, mock_api: respx.MockRouter) -> None:
        """Test successful GET request."""
        mock_api.get("/v1/test").mock(
            return_value=httpx.Response(200, json={"data": "value"})
        )
        client = SyncHTTPClient(BASE_URL, API_KEY)
        result = client.get("/v1/test")
        assert result == {"data": "value"}
        client.close()

    def test_post_success(self, mock_api: respx.MockRouter) -> None:
        """Test successful POST request."""
        mock_api.post("/v1/test").mock(
            return_value=httpx.Response(201, json={"id": "123"})
        )
        client = SyncHTTPClient(BASE_URL, API_KEY)
        result = client.post("/v1/test", json={"name": "test"})
        assert result == {"id": "123"}
        client.close()

    def test_delete_204_returns_none(self, mock_api: respx.MockRouter) -> None:
        """Test DELETE returning 204 No Content."""
        mock_api.delete("/v1/test/123").mock(
            return_value=httpx.Response(204)
        )
        client = SyncHTTPClient(BASE_URL, API_KEY)
        result = client.delete("/v1/test/123")
        assert result is None
        client.close()

    def test_401_raises_auth_error(self, mock_api: respx.MockRouter) -> None:
        """Test 401 raises RotascaleAuthError."""
        mock_api.get("/v1/test").mock(
            return_value=httpx.Response(401, json={"detail": "Invalid token"})
        )
        client = SyncHTTPClient(BASE_URL, API_KEY)
        with pytest.raises(RotascaleAuthError) as exc_info:
            client.get("/v1/test")
        assert exc_info.value.status_code == 401
        assert exc_info.value.detail == "Invalid token"
        client.close()

    def test_403_raises_auth_error(self, mock_api: respx.MockRouter) -> None:
        """Test 403 raises RotascaleAuthError."""
        mock_api.get("/v1/test").mock(
            return_value=httpx.Response(403, json={"detail": "Forbidden"})
        )
        client = SyncHTTPClient(BASE_URL, API_KEY)
        with pytest.raises(RotascaleAuthError) as exc_info:
            client.get("/v1/test")
        assert exc_info.value.status_code == 403
        client.close()

    def test_404_raises_not_found_error(self, mock_api: respx.MockRouter) -> None:
        """Test 404 raises RotascaleNotFoundError."""
        mock_api.get("/v1/test/missing").mock(
            return_value=httpx.Response(404, json={"detail": "Not found"})
        )
        client = SyncHTTPClient(BASE_URL, API_KEY)
        with pytest.raises(RotascaleNotFoundError) as exc_info:
            client.get("/v1/test/missing")
        assert exc_info.value.status_code == 404
        client.close()

    def test_422_raises_validation_error(self, mock_api: respx.MockRouter) -> None:
        """Test 422 raises RotascaleValidationError."""
        mock_api.post("/v1/test").mock(
            return_value=httpx.Response(
                422,
                json={"detail": [{"loc": ["body", "name"], "msg": "required"}]},
            )
        )
        client = SyncHTTPClient(BASE_URL, API_KEY)
        with pytest.raises(RotascaleValidationError) as exc_info:
            client.post("/v1/test", json={})
        assert exc_info.value.status_code == 422
        client.close()

    def test_429_raises_rate_limit_error(self, mock_api: respx.MockRouter) -> None:
        """Test 429 raises RotascaleRateLimitError."""
        mock_api.get("/v1/test").mock(
            return_value=httpx.Response(429, json={"detail": "Rate limit exceeded"})
        )
        client = SyncHTTPClient(BASE_URL, API_KEY)
        with pytest.raises(RotascaleRateLimitError) as exc_info:
            client.get("/v1/test")
        assert exc_info.value.status_code == 429
        client.close()

    def test_500_raises_api_error(self, mock_api: respx.MockRouter) -> None:
        """Test 500 raises RotascaleAPIError."""
        mock_api.get("/v1/test").mock(
            return_value=httpx.Response(500, text="Internal Server Error")
        )
        client = SyncHTTPClient(BASE_URL, API_KEY)
        with pytest.raises(RotascaleAPIError) as exc_info:
            client.get("/v1/test")
        assert exc_info.value.status_code == 500
        client.close()


class TestAsyncHTTPClient:
    """Tests for AsyncHTTPClient."""

    @pytest.mark.asyncio
    async def test_get_success(self, async_mock_api: respx.MockRouter) -> None:
        """Test successful async GET request."""
        async_mock_api.get("/v1/test").mock(
            return_value=httpx.Response(200, json={"data": "value"})
        )
        client = AsyncHTTPClient(BASE_URL, API_KEY)
        result = await client.get("/v1/test")
        assert result == {"data": "value"}
        await client.close()

    @pytest.mark.asyncio
    async def test_post_success(self, async_mock_api: respx.MockRouter) -> None:
        """Test successful async POST request."""
        async_mock_api.post("/v1/test").mock(
            return_value=httpx.Response(201, json={"id": "123"})
        )
        client = AsyncHTTPClient(BASE_URL, API_KEY)
        result = await client.post("/v1/test", json={"name": "test"})
        assert result == {"id": "123"}
        await client.close()

    @pytest.mark.asyncio
    async def test_401_raises_auth_error(self, async_mock_api: respx.MockRouter) -> None:
        """Test 401 raises RotascaleAuthError in async client."""
        async_mock_api.get("/v1/test").mock(
            return_value=httpx.Response(401, json={"detail": "Unauthorized"})
        )
        client = AsyncHTTPClient(BASE_URL, API_KEY)
        with pytest.raises(RotascaleAuthError) as exc_info:
            await client.get("/v1/test")
        assert exc_info.value.status_code == 401
        await client.close()

    @pytest.mark.asyncio
    async def test_404_raises_not_found_error(
        self, async_mock_api: respx.MockRouter
    ) -> None:
        """Test 404 raises RotascaleNotFoundError in async client."""
        async_mock_api.get("/v1/test/missing").mock(
            return_value=httpx.Response(404, json={"detail": "Not found"})
        )
        client = AsyncHTTPClient(BASE_URL, API_KEY)
        with pytest.raises(RotascaleNotFoundError) as exc_info:
            await client.get("/v1/test/missing")
        assert exc_info.value.status_code == 404
        await client.close()

    @pytest.mark.asyncio
    async def test_patch_success(self, async_mock_api: respx.MockRouter) -> None:
        """Test successful async PATCH request."""
        async_mock_api.patch("/v1/test/123").mock(
            return_value=httpx.Response(200, json={"id": "123", "updated": True})
        )
        client = AsyncHTTPClient(BASE_URL, API_KEY)
        result = await client.patch("/v1/test/123", json={"name": "updated"})
        assert result == {"id": "123", "updated": True}
        await client.close()

    @pytest.mark.asyncio
    async def test_delete_204_returns_none(
        self, async_mock_api: respx.MockRouter
    ) -> None:
        """Test async DELETE returning 204 No Content."""
        async_mock_api.delete("/v1/test/123").mock(
            return_value=httpx.Response(204)
        )
        client = AsyncHTTPClient(BASE_URL, API_KEY)
        result = await client.delete("/v1/test/123")
        assert result is None
        await client.close()
