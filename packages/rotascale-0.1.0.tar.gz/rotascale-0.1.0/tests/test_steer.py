"""Tests for Steer client."""

from __future__ import annotations

import httpx
import pytest
import respx

from rotascale.client import AsyncRotascaleClient, RotascaleClient
from rotascale.exceptions import RotascaleNotFoundError, RotascaleValidationError

BASE_URL = "http://localhost:8000"
API_KEY = "rsk_test_abc123"


class TestSteerClientSync:
    """Tests for sync SteerClient."""

    def test_list_configs(self, mock_api: respx.MockRouter) -> None:
        """Test listing behavior configs."""
        configs = [
            {"id": "cfg_1", "name": "Safety", "enabled": True},
            {"id": "cfg_2", "name": "Helpfulness", "enabled": False},
        ]
        mock_api.get("/v1/steer/configs").mock(
            return_value=httpx.Response(200, json=configs)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.steer.list_configs()
        assert len(result) == 2
        assert result[0]["name"] == "Safety"
        client.close()

    def test_create_config(self, mock_api: respx.MockRouter) -> None:
        """Test creating a behavior config."""
        created = {"id": "cfg_new", "name": "New Config", "enabled": True}
        mock_api.post("/v1/steer/configs").mock(
            return_value=httpx.Response(201, json=created)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.steer.create_config(name="New Config", enabled=True)
        assert result["id"] == "cfg_new"
        client.close()

    def test_get_config(self, mock_api: respx.MockRouter) -> None:
        """Test getting a single config."""
        config = {"id": "cfg_1", "name": "Safety", "vectors": []}
        mock_api.get("/v1/steer/configs/cfg_1").mock(
            return_value=httpx.Response(200, json=config)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.steer.get_config("cfg_1")
        assert result["id"] == "cfg_1"
        client.close()

    def test_update_config(self, mock_api: respx.MockRouter) -> None:
        """Test updating a config."""
        updated = {"id": "cfg_1", "name": "Updated Safety", "enabled": True}
        mock_api.patch("/v1/steer/configs/cfg_1").mock(
            return_value=httpx.Response(200, json=updated)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.steer.update_config("cfg_1", name="Updated Safety")
        assert result["name"] == "Updated Safety"
        client.close()

    def test_delete_config(self, mock_api: respx.MockRouter) -> None:
        """Test deleting a config."""
        mock_api.delete("/v1/steer/configs/cfg_1").mock(
            return_value=httpx.Response(204)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.steer.delete_config("cfg_1")
        assert result is None
        client.close()

    def test_list_vectors(self, mock_api: respx.MockRouter) -> None:
        """Test listing vector libraries."""
        vectors = [{"id": "vec_1", "name": "Library 1", "count": 100}]
        mock_api.get("/v1/steer/vectors").mock(
            return_value=httpx.Response(200, json=vectors)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.steer.list_vectors()
        assert len(result) == 1
        assert result[0]["count"] == 100
        client.close()

    def test_create_vector_library(self, mock_api: respx.MockRouter) -> None:
        """Test creating a vector library."""
        created = {"id": "vec_new", "name": "New Library"}
        mock_api.post("/v1/steer/vectors").mock(
            return_value=httpx.Response(201, json=created)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.steer.create_vector_library(name="New Library")
        assert result["id"] == "vec_new"
        client.close()

    def test_delete_vector_library(self, mock_api: respx.MockRouter) -> None:
        """Test deleting a vector library."""
        mock_api.delete("/v1/steer/vectors/vec_1").mock(
            return_value=httpx.Response(204)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.steer.delete_vector_library("vec_1")
        assert result is None
        client.close()

    def test_list_experiments(self, mock_api: respx.MockRouter) -> None:
        """Test listing experiments."""
        experiments = [
            {"id": "exp_1", "name": "A/B Test", "status": "running"},
        ]
        mock_api.get("/v1/steer/experiments").mock(
            return_value=httpx.Response(200, json=experiments)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.steer.list_experiments()
        assert result[0]["status"] == "running"
        client.close()

    def test_list_catalog(self, mock_api: respx.MockRouter) -> None:
        """Test listing behavior catalog."""
        catalog = [{"name": "safety", "category": "core"}]
        mock_api.get("/v1/steer/catalog").mock(
            return_value=httpx.Response(200, json=catalog)
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        result = client.steer.list_catalog()
        assert result[0]["name"] == "safety"
        client.close()

    def test_get_config_not_found(self, mock_api: respx.MockRouter) -> None:
        """Test getting non-existent config."""
        mock_api.get("/v1/steer/configs/invalid").mock(
            return_value=httpx.Response(404, json={"detail": "Config not found"})
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        with pytest.raises(RotascaleNotFoundError):
            client.steer.get_config("invalid")
        client.close()

    def test_create_config_validation_error(
        self, mock_api: respx.MockRouter
    ) -> None:
        """Test validation error when creating config."""
        mock_api.post("/v1/steer/configs").mock(
            return_value=httpx.Response(
                422, json={"detail": [{"loc": ["body", "name"], "msg": "required"}]}
            )
        )
        client = RotascaleClient(api_key=API_KEY, base_url=BASE_URL)
        with pytest.raises(RotascaleValidationError):
            client.steer.create_config()
        client.close()


class TestSteerClientAsync:
    """Tests for async AsyncSteerClient."""

    @pytest.mark.asyncio
    async def test_list_configs(self, async_mock_api: respx.MockRouter) -> None:
        """Test async listing configs."""
        configs = [{"id": "cfg_1", "name": "Safety"}]
        async_mock_api.get("/v1/steer/configs").mock(
            return_value=httpx.Response(200, json=configs)
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.steer.list_configs()
            assert result == configs

    @pytest.mark.asyncio
    async def test_create_config(self, async_mock_api: respx.MockRouter) -> None:
        """Test async creating a config."""
        created = {"id": "cfg_new", "name": "New Config"}
        async_mock_api.post("/v1/steer/configs").mock(
            return_value=httpx.Response(201, json=created)
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.steer.create_config(name="New Config")
            assert result["id"] == "cfg_new"

    @pytest.mark.asyncio
    async def test_get_config_not_found(
        self, async_mock_api: respx.MockRouter
    ) -> None:
        """Test async getting non-existent config."""
        async_mock_api.get("/v1/steer/configs/invalid").mock(
            return_value=httpx.Response(404, json={"detail": "Not found"})
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            with pytest.raises(RotascaleNotFoundError):
                await client.steer.get_config("invalid")

    @pytest.mark.asyncio
    async def test_delete_config(self, async_mock_api: respx.MockRouter) -> None:
        """Test async deleting a config."""
        async_mock_api.delete("/v1/steer/configs/cfg_1").mock(
            return_value=httpx.Response(204)
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.steer.delete_config("cfg_1")
            assert result is None

    @pytest.mark.asyncio
    async def test_list_vectors(self, async_mock_api: respx.MockRouter) -> None:
        """Test async listing vector libraries."""
        vectors = [{"id": "vec_1", "name": "Library 1"}]
        async_mock_api.get("/v1/steer/vectors").mock(
            return_value=httpx.Response(200, json=vectors)
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.steer.list_vectors()
            assert len(result) == 1

    @pytest.mark.asyncio
    async def test_import_vectors(self, async_mock_api: respx.MockRouter) -> None:
        """Test async importing vectors."""
        result_data = {"library_id": "vec_1", "imported": 50}
        async_mock_api.post("/v1/steer/vectors/vec_1/import").mock(
            return_value=httpx.Response(200, json=result_data)
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.steer.import_vectors("vec_1", source="file.json")
            assert result["imported"] == 50

    @pytest.mark.asyncio
    async def test_list_categories(self, async_mock_api: respx.MockRouter) -> None:
        """Test async listing catalog categories."""
        categories = ["core", "safety", "style"]
        async_mock_api.get("/v1/steer/catalog/categories").mock(
            return_value=httpx.Response(200, json=categories)
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.steer.list_categories()
            assert "safety" in result

    @pytest.mark.asyncio
    async def test_get_behavior(self, async_mock_api: respx.MockRouter) -> None:
        """Test async getting behavior from catalog."""
        behavior = {"name": "safety", "description": "Safety behavior"}
        async_mock_api.get("/v1/steer/catalog/safety").mock(
            return_value=httpx.Response(200, json=behavior)
        )
        async with AsyncRotascaleClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = await client.steer.get_behavior("safety")
            assert result["name"] == "safety"
