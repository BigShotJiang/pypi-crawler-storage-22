"""Rotascale Python SDK - Trust Intelligence Platform."""

from rotascale.client import AsyncRotascaleClient, RotascaleClient
from rotascale.exceptions import (
    RotascaleAPIError,
    RotascaleAuthError,
    RotascaleError,
    RotascaleNotFoundError,
    RotascaleRateLimitError,
    RotascaleValidationError,
)

__all__ = [
    "AsyncRotascaleClient",
    "RotascaleClient",
    "RotascaleError",
    "RotascaleAPIError",
    "RotascaleAuthError",
    "RotascaleNotFoundError",
    "RotascaleRateLimitError",
    "RotascaleValidationError",
]

__version__ = "0.1.1"
