"""
Roura Agent - Local-first AI coding assistant.

© Roura.io
"""
__all__ = []
