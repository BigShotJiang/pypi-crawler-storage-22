"""
Routeflow Python SDK

Instrument your Flask application with Routeflow telemetry.

Basic usage:
    ```python
    from flask import Flask
    from routeflow_python import init_routeflow

    app = Flask(__name__)
    init_routeflow(app)
    ```

Local testing:
    ```python
    from flask import Flask
    from routeflow_python import init_routeflow

    app = Flask(__name__)
    init_routeflow(app, ingest_url="http://localhost:5002")
    ```

Environment variables:
    - ROUTEFLOW_INGEST_KEY: Routeflow ingest key (required)
    - ROUTEFLOW_INGEST_URL: Routeflow backend URL (optional, defaults to production)
    - ROUTEFLOW_ENV: Environment name (default: "development")
    - ROUTEFLOW_ENABLED: Enable/disable SDK (default: true)
    - ROUTEFLOW_SAMPLE_RATE: Sampling rate 0.0-1.0 (default: 1.0)
"""

from .flask import (
    init_routeflow,
    shutdown_routeflow,
    get_routeflow_stats,
)

from .fastapi import init_routeflow_fastapi

from .django import (
    init_routeflow_django,
    shutdown_routeflow_django,
    RouteflowDjangoMiddleware,
)

__version__ = "0.1.0"

__all__ = [
    # Flask
    "init_routeflow",
    "shutdown_routeflow",
    "get_routeflow_stats",
    # FastAPI
    "init_routeflow_fastapi",
    # Django
    "init_routeflow_django",
    "shutdown_routeflow_django",
    "RouteflowDjangoMiddleware",
    # Common
    "__version__",
]
