"""HTTP client and background batching worker."""

import atexit
import logging
import queue
import random
import threading
import time
from datetime import datetime, timezone
from typing import Optional

import requests

from .config import RouteflowConfig
from .models import Event, IngestPayload, validate_event

logger = logging.getLogger(__name__)


class RouteflowStats:
    """Internal metrics for monitoring SDK behavior."""

    def __init__(self):
        self.enqueued = 0
        self.sent = 0
        self.dropped_queue_full = 0
        self.dropped_sampled = 0
        self.dropped_validation = 0
        self.dropped_http_4xx = 0
        self.dropped_http_5xx = 0
        self.retries = 0
        self.last_error_at: Optional[datetime] = None
        self._lock = threading.Lock()

    def to_dict(self) -> dict:
        """Get stats as dictionary."""
        with self._lock:
            return {
                "enqueued": self.enqueued,
                "sent": self.sent,
                "dropped_queue_full": self.dropped_queue_full,
                "dropped_sampled": self.dropped_sampled,
                "dropped_validation": self.dropped_validation,
                "dropped_http_4xx": self.dropped_http_4xx,
                "dropped_http_5xx": self.dropped_http_5xx,
                "retries": self.retries,
                "last_error_at": self.last_error_at.isoformat() if self.last_error_at else None,
            }


class RouteflowClient:
    """Background worker for batching and sending events."""

    def __init__(self, config: RouteflowConfig):
        """Initialize the client."""
        self.config = config
        self.stats = RouteflowStats()
        self._queue: queue.Queue[Optional[Event]] = queue.Queue(maxsize=config.queue_maxsize)
        self._worker_thread: Optional[threading.Thread] = None
        self._running = False
        self._shutdown_event = threading.Event()

        if config.enabled:
            self._start()
            atexit.register(self.shutdown)

    def _start(self) -> None:
        """Start the background worker thread."""
        if self._running:
            return

        self._running = True
        self._worker_thread = threading.Thread(
            target=self._worker_loop,
            name="routeflow-worker",
            daemon=True
        )
        self._worker_thread.start()
        logger.info("Routeflow worker thread started")

    def enqueue(self, event: Event) -> bool:
        """
        Enqueue an event for sending.

        Args:
            event: The event to enqueue

        Returns:
            True if enqueued, False if dropped
        """
        if not self.config.enabled:
            return False

        # Sampling
        if self.config.sample_rate < 1.0:
            if random.random() > self.config.sample_rate:
                with self.stats._lock:
                    self.stats.dropped_sampled += 1
                return False

        # Validate
        try:
            validate_event(event)
        except ValueError as e:
            logger.warning(f"Event validation failed: {e}")
            with self.stats._lock:
                self.stats.dropped_validation += 1
            return False

        # Enqueue
        try:
            self._queue.put_nowait(event)
            with self.stats._lock:
                self.stats.enqueued += 1
            return True
        except queue.Full:
            with self.stats._lock:
                self.stats.dropped_queue_full += 1
            logger.warning("Routeflow queue full, dropping event")
            return False

    def _worker_loop(self) -> None:
        """Main worker loop - batch and send events."""
        batch: list[Event] = []
        last_flush = time.time()

        while self._running or not self._queue.empty():
            try:
                # Calculate timeout until next flush
                now = time.time()
                time_since_flush = (now - last_flush) * 1000  # ms
                timeout = max(0.1, (self.config.flush_interval_ms - time_since_flush) / 1000)

                # Get event from queue
                try:
                    event = self._queue.get(timeout=timeout)

                    # None is sentinel for shutdown
                    if event is None:
                        break

                    batch.append(event)
                except queue.Empty:
                    pass

                # Flush if batch is full or interval elapsed
                now = time.time()
                batch_full = len(batch) >= self.config.max_events_per_batch
                interval_elapsed = (now - last_flush) * 1000 >= self.config.flush_interval_ms

                if batch and (batch_full or interval_elapsed):
                    self._send_batch(batch)
                    batch = []
                    last_flush = now

            except Exception as e:
                logger.error(f"Error in Routeflow worker loop: {e}", exc_info=True)

        # Final flush
        if batch:
            self._send_batch(batch)

        logger.info("Routeflow worker thread stopped")

    def _send_batch(self, events: list[Event]) -> None:
        """
        Send a batch of events with retry logic.

        Args:
            events: Events to send
        """
        payload: IngestPayload = {
            "sent_at": datetime.now(timezone.utc).isoformat(),
            "events": events,
        }

        max_retries = 3
        backoff_ms = 100

        for attempt in range(max_retries):
            try:
                response = requests.post(
                    f"{self.config.ingest_url}/v1/ingest",
                    json=payload,
                    headers={
                        "Authorization": f"Bearer {self.config.ingest_key}",
                        "Content-Type": "application/json",
                    },
                    timeout=self.config.timeout_ms / 1000,
                )

                if response.status_code == 200:
                    with self.stats._lock:
                        self.stats.sent += len(events)
                    logger.debug(f"Sent batch of {len(events)} events")
                    return

                elif 400 <= response.status_code < 500:
                    # Client error - don't retry
                    logger.warning(
                        f"Routeflow ingestion failed with {response.status_code}: {response.text}"
                    )
                    with self.stats._lock:
                        self.stats.dropped_http_4xx += len(events)
                        self.stats.last_error_at = datetime.now(timezone.utc)
                    return

                else:
                    # Server error - retry
                    logger.warning(
                        f"Routeflow ingestion failed with {response.status_code}, "
                        f"attempt {attempt + 1}/{max_retries}"
                    )
                    if attempt < max_retries - 1:
                        time.sleep(backoff_ms / 1000)
                        backoff_ms *= 2
                        with self.stats._lock:
                            self.stats.retries += 1
                    else:
                        # Final attempt failed
                        with self.stats._lock:
                            self.stats.dropped_http_5xx += len(events)
                            self.stats.last_error_at = datetime.now(timezone.utc)

            except requests.Timeout:
                logger.warning(
                    f"Routeflow ingestion timeout, attempt {attempt + 1}/{max_retries}"
                )
                if attempt < max_retries - 1:
                    time.sleep(backoff_ms / 1000)
                    backoff_ms *= 2
                    with self.stats._lock:
                        self.stats.retries += 1
                else:
                    with self.stats._lock:
                        self.stats.dropped_http_5xx += len(events)
                        self.stats.last_error_at = datetime.now(timezone.utc)

            except Exception as e:
                logger.error(
                    f"Routeflow ingestion error: {e}, attempt {attempt + 1}/{max_retries}"
                )
                if attempt < max_retries - 1:
                    time.sleep(backoff_ms / 1000)
                    backoff_ms *= 2
                    with self.stats._lock:
                        self.stats.retries += 1
                else:
                    with self.stats._lock:
                        self.stats.dropped_http_5xx += len(events)
                        self.stats.last_error_at = datetime.now(timezone.utc)

    def shutdown(self, timeout_sec: float = 2.0) -> None:
        """
        Shutdown the worker and flush remaining events.

        Args:
            timeout_sec: Maximum time to wait for flush
        """
        if not self._running:
            return

        logger.info("Shutting down Routeflow client...")
        self._running = False

        # Send sentinel to stop worker
        try:
            self._queue.put(None, timeout=timeout_sec)
        except queue.Full:
            pass

        # Wait for worker to finish
        if self._worker_thread:
            self._worker_thread.join(timeout=timeout_sec)

        logger.info("Routeflow client shutdown complete")

    def get_stats(self) -> dict:
        """Get current stats."""
        return self.stats.to_dict()


# Global client instance
_client: Optional[RouteflowClient] = None
_client_lock = threading.Lock()


def get_client() -> Optional[RouteflowClient]:
    """Get the global client instance."""
    return _client


def init_client(config: RouteflowConfig) -> RouteflowClient:
    """Initialize the global client instance."""
    global _client

    with _client_lock:
        if _client is not None:
            logger.warning("Routeflow client already initialized")
            return _client

        _client = RouteflowClient(config)
        return _client


def shutdown_client(timeout_sec: float = 2.0) -> None:
    """Shutdown the global client instance."""
    global _client

    with _client_lock:
        if _client:
            _client.shutdown(timeout_sec)
            _client = None
