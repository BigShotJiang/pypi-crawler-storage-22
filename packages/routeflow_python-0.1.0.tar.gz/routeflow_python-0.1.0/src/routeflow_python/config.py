"""Configuration management for Routeflow SDK."""

import os
from typing import Optional


# Hardcoded Routeflow production backend URL
DEFAULT_INGEST_URL = "https://routeflow-backend-production.up.railway.app"


class RouteflowConfig:
    """Configuration from environment variables."""

    def __init__(
        self,
        ingest_key: Optional[str] = None,
        ingest_url: Optional[str] = None,
        environment: Optional[str] = None,
        enabled: Optional[bool] = None,
        sample_rate: Optional[float] = None,
        service_name: Optional[str] = None,
        max_events_per_batch: Optional[int] = None,
        flush_interval_ms: Optional[int] = None,
        queue_maxsize: Optional[int] = None,
        timeout_ms: Optional[int] = None,
    ):
        """
        Initialize configuration.

        Arguments override environment variables.
        """
        # Ingest URL - defaults to production, can be overridden for local testing
        self.ingest_url = ingest_url or os.getenv("ROUTEFLOW_INGEST_URL", DEFAULT_INGEST_URL)

        # Required: ingest key
        self.ingest_key = ingest_key or os.getenv("ROUTEFLOW_INGEST_KEY", "")

        # Optional
        self.environment = environment or os.getenv("ROUTEFLOW_ENV", "development")
        self.enabled = (
            enabled if enabled is not None
            else os.getenv("ROUTEFLOW_ENABLED", "true").lower() == "true"
        )
        self.sample_rate = (
            sample_rate if sample_rate is not None
            else float(os.getenv("ROUTEFLOW_SAMPLE_RATE", "1.0"))
        )
        self.service_name = service_name or os.getenv("ROUTEFLOW_SERVICE_NAME", "")

        # Batching & Performance
        self.max_events_per_batch = (
            max_events_per_batch if max_events_per_batch is not None
            else int(os.getenv("ROUTEFLOW_MAX_EVENTS_PER_BATCH", "50"))
        )
        self.flush_interval_ms = (
            flush_interval_ms if flush_interval_ms is not None
            else int(os.getenv("ROUTEFLOW_FLUSH_INTERVAL_MS", "1000"))
        )
        self.queue_maxsize = (
            queue_maxsize if queue_maxsize is not None
            else int(os.getenv("ROUTEFLOW_QUEUE_MAXSIZE", "5000"))
        )
        self.timeout_ms = (
            timeout_ms if timeout_ms is not None
            else int(os.getenv("ROUTEFLOW_TIMEOUT_MS", "1500"))
        )

        # Code version detection
        self.code_version = self._detect_code_version()

        # Validate
        self._validate()

    def _detect_code_version(self) -> Optional[str]:
        """Detect code version from environment variables."""
        # Try Routeflow-specific var first
        if version := os.getenv("ROUTEFLOW_CODE_VERSION"):
            return version

        # Try common CI variables
        ci_vars = [
            "VERCEL_GIT_COMMIT_SHA",
            "GIT_SHA",
            "COMMIT_SHA",
            "SOURCE_VERSION",
            "HEROKU_SLUG_COMMIT",
        ]

        for var in ci_vars:
            if version := os.getenv(var):
                return version

        return None

    def _validate(self) -> None:
        """Validate required configuration."""
        if self.enabled:
            if not self.ingest_key:
                raise ValueError(
                    "Routeflow ingest key is required. Set ROUTEFLOW_INGEST_KEY environment variable."
                )

            # Validate environment
            allowed_envs = {"production", "staging", "preview", "development"}
            if self.environment not in allowed_envs:
                # Default to development if invalid
                self.environment = "development"

            # Validate sample rate
            if not 0.0 <= self.sample_rate <= 1.0:
                raise ValueError("ROUTEFLOW_SAMPLE_RATE must be between 0.0 and 1.0")

            # Validate batch settings
            if self.max_events_per_batch < 1:
                raise ValueError("ROUTEFLOW_MAX_EVENTS_PER_BATCH must be >= 1")
            if self.flush_interval_ms < 100:
                raise ValueError("ROUTEFLOW_FLUSH_INTERVAL_MS must be >= 100")
            if self.queue_maxsize < 1:
                raise ValueError("ROUTEFLOW_QUEUE_MAXSIZE must be >= 1")
