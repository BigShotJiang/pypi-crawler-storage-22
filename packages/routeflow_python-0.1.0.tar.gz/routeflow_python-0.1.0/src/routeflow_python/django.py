"""Django integration for Routeflow."""

import logging
import time
from datetime import datetime, timezone
from typing import Optional
from uuid import uuid4

from .client import get_client, init_client, shutdown_client
from .config import RouteflowConfig
from .models import create_event

logger = logging.getLogger(__name__)

# Package version
__version__ = "0.1.0"

# Global config instance
_config: Optional[RouteflowConfig] = None


class RouteflowDjangoMiddleware:
    """
    Django middleware for Routeflow telemetry.

    Compatible with Django 3.2+ / 4.x / 5.x new-style middleware.

    Add to your Django settings.py:
        MIDDLEWARE = [
            # ... other middleware
            'routeflow_python.django.RouteflowDjangoMiddleware',
        ]

    Then initialize in your settings.py or manage.py:
        from routeflow_python import init_routeflow_django
        init_routeflow_django()
    """

    def __init__(self, get_response):
        """
        Initialize the middleware.

        Args:
            get_response: Django get_response callable
        """
        self.get_response = get_response

    def __call__(self, request):
        """
        Process a Django request.

        Args:
            request: Django HttpRequest

        Returns:
            Django HttpResponse
        """
        # Record start time
        start_time = time.perf_counter()
        request_start = datetime.now(timezone.utc)

        # Extract trace_id from headers
        # Django converts X-Routeflow-Trace-Id to HTTP_X_ROUTEFLOW_TRACE_ID
        trace_id = request.META.get("HTTP_X_ROUTEFLOW_TRACE_ID")
        if not trace_id:
            trace_id = str(uuid4())

        # Extract frontend_route from headers
        frontend_route = request.META.get("HTTP_X_ROUTEFLOW_FRONTEND_ROUTE", "__unknown__")

        # Extract backend method
        backend_method = request.method

        # Extract backend path
        # Try to get route pattern from resolver_match
        backend_path = request.path
        if hasattr(request, "resolver_match") and request.resolver_match:
            # Django 2.2+ has resolver_match.route
            if hasattr(request.resolver_match, "route"):
                backend_path = "/" + request.resolver_match.route
            # Fallback to pattern (older Django versions)
            elif hasattr(request.resolver_match, "route_name"):
                backend_path = request.path  # Use actual path as fallback

        # Extract handler (best effort)
        handler = None
        if hasattr(request, "resolver_match") and request.resolver_match:
            # Try view_name first
            if hasattr(request.resolver_match, "view_name") and request.resolver_match.view_name:
                handler = request.resolver_match.view_name
            # Try to get function name
            elif hasattr(request.resolver_match, "func"):
                func = request.resolver_match.func
                # Handle class-based views
                if hasattr(func, "view_class"):
                    view_class = func.view_class
                    handler = f"{view_class.__module__}.{view_class.__name__}"
                # Handle function-based views
                elif hasattr(func, "__module__") and hasattr(func, "__name__"):
                    handler = f"{func.__module__}.{func.__name__}"

        # Process request
        status_code = 500  # Default to 500
        exception_occurred = False

        try:
            response = self.get_response(request)
            status_code = response.status_code
            return response
        except Exception as e:
            # Mark exception occurred but don't swallow it
            exception_occurred = True
            status_code = 500
            raise
        finally:
            # Send telemetry event
            self._send_event(
                request_start=request_start,
                start_time=start_time,
                trace_id=trace_id,
                frontend_route=frontend_route,
                backend_method=backend_method,
                backend_path=backend_path,
                handler=handler,
                status_code=status_code,
            )

    def _send_event(
        self,
        request_start: datetime,
        start_time: float,
        trace_id: str,
        frontend_route: str,
        backend_method: str,
        backend_path: str,
        handler: Optional[str],
        status_code: int,
    ) -> None:
        """
        Send a Routeflow event.

        Args:
            request_start: Request start timestamp
            start_time: Performance counter start time
            trace_id: Request trace ID
            frontend_route: Frontend route from header
            backend_method: HTTP method
            backend_path: Backend route pattern
            handler: Handler name
            status_code: HTTP status code
        """
        try:
            # Calculate latency
            latency_sec = time.perf_counter() - start_time
            latency_ms = int(latency_sec * 1000)

            # Get config
            global _config
            if not _config:
                return  # Not initialized

            # Get client
            client = get_client()
            if not client:
                return

            # Create event
            event = create_event(
                timestamp=request_start,
                trace_id=trace_id,
                environment=_config.environment,
                frontend_route=frontend_route,
                backend_method=backend_method,
                backend_path=backend_path,
                status_code=status_code,
                latency_ms=latency_ms,
                handler=handler,
                code_version=_config.code_version,
                sdk_name="routeflow-python",
                sdk_version=__version__,
            )

            # Enqueue event (non-blocking)
            client.enqueue(event)

        except Exception as e:
            # Never fail the request due to telemetry
            logger.error(f"Error sending Routeflow event: {e}", exc_info=True)


def init_routeflow_django(
    *,
    ingest_key: Optional[str] = None,
    ingest_url: Optional[str] = None,
    environment: Optional[str] = None,
    enabled: Optional[bool] = None,
    sample_rate: Optional[float] = None,
) -> None:
    """
    Initialize Routeflow instrumentation for a Django app.

    Call this in your Django settings.py or manage.py before running the server.
    Also add 'routeflow_python.django.RouteflowDjangoMiddleware' to MIDDLEWARE.

    Args:
        ingest_key: Routeflow ingest key (overrides ROUTEFLOW_INGEST_KEY)
        ingest_url: Routeflow backend URL (overrides ROUTEFLOW_INGEST_URL, defaults to production)
                   Use this for local testing, e.g., "http://localhost:5002"
        environment: Environment name (overrides ROUTEFLOW_ENV)
        enabled: Enable/disable SDK (overrides ROUTEFLOW_ENABLED)
        sample_rate: Sampling rate 0.0-1.0 (overrides ROUTEFLOW_SAMPLE_RATE)

    Example (in settings.py):
        ```python
        from routeflow_python import init_routeflow_django

        # Add middleware
        MIDDLEWARE = [
            'django.middleware.security.SecurityMiddleware',
            # ... other middleware
            'routeflow_python.django.RouteflowDjangoMiddleware',
        ]

        # Initialize Routeflow
        init_routeflow_django()
        ```

    Example (local testing):
        ```python
        init_routeflow_django(ingest_url="http://localhost:5002")
        ```
    """
    global _config

    # Initialize config
    _config = RouteflowConfig(
        ingest_key=ingest_key,
        ingest_url=ingest_url,
        environment=environment,
        enabled=enabled,
        sample_rate=sample_rate,
    )

    if not _config.enabled:
        logger.info("Routeflow SDK is disabled")
        return

    # Initialize client
    client = init_client(_config)

    logger.info(
        f"Routeflow SDK initialized for Django (env={_config.environment}, "
        f"sample_rate={_config.sample_rate})"
    )


def shutdown_routeflow_django(timeout_sec: float = 2.0) -> None:
    """
    Shutdown the Routeflow client and flush remaining events.

    This is called automatically on process exit, but can be called
    manually for testing or graceful shutdown.

    Args:
        timeout_sec: Maximum time to wait for flush
    """
    shutdown_client(timeout_sec)
