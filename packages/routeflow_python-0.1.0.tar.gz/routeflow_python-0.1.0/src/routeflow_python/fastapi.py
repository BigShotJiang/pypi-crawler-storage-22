"""FastAPI/Starlette integration for Routeflow."""

import logging
import time
from datetime import datetime, timezone
from typing import Optional
from uuid import uuid4

from .client import get_client, init_client
from .config import RouteflowConfig
from .models import create_event

logger = logging.getLogger(__name__)

# Package version
__version__ = "0.1.0"


class RouteflowASGIMiddleware:
    """ASGI middleware for FastAPI/Starlette applications."""

    def __init__(self, app, config: RouteflowConfig):
        """
        Initialize the middleware.

        Args:
            app: ASGI application
            config: Routeflow configuration
        """
        self.app = app
        self.config = config

    async def __call__(self, scope, receive, send):
        """
        Process an ASGI request.

        Args:
            scope: ASGI scope dictionary
            receive: ASGI receive callable
            send: ASGI send callable
        """
        # Only handle HTTP requests
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        # Capture request start time
        start_time = time.perf_counter()
        request_start = datetime.now(timezone.utc)

        # Extract trace_id from headers
        headers_dict = {k.decode(): v.decode() for k, v in scope.get("headers", [])}
        trace_id = headers_dict.get("x-routeflow-trace-id")
        if not trace_id:
            trace_id = str(uuid4())

        # Extract frontend_route from headers
        frontend_route = headers_dict.get("x-routeflow-frontend-route", "__unknown__")

        # Extract backend method and path
        backend_method = scope.get("method", "GET")
        backend_path = scope.get("path", "/")

        # Try to get route pattern from scope
        if "route" in scope:
            route = scope["route"]
            if hasattr(route, "path"):
                backend_path = route.path

        # Extract handler (best effort)
        handler = None
        if "endpoint" in scope:
            endpoint = scope["endpoint"]
            if hasattr(endpoint, "__name__"):
                if hasattr(endpoint, "__module__"):
                    handler = f"{endpoint.__module__}.{endpoint.__name__}"
                else:
                    handler = endpoint.__name__
        elif "route" in scope:
            route = scope["route"]
            if hasattr(route, "name"):
                handler = route.name

        # Capture status code via send wrapper
        status_code = 500  # Default to 500 in case of errors

        async def send_wrapper(message):
            nonlocal status_code
            if message["type"] == "http.response.start":
                status_code = message.get("status", 500)
            await send(message)

        # Call the app
        try:
            await self.app(scope, receive, send_wrapper)
        except Exception as e:
            # Ensure we still send event for exceptions
            status_code = 500
            raise
        finally:
            # Send telemetry event
            try:
                latency_sec = time.perf_counter() - start_time
                latency_ms = int(latency_sec * 1000)

                client = get_client()
                if client:
                    event = create_event(
                        timestamp=request_start,
                        trace_id=trace_id,
                        environment=self.config.environment,
                        frontend_route=frontend_route,
                        backend_method=backend_method,
                        backend_path=backend_path,
                        status_code=status_code,
                        latency_ms=latency_ms,
                        handler=handler,
                        code_version=self.config.code_version,
                        sdk_name="routeflow-python",
                        sdk_version=__version__,
                    )
                    client.enqueue(event)
            except Exception as e:
                # Never fail the request due to telemetry
                logger.error(f"Error sending Routeflow event: {e}", exc_info=True)


def init_routeflow_fastapi(
    app,
    *,
    ingest_key: Optional[str] = None,
    ingest_url: Optional[str] = None,
    environment: Optional[str] = None,
    enabled: Optional[bool] = None,
    sample_rate: Optional[float] = None,
) -> None:
    """
    Initialize Routeflow instrumentation for a FastAPI/Starlette app.

    This adds ASGI middleware to capture backend request telemetry
    and send it to Routeflow automatically.

    Args:
        app: FastAPI or Starlette application instance
        ingest_key: Routeflow ingest key (overrides ROUTEFLOW_INGEST_KEY)
        ingest_url: Routeflow backend URL (overrides ROUTEFLOW_INGEST_URL, defaults to production)
                   Use this for local testing, e.g., "http://localhost:5002"
        environment: Environment name (overrides ROUTEFLOW_ENV)
        enabled: Enable/disable SDK (overrides ROUTEFLOW_ENABLED)
        sample_rate: Sampling rate 0.0-1.0 (overrides ROUTEFLOW_SAMPLE_RATE)

    Example:
        ```python
        from fastapi import FastAPI
        from routeflow_python import init_routeflow_fastapi

        app = FastAPI()
        init_routeflow_fastapi(app)

        @app.get("/api/users")
        def get_users():
            return {"users": []}
        ```

    Example (local testing):
        ```python
        app = FastAPI()
        init_routeflow_fastapi(app, ingest_url="http://localhost:5002")
        ```
    """
    # Initialize config
    config = RouteflowConfig(
        ingest_key=ingest_key,
        ingest_url=ingest_url,
        environment=environment,
        enabled=enabled,
        sample_rate=sample_rate,
    )

    if not config.enabled:
        logger.info("Routeflow SDK is disabled")
        return

    # Initialize client
    client = init_client(config)

    logger.info(
        f"Routeflow SDK initialized for FastAPI (env={config.environment}, "
        f"sample_rate={config.sample_rate})"
    )

    # Add middleware to the app
    app.add_middleware(RouteflowASGIMiddleware, config=config)
