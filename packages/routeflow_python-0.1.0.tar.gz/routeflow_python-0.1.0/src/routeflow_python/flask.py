"""Flask integration for Routeflow."""

import logging
import time
from datetime import datetime, timezone
from typing import Optional
from uuid import uuid4

from flask import Flask, g, request

from .client import get_client, init_client, shutdown_client
from .config import RouteflowConfig
from .models import create_event

logger = logging.getLogger(__name__)

# Package version
__version__ = "0.1.0"


def init_routeflow(
    app: Flask,
    *,
    ingest_key: Optional[str] = None,
    ingest_url: Optional[str] = None,
    environment: Optional[str] = None,
    enabled: Optional[bool] = None,
    sample_rate: Optional[float] = None,
) -> None:
    """
    Initialize Routeflow instrumentation for a Flask app.

    This registers request hooks to capture backend request telemetry
    and send it to Routeflow Cloud automatically.

    The SDK sends data to: https://routeflow-backend-production.up.railway.app

    Args:
        app: Flask application instance
        ingest_key: Routeflow ingest key (overrides ROUTEFLOW_INGEST_KEY)
        ingest_url: Routeflow backend URL (overrides ROUTEFLOW_INGEST_URL, defaults to production)
                   Use this for local testing, e.g., "http://localhost:5002"
        environment: Environment name (overrides ROUTEFLOW_ENV)
        enabled: Enable/disable SDK (overrides ROUTEFLOW_ENABLED)
        sample_rate: Sampling rate 0.0-1.0 (overrides ROUTEFLOW_SAMPLE_RATE)

    Example:
        ```python
        from flask import Flask
        from routeflow_python import init_routeflow

        app = Flask(__name__)
        init_routeflow(app)

        @app.route('/api/users')
        def get_users():
            return {'users': []}
        ```

    Example (local testing):
        ```python
        app = Flask(__name__)
        init_routeflow(app, ingest_url="http://localhost:5002")
        ```
    """
    # Initialize config
    config = RouteflowConfig(
        ingest_key=ingest_key,
        ingest_url=ingest_url,
        environment=environment,
        enabled=enabled,
        sample_rate=sample_rate,
    )

    if not config.enabled:
        logger.info("Routeflow SDK is disabled")
        return

    # Initialize client
    client = init_client(config)

    logger.info(
        f"Routeflow SDK initialized (env={config.environment}, "
        f"sample_rate={config.sample_rate})"
    )

    # Register Flask hooks
    @app.before_request
    def _routeflow_before_request():
        """Capture request start time and metadata."""
        # Start time for latency calculation
        g._routeflow_start_time = time.perf_counter()
        g._routeflow_request_start = datetime.now(timezone.utc)

        # Extract or generate trace_id
        trace_id = request.headers.get("x-routeflow-trace-id")
        if not trace_id:
            trace_id = str(uuid4())
        g._routeflow_trace_id = trace_id

        # Extract frontend_route from header or use fallback
        frontend_route = request.headers.get("x-routeflow-frontend-route", "__unknown__")
        g._routeflow_frontend_route = frontend_route

        # Capture backend method and path from Flask rule
        # Use the route pattern, not the actual path with values
        g._routeflow_backend_method = request.method

        if request.url_rule:
            # Use the route pattern
            g._routeflow_backend_path = request.url_rule.rule
        else:
            # Fallback for 404s or unmatched routes
            g._routeflow_backend_path = request.path

        # Capture handler (endpoint name)
        handler = None
        if request.endpoint:
            # Format as "blueprint.endpoint" if blueprint exists
            if request.blueprint:
                handler = f"{request.blueprint}.{request.endpoint}"
            else:
                handler = request.endpoint

        g._routeflow_handler = handler

    @app.after_request
    def _routeflow_after_request(response):
        """Capture response and send event."""
        _send_routeflow_event(response.status_code, None, config)
        return response

    @app.teardown_request
    def _routeflow_teardown_request(exception=None):
        """Handle exceptions and still report event."""
        # Only send if after_request didn't run (exception occurred)
        if exception is not None and not hasattr(g, "_routeflow_event_sent"):
            # Report as 500 for exceptions
            _send_routeflow_event(500, exception, config)


def _send_routeflow_event(
    status_code: int,
    exception: Optional[Exception],
    config: RouteflowConfig,
) -> None:
    """
    Send a Routeflow event.

    Args:
        status_code: HTTP status code
        exception: Exception if one occurred
        config: Routeflow configuration
    """
    # Mark as sent to avoid duplicate sends
    if hasattr(g, "_routeflow_event_sent"):
        return
    g._routeflow_event_sent = True

    try:
        # Calculate latency
        if not hasattr(g, "_routeflow_start_time"):
            return  # Before request didn't run

        latency_sec = time.perf_counter() - g._routeflow_start_time
        latency_ms = int(latency_sec * 1000)

        # Get client
        client = get_client()
        if not client:
            return

        # Create event
        event = create_event(
            timestamp=g._routeflow_request_start,
            trace_id=g._routeflow_trace_id,
            environment=config.environment,
            frontend_route=g._routeflow_frontend_route,
            backend_method=g._routeflow_backend_method,
            backend_path=g._routeflow_backend_path,
            status_code=status_code,
            latency_ms=latency_ms,
            handler=g._routeflow_handler,
            code_version=config.code_version,
            sdk_name="routeflow-python",
            sdk_version=__version__,
        )

        # Enqueue event (non-blocking)
        client.enqueue(event)

    except Exception as e:
        # Never fail the request due to telemetry
        logger.error(f"Error sending Routeflow event: {e}", exc_info=True)


def shutdown_routeflow(timeout_sec: float = 2.0) -> None:
    """
    Shutdown the Routeflow client and flush remaining events.

    This is called automatically on process exit, but can be called
    manually for testing or graceful shutdown.

    Args:
        timeout_sec: Maximum time to wait for flush
    """
    shutdown_client(timeout_sec)


def get_routeflow_stats() -> dict:
    """
    Get Routeflow SDK statistics.

    Returns:
        Dictionary with metrics about event processing

    Example:
        ```python
        stats = get_routeflow_stats()
        print(f"Events sent: {stats['sent']}")
        print(f"Events dropped: {stats['dropped_queue_full']}")
        ```
    """
    client = get_client()
    if not client:
        return {
            "enqueued": 0,
            "sent": 0,
            "dropped_queue_full": 0,
            "dropped_sampled": 0,
            "dropped_validation": 0,
            "dropped_http_4xx": 0,
            "dropped_http_5xx": 0,
            "retries": 0,
            "last_error_at": None,
        }
    return client.get_stats()
