"""Event models and validation."""

from datetime import datetime, timezone
from typing import TypedDict, Optional, Any
from uuid import UUID


class SDKInfo(TypedDict, total=False):
    """SDK information."""
    name: str
    version: str


class Event(TypedDict, total=False):
    """Backend request observed event."""
    type: str
    timestamp: str
    trace_id: str
    environment: str
    frontend_route: str
    backend_method: str
    backend_path: str
    handler: Optional[str]
    status_code: int
    latency_ms: int
    code_version: Optional[str]
    sdk: Optional[SDKInfo]


class IngestPayload(TypedDict):
    """Payload sent to ingest endpoint."""
    sent_at: str
    events: list[Event]


def validate_route(route: str, field_name: str) -> str:
    """
    Validate and sanitize a route string.

    Args:
        route: The route string
        field_name: Name of the field (for error messages)

    Returns:
        Validated route string

    Raises:
        ValueError: If validation fails
    """
    if not isinstance(route, str):
        raise ValueError(f"{field_name} must be a string")

    # Remove query strings
    if "?" in route:
        route = route.split("?")[0]

    # Enforce max length
    if len(route) > 512:
        route = route[:512]

    # Ensure not empty after sanitization
    if not route:
        raise ValueError(f"{field_name} cannot be empty after sanitization")

    return route


def validate_event(event: Event) -> None:
    """
    Validate an event before sending.

    Args:
        event: The event to validate

    Raises:
        ValueError: If validation fails
    """
    # Required fields
    required = ["type", "timestamp", "trace_id", "environment",
                "frontend_route", "backend_method", "backend_path", "status_code", "latency_ms"]

    for field in required:
        if field not in event:
            raise ValueError(f"Missing required field: {field}")

    # Validate type
    if event["type"] != "backend_request_observed":
        raise ValueError(f"Invalid event type: {event['type']}")

    # Validate routes (sanitize in place)
    event["frontend_route"] = validate_route(event["frontend_route"], "frontend_route")
    event["backend_path"] = validate_route(event["backend_path"], "backend_path")

    # Validate backend_method
    allowed_methods = {"GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"}
    if event["backend_method"] not in allowed_methods:
        raise ValueError(f"backend_method must be one of {allowed_methods}, got {event['backend_method']}")

    # Validate status code
    status = event["status_code"]
    if not isinstance(status, int) or not (100 <= status < 600):
        raise ValueError(f"status_code must be between 100-599, got {status}")

    # Validate latency
    latency = event["latency_ms"]
    if not isinstance(latency, int) or latency < 0:
        raise ValueError(f"latency_ms must be >= 0, got {latency}")

    # Validate environment
    allowed_envs = {"production", "staging", "preview", "development"}
    if event["environment"] not in allowed_envs:
        event["environment"] = "development"

    # Validate trace_id is valid UUID string
    try:
        UUID(event["trace_id"])
    except (ValueError, AttributeError):
        raise ValueError(f"trace_id must be a valid UUID, got {event['trace_id']}")


def create_event(
    timestamp: datetime,
    trace_id: str,
    environment: str,
    frontend_route: str,
    backend_method: str,
    backend_path: str,
    status_code: int,
    latency_ms: int,
    handler: Optional[str] = None,
    code_version: Optional[str] = None,
    sdk_name: Optional[str] = None,
    sdk_version: Optional[str] = None,
) -> Event:
    """
    Create a validated event.

    Args:
        timestamp: Event timestamp
        trace_id: Request trace ID
        environment: Environment name
        frontend_route: Frontend route
        backend_method: HTTP method (GET, POST, etc.)
        backend_path: Backend route pattern
        status_code: HTTP status code
        latency_ms: Request latency in milliseconds
        handler: Optional handler name
        code_version: Optional code version
        sdk_name: Optional SDK name
        sdk_version: Optional SDK version

    Returns:
        Validated event dictionary
    """
    event: Event = {
        "type": "backend_request_observed",
        "timestamp": timestamp.isoformat(),
        "trace_id": trace_id,
        "environment": environment,
        "frontend_route": frontend_route,
        "backend_method": backend_method,
        "backend_path": backend_path,
        "status_code": status_code,
        "latency_ms": latency_ms,
    }

    # Optional fields
    if handler:
        event["handler"] = handler
    if code_version:
        event["code_version"] = code_version
    if sdk_name and sdk_version:
        event["sdk"] = {"name": sdk_name, "version": sdk_version}

    # Validate before returning
    validate_event(event)

    return event
