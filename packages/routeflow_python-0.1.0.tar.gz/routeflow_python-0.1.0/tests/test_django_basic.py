"""Basic tests for Django integration."""

import os
import pytest

# Skip tests if Django not installed
pytest.importorskip("django")

# Configure Django settings before importing Django components
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests.django_settings")

import django
from django.conf import settings
from django.test import RequestFactory, Client
from django.http import JsonResponse
from django.urls import path

# Initialize Django
if not settings.configured:
    settings.configure(
        DEBUG=True,
        SECRET_KEY="test-secret-key",
        ROOT_URLCONF="tests.test_django_basic",
        MIDDLEWARE=[
            "django.middleware.common.CommonMiddleware",
            "routeflow_python.django.RouteflowDjangoMiddleware",
        ],
        ALLOWED_HOSTS=["*"],
    )
    django.setup()

from routeflow_python import (
    init_routeflow_django,
    shutdown_routeflow_django,
    get_routeflow_stats,
)
from routeflow_python.client import get_client, shutdown_client


# Test views
def test_view(request):
    """Test view."""
    return JsonResponse({"message": "test"})


def get_user_view(request, user_id):
    """Get user view."""
    return JsonResponse({"id": user_id})


def error_view(request):
    """Error view."""
    raise ValueError("Test error")


# URL patterns for testing
urlpatterns = [
    path("test/", test_view, name="test"),
    path("users/<int:user_id>/", get_user_view, name="get_user"),
    path("error/", error_view, name="error"),
]


@pytest.fixture
def client():
    """Create a Django test client."""
    return Client()


def test_init_routeflow_disabled():
    """Test that SDK can be disabled."""
    init_routeflow_django(enabled=False)

    client = Client()
    response = client.get("/test/")
    assert response.status_code == 200

    # Should not have any stats since disabled
    stats = get_routeflow_stats()
    assert stats["enqueued"] == 0

    # Cleanup
    shutdown_routeflow_django()


def test_init_routeflow_missing_config():
    """Test that SDK fails gracefully without config."""
    # Should raise ValueError for missing required config
    with pytest.raises(ValueError, match="ingest key is required"):
        init_routeflow_django(enabled=True)


def test_basic_request():
    """Test that basic request works."""
    # Shutdown any existing client
    shutdown_client()

    # Initialize with valid config but disabled
    init_routeflow_django(ingest_key="test-key", enabled=False)

    client = Client()
    response = client.get("/test/")
    assert response.status_code == 200
    assert response.json() == {"message": "test"}

    # Cleanup
    shutdown_routeflow_django()


def test_parameterized_route():
    """Test that parameterized routes work."""
    # Shutdown any existing client
    shutdown_client()

    init_routeflow_django(ingest_key="test-key", enabled=False)

    client = Client()
    response = client.get("/users/123/")
    assert response.status_code == 200
    assert response.json() == {"id": 123}

    # Cleanup
    shutdown_routeflow_django()


def test_error_handling():
    """Test that errors are handled and re-raised."""
    # Shutdown any existing client
    shutdown_client()

    init_routeflow_django(ingest_key="test-key", enabled=False)

    client = Client()
    # Django test client re-raises exceptions by default
    # Use raise_request_exception=False to get 500 response
    with pytest.raises(ValueError, match="Test error"):
        response = client.get("/error/")

    # Cleanup
    shutdown_routeflow_django()


def test_middleware_enqueues_events():
    """Test that middleware enqueues events when enabled."""
    # Shutdown any existing client
    shutdown_client()

    # Initialize with enabled=True to test enqueueing
    init_routeflow_django(
        ingest_key="test-key",
        enabled=True,
        ingest_url="http://localhost:9999",  # Fake URL, won't actually send
    )

    client = Client()
    response = client.get("/test/")
    assert response.status_code == 200

    # Check that event was enqueued
    stats = get_routeflow_stats()
    assert stats["enqueued"] >= 1

    # Cleanup
    shutdown_routeflow_django()


def test_route_pattern_capture():
    """Test that route patterns are captured correctly."""
    # Shutdown any existing client
    shutdown_client()

    init_routeflow_django(ingest_key="test-key", enabled=False)

    client = Client()

    # Test parameterized route
    response = client.get("/users/456/")
    assert response.status_code == 200
    assert response.json() == {"id": 456}

    # Cleanup
    shutdown_routeflow_django()


def test_header_extraction():
    """Test that trace_id and frontend_route headers are extracted."""
    # Shutdown any existing client completely
    shutdown_client(timeout_sec=0.5)

    # Give it a moment
    import time
    time.sleep(0.1)

    init_routeflow_django(
        ingest_key="test-key",
        enabled=True,
        ingest_url="http://localhost:9999",
    )

    # Verify client was initialized
    client_instance = get_client()
    assert client_instance is not None

    client = Client()
    # Use a valid UUID for trace_id
    response = client.get(
        "/test/",
        HTTP_X_ROUTEFLOW_TRACE_ID="550e8400-e29b-41d4-a716-446655440000",
        HTTP_X_ROUTEFLOW_FRONTEND_ROUTE="/frontend/path",
    )
    assert response.status_code == 200

    # Event should be enqueued
    stats = get_routeflow_stats()
    assert stats["enqueued"] >= 1, f"Expected at least 1 event enqueued, got {stats}"

    # Cleanup
    shutdown_routeflow_django()
