"""Basic tests for FastAPI integration."""

import pytest

# Skip tests if FastAPI not installed
pytest.importorskip("fastapi")

from fastapi import FastAPI
from fastapi.testclient import TestClient

from routeflow_python import init_routeflow_fastapi, get_routeflow_stats
from routeflow_python.client import get_client, shutdown_client


@pytest.fixture
def app():
    """Create a test FastAPI app."""
    app = FastAPI()

    @app.get("/test")
    def test_route():
        return {"message": "test"}

    @app.get("/users/{user_id}")
    def get_user(user_id: int):
        return {"id": user_id}

    @app.post("/users")
    def create_user(user: dict):
        return {"id": 1, "name": user.get("name")}

    @app.get("/error")
    def error_route():
        raise ValueError("Test error")

    return app


def test_init_routeflow_disabled(app):
    """Test that SDK can be disabled."""
    init_routeflow_fastapi(app, enabled=False)

    client = TestClient(app)
    response = client.get("/test")
    assert response.status_code == 200

    # Should not have any stats since disabled
    stats = get_routeflow_stats()
    assert stats["enqueued"] == 0


def test_init_routeflow_missing_config(app):
    """Test that SDK fails gracefully without config."""
    # Should raise ValueError for missing required config
    with pytest.raises(ValueError, match="ingest key is required"):
        init_routeflow_fastapi(app, enabled=True)


def test_basic_request(app):
    """Test that basic request works."""
    # Initialize with valid config but disabled
    # (to avoid actual HTTP calls in tests)
    init_routeflow_fastapi(app, ingest_key="test-key", enabled=False)

    client = TestClient(app)
    response = client.get("/test")
    assert response.status_code == 200
    assert response.json() == {"message": "test"}


def test_parameterized_route(app):
    """Test that parameterized routes work."""
    init_routeflow_fastapi(app, ingest_key="test-key", enabled=False)

    client = TestClient(app)
    response = client.get("/users/123")
    assert response.status_code == 200
    assert response.json() == {"id": 123}


def test_post_request(app):
    """Test POST request."""
    init_routeflow_fastapi(app, ingest_key="test-key", enabled=False)

    client = TestClient(app)
    response = client.post("/users", json={"name": "Alice"})
    assert response.status_code == 200
    assert response.json() == {"id": 1, "name": "Alice"}


def test_error_handling(app):
    """Test that errors are handled gracefully."""
    init_routeflow_fastapi(app, ingest_key="test-key", enabled=False)

    # TestClient with raise_server_exceptions=False returns 500 response
    client = TestClient(app, raise_server_exceptions=False)
    response = client.get("/error")
    assert response.status_code == 500


def test_middleware_enqueues_events(app):
    """Test that middleware enqueues events when enabled."""
    # Shutdown any existing client
    shutdown_client()

    # Initialize with enabled=True to test enqueueing
    init_routeflow_fastapi(
        app,
        ingest_key="test-key",
        enabled=True,
        ingest_url="http://localhost:9999",  # Fake URL, won't actually send
    )

    client = TestClient(app)
    response = client.get("/test")
    assert response.status_code == 200

    # Check that event was enqueued
    stats = get_routeflow_stats()
    assert stats["enqueued"] >= 1

    # Cleanup
    shutdown_client()


def test_route_pattern_capture(app):
    """Test that route patterns are captured correctly."""
    # This is more of an integration test - we'd need to verify
    # the actual event data to check route pattern extraction
    # For now, just verify the middleware doesn't break route handling
    init_routeflow_fastapi(app, ingest_key="test-key", enabled=False)

    client = TestClient(app)

    # Test parameterized route
    response = client.get("/users/456")
    assert response.status_code == 200
    assert response.json() == {"id": 456}

    # Cleanup
    shutdown_client()
