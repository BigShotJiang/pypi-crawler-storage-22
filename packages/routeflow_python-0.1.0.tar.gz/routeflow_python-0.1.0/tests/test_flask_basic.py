"""Basic tests for Flask integration."""

import pytest
from flask import Flask

from routeflow_python import init_routeflow, get_routeflow_stats


@pytest.fixture
def app():
    """Create a test Flask app."""
    app = Flask(__name__)

    @app.route('/test')
    def test_route():
        return {'message': 'test'}

    @app.route('/users/<int:user_id>')
    def get_user(user_id):
        return {'id': user_id}

    return app


def test_init_routeflow_disabled(app):
    """Test that SDK can be disabled."""
    init_routeflow(app, enabled=False)

    with app.test_client() as client:
        response = client.get('/test')
        assert response.status_code == 200

    # Should not have any stats since disabled
    stats = get_routeflow_stats()
    assert stats['enqueued'] == 0


def test_init_routeflow_missing_config(app):
    """Test that SDK fails gracefully without config."""
    # Should raise ValueError for missing required config
    with pytest.raises(ValueError, match="ingest key is required"):
        init_routeflow(app, enabled=True)


def test_basic_request(app):
    """Test that basic request works."""
    # Initialize with valid config but disabled
    # (to avoid actual HTTP calls in tests)
    init_routeflow(
        app,
        ingest_key="test-key",
        enabled=False
    )

    with app.test_client() as client:
        response = client.get('/test')
        assert response.status_code == 200
        assert response.json == {'message': 'test'}


def test_parameterized_route(app):
    """Test that parameterized routes work."""
    init_routeflow(
        app,
        ingest_key="test-key",
        enabled=False
    )

    with app.test_client() as client:
        response = client.get('/users/123')
        assert response.status_code == 200
        assert response.json == {'id': 123}


def test_stats_structure():
    """Test that stats have correct structure."""
    stats = get_routeflow_stats()

    required_keys = [
        'enqueued', 'sent', 'dropped_queue_full', 'dropped_sampled',
        'dropped_validation', 'dropped_http_4xx', 'dropped_http_5xx',
        'retries', 'last_error_at'
    ]

    for key in required_keys:
        assert key in stats


def test_hardcoded_ingest_url(app):
    """Test that ingest URL is hardcoded to Routeflow production."""
    from routeflow_python.config import RouteflowConfig

    config = RouteflowConfig(
        ingest_key="test-key",
        enabled=False
    )

    assert config.ingest_url == "https://routeflow-backend-production.up.railway.app"
