"""CLI entry point for router-maestro."""

from router_maestro.cli.main import app

if __name__ == "__main__":
    app()
