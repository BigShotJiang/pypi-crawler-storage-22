"""CLI module for router-maestro."""
