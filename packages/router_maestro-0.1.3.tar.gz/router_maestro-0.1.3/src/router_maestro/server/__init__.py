"""Server module for router-maestro."""

from router_maestro.server.app import app, create_app

__all__ = ["app", "create_app"]
