::: rowan.rowan_rdkit
    handler: python
    options:
      show_source: false
      show_root_heading: false
      show_root_toc_entry: false
      members_order: source        # show items in the order they appear in code
      group_by_category: true      # adds “Classes”, “Functions”, … headings -->
