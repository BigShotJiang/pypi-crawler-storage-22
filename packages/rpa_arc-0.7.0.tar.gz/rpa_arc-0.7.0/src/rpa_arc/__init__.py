"""rpa-arc: CLI para geração de estrutura de projetos RPA em Python."""

__version__ = "0.5.0"
