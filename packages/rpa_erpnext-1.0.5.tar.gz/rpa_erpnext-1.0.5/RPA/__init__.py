from .ERPNext import ERPNextLibrary

__version__ = "1.0.0"
__author__ = "Mahara"
__all__ = ["ERPNextLibrary"]
