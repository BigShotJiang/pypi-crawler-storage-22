
import sys
import os
import json

# Add parent directory to path to import RPA.ERPNext
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from RPA.ERPNext import ERPNextLibrary

# Configuration
BASE_URL = "http://4.216.192.221:8080"
API_KEY = "j47s948g5i"
API_SECRET = "c0b0693403"

def test_connection():
    print(f"\n--- Testing Connection to {BASE_URL} ---")
    erp = ERPNextLibrary(BASE_URL, API_KEY, API_SECRET)
    print("Connection initialized.")
    return erp

def test_get_document(erp):
    print("\n--- Testing Get Document (User) ---")
    try:
        # Assuming Administrator or Guest exists, or we list first
        users = erp.list_documents("User", limit=1)
        if users:
            first_user = users[0]
            print(f"Found user: {first_user['name']}")
            doc = erp.get_document("User", first_user['name'])
            print("Document details retrieved successfully.")
            # print(json.dumps(doc, indent=2))
        else:
            print("No users found to test get_document.")
    except Exception as e:
        print(f"Error in test_get_document: {e}")

def test_procurement_flow(erp):
    print("\n--- Testing Procurement Flow Utilities ---")
    
    company = "EduRPA Co."
    supplier = "Supplier Demo"
    item_code = "TEMP_SENSOR"
    
    # 1. Ensure exists check
    print(f"Checking if company exists: {company}")
    exists = erp.ensure_company_exist(company, "EDU")
    print(f"Company exists: {exists}")

    print(f"Checking if supplier exists: {supplier}")
    sup_exists = erp.ensure_supplier_exist(supplier)
    print(f"Supplier exists: {sup_exists}")

    # 2. Test create material request (Simulated data)
    items = [{"item_code": item_code, "qty": 10, "schedule_date": "2025-11-05", "warehouse": "Stores - EDU"}]
    print(f"Creating Material Request for items: {items}")
    try:
        mr = erp.create_material_request(company, items, "2025-11-05")
        print(f"Material Request Created: {mr.get('name')}")
        
        # 3. Create RFQ
        print(f"Creating RFQ from MR: {mr.get('name')}")
        rfq = erp.create_request_for_quotation(company, [{"supplier": supplier}], items)
        print(f"RFQ Created: {rfq.get('name')}")
        
    except Exception as e:
        print(f"Error in procurement flow: {e}")

def main():
    erp = test_connection()
    
    # Uncomment functions to test specific logic
    test_get_document(erp)
    test_procurement_flow(erp)

if __name__ == "__main__":
    main()
