import json
import pandas as pd
import requests
from robot.api.deco import keyword, library
@library(scope='GLOBAL', auto_keywords=False)
class ERPNextLibrary:
    def __init__(self, base_url=None, api_key=None, api_secret=None):
        self.base_url = None
        self.session = None
        if base_url and api_key and api_secret:
            self.connect(base_url, api_key, api_secret)

    def connect(self, base_url, api_key=None, api_secret=None, access_token=None):
        """
        Kết nối tới ERPNext server.
        
        Args:
            base_url: URL của ERPNext server
            api_key: API Key (cho Token Auth)
            api_secret: API Secret (cho Token Auth)
            access_token: OAuth2 Access Token (Bearer Auth)
        """
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

        if access_token:
            headers["Authorization"] = f"Bearer {access_token}"
        elif api_key and api_secret:
            headers["Authorization"] = f"token {api_key}:{api_secret}"
            
        self.session.headers.update(headers)
        return {"status": "connected", "base_url": self.base_url}

    @keyword("Setup ERPNext Connection")
    def setup_erpnext_connection(self, token_file_path: str):
        """
        Thiết lập kết nối với ERPNext từ file credential JSON.
        
        Args:
            token_file_path: Đường dẫn đến file token JSON
            
        Format 1 (Standard ERPNext):
        {
            "base_url": "...",
            "api_key": "...",
            "api_secret": "..."
        }
        
        Format 2 (Google-like / Moodle structure):
        {
            "access_token": "http://erpnext.example.com",  # Mapping base_url here
            "refresh_token": "key:secret"                 # Mapping credentials here
        }
        """
        if not token_file_path:
             raise Exception("Token file path is required")

        # Fix for potential argument naming issue from Robot Framework (connection=...)
        if token_file_path.startswith("connection="):
             token_file_path = token_file_path.split("=", 1)[1]

        with open(token_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
        base_url = None
        api_key = None
        api_secret = None
        access_token = None

        # Logic to parse different formats
        if 'access_token' in data and 'refresh_token' in data:
            # Format 2: Google-like structure
            # access_token field holds the URL
            # refresh_token field holds the credentials (key:secret)
            base_url = data.get('access_token')
            creds = data.get('refresh_token')
            
            if ":" in creds:
                parts = creds.split(":")
                api_key = parts[0]
                api_secret = parts[1]
            else:
                # If no colon, assume it's a bearer token? Or just raw key?
                # For consistency with user request "y chang moodle", we assume this structure.
                # But ERPNext needs key:secret. If it's a single string, maybe it's bearer?
                # Let's support bearer if it's not key:secret
                access_token = creds

        else:
            # Format 1: Standard
            base_url = data.get("base_url")
            api_key = data.get("api_key")
            api_secret = data.get("api_secret")
            access_token = data.get("access_token") # Real OAuth2 access token
        
        if not base_url:
             raise Exception("Could not find base_url in token file")

        if access_token:
            return self.connect(base_url, access_token=access_token)
        elif api_key and api_secret:
            return self.connect(base_url, api_key=api_key, api_secret=api_secret)
        else:
             raise Exception("Token file must contain credentials (api_key+api_secret OR access_token/refresh_token)")

    # ===========================================================
    #  Utility Methods
    # ===========================================================

    def create_resource(self, doctype, data):
        res = self.session.post(f"{self.base_url}/api/resource/{doctype}", json=data)
        if not res.ok:
            raise Exception(f"HTTP {res.status_code}: {res.text}")
        return res.json().get("data", res.json())

    def get_doc(self, doctype, name):
        res = self.session.get(f"{self.base_url}/api/resource/{doctype}/{name}")
        res.raise_for_status()
        return res.json().get("data")

    def exists(self, doctype, name):
        """Kiểm tra xem tài nguyên có tồn tại hay không."""
        res = self.session.get(f"{self.base_url}/api/resource/{doctype}/{name}")
        return res.ok

    @keyword("Get Document")
    def get_document(self, doctype, name):
        """
        Lấy thông tin chi tiết của một document.
        
        Args:
            doctype: Loại document (Item, Customer, Sales Order, etc.)
            name: Tên/ID của document
            
        Example:
            | ${doc}= | Get Document | Customer | CUST-00001 |
        """
        return self.get_doc(doctype, name)

    @keyword("List Documents")
    def list_documents(self, doctype, filters=None, fields=None, limit=20):
        """
        Lấy danh sách documents với filters.
        
        Args:
            doctype: Loại document
            filters: Điều kiện lọc (dict hoặc JSON string)
            fields: Các trường cần lấy (list hoặc JSON string)
            limit: Số lượng kết quả tối đa
            
        Example:
            | ${items}= | List Documents | Item | {"item_group": "Products"} | ["item_code", "item_name"] | 10 |
        """
        params = {"limit_page_length": limit}
        
        if filters:
            if isinstance(filters, str):
                filters = json.loads(filters)
            params["filters"] = json.dumps(filters)
        
        if fields:
            if isinstance(fields, str):
                fields = json.loads(fields)
            params["fields"] = json.dumps(fields)
        
        res = self.session.get(f"{self.base_url}/api/resource/{doctype}", params=params)
        res.raise_for_status()
        return res.json().get("data", [])

    @keyword("Update Document")
    def update_document(self, doctype, name, data):
        """
        Cập nhật một document.
        
        Args:
            doctype: Loại document
            name: Tên/ID của document
            data: Dữ liệu cần cập nhật (dict hoặc JSON string)
            
        Example:
            | Update Document | Item | ITEM-001 | {"description": "New description"} |
        """
        if isinstance(data, str):
            data = json.loads(data)
        
        res = self.session.put(f"{self.base_url}/api/resource/{doctype}/{name}", json=data)
        if not res.ok:
            raise Exception(f"HTTP {res.status_code}: {res.text}")
        return res.json().get("data", res.json())

    @keyword("Delete Document")
    def delete_document(self, doctype, name):
        """
        Xóa một document.
        
        Args:
            doctype: Loại document
            name: Tên/ID của document
            
        Example:
            | Delete Document | Item | ITEM-001 |
        """
        res = self.session.delete(f"{self.base_url}/api/resource/{doctype}/{name}")
        if not res.ok:
            raise Exception(f"HTTP {res.status_code}: {res.text}")
        return {"status": "deleted", "doctype": doctype, "name": name}

    # ===========================================================
    #  Ensure Functions - Master Data
    # ===========================================================

    @keyword("Ensure Company Exist")
    def ensure_company_exist(self, company: str, abbr: str):
        """Đảm bảo Company tồn tại."""
        if self.exists("Company", company):
            return {"status": "exists", "name": company}

        data = {
            "doctype": "Company",
            "company_name": company,
            "abbr": abbr,
            "default_currency": "VND",
            "country": "Vietnam",
            "company_logo": None
        }
        return self.create_resource("Company", data)

    @keyword("Ensure Warehouse Exist")
    def ensure_warehouse_exist(self, warehouse: str, company: str):
        """Đảm bảo Warehouse tồn tại."""
        if self.exists("Warehouse", warehouse):
            return {"status": "exists", "name": warehouse}

        data = {
            "doctype": "Warehouse",
            "warehouse_name": warehouse,
            "company": company,
        }
        return self.create_resource("Warehouse", data)

    @keyword("Ensure Supplier Exist")
    def ensure_supplier_exist(self, supplier_name: str):
        """Đảm bảo Supplier tồn tại."""
        if self.exists("Supplier", supplier_name):
            return {"status": "exists", "name": supplier_name}

        data = {
            "doctype": "Supplier",
            "supplier_name": supplier_name,
            "supplier_type": "Company",
            "country": "Vietnam",
        }
        return self.create_resource("Supplier", data)

    @keyword("Ensure Items Exist")
    def ensure_items_exist(self, items_json):
        """Đảm bảo tất cả item tồn tại."""
        if isinstance(items_json, str):
            items = json.loads(items_json)
        else:
            items = items_json

        created_items = []
        for i in items:
            code = i["item_code"]
            if self.exists("Item", code):
                created_items.append({"status": "exists", "item_code": code})
                continue

            data = {
                "doctype": "Item",
                "item_code": code,
                "item_name": code,
                "description": i.get("description", code),
                "stock_uom": "Nos",
                "is_stock_item": 1,
                "item_group": "All Item Groups",
            }
            res = self.create_resource("Item", data)
            created_items.append(res)
        return created_items

    @keyword("Ensure Customer Exist")
    def ensure_customer_exist(self, customer_name: str, customer_group="Commercial", territory="Vietnam"):
        """
        Đảm bảo Customer tồn tại.
        
        API: /api/resource/Customer
        
        Args:
            customer_name: Tên khách hàng
            customer_group: Nhóm khách hàng (mặc định: Commercial)
            territory: Khu vực (mặc định: Vietnam)
        """
        if self.exists("Customer", customer_name):
            return {"status": "exists", "name": customer_name}

        data = {
            "doctype": "Customer",
            "customer_name": customer_name,
            "customer_type": "Company",
            "customer_group": customer_group,
            "territory": territory,
        }
        return self.create_resource("Customer", data)

    # ===========================================================
    #  Sales APIs - Quy trình bán hàng
    # ===========================================================

    @keyword("Create Sales Order")
    def create_sales_order(self, customer: str, items, delivery_date: str, company: str):
        """
        Tạo Sales Order (Đơn hàng bán).
        
        API: /api/resource/Sales Order
        
        Args:
            customer: Tên khách hàng
            items: Danh sách items [{"item_code": "ITEM-001", "qty": 10, "rate": 1000}]
            delivery_date: Ngày giao hàng (format: YYYY-MM-DD)
            company: Tên công ty
            
        Example:
            | ${items}= | Create List | {"item_code": "ITEM-001", "qty": 10, "rate": 1000} |
            | Create Sales Order | Customer A | ${items} | 2025-12-01 | My Company |
        """
        self.ensure_customer_exist(customer)
        
        if isinstance(items, str):
            items = json.loads(items)
        
        order_items = []
        for item in items:
            order_items.append({
                "item_code": item["item_code"],
                "qty": item["qty"],
                "rate": item.get("rate", 0),
                "delivery_date": delivery_date,
                "uom": item.get("uom", "Nos"),
            })

        data = {
            "doctype": "Sales Order",
            "customer": customer,
            "company": company,
            "delivery_date": delivery_date,
            "items": order_items
        }
        return self.create_resource("Sales Order", data)

    @keyword("Create Sales Invoice")
    def create_sales_invoice(self, customer: str, items, company: str, posting_date=None):
        """
        Tạo Sales Invoice (Hóa đơn bán hàng).
        
        API: /api/resource/Sales Invoice
        
        Args:
            customer: Tên khách hàng
            items: Danh sách items [{"item_code": "ITEM-001", "qty": 10, "rate": 1000}]
            company: Tên công ty
            posting_date: Ngày lập hóa đơn (mặc định: ngày hiện tại)
        """
        self.ensure_customer_exist(customer)
        
        if isinstance(items, str):
            items = json.loads(items)
        
        invoice_items = []
        for item in items:
            invoice_items.append({
                "item_code": item["item_code"],
                "qty": item["qty"],
                "rate": item.get("rate", 0),
                "uom": item.get("uom", "Nos"),
            })

        data = {
            "doctype": "Sales Invoice",
            "customer": customer,
            "company": company,
            "items": invoice_items
        }
        if posting_date:
            data["posting_date"] = posting_date
            
        return self.create_resource("Sales Invoice", data)

    # ===========================================================
    #  Stock/Inventory APIs - Quản lý kho
    # ===========================================================

    @keyword("Create Stock Entry")
    def create_stock_entry(self, purpose: str, items, company: str, posting_date=None):
        """
        Tạo Stock Entry (Phiếu nhập/xuất kho).
        
        API: /api/resource/Stock Entry
        
        Args:
            purpose: Mục đích (Material Receipt, Material Issue, Material Transfer, etc.)
            items: Danh sách items với warehouse
            company: Tên công ty
            posting_date: Ngày lập phiếu
            
        Purpose types:
            - Material Receipt: Nhập kho
            - Material Issue: Xuất kho
            - Material Transfer: Chuyển kho
            - Manufacture: Sản xuất
            - Repack: Đóng gói lại
            
        Example:
            | ${items}= | Create List | {"item_code": "ITEM-001", "qty": 100, "t_warehouse": "Stores - EDU"} |
            | Create Stock Entry | Material Receipt | ${items} | My Company |
        """

        if isinstance(items, str):
            items = json.loads(items)

        stock_items = []
        for item in items:
            stock_items.append({
                "item_code": item["item_code"],
                "qty": item["qty"],
                "s_warehouse": item.get("s_warehouse"),  # Source warehouse
                "t_warehouse": item.get("t_warehouse"),  # Target warehouse
                "uom": item.get("uom", "Nos"),
                "stock_uom": item.get("stock_uom", "Nos"),
                "conversion_factor": item.get("conversion_factor", 1.0),
            })

        data = {
            "doctype": "Stock Entry",
            "purpose": purpose,
            "company": company,
            "items": stock_items
        }
        if posting_date:
            data["posting_date"] = posting_date
            
        return self.create_resource("Stock Entry", data)

    @keyword("Create Purchase Receipt")
    def create_purchase_receipt(self, supplier: str, items, company: str, posting_date=None):
        """
        Tạo Purchase Receipt (Phiếu nhận hàng mua).
        
        API: /api/resource/Purchase Receipt
        
        Args:
            supplier: Tên nhà cung cấp
            items: Danh sách items [{"item_code": "ITEM-001", "qty": 100, "rate": 1000, "warehouse": "Stores - EDU"}]
            company: Tên công ty
            posting_date: Ngày nhận hàng
        """
        self.ensure_supplier_exist(supplier)
        
        if isinstance(items, str):
            items = json.loads(items)
        
        receipt_items = []
        for item in items:
            receipt_items.append({
                "item_code": item["item_code"],
                "qty": item["qty"],
                "rate": item.get("rate", 0),
                "warehouse": item.get("warehouse"),
                "uom": item.get("uom", "Nos"),
            })

        data = {
            "doctype": "Purchase Receipt",
            "supplier": supplier,
            "company": company,
            "items": receipt_items
        }
        if posting_date:
            data["posting_date"] = posting_date
            
        return self.create_resource("Purchase Receipt", data)



    @keyword("Create Purchase Order")
    def create_purchase_order(self, supplier: str, items, company: str, schedule_date=None):
        """
        Tạo Purchase Order (Đơn hàng mua).
        
        API: /api/resource/Purchase Order
        
        Args:
            supplier: Tên nhà cung cấp
            items: Danh sách items [{"item_code": "ITEM-001", "qty": 100, "rate": 1000}]
            company: Tên công ty
            schedule_date: Ngày cần hàng
        """
        self.ensure_supplier_exist(supplier)
        
        if isinstance(items, str):
            items = json.loads(items)
            
        po_items = []
        for item in items:
            po_items.append({
                "item_code": item["item_code"],
                "qty": item["qty"],
                "rate": item.get("rate", 0),
                "schedule_date": item.get("schedule_date", schedule_date),
                "warehouse": item.get("warehouse"),
                "uom": item.get("uom", "Nos"),
            })

        data = {
            "doctype": "Purchase Order",
            "supplier": supplier,
            "company": company,
            "items": po_items,
            "schedule_date": schedule_date
        }
            
        return self.create_resource("Purchase Order", data)

    # ===========================================================
    #  Accounting APIs - Kế toán
    # ===========================================================

    @keyword("Create Purchase Invoice")
    def create_purchase_invoice(self, supplier: str, items, company: str, posting_date=None):
        """
        Tạo Purchase Invoice (Hóa đơn mua hàng).
        
        API: /api/resource/Purchase Invoice
        
        Args:
            supplier: Tên nhà cung cấp
            items: Danh sách items [{"item_code": "ITEM-001", "qty": 100, "rate": 1000}]
            company: Tên công ty
            posting_date: Ngày lập hóa đơn
        """
        self.ensure_supplier_exist(supplier)
        
        if isinstance(items, str):
            items = json.loads(items)

        invoice_items = []
        for item in items:
            invoice_items.append({
                "item_code": item["item_code"],
                "qty": item["qty"],
                "rate": item.get("rate", 0),
                "uom": item.get("uom", "Nos"),
            })

        data = {
            "doctype": "Purchase Invoice",
            "supplier": supplier,
            "company": company,
            "items": invoice_items
        }
        if posting_date:
            data["posting_date"] = posting_date
            
        return self.create_resource("Purchase Invoice", data)

    @keyword("Create Payment Entry")
    def create_payment_entry(self, payment_type: str, party_type: str, party: str, 
                            paid_amount: float, company: str, posting_date=None):
        """
        Tạo Payment Entry (Phiếu thanh toán).
        
        API: /api/resource/Payment Entry
        
        Args:
            payment_type: Loại thanh toán (Receive, Pay, Internal Transfer)
            party_type: Loại đối tác (Customer, Supplier, Employee)
            party: Tên đối tác
            paid_amount: Số tiền thanh toán
            company: Tên công ty
            posting_date: Ngày thanh toán
            
        Example:
            | Create Payment Entry | Receive | Customer | Customer A | 10000000 | My Company |
            | Create Payment Entry | Pay | Supplier | Supplier B | 5000000 | My Company |
        """
        data = {
            "doctype": "Payment Entry",
            "payment_type": payment_type,
            "party_type": party_type,
            "party": party,
            "paid_amount": paid_amount,
            "received_amount": paid_amount if payment_type == "Receive" else 0,
            "company": company,
        }
        if posting_date:
            data["posting_date"] = posting_date
            
        return self.create_resource("Payment Entry", data)

    # ===========================================================
    #  Procurement - Quy trình mua hàng (đã có sẵn)
    # ===========================================================

    @keyword("Load Excel Request")
    def load_excel_request(self, path: str):
        """Đọc file Excel chứa company, itemcode, quantity."""
        df = pd.read_excel(path)
        return df.to_dict(orient="records")

    @keyword("Create Material Request From Excel")
    def create_material_request_from_excel(self, path: str, schedule_date: str):
        """Tạo Material Request từ file Excel."""
        rows = self.load_excel_request(path)
        if not rows:
            raise Exception("Excel file không có dữ liệu.")

        company = rows[0]["company"]
        self.ensure_company_exist(company, "EDU")
        self.ensure_warehouse_exist(f"Stores - EDU", company)

        items = []
        for row in rows:
            self.ensure_items_exist([{
                "item_code": row["itemcode"],
                "description": row["itemcode"]
            }])
            items.append({
                "item_code": row["itemcode"],
                "description": row["itemcode"],
                "qty": float(row["quantity"]),
                "schedule_date": schedule_date,
                "warehouse": f"Stores - EDU",
                "uom": "Nos",
                "stock_uom": "Nos",
                "conversion_factor": 1.0
            })

        data = {
            "doctype": "Material Request",
            "material_request_type": "Purchase",
            "company": company,
            "schedule_date": schedule_date,
            "items": items
        }
        return self.create_resource("Material Request", data)

    # ===========================================================
    #  Step 2: Gửi RFQ
    # ===========================================================

    @keyword("Send RFQ From Material Request")
    def send_rfq_from_mr(self, mr_name, suppliers):
        """Tạo RFQ dựa trên Material Request."""
        # Auto-detect if mr_name is a dict (from previous keyword return)
        if isinstance(mr_name, dict):
            mr_name = mr_name.get("name")
        
        # Normalize suppliers to list of strings
        if isinstance(suppliers, str):
            try:
                suppliers = json.loads(suppliers)
            except ValueError:
                # Nếu không phải JSON list, coi như là 1 supplier duy nhất
                suppliers = [suppliers]
        
        # Ensure suppliers is a list
        if not isinstance(suppliers, list):
            suppliers = [suppliers]
        
        # Flatten if nested list (e.g., [['Supplier A']] -> ['Supplier A'])
        if suppliers and isinstance(suppliers[0], list):
            suppliers = suppliers[0]

        mr_doc = self.get_doc("Material Request", mr_name)
        company = mr_doc["company"]
        self.ensure_warehouse_exist(f"Stores - EDU", company)
        for s in suppliers:
            self.ensure_supplier_exist(s)


        items = []
        for d in mr_doc["items"]:
            # Ensure all fields are proper types (not lists)
            item_code = d["item_code"]
            if isinstance(item_code, list):
                item_code = item_code[0] if item_code else ""
            
            warehouse = d.get("warehouse", "")
            if isinstance(warehouse, list):
                warehouse = warehouse[0] if warehouse else ""
            
            items.append({
                "item_code": str(item_code),
                "qty": float(d["qty"]),
                "uom": str(d.get("uom", "Nos")),
                "stock_uom": str(d.get("stock_uom", "Nos")),
                "conversion_factor": 1.0,
                "warehouse": str(warehouse),
            })

        rfq_data = {
            "doctype": "Request for Quotation",
            "company": str(company),
            "transaction_date": str(mr_doc["schedule_date"]),
            "suppliers": [{"supplier": str(s)} for s in suppliers],
            "items": items,
            "message_for_supplier": "Xin vui lòng gửi báo giá."
        }
        
        # Debug logging
        import logging
        logging.info(f"RFQ Data: {rfq_data}")
        
        return self.create_resource("Request for Quotation", rfq_data)

    # ===========================================================
    #  Step 3: Supplier gửi báo giá
    # ===========================================================

    @keyword("Receive Supplier Quotation")
    def receive_supplier_quotation(self, rfq_name: str, supplier_name: str, quotation_data):
        """
        Nhận báo giá từ Supplier.
        
        Args:
            rfq_name: Mã Request for Quotation
            supplier_name: Tên nhà cung cấp
            quotation_data: 
                - Đường dẫn file Excel (.xlsx) chứa các cột: item_code, qty, rate
                - Hoặc List/JSON string chứa thông tin items
        """
        rfq_doc = self.get_doc("Request for Quotation", rfq_name)
        company = rfq_doc["company"]
        self.ensure_supplier_exist(supplier_name)
        
        items_list = []

        # Case 1: Input is Excel file path
        if isinstance(quotation_data, str) and (quotation_data.endswith('.xlsx') or quotation_data.endswith('.xls')):
            df = pd.read_excel(quotation_data)
            # Clean column names (optional: lowercase)
            df.columns = [c.lower().strip() for c in df.columns]
            
            for _, row in df.iterrows():
                # Flexible column mapping
                item_code = row.get("item_code") or row.get("itemcode")
                qty = row.get("qty") or row.get("quantity")
                rate = row.get("rate") or row.get("price") or 0
                
                items_list.append({
                    "item_code": item_code,
                    "qty": float(qty),
                    "rate": float(rate),
                    "uom": "Nos",
                    "stock_uom": "Nos",
                    "conversion_factor": 1.0,
                    "warehouse": f"Stores - EDU"
                })
        
        # Case 2: Input is List or JSON String
        else:
            if isinstance(quotation_data, str):
                quotation_data = json.loads(quotation_data)

            for q in quotation_data:
                items_list.append({
                    "item_code": q["item_code"],
                    "qty": q["qty"],
                    "rate": q["rate"],
                    "uom": "Nos",
                    "stock_uom": "Nos",
                    "conversion_factor": 1.0,
                    "warehouse": f"Stores - EDU"
                })

        sq_data = {
            "doctype": "Supplier Quotation",
            "supplier": supplier_name,
            "company": company,
            "transaction_date": "2026-01-28",
            "items": items_list,
        }

        return self.create_resource("Supplier Quotation", sq_data)

    # ===========================================================
    #  Step 4: Tạo Purchase Order
    # ===========================================================

    @keyword("Create Purchase Order From Quotation")
    def create_purchase_order_from_quotation(self, quotation_name: str):
        sq_doc = self.get_doc("Supplier Quotation", quotation_name)
        supplier = sq_doc["supplier"]
        company = sq_doc["company"]

        self.ensure_supplier_exist(supplier)
        self.ensure_warehouse_exist(f"Stores - EDU", company)

        items = []
        for d in sq_doc["items"]:
            items.append({
                "item_code": d["item_code"],
                "qty": d["qty"],
                "rate": d["rate"],
                "schedule_date": "2026-02-28",
                "warehouse": f"Stores - EDU",
                "uom": d.get("uom", "Nos"),
                "conversion_factor": 1.0
            })

        po_data = {
            "doctype": "Purchase Order",
            "supplier": supplier,
            "company": company,
            "schedule_date": "2026-02-28",
            "items": items
        }
        return self.create_resource("Purchase Order", po_data)

        
