    @keyword("Export Grading Results With Question Breakdown To Excel")
    def export_grading_results_with_question_breakdown_to_excel(
        self,
        grading_results: List[Dict[str, Any]],
        output_path: str,
        max_score: float = 10.0
    ) -> str:
        """
        Export kết quả chấm điểm với breakdown từng câu hỏi ra Excel.
        
        Mỗi học sinh sẽ có nhiều dòng, mỗi dòng là 1 câu hỏi với:
        - Câu trả lời của học sinh
        - Đúng/Sai
        
        Args:
            grading_results: List of grading result dictionaries
            output_path: Path to save Excel file
            max_score: Maximum score
            
        Returns:
            Path to created Excel file
            
        Excel format:
        | Student Name | Question | Student Answer | Correct/Incorrect | Explanation |
        |--------------|----------|----------------|-------------------|-------------|
        | student1     | Câu 1    | Paris          | Đúng              | ...         |
        | student1     | Câu 2    | London         | Sai               | ...         |
        
        Example:
            ${file}=    Export Grading Results With Question Breakdown To Excel    ${grades}    breakdown.xlsx    10.0
        """
        import pandas as pd
        import re
        
        # Prepare data rows
        rows = []
        
        for result in grading_results:
            student_name = result.get('student_name', 'Unknown')
            score = result.get('score', 0)
            correct_answers = result.get('correct_answers', 0)
            total_questions = result.get('total_questions', 0)
            feedback_full = result.get('feedback', '')
            
            # Extract GRADING section
            grading_match = re.search(r'(?:GRADING|CHẤM ĐIỂM):(.+?)(?:SUMMARY:|TỔNG KẾT:|FEEDBACK:|NHẬN XÉT:|$)', 
                                     feedback_full, re.DOTALL | re.IGNORECASE)
            
            if grading_match:
                grading_text = grading_match.group(1).strip()
                
                # Parse each question line
                # Format: "Câu 1: [answer] - [Đúng/Sai] - [explanation]"
                question_lines = grading_text.split('\n')
                
                for line in question_lines:
                    line = line.strip()
                    if not line or line.startswith('*'):
                        continue
                    
                    # Try to parse: "Câu X: answer - Đúng/Sai - explanation"
                    match = re.match(r'(?:Question|Câu)\s+(\d+):\s*(.+?)\s*-\s*(Đúng|Sai|Correct|Incorrect)\s*-\s*(.+)', 
                                    line, re.IGNORECASE)
                    
                    if match:
                        question_num = match.group(1)
                        answer = match.group(2).strip()
                        correctness = match.group(3).strip()
                        explanation = match.group(4).strip()
                        
                        # Normalize correctness to Vietnamese
                        if correctness.lower() in ['correct', 'đúng']:
                            correctness = 'Đúng'
                        else:
                            correctness = 'Sai'
                        
                        rows.append({
                            'Student Name': student_name,
                            'Question': f'Câu {question_num}',
                            'Student Answer': answer,
                            'Correct/Incorrect': correctness,
                            'Explanation': explanation
                        })
            
            # Add summary row for this student
            if rows and rows[-1]['Student Name'] == student_name:
                rows.append({
                    'Student Name': student_name,
                    'Question': '--- TỔNG KẾT ---',
                    'Student Answer': f'{correct_answers}/{total_questions} câu đúng',
                    'Correct/Incorrect': f'{score}/{max_score} điểm',
                    'Explanation': f'{score/max_score*100:.1f}%'
                })
        
        # Create DataFrame
        df = pd.DataFrame(rows)
        
        # Export to Excel with formatting
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='Question Breakdown')
            
            # Get workbook and worksheet
            workbook = writer.book
            worksheet = writer.sheets['Question Breakdown']
            
            # Set column widths
            worksheet.column_dimensions['A'].width = 20  # Student Name
            worksheet.column_dimensions['B'].width = 15  # Question
            worksheet.column_dimensions['C'].width = 50  # Student Answer
            worksheet.column_dimensions['D'].width = 20  # Correct/Incorrect
            worksheet.column_dimensions['E'].width = 60  # Explanation
            
            # Enable text wrapping
            from openpyxl.styles import Alignment, Font, PatternFill
            for row in worksheet.iter_rows(min_row=2, max_row=worksheet.max_row):
                for cell in row:
                    cell.alignment = Alignment(wrap_text=True, vertical='top')
                
                # Highlight summary rows
                if row[1].value and '---' in str(row[1].value):
                    for cell in row:
                        cell.font = Font(bold=True)
                        cell.fill = PatternFill(start_color='E0E0E0', end_color='E0E0E0', fill_type='solid')
                
                # Color code correct/incorrect
                if row[3].value:
                    if 'Đúng' in str(row[3].value):
                        row[3].fill = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
                    elif 'Sai' in str(row[3].value):
                        row[3].fill = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
        
        self.logger.info(f"Question breakdown exported to: {output_path}")
        self.logger.info(f"Exported {len(rows)} question-level results")
        return output_path
