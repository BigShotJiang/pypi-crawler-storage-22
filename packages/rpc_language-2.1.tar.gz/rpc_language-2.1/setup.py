from setuptools import setup

setup(
    name="rpc-language",
    version="2.1",
    py_modules=["rpc"],
    install_requires=["pyinstaller"],
    entry_points={
        "console_scripts": [
            "rpc=rpc:main",
        ],
    },
)