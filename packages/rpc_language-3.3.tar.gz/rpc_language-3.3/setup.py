from setuptools import setup

setup(
    name="rpc-language",
    version="3.3",
    py_modules=["rpc"],
    install_requires=["pyinstaller"],
    entry_points={
        "console_scripts": [
            "rpc=rpc:main",
        ],
    },
)