import subprocess
import shutil
import time
import sys
import os

class RPC:
    class NeedSemicolon(Exception):
        def __init__(self, message):
            super().__init__(message)

    class MismatchedQuotationMarks(Exception):
        def __init__(self, message):
            super().__init__(message)

    class NotFiles(Exception):
        def __init__(self, message):
            super().__init__(message)

    class SingleLineIteration(Exception):
        def __init__(self, message):
            super().__init__(message)


def parse(line):
    indent   = len(line) - len(line.lstrip())
    line     = line.lstrip()
    add      = False

    mark1a = 0
    mark1b = 0
    text = line.split("//")[0]
    for i in line:
        if i == "'":
            mark1a += 1
        if i == '"':
            mark1b += 1

    mark2a = 0
    mark2b = 0
    for i in text:
        if i == "'":
            mark2a += 1
        if i == '"':
            mark2b += 1

    if mark1a % 2 == 0:
        if mark1b % 2 == 0:
            pass
        else:
            raise RPC.MismatchedQuotationMarks("不匹配的引号")
    else:
        raise RPC.MismatchedQuotationMarks("不匹配的引号")

    if "//" in line:
        if mark2a % 2 == 0 or mark2a == 0:
            if mark2b % 2 == 0 or mark2b == 0:
                line = line.split("//")[0].rstrip()

    if line.endswith(";"):    line = line[:-1]
    elif line == "":          pass
    elif line.endswith("{"):  pass
    elif line.endswith("}"):  pass
    elif line.endswith(">"):  pass
    elif line.endswith("++"): pass
    elif line.endswith("--"): pass
    elif line.endswith("?"):  pass
    elif line.startswith("@"):pass
    else:                     raise RPC.NeedSemicolon("缺少分号")

    if line.startswith("loop"):
        if line.endswith("loop"):
            line = "while True: pass"

        else:
            try:
                int(line[5:-1].rstrip().split()[0])
                ok = True
            except:
                ok = False

            if ok is True:
                if line.rstrip()[-1] != "{":
                    raise RPC.SingleLineIteration("不允许单行的次数循环")

                line = f"for _ in range({line[5:-1].rstrip()}):"
            else:
                if line.endswith("{"):
                    line = "while True:" + line[4:-1].rstrip()
                else:
                    line = "while True:" + line[4:].rstrip()

    if line.startswith("fn "):
        line = 'def ' + line[3:]

    if line.endswith("{"):
        if len(line) >= 3:
            if line[-3] != "=" or line[-2] != "=":
                if line.endswith(" {"):
                    line = line[0:-2] + ":"
                else:
                    line = line[0:-1] + ":"
        else:
            if line.endswith(" {"):
                    line = line[0:-2] + ":"
            else:
                line = line[0:-1] + ":"

    if line.startswith("}"):
        if line.startswith("} "):
            line = line[2:]
        else:
            line = line[1:]

    if line.startswith("from<"):
        attempt = False
        if line[-1] == "?":
            attempt = True

        line = line.split("from<")
        line = ' '.join(line)
        line = line.split("import<")

        line = [
            "from",
            line[0][:-1] if line[0][-1] == '>' else line[0][:-2],
            "import",
            line[1][:-1] if line[1][-1] == '>' else line[1][:-2]
        ]
        line = ' '.join(line)
        line = line.replace("  ", " ")

        if attempt:
            line = line + "?"

    if line.startswith("import<"):
        line = "import " + line[7:-1]

    if line.startswith("include<"):
        filename = line[8:-1]
        if os.path.exists(filename):
            try:
                with open(filename, "r", encoding="utf-8") as file:
                    lines = file.read().splitlines()
            except:
                raise RPC.NotFiles("未找到此文件")

            if filename[-4:] == ".rpc":
                line = ""
                for code in lines:
                    line += f"{parse(code)}\n"
            else:
                line = ""
                for code in lines:
                    line += f"{code}\n"

    if line.endswith("]"):
        lineadd = line.split("#[")
        line = lineadd[0].rstrip()
        add = True
        addfn = lineadd[1][:-1]

    if line == "@static":
        line = "@staticmethod"
    if line.endswith("++"):
        line = f"{line[:-2]} += 1"
    if line.endswith("--"):
        line = f"{line[:-2]} -= 1"
    if line.endswith("?"):
        line = "try:" + f"{line[:-1]}\n" + " " * indent + "except:pass"
    if add:
        line = f"{addfn}({line})"
    if line:
        line = " " * indent + line

    return line

def help():
    print("RustPythonCode")
    print("用法:")
    print("  check - 检查RPC代码")
    print("  parse - 分析RPC代码")
    print("  build - 分析并编译RPC代码")
    print("  run   - 分析并运行RPC代码")
    print("  help  - 显示帮助")

def main(args=None):
    if args is None:
        args = sys.argv

    if len(args) <= 1:
        help()
        return

    try:
        if args[1] not in ["check", "parse", "build", "run"] or args[1] == "help":
            if args[1] != "help":
                print("\033[97;41m错误: 没有这个参数\033[0m")

            help()

        if args[1] in ["check", "parse", "build", "run"]:
            if os.path.exists(args[2]):
                with open(args[2], "r", encoding="utf-8") as file:
                    codes = file.read().splitlines()
            else:
                print("\033[97;41m错误: 未找到此文件\033[0m")
                return

            if args[1] != "run":
                print("分析代码..." if args[1] != "check" else "检查代码...", end="\r")

            new    = []
            n      = 1
            all    = len(codes)
            error  = False
            for code in codes:
                try:
                    new.append(parse(code))
                except RPC.NeedSemicolon as e:
                    print(" " * 50, end='\r')
                    print(f"\033[97;41m\033[4m第{n}行\033[24m {code.lstrip()} - {e}\033[0m")
                    error = True

                except Exception as e:
                    print(" " * 50, end='\r')
                    print(f"\033[97;41m\033[4m第{n}行\033[24m {code.lstrip()} - {e}\033[0m")
                    error = True

                progress = round(n / all, 2)
                if args[1] != "run":
                    print("分析代码 " if args[1] != "check" else "检查代码 ", end="")
                    print("\033[36m[" + "#" * (i := int(int(progress * 100) / 5)) +
                        " " * int(int(100 / 5) - i) +
                        "]" +
                        f" {i * 5}%\033[0m", end='\r'
                    )
                n += 1

            if error:
                return

            new.append('if __name__ == "__main__":')
            new.append('    main()')

            if args[1] != "run":
                print(" " * 50, end='\r')

            output = args[2].replace(".rpc", ".py")
            if output == args[2]:
                output = args[2] + ".py"

            if args[1] != "check":
                with open(output, "w", encoding="utf-8") as file:
                    for code in new:
                        file.write(code + "\n")

            exe = output.replace(".py", ".exe")
            spec = exe.replace(".exe", ".spec")

            if args[1] != "run":
                if args[1] != "check":
                    print(f"\033[92m分析代码\033[0m \033[93m->\033[0m \033[4m{output}\033[0m")
                else:
                    print(f"\033[92m代码检查完成\033[0m")

        if args[1] == "run":
            os.system(f"python {output}")

        if args[1] == "build":
            try:
                process = subprocess.Popen(
                    f'pyinstaller {output} --onefile',
                    shell=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )

                n = 0

                while True:
                    bar   = ["|", "/", "-", "\\"]
                    order = [0, 1, 2, 3]
                    if n >= len(order):
                        n = 0

                    print("编译中 \033[36m" + bar[order[n]] + "\033[0m", end='\r', flush=True)

                    result = process.poll()
                    if result is not None:
                        print(f"\033[92m编译完成\033[0m \033[93m->\033[0m \033[4m{exe}\033[0m")
                        break

                    n += 1
                    time.sleep(0.5)

                try:
                    shutil.move(f"dist/{exe}", exe)
                    shutil.rmtree("dist")
                    shutil.rmtree("build")
                    os.remove(spec)
                except:
                    shutil.rmtree("dist")
                    shutil.rmtree("build")
                    os.remove(spec)

            except Exception as e:
                print(f"\033[97;41m错误: 编译失败: {e}\033[0m")
    except Exception as e:
        print(f"\033[97;41m错误: {e}\033[0m")

if __name__ == "__main__":
    try:
        main(sys.argv)
    except KeyboardInterrupt:
        exit()
    except Exception as e:
        print(f"\033[97;41m错误: {e}\033[0m")
