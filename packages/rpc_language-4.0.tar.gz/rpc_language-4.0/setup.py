from setuptools import setup

setup(
    name="rpc-language",
    version="4.0",
    py_modules=["rpc"],
    install_requires=["pyinstaller"],
    entry_points={
        "console_scripts": [
            "rpc=rpc:main",
        ],
    },
)