from setuptools import setup

version = "4.1"

setup(
    name="rpc-language",
    version=version,
    description="RPC Language - RustPythonCode 转译器",
    long_description="一个将 Rust 风格(但又没那么Rust)的 RPC 语法编译/解释为 Python 的语言工具",
    author="XiaoME",
    author_email="dev-xiaome@outlook.com",
    py_modules=["rpc"],
    install_requires=["pyinstaller>=6.0"],
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 4 - Beta",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Compilers",
    ],
    license="MIT",
    keywords="rpc python rust",
    entry_points={
        "console_scripts": [
            "rpc=rpc:main",
        ],
    },
)