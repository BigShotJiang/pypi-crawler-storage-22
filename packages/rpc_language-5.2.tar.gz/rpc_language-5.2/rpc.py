import subprocess
import shutil
import time
import sys
import os

class RPC:
    class NeedSemicolon(Exception):
        def __init__(self, message):
            super().__init__(message)

    class NotNeedSemicolon(Exception):
        def __init__(self, message):
            super().__init__(message)

    class MismatchedQuotationMarks(Exception):
        def __init__(self, message):
            super().__init__(message)

    class NotFiles(Exception):
        def __init__(self, message):
            super().__init__(message)

    class SingleLineIteration(Exception):
        def __init__(self, message):
            super().__init__(message)

    class ArrowsAndPipes(Exception):
        def __init__(self, message):
            super().__init__(message)

    class Def(Exception):
        def __init__(self, message):
            super().__init__(message)

    class CurlyBrackets(Exception):
            def __init__(self, message):
                super().__init__(message)

    class PoundSign(Exception):
            def __init__(self, message):
                super().__init__(message)

    class Import(Exception):
            def __init__(self, message):
                super().__init__(message)

    class From(Exception):
            def __init__(self, message):
                super().__init__(message)

    class Static(Exception):
            def __init__(self, message):
                super().__init__(message)

    class Except(Exception):
            def __init__(self, message):
                super().__init__(message)

def parse(line):
    if not line:
        return ""

    indent = len(line) - len(line.lstrip())
    line   = line.lstrip()
    arrows = False
    pipes  = False

    global left
    global right

    mark1a = 0
    mark1b = 0
    for i in line:
        if i == "'":
            mark1a += 1
        if i == '"':
            mark1b += 1

    mark2a = 0
    mark2b = 0
    text = line.split("//")[-1]
    for i in text:
        if i == "'":
            mark2a += 1
        if i == '"':
            mark2b += 1

    mark3a = 0
    mark3b = 0
    text = line.split("|>")[-1]
    for i in text:
        if i == "'":
            mark3a += 1
        if i == '"':
            mark3b += 1

    mark4a = 0
    mark4b = 0
    text = line.split("->")[-1]
    for i in text:
        if i == "'":
            mark4a += 1
        if i == '"':
            mark4b += 1

    if mark1a % 2 == 0:
        if mark1b % 2 == 0:
            pass
        else:
            raise RPC.MismatchedQuotationMarks("不匹配的引号")
    else:
        raise RPC.MismatchedQuotationMarks("不匹配的引号")

    if "//" in line:
        if mark2a % 2 == 0 or mark2a == 0:
            if mark2b % 2 == 0 or mark2b == 0:
                line = line.split("//")[0].rstrip()

    elif "#" in line:
        mark5a = 0
        mark5b = 0
        text = line.split("#")[-1]
        for i in text:
            if i == "'":
                mark5a += 1
            if i == '"':
                mark5b += 1
        if mark5a % 2 == 0 or mark5a == 0:
            if mark5b % 2 == 0 or mark5b == 0:
                raise RPC.PoundSign("需要使用 \"//\"")

    if line.endswith("{"):
        left += 1
        if line[-3] != "=" or line[-2] != "=":
            if line.endswith(" {"):
                line = line[0:-2] + ":"
            else:
                line = line[0:-1] + ":"

    elif line.endswith(":"):
        raise RPC.CurlyBrackets("需要使用 \"{\"")

    if line.startswith("}"):
        right += 1
        if line.startswith("} "):
            line = line[2:]
        else:
            line = line[1:]

    if line.startswith("loop"):
        if line.endswith("loop"):
            line = "while True: pass"

        else:
            try:
                int(line[5:-1].rstrip().split()[0])
                ok = True
            except:
                ok = False

            if ok is True:
                if line.rstrip()[-1] != ":":
                    raise RPC.SingleLineIteration("不允许单行的次数循环")

                line = f"for _ in range({line[5:-1].rstrip()}):"
            else:
                if line.endswith(":"):
                    line = "while True:" + line[4:-1].rstrip()
                else:
                    line = "while True:" + line[4:].rstrip()

    if line.startswith("fn "):
        if line[3] != "=":
            line = 'def ' + line[3:]
    elif line.startswith("def "):
        raise RPC.Def("需要使用 \"fn\"")

    if line.startswith("catch:"):
        line = "except:" + line[6:]
    elif line.startswith("except:"):
        raise RPC.Except("需要使用 \"catch\"")

    if line.startswith("from<"):
        attempt = False
        if line[-1] == "?":
            attempt = True

        line = line.split("from<")
        line = ' '.join(line)
        line = line.split("import<")

        if len(line) == 1:
            line = [
                "from",
                line[0][:-1] if line[0][-1] == '>' else line[0][:-2],
                "import *"
            ]
        else:
            line = [
                "from",
                line[0][:-1] if line[0][-1] == '>' else line[0][:-2],
                "import",
                line[1][:-1] if line[1][-1] == '>' else line[1][:-2]
            ]
        line = ' '.join(line)
        line = line.replace("  ", " ")

        if attempt:
            line = line + "?"

    elif line.startswith("from "):
        raise RPC.Import("需要使用 \"from<>\"")

    if line.startswith("import<"):
        name = line[7:-1]
        line = "import " + name

    elif line.startswith("import "):
        raise RPC.Import("需要使用 \"import<>\"")

    if line.startswith("include<"):
        filename = line[8:-1]
        if filename == "stdio":
            line = "from builtins import *"
        elif os.path.exists(filename):
            try:
                with open(filename, "r", encoding="utf-8") as file:
                    lines = file.read().splitlines()
            except:
                raise RPC.NotFiles("未找到此文件")

            if filename[-4:] == ".rpc":
                line = ""
                for code in lines:
                    line += f"{parse(code)}\n"
            else:
                line = ""
                for code in lines:
                    line += f"{code}\n"

    if line == "@static":
        line = "@staticmethod"
    elif line == "@staticmethod":
        raise RPC.Static("需要使用 \"@static\"")

    if line.endswith("++"):
        line = f"{line[:-2]} += 1"
    if line.endswith("--"):
        line = f"{line[:-2]} -= 1"
    if line.endswith("?"):
        line = "try:" + f"{line[:-1]}\n" + " " * indent + "except:pass"
    elif "??" in line:
        mark6a = 0
        mark6b = 0
        text = line.split("??")[-1]
        for i in text:
            if i == "'":
                mark6a += 1
            if i == '"':
                mark6b += 1
        if mark6a % 2 == 0 or mark6a == 0:
            if mark6b % 2 == 0 or mark6b == 0:
                tmp = line.split("??")
                line = "try:" + f"{'??'.join(tmp[:-1]).rstrip().lstrip()}\n" + " " * indent + f"except:{tmp[-1].rstrip().lstrip()}"

    if "|>" in line:
        if mark3a % 2 == 0 or mark3a == 0:
            if mark3b % 2 == 0 or mark3b == 0:
                arrows = True
                parts = [p.strip() for p in line.split("|>")]
                result = parts[0]
                for func in parts[1:]:
                    result = f"{func}({result})"
                line = result

    if "->" in line:
        if mark4a % 2 == 0 or mark4a == 0:
            if mark4b % 2 == 0 or mark4b == 0:
                if line[-1] != ":":
                    pipes = True
                    line = line.split("->")
                    line = f"{line[-1].strip()} = {'->'.join(line[:-1]).strip()}"

    if arrows and pipes:
        raise RPC.ArrowsAndPipes("\"|>\" 与 \"->\" 搭配会导致夸克粒子被切割")
    if line:
        line = " " * indent + line

    return line

def help():
    version = "5.2"
    logo = r"""    ____  ____  ______
   / __ \/ __ \/ ____/
  / /_/ / /_/ / /
 / _, _/ ____/ /___
/_/ |_/_/    \____/"""
    print(logo)
    print(" " * 12 + f"[Version {version}]")
    print()
    print("\033[92m用法:\033[0m")
    print("  \033[36mcheck\033[0m - \033[93m检查RPC代码\033[0m")
    print("  \033[36mparse\033[0m - \033[93m分析RPC代码\033[0m")
    print("  \033[36mbuild\033[0m - \033[93m分析并编译RPC代码\033[0m")
    print("  \033[36mrun\033[0m   - \033[93m分析并运行RPC代码\033[0m")
    print("  \033[36mhelp\033[0m  - \033[93m显示帮助\033[0m")

def main(args=None):
    if args is None:
        args = sys.argv

    if len(args) <= 1:
        help()
        return

    try:
        if args[1] not in ["check", "parse", "build", "run"] or args[1] == "help":
            if args[1] != "help":
                print("\033[97;41m错误: 没有这个参数\033[0m")

            help()

        if args[1] in ["check", "parse", "build", "run"]:
            if os.path.exists(args[2]):
                with open(args[2], "r", encoding="utf-8") as file:
                    codes = file.read().splitlines()
            else:
                print("\033[97;41m错误: 未找到此文件\033[0m")
                return

            if args[1] != "run":
                print("分析代码..." if args[1] != "check" else "检查代码...", end="\r")

            global left
            global right

            left  = 0
            right = 0

            new    = []
            n      = 1
            all    = len(codes)
            error  = False
            for code in codes:
                try:
                    new.append(parse(code))
                except RPC.NeedSemicolon as e:
                    print(" " * 50, end='\r')
                    print(f"\033[97;41m\033[4m第{n}行\033[24m {code.lstrip()} - {e}\033[0m")
                    error = True

                except Exception as e:
                    print(" " * 50, end='\r')
                    print(f"\033[97;41m\033[4m第{n}行\033[24m {code.lstrip()} - {e}\033[0m")
                    error = True

                progress = round(n / all, 2)
                if args[1] != "run":
                    print("分析代码 " if args[1] != "check" else "检查代码 ", end="")
                    print("\033[36m[" + "#" * (i := int(int(progress * 100) / 5)) +
                        " " * int(int(100 / 5) - i) +
                        "]" +
                        f" {i * 5}%\033[0m", end='\r'
                    )
                n += 1

            if left != right:
                print(f"\033[97;41m错误: 分析失败: 不匹配的大括号作用域\033[0m")
                error = True

            if error:
                return

            new = ["__builtins__ = builtins"] + new
            new = ["builtins = {'__import__': __builtins__.__import__}"] + new
            new.append('if __name__ == "__main__":')
            new.append('    main()')

            if args[1] != "run":
                print(" " * 50, end='\r')

            output = args[2].replace(".rpc", ".py")
            if output == args[2]:
                output = args[2] + ".py"

            if args[1] != "check":
                with open(output, "w", encoding="utf-8") as file:
                    for code in new:
                        file.write(code + "\n")

            exe = output.replace(".py", ".exe")
            spec = exe.replace(".exe", ".spec")

            if args[1] != "run":
                if args[1] != "check":
                    print(f"\033[92m分析代码\033[0m \033[93m->\033[0m \033[4m{output}\033[0m")
                else:
                    print(f"\033[92m代码检查完成\033[0m")

        if args[1] == "run":
            os.system(f"python {output}" if os.name == "nt" else f"python3 {output}")

        if args[1] == "build":
            try:
                process = subprocess.Popen(
                    f'pyinstaller {output} --onefile',
                    shell=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )

                n = 0

                while True:
                    bar   = ["|", "/", "-", "\\"]
                    order = [0, 1, 2, 3]
                    if n >= len(order):
                        n = 0

                    print("编译中 \033[36m" + bar[order[n]] + "\033[0m", end='\r', flush=True)

                    result = process.poll()
                    if result is not None:
                        print(f"\033[92m编译完成\033[0m \033[93m->\033[0m \033[4m{exe}\033[0m")
                        break

                    n += 1
                    time.sleep(0.5)

                try:
                    shutil.move(f"dist/{exe}", exe)
                    shutil.rmtree("dist")
                    shutil.rmtree("build")
                    os.remove(spec)
                except:
                    shutil.rmtree("dist")
                    shutil.rmtree("build")
                    os.remove(spec)

            except Exception as e:
                print(f"\033[97;41m错误: 编译失败: {e}\033[0m")
    except Exception as e:
        print(f"\033[97;41m错误: {e}\033[0m")

if __name__ == "__main__":
    try:
        main(sys.argv)
    except KeyboardInterrupt:
        exit()
    except Exception as e:
        print(f"\033[97;41m错误: {e}\033[0m")
