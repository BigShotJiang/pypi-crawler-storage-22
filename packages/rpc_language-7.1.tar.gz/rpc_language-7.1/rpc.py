import subprocess
import shutil
import base64
import time
import json
import sys
import os

class RPC:
    class NotFiles(Exception):
        def __init__(self, message):
            super().__init__(message)

    class Quark(Exception):
        def __init__(self, message):
            super().__init__(message)

    class NeedFn(Exception):
        def __init__(self, message):
            super().__init__(message)

    class NeedCurlyBrackets(Exception):
            def __init__(self, message):
                super().__init__(message)

    class Import(Exception):
            def __init__(self, message):
                super().__init__(message)

    class From(Exception):
            def __init__(self, message):
                super().__init__(message)

    class NeedStatic(Exception):
            def __init__(self, message):
                super().__init__(message)

    class NeedCatch(Exception):
            def __init__(self, message):
                super().__init__(message)

    class NeedInt(Exception):
            def __init__(self, message):
                super().__init__(message)

    class NeedLet(Exception):
            def __init__(self, message):
                super().__init__(message)

def instr(text, string):
    tmp    = ""
    have   = []
    a      = False
    b      = False
    escape = False
    pos    = []
    cur    = 0
    cont   = 0

    for i in text:
        if (escape == True) and (i == "'" or i == '"'):
            escape = True
        else:
            escape = False

        if tmp + i == string[:len(tmp)+1]:
            tmp += i
        else:
            tmp = ""

        if tmp == string:
            if a == True or b == True:
                have.append(False)
                cur += 1
            else:
                pos.append(cur)
                have.append(True)
                cur += 1

        if i == '"':
            if a == True and b == False and escape == False:
                a = False
                cont += 1
            elif a == False and b == False and escape == False:
                a = True
                cont += 1

            if cont == 3:
                cont = 0
                a    = False

        elif i == "'":
            if a == False and b == True and escape == False:
                b = False
                cont += 1
            elif a == False and b == False and escape == False:
                b = True
                cont += 1

            if cont == 3:
                cont = 0
                b    = False

        else:
            cont = 0
        if i == "\\":
            escape = True
        else:
            escape = False

    return pos if True in have else False

def leng(text):
    length = 0
    for char in str(text):
        code = ord(char)
        if (0x4E00 <= code <= 0x9FFF or
            0x3400 <= code <= 0x4DBF or
            0x20000 <= code <= 0x2A6DF or
            0x2A700 <= code <= 0x2B73F or
            0x2B740 <= code <= 0x2B81F or
            0x2B820 <= code <= 0x2CEAF or
            0x2CEB0 <= code <= 0x2EBEF or
            0x30000 <= code <= 0x3134F or
            0xF900 <= code <= 0xFAFF or
            0x2F800 <= code <= 0x2FA1F or
            0xFF00 <= code <= 0xFFEF or
            char in '，。！？；：「」【】（）《》'):
            length += 2
        else:
            length += 1
    return length

def findstr(text, string):
    tmp   = ""
    pos   = []
    n     = 0
    start = 0
    alr   = False

    for i in text:
        if tmp + i == string[:len(tmp)+1]:
            if not alr:
                start = n
            alr   = True
            tmp += i
        else:
            alr = False
            tmp = ""

        if tmp == string:
            pos.append([start, n])
            tmp = ""

        n += 1

    return pos if pos else None

def parse(line):
    global left
    global right
    global deepin
    global multiple

    if instr(line, "'''"):
        multiple = not multiple

    if instr(line, '"""'):
        multiple = not multiple

    if multiple:
        return line

    indent   = len(line) - len(line.lstrip())
    line     = line.strip()
    arrows   = False
    pipes    = False
    question = False

    if not line:
        return ""

    if line.endswith("{"):
        assig = False
        scope = False
        for i in line[::-1]:
            if i == "{":
                continue
            elif i == ":":
                deepin += 1
                scope = True
                break
            elif i == "[":
                deepin += 1
                scope = True
                break
            elif i == "(":
                deepin += 1
                scope = True
                break
            elif i == "=":
                assig = True
                continue
            elif i == " ":
                continue
            else:
                scope = False
                break

        if line == "{":
            deepin += 1

        elif scope:
            pass

        elif not assig:
            line = line[:-1].rstrip() + ":"
            left += 1
        else:
            deepin += 1

    elif line.endswith(":"):
        raise RPC.NeedCurlyBrackets("需要使用 \"{\"")

    if line.endswith("{}"):
        assig = False
        for i in line[::-1]:
            if i == "}":
                continue
            elif i == "{":
                continue
            elif i == "=":
                assig = True
                break
            elif i == " ":
                continue
            else:
                assig = False
                break

        if not assig:
            line = line[:-2].rstrip() + ": pass"

    if line.startswith("}"):
        if deepin == 0:
            line = line.lstrip("}").lstrip()
            right += 1
        else:
            deepin -= 1

    if pos := instr(line, "let "):
        assig = len(instr(line, "="))
        - len(instr(line, "=="))
        - len(instr(line, "!="))
        - len(instr(line, ">="))
        - len(instr(line, "<="))

        let = len(instr(line, "let "))

        if assig != let:
            print(let, assig)
            print(len(findstr(line, "let ")), len(instr(line, "let ")))
            raise RPC.NeedLet("需要使用 \"let\"")

        if pos:
            n    = 0
            tmp  = []
            find = findstr(line, "let ")
            for i in range(pos[-1] + 1):
                if n in pos:
                    tmp.append(find[n])
                n += 1

            find   = tmp
            result = line
            for i in sorted(range(len(find)), reverse=True):
                result = result[:find[i][0]] + result[find[i][1]+1:]

        line = result

    elif instr(line, "="):
        assig = len(instr(line, "="))
        - len(instr(line, "=="))
        - len(instr(line, "!="))
        - len(instr(line, ">="))
        - len(instr(line, "<="))

        if assig != 0:
            raise RPC.NeedLet("需要使用 \"let\"")

    if line.startswith("loop"):
        if line == "loop":
            line = "while True: pass"
        elif line == "loop:":
            line = "while True:"
        else:
            line = f"for _ in range({line[5:-1].rstrip()})" + (":" if line[-1] == ":" else "")

    if line.startswith("fn "):
        if line[3] != "=":
            line = 'def ' + line[3:]
    elif line.startswith("def "):
        raise RPC.NeedFn("需要使用 \"fn\"")

    if line.startswith("catch"):
        line = "except" + line[5:]
    elif line.startswith("except"):
        raise RPC.NeedCatch("需要使用 \"catch\"")

    if line.startswith("from<"):
        attempt = False
        if line[-1] == "?":
            attempt = True

        line = line.split("from<")
        line = ' '.join(line)
        line = line.split("import<")

        if len(line) == 1:
            line = [
                "from",
                line[0][:-1] if line[0][-1] == '>' else line[0][:-2],
                "import *"
            ]
        else:
            line = [
                "from",
                line[0][:-1] if line[0][-1] == '>' else line[0][:-2],
                "import",
                line[1][:-1] if line[1][-1] == '>' else line[1][:-2]
            ]
        line = ' '.join(line)
        line = line.replace("  ", " ")

        if attempt:
            line = line + "?"

    elif line.startswith("from "):
        raise RPC.Import("需要使用 \"from<>\"")

    if line.startswith("import<"):
        attempt = False
        if line[-1] == "?":
            line = line[:-1]
            attempt = True

        name = line[7:-1]
        line = "import " + name

        if attempt:
            line = line + "?"

    elif line.startswith("import "):
        raise RPC.Import("需要使用 \"import<>\"")

    if line.startswith("include<"):
        attempt = False
        if line[-1] == "?":
            line = line[:-1]
            attempt = True

        filename = line[8:-1]

        if filename == "stdio":
            line = "from builtins import *"
        elif filename[-1] == "!":
            filename = filename[:-1]
            content = f"""with open("{filename}", "r", encoding="utf-8") as file:
{' ' * indent}    {filename.split(".")[0]} = file.read()"""
            line = content

        else:
            try:
                with open(filename, "r", encoding="utf-8") as file:
                    lines = file.read().splitlines()
            except:
                ok = False
                for dir in os.environ["PATH"].split(os.pathsep):
                    try:
                        with open(os.path.join(dir, filename), "r", encoding="utf-8") as file:
                            lines = file.read().splitlines()
                        ok = True
                        break
                    except:
                        continue

                if not ok:
                    raise RPC.NotFiles("未找到此文件")

            if filename[-4:] == ".rpc":
                line = ""
                for code in lines:
                    line += f"{parse(code)}\n"
            else:
                line = ""
                for code in lines:
                    line += f"{code}\n"

        if attempt:
            line = line + "?"

    if line == "@static":
        line = "@staticmethod"
    elif line == "@staticmethod":
        raise RPC.NeedStatic("需要使用 \"@static\"")

    if line.endswith("++"):
        line = f"{line[:-2]} += 1"
    if line.endswith("--"):
        line = f"{line[:-2]} -= 1"
    if line.endswith("?"):
        question = True
        line = "try:\n" + " " * indent + " " * 4 + f"{line[:-1].strip()}\n" + " " * indent + "except:\n" + " " * indent + " " * 4 + "pass"
    elif "??" in line:
        result = instr(line, "??")

        if isinstance(result, list) and result:
            question = True
            first_target = result[0]

            parts = line.split("??")

            if first_target < len(parts) - 1:
                try_part = "??".join(parts[:first_target + 1])
                except_part = "??".join(parts[first_target + 1:])

                line = "try:\n" + " " * indent + " " * 4 + f"{try_part.strip()}\n" + " " * indent + f"except:\n" + " " * indent + " " * 4 + except_part.strip()

    if "|>" in line:
        result = instr(line, "|>")

        if isinstance(result, list) and result:
            if result[0] == 0:
                arrows = True
                parts = [p.strip() for p in line.split("|>")]
                result_expr = parts[0]
                for func in parts[1:]:
                    result_expr = f"{func}({result_expr})"
                line = result_expr

    if "->" in line:
        result = instr(line, "->")

        if isinstance(result, list) and result:
            if result[0] == 0 and line[-1] != ":":
                pipes = True
                line_parts = line.split("->")
                line = f"{line_parts[-1].strip()} = {'->'.join(line_parts[:-1]).strip()}"

    if arrows and pipes:
        raise RPC.Quark("\"|>\" 与 \"->\" 搭配会导致夸克粒子被切割")
    if arrows and question:
        raise RPC.Quark("\"->\" 与 \"??\" 搭配会导致夸克粒子被切割")
    if question and pipes:
        raise RPC.Quark("\"|>\" 与 \"??\" 搭配会导致夸克粒子被切割")
    if line:
        line = " " * indent + line

    return line

def help():
    version = "7.1"
    logo = r"""    ____  ____  ______
   / __ \/ __ \/ ____/
  / /_/ / /_/ / /
 / _, _/ ____/ /___
/_/ |_/_/    \____/"""
    print(logo)
    print(" " * 12 + f"[Version {version}]")
    print()
    print("\033[92m用法:\033[0m")
    print("  \033[36mcheck\033[0m - \033[93m检查RPC代码\033[0m")
    print("  \033[36mparse\033[0m - \033[93m解析RPC代码\033[0m")
    print("  \033[36mbuild\033[0m - \033[93m解析并编译RPC代码\033[0m")
    print("  \033[36mrun\033[0m   - \033[93m解析并运行RPC代码\033[0m")
    print("  \033[36mclean\033[0m - \033[93m清理build\033[0m")
    print("  \033[36mhelp\033[0m  - \033[93m显示帮助\033[0m")
    print("\033[92m参数:\033[0m")
    print("  \033[36m-f\033[0m - \033[93m快速解析\033[0m")
    print("  \033[36m-i\033[0m - \033[93m设置build可执行文件图标\033[0m")
    print("  \033[36m-g\033[0m - \033[93mbuild可执行文件不显示终端\033[0m")
    print("  \033[36m-s\033[0m - \033[93m跳过解析错误\033[0m")
    print()

def main(args=None):
    try:
        if args is None:
            args = sys.argv

        if len(args) <= 1:
            help()
            return

        try:
            if args[1] not in ["check", "parse", "build", "run", "clean"] or args[1] == "help":
                if args[1] != "help":
                    print("\033[91m错误: 没有这个参数\033[0m")

                help()

            if args[1] == "clean":
                try:
                    shutil.rmtree("dist")
                except:
                    pass
                try:
                    shutil.rmtree("build")
                except:
                    pass
                try:
                    os.remove("logo.ico")
                except:
                    pass
                return

            if args[1] in ["check", "parse", "build", "run"]:
                if os.path.exists(args[2]):
                    with open(args[2], "r", encoding="utf-8") as file:
                        codes = file.read().splitlines()
                else:
                    print("\033[91m错误: 未找到此文件\033[0m")
                    return

                if args[1] != "run":
                    print("解析代码..." if args[1] != "check" else "检查代码...", end="\r")

                global left
                global right

                left  = 0
                right = 0

                new  = []
                n    = 1
                all  = len(codes)

                global deepin
                global multiple

                multiple = False
                deepin = 0

                for code in codes:
                    try:
                        new.append(parse(code))
                    except Exception as e:
                        progress = round(n / all, 2)
                        i       = int(int(progress * 100) / 2)
                        percent = int(progress * 100)

                        if args[1] != "run":
                            print("\r", end='')
                            print("\033[K", end='')
                            print("[第" + "0" * (len(f"{all}") - len(f"{n}")) + f"{n}/{all}行] \033[91m{e}\033[0m")
                            print("\033[93m解析中\033[0m \033[91m[" + "#" * (i) +
                                "-" * int(int(100 / 2) - i) + "]\033[0m" +
                                f" ERROR", end='', flush=True
                            )
                            if not "-s" in args:
                                input()
                                return
                            else:
                                new.append(code)
                                n += 1
                                continue

                        else:
                            if not "-s" in args:
                                print(f"[第{n}行] \033[91m{e}\033[0m")
                                return
                            else:
                                new.append(code)
                                n += 1
                                continue

                    if args[1] != "run":
                        progress = round(n / all, 2)
                        i       = int(int(progress * 100) / 2)
                        percent = int(progress * 100)

                        print("\r", end='')
                        print("\033[K", end='')
                        print("[第" + "0" * (len(f"{all}") - len(f"{n}")) + f"{n}/{all}行] \033[92mOK\033[0m | {code}")
                        print("\033[93m解析中\033[0m \033[36m[" + "#" * (i) +
                            "-" * int(int(100 / 2) - i) + "]\033[0m" +
                            f" {percent}%", end= '', flush=True
                        )
                    n += 1
                    if "-f" not in args:
                        if args[1] != "run":
                            time.sleep(0.03)

                if left != right:
                    if not "-s" in args:
                        print("\r", end='')
                        print("\033[K", end='')
                        print(f"\033[91m[错误] 不匹配的大括号作用域\033[0m")
                        return

                new = ["__builtins__ = builtins"] + new
                new = ["builtins = {'__import__': __builtins__.__import__}"] + new
                new.append('if __name__ == "__main__":')
                new.append('    main()')

                if args[1] != "run":
                    print("\r\033[K", end='')

                output = args[2].replace(".rpc", ".py")
                if output == args[2]:
                    output = args[2] + ".py"

                if args[1] != "check":
                    with open(output, "w", encoding="utf-8") as file:
                        for code in new:
                            file.write(code + "\n")

                exe  = output.replace(".py", ".exe")
                spec = exe.replace(".exe", ".spec")

                old  = f"{exe}"

                exe  = exe.split("/")[-1]
                exe  = exe.split("\\")[-1]
                spec = spec.split("/")[-1]
                spec = spec.split("\\")[-1]

                if args[1] != "run":
                    if args[1] != "check":
                        print( "╭─ RPC ────────" + "─" * leng(old) + "╮")
                        print(f"│ \033[92m解析完成\033[0m \033[93m->\033[0m \033[4m{output}\033[0m  │")
                        if args[1] == "build":
                            print( "│              " + " " * leng(old) + "│")
                        print( "╰──────────────" + "─" * leng(old) + "╯")
                    else:
                        print( "╭─ RPC ────────╮")
                        print(f"│ \033[92m代码检查完成\033[0m │")
                        print( "╰──────────────╯")

            if args[1] == "run":
                os.system(f"python {output}" if os.name == "nt" else f"python3 {output}")

            if args[1] == "build":
                try:
                    DATA = "AAABAAEAYGAAAAEAIAColAAAFgAAACgAAABgAAAAwAAAAAEAIAAAAAAAAJAAABMLAAATCwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADeQ/yU3rv3YLcT/7ybF//Umxf/1JsX/9SbF//Umxf/1JsX/9SbF//Umxf/1JsX/9SbF//Umxf/1JsX/9SbF//Umxf/1JsX/9SbF//Umxf/1JsX/9SbF//Umxf/1JsX/9SbF//Umxf/1JsX/9SbF//Uzw//qM5H7VAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMJD8WiF9+vs4vv7/Pej//zLK//8fyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//zDI//8r1///J4v7+jCO+1QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAujfuZHXv6/xx6+v894f//Pur//z7q//862P//Jcf//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//MMj//yvX//8r1///LaT9/x98+f0wjvtUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOI3/EiqH+9kbefr/G3n6/yaH+/8+6v//Pur//z7q//8+6v//PuT//y/I//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8wyP//K9f//yvX//8r1///LMn+/xx5+v8ffPn9MI77VAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzkftGIoH69xt5+v8befr/G3n6/zCg/P8+6v//Pur//z7q//8+6v//Pur//z7q//830v//Isj//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//zDI//8r1///K9f//yvX//8r1///K9f//yWH+/8befr/H3z5/TCO+1QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC+N+4cdfPn+G3n6/xt5+v8befr/G3n6/zi+/v8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//POL//yvH//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//MMj//yvX//8r1///K9f//yvX//8r1///K9f//y2k/f8befr/G3n6/x98+f0wjvtUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfn/8IK4r7xxt5+v8befr/G3n6/xt5+v8befr/HHr6/z3h//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//81zv//IMn//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8wyP//K9f//yvX//8r1///K9f//yvX//8r1///K9f//yzJ/v8cefr/G3n6/xt5+v8ffPn9MI77VAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADSQ+jUkgfryG3n6/xt5+v8befr/G3n6/xt5+v8befr/Jof7/z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//PNz//yfH//8eyv//Hsr//x7K//8eyv//Hsr//x7K//8eyv//Hsr//zDI//8r1///K9f//yvX//8r1///K9f//yvX//8r1///K9f//yvX//8lh/v/G3n6/xt5+v8befr/H3z5/TCO+1QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMZD8cR98+f0befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/MKD8/z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z3o//8yyv//H8r//x7K//8eyv//Hsr//x7K//8eyv//MMj//yvX//8r1///K9f//yvX//8r1///K9f//yvX//8r1///K9f//yvX//8tpP3/G3n6/xt5+v8befr/G3n6/x98+f0wjvtUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB//wIuivy2HHr6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/OL7+/z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Otj//yXH//8eyv//Hsr//x7K//8wyP//K9f//yvX//8r1///K9f//yvX//8r1///K9f//yvX//8r1///K9f//yvX//8syf7/HHn6/xt5+v8befr/G3n6/xt5+v8ffPn9MI77VAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAN5D/JSaD+uobefr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8cevr/PeH//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7k//8vyP//Hsr//zDI//8r1///K9f//yvX//8r1///K9f//yvX//8r1///K9f//yvX//8r1///K9f//yvX//8r1///JYb7/xt5+v8befr/G3n6/xt5+v8befr/H3z5/TCO+1QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwkPxaIX36+xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8mh/v/Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//9B4v//QdT//zTU//8r1///K9f//yvX//8r1///K9f//yvX//8r1///K9f//yvX//8r1///K9f//yvX//8r1///LaP9/xt5+v8befr/G3n6/xt5+v8befr/G3n6/x98+f0wjvtUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC6L+6Mce/r/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8woPz/Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8/5///Rd7//07r//9V////UfL//z7q//9A3v//OdT//yvX//8r1///K9f//yvX//8r1///K9f//yvX//8r1///K9f//yvX//8r1///LMn+/xx5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8ffPn9MI77VAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4jf8SKof72Rt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v84vv7/Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//QuH//0vj//9T+v//Vf///1X///9V////Vf///0Dl//8+6v//Pur//0Di//881f//LdX//yvX//8r1///K9f//yvX//8r1///K9f//yvX//8r1///K9f//yWG+/8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/H3z5/TCO+1QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADOR+0Yigfr3G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xx6+v894f//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//QOT//0ff//9R8v//Vf///1X///9V////Vf///1X///9V////Vf///0Xf//8+6v//Pur//z7q//8+6v//P+X//z3W//8v1v//K9f//yvX//8r1///K9f//yvX//8r1///K9f//y2j/f8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/x98+f0wjvtUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAL437hx18+f4befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/yaH+/8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//P+j//0Tf//9M5f//Vf7//1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///0ni//8+6v//Pur//z7q//8+6v//Pur//z7q//8/5///P9f//zLU//8r1///K9f//yvX//8r1///K9f//yzJ/v8cefr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8ffPn9MI77VAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/mf9QNY/+/zKN/f8rh/z/H336/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/zCg/P8+6v//Pur//z7q//8+6v//Pur//0Hi//9J4P//U/f//1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///0/t//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z/p//9A2///NdT//yvX//8r1///K9f//yvX//8lhvv/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/H3z5/TCO+1QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zKM//81j/7/Mo7+/yyI/P8hfvr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/zi+/v8+6v//Pur//z/n//9F3v//Tuv//1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X+//8/5///Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//0De//851P//K9f//yvX//8to/3/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/x98+f0wjvtUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//Moz//zWP/v8yjv7/LIj8/yF++v8befr/HHr6/z3h//9C4f//S+P//1P6//9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9D3///Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//QOL//zzV//8vyf7/HHn6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8befr/G3n6/xt5+v8ffPn9MI77VAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8zjf//OJb+/1Dq//9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9I4P//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8/4///NJX9/zCL/f8wi/3/MIv9/zCL/f8wi/3/MIv9/zCL/f8wi/3/MIv9/zCL/f8wi/3/MIz8+gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8xiv//PZn//0PF//9P5///Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9O6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//9Cy///PZj//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//88mP//PZn//0Ci//8+6v//SOT//1X3//9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9U+///P+j//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//0Dl//8+n///Ppn//zSO//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zeR//89mf//PZn//z2Z//9A0P//Pur//0Hn//9S7P//Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////QuD//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//0G9//89mf//PZn//z2Y//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MYr//z2Z//89mf//PZn//z2Z//9BqP//Pur//z7q//8+6v//S+P//1T8//9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////R97//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Qd3//z6a//89mf//PZn//z6Z//8yjP//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//PJj//z2Z//89mf//PZn//z2Z//8+mf//P9n//z7q//8+6v//Pur//0Xl//9T8f//Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Teb//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//QK///z2Z//89mf//PZn//z2Z//86lf//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//83kf//PZn//z2Z//89mf//PZn//z2Z//89mf//Qq///z7q//8+6v//Pur//z7q//9A6P//TuX//1X+//9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Uvf//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//9C0v//PZn//z2Z//89mf//PZn//z2Z//89mv//MYn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zGK//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//Ppv//z/h//8+6v//Pur//z7q//8+6v//Pur//0bk//9U9f//Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///0Hi//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z/o//8/pf//PZn//z2Z//89mf//PZn//z2Z//89mf//OZP//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zyY//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//0K3//8+6v//Pur//z7q//8+6v//Pur//z7q//9A5///UOn//1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///0Xe//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//0HE//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//Ppj//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//N5H//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z+c//8+5///Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//0nj//9U+v//Vf///1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///0vj//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//QOL//z2b//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//zeQ//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//8xiv//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//9CwP//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//9C5v//Uu7//1X///9V////Vf///1X///9V////Vf///1X///9V////Vf///1Hy//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Qbb//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Y//8wif//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zCJ//88mP//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//9AoP//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//QOn//0zk//9V/f//Vf///1X///9V////Vf///1X///9V////Vf///1X///9A5f//Pur//z7q//8+6v//Pur//z7q//9B2f//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z6Z//80jv//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MIn//zeR//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//Qcv//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//9F5P//VPT//1X///9V////Vf///1X///9V////Vf///1X///9F3///Pur//z7q//8+6v//Pur//z7p//9Aqv//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mP//MIn//zCJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//MYr//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//QaT//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//QOn//0/n//9V////Vf///1X///9V////Vf///1X///9K4v//Pur//z7q//8+6v//Pur//0LL//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//8+mf//Moz//zCJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//8wif//PJj//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//0HV//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//9H5P//Vff//1X///9V////Vf///1X///9Q7f//Pur//z7q//8+6v//QOX//z6f//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//OpX//zCJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zCJ//83kf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//0Gr//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Qef//1Ls//9V////Vf///1X///9V/v//P+f//z7q//8+6v//Qb3//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZr//zGJ//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zGK//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z6a//8/3///Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//9L4///VPz//1X///9V////Q9///z7q//9B3f//PZr//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//zmT//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//MIn//zyY//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//9Csv//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//ReX//1Px//9V////SOD//z7q//9Ar///PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z6Y//8wif//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8wif//N5H//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//8/m///P+X//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//0Do//9O5f//Ten//0LR//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//82kf//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//8xiv//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//Qbv//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//R97//0On//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//88mP//MIn//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zCJ//88mP//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//QJ7//z/o//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8/5f//QKz//06s//9Lqf//RaH//z6a//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//8+mf//NI7//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMIn//zeR//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//0LF//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z/l//9ArP//PZn//0yn//9PrP//T6z//06r//9HpP//QZz//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZj//zCJ//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cMYr//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//0Ci//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//P+X//0Cs//89mf//PZn//0ai//9PrP//T6z//0+s//9PrP//T6z//0up//9Fof//Ppr//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//Ppn//zKM//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/lf9cPJj//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//9A0P//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8/5f//QKz//z2Z//89mf//PZn//z+b//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//Tqv//0ek//9BnP//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//zqV//8wif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBoP8zQ6D//ECc//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//9BqP//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//Pur//z/l//9ArP//PZn//z2Z//89mf//PZn//z2Z//9OrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//S6n//0Wh//8+mv//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2a//8xif//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAT6z/o0+s//9Nqv//Sab//0Wh//8/m///PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//8+mf//P9n//z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8+6v//P+X//0Cs//89mf//PZn//z2Z//89mf//PZn//z2Z//9Mp///T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Oq///R6T//0Gc//89mf//PZn//z2Z//89mf//PZn//z2Z//85k///MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE+s/+FPrP//T6z//0+s//9PrP//TKn//0ek//9Dn///Ppr//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//Qq///z7q//8+6v//Pur//z7q//8+6v//Pur//z7q//8/5f//QKz//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//9Gov//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Mqf//RqL//z6a//89mf//PZn//z2Z//8+mP//MIn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFKs/x9Pq//7T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0up//9Go///Qp7//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//Ppv//z/h//8+6v//Pur//z7q//8+6v//Pur//z/l//9ArP//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//8/m///T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//06r//9Jpv//Qp7//z2Z//89mf//NpH//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABOqP9hT6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//06r//9KqP//RqP//0Ke//8+mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//0K3//8+6v//Pur//z7q//8+6v//P+X//0Cs//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//Tqz//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0yp//9Gov//Ppn//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAT6v/vU+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Oq///Sqf//0ai//9BnP//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z+c//8+5///Pur//z7q//8/5f//QKz//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//TKf//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//TKv/8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf3//BE+r/+5PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//Tar//0mm//9Fof//P5v//z2Z//89mf//PZn//z2Z//9CwP//Pur//z/l//9ArP//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//RqL//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9OrP/+Tqj/PgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEuq/zNPrP/9T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0yp//9HpP//Q5///z6a//9AoP//P+X//z+q//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//P5v//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Oqv+WAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABOrP+CT6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Nqf//R6r//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//06s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//06s/94AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATqz/0k+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//UKz//121//9tv///T6z//0mk//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//0yn//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6v/+1en/x0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASLb/Dk6s//ZPrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Zsv//bsH//3DB//9iuP//T6z//0+s//9LqP//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//0ai//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6r/ZwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE+o/01Pq///T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//VrH//22///9wwf//cMH//3DB//9Zs///T6z//0+s//9PrP//S6j//z+Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z+b//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9OrP+/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABPrP+jT6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//1Ov//9qvf//cMH//3DB//9wwf//cMH//3DB//9Tr///T6z//0+s//9PrP//T6z//0yq//8/mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//9OrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//E/v/8IAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAT6z/4U+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Rrf//Zbr//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9PrP//T6z//0+s//9PrP//T6z//0+s//9Nq///P5v//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//9Mp///T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//kyr/0MAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUqz/H0+r//tPrP//T6z//0+s//9PrP//T6z//0+s//9PrP//Ua3//2K3//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//2y+//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//Tqv//z+b//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//9Gov//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//Tqr/lgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE6o/2FPrP//T6z//0+s//9PrP//T6z//0+s//9ctP//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//2C3//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+r//9Bnf//PZn//z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//8/m///T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Pq//jAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABPq/++T6z//0+s//9PrP//WbL//27B//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//1ix//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9OrP//Qp///z2Z//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//Tqz//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//06r//xNov8hAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/f/8ETqv/7Fax//9tv///cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//1Ku//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0Kf//89mf//PZn//z2Z//89mf//PZn//z2Z//89mf//TKf//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//1Gr/24AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYrb/anDB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9EoP//PZn//z2Z//89mf//PZn//z2Z//89mf//RqL//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//Tqz/vwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf7//BG2///xwwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//ab3//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//RaP//z2Z//89mf//PZn//z2Z//89mf//P5v//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9OrP/0Zpn/CgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGW6/9Bwwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//XrX//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0ej//89mf//PZn//z2Z//89mf//PZn//06s//9PrP//T6z//0+s//9PrP//T6z//0+s//5Mq/9DAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGK2/2pwwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//V7H//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9JpP//PZn//z2Z//89mf//PZn//0yn//9PrP//T6z//0+s//9PrP//T6z//06q/5YAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH+//wRtv//8cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//Ua7//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//S6j//z2Z//89mf//PZn//0ai//9PrP//T6z//0+s//9PrP//T6v/4wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABluv/QcMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0uo//8/mf//PZn//z+b//9PrP//T6z//0+s//9Oq//8TaL/IQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABitv9qcMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9nuv//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Mqv//P5n//z2Z//9OrP//T6z//0+s//9Rq/9uAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/v/8Ebb///HDB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9dtf//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//Tar//z+b//9Mp///T6z//06s/78AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZbr/0HDB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9Vr///T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//02s//9Ho///Tqz/9GaZ/woAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYbj/aXDB//9wwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3DB//9Rrf//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Nq//3Tqj/PgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf7//BG2///xwwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//3C///9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+r/+NNov8hAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGW6/9Bwwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//2O6//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Oq//9T6v/gwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGK2/2pwwf//cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//1uz//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+r/+NNov8hAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH+//wRtv//8cMH//3DB//9wwf//cMH//3DB//9wwf//cMH//1Ov//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Oq//9T6v/gwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABluv/QcMH//3DB//9wwf//cMH//3DB//9wwf//cMH//1Ct//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+r/+NNov8hAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABitv9qcMH//3DB//9wwf//cMH//3DB//9wwf//br///0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Oq//9T6v/gwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/v/8Ebb///HDB//9wwf//cMH//3DB//9wwf//Yrj//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+r/+NNov8hAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZbr/0HDB//9wwf//cMH//3DB//9wwf//WbP//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Oq//9T6v/gwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYrb/anDB//9wwf//cMH//3DB//9wwf//U6///0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+r/+NNov8hAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf7//BG2///xwwf//cMH//3DB//9wwf//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Oq//9T6v/gwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGW6/9Bwwf//cMH//3DB//9svv//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+r/+NNov8hAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGK2/2pwwf//cMH//3DB//9gt///T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+s//9Oq//9T6v/gwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH+//wRtv//8cMH//3DB//9Ysf//T6z//0+s//9PrP//T6z//0+s//9PrP//T6z//0+r/+NNov8hAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABluv/QcMH//3DB//9Srv//T6z//0+s//9PrP//T6z//0+s//9Oq//9T6v/gwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABht/9rcMH//3DB//9PrP//T6z//0+s//9PrP//T6z//0+r/+NNov8hAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/v/8Ebb///Gm9//9PrP//T6z//0+s//9Oq//9T6v/gwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZbr/0F61//9PrP//T6z//0+r/+NNov8hAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYbf/a1ex//9Oq//9T6v/gwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf7//BFSw/79Lqv8bAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/////////////////////////////////////////////////////AAAAA//////////+AAAAAf/////////8AAAAAP/////////wAAAAAH/////////gAAAAAD/////////AAAAAAB////////8AAAAAAA////////4AAAAAAAf///////wAAAAAAAP///////AAAAAAAAH//////+AAAAAAAAD//////8AAAAAAAAB//////4AAAAAAAAA//////gAAAAAAAAAf/////AAAAAAAAAAP////+AAAAAAAAAAH////8AAAAAAAAAAD////8AAAAAAAAAAB////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////8AAAAAAAAAAA////+AAAAAAAAAAA/////AAAAAAAAAAA/////AAAAAAAAAAA/////gAAAAAAAAAA/////wAAAAAAAAAA/////wAAAAAAAAAA/////4AAAAAAAAAB/////8AAAAAAAAAD/////+AAAAAAAAAD/////+AAAAAAAAAH//////AAAAAAAAAP//////gAAAAAAAAP//////wAAAAAAAAf//////wAAAAAAAA///////4AAAAAAAB///////8AAAAAAAB///////8AAAAAAAD///////+AAAAAAAH///////+AAAAAAAH////////AAAAAAAP////////AAAAAAAf////////AAAAAAA/////////gAAAAAA/////////gAAAAAB/////////gAAAAAD/////////wAAAAAD/////////wAAAAAH/////////wAAAAAP/////////4AAAAA//////////4AAAAB//////////4AAAAH//////////8AAAAP//////////8AAAA///////////8AAAB///////////+AAAH///////////+AAAP///////////+AAA/////////////AAB/////////////AAH/////////////AAP/////////////gA//////////////gB//////////////gH//////////////wP//////////////w///////////////x/////////////////////////////////////////////////////////8="
                    with open("logo.ico", "wb") as f:
                        f.write(base64.b64decode(DATA))

                    n = 0
                    appear = 0
                    for i in args:
                        if i == "-i":
                            appear += 1
                            try:
                                icon = args[n+1]
                            except:
                                print("\033[F", end='')
                                print("\033[F", end='')
                                print(f"│ \033[91m编译失败\033[0m")
                                print( "╰──────────────" + "─" * leng(old) + "╯")
                                print(f"\033[91m[错误] \"-i\"参数需要一个.ico文件\033[0m")
                                return
                        n += 1
                    if appear > 1:
                        print("\033[F", end='')
                        print("\033[F", end='')
                        print(f"│ \033[91m编译失败\033[0m")
                        print( "╰──────────────" + "─" * leng(old) + "╯")
                        print(f"\033[91m[错误] 不能有两个 \"-i\"参数\033[0m")
                        return

                    if appear == 1:
                        process = subprocess.Popen(
                            f'pyinstaller {output} --onefile --icon={icon}' +
                            (" --noconsole" if "-g" in args else ""),
                            shell=True,
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL
                        )
                    else:
                        process = subprocess.Popen(
                            f'pyinstaller {output} --onefile --icon=logo.ico' +
                            (" --noconsole" if "-g" in args else ""),
                            shell=True,
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL
                        )

                    n = 0

                    print("\033[F", end='')
                    print("\033[F", end='')

                    while True:
                        try:
                            bar   = ["|", "/", "-", "\\"]
                            order = [0, 1, 2, 3]
                            if n >= len(order):
                                n = 0

                            print("│ \033[93m编译中\033[0m \033[36m" + bar[order[n]] + "\033[0m", end='\r', flush=True)

                            result = process.poll()
                            if result is not None:
                                if result != 0:
                                    print(f"│ \033[91m编译失败\033[0m")
                                    print( "╰──────────────" + "─" * leng(old) + "╯")
                                else:
                                    print(f"│ \033[92m编译完成\033[0m \033[93m->\033[0m \033[4m{old}\033[0m")
                                    print( "╰──────────────" + "─" * leng(old) + "╯")
                                try:
                                    shutil.move(f"dist/{exe}", old)
                                except:
                                    pass
                                try:
                                    shutil.rmtree("dist")
                                except:
                                    pass
                                try:
                                    shutil.rmtree("build")
                                except:
                                    pass
                                try:
                                    os.remove("logo.ico")
                                except:
                                    pass
                                try:
                                    os.remove(spec)
                                except:
                                    pass
                                return

                            n += 1
                            time.sleep(0.5)
                        except KeyboardInterrupt:
                            print()
                            print()
                            exit()

                except Exception as e:
                    print(f"\033[91m[错误] 编译失败: {e}\033[0m")
                finally:
                    try:
                        shutil.rmtree("dist")
                    except:
                        pass
                    try:
                        shutil.rmtree("build")
                    except:
                        pass
                    try:
                        os.remove("logo.ico")
                    except:
                        pass
                    try:
                        os.remove(spec)
                    except:
                        pass
        except Exception as e:
            print(f"\033[91m[错误] {e}\033[0m")
    except KeyboardInterrupt:
        exit()
    except Exception as e:
        print(f"\033[91m[错误] {e}\033[0m")

if __name__ == "__main__":
    try:
        main(sys.argv)
    except KeyboardInterrupt:
        exit()
    except Exception as e:
        print(f"\033[91m[错误] {e}\033[0m")
