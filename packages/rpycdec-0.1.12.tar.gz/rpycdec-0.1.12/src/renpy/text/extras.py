class ParameterizedText(object):
    pass
