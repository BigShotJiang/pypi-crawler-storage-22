"""Integration tests for GitHub MCP server.

These tests make real API calls to GitHub and require a valid GITHUB_TOKEN.
"""
