"""RRQ client for enqueuing jobs via the Rust producer FFI."""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any

from .job import JobResult, JobStatus
from .producer_ffi import (
    JobResultModel,
    JobStatusResponseModel,
    RustProducer,
    RustProducerError,
    get_producer_constants,
)


def _normalize_datetime(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    else:
        value = value.astimezone(timezone.utc)
    return value.isoformat()


def _normalize_queue_name(value: str) -> str:
    if not value.strip():
        raise ValueError("queue_name cannot be blank")
    prefix = get_producer_constants().queue_key_prefix
    if value.startswith(prefix):
        return value
    return f"{prefix}{value}"


def _to_job_result(payload: JobResultModel) -> JobResult:
    try:
        status = JobStatus(payload.status)
    except ValueError:
        status = JobStatus.UNKNOWN
    return JobResult(
        status=status,
        result=payload.result,
        last_error=payload.last_error,
    )


class RRQClient:
    """Thin async wrapper around the Rust producer FFI."""

    def __init__(
        self,
        *,
        config: dict[str, Any] | None = None,
        config_path: str | None = None,
    ) -> None:
        if config is not None and config_path is not None:
            raise ValueError("Provide either config or config_path, not both.")
        if config is not None:
            normalized_config = dict(config)
            queue_name = normalized_config.get("queue_name")
            if isinstance(queue_name, str):
                normalized_config["queue_name"] = _normalize_queue_name(queue_name)
            self._producer = RustProducer.from_config(normalized_config)
        else:
            self._producer = RustProducer.from_toml(config_path)

    async def close(self) -> None:
        self._producer.close()

    async def enqueue(
        self,
        function_name: str,
        options: dict[str, Any] | None = None,
    ) -> str:
        options = dict(options) if options else {}
        params = dict(options.pop("params", {}))

        defer_until = options.get("defer_until")
        if isinstance(defer_until, datetime):
            options["defer_until"] = _normalize_datetime(defer_until)
        queue_name = options.get("queue_name")
        if isinstance(queue_name, str):
            options["queue_name"] = _normalize_queue_name(queue_name)

        request = {
            "function_name": function_name,
            "params": params,
            "options": options,
        }

        try:
            response = await asyncio.to_thread(self._producer.enqueue, request)
        except RustProducerError as exc:
            raise ValueError(str(exc)) from exc

        job_id = response.get("job_id")
        if not job_id:
            raise ValueError("Producer did not return a job_id")
        return job_id

    async def enqueue_with_unique_key(
        self,
        function_name: str,
        unique_key: str,
        options: dict[str, Any] | None = None,
    ) -> str:
        merged = dict(options or {})
        merged["unique_key"] = unique_key
        return await self.enqueue(function_name, merged)

    async def enqueue_with_rate_limit(
        self,
        function_name: str,
        options: dict[str, Any],
    ) -> str | None:
        merged = dict(options)
        request = {
            "function_name": function_name,
            "params": dict(merged.pop("params", {})),
            "options": merged,
            "mode": "rate_limit",
        }
        try:
            response = await asyncio.to_thread(self._producer.enqueue, request)
        except RustProducerError as exc:
            raise ValueError(str(exc)) from exc
        return response.get("job_id")

    async def enqueue_with_debounce(
        self,
        function_name: str,
        options: dict[str, Any],
    ) -> str:
        merged = dict(options)
        request = {
            "function_name": function_name,
            "params": dict(merged.pop("params", {})),
            "options": merged,
            "mode": "debounce",
        }
        try:
            response = await asyncio.to_thread(self._producer.enqueue, request)
        except RustProducerError as exc:
            raise ValueError(str(exc)) from exc
        job_id = response.get("job_id")
        if not job_id:
            raise ValueError("Producer did not return a job_id")
        return job_id

    async def enqueue_deferred(
        self,
        function_name: str,
        options: dict[str, Any],
    ) -> str:
        return await self.enqueue(function_name, options)

    async def get_job_status(self, job_id: str) -> JobResult | None:
        try:
            response: JobStatusResponseModel = await asyncio.to_thread(
                self._producer.get_job_status, job_id
            )
        except RustProducerError as exc:
            raise ValueError(str(exc)) from exc

        if not response.found or response.job is None:
            return None
        return _to_job_result(response.job)
