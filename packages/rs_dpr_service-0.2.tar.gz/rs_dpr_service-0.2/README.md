# rs-dpr-service
A service responsible for triggering the DPR processor execution within the Dask cluster.
