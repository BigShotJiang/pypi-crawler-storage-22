RS-Server AUXIP service
