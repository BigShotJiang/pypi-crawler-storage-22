RS-Server CADIP service
