RS-Server STAC Catalog
