RS-Server commons services
