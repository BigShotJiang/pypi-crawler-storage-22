RS-Server EDRS service
