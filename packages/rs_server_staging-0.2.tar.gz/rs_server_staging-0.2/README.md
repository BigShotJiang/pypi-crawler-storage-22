RS-Server staging service
