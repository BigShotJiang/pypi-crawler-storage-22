"""Internal module for the `rshogi` migration shim.

This distribution intentionally does NOT provide the `rshogi` import.
It only depends on `rshogi-py`, which provides `import rshogi`.
"""

__all__: list[str] = []

