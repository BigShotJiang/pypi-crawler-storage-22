from .rshogi import *

__doc__ = rshogi.__doc__
if hasattr(rshogi, "__all__"):
    __all__ = rshogi.__all__