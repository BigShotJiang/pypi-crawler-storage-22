# rshogi-py

Python bindings for the `rshogi` Rust crate.

This package provides the standard build of the `rshogi` Python module.
If you want an AVX2-optimized build, use
[`rshogi-py-avx2`](https://pypi.org/project/rshogi-py-avx2/).

## Development Install

```bash
python -m pip install maturin
maturin develop -m crates/rshogi-py/pyproject.toml
```

## AVX2 Build

`rshogi-py-avx2` is an AVX2-enabled build of the same Python module.

```bash
python -m pip install rshogi-py-avx2
```

## Notes

- `rshogi-py` and `rshogi-py-avx2` are mutually exclusive; install only one.
- `rshogi-py` is the safest default for broad compatibility.

## Quick Example

```python
from rshogi.core import Board

board = Board()
board.apply_usi("7g7f")
print(board.to_sfen())
```

USI の `position` 文字列を直接扱うこともできます。

```python
from rshogi.core import Board, normalize_usi_position, parse_usi_position

board = Board()
board.set_usi_position("position startpos moves 7g7f 3c3d")

board2 = parse_usi_position("startpos moves 7g7f")
print(board2.to_sfen())

print(normalize_usi_position("position startpos"))  # "startpos"
```

## Structured Imports

`rshogi` provides structured imports through submodules for better organization:

```python
# Types and constants
from rshogi.types import Color, PieceType, Square
from rshogi.core import Move, Move32

# Board
from rshogi.core import Board

# Records
from rshogi.record import GameRecord, GameRecordMetadata, GameResult

# Record conversion
record = GameRecord.from_kif_str(kif_text)
kif_text = record.to_kif()

# Record file I/O
record = GameRecord.from_kif_file("example.kif")
record.write_kif("example_out.kif")

# NumPy dtypes
from rshogi.numpy import PackedSfen, PackedSfenValue
```

Use submodules for all imports:

```python
from rshogi.core import Board
from rshogi.core import Move
from rshogi.record import GameRecord
```
