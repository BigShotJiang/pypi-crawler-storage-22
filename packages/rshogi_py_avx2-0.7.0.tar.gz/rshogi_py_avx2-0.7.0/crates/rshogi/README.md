# rshogi

Rust で実装された将棋ライブラリです。[YaneuraOu](https://github.com/yaneurao/YaneuraOu) の
Rust 版を目指し、高速かつ安全な将棋プリミティブを提供します。

Python バインディング ([rshogi-py](https://pypi.org/project/rshogi-py/)) も提供しています。

## 設計思想

### 1. 安全性優先

- パフォーマンス上必要な箇所に限り `unsafe` を使用し、SAFETY コメントとテストで妥当性を担保
- コンパイル時に検出可能なエラーは型システムで表現
- 実行時エラーは `Result` 型で明示的に扱う

### 2. 正確性

- YaneuraOu の合法手生成との互換性テストで正確性を担保
- Perft テストによる手生成の網羅的検証
- 千日手・入玉宣言勝ちなど将棋固有のルールを正しく実装

### 3. パフォーマンス

- ビットボードによる高速な盤面表現
- Magic Bitboard / PEXT による効率的なスライダー攻撃計算
- 差分更新による Zobrist ハッシュ計算
- SIMD 最適化（AVX2 対応）

### 4. 再利用性

- Rust と Python の両方から利用可能
- エンジンや評価関数とは分離し、純粋な局面管理に専念
- 明確な API 境界でダウンストリームプロジェクトに組み込みやすい

## アーキテクチャ

```text
rshogi
├── types     - 基本型（Color, Square, Move, Bitboard, Hand, ...）
├── board     - 盤面管理と合法手生成
│   ├── Position      - 盤面状態の管理
│   ├── movegen       - 合法手生成
│   ├── attack_tables - 利きテーブル
│   └── ...
├── records   - 棋譜フォーマット（KIF, CSA, JKF, SFEN, sbinpack, ...）
├── book      - 定跡管理（MemoryBook, StaticBook）
└── mate      - 詰み判定（1手詰め）
```

## クイックスタート

### 盤面操作

```rust
use rshogi::board::{self, Position};
use rshogi::types::Move;

// 初期化（プログラム起動時に1回）
board::init();

// 平手初期局面
let mut pos = board::hirate_position();

// SFEN から局面を構築
let mut pos = board::position_from_sfen(
    "lnsgkgsnl/1r5b1/ppppppppp/9/9/9/PPPPPPPPP/1B5R1/LNSGKGSNL b - 1"
).unwrap();

// 指し手の適用
let mv16 = Move::from_usi("7g7f").unwrap();
let m = pos.move32_from_move(mv16);
pos.apply_move32(m);

// 指し手の取り消し
pos.undo_move32(m);

// SFEN 出力
println!("{}", pos.to_sfen(None));
```

### 合法手生成

```rust
use rshogi::board::{self, Position, MoveList};
use rshogi::movegen::{Legal, generate_moves};

board::init();
let pos = board::hirate_position();

// 合法手を生成
let mut moves = MoveList::new();
generate_moves::<Legal>(&pos, &mut moves);

for m in moves.iter() {
    println!("{}", m.to_usi());
}

// 合法手の数
println!("合法手数: {}", moves.len());
```

### 棋譜の読み込み

```rust
use rshogi::records::formats::kif;
use rshogi::types::GameResult;

let kif_text = r#"
手合割：平手
手数----指手---------消費時間--
   1 ７六歩(77)
   2 ３四歩(33)
まで2手で中断
"#;

let record = kif::parse_kif_str(kif_text).unwrap();
println!("手数: {}", record.move_count());
println!("結果: {:?}", record.result());
assert_eq!(record.result(), GameResult::Paused);
assert!(record.main_terminal().is_some());
```

### 定跡の利用

```rust
use rshogi::board::{self, Position};
use rshogi::book::{Book, MemoryBook, BookBuilder, book_key_from_position};

board::init();
let pos = board::hirate_position();

// 定跡を構築（GameRecord から）
let mut builder = BookBuilder::default();
// builder.add_record(&record);
let book = builder.into_memory();

// 定跡を検索
let key = book_key_from_position(&pos);
if let Some(entry) = book.get(key) {
    for mv in entry.moves() {
        println!("{}: {}", mv.mv().to_usi(), mv.score());
    }
}
```

## モジュール詳細

### `types` - 基本型

将棋で使用する基本的な型を定義します。

| 型 | 説明 |
|---|---|
| `Color` | 手番（先手 `BLACK` / 後手 `WHITE`） |
| `Square` | マス（0-80、9x9 盤面） |
| `File` | 筋（1-9） |
| `Rank` | 段（一-九） |
| `PieceType` | 駒種（歩、香、桂、銀、金、角、飛、玉、と、... ） |
| `Piece` | 駒（駒種 + 手番） |
| `Hand` | 持ち駒（各駒種の枚数をビットパック） |
| `Move32` | 32bit 指し手（移動元・移動先・成り・駒打ちなど） |
| `Move` | 16bit 指し手（コンパクト版） |
| `Bitboard` | 81bit ビットボード |
| `GameResult` | 対局結果（勝敗、千日手、入玉宣言など） |

### `board` - 盤面管理

`Position` 構造体で盤面状態を管理します。

**主要メソッド:**

| メソッド | 説明 |
|---|---|
| `apply_move32(m)` | 指し手を適用（Move32） |
| `undo_move32(m)` | 指し手を取り消し（Move32） |
| `is_legal_move32(m)` | 合法手か判定（Move32） |
| `checkers()` | 王手している駒のビットボード |
| `check_squares(pt)` | 指定駒種で王手可能な候補マス（キャッシュ） |
| `blockers_for_king(color)` | 玉を守るブロッカー（pin候補を含む） |
| `is_in_check()` | 王手されているか |
| `is_mated()` | 詰んでいるか |
| `to_sfen(ply)` | SFEN 文字列を生成 |
| `board_key()` | 盤上配置 + 手番の Zobrist キー |
| `board_key_after(m)` | 指し手適用後の `board_key` を計算 |
| `key()` | Zobrist ハッシュキー |

### `board::movegen` - 合法手生成

ジェネリクスによる型安全な手生成 API を提供します。

```rust
use rshogi::board::{self, MoveList};
use rshogi::movegen::{generate_moves, Legal, Captures, Evasions};

board::init();
let pos = board::hirate_position();
let mut moves = MoveList::new();

// 全合法手
generate_moves::<Legal>(&pos, &mut moves);

// 駒を取る手のみ
generate_moves::<Captures>(&pos, &mut moves);

// 王手回避手（王手されている場合）
generate_moves::<Evasions>(&pos, &mut moves);
```

`Move32`（駒情報付き 32bit 指し手）のリストを直接生成することもできます。

```rust
use rshogi::board::{self, Move32List};
use rshogi::movegen::generate_legal_all_move32;

board::init();
let pos = board::hirate_position();

let mut moves = Move32List::new();
generate_legal_all_move32(&pos, &mut moves);
```

**手生成タイプ:**

| タイプ | 説明 |
|---|---|
| `Legal` | 全合法手 |
| `Captures` | 駒を取る手 |
| `Quiets` | 駒を取らない手 |
| `Evasions` | 王手回避手 |
| `Checks` | 王手をかける手 |
| `Recaptures` | 取り返し手 |

### `board::attack_tables` - 利き/王手候補テーブル

低レベル API として、王手候補マスの取得関数を提供します。

```rust
use rshogi::board::{self, check_candidate_bb};
use rshogi::types::{Color, PieceType, Square};

board::init();
let king_sq = Square::from_usi("5a").unwrap();
let candidates = check_candidate_bb(Color::BLACK, PieceType::ROOK, king_sq);
assert!(candidates.count() > 0);
```

### `records` - 棋譜フォーマット

複数の棋譜フォーマットの読み書きをサポートします。

| フォーマット | パース | 出力 |
|---|:---:|:---:|
| KIF | ○ | ○ |
| KI2 | ○ | ○ |
| CSA | ○ | ○ |
| JKF | - | ○ |
| SFEN | ○ | ○ |
| SBINPACK | ○ | ○ |

`GameRecord` の終局情報は `result() -> GameResult` で取得します。\
終局行そのもの（投了・千日手・最大手数などの種別、終局コメント、終局消費時間）は
`main_terminal() -> Option<&SpecialMoveRecord>` に保持されます。

各指し手のエンジン解析情報は `MoveEngineInfo` 構造体で管理されます。
評価値・探索深度・ノード数のほか、`extras` フィールドで任意のキー/値ペア
（`MoveEngineExtraValue`: String / Int / Float / Bool）を保持できます。

### `book` - 定跡

Zobrist ハッシュによる高速な定跡検索を提供します。

- `MemoryBook`: メモリ内で定跡を管理
- `StaticBook`: 静的にコンパイルされた定跡
- `BookBuilder`: `GameRecord` から定跡を構築

### `mate` - 詰み判定

テーブル駆動の 1 手詰め判定ルーチンを提供します。

- `solve_mate_in_one()`: 1手詰め判定

## 互換性

### YaneuraOu 互換

- 内部のビットボード表現、Zobrist ハッシュ、手のエンコーディングは YaneuraOu と互換
- `Move`（16bit）は YaneuraOu の `Move16` と同一のビットレイアウト
- Perft 結果が YaneuraOu と一致することを検証済み

## ベンチマーク（perft）

80 局面で perft（depth=4）を計測した参考値です。

### 実行方法

```bash
RUSTFLAGS="-C target-feature=+avx2" \
  scripts/bench_perft_avg.sh --depth 4 --repeat 5
```

### 参考結果

x86_64 / AVX2 環境、PGO なし、5 回平均の結果です。

| エンジン | avg NPS |
|---|---|
| rshogi (AVX2) | 約 248M |
| YaneuraOu MATERIAL (AVX2) | 約 289M |

詳細は [`BENCHMARK_RESULTS.md`](../../BENCHMARK_RESULTS.md) を参照してください。

結果はハードウェアや OS によって変動します。

## ライセンス

MIT License
