use crate::board::{Bitboard, Position};
use crate::types::{File, Piece, PieceType, Square, SQ_D, SQ_U};

use super::promotions::must_promote;
use super::types::MoveGenType;
use super::{ColorMarker, MoveSink};

#[inline]
fn push_move(list: &mut impl MoveSink, from: Square, to: Square, piece: Piece) {
    list.push_normal(from, to, piece);
}

#[inline]
fn push_promote(list: &mut impl MoveSink, from: Square, to: Square, piece: Piece) {
    list.push_promotion(from, to, piece);
}

/// 歩の移動手を生成
fn pawn_bb_effect<C: ColorMarker>(pawns: Bitboard) -> Bitboard {
    let mut out = Bitboard::EMPTY;
    for file_idx in 0..9 {
        let file = File::new(file_idx);
        let file_mask = Bitboard::file_mask(file);
        let file_bits = pawns & file_mask;
        if file_bits.is_empty() {
            continue;
        }
        let mask_bits = file_mask.packed_bits();
        let shifted =
            if C::IS_BLACK { file_bits.packed_bits() >> 1 } else { file_bits.packed_bits() << 1 };
        out |= Bitboard::from_packed_bits(shifted & mask_bits);
    }
    out
}

/// 歩の移動手を生成
#[allow(clippy::extra_unused_type_parameters)]
pub(super) fn generate_pawn_moves<T: MoveGenType, C: ColorMarker>(
    pos: &Position,
    list: &mut impl MoveSink,
    target: Bitboard,
) {
    let bb = pos.bitboards();
    let us = C::COLOR;
    let allow_underpromote = T::generate_all_legal();
    let pawns = bb.pieces_for(PieceType::PAWN, us);
    let mut destinations = pawn_bb_effect::<C>(pawns).and(target);
    let piece = Piece::from_parts(us, PieceType::PAWN);

    if C::IS_BLACK {
        while let Some(to) = destinations.pop_lsb() {
            let from = Square::new(to.raw() + SQ_D);
            let to_rank = to.rank().raw();
            if to_rank == 0 {
                push_promote(list, from, to, piece);
                continue;
            }

            let can_promote = from.rank().raw() <= 2 || to_rank <= 2;
            if can_promote {
                push_promote(list, from, to, piece);
            }
            if allow_underpromote || !can_promote {
                push_move(list, from, to, piece);
            }
        }
    } else {
        while let Some(to) = destinations.pop_lsb() {
            let from = Square::new(to.raw() + SQ_U);
            let to_rank = to.rank().raw();
            if to_rank == 8 {
                push_promote(list, from, to, piece);
                continue;
            }

            let can_promote = from.rank().raw() >= 6 || to_rank >= 6;
            if can_promote {
                push_promote(list, from, to, piece);
            }
            if allow_underpromote || !can_promote {
                push_move(list, from, to, piece);
            }
        }
    }
}

/// 桂馬の移動手を生成
#[allow(clippy::extra_unused_type_parameters)]
pub(super) fn generate_knight_moves<T: MoveGenType, C: ColorMarker>(
    pos: &Position,
    list: &mut impl MoveSink,
    target: Bitboard,
) {
    use crate::board::attack_tables::knight_attacks_unchecked;

    let us = C::COLOR;
    let bb = pos.bitboards();
    let mut knights = bb.pieces_for(PieceType::KNIGHT, us);
    let piece = Piece::from_parts(us, PieceType::KNIGHT);

    while let Some(from) = knights.pop_lsb() {
        let from_rank = from.raw() % 9;
        let attacks = knight_attacks_unchecked(from, us);
        let mut destinations = attacks.and(target);

        while let Some(to) = destinations.pop_lsb() {
            let to_rank = to.raw() % 9;
            let must_promote = if C::IS_BLACK { to_rank <= 1 } else { to_rank >= 7 };
            if must_promote {
                push_promote(list, from, to, piece);
                continue;
            }

            let can_promote = if C::IS_BLACK {
                from_rank <= 2 || to_rank <= 2
            } else {
                from_rank >= 6 || to_rank >= 6
            };
            if can_promote {
                push_promote(list, from, to, piece);
            }
            push_move(list, from, to, piece);
        }
    }
}

/// 銀の移動手を生成
#[allow(clippy::extra_unused_type_parameters)]
pub(super) fn generate_silver_moves<T: MoveGenType, C: ColorMarker>(
    pos: &Position,
    list: &mut impl MoveSink,
    target: Bitboard,
) {
    use crate::board::attack_tables::silver_attacks_unchecked;

    let us = C::COLOR;
    let bb = pos.bitboards();
    let mut silvers = bb.pieces_for(PieceType::SILVER, us);
    let piece = Piece::from_parts(us, PieceType::SILVER);
    let enemy_territory = Bitboard::promotion_zone(us);

    while let Some(from) = silvers.pop_lsb() {
        let attacks = silver_attacks_unchecked(from, us);
        let destinations = attacks.and(target);
        if enemy_territory.test(from) {
            let mut squares = destinations;
            while let Some(to) = squares.pop_lsb() {
                push_promote(list, from, to, piece);
                push_move(list, from, to, piece);
            }
            continue;
        }

        let mut promotions = destinations.and(enemy_territory);
        while let Some(to) = promotions.pop_lsb() {
            push_promote(list, from, to, piece);
            push_move(list, from, to, piece);
        }

        let mut non_promotions = destinations.and_not(enemy_territory);
        while let Some(to) = non_promotions.pop_lsb() {
            push_move(list, from, to, piece);
        }
    }
}

/// 金相当 + 馬/龍 + 玉の移動手を生成
#[allow(clippy::extra_unused_type_parameters)]
pub(super) fn generate_gold_hdk_moves<T: MoveGenType, C: ColorMarker>(
    pos: &Position,
    list: &mut impl MoveSink,
    target: Bitboard,
    occupied: Bitboard,
) {
    use crate::board::attack_tables::{
        bishop_attacks, gold_attacks_unchecked, king_attacks_unchecked, rook_attacks,
    };

    let us = C::COLOR;
    let bb = pos.bitboards();
    let color_mask = bb.color_pieces(us);

    // 金相当（金/と金/成香/成桂/成銀）
    // golds BB は複数駒種を含むため、from ごとに piece_on で Piece を取得し push_normal で渡す。
    let mut golds = bb.golds() & color_mask;
    while let Some(from) = golds.pop_lsb() {
        let piece = pos.piece_on(from);
        let attacks = gold_attacks_unchecked(from, us);
        let mut destinations = attacks.and(target);
        while let Some(to) = destinations.pop_lsb() {
            push_move(list, from, to, piece);
        }
    }

    // 玉
    let king_piece = Piece::from_parts(us, PieceType::KING);
    let mut kings = bb.pieces_for(PieceType::KING, us);
    while let Some(from) = kings.pop_lsb() {
        let attacks = king_attacks_unchecked(from);
        let mut destinations = attacks.and(target);
        while let Some(to) = destinations.pop_lsb() {
            push_move(list, from, to, king_piece);
        }
    }

    // 馬
    let horse_piece = Piece::from_parts(us, PieceType::HORSE);
    let mut horses = bb.pieces_for(PieceType::HORSE, us);
    while let Some(from) = horses.pop_lsb() {
        let bishop_moves = bishop_attacks(from, occupied);
        let king_moves = king_attacks_unchecked(from);
        let attacks = bishop_moves.or(king_moves.and_not(bishop_moves));
        let mut destinations = attacks.and(target);
        while let Some(to) = destinations.pop_lsb() {
            push_move(list, from, to, horse_piece);
        }
    }

    // 龍
    let dragon_piece = Piece::from_parts(us, PieceType::DRAGON);
    let mut dragons = bb.pieces_for(PieceType::DRAGON, us);
    while let Some(from) = dragons.pop_lsb() {
        let rook_moves = rook_attacks(from, occupied);
        let king_moves = king_attacks_unchecked(from);
        let attacks = rook_moves.or(king_moves.and_not(rook_moves));
        let mut destinations = attacks.and(target);
        while let Some(to) = destinations.pop_lsb() {
            push_move(list, from, to, dragon_piece);
        }
    }
}

/// 金相当 + 馬/龍の移動手を生成（玉は除外）
#[allow(clippy::extra_unused_type_parameters)]
pub(super) fn generate_gold_hd_moves<T: MoveGenType, C: ColorMarker>(
    pos: &Position,
    list: &mut impl MoveSink,
    target: Bitboard,
    occupied: Bitboard,
) {
    use crate::board::attack_tables::{
        bishop_attacks, gold_attacks_unchecked, king_attacks_unchecked, rook_attacks,
    };

    let us = C::COLOR;
    let bb = pos.bitboards();
    let color_mask = bb.color_pieces(us);

    // 金相当（from ごとに piece_on で Piece を取得し push_normal で渡す）
    let mut golds = bb.golds() & color_mask;
    while let Some(from) = golds.pop_lsb() {
        let piece = pos.piece_on(from);
        let attacks = gold_attacks_unchecked(from, us);
        let mut destinations = attacks.and(target);
        while let Some(to) = destinations.pop_lsb() {
            push_move(list, from, to, piece);
        }
    }

    // 馬
    let horse_piece = Piece::from_parts(us, PieceType::HORSE);
    let mut horses = bb.pieces_for(PieceType::HORSE, us);
    while let Some(from) = horses.pop_lsb() {
        let bishop_moves = bishop_attacks(from, occupied);
        let king_moves = king_attacks_unchecked(from);
        let attacks = bishop_moves.or(king_moves.and_not(bishop_moves));
        let mut destinations = attacks.and(target);
        while let Some(to) = destinations.pop_lsb() {
            push_move(list, from, to, horse_piece);
        }
    }

    // 龍
    let dragon_piece = Piece::from_parts(us, PieceType::DRAGON);
    let mut dragons = bb.pieces_for(PieceType::DRAGON, us);
    while let Some(from) = dragons.pop_lsb() {
        let rook_moves = rook_attacks(from, occupied);
        let king_moves = king_attacks_unchecked(from);
        let attacks = rook_moves.or(king_moves.and_not(rook_moves));
        let mut destinations = attacks.and(target);
        while let Some(to) = destinations.pop_lsb() {
            push_move(list, from, to, dragon_piece);
        }
    }
}

/// 香車の移動手を生成
#[allow(clippy::extra_unused_type_parameters)]
pub(super) fn generate_lance_moves<T: MoveGenType, C: ColorMarker>(
    pos: &Position,
    list: &mut impl MoveSink,
    target: Bitboard,
    occupied: Bitboard,
) {
    use crate::board::attack_tables::lance_attacks;
    use crate::types::Rank;

    let us = C::COLOR;
    let bb = pos.bitboards();
    let mut lances = bb.pieces_for(PieceType::LANCE, us);
    let allow_underpromote = T::generate_all_legal();
    let enemy_territory = Bitboard::promotion_zone(us);
    let non_promote_mask = if allow_underpromote {
        if C::IS_BLACK {
            Bitboard::ALL.and_not(Bitboard::rank_mask(Rank::RANK_1))
        } else {
            Bitboard::ALL.and_not(Bitboard::rank_mask(Rank::RANK_9))
        }
    } else if C::IS_BLACK {
        Bitboard::ALL
            .and_not(Bitboard::rank_mask(Rank::RANK_1))
            .and_not(Bitboard::rank_mask(Rank::RANK_2))
    } else {
        Bitboard::ALL
            .and_not(Bitboard::rank_mask(Rank::RANK_8))
            .and_not(Bitboard::rank_mask(Rank::RANK_9))
    };

    let piece = Piece::from_parts(us, PieceType::LANCE);

    while let Some(from) = lances.pop_lsb() {
        let attacks = lance_attacks(from, occupied, us);
        let destinations = attacks.and(target);

        let mut promotions = destinations.and(enemy_territory);
        while let Some(to) = promotions.pop_lsb() {
            push_promote(list, from, to, piece);
        }

        let mut non_promotions = destinations.and(non_promote_mask);
        while let Some(to) = non_promotions.pop_lsb() {
            if must_promote(PieceType::LANCE, to, us) {
                continue;
            }
            push_move(list, from, to, piece);
        }
    }
}

/// 角・飛車の移動手を生成
#[allow(clippy::extra_unused_type_parameters)]
pub(super) fn generate_br_moves<T: MoveGenType + 'static, C: ColorMarker>(
    pos: &Position,
    list: &mut impl MoveSink,
    target: Bitboard,
    occupied: Bitboard,
) {
    use crate::board::attack_tables::{bishop_attacks, rook_attacks};

    let us = C::COLOR;
    let bb = pos.bitboards();
    let allow_underpromote = T::generate_all_legal();
    let enemy_territory = Bitboard::promotion_zone(us);

    // 角と飛車を分けて回すことで `piece_on()` と分岐を避ける（ホットパス）。
    let bishop_piece = Piece::from_parts(us, PieceType::BISHOP);
    let mut bishops = bb.pieces_for(PieceType::BISHOP, us);
    while let Some(from) = bishops.pop_lsb() {
        let attacks = bishop_attacks(from, occupied);
        let destinations = attacks.and(target);
        let from_in_enemy = enemy_territory.test(from);

        if from_in_enemy {
            let mut squares = destinations;
            while let Some(to) = squares.pop_lsb() {
                push_promote(list, from, to, bishop_piece);
                if allow_underpromote {
                    push_move(list, from, to, bishop_piece);
                }
            }
            continue;
        }

        let mut promotions = destinations.and(enemy_territory);
        while let Some(to) = promotions.pop_lsb() {
            push_promote(list, from, to, bishop_piece);
            if allow_underpromote {
                push_move(list, from, to, bishop_piece);
            }
        }

        let mut non_promotions = destinations.and_not(enemy_territory);
        while let Some(to) = non_promotions.pop_lsb() {
            push_move(list, from, to, bishop_piece);
        }
    }

    let rook_piece = Piece::from_parts(us, PieceType::ROOK);
    let mut rooks = bb.pieces_for(PieceType::ROOK, us);
    while let Some(from) = rooks.pop_lsb() {
        let attacks = rook_attacks(from, occupied);
        let destinations = attacks.and(target);
        let from_in_enemy = enemy_territory.test(from);

        if from_in_enemy {
            let mut squares = destinations;
            while let Some(to) = squares.pop_lsb() {
                push_promote(list, from, to, rook_piece);
                if allow_underpromote {
                    push_move(list, from, to, rook_piece);
                }
            }
            continue;
        }

        let mut promotions = destinations.and(enemy_territory);
        while let Some(to) = promotions.pop_lsb() {
            push_promote(list, from, to, rook_piece);
            if allow_underpromote {
                push_move(list, from, to, rook_piece);
            }
        }

        let mut non_promotions = destinations.and_not(enemy_territory);
        while let Some(to) = non_promotions.pop_lsb() {
            push_move(list, from, to, rook_piece);
        }
    }
}
