use super::types::BoardArray;
use super::Position;
use crate::board::bitboard_set::BitboardSet;
use crate::board::state_info::StateStack;
use crate::board::zobrist::ZobristKey;
use crate::types::{Bitboard, Color, EnteringKingRule, Hand, PieceType, Square};

impl Position {
    /// 新しい空の盤面を作成
    #[must_use]
    pub fn empty() -> Self {
        Self {
            board: BoardArray::empty(),
            bitboards: BitboardSet::new(),
            hands: [Hand::ZERO; Color::COUNT],
            zobrist: ZobristKey::default(),
            board_key: ZobristKey::default(),
            hand_key: ZobristKey::default(),
            side_to_move: Color::BLACK,
            entering_king_rule: EnteringKingRule::None,
            entering_king_point: [0, 0],
            ply: 1,
            st_index: 0,
            state_stack: std::cell::RefCell::new(StateStack::new()),
            king_square: [Square::NONE; Color::COUNT],
            checkers_cache: Bitboard::EMPTY,
            check_squares_cache: [Bitboard::EMPTY; PieceType::COUNT],
            pinners_cache: [Bitboard::EMPTY; Color::COUNT],
            blockers_for_king: [Bitboard::EMPTY; Color::COUNT],
        }
    }

    /// スタックを初期化する（探索開始時などに使用）
    pub fn init_stack(&mut self) {
        let state_snapshot = {
            let mut stack = self.state_stack_mut();
            stack.reset_sfen();
            let state = stack.current_mut();
            state.board_key = self.board_key;
            state.hand_key = self.hand_key;
            self.compute_caches_for_state(state);
            state.hand = self.hand(self.turn());
            state.clone()
        };

        self.sync_caches_from_state(&state_snapshot);
        let st_index = {
            let stack = self.state_stack();
            stack.current_index()
        };
        self.st_index = st_index;
    }
}
