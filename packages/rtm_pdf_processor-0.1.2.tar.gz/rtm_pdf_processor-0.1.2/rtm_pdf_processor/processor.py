import os
from pdf2image import convert_from_path
import pytesseract
from tqdm import tqdm

class RTMPdfProcessor:
    def __init__(self, pdfs_dir="./PDFS", images_dir="PdfImages", texts_dir="PdfTextFiles"):
        try:
            self.pdfs_dir = pdfs_dir
            self.images_dir = images_dir
            self.texts_dir = texts_dir
        except Exception as e:
            raise e

    def loadPdfs(self):
        try:
            if not os.path.exists(self.pdfs_dir):
                raise FileNotFoundError(f"PDFS folder not found in project root directory. Create 'PDFS' folder in root directory and place PDF files inside it.")

            pdf_files = []
            #for file_name in os.listdir(self.pdfs_dir):
            for file_name in tqdm(os.listdir(self.pdfs_dir),desc="Scanning PDFs",unit="file"):
                if file_name.endswith('.pdf'):
                    pdf_files.append(os.path.join(self.pdfs_dir, file_name))
            return pdf_files
        except Exception as e:
            raise e

    # def readPdf(self,file_path):
    #     try:
    #         with open(file_path, 'rb') as file:
    #             content = file.read()
    #         return content
    #     except Exception as e:
    #         raise e
        
    def readPdf(self, file_path, chunk_size=1024 * 1024):
        try:
            file_size = os.path.getsize(file_path)
            content = b""

            with open(file_path, "rb") as file, tqdm(total=file_size,desc="Reading PDF",
                                                     unit="B",unit_scale=True) as pbar:
                while chunk := file.read(chunk_size):
                    content += chunk
                    pbar.update(len(chunk))

            return content

        except Exception as e:
            raise e
        
    def extractTextFromPdf(self,file_path,save_text_files=True,save_image_files=True):
        try:
            text = ""
            images = convert_from_path(file_path)
            
            if save_image_files:
                self.__saveImageFromImages(images, file_path)

            base_name = os.path.basename(file_path).replace('.pdf', '')
            
            pdf_pages_dir = self.texts_dir
            os.makedirs(pdf_pages_dir, exist_ok=True)

            pdf_pdf_pages_dir = os.path.join(pdf_pages_dir, base_name)
            os.makedirs(pdf_pdf_pages_dir, exist_ok=True)

            #for i, image in enumerate(images):
            for i, image in enumerate(tqdm(images, desc=f"Saving text files for  {base_name}", unit="page")):
                #print(f"Reading page {i+1} of {base_name}")
                page_text = pytesseract.image_to_string(image, lang='hin+eng')
                text += f"Page {i+1}:\n{page_text}\n\n"
                page_output_path = os.path.join(pdf_pdf_pages_dir, f"page_{i+1}.txt")
                
                if(save_text_files):
                    with open(page_output_path, 'w', encoding='utf-8') as f:
                        f.write(page_text)
                #print(f"Saved text: {page_output_path}")
                
            return text
        except Exception as e:
            raise e

    def __saveImageFromImages(self, images, file_path):
        try:
            os.makedirs(self.images_dir, exist_ok=True)
            base_name = os.path.basename(file_path).replace('.pdf', '')
            pdf_images_dir = os.path.join(self.images_dir, base_name)
            os.makedirs(pdf_images_dir, exist_ok=True)
            #for i, image in enumerate(images):
            for i, image in enumerate(tqdm(images, desc=f"Saving image files for {base_name}", unit="page")):
                output_path = os.path.join(pdf_images_dir, f"page_{i+1}.jpg")
                image.save(output_path, "JPEG")
                #print(f"Saved: {output_path}")
        except Exception as e:
            raise e