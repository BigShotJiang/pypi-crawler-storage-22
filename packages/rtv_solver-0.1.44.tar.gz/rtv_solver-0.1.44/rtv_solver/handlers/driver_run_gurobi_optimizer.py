import gurobipy as gp
from gurobipy import GRB
import numpy as np
import copy
import logging
from typing import Dict, List, Tuple, Optional

from .network_handler import NetworkHandler
from .payload_parser import PayloadParser
from ..structure.node import Node


class DriverRunGurobiOptimizer:
    def __init__(self, dwell_pickup: int = 180, dwell_dropoff: int = 60, time_limit: int = 5, return_cost: bool = False):
        self.dwell_pickup = dwell_pickup
        self.dwell_dropoff = dwell_dropoff
        self.time_limit = time_limit
        self.return_cost = return_cost

    def reoptimize_driver_run(self, driver_run: Dict, depot: Dict, request: Dict = None) -> Tuple[Dict, float, bool]:
        state = driver_run[PayloadParser.DRIVER_STATE]
        manifest = driver_run[PayloadParser.DRIVER_MANIFEST]

        completed_no = state[PayloadParser.DRIVER_STATE_LOC_SERV]
        completed_stops = manifest[:completed_no]
        remaining_stops = manifest[completed_no:]

        if request==None and len(remaining_stops) <= 1:
            return driver_run, True

        # Compute current load from completed stops
        current_load = 0
        for stop in completed_stops:
            if stop["action"] == "pickup":
                current_load += stop["am"]
            else:
                current_load -= stop["am"]

        state_loc = state[PayloadParser.DRIVER_STATE_LOC]
        current_time = state[PayloadParser.DRIVER_STATE_DT_SEC]
        end_time = state["end_time"]

        if request != None:
            pickup_stop = {'run_id': state["run_id"], 'booking_id': request['booking_id'], 'order': -1, 'action': "pickup", 
            "loc": request["pickup_pt"], 'scheduled_time': int((end_time+current_time)/2), 
            'am': request["am"], 'wc': request["wc"], 'time_window_start': request['pickup_time_window_start'],
            'time_window_end': request['pickup_time_window_end']}
            dropoff_stop = {'run_id': state["run_id"], 'booking_id': request['booking_id'], 'order': -1, 'action': "dropoff",
                "loc": request["dropoff_pt"], 'scheduled_time': int((end_time+current_time)/2), 
                'am': request["am"], 'wc': request["wc"], 'time_window_start': request['dropoff_time_window_start'],
                'time_window_end': request['dropoff_time_window_end']}
            remaining_stops.append(pickup_stop)
            remaining_stops.append(dropoff_stop)

        nb_customers = len(remaining_stops)
        truck_capacity = state["am_capacity"]
        start_node_id = state_loc["node_id"]
        depot_node_id = depot["pt"]["node_id"]

        # Build arrays
        demands_data = [0] * nb_customers
        service_time_data = [0] * nb_customers
        earliest_start_data = [0] * nb_customers
        latest_end_data = [0] * nb_customers
        pick_up_index = [0] * nb_customers
        delivery_index = [0] * nb_customers

        booking_to_pick = {}
        booking_to_drop = {}
        for i, stop in enumerate(remaining_stops):
            if stop["action"] == "pickup":
                booking_to_pick[stop["booking_id"]] = i
            else:
                booking_to_drop[stop["booking_id"]] = i

        for i, stop in enumerate(remaining_stops):
            action = stop["action"]
            amt = stop["am"]
            service_time_data[i] = self.dwell_pickup if action == "pickup" else self.dwell_dropoff
            earliest_start_data[i] = stop["time_window_start"]
            latest_end_data[i] = stop["time_window_end"]
            if action == "pickup":
                demands_data[i] = amt
                pick_up_index[i] = -1
                delivery_index[i] = booking_to_drop.get(stop["booking_id"], -1)
            else:
                demands_data[i] = -amt
                pick_up_index[i] = booking_to_pick.get(stop["booking_id"], -1)
                delivery_index[i] = -1

        # Distance matrices including depot/current location as 0 index
        travel_times = [[0] * (nb_customers + 1) for _ in range(nb_customers + 1)]
        # from depot/current location (index 0) to customers 1..n
        start_node = Node(state_loc["lat"], state_loc["lon"], id=start_node_id)
        depot_node = Node(depot["pt"]["lat"], depot["pt"]["lon"], id=depot_node_id)
        
        for j, stop in enumerate(remaining_stops):
            stop_node = Node(stop["loc"]["lat"], stop["loc"]["lon"], id=stop["loc"]["node_id"])
            travel_times[0][j + 1] = NetworkHandler.travel_time(start_node, stop_node)
            travel_times[j + 1][0] = NetworkHandler.travel_time(stop_node, depot_node)
        # inter-customers
        for i, stop_i in enumerate(remaining_stops):
            for j, stop_j in enumerate(remaining_stops):
                if i == j:
                    continue
                node_i = Node(stop_i["loc"]["lat"], stop_i["loc"]["lon"], id=stop_i["loc"]["node_id"])
                node_j = Node(stop_j["loc"]["lat"], stop_j["loc"]["lon"], id=stop_j["loc"]["node_id"])
                travel_times[i + 1][j + 1] = NetworkHandler.travel_time(node_i, node_j)

        try:
            with gp.Env(empty=True) as env:
                env.setParam('OutputFlag', 0)
                env.start()
                
                model = gp.Model('DriverRunOptimization', env=env)
                
                # Decision variables: x[i][j] = 1 if stop j is visited immediately after stop i
                x = {}
                for i in range(nb_customers + 1):  # +1 for depot, depot is 0
                    for j in range(nb_customers + 1):
                        if i != j:
                            x[i, j] = model.addVar(vtype=GRB.BINARY, name=f'x_{i}_{j}')
                
                # Time variables: t[i] = arrival time at stop i
                t = {}
                for i in range(nb_customers):
                    t[i] = model.addVar(lb=current_time+travel_times[0][i+1], ub=end_time-travel_times[i+1][0]-service_time_data[i], name=f't_{i}')
                
                # Load variables: l[i] = load after visiting stop i
                l = {}
                for i in range(nb_customers):
                    l[i] = model.addVar(lb=0, ub=state["am_capacity"], name=f'l_{i}')
                
                # Objective: minimize travel time
                # if objective == "travel_time":
                if self.return_cost:
                    model.setObjective(
                        gp.quicksum(travel_times[i][j] * x[i, j] 
                                    for i in range(nb_customers + 1) 
                                    for j in range(nb_customers + 1) if i != j),
                        GRB.MINIMIZE
                    )
                else:
                    model.setObjective(
                        gp.quicksum(travel_times[i][j] * x[i, j] 
                                    for i in range(nb_customers + 1) 
                                    for j in range(1, nb_customers + 1) if i != j),
                        GRB.MINIMIZE
                    )
                # else:  # total_time
                #     model.setObjective(
                #         gp.quicksum(t[i] for i in range(nb_customers)),
                #         GRB.MINIMIZE
                    # )
                
                # Constraints
                
                # 1. Each stop must be visited exactly once (from depot or another stop)
                for j in range(nb_customers+1):
                    model.addConstr(
                        gp.quicksum(x[i, j] for i in range(nb_customers + 1) if i != j) == 1,
                        name=f'visit_{j}'
                    )
                
                # 2. Each stop must be left exactly once (to depot or another stop)
                for i in range(nb_customers+1):
                    model.addConstr(
                        gp.quicksum(x[i, j] for j in range(nb_customers + 1) if i != j) == 1,
                        name=f'leave_{i}'
                    )
                
                # 4. Pickup-delivery precedence constraints
                for booking_id in booking_to_pick:
                    # Delivery must come after pickup
                    pickup_idx = booking_to_pick[booking_id]
                    delivery_idx = booking_to_drop.get(booking_id, -1)
                    model.addConstr(t[delivery_idx] >= t[pickup_idx], 
                                    name=f'precedence_{pickup_idx}_{delivery_idx}')
                
                # 5. Time window constraints
                for i in range(nb_customers):
                    model.addConstr(t[i] >= earliest_start_data[i], 
                                  name=f'tw_start_{i}')
                    model.addConstr(t[i] <= latest_end_data[i], 
                                  name=f'tw_end_{i}')
                
                # 6. Travel time and service time constraints
                for i in range(nb_customers):
                    for j in range(nb_customers):
                        if i != j:
                            model.addConstr(
                                t[j] >= t[i] + travel_times[i+1][j+1] + service_time_data[i] - 
                                (1 - x[i+1, j+1]) * 1000000,  # Big M constraint
                                name=f'travel_{i}_{j}'
                            )
                
                # 7. Capacity constraints (linear with Big M)
                M = state["am_capacity"]  # Big M value. M is the capacity of the vehicle.
                
                for i in range(nb_customers):
                    # Load at stop i = load from previous stop + load change at stop i
                    demand = demands_data[i]
                    
                    # If coming from depot (index nb_customers), load is just the load change
                    model.addConstr(
                        l[i] >= current_load + demand - M * (1 - x[0, i+1]),
                        name=f'load_from_depot_{i}'
                    )
                    
                    # If coming from another stop j, load is previous load + load change
                    for j in range(nb_customers):
                        if j != i:
                            model.addConstr(
                                l[i] >= l[j] + demand - M * (1 - x[j+1, i+1]),
                                name=f'load_from_stop_{j}_{i}'
                            )
                
                # Set initial solution (current stop sequence)
                x[0, 1].start = 1.0  # Go from depot to first stop
            
                # Connect stops in current order
                for i in range(nb_customers):
                    x[i, i + 1].start = 1.0  # Go from stop i to stop i+1
                
                # Return to depot from last stop
                x[nb_customers, 0].start = 1.0  # Go from last stop to depot
                
                # Set all other x variables to 0
                for i in range(nb_customers + 1):
                    for j in range(nb_customers + 1):
                        if i == 0 and j == 1:
                            continue
                        if i == nb_customers and j == 0:
                            continue
                        if i + 1 == j:
                            continue
                        if i == j:
                            continue
                        x[i, j].start = 0.0
                
                # Set initial time values using scheduled times
                current_load_value = current_load
                
                for i in range(nb_customers):
                    # Use the scheduled time for each stop
                    t[i].start = remaining_stops[i]["scheduled_time"]
                    
                    # Set initial load values
                    demand = demands_data[i]
                    current_load_value += demand
                    l[i].start = current_load_value
                
                # Write model to file for debugging
                # try:
                #     model.write('driver_run_optimization.lp')
                #     logging.debug("Model written to driver_run_optimization.lp")
                # except Exception as e:
                #     logging.warning(f"Failed to write model to file: {e}")
                
                # Solve the model
                model.setParam('TimeLimit', self.time_limit)  # reset time limit
                model.setParam('MIPGap', 0.05)  # 5% gap
                model.optimize()

                time_taken = model.Runtime
                logging.debug(f"Time taken for reoptimization of driver run: {time_taken} seconds")
                if model.Status == GRB.OPTIMAL or model.Status == GRB.SUBOPTIMAL or model.Status == GRB.TIME_LIMIT:
                    # Extract solution
                    sequence = []
                    current = 0  # Start from depot

                    while len(sequence) < nb_customers:
                        for j in range(nb_customers):
                            if current != j+1 and x[current, j+1].X > 0.5:  # If x[current, j] = 1
                                sequence.append(j)
                                current = j+1
                                break
                    
                    # Update scheduled times
                    # extract route
                    new_driver_run = {PayloadParser.DRIVER_STATE: copy.deepcopy(state),
                              PayloadParser.DRIVER_MANIFEST: copy.deepcopy(completed_stops)}
                    remaining_stops = copy.deepcopy(remaining_stops)
                    current_node = start_node
                    current_time = state[PayloadParser.DRIVER_STATE_DT_SEC]
                    current_order = completed_no + 1
                    for idx in sequence:
                        stop = remaining_stops[idx]
                        next_node = Node(stop["loc"]["lat"], stop["loc"]["lon"], id=stop["loc"]["node_id"])
                        travel_time = NetworkHandler.travel_time(current_node, next_node)
                        current_time += travel_time
                        if current_time < stop["time_window_start"]:
                            current_time = stop["time_window_start"]
                        action = stop["action"]
                        demand = stop["am"] if action == "pickup" else -stop["am"]
                        new_stop = {
                            'run_id': state[PayloadParser.DRIVER_STATE_RUN_ID],
                            'booking_id': stop['booking_id'],
                            'order': current_order,
                            'action': action,
                            'loc': stop['loc'],
                            'scheduled_time': current_time,
                            'am': demand if action == 'pickup' else -demand,
                            'wc': stop.get('wc', 0),
                            'time_window_start': stop['time_window_start'],
                            'time_window_end': stop['time_window_end']
                        }
                        current_node = next_node
                        current_order += 1
                        current_time += self.dwell_pickup if action == 'pickup' else self.dwell_dropoff
                        new_driver_run[PayloadParser.DRIVER_MANIFEST].append(new_stop)

                    new_driver_run[PayloadParser.DRIVER_STATE][PayloadParser.DRIVER_STATE_T_LOCS] = len(new_driver_run[PayloadParser.DRIVER_MANIFEST])
                        
                    return new_driver_run, True
                else:
                    logging.debug(f"Gurobi optimization failed with status: {model.Status}")
                    return None, False
                    
        except Exception as e:
            logging.error(f"Gurobi optimization error: {e}")
            return None, False
    
