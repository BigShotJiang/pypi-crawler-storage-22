from typing import Dict, List, Tuple
import copy
import numpy as np
import hexaly.optimizer
from hexaly.optimizer import HxCallbackType
from hexaly.optimizer import HxSolutionStatus
from .payload_parser import PayloadParser
from ..structure.node import Node
from .network_handler import NetworkHandler


class DriverRunHexalyOptimizer:
    def __init__(self, dwell_pickup: int = 180, dwell_dropoff: int = 60, time_limit: int = 5, return_cost: bool = False):
        self.dwell_pickup = dwell_pickup
        self.dwell_dropoff = dwell_dropoff
        self.time_limit = time_limit
        self.return_cost = return_cost

    def reoptimize_driver_run(self, driver_run: Dict, depot: Dict) -> Tuple[Dict, float, bool]:
        state = driver_run[PayloadParser.DRIVER_STATE]
        manifest = driver_run[PayloadParser.DRIVER_MANIFEST]

        completed_no = state[PayloadParser.DRIVER_STATE_LOC_SERV]
        completed_stops = manifest[:completed_no]
        remaining_stops = manifest[completed_no:]

        if len(remaining_stops) <= 1:
            return driver_run, True

        # Compute current load from completed stops
        current_load = 0
        for stop in completed_stops:
            if stop["action"] == "pickup":
                current_load += stop["am"]
            else:
                current_load -= stop["am"]

        state_loc = state[PayloadParser.DRIVER_STATE_LOC]

        # Use NetworkHandler.travel_time directly instead of recalculating matrix

        nb_customers = len(remaining_stops)
        truck_capacity = state["am_capacity"]
        start_node_id = state_loc["node_id"]
        depot_node_id = depot["pt"]["node_id"]

        # Build arrays
        demands_data = [0] * nb_customers
        service_time_data = [0] * nb_customers
        earliest_start_data = [0] * nb_customers
        latest_end_data = [0] * nb_customers
        pick_up_index = [0] * nb_customers
        delivery_index = [0] * nb_customers

        booking_to_pick = {}
        booking_to_drop = {}
        for i, stop in enumerate(remaining_stops):
            if stop["action"] == "pickup":
                booking_to_pick[stop["booking_id"]] = i
            else:
                booking_to_drop[stop["booking_id"]] = i

        for i, stop in enumerate(remaining_stops):
            action = stop["action"]
            amt = stop["am"]
            service_time_data[i] = self.dwell_pickup if action == "pickup" else self.dwell_dropoff
            earliest_start_data[i] = stop["time_window_start"]
            latest_end_data[i] = stop["time_window_end"]
            if action == "pickup":
                demands_data[i] = amt
                pick_up_index[i] = -1
                delivery_index[i] = booking_to_drop.get(stop["booking_id"], -1)
            else:
                demands_data[i] = -amt
                pick_up_index[i] = booking_to_pick.get(stop["booking_id"], -1)
                delivery_index[i] = -1

        # Distance matrices including depot/current location as 0 index
        dist_matrix_data = [[0] * (nb_customers + 1) for _ in range(nb_customers + 1)]
        # from depot/current location (index 0) to customers 1..n
        start_node = Node(state_loc["lat"], state_loc["lon"], id=start_node_id)
        depot_node = Node(depot["pt"]["lat"], depot["pt"]["lon"], id=depot_node_id)
        
        for j, stop in enumerate(remaining_stops):
            stop_node = Node(stop["loc"]["lat"], stop["loc"]["lon"], id=stop["loc"]["node_id"])
            dist_matrix_data[0][j + 1] = NetworkHandler.travel_time(start_node, stop_node)
            dist_matrix_data[j + 1][0] = NetworkHandler.travel_time(stop_node, depot_node)
        # inter-customers
        for i, stop_i in enumerate(remaining_stops):
            for j, stop_j in enumerate(remaining_stops):
                if i == j:
                    continue
                node_i = Node(stop_i["loc"]["lat"], stop_i["loc"]["lon"], id=stop_i["loc"]["node_id"])
                node_j = Node(stop_j["loc"]["lat"], stop_j["loc"]["lon"], id=stop_j["loc"]["node_id"])
                dist_matrix_data[i + 1][j + 1] = NetworkHandler.travel_time(node_i, node_j)

        with hexaly.optimizer.HexalyOptimizer() as optimizer:
            optimizer.param.verbosity = 0
            model = optimizer.model
            # Single truck case
            customers_sequence = model.list(nb_customers)
            # All customers must be visited exactly once
            model.constraint(model.count(customers_sequence) == nb_customers)

            # Hexaly arrays
            demands = model.array(demands_data)
            earliest = model.array(earliest_start_data)
            latest = model.array(latest_end_data)
            service_time = model.array(service_time_data)
            dist_matrix = model.array(dist_matrix_data)

            # capacity constraints along the route
            c = model.count(customers_sequence)
            demand_lambda = model.lambda_function(
                lambda i, prev: prev + demands[customers_sequence[i]]
            )
            route_load = model.array(model.range(0, c), demand_lambda, current_load)
            model.constraint(model.and_(model.range(0, c), model.lambda_function(
                lambda i: route_load[i] <= truck_capacity)))
            model.constraint(model.and_(model.range(0, c), model.lambda_function(
                lambda i: route_load[i] >= 0)))

            # time accumulation and time windows
            end_lambda = model.lambda_function(
                lambda i, prev:
                    model.max(
                        earliest[customers_sequence[i]],
                        model.iif(
                            i == 0,
                            prev + model.at(dist_matrix, 0, customers_sequence[0] + 1),
                            prev + model.at(dist_matrix, customers_sequence[i - 1]+1, customers_sequence[i]+1) + service_time[customers_sequence[i-1]])
                        )
                    )

            end_time = model.array(model.range(0, c), end_lambda, state["location_dt_seconds"])
            # latest window
            model.constraint(model.and_(model.range(1, c), model.lambda_function(
                lambda i: end_time[i] <= latest[customers_sequence[i]])))
            # ensure return to depot within horizon
            model.constraint(model.iif(c > 0,
                                       end_time[c - 1] + model.at(service_time, customers_sequence[c-1]) + model.at(dist_matrix, customers_sequence[c - 1] + 1, 0)
                                       <= state["end_time"],
                                       True))

            # precedence constraints pickup before delivery
            for j in range(nb_customers):
                if pick_up_index[j] == -1 and delivery_index[j] >= 0:
                    # j is pickup, delivery_index[j] is delivery
                    pick_idx = j
                    del_idx = delivery_index[j]
                    # find positions in sequence and enforce order
                    seq = model.array([customers_sequence])
                    pick_list_index = model.find(seq, pick_idx)
                    del_list_index = model.find(seq, del_idx)
                    model.constraint(pick_list_index == del_list_index)
                    same_list = model.at(seq, pick_list_index)
                    model.constraint(model.index(same_list, pick_idx) < model.index(same_list, del_idx))

            # objective: minimize total travel time (including return)
            if self.return_cost:
                total_distance = model.iif(c > 0,
                                        model.sum(model.range(1, c), model.lambda_function(
                                            lambda i: model.at(dist_matrix, customers_sequence[i - 1] + 1, customers_sequence[i] + 1)
                                        )) + model.at(dist_matrix, 0, customers_sequence[0] + 1)
                                        + model.at(dist_matrix, customers_sequence[c - 1] + 1, 0),
                                        0)
            else:
                total_distance = model.iif(c > 0,
                                        model.sum(model.range(1, c), model.lambda_function(
                                            lambda i: model.at(dist_matrix, customers_sequence[i - 1] + 1, customers_sequence[i] + 1)
                                        )) + model.at(dist_matrix, 0, customers_sequence[0] + 1),
                                        0)
            model.minimize(total_distance)
            model.close()

            # adding existing schedule
            customer_seq_val = customers_sequence.get_value()
            customer_seq_val.clear()
            for i, _ in enumerate(remaining_stops):
                customer_seq_val.add(i)

            optimizer.param.time_limit = self.time_limit
            optimizer.solve()

            # extract route
            new_driver_run = {PayloadParser.DRIVER_STATE: copy.deepcopy(state),
                              PayloadParser.DRIVER_MANIFEST: manifest[:completed_no]}
            if optimizer.solution.status != HxSolutionStatus.FEASIBLE and optimizer.solution.status != HxSolutionStatus.OPTIMAL:
                return driver_run, False

            seq_vals = customers_sequence.value
            if not seq_vals:
                return driver_run, True

            # Build new manifest based on sequence
            current_time = state[PayloadParser.DRIVER_STATE_DT_SEC]
            current_node = start_node
            current_order = completed_no + 1
            cost_before = 0
            for stop in remaining_stops:
                next_node = Node(stop["loc"]["lat"], stop["loc"]["lon"], id=stop["loc"]["node_id"])
                cost_before += NetworkHandler.travel_time(current_node, next_node)
                current_node = next_node

            current_node = start_node
            cost_after = 0
            for idx in seq_vals:
                stop = remaining_stops[idx]
                next_node = Node(stop["loc"]["lat"], stop["loc"]["lon"], id=stop["loc"]["node_id"])
                travel_time = NetworkHandler.travel_time(current_node, next_node)
                current_time += travel_time
                if current_time < stop["time_window_start"]:
                    current_time = stop["time_window_start"]
                action = stop["action"]
                demand = stop["am"] if action == "pickup" else -stop["am"]
                new_stop = {
                    'run_id': state[PayloadParser.DRIVER_STATE_RUN_ID],
                    'booking_id': stop['booking_id'],
                    'order': current_order,
                    'action': action,
                    'loc': stop['loc'],
                    'scheduled_time': current_time,
                    'am': demand if action == 'pickup' else -demand,
                    'wc': stop.get('wc', 0),
                    'time_window_start': stop['time_window_start'],
                    'time_window_end': stop['time_window_end'],
                    'dwell': self.dwell_pickup if action == 'pickup' else self.dwell_dropoff
                }
                current_node = next_node
                current_order += 1
                current_time += self.dwell_pickup if action == 'pickup' else self.dwell_dropoff
                cost_after += travel_time
                new_driver_run[PayloadParser.DRIVER_MANIFEST].append(new_stop)

            new_driver_run[PayloadParser.DRIVER_STATE][PayloadParser.DRIVER_STATE_T_LOCS] = len(new_driver_run[PayloadParser.DRIVER_MANIFEST])
            return new_driver_run, True
